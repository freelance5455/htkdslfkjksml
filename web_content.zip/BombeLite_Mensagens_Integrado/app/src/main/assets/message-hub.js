(() => {
  const conversations = [
    {name:'João Silva',platform:'WhatsApp',preview:'Tá chegando aí? 🚀',time:'12:34',icon:'🟢',messages:[['Tá chegando aí? 🚀',false],['Sim, já tô saindo agora!',true],['Beleza! Te espero 😊',false]]},
    {name:'Maria Souza',platform:'Messenger',preview:'Beleza! Te vejo depois então. 😊',time:'11:58',icon:'🔵',messages:[['Vamos marcar para amanhã?',false],['Beleza! Te vejo depois então. 😊',true]]},
    {name:'Lucas Gamer',platform:'Discord',preview:'Bora jogar mais tarde?',time:'11:20',icon:'🎮',messages:[['Bora jogar mais tarde?',false],['Fechado, te chamo!',true]]},
    {name:'Ana Clara',platform:'Instagram',preview:'Amei a foto 😍',time:'10:45',icon:'📸',messages:[['Amei a foto 😍',false],['Obrigada!! 💜',true]]},
    {name:'Grupo da Família',platform:'WhatsApp',preview:'Vovó: Já almoçaram?',time:'09:32',icon:'🟢',messages:[['Vovó: Já almoçaram?',false],['Sim, vó! 😄',true]]},
    {name:'Trabalho',platform:'Telegram',preview:'Reunião às 15h, ok?',time:'08:17',icon:'✈️',messages:[['Reunião às 15h, ok?',false],['Ok, confirmado.',true]]},
    {name:'Sistema',platform:'SMS',preview:'Nova mensagem de exemplo',time:'Ontem',icon:'✉️',messages:[['Nova mensagem SMS de demonstração.',false]]}
  ];
  let activeFilter = 'Todos';
  let activeConversation = conversations[0];
  let pendingServerText = '';
  let localChats = {};
  try { localChats = JSON.parse(localStorage.getItem('bombeLiteLocalChats') || '{}') || {}; } catch (_) { localChats = {}; }
  for (const item of conversations) {
    const saved = localChats[item.name];
    if (Array.isArray(saved) && saved.length) {
      const latest = saved[saved.length - 1];
      if (latest && latest.text) { item.preview = latest.text; item.time = latest.time || item.time; }
    }
  }

  function showConversation(item) {
    activeConversation = item;
    document.querySelectorAll('.demo-conversation').forEach(row => row.classList.toggle('selected', row.dataset.name === item.name));
    document.querySelector('#previewAvatar').textContent = item.icon;
    document.querySelector('#previewName').textContent = item.name + ' (' + item.platform + ')';
    document.querySelector('#previewStatus').textContent = 'Prévia de demonstração';
    const chat = document.querySelector('#messageDemoChat');
    chat.replaceChildren();
    for (const message of messagesFor(item)) {
      const bubble = document.createElement('div');
      bubble.className = 'demo-bubble' + (message.outgoing ? ' outgoing' : '');
      bubble.textContent = message.text;
      chat.append(bubble);
    }
  }

  window.renderMessageConversations = (filter = activeFilter) => {
    activeFilter = filter;
    const query = (document.querySelector('#messageSearch')?.value || '').trim().toLocaleLowerCase('pt-BR');
    const list = document.querySelector('#messageConversationList');
    if (!list) return;
    list.replaceChildren();
    const visible = conversations.filter(item => (filter === 'Todos' || item.platform === filter) && (item.name + ' ' + item.preview).toLocaleLowerCase('pt-BR').includes(query));
    for (const item of visible) {
      const row = document.createElement('button');
      row.type = 'button';
      row.className = 'demo-conversation' + (item === activeConversation ? ' selected' : '');
      row.dataset.name = item.name;
      const avatar = document.createElement('span'); avatar.className = 'demo-avatar'; avatar.textContent = item.icon;
      const copy = document.createElement('span'); copy.className = 'demo-copy';
      const name = document.createElement('strong'); name.textContent = item.name + ' (' + item.platform + ')';
      const preview = document.createElement('small'); preview.textContent = item.preview;
      copy.append(name, preview);
      const time = document.createElement('span'); time.className = 'demo-meta'; time.textContent = item.time;
      row.append(avatar, copy, time);
      row.onclick = () => showConversation(item);
      list.append(row);
    }
    if (!visible.length) {
      const empty = document.createElement('p');
      empty.className = 'message-preview-note';
      empty.textContent = 'Nenhum exemplo nesta categoria.';
      list.append(empty);
    }
    if (visible.length && !visible.includes(activeConversation)) showConversation(visible[0]);
    document.querySelectorAll('[data-message-filter]').forEach(button => button.classList.toggle('active', button.dataset.messageFilter === filter));
  };

  function currentTime() {
    return new Intl.DateTimeFormat('pt-BR', {hour:'2-digit', minute:'2-digit'}).format(new Date());
  }

  function messagesFor(item) {
    const saved = localChats[item.name];
    if (Array.isArray(saved)) return saved;
    return item.messages.map(([text, outgoing]) => ({text, outgoing, time:item.time || currentTime()}));
  }

  function openLocalChat(item) {
    if (!item) return;
    activeConversation = item;
    document.querySelector('#localChatAvatar').textContent = item.icon;
    document.querySelector('#localChatName').textContent = item.name;
    document.querySelector('#local-chat-screen').hidden = false;
    renderLocalChat();
    setTimeout(() => document.querySelector('#localChatInput')?.focus(), 100);
  }

  function renderLocalChat() {
    if (!activeConversation) return;
    const thread = document.querySelector('#localChatThread');
    thread.replaceChildren();
    for (const message of messagesFor(activeConversation)) {
      const bubble = document.createElement('article');
      bubble.className = 'local-message ' + (message.outgoing ? 'outgoing' : 'incoming');
      const owner = document.createElement('small'); owner.className = 'local-message-owner';
      owner.textContent = message.outgoing ? 'Você' : activeConversation.name;
      const body = document.createElement('span'); body.textContent = message.text;
      const time = document.createElement('small'); time.className = 'local-message-time'; time.textContent = message.time || '';
      bubble.append(owner, body, time); thread.append(bubble);
    }
    requestAnimationFrame(() => { thread.scrollTop = thread.scrollHeight; });
  }

  function sendLocalMessage(text) {
    const body = text.trim();
    if (!body || !activeConversation) return;
    const messages = messagesFor(activeConversation);
    messages.push({text:body, outgoing:true, time:currentTime()});
    localChats[activeConversation.name] = messages;
    try { localStorage.setItem('bombeLiteLocalChats', JSON.stringify(localChats)); } catch (_) { showToast('Não foi possível salvar o histórico neste aparelho.'); }
    activeConversation.preview = body;
    activeConversation.time = currentTime();
    renderLocalChat();
    showConversation(activeConversation);
    const row = [...document.querySelectorAll('.demo-conversation')].find(item => item.dataset.name === activeConversation.name);
    if (row) {
      const preview = row.querySelector('.demo-copy small');
      const time = row.querySelector('.demo-meta');
      if (preview) preview.textContent = activeConversation.preview;
      if (time) time.textContent = activeConversation.time;
    }
    document.querySelector('#localChatInput').value = '';
  }

  function sendViaServer() {
    const endpoint = document.querySelector('#messageServerEndpoint').value.trim();
    const phone = document.querySelector('#messagePhone').value.replace(/\D/g, '');
    const message = document.querySelector('#messageText').value.trim();
    let parsed;
    try { parsed = new URL(endpoint); } catch (_) { showToast('Informe a URL HTTPS do seu servidor.'); return; }
    if (parsed.protocol !== 'https:' || !parsed.host || parsed.hostname.toLowerCase() === 'seu-servidor.com') {
      showToast('Configure o endpoint HTTPS real do seu servidor.'); return;
    }
    if (!phone || !message) { showToast('Preencha telefone e mensagem antes de enviar.'); return; }
    if (!window.AndroidApp || typeof window.AndroidApp.sendWhatsAppViaServer !== 'function') {
      showToast('O envio via servidor está disponível no app Android instalado.'); return;
    }
    pendingServerText = message;
    const button = document.querySelector('#sendServerMessage');
    button.disabled = true;
    window.AndroidApp.sendWhatsAppViaServer(endpoint, phone, message);
  }

  window.serverSendResult = (success, message) => {
    const button = document.querySelector('#sendServerMessage');
    button.disabled = false;
    if (success && document.querySelector('#messageText').value.trim() === pendingServerText) {
      document.querySelector('#messageText').value = '';
    }
    showToast(message || (success ? 'O servidor aceitou a solicitação.' : 'O servidor não confirmou o envio.'));
  };

  document.querySelectorAll('[data-message-filter]').forEach(button => {
    button.onclick = () => window.renderMessageConversations(button.dataset.messageFilter);
  });
  document.querySelector('#messageSearch').addEventListener('input', () => window.renderMessageConversations(activeFilter));
  document.querySelector('#newMessage').onclick = () => { document.querySelector('#messageComposer').hidden = false; };
  document.querySelector('#messageComposeBack').onclick = () => { document.querySelector('#messageComposer').hidden = true; };
  document.querySelector('#messageSettings').onclick = () => showToast('A lista é demonstrativa; o WhatsApp pode abrir com mensagem preparada e o envio via Business exige endpoint configurado.');
  document.querySelector('#messageMore').onclick = () => showToast('Conversas de exemplo — não há outras contas conectadas.');
  document.querySelector('#previewMore').onclick = () => showToast('Esta conversa é apenas uma prévia demonstrativa.');
  document.querySelector('#openLocalChat').onclick = () => openLocalChat(activeConversation);
  document.querySelector('#localChatBack').onclick = () => { document.querySelector('#local-chat-screen').hidden = true; };
  document.querySelector('#localChatMore').onclick = () => showToast('As mensagens enviadas aqui ficam salvas apenas neste aparelho.');
  document.querySelector('#localChatForm').addEventListener('submit', event => { event.preventDefault(); sendLocalMessage(document.querySelector('#localChatInput').value); });
  document.querySelector('#previewBack').onclick = () => window.renderMessageConversations('Todos');
  document.querySelector('#sendServerMessage').onclick = sendViaServer;
  window.renderMessageConversations('Todos');
})();
