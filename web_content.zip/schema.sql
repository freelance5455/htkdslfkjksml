-- ARENA 7X · Supabase schema (run once in SQL Editor). TEST MODE until approvals are in place.
create extension if not exists pgcrypto;

create table profiles(id uuid primary key references auth.users on delete cascade, player_id text unique not null, email text,
  ff_uid text, ign text, role text not null default 'user' check(role in('user','admin')), banned bool not null default false, created_at timestamptz default now());
create table wallets(user_id uuid primary key references profiles on delete cascade, balance numeric(12,2) not null default 0 check(balance>=0));
create table ledger(id bigserial primary key, user_id uuid not null references profiles, kind text not null check(kind in('deposit','withdrawal','entry','winning','refund')),
  amount numeric(12,2) not null, balance_after numeric(12,2) not null, ref text, note text, created_at timestamptz default now());
create table tournaments(id uuid primary key default gen_random_uuid(), name text not null, mode text not null check(mode in('solo','duo','squad')),
  banner_url text, entry_fee numeric(10,2) not null default 0 check(entry_fee>=0), prize_pool numeric(12,2) not null default 0, per_kill numeric(10,2) not null default 0,
  starts_at timestamptz not null, max_slots int not null check(max_slots>0), joined int not null default 0, featured bool not null default false,
  status text not null default 'upcoming' check(status in('upcoming','live','completed','cancelled')), created_at timestamptz default now());
create table room_details(tournament_id uuid primary key references tournaments on delete cascade, room_id text, room_pass text, visible bool not null default false);
create table registrations(id uuid primary key default gen_random_uuid(), tournament_id uuid not null references tournaments on delete cascade,
  user_id uuid not null references profiles, team_name text, created_at timestamptz default now(), unique(tournament_id,user_id));
create table deposits(id uuid primary key default gen_random_uuid(), user_id uuid not null references profiles, amount numeric(12,2) not null check(amount>0),
  utr text not null, screenshot_path text not null, status text not null default 'pending' check(status in('pending','approved','rejected')),
  note text, reviewed_by uuid, created_at timestamptz default now(), reviewed_at timestamptz);
create unique index deposits_utr_uq on deposits(utr);
create table withdrawals(id uuid primary key default gen_random_uuid(), user_id uuid not null references profiles, amount numeric(12,2) not null check(amount>0),
  method text not null, payout_detail text not null, status text not null default 'pending' check(status in('pending','approved','processing','paid','rejected')),
  reference text, note text, created_at timestamptz default now(), updated_at timestamptz default now());
create unique index withdrawals_one_open on withdrawals(user_id) where status in('pending','approved','processing');
create table results(id uuid primary key default gen_random_uuid(), tournament_id uuid not null references tournaments on delete cascade, user_id uuid not null references profiles,
  ign text, kills int not null default 0, position int, pos_points int not null default 0, kill_earnings numeric(12,2) not null default 0, prize numeric(12,2) not null default 0,
  created_at timestamptz default now(), unique(tournament_id,user_id));
create table notifications(id bigserial primary key, user_id uuid not null references profiles on delete cascade, title text, body text, read bool not null default false, created_at timestamptz default now());
create table settings(key text primary key, value text);
insert into settings values('min_withdraw','50'),('max_withdraw','5000'),('qr_path','');

-- helpers ------------------------------------------------------------------
create function is_admin() returns bool language sql stable security definer set search_path=public as
$$ select exists(select 1 from profiles where id=auth.uid() and role='admin' and not banned) $$;
create function _me() returns uuid language plpgsql stable security definer set search_path=public as
$$ declare u uuid:=auth.uid(); begin
  if u is null then raise exception 'Please log in'; end if;
  if exists(select 1 from profiles where id=u and banned) then raise exception 'Account suspended'; end if; return u; end $$;
create function _notify(uid uuid,t text,b text) returns void language sql security definer set search_path=public as
$$ insert into notifications(user_id,title,body) values(uid,t,b) $$;
-- the ONLY way money moves: updates wallet and appends an immutable ledger row in one statement block
create function _post(uid uuid,amt numeric,k text,r text,n text) returns numeric language plpgsql security definer set search_path=public as
$$ declare nb numeric; begin
  update wallets set balance=balance+amt where user_id=uid returning balance into nb;
  if nb is null then raise exception 'Wallet not found'; end if;
  insert into ledger(user_id,kind,amount,balance_after,ref,note) values(uid,k,amt,nb,r,n); return nb; end $$;
revoke all on function _notify,_post from public,anon,authenticated;
create function _ro() returns trigger language plpgsql as $$ begin raise exception 'Ledger is append-only'; end $$;
create trigger ledger_ro before update or delete on ledger for each row execute function _ro();

create function handle_new_user() returns trigger language plpgsql security definer set search_path=public as
$$ declare pid text; begin
  loop pid:='A7X'||lpad(floor(random()*1000000)::int::text,6,'0'); exit when not exists(select 1 from profiles where player_id=pid); end loop;
  insert into profiles(id,player_id,email,ign,ff_uid) values(new.id,pid,new.email,left(new.raw_user_meta_data->>'ign',30),left(new.raw_user_meta_data->>'ff_uid',20));
  insert into wallets(user_id) values(new.id); return new; end $$;
create trigger on_auth_user after insert on auth.users for each row execute function handle_new_user();

-- user RPCs ----------------------------------------------------------------
create function my_stats() returns json language sql stable security definer set search_path=public as
$$ select json_build_object('balance',coalesce((select balance from wallets where user_id=auth.uid()),0),
  'played',(select count(*) from registrations where user_id=auth.uid()),
  'winnings',coalesce((select sum(amount) from ledger where user_id=auth.uid() and kind='winning'),0),
  'unread',(select count(*) from notifications where user_id=auth.uid() and not read)) $$;

create function submit_deposit(p_amount numeric,p_utr text,p_path text) returns uuid language plpgsql security definer set search_path=public as
$$ declare u uuid:=_me(); v text:=upper(trim(p_utr)); v_id uuid; begin
  if p_amount<10 or p_amount>50000 then raise exception 'Amount must be between 10 and 50000'; end if;
  if v !~ '^[A-Z0-9]{10,22}$' then raise exception 'Enter a valid UTR / transaction ID'; end if;
  if p_path is null or p_path not like u::text||'/%' then raise exception 'Upload your payment screenshot'; end if;
  if (select count(*) from deposits where user_id=u and status='pending')>=3 then raise exception 'You have too many pending deposits'; end if;
  insert into deposits(user_id,amount,utr,screenshot_path) values(u,p_amount,v,p_path) returning id into v_id; return v_id;
exception when unique_violation then raise exception 'This transaction ID was already submitted'; end $$;

create function join_tournament(p_tid uuid,p_team text default null) returns void language plpgsql security definer set search_path=public as
$$ declare u uuid:=_me(); t tournaments; bal numeric; begin
  select * into t from tournaments where id=p_tid for update;
  if not found or t.status<>'upcoming' then raise exception 'Registration is closed'; end if;
  if t.joined>=t.max_slots then raise exception 'Tournament is full'; end if;
  if exists(select 1 from registrations where tournament_id=p_tid and user_id=u) then raise exception 'You are already registered'; end if;
  if exists(select 1 from profiles where id=u and (coalesce(ign,'')='' or coalesce(ff_uid,'')='')) then raise exception 'Add your Free Fire UID and name in Profile first'; end if;
  select balance into bal from wallets where user_id=u for update;
  if bal<t.entry_fee then raise exception 'Insufficient wallet balance'; end if;
  if t.entry_fee>0 then perform _post(u,-t.entry_fee,'entry',p_tid::text,'Entry: '||t.name); end if;
  insert into registrations(tournament_id,user_id,team_name) values(p_tid,u,left(p_team,30));
  update tournaments set joined=joined+1 where id=p_tid;
  perform _notify(u,'Registration confirmed','You are in: '||t.name||'. Room details appear here before the match.'); end $$;

create function request_withdrawal(p_amount numeric,p_method text,p_detail text) returns uuid language plpgsql security definer set search_path=public as
$$ declare u uuid:=_me(); mn numeric; mx numeric; v_id uuid; begin
  select value::numeric into mn from settings where key='min_withdraw'; select value::numeric into mx from settings where key='max_withdraw';
  if p_amount<mn or p_amount>mx then raise exception 'Withdrawal must be between % and %',mn,mx; end if;
  if length(trim(coalesce(p_detail,'')))<5 then raise exception 'Enter a valid payout detail'; end if;
  perform 1 from wallets where user_id=u for update;
  if (select balance from wallets where user_id=u)<p_amount then raise exception 'Insufficient balance'; end if;
  perform _post(u,-p_amount,'withdrawal',null,'Withdrawal requested (held)');
  insert into withdrawals(user_id,amount,method,payout_detail) values(u,p_amount,left(p_method,20),left(trim(p_detail),80)) returning id into v_id; return v_id;
exception when unique_violation then raise exception 'You already have an open withdrawal request'; end $$;

-- admin RPCs ---------------------------------------------------------------
create function review_deposit(p_id uuid,p_ok bool,p_note text default null) returns void language plpgsql security definer set search_path=public as
$$ declare d deposits; begin
  if not is_admin() then raise exception 'Admins only'; end if;
  select * into d from deposits where id=p_id for update;
  if not found or d.status<>'pending' then raise exception 'Deposit was already reviewed'; end if;
  if p_ok then perform _post(d.user_id,d.amount,'deposit',d.id::text,'Deposit approved · UTR '||d.utr);
    perform _notify(d.user_id,'Payment approved',d.amount||' was added to your wallet.');
  else perform _notify(d.user_id,'Payment rejected','Deposit of '||d.amount||' (UTR '||d.utr||') was rejected. '||coalesce(p_note,'')); end if;
  update deposits set status=case when p_ok then 'approved' else 'rejected' end, note=p_note, reviewed_by=auth.uid(), reviewed_at=now() where id=p_id; end $$;

create function admin_set_withdrawal(p_id uuid,p_status text,p_ref text default null,p_note text default null) returns void language plpgsql security definer set search_path=public as
$$ declare w withdrawals; ok bool; begin
  if not is_admin() then raise exception 'Admins only'; end if;
  select * into w from withdrawals where id=p_id for update; if not found then raise exception 'Not found'; end if;
  ok:=(w.status='pending' and p_status in('approved','rejected')) or (w.status='approved' and p_status in('processing','rejected')) or (w.status='processing' and p_status in('paid','rejected'));
  if not ok then raise exception 'Cannot change % to %',w.status,p_status; end if;
  if p_status='paid' and length(trim(coalesce(p_ref,'')))<4 then raise exception 'Enter the payment reference before marking Paid'; end if;
  if p_status='rejected' then perform _post(w.user_id,w.amount,'refund',w.id::text,'Withdrawal rejected, refunded'); end if;
  update withdrawals set status=p_status, reference=coalesce(nullif(trim(p_ref),''),reference), note=p_note, updated_at=now() where id=p_id;
  perform _notify(w.user_id,'Withdrawal '||p_status,'Your withdrawal of '||w.amount||' is now '||p_status||coalesce(' · Ref '||nullif(trim(p_ref),''),'')||'.'); end $$;

create function admin_save_scores(p_tid uuid,p_rows jsonb) returns void language plpgsql security definer set search_path=public as
$$ declare t tournaments; begin
  if not is_admin() then raise exception 'Admins only'; end if;
  select * into t from tournaments where id=p_tid for update;
  if not found or t.status in('completed','cancelled') then raise exception 'Results are locked'; end if;
  insert into results(tournament_id,user_id,ign,kills,position,pos_points,kill_earnings,prize)
  select p_tid,(r->>'user_id')::uuid,(select ign from profiles where id=(r->>'user_id')::uuid),greatest(coalesce((r->>'kills')::int,0),0),nullif(r->>'position','')::int,
    coalesce((r->>'pos_points')::int,0),greatest(coalesce((r->>'kills')::int,0),0)*t.per_kill,greatest(coalesce((r->>'prize')::numeric,0),0)
  from jsonb_array_elements(p_rows) r where exists(select 1 from registrations g where g.tournament_id=p_tid and g.user_id=(r->>'user_id')::uuid)
  on conflict(tournament_id,user_id) do update set kills=excluded.kills,position=excluded.position,pos_points=excluded.pos_points,kill_earnings=excluded.kill_earnings,prize=excluded.prize;
end $$;

create function admin_finalize(p_tid uuid) returns void language plpgsql security definer set search_path=public as
$$ declare t tournaments; x results; begin
  if not is_admin() then raise exception 'Admins only'; end if;
  select * into t from tournaments where id=p_tid for update;
  if not found or t.status in('completed','cancelled') then raise exception 'Already finalized'; end if;
  for x in select * from results where tournament_id=p_tid loop
    if x.kill_earnings+x.prize>0 then perform _post(x.user_id,x.kill_earnings+x.prize,'winning',p_tid::text,'Winnings: '||t.name); end if;
    perform _notify(x.user_id,'Results are out',t.name||': '||x.kills||' kills'||coalesce(', rank #'||x.position,'')||'. Won '||(x.kill_earnings+x.prize)||'.');
  end loop;
  update tournaments set status='completed' where id=p_tid; end $$;

create function admin_notify(p_tid uuid,p_title text,p_body text) returns void language plpgsql security definer set search_path=public as
$$ begin if not is_admin() then raise exception 'Admins only'; end if;
  insert into notifications(user_id,title,body) select user_id,p_title,p_body from registrations where tournament_id=p_tid; end $$;
create function admin_ban(p_uid uuid,p_ban bool) returns void language sql security definer set search_path=public as
$$ update profiles set banned=p_ban where id=p_uid and is_admin() and role<>'admin' $$;
create function admin_report() returns json language sql stable security definer set search_path=public as
$$ select case when is_admin() then json_build_object(
  'users',(select count(*) from profiles),'deposits_in',coalesce((select sum(amount) from deposits where status='approved'),0),
  'pending_deposits',(select count(*) from deposits where status='pending'),'withdrawn',coalesce((select sum(amount) from withdrawals where status='paid'),0),
  'pending_withdrawals',(select count(*) from withdrawals where status in('pending','approved','processing')),
  'entry_fees',coalesce(-(select sum(amount) from ledger where kind='entry'),0),'winnings_paid',coalesce((select sum(amount) from ledger where kind='winning'),0),
  'wallet_liability',coalesce((select sum(balance) from wallets),0)) end $$;

-- RLS ----------------------------------------------------------------------
alter table profiles enable row level security; alter table wallets enable row level security; alter table ledger enable row level security;
alter table tournaments enable row level security; alter table room_details enable row level security; alter table registrations enable row level security;
alter table deposits enable row level security; alter table withdrawals enable row level security; alter table results enable row level security;
alter table notifications enable row level security; alter table settings enable row level security;
revoke insert,update,delete on all tables in schema public from anon,authenticated;
revoke execute on function admin_save_scores,admin_finalize,admin_notify,admin_ban,admin_report,review_deposit,admin_set_withdrawal from anon;
grant update(ign,ff_uid) on profiles to authenticated; grant update(read) on notifications to authenticated;
grant insert,update,delete on tournaments,room_details,settings to authenticated;

create policy p_own on profiles for select using(id=auth.uid() or is_admin());
create policy p_upd on profiles for update using(id=auth.uid()) with check(id=auth.uid());
create policy w_sel on wallets for select using(user_id=auth.uid() or is_admin());
create policy l_sel on ledger for select using(user_id=auth.uid() or is_admin());
create policy t_sel on tournaments for select using(true);
create policy t_adm on tournaments for all using(is_admin()) with check(is_admin());
create policy r_sel on room_details for select using(is_admin() or (visible and exists(select 1 from registrations g where g.tournament_id=room_details.tournament_id and g.user_id=auth.uid())));
create policy r_adm on room_details for all using(is_admin()) with check(is_admin());
create policy g_sel on registrations for select using(user_id=auth.uid() or is_admin());
create policy d_sel on deposits for select using(user_id=auth.uid() or is_admin());
create policy x_sel on withdrawals for select using(user_id=auth.uid() or is_admin());
create policy s_sel on results for select using(true);
create policy n_sel on notifications for select using(user_id=auth.uid());
create policy n_upd on notifications for update using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy c_sel on settings for select using(true);
create policy c_adm on settings for all using(is_admin()) with check(is_admin());

-- storage: public 'assets' (banners, QR), private 'proofs' (screenshots)
insert into storage.buckets(id,name,public) values('assets','assets',true),('proofs','proofs',false) on conflict do nothing;
create policy a_read on storage.objects for select using(bucket_id='assets');
create policy a_adm on storage.objects for all to authenticated using(bucket_id='assets' and is_admin()) with check(bucket_id='assets' and is_admin());
create policy f_up on storage.objects for insert to authenticated with check(bucket_id='proofs' and (storage.foldername(name))[1]=auth.uid()::text);
create policy f_read on storage.objects for select to authenticated using(bucket_id='proofs' and ((storage.foldername(name))[1]=auth.uid()::text or is_admin()));

-- After signing up in the app, make yourself admin (run once, with your email):
-- update profiles set role='admin' where email='you@example.com';
