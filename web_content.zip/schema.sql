-- =====================================================================
-- UDAAN - Supabase schema. Supabase > SQL Editor mein poora paste karke Run karein.
-- =====================================================================

create extension if not exists pgcrypto;

-- ---------- TABLES ----------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  role text check (role in ('buyer','seller')),
  onboarded boolean not null default false,
  is_admin boolean not null default false,
  is_super boolean not null default false,
  permissions text[] not null default '{}',
  is_blocked boolean not null default false,
  created_at timestamptz not null default now()
);

-- Phone / email / city / address: SIRF owner aur permission wale admin dekh sakte hain
create table if not exists public.private_contacts (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  email text,
  phone text,
  city text,
  address text,
  updated_at timestamptz not null default now()
);

create table if not exists public.services (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null,
  emoji text not null default '🛠️',
  color text not null default '#F2A014',
  sort int not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.listings (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.profiles(id) on delete cascade,
  service_id uuid not null references public.services(id) on delete cascade,
  title text not null,
  details text not null default '',
  price numeric(12,0) not null check (price >= 0),
  price_unit text not null default 'per kaam',
  city text not null default '',
  experience_years int not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.deals (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid references public.listings(id) on delete set null,
  service_id uuid references public.services(id) on delete set null,
  buyer_id uuid not null references public.profiles(id) on delete cascade,
  seller_id uuid not null references public.profiles(id) on delete cascade,
  listing_title text not null default '',
  listing_price numeric,
  status text not null default 'chatting'
    check (status in ('chatting','requested','approved','rejected','completed','cancelled')),
  agreed_price numeric,
  request_note text,
  admin_note text,
  requested_by uuid,
  decided_by uuid,
  decided_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index if not exists deals_one_open_per_listing
  on public.deals(listing_id, buyer_id) where status in ('chatting','requested','approved');

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  deal_id uuid not null references public.deals(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text not null,
  kind text not null default 'text' check (kind in ('text','system')),
  created_at timestamptz not null default now()
);
create index if not exists messages_deal_idx on public.messages(deal_id, created_at);

create table if not exists public.user_notes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  admin_id uuid references public.profiles(id) on delete set null,
  kind text not null default 'note' check (kind in ('note','warning','praise')),
  body text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.behavior_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  event text not null,
  detail text,
  deal_id uuid,
  created_at timestamptz not null default now()
);
create index if not exists behavior_logs_user_idx on public.behavior_logs(user_id, created_at desc);

-- ---------- HELPERS ----------
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select is_admin and not is_blocked from public.profiles where id = auth.uid()), false)
$$;

create or replace function public.has_perm(p text) returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select is_admin and not is_blocked and (is_super or p = any(permissions))
                   from public.profiles where id = auth.uid()), false)
$$;

-- Number / link / location detect karta hai. Reason ya NULL return karta hai.
create or replace function public.contact_violation(t text) returns text
language plpgsql immutable as $$
declare
  s text := lower(coalesce(t, ''));
  c text;
  n int;
begin
  s := translate(s, '٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹', '01234567890123456789');
  if s ~ '[0-9]{7,}' then return 'phone'; end if;
  c := regexp_replace(s, '(?<=[0-9])[^[:alnum:]]{1,3}(?=[0-9])', '', 'g');
  if c ~ '(^|[^0-9])(0|\+?92)[0-9]{9,}' then return 'phone'; end if;
  select count(*) into n from regexp_matches(s,
    '\m(zero|sifar|sifr|aik|ek|do|teen|char|chaar|panch|paanch|chay|chhe|saat|aath|nau|one|two|three|four|five|six|seven|eight|nine)\M', 'g');
  if n >= 6 then return 'phone'; end if;
  if s ~ '\m(number|nambar|namber|nmbr|whatsapp|watsapp|whatsap|wtsp|telegram|instagram|facebook|snapchat|tiktok|gmail|email|imo|location|lokation|address|gps)\M' then return 'keyword'; end if;
  if s ~ '(نمبر|واٹس|وٹس|لوکیشن|ایڈریس)' then return 'keyword'; end if;
  if s ~ '(https?:|www\.|[a-z0-9._-]+@[a-z0-9.-]+|\.(com|pk|net|org)\M)' then return 'link'; end if;
  return null;
end $$;

-- ---------- TRIGGERS ----------
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare r text := new.raw_user_meta_data->>'role';
begin
  if r is not null and r not in ('buyer','seller') then r := null; end if;
  insert into public.profiles(id, full_name, role)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', ''), r);
  insert into public.private_contacts(user_id, email) values (new.id, new.email);
  insert into public.behavior_logs(user_id, event, detail)
  values (new.id, 'signup', coalesce(new.raw_app_meta_data->>'provider', 'email'));
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- User apni role/admin/block fields khud change na kar sake
create or replace function public.guard_profile() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or coalesce(current_setting('udaan.admin_op', true), '') = '1' then
    return new;
  end if;
  new.id := old.id;
  new.is_admin := old.is_admin;
  new.is_super := old.is_super;
  new.permissions := old.permissions;
  new.is_blocked := old.is_blocked;
  new.created_at := old.created_at;
  if old.role is not null then new.role := old.role; end if;
  if new.onboarded and not old.onboarded then
    if new.role is null or new.full_name = '' or not exists (
      select 1 from public.private_contacts
      where user_id = new.id and coalesce(phone,'') <> '' and coalesce(city,'') <> '' and coalesce(address,'') <> ''
    ) then
      raise exception 'Pehle naam, role, phone, shehar aur address mukammal karein';
    end if;
  end if;
  return new;
end $$;
drop trigger if exists guard_profile_trg on public.profiles;
create trigger guard_profile_trg before update on public.profiles
  for each row execute function public.guard_profile();

create or replace function public.check_listing_text() returns trigger
language plpgsql as $$
begin
  if public.contact_violation(new.title || ' ' || new.details || ' ' || new.city) is not null then
    raise exception 'Title ya detail mein number, link ya location likhna allowed nahi.';
  end if;
  return new;
end $$;
drop trigger if exists check_listing_text_trg on public.listings;
create trigger check_listing_text_trg before insert or update on public.listings
  for each row execute function public.check_listing_text();

create or replace function public.touch_deal() returns trigger
language plpgsql as $$ begin new.updated_at := now(); return new; end $$;
drop trigger if exists touch_deal_trg on public.deals;
create trigger touch_deal_trg before update on public.deals
  for each row execute function public.touch_deal();

-- ---------- USER RPCs ----------
create or replace function public.log_event(p_event text, p_detail text default '') returns void
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or p_event not in ('login') then return; end if;
  insert into public.behavior_logs(user_id, event, detail) values (auth.uid(), p_event, left(coalesce(p_detail,''), 200));
end $$;

create or replace function public.start_deal(p_listing uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare me public.profiles; l public.listings; d uuid;
begin
  select * into me from public.profiles where id = auth.uid();
  if not found or me.is_blocked or not me.onboarded then raise exception 'Pehle profile mukammal karein'; end if;
  if coalesce(me.role,'') <> 'buyer' then raise exception 'Sirf buyer baat shuru kar sakta hai'; end if;
  select * into l from public.listings where id = p_listing and active;
  if not found then raise exception 'Ye service ab available nahi'; end if;
  select id into d from public.deals
    where listing_id = p_listing and buyer_id = auth.uid() and status in ('chatting','requested','approved') limit 1;
  if d is not null then return d; end if;
  insert into public.deals(listing_id, service_id, buyer_id, seller_id, listing_title, listing_price)
    values (l.id, l.service_id, auth.uid(), l.seller_id, l.title, l.price) returning id into d;
  insert into public.messages(deal_id, sender_id, body, kind)
    values (d, auth.uid(), 'Baat-cheet shuru hui. Price yahan tay karein. Number ya location share na karein.', 'system');
  insert into public.behavior_logs(user_id, event, detail, deal_id) values (auth.uid(), 'deal_started', l.title, d);
  return d;
end $$;

create or replace function public.send_message(p_deal uuid, p_body text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare d public.deals; body text := btrim(coalesce(p_body,''));
begin
  if auth.uid() is null then return jsonb_build_object('ok', false, 'reason', 'login'); end if;
  if length(body) = 0 or length(body) > 1000 then return jsonb_build_object('ok', false, 'reason', 'empty'); end if;
  select * into d from public.deals where id = p_deal;
  if not found or auth.uid() not in (d.buyer_id, d.seller_id) then return jsonb_build_object('ok', false, 'reason', 'denied'); end if;
  if exists (select 1 from public.profiles where id = auth.uid() and is_blocked) then
    return jsonb_build_object('ok', false, 'reason', 'blocked');
  end if;
  if d.status in ('rejected','cancelled','completed') then return jsonb_build_object('ok', false, 'reason', 'closed'); end if;
  if public.contact_violation(body) is not null then
    insert into public.behavior_logs(user_id, event, detail, deal_id)
      values (auth.uid(), 'contact_attempt', left(body, 300), p_deal);
    return jsonb_build_object('ok', false, 'reason', 'contact');
  end if;
  insert into public.messages(deal_id, sender_id, body) values (p_deal, auth.uid(), body);
  update public.deals set updated_at = now() where id = p_deal;
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.request_approval(p_deal uuid, p_price numeric, p_note text default '') returns void
language plpgsql security definer set search_path = public as $$
declare d public.deals;
begin
  select * into d from public.deals where id = p_deal;
  if not found or auth.uid() not in (d.buyer_id, d.seller_id) then raise exception 'Deal nahi mili'; end if;
  if d.status <> 'chatting' then raise exception 'Request pehle ho chuki hai ya deal band hai'; end if;
  if p_price is null or p_price <= 0 then raise exception 'Sahi price likhein'; end if;
  if public.contact_violation(coalesce(p_note,'')) is not null then
    raise exception 'Note mein number, link ya location allowed nahi';
  end if;
  update public.deals set status = 'requested', agreed_price = p_price,
    request_note = left(coalesce(p_note,''), 300), requested_by = auth.uid() where id = p_deal;
  insert into public.messages(deal_id, sender_id, body, kind)
    values (p_deal, auth.uid(), 'Admin approval ki request bheji gayi. Tay shuda price: Rs ' || p_price::bigint, 'system');
  insert into public.behavior_logs(user_id, event, detail, deal_id)
    values (auth.uid(), 'approval_requested', 'Rs ' || p_price::bigint, p_deal);
end $$;

create or replace function public.cancel_deal(p_deal uuid) returns void
language plpgsql security definer set search_path = public as $$
declare d public.deals;
begin
  select * into d from public.deals where id = p_deal;
  if not found or auth.uid() not in (d.buyer_id, d.seller_id) then raise exception 'Deal nahi mili'; end if;
  if d.status not in ('chatting','requested') then raise exception 'Ye deal ab cancel nahi ho sakti'; end if;
  update public.deals set status = 'cancelled' where id = p_deal;
  insert into public.messages(deal_id, sender_id, body, kind)
    values (p_deal, auth.uid(), 'Deal cancel kar di gayi.', 'system');
end $$;

-- ---------- ADMIN RPCs ----------
create or replace function public.admin_decide_deal(p_deal uuid, p_status text, p_note text default '') returns void
language plpgsql security definer set search_path = public as $$
declare d public.deals; msg text;
begin
  if not public.has_perm('approve_deals') then raise exception 'Aap ko is ki permission nahi'; end if;
  select * into d from public.deals where id = p_deal;
  if not found then raise exception 'Deal nahi mili'; end if;
  if p_status = 'approved' and d.status = 'requested' then
    msg := 'Admin ne approve kar diya. Admin ab aap dono se rabta karega.';
  elsif p_status = 'rejected' and d.status = 'requested' then
    msg := 'Admin ne request reject kar di.' || case when coalesce(p_note,'') <> '' then ' Wajah: ' || p_note else '' end;
  elsif p_status = 'completed' and d.status = 'approved' then
    msg := 'Kaam mukammal mark kar diya gaya.';
  else
    raise exception 'Ye status change allowed nahi';
  end if;
  update public.deals set status = p_status, admin_note = left(coalesce(p_note,''), 300),
    decided_by = auth.uid(), decided_at = now() where id = p_deal;
  insert into public.messages(deal_id, sender_id, body, kind) values (p_deal, auth.uid(), msg, 'system');
end $$;

create or replace function public.admin_user_overview()
returns table(id uuid, full_name text, role text, is_admin boolean, is_super boolean, is_blocked boolean,
              onboarded boolean, created_at timestamptz, email text, phone text, city text,
              violations bigint, deals bigint)
language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('manage_users') then raise exception 'Aap ko is ki permission nahi'; end if;
  return query
  select p.id, p.full_name, p.role, p.is_admin, p.is_super, p.is_blocked, p.onboarded, p.created_at,
         case when public.has_perm('view_contacts') then c.email end,
         case when public.has_perm('view_contacts') then c.phone end,
         c.city,
         (select count(*) from public.behavior_logs l where l.user_id = p.id and l.event = 'contact_attempt'),
         (select count(*) from public.deals d where d.buyer_id = p.id or d.seller_id = p.id)
  from public.profiles p left join public.private_contacts c on c.user_id = p.id
  order by p.created_at desc;
end $$;

create or replace function public.admin_set_blocked(p_user uuid, p_blocked boolean) returns void
language plpgsql security definer set search_path = public as $$
declare t public.profiles;
begin
  if not public.has_perm('manage_users') then raise exception 'Aap ko is ki permission nahi'; end if;
  select * into t from public.profiles where id = p_user;
  if not found then raise exception 'User nahi mila'; end if;
  if t.is_super or t.id = auth.uid() then raise exception 'Is account ko block nahi kar sakte'; end if;
  if t.is_admin and not public.has_perm('manage_admins') then raise exception 'Admin ko block karne ki permission nahi'; end if;
  perform set_config('udaan.admin_op', '1', true);
  update public.profiles set is_blocked = p_blocked where id = p_user;
  perform set_config('udaan.admin_op', '0', true);
  insert into public.behavior_logs(user_id, event, detail)
    values (p_user, case when p_blocked then 'blocked' else 'unblocked' end, 'admin action');
end $$;

create or replace function public.admin_delete_user(p_user uuid) returns void
language plpgsql security definer set search_path = public as $$
declare t public.profiles;
begin
  if not public.has_perm('manage_users') then raise exception 'Aap ko is ki permission nahi'; end if;
  select * into t from public.profiles where id = p_user;
  if not found then raise exception 'User nahi mila'; end if;
  if t.is_super or t.id = auth.uid() then raise exception 'Is account ko delete nahi kar sakte'; end if;
  if t.is_admin and not public.has_perm('manage_admins') then raise exception 'Admin ko delete karne ki permission nahi'; end if;
  delete from auth.users where id = p_user;
end $$;

create or replace function public.admin_set_admin(p_user uuid, p_is_admin boolean, p_perms text[]) returns void
language plpgsql security definer set search_path = public as $$
declare
  t public.profiles;
  me_super boolean;
  allowed text[] := array['approve_deals','view_contacts','view_chats','manage_users','manage_services','manage_admins'];
  clean text[];
begin
  if not public.has_perm('manage_admins') then raise exception 'Aap ko is ki permission nahi'; end if;
  select coalesce(is_super, false) into me_super from public.profiles where id = auth.uid();
  select * into t from public.profiles where id = p_user;
  if not found then raise exception 'User nahi mila'; end if;
  if t.is_super then raise exception 'Main admin ko change nahi kar sakte'; end if;
  if t.id = auth.uid() then raise exception 'Apni permissions khud change nahi kar sakte'; end if;
  select coalesce(array_agg(distinct x), '{}') into clean from unnest(coalesce(p_perms, '{}')) x where x = any(allowed);
  if 'manage_admins' = any(clean) and not me_super then raise exception 'manage_admins sirf main admin de sakta hai'; end if;
  if t.is_admin and 'manage_admins' = any(t.permissions) and not me_super then
    raise exception 'Is admin ko sirf main admin change kar sakta hai';
  end if;
  perform set_config('udaan.admin_op', '1', true);
  update public.profiles set is_admin = p_is_admin,
    permissions = case when p_is_admin then clean else '{}' end where id = p_user;
  perform set_config('udaan.admin_op', '0', true);
  insert into public.behavior_logs(user_id, event, detail)
    values (p_user, 'admin_changed', case when p_is_admin then 'admin: ' || array_to_string(clean, ',') else 'admin hataya gaya' end);
end $$;

-- ---------- ROW LEVEL SECURITY ----------
alter table public.profiles enable row level security;
alter table public.private_contacts enable row level security;
alter table public.services enable row level security;
alter table public.listings enable row level security;
alter table public.deals enable row level security;
alter table public.messages enable row level security;
alter table public.user_notes enable row level security;
alter table public.behavior_logs enable row level security;

drop policy if exists profiles_select on public.profiles;
create policy profiles_select on public.profiles for select to authenticated using (true);
drop policy if exists profiles_update on public.profiles;
create policy profiles_update on public.profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());

drop policy if exists contacts_select on public.private_contacts;
create policy contacts_select on public.private_contacts for select to authenticated
  using (user_id = auth.uid() or public.has_perm('view_contacts'));
drop policy if exists contacts_insert on public.private_contacts;
create policy contacts_insert on public.private_contacts for insert to authenticated with check (user_id = auth.uid());
drop policy if exists contacts_update on public.private_contacts;
create policy contacts_update on public.private_contacts for update to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

drop policy if exists services_select on public.services;
create policy services_select on public.services for select to authenticated
  using (active or public.has_perm('manage_services'));
drop policy if exists services_write on public.services;
create policy services_write on public.services for all to authenticated
  using (public.has_perm('manage_services')) with check (public.has_perm('manage_services'));

drop policy if exists listings_select on public.listings;
create policy listings_select on public.listings for select to authenticated
  using ((active and not exists (select 1 from public.profiles p where p.id = seller_id and p.is_blocked))
         or seller_id = auth.uid() or public.is_admin());
drop policy if exists listings_insert on public.listings;
create policy listings_insert on public.listings for insert to authenticated
  with check (seller_id = auth.uid() and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'seller' and not p.is_blocked and p.onboarded));
drop policy if exists listings_update on public.listings;
create policy listings_update on public.listings for update to authenticated
  using (seller_id = auth.uid() or public.has_perm('manage_users'))
  with check (seller_id = auth.uid() or public.has_perm('manage_users'));
drop policy if exists listings_delete on public.listings;
create policy listings_delete on public.listings for delete to authenticated
  using (seller_id = auth.uid() or public.has_perm('manage_users'));

drop policy if exists deals_select on public.deals;
create policy deals_select on public.deals for select to authenticated
  using (buyer_id = auth.uid() or seller_id = auth.uid() or public.has_perm('approve_deals') or public.has_perm('view_chats'));

drop policy if exists messages_select on public.messages;
create policy messages_select on public.messages for select to authenticated
  using (exists (select 1 from public.deals d where d.id = deal_id and (d.buyer_id = auth.uid() or d.seller_id = auth.uid()))
         or public.has_perm('view_chats'));

drop policy if exists notes_select on public.user_notes;
create policy notes_select on public.user_notes for select to authenticated using (public.has_perm('manage_users'));
drop policy if exists notes_insert on public.user_notes;
create policy notes_insert on public.user_notes for insert to authenticated
  with check (public.has_perm('manage_users') and admin_id = auth.uid());
drop policy if exists notes_delete on public.user_notes;
create policy notes_delete on public.user_notes for delete to authenticated using (public.has_perm('manage_users'));

drop policy if exists logs_select on public.behavior_logs;
create policy logs_select on public.behavior_logs for select to authenticated using (public.has_perm('manage_users'));

-- ---------- REALTIME (chat live update) ----------
do $$ begin
  begin alter publication supabase_realtime add table public.messages; exception when others then null; end;
  begin alter publication supabase_realtime add table public.deals; exception when others then null; end;
end $$;

-- ---------- SERVICES SEED ----------
insert into public.services(slug, name, emoji, color, sort) values
 ('mazdoor','Mazdoor','👷','#F2A014',1),
 ('plumber','Plumber','🚰','#1E88E5',2),
 ('ac-repair','AC Repair','❄️','#00ACC1',3),
 ('electrician','Electrician','💡','#FDD835',4),
 ('carpenter','Carpenter','🪚','#8D6E63',5),
 ('painter','Painter','🎨','#E4572E',6),
 ('mistri','Mistri / Mason','🧱','#A1887F',7),
 ('cleaning','Safai / Cleaning','🧹','#43A047',8),
 ('driver','Driver','🚗','#5C6BC0',9),
 ('mechanic','Car / Bike Mechanic','🔧','#546E7A',10),
 ('gardener','Mali / Gardener','🌿','#2E7D32',11),
 ('welder','Welder','🔥','#EF6C00',12),
 ('tutor','Home Tutor','📚','#7E57C2',13),
 ('cook','Cook / Chef','🍳','#D81B60',14),
 ('mobile-repair','Mobile / Laptop Repair','📱','#00897B',15),
 ('pest-control','Pest Control','🐜','#6D4C41',16),
 ('tailor','Tailor','🧵','#AD1457',17),
 ('generator','Generator / UPS','🔋','#F9A825',18)
on conflict (slug) do nothing;

-- =====================================================================
-- MAIN ADMIN BANANE KE LIYE (apni email likh kar, app mein signup karne ke BAAD ek baar run karein):
--
-- update public.profiles set is_admin = true, is_super = true
--   where id = (select id from auth.users where email = 'YAHAN-APNI-EMAIL@gmail.com');
-- =====================================================================

-- =====================================================================
-- LIVE TRACKING (map) - ye hissa Udaan project mein pehle se lag chuka hai
-- =====================================================================
create table if not exists public.live_locations (
  deal_id uuid not null references public.deals(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  lat double precision not null, lng double precision not null,
  accuracy real, heading real, speed real,
  updated_at timestamptz not null default now(),
  primary key (deal_id, user_id)
);
alter table public.live_locations enable row level security;
create policy live_select on public.live_locations for select to authenticated using (
  user_id = auth.uid() or public.has_perm('view_contacts')
  or exists (select 1 from public.deals d where d.id = live_locations.deal_id and d.buyer_id = auth.uid()
             and d.seller_id = live_locations.user_id and d.status = 'approved'));
-- functions update_location(), stop_location() aur trigger clear_locations_trg: migration "udaan_part3_live_tracking" mein hain

-- =====================================================================
-- SELLER LOCATION + NEARBY MAP - ye hissa Udaan project mein pehle se lag chuka hai
-- (migration "udaan_part4_listing_location_nearby": listings.lat/lng, normalize_listing_location trigger, nearby_listings())
-- =====================================================================

-- BOOKING (seedhi booking listed price par) - migration "udaan_part5_book_listing": book_listing(p_listing, p_note)
