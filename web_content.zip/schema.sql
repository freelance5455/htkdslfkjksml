-- Ask Everyone: run this once in Supabase -> SQL Editor
create table profiles(id uuid primary key references auth.users on delete cascade, name text, bio text default '', avatar text default '😎' check(char_length(avatar)<200000), phone text default '' check(char_length(phone)<30), role text not null default 'user' check(role in('user','admin')), banned boolean not null default false, created_at timestamptz default now());
create table polls(id bigint generated always as identity primary key, user_id uuid not null references profiles on delete cascade, question text not null check(char_length(question) between 3 and 300), options jsonb not null check(jsonb_typeof(options)='array' and jsonb_array_length(options) between 2 and 6), is_popular boolean not null default false, created_at timestamptz default now());
create table votes(poll_id bigint references polls on delete cascade, user_id uuid references profiles on delete cascade, option_idx int not null, created_at timestamptz default now(), primary key(poll_id,user_id));
create table reports(id bigint generated always as identity primary key, poll_id bigint references polls on delete cascade, user_id uuid references profiles on delete cascade, reason text default '', resolved boolean not null default false, created_at timestamptz default now());
create table announcements(id bigint generated always as identity primary key, text text not null check(char_length(text)<500), created_at timestamptz default now());
create index on polls(created_at desc);

create function is_admin() returns boolean language sql security definer stable set search_path=public as $$ select coalesce((select role='admin' from profiles where id=auth.uid()),false) $$;
create function is_active() returns boolean language sql security definer stable set search_path=public as $$ select coalesce((select not banned from profiles where id=auth.uid()),false) $$;

create function handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$ begin insert into profiles(id,name) values(new.id,left(coalesce(nullif(new.raw_user_meta_data->>'name',''),split_part(new.email,'@',1)),40)); return new; end $$;
create trigger on_signup after insert on auth.users for each row execute function handle_new_user();

create function check_vote() returns trigger language plpgsql as $$ declare n int; begin select jsonb_array_length(options) into n from polls where id=new.poll_id; if new.option_idx<0 or new.option_idx>=n then raise exception 'bad option'; end if; return new; end $$;
create trigger t_vote before insert on votes for each row execute function check_vote();

create view poll_counts as select poll_id,option_idx,count(*)::int as n from votes group by 1,2;

alter table profiles enable row level security; alter table polls enable row level security; alter table votes enable row level security; alter table reports enable row level security; alter table announcements enable row level security;
create policy p_sel on profiles for select using(true);
create policy p_upd on profiles for update to authenticated using(id=auth.uid()) with check(id=auth.uid());
revoke update on profiles from anon,authenticated; grant update(name,bio,avatar,phone) on profiles to authenticated; -- users can never change role/banned
create policy po_sel on polls for select using(true);
create policy po_ins on polls for insert to authenticated with check(user_id=auth.uid() and is_active());
create policy po_del on polls for delete to authenticated using(user_id=auth.uid() or is_admin());
create policy po_upd on polls for update to authenticated using(is_admin());
create policy v_sel on votes for select to authenticated using(user_id=auth.uid() or is_admin());
create policy v_ins on votes for insert to authenticated with check(user_id=auth.uid() and is_active());
create policy r_ins on reports for insert to authenticated with check(user_id=auth.uid());
create policy r_adm on reports for all to authenticated using(is_admin()) with check(is_admin());
create policy a_sel on announcements for select using(true);
create policy a_adm on announcements for all to authenticated using(is_admin()) with check(is_admin());
grant select on poll_counts to anon,authenticated;

create function admin_stats() returns json language plpgsql security definer set search_path=public as $$ begin if not is_admin() then raise exception 'forbidden'; end if; return json_build_object('users',(select count(*) from profiles),'polls',(select count(*) from polls),'votes',(select count(*) from votes),'reports',(select count(*) from reports where not resolved),'banned',(select count(*) from profiles where banned)); end $$;
create function admin_users() returns table(id uuid,email text,name text,role text,banned boolean,created_at timestamptz,polls bigint,votes bigint) language plpgsql security definer set search_path=public as $$ #variable_conflict use_column
begin if not is_admin() then raise exception 'forbidden'; end if;
return query select p.id,u.email::text,p.name,p.role,p.banned,p.created_at,(select count(*) from polls x where x.user_id=p.id),(select count(*) from votes v where v.user_id=p.id) from profiles p join auth.users u on u.id=p.id order by p.created_at desc; end $$;
create function admin_set_user(uid uuid,new_role text,is_banned boolean) returns void language plpgsql security definer set search_path=public as $$ begin if not is_admin() then raise exception 'forbidden'; end if; update profiles set role=new_role,banned=is_banned where id=uid; end $$;
create function delete_my_account() returns void language sql security definer set search_path=public as $$ delete from auth.users where id=auth.uid() $$;
revoke execute on function admin_stats(),admin_users(),admin_set_user(uuid,text,boolean) from public,anon; grant execute on function admin_stats(),admin_users(),admin_set_user(uuid,text,boolean),delete_my_account() to authenticated;

-- After you sign up in the app once, make yourself admin (put YOUR email):
-- update profiles set role='admin' where id=(select id from auth.users where email='you@example.com');
