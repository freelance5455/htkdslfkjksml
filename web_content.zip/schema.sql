-- این SQL را در Supabase > SQL Editor اجرا کنید.
create extension if not exists pgcrypto;

create table if not exists public.cases (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 title text not null,
 case_type text,
 role text,
 stage text,
 case_number text,
 archive_number text,
 court text,
 opponent text,
 facts text,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);

create table if not exists public.chat_messages (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 case_id uuid not null references public.cases(id) on delete cascade,
 role text not null check (role in ('user','assistant')),
 content text not null,
 created_at timestamptz not null default now()
);

alter table public.cases enable row level security;
alter table public.chat_messages enable row level security;

create policy "Users manage own cases" on public.cases
 for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy "Users manage own chat messages" on public.chat_messages
 for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create index if not exists cases_user_created_idx on public.cases(user_id,created_at desc);
create index if not exists chat_case_created_idx on public.chat_messages(case_id,created_at);
