-- KILILA V5 — Supabase/PostgreSQL schema
-- Run this in Supabase SQL Editor after creating the project.
create extension if not exists pgcrypto;
create table if not exists public.users (id uuid primary key default gen_random_uuid(), username text unique not null, display_name text not null, role text not null check(role in ('ADMIN','EMPLOYEE')), active boolean default true, created_at timestamptz default now());
create table if not exists public.devices (id text primary key, name text not null, user_id uuid references public.users(id), active boolean default true, last_seen timestamptz);
create table if not exists public.beers (id uuid primary key default gen_random_uuid(), name text unique not null, active boolean default true, price_pint numeric(12,2) default 0, price_liter numeric(12,2) default 0, price_new_bottle numeric(12,2) default 0, price_own_bottle numeric(12,2) default 0, cost_per_liter numeric(12,2) default 0, min_liters numeric(12,2) default 0, created_at timestamptz default now());
create table if not exists public.products (id uuid primary key default gen_random_uuid(), name text not null, category text not null, price numeric(12,2) default 0, cost numeric(12,2) default 0, active boolean default true, created_at timestamptz default now());
create table if not exists public.ingredients (id uuid primary key default gen_random_uuid(), name text unique not null, category text, unit text not null, stock numeric(14,3) default 0, min_stock numeric(14,3) default 0, ideal_stock numeric(14,3) default 0, unit_cost numeric(12,2) default 0, supplier text, active boolean default true);
create table if not exists public.recipes (id uuid primary key default gen_random_uuid(), beer_id uuid references public.beers(id), version int not null default 1, standard_yield_liters numeric(12,2) not null, active boolean default true, created_at timestamptz default now(), unique(beer_id,version));
create table if not exists public.recipe_items (id uuid primary key default gen_random_uuid(), recipe_id uuid references public.recipes(id) on delete cascade, ingredient_id uuid references public.ingredients(id), quantity numeric(14,3) not null, unit text not null);
create table if not exists public.production_batches (id uuid primary key default gen_random_uuid(), beer_id uuid references public.beers(id), recipe_id uuid references public.recipes(id), production_date date not null, planned_liters numeric(12,2), actual_liters numeric(12,2), total_cost numeric(14,2), cost_per_liter numeric(14,2), status text default 'PLANIFICADO', created_by uuid references public.users(id), device_id text references public.devices(id), created_at timestamptz default now());
create table if not exists public.kegs (id text primary key, batch_id uuid references public.production_batches(id), beer_id uuid references public.beers(id), capacity_liters numeric(12,2) not null, initial_liters numeric(12,2) not null, current_liters numeric(12,2) not null, state text not null, tap_number int, connected_at timestamptz, created_at timestamptz default now());
create table if not exists public.orders (id text primary key, order_date date not null, order_time time not null, total numeric(14,2) not null, liters numeric(12,2) default 0, status text default 'CONFIRMADA', user_id uuid references public.users(id), device_id text references public.devices(id), created_at timestamptz default now());
create table if not exists public.order_items (id uuid primary key default gen_random_uuid(), order_id text references public.orders(id) on delete cascade, product_id uuid references public.products(id), beer_id uuid references public.beers(id), variant text, quantity numeric(12,3) not null, liters numeric(12,3) default 0, unit_price numeric(12,2) not null, unit_cost numeric(12,2) default 0, keg_id text references public.kegs(id));
create table if not exists public.order_payments (id uuid primary key default gen_random_uuid(), order_id text references public.orders(id) on delete cascade, method text not null, amount numeric(14,2) not null);
create table if not exists public.stock_movements (id uuid primary key default gen_random_uuid(), movement_date date not null, movement_time time not null, item_type text not null, item_id text, product_name text, movement_type text not null, quantity numeric(14,3) not null, unit text, reference_id text, user_id uuid references public.users(id), device_id text references public.devices(id), created_at timestamptz default now());
create table if not exists public.cash_movements (id uuid primary key default gen_random_uuid(), movement_date date not null, movement_time time not null, type text not null, concept text, amount numeric(14,2) not null, payment_method text, reference_id text, user_id uuid references public.users(id), device_id text references public.devices(id), status text default 'ACTIVO', created_at timestamptz default now());
create table if not exists public.purchases (id text primary key, purchase_date date not null, supplier text, ingredient_id uuid references public.ingredients(id), quantity numeric(14,3), unit_cost numeric(12,2), total numeric(14,2), payment_method text, status text default 'CONFIRMADA', user_id uuid references public.users(id), device_id text references public.devices(id), created_at timestamptz default now());
create table if not exists public.expenses (id text primary key, expense_date date not null, category text, description text, amount numeric(14,2), payment_method text, user_id uuid references public.users(id), device_id text references public.devices(id), created_at timestamptz default now());
create table if not exists public.audit_log (id uuid primary key default gen_random_uuid(), action text not null, detail text, user_id uuid references public.users(id), device_id text references public.devices(id), created_at timestamptz default now());
create table if not exists public.sync_events (id text primary key, device_id text not null, entity_type text not null, payload jsonb not null, created_at timestamptz default now());

-- RLS: default deny, then allow authenticated users. Production policies should be tightened by role/device.
alter table public.users enable row level security;
alter table public.devices enable row level security;
alter table public.beers enable row level security;
alter table public.products enable row level security;
alter table public.ingredients enable row level security;
alter table public.recipes enable row level security;
alter table public.recipe_items enable row level security;
alter table public.production_batches enable row level security;
alter table public.kegs enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.order_payments enable row level security;
alter table public.stock_movements enable row level security;
alter table public.cash_movements enable row level security;
alter table public.purchases enable row level security;
alter table public.expenses enable row level security;
alter table public.audit_log enable row level security;
alter table public.sync_events enable row level security;

-- NOTE: create role-aware policies after enabling Supabase Auth. Do not use service_role in the mobile app.
