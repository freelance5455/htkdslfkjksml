-- MOHALLA - Relational Database Schema (PostgreSQL)
-- Trusted Local Services Marketplace for Pakistan

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "earthdistance" CASCADE;

-- ENUMS
CREATE TYPE user_role AS ENUM ('customer', 'provider', 'admin');
CREATE TYPE verification_status AS ENUM ('pending', 'verified', 'rejected');
CREATE TYPE booking_status AS ENUM (
  'PENDING',
  'ACCEPTED',
  'REJECTED',
  'ARRIVING',
  'IN_PROGRESS',
  'COMPLETED',
  'CANCELLED',
  'DISPUTED'
);
CREATE TYPE payment_method AS ENUM ('cash', 'easypaisa', 'jazzcash', 'bank_transfer');
CREATE TYPE payment_status AS ENUM ('pending', 'paid', 'refunded');
CREATE TYPE report_category AS ENUM ('Fraud', 'Bad behavior', 'Unsafe', 'Fake profile', 'Payment issue', 'Harassment', 'Other');
CREATE TYPE report_status AS ENUM ('OPEN', 'INVESTIGATING', 'RESOLVED');

-- 1. USERS TABLE
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(120) NOT NULL,
  phone VARCHAR(20) UNIQUE NOT NULL, -- e.g. 0300-1234567
  email VARCHAR(150) UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role user_role NOT NULL DEFAULT 'customer',
  avatar_url TEXT,
  city VARCHAR(50) NOT NULL DEFAULT 'Karachi',
  area VARCHAR(80) NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2. CATEGORIES TABLE
CREATE TABLE categories (
  id VARCHAR(50) PRIMARY KEY, -- e.g. 'electrician', 'plumber'
  name VARCHAR(100) NOT NULL,
  name_urdu VARCHAR(120) NOT NULL,
  icon VARCHAR(50) NOT NULL,
  description TEXT,
  typical_visit_charge NUMERIC(10, 2) NOT NULL DEFAULT 500.00,
  is_emergency_eligible BOOLEAN NOT NULL DEFAULT false,
  is_popular BOOLEAN NOT NULL DEFAULT false,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. PROVIDER PROFILES TABLE
CREATE TABLE provider_profiles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  business_name VARCHAR(150) NOT NULL,
  category_id VARCHAR(50) NOT NULL REFERENCES categories(id),
  sub_services TEXT[] DEFAULT '{}',
  bio TEXT,
  visit_charge NUMERIC(10, 2) NOT NULL DEFAULT 500.00,
  rating NUMERIC(3, 2) NOT NULL DEFAULT 5.00,
  review_count INT NOT NULL DEFAULT 0,
  completed_jobs INT NOT NULL DEFAULT 0,
  trust_score INT NOT NULL DEFAULT 85,
  verification_status verification_status NOT NULL DEFAULT 'pending',
  verification_badge VARCHAR(100) DEFAULT 'Pending Review',
  is_available_now BOOLEAN NOT NULL DEFAULT true,
  city VARCHAR(50) NOT NULL DEFAULT 'Karachi',
  service_areas TEXT[] DEFAULT '{}',
  service_radius_km NUMERIC(4, 1) NOT NULL DEFAULT 7.0,
  latitude NUMERIC(9, 6) NOT NULL,
  longitude NUMERIC(9, 6) NOT NULL,
  area_name VARCHAR(100) NOT NULL,
  cnic_masked VARCHAR(20) NOT NULL, -- Never store raw plain text for unprivileged display
  cnic_document_url TEXT,
  business_proof_url TEXT,
  emergency_service BOOLEAN NOT NULL DEFAULT false,
  response_time_minutes INT NOT NULL DEFAULT 15,
  on_time_percentage NUMERIC(5, 2) NOT NULL DEFAULT 98.00,
  cancellation_rate_percentage NUMERIC(5, 2) NOT NULL DEFAULT 1.5,
  weekly_schedule JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT fk_provider_user UNIQUE(user_id)
);

-- Index on Provider coordinates for nearby geospatial queries
CREATE INDEX idx_provider_location ON provider_profiles (latitude, longitude);
CREATE INDEX idx_provider_category ON provider_profiles (category_id);
CREATE INDEX idx_provider_available ON provider_profiles (is_available_now);

-- 4. BOOKINGS TABLE
CREATE TABLE bookings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  customer_id UUID NOT NULL REFERENCES users(id),
  provider_id UUID NOT NULL REFERENCES provider_profiles(id),
  category_id VARCHAR(50) NOT NULL REFERENCES categories(id),
  problem_description TEXT NOT NULL,
  photos TEXT[] DEFAULT '{}',
  preferred_time VARCHAR(100) NOT NULL,
  is_emergency BOOLEAN NOT NULL DEFAULT false,
  status booking_status NOT NULL DEFAULT 'PENDING',
  visit_fee NUMERIC(10, 2) NOT NULL,
  additional_charges NUMERIC(10, 2) DEFAULT 0.00,
  final_bill NUMERIC(10, 2),
  platform_commission_rate NUMERIC(4, 2) NOT NULL DEFAULT 0.10,
  platform_commission_amount NUMERIC(10, 2),
  provider_earnings NUMERIC(10, 2),
  payment_method payment_method NOT NULL DEFAULT 'cash',
  payment_status payment_status NOT NULL DEFAULT 'pending',
  delivery_address TEXT NOT NULL,
  delivery_area VARCHAR(100) NOT NULL,
  delivery_city VARCHAR(50) NOT NULL DEFAULT 'Karachi',
  latitude NUMERIC(9, 6),
  longitude NUMERIC(9, 6),
  cancellation_reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_booking_customer ON bookings (customer_id);
CREATE INDEX idx_booking_provider ON bookings (provider_id);
CREATE INDEX idx_booking_status ON bookings (status);

-- 5. BOOKING STATUS AUDIT TIMELINE
CREATE TABLE booking_status_history (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  booking_id UUID NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  status booking_status NOT NULL,
  note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 6. REVIEWS TABLE
CREATE TABLE reviews (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  booking_id UUID NOT NULL UNIQUE REFERENCES bookings(id) ON DELETE CASCADE,
  customer_id UUID NOT NULL REFERENCES users(id),
  provider_id UUID NOT NULL REFERENCES provider_profiles(id),
  rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment TEXT NOT NULL,
  tags TEXT[] DEFAULT '{}',
  provider_response TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_reviews_provider ON reviews (provider_id);

-- 7. CHAT MESSAGES
CREATE TABLE chat_messages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  booking_id UUID NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  sender_id UUID NOT NULL REFERENCES users(id),
  sender_role user_role NOT NULL,
  message_text TEXT NOT NULL,
  is_read BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_chat_booking ON chat_messages (booking_id);

-- 8. USER REPORTS & SAFETY INCIDENTS
CREATE TABLE user_reports (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  reporter_id UUID NOT NULL REFERENCES users(id),
  target_id UUID NOT NULL,
  target_type VARCHAR(20) NOT NULL,
  category report_category NOT NULL,
  description TEXT NOT NULL,
  status report_status NOT NULL DEFAULT 'OPEN',
  admin_notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 9. PLATFORM SETTINGS
CREATE TABLE platform_settings (
  id SERIAL PRIMARY KEY,
  commission_percentage NUMERIC(4, 2) NOT NULL DEFAULT 10.00,
  emergency_surcharge NUMERIC(10, 2) NOT NULL DEFAULT 250.00,
  min_visit_charge NUMERIC(10, 2) NOT NULL DEFAULT 350.00,
  active_cities TEXT[] DEFAULT ARRAY['Karachi'],
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
