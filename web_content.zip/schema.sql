CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS users(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), name TEXT NOT NULL, email TEXT UNIQUE NOT NULL,
 phone TEXT NOT NULL, cpf TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL,
 role TEXT NOT NULL CHECK(role IN ('passenger','driver','admin')),
 status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','pending','approved','rejected','blocked')),
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS driver_profiles(
 user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
 cnh_number TEXT NOT NULL, vehicle_type TEXT NOT NULL CHECK(vehicle_type IN ('car','motorcycle')),
 vehicle_model TEXT NOT NULL, vehicle_plate TEXT NOT NULL, is_online BOOLEAN NOT NULL DEFAULT FALSE,
 lat DOUBLE PRECISION, lng DOUBLE PRECISION, location_updated_at TIMESTAMPTZ, review_note TEXT
);
CREATE TABLE IF NOT EXISTS rides(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), passenger_id UUID NOT NULL REFERENCES users(id),
 driver_id UUID REFERENCES users(id), vehicle_type TEXT NOT NULL CHECK(vehicle_type IN ('car','motorcycle')),
 origin TEXT NOT NULL, destination TEXT NOT NULL, origin_lat DOUBLE PRECISION, origin_lng DOUBLE PRECISION,
 fare_cents INTEGER NOT NULL CHECK(fare_cents>0), commission_cents INTEGER NOT NULL,
 driver_amount_cents INTEGER NOT NULL,
 status TEXT NOT NULL DEFAULT 'requested' CHECK(status IN ('requested','dispatching','accepted','completed','cancelled')),
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), completed_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS rides_status_idx ON rides(status);
CREATE INDEX IF NOT EXISTS driver_profiles_online_idx ON driver_profiles(is_online,vehicle_type);
