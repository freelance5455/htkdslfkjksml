-- Illustrative production schema. Apply only after reviewing privacy/security requirements.
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  role TEXT NOT NULL CHECK(role IN ('customer','merchant','courier','support','admin')),
  display_name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS restaurants (
  id TEXT PRIMARY KEY,
  owner_user_id TEXT NOT NULL REFERENCES users(id),
  name TEXT NOT NULL,
  description TEXT,
  address TEXT NOT NULL,
  latitude REAL,
  longitude REAL,
  is_open INTEGER NOT NULL DEFAULT 0,
  service_radius_km REAL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS menu_items (
  id TEXT PRIMARY KEY,
  restaurant_id TEXT NOT NULL REFERENCES restaurants(id),
  name TEXT NOT NULL,
  description TEXT,
  price_centavos INTEGER NOT NULL CHECK(price_centavos >= 0),
  photo_key TEXT,
  is_available INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS orders (
  id TEXT PRIMARY KEY,
  customer_user_id TEXT NOT NULL REFERENCES users(id),
  restaurant_id TEXT NOT NULL REFERENCES restaurants(id),
  courier_user_id TEXT REFERENCES users(id),
  status TEXT NOT NULL CHECK(status IN ('placed','accepted','preparing','ready','picked_up','en_route','delivered','cancelled','refunded')),
  delivery_address TEXT NOT NULL,
  delivery_latitude REAL,
  delivery_longitude REAL,
  subtotal_centavos INTEGER NOT NULL,
  delivery_fee_centavos INTEGER NOT NULL,
  service_fee_centavos INTEGER NOT NULL DEFAULT 0,
  total_centavos INTEGER NOT NULL,
  payment_method TEXT NOT NULL,
  payment_status TEXT NOT NULL DEFAULT 'pending',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS order_items (
  order_id TEXT NOT NULL REFERENCES orders(id),
  menu_item_id TEXT NOT NULL REFERENCES menu_items(id),
  item_name_snapshot TEXT NOT NULL,
  quantity INTEGER NOT NULL CHECK(quantity > 0),
  unit_price_centavos INTEGER NOT NULL CHECK(unit_price_centavos >= 0),
  PRIMARY KEY(order_id, menu_item_id)
);

CREATE TABLE IF NOT EXISTS reviews (
  id TEXT PRIMARY KEY,
  order_id TEXT NOT NULL REFERENCES orders(id),
  customer_user_id TEXT NOT NULL REFERENCES users(id),
  restaurant_rating INTEGER CHECK(restaurant_rating BETWEEN 1 AND 5),
  courier_rating INTEGER CHECK(courier_rating BETWEEN 1 AND 5),
  food_quality INTEGER CHECK(food_quality BETWEEN 1 AND 5),
  speed_rating INTEGER CHECK(speed_rating BETWEEN 1 AND 5),
  packaging_rating INTEGER CHECK(packaging_rating BETWEEN 1 AND 5),
  comment TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(order_id, customer_user_id)
);

CREATE TABLE IF NOT EXISTS order_events (
  id TEXT PRIMARY KEY,
  order_id TEXT NOT NULL REFERENCES orders(id),
  actor_user_id TEXT REFERENCES users(id),
  status TEXT NOT NULL,
  note TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Production implementation must enforce ownership/role checks in server handlers;
-- schema constraints alone are not authorization.
