-- Run this in Supabase SQL Editor.
create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null,
  phone text not null,
  date date not null,
  time time not null,
  guests integer not null check (guests between 1 and 20),
  special_request text default '',
  status text not null default 'pending' check (status in ('pending','accepted','rejected')),
  created_at timestamptz not null default now()
);

alter table public.bookings enable row level security;

-- Customer can create bookings.
create policy "public can create bookings"
on public.bookings for insert
to anon, authenticated
with check (status = 'pending');

-- DEMO policy so the dashboard can read/update.
-- For a real restaurant, replace this with authenticated staff policies.
create policy "demo can read bookings"
on public.bookings for select
to anon, authenticated
using (true);

create policy "demo can update bookings"
on public.bookings for update
to anon, authenticated
using (true)
with check (status in ('pending','accepted','rejected'));
