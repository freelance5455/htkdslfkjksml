CREATE TABLE IF NOT EXISTS app_users (
  username VARCHAR(191) NOT NULL PRIMARY KEY,
  data JSON NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS app_roles (
  role_name VARCHAR(191) NOT NULL PRIMARY KEY,
  data JSON NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS app_logs (
  log_id VARCHAR(191) NOT NULL PRIMARY KEY,
  username VARCHAR(191) NOT NULL,
  data JSON NOT NULL,
  event_time BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  INDEX idx_logs_user_time (username, event_time)
);
CREATE TABLE IF NOT EXISTS app_resets (
  username VARCHAR(191) NOT NULL PRIMARY KEY,
  reset_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS app_appeals (
  appeal_id VARCHAR(191) NOT NULL PRIMARY KEY,
  username VARCHAR(191) NOT NULL,
  data JSON NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS app_messages (
  message_id VARCHAR(191) NOT NULL PRIMARY KEY,
  room_name VARCHAR(191) NOT NULL,
  sender VARCHAR(191) NOT NULL,
  data JSON NOT NULL,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  INDEX idx_messages_room_time (room_name, created_at)
);
CREATE TABLE IF NOT EXISTS app_signals (
  username VARCHAR(191) NOT NULL,
  signal_id VARCHAR(191) NOT NULL,
  data JSON NOT NULL,
  updated_at BIGINT NOT NULL,
  PRIMARY KEY (username, signal_id)
);
CREATE TABLE IF NOT EXISTS app_settings (
  setting_key VARCHAR(191) NOT NULL PRIMARY KEY,
  data JSON NOT NULL,
  updated_at BIGINT NOT NULL
);
