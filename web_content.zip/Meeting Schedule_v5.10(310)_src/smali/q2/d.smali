.class public interface abstract Lq2/d;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Ljava/lang/String;Z)Lq2/d;
.end method

.method public abstract b(Ljava/lang/String;I)Lq2/d;
.end method

.method public abstract c(Ljava/lang/String;I)I
.end method

.method public abstract d(Ljava/lang/String;J)J
.end method

.method public abstract e(Ljava/lang/String;Ljava/lang/Object;)Lq2/d;
.end method

.method public abstract f(Ljava/lang/String;Z)Z
.end method

.method public abstract g(Ljava/lang/String;)Ljava/lang/Object;
.end method

.method public abstract h(Ljava/lang/String;J)Lq2/d;
.end method
