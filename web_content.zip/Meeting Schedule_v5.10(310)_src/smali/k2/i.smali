.class public Lk2/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LR1/c;


# instance fields
.field private final a:Z

.field private final b:Z


# direct methods
.method public constructor <init>()V
    .locals 1

    const/4 v0, 0x1

    .line 4
    invoke-direct {p0, v0, v0}, Lk2/i;-><init>(ZZ)V

    return-void
.end method

.method public constructor <init>(ZZ)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-boolean p1, p0, Lk2/i;->a:Z

    .line 3
    iput-boolean p2, p0, Lk2/i;->b:Z

    return-void
.end method
