.class public abstract Li2/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LQ1/j;


# instance fields
.field protected b:LQ1/j;


# direct methods
.method public constructor <init>(LQ1/j;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const-string v0, "Wrapped entity"

    .line 5
    .line 6
    invoke-static {p1, v0}, Ls2/a;->g(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object p1

    .line 10
    check-cast p1, LQ1/j;

    .line 11
    .line 12
    iput-object p1, p0, Li2/d;->b:LQ1/j;

    .line 13
    .line 14
    return-void
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
.end method


# virtual methods
.method public a()LQ1/d;
    .locals 1

    .line 1
    iget-object v0, p0, Li2/d;->b:LQ1/j;

    .line 2
    .line 3
    invoke-interface {v0}, LQ1/j;->a()LQ1/d;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
.end method

.method public b(Ljava/io/OutputStream;)V
    .locals 1

    .line 1
    iget-object v0, p0, Li2/d;->b:LQ1/j;

    .line 2
    .line 3
    invoke-interface {v0, p1}, LQ1/j;->b(Ljava/io/OutputStream;)V

    .line 4
    .line 5
    .line 6
    return-void
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
.end method

.method public c()Z
    .locals 1

    .line 1
    iget-object v0, p0, Li2/d;->b:LQ1/j;

    .line 2
    .line 3
    invoke-interface {v0}, LQ1/j;->c()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
.end method

.method public e()LQ1/d;
    .locals 1

    .line 1
    iget-object v0, p0, Li2/d;->b:LQ1/j;

    .line 2
    .line 3
    invoke-interface {v0}, LQ1/j;->e()LQ1/d;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
.end method

.method public i()Z
    .locals 1

    .line 1
    iget-object v0, p0, Li2/d;->b:LQ1/j;

    .line 2
    .line 3
    invoke-interface {v0}, LQ1/j;->i()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
.end method

.method public k()Z
    .locals 1

    .line 1
    iget-object v0, p0, Li2/d;->b:LQ1/j;

    .line 2
    .line 3
    invoke-interface {v0}, LQ1/j;->k()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
.end method

.method public m()Ljava/io/InputStream;
    .locals 1

    .line 1
    iget-object v0, p0, Li2/d;->b:LQ1/j;

    .line 2
    .line 3
    invoke-interface {v0}, LQ1/j;->m()Ljava/io/InputStream;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
.end method

.method public n()J
    .locals 2

    .line 1
    iget-object v0, p0, Li2/d;->b:LQ1/j;

    .line 2
    .line 3
    invoke-interface {v0}, LQ1/j;->n()J

    .line 4
    .line 5
    .line 6
    move-result-wide v0

    .line 7
    return-wide v0
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
.end method
