.class public final Li2/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field public static final e:Li2/c;

.field public static final f:Li2/c;

.field public static final g:Li2/c;

.field public static final h:Li2/c;

.field public static final i:Li2/c;

.field public static final j:Li2/c;

.field public static final k:Li2/c;

.field public static final l:Li2/c;

.field public static final m:Li2/c;

.field public static final n:Li2/c;

.field public static final o:Li2/c;

.field public static final p:Li2/c;

.field public static final q:Li2/c;

.field public static final r:Li2/c;

.field public static final s:Li2/c;

.field public static final t:Li2/c;

.field public static final u:Li2/c;

.field public static final v:Li2/c;

.field public static final w:Li2/c;

.field private static final x:Ljava/util/Map;

.field public static final y:Li2/c;

.field public static final z:Li2/c;


# instance fields
.field private final b:Ljava/lang/String;

.field private final c:Ljava/nio/charset/Charset;

.field private final d:[LQ1/u;


# direct methods
.method static constructor <clinit>()V
    .locals 20

    .line 1
    sget-object v0, LQ1/b;->c:Ljava/nio/charset/Charset;

    .line 2
    .line 3
    const-string v1, "application/atom+xml"

    .line 4
    .line 5
    invoke-static {v1, v0}, Li2/c;->c(Ljava/lang/String;Ljava/nio/charset/Charset;)Li2/c;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    sput-object v1, Li2/c;->e:Li2/c;

    .line 10
    .line 11
    const-string v2, "application/x-www-form-urlencoded"

    .line 12
    .line 13
    invoke-static {v2, v0}, Li2/c;->c(Ljava/lang/String;Ljava/nio/charset/Charset;)Li2/c;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    sput-object v2, Li2/c;->f:Li2/c;

    .line 18
    .line 19
    const-string v3, "application/json"

    .line 20
    .line 21
    sget-object v4, LQ1/b;->a:Ljava/nio/charset/Charset;

    .line 22
    .line 23
    invoke-static {v3, v4}, Li2/c;->c(Ljava/lang/String;Ljava/nio/charset/Charset;)Li2/c;

    .line 24
    .line 25
    .line 26
    move-result-object v3

    .line 27
    sput-object v3, Li2/c;->g:Li2/c;

    .line 28
    .line 29
    const-string v4, "application/octet-stream"

    .line 30
    .line 31
    const/4 v5, 0x0

    .line 32
    invoke-static {v4, v5}, Li2/c;->c(Ljava/lang/String;Ljava/nio/charset/Charset;)Li2/c;

    .line 33
    .line 34
    .line 35
    move-result-object v4

    .line 36
    sput-object v4, Li2/c;->h:Li2/c;

    .line 37
    .line 38
    const-string v4, "application/svg+xml"

    .line 39
    .line 40
    invoke-static {v4, v0}, Li2/c;->c(Ljava/lang/String;Ljava/nio/charset/Charset;)Li2/c;

    .line 41
    .line 42
    .line 43
    move-result-object v4

    .line 44
    sput-object v4, Li2/c;->i:Li2/c;

    .line 45
    .line 46
    const-string v6, "application/xhtml+xml"

    .line 47
    .line 48
    invoke-static {v6, v0}, Li2/c;->c(Ljava/lang/String;Ljava/nio/charset/Charset;)Li2/c;

    .line 49
    .line 50
    .line 51
    move-result-object v6

    .line 52
    sput-object v6, Li2/c;->j:Li2/c;

    .line 53
    .line 54
    const-string v7, "application/xml"

    .line 55
    .line 56
    invoke-static {v7, v0}, Li2/c;->c(Ljava/lang/String;Ljava/nio/charset/Charset;)Li2/c;

    .line 57
    .line 58
    .line 59
    move-result-object v7

    .line 60
    sput-object v7, Li2/c;->k:Li2/c;

    .line 61
    .line 62
    const-string v8, "image/bmp"

    .line 63
    .line 64
    invoke-static {v8}, Li2/c;->b(Ljava/lang/String;)Li2/c;

    .line 65
    .line 66
    .line 67
    move-result-object v8

    .line 68
    sput-object v8, Li2/c;->l:Li2/c;

    .line 69
    .line 70
    const-string v9, "image/gif"

    .line 71
    .line 72
    invoke-static {v9}, Li2/c;->b(Ljava/lang/String;)Li2/c;

    .line 73
    .line 74
    .line 75
    move-result-object v9

    .line 76
    sput-object v9, Li2/c;->m:Li2/c;

    .line 77
    .line 78
    const-string v10, "image/jpeg"

    .line 79
    .line 80
    invoke-static {v10}, Li2/c;->b(Ljava/lang/String;)Li2/c;

    .line 81
    .line 82
    .line 83
    move-result-object v10

    .line 84
    sput-object v10, Li2/c;->n:Li2/c;

    .line 85
    .line 86
    const-string v11, "image/png"

    .line 87
    .line 88
    invoke-static {v11}, Li2/c;->b(Ljava/lang/String;)Li2/c;

    .line 89
    .line 90
    .line 91
    move-result-object v11

    .line 92
    sput-object v11, Li2/c;->o:Li2/c;

    .line 93
    .line 94
    const-string v12, "image/svg+xml"

    .line 95
    .line 96
    invoke-static {v12}, Li2/c;->b(Ljava/lang/String;)Li2/c;

    .line 97
    .line 98
    .line 99
    move-result-object v12

    .line 100
    sput-object v12, Li2/c;->p:Li2/c;

    .line 101
    .line 102
    const-string v13, "image/tiff"

    .line 103
    .line 104
    invoke-static {v13}, Li2/c;->b(Ljava/lang/String;)Li2/c;

    .line 105
    .line 106
    .line 107
    move-result-object v13

    .line 108
    sput-object v13, Li2/c;->q:Li2/c;

    .line 109
    .line 110
    const-string v14, "image/webp"

    .line 111
    .line 112
    invoke-static {v14}, Li2/c;->b(Ljava/lang/String;)Li2/c;

    .line 113
    .line 114
    .line 115
    move-result-object v14

    .line 116
    sput-object v14, Li2/c;->r:Li2/c;

    .line 117
    .line 118
    const-string v15, "multipart/form-data"

    .line 119
    .line 120
    invoke-static {v15, v0}, Li2/c;->c(Ljava/lang/String;Ljava/nio/charset/Charset;)Li2/c;

    .line 121
    .line 122
    .line 123
    move-result-object v15

    .line 124
    sput-object v15, Li2/c;->s:Li2/c;

    .line 125
    .line 126
    const-string v5, "text/html"

    .line 127
    .line 128
    invoke-static {v5, v0}, Li2/c;->c(Ljava/lang/String;Ljava/nio/charset/Charset;)Li2/c;

    .line 129
    .line 130
    .line 131
    move-result-object v5

    .line 132
    sput-object v5, Li2/c;->t:Li2/c;

    .line 133
    .line 134
    move-object/from16 v17, v5

    .line 135
    .line 136
    const-string v5, "text/plain"

    .line 137
    .line 138
    invoke-static {v5, v0}, Li2/c;->c(Ljava/lang/String;Ljava/nio/charset/Charset;)Li2/c;

    .line 139
    .line 140
    .line 141
    move-result-object v5

    .line 142
    sput-object v5, Li2/c;->u:Li2/c;

    .line 143
    .line 144
    move-object/from16 v18, v5

    .line 145
    .line 146
    const-string v5, "text/xml"

    .line 147
    .line 148
    invoke-static {v5, v0}, Li2/c;->c(Ljava/lang/String;Ljava/nio/charset/Charset;)Li2/c;

    .line 149
    .line 150
    .line 151
    move-result-object v0

    .line 152
    sput-object v0, Li2/c;->v:Li2/c;

    .line 153
    .line 154
    const-string v5, "*/*"

    .line 155
    .line 156
    move-object/from16 v19, v0

    .line 157
    .line 158
    const/4 v0, 0x0

    .line 159
    invoke-static {v5, v0}, Li2/c;->c(Ljava/lang/String;Ljava/nio/charset/Charset;)Li2/c;

    .line 160
    .line 161
    .line 162
    move-result-object v0

    .line 163
    sput-object v0, Li2/c;->w:Li2/c;

    .line 164
    .line 165
    const/16 v0, 0x11

    .line 166
    .line 167
    new-array v5, v0, [Li2/c;

    .line 168
    .line 169
    const/16 v16, 0x0

    .line 170
    .line 171
    aput-object v1, v5, v16

    .line 172
    .line 173
    const/4 v1, 0x1

    .line 174
    aput-object v2, v5, v1

    .line 175
    .line 176
    const/4 v2, 0x2

    .line 177
    aput-object v3, v5, v2

    .line 178
    .line 179
    const/4 v2, 0x3

    .line 180
    aput-object v4, v5, v2

    .line 181
    .line 182
    const/4 v2, 0x4

    .line 183
    aput-object v6, v5, v2

    .line 184
    .line 185
    const/4 v2, 0x5

    .line 186
    aput-object v7, v5, v2

    .line 187
    .line 188
    const/4 v2, 0x6

    .line 189
    aput-object v8, v5, v2

    .line 190
    .line 191
    const/4 v2, 0x7

    .line 192
    aput-object v9, v5, v2

    .line 193
    .line 194
    const/16 v2, 0x8

    .line 195
    .line 196
    aput-object v10, v5, v2

    .line 197
    .line 198
    const/16 v2, 0x9

    .line 199
    .line 200
    aput-object v11, v5, v2

    .line 201
    .line 202
    const/16 v2, 0xa

    .line 203
    .line 204
    aput-object v12, v5, v2

    .line 205
    .line 206
    const/16 v2, 0xb

    .line 207
    .line 208
    aput-object v13, v5, v2

    .line 209
    .line 210
    const/16 v2, 0xc

    .line 211
    .line 212
    aput-object v14, v5, v2

    .line 213
    .line 214
    const/16 v2, 0xd

    .line 215
    .line 216
    aput-object v15, v5, v2

    .line 217
    .line 218
    const/16 v2, 0xe

    .line 219
    .line 220
    aput-object v17, v5, v2

    .line 221
    .line 222
    const/16 v2, 0xf

    .line 223
    .line 224
    aput-object v18, v5, v2

    .line 225
    .line 226
    const/16 v2, 0x10

    .line 227
    .line 228
    aput-object v19, v5, v2

    .line 229
    .line 230
    new-instance v2, Ljava/util/HashMap;

    .line 231
    .line 232
    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    .line 233
    .line 234
    .line 235
    const/4 v3, 0x0

    .line 236
    :goto_0
    if-ge v3, v0, :cond_0

    .line 237
    .line 238
    aget-object v4, v5, v3

    .line 239
    .line 240
    invoke-virtual {v4}, Li2/c;->g()Ljava/lang/String;

    .line 241
    .line 242
    .line 243
    move-result-object v6

    .line 244
    invoke-virtual {v2, v6, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 245
    .line 246
    .line 247
    add-int/2addr v3, v1

    .line 248
    goto :goto_0

    .line 249
    :cond_0
    invoke-static {v2}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 250
    .line 251
    .line 252
    move-result-object v0

    .line 253
    sput-object v0, Li2/c;->x:Ljava/util/Map;

    .line 254
    .line 255
    sget-object v0, Li2/c;->u:Li2/c;

    .line 256
    .line 257
    sput-object v0, Li2/c;->y:Li2/c;

    .line 258
    .line 259
    sget-object v0, Li2/c;->h:Li2/c;

    .line 260
    .line 261
    sput-object v0, Li2/c;->z:Li2/c;

    .line 262
    .line 263
    return-void
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
.end method

.method constructor <init>(Ljava/lang/String;Ljava/nio/charset/Charset;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Li2/c;->b:Ljava/lang/String;

    .line 3
    iput-object p2, p0, Li2/c;->c:Ljava/nio/charset/Charset;

    const/4 p1, 0x0

    .line 4
    iput-object p1, p0, Li2/c;->d:[LQ1/u;

    return-void
.end method

.method constructor <init>(Ljava/lang/String;Ljava/nio/charset/Charset;[LQ1/u;)V
    .locals 0

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    iput-object p1, p0, Li2/c;->b:Ljava/lang/String;

    .line 7
    iput-object p2, p0, Li2/c;->c:Ljava/nio/charset/Charset;

    .line 8
    iput-object p3, p0, Li2/c;->d:[LQ1/u;

    return-void
.end method

.method private static a(LQ1/e;Z)Li2/c;
    .locals 1

    .line 1
    invoke-interface {p0}, LQ1/e;->getName()Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-interface {p0}, LQ1/e;->a()[LQ1/u;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    invoke-static {v0, p0, p1}, Li2/c;->d(Ljava/lang/String;[LQ1/u;Z)Li2/c;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    return-object p0
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
.end method

.method public static b(Ljava/lang/String;)Li2/c;
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-static {p0, v0}, Li2/c;->c(Ljava/lang/String;Ljava/nio/charset/Charset;)Li2/c;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    return-object p0
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
.end method

.method public static c(Ljava/lang/String;Ljava/nio/charset/Charset;)Li2/c;
    .locals 2

    .line 1
    const-string v0, "MIME type"

    .line 2
    .line 3
    invoke-static {p0, v0}, Ls2/a;->d(Ljava/lang/CharSequence;Ljava/lang/String;)Ljava/lang/CharSequence;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Ljava/lang/String;

    .line 8
    .line 9
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 10
    .line 11
    invoke-virtual {p0, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    invoke-static {p0}, Li2/c;->h(Ljava/lang/String;)Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    const-string v1, "MIME type may not contain reserved characters"

    .line 20
    .line 21
    invoke-static {v0, v1}, Ls2/a;->a(ZLjava/lang/String;)V

    .line 22
    .line 23
    .line 24
    new-instance v0, Li2/c;

    .line 25
    .line 26
    invoke-direct {v0, p0, p1}, Li2/c;-><init>(Ljava/lang/String;Ljava/nio/charset/Charset;)V

    .line 27
    .line 28
    .line 29
    return-object v0
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
.end method

.method private static d(Ljava/lang/String;[LQ1/u;Z)Li2/c;
    .locals 6

    .line 1
    array-length v0, p1

    .line 2
    const/4 v1, 0x0

    .line 3
    :goto_0
    const/4 v2, 0x0

    .line 4
    if-ge v1, v0, :cond_2

    .line 5
    .line 6
    aget-object v3, p1, v1

    .line 7
    .line 8
    invoke-interface {v3}, LQ1/u;->getName()Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v4

    .line 12
    const-string v5, "charset"

    .line 13
    .line 14
    invoke-virtual {v4, v5}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 15
    .line 16
    .line 17
    move-result v4

    .line 18
    if-eqz v4, :cond_1

    .line 19
    .line 20
    invoke-interface {v3}, LQ1/u;->getValue()Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    invoke-static {v0}, Ls2/f;->b(Ljava/lang/CharSequence;)Z

    .line 25
    .line 26
    .line 27
    move-result v1

    .line 28
    if-nez v1, :cond_2

    .line 29
    .line 30
    :try_start_0
    invoke-static {v0}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    .line 31
    .line 32
    .line 33
    move-result-object p2
    :try_end_0
    .catch Ljava/nio/charset/UnsupportedCharsetException; {:try_start_0 .. :try_end_0} :catch_0

    .line 34
    goto :goto_2

    .line 35
    :catch_0
    move-exception v0

    .line 36
    if-nez p2, :cond_0

    .line 37
    .line 38
    goto :goto_1

    .line 39
    :cond_0
    throw v0

    .line 40
    :cond_1
    add-int/lit8 v1, v1, 0x1

    .line 41
    .line 42
    goto :goto_0

    .line 43
    :cond_2
    :goto_1
    move-object p2, v2

    .line 44
    :goto_2
    new-instance v0, Li2/c;

    .line 45
    .line 46
    array-length v1, p1

    .line 47
    if-lez v1, :cond_3

    .line 48
    .line 49
    goto :goto_3

    .line 50
    :cond_3
    move-object p1, v2

    .line 51
    :goto_3
    invoke-direct {v0, p0, p2, p1}, Li2/c;-><init>(Ljava/lang/String;Ljava/nio/charset/Charset;[LQ1/u;)V

    .line 52
    .line 53
    .line 54
    return-object v0
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
.end method

.method public static e(LQ1/j;)Li2/c;
    .locals 2

    .line 1
    const/4 v0, 0x0

    .line 2
    if-nez p0, :cond_0

    .line 3
    .line 4
    return-object v0

    .line 5
    :cond_0
    invoke-interface {p0}, LQ1/j;->a()LQ1/d;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    if-eqz p0, :cond_1

    .line 10
    .line 11
    invoke-interface {p0}, LQ1/d;->a()[LQ1/e;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    array-length v1, p0

    .line 16
    if-lez v1, :cond_1

    .line 17
    .line 18
    const/4 v0, 0x0

    .line 19
    aget-object p0, p0, v0

    .line 20
    .line 21
    const/4 v0, 0x1

    .line 22
    invoke-static {p0, v0}, Li2/c;->a(LQ1/e;Z)Li2/c;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    return-object p0

    .line 27
    :cond_1
    return-object v0
    .line 28
    .line 29
.end method

.method private static h(Ljava/lang/String;)Z
    .locals 4

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x0

    .line 3
    :goto_0
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 4
    .line 5
    .line 6
    move-result v2

    .line 7
    if-ge v1, v2, :cond_2

    .line 8
    .line 9
    invoke-virtual {p0, v1}, Ljava/lang/String;->charAt(I)C

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    const/16 v3, 0x22

    .line 14
    .line 15
    if-eq v2, v3, :cond_1

    .line 16
    .line 17
    const/16 v3, 0x2c

    .line 18
    .line 19
    if-eq v2, v3, :cond_1

    .line 20
    .line 21
    const/16 v3, 0x3b

    .line 22
    .line 23
    if-ne v2, v3, :cond_0

    .line 24
    .line 25
    goto :goto_1

    .line 26
    :cond_0
    add-int/lit8 v1, v1, 0x1

    .line 27
    .line 28
    goto :goto_0

    .line 29
    :cond_1
    :goto_1
    return v0

    .line 30
    :cond_2
    const/4 p0, 0x1

    .line 31
    return p0
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
.end method


# virtual methods
.method public f()Ljava/nio/charset/Charset;
    .locals 1

    .line 1
    iget-object v0, p0, Li2/c;->c:Ljava/nio/charset/Charset;

    .line 2
    .line 3
    return-object v0
    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
.end method

.method public g()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, Li2/c;->b:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    .line 1
    new-instance v0, Ls2/c;

    .line 2
    .line 3
    const/16 v1, 0x40

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ls2/c;-><init>(I)V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, Li2/c;->b:Ljava/lang/String;

    .line 9
    .line 10
    invoke-virtual {v0, v1}, Ls2/c;->b(Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    iget-object v1, p0, Li2/c;->d:[LQ1/u;

    .line 14
    .line 15
    if-eqz v1, :cond_0

    .line 16
    .line 17
    const-string v1, "; "

    .line 18
    .line 19
    invoke-virtual {v0, v1}, Ls2/c;->b(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    sget-object v1, Lp2/e;->b:Lp2/e;

    .line 23
    .line 24
    iget-object v2, p0, Li2/c;->d:[LQ1/u;

    .line 25
    .line 26
    const/4 v3, 0x0

    .line 27
    invoke-virtual {v1, v0, v2, v3}, Lp2/e;->e(Ls2/c;[LQ1/u;Z)Ls2/c;

    .line 28
    .line 29
    .line 30
    goto :goto_0

    .line 31
    :cond_0
    iget-object v1, p0, Li2/c;->c:Ljava/nio/charset/Charset;

    .line 32
    .line 33
    if-eqz v1, :cond_1

    .line 34
    .line 35
    const-string v1, "; charset="

    .line 36
    .line 37
    invoke-virtual {v0, v1}, Ls2/c;->b(Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    iget-object v1, p0, Li2/c;->c:Ljava/nio/charset/Charset;

    .line 41
    .line 42
    invoke-virtual {v1}, Ljava/nio/charset/Charset;->name()Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    invoke-virtual {v0, v1}, Ls2/c;->b(Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    :cond_1
    :goto_0
    invoke-virtual {v0}, Ls2/c;->toString()Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    return-object v0
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
.end method
