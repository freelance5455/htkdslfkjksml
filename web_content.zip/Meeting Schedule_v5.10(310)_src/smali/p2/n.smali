.class public interface abstract Lp2/n;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Ls2/c;Lp2/o;)[LQ1/e;
.end method

.method public abstract b(Ls2/c;Lp2/o;)LQ1/e;
.end method
