.class public Lp2/g;
.super Lp2/a;
.source "SourceFile"

# interfaces
.implements LQ1/p;


# instance fields
.field private final d:Ljava/lang/String;

.field private final e:Ljava/lang/String;

.field private f:LQ1/y;


# direct methods
.method public constructor <init>(LQ1/y;)V
    .locals 1

    .line 2
    invoke-direct {p0}, Lp2/a;-><init>()V

    .line 3
    const-string v0, "Request line"

    invoke-static {p1, v0}, Ls2/a;->g(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LQ1/y;

    iput-object v0, p0, Lp2/g;->f:LQ1/y;

    .line 4
    invoke-interface {p1}, LQ1/y;->e()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lp2/g;->d:Ljava/lang/String;

    .line 5
    invoke-interface {p1}, LQ1/y;->f()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lp2/g;->e:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;LQ1/x;)V
    .locals 1

    .line 1
    new-instance v0, Lp2/k;

    invoke-direct {v0, p1, p2, p3}, Lp2/k;-><init>(Ljava/lang/String;Ljava/lang/String;LQ1/x;)V

    invoke-direct {p0, v0}, Lp2/g;-><init>(LQ1/y;)V

    return-void
.end method


# virtual methods
.method public a()LQ1/x;
    .locals 1

    .line 1
    invoke-virtual {p0}, Lp2/g;->s()LQ1/y;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-interface {v0}, LQ1/y;->a()LQ1/x;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    return-object v0
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
.end method

.method public s()LQ1/y;
    .locals 4

    .line 1
    iget-object v0, p0, Lp2/g;->f:LQ1/y;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    new-instance v0, Lp2/k;

    .line 6
    .line 7
    iget-object v1, p0, Lp2/g;->d:Ljava/lang/String;

    .line 8
    .line 9
    iget-object v2, p0, Lp2/g;->e:Ljava/lang/String;

    .line 10
    .line 11
    sget-object v3, LQ1/t;->g:LQ1/t;

    .line 12
    .line 13
    invoke-direct {v0, v1, v2, v3}, Lp2/k;-><init>(Ljava/lang/String;Ljava/lang/String;LQ1/x;)V

    .line 14
    .line 15
    .line 16
    iput-object v0, p0, Lp2/g;->f:LQ1/y;

    .line 17
    .line 18
    :cond_0
    iget-object v0, p0, Lp2/g;->f:LQ1/y;

    .line 19
    .line 20
    return-object v0
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, Lp2/g;->d:Ljava/lang/String;

    .line 7
    .line 8
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 9
    .line 10
    .line 11
    const/16 v1, 0x20

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 14
    .line 15
    .line 16
    iget-object v2, p0, Lp2/g;->e:Ljava/lang/String;

    .line 17
    .line 18
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 19
    .line 20
    .line 21
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 22
    .line 23
    .line 24
    iget-object v1, p0, Lp2/a;->b:Lp2/m;

    .line 25
    .line 26
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 27
    .line 28
    .line 29
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    return-object v0
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
.end method
