.class public interface abstract LR1/g;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()Ljava/security/Principal;
.end method
