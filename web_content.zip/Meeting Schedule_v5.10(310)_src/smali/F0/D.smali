.class public abstract synthetic LF0/D;
.super Ljava/lang/Object;
.source "SourceFile"
