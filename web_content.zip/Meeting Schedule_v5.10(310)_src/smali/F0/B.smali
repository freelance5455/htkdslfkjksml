.class public abstract synthetic LF0/B;
.super Ljava/lang/Object;
.source "SourceFile"
