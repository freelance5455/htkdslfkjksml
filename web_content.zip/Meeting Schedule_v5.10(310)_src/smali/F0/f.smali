.class public abstract synthetic LF0/f;
.super Ljava/lang/Object;
.source "SourceFile"
