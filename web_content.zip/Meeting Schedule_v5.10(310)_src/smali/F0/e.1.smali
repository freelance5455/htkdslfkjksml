.class public interface abstract LF0/e;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()LF0/b;
.end method
