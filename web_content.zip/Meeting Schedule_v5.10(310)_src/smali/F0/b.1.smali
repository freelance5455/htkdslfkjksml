.class public interface abstract LF0/b;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()LE0/f;
.end method

.method public abstract b(LF0/a;ILandroid/app/Activity;I)Z
.end method

.method public abstract c()LE0/f;
.end method
