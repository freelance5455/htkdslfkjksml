.class public interface abstract Lh2/h;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Lh2/c;Lh2/f;)V
.end method

.method public abstract b()I
.end method

.method public abstract c(LQ1/d;Lh2/f;)Ljava/util/List;
.end method
