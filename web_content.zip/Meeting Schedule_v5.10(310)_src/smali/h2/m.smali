.class public interface abstract Lh2/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lh2/n;


# virtual methods
.method public abstract f(Z)V
.end method

.method public abstract m(Ljava/lang/String;)V
.end method

.method public abstract n([I)V
.end method
