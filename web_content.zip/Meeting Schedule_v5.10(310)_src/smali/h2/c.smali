.class public interface abstract Lh2/c;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract b()I
.end method

.method public abstract c()Ljava/lang/String;
.end method

.method public abstract g()[I
.end method

.method public abstract getName()Ljava/lang/String;
.end method

.method public abstract getPath()Ljava/lang/String;
.end method

.method public abstract k(Ljava/util/Date;)Z
.end method
