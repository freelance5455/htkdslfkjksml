.class public interface abstract Lh2/d;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Lh2/c;Lh2/f;)V
.end method

.method public abstract c(Lh2/n;Ljava/lang/String;)V
.end method
