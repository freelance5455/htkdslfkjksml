.class public interface abstract Lh2/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lh2/d;


# virtual methods
.method public abstract b()Ljava/lang/String;
.end method
