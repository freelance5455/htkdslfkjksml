.class public interface abstract Lh2/n;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lh2/c;


# virtual methods
.method public abstract a(Ljava/lang/String;)V
.end method

.method public abstract d(I)V
.end method

.method public abstract e(Z)V
.end method

.method public abstract h(Ljava/util/Date;)V
.end method

.method public abstract i(Ljava/lang/String;)V
.end method

.method public abstract l(Ljava/lang/String;)V
.end method
