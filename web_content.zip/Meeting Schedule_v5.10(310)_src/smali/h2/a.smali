.class public interface abstract Lh2/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lh2/c;


# virtual methods
.method public abstract j(Ljava/lang/String;)Z
.end method
