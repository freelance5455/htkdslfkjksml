.class public Lo2/m;
.super Lo2/p;
.source "SourceFile"


# static fields
.field private static final b:[Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    const/16 v0, 0xe

    .line 2
    .line 3
    new-array v0, v0, [Ljava/lang/String;

    .line 4
    .line 5
    const-string v1, "EEE, dd MMM yyyy HH:mm:ss zzz"

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    aput-object v1, v0, v2

    .line 9
    .line 10
    const-string v1, "EEE, dd-MMM-yy HH:mm:ss zzz"

    .line 11
    .line 12
    const/4 v2, 0x1

    .line 13
    aput-object v1, v0, v2

    .line 14
    .line 15
    const-string v1, "EEE MMM d HH:mm:ss yyyy"

    .line 16
    .line 17
    const/4 v2, 0x2

    .line 18
    aput-object v1, v0, v2

    .line 19
    .line 20
    const-string v1, "EEE, dd-MMM-yyyy HH:mm:ss z"

    .line 21
    .line 22
    const/4 v2, 0x3

    .line 23
    aput-object v1, v0, v2

    .line 24
    .line 25
    const-string v1, "EEE, dd-MMM-yyyy HH-mm-ss z"

    .line 26
    .line 27
    const/4 v2, 0x4

    .line 28
    aput-object v1, v0, v2

    .line 29
    .line 30
    const-string v1, "EEE, dd MMM yy HH:mm:ss z"

    .line 31
    .line 32
    const/4 v2, 0x5

    .line 33
    aput-object v1, v0, v2

    .line 34
    .line 35
    const-string v1, "EEE dd-MMM-yyyy HH:mm:ss z"

    .line 36
    .line 37
    const/4 v2, 0x6

    .line 38
    aput-object v1, v0, v2

    .line 39
    .line 40
    const-string v1, "EEE dd MMM yyyy HH:mm:ss z"

    .line 41
    .line 42
    const/4 v2, 0x7

    .line 43
    aput-object v1, v0, v2

    .line 44
    .line 45
    const-string v1, "EEE dd-MMM-yyyy HH-mm-ss z"

    .line 46
    .line 47
    const/16 v2, 0x8

    .line 48
    .line 49
    aput-object v1, v0, v2

    .line 50
    .line 51
    const-string v1, "EEE dd-MMM-yy HH:mm:ss z"

    .line 52
    .line 53
    const/16 v2, 0x9

    .line 54
    .line 55
    aput-object v1, v0, v2

    .line 56
    .line 57
    const-string v1, "EEE dd MMM yy HH:mm:ss z"

    .line 58
    .line 59
    const/16 v2, 0xa

    .line 60
    .line 61
    aput-object v1, v0, v2

    .line 62
    .line 63
    const-string v1, "EEE,dd-MMM-yy HH:mm:ss z"

    .line 64
    .line 65
    const/16 v2, 0xb

    .line 66
    .line 67
    aput-object v1, v0, v2

    .line 68
    .line 69
    const-string v1, "EEE,dd-MMM-yyyy HH:mm:ss z"

    .line 70
    .line 71
    const/16 v2, 0xc

    .line 72
    .line 73
    aput-object v1, v0, v2

    .line 74
    .line 75
    const-string v1, "EEE, dd-MM-yyyy HH:mm:ss z"

    .line 76
    .line 77
    const/16 v2, 0xd

    .line 78
    .line 79
    aput-object v1, v0, v2

    .line 80
    .line 81
    sput-object v0, Lo2/m;->b:[Ljava/lang/String;

    .line 82
    .line 83
    return-void
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
.end method

.method public constructor <init>([Ljava/lang/String;Lo2/n$a;)V
    .locals 7

    .line 1
    new-instance v0, Lo2/o;

    .line 2
    .line 3
    invoke-direct {v0}, Lo2/o;-><init>()V

    .line 4
    .line 5
    .line 6
    new-instance v1, Lo2/f;

    .line 7
    .line 8
    invoke-direct {v1}, Lo2/f;-><init>()V

    .line 9
    .line 10
    .line 11
    sget-object v2, Lo2/n$a;->c:Lo2/n$a;

    .line 12
    .line 13
    if-ne p2, v2, :cond_0

    .line 14
    .line 15
    new-instance p2, Lo2/m$a;

    .line 16
    .line 17
    invoke-direct {p2}, Lo2/m$a;-><init>()V

    .line 18
    .line 19
    .line 20
    goto :goto_0

    .line 21
    :cond_0
    new-instance p2, Lo2/i;

    .line 22
    .line 23
    invoke-direct {p2}, Lo2/i;-><init>()V

    .line 24
    .line 25
    .line 26
    :goto_0
    new-instance v2, Lo2/h;

    .line 27
    .line 28
    invoke-direct {v2}, Lo2/h;-><init>()V

    .line 29
    .line 30
    .line 31
    new-instance v3, Lo2/j;

    .line 32
    .line 33
    invoke-direct {v3}, Lo2/j;-><init>()V

    .line 34
    .line 35
    .line 36
    new-instance v4, Lo2/e;

    .line 37
    .line 38
    invoke-direct {v4}, Lo2/e;-><init>()V

    .line 39
    .line 40
    .line 41
    new-instance v5, Lo2/g;

    .line 42
    .line 43
    if-eqz p1, :cond_1

    .line 44
    .line 45
    invoke-virtual {p1}, [Ljava/lang/String;->clone()Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    check-cast p1, [Ljava/lang/String;

    .line 50
    .line 51
    goto :goto_1

    .line 52
    :cond_1
    sget-object p1, Lo2/m;->b:[Ljava/lang/String;

    .line 53
    .line 54
    :goto_1
    invoke-direct {v5, p1}, Lo2/g;-><init>([Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    const/4 p1, 0x7

    .line 58
    new-array p1, p1, [Lh2/b;

    .line 59
    .line 60
    const/4 v6, 0x0

    .line 61
    aput-object v0, p1, v6

    .line 62
    .line 63
    const/4 v0, 0x1

    .line 64
    aput-object v1, p1, v0

    .line 65
    .line 66
    const/4 v0, 0x2

    .line 67
    aput-object p2, p1, v0

    .line 68
    .line 69
    const/4 p2, 0x3

    .line 70
    aput-object v2, p1, p2

    .line 71
    .line 72
    const/4 p2, 0x4

    .line 73
    aput-object v3, p1, p2

    .line 74
    .line 75
    const/4 p2, 0x5

    .line 76
    aput-object v4, p1, p2

    .line 77
    .line 78
    const/4 p2, 0x6

    .line 79
    aput-object v5, p1, p2

    .line 80
    .line 81
    invoke-direct {p0, p1}, Lo2/p;-><init>([Lh2/b;)V

    .line 82
    .line 83
    .line 84
    return-void
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
.end method


# virtual methods
.method public b()I
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    return v0
    .line 3
    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
.end method

.method public c(LQ1/d;Lh2/f;)Ljava/util/List;
    .locals 9

    .line 1
    const-string v0, "Header"

    .line 2
    .line 3
    invoke-static {p1, v0}, Ls2/a;->g(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    const-string v0, "Cookie origin"

    .line 7
    .line 8
    invoke-static {p2, v0}, Ls2/a;->g(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    invoke-interface {p1}, LQ1/u;->getName()Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    const-string v1, "Set-Cookie"

    .line 16
    .line 17
    invoke-virtual {v0, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-eqz v0, :cond_b

    .line 22
    .line 23
    invoke-interface {p1}, LQ1/d;->a()[LQ1/e;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    array-length v1, v0

    .line 28
    const/4 v2, 0x0

    .line 29
    const/4 v3, 0x0

    .line 30
    const/4 v4, 0x0

    .line 31
    const/4 v5, 0x0

    .line 32
    :goto_0
    const/4 v6, 0x1

    .line 33
    if-ge v3, v1, :cond_2

    .line 34
    .line 35
    aget-object v7, v0, v3

    .line 36
    .line 37
    const-string v8, "version"

    .line 38
    .line 39
    invoke-interface {v7, v8}, LQ1/e;->b(Ljava/lang/String;)LQ1/u;

    .line 40
    .line 41
    .line 42
    move-result-object v8

    .line 43
    if-eqz v8, :cond_0

    .line 44
    .line 45
    const/4 v5, 0x1

    .line 46
    :cond_0
    const-string v8, "expires"

    .line 47
    .line 48
    invoke-interface {v7, v8}, LQ1/e;->b(Ljava/lang/String;)LQ1/u;

    .line 49
    .line 50
    .line 51
    move-result-object v7

    .line 52
    if-eqz v7, :cond_1

    .line 53
    .line 54
    const/4 v4, 0x1

    .line 55
    :cond_1
    add-int/lit8 v3, v3, 0x1

    .line 56
    .line 57
    goto :goto_0

    .line 58
    :cond_2
    if-nez v4, :cond_4

    .line 59
    .line 60
    if-nez v5, :cond_3

    .line 61
    .line 62
    goto :goto_1

    .line 63
    :cond_3
    invoke-virtual {p0, v0, p2}, Lo2/p;->h([LQ1/e;Lh2/f;)Ljava/util/List;

    .line 64
    .line 65
    .line 66
    move-result-object p1

    .line 67
    return-object p1

    .line 68
    :cond_4
    :goto_1
    sget-object v0, Lo2/t;->b:Lo2/t;

    .line 69
    .line 70
    instance-of v1, p1, LQ1/c;

    .line 71
    .line 72
    if-eqz v1, :cond_5

    .line 73
    .line 74
    check-cast p1, LQ1/c;

    .line 75
    .line 76
    invoke-interface {p1}, LQ1/c;->c()Ls2/c;

    .line 77
    .line 78
    .line 79
    move-result-object v1

    .line 80
    new-instance v3, Lp2/o;

    .line 81
    .line 82
    invoke-interface {p1}, LQ1/c;->b()I

    .line 83
    .line 84
    .line 85
    move-result p1

    .line 86
    invoke-virtual {v1}, Ls2/c;->length()I

    .line 87
    .line 88
    .line 89
    move-result v5

    .line 90
    invoke-direct {v3, p1, v5}, Lp2/o;-><init>(II)V

    .line 91
    .line 92
    .line 93
    goto :goto_2

    .line 94
    :cond_5
    invoke-interface {p1}, LQ1/u;->getValue()Ljava/lang/String;

    .line 95
    .line 96
    .line 97
    move-result-object p1

    .line 98
    if-eqz p1, :cond_a

    .line 99
    .line 100
    new-instance v1, Ls2/c;

    .line 101
    .line 102
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 103
    .line 104
    .line 105
    move-result v3

    .line 106
    invoke-direct {v1, v3}, Ls2/c;-><init>(I)V

    .line 107
    .line 108
    .line 109
    invoke-virtual {v1, p1}, Ls2/c;->b(Ljava/lang/String;)V

    .line 110
    .line 111
    .line 112
    new-instance v3, Lp2/o;

    .line 113
    .line 114
    invoke-virtual {v1}, Ls2/c;->length()I

    .line 115
    .line 116
    .line 117
    move-result p1

    .line 118
    invoke-direct {v3, v2, p1}, Lp2/o;-><init>(II)V

    .line 119
    .line 120
    .line 121
    :goto_2
    invoke-virtual {v0, v1, v3}, Lo2/t;->a(Ls2/c;Lp2/o;)LQ1/e;

    .line 122
    .line 123
    .line 124
    move-result-object p1

    .line 125
    invoke-interface {p1}, LQ1/e;->getName()Ljava/lang/String;

    .line 126
    .line 127
    .line 128
    move-result-object v0

    .line 129
    invoke-interface {p1}, LQ1/e;->getValue()Ljava/lang/String;

    .line 130
    .line 131
    .line 132
    move-result-object v1

    .line 133
    if-eqz v0, :cond_9

    .line 134
    .line 135
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    .line 136
    .line 137
    .line 138
    move-result v3

    .line 139
    if-nez v3, :cond_9

    .line 140
    .line 141
    new-instance v3, Lo2/d;

    .line 142
    .line 143
    invoke-direct {v3, v0, v1}, Lo2/d;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 144
    .line 145
    .line 146
    invoke-static {p2}, Lo2/p;->g(Lh2/f;)Ljava/lang/String;

    .line 147
    .line 148
    .line 149
    move-result-object v0

    .line 150
    invoke-virtual {v3, v0}, Lo2/d;->i(Ljava/lang/String;)V

    .line 151
    .line 152
    .line 153
    invoke-static {p2}, Lo2/p;->f(Lh2/f;)Ljava/lang/String;

    .line 154
    .line 155
    .line 156
    move-result-object p2

    .line 157
    invoke-virtual {v3, p2}, Lo2/d;->a(Ljava/lang/String;)V

    .line 158
    .line 159
    .line 160
    invoke-interface {p1}, LQ1/e;->a()[LQ1/u;

    .line 161
    .line 162
    .line 163
    move-result-object p1

    .line 164
    array-length p2, p1

    .line 165
    sub-int/2addr p2, v6

    .line 166
    :goto_3
    if-ltz p2, :cond_7

    .line 167
    .line 168
    aget-object v0, p1, p2

    .line 169
    .line 170
    invoke-interface {v0}, LQ1/u;->getName()Ljava/lang/String;

    .line 171
    .line 172
    .line 173
    move-result-object v1

    .line 174
    sget-object v5, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 175
    .line 176
    invoke-virtual {v1, v5}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 177
    .line 178
    .line 179
    move-result-object v1

    .line 180
    invoke-interface {v0}, LQ1/u;->getValue()Ljava/lang/String;

    .line 181
    .line 182
    .line 183
    move-result-object v5

    .line 184
    invoke-virtual {v3, v1, v5}, Lo2/d;->o(Ljava/lang/String;Ljava/lang/String;)V

    .line 185
    .line 186
    .line 187
    invoke-virtual {p0, v1}, Lo2/b;->d(Ljava/lang/String;)Lh2/d;

    .line 188
    .line 189
    .line 190
    move-result-object v1

    .line 191
    if-eqz v1, :cond_6

    .line 192
    .line 193
    invoke-interface {v0}, LQ1/u;->getValue()Ljava/lang/String;

    .line 194
    .line 195
    .line 196
    move-result-object v0

    .line 197
    invoke-interface {v1, v3, v0}, Lh2/d;->c(Lh2/n;Ljava/lang/String;)V

    .line 198
    .line 199
    .line 200
    :cond_6
    add-int/lit8 p2, p2, -0x1

    .line 201
    .line 202
    goto :goto_3

    .line 203
    :cond_7
    if-eqz v4, :cond_8

    .line 204
    .line 205
    invoke-virtual {v3, v2}, Lo2/d;->d(I)V

    .line 206
    .line 207
    .line 208
    :cond_8
    invoke-static {v3}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 209
    .line 210
    .line 211
    move-result-object p1

    .line 212
    return-object p1

    .line 213
    :cond_9
    new-instance p1, Lh2/l;

    .line 214
    .line 215
    const-string p2, "Cookie name may not be empty"

    .line 216
    .line 217
    invoke-direct {p1, p2}, Lh2/l;-><init>(Ljava/lang/String;)V

    .line 218
    .line 219
    .line 220
    throw p1

    .line 221
    :cond_a
    new-instance p1, Lh2/l;

    .line 222
    .line 223
    const-string p2, "Header value is null"

    .line 224
    .line 225
    invoke-direct {p1, p2}, Lh2/l;-><init>(Ljava/lang/String;)V

    .line 226
    .line 227
    .line 228
    throw p1

    .line 229
    :cond_b
    new-instance p2, Lh2/l;

    .line 230
    .line 231
    new-instance v0, Ljava/lang/StringBuilder;

    .line 232
    .line 233
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 234
    .line 235
    .line 236
    const-string v1, "Unrecognized cookie header \'"

    .line 237
    .line 238
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 239
    .line 240
    .line 241
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 242
    .line 243
    .line 244
    move-result-object p1

    .line 245
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 246
    .line 247
    .line 248
    const-string p1, "\'"

    .line 249
    .line 250
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 251
    .line 252
    .line 253
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 254
    .line 255
    .line 256
    move-result-object p1

    .line 257
    invoke-direct {p2, p1}, Lh2/l;-><init>(Ljava/lang/String;)V

    .line 258
    .line 259
    .line 260
    goto :goto_5

    .line 261
    :goto_4
    throw p2

    .line 262
    :goto_5
    goto :goto_4
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
.end method

.method public toString()Ljava/lang/String;
    .locals 1

    .line 1
    const-string v0, "compatibility"

    .line 2
    .line 3
    return-object v0
    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
.end method
