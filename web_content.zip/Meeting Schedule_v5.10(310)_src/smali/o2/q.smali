.class public abstract Lo2/q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lh2/h;


# instance fields
.field private final a:Lo2/E;

.field private final b:Lo2/x;

.field private final c:Lo2/u;


# direct methods
.method public constructor <init>([Ljava/lang/String;Z)V
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move/from16 v1, p2

    .line 4
    .line 5
    invoke-direct/range {p0 .. p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    new-instance v2, Lo2/E;

    .line 9
    .line 10
    new-instance v3, Lo2/G;

    .line 11
    .line 12
    invoke-direct {v3}, Lo2/G;-><init>()V

    .line 13
    .line 14
    .line 15
    new-instance v4, Lo2/i;

    .line 16
    .line 17
    invoke-direct {v4}, Lo2/i;-><init>()V

    .line 18
    .line 19
    .line 20
    new-instance v5, Lo2/C;

    .line 21
    .line 22
    invoke-direct {v5}, Lo2/C;-><init>()V

    .line 23
    .line 24
    .line 25
    new-instance v6, Lo2/D;

    .line 26
    .line 27
    invoke-direct {v6}, Lo2/D;-><init>()V

    .line 28
    .line 29
    .line 30
    new-instance v7, Lo2/h;

    .line 31
    .line 32
    invoke-direct {v7}, Lo2/h;-><init>()V

    .line 33
    .line 34
    .line 35
    new-instance v8, Lo2/j;

    .line 36
    .line 37
    invoke-direct {v8}, Lo2/j;-><init>()V

    .line 38
    .line 39
    .line 40
    new-instance v9, Lo2/e;

    .line 41
    .line 42
    invoke-direct {v9}, Lo2/e;-><init>()V

    .line 43
    .line 44
    .line 45
    new-instance v10, Lo2/A;

    .line 46
    .line 47
    invoke-direct {v10}, Lo2/A;-><init>()V

    .line 48
    .line 49
    .line 50
    new-instance v11, Lo2/B;

    .line 51
    .line 52
    invoke-direct {v11}, Lo2/B;-><init>()V

    .line 53
    .line 54
    .line 55
    const/16 v12, 0x9

    .line 56
    .line 57
    new-array v12, v12, [Lh2/b;

    .line 58
    .line 59
    const/4 v13, 0x0

    .line 60
    aput-object v3, v12, v13

    .line 61
    .line 62
    const/4 v3, 0x1

    .line 63
    aput-object v4, v12, v3

    .line 64
    .line 65
    const/4 v4, 0x2

    .line 66
    aput-object v5, v12, v4

    .line 67
    .line 68
    const/4 v5, 0x3

    .line 69
    aput-object v6, v12, v5

    .line 70
    .line 71
    const/4 v6, 0x4

    .line 72
    aput-object v7, v12, v6

    .line 73
    .line 74
    const/4 v7, 0x5

    .line 75
    aput-object v8, v12, v7

    .line 76
    .line 77
    const/4 v8, 0x6

    .line 78
    aput-object v9, v12, v8

    .line 79
    .line 80
    const/4 v9, 0x7

    .line 81
    aput-object v10, v12, v9

    .line 82
    .line 83
    const/16 v9, 0x8

    .line 84
    .line 85
    aput-object v11, v12, v9

    .line 86
    .line 87
    invoke-direct {v2, v1, v12}, Lo2/E;-><init>(Z[Lh2/b;)V

    .line 88
    .line 89
    .line 90
    iput-object v2, v0, Lo2/q;->a:Lo2/E;

    .line 91
    .line 92
    new-instance v2, Lo2/x;

    .line 93
    .line 94
    new-instance v9, Lo2/z;

    .line 95
    .line 96
    invoke-direct {v9}, Lo2/z;-><init>()V

    .line 97
    .line 98
    .line 99
    new-instance v10, Lo2/i;

    .line 100
    .line 101
    invoke-direct {v10}, Lo2/i;-><init>()V

    .line 102
    .line 103
    .line 104
    new-instance v11, Lo2/w;

    .line 105
    .line 106
    invoke-direct {v11}, Lo2/w;-><init>()V

    .line 107
    .line 108
    .line 109
    new-instance v12, Lo2/h;

    .line 110
    .line 111
    invoke-direct {v12}, Lo2/h;-><init>()V

    .line 112
    .line 113
    .line 114
    new-instance v14, Lo2/j;

    .line 115
    .line 116
    invoke-direct {v14}, Lo2/j;-><init>()V

    .line 117
    .line 118
    .line 119
    new-instance v15, Lo2/e;

    .line 120
    .line 121
    invoke-direct {v15}, Lo2/e;-><init>()V

    .line 122
    .line 123
    .line 124
    new-array v8, v8, [Lh2/b;

    .line 125
    .line 126
    aput-object v9, v8, v13

    .line 127
    .line 128
    aput-object v10, v8, v3

    .line 129
    .line 130
    aput-object v11, v8, v4

    .line 131
    .line 132
    aput-object v12, v8, v5

    .line 133
    .line 134
    aput-object v14, v8, v6

    .line 135
    .line 136
    aput-object v15, v8, v7

    .line 137
    .line 138
    invoke-direct {v2, v1, v8}, Lo2/x;-><init>(Z[Lh2/b;)V

    .line 139
    .line 140
    .line 141
    iput-object v2, v0, Lo2/q;->b:Lo2/x;

    .line 142
    .line 143
    new-instance v1, Lo2/u;

    .line 144
    .line 145
    new-instance v2, Lo2/f;

    .line 146
    .line 147
    invoke-direct {v2}, Lo2/f;-><init>()V

    .line 148
    .line 149
    .line 150
    new-instance v8, Lo2/i;

    .line 151
    .line 152
    invoke-direct {v8}, Lo2/i;-><init>()V

    .line 153
    .line 154
    .line 155
    new-instance v9, Lo2/j;

    .line 156
    .line 157
    invoke-direct {v9}, Lo2/j;-><init>()V

    .line 158
    .line 159
    .line 160
    new-instance v10, Lo2/e;

    .line 161
    .line 162
    invoke-direct {v10}, Lo2/e;-><init>()V

    .line 163
    .line 164
    .line 165
    new-instance v11, Lo2/g;

    .line 166
    .line 167
    if-eqz p1, :cond_0

    .line 168
    .line 169
    invoke-virtual/range {p1 .. p1}, [Ljava/lang/String;->clone()Ljava/lang/Object;

    .line 170
    .line 171
    .line 172
    move-result-object v12

    .line 173
    check-cast v12, [Ljava/lang/String;

    .line 174
    .line 175
    goto :goto_0

    .line 176
    :cond_0
    new-array v12, v3, [Ljava/lang/String;

    .line 177
    .line 178
    const-string v14, "EEE, dd-MMM-yy HH:mm:ss z"

    .line 179
    .line 180
    aput-object v14, v12, v13

    .line 181
    .line 182
    :goto_0
    invoke-direct {v11, v12}, Lo2/g;-><init>([Ljava/lang/String;)V

    .line 183
    .line 184
    .line 185
    new-array v7, v7, [Lh2/b;

    .line 186
    .line 187
    aput-object v2, v7, v13

    .line 188
    .line 189
    aput-object v8, v7, v3

    .line 190
    .line 191
    aput-object v9, v7, v4

    .line 192
    .line 193
    aput-object v10, v7, v5

    .line 194
    .line 195
    aput-object v11, v7, v6

    .line 196
    .line 197
    invoke-direct {v1, v7}, Lo2/u;-><init>([Lh2/b;)V

    .line 198
    .line 199
    .line 200
    iput-object v1, v0, Lo2/q;->c:Lo2/u;

    .line 201
    .line 202
    return-void
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
.end method


# virtual methods
.method public a(Lh2/c;Lh2/f;)V
    .locals 1

    .line 1
    const-string v0, "Cookie"

    .line 2
    .line 3
    invoke-static {p1, v0}, Ls2/a;->g(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    const-string v0, "Cookie origin"

    .line 7
    .line 8
    invoke-static {p2, v0}, Ls2/a;->g(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    invoke-interface {p1}, Lh2/c;->b()I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-lez v0, :cond_1

    .line 16
    .line 17
    instance-of v0, p1, Lh2/m;

    .line 18
    .line 19
    if-eqz v0, :cond_0

    .line 20
    .line 21
    iget-object v0, p0, Lo2/q;->a:Lo2/E;

    .line 22
    .line 23
    invoke-virtual {v0, p1, p2}, Lo2/E;->a(Lh2/c;Lh2/f;)V

    .line 24
    .line 25
    .line 26
    goto :goto_0

    .line 27
    :cond_0
    iget-object v0, p0, Lo2/q;->b:Lo2/x;

    .line 28
    .line 29
    invoke-virtual {v0, p1, p2}, Lo2/x;->a(Lh2/c;Lh2/f;)V

    .line 30
    .line 31
    .line 32
    goto :goto_0

    .line 33
    :cond_1
    iget-object v0, p0, Lo2/q;->c:Lo2/u;

    .line 34
    .line 35
    invoke-virtual {v0, p1, p2}, Lo2/p;->a(Lh2/c;Lh2/f;)V

    .line 36
    .line 37
    .line 38
    :goto_0
    return-void
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
.end method

.method public b()I
    .locals 1

    .line 1
    iget-object v0, p0, Lo2/q;->a:Lo2/E;

    .line 2
    .line 3
    invoke-virtual {v0}, Lo2/E;->b()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
.end method

.method public c(LQ1/d;Lh2/f;)Ljava/util/List;
    .locals 9

    .line 1
    const/4 v0, 0x1

    .line 2
    const-string v1, "Header"

    .line 3
    .line 4
    invoke-static {p1, v1}, Ls2/a;->g(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    const-string v1, "Cookie origin"

    .line 8
    .line 9
    invoke-static {p2, v1}, Ls2/a;->g(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    invoke-interface {p1}, LQ1/d;->a()[LQ1/e;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    array-length v2, v1

    .line 17
    const/4 v3, 0x0

    .line 18
    const/4 v4, 0x0

    .line 19
    const/4 v5, 0x0

    .line 20
    const/4 v6, 0x0

    .line 21
    :goto_0
    if-ge v4, v2, :cond_2

    .line 22
    .line 23
    aget-object v7, v1, v4

    .line 24
    .line 25
    const-string v8, "version"

    .line 26
    .line 27
    invoke-interface {v7, v8}, LQ1/e;->b(Ljava/lang/String;)LQ1/u;

    .line 28
    .line 29
    .line 30
    move-result-object v8

    .line 31
    if-eqz v8, :cond_0

    .line 32
    .line 33
    const/4 v6, 0x1

    .line 34
    :cond_0
    const-string v8, "expires"

    .line 35
    .line 36
    invoke-interface {v7, v8}, LQ1/e;->b(Ljava/lang/String;)LQ1/u;

    .line 37
    .line 38
    .line 39
    move-result-object v7

    .line 40
    if-eqz v7, :cond_1

    .line 41
    .line 42
    const/4 v5, 0x1

    .line 43
    :cond_1
    add-int/2addr v4, v0

    .line 44
    goto :goto_0

    .line 45
    :cond_2
    if-nez v5, :cond_5

    .line 46
    .line 47
    if-nez v6, :cond_3

    .line 48
    .line 49
    goto :goto_1

    .line 50
    :cond_3
    const-string v0, "Set-Cookie2"

    .line 51
    .line 52
    invoke-interface {p1}, LQ1/u;->getName()Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object p1

    .line 56
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 57
    .line 58
    .line 59
    move-result p1

    .line 60
    if-eqz p1, :cond_4

    .line 61
    .line 62
    iget-object p1, p0, Lo2/q;->a:Lo2/E;

    .line 63
    .line 64
    invoke-virtual {p1, v1, p2}, Lo2/E;->h([LQ1/e;Lh2/f;)Ljava/util/List;

    .line 65
    .line 66
    .line 67
    move-result-object p1

    .line 68
    return-object p1

    .line 69
    :cond_4
    iget-object p1, p0, Lo2/q;->b:Lo2/x;

    .line 70
    .line 71
    invoke-virtual {p1, v1, p2}, Lo2/p;->h([LQ1/e;Lh2/f;)Ljava/util/List;

    .line 72
    .line 73
    .line 74
    move-result-object p1

    .line 75
    return-object p1

    .line 76
    :cond_5
    :goto_1
    sget-object v1, Lo2/t;->b:Lo2/t;

    .line 77
    .line 78
    instance-of v2, p1, LQ1/c;

    .line 79
    .line 80
    if-eqz v2, :cond_6

    .line 81
    .line 82
    check-cast p1, LQ1/c;

    .line 83
    .line 84
    invoke-interface {p1}, LQ1/c;->c()Ls2/c;

    .line 85
    .line 86
    .line 87
    move-result-object v2

    .line 88
    new-instance v4, Lp2/o;

    .line 89
    .line 90
    invoke-interface {p1}, LQ1/c;->b()I

    .line 91
    .line 92
    .line 93
    move-result p1

    .line 94
    invoke-virtual {v2}, Ls2/c;->length()I

    .line 95
    .line 96
    .line 97
    move-result v5

    .line 98
    invoke-direct {v4, p1, v5}, Lp2/o;-><init>(II)V

    .line 99
    .line 100
    .line 101
    goto :goto_2

    .line 102
    :cond_6
    invoke-interface {p1}, LQ1/u;->getValue()Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object p1

    .line 106
    if-eqz p1, :cond_7

    .line 107
    .line 108
    new-instance v2, Ls2/c;

    .line 109
    .line 110
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 111
    .line 112
    .line 113
    move-result v4

    .line 114
    invoke-direct {v2, v4}, Ls2/c;-><init>(I)V

    .line 115
    .line 116
    .line 117
    invoke-virtual {v2, p1}, Ls2/c;->b(Ljava/lang/String;)V

    .line 118
    .line 119
    .line 120
    new-instance v4, Lp2/o;

    .line 121
    .line 122
    invoke-virtual {v2}, Ls2/c;->length()I

    .line 123
    .line 124
    .line 125
    move-result p1

    .line 126
    invoke-direct {v4, v3, p1}, Lp2/o;-><init>(II)V

    .line 127
    .line 128
    .line 129
    :goto_2
    invoke-virtual {v1, v2, v4}, Lo2/t;->a(Ls2/c;Lp2/o;)LQ1/e;

    .line 130
    .line 131
    .line 132
    move-result-object p1

    .line 133
    new-array v0, v0, [LQ1/e;

    .line 134
    .line 135
    aput-object p1, v0, v3

    .line 136
    .line 137
    iget-object p1, p0, Lo2/q;->c:Lo2/u;

    .line 138
    .line 139
    invoke-virtual {p1, v0, p2}, Lo2/p;->h([LQ1/e;Lh2/f;)Ljava/util/List;

    .line 140
    .line 141
    .line 142
    move-result-object p1

    .line 143
    return-object p1

    .line 144
    :cond_7
    new-instance p1, Lh2/l;

    .line 145
    .line 146
    const-string p2, "Header value is null"

    .line 147
    .line 148
    invoke-direct {p1, p2}, Lh2/l;-><init>(Ljava/lang/String;)V

    .line 149
    .line 150
    .line 151
    goto :goto_4

    .line 152
    :goto_3
    throw p1

    .line 153
    :goto_4
    goto :goto_3
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
.end method
