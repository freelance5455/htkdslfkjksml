.class public Lo2/y;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lh2/i;
.implements Lh2/j;


# instance fields
.field private final a:Lh2/h;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x0

    .line 3
    invoke-direct {p0, v0, v1}, Lo2/y;-><init>([Ljava/lang/String;Z)V

    return-void
.end method

.method public constructor <init>([Ljava/lang/String;Z)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, Lo2/x;

    invoke-direct {v0, p1, p2}, Lo2/x;-><init>([Ljava/lang/String;Z)V

    iput-object v0, p0, Lo2/y;->a:Lh2/h;

    return-void
.end method
