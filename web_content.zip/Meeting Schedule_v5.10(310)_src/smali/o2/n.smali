.class public Lo2/n;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lh2/i;
.implements Lh2/j;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lo2/n$a;
    }
.end annotation


# instance fields
.field private final a:Lo2/n$a;

.field private final b:Lh2/h;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x0

    .line 4
    sget-object v1, Lo2/n$a;->b:Lo2/n$a;

    invoke-direct {p0, v0, v1}, Lo2/n;-><init>([Ljava/lang/String;Lo2/n$a;)V

    return-void
.end method

.method public constructor <init>([Ljava/lang/String;Lo2/n$a;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p2, p0, Lo2/n;->a:Lo2/n$a;

    .line 3
    new-instance v0, Lo2/m;

    invoke-direct {v0, p1, p2}, Lo2/m;-><init>([Ljava/lang/String;Lo2/n$a;)V

    iput-object v0, p0, Lo2/n;->b:Lh2/h;

    return-void
.end method
