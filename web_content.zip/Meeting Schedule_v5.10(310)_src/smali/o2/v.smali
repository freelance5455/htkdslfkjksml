.class public Lo2/v;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lh2/i;
.implements Lh2/j;


# instance fields
.field private final a:Lh2/h;


# direct methods
.method public constructor <init>()V
    .locals 1

    const/4 v0, 0x0

    .line 3
    invoke-direct {p0, v0}, Lo2/v;-><init>([Ljava/lang/String;)V

    return-void
.end method

.method public constructor <init>([Ljava/lang/String;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, Lo2/u;

    invoke-direct {v0, p1}, Lo2/u;-><init>([Ljava/lang/String;)V

    iput-object v0, p0, Lo2/v;->a:Lh2/h;

    return-void
.end method
