.class public interface abstract LN/a;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(LP/g;)V
.end method
