.class public Lj2/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LQ1/a;


# static fields
.field public static final a:Lj2/a;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lj2/a;

    .line 2
    .line 3
    invoke-direct {v0}, Lj2/a;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lj2/a;->a:Lj2/a;

    .line 7
    .line 8
    return-void
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
.end method

.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
.end method

.method private b(LQ1/p;LQ1/r;)Z
    .locals 2

    .line 1
    const/4 v0, 0x0

    .line 2
    if-eqz p1, :cond_0

    .line 3
    .line 4
    invoke-interface {p1}, LQ1/p;->s()LQ1/y;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    invoke-interface {p1}, LQ1/y;->e()Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    const-string v1, "HEAD"

    .line 13
    .line 14
    invoke-virtual {p1, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 15
    .line 16
    .line 17
    move-result p1

    .line 18
    if-eqz p1, :cond_0

    .line 19
    .line 20
    return v0

    .line 21
    :cond_0
    invoke-interface {p2}, LQ1/r;->u()LQ1/z;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    invoke-interface {p1}, LQ1/z;->c()I

    .line 26
    .line 27
    .line 28
    move-result p1

    .line 29
    const/16 p2, 0xc8

    .line 30
    .line 31
    if-lt p1, p2, :cond_1

    .line 32
    .line 33
    const/16 p2, 0xcc

    .line 34
    .line 35
    if-eq p1, p2, :cond_1

    .line 36
    .line 37
    const/16 p2, 0x130

    .line 38
    .line 39
    if-eq p1, p2, :cond_1

    .line 40
    .line 41
    const/16 p2, 0xcd

    .line 42
    .line 43
    if-eq p1, p2, :cond_1

    .line 44
    .line 45
    const/4 v0, 0x1

    .line 46
    :cond_1
    return v0
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
.end method


# virtual methods
.method public a(LQ1/r;Lr2/e;)Z
    .locals 6

    .line 1
    const-string v0, "HTTP response"

    .line 2
    .line 3
    invoke-static {p1, v0}, Ls2/a;->g(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    const-string v0, "HTTP context"

    .line 7
    .line 8
    invoke-static {p2, v0}, Ls2/a;->g(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    const-string v0, "http.request"

    .line 12
    .line 13
    invoke-interface {p2, v0}, Lr2/e;->a(Ljava/lang/String;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p2

    .line 17
    check-cast p2, LQ1/p;

    .line 18
    .line 19
    const-string v0, "Close"

    .line 20
    .line 21
    const-string v1, "Connection"

    .line 22
    .line 23
    const/4 v2, 0x0

    .line 24
    if-eqz p2, :cond_1

    .line 25
    .line 26
    :try_start_0
    new-instance v3, Lp2/l;

    .line 27
    .line 28
    invoke-interface {p2, v1}, LQ1/o;->w(Ljava/lang/String;)LQ1/g;

    .line 29
    .line 30
    .line 31
    move-result-object v4

    .line 32
    invoke-direct {v3, v4}, Lp2/l;-><init>(LQ1/g;)V

    .line 33
    .line 34
    .line 35
    :cond_0
    invoke-interface {v3}, LQ1/A;->hasNext()Z

    .line 36
    .line 37
    .line 38
    move-result v4

    .line 39
    if-eqz v4, :cond_1

    .line 40
    .line 41
    invoke-interface {v3}, LQ1/A;->c()Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v4

    .line 45
    invoke-virtual {v0, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 46
    .line 47
    .line 48
    move-result v4
    :try_end_0
    .catch LQ1/v; {:try_start_0 .. :try_end_0} :catch_0

    .line 49
    if-eqz v4, :cond_0

    .line 50
    .line 51
    :catch_0
    return v2

    .line 52
    :cond_1
    invoke-interface {p1}, LQ1/r;->u()LQ1/z;

    .line 53
    .line 54
    .line 55
    move-result-object v3

    .line 56
    invoke-interface {v3}, LQ1/z;->a()LQ1/x;

    .line 57
    .line 58
    .line 59
    move-result-object v3

    .line 60
    const-string v4, "Transfer-Encoding"

    .line 61
    .line 62
    invoke-interface {p1, v4}, LQ1/o;->m(Ljava/lang/String;)LQ1/d;

    .line 63
    .line 64
    .line 65
    move-result-object v4

    .line 66
    const/4 v5, 0x1

    .line 67
    if-eqz v4, :cond_2

    .line 68
    .line 69
    const-string p2, "chunked"

    .line 70
    .line 71
    invoke-interface {v4}, LQ1/u;->getValue()Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object v4

    .line 75
    invoke-virtual {p2, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 76
    .line 77
    .line 78
    move-result p2

    .line 79
    if-nez p2, :cond_4

    .line 80
    .line 81
    return v2

    .line 82
    :cond_2
    invoke-direct {p0, p2, p1}, Lj2/a;->b(LQ1/p;LQ1/r;)Z

    .line 83
    .line 84
    .line 85
    move-result p2

    .line 86
    if-eqz p2, :cond_4

    .line 87
    .line 88
    const-string p2, "Content-Length"

    .line 89
    .line 90
    invoke-interface {p1, p2}, LQ1/o;->q(Ljava/lang/String;)[LQ1/d;

    .line 91
    .line 92
    .line 93
    move-result-object p2

    .line 94
    array-length v4, p2

    .line 95
    if-ne v4, v5, :cond_3

    .line 96
    .line 97
    aget-object p2, p2, v2

    .line 98
    .line 99
    :try_start_1
    invoke-interface {p2}, LQ1/u;->getValue()Ljava/lang/String;

    .line 100
    .line 101
    .line 102
    move-result-object p2

    .line 103
    invoke-static {p2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 104
    .line 105
    .line 106
    move-result p2
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_1

    .line 107
    if-gez p2, :cond_4

    .line 108
    .line 109
    :catch_1
    :cond_3
    return v2

    .line 110
    :cond_4
    invoke-interface {p1, v1}, LQ1/o;->w(Ljava/lang/String;)LQ1/g;

    .line 111
    .line 112
    .line 113
    move-result-object p2

    .line 114
    invoke-interface {p2}, LQ1/g;->hasNext()Z

    .line 115
    .line 116
    .line 117
    move-result v1

    .line 118
    if-nez v1, :cond_5

    .line 119
    .line 120
    const-string p2, "Proxy-Connection"

    .line 121
    .line 122
    invoke-interface {p1, p2}, LQ1/o;->w(Ljava/lang/String;)LQ1/g;

    .line 123
    .line 124
    .line 125
    move-result-object p2

    .line 126
    :cond_5
    invoke-interface {p2}, LQ1/g;->hasNext()Z

    .line 127
    .line 128
    .line 129
    move-result p1

    .line 130
    if-eqz p1, :cond_9

    .line 131
    .line 132
    :try_start_2
    new-instance p1, Lp2/l;

    .line 133
    .line 134
    invoke-direct {p1, p2}, Lp2/l;-><init>(LQ1/g;)V

    .line 135
    .line 136
    .line 137
    const/4 p2, 0x0

    .line 138
    :cond_6
    :goto_0
    invoke-interface {p1}, LQ1/A;->hasNext()Z

    .line 139
    .line 140
    .line 141
    move-result v1

    .line 142
    if-eqz v1, :cond_8

    .line 143
    .line 144
    invoke-interface {p1}, LQ1/A;->c()Ljava/lang/String;

    .line 145
    .line 146
    .line 147
    move-result-object v1

    .line 148
    invoke-virtual {v0, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 149
    .line 150
    .line 151
    move-result v4

    .line 152
    if-eqz v4, :cond_7

    .line 153
    .line 154
    return v2

    .line 155
    :cond_7
    const-string v4, "Keep-Alive"

    .line 156
    .line 157
    invoke-virtual {v4, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 158
    .line 159
    .line 160
    move-result v1
    :try_end_2
    .catch LQ1/v; {:try_start_2 .. :try_end_2} :catch_2

    .line 161
    if-eqz v1, :cond_6

    .line 162
    .line 163
    const/4 p2, 0x1

    .line 164
    goto :goto_0

    .line 165
    :cond_8
    if-eqz p2, :cond_9

    .line 166
    .line 167
    return v5

    .line 168
    :catch_2
    return v2

    .line 169
    :cond_9
    sget-object p1, LQ1/t;->f:LQ1/t;

    .line 170
    .line 171
    invoke-virtual {v3, p1}, LQ1/x;->f(LQ1/x;)Z

    .line 172
    .line 173
    .line 174
    move-result p1

    .line 175
    xor-int/2addr p1, v5

    .line 176
    return p1
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
.end method
