.class public abstract LW1/a;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(Lq2/d;)LT1/a;
    .locals 1

    .line 1
    sget-object v0, LT1/a;->r:LT1/a;

    .line 2
    .line 3
    invoke-static {p0, v0}, LW1/a;->b(Lq2/d;LT1/a;)LT1/a;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
.end method

.method public static b(Lq2/d;LT1/a;)LT1/a;
    .locals 4

    .line 1
    invoke-static {p1}, LT1/a;->b(LT1/a;)LT1/a$a;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {p1}, LT1/a;->j()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const-string v2, "http.socket.timeout"

    .line 10
    .line 11
    invoke-interface {p0, v2, v1}, Lq2/d;->c(Ljava/lang/String;I)I

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    invoke-virtual {v0, v1}, LT1/a$a;->p(I)LT1/a$a;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    const-string v1, "http.connection.stalecheck"

    .line 20
    .line 21
    invoke-virtual {p1}, LT1/a;->s()Z

    .line 22
    .line 23
    .line 24
    move-result v2

    .line 25
    invoke-interface {p0, v1, v2}, Lq2/d;->f(Ljava/lang/String;Z)Z

    .line 26
    .line 27
    .line 28
    move-result v1

    .line 29
    invoke-virtual {v0, v1}, LT1/a$a;->q(Z)LT1/a$a;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    const-string v1, "http.connection.timeout"

    .line 34
    .line 35
    invoke-virtual {p1}, LT1/a;->c()I

    .line 36
    .line 37
    .line 38
    move-result v2

    .line 39
    invoke-interface {p0, v1, v2}, Lq2/d;->c(Ljava/lang/String;I)I

    .line 40
    .line 41
    .line 42
    move-result v1

    .line 43
    invoke-virtual {v0, v1}, LT1/a$a;->d(I)LT1/a$a;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    const-string v1, "http.protocol.expect-continue"

    .line 48
    .line 49
    invoke-virtual {p1}, LT1/a;->p()Z

    .line 50
    .line 51
    .line 52
    move-result v2

    .line 53
    invoke-interface {p0, v1, v2}, Lq2/d;->f(Ljava/lang/String;Z)Z

    .line 54
    .line 55
    .line 56
    move-result v1

    .line 57
    invoke-virtual {v0, v1}, LT1/a$a;->i(Z)LT1/a$a;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    const-string v1, "http.protocol.handle-authentication"

    .line 62
    .line 63
    invoke-virtual {p1}, LT1/a;->l()Z

    .line 64
    .line 65
    .line 66
    move-result v2

    .line 67
    invoke-interface {p0, v1, v2}, Lq2/d;->f(Ljava/lang/String;Z)Z

    .line 68
    .line 69
    .line 70
    move-result v1

    .line 71
    invoke-virtual {v0, v1}, LT1/a$a;->b(Z)LT1/a$a;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    const-string v1, "http.protocol.allow-circular-redirects"

    .line 76
    .line 77
    invoke-virtual {p1}, LT1/a;->m()Z

    .line 78
    .line 79
    .line 80
    move-result v2

    .line 81
    invoke-interface {p0, v1, v2}, Lq2/d;->f(Ljava/lang/String;Z)Z

    .line 82
    .line 83
    .line 84
    move-result v1

    .line 85
    invoke-virtual {v0, v1}, LT1/a$a;->c(Z)LT1/a$a;

    .line 86
    .line 87
    .line 88
    move-result-object v0

    .line 89
    invoke-virtual {p1}, LT1/a;->d()I

    .line 90
    .line 91
    .line 92
    move-result v1

    .line 93
    int-to-long v1, v1

    .line 94
    const-string v3, "http.conn-manager.timeout"

    .line 95
    .line 96
    invoke-interface {p0, v3, v1, v2}, Lq2/d;->d(Ljava/lang/String;J)J

    .line 97
    .line 98
    .line 99
    move-result-wide v1

    .line 100
    long-to-int v2, v1

    .line 101
    invoke-virtual {v0, v2}, LT1/a$a;->e(I)LT1/a$a;

    .line 102
    .line 103
    .line 104
    move-result-object v0

    .line 105
    const-string v1, "http.protocol.max-redirects"

    .line 106
    .line 107
    invoke-virtual {p1}, LT1/a;->g()I

    .line 108
    .line 109
    .line 110
    move-result v2

    .line 111
    invoke-interface {p0, v1, v2}, Lq2/d;->c(Ljava/lang/String;I)I

    .line 112
    .line 113
    .line 114
    move-result v1

    .line 115
    invoke-virtual {v0, v1}, LT1/a$a;->k(I)LT1/a$a;

    .line 116
    .line 117
    .line 118
    move-result-object v0

    .line 119
    const-string v1, "http.protocol.handle-redirects"

    .line 120
    .line 121
    invoke-virtual {p1}, LT1/a;->q()Z

    .line 122
    .line 123
    .line 124
    move-result v2

    .line 125
    invoke-interface {p0, v1, v2}, Lq2/d;->f(Ljava/lang/String;Z)Z

    .line 126
    .line 127
    .line 128
    move-result v1

    .line 129
    invoke-virtual {v0, v1}, LT1/a$a;->n(Z)LT1/a$a;

    .line 130
    .line 131
    .line 132
    move-result-object v0

    .line 133
    invoke-virtual {p1}, LT1/a;->r()Z

    .line 134
    .line 135
    .line 136
    move-result p1

    .line 137
    xor-int/lit8 p1, p1, 0x1

    .line 138
    .line 139
    const-string v1, "http.protocol.reject-relative-redirect"

    .line 140
    .line 141
    invoke-interface {p0, v1, p1}, Lq2/d;->f(Ljava/lang/String;Z)Z

    .line 142
    .line 143
    .line 144
    move-result p1

    .line 145
    xor-int/lit8 p1, p1, 0x1

    .line 146
    .line 147
    invoke-virtual {v0, p1}, LT1/a$a;->o(Z)LT1/a$a;

    .line 148
    .line 149
    .line 150
    move-result-object p1

    .line 151
    const-string v0, "http.route.default-proxy"

    .line 152
    .line 153
    invoke-interface {p0, v0}, Lq2/d;->g(Ljava/lang/String;)Ljava/lang/Object;

    .line 154
    .line 155
    .line 156
    move-result-object v0

    .line 157
    check-cast v0, LQ1/m;

    .line 158
    .line 159
    if-eqz v0, :cond_0

    .line 160
    .line 161
    invoke-virtual {p1, v0}, LT1/a$a;->l(LQ1/m;)LT1/a$a;

    .line 162
    .line 163
    .line 164
    :cond_0
    const-string v0, "http.route.local-address"

    .line 165
    .line 166
    invoke-interface {p0, v0}, Lq2/d;->g(Ljava/lang/String;)Ljava/lang/Object;

    .line 167
    .line 168
    .line 169
    move-result-object v0

    .line 170
    check-cast v0, Ljava/net/InetAddress;

    .line 171
    .line 172
    if-eqz v0, :cond_1

    .line 173
    .line 174
    invoke-virtual {p1, v0}, LT1/a$a;->j(Ljava/net/InetAddress;)LT1/a$a;

    .line 175
    .line 176
    .line 177
    :cond_1
    const-string v0, "http.auth.target-scheme-pref"

    .line 178
    .line 179
    invoke-interface {p0, v0}, Lq2/d;->g(Ljava/lang/String;)Ljava/lang/Object;

    .line 180
    .line 181
    .line 182
    move-result-object v0

    .line 183
    check-cast v0, Ljava/util/Collection;

    .line 184
    .line 185
    if-eqz v0, :cond_2

    .line 186
    .line 187
    invoke-virtual {p1, v0}, LT1/a$a;->r(Ljava/util/Collection;)LT1/a$a;

    .line 188
    .line 189
    .line 190
    :cond_2
    const-string v0, "http.auth.proxy-scheme-pref"

    .line 191
    .line 192
    invoke-interface {p0, v0}, Lq2/d;->g(Ljava/lang/String;)Ljava/lang/Object;

    .line 193
    .line 194
    .line 195
    move-result-object v0

    .line 196
    check-cast v0, Ljava/util/Collection;

    .line 197
    .line 198
    if-eqz v0, :cond_3

    .line 199
    .line 200
    invoke-virtual {p1, v0}, LT1/a$a;->m(Ljava/util/Collection;)LT1/a$a;

    .line 201
    .line 202
    .line 203
    :cond_3
    const-string v0, "http.protocol.cookie-policy"

    .line 204
    .line 205
    invoke-interface {p0, v0}, Lq2/d;->g(Ljava/lang/String;)Ljava/lang/Object;

    .line 206
    .line 207
    .line 208
    move-result-object p0

    .line 209
    check-cast p0, Ljava/lang/String;

    .line 210
    .line 211
    if-eqz p0, :cond_4

    .line 212
    .line 213
    invoke-virtual {p1, p0}, LT1/a$a;->g(Ljava/lang/String;)LT1/a$a;

    .line 214
    .line 215
    .line 216
    :cond_4
    invoke-virtual {p1}, LT1/a$a;->a()LT1/a;

    .line 217
    .line 218
    .line 219
    move-result-object p0

    .line 220
    return-object p0
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
.end method
