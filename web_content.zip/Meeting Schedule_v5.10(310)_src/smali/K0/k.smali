.class abstract LK0/k;
.super LL0/g;
.source "SourceFile"


# instance fields
.field final a:LL0/i;

.field final b:LE0/g;

.field final synthetic c:LK0/m;


# direct methods
.method constructor <init>(LK0/m;LL0/i;LE0/g;)V
    .locals 0

    .line 1
    iput-object p1, p0, LK0/k;->c:LK0/m;

    .line 2
    .line 3
    invoke-direct {p0}, LL0/g;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p2, p0, LK0/k;->a:LL0/i;

    .line 7
    .line 8
    iput-object p3, p0, LK0/k;->b:LE0/g;

    .line 9
    .line 10
    return-void
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
.end method


# virtual methods
.method public c(Landroid/os/Bundle;)V
    .locals 2

    .line 1
    iget-object p1, p0, LK0/k;->c:LK0/m;

    .line 2
    .line 3
    iget-object p1, p1, LK0/m;->a:LL0/t;

    .line 4
    .line 5
    if-eqz p1, :cond_0

    .line 6
    .line 7
    iget-object v0, p0, LK0/k;->b:LE0/g;

    .line 8
    .line 9
    invoke-virtual {p1, v0}, LL0/t;->r(LE0/g;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    iget-object p1, p0, LK0/k;->a:LL0/i;

    .line 13
    .line 14
    const/4 v0, 0x0

    .line 15
    new-array v0, v0, [Ljava/lang/Object;

    .line 16
    .line 17
    const-string v1, "onGetLaunchReviewFlowInfo"

    .line 18
    .line 19
    invoke-virtual {p1, v1, v0}, LL0/i;->d(Ljava/lang/String;[Ljava/lang/Object;)I

    .line 20
    .line 21
    .line 22
    return-void
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
.end method
