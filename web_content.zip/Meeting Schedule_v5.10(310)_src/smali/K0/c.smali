.class public interface abstract LK0/c;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Landroid/app/Activity;LK0/b;)LE0/f;
.end method

.method public abstract b()LE0/f;
.end method
