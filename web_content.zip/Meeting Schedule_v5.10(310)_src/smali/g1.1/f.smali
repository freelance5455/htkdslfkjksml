.class interface abstract Lg1/f;
.super Ljava/lang/Object;
.source "SourceFile"
