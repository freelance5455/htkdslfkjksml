.class abstract LA1/i;
.super LA1/h;
.source "SourceFile"
