.class abstract LA1/v;
.super LA1/u;
.source "SourceFile"
