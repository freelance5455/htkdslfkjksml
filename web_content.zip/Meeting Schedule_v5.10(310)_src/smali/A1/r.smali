.class abstract LA1/r;
.super LA1/q;
.source "SourceFile"
