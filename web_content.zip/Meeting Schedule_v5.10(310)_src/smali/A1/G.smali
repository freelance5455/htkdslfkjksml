.class abstract LA1/G;
.super LA1/F;
.source "SourceFile"
