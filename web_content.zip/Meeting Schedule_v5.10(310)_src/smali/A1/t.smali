.class abstract LA1/t;
.super LA1/s;
.source "SourceFile"
