.class public abstract LA1/m;
.super LA1/w;
.source "SourceFile"
