.class abstract LA1/u;
.super LA1/t;
.source "SourceFile"
