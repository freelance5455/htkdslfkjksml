.class public abstract LA1/C;
.super LA1/H;
.source "SourceFile"
