.class public abstract LA1/I;
.super LA1/L;
.source "SourceFile"
