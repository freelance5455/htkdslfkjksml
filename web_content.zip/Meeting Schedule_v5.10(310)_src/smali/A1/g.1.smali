.class public abstract LA1/g;
.super LA1/k;
.source "SourceFile"
