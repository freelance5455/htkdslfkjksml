.class abstract LA1/q;
.super LA1/p;
.source "SourceFile"
