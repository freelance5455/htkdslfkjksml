.class abstract LA1/L;
.super LA1/K;
.source "SourceFile"
