.class public Lf2/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Le2/e;
.implements Le2/a;
.implements Le2/b;


# static fields
.field public static final e:Lf2/j;

.field public static final f:Lf2/j;

.field public static final g:Lf2/j;


# instance fields
.field private final a:Ljavax/net/ssl/SSLSocketFactory;

.field private volatile b:Lf2/j;

.field private final c:[Ljava/lang/String;

.field private final d:[Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lf2/b;

    .line 2
    .line 3
    invoke-direct {v0}, Lf2/b;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lf2/g;->e:Lf2/j;

    .line 7
    .line 8
    new-instance v0, Lf2/c;

    .line 9
    .line 10
    invoke-direct {v0}, Lf2/c;-><init>()V

    .line 11
    .line 12
    .line 13
    sput-object v0, Lf2/g;->f:Lf2/j;

    .line 14
    .line 15
    new-instance v0, Lf2/h;

    .line 16
    .line 17
    invoke-direct {v0}, Lf2/h;-><init>()V

    .line 18
    .line 19
    .line 20
    sput-object v0, Lf2/g;->g:Lf2/j;

    .line 21
    .line 22
    return-void
    .line 23
    .line 24
    .line 25
    .line 26
.end method

.method public constructor <init>(Ljavax/net/ssl/SSLContext;Lf2/j;)V
    .locals 1

    .line 1
    const-string v0, "SSL context"

    invoke-static {p1, v0}, Ls2/a;->g(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljavax/net/ssl/SSLContext;

    invoke-virtual {p1}, Ljavax/net/ssl/SSLContext;->getSocketFactory()Ljavax/net/ssl/SSLSocketFactory;

    move-result-object p1

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0, v0, p2}, Lf2/g;-><init>(Ljavax/net/ssl/SSLSocketFactory;[Ljava/lang/String;[Ljava/lang/String;Lf2/j;)V

    return-void
.end method

.method public constructor <init>(Ljavax/net/ssl/SSLSocketFactory;[Ljava/lang/String;[Ljava/lang/String;Lf2/j;)V
    .locals 1

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    const-string v0, "SSL socket factory"

    invoke-static {p1, v0}, Ls2/a;->g(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljavax/net/ssl/SSLSocketFactory;

    iput-object p1, p0, Lf2/g;->a:Ljavax/net/ssl/SSLSocketFactory;

    .line 4
    iput-object p2, p0, Lf2/g;->c:[Ljava/lang/String;

    .line 5
    iput-object p3, p0, Lf2/g;->d:[Ljava/lang/String;

    if-eqz p4, :cond_0

    goto :goto_0

    .line 6
    :cond_0
    sget-object p4, Lf2/g;->f:Lf2/j;

    :goto_0
    iput-object p4, p0, Lf2/g;->b:Lf2/j;

    return-void
.end method

.method public static a()Lf2/g;
    .locals 3

    .line 1
    new-instance v0, Lf2/g;

    .line 2
    .line 3
    invoke-static {}, Lf2/e;->a()Ljavax/net/ssl/SSLContext;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    sget-object v2, Lf2/g;->f:Lf2/j;

    .line 8
    .line 9
    invoke-direct {v0, v1, v2}, Lf2/g;-><init>(Ljavax/net/ssl/SSLContext;Lf2/j;)V

    .line 10
    .line 11
    .line 12
    return-object v0
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
.end method
