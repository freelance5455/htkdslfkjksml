.class public interface abstract Lf2/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljavax/net/ssl/HostnameVerifier;


# virtual methods
.method public abstract a(Ljava/lang/String;[Ljava/lang/String;[Ljava/lang/String;)V
.end method
