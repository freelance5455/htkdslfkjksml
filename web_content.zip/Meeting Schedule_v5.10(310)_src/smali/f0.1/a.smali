.class public abstract Lf0/a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lf0/a$a;
    }
.end annotation


# static fields
.field public static final a:Lm0/a$g;

.field public static final b:Lm0/a$g;

.field private static final c:Lm0/a$a;

.field private static final d:Lm0/a$a;

.field public static final e:Lm0/a;

.field public static final f:Lm0/a;

.field public static final g:Lm0/a;

.field public static final h:Lh0/a;

.field public static final i:Lg0/a;

.field public static final j:Li0/a;


# direct methods
.method static constructor <clinit>()V
    .locals 6

    .line 1
    new-instance v0, Lm0/a$g;

    .line 2
    .line 3
    invoke-direct {v0}, Lm0/a$g;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lf0/a;->a:Lm0/a$g;

    .line 7
    .line 8
    new-instance v1, Lm0/a$g;

    .line 9
    .line 10
    invoke-direct {v1}, Lm0/a$g;-><init>()V

    .line 11
    .line 12
    .line 13
    sput-object v1, Lf0/a;->b:Lm0/a$g;

    .line 14
    .line 15
    new-instance v2, Lf0/e;

    .line 16
    .line 17
    invoke-direct {v2}, Lf0/e;-><init>()V

    .line 18
    .line 19
    .line 20
    sput-object v2, Lf0/a;->c:Lm0/a$a;

    .line 21
    .line 22
    new-instance v3, Lf0/f;

    .line 23
    .line 24
    invoke-direct {v3}, Lf0/f;-><init>()V

    .line 25
    .line 26
    .line 27
    sput-object v3, Lf0/a;->d:Lm0/a$a;

    .line 28
    .line 29
    sget-object v4, Lf0/b;->c:Lm0/a;

    .line 30
    .line 31
    sput-object v4, Lf0/a;->e:Lm0/a;

    .line 32
    .line 33
    new-instance v4, Lm0/a;

    .line 34
    .line 35
    const-string v5, "Auth.CREDENTIALS_API"

    .line 36
    .line 37
    invoke-direct {v4, v5, v2, v0}, Lm0/a;-><init>(Ljava/lang/String;Lm0/a$a;Lm0/a$g;)V

    .line 38
    .line 39
    .line 40
    sput-object v4, Lf0/a;->f:Lm0/a;

    .line 41
    .line 42
    new-instance v0, Lm0/a;

    .line 43
    .line 44
    const-string v2, "Auth.GOOGLE_SIGN_IN_API"

    .line 45
    .line 46
    invoke-direct {v0, v2, v3, v1}, Lm0/a;-><init>(Ljava/lang/String;Lm0/a$a;Lm0/a$g;)V

    .line 47
    .line 48
    .line 49
    sput-object v0, Lf0/a;->g:Lm0/a;

    .line 50
    .line 51
    sget-object v0, Lf0/b;->d:Lh0/a;

    .line 52
    .line 53
    sput-object v0, Lf0/a;->h:Lh0/a;

    .line 54
    .line 55
    new-instance v0, Ly0/d;

    .line 56
    .line 57
    invoke-direct {v0}, Ly0/d;-><init>()V

    .line 58
    .line 59
    .line 60
    sput-object v0, Lf0/a;->i:Lg0/a;

    .line 61
    .line 62
    new-instance v0, Lj0/h;

    .line 63
    .line 64
    invoke-direct {v0}, Lj0/h;-><init>()V

    .line 65
    .line 66
    .line 67
    sput-object v0, Lf0/a;->j:Li0/a;

    .line 68
    .line 69
    return-void
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
.end method
