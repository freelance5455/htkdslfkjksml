.class public interface abstract LX0/b;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(LX0/a;)V
.end method
