.class public abstract LT0/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LS0/a;
