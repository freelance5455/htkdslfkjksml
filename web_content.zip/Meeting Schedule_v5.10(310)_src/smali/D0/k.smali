.class public final LD0/k;
.super Lp0/a;
.source "SourceFile"


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "LD0/k;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final a:I

.field private final b:Ll0/b;

.field private final c:Lo0/u;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, LD0/l;

    .line 2
    .line 3
    invoke-direct {v0}, LD0/l;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, LD0/k;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 7
    .line 8
    return-void
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
.end method

.method public constructor <init>(I)V
    .locals 2

    .line 5
    new-instance p1, Ll0/b;

    const/16 v0, 0x8

    const/4 v1, 0x0

    invoke-direct {p1, v0, v1}, Ll0/b;-><init>(ILandroid/app/PendingIntent;)V

    invoke-direct {p0, p1, v1}, LD0/k;-><init>(Ll0/b;Lo0/u;)V

    return-void
.end method

.method constructor <init>(ILl0/b;Lo0/u;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Lp0/a;-><init>()V

    .line 2
    iput p1, p0, LD0/k;->a:I

    .line 3
    iput-object p2, p0, LD0/k;->b:Ll0/b;

    .line 4
    iput-object p3, p0, LD0/k;->c:Lo0/u;

    return-void
.end method

.method private constructor <init>(Ll0/b;Lo0/u;)V
    .locals 1

    const/4 p2, 0x1

    const/4 v0, 0x0

    .line 6
    invoke-direct {p0, p2, p1, v0}, LD0/k;-><init>(ILl0/b;Lo0/u;)V

    return-void
.end method


# virtual methods
.method public final b()Ll0/b;
    .locals 1

    .line 1
    iget-object v0, p0, LD0/k;->b:Ll0/b;

    .line 2
    .line 3
    return-object v0
    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
.end method

.method public final c()Lo0/u;
    .locals 1

    .line 1
    iget-object v0, p0, LD0/k;->c:Lo0/u;

    .line 2
    .line 3
    return-object v0
    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 4

    .line 1
    invoke-static {p1}, Lp0/c;->a(Landroid/os/Parcel;)I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x1

    .line 6
    iget v2, p0, LD0/k;->a:I

    .line 7
    .line 8
    invoke-static {p1, v1, v2}, Lp0/c;->f(Landroid/os/Parcel;II)V

    .line 9
    .line 10
    .line 11
    iget-object v1, p0, LD0/k;->b:Ll0/b;

    .line 12
    .line 13
    const/4 v2, 0x2

    .line 14
    const/4 v3, 0x0

    .line 15
    invoke-static {p1, v2, v1, p2, v3}, Lp0/c;->j(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    .line 16
    .line 17
    .line 18
    const/4 v1, 0x3

    .line 19
    iget-object v2, p0, LD0/k;->c:Lo0/u;

    .line 20
    .line 21
    invoke-static {p1, v1, v2, p2, v3}, Lp0/c;->j(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    .line 22
    .line 23
    .line 24
    invoke-static {p1, v0}, Lp0/c;->b(Landroid/os/Parcel;I)V

    .line 25
    .line 26
    .line 27
    return-void
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
.end method
