.class public interface abstract LD0/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/IInterface;


# virtual methods
.method public abstract K(Lcom/google/android/gms/common/api/Status;)V
.end method

.method public abstract i(Lcom/google/android/gms/common/api/Status;)V
.end method

.method public abstract k(Lcom/google/android/gms/common/api/Status;Lcom/google/android/gms/auth/api/signin/GoogleSignInAccount;)V
.end method

.method public abstract o(LD0/k;)V
.end method

.method public abstract r(Ll0/b;LD0/b;)V
.end method
