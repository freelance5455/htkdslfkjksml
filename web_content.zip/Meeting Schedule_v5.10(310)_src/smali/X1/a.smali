.class public LX1/a;
.super Lr2/f;
.source "SourceFile"


# direct methods
.method public constructor <init>(Lr2/e;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Lr2/f;-><init>(Lr2/e;)V

    .line 2
    .line 3
    .line 4
    return-void
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
.end method

.method public static i(Lr2/e;)LX1/a;
    .locals 1

    .line 1
    instance-of v0, p0, LX1/a;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    check-cast p0, LX1/a;

    .line 6
    .line 7
    return-object p0

    .line 8
    :cond_0
    new-instance v0, LX1/a;

    .line 9
    .line 10
    invoke-direct {v0, p0}, LX1/a;-><init>(Lr2/e;)V

    .line 11
    .line 12
    .line 13
    return-object v0
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
.end method

.method private q(Ljava/lang/String;Ljava/lang/Class;)La2/a;
    .locals 0

    .line 1
    const-class p2, La2/a;

    .line 2
    .line 3
    invoke-virtual {p0, p1, p2}, Lr2/f;->d(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, La2/a;

    .line 8
    .line 9
    return-object p1
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
.end method


# virtual methods
.method public j()LS1/a;
    .locals 2

    .line 1
    const-string v0, "http.auth.auth-cache"

    .line 2
    .line 3
    const-class v1, LS1/a;

    .line 4
    .line 5
    invoke-virtual {p0, v0, v1}, Lr2/f;->d(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    check-cast v0, LS1/a;

    .line 10
    .line 11
    return-object v0
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
.end method

.method public k()Lh2/f;
    .locals 2

    .line 1
    const-string v0, "http.cookie-origin"

    .line 2
    .line 3
    const-class v1, Lh2/f;

    .line 4
    .line 5
    invoke-virtual {p0, v0, v1}, Lr2/f;->d(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    check-cast v0, Lh2/f;

    .line 10
    .line 11
    return-object v0
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
.end method

.method public l()Lh2/h;
    .locals 2

    .line 1
    const-string v0, "http.cookie-spec"

    .line 2
    .line 3
    const-class v1, Lh2/h;

    .line 4
    .line 5
    invoke-virtual {p0, v0, v1}, Lr2/f;->d(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    check-cast v0, Lh2/h;

    .line 10
    .line 11
    return-object v0
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
.end method

.method public m()La2/a;
    .locals 2

    .line 1
    const-string v0, "http.cookiespec-registry"

    .line 2
    .line 3
    const-class v1, Lh2/j;

    .line 4
    .line 5
    invoke-direct {p0, v0, v1}, LX1/a;->q(Ljava/lang/String;Ljava/lang/Class;)La2/a;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    return-object v0
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
.end method

.method public n()LS1/f;
    .locals 2

    .line 1
    const-string v0, "http.cookie-store"

    .line 2
    .line 3
    const-class v1, LS1/f;

    .line 4
    .line 5
    invoke-virtual {p0, v0, v1}, Lr2/f;->d(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    check-cast v0, LS1/f;

    .line 10
    .line 11
    return-object v0
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
.end method

.method public o()LS1/g;
    .locals 2

    .line 1
    const-string v0, "http.auth.credentials-provider"

    .line 2
    .line 3
    const-class v1, LS1/g;

    .line 4
    .line 5
    invoke-virtual {p0, v0, v1}, Lr2/f;->d(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    check-cast v0, LS1/g;

    .line 10
    .line 11
    return-object v0
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
.end method

.method public p()Ld2/e;
    .locals 2

    .line 1
    const-string v0, "http.route"

    .line 2
    .line 3
    const-class v1, Ld2/b;

    .line 4
    .line 5
    invoke-virtual {p0, v0, v1}, Lr2/f;->d(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    check-cast v0, Ld2/e;

    .line 10
    .line 11
    return-object v0
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
.end method

.method public r()LR1/e;
    .locals 2

    .line 1
    const-string v0, "http.auth.proxy-scope"

    .line 2
    .line 3
    const-class v1, LR1/e;

    .line 4
    .line 5
    invoke-virtual {p0, v0, v1}, Lr2/f;->d(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    check-cast v0, LR1/e;

    .line 10
    .line 11
    return-object v0
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
.end method

.method public s()LT1/a;
    .locals 2

    .line 1
    const-string v0, "http.request-config"

    .line 2
    .line 3
    const-class v1, LT1/a;

    .line 4
    .line 5
    invoke-virtual {p0, v0, v1}, Lr2/f;->d(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    check-cast v0, LT1/a;

    .line 10
    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    sget-object v0, LT1/a;->r:LT1/a;

    .line 15
    .line 16
    :goto_0
    return-object v0
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
.end method

.method public t()LR1/e;
    .locals 2

    .line 1
    const-string v0, "http.auth.target-scope"

    .line 2
    .line 3
    const-class v1, LR1/e;

    .line 4
    .line 5
    invoke-virtual {p0, v0, v1}, Lr2/f;->d(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    check-cast v0, LR1/e;

    .line 10
    .line 11
    return-object v0
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
.end method
