# Smart Study AI v3.0 — Android Studio source

Gujarati-medium Std 9 study app starter with the previous Dark Neon Navy + Cyan + Purple visual style.

## Open and run
1. Extract `SmartStudyAI_v3.zip`.
2. Open the `SmartStudyAI_v3` folder in Android Studio.
3. Allow Gradle sync (Android Studio needs internet for the Android Gradle Plugin the first time).
4. Run on an Android device or emulator (Android 6.0+).

## Included
- Gujarati-medium home dashboard and subject navigation.
- Notes area for Science, Social Science, Maths and English.
- Local Classwork and Homework lists.
- 25-question chapter quiz flow with easy / medium / hard levels, randomized order, score and report card.
- Local question history to reduce repeats; when the local bank is exhausted, it resets so the app remains usable.
- Offline Smart Teacher sample explanations (not a full generative AI model).
- Live Teacher link area for a teacher-provided meeting/stream URL.
- LocalStorage persistence and JSON progress export.

## Important limitations
- No AI API key is needed because this build uses bundled notes, question bank and offline rules. It does **not** generate unlimited new AI questions or open a real live teacher automatically.
- The included quiz bank is a starter/demo bank. It currently contains 25 curated starter questions per subject and reuses the available bank after it is exhausted; the UI is configured for 25-question quizzes. Add at least 25 unique curriculum-verified questions for every chapter before classroom release.
- Notes are starter notes, not the complete official GSEB textbook/guide. Add teacher-verified chapter content in `app/src/main/assets/index.html` under the `notes` object.
- Real live teaching requires a teacher to publish a live meeting/stream link. The app stores and opens that link; it does not create a live broadcast service.
- User progress is stored on the device only. Realtime multi-device sync / teacher dashboard requires a backend such as Firebase or another hosted service.

## Customization
- Colors and layout are in the `<style>` section of `index.html`.
- Subject chapters are in the `subjects` object.
- Notes are in the `notes` object.
- Quiz questions are in the `bank` object. Question format: `[question, [four options], correctOptionIndex, level]`.
