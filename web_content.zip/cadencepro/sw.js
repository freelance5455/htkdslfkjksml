const C='cadencepro-v1',A=['./','./index.html','./manifest.webmanifest','./icon-192.png','./icon-512.png','./icon.svg','./pro.js'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(C).then(c=>c.addAll(A)));self.skipWaiting()});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==C).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
const r=e.request;if(r.method!=='GET')return;
const u=new URL(r.url);if(/goatcounter|zgo\.at/.test(u.host))return;
const page=r.mode==='navigate'||u.pathname.endsWith('/')||u.pathname.endsWith('index.html');
if(page){e.respondWith(fetch(r).then(res=>{const cp=res.clone();caches.open(C).then(c=>c.put(r,cp));return res}).catch(()=>caches.match(r).then(m=>m||caches.match('./index.html'))));return}
e.respondWith(caches.match(r).then(m=>m||fetch(r).then(res=>{const cp=res.clone();caches.open(C).then(c=>c.put(r,cp));return res}).catch(()=>caches.match('./index.html'))))});
