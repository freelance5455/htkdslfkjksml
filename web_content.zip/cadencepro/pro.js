(function(){
const $=s=>document.querySelector(s),E=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const NN=['Do','Do♯','Ré','Ré♯','Mi','Fa','Fa♯','Sol','Sol♯','La','La♯','Si'],NM=['Do','Ré','Mi','Fa','Sol','La','Si'];
const INS={trompette:['Trompette, cornet, clairon (Si♭)',2,'sol'],euph:['Euphonium, baryton (Si♭)',2,'sol'],trombone:['Trombone (Do)',0,'fa'],tuba:['Tuba, basse (Do)',0,'fa'],sax:['Saxophone alto (Mi♭)',9,'sol'],autre:['Autre instrument (Do)',0,'sol']};
let PR={name:'',inst:'trompette',a4:440,off:80,xp:0,streak:0,last:'',st:{rh:{},ear:{},rd:{}},tun:0};
try{const o=JSON.parse(localStorage.getItem('cadencepro')||'{}');PR=Object.assign(PR,o);PR.st=Object.assign({rh:{},ear:{},rd:{}},o.st||{})}catch(e){}
const sv=()=>{try{localStorage.setItem('cadencepro',JSON.stringify(PR))}catch(e){}};
const ds=d=>d.getFullYear()+'-'+d.getMonth()+'-'+d.getDate();
function act(){const t=new Date(),y=new Date(t.getFullYear(),t.getMonth(),t.getDate()-1);if(PR.last===ds(t)){sv();return}PR.streak=PR.last===ds(y)?PR.streak+1:1;PR.last=ds(t);sv()}
const stars=k=>Object.values(PR.st[k]||{}).reduce((a,b)=>a+b,0);
const XP=()=>P.read.length*20+P.best*10+PR.xp;
const RANKS=[[0,'Apprenti'],[100,'Musicien'],[300,'Instrumentiste'],[700,'Soliste'],[1400,'Chef de pupitre'],[2500,'Maître de fanfare']];
function rank(){const x=XP();let i=0;RANKS.forEach((r,k)=>{if(x>=r[0])i=k});const nx=RANKS[i+1];return{name:RANKS[i][1],next:nx?nx[0]:null,nname:nx?nx[1]:'',lo:RANKS[i][0],x}}
const star=n=>'★'.repeat(n)+'☆'.repeat(3-n);

/* ---------- styles ---------- */
const st=document.createElement('style');st.textContent=`
.hub{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:10px 0}.hub button{display:flex;flex-direction:column;align-items:flex-start;gap:4px;text-align:left;background:var(--card);color:var(--ink);border:1px solid var(--line);border-radius:18px;padding:14px;min-height:112px;box-shadow:0 8px 18px -14px rgba(10,27,56,.6)}
.hub b{font-family:"Playfair Display",Georgia,serif;font-size:18px}.hub .ic{font-size:28px}.hub small{color:var(--mute);font-weight:600}
.tn{font:800 78px/1 "Playfair Display",Georgia,serif;text-align:center;margin:8px 0}.tn sub{font-size:26px}
.tm{text-align:center;font-weight:700;min-height:26px}.gauge{position:relative;height:16px;border-radius:9px;background:linear-gradient(90deg,#d1342f,#f2b705 35%,#2e9b57 50%,#f2b705 65%,#d1342f);margin:14px 4px}
.gauge i{position:absolute;top:-6px;left:50%;width:6px;height:28px;border-radius:3px;background:var(--ink);transform:translateX(-50%);transition:left .12s}
.row2{display:flex;align-items:center;justify-content:center;gap:12px;margin-top:10px}.row2 button{width:42px;height:42px;min-height:0;padding:0;border-radius:50%}
.lv{display:flex;align-items:center;justify-content:space-between;gap:8px;width:100%;text-align:left;background:var(--card);color:var(--ink);border:1px solid var(--line);border-radius:14px;margin:8px 0;padding:12px 16px}
.st{color:#E0A100;letter-spacing:2px;font-size:18px}
.track{position:relative;height:64px;border-radius:12px;background:var(--soft,#E4F2EA);border:1px solid var(--line);overflow:hidden;margin:12px 0}
.track .g1{position:absolute;top:0;bottom:0;width:1px;background:var(--line)}.track .g4{position:absolute;top:0;bottom:0;width:3px;background:var(--mute);opacity:.5}
.track .mk{position:absolute;top:14px;width:20px;height:36px;margin-left:-10px;border-radius:6px;background:var(--gold,#D4A52C);border:2px solid var(--ink);opacity:.9}.track .mk.ok{background:#2e9b57}.track .mk.no{background:#d1342f}
.track .ph{position:absolute;top:0;bottom:0;width:3px;background:var(--red,#C23B32);left:0}
.pad{display:flex;align-items:center;justify-content:center;height:190px;border-radius:26px;background:linear-gradient(160deg,#1B4283,#0A1B38);color:#fff;font:800 44px "Playfair Display",Georgia,serif;border-bottom:6px solid var(--gold,#D4A52C);touch-action:manipulation;user-select:none}.pad:active{transform:scale(.98)}
.fb{text-align:center;font:800 22px "Playfair Display",Georgia,serif;min-height:32px;margin:8px 0}
.stf{background:#fff;border-radius:16px;border:1px solid var(--line);padding:6px;margin:8px 0}
.ch{display:grid;grid-template-columns:repeat(2,1fr);gap:8px;margin:8px 0}.ch button{background:var(--bg);color:var(--ink);border:2px solid var(--line)}
.ch.n7{grid-template-columns:repeat(4,1fr)}.ch button.good{border-color:#2e9b57;background:#d6f1e0;color:#0b5d33}.ch button.bad{border-color:#d1342f;background:#fde4e2;color:#a3242a}
.xb{height:10px;border-radius:6px;background:rgba(255,255,255,.18);overflow:hidden;margin:8px 0}.xb i{display:block;height:100%;background:linear-gradient(90deg,#F2B705,#ffe27a);border-radius:6px}
.cert{display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid var(--line)}.cert:last-child{border:0}.cert .gr{flex:1}.cert small{display:block;color:var(--mute);font-weight:600}
.lock{opacity:.5}#cm{position:fixed;inset:0;z-index:50;background:rgba(5,12,28,.92);display:flex;flex-direction:column;align-items:center;justify-content:center;padding:14px;gap:10px}#cm img{max-width:100%;max-height:68%;border-radius:8px}
select{width:100%;font:700 16px Nunito,sans-serif;color:var(--ink);background:var(--bg);border:2px solid var(--line);border-radius:12px;padding:11px 12px;margin:4px 0 8px;min-height:46px}
`;document.head.appendChild(st);

/* ---------- audio ---------- */
const hz=m=>PR.a4*Math.pow(2,(m-69)/12);
function click2(t,acc){const c=ac(),o=c.createOscillator(),g=c.createGain();o.type='square';o.frequency.value=acc?1400:900;g.gain.setValueAtTime(.001,t);g.gain.exponentialRampToValueAtTime(.2,t+.003);g.gain.exponentialRampToValueAtTime(.001,t+.06);o.connect(g);g.connect(c.destination);o.start(t);o.stop(t+.08)}
function pitch(m,d,when){const c=ac(),o=c.createOscillator(),f=c.createBiquadFilter(),g=c.createGain(),t=when||c.currentTime;o.type='sawtooth';o.frequency.value=hz(m);f.type='lowpass';f.frequency.value=1700;g.gain.setValueAtTime(.001,t);g.gain.linearRampToValueAtTime(.22,t+.05);g.gain.exponentialRampToValueAtTime(.001,t+d);o.connect(f);f.connect(g);g.connect(c.destination);o.start(t);o.stop(t+d+.05)}

/* ---------- accordeur (YIN) ---------- */
function yin(buf,sr){const W=buf.length>>1,tmax=Math.min(W-1,Math.floor(sr/55)),tmin=Math.max(2,Math.floor(sr/1600));let r=0;for(let i=0;i<buf.length;i++)r+=buf[i]*buf[i];if(Math.sqrt(r/buf.length)<.008)return -1;
const d=new Float32Array(tmax+2);for(let t=1;t<=tmax;t++){let s=0;for(let j=0;j<W;j++){const x=buf[j]-buf[j+t];s+=x*x}d[t]=s}
const n=new Float32Array(tmax+2);n[0]=1;let run=0;for(let t=1;t<=tmax;t++){run+=d[t];n[t]=run?d[t]*t/run:1}
let tau=-1;for(let t=tmin;t<tmax;t++){if(n[t]<.12){while(t+1<tmax&&n[t+1]<n[t])t++;tau=t;break}}if(tau<0)return -1;
const a=n[tau-1],b=n[tau],c=n[tau+1],den=a+c-2*b,sh=den?(a-c)/(2*den):0;return sr/(tau+sh)}
function note(f){const trans=INS[PR.inst][1],m=69+12*Math.log2(f/PR.a4)+trans,wm=Math.round(m);return{name:NN[((wm%12)+12)%12],oct:Math.floor(wm/12)-1,cents:(m-wm)*100}}
let TU=null;
function stopT(){if(!TU)return;clearInterval(TU.iv);try{TU.stream.getTracks().forEach(t=>t.stop())}catch(e){}try{TU.src.disconnect()}catch(e){}TU=null}
async function startT(){const b=$('#tgo'),msg=$('#tcents');try{if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia)throw 0;const stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:false,noiseSuppression:false,autoGainControl:false}});const c=ac();await c.resume();const src=c.createMediaStreamSource(stream),an=c.createAnalyser();an.fftSize=4096;src.connect(an);const buf=new Float32Array(4096),hist=[];
TU={stream,src,iv:setInterval(()=>{an.getFloatTimeDomainData(buf);const f=yin(buf,c.sampleRate);if(f<0){hist.length=0;$('#tnote').innerHTML='–';$('#tcents').textContent='Jouez une note longue';$('#tgm').style.left='50%';$('#tfreq').textContent='';return}
hist.push(f);if(hist.length>5)hist.shift();const s=hist.slice().sort((x,y)=>x-y),fm=s[s.length>>1],n=note(fm),cc=Math.round(n.cents);
$('#tnote').innerHTML=`${n.name}<sub>${n.oct}</sub>`;$('#tgm').style.left=(50+Math.max(-50,Math.min(50,n.cents)))+'%';$('#tfreq').textContent=fm.toFixed(1)+' Hz';
const e=$('#tcents');e.textContent=Math.abs(cc)<=5?'Juste ✓':cc<0?`Trop bas (${cc}) · montez`:`Trop haut (+${cc}) · descendez`;e.style.color=Math.abs(cc)<=5?'#2e9b57':'inherit'},90)};
b.textContent='Arrêter le micro';b.dataset.p='tstop';if(!PR.tun){PR.xp+=10}PR.tun=(PR.tun||0)+1;act();sv()}catch(e){msg.textContent='Le micro n’est pas autorisé. Autorisez le micro pour ce site dans Chrome, puis réessayez.'}}

/* ---------- rythme ---------- */
const RL=[{n:'Niveau 1 · Noires',bpm:70,p:[0,1,2,3]},{n:'Niveau 2 · Noires et croches',bpm:74,p:[0,1,2,2.5,3]},{n:'Niveau 3 · Croches',bpm:78,p:[0,.5,1,2,2.5,3]},{n:'Niveau 4 · Contretemps',bpm:80,p:[0,1.5,2,3.5]},{n:'Niveau 5 · Syncopes',bpm:86,p:[0,.5,1.5,2,3,3.5]}];
function scoreRhythm(exp,taps){const used=new Set();let pts=0;for(const e of exp){let best=-1,bd=1e9;taps.forEach((t,i)=>{if(used.has(i))return;const d=Math.abs(t-e);if(d<bd){bd=d;best=i}});if(best>=0&&bd<=.21){used.add(best);pts+=bd<=.07?1:bd<=.13?.7:.4}}
const extra=taps.length-used.size;return Math.max(0,pts/exp.length-Math.min(.3,extra*.04))}
const starsOf=(a,t)=>a>=t[2]?3:a>=t[1]?2:a>=t[0]?1:0;
let RS=null;
function stopR(){if(RS&&RS.raf)cancelAnimationFrame(RS.raf);RS=null}
function rhythmMenu(){return `<button class="alt" data-p="hub">← Atelier</button><h2 style="margin:12px 0 4px">Jeu de rythme</h2><p class="mute">Écoutez le clic, puis tapez sur le pad au bon moment. 4 temps pour vous préparer, puis 2 mesures à jouer.</p>`+RL.map((l,i)=>`<button class="lv" data-p="rstart" data-i="${i}"><span><b>${l.n}</b><br><small class="mute">${l.bpm} battements/min</small></span><span class="st">${star(PR.st.rh[i]||0)}</span></button>`).join('')}
function rhythmRun(){const L=RL[RS.lvl];let mk='',g='';for(let b=0;b<8;b++)g+=`<div class="${b%4?'g1':'g4'}" style="left:${b/8*100}%"></div>`;RS.exp.forEach((e,i)=>{const bt=e/RS.beat-4;mk+=`<div class="mk" id="mk${i}" style="left:${bt/8*100+1.5}%"></div>`});
return `<button class="alt" data-p="rmenu">← Niveaux</button><h2 style="margin:12px 0 4px">${L.n}</h2><div class="fb" id="rct">Prêt…</div><div class="track">${g}${mk}<div class="ph" id="rph"></div></div><div class="pad" id="rpad">TAP</div><div class="fb" id="rfb"></div>`}
function rStart(li){stopR();const c=ac();try{c.resume()}catch(e){}const L=RL[li],beat=60/L.bpm,t0=c.currentTime+.5;RS={lvl:li,beat,t0,taps:[],exp:[],raf:0,done:false};for(let m=0;m<2;m++)for(const p of L.p)RS.exp.push((4+m*4+p)*beat);for(let i=0;i<12;i++)click2(t0+i*beat,i%4===0);$('#v').innerHTML=rhythmRun();RS.raf=requestAnimationFrame(rLoop)}
function rLoop(){if(!RS||RS.done)return;const b=(ac().currentTime-RS.t0)/RS.beat,ph=$('#rph'),ct=$('#rct');if(ph)ph.style.left=Math.max(0,Math.min(100,(b-4)/8*100))+'%';if(ct&&!RS.done)ct.textContent=b<0?'Prêt…':b<4?String(Math.floor(b)+1):'Jouez !';if(b>=12.7)return rFinish();RS.raf=requestAnimationFrame(rLoop)}
function rTap(){if(!RS||RS.done)return;const tt=ac().currentTime-PR.off/1000-RS.t0;if(tt<RS.beat*3.4)return;RS.taps.push(tt);let bi=0,bd=1e9;RS.exp.forEach((e,i)=>{const d=Math.abs(tt-e);if(d<bd){bd=d;bi=i}});const f=$('#rfb'),m=$('#mk'+bi);if(f)f.textContent=bd<=.07?'Parfait !':bd<=.13?'Bien':bd<=.21?(tt<RS.exp[bi]?'Un peu tôt':'Un peu tard'):'Hors rythme';if(m)m.className='mk '+(bd<=.21?'ok':'no')}
function rFinish(){RS.done=true;const a=scoreRhythm(RS.exp,RS.taps),s=starsOf(a,[.45,.7,.9]),li=RS.lvl;if(s>(PR.st.rh[li]||0))PR.st.rh[li]=s;PR.xp+=s*10;act();sv();
$('#v').innerHTML=`<h2>${RL[li].n}</h2><div class="card" style="text-align:center"><div class="st" style="font-size:42px">${star(s)}</div><h2>${Math.round(a*100)} %</h2><p>${s===3?'Magnifique, vous êtes dans le tempo !':s>=1?'Bien joué. Rejouez pour gagner une étoile.':'Écoutez bien le clic et réessayez.'}</p><div class="btns"><button data-p="rstart" data-i="${li}">Rejouer</button><button class="alt" data-p="rmenu">Niveaux</button></div></div>`}

/* ---------- oreille : intervalles ---------- */
const IV={2:'Seconde',4:'Tierce',5:'Quarte',7:'Quinte',9:'Sixte',11:'Septième',12:'Octave'};
const EL=[{n:'Niveau 1 · Tierce, quinte, octave',iv:[4,7,12]},{n:'Niveau 2 · + seconde et quarte',iv:[2,4,5,7,12]},{n:'Niveau 3 · Tous les intervalles',iv:[2,4,5,7,9,11,12]}];
let ES=null;
function eMenu(){return `<button class="alt" data-p="hub">← Atelier</button><h2 style="margin:12px 0 4px">Oreille : les intervalles</h2><p class="mute">Écoutez deux notes qui montent, puis trouvez la distance entre elles. 10 questions par niveau.</p>`+EL.map((l,i)=>`<button class="lv" data-p="estart" data-i="${i}"><span><b>${l.n}</b></span><span class="st">${star(PR.st.ear[i]||0)}</span></button>`).join('')}
function ePlay(){const c=ac();try{c.resume()}catch(e){}const t=c.currentTime+.05;pitch(ES.cur.b,.8,t);pitch(ES.cur.b+ES.cur.iv,.9,t+.85)}
function eView(){const q=ES.cur;if(ES.q>=10)return eEnd();return `<button class="alt" data-p="emenu">← Niveaux</button><div class="card" style="margin-top:12px;text-align:center"><p class="mute">Question ${ES.q+1} sur 10 · Score ${ES.sc}</p><button data-p="eplay">🔊 Réécouter</button><div class="ch">${EL[ES.lvl].iv.map(v=>`<button data-p="eans" data-v="${v}">${IV[v]}</button>`).join('')}</div><div class="fb" id="efb"></div></div>`}
function eNext(){const L=EL[ES.lvl],iv=L.iv[Math.random()*L.iv.length|0];ES.cur={iv,b:60+(Math.random()*8|0)};ES.lock=false;$('#v').innerHTML=eView();if(ES.q<10)setTimeout(ePlay,250)}
function eEnd(){const s=starsOf(ES.sc,[5,7,9]),li=ES.lvl;if(s>(PR.st.ear[li]||0))PR.st.ear[li]=s;PR.xp+=s*10;act();sv();return `<h2>${EL[li].n}</h2><div class="card" style="text-align:center"><div class="st" style="font-size:42px">${star(s)}</div><h2>${ES.sc} / 10</h2><div class="btns"><button data-p="estart" data-i="${li}">Rejouer</button><button class="alt" data-p="emenu">Niveaux</button></div></div>`}

/* ---------- lecture de notes ---------- */
const CLF={sol:{bot:30,ld:32,l:'G',lv:[[30,38],[28,41]]},fa:{bot:18,ld:24,l:'F',lv:[[18,26],[16,29]]}};
let RD=null;
function stopD(){if(RD&&RD.iv)clearInterval(RD.iv);RD=null}
function staff(D,clef){const c=CLF[clef],yb=112,sp=7,y=d=>yb-(d-c.bot)*sp;let s=`<svg viewBox="0 0 260 176" width="100%" role="img" aria-label="Une note sur la portée">`;for(let k=0;k<5;k++)s+=`<line x1="14" x2="246" y1="${yb-k*2*sp}" y2="${yb-k*2*sp}" stroke="#333" stroke-width="1.4"/>`;
const st=D-c.bot;if(st<0)for(let k=-2;k>=st-(st%2?1:0)&&k>=st-1;k-=2)s+=`<line x1="108" x2="152" y1="${yb-k*sp}" y2="${yb-k*sp}" stroke="#333" stroke-width="1.6"/>`;
if(st>8)for(let k=10;k<=st;k+=2)s+=`<line x1="108" x2="152" y1="${yb-k*sp}" y2="${yb-k*sp}" stroke="#333" stroke-width="1.6"/>`;
s+=`<circle cx="42" cy="${y(c.ld)}" r="15" fill="none" stroke="#0F2A5C" stroke-width="2.4"/><text x="42" y="${y(c.ld)+6}" text-anchor="middle" font-family="Georgia,serif" font-weight="700" font-size="19" fill="#0F2A5C">${c.l}</text>`;
s+=`<ellipse cx="130" cy="${y(D)}" rx="10" ry="7" fill="#C23B32" transform="rotate(-18 130 ${y(D)})"/></svg>`;return s}
function rdNext(){const c=CLF[RD.clef],r=c.lv[RD.lv];let d;do{d=r[0]+(Math.random()*(r[1]-r[0]+1)|0)}while(d===RD.cur&&r[1]>r[0]);RD.cur=d;RD.lock=false}
function rdView(){return `<div class="card" style="text-align:center;margin-top:0"><p class="mute">⏱ <b id="rdt">${RD.t}</b> s · Score <b id="rds">${RD.sc}</b></p><div class="stf" id="rdst">${staff(RD.cur,RD.clef)}</div><div class="ch n7">${NM.map((n,i)=>`<button data-p="rans" data-n="${i}">${n}</button>`).join('')}</div></div>`}
function rdStart(clef,lv){stopD();RD={clef,lv,t:60,sc:0,cur:-1};rdNext();$('#v').innerHTML=`<button class="alt" data-p="rdmenu">← Retour</button><div style="height:10px"></div>`+rdView();RD.iv=setInterval(()=>{RD.t--;const e=$('#rdt');if(e)e.textContent=RD.t;if(RD.t<=0){clearInterval(RD.iv);rdEnd()}},1000)}
function rdEnd(){const k=RD.clef+RD.lv,th=RD.lv?[6,11,16]:[8,14,20],s=starsOf(RD.sc,th);if(s>(PR.st.rd[k]||0))PR.st.rd[k]=s;PR.xp+=s*10;act();sv();const sc=RD.sc,cl=RD.clef,lv=RD.lv;$('#v').innerHTML=`<h2>Temps écoulé !</h2><div class="card" style="text-align:center"><div class="st" style="font-size:42px">${star(s)}</div><h2>${sc} notes justes</h2><div class="btns"><button data-p="rdstart" data-c="${cl}" data-l="${lv}">Rejouer</button><button class="alt" data-p="rdmenu">Retour</button></div></div>`}
function rdMenu(){const mk=(c,l,t)=>`<button class="lv" data-p="rdstart" data-c="${c}" data-l="${l}"><span><b>${t}</b></span><span class="st">${star(PR.st.rd[c+l]||0)}</span></button>`;return `<button class="alt" data-p="hub">← Atelier</button><h2 style="margin:12px 0 4px">Lecture de notes</h2><p class="mute">60 secondes : nommez le plus de notes possible.</p><h3 style="margin:12px 0 0">Clé de sol</h3>${mk('sol',0,'Sur la portée')}${mk('sol',1,'Avec lignes supplémentaires')}<h3 style="margin:12px 0 0">Clé de fa</h3>${mk('fa',0,'Sur la portée')}${mk('fa',1,'Avec lignes supplémentaires')}<p class="mute">Votre instrument (${E(INS[PR.inst][0])}) lit plutôt la clé de ${INS[PR.inst][2]}.</p>`}

/* ---------- certificats ---------- */
const CERTS=[['theo1','Théorie · Niveau 1','Lire 8 leçons et obtenir 8/10 au quiz',()=>P.read.length>=8&&P.best>=8],['theo2','Théorie · Niveau 2','Lire toutes les leçons et obtenir 9/10 au quiz',()=>P.read.length>=LESSONS.length&&P.best>=9],['rhy','Maître du rythme','Obtenir 9 étoiles au jeu de rythme',()=>stars('rh')>=9],['ear','Oreille musicale','Obtenir 6 étoiles aux intervalles',()=>stars('ear')>=6],['rdg','Lecteur de notes','Obtenir 4 étoiles en lecture de notes',()=>stars('rd')>=4]];
CERTS.push(['all','Musicien complet','Obtenir les cinq autres certificats',()=>CERTS.slice(0,5).every(c=>c[3]())]);
function certBlob(c,cb){const W=1100,H=780,cv=document.createElement('canvas');cv.width=W;cv.height=H;const g=cv.getContext('2d');
const draw=img=>{g.fillStyle='#fffbef';g.fillRect(0,0,W,H);g.strokeStyle='#C9962B';g.lineWidth=14;g.strokeRect(30,30,W-60,H-60);g.lineWidth=3;g.strokeRect(54,54,W-108,H-108);g.textAlign='center';
if(img)g.drawImage(img,W/2-62,82,124,124);g.fillStyle='#0F2A5C';g.font='700 58px Georgia,serif';g.fillText('CERTIFICAT',W/2,262);g.fillStyle='#8a6a1a';g.font='italic 26px Georgia,serif';g.fillText('Cadence Pro · École de la fanfare',W/2,304);
g.fillStyle='#444';g.font='26px Georgia,serif';g.fillText('est décerné à',W/2,366);g.fillStyle='#0F2A5C';g.font='italic 700 62px Georgia,serif';g.fillText(PR.name||'Un musicien',W/2,444);
g.fillStyle='#444';g.font='26px Georgia,serif';g.fillText('pour avoir réussi',W/2,500);g.fillStyle='#C23B32';g.font='700 44px Georgia,serif';g.fillText(c[1],W/2,562);g.fillStyle='#666';g.font='italic 22px Georgia,serif';g.fillText(c[2],W/2,604);
g.fillStyle='#444';g.font='22px Georgia,serif';g.fillText(new Date().toLocaleDateString('fr-FR',{day:'numeric',month:'long',year:'numeric'}),230,690);g.fillText('Cadence Pro',W-230,690);g.fillRect(130,664,200,2);g.fillRect(W-330,664,200,2);
g.fillStyle='#C9962B';g.beginPath();g.arc(W/2,672,48,0,7);g.fill();g.fillStyle='#fffbef';g.font='700 44px Georgia,serif';g.fillText('★',W/2,688);cv.toBlob(cb,'image/png')};
const im=new Image();im.onload=()=>draw(im);im.onerror=()=>draw(null);im.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(logo(120).replace('<svg ','<svg xmlns="http://www.w3.org/2000/svg" '))}
function showCert(i){const c=CERTS[i];certBlob(c,b=>{const u=URL.createObjectURL(b),d=document.createElement('div');d.id='cm';d.innerHTML=`<img src="${u}" alt="Certificat"><div class="btns" style="width:100%;max-width:420px"><button id="cshare">Partager</button><button class="alt" id="cdl" style="color:#fff">Télécharger</button><button class="alt" id="cclose" style="color:#fff">Fermer</button></div>`;document.body.appendChild(d);
const f=new File([b],'certificat-cadence-pro.png',{type:'image/png'});$('#cclose').onclick=()=>{d.remove();URL.revokeObjectURL(u)};$('#cdl').onclick=()=>{const a=document.createElement('a');a.href=u;a.download='certificat-cadence-pro.png';a.click()};
$('#cshare').onclick=()=>{if(navigator.canShare&&navigator.canShare({files:[f]}))navigator.share({files:[f],title:'Mon certificat Cadence Pro'}).catch(()=>{});else $('#cdl').click()}})}
window.__certBlob=certBlob;

/* ---------- vues ---------- */
let SB=null;
const DAYS=['tuner','rhythm','ear','read'];
function homeV(){const r=rank(),pct=r.next?Math.round((r.x-r.lo)/(r.next-r.lo)*100):100,done=CERTS.filter(c=>c[3]()).length,un=LESSONS.findIndex((l,i)=>!P.read.includes(i)),dd=DAYS[Math.floor(Date.now()/864e5)%4],dn={tuner:'Accordez votre instrument',rhythm:'Un jeu de rythme',ear:'Reconnaître un intervalle',read:'Lire des notes en 60 s'}[dd];
return `<section class="hero">${logo(92)}<h1>Cadence <span style="color:#F2B705">Pro</span></h1><p><b>${r.name}</b> · ${r.x} points</p><div class="xb"><i style="width:${pct}%"></i></div><p style="font-size:14px">${r.next?`Encore ${r.next-r.x} points pour devenir ${r.nname}`:'Niveau maximum atteint !'}</p></section>
<div class="stats"><div><strong>🔥 ${PR.streak}</strong><span>jour${PR.streak>1?'s':''} de suite</span></div><div><strong>${done}/${CERTS.length}</strong><span>certificats</span></div><div><strong>${P.read.length}/${LESSONS.length}</strong><span>leçons lues</span></div></div>
<div class="card"><h3>Défi du jour</h3><p>${dn}</p><button data-p="daily" data-d="${dd}">Relever le défi</button></div>
${un>=0?`<div class="card"><h3>Prochaine leçon</h3><p>${LESSONS[un][0]}</p><button class="alt" data-tab="theorie">Ouvrir les leçons</button></div>`:''}`}
function hubV(){return `<h2 style="margin:6px 0">Atelier</h2><div class="hub"><button data-p="go" data-s="tuner"><span class="ic">🎯</span><b>Accordeur</b><small>Le micro écoute votre instrument</small></button><button data-p="go" data-s="rhythm"><span class="ic">🥁</span><b>Rythme</b><small>${star(Math.min(3,Math.floor(stars('rh')/5)))} · ${stars('rh')}/15 ★</small></button><button data-p="go" data-s="ear"><span class="ic">👂</span><b>Oreille</b><small>${stars('ear')}/9 ★</small></button><button data-p="go" data-s="read"><span class="ic">🎼</span><b>Lecture de notes</b><small>${stars('rd')}/12 ★</small></button><button data-p="go" data-s="quiz" style="grid-column:1/3;min-height:84px"><span class="ic">❓</span><b>Quiz de théorie</b><small>Meilleur score : ${P.best}/10</small></button></div>`}
function tunerV(){return `<button class="alt" data-p="hub">← Atelier</button><div class="card" style="margin-top:12px"><h2>Accordeur</h2><p class="mute">Instrument : <b>${E(INS[PR.inst][0])}</b> (à changer dans Profil). Jouez une note longue, près du téléphone.</p><div class="tn" id="tnote">–</div><div class="tm" id="tcents">Touchez le bouton pour démarrer</div><div class="gauge"><i id="tgm"></i></div><div class="mute" id="tfreq" style="text-align:center;min-height:20px"></div><div class="btns"><button id="tgo" data-p="tgo">Démarrer le micro</button></div><div class="row2"><span>La =</span><button data-p="a4" data-d="-1">−</button><b id="a4v">${PR.a4}</b><button data-p="a4" data-d="1">+</button><span>Hz</span></div></div><div class="card"><h3>Écouter une note de référence</h3><div class="btns"><button class="alt" data-p="ref" data-m="69">La</button><button class="alt" data-p="ref" data-m="70">Si♭</button><button class="alt" data-p="ref" data-m="60">Do</button><button class="alt" data-p="ref" data-m="65">Fa</button></div><p class="mute">Ces notes sont celles qui sonnent (hauteur réelle). Votre trompette en Si♭ joue un Do écrit pour faire sonner un Si♭.</p></div>`}
function defisV(){if(!SB)return hubV();if(SB==='tuner')return tunerV();if(SB==='quiz')return quiz();if(SB==='rhythm')return rhythmMenu();if(SB==='ear')return ES&&ES.on?eView():eMenu();if(SB==='read')return rdMenu();return hubV()}
function profilV(){const r=rank();return `<div class="card"><h3>Mon profil</h3><label for="pn">Mon nom (pour les certificats)</label><input id="pn" value="${E(PR.name)}" placeholder="Votre nom"><label for="pi">Mon instrument</label><select id="pi">${Object.keys(INS).map(k=>`<option value="${k}" ${k===PR.inst?'selected':''}>${E(INS[k][0])}</option>`).join('')}</select><label>Décalage audio du jeu de rythme : <b id="pov">${PR.off}</b> ms</label><div class="row2" style="justify-content:flex-start"><button data-p="off" data-d="-10">−</button><button data-p="off" data-d="10">+</button></div><p class="mute">Si vous êtes toujours en retard (ou en avance) sur les temps, changez ce réglage.</p></div>
<div class="card"><h3>${r.name} · ${r.x} points</h3><p class="mute">Série : ${PR.streak} jour${PR.streak>1?'s':''}. Gagnez des points avec les leçons, le quiz et les jeux.</p></div>
<div class="card"><h3>Mes certificats</h3>${CERTS.map((c,i)=>{const ok=c[3]();return `<div class="cert ${ok?'':'lock'}"><div class="gr"><b>${ok?'🏅':'🔒'} ${c[1]}</b><small>${c[2]}</small></div>${ok?`<button class="sm" data-p="cert" data-i="${i}" style="min-height:38px;padding:8px 14px">Voir</button>`:''}</div>`}).join('')}</div>
<div class="card"><h3>Sauvegarde</h3><p class="mute">Vos données sont sur ce téléphone.</p><div class="btns"><button data-p="exp">Sauvegarder</button><button class="alt" data-p="imp">Restaurer</button></div><input id="fi2" type="file" accept=".json,application/json" style="display:none"></div>`}

function stopAll(){stopT();stopR();stopD()}
window.render=function(){try{stopM()}catch(e){}try{stopB()}catch(e){}stopAll();nav();$('#v').innerHTML=({home:homeV,theorie,pratique,defis:defisV,profil:profilV}[tab]||homeV)();window.scrollTo(0,0)};
const _q=window.quiz;window.quiz=function(){return `<button class="alt" data-p="hub" style="margin-bottom:10px">← Atelier</button>`+_q()};
TABS.length=0;TABS.push(['home','Accueil'],['theorie','Leçons'],['pratique','Pratique'],['defis','Atelier'],['profil','Profil']);
ICON.defis='<path d="M12 3a9 9 0 100 18 9 9 0 000-18zM12 7v5l3 2"/>';ICON.profil='<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>';

document.addEventListener('click',e=>{const t=e.target.closest('[data-tab]');if(t&&t.dataset.tab==='defis'&&tab==='defis'){SB=null;ES=null}},true);
document.addEventListener('pointerdown',e=>{if(e.target.closest('#rpad')){e.preventDefault();rTap()}});
document.addEventListener('click',e=>{const t=e.target.closest('[data-p]');if(!t)return;const a=t.dataset.p,d=t.dataset;try{ac().resume()}catch(x){}
if(a==='hub'){SB=null;ES=null;render()}
else if(a==='go'){SB=d.s;ES=null;render()}
else if(a==='daily'){tab='defis';SB=d.d==='tuner'?'tuner':d.d==='rhythm'?'rhythm':d.d==='ear'?'ear':'read';render()}
else if(a==='tgo')startT();
else if(a==='tstop'){stopT();render()}
else if(a==='a4'){PR.a4=Math.max(430,Math.min(450,PR.a4+ +d.d));sv();$('#a4v').textContent=PR.a4}
else if(a==='ref'){pitch(+d.m,2.4)}
else if(a==='rmenu'){stopR();render()}
else if(a==='rstart')rStart(+d.i);
else if(a==='emenu'){ES=null;render()}
else if(a==='estart'){ES={lvl:+d.i,q:0,sc:0,on:true};eNext()}
else if(a==='eplay')ePlay();
else if(a==='eans'){if(ES.lock)return;ES.lock=true;const v=+d.v,ok=v===ES.cur.iv;if(ok)ES.sc++;document.querySelectorAll('.ch button').forEach(b=>{if(+b.dataset.v===ES.cur.iv)b.classList.add('good');else if(b===t)b.classList.add('bad')});$('#efb').textContent=ok?'Bravo !':'C’était : '+IV[ES.cur.iv];ES.q++;setTimeout(()=>{if(ES&&ES.on)eNext()},1300)}
else if(a==='rdmenu'){stopD();render()}
else if(a==='rdstart')rdStart(d.c,+d.l);
else if(a==='rans'){if(!RD||RD.lock||RD.t<=0)return;RD.lock=true;const ok=RD.cur%7===+d.n;if(ok)RD.sc++;const e2=$('#rds');if(e2)e2.textContent=RD.sc;t.classList.add(ok?'good':'bad');if(!ok)document.querySelectorAll('.ch button')[RD.cur%7].classList.add('good');setTimeout(()=>{if(!RD)return;rdNext();const s=$('#rdst');if(!s)return;s.innerHTML=staff(RD.cur,RD.clef);document.querySelectorAll('.ch button').forEach(b=>b.className='')},ok?160:700)}
else if(a==='off'){PR.off=Math.max(-100,Math.min(300,PR.off+ +d.d));sv();$('#pov').textContent=PR.off}
else if(a==='cert'){if(!PR.name){alert('Écrivez d’abord votre nom dans “Mon profil”.');return}showCert(+d.i)}
else if(a==='exp'){const b=new Blob([JSON.stringify({P,PR})],{type:'application/json'}),l=document.createElement('a');l.href=URL.createObjectURL(b);l.download='cadence-pro-sauvegarde-'+new Date().toISOString().slice(0,10)+'.json';l.click()}
else if(a==='imp')$('#fi2').click()});
document.addEventListener('input',e=>{if(e.target.id==='pn'){PR.name=e.target.value;sv()}});
document.addEventListener('change',e=>{const t=e.target;if(t.id==='pi'){PR.inst=t.value;sv()}
if(t.id==='fi2'&&t.files[0]){const r=new FileReader();r.onload=()=>{try{const o=JSON.parse(r.result);if(!o.P||!o.PR)throw 0;if(confirm('Remplacer vos données actuelles ?')){Object.assign(P,o.P);Object.assign(PR,o.PR);save();sv();render()}}catch(x){alert('Fichier non valide')}};r.readAsText(t.files[0])}});
window.__pro={yin,note,scoreRhythm,staff,CLF,PR:()=>PR,NM,RS:()=>RS,ES:()=>ES,RD:()=>RD,CERTS};
render();
})();
