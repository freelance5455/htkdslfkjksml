# Converter Notes

1. Entry file: `index.html`.
2. App name: `Scrap अड्डा`.
3. Use a square Scrap अड्डा logo as the app icon in the converter.
4. Enable camera and location permissions.
5. Keep JavaScript and DOM storage enabled.
6. Keep external HTTPS access enabled for map/directions resources.
7. The app is designed as a mobile-first offline-tolerant demo. The dummy dataset is included separately for the build/reference package.
8. Voice uses the HTML/browser/WebView speech path in the converter. A converter that disables Web Speech API may not provide voice; for native Android TTS use the separate Android project.
