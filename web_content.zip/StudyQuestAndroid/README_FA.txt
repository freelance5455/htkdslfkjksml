# Study Quest Android

نسخه Android از Study Quest فعلی.

## باز کردن
1. Android Studio را نصب کنید.
2. این پوشه را با File > Open باز کنید.
3. صبر کنید Gradle Sync تمام شود.
4. برای تست روی گوشی: Run ▶
5. برای APK: Build > Build APK(s)

## شناسه برنامه
com.studyquest.app

## نسخه
1.0.0

## نکته
این نسخه رابط و منطق فعلی Study Quest را داخل WebView اجرا می‌کند.
پرداخت واقعی، حساب کاربری، سرور، همگام‌سازی و اشتراک واقعی هنوز باید به بک‌اند/درگاه پرداخت متصل شوند.
