STUDYQUEST ANDROID PROJECT

This project wraps your existing studyquest_app.html file in an Android WebView app.

IMPORTANT
- This is an Android Studio project, not a prebuilt APK.
- The HTML uses online Tailwind CSS, Font Awesome, and Google Fonts, so an internet connection is needed for those resources to load.
- This wrapper does not add a real online multiplayer server or cloud account system. Any simulated game features remain simulated.

HOW TO MAKE AN APK
1. Install Android Studio on a computer from the official Android developer website.
2. Extract the StudyQuestAndroid ZIP.
3. Open Android Studio and choose Open, then select the StudyQuestAndroid folder.
4. Wait for Gradle sync to finish. If prompted, install the Android SDK/platform requested by Android Studio.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When it finishes, click the notification's Locate link to find the APK.
7. Transfer the APK to your Android phone and install it. You may need to allow installation from that file manager.

PLAY STORE NOTE
Publishing requires a Google Play Console developer account and compliance with Google's current testing, privacy, and app requirements. If you are under 18, ask a parent/guardian to handle the developer account and publishing steps.
