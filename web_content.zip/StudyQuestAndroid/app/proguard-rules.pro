# Study Quest release rules
