RAJA TRAVEL AGENCY LEDGER POS
==============================

Included:
- index.html: complete offline-first POS app (HTML/CSS/JavaScript in one file)
- README.txt: these instructions

HOW TO USE ON ANDROID WITH ACODE
1. Install/open Acode.
2. Create a folder named Raja_Travel_Agency_POS.
3. Create a file named index.html inside that folder.
4. Copy all contents of the supplied index.html into Acode and save.
5. Tap Preview (or use the menu -> Preview). If Preview is unavailable, open the file in Chrome using Acode's open-in-browser option.
6. Add a test ticket, then check Dashboard, Customers Ledger and Reports.
7. Open Backup & Restore and download a JSON backup regularly.

HOW TO USE ON A LAPTOP
1. Extract the ZIP file.
2. Double-click index.html to open it in Chrome, Edge or Firefox.
3. No internet connection is needed for normal local use.

IMPORTANT DATA NOTES
- Records are saved in browser localStorage on the current device/browser.
- Clearing browser/site data may delete records. Download backups regularly.
- Mobile and laptop do not synchronize automatically. Download backup on one device and restore it on the other.
- WhatsApp bill sharing opens WhatsApp/WhatsApp Web with a prepared message. You still press Send.
- This is a local ledger/POS tool, not an airline reservation or ticket issuance system.
- Estimated profit is ticket selling price minus purchase price, less recorded office expenses and refunds. Actual accounting may need additional adjustments.
- Test with sample data and restore a backup before relying on it for business records.
