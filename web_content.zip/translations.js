var ICONS={
 home:'M3 11l9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z',
 list:'M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01',
 plus:'M12 5v14M5 12h14',
 shield:'M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6zM9 12l2 2 4-4',
 search:'M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM21 21l-4.5-4.5',
 edit:'M4 20h4L19 9l-4-4L4 16z',
 trash:'M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13',
 back:'M15 5l-7 7 7 7',
 down:'M12 4v11m0 0l-4-4m4 4l4-4M5 20h14',
 up:'M12 20V9m0 0l-4 4m4-4l4 4M5 4h14',
 clock:'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 7v5l3 2',
 alert:'M12 4l9 16H3zM12 10v4M12 17h.01',
 box:'M3 7l9-4 9 4v10l-9 4-9-4zM3 7l9 4 9-4M12 11v10',
 lock:'M6 11h12v9H6zM8 11V8a4 4 0 0 1 8 0v3',
 check:'M5 12l5 5 9-10',
 settings:'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19 12a7 7 0 0 0-.1-1.2l2-1.5-2-3.4-2.3.9a7 7 0 0 0-2-1.2L14 3h-4l-.6 2.6a7 7 0 0 0-2 1.2l-2.3-.9-2 3.4 2 1.5a7 7 0 0 0 0 2.4l-2 1.5 2 3.4 2.3-.9a7 7 0 0 0 2 1.2L10 21h4l.6-2.6a7 7 0 0 0 2-1.2l2.3.9 2-3.4-2-1.5c.1-.4.1-.8.1-1.2z'
};
function ic(n){return '<svg viewBox="0 0 24 24"><path d="'+(ICONS[n]||'')+'"/></svg>';}

/* ---------- Translations ---------- */
var T={
bn:{
 tagline:'আপনার ওয়ারেন্টি, এক জায়গায় নিরাপদ',
 hTitle:'স্বাগতম 👋',hSub:'আপনার সব পণ্যের ওয়ারেন্টির হিসাব এখানে রাখুন।',
 navHome:'হোম',navList:'পণ্য',navAdd:'যোগ',navBackup:'ব্যাকআপ',
 total:'মোট পণ্য',active:'চালু ওয়ারেন্টি',expiring:'শীঘ্রই শেষ',expired:'মেয়াদ শেষ',
 soonTitle:'শীঘ্রই মেয়াদ শেষ হবে',soonNone:'আগামী ৩০ দিনে কোনো ওয়ারেন্টির মেয়াদ শেষ হচ্ছে না।',
 searchPh:'পণ্য, ব্র্যান্ড বা সিরিয়াল খুঁজুন',
 fAll:'সব',fActive:'চালু',fExpiring:'শীঘ্রই শেষ',fExpired:'মেয়াদ শেষ',
 empty:'কোনো পণ্য নেই',emptyHint:'প্রথম পণ্যটি যোগ করে ওয়ারেন্টি ট্র্যাক করা শুরু করুন।',noMatch:'কোনো মিল পাওয়া যায়নি',addFirst:'পণ্য যোগ করুন',
 addTitle:'নতুন পণ্য যোগ করুন',editTitle:'পণ্য সম্পাদনা করুন',
 lName:'পণ্যের নাম *',lBrand:'ব্র্যান্ড',lCat:'ক্যাটাগরি',lPurchase:'কেনার তারিখ *',lMonths:'ওয়ারেন্টির মেয়াদ (মাস) *',lExpiry:'মেয়াদ শেষের তারিখ (স্বয়ংক্রিয়)',lShop:'দোকানের নাম',lSerial:'সিরিয়াল নম্বর',lNotes:'নোট',
 save:'সংরক্ষণ করুন',update:'আপডেট করুন',cancel:'বাতিল',back:'ফিরে যান',
 cat_electronics:'ইলেকট্রনিক্স',cat_mobile:'মোবাইল ও গ্যাজেট',cat_appliance:'হোম অ্যাপ্লায়েন্স',cat_furniture:'ফার্নিচার',cat_vehicle:'যানবাহন',cat_other:'অন্যান্য',
 eName:'পণ্যের নাম লিখুন।',eDate:'সঠিক কেনার তারিখ দিন।',eMonths:'মাস ১ থেকে ১২০ এর মধ্যে একটি পূর্ণসংখ্যা হতে হবে।',
 sSaved:'পণ্য সংরক্ষিত হয়েছে',sUpdated:'পণ্য আপডেট হয়েছে',sDeleted:'পণ্য মুছে ফেলা হয়েছে',eStore:'সংরক্ষণ করা যায়নি। ব্রাউজারের স্টোরেজ বন্ধ বা পূর্ণ থাকতে পারে।',
 detMissing:'পণ্যটি পাওয়া যায়নি।',edit:'সম্পাদনা',del:'মুছুন',
 delTitle:'পণ্যটি মুছবেন?',delMsg:'"{n}" স্থায়ীভাবে মুছে যাবে। এটি আর ফেরত আনা যাবে না।',yesDel:'হ্যাঁ, মুছুন',
 left:'{n} দিন বাকি',today:'আজ মেয়াদ শেষ',ago:'{n} দিন আগে মেয়াদ শেষ',
 st_active:'চালু',st_expiring:'শীঘ্রই শেষ',st_expired:'মেয়াদ শেষ',monthsUnit:'মাস',
 bkTitle:'ব্যাকআপ ও রিস্টোর',bkHint:'আপনার সব তথ্য শুধু এই ফোনের ব্রাউজারে থাকে। ডেটা হারানো এড়াতে মাঝেমধ্যে ব্যাকআপ নিন।',
 exportBtn:'ব্যাকআপ ডাউনলোড (JSON)',importBtn:'ব্যাকআপ ফাইল ইমপোর্ট করুন',exported:'ব্যাকআপ ফাইল তৈরি হয়েছে',noData:'ব্যাকআপ নেওয়ার মতো কোনো পণ্য নেই।',
 impBad:'ফাইলটি সঠিক নয়। শুধু এই অ্যাপ থেকে নেওয়া JSON ব্যাকআপ ব্যবহার করুন।',impTitle:'ইমপোর্ট করবেন?',
 impMsg:'{n}টি সঠিক পণ্য পাওয়া গেছে{s}। একই আইডির পণ্য আপডেট হবে, বাকিগুলো যোগ হবে।',impSkip:' ({k}টি অবৈধ বলে বাদ গেছে)',yesImp:'হ্যাঁ, ইমপোর্ট করুন',impDone:'{n}টি পণ্য ইমপোর্ট হয়েছে',
 langTitle:'ভাষা',privTitle:'গোপনীয়তা',privText:'কোনো অ্যাকাউন্ট, সার্ভার বা অ্যানালিটিক্স নেই। আপনার তথ্য কোথাও পাঠানো হয় না — শুধু এই ডিভাইসের ব্রাউজারে থাকে।',
 disc:'এটি শুধু মনে রাখার সহায়ক অ্যাপ। ওয়ারেন্টি অনুমোদনের কোনো নিশ্চয়তা দেয় না। প্রকৃত শর্ত ও মেয়াদ বিক্রেতা বা প্রস্তুতকারকের ওয়ারেন্টি কার্ড দেখে নিশ্চিত করুন।'
},
en:{
 tagline:'Your warranties, safe in one place',
 hTitle:'Welcome 👋',hSub:'Keep track of all your product warranties here.',
 navHome:'Home',navList:'Products',navAdd:'Add',navBackup:'Backup',
 total:'Total products',active:'Active warranties',expiring:'Expiring soon',expired:'Expired',
 soonTitle:'Expiring soon',soonNone:'No warranty expires in the next 30 days.',
 searchPh:'Search product, brand or serial',
 fAll:'All',fActive:'Active',fExpiring:'Expiring',fExpired:'Expired',
 empty:'No products yet',emptyHint:'Add your first product to start tracking its warranty.',noMatch:'No matching products',addFirst:'Add product',
 addTitle:'Add new product',editTitle:'Edit product',
 lName:'Product name *',lBrand:'Brand',lCat:'Category',lPurchase:'Purchase date *',lMonths:'Warranty duration (months) *',lExpiry:'Expiry date (automatic)',lShop:'Shop name',lSerial:'Serial number',lNotes:'Notes',
 save:'Save',update:'Update',cancel:'Cancel',back:'Back',
 cat_electronics:'Electronics',cat_mobile:'Mobile & gadgets',cat_appliance:'Home appliance',cat_furniture:'Furniture',cat_vehicle:'Vehicle',cat_other:'Other',
 eName:'Please enter the product name.',eDate:'Please enter a valid purchase date.',eMonths:'Months must be a whole number from 1 to 120.',
 sSaved:'Product saved',sUpdated:'Product updated',sDeleted:'Product deleted',eStore:'Could not save. Browser storage may be disabled or full.',
 detMissing:'Product not found.',edit:'Edit',del:'Delete',
 delTitle:'Delete this product?',delMsg:'"{n}" will be permanently deleted. This cannot be undone.',yesDel:'Yes, delete',
 left:'{n} days left',today:'Expires today',ago:'Expired {n} days ago',
 st_active:'Active',st_expiring:'Expiring',st_expired:'Expired',monthsUnit:'months',
 bkTitle:'Backup & Restore',bkHint:'All your data stays only in this phone\'s browser. Take a backup now and then to avoid losing it.',
 exportBtn:'Download backup (JSON)',importBtn:'Import backup file',exported:'Backup file created',noData:'There are no products to back up.',
 impBad:'Invalid file. Please use a JSON backup exported from this app.',impTitle:'Import data?',
 impMsg:'Found {n} valid product(s){s}. Items with the same ID will be updated, others will be added.',impSkip:' ({k} invalid skipped)',yesImp:'Yes, import',impDone:'{n} product(s) imported',
 langTitle:'Language',privTitle:'Privacy',privText:'No account, no server, no analytics. Your data is never sent anywhere — it stays in this device\'s browser only.',
 disc:'This app is only a reminder tool and does not guarantee warranty approval. Confirm real terms and validity with the seller or the manufacturer\'s warranty card.'
}};

/* ---------- Constants ---------- */
var KEY='akashWarrantyKeeper.v1', LKEY='akashWarrantyKeeper.lang';
var CATS=['electronics','mobile','appliance','furniture','vehicle','other'];
var SOON_DAYS=30;
