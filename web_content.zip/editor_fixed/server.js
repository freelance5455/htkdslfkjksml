#!/usr/bin/env node
// ===== Editor Xbox by Laisy: servidor local =====
const http = require('http');
const net = require('net');
const fs = require('fs');
const path = require('path');

const PORT = 3360;
let cfg = null, client = null, chain = Promise.resolve();
const state = { assetsRoot: null };

class FtpError extends Error { constructor(code, msg) { super(msg); this.code = code; } }

// Cliente FTP mínimo (sem dependências)
class Ftp {
  constructor(c) { this.c = c; this.buf = ''; this.cur = []; this.multi = null; this.replies = []; this.waiters = []; this.closed = false; }
  connect() {
    return new Promise((resolve, reject) => {
      const s = this.sock = net.connect(this.c.port, this.c.host);
      s.setTimeout(30000, () => s.destroy(new Error('Tempo esgotado falando com o Xbox')));
      s.on('data', d => this._data(d));
      s.on('error', e => { this.closed = true; this._fail(e); reject(e); });
      s.on('close', () => { this.closed = true; this._fail(new Error('Conexão encerrada')); });
      this.reply().then(async r => {
        if (r.code !== 220) throw new FtpError(r.code, r.text);
        let u = await this.raw('USER ' + this.c.user);
        if (u.code === 331) u = await this.raw('PASS ' + this.c.pass);
        if (u.code >= 400) throw new FtpError(u.code, 'Usuário ou senha recusados');
        await this.raw('TYPE I');
        resolve();
      }).catch(reject);
    });
  }
  _fail(e) { this.waiters.splice(0).forEach(w => w.reject(e)); }
  _data(d) {
    this.buf += d.toString('latin1'); let i;
    while ((i = this.buf.indexOf('\n')) >= 0) {
      const l = this.buf.slice(0, i).replace(/\r$/, ''); this.buf = this.buf.slice(i + 1);
      if (this.multi) { this.cur.push(l); if (l.startsWith(this.multi + ' ')) this._done(this.multi); continue; }
      const m = /^(\d{3})([ -])/.exec(l); if (!m) continue;
      this.cur = [l]; if (m[2] === '-') this.multi = m[1]; else this._done(m[1]);
    }
  }
  _done(code) {
    const r = { code: +code, text: this.cur.join('\n') }; this.cur = []; this.multi = null;
    const w = this.waiters.shift(); if (w) w.resolve(r); else this.replies.push(r);
  }
  reply() {
    if (this.replies.length) return Promise.resolve(this.replies.shift());
    if (this.closed) return Promise.reject(new Error('Conexão encerrada'));
    return new Promise((resolve, reject) => this.waiters.push({ resolve, reject }));
  }
  async raw(cmd) { this.sock.write(cmd + '\r\n'); return this.reply(); }
  async cmd(cmd) { const r = await this.raw(cmd); if (r.code >= 400) throw new FtpError(r.code, r.text); return r; }
  async pasv() {
    const r = await this.raw('PASV');
    const m = /(\d+),(\d+),(\d+),(\d+),(\d+),(\d+)/.exec(r.text);
    if (r.code !== 227 || !m) throw new FtpError(r.code, 'PASV não suportado: ' + r.text);
    return new Promise((resolve, reject) => {
      const ds = net.connect(m[5] * 256 + +m[6], this.c.host, () => resolve(ds));
      ds.setTimeout(30000, () => ds.destroy()); ds.on('error', reject);
    });
  }
  async xfer(cmd, send) {
    const ds = await this.pasv(); const chunks = [];
    ds.removeAllListeners('error'); ds.on('error', () => {});
    ds.on('data', c => chunks.push(c)); const closed = new Promise(r => ds.on('close', r));
    try { await this.cmd(cmd); } catch (e) { ds.destroy(); throw e; }
    if (send) await new Promise(r => ds.end(send, r));
    await closed;
    const r = await this.reply(); if (r.code >= 400) throw new FtpError(r.code, r.text);
    return Buffer.concat(chunks);
  }
  async list(p) {
    try { await this.cmd('CWD ' + p); } catch (e) { if (e instanceof FtpError) return []; throw e; }
    let out; try { out = await this.xfer('LIST'); } catch (e) { if (e instanceof FtpError) return []; throw e; }
    return parseList(out.toString('utf8'));
  }
  retr(p) { return this.xfer('RETR ' + p); }
  stor(p, data) { return this.xfer('STOR ' + p, data); }
  close() { this.closed = true; try { this.sock.destroy(); } catch (e) {} }
}

function parseList(txt) {
  const out = [];
  for (const raw of txt.split('\n')) {
    const l = raw.replace(/\r$/, ''); if (!l.trim()) continue;
    let m = /^([d\-l])[rwxsStT\-]{9}\S*\s+\d*\s*(?:\S+\s+){0,2}?(\d+)\s+\w{3}\s+\d{1,2}\s+(?:\d{4}|\d{1,2}:\d{2})\s+(.+)$/.exec(l);
    if (m) { if (m[3] !== '.' && m[3] !== '..') out.push({ name: m[3], isDirectory: m[1] === 'd', isFile: m[1] !== 'd', size: +m[2] }); continue; }
    m = /^\d{2}-\d{2}-\d{2,4}\s+\d{1,2}:\d{2}\s*[AP]?M?\s+(<DIR>|\d+)\s+(.+)$/i.exec(l);
    if (m) { const d = m[1].toUpperCase() === '<DIR>'; out.push({ name: m[2], isDirectory: d, isFile: !d, size: d ? 0 : +m[1] }); }
  }
  return out;
}

async function getClient() {
  if (client && !client.closed) return client;
  client = new Ftp(cfg); await client.connect(); return client;
}
function op(fn) {
  const run = chain.then(async () => {
    try { return await fn(await getClient()); }
    catch (e) { if (!(e instanceof FtpError) && client) { client.close(); client = null; } throw e; }
  });
  chain = run.catch(() => {}); return run;
}
const safeList = (c, p) => c.list(p);

async function readRemote(c, p, max = 0x2000) { return (await c.retr(p)).slice(0, max); }

function utf16be(buf) {
  let s = '';
  for (let i = 0; i + 1 < buf.length; i += 2) { const ch = buf.readUInt16BE(i); if (ch === 0) break; s += String.fromCharCode(ch); }
  return s.trim();
}
function parseStfs(buf) {
  const magic = buf.slice(0, 4).toString('latin1');
  if (!['LIVE', 'PIRS', 'CON '].includes(magic) || buf.length < 0x1700) return null;
  const titleId = buf.readUInt32BE(0x360).toString(16).toUpperCase().padStart(8, '0');
  const name = utf16be(buf.slice(0x1691, 0x1691 + 0x80)) || utf16be(buf.slice(0x411, 0x411 + 0x80));
  return { titleId, name };
}

async function scan(c, emit) {
  const root = await safeList(c, '/');
  const drives = root.filter(e => e.isDirectory && !/^flash$/i.test(e.name)).map(e => e.name);
  emit({ type: 'drives', drives });

  let assetFolders = []; state.assetsRoot = null;
  for (const d of drives) {
    const l = await safeList(c, `/${d}/Aurora/Data/GameData`);
    if (l.length) { state.assetsRoot = `/${d}/Aurora/Data/GameData`; assetFolders = l.filter(e => e.isDirectory).map(e => e.name); break; }
  }
  emit({ type: 'assets', root: state.assetsRoot, folders: assetFolders });
  const findAsset = tid => assetFolders.find(f => f.toUpperCase().startsWith(tid)) || null;

  for (const d of drives) {
    emit({ type: 'progress', text: `Lendo ${d}…` });
    for (const g of await safeList(c, `/${d}/Games`)) {
      if (!g.isDirectory) continue;
      const inner = await safeList(c, `/${d}/Games/${g.name}`);
      if (!inner.some(x => /\.xex$/i.test(x.name))) continue;
      emit({ type: 'game', game: { id: `/${d}/Games/${g.name}`, name: g.name, titleId: null, drive: d, kind: 'Pasta', assetFolder: null } });
    }
    const base = `/${d}/Content/0000000000000000`;
    for (const t of await safeList(c, base)) {
      if (!t.isDirectory || !/^[0-9A-F]{8}$/i.test(t.name)) continue;
      for (const f of await safeList(c, `${base}/${t.name}/00007000`)) {
        if (!f.isFile || f.size > 2000000) continue;
        const p = `${base}/${t.name}/00007000/${f.name}`;
        try {
          const info = parseStfs(await readRemote(c, p));
          if (!info) continue;
          emit({ type: 'game', game: { id: p, name: info.name || t.name, titleId: info.titleId, drive: d, kind: 'GOD', assetFolder: findAsset(info.titleId) } });
        } catch (e) { if (!(e instanceof FtpError)) throw e; }
      }
    }
  }
  emit({ type: 'done' });
}

function readBody(req, limit = 30 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    const parts = []; let size = 0;
    req.on('data', ch => { size += ch.length; if (size > limit) { reject(new Error('Arquivo grande demais')); req.destroy(); } else parts.push(ch); });
    req.on('end', () => resolve(Buffer.concat(parts))); req.on('error', reject);
  });
}
const json = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(obj)); };
const okName = s => s && !/[\\/]|\.\./.test(s);

const server = http.createServer(async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
  const url = new URL(req.url, `http://localhost:${PORT}`);
  try {
    if (url.pathname === '/' || url.pathname === '/index.html') {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      return res.end(fs.readFileSync(path.join(__dirname, 'assets', 'web', 'editor-xbox.html')));
    }
    if (url.pathname === '/api/connect' && req.method === 'POST') {
      const b = JSON.parse((await readBody(req)).toString() || '{}');
      if (client) { client.close(); client = null; }
      cfg = { host: String(b.host || '').trim(), port: parseInt(b.port, 10) || 21, user: b.user || 'xbox', pass: b.pass || 'xbox' };
      if (!cfg.host) return json(res, 400, { error: 'Informe o IP do Xbox.' });
      const drives = await op(async c => (await c.list('/')).filter(e => e.isDirectory).map(e => e.name));
      return json(res, 200, { ok: true, drives });
    }
    if (url.pathname === '/api/scan') {
      if (!cfg) return json(res, 400, { error: 'Conecte primeiro.' });
      res.writeHead(200, { 'Content-Type': 'application/x-ndjson', 'Cache-Control': 'no-store' });
      const emit = o => res.write(JSON.stringify(o) + '\n');
      try { await op(c => scan(c, emit)); } catch (e) { emit({ type: 'error', error: e.message }); }
      return res.end();
    }
    if (url.pathname === '/api/assets') {
      const folder = url.searchParams.get('folder');
      if (!cfg || !state.assetsRoot || !okName(folder)) return json(res, 200, { files: [] });
      const list = await op(c => c.list(`${state.assetsRoot}/${folder}`));
      return json(res, 200, { files: list.filter(f => f.isFile).map(f => ({ name: f.name, size: f.size })) });
    }
    if (url.pathname === '/api/upload' && req.method === 'POST') {
      const folder = url.searchParams.get('folder'), file = url.searchParams.get('file');
      if (!cfg || !state.assetsRoot) return json(res, 400, { error: 'Pasta GameData do Aurora não encontrada.' });
      if (!okName(folder) || !okName(file)) return json(res, 400, { error: 'Nome inválido.' });
      const data = await readBody(req), remote = `${state.assetsRoot}/${folder}/${file}`;
      const backup = await op(async c => {
        let bk = null;
        const existing = (await c.list(`${state.assetsRoot}/${folder}`)).find(f => f.name === file);
        if (existing) {
          const dir = path.join(path.dirname(__filename), 'backups', folder);
          fs.mkdirSync(dir, { recursive: true });
          bk = path.join(dir, `${file}.${Date.now()}.bak`);
          fs.writeFileSync(bk, await c.retr(remote));
        }
        await c.stor(remote, data);
        return bk;
      });
      return json(res, 200, { ok: true, backup });
    }
    json(res, 404, { error: 'Não encontrado' });
  } catch (e) {
    if (!res.headersSent) json(res, 500, { error: e.message }); else res.end();
  }
});
server.listen(PORT, () => console.log(`\n  Editor Xbox by Laisy rodando em http://localhost:${PORT}\n  Abra esse endereço no navegador.\n`));

