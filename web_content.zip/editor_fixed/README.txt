EDITOR XBOX BY LAISY - VERSAO CORRIGIDA

O que foi corrigido:
- O servidor Node foi separado do HTML. Antes ele estava dentro de um comentario HTML e nao podia ser executado corretamente.
- O servidor agora serve o editor corretamente em http://localhost:3360.
- A API /api/connect, /api/scan, /api/assets e /api/upload continuam usando FTP com o Xbox/Aurora.
- O HTML continua funcionando no navegador/WebView quando aberto pelo servidor.

COMO USAR NO PC:
1. Instale Node.js.
2. Abra um terminal nesta pasta.
3. Execute: node server.js
4. Abra: http://localhost:3360
5. No Aurora, deixe o FTP ligado e informe IP, porta 21, usuario xbox e senha xbox (se forem os padroes).

IMPORTANTE SOBRE O APK:
O APK enviado usa um WebView. Um WebView nao consegue abrir conexao FTP TCP diretamente. Por isso, apenas corrigir o HTML nao transforma o APK em um cliente FTP nativo. Para o APK conectar diretamente ao Xbox sem depender de Node/PC, e necessario recompilar a parte Android adicionando uma ponte nativa ou uma biblioteca FTP.
