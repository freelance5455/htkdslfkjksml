# Atualização v1.26.8 — Formulário e avaliação dos clubes

- Removidos os campos “Tom de pele” e “Cabelo” de “Dados do Jogador”.
- A tela “Escolher país e clube” agora exibe a avaliação em estrelas abaixo do nome de cada clube.
- Mantido o tamanho grande dos escudos também em telas pequenas, sem o antigo encolhimento para 94 px.
