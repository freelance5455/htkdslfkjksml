# Terms of use — TEMPLATE (must be reviewed by a lawyer)
The software is provided "as is". It is not tax, legal or audit advice; verify reports before filing. Plan limits shown are samples.
