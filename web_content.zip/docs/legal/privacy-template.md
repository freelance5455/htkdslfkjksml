# Privacy policy — TEMPLATE (must be reviewed by a lawyer)
Data is stored only in your browser on this device. The app sends nothing to any server. You can export (JSON/CSV) and delete everything at any time. Clearing browser data erases the books; keep backups.
