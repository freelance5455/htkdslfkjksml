# Legal texts
The Terms of Use and Privacy Policy live in `src/legal-texts.js` (fa, en) and `tools/translations/{ar,fr,de}.json` (generated into `src/lang-extra.js` by `node tools/gen-langs.mjs`).
Fill `src/legal-config.js` (or the LEGAL CONFIG block at the top of the built `index.html`): owner, e-mail, governing law, refund policy. Change `version` whenever the texts change — every user is asked to accept again.
**These are templates, not legal advice.** A lawyer in your jurisdiction must review them (consumer law, data protection, e-commerce, tax/e-invoicing rules, subscription cancellation rules, local requirements for Persian/Arabic contracts).
