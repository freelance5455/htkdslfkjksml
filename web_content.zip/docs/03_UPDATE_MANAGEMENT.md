# 3. Managing Dagba without new app releases

You manage everything from the website admin as today. There are three kinds of change.

## A. Automatic (no action, no release)
Courses, lessons, videos, resources, prices (as shown on screen), images, banners, instructors, articles, learning paths, plans, home-page toggles, contact details, announcements, subscription grants and revocations.
**How it works:** every screen asks the backend each time it opens (using ETag revalidation, so unchanged content costs almost no data). Database triggers also bump a `content_version` number on any content change, from any admin screen or script; the app checks it when it returns to the foreground and refreshes the current screen. Learner activity does not bump it.
**Test it yourself:** change a course price in admin, then reopen the course in the app.
**Exception:** the *charged* store price for in-app purchases is set in the store consoles (see `04_STORE_BILLING.md`).

## B. Eligible live update (no store review, you run one command)
Changes to the app's interface only: text, layout, colours, new screens built from existing API data, bug fixes in `mobile/www`.
```
cd mobile && npm run check && npm test            # must pass
python backend/scripts/publish_web_bundle.py mobile/www 1.0.1 --min-native 1.0.0     # on the server
```
Apps download the bundle in the background at launch and switch to it on the **next** launch (never mid-lesson). If a new bundle fails to start, the updater rolls back to the previous one. `--min-native` stops old binaries from receiving a bundle that needs newer native features. To roll back, publish the previous files again under a new, higher version number.
**Policy position (checked in this session):** Apple and Google permit updating interpreted web assets that run in the app's web view, provided the app's purpose and approved behaviour do not change and no native code/permissions are downloaded. Do not use live updates to add purchase methods, change what the app is for, or work around review. This is your responsibility as publisher; if in doubt ship a store build.
**Status:** the publishing side is tested here (bundle built, hosted, announced in `/config`). The device-side download/apply uses the open-source `@capgo/capacitor-updater` plugin and has **not** been run on a phone. Test on a real device before relying on it; hosting your own bundles avoids a monthly fee, but check the plugin's current docs for its self-hosted mode.

## C. New store release required
Anything under `android/` or `ios/`; any new or upgraded Capacitor plugin; permissions (camera, notifications text, etc.); app icon/splash/name; `capacitor.config.json`; the API domain (`config.js` `API_BASE`); Firebase/Apple/Google keys; the billing library. Steps: bump versions, build (`07`/`08`), upload, submit. Raise `min_app_version` (setting in `api_v1.py` `MIN_APP_VERSION`) only when you want to force old installs to update.

## Version numbers
Keep `mobile/www/js/config.js` `APP_VERSION`, Android `versionName` and iOS `CFBundleShortVersionString` equal for store builds; Android `versionCode` and iOS build number must increase on every upload.
