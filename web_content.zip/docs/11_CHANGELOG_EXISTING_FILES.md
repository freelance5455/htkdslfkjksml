# 11. Exactly what changed in your existing website code

Compared file-by-file with your uploaded ZIP. **Everything else is byte-identical.** No templates, CSS, existing migrations, models or website routes were modified or removed.

| Existing file | Change |
|---|---|
| `dagba/__init__.py` | registers the new API blueprint; 400/403/404/413/500 handlers return JSON **only** for URLs starting `/api/v1/` |
| `dagba/security.py` | `load_user` reads `Authorization: Bearer` for `/api/v1/*` (cookies ignored there); CSRF check skipped for `/api/v1/*` (bearer-only, so cookie-CSRF cannot apply); `/api/` added to the no-cache path list |
| `dagba/services/prelaunch.py` | API config/login/refresh/logout/health/delete-account/.well-known paths allowed during prelaunch; API registration follows the same registration switch; prelaunch answers API calls with JSON |
| `dagba/services/notify.py` | after saving a notification, also sends a push (best-effort, silently skipped if Firebase is not configured) |
| `dagba/blueprints/public.py` | new routes: `/healthz`, `/delete-account`, `/.well-known/assetlinks.json`, `/.well-known/apple-app-site-association` |
| 5 test files | added `025_mobile_api.sql`, `026_store_billing.sql` to the hard-coded migration list they assert |

**New files:** `blueprints/api_v1*.py`, `services/{mobile,push,store_billing,store_verify}.py`, `migrations/025_mobile_api.sql` (+ content-version triggers), `migrations/026_store_billing.sql`, `deploy/*`, `scripts/{publish_web_bundle,dev_seeded_server}.py`, `requirements-store.txt`, 3 new test modules.
**Note on triggers:** the content-version triggers are on the content tables. If a *future* migration rebuilds one of those tables (the "create new table, copy, rename" pattern), SQLite drops that table's triggers; re-create them in the same migration (copy the lines from 025).
