# Matriks fitur (status audit "review")
| Fitur lama | Status | Catatan |
|---|---|---|
| Gerak, wrap grid, tumbuh, skor, nyawa, grid & kecepatan progresif | Dipertahankan/diperbaiki | kecepatan kini diturunkan dari skor (hasil sama) |
| Makanan 10 jenis, bergerak, rare | Diperbaiki | flag rare kini hidup; digambar sebagai bentuk+angka (tanpa emoji) |
| Power-up: speed, shield, slow, double, ghost, magnet | Diperbaiki | magnet kini nyata; aturan konflik eksplisit |
| Fury | Disambungkan | aktif tiap +30 skor, 10 dtk, skor ×2 (tidak menumpuk dengan 2×) — **keputusan desain baru**, aslinya tak ada efek |
| Combo Bonus | Disambungkan | jendela 4 dtk game; +5 tiap kelipatan 3 makanan beruntun (aturan asli mustahil dicapai) |
| Portal, es, slow zone, random box, koin, meteor, shadow snake | Dipertahankan/diperbaiki | |
| Bomb | **Evaluasi** | tidak pernah di-spawn di aslinya; kode tabrakan/render dipertahankan, spawn ditunda |
| Mirror mode, Dash | Dipertahankan/diperbaiki | |
| Kontrol Swipe / D-pad | Diperbaiki | satu gesture = satu belok; antrean 2 arah |
| Tema ×6 (palet) | Dipertahankan | efek partikel dekoratif per tema → **ditunda Fase 2** |
| Tema Special | Diperbaiki | dialog internal; easter egg |
| Musik/SFX per tema, volume | Dipertahankan | satu AudioContext dipakai ulang |
| Simpan/Muat, Reset, FPS | Diperbaiki | |
| Popup YouTube | Diganti | tawaran nyawa tambahan tanpa klaim eksternal |
| Efek kemenangan | Diperbaiki | kembang api sekali saat rekor baru, dibatasi partikel |
## Fitur baru PRD
| Fitur | Status Fase 1 |
|---|---|
| Backup/restore, namespace storage, migrasi | **Selesai** (localStorage) |
| Ikon ular + adaptive | **Selesai** |
| Aksesibilitas dasar (target ≥48px, fokus, Esc, reduced motion, safe-area, bukan hanya warna) | **Sebagian** — belum: kontrol skala font penuh, pilihan efek visual lengkap |
| Tutorial (visual/interaktif), Gamepad, Haptic, Achievement, Misi, Skin, Tantangan harian, Statistik, IndexedDB | **Belum — Fase 2** |
