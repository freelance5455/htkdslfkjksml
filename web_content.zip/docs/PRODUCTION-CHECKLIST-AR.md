# قائمة الإطلاق

- [ ] PostgreSQL تم إنشاؤها وschema/seed تم تشغيلهما.
- [ ] API health يرجع `{ "ok": true, "online": true }`.
- [ ] `JWT_SECRET` موجود في Secrets فقط.
- [ ] سر المؤسس موجود في Secrets فقط.
- [ ] `CORS_ORIGIN` يطابق رابط Vercel حرفياً.
- [ ] `GEMINI_API_KEY` موجود في API فقط.
- [ ] رابط Vercel يعمل عبر HTTPS.
- [ ] تسجيل الدخول والطلبات والخريطة وAI تم اختبارها.
- [ ] تم تحديث `APP-CONVERTER/index.html` برابط HTTPS النهائي.
- [ ] بعدها فقط يتم تحويله إلى APK.
