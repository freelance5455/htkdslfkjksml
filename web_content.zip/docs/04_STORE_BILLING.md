# 4. Payments inside the apps (Google Play Billing / Apple In-App Purchase)

## What the current policies say (researched in this session; re-check before launch, rules change)
- **Apple (App Store Review Guideline 3.1.1):** digital content, courses and memberships consumed in the app must be sold with In-App Purchase. Developer-forum rejections cited in the search results involved apps that sold courses/memberships through other methods. Since the May 2025 US court-driven changes, apps on the **US storefront** may link to external purchase; that is US-only, has been in litigation, and is not a basis for a Nigerian audience. Outside the US, plan on IAP.
- **Google Play Payments policy:** apps distributed on Google Play must use Play Billing for in-app digital goods and subscriptions. Alternative/user-choice billing exists only in specific regions/programs; Nigeria did not appear among the markets listed in the sources I found. Plan on Play Billing.
- **Consequence:** the apps must **not** show the website bank-transfer flow, bank details, or "pay on our website" buttons for buying courses/subscriptions. The app's checks (`npm run check`) block bank-transfer UI from shipping. Bank transfer continues to work on the website for people who sign up there; their purchases appear in the app because it is the same account.
- Store commission applies (typically 15–30% depending on program/revenue); that is a business decision for pricing, not an engineering one.

## How it is built
1. App calls `GET /store/products` → list of `dagba.<kind>.<id>` product ids (kinds: `plan`, `course`, `subject`, `faith`, `faithtopic`). **You create matching products in the consoles** (subscriptions for plans; one-time "non-consumable"/"managed" products for the rest).
2. The phone's store shows the localised price and takes payment (the app never handles card data).
3. The app sends the store's proof to `POST /store/verify`. The **server** asks Google (Play Developer API) or Apple (App Store Server API, signed-JWS chain verified) whether the purchase is real. Without credentials the endpoint answers **503**; it never grants access on the app's word.
4. On success it calls the same `payments._approve` code used for bank transfers → entitlement with the correct scope and expiry, instructor earnings, affiliate commission, receipt/notification. A `store_purchases` row (unique per store transaction) makes it idempotent: restoring or retrying never double-grants, and a receipt cannot be reused on another account.
5. Independence: an Academic plan product grants only the Academic entitlement; Income Skills only its own (tested).
6. Refunds: `store_billing.revoke(platform, store_txn_id)` reverses access and earnings exactly like a staff refund. **It is not yet wired to automatic notifications** (see below).

## Known gaps (be aware before charging real users)
- **Renewals/refunds are picked up when the user opens the app and restores/verifies**, not instantly. Production subscriptions should add Google Real-time Developer Notifications (Pub/Sub push) and Apple App Store Server Notifications V2 pointing at new webhook routes that call `store_billing.fulfil/revoke`. I did not build these webhooks (they need your console configuration to test).
- **Untested against live stores.** The verifier code follows the public API documentation and is unit-tested with a local fake store and locally generated Apple-style certificate chains, but it has never spoken to Google or Apple. Test with Play licence testers and Apple sandbox testers before release.
- iOS push needs the Firebase iOS SDK added to the native project (Capacitor's plugin returns an APNs token by default); see `08_IOS_BUILD.md`.
- Instructor earnings are calculated on the website price; store fees are not deducted. Decide your policy.

## One-time setup (you must do these; they need your accounts)
Google: Play Console → create app → Monetize → products; create a **service account** (Play Console → API access), grant "View financial data / Manage orders"; download its JSON to `/etc/dagba/secrets/` and set `GOOGLE_PLAY_SERVICE_ACCOUNT_FILE`, `GOOGLE_PLAY_PACKAGE_NAME`.
Apple: App Store Connect → In-App Purchases (and a subscription group per scope); Users and Access → Integrations → **In-App Purchase** key (.p8, key id, issuer id) → `APPLE_IAP_*`; download Apple Root CA G3 for `APPLE_ROOT_CA_FILE`; `APPLE_BUNDLE_ID`.
Server: `pip install -r requirements-store.txt`.

## Test checklist (all required before submission)
1. Android licence tester buys a course → access appears; buys again → "already have access"; restore on a second device.
2. Android subscription (Academic) → Academic unlocked, Income Skills still locked.
3. iOS sandbox purchase of a subscription and a one-time item; restore purchases button.
4. Forge a request to `/store/verify` with a made-up token → must be rejected.
5. Refund a purchase in the console → run `revoke` → access removed, earnings reversed.
6. Reviewer demo account works and can reach purchase screens (see `09`).
