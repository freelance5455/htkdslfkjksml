# Carreira de Craque v1.26.4 — Overall lógico e partidas equilibradas

## Alterações
- Adicionada uma avaliação interna por estrelas para os clubes da Série A, Série B, Premier League e Sub-20.
- A avaliação por estrelas entra no cálculo de força da equipe junto com a média dos 11 melhores jogadores disponíveis no cadastro do jogo.
- A simulação usa variação de desempenho por partida, mando de campo moderado e uma relação menos extrema entre diferença de força e chance de gol.
- A carreira do jogador também usa variação de desempenho dos dois times; forma física e energia, plano tático e mando de campo continuam influenciando o resultado.

## Princípio de equilíbrio
- Um time mais forte tende a ter vantagem ao longo de uma temporada, mas não recebe vitória automática.
- Times menores podem vencer, empatar ou surpreender gigantes em uma partida, especialmente com mando de campo e boa execução.
- A aleatoriedade altera probabilidades, não garante resultados fixos. Os placares continuam limitados a 0–6 gols por equipe.

## Observação de teste
O teste automatizado existente `tests/smoke-test.js` interrompe na asserção `career systems initialized with identified real roster records`, relacionada à expectativa de elenco real na inicialização. A falha ocorre antes de qualquer teste específico da nova lógica de força; não foi declarada como aprovação.
