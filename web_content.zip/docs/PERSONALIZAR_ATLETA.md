# Personalizar atleta — Carreira de Craque

Versão: 1.9.0 (base do projeto v1.8.7)

## O que mudou
- Nova aba **Personalizar** dentro de **JOGADOR**, ao lado de Perfil e Atributos.
- Editor de aparência por categorias, com prévia SVG local e sem dependência externa.
- Opções de rosto, tom de pele, cortes e cores de cabelo, barba, bigode, sobrancelhas, olhos, brincos, faixa e manga do uniforme.
- Prévia atualiza ao selecionar opções; **Salvar aparência** grava os dados em `state.p.appearance` no mesmo save da carreira.
- **Restaurar padrão** altera apenas os dados visuais, sem apagar atributos, saldo, clube, contrato, partidas ou conquistas.
- `art(p)` reutiliza a aparência salva nas telas do jogo que já mostram o atleta.
- Migração segura: saves antigos recebem valores padrão sem recriar a carreira.

## Limitação honesta
O avatar é uma ilustração SVG modular em 2D, não um modelo 3D nem uma fotografia. Alguns estilos compartilham uma silhueta base e podem ser refinados com arte vetorial específica no futuro.
