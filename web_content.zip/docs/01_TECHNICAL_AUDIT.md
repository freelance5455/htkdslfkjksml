# 1. Technical audit and architecture

## What was found in your ZIP (inspected, not assumed)
- **Backend:** Flask 3.1 / Python 3.12 modular monolith, 19 blueprints, about 222 routes, about 9,000 lines of application code, 24 SQL migrations, about 75 tables, SQLite (WAL), Jinja2 templates, ReportLab certificates, Pillow upload validation, 269 existing tests (per the README).
- **Auth:** cookie sessions + CSRF tokens + role/permission model (student, instructor, writer, admin, owner). No token auth and no JSON API for learners existed.
- **Business rules live in services, not routes:** `services/access.py` (who may open what), `payments.py` (bank transfer, gateway scaffolding, approvals, refunds), `release.py` (scheduled lessons), `lms.py` (progress, certificates), `payouts.py`, `affiliates.py`. This is what made a thin API possible without duplicating logic.
- **Entitlement model:** Basic and Advanced (Academic) are sold per subject or by subscription; Income Skills per course or subscription; Professional Development per subject; Faith per series/topic. Scopes are independent by design and the API reuses that code, so "Academic does not unlock Income Skills" holds in the app too (there are tests for it).
- **Findings you should know about**
  1. The website registration form (`auth.py`) and a few admin pages still reference JSS/SS class levels. The mobile app never shows them (the API only returns Basic/Advanced) and an automated check fails the build if "JSS"/"SS1-3" appears in app code. I did **not** change the website form; say if you want it removed.
  2. `MAX_UPLOAD_MB` defaults to 25 MB. Lesson videos need a larger value (the deployment env file sets 600).
  3. Existing tests hard-coded the migration list; I added the new migration names to five of them (no other test changed).

## Architecture decision (confirmed, no deviation needed)
```
 Website (Jinja, cookies)  ─┐
 Android app (Capacitor)   ─┼──►  ONE Flask backend  ──►  ONE SQLite database + uploads
 iOS app (Capacitor)       ─┘      /api/v1 (Bearer tokens) reuses the same services
```
- No separate mobile accounts, courses, or payment tables. Mobile adds only: `api_sessions` (sign-ins), `device_tokens` (push), `content_version` (sync stamp), `store_purchases` (store receipts). All migrations are **additive** (025, 026): nothing existing is altered or dropped.
- The app is a bundled web app (`mobile/www`, vanilla JS, no build step) inside a Capacitor shell. It holds **no** course, price, banner, or text content; everything is fetched from `/api/v1`.

## Limitations I am flagging (per your rule: explain before changing architecture)
1. **Store payments:** Apple and Google require their own billing for digital courses/subscriptions inside the apps. Bank transfer therefore stays on the website only. See `04_STORE_BILLING.md`. This is a policy constraint, not a technical choice.
2. **Store prices are set in the store consoles**, not pulled from your database. A price change on the website is automatic in the app's catalogue (browse) but the *charged* store price must also be changed in Play Console / App Store Connect.
3. **SQLite means one server.** It is fine for this scale and is simple to back up, but you cannot run several app servers at once. Do not move to multiple servers without moving to PostgreSQL.
4. **Termux cannot build the apps.** Android Studio / Xcode need a PC or Mac (or a CI runner). Termux remains fine as a development environment for the backend.
5. **No browser/emulator/devices or store accounts were available in this build environment.** See the honest status table in `00_START_HERE.md`.
