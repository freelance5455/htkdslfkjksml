# Migrasi data
Prinsip: **key lama tidak pernah dihapus oleh migrasi** (rollback ke versi lama tetap aman). Reset oleh pengguna menghapus key lama + baru milik game saja.

| Key lama | Key baru | Catatan |
|---|---|---|
| snakeHighScore | ular_super:highScore | disalin bila key baru belum ada |
| snakeTheme/snakeBgSound/snakeFxSound/snakeControls/snakeBgVolume/snakeFxVolume | ular_super:settings (JSON, tervalidasi) | `snakeControls=dpad` kini dihormati |
| specialThemeUnlocked | ular_super:unlocks | |
| snakeSaveGame | dimuat lewat `fromLegacy()` → divalidasi → disimpan ulang dalam skema baru saat Simpan | power-up aktif lama (berbasis `Date.now()`) **tidak dapat dipulihkan** dan dibuang |
Skema baru: `ular_super:save = {schemaVersion:1, savedAt, session}`. Versi tak dikenal/rusak → ditolak dengan pesan, data **tidak** ditimpa/dihapus.
Backup: `{app:"game-ular-super", schemaVersion:1, data:{settings,highScore,unlocks,save}}`, mode Timpa/Gabung dengan konfirmasi.
Tidak ada nama key lama yang diubah atau struktur data lama yang dirusak. ID elemen HTML lama yang masih dipakai dipertahankan (`gameCanvas`, `scoreValue`, `pauseButton`, dst.); elemen lama yang tidak lagi dipakai (popup YouTube, panel setting statis) digantikan UI dinamis.
