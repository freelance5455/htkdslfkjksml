# JARVIS AI — Android APK Packaging Guide

JARVIS AI is structured so the frontend (`dist/`) can be packaged as an Android APK using **Capacitor** or **Bubblewrap (TWA)** while keeping your `GEMINI_API_KEY` isolated on the backend server.

## Option A: Capacitor Android APK (Native WebView Wrapper)

1. Build the static web bundle pointing to your hosted Express/Gemini backend (never embed `GEMINI_API_KEY` in `VITE_*` variables):
   ```bash
   VITE_API_BASE_URL="https://your-deployed-jarvis-backend.example.com" npm run build
   ```
2. Install Capacitor CLI and Android platform in your local Android Studio workspace:
   ```bash
   npm install @capacitor/core @capacitor/android
   npx cap add android
   npx cap sync android
   ```
3. In `android/app/src/main/AndroidManifest.xml`, declare only the required permissions:
   ```xml
   <uses-permission android:name="android.permission.INTERNET" />
   <uses-permission android:name="android.permission.RECORD_AUDIO" />
   ```
4. Build the signed APK or AAB from Android Studio (`npx cap open android`).

## Option B: Trusted Web Activity (TWA / Bubblewrap)

`public/manifest.webmanifest` and `public/sw.js` are preconfigured for standalone Android installability:
```bash
npx @bubblewrap/cli init --manifest="https://your-deployed-jarvis-backend.example.com/manifest.webmanifest"
npx @bubblewrap/cli build
```

## Microphone & Foreground Service Policy

- Voice listening operates strictly in the foreground while **Talk** mode is active and stops immediately when **Stop** is tapped.
- Do not enable background microphone capture unless you implement a dedicated native Android `ForegroundService` with `foregroundServiceType="microphone"` and a persistent visible notification with Pause/Stop controls.
