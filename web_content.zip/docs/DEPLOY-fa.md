# راه‌اندازی سرور Contractor Pro

## ۱. ساده‌ترین حالت — تست روی گوشی/لپ‌تاپ خودت (بدون دیتابیس واقعی)

برای امتحان کردن، نیازی به هیچ سروری نیست:

```bash
cd server
npm install
node src/index.js
```

این کار سرور رو روی `http://localhost:8080` بالا میاره. اطلاعات فقط توی حافظه‌ی برنامه (RAM) می‌مونه و با ری‌استارت شدن سرور پاک می‌شه — فقط برای تست خوبه، نه برای استفاده‌ی واقعی.

## ۲. حالت واقعی — روی یک سرور (VPS)

### قدم ۱: یک VPS بگیر
هر سرویسی مثل Hetzner، DigitalOcean، یا سرورهای داخلی که Node.js رو پشتیبانی کنه کافیه. حداقل ۱ گیگابایت رم کافیه برای شروع.

### قدم ۲: Node.js رو نصب کن
```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo bash -
sudo apt install -y nodejs
```

### قدم ۳: یک پایگاه‌داده‌ی PostgreSQL بساز
اگه بدون این کار سرور رو روی حالت production بالا بیاری، خودش از کار می‌افته (عمداً، تا اطلاعاتت گم نشه). ساده‌ترین راه:
```bash
sudo apt install -y postgresql
sudo -u postgres createdb contractorpro
sudo -u postgres psql -c "ALTER USER postgres PASSWORD 'یک-رمز-قوی';"
```
بعد فایل `server/db/schema.sql` رو روی همین دیتابیس اجرا کن:
```bash
sudo -u postgres psql -d contractorpro -f server/db/schema.sql
```

### قدم ۴: فایل `.env` رو بساز
یک کپی از `server/.env.example` بگیر و این مقادیر رو پر کن:
```
JWT_SECRET=یک رشته‌ی طولانی و تصادفی (حداقل ۳۲ کاراکتر)
DATABASE_URL=postgres://postgres:یک-رمز-قوی@localhost:5432/contractorpro
NODE_ENV=production
PORT=8080
CRYPTO_BTC_ADDRESS=آدرس کیف‌پول بیت‌کوین خودت (اختیاری)
CRYPTO_USDT_ADDRESS=آدرس کیف‌پول تتر خودت (اختیاری)
```

### قدم ۵: اجرا کن
```bash
cd server
npm install
export $(cat .env | xargs)
node src/index.js
```

### قدم ۶: همیشه روشن نگهش دار
بدون این، با ری‌استارت گوشی/سرور، برنامه خاموش می‌مونه:
```bash
sudo npm install -g pm2
pm2 start src/index.js --name contractor-pro
pm2 save
pm2 startup
```

### قدم ۷: یک دامنه و HTTPS بذار جلوش
با Caddy (خودش گواهی SSL رایگان می‌گیره):
```bash
sudo apt install -y caddy
```
فایل `/etc/caddy/Caddyfile`:
```
yourdomain.com {
    reverse_proxy localhost:8080
}
```
```bash
sudo systemctl reload caddy
```

### قدم ۸: برنامه رو به سرور وصل کن
توی برنامه، قسمت «Online Account» → آدرس سرور رو بزن: `https://yourdomain.com`

## ارزهای دیجیتال (تتر / بیت‌کوین)
- فقط کافیه آدرس کیف‌پول خودت رو (که از قبل داری یا توی اپی مثل Trust Wallet/Exodus می‌سازی) توی `.env` بذاری — سرور هیچ کلید خصوصی‌ای نگه نمی‌داره.
- قیمت BTC لحظه‌ای از یک سرویس عمومی (CoinGecko) گرفته می‌شه؛ قیمت USDT تقریباً برابر دلار در نظر گرفته می‌شه.
- **تأیید پرداخت خودکار نیست** — یعنی بعد از اینکه مشتری پول رو فرستاد، خودت باید توی کیف‌پولت یا یک بلاک‌اکسپلورر (مثل blockchain.com یا tronscan.org) چک کنی که واقعاً رسیده، بعد توی برنامه دکمه‌ی «I paid — confirm» رو بزنی. این برای جلوگیری از پرداخت جعلی عمدیه.

## نکته‌ی امنیتی
فایل `.env` رو هیچ‌وقت جایی عمومی (مثل گیت‌هاب) آپلود نکن — رمزها و کلیدهای داخلش حساسن.
