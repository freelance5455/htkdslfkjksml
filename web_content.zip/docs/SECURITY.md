# Segurança

Já existe validação de tipo e tamanho na importação, armazenamento local, SHA-256 de arquivos e helper AES-GCM via Web Crypto. O fluxo normal não mostra notificações de verificação.

Para produção ainda são necessários CSP e headers no host, gestão de segredos fora do cliente, assinatura de builds, hardening de qualquer bridge nativa e auditoria de dependências.
