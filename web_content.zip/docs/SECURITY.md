# Security boundary

Frontend-only password gates are not real authentication. Do not put secrets in JS. When a backend is added, use server-side authentication, authorization, password hashing, session controls, CSRF/XSS protections, rate limiting and strict input validation.