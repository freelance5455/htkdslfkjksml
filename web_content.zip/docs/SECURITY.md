# Strict security profile

- Internet-only: UI is blocked when browser connectivity is lost and the API health check fails.
- Founder password is never stored in plaintext or frontend code; only a derived scrypt hash is used server-side.
- Founder token expires in 30 minutes and founder scope is checked on every admin route.
- Helmet security headers and restrictive CSP.
- CORS allowlist.
- Global API rate limit + tighter authentication rate limit.
- bcrypt cost 12 for normal user passwords.
- PostgreSQL transactions and `FOR UPDATE` inventory locking.
- Audit logs for important operations.
- No API keys in frontend.
- HTTPS is mandatory in production.
- Secrets must be stored in environment/secret manager, not Git.
- Before public launch add WebAuthn/TOTP 2FA, session/device revocation, WAF, centralized logs, backups/PITR and penetration testing.
