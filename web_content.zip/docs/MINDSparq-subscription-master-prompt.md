# MindSparq Subscription Implementation Brief

Use this prompt when continuing development of this existing codebase. Do not restart or replace the project.

Act as a senior SaaS product architect, full-stack developer, subscription monetization expert, UI/UX designer, and security engineer. Inspect the current React + TypeScript + Vite frontend and Express backend first. Preserve the existing AI tutoring, chat history, quiz, flashcard, and fallback features.

## Product and Proposed Pricing
- Free: ₹0; starter AI tutoring allowances and essential learning tools.
- MindSparq Plus: ₹199/month or ₹1,990/year; higher tutoring allowances, practice quizzes, flashcards, study planning, and revision tools.
- MindSparq Pro: ₹499/month or ₹4,990/year; everything in Plus, higher advanced tutoring allowances, detailed explanations, mock tests, performance insights, and document analysis only when implemented.

These are proposed prices, not validated or live offers. Keep them configurable. Make usage limits configurable based on real AI-provider costs.

## Required Launch Work
1. Connect authentication and durable user records before assigning subscriptions to users.
2. Choose a supported payment provider based on the actual publishing platform and applicable policies.
3. Create checkout sessions on the server; verify payment status and webhook signatures server-side; handle idempotency, renewals, failed payments, cancellations, and expiration.
4. Store subscription state in the server-side database and enforce entitlements on every protected API operation. Never trust localStorage, request-body plan flags, URL parameters, or frontend success states.
5. Add billing management, clear renewal/cancellation terms, tests, and deployment documentation.
6. Keep sandbox/test mode available. Do not charge users or use live credentials without explicit authorization.
7. Run TypeScript checks and production builds. Report actual test results, changed files, configuration requirements, and remaining limitations honestly.

## Current Known Limitation
The current project has no configured user authentication, subscription database, or payment provider. The pricing page is presentational only. Paid buttons must not activate a subscription until secure billing and server-side entitlements are implemented and tested.


## Direct UPI payment request (manual, not recurring)
- The subscription page may request a one-time UPI intent from the Express server using `POST /api/billing/upi-intent`.
- Read the receiving UPI ID and payment-support email only from private server environment variables (`PAYMENT_UPI_ID`, `PAYMENT_SUPPORT_EMAIL`); never hardcode them in a frontend file or expose them as `VITE_` variables.
- The UI should not print the raw identifiers. The payer's UPI app will still show recipient details at confirmation; the payee cannot be hidden from the person making a UPI transfer.
- A UPI intent is not payment proof. Never activate a subscription based on clicking “I paid” or opening an intent. Require independent payment verification and server-side records before granting paid access.
- State clearly that direct UPI payment is one-time, manually reviewed, and does not auto-renew. For true recurring subscriptions, integrate an eligible payment provider and verified webhooks.
