# JARVIS Android Companion Architecture & Truthful OS Realities

## 1. Operating System Realities (Android 12, 13, 14, 15)

### Background Microphone Access
- **Web App Limitation:** Standard web applications running in mobile Chrome, Firefox, or Safari **cannot** capture audio when the browser tab is backgrounded, minimized, or when the device screen is locked.
- **Native Android Companion:** The native companion app (`ai.jarvis.companion`) uses a dedicated **Foreground Service** with `FOREGROUND_SERVICE_TYPE_MICROPHONE` and a persistent ongoing notification. This complies with Android 14 security rules, permitting hands-free interaction while the device is in use.

### Doze Mode & OEM Battery Optimizations
- Aggressive OEM battery killers (MIUI, ColorOS, OneUI) terminate background processes unless the user explicitly exempts the app in *Settings > Apps > JARVIS > Battery > Unrestricted*.
- Wake locks (`PARTIAL_WAKE_LOCK`) keep the CPU alive when screen turns off during an active voice session.

## 2. Hardware Button & Voice Assistant Integration
- **Intent Filters:**
  - `android.intent.action.ASSIST`
  - `android.intent.action.VOICE_COMMAND`
- **Default Digital Assistant:**
  - When selected as the device's Default Digital Assistant (*Settings > Apps > Default Apps > Digital Assistant app*), holding the power button or swiping from the bottom screen corner triggers JARVIS instantly.

## 3. Reproducible APK Build Commands
To compile the release APK from the project directory:

```bash
cd android-companion
./gradlew assembleDebug
# Output APK: app/build/outputs/apk/debug/app-debug.apk
```
