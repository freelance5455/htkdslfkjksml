# Atualização v1.27.0 — estrelas dos clubes corrigidas

Corrigida a identificação dos nomes alternativos dos clubes no seletor, para que os times não apareçam com zero estrelas. Inclui Mirassol, Bahia, Coritiba, Red Bull Bragantino, Vitória, América-MG, Botafogo-SP, CRB, Fortaleza e Sport. As avaliações usam os valores definidos para Série A/B e Sub-20, conforme o modo selecionado.
