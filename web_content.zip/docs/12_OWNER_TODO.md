# 12. What only you can supply or do

| # | Item | Needed for |
|---|---|---|
| 1 | A VPS (or hosting) account, SSH access, domain/Cloudflare access | production hosting |
| 2 | Off-site backup storage + `rclone` remote | backups |
| 3 | Google Play Developer account (one-time fee) and Apple Developer Program (annual fee): check current prices | store publishing |
| 4 | Final bundle ID / package name (default `com.dagbadigitalacademy.app`), confirm before first upload | stores |
| 5 | Android upload keystore (`gen_android_keystore.sh`) + secure backup | Android release |
| 6 | Firebase project; `google-services.json` (Android), `GoogleService-Info.plist` + APNs key (iOS), service-account JSON on the server | push |
| 7 | Google Play service account JSON; Apple IAP key (.p8, key id, issuer id), Apple Root CA | purchase verification |
| 8 | Create the in-app products in both consoles using the ids from `GET /api/v1/store/products`, and set their store prices | in-app purchases |
| 9 | Higher-resolution/vector brand logo (the supplied 256 px file produced the icon; a vector will be crisper) and your mobile mockup if you want it matched more closely | icon/splash/visual polish |
| 10 | Real screenshots from a device or emulator; demo reviewer account | store submission |
| 11 | Lawyer review of privacy/terms for NDPA and store rules | compliance |
| 12 | A Mac (or macOS CI) for iOS builds | iOS |
| 13 | Decisions: remove JSS/SS from website registration? Staff accounts' deletion process? Store-fee handling in instructor payouts? | policy |
| 14 | Run `python scripts/mobile_settings.py set <key> <value>` on the server for `mobile.android_package`, `mobile.android_sha256`, `mobile.apple_app_id`, `mobile.store_url_android`, `mobile.store_url_ios` (these have no admin screen) | deep links, update prompts |
