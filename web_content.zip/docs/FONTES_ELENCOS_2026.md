# Fontes e política de dados — elencos 2026

**Data de referência do banco local:** 2026-10-25. Essa data é a edição do arquivo, não uma garantia de que cada página tenha sido atualizada naquele dia.

## Fontes gerais oficiais

- [CBF — times da Série A 2026](https://www.cbf.com.br/futebol-brasileiro/times/campeonato-brasileiro/serie-a/2026)
- [CBF — atletas inscritos na Série A 2026](https://www.cbf.com.br/futebol-brasileiro/atletas/campeonato-brasileiro/serie-a/2026)
- [CBF — tabela/estatísticas da Série A 2026](https://www.cbf.com.br/futebol-brasileiro/tabelas/campeonato-brasileiro/serie-a/2026)
- [CBF — tabela/estatísticas da Série B 2026](https://www.cbf.com.br/futebol-brasileiro/tabelas/campeonato-brasileiro/serie-b/2026)
- [Palmeiras — elenco profissional e números](https://www.palmeiras.com.br/elenco/)

## Fonte associada a cada clube

A URL abaixo é a referência local associada aos registros daquele clube. Em alguns casos é uma página oficial de atletas; em outros, uma escalação oficial da CBF ou a tabela/estatísticas da competição. A base não afirma que todos os nomes de um elenco foram cadastrados.

| Divisão | Clube | Registros locais | Fonte |
|---|---|---:|---|
| Série A | Athletico Paranaense | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/times/campeonato-brasileiro/serie-a/2026/20052?tab=atletas) |
| Série A | Atlético Mineiro | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/times/campeonato-brasileiro/serie-a/2026/62194?tab=atletas) |
| Série A | Bahia | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-a/2026/athletico-paranaense-x-bahia/832168?view=escalacao) |
| Série A | Botafogo | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/times/campeonato-brasileiro/serie-a/2026/60175?tab=atletas) |
| Série A | Chapecoense | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/times/campeonato-brasileiro/serie-a/2026/20086?tab=atletas) |
| Série A | Corinthians | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/times/campeonato-brasileiro/serie-a/2026/20001?tab=atletas) |
| Série A | Coritiba | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/times/campeonato-brasileiro/serie-a/2026/61590?tab=atletas) |
| Série A | Cruzeiro | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/tabelas/campeonato-brasileiro/serie-a/2026) |
| Série A | Flamengo | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/times/campeonato-brasileiro/serie-a/2026/20016?tab=atletas) |
| Série A | Fluminense | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/times/campeonato-brasileiro/serie-a/2026/20014?tab=atletas) |
| Série A | Grêmio | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/times/campeonato-brasileiro/serie-a/2026/20013?tab=atletas) |
| Série A | Internacional | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/times/campeonato-brasileiro/serie-a/2026/20011?tab=atletas) |
| Série A | Mirassol | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/times/campeonato-brasileiro/serie-a/2026/20385?tab=atletas) |
| Série A | Palmeiras | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/times/campeonato-brasileiro/serie-a/2026/20002?tab=atletas) |
| Série A | Red Bull Bragantino | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/times/campeonato-brasileiro/serie-a/2026/20007?tab=atletas) |
| Série A | Remo | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/times/campeonato-brasileiro/serie-a/2026/20022?tab=atletas) |
| Série A | Santos | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/times/campeonato-brasileiro/serie-a/2026/20008?tab=atletas) |
| Série A | São Paulo | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/times/campeonato-brasileiro/serie-a/2026/20005?tab=atletas) |
| Série A | Vasco da Gama | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-a/2026/gremio-x-vasco-da-gama-saf/832157?view=escalacao) |
| Série A | Vitória | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-a/2026/sao-paulo-x-vitoria/832183?view=escalacao) |
| Série B | América Mineiro | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/times/campeonato-brasileiro/serie-b/2026/59897?tab=atletas) |
| Série B | Athletic Club | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-b/2026/athletic-saf-x-londrina-saf/833214?view=escalacao) |
| Série B | Atlético Goianiense | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-b/2026/londrina-saf-x-atletico-goianiense-saf/833105?view=escalacao) |
| Série B | Avaí | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/times/campeonato-brasileiro/serie-b/2026/20058?tab=atletas) |
| Série B | Botafogo-SP | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/tabelas/campeonato-brasileiro/serie-b/2026) |
| Série B | Ceará | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/tabelas/campeonato-brasileiro/serie-b/2026) |
| Série B | CRB | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-a/2026/ponte-preta-x-crb/833166?view=escalacao) |
| Série B | Criciúma | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/times/campeonato-brasileiro/serie-b/2026/20019?tab=atletas) |
| Série B | Cuiabá | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-b/2026/ponte-preta-x-cuiaba/832992?view=escalacao) |
| Série B | Fortaleza | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-b/2026/fortaleza-saf-x-sao-bernardo-saf/833106?view=escalacao) |
| Série B | Goiás | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-b/2026/goias-x-londrina-saf/833087?view=escalacao) |
| Série B | Juventude | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/tabelas/campeonato-brasileiro/serie-b/2026) |
| Série B | Londrina | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/times/campeonato-brasileiro/serie-b/2026/62726?tab=atletas) |
| Série B | Náutico | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-b/2026/sao-bernardo-saf-x-nautico/833113?view=escalacao) |
| Série B | Novorizontino | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-b/2026/londrina-saf-x-gremio-novorizontino-saf/833075?view=escalacao) |
| Série B | Operário-PR | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/tabelas/campeonato-brasileiro/serie-b/2026) |
| Série B | Ponte Preta | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/times/campeonato-brasileiro/serie-b/2026/20037?tab=atletas) |
| Série B | São Bernardo | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/times/campeonato-brasileiro/serie-b/2026/31790?tab=atletas) |
| Série B | Sport Recife | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/times/campeonato-brasileiro/serie-b/2026/20010?tab=atletas) |
| Série B | Vila Nova | 18 | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/times/campeonato-brasileiro/serie-b/2026/20079?tab=atletas) |

## Fontes usadas para números de camisa

O número é preenchido somente quando há uma numeração observável numa escalação oficial ou no cadastro de elenco consultado. Os demais ficam nulos. A base parcial não pode garantir que um número sem dono identificado esteja administrativamente livre.

| Clube | Fonte de numeração |
|---|---|
| Athletico Paranaense | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-a/2026/athletico-paranaense-x-bahia/832168?view=escalacao) |
| Bahia | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-a/2026/athletico-paranaense-x-bahia/832168?view=escalacao) |
| Botafogo | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-a/2026/coritiba-saf-x-botafogo/832188?view=escalacao) |
| Chapecoense | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-a/2026/chapecoense-x-internacional/832160?view=escalacao) |
| Grêmio | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-a/2026/gremio-x-vasco-da-gama-saf/832157?view=escalacao) |
| Internacional | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-a/2026/chapecoense-x-internacional/832160?view=escalacao) |
| Mirassol | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-a/2026/mirassol-x-sao-paulo/832205?view=escalacao) |
| Palmeiras | [Abrir fonte](https://www.palmeiras.com.br/elenco/) |
| Red Bull Bragantino | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-a/2026/flamengo-x-red-bull-bragantino/832161?view=escalacao) |
| Flamengo | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-a/2026/flamengo-x-red-bull-bragantino/832161?view=escalacao) |
| Remo | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-a/2026/remo-x-santos-fc/832170?view=escalacao) |
| Santos | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-a/2026/remo-x-santos-fc/832170?view=escalacao) |
| São Paulo | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-a/2026/mirassol-x-sao-paulo/832205?view=escalacao) |
| Vasco da Gama | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-a/2026/gremio-x-vasco-da-gama-saf/832157?view=escalacao) |
| Vitória | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-a/2026/sao-paulo-x-vitoria/832183?view=escalacao) |
| Atlético Goianiense | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-b/2026/londrina-saf-x-atletico-goianiense-saf/833105?view=escalacao) |
| Avaí | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-b/2026/avai-x-londrina-saf/833208?view=escalacao) |
| Ceará | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/tabelas/campeonato-brasileiro/serie-b/2026) |
| Criciúma | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-b/2026/londrina-saf-x-criciuma/833195?view=escalacao) |
| CRB | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-a/2026/ponte-preta-x-crb/833166?view=escalacao) |
| Cuiabá | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-b/2026/ponte-preta-x-cuiaba/832992?view=escalacao) |
| Fortaleza | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-b/2026/fortaleza-saf-x-sao-bernardo-saf/833106?view=escalacao) |
| Goiás | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-b/2026/goias-x-londrina-saf/833087?view=escalacao) |
| Londrina | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-b/2026/athletic-saf-x-londrina-saf/833214?view=escalacao) |
| Náutico | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-b/2026/sao-bernardo-saf-x-nautico/833113?view=escalacao) |
| Novorizontino | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-b/2026/londrina-saf-x-gremio-novorizontino-saf/833075?view=escalacao) |
| Ponte Preta | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-b/2026/ponte-preta-x-cuiaba/832992?view=escalacao) |
| São Bernardo | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-b/2026/fortaleza-saf-x-sao-bernardo-saf/833106?view=escalacao) |
| Sport Recife | [Abrir fonte](https://www.cbf.com.br/futebol-brasileiro/jogos/campeonato-brasileiro/serie-b/2026/sport-recife-x-sao-bernardo-saf/833203?view=escalacao) |

## Conteúdo e limites

- O arquivo `data/jogadores_reais_2026.json` contém **720 registros**, com 18 nomes cadastrados por clube para a versão 1.4.0.
- Os nomes foram associados às páginas de atletas/inscrições da CBF e às páginas de elencos profissionais consultadas. As páginas da CBF podem incluir registros históricos; foram selecionados nomes que apareciam como atuais na fonte consultada quando esse campo estava disponível.
- ID é único por registro e acompanha o jogador quando ocorre uma movimentação simulada dentro do save.
- Posição funcional, overall e os 21 atributos são estimativas para gameplay. Não são notas oficiais, nem avaliações oficiais de habilidade.
- Idade, nacionalidade, altura, pé dominante e valor de mercado ficam nulos quando não foram confirmados na fonte usada. A interface mostra “não verificado” em vez de inventar valores.
- Números não informados não são tratados como confirmação de vaga. O cadastro de camisas é parcial mesmo com 18 nomes por clube, pois a numeração completa de todos os atletas não pôde ser confirmada.
- Gols e assistências são calculados a partir das partidas simuladas no save. Não são estatísticas oficiais reais do Brasileirão 2026.
- Transferências acionadas no menu de elenco são acontecimentos fictícios da carreira, não notícias do futebol fora do jogo.
- Não foram incorporadas fotos de jogadores nem escudos oficiais; o avatar ilustrado é o fallback local.

## Cobertura de elencos — versão 1.4.0

Todos os 40 clubes das Séries A e B têm 18 atletas cadastrados (dentro da faixa solicitada de 17 a 22). A base detalhada contém 720 registros. Os nomes foram conferidos em páginas de atletas/inscrições da CBF e páginas oficiais de elencos consultadas para 2026. A posição, overall e atributos continuam estimativas para o jogo, não notas oficiais. O número de camisa permanece nulo quando não confirmado por uma fonte específica.

| Divisão | Clube | Atletas cadastrados | Situação |
|---|---|---:|---|

| Divisão | Clube | Atletas cadastrados | Situação |
|---|---|---:|---|
| Série A | Athletico Paranaense | 18 | Dentro da faixa 17–22 |
| Série A | Atlético Mineiro | 18 | Dentro da faixa 17–22 |
| Série A | Bahia | 18 | Dentro da faixa 17–22 |
| Série A | Botafogo | 18 | Dentro da faixa 17–22 |
| Série A | Chapecoense | 18 | Dentro da faixa 17–22 |
| Série A | Corinthians | 18 | Dentro da faixa 17–22 |
| Série A | Coritiba | 18 | Dentro da faixa 17–22 |
| Série A | Cruzeiro | 18 | Dentro da faixa 17–22 |
| Série A | Flamengo | 18 | Dentro da faixa 17–22 |
| Série A | Fluminense | 18 | Dentro da faixa 17–22 |
| Série A | Grêmio | 18 | Dentro da faixa 17–22 |
| Série A | Internacional | 18 | Dentro da faixa 17–22 |
| Série A | Mirassol | 18 | Dentro da faixa 17–22 |
| Série A | Palmeiras | 18 | Dentro da faixa 17–22 |
| Série A | Red Bull Bragantino | 18 | Dentro da faixa 17–22 |
| Série A | Remo | 18 | Dentro da faixa 17–22 |
| Série A | Santos | 18 | Dentro da faixa 17–22 |
| Série A | São Paulo | 18 | Dentro da faixa 17–22 |
| Série A | Vasco da Gama | 18 | Dentro da faixa 17–22 |
| Série A | Vitória | 18 | Dentro da faixa 17–22 |
| Série B | América Mineiro | 18 | Dentro da faixa 17–22 |
| Série B | Athletic Club | 18 | Dentro da faixa 17–22 |
| Série B | Atlético Goianiense | 18 | Dentro da faixa 17–22 |
| Série B | Avaí | 18 | Dentro da faixa 17–22 |
| Série B | Botafogo-SP | 18 | Dentro da faixa 17–22 |
| Série B | Ceará | 18 | Dentro da faixa 17–22 |
| Série B | CRB | 18 | Dentro da faixa 17–22 |
| Série B | Criciúma | 18 | Dentro da faixa 17–22 |
| Série B | Cuiabá | 18 | Dentro da faixa 17–22 |
| Série B | Fortaleza | 18 | Dentro da faixa 17–22 |
| Série B | Goiás | 18 | Dentro da faixa 17–22 |
| Série B | Juventude | 18 | Dentro da faixa 17–22 |
| Série B | Londrina | 18 | Dentro da faixa 17–22 |
| Série B | Náutico | 18 | Dentro da faixa 17–22 |
| Série B | Novorizontino | 18 | Dentro da faixa 17–22 |
| Série B | Operário-PR | 18 | Dentro da faixa 17–22 |
| Série B | Ponte Preta | 18 | Dentro da faixa 17–22 |
| Série B | São Bernardo | 18 | Dentro da faixa 17–22 |
| Série B | Sport Recife | 18 | Dentro da faixa 17–22 |
| Série B | Vila Nova | 18 | Dentro da faixa 17–22 |
