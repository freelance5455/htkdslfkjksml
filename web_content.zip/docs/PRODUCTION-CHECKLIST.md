# Production checklist

## Required before public launch
- [ ] Provision managed PostgreSQL and enable backups/PITR.
- [ ] Set a strong JWT secret and rotate it securely.
- [ ] Add phone OTP provider and email provider.
- [ ] Obtain official Jawwal Pay / Paltel Pay merchant API credentials and webhook documentation.
- [ ] Implement webhook signature verification, idempotency and reconciliation.
- [ ] Configure Cloudinary or S3; store only HTTPS URLs.
- [ ] Add Redis for catalog/session/rate-limit caching.
- [ ] Add WebSocket/SSE gateway for chat and shipment updates.
- [ ] Add push notifications for Android/iOS/PWA.
- [ ] Add real GPS/maps provider and driver tracking permissions.
- [ ] Add rate limiting, CSRF/CORS policy, request validation, audit logs and secrets management.
- [ ] Run load, payment, inventory-concurrency and disaster-recovery tests.
- [ ] Build Flutter customer/seller/driver apps against the same REST API.
- [ ] Deploy web and API behind HTTPS with monitoring and centralized logs.
