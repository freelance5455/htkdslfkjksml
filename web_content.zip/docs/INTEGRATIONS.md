# Integrações externas

A base inclui adaptadores para AI e para ferramentas de desenvolvimento, mas não embute serviços externos dentro do APK/browser. Para Sora ou Veo, use um backend/bridge autorizado e mantenha chaves fora do cliente.

Cursor, Windsurf, Bolt.new, Lovable e Muse podem ser usados como ferramentas de desenvolvimento do projeto. O runtime do NIVEX continua independente dessas ferramentas.

Os módulos Canvas/WebGL/WebGPU, WebCodecs/FFmpeg WASM e Workers ficam como pontos de integração do motor principal.
