# مكتبات قنوات المدرّسين داخل منارة

تاريخ التحقق: ١١ تشرين الثاني ٢٠٢٦. طلب المستخدم عرض محتوى القنوات كاملاً بدلاً من الاكتفاء بمقاطع منتقاة. لا تنسخ منارة الفيديوهات ولا تنزّلها أو تعيد استضافتها؛ تستخدم مشغّل YouTube المضمّن وقائمة الرفع العامة التي يقدمها YouTube لكل قناة.

## الطريقة الرسمية والحدود

- توثيق YouTube IFrame Player API يذكر أن `cuePlaylist` و`loadPlaylist` يدعمان قوائم التشغيل، ويمكن أن يستقبلا معرّف القائمة ونوعها؛ توثيق معاملات المشغّل يحدد `listType=playlist` و`list=PLAYLIST_ID` لتضمين قائمة كاملة، من دون الحاجة لمعرّف فيديو منفرد في مسار الرابط.
- يشرح YouTube Data API أن معرّف قائمة الرفع للقناة موجود في `contentDetails.relatedPlaylists.uploads` عند استدعاء `channels.list(part=contentDetails, id=...)`؛ وتسترجع العناصر عبر `playlistItems.list`. قوائم الرفع أدناه طابقت صفحات YouTube العامة نفسها من حيث الاسم والمالك والعناصر الظاهرة، دون استدعاء Data API أو الحاجة إلى مفتاح API عند تشغيل التطبيق.
- توثيق YouTube يؤكد أن شروط API تنطبق على المشغّل المضمّن، وأن المقاطع المقيّدة بالعمر لا تعمل على معظم مواقع الطرف الثالث وقد تعيد توجيه المشاهد إلى YouTube. كذلك يمكن للمالك تعطيل التضمين أو حذف فيديو. لا تحاول منارة تجاوز هذه القيود، ولا تفتح الموقع الخارجي تلقائياً؛ يستخدم العرض نطاق `youtube-nocookie.com` ويبدأ التحميل بعد ضغط الطالب فقط.
- قائمة «الرفع» تتحدث لدى YouTube مع ما ينشره صاحب القناة؛ أعداد الفيديوهات التالية لقطات من يوم التحقق وليست أعداداً ثابتة في واجهة التطبيق. القائمة الكاملة قد تضم مقاطع قصيرة أو مواد غير خاصة بالبكالوريا السوري العلمي؛ تبقى المقاطع المنهجية المنتقاة موضّحة منفصلة.

## القنوات وقوائم الرفع المتحققة

| القناة/المدرس المعروض | القناة الرسمية | معرّف القناة | معرّف قائمة الرفع المتحقق | عدد ظاهر يوم التحقق |
|---|---|---|---|---:|
| MK Academy | https://www.youtube.com/@mk.syr.academy | `UCyO_aJBFLaPvfyjW2MZqtdw` | `UUyO_aJBFLaPvfyjW2MZqtdw` | ٤٤٢ |
| فريق Pixel التعليمي | https://www.youtube.com/@PIXEL-8LEG | `UCmnRJbs89z4GKG6v8grbPzw` | `UUmnRJbs89z4GKG6v8grbPzw` | ٩٩٧ |
| علي الدرساني | https://www.youtube.com/@AliAldarsani | `UCC3XJtbbB82OqiznzAW8rzA` | `UUC3XJtbbB82OqiznzAW8rzA` | ١٢٥ |
| منصة طريقي (القناة المرتبطة بأنس أحمد) | https://www.youtube.com/@myway.education | `UCEskgtF0DwQsB8NBJiTWmAg` | `UUEskgtF0DwQsB8NBJiTWmAg` | ٧٨٧ |
| همام حمدان | https://www.youtube.com/@homamhamdan2 | `UCExkNkpBU67nm88a6wcDuTQ` | `UUExkNkpBU67nm88a6wcDuTQ` | ٦٨٦ |
| كرم كيوان | https://www.youtube.com/@Karam_Arabic | `UCSXO8v6sxIPMOCowF9l8ONA` | `UUSXO8v6sxIPMOCowF9l8ONA` | ٩٢ |

تحقق كل معرّف قائمة من صفحة YouTube عامة مستقلة، وتطابق عنوان «Uploads from …» واسم المالك مع القناة المقابلة:

- https://www.youtube.com/playlist?list=UUyO_aJBFLaPvfyjW2MZqtdw
- https://www.youtube.com/playlist?list=UUmnRJbs89z4GKG6v8grbPzw
- https://www.youtube.com/playlist?list=UUC3XJtbbB82OqiznzAW8rzA
- https://www.youtube.com/playlist?list=UUEskgtF0DwQsB8NBJiTWmAg
- https://www.youtube.com/playlist?list=UUExkNkpBU67nm88a6wcDuTQ
- https://www.youtube.com/playlist?list=UUSXO8v6sxIPMOCowF9l8ONA

## المصادر الرسمية

- IFrame Player API: https://developers.google.com/youtube/iframe_api_reference
- معاملات التضمين وقوائم التشغيل: https://developers.google.com/youtube/player_parameters
- استرجاع فيديوهات القناة وقائمة الرفع عبر Data API: https://developers.google.com/youtube/data/guides/implementation/videos
- مساعدة YouTube حول تضمين الفيديوهات وقوائم التشغيل والقيود: https://support.google.com/youtube/answer/171780?hl=en
