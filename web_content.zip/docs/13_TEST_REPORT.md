# 13. Test report (what was actually run, and what was not)

Run on 28 Nov 2026 in the build sandbox (Python 3.12, Node 22). Backend total: **747 tests in 33 modules, 0 failures**; mobile: **11 tests, 0 failures**.

| Suite | Result |
|---|---|
| Existing website tests (30 modules, 704 tests) | all pass after changes (only change: the 5 hard-coded migration lists, see `11`) |
| New backend tests: `test_mobile_api` (20), `test_mobile_learning` (13), `test_store_billing` (10) | 43 pass: auth/refresh rotation and replay revocation, cookie ignored, CORS, secrets never in `/config`, draft hiding, entitlement gating of lessons/quizzes/assignments, signed media (range, binding, deactivated user), quiz answer hiding, certificate PDF, notifications isolation, content-version bump from any change, account deletion, prelaunch, store verify idempotency, cross-account receipt rejection, scope independence, refund revoke, Apple certificate-chain verification, push no-op and dead-token cleanup |
| Mobile unit tests (3) + end-to-end (8) | 11 pass. The **real app modules** (API client, token refresh, offline cache, every main screen) ran against a **real backend** with seeded data, through a minimal DOM. This found and fixed two real bugs (stray "null" text; no offline cache for signed-in data) |
| `npm run check` (static gate) | passes: syntax, no unsafe HTML injection, no secrets, tokens not in localStorage, no bank-transfer UI, no JSS/SS, CSP present |
| Deployment scripts | export → import (checksums + counts), refusal to overwrite, backup (integrity-checked), restore, wrong-confirmation cancel, corrupt-backup rejection: **run on throw-away data and behaved correctly**. `publish_web_bundle.py` tested end to end (zip → hosted → `/config`) |
| `patch_android.py` | run twice (idempotent) on a **sample** manifest/gradle file, not on a real generated project |

## NOT verified (no network, devices, accounts or Mac here)
Generating `android/` and `ios/`; Gradle/Xcode builds; running on any phone or emulator (so **no visual QA**, no screenshots, no performance numbers on real Nigerian networks); video playback on devices; Capacitor plugins (secure storage, push, updater, purchase); live-update apply/rollback on a device; live Google/Apple billing calls; FCM delivery; `bootstrap_server.sh`, systemd, Caddy/Tunnel on a real server; CI templates; any store review. Expect a first-device debugging round.
