# StreetRush 3D — Game Design

## Core loop
Start race -> dodge traffic -> collect coins -> use nitro -> finish distance target -> earn coins -> unlock cars -> repeat.

## Controls
Left/right: steer.
Nitro: temporary speed boost.
Pause: stop the race.

## Monetization-ready structure
The project is intentionally ad-free. Optional future monetization can use cosmetic cars, skins, and track packs. Real-money digital purchases must be implemented through the Android/Google Play billing system when published.

## Originality
All gameplay code and vector-style visuals in this project are created for this project. This does not guarantee that no similar racing concept exists elsewhere.
