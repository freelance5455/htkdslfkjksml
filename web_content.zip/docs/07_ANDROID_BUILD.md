# 7. Android: build, test, release (.aab)

**Needs a PC or Mac** (Windows/Linux/macOS) with Node 20+, JDK 17+, Android Studio. Termux cannot build the app.
**Package/application ID:** `com.dagbadigitalacademy.app` (change in `mobile/capacitor.config.json` **before the first upload**; it can never be changed afterwards).

```
cd mobile
bash scripts/setup_native.sh android     # installs packages, generates icons/splash from resources/, creates android/, patches manifest + signing
bash scripts/gen_android_keystore.sh     # once: creates the upload key + android/keystore.properties (git-ignored)
npx cap open android                     # Android Studio: run on a phone/emulator to test
cd android && ./gradlew bundleRelease    # → app/build/outputs/bundle/release/app-release.aab
```
Not yet run here (no network/SDK): generating `android/`, the patch script against a real generated project (tested only on a sample), Gradle build, emulator run.
Check `git diff android/` after the patch script. Add `google-services.json` (Firebase) to `android/app/` for push.

**Play Console steps:** create app → Play App Signing (accept) → upload the `.aab` to **Internal testing** → add testers → fix pre-launch report → (personal developer accounts created after Nov 2023 must run a **closed test with at least 12 testers for 14 days** before production; verify current requirement in Play Console) → store listing (`store/`) → Data safety → content rating → target audience → App content declarations → Production.
**Deep links:** get the signing certificate SHA-256 (Play Console → App signing) and set in admin settings `mobile.android_package` and `mobile.android_sha256` so `https://dagbadigitalacademy.com/.well-known/assetlinks.json` is served.
**Back button, offline banner, file/camera pickers:** implemented in the web layer (`app.js`, `native.js`; file inputs open the system picker/camera on Android).
**Target API level:** Capacitor templates track Google's current requirement; confirm the "target API" warning in Play Console before upload.
