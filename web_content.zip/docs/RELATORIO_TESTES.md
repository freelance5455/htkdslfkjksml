## Relatório de testes v1.8.0

- Sintaxe JavaScript: verificada.
- Fluxo de pedido de saída: proposta imediata, clube diferente do atual, transferência e salvamento.
- Confirmação de transferência dentro do aplicativo.
- Gerenciamento e exclusão individual de carreiras com confirmação SIM/NÃO.
- Compatibilidade de saves anteriores preservada pela migração de versão.

# Relatório de testes — Carreira Craque v1.7.0

Data: 25/10/2026

## Correção principal
- `eligibleTargets()` tinha um limite de diferença de nível muito restritivo para atletas com overall abaixo de 65. Como os níveis dos clubes começam na faixa dos 60 e tantos, um atleta novo com OVR 60 podia ficar sem nenhum destino elegível.
- `requestExit()` apenas registrava o pedido e aumentava a probabilidade futura; não criava proposta e dependia de novas avaliações aleatórias. O pedido podia parecer sem efeito.
- Agora, pedir saída dispara sondagem imediata, cria uma proposta compatível quando há outro clube cadastrado e apresenta notificação. O usuário ainda decide se aceita, negocia ou recusa; não ocorre transferência automática.

## Testes executados
Comando: `npm run test:logic`
Resultado: `PASS`.

Inclui os testes anteriores e novos casos para:
- pedido de saída com OVR 60;
- criação imediata de uma única proposta para clube diferente do atual;
- notificação vinculada à proposta;
- aceitação da proposta e atualização de clube, contrato e histórico;
- persistência da transferência no autosave e recarga da carreira;
- simulação de 500 placares para verificar vantagem estatística do time mais forte.

Também foi executado `node --check` sobre o JavaScript extraído de `index.html`, sem erros de sintaxe.

## Limitação conhecida
O simulador usa níveis internos de clubes e regras de compatibilidade aproximadas. Não consulta um servidor de transferências real nem implementa integralmente janelas oficiais, cláusulas ou negociação financeira entre clubes.
