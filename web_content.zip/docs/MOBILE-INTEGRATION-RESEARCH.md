# Mobile integration decisions and sources

Research checked 5 November 2026. These official references establish the native build and provider constraints used by this repository's mobile extension.

Expo SDK 58 was released on 15 October 2026 and uses React Native 0.88. The project will use this SDK family and a custom development/release build because SQLCipher and the billing/ad SDKs contain native code; Expo Go is not a production verification surface. [1] [2]

Expo SQLite supports SQLCipher on Android and iOS when `useSQLCipher` is enabled in the config plugin and the native app is rebuilt. Opening the database is not enough to prove it is encrypted: check that `PRAGMA cipher_version` returns a value before writing sensitive records, then set the key. SQLCipher is not supported in Expo Go. [3]

Expo SecureStore uses Android Keystore and iOS Keychain for local secret storage. Android SecureStore entries are removed when the app is uninstalled, so they are not a backup. Android backup must exclude those preferences because the original Keystore key does not survive restore. Biometric-protected values can also become inaccessible after biometric enrollment changes. The app therefore needs user-controlled export and clear recovery limits. [4]

Local notification scheduling requires a permission-aware flow, a notification handler and cancellation identifiers. Scheduling itself does not guarantee delivery; operating-system permission and state also matter. A date trigger can schedule reminders at the user's 3-days, 1-day and due-date offsets. Reminder screens must show permission/schedule state accurately and leave finance features usable when alerts are unavailable. [5]

For native CSV export, use the current `expo-file-system` `File` and `Paths.document` API, and share the resulting file with Expo Sharing. Avoid the deprecated legacy string-write method. For PDF export, `expo-print` `printToFileAsync` renders local HTML and returns a PDF URI; share the URI with the Android/iOS system sheet. [6] [7]

The React Native Google Mobile Ads SDK requires a native development build. Its Expo config plugin writes app IDs into native projects, and changes require a rebuild. Use test ad units during development and obtain consent before SDK initialization. Real ads require an owner AdMob account and app IDs; this repository has none configured. [8] [9]

Google Play treats subscriptions, ad-free functionality, extra app features and cloud-software services as digital goods for which Play Billing is generally required on Play-distributed Android apps, subject to policy exceptions/programs. Google recommends a secure backend for purchase verification and subscription state; the Developer API `purchases.subscriptionsv2.get` needs the package name, token and authorized Play Developer access. No Play Console account, package listing, subscription product or service account has been connected. [10] [11] [12]

Expo's official guide identifies `expo-iap` as an Expo-compatible library for native in-app purchases. The maintained OpenIAP monorepo keeps separate `expo-iap` and `react-native-iap` libraries; both need a development build rather than Expo Go. Billing must remain unavailable until store products and trusted verification are configured. [13] [14]

Apple digital purchases use StoreKit / App Store In-App Purchase for iOS. No Apple Developer membership or App Store Connect record is connected. [15]

EAS Build is Expo's hosted app-binary service and can manage signing credentials. Android production builds default to AAB for Play; an APK profile can be set for internal installation. In a monorepo, run EAS commands from the mobile app directory and keep `eas.json` there. A real EAS build requires the owner's Expo/EAS access and configured signing/project identity. This repository is a Webdev website, not a managed Mobile project, so a Manus mobile build action cannot produce its APK/AAB; this repository can prepare EAS profiles and phone-friendly instructions instead. [16] [17] [18]

## References

[1]: https://expo.dev/changelog/sdk-58 "Expo SDK 58 changelog"
[2]: https://docs.expo.dev/versions/v58.0.0/ "Expo SDK 58 documentation"
[3]: https://docs.expo.dev/versions/v58.0.0/sdk/sqlite/ "Expo SQLite and SQLCipher documentation"
[4]: https://docs.expo.dev/versions/v58.0.0/sdk/securestore/ "Expo SecureStore SDK documentation"
[5]: https://docs.expo.dev/versions/v58.0.0/sdk/notifications/ "Expo Notifications SDK documentation"
[6]: https://docs.expo.dev/versions/v58.0.0/sdk/filesystem/ "Expo FileSystem SDK documentation"
[7]: https://docs.expo.dev/versions/v58.0.0/sdk/print/ "Expo Print SDK documentation"
[8]: https://docs.page/invertase/react-native-google-ads/installation/expo "React Native Google Mobile Ads Expo installation"
[9]: https://docs.page/invertase/react-native-google-ads "React Native Google Mobile Ads documentation"
[10]: https://support.google.com/googleplay/android-developer/answer/10281818?hl=en "Understanding Google Play payments policy"
[11]: https://developer.android.com/google/play/billing "Google Play Billing documentation"
[12]: https://developers.google.com/android-publisher/api-ref/rest/v3/purchases.subscriptionsv2 "Google Play subscriptionsv2 API"
[13]: https://docs.expo.dev/guides/in-app-purchases/ "Using in-app purchases with Expo"
[14]: https://github.com/hyodotdev/openiap/tree/main/libraries/expo-iap "Expo IAP in the OpenIAP repository"
[15]: https://developer.apple.com/in-app-purchase/ "Apple In-App Purchase"
[16]: https://docs.expo.dev/build/introduction/ "EAS Build"
[17]: https://docs.expo.dev/build-reference/apk/ "Build APKs for Android devices"
[18]: https://docs.expo.dev/build-reference/build-with-monorepos/ "Set up EAS Build with a monorepo"
