# Escudos de clubes — Carreira Craque v1.8.7

## Ajuste dos quatro escudos reportados

As referências abaixo substituem as imagens antigas que podiam aparecer com fundo branco ou apontar para o Botafogo do Rio. O CSS do jogo mantém `background: transparent`, sem moldura decorativa e com `object-fit: contain`.

- Mirassol — PNG transparente atual: `https://www.footylogos.com/dls/logo/mirassol-fc.png`
- Fortaleza — PNG transparente atual: `https://www.footylogos.com/dls/logo/rgba-v1/fortaleza.png`
- Grêmio Novorizontino — PNG transparente atual: `https://www.footylogos.com/dls/logo/rgba-v1/gremio-novorizontino.png`
- Botafogo-SP (Ribeirão Preto) — PNG transparente correto: `https://www.footylogos.com/dls/logo/rgba-v1/botafogo-sp.png`

## Limitação

Esses quatro PNGs são carregados de URLs externas, não estão incorporados no pacote; por isso, dependem de conexão com a internet. A referência do Botafogo-SP é específica do clube de Ribeirão Preto, não do Botafogo de Futebol e Regatas (RJ). Os demais recursos do jogo e os dados de carreira foram preservados.
