# 6. Backup and recovery

**What is backed up:** the SQLite database (consistent online copy using SQLite's backup API, integrity-checked, gzip, SHA-256 list), and uploads (receipts, videos, images). Runs 4 times a day (timer); uploads archived nightly. Local copies kept 30 days. **Set `BACKUP_REMOTE` (rclone) so a copy exists off the server**; without it the script prints a warning every run, because a backup on the same disk is not a backup.
Install rclone, then `rclone config` once (Backblaze B2, S3-compatible, Google Drive, etc.).

**Check monthly:** (1) a recent backup exists off-site, (2) do a restore drill on a spare machine: `restore.sh dagba-....db.gz dagba-uploads-....tar.gz`.

## Restore (`deploy/restore.sh`)
Stops the site, copies the *current* data to `pre-restore-<time>/`, asks you to type `RESTORE`, verifies the backup's integrity and refuses corrupt files, switches the database, unpacks uploads, restarts. Tested here: damaged DB restored to the correct user count; wrong confirmation cancels; corrupt file rejected before anything is touched.

## Disaster scenarios
| Situation | Action |
|---|---|
| Bad admin edit / deleted course | restore a recent DB backup into a **spare** folder, copy the rows you need (or full restore if severe) |
| Server lost | new VPS → `bootstrap_server.sh` → restore latest off-site backup → deploy release → move tunnel/DNS |
| Server compromised | new VPS, rotate `SECRET_KEY` (signs all out), rotate payment/Firebase/store keys, restore from a backup older than the incident |
| Mobile app key lost | Android: Play App Signing lets Google reset the upload key via support. Keep the keystore backed up anyway. iOS: certificates can be re-issued in your Apple account |
