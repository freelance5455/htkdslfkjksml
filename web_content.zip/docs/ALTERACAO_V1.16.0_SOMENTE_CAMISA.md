# Carreira de Craque v1.16.0 — somente camisa do jogador

## Alterações implementadas
- Removida a exibição visual do rosto/cabelo/corpo do atleta nas telas de criação, início e perfil.
- A representação do jogador agora é uma ilustração de camisa, com o nome (ou apelido, quando definido) e o número atuais.
- A tela antes chamada de personalização foi substituída por **Camisa do jogador**; ela não oferece controles de rosto, pele, cabelo, barba ou acessórios.
- A camisa usa as cores e o padrão cadastrados para o clube atual e acompanha mudanças de clube, nome/apelido e número.
- O botão dessa tela leva à seção existente de solicitação de número.
- O ícone do cabeçalho deixou de mostrar iniciais do atleta e passou a usar um símbolo de camisa.
- Não houve alteração intencional na lógica de carreira, atributos, partidas, calendário, contratos, dinheiro, transferências ou formato dos saves.

## Verificações executadas
- `node --check` no JavaScript embutido: aprovado.
- `node tests/smoke-test.js`: aprovado, incluindo criação de carreira, telas, transferências, numeração e persistência.
- `unzip -t` no pacote final: executar após empacotamento.

## Limitação visual conhecida
A camisa é uma ilustração gerada com as cores/padrões cadastrados do clube; ela não pretende ser uma reprodução fotográfica exata de cada uniforme oficial. Os uniformes fotográficos do catálogo anterior não são necessários para esta representação.
