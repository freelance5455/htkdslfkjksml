# TO‘LOVCHI Privacy Policy (Draft)

**Status:** Owner/legal review required. This is a product-accurate draft, not legal advice. Before public release, the owner must complete the legal entity name, privacy contact, effective date, retention/deletion terms and any jurisdiction-specific notices, and obtain qualified local review.

## What the app does

TO‘LOVCHI is designed as a local personal-finance ledger. The inspected mobile source does not connect to a bank, require a customer account, or send customers’ income, expenses, debts, balances, Zakat inputs or transaction history to the Super Admin Dashboard. The dashboard currently has no customer-finance feed.

## Local storage and security

The app uses a local SQLite database configured for SQLCipher in native builds. Its random database key is stored separately in Android/iOS secure storage. A PIN is an app-access control, not the database key. Native encryption and key-storage behavior have not yet been verified on a physical device. A user may create a portable file encrypted with AES-256-GCM using a PBKDF2-HMAC-SHA256 key derived from a passphrase they choose. TO‘LOVCHI does not upload the backup or reset its passphrase. Users may select an external destination in the system share sheet; the recipient's terms then apply. Without both a usable backup file and its passphrase, data may be unrecoverable.

## Notifications and exports

Optional reminders are scheduled locally by the operating system. Their notification text is generic and the payload contains an entity identifier and reminder type, not the amount, counterparty name or note. The operating system may display notifications outside the app; users can control them in device settings.

CSV and PDF reports are created only after the user chooses an export action. The operating-system share sheet can send the selected file to another app or recipient. The owner of that receiving service controls its further use and retention.

## Services not active

Automatic/cloud backup, family sharing, advertising and in-app purchases are not active. The optional encrypted backup is an explicit user-controlled file export and restore. If the owner later enables third-party analytics, ads, purchases, accounts, sync or cloud backup, this policy and the app’s consent flows must be reviewed and updated before those data flows begin.

## Deletion and contact

Users can clear sample entries or delete all finance records from Settings. Deletion is local and cannot be undone. Because there is no account or server-side finance store, the app has no remote copy to restore or remotely erase.

Privacy contact (owner must complete): **[Legal entity] · [privacy email] · [business address or country]**. Do not send a database key or financial export to support.
