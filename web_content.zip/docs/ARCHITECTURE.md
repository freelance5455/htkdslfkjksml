# Arquitetura

`core` contém o domínio e catálogo de efeitos. `engine` contém timeline e exportação/renderização. `services` cuida de armazenamento, segurança, capacidades e API de identidade. `components` contém UI.

Bolt.new, Lovable, Muse, Windsurf e Cursor são ferramentas externas de desenvolvimento. O app não precisa carregar essas plataformas para funcionar; o código pode ser continuado nelas ou no VS Code.

A camada de renderização está isolada para permitir trocar o preview CSS por Canvas/WebGL/WebGPU e evoluir o exportador para WebCodecs + FFmpeg/WASM sem reescrever a interface.
