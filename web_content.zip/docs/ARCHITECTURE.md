# Architecture

Public UI -> hash router -> page renderers -> local state -> localStorage. Admin UI uses the same state layer and CRUD helpers. Service worker provides offline caching for the static shell.