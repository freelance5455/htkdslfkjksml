# Contractor Pro V18 — Architecture

## 1. Overview
Offline-first client + small sync server. The app is fully usable with no network; the server adds accounts,
multi-device sync, licensing and client portals.

```
 Phone/Tablet (WebView APK)                          Server (Node, zero dependencies)
 ┌──────────────────────────────┐   HTTPS/JSON     ┌──────────────────────────────┐
 │ UI + business logic (index.html) │ ───────────▶ │ Auth (OTP/password, JWT+session) │
 │ localStorage = source of truth │   push/pull     │ Sync (per-workspace snapshots) │
 │ Cloud client: merge + tombstones│ ◀───────────  │ License · Portal · Audit log   │
 └──────────────────────────────┘                  │ data.json (single file)        │
                                                    └──────────────────────────────┘
```

## 2. Client
- Single HTML file (no build, no external requests) -> reliable in HTML-to-APK WebViews and fully offline.
- 7 UI languages (fa, en, ar, tr, ru, fr, de); RTL; Persian/Hijri/Gregorian calendars; multi-currency; unit systems.
- Cloud client (`Settings > Cloud & Sync > Connect & Sync`): email OTP login, silent token refresh (single-flight),
  auto-sync 8 s after changes, every 5 min, and when back online. Refresh token lives in its own storage key and
  is never part of a snapshot.
- Endpoint rule: https required; http only for localhost/LAN.

## 3. Sync model
- Unit of exchange: full snapshot of business records (all modules except device-local notifications).
- Client always **pulls -> merges -> pushes** with `baseSeq`; if another device pushed meanwhile the server answers
  409 `SYNC_CONFLICT` with the newer snapshot, the client merges again and retries once.
- Merge is record-level by `id`: newest `updatedAt || createdAt` wins; deletes propagate through tombstones
  (kept 90 days); ids are validated (reserved names rejected); remote data is treated as untrusted.
- Server keeps the last N snapshots **per workspace** (default 20), cursors are monotonic sequence numbers.

## 4. Security
- Passwords: scrypt. Access JWT 15 min + server-side session; refresh tokens rotate and are revoked on logout / password change.
- Rate limits per IP and per email; constant-time admin key check with lockout; random secrets generated at first start.
- Portal pages: CSP, nosniff, no-referrer, frame-deny, output escaping; revocable tokens (hashed at rest).
- Audit log per workspace (login, password, sync, license, portal events). Data file mode 600, atomic writes.

## 5. Tests
`npm test` (server + security regression) · `npm run test:e2e` (two real browser "devices" + real server: create,
edit, delete, concurrent push, merge safety, sign-out).

## 6. Known limits (honest list)
- Whole-snapshot sync: fine for one business, not for very large data or many simultaneous editors per record;
  two devices editing the *same field* resolve by newest-wins, not field-level merge.
- JSON-file storage, single process: great for a pilot (Termux/VPS), not for thousands of tenants.
- localStorage (~5 MB) limits photos/documents; OTP delivery is console-only in dev; billing and AI return 501.
- Roles other than owner are modelled but not yet enforced; no member invitation flow yet.

## 7. Roadmap to enterprise
1. PostgreSQL + object storage (photos/PDF), migrations, backups.  2. Real OTP provider (email/SMS), HTTPS reverse proxy.
3. Per-record/field sync API (replace snapshots).  4. RBAC + member invitations, SSO (SAML/OIDC), SCIM.
5. Billing adapters (Play/App Store/Stripe), invoices PDF, tax/e-invoice per country.
6. Observability (structured logs, metrics, alerts), CI/CD, pen-test, SOC 2 / GDPR processes.
