# OPUX 2.2 — Implementation Report

Built on OPUX 2.1. Nothing was rebuilt. All changes are additive patches to
`app/src/main/assets/index.html` (the single-file app) plus three small bridge
methods in `MainActivity.java`.

## Status legend
- **Implemented** = code written in the project.
- **Tested in browser** = run in headless Chromium (Playwright, 390×844 mobile viewport) with a seeded OPUX 2.1-format backup.
- **Built** = Gradle build / APK produced. **NOT DONE** (see Limitations).
- **Tested on real Android** = **NOT DONE**.

## 1. Productivity intelligence — Implemented, Tested in browser
- Each activity has a classification: **Productive Work**, **Neutral**, **Leisure / Personal**, or **Unclassified** (default).
  Set it when creating an activity (Settings), when editing it (Settings), or from More → Productive time.
  Small glyphs ◆ ◇ ○ appear on activity chips; unclassified activities show nothing.
- Per-day `dayCls(date)` returns total / work / neutral / leisure / unclassified and the productive %.
  Unclassified time is never productive. The existing `prod()` now uses this, so Records, Stats and Home use the same numbers.
- **Most Productive Day** (More → Productive time, also linked from Stats): date, productive time, total tracked,
  productive %, difference vs. your average, runner-up and previous best. It ranks by productive time, never by longest tracked day.
- Also: best day this week / this month, best and current productive streak (a streak day = at least your daily goal,
  or 1 minute if no goal is set; the rule is shown on screen), average productive time per recorded day,
  productive hours over time (7/14/30/90 day bars with average line), productive vs neutral vs leisure vs unclassified (Today / 7 days / 30 days / All).
  A productivity breakdown also appears on the Tracker and History day pages.

### Historical data integrity (answer to your question)
OPUX stores each day as a list of `{activity, minutes}`; a day has no label of its own. Therefore:
- **Changing a classification changes past statistics by default**, because past days point at the activity.
- To keep this safe, changing an activity that has history opens a dialog showing how much recorded time is affected and offers
  **Apply to all history** or **From today onward** (past days keep the old class, via an effective-from log) or Cancel.
- The log is visible under *Classification history* and any entry can be removed to revert that change.
- Time entries are never edited by any of this (verified by test). No historical productivity data is invented.
- Migration: activities that were marked productive (`p:1`) in 2.1 become Productive Work. Everything else is **Unclassified**, not guessed.
  The legacy `p` flag is kept in sync, so older exports/imports still work.

## 2. Home atom — Implemented, Tested in browser
Canvas 2D with its own 3D projection (no libraries, fully offline). Lit nucleus with breathing, specular and rim light;
three tilted orbits with depth-sorted electrons, trails, glow and dust parallax; idle drift; drag to rotate with inertia;
mouse-hover tilt; tap an electron (productive today / most time today / goal or untracked) or the nucleus for a real-data readout;
ripple + haptic feedback; an intro spin-up when entering Home. Pauses when the tab is hidden or you leave Home.
**Reduced motion**: follows the device setting, or override in Settings (Auto / Always / Never). When reduced, the atom is a still frame
(drag and tap still work), flips shorten and confetti is off.
Three.js was **not** used: no offline copy is available in this environment, and Canvas 2D covers the need with no added weight.

## 3. Playground — Implemented, Tested in browser
More → Playground, plus Quick actions. A registry (`PLAY` array + `VX.<id>` view) lets you add tools without redesign.
- **Spin the Wheel**: add/edit/remove options (2–24), rename, multiple saved wheels, templates (study/subject wheels use your Productive Work activities when you have ≥2),
  6 colour palettes, ticking sound + sound toggle, pointer flick, decelerating spin, winner highlight, confetti, reset.
  The winner is drawn first with unbiased random numbers (crypto + rejection sampling), then the animation lands on it.
- **Coin Toss**: real 3D coin (thickness layers), toss arc and shadow, 1/3/5/10 flips, sound, saved history, reset.
- **Random Number**: min/max, inclusive, validated, optional history.
- **Decision Picker**: choices, animated pick, saved frequent sets.
- **Task Picker**: picks from your existing activities (OPUX has no task list, so none was invented); can start a focus session or the tracker timer.
- **Focus Session**: choose activity + duration, start / pause / resume / finish early. Nothing is written to the tracker until you confirm the minutes. Survives leaving the screen.

## 4. OPUX Intelligence (ChatGPT-assisted) — Implemented, Tested in browser
More → ChatGPT prompts. **No AI model, no API key, no network call, nothing sent automatically.** OPUX only builds text; you copy it and paste it into ChatGPT.
- Daily Brief (with the "Prepare ChatGPT Analysis" button), Productivity Analysis (7/14/30 days), Task Breakdown, Weekly Review, Prompt Studio.
- Prompts contain real figures only. Days without a record are labelled "no record", not zero; unclassified time and the absence of a task list are stated.
  Entry notes are excluded unless you tick the option.
- Prompt Studio: create / edit / delete / categorise / copy; 5 editable starter prompts; `{{placeholders}}` (today, week, 7/30 days, top activities, best day) are filled with live data at copy time.
- Buttons: Copy, Copy & open ChatGPT (opens https://chatgpt.com/), Share. New Android bridge methods `copyText`, `shareText`, `openUrl` (with browser fallbacks).

## 5. Quality-of-life changes (each fixes a real issue)
- Productivity breakdown on Tracker/History day pages; productive share on Home progress; Productivity link on Stats.
- Quick actions gained Focus, Productivity, Playground, Intelligence.
- Empty states on every new screen explain what to do next.
- Back button/gesture closes 2.2 sheets first.
- Inputs avoid re-rendering on blur where it would swallow the next tap.
- Reduced-motion control and Playground sound toggle in Settings.

## 6. Data model additions (all inside the existing `ext` object; `h24v1` key unchanged)
`acts[].cls`, `ext.cl` (classification log), `wh/whSel` (wheels), `cn` (coin), `rn`, `pk`, `tp/tpInit`, `fs` (confirmed focus sessions),
`fx` (running focus session), `pr/prSeed` (prompts), `rm`, `ps`. All are validated on load/import by `ext22()`; older backups import unchanged.
