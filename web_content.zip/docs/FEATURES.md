# CINEMA GOLD — قابلیت‌ها و وضعیت فنی

## قابلیت‌های موجود در بسته توسعه
- اپ وب فارسی و RTL
- فهرست فیلم‌ها و سریال‌ها، جستجو و ژانر
- جزئیات محتوا، نظرات و امتیازدهی
- پخش آنلاین با URLهای واردشده توسط مدیر
- ثبت‌نام و ورود با نام کاربری و رمز عبور، بدون پیامک
- پیامک فعلاً غیرفعال است و فقط برای فاز تست آینده طراحی خواهد شد
- هش رمز عبور PBKDF2 و ارتقای تدریجی هش‌های قدیمی
- نشست قابل لغو و خروج از حساب
- دوره عرضه رایگان؛ اشتراک در حالت پیش‌فرض خاموش
- تیکت پشتیبانی و گفت‌وگوی کاربر/مدیر
- گزارش خرابی محتوا و API تغییر وضعیت گزارش
- پنل وب برای مدیریت محتوای موجود و مشاهده پشتیبانی
- سورس اندروید با Kotlin، Compose و Media3
- نگهداری رمزنگاری‌شده توکن اندروید با Android Keystore

## APIهای افزوده‌شده

### حساب
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/auth/me`
- `POST /api/me/password` — تغییر رمز و لغو همه نشست‌های فعال

### پشتیبانی
- `POST /api/me/support/tickets`
- `GET /api/me/support/tickets`
- `GET /api/me/support/tickets/{id}`
- `POST /api/me/support/tickets/{id}/messages`
- `GET /api/admin/support/tickets`
- `GET /api/admin/support/tickets/{id}`
- `POST /api/admin/support/tickets/{id}/messages`
- `PATCH /api/admin/support/tickets/{id}`

### گزارش محتوا
- `POST /api/reports`
- `GET /api/admin/reports`
- `PATCH /api/admin/reports/{id}`

## مواردی که هنوز باید برای نسخه انتشار پیاده‌سازی شوند
- PostgreSQL و Alembic migrations
- سرویس ایمیل و بازیابی رمز
- پیامک آزمایشی و کنترل‌پذیر از پنل
- سرویس پخش امن، Signed URL و DRM در صورت پشتیبانی مجوزدهنده
- درگاه پرداخت واقعی و تطبیق تراکنش سمت سرور
- مدیریت کامل حساب‌ها، تعلیق، خروج از همه دستگاه‌ها و audit log
- مدیریت کامل فصل/قسمت و اتصال لینک‌های رسانه به قسمت‌ها
- تست یکپارچه Android و ساخت APK امضاشده
- بکاپ زمان‌بندی‌شده و بازیابی دیتابیس

## CINEMA GOLD 3.1 storage update

- A selectable storage adapter now supports JSON (default) and experimental PostgreSQL JSONB records.
- `backend-py/migrate_json_to_postgres.py` migrates current JSON collections without overwriting non-empty destination collections unless `--replace` is explicitly supplied.
- PostgreSQL setup instructions and multi-instance/concurrency limitations are documented in the root README.
- PostgreSQL has not been integration-tested against a live database in this environment; production rollout remains blocked on row-level transactional business operations and deployment hardening.

## نسخه ۳٫۲ — امنیت حساب

- کاربر واردشده می‌تواند رمز عبور خود را با ارائه رمز فعلی تغییر دهد.
- رمز جدید باید حداقل ۱۰ نویسه داشته باشد و تکرار آن با رمز جدید یکسان باشد.
- پس از تغییر رمز، تمام نشست‌های فعال آن حساب لغو می‌شوند و ورود مجدد با رمز جدید لازم است.
- API: `POST /api/me/password` با فیلدهای `current_password`، `new_password` و `confirm_password`.


## نسخه ۳.۳ — مدیریت کاربران و ممیزی
- فهرست کاربران با فیلدهای امن و حذف فیلد رمز از پاسخ API.
- مسدودسازی/فعال‌سازی کاربر از پنل مدیر.
- باطل‌سازی نشست‌های کاربر هنگام مسدودسازی.
- محافظت از آخرین مدیر فعال و جلوگیری از مسدودسازی مدیر جاری توسط خودش.
- گزارش رویدادهای مدیریتی با شناسه مدیر، نوع اقدام، موضوع، شناسه هدف و زمان UTC.
- دسترسی به گزارش ممیزی فقط برای مدیران و محدودیت خروجی به ۳۰۰ رویداد.


## پخش نسخه ۳.۵
- لینک‌های پخش و دانلود با توکن امضاشده و تاریخ انقضا صادر می‌شوند.
- زمان تماشای هر کاربر به‌صورت مستقل ذخیره می‌شود.
- انتخاب کیفیت/مسیر صوتی/زیرنویس در رابط پخش وجود دارد.
- لینک redirect شده همچنان می‌تواند URL اصلی رسانه را آشکار کند؛ این قابلیت DRM نیست.


## نسخه ۳٫۶ — ادامه تماشا و HLS

- `GET /api/me/watch-progress` بدون query، حداکثر ۲۰ مورد آخرِ قابل‌ادامه همان کاربر را همراه اطلاعات عمومی فیلم/قسمت برمی‌گرداند.
- `POST /api/me/watch-progress` با `{"action":"remove","type":"movie|episode","id":123}` یک مورد را حذف می‌کند؛ با `{"action":"clear"}` تاریخچه همان کاربر پاک می‌شود.
- endpoint قبلی `?type=...&id=...` برای خواندن موقعیت دقیق و ارسال `position_seconds` برای ذخیره پیشرفت حفظ شده است.
- مانیفست HLS با `video_mime_type=application/x-mpegURL` به کلاینت اندروید معرفی می‌شود تا Media3 بتواند نوع محتوا را مستقل از لینک امضاشده تشخیص دهد.
- لینک امضاشده صرفاً redirect کوتاه‌مدت است و DRM یا محافظت از segmentهای HLS محسوب نمی‌شود.


## HLS package upload (3.7.8-dev)
- Admins can upload a ZIP bundle containing `master.m3u8` (or `index.m3u8`), nested variant playlists, and media segments.
- Admins can upload SRT/VTT subtitle files directly for movies and episodes, not only paste external subtitle URLs.
- The backend preserves relative paths, rejects unsafe ZIP entries, rewrites local playlist URIs to signed URLs, and protects HLS manifests/segments from direct public access.
- Supported bundle file types: `.m3u8`, `.ts`, `.m4s`, `.mp4`, `.aac`, `.mp3`, `.m4a`, `.vtt`, `.key`.
- Browser/WebView playback still depends on native HLS support; hls.js is not bundled in this dev release.
