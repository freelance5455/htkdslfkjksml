# Spécification GM Pay

## Inclus dans cette version
- Compte par téléphone
- Mot de passe + PIN
- Portefeuille USD/CDF
- Transfert utilisateur à utilisateur
- Réception de transfert
- Historique et références
- Compte marchand
- API backend
- Base SQLite
- Limiteur de requêtes et headers de sécurité
- Mode sandbox clairement identifié
- Frais d'activation configurables à 1 USD

## À connecter avant une exploitation financière réelle
- OTP/SMS réel
- KYC/identité
- Fournisseur Mobile Money RDC
- Acquéreur/cartes bancaires
- Banque/partenaire de paiement
- Conversion FX avec fournisseur
- Paiements internationaux
- Webhooks signés et idempotence
- Moteur anti-fraude et surveillance
- Gestion des litiges
- Facturation réelle
- Paiement différé via partenaire de crédit
- conformité/licences selon les pays

## Principe
L'application ne doit jamais prétendre qu'un paiement externe a réussi avant confirmation du
fournisseur par webhook/API. Les clés secrètes doivent rester côté serveur et être stockées
dans des variables d'environnement ou un secret manager.
