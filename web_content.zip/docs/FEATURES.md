# Feature Coverage

## Intelligence
General-purpose orchestration, context/reasoning contracts, model routing,
reliability states, self-correction/replanning.

## Conversation
Multi-chat, projects, memory, Founder Mode, expressive personality,
adaptive response depth, multilingual architecture.

## Files and creation
Plus button, universal attachment contract, PDF/document/image/video
generation provider interfaces, artifacts and file verification contracts.

## Research
Universal web research, source verification, free/legal resource classification,
free vs tier/trial/login/payment/region/unknown states.

## Build
Coding agent, website generator, app generator, deployment/hosting planner,
health-check and verification workflow.

## Voice
Microphone, continuous-session, separate Voice Chat, speech state contracts.
Actual background microphone behavior remains browser/OS dependent.

## Android
Android Companion architecture, offline-first sync, assistant integration,
screen/device permission contracts. Native APK requires Android SDK/Gradle.

## Security
Permission levels, confirmation gates, secret hygiene, sandbox boundary,
audit/observability contracts. No unauthorized account/device access.

## Finance
Research/paper-trading architecture only. No autonomous real-money trading.

## API / Assistant
Provider-neutral API layer and AI Assistant access contracts are included.
Real external provider credentials/configuration are intentionally not embedded.

## UI
Light professional responsive foundation with chat, sidebar, Plus, microphone,
separate Voice Chat, files/artifacts and workspace sections.
