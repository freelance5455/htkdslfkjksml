# Deploying AccoNova (server edition)

## What runs where
| Piece | Where | Secrets |
|---|---|---|
| App (`index.html`, minified) | browser | none |
| Accounting data | the user's browser (local-first) | — |
| AI assistant, subscriptions, signed plan | `server/server.mjs` | `ANTHROPIC_API_KEY`, `STRIPE_*` — **environment only** |

## 1. Run it
```
cp server/.env.example .env        # fill in the values
docker build -t acconova . && docker run -d --env-file .env -p 8080:8080 -v acconova-data:/data acconova
# or without Docker (Node 20+):  set -a; . ./.env; set +a; node server/server.mjs
```
Put it behind HTTPS (Caddy / nginx / Cloudflare / your host's TLS). `GET /healthz` is the health check.

## 2. Stripe (subscriptions in USD)
1. Create two recurring **monthly** Prices (e.g. $9 Pro, $29 Business) → put their ids in `STRIPE_PRICE_PRO`, `STRIPE_PRICE_BUSINESS`.
2. Add a webhook endpoint `https://YOUR_DOMAIN/api/stripe/webhook` with events: `checkout.session.completed`, `customer.subscription.created`, `customer.subscription.updated`, `customer.subscription.deleted`, `invoice.paid`, `invoice.payment_failed` → copy the signing secret to `STRIPE_WEBHOOK_SECRET`.
3. Enable the Customer Portal (Stripe → Settings → Billing → Customer portal) so users can manage/cancel.
4. Test with Stripe test keys and card 4242 4242 4242 4242 first.
The app never sees card numbers. The server turns Stripe events into a **signed** plan token (ECDSA P-256); the app verifies the signature before it unlocks anything.

## 3. AI assistant
Set `ANTHROPIC_API_KEY`. Requests are limited per minute (per IP), per day (per company, by plan) and per day (per IP). The app sends only an aggregated summary (no names, memos or documents) and only after the user ticks the consent box and presses Send. Change the daily limits with `AI_*_PER_DAY`. Watch your provider bill the first weeks.

## 4. Build the production file yourself (needs the private source zip)
```
AN_API_BASE=https://YOUR_DOMAIN AN_ALLOWED_HOSTS=YOUR_DOMAIN node tools/build.mjs --prod
```
`AN_API_BASE` is only needed when the app is opened from somewhere other than the server (for example wrapped as a mobile app); leave it empty when the server serves the page.
Edit the `LEGAL CONFIG` block at the top of `index.html` (owner, e-mail, governing law, refund policy) — it stays readable on purpose. Have a lawyer review the Terms and Privacy texts.

## 5. Protecting the code — what is and is not possible
* A browser must receive the program to run it, so **nothing shipped to a browser can be made impossible to copy.** What this edition does: the file is minified (names and structure unreadable, no comments, no source map, no tests, no test harness); the server never serves source, tests or docs (everything except `/` and `/api/*` is 404); strict CSP and security headers; `AN_ALLOWED_HOSTS` makes a copy refuse to run on another domain (a speed-bump, easily edited out).
* What actually protects your business: keep value on the server — the AI key, Stripe, and the signed plan are server-side and cannot be copied. Paid features that cost you money (AI) are enforced by the server. Local-only paid features (reports, purchases) can be unlocked by someone who edits their own browser copy — accept that, or move more logic to the server over time.
* Legal protection: the Terms forbid copying/reverse engineering; keep `LICENSE.txt`; register the name/logo if you can; keep the private source zip off public repositories.

## 6. Operations checklist
* Back up the `/data` volume (`signing-key.json` — losing it forces every client to re-sync; `subs.json` — your subscription state).
* Rotate keys if they were ever shown anywhere. Never put them in the app file.
* Put a WAF / rate limiter (Cloudflare) in front; the in-process limiter resets on restart.
* The server stores no accounting data. It stores only: company id → plan/status/Stripe ids, and daily AI counters.
