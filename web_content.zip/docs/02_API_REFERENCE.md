# 2. API reference (`/api/v1`)

Base URL `https://dagbadigitalacademy.com/api/v1`. JSON in and out. Errors always look like `{"ok":false,"error":{"code":"...","message":"..."}}`.
Authenticated calls send `Authorization: Bearer <access_token>`. Browser cookies are **ignored** by the API (so cookie-CSRF cannot apply). Access tokens last 15 minutes; refresh tokens 60 days, rotate on every use, and replaying an old one revokes that session.
Public GET responses carry an `ETag` (send `If-None-Match` to get cheap `304`s on slow networks).

## Auth and account
| Method | Path | Notes |
|---|---|---|
| POST | `/auth/register` | `{email, full_name, password, phone?}` rate-limited; creates a normal student |
| POST | `/auth/login` | `{email, password, platform?, app_version?, device_name?}` → tokens + user |
| POST | `/auth/refresh` | `{refresh_token}` rotates |
| POST | `/auth/logout` | revokes this session |
| GET/PATCH | `/me` | profile + independent subscription status (`basic`, `advanced`, `income`) |
| POST | `/me/password` | signs out other devices |
| DELETE | `/me` | in-app account deletion (needs password; students only) |
| POST | `/devices` | register push token `{token, platform}` |

## Public content (admin edits show up automatically)
`GET /config` (brand, contact, levels, live-update info, prelaunch state, **no secrets**), `/content-version`, `/categories`, `/courses` (filters `division, level, category_id, q, free, featured, sort, page, per_page`), `/courses/<slug>`, `/home` (banners, featured, popular, per-division sections, faith, paths, articles; admin toggles `home.show_*` respected), `/plans`, `/articles`, `/articles/<slug>`, `/paths`, `/paths/<slug>`, `/faith`, `/faith/topics/<slug>`, `/faith/items/<slug>`.

## Learning (signed in; same access rules as the website)
`GET /my/learning`, `/learn/<slug>`, `/lessons/<id>`, `POST /lessons/<id>/progress|complete`, `GET /quizzes/<id>`, `POST /quizzes/<id>/submit` (correct answers are never sent before submission), `GET /assignments/<id>`, `POST /assignments/<id>/submit` (multipart; same validated upload path as the website), `GET /my/assignments`, `GET /my/certificates`, `POST /learn/<slug>/certificate`, `GET|POST /courses/<slug>/discussions`, `GET /notifications`, `POST /notifications/read`, `GET /my/payments`.
Lesson videos/resources/certificate PDFs use **signed, short-lived, user- and item-bound links** (`/media/video|resource|cert|fvideo|faudio/<id>?t=...`, Range requests supported) because a phone's video player cannot send an Authorization header.

## Store billing
`GET /store/products` (product ids that must exist in the store consoles), `POST /store/verify`. See `04_STORE_BILLING.md`.

## Other
`GET /healthz` (uptime probe), `GET /.well-known/assetlinks.json` and `/apple-app-site-association` (deep links; served only once you set the values), `GET /api/v1/bundles/<file>.zip` (live-update bundles), `GET /delete-account` (public deletion instructions page required by Google Play).
