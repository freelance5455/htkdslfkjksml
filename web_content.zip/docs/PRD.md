# PRD — Game Ular Super
**Versi:** 1.0  
**Jenis pekerjaan:** Upgrade aplikasi yang sudah ada  
**Platform utama:** Android WebView  
**Output:** Source code modular dalam ZIP (bukan APK)

## 1. Ringkasan Produk

Game Ular Super adalah game ular berbasis HTML, CSS, JavaScript, dan Canvas yang sudah memiliki sistem gameplay, variasi makanan, power-up, elemen peta, tema, audio, kontrol sentuh, penyimpanan, serta beberapa alur tambahan.

Proyek ini bukan pembuatan game baru. Tujuannya adalah meningkatkan kualitas implementasi, memperbaiki bug, menyatukan alur yang terputus, menghilangkan fungsi pajangan, meningkatkan UX menjadi premium, dan menambahkan sistem permainan modern yang benar-benar berfungsi.

## 2. Keputusan Produk

| Area | Keputusan |
|---|---|
| Pendekatan | Upgrade source yang ada |
| Platform | Android WebView sebagai prioritas |
| Visual | Premium, clean, profesional, mobile-first |
| Fitur lama | Review satu per satu; pertahankan dan perbaiki yang relevan |
| Tutorial | Tutorial visual dan tutorial interaktif |
| Gamepad | Wajib diupayakan dengan fallback |
| Haptic | Wajib dengan fallback |
| Achievement | Wajib |
| Missions/challenges | Wajib |
| Skins | Wajib |
| Daily challenge | Wajib |
| Statistics | Wajib |
| Accessibility | Wajib |
| Aset | Lokal, termasuk ikon aplikasi bergambar ular |
| Koneksi | Offline/local-first; tanpa backend/cloud/CDN |
| Hasil | ZIP source modular terbaru, bukan APK |

## 3. Sasaran dan Prinsip

### 3.1 Sasaran
1. Tidak ada bug kritis/high yang diketahui dan belum ditangani pada fitur yang dinyatakan selesai.
2. Semua kontrol dan tombol memiliki aksi nyata.
3. Transisi antar-state konsisten.
4. Save/load dan migrasi tidak menghilangkan progress lama.
5. Tutorial membantu pemain memahami mekanisme sebenarnya.
6. Fitur baru menghitung progress dari event gameplay nyata.
7. Performa stabil pada perangkat Android yang diuji.
8. Semua aset yang digunakan tersedia secara lokal.
9. Hasil akhir dapat dibuka, diuji, dan dikembangkan dari source modular.

### 3.2 Bukan sasaran
- Membuat game online/multiplayer.
- Menambahkan backend, akun, cloud save, iklan, pembayaran, atau monetisasi.
- Mengirim APK hasil build.
- Mengklaim kompatibilitas semua perangkat tanpa pengujian.
- Mengklaim game 100% bebas bug.

## 4. Baseline Source yang Harus Diaudit

Source utama: `v2(Copy).html`.

Baseline yang terlihat pada source:
- Satu file HTML sekitar 114 KB dan sekitar 2.869 baris.
- Canvas game dengan grid awal 25 dan CELL_SIZE 16.
- Kecepatan awal 8.
- Skor, high score, nyawa, combo, peningkatan speed/grid.
- State yang mencakup menu, playing, paused, gameOver, youtube, checking.
- Variasi makanan.
- Power-up dan activePowerUps.
- Elemen peta: random box, slow zone, ice patch, portal, coin, meteor; terdapat pula bomb dan shadow snake pada collision/update.
- Tema dan efek dekoratif.
- Audio, volume musik dan SFX.
- Swipe, D-pad yang belum benar-benar berfungsi, keyboard, dan dash.
- Save/load berbasis localStorage.
- Modal settings dan reset.
- Popup extra-life/YouTube.
- Particles dan victory effect.

Daftar ini adalah baseline awal, bukan jaminan seluruh fitur sudah berfungsi. Implementer wajib membaca source secara penuh dan memverifikasi semua dependency.

## 5. Audit dan Perbaikan Wajib

### 5.1 Start, Continue, Restart
- Pisahkan aksi mulai sesi baru dan melanjutkan sesi.
- Tombol start/continue tidak boleh selalu memanggil jalur `startGame(true)` tanpa memeriksa state.
- Resume mempertahankan skor, nyawa, posisi, power-up, dan progress sesi.
- Restart memulai sesi baru sesuai aturan dan reset hanya state sesi.
- Game over tidak boleh meninggalkan loop atau timer aktif.

### 5.2 State machine
State minimal yang perlu dipertimbangkan:
- `boot`
- `menu`
- `tutorial`
- `playing`
- `paused`
- `settings`
- `lifeLost` atau state respawn yang sesuai
- `gameOver`
- `summary`
- `confirmation`

State akhir boleh berbeda jika lebih tepat, tetapi harus terdokumentasi. Buat transition map dan validasi aksi pada setiap state. Hindari perubahan state dari banyak fungsi tanpa aturan tunggal.

### 5.3 Kontrol
- Swipe: satu gesture menghasilkan satu perubahan arah yang valid; cegah multi-trigger dari touchmove.
- D-pad: implementasi sungguhan dan tidak dipaksa menjadi Swipe.
- Keyboard: arah, pause, dan aksi yang relevan.
- Gamepad: arah, confirm/cancel, pause, dash bila didukung.
- Jangan menerima arah berlawanan langsung jika aturan ular melarangnya.
- Touch target cukup besar dan tidak tertutup modal/HUD.
- DASH tersedia pada mode kontrol yang sesuai dan tidak hilang karena container kontrol disembunyikan.

### 5.4 Tema Special
- Ganti penggunaan `confirm()` sebagai input password dengan dialog internal.
- Validasi input secara benar.
- Jangan menganggap password hardcoded di client sebagai keamanan.
- Bila Special Theme hanya unlock/easter egg lokal, jelaskan hal tersebut.

### 5.5 Reset
- Tidak boleh memakai `localStorage.clear()`.
- Reset hanya key/record yang dimiliki Game Ular Super.
- Pisahkan reset pengaturan, statistik, progress, dan seluruh data game bila dibutuhkan.
- Konfirmasi harus menjelaskan data yang akan dihapus.
- Jangan hapus data sebelum validasi/konfirmasi selesai.

### 5.6 Loop dan waktu
- Satu requestAnimationFrame loop aktif.
- Pause, settings, game over, visibilitychange, dan background lifecycle menghentikan update gameplay dengan benar.
- Resume menginisialisasi ulang timestamp agar tidak terjadi lonjakan delta.
- Fixed timestep/accumulator disarankan.
- Clamp delta dan batasi catch-up.
- Timer power-up dan objek harus konsisten dengan aturan pause.
- Tidak ada interval/timeout yang tertinggal.

### 5.7 Power-up dan elemen peta
Audit setiap tipe dan pastikan:
- spawn valid,
- tidak overlap,
- collect/collision valid,
- efek diterapkan,
- indikator UI tampil,
- timer berjalan,
- expiry mengembalikan state dengan benar,
- stacking/refresh memiliki aturan,
- cleanup menghapus efek dan objek,
- efek tidak saling merusak.

Telusuri secara khusus Fury, Combo Bonus, Magnet, Rare Food, Shield, Ghost, Speed, Slow, Slide, Dash, Random Box, Portal, Ice, Slow Zone, Coin, Meteor, Bomb, dan Shadow Snake. Jangan menganggap semua nama di atas pasti sudah terimplementasi penuh; cocokkan dengan source.

### 5.8 Save/load
- Audit seluruh key lama.
- Buat schema version.
- Validasi tipe/rentang data sebelum restore.
- Migrasikan data lama secara aman.
- Save tidak boleh menyimpan state sementara yang tidak aman untuk dipulihkan.
- Load tidak boleh memulai loop ganda.
- Data rusak harus ditangani tanpa merusak save lain.
- Backup/import/export harus benar-benar berfungsi.

## 6. Arsitektur Modular

Pisahkan source sekurang-kurangnya menjadi:

```text
Game-Ular-Super/
├── index.html
├── assets/
│   ├── icons/
│   ├── images/
│   ├── audio/
│   └── fonts/
├── css/
├── js/
│   ├── core/
│   ├── gameplay/
│   ├── input/
│   ├── systems/
│   ├── ui/
│   ├── storage/
│   ├── audio/
│   ├── render/
│   └── utils/
├── docs/
├── tests/
└── README.md
```

Struktur dapat disesuaikan berdasarkan kebutuhan teknis, tetapi pemisahan tanggung jawab wajib ada. Jangan memecah file secara berlebihan tanpa manfaat.

### 6.1 Core
- Bootstrap dan initialization.
- State machine.
- Lifecycle dan game loop.
- Configuration.

### 6.2 Gameplay
- Snake movement.
- Direction validation.
- Food and spawning.
- Collision.
- Scoring, combo, lives, difficulty.

### 6.3 Systems
- Power-ups.
- Map elements.
- Achievements.
- Missions.
- Daily challenge.
- Skins.
- Statistics.

### 6.4 Input
- Swipe.
- D-pad.
- Keyboard.
- Gamepad.
- Input mapping dan debounce.

### 6.5 UI
- Menu.
- HUD.
- Tutorial.
- Settings.
- Modal/dialog.
- Summary.
- Feedback dan microinteraction.

### 6.6 Storage
- Data schema.
- IndexedDB untuk data progres/riwayat yang sesuai.
- localStorage untuk preferensi ringan dengan namespace.
- Migration.
- Backup/restore.

### 6.7 Rendering dan audio
- Canvas renderer.
- Theme renderer.
- Particles/effects.
- Audio manager dan cleanup.

## 7. Tutorial

Tutorial harus memiliki dua pendekatan yang dapat dipilih/diulang.

### 7.1 Tutorial visual
- Langkah pendek, visual, dan mudah dipahami.
- Menjelaskan tujuan game, kontrol, skor, nyawa, pause, dash, power-up, obstacle, dan fitur khusus.
- Menggunakan ikon/ilustrasi lokal.
- Tersedia tombol lanjut, kembali, lewati, dan ulangi.

### 7.2 Tutorial interaktif
- Pemain diminta melakukan aksi nyata.
- Sistem menunggu input yang sesuai sebelum melanjutkan.
- Contoh: geser ke arah tertentu, kumpulkan makanan, pause/resume, aktifkan dash, ambil power-up.
- Langkah harus dapat diselesaikan dan tidak boleh macet.
- Sediakan petunjuk jika pemain tidak memahami langkah.
- Jangan mengaktifkan mekanisme yang belum tersedia dalam gameplay.

### 7.3 Progress
- Simpan status selesai dan preferensi tutorial.
- Pemain dapat mengulang tutorial dari Settings.
- Tutorial tidak menghalangi permainan normal setelah selesai.

## 8. Fitur Baru

### 8.1 Gamepad/controller
- Deteksi Gamepad API bila tersedia.
- Mapping arah dan tombol aksi.
- Dead zone dan debounce.
- Status koneksi.
- Fallback ke touch, swipe, D-pad, dan keyboard.
- Keterbatasan dukungan Android WebView wajib dijelaskan.

### 8.2 Haptic feedback
- Gunakan Vibration API jika tersedia.
- On/off.
- Pola berbeda untuk collect, power-up, collision, achievement, dan game over.
- Batasi frekuensi.
- Fallback tanpa getaran.

### 8.3 Achievements
- Daftar achievement dengan judul, deskripsi, syarat, progress, status, dan waktu unlock.
- Progress berasal dari event yang nyata.
- Unlock tidak berulang.
- Tidak ada achievement yang mustahil atau hanya pajangan.

### 8.4 Missions
- Tujuan dan progress jelas.
- Misi harian/bertahap dapat disediakan sesuai sistem daily challenge.
- Reward harus nyata dan dijelaskan.
- Jangan menambah ekonomi/uang virtual kompleks tanpa kebutuhan produk.

### 8.5 Skins
- Skin mengubah tampilan ular secara nyata.
- Preview dan active selection.
- Skin default selalu tersedia.
- Unlock melalui achievement/misi atau aturan offline yang jelas.
- Simpan pilihan dan unlock secara persisten.

### 8.6 Daily challenge
- Berdasarkan tanggal lokal perangkat.
- Tantangan untuk tanggal sama harus konsisten.
- Reward hanya satu kali per tanggal.
- Tangani pergantian hari dan perubahan zona waktu.
- Offline-first.
- Dokumentasikan bahwa validasi lokal bukan anti-cheat kuat.

### 8.7 Statistics
Minimal data yang boleh ditampilkan jika benar-benar direkam:
- Total sesi.
- Best score.
- Total skor.
- Total makanan.
- Total durasi bermain.
- Power-up digunakan.
- Achievement dan misi selesai.
- Riwayat sesi dan tren.
Batasi ukuran riwayat dan sediakan reset statistik terpisah.

### 8.8 Accessibility
- Ukuran target sentuh.
- Kontras.
- Font scaling.
- Label yang jelas.
- Reduced motion.
- Efek visual dapat dikurangi.
- Warna bukan satu-satunya indikator.
- Keyboard/controller focus.
- Pengaturan bantuan/kecepatan bila sesuai.
- Tidak mengorbankan aksesibilitas dengan menonaktifkan seluruh seleksi teks secara global.

## 9. Visual dan Mikrointeraksi

### 9.1 Arah visual
- Premium, clean, profesional, tidak berlebihan.
- Mobile-first dan nyaman di Android.
- Area game menjadi fokus utama.
- HUD mudah dibaca.
- Ikon lokal satu gaya.
- Layout tidak overflow horizontal.
- Tidak ada tombol terlalu kecil atau panel yang menutupi kontrol.

### 9.2 Mikrointeraksi
- Pressed/active/disabled state.
- Feedback collect dan score.
- Combo feedback.
- Power-up activation/expiry.
- Achievement unlocked.
- Mission completed.
- Pause/resume.
- Game over/summary.
- Loading/empty/error state bila relevan.
- Durasi animasi singkat dan konsisten.
- Reduced-motion.
- Tidak boleh mengganggu input atau frame rate.

## 10. Audio dan Haptic

- Pengaturan musik dan SFX terpisah.
- Volume slider langsung dan stabil.
- AudioContext/node digunakan ulang atau dibersihkan.
- Hormati autoplay restriction.
- Pause/settings/game over menghentikan audio yang sesuai.
- Haptic dapat dimatikan terpisah dari audio.
- Tidak ada audio/haptic yang terus berjalan tanpa alasan.

## 11. Data, Backup, dan Privasi

- Offline/local-first.
- Tidak mengirim data ke server.
- Tidak ada telemetry pihak ketiga.
- Namespace storage khusus Game Ular Super.
- Migrasi data lama non-destruktif.
- Backup export dan restore import nyata.
- Validasi file sebelum restore.
- Tampilkan error yang dapat dipahami.
- Jangan overwrite data valid diam-diam.
- Uji data kosong, lama, rusak, dan kuota penuh.

## 12. Ikon Aplikasi dan Aset

Wajib ada ikon bergambar ular yang jelas dan konsisten:
- `assets/icons/app-icon-512.png`
- `assets/icons/app-icon-192.png`
- `assets/icons/snake-logo.svg` atau PNG
- `assets/icons/favicon.svg` atau PNG
- Android adaptive icon foreground/background bila disediakan.

Ikon harus:
- Memiliki bentuk ular yang mudah dikenali.
- Terbaca pada ukuran kecil.
- Tidak bergantung pada teks kecil.
- Memiliki source vektor bila memungkinkan.
- Tersedia lokal dan masuk ZIP.

Catatan: favicon atau ikon HTML tidak otomatis menjadi launcher icon APK. README harus menjelaskan file yang harus dipakai pada konfigurasi launcher icon Android wrapper. Pengguna membangun APK sendiri.

## 13. Persyaratan Android WebView

- Fokus pada perangkat Android.
- Uji touch, safe area, orientation, keyboard, screen background/foreground.
- Tangani audio gesture restriction.
- Vibration/Gamepad API memiliki fallback.
- Jangan mengandalkan CDN atau network.
- Periksa dukungan ES modules pada cara pemuatan yang digunakan.
- Jangan mengklaim module source dapat dibuka langsung dari `file://` jika belum diuji.
- Berikan petunjuk integrasi source ke WebView wrapper.
- Jangan mengirim APK.

## 14. QA dan Acceptance Criteria

### 14.1 Functional acceptance
- [ ] New Game membuat sesi baru.
- [ ] Continue melanjutkan state yang benar.
- [ ] Pause menghentikan gameplay.
- [ ] Resume tidak mereset progress.
- [ ] Restart membuat sesi baru.
- [ ] Game over menghentikan semua loop.
- [ ] Swipe berfungsi.
- [ ] D-pad berfungsi.
- [ ] Keyboard berfungsi jika tersedia.
- [ ] Gamepad memiliki fallback yang jelas.
- [ ] DASH dapat diakses dan bekerja pada mode yang didukung.
- [ ] Semua power-up punya efek dan expiry yang benar.
- [ ] Semua map element spawn/collect/collision sesuai aturan.
- [ ] Tema dapat dipilih dan unlock berjalan benar.
- [ ] Save/load berfungsi setelah reload.
- [ ] Data lama tetap terbaca atau dimigrasikan.
- [ ] Reset tidak menghapus data lain di origin.
- [ ] Tutorial visual dan interaktif selesai tanpa dead end.
- [ ] Achievement ter-unlock dari event nyata.
- [ ] Mission progress akurat.
- [ ] Daily challenge konsisten untuk tanggal yang sama.
- [ ] Skin benar-benar mengubah render.
- [ ] Statistics sesuai data yang direkam.
- [ ] Haptic memiliki fallback.
- [ ] Accessibility settings memengaruhi UI/game.
- [ ] Semua tombol memiliki aksi nyata.

### 14.2 Technical acceptance
- [ ] Tidak ada syntax error.
- [ ] Tidak ada import/path aset yang rusak.
- [ ] Tidak ada undefined element handler.
- [ ] Tidak ada loop ganda.
- [ ] Tidak ada timer/listener/audio node yang bocor.
- [ ] Tidak ada spawn overlap yang tidak valid.
- [ ] Tidak ada reset destruktif.
- [ ] Migrasi diuji dengan data lama.
- [ ] ZIP dapat diekstrak.
- [ ] Source dapat dijalankan sesuai README.
- [ ] Aset ikon ular ada dan valid.
- [ ] Tidak ada CDN/runtime remote dependency.

### 14.3 Status pengujian
Setiap test harus dilaporkan sebagai:
- PASS: benar-benar dijalankan dan berhasil.
- FAIL: dijalankan dan gagal.
- BLOCKED: tidak dapat dilakukan karena lingkungan/API/perangkat.
- NOT TESTED: belum dijalankan.

Dilarang mengubah BLOCKED atau NOT TESTED menjadi PASS. Catat perangkat, browser/WebView, langkah reproduksi, hasil, dan bug tersisa.

## 15. Deliverable

Wajib dikirim:
1. ZIP berisi source modular terbaru.
2. `index.html` sebagai entry point.
3. Semua JS/CSS/assets lokal.
4. Ikon aplikasi bergambar ular.
5. `README.md` cara menjalankan dan integrasi ke Android WebView.
6. `PRD.md`.
7. `CHANGELOG.md`.
8. `QA-REPORT.md`.
9. `FEATURE-MATRIX.md`.
10. `MIGRATION.md`.
11. Test files jika test runner tersedia.

Tidak diminta dan jangan dikirim:
- APK final.
- Link CDN sebagai pengganti aset.
- Source yang tidak lengkap.
- File kosong/placeholder.
- Klaim semua tes lulus tanpa bukti.

## 16. Format Laporan Akhir Claude

Laporan akhir harus menyertakan:
1. Ringkasan perubahan.
2. Daftar bug dan root cause yang diperbaiki.
3. Daftar fitur lama: dipertahankan, diperbaiki, digabung, atau dievaluasi beserta alasan.
4. Daftar fitur baru yang benar-benar selesai.
5. Daftar fitur yang belum selesai/terblokir.
6. Hasil QA PASS/FAIL/BLOCKED/NOT TESTED.
7. Cara menjalankan source.
8. Cara memasukkan ikon ular ke launcher icon Android wrapper.
9. Ukuran ZIP dan folder hasil ekstrak.
10. Nama file ZIP dan isi struktur folder.

**Definisi selesai:** source modular terbaru telah dikemas, diekstrak ulang untuk verifikasi, seluruh path/import/aset diperiksa, test yang tersedia dijalankan, dan keterbatasan dilaporkan dengan jujur.