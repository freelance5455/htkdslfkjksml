# Deployment checklist (not done by this package)
1. Managed PostgreSQL 16, daily PITR backups, restore drill monthly.
2. Apply `database/migrations/001_core.sql`; app connects as `acconova_app`.
3. Argon2id passwords, TOTP MFA, short-lived sessions, rate limiting.
4. Payment provider webhook: verify signature with the server-held secret (the demo secret in this package is public — never reuse it).
5. TLS, HSTS, CSP, secrets manager, centralized logs, uptime + error alerts.
6. Legal review of `docs/legal/*`; local e-invoicing/tax rules.
Run the DB tests: `bash tests/db.test.sh` (needs PostgreSQL 16 binaries).
