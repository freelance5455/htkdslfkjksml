# Deployment Guide

## Docker Compose Deployment
1. Copy `.env.example` to `.env` and configure your database credentials and secret key:
   ```bash
   cp .env.example .env
   ```
2. Build and start containers:
   ```bash
   docker-compose up -d --build
   ```
3. Run database migrations and seed data:
   ```bash
   npx prisma migrate deploy
   npx tsx prisma/seed.ts
   ```

## Production Cloud Deployment
The system builds into a standalone Node.js production service (`npm run build` -> `node dist/server.cjs` or container runner).
Static assets are served with optimal caching headers and API routes run behind secure reverse proxies.
