# AI / builder handoff
NIVEX can be continued in Bolt.new, Lovable, Muse, Windsurf or Cursor by opening this repository. These are development environments, not runtime libraries of the editor.

Cursor/Windsurf are suited to refactors, profiling and tests. Bolt/Lovable/Muse can be used for interface exploration. Keep the shipped runtime independent from those platforms.
