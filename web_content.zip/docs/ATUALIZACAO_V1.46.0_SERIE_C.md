# Carreira de Craque v1.46.0 — Série C

## Implementação
- Adicionada a Série C com os 20 clubes informados: Amazonas, Anápolis, Barra, Botafogo-PB, Brusque, Caxias, Confiança, Ferroviária, Figueirense, Floresta, Guarani, Inter de Limeira, Itabaiana, Ituano, Maranhão, Maringá, Paysandu, Santa Cruz, Volta Redonda e Ypiranga.
- Calendário de turno e returno: 38 rodadas e 380 partidas, persistidas na carreira.
- A Série C avança automaticamente em paralelo com as rodadas brasileiras e passa a aparecer no menu de Ligas.
- Promoção/rebaixamento: quatro primeiros da Série B sobem à Série A; quatro últimos da Série A caem à Série B; quatro primeiros da Série C sobem à Série B; quatro últimos da Série B caem à Série C.
- O histórico de temporada passa a guardar campeão, tabela e partidas da Série C.
- Os clubes da Série C têm força inicial e abreviações próprias. As avaliações anteriores de clubes das Séries A e B foram preservadas.
- Clubes atualmente na Série C não são oferecidos como destino de transferência; quando promovidos à Série B, passam a integrar a lista elegível.

## Validações técnicas
- JavaScript: verificação de sintaxe com `node --check` concluída sem erros.
- Calendário: validado em teste separado para 20 clubes, 38 rodadas, 380 jogos e 19 partidas por clube contra adversários únicos.
- ZIP: verificado após empacotamento.
- Limitação: não foi executado um ciclo completo de temporada no navegador; testar a progressão visual, o save real e a temporada completa no Netlify antes de substituir a versão estável.
