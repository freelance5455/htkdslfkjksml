# Laporan QA — Fase 1
Lingkungan: Node v22, Chromium 153 headless (Playwright, viewport 390×844, touch aktif, `file://`), Linux. **Bukan perangkat Android nyata.**
Perintah: `sh tests/run-all.sh`. Hasil run terakhir: static 8/8, engine 27/27, store+machine 13/13, browser 30/30 (semua PASS).

| Area | Hasil | Bukti |
|---|---|---|
| Sintaks JS, ID/selector, path aset, tanpa URL remote/alert/clear | PASS | tests/unit/static.test.js |
| Unit: arah, wrap, makan, combo, 2×/fury, tabrakan, ghost, perisai, nyawa, extra life, speed/slow/dash, expiry power-up, clamp delta, catch-up, es, mirror, magnet, portal, spawn 3000×, papan penuh, grid, simulasi 20.000 tick, snapshot, validasi, migrasi save lama | PASS | engine.test.js |
| Unit: migrasi key lama, idempotensi, storage kosong, pengaturan rusak, save/load, save rusak tidak dihapus, kuota penuh, reset ber-namespace, backup export/import, state machine | PASS | store.test.js |
| Integrasi (Chromium): menu→main→jeda→lanjut (skor/nyawa utuh), timer berhenti saat jeda, P/Esc, visibilitychange, settings, D-pad, DASH di mode Swipe, sandi tema, reset+konfirmasi, tabrakan→nyawa→extra life→game over→main lagi, migrasi, save rusak, tanpa error konsol, satu loop (~60 rAF/dtk) | PASS | browser_test.py |
| Gamepad, haptic, tutorial, achievement, misi, skin, harian, statistik, IndexedDB | **NOT TESTED** (belum diimplementasi — Fase 2) | |
| Perangkat Android nyata: sentuhan, rotasi, layar mati, gesture audio, vibrasi, unduhan backup di wrapper | **NOT TESTED / BLOCKED** (tak ada perangkat) | prosedur manual di bawah |
| Audio (bunyi nyata) | **NOT TESTED** — headless tidak dapat memverifikasi suara; hanya diuji tanpa error | |
| Performa sesi panjang di perangkat low-end | **NOT TESTED**; hanya simulasi logika 20.000 tick & hitung rAF | |
| Landscape, font scaling | **NOT TESTED** | |

## Catatan jujur
- Tes browser sempat flaky (±40% run) di langkah "muat simpanan rusak". Penyebab yang dibuktikan: di tes, `localStorage.setItem` lalu `reload()` langsung kadang kehilangan key (terjadi hanya bersama `add_init_script`, Chromium headless `file://`; 0/25 tanpa init script). Game tidak punya jalur yang menghapus save saat boot. Tes diubah agar meng-seed lewat init script tanpa reload; 8 run berturut-turut + 5 sebelumnya lulus. Bila hal serupa terjadi di perangkat nyata (data hilang setelah tutup paksa), itu perlu diselidiki terpisah — belum diuji.
- Dua tes sempat gagal karena kesalahan tes (perbandingan objek lintas konteks `vm`, `acc` yang sengaja di-reset saat restore) — diperbaiki di tes, bukan engine. Satu bug nyata ditemukan tes dan diperbaiki: `machine.back()` hanya satu level (salah arah setelah Settings→Konfirmasi).
- Keseimbangan gameplay (frekuensi spawn per langkah, aturan Fury/Combo baru) belum diuji oleh pemain nyata.
## Prosedur manual Android
1) Putar layar, kunci/buka layar saat bermain → harus otomatis Jeda. 2) Geser di canvas: satu gesture = satu belok. 3) Nyalakan musik setelah sentuhan pertama. 4) Ekspor backup → cek apakah berkas terunduh (butuh DownloadListener). 5) Impor backup yang sama. 6) Cabut/pasang data: reset hanya menghapus data game.
