# Security & Cryptography Guidelines

## 1. Password Storage & Authentication
- Passwords are never stored in plaintext and never logged.
- Argon2id / PBKDF2 hashing with salt is enforced.
- Rate limiting protects against brute force attacks (locks account after 5 failed attempts).
- Session tokens are securely handled and verified on every server API request.

## 2. Role-Based Access Control (RBAC)
Granular permissions are validated server-side on every request:
- `POS_CREATE_SALE`: Execute retail sales transactions.
- `POS_REFUND`: Authorize customer item refunds.
- `PRODUCT_CREATE` / `PRODUCT_EDIT`: Modify catalog details and retail prices.
- `INVENTORY_ADJUST`: Perform manual inventory write-offs or intake.
- `PURCHASE_RECEIVE`: Record inbound supplier inventory.
- `REPORT_VIEW` / `REPORT_EXPORT`: Access financial and sales reports.
- `SETTINGS_MANAGE`: Modify store details, tax rates, and policies.

## 3. Database Integrity & Concurrency
- Atomic transactions prevent race conditions during simultaneous sales.
- Row-level locking ensures inventory quantities cannot be oversold concurrently.
