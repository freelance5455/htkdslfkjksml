# TO‘LOVCHI Super Admin Dashboard: owner manual for Android

This guide is for the owner using an Android phone. The dashboard is a private operations console. It shows service-wide totals and anonymized samples; it must never show a person’s debts, bank balance, income, zakat details or financial records.

## 1. Open the dashboard safely

1. Open the dashboard URL supplied by the person who deployed it in Chrome on your Android phone. Check that the address begins with `https://` and is the domain you control.
2. For quick access, in Chrome open the three-dot menu and choose **Add to Home screen**. This creates a shortcut; it does not install a separate app.
3. Do not sign in on a shared phone or public Wi-Fi. Keep Android’s screen lock enabled. Use a unique administrator password and a reputable authenticator app.

## 2. First-time owner setup

The initial owner enrollment is available only while no administrator exists and only when the deployment has the protected `ADMIN_SETUP_TOKEN` and `TOTP_ENCRYPTION_KEY` values configured.

1. Open `/?setup=owner` on your dashboard domain.
2. Enter the one-time setup token from your private deployment settings, your name and email, and a unique password of at least 12 characters.
3. The dashboard displays an authenticator setup key. In your authenticator app, add an account manually, choose a time-based code (TOTP), and type the key exactly as shown. Enter the current six-digit code in the dashboard.
4. Save all displayed recovery codes in a password manager or another private place. Each code works once. The dashboard will not display them again.
5. Sign in with your email and password, then confirm the current authenticator code. The first owner receives the full owner role.

Never send the setup token, encryption key, password, authenticator key or recovery codes through chat, email or a support ticket. Keep a secure backup of `TOTP_ENCRYPTION_KEY`: existing authenticator secrets are encrypted with it. If it is lost, administrators may need a recovery and re-enrollment procedure before a migration.

## 3. Sign in and recover access

Enter your administrator email and password, select **Continue**, then type the six-digit code from your authenticator app. If you cannot access the authenticator, select **Use a recovery code** and enter one saved code; each recovery code can be used only once. An administrator can change their password from **Admin team → Change my password**; all active sessions end and they must sign in again. If the password and MFA are both lost, ask the owner to create a one-time **Reset access** link in **Admin team**. The link suspends that account, revokes its sessions and expires after seven days; share it privately with the same administrator so they can set a new password and authenticator. Do not share credentials with another person—use a separate role-based invitation instead.

Use the sign-out icon beside your profile when you finish. The session expires automatically after 12 hours.

## 4. Navigate on a phone

The bottom row provides quick links to **Home**, **Users**, **Ops** and **Manage**. Tap **More** to open the complete section menu. On a wider screen, the same sections appear in the left-side menu. Use the growth selector to switch between new registrations for seven days and registered-user totals for seven months; use the revenue selector for three or seven months. Reliability can be filtered by incident status, support by topic, and the other available tables can be swiped horizontally on a phone.

The main sections are:

- **Overview:** aggregate registered users, daily/monthly activity, Premium subscribers, subscription and ad revenue, growth charts and service signals.
- **Users & growth / Revenue:** additional anonymized trends and separate monetization figures.
- **Reliability:** sample incident/crash summaries, severity and status.
- **Feedback & support:** sample anonymized topics and screened excerpts only.
- **App releases:** version records for Android, iOS and backend. Adding a record does not upload an app or publish it to Google Play or Apple.
- **Backend & cost:** sample request volume, storage and estimated service cost; it is not a provider invoice.
- **Feature controls:** owner/admin can turn saved feature flags on or off. The admin-side settings do not change the customer app until that app is connected to the feature-flag feed.
- **Announcements:** owner/admin can save a draft or mark an item as published in the dashboard register. This does not send a message to customer devices; delivery to the customer app is not connected yet.
- **Admin team:** owner can create a time-limited invitation and choose Administrator, Analyst or Support. Copy the invitation link and share it privately with the matching email address. Every invited administrator must set a password and authenticator. The owner can change roles, suspend/restore non-owner accounts (suspension revokes all sessions), and create one-time access-reset links for a non-owner. Never paste a reset link into a public channel. Administrators can change their own password here; that also signs out all sessions.
- **Audit history:** review who made administrative changes and when.

## 5. Understand the data banner

Until you connect sources from accounts you own, the amber **Demonstration data** banner remains visible. The dashboard’s sample registrations, revenue, incidents, support requests, storage, service costs and app releases are illustrative; they are not live TO‘LOVCHI data. Do not use them for business, support or financial decisions. The dashboard does not connect to app analytics, AdMob, store billing, crash reporting or a cloud billing account by itself.

To show live operational figures, the owner must connect approved sources through an aggregate-only integration. Do not import individual debts, balances, income, zakat information or personal financial histories. Support and crash text must be screened/redacted before administrators see it.

## 6. Privacy, roles and audit trail

The console intentionally has no user-level financial-record search. Never paste a customer’s sensitive financial details into an announcement or administrator note. A user who needs help should be handled through your support process after private financial details are removed from dashboard-visible content.

The **Owner** can manage administrator roles and all controls. An **Administrator** can operate the dashboard except for owner-only access changes. An **Analyst** can view aggregate service metrics and audit history. **Support** can see only the anonymized support queue and a **My account** page for changing their own password; support cannot view metrics, incidents, feature settings, announcements, releases, team members or audit history. A screen that is missing for your role is restricted intentionally.

Feature, announcement, release, role and sign-in actions create audit events. The dashboard provides no delete button for audit history.

## 7. If the dashboard is unavailable

Refresh the page once. If sign-in fails, check your password, phone clock and authenticator code, then wait if the dashboard reports too many attempts. If the health endpoint or website itself is unavailable, contact the owner of the cloud hosting account; this dashboard cannot fix a hosting outage from inside the phone interface.


## 8. Customer app is a separate application

The TO‘LOVCHI finance app is a separate Android app in `mobile/`; it is not the admin dashboard and does not send personal financial records to this console. User balances, debts, bills and zakat stay in the customer's encrypted device database. Use [`BUILD-ANDROID-PHONE.md`](./BUILD-ANDROID-PHONE.md) for owner account setup, the internal APK and Play AAB profiles, installation/testing, and external services that are still disabled. No signed APK/AAB or owner EAS/Play account is connected in this project yet.
