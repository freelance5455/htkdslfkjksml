# TO‘LOVCHI Terms of Use (Draft)

**Status:** Owner review required. This is a product-accurate draft, not legal advice. Before publication, the owner must complete the legal entity, contact, effective date, governing-law and dispute fields that apply locally, then obtain qualified legal review.

## Service scope

TO‘LOVCHI is a personal record-keeping tool. It is not a bank, payment service, lender, tax adviser or professional financial adviser. It does not move money or verify bank balances.

## User-entered information and estimates

All figures, categories, dates, exchange rates and Zakat inputs are entered or confirmed by the user. Reports and conversions are informational and may be wrong if the underlying entries or rates are wrong. Zakat output is an illustrative estimate, not a religious ruling; users should consult a qualified scholar about their circumstances.

## Reminders

Reminders are local best-effort operating-system notifications and can be delayed or suppressed by device permissions, battery settings, force-stop or operating-system behavior. They are not a guarantee that a payment or deadline will be met.

## Local data and exports

Records are stored locally. Users may create and restore a portable AES-256-GCM encrypted backup file protected by a passphrase they choose. TO‘LOVCHI does not upload the file or reset the passphrase. The user is responsible for the file, passphrase and any external destination selected in the system share sheet. Without both the file and passphrase, restoration is impossible; restore replaces current local records and saved preferences. Automatic/cloud backup is not active.

The user chooses whether to create and share CSV/PDF exports. Once shared outside TO‘LOVCHI, another app or recipient may retain or disclose the file under its own terms.

## Premium and advertising

Premium purchases and advertisements are not active in this version. No payment is initiated by the Premium status screen. Future paid features must be described and implemented with verified store flows before being offered.

Owner contact and applicable local legal terms: **[Legal entity] · [support email] · [country/jurisdiction] · [effective date]**. This draft is not legal advice and is not ready for public release until completed and reviewed.
