# OPUX 2.3 — Implementation Report

Version 2.3.0 (versionCode 8). Storage key `h24v1` unchanged. No data migration needed: the only new stored fields are optional (`ext.mo`, `ext.fx.sg`) and default safely when absent.

## Root causes found
1. **Midnight**: every time-adding path assigned the whole duration to ONE date: `stopT` (date captured at start), `saveCheckin` (date of the save moment) and `fsConfirm` (today at confirm). Data model is `S.days[date]=[{act,min,note}]` with no timestamps, so nothing could be split.
2. **Swipe**: a `touchend`-only handler; the page never moved with the finger, and only one view (`#app`) exists at a time.
3. **RDBD**: entries already store `d` (date written). The carousel never rendered it; notes (`k:'n'`) were only listed inside Edit mode.
4. **"https://… updated" messages**: no such string exists anywhere in the JS or Java. The WebChromeClient had no `onJsAlert/onJsConfirm`, so Android shows its default dialog whose title is the page URL. I could not reproduce your exact message, so this is the most likely cause, not a confirmed one. Fixed at both layers (below).
5. **Colours**: native `<input type=color>` in Settings.

## What was implemented
- **Midnight splitting**: `splitSpan(a,b)` splits a real interval at local midnight (DST/leap/month/year safe, cumulative rounding so pieces sum exactly). `putParts` writes each piece to its own date; earlier piece appended, post-midnight pieces inserted at the start of their day. Applied to: timer stop (`[start, now]`), check-in (the last N minutes ending now), focus sessions (new per-run segments `fx.sg`, so paused time is not counted). Check-in/focus are all-or-nothing if a day lacks room; timer clamps per day with a clear message. Check-in sheet shows a live "crosses midnight" preview. Manual entries and all historical data are untouched; no timestamps were invented.
- **RDBD**: title untouched (still ALL CAPS via existing CSS). Every quote shows "Written <date>" (carousel and Home widget). Notes are a readable list in normal view with dates, tap to expand. Editing preserves original dates.
- **Finger-following navigation**: touch-driven drag where the current page tracks the finger 1:1 and the destination page is rendered beside it. Tab pages swipe both ways; sub-pages swipe right to go back (parallax reveal of the parent). Release decides by distance (>40 %) or velocity (>0.45 px/ms); settle uses a 160–380 ms ease-out; cancel springs back. Ignored on inputs, selects, canvas/SVG, sliders, horizontal scrollers, open dialogs/panels, and branch edit mode. Vertical intent aborts. touchcancel, blur, multi-touch and tab-hide clean up.
- **Branch**: breathing nodes, flowing dashes along connections, selection highlights connected edges/nodes and dims the rest, tactile selection pop + haptic, lifted node while dragging, 560 ms eased layout transitions, animated camera re-fit, entrance zoom, attach/remove feedback.
- **Home / Tracker / Global**: floating particles on Home (only while Home is visible), FLIP animation for widget reordering, date-switch slide direction on Tracker/History, running-timer glow, press feedback, animated toggle switches, chip pop, smoother sheet/panel easing.
- **Motion setting** (More → Settings): Full / Balanced / Off, stored in `ext.mo` (survives backup). Android reduced-motion is respected; ambient loops pause when the app is hidden and exist only on their own screen.
- **Messages**: `alert()` is now an in-app error toast (nothing silently hidden); toasts have success/error styling; any message containing a URL is replaced; contextual "Link saved / Node updated / File attached / Activity updated". Native dialogs are branded "OPUX" (Java change).
- **Colour picker**: swatch button opens a sheet with 24 swatches, animated check, live preview, custom colour, luminance-aware check mark. Existing colours are never changed; only the edited activity is saved; values validated as `#rrggbb`.

## Modified files
`app/src/main/assets/index.html`, `app/src/main/java/com/opux/tracker/MainActivity.java`, `app/build.gradle`, `STATUS.md`, `docs/OPUX_2_3_IMPLEMENTATION_REPORT.md`, `QA/tests/t23_*.py` (new), `QA/tests/t2.py, t4.py, shots.py, fixture.py` (paths only).

## Tests actually run (headless Chromium, Playwright; not on a device)
- `t23_tracker_midnight.py`: **56/56**, in UTC, New York, Karachi, London: 23:00→01:00 = 1h+1h; 3-day span; leap day; year change; DST week; timer stop, check-in, focus segments end to end; existing data preserved; 24 h clamp; strict rejection writes nothing.
- `t23_ui_motion_rdbd_color_branch.py`: **39/39**: drag follows finger, completes by distance and by velocity, cancels, vertical ignored, rubber-band at first tab, back swipe, inputs/dialog excluded, touchcancel cleanup; RDBD dates/notes/edit-date preservation; toasts; colour persistence; motion setting; backup validator round trip; Branch breathing/flow/selection/layout tween.
- Legacy `t2.py` 59/61 and `t4.py`: the same 2 failures occur on the untouched 2.2 build (time-of-day and wheel tests), so no regression.
- One screenshot of a mid-swipe frame was inspected visually.

## Not verified / limitations
- **No APK was built or tested.** No JDK/Gradle here. The Java dialog change is uncompiled (standard `onJsAlert/onJsConfirm`, anonymous classes).
- Gesture feel, frame rate and low-end performance were not tested on a real Android device. Headless touch timing differs from a finger.
- The destination page in a swipe is static HTML; canvases/charts on it appear after the swipe settles.
- Dialogs animate open but not closed. No new loading-state visuals. Number count-ups are the pre-existing ones, not new.
- Timer allocation now uses real clock dates; a timer started while viewing a past day no longer logs to that day. Check-in minutes are assumed to be the most recent N minutes ending now.
- I could not find or reproduce the literal "https://… updated" text (see root cause 4).
