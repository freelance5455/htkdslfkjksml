# Stack V3.0

## Editor/UI
HTML, CSS, JavaScript, TypeScript, React, Vite, Canvas.

## Renderização
WebGL, WebGPU, PixiJS, Three.js, p5.js.

## Manipulação visual
Fabric.js, Konva.js, Cropper.js, CamanJS, glfx.

## Vídeo
FFmpeg.wasm, WebCodecs, WASM, Web Workers.

## Áudio e mídia
Web Audio API, MediaRecorder, MediaDevices, getUserMedia, File API, Blob, FileReader.

## Dados/offline
IndexedDB, LocalStorage, Service Worker.

## Mobile
React Native/Expo, Flutter/Dart, Kotlin, Swift.
AndroidManifest e Info.plist; permissões de galeria/câmera/microfone conforme APIs modernas
de cada sistema.

## Tooling
Node.js, Express/Fastify, Electron/Tauri (ferramentas auxiliares/desktop quando fizer sentido),
Webpack/Babel, ESLint, Prettier, Git, npm/yarn/pnpm.

## Observação
Nem todos os itens precisam entrar no bundle final. A arquitetura permite adicionar módulos
gradualmente sem misturar frameworks concorrentes no mesmo runtime.
