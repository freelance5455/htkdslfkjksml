# Elencos Série A — 25/10/2026

A versão 1.17.0 aplica ao jogo as listas fornecidas pelo usuário para 19 clubes e mantém o Athletico Paranaense da versão 1.16.9. O apelido “Galo” foi unido a Atlético-MG para evitar duplicação do clube. Nomes e números foram mantidos conforme enviados, inclusive números repetidos na fonte.

Os atributos/posições são estimativas de gameplay quando não havia correspondência na base anterior; não representam validação oficial de registro.
