# NIVEX

Esta pasta documenta a base V3.1. A entrega é executável e extensível, mas ainda não é um APK de produção final. Recursos que exigem codecs, GPU nativa, IA ou integração do sistema estão encapsulados como pontos de extensão.
