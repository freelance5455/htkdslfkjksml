# Game Ular Super — Fase 1 (modular)

Port modular dari `v2(Copy).html` dengan perbaikan bug inti. **Fase 1**: lihat `FEATURE-MATRIX.md` untuk apa yang sudah/belum ada.

## Menjalankan
- **Cepat:** buka `index.html` di browser. Tidak memakai ES module sehingga aman dari `file://` dan WebView (semua modul memakai namespace global `SU` lewat `<script>` biasa, urutan di `index.html` wajib dijaga).
- **Android WebView:** muat `index.html` dari assets (`file:///android_asset/...`) atau lewat `WebViewAssetLoader`. Tidak butuh server maupun jaringan.
- **Tes:** `sh tests/run-all.sh` (Node.js; tes browser butuh Python + `playwright` + Chromium, dilewati bila tidak ada).

## Struktur
`js/core` (config, state machine, main) · `js/gameplay` (engine murni tanpa DOM) · `js/storage` · `js/input` · `js/audio` · `js/render` · `js/ui` · `css/` · `assets/icons` · `tests/` · `tools/make_icons.py` (pembuat ikon).
Folder `js/systems`, `js/utils`, `assets/audio|fonts|images` sengaja dibiarkan kosong untuk Fase 2.

## Ikon untuk APK (wrapper buatan Anda)
- Legacy launcher: `assets/icons/android/mipmap-*/ic_launcher.png`
- Adaptive: `android-adaptive-foreground-432.png` + `android-adaptive-background-432.png` (foreground sudah di zona aman 66%); sumber vektor `android-adaptive-foreground.svg`.
- `favicon.*`/`app-icon-*.png` untuk HTML/PWA. Favicon HTML **tidak** otomatis menjadi ikon launcher Android.

## Catatan teknis penting
- Waktu game = detik game yang hanya maju saat `tick()`; pause otomatis menghentikan semua timer.
- Tombol Back Android tidak diintegrasikan (butuh kode wrapper). Di web, `P`/`Esc` menjeda. Wrapper dapat memanggil jeda dengan menyalakan `visibilitychange`/`pagehide` saat app ke latar (sudah ditangani).
- Ekspor backup memakai unduhan Blob; sebagian WebView memblokirnya → perlu `DownloadListener` di wrapper.
- Tema Special adalah easter egg; sandinya ada di kode (`js/core/main.js`) dan **bukan** keamanan.
