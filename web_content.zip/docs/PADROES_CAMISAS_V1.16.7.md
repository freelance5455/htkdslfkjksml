# Padrões de camisa — v1.16.7

A renderização traseira passou a usar o padrão do uniforme por clube, em vez de desenhar o mesmo conjunto de faixas horizontais em todos os casos.

Padrões suportados: camisa lisa/textura discreta, painéis laterais, listras verticais, listras horizontais em quantidades diferentes, faixa diagonal, faixas no peito e composições tricolores.

Exemplos de diversidade: Vasco da Gama usa faixa diagonal; Operário-PR usa painéis laterais contrastantes; Vitória e Atlético-MG usam listras verticais; Flamengo e Sport Recife usam faixas horizontais; Corinthians, Santos, Cruzeiro e Internacional usam base lisa com textura discreta.

As cores primária/secundária, o nome do atleta e o número continuam dinâmicos. A representação é uma réplica estilizada da identidade visual, não uma reprodução pixel a pixel de todos os uniformes oficiais.

Referências consultadas para variedade histórica e identidade:
- Vasco da Gama, uniforme e faixa diagonal: https://www.nike.com.br/nav/times/vasco
- Arquivo de camisas brasileiras: https://shirt-archive.com/pt-br/league/brasileirao/
- Vitória, exemplos de uniformes com listras verticais: https://ge.globo.com/ba/futebol/times/vitoria/noticia/2025/04/03/com-filho-de-matheusinho-como-modelo-vitoria-lanca-nova-camisa-para-temporada-2025.ghtml


## Correção v1.16.8
As listras verticais agora usam faixas alternadas largas, ocupando toda a área frontal do tronco desde a parte superior até a barra, com recorte na silhueta da camisa.
