# Carreira de Craque v1.26.5 — Seletor de clube

- Removidos os campos inline de país e clube da tela principal de criação de carreira.
- Adicionado seletor separado com título “País do Clube”, seletor de país, escudo grande, setas anterior/próximo e botões CONFIRMAR/VOLTAR.
- Brasil lista os clubes da base Sub-20; Inglaterra lista os clubes jogáveis da Premier League.
- Países sem clubes implementados exibem aviso e não permitem confirmar uma seleção vazia.
- Confirmar grava país e clube nos campos ocultos do formulário original, preservando a criação de carreira existente.
- Transição visual curta e layout responsivo para celular.


Atualizacao v1.26.6: escudos no seletor de clube ampliados para 176px (148px em telas pequenas), com mais area vertical para melhor visualizacao.
