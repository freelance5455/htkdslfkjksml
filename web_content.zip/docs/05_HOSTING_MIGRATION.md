# 5. Production hosting and safe migration off the phone

## Options (researched; prices change often, so verify on the provider's page)
| Option | Cost (indicative) | Verdict |
|---|---|---|
| **Small VPS** (Hetzner, Contabo, Hostinger, IONOS, Vultr, DigitalOcean, OVH, Kamatera…) | roughly **US$4–10/month** for 2 vCPU / 2–4 GB / 40+ GB disk. Hetzner repriced in June 2026 and the cheapest tier had limited availability; entry prices across providers vary and renewal prices differ, so confirm before buying | **Recommended.** Persistent disk, root access, runs your Flask+SQLite unchanged, supports big uploads, easy backups |
| Free tiers (PaaS free plans, Oracle "always free", etc.) | $0 | **Not recommended for student data.** I did not verify any free tier in this session; free plans commonly have no persistent disk, sleep when idle, cap upload size, or can be reclaimed. A free tier is fine for a throw-away staging copy only |
| Keep the phone | $0 | Not suitable as permanent production (battery, sleep, network, no redundancy) |

Choose a data-centre close to Nigeria's routes (Europe is typical). Cloudflare in front (free) caches static files and hides the server IP. For lesson videos consider YouTube/Vimeo embeds (already supported) to save bandwidth and disk.
Budget for **off-site backup storage** (a few dollars/month, or a free tier of any object storage with `rclone`).

## What is provided (`backend/deploy/`)
`bootstrap_server.sh` (users, folders, firewall, fail2ban, auto-updates, systemd, backup timer), `dagba.service` (gunicorn, hardened), `dagba.env.example` (secrets file, mode 640), `Caddyfile.example` or `cloudflared-config.example.yml` (HTTPS), `deploy.sh` (backup → migrate → switch → health check → automatic rollback), `backup.sh`/`restore.sh`, `export_for_migration.sh` / `import_migration.sh`, `healthcheck.sh`, `/healthz` endpoint. All the data-handling scripts were run on throw-away data here (export, import with count verification, refusal to overwrite, backup, restore, corrupt-backup rejection). `bootstrap_server.sh`, systemd and Caddy/Tunnel files could **not** be run here (no server) and need a first-run check by you or a technical helper.

## Safe migration plan (nothing destructive happens without your explicit step)
1. **Rent the VPS** (Ubuntu 24.04). Add your SSH key. Run `bootstrap_server.sh`. Edit `/etc/dagba/dagba.env` (new `SECRET_KEY`; keep `SITE_URL=https://dagbadigitalacademy.com`).
   Important: keeping the **same `SECRET_KEY` is not required**, but changing it signs everyone out once (acceptable).
2. **On the phone (Termux)**: `bash deploy/export_for_migration.sh`. It only *reads*: makes a consistent copy of the database and uploads plus a checksum and record-count manifest. Your live site keeps running.
3. Copy the `.tar` to the server (`scp`). Run `import_migration.sh`. It verifies checksums, imports, and prints source-vs-imported counts for users, courses, lessons, transactions, entitlements, certificates, progress and submissions. It **refuses** to overwrite a database that already has users.
4. Deploy the release: `tar czf release.tar.gz -C backend . && deploy.sh release.tar.gz` (runs the additive migrations 025–026, health-checks, rolls back automatically on failure).
5. **Rehearse before switching:** on your own computer add the server IP for `dagbadigitalacademy.com` in the hosts file (or use a temporary hostname) and check: sign-in, a course, a video, certificate PDF verification, an admin screen, a test bank-transfer submission.
6. **Final sync and cut-over (short maintenance window):** put the phone site in prelaunch/maintenance, repeat steps 2–3 into a *fresh* empty data folder (to pick up the last changes), then move the Cloudflare Tunnel route/DNS to the new server. Keep the phone copy, untouched, for at least 30 days.
7. Turn on monitoring (free uptime monitor on `/healthz`) and confirm the first scheduled backup appears **and** reaches the off-site remote (`BACKUP_REMOTE`).
**Rollback:** point the tunnel/DNS back at the phone. Because the phone was never modified, nothing is lost; any payments recorded on the new server during the window would need to be re-entered, so keep the window short.

Retain Termux for development (`termux-*.sh` scripts remain).
