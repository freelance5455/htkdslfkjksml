# Elenco Athletico-PR — referência 25/10/2026

- 1 — Mycael
- 23 — Santos
- 2 — Gilberto Júnior
- 29 — Gastón Benavídez
- 3 — Léo Pelé
- 4 — Arthur Dias
- 33 — Juan Aguirre
- 37 — Lucas Esquivel
- 5 — Felipinho
- 14 — Luiz Gustavo
- 16 — Jádson
- 27 — Juan Portilla
- 8 — João Cruz
- 10 — Bruno Zapelli
- 26 — Claudinho
- 47 — Chiqueti
- 7 — Steven Mendoza
- 9 — Kevin Viveros
- 11 — Isaac
- 18 — Kerwin Vargas
- 21 — Leozinho

Os números e nomes foram inseridos conforme a lista fornecida. Posições e overall são estimativas de gameplay.
