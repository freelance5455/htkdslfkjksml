# Maps and AI

## Maps
AMAZON GAZA uses Leaflet with OpenStreetMap-derived tiles instead of Google Maps. Device GPS is obtained through the browser/app location permission. The map must show OSM attribution. Public OSM tile/Nominatim services are best-effort and rate-limited; a production-scale deployment should use an OSM-derived commercial provider or self-host appropriate services and cache responsibly.

Official policies:
- https://operations.osmfoundation.org/policies/tiles/
- https://operations.osmfoundation.org/policies/nominatim/

## AI
AMAZON GAZA has a real server-side Gemini API adapter. Gemini provides a free tier for developers, subject to model, geography and rate limits. The API key is never shipped to the browser. Configure GEMINI_API_KEY on the API server.
