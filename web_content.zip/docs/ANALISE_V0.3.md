# Análise da base Carreira Craque v0.3

## Arquivos encontrados no ZIP original
- `CarreiraCraque_v3/index.html` — interface, estilos, estado da carreira, calendário, motor de placares, treinos, mercado e persistência em JavaScript no mesmo arquivo.
- `CarreiraCraque_v3/package.json` — scripts e dependências de preparação para Capacitor.
- `CarreiraCraque_v3/capacitor.config.json` — configuração inicial de empacotamento.
- `CarreiraCraque_v3/README.md` — instruções e limitações da versão.

## Recursos existentes preservados
- HTML/CSS/JavaScript mobile-first, sem migração desnecessária de tecnologia.
- Salvamento local e formato de dados legado `cc_v3`/`cc_v2`.
- A versão original tinha liga de 16 clubes, turno e returno em 30 rodadas. A atualização adiciona a Série A e a Série B de 2026, com 20 clubes e 38 rodadas em cada divisão.
- Criação do atleta, treino, estatísticas básicas, lesões/suspensões simplificadas e mercado local.
- Interface de pré-jogo, simulação automática, relatório pós-jogo e histórico.

## Lacunas identificadas na base
- Perfil de atleta resumido a oito atributos genéricos.
- Modos Híbrido/Decisões não tinham decisões reais durante o fluxo da partida; o usuário escolhia uma abordagem antes da simulação completa.
- Relatório com pouca estatística coletiva e sem estado de intervalo persistente.
- O universo era uma liga simplificada; copas, seleções e simulação mundial contínua não estavam presentes.
- Arquitetura centralizada em um único `index.html`; reorganizar em módulos grandes neste ciclo exigiria refatoração adicional e poderia quebrar a compatibilidade dos salvamentos e do empacotamento.

## Mudanças priorizadas nesta entrega
- Perfil expandido para 21 atributos e overall ponderado por posição.
- Migração de atributos antigos para o novo esquema, preservando valores e evitando descartar carreiras existentes.
- Intervalo interativo persistido nos modos Híbrido/Decisões; as escolhas de segundo tempo afetam o motor antes da geração da segunda etapa.
- Decisão individual contextual por posição no modo Decisões.
- Estatísticas coletivas e validações automatizadas de consistência entre eventos e placar.

## Fora do escopo concluído
A entrega não declara concluídos os módulos de copas, seleções, divisões/rebaixamento, simulação global completa, editor avançado de rosto, partidas 3D ou APK validado. Essas limitações estão listadas no `README.md` e devem ser tratadas em etapas futuras.
