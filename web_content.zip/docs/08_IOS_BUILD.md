# 8. iOS: build, TestFlight, release

**Needs:** a Mac with Xcode and CocoaPods **or** the GitHub Actions macOS job in `mobile/ci/ios.yml` (template, untested), plus an **Apple Developer Program** membership (paid annual fee; check current price). **Bundle identifier:** `com.dagbadigitalacademy.app`.
```
cd mobile && bash scripts/setup_native.sh ios      # on a Mac
npx cap open ios                                   # Xcode
```
In Xcode (not automated here; I had no Mac):
1. Signing & Capabilities → select your Team → "Automatically manage signing".
2. Add capabilities: **Push Notifications**, **Associated Domains** (`applinks:dagbadigitalacademy.com`), **In-App Purchase**.
3. Info.plist: `NSCameraUsageDescription` and `NSPhotoLibraryUsageDescription` (text like "Attach photos to assignments"), `ITSAppUsesNonExemptEncryption` = NO (HTTPS only; confirm with Apple's export-compliance questions).
4. Push on iOS: Capacitor's plugin returns an **APNs** token by default, but the server sends through **FCM**. Add Firebase to the iOS project per Capacitor's push-notification guide (Firebase iOS SDK + `GoogleService-Info.plist` + APNs key uploaded in Firebase console), so the token registered with `/devices` is an FCM token.
5. Product → Archive → Distribute App → App Store Connect → upload. Add testers in **TestFlight**; test purchases with Sandbox testers.
6. Deep links: set admin setting `mobile.apple_app_id` = `<TEAMID>.com.dagbadigitalacademy.app` so `/.well-known/apple-app-site-association` is served.
Status: **nothing in this document has been executed** (no Mac, no Apple account). Treat it as a checked-in checklist, not a verified result.
