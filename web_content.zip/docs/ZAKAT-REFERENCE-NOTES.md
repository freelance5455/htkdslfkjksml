# Zakat estimator reference notes

TO‘LOVCHI's calculator is an editable estimate, not a religious authority. It stores the user's selected basis, currency, metal price, calculation date, assets, deductions and confirmations locally. It does not claim live market rates. A payable 2.5% estimate remains unavailable until the user has entered a current metal price and personally confirmed both the selected nisab threshold and applicable lunar-year/haul condition.

The Hanafi-oriented starting references are 87.48 grams of gold and 612.35 grams of silver. AskImam's Darul Iftaa answer describes these as conversions for 20 mithqals and 200 dirhams and cites Hanafi source texts. Islamic Relief lists 87.48 grams of gold and 612.36 grams of silver, and describes its advice to use silver nisab. The hundredth-gram silver difference reflects source rounding; the calculator makes the gram weight editable and shows the source/method instead of presenting one figure as a universal ruling. Islamic Relief also describes a full lunar year as part of the conditions. [1] [2] [3]

The app does not decide whether a particular asset, liability or deduction is zakatable under a user's school or circumstances. Users can choose or edit the reference. Unconfirmed conditions never produce a payable estimate. Ask a qualified scholar about personal circumstances.

## References

[1]: https://www.askimam.org/public/question_detail/16927 "AskImam and Darul Iftaa on Hanafi nisab weight conversion"
[2]: https://www.islamic-relief.org.uk/giving/islamic-giving/zakat/nisab/ "Islamic Relief on nisab weights and silver guidance"
[3]: https://islamic-relief.org/zakat-calculator/ "Islamic Relief Zakat calculator and haul explanation"
