# AccoNova — Gap report / گزارش شکاف‌ها

Status legend: **Done** = implemented and tested in this package · **Local** = works, but only inside the browser (not a server guarantee) · **Server** = needs a real backend; design + SQL provided, not running.

| Area (plan) | Requirement | Status | Evidence |
|---|---|---|---|
| Double-entry engine | Balanced entries, TB, GL, reversal, no edits | **Done** | `tests/core.test.mjs` (balance group), `database/migrations/001_core.sql` trigger |
| Integer money | No floats; rounding rule | **Done** | BigInt `mulDivRound`, currency group |
| Data integrity | Atomic posting, idempotency, hash chain | **Local** | duplicate / immutable groups; DB: unique index + immutability triggers (tested in Postgres) |
| Fiscal periods | Close / reopen / year-end | **Done** | periods group |
| Users & roles | owner/admin/accountant/viewer, escalation rules, last owner | **Local** | permissions group; DB `LAST_OWNER` trigger tested |
| Optional local password | Lock screen, required before erasing data (PBKDF2-SHA256, salted, 5-try lockout) | **Local** | password group; E2E. Not encryption — local convenience only |
| Per-section data erase | Sales / purchases / payments / manual journal / contacts, owner only, backup first, ledger re-chained | **Local** | erase group (18 checks) + E2E |
| Authentication | Real login, MFA, sessions | **Server** | Not possible honestly in a static page; schema fields prepared |
| Tenant isolation | Cannot read other company | **Local** + **Server** | tenant group; RLS policies tested in Postgres with a non-bypass role |
| Subscriptions | Free/Pro/Business limits, grace, downgrade | **Done** (limits) | subscription group |
| Paid sections (monthly) | Purchases + supplier payments, VAT summary, ageing/BS reports, multi-currency, encrypted backup, more members; audit CSV on Business. Enforced in the data layer | **Done** | `paid` group; E2E |
| Languages | Persian, English, Arabic, French, German (RTL/LTR) | **Done** | i18n test: 646 keys × 5 languages; browser test per language. AR/FR/DE are machine-drafted — have a native speaker proofread before launch |
| Terms of Use / Privacy | In-app texts in 5 languages, acceptance gate with version, footer links | **Draft** | Fill `LEGAL CONFIG` (owner, e-mail, law, refunds) and have a lawyer review. No text can guarantee freedom from legal disputes |
| Payment gateway | Real checkout + webhooks | **Server** | HMAC-verified handler + simulator; real gateway needs server & secret |
| Reports | TB, GL, P&L, BS, AR/AP ageing, CSV, print | **Done** | E2E |
| Backup | Verified, encrypted (AES-256-GCM), restore to new company | **Local** | backup group; server-side scheduled backup = **Server** |
| Monitoring / ops | Alerts, logs, uptime | **Server** | see `docs/deployment.md` |
| Multi-currency | Rates, FX difference | **Done** | currency group |
| Locales | fa/en, RTL/LTR, Jalali + Gregorian | **Done** | `tests/jalali.test.mjs`, `tests/i18n.test.mjs` |
| Tax | Tax codes per line | **Done** (basic) | country-specific e-invoicing = **Server / legal** |
| Performance | 1,500 entries | **Done** | perf test |

Acceptance tests of the plan (9): balance ✔, tenant isolation ✔, duplicate posting ✔, cash-flow consistency ✔, permissions ✔, subscription webhooks ✔ (simulated), backup restore ✔, performance ✔, multi-currency ✔.
