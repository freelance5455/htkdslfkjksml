# Enable the Qwen3-TTS neural engine

This starter contains an optional Qwen3-TTS adapter. Model weights are not bundled; they are large and must be downloaded to your server.

## Model capabilities and limits
The official Qwen3-TTS repository describes voice design and reference-based voice cloning for 10 major languages: Chinese, English, Japanese, Korean, German, French, Russian, Portuguese, Spanish and Italian. It does **not** claim every language. Urdu, Hindi, Arabic and Punjabi are not listed in its published supported-language list. Source: https://github.com/QwenLM/Qwen3-TTS

## Install on a compatible GPU server
Use a fresh Linux environment. Upstream recommends Python 3.12. Install a PyTorch build compatible with your CUDA driver first, then:

```bash
python -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r backend/requirements-gpu.txt
```

Set environment variables before starting the app:

```bash
export VOXFORGE_ENGINE=qwen3
export QWEN_TTS_DEVICE=cuda:0
export QWEN_TTS_DTYPE=bfloat16
uvicorn app.main:app --app-dir backend --host 0.0.0.0 --port 8000
```

Default models:
- `Qwen/Qwen3-TTS-12Hz-1.7B-VoiceDesign` for description-based character voice design.
- `Qwen/Qwen3-TTS-12Hz-1.7B-Base` for reference-audio voice cloning.

If the GPU does not support bfloat16, try `QWEN_TTS_DTYPE=float16`. CPU mode may be much slower. First use downloads model weights, so provision disk space and network access. For production, move inference to a separate GPU worker and keep the public API lightweight.

## Voice cloning flow
1. Obtain a clear recording you own or have explicit permission to clone.
2. Upload it through Voice cloning and enter the exact transcript spoken in the reference.
3. The backend stores the recording in a private local reference directory and records the transcript.
4. Use `POST /api/synthesize` with `custom_voice_id` to synthesize using the stored reference; the API retrieves its transcript.
5. Delete references when no longer needed using `DELETE /api/voices/custom/{voice_id}`.

## Engineering notes
- Model weights are loaded lazily and cached in the API process. Loading both 1.7B models can consume substantial GPU memory. For constrained GPUs, split tasks into separate workers or load only one model at a time.
- Rate and pitch are passed as natural-language style preferences, not guaranteed low-level controls.
- Preset names are style prompts, not 50 independently trained vocal identities. Curate and quality-check actual timbres before promising 50 unique voices.
- Add authentication, HTTPS, access controls, per-user storage isolation, rate limits, retention policies and deletion controls before public deployment.
- Use only voices with informed consent. Never use cloning to impersonate or deceive.
