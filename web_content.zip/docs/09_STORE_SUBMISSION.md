# 9. App-store submission guide and checklists

I cannot and do **not** claim approval or publication; reviews are done by Apple and Google.

## Before you submit (both stores)
- [ ] Production API is live over HTTPS and migrated (`05`), backups reaching off-site (`06`).
- [ ] Prelaunch mode OFF for the audience you want to reach (the app shows "We're launching soon" while it is on).
- [ ] Privacy policy updated (`store/privacy_policy_addendum.md`), terms and refund pages current, support email/WhatsApp set in admin settings.
- [ ] `/delete-account` page loads; in-app deletion works with a throw-away account.
- [ ] Store billing configured and **sandbox-tested** (`04`); products exist in consoles.
- [ ] A **reviewer demo account** (student) with a purchased course and a subscription, credentials in the review notes. Also a way for reviewers to reach purchase screens.
- [ ] Real screenshots captured from a device/emulator (see list below). **No screenshots are included, because no emulator or browser was available to produce honest ones.**
- [ ] `min_app_version`, version numbers and `API_BASE` correct; `npm run check && npm test` pass.

## Google Play
App content: privacy policy URL, ads (No), data safety (`store/data_safety.md`), content rating questionnaire, target audience, news/health/finance declarations (none), government app (No). Provide the account-deletion URL. Complete the closed-testing requirement for new personal accounts if it applies (`07`). Upload `.aab`; roll out to production in stages.

## Apple App Store
App Store Connect → new app (bundle id) → listing, screenshots (6.9"/6.5" iPhone required sizes; iPad if supported), App Privacy labels, age rating, review notes with demo account, **in-app purchases attached to the version**, export compliance, then submit. Expect reviewers to test: sign-in, **sign-up without forcing purchase**, account deletion in-app, restore purchases, and that no external payment is offered. Guest browsing of the catalogue is implemented (login is needed only for learning/buying).
Guideline watch-outs for this app: 3.1.1 (IAP; done), 5.1.1(v) (in-app account deletion; done), 1.2 (user-generated content: discussions are moderated by staff; add a visible "report" path or confirm staff moderation in review notes), 2.1 (app must work: demo account), 4.2 (not a thin website wrapper: native push, secure storage, offline reading, deep links).

## Suggested screenshots (capture 6–8 per device size)
Home with banners · Explore with filters · Course detail · Lesson (video) · My Learning with progress · Certificate · Activity · Profile. Use sample/demo content that is realistic and rights-cleared.

## Review notes template
"Demo student: email … password … (has an enrolled course and an active Academic subscription). Payments inside the app use Google Play Billing / Apple IAP. Account deletion: Profile → Delete account. The app displays course content fetched from our server; it contains no code downloaded outside the web-layer assets bundled in the app."
