# TO‘LOVCHI Android build guide (owner-operated)

This repository contains two separate targets: the Super Admin Dashboard at the repository root, and the customer finance app in `mobile/`. This guide covers only the Android customer app. It explains the existing build configuration; it does not claim that an APK or AAB has already been built.

## Before a release build

The current app ID `uz.tolovchi.app` is a placeholder. Choose an unused package ID that you own before creating the Play Console app; Play package IDs are permanent for that listing. Also create owner-controlled accounts for Expo/EAS and Google Play Console, and decide which trusted Git repository and source history you will maintain. This project currently has no EAS project ID, Expo credential, Play Console listing, signing credential or connected owner GitHub repository.

1. Open the project in the owner-controlled Git repository. Preserve the whole repository, including `mobile/`, `pnpm-lock.yaml`, `pnpm-workspace.yaml` and the root deployment docs. The root dashboard and mobile app are separate applications in this one repository.
2. In the Expo/EAS account that you own, link `mobile/` to your EAS project and set its project ID as `EXPO_PUBLIC_EAS_PROJECT_ID`. Set `EXPO_PUBLIC_ANDROID_PACKAGE` to the package ID approved for your Play listing. Set `EXPO_PUBLIC_IOS_BUNDLE_ID` only if you are also preparing the iOS app. These are public identifiers, not secrets.
3. Keep signing credentials in your own Expo/EAS account or owner-controlled key vault. Do not put private keys, service-account JSON, store credentials or purchase-verification secrets in source code, `.env.example` or any `EXPO_PUBLIC_*` variable.
4. Review the native permissions and privacy disclosures. The app uses SQLCipher for local financial storage, local notifications and optional device biometrics. A SQLCipher-capable native build is required; Expo Go is not sufficient.
5. Run the checks from the repository root: `pnpm install --frozen-lockfile`, `pnpm mobile:check`, `pnpm mobile:test` and `pnpm mobile:doctor`. Resolve reported issues before releasing.

## Existing build profiles

The profiles are already in `mobile/eas.json`:

| Purpose | Profile | Output |
| --- | --- | --- |
| Internal testing / direct install | `preview` | Android APK |
| Google Play upload | `production` | Android App Bundle (AAB) |

After configuring EAS and selecting owner-controlled credentials, run commands from the `mobile/` directory:

```sh
eas build:configure
eas build --platform android --profile preview
eas build --platform android --profile production
```

The first build may prompt you to confirm application identity and create or select signing credentials. Read each prompt and select only accounts and credentials owned by you. The `preview` artifact is an internal APK; install it only from your private EAS build link. The `production` artifact is an AAB for Play Console; it is not a direct-install APK. Use Play Console's internal testing track to install and test an AAB before a wider release. Increment `versionCode` for each Android release in `mobile/app.config.ts`.

## Current artifact-generation status (2026-11-09)

The Android JavaScript production export succeeded with `expo export --platform android`, but that output is only a JavaScript bundle—not an APK or AAB. This existing repository is bound as a Webdev Web project, and its available project tools do not expose an Android native-build action. The current Sandbox also lacks the Android SDK, Gradle, ADB and EAS CLI; no owner Expo/EAS project ID, EAS token or signing/Play credentials are connected. **No APK or AAB has been generated.**

Do not reinitialize or replace this repository as a Mobile-only project: the Super Admin Dashboard and customer app are intentionally kept together. To produce signed artifacts, connect this existing `mobile/` app to an Expo/EAS project and source repository under the owner's accounts, select a permanent package ID, and create the configured `preview` and `production` builds from the owner-controlled EAS workflow. Run the physical-device verification below before any Play release.

## Using an Android phone

1. Sign in to your Expo/EAS, owner Git and Play Console accounts in Chrome on your phone. Protect those accounts with strong authentication; do not paste passwords, recovery codes or signing secrets into this repository or an issue.
2. Once the source repository is connected to your EAS project, use the EAS build page on the phone to start or monitor a build if that workflow is available for the linked project. Download the completed **preview APK** from the private build page and approve Android's installation prompt only after confirming the account and project.
3. To test the Play-format **AAB**, use the Play Console internal testing release flow; an AAB is not installed directly like an APK. Review the release summary, app signing and privacy declarations before submitting it.
4. If EAS has not been linked to an owner-controlled source repository, an Android phone alone cannot produce the signed artifact from this project yet. Complete the one-time source/EAS project and signing setup first, or use a trusted developer operating only under your accounts. This repository does not currently contain a downloadable APK or AAB.

## Verify the installed native app

Install the preview APK on a supported Android device. Complete onboarding, verify that the encrypted local database opens (the app must not fall back to plaintext), and exercise a sample transaction, local reminder permission, report export, PIN/biometric settings and the Uzbek/Russian/English selectors. Confirm that the app remains usable with networking disabled. Test only with fictional sample data. Expo Doctor and unit tests do not replace this real native-device check.

## Features requiring owner services or further implementation

- **Premium / store billing:** the status screen deliberately does not start purchases or claim entitlement. The owner must provide Play product IDs, an authorized purchase-verification service and test purchases. iOS also needs Apple Developer/App Store Connect and StoreKit setup.
- **Ads:** AdMob is disabled; there are no owner publisher/app/ad-unit IDs or consent configuration. Never use production ad IDs for development or expose finance data to an ad SDK.
- **Backup and family sharing:** manual encrypted file backup/restore is implemented locally. AES-256-GCM protects the export with a user-chosen passphrase; the app does not upload it or include the SQLCipher key/PIN. Restore replaces local finance records and saved preferences. The user must keep the file and passphrase separately; neither can be recovered by the owner. Test file sharing, file picking and complete restore on physical Android/iOS devices before release. Automatic/cloud backup and family sharing remain disabled.
- **Support and live operational metrics:** no customer support, crash analytics or admin-to-app configuration feed is connected. Do not send personal finance data to the Super Admin Dashboard, support tickets, analytics or crash logs.

For dashboard deployment, keep using [`DEPLOYMENT.md`](./DEPLOYMENT.md); the customer finance database is intentionally separate and local-only.
