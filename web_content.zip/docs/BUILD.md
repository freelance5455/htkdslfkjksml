# Build

Requirements: Node.js 20+.

npm install
npm run typecheck
npm test
npm run build
npm start

The application binds to 0.0.0.0 and uses PORT (default 3000).

Before production deployment:
1. Configure real AI/search/media providers.
2. Configure database.
3. Configure secrets server-side.
4. Run tests/typecheck/build.
5. Deploy.
6. Verify health endpoint and real user journeys.
7. Only then mark deployment VERIFIED.

Android Companion:
use its own standard Gradle project with Android SDK and Java 17.
Do not treat a synthetic APK as a genuine Android build.
