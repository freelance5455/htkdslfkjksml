# Recursos V3.0

- Tela de carregamento discreta
- Tela de projetos e botão +
- Importação de fotos/vídeos/áudio
- Timeline multicamadas
- Keyframes e curvas
- Máscaras e composição
- Texto e motion graphics
- Efeitos: glow, blur, motion blur, glitch, RGB, distortion, VHS, neon, partículas
- Color grading e LUTs
- Áudio, waveform, mixer e redução de ruído
- IA preparada para remoção de fundo, tracking, legendas e auto-reframe
- Exportação 720p/1080p/1440p conforme aparelho
- FPS 20/24/25/30/40/50/60/90/120/144 conforme suporte
- Salvamento local e recuperação
- Permissões solicitadas sob demanda
- Modo de compatibilidade para aparelhos fracos
