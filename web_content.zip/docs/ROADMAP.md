# ZEIN roadmap

## Milestone 0 — UI starter
Responsive Arabic RTL shell, personal/business mode, local demo contacts and platform registry.

## Milestone 1 — Identity and workspace security
Supabase Auth, profiles, workspaces, workspace memberships, server-side role checks, row-level security.
No user-controlled role claims in editable metadata.

## Milestone 2 — Unified inbox foundation
Normalized conversations/messages schema, connector registry, webhook ingestion, delivery state, retry queue.
Store provider IDs and minimal permitted message metadata; respect each provider's retention and messaging rules.

## Milestone 3 — Provider integrations
Implement one provider at a time after reviewing current API access, app review, permissions and region/account eligibility.
Initial candidates: Telegram bot integration, WhatsApp Business Cloud API, Meta Messenger/Instagram messaging for eligible professional accounts, Gmail OAuth.

## Milestone 4 — AI and calls
Server-mediated AI provider, explicit user consent, redact secrets, usage limits.
Calls through WebRTC/SFU or a supported provider; do not claim interoperability with third-party private calls.

## Milestone 5 — Android release
Native permissions, deep links, push notifications, secure token storage, QA, signed release APK/AAB.
