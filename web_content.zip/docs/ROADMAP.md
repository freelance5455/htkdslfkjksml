# Evolução técnica

1. Motor de composição WebGL/WebGPU em Worker.
2. Exportador de vídeo via WebCodecs com fallback FFmpeg/WASM.
3. Decodificação/encode por hardware conforme plataforma.
4. Tracking, remoção de fundo, auto-reframe e beat sync como módulos.
5. Asset packs baixáveis para aumentar recursos ao longo do uso, em vez de inflar o pacote inicial.
6. Native shell Android/iOS com permissões sob demanda.
