# Roadmap técnico

1. Consolidar editor web/React + TypeScript.
2. Criar motor de timeline e modelo de projeto.
3. Integrar processamento Canvas/WebGL.
4. Adicionar WebCodecs/FFmpeg WASM com fallback.
5. Integrar armazenamento IndexedDB.
6. Criar bridge nativa Android/iOS.
7. Otimizar memória, GPU e exportação.
8. Testar em aparelhos de diferentes classes.
9. Adicionar módulos avançados e IA.
