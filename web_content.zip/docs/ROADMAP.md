# Roadmap

v1.2: richer editors, media preview/upload adapters, permissions model, notification center.
v1.3: backend adapter, real authentication, database schema, server validation.
v1.4: advanced analytics, search indexing, migrations, audit log.
v2.0: production deployment, observability, automated testing, API integrations.