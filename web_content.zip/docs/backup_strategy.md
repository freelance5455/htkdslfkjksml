# PostgreSQL Disaster Recovery & Backup Strategy

## 1. Automated Daily Backups (`pg_dump`)
Run encrypted database dumps using standard PostgreSQL tools:
```bash
pg_dump -h localhost -U postgres -F c -b -v -f "/var/backups/supermarket_pos_$(date +\%Y\%m\%d_\%H\%M\%S).dump" supermarket_pos
```

## 2. Restoration Testing (`pg_restore`)
Regular restoration validation drill:
```bash
pg_restore -h localhost -U postgres -d supermarket_pos_recovery -v "/var/backups/supermarket_pos_latest.dump"
```

## 3. Retention Policy
- Daily snapshots: retained for 30 days.
- Weekly snapshots: retained for 12 weeks.
- Monthly archives: retained for 7 years offsite in encrypted S3/GCS cold storage.
