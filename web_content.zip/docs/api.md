# RESTful API Specifications

All endpoints return a uniform response envelope:
```json
// Success
{
  "success": true,
  "data": { ... }
}

// Error
{
  "success": false,
  "error": {
    "code": "ERROR_CODE",
    "message": "User-safe error description"
  }
}
```

### Endpoints
- `POST /api/auth/login`: Authenticate user and issue session
- `POST /api/auth/logout`: Invalidate session
- `GET  /api/auth/me`: Retrieve current session user & permissions
- `GET  /api/products`: Search and list products (supports barcode, sku, query)
- `POST /api/products`: Create new product (requires `PRODUCT_CREATE`)
- `GET  /api/inventory`: Real-time stock counts across branches
- `POST /api/inventory/adjust`: Record stock adjustment and create movement
- `POST /api/sales`: Atomically commit POS sale, deduct stock, and update register
- `POST /api/refunds`: Process customer return and restore inventory
- `GET  /api/reports/dashboard`: Fetch live dashboard KPIs and analytics
- `GET  /api/reports/sales`: Financial breakdown and trends
- `GET  /api/cash-sessions`: Active and closed cash drawer sessions
