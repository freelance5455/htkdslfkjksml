# Web + Android Native Bridge

The launcher activity is a local WebView (`file:///android_asset/web/index.html`) and exposes a small, device-local JavaScript bridge named `AndroidJarvis`.

Implemented native actions include:
- Open installed apps by package or visible label
- Open Accessibility settings and overlay settings
- Read visible accessibility text
- Tap visible UI text and clickable parents
- Type into the focused/editable field
- Home / Back / Recents
- Scroll up/down
- Turkish native speech recognition
- Current local time without network
- WhatsApp contact lookup from Android Contacts and opening a prefilled chat
- Explicit `gönder/yolla` commands attempt to press WhatsApp's Send button through Accessibility

Limitations are platform-enforced: Accessibility must be enabled by the user, Contacts permission is needed for name-based WhatsApp messaging, and Android does not permit a WebView to replace privileged OS services. Cloud LLMs still need network access; the deterministic native commands do not.
