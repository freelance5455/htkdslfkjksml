# TO‘LOVCHI — Release status

**Checked:** 2026-11-09
**Repository:** existing dual-target repository; no replacement project was created.

## Executive status

The core customer-app source and existing Super Admin Dashboard remain in the repository. The offline MVP source is substantially implemented and automated checks pass. **TO‘LOVCHI is not yet a signed Android release and is not ready to submit to Google Play:** no APK or AAB was produced, and native-device checks have not been performed. The current project is configured as a Webdev Web project; its available project actions do not include a native Android builder.

## Implemented in source

The mobile app contains the local finance dashboard; income and expense tracking; custom categories; recurring bills and permission-aware local reminders; debts, repayment history and partial repayments; budgets; financial calendar; editable Zakat estimates and annual reminders; UZS/USD/EUR/RUB plus custom currencies and user-entered dated exchange rates; monthly reports and CSV/PDF export; Uzbek, Russian and English UI; Settings; PIN/biometric lock controls; and offline-first local data operations. Native SQLCipher configuration, app-switcher/screenshot concealment and secure-device APIs are present in source, but require a native build and phone test before their device behavior can be claimed verified.

A user-initiated portable backup/restore is implemented in source: AES-256-GCM with a user-held passphrase and PBKDF2-HMAC-SHA256, validated/allowlisted database snapshot, transactional local restore, and reminder rescheduling. The backup includes the saved Zakat profile but excludes PIN, SQLCipher key and onboarding state. Crypto and repository behavior have automated coverage. Restore/share/file-picker behavior still needs a physical-device test. Automatic/cloud backup is not active.

The existing Super Admin Dashboard retains password + TOTP and recovery-code controls, roles, protected APIs and audit logs. It has no user-level financial lookup; its business, health, support and operational numbers are synthetic demo data until aggregate-only production sources are connected. The owner Android manual and portable dashboard deployment guide remain in the repository.

Premium billing, AdMob, family sharing, customer-support integration and live admin analytics/release sources remain disabled or unconnected. No purchase or paid entitlement is simulated. The in-app privacy policy and terms are drafts for owner and legal review, not legal approval.

## Verification performed

| Check | Result |
| --- | --- |
| `pnpm mobile:check` | Passed |
| `pnpm check` | Passed |
| `pnpm test` | Passed: 45 tests across 12 files, including dashboard security, finance domains, backup encryption and restore validation |
| `pnpm build` | Passed; Vite emitted a large-JavaScript-chunk advisory (about 883 kB uncompressed), not a build failure |
| `CI=1 pnpm --filter @tolovchi/mobile exec expo export --platform android --output-dir /tmp/tolovchi-android-js-export` | Passed; generated an Android JavaScript/Hermes bundle only. **This is not an APK or AAB.** |
| `pnpm mobile:doctor` | 19 of 20 checks passed. The remaining React Native Directory metadata request failed with an unexpected server response; the failure is a remote metadata check and does not establish a local dependency error. |
| `mobile/eas.json` profiles | Validated: `preview` requests APK; `production` requests AAB. |

No physical-device tests or release screenshots are claimed.

## Android artifact status

| Artifact | Status |
| --- | --- |
| Preview APK | **Not generated** |
| Google Play AAB | **Not generated** |
| Android JavaScript export | Generated successfully; not installable as an app |
| Google Play release readiness | **Not ready** |

Build blockers found in this environment: Android SDK, Gradle, ADB and EAS CLI are absent; no `EXPO_PUBLIC_EAS_PROJECT_ID`, EAS token or owner signing credentials are configured; and this existing Web project exposes no Dashboard APK/AAB build action. The EAS profiles are configuration only, not artifacts. The app identifier `uz.tolovchi.app` is still a placeholder and must be replaced with a permanent owner-chosen package ID before creating the Play listing.

Do not rebuild this repository as a Mobile-only project: that would jeopardize the requirement to keep the Dashboard and customer app together. Follow the existing [Android phone build guide](./BUILD-ANDROID-PHONE.md) after connecting the `mobile/` app to owner-controlled Expo/EAS and source accounts. It describes the preview APK and production AAB profiles and the actual owner steps.

## Owner actions before release

1. Choose a permanent, available Android package ID and confirm the app name, owner/publisher identity, support address and domain.
2. Create or connect owner-controlled Git/source, Expo/EAS and Google Play Console accounts; create the EAS project, configure signing under the owner’s control, and link the existing `mobile/` app. Do not send passwords, tokens or signing keys in chat.
3. Create the preview APK and production AAB from that EAS project. Install the APK on a real supported Android device and verify SQLCipher-protected storage, restart persistence, offline use, notification permissions and recurrence, exports, encrypted backup/restore, PIN/biometrics and Uzbek/Russian/English navigation using fictional data.
4. Review and approve the policy/terms with appropriate counsel and complete Play privacy/data-safety declarations. Do not submit a public production release until the owner reviews the Play listing and release summary.
5. Before enabling monetization, implement and verify Google Play purchase validation and provide owner-controlled product IDs; configure AdMob app/ad-unit IDs and consent flows. These are not implemented or enabled. Family sharing and automatic cloud backup also remain disabled.
6. For real Dashboard metrics, connect owner-approved aggregate-only analytics, crash/health, support, release and service-usage sources; retain data minimization and redact identifiers/financial content.

For the Dashboard’s Android-phone administration steps, see [Owner Manual](./OWNER-MANUAL-ANDROID.md). The repository-wide deployment and account-ownership guidance is in [Deployment Guide](./DEPLOYMENT.md); the customer app setup is also summarized in [mobile/README.md](../mobile/README.md).
