# Interpretation policy

## Separation of concerns
- Chart positions and aspects must come from deterministic ephemeris calculations, never from language-model guessing.
- The interpretation engine emits structured indicators and warnings.
- AI may explain those indicators in natural Bulgarian but must not invent chart facts or silently change the verdict.
- If calculations fail, show “Не може да се направи надеждно тълкуване” rather than fabricate a result.

## Verdicts
Use “По-скоро благоприятно”, “По-скоро неблагоприятно”, “Нееднозначно” and “Недостатъчно данни”.
Avoid certainty language such as “със сигурност”, “гарантирано” or claims about another person's private thoughts as fact.

## Confidence
The score is an interpretation-consistency indicator based on completeness, clear perfection/non-perfection indicators, Moon condition, and conflicting testimony. It is not a calibrated probability of the event occurring. Label it “Съгласуваност на показателите”, not “вероятност”.

## Timing
Only provide a symbolic time range when a valid applying aspect and a documented timing rule support it. Otherwise say timing is indeterminate. Never manufacture a months/years estimate from an arbitrary orb.
