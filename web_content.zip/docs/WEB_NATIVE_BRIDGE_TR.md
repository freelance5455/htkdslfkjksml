# Web + Android native bridge

Uygulama `index.html` arayüzünü WebView içinde çalıştırır. JavaScript `AndroidJarvis` köprüsü ile Kotlin tarafına bağlanır.

Desteklenen native çağrılar: Accessibility ayarları, uygulama açma, WhatsApp açma/mesaj akışı, metne dokunma, metin yazma, geri/ana ekran/son uygulamalar ve görünür ekran metnini okuma.

Not: Accessibility işlemleri Android ayarlarından kullanıcı tarafından etkinleştirilmelidir. WhatsApp'ın arayüz metinleri sürüme/dile göre değişebileceğinden otomasyon bazı cihazlarda ek uyarlama isteyebilir.
