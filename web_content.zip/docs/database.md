# Database Architecture & Entity Specifications

## Entity Relationship Summary
The system adheres to third-normal-form (3NF) relational principles with strict integrity constraints.

### Core Tables
1. **users**: System operators, cashiers, store managers, and administrators.
2. **roles & permissions**: RBAC mapping assigning granular abilities (e.g., `POS_CREATE_SALE`, `POS_REFUND`, `INVENTORY_ADJUST`).
3. **branches**: Multi-location retail network with distinct physical stock.
4. **categories & brands**: Product classification hierarchy.
5. **products & product_barcodes**: Catalog supporting multi-barcode alias mapping, cost, selling price, wholesale price, tax rate, and reorder levels.
6. **inventory & stock_movements**: Real-time stock counts by branch with an immutable movement history log.
7. **suppliers & purchase_orders**: Vendor management, automated procurement, goods receiving, and cost tracking.
8. **cash_registers & cash_sessions**: Opening balances, cash drawer drops/payouts, closing audits, and discrepancy monitoring.
9. **sales & sale_items**: Cashier transactions, itemized basket line items, taxes, discounts, tender details, and change.
10. **refunds & refund_items**: Authorised returns restoring inventory and recording refund reasons.
11. **audit_logs**: Immutable security trail recording logins, credential modifications, price changes, and stock updates.

## Monetary Data Types
All prices, discounts, taxes, and totals strictly use `NUMERIC(12, 2)` to eliminate floating-point rounding inaccuracies.
