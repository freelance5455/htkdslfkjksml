# Atualização v1.46.1 — Escudos da Série C

A Série C usa escudos próprios por clube em todos os lugares que chamam `crest(nome)`. Os clubes com arquivo local usam SVG local; os demais usam PNG transparente remoto.

Clubes cobertos: Amazonas, Anápolis, Barra, Botafogo-PB, Brusque, Caxias, Confiança, Ferroviária, Figueirense, Floresta, Guarani, Inter de Limeira, Itabaiana, Ituano, Maranhão, Maringá, Paysandu, Santa Cruz, Volta Redonda e Ypiranga.

Fonte dos escudos remotos: https://www.footylogos.com/pt-br/competition/brasileirao-serie-c. Os recursos remotos dependem de conexão à internet.
