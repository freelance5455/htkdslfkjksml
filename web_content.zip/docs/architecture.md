# System Architecture

## Overview
The Supermarket POS & Inventory Management System is an enterprise-grade, high-throughput retail platform designed for modern supermarkets, multi-branch department stores, and grocery chains.

## Layered Architecture

1. **Frontend Presentation & POS Terminal (React 19 + Tailwind CSS + Lucide Icons)**
   - High-speed cashier POS interface with barcode scanner support (USB / hardware scanner and keyboard input).
   - Keyboard accelerator shortcuts (`F2` Search, `F4` Hold, `F5` Resume, `F8` Tender/Pay, `ESC` Modal dismiss).
   - Offline transaction queue with automatic background reconciliation.
   - Thermal 80mm receipt generation and A4 printable tax invoices.
   - Comprehensive dashboard, inventory management, purchase orders, cash register balancing, and reporting.

2. **Application Server & Business Logic Layer (TypeScript + Express API)**
   - RESTful endpoints for POS sales, inventory ledger, purchasing, authentication, and reporting.
   - Atomic database transactions with strict ACID guarantees.
   - Decimal arithmetic protection for currency and tax precision.
   - Robust RBAC engine with fine-grained permissions.
   - Structured JSON audit logging for compliance and forensic trail.

3. **Data Persistence Engine (PostgreSQL / Prisma ORM & Cloud Firestore)**
   - Normalized relational PostgreSQL schema with UUID keys, indexes, foreign keys, and numeric types.
   - Dual resilience: Persistent Cloud Firestore live synchronization + PostgreSQL migration & seeding scripts.
   - Strict auditability with immutable `stock_movements` and `audit_logs` tables.
