# Architecture

**This package (local-first):** one `index.html`, no network (CSP `connect-src 'none'`). Data in `localStorage` (≈5 MB). Modules: `jalali` → `core` (engine, store, plans, backup) → `selftest` → `i18n` → `ui-core` → views → `main`.

**Production target:** NestJS + PostgreSQL 16 + React. Port `core.js` rules to a domain service; keep the same error codes. `database/migrations/001_core.sql` already enforces the invariants in the database: balanced entries (deferred trigger), immutability, closed periods, idempotency key, RLS (`SET LOCAL app.company_id / app.user_id` per request, app role without BYPASSRLS).

Request flow: auth → membership+role check → `BEGIN; SET LOCAL app.*; …; COMMIT` → audit row.
