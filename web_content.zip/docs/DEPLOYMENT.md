# Owner-controlled deployment guide

## What is included

This project is a React/Vite web client served by an Express/tRPC backend. Persistent dashboard settings, admin accounts and active status, server-side sessions, recovery-code hashes, announcements, release records, invitations and audit events use Drizzle ORM with a MySQL-compatible database. Admin passwords use Node.js scrypt; TOTP secrets are AES-256-GCM encrypted at rest; session identifiers are random and only their hashes are stored. The owner can suspend another administrator, revoke that administrator’s sessions and issue a single-use password/MFA re-enrollment link. Administrators can change their own password, which revokes all of their sessions. No Manus OAuth is required by this application flow.

The current development/Preview instance uses the managed project environment. That is not the same as transferring ownership of a cloud account, repository, database, domain or app-store account. To operate independently, the owner must deploy the source and migrations under accounts the owner controls and keep their own backup of the required encryption key. No Google Play, Apple, AdMob, analytics, crash-reporting, ticketing or cloud-cost provider is connected by default.

## Requirements

Use Node.js 22, pnpm 10.18 and a MySQL-compatible database. The included `Dockerfile` builds and serves the app on `PORT` (default 3000). Deploy behind HTTPS on a maintained container host and use a private database service with backups, encryption at rest and restricted network access. The health check is `GET /api/health` and intentionally reveals no user or database information. The web client sets a no-referrer policy so private invitation query tokens are not sent as cross-origin referrers.

## Required runtime configuration

Copy `.env.example` to a private environment settings panel or `.env` file outside source control. Set:

| Variable              | Purpose                                                                                                                                                                                         |
| --------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `DATABASE_URL`        | MySQL-compatible DSN for the owner-controlled production database. URL-encode reserved characters in the username/password.                                                                     |
| `ADMIN_SETUP_TOKEN`   | Unique, high-entropy one-time token for initial owner enrollment. Remove or rotate it after setup; enrollment closes once the owner claim exists.                                               |
| `TOTP_ENCRYPTION_KEY` | Unique, high-entropy value of at least 32 characters used to encrypt authenticator seeds. Keep a secure backup and make the same value available to the production deployment. Never commit it. |
| `PORT`                | Optional listener port; defaults to 3000.                                                                                                                                                       |
| `NODE_ENV`            | Set to `production` for the deployed container.                                                                                                                                                 |

Do not reuse secrets from a demo environment for unrelated services. Do not paste secret values into source code, issue trackers, chat, or the Git repository. The repository contains only placeholders in `.env.example`. Generate distinct random values in a password manager or an owner-controlled terminal (for example, `openssl rand -hex 32`); store `TOTP_ENCRYPTION_KEY` in the owner's secret manager and backup vault. `ADMIN_SETUP_TOKEN` is needed only for first owner enrollment and may be removed afterward.

## Build and deploy

1. Create a Git repository and cloud project under the owner’s own accounts. Import or upload this complete source tree; keep the `Dockerfile`, `pnpm-lock.yaml`, `drizzle/` migration files and `.env.example`.
2. Provision a private MySQL-compatible database and configure the runtime environment values above in the host’s encrypted secret manager. Enable HTTPS and point the owner’s domain to the container host.
3. Before the first app launch, install dependencies and apply the committed database migrations once: `pnpm install --frozen-lockfile`, then `pnpm db:migrate` with the owner-controlled `DATABASE_URL` set. Do not run schema migration generation during a normal deployment.
4. Build the container with `docker build -t tolovchi-admin .`, then run it using the owner’s secret manager and map the host’s HTTPS route to container port 3000. On a local or single-server setup, use the private environment file and never expose the database port publicly. For a managed container service, set its health check to `/api/health`.
5. Visit `https://YOUR-OWN-DOMAIN/?setup=owner`, enroll the owner with the one-time setup token and TOTP, and save recovery codes. After the initial owner exists, remove or rotate the setup token. Invite additional administrators from the Admin team page.
6. Confirm the health endpoint, sign-in and MFA, role access, HTTPS and database backup before routing production users to the deployment.

## Database changes and portability

Schema changes are in `drizzle/schema.ts` and committed as additive files under `drizzle/`. Apply the new migration once before publishing new code. Back up the destination database before migrations. The admin database intentionally contains no tables or fields for end-user debts, balances, income, zakat or personal financial records.

To move from one host/database to another, use the database export/import mechanism supplied by the owner’s source and destination providers; verify the export and restore privately before cutover. Preserve `TOTP_ENCRYPTION_KEY` securely during the move. If the key is lost or rotated, stored TOTP secrets cannot be decrypted; plan a secure MFA recovery/re-enrollment before making that change. Store passwords are not moved in the source repository.

The application process is stateless apart from its MySQL database, so additional web instances can share the same database behind a load balancer without rebuilding the application. Before running multiple instances at high scale, add a shared rate-limit service and operational monitoring; current sign-in throttling includes an in-process guard as well as per-account failed-attempt lockout. MFA challenge attempt counts, one-time invitation claims and recovery-code updates use database-backed atomic operations.

## Integrations and honest status

Dashboard metric cards, trends, technical incidents, support excerpts, service usage/cost estimates and the sample release history are explicitly labeled demonstration data. They are not produced by connected production sources. The feature-flag table and announcement/release registers persist changes for administrators, but the customer app, stores and advertising services do not yet consume or publish them. Add only aggregate, anonymized connectors, and screen/redact crash/support content before it reaches the dashboard. Keep the amber demo banner until live sources have been implemented and verified.

## Owner responsibility

This repository and deployment guide are portable, but this task does not create accounts at a third-party cloud host, register a domain, connect the owner’s GitHub, publish Android/iOS builds, or transfer an app-store listing. Complete those actions only from the owner’s own accounts. Keep encrypted database backups and MFA recovery codes separately from the running service.


## Two applications in one repository

The repository root is the existing Super Admin Dashboard (React/Vite plus Express/tRPC and the owner-only MySQL database). `mobile/` is the separate Expo/React Native customer finance app. Keep their environments and data boundaries separate: dashboard analytics are aggregate/demo or owner-sourced operations data; personal income, expenses, debts, bills, budgets and Zakat remain in the mobile app's SQLCipher database on the customer's device. Do not add customer finance tables, backup files or decrypted mobile exports to the admin database or its APIs.

The root commands remain `pnpm dev`, `pnpm check`, `pnpm test`, `pnpm build` and `pnpm db:migrate`. Mobile commands are `pnpm mobile:check`, `pnpm mobile:test`, `pnpm mobile:doctor` and `pnpm mobile:start`. Mobile native release profiles are in `mobile/eas.json`: `preview` produces an internal Android APK and `production` produces an Android App Bundle for Play. A custom native build is required for SQLCipher; Expo Go is not a release or encryption verification surface.

No Expo/EAS project, owner Git repository, Play Console app listing or signing credentials are connected, so this repository does **not** include a signed APK/AAB. The Android ID `uz.tolovchi.app` is a pre-release placeholder pending owner approval. The owner must choose a permanent package ID, link the mobile workspace to an Expo project and create builds with credentials under owner control. Follow [`BUILD-ANDROID-PHONE.md`](./BUILD-ANDROID-PHONE.md) for commands, account setup, phone workflow and release verification.

Premium purchase verification, AdMob production serving, cloud backup/restore, family sharing, customer-support integration and live admin operational metrics remain disabled or unconnected. Do not represent a saved dashboard flag or release record as having changed a published mobile build. The owner must supply and configure the appropriate store/provider accounts, IDs, privacy/consent disclosures and trusted services before those features can be enabled.
