"""
H.R.P AI TRADER 2026 - Unit Test for Security Audit & Anti-Rugpull
"""
import unittest
from backend.core.security_audit import SecurityAuditor

class TestSecurityAuditor(unittest.TestCase):
    def test_audit_token(self):
        auditor = SecurityAuditor()
        # Mock token data with safe parameters
        token_data = {
            "is_honeypot": False,
            "buy_tax": 1.0,
            "sell_tax": 1.0,
            "is_open_source": True,
            "owner_balance_percent": 2.0
        }
        result = auditor.audit(token_data)
        self.assertEqual(result["status"], "SECURE")

if __name__ == '__main__':
    unittest.main()
