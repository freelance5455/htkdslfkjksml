"""
H.R.P AI TRADER 2026 - Comprehensive Integration Test Suite (Moon Edition)
Author: Pakoyan / Hamidreza
Path: hrp_v1/tests/test_integration.py
"""

import pytest
from fastapi.testclient import TestClient
from hrp_v1.backend.api.main import app, orchestrator

client = TestClient(app)

def test_root_and_health():
    """تست سلامت و اتصال اولیه سرور API"""
    response = client.get("/")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ONLINE"
    assert "H.R.P AI TRADER" in data["system"]

    health_resp = client.get("/api/v1/health")
    assert health_resp.status_code == 200
    assert health_resp.json()["status"] == "operational"

def test_trade_execution_flow():
    """تست جریان ثبت سفارش و فیلترهای امنیتی"""
    payload = {
        "symbol": "BTC/USDT",
        "type": "BUY",
        "amount": 2500.0,
        "market_mode": "sandbox"
    }
    response = client.post("/api/v1/trade/execute", json=payload)
    assert response.status_code == 200
    res_data = response.json()
    assert res_data["status"] == "success"
    assert res_data["verified_by_antifab"] is True
    assert "order_id" in res_data

def test_market_validation_and_scoring():
    """تست اعتبارسنجی پِی‌لود بازار و موتور امتیازدهی هوش مصنوعی"""
    market_payload = {
        "symbol": "ETH/USDT",
        "price": 3450.50,
        "volume_24h": 1250000.0,
        "whale_flow_score": 8.5,
        "exchanges": [
            {"name": "Binance", "price": 3450.0},
            {"name": "KuCoin", "price": 3451.0}
        ]
    }
    response = client.post("/api/v1/market/validate", json=market_payload)
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "OK"
    assert data["anti_fabrication"] == "PASSED"
    assert "ai_score" in data
