/**
 * H.R.P AI TRADER 2026 - INTELLIGENCE & NLP ENGINE
 * مسئولیت: تحلیل اخبار، تشخیص نوسان‌گیری و امتیازدهی به اخبار (Scoring)
 */

const IntelligenceEngine = {
    // کلمات کلیدی برای تشخیص جهت بازار (Sentiment Analysis)
    keywords: {
        bullish: ['صعودی', 'افزایش', 'تایید', 'حمایت', 'خرید', 'bullish', 'surge', 'breakout', 'adoption', 'ETF', 'bull'],
        bearish: ['نزولی', 'کاهش', 'فشار فروش', 'مقابله', 'فروش', 'bearish', 'drop', 'crash', 'regulation', 'fud', 'bear'],
        whale: ['نهنگ', 'انتقال بزرگ', 'whale', 'large transfer', 'accumulation'],
        geopolitical: ['جنگ', 'تحریم', 'تنش', 'sanction', 'war', 'conflict', 'fed', 'interest rate']
    },

    // دیتابیس موقت برای ذخیره اخبار تحلیل شده
    newsCache: [],

    /**
     * تحلیل متن خبر (NLP Simulation)
     * @param {string} text - متن خبر
     * @returns {object} - شیء شامل امتیاز، جهت و دسته‌بندی
     */
    analyzeNews(text) {
        let score = 0; // از -5 تا +5
        let category = 'general';
        let sentiment = 'neutral';

        const lowerText = text.toLowerCase();

        // 1. تشخیص دسته بندی (Category Detection)
        if (this.containsAny(lowerText, this.keywords.whale)) category = 'whale';
        else if (this.containsAny(lowerText, this.keywords.geopolitical)) category = 'geopolitical';

        // 2. محاسبه امتیاز (Scoring Logic)
        // امتیاز مثبت برای کلمات صعودی
        this.keywords.bullish.forEach(word => {
            if (lowerText.includes(word)) score += 0.5;
        });

        // امتیاز منفی برای کلمات نزولی
        this.keywords.bearish.forEach(word => {
            if (lowerText.includes(word)) score -= 0.5;
        });

        // 3. تعیین جهت نهایی
        if (score > 1) sentiment = 'bullish';
        else if (score < -1) sentiment = 'bearish';

        const analysis = {
            id: Date.now(),
            timestamp: new Date().toLocaleTimeString('fa-IR'),
            text: text,
            score: score.toFixed(2),
            sentiment: sentiment,
            category: category
        };

        this.newsCache.unshift(analysis); // اضافه کردن به ابتدای لیست
        if (this.newsCache.length > 50) this.newsCache.pop(); // محدود کردن حافظه

        return analysis;
    },

    containsAny(text, list) {
        return list.some(word => text.includes(word));
    },

    /**
     * شبیه‌سازی دریافت اخبار جدید از API (مثلاً از CryptoPanic یا Twitter)
     */
    async fetchGlobalIntelligence() {
        // در نسخه واقعی، اینجا به Backend پایتون متصل می‌شود
        // فعلاً برای تست، داده‌های شبیه‌سازی شده تولید می‌کنیم
        const mockNews = [
            "انتقال بزرگ ۱۰۰۰ بیت‌کوین توسط نهنگ به صرافی با احتمال فشار فروش",
            "تایید خبر جذب سرمایه ETF برای اتریوم در بازار آمریکا",
            "افزایش تنش‌های ژئوپلیتیک در منطقه خلیج فارس و تاثیر بر بازارهای جهانی",
            "بریک‌اوت قیمتی بیت‌کوین در محدوده مقاومت اصلی"
        ];

        const newsToProcess = [];
        for (let news of mockNews) {
            newsToProcess.push(this.analyzeNews(news));
        }
        return newsToProcess;
    },

    /**
     * آپدیت کردن بخش اخبار در UI
     */
    updateNewsUI() {
        const newsContainer = document.getElementById('news-list-container'); // باید در HTML تعریف شود
        if (!newsContainer) return;

        newsContainer.innerHTML = this.newsCache.map(news => `
            <div class="card" style="border-right: 4px solid ${this.getSentimentColor(news.sentiment)}">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px;">
                    <span style="font-size: 0.6rem; color: var(--accent-gold);">${news.category.toUpperCase()}</span>
                    <span style="font-size: 0.6rem; color: var(--text-dim);">${news.timestamp}</span>
                </div>
                <p style="font-size: 0.75rem; margin: 0;">${news.text}</p>
                <div style="margin-top: 8px; font-size: 0.65rem; font-weight: bold; color: ${this.getSentimentColor(news.sentiment)}">
                    Score: ${news.score} | ${news.sentiment.toUpperCase()}
                </div>
            </div>
        `).join('');
    },

    getSentimentColor(sentiment) {
        if (sentiment === 'bullish') return 'var(--success)';
        if (sentiment === 'bearish') return 'var(--danger)';
        return 'var(--text-dim)';
    }
};

// اتصال به موتور اصلی در هنگام لود
document.addEventListener('DOMContentLoaded', async () => {
    await IntelligenceEngine.fetchGlobalIntelligence();
    IntelligenceEngine.updateNewsUI();
});
