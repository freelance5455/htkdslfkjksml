"""
H.R.P AI TRADER 2026 - Market Regime Detection Engine (Enterprise Edition)
Author: Pakoyan / Hamidreza
Path: hrp_v1/backend/engines/regime.py
"""

import logging
from typing import Dict, Any, List

logger = logging.getLogger("HRP.RegimeEngine")

class MarketRegimeEngine:
    """
    Analyzes market data to determine the current macroeconomic and technical regime:
    BULLISH, BEARISH, RANGING, or VOLATILE.
    """
    
    def __init__(self, volatility_threshold: float = 0.035, trend_strength_threshold: float = 0.02):
        self.volatility_threshold = volatility_threshold
        self.trend_strength_threshold = trend_strength_threshold
        logger.info("MarketRegimeEngine initialized with Enterprise parameters.")

    def analyze_regime(self, price_series: List[float], volume_series: List[float] = None) -> Dict[str, Any]:
        """
        Analyzes historical price and volume arrays to classify the market regime.
        Returns regime status, confidence score, and analytical metrics.
        """
        if not price_series or len(price_series) < 5:
            logger.warning("Insufficient price series data for regime detection. Defaulting to RANGING.")
            return {
                "regime": "RANGING",
                "confidence": 0.5,
                "volatility": 0.0,
                "trend_score": 0.0,
                "status": "INSUFFICIENT_DATA"
            }

        try:
            start_price = price_series[0]
            end_price = price_series[-1]
            price_change_pct = (end_price - start_price) / start_price

            # Calculate basic volatility (Standard deviation of returns simplified)
            returns = [(price_series[i] - price_series[i-1]) / price_series[i-1] for i in range(1, len(price_series))]
            mean_return = sum(returns) / len(returns) if returns else 0.0
            variance = sum((r - mean_return) ** 2 for r in returns) / len(returns) if returns else 0.0
            volatility = variance ** 0.5

            # Determine regime
            regime = "RANGING"
            confidence = 0.75

            if volatility > self.volatility_threshold:
                regime = "VOLATILE"
                confidence = min(0.95, 0.70 + (volatility / self.volatility_threshold) * 0.1)
            elif price_change_pct > self.trend_strength_threshold:
                regime = "BULLISH"
                confidence = min(0.95, 0.70 + abs(price_change_pct))
            elif price_change_pct < -self.trend_strength_threshold:
                regime = "BEARISH"
                confidence = min(0.95, 0.70 + abs(price_change_pct))
            else:
                regime = "RANGING"
                confidence = 0.80

            result = {
                "regime": regime,
                "confidence": round(confidence, 4),
                "volatility": round(volatility, 5),
                "trend_score": round(price_change_pct, 5),
                "status": "SUCCESS"
            }

            logger.debug(f"Regime analysis result: {result}")
            return result

        except Exception as e:
            logger.error(f"Error in MarketRegimeEngine analysis: {str(e)}", exc_info=True)
            return {
                "regime": "RANGING",
                "confidence": 0.0,
                "volatility": 0.0,
                "trend_score": 0.0,
                "status": f"ERROR: {str(e)}"
            }

# Global function wrapper for backward compatibility with existing imports
async def analyze_market_regime(price_series: List[float], volume_series: List[float] = None) -> Dict[str, Any]:
    engine = MarketRegimeEngine()
    return engine.analyze_regime(price_series, volume_series)
