"""
H.R.P AI TRADER 2026 - Output Table Engine
Formats and aggregates trading signals into structured JSON/Dict outputs.
"""

class OutputTableFormatter:
    def __init__(self):
        pass

    def build_signal_response(self, symbol, score_data, security_audit, whale_data):
        """
        Constructs the final military-grade intelligence payload for the client.
        """
        return {
            "symbol": symbol,
            "timestamp": score_data.get("timestamp"),
            "composite_score": score_data.get("score", 0),
            "security_status": security_audit.get("status", "UNKNOWN"),
            "whale_activity": whale_data.get("flow_status", "NEUTRAL"),
            "action_recommendation": "EXECUTE_LONG" if score_data.get("score", 0) > 75 else "HOLD",
            "system_version": "HRP-2026-Enterprise"
        }
