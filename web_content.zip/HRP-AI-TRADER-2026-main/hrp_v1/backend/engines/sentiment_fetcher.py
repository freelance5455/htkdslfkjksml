import logging
import asyncio
from typing import List, Dict, Any
from abc import ABC, abstractmethod

try:
    from textblob import TextBlob
except ImportError:
    TextBlob = None

class SentimentProvider(ABC):
    @abstractmethod
    async def fetch_raw_data(self, symbol: str) -> List[str]:
        pass

    @abstractmethod
    def analyze_text(self, text: str) -> float:
        pass

class NewsAPIProvider(SentimentProvider):
    """ارائه دهنده داده‌های خبری و احساسات بازار"""
    async def fetch_raw_data(self, symbol: str) -> List[str]:
        # در نسخه واقعی، این بخش به APIهای خبری متصل می‌شود
        return [
            f"{symbol} is showing massive bullish signals in global markets today!",
            f"Regulatory scrutiny and market concerns rising for {symbol}.",
            f"Institutional investors accumulation detected for {symbol}."
        ]

    def analyze_text(self, text: str) -> float:
        if TextBlob:
            return TextBlob(text).sentiment.polarity
        # فال‌بک ساده در صورت عدم حضور کتابخانه
        text_lower = text.lower()
        if "bullish" in text_lower or "accumulation" in text_lower:
            return 0.8
        if "bearish" in text_lower or "concern" in text_lower:
            return -0.8
        return 0.0

class SentimentEngine:
    """موتور تجمیع و محاسبه امتیاز احساسات سازمانی"""
    def __init__(self, providers: List[SentimentProvider]):
        self.logger = logging.getLogger(__name__)
        self.providers = providers

    async def get_unified_sentiment(self, symbol: str) -> float:
        total_score = 0.0
        count = 0
        for provider in self.providers:
            try:
                texts = await provider.fetch_raw_data(symbol)
                if not texts:
                    continue
                scores = [provider.analyze_text(t) for t in texts]
                if scores:
                    total_score += (sum(scores) / len(scores))
                    count += 1
            except Exception as e:
                self.logger.error(f"Sentiment provider execution failed for {symbol}: {e}")
                continue
        
        return round(total_score / count, 4) if count > 0 else 0.0
