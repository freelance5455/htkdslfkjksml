"""
H.R.P AI TRADER 2026 - NEWS FETCHER ENGINE
مسئولیت: دریافت اخبار زنده و تبدیل آن‌ها به داده‌های قابل تحلیل برای Intelligence Engine
"""

import requests
import datetime

class NewsFetcher:
    def __init__(self, api_key=None):
        self.api_key = api_key
        # استفاده از CryptoPanic به عنوان منبع اصلی اخبار کریپتو
        self.base_url = "https://cryptopanic.com/api/v1/posts/"
        
    def fetch_latest_news(self):
        """
        دریافت اخبار جدید. در صورت نبود API Key، از متد شبیه‌سازی (Mock) استفاده می‌کند.
        """
        if not self.api_key:
            return self._get_mock_news()

        params = {
            'auth': self.api_key,
            'kind': 'news'
        }
        
        try:
            response = requests.get(self.base_url, params=params, timeout=5)
            if response.status_code == 200:
                return response.json().get('results', [])
            else:
                return self._get_mock_news()
        except Exception as e:
            print(f"Error fetching news: {e}")
            return self._get_mock_news()

    def _get_mock_news(self):
        """
        داده‌های شبیه‌سازی شده برای تست سیستم در صورت نبود API Key
        """
        return [
            {
                "title": "Bitcoin breaks major resistance level after massive accumulation",
                "created_at": datetime.datetime.now().isoformat(),
                "domain": "Coindesk",
                "category": "news"
            },
            {
                "title": "Ethereum facing huge sell pressure as whales move funds to exchanges",
                "created_at": datetime.datetime.now().isoformat(),
                "domain": "CoinTelegraph",
                "category": "news"
            }
        ]
