"""
H.R.P AI TRADER 2026 - Advanced Discovery, Verification & Meme Hunter Engine (Enterprise Grade)
Author: Pakoyan / Hamidreza
Path: hrp_v1/backend/engines/discovery.py
"""

import logging
import asyncio
import time
from typing import List, Dict, Any, Optional
from datetime import datetime

# ایمپورت کردن موتورهای لایه زیرین (با مدیریت ایمن خطا)
try:
    from hrp_v1.backend.engines.sentiment_fetcher import SentimentEngine
except ImportError:
    SentimentEngine = None

try:
    from hrp_v1.backend.engines.regime import RegimeEngine
except ImportError:
    RegimeEngine = None

try:
    from hrp_v1.backend.core.security_audit import SecurityAuditEngine
except ImportError:
    class SecurityAuditEngine:
        @staticmethod
        def audit_contract(token_data: Dict[str, Any]) -> Dict[str, Any]:
            is_risky = token_data.get("is_honeypot", False) or token_data.get("has_hidden_mint", False)
            return {
                "safe": not is_risky,
                "score": 20 if is_risky else 95,
                "issues": ["Honeypot risk detected"] if is_risky else []
            }

logger = logging.getLogger("HRP.DiscoveryEngine")

class DiscoveryEngine:
    """موتور نهایی کشف فرصت‌های تجاری و فیلترینگ ضدجعلی و Honeypot (Enterprise Edition)"""
    
    def __init__(self, sentiment_engine: Any = None, regime_engine: Any = None, 
                 min_liquidity_usd: float = 50000.0, min_volume_24h: float = 100000.0, 
                 max_risk_score: float = 0.7):
        self.logger = logger
        self.sentiment_engine = sentiment_engine
        self.regime_engine = regime_engine
        self.min_liquidity = min_liquidity_usd
        self.min_volume_24h = min_volume_24h
        self.max_risk_score = max_risk_score
        self.min_discovery_score = 0.75
        self.logger.info("DiscoveryEngine initialized with Enterprise parameters.")

    def verify_token(self, token_data: Dict[str, Any]) -> Dict[str, Any]:
        """بررسی متریک‌های توکن جهت جلوگیری از هان‌پات (Honeypot)، حجم‌های جعلی (Wash Trading) و تله‌های نقدینگی."""
        symbol = token_data.get("symbol", "UNKNOWN")
        is_honeypot = token_data.get("is_honeypot", False)
        liquidity = token_data.get("liquidity", token_data.get("liquidity_usd", 0.0))
        volume_24h = token_data.get("volume_24h", 0.0)
        holder_count = token_data.get("holder_count", 0)
        is_verified_source = token_data.get("is_verified", True)

        risk_score = 0.0
        reasons = []

        if is_honeypot:
            risk_score = 1.0
            reasons.append(f"Token {symbol} flagged as HONEYPOT.")

        if liquidity < self.min_liquidity:
            risk_score += 0.4
            reasons.append(f"Low liquidity: ${liquidity} < ${self.min_liquidity}")

        if volume_24h > (liquidity * 10):  
            risk_score += 0.3
            reasons.append("Suspicious high volume-to-liquidity ratio (potential wash trading)")

        if holder_count > 0 and holder_count < 100:
            risk_score += 0.2
            reasons.append(f"Low holder concentration: {holder_count} holders")

        if not is_verified_source:
            risk_score += 0.5
            reasons.append("Unverified token contract / source")

        passed = risk_score <= self.max_risk_score and not is_honeypot

        result = {
            "symbol": symbol,
            "passed": passed,
            "risk_score": round(min(1.0, risk_score), 4),
            "reasons": reasons,
            "status": "VERIFIED" if passed else "REJECTED_HIGH_RISK"
        }

        self.logger.debug(f"Token verification for {symbol}: {result}")
        return result

    async def execute_intelligence_scan(self, market_data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """اسکن هوشمند، موازی و ایمن بازار با اعمال چک‌های ضدجعلی، Honeypot و تحلیل عمیق"""
        self.logger.info(f"🚀 Intelligence Scan Started at {datetime.now()}")
        
        filtered_assets = []
        for asset in market_data:
            check = self.verify_token(asset)
            if check["passed"]:
                asset["risk_score"] = check["risk_score"]
                asset["verification_reasons"] = check["reasons"]
                filtered_assets.append(asset)
            else:
                self.logger.warning(f"🚨 Asset {asset.get('symbol', 'UNKNOWN')} rejected by Discovery Engine: {check['reasons']}")

        tasks = [self._analyze_asset_deeply(asset) for asset in filtered_assets]
        results = await asyncio.gather(*tasks)
        
        opportunities = [r for r in results if r is not None and r.get('score', 0) >= self.min_discovery_score]
        opportunities.sort(key=lambda x: x['score'], reverse=True)
        
        self.logger.info(f"Discovery Scan Complete. {len(opportunities)} valid enterprise assets verified.")
        return opportunities

    async def _analyze_asset_deeply(self, asset: Dict[str, Any]) -> Dict[str, Any]:
        """تحلیل عمیق تک‌تک توکن‌ها با استفاده از موتور احساسات و رژیم بازار"""
        symbol = asset.get('symbol', 'UNKNOWN')
        try:
            sentiment_score = 0.5
            if self.sentiment_engine and hasattr(self.sentiment_engine, 'get_unified_sentiment'):
                sentiment_score = await self.sentiment_engine.get_unified_sentiment(symbol)
            
            regime_info = {"regime": "UNKNOWN", "confidence": 0.0}
            if self.regime_engine and 'price_history' in asset:
                if asyncio.iscoroutinefunction(self.regime_engine.classify_regime):
                    regime_info = await self.regime_engine.classify_regime(asset['price_history'], asset.get('volatility', 0.0))
                else:
                    regime_info = self.regime_engine.classify_regime(asset['price_history'], asset.get('volatility', 0.0))

            regime_str = str(regime_info.get('regime', '')).upper()
            regime_alignment = 1.0 if "BULLISH" in regime_str else (0.5 if "RANGING" in regime_str else 0.0)
            volatility_factor = min(asset.get('volatility', 0.05) / 0.1, 1.0)
            
            final_score = (sentiment_score * 0.4) + (regime_alignment * 0.3) + (volatility_factor * 0.3)

            asset["status"] = "VERIFIED"
            asset["score"] = round(final_score, 4)
            asset["sentiment"] = round(sentiment_score, 2)
            asset["regime"] = regime_info.get('regime', 'UNKNOWN')
            asset["timestamp"] = datetime.utcnow().isoformat()

            return asset
        except Exception as e:
            self.logger.error(f"Error in deep analysis for {symbol}: {e}")
            return None

    def scan_market(self, candidate_tokens: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """متد سنکرون سازگار برای تست‌ها"""
        verified_tokens = []
        for token in candidate_tokens:
            check = self.verify_token(token)
            if check["passed"]:
                verified_tokens.append(token)
        return verified_tokens


class MemeHunterDiscoveryEngine:
    """
    موتور تخصصی شکارچی مم‌کوین برای دریافت از منابع متعدد (DexScreener, Telegram Alpha)،
    حذف موارد تکراری، ممیزی امنیتی و امتیازدهی چندعاملی S-RANK.
    """

    def __init__(self, min_liquidity: float = 50000.0, min_volume: float = 20000.0):
        self.min_liquidity = min_liquidity
        self.min_volume = min_volume
        self.seen_tokens = set()

    def ingest_and_deduplicate(self, raw_candidates: List[Dict[str, Any]], source_name: str) -> List[Dict[str, Any]]:
        processed = []
        current_time = time.time()

        for token in raw_candidates:
            chain = token.get("chain", "ETH").upper()
            address = token.get("contract_address", "").lower()
            
            if not address:
                continue

            unique_key = f"{chain}:{address}"
            if unique_key in self.seen_tokens:
                continue

            token_timestamp = token.get("timestamp", current_time)
            if current_time - token_timestamp > 86400:
                continue

            token = dict(token)
            token["source"] = source_name
            token["ingested_at"] = current_time
            
            self.seen_tokens.add(unique_key)
            processed.append(token)

        return processed

    def evaluate_token(self, token: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        liquidity = float(token.get("liquidity_usd", token.get("liquidity", 0.0)))
        volume = float(token.get("volume_24h", 0.0))

        if liquidity < self.min_liquidity or volume < self.min_volume:
            return None

        audit_result = SecurityAuditEngine.audit_contract(token)
        if not audit_result.get("safe", False):
            return None

        vol_velocity = max(0.0, min(100.0, float(token.get("volume_velocity_score", 50.0))))
        social_sentiment = max(0.0, min(100.0, float(token.get("social_sentiment_score", 50.0))))
        whale_flows = max(0.0, min(100.0, float(token.get("whale_flow_score", 50.0))))
        security_score = max(0.0, min(100.0, float(audit_result.get("score", 90.0))))

        final_score = (
            (vol_velocity * 0.35) +
            (social_sentiment * 0.25) +
            (whale_flows * 0.25) +
            (security_score * 0.15)
        )

        token["security_audit"] = audit_result
        token["s_rank_score"] = round(final_score, 2)
        token["rank_tier"] = self._assign_tier(final_score)

        return token

    def _assign_tier(self, score: float) -> str:
        if score >= 90:
            return "S-RANK (Elite)"
        elif score >= 75:
            return "A-RANK (Strong)"
        elif score >= 60:
            return "B-RANK (Moderate)"
        return "WATCHLIST"

    def scan_meme_market(self, raw_sources: Dict[str, List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
        all_candidates = []
        for source_name, candidates in raw_sources.items():
            deduped = self.ingest_and_deduplicate(candidates, source_name)
            all_candidates.extend(deduped)

        scored_tokens = []
        for token in all_candidates:
            evaluated = self.evaluate_token(token)
            if evaluated:
                scored_tokens.append(evaluated)

        scored_tokens.sort(key=lambda x: x["s_rank_score"], reverse=True)
        return scored_tokens


# تابع گلوبال سازگار با نسخه‌های قبلی (Backward Compatibility Wrapper)
async def discover_and_verify_tokens(candidate_tokens: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    engine = DiscoveryEngine()
    return await engine.execute_intelligence_scan(candidate_tokens)
