"""
H.R.P AI TRADER 2026 - INTELLIGENCE ENGINE (v1.0)
مسئولیت: تحلیل متنی اخبار، تشخیص رژیم بازار و امتیازدهی نهایی (Intelligence Score)
"""

import datetime
import math

class IntelligenceEngine:
    def __init__(self):
        self.version = "1.0.0-Moon"
        self.knowledge_keywords_map = {
            "bullish_keywords": ["surge", "breakout", "accumulation", "adoption", "bullish", "rally", "support"],
            "bearish_keywords": ["dump", "crash", "distribution", "rejection", "bearish", "resistance", "fud"]
        }

    def analyze_sentiment(self, text: str) -> float:
        """
        تحلیل متن (NLP Simplified) برای استخراج امتیاز احساسات
        خروجی: بین -1.0 (بسیار منفی) تا 1.0 (بسیار مثبت)
        """
        text = text.lower()
        score = 0.0
        words = text.split()
        
        for word in words:
            if word in self.knowledge_keywords("bullish_keywords"):
                score += 0.1
            elif word in self.knowledge_keywords("bearish_keywords"):
                score -= 0.1
        
        return max(min(score, 1.0), -1.0)

    def detect_market_regime(self, volatility: float, volume_change: float) -> str:
        """
        تشخیص وضعیت بازار بر اساس نوسان و تغییر حجم
        """
        if volatility > 0.05 and volume_change > 0.5:
            return "HIGH_VOLATILITY_TRENDING"
        elif volatility < 0.02:
            return "SIDEWAYS_RANGING"
        elif volume_change > 0.2:
            return "ACCUMULATION_PHASE"
        else:
            return "STABLE_MARKET"

    def generate_intelligence_score(self, sentiment: float, regime: str, whale_activity: float) -> dict:
        """
        ترکیب تمام عوامل برای تولید یک امتیاز نهایی (Intelligence Score)
        """
        base_score = (sentiment * 0.4) + (whale_activity * 0.3)
        
        if regime == "HIGH_VOLATILITY_TRENDING":
            base_score *= 1.2
        elif regime == "SIDEWAYS_RANGING":
            base_score *= 0.5

        final_score = max(min(base_score * 100, 100), 0)
        
        return {
            "score": round(final_score, 2),
            "signal": "STRONG_BUY" if final_score > 70 else "HOLD" if final_score > 40 else "STRONG_SELL",
            "confidence": "HIGH" if final_score > 80 or final_score < 20 else "MEDIUM"
        }

    def knowledge_keywords(self, key):
        return self.knowledge_keywords_map.get(key, [])

# تست سریع ماژول
if __name__ == "__main__":
    engine = IntelligenceEngine()
    print(f"Testing Engine {engine.version}...")
    s = engine.analyze_sentiment("Bitcoin sees massive accumulation and breakout surge!")
    print(f"Sentiment Score: {s}")
    r = engine.detect_market_regime(0.06, 0.6)
    print(f"Regime: {r}")
    final = engine.generate_intelligence_score(s, r, 0.8)
    print(f"Final Intelligence Result: {final}")
