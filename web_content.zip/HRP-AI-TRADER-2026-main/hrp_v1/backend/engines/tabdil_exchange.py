"""Tabdil Exchange REST connector. Configure TABDIL_BASE_URL and optional TABDIL_API_KEY."""
import os
import json
import urllib.request
import urllib.parse

class TabdilExchangeClient:
    def __init__(self, base_url=None, api_key=None, timeout=10):
        self.base_url=(base_url or os.getenv("TABDIL_BASE_URL", "https://api.tabdeal.org")).rstrip("/")
        self.api_key=api_key or os.getenv("TABDIL_API_KEY")
        self.timeout=timeout
    def _get(self, path, params=None):
        url=self.base_url+path
        if params: url += "?"+urllib.parse.urlencode(params)
        headers={"Accept":"application/json", "User-Agent":"HRP-AI-TRADER/2026"}
        if self.api_key: headers["Authorization"]="Bearer "+self.api_key
        req=urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=self.timeout) as r: return json.loads(r.read().decode("utf-8"))
    def ticker(self, symbol):
        """Fetch a ticker; endpoint path can be adapted via the API gateway deployment."""
        return self._get("/api/v1/market/ticker/"+urllib.parse.quote(symbol, safe=""))
    def order_book(self, symbol, limit=20):
        return self._get("/api/v1/market/orderbook/"+urllib.parse.quote(symbol, safe=""), {"limit":int(limit)})
    def balances(self):
        if not self.api_key: raise RuntimeError("TABDIL_API_KEY is required for private balances")
        return self._get("/api/v1/account/balances")
