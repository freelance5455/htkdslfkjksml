"""Explicit-rate currency conversion utilities for Tabdil markets.

Rates are supplied by the caller; each rate expresses units of that currency
per one unit of the configured base currency. This module intentionally does
not fetch or invent market rates.
"""
from __future__ import annotations

import math
from collections.abc import Mapping


class ExchangeRateError(ValueError):
    """Raised when a currency rate is unavailable or invalid."""


class TabdilExchange:
    """Convert currencies using caller-provided rates relative to a base.

    Args:
        rates: Mapping of currency code to units per one base-currency unit.
            The base currency is implicitly assigned a rate of 1.
        base_currency: Currency code defining the rate basis (default ``USDT``).
    """

    def __init__(self, rates: Mapping[str, float] | None = None,
                 base_currency: str = "USDT") -> None:
        self.base_currency = self._currency(base_currency)
        self._rates: dict[str, float] = {self.base_currency: 1.0}
        for currency, rate in (rates or {}).items():
            code = self._currency(currency)
            value = float(rate)
            if not math.isfinite(value) or value <= 0:
                raise ExchangeRateError(f"Rate for {code} must be finite and positive")
            self._rates[code] = value

    @staticmethod
    def _currency(code: str) -> str:
        if not isinstance(code, str) or not code.strip():
            raise ValueError("Currency code must be a non-empty string")
        return code.strip().upper()

    def convert(self, amount: float, from_currency: str,
                to_currency: str) -> float:
        """Convert a non-negative amount using configured rates."""
        value = float(amount)
        if not math.isfinite(value) or value < 0:
            raise ValueError("Amount must be finite and non-negative")
        source, target = self._currency(from_currency), self._currency(to_currency)
        if source not in self._rates or target not in self._rates:
            missing = source if source not in self._rates else target
            raise ExchangeRateError(f"No configured rate for {missing}")
        return value * self._rates[target] / self._rates[source]

    def quote(self, amount: float, from_currency: str,
              to_currency: str) -> dict[str, object]:
        """Return a small auditable quote with the applied conversion rate."""
        source, target = self._currency(from_currency), self._currency(to_currency)
        converted = self.convert(amount, source, target)
        return {
            "amount": float(amount),
            "from_currency": source,
            "to_currency": target,
            "rate": self._rates[target] / self._rates[source],
            "converted_amount": converted,
            "base_currency": self.base_currency,
        }
