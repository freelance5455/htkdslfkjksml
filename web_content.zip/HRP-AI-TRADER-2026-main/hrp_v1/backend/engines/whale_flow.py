"""
H.R.P AI TRADER 2026 - Whale Flow Engine (Enterprise Grade)
Responsible for tracking large-scale wallet movements, exchange inflows/outflows,
and calculating whale accumulation/distribution pressure scores.
Author: Pakoyan / Hamidreza
Path: hrp_v1/backend/engines/whale_flow.py
"""

import logging
import asyncio
from typing import List, Dict, Any
from datetime import datetime

logger = logging.getLogger("HRP_WHALE_FLOW")

class WhaleFlowEngine:
    """موتور پیشرفته ردیابی جریان نهنگ‌ها و تحلیل نقدینگی کلان (Enterprise Version)"""
    
    def __init__(self, min_whale_usd: float = 50000.0):
        self.logger = logger
        self.min_whale_usd = min_whale_usd
        self.logger.info("WhaleFlowEngine initialized with Enterprise parameters.")

    async def analyze_whale_transactions(self, transactions: List[Dict[str, Any]]) -> Dict[str, Any]:
        """تحلیل موازی تراکنش‌های کلان و تعیین جهت فشار بازار (Inflow vs Outflow)"""
        self.logger.info(f"🐋 Whale Flow Analysis Started at {datetime.now()}")

        if not transactions:
            return {
                "timestamp": datetime.utcnow().isoformat(),
                "total_whale_transactions": 0,
                "total_inflow_usd": 0.0,
                "total_outflow_usd": 0.0,
                "net_flow_usd": 0.0,
                "pressure_score": 0.0,
                "whale_sentiment": "NEUTRAL_FLOW",
                "alerts": [],
                "status": "NO_DATA"
            }

        total_inflow = 0.0   # واریز به صرافی (احتمال فشار فروش)
        total_outflow = 0.0  # برداشت از صرافی (احتمال انباشت و نگهداری)
        whale_alerts = []

        try:
            for tx in transactions:
                amount_usd = tx.get("amount_usd", 0.0)
                if amount_usd < self.min_whale_usd:
                    continue

                symbol = tx.get("symbol", "UNKNOWN")
                tx_type = tx.get("type", "TRANSFER").upper() # INFLOW, OUTFLOW, TRANSFER
                sender = tx.get("sender", "UNKNOWN")
                receiver = tx.get("receiver", "UNKNOWN")

                # ثبت هشدار نهنگ
                alert = {
                    "symbol": symbol,
                    "amount_usd": amount_usd,
                    "type": tx_type,
                    "sender": sender,
                    "receiver": receiver,
                    "timestamp": datetime.utcnow().isoformat()
                }
                whale_alerts.append(alert)

                if "INFLOW" in tx_type or "EXCHANGE" in str(receiver).upper():
                    total_inflow += amount_usd
                    self.logger.warning(f"🚨 Whale INFLOW Detected: ${amount_usd:,.2f} of {symbol} moved to exchange!")
                elif "OUTFLOW" in tx_type or "WITHDRAW" in tx_type or "EXCHANGE" in str(sender).upper():
                    total_outflow += amount_usd
                    self.logger.info(f"🟢 Whale OUTFLOW (Accumulation) Detected: ${amount_usd:,.2f} of {symbol} withdrawn!")

            # محاسبه شاخص فشار نهنگ (-1.0 کاملاً خرسی/فشار فروش تا +1.0 کاملاً صعودی/انباشت)
            net_flow = total_outflow - total_inflow
            total_volume = total_inflow + total_outflow
            
            pressure_score = 0.0
            if total_volume > 0:
                pressure_score = net_flow / total_volume

            # دسته‌بندی وضعیت جریان نهنگ‌ها
            if pressure_score > 0.3 or net_flow > 1000000.0:
                market_sentiment = "STRONG_ACCUMULATION"
            elif pressure_score < -0.3 or net_flow < -1000000.0:
                market_sentiment = "HEAVY_DISTRIBUTION"
            else:
                market_sentiment = "NEUTRAL_FLOW"

            analysis_result = {
                "timestamp": datetime.utcnow().isoformat(),
                "total_whale_transactions": len(whale_alerts),
                "total_inflow_usd": round(total_inflow, 2),
                "total_outflow_usd": round(total_outflow, 2),
                "net_flow_usd": round(net_flow, 2),
                "pressure_score": round(pressure_score, 4),
                "whale_sentiment": market_sentiment,
                "alerts": whale_alerts[:20], # بازگرداندن ۲۰ هشدار برتر جهت کاهش حجم داده
                "status": "SUCCESS"
            }

            self.logger.info(f"Whale Flow Analysis Complete. Sentiment: {market_sentiment} | Pressure Score: {pressure_score:.2f}")
            return analysis_result

        except Exception as e:
            self.logger.error(f"Error in WhaleFlowEngine analysis: {str(e)}", exc_info=True)
            return {
                "timestamp": datetime.utcnow().isoformat(),
                "total_whale_transactions": 0,
                "total_inflow_usd": 0.0,
                "total_outflow_usd": 0.0,
                "net_flow_usd": 0.0,
                "pressure_score": 0.0,
                "whale_sentiment": "ERROR",
                "alerts": [],
                "status": f"ERROR: {str(e)}"
            }

    async def get_asset_whale_score(self, symbol: str, recent_txs: List[Dict[str, Any]]) -> float:
        """محاسبه امتیاز تخصصی جریان نهنگ برای یک دارایی خاص جهت استفاده در موتور امتیازدهی کلی"""
        filtered = [tx for tx in recent_txs if tx.get("symbol", "").upper() == symbol.upper()]
        result = await self.analyze_whale_transactions(filtered)
        # نرمال‌سازی امتیاز فشار به بازه 0 تا 1 برای انطباق با مدل Scoring Engine
        raw_score = result.get("pressure_score", 0.0)
        normalized_score = (raw_score + 1.0) / 2.0
        return round(normalized_score, 4)

# تابع گلوبال سازگار با نسخه‌های قبلی (Backward Compatibility Wrapper)
async def analyze_whale_flows(transactions: List[Dict[str, Any]]) -> Dict[str, Any]:
    engine = WhaleFlowEngine()
    return await engine.analyze_whale_transactions(transactions)
