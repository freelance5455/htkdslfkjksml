def audit_token_security(token_data: dict) -> dict:
    """
    بررسی امنیتی ضد Rugpull و Honeypot برای رمزارزها
    """
    is_honeypot = token_data.get("is_honeypot", False)
    buy_tax = token_data.get("buy_tax", 0)
    sell_tax = token_data.get("sell_tax", 0)
    has_mint_function = token_data.get("has_mint_function", False)
    
    risk_score = 0
    if is_honeypot:
        risk_score += 100
    if buy_tax > 5 or sell_tax > 5:
        risk_score += 40
    if has_mint_function:
        risk_score += 30
        
    status = "SAFE" if risk_score < 50 else "HIGH_RISK"
    
    return {
        "risk_score": risk_score,
        "status": status,
        "details": {
            "is_honeypot": is_honeypot,
            "buy_tax": buy_tax,
            "sell_tax": sell_tax,
            "has_mint_function": has_mint_function
        }
    }
