def analyze_multi_timeframe(tf_15m: dict, tf_1h: dict, tf_4h: dict) -> str:
    """
    تحلیل چندتایم‌فریم (15M, 1H, 4H) برای تأیید روند معامله
    """
    trend_15m = tf_15m.get("trend", "NEUTRAL")
    trend_1h = tf_1h.get("trend", "NEUTRAL")
    trend_4h = tf_4h.get("trend", "NEUTRAL")
    
    if trend_4h == "BULLISH" and trend_1h == "BULLISH" and trend_15m == "BULLISH":
        return "STRONG_BUY_CONFLUENCE"
    elif trend_4h == "BEARISH" and trend_1h == "BEARISH":
        return "STRONG_SELL_CONFLUENCE"
    else:
        return "WAIT_FOR_CLEAR_SETUP"
