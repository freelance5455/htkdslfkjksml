"""
H.R.P AI TRADER 2026 - ENTERPRISE RISK MANAGEMENT ENGINE (PRO EDITION)
Core Module: risk_manager.py
Author: Hamidreza Pakoyan
Version: 2.1.0 (Moon Edition - Fully Integrated Gatekeeper)
"""

from enum import Enum
from typing import Dict, Any, Optional
import logging

logger = logging.getLogger("HRP.RiskManager")

class MarketRegime(Enum):
    TREND = "TREND"
    RANGE = "RANGE"
    VOLATILE = "VOLATILE"

class SystemState(Enum):
    NORMAL = "NORMAL"
    HIGH_VOLATILITY = "HIGH_VOLATILITY"
    EMERGENCY_LOCKDOWN = "EMERGENCY_LOCKDOWN"

class RiskValidationError(Exception):
    """Custom exception for enterprise-grade risk violations."""
    pass

class RiskManager:
    def __init__(self, is_live: bool = False):
        # تنظیمات سخت‌گیرانه نظامی (Military-Grade Config)
        self.config = {
            "max_risk_per_trade": 0.02,      # حداکثر ۲٪ ریسک در هر معامله
            "max_daily_loss": 0.05,         # حداکثر ۵٪ ضرر روزانه (Circuit Breaker)
            "min_rr_ratio": 1.5,             # حداقل نسبت ریسک به پاداش ۱.۵
            "leverage_limit": 10,            # محدودیت اهرم در حالت Live
            "is_live": is_live
        }
        
        # وضعیت حساب (Account State)
        self.account = {
            "total_equity": 148520.40,       # Equity پایه پروژه
            "available_margin": 120000.00,
            "daily_profit_loss": 0.0         # ضرر/سود روزانه برای مدیریت Drawdown
        }
        
        self.current_state = SystemState.NORMAL
        logger.info("[INIT] RiskManager (The Gatekeeper) initialized successfully.")

    def calculate_position_size(self, entry_price: float, stop_loss_price: float, take_profit_price: float = None) -> Dict[str, Any]:
        """
        محاسبه حجم بهینه بر اساس مدیریت سرمایه (Position Sizing)
        """
        try:
            risk_amount = self.account["total_equity"] * self.config["max_risk_per_trade"]
            price_diff = abs(entry_price - stop_loss_price)

            if price_diff <= 0:
                raise ValueError("Stop loss price must be different from entry price.")

            recommended_size = risk_amount / price_diff
            
            rr_status = "N/A"
            if take_profit_price:
                reward = abs(take_profit_price - entry_price)
                rr_ratio = reward / price_diff
                rr_status = round(rr_ratio, 2)

            return {
                "status": "SUCCESS",
                "recommended_size": round(recommended_size, 6),
                "risk_in_usd": round(risk_amount, 2),
                "rr_ratio": rr_status,
                "percentage_of_equity": f"{self.config['max_risk_per_trade'] * 100}%"
            }
        except Exception as e:
            return {"status": "ERROR", "message": str(e)}

    def validate_trade(self, proposed_trade: dict) -> Dict[str, Any]:
        """
        Pre-Trade Audit: بررسی تمامی لایه‌های امنیتی قبل از ارسال سفارش به Exchange
        """
        try:
            entry = proposed_trade.get("entry")
            stop_loss = proposed_trade.get("stop_loss")
            take_profit = proposed_trade.get("take_profit", None)
            leverage = proposed_trade.get("leverage", 1)

            # ۱. لایه حفاظت از Drawdown (Daily Circuit Breaker)
            if self.account["daily_profit_loss"] <= -(self.account["total_equity"] * self.config["max_daily_loss"]):
                return {"allowed": False, "reason": "❌ Daily Loss Limit Reached. Circuit Breaker Active."}

            # ۲. لایه فیلتر سودآوری (R:R Ratio Filter)
            if take_profit:
                rr_ratio = abs(take_profit - entry) / abs(entry - stop_loss)
                if rr_ratio < self.config["min_rr_ratio"]:
                    return {"allowed": False, "reason": f"❌ Low R:R Ratio ({round(rr_ratio, 2)}). Min required: {self.config['min_rr_ratio']}"}

            # ۳. لایه کنترل اهرم (Leverage Control)
            if self.config["is_live"] and leverage > self.config["leverage_limit"]:
                return {"allowed": False, "reason": f"⚠️ Leverage exceeds limit ({self.config['leverage_limit']}x) in LIVE mode."}

            # ۴. لایه جلوگیری از Stop-loss بسیار نزدیک (Noise Protection)
            if abs(entry - stop_loss) / entry < 0.005:
                return {"allowed": False, "reason": "❌ Stop-loss too tight (Risk of market noise)."}

            return {"allowed": True, "reason": "✅ Trade passed all risk audits."}

        except Exception as e:
            return {"allowed": False, "reason": f"❌ Risk Engine Error: {str(e)}"}

    def evaluate_trade_permission(self, symbol: str, signal_score: float, antifab_report: Dict[str, Any], regime: MarketRegime) -> Dict[str, Any]:
        """
        متد اصلی هماهنگ‌کننده با main.py جهت ارزیابی نهایی مجوز معامله بر اساس رژیم بازار و آنتی‌جعل
        """
        try:
            # بررسی وضعیت اضطراری
            if self.current_state == SystemState.EMERGENCY_LOCKDOWN:
                return {"approved": False, "reason": "System is in EMERGENCY LOCKDOWN."}

            # بررسی گزارش ضدجعل
            if not antifab_report.get("is_authentic", True):
                self.current_state = SystemState.EMERGENCY_LOCKDOWN
                return {"approved": False, "reason": "Anti-Fabrication Firewall Triggered: Data tampering detected."}

            # بررسی حداقل امتیاز سیگنال
            if signal_score < 75.0:
                return {"approved": False, "reason": f"Signal score {signal_score} below enterprise threshold (75.0)."}

            # تنظیم ضریب پوزیشن بر اساس رژیم بازار
            position_multiplier = 1.0
            if regime == MarketRegime.VOLATILE:
                self.current_state = SystemState.HIGH_VOLATILITY
                position_multiplier = 0.5  # کاهش حجم در بازار پرنوسان
            else:
                self.current_state = SystemState.NORMAL

            # محاسبه حجم نهایی ریسک
            risk_amount = self.account["total_equity"] * self.config["max_risk_per_trade"]
            final_position_size = risk_amount * position_multiplier

            return {
                "approved": True,
                "reason": "Passed all multi-layered risk and regime gates.",
                "position_size": round(final_position_size, 4),
                "system_state": self.current_state.value
            }
        except Exception as e:
            return {"approved": False, "reason": f"Evaluation Error: {str(e)}"}

    def update_account_data(self, new_equity: float, new_daily_pl: float) -> None:
        """
        آپدیت وضعیت حساب پس از بسته شدن پوزیشن‌ها
        """
        self.account["total_equity"] = new_equity
        self.account["daily_profit_loss"] = new_daily_pl
        logger.info(f"[ACCOUNT UPDATE] Equity: {new_equity} | Daily P/L: {new_daily_pl}")
