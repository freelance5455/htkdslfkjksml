import os

class Settings:
    PROJECT_NAME: str = "H.R.P AI TRADER 2026"
    VERSION: str = "1.0.0"
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///./hrp_trader.db")
    SECRET_KEY: str = os.getenv("SECRET_KEY", "hrp-pakoyan-secure-secret-key-2026")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 1440

settings = Settings()
