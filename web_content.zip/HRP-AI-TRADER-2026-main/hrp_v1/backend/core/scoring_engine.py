def calculate_trade_score(technical_score: float, whale_score: float, security_score: float) -> float:
    """
    محاسبه امتیاز نهایی معامله بر اساس فاکتورهای تکنیکال، نهنگ و امنیت
    """
    weights = {
        "technical": 0.4,
        "whale": 0.4,
        "security": 0.2
    }
    
    final_score = (
        (technical_score * weights["technical"]) +
        (whale_score * weights["whale"]) +
        (security_score * weights["security"])
    )
    return round(final_score, 2)
