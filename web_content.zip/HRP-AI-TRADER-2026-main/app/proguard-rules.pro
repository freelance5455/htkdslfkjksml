# Add project specific ProGuard rules here.
# You can control the set of kept classes in your applications by using the `-keep` attributes.

-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn androidx.**

# Keep all core classes in HRP Trader package
-keep class com.hrp.aitrader.** { *; }

# Keep JavaScript Interface methods from being stripped or renamed
-keepclassmembers class com.hrp.aitrader.HrpBridge {
    @android.webkit.JavascriptInterface <methods>;
}

# حفظ سازگاری کامل WorkManager و کتابخانه‌های اندروید در حالت minify
-keep class androidx.work.** { *; }
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
