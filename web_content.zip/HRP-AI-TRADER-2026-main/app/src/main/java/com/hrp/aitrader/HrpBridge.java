package com.hrp.aitrader;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;
import org.json.JSONException;
import org.json.JSONObject;

/** 
 * H.R.P AI TRADER 2026 - Master Integrated Bridge (ULTIMATE SECURE ENTERPRISE VERSION - MOON EDITION)
 * Author: Pakoyan / Hamidreza
 * Path: HRP_Android_Client_Package/app/src/main/java/com/hrp/aitrader/HrpBridge.java
 */
public class HrpBridge {
    private static final String TAG = "HRPBridge";
    private static final String PREFS = "hrp_preferences";
    private static final String MODE = "hrp_mode";
    
    private final MainActivity activity;
    private final WebView webView;
    private final SharedPreferences prefs;
    private final Handler mainHandler;
    private final Context fallbackContext;

    // سازنده اصلی سازگار با نسخه جامع مخزن
    public HrpBridge(MainActivity context, WebView view) {
        this.activity = context;
        this.webView = view;
        this.fallbackContext = context;
        this.prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        this.mainHandler = new Handler(Looper.getMainLooper());
        Log.i(TAG, "Master Secure HrpBridge initialized successfully (Moon Edition).");
    }

    // سازنده پشتیبان جهت سازگاری با نمونه‌های ساده‌تر Context
    public HrpBridge(Context context) {
        this.activity = null;
        this.webView = null;
        this.fallbackContext = context;
        this.prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        this.mainHandler = new Handler(Looper.getMainLooper());
        Log.i(TAG, "Master Secure HrpBridge initialized with fallback context.");
    }

    // --- [ بخش ۱: لایه امنیتی و لاگینگ ایزوله ] ---

    @JavascriptInterface
    public void secureLog(String message) {
        // Encrypted / Filtered logging for production safety
        if (message != null && !message.isEmpty()) {
            Log.d(TAG, "[SECURE_BRIDGE] " + message);
        }
    }

    @JavascriptInterface
    public String getAppVersion() {
        return "2026.Moon.Enterprise";
    }

    // --- [ بخش ۲: تزریق داده‌های هوش مصنوعی و مدیریت حالت‌ها ] ---

    @JavascriptInterface
    public synchronized void injectIntelligenceData(String jsonPayload) {
        Log.d(TAG, "AI Engine Payload Received: " + jsonPayload);
        try {
            new JSONObject(jsonPayload); 
            mainHandler.post(() -> {
                if (webView != null) {
                    String safeJson = jsonPayload.replace("'", "\\'");
                    String js = "try { " +
                                "  if(window.updateDashboard) { window.updateDashboard(" + jsonPayload + "); } " +
                                "  if(window.updateDashboardUI) { window.updateDashboardUI('" + safeJson + "'); } " +
                                "} catch(e) { console.error('HRP Dashboard Update Error: ' + e.message); }";
                    webView.evaluateJavascript(js, null);
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "AI Injection Failed (Invalid JSON/UI Error): " + e.getMessage());
        }
    }

    @JavascriptInterface
    public String hrp_getMode() {
        return prefs.getString(MODE, "sandbox");
    }

    @JavascriptInterface
    public synchronized void hrp_setMode(String mode) {
        if (mode != null && !mode.trim().isEmpty()) {
            prefs.edit().putString(MODE, mode.trim()).apply();
            Log.d(TAG, "Mode changed to: " + mode);
        }
    }

    @JavascriptInterface
    public void hrp_toast(String message) {
        Context ctx = (activity != null) ? activity : fallbackContext;
        mainHandler.post(() -> Toast.makeText(ctx, message == null ? "" : message, Toast.LENGTH_SHORT).show());
    }

    @JavascriptInterface
    public void showToast(String message) {
        hrp_toast(message);
    }

    @JavascriptInterface
    public void showNativeToast(String message) {
        hrp_toast(message);
    }

    @JavascriptInterface
    public void logToNative(String tag, String message) {
        Log.d("HRP_WEB_" + (tag != null ? tag : "GENERAL"), message != null ? message : "");
    }

    @JavascriptInterface
    public synchronized void logTradeAction(final String payloadJson) {
        try {
            JSONObject obj = new JSONObject(payloadJson);
            String symbol = obj.optString("symbol", "UNKNOWN");
            double amount = obj.optDouble("amount", 0.0);
            
            mainHandler.post(() -> {
                Context ctx = (activity != null) ? activity : fallbackContext;
                Toast.makeText(ctx, "سفارش ثبت شد: " + symbol + " ($" + amount + ")", Toast.LENGTH_LONG).show();
            });
        } catch (Exception e) {
            Log.e(TAG, "logTradeAction parsing error: " + e.getMessage());
        }
    }

    @JavascriptInterface
    public synchronized void hrp_nav(String destination) {
        if (destination == null || webView == null) return;
        try {
            String js = "if(typeof window.hrpNavigate==='function')window.hrpNavigate(" + JSONObject.quote(destination) + ");";
            mainHandler.post(() -> webView.evaluateJavascript(js, null));
        } catch (Exception e) {
            Log.e(TAG, "Navigation Error: " + e.getMessage());
        }
    }

    @JavascriptInterface
    public void triggerHaptic(long[] pattern) {
        if (activity == null) return;
        try {
            Vibrator v = (Vibrator) activity.getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null && v.hasVibrator()) {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    v.vibrate(VibrationEffect.createWaveform(pattern, -1));
                } else {
                    v.vibrate(pattern, -1);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Haptic error: " + e.getMessage());
        }
    }

    // --- [ بخش ۳: متدهای پیشرفته معاملاتی و امنیتی ] ---

    @JavascriptInterface
    public synchronized void executeLiveTradeAPI(String payload) {
        mainHandler.post(() -> {
            Log.d(TAG, "Executing Live Trade Payload: " + payload);
            hrp_toast("دستور معامله لایو صادر شد (سرعت < 2s)");
        });
    }

    @JavascriptInterface
    public synchronized void executeTrade(String jsonPayload) {
        Log.i(TAG, "executeTrade received payload: " + jsonPayload);
        try {
            JSONObject tradeData = new JSONObject(jsonPayload);
            String symbol = tradeData.optString("symbol", "UNKNOWN");
            String type = tradeData.optString("type", "BUY");
            double amount = tradeData.optDouble("amount", 0.0);

            Log.w(TAG, "Executing Trade -> Symbol: " + symbol + " | Type: " + type + " | Amount: " + amount);
            hrp_toast("دستور سفارش " + type + " برای " + symbol + " ثبت شد.");

            mainHandler.post(() -> {
                if (webView != null) {
                    webView.evaluateJavascript("window.onTradeResponse && window.onTradeResponse({status:'success', symbol:'" + symbol + "'});", null);
                }
            });
        } catch (JSONException e) {
            Log.e(TAG, "Invalid trade payload JSON", e);
        }
    }

    @JavascriptInterface
    public void executeTrade(String symbol, String action, double amount) {
        Log.i(TAG, "Trade requested (Legacy overload): " + action + " " + amount + " of " + symbol);
        hrp_toast("دستور " + action + " برای " + symbol + " ثبت شد.");
    }

    @JavascriptInterface
    public String getSystemStatus() {
        try {
            JSONObject status = new JSONObject();
            status.put("status", "ONLINE");
            status.put("edition", "Moon Edition 2026");
            status.put("security", "SECURE_OBFUSCATED");
            status.put("mode", prefs.getString(MODE, "sandbox"));
            return status.toString();
        } catch (Exception e) {
            return "{\"status\": \"ONLINE\", \"edition\": \"Moon Edition 2026\", \"security\": \"SECURE\"}";
        }
    }

    @JavascriptInterface
    public synchronized void emergencyLockdown() {
        Log.e(TAG, "🚨 EMERGENCY LOCKDOWN TRIGGERED FROM UI!");
        Context ctx = (activity != null) ? activity : fallbackContext;
        mainHandler.post(() -> {
            Toast.makeText(ctx, "⚠️ قفل اضطراری سیستم فعال شد!", Toast.LENGTH_LONG).show();
            if (webView != null) {
                webView.evaluateJavascript("window.onEmergencyActive && window.onEmergencyActive();", null);
            }
        });
    }

    @JavascriptInterface
    public void postMessage(String channel, String payload) {
        Log.d(TAG, "PostMessage -> Channel: " + channel + " | Payload: " + payload);
        mainHandler.post(() -> {
            if (webView != null) {
                String jsCall = String.format("window.HRP_EVENT_BUS && window.HRP_EVENT_BUS('%s', '%s');", channel, payload);
                webView.evaluateJavascript(jsCall, null);
            }
        });
    }

    @JavascriptInterface
    public void hrp_log(String message) {
        Log.d(TAG, message == null ? "" : message);
    }
    
    @JavascriptInterface
    public String hrp_scan() {
        return "{}";
    }
}
