package com.hrp.aitrader;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.*;
import androidx.appcompat.app.AppCompatActivity;

/** 
 * H.R.P AI TRADER 2026 - Master MainActivity (Enterprise Secure Moon Edition)
 * Author: Pakoyan / Hamidreza
 * Path: HRP_Android_Client_Package/app/src/main/java/com/hrp/aitrader/MainActivity.java
 * Status: Merged & Dual-Bridge Active (HrpBridge & HRPAndroid)
 */
public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private boolean backHandledByPage = false;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        webView = findViewById(R.id.webView);
        WebSettings webSettings = webView.getSettings();
        
        // تنظیمات حیاتی وب‌ویو برای عملکرد بی‌نقص تریدینگ
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowContentAccess(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        
        // --- [ CRITICAL SECURITY: DISABLE WEBVIEW DEBUGGING IN RELEASE ] ---
        // جلوگیری از دسترسی ابزارهای مانیتورینگ و دیباگینگ در نسخه نهایی (Release)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.KITKAT) {
            WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);
        }
        
        webView.setBackgroundColor(android.graphics.Color.TRANSPARENT);
        
        // --- [ CRITICAL: DUAL HRP BRIDGE INJECTION ] ---
        // تزریق پل ارتباطی با هر دو نام استاندارد برای سازگاری کامل با کدهای جدید و قدیم فرانت‌اند
        HrpBridge bridgeInstance = new HrpBridge(this, webView);
        webView.addJavascriptInterface(bridgeInstance, "HRPAndroid");
        webView.addJavascriptInterface(bridgeInstance, "HrpBridge");

        // پیوندهای وب بیرونی در مرورگر سیستم باز می‌شوند و لینک‌های داخلی در وب‌ویو
        final HrpBridge marketBridge = bridgeInstance;
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                marketBridge.startMarketPolling();
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String sc = u.getScheme();
                if (sc != null && (sc.equalsIgnoreCase("http") || sc.equalsIgnoreCase("https"))) {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                    return true;
                }
                return false;
            }
        });
        
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onDestroy() {
        if (webView != null) webView.stopLoading();
        super.onDestroy();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (webView == null) {
            super.onBackPressed();
            return;
        }
        backHandledByPage = false;
        webView.evaluateJavascript("(function(){return typeof window.hrpHandleBack==='function' && window.hrpHandleBack()===true})()", v -> backHandledByPage = "true".equals(v));
        webView.postDelayed(() -> {
            if (!backHandledByPage) MainActivity.super.onBackPressed();
        }, 120);
    }
}
