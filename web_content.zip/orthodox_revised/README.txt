የመናፍቃን ጥያቄዎች እና መልሶቻቸው

Updated offline HTML app prototype.
- Topic-specific vector illustrations are embedded in the file, so they work offline.
- The requested John 5:39 verse replaces the old tagline.
- Original lesson titles and body content were not edited.

Open index.html in a modern browser. This is HTML, not a compiled Android APK.
