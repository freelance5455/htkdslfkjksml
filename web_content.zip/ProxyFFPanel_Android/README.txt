PROXY FF PANEL - PROJETO ANDROID

Este projeto empacota a interface HTML em um aplicativo Android usando WebView.
O botão COMEÇAR PROXY tenta abrir o Free Fire instalado (versão normal ou MAX).
Se nenhum deles estiver instalado, o app mostra um aviso e abre a pesquisa do jogo
na Google Play.

COMO GERAR O APK:
1. Extraia este ZIP em um computador.
2. Abra a pasta ProxyFFPanel_Android no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Selecione Build > Build Bundle(s) / APK(s) > Build APK(s).
5. O APK de depuração será gerado em app/build/outputs/apk/debug/app-debug.apk.

Observações:
- Este ZIP é o projeto-fonte, não um APK compilado.
- O botão apenas abre o jogo instalado; não injeta cheats nem modifica o Free Fire.
- A primeira sincronização do Gradle pode precisar de internet.
