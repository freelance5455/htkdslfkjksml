package com.proxyff.panel;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(9, 9, 12));
        getWindow().setNavigationBarColor(Color.rgb(9, 9, 12));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(9, 9, 12));
        webView.setVerticalScrollBarEnabled(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.addJavascriptInterface(new ProxyBridge(), "ProxyBridge");
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    private class ProxyBridge {
        @JavascriptInterface
        public void openFreeFire() {
            runOnUiThread(() -> {
                String[] packages = {"com.dts.freefireth", "com.dts.freefiremax"};
                PackageManager pm = getPackageManager();
                for (String packageName : packages) {
                    Intent launch = pm.getLaunchIntentForPackage(packageName);
                    if (launch != null) {
                        try {
                            startActivity(launch);
                            return;
                        } catch (Exception ignored) { }
                    }
                }
                Toast.makeText(MainActivity.this,
                    "Free Fire não foi encontrado. Instale o jogo e tente novamente.",
                    Toast.LENGTH_LONG).show();
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://play.google.com/store/search?q=Free%20Fire&c=apps")));
                } catch (Exception ignored) { }
            });
        }
    }
}
