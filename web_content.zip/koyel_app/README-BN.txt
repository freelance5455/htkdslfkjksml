Koyel Mobile Service Point - Android Project

Package ID: com.koyel.mobileservicepoint
Version: 1.0 (code 1)

প্রজেক্টটি Android Studio-তে খুলে Build > Build APK(s) নির্বাচন করুন।

প্রয়োজন হলে Gradle sync-এর জন্য ইন্টারনেট লাগতে পারে।

HTML ফাইলটি app/src/main/assets/index.html-এ আছে।
