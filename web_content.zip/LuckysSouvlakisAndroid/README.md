# Lucky's Souvlakis Android app

This is an Android Studio project wrapping the digital menu in a native Android WebView. The menu itself is bundled locally, so browsing the menu works offline. Sending an order opens the WhatsApp link and requires an internet connection.

## Build the APK
1. Install Android Studio (current stable) with Android SDK Platform 35.
2. Open this project folder (`LuckysSouvlakisAndroid`) in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

For a release APK, use **Build > Generate Signed Bundle / APK** and create/choose a signing key.

## App details
- App name: Lucky's Souvlakis
- Application ID: `com.luckysouvlakis.menu`
- Minimum Android: Android 6.0 (API 23)
- Menu HTML is in `app/src/main/assets/index.html`
- WhatsApp destination is configured in the HTML menu.

Note: This source project has not been compiled or tested on a device in this environment. Verify the restaurant WhatsApp number, prices, dietary labels, and VAT treatment before release.
