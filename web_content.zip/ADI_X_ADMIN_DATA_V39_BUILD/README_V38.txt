ADI X ADMIN DATA V38
Approval integrity hotfix. Withdrawal approval now verifies/resolves the withdrawal UID against the live users tree when necessary, parses numeric/string balances safely, reports the real stored balance and requested amount on rejection, and writes a corrected UID when a unique email/mobile match is found. Existing balance controls, withdrawal reason/refund, Telegram Control Center, maintenance, notifications, keys, levels and settings are preserved.


V39 approval hotfix
- Approval now reads the authoritative live users/{uid}/balance before attempting deduction.
- Transaction updater handles a stale/null local cache without falsely reporting insufficient funds.
- Permission/unauthorized transaction failures are reported separately from genuine low-balance cases.
- Approval retries up to 3 times on transient transaction contention and never deducts more than once.
