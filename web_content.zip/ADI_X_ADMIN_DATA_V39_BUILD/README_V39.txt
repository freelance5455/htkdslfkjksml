
V39 approval hotfix: authoritative live-balance precheck, null/stale transaction-cache handling, distinct permission errors, and safe retry without double deduction.
