const $ = (id) => document.getElementById(id);
let items = [];
let bill = [];

const money = n => '₦' + Number(n || 0).toLocaleString('en-NG', {minimumFractionDigits:2, maximumFractionDigits:2});
function toast(message){const el=$('toast');el.textContent=message;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),2300)}
async function api(url, options={}) {
  const res = await fetch(url, {headers:{'Content-Type':'application/json'}, ...options});
  const data = await res.json();
  if(!res.ok) throw new Error(data.error || 'Something went wrong.');
  return data;
}
async function loadItems(){
  items = await api('/api/items');
  renderItems(); renderSelect();
}
function renderSelect(){
  const select=$('itemSelect');
  select.innerHTML='<option value="">Select an item...</option>'+items.map(i=>`<option value="${i.id}">${escapeHtml(i.name)} — ${money(i.price)}</option>`).join('');
}
function renderItems(){
  const q=$('searchItems').value.toLowerCase();
  const filtered=items.filter(i=>i.name.toLowerCase().includes(q));
  $('itemCount').textContent=items.length;
  $('savedItems').innerHTML=filtered.length ? filtered.map(i=>`
    <div class="saved-row">
      <div><div class="item-name">${escapeHtml(i.name)}</div><div class="item-price">${money(i.price)}</div></div>
      <div class="item-actions"><button class="mini-btn" onclick="useItem(${i.id})">Use</button><button class="mini-btn" onclick="editItem(${i.id})">Edit</button><button class="mini-btn delete" onclick="removeItem(${i.id})">Delete</button></div>
    </div>`).join('') : '<div class="empty-state">No matching items found.</div>';
}
function escapeHtml(value){return String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
$('itemForm').addEventListener('submit', async e=>{
  e.preventDefault();
  try{
    const name=$('itemName').value.trim(), price=Number($('itemPrice').value);
    const result=await api('/api/items',{method:'POST',body:JSON.stringify({name,price})});
    $('itemForm').reset(); await loadItems(); toast(result.message);
  }catch(err){toast(err.message)}
});
$('itemSelect').addEventListener('change',()=>{
  const item=items.find(i=>i.id===Number($('itemSelect').value));
  $('unitPrice').value=item ? item.price : '';
});
$('addLineBtn').addEventListener('click',()=>{
  const item=items.find(i=>i.id===Number($('itemSelect').value));
  const quantity=Math.floor(Number($('quantity').value));
  const price=Number($('unitPrice').value);
  if(!item){toast('Choose a saved item first.');return}
  if(!Number.isFinite(quantity)||quantity<1||!Number.isFinite(price)||price<0){toast('Enter a valid quantity and price.');return}
  bill.push({name:item.name,quantity,price});
  renderBill(); $('quantity').value=1;
});
function renderBill(){
  $('billLines').innerHTML=bill.length ? bill.map((line,index)=>`
    <div class="bill-row"><div><strong>${escapeHtml(line.name)}</strong><small>${line.quantity} × ${money(line.price)}</small></div><strong>${money(line.quantity*line.price)}</strong><button class="remove-line" onclick="removeLine(${index})">×</button></div>`).join('') : '<div class="empty-state">Your bill is empty. Select an item above to begin.</div>';
  const total=bill.reduce((sum,line)=>sum+line.quantity*line.price,0);
  $('grandTotal').textContent=money(total);
  $('lineCount').textContent=`${bill.length} line${bill.length===1?'':'s'}`;
}
window.removeLine=index=>{bill.splice(index,1);renderBill()};
window.useItem=id=>{$('itemSelect').value=id;$('itemSelect').dispatchEvent(new Event('change'));$('quantity').focus()};
window.editItem=async id=>{
  const item=items.find(i=>i.id===id); if(!item)return;
  const name=prompt('Item name:',item.name); if(name===null)return;
  const price=prompt('New price (₦):',item.price); if(price===null)return;
  try{const result=await api(`/api/items/${id}`,{method:'PUT',body:JSON.stringify({name:name.trim(),price:Number(price)})});await loadItems();toast(result.message)}catch(err){toast(err.message)}
};
window.removeItem=async id=>{
  const item=items.find(i=>i.id===id);if(!item||!confirm(`Delete "${item.name}" from saved items?`))return;
  try{await api(`/api/items/${id}`,{method:'DELETE'});await loadItems();toast('Item deleted.')}catch(err){toast(err.message)}
};
$('searchItems').addEventListener('input',renderItems);
$('clearBillBtn').addEventListener('click',()=>{bill=[];renderBill()});
$('printBtn').addEventListener('click',()=>{
  if(!bill.length){toast('Add items to the bill first.');return}
  const total=bill.reduce((sum,line)=>sum+line.quantity*line.price,0);
  const rows=bill.map(line=>`<tr><td>${escapeHtml(line.name)}</td><td>${line.quantity}</td><td>${money(line.price)}</td><td>${money(line.quantity*line.price)}</td></tr>`).join('');
  const w=window.open('','_blank');
  w.document.write(`<html><head><title>PricePilot Bill</title><style>body{font-family:Arial;padding:30px;color:#18243a}h1{margin-bottom:4px}p{color:#68758a}table{width:100%;border-collapse:collapse;margin-top:25px}th,td{text-align:left;padding:12px;border-bottom:1px solid #ddd}th{background:#f2f5fa}.total{text-align:right;font-size:22px;font-weight:bold;margin-top:25px}</style></head><body><h1>PricePilot</h1><p>Bill summary • ${new Date().toLocaleString()}</p><table><thead><tr><th>Item</th><th>Qty</th><th>Unit price</th><th>Amount</th></tr></thead><tbody>${rows}</tbody></table><div class="total">Grand total: ${money(total)}</div><script>window.onload=()=>window.print()<\/script></body></html>`);
  w.document.close();
});
loadItems().catch(()=>toast('Could not connect to the Python server.'));
renderBill();