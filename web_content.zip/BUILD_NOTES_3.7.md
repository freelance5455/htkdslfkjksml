# XGaming 3.7

- Refined the X gaming top wordmark into a cleaner company-style brand treatment.
- Balanced the two toolbar icon groups with equal-width columns and consistent spacing.
- Kept the existing icon artwork and functionality unchanged.
- Responsive spacing retained for small Android screens.
- versionCode: 37
- versionName: 3.7
