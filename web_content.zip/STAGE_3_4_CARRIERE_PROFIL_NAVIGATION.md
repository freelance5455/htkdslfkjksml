# Socle 3.4 — Fondation carrière, profil manager et navigation mobile

## Objectif
Faire évoluer le prototype de gestion sportive vers une carrière incarnée, avec identité persistante du manager et une navigation mobile à écran unique inspirée des jeux de management sportif.

## Livré dans ce socle
- Création du profil manager : prénom, nom, galaxie de jeu, sexe, réputation initiale et mode de carrière.
- Sélection du club de départ parmi les clubs actifs pour les modes Club et Club & International.
- Mode Sans emploi : le manager démarre sans club (le système de candidatures et d'offres d'emploi reste une étape ultérieure).
- Quatre paliers de réputation : Inconnu, Locale, Continentale et Mondiale ; moteur de score borné de 0 à 100 et journal des évolutions.
- Conservation du profil, du mode et des options dans la sauvegarde existante avec migration rétrocompatible.
- Rail de navigation tactile : Messagerie, Accueil, Club, Arène, Damistes, Compétitions, Recherche et Réglages ; un écran principal est affiché à la fois.
- Affichage d'un écran principal à la fois, sans supprimer les sections existantes ; les rubriques sont regroupées sous les écrans correspondants.
- Réglage du niveau de l'IA et commandes de sauvegarde manuelle / rechargement.
- Badge du nombre de messages non lus.
- Bouton global « CONTINUER » dont le libellé bascule vers « RÉPONSE REQUISE » ou « ALLER AU MATCH » selon les événements prioritaires ; les messages du conseil sont bloquants jusqu’à la réponse.

## Architecture préservée
Les huit compétitions, les moteurs de dames, le calendrier FGD / AGD, les contrats, les transferts, l’identité visuelle et la scène 3D n’ont pas été modifiés. La spécification complète des onze domaines est consignée dans `SPEC_CARRIERE_MANAGER_CGD_V117.md`. Les clubs conservent deux damistes chacun.

## Étapes restantes du grand chantier
1. Boucle quotidienne CONTINUER et arrêts contextuels obligatoires.
2. Messagerie avec types d'interlocuteurs élargis et messages bloquants configurables.
3. Tableau du conseil, objectifs, demandes et risque de licenciement.
4. Finances détaillées, installations, staff et délégation.
5. Arènes spéciales et 60 arènes de clubs dans un sélecteur dédié.
6. Effectif enrichi, réserve, centre de jeunes et progression.
7. Recrutement, agents, prêts, listes de transfert et offres d'emploi.
8. Calendrier de compétition avec créneaux officiels mardi, mercredi, jeudi et samedi, sous réserve des dates validées FGD / AGD déjà requises.
9. Hall of Fame, armoire à trophées et cérémonie de fin de saison animée prix par prix.
10. Sauvegardes multiples, chargement de plusieurs carrières et options complètes.

## Limites explicites
Ce socle ne prétend pas encore livrer toutes les fonctionnalités de la spécification complète. Le mode Club & International ne donne pas encore automatiquement une sélection au manager ; le mode Sans emploi démarre bien sans club, mais les offres et candidatures seront raccordées dans une étape ultérieure. Le système quotidien et les récompenses complètes restent à développer.
