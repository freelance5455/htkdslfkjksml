NovaCam Studio — Android Studio project
======================================

এই ZIP-এ NovaCam ওয়েবসাইটের Android WebView wrapper, ক্যামেরা permission এবং launcher icon আছে।
এটি একটি Android Studio project; এটি নিজে থেকে compiled APK নয়।

APK বানানোর নিয়ম:
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. Android Studio > Open দিয়ে এই ZIP extract করা NovaCamAndroidProject ফোল্ডার খুলুন।
3. Gradle sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
5. Build সফল হলে app/build/outputs/apk/debug/app-debug.apk ফাইল পাবেন।
6. APK ফোনে পাঠিয়ে ইনস্টল করুন। ফোনে “Install unknown apps” অনুমতি দিতে হতে পারে।

গুরুত্বপূর্ণ:
- JavaScript এবং WebView camera capture অনুমতি যোগ করা হয়েছে।
- ভিডিও রেকর্ডিং WebView/Android সংস্করণ অনুযায়ী পরীক্ষা করতে হবে; কিছু ডিভাইসে WebView-এর MediaRecorder সীমাবদ্ধতা থাকতে পারে।
- প্রকল্পটি Android SDK ও Gradle sync করতে ইন্টারনেট চাইতে পারে।
