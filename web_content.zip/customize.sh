#!/system/bin/sh
SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true
REPLACE="
"

NAME="𝗞𝗿𝘆𝘁𝗲𝘅 𝗥𝗮𝘁𝗲."
VERSION="3.0"
AUTHOR="@vennec"

ui_print() { echo "$1"; }

ui_print " "
ui_print "========================================"
ui_print " MODULE INFO"
ui_print "======================================"
ui_print " Name    : $NAME"
ui_print " Version : $VERSION"
ui_print " Author  : $AUTHOR"
ui_print " Date    : $(date +'%Y-%m-%d %H:%M')"
ui_print "======================================"
ui_print " "

ANDROID_VER=$(getprop ro.build.version.release)
DEVICE_MODEL=$(getprop ro.product.model)
DEVICE_CODENAME=$(getprop ro.product.device)

ui_print "======================================"
ui_print " DEVICE INFO"
ui_print "======================================"
ui_print " Model   : $DEVICE_MODEL ($DEVICE_CODENAME)"
ui_print " Android : $ANDROID_VER"
ui_print "======================================"
ui_print " "

ui_print "- Installing module files..."
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
sleep 1

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive  $MODPATH/system/lib       0     0       0755      0644
set_perm  $MODPATH/system/bin/app_process32   0     2000    0755      u:object_r:zygote_exec:s0
set_perm  $MODPATH/system/bin/dex2oat         0     2000    0755      u:object_r:dex2oat_exec:s0
set_perm  $MODPATH/system/lib/libart.so       0     0       0644
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/post-fs-data.sh 0 0 0755
set_perm $MODPATH/customize.sh 0 0 0755
set_perm_recursive $MODPATH/webroot 0 0 0755 0644

ui_print "- Install successfully."
sleep 1

ui_print "- Opening support channel..."
am start -a android.intent.action.VIEW -d "tg://resolve?domain=Vennec" >/dev/null 2>&1

set_perm_recursive $MODPATH 0 0 0755 0644