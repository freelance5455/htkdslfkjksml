#!/sbin/sh

SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=true
LATESTARTSERVICE=true
SKIPUNZIP=0

REPLACE="
"

print_modname() {
  ui_print " "
  ui_print "  ------------------------------------------------------------"
  ui_print "   HyperVulkan Switcher v3.2.1 - Render Auto Engine"
  ui_print "   Auto-render v3.2.1"
  ui_print "   Eligible renderer: vulkan / vulkan skia in games,"
  ui_print "                      opengl / skiagl outside games"
  ui_print "   Config ONLY contains enabled items (HyperPerf pattern)"
  ui_print "  ------------------------------------------------------------"
  ui_print " "
}

on_install() {
  ui_print "  ------------------------------------------------------------"
  ui_print "   DEVICE INFO"
  ui_print "  ------------------------------------------------------------"
  ui_print "   Model    : $(getprop ro.product.model 2>/dev/null || echo "Unknown")"
  ui_print "   Android  : $(getprop ro.build.version.release 2>/dev/null || echo "Unknown")"
  ui_print "   GPU      : $(getprop ro.hardware.egl 2>/dev/null || echo "Unknown")"
  ui_print "  "
  ui_print "  ------------------------------------------------------------"
  ui_print "   MODULE INFO"
  ui_print "  ------------------------------------------------------------"
  ui_print "   Auto-render      : Vulkan in games / GL outside"
  ui_print "                     (v3.2.1 detection, editable list)"
  ui_print "   Flat props       : written to .conf upon activation"
  ui_print "   WebUI Interface  : toggle applies instantly"
  ui_print "                     (KernelSU / APatch / KSUWebUI / MMRL)"
  ui_print "  "
  ui_print "  ------------------------------------------------------------"
  ui_print "   INSTALLING"
  ui_print "  ------------------------------------------------------------"
  OLD_MOD="/data/adb/modules/Switchmat"
  BACKUP_DIR="/data/adb/hvs_backup"
  if [ -d "$OLD_MOD" ]; then
    mkdir -p "$BACKUP_DIR" 2>/dev/null
    cp -f "$OLD_MOD/config.conf" "$BACKUP_DIR/config.conf" 2>/dev/null
    cp -f "$OLD_MOD/games.conf" "$BACKUP_DIR/games.conf" 2>/dev/null
  fi

  unzip -o "$ZIPFILE" '*' -d $MODPATH >&2

  if [ -f "$BACKUP_DIR/config.conf" ] || [ -f "$BACKUP_DIR/games.conf" ]; then
    [ -f "$BACKUP_DIR/config.conf" ] && cp -f "$BACKUP_DIR/config.conf" "$MODPATH/config.conf" 2>/dev/null
    [ -f "$BACKUP_DIR/games.conf" ] && cp -f "$BACKUP_DIR/games.conf" "$MODPATH/games.conf" 2>/dev/null
  fi
  rm -rf "$BACKUP_DIR" 2>/dev/null

  ui_print "   [ok] service.sh       auto-render monitor (v3.2.1)"
  ui_print "   [ok] post-fs-data.sh  boot properties (early)"
  ui_print "   [ok] action.sh        CLI + WebUI control"
  ui_print "   [ok] lib/props.sh     props registry"
  ui_print "   [ok] config.conf      flat props (KEY=VALUE)"
  ui_print "   [ok] games.conf       games list"
  ui_print "   [ok] webroot/         WebUI interface"
  ui_print "   [ok] uninstall.sh     cleanup on uninstall"
  ui_print "  "

  rm -f "$MODPATH/.webui_draft" "$MODPATH/config.conf.tmp" "$MODPATH/config.prop.tmp" 2>/dev/null
  rm -f "$MODPATH/current_mode" "$MODPATH/last_focus" 2>/dev/null
}

set_permissions() {
  set_perm_recursive "$MODPATH" root root 0755 0644
  set_perm "$MODPATH/service.sh" root root 0755
  set_perm "$MODPATH/post-fs-data.sh" root root 0755
  set_perm "$MODPATH/action.sh" root root 0755
  set_perm "$MODPATH/lib/props.sh" root root 0644
  set_perm "$MODPATH/config.conf" root root 0644
  set_perm "$MODPATH/games.conf" root root 0644
  set_perm "$MODPATH/uninstall.sh" root root 0755
}

post_install() {
  ui_print "  ------------------------------------------------------------"
  ui_print "   INSTALLATION COMPLETE"
  ui_print "  ------------------------------------------------------------"
  ui_print "   Reboot your device to enable the module"
  ui_print "   Open the WebUI interface from your module manager"
  ui_print "   (KernelSU / APatch / Magisk + KSUWebUI or MMRL)"
  ui_print "   Add your games in the Games tab of the interface"
  ui_print "  "
  ui_print "  ------------------------------------------------------------"
  ui_print "   DEVELOPER & LINKS"
  ui_print "  ------------------------------------------------------------"
  ui_print "   Developer : SrMatdroid"
  ui_print "   support   : https://t.me/hyperperfdisccusion"
  ui_print "   channel   : https://t.me/keycertificados"
  ui_print "   GitHub    : https://github.com/SrMatdroid"
  ui_print "  ------------------------------------------------------------"
  ui_print " "
}

on_install
post_install
