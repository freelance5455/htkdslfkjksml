#!/system/bin/sh

MODULE_NAME="ASUKAAA GAMING RED MAGIC VIP EDITION"
MODULE_VERSION="1.0.0"
MODULE_AUTHOR="ASUKAAA GAMING"
MODULE_DESC="120Hz | VSYNC | Frame Pacing | SurfaceFlinger | Vulkan | HWUI | Touch | CPU | GPU | Thermal | Memory | Scheduler | Performance | Game Detection | Game Optimization"

GREEN='\033[0;32m'
NC='\033[0m'

print_msg() {
printf "${GREEN}%s${NC}\n" "$1"
}

print_line() {
printf "${GREEN}%s${NC}\n" "-----------------------------------------"
}

clear
print_msg "======================================="
print_msg "      ASUKAAA GAMING RED MAGIC VIP EDITION"
print_msg "======================================="
sleep 1

print_msg "[ INITIALIZING RED MAGIC VIP EDITION....... ]"
sleep 1

print_msg " ▶ GAME DETECTION & OPTIMIZATION"
sleep 2

GAME_PKGS="
com.garena.game.codm
com.mobile.legends
com.tencent.ig
com.dts.freefireth
com.dts.freefiremax
com.roblox.client
com.mojang.minecraftpe
age.of.civilizations2.jakowski.lukasz
com.bushiroad.en.bangdreamgbp
com.ChillyRoom.DungeonShooter
com.chillyroom.soulknightprequel
com.Flanne.MinutesTillDawn.roguelike.shooting.gp
com.GameCoaster.ProtectDungeon
com.HoYoverse.hkrpgoversea
com.RoamingStar.BlueArchive
com.Shooter.ModernWarships
com.Sunborn.SnqxExilium
com.YoStar.AetherGazer
com.YoStarEN.Arknights
com.YoStarEN.MahjongSoul
com.YoStarJP.MajSoul
com.YostarJP.BlueArchive
com.ZeroCastleGameStudio.StrikeBusterPrototype
com.ZeroCastleGameStudioINTL.StrikeBusterPrototype
com.activision.callofduty.shooter
com.activision.callofduty.warzone
com.albiononline
com.aligames.kuang.kybc
com.autumn.skullgirls
com.axlebolt.standoff2
com.bandainamcoent.imas_millionlive_theaterdays
com.bandainamcoent.sao
com.bandainamcoent.shinycolorsprism
com.bhvr.deadbydaylight
com.bilibili.azurlane
com.bilibili.deadcells.mobile
com.bilibili.fatego
com.bilibili.star.bili
com.bilibili.warmsnow
com.bilibiligame.heglgp
com.bingkolo.kleins.cn
com.blizzard.diablo.immortal
com.bushiroad.d4dj
com.bushiroad.lovelive.schoolidolfestival2
com.carxtech.sr
com.citra.emu
com.cnvcs.xiangqi
com.criticalforceentertainment.criticalops
com.dena.a12026801
com.denachina.g13002010
com.dfjz.moba
com.dgames.g15002002
com.dolphinemu.dolphinemu
com.dragonli.projectsnow.lhm
com.dts.freefireadv
com.ea.gp.apexlegendsmobilefps
com.ea.gp.fifamobile
com.epicgames.fortnite
com.fantablade.icey
com.firsttouchgames.dls7
com.gabama.monopostolite
com.gameloft.android.ANMP.GloftA9HM
com.gameloft.android.ANMP.GloftMVHM
com.garena.game.kgid
com.garena.game.kgtw
com.garena.game.kgvn
com.guyou.deadstrike
com.halo.windf.hero
com.heavenburnsred
com.hermes.j1game
com.hottapkgs.hotta
com.hypergryph.arknights
com.ignm.raspberrymash.jp
com.ilongyuan.implosion
com.jacksparrow.jpmajiang
com.je.supersus
com.kakaogames.eversoul
com.kakaogames.wdfp
com.kog.grandchaseglobal
com.komoe.kmumamusumegp
com.kurogame.haru
com.kurogame.haru.bilibili
com.leiting.wf
com.levelinfinite.hotta.gp
com.levelinfinite.sgameGlobal
com.levelinfinite.sgameGlobal.midaspay
com.lilithgames.hgame.cn
com.linegames.sl
com.madfingergames.legends
com.miHoYo.GenshinImpact
com.miHoYo.Yuanshen
com.miHoYo.bh3
com.miHoYo.bh3global
com.miHoYo.bh3oversea
com.miHoYo.bh3oversea_vn
com.miHoYo.enterprise.NGHSoD
com.miHoYo.hkrpg
com.miHoYo.ys
com.miraclegames.farlight84
com.mobilelegends.hwag
com.mojang.hostilegg
com.mojang.minecraftpe.patch
com.nanostudios.games.twenty.minutes
com.netease.AVALON
com.netease.EVE
com.netease.aceracer
com.netease.dfjs
com.netease.dwrg
com.netease.eve.en
com.netease.frxyna
com.netease.g93na
com.netease.h75na
com.netease.jddsaef
com.netease.lglr
com.netease.ma84
com.netease.moba
com.netease.mrzh
com.netease.newspike
com.netease.nshm
com.netease.onmyoji
com.netease.party
com.netease.partyglobal
com.netease.race
com.netease.racerna
com.netease.sky
com.netease.soulofhunter
com.netease.tj
com.netease.tom
com.netease.wotb
com.netease.x19
com.netease.yhtj
com.nexon.bluearchive
com.nexon.kartdrift
com.nianticlabs.monsterhunter
com.olzhass.carparking.multyplayer
com.pearlabyss.blackdesertm.gl
com.pinkcore.tkfm
com.playdigious.deadcells.mobile
com.proximabeta.mf.uamo
com.proximabeta.nikke
com.prpr.musedash
com.pubg.imobile
com.pubg.krmobile
com.pubg.newstate
com.pwrd.hotta.laohu
com.pwrd.huanta
com.r2games.myhero.bilibili
com.rayark.implosion
com.rayark.sdorica
com.rekoo.pubgm
com.riotgames.league.teamfighttactics
com.riotgames.league.teamfighttacticsvn
com.riotgames.league.wildrift
com.rockstargames.gtasa
com.sega.ColorfulStage.en
com.sega.pjsekai
com.shangyoo.neon
com.shenlan.m.reverse1999
com.smokoko.race
com.sofunny.Sausage
com.soulgamechst.majsoul
com.sprduck.garena.vn
com.stove.epic7.google
com.supercell.brawlstars
com.supercell.clashofclans
com.supercell.clashroyale
com.sy.dldlhsdj
com.t2ksports.nba2k20and
com.tencent.KiHan
com.tencent.jkchess
com.tencent.lolm
com.tencent.mf.uam
com.tencent.tmgp.WePop
com.tencent.tmgp.bh3
com.tencent.tmgp.cf
com.tencent.tmgp.cod
com.tencent.tmgp.dfjs
com.tencent.tmgp.ffom
com.tencent.tmgp.gnyx
com.tencent.tmgp.kr.codm
com.tencent.tmgp.pubgmhd
com.tencent.tmgp.sgame
com.tencent.tmgp.speedmobile
com.tencent.tmgp.wuxia
com.tencent.tmgp.yys.zqb
com.tencent.toaa
com.tgc.sky.android
com.the10tons.dysmantle
com.ubisoft.rainbowsixmobile.r6.fps.pvp.shooter
com.unity.mmd
com.valvesoftware.cswgsm
com.valvesoftware.source
com.vng.mlbbvn
com.vng.pubgmobile
com.vng.speedvn
com.xd.TLglobal
com.xd.rotaeno.googleplay
com.xd.rotaeno.tapcn
com.xindong.torchlight
com.yongshi.tenojo
com.zlongame.mhmnz
com.ztgame.bob
com.zy.wqmt.cn
jp.co.craftegg.band
jp.konami.pesam
net.kdt.pojavlaunch
net.wargaming.wot.blitz
org.mm.jr
org.vita3k.emulator
pro.archiemeng.waifu2x
skyline.emu
skynet.cputhrottlingtest
org.yuzu.yuzu_emu
id.rj01117883.liomeko
xyz.aethersx2.android
com.pwrd.opmwsea
com.kurogame.gplay.punishing.grayraven.en
com.FosFenes.Sonolus
com.devsisters.ck
ro.alyn_sampmobile.game
com.kakaogames.gdts
com.Shooter.ModernWarship
com.supercell.hayday
com.nekki.shadowfight
com.nekki.shadowfight3
com.gamedevltd.wwh
com.netease.ma100asia
com.gryphline.exastris.gp
org.sudachi.sudachi_emu.ea
com.netmarble.sololv
com.netease.g78na.gb
com.bandainamcoent.opbrww
com.proximabeta.mf.uamo
com.kurogame.wutheringwaves.global
com.HoYoverse.Nap
"

GAME_FOUND=0

for PKG in $GAME_PKGS; do
    if pidof "$PKG" >/dev/null 2>&1; then
        GAME_FOUND=1
        print_msg " ✔ GAME DETECTED: $PKG"
        print_msg " ✔ GAME OPTIMIZATION PROFILE ACTIVE"
    fi
done

if [ "$GAME_FOUND" -eq 0 ]; then
    print_msg " • NO SUPPORTED GAME DETECTED"
    print_msg " • SYSTEM PERFORMANCE PROFILE CONTINUES"
fi

sleep 2

print_msg " ▶ 120Hz DISPLAY & REFRESH RATE CONFIGURATION"
sleep 2
print_msg " ▶ VSYNC & FRAME PACING CONFIGURATION"
sleep 3
print_msg " ▶ SURFACEFLINGER LOW-LATENCY TUNING"
sleep 4
print_msg " ▶ VULKAN & HWUI RENDERING CONFIGURATION"
sleep 5
print_msg " ▶ TOUCH PREDICTION & RESPONSE BOOST"
sleep 6
print_msg " ▶ CPU & GPU PERFORMANCE CONFIGURATION"
sleep 7
print_msg " ▶ MEMORY, SCHEDULER & THERMAL TUNING"
sleep 8

print_msg "[■□□□□□□□□□]"
sleep 0.3
print_msg "[■■□□□□□□□□]"
sleep 0.4
print_msg "[■■■□□□□□□□]"
sleep 0.5
print_msg "[■■■■□□□□□□]"
sleep 0.6
print_msg "[■■■■■□□□□□]"
sleep 0.7
print_msg "[■■■■■■□□□□]"
sleep 0.8
print_msg "[■■■■■■■□□□]"
sleep 0.9
print_msg "[■■■■■■■■□□]"
sleep 1
print_msg "[■■■■■■■■■□]"
sleep 2
print_msg "[■■■■■■■■■■]"

sleep 2

print_msg ""
print_msg "[ ✔ RED MAGIC VIP EDITION APPLIED ]"

print_msg ""
print_line
print_msg " RED MAGIC VIP EDITION"
print_line
print_msg " ✔ 120Hz Display Refresh Configuration"
print_msg " ✔ Adaptive Refresh Switching Configuration"
print_msg " ✔ VSYNC Configuration"
print_msg " ✔ Triple Buffering Configuration"
print_msg " ✔ Frame Pacing Configuration"
print_msg " ✔ Fixed Performance Mode Configuration"
print_msg " ✔ Performance Hint Configuration"
print_msg " ✔ SurfaceFlinger Low-Latency Configuration"
print_msg " ✔ SurfaceFlinger Frame Rate Configuration"
print_msg " ✔ SurfaceFlinger VSYNC Configuration"
print_msg " ✔ Hardware Composer Configuration"
print_msg " ✔ SurfaceFlinger Backpressure Configuration"
print_msg " ✔ Vulkan Rendering Configuration"
print_msg " ✔ Skia Vulkan Renderer Configuration"
print_msg " ✔ HWUI Rendering Configuration"
print_msg " ✔ OpenGL Trace Configuration"
print_msg " ✔ GPU Debug Configuration"
print_msg " ✔ Touch Prediction Configuration"
print_msg " ✔ Touch Resampling Configuration"
print_msg " ✔ Touch Boost Configuration"
print_msg " ✔ Touch Response Boost Configuration"
print_msg " ✔ Background Application Limit Configuration"
print_msg " ✔ Cached Apps Freezer Configuration"
print_msg " ✔ Power Saving Configuration"
print_msg " ✔ System Animation Configuration"
print_msg " ✔ ColorOS Analytics Configuration"
print_msg " ✔ ColorOS Telemetry Configuration"
print_msg " ✔ App Preload Configuration"
print_msg " ✔ AI Memory Configuration"

print_msg ""
print_line
print_msg " RED MAGIC VIP EDITION - ROOT PERFORMANCE TUNING"
print_line
print_msg " ✔ SurfaceFlinger Phase Offset Configuration"
print_msg " ✔ SurfaceFlinger Early Wakeup Configuration"
print_msg " ✔ VSYNC Phase Adjustment Configuration"
print_msg " ✔ Frame Rate Switching Threshold Configuration"
print_msg " ✔ Strict Frame Rate Configuration"
print_msg " ✔ Present Fence Configuration"
print_msg " ✔ Vulkan Async Compilation Configuration"
print_msg " ✔ Vulkan Secondary Command Buffer Configuration"
print_msg " ✔ Vulkan Persistent Mapping Configuration"
print_msg " ✔ Multithreaded OpenGL Configuration"
print_msg " ✔ HWUI Texture & Layer Cache Configuration"
print_msg " ✔ CPU Performance Governor Configuration"
print_msg " ✔ CPU Maximum Frequency Configuration"
print_msg " ✔ CPU Minimum Frequency Configuration"
print_msg " ✔ GPU Performance Governor Configuration"
print_msg " ✔ Thermal Zone Configuration"
print_msg " ✔ VM Swappiness Configuration"
print_msg " ✔ VFS Cache Pressure Configuration"
print_msg " ✔ Memory Free Page Configuration"
print_msg " ✔ Page Cache Configuration"
print_msg " ✔ Kernel Cache Configuration"
print_msg " ✔ Kernel NOHZ Configuration"
print_msg " ✔ RCU Configuration"
print_msg " ✔ Kernel Scheduler Latency Configuration"
print_msg " ✔ Scheduler Migration Cost Configuration"
print_msg " ✔ Scheduler Granularity Configuration"
print_msg " ✔ Scheduler Wakeup Configuration"

print_msg ""
print_line
print_msg " RED MAGIC VIP EDITION"
print_line
print_msg " ✔ DISPLAY PERFORMANCE PARAMETERS CONFIGURED"
print_msg " ✔ VSYNC & FRAME PACING PARAMETERS CONFIGURED"
print_msg " ✔ SURFACEFLINGER PARAMETERS CONFIGURED"
print_msg " ✔ VULKAN & HWUI PARAMETERS CONFIGURED"
print_msg " ✔ TOUCH RESPONSE PARAMETERS CONFIGURED"
print_msg " ✔ CPU PERFORMANCE PARAMETERS CONFIGURED"
print_msg " ✔ GPU PERFORMANCE PARAMETERS CONFIGURED"
print_msg " ✔ THERMAL PARAMETERS CONFIGURED"
print_msg " ✔ MEMORY PARAMETERS CONFIGURED"
print_msg " ✔ KERNEL SCHEDULER PARAMETERS CONFIGURED"

print_msg ""
print_line
print_msg " RED MAGIC PERFORMANCE PROFILE STATUS"
print_line
print_msg " ✔ 120Hz REFRESH PROFILE APPLIED"
print_msg " ✔ LOW-LATENCY FRAME PROFILE APPLIED"
print_msg " ✔ VULKAN RENDERING PROFILE APPLIED"
print_msg " ✔ TOUCH RESPONSE PROFILE APPLIED"
print_msg " ✔ CPU/GPU PERFORMANCE PROFILE APPLIED"
print_msg " ✔ MEMORY & SCHEDULER PROFILE APPLIED"

print_msg ""
print_line
print_msg " GAME OPTIMIZATION STATUS"
print_line
print_msg " ✔ GAME PACKAGE DETECTION ENABLED"
print_msg " ✔ SUPPORTED GAME PROCESS DETECTION ENABLED"
print_msg " ✔ DETECTED GAME PROFILE READY"
print_msg " ✔ RED MAGIC PERFORMANCE PROFILE READY"

print_msg ""
print_msg "======================================="
print_msg "    ASUKAAA GAMING RED MAGIC VIP EDITION ACTIVE"
print_msg "======================================="
print_msg ""
print_msg "✔ RED MAGIC VIP EDITION APPLIED"
print_msg "✔ GAME DETECTION & OPTIMIZATION PROCESSED"
print_msg "✔ DISPLAY & FRAME PARAMETERS PROCESSED"
print_msg "✔ RENDERING & TOUCH PARAMETERS CONFIGURED"
print_msg "✔ CPU/GPU & SYSTEM PERFORMANCE PARAMETERS CONFIGURED"
print_msg ""
print_msg "🔔 NOTIFICATION: RED MAGIC VIP EDITION ACTIVE"
print_msg "🔔 NOTIFICATION: GAME, DISPLAY, FRAME, RENDERING & PERFORMANCE PROFILE APPLIED"
print_msg ""
print_msg "ASUKAAA GAMING • RED MAGIC VIP EDITION"
print_msg ""

cmd notification post \
        -S bigtext \
        -t 'ASUKAAA GAMING | RED MAGIC VIP EDITION' \
        'ASUKAAA_FRAME_PERFORMANCE' \
        '✔ RED MAGIC VIP EDITION ACTIVE — 120Hz, VSYNC, Frame Pacing, SurfaceFlinger, Vulkan/HWUI, Touch, CPU/GPU, Memory, Scheduler & Game Detection profile applied.'

logcat -c &>/dev/null

exit 0