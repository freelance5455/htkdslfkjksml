# OneHub Website (English UI)

Updated responsive PWA link hub. The interface, categories, search, About and Privacy pages are in English. Service tiles use brand-inspired colors; these are text-based marks, not official logo artwork.

## Publish on Netlify
1. Extract this ZIP.
2. Upload the contents of the `OneHubWeb` folder (including `index.html`, `manifest.webmanifest`, `sw.js`, `icon.svg`, `about.html`, and `privacy.html`) to your existing Netlify site, replacing the previous deployed files.
3. Keep the Google Search Console verification meta tag in `index.html` unchanged.
4. After deployment, open the live site and check the bottom `Download App Now` bar. On supported Android browsers it opens the install prompt; otherwise follow the browser's Add to Home Screen option. On iPhone, use Safari Share → Add to Home Screen.

## Notes
OneHub is an independent link hub and does not integrate third-party accounts, carts, or payments. Brand colors are approximations for visual recognition; no official brand logos are embedded. Review the privacy policy and add a contact email before public promotion.
