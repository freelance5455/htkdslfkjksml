# Candy Quest — AdMob Test Project

This Android Studio project wraps the supplied Candy Quest / Sweet Match Adventure HTML game in a WebView and adds:

- Banner ad using Google's official test banner unit.
- Interstitial ad using Google's official test interstitial unit.
- Interstitial is triggered at the game's Level Complete modal.
- No real AdMob account or real ad IDs are required for testing.

## Build

1. Open this folder in Android Studio.
2. Allow Gradle to download dependencies.
3. Sync the project.
4. Run the `app` configuration on an Android 7.0+ device/emulator.
5. Build > Build APK(s).

## Before publishing

Create/register the app in AdMob and replace:

- `ca-app-pub-3940256099942544~3347511713` in `AndroidManifest.xml` with your AdMob App ID.
- `ca-app-pub-3940256099942544/9214589741` in `activity_main.xml` with your Banner Ad Unit ID.
- `ca-app-pub-3940256099942544/1033173712` in `MainActivity.java` with your Interstitial Ad Unit ID.

Do not publish the Google sample test IDs as production ad IDs.

## Important

This project intentionally keeps the original HTML gameplay and adds the native Android ad layer around it. The supplied APK itself is not modified/re-signed; this is a clean rebuildable Android Studio project.
