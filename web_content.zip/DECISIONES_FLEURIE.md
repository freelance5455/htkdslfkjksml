# Fleurie by Elixir — decisiones del producto

## Confirmado por la propietaria
- Android y iOS desde el lanzamiento previsto.
- Comunidad con perfiles personales y páginas de negocios.
- Marketplace de clasificados: cualquier persona puede vender.
- Premium con suscripción mensual.
- Sin anuncios en Free ni Premium.
- Asistente general de IA integrado.
- Cuenta Founder con todas las funciones Premium gratuitas y controles administrativos/monetización exclusivos.
- Agregar muchísimas tipografías, kaomojis y banners para perfiles.
- Fleurie Academy debe enseñar matemáticas y muchas otras materias.
- Fleurie Career debe avisar sobre oportunidades laborales.

## Regla de Premium
Solo deben ser Premium las funciones que la propietaria haya seleccionado expresamente. No se debe asignar Premium automáticamente a módulos completos. La clasificación detallada no se inventará.

## Módulos previstos
Inicio; Calendario; Metas; Hábitos; Finanzas; Mi hogar; Estudios; Career; Bienestar; Fitness; My Little World (sin música, películas ni series); Dear Diary; Discover; Social; Market; Kitchen; Style; Astrología y tarot; Mini Games; Little Companion; My Future Home; My Evolution; Travel; Around; Business; Academy; Library; Closet; Services; Fleurie AI; Personalización; Perfil; Herramients generales.

## Desarrollo
El proyecto incluido es una base/prototipo local para Android. La versión de producción requiere backend y servicios adicionales. La versión iOS deberá desarrollarse y probarse aparte.
