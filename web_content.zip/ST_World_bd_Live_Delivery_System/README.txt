ST World bd – Live Delivery System

এই ভার্সনে Admin, Rider এবং Shop একই ওয়েব অ্যাপের মধ্যে আছে।
config.js-এ Supabase URL ও anon/publishable key বসালে PC ও ফোন একই online database ব্যবহার করবে।

ধাপ:
1. Supabase free project খুলুন।
2. SQL Editor-এ supabase.sql-এর সব SQL Run করুন।
3. Project URL ও anon/publishable key config.js-এ বসান।
4. এই ফোল্ডার HTTPS static hosting-এ upload করুন।
5. ফোনে link খুলে Add to Home Screen দিন।

নোট: এটি prototype। Production ব্যবহারের আগে proper authentication এবং Row Level Security শক্ত করা উচিত।
