Cartoon World — updated prototype
- Catalogue includes the cartoon titles requested by the user.
- Open index.html in a modern browser.
- Search supports Arabic and English title names; favorites are stored locally.
- This is a web prototype, not an APK or Google Play release.
- It uses emoji artwork and descriptive demo cards, not official copyrighted posters or video episodes.
- Add only video sources you have permission to distribute/stream.
