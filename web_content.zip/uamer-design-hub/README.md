# Uamer Design Hub — Uamer Feruak SR

Mobile-first PWA for ordering digital services (React + TypeScript + Tailwind + Supabase).
Customers browse services, submit orders with files, pay by bank transfer (manual proof), chat via WhatsApp and track orders.
The admin dashboard manages services, customers, orders, files, payments, notifications and settings.

## 1. Create the Supabase project
1. Go to https://supabase.com, sign in, click **New project**. Pick a name, a strong database password (save it somewhere safe) and the region closest to Nigeria.
2. Wait until the project is ready.

## 2. Run the SQL schema
1. In Supabase open **SQL Editor → New query**.
2. Paste the entire contents of `supabase/schema.sql` and click **Run**.
3. This creates the tables, indexes, triggers (notifications, timeline), Row Level Security policies, the private `order-files` bucket, the public `branding` bucket (logo only), storage policies, and seeds the 8 services plus default settings. No fake customers or orders are created.

## 3. Configure authentication
1. **Authentication → Providers → Email**: keep enabled.
2. **Authentication → URL Configuration**: set **Site URL** to your live URL (use `http://localhost:5173` while testing). Add the same URL, with `/reset-password` and `/login`, under **Redirect URLs**.
3. Optional: turn off "Confirm email" while testing. Keep it on for production.

## 4. Storage buckets
Already created by the SQL (step 2). Check **Storage**: `order-files` must be **Private**. Do not make it public.

## 5. Environment variables
```
cp .env.example .env
```
Fill in from **Project Settings → API**:
```
VITE_SUPABASE_URL=https://xxxx.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-public-key
```
Use only the `anon` key. Never put the `service_role` key in this project.

## 6. Run locally
```
npm install
npm run dev
```
Open http://localhost:5173 (on your phone use the Network URL shown, same Wi‑Fi).

## 7. Build
```
npm run build      # type-checks, then outputs dist/
npm run preview
```

## 8. Deploy
Any static host works. Environment variables must be set on the host.
- **Vercel**: import the repo → framework Vite → add the two `VITE_` variables → Deploy (`vercel.json` already handles page refreshes).
- **Netlify**: build command `npm run build`, publish directory `dist`, add the variables (`public/_redirects` handles routing).
- **Cloudflare Pages**: same build settings; add the variables.

## 9. Custom domain later
In your host's dashboard add the domain (e.g. `uamerferuak.com`), set the DNS records it shows at your registrar, wait for HTTPS, then update Supabase **Site URL / Redirect URLs** to the new domain.

## 10. Create the first admin securely
Admins can only be created from the database, never from the app.
1. Open the live app and **sign up** with the email you want as admin, then log in once.
2. In Supabase **SQL Editor** run (use your email):
```sql
update public.profiles set role = 'admin' where email = 'you@example.com';
```
3. Log out and in again; you will land on `/admin`.
A database trigger blocks anyone using the app from changing a role. No admin password is stored anywhere in the code.

## Security model (summary)
- RLS on every table; customers see only their own profile, orders, files, messages, payments, notifications.
- Customers cannot set an order to Paid: proof goes through `submit_payment_proof()` and only an admin can run `verify_payment()`.
- Order files live in a private bucket, opened by 10-minute signed URLs; storage policies restrict each folder (`<order_id>/…`) to its owner and admins.
- Frontend route guards are convenience only; the database enforces access.

## Notifications and Telegram later
All in-app notifications are created by database triggers into `notifications` and delivered live via Supabase Realtime. To add Telegram: create a Supabase Edge Function (bot token stored as a function secret, never in the frontend) triggered by a Database Webhook on `notifications` inserts for admin users.

## Payments later
`payments` already has `provider` and `provider_reference` columns. Add a Paystack/Flutterwave webhook as an Edge Function that calls the same status update server-side.

## Test checklist
Sign up · log in/out · password reset · browse services · create order with files · view order · admin changes status (customer gets notification + timeline entry) · customer uploads payment proof · admin verifies · customer cannot open `/admin` or another customer's order URL · WhatsApp buttons open a pre-filled chat · layouts at 360, 390, 430, 768, 1024, 1440 px · install to Android home screen.
