-- =====================================================================
-- Uamer Design Hub  |  Uamer Feruak SR
-- Run this whole file once in Supabase: SQL Editor > New query > Run
-- =====================================================================

create extension if not exists "pgcrypto";

-- ---------- ENUMS ----------
do $$ begin
  create type user_role as enum ('customer','admin');
exception when duplicate_object then null; end $$;
do $$ begin
  create type order_status as enum ('Pending','In Progress','Review','Completed','Cancelled');
exception when duplicate_object then null; end $$;
do $$ begin
  create type payment_status as enum ('Unpaid','Pending Verification','Paid','Refunded');
exception when duplicate_object then null; end $$;
do $$ begin
  create type payment_method as enum ('Bank Transfer','Other');
exception when duplicate_object then null; end $$;

-- ---------- TABLES ----------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  email text,
  whatsapp text,
  role user_role not null default 'customer',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.services (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  description text not null default '',
  icon text not null default 'Sparkles',
  is_active boolean not null default true,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number bigint generated always as identity,
  customer_id uuid not null references public.profiles(id) on delete cascade,
  service_id uuid not null references public.services(id) on delete restrict,
  customer_name text not null,
  customer_whatsapp text not null,
  customer_email text,
  project_title text not null,
  description text not null,
  deadline date,
  additional_notes text,
  admin_notes text,
  status order_status not null default 'Pending',
  payment_status payment_status not null default 'Unpaid',
  payment_method payment_method,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists orders_customer_idx on public.orders(customer_id);
create index if not exists orders_service_idx on public.orders(service_id);
create index if not exists orders_status_idx on public.orders(status);
create index if not exists orders_created_idx on public.orders(created_at desc);

create table if not exists public.order_files (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  uploaded_by uuid not null references public.profiles(id) on delete cascade,
  kind text not null default 'attachment' check (kind in ('attachment','payment_proof')),
  storage_path text not null,
  file_name text not null,
  mime_type text,
  size_bytes bigint,
  created_at timestamptz not null default now()
);
create index if not exists order_files_order_idx on public.order_files(order_id);

create table if not exists public.order_status_history (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  status order_status not null,
  note text,
  changed_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);
create index if not exists osh_order_idx on public.order_status_history(order_id, created_at);

create table if not exists public.order_messages (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  is_admin boolean not null default false,
  body text not null,
  created_at timestamptz not null default now()
);
create index if not exists om_order_idx on public.order_messages(order_id, created_at);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  method payment_method not null default 'Bank Transfer',
  amount numeric(12,2),
  reference text,
  proof_file_id uuid references public.order_files(id) on delete set null,
  status payment_status not null default 'Pending Verification',
  provider text,                 -- reserved for future Nigerian payment provider
  provider_reference text,       -- reserved for future integration
  verified_by uuid references public.profiles(id) on delete set null,
  verified_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists payments_order_idx on public.payments(order_id);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  body text,
  link text,
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists notif_user_idx on public.notifications(user_id, is_read, created_at desc);

create table if not exists public.settings (
  key text primary key,
  value text not null default '',
  updated_at timestamptz not null default now()
);

-- ---------- HELPERS ----------
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;

create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

drop trigger if exists trg_profiles_touch on public.profiles;
create trigger trg_profiles_touch before update on public.profiles
  for each row execute function public.touch_updated_at();
drop trigger if exists trg_orders_touch on public.orders;
create trigger trg_orders_touch before update on public.orders
  for each row execute function public.touch_updated_at();

-- Create profile automatically on sign-up (role is ALWAYS customer here)
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name, email, whatsapp, role)
  values (new.id,
          coalesce(new.raw_user_meta_data->>'full_name',''),
          new.email,
          new.raw_user_meta_data->>'whatsapp',
          'customer');
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Block role changes by non-admins (and by anyone via the API except admins)
create or replace function public.protect_role()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.role is distinct from old.role and not public.is_admin() then
    -- allow SQL editor / service role (auth.uid() is null there)
    if auth.uid() is not null then
      raise exception 'Not allowed to change role';
    end if;
  end if;
  return new;
end $$;
drop trigger if exists trg_protect_role on public.profiles;
create trigger trg_protect_role before update on public.profiles
  for each row execute function public.protect_role();

-- Notify admins helper
create or replace function public.notify_admins(p_title text, p_body text, p_link text)
returns void language plpgsql security definer set search_path = public as $$
begin
  insert into public.notifications (user_id, title, body, link)
  select id, p_title, p_body, p_link from public.profiles where role = 'admin';
end $$;

-- On new order: history row + notifications
create or replace function public.on_order_created()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.order_status_history (order_id, status, note, changed_by)
  values (new.id, 'Pending', 'Order submitted', new.customer_id);
  insert into public.notifications (user_id, title, body, link)
  values (new.customer_id, 'Order submitted',
          'Your order #' || new.order_number || ' (' || new.project_title || ') was received.',
          '/dashboard/orders/' || new.id);
  perform public.notify_admins('New order #' || new.order_number,
          new.project_title || ' from ' || new.customer_name,
          '/admin/orders/' || new.id);
  return new;
end $$;
drop trigger if exists trg_order_created on public.orders;
create trigger trg_order_created after insert on public.orders
  for each row execute function public.on_order_created();

-- On status / payment change: history + customer notification
create or replace function public.on_order_updated()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.status is distinct from old.status then
    insert into public.order_status_history (order_id, status, note, changed_by)
    values (new.id, new.status, null, auth.uid());
    insert into public.notifications (user_id, title, body, link)
    values (new.customer_id,
            case when new.status = 'Completed' then 'Order completed' else 'Order status updated' end,
            'Order #' || new.order_number || ' is now ' || new.status || '.',
            '/dashboard/orders/' || new.id);
  end if;
  if new.payment_status is distinct from old.payment_status and new.payment_status = 'Paid' then
    insert into public.notifications (user_id, title, body, link)
    values (new.customer_id, 'Payment verified',
            'Payment for order #' || new.order_number || ' has been verified.',
            '/dashboard/orders/' || new.id);
  end if;
  return new;
end $$;
drop trigger if exists trg_order_updated on public.orders;
create trigger trg_order_updated after update on public.orders
  for each row execute function public.on_order_updated();

-- On message: notify the other side
create or replace function public.on_message_created()
returns trigger language plpgsql security definer set search_path = public as $$
declare o record;
begin
  select * into o from public.orders where id = new.order_id;
  if new.is_admin then
    insert into public.notifications (user_id, title, body, link)
    values (o.customer_id, 'Update on order #' || o.order_number, left(new.body, 140),
            '/dashboard/orders/' || o.id);
  else
    perform public.notify_admins('Customer message on order #' || o.order_number,
            left(new.body, 140), '/admin/orders/' || o.id);
  end if;
  return new;
end $$;
drop trigger if exists trg_message_created on public.order_messages;
create trigger trg_message_created after insert on public.order_messages
  for each row execute function public.on_message_created();

-- On file upload: notify admins (additional files / payment proof)
create or replace function public.on_file_created()
returns trigger language plpgsql security definer set search_path = public as $$
declare o record;
begin
  select * into o from public.orders where id = new.order_id;
  if new.kind = 'payment_proof' then
    perform public.notify_admins('Payment proof uploaded',
      'Order #' || o.order_number, '/admin/orders/' || o.id);
  elsif o.created_at < now() - interval '1 minute' then
    perform public.notify_admins('Additional file uploaded',
      'Order #' || o.order_number, '/admin/orders/' || o.id);
  end if;
  return new;
end $$;
drop trigger if exists trg_file_created on public.order_files;
create trigger trg_file_created after insert on public.order_files
  for each row execute function public.on_file_created();

-- Customers may only submit proof through this function (cannot set Paid)
create or replace function public.submit_payment_proof(
  p_order_id uuid, p_file_id uuid, p_method payment_method, p_reference text)
returns void language plpgsql security definer set search_path = public as $$
declare o record;
begin
  select * into o from public.orders where id = p_order_id and customer_id = auth.uid();
  if not found then raise exception 'Order not found'; end if;
  if o.payment_status = 'Paid' then raise exception 'Already paid'; end if;
  insert into public.payments (order_id, method, reference, proof_file_id, status)
  values (p_order_id, p_method, p_reference, p_file_id, 'Pending Verification');
  update public.orders set payment_status = 'Pending Verification', payment_method = p_method
  where id = p_order_id;
end $$;

-- Admin verifies / rejects payment
create or replace function public.verify_payment(p_payment_id uuid, p_status payment_status)
returns void language plpgsql security definer set search_path = public as $$
declare p record;
begin
  if not public.is_admin() then raise exception 'Not allowed'; end if;
  select * into p from public.payments where id = p_payment_id;
  if not found then raise exception 'Payment not found'; end if;
  update public.payments set status = p_status, verified_by = auth.uid(), verified_at = now()
  where id = p_payment_id;
  update public.orders set payment_status = p_status where id = p.order_id;
end $$;

-- ---------- ROW LEVEL SECURITY ----------
alter table public.profiles enable row level security;
alter table public.services enable row level security;
alter table public.orders enable row level security;
alter table public.order_files enable row level security;
alter table public.order_status_history enable row level security;
alter table public.order_messages enable row level security;
alter table public.payments enable row level security;
alter table public.notifications enable row level security;
alter table public.settings enable row level security;

-- profiles
drop policy if exists "profiles_select" on public.profiles;
create policy "profiles_select" on public.profiles for select
  using (id = auth.uid() or public.is_admin());
drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own" on public.profiles for update
  using (id = auth.uid() or public.is_admin()) with check (id = auth.uid() or public.is_admin());

-- services: public can read active ones, admin full control
drop policy if exists "services_select" on public.services;
create policy "services_select" on public.services for select
  using (is_active or public.is_admin());
drop policy if exists "services_admin_all" on public.services;
create policy "services_admin_all" on public.services for all
  using (public.is_admin()) with check (public.is_admin());

-- orders
drop policy if exists "orders_select" on public.orders;
create policy "orders_select" on public.orders for select
  using (customer_id = auth.uid() or public.is_admin());
drop policy if exists "orders_insert_own" on public.orders;
create policy "orders_insert_own" on public.orders for insert
  with check (customer_id = auth.uid() and status = 'Pending' and payment_status = 'Unpaid');
drop policy if exists "orders_update_admin" on public.orders;
create policy "orders_update_admin" on public.orders for update
  using (public.is_admin()) with check (public.is_admin());

-- order_files
drop policy if exists "files_select" on public.order_files;
create policy "files_select" on public.order_files for select
  using (public.is_admin() or exists
    (select 1 from public.orders o where o.id = order_id and o.customer_id = auth.uid()));
drop policy if exists "files_insert" on public.order_files;
create policy "files_insert" on public.order_files for insert
  with check (uploaded_by = auth.uid() and (public.is_admin() or exists
    (select 1 from public.orders o where o.id = order_id and o.customer_id = auth.uid())));

-- history
drop policy if exists "history_select" on public.order_status_history;
create policy "history_select" on public.order_status_history for select
  using (public.is_admin() or exists
    (select 1 from public.orders o where o.id = order_id and o.customer_id = auth.uid()));

-- messages
drop policy if exists "messages_select" on public.order_messages;
create policy "messages_select" on public.order_messages for select
  using (public.is_admin() or exists
    (select 1 from public.orders o where o.id = order_id and o.customer_id = auth.uid()));
drop policy if exists "messages_insert" on public.order_messages;
create policy "messages_insert" on public.order_messages for insert
  with check (sender_id = auth.uid() and (
    (is_admin and public.is_admin()) or
    (not is_admin and exists (select 1 from public.orders o where o.id = order_id and o.customer_id = auth.uid()))));

-- payments (customers read only; writes go through functions)
drop policy if exists "payments_select" on public.payments;
create policy "payments_select" on public.payments for select
  using (public.is_admin() or exists
    (select 1 from public.orders o where o.id = order_id and o.customer_id = auth.uid()));

-- notifications
drop policy if exists "notif_select" on public.notifications;
create policy "notif_select" on public.notifications for select using (user_id = auth.uid());
drop policy if exists "notif_update" on public.notifications;
create policy "notif_update" on public.notifications for update
  using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists "notif_delete" on public.notifications;
create policy "notif_delete" on public.notifications for delete using (user_id = auth.uid());

-- settings: public read, admin write
drop policy if exists "settings_select" on public.settings;
create policy "settings_select" on public.settings for select using (true);
drop policy if exists "settings_admin" on public.settings;
create policy "settings_admin" on public.settings for all
  using (public.is_admin()) with check (public.is_admin());

-- ---------- STORAGE ----------
-- Private bucket for order files. Path convention: <order_id>/<random>-<filename>
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('order-files','order-files', false, 26214400,
        array['image/jpeg','image/png','image/webp','application/pdf','video/mp4'])
on conflict (id) do update set public = false;

-- Public bucket just for the business logo (not sensitive)
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('branding','branding', true, 2097152, array['image/jpeg','image/png','image/webp','image/svg+xml'])
on conflict (id) do nothing;

drop policy if exists "order_files_read" on storage.objects;
create policy "order_files_read" on storage.objects for select
  using (bucket_id = 'order-files' and (public.is_admin() or exists (
    select 1 from public.orders o
    where o.id::text = (storage.foldername(name))[1] and o.customer_id = auth.uid())));

drop policy if exists "order_files_insert" on storage.objects;
create policy "order_files_insert" on storage.objects for insert
  with check (bucket_id = 'order-files' and (public.is_admin() or exists (
    select 1 from public.orders o
    where o.id::text = (storage.foldername(name))[1] and o.customer_id = auth.uid())));

drop policy if exists "order_files_admin_delete" on storage.objects;
create policy "order_files_admin_delete" on storage.objects for delete
  using (bucket_id = 'order-files' and public.is_admin());

drop policy if exists "branding_read" on storage.objects;
create policy "branding_read" on storage.objects for select using (bucket_id = 'branding');
drop policy if exists "branding_admin_write" on storage.objects;
create policy "branding_admin_write" on storage.objects for all
  using (bucket_id = 'branding' and public.is_admin())
  with check (bucket_id = 'branding' and public.is_admin());

-- ---------- REALTIME (in-app notifications) ----------
do $$ begin
  alter publication supabase_realtime add table public.notifications;
exception when others then null; end $$;

-- ---------- SEED: services + default settings only ----------
insert into public.services (name, description, icon, sort_order) values
 ('Poster Design','Eye-catching posters for events, promotions and brands.','Palette',1),
 ('Banner Design','Print and web banners that get noticed.','Flag',2),
 ('Invitation Card Design','Elegant invitation cards for weddings, parties and events.','Mail',3),
 ('Photo Editing','Retouching, colour correction and background removal.','Image',4),
 ('Video Editing','Clean, engaging edits for ads, events and social media.','Video',5),
 ('Website Design & Development','Modern, fast, mobile-friendly websites for your business.','Globe',6),
 ('Business Advertisement','Complete ad creatives that help your business grow.','Megaphone',7),
 ('Social Media Design','Consistent, scroll-stopping social media graphics.','Share2',8)
on conflict (name) do nothing;

insert into public.settings (key, value) values
 ('business_name','Uamer Feruak SR'),
 ('whatsapp_number','+2348149617851'),
 ('phone_number','+2348149538264'),
 ('business_description','Professional graphic design, photo editing, video editing and website development.'),
 ('logo_url',''),
 ('contact_info','Azare, Bauchi State, Nigeria'),
 ('bank_details','Bank transfer details will be shared by Uamer Feruak SR on WhatsApp.')
on conflict (key) do nothing;
