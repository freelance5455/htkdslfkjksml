/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#f1efff', 100: '#e4e0ff', 200: '#c9c0ff', 300: '#a99bff', 400: '#8570ff',
          500: '#6a4cff', 600: '#5632f0', 700: '#4524cc', 800: '#2f1a8f', 900: '#1d1166',
        },
        gold: { 400: '#ffd93a', 500: '#fbc90d', 600: '#e0ad00' },
      },
      fontFamily: { sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'] },
      boxShadow: { card: '0 8px 30px -12px rgba(69,36,204,.25)' },
      keyframes: {
        fadeUp: { '0%': { opacity: 0, transform: 'translateY(12px)' }, '100%': { opacity: 1, transform: 'none' } },
      },
      animation: { fadeUp: 'fadeUp .5s ease both' },
    },
  },
  plugins: [],
};
