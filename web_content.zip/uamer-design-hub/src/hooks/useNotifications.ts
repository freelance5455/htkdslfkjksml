import { useCallback, useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { listNotifications } from '../services/api';
import type { AppNotification } from '../types';

/** Loads the signed-in user's notifications and keeps them live via Supabase Realtime. */
export function useNotifications(userId?: string) {
  const [items, setItems] = useState<AppNotification[]>([]);
  const [loading, setLoading] = useState(true);

  const reload = useCallback(async () => {
    if (!userId) { setItems([]); setLoading(false); return; }
    try { setItems(await listNotifications(userId)); } catch (e) { console.error(e); }
    setLoading(false);
  }, [userId]);

  useEffect(() => {
    reload();
    if (!userId) return;
    const ch = supabase.channel(`notif-${userId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'notifications', filter: `user_id=eq.${userId}` }, () => reload())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [userId, reload]);

  return { items, loading, unread: items.filter((n) => !n.is_read).length, reload };
}
