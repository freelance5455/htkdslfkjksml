import { useEffect, useState } from 'react';
import { isConfigured } from '../lib/supabase';
import { listServices } from '../services/api';
import type { Service } from '../types';

/** Active services for public pages, loaded from the database. */
export function useServicesList() {
  const [services, setServices] = useState<Service[]>([]);
  useEffect(() => {
    if (!isConfigured) return;
    listServices().then(setServices).catch((e) => console.error(e));
  }, []);
  return services;
}
