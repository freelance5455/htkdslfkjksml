import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { isConfigured } from '../lib/supabase';
import { getSettings } from '../services/api';
import { DEFAULT_PHONE, DEFAULT_WHATSAPP } from '../lib/utils';
import type { Settings } from '../types';

const FALLBACK: Settings = {
  business_name: 'Uamer Feruak SR',
  whatsapp_number: DEFAULT_WHATSAPP,
  phone_number: DEFAULT_PHONE,
  business_description: 'Professional graphic design, photo editing, video editing and website development.',
  logo_url: '',
  contact_info: 'Azare, Bauchi State, Nigeria',
  bank_details: '',
};

interface SettingsState { settings: Settings; reload: () => Promise<void>; }
const Ctx = createContext<SettingsState>({ settings: FALLBACK, reload: async () => {} });

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<Settings>(FALLBACK);
  const reload = useCallback(async () => {
    if (!isConfigured) return;
    try {
      const s = await getSettings();
      setSettings({ ...FALLBACK, ...Object.fromEntries(Object.entries(s).filter(([, v]) => v !== '')) , logo_url: s.logo_url ?? '', bank_details: s.bank_details ?? '' });
    } catch (e) { console.error(e); }
  }, []);
  useEffect(() => { reload(); }, [reload]);
  const value = useMemo(() => ({ settings, reload }), [settings, reload]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
export const useSettings = () => useContext(Ctx);
