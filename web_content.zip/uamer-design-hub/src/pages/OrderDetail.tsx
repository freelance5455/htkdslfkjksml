import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { useAsync } from '../hooks/useAsync';
import { useSettings } from '../hooks/useSettings';
import {
  getOrder, listHistory, listMessages, listOrderFiles, listPayments, submitPaymentProof, uploadOrderFile,
} from '../services/api';
import { ErrorBox, ListSkeleton, PaymentBadge, StatusBadge, WhatsAppButton } from '../components/ui';
import { FilesList, MessageThread, Timeline } from '../components/OrderParts';
import FileUploader from '../components/FileUploader';
import { formatDate, friendlyError } from '../lib/utils';
import type { PaymentMethod } from '../types';

export default function OrderDetail() {
  const { id = '' } = useParams();
  const { session } = useAuth();
  const { settings } = useSettings();
  const uid = session!.user.id;

  const order = useAsync(() => getOrder(id), [id]);
  const files = useAsync(() => listOrderFiles(id), [id]);
  const history = useAsync(() => listHistory(id), [id]);
  const messages = useAsync(() => listMessages(id), [id]);
  const payments = useAsync(() => listPayments(id), [id]);

  const [extra, setExtra] = useState<File[]>([]);
  const [proof, setProof] = useState<File[]>([]);
  const [method, setMethod] = useState<PaymentMethod>('Bank Transfer');
  const [ref, setRef] = useState('');
  const [progress, setProgress] = useState<Record<string, number>>({});
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  async function addFiles() {
    setBusy(true); setMsg(null);
    try {
      for (const f of extra) await uploadOrderFile(id, uid, f, 'attachment', (p) => setProgress((s) => ({ ...s, [f.name]: p })));
      setExtra([]); setProgress({}); files.reload();
      setMsg({ ok: true, text: 'Files uploaded.' });
    } catch (e) { setMsg({ ok: false, text: friendlyError(e, 'Upload failed. Please try again.') }); }
    setBusy(false);
  }

  async function sendProof() {
    if (proof.length === 0) return setMsg({ ok: false, text: 'Please choose your payment proof first.' });
    setBusy(true); setMsg(null);
    try {
      const f = await uploadOrderFile(id, uid, proof[0], 'payment_proof', (p) => setProgress((s) => ({ ...s, [proof[0].name]: p })));
      await submitPaymentProof(id, f.id, method, ref.trim());
      setProof([]); setRef(''); setProgress({});
      order.reload(); files.reload(); payments.reload();
      setMsg({ ok: true, text: 'Payment proof sent. We will verify it and update your order.' });
    } catch (e) { setMsg({ ok: false, text: friendlyError(e, 'Could not send payment proof. Please try again.') }); }
    setBusy(false);
  }

  if (order.loading) return <div className="mx-auto max-w-3xl p-4"><ListSkeleton rows={4} /></div>;
  if (order.error) return <div className="mx-auto max-w-3xl p-4"><ErrorBox message={order.error} onRetry={order.reload} /></div>;
  const o = order.data;
  if (!o) return (
    <div className="mx-auto max-w-md p-10 text-center">
      <h1 className="text-xl font-extrabold">Order not found</h1>
      <p className="mt-2 text-sm text-slate-500">This order does not exist or you do not have access to it.</p>
      <Link to="/dashboard" className="btn-primary mt-4">Back to dashboard</Link>
    </div>
  );

  const canPay = o.payment_status === 'Unpaid' || o.payment_status === 'Pending Verification';
  const waMsg = `Hello Uamer Feruak SR, I'm writing about Order #${o.order_number} (${o.services?.name}).`;

  return (
    <div className="mx-auto max-w-3xl space-y-4 px-4 py-6">
      <Link to="/dashboard" className="inline-flex items-center gap-1 text-sm text-brand-600"><ArrowLeft className="h-4 w-4" /> Back to orders</Link>

      <section className="card">
        <div className="flex items-start justify-between gap-2">
          <div><p className="text-xs font-semibold text-brand-600">Order #{o.order_number}</p><h1 className="text-xl font-extrabold">{o.project_title}</h1></div>
          <div className="flex flex-col items-end gap-1"><StatusBadge status={o.status} /><PaymentBadge status={o.payment_status} /></div>
        </div>
        <dl className="mt-4 grid gap-2 text-sm sm:grid-cols-2">
          <div><dt className="text-slate-500">Service</dt><dd className="font-medium">{o.services?.name}</dd></div>
          <div><dt className="text-slate-500">Submitted</dt><dd className="font-medium">{formatDate(o.created_at, true)}</dd></div>
          <div><dt className="text-slate-500">Preferred deadline</dt><dd className="font-medium">{formatDate(o.deadline)}</dd></div>
          <div><dt className="text-slate-500">WhatsApp</dt><dd className="font-medium">{o.customer_whatsapp}</dd></div>
        </dl>
        <p className="mt-4 whitespace-pre-wrap text-sm">{o.description}</p>
        {o.additional_notes && <p className="mt-2 whitespace-pre-wrap rounded-lg bg-slate-50 p-3 text-sm text-slate-600">{o.additional_notes}</p>}
        <div className="mt-4"><WhatsAppButton message={waMsg} label="Message us about this order" /></div>
      </section>

      {msg && <p role={msg.ok ? 'status' : 'alert'} className={`rounded-lg p-3 text-sm ${msg.ok ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>{msg.text}</p>}

      <section className="card">
        <h2 className="mb-3 font-bold">Uploaded files</h2>
        {files.loading ? <ListSkeleton rows={1} /> : <FilesList files={files.data ?? []} />}
        {o.status !== 'Cancelled' && o.status !== 'Completed' && (
          <div className="mt-4 space-y-2">
            <FileUploader files={extra} onChange={setExtra} progress={progress} label="Add more files" />
            {extra.length > 0 && <button onClick={addFiles} disabled={busy} className="btn-primary w-full">{busy ? 'Uploading…' : 'Upload files'}</button>}
          </div>
        )}
      </section>

      <section className="card">
        <h2 className="mb-3 font-bold">Payment</h2>
        <p className="mb-3 text-sm">Status: <PaymentBadge status={o.payment_status} /></p>
        {settings.bank_details && <p className="mb-3 whitespace-pre-wrap rounded-lg bg-brand-50 p-3 text-sm">{settings.bank_details}</p>}
        <p className="mb-3 text-xs text-slate-500">Payments are verified manually by Uamer Feruak SR after you send proof. Your status only changes to Paid once it has been checked.</p>
        {(payments.data ?? []).length > 0 && (
          <ul className="mb-3 space-y-1 text-sm">
            {payments.data!.map((p) => <li key={p.id} className="flex justify-between"><span>{p.method} · {formatDate(p.created_at)}</span><PaymentBadge status={p.status} /></li>)}
          </ul>
        )}
        {canPay && (
          <div className="space-y-3">
            <div><label className="label" htmlFor="pm">Payment method</label>
              <select id="pm" className="input" value={method} onChange={(e) => setMethod(e.target.value as PaymentMethod)}><option>Bank Transfer</option><option>Other</option></select></div>
            <div><label className="label" htmlFor="pr">Reference (optional)</label><input id="pr" className="input" value={ref} onChange={(e) => setRef(e.target.value)} placeholder="Transfer reference or note" /></div>
            <FileUploader files={proof} onChange={setProof} multiple={false} progress={progress} label="Upload payment proof" />
            <button onClick={sendProof} disabled={busy} className="btn-gold w-full">{busy ? 'Sending…' : 'Send payment proof'}</button>
          </div>
        )}
      </section>

      <section className="card"><h2 className="mb-3 font-bold">Updates & messages</h2>
        <MessageThread orderId={id} userId={uid} isAdmin={false} messages={messages.data ?? []} onSent={messages.reload} /></section>

      <section className="card"><h2 className="mb-3 font-bold">Timeline</h2>
        {history.loading ? <ListSkeleton rows={2} /> : <Timeline items={history.data ?? []} />}</section>
    </div>
  );
}
