import { useState, type FormEvent, type ReactNode } from 'react';
import { Link, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { friendlyError, isValidPhone } from '../lib/utils';
import { Logo } from '../components/ui';

function Shell({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="mx-auto max-w-md px-4 py-10">
      <div className="mb-6 flex justify-center"><Logo size="lg" /></div>
      <div className="card p-6">
        <h1 className="mb-4 text-xl font-extrabold text-slate-900">{title}</h1>
        {children}
      </div>
    </div>
  );
}
function Msg({ error, ok }: { error?: string; ok?: string }) {
  if (error) return <p role="alert" className="mb-3 rounded-lg bg-red-50 p-3 text-sm text-red-700">{error}</p>;
  if (ok) return <p role="status" className="mb-3 rounded-lg bg-green-50 p-3 text-sm text-green-700">{ok}</p>;
  return null;
}

export function Login() {
  const { session, isAdmin, profile } = useAuth();
  const nav = useNavigate();
  const loc = useLocation();
  const from = (loc.state as { from?: string } | null)?.from;
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  if (session && profile) return <Navigate to={from ?? (isAdmin ? '/admin' : '/dashboard')} replace />;

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError(''); setBusy(true);
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    setBusy(false);
    if (error) setError(friendlyError(error, 'Could not log in. Please try again.'));
    else nav(from ?? '/dashboard', { replace: true });
  }

  return (
    <Shell title="Welcome back">
      <Msg error={error} />
      <form onSubmit={submit} className="space-y-4">
        <div><label className="label" htmlFor="email">Email</label><input id="email" type="email" required autoComplete="email" className="input" value={email} onChange={(e) => setEmail(e.target.value)} /></div>
        <div><label className="label" htmlFor="pw">Password</label><input id="pw" type="password" required autoComplete="current-password" className="input" value={password} onChange={(e) => setPassword(e.target.value)} /></div>
        <button className="btn-primary w-full" disabled={busy}>{busy ? 'Logging in…' : 'Login'}</button>
      </form>
      <div className="mt-4 flex justify-between text-sm">
        <Link to="/forgot-password" className="text-brand-600">Forgot password?</Link>
        <Link to="/signup" className="font-semibold text-brand-600">Create account</Link>
      </div>
    </Shell>
  );
}

export function Signup() {
  const { session } = useAuth();
  const [f, setF] = useState({ name: '', whatsapp: '', email: '', password: '' });
  const [error, setError] = useState('');
  const [ok, setOk] = useState('');
  const [busy, setBusy] = useState(false);
  if (session) return <Navigate to="/dashboard" replace />;

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError(''); setOk('');
    if (f.name.trim().length < 2) return setError('Please enter your full name.');
    if (!isValidPhone(f.whatsapp)) return setError('Enter a valid WhatsApp number, e.g. +2348012345678.');
    if (f.password.length < 8) return setError('Password must be at least 8 characters.');
    setBusy(true);
    const { data, error } = await supabase.auth.signUp({
      email: f.email.trim(), password: f.password,
      options: { data: { full_name: f.name.trim(), whatsapp: f.whatsapp.trim() }, emailRedirectTo: window.location.origin + '/login' },
    });
    setBusy(false);
    if (error) return setError(friendlyError(error, 'Could not create your account. Please try again.'));
    if (!data.session) setOk('Account created. Check your email to confirm your address, then log in.');
  }

  return (
    <Shell title="Create your account">
      <Msg error={error} ok={ok} />
      <form onSubmit={submit} className="space-y-4">
        <div><label className="label" htmlFor="n">Full name</label><input id="n" required autoComplete="name" className="input" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></div>
        <div><label className="label" htmlFor="w">WhatsApp number</label><input id="w" type="tel" required autoComplete="tel" placeholder="+234…" className="input" value={f.whatsapp} onChange={(e) => setF({ ...f, whatsapp: e.target.value })} /></div>
        <div><label className="label" htmlFor="e">Email</label><input id="e" type="email" required autoComplete="email" className="input" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></div>
        <div><label className="label" htmlFor="p">Password</label><input id="p" type="password" required minLength={8} autoComplete="new-password" className="input" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} /></div>
        <button className="btn-primary w-full" disabled={busy}>{busy ? 'Creating…' : 'Sign up'}</button>
      </form>
      <p className="mt-4 text-center text-sm">Already have an account? <Link to="/login" className="font-semibold text-brand-600">Login</Link></p>
    </Shell>
  );
}

export function ForgotPassword() {
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [ok, setOk] = useState('');
  const [busy, setBusy] = useState(false);
  async function submit(e: FormEvent) {
    e.preventDefault();
    setError(''); setOk(''); setBusy(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), { redirectTo: window.location.origin + '/reset-password' });
    setBusy(false);
    if (error) setError(friendlyError(error)); else setOk('If that email has an account, a reset link is on its way.');
  }
  return (
    <Shell title="Reset your password">
      <Msg error={error} ok={ok} />
      <form onSubmit={submit} className="space-y-4">
        <div><label className="label" htmlFor="fe">Email</label><input id="fe" type="email" required className="input" value={email} onChange={(e) => setEmail(e.target.value)} /></div>
        <button className="btn-primary w-full" disabled={busy}>{busy ? 'Sending…' : 'Send reset link'}</button>
      </form>
      <p className="mt-4 text-center text-sm"><Link to="/login" className="text-brand-600">Back to login</Link></p>
    </Shell>
  );
}

export function ResetPassword() {
  const nav = useNavigate();
  const { session } = useAuth();
  const [pw, setPw] = useState('');
  const [error, setError] = useState('');
  const [ok, setOk] = useState('');
  const [busy, setBusy] = useState(false);
  async function submit(e: FormEvent) {
    e.preventDefault();
    setError('');
    if (pw.length < 8) return setError('Password must be at least 8 characters.');
    setBusy(true);
    const { error } = await supabase.auth.updateUser({ password: pw });
    setBusy(false);
    if (error) return setError(friendlyError(error));
    setOk('Password updated. Redirecting…');
    setTimeout(() => nav('/dashboard'), 1200);
  }
  return (
    <Shell title="Choose a new password">
      <Msg error={error} ok={ok} />
      {!session ? <p className="text-sm text-slate-600">Open the reset link from your email to continue.</p> : (
        <form onSubmit={submit} className="space-y-4">
          <div><label className="label" htmlFor="np">New password</label><input id="np" type="password" minLength={8} required autoComplete="new-password" className="input" value={pw} onChange={(e) => setPw(e.target.value)} /></div>
          <button className="btn-primary w-full" disabled={busy}>{busy ? 'Saving…' : 'Update password'}</button>
        </form>
      )}
    </Shell>
  );
}
