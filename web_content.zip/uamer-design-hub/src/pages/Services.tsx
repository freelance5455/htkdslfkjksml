import { Link } from 'react-router-dom';
import { useAsync } from '../hooks/useAsync';
import { listServices } from '../services/api';
import { EmptyState, ErrorBox, PageTitle } from '../components/ui';
import { ServiceCardSkeleton } from '../components/ServiceBits';
import { ServiceIcon } from '../lib/icons';

export default function ServicesPage() {
  const { data, loading, error, reload } = useAsync(() => listServices(), []);
  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <PageTitle title="Our Services" sub="Choose a service to start your order." />
      {loading && <ServiceCardSkeleton />}
      {error && <ErrorBox message={error} onRetry={reload} />}
      {data && data.length === 0 && <EmptyState title="No services available right now." text="Please check back soon." />}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {data?.map((s) => (
          <article key={s.id} className="card flex flex-col transition hover:-translate-y-1">
            <span className="mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-brand-50 text-brand-600"><ServiceIcon name={s.icon} className="h-6 w-6" /></span>
            <h2 className="text-lg font-bold">{s.name}</h2>
            <p className="mt-1 flex-1 text-sm text-slate-500">{s.description}</p>
            <Link to={`/order?service=${s.id}`} className="btn-primary mt-4">Order</Link>
          </article>
        ))}
      </div>
    </div>
  );
}
