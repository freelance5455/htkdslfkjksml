import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAsync } from '../../hooks/useAsync';
import { listPayments, verifyPayment } from '../../services/api';
import { EmptyState, ErrorBox, ListSkeleton, PageTitle, PaymentBadge } from '../../components/ui';
import { formatDate, friendlyError } from '../../lib/utils';

export default function AdminPayments() {
  const { data, loading, error, reload } = useAsync(() => listPayments(), []);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  async function act(id: string, status: 'Paid' | 'Unpaid') {
    setBusy(true); setMsg(null);
    try { await verifyPayment(id, status); reload(); setMsg({ ok: true, text: status === 'Paid' ? 'Payment verified.' : 'Payment proof rejected.' }); }
    catch (e) { setMsg({ ok: false, text: friendlyError(e) }); }
    setBusy(false);
  }

  return (
    <>
      <PageTitle title="Payments" sub="Payments are verified manually. Open the order to view the payment proof file." />
      {msg && <p role={msg.ok ? 'status' : 'alert'} className={`mb-3 rounded-lg p-3 text-sm ${msg.ok ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>{msg.text}</p>}
      {loading && <ListSkeleton />}
      {error && <ErrorBox message={error} onRetry={reload} />}
      {data && data.length === 0 && <EmptyState title="No payments yet." text="Payment proofs from customers will appear here." />}
      <ul className="space-y-3">
        {data?.map((p) => (
          <li key={p.id} className="card">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0"><Link to={`/admin/orders/${p.order_id}`} className="text-xs font-semibold text-brand-600 underline">Order #{p.orders?.order_number}</Link>
                <p className="truncate font-bold">{p.orders?.project_title}</p><p className="text-sm text-slate-500">{p.orders?.customer_name} · {p.method} · {formatDate(p.created_at, true)}</p>
                {p.reference && <p className="text-sm text-slate-600">Ref: {p.reference}</p>}</div>
              <PaymentBadge status={p.status} />
            </div>
            {p.status === 'Pending Verification' && (
              <div className="mt-3 flex gap-2">
                <button className="btn-primary !py-2" disabled={busy} onClick={() => act(p.id, 'Paid')}>Verify as Paid</button>
                <button className="btn-outline !py-2" disabled={busy} onClick={() => act(p.id, 'Unpaid')}>Reject</button>
              </div>
            )}
          </li>
        ))}
      </ul>
    </>
  );
}
