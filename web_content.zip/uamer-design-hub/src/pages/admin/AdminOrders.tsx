import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Search } from 'lucide-react';
import { useAsync } from '../../hooks/useAsync';
import { listAllOrders, listServices } from '../../services/api';
import { EmptyState, ErrorBox, ListSkeleton, PageTitle, PaymentBadge, StatusBadge } from '../../components/ui';
import { formatDate } from '../../lib/utils';
import { ORDER_STATUSES } from '../../types';

export default function AdminOrders() {
  const orders = useAsync(() => listAllOrders(), []);
  const services = useAsync(() => listServices(true), []);
  const [q, setQ] = useState('');
  const [status, setStatus] = useState('');
  const [service, setService] = useState('');

  const rows = useMemo(() => {
    const t = q.trim().toLowerCase();
    return (orders.data ?? []).filter((o) =>
      (!status || o.status === status) && (!service || o.service_id === service) &&
      (!t || [String(o.order_number), o.project_title, o.customer_name, o.customer_whatsapp, o.customer_email ?? ''].some((v) => v.toLowerCase().includes(t))));
  }, [orders.data, q, status, service]);

  return (
    <>
      <PageTitle title="Orders" sub={`${rows.length} order${rows.length === 1 ? '' : 's'}`} />
      <div className="card mb-4 grid gap-3 md:grid-cols-3">
        <div className="relative"><Search className="absolute left-3 top-3.5 h-4 w-4 text-slate-400" aria-hidden="true" />
          <label htmlFor="s" className="sr-only">Search orders</label>
          <input id="s" className="input pl-9" placeholder="Search order #, title, customer…" value={q} onChange={(e) => setQ(e.target.value)} /></div>
        <div><label htmlFor="fs" className="sr-only">Filter by status</label>
          <select id="fs" className="input" value={status} onChange={(e) => setStatus(e.target.value)}><option value="">All statuses</option>{ORDER_STATUSES.map((s) => <option key={s}>{s}</option>)}</select></div>
        <div><label htmlFor="fv" className="sr-only">Filter by service</label>
          <select id="fv" className="input" value={service} onChange={(e) => setService(e.target.value)}><option value="">All services</option>{services.data?.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select></div>
      </div>
      {orders.loading && <ListSkeleton rows={4} />}
      {orders.error && <ErrorBox message={orders.error} onRetry={orders.reload} />}
      {!orders.loading && rows.length === 0 && <EmptyState title="No orders found." text="Try changing your search or filters." />}
      <ul className="space-y-3">
        {rows.map((o) => (
          <li key={o.id}><Link to={`/admin/orders/${o.id}`} className="card block transition hover:-translate-y-0.5">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0"><p className="text-xs font-semibold text-brand-600">#{o.order_number} · {o.services?.name}</p>
                <p className="truncate font-bold">{o.project_title}</p><p className="text-sm text-slate-500">{o.customer_name} · {formatDate(o.created_at)}</p></div>
              <div className="flex flex-col items-end gap-1"><StatusBadge status={o.status} /><PaymentBadge status={o.payment_status} /></div>
            </div></Link></li>
        ))}
      </ul>
    </>
  );
}
