import { useEffect, useState, type FormEvent } from 'react';
import { useSettings } from '../../hooks/useSettings';
import { saveSettings, uploadLogo } from '../../services/api';
import { friendlyError, isValidPhone } from '../../lib/utils';
import { PageTitle } from '../../components/ui';

export default function AdminSettings() {
  const { settings, reload } = useSettings();
  const [f, setF] = useState(settings);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => setF(settings), [settings]);
  const set = (k: string, v: string) => setF((p) => ({ ...p, [k]: v }));

  async function onLogo(file?: File) {
    if (!file) return;
    if (!['image/png', 'image/jpeg', 'image/webp', 'image/svg+xml'].includes(file.type) || file.size > 2 * 1024 * 1024)
      return setMsg({ ok: false, text: 'Logo must be a PNG, JPG, WEBP or SVG under 2 MB.' });
    setBusy(true);
    try { set('logo_url', await uploadLogo(file)); setMsg({ ok: true, text: 'Logo uploaded. Click Save settings to apply it.' }); }
    catch (e) { setMsg({ ok: false, text: friendlyError(e, 'Logo upload failed.') }); }
    setBusy(false);
  }

  async function save(e: FormEvent) {
    e.preventDefault();
    if (!f.business_name.trim()) return setMsg({ ok: false, text: 'Business name is required.' });
    if (!isValidPhone(f.whatsapp_number) || !isValidPhone(f.phone_number)) return setMsg({ ok: false, text: 'Enter valid WhatsApp and phone numbers.' });
    setBusy(true); setMsg(null);
    try { await saveSettings(f); await reload(); setMsg({ ok: true, text: 'Settings saved.' }); }
    catch (err) { setMsg({ ok: false, text: friendlyError(err) }); }
    setBusy(false);
  }

  return (
    <>
      <PageTitle title="Settings" sub="Business details shown across the app." />
      <form onSubmit={save} className="card max-w-xl space-y-4">
        {msg && <p role={msg.ok ? 'status' : 'alert'} className={`rounded-lg p-3 text-sm ${msg.ok ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>{msg.text}</p>}
        <div><label className="label" htmlFor="bn">Business name</label><input id="bn" className="input" value={f.business_name} onChange={(e) => set('business_name', e.target.value)} /></div>
        <div className="grid gap-4 sm:grid-cols-2">
          <div><label className="label" htmlFor="wn">WhatsApp number</label><input id="wn" type="tel" className="input" value={f.whatsapp_number} onChange={(e) => set('whatsapp_number', e.target.value)} /></div>
          <div><label className="label" htmlFor="pn">Phone number</label><input id="pn" type="tel" className="input" value={f.phone_number} onChange={(e) => set('phone_number', e.target.value)} /></div>
        </div>
        <div><label className="label" htmlFor="bd">Business description</label><textarea id="bd" rows={3} className="input" value={f.business_description} onChange={(e) => set('business_description', e.target.value)} /></div>
        <div><label className="label" htmlFor="ci">Contact information / address</label><input id="ci" className="input" value={f.contact_info} onChange={(e) => set('contact_info', e.target.value)} /></div>
        <div><label className="label" htmlFor="bk">Payment (bank transfer) details shown to customers</label><textarea id="bk" rows={3} className="input" value={f.bank_details ?? ''} onChange={(e) => set('bank_details', e.target.value)} placeholder="Bank name, account number, account name" /></div>
        <div><span className="label">Logo</span>
          <div className="flex items-center gap-3">
            <img src={f.logo_url || '/favicon.svg'} alt="Current logo" className="h-14 w-14 rounded-xl object-cover" />
            <input type="file" accept="image/png,image/jpeg,image/webp,image/svg+xml" aria-label="Upload logo" onChange={(e) => onLogo(e.target.files?.[0])} className="text-sm" />
          </div></div>
        <button className="btn-primary" disabled={busy}>{busy ? 'Saving…' : 'Save settings'}</button>
      </form>
    </>
  );
}
