import { useState, type FormEvent } from 'react';
import { Pencil, Plus, Trash2 } from 'lucide-react';
import { useAsync } from '../../hooks/useAsync';
import { deleteService, listServices, saveService } from '../../services/api';
import { EmptyState, ErrorBox, ListSkeleton, PageTitle } from '../../components/ui';
import { ICON_NAMES, ServiceIcon } from '../../lib/icons';
import { formatDate, friendlyError } from '../../lib/utils';
import type { Service } from '../../types';

const blank = { name: '', description: '', icon: 'Sparkles', is_active: true };

export default function AdminServices() {
  const { data, loading, error, reload } = useAsync(() => listServices(true), []);
  const [form, setForm] = useState<(Partial<Service> & typeof blank) | null>(null);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!form) return;
    if (form.name.trim().length < 2) return setMsg({ ok: false, text: 'Please enter a service name.' });
    setBusy(true); setMsg(null);
    try {
      await saveService({
        id: form.id, name: form.name.trim(), description: form.description.trim(), icon: form.icon, is_active: form.is_active,
        ...(form.id ? {} : { sort_order: (data?.length ?? 0) + 1 }),
      });
      setForm(null); reload(); setMsg({ ok: true, text: 'Service saved.' });
    } catch (err) { setMsg({ ok: false, text: friendlyError(err, 'Could not save. A service with this name may already exist.') }); }
    setBusy(false);
  }

  async function toggle(s: Service) {
    try { await saveService({ id: s.id, name: s.name, is_active: !s.is_active }); reload(); }
    catch (e) { setMsg({ ok: false, text: friendlyError(e) }); }
  }

  async function remove(s: Service) {
    if (!window.confirm(`Delete "${s.name}"? This cannot be undone.`)) return;
    try { await deleteService(s.id); reload(); setMsg({ ok: true, text: 'Service deleted.' }); }
    catch (e) {
      const inUse = (e as Error).message === 'in-use';
      setMsg({ ok: false, text: inUse ? 'This service has orders, so it cannot be deleted. Disable it instead.' : friendlyError(e) });
    }
  }

  return (
    <>
      <PageTitle title="Services" right={<button className="btn-primary" onClick={() => { setMsg(null); setForm({ ...blank }); }}><Plus className="h-4 w-4" /> Add service</button>} />
      {msg && <p role={msg.ok ? 'status' : 'alert'} className={`mb-3 rounded-lg p-3 text-sm ${msg.ok ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>{msg.text}</p>}

      {form && (
        <form onSubmit={submit} className="card mb-4 space-y-3">
          <h2 className="font-bold">{form.id ? 'Edit service' : 'Add service'}</h2>
          <div><label className="label" htmlFor="sn">Name</label><input id="sn" className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
          <div><label className="label" htmlFor="sd">Description</label><textarea id="sd" rows={2} className="input" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
          <div><span className="label">Icon</span>
            <div className="flex flex-wrap gap-2" role="radiogroup" aria-label="Icon">
              {ICON_NAMES.map((n) => (
                <button type="button" key={n} role="radio" aria-checked={form.icon === n} aria-label={n} onClick={() => setForm({ ...form, icon: n })}
                  className={`flex h-11 w-11 items-center justify-center rounded-xl border ${form.icon === n ? 'border-brand-600 bg-brand-50 text-brand-700' : 'border-slate-200 text-slate-500'}`}><ServiceIcon name={n} className="h-5 w-5" /></button>
              ))}
            </div></div>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.is_active} onChange={(e) => setForm({ ...form, is_active: e.target.checked })} /> Active (visible to customers)</label>
          <div className="flex gap-2"><button className="btn-primary" disabled={busy}>{busy ? 'Saving…' : 'Save service'}</button><button type="button" className="btn-outline" onClick={() => setForm(null)}>Cancel</button></div>
        </form>
      )}

      {loading && <ListSkeleton />}
      {error && <ErrorBox message={error} onRetry={reload} />}
      {data && data.length === 0 && <EmptyState title="No services yet." text="Add your first service." />}
      <ul className="space-y-3">
        {data?.map((s) => (
          <li key={s.id} className={`card flex items-center gap-3 ${s.is_active ? '' : 'opacity-60'}`}>
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-brand-50 text-brand-600"><ServiceIcon name={s.icon} className="h-5 w-5" /></span>
            <div className="min-w-0 flex-1"><p className="truncate font-bold">{s.name} {!s.is_active && <span className="text-xs font-normal text-slate-500">(disabled)</span>}</p><p className="truncate text-xs text-slate-500">Created {formatDate(s.created_at)}</p></div>
            <button className="btn-outline !px-3 !py-2 text-xs" onClick={() => toggle(s)}>{s.is_active ? 'Disable' : 'Enable'}</button>
            <button aria-label={`Edit ${s.name}`} className="rounded-lg p-2 hover:bg-slate-100" onClick={() => { setMsg(null); setForm({ ...s }); }}><Pencil className="h-4 w-4" /></button>
            <button aria-label={`Delete ${s.name}`} className="rounded-lg p-2 text-red-600 hover:bg-red-50" onClick={() => remove(s)}><Trash2 className="h-4 w-4" /></button>
          </li>
        ))}
      </ul>
    </>
  );
}
