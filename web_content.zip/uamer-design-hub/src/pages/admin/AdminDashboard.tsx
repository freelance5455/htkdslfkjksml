import { Link } from 'react-router-dom';
import { useAsync } from '../../hooks/useAsync';
import { listAllOrders, listCustomers } from '../../services/api';
import { EmptyState, ErrorBox, ListSkeleton, PageTitle, StatCard, StatusBadge } from '../../components/ui';
import { formatDate } from '../../lib/utils';

export default function AdminDashboard() {
  const orders = useAsync(() => listAllOrders(), []);
  const customers = useAsync(() => listCustomers(), []);
  const o = orders.data;
  const n = (s: string) => o?.filter((x) => x.status === s).length ?? '–';
  const recent = o?.filter((x) => Date.now() - new Date(x.created_at).getTime() < 3 * 86400000).length ?? '–';

  return (
    <>
      <PageTitle title="Dashboard" sub="Overview of Uamer Design Hub" />
      <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-3">
        <StatCard label="Total Orders" value={o?.length ?? '–'} tone="bg-brand-600" />
        <StatCard label="Pending Orders" value={n('Pending')} tone="bg-orange-500" />
        <StatCard label="In Progress" value={n('In Progress')} tone="bg-blue-600" />
        <StatCard label="Completed" value={n('Completed')} tone="bg-green-600" />
        <StatCard label="Total Customers" value={customers.data?.length ?? '–'} tone="bg-purple-600" />
        <StatCard label="New (last 3 days)" value={recent} tone="bg-pink-600" />
      </div>
      <div className="mb-3 flex items-center justify-between"><h2 className="font-bold">Recent orders</h2><Link to="/admin/orders" className="text-sm font-semibold text-brand-600">See all →</Link></div>
      {orders.loading && <ListSkeleton />}
      {orders.error && <ErrorBox message={orders.error} onRetry={orders.reload} />}
      {o && o.length === 0 && <EmptyState title="No orders yet." text="New orders will appear here." />}
      <ul className="space-y-3">
        {o?.slice(0, 6).map((x) => (
          <li key={x.id}><Link to={`/admin/orders/${x.id}`} className="card flex items-center justify-between gap-2 transition hover:-translate-y-0.5">
            <div className="min-w-0"><p className="text-xs font-semibold text-brand-600">#{x.order_number} · {x.services?.name}</p><p className="truncate font-bold">{x.project_title}</p><p className="text-sm text-slate-500">{x.customer_name} · {formatDate(x.created_at)}</p></div>
            <StatusBadge status={x.status} />
          </Link></li>
        ))}
      </ul>
    </>
  );
}
