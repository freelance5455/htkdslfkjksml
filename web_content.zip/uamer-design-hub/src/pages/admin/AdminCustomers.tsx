import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Search } from 'lucide-react';
import { useAsync } from '../../hooks/useAsync';
import { listAllOrders, listCustomers } from '../../services/api';
import { EmptyState, ErrorBox, ListSkeleton, PageTitle, StatusBadge, WhatsAppButton } from '../../components/ui';
import { formatDate } from '../../lib/utils';
import type { Profile } from '../../types';

export default function AdminCustomers() {
  const customers = useAsync(() => listCustomers(), []);
  const orders = useAsync(() => listAllOrders(), []);
  const [q, setQ] = useState('');
  const [open, setOpen] = useState<Profile | null>(null);

  const rows = useMemo(() => {
    const t = q.trim().toLowerCase();
    return (customers.data ?? []).filter((c) => !t || [c.full_name, c.email ?? '', c.whatsapp ?? ''].some((v) => v.toLowerCase().includes(t)));
  }, [customers.data, q]);

  if (open) {
    const mine = (orders.data ?? []).filter((o) => o.customer_id === open.id);
    return (
      <>
        <button onClick={() => setOpen(null)} className="mb-3 inline-flex items-center gap-1 text-sm text-brand-600"><ArrowLeft className="h-4 w-4" /> Back to customers</button>
        <section className="card mb-4">
          <h1 className="text-xl font-extrabold">{open.full_name || 'Unnamed customer'}</h1>
          <p className="text-sm text-slate-600">{open.email}</p>
          <p className="text-sm text-slate-600">{open.whatsapp}</p>
          <p className="text-xs text-slate-400">Joined {formatDate(open.created_at)}</p>
          {open.whatsapp && <div className="mt-3"><WhatsAppButton message={`Hello ${open.full_name}, this is Uamer Feruak SR.`} label="WhatsApp customer" /></div>}
        </section>
        <h2 className="mb-2 font-bold">Orders ({mine.length})</h2>
        {mine.length === 0 && <EmptyState title="No orders from this customer yet." />}
        <ul className="space-y-3">
          {mine.map((o) => <li key={o.id}><Link to={`/admin/orders/${o.id}`} className="card flex items-center justify-between gap-2"><div className="min-w-0"><p className="text-xs font-semibold text-brand-600">#{o.order_number} · {o.services?.name}</p><p className="truncate font-bold">{o.project_title}</p></div><StatusBadge status={o.status} /></Link></li>)}
        </ul>
      </>
    );
  }

  return (
    <>
      <PageTitle title="Customers" sub={`${rows.length} customer${rows.length === 1 ? '' : 's'}`} />
      <div className="relative mb-4"><Search className="absolute left-3 top-3.5 h-4 w-4 text-slate-400" aria-hidden="true" />
        <label htmlFor="cs" className="sr-only">Search customers</label>
        <input id="cs" className="input pl-9" placeholder="Search name, email or WhatsApp…" value={q} onChange={(e) => setQ(e.target.value)} /></div>
      {customers.loading && <ListSkeleton />}
      {customers.error && <ErrorBox message={customers.error} onRetry={customers.reload} />}
      {!customers.loading && rows.length === 0 && <EmptyState title="No customers found." />}
      <ul className="space-y-3">
        {rows.map((c) => (
          <li key={c.id}><button onClick={() => setOpen(c)} className="card flex w-full items-center justify-between gap-2 text-left transition hover:-translate-y-0.5">
            <div className="min-w-0"><p className="truncate font-bold">{c.full_name || 'Unnamed customer'}</p><p className="truncate text-sm text-slate-500">{c.email}</p><p className="text-sm text-slate-500">{c.whatsapp} · Joined {formatDate(c.created_at)}</p></div>
            <span className="shrink-0 rounded-full bg-brand-50 px-3 py-1 text-xs font-bold text-brand-700">{c.order_count} order{c.order_count === 1 ? '' : 's'}</span>
          </button></li>
        ))}
      </ul>
    </>
  );
}
