import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { useAsync } from '../../hooks/useAsync';
import {
  getOrder, listHistory, listMessages, listOrderFiles, listPayments, setOrderPayment,
  updateAdminNotes, updateOrderStatus, verifyPayment,
} from '../../services/api';
import { ErrorBox, ListSkeleton, PaymentBadge, StatusBadge, WhatsAppButton } from '../../components/ui';
import { FilesList, MessageThread, Timeline } from '../../components/OrderParts';
import { formatDate, friendlyError } from '../../lib/utils';
import { ORDER_STATUSES, PAYMENT_STATUSES, type OrderStatus, type PaymentStatus } from '../../types';

export default function AdminOrderDetail() {
  const { id = '' } = useParams();
  const { session } = useAuth();
  const uid = session!.user.id;
  const order = useAsync(() => getOrder(id), [id]);
  const files = useAsync(() => listOrderFiles(id), [id]);
  const history = useAsync(() => listHistory(id), [id]);
  const messages = useAsync(() => listMessages(id), [id]);
  const payments = useAsync(() => listPayments(id), [id]);
  const [notes, setNotes] = useState('');
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => { if (order.data) setNotes(order.data.admin_notes ?? ''); }, [order.data]);

  async function run(fn: () => Promise<void>, okText: string) {
    setBusy(true); setMsg(null);
    try { await fn(); setMsg({ ok: true, text: okText }); order.reload(); history.reload(); payments.reload(); }
    catch (e) { setMsg({ ok: false, text: friendlyError(e) }); }
    setBusy(false);
  }

  if (order.loading) return <ListSkeleton rows={4} />;
  if (order.error) return <ErrorBox message={order.error} onRetry={order.reload} />;
  const o = order.data;
  if (!o) return <div className="card text-center"><p className="font-semibold">Order not found.</p><Link to="/admin/orders" className="btn-primary mt-3">Back to orders</Link></div>;

  const wa = `Hello ${o.customer_name}, this is Uamer Feruak SR about your Order #${o.order_number} (${o.services?.name}).`;

  return (
    <div className="space-y-4">
      <Link to="/admin/orders" className="inline-flex items-center gap-1 text-sm text-brand-600"><ArrowLeft className="h-4 w-4" /> Back to orders</Link>

      <section className="card">
        <div className="flex items-start justify-between gap-2">
          <div><p className="text-xs font-semibold text-brand-600">Order #{o.order_number} · {o.services?.name}</p><h1 className="text-xl font-extrabold">{o.project_title}</h1></div>
          <div className="flex flex-col items-end gap-1"><StatusBadge status={o.status} /><PaymentBadge status={o.payment_status} /></div>
        </div>
        <p className="mt-3 whitespace-pre-wrap text-sm">{o.description}</p>
        {o.additional_notes && <p className="mt-2 whitespace-pre-wrap rounded-lg bg-slate-50 p-3 text-sm text-slate-600">{o.additional_notes}</p>}
        <dl className="mt-4 grid gap-2 text-sm sm:grid-cols-2">
          <div><dt className="text-slate-500">Customer</dt><dd className="font-medium">{o.customer_name}</dd></div>
          <div><dt className="text-slate-500">WhatsApp</dt><dd className="font-medium">{o.customer_whatsapp}</dd></div>
          <div><dt className="text-slate-500">Email</dt><dd className="font-medium">{o.customer_email || '—'}</dd></div>
          <div><dt className="text-slate-500">Deadline</dt><dd className="font-medium">{formatDate(o.deadline)}</dd></div>
          <div><dt className="text-slate-500">Submitted</dt><dd className="font-medium">{formatDate(o.created_at, true)}</dd></div>
        </dl>
        <div className="mt-4"><WhatsAppButton message={wa} label="WhatsApp customer" /></div>
      </section>

      {msg && <p role={msg.ok ? 'status' : 'alert'} className={`rounded-lg p-3 text-sm ${msg.ok ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>{msg.text}</p>}

      <section className="card grid gap-4 md:grid-cols-2">
        <div><label className="label" htmlFor="st">Order status</label>
          <select id="st" className="input" value={o.status} disabled={busy}
            onChange={(e) => run(() => updateOrderStatus(o.id, e.target.value as OrderStatus), 'Status updated. The customer was notified.')}>
            {ORDER_STATUSES.map((s) => <option key={s}>{s}</option>)}</select></div>
        <div><label className="label" htmlFor="ps">Payment status</label>
          <select id="ps" className="input" value={o.payment_status} disabled={busy}
            onChange={(e) => run(() => setOrderPayment(o.id, e.target.value as PaymentStatus), 'Payment status updated.')}>
            {PAYMENT_STATUSES.map((s) => <option key={s}>{s}</option>)}</select></div>
      </section>

      <section className="card"><h2 className="mb-3 font-bold">Payments</h2>
        {(payments.data ?? []).length === 0 ? <p className="text-sm text-slate-500">No payment proof submitted.</p> : (
          <ul className="space-y-3">
            {payments.data!.map((p) => (
              <li key={p.id} className="rounded-xl border border-slate-200 p-3 text-sm">
                <div className="flex items-center justify-between"><span>{p.method} · {formatDate(p.created_at, true)}</span><PaymentBadge status={p.status} /></div>
                {p.reference && <p className="mt-1 text-slate-600">Ref: {p.reference}</p>}
                {p.status === 'Pending Verification' && (
                  <div className="mt-2 flex gap-2">
                    <button className="btn-primary !py-2" disabled={busy} onClick={() => run(() => verifyPayment(p.id, 'Paid'), 'Payment verified. The customer was notified.')}>Verify as Paid</button>
                    <button className="btn-outline !py-2" disabled={busy} onClick={() => run(() => verifyPayment(p.id, 'Unpaid'), 'Payment proof rejected.')}>Reject</button>
                  </div>
                )}
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="card"><h2 className="mb-3 font-bold">Files</h2>{files.loading ? <ListSkeleton rows={1} /> : <FilesList files={files.data ?? []} />}</section>

      <section className="card"><h2 className="mb-2 font-bold">Admin notes (private)</h2>
        <label htmlFor="an" className="sr-only">Admin notes</label>
        <textarea id="an" rows={3} className="input" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Only you can see these notes." />
        <button className="btn-primary mt-2" disabled={busy} onClick={() => run(() => updateAdminNotes(o.id, notes), 'Notes saved.')}>Save notes</button></section>

      <section className="card"><h2 className="mb-3 font-bold">Messages to customer</h2>
        <MessageThread orderId={o.id} userId={uid} isAdmin messages={messages.data ?? []} onSent={messages.reload} /></section>

      <section className="card"><h2 className="mb-3 font-bold">Timeline</h2>{history.loading ? <ListSkeleton rows={2} /> : <Timeline items={history.data ?? []} />}</section>
    </div>
  );
}
