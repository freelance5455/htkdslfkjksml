import { useEffect, useState, type FormEvent } from 'react';
import { LogOut } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { updateProfile } from '../services/api';
import { friendlyError, isValidPhone } from '../lib/utils';
import { PageTitle } from '../components/ui';

export default function Profile() {
  const { session, profile, refreshProfile, signOut } = useAuth();
  const [name, setName] = useState('');
  const [wa, setWa] = useState('');
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => { if (profile) { setName(profile.full_name); setWa(profile.whatsapp ?? ''); } }, [profile]);

  async function save(e: FormEvent) {
    e.preventDefault();
    setMsg(null);
    if (name.trim().length < 2) return setMsg({ ok: false, text: 'Please enter your name.' });
    if (!isValidPhone(wa)) return setMsg({ ok: false, text: 'Enter a valid WhatsApp number.' });
    setBusy(true);
    try { await updateProfile(session!.user.id, { full_name: name.trim(), whatsapp: wa.trim() }); await refreshProfile(); setMsg({ ok: true, text: 'Profile updated.' }); }
    catch (err) { setMsg({ ok: false, text: friendlyError(err) }); }
    setBusy(false);
  }

  return (
    <div className="mx-auto max-w-md px-4 py-6">
      <PageTitle title="Your profile" />
      <form onSubmit={save} className="card space-y-4">
        {msg && <p role={msg.ok ? 'status' : 'alert'} className={`rounded-lg p-3 text-sm ${msg.ok ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>{msg.text}</p>}
        <div><label className="label" htmlFor="pe">Email</label><input id="pe" className="input bg-slate-50" value={profile?.email ?? session?.user.email ?? ''} disabled /></div>
        <div><label className="label" htmlFor="pn">Full name</label><input id="pn" className="input" value={name} onChange={(e) => setName(e.target.value)} /></div>
        <div><label className="label" htmlFor="pw">WhatsApp number</label><input id="pw" type="tel" className="input" value={wa} onChange={(e) => setWa(e.target.value)} /></div>
        <button className="btn-primary w-full" disabled={busy}>{busy ? 'Saving…' : 'Save changes'}</button>
      </form>
      <button onClick={signOut} className="btn-outline mt-4 w-full"><LogOut className="h-4 w-4" /> Logout</button>
    </div>
  );
}
