import { useEffect, useState, type FormEvent } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { CheckCircle2 } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { useAsync } from '../hooks/useAsync';
import { createOrder, listServices, uploadOrderFile } from '../services/api';
import { formatDate, friendlyError, isValidPhone } from '../lib/utils';
import FileUploader from '../components/FileUploader';
import { ErrorBox, ListSkeleton, PageTitle, StatusBadge, WhatsAppButton } from '../components/ui';
import type { Order } from '../types';

export default function OrderPage() {
  const { session, profile } = useAuth();
  const [params] = useSearchParams();
  const services = useAsync(() => listServices(), []);
  const [f, setF] = useState({
    name: '', whatsapp: '', email: '', service_id: params.get('service') ?? '',
    title: '', description: '', deadline: '', notes: '',
  });
  const [files, setFiles] = useState<File[]>([]);
  const [progress, setProgress] = useState<Record<string, number>>({});
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<{ order: Order; failed: string[] } | null>(null);

  useEffect(() => {
    if (profile) setF((p) => ({ ...p, name: p.name || profile.full_name, whatsapp: p.whatsapp || profile.whatsapp || '', email: p.email || profile.email || '' }));
  }, [profile]);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError('');
    if (!session) return;
    if (f.name.trim().length < 2) return setError('Please enter your name.');
    if (!isValidPhone(f.whatsapp)) return setError('Enter a valid WhatsApp number, e.g. +2348012345678.');
    if (f.email && !/^\S+@\S+\.\S+$/.test(f.email)) return setError('Enter a valid email address or leave it empty.');
    if (!f.service_id) return setError('Please select a service.');
    if (f.title.trim().length < 3) return setError('Please enter a project title.');
    if (f.description.trim().length < 10) return setError('Please describe your project in a little more detail.');
    if (f.deadline && new Date(f.deadline) < new Date(new Date().toDateString())) return setError('Deadline cannot be in the past.');

    setBusy(true);
    try {
      const order = await createOrder({
        customer_id: session.user.id, service_id: f.service_id,
        customer_name: f.name.trim(), customer_whatsapp: f.whatsapp.trim(), customer_email: f.email.trim() || null,
        project_title: f.title.trim(), description: f.description.trim(),
        deadline: f.deadline || null, additional_notes: f.notes.trim() || null,
      });
      const failed: string[] = [];
      for (const file of files) {
        try {
          await uploadOrderFile(order.id, session.user.id, file, 'attachment', (p) => setProgress((s) => ({ ...s, [file.name]: p })));
        } catch (err) { console.error(err); failed.push(file.name); }
      }
      setDone({ order, failed });
    } catch (err) {
      setError(friendlyError(err));
    } finally { setBusy(false); }
  }

  if (done) {
    const o = done.order;
    return (
      <div className="mx-auto max-w-lg px-4 py-10">
        <div className="card text-center">
          <CheckCircle2 className="mx-auto h-16 w-16 text-green-500" aria-hidden="true" />
          <h1 className="mt-2 text-2xl font-extrabold">Order submitted successfully.</h1>
          <dl className="mt-5 space-y-2 text-left text-sm">
            <div className="flex justify-between"><dt className="text-slate-500">Order ID</dt><dd className="font-semibold">#{o.order_number}</dd></div>
            <div className="flex justify-between"><dt className="text-slate-500">Service</dt><dd className="font-semibold">{o.services?.name}</dd></div>
            <div className="flex justify-between"><dt className="text-slate-500">Status</dt><dd><StatusBadge status={o.status} /></dd></div>
            <div className="flex justify-between"><dt className="text-slate-500">Date submitted</dt><dd className="font-semibold">{formatDate(o.created_at, true)}</dd></div>
          </dl>
          {done.failed.length > 0 && <p role="alert" className="mt-4 rounded-lg bg-amber-50 p-3 text-sm text-amber-800">Some files could not be uploaded ({done.failed.join(', ')}). You can add them again from the order page.</p>}
          <div className="mt-6 flex flex-col gap-2">
            <Link to={`/dashboard/orders/${o.id}`} className="btn-primary">View order</Link>
            <WhatsAppButton message={`Hello Uamer Feruak SR, I just submitted order #${o.order_number} for ${o.services?.name}.`} label="Tell us on WhatsApp" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-8">
      <PageTitle title="Place an Order" sub="Tell us what you need and upload any reference files." />
      {services.loading && <ListSkeleton rows={4} />}
      {services.error && <ErrorBox message={services.error} onRetry={services.reload} />}
      {services.data && (
        <form onSubmit={submit} className="card space-y-4 p-5" noValidate>
          {error && <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-700">{error}</p>}
          <div><label className="label" htmlFor="svc">Select service *</label>
            <select id="svc" className="input" value={f.service_id} onChange={(e) => setF({ ...f, service_id: e.target.value })} required>
              <option value="">Choose a service…</option>
              {services.data.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select></div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div><label className="label" htmlFor="cn">Your name *</label><input id="cn" className="input" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></div>
            <div><label className="label" htmlFor="cw">WhatsApp number *</label><input id="cw" type="tel" placeholder="+234…" className="input" value={f.whatsapp} onChange={(e) => setF({ ...f, whatsapp: e.target.value })} /></div>
          </div>
          <div><label className="label" htmlFor="ce">Email (optional)</label><input id="ce" type="email" className="input" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></div>
          <div><label className="label" htmlFor="pt">Project title *</label><input id="pt" className="input" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></div>
          <div><label className="label" htmlFor="pd">Project description *</label><textarea id="pd" rows={4} placeholder="Tell us what you want…" className="input" value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></div>
          <div><label className="label" htmlFor="dl">Preferred deadline</label><input id="dl" type="date" className="input" value={f.deadline} onChange={(e) => setF({ ...f, deadline: e.target.value })} /></div>
          <div><label className="label" htmlFor="an">Additional notes</label><textarea id="an" rows={2} className="input" value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} /></div>
          <div><span className="label">Upload files / images (optional)</span><FileUploader files={files} onChange={setFiles} progress={progress} /></div>
          <button className="btn-primary w-full" disabled={busy}>{busy ? 'Submitting…' : 'Submit Order'}</button>
        </form>
      )}
    </div>
  );
}
