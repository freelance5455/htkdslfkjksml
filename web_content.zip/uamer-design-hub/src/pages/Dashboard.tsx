import { Link } from 'react-router-dom';
import { Plus } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { useAsync } from '../hooks/useAsync';
import { listMyOrders } from '../services/api';
import { EmptyState, ErrorBox, ListSkeleton, PaymentBadge, StatCard, StatusBadge } from '../components/ui';
import { formatDate } from '../lib/utils';

export default function Dashboard() {
  const { session, profile } = useAuth();
  const uid = session!.user.id;
  const { data, loading, error, reload } = useAsync(() => listMyOrders(uid), [uid]);
  const count = (s: string) => data?.filter((o) => o.status === s).length ?? 0;

  return (
    <div className="mx-auto max-w-4xl px-4 py-6">
      <div className="mb-4 flex items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-extrabold md:text-2xl">Welcome{profile?.full_name ? `, ${profile.full_name.split(' ')[0]}` : ''} 👋</h1>
          <p className="text-sm text-slate-500">Here is an overview of your orders.</p>
        </div>
        <Link to="/order" className="btn-primary"><Plus className="h-4 w-4" /> New order</Link>
      </div>

      <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-4">
        <StatCard label="Total Orders" value={data?.length ?? '–'} tone="bg-brand-600" />
        <StatCard label="Pending" value={data ? count('Pending') : '–'} tone="bg-orange-500" />
        <StatCard label="In Progress" value={data ? count('In Progress') : '–'} tone="bg-blue-600" />
        <StatCard label="Completed" value={data ? count('Completed') : '–'} tone="bg-green-600" />
      </div>

      <h2 className="mb-3 font-bold">Your orders</h2>
      {loading && <ListSkeleton />}
      {error && <ErrorBox message={error} onRetry={reload} />}
      {data && data.length === 0 && <EmptyState title="You don't have any orders yet." action={{ to: '/order', label: 'Order a Service' }} />}
      <ul className="space-y-3">
        {data?.map((o) => (
          <li key={o.id}>
            <Link to={`/dashboard/orders/${o.id}`} className="card block transition hover:-translate-y-0.5">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="text-xs font-semibold text-brand-600">Order #{o.order_number}</p>
                  <p className="truncate font-bold">{o.project_title}</p>
                  <p className="text-sm text-slate-500">{o.services?.name} · {formatDate(o.created_at)}</p>
                </div>
                <div className="flex flex-col items-end gap-1"><StatusBadge status={o.status} /><PaymentBadge status={o.payment_status} /></div>
              </div>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
