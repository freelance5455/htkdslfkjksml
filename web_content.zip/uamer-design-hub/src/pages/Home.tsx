import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle2, Clock, FileUp, MessageCircle, Phone, ShieldCheck, Zap } from 'lucide-react';
import { useServicesList } from '../hooks/useServicesList';
import { useSettings } from '../hooks/useSettings';
import { CallButton, ServiceCardSkeleton, WhatsAppButton } from '../components/ServiceBits';
import { ServiceIcon } from '../lib/icons';

const why = [
  { icon: Zap, t: 'Fast turnaround', d: 'Clear timelines and quick delivery on every project.' },
  { icon: ShieldCheck, t: 'Professional quality', d: 'Polished, brand-ready work you can be proud of.' },
  { icon: MessageCircle, t: 'Easy communication', d: 'Chat on WhatsApp or track updates inside your dashboard.' },
  { icon: Clock, t: 'Track every order', d: 'See status, files and updates for each order anytime.' },
];
const steps = [
  { n: 1, t: 'Choose a service', d: 'Pick what you need from our services.' },
  { n: 2, t: 'Submit your order', d: 'Describe your project and upload your files.' },
  { n: 3, t: 'We get to work', d: 'Follow progress and chat with us anytime.' },
  { n: 4, t: 'Receive & approve', d: 'Review your finished work and complete your order.' },
];

export default function Home() {
  const services = useServicesList();
  const { settings } = useSettings();
  return (
    <>
      <section className="bg-gradient-to-br from-brand-900 via-brand-800 to-brand-600 text-white">
        <div className="mx-auto max-w-6xl px-4 py-14 md:py-24">
          <p className="mb-3 inline-block rounded-full bg-white/10 px-3 py-1 text-xs font-semibold text-gold-400">{settings.business_name}</p>
          <h1 className="max-w-2xl animate-fadeUp text-4xl font-extrabold leading-tight md:text-6xl">
            Professional Digital Services, <span className="text-gold-500">Made Simple.</span>
          </h1>
          <p className="mt-4 max-w-xl text-brand-100 md:text-lg">
            Get professional graphic design, photo editing, video editing and website development services from Uamer Feruak SR.
          </p>
          <div className="mt-7 flex flex-col gap-3 sm:flex-row">
            <Link to="/order" className="btn-gold">Order a Service <ArrowRight className="h-4 w-4" /></Link>
            <WhatsAppButton message={`Hello ${settings.business_name}, I would like to order a service.`} />
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-12" aria-labelledby="svc">
        <div className="mb-6 flex items-end justify-between">
          <h2 id="svc" className="text-2xl font-extrabold text-brand-900">Our Services</h2>
          <Link to="/services" className="text-sm font-semibold text-brand-600">See all →</Link>
        </div>
        {services.length === 0 ? <ServiceCardSkeleton /> : (
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            {services.map((s) => (
              <Link key={s.id} to={`/order?service=${s.id}`} className="card group flex flex-col items-center gap-2 text-center transition hover:-translate-y-1">
                <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-brand-50 text-brand-600 transition group-hover:bg-brand-600 group-hover:text-white"><ServiceIcon name={s.icon} className="h-6 w-6" /></span>
                <span className="text-sm font-semibold">{s.name}</span>
              </Link>
            ))}
          </div>
        )}
      </section>

      <section className="bg-white py-12">
        <div className="mx-auto max-w-6xl px-4">
          <h2 className="mb-6 text-2xl font-extrabold text-brand-900">Why choose us</h2>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {why.map((w) => (
              <div key={w.t} className="card">
                <w.icon className="mb-2 h-6 w-6 text-brand-600" aria-hidden="true" />
                <h3 className="font-bold">{w.t}</h3><p className="mt-1 text-sm text-slate-500">{w.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-12">
        <h2 className="mb-6 text-2xl font-extrabold text-brand-900">How it works</h2>
        <ol className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {steps.map((s) => (
            <li key={s.n} className="card">
              <span className="mb-2 flex h-9 w-9 items-center justify-center rounded-full bg-gold-500 font-extrabold text-brand-900">{s.n}</span>
              <h3 className="font-bold">{s.t}</h3><p className="mt-1 text-sm text-slate-500">{s.d}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="mx-4 mb-12 max-w-6xl rounded-3xl bg-gradient-to-r from-brand-700 to-brand-500 p-8 text-center text-white lg:mx-auto">
        <FileUp className="mx-auto mb-2 h-8 w-8 text-gold-400" aria-hidden="true" />
        <h2 className="text-2xl font-extrabold">Ready to start your project?</h2>
        <p className="mx-auto mt-2 max-w-md text-brand-100">Submit your order in minutes and we will take it from there.</p>
        <div className="mt-5 flex flex-col justify-center gap-3 sm:flex-row">
          <Link to="/order" className="btn-gold">Order a Service</Link>
          <WhatsAppButton message={`Hello ${settings.business_name}, I would like to order a service.`} />
        </div>
      </section>

      <section className="bg-white py-12" aria-labelledby="contact">
        <div className="mx-auto max-w-6xl px-4">
          <h2 id="contact" className="mb-4 text-2xl font-extrabold text-brand-900">Contact</h2>
          <div className="card max-w-lg space-y-2">
            <p className="text-lg font-bold">{settings.business_name}</p>
            <p className="flex items-center gap-2 text-sm"><CheckCircle2 className="h-4 w-4 text-green-600" /> WhatsApp: {settings.whatsapp_number}</p>
            <p className="flex items-center gap-2 text-sm"><Phone className="h-4 w-4 text-brand-600" /> Phone: {settings.phone_number}</p>
            <p className="text-sm text-slate-500">{settings.contact_info}</p>
            <div className="flex flex-col gap-2 pt-2 sm:flex-row">
              <WhatsAppButton message={`Hello ${settings.business_name}, I would like to order a service.`} />
              <CallButton />
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
