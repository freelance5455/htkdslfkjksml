import { useNavigate } from 'react-router-dom';
import { Bell, CheckCheck } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { useNotifications } from '../hooks/useNotifications';
import { markAllRead, markNotificationRead } from '../services/api';
import { EmptyState, ListSkeleton, PageTitle } from '../components/ui';
import { timeAgo } from '../lib/utils';

export default function Notifications() {
  const { session } = useAuth();
  const uid = session!.user.id;
  const { items, loading, unread, reload } = useNotifications(uid);
  const nav = useNavigate();

  async function open(id: string, link: string | null, read: boolean) {
    try { if (!read) await markNotificationRead(id); } catch (e) { console.error(e); }
    reload();
    if (link) nav(link);
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-6">
      <PageTitle title="Notifications" right={unread > 0 ? (
        <button className="btn-outline !py-2" onClick={async () => { try { await markAllRead(uid); } catch (e) { console.error(e); } reload(); }}><CheckCheck className="h-4 w-4" /> Mark all read</button>
      ) : undefined} />
      {loading && <ListSkeleton />}
      {!loading && items.length === 0 && <EmptyState title="You're all caught up." text="New updates will appear here." />}
      <ul className="space-y-2">
        {items.map((n) => (
          <li key={n.id}>
            <button onClick={() => open(n.id, n.link, n.is_read)} className={`card flex w-full items-start gap-3 text-left ${n.is_read ? '' : 'border-brand-200 bg-brand-50/60'}`}>
              <span className={`mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full ${n.is_read ? 'bg-slate-100 text-slate-500' : 'bg-brand-600 text-white'}`}><Bell className="h-4 w-4" /></span>
              <span className="min-w-0 flex-1"><span className="block text-sm font-semibold">{n.title}</span>{n.body && <span className="block text-sm text-slate-600">{n.body}</span>}<span className="text-xs text-slate-400">{timeAgo(n.created_at)}</span></span>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
