import { Link } from 'react-router-dom';
import { AlertCircle, Inbox, Phone } from 'lucide-react';
import type { ReactNode } from 'react';
import { paymentStyle, statusStyle, whatsappLink } from '../lib/utils';
import { useSettings } from '../hooks/useSettings';
import type { OrderStatus, PaymentStatus } from '../types';

export function WhatsAppIcon({ className = 'h-5 w-5' }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden="true">
      <path d="M12.04 2a9.9 9.9 0 0 0-8.43 15.1L2 22l5.04-1.58A9.9 9.9 0 1 0 12.04 2Zm5.8 14.07c-.24.68-1.4 1.3-1.92 1.34-.5.05-1.12.07-1.8-.11a12.6 12.6 0 0 1-4.6-2.83 10.4 10.4 0 0 1-2.2-3.3c-.4-1-.1-1.8.5-2.4.2-.2.5-.3.7-.3h.5c.15 0 .35-.05.55.42l.77 1.86c.07.15.1.3 0 .5l-.3.46-.4.46c-.14.15-.28.3-.12.6.17.3.73 1.2 1.56 1.94 1.07.95 1.97 1.25 2.27 1.4.3.14.47.12.65-.07.17-.2.75-.87.95-1.17.2-.3.4-.25.67-.15l1.78.84c.3.15.5.22.57.35.07.13.07.74-.17 1.4Z" />
    </svg>
  );
}

export function StatusBadge({ status }: { status: OrderStatus }) {
  return <span className={`inline-block rounded-full px-2.5 py-1 text-xs font-semibold ${statusStyle[status]}`}>{status}</span>;
}
export function PaymentBadge({ status }: { status: PaymentStatus }) {
  return <span className={`inline-block rounded-full px-2.5 py-1 text-xs font-semibold ${paymentStyle[status]}`}>{status}</span>;
}

export function WhatsAppButton({ message, label = 'Chat on WhatsApp', className = 'btn-wa' }: { message: string; label?: string; className?: string }) {
  const { settings } = useSettings();
  return (
    <a href={whatsappLink(settings.whatsapp_number, message)} target="_blank" rel="noopener noreferrer" className={className}>
      <WhatsAppIcon /> {label}
    </a>
  );
}

export function FloatingWhatsApp() {
  const { settings } = useSettings();
  return (
    <a
      href={whatsappLink(settings.whatsapp_number, `Hello ${settings.business_name}, I would like to order a service.`)}
      target="_blank" rel="noopener noreferrer" aria-label="Chat on WhatsApp"
      className="fixed bottom-20 right-4 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-[#1faa59] text-white shadow-lg transition hover:scale-105 active:scale-95 md:bottom-6"
    >
      <WhatsAppIcon className="h-7 w-7" />
    </a>
  );
}

export function CallButton({ className = 'btn-outline' }: { className?: string }) {
  const { settings } = useSettings();
  return <a href={`tel:${settings.phone_number}`} className={className}><Phone className="h-4 w-4" /> Call Now</a>;
}

export function Skeleton({ className = 'h-20' }: { className?: string }) {
  return <div className={`skeleton ${className}`} aria-hidden="true" />;
}
export function ListSkeleton({ rows = 3 }: { rows?: number }) {
  return <div className="space-y-3" role="status" aria-label="Loading">{Array.from({ length: rows }).map((_, i) => <Skeleton key={i} />)}</div>;
}

export function EmptyState({ title, text, action }: { title: string; text?: string; action?: { to: string; label: string } }) {
  return (
    <div className="card flex flex-col items-center py-10 text-center">
      <div className="mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-brand-50 text-brand-600"><Inbox className="h-7 w-7" /></div>
      <p className="font-semibold text-slate-800">{title}</p>
      {text && <p className="mt-1 text-sm text-slate-500">{text}</p>}
      {action && <Link to={action.to} className="btn-primary mt-4">{action.label}</Link>}
    </div>
  );
}

export function ErrorBox({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="card flex items-start gap-3 border-red-200 bg-red-50" role="alert">
      <AlertCircle className="mt-0.5 h-5 w-5 shrink-0 text-red-600" />
      <div className="flex-1 text-sm text-red-800">{message}</div>
      {onRetry && <button onClick={onRetry} className="text-sm font-semibold text-red-700 underline">Retry</button>}
    </div>
  );
}

export function StatCard({ label, value, tone = 'bg-brand-600' }: { label: string; value: ReactNode; tone?: string }) {
  return (
    <div className={`rounded-2xl ${tone} p-4 text-white shadow-card`}>
      <div className="text-2xl font-extrabold">{value}</div>
      <div className="text-xs font-medium opacity-90">{label}</div>
    </div>
  );
}

export function PageTitle({ title, sub, right }: { title: string; sub?: string; right?: ReactNode }) {
  return (
    <div className="mb-4 flex flex-wrap items-end justify-between gap-2">
      <div><h1 className="text-xl font-extrabold text-slate-900 md:text-2xl">{title}</h1>{sub && <p className="text-sm text-slate-500">{sub}</p>}</div>
      {right}
    </div>
  );
}

export function Logo({ light = false, size = 'md' }: { light?: boolean; size?: 'md' | 'lg' }) {
  const { settings } = useSettings();
  const h = size === 'lg' ? 'h-12 w-12' : 'h-9 w-9';
  return (
    <span className="inline-flex items-center gap-2">
      {settings.logo_url
        ? <img src={settings.logo_url} alt="Uamer Design Hub logo" className={`${h} rounded-xl object-cover`} />
        : <img src="/favicon.svg" alt="Uamer Design Hub logo" className={`${h} rounded-xl`} />}
      <span className="leading-tight">
        <span className={`block text-base font-extrabold ${light ? 'text-white' : 'text-brand-800'}`}>Uamer <span className="text-gold-500">Design Hub</span></span>
        <span className={`block text-[10px] font-medium ${light ? 'text-brand-100' : 'text-slate-500'}`}>{settings.business_name}</span>
      </span>
    </span>
  );
}
