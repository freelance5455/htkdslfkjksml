import { useRef, useState } from 'react';
import { CloudUpload, X } from 'lucide-react';
import { ACCEPT_ATTR, formatBytes, validateFile } from '../lib/utils';

interface Props {
  files: File[];
  onChange: (files: File[]) => void;
  multiple?: boolean;
  progress?: Record<string, number>;
  label?: string;
}

export default function FileUploader({ files, onChange, multiple = true, progress = {}, label = 'Tap to upload images/files' }: Props) {
  const ref = useRef<HTMLInputElement>(null);
  const [error, setError] = useState('');

  function add(list: FileList | null) {
    if (!list) return;
    const errs: string[] = [];
    const ok: File[] = [];
    Array.from(list).forEach((f) => { const e = validateFile(f); if (e) errs.push(e); else ok.push(f); });
    setError(errs.join(' '));
    onChange(multiple ? [...files, ...ok].slice(0, 10) : ok.slice(0, 1));
    if (ref.current) ref.current.value = '';
  }

  return (
    <div>
      <button type="button" onClick={() => ref.current?.click()}
        className="flex w-full flex-col items-center gap-1 rounded-xl border-2 border-dashed border-brand-300 bg-brand-50/50 p-5 text-sm text-brand-700 hover:bg-brand-50">
        <CloudUpload className="h-6 w-6" aria-hidden="true" />
        <span className="font-semibold">{label}</span>
        <span className="text-xs text-slate-500">JPG, PNG, WEBP, PDF or MP4 · max 25 MB each</span>
      </button>
      <input ref={ref} type="file" hidden multiple={multiple} accept={ACCEPT_ATTR} onChange={(e) => add(e.target.files)} aria-label="Choose files" />
      {error && <p role="alert" className="mt-2 text-sm text-red-600">{error}</p>}
      <ul className="mt-2 space-y-2">
        {files.map((f, i) => (
          <li key={f.name + i} className="rounded-lg border border-slate-200 bg-white p-2 text-sm">
            <div className="flex items-center justify-between gap-2">
              <span className="truncate">{f.name} <span className="text-xs text-slate-400">{formatBytes(f.size)}</span></span>
              <button type="button" aria-label={`Remove ${f.name}`} onClick={() => onChange(files.filter((_, j) => j !== i))}><X className="h-4 w-4 text-slate-500" /></button>
            </div>
            {progress[f.name] !== undefined && (
              <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-slate-200" role="progressbar" aria-valuenow={progress[f.name]} aria-valuemin={0} aria-valuemax={100}>
                <div className="h-full bg-brand-600 transition-all" style={{ width: `${progress[f.name]}%` }} />
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}
