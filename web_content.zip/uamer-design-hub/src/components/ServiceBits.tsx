import { Skeleton } from './ui';
export { CallButton, WhatsAppButton } from './ui';

export function ServiceCardSkeleton() {
  return (
    <div className="grid grid-cols-2 gap-3 md:grid-cols-4" role="status" aria-label="Loading services">
      {Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-28" />)}
    </div>
  );
}
