import { useState } from 'react';
import { Download, FileText, Send } from 'lucide-react';
import { signedUrl, sendMessage } from '../services/api';
import { formatBytes, formatDate, friendlyError } from '../lib/utils';
import type { HistoryItem, OrderFile, OrderMessage } from '../types';
import { StatusBadge } from './ui';

export function FilesList({ files, empty = 'No files uploaded.' }: { files: OrderFile[]; empty?: string }) {
  const [err, setErr] = useState('');
  async function open(f: OrderFile) {
    setErr('');
    try { window.open(await signedUrl(f.storage_path), '_blank', 'noopener'); }
    catch (e) { setErr(friendlyError(e, 'Could not open this file.')); }
  }
  if (files.length === 0) return <p className="text-sm text-slate-500">{empty}</p>;
  return (
    <div>
      {err && <p role="alert" className="mb-2 text-sm text-red-600">{err}</p>}
      <ul className="space-y-2">
        {files.map((f) => (
          <li key={f.id}>
            <button onClick={() => open(f)} className="flex w-full items-center gap-3 rounded-xl border border-slate-200 p-3 text-left hover:bg-slate-50">
              <FileText className="h-5 w-5 shrink-0 text-brand-600" aria-hidden="true" />
              <span className="min-w-0 flex-1"><span className="block truncate text-sm font-medium">{f.file_name}</span>
                <span className="text-xs text-slate-500">{f.kind === 'payment_proof' ? 'Payment proof · ' : ''}{formatBytes(f.size_bytes)} · {formatDate(f.created_at)}</span></span>
              <Download className="h-4 w-4 text-slate-400" aria-hidden="true" />
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function Timeline({ items }: { items: HistoryItem[] }) {
  return (
    <ol className="relative ml-2 space-y-4 border-l-2 border-brand-100 pl-5">
      {items.map((h) => (
        <li key={h.id} className="relative">
          <span className="absolute -left-[27px] top-1 h-3 w-3 rounded-full bg-brand-600 ring-4 ring-white" />
          <StatusBadge status={h.status} />
          <p className="mt-1 text-xs text-slate-500">{formatDate(h.created_at, true)}{h.note ? ` · ${h.note}` : ''}</p>
        </li>
      ))}
    </ol>
  );
}

export function MessageThread({
  orderId, userId, isAdmin, messages, onSent,
}: { orderId: string; userId: string; isAdmin: boolean; messages: OrderMessage[]; onSent: () => void }) {
  const [body, setBody] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  async function send() {
    const text = body.trim();
    if (!text) return;
    setBusy(true); setErr('');
    try { await sendMessage(orderId, userId, isAdmin, text); setBody(''); onSent(); }
    catch (e) { setErr(friendlyError(e)); }
    setBusy(false);
  }
  return (
    <div>
      <ul className="mb-3 max-h-80 space-y-2 overflow-y-auto" aria-live="polite">
        {messages.length === 0 && <li className="text-sm text-slate-500">No messages yet.</li>}
        {messages.map((m) => {
          const mine = m.is_admin === isAdmin;
          return (
            <li key={m.id} className={`max-w-[85%] rounded-2xl px-3 py-2 text-sm ${mine ? 'ml-auto bg-brand-600 text-white' : 'bg-slate-100 text-slate-800'}`}>
              <p className="whitespace-pre-wrap break-words">{m.body}</p>
              <p className={`mt-1 text-[10px] ${mine ? 'text-brand-100' : 'text-slate-400'}`}>{m.is_admin ? 'Uamer Feruak SR' : 'Customer'} · {formatDate(m.created_at, true)}</p>
            </li>
          );
        })}
      </ul>
      {err && <p role="alert" className="mb-2 text-sm text-red-600">{err}</p>}
      <div className="flex gap-2">
        <label htmlFor="msg" className="sr-only">Message</label>
        <input id="msg" className="input" placeholder={isAdmin ? 'Write an update for the customer…' : 'Write a message…'} value={body}
          onChange={(e) => setBody(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') send(); }} maxLength={2000} />
        <button onClick={send} disabled={busy || !body.trim()} className="btn-primary !px-4" aria-label="Send message"><Send className="h-4 w-4" /></button>
      </div>
    </div>
  );
}
