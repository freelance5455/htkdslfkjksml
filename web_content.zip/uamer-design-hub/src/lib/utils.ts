import type { OrderStatus, PaymentStatus } from '../types';

export const DEFAULT_WHATSAPP = '+2348149617851';
export const DEFAULT_PHONE = '+2348149538264';

export const MAX_FILE_BYTES = 25 * 1024 * 1024;
export const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf', 'video/mp4'];
export const ACCEPT_ATTR = '.jpg,.jpeg,.png,.webp,.pdf,.mp4';

export function friendlyError(err: unknown, fallback = 'Something went wrong. Please try again.'): string {
  // Log the technical detail for developers, show a friendly message to people.
  console.error('[UamerHub]', err);
  const msg = String((err as { message?: string })?.message ?? '').toLowerCase();
  if (msg.includes('failed to fetch') || msg.includes('network')) return 'Network problem. Check your connection and try again.';
  if (msg.includes('invalid login')) return 'Incorrect email or password.';
  if (msg.includes('already registered')) return 'An account with this email already exists. Try logging in.';
  if (msg.includes('email not confirmed')) return 'Please confirm your email first, then log in.';
  if (msg.includes('row-level security') || msg.includes('not allowed') || msg.includes('permission')) return 'You do not have permission to do that.';
  return fallback;
}

export function isValidPhone(v: string): boolean {
  const d = v.replace(/[\s()-]/g, '');
  return /^\+?\d{10,15}$/.test(d);
}

/** Normalise a Nigerian-style number to digits with country code for wa.me links. */
export function waDigits(num: string): string {
  let d = num.replace(/\D/g, '');
  if (d.startsWith('0')) d = '234' + d.slice(1);
  return d;
}

export function whatsappLink(number: string, message: string): string {
  return `https://wa.me/${waDigits(number)}?text=${encodeURIComponent(message)}`;
}

export function validateFile(f: File): string | null {
  if (!ALLOWED_TYPES.includes(f.type)) return `${f.name}: unsupported file type. Use JPG, PNG, WEBP, PDF or MP4.`;
  if (f.size > MAX_FILE_BYTES) return `${f.name}: file is too large (max 25 MB).`;
  return null;
}

export function formatBytes(n?: number | null): string {
  if (!n) return '';
  if (n < 1024 * 1024) return `${Math.round(n / 1024)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

export function formatDate(s?: string | null, withTime = false): string {
  if (!s) return '—';
  const d = new Date(s);
  return d.toLocaleDateString('en-NG', { day: 'numeric', month: 'short', year: 'numeric', ...(withTime ? { hour: '2-digit', minute: '2-digit' } : {}) });
}

export function timeAgo(s: string): string {
  const diff = (Date.now() - new Date(s).getTime()) / 1000;
  if (diff < 60) return 'just now';
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}

export const statusStyle: Record<OrderStatus, string> = {
  Pending: 'bg-amber-100 text-amber-800',
  'In Progress': 'bg-blue-100 text-blue-800',
  Review: 'bg-purple-100 text-purple-800',
  Completed: 'bg-green-100 text-green-800',
  Cancelled: 'bg-slate-200 text-slate-700',
};
export const paymentStyle: Record<PaymentStatus, string> = {
  Unpaid: 'bg-red-100 text-red-700',
  'Pending Verification': 'bg-amber-100 text-amber-800',
  Paid: 'bg-green-100 text-green-800',
  Refunded: 'bg-slate-200 text-slate-700',
};

export function safeFileName(n: string): string {
  return n.replace(/[^a-zA-Z0-9._-]/g, '_').slice(-80);
}
