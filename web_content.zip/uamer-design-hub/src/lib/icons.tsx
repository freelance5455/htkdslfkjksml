import {
  Palette, Flag, Mail, Image, Video, Globe, Megaphone, Share2, Sparkles, Camera, Printer,
  PenTool, Layout, Smartphone, Music, Package, type LucideIcon,
} from 'lucide-react';

export const ICONS: Record<string, LucideIcon> = {
  Palette, Flag, Mail, Image, Video, Globe, Megaphone, Share2, Sparkles, Camera, Printer,
  PenTool, Layout, Smartphone, Music, Package,
};
export const ICON_NAMES = Object.keys(ICONS);

export function ServiceIcon({ name, className }: { name: string; className?: string }) {
  const I = ICONS[name] ?? Sparkles;
  return <I className={className} aria-hidden="true" />;
}
