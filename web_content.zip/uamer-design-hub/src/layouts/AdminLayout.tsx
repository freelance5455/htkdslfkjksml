import { Link, NavLink, Outlet } from 'react-router-dom';
import { Bell, CreditCard, LayoutDashboard, LogOut, Package, Settings, Sparkles, Users } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { useNotifications } from '../hooks/useNotifications';
import { Logo } from '../components/ui';

const items = [
  { to: '/admin', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/admin/orders', label: 'Orders', icon: Package },
  { to: '/admin/customers', label: 'Customers', icon: Users },
  { to: '/admin/services', label: 'Services', icon: Sparkles },
  { to: '/admin/payments', label: 'Payments', icon: CreditCard },
  { to: '/admin/settings', label: 'Settings', icon: Settings },
];

export default function AdminLayout() {
  const { session, signOut } = useAuth();
  const { unread } = useNotifications(session?.user.id);
  const side = ({ isActive }: { isActive: boolean }) =>
    `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium ${isActive ? 'bg-white text-brand-800' : 'text-brand-100 hover:bg-white/10'}`;
  const tab = ({ isActive }: { isActive: boolean }) =>
    `flex min-w-[64px] flex-1 flex-col items-center gap-0.5 py-2 text-[10px] font-medium ${isActive ? 'text-brand-700' : 'text-slate-500'}`;

  return (
    <div className="min-h-screen md:flex">
      <aside className="hidden w-60 shrink-0 flex-col bg-brand-800 p-4 md:flex">
        <Link to="/" className="mb-6"><Logo light /></Link>
        <nav className="flex-1 space-y-1" aria-label="Admin">
          {items.map((i) => <NavLink key={i.to} to={i.to} end={i.end} className={side}><i.icon className="h-4 w-4" />{i.label}</NavLink>)}
        </nav>
        <Link to="/notifications" className="mb-1 flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-brand-100 hover:bg-white/10"><Bell className="h-4 w-4" />Notifications{unread > 0 && <span className="ml-auto rounded-full bg-gold-500 px-2 text-xs font-bold text-brand-900">{unread}</span>}</Link>
        <button onClick={signOut} className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-brand-100 hover:bg-white/10"><LogOut className="h-4 w-4" />Logout</button>
      </aside>

      <div className="flex-1 pb-20 md:pb-0">
        <header className="sticky top-0 z-30 flex items-center justify-between bg-brand-800 px-4 py-3 text-white md:hidden">
          <Link to="/" aria-label="Public site"><Logo light /></Link>
          <div className="flex items-center gap-1">
            <Link to="/notifications" className="relative rounded-full p-2" aria-label="Notifications"><Bell className="h-5 w-5" />{unread > 0 && <span className="absolute right-0.5 top-0.5 h-3 w-3 rounded-full bg-gold-500" />}</Link>
            <button onClick={signOut} className="rounded-full p-2" aria-label="Logout"><LogOut className="h-5 w-5" /></button>
          </div>
        </header>
        <div className="mx-auto max-w-6xl p-4 md:p-8"><Outlet /></div>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-40 flex overflow-x-auto border-t border-slate-200 bg-white pb-[env(safe-area-inset-bottom)] md:hidden" aria-label="Admin mobile">
        {items.map((i) => <NavLink key={i.to} to={i.to} end={i.end} className={tab}><i.icon className="h-5 w-5" />{i.label}</NavLink>)}
      </nav>
    </div>
  );
}
