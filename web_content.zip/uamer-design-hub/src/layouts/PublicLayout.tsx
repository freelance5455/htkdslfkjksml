import { Link, NavLink, Outlet, useNavigate } from 'react-router-dom';
import { Bell, ClipboardList, Home, LayoutDashboard, LogIn, Sparkles, User } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { useNotifications } from '../hooks/useNotifications';
import { useSettings } from '../hooks/useSettings';
import { useServicesList } from '../hooks/useServicesList';
import { FloatingWhatsApp, Logo, WhatsAppIcon } from '../components/ui';
import { whatsappLink } from '../lib/utils';

const tab = ({ isActive }: { isActive: boolean }) =>
  `flex flex-1 flex-col items-center gap-0.5 py-2 text-[11px] font-medium ${isActive ? 'text-brand-700' : 'text-slate-500'}`;

export default function PublicLayout() {
  const { session, isAdmin, profile } = useAuth();
  const { unread } = useNotifications(session?.user.id);
  const { settings } = useSettings();
  const nav = useNavigate();
  const services = useServicesList();

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-30 bg-brand-800 text-white shadow">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <Link to="/" aria-label="Uamer Design Hub home"><Logo light /></Link>
          <nav className="hidden items-center gap-6 text-sm font-medium md:flex" aria-label="Main">
            <NavLink to="/" end className="hover:text-gold-400">Home</NavLink>
            <NavLink to="/services" className="hover:text-gold-400">Services</NavLink>
            <NavLink to={session ? '/dashboard' : '/login'} className="hover:text-gold-400">Orders</NavLink>
            <NavLink to={session ? '/profile' : '/login'} className="hover:text-gold-400">Profile</NavLink>
            {isAdmin && <NavLink to="/admin" className="rounded-lg bg-white/10 px-3 py-1.5 hover:bg-white/20">Admin</NavLink>}
          </nav>
          <div className="flex items-center gap-2">
            {session && (
              <button onClick={() => nav('/notifications')} className="relative rounded-full p-2 hover:bg-white/10" aria-label={`Notifications${unread ? `, ${unread} unread` : ''}`}>
                <Bell className="h-5 w-5" />
                {unread > 0 && <span className="absolute right-0.5 top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-gold-500 px-1 text-[10px] font-bold text-brand-900">{unread}</span>}
              </button>
            )}
            {!session && <Link to="/login" className="btn-gold !px-4 !py-2"><LogIn className="h-4 w-4" /> Login</Link>}
            {session && !profile && <span className="text-xs">…</span>}
          </div>
        </div>
      </header>

      <main className="flex-1 pb-20 md:pb-0"><Outlet /></main>

      <footer className="bg-brand-900 text-brand-100">
        <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 pb-28 md:grid-cols-4 md:pb-10">
          <div className="md:col-span-2">
            <Logo light />
            <p className="mt-3 text-sm">Professional Digital Services, Made Simple.</p>
          </div>
          <div>
            <h3 className="mb-2 font-semibold text-white">Services</h3>
            <ul className="space-y-1 text-sm">
              {services.slice(0, 6).map((s) => <li key={s.id}><Link to={`/order?service=${s.id}`} className="hover:text-gold-400">{s.name}</Link></li>)}
              <li><Link to="/services" className="text-gold-400">All services</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="mb-2 font-semibold text-white">Contact</h3>
            <ul className="space-y-1 text-sm">
              <li>{settings.business_name}</li>
              <li><a className="inline-flex items-center gap-1 hover:text-gold-400" href={whatsappLink(settings.whatsapp_number, `Hello ${settings.business_name}, I would like to order a service.`)} target="_blank" rel="noopener noreferrer"><WhatsAppIcon className="h-4 w-4" /> WhatsApp: {settings.whatsapp_number}</a></li>
              <li><a className="hover:text-gold-400" href={`tel:${settings.phone_number}`}>Phone: {settings.phone_number}</a></li>
              <li>{settings.contact_info}</li>
            </ul>
          </div>
        </div>
        <div className="border-t border-white/10 py-4 pb-24 text-center text-xs md:pb-4">© 2026 Uamer Feruak SR. All rights reserved.</div>
      </footer>

      <FloatingWhatsApp />

      {/* Sticky mobile navigation */}
      <nav className="fixed inset-x-0 bottom-0 z-40 flex border-t border-slate-200 bg-white pb-[env(safe-area-inset-bottom)] md:hidden" aria-label="Mobile">
        <NavLink to="/" end className={tab}><Home className="h-5 w-5" />Home</NavLink>
        <NavLink to="/services" className={tab}><Sparkles className="h-5 w-5" />Services</NavLink>
        <NavLink to={session ? '/dashboard' : '/login'} className={tab}><ClipboardList className="h-5 w-5" />Orders</NavLink>
        {isAdmin && <NavLink to="/admin" className={tab}><LayoutDashboard className="h-5 w-5" />Admin</NavLink>}
        <NavLink to={session ? '/profile' : '/login'} className={tab}><User className="h-5 w-5" />Profile</NavLink>
      </nav>
    </div>
  );
}
