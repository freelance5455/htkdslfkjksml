import { Link, Route, Routes } from 'react-router-dom';
import { isConfigured } from './lib/supabase';
import PublicLayout from './layouts/PublicLayout';
import AdminLayout from './layouts/AdminLayout';
import { RequireAdmin, RequireAuth } from './components/Guards';
import Home from './pages/Home';
import ServicesPage from './pages/Services';
import OrderPage from './pages/Order';
import { ForgotPassword, Login, ResetPassword, Signup } from './pages/Auth';
import Dashboard from './pages/Dashboard';
import OrderDetail from './pages/OrderDetail';
import Profile from './pages/Profile';
import Notifications from './pages/Notifications';
import AdminDashboard from './pages/admin/AdminDashboard';
import AdminOrders from './pages/admin/AdminOrders';
import AdminOrderDetail from './pages/admin/AdminOrderDetail';
import AdminCustomers from './pages/admin/AdminCustomers';
import AdminServices from './pages/admin/AdminServices';
import AdminPayments from './pages/admin/AdminPayments';
import AdminSettings from './pages/admin/AdminSettings';

function SetupNotice() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-brand-900 p-6">
      <div className="card max-w-md text-center">
        <h1 className="text-xl font-extrabold text-brand-800">Uamer Design Hub</h1>
        <p className="mt-2 text-sm text-slate-600">
          The app is not connected to Supabase yet. Copy <code>.env.example</code> to <code>.env</code>, add
          <code> VITE_SUPABASE_URL</code> and <code>VITE_SUPABASE_ANON_KEY</code>, then restart. See README.md.
        </p>
      </div>
    </div>
  );
}

function NotFound() {
  return (
    <div className="mx-auto max-w-md p-10 text-center">
      <h1 className="text-2xl font-extrabold text-brand-800">Page not found</h1>
      <p className="mt-2 text-slate-500">The page you are looking for does not exist.</p>
      <Link to="/" className="btn-primary mt-5">Back to Home</Link>
    </div>
  );
}

export default function App() {
  if (!isConfigured) return <SetupNotice />;
  return (
    <Routes>
      <Route element={<PublicLayout />}>
        <Route path="/" element={<Home />} />
        <Route path="/services" element={<ServicesPage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route path="/order" element={<RequireAuth><OrderPage /></RequireAuth>} />
        <Route path="/dashboard" element={<RequireAuth><Dashboard /></RequireAuth>} />
        <Route path="/dashboard/orders/:id" element={<RequireAuth><OrderDetail /></RequireAuth>} />
        <Route path="/profile" element={<RequireAuth><Profile /></RequireAuth>} />
        <Route path="/notifications" element={<RequireAuth><Notifications /></RequireAuth>} />
        <Route path="*" element={<NotFound />} />
      </Route>
      <Route path="/admin" element={<RequireAdmin><AdminLayout /></RequireAdmin>}>
        <Route index element={<AdminDashboard />} />
        <Route path="orders" element={<AdminOrders />} />
        <Route path="orders/:id" element={<AdminOrderDetail />} />
        <Route path="customers" element={<AdminCustomers />} />
        <Route path="services" element={<AdminServices />} />
        <Route path="payments" element={<AdminPayments />} />
        <Route path="settings" element={<AdminSettings />} />
      </Route>
    </Routes>
  );
}
