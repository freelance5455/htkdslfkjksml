export type Role = 'customer' | 'admin';
export const ORDER_STATUSES = ['Pending', 'In Progress', 'Review', 'Completed', 'Cancelled'] as const;
export type OrderStatus = (typeof ORDER_STATUSES)[number];
export const PAYMENT_STATUSES = ['Unpaid', 'Pending Verification', 'Paid', 'Refunded'] as const;
export type PaymentStatus = (typeof PAYMENT_STATUSES)[number];
export type PaymentMethod = 'Bank Transfer' | 'Other';

export interface Profile {
  id: string; full_name: string; email: string | null; whatsapp: string | null;
  role: Role; created_at: string;
}
export interface Service {
  id: string; name: string; description: string; icon: string; is_active: boolean;
  sort_order: number; created_at: string;
}
export interface Order {
  id: string; order_number: number; customer_id: string; service_id: string;
  customer_name: string; customer_whatsapp: string; customer_email: string | null;
  project_title: string; description: string; deadline: string | null;
  additional_notes: string | null; admin_notes: string | null;
  status: OrderStatus; payment_status: PaymentStatus; payment_method: PaymentMethod | null;
  created_at: string; updated_at: string;
  services?: { name: string } | null;
  profiles?: { full_name: string; email: string | null; whatsapp: string | null } | null;
}
export interface OrderFile {
  id: string; order_id: string; uploaded_by: string; kind: 'attachment' | 'payment_proof';
  storage_path: string; file_name: string; mime_type: string | null; size_bytes: number | null;
  created_at: string;
}
export interface HistoryItem { id: string; order_id: string; status: OrderStatus; note: string | null; created_at: string; }
export interface OrderMessage { id: string; order_id: string; sender_id: string; is_admin: boolean; body: string; created_at: string; }
export interface Payment {
  id: string; order_id: string; method: PaymentMethod; amount: number | null; reference: string | null;
  proof_file_id: string | null; status: PaymentStatus; verified_at: string | null; created_at: string;
  orders?: { order_number: number; project_title: string; customer_name: string } | null;
}
export interface AppNotification { id: string; user_id: string; title: string; body: string | null; link: string | null; is_read: boolean; created_at: string; }
export type Settings = Record<string, string>;
