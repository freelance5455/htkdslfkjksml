import { supabase } from '../lib/supabase';
import { safeFileName } from '../lib/utils';
import type {
  AppNotification, HistoryItem, Order, OrderFile, OrderMessage, OrderStatus, Payment,
  PaymentMethod, PaymentStatus, Profile, Service, Settings,
} from '../types';

const BUCKET = 'order-files';
function check<T>(res: { data: T | null; error: unknown }): T {
  if (res.error) throw res.error;
  return res.data as T;
}

/* ---------- settings ---------- */
export async function getSettings(): Promise<Settings> {
  const rows = check(await supabase.from('settings').select('key,value')) as { key: string; value: string }[];
  return Object.fromEntries(rows.map((r) => [r.key, r.value]));
}
export async function saveSettings(s: Settings) {
  const rows = Object.entries(s).map(([key, value]) => ({ key, value, updated_at: new Date().toISOString() }));
  check(await supabase.from('settings').upsert(rows));
}
export async function uploadLogo(file: File): Promise<string> {
  const path = `logo-${Date.now()}-${safeFileName(file.name)}`;
  const up = await supabase.storage.from('branding').upload(path, file, { upsert: true });
  if (up.error) throw up.error;
  return supabase.storage.from('branding').getPublicUrl(path).data.publicUrl;
}

/* ---------- services ---------- */
export async function listServices(includeInactive = false): Promise<Service[]> {
  let q = supabase.from('services').select('*').order('sort_order').order('name');
  if (!includeInactive) q = q.eq('is_active', true);
  return check(await q) as Service[];
}
export async function saveService(s: Partial<Service> & { name: string }) {
  if (s.id) {
    const { id, ...rest } = s;
    check(await supabase.from('services').update(rest).eq('id', id));
  } else check(await supabase.from('services').insert(s));
}
export async function deleteService(id: string) {
  // Orders reference services (ON DELETE RESTRICT). If any exist, disable instead of delete.
  const { count } = await supabase.from('orders').select('id', { count: 'exact', head: true }).eq('service_id', id);
  if (count && count > 0) throw new Error('in-use');
  check(await supabase.from('services').delete().eq('id', id));
}

/* ---------- profiles ---------- */
export async function getProfile(id: string): Promise<Profile | null> {
  const { data } = await supabase.from('profiles').select('*').eq('id', id).maybeSingle();
  return data as Profile | null;
}
export async function updateProfile(id: string, p: { full_name: string; whatsapp: string }) {
  check(await supabase.from('profiles').update(p).eq('id', id));
}
export async function listCustomers(): Promise<(Profile & { order_count: number })[]> {
  const profiles = check(await supabase.from('profiles').select('*').eq('role', 'customer').order('created_at', { ascending: false })) as Profile[];
  const orders = check(await supabase.from('orders').select('customer_id')) as { customer_id: string }[];
  const counts: Record<string, number> = {};
  orders.forEach((o) => { counts[o.customer_id] = (counts[o.customer_id] ?? 0) + 1; });
  return profiles.map((p) => ({ ...p, order_count: counts[p.id] ?? 0 }));
}

/* ---------- orders ---------- */
const ORDER_SELECT = '*, services(name), profiles(full_name,email,whatsapp)';

export async function createOrder(input: {
  customer_id: string; service_id: string; customer_name: string; customer_whatsapp: string;
  customer_email: string | null; project_title: string; description: string;
  deadline: string | null; additional_notes: string | null;
}): Promise<Order> {
  return check(await supabase.from('orders').insert(input).select(ORDER_SELECT).single()) as Order;
}
export async function listMyOrders(userId: string): Promise<Order[]> {
  return check(await supabase.from('orders').select(ORDER_SELECT).eq('customer_id', userId).order('created_at', { ascending: false })) as Order[];
}
export async function listAllOrders(): Promise<Order[]> {
  return check(await supabase.from('orders').select(ORDER_SELECT).order('created_at', { ascending: false })) as Order[];
}
export async function getOrder(id: string): Promise<Order | null> {
  const { data, error } = await supabase.from('orders').select(ORDER_SELECT).eq('id', id).maybeSingle();
  if (error) throw error;
  return data as Order | null;
}
export async function updateOrderStatus(id: string, status: OrderStatus) {
  check(await supabase.from('orders').update({ status }).eq('id', id));
}
export async function updateAdminNotes(id: string, admin_notes: string) {
  check(await supabase.from('orders').update({ admin_notes }).eq('id', id));
}

/* ---------- files ---------- */
export async function uploadOrderFile(
  orderId: string, userId: string, file: File, kind: 'attachment' | 'payment_proof',
  onProgress?: (pct: number) => void,
): Promise<OrderFile> {
  const path = `${orderId}/${crypto.randomUUID()}-${safeFileName(file.name)}`;
  onProgress?.(10);
  const up = await supabase.storage.from(BUCKET).upload(path, file, { contentType: file.type, upsert: false });
  if (up.error) throw up.error;
  onProgress?.(80);
  const row = check(await supabase.from('order_files').insert({
    order_id: orderId, uploaded_by: userId, kind, storage_path: path, file_name: file.name,
    mime_type: file.type, size_bytes: file.size,
  }).select('*').single()) as OrderFile;
  onProgress?.(100);
  return row;
}
export async function listOrderFiles(orderId: string): Promise<OrderFile[]> {
  return check(await supabase.from('order_files').select('*').eq('order_id', orderId).order('created_at')) as OrderFile[];
}
/** Private bucket: files are opened through short-lived signed URLs. */
export async function signedUrl(path: string): Promise<string> {
  const { data, error } = await supabase.storage.from(BUCKET).createSignedUrl(path, 60 * 10);
  if (error) throw error;
  return data.signedUrl;
}

/* ---------- history & messages ---------- */
export async function listHistory(orderId: string): Promise<HistoryItem[]> {
  return check(await supabase.from('order_status_history').select('*').eq('order_id', orderId).order('created_at')) as HistoryItem[];
}
export async function listMessages(orderId: string): Promise<OrderMessage[]> {
  return check(await supabase.from('order_messages').select('*').eq('order_id', orderId).order('created_at')) as OrderMessage[];
}
export async function sendMessage(orderId: string, senderId: string, isAdmin: boolean, body: string) {
  check(await supabase.from('order_messages').insert({ order_id: orderId, sender_id: senderId, is_admin: isAdmin, body }));
}

/* ---------- payments ---------- */
export async function submitPaymentProof(orderId: string, fileId: string, method: PaymentMethod, reference: string) {
  const { error } = await supabase.rpc('submit_payment_proof', {
    p_order_id: orderId, p_file_id: fileId, p_method: method, p_reference: reference || null,
  });
  if (error) throw error;
}
export async function listPayments(orderId?: string): Promise<Payment[]> {
  let q = supabase.from('payments').select('*, orders(order_number,project_title,customer_name)').order('created_at', { ascending: false });
  if (orderId) q = q.eq('order_id', orderId);
  return check(await q) as Payment[];
}
export async function verifyPayment(paymentId: string, status: PaymentStatus) {
  const { error } = await supabase.rpc('verify_payment', { p_payment_id: paymentId, p_status: status });
  if (error) throw error;
}
/** Admin can also mark Paid/Refunded directly on an order that has no proof (e.g. cash/WhatsApp). */
export async function setOrderPayment(orderId: string, payment_status: PaymentStatus) {
  check(await supabase.from('orders').update({ payment_status }).eq('id', orderId));
}

/* ---------- notifications ---------- */
export async function listNotifications(userId: string): Promise<AppNotification[]> {
  return check(await supabase.from('notifications').select('*').eq('user_id', userId).order('created_at', { ascending: false }).limit(50)) as AppNotification[];
}
export async function markNotificationRead(id: string) {
  check(await supabase.from('notifications').update({ is_read: true }).eq('id', id));
}
export async function markAllRead(userId: string) {
  check(await supabase.from('notifications').update({ is_read: true }).eq('user_id', userId).eq('is_read', false));
}
