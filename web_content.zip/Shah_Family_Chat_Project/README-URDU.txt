SHAH FAMILY CHAT — Firebase/Android starter
===========================================
یہ سورس پروجیکٹ ہے، APK فائل نہیں۔ حقیقی آن لائن استعمال کے لیے Firebase config، قواعد، اور Android build درکار ہیں۔

1) Firebase سیٹ اپ
- https://console.firebase.google.com پر نیا project بنائیں۔
- Authentication > Sign-in method میں Email/Password فعال کریں۔
- Firestore Database بنائیں اور Storage کی موجودہ دستیابی/قیمت اپنے project میں چیک کریں۔ مفت Storage ہر project/علاقے میں لازمی نہیں۔
- Project settings > Your apps > Web app سے config حاصل کریں۔
- index.html میں cfg کے PASTE_ placeholders کو اپنی اصل values سے بدلیں۔
- Firestore Rules میں firestore.rules اور Storage Rules میں storage.rules کا متن publish کریں۔

2) Android APK build
کمپیوٹر پر Node.js، Android Studio اور Android SDK درکار ہیں۔ project directory میں چلائیں:
  npm install
  npx cap add android
  npx cap sync android
  npx cap open android
Android Studio میں Gradle sync کے بعد Build > Build APK(s) منتخب کریں۔ عام debug APK path: android/app/build/outputs/apk/debug/app-debug.apk

3) دو فونز پر ٹیسٹ
دونوں فونز پر الگ اکاؤنٹ بنائیں، ایک دوسرے کی ای میل سے چیٹ شروع کریں، پھر text/media/voice/call آزمائیں۔ مائیکروفون اور کیمرہ permissions دیں۔

اہم حدود
- یہ starter implementation ہے؛ production-ready یا مکمل audited app نہیں۔ موجودہ WebRTC call signaling ابتدائی ہے۔ STUN بعض نیٹ ورکس پر کافی نہیں؛ reliable calls کے لیے TURN server/service درکار ہو سکتی ہے، جس پر لاگت آسکتی ہے۔
- پس منظر میں incoming-call notifications، E2E encryption، group calls، abuse protection، retry logic اور Android native call screen شامل نہیں۔
- Storage rules اس demo میں تمام signed-in users کو media پڑھنے دیتی ہیں؛ نجی فیملی استعمال سے پہلے chat-member access کے لیے انہیں مزید سخت کریں۔
- Firebase quotas/pricing بدل سکتے ہیں۔ اپنا Firebase console چیک کریں؛ “مفت” ہونے کی ضمانت نہیں۔
