WIM'S WEIGHT TRACKER — Android Studio project

BELANGRIJK: Dit is de volledige Android Studio-broncode, nog geen APK.
In de huidige werkomgeving is geen Android SDK/Gradle-buildomgeving beschikbaar,
dus ik kan hier geen ondertekende of installeerbare APK compileren.

APK bouwen:
1. Installeer Android Studio op een Windows-, Mac- of Linux-computer.
2. Pak deze ZIP uit.
3. Open de map WimsWeightTracker in Android Studio.
4. Laat Gradle synchroniseren en installeer eventueel Android SDK Platform 35.
5. Kies Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio maakt de APK in app/build/outputs/apk/debug/app-debug.apk.
7. Kopieer die APK naar je Samsung en open ze om te installeren. Mogelijk moet je
   Android toestemming geven om apps uit die bron te installeren.

De app werkt offline, bewaart wegingen lokaal op het toestel en bevat:
dashboard, grafiek, datum/uur/gewicht invoeren, wijzigen/verwijderen,
week- en maandgemiddelden, BMI, doelvoorspelling en CSV-export.

BMI gebruikt 1,85 m als lengte. Pas dit in index.html aan als je lengte verandert.
