-- MyChat starter schema for Supabase PostgreSQL.
-- Run in Supabase Dashboard -> SQL Editor. Review policies before production.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null check (char_length(username) between 3 and 24),
  created_at timestamptz not null default now()
);
create unique index if not exists profiles_username_lower_unique on public.profiles (lower(username));

create table if not exists public.user_roles (
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('owner','admin','moderator')),
  created_at timestamptz not null default now(),
  primary key (user_id, role)
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  title text,
  is_group boolean not null default false,
  owner_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  check (is_group or title is null)
);

create table if not exists public.conversation_members (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (conversation_id,user_id)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 4000),
  created_at timestamptz not null default now()
);
create index if not exists messages_conversation_created_idx on public.messages(conversation_id,created_at);

create or replace function public.has_staff_role(allowed_roles text[])
returns boolean language sql stable security definer
set search_path = '' as $$
  select exists (
    select 1 from public.user_roles ur
    where ur.user_id = (select auth.uid()) and ur.role = any(allowed_roles)
  );
$$;
revoke all on function public.has_staff_role(text[]) from public;
grant execute on function public.has_staff_role(text[]) to authenticated;

-- SECURITY DEFINER helper avoids recursive membership-table RLS checks.
create or replace function public.is_conversation_member(target_conversation uuid)
returns boolean language sql stable security definer
set search_path = '' as $$
  select exists (
    select 1 from public.conversation_members cm
    where cm.conversation_id = target_conversation and cm.user_id = (select auth.uid())
  );
$$;
revoke all on function public.is_conversation_member(uuid) from public;
grant execute on function public.is_conversation_member(uuid) to authenticated;

alter table public.profiles enable row level security;
alter table public.user_roles enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;

grant select, insert, update on public.profiles to authenticated;
grant select on public.user_roles to authenticated;
grant select, insert on public.conversations to authenticated;
grant select, insert, delete on public.conversation_members to authenticated;
grant select, insert on public.messages to authenticated;

drop policy if exists "profiles visible to signed in users" on public.profiles;
create policy "profiles visible to signed in users" on public.profiles
for select to authenticated using (true);
drop policy if exists "users create own profile" on public.profiles;
create policy "users create own profile" on public.profiles
for insert to authenticated with check (id = (select auth.uid()));
drop policy if exists "users update own username" on public.profiles;
create policy "users update own username" on public.profiles
for update to authenticated using (id = (select auth.uid())) with check (id = (select auth.uid()));

drop policy if exists "users read own role rows or staff reads all" on public.user_roles;
create policy "users read own role rows or staff reads all" on public.user_roles
for select to authenticated using (user_id = (select auth.uid()) or public.has_staff_role(array['owner','admin']));

drop policy if exists "members read their conversations" on public.conversations;
create policy "members read their conversations" on public.conversations
for select to authenticated using (
  public.is_conversation_member(id)
  or public.has_staff_role(array['owner','admin'])
);
drop policy if exists "users create conversations they own" on public.conversations;
create policy "users create conversations they own" on public.conversations
for insert to authenticated with check (owner_id=(select auth.uid()));

drop policy if exists "members see memberships" on public.conversation_members;
create policy "members see memberships" on public.conversation_members
for select to authenticated using (
  user_id=(select auth.uid())
  or public.is_conversation_member(conversation_id)
  or public.has_staff_role(array['owner','admin'])
);
drop policy if exists "self join or conversation owner adds member" on public.conversation_members;
create policy "self join or conversation owner adds member" on public.conversation_members
for insert to authenticated with check (
  user_id=(select auth.uid())
  or exists (select 1 from public.conversations c where c.id=conversation_id and c.owner_id=(select auth.uid()))
);
drop policy if exists "conversation owner or self can leave" on public.conversation_members;
create policy "conversation owner or self can leave" on public.conversation_members
for delete to authenticated using (
  user_id=(select auth.uid())
  or exists (select 1 from public.conversations c where c.id=conversation_id and c.owner_id=(select auth.uid()))
  or public.has_staff_role(array['owner','admin'])
);

drop policy if exists "members read messages" on public.messages;
create policy "members read messages" on public.messages
for select to authenticated using (
  public.is_conversation_member(conversation_id)
  or public.has_staff_role(array['owner','admin','moderator'])
);
drop policy if exists "members send as themselves" on public.messages;
create policy "members send as themselves" on public.messages
for insert to authenticated with check (
  sender_id=(select auth.uid())
  and public.is_conversation_member(conversation_id)
);

-- Automatically create a profile after sign-up. Username comes from auth metadata;
-- users can still update their own username afterward.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
declare candidate text;
begin
  candidate := coalesce(new.raw_user_meta_data->>'username', split_part(new.email,'@',1), 'member');
  candidate := left(regexp_replace(candidate, '[^a-zA-Z0-9_.-]', '', 'g'), 24);
  if char_length(candidate) < 3 then candidate := 'user_' || left(new.id::text, 8); end if;
  insert into public.profiles(id,username) values(new.id,candidate)
  on conflict (id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

-- IMPORTANT: after creating your own account and confirming its UUID in
-- Authentication -> Users, assign the owner role manually in the SQL Editor:
-- insert into public.user_roles(user_id, role)
-- values ('YOUR-AUTH-USER-UUID', 'owner');
-- Never let a client app assign roles to itself. Only owner/admin may read roles.
-- In this starter the admin panel is read-only; do not add ban/role editing from
-- the browser without a server-side function and an audit log.
