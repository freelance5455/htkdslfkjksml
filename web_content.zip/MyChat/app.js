/* MyChat starter. Configure Supabase in the form below before using accounts. */
const SUPABASE_URL = ""; // e.g. https://YOUR_PROJECT.supabase.co
const SUPABASE_ANON_KEY = ""; // publishable/anon key only; NEVER put a service-role key here
const $ = (id) => document.getElementById(id);
const state = { mode: "login", user: null, profile: null, role: "user", chats: [], activeChat: null, channel: null, theme: "dark" };
let supabase = null;
const toast = (message) => { const el=$("toast"); el.textContent=message; el.classList.add("show"); setTimeout(()=>el.classList.remove("show"),3200); };
const esc = (s="") => String(s).replace(/[&<>"']/g, c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function showAuthError(msg=""){ $("authError").textContent=msg; }
function setMode(mode){state.mode=mode;$("loginTab").classList.toggle("active",mode==="login");$("signupTab").classList.toggle("active",mode==="signup");$("usernameWrap").classList.toggle("hidden",mode!=="signup");$("username").required=mode==="signup";$("authSubmit").textContent=mode==="login"?"Sign in":"Create account";$("password").autocomplete=mode==="login"?"current-password":"new-password";showAuthError("");}
function setTheme(theme){state.theme=theme;document.documentElement.dataset.theme=theme;localStorage.setItem("mychat-theme",theme);$("themeBtn").textContent=theme==="dark"?"☼":"☾";}
function showView(view){["authView","appView"].forEach(id=>$(id).classList.add("hidden"));$(view).classList.remove("hidden");}
function requireConfig(){if(!SUPABASE_URL||!SUPABASE_ANON_KEY){showAuthError("Setup needed: add your Supabase project URL and publishable/anon key in app.js, then reload.");return false;}return true;}
async function init(){
  setTheme(localStorage.getItem("mychat-theme")||"dark");
  $("loginTab").onclick=()=>setMode("login");$("signupTab").onclick=()=>setMode("signup");
  $("themeBtn").onclick=()=>setTheme(state.theme==="dark"?"light":"dark");
  $("chatKind").onchange=()=> $("groupNameWrap").classList.toggle("hidden",$("chatKind").value!=="group");
  $("newChatBtn").onclick=()=>{$("newChatError").textContent="";$("newChatDialog").showModal();};
  $("backChatsBtn").onclick=()=>showChatArea();
  $("adminBtn").onclick=()=>openAdmin();
  $("signOutBtn").onclick=async()=>{if(supabase)await supabase.auth.signOut();cleanupRealtime();state.user=null;showView("authView");$("signOutBtn").classList.add("hidden");};
  $("authForm").onsubmit=authSubmit;$("newChatForm").onsubmit=createChat;$("messageForm").onsubmit=sendMessage;
  if(!requireConfig()) return;
  try{
    supabase=window.supabase.createClient(SUPABASE_URL,SUPABASE_ANON_KEY);
    const {data:{session}}=await supabase.auth.getSession();
    if(session) await enterApp(session.user);
    supabase.auth.onAuthStateChange(async(event,session)=>{if(session&&(!state.user||state.user.id!==session.user.id))await enterApp(session.user);else if(!session){state.user=null;showView("authView");}});
  }catch(e){showAuthError("Could not connect to Supabase: "+e.message);}
}
async function authSubmit(e){
 e.preventDefault();showAuthError("");if(!requireConfig())return;
 const email=$("email").value.trim(),password=$("password").value;
 $("authSubmit").disabled=true;
 try{
  if(state.mode==="login"){
   const {data,error}=await supabase.auth.signInWithPassword({email,password});if(error)throw error;await enterApp(data.user);
  }else{
   const username=$("username").value.trim();if(username.length<3)throw Error("Username must be at least 3 characters.");
   const {data,error}=await supabase.auth.signUp({email,password,options:{data:{username}}});if(error)throw error;
   if(data.session)await enterApp(data.user);else showAuthError("Account created. Check your email to confirm it, then sign in.");
  }
 }catch(err){showAuthError(err.message||"Authentication failed.");}finally{$("authSubmit").disabled=false;}
}
async function enterApp(user){
 state.user=user;showView("appView");$("signOutBtn").classList.remove("hidden");$("myIdentity").textContent=user.email||"Signed in";
 try{
  const username=(user.user_metadata?.username||user.email?.split("@")[0]||"member").slice(0,24);
  const {error:profileError}=await supabase.from("profiles").upsert({id:user.id,username},{onConflict:"id",ignoreDuplicates:true});
  if(profileError) console.warn("Profile initialization:",profileError.message);
  const {data:roleRows,error:roleError}=await supabase.from("user_roles").select("role").eq("user_id",user.id);
  state.role=roleError?"user":(roleRows?.some(r=>r.role==="owner")?"owner":roleRows?.some(r=>r.role==="admin")?"admin":roleRows?.some(r=>r.role==="moderator")?"moderator":"user");
  $("adminBtn").classList.toggle("hidden",!["owner","admin","moderator"].includes(state.role));
  await loadChats();
 }catch(err){toast("App setup error: "+err.message);}
}
async function loadChats(){
 const {data:members,error}=await supabase.from("conversation_members").select("conversation_id, conversations(id,title,is_group,created_at,owner_id)").eq("user_id",state.user.id);
 if(error){$("chatList").innerHTML=`<p class="muted pad">Chat setup error: ${esc(error.message)}</p>`;return;}
 state.chats=(members||[]).map(x=>x.conversations).filter(Boolean);
 const html=[];
 for(const chat of state.chats){
  let label=chat.title||"Private chat";
  if(!chat.is_group){
   const {data:ms}=await supabase.from("conversation_members").select("user_id, profiles(username)").eq("conversation_id",chat.id);
   const other=(ms||[]).find(x=>x.user_id!==state.user.id);if(other?.profiles?.username)label=other.profiles.username;
  }
  chat.displayTitle=label;
  html.push(`<button class="chat-item ${state.activeChat?.id===chat.id?"selected":""}" data-chat="${chat.id}"><span class="avatar">${esc(label.slice(0,1).toUpperCase())}</span><span><span class="chat-name">${esc(label)}</span><span class="chat-preview">${chat.is_group?"Group conversation":"Private conversation"}</span></span></button>`);
 }
 $("chatList").innerHTML=html.join("")||'<p class="muted pad">No chats yet. Tap “＋ New” to start one.</p>';
 document.querySelectorAll("[data-chat]").forEach(b=>b.onclick=()=>openChat(b.dataset.chat));
}
async function createChat(e){
 e.preventDefault();$("newChatError").textContent="";
 const username=$("memberEmail").value.trim().replace(/^@/,""),kind=$("chatKind").value,title=$("groupName").value.trim();
 $("createChatBtn").disabled=true;
 try{
  const {data:matches,error}=await supabase.from("profiles").select("id,username").ilike("username",username).limit(1);
  if(error)throw error;
  if(!matches?.length)throw Error("Username not found. Ask the person to sign up first and check the spelling.");
  const member=matches[0];
  if(member.id===state.user.id)throw Error("Choose another user's account.");
  const {data:conv,error:convErr}=await supabase.from("conversations").insert({title:kind==="group"?(title||"New group"):null,is_group:kind==="group",owner_id:state.user.id}).select().single();
  if(convErr)throw convErr;
  const {error:memberErr}=await supabase.from("conversation_members").insert([{conversation_id:conv.id,user_id:state.user.id},{conversation_id:conv.id,user_id:member.id}]);
  if(memberErr)throw memberErr;
  $("newChatDialog").close();$("memberEmail").value="";await loadChats();await openChat(conv.id);toast("Chat created.");
 }catch(err){$("newChatError").textContent=err.message;}finally{$("createChatBtn").disabled=false;}
}
async function openChat(id){
 cleanupRealtime();state.activeChat=state.chats.find(c=>c.id===id);if(!state.activeChat)return;
 $("emptyChat").classList.add("hidden");$("adminView").classList.add("hidden");$("chatView").classList.remove("hidden");
 $("chatTitle").textContent=state.activeChat.displayTitle||state.activeChat.title||"Chat";$("chatSubtitle").textContent=state.activeChat.is_group?"Group chat":"Private chat";$("chatType").textContent=state.activeChat.is_group?"GROUP":"PRIVATE";
 await loadMessages();
 state.channel=supabase.channel("messages-"+id).on("postgres_changes",{event:"INSERT",schema:"public",table:"messages",filter:"conversation_id=eq."+id},payload=>renderIncoming(payload.new)).subscribe();
 document.querySelectorAll("[data-chat]").forEach(b=>b.classList.toggle("selected",b.dataset.chat===id));
}
async function loadMessages(){
 const id=state.activeChat.id;
 const {data,error}=await supabase.from("messages").select("id,conversation_id,sender_id,body,created_at,profiles(username)").eq("conversation_id",id).order("created_at",{ascending:true}).limit(200);
 if(error){$("messages").innerHTML=`<p class="error">${esc(error.message)}</p>`;return;}
 $("messages").innerHTML="";(data||[]).forEach(renderIncoming);$("messages").scrollTop=$("messages").scrollHeight;
}
function renderIncoming(m){
 if(!state.activeChat||m.conversation_id!==state.activeChat.id)return;
 if($("messages").querySelector(`[data-message="${m.id}"]`))return;
 const mine=m.sender_id===state.user.id;
 const name=m.profiles?.username||(mine?"You":"Member");
 const time=new Date(m.created_at||Date.now()).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"});
 const el=document.createElement("div");el.className="message"+(mine?" mine":"");el.dataset.message=m.id;
 el.innerHTML=`${state.activeChat.is_group?`<div class="message-author">${esc(name)}</div>`:""}<div>${esc(m.body)}</div><div class="message-time">${esc(time)}</div>`;
 $("messages").appendChild(el);$("messages").scrollTop=$("messages").scrollHeight;
}
async function sendMessage(e){
 e.preventDefault();if(!state.activeChat)return;const body=$("messageInput").value.trim();if(!body)return;
 const btn=$("messageForm").querySelector("button");btn.disabled=true;
 try{const {error}=await supabase.from("messages").insert({conversation_id:state.activeChat.id,sender_id:state.user.id,body});if(error)throw error;$("messageInput").value="";}
 catch(err){toast("Message not sent: "+err.message);}finally{btn.disabled=false;$("messageInput").focus();}
}
function cleanupRealtime(){if(state.channel&&supabase){supabase.removeChannel(state.channel);state.channel=null;}}
function showChatArea(){$("adminView").classList.add("hidden");$("chatView").classList.add("hidden");$("emptyChat").classList.remove("hidden");}
async function openAdmin(){
 showChatArea();$("emptyChat").classList.add("hidden");$("adminView").classList.remove("hidden");
 $("adminNotice").textContent=`Signed in as ${state.role}. Staff actions are restricted by database policies.`;
 if(!["owner","admin","moderator"].includes(state.role)){$("adminContent").textContent="You do not have permission to use this panel.";return;}
 const {data,error}=await supabase.from("profiles").select("id,username,created_at").order("created_at",{ascending:false}).limit(100);
 if(error){$("adminContent").innerHTML=`<p class="error">Could not load users: ${esc(error.message)}</p><p class="muted small">Check the admin policies in schema.sql.</p>`;return;}
 $("adminContent").innerHTML=`<h3>Recent users <span class="muted small">(${data.length} shown)</span></h3><p class="muted small">Read-only in this starter. Role changes and suspensions should be added through audited server-side functions, never trusted to client-side UI.</p><table class="admin-table"><thead><tr><th>Username</th><th>Joined</th><th>Account ID</th></tr></thead><tbody>${data.map(u=>`<tr><td>${esc(u.username)}</td><td>${u.created_at?esc(new Date(u.created_at).toLocaleDateString()):"—"}</td><td>${esc(u.id.slice(0,8))}…</td></tr>`).join("")}</tbody></table>`;
}
window.addEventListener("beforeunload",cleanupRealtime);
init();
