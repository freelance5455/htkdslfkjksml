# MyChat — first test version

This is a starter project, not a finished WhatsApp replacement. It provides a responsive dark/light chat UI, Supabase email/password authentication, private/group conversation records, real-time text messages, and a read-only staff dashboard. Voice/video calls, attachments, push notifications, encryption beyond HTTPS/provider storage protections, moderation actions, and production hardening are not included yet.

## 1. What you need

- Termux installed from a trusted official source.
- Internet access and several GB of free storage for Android build tools.
- A Supabase project (free tier may be enough for testing).
- Do not publish passwords, database service-role keys, or signing keys.

## 2. Configure the backend

1. Create a Supabase project.
2. Open **SQL Editor**, paste all of `schema.sql`, and run it.
3. In **Project Settings → API**, copy the Project URL and the publishable/anon key.
4. Edit `app.js` and fill in `SUPABASE_URL` and `SUPABASE_ANON_KEY`.
   Only the publishable/anon key belongs in client code. Never use a service-role/secret key in the app.
5. In Supabase Authentication settings, configure email confirmation and allowed redirect URLs for your eventual hosted site.
6. Create two test accounts. In Authentication → Users, copy your own user UUID. In SQL Editor run:
   ```sql
   insert into public.user_roles(user_id, role)
   values ('YOUR-UUID-HERE', 'owner');
   ```
7. Test sign-in and sign-up. New chats are found by exact username; profiles do not expose email addresses. Ask the other person for their username.

## 3. Test the interface in Termux

```sh
pkg update
pkg install nodejs-lts
mkdir -p ~/MyChat
# Copy this project folder into ~/MyChat, then:
cd ~/MyChat
```

A simple local web server can serve the files:
```sh
npx --yes http-server . -p 8080
```
Open `http://127.0.0.1:8080` in the phone browser. This tests the interface; Supabase must be configured for account/chat actions to work. Some browser auth redirect behavior requires a hosted HTTPS origin.

## 4. Building an APK entirely on-device

A web app is not itself an APK. Current Capacitor Android workflows officially expect Android SDK tooling and Android Studio, so a phone-only build needs a separately configured on-device Android toolchain. One community option is `termux-android-build`; another is `termux-android-studio`. These are third-party projects, not official Android tools. Inspect their repository, install script, permissions and source before running anything. Never blindly pipe a downloaded script into a shell.

After a suitable toolchain is installed, the next packaging step is to add a Capacitor Android shell or create a small native Android WebView wrapper around the hosted MyChat web app, then build and sign it. The exact commands depend on which on-device toolchain is compatible with your phone and Android version. Keep the signing keystore backed up; future updates must use the same signing key.

Android's official command-line build overview:
https://developer.android.com/build/building-cmdline

Capacitor's current Android environment requirements:
https://capacitorjs.com/docs/getting-started/environment-setup

## 5. Security checklist before real users

- Keep row-level security enabled on every exposed database table.
- Test that one user cannot read another user's private messages.
- Never trust a hidden button as an authorization control; enforce all permissions in database policies/server functions.
- The current staff panel is read-only. Add audited server-side functions before allowing suspensions, role changes, or message deletion.
- The starter has no end-to-end encryption. Do not describe it as end-to-end encrypted.
- Add abuse reporting, blocking, rate limits, account recovery, privacy policy, and deletion/export workflows before public launch.
- Voice/video calls need WebRTC signaling and usually a TURN relay; implement only after messaging and access controls are tested.

## Current limitation

The starter supports username lookup. Before public launch, move conversation creation and membership changes into a database RPC or server-side function so creation is atomic and add more tests for group membership and role permissions.
