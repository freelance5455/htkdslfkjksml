const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const STORE = 'forgeFitnessDashboard_v1';
const plans = {
  Push:{focus:'Chest, shoulders & triceps',items:[['Barbell bench press','3 sets × 6–8 reps','Compound'],['Incline dumbbell press','3 sets × 8–10 reps','Upper chest'],['Seated shoulder press','3 sets × 8–10 reps','Shoulders'],['Lateral raises','3 sets × 12–15 reps','Isolation'],['Triceps pushdowns','3 sets × 10–12 reps','Triceps']]},
  Pull:{focus:'Back, rear delts & biceps',items:[['Lat pulldown','3 sets × 8–12 reps','Back'],['Chest-supported row','3 sets × 8–12 reps','Back'],['Seated cable row','2 sets × 10–12 reps','Back'],['Face pulls','3 sets × 12–15 reps','Rear delts'],['Dumbbell curls','3 sets × 10–12 reps','Biceps']]},
  Legs:{focus:'Quads, hamstrings & calves',items:[['Goblet squat or leg press','3 sets × 8–12 reps','Quads'],['Romanian deadlift','3 sets × 8–10 reps','Hamstrings'],['Leg curl','3 sets × 10–12 reps','Hamstrings'],['Leg extension','2 sets × 12–15 reps','Quads'],['Standing calf raises','3 sets × 12–15 reps','Calves']]},
  Rest:{focus:'Recovery & mobility',items:[['Easy walk','10–20 minutes','Recovery'],['Gentle mobility','5–10 minutes','Mobility'],['Prepare meals and sleep','Plan your recovery','Lifestyle']]}
};
const defaultState = {name:'',weight:56,proteinGoal:100,weightLogs:[],sessions:[],foods:[],checks:{},day:'Push'};
let state;
try { state = {...defaultState,...JSON.parse(localStorage.getItem(STORE)||'{}')}; } catch { state = {...defaultState}; }
function save(){localStorage.setItem(STORE,JSON.stringify(state));renderAll();}
function toast(msg){const el=$('#toast');el.textContent=msg;el.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.classList.remove('show'),2400);}
function dateKey(d=new Date()){return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
function todayFoods(){return state.foods.filter(f=>f.date===dateKey());}
function todayChecks(){return state.checks[dateKey()]?.[state.day]||[];}
function renderPlan(){
 const p=plans[state.day]||plans.Push;$('#focusTitle').textContent=p.focus;
 $$('#dayTabs button').forEach(b=>b.classList.toggle('active',b.dataset.day===state.day));
 const checks=todayChecks();
 $('#exerciseList').innerHTML=p.items.map((item,i)=>`<label class="exercise-row ${checks.includes(i)?'done':''}"><input class="exercise-check" type="checkbox" data-index="${i}" ${checks.includes(i)?'checked':''}><span class="exercise-info"><strong>${item[0]}</strong><small>${item[1]}</small></span><span class="exercise-badge">${item[2]}</span></label>`).join('');
 $('#exerciseProgress').textContent=`${checks.length} of ${p.items.length} exercises checked`;
}
function renderStats(){
 $('#workoutCount').textContent=state.sessions.length;
 $('#weightDisplay').textContent=Number(state.weight).toLocaleString('en-IN');
 $('#proteinDisplay').textContent=state.proteinGoal;
 const now=new Date(), day=now.getDay(), monday=new Date(now);monday.setDate(now.getDate()-(day===0?6:day-1));monday.setHours(0,0,0,0);
 const count=state.sessions.filter(s=>new Date(s.date+'T12:00:00')>=monday).length;
 $('#weekCount').innerHTML=`${count}<small class="unit"> / 4</small>`;
 $('#today').textContent=now.toLocaleDateString('en-IN',{weekday:'short',day:'numeric',month:'short'});
 $('#nameInput').value=state.name||'';$('#settingsWeight').value=state.weight;$('#settingsProtein').value=state.proteinGoal;
}
function renderChart(){
 const svg=$('#weightChart'), logs=state.weightLogs.slice(-7);const W=500,H=170,L=30,R=15,T=15,B=25;
 if(!logs.length){svg.innerHTML=`<text x="250" y="82" text-anchor="middle" fill="#858b7b" font-size="12">Your weight trend will appear here</text>`;$('#weightTrend').textContent='Add your first entry';return;}
 const vals=logs.map(x=>Number(x.weight)),min=Math.min(...vals)-1,max=Math.max(...vals)+1,span=max-min||1;
 const pts=vals.map((v,i)=>({x:logs.length===1?W/2:L+i*(W-L-R)/(logs.length-1),y:T+(max-v)/span*(H-T-B),v,log:logs[i]}));
 const path=pts.map((p,i)=>`${i?'L':'M'} ${p.x} ${p.y}`).join(' ');
 const grid=[0,1,2].map(i=>{let y=T+i*(H-T-B)/2;return `<line x1="${L}" y1="${y}" x2="${W-R}" y2="${y}" stroke="#34372f" stroke-dasharray="3 5"/><text x="${L-7}" y="${y+4}" text-anchor="end" fill="#858b7b" font-size="10">${(max-i*span/2).toFixed(1)}</text>`}).join('');
 svg.innerHTML=`${grid}<path d="${path} L ${pts[pts.length-1].x} ${H-B} L ${pts[0].x} ${H-B} Z" fill="#c4f45d" opacity=".08"/><path d="${path}" fill="none" stroke="#c4f45d" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>${pts.map(p=>`<circle cx="${p.x}" cy="${p.y}" r="4" fill="#c4f45d" stroke="#191b18" stroke-width="2"><title>${p.log.date}: ${p.v} kg</title></circle>`).join('')}${pts.map(p=>`<text x="${p.x}" y="${H-5}" text-anchor="middle" fill="#858b7b" font-size="9">${p.log.date.slice(5)}</text>`).join('')}`;
 if(vals.length>1){const diff=vals[vals.length-1]-vals[0];$('#weightTrend').textContent=`${diff>0?'+':''}${diff.toFixed(1)} kg over ${vals.length} entries`;}else $('#weightTrend').textContent='First entry saved';
}
function renderHistory(){
 $('#historyCount').textContent=`${state.sessions.length} session${state.sessions.length===1?'':'s'}`;
 const sessions=[...state.sessions].reverse().slice(0,5);
 $('#historyList').innerHTML=sessions.length?sessions.map(s=>`<div class="history-item"><strong>${s.day} day</strong><span>${new Date(s.date+'T12:00:00').toLocaleDateString('en-IN',{day:'numeric',month:'short'})} · ${s.checked} exercises</span></div>`).join(''):'<p class="empty-state">Your completed sessions will appear here.</p>';
}
function renderNutrition(){
 const foods=todayFoods(),total=foods.reduce((n,f)=>n+Number(f.protein),0),pct=Math.min(100,total/state.proteinGoal*100);
 $('#proteinTotal').textContent=Number(total.toFixed(1));$('#goalText').textContent=state.proteinGoal;
 $('#proteinRing').style.background=`conic-gradient(var(--lime) ${pct*3.6}deg,#34382c ${pct*3.6}deg)`;
 $('#proteinBar').style.width=pct+'%';
 $('#foodList').innerHTML=foods.length?foods.map(f=>`<div class="food-item"><span>${escapeHtml(f.name)}</span><span>${Number(f.protein)} g</span></div>`).join(''):'<p class="empty-state">Add foods to track your daily total.</p>';
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function renderAll(){renderPlan();renderStats();renderChart();renderHistory();renderNutrition();}
$('#dayTabs').addEventListener('click',e=>{const b=e.target.closest('[data-day]');if(!b)return;state.day=b.dataset.day;renderPlan();});
$('#exerciseList').addEventListener('change',e=>{if(!e.target.matches('.exercise-check'))return;const key=dateKey();state.checks[key]??={};state.checks[key][state.day]??=[];const idx=Number(e.target.dataset.index),arr=state.checks[key][state.day];state.checks[key][state.day]=e.target.checked?[...new Set([...arr,idx])]:arr.filter(x=>x!==idx);renderPlan();localStorage.setItem(STORE,JSON.stringify(state));});
$('#finishWorkout').addEventListener('click',()=>{const checked=todayChecks().length;if(!checked){toast('Check off at least one exercise first.');return;}if(state.sessions.some(s=>s.date===dateKey()&&s.day===state.day)){toast('This workout is already logged today.');return;}state.sessions.push({date:dateKey(),day:state.day,checked});save();toast('Session logged. Nice work!');});
$('#weightForm').addEventListener('submit',e=>{e.preventDefault();const weight=Number($('#weightInput').value);if(weight<20||weight>350)return toast('Enter a valid weight in kg.');state.weight=weight;state.weightLogs.push({date:dateKey(),weight});$('#weightInput').value='';save();toast('Weight entry saved.');});
$('#proteinForm').addEventListener('submit',e=>{e.preventDefault();const name=$('#foodName').value.trim(),protein=Number($('#foodProtein').value);if(!name||protein<=0)return;state.foods.push({name,protein,date:dateKey()});$('#foodName').value='';$('#foodProtein').value='';save();toast('Food added to today’s log.');});
$('#resetProtein').addEventListener('click',()=>{if(!todayFoods().length)return toast('Today’s food log is already empty.');if(confirm('Reset today’s food log?')){state.foods=state.foods.filter(f=>f.date!==dateKey());save();toast('Today’s food log reset.');}});
$('#settingsForm').addEventListener('submit',e=>{e.preventDefault();const weight=Number($('#settingsWeight').value),goal=Number($('#settingsProtein').value);if(weight<20||weight>350||goal<20||goal>350)return toast('Please check the weight and protein goal.');state.name=$('#nameInput').value.trim();state.weight=weight;state.proteinGoal=goal;if(!state.weightLogs.length||state.weightLogs[state.weightLogs.length-1].date!==dateKey())state.weightLogs.push({date:dateKey(),weight});else state.weightLogs[state.weightLogs.length-1].weight=weight;save();toast('Your settings are saved.');});
$('#clearData').addEventListener('click',()=>{if(confirm('Clear all Forge workout, nutrition, weight and settings data saved in this browser? This cannot be undone.')){localStorage.removeItem(STORE);state={...defaultState,weightLogs:[],sessions:[],foods:[],checks:{}};save();toast('Saved data cleared.');}});
$('#menuBtn').addEventListener('click',()=>$('#sidebar').classList.toggle('open'));
$$('.nav-item').forEach(a=>a.addEventListener('click',()=>$('#sidebar').classList.remove('open')));
renderAll();
