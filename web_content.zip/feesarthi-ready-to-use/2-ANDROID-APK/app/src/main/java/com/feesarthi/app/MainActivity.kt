package com.feesarthi.app

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.webkit.WebViewAssetLoader
import java.io.File

/**
 * FeeSarthi – WebView wrapper.
 * A normal WebView cannot print, download blobs or share files, so this class gives the web app
 * a small native bridge (window.AndroidBridge) for: Save PDF / Print, Download, WhatsApp share, Copy.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private var startHost = ""

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        val startUrl = getString(R.string.start_url).trim()
        startHost = if (startUrl.isNotEmpty()) (Uri.parse(startUrl).host ?: "") else ""

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.setSupportZoom(false)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                return loader.shouldInterceptRequest(request.url)
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                val host = u.host ?: ""
                val webScheme = u.scheme == "https" || u.scheme == "http"
                val internal = webScheme &&
                    (host == WebViewAssetLoader.DEFAULT_DOMAIN || (startHost.isNotEmpty() && host == startHost))
                if (internal) return false
                openExternal(u)   // wa.me, upi://, tel:, mailto:, other sites -> open in the proper app
                return true
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(typeof appBack==='function')?String(appBack()):'false'") { r ->
                    if (r == null || !r.contains("true")) {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })

        web.loadUrl(
            if (startUrl.isNotEmpty()) startUrl
            else "https://" + WebViewAssetLoader.DEFAULT_DOMAIN + "/assets/www/index.html"
        )
    }

    override fun onDestroy() {
        web.removeJavascriptInterface("AndroidBridge")
        super.onDestroy()
    }

    // ---------------------------------------------------------------- helpers
    private fun toast(msg: String) {
        runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
    }

    private fun safe(name: String): String = name.replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "file" }

    private fun openExternal(u: Uri) {
        try {
            val intent = if (u.scheme == "intent") Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME)
            else Intent(Intent.ACTION_VIEW, u)
            startActivity(intent)
        } catch (e: Exception) {
            toast("यह लिंक खोल नहीं सका / Cannot open link")
        }
    }

    private fun whatsappPackage(): String? {
        for (p in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            try {
                packageManager.getPackageInfo(p, 0)
                return p
            } catch (e: Exception) { /* not installed */ }
        }
        return null
    }

    // ---------------------------------------------------------------- JS bridge
    inner class Bridge {

        @JavascriptInterface
        fun isNative(): Boolean = true

        /** Save a file to Downloads/FeeSarthi (raseed photo, Excel CSV ...). */
        @JavascriptInterface
        fun saveFile(name: String, mime: String, b64: String): Boolean {
            return try {
                val bytes = Base64.decode(b64, Base64.DEFAULT)
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, safe(name))
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/FeeSarthi")
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("insert failed")
                contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                toast("सेव हो गया ✓  Downloads/FeeSarthi/" + safe(name))
                true
            } catch (e: Exception) {
                toast("सेव नहीं हो सका: " + e.message)
                false
            }
        }

        /** Share a file. If [phone] is given and WhatsApp is installed, tries to open that chat directly. */
        @JavascriptInterface
        fun shareFile(name: String, mime: String, b64: String, text: String, phone: String) {
            try {
                val dir = File(cacheDir, "shared").apply { mkdirs() }
                val f = File(dir, safe(name))
                f.writeBytes(Base64.decode(b64, Base64.DEFAULT))
                val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", f)
                runOnUiThread {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = mime
                        putExtra(Intent.EXTRA_STREAM, uri)
                        if (text.isNotEmpty()) putExtra(Intent.EXTRA_TEXT, text)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    val wa = whatsappPackage()
                    try {
                        if (phone.isNotEmpty() && wa != null) {
                            send.setPackage(wa)
                            send.putExtra("jid", phone.filter { it.isDigit() } + "@s.whatsapp.net")
                            startActivity(send)
                        } else {
                            startActivity(Intent.createChooser(send, "भेजें / Share"))
                        }
                    } catch (e: Exception) {
                        try {
                            send.setPackage(null)
                            startActivity(Intent.createChooser(send, "भेजें / Share"))
                        } catch (e2: Exception) {
                            toast("Share नहीं हो सका / Cannot share")
                        }
                    }
                }
            } catch (e: Exception) {
                toast("Share नहीं हो सका: " + e.message)
            }
        }

        @JavascriptInterface
        fun copyText(t: String) {
            runOnUiThread {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("FeeSarthi", t))
                toast("कॉपी हो गया ✓")
            }
        }

        /** Opens Android's print screen -> choose "Save as PDF" or a printer. */
        @JavascriptInterface
        fun printPage(title: String, landscape: Boolean) {
            runOnUiThread {
                try {
                    val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
                    val size = if (landscape) PrintAttributes.MediaSize.ISO_A4.asLandscape()
                    else PrintAttributes.MediaSize.ISO_A4
                    val attrs = PrintAttributes.Builder().setMediaSize(size).build()
                    val job = safe(title)
                    pm.print(job, web.createPrintDocumentAdapter(job), attrs)
                } catch (e: Exception) {
                    toast("Print नहीं हो सका: " + e.message)
                }
            }
        }

        /** Opens WhatsApp directly on the chat of [phone] (country code + number) with [text] pre-filled. */
        @JavascriptInterface
        fun openWhatsApp(phone: String, text: String) {
            runOnUiThread {
                val digits = phone.filter { it.isDigit() }
                val uri = Uri.parse("https://wa.me/" + digits + "?text=" + Uri.encode(text))
                val wa = whatsappPackage()
                try {
                    val i = Intent(Intent.ACTION_VIEW, uri)
                    if (wa != null) i.setPackage(wa)
                    startActivity(i)
                } catch (e: Exception) {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, uri))
                    } catch (e2: Exception) {
                        toast("WhatsApp नहीं खुला – क्या WhatsApp इंस्टॉल है?")
                    }
                }
            }
        }

        @JavascriptInterface
        fun openUrl(u: String) {
            runOnUiThread { openExternal(Uri.parse(u)) }
        }
    }
}
