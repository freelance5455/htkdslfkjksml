# फीस सारथी (FeeSarthi) – Ready to Use

Is zip mein do cheezein hain:

| Folder | Kya hai |
|---|---|
| `1-WEBSITE/` | Website (ek `index.html`) + Firebase rules + phone icon. Hosting par daalni hai. |
| `2-ANDROID-APK/` | Android app project. Isse APK banta hai jisme WhatsApp, PDF, Download sab chalte hain. |

## Sabse pehle (2 minute) – bina Firebase ke chalana
`1-WEBSITE/index.html` ko Chrome mein kholein -> naya school banayein. Firebase config na bhari ho to data sirf us phone/browser mein rehta hai.

## Asli use ka rasta (sab phones par ek jaisa data)
1. **Firebase banayein** (free): Authentication me Email/Password + Phone enable, Firestore Database create.
   Steps: `1-WEBSITE/README.md`.
2. `1-WEBSITE/index.html` ke upar `FIREBASE_CONFIG` mein apni values daalein; `firestore.rules` Publish karein.
3. Website host karein (Firebase Hosting / Netlify / GitHub Pages) -> aapko `https://...` link milega.
4. **APK**: `2-ANDROID-APK/app/src/main/res/values/strings.xml` mein `start_url` me apna https link daalein,
   phir APK banayein (`2-ANDROID-APK/README-APK.md`: Android Studio ya GitHub Actions).
5. APK install karke login karein. Pehla account Admin banta hai; staff Sign up karke seedha Clerk ban jaate hain (Admin ki manzoori nahi chahiye). Admin Settings se kisi ko Admin/Disabled kar sakta hai.

## Buttons jo ab kaam karte hain (APK mein)
- **WhatsApp:** usi bacche ke parent ke number par WhatsApp khulta hai, raseed ka message likha hua.
- **Share Photo:** raseed ki photo WhatsApp ke zariye bhejna.
- **Photo / PDF Download:** `Downloads/FeeSarthi/` mein save.
- **Print / Class sheet PDF:** Android print screen -> "Save as PDF".
- **Excel (CSV) / Copy:** Downloads mein CSV file, ya copy karke Excel mein paste.

## Zaroor padhein
- APK maine yahan build karke nahi dekha (yahan Android SDK nahi hai). Build mein error aaye to screenshot bhejein.
- Asli SMS OTP aur Firebase ka kharch/seema Firebase ki current sharton par hai; WebView mein OTP kabhi-kabhi reCAPTCHA se atak sakta hai.
- Hafte mein ek baar Settings -> Backup se copy rakhein.


## Raseed number aur signature
- Pehli baar setup karte waqt chunein ki raseed number kahan se shuru ho (jaise 1000 -> 1000, 1001, 1002 ...). Baad mein Admin Settings -> "Receipt Number" se agla number badal sakta hai (purane number se peeche nahi ja sakta).
- Teen mahine ek saath jama karne par ek hi raseed banti hai, aur wahi number teeno mahine mein dikhta hai.
- Raseed page par teen option: WhatsApp (photo ke saath), PDF download, raseed (photo) download.
- Fees jama karte waqt ungli se sign sahi na aaye to "hastakshar ki photo upload karein" dabayein: safed kagaz par pen se sign ki photo chunein; background apne-aap hat jata hai aur wahi har raseed par lagta hai.

- **Fee ke mahine:** school banate waqt chunein kitne mahine ki fees lagti hai (12, ya 11 jun chhodkar, ya apne hisaab se mahine chunein). Sirf wahi mahine fee table, Add Fees, class sheet aur bakaya mein aate hain. Baad mein Settings -> "Fee Months" se badal sakte hain (jis mahine ki raseed ban chuki ho use hata nahi sakte).

- **Login / Sign up (naya, saaf tareeka):** pehle ek simple page aata hai. Naya school ho to "Naya school shuru karein" (3 chhote kadam); school pehle se ho to "Login karein" ya "Naya khata banayein" (staff). Sign up ke baad staff seedha login ho jaata hai (Admin ki manzoori nahi chahiye).

- **Logo:** app ke logo mein Maa Saraswati ki tasveer hai (veena, lotus aur halo ke saath). Apne school ka logo lagana ho to school banate waqt (kadam 1) ya Settings -> "School ka logo" se photo chunein; wapas Saraswati logo bhi laga sakte hain.

- **Suraksha chetavani:** jab tak Admin ki manzoori nahi hai, jisko bhi aapki website/APK ka link milega wo Sign up karke Clerk ban sakta hai aur bacchon ka data dekh sakta hai. Link sirf staff ko dein, aur Settings -> Users mein anjaan naam dikhe to use "Disabled" kar dein.
