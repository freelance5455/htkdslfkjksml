# फीस सारथी (FeeSarthi) – पहले ये पढ़ें

## Problem kyun aa rahi thi?
Online "website to APK" converters ka WebView **sirf page dikhata hai**. Usme:
logo/photo upload, PDF save, download, WhatsApp-photo share **band** rehte hain (ye converter ki seema hai, app ki galti nahi).
Chrome ya hamara APK project inhe chalne deta hai.

## Sabse aasan aur pakka raasta (phone se, 10 minute) – Chrome mein "Install app"
1. Zip ko phone ki **Files** app mein "Extract" karein.
2. github.com par free account banayein -> **New repository** (Public, naam `fees`).
3. **Add file -> Upload files**: `1-WEBSITE` folder ke **saare files** chunein (index.html, sw.js, manifest.json, icons, rules...) -> Commit.
   (Phone mein dikkat ho to Chrome ka menu -> "Desktop site" chalu karein.)
4. **Settings -> Pages** -> Branch: `main` / `/ (root)` -> Save. 1-2 minute baad link: `https://<aapka-naam>.github.io/fees/`
5. Is link ko **Chrome** mein kholein -> menu (⋮) -> **"Install app" / "Add to Home screen"**. Ab ye asli app ki tarah khulega.

Isme sab kaam karta hai: logo/signature photo upload, **PDF save**, **download**, Print, aur WhatsApp.

## WhatsApp kaise kaam karta hai
| Jagah | "WhatsApp पर भेजें" dabane par |
|---|---|
| Chrome / Installed app (https) | Share menu khulta hai (photo ke saath) -> WhatsApp chunein |
| APK (hamare Android project se) | WhatsApp seedha khulta hai, usi number par, photo ke saath |
| Jahan share nahi chalta | Raseed ki photo download hoti hai aur WhatsApp **usi number ki chat** mein khulta hai -> 📎 se photo jodein |
| "सिर्फ संदेश भेजें" | Hamesha usi number par WhatsApp khulta hai, raseed ka message likha hua |
Dhyan: Chrome ka share menu khud se contact nahi chun sakta; number-wali chat ke liye "सिर्फ संदेश" ya APK wala tareeka use karein.

## APK chahiye to
- **Poori suvidha ke saath:** `2-ANDROID-APK` folder se banayein (computer par Android Studio, ya GitHub Actions) – `2-ANDROID-APK/README-APK.md`.
- **Aasan:** hosted https link se pwabuilder.com par "Package for Android". (URL bar dikh sakti hai kyunki GitHub link aapka domain nahi hota.)
- Online converter se banane par upar wali seemayein rahengi.

## Asli data ke liye (sab phones par ek jaisa)
`1-WEBSITE/README.md` – Firebase banana, `index.html` mein config bharna, `firestore.rules` Publish karna.

## Zip mein
- `1-WEBSITE/` – website (flat folder, seedha upload ho jata hai)
- `2-ANDROID-APK/` – Android project (native bridge: WhatsApp, PDF, download, photo-upload)
- `3-EXTRAS/` – logo SVG aur icon banwane ka prompt

## Pehle jaisa: Admin ki manzoori
Naya staff Sign up karta hai -> khata "manzoori baaki" rehta hai -> Admin: Settings -> Users -> naam ke aage **Clerk** chunta hai -> tab login chalta hai.

## Zaroor jaanein
- APK project maine yahan build karke nahi dekha (yahan Android SDK nahi hai); web ka hissa test hua hai.
- Hafte mein ek baar Settings -> Backup se copy rakhein.
