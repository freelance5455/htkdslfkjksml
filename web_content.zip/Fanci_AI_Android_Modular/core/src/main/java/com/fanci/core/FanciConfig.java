package com.fanci.core;

public final class FanciConfig {
    private FanciConfig() {}
    public static final String APP_NAME = "Fanci AI";
    public static final String CHAT_ENDPOINT = "https://fanci-ai-production.up.railway.app/chat";
    public static final String VERSION_NAME = "1.2.0";
}
