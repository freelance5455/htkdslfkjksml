# Fanci AI WebView bridge rules
-keepclassmembers class com.fanci.ai.FanciBridge { public *; }
