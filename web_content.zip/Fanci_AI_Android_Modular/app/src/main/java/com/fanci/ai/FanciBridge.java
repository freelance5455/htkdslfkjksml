package com.fanci.ai;

import android.webkit.JavascriptInterface;
import android.speech.tts.TextToSpeech;
import java.util.Locale;

public final class FanciBridge {
    private final TextToSpeech tts;
    public FanciBridge(TextToSpeech tts) { this.tts = tts; }
    @JavascriptInterface public void speak(String text) {
        if (tts != null) tts.speak(text == null ? "" : text, TextToSpeech.QUEUE_FLUSH, null, "fanci");
    }
}
