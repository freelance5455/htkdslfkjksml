# Fanci AI 1.2.0 — Android Modular

Modules:
- `app`: Android application, WebView UI, gallery/camera file chooser, native TTS bridge.
- `core`: shared Fanci configuration.

AI architecture:
Android APK -> Railway `/chat` -> OpenRouter.
The OpenRouter API key is NOT stored in this project or APK.

Build with Android Studio:
1. Open this folder.
2. Let Gradle sync (Gradle 8.7 + Android Gradle Plugin 8.5.2).
3. Build > Generate App Bundle / APK > Generate APK.

For a local/Termux build with Android SDK configured:
`./gradlew assembleDebug`

Release:
`./gradlew assembleRelease`

Note: this source archive intentionally does not contain Gradle caches, SDK files, or node_modules. Those are build dependencies and would unnecessarily inflate the ZIP.
