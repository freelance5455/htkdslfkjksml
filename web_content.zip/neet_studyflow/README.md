# NEET StudyFlow

A responsive, chapter-wise NEET study checklist built with plain HTML, CSS, and JavaScript.

## Features
- Class 11 and Class 12 chapter lists for Physics, Chemistry, and Biology
- Per-chapter checklists for NCERT Reading, PYQ Practice, and Short Notes
- Dashboard with overall and subject-wise progress
- Search and subject filters
- Chapter-specific short-notes editor with automatic local saving
- Progress report, pending-task overview, JSON export, and reset
- Responsive layout for desktop and mobile

## Run
1. Unzip the folder.
2. Open `index.html` in a modern browser.
3. Start checking off tasks. Data is stored in that browser's localStorage.

No backend or build tools are required. This is a frontend-only starter; data remains on the current device/browser.
