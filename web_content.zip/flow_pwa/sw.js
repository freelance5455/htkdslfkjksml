// 值班 v6.1 — 离线优先：同源静态资源全部预缓存。
const CACHE='zhiban-v63-short-title';
const APP_SHELL=['./','./index.html','./manifest.webmanifest','./icon.svg','./v2.js?v=63','./vault.js?v=63','./prefill.js?v=63','./shift-clock.js?v=63','./online-temp.js?v=63'];
self.addEventListener('install',event=>{
  event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(APP_SHELL)).then(()=>self.skipWaiting()));
});
self.addEventListener('activate',event=>{
  event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key.startsWith('zhiban-')&&key!==CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim()));
});
self.addEventListener('fetch',event=>{
  const req=event.request;
  if(req.method!=='GET')return;
  const url=new URL(req.url);
  if(url.origin!==self.location.origin)return;
  if(req.mode==='navigate'){
    event.respondWith(caches.match('./index.html').then(cached=>cached||caches.match('./')).then(cached=>cached||fetch(req)));
    return;
  }
  event.respondWith(caches.match(req).then(hit=>hit||fetch(req).then(response=>{
    if(response.ok&&response.type==='basic'){
      const copy=response.clone();event.waitUntil(caches.open(CACHE).then(cache=>cache.put(req,copy)));
    }
    return response;
  })));
});
self.addEventListener('message',event=>{
  if(event.data&&event.data.type==='CHECK_OFFLINE_CACHE'){
    event.waitUntil(caches.open(CACHE).then(async cache=>{
      const results=await Promise.all(APP_SHELL.map(url=>cache.match(url)));
      event.source?.postMessage({type:'OFFLINE_CACHE_STATUS',ready:results.every(Boolean),cached:results.filter(Boolean).length,total:APP_SHELL.length});
    }));
  }
});
