/* 值班 v5.4 线上核检多物料模板（兼容 v5.3 本地模板与草稿） */
(()=>{'use strict';
const SECTIONS=['温度计校准','第一次测温','第二次测温','成品测温','第四次测温','第五次测温'];
const TKEY='zhiban_online_temperature_templates_v53',DKEY='zhiban_online_temperature_drafts_v53',NKEY='zhiban_online_temperature_material_names_v55',NOTEKEY='zhiban_online_temperature_notes_v57',CALKEY='zhiban_online_temperature_calibration_v58',MODEKEY='zhiban_online_temperature_entry_modes_v59';
const RULES=[['配料台上',1,5],['配料台下',1,4],['饮料冰箱',1,4],['冷冻库',null,-18],['冷藏库',1,3],['副食',1,4],['果汁机',1,5],['汇集烤架',74,null]];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const read=(k,f)=>{try{return JSON.parse(localStorage.getItem(k)||'null')??f}catch{return f}};
const write=(k,x)=>localStorage.setItem(k,JSON.stringify(x));
const day=()=>{const d=new Date();if(d.getHours()<2)d.setDate(d.getDate()-1);return d.toLocaleDateString('sv-SE')};
const empty=()=>Object.fromEntries(SECTIONS.map(s=>[s,[]]));
function ruleFor(label,section){if(section==='温度计校准')return null;if(section==='成品测温')return {min:75,max:null,desc:'≥75℃'};const entry=RULES.find(x=>label.includes(x[0]));if(!entry)return null;const [,min,max]=entry;return {min,max,desc:min===null?`≤${max}℃`:max===null?`≥${min}℃`:`${min}–${max}℃`}}
function valid(r,v){if(!r)return true;return (r.min===null||v>=r.min)&&(r.max===null||v<=r.max)}
// 模板格式允许：冷藏库；配料台上方：起司、小番茄；配料台上方：起司 2℃ 、 小番茄 3℃。
function parseLine(line){line=String(line||'').trim();if(!line)return null;const m=line.match(/^([^：:]+)(?:[：:](.*))?$/);if(!m)return null;const label=m[1].trim().replace(/\s*[+-]?\d+(?:\.\d+)?\s*℃\s*$/,'').trim();if(!label)return null;const tail=(m[2]||'').trim();let items=tail?tail.split(/[、，,;；]+/).map(x=>x.trim().replace(/\s*[+-]?\d+(?:\.\d+)?\s*℃?\s*$/,'').trim()).filter(Boolean):[];return {label,items:[...new Set(items)]}}
function normalizedTemplate(x){if(typeof x==='string')return parseLine(x);if(x&&typeof x==='object'&&typeof x.label==='string')return {label:x.label,items:(Array.isArray(x.items)?x.items:[]).map(i=>typeof i==='string'?i:i?.name).filter(Boolean)};return null}
function normalizeDraft(x){if(!x||typeof x!=='object')return null;return {label:x.label,items:Array.isArray(x.items)?x.items.map(i=>({name:i.name||'',number:String(i.number??'')})):[{name:'',number:String(x.number??'')}]}}
let templates={...empty(),...read(TKEY,{})};for(const s of SECTIONS)templates[s]=(templates[s]||[]).map(normalizedTemplate).filter(Boolean);
let materialNames=read(NKEY,[]);function collectNames(){materialNames=[...new Set([...materialNames,...SECTIONS.flatMap(k=>(templates[k]||[]).flatMap(t=>t.items||[]))].map(x=>String(x).trim()).filter(Boolean))];write(NKEY,materialNames)}collectNames();
const fmt=v=>v===''?'':(Number.isFinite(Number(v))?Number(v).toFixed(1):v);
let calibration=read(CALKEY,{});let persisted=read(DKEY,{}),values={...empty(),...(persisted[day()]||{})},active=0,layer=null,notes={...Object.fromEntries(SECTIONS.map(k=>[k,''])),...((read(NOTEKEY,{})||{})[day()]||{})};
function reconcile(){for(const s of SECTIONS){const old=(values[s]||[]).map(normalizeDraft).filter(Boolean);values[s]=(templates[s]||[]).map(t=>{const prior=old.find(v=>v.label===t.label);const names=t.items.length?t.items:[''];return {label:t.label,items:names.map((name,i)=>({name,number:prior?.items.find(x=>x.name===name)?.number??((prior?.items.length===1&&names.length===1)?prior.items[0].number:'')}))}})}}
reconcile();
let savedModes=read(MODEKEY,{});let entryModes={...((savedModes[day()]||{}))};for(const sec of SECTIONS.slice(1)){if(!entryModes[sec])entryModes[sec]=(values[sec]||[]).some(r=>r.items.some(it=>it.number!==''))?'template':'choice'}
function saveModes(){write(MODEKEY,{...read(MODEKEY,{}),[day()]:entryModes})}
function save(){write(DKEY,{...read(DKEY,{}),[day()]:values});write(NOTEKEY,{...read(NOTEKEY,{}),[day()]:notes});write(CALKEY,calibration)}
function rowOutput(row){const parts=row.items.map(it=>it.name?`${it.name}${it.number!==''?' '+fmt(it.number)+'℃':''}`:(it.number!==''?fmt(it.number)+'℃':''));return `${row.label}：${parts.join('、')}`}
function copyText(){return SECTIONS[active]==='温度计校准'?`温度计校准：${calibration[day()]!==undefined&&calibration[day()]!==''?fmt(calibration[day()])+'℃':''}`:(values[SECTIONS[active]]||[]).map(rowOutput).join('\n')}
function outer(){return `<div class="zb-temp-page" id="zbTempOverlay"><div class="zb-temp-page-head"><div><h2>线上核检预填</h2></div><div class="zb-top-actions"><button class="btn secondary" data-t-action="ref">查看温度表格</button><button class="btn secondary" data-t-action="notes">备注</button><button class="btn secondary" data-t-action="close">← 返回</button></div></div><div id="zbTempInner"></div></div>`}
function noteEditor(){const over=document.createElement('div');over.className='zb-temp-pop';over.innerHTML=`<div class="zb-temp-dialog"><div class="zb-temp-head"><strong>编辑各栏备注</strong><button class="btn secondary" data-note-close>关闭</button></div>${SECTIONS.map((section,i)=>`<label class="zb-note-edit-row"><span>${i+1}. ${esc(section)}</span><textarea rows="2" data-note-edit="${esc(section)}" placeholder="填写栏目备注">${esc(notes[section]||'')}</textarea></label>`).join('')}<button class="btn" style="width:100%;margin-top:12px" data-note-save>保存备注</button></div>`;layer.appendChild(over);over.addEventListener('click',e=>{if(e.target===over||e.target.closest('[data-note-close]'))over.remove();if(e.target.closest('[data-note-save]')){over.querySelectorAll('[data-note-edit]').forEach(t=>notes[t.dataset.noteEdit]=t.value);save();over.remove();render()}})}
function status(row,section){const rule=ruleFor(row.label,section);if(row.items.every(it=>it.number===''))return '待填写';if(row.items.some(it=>it.number!==''&&(!Number.isFinite(Number(it.number))||!valid(rule,Number(it.number)))))return '⚠ 超出范围，请核对';return row.items.some(it=>it.number==='')?'部分已填写':'✓ 合格'}
function inner(section){const list=values[section]||[];const isCal=section==='温度计校准';const mode=entryModes[section]||'choice';const cal=String(calibration[day()]??'');const cv=cal===''?null:Number(cal);const calBad=cv!==null&&(!Number.isFinite(cv)||cv< -1||cv>1);
const heading=`<div class="zb-temp-head"><strong>${esc(section)}</strong>${isCal?'':mode==='choice'?'':`<div class="zb-head-mini"><button class="btn secondary" data-t-action="edit">批量编辑模板</button><button class="btn secondary" data-t-action="${mode==='direct'?'use-last':'direct'}">${mode==='direct'?'使用上次模板':'直接编辑'}</button><button class="btn secondary" data-t-action="names">保存物料名称</button></div>`}</div>${notes[section]?`<div class="zb-inline-note">${esc(notes[section])}</div>`:''}`;
const chooser=`<div class="zb-temp-entry-chooser"><button class="btn secondary" data-t-action="direct">直接编辑</button><button class="btn" data-t-action="use-last">使用上次模板</button></div>`;
const directEditor=`<div class="zb-temp-direct"><label>直接预填（每行一个位置，可包含多个物料）</label><textarea rows="4" data-t-direct placeholder="配料台上方：起司、小番茄\n冷藏库">${esc((list||[]).map(r=>r.label+(r.items.some(it=>it.name)?'：'+r.items.map(it=>it.name).join('、'):'')).join('\n'))}</textarea><button class="btn secondary" data-t-action="apply-direct">应用到本栏</button><div class="hint">输入位置和物料名称，点击应用后填写温度；点击“保存物料名称”才能保存成下次可用的模板。</div></div>`;
const rows=`<div class="zb-temp-list">${list.map((row,i)=>{const rule=ruleFor(row.label,section),st=status(row,section);return `<div class="zb-temp-row zb-temp-multi ${st.startsWith('⚠')?'bad':''}" data-t-row="${i}"><div class="zb-temp-label">${esc(row.label)}<div class="zb-temp-range">${rule?'参考：'+rule.desc:row.label.includes('配料台')?'请写明上方或下方':'未匹配参考范围'}</div></div><div class="zb-temp-items">${row.items.map((it,j)=>`<label class="zb-temp-item"><span class="zb-material-edit"><input class="zb-material-name" value="${esc(it.name)}" placeholder="物料名称（可编辑）" data-t-name="${i}" data-t-sub="${j}" autocomplete="off"><span class="zb-name-suggest" hidden></span></span><span class="zb-temp-right"><input type="number" step="0.1" inputmode="decimal" placeholder="数字" data-t-input="${i}" data-t-sub="${j}" value="${esc(it.number)}" aria-label="${esc(row.label+' '+it.name)}温度"><span>℃</span></span></label>`).join('')}</div><div class="zb-temp-check">${st}</div></div>`}).join('')||'<div class="hint" style="padding:15px">请先输入测温位置和物料名称，点击“应用到本栏”。</div>'}</div>`;
return heading+(isCal?`<div class="zb-calibration ${calBad?'bad':''}"><label>温度计校准 <small>合格范围 -1.0～1.0℃</small></label><div class="zb-cal-input"><input type="number" step="0.1" inputmode="decimal" data-t-cal value="${esc(cal)}" placeholder="输入校准温度"><span>℃</span></div><div class="zb-cal-status">${cv===null?'待填写':calBad?'⚠ 超出范围，请核对': '✓ 合格'}</div></div>`:mode==='choice'?chooser:(mode==='direct'?directEditor:'')+rows)+ (mode==='choice'?'':`<div class="zb-temp-actions zb-two-actions"><button class="btn secondary" data-t-action="save">保存草稿</button><button class="btn" data-t-action="copy">复制本栏</button></div>${isCal?'':`<div class="zb-temp-preview"><strong>复制内容预览</strong><pre>${esc(copyText())}</pre></div>`}`)}

function render(){if(layer&&layer.isConnected)layer.querySelector('#zbTempInner').innerHTML=SECTIONS.map(section=>`<section class="zb-temp-section" data-t-sectionpanel="${esc(section)}">${inner(section)}</section>`).join('')}
function reference(){const rows=[['冷冻库','≤ -18℃'],['冷藏库','1–3℃'],['副食','1–4℃'],['配料台上方','1–5℃'],['配料台下方','1–4℃'],['饮料冰箱','1–4℃'],['果汁机','1–5℃'],['汇集烤架','≥74℃'],['成品测温（所有项目）','≥75℃'],['温度计校准','-1～1℃']];const overlay=document.createElement('div');overlay.className='zb-temp-pop';overlay.innerHTML=`<div class="zb-temp-dialog"><div class="zb-temp-head"><strong>参考温度表格</strong><button class="btn secondary" data-ref-close>关闭</button></div><table class="zb-temp-table"><thead><tr><th>位置</th><th>合格范围</th></tr></thead><tbody>${rows.map(([n,r])=>`<tr><td>${n}</td><td>${r}</td></tr>`).join('')}</tbody></table></div>`;layer.appendChild(overlay);overlay.addEventListener('click',e=>{if(e.target===overlay||e.target.closest('[data-ref-close]'))overlay.remove()})}
function saveNames(){const section=SECTIONS[active];templates[section]=(values[section]||[]).map(row=>({label:row.label,items:row.items.map(it=>it.name.trim()).filter(Boolean)}));write(TKEY,templates);collectNames();save();render();alert('物料名称已保存到模板，下次只需填写温度')}
function suggestions(input,query,apply){const host=input.parentElement.querySelector('.zb-name-suggest');if(!host)return;const words=materialNames.filter(x=>query.trim()&&x.includes(query.trim())&&x!==query.trim()).slice(0,6);host.replaceChildren();host.hidden=!words.length;words.forEach(w=>{let b=document.createElement('button');b.type='button';b.textContent=w;b.className='zb-name-option';b.addEventListener('mousedown',e=>e.preventDefault());b.addEventListener('click',()=>{apply(w);host.hidden=true});host.append(b)})}
function showEditorHints(ta){const at=ta.selectionStart;const before=ta.value.slice(0,at);const frag=before.split(/[：:、，,;；\n]/).at(-1)||'';const q=frag.replace(/\s*[+-]?\d+(?:\.\d+)?\s*℃?$/,'').trim();suggestions(ta,q,w=>{const start=at-frag.length;ta.value=ta.value.slice(0,start)+w+ta.value.slice(at);ta.focus();ta.setSelectionRange(start+w.length,start+w.length);showEditorHints(ta)})}
function editor(){const s=SECTIONS[active],over=document.createElement('div');over.className='zb-temp-pop';over.innerHTML=`<div class="zb-temp-dialog"><div class="zb-temp-head"><strong>编辑「${esc(s)}」模板</strong><button class="btn secondary" data-edit-cancel>取消</button></div><p class="hint">每行一个测温位置。可写「配料台上方：起司、小番茄」，也可直接粘贴「配料台上方：起司 2℃ 、 小番茄 3℃」；保存后仅保留名称，不保存温度数字。</p><textarea id="zbTempTplText" rows="9" style="width:100%;border:1px solid #d4e2e7;border-radius:10px;padding:11px;box-sizing:border-box">${esc((templates[s]||[]).map(t=>t.label+(t.items.length?'：'+t.items.join('、'):'')).join('\n'))}</textarea><div class="zb-name-suggest zb-edit-suggest" hidden></div><div class="zb-temp-actions"><button class="btn" data-edit-save>保存模板</button></div></div>`;layer.appendChild(over);const editorText=over.querySelector('#zbTempTplText');editorText.addEventListener('input',()=>showEditorHints(editorText));editorText.addEventListener('click',()=>showEditorHints(editorText));over.addEventListener('click',e=>{if(e.target===over||e.target.closest('[data-edit-cancel]'))over.remove();if(e.target.closest('[data-edit-save]')){const lines=over.querySelector('#zbTempTplText').value.split(/\r?\n/).map(parseLine).filter(Boolean);templates[s]=lines;write(TKEY,templates);collectNames();reconcile();save();over.remove();render()}})}
async function copy(){save();const txt=copyText();try{await navigator.clipboard.writeText(txt);alert('已复制本栏测温内容')}catch{prompt('请长按复制',txt)}}
function show(){
 const main=document.getElementById('main');if(!main)return;
 document.getElementById('hero').textContent='线上核检预填';
 main.innerHTML=outer();layer=main.querySelector('#zbTempOverlay');
 layer.addEventListener('click',e=>{
  const panel=e.target.closest('[data-t-sectionpanel]');if(panel)active=SECTIONS.indexOf(panel.dataset.tSectionpanel);
  const cmd=e.target.closest('[data-t-action]')?.dataset.tAction;
  if(cmd==='close'){save();layer=null;window.render?.();return}
  if(cmd==='ref')reference();if(cmd==='notes')noteEditor();if(cmd==='edit')editor();if(cmd==='names')saveNames();
  if(cmd==='direct'){entryModes[SECTIONS[active]]='direct';saveModes();render()}
  if(cmd==='use-last'){const sec=SECTIONS[active];if(!(templates[sec]||[]).length){alert('本栏还没有保存过模板，请先直接编辑并保存物料名称');return}entryModes[sec]='template';reconcile();saveModes();save();render()}
  if(cmd==='apply-direct'){const sec=SECTIONS[active],ta=panel?.querySelector('[data-t-direct]');if(!ta)return;const lines=ta.value.split(/\r?\n/).map(parseLine).filter(Boolean);const old=values[sec]||[];values[sec]=lines.map(t=>{const oldRow=old.find(x=>x.label===t.label);return {label:t.label,items:(t.items.length?t.items:['']).map(name=>({name,number:oldRow?.items.find(x=>x.name===name)?.number||''}))}});save();render()}

  if(cmd==='save'){save();alert('本栏草稿已保存')}
  if(cmd==='copy')copy();
 });
 layer.addEventListener('input',e=>{
  const panel=e.target.closest('[data-t-sectionpanel]');if(panel)active=SECTIONS.indexOf(panel.dataset.tSectionpanel);
  const section=SECTIONS[active];
  if(e.target.dataset.tCal!==undefined){calibration[day()]=e.target.value;save();const num=e.target.value===''?null:Number(e.target.value);const bad=num!==null&&(!Number.isFinite(num)||num< -1||num>1);const box=e.target.closest('.zb-calibration');box.classList.toggle('bad',bad);box.querySelector('.zb-cal-status').textContent=num===null?'待填写':bad?'⚠ 超出范围，请核对':'✓ 合格';return}
  if(e.target.dataset.tName!==undefined){
   const i=Number(e.target.dataset.tName),j=Number(e.target.dataset.tSub),row=values[section][i];
   row.items[j].name=e.target.value;save();panel.querySelector('.zb-temp-preview pre').textContent=copyText();
   suggestions(e.target,e.target.value,w=>{e.target.value=w;row.items[j].name=w;save();panel.querySelector('.zb-temp-preview pre').textContent=copyText()});return;
  }
  const i=e.target.dataset.tInput,j=e.target.dataset.tSub;if(i===undefined)return;
  const row=values[section][Number(i)];row.items[Number(j)].number=e.target.value;save();
  const st=status(row,section),el=e.target.closest('.zb-temp-row');el.classList.toggle('bad',st.startsWith('⚠'));
  el.querySelector('.zb-temp-check').textContent=st;panel.querySelector('.zb-temp-preview pre').textContent=copyText();
 });
 layer.addEventListener('change',e=>{
  if(e.target.dataset.tCal!==undefined){if(e.target.value!==''&&Number.isFinite(Number(e.target.value))){e.target.value=fmt(e.target.value);calibration[day()]=e.target.value;save()}return}
  if(e.target.dataset.tInput===undefined)return;
  const panel=e.target.closest('[data-t-sectionpanel]');active=SECTIONS.indexOf(panel.dataset.tSectionpanel);
  const i=Number(e.target.dataset.tInput),j=Number(e.target.dataset.tSub),it=values[SECTIONS[active]][i].items[j];
  if(it.number!==''&&Number.isFinite(Number(it.number))){it.number=fmt(it.number);e.target.value=it.number;save();panel.querySelector('.zb-temp-preview pre').textContent=copyText()}
 });
 render();
}
function picker(){const overlay=document.createElement('div');overlay.className='overlay';overlay.innerHTML=`<div class="modal" role="dialog" aria-modal="true" style="max-width:440px"><div class="modal-head"><h2>晚班预填表格</h2><button class="close" data-choose="close">关闭 ×</button></div><p class="hint">请选择需要填写的表格，数据分别独立保存。</p><div class="zb-temp-actions" style="display:grid;grid-template-columns:1fr 1fr"><button class="btn secondary" data-choose="report">日报预填</button><button class="btn" data-choose="temp">线上核检预填</button></div></div>`;document.body.appendChild(overlay);overlay.addEventListener('click',e=>{const choice=e.target.closest('[data-choose]')?.dataset.choose;if(e.target===overlay||choice==='close'){overlay.remove();return}if(choice){overlay.remove();if(choice==='report')window.openZbDailyReport?.();else show()}})}
window.openZbOnlineTemp=show;window.openZbPrefillMenu=picker;
})();
