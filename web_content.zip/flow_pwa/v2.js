/* 值班 v2：在原 v1.1 状态上扩展，保留原存储键和原任务功能 */
const NORMAL_ROLES=['拍卷发饼','配料','敲单','副食','司炉','外场','汇集+饮料'];
const OPENING_ROLES=['解冻','饮料','PRP','干货架','汇集+司炉','配料线+副食','收货安排'];
const CLOSING_ROLES=['解冻','洗刷','饮料','外场','内场','司炉汇集','休息室+垃圾桶'];
const DEFAULT_GOAL='进炉 ≤ 3 分钟｜出餐 ≤ 12 分钟\n有效好评 ≥ 5（抖音好评不算）';
function initV2(){
  state.staff??=[];state.roles??={normal:NORMAL_ROLES.slice(),closing:CLOSING_ROLES.slice()};
  state.rosters??=[];state.rosterDraft??=null;state.defaultGoal??=DEFAULT_GOAL;state.dailyRevenue??={};state.morningOpeningRoles??=OPENING_ROLES.slice(); state.morningOpeningRoles=OPENING_ROLES.slice();
  if(!Array.isArray(state.roles.normal))state.roles.normal=NORMAL_ROLES.slice();
  if(!Array.isArray(state.roles.closing))state.roles.closing=CLOSING_ROLES.slice();
  save();
}
initV2();
let rosterStage='people',rosterRole=null,rosterKind='normal',rosterFilter='all',rosterWarn=null;
let statsRoleView='normal';
const originalRender=render;
const origCloseModal=closeModal;
function shiftPeople(){return state.rosterDraft||{early:[],late:[],normal:{},closing:{},goal:state.defaultGoal}}
function makeDraft(){return {id:'r'+Date.now(),date:dayKey(),early:[],late:[],normal:{},closing:{},opening:{},receiving:false,receivingTime:'',goal:state.defaultGoal,shiftType:state.uiShift||'evening',createdAt:new Date().toISOString()}}
function draft(){if(!state.rosterDraft||state.rosterDraft.date!==dayKey()||(state.rosterDraft.shiftType||'evening')!==(state.uiShift||'evening')){state.rosterDraft=makeDraft();save()}state.rosterDraft.opening??={};state.rosterDraft.receiving??=false;state.rosterDraft.receivingTime??='';return state.rosterDraft}
function getStaff(id){return state.staff.find(x=>x.id===id)}
function hasShift(id){return draft().early.includes(id)||draft().late.includes(id)}
function rankOf(id,role,kind){const p=getStaff(id);return p?(kind==='closing'||p.allRound?0:(p.ranks||[]).indexOf(role)):-1}
function jobCount(id){return Object.values(draft().normal).filter(a=>a.includes(id)).length}
function roleText(map,roles){return roles.map(r=>`${r}｜${(map[r]||[]).map(id=>getStaff(id)?.name||'已删除员工').join('、')}`).join('\n')}
function displayRole(role){return role==='拍卷发饼'?'拍卷发':role}
function rosterDateLabel(date){const m=String(date||dayKey()).match(/^(\d{4})-(\d{2})-(\d{2})$/);return m?`${Number(m[2])}.${Number(m[3])}`:String(date||'')}
function rosterText(r){
 const staffNames=r.staffNames||{};
 const textFor=(map,roles)=>roles.map(role=>`${displayRole(role)}｜${(map?.[role]||[]).map(id=>staffNames[id]||getStaff(id)?.name||'已删除员工').join('、')}`).join('\n');
 const basic=textFor(r.normal,r.normalRoleNames||state.roles.normal);
 const hasClosing=Object.values(r.closing||{}).some(a=>Array.isArray(a)&&a.length);
 const closing=r.shiftType==='morning'?'':hasClosing?'\n\n打烊安排🧹 ：\n'+textFor(r.closing,r.closingRoleNames||state.roles.closing):'';
 const opening=r.shiftType==='morning'?'\n\n开早准备：\n'+textFor(r.opening,(r.openingRoleNames||state.morningOpeningRoles||OPENING_ROLES).filter(x=>r.receiving||x!=='收货安排'))+(r.receiving?'\n收货准备：'+(r.receivingTime||'未设置时间')+'之前':''):'';
 const revenue=r.forecastRevenue??state.dailyRevenue?.[r.date];
 return `【${rosterDateLabel(r.date)} ${r.shiftType==='morning'?'早班':'晚班'}岗位】\n全天预估营业额：${revenue==null?'未填写':Number(revenue)}\n\n${basic}\n\n当天目标🎯 :\n${r.goal??DEFAULT_GOAL}${opening}${closing}`;
}
function showRevenueGate(){
 const date=dayKey();
 if(Object.prototype.hasOwnProperty.call(state.dailyRevenue,date))return;
 const root=document.getElementById('modalRoot');
 root.innerHTML=`<div class="overlay revenue-gate"><div class="modal" role="dialog" aria-modal="true" aria-labelledby="revenueTitle"><div class="modal-head"><h2 id="revenueTitle">填写今日预估营业额</h2></div><p class="hint">${esc(date)} · 今天首次进入「值班」，请先保存全天预估营业额，再开始排岗和工作。</p><div class="field"><label for="dailyRevenueInput">全天预估营业额（元）</label><input type="number" id="dailyRevenueInput" min="0" max="999999999" step="0.01" inputmode="decimal" placeholder="例如 15651" autocomplete="off" required></div><button class="btn wide" id="saveDailyRevenue">保存并进入值班</button><p class="hint" style="margin-top:12px">一天只填写一次。之后可在工作台修改，当天排岗会自动使用最新预估值。</p></div></div>`;
 const button=document.getElementById('saveDailyRevenue'),field=document.getElementById('dailyRevenueInput');
 const submit=()=>{let raw=field.value.trim(),amount=Number(raw);if(!raw||!Number.isFinite(amount)||amount<0||amount>999999999){toast('请输入有效的非负营业额');field.focus();return}state.dailyRevenue[date]=amount;save();root.innerHTML='';render();toast('今日预估营业额已保存');setTimeout(bootShift,100)};
 button.onclick=submit;field.onkeydown=e=>{if(e.key==='Enter')submit()};field.focus();
}
function editDailyRevenue(){
 const date=dayKey(),current=state.dailyRevenue[date];let v=prompt('修改 '+date+' 全天预估营业额（元）',current??'');if(v===null)return;v=v.trim();const amount=Number(v);if(!v||!Number.isFinite(amount)||amount<0||amount>999999999)return toast('营业额格式不正确');state.dailyRevenue[date]=amount;save();render();toast('今日预估营业额已更新');
}

function v2Page(title,body){document.getElementById('hero').textContent=title;document.getElementById('main').innerHTML=body}
function renderV2(){
 const oldRow=document.querySelector('.hero-title-row');
 if(oldRow){const hero=oldRow.querySelector('#hero');oldRow.parentNode.insertBefore(hero,oldRow);oldRow.remove()}
 if(tab==='prefill'){
  v2Page('预填表格',`<div class="prefill-hub">
    <button type="button" class="prefill-hub-card" id="prefillDailyEntry"><span class="prefill-hub-icon">▤</span><span class="prefill-hub-info"><strong>日报预填</strong><small>提前填写经营数据，自动保存日报草稿</small></span><span class="prefill-hub-arrow">›</span></button>
    <button type="button" class="prefill-hub-card" id="prefillOnlineEntry"><span class="prefill-hub-icon temp">♨</span><span class="prefill-hub-info"><strong>线上核检预填</strong><small>六栏测温、物料模板与合格范围核对</small></span><span class="prefill-hub-arrow">›</span></button>
  </div>`);
  document.getElementById('prefillDailyEntry').onclick=()=>window.openZbDailyReport?.();
  document.getElementById('prefillOnlineEntry').onclick=()=>window.openZbOnlineTemp?.();
  return;
 }
 if(tab==='staff')return renderStaff();
  if(tab==='statistics')return renderStats();
  if(tab==='roster')return renderRoster();
 originalRender();
 if(tab==='reports'){
  const el=document.getElementById('main');
  el.insertAdjacentHTML('afterbegin',`<div class="panel"><h3>👥 智能排岗</h3><p>选择早晚班 → 普通排岗 → 打烊安排 → 一键复制、归档。</p><button class="btn wide" id="enterRoster">开始智能排岗</button></div>`);
  document.getElementById('enterRoster').onclick=()=>{tab='roster';rosterStage='people';render()};
 }
 if(tab==='home'){
  const amount=state.dailyRevenue?.[dayKey()],main=document.getElementById('main');
  // 优先显示当天正在编辑的人员选择；未选人时回退至今天最后保存的排岗。
  const live=state.rosterDraft?.date===dayKey()?state.rosterDraft:null;
  const saved=(Array.isArray(state.rosters)?state.rosters:[]).filter(r=>r.date===dayKey()).sort((a,b)=>String(b.savedAt||b.createdAt||'').localeCompare(String(a.savedAt||a.createdAt||'')))[0];
  const useDraft=!!(live&&((live.early?.length||0)||(live.late?.length||0)));
  const source=useDraft?live:saved;
  const lateCount=new Set(source?.late||[]).size;
  const earlyCount=new Set(source?.early||[]).size;
  // Compact inline counters alongside the hero title, no separate personnel panel.
  let hero=document.getElementById('hero');
  hero.insertAdjacentHTML('afterend',`<div id="inlineCrew" class="inline-crew" aria-label="今日值班人数"><span class="crew-mini late">晚班 <b>${lateCount}</b>人</span><span class="crew-mini early">早班滞留 <b>${earlyCount}</b>人</span></div>`);
  const titleRow=document.createElement('div');titleRow.className='hero-title-row';
  hero.parentNode.insertBefore(titleRow,hero);
  titleRow.appendChild(hero);
  titleRow.appendChild(document.getElementById('inlineCrew'));
  const revenueLabel=amount==null?'待填写':Number(amount).toLocaleString('zh-CN')+'元';
  titleRow.insertAdjacentHTML('beforeend',`<button type="button" class="revenue-mini" id="editRevenue" title="点击修改今日预估营业额" aria-label="今日预估营业额 ${revenueLabel}，点击修改"><span>预估</span><b>${revenueLabel}</b><span aria-hidden="true">✎</span></button>`);
  document.getElementById('editRevenue').onclick=editDailyRevenue;
}
 if(tab==='settings'){document.getElementById('main').insertAdjacentHTML('afterbegin','<div class="panel"><h3>管理中心</h3><p>人员和岗位资料统一在这里管理。</p><button class="settings-link" id="settingsStaff">👥 人员与岗位管理 <span>›</span></button></div>');document.getElementById('settingsStaff').onclick=()=>setTab('staff');document.querySelectorAll('[data-shift-history]').forEach(b=>b.onclick=()=>showShiftArchive(b.dataset.shiftHistory));}
}
render=function(){renderV2();if(!Object.prototype.hasOwnProperty.call(state.dailyRevenue,dayKey()))showRevenueGate()};
function setTab(name){closeModal();tab=name;document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));render()}
const nav=document.querySelector('.bottom');
nav.insertAdjacentHTML('beforeend','<button class="tab" data-tab="statistics"><span class="ico">▥</span>统计</button>');
document.getElementById('topSettings').onclick=()=>setTab('settings');
nav.querySelectorAll('.tab').forEach(b=>b.onclick=()=>setTab(b.dataset.tab));
document.querySelector('style').append('');
const style=document.createElement('style');style.textContent=`.hero-title-row{display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap;margin:0 0 8px}.hero-title-row #hero{margin:0;flex-shrink:0}.inline-crew{display:flex;gap:5px;flex-wrap:wrap;align-items:center}.crew-mini{border-radius:100px;padding:5px 7px;font-size:11px;white-space:nowrap;font-weight:600}.crew-mini b{font-size:14px;margin-left:2px}.revenue-mini{display:inline-flex;align-items:center;gap:4px;border:1px solid rgba(151,226,203,.55);background:rgba(142,225,205,.16);border-radius:999px;padding:5px 8px;color:#e0fff2;white-space:nowrap;font-size:11px;line-height:1.3;cursor:pointer}.revenue-mini b{font-size:12px;font-weight:700}.revenue-mini:focus-visible{outline:2px solid #9de7cf;outline-offset:2px}.hero-title-row{justify-content:flex-start}.hero-title-row #hero{margin-right:5px}@media(max-width:390px){.revenue-mini{padding:4px 6px;font-size:10px}.revenue-mini b{font-size:11px}}.crew-mini.late{background:#e4effd;color:#245d89}.crew-mini.early{background:#fff0bf;color:#8a6316}@media(max-width:370px){.crew-mini{font-size:10px;padding:4px 5px}.crew-mini b{font-size:12px}}.headcount-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:13px}.headcount-card{padding:15px 10px;border-radius:12px;text-align:center}.headcount-card strong{display:block;font-size:26px;line-height:1.3}.headcount-card strong small{font-size:13px;margin-left:3px}.headcount-card span{display:block;font-size:12px;margin-top:5px}.headcount-card.late{background:#e4effd;color:#245d89}.headcount-card.early{background:#fff0bf;color:#8a6316}.bottom{grid-template-columns:repeat(3,1fr)}.tab{font-size:11px}.content{padding-bottom:25px}.pick-card{width:100%;display:block;text-align:left;border:1px solid #dfe6e9;border-radius:14px;background:#f3f6f8;padding:13px;margin:8px 0;color:#234052}.pick-card.early{background:#fff2b0;border-color:#e6c864}.pick-card.early.depth2{background:#f1d46e}.pick-card.early.depth3{background:#ddb044}.pick-card.used{background:#dcecff;border-color:#a1c6f1}.pick-card.chosen{outline:2px solid #208a70}.pick-card strong{display:block}.pick-card small{display:block;margin-top:5px;color:#59727e}.role-card{border:1px solid #e0e8eb;background:#f5f8f9;width:100%;padding:13px;border-radius:14px;text-align:left;margin-bottom:9px;color:#234052}.role-card b{display:block;margin-bottom:5px}.role-card span{font-size:13px}.role-card .yellow{background:#f5d477;padding:3px 6px;border-radius:7px}.role-card .blue{background:#dcecff;padding:3px 6px;border-radius:7px}.phase{display:flex;gap:6px;margin:12px 0;flex-wrap:wrap}.phase button{flex:1;min-width:70px}.outline-card{border:1px solid #dce5e9;border-radius:14px;padding:13px;margin-bottom:9px}.warning{background:#fff0d2;border:1px solid #e5ba67;border-radius:11px;padding:12px}.smalltxt{font-size:12px;color:#708490}.data-ta{min-height:160px!important}`;document.head.appendChild(style);
function renderStaff(){
 let body=`<div class="section"><h2>人员资料库</h2><span class="tag">${state.staff.length} 人</span></div><div class="panel"><p>保存员工姓名与普通岗位第一至第六适配顺序；全岗位都能胜任时直接开启「通岗」。打烊岗位不需要适配排名。</p><div class="actions"><button class="btn" id="addPerson">＋ 新增员工</button><button class="btn secondary" id="staffImport">导入资料</button><button class="btn secondary" id="staffExport">导出资料</button></div></div>`;
 body+=state.staff.map(p=>`<button class="task" data-person="${esc(p.id)}"><div class="line"><strong>${esc(p.name)}</strong><span>编辑 ›</span></div><p>${p.allRound?'🟢 通岗':((p.ranks||[]).map((r,i)=>`${i+1}. ${esc(r)}`).join('　')||'未设置适合岗位')}</p></button>`).join('')||'<div class="empty">没有员工，请先新增或导入</div>';
 body+=`<div class="panel"><h3>岗位设置</h3><p>普通岗位：${state.roles.normal.map(esc).join('、')}</p><p>打烊岗位：${state.roles.closing.map(esc).join('、')}</p><button class="btn secondary" id="editRoles">编辑岗位名称与顺序</button></div>`;
 v2Page('人员与岗位',body);
 document.getElementById('addPerson').onclick=()=>editPerson();document.getElementById('staffImport').onclick=importStaff;document.getElementById('staffExport').onclick=exportStaff;document.getElementById('editRoles').onclick=editRoles;
 document.querySelectorAll('[data-person]').forEach(b=>b.onclick=()=>editPerson(b.dataset.person));
}
function editPerson(id){let old=id?getStaff(id):null,p=old||{id:'p'+Date.now(),name:'',ranks:[],closingRanks:[]};const options=arr=>`<option value="">不设置</option>`+arr.map(r=>`<option value="${esc(r)}">${esc(r)}</option>`).join('');
 document.getElementById('modalRoot').innerHTML=`<div class="overlay"><div class="modal" role="dialog" aria-modal="true"><div class="modal-head"><h2>${old?'编辑员工':'新增员工'}</h2><button class="close" id="dismiss">关闭 ×</button></div><div class="field"><label>员工姓名</label><input id="personName" value="${esc(p.name)}"></div><div class="field"><label style="display:flex;align-items:center;gap:9px"><input type="checkbox" id="personAllRound" style="width:auto" ${p.allRound?'checked':''}>通岗（可胜任全部普通岗位）</label></div><div id="personRanks"><h3>普通岗位 · 第一至第六适配</h3>${Array.from({length:6},(_,i)=>`<div class="field"><label>第 ${i+1} 适配岗位</label><select id="rank${i}">${options(state.roles.normal)}</select></div>`).join('')}</div><p class="hint">打烊岗位对所有晚班员工开放，无需填写适配度。</p><div class="actions"><button class="btn" id="savePerson">保存员工</button>${old?'<button class="btn danger" id="deletePerson">删除员工</button>':''}</div></div></div>`;
 for(let i=0;i<6;i++){document.getElementById('rank'+i).value=p.ranks?.[i]||'';/* 打烊岗位无需适配排名 */}
 const allRoundInput=document.getElementById('personAllRound');const toggleRanks=()=>document.getElementById('personRanks').style.display=allRoundInput.checked?'none':'';allRoundInput.addEventListener('change',toggleRanks);toggleRanks();
 document.getElementById('dismiss').onclick=closeModal;
 document.getElementById('savePerson').onclick=()=>{const name=document.getElementById('personName').value.trim(),allRound=allRoundInput.checked,ranks=Array.from({length:6},(_,i)=>document.getElementById('rank'+i).value).filter(Boolean),closingRanks=[];if(!name)return toast('请填写姓名');if(new Set(ranks).size!==ranks.length||new Set(closingRanks).size!==closingRanks.length)return toast('岗位排名不能重复');let next={id:p.id,name,ranks,closingRanks,allRound};if(old)Object.assign(old,next);else state.staff.push(next);save();closeModal();render()};
 if(old)document.getElementById('deletePerson').onclick=()=>{if(confirm('删除员工后，历史记录保留，但未来排岗不再显示此人。确定吗？')){state.staff=state.staff.filter(x=>x.id!==id);save();closeModal();render()}};
}
function editRoles(){const d=state.roles;document.getElementById('modalRoot').innerHTML=`<div class="overlay"><div class="modal" role="dialog" aria-modal="true"><div class="modal-head"><h2>编辑岗位库</h2><button class="close" id="dismiss">关闭 ×</button></div><p class="hint">一行一个岗位，顺序就是最终文字输出顺序。改名可能影响员工已设置的适配排名。</p><div class="field"><label>普通岗位</label><textarea id="normalRoles" class="data-ta">${esc(d.normal.join('\n'))}</textarea></div><div class="field"><label>打烊岗位</label><textarea id="closingRoles" class="data-ta">${esc(d.closing.join('\n'))}</textarea></div><button class="btn wide" id="saveRoles">保存岗位</button></div></div>`;
 document.getElementById('dismiss').onclick=closeModal;document.getElementById('saveRoles').onclick=()=>{const n=document.getElementById('normalRoles').value.split('\n').map(x=>x.trim()).filter(Boolean),c=document.getElementById('closingRoles').value.split('\n').map(x=>x.trim()).filter(Boolean);if(!n.length||!c.length||new Set(n).size!==n.length||new Set(c).size!==c.length)return toast('岗位不能为空或重复');state.roles={normal:n,closing:c};save();closeModal();render()};}
function exportStaff(){const blob=new Blob([JSON.stringify({kind:'zhiban_staff',version:2,staff:state.staff,roles:state.roles,defaultGoal:state.defaultGoal},null,2)],{type:'application/json'});downloadBlob(blob,'值班_人员岗位资料.json')}
function downloadBlob(blob,name){let u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),3000)}
function importStaff(){let input=document.createElement('input');input.type='file';input.accept='.json,application/json,.csv,text/csv';input.onchange=async()=>{try{let f=input.files[0];if(!f)return;let s=await f.text(),incoming,roles=null;if(f.name.toLowerCase().endsWith('.csv')){let lines=s.replace(/^\uFEFF/,'').split(/\r?\n/).filter(Boolean);let head=lines.shift().split(',').map(x=>x.trim());incoming=lines.map(line=>{let c=line.split(',').map(x=>x.trim());let obj=Object.fromEntries(head.map((h,i)=>[h,c[i]||'']));return {id:'p'+Math.random().toString(36).slice(2),name:obj['姓名']||obj.name||'',allRound:['true','1','是','通岗','yes'].includes(String(obj['通岗']||obj.allRound||'').toLowerCase()),ranks:Array.from({length:6},(_,i)=>obj[`第${i+1}适配`]||'').filter(Boolean),closingRanks:[]}})}else{let d=JSON.parse(s);incoming=d.staff;roles=d.roles}if(!Array.isArray(incoming)||incoming.some(x=>typeof x.name!=='string'))throw Error('人员资料格式不正确');let valid=incoming.filter(x=>x.name.trim()).map(x=>({id:x.id||'p'+Math.random().toString(36).slice(2),name:x.name.trim(),ranks:Array.isArray(x.ranks)?x.ranks.slice(0,6):[],closingRanks:[],allRound:x.allRound===true||x.allRound===1||x.allRound==='true'}));if(!confirm(`读取到 ${valid.length} 人。选择确定将按姓名合并，并保留当前其他员工。建议先导出备份。`))return;for(let p of valid){let existing=state.staff.find(x=>x.name===p.name);if(existing){existing.ranks=p.ranks;existing.closingRanks=[];existing.allRound=p.allRound}else{if(state.staff.some(x=>x.id===p.id))p.id='p'+Date.now()+Math.random();state.staff.push(p)}}if(roles&&Array.isArray(roles.normal)&&Array.isArray(roles.closing)&&confirm('同时导入文件内的岗位列表吗？'))state.roles=roles;save();render();toast('已导入 '+valid.length+' 位员工')}catch(err){toast('导入失败：'+err.message)}};input.click()}
// v4.1: coverage-first suggestions. Early staff only cover their own short-lived post;
// every ordinary role also needs a late-shift replacement to avoid gaps after handoff.
// Suggestions never write draft assignments, and must report uncovered roles honestly.
function buildCoverageRecommendation(d){
 const roles=state.roles.normal.slice();
 const early=d.early.filter(id=>getStaff(id));
 const late=d.late.filter(id=>getStaff(id));
 const earlyByRole=Object.fromEntries(roles.map(r=>[r,[]]));
 const lateByRole=Object.fromEntries(roles.map(r=>[r,[]]));
 const fit=(id,r)=>{const p=getStaff(id);if(!p)return 999;if(p.allRound)return 0;const n=rankOf(id,r,'normal');return n<0?30:n<3?n*2:12+n*3};
 // Place each early worker at one post only. Prefer posts compatible with incoming workers.
 for(const id of early){
   const possible=roles.map((r,i)=>({r,i,cost:fit(id,r),need:earlyByRole[r].length,
     cover:late.filter(x=>fit(x,r)<30).length}));
   possible.sort((a,b)=>(a.cost>=30)-(b.cost>=30)||a.need-b.need||a.cost-b.cost||Number(b.cover>0)-Number(a.cover>0)||a.i-b.i);
   if(possible.length)earlyByRole[possible[0].r].push(id);
 }
 // Minimum-cost capacitated matching: one mandatory late worker per role, no worker >2 roles.
 // Treat 配料 and 敲单 as the same operating line but two functions needing coverage.
 const N=late.length,R=roles.length,source=0,roleBase=1,personBase=roleBase+R,sink=personBase+N;
 const graph=Array.from({length:sink+1},()=>[]);
 function edge(u,v,cap,cost){const a={to:v,rev:graph[v].length,cap,cost},b={to:u,rev:graph[u].length,cap:0,cost:-cost};graph[u].push(a);graph[v].push(b);return a}
 const ref=[];
 roles.forEach((r,i)=>{edge(source,roleBase+i,1,0);late.forEach((id,j)=>{
   // Compatibility matters more than arrival order; ties go to earlier arrival.
   const cost=fit(id,r)*100+(earlyByRole[r].length?0:5)+j*2;
   ref.push({r,id,e:edge(roleBase+i,personBase+j,1,cost)});
 })});
 late.forEach((id,j)=>edge(personBase+j,sink,2,0));
 for(let k=0;k<R;k++){
   const distance=Array(sink+1).fill(Infinity),prev=Array(sink+1).fill(null),queue=[source],inq=Array(sink+1).fill(false);
   distance[source]=0;inq[source]=true;
   while(queue.length){let u=queue.shift();inq[u]=false;graph[u].forEach((e,idx)=>{
     if(e.cap<=0||distance[u]+e.cost>=distance[e.to])return;
     distance[e.to]=distance[u]+e.cost;prev[e.to]=[u,idx];if(!inq[e.to]){inq[e.to]=true;queue.push(e.to)}
   })}
   if(!prev[sink])break;
   for(let v=sink;v!==source;){const [u,idx]=prev[v],e=graph[u][idx];e.cap--;graph[v][e.rev].cap++;v=u}
 }
 ref.forEach(({r,id,e})=>{if(e.cap===0)lateByRole[r].push(id)});
 // Every late staff member should have a second work assignment where feasible.
 // Prioritize pairing 配料/敲单 and otherwise prefer the least staffed compatible role.
 for(const id of late){
   const used=roles.filter(r=>lateByRole[r].includes(id));
   if(used.length>=2)continue;
   const options=roles.filter(r=>!used.includes(r)).map((r,i)=>({r,i,
     pair:used.includes('配料')&&r==='敲单'||used.includes('敲单')&&r==='配料',
     compatible:fit(id,r),people:lateByRole[r].length}));
   options.sort((a,b)=>Number(b.pair)-Number(a.pair)||Number(a.compatible>=30)-Number(b.compatible>=30)||a.people-b.people||a.compatible-b.compatible||a.i-b.i);
   if(options.length)lateByRole[options[0].r].push(id);
 }
 const uncovered=roles.filter(r=>lateByRole[r].length===0);
 const secondRoles=late.filter(id=>Object.values(lateByRole).filter(x=>x.includes(id)).length<2);
 return {roles,earlyByRole,lateByRole,uncovered,secondRoles,fit};
}
function rosterSuggestions(d){
 const data=buildCoverageRecommendation(d);
 const {roles,earlyByRole,lateByRole,uncovered,secondRoles,fit}=data;
 const rows=roles.map(role=>{
   const earlyTags=earlyByRole[role].map(id=>`<span class="recommend-name recommend-early">${esc(getStaff(id).name)} · 早班</span>`).join('');
   const lateTags=lateByRole[role].map(id=>`<span class="recommend-name ${fit(id,role)>=30?'recommend-caution':''}">${esc(getStaff(id).name)} · 接替${fit(id,role)>=30?' ⚠':''}</span>`).join('');
   const remaining=lateByRole[role].length?'':'<span class="recommend-missing">缺少晚班接替</span>';
   return `<div class="recommend-line"><strong>${esc(role)}：</strong><div>${earlyTags}${earlyTags&&lateTags?'<span class="recommend-handoff">→</span>':''}${lateTags}${remaining}</div></div>`;
 }).join('');
 const note=uncovered.length?`<p class="recommend-warning">⚠ 晚班有 ${uncovered.length} 个岗位缺少接替：${esc(uncovered.join('、'))}。请增补人员或人工调整。</p>`:'';
 const coverage=`<p class="smalltxt">晚班覆盖 ${roles.length-uncovered.length}/${roles.length} 个岗位 · ${data.lateByRole['配料']?.length&&data.lateByRole['敲单']?.length?'配料线与敲单均有人员':'配料线/敲单尚未完全覆盖'}</p>`;
 const capacity=secondRoles.length?`<p class="smalltxt">尚未安排第二岗位：${esc(secondRoles.map(id=>getStaff(id).name).join('、'))}（如岗位已全部覆盖，可留作机动）</p>`:'';
 return `<div class="panel recommend-panel"><h3>✨ 排班参考推荐</h3>${coverage}${rows}${note}${capacity}</div>`;
}
function renderRoster(){let d=draft();let isMorning=state.uiShift==='morning';let stages=isMorning?[['people','① 选人'],['normal','② 普通岗位'],['opening','③ 开早'],['finish','④ 结果']]:[['people','① 选人'],['normal','② 普通岗位'],['closing','③ 打烊'],['finish','④ 结果']];
 let body=`<div class="phase">${stages.map(([v,label])=>`<button class="btn ${rosterStage===v?'':'secondary'}" data-stage="${v}">${label}</button>`).join('')}</div>`;
 if(rosterStage==='people'){
  const sortedStaff=[...state.staff].sort((a,b)=>a.name.localeCompare(b.name,'zh-CN',{sensitivity:'base'}));
  if(isMorning){
    body+=`<div class="panel"><h3>第一步 · 选择早班员工</h3><p>只需选择今天上早班的人员，不区分离岗与接替。可点击姓名卡片选择或取消。</p><div class="actions"><button class="btn secondary" id="addFromRoster">管理员工库</button><button class="btn secondary" id="resetRoster">重新开始当天排岗</button></div></div><div class="section"><h2>今日早班人员</h2><span class="tag">${d.early.length} 人</span></div>`;
    body+='<div class="staff-pick-grid">'+sortedStaff.map(p=>`<button class="staff-name-tile ${d.early.includes(p.id)?'late-chosen':p.allRound?'all-round':''}" data-early="${esc(p.id)}" aria-pressed="${d.early.includes(p.id)}" title="${esc(p.name)}"><span>${esc(p.name)}</span></button>`).join('')+'</div>';
  }else{
    body+=`<div class="panel"><h3>第一步 · 选择早晚班</h3><p>点击员工加入早班或晚班；黄色按点击先后从浅到深，早班越早选越早下班。晚班顺序也按选择顺序保存。</p><div class="actions"><button class="btn secondary" id="addFromRoster">管理员工库</button><button class="btn secondary" id="resetRoster">重新开始当天排岗</button></div></div><div class="section"><h2>早班即将下班</h2><span class="tag">${d.early.length} 人</span></div>`;
    body+='<div class="staff-pick-grid">'+sortedStaff.map(p=>`<button class="staff-name-tile ${d.early.includes(p.id)?'early depth'+Math.min(3,1+Math.floor(d.early.indexOf(p.id)/2)):d.late.includes(p.id)?'other-shift':p.allRound?'all-round':''}" data-early="${esc(p.id)}" aria-pressed="${d.early.includes(p.id)}" title="${esc(p.name)}"><span>${esc(p.name)}</span></button>`).join('')+'</div>';
    body+=`<div class="section"><h2>晚班人员</h2><span class="tag">${d.late.length} 人</span></div>`;
    body+='<div class="staff-pick-grid">'+sortedStaff.map(p=>`<button class="staff-name-tile ${d.late.includes(p.id)?'late-chosen':d.early.includes(p.id)?'other-shift':p.allRound?'all-round':''}" data-late="${esc(p.id)}" aria-pressed="${d.late.includes(p.id)}" title="${esc(p.name)}"><span>${esc(p.name)}</span></button>`).join('')+'</div>';
  }
  body+='<button class="btn wide" id="goNormal">下一步：安排普通岗位 →</button>';
 } else if(rosterStage==='normal'||rosterStage==='closing'||rosterStage==='opening'){
   if(rosterStage==='normal'&&!isMorning)body+=rosterSuggestions(d);
   let kind=rosterStage==='normal'?'normal':rosterStage==='opening'?'opening':'closing',roles=kind==='opening'?state.morningOpeningRoles.filter(r=>d.receiving||r!=='收货安排'):state.roles[kind],assign=d[kind];body+=`<div class="panel"><h3>${kind==='normal'?'普通岗位安排':kind==='opening'?'开早准备':'打烊安排 🧹'}</h3><p>${kind==='normal'?(isMorning?'从今日早班人员中选岗，每人最多两个普通岗位。':'早班最多1岗，晚班最多2岗；蓝色表示已经安排第一岗。'):kind==='opening'?'可选择本次选中的任意员工，同一个人可以负责多个开早岗位。':'只能选择晚班员工，打烊不占普通岗位名额。同一名晚班员工可负责多个不同的打烊岗位。'}</p></div>`;
   body+=roles.map(role=>`<button class="role-card" data-role="${esc(role)}"><b>${esc(role)}　›</b><span>${(assign[role]||[]).map(id=>{let p=getStaff(id);if(!p)return '';return `<span class="${isMorning?'blue':d.early.includes(id)?'yellow':'blue'}">${esc(p.name)}</span>`}).join('　')||'＋ 点击安排员工'}</span></button>`).join('');
   if(kind==='opening')body+=`<div class="panel"><h3>收货准备</h3><label style="display:flex;align-items:center;gap:8px"><input id="receivingSwitch" type="checkbox" ${d.receiving?'checked':''} style="width:auto"> 今天是否收货</label><div class="field" id="receivingTimeWrap" style="display:${d.receiving?'block':'none'}"><label>几点之前完成收货准备</label><input id="receivingTime" type="time" value="${esc(d.receivingTime||'')}" /></div></div>`;
   body+=`<button class="btn wide" id="nextRoster">${kind==='normal'?'普通岗位已安排，继续 →':kind==='opening'?'保存开早安排，生成结果 →':'保存打烊安排，生成结果 →'}</button>`;
 }else{
  body+=`<div class="panel"><h3>排岗文字 · 最终预览</h3><p>自动填写今日日期与预估营业额；普通岗位、当天目标、打烊安排按发送格式输出。</p><div class="field"><label>当天目标 🎯</label><textarea id="goalText">${esc(d.goal)}</textarea></div><div class="field"><label>完整排岗文字</label><textarea class="data-ta" readonly id="rosterOutput">${esc(rosterText(d))}</textarea></div><div class="actions"><button class="btn" id="saveRoster">保存到统计</button><button class="btn secondary" id="copyRoster">复制文字</button></div></div>`;
 }
 v2Page('智能排岗',body);
 document.querySelectorAll('[data-stage]').forEach(x=>x.onclick=()=>{rosterStage=x.dataset.stage;render()});
 if(rosterStage==='people'){
  document.getElementById('addFromRoster').onclick=()=>setTab('staff');document.getElementById('resetRoster').onclick=()=>{if(confirm('确定清空当前未归档的排岗草稿？')){state.rosterDraft=makeDraft();save();render()}};
  document.querySelectorAll('[data-early]').forEach(b=>b.onclick=()=>{let id=b.dataset.early;d.early=d.early.includes(id)?d.early.filter(x=>x!==id):[...d.early.filter(x=>x!==id),id];d.late=d.late.filter(x=>x!==id);if(!d.early.includes(id))for(let m of [d.normal,d.closing,d.opening])for(let k in m)m[k]=m[k].filter(x=>x!==id);save();render()});
  if(!isMorning)document.querySelectorAll('[data-late]').forEach(b=>b.onclick=()=>{let id=b.dataset.late;d.late=d.late.includes(id)?d.late.filter(x=>x!==id):[...d.late,id];d.early=d.early.filter(x=>x!==id);if(!d.late.includes(id))for(let m of [d.normal,d.closing])for(let k in m)m[k]=m[k].filter(x=>x!==id);save();render()});
  document.getElementById('goNormal').onclick=()=>{if(!(isMorning?d.early.length:(d.early.length+d.late.length)))return toast('请至少选择一名员工');rosterStage='normal';render()};
 } else if(rosterStage==='normal'||rosterStage==='closing'||rosterStage==='opening'){
  document.querySelectorAll('[data-role]').forEach(b=>b.onclick=()=>openRole(b.dataset.role,rosterStage));if(rosterStage==='opening'){const chk=document.getElementById('receivingSwitch'),tm=document.getElementById('receivingTime');chk.onchange=()=>{d.receiving=chk.checked;save();render()};tm.onchange=()=>{d.receivingTime=tm.value;save()}}
  document.getElementById('nextRoster').onclick=()=>{if(rosterStage==='normal'){if(isMorning)rosterStage='opening';else if(confirm('普通岗位已自动保存。是否继续安排打烊？\n确定：安排打烊；取消：直接生成文字。'))rosterStage='closing';else rosterStage='finish'}else rosterStage='finish';save();render()};
 }else{
  document.getElementById('goalText').oninput=e=>{d.goal=e.target.value;save();document.getElementById('rosterOutput').value=rosterText(d)};
  document.getElementById('copyRoster').onclick=()=>copy(rosterText(d));
  document.getElementById('saveRoster').onclick=()=>{let snap=clone(d);snap.savedAt=new Date().toISOString();snap.forecastRevenue=state.dailyRevenue?.[snap.date]??null;snap.text=rosterText(snap);snap.normalRoleNames=state.roles.normal.slice();snap.closingRoleNames=state.roles.closing.slice();snap.openingRoleNames=state.morningOpeningRoles.slice();snap.staffNames=Object.fromEntries(state.staff.map(p=>[p.id,p.name]));if(!Array.isArray(state.rosters))state.rosters=[];state.rosters.push(snap);state.rosterDraft=null;save();rosterStage='people';setTab('statistics');toast('排岗保存成功，已同步到今日岗位卡片')};
 }
}
function openRole(role,kind){let d=draft(),arr=d[kind][role]||[],isClose=kind==='closing',isOpening=kind==='opening';rosterRole=role;rosterKind=kind;
 let morning=d.shiftType==='morning';let eligible=state.staff.filter(p=>(isClose?d.late.includes(p.id):morning?d.early.includes(p.id):hasShift(p.id))&&(isClose||isOpening||arr.includes(p.id)||jobCount(p.id)<(morning?2:d.early.includes(p.id)?1:2)));
 // Strict shift order: early departure order first; late arrival order second.
 // Role suitability is displayed for guidance but must never reorder candidates.
 eligible.sort((a,b)=>{
   if(morning)return d.early.indexOf(a.id)-d.early.indexOf(b.id);
   const ai=d.early.indexOf(a.id),bi=d.early.indexOf(b.id);
   if(ai>=0 && bi>=0)return ai-bi;
   if(ai>=0)return -1;
   if(bi>=0)return 1;
   return d.late.indexOf(a.id)-d.late.indexOf(b.id);
 });
 document.getElementById('modalRoot').innerHTML=`<div class="overlay"><div class="modal" role="dialog" aria-modal="true"><div class="modal-head"><h2>${esc(role)} · 选人</h2><button class="close" id="dismiss">关闭 ×</button></div><p class="hint">${isOpening?'开早准备允许一人多岗；':morning?'只显示今天选中的早班人员，按照选人顺序排列；':isClose?'按晚班到岗先后排序，仅晚班参与打烊；':'先按早班下班顺序、再按晚班到岗顺序展示。蓝色表示已安排第一岗位；岗位适配只作参考。'}点击已选中的员工可撤销。</p><div class="${isClose?'':'picker-two-col'}">${eligible.map(p=>{let n=rankOf(p.id,role,kind),e=d.early.indexOf(p.id),used=!isClose&&jobCount(p.id)>0;return `<button class="pick-card ${morning?(used?'used':''):e>=0?'early depth'+Math.min(3,1+Math.floor(e/2)):used?'used':''} ${arr.includes(p.id)?'chosen':''}" data-select="${esc(p.id)}"><strong>${esc(p.name)} ${arr.includes(p.id)?'· 已选':''}</strong><small>${morning?'早班员工':e>=0?`早班 · 第${e+1}位下班`:`晚班 · 第${d.late.indexOf(p.id)+1}位到岗${isClose?' · 打烊候选':``}`}${isClose?'':''}</small>${isClose?'':`<span class="role-used-count">已排普通岗位 ${jobCount(p.id)}/2</span><span class="current-fit ${(!p.allRound && (n>=5 || n<0))?'bad':''}">${p.allRound||n>=0&&n<5?'当前岗位合适':'当前岗位不太合适'}</span>`}${isClose?'':p.allRound?'<span class="fit-chips"><span class="fit-chip fit-good">通岗</span></span>':`<span class="fit-chips">${(p.ranks||[]).length?(p.ranks||[]).map((r,i)=>`<span class="fit-chip ${i<3?'fit-good':i<5?'fit-medium':'fit-low'}">${i+1}. ${esc(r)}</span>`).join(''):'<span class="fit-chip fit-unknown">适配情况未设置</span>'}</span>`}</button>`}).join('')||'<p class="empty">当前没有可安排的员工</p>'}</div><div id="fitWarning"></div><button class="btn wide" id="donePicking">完成本岗位选择</button></div></div>`;
 document.getElementById('dismiss').onclick=closeModal;document.getElementById('donePicking').onclick=()=>{closeModal();render()};
 document.querySelectorAll('[data-select]').forEach(b=>b.onclick=()=>{let id=b.dataset.select,current=d[kind][role]||[];if(current.includes(id)){d[kind][role]=current.filter(x=>x!==id);save();openRole(role,kind);return}let n=rankOf(id,role,kind);if(!isClose&&!isOpening&&!getStaff(id)?.allRound&&(n>=3||n<0)){let p=getStaff(id);let mild=n===3||n===4;document.getElementById('fitWarning').innerHTML=`<div class="warning"><strong>${mild?'可能不是最优解':'岗位适配警告'}</strong><p>${mild?`${esc(p.name)}的「${esc(role)}」属于第${n+1}适配，可能不是最优解，是否仍然选择？`:`${esc(p.name)}在「${esc(role)}」的适配度较低或尚未设置；如需安排，建议高峰期及时换岗。确定继续？`}</p><div class="actions"><button class="btn secondary" id="cancelFit">取消</button><button class="btn" id="confirmFit">仍然安排</button></div></div>`;document.getElementById('cancelFit').onclick=()=>document.getElementById('fitWarning').innerHTML='';document.getElementById('fitWarning').scrollIntoView({behavior:'smooth',block:'nearest'});document.getElementById('confirmFit').onclick=()=>{d[kind][role]=[...current,id];save();openRole(role,kind)};return}d[kind][role]=[...current,id];save();openRole(role,kind)});
}
function renderStats(){
 const records=Array.isArray(state.rosters)?state.rosters:[];
 const sorted=records.slice().sort((a,b)=>String(b.savedAt||'').localeCompare(String(a.savedAt||'')));
 const today=dayKey();
 // Prefer the newest roster for the current business day; never manufacture a roster from the draft.
 const current=sorted.find(r=>r.date===today&&(r.shiftType||'evening')===(state.uiShift||'evening'));
 const makeTiles=(r,kind)=>{let roles=r[kind==='normal'?'normalRoleNames':kind==='opening'?'openingRoleNames':'closingRoleNames']||(kind==='opening'?state.morningOpeningRoles:state.roles[kind]),map=r[kind]||{},staffNames=r.staffNames||{};
   return '<div class="role-grid">'+roles.filter(role=>kind!=='opening'||r.receiving||role!=='收货安排').map(role=>{let people=(map[role]||[]).map(id=>({id,name:staffNames[id]||getStaff(id)?.name||'已删除员工'}));return `<div class="role-tile"><h4>${esc(role)}</h4>${people.length?people.map(p=>`<span class="person-tag ${r.early?.includes(p.id)?'early':''}">${esc(p.name)}</span>`).join(''):'<span class="smalltxt">未安排</span>'}</div>`}).join('')+'</div>';
 };
 let html=`<div class="panel"><div class="row"><div><h3>今日岗位总览</h3><p>${esc(today)} · 预估营业额：${state.dailyRevenue?.[today] == null?'待填写':Number(state.dailyRevenue[today]).toLocaleString('zh-CN')+' 元'} · 最近一次保存的排岗</p></div><span class="tag">${current?'已同步':'暂无安排'}</span></div></div>`;
 if(current){
   const hasClosing=Object.values(current.closing||{}).some(x=>Array.isArray(x)&&x.length);
   const activeKind=state.uiShift==='morning'?(statsRoleView==='closing'?'opening':statsRoleView):(statsRoleView==='opening'?'closing':statsRoleView);
   const activeRoles=current[activeKind==='normal'?'normalRoleNames':activeKind==='opening'?'openingRoleNames':'closingRoleNames']||(activeKind==='opening'?state.morningOpeningRoles:state.roles[activeKind]);    
   html+=`<div class="panel"><div class="stats-role-switch" role="group" aria-label="切换岗位类型"><button class="stats-switch-btn ${activeKind==='normal'?'active':''}" data-stats-kind="normal" aria-pressed="${activeKind==='normal'}">普通岗位</button><button class="stats-switch-btn ${activeKind!=='normal'?'active':''}" data-stats-kind="${state.uiShift==='morning'?'opening':'closing'}" aria-pressed="${activeKind!=='normal'}">${state.uiShift==='morning'?'开早岗位':'打烊岗位 🧹'}</button></div><div class="row" style="margin:14px 0 10px"><strong>${activeKind==='normal'?'普通岗位':activeKind==='opening'?'开早岗位':'打烊岗位 🧹'}</strong><span class="tag">${activeRoles.length} 个岗位</span></div>${activeKind==='closing'&&!hasClosing?'<p class="smalltxt">今天的排岗尚未安排打烊岗位，可以在填表中补充。</p>':''}${makeTiles(current,activeKind)}</div>`;
   html+=`<div class="panel"><h3>当天目标 🎯</h3><p style="white-space:pre-wrap;color:#24485b">${esc(current.goal||DEFAULT_GOAL)}</p><div class="actions"><button class="btn" id="copyTodayRoster">复制今日完整排岗</button></div></div>`;
 }else html+='<div class="panel"><p>今天还没有保存排岗。请在「填表 → 智能排岗」完成安排，点击「保存到统计」，岗位卡片就会显示在这里。</p></div>';
 html+=`<div class="section"><h2>历史排岗记录</h2><div class="roster-history-actions"><span class="tag">${sorted.length} 条</span><button id="toggleRosterHistory" type="button" aria-label="展开全部历史排岗">展开全部</button></div></div>`;
 html+=sorted.map((r,i)=>`<details class="history-card roster-history-fold"><summary class="roster-history-summary"><span class="roster-history-heading"><strong>${esc(r.date||'未知日期')} · ${r.shiftType==='morning'?'早班':'晚班'}</strong><span class="smalltxt">${esc(r.savedAt?new Date(r.savedAt).toLocaleString('zh-CN'):'未记录保存时间')}</span><span class="smalltxt">普通岗位 ${Object.values(r.normal||{}).reduce((n,a)=>n+(a?.length||0),0)} 人次 · ${r.shiftType==='morning'?'开早':'打烊'} ${Object.values((r.shiftType==='morning'?r.opening:r.closing)||{}).reduce((n,a)=>n+(a?.length||0),0)} 人次</span></span><span class="roster-expand-label" aria-hidden="true"></span><span class="roster-history-chevron" aria-hidden="true">⌄</span></summary><div class="roster-history-body"><pre class="roster-history-text">${esc(r.text||rosterText(r))}</pre><div class="actions"><button class="btn secondary" data-copy-roster="${i}">复制本次排岗</button></div></div></details>`).join('')||'<div class="empty">暂无历史排岗记录</div>';
 html+=`<div class="panel"><h3>任务完成统计</h3>${Object.keys(state.days).sort().reverse().slice(0,14).map(k=>`<p><strong>${esc(k)}</strong>：${state.days[k].filter(isDone).length}/${state.days[k].length} 已完成</p>`).join('')||'<p>暂无记录</p>'}</div>`;
 v2Page('统计与排岗记录',html);
 document.querySelectorAll('[data-stats-kind]').forEach(b=>b.onclick=()=>{statsRoleView=b.dataset.statsKind;renderStats()});
 const copyToday=document.getElementById('copyTodayRoster');if(copyToday)copyToday.onclick=()=>copy(current.text||rosterText(current));
 document.querySelectorAll('[data-copy-roster]').forEach(b=>b.onclick=()=>copy(sorted[+b.dataset.copyRoster].text||rosterText(sorted[+b.dataset.copyRoster])));
 const historyToggle=document.getElementById('toggleRosterHistory');const historyCards=[...document.querySelectorAll('.roster-history-fold')];if(historyToggle){const syncHistoryToggle=()=>{const allOpen=historyCards.length>0&&historyCards.every(d=>d.open);historyToggle.textContent=allOpen?'收起全部':'展开全部';historyToggle.setAttribute('aria-label',historyToggle.textContent+'历史排岗')};historyToggle.onclick=()=>{const allOpen=historyCards.length>0&&historyCards.every(d=>d.open);historyCards.forEach(d=>d.open=!allOpen);syncHistoryToggle()};historyCards.forEach(d=>d.addEventListener('toggle',syncHistoryToggle));syncHistoryToggle()}
}
const origExportBackup=exportBackup;exportBackup=()=>downloadBlob(new Blob([JSON.stringify({version:2,exportedAt:new Date().toISOString(),data:state},null,2)],{type:'application/json'}),'值班_完整备份_'+dayKey()+'.json');
render();

// v3.8: show selected duty shift before title on all pages.
const renderBeforeBrand=render;render=function(){renderBeforeBrand();const x=document.getElementById('brandShift');if(x)x.textContent=(state.uiShift==='morning'?'早班':'晚班');};render();
