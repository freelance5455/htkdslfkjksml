/* 值班 v4.3 - 工作日报预填草稿，独立存储以兼容旧数据 */
(()=>{'use strict';
const KEY='zhiban_prefill_drafts_v43';
const fields=[['expected','预估营业额','number'],['s','S','text'],['tc','TC','number'],['atp','ATP','text'],['deliveryTc','外送 TC','number'],['fob','FOB 金额','number'],['member','会员数量','number'],['hours','员工工时','text'],['oven','进炉时间','text'],['notes','备注 / 待补数据','textarea']];
const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function data(){try{return JSON.parse(localStorage.getItem(KEY)||'{}')||{}}catch{return {}}}
function workDate(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`}
function show(){const date=workDate(), all=data(), value=all[date]||{};
const layer=document.createElement('div');layer.className='overlay';layer.id='prefillOverlay';layer.innerHTML='<div class="modal" role="dialog" aria-modal="true" aria-label="预填日报" style="max-height:88vh;overflow:auto"><div class="modal-head"><h2>预填表格 · '+date+'</h2><button class="close" id="prefillClose">关闭 ×</button></div><p class="hint">内容保存于当前手机，未完成的字段可以留空，稍后继续填写。</p><div class="prefill-grid">'+fields.map(([key,label,type])=>'<div class="field" style="'+(type==='textarea'?'grid-column:1/-1':'')+'"><label for="pf_'+key+'">'+label+'</label>'+(type==='textarea'?'<textarea id="pf_'+key+'" rows="3">'+escape(value[key])+'</textarea>':'<input id="pf_'+key+'" type="'+type+'" '+(type==='number'?'min="0" step="any"':'')+' value="'+escape(value[key])+'">')+'</div>').join('')+'</div><div class="actions"><button class="btn" id="prefillSave">保存草稿</button><button class="btn secondary" id="prefillCopy">复制表格内容</button></div></div>';
document.body.appendChild(layer);layer.querySelector('#prefillClose').onclick=()=>layer.remove();layer.onclick=e=>{if(e.target===layer)layer.remove()};
const collect=()=>Object.fromEntries(fields.map(([key])=>[key,layer.querySelector('#pf_'+key).value]));
const save=()=>{const all=data();all[date]=collect();localStorage.setItem(KEY,JSON.stringify(all));return all[date]};
layer.querySelector('#prefillSave').onclick=()=>{save();alert('预填草稿已保存')};
layer.querySelector('#prefillCopy').onclick=async()=>{const x=save(),text='【'+date+' 日报预填】\n'+fields.map(([key,label])=>label+'：'+(x[key]||'待补')).join('\n');try{await navigator.clipboard.writeText(text);alert('已复制，草稿也已保存')}catch{prompt('可长按复制以下文字',text)}};
}
window.openZbPrefill=()=>window.openZbPrefillMenu?window.openZbPrefillMenu():show();
window.openZbDailyReport=show;
})();
