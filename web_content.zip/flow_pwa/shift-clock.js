/* 值班 v4.5: real-time clock and end-of-shift countdown. All calculations use device local time. */
(()=>{
'use strict';
const pad=n=>String(n).padStart(2,'0');
function nextEnd(now,shift){
 const h=shift==='morning'?15:0,minute=30;
 const d=new Date(now.getFullYear(),now.getMonth(),now.getDate(),h,minute,0,0);
 if(shift==='evening'){
  // On a running night shift, midnight belongs to the next calendar date from shift start.
  if(state?.activeShift?.status==='active' && state.activeShift.type==='evening'){
   const start=new Date(state.activeShift.startedAt);
   const end=new Date(start.getFullYear(),start.getMonth(),start.getDate()+1,0,30,0,0);
   return end;
  }
  if(now>=d)d.setDate(d.getDate()+1);
 }else if(state?.activeShift?.status!=='active' && now>=d){d.setDate(d.getDate()+1)}
 return d;
}
function tick(){
 const el=document.getElementById('shiftClock');if(!el)return;
 const now=new Date(),shift=state?.uiShift==='morning'?'morning':'evening';
 const end=nextEnd(now,shift),ms=end-now;
 const clock=[now.getHours(),now.getMinutes(),now.getSeconds()].map(pad).join(':');
 if(ms<=0){el.textContent=clock+' · 已到下班时间';return}
 const minutes=Math.ceil(ms/60000),hours=Math.floor(minutes/60),rem=minutes%60;
 el.textContent=clock+' · 距下班 '+(hours?hours+'小时':'')+rem+'分';
}
tick();setInterval(tick,1000);document.addEventListener('visibilitychange',()=>{if(!document.hidden)tick()});
})();
