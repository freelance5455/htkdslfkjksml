# BARBARIANS App Package

This package is a mobile-ready Progressive Web App (PWA) connected to the BARBARIANS Supabase backend.

## Includes
- Responsive BARBARIANS UI
- Supabase authentication
- Profiles
- Discussions/posts
- Likes/upvotes
- Comments
- Communities
- Trending/saved views
- PWA manifest and offline app shell
- BARBARIANS splash artwork and app icons

## Important
The app needs to be served over HTTPS for browser installation and service-worker features. Supabase data also requires an internet connection.

For Android/Play Store packaging, this web app can be wrapped into an Android project after it has a stable HTTPS URL, or loaded as local web assets in a native WebView wrapper.
