
package com.jeffmods.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30, 50, 30, 30)
            setBackgroundColor(Color.rgb(5, 10, 20))
        }

        val title = TextView(this).apply {
            text = "JEFF MODS"
            textSize = 28f
            setTextColor(Color.CYAN)
        }
        layout.addView(title)

        val button = Button(this).apply {
            text = "ATIVAR BOLHA FLUTUANTE"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(intent)
                } else {
                    startService(
                        Intent(this@MainActivity, FloatingService::class.java)
                    )
                    finish()
                }
            }
        }
        layout.addView(button)
        setContentView(layout)
    }
}
