
package com.jeffmods.app

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.SeekBar

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var bubble: TextView
    private var panel: LinearLayout? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        bubble = TextView(this).apply {
            text = "JM"
            textSize = 19f
            gravity = Gravity.CENTER
            setTextColor(Color.CYAN)
            setBackgroundColor(Color.rgb(8, 20, 35))
            typeface = Typeface.DEFAULT_BOLD
            setOnClickListener { togglePanel() }
        }

        val params = WindowManager.LayoutParams(
            58, 58,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 20
            y = 220
        }

        wm.addView(bubble, params)

        bubble.setOnTouchListener(object :
            android.view.View.OnTouchListener {
            var sx = 0f
            var sy = 0f
            var ox = 0
            var oy = 0
            var moved = false

            override fun onTouch(
                v: android.view.View,
                e: MotionEvent
            ): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = e.rawX
                        sy = e.rawY
                        ox = params.x
                        oy = params.y
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - sx).toInt()
                        val dy = (e.rawY - sy).toInt()
                        if (kotlin.math.abs(dx) > 8 ||
                            kotlin.math.abs(dy) > 8) moved = true
                        params.x = ox + dx
                        params.y = oy + dy
                        wm.updateViewLayout(bubble, params)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) togglePanel()
                        return true
                    }
                }
                return false
            }
        })
    }

    private fun togglePanel() {
        if (panel != null) {
            wm.removeView(panel)
            panel = null
            return
        }

        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(Color.rgb(7, 14, 28))
        }

        val title = TextView(this).apply {
            text = "JEFF MODS  •  V2"
            textSize = 20f
            setTextColor(Color.CYAN)
            typeface = Typeface.DEFAULT_BOLD
        }
        p.addView(title)

        fun addSlider(label: String) {
            val text = TextView(this).apply {
                this.text = "$label: 50"
                setTextColor(Color.WHITE)
                textSize = 14f
            }
            p.addView(text)

            val slider = SeekBar(this).apply {
                max = 100
                progress = 50
                setOnSeekBarChangeListener(
                    object : SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(
                            bar: SeekBar?,
                            value: Int,
                            user: Boolean
                        ) {
                            text.text = "$label: $value"
                        }
                        override fun onStartTrackingTouch(bar: SeekBar?) {}
                        override fun onStopTrackingTouch(bar: SeekBar?) {}
                    }
                )
            }
            p.addView(slider)
        }

        addSlider("Precisão")
        addSlider("FOV")
        addSlider("Suavidade")

        listOf("Aimbot", "ESP", "AimLock", "No Recoil").forEach {
            val option = android.widget.CheckBox(this).apply {
                text = it
                setTextColor(Color.CYAN)
            }
            p.addView(option)
        }

        val close = TextView(this).apply {
            text = "FECHAR PAINEL ×"
            gravity = Gravity.CENTER
            setTextColor(Color.CYAN)
            setPadding(10, 20, 10, 10)
            setOnClickListener { togglePanel() }
        }
        p.addView(close)

        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.82f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        panel = p
        wm.addView(p, params)
    }

    override fun onDestroy() {
        panel?.let { wm.removeView(it) }
        if (::bubble.isInitialized) wm.removeView(bubble)
        super.onDestroy()
    }
}
