@echo off
setlocal
title Abdul Samad Watches POS (Offline)

set "APP_FILE=%~dp0abdul_samad_watches_pos.html"
if not exist "%APP_FILE%" (
    echo ERROR: abdul_samad_watches_pos.html not found next to this script!
    pause
    exit /b 1
)

echo Starting Abdul Samad Watches POS offline...
start "" "%APP_FILE%"
exit /b 0
