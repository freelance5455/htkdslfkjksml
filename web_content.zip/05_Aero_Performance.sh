#!/bin/bash
# Aero Performance v1.4.0 - Comandos limpos com 2>/dev/null || true
echo "Aplicando Aero Performance..."

settings put global window_animation_scale 0 2>/dev/null || true
settings put global transition_animation_scale 0 2>/dev/null || true
settings put global animator_duration_scale 0 2>/dev/null || true
settings put system peak_refresh_rate 120 2>/dev/null || true
settings put system min_refresh_rate 120 2>/dev/null || true
settings put global force_gpu_rendering 1 2>/dev/null || true
settings put global disable_hw_overlays 1 2>/dev/null || true
setprop debug.performance.tuning 1 2>/dev/null || true
setprop persist.sys.ui.hw 1 2>/dev/null || true
setprop debug.sf.hw 1 2>/dev/null || true
pm trim-caches 999G 2>/dev/null || true

echo "Aero Performance aplicado!"
