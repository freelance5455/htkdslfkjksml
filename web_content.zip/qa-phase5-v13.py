"""Phase 5 UI regression: all career tracks/projects, portfolio, legacy saves.
Real Chromium DOM controls, inlined scripts and isolated localStorage fixture.
Never uses actual personal storage. Offline test is separate Node simulation.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json, re
ROOT=Path(__file__).resolve().parent
html=(ROOT/'index.html').read_text('utf-8')
for f in ('curriculum-v6.js','curriculum-v7.js','university-v8.js','inquiry-v9.js','kingdom-v10.js','career-v11.js','life-v12.js','curriculum-v13.js','academy-v13.js'):
    assert f'<script src="{f}"></script>' in html
    html=html.replace(f'<script src="{f}"></script>','<script>\n'+(ROOT/f).read_text('utf-8')+'\n</script>')
for f in ('university-v8.css','inquiry-v9.css','kingdom-v10.css','career-v11.css','life-v12.css','academy-v13.css'):
    assert f'<link rel="stylesheet" href="{f}">' in html
    html=html.replace(f'<link rel="stylesheet" href="{f}">','<style>'+ (ROOT/f).read_text('utf-8')+'</style>')
html=re.sub(r'<link rel="preconnect"[^>]*>|<link href="https://fonts.googleapis.com[^>]*>','',html)

def setup(browser,db=None,viewport=None):
    ctx=browser.new_context(viewport=viewport or {'width':390,'height':844},accept_downloads=True)
    page=ctx.new_page(); page.set_default_timeout(6500)
    errors=[];page.on('pageerror',lambda error:errors.append(str(error)))
    data=db if db is not None else {'loonieAcademy_v1':json.dumps({'onboarded':True,'done':{'79':'5/5'},'stars':{'79':3},'notes':{'79':'Existing lesson note from v10'},'checks':{},'sound':False,'kingdomV10':{'quests':{'lantern:0':{'finishedAt':1720000000}},'notes':{'lantern':'Existing kingdom story note'},'sparks':1}})}
    page.evaluate('''db=>{window.__db=db;Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>window.__db[k]??null,setItem:(k,v)=>window.__db[k]=String(v),removeItem:k=>delete window.__db[k],clear:()=>Object.keys(window.__db).forEach(k=>delete window.__db[k])}});}''',data)
    page.set_content(html,wait_until='domcontentloaded',timeout=90000)
    page.wait_for_function('window.LOONIE_V11 && window.LOONIE_V10 && window.LOONIE_V9 && window.LOONIE_V8')
    assert not errors,errors
    return ctx,page,errors

def route(page,h):
    page.evaluate('''()=>{document.querySelectorAll('.overlay').forEach(e=>e.remove());}''')
    page.evaluate('h=>{location.hash="#"+h;route();}',h)
    msg=page.locator('#screen').inner_text()
    assert 'Something went wrong' not in msg,(h,msg[:500])
    assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth + 1'),(h,page.evaluate('document.documentElement.scrollWidth'),page.evaluate('window.innerWidth'))

def answer_project(page,project,correct=True):
    questions=project['questions']
    for i,q in enumerate(questions):
        if q['type']=='number':
            answer=q['a'] if correct else q['a']+999
            page.locator(f'[data-answer="{i}"]').fill(str(answer))
        else:
            answer=q['a'] if correct else (q['a']+1)%len(q['opts'])
            page.locator(f'.cp-choice[data-q="{i}"][data-a="{answer}"]').click()
    for i in range(3):
        page.locator(f'[data-note="{i}"]').fill('I reviewed all of the fictional input evidence and documented how this calculation supports a limited recommendation. '+str(i))
    page.locator('#cp-submit').click()

with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    ctx,page,errors=setup(browser)
    for v in ('LOONIE_V11','LOONIE_V10','LOONIE_V9','LOONIE_V8'):
        assert page.evaluate(f'{v}.validate().ok'),(v,page.evaluate(f'{v}.validate()'))
    counts=page.evaluate('({lessons:LESSONS.length,subjects:SUBJECTS.length,questions:LESSONS.reduce((a,l)=>a+l.quiz.length,0)})')
    assert counts=={'lessons':807,'subjects':37,'questions':3714},counts
    assert page.evaluate('state.notes[79]')=='Existing lesson note from v10'
    assert page.evaluate('state.kingdomV10.notes.lantern')=='Existing kingdom story note'
    assert page.evaluate('LOONIE_V11.validate().projects')==16
    assert page.evaluate('LOONIE_V11.validate().objectiveChecks')==64
    print('SOURCE/CATALOGS',counts,'PASS',flush=True)
    for h,s in [('learn','Study hub'),('career','Career Pathways & Portfolios'),('career11','Build skills'),('path11-accounting','Accounting & Bookkeeping'),('portfolio11','Portfolio Studio'),('careerplan11','Make a plan'),('work11-new','Bring your own work'),('world','Knowledge Kingdom'),('kingdom','Every lesson'),('uni','Personal University'),('inquiry','Inquiry Studio'),('lab','Lab'),('me','My Career Portfolio')]:
        route(page,h)
        assert s.lower() in page.locator('#screen').inner_text().lower(),(h,s)
        print('ROUTE',h,'PASS',flush=True)
    route(page,'career11')
    assert page.locator('.cp-pathcard').count()==8
    page.locator('#cp-search').fill('Carpentry')
    assert page.locator('.cp-pathcard').count()==1
    page.locator('#cp-search').fill('')
    page.locator('button[data-cat="Skilled trades"]').click()
    assert page.locator('.cp-pathcard').count()==4
    route(page,'path11-carpentry')
    assert page.locator('.cp-lessonrow').count()==4
    page.locator('#cp-activate').click()
    assert page.evaluate('state.careerV11.active')=='carpentry'
    route(page,'careerplan11')
    page.locator('#cp-goal').fill('I will complete two lessons, pass the estimator case, and explain the quote limitations.')
    page.locator('#cp-weekly').select_option('240')
    assert page.evaluate('state.careerV11.portfolio.weeklyMinutes')==240
    print('SEARCH/FILTER/ACTIVE/PLAN PASS',flush=True)
    # Explicit negative gates, incorrect answers, partial evidence, and no rewards.
    route(page,'project11-accounting-1')
    assert page.locator('#cp-submit').count()==0
    assert not page.evaluate('LOONIE_V11.submit("accounting-1").ok')
    project_list=page.evaluate('LOONIE_V11.projects')
    for index,pr in enumerate(page.evaluate('LOONIE_V11.paths')):
        ids=page.evaluate('id=>LOONIE_V11.lessons(LOONIE_V11.paths.find(x=>x.id===id))',pr['id'])
        # Simulate learner having ALREADY finished original lesson quizzes; do not fabricate grade in product.
        page.evaluate('ids=>{for(const id of ids){state.done[id]="4/4";state.stars[id]=3;}save();}',ids)
        first,second=pr['projects']
        route(page,'project11-'+second)
        assert page.locator('#cp-submit').count()==0,second
        for n,project_id in enumerate([first,second]):
            project=next(x for x in project_list if x['id']==project_id)
            route(page,'project11-'+project_id)
            assert page.locator('.cp-question').count()==4,project_id
            if index==0 and n==0:
                page.locator('#cp-submit').click()
                assert 'Answer check 1' in page.locator('#cp-formmessage').inner_text()
                xp_before=page.evaluate('state.xp')
                answer_project(page,project,correct=False)
                assert not page.evaluate('LOONIE_V11.store().projects["accounting-1"].passedAt')
                assert page.evaluate('state.xp')==xp_before
                route(page,'project11-accounting-1')
            before=page.evaluate('({xp:state.xp,coins:state.coins})')
            answer_project(page,project,correct=True)
            assert page.evaluate('id=>LOONIE_V11.store().projects[id].passedAt>0',project_id),project_id
            assert page.evaluate('id=>LOONIE_V11.store().projects[id].verified.correct',project_id)==4
            assert page.evaluate('id=>LOONIE_V11.store().projects[id].evidence.length',project_id)==3
            if index==0 and n==0:
                assert page.evaluate('state.xp')>=before['xp']+60
                route(page,'project11-accounting-1')
                page.wait_for_timeout(650)  # allow legacy daily missions to settle before anti-farming comparison
                wallet=page.evaluate('({xp:state.xp,coins:state.coins})')
                answer_project(page,project,correct=True)
                after=page.evaluate('({xp:state.xp,coins:state.coins})'); print('REPLAY WALLET before/after',wallet,after, 'record',page.evaluate('LOONIE_V11.store().projects["accounting-1"].attempts'),flush=True); assert after==wallet,'replay rewarded again!'
                route(page,'project11-accounting-1')
                page.locator('[data-note="0"]').fill('UPDATED validated note for the published portfolio. I retested the relevant calculation and explained assumptions.')
                page.locator('#cp-revise').click()
                assert 'UPDATED' in page.evaluate('LOONIE_V11.store().projects["accounting-1"].evidence[0]')
        assert page.evaluate('id=>LOONIE_V11.counters(LOONIE_V11.paths.find(p=>p.id===id)).percent',pr['id'])==100
        print('PATH',pr['id'],'2 UI cases, 8 checks, evidence, milestone tracking PASS',flush=True)
    assert page.evaluate('LOONIE_V11.summary().completed')==16
    assert page.evaluate('LOONIE_V11.summary().finishedPaths')==8
    assert page.evaluate('state.ach["career-path"]')
    route(page,'portfolio11')
    assert page.locator('.cp-include').count()==16
    page.locator('[data-profile="displayName"]').fill('<script>alert(9)</script>')
    page.locator('[data-profile="headline"]').fill('Career case studies and practice evidence')
    page.locator('[data-profile="about"]').fill('I am developing realistic workplace skills in a simulated training environment.')
    assert page.evaluate('LOONIE_V11.renderDocument().includes("&lt;script&gt;alert(9)&lt;/script&gt;")')
    assert not page.evaluate('LOONIE_V11.renderDocument().includes("<script>alert(9)</script>")')
    page.locator('[data-include="accounting-2"]').uncheck()
    assert page.evaluate('LOONIE_V11.portfolioItems().length')==15
    assert not page.evaluate('LOONIE_V11.renderMarkdown().includes("Prepare an Adjusted Profit Snapshot")')
    with page.expect_download() as d:
        page.locator('#cp-export-html').click()
    download=d.value
    assert download.suggested_filename=='loonie-career-portfolio.html'
    exported=download.path().read_text() if False else Path(download.path()).read_text()
    assert 'Reconcile the April Cash Account' in exported
    assert '<script>alert(9)</script>' not in exported
    assert 'Adjusted Profit Snapshot' not in exported
    assert 'Educational practice' in exported
    with page.expect_download() as d:
        page.locator('#cp-export-json').click()
    blob=json.loads(Path(d.value.path()).read_text())
    assert blob['format']=='loonie-academy-career-portfolio' and len(blob['items'])==15
    assert 'state' not in blob and 'kingdomV10' not in blob
    print('EXPORT HTML/JSON, SELECTIVE INCLUSION, HTML ESCAPE PASS',flush=True)
    route(page,'work11-new')
    page.locator('#cp-wtitle').fill('<img src=x onerror=alert(4)> Personal project')
    page.locator('#cp-wcategory').fill('Portfolio')
    page.locator('#cp-wdesc').fill('I built a fictional project that I can explain and revise with sample data; no customer records were used.')
    page.locator('#cp-wevidence').fill('I documented checks and limitations so a reviewer can understand which results are unverified.')
    page.locator('#cp-wurl').fill('javascript:alert(1)')
    page.locator('#cp-workform button[type="submit"]').click()
    assert 'valid HTTP' in page.locator('#cp-workmessage').inner_text()
    page.locator('#cp-wurl').fill('https://example.com/sample')
    page.locator('#cp-workform button[type="submit"]').click()
    assert page.evaluate('LOONIE_V11.summary().custom')==1
    assert page.evaluate('LOONIE_V11.portfolioItems().length')==16
    assert page.locator('#cp-preview img').count()==0
    assert '<img src=x onerror=alert(4)>' not in page.evaluate('LOONIE_V11.renderDocument()')
    assert 'https://example.com/sample' in page.evaluate('LOONIE_V11.renderDocument()')
    route(page,'work11-manual-1')
    page.locator('#cp-wdesc').fill('I built a fictional project with a new description and several reliable practice examples for my records.')
    page.locator('#cp-workform button[type="submit"]').click()
    assert 'new description' in page.evaluate('LOONIE_V11.store().custom["manual-1"].description')
    route(page,'work11-manual-1')
    page.locator('#cp-wdelete').click()
    assert page.evaluate('LOONIE_V11.summary().custom')==1
    page.locator('#cp-wdelete').click()
    assert page.evaluate('LOONIE_V11.summary().custom')==0
    print('CUSTOM PROJECT ADD/EDIT/DELETE, URL VALIDATION, XSS ESCAPE PASS',flush=True)
    route(page,'portfolio11')
    backup=page.evaluate('makeBackup()')
    parsed=json.loads(backup)
    assert parsed['state']['notes']['79']=='Existing lesson note from v10'
    assert parsed['state']['kingdomV10']['notes']['lantern']=='Existing kingdom story note'
    assert parsed['state']['careerV11']['projects']['accounting-1']['passedAt']
    assert page.evaluate('txt=>parseBackup(txt).checksum',backup)==parsed['checksum']
    db=page.evaluate('window.__db')
    ctx2,new,err2=setup(browser,db,{'width':1280,'height':800})
    assert new.evaluate('LOONIE_V11.summary().completed')==16
    assert new.evaluate('LOONIE_V11.store().active')=='carpentry'
    assert new.evaluate('state.notes[79]')=='Existing lesson note from v10'
    assert new.evaluate('state.kingdomV10.notes.lantern')=='Existing kingdom story note'
    for h in ['career11','path11-software','project11-software-2','portfolio11','careerplan11','kingdom','uni']:
        route(new,h)
    assert not errors and not err2,(errors,err2)
    print('BACKUP/RELOAD, LEGACY DATA, 390/1280 PX, NO JS ERRORS PASS',flush=True)
    new.close();ctx2.close();page.close();ctx.close();browser.close()
print('PHASE 5 FULL TEST SUITE PASSED')
