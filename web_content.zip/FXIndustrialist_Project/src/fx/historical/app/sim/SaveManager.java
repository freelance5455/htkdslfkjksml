package fx.historical.app.sim;

import fx.historical.app.core.GameData;
import fx.historical.app.core.Hex;
import fx.historical.app.core.Json;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Crash-safe local saves: write temp file, fsync, keep the previous good save as .bak, then rename.
 * Every save carries a SHA-256 checksum; a corrupt or interrupted main file falls back to the backup.
 */
public final class SaveManager {
    public static final class Loaded {
        public final Factory factory;
        public final String warning;
        Loaded(Factory f, String w) { factory = f; warning = w; }
    }

    private final File main, backup, tmp;

    public SaveManager(File dir, String slotName) {
        dir.mkdirs();
        main = new File(dir, slotName + ".json");
        backup = new File(dir, slotName + ".bak");
        tmp = new File(dir, slotName + ".tmp");
    }

    public boolean exists() { return main.exists() || backup.exists(); }

    /** @return null on success, otherwise a short error message safe to show to the player. */
    public String save(Factory f) {
        try {
            String body = Json.write(f.toMap());
            Map<String, Object> wrap = new LinkedHashMap<>();
            wrap.put("v", 1L);
            wrap.put("sha256", Hex.sha256(body));
            wrap.put("body", body);
            byte[] bytes = Json.write(wrap).getBytes(StandardCharsets.UTF_8);
            try (FileOutputStream out = new FileOutputStream(tmp)) {
                out.write(bytes);
                out.flush();
                out.getFD().sync();
            }
            // only promote the current main file to backup if it is itself intact, so a corrupt file never overwrites the good backup
            if (main.exists() && checksumOk(main)) Files.copy(main.toPath(), backup.toPath(), StandardCopyOption.REPLACE_EXISTING);
            Files.move(tmp.toPath(), main.toPath(), StandardCopyOption.REPLACE_EXISTING);
            return null;
        } catch (IOException | RuntimeException e) {
            tmp.delete();
            return "Save failed: " + e.getClass().getSimpleName();
        }
    }

    /** Returns null if there is no usable save at all. */
    public Loaded load(GameData data) {
        String warning = null;
        if (main.exists()) {
            try { return new Loaded(read(main, data), null); }
            catch (IOException | Json.JsonException e) { warning = "Main save damaged, restored from backup"; }
        }
        if (backup.exists()) {
            try { return new Loaded(read(backup, data), warning == null ? "Loaded backup save" : warning); }
            catch (IOException | Json.JsonException e) { return null; }
        }
        return null;
    }

    private static boolean checksumOk(File f) {
        try { return unwrap(f) != null; } catch (IOException | Json.JsonException e) { return false; }
    }

    private static Factory read(File f, GameData data) throws IOException, Json.JsonException {
        return Factory.fromMap(data, Json.parseObject(unwrap(f)));
    }

    /** Reads the wrapper, verifies the checksum and returns the inner save body. */
    private static String unwrap(File f) throws IOException, Json.JsonException {
        if (f.length() > 16_000_000) throw new IOException("too large");
        byte[] buf = new byte[(int) f.length()];
        try (FileInputStream in = new FileInputStream(f)) {
            int off = 0;
            while (off < buf.length) {
                int n = in.read(buf, off, buf.length - off);
                if (n < 0) throw new IOException("short read");
                off += n;
            }
        }
        Map<String, Object> wrap = Json.parseObject(new String(buf, StandardCharsets.UTF_8));
        String body = Json.str(wrap, "body", "");
        if (!Hex.constantTimeEquals(Hex.sha256(body), Json.str(wrap, "sha256", ""))) throw new Json.JsonException("checksum mismatch");
        return body;
    }

    /** Copies the current main save to a labelled one-off backup (used before a load drops buildings of removed mods). */
    public boolean snapshot(String label) {
        try {
            if (!main.exists()) return false;
            File dst = new File(main.getParentFile(), main.getName().replace(".json", "") + "." + label + ".bak");
            Files.copy(main.toPath(), dst.toPath(), StandardCopyOption.REPLACE_EXISTING);
            return true;
        } catch (IOException e) { return false; }
    }

    public long sizeBytes() { return (main.exists() ? main.length() : 0) + (backup.exists() ? backup.length() : 0); }

    public void deleteAll() { main.delete(); backup.delete(); tmp.delete(); }
}
