package fx.historical.app.sim;

import java.util.LinkedHashMap;
import java.util.Map;

/** One placed machine plus its runtime state. Pure data; all rules live in {@link Factory}. */
public final class Building {
    public enum State { OK, IDLE, NO_POWER, NO_INPUT, BLOCKED, INVALID }

    public final String machineId;
    public final int x, y;
    /** 0=East, 1=South, 2=West, 3=North. */
    public int rot;

    /** Conveyor / splitter single-item slot (null = empty) and how long it has waited, in ticks. */
    public String slot;
    public int wait;

    /** Fixed-point progress (100 = one tick at full power). */
    public int progress;
    public String recipeId;
    public final Map<String, Integer> inBuf = new LinkedHashMap<>();
    public final Map<String, Integer> outBuf = new LinkedHashMap<>();
    public int rr;
    public boolean active;
    public State state = State.IDLE;

    public Building(String machineId, int x, int y, int rot) {
        this.machineId = machineId; this.x = x; this.y = y; this.rot = rot & 3;
    }

    public static int total(Map<String, Integer> m) {
        int t = 0;
        for (int v : m.values()) t += v;
        return t;
    }

    public static void add(Map<String, Integer> m, String k, int n) {
        Integer c = m.get(k);
        m.put(k, (c == null ? 0 : c) + n);
    }

    public static boolean take(Map<String, Integer> m, String k, int n) {
        Integer c = m.get(k);
        if (c == null || c < n) return false;
        if (c == n) m.remove(k); else m.put(k, c - n);
        return true;
    }
}
