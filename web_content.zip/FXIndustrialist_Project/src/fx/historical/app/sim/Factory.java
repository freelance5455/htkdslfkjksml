package fx.historical.app.sim;

import fx.historical.app.core.GameData;
import fx.historical.app.core.GameData.Kind;
import fx.historical.app.core.GameData.MachineDef;
import fx.historical.app.core.GameData.Recipe;
import fx.historical.app.core.Json;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Deterministic, tick-based factory simulation and the single authority for every action
 * (place / remove / rotate / research). A future multiplayer server would call exactly these methods.
 *
 * Model: fixed 10 ticks per second, integer arithmetic only, buildings stepped in stable insertion order.
 * No per-item threads or loops: only buildings are stepped, items are counters or single slots.
 * Items are never created or destroyed except through the audited ledger (mine, recipe, sell, discard).
 */
public final class Factory {
    public static final int TICKS_PER_SECOND = 10;
    public static final int FORMAT_VERSION = 1;
    public static final int BUFFER_CAP = 8;
    public static final int MINER_BUFFER = 5;
    public static final long START_MONEY = 400;
    private static final int[] DX = {1, 0, -1, 0};
    private static final int[] DY = {0, 1, 0, -1};
    /** Resource ids by resource-layer value (0 = none). */
    public static final String[] RESOURCE = {null, "iron_ore", "copper_ore"};

    public static final class Result {
        public final boolean ok;
        public final String message;
        Result(boolean ok, String message) { this.ok = ok; this.message = message; }
    }

    public final int width, height;
    public final long seed;
    public GameData data;

    private final Building[] cells;
    private final byte[] resources;
    private final List<Building> order = new ArrayList<>();

    public long tick;
    /** Buildings dropped on load because their machine no longer exists (e.g. a removed mod). */
    public int skippedOnLoad;
    public long money = START_MONEY;
    public final Set<String> techs = new LinkedHashSet<>();

    // statistics and item ledger
    public long mined, recipeCreated, sold, discarded, recipeConsumed, earned;
    public final Map<String, Long> soldByItem = new LinkedHashMap<>();
    private final long[] earnedRing = new long[60];
    private long earnedAtLastSecond;

    // power (recomputed every tick)
    public int powerSupply, powerDemand, satisfactionPct = 100;

    public Factory(GameData data, int width, int height, long seed) {
        this.data = data; this.width = width; this.height = height; this.seed = seed;
        cells = new Building[width * height];
        resources = new byte[width * height];
        generateResources();
    }

    // ------------------------------------------------------------------ world

    private void generateResources() {
        long s = seed * 6364136223846793005L + 1442695040888963407L;
        int patches = Math.max(4, width * height / 140);
        for (int p = 0; p < patches; p++) {
            s = s * 6364136223846793005L + 1442695040888963407L;
            int cx = (int) ((s >>> 33) % width);
            s = s * 6364136223846793005L + 1442695040888963407L;
            int cy = (int) ((s >>> 33) % height);
            int type = 1 + (p & 1);
            int r = 2 + (p % 2);
            for (int y = cy - r; y <= cy + r; y++)
                for (int x = cx - r; x <= cx + r; x++)
                    if (inBounds(x, y) && (x - cx) * (x - cx) + (y - cy) * (y - cy) <= r * r + 1)
                        resources[y * width + x] = (byte) type;
        }
        // guaranteed starter patches near the origin so a new player always has both ores close by
        for (int y = 2; y <= 4; y++) for (int x = 2; x <= 4; x++) setRes(x, y, 1);
        for (int y = 2; y <= 4; y++) for (int x = 7; x <= 9; x++) setRes(x, y, 2);
    }

    private void setRes(int x, int y, int t) { if (inBounds(x, y)) resources[y * width + x] = (byte) t; }

    public boolean inBounds(int x, int y) { return x >= 0 && y >= 0 && x < width && y < height; }

    public int resourceAt(int x, int y) { return inBounds(x, y) ? resources[y * width + x] : 0; }

    public Building at(int x, int y) { return inBounds(x, y) ? cells[y * width + x] : null; }

    public List<Building> buildings() { return order; }

    public boolean isUnlocked(MachineDef m) { return m.tech.isEmpty() || techs.contains(m.tech); }

    // ------------------------------------------------------------------ actions (authoritative validation)

    public Result place(String machineId, int x, int y, int rot) {
        MachineDef m = data.machines.get(machineId);
        if (m == null) return new Result(false, "Unknown machine");
        if (!inBounds(x, y)) return new Result(false, "Outside the plot");
        if (at(x, y) != null) return new Result(false, "Tile is occupied");
        if (!isUnlocked(m)) return new Result(false, "Research " + m.tech + " first");
        if (m.kind == Kind.MINER && resourceAt(x, y) == 0) return new Result(false, "Miner needs an ore tile");
        if (money < m.cost) return new Result(false, "Not enough money (" + m.cost + " needed)");
        money -= m.cost;
        Building b = new Building(machineId, x, y, rot);
        cells[y * width + x] = b;
        order.add(b);
        return new Result(true, "Placed " + m.name);
    }

    public Result remove(int x, int y) {
        Building b = at(x, y);
        if (b == null) return new Result(false, "Nothing here");
        MachineDef m = data.machines.get(b.machineId);
        int lost = (b.slot == null ? 0 : 1) + Building.total(b.inBuf) + Building.total(b.outBuf);
        discarded += lost;
        if (m != null) money += m.cost / 2;
        cells[y * width + x] = null;
        order.remove(b);
        return new Result(true, "Removed" + (lost > 0 ? " (" + lost + " items discarded)" : ""));
    }

    public Result rotate(int x, int y) {
        Building b = at(x, y);
        if (b == null) return new Result(false, "Nothing here");
        b.rot = (b.rot + 1) & 3;
        return new Result(true, "Rotated");
    }

    public Result research(String techId) {
        GameData.Tech t = data.techs.get(techId);
        if (t == null) return new Result(false, "Unknown technology");
        if (techs.contains(techId)) return new Result(false, "Already researched");
        for (String q : t.requires) if (!techs.contains(q)) return new Result(false, "Requires " + q);
        if (money < t.cost) return new Result(false, "Not enough money (" + t.cost + " needed)");
        money -= t.cost;
        techs.add(techId);
        return new Result(true, "Researched " + t.name);
    }

    // ------------------------------------------------------------------ simulation

    public void tick() {
        tick++;
        computePower();
        for (int i = 0; i < order.size(); i++) step(order.get(i));
        if (tick % TICKS_PER_SECOND == 0) {
            earnedRing[(int) ((tick / TICKS_PER_SECOND) % earnedRing.length)] = earned - earnedAtLastSecond;
            earnedAtLastSecond = earned;
        }
    }

    public void run(int ticks) { for (int i = 0; i < ticks; i++) tick(); }

    public long earnedPerMinute() {
        long t = 0;
        for (long v : earnedRing) t += v;
        return t;
    }

    private void computePower() {
        int supply = 0, demand = 0;
        for (Building b : order) {
            MachineDef m = data.machines.get(b.machineId);
            if (m == null) continue;
            if (m.kind == Kind.GENERATOR) supply += -m.power;
            else if (m.power > 0 && b.active) demand += m.power;
        }
        powerSupply = supply;
        powerDemand = demand;
        satisfactionPct = demand == 0 ? 100 : Math.min(100, supply * 100 / demand);
    }

    private void step(Building b) {
        MachineDef m = data.machines.get(b.machineId);
        if (m == null) { b.state = Building.State.INVALID; return; }
        switch (m.kind) {
            case MINER: stepMiner(b, m); break;
            case CONVEYOR: stepConveyor(b, m, false); break;
            case SPLITTER: stepConveyor(b, m, true); break;
            case PROCESSOR: stepProcessor(b, m); break;
            case GENERATOR: b.state = Building.State.OK; break;
            case SELLER: b.state = Building.State.OK; break;
        }
    }

    private boolean powered(Building b, MachineDef m) {
        if (m.power <= 0) return true;
        if (satisfactionPct == 0) { b.state = Building.State.NO_POWER; return false; }
        return true;
    }

    private void stepMiner(Building b, MachineDef m) {
        String ore = RESOURCE[Math.min(resourceAt(b.x, b.y), RESOURCE.length - 1)];
        if (ore == null) { b.state = Building.State.INVALID; b.active = false; return; }
        pushOut(b);
        if (Building.total(b.outBuf) >= MINER_BUFFER) { b.state = Building.State.BLOCKED; b.active = false; return; }
        b.active = true;
        if (!powered(b, m)) return;
        b.progress += satisfactionPct;
        if (b.progress >= m.cycleTicks * 100) {
            b.progress = 0;
            Building.add(b.outBuf, ore, 1);
            mined++;
        }
        b.state = Building.State.OK;
    }

    private void stepConveyor(Building b, MachineDef m, boolean splitter) {
        if (b.slot == null) { b.state = Building.State.IDLE; return; }
        if (b.wait < m.cycleTicks) b.wait++;
        if (b.wait < m.cycleTicks) { b.state = Building.State.OK; return; }
        boolean moved = false;
        if (splitter) {
            for (int k = 0; k < 3 && !moved; k++) {
                int dir = (b.rot + (b.rr + k) % 3 - 1) & 3; // left, front, right rotation
                int idx = (b.rr + k) % 3;
                if (offer(b, dir, b.slot)) { moved = true; b.rr = (idx + 1) % 3; }
            }
        } else {
            moved = offer(b, b.rot, b.slot);
        }
        if (moved) { b.slot = null; b.wait = 0; b.state = Building.State.OK; }
        else b.state = Building.State.BLOCKED;
    }

    private void stepProcessor(Building b, MachineDef m) {
        pushOut(b);
        // finish a running recipe
        if (b.recipeId != null) {
            Recipe r = data.recipes.get(b.recipeId);
            if (r == null) { b.recipeId = null; b.progress = 0; b.state = Building.State.INVALID; return; }
            b.active = true;
            if (b.progress < r.ticks * 100) {
                if (!powered(b, m)) return;
                b.progress += satisfactionPct;
                b.state = Building.State.OK;
                if (b.progress < r.ticks * 100) return;
            }
            if (Building.total(b.outBuf) + Building.total(r.outputs) > BUFFER_CAP) { b.state = Building.State.BLOCKED; return; }
            for (Map.Entry<String, Integer> e : r.outputs.entrySet()) {
                Building.add(b.outBuf, e.getKey(), e.getValue());
                recipeCreated += e.getValue();
            }
            b.recipeId = null;
            b.progress = 0;
        }
        // start the next recipe if every input is present (inputs are consumed atomically)
        for (Recipe r : data.recipesFor(m.id)) {
            if (hasAll(b.inBuf, r.inputs)) {
                for (Map.Entry<String, Integer> e : r.inputs.entrySet()) {
                    Building.take(b.inBuf, e.getKey(), e.getValue());
                    recipeConsumed += e.getValue();
                }
                b.recipeId = r.id;
                b.progress = 0;
                b.active = true;
                b.state = Building.State.OK;
                return;
            }
        }
        b.active = false;
        b.state = Building.State.NO_INPUT;
    }

    private static boolean hasAll(Map<String, Integer> buf, Map<String, Integer> need) {
        for (Map.Entry<String, Integer> e : need.entrySet()) {
            Integer c = buf.get(e.getKey());
            if (c == null || c < e.getValue()) return false;
        }
        return true;
    }

    /** Moves at most one item from the building's output buffer to the cell it faces. */
    private void pushOut(Building b) {
        if (b.outBuf.isEmpty()) return;
        String item = b.outBuf.keySet().iterator().next();
        if (offer(b, b.rot, item)) Building.take(b.outBuf, item, 1);
    }

    /** Atomic transfer: the item is accepted by the neighbour or nothing changes. */
    private boolean offer(Building from, int dir, String item) {
        Building to = at(from.x + DX[dir], from.y + DY[dir]);
        if (to == null) return false;
        MachineDef m = data.machines.get(to.machineId);
        if (m == null) return false;
        switch (m.kind) {
            case CONVEYOR:
                // a conveyor cannot be fed from the tile it faces
                if (to.x + DX[to.rot] == from.x && to.y + DY[to.rot] == from.y) return false;
                if (to.slot != null) return false;
                to.slot = item; to.wait = 0;
                return true;
            case SPLITTER:
                // splitters only accept from directly behind
                if (to.x - DX[to.rot] != from.x || to.y - DY[to.rot] != from.y) return false;
                if (to.slot != null) return false;
                to.slot = item; to.wait = 0;
                return true;
            case PROCESSOR:
                if (!isInputOf(m.id, item) || to.inBuf.getOrDefault(item, 0) >= BUFFER_CAP) return false;
                Building.add(to.inBuf, item, 1);
                return true;
            case SELLER: {
                GameData.ItemDef def = data.items.get(item);
                if (def == null) return false;
                money += def.sellPrice; earned += def.sellPrice; sold++;
                soldByItem.merge(item, 1L, Long::sum);
                return true;
            }
            default:
                return false;
        }
    }

    private boolean isInputOf(String machineId, String item) {
        for (Recipe r : data.recipesFor(machineId)) if (r.inputs.containsKey(item)) return true;
        return false;
    }

    // ------------------------------------------------------------------ audit

    /** Items currently held anywhere in the factory. */
    public long itemsInSystem() {
        long t = 0;
        for (Building b : order) t += (b.slot == null ? 0 : 1) + Building.total(b.inBuf) + Building.total(b.outBuf);
        return t;
    }

    /** Must always be 0: every item created is accounted for as held, sold, discarded or consumed. */
    public long ledgerBalance() {
        return (mined + recipeCreated) - (sold + discarded + recipeConsumed) - itemsInSystem();
    }

    public String describe(Building b) {
        MachineDef m = data.machines.get(b.machineId);
        StringBuilder sb = new StringBuilder(m == null ? b.machineId : m.name);
        sb.append(" — ").append(stateText(b.state));
        if (b.slot != null) sb.append(" | carrying ").append(b.slot);
        if (!b.inBuf.isEmpty()) sb.append(" | in ").append(b.inBuf);
        if (!b.outBuf.isEmpty()) sb.append(" | out ").append(b.outBuf);
        return sb.toString();
    }

    public static String stateText(Building.State s) {
        switch (s) {
            case OK: return "working";
            case IDLE: return "idle";
            case NO_POWER: return "no power";
            case NO_INPUT: return "waiting for input";
            case BLOCKED: return "output blocked";
            default: return "invalid (check recipe/tile)";
        }
    }

    // ------------------------------------------------------------------ persistence

    public Map<String, Object> toMap() {
        Map<String, Object> root = new LinkedHashMap<>();
        root.put("format", (long) FORMAT_VERSION);
        root.put("width", (long) width);
        root.put("height", (long) height);
        root.put("seed", seed);
        root.put("tick", tick);
        root.put("money", money);
        root.put("techs", new ArrayList<Object>(techs));
        Map<String, Object> st = new LinkedHashMap<>();
        st.put("mined", mined); st.put("recipeCreated", recipeCreated); st.put("sold", sold);
        st.put("discarded", discarded); st.put("recipeConsumed", recipeConsumed); st.put("earned", earned);
        root.put("stats", st);
        List<Object> bl = new ArrayList<>();
        for (Building b : order) {
            Map<String, Object> o = new LinkedHashMap<>();
            o.put("m", b.machineId); o.put("x", (long) b.x); o.put("y", (long) b.y); o.put("r", (long) b.rot);
            if (b.slot != null) { o.put("slot", b.slot); o.put("wait", (long) b.wait); }
            if (b.progress != 0) o.put("p", (long) b.progress);
            if (b.recipeId != null) o.put("rec", b.recipeId);
            if (!b.inBuf.isEmpty()) o.put("in", new LinkedHashMap<String, Object>(b.inBuf));
            if (!b.outBuf.isEmpty()) o.put("out", new LinkedHashMap<String, Object>(b.outBuf));
            if (b.rr != 0) o.put("rr", (long) b.rr);
            bl.add(o);
        }
        root.put("buildings", bl);
        return root;
    }

    /** Rebuilds a factory; unknown machines (e.g. from a removed mod) are skipped and counted as discarded items. */
    public static Factory fromMap(GameData data, Map<String, Object> root) throws Json.JsonException {
        if (Json.lng(root, "format", -1) != FORMAT_VERSION) throw new Json.JsonException("unsupported save format");
        int w = (int) Json.lng(root, "width", 0), h = (int) Json.lng(root, "height", 0);
        if (w < 8 || h < 8 || w > 256 || h > 256) throw new Json.JsonException("bad plot size");
        Factory f = new Factory(data, w, h, Json.lng(root, "seed", 1));
        f.tick = Json.lng(root, "tick", 0);
        f.money = Json.lng(root, "money", START_MONEY);
        List<Object> tl = Json.arr(root.get("techs"));
        if (tl != null) for (Object o : tl) if (o instanceof String && data.techs.containsKey(o)) f.techs.add((String) o);
        Map<String, Object> st = Json.obj(root.get("stats"));
        f.mined = Json.lng(st, "mined", 0); f.recipeCreated = Json.lng(st, "recipeCreated", 0);
        f.sold = Json.lng(st, "sold", 0); f.discarded = Json.lng(st, "discarded", 0);
        f.recipeConsumed = Json.lng(st, "recipeConsumed", 0); f.earned = Json.lng(st, "earned", 0);
        f.earnedAtLastSecond = f.earned;
        List<Object> bl = Json.arr(root.get("buildings"));
        if (bl == null) throw new Json.JsonException("missing buildings");
        for (Object o : bl) {
            Map<String, Object> m = Json.obj(o);
            if (m == null) continue;
            String id = Json.str(m, "m", "");
            int x = (int) Json.lng(m, "x", -1), y = (int) Json.lng(m, "y", -1);
            Building b = new Building(id, x, y, (int) Json.lng(m, "r", 0));
            b.slot = Json.str(m, "slot", null);
            b.wait = (int) Json.lng(m, "wait", 0);
            b.progress = (int) Json.lng(m, "p", 0);
            b.recipeId = Json.str(m, "rec", null);
            readCounts(Json.obj(m.get("in")), b.inBuf);
            readCounts(Json.obj(m.get("out")), b.outBuf);
            b.rr = (int) Json.lng(m, "rr", 0);
            long held = (b.slot == null ? 0 : 1) + Building.total(b.inBuf) + Building.total(b.outBuf);
            if (!f.inBounds(x, y) || f.at(x, y) != null || !data.machines.containsKey(id)) {
                f.discarded += held; // never silently lose items: account for them
                f.skippedOnLoad++;
                continue;
            }
            f.cells[y * w + x] = b;
            f.order.add(b);
        }
        return f;
    }

    private static void readCounts(Map<String, Object> src, Map<String, Integer> dst) {
        if (src == null) return;
        for (Map.Entry<String, Object> e : src.entrySet())
            if (e.getValue() instanceof Number) {
                int n = ((Number) e.getValue()).intValue();
                if (n > 0 && n <= 1000) dst.put(e.getKey(), n);
            }
    }
}
