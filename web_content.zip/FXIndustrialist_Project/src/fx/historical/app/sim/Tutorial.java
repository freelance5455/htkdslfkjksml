package fx.historical.app.sim;

/** Stateless tutorial: the current step is derived from factory state, so it survives save/load. */
public final class Tutorial {
    private Tutorial() {}

    private static int count(Factory f, String id) {
        int n = 0;
        for (Building b : f.buildings()) if (b.machineId.equals(id)) n++;
        return n;
    }

    /** @return the instruction for the first unfinished step, or null when the tutorial is complete. */
    public static String current(Factory f) {
        if (count(f, "solar") < 1) return "1/8  Select Solar Array and tap a tile to place it. Machines need power.";
        if (count(f, "miner") < 1) return "2/8  Select Miner and place it on a dark ore tile (near the top-left).";
        if (count(f, "seller") < 1) return "3/8  Place a Seller a few tiles away. It buys items.";
        if (count(f, "conveyor") < 2) return "4/8  Drag Conveyors from the Miner to the Seller. Use Rotate to change direction.";
        if (f.sold < 1) return "5/8  Make sure the Miner faces the conveyor line. Wait for the first sale.";
        if (count(f, "smelter") < 1) return "6/8  Place a Smelter between Miner and Seller to turn ore into plates (worth more).";
        if (!f.techs.contains("logistics")) return "7/8  Open Research and unlock Logistics to get Splitters.";
        if (f.earned < 500) return "8/8  Grow your factory. Earn 500 total to finish the tutorial.";
        return null;
    }
}
