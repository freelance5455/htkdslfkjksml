package fx.historical.app.auth;

import fx.historical.app.core.Json;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.function.LongSupplier;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * Device-local accounts. Passwords are never stored: only PBKDF2-HMAC-SHA256 hashes with a per-account random salt.
 * Failed logins/recoveries trigger persistent exponential lockouts. Recovery uses a one-time recovery code
 * (shown once at registration, stored only as a hash) because there is no email backend.
 *
 * LIMIT: these accounts exist only on this device. Cloud accounts, email reset and cross-device sign-in need
 * a backend (see docs/ARCHITECTURE_DECISION_RECORD.md); this class is the interface a server-backed provider replaces.
 */
public final class LocalAuth {
    public static final int ITERATIONS = 120_000;
    public static final int MAX_FAILS_BEFORE_LOCK = 5;
    private static final SecureRandom RNG = new SecureRandom();
    private static final String GENERIC_FAIL = "Invalid username or password.";

    public static final class Result {
        public final boolean ok;
        public final String message;
        /** Only set by register() and recover(); show once and never store. */
        public final String recoveryCode;
        Result(boolean ok, String message, String recoveryCode) { this.ok = ok; this.message = message; this.recoveryCode = recoveryCode; }
    }

    public static final class Session {
        public final String username;
        public final String token;
        Session(String u, String t) { username = u; token = t; }
    }

    private final File file;
    private final LongSupplier clock;
    private final Map<String, Map<String, Object>> accounts = new LinkedHashMap<>();
    private Session session;

    public LocalAuth(File dir) { this(dir, System::currentTimeMillis); }

    public LocalAuth(File dir, LongSupplier clock) {
        dir.mkdirs();
        this.file = new File(dir, "accounts.json");
        this.clock = clock;
        load();
    }

    // ------------------------------------------------------------------ public API

    public synchronized Result register(String username, String password) {
        String err = validateUsername(username);
        if (err == null) err = validatePassword(username, password);
        if (err != null) return new Result(false, err, null);
        String key = username.toLowerCase(Locale.ROOT);
        if (accounts.containsKey(key)) return new Result(false, "That username is already taken.", null);
        Map<String, Object> a = new LinkedHashMap<>();
        a.put("name", username);
        a.put("created", clock.getAsLong());
        putHash(a, "pw", password);
        String code = newRecoveryCode();
        putHash(a, "rc", normalizeCode(code));
        a.put("fails", 0L);
        a.put("lockUntil", 0L);
        accounts.put(key, a);
        if (!persist()) { accounts.remove(key); return new Result(false, "Could not save the account on this device.", null); }
        session = new Session(username, token());
        return new Result(true, "Account created.", code);
    }

    public synchronized Result login(String username, String password) {
        Map<String, Object> a = username == null ? null : accounts.get(username.toLowerCase(Locale.ROOT));
        if (a == null) {
            hash("dummy-password", new byte[16], ITERATIONS); // equalise timing; do not reveal which usernames exist
            return new Result(false, GENERIC_FAIL, null);
        }
        long wait = lockRemaining(a);
        if (wait > 0) return new Result(false, "Too many attempts. Try again in " + (wait / 1000 + 1) + " s.", null);
        if (password != null && verify(a, "pw", password)) {
            a.put("fails", 0L); a.put("lockUntil", 0L);
            persist();
            session = new Session((String) a.get("name"), token());
            return new Result(true, "Signed in.", null);
        }
        registerFailure(a);
        return new Result(false, GENERIC_FAIL, null);
    }

    public synchronized Result recover(String username, String recoveryCode, String newPassword) {
        Map<String, Object> a = username == null ? null : accounts.get(username.toLowerCase(Locale.ROOT));
        if (a == null) {
            hash("dummy-password", new byte[16], ITERATIONS);
            return new Result(false, "Recovery details are not valid.", null);
        }
        long wait = lockRemaining(a);
        if (wait > 0) return new Result(false, "Too many attempts. Try again in " + (wait / 1000 + 1) + " s.", null);
        String err = validatePassword((String) a.get("name"), newPassword);
        if (err != null) return new Result(false, err, null);
        if (recoveryCode == null || !verify(a, "rc", normalizeCode(recoveryCode))) {
            registerFailure(a);
            return new Result(false, "Recovery details are not valid.", null);
        }
        putHash(a, "pw", newPassword);
        String code = newRecoveryCode(); // rotate: a used code can never be replayed
        putHash(a, "rc", normalizeCode(code));
        a.put("fails", 0L); a.put("lockUntil", 0L);
        persist();
        return new Result(true, "Password reset. Save your new recovery code.", code);
    }

    public synchronized Session session() { return session; }

    public synchronized void logout() { session = null; }

    public synchronized boolean hasAccounts() { return !accounts.isEmpty(); }

    /** Deletes the signed-in account (caller must separately delete its save data). */
    public synchronized boolean deleteCurrentAccount(String password) {
        if (session == null) return false;
        String key = session.username.toLowerCase(Locale.ROOT);
        Map<String, Object> a = accounts.get(key);
        if (a == null || !verify(a, "pw", password == null ? "" : password)) return false;
        accounts.remove(key);
        session = null;
        return persist();
    }

    // ------------------------------------------------------------------ validation

    public static String validateUsername(String u) {
        if (u == null || !u.matches("[A-Za-z0-9_]{3,20}")) return "Username must be 3-20 letters, digits or underscores.";
        return null;
    }

    public static String validatePassword(String user, String p) {
        if (p == null || p.length() < 8) return "Password must be at least 8 characters.";
        if (p.length() > 128) return "Password is too long.";
        if (!p.matches(".*[A-Za-z].*") || !p.matches(".*[0-9].*")) return "Password needs at least one letter and one digit.";
        if (user != null && p.equalsIgnoreCase(user)) return "Password must differ from the username.";
        return null;
    }

    // ------------------------------------------------------------------ internals

    private long lockRemaining(Map<String, Object> a) {
        return Math.max(0, Json.lng(a, "lockUntil", 0) - clock.getAsLong());
    }

    private void registerFailure(Map<String, Object> a) {
        long fails = Json.lng(a, "fails", 0) + 1;
        a.put("fails", fails);
        if (fails >= MAX_FAILS_BEFORE_LOCK) {
            long shift = Math.min(fails - MAX_FAILS_BEFORE_LOCK, 5);
            long lockMs = Math.min(30_000L << shift, 15 * 60_000L);
            a.put("lockUntil", clock.getAsLong() + lockMs);
        }
        persist();
    }

    private static byte[] hash(String pw, byte[] salt, int iterations) {
        try {
            PBEKeySpec spec = new PBEKeySpec(pw.toCharArray(), salt, iterations, 256);
            byte[] h = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
            spec.clearPassword();
            return h;
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("PBKDF2 unavailable", e);
        }
    }

    private static void putHash(Map<String, Object> a, String prefix, String secret) {
        byte[] salt = new byte[16];
        RNG.nextBytes(salt);
        a.put(prefix + "Salt", Base64.getEncoder().encodeToString(salt));
        a.put(prefix + "Iter", (long) ITERATIONS);
        a.put(prefix + "Hash", Base64.getEncoder().encodeToString(hash(secret, salt, ITERATIONS)));
    }

    private static boolean verify(Map<String, Object> a, String prefix, String secret) {
        try {
            byte[] salt = Base64.getDecoder().decode(Json.str(a, prefix + "Salt", ""));
            byte[] want = Base64.getDecoder().decode(Json.str(a, prefix + "Hash", ""));
            int it = (int) Json.lng(a, prefix + "Iter", ITERATIONS);
            return java.security.MessageDigest.isEqual(want, hash(secret, salt, it));
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    private static String token() {
        byte[] b = new byte[32];
        RNG.nextBytes(b);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(b);
    }

    private static String newRecoveryCode() {
        String alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // no look-alike characters
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 16; i++) {
            if (i > 0 && i % 4 == 0) sb.append('-');
            sb.append(alphabet.charAt(RNG.nextInt(alphabet.length())));
        }
        return sb.toString();
    }

    private static String normalizeCode(String c) { return c.replace("-", "").replace(" ", "").toUpperCase(Locale.ROOT); }

    private void load() {
        if (!file.exists()) return;
        try {
            Map<String, Object> root = Json.parseObject(new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8));
            Map<String, Object> accs = Json.obj(root.get("accounts"));
            if (accs != null)
                for (Map.Entry<String, Object> e : accs.entrySet()) {
                    Map<String, Object> m = Json.obj(e.getValue());
                    if (m != null) accounts.put(e.getKey(), m);
                }
        } catch (IOException | Json.JsonException e) {
            // unreadable file: start empty rather than crash; never log secrets
        }
    }

    private boolean persist() {
        try {
            Map<String, Object> root = new LinkedHashMap<>();
            root.put("v", 1L);
            root.put("accounts", new LinkedHashMap<String, Object>(accounts));
            File tmp = new File(file.getPath() + ".tmp");
            Files.write(tmp.toPath(), Json.write(root).getBytes(StandardCharsets.UTF_8));
            Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING);
            return true;
        } catch (IOException e) {
            return false;
        }
    }
}
