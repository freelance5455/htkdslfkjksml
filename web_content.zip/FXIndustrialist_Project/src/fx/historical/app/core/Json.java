package fx.historical.app.core;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Minimal strict JSON parser/writer (no external dependencies, identical on Android and a plain JVM).
 * Parsed types: Map (LinkedHashMap), List (ArrayList), String, Double, Boolean, null.
 * Limits (depth, length) protect against hostile input such as mod manifests.
 */
public final class Json {
    public static final int MAX_DEPTH = 24;
    public static final int MAX_CHARS = 2_000_000;

    public static final class JsonException extends Exception {
        public JsonException(String m) { super(m); }
    }

    private final String s;
    private int i;

    private Json(String s) { this.s = s; }

    public static Object parse(String text) throws JsonException {
        if (text == null) throw new JsonException("null input");
        if (text.length() > MAX_CHARS) throw new JsonException("input too large");
        Json p = new Json(text);
        p.ws();
        Object v = p.value(0);
        p.ws();
        if (p.i != p.s.length()) throw new JsonException("trailing data at " + p.i);
        return v;
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Object> parseObject(String text) throws JsonException {
        Object o = parse(text);
        if (!(o instanceof Map)) throw new JsonException("expected JSON object");
        return (Map<String, Object>) o;
    }

    private void ws() {
        while (i < s.length()) {
            char c = s.charAt(i);
            if (c == ' ' || c == '\n' || c == '\r' || c == '\t') i++; else break;
        }
    }

    private Object value(int depth) throws JsonException {
        if (depth > MAX_DEPTH) throw new JsonException("nesting too deep");
        if (i >= s.length()) throw new JsonException("unexpected end");
        char c = s.charAt(i);
        switch (c) {
            case '{': return object(depth);
            case '[': return array(depth);
            case '"': return string();
            case 't': lit("true"); return Boolean.TRUE;
            case 'f': lit("false"); return Boolean.FALSE;
            case 'n': lit("null"); return null;
            default: return number();
        }
    }

    private void lit(String w) throws JsonException {
        if (!s.startsWith(w, i)) throw new JsonException("bad literal at " + i);
        i += w.length();
    }

    private Map<String, Object> object(int depth) throws JsonException {
        Map<String, Object> m = new LinkedHashMap<>();
        i++; ws();
        if (peek() == '}') { i++; return m; }
        while (true) {
            ws();
            if (peek() != '"') throw new JsonException("expected key at " + i);
            String k = string();
            ws();
            if (peek() != ':') throw new JsonException("expected ':' at " + i);
            i++; ws();
            if (m.containsKey(k)) throw new JsonException("duplicate key " + k);
            m.put(k, value(depth + 1));
            ws();
            char c = peek();
            i++;
            if (c == ',') continue;
            if (c == '}') return m;
            throw new JsonException("expected ',' or '}' at " + (i - 1));
        }
    }

    private List<Object> array(int depth) throws JsonException {
        List<Object> l = new ArrayList<>();
        i++; ws();
        if (peek() == ']') { i++; return l; }
        while (true) {
            ws();
            l.add(value(depth + 1));
            ws();
            char c = peek();
            i++;
            if (c == ',') continue;
            if (c == ']') return l;
            throw new JsonException("expected ',' or ']' at " + (i - 1));
        }
    }

    private char peek() throws JsonException {
        if (i >= s.length()) throw new JsonException("unexpected end");
        return s.charAt(i);
    }

    private String string() throws JsonException {
        StringBuilder b = new StringBuilder();
        i++;
        while (true) {
            if (i >= s.length()) throw new JsonException("unterminated string");
            char c = s.charAt(i++);
            if (c == '"') return b.toString();
            if (c < 0x20) throw new JsonException("control char in string");
            if (c != '\\') { b.append(c); continue; }
            if (i >= s.length()) throw new JsonException("bad escape");
            char e = s.charAt(i++);
            switch (e) {
                case '"': b.append('"'); break;
                case '\\': b.append('\\'); break;
                case '/': b.append('/'); break;
                case 'b': b.append('\b'); break;
                case 'f': b.append('\f'); break;
                case 'n': b.append('\n'); break;
                case 'r': b.append('\r'); break;
                case 't': b.append('\t'); break;
                case 'u':
                    if (i + 4 > s.length()) throw new JsonException("bad unicode escape");
                    try { b.append((char) Integer.parseInt(s.substring(i, i + 4), 16)); }
                    catch (NumberFormatException ex) { throw new JsonException("bad unicode escape"); }
                    i += 4; break;
                default: throw new JsonException("bad escape \\" + e);
            }
        }
    }

    private Double number() throws JsonException {
        int st = i;
        if (i < s.length() && s.charAt(i) == '-') i++;
        while (i < s.length() && "0123456789.eE+-".indexOf(s.charAt(i)) >= 0) i++;
        if (st == i) throw new JsonException("unexpected character at " + st);
        try {
            double d = Double.parseDouble(s.substring(st, i));
            if (Double.isNaN(d) || Double.isInfinite(d)) throw new JsonException("bad number");
            return d;
        } catch (NumberFormatException ex) {
            throw new JsonException("bad number at " + st);
        }
    }

    // ---------------------------------------------------------------- writer

    public static String write(Object v) {
        StringBuilder b = new StringBuilder();
        write(b, v);
        return b.toString();
    }

    @SuppressWarnings("unchecked")
    private static void write(StringBuilder b, Object v) {
        if (v == null) { b.append("null"); return; }
        if (v instanceof String) { quote(b, (String) v); return; }
        if (v instanceof Boolean) { b.append(v); return; }
        if (v instanceof Number) {
            double d = ((Number) v).doubleValue();
            if (d == Math.rint(d) && Math.abs(d) < 9e15) b.append((long) d); else b.append(d);
            return;
        }
        if (v instanceof Map) {
            b.append('{');
            boolean first = true;
            for (Map.Entry<String, Object> e : ((Map<String, Object>) v).entrySet()) {
                if (!first) b.append(',');
                first = false;
                quote(b, e.getKey());
                b.append(':');
                write(b, e.getValue());
            }
            b.append('}');
            return;
        }
        if (v instanceof List) {
            b.append('[');
            boolean first = true;
            for (Object o : (List<Object>) v) {
                if (!first) b.append(',');
                first = false;
                write(b, o);
            }
            b.append(']');
            return;
        }
        throw new IllegalArgumentException("unsupported type " + v.getClass());
    }

    private static void quote(StringBuilder b, String s) {
        b.append('"');
        for (int k = 0; k < s.length(); k++) {
            char c = s.charAt(k);
            switch (c) {
                case '"': b.append("\\\""); break;
                case '\\': b.append("\\\\"); break;
                case '\n': b.append("\\n"); break;
                case '\r': b.append("\\r"); break;
                case '\t': b.append("\\t"); break;
                default:
                    if (c < 0x20) b.append(String.format("\\u%04x", (int) c)); else b.append(c);
            }
        }
        b.append('"');
    }

    // ---------------------------------------------------------------- typed accessors

    @SuppressWarnings("unchecked")
    public static Map<String, Object> obj(Object o) {
        return o instanceof Map ? (Map<String, Object>) o : null;
    }

    @SuppressWarnings("unchecked")
    public static List<Object> arr(Object o) {
        return o instanceof List ? (List<Object>) o : null;
    }

    public static String str(Map<String, Object> m, String k, String def) {
        Object o = m == null ? null : m.get(k);
        return o instanceof String ? (String) o : def;
    }

    public static long lng(Map<String, Object> m, String k, long def) {
        Object o = m == null ? null : m.get(k);
        return o instanceof Number ? ((Number) o).longValue() : def;
    }

    public static boolean bool(Map<String, Object> m, String k, boolean def) {
        Object o = m == null ? null : m.get(k);
        return o instanceof Boolean ? (Boolean) o : def;
    }
}
