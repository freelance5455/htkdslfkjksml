package fx.historical.app.core;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Data-driven game definitions: items, machines, recipes, techs.
 * Everything gameplay-relevant lives in JSON so mods and signed config updates can adjust it
 * without any executable code.
 */
public final class GameData {

    public enum Kind { MINER, CONVEYOR, SPLITTER, PROCESSOR, SELLER, GENERATOR }

    public static final class ItemDef {
        public final String id, name;
        public int sellPrice;
        public ItemDef(String id, String name, int sellPrice) { this.id = id; this.name = name; this.sellPrice = sellPrice; }
    }

    public static final class MachineDef {
        public final String id, name, tech;
        public final Kind kind;
        public int cost;
        /** Positive = consumes power; negative = produces power. */
        public int power;
        public int cycleTicks;
        public MachineDef(String id, String name, Kind kind, int cost, int power, int cycleTicks, String tech) {
            this.id = id; this.name = name; this.kind = kind; this.cost = cost;
            this.power = power; this.cycleTicks = cycleTicks; this.tech = tech;
        }
    }

    public static final class Recipe {
        public final String id, machine;
        public final Map<String, Integer> inputs, outputs;
        public final int ticks;
        public Recipe(String id, String machine, Map<String, Integer> in, Map<String, Integer> out, int ticks) {
            this.id = id; this.machine = machine; this.inputs = in; this.outputs = out; this.ticks = ticks;
        }
    }

    public static final class Tech {
        public final String id, name;
        public final int cost;
        public final List<String> unlocks, requires;
        public Tech(String id, String name, int cost, List<String> unlocks, List<String> requires) {
            this.id = id; this.name = name; this.cost = cost; this.unlocks = unlocks; this.requires = requires;
        }
    }

    public final Map<String, ItemDef> items = new LinkedHashMap<>();
    public final Map<String, MachineDef> machines = new LinkedHashMap<>();
    public final Map<String, Recipe> recipes = new LinkedHashMap<>();
    public final Map<String, Tech> techs = new LinkedHashMap<>();

    // ------------------------------------------------------------------ loading

    public static GameData load(String itemsJson, String machinesJson, String recipesJson, String techsJson)
            throws Json.JsonException {
        GameData d = new GameData();
        d.addItems(Json.parseObject(itemsJson).get("items"), "");
        d.addMachines(Json.parseObject(machinesJson).get("machines"), "");
        d.addRecipes(Json.parseObject(recipesJson).get("recipes"), "");
        d.addTechs(Json.parseObject(techsJson).get("techs"));
        d.validateReferences();
        return d;
    }

    /** Adds items; when prefix is non-empty every id must start with it (mod namespace). */
    public void addItems(Object list, String prefix) throws Json.JsonException {
        List<Object> l = Json.arr(list);
        if (l == null) throw new Json.JsonException("items must be an array");
        for (Object o : l) {
            Map<String, Object> m = Json.obj(o);
            if (m == null) throw new Json.JsonException("item must be an object");
            String id = Json.str(m, "id", null);
            checkId(id, prefix);
            if (items.containsKey(id)) throw new Json.JsonException("duplicate item " + id);
            items.put(id, new ItemDef(id, Json.str(m, "name", id), (int) Json.lng(m, "sellPrice", 0)));
        }
    }

    public void addMachines(Object list, String prefix) throws Json.JsonException {
        List<Object> l = Json.arr(list);
        if (l == null) throw new Json.JsonException("machines must be an array");
        for (Object o : l) {
            Map<String, Object> m = Json.obj(o);
            if (m == null) throw new Json.JsonException("machine must be an object");
            String id = Json.str(m, "id", null);
            checkId(id, prefix);
            if (machines.containsKey(id)) throw new Json.JsonException("duplicate machine " + id);
            Kind k;
            try { k = Kind.valueOf(Json.str(m, "kind", "")); }
            catch (IllegalArgumentException e) { throw new Json.JsonException("bad machine kind for " + id); }
            machines.put(id, new MachineDef(id, Json.str(m, "name", id), k, (int) Json.lng(m, "cost", 0),
                    (int) Json.lng(m, "power", 0), (int) Json.lng(m, "cycleTicks", 1), Json.str(m, "tech", "")));
        }
    }

    public void addRecipes(Object list, String prefix) throws Json.JsonException {
        List<Object> l = Json.arr(list);
        if (l == null) throw new Json.JsonException("recipes must be an array");
        for (Object o : l) {
            Map<String, Object> m = Json.obj(o);
            if (m == null) throw new Json.JsonException("recipe must be an object");
            String id = Json.str(m, "id", null);
            checkId(id, prefix);
            if (recipes.containsKey(id)) throw new Json.JsonException("duplicate recipe " + id);
            recipes.put(id, new Recipe(id, Json.str(m, "machine", ""), counts(m.get("inputs")),
                    counts(m.get("outputs")), (int) Json.lng(m, "ticks", 1)));
        }
    }

    public void addTechs(Object list) throws Json.JsonException {
        List<Object> l = Json.arr(list);
        if (l == null) throw new Json.JsonException("techs must be an array");
        for (Object o : l) {
            Map<String, Object> m = Json.obj(o);
            if (m == null) throw new Json.JsonException("tech must be an object");
            String id = Json.str(m, "id", null);
            checkId(id, "");
            techs.put(id, new Tech(id, Json.str(m, "name", id), (int) Json.lng(m, "cost", 0),
                    strings(m.get("unlocks")), strings(m.get("requires"))));
        }
    }

    private static void checkId(String id, String prefix) throws Json.JsonException {
        if (id == null || !id.matches("[a-z0-9_]+(:[a-z0-9_]+)?")) throw new Json.JsonException("bad id: " + id);
        if (!prefix.isEmpty() && !id.startsWith(prefix)) throw new Json.JsonException("id " + id + " outside namespace " + prefix);
    }

    private static Map<String, Integer> counts(Object o) throws Json.JsonException {
        Map<String, Object> m = Json.obj(o);
        if (m == null || m.isEmpty()) throw new Json.JsonException("recipe needs inputs/outputs");
        Map<String, Integer> r = new LinkedHashMap<>();
        for (Map.Entry<String, Object> e : m.entrySet()) {
            if (!(e.getValue() instanceof Number)) throw new Json.JsonException("bad count for " + e.getKey());
            r.put(e.getKey(), ((Number) e.getValue()).intValue());
        }
        return r;
    }

    private static List<String> strings(Object o) {
        List<String> r = new ArrayList<>();
        List<Object> l = Json.arr(o);
        if (l != null) for (Object x : l) if (x instanceof String) r.add((String) x);
        return r;
    }

    /** Throws if any recipe/tech refers to something that does not exist or has impossible numbers. */
    public void validateReferences() throws Json.JsonException {
        for (Recipe r : recipes.values()) {
            MachineDef m = machines.get(r.machine);
            if (m == null || m.kind != Kind.PROCESSOR) throw new Json.JsonException("recipe " + r.id + ": bad machine " + r.machine);
            if (r.ticks < 1) throw new Json.JsonException("recipe " + r.id + ": ticks must be >= 1");
            for (Map<String, Integer> side : java.util.Arrays.asList(r.inputs, r.outputs))
                for (Map.Entry<String, Integer> e : side.entrySet()) {
                    if (!items.containsKey(e.getKey())) throw new Json.JsonException("recipe " + r.id + ": unknown item " + e.getKey());
                    if (e.getValue() < 1 || e.getValue() > 64) throw new Json.JsonException("recipe " + r.id + ": bad count");
                }
        }
        for (Tech t : techs.values()) {
            for (String u : t.unlocks) if (!machines.containsKey(u)) throw new Json.JsonException("tech " + t.id + ": unknown machine " + u);
            for (String q : t.requires) if (!techs.containsKey(q)) throw new Json.JsonException("tech " + t.id + ": unknown requirement " + q);
        }
        for (MachineDef m : machines.values())
            if (!m.tech.isEmpty() && !techs.containsKey(m.tech)) throw new Json.JsonException("machine " + m.id + ": unknown tech " + m.tech);
    }

    public List<Recipe> recipesFor(String machineId) {
        List<Recipe> r = new ArrayList<>();
        for (Recipe x : recipes.values()) if (x.machine.equals(machineId)) r.add(x);
        return r;
    }

    /** Deep copy so mods / config overrides never mutate the pristine base data. */
    public GameData copy() {
        GameData c = new GameData();
        for (ItemDef i : items.values()) c.items.put(i.id, new ItemDef(i.id, i.name, i.sellPrice));
        for (MachineDef m : machines.values())
            c.machines.put(m.id, new MachineDef(m.id, m.name, m.kind, m.cost, m.power, m.cycleTicks, m.tech));
        c.recipes.putAll(recipes);
        c.techs.putAll(techs);
        return c;
    }
}
