package fx.historical.app.ui;

import android.app.AlertDialog;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import fx.historical.app.core.GameData;
import fx.historical.app.sim.Factory;
import fx.historical.app.sim.Tutorial;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** The playable factory screen: HUD, canvas, build toolbar, research and statistics dialogs, autosave. */
final class GameScreen extends Screen implements GameView.Listener {
    private static final String[] ARROWS = {"\u2192", "\u2193", "\u2190", "\u2191"};
    private static final long AUTOSAVE_MS = 30_000;

    private final Nav nav;
    private final Services sv;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Factory factory;
    private GameView view;
    private TextView hud, hint, banner, inspect;
    private Button rotBtn;
    private final List<Button> toolButtons = new ArrayList<>();
    private final List<String> toolIds = new ArrayList<>();
    private int rot;
    private boolean alive;

    GameScreen(Nav nav) { this.nav = nav; this.sv = nav.services(); }

    @Override public View create() {
        android.content.Context c = nav.activity();
        factory = sv.factory();
        LinearLayout root = UI.column(c);
        root.setBackgroundColor(UI.BG);

        LinearLayout top = UI.row(c);
        top.setPadding(UI.dp(c, 8), UI.dp(c, 4), UI.dp(c, 8), UI.dp(c, 4));
        Button menu = UI.button(c, "Menu", false);
        menu.setOnClickListener(v -> exitToHub());
        top.addView(menu);
        hud = UI.mono(c, "", 13, UI.TEXT);
        hud.setPadding(UI.dp(c, 10), 0, 0, 0);
        top.addView(hud, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(top);

        banner = UI.label(c, "", 13, UI.WARN);
        banner.setPadding(UI.dp(c, 12), 0, UI.dp(c, 12), 0);
        root.addView(banner);
        hint = UI.label(c, "", 13, UI.ACCENT);
        hint.setPadding(UI.dp(c, 12), UI.dp(c, 2), UI.dp(c, 12), UI.dp(c, 4));
        hint.setContentDescription("Tutorial hint");
        hint.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        root.addView(hint);

        view = new GameView(c, sv, this);
        view.bind(factory);
        root.addView(view, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        inspect = UI.mono(c, "Tap with Inspect to see machine details.", 12, UI.dim());
        inspect.setPadding(UI.dp(c, 12), UI.dp(c, 4), UI.dp(c, 12), UI.dp(c, 4));
        root.addView(inspect);

        root.addView(buildToolbar(c));
        select(GameView.TOOL_PAN);
        if (!sv.loadWarning.isEmpty()) onMessage(sv.loadWarning, true);
        return root;
    }

    private View buildToolbar(android.content.Context c) {
        HorizontalScrollView sc = new HorizontalScrollView(c);
        sc.setHorizontalScrollBarEnabled(false);
        sc.setBackgroundColor(UI.PANEL);
        LinearLayout row = UI.row(c);
        row.setPadding(UI.dp(c, 6), UI.dp(c, 6), UI.dp(c, 6), UI.dp(c, 6));
        sc.addView(row);

        addTool(c, row, "Pan", GameView.TOOL_PAN);
        rotBtn = UI.button(c, "Facing " + ARROWS[0], false);
        rotBtn.setOnClickListener(v -> {
            rot = (rot + 1) & 3;
            view.setPlaceRotation(rot);
            rotBtn.setText("Facing " + ARROWS[rot]);
            rotBtn.setContentDescription("Placement direction " + new String[]{"east", "south", "west", "north"}[rot]);
        });
        row.addView(rotBtn, UI.lp(c, LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT, 0));
        GameData d = sv.effective;
        for (GameData.MachineDef m : d.machines.values()) {
            boolean locked = !factory.isUnlocked(m);
            addTool(c, row, m.name + " $" + m.cost + (locked ? " (locked)" : ""), m.id);
        }
        addTool(c, row, "Rotate", GameView.TOOL_ROTATE);
        addTool(c, row, "Remove", GameView.TOOL_REMOVE);
        addTool(c, row, "Inspect", GameView.TOOL_INSPECT);
        Button research = UI.button(c, "Research", false);
        research.setOnClickListener(v -> showResearch());
        row.addView(research, UI.lp(c, LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT, 0));
        Button stats = UI.button(c, "Stats", false);
        stats.setOnClickListener(v -> showStats());
        row.addView(stats, UI.lp(c, LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT, 0));
        return sc;
    }

    private void addTool(android.content.Context c, LinearLayout row, String label, String id) {
        Button b = UI.button(c, label, false);
        b.setOnClickListener(v -> select(id));
        LinearLayout.LayoutParams p = UI.lp(c, LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT, 0);
        p.rightMargin = UI.dp(c, 6);
        row.addView(b, p);
        toolButtons.add(b);
        toolIds.add(id);
    }

    private void select(String id) {
        view.setTool(id);
        for (int i = 0; i < toolButtons.size(); i++) {
            boolean on = toolIds.get(i).equals(id);
            Button b = toolButtons.get(i);
            b.setBackground(UI.box(nav.activity(), on ? 0xFF0B4A55 : UI.PANEL2, on ? UI.ACCENT : 0xFF3A424D, 10));
            b.setSelected(on);
        }
    }

    // ------------------------------------------------------------------ HUD, autosave

    private final Runnable hudTick = new Runnable() {
        @Override public void run() {
            if (!alive) return;
            refreshHud();
            handler.postDelayed(this, 500);
        }
    };

    private final Runnable autosave = new Runnable() {
        @Override public void run() {
            if (!alive) return;
            saveNow();
            handler.postDelayed(this, AUTOSAVE_MS);
        }
    };

    private void saveNow() {
        String err = sv.saveNow();
        if (err != null) onMessage(err + " - your last good save is still intact.", true);
    }

    private void refreshHud() {
        boolean maint = sv.maintenance();
        view.setPaused(maint);
        String power = factory.powerDemand == 0 ? factory.powerSupply + "/0" : factory.powerSupply + "/" + factory.powerDemand;
        hud.setText("$" + factory.money + "  |  Power " + power + (factory.satisfactionPct < 100 ? " (" + factory.satisfactionPct + "%)" : "")
                + "  |  $" + factory.earnedPerMinute() + "/min");
        String t = Tutorial.current(factory);
        hint.setText(t == null ? "" : t);
        hint.setVisibility(t == null ? View.GONE : View.VISIBLE);
        String b = maint ? "MAINTENANCE MODE - simulation paused" : sv.announcement;
        banner.setText(b);
        banner.setVisibility(b.isEmpty() ? View.GONE : View.VISIBLE);
    }

    @Override public void onMessage(String text, boolean error) {
        if (inspect == null) return;
        inspect.setTextColor(error ? UI.WARN : UI.GOOD);
        inspect.setText(text);
        inspect.announceForAccessibility(text);
    }

    @Override public void onInspect(String text) {
        inspect.setTextColor(UI.TEXT);
        inspect.setText(text);
    }

    // ------------------------------------------------------------------ dialogs

    private void showResearch() {
        android.content.Context c = nav.activity();
        LinearLayout col = UI.column(c);
        col.setPadding(UI.dp(c, 16), UI.dp(c, 8), UI.dp(c, 16), UI.dp(c, 8));
        final AlertDialog[] dlg = new AlertDialog[1];
        for (GameData.Tech t : sv.effective.techs.values()) {
            boolean done = factory.techs.contains(t.id);
            StringBuilder what = new StringBuilder("Unlocks:");
            for (String u : t.unlocks) what.append(' ').append(sv.effective.machines.get(u).name);
            TextView info = UI.label(c, t.name + "  ($" + t.cost + ")\n" + what + (t.requires.isEmpty() ? "" : "\nNeeds: " + t.requires), 14, UI.TEXT);
            col.addView(info, UI.fillWidth(c, 10));
            Button b = UI.button(c, done ? "Researched" : "Research", !done);
            b.setEnabled(!done);
            final String id = t.id;
            b.setOnClickListener(v -> {
                Factory.Result r = factory.research(id);
                onMessage(r.message, !r.ok);
                if (r.ok && dlg[0] != null) dlg[0].dismiss();
                if (r.ok) nav.go(new GameScreen(nav)); // rebuild toolbar so newly unlocked machines lose "(locked)"
            });
            col.addView(b, UI.fillWidth(c, 4));
        }
        ScrollView sc = new ScrollView(c);
        sc.addView(col);
        dlg[0] = new AlertDialog.Builder(c).setTitle("Research").setView(sc).setNegativeButton("Close", null).show();
    }

    private void showStats() {
        StringBuilder sb = new StringBuilder();
        sb.append("Ore mined: ").append(factory.mined).append('\n');
        sb.append("Items sold: ").append(factory.sold).append('\n');
        for (Map.Entry<String, Long> e : factory.soldByItem.entrySet())
            sb.append("  ").append(sv.effective.items.containsKey(e.getKey()) ? sv.effective.items.get(e.getKey()).name : e.getKey()).append(": ").append(e.getValue()).append('\n');
        sb.append("Total earned: $").append(factory.earned).append('\n');
        sb.append("Earning now: $").append(factory.earnedPerMinute()).append("/min\n");
        sb.append("Items in transit/buffers: ").append(factory.itemsInSystem()).append('\n');
        sb.append("Items discarded by removal: ").append(factory.discarded).append('\n');
        sb.append("Buildings: ").append(factory.buildings().size()).append('\n');
        sb.append("Power: ").append(factory.powerSupply).append(" supply / ").append(factory.powerDemand).append(" demand\n");
        sb.append("Play time: ").append(factory.tick / Factory.TICKS_PER_SECOND / 60).append(" min");
        new AlertDialog.Builder(nav.activity()).setTitle("Production statistics").setMessage(sb.toString()).setPositiveButton("Close", null).show();
    }

    // ------------------------------------------------------------------ lifecycle

    private void exitToHub() {
        saveNow();
        nav.home();
    }

    @Override public void onResume() {
        alive = true;
        view.start();
        handler.post(hudTick);
        handler.postDelayed(autosave, AUTOSAVE_MS);
    }

    @Override public void onPause() {
        alive = false;
        handler.removeCallbacksAndMessages(null);
        if (view != null) view.stop();
        saveNow(); // interrupted sessions (home button, phone call, process death) keep their progress
    }

    @Override public boolean onBack() {
        exitToHub();
        return true;
    }
}
