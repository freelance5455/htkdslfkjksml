package fx.historical.app.ui;

import android.content.Context;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;

/** Animated backdrop + scrolling centred column, shared by the menu-style screens. */
final class FrameLayoutHolder {
    final FrameLayout root;
    final LinearLayout column;

    FrameLayoutHolder(Context c, Services sv) {
        root = new FrameLayout(c);
        root.addView(new SciFiBackground(c, sv.reducedMotion()), new FrameLayout.LayoutParams(-1, -1));
        ScrollView sc = new ScrollView(c);
        sc.setFillViewport(true);
        root.addView(sc, new FrameLayout.LayoutParams(-1, -1));
        FrameLayout wrap = new FrameLayout(c);
        sc.addView(wrap, new FrameLayout.LayoutParams(-1, -2));
        column = UI.panel(c);
        int w = Math.min(UI.dp(c, 480), c.getResources().getDisplayMetrics().widthPixels - UI.dp(c, 24));
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(w, -2, Gravity.CENTER_HORIZONTAL | Gravity.TOP);
        p.topMargin = UI.dp(c, 16);
        p.bottomMargin = UI.dp(c, 16);
        wrap.addView(column, p);
    }
}
