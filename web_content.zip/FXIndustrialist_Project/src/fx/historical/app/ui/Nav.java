package fx.historical.app.ui;

import android.app.Activity;

/** Navigation and platform services handed to every screen. */
public interface Nav {
    interface FilePicked { void onBytes(byte[] data, String error); }

    void go(Screen s);
    void home();
    Services services();
    Activity activity();
    void pickFile(String[] mimeTypes, FilePicked callback);
}
