package fx.historical.app.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.view.Choreographer;
import android.view.View;

/**
 * Animated original sci-fi backdrop: drifting grid, faint scan band. Cheap (a few lines per frame),
 * capped at ~30 fps, and fully static when reduced motion is on.
 */
final class SciFiBackground extends View implements Choreographer.FrameCallback {
    private final Paint grid = new Paint();
    private final Paint band = new Paint();
    private final Paint fill = new Paint();
    private final boolean animate;
    private long startNs, lastDrawNs;
    private boolean running;

    SciFiBackground(Context c, boolean reducedMotion) {
        super(c);
        animate = !reducedMotion;
        grid.setStrokeWidth(UI.dp(c, 1));
        grid.setColor(0x2200E5FF);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (animate) { running = true; startNs = System.nanoTime(); Choreographer.getInstance().postFrameCallback(this); }
    }

    @Override protected void onDetachedFromWindow() {
        running = false;
        Choreographer.getInstance().removeFrameCallback(this);
        super.onDetachedFromWindow();
    }

    @Override public void doFrame(long frameTimeNanos) {
        if (!running) return;
        if (frameTimeNanos - lastDrawNs > 33_000_000L) { lastDrawNs = frameTimeNanos; invalidate(); }
        Choreographer.getInstance().postFrameCallback(this);
    }

    @Override protected void onDraw(Canvas canvas) {
        int w = getWidth(), h = getHeight();
        fill.setShader(new LinearGradient(0, 0, 0, h, 0xFF14181D, 0xFF08090B, Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, w, h, fill);
        float t = animate ? (System.nanoTime() - startNs) / 1e9f : 0f;
        float step = UI.dp(getContext(), 44);
        float off = (t * 10f) % step;
        for (float x = -off; x < w; x += step) canvas.drawLine(x, 0, x, h, grid);
        for (float y = -off; y < h; y += step) canvas.drawLine(0, y, w, y, grid);
        if (animate) {
            float y = ((t * 60f) % (h + 200)) - 100;
            band.setShader(new LinearGradient(0, y - 60, 0, y + 60, new int[]{0x0000E5FF, 0x2200E5FF, 0x0000E5FF}, null, Shader.TileMode.CLAMP));
            canvas.drawRect(0, y - 60, w, y + 60, band);
        }
    }
}
