package fx.historical.app.ui;

import android.app.AlertDialog;
import android.content.Context;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import fx.historical.app.auth.LocalAuth;

/** Futuristic sign-in / register / recover page. Password hashing runs off the UI thread. */
final class LoginScreen extends Screen {
    private enum Mode { SIGN_IN, REGISTER, RECOVER }

    private final Nav nav;
    private final Services sv;
    private Mode mode = Mode.SIGN_IN;
    private LinearLayout form;
    private TextView status;
    private Button submit;
    private boolean busy;

    LoginScreen(Nav nav) { this.nav = nav; this.sv = nav.services(); }

    @Override public View create() {
        Context c = nav.activity();
        FrameLayout root = new FrameLayout(c);
        root.addView(new SciFiBackground(c, sv.reducedMotion()), new FrameLayout.LayoutParams(-1, -1));

        ScrollView scroll = new ScrollView(c);
        scroll.setFillViewport(true);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-1, -1);
        root.addView(scroll, sp);

        FrameLayout center = new FrameLayout(c);
        scroll.addView(center, new FrameLayout.LayoutParams(-1, -2));

        LinearLayout card = UI.panel(c);
        int maxW = UI.dp(c, 420);
        int screenW = c.getResources().getDisplayMetrics().widthPixels;
        int w = Math.min(maxW, screenW - UI.dp(c, 32)); // phones fill the width, tablets get a centred card
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(w, -2, Gravity.CENTER_HORIZONTAL | Gravity.TOP);
        cp.topMargin = UI.dp(c, 40);
        cp.bottomMargin = UI.dp(c, 24);
        center.addView(card, cp);

        TextView title = UI.label(c, "FX INDUSTRIALIST", 26, UI.ACCENT);
        title.setLetterSpacing(0.12f);
        title.setGravity(Gravity.CENTER);
        title.setContentDescription("FX Industrialist");
        card.addView(title, UI.fillWidth(c, 0));
        TextView sub = UI.label(c, "Build. Automate. Optimise.", 13, UI.dim());
        sub.setGravity(Gravity.CENTER);
        card.addView(sub, UI.fillWidth(c, 2));

        LinearLayout tabs = UI.row(c);
        tabs.addView(tab(c, "Sign in", Mode.SIGN_IN), new LinearLayout.LayoutParams(0, -2, 1f));
        tabs.addView(tab(c, "Register", Mode.REGISTER), new LinearLayout.LayoutParams(0, -2, 1f));
        tabs.addView(tab(c, "Recover", Mode.RECOVER), new LinearLayout.LayoutParams(0, -2, 1f));
        card.addView(tabs, UI.fillWidth(c, 16));

        form = UI.column(c);
        card.addView(form, UI.fillWidth(c, 8));

        status = UI.label(c, "", 13, UI.BAD);
        status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        card.addView(status, UI.fillWidth(c, 8));

        TextView note = UI.label(c, "Accounts are stored only on this device. No data leaves your phone.", 12, UI.dim());
        card.addView(note, UI.fillWidth(c, 12));
        rebuildForm();
        return root;
    }

    private Button tab(Context c, String label, Mode m) {
        Button b = UI.button(c, label, false);
        b.setOnClickListener(v -> { if (!busy) { mode = m; status.setText(""); rebuildForm(); } });
        return b;
    }

    private void rebuildForm() {
        Context c = nav.activity();
        form.removeAllViews();
        final EditText user = UI.input(c, "Username", false);
        form.addView(user, UI.fillWidth(c, 8));
        final EditText code = mode == Mode.RECOVER ? UI.input(c, "Recovery code (XXXX-XXXX-XXXX-XXXX)", false) : null;
        if (code != null) form.addView(code, UI.fillWidth(c, 8));
        final EditText pass = UI.input(c, mode == Mode.RECOVER ? "New password" : "Password", true);
        form.addView(pass, UI.fillWidth(c, 8));
        final EditText pass2 = mode == Mode.SIGN_IN ? null : UI.input(c, "Repeat password", true);
        if (pass2 != null) form.addView(pass2, UI.fillWidth(c, 8));

        CheckBox show = new CheckBox(c);
        show.setText("Show password");
        show.setTextColor(UI.TEXT);
        show.setMinHeight(UI.dp(c, 48));
        show.setOnCheckedChangeListener((b, on) -> {
            android.text.method.TransformationMethod tm = on ? HideReturnsTransformationMethod.getInstance() : PasswordTransformationMethod.getInstance();
            pass.setTransformationMethod(tm);
            if (pass2 != null) pass2.setTransformationMethod(tm);
        });
        form.addView(show, UI.fillWidth(c, 2));

        String label = mode == Mode.SIGN_IN ? "Sign in" : mode == Mode.REGISTER ? "Create account" : "Reset password";
        submit = UI.button(c, label, true);
        submit.setOnClickListener(v -> submit(user.getText().toString().trim(), pass.getText().toString(),
                pass2 == null ? null : pass2.getText().toString(), code == null ? null : code.getText().toString()));
        form.addView(submit, UI.fillWidth(c, 8));
    }

    private void submit(String user, String pass, String pass2, String code) {
        if (busy) return;
        if (mode != Mode.SIGN_IN && !pass.equals(pass2)) { fail("Passwords do not match."); return; }
        setBusy(true);
        final Mode m = mode;
        sv.io.execute(() -> {
            LocalAuth.Result r;
            if (m == Mode.SIGN_IN) r = sv.auth.login(user, pass);
            else if (m == Mode.REGISTER) r = sv.auth.register(user, pass);
            else r = sv.auth.recover(user, code, pass);
            final LocalAuth.Result res = r;
            nav.activity().runOnUiThread(() -> done(m, res));
        });
    }

    private void done(Mode m, LocalAuth.Result r) {
        setBusy(false);
        if (!r.ok) { fail(r.message); return; }
        if (m == Mode.RECOVER) {
            showCode(r.recoveryCode, false);
            return;
        }
        if (m == Mode.REGISTER) { showCode(r.recoveryCode, true); return; }
        sv.onLogin(sv.auth.session().username);
        nav.home();
    }

    private void showCode(String code, boolean thenEnter) {
        Context c = nav.activity();
        TextView t = UI.mono(c, code, 22, UI.ACCENT);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, UI.dp(c, 16), 0, UI.dp(c, 16));
        t.setTextIsSelectable(true);
        LinearLayout box = UI.column(c);
        box.setPadding(UI.dp(c, 20), UI.dp(c, 8), UI.dp(c, 20), 0);
        box.addView(UI.label(c, "This is the ONLY way to reset your password. It is shown once and not stored in readable form. Write it down somewhere safe.", 14, UI.TEXT));
        box.addView(t);
        new AlertDialog.Builder(c).setTitle("Your recovery code").setView(box).setCancelable(false)
                .setPositiveButton("I saved it", (d, w) -> {
                    if (thenEnter && sv.auth.session() != null) { sv.onLogin(sv.auth.session().username); nav.home(); }
                    else { mode = Mode.SIGN_IN; status.setText(""); rebuildForm(); }
                }).show();
    }

    private void fail(String msg) {
        status.setTextColor(UI.BAD);
        status.setText(msg);
        UI.announce(status, msg);
    }

    private void setBusy(boolean b) {
        busy = b;
        submit.setEnabled(!b);
        submit.setText(b ? "Please wait..." : submit.getContentDescription().toString());
        if (b) status.setText("");
    }
}
