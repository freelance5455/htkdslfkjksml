package fx.historical.app.ui;

import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;

import fx.historical.app.admin.AdminConsole;
import fx.historical.app.admin.AppConfig;
import fx.historical.app.admin.AuditLog;
import fx.historical.app.admin.ConfigUpdater;
import fx.historical.app.admin.OwnerSession;
import fx.historical.app.auth.LocalAuth;
import fx.historical.app.core.GameData;
import fx.historical.app.core.Json;
import fx.historical.app.mod.ModManager;
import fx.historical.app.sim.Factory;
import fx.historical.app.sim.SaveManager;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Owns every long-lived service. One instance per process, created by MainActivity. */
public final class Services implements AdminConsole.Host {
    public final Context ctx;
    public final File files;
    public final AppConfig config;
    public final LocalAuth auth;
    public final ModManager mods;
    public volatile ConfigUpdater configUpdater;
    public final OwnerSession owner;
    public final AuditLog audit;
    public final AdminConsole console;
    public final SharedPreferences prefs;
    public final ExecutorService io = Executors.newSingleThreadExecutor();
    public final GameData base;

    public volatile GameData effective;
    public volatile List<String> modReport = new ArrayList<>();
    public volatile Map<String, String> localization = new LinkedHashMap<>();
    public volatile String announcement = "";
    public volatile String loadWarning = "";
    private volatile boolean maintenance;

    private SaveManager saves;
    private Factory factory;
    private String user = "";

    public Services(Context appContext) throws IOException, Json.JsonException {
        ctx = appContext;
        files = appContext.getFilesDir();
        prefs = appContext.getSharedPreferences("fx_prefs", Context.MODE_PRIVATE);
        applyPrefs();
        String cfg = "{}";
        try { cfg = readAsset("app_config.json"); } catch (IOException ignored) { }
        config = AppConfig.parse(cfg);
        base = GameData.load(readAsset("data/items.json"), readAsset("data/machines.json"),
                readAsset("data/recipes.json"), readAsset("data/techs.json"));
        auth = new LocalAuth(new File(files, "auth"));
        mods = new ModManager(new File(files, "mods"));
        configUpdater = new ConfigUpdater(new File(files, "config"), config.releasePublicKey);
        owner = new OwnerSession(config.ownerPublicKey, new File(files, "owner_state.json"), System::currentTimeMillis);
        audit = new AuditLog(new File(files, "audit.jsonl"), config.serverId, config.environment, System::currentTimeMillis);
        rebuildData();
        console = new AdminConsole(owner, audit, config, this, System::currentTimeMillis);
    }

    // ------------------------------------------------------------------ preferences

    public void applyPrefs() { UI.highContrast = prefs.getBoolean("high_contrast", false); }

    public boolean reducedMotion() {
        if (prefs.contains("reduced_motion")) return prefs.getBoolean("reduced_motion", false);
        try { // default follows the system "remove animations" accessibility setting
            return Settings.Global.getFloat(ctx.getContentResolver(), Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f;
        } catch (RuntimeException e) { return false; }
    }

    public boolean batterySaver() { return prefs.getBoolean("battery_saver", false); }

    /** 0.25 .. 2.0 */
    public float cameraSensitivity() { return prefs.getInt("camera_sens", 100) / 100f; }

    // ------------------------------------------------------------------ data pipeline: base -> signed config -> mods

    public GameData modBase() { return configUpdater.overlay(base); }

    public synchronized void rebuildData() {
        ModManager.Built b = mods.build(modBase());
        effective = b.data;
        modReport = b.report;
        localization = b.localization;
        if (factory != null) factory.data = effective; // hot-apply balance changes to a running game
    }

    public String importConfigBundle(String json) {
        ConfigUpdater.Result r = configUpdater.apply(json);
        audit.record(user, "config import", r.ok ? "ok: " + r.message : "fail: " + r.message);
        if (r.ok) rebuildData();
        return r.message;
    }

    // ------------------------------------------------------------------ player / game

    public synchronized void onLogin(String username) {
        user = username;
        saves = new SaveManager(new File(files, "saves"), username.toLowerCase(Locale.ROOT));
        factory = null;
        loadWarning = "";
    }

    public synchronized void onLogout() {
        if (factory != null && saves != null) saves.save(factory);
        owner.clear();
        user = "";
        saves = null;
        factory = null;
    }

    @Override public synchronized Factory factory() {
        if (factory == null) {
            SaveManager.Loaded l = saves == null ? null : saves.load(effective);
            if (l != null) {
                factory = l.factory;
                loadWarning = l.warning == null ? "" : l.warning;
                if (factory.skippedOnLoad > 0) {
                    saves.snapshot("mod-removed");
                    loadWarning = factory.skippedOnLoad + " building(s) from a missing mod were removed; a backup of your old save was kept.";
                }
            } else {
                factory = new Factory(effective, 48, 48, user.hashCode() & 0xffff);
            }
        }
        return factory;
    }

    /** @return null on success, else a short message. */
    public synchronized String saveNow() {
        if (saves == null || factory == null) return null;
        return saves.save(factory);
    }

    public synchronized void deleteSave() {
        if (saves != null) saves.deleteAll();
        factory = null;
    }

    public synchronized long saveBytes() { return saves == null ? 0 : saves.sizeBytes(); }

    public synchronized boolean hasSave() { return saves != null && saves.exists(); }

    public long dirBytes(File f) {
        long t = 0;
        File[] kids = f.listFiles();
        if (kids == null) return f.length();
        for (File k : kids) t += k.isDirectory() ? dirBytes(k) : k.length();
        return t;
    }

    public boolean reportContent(String kind, String id, String reason) {
        try {
            Map<String, Object> e = new LinkedHashMap<>();
            e.put("ts", System.currentTimeMillis());
            e.put("reporter", user);
            e.put("kind", kind);
            e.put("id", id);
            e.put("reason", reason.length() > 200 ? reason.substring(0, 200) : reason);
            Files.write(new File(files, "reports.jsonl").toPath(), (Json.write(e) + "\n").getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
            return true;
        } catch (IOException e) { return false; }
    }

    public String readAsset(String path) throws IOException {
        try (InputStream in = ctx.getAssets().open(path)) {
            byte[] b = readLimited(in, 4_000_000);
            if (b == null) throw new IOException("asset too large");
            return new String(b, StandardCharsets.UTF_8);
        }
    }

    public byte[] readAssetBytes(String path) throws IOException {
        try (InputStream in = ctx.getAssets().open(path)) { return readLimited(in, 4_000_000); }
    }

    /** Reads up to limit bytes; returns null if the stream is longer than the limit. */
    public static byte[] readLimited(InputStream in, int limit) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) {
            bo.write(buf, 0, n);
            if (bo.size() > limit) return null;
        }
        return bo.toByteArray();
    }

    // ------------------------------------------------------------------ AdminConsole.Host

    @Override public GameData baseData() { return base; }

    @Override public ModManager mods() { return mods; }

    @Override public String playerName() { return user; }

    @Override public boolean maintenance() { return maintenance; }

    @Override public void setMaintenance(boolean on) { maintenance = on; }

    @Override public void announce(String text) { announcement = text; }

    @Override public String reloadConfig() {
        configUpdater = new ConfigUpdater(new File(files, "config"), config.releasePublicKey);
        rebuildData();
        return "Config v" + configUpdater.version() + " active (balance values hot-applied; code changes would need an app update).";
    }

    @Override public String rollbackConfig() {
        ConfigUpdater.Result r = configUpdater.rollback();
        rebuildData();
        return r.message;
    }

    @Override public String healthReport() {
        Runtime rt = Runtime.getRuntime();
        Factory f = factory();
        return "heapUsedMB=" + ((rt.totalMemory() - rt.freeMemory()) >> 20) + " heapMaxMB=" + (rt.maxMemory() >> 20)
                + " tick=" + f.tick + " buildings=" + f.buildings().size() + " ledgerBalance=" + f.ledgerBalance()
                + " saveKB=" + (saveBytes() >> 10) + " modsLoaded=" + modReport.size() + " configVersion=" + configUpdater.version();
    }
}
