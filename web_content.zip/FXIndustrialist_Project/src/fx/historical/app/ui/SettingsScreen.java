package fx.historical.app.ui;

import android.app.AlertDialog;
import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import fx.historical.app.admin.OwnerSession;

import java.io.File;
import java.nio.charset.StandardCharsets;

/** Settings, accessibility, storage, privacy, signed update import, account deletion. */
final class SettingsScreen extends Screen {
    private final Nav nav;
    private final Services sv;
    private TextView status;

    SettingsScreen(Nav nav) { this.nav = nav; this.sv = nav.services(); }

    @Override public View create() {
        Context c = nav.activity();
        FrameLayoutHolder h = new FrameLayoutHolder(c, sv);
        LinearLayout col = h.column;
        col.addView(UI.label(c, "Settings", 22, UI.ACCENT), UI.fillWidth(c, 0));

        col.addView(section(c, "Accessibility and performance"));
        col.addView(check(c, "Reduce motion (static backgrounds)", sv.reducedMotion(), "reduced_motion"));
        col.addView(check(c, "High contrast", UI.highContrast, "high_contrast"));
        col.addView(check(c, "Battery saver (draw at half frame rate)", sv.batterySaver(), "battery_saver"));
        final TextView sens = UI.label(c, "Camera sensitivity: " + sv.prefs.getInt("camera_sens", 100) + "%", 14, UI.TEXT);
        col.addView(sens, UI.fillWidth(c, 8));
        SeekBar bar = new SeekBar(c);
        bar.setMax(175);
        bar.setProgress(sv.prefs.getInt("camera_sens", 100) - 25);
        bar.setContentDescription("Camera sensitivity");
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                sv.prefs.edit().putInt("camera_sens", p + 25).apply();
                sens.setText("Camera sensitivity: " + (p + 25) + "%");
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        col.addView(bar, UI.lp(c, -1, 48, 0));
        col.addView(UI.label(c, "Motion and contrast changes apply the next time a screen opens.", 12, UI.dim()), UI.fillWidth(c, 2));

        col.addView(section(c, "Storage"));
        col.addView(UI.label(c, "Factory save: " + (sv.saveBytes() / 1024) + " KB\nMods: " + (sv.dirBytes(new File(sv.files, "mods")) / 1024)
                + " KB\nAll app data: " + (sv.dirBytes(sv.files) / 1024) + " KB", 13, UI.TEXT), UI.fillWidth(c, 4));

        col.addView(section(c, "Signed updates"));
        col.addView(UI.label(c, "Balance updates are signed bundles. Installed: config v" + sv.configUpdater.version()
                + (sv.config.releasePublicKey.isEmpty() ? " (updates disabled: no release key in this build)" : ""), 13, UI.TEXT), UI.fillWidth(c, 4));
        Button imp = UI.button(c, "Import update bundle (.json)", false);
        imp.setOnClickListener(v -> nav.pickFile(new String[]{"application/json", "text/plain", "application/octet-stream"}, (data, err) -> {
            if (err != null) { say(err, true); return; }
            String msg = sv.importConfigBundle(new String(data, StandardCharsets.UTF_8));
            say(msg, false);
        }));
        col.addView(imp, UI.fillWidth(c, 6));

        col.addView(section(c, "Privacy"));
        col.addView(UI.label(c, "This build is fully offline: it requests no network permission, has no analytics, and keeps your account, saves and "
                + "mods only on this device. Passwords are stored only as salted hashes. Reports you file are saved locally.", 13, UI.TEXT), UI.fillWidth(c, 4));

        if (OwnerSession.OWNER_USERNAME.equals(sv.playerName()) && sv.owner.isDisabled()) {
            Button re = UI.button(c, "Re-enable owner tools (needs password)", false);
            re.setOnClickListener(v -> askPassword("Re-enable owner tools", pw -> {
                if (sv.auth.login(sv.playerName(), pw).ok) { sv.owner.reenable(); say("Owner tools re-enabled. Authorize with a fresh token.", false); }
                else say("Wrong password.", true);
            }));
            col.addView(re, UI.fillWidth(c, 10));
        }

        Button del = UI.button(c, "Delete my account and local data", false);
        del.setTextColor(UI.BAD);
        del.setOnClickListener(v -> askPassword("Delete account permanently", pw -> {
            String user = sv.playerName();
            if (sv.auth.deleteCurrentAccount(pw)) { sv.deleteSave(); sv.onLogout(); say("Account deleted.", false); nav.home(); }
            else say("Wrong password; nothing was deleted.", true);
        }));
        col.addView(del, UI.fillWidth(c, 16));

        status = UI.label(c, "", 13, UI.GOOD);
        status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        col.addView(status, UI.fillWidth(c, 8));
        Button back = UI.button(c, "Back", true);
        back.setOnClickListener(v -> nav.home());
        col.addView(back, UI.fillWidth(c, 8));
        return h.root;
    }

    private interface PwAction { void run(String pw); }

    private void askPassword(String title, PwAction a) {
        final EditText e = UI.input(nav.activity(), "Account password", true);
        LinearLayout box = UI.column(nav.activity());
        box.setPadding(UI.dp(nav.activity(), 20), UI.dp(nav.activity(), 8), UI.dp(nav.activity(), 20), 0);
        box.addView(e);
        new AlertDialog.Builder(nav.activity()).setTitle(title).setView(box)
                .setPositiveButton("Confirm", (d, w) -> {
                    final String pw = e.getText().toString();
                    sv.io.execute(() -> nav.activity().runOnUiThread(() -> a.run(pw)));
                }).setNegativeButton("Cancel", null).show();
    }

    private TextView section(Context c, String t) {
        TextView v = UI.label(c, t.toUpperCase(), 12, UI.ACCENT);
        v.setLetterSpacing(0.1f);
        v.setPadding(0, UI.dp(c, 18), 0, 0);
        return v;
    }

    private CheckBox check(Context c, String label, boolean on, final String key) {
        CheckBox b = new CheckBox(c);
        b.setText(label);
        b.setTextColor(UI.TEXT);
        b.setChecked(on);
        b.setMinHeight(UI.dp(c, 48));
        b.setOnCheckedChangeListener((x, v) -> { sv.prefs.edit().putBoolean(key, v).apply(); sv.applyPrefs(); });
        return b;
    }

    private void say(String m, boolean error) {
        if (status == null) return;
        status.setTextColor(error ? UI.BAD : UI.GOOD);
        status.setText(m);
    }

    @Override public boolean onBack() { nav.home(); return true; }
}
