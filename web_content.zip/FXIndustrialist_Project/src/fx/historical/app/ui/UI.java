package fx.historical.app.ui;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Small widget factory for the original graphite + neon design language. All sizes respect large touch targets. */
final class UI {
    static boolean highContrast;

    static final int BG = 0xFF0E1013, PANEL = 0xFF171A1F, PANEL2 = 0xFF21262D, TEXT = 0xFFE6EAF0;
    static final int ACCENT = 0xFF00E5FF, GOOD = 0xFF7CFF6B, WARN = 0xFFFFC857, BAD = 0xFFFF5C6C;

    private UI() {}

    static int dim() { return highContrast ? 0xFFFFFFFF : 0xFF8E98A6; }

    static int dp(Context c, float v) { return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f); }

    static GradientDrawable box(Context c, int fill, int stroke, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(c, radiusDp));
        if (stroke != 0) d.setStroke(dp(c, highContrast ? 2 : 1), stroke);
        return d;
    }

    static TextView label(Context c, String text, float sp, int color) {
        TextView t = new TextView(c);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    static TextView mono(Context c, String text, float sp, int color) {
        TextView t = label(c, text, sp, color);
        t.setTypeface(Typeface.MONOSPACE);
        return t;
    }

    static Button button(Context c, String text, boolean primary) {
        Button b = new Button(c);
        b.setText(text);
        b.setTransformationMethod(null); // keep the label exactly as written (setAllCaps needs API 28)
        b.setTextSize(15);
        b.setTextColor(primary ? 0xFF001418 : TEXT);
        b.setMinHeight(dp(c, 48));
        b.setMinimumHeight(dp(c, 48));
        b.setMinWidth(dp(c, 48));
        b.setMinimumWidth(dp(c, 48));
        b.setPadding(dp(c, 14), 0, dp(c, 14), 0);
        GradientDrawable bg = box(c, primary ? ACCENT : PANEL2, primary ? ACCENT : 0xFF3A424D, 10);
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), bg, null));
        b.setStateListAnimator(null);
        b.setContentDescription(text);
        return b;
    }

    static EditText input(Context c, String hint, boolean password) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setContentDescription(hint);
        e.setSingleLine(true);
        e.setTextColor(TEXT);
        e.setHintTextColor(0xFF6B7480);
        e.setTextSize(16);
        e.setMinHeight(dp(c, 48));
        e.setPadding(dp(c, 12), dp(c, 8), dp(c, 12), dp(c, 8));
        e.setBackground(box(c, 0xFF0B0D10, 0xFF3A424D, 8));
        e.setInputType(password ? (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD)
                : (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS));
        e.setImeOptions(android.view.inputmethod.EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING);
        return e;
    }

    static LinearLayout column(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    static LinearLayout.LayoutParams lp(Context c, int widthDp, int heightDp, int topDp) {
        int w = widthDp < 0 ? widthDp : dp(c, widthDp);
        int h = heightDp < 0 ? heightDp : dp(c, heightDp);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.topMargin = dp(c, topDp);
        return p;
    }

    static LinearLayout.LayoutParams fillWidth(Context c, int topDp) {
        return lp(c, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, topDp);
    }

    static LinearLayout panel(Context c) {
        LinearLayout l = column(c);
        l.setBackground(box(c, PANEL, 0xFF2A313A, 14));
        int p = dp(c, 16);
        l.setPadding(p, p, p, p);
        return l;
    }

    static void announce(View v, String text) {
        v.announceForAccessibility(text);
    }
}
