package fx.historical.app.ui;

import android.app.AlertDialog;
import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import fx.historical.app.admin.OwnerSession;
import fx.historical.app.sim.Factory;

import java.io.IOException;

/** Home page after sign-in. Only lists features that are implemented in this build. */
final class HubScreen extends Screen {
    private final Nav nav;
    private final Services sv;

    HubScreen(Nav nav) { this.nav = nav; this.sv = nav.services(); }

    @Override public View create() {
        Context c = nav.activity();
        FrameLayoutHolder h = new FrameLayoutHolder(c, sv);
        LinearLayout col = h.column;
        String user = sv.auth.session() == null ? "" : sv.auth.session().username;

        TextView title = UI.label(c, "FX INDUSTRIALIST", 24, UI.ACCENT);
        title.setLetterSpacing(0.1f);
        col.addView(title, UI.fillWidth(c, 0));
        col.addView(UI.label(c, "Welcome, " + user, 15, UI.TEXT), UI.fillWidth(c, 4));
        col.addView(UI.label(c, "Game " + fx.historical.app.mod.ModValidator.GAME_VERSION + "  |  config v" + sv.configUpdater.version()
                + "  |  " + sv.config.environment, 12, UI.dim()), UI.fillWidth(c, 2));
        if (!sv.announcement.isEmpty()) col.addView(UI.label(c, sv.announcement, 14, UI.WARN), UI.fillWidth(c, 10));
        if (sv.maintenance()) col.addView(UI.label(c, "Maintenance mode is on: the simulation is paused.", 14, UI.WARN), UI.fillWidth(c, 6));

        String play = sv.hasSave() ? "Continue factory" : "Start new factory";
        android.widget.Button b = UI.button(c, play, true);
        b.setOnClickListener(v -> nav.go(new GameScreen(nav)));
        col.addView(b, UI.fillWidth(c, 20));

        if (sv.hasSave()) {
            android.widget.Button nw = UI.button(c, "New factory (erases save)", false);
            nw.setOnClickListener(v -> new AlertDialog.Builder(nav.activity()).setTitle("Erase your factory?")
                    .setMessage("This deletes your saved factory and its backup. This cannot be undone.")
                    .setPositiveButton("Erase", (d, w) -> { sv.deleteSave(); nav.home(); })
                    .setNegativeButton("Cancel", null).show());
            col.addView(nw, UI.fillWidth(c, 8));
        }
        android.widget.Button mods = UI.button(c, "Mods", false);
        mods.setOnClickListener(v -> nav.go(new ModsScreen(nav)));
        col.addView(mods, UI.fillWidth(c, 8));
        android.widget.Button notes = UI.button(c, "Version notes", false);
        notes.setOnClickListener(v -> showNotes());
        col.addView(notes, UI.fillWidth(c, 8));
        android.widget.Button set = UI.button(c, "Settings, privacy and storage", false);
        set.setOnClickListener(v -> nav.go(new SettingsScreen(nav)));
        col.addView(set, UI.fillWidth(c, 8));
        if (OwnerSession.OWNER_USERNAME.equals(user) && !sv.config.ownerPublicKey.isEmpty()) {
            android.widget.Button own = UI.button(c, "Owner console", false);
            own.setOnClickListener(v -> nav.go(new AdminScreen(nav)));
            col.addView(own, UI.fillWidth(c, 8));
        }
        android.widget.Button out = UI.button(c, "Sign out", false);
        out.setOnClickListener(v -> { sv.onLogout(); sv.auth.logout(); nav.home(); });
        col.addView(out, UI.fillWidth(c, 20));
        return h.root;
    }

    private void showNotes() {
        String text;
        try { text = sv.readAsset("data/release_notes.txt"); } catch (IOException e) { text = "Version notes unavailable."; }
        String n = sv.configUpdater.notes();
        if (!n.isEmpty()) text = "Config v" + sv.configUpdater.version() + ": " + n + "\n\n" + text;
        TextView t = UI.label(nav.activity(), text, 14, UI.TEXT);
        t.setPadding(UI.dp(nav.activity(), 20), UI.dp(nav.activity(), 10), UI.dp(nav.activity(), 20), 0);
        ScrollView sc = new ScrollView(nav.activity());
        sc.addView(t);
        new AlertDialog.Builder(nav.activity()).setTitle("Version notes").setView(sc).setPositiveButton("Close", null).show();
    }
}
