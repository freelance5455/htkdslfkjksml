package fx.historical.app.ui;

import android.content.Context;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import fx.historical.app.admin.AdminConsole;

/**
 * Owner console. Reachable only when the signed-in account is exactly FxplayzOfficial AND an owner key is configured;
 * commands still require a valid signed token and are re-checked by the console on every call.
 */
final class AdminScreen extends Screen {
    private final Nav nav;
    private final Services sv;
    private LinearLayout body;
    private TextView out;
    private ScrollView outScroll;

    AdminScreen(Nav nav) { this.nav = nav; this.sv = nav.services(); }

    @Override public View create() {
        Context c = nav.activity();
        FrameLayoutHolder h = new FrameLayoutHolder(c, sv);
        h.column.addView(UI.label(c, "Owner console", 22, UI.ACCENT), UI.fillWidth(c, 0));
        body = UI.column(c);
        h.column.addView(body, UI.fillWidth(c, 8));
        Button back = UI.button(c, "Back", false);
        back.setOnClickListener(v -> nav.home());
        h.column.addView(back, UI.fillWidth(c, 16));
        render();
        return h.root;
    }

    private void render() {
        Context c = nav.activity();
        body.removeAllViews();
        if (!sv.owner.isOwner()) {
            body.addView(UI.label(c, "Paste your signed owner token. It is checked against the public key in this build, expires within 24 hours "
                    + "and is never stored. Owner rights also require this account name to match exactly.", 13, UI.dim()));
            final EditText tok = UI.input(c, "Owner token", true);
            body.addView(tok, UI.fillWidth(c, 10));
            final TextView msg = UI.label(c, "", 13, UI.BAD);
            Button go = UI.button(c, "Authorize", true);
            go.setOnClickListener(v -> {
                String err = sv.owner.authorize(sv.playerName(), tok.getText().toString().trim());
                sv.audit.record(sv.playerName(), "owner authorize", err == null ? "ok" : "fail: " + err);
                tok.setText("");
                if (err == null) render(); else { msg.setText(err); UI.announce(msg, err); }
            });
            body.addView(go, UI.fillWidth(c, 8));
            body.addView(msg, UI.fillWidth(c, 6));
            return;
        }
        body.addView(UI.label(c, "Environment: " + sv.config.environment + "   Server: " + sv.config.serverId
                + "\nType help for commands. Global and destructive actions ask for a confirmation code.", 13, UI.dim()));
        out = UI.mono(c, "Authorized.\n", 12, UI.GOOD);
        out.setTextIsSelectable(true);
        outScroll = new ScrollView(c);
        outScroll.addView(out);
        body.addView(outScroll, UI.lp(c, -1, 260, 8));
        final EditText in = UI.input(c, "Command", false);
        in.setImeOptions(EditorInfo.IME_ACTION_SEND);
        in.setOnEditorActionListener((v, action, ev) -> { if (action == EditorInfo.IME_ACTION_SEND) { send(in); return true; } return false; });
        body.addView(in, UI.fillWidth(c, 8));
        Button send = UI.button(c, "Run", true);
        send.setOnClickListener(v -> send(in));
        body.addView(send, UI.fillWidth(c, 6));
        Button end = UI.button(c, "End owner session", false);
        end.setOnClickListener(v -> { sv.owner.clear(); render(); });
        body.addView(end, UI.fillWidth(c, 6));
    }

    private void send(final EditText in) {
        final String line = in.getText().toString();
        in.setText("");
        sv.io.execute(() -> {
            final AdminConsole.Result r = sv.console.execute(line);
            nav.activity().runOnUiThread(() -> {
                out.append("> " + line + "\n" + r.text + "\n");
                out.setTextColor(r.ok ? UI.GOOD : UI.WARN);
                outScroll.post(() -> outScroll.fullScroll(View.FOCUS_DOWN));
                if (!sv.owner.isOwner()) render();
            });
        });
    }

    @Override public boolean onBack() { nav.home(); return true; }
}
