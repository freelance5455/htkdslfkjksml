package fx.historical.app.ui;

import android.app.AlertDialog;
import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import fx.historical.app.mod.ModManager;

import java.io.IOException;
import java.util.List;

/** Mod manager: import, enable/disable, update (re-import newer ZIP), roll back, remove, report. Content mods only. */
final class ModsScreen extends Screen {
    private final Nav nav;
    private final Services sv;
    private LinearLayout list;
    private TextView status;

    ModsScreen(Nav nav) { this.nav = nav; this.sv = nav.services(); }

    @Override public View create() {
        Context c = nav.activity();
        FrameLayoutHolder h = new FrameLayoutHolder(c, sv);
        LinearLayout col = h.column;
        col.addView(UI.label(c, "Mods", 22, UI.ACCENT), UI.fillWidth(c, 0));
        col.addView(UI.label(c, "Mods are data-only packages (items, machines, recipes, text). They cannot run code. "
                + "Changes apply the next time you open the factory.", 13, UI.dim()), UI.fillWidth(c, 4));

        Button imp = UI.button(c, "Import mod (.zip)", true);
        imp.setOnClickListener(v -> nav.pickFile(new String[]{"application/zip", "application/x-zip-compressed", "application/octet-stream"}, (data, err) -> {
            if (err != null) { say(err, true); return; }
            ModManager.Op op = sv.mods.installZip(data, sv.modBase());
            say(op.message + (op.warnings.isEmpty() ? "" : " Warnings: " + op.warnings), !op.ok);
            refresh();
        }));
        col.addView(imp, UI.fillWidth(c, 12));
        Button sample = UI.button(c, "Install bundled sample mod", false);
        sample.setOnClickListener(v -> {
            try {
                ModManager.Op op = sv.mods.installZip(sv.readAssetBytes("sample_mods/bronze_age_pack.zip"), sv.modBase());
                say(op.message, !op.ok);
            } catch (IOException e) { say("Sample mod missing from this build.", true); }
            refresh();
        });
        col.addView(sample, UI.fillWidth(c, 8));
        status = UI.label(c, "", 13, UI.GOOD);
        status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        col.addView(status, UI.fillWidth(c, 8));
        list = UI.column(c);
        col.addView(list, UI.fillWidth(c, 8));
        Button back = UI.button(c, "Back", false);
        back.setOnClickListener(v -> nav.home());
        col.addView(back, UI.fillWidth(c, 16));
        refresh();
        return h.root;
    }

    private void say(String m, boolean error) {
        status.setTextColor(error ? UI.BAD : UI.GOOD);
        status.setText(m);
    }

    private void refresh() {
        Context c = nav.activity();
        list.removeAllViews();
        List<ModManager.Info> mods = sv.mods.list(sv.modBase());
        if (mods.isEmpty()) list.addView(UI.label(c, "No mods installed.", 14, UI.dim()));
        for (ModManager.Info i : mods) {
            LinearLayout card = UI.column(c);
            card.setBackground(UI.box(c, UI.PANEL2, 0xFF3A424D, 10));
            card.setPadding(UI.dp(c, 12), UI.dp(c, 10), UI.dp(c, 12), UI.dp(c, 10));
            card.addView(UI.label(c, i.name + "  v" + i.version, 16, UI.TEXT));
            card.addView(UI.label(c, "by " + i.author + "  |  " + (i.enabled ? "ENABLED" : "disabled")
                    + (i.compatible ? "" : "  |  NOT COMPATIBLE with this game version"), 12, i.compatible ? UI.dim() : UI.WARN));
            card.addView(UI.label(c, i.description, 13, UI.TEXT), UI.fillWidth(c, 4));
            LinearLayout row = UI.row(c);
            Button tog = UI.button(c, i.enabled ? "Disable" : "Enable", !i.enabled);
            tog.setOnClickListener(v -> {
                ModManager.Op op = i.enabled ? sv.mods.disable(i.id) : sv.mods.enable(i.id, sv.modBase());
                say(op.message + (op.warnings.isEmpty() ? "" : " " + op.warnings), !op.ok);
                sv.rebuildData();
                refresh();
            });
            row.addView(tog, new LinearLayout.LayoutParams(0, -2, 1f));
            if (i.previousVersion != null) {
                Button rb = UI.button(c, "Roll back", false);
                rb.setOnClickListener(v -> { ModManager.Op op = sv.mods.rollback(i.id, sv.modBase()); say(op.message, !op.ok); sv.rebuildData(); refresh(); });
                row.addView(rb, new LinearLayout.LayoutParams(0, -2, 1f));
            }
            card.addView(row, UI.fillWidth(c, 6));
            LinearLayout row2 = UI.row(c);
            Button rm = UI.button(c, "Remove", false);
            rm.setOnClickListener(v -> new AlertDialog.Builder(nav.activity()).setTitle("Remove " + i.name + "?")
                    .setMessage("Your save is kept, but machines and items from this mod will be removed from it on next load. A backup of the save is made.")
                    .setPositiveButton("Remove", (d, w) -> { ModManager.Op op = sv.mods.uninstall(i.id); say(op.message, !op.ok); sv.rebuildData(); refresh(); })
                    .setNegativeButton("Cancel", null).show());
            row2.addView(rm, new LinearLayout.LayoutParams(0, -2, 1f));
            Button rp = UI.button(c, "Report", false);
            rp.setOnClickListener(v -> new AlertDialog.Builder(nav.activity()).setTitle("Report " + i.name)
                    .setItems(new String[]{"Malicious or unsafe", "Offensive content", "Broken or misleading"}, (d, which) -> {
                        String why = new String[]{"unsafe", "offensive", "broken"}[which];
                        boolean ok = sv.reportContent("mod", i.id + "@" + i.version, why);
                        say(ok ? "Report saved on this device. There is no server in this build, so it is not sent anywhere yet." : "Could not save report.", !ok);
                    }).show());
            row2.addView(rp, new LinearLayout.LayoutParams(0, -2, 1f));
            card.addView(row2, UI.fillWidth(c, 4));
            list.addView(card, UI.fillWidth(c, 10));
        }
        if (!sv.modReport.isEmpty()) {
            StringBuilder sb = new StringBuilder("Load report:");
            for (String r : sv.modReport) sb.append("\n  ").append(r);
            list.addView(UI.mono(c, sb.toString(), 12, UI.dim()), UI.fillWidth(c, 12));
        }
    }

    @Override public boolean onBack() { nav.home(); return true; }
}
