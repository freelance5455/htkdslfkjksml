package fx.historical.app.ui;

import android.view.View;

/** One full-screen UI page. Pages are plain Java objects that build their own views (no XML layouts needed). */
public abstract class Screen {
    public abstract View create();
    public void onResume() { }
    public void onPause() { }
    public void onDestroy() { }
    /** @return true if the page handled the back press itself. */
    public boolean onBack() { return false; }
}
