package fx.historical.app.ui;

/** Public entry points so MainActivity (a different package) can create package-private screens. */
public final class LoginScreenFactory {
    public Screen create(Nav nav) { return new LoginScreen(nav); }
    public Screen hub(Nav nav) { return new HubScreen(nav); }
}
