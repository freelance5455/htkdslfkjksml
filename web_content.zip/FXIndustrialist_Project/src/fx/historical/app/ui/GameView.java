package fx.historical.app.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.Choreographer;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import fx.historical.app.core.GameData;
import fx.historical.app.sim.Building;
import fx.historical.app.sim.Factory;

import java.util.HashMap;
import java.util.Map;

/**
 * Renders and controls the factory. The simulation advances in fixed 100 ms steps decoupled from the frame rate
 * (so slow phones simulate the same as fast ones, just with less smooth drawing). All game rules stay in {@link Factory};
 * this view only sends actions to it and draws the result.
 */
final class GameView extends View implements Choreographer.FrameCallback {
    interface Listener {
        void onMessage(String text, boolean error);
        void onInspect(String text);
    }

    static final String TOOL_PAN = "#pan", TOOL_REMOVE = "#remove", TOOL_ROTATE = "#rotate", TOOL_INSPECT = "#inspect";

    private static final long STEP_NS = 100_000_000L;

    private final Services services;
    private final Listener listener;
    private Factory factory;

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path arrow = new Path();
    private final RectF rect = new RectF();
    private final Map<String, Integer> itemColors = new HashMap<>();
    private final ScaleGestureDetector scaler;

    private String tool = TOOL_PAN;
    private int placeRot;
    private float camX, camY, cell;
    private final float minCell, maxCell;

    private boolean running, multi, paused;
    private long lastNs, acc;
    private int frameCount;
    private float lastX, lastY, lastFocusX, lastFocusY;
    private int lastCx = -1, lastCy = -1;
    private int selX = -1, selY = -1;
    private String lastMessage = "";
    private long lastMessageNs;

    GameView(Context c, Services services, Listener listener) {
        super(c);
        this.services = services;
        this.listener = listener;
        cell = UI.dp(c, 44);
        minCell = UI.dp(c, 14);
        maxCell = UI.dp(c, 110);
        camX = UI.dp(c, 6);
        camY = UI.dp(c, 6);
        text.setTextAlign(Paint.Align.CENTER);
        text.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        setContentDescription("Factory plot. Use the toolbar below to build.");
        scaler = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScaleBegin(ScaleGestureDetector d) {
                lastFocusX = d.getFocusX(); lastFocusY = d.getFocusY(); multi = true; return true;
            }
            @Override public boolean onScale(ScaleGestureDetector d) {
                float old = cell;
                cell = Math.max(minCell, Math.min(maxCell, cell * d.getScaleFactor()));
                float k = cell / old;
                // keep the world point under the fingers fixed, then follow the finger drift (two-finger pan)
                camX = d.getFocusX() - (d.getFocusX() - camX) * k + (d.getFocusX() - lastFocusX);
                camY = d.getFocusY() - (d.getFocusY() - camY) * k + (d.getFocusY() - lastFocusY);
                lastFocusX = d.getFocusX(); lastFocusY = d.getFocusY();
                return true;
            }
        });
    }

    void bind(Factory f) { factory = f; }

    void setTool(String t) { tool = t; lastCx = lastCy = -1; }

    String tool() { return tool; }

    void setPlaceRotation(int r) { placeRot = r & 3; }

    void setPaused(boolean p) { paused = p; }

    void start() {
        if (running) return;
        running = true;
        lastNs = 0;
        Choreographer.getInstance().postFrameCallback(this);
    }

    void stop() {
        running = false;
        Choreographer.getInstance().removeFrameCallback(this);
    }

    // ------------------------------------------------------------------ loop

    @Override public void doFrame(long ns) {
        if (!running) return;
        if (lastNs != 0 && !paused && factory != null) {
            acc += ns - lastNs;
            int steps = 0;
            while (acc >= STEP_NS && steps < 5) { factory.tick(); acc -= STEP_NS; steps++; }
            if (acc >= STEP_NS) acc = 0; // fell far behind (e.g. after pause): drop the backlog instead of burning battery
        }
        lastNs = ns;
        frameCount++;
        if (!services.batterySaver() || (frameCount & 1) == 0) invalidate();
        Choreographer.getInstance().postFrameCallback(this);
    }

    // ------------------------------------------------------------------ touch

    @Override public boolean onTouchEvent(MotionEvent e) {
        scaler.onTouchEvent(e);
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) { multi = false; lastX = e.getX(); lastY = e.getY(); lastCx = lastCy = -1; }
        if (e.getPointerCount() > 1 || scaler.isInProgress()) { multi = true; return true; }
        if (a == MotionEvent.ACTION_POINTER_UP || (multi && a != MotionEvent.ACTION_UP && a != MotionEvent.ACTION_CANCEL)) {
            lastX = e.getX(); lastY = e.getY(); // avoid a jump when one finger lifts
            return true;
        }
        if (multi) { if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) multi = false; return true; }
        switch (a) {
            case MotionEvent.ACTION_DOWN:
                if (!tool.equals(TOOL_PAN)) act(e.getX(), e.getY(), true);
                return true;
            case MotionEvent.ACTION_MOVE:
                if (tool.equals(TOOL_PAN)) {
                    float s = services.cameraSensitivity();
                    camX += (e.getX() - lastX) * s;
                    camY += (e.getY() - lastY) * s;
                } else if (!tool.equals(TOOL_INSPECT) && !tool.equals(TOOL_ROTATE)) {
                    act(e.getX(), e.getY(), false); // drag-paint for placing and removing
                }
                lastX = e.getX(); lastY = e.getY();
                return true;
            default:
                return true;
        }
    }

    private void act(float sx, float sy, boolean first) {
        if (factory == null) return;
        int cx = (int) Math.floor((sx - camX) / cell), cy = (int) Math.floor((sy - camY) / cell);
        if (cx == lastCx && cy == lastCy) return;
        lastCx = cx; lastCy = cy; selX = cx; selY = cy;
        if (!factory.inBounds(cx, cy)) return;
        Factory.Result r;
        if (tool.equals(TOOL_REMOVE)) r = factory.remove(cx, cy);
        else if (tool.equals(TOOL_ROTATE)) r = factory.rotate(cx, cy);
        else if (tool.equals(TOOL_INSPECT)) {
            Building b = factory.at(cx, cy);
            int res = factory.resourceAt(cx, cy);
            String ground = res == 0 ? "empty ground" : Factory.RESOURCE[res].replace('_', ' ') + " deposit";
            listener.onInspect(b == null ? "(" + cx + "," + cy + ") " + ground : factory.describe(b));
            return;
        } else r = factory.place(tool, cx, cy, placeRot);
        // placing over many tiles while dragging should not spam errors: only report the first failure of a gesture
        if (r.ok || first) message(r.message, !r.ok);
    }

    private void message(String m, boolean error) {
        long now = System.nanoTime();
        if (m.equals(lastMessage) && now - lastMessageNs < 1_500_000_000L) return;
        lastMessage = m; lastMessageNs = now;
        listener.onMessage(m, error);
    }

    // ------------------------------------------------------------------ drawing

    @Override protected void onDraw(Canvas c) {
        c.drawColor(0xFF0B0D10);
        if (factory == null) return;
        int w = getWidth(), h = getHeight();
        int x0 = Math.max(0, (int) Math.floor(-camX / cell)), y0 = Math.max(0, (int) Math.floor(-camY / cell));
        int x1 = Math.min(factory.width - 1, (int) Math.floor((w - camX) / cell)), y1 = Math.min(factory.height - 1, (int) Math.floor((h - camY) / cell));

        // plot background
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xFF12161B);
        rect.set(camX, camY, camX + factory.width * cell, camY + factory.height * cell);
        c.drawRect(rect, paint);

        // resource deposits
        for (int y = y0; y <= y1; y++)
            for (int x = x0; x <= x1; x++) {
                int r = factory.resourceAt(x, y);
                if (r == 0) continue;
                paint.setColor(r == 1 ? 0x553F6C8F : 0x55B5642B);
                rect.set(camX + x * cell + 1, camY + y * cell + 1, camX + (x + 1) * cell - 1, camY + (y + 1) * cell - 1);
                c.drawRect(rect, paint);
            }

        // grid (skipped when zoomed far out: cheaper and less noisy)
        if (cell >= UI.dp(getContext(), 20)) {
            paint.setColor(0x22FFFFFF);
            paint.setStrokeWidth(1f);
            for (int x = x0; x <= x1 + 1; x++) c.drawLine(camX + x * cell, camY + y0 * cell, camX + x * cell, camY + (y1 + 1) * cell, paint);
            for (int y = y0; y <= y1 + 1; y++) c.drawLine(camX + x0 * cell, camY + y * cell, camX + (x1 + 1) * cell, camY + y * cell, paint);
        }

        GameData d = factory.data;
        for (Building b : factory.buildings()) {
            if (b.x < x0 || b.x > x1 || b.y < y0 || b.y > y1) continue;
            GameData.MachineDef m = d.machines.get(b.machineId);
            drawBuilding(c, b, m);
        }

        if (selX >= 0 && factory.inBounds(selX, selY)) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(UI.dp(getContext(), 2));
            paint.setColor(UI.ACCENT);
            rect.set(camX + selX * cell, camY + selY * cell, camX + (selX + 1) * cell, camY + (selY + 1) * cell);
            c.drawRect(rect, paint);
            paint.setStyle(Paint.Style.FILL);
        }
    }

    private void drawBuilding(Canvas c, Building b, GameData.MachineDef m) {
        float l = camX + b.x * cell, t = camY + b.y * cell, pad = Math.max(2f, cell * 0.08f);
        rect.set(l + pad, t + pad, l + cell - pad, t + cell - pad);
        int color = 0xFF5A6572;
        if (m != null) {
            switch (m.kind) {
                case MINER: color = 0xFF8D6E3F; break;
                case CONVEYOR: color = 0xFF3C4652; break;
                case SPLITTER: color = 0xFF4C5BA8; break;
                case PROCESSOR: color = 0xFFA1503C; break;
                case SELLER: color = 0xFF2F8F5B; break;
                case GENERATOR: color = 0xFF2E7F9A; break;
            }
        }
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(color);
        c.drawRoundRect(rect, cell * 0.12f, cell * 0.12f, paint);

        int ring = 0;
        switch (b.state) {
            case BLOCKED: ring = UI.WARN; break;
            case NO_POWER: ring = UI.BAD; break;
            case INVALID: ring = 0xFFFF00FF; break;
            default: break;
        }
        if (ring != 0) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Math.max(2f, cell * 0.07f));
            paint.setColor(ring);
            c.drawRoundRect(rect, cell * 0.12f, cell * 0.12f, paint);
            paint.setStyle(Paint.Style.FILL);
        }

        // direction arrow (not for generators/sellers, which have no output direction)
        if (m != null && m.kind != GameData.Kind.GENERATOR && m.kind != GameData.Kind.SELLER) {
            float cx = l + cell / 2, cy = t + cell / 2, r = cell * 0.26f;
            arrow.reset();
            float[][] pts = {{r, 0}, {-r * 0.7f, -r * 0.8f}, {-r * 0.7f, r * 0.8f}};
            for (int i = 0; i < 3; i++) {
                float px = pts[i][0], py = pts[i][1], rx, ry;
                switch (b.rot) { case 1: rx = -py; ry = px; break; case 2: rx = -px; ry = -py; break; case 3: rx = py; ry = -px; break; default: rx = px; ry = py; }
                if (i == 0) arrow.moveTo(cx + rx, cy + ry); else arrow.lineTo(cx + rx, cy + ry);
            }
            arrow.close();
            paint.setColor(0x99FFFFFF);
            c.drawPath(arrow, paint);
        }

        if (m != null && cell >= UI.dp(getContext(), 30) && m.kind != GameData.Kind.CONVEYOR) {
            text.setTextSize(cell * 0.28f);
            text.setColor(0xFFFFFFFF);
            c.drawText(m.name.substring(0, Math.min(3, m.name.length())).toUpperCase(), l + cell / 2, t + cell * 0.30f, text);
        }

        // carried item
        if (b.slot != null) {
            paint.setColor(colorOf(b.slot));
            c.drawCircle(l + cell / 2, t + cell / 2, cell * 0.14f, paint);
        }
        int held = Building.total(b.outBuf) + Building.total(b.inBuf);
        if (held > 0 && cell >= UI.dp(getContext(), 30)) {
            text.setTextSize(cell * 0.24f);
            text.setColor(0xFFFFE9A8);
            c.drawText(String.valueOf(held), l + cell / 2, t + cell * 0.92f, text);
        }
    }

    private int colorOf(String item) {
        Integer col = itemColors.get(item);
        if (col == null) {
            col = Color.HSVToColor(new float[]{(item.hashCode() & 0x7fffffff) % 360, 0.55f, 0.98f});
            itemColors.put(item, col);
        }
        return col;
    }
}
