package fx.historical.app.mod;

import fx.historical.app.core.GameData;
import fx.historical.app.core.Json;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Structural and content validation of a mod package (name -> bytes). This is real validation of a
 * restricted, declarative format; it is NOT antivirus. Safety comes from the format itself: only JSON data
 * is accepted, there is no code path that executes anything from a mod.
 */
public final class ModValidator {
    public static final String GAME_VERSION = "1.0.0";
    public static final int MAX_FILES = 32;
    public static final int MAX_FILE_BYTES = 512 * 1024;
    public static final int MAX_TOTAL_BYTES = 2 * 1024 * 1024;
    public static final int MAX_MANIFEST_BYTES = 64 * 1024;

    public static final List<String> PERMISSIONS = Arrays.asList(
            "content.items", "content.recipes", "content.machines", "content.localization");
    private static final Set<String> CODE_EXT = new HashSet<>(Arrays.asList(
            "dex", "jar", "so", "js", "lua", "luau", "class", "apk", "sh", "py", "exe", "dll", "bat", "wasm", "html", "kt", "java"));

    public static final class Report {
        public final List<String> errors = new ArrayList<>();
        public final List<String> warnings = new ArrayList<>();
        public ModManifest manifest;
        public boolean ok() { return errors.isEmpty() && manifest != null; }
    }

    private ModValidator() {}

    public static boolean safeName(String n) {
        return n != null && n.length() <= 64 && n.matches("[A-Za-z0-9_][A-Za-z0-9_.-]*") && !n.contains("..");
    }

    /** Full validation including a trial merge into a copy of {@code base}. */
    public static Report validate(Map<String, byte[]> files, GameData base) {
        Report r = new Report();
        long total = 0;
        if (files.size() > MAX_FILES) r.errors.add("Too many files (max " + MAX_FILES + ").");
        for (Map.Entry<String, byte[]> e : files.entrySet()) {
            String n = e.getKey();
            if (!safeName(n)) { r.errors.add("Unsafe file name: " + n); continue; }
            String ext = n.contains(".") ? n.substring(n.lastIndexOf('.') + 1).toLowerCase() : "";
            if (CODE_EXT.contains(ext)) r.errors.add("Executable or script content is not allowed: " + n);
            else if (!ext.equals("json")) r.errors.add("Only .json files are allowed: " + n);
            if (e.getValue().length > MAX_FILE_BYTES) r.errors.add("File too large: " + n);
            total += e.getValue().length;
        }
        if (total > MAX_TOTAL_BYTES) r.errors.add("Package too large.");
        byte[] mb = files.get("manifest.json");
        if (mb == null) { r.errors.add("manifest.json is missing."); return r; }
        if (mb.length > MAX_MANIFEST_BYTES) { r.errors.add("manifest.json too large."); return r; }
        if (!r.errors.isEmpty()) return r;

        Map<String, Object> m;
        try { m = Json.parseObject(new String(mb, StandardCharsets.UTF_8)); }
        catch (Json.JsonException ex) { r.errors.add("manifest.json invalid: " + ex.getMessage()); return r; }

        ModManifest mf = new ModManifest();
        mf.id = Json.str(m, "id", "");
        mf.namespace = Json.str(m, "namespace", "");
        mf.name = Json.str(m, "name", "");
        mf.version = Json.str(m, "version", "");
        mf.author = Json.str(m, "author", "");
        mf.description = Json.str(m, "description", "");
        mf.minGameVersion = Json.str(m, "minGameVersion", "");
        mf.maxGameVersion = Json.str(m, "maxGameVersion", "");
        if (!mf.id.matches("[a-z0-9]+(\\.[a-z0-9_]+){1,4}") || mf.id.length() > 64) r.errors.add("Invalid id (use reverse-DNS like com.author.mod).");
        if (!mf.namespace.matches("[a-z0-9_]{2,16}")) r.errors.add("Invalid namespace (2-16 of a-z 0-9 _).");
        if (mf.name.isEmpty() || mf.name.length() > 48) r.errors.add("Name must be 1-48 characters.");
        if (!Versions.valid(mf.version)) r.errors.add("version must look like 1.2.3.");
        if (mf.author.isEmpty() || mf.author.length() > 48) r.errors.add("Author must be 1-48 characters.");
        if (mf.description.length() > 280) r.errors.add("Description too long (max 280).");
        if (!Versions.valid(mf.minGameVersion)) r.errors.add("minGameVersion must look like 1.0.0.");
        if (!mf.maxGameVersion.isEmpty() && !Versions.valid(mf.maxGameVersion)) r.errors.add("maxGameVersion invalid.");

        Map<String, Object> deps = Json.obj(m.get("dependencies"));
        if (deps != null)
            for (Map.Entry<String, Object> e : deps.entrySet()) {
                if (!(e.getValue() instanceof String) || !Versions.valid((String) e.getValue())) { r.errors.add("Bad dependency version for " + e.getKey()); continue; }
                mf.dependencies.put(e.getKey(), (String) e.getValue());
            }
        List<Object> perms = Json.arr(m.get("permissions"));
        if (perms != null)
            for (Object p : perms) {
                if (!(p instanceof String) || !PERMISSIONS.contains(p)) r.errors.add("Unknown or forbidden permission: " + p);
                else mf.permissions.add((String) p);
            }
        Map<String, Object> ent = Json.obj(m.get("entries"));
        if (ent != null)
            for (Map.Entry<String, Object> e : ent.entrySet()) {
                String perm = "content." + e.getKey();
                if (!PERMISSIONS.contains(perm)) { r.errors.add("Unknown entry kind: " + e.getKey()); continue; }
                if (!mf.permissions.contains(perm)) r.errors.add("Entry '" + e.getKey() + "' requires permission " + perm);
                if (!(e.getValue() instanceof String) || !safeName((String) e.getValue()) || !files.containsKey(e.getValue()))
                    r.errors.add("Entry file missing or unsafe for " + e.getKey());
                else mf.entries.put(e.getKey(), (String) e.getValue());
            }
        if (mf.entries.isEmpty()) r.errors.add("Mod declares no content.");
        if (Versions.valid(mf.minGameVersion) && Versions.compare(mf.minGameVersion, GAME_VERSION) > 0)
            r.warnings.add("Needs game version " + mf.minGameVersion + " or newer.");
        if (Versions.valid(mf.maxGameVersion) && Versions.compare(mf.maxGameVersion, GAME_VERSION) < 0)
            r.warnings.add("Made for older game versions (up to " + mf.maxGameVersion + ").");
        if (!r.errors.isEmpty()) return r;

        r.manifest = mf;
        try {
            applyContent(base.copy(), mf, files);
        } catch (Json.JsonException ex) {
            r.errors.add("Content invalid: " + ex.getMessage());
            r.manifest = null;
        }
        return r;
    }

    public static boolean compatible(ModManifest mf) {
        if (Versions.compare(mf.minGameVersion, GAME_VERSION) > 0) return false;
        return mf.maxGameVersion.isEmpty() || Versions.compare(mf.maxGameVersion, GAME_VERSION) >= 0;
    }

    /** Merges the mod's content into {@code target}; throws if anything is out of bounds or collides. */
    public static void applyContent(GameData target, ModManifest mf, Map<String, byte[]> files) throws Json.JsonException {
        String prefix = mf.namespace + ":";
        String items = mf.entries.get("items"), machines = mf.entries.get("machines"), recipes = mf.entries.get("recipes");
        if (items != null) {
            Object list = Json.parseObject(text(files, items)).get("items");
            target.addItems(list, prefix);
            for (Object o : Json.arr(list)) {
                long p = Json.lng(Json.obj(o), "sellPrice", -1);
                if (p < 0 || p > 10_000) throw new Json.JsonException("sellPrice out of range (0-10000)");
            }
        }
        if (machines != null) {
            Object list = Json.parseObject(text(files, machines)).get("machines");
            target.addMachines(list, prefix);
            for (Object o : Json.arr(list)) {
                Map<String, Object> m = Json.obj(o);
                long cost = Json.lng(m, "cost", -1), power = Json.lng(m, "power", 999), cyc = Json.lng(m, "cycleTicks", 0);
                if (cost < 0 || cost > 1_000_000) throw new Json.JsonException("machine cost out of range");
                if (power < -100 || power > 100) throw new Json.JsonException("machine power out of range");
                if (cyc < 0 || cyc > 6000) throw new Json.JsonException("cycleTicks out of range");
                if (!Json.str(m, "tech", "").isEmpty() && !target.techs.containsKey(Json.str(m, "tech", "")))
                    throw new Json.JsonException("unknown tech requirement");
            }
        }
        if (recipes != null) {
            Object list = Json.parseObject(text(files, recipes)).get("recipes");
            target.addRecipes(list, prefix);
            for (Object o : Json.arr(list))
                if (Json.lng(Json.obj(o), "ticks", 0) > 6000) throw new Json.JsonException("recipe ticks out of range");
        }
        String loc = mf.entries.get("localization");
        if (loc != null) {
            Map<String, Object> l = Json.parseObject(text(files, loc));
            if (l.size() > 200) throw new Json.JsonException("too many localization strings");
            for (Map.Entry<String, Object> e : l.entrySet())
                if (!(e.getValue() instanceof String) || ((String) e.getValue()).length() > 200 || e.getKey().length() > 64)
                    throw new Json.JsonException("bad localization entry");
        }
        target.validateReferences();
    }

    private static String text(Map<String, byte[]> files, String name) throws Json.JsonException {
        byte[] b = files.get(name);
        if (b == null) throw new Json.JsonException("missing file " + name);
        return new String(b, StandardCharsets.UTF_8);
    }
}
