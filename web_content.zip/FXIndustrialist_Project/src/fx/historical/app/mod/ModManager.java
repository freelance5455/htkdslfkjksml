package fx.historical.app.mod;

import fx.historical.app.core.GameData;
import fx.historical.app.core.Json;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Installs, updates, enables, disables, uninstalls and rolls back declarative mods.
 * Mods live under {root}/installed/{id}/{version}/ and never touch the base game data or saves:
 * the effective {@link GameData} is rebuilt on a copy, and a mod that fails is disabled and skipped.
 */
public final class ModManager {
    public static final int MAX_ZIP_BYTES = 4 * 1024 * 1024;

    public static final class Op {
        public final boolean ok;
        public final String message;
        public final List<String> warnings;
        Op(boolean ok, String message, List<String> warnings) { this.ok = ok; this.message = message; this.warnings = warnings; }
        static Op fail(String m) { return new Op(false, m, new ArrayList<String>()); }
        static Op ok(String m) { return new Op(true, m, new ArrayList<String>()); }
    }

    public static final class Info {
        public String id, name, version, previousVersion, author, description;
        public boolean enabled, approved, compatible;
    }

    public static final class Built {
        public final GameData data;
        public final List<String> report = new ArrayList<>();
        public final Map<String, String> localization = new LinkedHashMap<>();
        Built(GameData d) { data = d; }
    }

    private final File root, stateFile;
    private final Map<String, Map<String, Object>> state = new LinkedHashMap<>();
    private boolean approvalRequired;

    public ModManager(File root) {
        this.root = root;
        new File(root, "installed").mkdirs();
        stateFile = new File(root, "state.json");
        loadState();
    }

    // ------------------------------------------------------------------ install

    public Op installZip(byte[] zip, GameData base) {
        if (zip == null || zip.length == 0 || zip.length > MAX_ZIP_BYTES) return Op.fail("Mod package is empty or larger than 4 MB.");
        Map<String, byte[]> files = new LinkedHashMap<>();
        try (ZipInputStream in = new ZipInputStream(new ByteArrayInputStream(zip))) {
            ZipEntry e;
            long total = 0;
            while ((e = in.getNextEntry()) != null) {
                if (e.isDirectory()) return Op.fail("Folders are not allowed inside a mod package.");
                String name = e.getName();
                if (!ModValidator.safeName(name)) return Op.fail("Unsafe file name in package: " + name);
                if (files.size() >= ModValidator.MAX_FILES) return Op.fail("Too many files in package.");
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) {
                    total += n; bo.write(buf, 0, n);
                    // limits are enforced on inflated bytes, so zip bombs are cut off early
                    if (bo.size() > ModValidator.MAX_FILE_BYTES || total > ModValidator.MAX_TOTAL_BYTES) return Op.fail("Package expands too large.");
                }
                if (files.put(name, bo.toByteArray()) != null) return Op.fail("Duplicate file in package: " + name);
            }
        } catch (IOException ex) {
            return Op.fail("Not a valid ZIP package.");
        }
        return installFiles(files, base);
    }

    public Op installFiles(Map<String, byte[]> files, GameData base) {
        ModValidator.Report rep = ModValidator.validate(files, base);
        if (!rep.ok()) return Op.fail("Rejected: " + String.join(" ", rep.errors));
        ModManifest mf = rep.manifest;
        Map<String, Object> st = state.get(mf.id);
        String current = st == null ? null : (String) st.get("version");
        if (current != null && Versions.compare(mf.version, current) <= 0)
            return Op.fail("Version " + current + " or newer is already installed.");
        File dir = new File(root, "installed/" + mf.id + "/" + mf.version);
        File staging = new File(root, "staging-" + System.nanoTime());
        try {
            if (!staging.mkdirs()) return Op.fail("Cannot create staging folder.");
            for (Map.Entry<String, byte[]> e : files.entrySet()) Files.write(new File(staging, e.getKey()).toPath(), e.getValue());
            dir.getParentFile().mkdirs();
            deleteRecursive(dir);
            Files.move(staging.toPath(), dir.toPath(), StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException ex) {
            deleteRecursive(staging);
            return Op.fail("Could not write mod files.");
        }
        Map<String, Object> ns = new LinkedHashMap<>();
        boolean wasEnabled = st != null && Boolean.TRUE.equals(st.get("enabled"));
        ns.put("version", mf.version);
        ns.put("previous", current);
        ns.put("enabled", wasEnabled);
        ns.put("approved", st != null && Boolean.TRUE.equals(st.get("approved")));
        // keep exactly one previous version for rollback, drop older ones
        if (st != null && st.get("previous") instanceof String && !st.get("previous").equals(current))
            deleteRecursive(new File(root, "installed/" + mf.id + "/" + st.get("previous")));
        state.put(mf.id, ns);
        saveState();
        Op op = new Op(true, (current == null ? "Installed " : "Updated ") + mf.name + " " + mf.version + " (disabled until you enable it).", rep.warnings);
        return op;
    }

    // ------------------------------------------------------------------ enable / disable / remove / rollback

    public Op enable(String id, GameData base) {
        Map<String, Object> st = state.get(id);
        if (st == null) return Op.fail("Mod is not installed.");
        if (approvalRequired && !Boolean.TRUE.equals(st.get("approved"))) return Op.fail("Mod is not approved by the owner.");
        Map<String, byte[]> files = readFiles(id, (String) st.get("version"));
        if (files == null) return Op.fail("Mod files are missing.");
        ModValidator.Report rep = ModValidator.validate(files, base);
        if (!rep.ok()) return Op.fail("Cannot enable: " + String.join(" ", rep.errors));
        ModManifest mf = rep.manifest;
        if (!ModValidator.compatible(mf)) return Op.fail("Not compatible with game version " + ModValidator.GAME_VERSION + ".");
        for (Map.Entry<String, String> d : mf.dependencies.entrySet()) {
            Map<String, Object> ds = state.get(d.getKey());
            if (ds == null || !Boolean.TRUE.equals(ds.get("enabled"))) return Op.fail("Requires " + d.getKey() + " to be installed and enabled.");
            if (Versions.compare((String) ds.get("version"), d.getValue()) < 0) return Op.fail("Requires " + d.getKey() + " " + d.getValue() + " or newer.");
        }
        st.put("enabled", true);
        saveState();
        Built b = build(base);
        if (!Boolean.TRUE.equals(st.get("enabled"))) return Op.fail("Mod failed to load: " + String.join(" ", b.report));
        return new Op(true, "Enabled " + mf.name + ".", rep.warnings);
    }

    public Op disable(String id) {
        Map<String, Object> st = state.get(id);
        if (st == null) return Op.fail("Mod is not installed.");
        List<String> dependents = dependentsOf(id);
        if (!dependents.isEmpty()) return Op.fail("Disable these first: " + String.join(", ", dependents));
        st.put("enabled", false);
        saveState();
        return Op.ok("Disabled.");
    }

    public Op uninstall(String id) {
        Map<String, Object> st = state.get(id);
        if (st == null) return Op.fail("Mod is not installed.");
        List<String> dependents = dependentsOf(id);
        if (!dependents.isEmpty()) return Op.fail("Remove these first: " + String.join(", ", dependents));
        state.remove(id);
        saveState();
        deleteRecursive(new File(root, "installed/" + id));
        return Op.ok("Uninstalled. Saves are untouched; items from this mod are discarded on next load.");
    }

    public Op rollback(String id, GameData base) {
        Map<String, Object> st = state.get(id);
        if (st == null) return Op.fail("Mod is not installed.");
        String prev = (String) st.get("previous");
        if (prev == null || !new File(root, "installed/" + id + "/" + prev).isDirectory()) return Op.fail("No earlier version to roll back to.");
        Map<String, byte[]> files = readFiles(id, prev);
        if (files == null || !ModValidator.validate(files, base).ok()) return Op.fail("Earlier version no longer validates.");
        String cur = (String) st.get("version");
        st.put("version", prev);
        st.put("previous", cur);
        saveState();
        return Op.ok("Rolled back to " + prev + ".");
    }

    public void setApproved(String id, boolean approved) {
        Map<String, Object> st = state.get(id);
        if (st != null) { st.put("approved", approved); saveState(); }
    }

    public void setApprovalRequired(boolean required) { approvalRequired = required; }

    private List<String> dependentsOf(String id) {
        List<String> out = new ArrayList<>();
        for (Map.Entry<String, Map<String, Object>> e : state.entrySet()) {
            if (e.getKey().equals(id) || !Boolean.TRUE.equals(e.getValue().get("enabled"))) continue;
            Map<String, byte[]> files = readFiles(e.getKey(), (String) e.getValue().get("version"));
            if (files == null) continue;
            try {
                Map<String, Object> m = Json.parseObject(new String(files.get("manifest.json"), StandardCharsets.UTF_8));
                Map<String, Object> deps = Json.obj(m.get("dependencies"));
                if (deps != null && deps.containsKey(id)) out.add(e.getKey());
            } catch (Json.JsonException | RuntimeException ignored) { }
        }
        return out;
    }

    // ------------------------------------------------------------------ listing and loading

    public List<Info> list(GameData base) {
        List<Info> out = new ArrayList<>();
        for (Map.Entry<String, Map<String, Object>> e : state.entrySet()) {
            Info i = new Info();
            i.id = e.getKey();
            i.version = (String) e.getValue().get("version");
            i.previousVersion = (String) e.getValue().get("previous");
            i.enabled = Boolean.TRUE.equals(e.getValue().get("enabled"));
            i.approved = Boolean.TRUE.equals(e.getValue().get("approved"));
            Map<String, byte[]> files = readFiles(i.id, i.version);
            ModValidator.Report r = files == null ? null : ModValidator.validate(files, base);
            if (r != null && r.manifest != null) {
                i.name = r.manifest.name; i.author = r.manifest.author; i.description = r.manifest.description;
                i.compatible = ModValidator.compatible(r.manifest);
            } else { i.name = i.id; i.author = "?"; i.description = "Damaged or invalid package"; }
            out.add(i);
        }
        return out;
    }

    /** Rebuilds effective game data from base + enabled mods (dependency order). Failing mods are disabled. */
    public Built build(GameData base) {
        GameData data = base.copy();
        Built built = new Built(data);
        Set<String> done = new LinkedHashSet<>();
        Map<String, ModManifest> manifests = new HashMap<>();
        Map<String, Map<String, byte[]>> allFiles = new HashMap<>();
        List<String> enabled = new ArrayList<>();
        for (Map.Entry<String, Map<String, Object>> e : state.entrySet())
            if (Boolean.TRUE.equals(e.getValue().get("enabled"))) enabled.add(e.getKey());
        boolean changed = false;
        for (String id : enabled) {
            Map<String, byte[]> files = readFiles(id, (String) state.get(id).get("version"));
            ModValidator.Report r = files == null ? null : ModValidator.validate(files, base);
            if (r == null || !r.ok() || !ModValidator.compatible(r.manifest)) {
                built.report.add(id + ": disabled (invalid, damaged or incompatible)");
                state.get(id).put("enabled", false); changed = true;
                continue;
            }
            manifests.put(id, r.manifest); allFiles.put(id, files);
        }
        boolean progress = true;
        while (progress) {
            progress = false;
            for (String id : new ArrayList<>(manifests.keySet())) {
                if (done.contains(id)) continue;
                ModManifest mf = manifests.get(id);
                boolean ready = true;
                for (String dep : mf.dependencies.keySet()) if (!done.contains(dep)) ready = false;
                if (!ready) continue;
                GameData trial = data.copy();
                try {
                    ModValidator.applyContent(trial, mf, allFiles.get(id));
                    data.items.clear(); data.items.putAll(trial.items);
                    data.machines.clear(); data.machines.putAll(trial.machines);
                    data.recipes.clear(); data.recipes.putAll(trial.recipes);
                    String loc = mf.entries.get("localization");
                    if (loc != null) {
                        Map<String, Object> l = Json.parseObject(new String(allFiles.get(id).get(loc), StandardCharsets.UTF_8));
                        for (Map.Entry<String, Object> e : l.entrySet()) built.localization.put(e.getKey(), (String) e.getValue());
                    }
                    done.add(id);
                    built.report.add(id + ": loaded");
                } catch (Json.JsonException ex) {
                    built.report.add(id + ": disabled (" + ex.getMessage() + ")");
                    state.get(id).put("enabled", false); changed = true;
                    manifests.remove(id);
                }
                progress = true;
            }
        }
        for (String id : manifests.keySet())
            if (!done.contains(id)) {
                built.report.add(id + ": disabled (dependency problem)");
                state.get(id).put("enabled", false); changed = true;
            }
        if (changed) saveState();
        return built;
    }

    // ------------------------------------------------------------------ storage

    private Map<String, byte[]> readFiles(String id, String version) {
        if (version == null || !ModValidator.safeName(version)) return null;
        File dir = new File(root, "installed/" + id + "/" + version);
        File[] list = dir.listFiles();
        if (list == null) return null;
        Map<String, byte[]> files = new LinkedHashMap<>();
        try {
            for (File f : list) {
                if (!f.isFile() || f.length() > ModValidator.MAX_FILE_BYTES) return null;
                files.put(f.getName(), Files.readAllBytes(f.toPath()));
            }
        } catch (IOException e) { return null; }
        return files;
    }

    private void loadState() {
        if (!stateFile.exists()) return;
        try {
            Map<String, Object> root0 = Json.parseObject(new String(Files.readAllBytes(stateFile.toPath()), StandardCharsets.UTF_8));
            Map<String, Object> mods = Json.obj(root0.get("mods"));
            if (mods != null)
                for (Map.Entry<String, Object> e : mods.entrySet())
                    if (Json.obj(e.getValue()) != null && ModValidator.safeName(e.getKey().replace('.', '_')))
                        state.put(e.getKey(), Json.obj(e.getValue()));
        } catch (IOException | Json.JsonException e) { /* start clean; installed files remain on disk */ }
    }

    private void saveState() {
        try {
            Map<String, Object> r = new LinkedHashMap<>();
            r.put("mods", new LinkedHashMap<String, Object>(state));
            File tmp = new File(stateFile.getPath() + ".tmp");
            Files.write(tmp.toPath(), Json.write(r).getBytes(StandardCharsets.UTF_8));
            Files.move(tmp.toPath(), stateFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ignored) { }
    }

    private static void deleteRecursive(File f) {
        if (f == null || !f.exists()) return;
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteRecursive(k);
        f.delete();
    }
}
