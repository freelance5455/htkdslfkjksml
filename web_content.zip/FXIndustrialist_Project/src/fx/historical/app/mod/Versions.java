package fx.historical.app.mod;

/** Strict MAJOR.MINOR.PATCH comparison. */
public final class Versions {
    private Versions() {}

    public static boolean valid(String v) { return v != null && v.matches("\\d{1,4}\\.\\d{1,4}\\.\\d{1,4}"); }

    public static int compare(String a, String b) {
        String[] x = a.split("\\."), y = b.split("\\.");
        for (int i = 0; i < 3; i++) {
            int c = Integer.compare(Integer.parseInt(x[i]), Integer.parseInt(y[i]));
            if (c != 0) return c;
        }
        return 0;
    }
}
