package fx.historical.app.mod;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Parsed and validated mod manifest. Mods are declarative data only: there is no code entry point. */
public final class ModManifest {
    public String id, namespace, name, version, author, description, minGameVersion, maxGameVersion;
    public final Map<String, String> dependencies = new LinkedHashMap<>(); // mod id -> minimum version
    public final List<String> permissions = new ArrayList<>();
    public final Map<String, String> entries = new LinkedHashMap<>();      // kind -> file name
}
