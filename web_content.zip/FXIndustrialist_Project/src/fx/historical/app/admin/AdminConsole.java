package fx.historical.app.admin;

import fx.historical.app.core.GameData;
import fx.historical.app.mod.ModManager;
import fx.historical.app.sim.Factory;

import java.security.SecureRandom;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.LongSupplier;
import java.util.regex.Pattern;

/**
 * Owner command console. Every command goes through: owner check -> rate limit -> input sanitising ->
 * allowlist lookup -> argument validation -> dev/prod gate -> confirmation (for global/destructive ones) -> audit log.
 * There is NO command that runs shell commands, reads files, touches other apps/games, or reaches credentials.
 * Commands that need a multiplayer server (kick, roles, publish, release rollback) are intentionally absent
 * because no server exists in this build; the docs describe how they plug in.
 */
public final class AdminConsole {

    /** What the console is allowed to act on. Implemented by the app. */
    public interface Host {
        Factory factory();
        GameData baseData();
        ModManager mods();
        String playerName();
        boolean maintenance();
        void setMaintenance(boolean on);
        void announce(String text);
        String reloadConfig();
        String rollbackConfig();
        String healthReport();
    }

    public static final class Result {
        public final boolean ok;
        public final String text;
        Result(boolean ok, String text) { this.ok = ok; this.text = text; }
    }

    private static final class Cmd {
        final String usage, help;
        final Pattern args;       // validated against the joined argument string
        final boolean destructive, devOnly;
        Cmd(String usage, String help, String argRegex, boolean destructive, boolean devOnly) {
            this.usage = usage; this.help = help; this.args = Pattern.compile(argRegex);
            this.destructive = destructive; this.devOnly = devOnly;
        }
    }

    private static final int MAX_LINE = 200;
    private static final int RATE_LIMIT = 12;          // commands per window
    private static final long RATE_WINDOW_MS = 60_000;
    private static final long CONFIRM_MS = 30_000;
    private static final Pattern SAFE_LINE = Pattern.compile("[\\x20-\\x7E]*");
    private static final SecureRandom RNG = new SecureRandom();

    private final Map<String, Cmd> commands = new LinkedHashMap<>();
    private final OwnerSession owner;
    private final AuditLog audit;
    private final AppConfig config;
    private final Host host;
    private final LongSupplier clock;
    private final Deque<Long> recent = new ArrayDeque<>();
    private String pendingCode, pendingLine;
    private long pendingExpiry;

    public AdminConsole(OwnerSession owner, AuditLog audit, AppConfig config, Host host, LongSupplier clock) {
        this.owner = owner; this.audit = audit; this.config = config; this.host = host; this.clock = clock;
        commands.put("help", new Cmd("help", "List commands", "", false, false));
        commands.put("status", new Cmd("status", "Show game and owner session status", "", false, false));
        commands.put("health", new Cmd("health", "Show device/simulation health", "", false, false));
        commands.put("announce", new Cmd("announce <text>", "Show an announcement banner to the player", "[A-Za-z0-9 .,!?:'()-]{1,120}", false, false));
        commands.put("maintenance", new Cmd("maintenance on|off", "Toggle maintenance mode (pauses the simulation)", "(on|off)", true, false));
        commands.put("inspect", new Cmd("inspect factory|player", "Read-only support view", "(factory|player)", false, false));
        commands.put("grant_test", new Cmd("grant_test money <1-100000> | research <techId>", "Dev environment only", "(money [0-9]{1,6}|research [a-z0-9_]{1,32})", false, true));
        commands.put("reload_config", new Cmd("reload_config", "Re-read the signed config bundle and hot-apply it", "", true, false));
        commands.put("config_rollback", new Cmd("config_rollback", "Restore the last known-good config bundle", "", true, false));
        commands.put("mods", new Cmd("mods list|approve <id>|unapprove <id>|require_approval on|off", "Moderate installed mods", "(list|(approve|unapprove) [a-z0-9._]{3,64}|require_approval (on|off))", false, false));
        commands.put("audit", new Cmd("audit [n]", "Show the last n audit entries (max 30)", "([0-9]{1,2})?", false, false));
        commands.put("emergency_disable", new Cmd("emergency_disable", "Revoke the token and lock owner tools on this device", "", true, false));
        commands.put("confirm", new Cmd("confirm <code>", "Confirm a pending destructive command", "[A-Z0-9]{6}", false, false));
    }

    public synchronized Result execute(String line) {
        String actor = host.playerName();
        String safe = line == null ? "" : line.trim();
        if (!owner.isOwner()) {
            audit.record(actor, "(denied) " + truncate(safe), "denied: not owner");
            return new Result(false, "Not authorized.");
        }
        long now = clock.getAsLong();
        while (!recent.isEmpty() && now - recent.peekFirst() > RATE_WINDOW_MS) recent.pollFirst();
        if (recent.size() >= RATE_LIMIT) {
            audit.record(actor, "(rate-limited)", "denied: rate limit");
            return new Result(false, "Slow down: too many commands. Try again shortly.");
        }
        recent.addLast(now);
        if (safe.isEmpty() || safe.length() > MAX_LINE || !SAFE_LINE.matcher(safe).matches())
            return finish(actor, "(invalid input)", new Result(false, "Invalid input."));

        String[] parts = safe.split("\\s+", 2);
        String name = parts[0].toLowerCase(Locale.ROOT);
        String args = parts.length > 1 ? parts[1].trim() : "";
        Cmd c = commands.get(name);
        if (c == null) return finish(actor, safe, new Result(false, "Unknown command. Type help."));
        if (!c.args.matcher(args).matches()) return finish(actor, safe, new Result(false, "Usage: " + c.usage));
        if (c.devOnly && !config.isDev()) return finish(actor, safe, new Result(false, "Not available in production."));

        if (name.equals("confirm")) {
            if (pendingCode == null || now > pendingExpiry || !pendingCode.equals(args)) {
                pendingCode = null;
                return finish(actor, "confirm", new Result(false, "Nothing to confirm (expired or wrong code)."));
            }
            String run = pendingLine;
            pendingCode = null;
            String[] p2 = run.split("\\s+", 2);
            return finish(actor, "confirmed: " + run, run(p2[0].toLowerCase(Locale.ROOT), p2.length > 1 ? p2[1].trim() : ""));
        }
        if (c.destructive && !(name.equals("maintenance") && args.equals("off"))) {
            pendingCode = code();
            pendingLine = safe;
            pendingExpiry = now + CONFIRM_MS;
            return finish(actor, "(pending) " + safe, new Result(true, "This is a global/destructive action on environment '" + config.environment
                    + "'. Type: confirm " + pendingCode + "  (valid 30 s)"));
        }
        return finish(actor, safe, run(name, args));
    }

    private Result finish(String actor, String cmd, Result r) {
        audit.record(actor, cmd, (r.ok ? "ok: " : "fail: ") + truncate(r.text));
        return r;
    }

    private Result run(String name, String args) {
        Factory f = host.factory();
        switch (name) {
            case "help": {
                StringBuilder sb = new StringBuilder();
                for (Cmd c : commands.values()) sb.append(c.usage).append("  - ").append(c.help).append('\n');
                return new Result(true, sb.toString().trim());
            }
            case "status":
                return new Result(true, "env=" + config.environment + " server=" + config.serverId + " tick=" + f.tick + " money=" + f.money
                        + " buildings=" + f.buildings().size() + " maintenance=" + host.maintenance()
                        + " ownerSessionEndsIn=" + Math.max(0, owner.expiresAtSeconds() - clock.getAsLong() / 1000) + "s");
            case "health":
                return new Result(true, host.healthReport());
            case "announce":
                host.announce(args);
                return new Result(true, "Announced.");
            case "maintenance":
                host.setMaintenance(args.equals("on"));
                return new Result(true, "Maintenance " + args + ".");
            case "inspect":
                if (args.equals("player"))
                    return new Result(true, "player=" + host.playerName() + " money=" + f.money + " techs=" + f.techs + " earned=" + f.earned);
                return new Result(true, "buildings=" + f.buildings().size() + " mined=" + f.mined + " sold=" + f.sold + " discarded=" + f.discarded
                        + " ledgerBalance=" + f.ledgerBalance() + " power=" + f.powerSupply + "/" + f.powerDemand);
            case "grant_test": {
                String[] a = args.split(" ");
                if (a[0].equals("money")) {
                    long amt = Long.parseLong(a[1]);
                    if (amt < 1 || amt > 100_000) return new Result(false, "Amount must be 1-100000.");
                    f.money += amt;
                    return new Result(true, "Granted " + amt + " test money.");
                }
                if (!host.baseData().techs.containsKey(a[1])) return new Result(false, "Unknown technology.");
                f.techs.add(a[1]);
                return new Result(true, "Granted research " + a[1] + ".");
            }
            case "reload_config":
                return new Result(true, host.reloadConfig());
            case "config_rollback":
                return new Result(true, host.rollbackConfig());
            case "mods": {
                ModManager mm = host.mods();
                if (args.equals("list")) {
                    StringBuilder sb = new StringBuilder();
                    for (ModManager.Info i : mm.list(host.baseData()))
                        sb.append(i.id).append(' ').append(i.version).append(i.enabled ? " enabled" : " disabled").append(i.approved ? " approved" : " unapproved").append('\n');
                    return new Result(true, sb.length() == 0 ? "No mods installed." : sb.toString().trim());
                }
                String[] a = args.split(" ");
                if (a[0].equals("require_approval")) { mm.setApprovalRequired(a[1].equals("on")); return new Result(true, "Approval requirement " + a[1] + "."); }
                mm.setApproved(a[1], a[0].equals("approve"));
                return new Result(true, a[0] + "d " + a[1] + ".");
            }
            case "audit": {
                int n = args.isEmpty() ? 10 : Math.min(30, Math.max(1, Integer.parseInt(args)));
                List<String> t = audit.tail(n);
                return new Result(true, t.isEmpty() ? "Audit log is empty." : String.join("\n", t));
            }
            case "emergency_disable":
                owner.revokeCurrentToken();
                owner.emergencyDisable();
                return new Result(true, "Owner tools disabled and token revoked. Re-enable from Settings with your account password.");
            default:
                return new Result(false, "Unknown command.");
        }
    }

    private static String code() {
        String a = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 6; i++) sb.append(a.charAt(RNG.nextInt(a.length())));
        return sb.toString();
    }

    private static String truncate(String s) { return s.length() > 120 ? s.substring(0, 120) : s; }
}
