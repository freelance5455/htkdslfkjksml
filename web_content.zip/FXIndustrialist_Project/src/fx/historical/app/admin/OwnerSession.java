package fx.historical.app.admin;

import fx.historical.app.core.Json;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Base64;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.function.LongSupplier;

/**
 * Owner authorization. Owner rights are granted ONLY when all of these hold:
 *  1. the signed-in account's username is exactly "FxplayzOfficial" (set by LocalAuth after a real login),
 *  2. a token signed by the configured owner private key is presented, naming that same subject,
 *  3. the token is unexpired, short-lived, correctly scoped and its id has not been revoked,
 *  4. the emergency-disable flag is not set.
 * A client-supplied name, display name, config value or local variable alone never grants anything.
 *
 * LIMIT: this is on-device verification. A hacked device can bypass any on-device check, so for multiplayer
 * the same token must be verified by the server before any command is applied (see docs).
 */
public final class OwnerSession {
    public static final String OWNER_USERNAME = "FxplayzOfficial";
    public static final long MAX_TOKEN_LIFETIME_SECONDS = 24 * 3600;
    private static final long CLOCK_SKEW_SECONDS = 300;

    private final String publicKey;
    private final File stateFile;
    private final LongSupplier clock;
    private final Set<String> revokedIds = new LinkedHashSet<>();
    private boolean disabled;
    private boolean active;
    private long expiresAt;
    private String jti = "";

    public OwnerSession(String publicKeyB64, File stateFile, LongSupplier clock) {
        this.publicKey = publicKeyB64 == null ? "" : publicKeyB64;
        this.stateFile = stateFile;
        this.clock = clock;
        load();
    }

    /** @return null on success, otherwise a safe, non-revealing message. */
    public synchronized String authorize(String signedInUsername, String token) {
        active = false;
        if (disabled) return "Owner tools are disabled on this device.";
        if (publicKey.isEmpty()) return "Owner tools are not configured in this build.";
        if (!OWNER_USERNAME.equals(signedInUsername)) return "Not authorized.";
        if (token == null || token.length() > 4096) return "Not authorized.";
        String[] parts = token.trim().split("\\.");
        if (parts.length != 2) return "Not authorized.";
        try {
            byte[] payload = Base64.getUrlDecoder().decode(parts[0]);
            if (!Crypto.verify(publicKey, payload, parts[1])) return "Not authorized.";
            Map<String, Object> p = Json.parseObject(new String(payload, StandardCharsets.UTF_8));
            long now = clock.getAsLong() / 1000;
            long iat = Json.lng(p, "iat", 0), exp = Json.lng(p, "exp", 0);
            String id = Json.str(p, "jti", "");
            if (!OWNER_USERNAME.equals(Json.str(p, "sub", "")) || !"owner".equals(Json.str(p, "scope", ""))) return "Not authorized.";
            if (now < iat - CLOCK_SKEW_SECONDS || now >= exp || exp - iat > MAX_TOKEN_LIFETIME_SECONDS) return "Token expired or invalid.";
            if (id.isEmpty() || revokedIds.contains(id)) return "Not authorized.";
            active = true; expiresAt = exp; jti = id;
            return null;
        } catch (IllegalArgumentException | Json.JsonException e) {
            return "Not authorized.";
        }
    }

    public synchronized boolean isOwner() {
        if (active && (disabled || clock.getAsLong() / 1000 >= expiresAt)) active = false;
        return active;
    }

    public synchronized long expiresAtSeconds() { return active ? expiresAt : 0; }

    public synchronized void clear() { active = false; }

    /** Revokes the current token id and ends the session. */
    public synchronized void revokeCurrentToken() {
        if (!jti.isEmpty()) revokedIds.add(jti);
        active = false;
        save();
    }

    /** Emergency kill switch: owner tools stay off until {@link #reenable()} is called from a password-protected UI. */
    public synchronized void emergencyDisable() {
        disabled = true;
        active = false;
        save();
    }

    public synchronized void reenable() { disabled = false; save(); }

    public synchronized boolean isDisabled() { return disabled; }

    private void load() {
        if (stateFile == null || !stateFile.exists()) return;
        try {
            Map<String, Object> m = Json.parseObject(new String(Files.readAllBytes(stateFile.toPath()), StandardCharsets.UTF_8));
            disabled = Json.bool(m, "disabled", false);
            java.util.List<Object> r = Json.arr(m.get("revoked"));
            if (r != null) for (Object o : r) if (o instanceof String) revokedIds.add((String) o);
        } catch (IOException | Json.JsonException e) {
            disabled = true; // unreadable safety state: fail closed
        }
    }

    private void save() {
        if (stateFile == null) return;
        try {
            Map<String, Object> m = new java.util.LinkedHashMap<>();
            m.put("disabled", disabled);
            m.put("revoked", new java.util.ArrayList<Object>(revokedIds));
            Files.write(stateFile.toPath(), Json.write(m).getBytes(StandardCharsets.UTF_8));
        } catch (IOException ignored) { }
    }
}
