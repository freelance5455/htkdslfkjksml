package fx.historical.app.admin;

import fx.historical.app.core.GameData;
import fx.historical.app.core.Json;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Base64;
import java.util.Map;

/**
 * Signed, versioned, hot-reloadable balance bundles with last-known-good rollback.
 *
 * HOT-RELOADABLE (this class): item sell prices; machine cost, power, cycle time.
 * NEEDS A NEW APP BUILD (never applied here): code, new machine behaviours, save-format or protocol changes.
 * A bundle must declare "requires":"none"; anything else is refused and reported, never half-applied.
 * Bundles are verified with the release public key; only whitelisted keys inside numeric bounds are read.
 * Saves are never touched by a config change.
 */
public final class ConfigUpdater {
    public static final class Result {
        public final boolean ok;
        public final String message;
        Result(boolean ok, String m) { this.ok = ok; this.message = m; }
    }

    private final File current, lastGood;
    private final String publicKey;
    private int version;
    private String notes = "";
    private String payloadJson = "{}";

    public ConfigUpdater(File dir, String releasePublicKey) {
        dir.mkdirs();
        current = new File(dir, "current_bundle.json");
        lastGood = new File(dir, "last_good_bundle.json");
        publicKey = releasePublicKey == null ? "" : releasePublicKey;
        if (current.exists()) {
            try { load(read(current)); } catch (IOException | Json.JsonException | RuntimeException e) { resetState(); current.delete(); }
        }
    }

    public int version() { return version; }

    public String notes() { return notes; }

    public synchronized Result apply(String bundleJson) {
        if (publicKey.isEmpty()) return new Result(false, "No release key configured; updates are disabled.");
        try {
            Map<String, Object> b = Json.parseObject(bundleJson);
            int v = (int) Json.lng(b, "version", -1);
            if (v <= version) return new Result(false, "Bundle version " + v + " is not newer than " + version + ".");
            String requires = Json.str(b, "requires", "");
            String p64 = Json.str(b, "payloadB64", "");
            if (!Crypto.verify(publicKey, signedBytes(v, requires, p64), Json.str(b, "sig", "")))
                return new Result(false, "Signature check failed. Bundle rejected.");
            if (!"none".equals(requires)) return new Result(false, "This release needs an app update (" + requires + "); it cannot be hot-loaded.");
            String payload = new String(Base64.getDecoder().decode(p64), StandardCharsets.UTF_8);
            validatePayload(payload);
            // keep the previous bundle as last-known-good before replacing it
            if (current.exists()) Files.copy(current.toPath(), lastGood.toPath(), StandardCopyOption.REPLACE_EXISTING);
            File tmp = new File(current.getPath() + ".tmp");
            Files.write(tmp.toPath(), bundleJson.getBytes(StandardCharsets.UTF_8));
            Files.move(tmp.toPath(), current.toPath(), StandardCopyOption.REPLACE_EXISTING);
            load(bundleJson);
            return new Result(true, "Applied config v" + version + (notes.isEmpty() ? "" : ": " + notes));
        } catch (Json.JsonException | IllegalArgumentException | IOException e) {
            return new Result(false, "Bundle rejected: invalid content.");
        }
    }

    public synchronized Result rollback() {
        try {
            if (!lastGood.exists()) {
                current.delete();
                resetState();
                return new Result(true, "Rolled back to built-in values.");
            }
            String prev = read(lastGood);
            Files.write(current.toPath(), prev.getBytes(StandardCharsets.UTF_8));
            lastGood.delete();
            load(prev);
            return new Result(true, "Rolled back to config v" + version + ".");
        } catch (IOException | Json.JsonException | RuntimeException e) {
            return new Result(false, "Rollback failed.");
        }
    }

    /** Returns a copy of base with the active bundle's overrides applied. */
    public synchronized GameData overlay(GameData base) {
        GameData d = base.copy();
        try {
            Map<String, Object> p = Json.parseObject(payloadJson);
            Map<String, Object> items = Json.obj(p.get("items")), machines = Json.obj(p.get("machines"));
            if (items != null)
                for (Map.Entry<String, Object> e : items.entrySet()) {
                    GameData.ItemDef it = d.items.get(e.getKey());
                    Map<String, Object> o = Json.obj(e.getValue());
                    if (it != null && o != null && o.containsKey("sellPrice")) it.sellPrice = (int) Json.lng(o, "sellPrice", it.sellPrice);
                }
            if (machines != null)
                for (Map.Entry<String, Object> e : machines.entrySet()) {
                    GameData.MachineDef m = d.machines.get(e.getKey());
                    Map<String, Object> o = Json.obj(e.getValue());
                    if (m == null || o == null) continue;
                    if (o.containsKey("cost")) m.cost = (int) Json.lng(o, "cost", m.cost);
                    if (o.containsKey("power")) m.power = (int) Json.lng(o, "power", m.power);
                    if (o.containsKey("cycleTicks")) m.cycleTicks = (int) Json.lng(o, "cycleTicks", m.cycleTicks);
                }
        } catch (Json.JsonException ignored) { }
        return d;
    }

    // ------------------------------------------------------------------ helpers

    public static byte[] signedBytes(int version, String requires, String payloadB64) {
        return ("fxcfg1\n" + version + "\n" + requires + "\n" + payloadB64).getBytes(StandardCharsets.UTF_8);
    }

    private static void validatePayload(String payload) throws Json.JsonException {
        Map<String, Object> p = Json.parseObject(payload);
        for (String k : p.keySet()) if (!k.equals("items") && !k.equals("machines")) throw new Json.JsonException("unknown key " + k);
        Map<String, Object> items = Json.obj(p.get("items")), machines = Json.obj(p.get("machines"));
        if (items != null)
            for (Object o : items.values()) {
                Map<String, Object> m = Json.obj(o);
                if (m == null) throw new Json.JsonException("bad item entry");
                for (String k : m.keySet()) if (!k.equals("sellPrice")) throw new Json.JsonException("unknown item key");
                range(m, "sellPrice", 0, 10_000);
            }
        if (machines != null)
            for (Object o : machines.values()) {
                Map<String, Object> m = Json.obj(o);
                if (m == null) throw new Json.JsonException("bad machine entry");
                for (String k : m.keySet()) if (!k.equals("cost") && !k.equals("power") && !k.equals("cycleTicks")) throw new Json.JsonException("unknown machine key");
                range(m, "cost", 0, 1_000_000);
                range(m, "power", -100, 100);
                range(m, "cycleTicks", 1, 6000);
            }
    }

    private static void range(Map<String, Object> m, String k, long lo, long hi) throws Json.JsonException {
        if (!m.containsKey(k)) return;
        if (!(m.get(k) instanceof Number)) throw new Json.JsonException("not a number: " + k);
        long v = ((Number) m.get(k)).longValue();
        if (v < lo || v > hi) throw new Json.JsonException(k + " out of range");
    }

    private void load(String bundleJson) throws Json.JsonException {
        Map<String, Object> b = Json.parseObject(bundleJson);
        version = (int) Json.lng(b, "version", 0);
        notes = Json.str(b, "notes", "");
        if (notes.length() > 200) notes = notes.substring(0, 200);
        payloadJson = new String(Base64.getDecoder().decode(Json.str(b, "payloadB64", "")), StandardCharsets.UTF_8);
    }

    private void resetState() { version = 0; notes = ""; payloadJson = "{}"; }

    private static String read(File f) throws IOException {
        return new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8);
    }
}
