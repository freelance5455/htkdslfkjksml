package fx.historical.app.admin;

import fx.historical.app.core.Json;

import java.util.Map;

/** Non-secret app configuration. Public keys are public by design; private keys never ship in the app. */
public final class AppConfig {
    public final String environment;       // "dev" or "prod"
    public final String ownerPublicKey;    // Base64 X.509 EC P-256 key, empty = owner tools disabled
    public final String releasePublicKey;  // key that signs config bundles; falls back to owner key
    public final String serverId;

    public AppConfig(String env, String ownerKey, String releaseKey, String serverId) {
        this.environment = "dev".equals(env) ? "dev" : "prod"; // anything unexpected is treated as production
        this.ownerPublicKey = ownerKey == null ? "" : ownerKey.trim();
        this.releasePublicKey = (releaseKey == null || releaseKey.trim().isEmpty()) ? this.ownerPublicKey : releaseKey.trim();
        this.serverId = serverId == null || serverId.isEmpty() ? "local-device" : serverId;
    }

    public static AppConfig parse(String json) {
        try {
            Map<String, Object> m = Json.parseObject(json);
            return new AppConfig(Json.str(m, "environment", "prod"), Json.str(m, "owner_public_key", ""),
                    Json.str(m, "release_public_key", ""), Json.str(m, "server_id", "local-device"));
        } catch (Json.JsonException e) {
            return new AppConfig("prod", "", "", "local-device");
        }
    }

    public boolean isDev() { return "dev".equals(environment); }
}
