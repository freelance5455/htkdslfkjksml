package fx.historical.app.admin;

import fx.historical.app.core.Json;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.LongSupplier;

/** Append-only JSON-lines audit log: who, when, where (server id/environment), what, outcome. */
public final class AuditLog {
    private static final long ROTATE_BYTES = 256 * 1024;
    private final File file;
    private final String serverId, environment;
    private final LongSupplier clock;

    public AuditLog(File file, String serverId, String environment, LongSupplier clock) {
        this.file = file; this.serverId = serverId; this.environment = environment; this.clock = clock;
    }

    public synchronized void record(String actor, String command, String outcome) {
        try {
            Map<String, Object> e = new LinkedHashMap<>();
            e.put("ts", clock.getAsLong());
            e.put("actor", actor == null ? "unknown" : actor);
            e.put("server", serverId);
            e.put("env", environment);
            e.put("cmd", command.length() > 200 ? command.substring(0, 200) : command);
            e.put("result", outcome);
            if (file.exists() && file.length() > ROTATE_BYTES)
                Files.move(file.toPath(), new File(file.getPath() + ".1").toPath(), StandardCopyOption.REPLACE_EXISTING);
            Files.write(file.toPath(), (Json.write(e) + "\n").getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException ignored) { }
    }

    public synchronized List<String> tail(int n) {
        List<String> out = new ArrayList<>();
        try {
            if (!file.exists()) return out;
            List<String> lines = Files.readAllLines(file.toPath(), StandardCharsets.UTF_8);
            for (int i = Math.max(0, lines.size() - n); i < lines.size(); i++) out.add(lines.get(i));
        } catch (IOException ignored) { }
        return out;
    }
}
