package fx.historical.app.admin;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

/** ECDSA P-256 / SHA-256 signature verification (verification only: the app never holds a private key). */
public final class Crypto {
    private Crypto() {}

    public static boolean verify(String publicKeyB64, byte[] data, String sigB64Url) {
        if (publicKeyB64 == null || publicKeyB64.isEmpty() || sigB64Url == null) return false;
        try {
            PublicKey key = KeyFactory.getInstance("EC").generatePublic(new X509EncodedKeySpec(Base64.getDecoder().decode(publicKeyB64)));
            Signature s = Signature.getInstance("SHA256withECDSA");
            s.initVerify(key);
            s.update(data);
            return s.verify(Base64.getUrlDecoder().decode(sigB64Url));
        } catch (GeneralSecurityException | IllegalArgumentException e) {
            return false;
        }
    }

    public static byte[] utf8(String s) { return s.getBytes(StandardCharsets.UTF_8); }
}
