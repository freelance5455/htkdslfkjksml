package fx.historical.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import fx.historical.app.ui.Nav;
import fx.historical.app.ui.Screen;
import fx.historical.app.ui.Services;

import java.io.InputStream;

/** Single-activity host: owns the Services container and swaps full-screen pages. */
public class MainActivity extends Activity implements Nav {
    private static final int REQ_PICK = 4711;

    private Services services;
    private FrameLayout root;
    private Screen current;
    private FilePicked pending;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        root = new FrameLayout(this);
        setContentView(root);
        try {
            services = new Services(getApplicationContext());
        } catch (Exception e) {
            TextView t = new TextView(this);
            t.setText("FX Industrialist could not start: game data is missing or damaged.\n" + e.getMessage());
            t.setTextColor(0xFFFF5C6C);
            t.setPadding(40, 80, 40, 40);
            root.addView(t);
            return;
        }
        home();
    }

    @Override public void go(Screen s) {
        if (current != null) { current.onPause(); current.onDestroy(); }
        current = s;
        root.removeAllViews();
        View v = s.create();
        root.addView(v, new FrameLayout.LayoutParams(-1, -1));
        s.onResume();
    }

    @Override public void home() {
        if (services == null) return;
        if (services.auth.session() == null) go(new fx.historical.app.ui.LoginScreenFactory().create(this));
        else go(new fx.historical.app.ui.LoginScreenFactory().hub(this));
    }

    @Override public Services services() { return services; }

    @Override public Activity activity() { return this; }

    @Override public void pickFile(String[] mimeTypes, FilePicked cb) {
        pending = cb;
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes);
        startActivityForResult(i, REQ_PICK);
    }

    @Override protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);
        if (req != REQ_PICK || pending == null) return;
        final FilePicked cb = pending;
        pending = null;
        if (result != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        services.io.execute(() -> {
            byte[] bytes = null;
            String err = null;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                bytes = in == null ? null : Services.readLimited(in, 5 * 1024 * 1024);
                if (bytes == null) err = "File is empty or larger than 5 MB.";
            } catch (Exception e) {
                err = "Could not read that file.";
            }
            final byte[] fb = bytes;
            final String fe = err;
            runOnUiThread(() -> cb.onBytes(fb, fe));
        });
    }

    @Override protected void onPause() {
        if (current != null) current.onPause();
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        if (current != null) current.onResume();
    }

    @Override public void onBackPressed() {
        if (current != null && current.onBack()) return;
        super.onBackPressed();
    }
}
