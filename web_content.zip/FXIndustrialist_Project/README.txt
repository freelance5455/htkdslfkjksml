FX INDUSTRIALIST  -  Android app (package: fx.historical.app)
=============================================================

WHAT THIS IS
An original, offline, mobile-first factory-building game plus a small platform around it
(accounts, mod manager, owner console, signed balance updates). All code, UI and graphics are original;
nothing is copied from Roblox or any other game.

WHAT IS REAL AND TESTED vs NOT
Tested (136 automated checks, run on a JDK, all passing when this ZIP was made):
  - factory simulation (placement rules, power, conveyors, splitter, smelting, selling, research, item ledger, determinism)
  - crash-safe saves (backup, checksum, corrupt-file recovery)
  - local accounts (salted PBKDF2 hashes, lockout, recovery code), mod validation/install/rollback, owner token checks,
    command console (allowlist, confirmation, rate limit, audit log), signed config bundles with rollback
NOT tested on a real phone: the Android UI layer (src/fx/historical/app/ui and MainActivity.java). It was only
compile-checked against hand-written stand-ins for the Android classes, never against the real Android SDK and never run.
Expect to fix a few compile or layout issues on first build. Please send me the exact error text and I will fix it.
No APK was built. No claim is made that the app is published, online, multiplayer-ready, or "fully secure".

NOT IMPLEMENTED (honest list)
  - Multiplayer, cloud saves, cloud accounts, email password reset, online mod catalog/marketplace
  - Server-side owner commands: kick, roles, publish release, release rollback (need a backend; see docs)
  - Filter machine, pollution, sound/music, plot expansion, in-game use of mod localization strings
  - Experience browser (there is exactly one game)

GAMEPLAY QUICK START
1. Register (write down the recovery code), then Start new factory.
2. Follow the on-screen tutorial: Solar Array -> Miner on an ore tile -> Seller -> Conveyors -> smelter -> Research.
3. Tools: Pan (one finger), pinch to zoom, two fingers to pan. "Facing" sets the direction for new machines.
   Drag with a build tool selected to place many tiles. Rotate/Remove/Inspect are tools too.
4. Colored outlines: yellow = output blocked, red = no power.

BUILDING THE APK ON A PHONE (Code Studio by ALIF Technology)
This project uses the same flat layout as your other Code Studio projects: AndroidManifest.xml, src/, res/, assets/.
There are NO Gradle files on purpose.
1. Unzip FXIndustrialist_Project.zip and open the folder in Code Studio.
2. Build/Run. minSdk is 26 (Android 8.0), target 33. Package name is fx.historical.app.
3. If Code Studio reports an error, copy the first error line to me.
If you would rather build with Gradle (for example through GitHub Actions) tell me and I will add the Gradle files.

RUNNING THE TESTS (needs a JDK 17+, i.e. a computer or a cloud shell - not possible inside the app)
  sh tools/run_tests.sh

CONFIGURATION
assets/app_config.json (no secrets):  environment ("prod" or "dev"), owner_public_key, release_public_key, server_id.
Leave the keys empty and the owner console and signed updates stay switched off (the safe default).
Details for owner setup: docs/OWNER_AND_LIVE_UPDATE.md.

TROUBLESHOOTING
- "could not start: game data is missing": the assets/ folder was not packaged. Check that assets/data/*.json exist.
- Login says "Too many attempts": wait; lockouts grow after 5 wrong tries. Forgot password: use Recover with your recovery code.
- A mod will not enable: read the red message; common causes are a missing dependency or a newer game version requirement.
- Save damaged message: the game restored your backup automatically; one-off backups named *.mod-removed.bak are kept when a mod was removed.
- Battery or lag on a low-end phone: Settings -> Battery saver, and zoom out less.
