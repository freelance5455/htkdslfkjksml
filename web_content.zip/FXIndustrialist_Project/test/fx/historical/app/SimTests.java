package fx.historical.app;

import fx.historical.app.core.GameData;
import fx.historical.app.core.Json;
import fx.historical.app.sim.Building;
import fx.historical.app.sim.Factory;
import fx.historical.app.sim.SaveManager;
import fx.historical.app.sim.Tutorial;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

import static fx.historical.app.TestSupport.check;

public final class SimTests {
    static Factory chain(GameData d) {
        Factory f = new Factory(d, 40, 40, 7);
        f.money = 10_000;
        check(f.place("solar", 0, 0, 0).ok, "place solar");
        check(f.place("miner", 3, 3, 0).ok, "place miner on ore");
        check(f.place("conveyor", 4, 3, 0).ok, "place conveyor 1");
        check(f.place("conveyor", 5, 3, 0).ok, "place conveyor 2");
        check(f.place("seller", 6, 3, 0).ok, "place seller");
        return f;
    }

    public static void run() throws Exception {
        System.out.println("[sim]");
        GameData d = TestSupport.baseData();

        Factory f = chain(d);
        f.run(600);
        check(f.mined > 10, "miner produced ore (" + f.mined + ")");
        check(f.sold > 5 && f.earned == f.sold, "seller sold ore and paid (" + f.sold + ")");
        check(f.ledgerBalance() == 0, "ledger balances (no duplication or loss)");

        Factory g = new Factory(d, 40, 40, 7);
        g.money = 10_000;
        check(!g.place("miner", 20, 20, 0).ok || g.resourceAt(20, 20) != 0, "miner rejected off ore");
        check(!g.place("miner", -1, 0, 0).ok, "out-of-bounds rejected");
        g.place("seller", 1, 1, 0);
        check(!g.place("seller", 1, 1, 0).ok, "occupied tile rejected");
        check(!g.place("splitter", 2, 1, 0).ok, "locked machine rejected before research");
        check(!g.research("automation").ok, "research prerequisite enforced");
        check(g.research("logistics").ok && g.place("splitter", 2, 1, 0).ok, "research unlocks splitter");
        Factory poor = new Factory(d, 40, 40, 7);
        poor.money = 1;
        check(!poor.place("seller", 1, 1, 0).ok, "insufficient money rejected");

        Factory noPower = new Factory(d, 40, 40, 7);
        noPower.money = 10_000;
        noPower.place("miner", 3, 3, 0);
        noPower.run(200);
        check(noPower.mined == 0 && noPower.at(3, 3).state == Building.State.NO_POWER, "no power state, no output");

        Factory blocked = new Factory(d, 40, 40, 7);
        blocked.money = 10_000;
        blocked.place("solar", 0, 0, 0);
        blocked.place("miner", 3, 3, 0);
        blocked.run(600);
        check(blocked.at(3, 3).state == Building.State.BLOCKED && Building.total(blocked.at(3, 3).outBuf) == 5, "blocked output state, buffer capped");
        check(blocked.ledgerBalance() == 0, "ledger balances when blocked");

        // smelting chain: miner -> smelter -> seller
        Factory sm = new Factory(d, 40, 40, 7);
        sm.money = 10_000;
        sm.place("solar", 0, 0, 0); sm.place("solar", 1, 0, 0);
        sm.place("miner", 3, 3, 0); sm.place("smelter", 4, 3, 0); sm.place("seller", 5, 3, 0);
        sm.run(1200);
        check(sm.soldByItem.getOrDefault("iron_plate", 0L) > 3, "ore smelted into plates and sold");
        check(sm.recipeConsumed > 0 && sm.ledgerBalance() == 0, "ledger balances with recipes");

        // splitter distributes to two sellers
        Factory sp = new Factory(d, 40, 40, 7);
        sp.money = 100_000;
        sp.techs.add("logistics");
        sp.place("solar", 0, 0, 0);
        sp.place("miner", 3, 3, 0); sp.place("splitter", 4, 3, 0);
        sp.place("seller", 5, 3, 0); sp.place("seller", 4, 2, 0); sp.place("seller", 4, 4, 0);
        sp.run(800);
        check(sp.sold > 5 && sp.ledgerBalance() == 0, "splitter routes items without loss");

        // removal discards are accounted
        Factory rm = chain(d);
        rm.run(120);
        long money = rm.money;
        rm.remove(5, 3);
        check(rm.money > money && rm.ledgerBalance() == 0, "remove refunds and keeps ledger balanced");

        // determinism
        Factory a = chain(d), b = chain(d);
        a.run(1000); b.run(1000);
        check(Json.write(a.toMap()).equals(Json.write(b.toMap())), "same inputs give identical state");

        // save / load round trip
        File dir = TestSupport.tempDir("fxsave");
        SaveManager sv = new SaveManager(dir, "slot1");
        check(sv.save(a) == null, "save succeeds");
        SaveManager.Loaded l = sv.load(d);
        check(l != null && Json.write(l.factory.toMap()).equals(Json.write(a.toMap())), "load restores identical state");
        l.factory.run(100); a.run(100);
        check(Json.write(l.factory.toMap()).equals(Json.write(a.toMap())), "loaded game continues deterministically");

        // corrupt main save -> backup
        sv.save(a);
        File main = new File(dir, "slot1.json");
        Files.write(main.toPath(), "{garbage".getBytes(StandardCharsets.UTF_8));
        SaveManager.Loaded rec = sv.load(d);
        check(rec != null && rec.warning != null, "corrupt save recovered from backup with warning");
        // tampered body -> checksum mismatch
        sv.save(a);
        String txt = TestSupport.read(main.getPath()).replace("\\\"money\\\":", "\\\"money\\\":9");
        Files.write(main.toPath(), txt.getBytes(StandardCharsets.UTF_8));
        check(sv.load(d).warning != null, "tampered save detected by checksum");

        // unknown machine in save (removed mod) does not crash and items are accounted
        Factory modded = new Factory(d, 40, 40, 7);
        modded.money = 10_000;
        modded.place("solar", 0, 0, 0);
        String json = Json.write(modded.toMap()).replace("\"buildings\":[", "\"buildings\":[{\"m\":\"gone:machine\",\"x\":9,\"y\":9,\"r\":0,\"slot\":\"iron_ore\"},");
        Factory loaded = Factory.fromMap(d, Json.parseObject(json));
        check(loaded.buildings().size() == 1 && loaded.discarded == 1, "missing-mod machine skipped, item discarded and counted");

        // tutorial progression
        check(Tutorial.current(new Factory(d, 40, 40, 7)).startsWith("1/8"), "tutorial starts at step 1");
        check(Tutorial.current(chain(d)) != null, "tutorial advances from state");

        // performance sanity: a large factory ticks quickly
        Factory big = new Factory(d, 128, 128, 3);
        big.money = Long.MAX_VALUE / 4;
        big.techs.add("logistics");
        big.place("solar", 0, 0, 0);
        for (int y = 5; y < 125; y += 2) for (int x = 5; x < 120; x++) big.place("conveyor", x, y, 0);
        long t0 = System.nanoTime();
        big.run(100);
        long ms = (System.nanoTime() - t0) / 1_000_000;
        check(big.buildings().size() > 5000 && ms < 3000, "5000+ buildings x 100 ticks in " + ms + " ms");
        check(d.copy().machines.size() == d.machines.size(), "GameData.copy works");
    }
}
