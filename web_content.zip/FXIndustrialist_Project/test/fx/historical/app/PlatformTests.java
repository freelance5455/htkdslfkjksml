package fx.historical.app;

import fx.historical.app.admin.AdminConsole;
import fx.historical.app.admin.AppConfig;
import fx.historical.app.admin.AuditLog;
import fx.historical.app.admin.ConfigUpdater;
import fx.historical.app.admin.OwnerSession;
import fx.historical.app.auth.LocalAuth;
import fx.historical.app.core.GameData;
import fx.historical.app.mod.ModManager;
import fx.historical.app.mod.ModValidator;
import fx.historical.app.sim.Factory;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import static fx.historical.app.TestSupport.check;

public final class PlatformTests {
    static String tool(String... args) throws Exception {
        java.util.List<String> cmd = new java.util.ArrayList<>();
        cmd.add("java"); cmd.add("tools/OwnerTokenTool.java");
        for (String a : args) cmd.add(a);
        Process p = new ProcessBuilder(cmd).redirectErrorStream(true).start();
        String out = new String(p.getInputStream().readAllBytes(), StandardCharsets.UTF_8).trim();
        p.waitFor();
        return out;
    }

    static byte[] zip(Map<String, String> files) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        try (ZipOutputStream z = new ZipOutputStream(bo)) {
            for (Map.Entry<String, String> e : files.entrySet()) {
                z.putNextEntry(new ZipEntry(e.getKey()));
                z.write(e.getValue().getBytes(StandardCharsets.UTF_8));
                z.closeEntry();
            }
        }
        return bo.toByteArray();
    }

    static Map<String, String> sampleFiles() throws Exception {
        Map<String, String> m = new LinkedHashMap<>();
        for (String n : new String[]{"manifest.json", "items.json", "machines.json", "recipes.json", "lang_en.json"})
            m.put(n, TestSupport.read("mods/sample_mod/" + n));
        return m;
    }

    static Map<String, String> withManifest(String find, String repl) throws Exception {
        Map<String, String> m = sampleFiles();
        m.put("manifest.json", m.get("manifest.json").replace(find, repl));
        return m;
    }

    public static void run() throws Exception {
        GameData base = TestSupport.baseData();
        AtomicLong now = new AtomicLong(1_000_000);

        System.out.println("[auth]");
        LocalAuth auth = new LocalAuth(TestSupport.tempDir("fxauth"), now::get);
        LocalAuth.Result r = auth.register("Player_One", "hunter2hunter");
        check(r.ok && r.recoveryCode != null && r.recoveryCode.matches("[A-Z2-9]{4}(-[A-Z2-9]{4}){3}"), "register returns one-time recovery code");
        check(!auth.register("player_one", "another1pass").ok, "duplicate username (case-insensitive) refused");
        check(!auth.register("ab", "hunter2hunter").ok && !auth.register("Valid_Name", "short1").ok && !auth.register("Valid_Name", "allletterspass").ok, "weak credentials refused");
        auth.logout();
        check(!auth.login("Player_One", "wrongpass1").ok && !auth.login("nobody", "whatever1").ok, "bad login refused");
        check(auth.login("Player_One", "wrongpass1").message.equals(auth.login("nobody", "whatever1").message), "same message for unknown user vs bad password");
        check(auth.login("Player_One", "hunter2hunter").ok && auth.session() != null && auth.session().username.equals("Player_One"), "good login creates session");
        auth.logout();
        for (int i = 0; i < 6; i++) auth.login("Player_One", "badbadbad1");
        LocalAuth.Result locked = auth.login("Player_One", "hunter2hunter");
        check(!locked.ok && locked.message.contains("Too many attempts"), "lockout after repeated failures, even for correct password");
        now.addAndGet(5 * 60_000);
        check(auth.login("Player_One", "hunter2hunter").ok, "lockout expires");
        // persistence + no plaintext
        File adir = TestSupport.tempDir("fxauth2");
        LocalAuth a2 = new LocalAuth(adir, now::get);
        LocalAuth.Result reg = a2.register("Persist_User", "persist123pw");
        String disk = TestSupport.read(new File(adir, "accounts.json").getPath());
        check(!disk.contains("persist123pw") && !disk.contains(reg.recoveryCode) && disk.contains("pwHash"), "no plaintext password or recovery code on disk");
        check(new LocalAuth(adir, now::get).login("Persist_User", "persist123pw").ok, "accounts persist across restarts");
        LocalAuth.Result rec = a2.recover("Persist_User", reg.recoveryCode.toLowerCase(), "brandnew456pw");
        check(rec.ok && rec.recoveryCode != null && !rec.recoveryCode.equals(reg.recoveryCode), "recovery code resets password and rotates");
        check(!a2.recover("Persist_User", reg.recoveryCode, "another789pw").ok, "used recovery code cannot be replayed");
        check(a2.login("Persist_User", "brandnew456pw").ok && !a2.login("Persist_User", "persist123pw").ok, "new password works, old does not");

        System.out.println("[mods]");
        ModManager mm = new ModManager(TestSupport.tempDir("fxmods"));
        ModManager.Op op = mm.installZip(zip(sampleFiles()), base);
        check(op.ok, "sample mod installs: " + op.message);
        check(mm.list(base).size() == 1 && !mm.list(base).get(0).enabled, "installed mods start disabled");
        check(mm.enable("com.example.bronze", base).ok, "enable sample mod");
        ModManager.Built built = mm.build(base);
        check(built.data.items.containsKey("bronze:ingot") && built.data.machines.containsKey("bronze:foundry") && built.data.recipes.containsKey("bronze:cast_bronze"), "mod content merged");
        check(!base.items.containsKey("bronze:ingot"), "base game data untouched by mod");
        check(built.localization.containsKey("bronze.tip"), "localization loaded");
        Factory fac = new Factory(built.data, 40, 40, 5);
        fac.money = 100_000;
        fac.place("solar", 0, 0, 0); fac.place("solar", 1, 0, 0);
        check(fac.place("bronze:foundry", 10, 10, 0).ok, "mod machine placeable in game");
        check(!mm.installZip(zip(sampleFiles()), base).ok, "same version cannot be installed twice");
        Map<String, String> v2 = withManifest("\"version\": \"1.0.0\"", "\"version\": \"1.1.0\"");
        check(mm.installZip(zip(v2), base).ok && mm.list(base).get(0).version.equals("1.1.0") && "1.0.0".equals(mm.list(base).get(0).previousVersion), "update keeps previous version");
        check(mm.rollback("com.example.bronze", base).ok && mm.list(base).get(0).version.equals("1.0.0"), "rollback to previous version");
        check(mm.disable("com.example.bronze").ok && mm.uninstall("com.example.bronze").ok && mm.list(base).isEmpty(), "disable and uninstall");

        ModManager bad = new ModManager(TestSupport.tempDir("fxbad"));
        Map<String, String> f1 = sampleFiles(); f1.put("payload.dex", "xxx");
        check(!bad.installZip(zip(f1), base).ok, "reject package containing .dex");
        Map<String, String> f2 = sampleFiles(); f2.put("run.js", "alert(1)");
        check(!bad.installZip(zip(f2), base).ok, "reject package containing script");
        Map<String, String> f3 = new LinkedHashMap<>(); f3.put("../evil.json", "{}");
        check(!bad.installZip(zip(f3), base).ok, "reject zip-slip path traversal");
        Map<String, String> f4 = new LinkedHashMap<>(); f4.put("sub/manifest.json", "{}");
        check(!bad.installZip(zip(f4), base).ok, "reject nested paths");
        check(!bad.installZip(zip(withManifest("\"content.items\"", "\"system.shell\"")), base).ok, "reject unknown permission");
        check(!bad.installZip(zip(withManifest("\"permissions\": [\"content.items\", ", "\"permissions\": [")), base).ok, "reject entry without declared permission");
        check(!bad.installZip(zip(withManifest("\"namespace\": \"bronze\"", "\"namespace\": \"evil\"")), base).ok, "reject ids outside own namespace");
        Map<String, String> f5 = sampleFiles(); f5.put("items.json", "{\"items\":[{\"id\":\"iron_ore\",\"name\":\"x\",\"sellPrice\":1}]}");
        check(!bad.installZip(zip(f5), base).ok, "reject overriding base item ids");
        Map<String, String> f6 = sampleFiles(); f6.put("items.json", "{\"items\":[{\"id\":\"bronze:ingot\",\"name\":\"x\",\"sellPrice\":99999999}]}");
        check(!bad.installZip(zip(f6), base).ok, "reject out-of-range values");
        check(!bad.installZip("not a zip".getBytes(StandardCharsets.UTF_8), base).ok, "reject non-zip bytes");
        Map<String, String> f7 = sampleFiles(); f7.put("items.json", "{\"items\":[" + "{\"id\":\"bronze:a\",\"name\":\"" + "A".repeat(600_000) + "\",\"sellPrice\":1}]}");
        check(!bad.installZip(zip(f7), base).ok, "reject oversized file");
        check(!bad.installZip(zip(withManifest("\"minGameVersion\": \"1.0.0\"", "\"minGameVersion\": \"9.0.0\"")), base).ok
                || !bad.enable("com.example.bronze", base).ok, "future-version mod cannot be enabled");
        // tampering with installed files after install is caught at load time; the mod is auto-disabled, base data stays intact
        File tamRoot = TestSupport.tempDir("fxtam");
        ModManager tam = new ModManager(tamRoot);
        tam.installZip(zip(sampleFiles()), base);
        check(tam.enable("com.example.bronze", base).ok, "enable before tampering");
        Files.write(new File(tamRoot, "installed/com.example.bronze/1.0.0/items.json").toPath(),
                "{\"items\":[{\"id\":\"bronze:ingot\",\"name\":\"x\",\"sellPrice\":99999999}]}".getBytes(StandardCharsets.UTF_8));
        ModManager.Built tb = tam.build(base);
        check(!tb.data.items.containsKey("bronze:ingot") && !tam.list(base).get(0).enabled, "tampered mod auto-disabled, not loaded");
        check(tb.data.items.size() == base.items.size() && tb.data.machines.size() == base.machines.size(), "base content intact after broken mod");
        // dependency handling
        Map<String, String> dep = withManifest("\"dependencies\": {}", "\"dependencies\": {\"com.example.missing\": \"1.0.0\"}");
        ModManager dm = new ModManager(TestSupport.tempDir("fxdep"));
        dm.installZip(zip(dep), base);
        check(!dm.enable("com.example.bronze", base).ok, "enable refused when dependency missing");
        // owner approval gate
        ModManager am = new ModManager(TestSupport.tempDir("fxappr"));
        am.installZip(zip(sampleFiles()), base);
        am.setApprovalRequired(true);
        check(!am.enable("com.example.bronze", base).ok, "unapproved mod cannot be enabled when approval is required");
        am.setApproved("com.example.bronze", true);
        check(am.enable("com.example.bronze", base).ok, "approved mod can be enabled");

        System.out.println("[owner/admin/config]");
        File od = TestSupport.tempDir("fxowner");
        String keyDir = od.getPath() + "/keys";
        tool("genkey", keyDir);
        String pub = TestSupport.read(keyDir + "/owner_public.x509.b64").trim();
        String priv = keyDir + "/owner_private.pk8.b64";
        long nowSec = System.currentTimeMillis() / 1000;
        AtomicLong clock = new AtomicLong(System.currentTimeMillis());
        String token = tool("token", priv, "FxplayzOfficial", "1");
        OwnerSession os = new OwnerSession(pub, new File(od, "owner_state.json"), clock::get);
        check(os.authorize("SomeoneElse", token) != null && !os.isOwner(), "valid token refused for a different account name");
        check(os.authorize("fxplayzofficial", token) != null && !os.isOwner(), "username match is exact (case-sensitive)");
        check(os.authorize("FxplayzOfficial", null) != null && !os.isOwner(), "no token = no owner rights");
        check(os.authorize("FxplayzOfficial", "AAAA.BBBB") != null && !os.isOwner(), "forged token refused");
        String tampered = token.substring(0, token.indexOf('.') - 2) + "AA" + token.substring(token.indexOf('.'));
        check(os.authorize("FxplayzOfficial", tampered) != null && !os.isOwner(), "tampered payload refused");
        String wrongSub = tool("token", priv, "NotTheOwner", "1");
        check(os.authorize("FxplayzOfficial", wrongSub) != null && !os.isOwner(), "token for another subject refused");
        OwnerSession noKey = new OwnerSession("", null, clock::get);
        check(noKey.authorize("FxplayzOfficial", token) != null, "owner tools off when no key configured");
        File od2 = TestSupport.tempDir("fxowner2");
        tool("genkey", od2.getPath());
        OwnerSession otherKey = new OwnerSession(TestSupport.read(od2.getPath() + "/owner_public.x509.b64").trim(), null, clock::get);
        check(otherKey.authorize("FxplayzOfficial", token) != null, "token signed by a different key refused");
        check(os.authorize("FxplayzOfficial", token) == null && os.isOwner(), "exact username + valid signed token = owner");
        clock.addAndGet(2 * 3600_000L);
        check(!os.isOwner(), "owner session expires with the token");
        clock.addAndGet(-2 * 3600_000L);

        AppConfig cfgDev = new AppConfig("dev", pub, "", "test-server");
        AppConfig cfgProd = new AppConfig("prod", pub, "", "test-server");
        final boolean[] maint = {false};
        final String[] announced = {null};
        Factory hostFactory = new Factory(base, 40, 40, 1);
        AdminConsole.Host host = new AdminConsole.Host() {
            public Factory factory() { return hostFactory; }
            public GameData baseData() { return base; }
            public ModManager mods() { return mm; }
            public String playerName() { return "FxplayzOfficial"; }
            public boolean maintenance() { return maint[0]; }
            public void setMaintenance(boolean on) { maint[0] = on; }
            public void announce(String t) { announced[0] = t; }
            public String reloadConfig() { return "reloaded"; }
            public String rollbackConfig() { return "rolled back"; }
            public String healthReport() { return "healthy"; }
        };
        File auditFile = new File(od, "audit.jsonl");
        OwnerSession os2 = new OwnerSession(pub, new File(od, "owner_state2.json"), clock::get);
        AuditLog audit = new AuditLog(auditFile, "test-server", "dev", clock::get);
        AdminConsole con = new AdminConsole(os2, audit, cfgDev, host, clock::get);
        check(!con.execute("status").ok, "commands refused before owner authorization");
        os2.authorize("FxplayzOfficial", tool("token", priv, "FxplayzOfficial", "1"));
        check(con.execute("help").ok && con.execute("status").text.contains("env=dev"), "help/status work for owner");
        check(!con.execute("rm -rf /").ok && !con.execute("shell ls").ok && !con.execute("exec id").ok, "arbitrary/OS commands are not in the allowlist");
        check(!con.execute("announce <script>").ok && !con.execute("grant_test money 999999999").ok, "arguments validated");
        check(con.execute("announce Server restart soon").ok && "Server restart soon".equals(announced[0]), "announce works");
        long moneyBefore = hostFactory.money;
        check(con.execute("grant_test money 500").ok && hostFactory.money == moneyBefore + 500, "grant_test works in dev");
        AdminConsole prodCon = new AdminConsole(os2, audit, cfgProd, host, clock::get);
        check(!prodCon.execute("grant_test money 500").ok, "grant_test blocked in production");
        clock.addAndGet(61_000);
        AdminConsole.Result pend = con.execute("maintenance on");
        check(pend.ok && pend.text.contains("confirm ") && !maint[0], "destructive command needs confirmation first");
        check(!con.execute("confirm ZZZZZZ").ok && !maint[0], "wrong confirmation code refused");
        con.execute("maintenance on");
        String code = con.execute("maintenance on").text.replaceAll(".*confirm ([A-Z0-9]{6}).*", "$1");
        check(con.execute("confirm " + code).ok && maint[0], "correct confirmation executes");
        clock.addAndGet(61_000);
        check(con.execute("maintenance off").ok && !maint[0], "maintenance off needs no confirmation");
        check(con.execute("mods list").ok, "mod moderation command works");
        check(con.execute("inspect factory").text.contains("ledgerBalance=0"), "inspect shows ledger balance");
        for (int i = 0; i < 15; i++) con.execute("help");
        check(!con.execute("help").ok && con.execute("help").text.contains("Slow down"), "rate limit blocks command floods");
        clock.addAndGet(61_000);
        String auditText = String.join("\n", audit.tail(100));
        check(auditText.contains("FxplayzOfficial") && auditText.contains("test-server") && auditText.contains("announce") && auditText.contains("denied"), "audit log records actor, server, command, denials");
        String sessionToken = tool("token", priv, "FxplayzOfficial", "1");
        os2.authorize("FxplayzOfficial", sessionToken);
        con.execute("emergency_disable");
        String c2 = con.execute("emergency_disable").text.replaceAll(".*confirm ([A-Z0-9]{6}).*", "$1");
        check(con.execute("confirm " + c2).ok && !os2.isOwner(), "emergency disable ends owner session");
        String fresh = tool("token", priv, "FxplayzOfficial", "1");
        check(new OwnerSession(pub, new File(od, "owner_state2.json"), clock::get).authorize("FxplayzOfficial", fresh) != null, "emergency disable persists across restart (even fresh tokens refused)");
        OwnerSession re = new OwnerSession(pub, new File(od, "owner_state2.json"), clock::get);
        re.reenable();
        check(re.authorize("FxplayzOfficial", sessionToken) != null && !re.isOwner(), "revoked token id stays revoked after re-enable");
        check(re.authorize("FxplayzOfficial", tool("token", priv, "FxplayzOfficial", "1")) == null, "new token works after re-enable");

        // signed config bundles
        File cd = TestSupport.tempDir("fxcfg");
        ConfigUpdater cu = new ConfigUpdater(cd, pub);
        File payload = new File(cd, "p1.json");
        Files.write(payload.toPath(), "{\"items\":{\"iron_plate\":{\"sellPrice\":9}},\"machines\":{\"miner\":{\"cycleTicks\":10}}}".getBytes(StandardCharsets.UTF_8));
        String b1 = tool("bundle", priv, "1", payload.getPath(), "Balance pass 1");
        check(cu.apply(b1).ok && cu.version() == 1, "signed bundle applies");
        GameData over = cu.overlay(base);
        check(over.items.get("iron_plate").sellPrice == 9 && over.machines.get("miner").cycleTicks == 10, "overrides hot-applied");
        check(base.items.get("iron_plate").sellPrice == 4 && base.machines.get("miner").cycleTicks == 20, "base data not mutated");
        check(!cu.apply(b1).ok, "same/older version refused (no replay or downgrade)");
        check(!cu.apply(b1.replace("\"version\":1", "\"version\":2")).ok, "tampered bundle refused");
        check(!cu.apply(b1.replaceAll("\"sig\":\"[^\"]*\"", "\"sig\":\"AAAA\"").replace("\"version\":1", "\"version\":3")).ok, "bad signature refused");
        Files.write(payload.toPath(), "{\"items\":{\"iron_plate\":{\"sellPrice\":99999999}}}".getBytes(StandardCharsets.UTF_8));
        check(!cu.apply(tool("bundle", priv, "5", payload.getPath(), "bad range")).ok, "signed but out-of-range values refused");
        Files.write(payload.toPath(), "{\"code\":\"System.exit(0)\"}".getBytes(StandardCharsets.UTF_8));
        check(!cu.apply(tool("bundle", priv, "6", payload.getPath(), "unknown key")).ok, "signed but unknown keys refused");
        Files.write(payload.toPath(), "{\"items\":{\"iron_plate\":{\"sellPrice\":12}}}".getBytes(StandardCharsets.UTF_8));
        check(cu.apply(tool("bundle", priv, "2", payload.getPath(), "Balance pass 2")).ok && cu.overlay(base).items.get("iron_plate").sellPrice == 12, "second bundle applies");
        check(cu.rollback().ok && cu.version() == 1 && cu.overlay(base).items.get("iron_plate").sellPrice == 9, "rollback restores last known-good bundle");
        check(new ConfigUpdater(cd, pub).version() == 1, "config persists across restart");
        check(!new ConfigUpdater(TestSupport.tempDir("fxcfg2"), "").apply(b1).ok, "updates disabled without release key");
    }
}
