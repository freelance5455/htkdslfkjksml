package fx.historical.app;

public final class RunAllTests {
    public static void main(String[] args) throws Exception {
        SimTests.run();
        try {
            Class.forName("fx.historical.app.PlatformTests").getMethod("run").invoke(null);
        } catch (ClassNotFoundException ignored) { }
        System.out.println("\nRESULT: " + TestSupport.passed + " passed, " + TestSupport.failed + " failed");
        System.exit(TestSupport.failed == 0 ? 0 : 1);
    }
}
