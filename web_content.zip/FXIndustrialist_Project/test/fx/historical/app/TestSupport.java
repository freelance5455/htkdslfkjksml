package fx.historical.app;

import fx.historical.app.core.GameData;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/** Tiny dependency-free test helpers (works on any JVM; no JUnit needed). */
public final class TestSupport {
    public static int passed, failed;

    public static void check(boolean cond, String name) {
        if (cond) { passed++; System.out.println("  PASS " + name); }
        else { failed++; System.out.println("  FAIL " + name); }
    }

    public static String read(String path) throws Exception {
        return new String(Files.readAllBytes(new File(path).toPath()), StandardCharsets.UTF_8);
    }

    /** Project root is the working directory when tests run (see README). */
    public static GameData baseData() throws Exception {
        return GameData.load(read("assets/data/items.json"), read("assets/data/machines.json"),
                read("assets/data/recipes.json"), read("assets/data/techs.json"));
    }

    public static File tempDir(String name) throws Exception {
        return Files.createTempDirectory(name).toFile();
    }
}
