#!/bin/sh
# Runs the automated tests on any machine with JDK 17+ (computer, cloud shell, CI). Not runnable inside the Android app.
# Usage (from the project root):  sh tools/run_tests.sh
set -e
OUT="${TMPDIR:-/tmp}/fx_test_out"
rm -rf "$OUT"; mkdir -p "$OUT"
javac -d "$OUT" $(find src/fx/historical/app/core src/fx/historical/app/sim src/fx/historical/app/auth src/fx/historical/app/mod src/fx/historical/app/admin test -name '*.java')
java -cp "$OUT" fx.historical.app.RunAllTests
