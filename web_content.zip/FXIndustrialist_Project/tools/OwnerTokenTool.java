// Owner-side tool. Run on a trusted machine or cloud shell with JDK 11+ (NOT inside the app):
//   java OwnerTokenTool.java genkey  <outDir>
//   java OwnerTokenTool.java token   <owner_private.pk8.b64> FxplayzOfficial <hours 1-24>
//   java OwnerTokenTool.java bundle  <owner_private.pk8.b64> <version> <payload.json> "<release notes>"
// The PRIVATE key never goes into the app, the ZIP, Git, or chat. Only the PUBLIC key goes into app_config.json.
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.*;
import java.security.spec.*;
import java.util.Base64;

public class OwnerTokenTool {
    public static void main(String[] a) throws Exception {
        if (a.length < 1) { usage(); return; }
        switch (a[0]) {
            case "genkey": {
                KeyPairGenerator g = KeyPairGenerator.getInstance("EC");
                g.initialize(new ECGenParameterSpec("secp256r1"));
                KeyPair kp = g.generateKeyPair();
                Path dir = Paths.get(a.length > 1 ? a[1] : ".");
                Files.createDirectories(dir);
                Files.write(dir.resolve("owner_private.pk8.b64"), Base64.getEncoder().encode(kp.getPrivate().getEncoded()));
                Files.write(dir.resolve("owner_public.x509.b64"), Base64.getEncoder().encode(kp.getPublic().getEncoded()));
                System.out.println("Wrote owner_private.pk8.b64 (KEEP SECRET) and owner_public.x509.b64 (put in app_config.json owner_public_key).");
                break;
            }
            case "token": {
                PrivateKey k = loadKey(a[1]);
                long hours = Math.max(1, Math.min(24, Long.parseLong(a[3])));
                long now = System.currentTimeMillis() / 1000;
                byte[] id = new byte[12];
                new SecureRandom().nextBytes(id);
                String payload = "{\"sub\":\"" + a[2] + "\",\"scope\":\"owner\",\"iat\":" + now + ",\"exp\":" + (now + hours * 3600)
                        + ",\"jti\":\"" + Base64.getUrlEncoder().withoutPadding().encodeToString(id) + "\"}";
                byte[] p = payload.getBytes(StandardCharsets.UTF_8);
                System.out.println(Base64.getUrlEncoder().withoutPadding().encodeToString(p) + "." + sign(k, p));
                break;
            }
            case "bundle": {
                PrivateKey k = loadKey(a[1]);
                int version = Integer.parseInt(a[2]);
                String payload = new String(Files.readAllBytes(Paths.get(a[3])), StandardCharsets.UTF_8).trim();
                String p64 = Base64.getEncoder().encodeToString(payload.getBytes(StandardCharsets.UTF_8));
                String signed = "fxcfg1\n" + version + "\nnone\n" + p64;
                String notes = (a.length > 4 ? a[4] : "").replace("\\", "\\\\").replace("\"", "\\\"");
                System.out.println("{\"version\":" + version + ",\"notes\":\"" + notes + "\",\"requires\":\"none\",\"payloadB64\":\"" + p64
                        + "\",\"sig\":\"" + sign(k, signed.getBytes(StandardCharsets.UTF_8)) + "\"}");
                break;
            }
            default: usage();
        }
    }

    static PrivateKey loadKey(String file) throws Exception {
        byte[] der = Base64.getDecoder().decode(new String(Files.readAllBytes(Paths.get(file)), StandardCharsets.UTF_8).trim());
        return KeyFactory.getInstance("EC").generatePrivate(new PKCS8EncodedKeySpec(der));
    }

    static String sign(PrivateKey k, byte[] data) throws Exception {
        Signature s = Signature.getInstance("SHA256withECDSA");
        s.initSign(k);
        s.update(data);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(s.sign());
    }

    static void usage() {
        System.out.println("usage: genkey <dir> | token <privKeyFile> <username> <hours> | bundle <privKeyFile> <version> <payload.json> [notes]");
    }
}
