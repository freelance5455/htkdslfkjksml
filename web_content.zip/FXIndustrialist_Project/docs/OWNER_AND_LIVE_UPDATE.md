# Owner console and live updates

## Owner setup (once, on a trusted machine or free cloud shell with JDK 11+)
1. `java tools/OwnerTokenTool.java genkey keys/` creates `owner_private.pk8.b64` (SECRET, never share, never put in the app, ZIP, Git or chat) and `owner_public.x509.b64`.
2. Put the public key text into `assets/app_config.json` as `owner_public_key` (and optionally `release_public_key`). Rebuild the app.
3. For each session: `java tools/OwnerTokenTool.java token keys/owner_private.pk8.b64 FxplayzOfficial 1` (1-24 hours).
4. In the app, sign in as the account named exactly `FxplayzOfficial`, open Owner console, paste the token.
Owner rights need ALL of: exact username, valid signature, unexpired short-lived token, not revoked, owner tools not emergency-disabled. A name, a setting or a local variable alone grants nothing.

## Commands (allowlist; anything else is refused)
help, status, health, announce, maintenance on|off, inspect factory|player, grant_test (dev environment only), reload_config, config_rollback, mods list|approve|unapprove|require_approval, audit, emergency_disable, confirm.
Global/destructive ones return a 6-character code; `confirm CODE` within 30 s executes. 12 commands/minute max. Every attempt (including denials) goes to the audit log with actor, server id, environment, command, result.
Emergency disable revokes the token and locks owner tools until the owner re-enables them in Settings with the account password.
No command runs OS commands, reads files, touches other apps or games, or handles credentials.

## Not available (needs a server)
kick, grant/revoke roles, publish release, release rollback. They are absent rather than faked.

## Live update pipeline in this offline build
1. Edit a payload JSON, e.g. `{"items":{"iron_plate":{"sellPrice":6}},"machines":{"miner":{"cycleTicks":18}}}`.
2. Sign: `java tools/OwnerTokenTool.java bundle keys/owner_private.pk8.b64 2 payload.json "Balance pass"`.
3. Deliver the bundle file to the phone and import it in Settings -> Import update bundle, or have the owner run `reload_config`.
4. The app verifies signature, version (must increase), `requires:"none"`, whitelist and numeric ranges. Then it applies the values to the running game and shows the notes in Version notes.
5. `config_rollback` restores the last known-good bundle. Saves are never modified by a config change.

Hot-reloadable: item sell prices; machine cost, power, cycle time.
Needs a new app build: any code, new machine behaviours, save-format or protocol changes. Bundles declaring that (`requires` other than `none`) are refused, never half-applied.
A real automatic push to every device needs a backend (signed update notifications to servers, version registry); not part of this build.
