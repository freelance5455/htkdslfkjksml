# ADR-001: Architecture of FX Industrialist (v1.0.0)

## Assumptions
- The developer works from an Android phone only (Code Studio). No PC, no Android Studio, no hosted build service is available.
- Package: `fx.historical.app`. Original code and art only.
- No backend, domain, or paid service exists yet.

## Options compared
| Option | Fits phone-only? | Verdict |
|---|---|---|
| Unity / Godot game + separate app shell | Engine editors and export need a PC or cloud build | Rejected for now: cannot be built or edited on the phone |
| Kotlin + Jetpack Compose, Gradle | Needs Gradle; it did not work in Code Studio on earlier projects | Rejected for the phone workflow |
| **Native Java + custom Canvas view, flat Code Studio layout** | Yes: plain source files, no Gradle, no libraries | **Chosen** |

## Decisions
- **Engine/language:** native Java 8 syntax, Android framework only, one custom `View` renders the factory.
- **Simulation:** pure Java in `sim/` with no Android imports, fixed 10 ticks/s, integer math, deterministic. This is why it is testable on any JVM and could later run on a server unchanged.
- **Data-driven content:** items, machines, recipes, techs in `assets/data/*.json`; mods and signed config bundles change data, never code.
- **Build pipeline:** Code Studio builds the flat layout. Optional later: Gradle + GitHub Actions (needs a phone-friendly repo setup, not included).
- **Backend/database/auth provider:** none in 1.0. Accounts are device-local (PBKDF2). A hosted provider (for example Firebase Auth) would replace `LocalAuth` behind the same calls. Costs: Firebase Auth free tier covers small projects; a game server/database would be extra (estimate before choosing, not guessed here).
- **Multiplayer/network model (future):** server-authoritative. `Factory.place/remove/rotate/research` are already the only mutation points and validate everything, so a server can call them and clients send only intents.
- **Mod packaging and sandbox:** ZIP of JSON files only; no code, no scripts, no native libraries. Validated before install, re-validated at every load, merged into a copy of the game data. See MOD_AUTHORING_GUIDE.md.
- **Live updates and rollback:** signed config bundles (ECDSA P-256), monotonic versions, strict whitelist and ranges, last-known-good rollback. See OWNER_AND_LIVE_UPDATE.md.

## Data flow
```mermaid
flowchart LR
  A[assets/data JSON] --> B[GameData base]
  C[signed config bundle] -->|verify + whitelist| D[overlay copy]
  B --> D
  E[enabled mods] -->|validate + namespace| F[effective GameData]
  D --> F
  F --> G[Factory simulation]
  G --> H[GameView draws]
  G --> I[SaveManager: tmp, fsync, backup, checksum]
```

## Owner authorization
```mermaid
sequenceDiagram
  participant O as Owner (trusted machine)
  participant App
  O->>O: OwnerTokenTool genkey (private key stays here)
  O->>App: public key in app_config.json
  O->>O: OwnerTokenTool token FxplayzOfficial 1
  O->>App: paste token while signed in as FxplayzOfficial
  App->>App: exact username + signature + expiry + not revoked + not disabled
  App->>App: every command: allowlist, validation, rate limit, confirm, audit
```

## What needs a PC or cloud shell
- Generating the owner key pair and signing tokens/bundles (needs a JDK; a free cloud shell works from a phone browser).
- Running the automated tests.
- Anything involving a backend, multiplayer, or a Play Store release signing flow.

## Network messages and data models
No network messages exist in 1.0 (the app has no INTERNET permission). Save format: `format:1` JSON with buildings, stats, techs, wrapped with a SHA-256 checksum. Mod manifest and bundle formats are documented in the two other docs.

## Known limitations
- On-device owner verification cannot stop a modified app on a rooted device; for multiplayer the same token must be verified by a server.
- Fixed 48x48 plot. No expansion yet.
- UI layer unverified on real devices.
