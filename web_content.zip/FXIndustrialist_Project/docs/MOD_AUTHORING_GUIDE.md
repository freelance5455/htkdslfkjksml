# Mod authoring guide

A mod is a ZIP with JSON files in the top level (no folders). See `mods/sample_mod`.

## manifest.json
| Field | Rule |
|---|---|
| id | reverse-DNS, lowercase, e.g. `com.you.mymod` |
| namespace | 2-16 chars `a-z0-9_`; every id you add must start with `namespace:` |
| name, author | 1-48 chars; description up to 280 |
| version | `1.2.3` |
| minGameVersion / maxGameVersion | game is `1.0.0`; max is optional |
| dependencies | `{ "other.mod.id": "1.0.0" }` (minimum version; dependency must be enabled) |
| permissions | any of `content.items`, `content.recipes`, `content.machines`, `content.localization` |
| entries | `{ "items": "items.json", "machines": "...", "recipes": "...", "localization": "..." }`; each needs its permission |

## Content
- items: `{"items":[{"id":"ns:thing","name":"Thing","sellPrice":0-10000}]}`
- machines: `{"machines":[{"id":"ns:m","name":"M","kind":"PROCESSOR","cost":0-1000000,"power":-100..100,"cycleTicks":0-6000,"tech":""}]}`
  kinds: MINER, CONVEYOR, SPLITTER, PROCESSOR, SELLER, GENERATOR. Positive power = uses power, negative = makes power.
- recipes: `{"recipes":[{"id":"ns:r","machine":"ns:m","inputs":{"iron_plate":2},"outputs":{"ns:thing":1},"ticks":1-6000}]}` (machine must be a PROCESSOR)
- localization: flat `{"key":"text"}`, up to 200 strings of 200 chars.

## Rejected automatically
Any file that is not `.json`; code or script files (`.dex .jar .so .js .lua .py .sh ...`); folders or `..` paths; more than 32 files, 512 KB per file, 2 MB total, 4 MB ZIP;
unknown permissions; ids outside your namespace or clashing with existing ids; numbers out of range; unknown item/machine/tech references.

## Safety model (honest wording)
This is not malware scanning. Mods are safe because the format cannot contain executable behaviour: the game only reads JSON numbers and names. A mod can still be unbalanced or silly, which is why the owner can require approval and players can disable, roll back, remove and report mods. Removing a mod never deletes the save; its buildings are dropped on load and a backup of the save is kept.

## Versions, updates, rollback
Install a higher version of the same id to update; the previous version is kept for one-tap rollback. Mods start disabled.
