ROTA GAYRİMENKUL – ANDROID STUDIO PROJESİ

Bu klasör APK'nın kaynak projesidir. Bu çalışma ortamında Android SDK/Gradle bulunmadığı için burada doğrudan derlenmiş APK üretilemedi. Proje Android Studio ile APK'ya dönüştürülebilir.

APK oluşturma:
1. Bilgisayara Android Studio kurun.
2. Android Studio > Open ile bu klasörü açın (ROTA_GAYRIMENKUL_Android).
3. Gradle eşitlemesi tamamlanınca Build > Build Bundle(s) / APK(s) > Build APK(s) seçin.
4. APK genellikle app/build/outputs/apk/debug/app-debug.apk konumunda oluşur.
5. APK'yı Android telefona gönderip kurun. Telefon kurulum izni isteyebilir.

Özellikler:
- İlan bilgileri ve medya WebView/IndexedDB içinde cihazda tutulur.
- Fotoğraf/video seçimi çoklu dosya seçimini destekler.
- Yedekleme JSON dosyasını İndirilenler klasörüne kaydeder.
- Harita ve harici web kütüphaneleri için internet bağlantısı gerekir.

ÖNEMLİ:
- Veriler bu uygulamanın kendi depolamasında tutulur; uygulamayı kaldırmak verileri silebilir. Düzenli olarak Yedekle düğmesini kullanın.
- Büyük videolar telefonun depolama alanını tüketebilir.
- Bu proje henüz Android Studio'da derlenip cihazda test edilmedi; derleme ve cihaz testi gereklidir.
