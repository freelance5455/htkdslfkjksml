// Arranque de la aplicación, enrutado por módulos, navegación y gestos.
import { Store } from './core/store.js';
import { esc, $, $$, setCurrency, toast, openModal, modalOpen, debounce, closeThenNavigate } from './ui/dom.js';
import { initForms } from './ui/forms.js';
import { views, initViews, setRerender } from './ui/views.js';
import { attachSwipe } from './ui/gestures.js';

const VERSION = '1.0.0';

export const ROUTES = [
  { id: 'dashboard', title: 'Inicio', icon: '◧' },
  { id: 'ventas', title: 'Ventas', icon: '🧾' },
  { id: 'compras', title: 'Compras', icon: '📦' },
  { id: 'inventario', title: 'Inventario', icon: '▤' },
  { id: 'productos', title: 'Productos y estilos', short: 'Productos', icon: '🩴' },
  { id: 'estadisticas', title: 'Estadísticas', icon: '📈' },
  { id: 'gastos', title: 'Gastos', icon: '💸' },
  { id: 'proveedores', title: 'Proveedores', icon: '🚚' },
  { id: 'historial', title: 'Historial', icon: '🕘' },
  { id: 'informes', title: 'Informes y copias', short: 'Informes', icon: '⇩' },
  { id: 'config', title: 'Configuración', short: 'Ajustes', icon: '⚙' },
];
const BOTTOM = ['dashboard', 'ventas', 'inventario', 'productos'];

const app = { version: VERSION, store: null, settings: null, route: 'dashboard' };
window.__chinela = app; // acceso para pruebas automáticas

function currentRoute() {
  const id = (location.hash.match(/^#\/([a-z]+)/) || [])[1];
  return ROUTES.some((r) => r.id === id) ? id : 'dashboard';
}

function applyTheme(theme) {
  const root = document.documentElement;
  if (theme === 'light' || theme === 'dark') root.dataset.theme = theme;
  else delete root.dataset.theme;
  try { localStorage.setItem('chinelastock.theme', theme); } catch { /* sin almacenamiento */ }
  const dark = theme === 'dark' || (theme !== 'light' && matchMedia('(prefers-color-scheme: dark)').matches);
  $('meta[name=theme-color]')?.setAttribute('content', dark ? '#14171c' : '#f6f4ef');
}
app.applyTheme = applyTheme;

function buildNav() {
  $('#sidenav').innerHTML = `
    <div class="brand"><span class="logo" aria-hidden="true">C</span><span data-shop>${esc(app.settings.shopName)}</span></div>
    <nav aria-label="Módulos">${ROUTES.map((r) => `<a href="#/${r.id}" data-route="${r.id}"><span class="ico" aria-hidden="true">${r.icon}</span>${esc(r.title)}</a>`).join('')}</nav>`;
  $('#bottomnav').innerHTML = `${BOTTOM.map((id) => {
    const r = ROUTES.find((x) => x.id === id);
    return `<a href="#/${id}" data-route="${id}"><span class="ico" aria-hidden="true">${r.icon}</span><span>${esc(r.short || r.title)}</span></a>`;
  }).join('')}<button type="button" data-more><span class="ico" aria-hidden="true">☰</span><span>Más</span></button>`;
  $('#bottomnav [data-more]').onclick = openMoreMenu;
}

function openMoreMenu() {
  const m = openModal({
    title: 'Más secciones', size: 'sm',
    render(el) {
      el.innerHTML = `<nav class="menu grid-menu">${ROUTES.filter((r) => !BOTTOM.includes(r.id)).map((r) => `<a class="btn" href="#/${r.id}" data-route="${r.id}"><span aria-hidden="true">${r.icon}</span> ${esc(r.title)}</a>`).join('')}</nav>`;
      el.onclick = (e) => {
        const a = e.target.closest('a[href]');
        if (!a) return;
        e.preventDefault();
        closeThenNavigate(m, a.getAttribute('href'));
      };
    },
  });
}

function updateChrome() {
  const idx = ROUTES.findIndex((r) => r.id === app.route);
  const r = ROUTES[idx];
  document.title = `${r.title} · ${app.settings.shopName}`;
  $('#title').textContent = r.title;
  const prev = ROUTES[idx - 1];
  const next = ROUTES[idx + 1];
  $('#nav-prev').hidden = !prev;
  $('#nav-next').hidden = !next;
  if (prev) { $('#nav-prev').href = `#/${prev.id}`; $('#nav-prev').title = prev.title; $('#nav-prev').setAttribute('aria-label', `Ir a ${prev.title}`); }
  if (next) { $('#nav-next').href = `#/${next.id}`; $('#nav-next').title = next.title; $('#nav-next').setAttribute('aria-label', `Ir a ${next.title}`); }
  $('#dots').innerHTML = ROUTES.map((x, i) => `<i class="${i === idx ? 'on' : ''}"></i>`).join('');
  $$('[data-route]').forEach((a) => a.classList.toggle('active', a.dataset.route === app.route));
  $$('[data-route]').forEach((a) => { if (a.dataset.route === app.route) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); });
  const inBottom = BOTTOM.includes(app.route);
  $('#bottomnav [data-more]').classList.toggle('active', !inBottom);
}

let renderSeq = 0;
async function render({ animate = null } = {}) {
  const seq = ++renderSeq;
  const view = $('#view');
  const fn = views[app.route];
  // Conserva el foco y el cursor de los campos de búsqueda al refrescar
  const ae = document.activeElement;
  const focus = ae && view.contains(ae) && ae.name ? { name: ae.name, start: ae.selectionStart, end: ae.selectionEnd } : null;
  const scroll = window.scrollY;
  const tmp = document.createElement('div');
  tmp.className = 'view-inner';
  try {
    await fn(tmp);
  } catch (err) {
    console.error(err);
    tmp.innerHTML = `<div class="banner err">No se pudo cargar esta sección: ${esc(err.message)}</div>`;
  }
  if (seq !== renderSeq) return; // otra renderización más reciente ganó
  view.replaceChildren(tmp);
  view.dataset.route = app.route;
  if (animate) {
    tmp.classList.add(animate === 'next' ? 'enter-next' : 'enter-prev');
    window.scrollTo(0, 0);
  } else {
    window.scrollTo(0, scroll);
  }
  if (focus) {
    const f = tmp.querySelector(`[name="${CSS.escape(focus.name)}"]`);
    if (f) { f.focus({ preventScroll: true }); try { f.setSelectionRange(focus.start, focus.end); } catch { /* no aplica */ } }
  }
  view.setAttribute('aria-busy', 'false');
}
const renderSoon = debounce(() => render(), 160);
setRerender(() => render(), renderSoon);

let lastIdx = 0;
function onRoute() {
  const r = currentRoute();
  const idx = ROUTES.findIndex((x) => x.id === r);
  const dir = r === app.route ? null : idx > lastIdx ? 'next' : 'prev';
  app.route = r;
  lastIdx = idx;
  updateChrome();
  render({ animate: dir });
}

function go(dir) {
  const idx = ROUTES.findIndex((r) => r.id === app.route);
  const n = ROUTES[idx + (dir === 'next' ? 1 : -1)];
  if (n) location.hash = `#/${n.id}`;
}
app.go = go;

async function boot() {
  try {
    app.store = await Store.open();
  } catch (err) {
    $('#view').innerHTML = `<div class="banner err"><b>No se puede abrir la base de datos.</b><br>${esc(err.message)}<br>Si usas el modo incógnito o tienes bloqueado el almacenamiento del sitio, desactívalo.</div>`;
    return;
  }
  app.settings = await app.store.getSettings();
  setCurrency(app.settings.currency);
  applyTheme(app.settings.theme);
  initForms(app);
  initViews(app);
  buildNav();
  app.store.addEventListener('change', async (e) => {
    if (e.detail.stores.includes('settings')) {
      app.settings = await app.store.getSettings();
      setCurrency(app.settings.currency);
      applyTheme(app.settings.theme);
      $('[data-shop]').textContent = app.settings.shopName;
    }
    if (e.detail.remote && e.detail.stores.includes('settings')) toast('Datos actualizados desde otra pestaña');
    renderSoon();
  });
  window.addEventListener('hashchange', onRoute);
  attachSwipe($('#main'), { onSwipe: go, isEnabled: () => !modalOpen() });
  document.addEventListener('keydown', (e) => {
    if (modalOpen() || e.target.closest('input, textarea, select')) return;
    if (e.altKey && e.key === 'ArrowRight') go('next');
    if (e.altKey && e.key === 'ArrowLeft') go('prev');
  });
  matchMedia('(prefers-color-scheme: dark)').addEventListener?.('change', () => applyTheme(app.settings.theme));
  onRoute();
  // Pedir almacenamiento persistente para que el navegador no borre los datos
  try { if (navigator.storage?.persist && !(await navigator.storage.persisted())) await navigator.storage.persist(); } catch { /* no disponible */ }
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
    navigator.serviceWorker.register('./sw.js').catch((err) => console.warn('Service worker no registrado', err));
  }
  document.body.classList.add('ready');
}

boot();
