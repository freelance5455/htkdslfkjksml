// Utilidades de interfaz: escape de HTML, modales, avisos, descargas.
import { formatMoney } from '../core/money.js';

export function esc(v) {
  return String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

let currency = 'EUR';
export function setCurrency(c) { currency = c || 'EUR'; }
export const money = (c) => formatMoney(c, currency);

export function fmtDate(iso) {
  if (!iso) return '';
  const [y, m, d] = iso.slice(0, 10).split('-');
  return `${d}/${m}/${y}`;
}
export function fmtDateTime(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  return d.toLocaleString('es-ES', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}
export function pct(bp) {
  if (bp == null) return '—';
  return `${(bp / 100).toLocaleString('es-ES', { maximumFractionDigits: 1 })} %`;
}

export function debounce(fn, ms = 200) {
  let t;
  return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}

// ---------- avisos ----------
export function toast(message, type = 'ok') {
  const root = $('#toasts');
  const el = document.createElement('div');
  el.className = `toast toast-${type}`;
  el.setAttribute('role', type === 'error' ? 'alert' : 'status');
  el.textContent = message;
  root.appendChild(el);
  setTimeout(() => el.classList.add('out'), type === 'error' ? 5000 : 2800);
  setTimeout(() => el.remove(), type === 'error' ? 5400 : 3200);
}

// ---------- modales con control de cambios sin guardar ----------
const stack = [];
let ignorePop = 0;
const afterPops = [];

export function hasDirtyModal() { return stack.some((m) => m.dirty); }
export function modalOpen() { return stack.length > 0; }

/**
 * Abre un modal. `render(el, ctrl)` rellena el contenido.
 * ctrl.setDirty(true) activa la confirmación al salir sin guardar.
 */
export function openModal({ title, size = 'md', render, onClose = null, closable = true }) {
  const root = $('#modals');
  const wrap = document.createElement('div');
  wrap.className = 'modal-backdrop';
  wrap.innerHTML = `
    <section class="modal modal-${size}" role="dialog" aria-modal="true" aria-label="${esc(title)}">
      <header class="modal-head">
        <h2>${esc(title)}</h2>
        ${closable ? '<button type="button" class="icon-btn" data-close aria-label="Cerrar">✕</button>' : ''}
      </header>
      <div class="modal-body"></div>
    </section>`;
  root.appendChild(wrap);
  const ctrl = {
    el: wrap.querySelector('.modal-body'),
    root: wrap,
    dirty: false,
    listeners: [],
    setDirty(v = true) { ctrl.dirty = !!v; },
    async requestClose() {
      if (ctrl.dirty) {
        const ok = await confirmDialog({ title: 'Cambios sin guardar', message: 'Si sales ahora se perderán los datos introducidos en este formulario.', okText: 'Salir sin guardar', cancelText: 'Seguir editando', danger: true });
        if (!ok) return false;
      }
      ctrl.close();
      return true;
    },
    close() {
      const i = stack.indexOf(ctrl);
      if (i === -1) return;
      stack.splice(i, 1);
      wrap.remove();
      ctrl.listeners.forEach((f) => f());
      onClose?.();
      if (ctrl.pushed) {
        ctrl.pushed = false;
        ignorePop++;
        history.back();
      }
      const prev = stack[stack.length - 1];
      (prev?.root.querySelector('[autofocus], input, button') || document.body).focus?.();
    },
    onDispose(f) { ctrl.listeners.push(f); },
  };
  ctrl.id = `m${Date.now()}${Math.random().toString(36).slice(2, 6)}`;
  stack.push(ctrl);
  // botón «atrás» del móvil cierra el modal. Si aún hay un «atrás» pendiente
  // de un modal recién cerrado, se espera a que termine para no perder la entrada.
  ctrl.pushed = false;
  const doPush = () => {
    if (!stack.includes(ctrl)) return;
    try {
      history.pushState({ modal: ctrl.id }, '', location.href);
      ctrl.pushed = true;
    } catch { ctrl.pushed = false; }
  };
  if (ignorePop > 0) afterPops.push(doPush); else doPush();
  wrap.addEventListener('click', (e) => {
    if (e.target.closest('[data-close]') && closable) ctrl.requestClose();
  });
  wrap.addEventListener('mousedown', (e) => {
    if (e.target === wrap && closable) wrap.dataset.downOnBackdrop = '1';
  });
  wrap.addEventListener('mouseup', (e) => {
    if (e.target === wrap && wrap.dataset.downOnBackdrop && closable) ctrl.requestClose();
    delete wrap.dataset.downOnBackdrop;
  });
  render(ctrl.el, ctrl);
  const af = ctrl.el.querySelector('[autofocus]');
  if (af && matchMedia('(pointer: fine)').matches) af.focus();
  return ctrl;
}

window.addEventListener('popstate', async () => {
  if (ignorePop > 0) {
    ignorePop--;
    if (ignorePop === 0) afterPops.splice(0).forEach((f) => f());
    return;
  }
  const top = stack[stack.length - 1];
  if (!top) return;
  top.pushed = false; // la entrada del historial ya se consumió
  const closed = await top.requestClose();
  if (!closed && stack.includes(top)) {
    // Volver a crear la entrada del historial cuando termine el «atrás» del diálogo de confirmación
    const repush = () => {
      if (!stack.includes(top) || top.pushed) return;
      history.pushState({ modal: top.id }, '', location.href);
      top.pushed = true;
    };
    if (ignorePop > 0) afterPops.push(repush); else repush();
  }
});

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && stack.length) {
    const top = stack[stack.length - 1];
    if (top.root.querySelector('[data-close]')) {
      e.preventDefault();
      top.requestClose();
    }
  }
});

window.addEventListener('beforeunload', (e) => {
  if (hasDirtyModal()) {
    e.preventDefault();
    e.returnValue = '';
  }
});

/** Cierra un modal y navega cuando el navegador ha retirado su entrada del historial. */
export function closeThenNavigate(ctrl, hash) {
  const hadEntry = ctrl.pushed;
  let done = false;
  const nav = () => { if (done) return; done = true; location.hash = hash; };
  if (hadEntry) window.addEventListener('popstate', () => setTimeout(nav, 0), { once: true });
  ctrl.close();
  setTimeout(nav, hadEntry ? 500 : 0);
}

export function confirmDialog({ title = '¿Confirmar?', message = '', okText = 'Confirmar', cancelText = 'Cancelar', danger = false }) {
  return new Promise((resolve) => {
    let answered = false;
    const m = openModal({
      title, size: 'sm',
      onClose: () => { if (!answered) resolve(false); },
      render(el) {
        el.innerHTML = `<p class="confirm-msg">${esc(message)}</p>
          <div class="form-actions">
            <button type="button" class="btn" data-no>${esc(cancelText)}</button>
            <button type="button" class="btn ${danger ? 'btn-danger' : 'btn-primary'}" data-yes>${esc(okText)}</button>
          </div>`;
        el.querySelector('[data-no]').onclick = () => { answered = true; resolve(false); m.close(); };
        el.querySelector('[data-yes]').onclick = () => { answered = true; resolve(true); m.close(); };
        setTimeout(() => el.querySelector('[data-yes]').focus(), 0);
      },
    });
  });
}

export function download(filename, content, type = 'text/csv;charset=utf-8') {
  const blob = content instanceof Blob ? content : new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

/** Muestra un error de validación en un formulario sin borrar los datos introducidos. */
export function showFormError(form, err) {
  const box = form.querySelector('.form-error');
  $$('.invalid', form).forEach((x) => x.classList.remove('invalid'));
  if (!err) { if (box) { box.hidden = true; box.textContent = ''; } return; }
  const msg = err?.message || String(err);
  if (box) {
    box.hidden = false;
    box.textContent = msg;
    box.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  }
  if (err?.field) {
    const f = form.querySelector(`[name="${CSS.escape(err.field)}"]`);
    if (f) { f.classList.add('invalid'); f.focus({ preventScroll: true }); }
  }
  if (err?.name !== 'ValidationError') console.error(err);
}

/** Ejecuta una acción de guardado bloqueando los botones para evitar dobles pulsaciones. */
export async function busy(form, fn) {
  if (form.dataset.busy === '1') return undefined;
  form.dataset.busy = '1';
  const btns = $$('button', form);
  btns.forEach((b) => { b.dataset.wasDisabled = b.disabled ? '1' : ''; b.disabled = true; });
  try {
    return await fn();
  } finally {
    form.dataset.busy = '';
    btns.forEach((b) => { b.disabled = b.dataset.wasDisabled === '1'; delete b.dataset.wasDisabled; });
  }
}

/** Reduce y comprime una foto para guardarla dentro de la base de datos. */
export function compressImage(file, max = 480, quality = 0.78) {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith('image/')) { reject(new Error('El archivo no es una imagen.')); return; }
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const scale = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement('canvas');
      c.width = Math.round(img.width * scale);
      c.height = Math.round(img.height * scale);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      resolve(c.toDataURL('image/jpeg', quality));
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('No se pudo leer la imagen.')); };
    img.src = url;
  });
}

export function initials(s) {
  return String(s || '?').split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0].toUpperCase()).join('');
}

// recordar últimas opciones
const RKEY = 'chinelastock.recent';
export function recent() {
  try { return JSON.parse(localStorage.getItem(RKEY)) || {}; } catch { return {}; }
}
export function remember(patch) {
  try {
    const r = recent();
    if (patch.brand) r.brands = [patch.brand, ...(r.brands || []).filter((b) => b.toLowerCase() !== patch.brand.toLowerCase())].slice(0, 5);
    for (const k of ['supplier', 'cost', 'price', 'payment']) if (patch[k] != null) r[k] = patch[k];
    localStorage.setItem(RKEY, JSON.stringify(r));
  } catch { /* almacenamiento no disponible */ }
}
