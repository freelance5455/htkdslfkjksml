// Pantallas de cada módulo. Cada vista guarda su estado (filtros) para que se
// conserve al refrescar automáticamente tras un cambio en los datos.
import { formatMoney, centsToInput } from '../core/money.js';
import { normKey, localDate } from '../core/store.js';
import { buildExport } from '../core/exports.js';
import { Store } from '../core/store.js';
import {
  esc, $, $$, money, pct, fmtDate, fmtDateTime, toast, download, confirmDialog, initials, openModal, closeThenNavigate,
} from './dom.js';
import {
  openProductForm, openModelEdit, openVariantEdit, inlinePriceEdit, openBulkPrice, openPriceHistory, openStockAdjust,
  openSaleForm, openPurchaseForm, openSaleDetail, openPurchaseDetail, receivePurchase, openExpenseForm, openSupplierForm,
  saleStatusBadge,
} from './forms.js';

let app;
export function initViews(ctx) { app = ctx; }

const state = {
  inventario: { q: '', brand: '', size: '', color: '', low: false, archived: false, sel: new Set() },
  productos: { q: '', brand: '' },
  ventas: { q: '', period: '30' },
  compras: { tab: 'pending' },
  estadisticas: { period: 'month', from: '', to: '' },
  historial: { tab: 'moves', q: '' },
};

function periodRange(p, custom = {}) {
  const now = app.store.now();
  const t = localDate(now);
  const d = (n) => localDate(new Date(now.getFullYear(), now.getMonth(), now.getDate() - n));
  switch (p) {
    case 'today': return [t, t];
    case '7': return [d(6), t];
    case '30': return [d(29), t];
    case 'month': return [localDate(new Date(now.getFullYear(), now.getMonth(), 1)), t];
    case 'prevmonth': return [localDate(new Date(now.getFullYear(), now.getMonth() - 1, 1)), localDate(new Date(now.getFullYear(), now.getMonth(), 0))];
    case 'year': return [`${now.getFullYear()}-01-01`, t];
    case 'all': return ['2000-01-01', t];
    case 'custom': return [custom.from || t, custom.to || t];
    default: return [t, t];
  }
}
const PERIODS = [['today', 'Hoy'], ['7', '7 días'], ['30', '30 días'], ['month', 'Este mes'], ['prevmonth', 'Mes anterior'], ['year', 'Este año'], ['all', 'Todo'], ['custom', 'Personalizado']];

const empty = (icon, title, text, action = '') => `<div class="empty"><div class="empty-icon" aria-hidden="true">${icon}</div><h3>${esc(title)}</h3><p>${esc(text)}</p>${action}</div>`;

// =====================================================================
export const views = {
  // -------------------------------------------------------------------
  async dashboard(el) {
    const today = app.store.today();
    const [m0] = periodRange('month');
    const [st, sm, sales, s] = await Promise.all([
      app.store.stats({ from: today, to: today }),
      app.store.stats({ from: m0, to: today }),
      app.store.listSales(),
      app.store.getSettings(),
    ]);
    const lastBk = s.lastBackupAt ? new Date(s.lastBackupAt) : null;
    const days = lastBk ? Math.floor((app.store.now() - lastBk) / 86400000) : null;
    const needBackup = sales.length > 0 && (days == null || days >= 7);
    el.innerHTML = `
      <div class="quick">
        <button class="qbtn qbtn-primary" data-act="sale"><span aria-hidden="true">＋</span>Venta</button>
        <button class="qbtn" data-act="product"><span aria-hidden="true">＋</span>Producto</button>
        <button class="qbtn" data-act="purchase"><span aria-hidden="true">＋</span>Compra</button>
        <button class="qbtn" data-act="expense"><span aria-hidden="true">＋</span>Gasto</button>
      </div>
      ${needBackup ? `<div class="banner warn">${days == null ? 'Aún no has hecho ninguna copia de seguridad.' : `Tu última copia es de hace ${days} días.`} Los datos solo están en este móvil. <button class="btn btn-sm" data-act="backup">Hacer copia ahora</button></div>` : ''}
      <h2 class="h-sec">Hoy</h2>
      <div class="kpis">
        <div class="kpi"><span>Ventas</span><b data-kpi="today-count">${st.salesCount}</b></div>
        <div class="kpi"><span>Ingresos</span><b data-kpi="today-revenue">${money(st.netRevenue)}</b></div>
        <div class="kpi"><span>Beneficio bruto</span><b>${money(st.grossProfit)}</b></div>
        <div class="kpi"><span>Unidades</span><b>${st.unitsSold - st.unitsReturned}</b></div>
      </div>
      <h2 class="h-sec">Este mes</h2>
      <div class="kpis">
        <div class="kpi"><span>Ingresos</span><b>${money(sm.netRevenue)}</b></div>
        <div class="kpi"><span>Beneficio neto</span><b class="${sm.netProfit < 0 ? 'neg' : ''}">${money(sm.netProfit)}</b><small>tras ${money(sm.expenses)} de gastos</small></div>
        <div class="kpi"><span>Stock (a coste)</span><b>${money(sm.stockValue)}</b><small>${sm.stockUnits} unidades</small></div>
        <div class="kpi"><span>Compras pendientes</span><b>${sm.pendingPurchases}</b></div>
      </div>
      <div class="cols">
        <section class="card">
          <h3>Stock bajo <small class="muted">(≤ ${s.lowStock})</small></h3>
          ${sm.lowStock.length ? `<ul class="plain list">${sm.lowStock.slice(0, 8).map((x) => `<li><span>${esc(x.label)}</span><span class="badge ${x.stock === 0 ? 'badge-err' : 'badge-warn'}">${x.stock}</span></li>`).join('')}</ul>
          <a href="#/inventario" data-low class="link">Ver en inventario →</a>` : '<p class="muted">Todo con stock suficiente.</p>'}
        </section>
        <section class="card">
          <h3>Últimas ventas</h3>
          ${sales.length ? `<ul class="plain list">${sales.slice(0, 6).map((x) => `<li><button class="link" data-sale="${x.id}">#${x.id} · ${fmtDate(x.date)}</button><b>${money(x.total)}</b></li>`).join('')}</ul>` : '<p class="muted">Todavía no hay ventas.</p>'}
        </section>
      </div>`;
    el.onclick = (e) => {
      const a = e.target.closest('[data-act]')?.dataset.act;
      if (a === 'sale') openSaleForm();
      if (a === 'product') openProductForm();
      if (a === 'purchase') openPurchaseForm();
      if (a === 'expense') openExpenseForm();
      if (a === 'backup') doBackup();
      const sid = e.target.closest('[data-sale]')?.dataset.sale;
      if (sid) openSaleDetail(Number(sid));
      if (e.target.closest('[data-low]')) state.inventario.low = true;
    };
  },

  // -------------------------------------------------------------------
  async ventas(el) {
    const st = state.ventas;
    const [from, to] = periodRange(st.period);
    const sales = await app.store.listSales({ from, to });
    const words = normKey(st.q).split(' ').filter(Boolean);
    const list = words.length ? sales.filter((s) => {
      const k = normKey(`#${s.id} ${s.id} ${s.paymentMethod} ${s.notes} ${s.lines.map((l) => `${l.label} ${l.sku}`).join(' ')}`);
      return words.every((w) => k.includes(w));
    }) : sales;
    const total = list.reduce((a, s) => a + s.total, 0);
    el.innerHTML = `
      <div class="toolbar">
        <button class="btn btn-primary" data-new>+ Nueva venta</button>
        <input type="search" class="grow" name="q" placeholder="Buscar venta, producto o referencia" value="${esc(st.q)}" aria-label="Buscar ventas">
        <select name="period" aria-label="Período">${PERIODS.filter((p) => p[0] !== 'custom').map(([v, l]) => `<option value="${v}" ${v === st.period ? 'selected' : ''}>${l}</option>`).join('')}</select>
      </div>
      <p class="muted small">${list.length} ventas · ${money(total)}</p>
      ${list.length ? `<ul class="cards">${list.map((s) => `
        <li><button class="row-card" data-sale="${s.id}">
          <span class="rc-main"><b>#${s.id}</b> · ${fmtDate(s.date)} ${s.status !== 'ok' ? saleStatusBadge(s.status) : ''}
            <small class="muted">${esc(s.lines.map((l) => `${l.qty}× ${l.label}`).join(', '))}</small></span>
          <span class="rc-side"><b>${money(s.total)}</b><small class="muted">${esc(s.paymentMethod)}</small></span>
        </button></li>`).join('')}</ul>` : empty('🧾', 'Sin ventas en este período', 'Registra una venta con el botón «+ Nueva venta».')}`;
    el.querySelector('[data-new]').onclick = () => openSaleForm();
    el.querySelector('[name=q]').oninput = (e) => { st.q = e.target.value; rerenderSoon(); };
    el.querySelector('[name=period]').onchange = (e) => { st.period = e.target.value; rerender(); };
    el.onclick = (e) => { const b = e.target.closest('[data-sale]'); if (b) openSaleDetail(Number(b.dataset.sale)); };
  },

  // -------------------------------------------------------------------
  async compras(el) {
    const st = state.compras;
    const all = await app.store.listPurchases();
    const list = st.tab === 'all' ? all : all.filter((p) => p.status === st.tab);
    const counts = { pending: all.filter((p) => p.status === 'pending').length, received: all.filter((p) => p.status === 'received').length };
    el.innerHTML = `
      <div class="toolbar"><button class="btn btn-primary" data-new>+ Nueva compra</button></div>
      <div class="seg" role="tablist">
        ${[['pending', `Pendientes (${counts.pending})`], ['received', `Recibidas (${counts.received})`], ['all', 'Todas']].map(([k, l]) => `<button role="tab" aria-selected="${st.tab === k}" data-tab="${k}">${l}</button>`).join('')}
      </div>
      ${list.length ? `<ul class="cards">${list.map((p) => `
        <li class="row-card">
          <button class="rc-main link-area" data-p="${p.id}"><b>#${p.id}</b> · ${fmtDate(p.date)} ${p.supplier ? `· ${esc(p.supplier)}` : ''}
            <small class="muted">${p.lines.reduce((a, l) => a + l.qty, 0)} uds · ${esc(p.lines.map((l) => l.label).slice(0, 3).join(', '))}${p.lines.length > 3 ? '…' : ''}</small></button>
          <span class="rc-side"><b>${money(p.total)}</b>
            ${p.status === 'pending' ? `<button class="btn btn-sm btn-primary" data-receive="${p.id}">Recibir</button>` : `<span class="badge ${p.status === 'received' ? 'badge-ok' : 'badge-muted'}">${p.status === 'received' ? 'Recibida' : 'Anulada'}</span>`}</span>
        </li>`).join('')}</ul>` : empty('📦', st.tab === 'pending' ? 'No hay compras pendientes' : 'Sin compras', 'Registra la mercancía que compras a tus proveedores.')}`;
    el.querySelector('[data-new]').onclick = () => openPurchaseForm();
    el.onclick = (e) => {
      const t = e.target.closest('[data-tab]');
      if (t) { st.tab = t.dataset.tab; rerender(); return; }
      const r = e.target.closest('[data-receive]');
      if (r) { receivePurchase(all.find((p) => p.id === Number(r.dataset.receive))); return; }
      const d = e.target.closest('[data-p]');
      if (d) openPurchaseDetail(all.find((p) => p.id === Number(d.dataset.p)));
    };
  },

  // -------------------------------------------------------------------
  async inventario(el) {
    const st = state.inventario;
    const cat = await app.store.loadCatalog();
    const settings = app.settings;
    const words = normKey(st.q).split(' ').filter(Boolean);
    // Opciones de filtro agrupadas por clave normalizada (tildes y mayúsculas no cuentan)
    const uniq = (key, label) => [...new Map(cat.variants.filter((v) => v[key]).map((v) => [v[key], v[label]])).entries()];
    const sizes = uniq('sizeKey', 'size').sort((a, b) => a[1].localeCompare(b[1], 'es', { numeric: true }));
    const colors = uniq('colorKey', 'color').sort((a, b) => a[1].localeCompare(b[1], 'es'));
    const list = cat.variants.filter((v) => {
      const m = cat.modelById.get(v.modelId);
      const archived = v.active === false || m?.active === false;
      if (archived !== st.archived) return false;
      if (st.brand && String(v.brandId) !== st.brand) return false;
      if (st.size && v.sizeKey !== st.size) return false;
      if (st.color && v.colorKey !== st.color) return false;
      if (st.low && v.stock > settings.lowStock) return false;
      return words.every((w) => v.searchKey.includes(w));
    });
    for (const id of [...st.sel]) if (!cat.variants.some((v) => v.id === id)) st.sel.delete(id);
    const units = list.reduce((a, v) => a + v.stock, 0);
    const value = list.reduce((a, v) => a + v.stock * v.avgCost, 0);
    el.innerHTML = `
      <div class="toolbar">
        <button class="btn btn-primary" data-new>+ Añadir producto</button>
        <input type="search" class="grow" name="q" placeholder="Buscar modelo, marca, referencia…" value="${esc(st.q)}" aria-label="Buscar en inventario">
      </div>
      <div class="filters" data-noswipe>
        <select name="brand" aria-label="Marca"><option value="">Todas las marcas</option>${cat.brands.map((b) => `<option value="${b.id}" ${String(b.id) === st.brand ? 'selected' : ''}>${esc(b.name)}</option>`).join('')}</select>
        <select name="size" aria-label="Talla"><option value="">Todas las tallas</option>${sizes.map(([k, l]) => `<option value="${esc(k)}" ${k === st.size ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select>
        <select name="color" aria-label="Color"><option value="">Todos los colores</option>${colors.map(([k, l]) => `<option value="${esc(k)}" ${k === st.color ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select>
        <label class="check"><input type="checkbox" name="low" ${st.low ? 'checked' : ''}> Stock bajo</label>
        <label class="check"><input type="checkbox" name="archived" ${st.archived ? 'checked' : ''}> Archivados</label>
      </div>
      <div class="selbar">
        <label class="check"><input type="checkbox" name="selall" ${list.length && list.every((v) => st.sel.has(v.id)) ? 'checked' : ''}> Seleccionar los ${list.length} filtrados</label>
        <span class="muted small">${units} uds · ${money(value)} a coste</span>
        <button class="btn btn-sm btn-primary" data-bulk ${st.sel.size ? '' : 'disabled'}>Cambiar precios (${st.sel.size})</button>
      </div>
      ${list.length ? `<ul class="vlist">${list.map((v) => {
        const marginBp = v.price > 0 ? Math.round(((v.price - v.avgCost) * 10000) / v.price) : null;
        const lowCls = v.stock === 0 ? 'badge-err' : v.stock <= settings.lowStock ? 'badge-warn' : 'badge-ok';
        return `<li class="vitem" data-vid="${v.id}">
          <input type="checkbox" class="vsel" aria-label="Seleccionar ${esc(v.label)}" ${st.sel.has(v.id) ? 'checked' : ''}>
          <div class="vinfo"><b>${esc(v.brandName)} ${esc(v.modelName)}</b><span>T${esc(v.size)}${v.color ? ` · ${esc(v.color)}` : ''} · <span class="muted">${esc(v.sku)}</span></span></div>
          <button class="badge stock ${lowCls}" data-stock aria-label="Existencias ${v.stock}, ajustar">${v.stock} uds</button>
          <div class="vprices">
            <span><small>Compra</small><button class="inline-edit" data-edit="cost" aria-label="Editar precio de compra de ${esc(v.label)}">${money(v.cost)}</button></span>
            <span><small>Venta</small><button class="inline-edit strong" data-edit="price" aria-label="Editar precio de venta de ${esc(v.label)}">${money(v.price)}</button></span>
            <span class="margin"><small>Margen</small>${pct(marginBp)}</span>
          </div>
          <button class="icon-btn" data-more aria-label="Más opciones">⋯</button>
        </li>`;
      }).join('')}</ul>` : cat.variants.length ? empty('🔍', 'Nada coincide con los filtros', 'Cambia la búsqueda o los filtros.') : empty('🩴', 'Tu inventario está vacío', 'Empieza añadiendo tu primer producto con sus tallas y colores.', '<button class="btn btn-primary" data-new>+ Añadir producto</button>')}`;

    const byId = new Map(cat.variants.map((v) => [v.id, v]));
    el.querySelector('[name=q]').oninput = (e) => { st.q = e.target.value; rerenderSoon(); };
    el.querySelectorAll('.filters select').forEach((s) => { s.onchange = () => { st[s.name] = s.value; rerender(); }; });
    el.querySelectorAll('.filters input').forEach((c) => { c.onchange = () => { st[c.name] = c.checked; rerender(); }; });
    el.querySelector('[name=selall]').onchange = (e) => {
      list.forEach((v) => (e.target.checked ? st.sel.add(v.id) : st.sel.delete(v.id)));
      rerender();
    };
    el.onclick = (e) => {
      if (e.target.closest('[data-new]')) { openProductForm(); return; }
      if (e.target.closest('[data-bulk]')) { openBulkPrice([...st.sel]); return; }
      const item = e.target.closest('[data-vid]');
      if (!item) return;
      const v = byId.get(Number(item.dataset.vid));
      if (e.target.matches('.vsel')) {
        if (e.target.checked) st.sel.add(v.id); else st.sel.delete(v.id);
        const b = el.querySelector('[data-bulk]');
        b.disabled = !st.sel.size; b.textContent = `Cambiar precios (${st.sel.size})`;
        return;
      }
      const ed = e.target.closest('[data-edit]');
      if (ed) { inlinePriceEdit(ed, v, ed.dataset.edit); return; }
      if (e.target.closest('[data-stock]')) { openStockAdjust(v); return; }
      if (e.target.closest('[data-more]')) variantMenu(v, cat);
    };
  },

  // -------------------------------------------------------------------
  async productos(el) {
    const st = state.productos;
    const cat = await app.store.loadCatalog();
    const words = normKey(st.q).split(' ').filter(Boolean);
    const list = cat.models.filter((m) => {
      if (st.brand && String(m.brandId) !== st.brand) return false;
      const k = normKey(`${m.brandName} ${m.name} ${m.supplierName} ${m.variants.map((v) => `${v.sku} ${v.color}`).join(' ')}`);
      return words.every((w) => k.includes(w));
    });
    el.innerHTML = `
      <div class="toolbar">
        <button class="btn btn-primary" data-new>+ Añadir producto</button>
        <input type="search" class="grow" name="q" placeholder="Buscar modelo, marca, color…" value="${esc(st.q)}" aria-label="Buscar productos">
      </div>
      ${cat.brands.length ? `<div class="chips scroll-x" data-noswipe>
        <button class="chip ${st.brand ? '' : 'on'}" data-brand="">Todas</button>
        ${cat.brands.map((b) => `<button class="chip ${String(b.id) === st.brand ? 'on' : ''}" data-brand="${b.id}">${esc(b.name)}</button>`).join('')}</div>` : ''}
      ${list.length ? `<ul class="mgrid">${list.map((m) => {
        const stock = m.variants.reduce((a, v) => a + v.stock, 0);
        const prices = m.variants.map((v) => v.price);
        const min = Math.min(...prices); const max = Math.max(...prices);
        return `<li><button class="mcard ${m.active === false ? 'archived' : ''}" data-model="${m.id}">
          ${m.photo ? `<img src="${esc(m.photo)}" alt="" loading="lazy">` : `<span class="ph" aria-hidden="true">${esc(initials(m.name))}</span>`}
          <span class="mc-body"><small class="muted">${esc(m.brandName)}</small><b>${esc(m.name)}</b>
          <small>${m.variants.length} variantes · ${stock} uds</small>
          <small class="strong">${prices.length ? (min === max ? money(min) : `${money(min)} – ${money(max)}`) : ''}</small></span>
        </button></li>`;
      }).join('')}</ul>` : cat.models.length ? empty('🔍', 'Sin resultados', 'Prueba con otra búsqueda.') : empty('🩴', 'Aún no hay productos', 'Añade un modelo con todas sus tallas y colores en un solo paso.', '<button class="btn btn-primary" data-new>+ Añadir producto</button>')}`;
    el.querySelector('[name=q]').oninput = (e) => { st.q = e.target.value; rerenderSoon(); };
    el.onclick = (e) => {
      if (e.target.closest('[data-new]')) { openProductForm(); return; }
      const b = e.target.closest('[data-brand]');
      if (b) { st.brand = b.dataset.brand; rerender(); return; }
      const m = e.target.closest('[data-model]');
      if (m) openModelDetail(Number(m.dataset.model));
    };
  },

  // -------------------------------------------------------------------
  async estadisticas(el) {
    const st = state.estadisticas;
    const [from, to] = periodRange(st.period, st);
    let r;
    try { r = await app.store.stats({ from, to }); } catch (err) { el.innerHTML = `<p class="err">${esc(err.message)}</p>`; return; }
    el.innerHTML = `
      <div class="chips scroll-x" data-noswipe>${PERIODS.map(([k, l]) => `<button class="chip ${k === st.period ? 'on' : ''}" data-period="${k}">${l}</button>`).join('')}</div>
      ${st.period === 'custom' ? `<div class="toolbar"><label class="field"><span>Desde</span><input type="date" name="from" value="${from}"></label><label class="field"><span>Hasta</span><input type="date" name="to" value="${to}"></label></div>` : ''}
      <p class="muted small">${fmtDate(from)} – ${fmtDate(to)}</p>
      <div class="kpis">
        <div class="kpi"><span>Ingresos netos</span><b data-kpi="revenue">${money(r.netRevenue)}</b><small>${r.refunds ? `tras ${money(r.refunds)} devueltos` : `${r.salesCount} ventas`}</small></div>
        <div class="kpi"><span>Coste de lo vendido</span><b>${money(r.cogs)}</b></div>
        <div class="kpi"><span>Beneficio bruto</span><b data-kpi="gross">${money(r.grossProfit)}</b><small>Margen ${pct(r.marginBp)}</small></div>
        <div class="kpi"><span>Gastos</span><b>${money(r.expenses)}</b></div>
        <div class="kpi"><span>Beneficio neto</span><b class="${r.netProfit < 0 ? 'neg' : 'pos'}" data-kpi="net">${money(r.netProfit)}</b></div>
        <div class="kpi"><span>Ticket medio</span><b>${money(r.avgTicket)}</b><small>${r.unitsSold - r.unitsReturned} uds netas</small></div>
        <div class="kpi"><span>Compras recibidas</span><b>${money(r.purchases)}</b></div>
        <div class="kpi"><span>Valor del stock</span><b>${money(r.stockValue)}</b><small>a precio de venta ${money(r.stockRetail)}</small></div>
      </div>
      <section class="card"><h3>Ingresos y beneficio bruto</h3>${barChart(r.byDay)}</section>
      <div class="cols">
        <section class="card"><h3>Modelos más vendidos</h3>${rankTable(r.topModels.slice(0, 10))}</section>
        <section class="card"><h3>Por marca</h3>${rankTable(r.byBrand)}</section>
      </div>
      <div class="cols">
        <section class="card"><h3>Formas de pago</h3>${Object.keys(r.byPayment).length ? `<ul class="plain list">${Object.entries(r.byPayment).map(([k, v]) => `<li><span>${esc(k)}</span><b>${money(v)}</b></li>`).join('')}</ul>` : '<p class="muted">Sin ventas.</p>'}</section>
        <section class="card"><h3>Gastos por categoría</h3>${Object.keys(r.byExpenseCategory).length ? `<ul class="plain list">${Object.entries(r.byExpenseCategory).sort((a, b) => b[1] - a[1]).map(([k, v]) => `<li><span>${esc(k)}</span><b>${money(v)}</b></li>`).join('')}</ul>` : '<p class="muted">Sin gastos.</p>'}</section>
      </div>`;
    el.onclick = (e) => { const p = e.target.closest('[data-period]'); if (p) { st.period = p.dataset.period; if (p.dataset.period === 'custom' && !st.from) { st.from = from; st.to = to; } rerender(); } };
    el.querySelectorAll('input[type=date]').forEach((i) => { i.onchange = () => { st[i.name] = i.value; rerender(); }; });
  },

  // -------------------------------------------------------------------
  async gastos(el) {
    const list = await app.store.listExpenses();
    const byMonth = new Map();
    for (const e of list) {
      const k = e.date.slice(0, 7);
      if (!byMonth.has(k)) byMonth.set(k, []);
      byMonth.get(k).push(e);
    }
    const monthName = (k) => new Date(`${k}-01T00:00:00`).toLocaleDateString('es-ES', { month: 'long', year: 'numeric' });
    el.innerHTML = `
      <div class="toolbar"><button class="btn btn-primary" data-new>+ Añadir gasto</button></div>
      ${list.length ? [...byMonth].map(([k, es]) => `
        <section class="card"><h3>${esc(monthName(k))} <span class="muted">· ${money(es.reduce((a, e) => a + e.amount, 0))}</span></h3>
        <ul class="plain list">${es.map((e) => `<li><span>${fmtDate(e.date)} · <b>${esc(e.category)}</b>${e.note ? ` <small class="muted">${esc(e.note)}</small>` : ''}</span><span>${money(e.amount)} <button class="icon-btn" data-del="${e.id}" aria-label="Eliminar gasto">🗑</button></span></li>`).join('')}</ul></section>`).join('')
        : empty('💸', 'Sin gastos registrados', 'Anota alquiler, transporte, publicidad… para calcular tu beneficio neto.')}`;
    el.onclick = async (e) => {
      if (e.target.closest('[data-new]')) { openExpenseForm(); return; }
      const d = e.target.closest('[data-del]');
      if (d) {
        const ex = list.find((x) => x.id === Number(d.dataset.del));
        if (await confirmDialog({ title: 'Eliminar gasto', message: `${ex.category} · ${money(ex.amount)} del ${fmtDate(ex.date)}`, okText: 'Eliminar', danger: true })) {
          try { await app.store.deleteExpense(ex.id); toast('Gasto eliminado'); } catch (err) { toast(err.message, 'error'); }
        }
      }
    };
  },

  // -------------------------------------------------------------------
  async proveedores(el) {
    const [sups, cat, purchases] = await Promise.all([app.store.listSuppliers(), app.store.loadCatalog(), app.store.listPurchases()]);
    el.innerHTML = `
      <div class="toolbar"><button class="btn btn-primary" data-new>+ Añadir proveedor</button></div>
      ${sups.length ? `<ul class="cards">${sups.map((s) => {
        const ps = purchases.filter((p) => p.supplierId === s.id && p.status === 'received');
        return `<li><button class="row-card" data-sup="${s.id}">
          <span class="rc-main"><b>${esc(s.name)}</b><small class="muted">${[s.phone, s.email].filter(Boolean).map(esc).join(' · ') || 'Sin datos de contacto'}</small>
          <small>${cat.models.filter((m) => m.supplierId === s.id).length} modelos · ${ps.length} compras</small></span>
          <span class="rc-side"><b>${money(ps.reduce((a, p) => a + p.total, 0))}</b><small class="muted">comprado</small></span>
        </button></li>`;
      }).join('')}</ul>` : empty('🚚', 'Sin proveedores', 'Añádelos aquí o escribe uno nuevo al registrar un producto o una compra.')}`;
    el.onclick = (e) => {
      if (e.target.closest('[data-new]')) { openSupplierForm(); return; }
      const s = e.target.closest('[data-sup]');
      if (s) openSupplierForm(sups.find((x) => x.id === Number(s.dataset.sup)));
    };
  },

  // -------------------------------------------------------------------
  async historial(el) {
    const st = state.historial;
    const cat = await app.store.loadCatalog();
    const byId = new Map(cat.variants.map((v) => [v.id, v]));
    const words = normKey(st.q).split(' ').filter(Boolean);
    const match = (s) => words.every((w) => normKey(s).includes(w));
    let rows = '';
    if (st.tab === 'moves') {
      const TYPES = { inicial: 'Alta', compra: 'Compra', venta: 'Venta', devolucion: 'Devolución', ajuste: 'Ajuste' };
      const moves = (await app.store.listStockMoves({ limit: 500 })).filter((m) => match(`${byId.get(m.variantId)?.label ?? ''} ${byId.get(m.variantId)?.sku ?? ''} ${TYPES[m.type]} ${m.note}`));
      rows = moves.length ? `<div class="table-wrap" data-noswipe><table class="table"><thead><tr><th>Fecha</th><th>Producto</th><th>Tipo</th><th class="num">Cambio</th><th class="num">Queda</th></tr></thead><tbody>
        ${moves.map((m) => `<tr><td>${fmtDateTime(m.at)}</td><td>${esc(byId.get(m.variantId)?.label ?? `#${m.variantId}`)}${m.note ? `<br><small class="muted">${esc(m.note)}</small>` : ''}</td><td>${TYPES[m.type] || m.type}${m.refId ? ` #${m.refId}` : ''}</td><td class="num ${m.qty > 0 ? 'pos' : 'neg'}">${m.qty > 0 ? '+' : ''}${m.qty}</td><td class="num">${m.stockAfter}</td></tr>`).join('')}
      </tbody></table></div>` : '<p class="muted">Sin movimientos.</p>';
    } else if (st.tab === 'prices') {
      const ph = (await app.store.listPriceHistory({ limit: 500 })).filter((h) => h.old != null && match(`${byId.get(h.variantId)?.label ?? ''} ${byId.get(h.variantId)?.sku ?? ''} ${h.reason}`));
      rows = ph.length ? `<div class="table-wrap" data-noswipe><table class="table"><thead><tr><th>Fecha</th><th>Producto</th><th>Precio</th><th class="num">Antes</th><th class="num">Después</th><th>Motivo</th></tr></thead><tbody>
        ${ph.map((h) => `<tr><td>${fmtDateTime(h.at)}</td><td>${esc(byId.get(h.variantId)?.label ?? `#${h.variantId}`)}</td><td>${h.field === 'price' ? 'Venta' : 'Compra'}</td><td class="num">${money(h.old)}</td><td class="num">${money(h.new)}</td><td>${esc(h.reason)}</td></tr>`).join('')}
      </tbody></table></div>` : '<p class="muted">Sin cambios de precio.</p>';
    } else {
      const [sales, purchases, returns, expenses] = await Promise.all([app.store.listSales(), app.store.listPurchases(), app.store.listReturns(), app.store.listExpenses()]);
      const ops = [
        ...sales.map((s) => ({ at: s.createdAt, date: s.date, kind: 'Venta', id: s.id, text: s.lines.map((l) => `${l.qty}× ${l.label}`).join(', '), amount: s.total, sale: s.id })),
        ...purchases.map((p) => ({ at: p.createdAt, date: p.date, kind: 'Compra', id: p.id, text: `${p.supplier || ''} ${p.lines.map((l) => `${l.qty}× ${l.label}`).join(', ')}`, amount: -p.total })),
        ...returns.map((r) => ({ at: r.createdAt, date: r.date, kind: 'Devolución', id: r.id, text: `Venta #${r.saleId}: ${r.lines.map((l) => `${l.qty}× ${l.label}`).join(', ')}`, amount: -r.refund, sale: r.saleId })),
        ...expenses.map((e) => ({ at: e.createdAt, date: e.date, kind: 'Gasto', id: e.id, text: `${e.category} ${e.note}`, amount: -e.amount })),
      ].filter((o) => match(`${o.kind} #${o.id} ${o.text}`)).sort((a, b) => (a.at < b.at ? 1 : -1)).slice(0, 500);
      rows = ops.length ? `<ul class="cards">${ops.map((o) => `<li><div class="row-card ${o.sale ? 'clickable' : ''}" ${o.sale ? `data-sale="${o.sale}" role="button" tabindex="0"` : ''}>
        <span class="rc-main"><b>${o.kind} #${o.id}</b> · ${fmtDate(o.date)}<small class="muted">${esc(o.text)}</small></span>
        <span class="rc-side"><b class="${o.amount < 0 ? 'neg' : 'pos'}">${money(o.amount)}</b></span></div></li>`).join('')}</ul>` : '<p class="muted">Sin operaciones.</p>';
    }
    el.innerHTML = `
      <div class="seg" role="tablist">${[['moves', 'Stock'], ['prices', 'Precios'], ['ops', 'Operaciones']].map(([k, l]) => `<button role="tab" aria-selected="${st.tab === k}" data-tab="${k}">${l}</button>`).join('')}</div>
      <div class="toolbar"><input type="search" class="grow" name="q" placeholder="Filtrar por producto, referencia, motivo…" value="${esc(st.q)}" aria-label="Filtrar historial"></div>
      ${rows}`;
    el.querySelector('[name=q]').oninput = (e) => { st.q = e.target.value; rerenderSoon(); };
    el.onclick = (e) => {
      const t = e.target.closest('[data-tab]');
      if (t) { st.tab = t.dataset.tab; rerender(); return; }
      const s = e.target.closest('[data-sale]');
      if (s) openSaleDetail(Number(s.dataset.sale));
    };
  },

  // -------------------------------------------------------------------
  async informes(el) {
    const s = await app.store.getSettings();
    let persisted = null;
    try { persisted = await navigator.storage?.persisted?.(); } catch { /* no disponible */ }
    let estimate = null;
    try { estimate = await navigator.storage?.estimate?.(); } catch { /* no disponible */ }
    el.innerHTML = `
      <section class="card">
        <h3>Copia de seguridad</h3>
        <p>Todos tus datos están guardados <b>solo en este dispositivo</b>. Descarga una copia con frecuencia y guárdala fuera del móvil (correo, Drive, ordenador).</p>
        <p class="muted small">Última copia: ${s.lastBackupAt ? fmtDateTime(s.lastBackupAt) : 'nunca'}${estimate?.usage != null ? ` · Espacio usado: ${(estimate.usage / 1048576).toFixed(1)} MB` : ''}
          · Almacenamiento persistente: ${persisted == null ? 'no disponible' : persisted ? 'activado ✓' : 'no activado'}</p>
        <div class="row-actions">
          <button class="btn btn-primary" data-backup>Descargar copia (.json)</button>
          <label class="btn">Restaurar copia…<input type="file" accept="application/json,.json" name="restore" hidden></label>
          ${persisted === false ? '<button class="btn btn-ghost" data-persist>Activar almacenamiento persistente</button>' : ''}
        </div>
      </section>
      <section class="card">
        <h3>Exportar a Excel (CSV)</h3>
        <p class="muted">Archivos separados por «;» con decimales en coma, listos para abrir en Excel o Google Sheets.</p>
        <div class="row-actions">
          ${[['inventario', 'Inventario'], ['ventas', 'Ventas (por línea)'], ['compras', 'Compras'], ['devoluciones', 'Devoluciones'], ['gastos', 'Gastos']].map(([k, l]) => `<button class="btn" data-export="${k}">${l}</button>`).join('')}
        </div>
      </section>`;
    el.onclick = async (e) => {
      if (e.target.closest('[data-backup]')) { doBackup(); return; }
      if (e.target.closest('[data-persist]')) {
        const ok = await navigator.storage.persist();
        toast(ok ? 'Almacenamiento persistente activado' : 'El navegador no lo ha concedido. Instala la app en la pantalla de inicio y vuelve a intentarlo.', ok ? 'ok' : 'error');
        rerender();
        return;
      }
      const x = e.target.closest('[data-export]');
      if (x) {
        try { const f = await buildExport(app.store, x.dataset.export); download(f.filename, f.content); toast(`Exportado ${f.filename}`); } catch (err) { toast(err.message, 'error'); }
      }
    };
    el.querySelector('[name=restore]').onchange = async (e) => {
      const file = e.target.files[0];
      e.target.value = '';
      if (!file) return;
      let obj; let sum;
      try {
        obj = JSON.parse(await file.text());
        sum = Store.validateBackup(obj);
      } catch (err) {
        toast(err instanceof SyntaxError ? 'El archivo no es un JSON válido.' : err.message, 'error');
        return;
      }
      const ok = await confirmDialog({
        title: 'Restaurar copia',
        message: `La copia del ${fmtDateTime(obj.exportedAt)} contiene ${sum.models} modelos, ${sum.variants} variantes, ${sum.sales} ventas, ${sum.purchases} compras y ${sum.expenses} gastos. SUSTITUIRÁ todos los datos actuales. Te recomendamos descargar antes una copia de lo que tienes ahora.`,
        okText: 'Sustituir mis datos', danger: true,
      });
      if (!ok) return;
      try { await app.store.importBackup(obj); toast('Copia restaurada correctamente'); } catch (err) { toast(err.message, 'error'); }
    };
  },

  // -------------------------------------------------------------------
  async config(el) {
    const s = await app.store.getSettings();
    el.innerHTML = `
      <form class="form card" novalidate>
        <div class="form-error" role="alert" hidden></div>
        <label class="field"><span>Nombre del negocio</span><input name="shopName" value="${esc(s.shopName)}"></label>
        <div class="grid-2">
          <label class="field"><span>Moneda</span><select name="currency">${['EUR', 'USD', 'MXN', 'ARS', 'COP', 'CLP', 'PEN', 'GTQ', 'HNL', 'BOB', 'PYG', 'UYU', 'GBP'].map((c) => `<option ${c === s.currency ? 'selected' : ''}>${c}</option>`).join('')}</select></label>
          <label class="field"><span>Aviso de stock bajo (≤ uds)</span><input name="lowStock" inputmode="numeric" value="${s.lowStock}"></label>
        </div>
        <fieldset class="field"><legend>Apariencia</legend>
          <div class="seg">${[['system', 'Automático'], ['light', 'Claro'], ['dark', 'Oscuro']].map(([k, l]) => `<label class="seg-opt"><input type="radio" name="theme" value="${k}" ${s.theme === k ? 'checked' : ''}><span>${l}</span></label>`).join('')}</div>
        </fieldset>
        <label class="check"><input type="checkbox" name="allowPriceOverride" ${s.allowPriceOverride ? 'checked' : ''}> Permitir cambiar el precio al registrar una venta</label>
        <p class="muted small">Valoración del inventario: <b>coste medio ponderado</b>. Cada compra recibida recalcula el coste medio de la talla/color; cada venta guarda el coste del momento, por lo que cambiar precios no altera beneficios pasados.</p>
        <div class="form-actions"><button class="btn btn-primary">Guardar configuración</button></div>
      </form>
      <p class="muted small center">ChinelaStock ${esc(app.version)} · funciona sin conexión</p>`;
    const form = $('form', el);
    form.querySelectorAll('[name=theme]').forEach((r) => { r.onchange = () => app.applyTheme(r.value); });
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      try {
        await app.store.setSettings({
          shopName: form.shopName.value, currency: form.currency.value, lowStock: form.lowStock.value,
          theme: form.querySelector('[name=theme]:checked').value, allowPriceOverride: form.allowPriceOverride.checked,
        });
        toast('Configuración guardada');
      } catch (err) {
        const box = form.querySelector('.form-error'); box.hidden = false; box.textContent = err.message;
      }
    });
  },
};

// ---------------------------------------------------------------------
async function doBackup() {
  try {
    const data = await app.store.exportBackup();
    download(`chinelastock-copia-${app.store.today()}.json`, JSON.stringify(data), 'application/json');
    await app.store.markBackupDone();
    toast('Copia descargada. Guárdala fuera del móvil.');
  } catch (err) { toast(err.message, 'error'); }
}

function rankTable(rows) {
  if (!rows.length) return '<p class="muted">Sin ventas en el período.</p>';
  const max = Math.max(...rows.map((r) => r.revenue), 1);
  return `<ul class="plain rank">${rows.map((r) => `<li><span class="rk-name">${esc(r.name)}<small class="muted">${r.units} uds · beneficio ${money(r.profit)}</small></span><b>${money(r.revenue)}</b><span class="bar" style="--w:${Math.max(0, (r.revenue / max) * 100).toFixed(1)}%"></span></li>`).join('')}</ul>`;
}

function barChart(days) {
  if (!days.length) return '';
  let pts = days;
  let grouped = false;
  if (days.length > 62) {
    grouped = true;
    const m = new Map();
    for (const d of days) {
      const k = d.date.slice(0, 7);
      if (!m.has(k)) m.set(k, { date: k, revenue: 0, profit: 0 });
      const x = m.get(k); x.revenue += d.revenue; x.profit += d.profit;
    }
    pts = [...m.values()];
  }
  const maxV = Math.max(1, ...pts.map((p) => Math.max(p.revenue, p.profit)));
  const minV = Math.min(0, ...pts.map((p) => Math.min(p.revenue, p.profit)));
  const W = 640; const H = 200; const pad = 4; const bw = (W - pad * 2) / pts.length;
  const y = (v) => H - ((v - minV) / (maxV - minV)) * (H - 20) - 10;
  const zero = y(0);
  const label = (p) => (grouped ? new Date(`${p.date}-01T00:00:00`).toLocaleDateString('es-ES', { month: 'short', year: '2-digit' }) : fmtDate(p.date));
  const bars = pts.map((p, i) => {
    const x = pad + i * bw;
    const r = y(p.revenue);
    const g = y(p.profit);
    const w = Math.max(1, bw * 0.42);
    return `<g><title>${label(p)} · Ingresos ${formatMoney(p.revenue, app.settings.currency)} · Beneficio ${formatMoney(p.profit, app.settings.currency)}</title>
      <rect class="b-rev" x="${(x + bw * 0.06).toFixed(1)}" y="${Math.min(r, zero).toFixed(1)}" width="${w.toFixed(1)}" height="${Math.max(0.5, Math.abs(zero - r)).toFixed(1)}" rx="1.5"/>
      <rect class="b-pro" x="${(x + bw * 0.06 + w).toFixed(1)}" y="${Math.min(g, zero).toFixed(1)}" width="${w.toFixed(1)}" height="${Math.max(0.5, Math.abs(zero - g)).toFixed(1)}" rx="1.5"/></g>`;
  }).join('');
  return `<div class="chart" data-noswipe>
    <svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img" aria-label="Gráfico de ingresos y beneficio">
      <line x1="0" x2="${W}" y1="${zero}" y2="${zero}" class="axis"/>${bars}</svg>
    <div class="chart-x"><span>${label(pts[0])}</span><span>${label(pts[pts.length - 1])}</span></div>
    <div class="legend"><span><i class="b-rev"></i>Ingresos</span><span><i class="b-pro"></i>Beneficio bruto</span><span class="muted">Máx. ${money(maxV)}</span></div>
  </div>`;
}

function variantMenu(v, cat) {
  const m = cat.modelById.get(v.modelId);
  const ctrl = openModal({
    title: v.label, size: 'sm',
    render(el) {
      el.innerHTML = `<div class="menu">
        <button class="btn" data-a="stock">Ajustar existencias</button>
        <button class="btn" data-a="model">Ver modelo y todas sus tallas</button>
        <button class="btn" data-a="edit">Editar talla, color o referencia</button>
        <button class="btn" data-a="hist">Historial de precios</button>
        <button class="btn" data-a="moves">Movimientos de stock</button>
      </div>`;
      el.onclick = async (e) => {
        const a = e.target.closest('[data-a]')?.dataset.a;
        if (!a) return;
        if (a === 'moves') { state.historial.tab = 'moves'; state.historial.q = v.sku; closeThenNavigate(ctrl, '#/historial'); return; }
        ctrl.close();
        if (a === 'stock') openStockAdjust(v);
        if (a === 'model') openModelDetail(m.id);
        if (a === 'edit') openVariantEdit(v);
        if (a === 'hist') openPriceHistory(v);
      };
    },
  });
}

export async function openModelDetail(modelId) {
  const ctrl = openModal({ title: 'Modelo', size: 'lg', render() {} });
  const paint = async () => {
    const cat = await app.store.loadCatalog();
    const m = cat.modelById.get(modelId);
    if (!m) { ctrl.el.innerHTML = '<p>El modelo ya no existe.</p>'; return; }
    ctrl.root.querySelector('.modal-head h2').textContent = `${m.brandName} ${m.name}`;
    const stock = m.variants.reduce((a, v) => a + v.stock, 0);
    ctrl.el.innerHTML = `
      <div class="mhead">
        ${m.photo ? `<img src="${esc(m.photo)}" alt="Foto de ${esc(m.name)}" class="mphoto">` : `<span class="ph big" aria-hidden="true">${esc(initials(m.name))}</span>`}
        <div><p class="muted">${esc(m.brandName)}${m.supplierName ? ` · Proveedor: ${esc(m.supplierName)}` : ''}</p>
        <p><b>${m.variants.length}</b> variantes · <b>${stock}</b> unidades${m.active === false ? ' · <span class="badge badge-muted">Archivado</span>' : ''}</p>
        ${m.notes ? `<p class="small">${esc(m.notes)}</p>` : ''}</div>
      </div>
      <div class="row-actions">
        <button class="btn btn-primary" data-a="add">+ Añadir tallas</button>
        <button class="btn" data-a="dup">Duplicar</button>
        <button class="btn" data-a="edit">Editar datos</button>
        <button class="btn" data-a="bulk">Cambiar precios de todas</button>
        <button class="btn btn-ghost" data-a="archive">${m.active === false ? 'Reactivar' : 'Archivar'}</button>
      </div>
      <ul class="vlist compact">${m.variants.map((v) => `
        <li class="vitem" data-vid="${v.id}">
          <div class="vinfo"><b>T${esc(v.size)}${v.color ? ` · ${esc(v.color)}` : ''}</b><span class="muted">${esc(v.sku)}${v.active === false ? ' · archivada' : ''}</span></div>
          <button class="badge stock ${v.stock === 0 ? 'badge-err' : v.stock <= app.settings.lowStock ? 'badge-warn' : 'badge-ok'}" data-stock>${v.stock} uds</button>
          <div class="vprices">
            <span><small>Compra</small><button class="inline-edit" data-edit="cost">${money(v.cost)}</button></span>
            <span><small>Venta</small><button class="inline-edit strong" data-edit="price">${money(v.price)}</button></span>
          </div>
          <button class="icon-btn" data-vedit aria-label="Editar variante">✎</button>
        </li>`).join('')}</ul>`;
    const byId = new Map(m.variants.map((v) => [v.id, v]));
    ctrl.el.onclick = async (e) => {
      const a = e.target.closest('[data-a]')?.dataset.a;
      if (a === 'add') openProductForm({ mode: 'addVariants', model: m });
      if (a === 'dup') openProductForm({ mode: 'duplicate', model: m });
      if (a === 'edit') openModelEdit(m);
      if (a === 'bulk') openBulkPrice(m.variants.map((v) => v.id));
      if (a === 'archive') {
        const arch = m.active !== false;
        if (arch && !await confirmDialog({ title: 'Archivar modelo', message: 'No aparecerá en ventas ni en el inventario activo. Su historial se conserva y podrás reactivarlo.', okText: 'Archivar' })) return;
        try { await app.store.updateModel(m.id, { active: !arch }); toast(arch ? 'Modelo archivado' : 'Modelo reactivado'); } catch (err) { toast(err.message, 'error'); }
      }
      const item = e.target.closest('[data-vid]');
      if (!item) return;
      const v = byId.get(Number(item.dataset.vid));
      const ed = e.target.closest('[data-edit]');
      if (ed) inlinePriceEdit(ed, v, ed.dataset.edit);
      if (e.target.closest('[data-stock]')) openStockAdjust(v);
      if (e.target.closest('[data-vedit]')) openVariantEdit(v);
    };
  };
  await paint();
  const onChange = () => { if (!ctrl.el.querySelector('.inline-editor')) paint(); };
  app.store.addEventListener('change', onChange);
  ctrl.onDispose(() => app.store.removeEventListener('change', onChange));
}

// refresco de la vista actual (lo define app.js)
let rerender = () => {};
let rerenderSoon = () => {};
export function setRerender(fn, soon) { rerender = fn; rerenderSoon = soon; }
void centsToInput; void $$;
