// Navegación por gestos laterales entre módulos.
// Los gestos se ignoran sobre campos de formulario, zonas con desplazamiento
// horizontal, gráficos y mientras hay un modal abierto.

export const SWIPE = { minDx: 70, maxDy: 45, maxMs: 700, ratio: 2 };

/** Decide el resultado de un gesto. Pura: se puede probar sin navegador. */
export function decideSwipe({ dx, dy, dt }) {
  if (dt > SWIPE.maxMs) return null;
  if (Math.abs(dx) < SWIPE.minDx) return null;
  if (Math.abs(dy) > SWIPE.maxDy) return null;
  if (Math.abs(dx) < Math.abs(dy) * SWIPE.ratio) return null;
  return dx < 0 ? 'next' : 'prev';
}

const BLOCK_SELECTOR = 'input, textarea, select, button.inline-edit, [contenteditable="true"], [data-noswipe], .chart, .modal-backdrop';

export function isBlockedTarget(target) {
  if (!target || !target.closest) return false;
  if (target.closest(BLOCK_SELECTOR)) return true;
  // Zonas con desplazamiento horizontal (tablas anchas, carruseles)
  for (let el = target; el && el !== document.body; el = el.parentElement) {
    if (el.scrollWidth > el.clientWidth + 2) {
      const ox = getComputedStyle(el).overflowX;
      if (ox === 'auto' || ox === 'scroll') return true;
    }
  }
  return false;
}

export function attachSwipe(el, { onSwipe, isEnabled = () => true }) {
  let start = null;
  el.addEventListener('touchstart', (e) => {
    if (e.touches.length !== 1 || !isEnabled() || isBlockedTarget(e.target)) { start = null; return; }
    const t = e.touches[0];
    // No interferir con el gesto «atrás» del sistema en los bordes de la pantalla
    if (t.clientX < 16 || t.clientX > window.innerWidth - 16) { start = null; return; }
    start = { x: t.clientX, y: t.clientY, t: performance.now() };
  }, { passive: true });
  el.addEventListener('touchmove', (e) => {
    if (start && e.touches.length > 1) start = null;
  }, { passive: true });
  el.addEventListener('touchend', (e) => {
    if (!start) return;
    const t = e.changedTouches[0];
    const res = decideSwipe({ dx: t.clientX - start.x, dy: t.clientY - start.y, dt: performance.now() - start.t });
    start = null;
    if (res && !(window.getSelection && String(window.getSelection()).length)) onSwipe(res);
  }, { passive: true });
  el.addEventListener('touchcancel', () => { start = null; }, { passive: true });
}
