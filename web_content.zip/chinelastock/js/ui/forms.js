// Formularios rápidos: productos, ventas, compras, precios, inventario, devoluciones, gastos, proveedores.
import { parseMoney, parseQty, parsePercent, centsToInput, roundDiv, allocate, ValidationError } from '../core/money.js';
import { normKey, newOpKey, PAYMENT_METHODS } from '../core/store.js';
import {
  esc, $, $$, money, openModal, toast, showFormError, busy, confirmDialog, compressImage,
  recent, remember, debounce, fmtDate, fmtDateTime, initials,
} from './dom.js';

let app; // { store, settings }
export function initForms(ctx) { app = ctx; }

const tryMoney = (s) => { try { return parseMoney(s); } catch { return null; } };
const tryQty = (s, min = 0) => { try { return parseQty(s, { min }); } catch { return null; } };

function nextSize(size) {
  const m = /^(\d+)(?:[.,](5))?$/.exec(String(size).trim());
  if (!m) return '';
  return String(Number(m[1]) + 1);
}

// =====================================================================
// PRODUCTO (alta, duplicado, añadir tallas, alta desde compra)
// =====================================================================
/**
 * opts.mode: 'new' | 'duplicate' | 'addVariants' | 'purchase'
 * opts.model: modelo origen (duplicate / addVariants)
 * opts.onSaved(result, rows)
 */
export async function openProductForm(opts = {}) {
  const mode = opts.mode || 'new';
  const cat = await app.store.loadCatalog();
  const rec = recent();
  const src = opts.model || null;
  const fixedModel = mode === 'addVariants';
  const showQty = mode !== 'purchase';
  const titles = { new: 'Añadir producto', duplicate: 'Duplicar producto', addVariants: `Añadir tallas · ${src?.name ?? ''}`, purchase: 'Producto nuevo para la compra' };

  const blankRow = (base = {}) => ({ size: '', color: base.color ?? '', sku: '', cost: base.cost ?? (rec.cost || ''), price: base.price ?? (rec.price || ''), qty: '' });
  let rows;
  if (mode === 'duplicate' && src) {
    rows = src.variants.map((v) => ({ size: v.size, color: v.color, sku: '', cost: centsToInput(v.cost), price: centsToInput(v.price), qty: '' }));
  } else if (mode === 'addVariants' && src?.variants.length) {
    const last = src.variants[src.variants.length - 1];
    rows = [{ ...blankRow({ color: last.color, cost: centsToInput(last.cost), price: centsToInput(last.price) }), size: nextSize(last.size) }];
  } else {
    rows = [blankRow()];
  }

  return openModal({
    title: titles[mode], size: 'lg',
    render(el, ctrl) {
      el.innerHTML = `
      <form class="form product-form" novalidate>
        <div class="form-error" role="alert" hidden></div>
        ${fixedModel ? `<p class="muted">Marca <b>${esc(src.brandName)}</b> · Modelo <b>${esc(src.name)}</b></p>` : `
        <div class="grid-2">
          <label class="field"><span>Marca *</span>
            <input name="brandName" list="dl-brands" autocomplete="off" required placeholder="Escribe o elige una marca" value="${esc(src?.brandName ?? '')}" autofocus>
            <small class="hint" data-hint="brand"></small>
            ${rec.brands?.length ? `<div class="chips" aria-label="Marcas recientes">${rec.brands.map((b) => `<button type="button" class="chip" data-brand="${esc(b)}">${esc(b)}</button>`).join('')}</div>` : ''}
          </label>
          <label class="field"><span>Modelo *</span>
            <input name="modelName" list="dl-models" autocomplete="off" required placeholder="p. ej. Classic" value="${esc(mode === 'duplicate' ? `${src.name} (copia)` : '')}">
            <small class="hint" data-hint="model"></small>
          </label>
        </div>
        <datalist id="dl-brands">${cat.brands.map((b) => `<option value="${esc(b.name)}">`).join('')}</datalist>
        <datalist id="dl-models"></datalist>
        <datalist id="dl-suppliers">${cat.suppliers.map((b) => `<option value="${esc(b.name)}">`).join('')}</datalist>
        <details class="more" ${mode === 'duplicate' ? 'open' : ''}>
          <summary>Proveedor, foto y notas (opcional)</summary>
          <div class="grid-2">
            <label class="field"><span>Proveedor</span><input name="supplierName" list="dl-suppliers" autocomplete="off" value="${esc(src?.supplierName ?? rec.supplier ?? '')}"></label>
            <div class="field"><span>Fotografía</span>
              <div class="photo-pick">
                <img class="photo-preview" alt="" ${src?.photo ? `src="${esc(src.photo)}"` : 'hidden'}>
                <label class="btn btn-sm">📷 Elegir foto<input type="file" name="photoFile" accept="image/*" hidden></label>
                <button type="button" class="btn btn-sm btn-ghost" data-photo-clear ${src?.photo ? '' : 'hidden'}>Quitar</button>
              </div>
            </div>
          </div>
          <label class="field"><span>Notas</span><textarea name="notes" rows="2">${esc(src?.notes ?? '')}</textarea></label>
        </details>`}
        <div class="section-head">
          <h3>Tallas y colores</h3>
          <div class="row-actions">
            <button type="button" class="btn btn-sm" data-add-row>+ Talla</button>
            <button type="button" class="btn btn-sm" data-range>Rango de tallas</button>
            <button type="button" class="btn btn-sm btn-ghost" data-fill title="Copiar coste y precio de la primera fila a todas">Copiar precios ↓</button>
          </div>
        </div>
        <div class="range-box" hidden>
          <label class="field"><span>Desde</span><input name="rFrom" inputmode="numeric" placeholder="35"></label>
          <label class="field"><span>Hasta</span><input name="rTo" inputmode="numeric" placeholder="44"></label>
          <label class="field"><span>Color</span><input name="rColor" placeholder="Negro"></label>
          <button type="button" class="btn btn-sm btn-primary" data-range-ok>Generar</button>
        </div>
        <div class="vrows ${showQty ? '' : 'no-qty'}" data-noswipe>
          <div class="vrow vhead" aria-hidden="true"><span>Talla *</span><span>Color</span><span>Ref. (auto)</span><span>Coste *</span><span>Venta *</span>${showQty ? '<span>Cant.</span>' : ''}<span></span></div>
          <div class="vbody"></div>
        </div>
        <p class="muted small">La referencia se genera automáticamente si la dejas vacía. Cada talla/color tiene su propio stock.</p>
        <div class="form-actions sticky">
          <button type="button" class="btn" data-close>Cancelar</button>
          ${mode !== 'purchase' ? '<button type="submit" class="btn" data-again>Guardar y añadir otro</button>' : ''}
          <button type="submit" class="btn btn-primary">Guardar</button>
        </div>
      </form>`;
      const form = $('form', el);
      const body = $('.vbody', form);
      let photo = src?.photo ?? null;

      const renderRows = () => {
        body.innerHTML = rows.map((r, i) => `
          <div class="vrow" data-i="${i}">
            <label class="vcell vc-size"><span>Talla</span><input name="variants.${i}.size" aria-label="Talla fila ${i + 1}" value="${esc(r.size)}" placeholder="Talla" data-k="size" autocomplete="off"></label>
            <label class="vcell vc-color"><span>Color</span><input name="variants.${i}.color" aria-label="Color fila ${i + 1}" value="${esc(r.color)}" placeholder="Color" data-k="color" list="dl-colors" autocomplete="off"></label>
            <label class="vcell vc-sku"><span>Ref.</span><input name="variants.${i}.sku" aria-label="Referencia fila ${i + 1}" value="${esc(r.sku)}" placeholder="Ref. (auto)" data-k="sku" autocomplete="off" autocapitalize="characters"></label>
            <label class="vcell vc-cost"><span>Coste</span><input name="variants.${i}.cost" aria-label="Coste fila ${i + 1}" value="${esc(r.cost)}" placeholder="Coste" inputmode="decimal" data-k="cost"></label>
            <label class="vcell vc-price"><span>Venta</span><input name="variants.${i}.price" aria-label="Precio venta fila ${i + 1}" value="${esc(r.price)}" placeholder="Venta" inputmode="decimal" data-k="price"></label>
            ${showQty ? `<label class="vcell vc-qty"><span>Cant.</span><input name="variants.${i}.qty" aria-label="Cantidad fila ${i + 1}" value="${esc(r.qty)}" placeholder="Cant." inputmode="numeric" data-k="qty"></label>` : ''}
            <button type="button" class="icon-btn" data-del="${i}" aria-label="Quitar fila ${i + 1}" ${rows.length === 1 ? 'disabled' : ''}>✕</button>
            <small class="row-issue" data-issue="${i}"></small>
          </div>`).join('');
        if (!$('#dl-colors')) {
          const colors = [...new Set(cat.variants.map((v) => v.color).filter(Boolean))];
          form.insertAdjacentHTML('beforeend', `<datalist id="dl-colors">${colors.map((c) => `<option value="${esc(c)}">`).join('')}</datalist>`);
        }
      };
      renderRows();

      const brandInput = $('[name=brandName]', form);
      const modelInput = $('[name=modelName]', form);
      const updateHints = async () => {
        if (!form.isConnected) return;
        if (fixedModel) {
          const res = await app.store.checkProductDraft({ brandName: src.brandName, modelName: src.name, variants: rows });
          if (!form.isConnected) return;
          paintIssues(res.rowIssues);
          return;
        }
        const b = brandInput.value.trim();
        const m = modelInput.value.trim();
        const brand = cat.brands.find((x) => x.nameKey === normKey(b));
        const bh = $('[data-hint=brand]', form);
        if (!b) bh.innerHTML = '';
        else if (brand) bh.innerHTML = '<span class="ok">✓ Marca registrada</span>';
        else bh.innerHTML = `Marca nueva. <button type="button" class="link" data-create-brand>Crear «${esc(b)}» ahora</button> o se creará al guardar.`;
        const models = brand ? cat.models.filter((x) => x.brandId === brand.id) : [];
        $('#dl-models').innerHTML = models.map((x) => `<option value="${esc(x.name)}">`).join('');
        const res = await app.store.checkProductDraft({ brandName: b, modelName: m, variants: rows });
        if (!form.isConnected) return;
        const mh = $('[data-hint=model]', form);
        mh.innerHTML = res.model ? `<span class="warn">Ya existe este modelo: las tallas se añadirán a él (${cat.modelById.get(res.model.id)?.variants.length ?? 0} existentes).</span>` : '';
        paintIssues(res.rowIssues);
      };
      const paintIssues = (issues) => {
        $$('[data-issue]', form).forEach((x) => { x.textContent = ''; });
        for (const it of issues) {
          const x = form.querySelector(`[data-issue="${it.row}"]`);
          if (x) x.textContent = x.textContent ? `${x.textContent} ${it.message}` : it.message;
        }
      };
      const hintsLater = debounce(updateHints, 250);
      if (brandInput.value || fixedModel) hintsLater();

      form.addEventListener('input', (e) => {
        ctrl.setDirty(true);
        const k = e.target.dataset.k;
        if (k) {
          const i = Number(e.target.closest('.vrow').dataset.i);
          rows[i][k] = e.target.value;
          if (k === 'size' || k === 'color' || k === 'sku') hintsLater();
        }
        if (e.target === brandInput || e.target === modelInput) hintsLater();
      });
      form.addEventListener('change', async (e) => {
        if (e.target.name === 'photoFile' && e.target.files[0]) {
          try {
            photo = await compressImage(e.target.files[0]);
            const img = $('.photo-preview', form);
            img.src = photo; img.hidden = false;
            $('[data-photo-clear]', form).hidden = false;
            ctrl.setDirty(true);
          } catch (err) { toast(err.message, 'error'); }
        }
      });
      form.addEventListener('click', async (e) => {
        const t = e.target;
        if (t.dataset.brand) { brandInput.value = t.dataset.brand; ctrl.setDirty(true); updateHints(); modelInput.focus(); return; }
        if (t.matches('[data-photo-clear]')) { photo = null; $('.photo-preview', form).hidden = true; t.hidden = true; return; }
        if (t.matches('[data-create-brand]')) {
          try {
            const b = await app.store.createBrand(brandInput.value);
            cat.brands.push(b);
            $('#dl-brands').insertAdjacentHTML('beforeend', `<option value="${esc(b.name)}">`);
            toast(`Marca «${b.name}» creada`);
            updateHints();
          } catch (err) { showFormError(form, err); }
          return;
        }
        if (t.matches('[data-add-row]')) {
          const last = rows[rows.length - 1];
          rows.push({ ...blankRow({ color: last.color, cost: last.cost, price: last.price }), size: nextSize(last.size) });
          renderRows();
          body.querySelector(`[data-i="${rows.length - 1}"] [data-k=size]`).focus();
          ctrl.setDirty(true);
          hintsLater();
          return;
        }
        if (t.dataset.del != null) {
          rows.splice(Number(t.dataset.del), 1);
          renderRows();
          hintsLater();
          return;
        }
        if (t.matches('[data-range]')) { $('.range-box', form).hidden = !$('.range-box', form).hidden; $('[name=rFrom]', form).focus(); return; }
        if (t.matches('[data-range-ok]')) {
          const a = Number($('[name=rFrom]', form).value);
          const b = Number($('[name=rTo]', form).value);
          const color = $('[name=rColor]', form).value.trim();
          if (!Number.isInteger(a) || !Number.isInteger(b) || a <= 0 || b < a || b - a > 30) {
            showFormError(form, new ValidationError('Rango de tallas no válido (p. ej. de 35 a 44).'));
            return;
          }
          showFormError(form, null);
          const base = rows.find((r) => r.cost || r.price) || blankRow();
          rows = rows.filter((r) => r.size.trim());
          for (let s = a; s <= b; s++) rows.push({ ...blankRow({ color, cost: base.cost, price: base.price }), size: String(s) });
          renderRows();
          $('.range-box', form).hidden = true;
          ctrl.setDirty(true);
          hintsLater();
          return;
        }
        if (t.matches('[data-fill]')) {
          const f = rows[0];
          rows.forEach((r) => { r.cost = f.cost; r.price = f.price; });
          renderRows();
          ctrl.setDirty(true);
        }
      });

      let again = false;
      form.addEventListener('click', (e) => { if (e.target.matches('[type=submit]')) again = e.target.hasAttribute('data-again'); }, true);
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        showFormError(form, null);
        const filled = rows.filter((r) => Object.entries(r).some(([k, v]) => k !== 'cost' && k !== 'price' && String(v).trim()));
        await busy(form, async () => {
          try {
            const input = {
              variants: filled.length ? filled : rows,
              photo,
            };
            if (fixedModel) input.modelId = src.id;
            else {
              input.brandName = brandInput.value;
              input.modelName = modelInput.value;
              input.supplierName = $('[name=supplierName]', form).value;
              input.notes = $('[name=notes]', form).value;
            }
            const res = await app.store.createProduct(input);
            const r0 = input.variants[0];
            remember({ brand: input.brandName?.trim() || src?.brandName, supplier: input.supplierName?.trim(), cost: r0.cost, price: r0.price });
            toast(`${res.addedToExisting ? 'Tallas añadidas' : 'Producto guardado'}: ${res.variantIds.length} ${res.variantIds.length === 1 ? 'variante' : 'variantes'}`);
            ctrl.setDirty(false);
            opts.onSaved?.(res, input.variants);
            if (again) {
              ctrl.close();
              openProductForm({ mode: 'new' });
            } else {
              ctrl.close();
            }
          } catch (err) {
            showFormError(form, err);
          }
        });
      });
    },
  });
}

// =====================================================================
// Edición del modelo
// =====================================================================
export async function openModelEdit(model) {
  const cat = await app.store.loadCatalog();
  openModal({
    title: 'Editar modelo', size: 'md',
    render(el, ctrl) {
      let photo = model.photo;
      el.innerHTML = `
      <form class="form" novalidate>
        <div class="form-error" role="alert" hidden></div>
        <label class="field"><span>Marca *</span><input name="brandName" list="dl-brands2" value="${esc(model.brandName)}" required></label>
        <label class="field"><span>Modelo *</span><input name="modelName" value="${esc(model.name)}" required></label>
        <label class="field"><span>Proveedor</span><input name="supplierName" list="dl-sup2" value="${esc(model.supplierName)}"></label>
        <datalist id="dl-brands2">${cat.brands.map((b) => `<option value="${esc(b.name)}">`).join('')}</datalist>
        <datalist id="dl-sup2">${cat.suppliers.map((b) => `<option value="${esc(b.name)}">`).join('')}</datalist>
        <div class="field"><span>Fotografía</span>
          <div class="photo-pick">
            <img class="photo-preview" alt="" ${photo ? `src="${esc(photo)}"` : 'hidden'}>
            <label class="btn btn-sm">📷 Elegir foto<input type="file" name="photoFile" accept="image/*" hidden></label>
            <button type="button" class="btn btn-sm btn-ghost" data-photo-clear ${photo ? '' : 'hidden'}>Quitar</button>
          </div>
        </div>
        <label class="field"><span>Notas</span><textarea name="notes" rows="3">${esc(model.notes)}</textarea></label>
        <div class="form-actions"><button type="button" class="btn" data-close>Cancelar</button><button class="btn btn-primary">Guardar cambios</button></div>
      </form>`;
      const form = $('form', el);
      form.addEventListener('input', () => ctrl.setDirty(true));
      form.addEventListener('change', async (e) => {
        if (e.target.name === 'photoFile' && e.target.files[0]) {
          try {
            photo = await compressImage(e.target.files[0]);
            Object.assign($('.photo-preview', form), { src: photo, hidden: false });
            $('[data-photo-clear]', form).hidden = false;
            ctrl.setDirty(true);
          } catch (err) { toast(err.message, 'error'); }
        }
      });
      $('[data-photo-clear]', form).onclick = (e) => { photo = null; $('.photo-preview', form).hidden = true; e.target.hidden = true; ctrl.setDirty(true); };
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        busy(form, async () => {
          try {
            await app.store.updateModel(model.id, {
              brandName: form.brandName.value, name: form.modelName.value, supplierName: form.supplierName.value, notes: form.notes.value, photo,
            });
            ctrl.setDirty(false); ctrl.close(); toast('Modelo actualizado');
          } catch (err) { showFormError(form, err); }
        });
      });
    },
  });
}

export function openVariantEdit(v) {
  openModal({
    title: `Editar ${v.label}`, size: 'sm',
    render(el, ctrl) {
      el.innerHTML = `
      <form class="form" novalidate>
        <div class="form-error" role="alert" hidden></div>
        <div class="grid-2">
          <label class="field"><span>Talla *</span><input name="size" value="${esc(v.size)}"></label>
          <label class="field"><span>Color</span><input name="color" value="${esc(v.color)}"></label>
        </div>
        <label class="field"><span>Referencia *</span><input name="sku" value="${esc(v.sku)}" autocapitalize="characters"></label>
        <label class="check"><input type="checkbox" name="active" ${v.active === false ? '' : 'checked'}> Activa (desmarca para archivarla: no aparecerá en ventas)</label>
        <div class="form-actions"><button type="button" class="btn" data-close>Cancelar</button><button class="btn btn-primary">Guardar</button></div>
      </form>`;
      const form = $('form', el);
      form.addEventListener('input', () => ctrl.setDirty(true));
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        busy(form, async () => {
          try {
            await app.store.updateVariant(v.id, { size: form.size.value, color: form.color.value, sku: form.sku.value, active: form.active.checked });
            ctrl.setDirty(false); ctrl.close(); toast('Variante actualizada');
          } catch (err) { showFormError(form, err); }
        });
      });
    },
  });
}

// =====================================================================
// PRECIOS
// =====================================================================
/** Edición en línea de un precio dentro de una tabla. */
export function inlinePriceEdit(btn, v, field) {
  const cell = btn.parentElement;
  const old = btn.outerHTML;
  const wrap = document.createElement('span');
  wrap.className = 'inline-editor';
  wrap.innerHTML = `<input aria-label="${field === 'price' ? 'Nuevo precio de venta' : 'Nuevo precio de compra'}" inputmode="decimal" value="${esc(centsToInput(v[field]))}"><button type="button" class="icon-btn ok" aria-label="Guardar precio">✓</button><button type="button" class="icon-btn" aria-label="Cancelar">✕</button><small class="inline-err"></small>`;
  btn.replaceWith(wrap);
  const input = $('input', wrap);
  input.focus();
  input.select();
  let done = false;
  const restore = () => { if (wrap.isConnected) wrap.outerHTML = old; };
  const cancel = () => { if (done) return; done = true; restore(); };
  const save = async () => {
    if (done) return;
    try {
      const res = await app.store.setPrice(v.id, field, input.value, { reason: 'Edición rápida' });
      done = true;
      toast(res.changed ? `${field === 'price' ? 'Precio de venta' : 'Precio de compra'}: ${money(res.old)} → ${money(res.new)}` : 'Sin cambios');
      if (!res.changed) restore();
    } catch (err) {
      $('.inline-err', wrap).textContent = err.message;
      input.classList.add('invalid');
      input.focus();
    }
  };
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); save(); }
    if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); cancel(); }
  });
  wrap.querySelector('.ok').onclick = save;
  wrap.querySelectorAll('.icon-btn')[1].onclick = cancel;
  void cell;
}

export function openBulkPrice(variantIds) {
  openModal({
    title: `Cambiar precios (${variantIds.length})`, size: 'lg',
    render(el, ctrl) {
      el.innerHTML = `
      <form class="form" novalidate>
        <div class="form-error" role="alert" hidden></div>
        <div class="grid-3">
          <label class="field"><span>Precio a cambiar</span>
            <select name="field"><option value="price">Precio de venta</option><option value="cost">Precio de compra</option></select></label>
          <label class="field"><span>Tipo de cambio</span>
            <select name="mode"><option value="percent">Porcentaje (%)</option><option value="amount">Importe fijo</option><option value="set">Fijar un precio</option></select></label>
          <label class="field" data-dir><span>Sentido</span>
            <select name="direction"><option value="up">Subir</option><option value="down">Bajar</option></select></label>
          <label class="field"><span data-vlabel>Porcentaje</span><input name="value" inputmode="decimal" placeholder="10" autofocus></label>
          <label class="field" data-round><span>Redondear a</span>
            <select name="rounding"><option value="0">Sin redondeo</option><option value="5">0,05</option><option value="10">0,10</option><option value="50">0,50</option><option value="100">1,00</option></select></label>
          <label class="field"><span>Motivo (opcional)</span><input name="reason" placeholder="Subida de temporada"></label>
        </div>
        <div class="form-actions"><button type="button" class="btn" data-close>Cancelar</button><button class="btn btn-primary" data-preview>Ver vista previa</button></div>
        <div class="preview"></div>
      </form>`;
      const form = $('form', el);
      const syncMode = () => {
        const m = form.mode.value;
        $('[data-dir]', form).hidden = m === 'set';
        $('[data-round]', form).hidden = m === 'set';
        $('[data-vlabel]', form).textContent = m === 'percent' ? 'Porcentaje' : m === 'amount' ? 'Importe' : 'Nuevo precio';
        form.value.placeholder = m === 'percent' ? '10' : '0,50';
      };
      syncMode();
      let rows = null;
      form.addEventListener('input', (e) => {
        ctrl.setDirty(true);
        if (e.target.name === 'mode') syncMode();
        if (rows) { rows = null; $('.preview', form).innerHTML = '<p class="muted">Los datos cambiaron: vuelve a generar la vista previa.</p>'; }
      });
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        busy(form, async () => {
          showFormError(form, null);
          try {
            const mode = form.mode.value;
            let value = form.value.value;
            if (mode === 'percent' && form.direction.value === 'down') value = `-${String(value).replace(/^-/, '')}`;
            rows = await app.store.previewBulkPrice({ variantIds, field: form.field.value, mode, value, direction: form.direction.value, rounding: Number(form.rounding.value) });
            const errs = rows.filter((r) => r.error).length;
            const changes = rows.filter((r) => r.diff !== 0).length;
            $('.preview', form).innerHTML = `
              <h3>Vista previa · ${changes} cambios</h3>
              <div class="table-wrap" data-noswipe><table class="table">
                <thead><tr><th>Producto</th><th class="num">Actual</th><th class="num">Nuevo</th><th class="num">Diferencia</th></tr></thead>
                <tbody>${rows.map((r) => `<tr class="${r.error ? 'row-err' : ''}"><td>${esc(r.label)}<br><small class="muted">${esc(r.sku)}</small>${r.error ? `<br><small class="err">${esc(r.error)}</small>` : ''}${r.warning ? `<br><small class="warn">${esc(r.warning)}</small>` : ''}</td>
                  <td class="num">${money(r.old)}</td><td class="num"><b>${money(r.new)}</b></td><td class="num ${r.diff > 0 ? 'pos' : r.diff < 0 ? 'neg' : ''}">${r.diff > 0 ? '+' : ''}${money(r.diff)}</td></tr>`).join('')}</tbody>
              </table></div>
              <div class="form-actions">
                <button type="button" class="btn" data-close>Cancelar sin cambiar nada</button>
                <button type="button" class="btn btn-primary" data-apply ${errs || !changes ? 'disabled' : ''}>Confirmar ${changes} cambios</button>
              </div>`;
            $('[data-apply]', form).onclick = () => busy(form, async () => {
              try {
                const res = await app.store.applyBulkPrice(rows, { reason: form.reason.value || 'Cambio masivo' });
                ctrl.setDirty(false); ctrl.close();
                toast(`${res.changed} precios actualizados`);
              } catch (err) { showFormError(form, err); }
            });
          } catch (err) {
            rows = null;
            $('.preview', form).innerHTML = '';
            showFormError(form, err);
          }
        });
      });
    },
  });
}

export async function openPriceHistory(v) {
  const hist = await app.store.listPriceHistory({ variantId: v.id });
  openModal({
    title: `Historial de precios · ${v.label}`, size: 'md',
    render(el) {
      el.innerHTML = hist.length ? `<div class="table-wrap" data-noswipe><table class="table"><thead><tr><th>Fecha</th><th>Tipo</th><th class="num">Antes</th><th class="num">Después</th><th>Motivo</th></tr></thead><tbody>
        ${hist.map((h) => `<tr><td>${fmtDateTime(h.at)}</td><td>${h.field === 'price' ? 'Venta' : 'Compra'}</td><td class="num">${h.old == null ? '—' : money(h.old)}</td><td class="num">${money(h.new)}</td><td>${esc(h.reason)}</td></tr>`).join('')}
      </tbody></table></div>` : '<p class="muted">Sin cambios registrados.</p>';
    },
  });
}

// =====================================================================
// INVENTARIO: ajuste por recuento
// =====================================================================
export function openStockAdjust(v) {
  openModal({
    title: 'Ajustar existencias', size: 'sm',
    render(el, ctrl) {
      el.innerHTML = `
      <form class="form" novalidate>
        <p><b>${esc(v.label)}</b><br><span class="muted">Ref. ${esc(v.sku)} · existencias registradas: <b>${v.stock}</b></span></p>
        <div class="form-error" role="alert" hidden></div>
        <label class="field"><span>Existencias reales *</span>
          <div class="stepper"><button type="button" class="icon-btn" data-step="-1" aria-label="Restar">−</button><input name="stock" inputmode="numeric" value="${v.stock}" autofocus><button type="button" class="icon-btn" data-step="1" aria-label="Sumar">+</button></div></label>
        <label class="field"><span>Motivo *</span><input name="reason" list="dl-reasons" placeholder="Recuento"></label>
        <datalist id="dl-reasons"><option value="Recuento"><option value="Rotura / defecto"><option value="Pérdida"><option value="Regalo / muestra"><option value="Corrección de error"></datalist>
        <p class="muted small">Para entradas de mercancía usa «Compras», así se registra el coste.</p>
        <div class="form-actions"><button type="button" class="btn" data-close>Cancelar</button><button class="btn btn-primary">Guardar ajuste</button></div>
      </form>`;
      const form = $('form', el);
      form.addEventListener('input', () => ctrl.setDirty(true));
      form.addEventListener('click', (e) => {
        const s = e.target.dataset.step;
        if (s) { const n = (tryQty(form.stock.value) ?? 0) + Number(s); form.stock.value = Math.max(0, n); ctrl.setDirty(true); }
      });
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        busy(form, async () => {
          try {
            const r = await app.store.setStock(v.id, form.stock.value, form.reason.value);
            ctrl.setDirty(false); ctrl.close();
            toast(r.delta ? `Existencias ajustadas (${r.delta > 0 ? '+' : ''}${r.delta})` : 'Sin cambios');
          } catch (err) { showFormError(form, err); }
        });
      });
    },
  });
}

// =====================================================================
// Selector de productos para ventas y compras
// =====================================================================
function productPicker(container, { onPick, stockAware }) {
  container.innerHTML = `
    <label class="field search-field"><span>Añadir producto</span>
      <input type="search" name="q" placeholder="Busca modelo, marca, referencia, talla o color" autocomplete="off" enterkeyhint="search"></label>
    <div class="pick-results" role="listbox"></div>`;
  const input = $('input', container);
  const list = $('.pick-results', container);
  let catalog = null;
  const run = async () => {
    const q = input.value.trim();
    if (!q) { list.innerHTML = ''; return; }
    catalog = catalog || await app.store.loadCatalog();
    const res = await app.store.searchVariants(q, { limit: 25, catalog });
    list.innerHTML = res.length ? res.map((v) => {
      const out = stockAware && v.stock <= 0;
      return `<button type="button" class="pick" role="option" data-vid="${v.id}" ${out ? 'disabled' : ''}>
        <span class="pick-main">${esc(v.label)}<small class="muted">${esc(v.sku)}</small></span>
        <span class="pick-side"><b>${money(stockAware ? v.price : v.cost)}</b><small class="${v.stock <= 0 ? 'err' : 'muted'}">${v.stock <= 0 ? 'Sin stock' : `${v.stock} uds`}</small></span>
      </button>`;
    }).join('') : '<p class="muted small">Sin resultados.</p>';
  };
  const runLater = debounce(run, 150);
  input.addEventListener('input', runLater);
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      const first = list.querySelector('.pick:not([disabled])');
      if (first) first.click();
    }
  });
  list.addEventListener('click', (e) => {
    const b = e.target.closest('[data-vid]');
    if (!b) return;
    const v = catalog.variants.find((x) => x.id === Number(b.dataset.vid));
    onPick(v);
    input.value = '';
    list.innerHTML = '';
    input.focus();
  });
  return { refresh() { catalog = null; }, input, async pickById(id) { catalog = await app.store.loadCatalog(); const v = catalog.variants.find((x) => x.id === id); if (v) onPick(v); } };
}

// =====================================================================
// VENTA
// =====================================================================
export function openSaleForm() {
  const allow = app.settings.allowPriceOverride;
  const rec = recent();
  return openModal({
    title: 'Nueva venta', size: 'lg',
    render(el, ctrl) {
      let opKey = newOpKey();
      let lines = [];
      el.innerHTML = `
      <form class="form sale-form" novalidate>
        <div class="form-error" role="alert" hidden></div>
        <div class="picker"></div>
        <div class="lines"></div>
        <div class="grid-3">
          <label class="field"><span>Descuento</span>
            <div class="input-group"><input name="discount" inputmode="decimal" placeholder="0"><select name="discountType" aria-label="Tipo de descuento"><option value="amount">€</option><option value="percent">%</option></select></div></label>
          <label class="field"><span>Forma de pago</span><select name="payment">${PAYMENT_METHODS.map((p) => `<option ${p === (rec.payment || 'Efectivo') ? 'selected' : ''}>${p}</option>`).join('')}</select></label>
          <label class="field"><span>Fecha</span><input type="date" name="date" value="${app.store.today()}" max="${app.store.today()}"></label>
        </div>
        <label class="field"><span>Notas (opcional)</span><input name="notes" placeholder="Cliente, observaciones…"></label>
        <div class="totals"></div>
        <div class="form-actions sticky">
          <button type="button" class="btn" data-close>Cancelar</button>
          <button type="submit" class="btn" data-again>Guardar y nueva</button>
          <button type="submit" class="btn btn-primary">Guardar venta</button>
        </div>
      </form>`;
      const form = $('form', el);
      const picker = productPicker($('.picker', form), {
        stockAware: true,
        onPick(v) {
          const ex = lines.find((l) => l.v.id === v.id);
          if (ex) ex.qty = String((tryQty(ex.qty) || 0) + 1);
          else lines.push({ v, qty: '1', price: centsToInput(v.price) });
          ctrl.setDirty(true);
          renderLines();
        },
      });
      setTimeout(() => picker.input.focus(), 50);
      const renderLines = () => {
        $('.lines', form).innerHTML = lines.length ? lines.map((l, i) => {
          const q = tryQty(l.qty, 1);
          const over = q != null && q > l.v.stock;
          return `<div class="line" data-i="${i}">
            <div class="line-info"><b>${esc(l.v.label)}</b><small class="muted">${esc(l.v.sku)} · ${l.v.stock} en stock</small>${over ? '<small class="err">Supera las existencias</small>' : ''}</div>
            <div class="stepper"><button type="button" class="icon-btn" data-step="-1" aria-label="Menos">−</button><input data-k="qty" aria-label="Cantidad" inputmode="numeric" value="${esc(l.qty)}"><button type="button" class="icon-btn" data-step="1" aria-label="Más">+</button></div>
            <label class="line-price"><span class="sr-only">Precio unitario</span><input data-k="price" inputmode="decimal" value="${esc(l.price)}" ${allow ? '' : 'readonly'} aria-label="Precio unitario"></label>
            <span class="line-total num">${(() => { const p = tryMoney(l.price); return q != null && p != null ? money(q * p) : '—'; })()}</span>
            <button type="button" class="icon-btn" data-del aria-label="Quitar">✕</button>
          </div>`;
        }).join('') : '<p class="empty-lines">Busca un producto para añadirlo a la venta.</p>';
        renderTotals();
      };
      const calc = () => {
        let subtotal = 0;
        for (const l of lines) {
          const q = tryQty(l.qty, 1); const p = tryMoney(l.price);
          if (q == null || p == null) return null;
          subtotal += q * p;
        }
        let disc = 0;
        const dv = form.discount.value.trim();
        if (dv) {
          if (form.discountType.value === 'percent') {
            try { const bp = parsePercent(dv); if (bp < 0 || bp > 10000) return { subtotal, error: 'Descuento entre 0 y 100 %' }; disc = roundDiv(subtotal * bp, 10000); } catch { return { subtotal, error: 'Descuento no válido' }; }
          } else {
            const c = tryMoney(dv); if (c == null) return { subtotal, error: 'Descuento no válido' }; disc = c;
          }
        }
        if (disc > subtotal) return { subtotal, error: 'El descuento supera el subtotal' };
        void allocate;
        return { subtotal, disc, total: subtotal - disc };
      };
      const renderTotals = () => {
        const c = calc();
        $('.totals', form).innerHTML = !c ? '<p class="err small">Revisa cantidades y precios.</p>' : `
          <div><span>Subtotal</span><span class="num">${money(c.subtotal)}</span></div>
          ${c.error ? `<div class="err">${esc(c.error)}</div>` : `<div><span>Descuento</span><span class="num">−${money(c.disc)}</span></div>
          <div class="grand"><span>Total</span><span class="num" data-total>${money(c.total)}</span></div>`}`;
      };
      renderLines();
      form.addEventListener('input', (e) => {
        ctrl.setDirty(true);
        const k = e.target.dataset.k;
        if (k) {
          const i = Number(e.target.closest('.line').dataset.i);
          lines[i][k] = e.target.value;
          const row = e.target.closest('.line');
          const q = tryQty(lines[i].qty, 1); const p = tryMoney(lines[i].price);
          $('.line-total', row).textContent = q != null && p != null ? money(q * p) : '—';
          renderTotals();
        } else if (e.target.name === 'discount' || e.target.name === 'discountType') renderTotals();
      });
      // diferido: el evento «change» puede llegar mientras se reemplaza la lista (al perder el foco)
      form.addEventListener('change', (e) => { if (e.target.dataset.k === 'qty') setTimeout(renderLines, 0); });
      form.addEventListener('click', (e) => {
        const row = e.target.closest('.line');
        if (!row) return;
        const i = Number(row.dataset.i);
        if (e.target.dataset.step) {
          const n = Math.max(1, (tryQty(lines[i].qty) || 0) + Number(e.target.dataset.step));
          lines[i].qty = String(n);
          renderLines();
        } else if (e.target.matches('[data-del]')) {
          lines.splice(i, 1);
          renderLines();
        }
      });
      let again = false;
      form.addEventListener('click', (e) => { if (e.target.matches('[type=submit]')) again = e.target.hasAttribute('data-again'); }, true);
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        showFormError(form, null);
        busy(form, async () => {
          try {
            const res = await app.store.createSale({
              date: form.date.value,
              lines: lines.map((l) => ({ variantId: l.v.id, qty: l.qty, unitPrice: allow ? l.price : null })),
              discount: form.discount.value.trim() ? { type: form.discountType.value, value: form.discount.value } : null,
              paymentMethod: form.payment.value,
              notes: form.notes.value,
              opKey,
            });
            remember({ payment: form.payment.value });
            toast(res.duplicate ? 'Esta venta ya estaba guardada' : `Venta #${res.id} guardada · ${money(res.total)}`);
            ctrl.setDirty(false);
            if (again) {
              lines = []; opKey = newOpKey();
              form.discount.value = ''; form.notes.value = '';
              picker.refresh(); renderLines(); picker.input.focus();
            } else ctrl.close();
          } catch (err) { showFormError(form, err); }
        });
      });
    },
  });
}

// =====================================================================
// COMPRA
// =====================================================================
export async function openPurchaseForm() {
  const cat = await app.store.loadCatalog();
  const rec = recent();
  return openModal({
    title: 'Nueva compra', size: 'lg',
    render(el, ctrl) {
      let opKey = newOpKey();
      let lines = [];
      el.innerHTML = `
      <form class="form" novalidate>
        <div class="form-error" role="alert" hidden></div>
        <div class="grid-3">
          <label class="field"><span>Proveedor</span><input name="supplier" list="dl-psup" value="${esc(rec.supplier || '')}" autocomplete="off"></label>
          <label class="field"><span>Fecha</span><input type="date" name="date" value="${app.store.today()}"></label>
          <label class="field"><span>Estado</span><select name="status"><option value="received">Mercancía recibida</option><option value="pending">Pendiente de recibir</option></select></label>
        </div>
        <datalist id="dl-psup">${cat.suppliers.map((s) => `<option value="${esc(s.name)}">`).join('')}</datalist>
        <div class="picker-row"><div class="picker"></div><button type="button" class="btn btn-sm" data-newprod>+ Producto nuevo</button></div>
        <div class="lines"></div>
        <label class="check"><input type="checkbox" name="updateCost" checked> Actualizar el precio de compra de los productos con estos costes</label>
        <label class="field"><span>Notas (opcional)</span><input name="notes" placeholder="Nº de factura, observaciones…"></label>
        <div class="totals"></div>
        <div class="form-actions sticky">
          <button type="button" class="btn" data-close>Cancelar</button>
          <button type="submit" class="btn" data-again>Guardar y añadir otra</button>
          <button type="submit" class="btn btn-primary">Guardar compra</button>
        </div>
      </form>`;
      const form = $('form', el);
      const addLine = (v, qty = '1') => {
        const ex = lines.find((l) => l.v.id === v.id);
        if (ex) ex.qty = String((tryQty(ex.qty) || 0) + Number(qty));
        else lines.push({ v, qty: String(qty), cost: centsToInput(v.cost) });
        ctrl.setDirty(true);
        renderLines();
      };
      const picker = productPicker($('.picker', form), { stockAware: false, onPick: (v) => addLine(v) });
      const renderLines = () => {
        $('.lines', form).innerHTML = lines.length ? lines.map((l, i) => `
          <div class="line" data-i="${i}">
            <div class="line-info"><b>${esc(l.v.label)}</b><small class="muted">${esc(l.v.sku)} · ${l.v.stock} en stock</small></div>
            <div class="stepper"><button type="button" class="icon-btn" data-step="-1" aria-label="Menos">−</button><input data-k="qty" aria-label="Cantidad" inputmode="numeric" value="${esc(l.qty)}"><button type="button" class="icon-btn" data-step="1" aria-label="Más">+</button></div>
            <label class="line-price"><span class="sr-only">Coste unitario</span><input data-k="cost" inputmode="decimal" value="${esc(l.cost)}" aria-label="Coste unitario"></label>
            <span class="line-total num">${(() => { const q = tryQty(l.qty, 1); const c = tryMoney(l.cost); return q != null && c != null ? money(q * c) : '—'; })()}</span>
            <button type="button" class="icon-btn" data-del aria-label="Quitar">✕</button>
          </div>`).join('') : '<p class="empty-lines">Busca los productos comprados o crea uno nuevo.</p>';
        renderTotals();
      };
      const renderTotals = () => {
        let t = 0; let units = 0;
        for (const l of lines) {
          const q = tryQty(l.qty, 1); const c = tryMoney(l.cost);
          if (q == null || c == null) { $('.totals', form).innerHTML = '<p class="err small">Revisa cantidades y costes.</p>'; return; }
          t += q * c; units += q;
        }
        $('.totals', form).innerHTML = `<div><span>Unidades</span><span class="num">${units}</span></div><div class="grand"><span>Total compra</span><span class="num">${money(t)}</span></div>`;
      };
      renderLines();
      form.addEventListener('input', (e) => {
        ctrl.setDirty(true);
        const k = e.target.dataset.k;
        if (k) {
          const row = e.target.closest('.line');
          const l = lines[Number(row.dataset.i)];
          l[k] = e.target.value;
          const q = tryQty(l.qty, 1); const c = tryMoney(l.cost);
          $('.line-total', row).textContent = q != null && c != null ? money(q * c) : '—';
          renderTotals();
        }
      });
      form.addEventListener('click', (e) => {
        if (e.target.matches('[data-newprod]')) {
          openProductForm({
            mode: 'purchase',
            onSaved: async (res, rows) => {
              const c2 = await app.store.loadCatalog();
              picker.refresh();
              res.variantIds.forEach((id) => { const v = c2.variants.find((x) => x.id === id); if (v) addLine(v, '1'); });
              void rows;
            },
          });
          return;
        }
        const row = e.target.closest('.line');
        if (!row) return;
        const i = Number(row.dataset.i);
        if (e.target.dataset.step) { lines[i].qty = String(Math.max(1, (tryQty(lines[i].qty) || 0) + Number(e.target.dataset.step))); renderLines(); }
        if (e.target.matches('[data-del]')) { lines.splice(i, 1); renderLines(); }
      });
      let again = false;
      form.addEventListener('click', (e) => { if (e.target.matches('[type=submit]')) again = e.target.hasAttribute('data-again'); }, true);
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        showFormError(form, null);
        busy(form, async () => {
          try {
            const res = await app.store.createPurchase({
              supplierName: form.supplier.value, date: form.date.value, status: form.status.value, notes: form.notes.value,
              updateCost: form.updateCost.checked, opKey,
              lines: lines.map((l) => ({ variantId: l.v.id, qty: l.qty, unitCost: l.cost })),
            });
            remember({ supplier: form.supplier.value.trim() });
            toast(res.duplicate ? 'Esta compra ya estaba guardada' : `Compra #${res.id} guardada${form.status.value === 'pending' ? ' (pendiente de recibir)' : ''}`);
            ctrl.setDirty(false);
            if (again) { lines = []; opKey = newOpKey(); form.notes.value = ''; picker.refresh(); renderLines(); } else ctrl.close();
          } catch (err) { showFormError(form, err); }
        });
      });
    },
  });
}

// =====================================================================
// Detalle de venta y devoluciones
// =====================================================================
const SALE_STATUS = { ok: ['Completada', 'ok'], partial: ['Devolución parcial', 'warn'], returned: ['Devuelta', 'muted'] };
export const saleStatusBadge = (s) => { const [t, c] = SALE_STATUS[s] || [s, '']; return `<span class="badge badge-${c}">${t}</span>`; };

export async function openSaleDetail(id) {
  const ctrl = openModal({ title: `Venta #${id}`, size: 'md', render() {} });
  const paint = async () => {
    const s = await app.store.getSale(id);
    if (!s) { ctrl.el.innerHTML = '<p>La venta no existe.</p>'; return; }
    const returns = (await app.store.listReturns()).filter((r) => r.saleId === id);
    const refunded = returns.reduce((a, r) => a + r.refund, 0);
    ctrl.el.innerHTML = `
      <p class="muted">${fmtDate(s.date)} · ${esc(s.paymentMethod)} · ${saleStatusBadge(s.status)}</p>
      <div class="table-wrap" data-noswipe><table class="table">
        <thead><tr><th>Producto</th><th class="num">Cant.</th><th class="num">Precio</th><th class="num">Importe</th></tr></thead>
        <tbody>${s.lines.map((l) => `<tr><td>${esc(l.label)}<br><small class="muted">${esc(l.sku)}${l.unitPrice !== l.listPrice ? ` · precio de lista ${money(l.listPrice)}` : ''}${l.returnedQty ? ` · <span class="warn">${l.returnedQty} devuelta(s)</span>` : ''}</small></td><td class="num">${l.qty}</td><td class="num">${money(l.unitPrice)}</td><td class="num">${money(l.lineTotal)}</td></tr>`).join('')}</tbody>
      </table></div>
      <div class="totals">
        <div><span>Subtotal</span><span class="num">${money(s.subtotal)}</span></div>
        <div><span>Descuento</span><span class="num">−${money(s.discount)}</span></div>
        <div class="grand"><span>Total</span><span class="num">${money(s.total)}</span></div>
        ${refunded ? `<div><span>Reembolsado</span><span class="num neg">−${money(refunded)}</span></div>` : ''}
        <div class="muted"><span>Coste de la mercancía</span><span class="num">${money(s.cost)}</span></div>
        <div class="muted"><span>Margen bruto</span><span class="num">${money(s.total - s.cost)}</span></div>
      </div>
      ${s.notes ? `<p><b>Notas:</b> ${esc(s.notes)}</p>` : ''}
      ${returns.length ? `<h3>Devoluciones</h3><ul class="plain">${returns.map((r) => `<li>${fmtDate(r.date)} · ${r.lines.map((l) => `${l.qty}× ${esc(l.label)}${l.restock ? '' : ' (no vuelve al stock)'}`).join(', ')} · ${money(r.refund)}${r.reason ? ` · ${esc(r.reason)}` : ''}</li>`).join('')}</ul>` : ''}
      <div class="form-actions">
        <button type="button" class="btn" data-close>Cerrar</button>
        ${s.status !== 'returned' ? '<button type="button" class="btn btn-primary" data-return>Registrar devolución</button>' : ''}
      </div>`;
    const b = ctrl.el.querySelector('[data-return]');
    if (b) b.onclick = () => openReturnForm(s);
  };
  await paint();
  const onChange = () => paint();
  app.store.addEventListener('change', onChange);
  ctrl.onDispose(() => app.store.removeEventListener('change', onChange));
}

export function openReturnForm(sale) {
  openModal({
    title: `Devolución de la venta #${sale.id}`, size: 'md',
    render(el, ctrl) {
      const opKey = newOpKey();
      el.innerHTML = `
      <form class="form" novalidate>
        <div class="form-error" role="alert" hidden></div>
        ${sale.lines.map((l, i) => {
          const avail = l.qty - l.returnedQty;
          return `<div class="ret-line ${avail ? '' : 'disabled'}" data-i="${i}">
            <div class="line-info"><b>${esc(l.label)}</b><small class="muted">Vendidas ${l.qty} · ya devueltas ${l.returnedQty} · ${money(l.net / l.qty)} c/u aprox.</small></div>
            <label class="field"><span>Unidades</span><input name="q${i}" inputmode="numeric" value="0" ${avail ? '' : 'disabled'} data-avail="${avail}"></label>
            <label class="check"><input type="checkbox" name="r${i}" checked ${avail ? '' : 'disabled'}> Vuelve al stock</label>
          </div>`;
        }).join('')}
        <div class="grid-2">
          <label class="field"><span>Fecha</span><input type="date" name="date" value="${app.store.today()}" min="${sale.date}"></label>
          <label class="field"><span>Motivo</span><input name="reason" placeholder="Cambio de talla, defecto…"></label>
        </div>
        <p class="muted small">Desmarca «Vuelve al stock» si el producto está dañado: se reembolsa pero no se suma al inventario.</p>
        <div class="totals"><div class="grand"><span>A reembolsar</span><span class="num" data-refund>${money(0)}</span></div></div>
        <div class="form-actions"><button type="button" class="btn" data-close>Cancelar</button><button class="btn btn-primary">Confirmar devolución</button></div>
      </form>`;
      const form = $('form', el);
      const recompute = () => {
        let total = 0;
        sale.lines.forEach((l, i) => {
          const q = tryQty(form[`q${i}`].value) || 0;
          if (q > 0 && q <= l.qty - l.returnedQty) total += roundDiv(l.net * (l.returnedQty + q), l.qty) - roundDiv(l.net * l.returnedQty, l.qty);
        });
        $('[data-refund]', form).textContent = money(total);
      };
      form.addEventListener('input', () => { ctrl.setDirty(true); recompute(); });
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        busy(form, async () => {
          try {
            const lines = sale.lines.map((l, i) => ({ index: i, qty: form[`q${i}`].value, restock: form[`r${i}`].checked }))
              .filter((l, i) => sale.lines[i].qty - sale.lines[i].returnedQty > 0);
            const res = await app.store.createReturn({ saleId: sale.id, date: form.date.value, lines, reason: form.reason.value, opKey });
            ctrl.setDirty(false); ctrl.close();
            toast(`Devolución registrada · ${money(res.refund)}`);
          } catch (err) { showFormError(form, err); }
        });
      });
    },
  });
}

// =====================================================================
// Compras: detalle
// =====================================================================
export async function openPurchaseDetail(p) {
  openModal({
    title: `Compra #${p.id}`, size: 'md',
    render(el, ctrl) {
      el.innerHTML = `
        <p class="muted">${fmtDate(p.date)}${p.supplier ? ` · ${esc(p.supplier)}` : ''} · ${p.status === 'received' ? `Recibida el ${fmtDate(p.receivedDate)}` : p.status === 'pending' ? 'Pendiente de recibir' : 'Anulada'}</p>
        <div class="table-wrap" data-noswipe><table class="table"><thead><tr><th>Producto</th><th class="num">Cant.</th><th class="num">Coste</th><th class="num">Total</th></tr></thead>
        <tbody>${p.lines.map((l) => `<tr><td>${esc(l.label)}<br><small class="muted">${esc(l.sku)}</small></td><td class="num">${l.qty}</td><td class="num">${money(l.unitCost)}</td><td class="num">${money(l.lineTotal)}</td></tr>`).join('')}</tbody></table></div>
        <div class="totals"><div class="grand"><span>Total</span><span class="num">${money(p.total)}</span></div></div>
        ${p.notes ? `<p><b>Notas:</b> ${esc(p.notes)}</p>` : ''}
        <div class="form-actions"><button type="button" class="btn" data-close>Cerrar</button>
        ${p.status === 'pending' ? '<button type="button" class="btn btn-danger" data-cancel>Anular</button><button type="button" class="btn btn-primary" data-receive>Marcar como recibida</button>' : ''}</div>`;
      const rcv = $('[data-receive]', el);
      if (rcv) {
        rcv.onclick = () => receivePurchase(p, ctrl);
        $('[data-cancel]', el).onclick = async () => {
          if (!await confirmDialog({ title: 'Anular compra', message: 'La compra quedará anulada y no sumará existencias.', okText: 'Anular compra', danger: true })) return;
          try { await app.store.cancelPurchase(p.id); ctrl.close(); toast('Compra anulada'); } catch (err) { toast(err.message, 'error'); }
        };
      }
    },
  });
}

export async function receivePurchase(p, ctrl = null) {
  const units = p.lines.reduce((a, l) => a + l.qty, 0);
  if (!await confirmDialog({ title: 'Recibir mercancía', message: `Se sumarán ${units} unidades al inventario (compra #${p.id}).`, okText: 'Recibir' })) return;
  try {
    await app.store.receivePurchase(p.id);
    ctrl?.close();
    toast(`Compra #${p.id} recibida: +${units} uds`);
  } catch (err) { toast(err.message, 'error'); }
}

// =====================================================================
// Gastos y proveedores
// =====================================================================
export async function openExpenseForm() {
  const existing = await app.store.listExpenses();
  const cats = [...new Set(['Alquiler', 'Transporte', 'Publicidad', 'Suministros', 'Embalaje', 'Comisiones', ...existing.map((e) => e.category)])];
  openModal({
    title: 'Añadir gasto', size: 'sm',
    render(el, ctrl) {
      let opKey = newOpKey();
      el.innerHTML = `
      <form class="form" novalidate>
        <div class="form-error" role="alert" hidden></div>
        <label class="field"><span>Importe *</span><input name="amount" inputmode="decimal" placeholder="0,00" autofocus></label>
        <label class="field"><span>Categoría *</span><input name="category" list="dl-ecat" autocomplete="off"></label>
        <datalist id="dl-ecat">${cats.map((c) => `<option value="${esc(c)}">`).join('')}</datalist>
        <label class="field"><span>Fecha</span><input type="date" name="date" value="${app.store.today()}"></label>
        <label class="field"><span>Nota</span><input name="note"></label>
        <div class="form-actions"><button type="button" class="btn" data-close>Cancelar</button><button type="submit" class="btn" data-again>Guardar y añadir otro</button><button type="submit" class="btn btn-primary">Guardar gasto</button></div>
      </form>`;
      const form = $('form', el);
      form.addEventListener('input', () => ctrl.setDirty(true));
      let again = false;
      form.addEventListener('click', (e) => { if (e.target.matches('[type=submit]')) again = e.target.hasAttribute('data-again'); }, true);
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        busy(form, async () => {
          try {
            await app.store.addExpense({ date: form.date.value, category: form.category.value, amount: form.amount.value, note: form.note.value, opKey });
            toast('Gasto guardado');
            ctrl.setDirty(false);
            if (again) { opKey = newOpKey(); form.amount.value = ''; form.note.value = ''; form.amount.focus(); } else ctrl.close();
          } catch (err) { showFormError(form, err); }
        });
      });
    },
  });
}

export function openSupplierForm(sup = null) {
  openModal({
    title: sup ? 'Editar proveedor' : 'Añadir proveedor', size: 'sm',
    render(el, ctrl) {
      el.innerHTML = `
      <form class="form" novalidate>
        <div class="form-error" role="alert" hidden></div>
        <label class="field"><span>Nombre *</span><input name="name" value="${esc(sup?.name ?? '')}" autofocus></label>
        <label class="field"><span>Teléfono</span><input name="phone" type="tel" value="${esc(sup?.phone ?? '')}"></label>
        <label class="field"><span>Correo</span><input name="email" type="email" value="${esc(sup?.email ?? '')}"></label>
        <label class="field"><span>Notas</span><textarea name="notes" rows="2">${esc(sup?.notes ?? '')}</textarea></label>
        <div class="form-actions"><button type="button" class="btn" data-close>Cancelar</button><button class="btn btn-primary">Guardar</button></div>
      </form>`;
      const form = $('form', el);
      form.addEventListener('input', () => ctrl.setDirty(true));
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        busy(form, async () => {
          try {
            await app.store.saveSupplier({ id: sup?.id ?? null, name: form.name.value, phone: form.phone.value, email: form.email.value, notes: form.notes.value });
            ctrl.setDirty(false); ctrl.close(); toast('Proveedor guardado');
          } catch (err) { showFormError(form, err); }
        });
      });
    },
  });
}

export { initials };
