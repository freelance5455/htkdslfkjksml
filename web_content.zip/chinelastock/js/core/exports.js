// Exportaciones CSV (separador ";" y decimales con coma, compatibles con Excel en español).
import { centsToCsv } from './money.js';

export function toCSV(header, rows) {
  const cell = (v) => {
    const s = v == null ? '' : String(v);
    return /[;"\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const lines = [header.map(cell).join(';'), ...rows.map((r) => r.map(cell).join(';'))];
  return `﻿${lines.join('\r\n')}\r\n`;
}

const STATUS = { received: 'Recibida', pending: 'Pendiente', cancelled: 'Anulada', ok: 'Completada', partial: 'Devolución parcial', returned: 'Devuelta' };

export async function buildExport(store, kind) {
  const stamp = store.today();
  if (kind === 'inventario') {
    const cat = await store.loadCatalog();
    const rows = cat.variants.map((v) => [
      v.sku, v.brandName, v.modelName, v.size, v.color, centsToCsv(v.cost), centsToCsv(v.price), centsToCsv(v.avgCost), v.stock,
      centsToCsv(v.stock * v.avgCost), v.active === false ? 'Archivado' : 'Activo',
    ]);
    return { filename: `inventario-${stamp}.csv`, content: toCSV(['Referencia', 'Marca', 'Modelo', 'Talla', 'Color', 'Precio compra', 'Precio venta', 'Coste medio', 'Existencias', 'Valor a coste', 'Estado'], rows) };
  }
  if (kind === 'ventas') {
    const sales = await store.listSales();
    const rows = [];
    for (const s of sales) {
      for (const l of s.lines) {
        rows.push([s.id, s.date, s.paymentMethod, STATUS[s.status] || s.status, l.sku, l.label, l.qty, centsToCsv(l.unitPrice), centsToCsv(l.discount), centsToCsv(l.net), centsToCsv(l.unitCost), centsToCsv(l.net - l.qty * l.unitCost), l.returnedQty, centsToCsv(l.refunded)]);
      }
    }
    return { filename: `ventas-${stamp}.csv`, content: toCSV(['Venta', 'Fecha', 'Pago', 'Estado', 'Referencia', 'Producto', 'Cantidad', 'Precio unitario', 'Descuento', 'Importe neto', 'Coste unitario', 'Margen', 'Unidades devueltas', 'Reembolsado'], rows) };
  }
  if (kind === 'compras') {
    const ps = await store.listPurchases();
    const rows = [];
    for (const p of ps) for (const l of p.lines) rows.push([p.id, p.date, p.supplier, STATUS[p.status] || p.status, p.receivedDate || '', l.sku, l.label, l.qty, centsToCsv(l.unitCost), centsToCsv(l.lineTotal)]);
    return { filename: `compras-${stamp}.csv`, content: toCSV(['Compra', 'Fecha', 'Proveedor', 'Estado', 'Recibida el', 'Referencia', 'Producto', 'Cantidad', 'Coste unitario', 'Total línea'], rows) };
  }
  if (kind === 'gastos') {
    const es = await store.listExpenses();
    return { filename: `gastos-${stamp}.csv`, content: toCSV(['Fecha', 'Categoría', 'Importe', 'Nota'], es.map((e) => [e.date, e.category, centsToCsv(e.amount), e.note])) };
  }
  if (kind === 'devoluciones') {
    const rs = await store.listReturns();
    const rows = [];
    for (const r of rs) for (const l of r.lines) rows.push([r.id, r.date, r.saleId, l.label, l.qty, centsToCsv(l.refund), l.restock ? 'Sí' : 'No', r.reason]);
    return { filename: `devoluciones-${stamp}.csv`, content: toCSV(['Devolución', 'Fecha', 'Venta', 'Producto', 'Cantidad', 'Reembolso', 'Vuelve al stock', 'Motivo'], rows) };
  }
  throw new Error(`Exportación desconocida: ${kind}`);
}
