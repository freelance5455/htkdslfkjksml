// Utilidades monetarias. Todos los importes se guardan como ENTEROS en céntimos.
// Nunca se hacen cálculos de dinero con decimales en coma flotante.

export class ValidationError extends Error {
  constructor(message, field = null) {
    super(message);
    this.name = 'ValidationError';
    this.field = field;
  }
}

export const MAX_CENTS = 100_000_000_00; // 100 millones (límite de seguridad)

/**
 * Convierte un texto introducido por el usuario a céntimos enteros.
 * Acepta "9", "9,5", "9,50", "9.50", "1.234,56", "€ 12".
 * Rechaza negativos, más de 2 decimales y texto no numérico.
 */
export function parseMoney(input, { field = null, allowEmpty = false, label = 'El importe' } = {}) {
  if (typeof input === 'number') {
    if (!Number.isInteger(input) || input < 0 || input > MAX_CENTS) {
      throw new ValidationError(`${label} no es válido.`, field);
    }
    return input; // un número entero ya está en céntimos
  }
  let s = String(input ?? '').trim().replace(/[\s€$]/g, '');
  if (!s) {
    if (allowEmpty) return null;
    throw new ValidationError(`${label} es obligatorio.`, field);
  }
  if (s.startsWith('-')) throw new ValidationError(`${label} no puede ser negativo.`, field);
  if (/^\d{1,3}(\.\d{3})+(,\d{1,2})?$/.test(s)) {
    s = s.replace(/\./g, '').replace(',', '.'); // formato español con separador de miles
  } else {
    s = s.replace(',', '.');
  }
  if (!/^\d+(\.\d{1,2})?$/.test(s)) {
    throw new ValidationError(`${label} no es válido (usa números con un máximo de 2 decimales, p. ej. 9,50).`, field);
  }
  const [ent, dec = ''] = s.split('.');
  const cents = Number(ent) * 100 + Number((dec + '00').slice(0, 2));
  if (!Number.isSafeInteger(cents) || cents > MAX_CENTS) throw new ValidationError(`${label} es demasiado alto.`, field);
  return cents;
}

/** Comprueba que un valor ya en céntimos es un entero válido. */
export function assertCents(v, label = 'Importe') {
  if (!Number.isSafeInteger(v) || v < 0 || v > MAX_CENTS) throw new ValidationError(`${label} no es válido.`);
  return v;
}

/** Cantidad de unidades: entero >= min. */
export function parseQty(input, { min = 0, label = 'La cantidad', field = null } = {}) {
  const s = String(input ?? '').trim();
  if (s === '') {
    if (min <= 0) return 0;
    throw new ValidationError(`${label} es obligatoria.`, field);
  }
  if (!/^-?\d+$/.test(s)) throw new ValidationError(`${label} debe ser un número entero de unidades.`, field);
  const n = Number(s);
  if (!Number.isSafeInteger(n) || n > 1_000_000) throw new ValidationError(`${label} no es válida.`, field);
  if (n < min) throw new ValidationError(`${label} debe ser como mínimo ${min}.`, field);
  return n;
}

/** Porcentaje a "puntos básicos" enteros (10,5 % -> 1050). */
export function parsePercent(input, { label = 'El porcentaje' } = {}) {
  let s = String(input ?? '').trim().replace('%', '').replace(',', '.');
  if (!/^-?\d+(\.\d{1,2})?$/.test(s)) throw new ValidationError(`${label} no es válido (p. ej. 10 o 7,5).`);
  const neg = s.startsWith('-');
  if (neg) s = s.slice(1);
  const [e, d = ''] = s.split('.');
  const bp = Number(e) * 100 + Number((d + '00').slice(0, 2));
  if (bp > 100000) throw new ValidationError(`${label} es demasiado alto.`);
  return neg ? -bp : bp;
}

/** División entera redondeando al más cercano (mitades hacia arriba). a >= 0, b > 0. */
export function roundDiv(a, b) {
  if (a < 0) return -roundDiv(-a, b);
  return Math.floor((2 * a + b) / (2 * b));
}

/** Aplica un porcentaje (en puntos básicos) a un importe en céntimos. */
export function applyPercent(cents, bp) {
  const r = roundDiv(cents * (10000 + bp), 10000);
  return r;
}

/** Redondea a un múltiplo (en céntimos), p. ej. step=10 -> 0,10 €. */
export function roundToStep(cents, step) {
  if (!step || step <= 1) return cents;
  return roundDiv(cents, step) * step;
}

/** Reparte `total` entre partes proporcionales a `weights`, sin perder céntimos. */
export function allocate(total, weights) {
  const sum = weights.reduce((a, b) => a + b, 0);
  if (sum === 0) return weights.map((_, i) => (i === weights.length - 1 ? total : 0));
  const out = [];
  let acc = 0;
  let accW = 0;
  for (let i = 0; i < weights.length; i++) {
    accW += weights[i];
    const target = roundDiv(total * accW, sum); // reparto acumulado: la suma es exacta
    out.push(target - acc);
    acc = target;
  }
  return out;
}

const fmtCache = new Map();
export function formatMoney(cents, currency = 'EUR') {
  if (cents == null || Number.isNaN(cents)) return '—';
  let f = fmtCache.get(currency);
  if (!f) {
    try {
      f = new Intl.NumberFormat('es-ES', { style: 'currency', currency, minimumFractionDigits: 2, maximumFractionDigits: 2 });
    } catch {
      f = new Intl.NumberFormat('es-ES', { style: 'currency', currency: 'EUR' });
    }
    fmtCache.set(currency, f);
  }
  // División exacta para mostrar: el entero de céntimos se convierte solo para formatear.
  return f.format(cents / 100);
}

/** Céntimos a texto editable "9,50" (sin símbolo). */
export function centsToInput(cents) {
  if (cents == null) return '';
  const neg = cents < 0;
  const a = Math.abs(cents);
  return `${neg ? '-' : ''}${Math.floor(a / 100)},${String(a % 100).padStart(2, '0')}`;
}

/** Céntimos a número decimal en texto para CSV con coma: 1234 -> "12,34". */
export const centsToCsv = centsToInput;
