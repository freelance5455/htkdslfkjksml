// Capa de base de datos sobre IndexedDB.
// Las restricciones de integridad (unicidad) se definen como índices únicos,
// de modo que no dependen solo de las validaciones de la interfaz.
import { ValidationError } from './money.js';

export const DB_NAME = 'chinelastock';
export const DB_VERSION = 1;

export const STORES = [
  'settings', 'brands', 'suppliers', 'models', 'variants', 'priceHistory',
  'purchases', 'sales', 'returns', 'expenses', 'stockMoves',
];

function upgrade(db) {
  const mk = (name, opts, indexes = []) => {
    const s = db.createObjectStore(name, opts);
    for (const [iname, keyPath, unique = false] of indexes) s.createIndex(iname, keyPath, { unique });
    return s;
  };
  const auto = { keyPath: 'id', autoIncrement: true };
  mk('settings', { keyPath: 'key' });
  mk('brands', auto, [['nameKey', 'nameKey', true]]);
  mk('suppliers', auto, [['nameKey', 'nameKey', true]]);
  mk('models', auto, [['brandId', 'brandId'], ['brandName', ['brandId', 'nameKey'], true]]);
  mk('variants', auto, [
    ['modelId', 'modelId'],
    ['sku', 'skuKey', true],
    ['combo', ['modelId', 'sizeKey', 'colorKey'], true],
  ]);
  mk('priceHistory', auto, [['variantId', 'variantId'], ['at', 'at']]);
  mk('purchases', auto, [['date', 'date'], ['status', 'status'], ['opKey', 'opKey', true]]);
  mk('sales', auto, [['date', 'date'], ['opKey', 'opKey', true]]);
  mk('returns', auto, [['saleId', 'saleId'], ['date', 'date'], ['opKey', 'opKey', true]]);
  mk('expenses', auto, [['date', 'date'], ['opKey', 'opKey', true]]);
  mk('stockMoves', auto, [['variantId', 'variantId'], ['at', 'at']]);
}

export function openDB(name = DB_NAME) {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('Este navegador no permite guardar datos (IndexedDB no disponible).'));
      return;
    }
    const r = indexedDB.open(name, DB_VERSION);
    r.onupgradeneeded = (ev) => {
      if (ev.oldVersion < 1) upgrade(r.result);
    };
    r.onsuccess = () => {
      const db = r.result;
      db.onversionchange = () => db.close();
      resolve(db);
    };
    r.onerror = () => reject(r.error);
    r.onblocked = () => reject(new Error('La base de datos está abierta en otra pestaña con una versión distinta. Ciérrala y vuelve a intentarlo.'));
  });
}

export function deleteDB(name = DB_NAME) {
  return new Promise((resolve, reject) => {
    const r = indexedDB.deleteDatabase(name);
    r.onsuccess = () => resolve();
    r.onerror = () => reject(r.error);
    r.onblocked = () => resolve();
  });
}

/** Traduce errores técnicos de IndexedDB a mensajes comprensibles. */
export function friendlyError(err) {
  if (!err) return new Error('Error desconocido al guardar.');
  if (err instanceof ValidationError) return err;
  if (err.name === 'ConstraintError') {
    return new ValidationError('Ya existe un registro con esos datos (referencia, marca, modelo o combinación talla/color repetida).');
  }
  if (err.name === 'QuotaExceededError') {
    return new Error('No queda espacio de almacenamiento en el dispositivo. Exporta una copia y libera espacio.');
  }
  return err;
}

/** Envuelve una petición IDB en una promesa. */
export function req(r) {
  return new Promise((resolve, reject) => {
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(friendlyError(r.error));
  });
}

/**
 * Ejecuta `fn(stores)` dentro de UNA transacción. Resuelve solo cuando la
 * transacción se ha confirmado (complete). Si `fn` lanza un error, la
 * transacción se aborta y no se guarda nada.
 */
export function tx(db, names, mode, fn) {
  const list = Array.isArray(names) ? names : [names];
  return new Promise((resolve, reject) => {
    let t;
    try {
      t = db.transaction(list, mode);
    } catch (e) {
      reject(friendlyError(e));
      return;
    }
    let result;
    let failed = null;
    t.oncomplete = () => (failed ? reject(failed) : resolve(result));
    t.onabort = () => reject(failed || friendlyError(t.error) || new Error('La operación se canceló.'));
    t.onerror = (ev) => {
      if (!failed) failed = friendlyError(ev.target?.error || t.error);
    };
    const stores = {};
    for (const n of list) stores[n] = t.objectStore(n);
    let p;
    try {
      p = fn(stores, t);
    } catch (e) {
      failed = e;
      try { t.abort(); } catch { /* ya abortada */ }
      return;
    }
    Promise.resolve(p).then(
      (r) => { result = r; },
      (e) => {
        failed = friendlyError(e);
        try { t.abort(); } catch { /* ya abortada */ }
      },
    );
  });
}

export const getAll = (store, query) => req(store.getAll(query));
export const get = (store, key) => req(store.get(key));
