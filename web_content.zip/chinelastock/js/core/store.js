// Lógica de negocio de ChinelaStock. Toda escritura pasa por aquí y se
// ejecuta en una única transacción por operación (todo o nada).
import {
  ValidationError, parseMoney, parseQty, parsePercent, assertCents,
  applyPercent, roundToStep, roundDiv, allocate,
} from './money.js';
import { openDB, tx, req, getAll, get, STORES, DB_NAME } from './db.js';

export const BACKUP_FORMAT = 1;

export const DEFAULT_SETTINGS = {
  shopName: 'ChinelaStock',
  currency: 'EUR',
  lowStock: 2,
  allowPriceOverride: true,
  theme: 'system',
  valuation: 'average', // coste medio ponderado
  lastBackupAt: null,
};

export const PAYMENT_METHODS = ['Efectivo', 'Tarjeta', 'Bizum', 'Transferencia', 'Otro'];

// ---------- utilidades ----------
export function normKey(s) {
  return String(s ?? '').trim().replace(/\s+/g, ' ').toLocaleLowerCase('es')
    .normalize('NFD').replace(/[̀-ͯ]/g, '');
}
export function cleanText(s, max = 120) {
  return String(s ?? '').trim().replace(/\s+/g, ' ').slice(0, max);
}
/** "negro" -> "Negro" para que el mismo color no aparezca escrito de dos formas. */
export function capFirst(s) {
  return s ? s.charAt(0).toLocaleUpperCase('es') + s.slice(1) : s;
}
export function isValidDate(s) {
  if (typeof s !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const d = new Date(`${s}T00:00:00Z`);
  if (Number.isNaN(d.getTime()) || d.toISOString().slice(0, 10) !== s) return false;
  const y = Number(s.slice(0, 4));
  return y >= 2000 && y <= 2100;
}
export function localDate(d = new Date()) {
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}
export function newOpKey() {
  if (globalThis.crypto?.randomUUID) return crypto.randomUUID();
  return `${Date.now()}-${Math.random().toString(36).slice(2)}`;
}
function checkDate(date, label = 'La fecha') {
  if (!isValidDate(date)) throw new ValidationError(`${label} no es válida.`, 'date');
  return date;
}
function skuNormalize(sku) {
  const s = cleanText(sku, 40).toUpperCase().replace(/\s+/g, '-');
  if (s && !/^[A-Z0-9._\-/]+$/.test(s)) {
    throw new ValidationError(`La referencia "${sku}" solo puede contener letras, números, guiones, puntos o barras.`, 'sku');
  }
  return s;
}
function skuPart(s, n) {
  return normKey(s).toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, n);
}
export function variantLabel(brandName, modelName, size, color) {
  return `${brandName} ${modelName} · T${size}${color ? ` · ${color}` : ''}`;
}
const centsOrParse = (v, label) => (typeof v === 'number' ? assertCents(v, label) : parseMoney(v, { label }));
const intOrParse = (v, min, label) => (typeof v === 'number' ? parseQty(String(v), { min, label }) : parseQty(v, { min, label }));

// ---------- Store ----------
export class Store extends EventTarget {
  constructor(db, { now = () => new Date(), channelName = null } = {}) {
    super();
    this.db = db;
    this.now = now;
    this.channel = null;
    if (channelName && typeof BroadcastChannel !== 'undefined') {
      this.channel = new BroadcastChannel(channelName);
      this.channel.onmessage = (e) => this.dispatchEvent(new CustomEvent('change', { detail: { stores: e.data, remote: true } }));
    }
  }

  static async open(name = DB_NAME, opts = {}) {
    const db = await openDB(name);
    return new Store(db, { channelName: `${name}-sync`, ...opts });
  }

  close() {
    this.db.close();
    this.channel?.close();
  }

  nowISO() { return this.now().toISOString(); }
  today() { return localDate(this.now()); }

  emit(stores) {
    this.dispatchEvent(new CustomEvent('change', { detail: { stores } }));
    try { this.channel?.postMessage(stores); } catch { /* sin pestañas */ }
  }

  async write(names, fn) {
    const r = await tx(this.db, names, 'readwrite', fn);
    this.emit(names); // solo se notifica cuando la transacción se ha confirmado
    return r;
  }
  read(names, fn) { return tx(this.db, names, 'readonly', fn); }

  // ---------- configuración ----------
  async getSettings() {
    const rows = await this.read('settings', (s) => getAll(s.settings));
    const out = { ...DEFAULT_SETTINGS };
    for (const r of rows) out[r.key] = r.value;
    return out;
  }
  async setSettings(patch) {
    const allowed = Object.keys(DEFAULT_SETTINGS);
    const clean = {};
    for (const [k, v] of Object.entries(patch)) {
      if (!allowed.includes(k)) throw new ValidationError(`Ajuste desconocido: ${k}`);
      clean[k] = v;
    }
    if ('currency' in clean && !/^[A-Z]{3}$/.test(clean.currency)) throw new ValidationError('La moneda debe ser un código de 3 letras (EUR, USD, MXN…).');
    if ('lowStock' in clean) clean.lowStock = parseQty(String(clean.lowStock), { min: 0, label: 'El aviso de stock bajo' });
    if ('shopName' in clean) clean.shopName = cleanText(clean.shopName, 60) || DEFAULT_SETTINGS.shopName;
    if ('theme' in clean && !['system', 'light', 'dark'].includes(clean.theme)) throw new ValidationError('Tema no válido.');
    if ('allowPriceOverride' in clean) clean.allowPriceOverride = !!clean.allowPriceOverride;
    if ('valuation' in clean && clean.valuation !== 'average') throw new ValidationError('Solo está disponible el coste medio ponderado.');
    await this.write('settings', async (s) => {
      for (const [key, value] of Object.entries(clean)) await req(s.settings.put({ key, value }));
    });
  }

  // ---------- marcas y proveedores ----------
  async listBrands() {
    const r = await this.read('brands', (s) => getAll(s.brands));
    return r.sort((a, b) => a.name.localeCompare(b.name, 'es'));
  }
  async _ensureNamed(store, name, label, extra = {}) {
    const clean = cleanText(name, 60);
    if (!clean) throw new ValidationError(`${label} es obligatorio.`);
    const key = normKey(clean);
    const existing = await req(store.index('nameKey').get(key));
    if (existing) return { record: existing, created: false };
    const ts = this.nowISO();
    const rec = { name: clean, nameKey: key, createdAt: ts, ...extra };
    rec.id = await req(store.add(rec));
    return { record: rec, created: true };
  }
  async createBrand(name) {
    return this.write('brands', async (s) => {
      const r = await this._ensureNamed(s.brands, name, 'El nombre de la marca');
      if (!r.created) throw new ValidationError(`La marca "${r.record.name}" ya existe.`);
      return r.record;
    });
  }
  async renameBrand(id, name) {
    return this.write('brands', async (s) => {
      const b = await get(s.brands, id);
      if (!b) throw new ValidationError('La marca no existe.');
      const clean = cleanText(name, 60);
      if (!clean) throw new ValidationError('El nombre de la marca es obligatorio.');
      b.name = clean; b.nameKey = normKey(clean);
      await req(s.brands.put(b));
      return b;
    });
  }
  async listSuppliers() {
    const r = await this.read('suppliers', (s) => getAll(s.suppliers));
    return r.sort((a, b) => a.name.localeCompare(b.name, 'es'));
  }
  async saveSupplier({ id = null, name, phone = '', email = '', notes = '' }) {
    return this.write('suppliers', async (s) => {
      const clean = cleanText(name, 60);
      if (!clean) throw new ValidationError('El nombre del proveedor es obligatorio.', 'name');
      const data = { name: clean, nameKey: normKey(clean), phone: cleanText(phone, 30), email: cleanText(email, 80), notes: cleanText(notes, 500) };
      if (data.email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(data.email)) throw new ValidationError('El correo no es válido.', 'email');
      if (id == null) {
        const dup = await req(s.suppliers.index('nameKey').get(data.nameKey));
        if (dup) throw new ValidationError(`El proveedor "${dup.name}" ya existe.`, 'name');
        const rec = { ...data, createdAt: this.nowISO() };
        rec.id = await req(s.suppliers.add(rec));
        return rec;
      }
      const cur = await get(s.suppliers, id);
      if (!cur) throw new ValidationError('El proveedor no existe.');
      const rec = { ...cur, ...data };
      await req(s.suppliers.put(rec));
      return rec;
    });
  }

  // ---------- catálogo ----------
  /** Carga marcas, modelos y variantes y los une en memoria. */
  async loadCatalog() {
    const { brands, models, variants, suppliers } = await this.read(['brands', 'models', 'variants', 'suppliers'], async (s) => ({
      brands: await getAll(s.brands),
      models: await getAll(s.models),
      variants: await getAll(s.variants),
      suppliers: await getAll(s.suppliers),
    }));
    const brandById = new Map(brands.map((b) => [b.id, b]));
    const supplierById = new Map(suppliers.map((b) => [b.id, b]));
    const modelById = new Map();
    for (const m of models) {
      m.brandName = brandById.get(m.brandId)?.name ?? '¿?';
      m.supplierName = m.supplierId ? supplierById.get(m.supplierId)?.name ?? '' : '';
      m.variants = [];
      modelById.set(m.id, m);
    }
    for (const v of variants) {
      const m = modelById.get(v.modelId);
      v.modelName = m?.name ?? '¿?';
      v.brandName = m?.brandName ?? '¿?';
      v.brandId = m?.brandId;
      v.label = variantLabel(v.brandName, v.modelName, v.size, v.color);
      v.searchKey = normKey(`${v.brandName} ${v.modelName} ${v.sku} ${v.size} ${v.color}`);
      m?.variants.push(v);
    }
    const sortSize = (a, b) => a.size.localeCompare(b.size, 'es', { numeric: true }) || a.color.localeCompare(b.color, 'es');
    for (const m of models) m.variants.sort(sortSize);
    models.sort((a, b) => a.brandName.localeCompare(b.brandName, 'es') || a.name.localeCompare(b.name, 'es'));
    variants.sort((a, b) => a.brandName.localeCompare(b.brandName, 'es') || a.modelName.localeCompare(b.modelName, 'es') || sortSize(a, b));
    return { brands: brands.sort((a, b) => a.name.localeCompare(b.name, 'es')), models, variants, suppliers: suppliers.sort((a, b) => a.name.localeCompare(b.name, 'es')), modelById, brandById };
  }

  /** Busca variantes por nombre, marca, referencia, talla o color (todas las palabras deben coincidir). */
  async searchVariants(q, { limit = 30, onlyActive = true, catalog = null } = {}) {
    const cat = catalog || await this.loadCatalog();
    const words = normKey(q).split(' ').filter(Boolean);
    const out = [];
    for (const v of cat.variants) {
      if (onlyActive && v.active === false) continue;
      if (words.every((w) => v.searchKey.includes(w))) out.push(v);
      if (out.length >= limit) break;
    }
    return out;
  }

  /** Revisión previa (solo lectura) para avisar de duplicados antes de guardar. */
  async checkProductDraft({ brandName, modelName, variants = [], excludeVariantIds = [] }) {
    return this.read(['brands', 'models', 'variants'], async (s) => {
      const out = { brand: null, model: null, rowIssues: [] };
      const bKey = normKey(brandName);
      if (bKey) out.brand = (await req(s.brands.index('nameKey').get(bKey))) || null;
      if (out.brand && normKey(modelName)) {
        out.model = (await req(s.models.index('brandName').get([out.brand.id, normKey(modelName)]))) || null;
      }
      const seen = new Map();
      for (let i = 0; i < variants.length; i++) {
        const r = variants[i];
        const combo = `${normKey(r.size)}|${normKey(r.color)}`;
        if (normKey(r.size)) {
          if (seen.has(combo)) out.rowIssues.push({ row: i, message: `Repite talla y color de la fila ${seen.get(combo) + 1}.` });
          else seen.set(combo, i);
          if (out.model) {
            const ex = await req(s.variants.index('combo').get([out.model.id, normKey(r.size), normKey(r.color)]));
            if (ex && !excludeVariantIds.includes(ex.id)) out.rowIssues.push({ row: i, message: `Esta talla y color ya existe en el modelo (ref. ${ex.sku}).` });
          }
        }
        if (r.sku) {
          let key;
          try { key = skuNormalize(r.sku); } catch (e) { out.rowIssues.push({ row: i, message: e.message }); continue; }
          const ex = await req(s.variants.index('sku').get(key));
          if (ex && !excludeVariantIds.includes(ex.id)) out.rowIssues.push({ row: i, message: `La referencia ${key} ya está en uso.` });
        }
      }
      return out;
    });
  }

  /**
   * Alta de producto: crea (o reutiliza) marca, proveedor y modelo, y añade
   * todas las variantes en una sola transacción.
   */
  async createProduct(input) {
    const modelName = cleanText(input.modelName, 80);
    if (!modelName && input.modelId == null) throw new ValidationError('El nombre del modelo es obligatorio.', 'modelName');
    if (!cleanText(input.brandName, 60) && input.modelId == null) throw new ValidationError('La marca es obligatoria.', 'brandName');
    const rows = Array.isArray(input.variants) ? input.variants : [];
    if (!rows.length) throw new ValidationError('Añade al menos una talla.', 'variants');
    // Validación de filas antes de abrir la transacción
    const clean = rows.map((r, i) => {
      const n = `Fila ${i + 1}: `;
      const size = cleanText(r.size, 12);
      if (!size) throw new ValidationError(`${n}la talla es obligatoria.`, `variants.${i}.size`);
      const color = capFirst(cleanText(r.color, 30));
      let cost; let price; let qty;
      try { cost = centsOrParse(r.cost, 'el precio de compra'); } catch (e) { throw new ValidationError(n + e.message, `variants.${i}.cost`); }
      try { price = centsOrParse(r.price, 'el precio de venta'); } catch (e) { throw new ValidationError(n + e.message, `variants.${i}.price`); }
      try { qty = intOrParse(r.qty ?? 0, 0, 'la cantidad inicial'); } catch (e) { throw new ValidationError(n + e.message, `variants.${i}.qty`); }
      let sku;
      try { sku = skuNormalize(r.sku); } catch (e) { throw new ValidationError(n + e.message, `variants.${i}.sku`); }
      return { size, sizeKey: normKey(size), color, colorKey: normKey(color), cost, price, qty, sku };
    });
    const combos = new Set();
    clean.forEach((r, i) => {
      const k = `${r.sizeKey}|${r.colorKey}`;
      if (combos.has(k)) throw new ValidationError(`Fila ${i + 1}: la talla ${r.size}${r.color ? ` en ${r.color}` : ''} está repetida.`, `variants.${i}.size`);
      combos.add(k);
    });
    const opKey = input.opKey || null;

    return this.write(['brands', 'suppliers', 'models', 'variants', 'stockMoves', 'priceHistory'], async (s) => {
      const ts = this.nowISO();
      let model;
      let brand;
      let addedToExisting = false;
      if (input.modelId != null) {
        model = await get(s.models, input.modelId);
        if (!model) throw new ValidationError('El modelo no existe.');
        brand = await get(s.brands, model.brandId);
        addedToExisting = true;
      } else {
        brand = (await this._ensureNamed(s.brands, input.brandName, 'La marca')).record;
        model = await req(s.models.index('brandName').get([brand.id, normKey(modelName)]));
        if (model) {
          addedToExisting = true;
        } else {
          let supplierId = null;
          if (cleanText(input.supplierName)) supplierId = (await this._ensureNamed(s.suppliers, input.supplierName, 'El proveedor')).record.id;
          model = {
            brandId: brand.id, name: modelName, nameKey: normKey(modelName), supplierId,
            notes: cleanText(input.notes, 1000), photo: typeof input.photo === 'string' ? input.photo : null,
            active: true, createdAt: ts, updatedAt: ts, opKey,
          };
          model.id = await req(s.models.add(model));
        }
      }
      const variantIds = [];
      const usedSku = new Set();
      for (let i = 0; i < clean.length; i++) {
        const r = clean[i];
        const dupCombo = await req(s.variants.index('combo').get([model.id, r.sizeKey, r.colorKey]));
        if (dupCombo) throw new ValidationError(`Fila ${i + 1}: ${brand.name} ${model.name} ya tiene la talla ${r.size}${r.color ? ` en ${r.color}` : ''} (ref. ${dupCombo.sku}).`, `variants.${i}.size`);
        let sku = r.sku;
        if (sku) {
          const ex = await req(s.variants.index('sku').get(sku));
          if (ex || usedSku.has(sku)) throw new ValidationError(`Fila ${i + 1}: la referencia ${sku} ya está en uso.`, `variants.${i}.sku`);
        } else {
          const base = [skuPart(brand.name, 3), skuPart(model.name, 4), skuPart(r.size, 6), skuPart(r.color, 3)].filter(Boolean).join('-') || 'REF';
          sku = base;
          for (let n = 2; usedSku.has(sku) || await req(s.variants.index('sku').get(sku)); n++) sku = `${base}-${n}`;
        }
        usedSku.add(sku);
        const v = {
          modelId: model.id, sku, skuKey: sku, size: r.size, sizeKey: r.sizeKey, color: r.color, colorKey: r.colorKey,
          cost: r.cost, price: r.price, avgCost: r.cost, stock: r.qty, active: true, createdAt: ts, updatedAt: ts,
        };
        v.id = await req(s.variants.add(v));
        variantIds.push(v.id);
        await req(s.priceHistory.add({ variantId: v.id, field: 'price', old: null, new: r.price, at: ts, reason: 'Alta' }));
        await req(s.priceHistory.add({ variantId: v.id, field: 'cost', old: null, new: r.cost, at: ts, reason: 'Alta' }));
        if (r.qty > 0) {
          await req(s.stockMoves.add({ variantId: v.id, qty: r.qty, stockAfter: r.qty, type: 'inicial', unitCost: r.cost, refType: null, refId: null, at: ts, note: 'Cantidad inicial' }));
        }
      }
      if (addedToExisting) {
        model.updatedAt = ts;
        await req(s.models.put(model));
      }
      return { modelId: model.id, brandId: brand.id, variantIds, addedToExisting };
    });
  }

  async updateModel(id, { brandName, name, supplierName, notes, photo, active }) {
    return this.write(['brands', 'suppliers', 'models'], async (s) => {
      const m = await get(s.models, id);
      if (!m) throw new ValidationError('El modelo no existe.');
      if (brandName !== undefined) m.brandId = (await this._ensureNamed(s.brands, brandName, 'La marca')).record.id;
      if (name !== undefined) {
        const n = cleanText(name, 80);
        if (!n) throw new ValidationError('El nombre del modelo es obligatorio.', 'modelName');
        m.name = n; m.nameKey = normKey(n);
      }
      const dup = await req(s.models.index('brandName').get([m.brandId, m.nameKey]));
      if (dup && dup.id !== m.id) throw new ValidationError(`Ya existe el modelo "${dup.name}" en esa marca.`, 'modelName');
      if (supplierName !== undefined) m.supplierId = cleanText(supplierName) ? (await this._ensureNamed(s.suppliers, supplierName, 'El proveedor')).record.id : null;
      if (notes !== undefined) m.notes = cleanText(notes, 1000);
      if (photo !== undefined) m.photo = photo || null;
      if (active !== undefined) m.active = !!active;
      m.updatedAt = this.nowISO();
      await req(s.models.put(m));
      return m;
    });
  }

  async updateVariant(id, { sku, size, color, active }) {
    return this.write(['variants'], async (s) => {
      const v = await get(s.variants, id);
      if (!v) throw new ValidationError('La variante no existe.');
      if (size !== undefined) {
        const c = cleanText(size, 12);
        if (!c) throw new ValidationError('La talla es obligatoria.', 'size');
        v.size = c; v.sizeKey = normKey(c);
      }
      if (color !== undefined) { v.color = capFirst(cleanText(color, 30)); v.colorKey = normKey(v.color); }
      const dup = await req(s.variants.index('combo').get([v.modelId, v.sizeKey, v.colorKey]));
      if (dup && dup.id !== v.id) throw new ValidationError('Ya existe esa talla y color en este modelo.', 'size');
      if (sku !== undefined) {
        const k = skuNormalize(sku);
        if (!k) throw new ValidationError('La referencia no puede quedar vacía.', 'sku');
        const ex = await req(s.variants.index('sku').get(k));
        if (ex && ex.id !== v.id) throw new ValidationError(`La referencia ${k} ya está en uso.`, 'sku');
        v.sku = k; v.skuKey = k;
      }
      if (active !== undefined) v.active = !!active;
      v.updatedAt = this.nowISO();
      await req(s.variants.put(v));
      return v;
    });
  }

  // ---------- precios ----------
  /**
   * Cambia el precio de venta ('price') o de compra ('cost') de una variante.
   * No toca ventas anteriores: cada línea de venta guarda su propio precio y coste.
   * `applyToStockCost` corrige además el coste medio de las existencias actuales.
   */
  async setPrice(variantId, field, value, { reason = 'Edición manual', applyToStockCost = false } = {}) {
    if (!['price', 'cost'].includes(field)) throw new ValidationError('Campo de precio no válido.');
    const cents = centsOrParse(value, field === 'price' ? 'El precio de venta' : 'El precio de compra');
    return this.write(['variants', 'priceHistory'], async (s) => {
      const v = await get(s.variants, variantId);
      if (!v) throw new ValidationError('La variante no existe.');
      const old = v[field];
      if (old === cents && !(field === 'cost' && applyToStockCost && v.avgCost !== cents)) return { changed: false, old, new: cents };
      const ts = this.nowISO();
      v[field] = cents;
      if (field === 'cost' && applyToStockCost) v.avgCost = cents;
      v.updatedAt = ts;
      await req(s.variants.put(v));
      if (old !== cents) await req(s.priceHistory.add({ variantId, field, old, new: cents, at: ts, reason: cleanText(reason, 120) }));
      return { changed: true, old, new: cents };
    });
  }

  /**
   * Vista previa de un cambio masivo. No guarda nada.
   * mode: 'percent' (value "10" o "-5"), 'amount' (value "0,50" con direction up/down), 'set' (value "12,00").
   */
  async previewBulkPrice({ variantIds, field = 'price', mode, value, direction = 'up', rounding = 0 }) {
    if (!['price', 'cost'].includes(field)) throw new ValidationError('Campo de precio no válido.');
    if (!Array.isArray(variantIds) || !variantIds.length) throw new ValidationError('Selecciona al menos un producto.');
    let fnNew;
    if (mode === 'percent') {
      const bp = parsePercent(value);
      if (bp === 0) throw new ValidationError('El porcentaje no puede ser 0.');
      fnNew = (old) => applyPercent(old, bp);
    } else if (mode === 'amount') {
      const c = parseMoney(value, { label: 'El importe' });
      if (c === 0) throw new ValidationError('El importe no puede ser 0.');
      const sign = direction === 'down' ? -1 : 1;
      fnNew = (old) => old + sign * c;
    } else if (mode === 'set') {
      const c = parseMoney(value, { label: 'El nuevo precio' });
      fnNew = () => c;
    } else {
      throw new ValidationError('Tipo de cambio no válido.');
    }
    const step = Number.isInteger(rounding) && rounding > 0 ? rounding : 0;
    const cat = await this.loadCatalog();
    const byId = new Map(cat.variants.map((v) => [v.id, v]));
    const rows = [];
    for (const id of new Set(variantIds)) {
      const v = byId.get(id);
      if (!v) continue;
      const old = v[field];
      let nv = fnNew(old);
      if (mode !== 'set') nv = roundToStep(nv, step);
      const row = { variantId: id, label: v.label, sku: v.sku, field, old, new: nv, diff: nv - old, error: null };
      if (nv < 0) row.error = 'El resultado sería negativo.';
      if (field === 'price' && nv >= 0 && nv < v.avgCost) row.warning = 'Por debajo del coste medio.';
      rows.push(row);
    }
    if (!rows.length) throw new ValidationError('Los productos seleccionados ya no existen.');
    return rows;
  }

  /** Aplica una vista previa confirmada. Falla si algún precio cambió mientras tanto. */
  async applyBulkPrice(rows, { reason = 'Cambio masivo' } = {}) {
    if (!Array.isArray(rows) || !rows.length) throw new ValidationError('No hay cambios que aplicar.');
    if (rows.some((r) => r.error)) throw new ValidationError('Hay filas con errores. Corrige el cambio antes de confirmar.');
    return this.write(['variants', 'priceHistory'], async (s) => {
      const ts = this.nowISO();
      let changed = 0;
      for (const r of rows) {
        assertCents(r.new, 'El nuevo precio');
        const v = await get(s.variants, r.variantId);
        if (!v) throw new ValidationError(`${r.label}: ya no existe.`);
        if (v[r.field] !== r.old) throw new ValidationError(`El precio de ${r.label} cambió mientras revisabas. Vuelve a generar la vista previa.`);
        if (r.new === r.old) continue;
        v[r.field] = r.new;
        v.updatedAt = ts;
        await req(s.variants.put(v));
        await req(s.priceHistory.add({ variantId: v.id, field: r.field, old: r.old, new: r.new, at: ts, reason: cleanText(reason, 120) }));
        changed++;
      }
      return { changed };
    });
  }

  // ---------- inventario ----------
  /** Ajuste por recuento: fija la existencia real de una variante. */
  async setStock(variantId, newStock, reason) {
    const n = intOrParse(newStock, 0, 'La existencia');
    const why = cleanText(reason, 120);
    if (!why) throw new ValidationError('Indica el motivo del ajuste (recuento, rotura, regalo…).', 'reason');
    return this.write(['variants', 'stockMoves'], async (s) => {
      const v = await get(s.variants, variantId);
      if (!v) throw new ValidationError('La variante no existe.');
      const delta = n - v.stock;
      if (delta === 0) return { delta: 0 };
      const ts = this.nowISO();
      v.stock = n;
      v.updatedAt = ts;
      await req(s.variants.put(v));
      await req(s.stockMoves.add({ variantId, qty: delta, stockAfter: n, type: 'ajuste', unitCost: v.avgCost, refType: null, refId: null, at: ts, note: why }));
      return { delta };
    });
  }

  async listStockMoves({ variantId = null, limit = 300 } = {}) {
    return this.read('stockMoves', async (s) => {
      const all = variantId != null ? await getAll(s.stockMoves.index('variantId'), variantId) : await getAll(s.stockMoves);
      return all.sort((a, b) => (a.at < b.at ? 1 : a.at > b.at ? -1 : b.id - a.id)).slice(0, limit);
    });
  }
  async listPriceHistory({ variantId = null, limit = 300 } = {}) {
    return this.read('priceHistory', async (s) => {
      const all = variantId != null ? await getAll(s.priceHistory.index('variantId'), variantId) : await getAll(s.priceHistory);
      return all.sort((a, b) => (a.at < b.at ? 1 : a.at > b.at ? -1 : b.id - a.id)).slice(0, limit);
    });
  }

  async _labelFor(s, variantId) {
    const v = await get(s.variants, variantId);
    if (!v) return { v: null, label: '' };
    const m = await get(s.models, v.modelId);
    const b = m ? await get(s.brands, m.brandId) : null;
    return { v, m, label: variantLabel(b?.name ?? '¿?', m?.name ?? '¿?', v.size, v.color) };
  }

  async _findByOpKey(store, opKey) {
    if (!opKey) return null;
    return (await req(store.index('opKey').get(opKey))) || null;
  }

  // ---------- compras ----------
  async createPurchase({ supplierName = '', date, status = 'received', lines, notes = '', updateCost = true, opKey = null }) {
    checkDate(date);
    if (!['received', 'pending'].includes(status)) throw new ValidationError('Estado de compra no válido.');
    if (!Array.isArray(lines) || !lines.length) throw new ValidationError('Añade al menos un producto a la compra.', 'lines');
    const clean = lines.map((l, i) => {
      if (!Number.isInteger(l.variantId)) throw new ValidationError(`Línea ${i + 1}: selecciona un producto.`);
      let qty; let unitCost;
      try { qty = intOrParse(l.qty, 1, 'la cantidad'); } catch (e) { throw new ValidationError(`Línea ${i + 1}: ${e.message}`); }
      try { unitCost = centsOrParse(l.unitCost, 'el coste unitario'); } catch (e) { throw new ValidationError(`Línea ${i + 1}: ${e.message}`); }
      return { variantId: l.variantId, qty, unitCost, lineTotal: qty * unitCost };
    });
    return this.write(['purchases', 'suppliers', 'variants', 'models', 'brands', 'stockMoves', 'priceHistory'], async (s) => {
      const prev = await this._findByOpKey(s.purchases, opKey);
      if (prev) return { id: prev.id, duplicate: true };
      let supplierId = null;
      let supplier = '';
      if (cleanText(supplierName)) {
        const r = (await this._ensureNamed(s.suppliers, supplierName, 'El proveedor')).record;
        supplierId = r.id; supplier = r.name;
      }
      for (const l of clean) {
        const { v, label } = await this._labelFor(s, l.variantId);
        if (!v) throw new ValidationError('Uno de los productos de la compra ya no existe.');
        l.label = label; l.sku = v.sku;
      }
      const ts = this.nowISO();
      const p = {
        date, supplierId, supplier, status, lines: clean, total: clean.reduce((a, l) => a + l.lineTotal, 0),
        notes: cleanText(notes, 500), updateCost: !!updateCost, createdAt: ts, receivedAt: null, receivedDate: null, opKey,
      };
      p.id = await req(s.purchases.add(p));
      if (status === 'received') {
        await this._receive(s, p, date, ts);
        await req(s.purchases.put(p));
      }
      return { id: p.id, duplicate: false };
    });
  }

  async _receive(s, p, date, ts) {
    for (const l of p.lines) {
      const v = await get(s.variants, l.variantId);
      if (!v) throw new ValidationError(`${l.label}: el producto ya no existe.`);
      const newStock = v.stock + l.qty;
      // Coste medio ponderado
      v.avgCost = v.stock > 0 ? roundDiv(v.stock * v.avgCost + l.qty * l.unitCost, newStock) : l.unitCost;
      v.stock = newStock;
      if (p.updateCost && v.cost !== l.unitCost) {
        await req(s.priceHistory.add({ variantId: v.id, field: 'cost', old: v.cost, new: l.unitCost, at: ts, reason: `Compra #${p.id}` }));
        v.cost = l.unitCost;
      }
      v.updatedAt = ts;
      await req(s.variants.put(v));
      await req(s.stockMoves.add({ variantId: v.id, qty: l.qty, stockAfter: newStock, type: 'compra', unitCost: l.unitCost, refType: 'purchase', refId: p.id, at: ts, note: p.supplier || '' }));
    }
    p.status = 'received';
    p.receivedAt = ts;
    p.receivedDate = date;
  }

  async receivePurchase(id, date = this.today()) {
    checkDate(date);
    return this.write(['purchases', 'variants', 'stockMoves', 'priceHistory'], async (s) => {
      const p = await get(s.purchases, id);
      if (!p) throw new ValidationError('La compra no existe.');
      if (p.status === 'received') throw new ValidationError('Esta compra ya se recibió. No se vuelve a sumar el stock.');
      if (p.status !== 'pending') throw new ValidationError('Esta compra está anulada.');
      await this._receive(s, p, date, this.nowISO());
      await req(s.purchases.put(p));
      return p;
    });
  }

  async cancelPurchase(id) {
    return this.write(['purchases'], async (s) => {
      const p = await get(s.purchases, id);
      if (!p) throw new ValidationError('La compra no existe.');
      if (p.status !== 'pending') throw new ValidationError('Solo se pueden anular compras pendientes de recibir.');
      p.status = 'cancelled';
      await req(s.purchases.put(p));
      return p;
    });
  }

  async listPurchases() {
    const r = await this.read('purchases', (s) => getAll(s.purchases));
    return r.sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : b.id - a.id));
  }

  // ---------- ventas ----------
  /**
   * Registra una venta completa. Comprueba existencias y descuenta el stock
   * dentro de la misma transacción, por lo que dos ventas simultáneas no
   * pueden vender la misma unidad.
   * discount: { type: 'amount'|'percent', value } (opcional)
   */
  async createSale({ date, lines, discount = null, paymentMethod = 'Efectivo', notes = '', opKey = null }) {
    checkDate(date);
    if (!Array.isArray(lines) || !lines.length) throw new ValidationError('Añade al menos un producto a la venta.', 'lines');
    if (!PAYMENT_METHODS.includes(paymentMethod)) throw new ValidationError('Forma de pago no válida.');
    const clean = lines.map((l, i) => {
      if (!Number.isInteger(l.variantId)) throw new ValidationError(`Línea ${i + 1}: selecciona un producto.`);
      let qty; let unitPrice = null;
      try { qty = intOrParse(l.qty, 1, 'la cantidad'); } catch (e) { throw new ValidationError(`Línea ${i + 1}: ${e.message}`); }
      if (l.unitPrice != null && l.unitPrice !== '') {
        try { unitPrice = centsOrParse(l.unitPrice, 'el precio'); } catch (e) { throw new ValidationError(`Línea ${i + 1}: ${e.message}`); }
      }
      return { variantId: l.variantId, qty, unitPrice };
    });
    return this.write(['sales', 'variants', 'models', 'brands', 'stockMoves', 'settings'], async (s) => {
      const prev = await this._findByOpKey(s.sales, opKey);
      if (prev) return { id: prev.id, duplicate: true, total: prev.total };
      const allowRow = await get(s.settings, 'allowPriceOverride');
      const allowOverride = allowRow ? !!allowRow.value : DEFAULT_SETTINGS.allowPriceOverride;
      // 1) leer variantes y comprobar existencias acumuladas
      const vmap = new Map();
      const need = new Map();
      for (const l of clean) {
        if (!vmap.has(l.variantId)) {
          const info = await this._labelFor(s, l.variantId);
          if (!info.v) throw new ValidationError('Uno de los productos ya no existe.');
          if (info.v.active === false || info.m?.active === false) throw new ValidationError(`${info.label} está archivado y no se puede vender.`);
          vmap.set(l.variantId, info);
        }
        need.set(l.variantId, (need.get(l.variantId) || 0) + l.qty);
      }
      for (const [id, q] of need) {
        const { v, label } = vmap.get(id);
        if (v.stock < q) throw new ValidationError(`Stock insuficiente de ${label}: hay ${v.stock} y pides ${q}.`);
      }
      // 2) precios y totales
      const out = clean.map((l) => {
        const { v, label } = vmap.get(l.variantId);
        const unitPrice = l.unitPrice ?? v.price;
        if (unitPrice !== v.price && !allowOverride) throw new ValidationError('No está permitido cambiar el precio en la venta (Configuración).');
        return {
          variantId: v.id, label, sku: v.sku, qty: l.qty, unitPrice, listPrice: v.price, unitCost: v.avgCost,
          lineTotal: l.qty * unitPrice, discount: 0, net: 0, returnedQty: 0, refunded: 0, restockedCost: 0,
        };
      });
      const subtotal = out.reduce((a, l) => a + l.lineTotal, 0);
      let disc = 0;
      if (discount && discount.value !== '' && discount.value != null) {
        if (discount.type === 'percent') {
          const bp = parsePercent(discount.value, { label: 'El descuento' });
          if (bp < 0 || bp > 10000) throw new ValidationError('El descuento debe estar entre 0 y 100 %.');
          disc = roundDiv(subtotal * bp, 10000);
        } else {
          disc = centsOrParse(discount.value, 'El descuento');
        }
      }
      if (disc > subtotal) throw new ValidationError('El descuento no puede superar el subtotal.');
      const parts = allocate(disc, out.map((l) => l.lineTotal));
      out.forEach((l, i) => { l.discount = parts[i]; l.net = l.lineTotal - parts[i]; });
      const ts = this.nowISO();
      const sale = {
        date, lines: out, subtotal, discount: disc, total: subtotal - disc,
        cost: out.reduce((a, l) => a + l.qty * l.unitCost, 0), paymentMethod, notes: cleanText(notes, 500),
        status: 'ok', createdAt: ts, opKey,
      };
      sale.id = await req(s.sales.add(sale));
      // 3) descontar existencias
      for (const l of out) {
        const { v } = vmap.get(l.variantId);
        v.stock -= l.qty;
        if (v.stock < 0) throw new ValidationError('Las existencias no pueden quedar en negativo.');
        await req(s.stockMoves.add({ variantId: v.id, qty: -l.qty, stockAfter: v.stock, type: 'venta', unitCost: l.unitCost, refType: 'sale', refId: sale.id, at: ts, note: '' }));
      }
      for (const { v } of vmap.values()) {
        v.updatedAt = ts;
        await req(s.variants.put(v));
      }
      return { id: sale.id, duplicate: false, total: sale.total };
    });
  }

  async getSale(id) { return this.read('sales', (s) => get(s.sales, id)); }

  async listSales({ from = null, to = null } = {}) {
    const r = await this.read('sales', (s) => (from && to ? getAll(s.sales.index('date'), IDBKeyRange.bound(from, to)) : getAll(s.sales)));
    return r.sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : b.id - a.id));
  }

  // ---------- devoluciones ----------
  /**
   * lines: [{ index, qty, restock }] — restock=true vuelve al inventario;
   * restock=false (producto defectuoso) no suma stock.
   */
  async createReturn({ saleId, date, lines, reason = '', opKey = null }) {
    checkDate(date);
    if (!Array.isArray(lines) || !lines.some((l) => Number(l.qty) > 0)) throw new ValidationError('Indica qué unidades se devuelven.');
    return this.write(['sales', 'returns', 'variants', 'stockMoves'], async (s) => {
      const prev = await this._findByOpKey(s.returns, opKey);
      if (prev) return { id: prev.id, duplicate: true, refund: prev.refund };
      const sale = await get(s.sales, saleId);
      if (!sale) throw new ValidationError('La venta no existe.');
      if (date < sale.date) throw new ValidationError('La devolución no puede ser anterior a la venta.');
      const ts = this.nowISO();
      const rlines = [];
      for (const l of lines) {
        const qty = intOrParse(l.qty ?? 0, 0, 'La cantidad devuelta');
        if (!qty) continue;
        const sl = sale.lines[l.index];
        if (!sl) throw new ValidationError('Línea de venta no válida.');
        const avail = sl.qty - sl.returnedQty;
        if (qty > avail) throw new ValidationError(`${sl.label}: solo quedan ${avail} unidades por devolver.`);
        const prevQ = sl.returnedQty;
        const refund = roundDiv(sl.net * (prevQ + qty), sl.qty) - roundDiv(sl.net * prevQ, sl.qty);
        const cost = qty * sl.unitCost;
        sl.returnedQty += qty;
        sl.refunded += refund;
        if (l.restock) {
          sl.restockedCost += cost;
          const v = await get(s.variants, sl.variantId);
          if (v) {
            const ns = v.stock + qty;
            v.avgCost = v.stock > 0 ? roundDiv(v.stock * v.avgCost + cost, ns) : sl.unitCost;
            v.stock = ns;
            v.updatedAt = ts;
            await req(s.variants.put(v));
            await req(s.stockMoves.add({ variantId: v.id, qty, stockAfter: ns, type: 'devolucion', unitCost: sl.unitCost, refType: 'sale', refId: sale.id, at: ts, note: cleanText(reason, 120) }));
          }
        }
        rlines.push({ index: l.index, variantId: sl.variantId, label: sl.label, qty, refund, unitCost: sl.unitCost, restock: !!l.restock });
      }
      if (!rlines.length) throw new ValidationError('Indica qué unidades se devuelven.');
      const allBack = sale.lines.every((x) => x.returnedQty === x.qty);
      sale.status = allBack ? 'returned' : 'partial';
      await req(s.sales.put(sale));
      const ret = {
        saleId, date, lines: rlines, refund: rlines.reduce((a, l) => a + l.refund, 0),
        restockedCost: rlines.filter((l) => l.restock).reduce((a, l) => a + l.qty * l.unitCost, 0),
        reason: cleanText(reason, 200), createdAt: ts, opKey,
      };
      ret.id = await req(s.returns.add(ret));
      return { id: ret.id, duplicate: false, refund: ret.refund };
    });
  }

  async listReturns({ from = null, to = null } = {}) {
    const r = await this.read('returns', (s) => (from && to ? getAll(s.returns.index('date'), IDBKeyRange.bound(from, to)) : getAll(s.returns)));
    return r.sort((a, b) => (a.date < b.date ? 1 : -1));
  }

  // ---------- gastos ----------
  async addExpense({ date, category, amount, note = '', opKey = null }) {
    checkDate(date);
    const cat = cleanText(category, 40);
    if (!cat) throw new ValidationError('La categoría es obligatoria.', 'category');
    const cents = centsOrParse(amount, 'El importe');
    if (cents === 0) throw new ValidationError('El importe debe ser mayor que 0.', 'amount');
    return this.write(['expenses'], async (s) => {
      const prev = await this._findByOpKey(s.expenses, opKey);
      if (prev) return { id: prev.id, duplicate: true };
      const e = { date, category: cat, amount: cents, note: cleanText(note, 300), createdAt: this.nowISO(), opKey };
      e.id = await req(s.expenses.add(e));
      return { id: e.id, duplicate: false };
    });
  }
  async deleteExpense(id) {
    return this.write(['expenses'], async (s) => {
      const e = await get(s.expenses, id);
      if (!e) throw new ValidationError('El gasto no existe.');
      await req(s.expenses.delete(id));
      return e;
    });
  }
  async listExpenses({ from = null, to = null } = {}) {
    const r = await this.read('expenses', (s) => (from && to ? getAll(s.expenses.index('date'), IDBKeyRange.bound(from, to)) : getAll(s.expenses)));
    return r.sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : b.id - a.id));
  }

  // ---------- estadísticas ----------
  async stats({ from, to }) {
    checkDate(from, 'La fecha inicial');
    checkDate(to, 'La fecha final');
    if (from > to) throw new ValidationError('La fecha inicial es posterior a la final.');
    const range = IDBKeyRange.bound(from, to);
    const data = await this.read(['sales', 'returns', 'expenses', 'purchases', 'variants', 'models', 'brands', 'settings'], async (s) => ({
      sales: await getAll(s.sales.index('date'), range),
      returns: await getAll(s.returns.index('date'), range),
      expenses: await getAll(s.expenses.index('date'), range),
      purchases: await getAll(s.purchases),
      variants: await getAll(s.variants),
      models: await getAll(s.models),
      brands: await getAll(s.brands),
      low: await get(s.settings, 'lowStock'),
    }));
    const low = data.low ? data.low.value : DEFAULT_SETTINGS.lowStock;
    const brandById = new Map(data.brands.map((b) => [b.id, b]));
    const modelById = new Map(data.models.map((m) => [m.id, m]));
    const variantById = new Map(data.variants.map((v) => [v.id, v]));

    const r = {
      from, to, salesCount: data.sales.length, unitsSold: 0, grossSales: 0, discounts: 0, refunds: 0, unitsReturned: 0,
      cogs: 0, expenses: 0, purchases: 0, byPayment: {}, byDay: [], byExpenseCategory: {},
    };
    const day = new Map();
    const dayRow = (d) => {
      if (!day.has(d)) day.set(d, { date: d, revenue: 0, profit: 0, units: 0 });
      return day.get(d);
    };
    const perVariant = new Map();
    const pv = (id) => {
      if (!perVariant.has(id)) perVariant.set(id, { units: 0, revenue: 0, cost: 0 });
      return perVariant.get(id);
    };
    for (const sale of data.sales) {
      r.grossSales += sale.total;
      r.discounts += sale.discount;
      r.cogs += sale.cost;
      r.byPayment[sale.paymentMethod] = (r.byPayment[sale.paymentMethod] || 0) + sale.total;
      const d = dayRow(sale.date);
      d.revenue += sale.total;
      d.profit += sale.total - sale.cost;
      for (const l of sale.lines) {
        r.unitsSold += l.qty;
        d.units += l.qty;
        const p = pv(l.variantId);
        p.units += l.qty; p.revenue += l.net; p.cost += l.qty * l.unitCost;
      }
    }
    for (const ret of data.returns) {
      r.refunds += ret.refund;
      r.cogs -= ret.restockedCost;
      const d = dayRow(ret.date);
      d.revenue -= ret.refund;
      d.profit -= ret.refund - ret.restockedCost;
      for (const l of ret.lines) {
        r.unitsReturned += l.qty;
        const p = pv(l.variantId);
        p.units -= l.qty; p.revenue -= l.refund;
        if (l.restock) p.cost -= l.qty * l.unitCost;
      }
    }
    for (const e of data.expenses) {
      r.expenses += e.amount;
      r.byExpenseCategory[e.category] = (r.byExpenseCategory[e.category] || 0) + e.amount;
    }
    for (const p of data.purchases) {
      if (p.status === 'received' && p.receivedDate >= from && p.receivedDate <= to) r.purchases += p.total;
    }
    r.netRevenue = r.grossSales - r.refunds;
    r.grossProfit = r.netRevenue - r.cogs;
    r.netProfit = r.grossProfit - r.expenses;
    r.marginBp = r.netRevenue > 0 ? roundDiv(r.grossProfit * 10000, r.netRevenue) : null;
    r.avgTicket = r.salesCount ? roundDiv(r.grossSales, r.salesCount) : 0;
    // serie diaria completa (días sin ventas = 0)
    const days = [];
    const start = new Date(`${from}T00:00:00Z`);
    const end = new Date(`${to}T00:00:00Z`);
    for (let d = start; d <= end && days.length < 1200; d = new Date(d.getTime() + 86400000)) {
      const k = d.toISOString().slice(0, 10);
      days.push(day.get(k) || { date: k, revenue: 0, profit: 0, units: 0 });
    }
    r.byDay = days;
    // ranking por modelo y marca
    const byModel = new Map();
    const byBrand = new Map();
    for (const [vid, p] of perVariant) {
      const v = variantById.get(vid);
      const m = v ? modelById.get(v.modelId) : null;
      const b = m ? brandById.get(m.brandId) : null;
      const mk = m ? m.id : `x${vid}`;
      if (!byModel.has(mk)) byModel.set(mk, { name: m ? `${b?.name ?? ''} ${m.name}` : 'Producto eliminado', units: 0, revenue: 0, profit: 0 });
      const bm = byModel.get(mk);
      bm.units += p.units; bm.revenue += p.revenue; bm.profit += p.revenue - p.cost;
      const bk = b ? b.id : 'x';
      if (!byBrand.has(bk)) byBrand.set(bk, { name: b?.name ?? 'Sin marca', units: 0, revenue: 0, profit: 0 });
      const bb = byBrand.get(bk);
      bb.units += p.units; bb.revenue += p.revenue; bb.profit += p.revenue - p.cost;
    }
    r.topModels = [...byModel.values()].sort((a, b) => b.revenue - a.revenue || b.units - a.units);
    r.byBrand = [...byBrand.values()].sort((a, b) => b.revenue - a.revenue);
    // foto actual del inventario
    r.stockUnits = 0; r.stockValue = 0; r.stockRetail = 0; r.lowStock = [];
    for (const v of data.variants) {
      if (v.active === false) continue;
      r.stockUnits += v.stock;
      r.stockValue += v.stock * v.avgCost;
      r.stockRetail += v.stock * v.price;
      const m = modelById.get(v.modelId);
      if (v.stock <= low && m?.active !== false) {
        r.lowStock.push({ variantId: v.id, stock: v.stock, label: variantLabel(brandById.get(m?.brandId)?.name ?? '', m?.name ?? '', v.size, v.color) });
      }
    }
    r.lowStock.sort((a, b) => a.stock - b.stock);
    r.pendingPurchases = data.purchases.filter((p) => p.status === 'pending').length;
    return r;
  }

  // ---------- copia de seguridad ----------
  async exportBackup() {
    const data = await this.read(STORES, async (s) => {
      const o = {};
      for (const n of STORES) o[n] = await getAll(s[n]);
      return o;
    });
    return { app: 'ChinelaStock', format: BACKUP_FORMAT, exportedAt: this.nowISO(), data };
  }

  async markBackupDone() {
    await this.setSettings({ lastBackupAt: this.nowISO() });
  }

  /** Valida una copia antes de restaurarla. Devuelve un resumen o lanza un error claro. */
  static validateBackup(obj) {
    if (!obj || obj.app !== 'ChinelaStock' || !obj.data) throw new ValidationError('El archivo no es una copia de seguridad de ChinelaStock.');
    if (obj.format !== BACKUP_FORMAT) throw new ValidationError('La copia es de una versión no compatible.');
    for (const n of STORES) if (!Array.isArray(obj.data[n])) throw new ValidationError(`La copia está incompleta (falta "${n}").`);
    const d = obj.data;
    const ids = (n) => new Set(d[n].map((r) => r.id));
    const brandIds = ids('brands');
    const modelIds = ids('models');
    const okInt = (x) => Number.isSafeInteger(x) && x >= 0;
    for (const n of STORES.filter((x) => x !== 'settings')) {
      for (const r of d[n]) if (!Number.isSafeInteger(r.id)) throw new ValidationError(`Registro sin identificador válido en "${n}".`);
    }
    for (const m of d.models) if (!brandIds.has(m.brandId)) throw new ValidationError(`El modelo "${m.name}" apunta a una marca que no existe.`);
    for (const v of d.variants) {
      if (!modelIds.has(v.modelId)) throw new ValidationError(`La variante ${v.sku} apunta a un modelo que no existe.`);
      if (![v.cost, v.price, v.avgCost, v.stock].every(okInt)) throw new ValidationError(`La variante ${v.sku} tiene precios o existencias no válidos.`);
    }
    for (const sale of d.sales) {
      if (!okInt(sale.total) || !Array.isArray(sale.lines)) throw new ValidationError(`La venta #${sale.id} no es válida.`);
    }
    return { brands: d.brands.length, models: d.models.length, variants: d.variants.length, sales: d.sales.length, purchases: d.purchases.length, expenses: d.expenses.length };
  }

  /** Sustituye TODOS los datos por los de la copia, en una sola transacción. */
  async importBackup(obj) {
    const summary = Store.validateBackup(obj);
    await this.write(STORES, async (s) => {
      for (const n of STORES) await req(s[n].clear());
      for (const n of STORES) for (const r of obj.data[n]) await req(s[n].add(r));
    });
    return summary;
  }
}
