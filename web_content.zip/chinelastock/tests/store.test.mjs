import 'fake-indexeddb/auto';
import { test, beforeEach, afterEach } from 'node:test';
import assert from 'node:assert/strict';
import { Store, newOpKey } from '../js/core/store.js';
import { deleteDB } from '../js/core/db.js';
import { buildExport } from '../js/core/exports.js';
import { ValidationError } from '../js/core/money.js';

let store;
let dbName;
let n = 0;
const D = '2026-10-01';

beforeEach(async () => {
  dbName = `test-${process.pid}-${n++}`;
  store = await Store.open(dbName, { channelName: null });
});
afterEach(async () => {
  store.close();
  await deleteDB(dbName);
});

async function classic(extra = {}) {
  return store.createProduct({
    brandName: 'Marca A', modelName: 'Classic', supplierName: 'Prov 1',
    variants: [
      { size: '38', color: 'Negro', cost: '4,00', price: '9,00', qty: 10 },
      { size: '39', color: 'Negro', cost: '4,00', price: '9,00', qty: 12 },
      { size: '40', color: 'Blanco', cost: '4,50', price: '10,00', qty: 8 },
    ],
    ...extra,
  });
}
const variant = async (id) => (await store.loadCatalog()).variants.find((v) => v.id === id);

// ---------- productos, marcas, variantes ----------
test('alta de producto con varias variantes, marca y proveedor nuevos', async () => {
  const r = await classic();
  assert.equal(r.variantIds.length, 3);
  assert.equal(r.addedToExisting, false);
  const cat = await store.loadCatalog();
  assert.equal(cat.brands.length, 1);
  assert.equal(cat.suppliers.length, 1);
  assert.equal(cat.models.length, 1);
  const v40 = cat.variants.find((v) => v.size === '40');
  assert.equal(v40.price, 1000);
  assert.equal(v40.cost, 450);
  assert.equal(v40.avgCost, 450);
  assert.equal(v40.stock, 8);
  assert.match(v40.sku, /^MAR-CLAS-40-BLA$/);
  const moves = await store.listStockMoves({ variantId: v40.id });
  assert.equal(moves.length, 1);
  assert.equal(moves[0].type, 'inicial');
});

test('crear marca: no duplica aunque cambien mayúsculas o tildes', async () => {
  await store.createBrand('Havaianas');
  await assert.rejects(store.createBrand('  havaíanas '), ValidationError);
  await store.createProduct({ brandName: 'HAVAIANAS', modelName: 'Top', variants: [{ size: '37', cost: '3', price: '7' }] });
  assert.equal((await store.listBrands()).length, 1);
});

test('campos obligatorios y validaciones del alta', async () => {
  await assert.rejects(store.createProduct({ brandName: 'A', modelName: '', variants: [{ size: '1', cost: 1, price: 1 }] }), /modelo es obligatorio/);
  await assert.rejects(store.createProduct({ brandName: '', modelName: 'X', variants: [{ size: '1', cost: 1, price: 1 }] }), /marca es obligatoria/);
  await assert.rejects(store.createProduct({ brandName: 'A', modelName: 'X', variants: [] }), /al menos una talla/);
  await assert.rejects(store.createProduct({ brandName: 'A', modelName: 'X', variants: [{ size: '', cost: '1', price: '2' }] }), /talla es obligatoria/);
  await assert.rejects(store.createProduct({ brandName: 'A', modelName: 'X', variants: [{ size: '38', cost: 'abc', price: '2' }] }), /precio de compra/);
  await assert.rejects(store.createProduct({ brandName: 'A', modelName: 'X', variants: [{ size: '38', cost: '1', price: '2', qty: '-3' }] }), /cantidad inicial/);
  await assert.rejects(store.createProduct({ brandName: 'A', modelName: 'X', variants: [{ size: '38', color: 'Rojo', cost: '1', price: '2' }, { size: '38', color: 'rojo', cost: '1', price: '2' }] }), /repetida/);
  // Ningún intento fallido debe haber dejado registros a medias
  const cat = await store.loadCatalog();
  assert.equal(cat.models.length, 0);
  assert.equal(cat.variants.length, 0);
  assert.equal(cat.brands.length, 0);
});

test('mismo modelo: añade variantes nuevas legítimas y rechaza las repetidas sin guardar nada', async () => {
  const a = await classic();
  const b = await store.createProduct({ brandName: 'marca a', modelName: 'CLASSIC', variants: [{ size: '41', color: 'Negro', cost: '4', price: '9' }] });
  assert.equal(b.addedToExisting, true);
  assert.equal(b.modelId, a.modelId);
  await assert.rejects(
    store.createProduct({ brandName: 'Marca A', modelName: 'Classic', variants: [{ size: '42', color: 'Negro', cost: '4', price: '9' }, { size: '38', color: 'negro', cost: '4', price: '9' }] }),
    /ya tiene la talla 38/,
  );
  const cat = await store.loadCatalog();
  assert.equal(cat.variants.length, 4, 'la talla 42 no se guardó porque la operación completa se canceló');
  const check = await store.checkProductDraft({ brandName: 'Marca A', modelName: 'Classic', variants: [{ size: '39', color: 'Negro' }, { size: '43' }] });
  assert.ok(check.model);
  assert.equal(check.rowIssues.length, 1);
  assert.equal(check.rowIssues[0].row, 0);
});

test('referencias (SKU) únicas', async () => {
  await store.createProduct({ brandName: 'A', modelName: 'X', variants: [{ sku: 'ref-1', size: '38', cost: '1', price: '2' }] });
  await assert.rejects(store.createProduct({ brandName: 'B', modelName: 'Y', variants: [{ sku: 'REF-1', size: '38', cost: '1', price: '2' }] }), /REF-1 ya está en uso/);
  // SKU automático no colisiona
  const r = await store.createProduct({ brandName: 'A', modelName: 'X2', variants: [{ size: '38', cost: '1', price: '2' }, { size: '38 ', color: 'Azul', cost: '1', price: '2' }] });
  const cat = await store.loadCatalog();
  const skus = cat.variants.map((v) => v.sku);
  assert.equal(new Set(skus).size, skus.length);
  assert.equal(r.variantIds.length, 2);
});

test('duplicar producto: copia descripción pero no existencias ni historial', async () => {
  const a = await classic();
  await store.createSale({ date: D, lines: [{ variantId: a.variantIds[0], qty: 2 }] });
  // La interfaz duplica copiando datos descriptivos y dejando cantidad 0
  const cat = await store.loadCatalog();
  const src = cat.modelById.get(a.modelId);
  const dup = await store.createProduct({
    brandName: src.brandName, modelName: 'Classic Plus', supplierName: src.supplierName, notes: src.notes,
    variants: src.variants.map((v) => ({ size: v.size, color: v.color, cost: v.cost, price: v.price, qty: 0 })),
  });
  const cat2 = await store.loadCatalog();
  const nv = cat2.variants.filter((v) => dup.variantIds.includes(v.id));
  assert.equal(nv.length, 3);
  assert.ok(nv.every((v) => v.stock === 0));
  assert.equal((await variant(a.variantIds[0])).stock, 8, 'el original conserva su stock');
  for (const v of nv) assert.equal((await store.listStockMoves({ variantId: v.id })).length, 0);
});

// ---------- precios ----------
test('cambiar precio NO modifica ventas anteriores ni sus ingresos', async () => {
  const a = await classic();
  const vid = a.variantIds[0];
  const sale = await store.createSale({ date: D, lines: [{ variantId: vid, qty: 2 }] });
  const before = await store.stats({ from: D, to: D });
  await store.setPrice(vid, 'price', '12,00');
  await store.setPrice(vid, 'cost', '6,00');
  const after = await store.stats({ from: D, to: D });
  const s = await store.getSale(sale.id);
  assert.equal(s.lines[0].unitPrice, 900);
  assert.equal(s.lines[0].unitCost, 400);
  assert.equal(after.netRevenue, before.netRevenue);
  assert.equal(after.grossProfit, before.grossProfit);
  assert.equal(after.netRevenue, 1800);
  // la siguiente venta usa el precio nuevo
  const s2 = await store.createSale({ date: D, lines: [{ variantId: vid, qty: 1 }] });
  assert.equal(s2.total, 1200);
  // el coste de reposición cambió, pero el coste medio de las existencias se conserva
  const v = await variant(vid);
  assert.equal(v.cost, 600);
  assert.equal(v.avgCost, 400);
  const hist = await store.listPriceHistory({ variantId: vid });
  const priceChange = hist.find((h) => h.field === 'price' && h.reason === 'Edición manual');
  assert.equal(priceChange.old, 900);
  assert.equal(priceChange.new, 1200);
});

test('corregir coste del stock actual (opcional)', async () => {
  const a = await classic();
  await store.setPrice(a.variantIds[0], 'cost', '3,50', { applyToStockCost: true, reason: 'Error de alta' });
  const v = await variant(a.variantIds[0]);
  assert.equal(v.avgCost, 350);
});

test('cambio masivo: vista previa, confirmación, redondeo e historial', async () => {
  const a = await classic();
  const rows = await store.previewBulkPrice({ variantIds: a.variantIds, field: 'price', mode: 'percent', value: '10' });
  assert.deepEqual(rows.map((r) => [r.old, r.new, r.diff]), [[900, 990, 90], [900, 990, 90], [1000, 1100, 100]]);
  // La vista previa no guarda nada
  assert.equal((await variant(a.variantIds[0])).price, 900);
  const res = await store.applyBulkPrice(rows);
  assert.equal(res.changed, 3);
  assert.equal((await variant(a.variantIds[2])).price, 1100);
  const hist = (await store.listPriceHistory()).filter((h) => h.reason === 'Cambio masivo');
  assert.equal(hist.length, 3);
  // Cambio fijo hacia abajo y redondeo a 0,50
  const r2 = await store.previewBulkPrice({ variantIds: [a.variantIds[0]], field: 'price', mode: 'amount', value: '0,37', direction: 'down', rounding: 50 });
  assert.equal(r2[0].new, 950); // 9,90 - 0,37 = 9,53 -> 9,50
  // Fijar precio
  const r3 = await store.previewBulkPrice({ variantIds: a.variantIds, field: 'cost', mode: 'set', value: '5' });
  assert.ok(r3.every((r) => r.new === 500));
});

test('cambio masivo: rechaza negativos y conflictos', async () => {
  const a = await classic();
  const rows = await store.previewBulkPrice({ variantIds: [a.variantIds[0]], field: 'price', mode: 'amount', value: '20', direction: 'down' });
  assert.ok(rows[0].error);
  await assert.rejects(store.applyBulkPrice(rows), /errores/);
  const ok = await store.previewBulkPrice({ variantIds: [a.variantIds[0]], field: 'price', mode: 'percent', value: '5' });
  await store.setPrice(a.variantIds[0], 'price', '9,10'); // alguien cambia el precio entre la vista previa y la confirmación
  await assert.rejects(store.applyBulkPrice(ok), /cambió mientras revisabas/);
  assert.equal((await variant(a.variantIds[0])).price, 910);
});

// ---------- compras ----------
test('compra recibida: suma stock y recalcula coste medio ponderado', async () => {
  const a = await classic();
  const vid = a.variantIds[0]; // 10 uds a 4,00
  const p = await store.createPurchase({ supplierName: 'Prov 2', date: D, status: 'received', lines: [{ variantId: vid, qty: 10, unitCost: '5,00' }] });
  const v = await variant(vid);
  assert.equal(v.stock, 20);
  assert.equal(v.avgCost, 450); // (10*400 + 10*500) / 20
  assert.equal(v.cost, 500, 'último precio de compra actualizado');
  const list = await store.listPurchases();
  assert.equal(list[0].total, 5000);
  assert.equal(list[0].id, p.id);
});

test('compra pendiente: no suma stock hasta recibirla y no se recibe dos veces', async () => {
  const a = await classic();
  const vid = a.variantIds[1];
  const p = await store.createPurchase({ date: D, status: 'pending', lines: [{ variantId: vid, qty: 5, unitCost: '4' }] });
  assert.equal((await variant(vid)).stock, 12);
  await store.receivePurchase(p.id, '2026-10-02');
  assert.equal((await variant(vid)).stock, 17);
  await assert.rejects(store.receivePurchase(p.id), /ya se recibió/);
  assert.equal((await variant(vid)).stock, 17);
  const p2 = await store.createPurchase({ date: D, status: 'pending', lines: [{ variantId: vid, qty: 5, unitCost: '4' }] });
  await store.cancelPurchase(p2.id);
  await assert.rejects(store.receivePurchase(p2.id), /anulada/);
});

test('compra: validaciones', async () => {
  const a = await classic();
  await assert.rejects(store.createPurchase({ date: D, lines: [] }), /al menos un producto/);
  await assert.rejects(store.createPurchase({ date: '2026-02-30', lines: [{ variantId: a.variantIds[0], qty: 1, unitCost: '1' }] }), /fecha no es válida/);
  await assert.rejects(store.createPurchase({ date: D, lines: [{ variantId: a.variantIds[0], qty: 0, unitCost: '1' }] }), /como mínimo 1/);
  await assert.rejects(store.createPurchase({ date: D, lines: [{ variantId: 9999, qty: 1, unitCost: '1' }] }), /ya no existe/);
});

// ---------- ventas ----------
test('venta con varios productos y descuento: totales, stock y margen', async () => {
  const a = await classic();
  const [v38, v39, v40] = a.variantIds;
  const r = await store.createSale({
    date: D, paymentMethod: 'Tarjeta',
    lines: [{ variantId: v38, qty: 2 }, { variantId: v40, qty: 1 }, { variantId: v39, qty: 1, unitPrice: '8,50' }],
    discount: { type: 'amount', value: '1,00' },
  });
  // Cálculo de referencia independiente
  const subtotal = 2 * 900 + 1 * 1000 + 850;
  assert.equal(r.total, subtotal - 100);
  const s = await store.getSale(r.id);
  assert.equal(s.lines.reduce((a2, l) => a2 + l.net, 0), s.total);
  assert.equal(s.cost, 2 * 400 + 450 + 400);
  assert.equal((await variant(v38)).stock, 8);
  assert.equal((await variant(v40)).stock, 7);
  assert.equal((await variant(v39)).stock, 11);
  const st = await store.stats({ from: D, to: D });
  assert.equal(st.netRevenue, 3550);
  assert.equal(st.cogs, 1650);
  assert.equal(st.grossProfit, 1900);
  assert.equal(st.unitsSold, 4);
  assert.equal(st.byPayment.Tarjeta, 3550);
});

test('venta: no permite existencias negativas (también con líneas repetidas)', async () => {
  const a = await classic();
  const vid = a.variantIds[2]; // 8 uds
  await assert.rejects(store.createSale({ date: D, lines: [{ variantId: vid, qty: 9 }] }), /Stock insuficiente.*hay 8 y pides 9/);
  await assert.rejects(store.createSale({ date: D, lines: [{ variantId: vid, qty: 5 }, { variantId: vid, qty: 4 }] }), /hay 8 y pides 9/);
  assert.equal((await variant(vid)).stock, 8);
  assert.equal((await store.listSales()).length, 0);
});

test('venta: cambio de precio bloqueado si no está autorizado', async () => {
  const a = await classic();
  await store.setSettings({ allowPriceOverride: false });
  await assert.rejects(store.createSale({ date: D, lines: [{ variantId: a.variantIds[0], qty: 1, unitPrice: '1,00' }] }), /No está permitido/);
  const ok = await store.createSale({ date: D, lines: [{ variantId: a.variantIds[0], qty: 1 }] });
  assert.equal(ok.total, 900);
});

test('doble pulsación: la misma operación no se registra dos veces', async () => {
  const a = await classic();
  const opKey = newOpKey();
  const payload = { date: D, lines: [{ variantId: a.variantIds[0], qty: 1 }], opKey };
  const [r1, r2] = await Promise.all([store.createSale(payload), store.createSale(payload)]);
  assert.equal(r1.id, r2.id);
  assert.equal([r1.duplicate, r2.duplicate].filter(Boolean).length, 1);
  assert.equal((await store.listSales()).length, 1);
  assert.equal((await variant(a.variantIds[0])).stock, 9);
  const pk = newOpKey();
  await store.createPurchase({ date: D, lines: [{ variantId: a.variantIds[0], qty: 3, unitCost: '4' }], opKey: pk });
  await store.createPurchase({ date: D, lines: [{ variantId: a.variantIds[0], qty: 3, unitCost: '4' }], opKey: pk });
  assert.equal((await variant(a.variantIds[0])).stock, 12);
  const ek = newOpKey();
  await store.addExpense({ date: D, category: 'Alquiler', amount: '300', opKey: ek });
  await store.addExpense({ date: D, category: 'Alquiler', amount: '300', opKey: ek });
  assert.equal((await store.listExpenses()).length, 1);
});

test('ventas simultáneas: no se vende más de lo disponible (condición de carrera)', async () => {
  const r = await store.createProduct({ brandName: 'A', modelName: 'Única', variants: [{ size: '40', cost: '4', price: '9', qty: 3 }] });
  const vid = r.variantIds[0];
  const attempts = Array.from({ length: 10 }, () => store.createSale({ date: D, lines: [{ variantId: vid, qty: 1 }] }).then(() => 'ok', (e) => e.message));
  const results = await Promise.all(attempts);
  assert.equal(results.filter((x) => x === 'ok').length, 3);
  assert.equal(results.filter((x) => /Stock insuficiente/.test(x)).length, 7);
  assert.equal((await variant(vid)).stock, 0);
  // Segunda conexión a la misma base de datos (como otra pestaña)
  const other = await Store.open(dbName, { channelName: null });
  await store.createPurchase({ date: D, lines: [{ variantId: vid, qty: 2, unitCost: '4' }] });
  const both = await Promise.all([
    store.createSale({ date: D, lines: [{ variantId: vid, qty: 2 }] }).then(() => 'ok', (e) => e.message),
    other.createSale({ date: D, lines: [{ variantId: vid, qty: 2 }] }).then(() => 'ok', (e) => e.message),
  ]);
  other.close();
  assert.equal(both.filter((x) => x === 'ok').length, 1);
  assert.equal((await variant(vid)).stock, 0);
});

// ---------- devoluciones ----------
test('devoluciones: reembolso proporcional, stock y estadísticas', async () => {
  const a = await classic();
  const [v38, , v40] = a.variantIds;
  const sale = await store.createSale({ date: D, lines: [{ variantId: v38, qty: 3 }, { variantId: v40, qty: 1 }], discount: { type: 'percent', value: '10' } });
  // subtotal 2700+1000=3700, descuento 370, total 3330
  assert.equal(sale.total, 3330);
  const D2 = '2026-10-03';
  const r1 = await store.createReturn({ saleId: sale.id, date: D2, lines: [{ index: 0, qty: 1, restock: true }], reason: 'Talla' });
  const s = await store.getSale(sale.id);
  // neto línea 0: 2700 - reparto del descuento
  const net0 = s.lines[0].net;
  assert.equal(r1.refund, Math.round(net0 / 3));
  assert.equal((await variant(v38)).stock, 8); // 10 -3 +1
  // Defectuoso: no vuelve al stock
  await store.createReturn({ saleId: sale.id, date: D2, lines: [{ index: 1, qty: 1, restock: false }] });
  assert.equal((await variant(v40)).stock, 7);
  await assert.rejects(store.createReturn({ saleId: sale.id, date: D2, lines: [{ index: 1, qty: 1, restock: false }] }), /solo quedan 0/);
  await assert.rejects(store.createReturn({ saleId: sale.id, date: '2026-09-01', lines: [{ index: 0, qty: 1, restock: true }] }), /anterior a la venta/);
  // devolver el resto: la suma de reembolsos debe ser exactamente el neto de la línea
  await store.createReturn({ saleId: sale.id, date: D2, lines: [{ index: 0, qty: 2, restock: true }] });
  const s2 = await store.getSale(sale.id);
  assert.equal(s2.lines[0].refunded, s2.lines[0].net);
  assert.equal(s2.status, 'returned');
  const st = await store.stats({ from: D, to: D2 });
  assert.equal(st.netRevenue, 0);
  // Coste: las 3 de la talla 38 vuelven al stock; la defectuosa (4,50) es pérdida
  assert.equal(st.cogs, 450);
  assert.equal(st.grossProfit, -450);
});

// ---------- inventario, gastos y estadísticas ----------
test('ajuste de inventario exige motivo y no admite negativos', async () => {
  const a = await classic();
  await assert.rejects(store.setStock(a.variantIds[0], 5, ''), /motivo/);
  await assert.rejects(store.setStock(a.variantIds[0], -1, 'Recuento'), ValidationError);
  await store.setStock(a.variantIds[0], 7, 'Recuento');
  const v = await variant(a.variantIds[0]);
  assert.equal(v.stock, 7);
  const mv = await store.listStockMoves({ variantId: v.id });
  assert.equal(mv[0].qty, -3);
  assert.equal(mv[0].type, 'ajuste');
});

test('estadísticas: período, gastos, beneficio neto e inventario (cálculo de referencia)', async () => {
  const a = await classic();
  const [v38, v39] = a.variantIds;
  await store.createSale({ date: '2026-10-01', lines: [{ variantId: v38, qty: 1 }] });
  await store.createSale({ date: '2026-10-05', lines: [{ variantId: v39, qty: 2 }] });
  await store.createSale({ date: '2026-11-01', lines: [{ variantId: v39, qty: 1 }] });
  await store.addExpense({ date: '2026-10-10', category: 'Transporte', amount: '12,35' });
  await store.addExpense({ date: '2026-11-02', category: 'Alquiler', amount: '300' });
  const oct = await store.stats({ from: '2026-10-01', to: '2026-10-31' });
  assert.equal(oct.salesCount, 2);
  assert.equal(oct.netRevenue, 2700);
  assert.equal(oct.cogs, 1200);
  assert.equal(oct.expenses, 1235);
  assert.equal(oct.netProfit, 2700 - 1200 - 1235);
  assert.equal(oct.byDay.length, 31);
  assert.equal(oct.byDay.reduce((x, d) => x + d.revenue, 0), oct.netRevenue);
  assert.equal(oct.avgTicket, 1350);
  assert.equal(oct.marginBp, Math.round((1500 / 2700) * 10000));
  assert.equal(oct.topModels[0].units, 3);
  // Inventario actual: 9*400 + 9*400 + 8*450
  assert.equal(oct.stockUnits, 26);
  assert.equal(oct.stockValue, 9 * 400 + 9 * 400 + 8 * 450);
  await assert.rejects(store.stats({ from: '2026-10-31', to: '2026-10-01' }), /posterior/);
});

test('búsqueda por nombre, marca, referencia, talla y color', async () => {
  await classic();
  await store.createProduct({ brandName: 'Rider', modelName: 'Strike', variants: [{ size: '42', color: 'Azul', cost: '5', price: '12', sku: 'RD-42' }] });
  assert.equal((await store.searchVariants('classic')).length, 3);
  assert.equal((await store.searchVariants('marca a 40')).length, 1);
  assert.equal((await store.searchVariants('rd-42')).length, 1);
  assert.equal((await store.searchVariants('negro')).length, 2);
  assert.equal((await store.searchVariants('blanco 39')).length, 0);
});

test('persistencia: los datos siguen ahí al cerrar y volver a abrir', async () => {
  const a = await classic();
  await store.createSale({ date: D, lines: [{ variantId: a.variantIds[0], qty: 1 }] });
  await store.setSettings({ theme: 'dark', currency: 'USD' });
  store.close();
  store = await Store.open(dbName, { channelName: null });
  const cat = await store.loadCatalog();
  assert.equal(cat.variants.length, 3);
  assert.equal((await store.listSales()).length, 1);
  const st = await store.getSettings();
  assert.equal(st.theme, 'dark');
  assert.equal(st.currency, 'USD');
});

test('copia de seguridad: exportar, validar y restaurar de forma íntegra', async () => {
  const a = await classic();
  await store.createSale({ date: D, lines: [{ variantId: a.variantIds[0], qty: 2 }] });
  const backup = JSON.parse(JSON.stringify(await store.exportBackup()));
  await store.createSale({ date: D, lines: [{ variantId: a.variantIds[0], qty: 1 }] });
  await assert.rejects(store.importBackup({ app: 'otra', data: {} }), /no es una copia/);
  const broken = JSON.parse(JSON.stringify(backup));
  broken.data.variants[0].stock = -5;
  await assert.rejects(store.importBackup(broken), /no válidos/);
  assert.equal((await store.listSales()).length, 2, 'una copia rechazada no toca los datos');
  const sum = await store.importBackup(backup);
  assert.equal(sum.sales, 1);
  assert.equal((await store.listSales()).length, 1);
  assert.equal((await variant(a.variantIds[0])).stock, 8);
  // tras restaurar, los nuevos ids no chocan con los existentes
  const s3 = await store.createSale({ date: D, lines: [{ variantId: a.variantIds[0], qty: 1 }] });
  assert.ok(s3.id > 1);
});

test('exportaciones CSV', async () => {
  const a = await classic();
  await store.createSale({ date: D, lines: [{ variantId: a.variantIds[0], qty: 2 }], notes: 'Cliente; "VIP"' });
  const inv = await buildExport(store, 'inventario');
  assert.match(inv.filename, /^inventario-\d{4}-\d{2}-\d{2}\.csv$/);
  const lines = inv.content.replace('﻿', '').trim().split('\r\n');
  assert.equal(lines.length, 4);
  assert.match(lines[1], /;9,00;/);
  const ventas = await buildExport(store, 'ventas');
  assert.match(ventas.content, /;2;9,00;0,00;18,00;4,00;10,00;0;0,00/);
  for (const k of ['compras', 'gastos', 'devoluciones']) assert.ok((await buildExport(store, k)).content.startsWith('﻿'));
});

test('eventos de cambio: solo se emiten tras confirmar la transacción', async () => {
  const events = [];
  store.addEventListener('change', (e) => events.push(e.detail.stores));
  await classic();
  assert.equal(events.length, 1);
  await assert.rejects(store.createSale({ date: D, lines: [{ variantId: 999, qty: 1 }] }));
  assert.equal(events.length, 1, 'una operación fallida no notifica cambios');
});

test('configuración: valida valores', async () => {
  await assert.rejects(store.setSettings({ currency: 'euros' }), /3 letras/);
  await assert.rejects(store.setSettings({ hack: 1 }), /desconocido/);
  await store.setSettings({ lowStock: '5' });
  assert.equal((await store.getSettings()).lowStock, 5);
});
