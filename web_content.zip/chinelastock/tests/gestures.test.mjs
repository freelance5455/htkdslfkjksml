import { test } from 'node:test';
import assert from 'node:assert/strict';
import { decideSwipe } from '../js/ui/gestures.js';

test('gestos: deslizamiento horizontal claro cambia de sección', () => {
  assert.equal(decideSwipe({ dx: -120, dy: 10, dt: 200 }), 'next');
  assert.equal(decideSwipe({ dx: 130, dy: -15, dt: 250 }), 'prev');
});

test('gestos: se ignoran desplazamientos cortos, verticales o lentos', () => {
  assert.equal(decideSwipe({ dx: -40, dy: 0, dt: 100 }), null);
  assert.equal(decideSwipe({ dx: -120, dy: 90, dt: 200 }), null);
  assert.equal(decideSwipe({ dx: -80, dy: 44, dt: 200 }), null); // demasiado diagonal
  assert.equal(decideSwipe({ dx: -200, dy: 0, dt: 1500 }), null);
});
