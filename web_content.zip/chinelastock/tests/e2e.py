"""Pruebas de extremo a extremo en Chromium (móvil y escritorio) con Playwright.

Uso:  python3 tests/e2e.py        (sirve la app en un puerto local temporal)
Requisitos: pip install playwright && python3 -m playwright install chromium
"""
import functools
import http.server
import json
import os
import re
import socketserver
import sys
import threading
import time
import traceback

from playwright.sync_api import sync_playwright, expect

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RESULTS = []
SHARED = {}


class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a):
        pass


def serve():
    handler = functools.partial(Quiet, directory=ROOT)
    httpd = socketserver.TCPServer(("127.0.0.1", 0), handler)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    return httpd, f"http://localhost:{httpd.server_address[1]}"


def case(name):
    def deco(fn):
        fn.case_name = name
        return fn
    return deco


# ---------------------------------------------------------------- utilidades
def modal(pg):
    return pg.locator(".modal-backdrop").last


def wait_toast(pg, text):
    expect(pg.locator(".toast", has_text=text).last).to_be_visible(timeout=5000)


def go(pg, base, route):
    pg.evaluate(f"location.hash = '#/{route}'")
    expect(pg.locator("#view")).to_have_attribute("data-route", route, timeout=5000)
    pg.wait_for_timeout(150)


def app_eval(pg, js):
    return pg.evaluate(f"async () => {{ const app = window.__chinela; {js} }}")


def variants(pg):
    return app_eval(pg, "const c = await app.store.loadCatalog(); return c.variants.map(v => ({id: v.id, label: v.label, sku: v.sku, size: v.size, color: v.color, price: v.price, cost: v.cost, stock: v.stock, avgCost: v.avgCost}));")


def swipe(pg, cdp, x0, y0, x1, y1, steps=6, duration=0.18):
    cdp.send("Input.dispatchTouchEvent", {"type": "touchStart", "touchPoints": [{"x": x0, "y": y0}]})
    for i in range(1, steps + 1):
        cdp.send("Input.dispatchTouchEvent", {"type": "touchMove", "touchPoints": [{"x": x0 + (x1 - x0) * i / steps, "y": y0 + (y1 - y0) * i / steps}]})
        time.sleep(duration / steps)
    cdp.send("Input.dispatchTouchEvent", {"type": "touchEnd", "touchPoints": []})
    pg.wait_for_timeout(300)


def add_product(pg, brand, model, rows, again=False):
    """rows: lista de (talla, color, coste, venta, cantidad)."""
    m = modal(pg)
    m.locator("[name=brandName]").fill(brand)
    m.locator("[name=modelName]").fill(model)
    for i, r in enumerate(rows):
        if i > 0:
            m.locator("[data-add-row]").click()
        for k, v in zip(["size", "color", "cost", "price", "qty"], r):
            m.locator(f"[name='variants.{i}.{k}']").fill(str(v))
    if again:
        m.locator("[data-again]").click()
    else:
        m.get_by_role("button", name="Guardar", exact=True).click()


# ---------------------------------------------------------------- casos
@case("Alta rápida de producto con marca nueva, varias tallas y colores")
def t_add_product(pg, base, **_):
    go(pg, base, "productos")
    pg.get_by_role("button", name="+ Añadir producto").first.click()
    m = modal(pg)
    m.locator("[name=brandName]").fill("Marca A")
    expect(m.locator("[data-hint=brand]")).to_contain_text("Marca nueva", timeout=3000)
    m.locator("[data-create-brand]").click()
    wait_toast(pg, "Marca «Marca A» creada")
    expect(m.locator("[data-hint=brand]")).to_contain_text("Marca registrada")
    pg.keyboard.press("Tab")
    m.locator("[name=modelName]").fill("Classic")
    # primera fila
    for k, v in [("size", "38"), ("color", "Negro"), ("cost", "4,00"), ("price", "9,00"), ("qty", "10")]:
        m.locator(f"[name='variants.0.{k}']").fill(v)
    # «+ Talla» copia color y precios y sugiere la siguiente talla
    m.locator("[data-add-row]").click()
    assert m.locator("[name='variants.1.size']").input_value() == "39"
    assert m.locator("[name='variants.1.color']").input_value() == "Negro"
    assert m.locator("[name='variants.1.price']").input_value() == "9,00"
    m.locator("[name='variants.1.qty']").fill("12")
    m.locator("[data-add-row]").click()
    for k, v in [("size", "40"), ("color", "Blanco"), ("cost", "4,50"), ("price", "10,00"), ("qty", "8")]:
        m.locator(f"[name='variants.2.{k}']").fill(v)
    m.get_by_role("button", name="Guardar", exact=True).click()
    wait_toast(pg, "Producto guardado: 3 variantes")
    expect(pg.locator(".modal-backdrop")).to_have_count(0)
    # aparece sin recargar
    expect(pg.locator(".mcard", has_text="Classic")).to_be_visible()
    expect(pg.locator(".mcard", has_text="Classic")).to_contain_text("3 variantes · 30 uds")
    v = variants(pg)
    assert sorted((x["size"], x["color"], x["cost"], x["price"], x["stock"]) for x in v) == [
        ("38", "Negro", 400, 900, 10), ("39", "Negro", 400, 900, 12), ("40", "Blanco", 450, 1000, 8)], v


@case("Guardar y añadir otro + rango de tallas + marca reciente")
def t_add_again(pg, base, **_):
    go(pg, base, "inventario")
    pg.get_by_role("button", name="+ Añadir producto").first.click()
    m = modal(pg)
    expect(m.locator(".chip[data-brand='Marca A']")).to_be_visible()
    m.locator(".chip[data-brand='Marca A']").click()
    assert m.locator("[name=brandName]").input_value() == "Marca A"
    m.locator("[name=modelName]").fill("Slide")
    m.locator("[name='variants.0.cost']").fill("3")
    m.locator("[name='variants.0.price']").fill("7,5")
    m.locator("[data-range]").click()
    m.locator("[name=rFrom]").fill("36")
    m.locator("[name=rTo]").fill("38")
    m.locator("[name=rColor]").fill("Azul")
    m.locator("[data-range-ok]").click()
    assert m.locator(".vbody .vrow").count() == 3
    assert m.locator("[name='variants.2.size']").input_value() == "38"
    assert m.locator("[name='variants.2.price']").input_value() == "7,5"
    m.locator("[data-again]").click()
    wait_toast(pg, "Producto guardado: 3 variantes")
    # se abre un formulario nuevo vacío
    m = modal(pg)
    expect(m.locator("[name=modelName]")).to_have_value("")
    add_product(pg, "Rider", "Strike", [("42", "Gris", "5", "12", "4")])
    wait_toast(pg, "Producto guardado: 1 variante")
    expect(pg.locator(".modal-backdrop")).to_have_count(0)
    expect(pg.locator(".vitem")).to_have_count(7)


@case("Aviso de duplicados y error sin perder los datos introducidos")
def t_duplicates(pg, base, **_):
    go(pg, base, "productos")
    pg.get_by_role("button", name="+ Añadir producto").first.click()
    m = modal(pg)
    m.locator("[name=brandName]").fill("marca a")
    m.locator("[name=modelName]").fill("classic")
    expect(m.locator("[data-hint=model]")).to_contain_text("Ya existe este modelo", timeout=3000)
    m.locator("[name='variants.0.size']").fill("38")
    m.locator("[name='variants.0.color']").fill("negro")
    m.locator("[name='variants.0.cost']").fill("4")
    m.locator("[name='variants.0.price']").fill("9")
    expect(m.locator("[data-issue='0']")).to_contain_text("ya existe en el modelo", timeout=3000)
    m.get_by_role("button", name="Guardar", exact=True).click()
    expect(m.locator(".form-error")).to_contain_text("ya tiene la talla 38")
    assert m.locator("[name='variants.0.price']").input_value() == "9", "los datos no se borran tras un error"
    # corregir a una variante nueva legítima
    m.locator("[name='variants.0.size']").fill("41")
    m.get_by_role("button", name="Guardar", exact=True).click()
    wait_toast(pg, "Tallas añadidas: 1 variante")
    expect(pg.locator(".mcard", has_text="Classic")).to_contain_text("4 variantes")


@case("Validaciones: precio con 3 decimales y campos obligatorios")
def t_validation(pg, base, **_):
    pg.get_by_role("button", name="+ Añadir producto").first.click()
    m = modal(pg)
    m.locator("[name=brandName]").fill("X")
    m.get_by_role("button", name="Guardar", exact=True).click()
    expect(m.locator(".form-error")).to_contain_text("modelo es obligatorio")
    m.locator("[name=modelName]").fill("Y")
    m.locator("[name='variants.0.size']").fill("40")
    m.locator("[name='variants.0.cost']").fill("4,999")
    m.locator("[name='variants.0.price']").fill("9")
    m.get_by_role("button", name="Guardar", exact=True).click()
    expect(m.locator(".form-error")).to_contain_text("máximo de 2 decimales")
    expect(m.locator("[name='variants.0.cost']")).to_have_class(re.compile("invalid"))
    assert m.locator("[name=modelName]").input_value() == "Y"


@case("Cambios sin guardar: pide confirmación al cerrar y con el botón «atrás»")
def t_unsaved(pg, base, **_):
    m = modal(pg)  # sigue abierto el formulario del caso anterior, con datos
    m.locator("[data-close]").first.click()
    c = modal(pg)
    expect(c).to_contain_text("Cambios sin guardar")
    c.get_by_role("button", name="Seguir editando").click()
    expect(pg.locator(".modal-backdrop")).to_have_count(1)
    assert modal(pg).locator("[name=modelName]").input_value() == "Y"
    # botón atrás del móvil
    route_before = pg.evaluate("location.hash")
    pg.go_back()
    expect(modal(pg)).to_contain_text("Cambios sin guardar")
    modal(pg).get_by_role("button", name="Seguir editando").click()
    expect(pg.locator(".modal-backdrop")).to_have_count(1)
    pg.go_back()
    modal(pg).get_by_role("button", name="Salir sin guardar").click()
    expect(pg.locator(".modal-backdrop")).to_have_count(0)
    assert pg.evaluate("location.hash") == route_before, "cerrar el modal no cambia de sección"
    assert not any(v["label"].startswith("X Y") for v in variants(pg)), "no se guardó nada"


@case("Edición rápida de precio en el inventario")
def t_inline_price(pg, base, **_):
    go(pg, base, "inventario")
    row = pg.locator(".vitem", has_text="Strike")
    row.locator("[data-edit=price]").click()
    inp = row.locator(".inline-editor input")
    inp.fill("12,50")
    inp.press("Enter")
    wait_toast(pg, "Precio de venta: 12,00 € → 12,50 €")
    expect(pg.locator(".vitem", has_text="Strike").locator("[data-edit=price]")).to_have_text(re.compile(r"12,50"))
    # Escape cancela
    pg.locator(".vitem", has_text="Strike").locator("[data-edit=cost]").click()
    pg.locator(".inline-editor input").fill("99")
    pg.locator(".inline-editor input").press("Escape")
    v = [x for x in variants(pg) if "Strike" in x["label"]][0]
    assert v["cost"] == 500 and v["price"] == 1250, v


@case("Cambio masivo de precios con filtros, vista previa, cancelación y confirmación")
def t_bulk(pg, base, **_):
    go(pg, base, "inventario")
    pg.locator(".filters [name=color]").select_option(label="Negro")
    expect(pg.locator(".vitem")).to_have_count(3)
    pg.locator("[name=selall]").check()
    expect(pg.locator("[data-bulk]")).to_have_text("Cambiar precios (3)")
    pg.locator("[data-bulk]").click()
    m = modal(pg)
    m.locator("[name=value]").fill("10")
    m.get_by_role("button", name="Ver vista previa").click()
    expect(m.locator(".preview tbody tr")).to_have_count(3)
    expect(m.locator(".preview")).to_contain_text("9,90")
    # cancelar no cambia nada
    m.get_by_role("button", name="Cancelar sin cambiar nada").click()
    if pg.locator(".modal-backdrop").count() > 1 or "Cambios sin guardar" in modal(pg).inner_text():
        modal(pg).get_by_role("button", name="Salir sin guardar").click()
    expect(pg.locator(".modal-backdrop")).to_have_count(0)
    assert all(v["price"] == 900 for v in variants(pg) if "Classic" in v["label"] and v["color"] == "Negro")
    # ahora sí
    pg.locator("[data-bulk]").click()
    m = modal(pg)
    m.locator("[name=value]").fill("10")
    m.get_by_role("button", name="Ver vista previa").click()
    m.locator("[data-apply]").click()
    wait_toast(pg, "3 precios actualizados")
    got = sorted(v["price"] for v in variants(pg) if v["color"] == "Negro")
    assert got == [990, 990, 990], got
    pg.locator(".filters [name=color]").select_option("")
    pg.locator("[name=selall]").uncheck()


@case("Venta rápida con varios productos, descuento y protección contra doble clic")
def t_sale(pg, base, **_):
    go(pg, base, "ventas")
    pg.get_by_role("button", name="+ Nueva venta").click()
    m = modal(pg)
    m.locator("[name=q]").fill("classic 38")
    m.locator(".pick").first.click()
    m.locator("[name=q]").fill("strike")
    m.locator(".pick").first.click()
    m.locator("[name=q]").fill("classic 38")
    m.locator(".pick").first.click()  # vuelve a sumar a la misma línea
    expect(m.locator(".line")).to_have_count(2)
    assert m.locator(".line").first.locator("[data-k=qty]").input_value() == "2"
    m.locator("[name=discount]").fill("1")
    # 2 × 9,90 + 12,50 − 1,00 = 31,30
    expect(m.locator("[data-total]")).to_have_text(re.compile(r"31,30"))
    m.locator("[name=payment]").select_option("Bizum")
    btn = m.get_by_role("button", name="Guardar venta")
    btn.dblclick()
    wait_toast(pg, "guardada · 31,30")
    expect(pg.locator(".modal-backdrop")).to_have_count(0)
    sales = app_eval(pg, "return (await app.store.listSales()).map(s => ({id: s.id, total: s.total}));")
    assert len(sales) == 1 and sales[0]["total"] == 3130, sales
    v = {x["label"]: x for x in variants(pg)}
    assert v["Marca A Classic · T38 · Negro"]["stock"] == 8
    assert v["Rider Strike · T42 · Gris"]["stock"] == 3
    expect(pg.locator(".row-card").first).to_contain_text("31,30")


@case("Stock insuficiente: la venta se rechaza con un mensaje claro")
def t_sale_stock(pg, base, **_):
    pg.get_by_role("button", name="+ Nueva venta").click()
    m = modal(pg)
    m.locator("[name=q]").fill("strike")
    m.locator(".pick").first.click()
    m.locator("[data-k=qty]").fill("5")
    m.locator("[data-k=qty]").dispatch_event("change")
    expect(m.locator(".line")).to_contain_text("Supera las existencias")
    m.get_by_role("button", name="Guardar venta").click()
    expect(m.locator(".form-error")).to_contain_text("Stock insuficiente de Rider Strike · T42 · Gris: hay 3 y pides 5")
    m.locator("[data-close]").first.click()
    modal(pg).get_by_role("button", name="Salir sin guardar").click()
    expect(pg.locator(".modal-backdrop")).to_have_count(0)


@case("Cambiar el precio no altera la venta anterior (detalle y estadísticas)")
def t_history_safe(pg, base, **_):
    before = app_eval(pg, "const t = app.store.today(); return await app.store.stats({from: t, to: t});")
    vid = [x for x in variants(pg) if x["label"] == "Marca A Classic · T38 · Negro"][0]["id"]
    app_eval(pg, f"await app.store.setPrice({vid}, 'price', '15,00');")
    after = app_eval(pg, "const t = app.store.today(); return await app.store.stats({from: t, to: t});")
    assert before["netRevenue"] == after["netRevenue"] == 3130
    assert before["grossProfit"] == after["grossProfit"]
    go(pg, base, "ventas")
    pg.locator(".row-card").first.click()
    m = modal(pg)
    expect(m).to_contain_text("9,90")
    expect(m.locator(".grand")).to_contain_text("31,30")
    m.locator("[data-close]").first.click()


@case("Compra pendiente → recepción de mercancía → stock y coste medio")
def t_purchase(pg, base, **_):
    go(pg, base, "compras")
    pg.get_by_role("button", name="+ Nueva compra").click()
    m = modal(pg)
    m.locator("[name=supplier]").fill("Proveedor Norte")
    m.locator("[name=status]").select_option("pending")
    m.locator("[name=q]").fill("strike")
    m.locator(".pick").first.click()
    m.locator("[data-k=qty]").fill("10")
    m.locator("[data-k=cost]").fill("6")
    expect(m.locator(".totals")).to_contain_text("60,00")
    m.get_by_role("button", name="Guardar compra").click()
    wait_toast(pg, "pendiente de recibir")
    v = [x for x in variants(pg) if "Strike" in x["label"]][0]
    assert v["stock"] == 3, "pendiente no suma stock"
    expect(pg.locator(".row-card")).to_have_count(1)
    pg.get_by_role("button", name="Recibir").click()
    modal(pg).get_by_role("button", name="Recibir").click()
    wait_toast(pg, "recibida: +10 uds")
    v = [x for x in variants(pg) if "Strike" in x["label"]][0]
    assert v["stock"] == 13, v
    assert v["avgCost"] == round((3 * 500 + 10 * 600) / 13), v
    assert v["cost"] == 600


@case("Compra con producto nuevo creado sin salir del formulario")
def t_purchase_newprod(pg, base, **_):
    pg.get_by_role("button", name="+ Nueva compra").click()
    m = modal(pg)
    m.locator("[data-newprod]").click()
    p = modal(pg)
    p.locator("[name=brandName]").fill("Ipanema")
    p.locator("[name=modelName]").fill("Bossa")
    p.locator("[name='variants.0.size']").fill("37")
    p.locator("[name='variants.0.color']").fill("Rosa")
    p.locator("[name='variants.0.cost']").fill("6")
    p.locator("[name='variants.0.price']").fill("15")
    assert p.locator("[data-k=qty]").count() == 0, "en compras la cantidad se pone en la línea"
    p.get_by_role("button", name="Guardar", exact=True).click()
    wait_toast(pg, "Producto guardado")
    m = modal(pg)
    expect(m.locator(".line")).to_contain_text("Ipanema Bossa")
    m.locator("[data-k=qty]").fill("6")
    m.get_by_role("button", name="Guardar compra").click()
    wait_toast(pg, "Compra #")
    v = [x for x in variants(pg) if "Bossa" in x["label"]][0]
    assert v["stock"] == 6 and v["avgCost"] == 600, v


@case("Devolución parcial que vuelve al stock")
def t_return(pg, base, **_):
    go(pg, base, "ventas")
    pg.locator(".row-card").first.click()
    m = modal(pg)
    m.get_by_role("button", name="Registrar devolución").click()
    r = modal(pg)
    r.locator("[name=q0]").fill("1")
    expect(r.locator("[data-refund]")).to_have_text(re.compile(r"9,\d\d"))
    r.locator("[name=reason]").fill("Talla pequeña")
    r.get_by_role("button", name="Confirmar devolución").click()
    wait_toast(pg, "Devolución registrada")
    m = modal(pg)
    expect(m).to_contain_text("Devoluciones")
    expect(m).to_contain_text("Devolución parcial")
    m.locator("[data-close]").first.click()
    v = {x["label"]: x for x in variants(pg)}
    assert v["Marca A Classic · T38 · Negro"]["stock"] == 9


@case("Gasto y estadísticas coherentes con cálculo de referencia")
def t_stats(pg, base, **_):
    go(pg, base, "gastos")
    pg.get_by_role("button", name="+ Añadir gasto").click()
    m = modal(pg)
    m.locator("[name=amount]").fill("5,25")
    m.locator("[name=category]").fill("Transporte")
    m.get_by_role("button", name="Guardar gasto").click()
    wait_toast(pg, "Gasto guardado")
    data = app_eval(pg, """
      const sales = await app.store.listSales(); const rets = await app.store.listReturns(); const ex = await app.store.listExpenses();
      return {sales, rets, ex};""")
    # referencia independiente
    revenue = sum(s["total"] for s in data["sales"]) - sum(r["refund"] for r in data["rets"])
    cogs = sum(l["qty"] * l["unitCost"] for s in data["sales"] for l in s["lines"]) - sum(l["qty"] * l["unitCost"] for r in data["rets"] for l in r["lines"] if l["restock"])
    expenses = sum(e["amount"] for e in data["ex"])
    go(pg, base, "estadisticas")
    pg.locator("[data-period=today]").click()
    pg.wait_for_timeout(300)
    def eur(c):
        s = f"{abs(c) // 100:,}".replace(",", ".") + "," + f"{abs(c) % 100:02d}"
        return ("-" if c < 0 else "") + s
    expect(pg.locator("[data-kpi=revenue]")).to_contain_text(eur(revenue))
    expect(pg.locator("[data-kpi=gross]")).to_contain_text(eur(revenue - cogs))
    expect(pg.locator("[data-kpi=net]")).to_contain_text(eur(revenue - cogs - expenses))
    expect(pg.locator(".chart svg")).to_be_visible()
    go(pg, base, "dashboard")
    expect(pg.locator("[data-kpi=today-revenue]")).to_contain_text(eur(revenue))


@case("Búsqueda y filtros en ventas, inventario e historial")
def t_search(pg, base, **_):
    go(pg, base, "inventario")
    pg.locator("[name=q]").fill("rosa")
    pg.wait_for_timeout(400)
    expect(pg.locator(".vitem")).to_have_count(1)
    expect(pg.locator("[name=q]")).to_be_focused()
    pg.locator("[name=q]").fill("")
    pg.wait_for_timeout(400)
    go(pg, base, "ventas")
    pg.locator("[name=q]").fill("strike")
    pg.wait_for_timeout(400)
    expect(pg.locator(".row-card")).to_have_count(1)
    pg.locator("[name=q]").fill("ipanema")
    pg.wait_for_timeout(400)
    expect(pg.locator(".row-card")).to_have_count(0)
    pg.locator("[name=q]").fill("")
    go(pg, base, "historial")
    pg.get_by_role("tab", name="Precios").click()
    expect(pg.locator("#view")).to_contain_text("Cambio masivo")
    pg.get_by_role("tab", name="Operaciones").click()
    expect(pg.locator("#view")).to_contain_text("Devolución #1")


@case("Navegación por gestos laterales (y bloqueo sobre campos y modales)")
def t_gestures(pg, base, cdp, **_):
    go(pg, base, "ventas")
    vw = pg.viewport_size["width"]
    y = 420
    swipe(pg, cdp, vw * 0.8, y, vw * 0.15, y + 8)
    expect(pg.locator("#view")).to_have_attribute("data-route", "compras")
    swipe(pg, cdp, vw * 0.2, y, vw * 0.85, y - 5)
    expect(pg.locator("#view")).to_have_attribute("data-route", "ventas")
    # gesto mayormente vertical: no navega
    swipe(pg, cdp, vw * 0.7, 300, vw * 0.4, 520)
    expect(pg.locator("#view")).to_have_attribute("data-route", "ventas")
    # sobre un campo de texto: no navega
    box = pg.locator("[name=q]").bounding_box()
    swipe(pg, cdp, box["x"] + box["width"] - 20, box["y"] + 10, box["x"] + 10, box["y"] + 12)
    expect(pg.locator("#view")).to_have_attribute("data-route", "ventas")
    # con un modal abierto: no navega
    pg.get_by_role("button", name="+ Nueva venta").click()
    swipe(pg, cdp, vw * 0.8, 600, vw * 0.15, 600)
    expect(pg.locator("#view")).to_have_attribute("data-route", "ventas")
    modal(pg).locator("[data-close]").first.click()
    expect(pg.locator(".modal-backdrop")).to_have_count(0)
    # barra inferior y menú «Más»
    pg.locator("#bottomnav [data-route=inventario]").click()
    expect(pg.locator("#view")).to_have_attribute("data-route", "inventario")
    pg.locator("#bottomnav [data-more]").click()
    modal(pg).get_by_role("link", name=re.compile("Proveedores")).click()
    expect(pg.locator("#view")).to_have_attribute("data-route", "proveedores")
    expect(pg.locator(".modal-backdrop")).to_have_count(0)
    expect(pg.locator(".row-card")).to_have_count(1)  # proveedor creado al vuelo en la compra


@case("Exportaciones CSV y copia de seguridad descargable")
def t_exports(pg, base, **_):
    go(pg, base, "informes")
    with pg.expect_download() as d:
        pg.locator("[data-export=ventas]").click()
    path = d.value.path()
    text = open(path, encoding="utf-8-sig").read()
    assert text.startswith("Venta;Fecha;Pago"), text[:80]
    assert "Rider Strike" in text and "Bizum" in text
    with pg.expect_download() as d:
        pg.locator("[data-export=inventario]").click()
    inv = open(d.value.path(), encoding="utf-8-sig", newline="").read().strip().split("\r\n")
    assert len(inv) == 1 + len(variants(pg)), (len(inv), len(variants(pg)), inv[:3])
    with pg.expect_download() as d:
        pg.locator("[data-backup]").click()
    backup_path = d.value.path()
    data = json.load(open(backup_path))
    assert data["app"] == "ChinelaStock" and len(data["data"]["sales"]) == 1
    SHARED["backup"] = backup_path  # para el siguiente caso


@case("Restaurar copia de seguridad (sustituye datos tras confirmar)")
def t_restore(pg, base, **_):
    app_eval(pg, "await app.store.addExpense({date: app.store.today(), category: 'Prueba', amount: '1'});")
    n_before = app_eval(pg, "return (await app.store.listExpenses()).length;")
    go(pg, base, "informes")
    pg.locator("[name=restore]").set_input_files(SHARED["backup"])
    m = modal(pg)
    expect(m).to_contain_text("SUSTITUIRÁ")
    m.get_by_role("button", name="Sustituir mis datos").click()
    wait_toast(pg, "Copia restaurada")
    n_after = app_eval(pg, "return (await app.store.listExpenses()).length;")
    assert n_after == n_before - 1, (n_before, n_after)
    # archivo no válido
    bad = os.path.join(os.path.dirname(SHARED["backup"]), "malo.json")
    open(bad, "w").write('{"app":"otra"}')
    pg.locator("[name=restore]").set_input_files(bad)
    wait_toast(pg, "no es una copia de seguridad")
    expect(pg.locator(".modal-backdrop")).to_have_count(0)


@case("Modo oscuro persistente y datos intactos tras cerrar y volver a abrir")
def t_persist(pg, base, **_):
    go(pg, base, "config")
    pg.locator(".seg-opt", has_text="Oscuro").click()
    pg.get_by_role("button", name="Guardar configuración").click()
    wait_toast(pg, "Configuración guardada")
    before = variants(pg)
    pg.reload()
    pg.wait_for_selector("body.ready")
    assert pg.evaluate("document.documentElement.dataset.theme") == "dark"
    bg = pg.evaluate("getComputedStyle(document.body).backgroundColor")
    assert bg == "rgb(20, 23, 28)", bg
    after = variants(pg)
    assert before == after
    assert app_eval(pg, "return (await app.store.listSales()).length;") == 1


@case("Funciona sin conexión tras la primera visita (service worker)")
def t_offline(pg, base, ctx, **_):
    pg.evaluate("navigator.serviceWorker.ready.then(() => true)")
    pg.reload()  # la página queda controlada por el service worker
    pg.wait_for_selector("body.ready")
    pg.wait_for_function("!!navigator.serviceWorker.controller", timeout=8000)
    ctx.set_offline(True)
    try:
        pg.reload()
        pg.wait_for_selector("body.ready", timeout=8000)
        go(pg, base, "inventario")
        expect(pg.locator(".vitem").first).to_be_visible()
        # una venta sin conexión
        pg.locator("#bottomnav [data-route=ventas]").click()
        pg.get_by_role("button", name="+ Nueva venta").click()
        m = modal(pg)
        m.locator("[name=q]").fill("bossa")
        m.locator(".pick").first.click()
        m.get_by_role("button", name="Guardar venta").click()
        wait_toast(pg, "guardada")
    finally:
        ctx.set_offline(False)


@case("Escritorio: menú lateral visible y barra inferior oculta")
def t_desktop(pg, base, browser, **_):
    c2 = browser.new_context(viewport={"width": 1280, "height": 800})
    p2 = c2.new_page()
    p2.goto(base + "/#/inventario")
    p2.wait_for_selector("body.ready")
    expect(p2.locator("#sidenav")).to_be_visible()
    expect(p2.locator("#bottomnav")).to_be_hidden()
    p2.locator("#sidenav [data-route=estadisticas]").click()
    expect(p2.locator("#view")).to_have_attribute("data-route", "estadisticas")
    p2.keyboard.press("Alt+ArrowRight")
    expect(p2.locator("#view")).to_have_attribute("data-route", "gastos")
    p2.screenshot(path=os.path.join(ROOT, "tests", "screens", "desktop-gastos.png"))
    c2.close()


def main():
    httpd, base = serve()
    os.makedirs(os.path.join(ROOT, "tests", "screens"), exist_ok=True)
    cases = [g for g in globals().values() if callable(g) and hasattr(g, "case_name")]
    failed = 0
    with sync_playwright() as p:
        browser = p.chromium.launch()
        ctx = browser.new_context(**p.devices["Pixel 7"], accept_downloads=True)
        pg = ctx.new_page()
        errors = []
        pg.on("pageerror", lambda e: errors.append(str(e)))
        pg.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
        pg.on("dialog", lambda d: d.dismiss())
        pg.goto(base + "/")
        pg.wait_for_selector("body.ready")
        cdp = ctx.new_cdp_session(pg)
        for fn in cases:
            t0 = time.time()
            try:
                fn(pg, base, cdp=cdp, ctx=ctx, browser=browser)
                status = "OK"
            except Exception as e:  # noqa: BLE001
                failed += 1
                status = "FALLO"
                traceback.print_exc()
                pg.screenshot(path=os.path.join(ROOT, "tests", "screens", f"fallo-{fn.__name__}.png"))
                # dejar la página limpia para el siguiente caso
                for _ in range(4):
                    if pg.locator(".modal-backdrop").count() == 0:
                        break
                    pg.keyboard.press("Escape")
                    pg.wait_for_timeout(200)
                    if pg.locator("[data-yes]").count():
                        pg.locator("[data-yes]").last.click()
            RESULTS.append((status, fn.case_name, time.time() - t0))
            print(f"[{status}] {fn.case_name} ({time.time() - t0:.1f}s)", flush=True)
        for name in ["dashboard", "inventario", "productos", "estadisticas"]:
            pg.evaluate(f"location.hash = '#/{name}'")
            pg.wait_for_timeout(400)
            pg.screenshot(path=os.path.join(ROOT, "tests", "screens", f"movil-{name}.png"), full_page=False)
        browser.close()
    httpd.shutdown()
    js_errors = [e for e in errors if "Failed to load resource" not in e]
    print(f"\n{len(RESULTS) - failed}/{len(RESULTS)} casos superados")
    if js_errors:
        print("Errores de JavaScript en consola:\n  " + "\n  ".join(js_errors))
    sys.exit(1 if failed or js_errors else 0)


if __name__ == "__main__":
    main()
