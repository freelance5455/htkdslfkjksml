import { test } from 'node:test';
import assert from 'node:assert/strict';
import { parseMoney, parseQty, parsePercent, applyPercent, allocate, roundToStep, centsToInput, ValidationError } from '../js/core/money.js';

test('parseMoney: formatos admitidos', () => {
  assert.equal(parseMoney('9'), 900);
  assert.equal(parseMoney('9,5'), 950);
  assert.equal(parseMoney('9,50'), 950);
  assert.equal(parseMoney('9.50'), 950);
  assert.equal(parseMoney('1.234,56'), 123456);
  assert.equal(parseMoney(' 12 € '), 1200);
  assert.equal(parseMoney('0'), 0);
  assert.equal(parseMoney('0,1'), 10);
});

test('parseMoney: rechaza valores no válidos', () => {
  for (const bad of ['', 'abc', '-3', '9,999', '1,2,3', '9..5', 'NaN']) {
    assert.throws(() => parseMoney(bad), ValidationError, bad);
  }
  assert.equal(parseMoney('', { allowEmpty: true }), null);
});

test('sin errores de coma flotante: 0,1 + 0,2', () => {
  assert.equal(parseMoney('0,10') + parseMoney('0,20'), parseMoney('0,30'));
  // 19,99 * 3 calculado en céntimos
  assert.equal(parseMoney('19,99') * 3, 5997);
});

test('parseQty y parsePercent', () => {
  assert.equal(parseQty('12'), 12);
  assert.equal(parseQty(''), 0);
  assert.throws(() => parseQty('1,5'), ValidationError);
  assert.throws(() => parseQty('0', { min: 1 }), ValidationError);
  assert.equal(parsePercent('10'), 1000);
  assert.equal(parsePercent('7,5'), 750);
  assert.equal(parsePercent('-5'), -500);
  assert.throws(() => parsePercent('diez'), ValidationError);
});

test('porcentajes y redondeo exactos', () => {
  assert.equal(applyPercent(900, 1000), 990); // 9,00 +10 % = 9,90
  assert.equal(applyPercent(999, 1000), 1099); // 10,989 -> 10,99
  assert.equal(applyPercent(1000, -1500), 850);
  assert.equal(applyPercent(105, 5000), 158); // 1,575 -> 1,58 (mitad hacia arriba)
  assert.equal(roundToStep(1093, 10), 1090);
  assert.equal(roundToStep(1095, 10), 1100);
  assert.equal(roundToStep(1093, 50), 1100);
});

test('allocate reparte sin perder céntimos', () => {
  const parts = allocate(100, [300, 300, 300]);
  assert.equal(parts.reduce((a, b) => a + b, 0), 100);
  assert.deepEqual(parts, [33, 34, 33]);
  for (let t = 0; t < 500; t += 7) {
    const w = [123, 456, 789, 1];
    assert.equal(allocate(t, w).reduce((a, b) => a + b, 0), t);
  }
});

test('centsToInput', () => {
  assert.equal(centsToInput(950), '9,50');
  assert.equal(centsToInput(5), '0,05');
  assert.equal(centsToInput(-120), '-1,20');
});
