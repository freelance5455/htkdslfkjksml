# ChinelaStock

Aplicación para gestionar un negocio de chinelas: productos con tallas y colores, precios, inventario, compras, ventas, devoluciones, gastos, estadísticas, exportaciones y copias de seguridad.

**Funciona en el móvil y sin conexión.** Es una aplicación web instalable (PWA): se instala una vez desde el navegador y después se abre desde la pantalla de inicio como cualquier app, con o sin internet.

---

## 1. Instalarla en el móvil (una sola vez)

El navegador solo permite instalar y usar sin conexión una app que se haya abierto al menos una vez desde una dirección **https**. Por eso hay que publicar la carpeta en un alojamiento gratuito. Tus datos **no** se suben a ningún sitio: se guardan solo en el móvil.

### Opción A — Netlify Drop (la más fácil, sin programar)
1. En un ordenador, entra en <https://app.netlify.com/drop> y crea una cuenta gratuita.
2. Arrastra la carpeta `chinelastock` (la que contiene `index.html`) a la página.
3. Netlify te da una dirección del tipo `https://nombre-aleatorio.netlify.app`. Puedes cambiar el nombre en *Site configuration*.

### Opción B — GitHub Pages
1. Crea un repositorio en GitHub y sube el contenido de la carpeta.
2. *Settings → Pages → Deploy from a branch → main / (root)*.
3. La dirección será `https://TU-USUARIO.github.io/NOMBRE-REPO/`.

### Después, en el móvil
1. Abre la dirección en **Chrome** (Android) o **Safari** (iPhone).
2. Android: menú ⋮ → **Instalar aplicación** / *Añadir a pantalla de inicio*.
   iPhone: botón Compartir → **Añadir a pantalla de inicio**.
3. Abre ChinelaStock desde el icono. A partir de aquí funciona sin internet.

> Usa siempre la app instalada en el mismo navegador. Los datos de Chrome no se ven desde Safari ni desde otro móvil.

---

## 2. Proteger tus datos (importante)

- Los datos viven en la base de datos del navegador del móvil (IndexedDB). Si borras los datos de navegación o desinstalas el navegador, **se pierden**.
- La app pide al navegador «almacenamiento persistente» para que no los borre por falta de espacio. Puedes ver si está activado en **Informes y copias**.
- **Haz copias de seguridad**: *Informes y copias → Descargar copia (.json)* y guárdala fuera del móvil (correo, Drive, ordenador). El inicio te avisa si llevas más de 7 días sin copia.
- Para pasar los datos a otro móvil: descarga la copia en el antiguo y usa *Restaurar copia* en el nuevo (sustituye todo, previa confirmación).

---

## 3. Uso rápido

| Quiero… | Dónde |
|---|---|
| Dar de alta un modelo con todas sus tallas | **Productos** o **Inventario → + Añadir producto**. Usa *+ Talla* (copia color y precios y sugiere la siguiente talla) o *Rango de tallas* (p. ej. 35 a 44). Si la marca no existe, se crea desde el mismo formulario. |
| Un modelo parecido a otro | Abre el modelo → **Duplicar** (copia descripción, tallas y precios; no copia existencias ni historial). |
| Cambiar un precio | Toca el precio en **Inventario** o en la ficha del modelo, escribe y pulsa ✓ o Intro. |
| Cambiar muchos precios | **Inventario** → filtra → marca → **Cambiar precios** → porcentaje, importe fijo o precio nuevo → **Ver vista previa** → **Confirmar**. |
| Vender | **+ Venta**: busca por modelo, marca, referencia, talla o color, ajusta cantidades, descuento y forma de pago. |
| Registrar mercancía | **Compras → + Nueva compra**. «Pendiente de recibir» no suma stock hasta que pulses **Recibir**. |
| Devolución | Abre la venta → **Registrar devolución**. Desmarca «Vuelve al stock» si el producto está dañado. |
| Corregir el stock contado | Toca las unidades de una talla en **Inventario** → indica el motivo. |
| Moverte entre secciones | Menú inferior / lateral, flechas ‹ › de la cabecera o **deslizando el dedo** a izquierda y derecha. |

---

## 4. Cómo calcula

- **Dinero en céntimos enteros**: no hay errores de redondeo de coma flotante. Los porcentajes se redondean al céntimo más cercano.
- **Coste medio ponderado**: cada compra recibida recalcula el coste medio de esa talla/color.
- **Ventas históricas protegidas**: cada línea de venta guarda su precio y su coste del momento. Cambiar precios después no altera ingresos ni beneficios pasados.
- **Descuentos** repartidos entre las líneas al céntimo; los reembolsos parciales suman exactamente el importe cobrado.
- **Beneficio bruto** = ingresos − devoluciones − coste de lo vendido (las devoluciones que vuelven al stock recuperan su coste; las dañadas cuentan como pérdida). **Beneficio neto** = bruto − gastos.

### Seguridad de los datos
- Cada operación es **una transacción**: o se guarda completa o no se guarda nada.
- Restricciones en la base de datos: marca única, modelo único por marca, referencia (SKU) única, talla+color única por modelo, clave anti-duplicado por operación.
- Comprobación de existencias dentro de la misma transacción que descuenta el stock: dos ventas simultáneas no pueden vender la misma unidad.
- Pulsar «Guardar» dos veces no registra dos operaciones.

---

## 5. Desarrollo y pruebas

Estructura:
```
index.html, manifest.webmanifest, sw.js   app instalable y caché sin conexión
css/app.css                               estilos (claro/oscuro, móvil y escritorio)
js/core/money.js     importes en céntimos, validación numérica
js/core/db.js        esquema IndexedDB, índices únicos, transacciones
js/core/store.js     lógica de negocio (productos, precios, compras, ventas, devoluciones, gastos, estadísticas, copias)
js/core/exports.js   exportaciones CSV
js/ui/*.js           pantallas, formularios y gestos
tests/               pruebas automáticas
```

Probar en el ordenador:
```bash
npm install                 # instala fake-indexeddb (solo para pruebas)
npm test                    # 36 pruebas de lógica (Node 20+)
pip install playwright && python3 -m playwright install chromium
python3 tests/e2e.py        # 21 pruebas en Chromium móvil/escritorio
python3 -m http.server 8080 # abrir http://localhost:8080
```

**Al publicar una versión nueva**, cambia el número de `CACHE` en `sw.js` (p. ej. `chinelastock-v1.0.1`) para que los móviles descarguen los archivos nuevos. Los datos no se ven afectados.

---

## 6. Limitaciones conocidas

- **Un solo dispositivo**: no hay sincronización entre móviles. Varias pestañas del mismo navegador sí se mantienen coherentes.
- Valoración del inventario: solo **coste medio ponderado** (no FIFO).
- La autorización para cambiar el precio en una venta es un ajuste (sí/no), no un sistema de usuarios con contraseña.
- Monedas con 2 decimales (EUR, USD, MXN…). Monedas sin decimales (CLP, PYG) se muestran con ,00.
- Sin impresión de tickets ni facturas.
- Las fotos se reducen a 480 px y se guardan dentro de la base de datos; muchas fotos aumentan el tamaño de las copias de seguridad.
- Probado automáticamente en Chromium (emulación de Pixel 7 y escritorio). En Safari/iPhone no se ha podido probar desde este entorno.
