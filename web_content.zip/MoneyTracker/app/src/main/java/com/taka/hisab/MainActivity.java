package com.taka.hisab;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/**
 * Loads the bundled app/src/main/assets/index.html inside a WebView.
 * Everything is served locally through WebViewAssetLoader; the app has no INTERNET permission.
 *
 * IMPORTANT: keep HOST and START_URL unchanged in future updates. localStorage is stored per
 * origin, so changing the origin would make the old data look "missing".
 */
public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + HOST + "/assets/index.html";
    private static final String MIRROR_FILE = "data.json";
    private static final int REQ_SAVE = 1001;
    private static final int REQ_PICK = 1002;

    private WebView web;
    private WebViewAssetLoader loader;
    private ValueCallback<Uri[]> filePathCallback;

    private String pendingText;
    private String pendingName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if ((getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            WebView.setWebContentsDebuggingEnabled(true);
        }

        loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) {
                    return loader.shouldInterceptRequest(u);
                }
                String scheme = u.getScheme();
                if ("data".equals(scheme) || "blob".equals(scheme)) {
                    return null;
                }
                // Anything that is not bundled content is blocked.
                return new WebResourceResponse("text/plain", "utf-8", 403, "Blocked",
                        null, new java.io.ByteArrayInputStream(new byte[0]));
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !HOST.equals(request.getUrl().getHost());
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*"); // JSON backups are often labelled text/plain or octet-stream
                try {
                    startActivityForResult(Intent.createChooser(i, "ব্যাকআপ ফাইল বাছুন"), REQ_PICK);
                } catch (ActivityNotFoundException e) {
                    filePathCallback = null;
                    callback.onReceiveValue(null);
                    return false;
                }
                return true;
            }
        });

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl(START_URL);
        }
    }

    /** Functions callable from the page as window.AndroidBridge.* */
    private class Bridge {

        /** Opens the system "save as" screen (Downloads, Drive, SD card ...). */
        @JavascriptInterface
        public void saveFile(final String name, final String mime, final String text) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    pendingName = name;
                    pendingText = text;
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType(mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
                    i.putExtra(Intent.EXTRA_TITLE, name);
                    try {
                        startActivityForResult(i, REQ_SAVE);
                    } catch (ActivityNotFoundException e) {
                        pendingText = null;
                        toast("ফাইল সেভ করার অ্যাপ পাওয়া যায়নি");
                    }
                }
            });
        }

        /** Second local copy of the data in the app's private files folder. */
        @JavascriptInterface
        public void persist(String json) {
            try {
                File tmp = new File(getFilesDir(), MIRROR_FILE + ".tmp");
                FileOutputStream out = new FileOutputStream(tmp);
                try {
                    out.write(json.getBytes(StandardCharsets.UTF_8));
                    out.getFD().sync();
                } finally {
                    out.close();
                }
                File dst = new File(getFilesDir(), MIRROR_FILE);
                if (!tmp.renameTo(dst)) {
                    // Fallback for file systems that refuse to overwrite on rename.
                    //noinspection ResultOfMethodCallIgnored
                    dst.delete();
                    //noinspection ResultOfMethodCallIgnored
                    tmp.renameTo(dst);
                }
            } catch (Exception ignored) {
                // localStorage still holds the data; the mirror is only a safety net.
            }
        }

        @JavascriptInterface
        public String load() {
            File f = new File(getFilesDir(), MIRROR_FILE);
            if (!f.exists()) return "";
            try {
                InputStream in = new FileInputStream(f);
                try {
                    ByteArrayOutputStream bo = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                    return bo.toString("UTF-8");
                } finally {
                    in.close();
                }
            } catch (Exception e) {
                return "";
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_PICK) {
            if (filePathCallback != null) {
                Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                filePathCallback.onReceiveValue(result);
                filePathCallback = null;
            }
            return;
        }

        if (requestCode == REQ_SAVE) {
            String text = pendingText;
            pendingText = null;
            if (resultCode != RESULT_OK || data == null || data.getData() == null || text == null) {
                return; // user cancelled
            }
            try {
                OutputStream out = getContentResolver().openOutputStream(data.getData(), "wt");
                if (out == null) throw new IllegalStateException("no stream");
                try {
                    out.write(text.getBytes(StandardCharsets.UTF_8));
                    out.flush();
                } finally {
                    out.close();
                }
                toast("✔ ফাইল সেভ হয়েছে");
            } catch (Exception e) {
                toast("ফাইল সেভ করা যায়নি");
            }
        }
    }

    @Override
    public void onBackPressed() {
        // Let the page handle Back first (e.g. leave a tab); exit only from the home screen.
        web.evaluateJavascript(
                "(function(){return window.__back?window.__back():false})()",
                new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String value) {
                        if (!"true".equals(value)) finish();
                    }
                });
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    protected void onPause() {
        web.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.destroy();
        }
        super.onDestroy();
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
