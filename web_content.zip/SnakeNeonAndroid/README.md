# Snake Neon Android

Android Studio project wrapping the offline Snake Neon game in a native Android WebView. No network permission is requested; game runs locally and saves its best score in WebView local storage.


## Build APK
1. Install Android Studio.
2. Open this folder (`SnakeNeonAndroid`) as a project.
3. Allow Gradle sync to finish (internet may be needed to download Android Gradle Plugin).
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio reports the APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer the APK to your Android phone and open it. If prompted, allow installation from that source.

App ID: `com.example.snakeneon` · Version 1.0 · Portrait · Offline.
