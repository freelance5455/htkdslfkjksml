package com.example.codexremotestarter

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var web: WebView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            setBackgroundColor(Color.rgb(11,16,32))
            addJavascriptInterface(TermuxBridge(), "AndroidBridge")
            loadUrl("file:///android_asset/web/index.html")
        }
        setContentView(web)
    }

    inner class TermuxBridge {
        @android.webkit.JavascriptInterface
        fun startCodex() {
            runOnUiThread {
                try {
                    val intent = Intent("com.termux.RUN_COMMAND").apply {
                        setClassName("com.termux", "com.termux.app.RunCommandService")
                        putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash")
                        putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-lc", "proot-distro login ubuntu -- bash -lc 'export PATH=/opt/node-v22.22.1-linux-arm64/bin:\$PATH; codex remote-control start'"))
                        putExtra("com.termux.RUN_COMMAND_WORKDIR", "/data/data/com.termux/files/home")
                        putExtra("com.termux.RUN_COMMAND_BACKGROUND", true)
                    }
                    startService(intent)
                    web.evaluateJavascript("window.onNativeLog('Termux\'a başlatma isteği gönderildi.');", null)
                } catch (e: Exception) {
                    web.evaluateJavascript("window.onNativeError(${org.json.JSONObject.quote(e.message ?: e.toString())});", null)
                }
            }
        }

        @android.webkit.JavascriptInterface
        fun stopCodex() {
            try {
                val intent = Intent("com.termux.RUN_COMMAND").apply {
                    setClassName("com.termux", "com.termux.app.RunCommandService")
                    putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash")
                    putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-lc", "proot-distro login ubuntu -- bash -lc 'export PATH=/opt/node-v22.22.1-linux-arm64/bin:\$PATH; codex remote-control stop'"))
                    putExtra("com.termux.RUN_COMMAND_WORKDIR", "/data/data/com.termux/files/home")
                    putExtra("com.termux.RUN_COMMAND_BACKGROUND", true)
                }
                startService(intent)
                web.evaluateJavascript("window.onNativeLog('Durdurma isteği gönderildi.');", null)
            } catch (e: Exception) {
                web.evaluateJavascript("window.onNativeError(${org.json.JSONObject.quote(e.message ?: e.toString())});", null)
            }
        }
    }
}
