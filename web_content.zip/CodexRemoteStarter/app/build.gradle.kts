plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.codexremotestarter"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.codexremotestarter"
        minSdk = 27
        targetSdk = 27
        versionCode = 1
        versionName = "1.0"
    }
}
