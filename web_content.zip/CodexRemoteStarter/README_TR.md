# Codex Remote Başlatıcı

İmzalanmamış Android kaynak projesi. Web arayüzü `index.html`, `script.js`, `style.css` olarak APK içindeki `assets/web/` klasörüne dahil edilmiştir.

- Min SDK 27
- Target SDK 28
- Max SDK sınırı yok
- START: Termux RUN_COMMAND üzerinden Ubuntu içindeki Codex Remote'u başlatmayı dener
- Stop: Codex Remote stop komutunu gönderir
- Manual/Auto Mode
- Log paneli

Derleme: Android Studio/Gradle ile `assembleDebug` veya `Build APK(s)`.

Termux tarafında harici RUN_COMMAND kullanımının etkin olması gerekir.
