# Game Plan

- Planned at:     2026-10-06T19:27:05Z
- Mode:           2d
- One-line pitch: Arraste o polvo pintor pela tela para cobri-la de tinta enquanto manchas inimigas tentam sujá-la — sobreviva ao caos crescente e quebre seu recorde.

## 1. Verb — the moment-to-moment action

**Primary verb:** drag
**Input:** touch drag (mobile-first; mouse drag no desktop)

**Actions** (each is a candidate SFX cue for audio generation; mark core vs. secondary):

- `paint_trail` *(core)*: enquanto arrasta, o polvo segue o dedo e deixa um rastro de tinta
- `repaint_stain` *(core)*: pintar por cima de uma mancha inimiga a limpa e devolve cobertura
- `combo_streak` *(secondary)*: cobrir área limpa sem parar aumenta o multiplicador de pontos
- `game_over` *(secondary)*: cobertura cai abaixo do mínimo → fim de run

## 2. Loop — the rhythm

**30-second loop:** arraste o polvo cobrindo a tela; manchas inimigas surgem e sujam áreas pintadas — repinte rápido pra manter a cobertura alta.
**5-minute loop:** morreu → vê pontuação/recorde → recomeça com meta de aguentar mais tempo e cobrir mais.

## 3. Stakes — what's at risk and what's earned

**Tension:** manchas inimigas surgem cada vez mais rápido e cobrem sua tinta; a cobertura % cai
**Reward:** pontos por área pintada + combos; high score e “melhor cobertura”
**Failure:** cobertura cai abaixo do limiar (ex.: 20%) → game over

## 4. Setting — the lightweight vibe

**World:** uma tela em branco que vira o ateliê caótico do polvo pintor
**Mood:** tense + retro
**Art style:** 16-bit SNES pixel art

**Scenes** (each is a candidate background asset):

- `atelier`: tela de jogo — fundo pixelado tipo canvas/ateliê SNES
- `result`: tela de game over com pontuação e recorde

**Cast** (each is a candidate portrait or sprite asset; omit if none):

- `polvo`: o polvo pintor protagonista (sprite arrastável)

## 5. MVP — the line we don't cross

**Tier:** Standard

**Must-have** (the smallest thing that's still the game):
- Arrastar o polvo deixando rastro de tinta
- Manchas inimigas que sujam a tela (escalam com o tempo)
- Medidor de cobertura % + pontuação com multiplicador
- Game over quando cobertura cai demais + tela de resultado com high score
- Controles touch mobile-first (portrait)
- Visual pixel art SNES

**Nice-to-have** (explicit "if we have time"):
- Cores de tinta que mudam a cada X segundos
- Partículas/splash ao pintar
- BGM + SFX (pintar, mancha, game over, combo)

**Out of scope** (the temptations we're refusing — must be non-empty):
- Modo multiplayer / ranking online
- Níveis com narrativa ou chefes
- Customização de polvo / loja de skins
- Power-ups complexos (bomba, escudo, etc.)
- Modo sandbox sem falha

**Asset budget:** 2 backgrounds (atelier + result), 1 sprite do polvo, 1 sprite/ícone de mancha inimiga, 1 BGM, 4 SFX (paint, stain, combo, gameover)

## Open questions

- Limiar exato de falha (sugestão: 20% de cobertura) — ajustável no playtest.
- Cor da tinta: fixa no MVP ou ciclando (nice-to-have).
