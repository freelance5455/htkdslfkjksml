# Game Plan

- Planned at:     2026-10-06T16:38:00Z
- Mode:           2d
- One-line pitch: Um pescador aconchegante em pixel art 16-bit: anda até o lago, pesca peixes de raridades diferentes e vende para comprar iscas melhores — sem pressão, só progresso.

## 1. Verb — the moment-to-moment action

**Primary verb:** pescar
**Input:** touch (joystick virtual + botão de ação) + teclado no desktop

**Actions** (each is a candidate SFX cue for audio generation; mark core vs. secondary):

- `move` *(core)*: andar pelo mapa da fazenda/lago
- `cast` *(core)*: lançar a linha na água
- `reel` *(core)*: puxar o peixe no mini-jogo de timing
- `sell` *(secondary)*: vender peixes no balcão
- `buy_bait` *(secondary)*: comprar isca melhor

## 2. Loop — the rhythm

**30-second loop:** chegar à beira d'água → lançar → acertar o timing → pegar peixe
**5-minute loop:** encher a cesta → vender → comprar isca melhor → tentar peixes mais raros

## 3. Stakes — what's at risk and what's earned

**Tension:** peixes raros exigem timing mais apertado e isca melhor
**Reward:** peixes valem ouro; ouro compra iscas e desbloqueia peixes novos
**Failure:** sem falha (cozy) — peixe pode escapar, mas o dia continua

## 4. Setting — the lightweight vibe

**World:** pequena fazenda à beira de um lago, pôr do sol suave
**Mood:** cozy / relaxante
**Art style:** 16-bit pixel art (estilo Stardew Valley)

**Scenes** (each is a candidate background asset):

- `farm_lake`: fazenda + lago + casa + balcão de venda

**Cast** (each is a candidate portrait or sprite asset; omit if none):

- `fisher`: o jogador (vista top-down)
- `fish_common`: peixe comum
- `fish_rare`: peixe raro
- `fish_legend`: peixe lendário

## 5. MVP — the line we don't cross

**Tier:** Minimal

**Must-have** (the smallest thing that's still the game):
- mapa top-down pequeno com lago
- movimento touch (joystick) + botão pescar
- mini-jogo de pesca (timing bar)
- 3 peixes (comum / raro / lendário)
- vender peixes → comprar isca
- HUD: ouro, isca, peixe atual

**Nice-to-have** (explicit "if we have time"):
- ciclo dia/noite visual
- partículas na água / splash
- NPC vendedor com fala curta

**Out of scope** (the temptations we're refusing — must be non-empty):
- plantio / cultivo
- combate / dungeons
- multiplayer
- inventário complexo / crafting
- várias áreas / estações

**Asset budget:** 1 fundo do mapa, 1 sprite do jogador (idle/walk), 3 peixes, ícones UI (isca/ouro), 3–4 SFX, 1 BGM curto
