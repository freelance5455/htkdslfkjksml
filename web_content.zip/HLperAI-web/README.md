# HLper AI — Web (HTML/CSS/JS) Version

This is a plain HTML/CSS/JavaScript version of the HLper AI chat UI —
no build tools, no Android Studio needed. Just open `index.html` in a
browser (or serve the folder with any static server) and it runs.

## Files
- `index.html` — page structure
- `style.css` — blue futuristic theme (same palette as the Android app)
- `script.js` — chat logic (sending messages, rendering bubbles, saving
  history in the browser's localStorage)

## Current behaviour
No AI model is wired in yet — `replyFromModel()` in `script.js` just
echoes back what you typed, so you can see the full chat flow working.

## Making it a real offline AI chat (in-browser)
Pick one:

1. **WebLLM** (https://github.com/mlc-ai/web-llm) — runs a quantized
   model fully client-side using WebGPU (Chrome/Edge). Good match for a
   Gemma-2 2B build. Load it via a `<script type="module">` import and
   call it from `replyFromModel()`.

2. **Transformers.js** (https://huggingface.co/docs/transformers.js) —
   runs ONNX models via WASM/WebGPU, also client-side. Simpler API but
   check that the Malayalam-tuned checkpoint you pick has an ONNX export.

3. **A small local server** — run llama.cpp's built-in server
   (`llama-server -m model.gguf`) on your own machine/phone and have
   `replyFromModel()` `fetch()` its `/completion` endpoint. Not "offline
   in the browser" but is the simplest to get working first since it
   reuses the same GGUF models discussed for the Android app
   (MalayaLLM Gemma-2 2B/9B GGUF on Hugging Face).

## Note
This web version and the separate Android Studio project
(`HLperAI-starter.zip`) are two independent ways to build the same chat
app — pick whichever fits where you want to ship it (browser vs. native
Android app), or use this one to prototype the UI/flow quickly.
