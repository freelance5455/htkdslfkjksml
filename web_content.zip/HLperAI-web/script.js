/*
 * HLper AI — web chat logic.
 *
 * Right now replyFromModel() just echoes the input. To make this truly
 * offline/AI-powered in a browser, wire one of these in (see README.md):
 *
 *   - WebLLM (https://github.com/mlc-ai/web-llm) — runs quantized models
 *     fully client-side via WebGPU. Load a Gemma-2 build and swap
 *     replyFromModel() to call engine.chat.completions.create(...).
 *
 *   - Transformers.js (https://huggingface.co/docs/transformers.js) —
 *     runs ONNX models client-side via WASM/WebGPU. Works for smaller
 *     models; Malayalam coverage depends on the specific checkpoint.
 *
 *   - A backend API (if you don't need fully offline) — replace
 *     replyFromModel() with a fetch() call to your own server, which in
 *     turn calls the Gemma/MalayaLLM GGUF model via llama.cpp's server mode.
 */

const chatWindow = document.getElementById("chatWindow");
const messageInput = document.getElementById("messageInput");
const sendButton = document.getElementById("sendButton");
const statusText = document.getElementById("statusText");

const STORAGE_KEY = "hlper_ai_chat_history";

let modelReady = false;

function loadHistory() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    return [];
  }
}

function saveHistory(history) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(history));
  } catch (e) {
    /* storage unavailable — ignore */
  }
}

let history = loadHistory();

function renderBubble(text, isUser) {
  const bubble = document.createElement("div");
  bubble.className = "bubble " + (isUser ? "user" : "ai");
  bubble.textContent = text;
  chatWindow.appendChild(bubble);
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

function renderAll() {
  chatWindow.innerHTML = "";
  history.forEach((m) => renderBubble(m.text, m.isUser));
}

/**
 * Stub inference call. Replace this with a real model call (see header
 * comment above) once one is wired in.
 */
async function replyFromModel(userText) {
  await new Promise((r) => setTimeout(r, 300)); // simulate thinking
  if (!modelReady) {
    return (
      "(ഓഫ്‌ലൈൻ AI മോഡൽ ഇതുവരെ connect ചെയ്തിട്ടില്ല — README.md കാണുക)\n\n" +
      "Echo: " + userText
    );
  }
  return "Echo: " + userText;
}

async function handleSend() {
  const text = messageInput.value.trim();
  if (!text) return;

  history.push({ text, isUser: true });
  renderBubble(text, true);
  saveHistory(history);

  messageInput.value = "";
  messageInput.style.height = "auto";
  sendButton.disabled = true;

  const reply = await replyFromModel(text);

  history.push({ text: reply, isUser: false });
  renderBubble(reply, false);
  saveHistory(history);

  sendButton.disabled = false;
  messageInput.focus();
}

sendButton.addEventListener("click", handleSend);

messageInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    handleSend();
  }
});

messageInput.addEventListener("input", () => {
  messageInput.style.height = "auto";
  messageInput.style.height = Math.min(messageInput.scrollHeight, 120) + "px";
});

// Initial render
renderAll();
statusText.textContent = modelReady
  ? "Offline AI ready ✓"
  : "Model connected ചെയ്തിട്ടില്ല (echo mode)";
