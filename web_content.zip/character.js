// Procedural top-down RPG character sprite generator.
// Renders pixel-art frames (idle + walk) in 4 facing directions onto small
// canvases, then packs them into a sprite sheet. Everything is drawn from a
// part-based model, so palettes/characters can vary while the animation stays
// consistent.
//
// Legs are articulated: the hip follows the torso's bob while the foot stays
// planted (or lifts, during a walk) — so a bob never yanks the feet off the
// ground.

export const FRAME_W = 32;
export const FRAME_H = 32;
export const IDLE_FRAMES = 4;
export const WALK_FRAMES = 4;
export const DASH_FRAMES = 4;
// a melee swing cycle: two wind-up frames and two strike frames, so a combo
// reads as distinct swings instead of one repeated slash
export const ATTACK_FRAMES = 4;
// every animation the character model can produce (cached per palette)
export const ANIMS = ["idle", "walk", "dash", "attack"];

export const DIRECTIONS = ["down", "left", "right", "up"];

const _rgbCache = new Map();
function rgb(hex) {
  let v = _rgbCache.get(hex);
  if (v) return v;
  let h = String(hex).replace("#", "");
  if (h.length === 3) h = h.split("").map((c) => c + c).join("");
  const n = parseInt(h, 16);
  v = [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  _rgbCache.set(hex, v);
  return v;
}

export class Pix {
  constructor(w, h) {
    this.w = w;
    this.h = h;
    this.d = new Uint8ClampedArray(w * h * 4);
  }
  set(x, y, color) {
    x = Math.round(x);
    y = Math.round(y);
    if (x < 0 || y < 0 || x >= this.w || y >= this.h || !color) return;
    const i = (y * this.w + x) * 4;
    const c = rgb(color);
    this.d[i] = c[0];
    this.d[i + 1] = c[1];
    this.d[i + 2] = c[2];
    this.d[i + 3] = 255;
  }
  rect(x, y, w, h, color) {
    for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) this.set(x + i, y + j, color);
  }
  outline(color) {
    const { w, h } = this;
    const src = this.d.slice();
    const opaque = (x, y) => (x < 0 || y < 0 || x >= w || y >= h ? 0 : src[(y * w + x) * 4 + 3]);
    const c = rgb(color);
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const i = (y * w + x) * 4;
        if (src[i + 3] !== 0) continue;
        if (opaque(x - 1, y) || opaque(x + 1, y) || opaque(x, y - 1) || opaque(x, y + 1)) {
          this.d[i] = c[0];
          this.d[i + 1] = c[1];
          this.d[i + 2] = c[2];
          this.d[i + 3] = 255;
        }
      }
    }
  }
  flipX() {
    const p = new Pix(this.w, this.h);
    for (let y = 0; y < this.h; y++) {
      for (let x = 0; x < this.w; x++) {
        const s = (y * this.w + (this.w - 1 - x)) * 4;
        const d = (y * this.w + x) * 4;
        p.d[d] = this.d[s];
        p.d[d + 1] = this.d[s + 1];
        p.d[d + 2] = this.d[s + 2];
        p.d[d + 3] = this.d[s + 3];
      }
    }
    return p;
  }
  toCanvas() {
    const c = document.createElement("canvas");
    c.width = this.w;
    c.height = this.h;
    c.getContext("2d").putImageData(new ImageData(new Uint8ClampedArray(this.d), this.w, this.h), 0, 0);
    return c;
  }
}

export const PALETTES = {
  hero: {
    skin: "#f0c8a0", skinShade: "#d09a71",
    hair: "#5e3a24", hairDark: "#412717", hairLight: "#805133",
    tunic: "#3f8f4a", tunicDark: "#2d6b38", tunicLight: "#5cb06a",
    belt: "#57381f", buckle: "#e0b74a",
    pants: "#3a3f55", pantsDark: "#282c3d",
    boot: "#4b3524", bootDark: "#2f2114",
    outline: "#17140f", eye: "#1b1b22", eyeLight: "#f4f6ff", mouth: "#8a4f30",
  },
  mage: {
    skin: "#e8c6a8", skinShade: "#c79a78",
    hair: "#d8d2c4", hairDark: "#b0a894", hairLight: "#f2eee4",
    tunic: "#4a5bb5", tunicDark: "#36428c", tunicLight: "#6a7bd8",
    belt: "#4a3a6a", buckle: "#d8c25a",
    pants: "#2f3350", pantsDark: "#20233a",
    boot: "#3a2f4a", bootDark: "#251d33",
    outline: "#141018", eye: "#20203a", eyeLight: "#eef2ff", mouth: "#87553c",
  },
  rogue: {
    skin: "#e6b98f", skinShade: "#c2916a",
    hair: "#2c2320", hairDark: "#1a1512", hairLight: "#4a3d36",
    tunic: "#3d3d46", tunicDark: "#2a2a31", tunicLight: "#565662",
    belt: "#6a4a24", buckle: "#c9a04a",
    pants: "#2c2c33", pantsDark: "#1e1e24",
    boot: "#38281a", bootDark: "#241a10",
    outline: "#101010", eye: "#241c14", eyeLight: "#f2ede2", mouth: "#7a4630",
  },
  ranger: {
    skin: "#f0c8a0", skinShade: "#d09a71",
    hair: "#a8632f", hairDark: "#7d451e", hairLight: "#c98a52",
    tunic: "#6a7a34", tunicDark: "#4d5a24", tunicLight: "#8a9c4c",
    belt: "#4a3520", buckle: "#b89a50",
    pants: "#4a3d2a", pantsDark: "#33291c",
    boot: "#3f2d1c", bootDark: "#291c11",
    outline: "#17140f", eye: "#241c14", eyeLight: "#f4f0e6", mouth: "#8a4f30",
  },
  knight: {
    skin: "#f0c8a0", skinShade: "#d09a71",
    hair: "#c9d2e2", hairDark: "#8b95a8", hairLight: "#eef2fa",
    tunic: "#8a93a8", tunicDark: "#5b6377", tunicLight: "#b9c2d6",
    belt: "#4a4f5e", buckle: "#e0c46a",
    pants: "#3a4050", pantsDark: "#282d39",
    boot: "#2e333f", bootDark: "#1d212a",
    outline: "#141824", eye: "#1b1b22", eyeLight: "#f4f6ff", mouth: "#8a4f30",
  },
  pyromancer: {
    skin: "#e6b98f", skinShade: "#c2916a",
    hair: "#2a1a12", hairDark: "#170d08", hairLight: "#4a2c1c",
    tunic: "#3a2030", tunicDark: "#22121e", tunicLight: "#5e3244",
    belt: "#6a3a1a", buckle: "#f0a03a",
    pants: "#2a1a20", pantsDark: "#1a1016",
    boot: "#1a1016", bootDark: "#0e080c",
    outline: "#160a10", eye: "#ff8a3a", eyeLight: "#ffe0a0", mouth: "#7a3a2a",
  },
  shadow: {
    skin: "#6a6a86", skinShade: "#4a4a63",
    hair: "#171226", hairDark: "#0b0814", hairLight: "#2e2340",
    tunic: "#1c1626", tunicDark: "#0e0a14", tunicLight: "#33294a",
    belt: "#2a1c34", buckle: "#a86cf0",
    pants: "#171225", pantsDark: "#0d0a18",
    boot: "#0e0a14", bootDark: "#07050a",
    outline: "#070510", eye: "#ff5a7a", eyeLight: "#ffd0dc", mouth: "#4a2438",
  },
  aurum: {
    skin: "#f5d3ab", skinShade: "#d4a87c",
    hair: "#f0e2a8", hairDark: "#bda45c", hairLight: "#fff8d8",
    tunic: "#e8c766", tunicDark: "#a8862f", tunicLight: "#fff0b0",
    belt: "#8a6a20", buckle: "#fff6d0",
    pants: "#6a5a2a", pantsDark: "#4a3f1c",
    boot: "#4a3c1a", bootDark: "#2e2610",
    outline: "#2a2008", eye: "#2a2410", eyeLight: "#fffbe8", mouth: "#a86a3a",
  },
  // ultra-legendary bunny girl: silver hair, plum bunny suit, pink trim.
  // `bunny: true` switches to the dedicated bunny-suit body renderer;
  // `ears`/`earsInner`/`tail`/`blush`/`shoe` are optional extras.
  usagi: {
    bunny: true,
    skin: "#fbe3d6", skinShade: "#e7b4a4", skinLight: "#fff4ec",
    hair: "#dbe0f8", hairDark: "#a6aedc", hairLight: "#ffffff",
    tunic: "#3b2c56", tunicDark: "#211634", tunicLight: "#7a63b4",
    belt: "#ff7ab8", buckle: "#ffd9ee",
    pants: "#3b2c56", pantsDark: "#211634",
    boot: "#f0f3ff", bootDark: "#c8d0ee",
    shoe: "#2a2140", shoeLight: "#4a3a70",
    outline: "#150f20",
    eye: "#9b7ae8", eyeShade: "#5f43a0", eyeDeep: "#2a1a48",
    eyeLight: "#ffffff", eyeShine: "#ffffff",
    mouth: "#d9668f", lip: "#e8779e",
    ears: "#dbe0f8", earsInner: "#ff8ec4", earsInnerLight: "#ffc2e2",
    tail: "#f4f6ff", tailShade: "#cdd4ea", blush: "#ff9ecb",
  },
  // ultra-legendary swordswoman: black hair, dark red eyes, a black tactical
  // jacket (dark red trim), black plated skirt and white socks. Wields the
  // glowing Blood Sword.
  kuruki: {
    longHair: true,
    skirt: true,
    skin: "#f0cec0", skinShade: "#d4a693",
    hair: "#141419", hairDark: "#06060a", hairLight: "#3c3c50",
    tunic: "#16161c", tunicDark: "#09090d", tunicLight: "#3a1a22",
    belt: "#2a0c12", buckle: "#d81f2a",
    pants: "#e9edf6", pantsDark: "#b9c1d2",
    boot: "#15151b", bootDark: "#08080c",
    outline: "#040407", eye: "#d01028", eyeLight: "#ff9a9a", mouth: "#b0565e",
  },
  // epic healer: leaf-green robes, mossy brown hair, bark accents.
  druid: {
    skin: "#e9c39c", skinShade: "#c69b74",
    hair: "#6a4a2a", hairDark: "#452e18", hairLight: "#8f6a3e",
    tunic: "#3f7a3c", tunicDark: "#28522a", tunicLight: "#63a85c",
    belt: "#4a3a22", buckle: "#c9d86a",
    pants: "#35502c", pantsDark: "#233619",
    boot: "#3a2b1a", bootDark: "#241a0f",
    outline: "#101a0c", eye: "#2a5a2a", eyeLight: "#dfffcf", mouth: "#8a5a3a",
  },
  // epic gunner: brown duster coat, dark hair, gold trim.
  gunslinger: {
    skin: "#eabf95", skinShade: "#c8996c",
    hair: "#2e2018", hairDark: "#1a1109", hairLight: "#4e3728",
    tunic: "#6a4a2e", tunicDark: "#432d1a", tunicLight: "#96703f",
    belt: "#2a201a", buckle: "#e0b74a",
    pants: "#3a3026", pantsDark: "#261f18",
    boot: "#2e2014", bootDark: "#1c130b",
    outline: "#160f08", eye: "#2a2016", eyeLight: "#f6ecd8", mouth: "#8a5136",
  },
  // legendary blademaster: crimson haori, black sash, pale steel.
  ronin: {
    skin: "#f0cba6", skinShade: "#d0a078",
    hair: "#1a1a20", hairDark: "#0a0a10", hairLight: "#3c3c4a",
    tunic: "#8e1f28", tunicDark: "#5c1018", tunicLight: "#c2454c",
    belt: "#141418", buckle: "#d8d2c0",
    pants: "#26262e", pantsDark: "#16161c",
    boot: "#1c1c22", bootDark: "#0e0e12",
    outline: "#0e0a0c", eye: "#3a2418", eyeLight: "#f6f2ea", mouth: "#9a5340",
  },
  // legendary death-caster: violet robes, bone-white hair, soul-green eyes.
  necromancer: {
    skin: "#d8c6b8", skinShade: "#b39c8c",
    hair: "#e6e2ee", hairDark: "#b3aec4", hairLight: "#ffffff",
    tunic: "#3a2258", tunicDark: "#22103a", tunicLight: "#5e3a8c",
    belt: "#241436", buckle: "#8ce6a8",
    pants: "#241436", pantsDark: "#160a24",
    boot: "#1a0f28", bootDark: "#0e0718",
    outline: "#0a0612", eye: "#6ce6a0", eyeLight: "#d8ffe6", mouth: "#8a5a70",
  },
  // epic sun-priest: white-and-gold vestments, pale gold hair.
  cleric: {
    skin: "#f3d3b4", skinShade: "#d3a887",
    hair: "#f0d488", hairDark: "#c0a34f", hairLight: "#fff2c0",
    tunic: "#f2efe2", tunicDark: "#c3bfae", tunicLight: "#ffffff",
    belt: "#c9a63c", buckle: "#fff6d0",
    pants: "#ddd6c0", pantsDark: "#b3ab92",
    boot: "#8a7648", bootDark: "#5f502e",
    outline: "#2a2414", eye: "#3a6a8a", eyeLight: "#eaf6ff", mouth: "#a86a52",
  },
  // rare wandering minstrel: deep violet doublet with amber trim.
  bard: {
    skin: "#eec39a", skinShade: "#cb9770",
    hair: "#8a4a2a", hairDark: "#5e2f18", hairLight: "#b97244",
    tunic: "#5a3aa0", tunicDark: "#3b2470", tunicLight: "#8260d0",
    belt: "#3a2a1a", buckle: "#e8b64a",
    pants: "#33304a", pantsDark: "#232036",
    boot: "#3a2a1c", bootDark: "#241a10",
    outline: "#180f22", eye: "#2a3a5a", eyeLight: "#f2f6ff", mouth: "#9a5a3a",
  },
  // ultra-legendary tea-mistress: long silver-blue hair, a flowing teal gown
  // with cyan trim, and bright blue eyes. She floats above an ornate table with
  // a cyan-eyed robot at her side (both drawn in the scene, not the sprite),
  // and channels charged electro beams. `hover: true` lifts her a couple px so
  // she reads as weightless.
  seraphina: {
    longHair: true,
    skirt: true,
    hover: true,
    skin: "#f7e0d6", skinShade: "#d9b0a4", skinLight: "#fff5ef",
    hair: "#c8d6f2", hairDark: "#93a6d4", hairLight: "#ffffff",
    tunic: "#2f8f9a", tunicDark: "#1b5f68", tunicLight: "#66c6cf",
    belt: "#5a3f96", buckle: "#8fe6ff",
    pants: "#28404e", pantsDark: "#182c36",
    boot: "#33566a", bootDark: "#1f3846",
    outline: "#0b1622", eye: "#2f7dd8", eyeShade: "#1b4d96", eyeLight: "#dff0ff",
    mouth: "#c46a80",
  },
};

// ---- signature kit loadout ------------------------------------------------
// Every palette gets a `feat` object describing the gear that sets its wearer
// apart at a glance. It lives in its own table (rather than inline in PALETTES)
// so the whole silhouette language is readable in one place. Colours are
// authored once and shaded at draw time; palette colours are reused where the
// gear should match the outfit (a hood takes the tunic colour, etc.), so all
// 17 heroes read as distinct characters even though most of them share a body.
const FEATS = {
  hero:        { bandana: "#c0392b", hairStyle: "spiky", pauldrons: "#7a5a34" },
  ranger:      { hood: true, hoodPeak: true, quiver: true, satchel: "#5a4426" },
  rogue:       { hairStyle: "ponytail", ponytailTie: "#6a4a24", scarf: "#3a3a46", mask: "#2a2a33", satchel: "#4a3a24" },
  knight:      { hat: "helm", metal: "#9aa4bb", metalDark: "#5b6377", metalLight: "#cdd6ea", plume: "#c0392b", cape: "#2f5fa8", capeDark: "#1c3a6a", capeLight: "#4f86d8", pauldrons: true },
  bard:        { hat: "feathercap", hatColor: "#5a3aa0", hatDark: "#3b2470", hatLight: "#8260d0", feather: "#e8b64a", scarf: "#e8b64a", satchel: "#6a4a2a" },
  mage:        { hat: "witch", hatColor: "#4a5bb5", hatDark: "#36428c", hatLight: "#6a7bd8", hatBand: "#36428c", hatBuckle: "#e0b74a", robe: "#4a5bb5", robeDark: "#36428c", robeLight: "#6a7bd8", beard: true },
  pyromancer:  { hood: true, hoodColor: "#3a2030", hoodDark: "#22121e", hoodLight: "#5e3244", robe: "#3a2030", robeDark: "#22121e", robeLight: "#5e3244", pauldrons: "#5e3244", pauldronDark: "#22121e", pauldronLight: "#8a4a5e", pauldronSpikes: true },
  shadow:      { hood: true, hoodDeep: true, hoodColor: "#1c1626", hoodDark: "#0e0a14", hoodLight: "#33294a", cape: "#160f20", capeDark: "#0a0710", capeLight: "#2e2340" },
  aurum:       { hat: "crown", crown: "#e8c766", crownDark: "#a8862f", crownLight: "#fff0b0", crownGem: "#d8354a", cape: "#a8243a", capeDark: "#6a1624", capeLight: "#d8526a", capeClasp: "#fff6d0", pauldrons: "#e8c766", pauldronDark: "#a8862f", pauldronLight: "#fff0b0" },
  usagi:       {},
  kuruki:      { cape: "#2a0c12", capeDark: "#140608", capeLight: "#4a1a24", capeClasp: "#d81f2a" },
  druid:       { antlers: "#c9b06a", robe: "#3f7a3c", robeDark: "#28522a", robeLight: "#63a85c", scarf: "#63a85c", scarfDark: "#28522a", satchel: "#4a3a22" },
  cleric:      { hood: true, hoodLow: true, hoodColor: "#f2efe2", hoodDark: "#c3bfae", hoodLight: "#ffffff", robe: "#f2efe2", robeDark: "#c3bfae", robeLight: "#ffffff", halo: "#f5e06a" },
  gunslinger:  { hat: "cowboy", hatColor: "#6a4a2e", hatDark: "#432d1a", hatLight: "#96703f", hatBand: "#2a201a", scarf: "#a8243a", scarfDark: "#6a1624" },
  ronin:       { hairStyle: "topknot", topknotTie: "#141418", robe: "#8e1f28", robeDark: "#5c1018", robeLight: "#c2454c", robeOpen: true, pauldrons: "#26262e", pauldronDark: "#16161c", pauldronLight: "#3c3c4a" },
  necromancer: { hood: true, hoodPeak: true, hoodColor: "#3a2258", hoodDark: "#22103a", hoodLight: "#5e3a8c", robe: "#3a2258", robeDark: "#22103a", robeLight: "#5e3a8c", pauldrons: "#b3a98e", pauldronDark: "#8a8068", pauldronLight: "#e8e2d0", pauldronSpikes: true },
  seraphina:   { robe: "#2f8f9a", robeDark: "#1b5f68", robeLight: "#66c6cf", robeOpen: true, halo: "#8fe6ff", scarf: "#5a3f96", scarfDark: "#38266a", scarfLight: "#8a6ad0" },
};
for (const k of Object.keys(FEATS)) {
  if (PALETTES[k] && Object.keys(FEATS[k]).length) PALETTES[k].feat = FEATS[k];
}

// ---- poses ----------------------------------------------------------------
// Leg entries are [dx, dy]; dy is the FOOT lift (negative = raised).
// bob shifts the upper body only, so planted feet stay planted.
const WALK_FRONT = [
  { lLeg: [0, -3], rLeg: [0, 0], bob: -1, lArm: 0, rArm: 1 },
  { lLeg: [-1, 0], rLeg: [1, -3], bob: 0, lArm: -1, rArm: 0 },
  { lLeg: [0, 0], rLeg: [0, -3], bob: -1, lArm: 1, rArm: 0 },
  { lLeg: [1, -3], rLeg: [-1, 0], bob: 0, lArm: 0, rArm: -1 },
];
const WALK_SIDE = [
  { lLeg: [3, 0], rLeg: [-3, 0], bob: 0, arm: -2 },
  { lLeg: [1, -2], rLeg: [-1, 0], bob: -1, arm: 0 },
  { lLeg: [-3, 0], rLeg: [3, 0], bob: 0, arm: 2 },
  { lLeg: [-1, 0], rLeg: [1, -2], bob: -1, arm: 0 },
];

// the "Naruto run": a hard forward lean with both arms streaming behind.
const DASH_FRONT = [
  { lLeg: [0, -3], rLeg: [0, 0], bob: -1 },
  { lLeg: [-2, 0], rLeg: [2, -3], bob: 0 },
  { lLeg: [0, 0], rLeg: [0, -3], bob: -1 },
  { lLeg: [2, -3], rLeg: [-2, 0], bob: 0 },
];
const DASH_SIDE = [
  { lLeg: [5, -2], rLeg: [-5, 0], bob: 0 },
  { lLeg: [1, -3], rLeg: [-4, 0], bob: -1 },
  { lLeg: [-5, 0], rLeg: [5, -2], bob: 0 },
  { lLeg: [-2, 0], rLeg: [3, -3], bob: -1 },
];

// Combat poses. Frames 0/2 cock the arms back and up, frames 1/3 are the two
// strikes of the combo (arms swept down and across, then down and out), with a
// matching little stance shift in the legs. The scene picks the frame from the
// swing timer and the combo step, so hit 1, 2, 3 look different from each other.
const ATTACK_FRONT = [
  { bob: -1, lLeg: [0, 0], rLeg: [0, 0], lArm: -2, rArm: -2, lDx: 0, rDx: 0 },
  { bob: 0, lLeg: [-1, 0], rLeg: [1, 0], lArm: 2, rArm: 2, lDx: 1, rDx: -1 },
  { bob: -1, lLeg: [0, 0], rLeg: [0, 0], lArm: -2, rArm: -2, lDx: 0, rDx: 0 },
  { bob: 0, lLeg: [1, 0], rLeg: [-1, 0], lArm: 2, rArm: 2, lDx: -1, rDx: 1 },
];
const ATTACK_SIDE = [
  { bob: -1, lLeg: [0, 0], rLeg: [0, 0], arm: -4 },
  { bob: 0, lLeg: [2, 0], rLeg: [-2, 0], arm: 4 },
  { bob: -1, lLeg: [0, 0], rLeg: [0, 0], arm: -4 },
  { bob: 0, lLeg: [2, 0], rLeg: [-2, 0], arm: 4 },
];

function poseFor(anim, frame, dir) {
  const pose = {
    bob: 0,
    lArm: { dx: 0, dy: 0 },
    rArm: { dx: 0, dy: 0 },
    lLeg: { dx: 0, dy: 0 },
    rLeg: { dx: 0, dy: 0 },
  };
  if (anim === "idle") {
    pose.bob = [0, -1, -1, 0][frame % IDLE_FRAMES];
    return pose;
  }
  if (anim === "dash") {
    const f = frame % DASH_FRAMES;
    if (dir === "left" || dir === "right") {
      const w = DASH_SIDE[f];
      pose.lLeg = { dx: w.lLeg[0], dy: w.lLeg[1] };
      pose.rLeg = { dx: w.rLeg[0], dy: w.rLeg[1] };
      pose.lArm.dx = -4;
      pose.rArm.dx = -2;
      pose.bob = w.bob;
    } else {
      const w = DASH_FRONT[f];
      pose.lLeg = { dx: w.lLeg[0], dy: w.lLeg[1] };
      pose.rLeg = { dx: w.rLeg[0], dy: w.rLeg[1] };
      pose.lArm.dy = 2;
      pose.rArm.dy = 2;
      pose.bob = w.bob;
    }
    return pose;
  }
  if (anim === "attack") {
    const f = frame % ATTACK_FRAMES;
    const w = dir === "left" || dir === "right" ? ATTACK_SIDE[f] : ATTACK_FRONT[f];
    pose.lLeg = { dx: w.lLeg[0], dy: w.lLeg[1] };
    pose.rLeg = { dx: w.rLeg[0], dy: w.rLeg[1] };
    pose.bob = w.bob;
    if (w.arm !== undefined) pose.lArm.dx = w.arm;
    else { pose.lArm.dy = w.lArm; pose.rArm.dy = w.rArm; pose.lArm.dx = w.lDx; pose.rArm.dx = w.rDx; }
    return pose;
  }
  const f = frame % WALK_FRAMES;
  if (dir === "left" || dir === "right") {
    const w = WALK_SIDE[f];
    pose.lLeg = { dx: w.lLeg[0], dy: w.lLeg[1] };
    pose.rLeg = { dx: w.rLeg[0], dy: w.rLeg[1] };
    pose.lArm.dx = w.arm;
    pose.bob = w.bob;
  } else {
    const w = WALK_FRONT[f];
    pose.lLeg = { dx: w.lLeg[0], dy: w.lLeg[1] };
    pose.rLeg = { dx: w.rLeg[0], dy: w.rLeg[1] };
    pose.lArm.dy = w.lArm;
    pose.rArm.dy = w.rArm;
    pose.bob = w.bob;
  }
  return pose;
}

// ---- parts ----------------------------------------------------------------
const HIP_Y = 21;
const FOOT_Y = 30;

function drawLeg(p, pal, x, w, leg, colors, bob, side = "l") {
  const top = HIP_Y + bob;
  const foot = FOOT_Y + leg.dy;
  const hgt = foot - top;
  const sx = x + leg.dx + (side === "l" ? 0 : w - 1);
  if (hgt > 0) {
    p.rect(x + leg.dx, top, w, hgt, colors.pants);
    if (colors.pantsDark) p.rect(sx, top, 1, hgt, colors.pantsDark);
  }
  p.rect(x + leg.dx, foot, w, 1, colors.boot);
  p.rect(x + leg.dx, foot + 1, w, 1, colors.bootDark || colors.boot);
}

function drawArmFront(p, pal, x, y, arm, side) {
  const dx = arm.dx, dy = arm.dy;
  const outer = side === "l" ? 0 : 1;
  const inner = side === "l" ? 1 : 0;
  p.rect(x + dx, y + dy, 2, 4, pal.tunic);
  p.rect(x + dx + outer, y + dy, 1, 4, pal.tunicDark);
  p.rect(x + dx + inner, y + dy, 1, 1, pal.tunicLight);
  p.rect(x + dx, y + 4 + dy, 2, 3, pal.skin);
  p.rect(x + dx + outer, y + 4 + dy, 1, 3, pal.skinShade);
}

// ---- pleated mini-skirt (Kuruki) ------------------------------------------
// Palettes flagged `skirt: true` drop the hip-to-ankle trouser leg and wear a
// short tiered black skirt instead, matching Kuruki's banner art: a flared
// plate over the hips with a darker tier seam, pleats, faint dark-red piping
// and two red rose pins on the front waistband. Her legs keep the white
// thigh-high socks from the palette, so the hem meets the socks mid-thigh.
function drawSkirtFront(p, pal, b, back) {
  const R = (x, y, w, h, c) => p.rect(x, y + b, w, h, c);
  R(11, 22, 10, 1, pal.tunic); // waistband, flush with the torso
  R(9, 23, 14, 1, pal.tunic); // top tier flares out past the arms
  R(9, 24, 14, 1, pal.tunicDark); // tier seam
  R(7, 25, 18, 1, pal.tunic); // bottom tier
  R(6, 26, 20, 1, pal.tunicDark); // hem edge
  R(11, 23, 1, 3, pal.tunicDark); // pleats
  R(20, 23, 1, 3, pal.tunicDark);
  R(15, 23, 2, 3, pal.tunicDark);
  R(9, 23, 1, 1, pal.tunicLight); // top-tier edge highlight
  R(22, 23, 1, 1, pal.tunicLight);
  if (!back) {
    R(12, 22, 1, 1, pal.buckle); // red rose pins
    R(19, 22, 1, 1, pal.buckle);
  }
}

function drawSkirtSide(p, pal, b) {
  const R = (x, y, w, h, c) => p.rect(x, y + b, w, h, c);
  R(12, 22, 9, 1, pal.tunic); // waistband
  R(10, 23, 13, 1, pal.tunic); // top tier
  R(10, 24, 13, 1, pal.tunicDark); // tier seam
  R(8, 25, 16, 1, pal.tunic); // bottom tier, sweeping back
  R(7, 26, 18, 1, pal.tunicDark); // hem edge
  R(12, 23, 1, 3, pal.tunicDark); // pleats
  R(18, 23, 1, 3, pal.tunicDark);
  R(10, 23, 1, 1, pal.tunicLight); // top-tier edge highlight
  R(18, 22, 1, 1, pal.buckle); // red rose pin
}

// ---- Usagi: the dedicated bunny-suit body ---------------------------------
// She is the ultra-rarity hero, so she gets her own body renderer instead of
// the generic tunic/leg wear: a cinched plum leotard with pink piping, a chest
// bow and a choker; bare arms with leotard shoulder caps and pink wrist cuffs;
// bare thighs into thigh-high white stockings with pink garters and dark heels;
// a wide silver-haired head with large rounded violet eyes; a long ponytail in
// profile; and a fluffy pom tail on the hip.
//
// Front/back pixels are mirrored around x=15.5 (x -> 31-x) so both halves stay
// symmetric: `M` is `R`'s mirrored twin. The ears lag one beat behind the body
// bob (`bounce`) so they feel alive.

// Each ear row is [x, y, width], tip -> root. Usagi's splay outward and swell
// to 4px through the belly of the ear so the pair reads as full, velvety rabbit
// ears rather than thin antennae. The pink inner fur then gets a 2px stripe
// down the middle of every wide row.
const EAR_FRONT = [
  [6, 0, 2],
  [6, 1, 3],
  [6, 2, 4],
  [7, 3, 4],
  [7, 4, 4],
  [8, 5, 4],
  [9, 6, 4],
];
// the profile ear sweeps back off the crown
const EAR_SIDE = [
  [7, 0, 2],
  [6, 1, 3],
  [6, 2, 4],
  [7, 3, 4],
  [8, 4, 4],
  [9, 5, 4],
  [10, 6, 4],
];

function drawBunnyLeg(p, pal, x, leg, b, far, innerDir = 0) {
  const skin = far ? pal.skinShade : pal.skin;
  const stk = far ? (pal.bootDark || pal.boot) : pal.boot;
  const stkD = pal.bootDark || pal.boot;
  const shoe = pal.shoe || pal.outline;
  const shoeL = pal.shoeLight || shoe;
  const top = HIP_Y + b;
  const foot = FOOT_Y + leg.dy;
  const lx = Math.round(x + leg.dx);
  const stTop = top + 4; // stockings start right under the skirt hem
  const thighH = Math.max(1, stTop - top);
  // bare thigh — a touch fuller at the hip so the inner-thigh gap opens low
  const nWide = innerDir === 0 ? 0 : Math.max(0, thighH - 2);
  const wx = innerDir < 0 ? lx - 1 : lx;
  p.rect(lx, top, 3, thighH, skin);
  if (nWide > 0) {
    p.rect(wx, top, 4, nWide, skin);
    if (!far) p.rect(wx + 3, top, 1, nWide, pal.skinShade);
  }
  if (!far) p.rect(lx + 2, top + nWide, 1, thighH - nWide, pal.skinShade);
  // thigh-high stocking with a pink garter band + a tiny bow
  const stH = Math.max(1, foot - stTop);
  p.rect(lx, stTop, 3, stH, stk);
  if (!far && stH > 1) p.rect(lx + 2, stTop + 1, 1, stH - 1, stkD);
  p.rect(lx, stTop, 3, 1, pal.belt);
  if (!far && stH > 2) p.rect(lx, stTop + 1, 1, 1, pal.buckle || pal.belt);
  // heel
  p.rect(lx, foot, 3, 1, shoe);
  p.rect(lx, foot + 1, 3, 1, shoe);
  if (!far) p.rect(lx + 2, foot, 1, 2, shoeL);
}

function drawBunnyArm(p, pal, x, y, arm, side) {
  const dx = arm.dx || 0, dy = arm.dy || 0;
  const skin = pal.skin, skinD = pal.skinShade, skinL = pal.skinLight || pal.skin;
  // light falls from the upper-left: on the left arm the OUTER column catches
  // it, on the right arm the INNER one does. The far column is always the deep
  // shadow that doubles as the seam against the bodice, so the limb reads as a
  // rounded arm instead of a flat lit stripe pasted onto the torso.
  const capLit = side === "l" ? pal.tunicLight : pal.tunic;
  const cuff = pal.mouth || pal.lip || pal.belt;
  // leotard puff sleeve, ending in a pink trim band
  p.rect(x + dx, y + dy, 2, 3, pal.tunic);
  p.rect(x + dx + 1, y + dy, 1, 3, pal.tunicDark);
  p.rect(x + dx, y + dy, 1, 3, capLit);
  p.rect(x + dx, y + 2 + dy, 2, 1, pal.belt);
  // bare forearm
  p.rect(x + dx, y + 3 + dy, 2, 3, skin);
  p.rect(x + dx + 1, y + 3 + dy, 1, 3, skinD);
  p.rect(x + dx, y + 3 + dy, 1, 1, skinL);
  // rose wrist cuff (bright pip on top) + hand
  p.rect(x + dx, y + 6 + dy, 2, 1, cuff);
  p.rect(x + dx, y + 6 + dy, 1, 1, pal.belt);
  p.rect(x + dx, y + 7 + dy, 2, 1, skin);
  p.rect(x + dx + 1, y + 7 + dy, 1, 1, skinD);
}

// Optional bunny ears (palette.ears) — drawn last so they sit on top of the
// hair. `tall` selects Usagi's long splayed ears with pink inner fluff; the
// short variant is for any other character that just wants ears.
function drawEarsFront(p, pal, b, tall, bounce = 0, back = false) {
  if (!pal.ears) return;
  const inner = pal.earsInner || pal.ears;
  const innerL = pal.earsInnerLight || inner;
  if (tall) {
    const e = b + bounce;
    for (const [x, y, w] of EAR_FRONT) {
      p.rect(x, y + e, w, 1, pal.ears);
      p.rect(31 - (x + w - 1), y + e, w, 1, pal.ears);
      if (w < 2) continue;
      // from behind we only see the ear's outer fur and a soft centre fold
      const iw = back ? 1 : (w >= 4 ? 2 : 1);
      const ix = back ? x + w - 2 : (w >= 3 ? x + 1 : x + w - 1);
      const c = back ? (pal.hairDark || pal.ears) : (y <= 3 ? innerL : inner);
      p.rect(ix, y + e, iw, 1, c);
      p.rect(31 - (ix + iw - 1), y + e, iw, 1, c);
    }
    return;
  }
  for (const x of [12, 17]) {
    p.rect(x, 1 + b, 3, 4, pal.ears);
    p.rect(x + 1, 0 + b, 1, 1, pal.ears);
    p.rect(x + 1, 2 + b, 1, 2, pal.earsInner || pal.ears);
    p.rect(x, 5 + b, 3, 1, pal.hairDark || pal.ears);
  }
}

function drawEarsSide(p, pal, b, tall, bounce = 0) {
  if (!pal.ears) return;
  const inner = pal.earsInner || pal.ears;
  const innerL = pal.earsInnerLight || inner;
  if (tall) {
    const e = b + bounce;
    for (const [x, y, w] of EAR_SIDE) {
      p.rect(x, y + e, w, 1, pal.ears);
      if (w < 2) continue;
      const c = y <= 3 ? innerL : inner;
      const iw = w >= 4 ? 2 : 1;
      const ix = w >= 3 ? x + 1 : x + w - 1;
      p.rect(ix, y + e, iw, 1, c);
    }
    return;
  }
  const x = 10;
  p.rect(x, 1 + b, 3, 4, pal.ears);
  p.rect(x + 1, 0 + b, 1, 1, pal.ears);
  p.rect(x + 1, 2 + b, 1, 2, pal.earsInner || pal.ears);
  p.rect(x, 5 + b, 3, 1, pal.hairDark || pal.ears);
}

// A big round chibi eye: thin dark lids, a wide violet iris and a white glint.
// `x` is the eye's OUTER column (left edge of the left eye). The bitmap keeps
// the dark lash to the top/outer edge so the iris stays bright and open.
const EYE_FRONT = [
  ["L", "L", "L", "L"],
  ["L", "W", "i", "i"],
  ["L", "i", "i", "I"],
  [".", "L", "L", "."],
];
// a narrower almond for the profile view, leaning toward the direction of gaze
const EYE_SIDE = [
  ["L", "L", "."],
  ["L", "W", "i"],
  ["i", "i", "I"],
  [".", "L", "L"],
];
function drawEyeBits(p, pal, x, y, grid, lash, mirror) {
  const iris = pal.eye, irisD = pal.eyeShade || pal.eye;
  const shine = pal.eyeShine || pal.eyeLight || "#ffffff";
  const tone = { L: lash, i: iris, I: irisD, W: shine };
  for (let ry = 0; ry < grid.length; ry++) {
    const row = grid[ry];
    for (let rx = 0; rx < row.length; rx++) {
      const c = tone[row[rx]];
      if (!c) continue;
      if (mirror) p.rect(31 - (x + rx), y + ry, 1, 1, c);
      else p.rect(x + rx, y + ry, 1, 1, c);
    }
  }
}
function bunnyEye(p, pal, x, y, lash, mirror) {
  drawEyeBits(p, pal, x, y, EYE_FRONT, lash, mirror);
  // a tiny lower lash flick on the outer cheek adds a wink of length
  if (mirror) p.rect(31 - (x - 1), y + 3, 1, 1, lash);
  else p.rect(x - 1, y + 3, 1, 1, lash);
}
function bunnyEyeSide(p, pal, x, y, lash) {
  drawEyeBits(p, pal, x, y, EYE_SIDE, lash, false);
  p.rect(x - 1, y + 3, 1, 1, lash);
}

function drawBunnyFront(p, pal, pose, back) {
  const b = pose.bob;
  const bounce = -b; // ears lag a beat behind the body's bob
  const R = (x, y, w, h, c) => p.rect(x, y + b, w, h, c);
  const M = (x, y, w, h, c) => p.rect(31 - (x + w - 1), y + b, w, h, c);
  const skin = pal.skin, skinD = pal.skinShade;
  const hair = pal.hair, hairD = pal.hairDark, hairL = pal.hairLight;
  const suit = pal.tunic, suitD = pal.tunicDark, suitL = pal.tunicLight;
  const trim = pal.belt, trimL = pal.buckle || pal.belt;
  const lash = pal.eyeDeep || pal.eye;

  // a soft fall of hair behind each shoulder, for depth
  R(7, 10, 4, 7, hair);
  M(7, 10, 4, 7, hair);
  R(7, 10, 1, 7, hairD);
  M(7, 10, 1, 7, hairD);

  drawBunnyLeg(p, pal, 12, pose.lLeg, b, false, 1);
  drawBunnyLeg(p, pal, 17, pose.rLeg, b, false, -1);

  // cinched leotard, cut high on the hip (lit from the upper-left)
  R(11, 15, 10, 2, suit);
  R(12, 17, 8, 2, suit);
  R(12, 19, 8, 2, suit);
  // a soft flared skirt with a white lace hem: it covers the hip and the upper
  // thigh, so the bunny suit reads as a proper little dress, not a leotard
  R(11, 21, 10, 1, suit);
  R(10, 22, 12, 2, suit);
  R(10, 22, 1, 2, suitL); R(21, 22, 1, 2, suitD);
  R(11, 21, 1, 1, suitL); R(20, 21, 1, 1, suitD);
  R(10, 24, 12, 1, pal.boot || pal.tunicLight);
  R(10, 25, 2, 1, pal.boot || pal.tunicLight);
  M(10, 25, 2, 1, pal.boot || pal.tunicLight);
  R(15, 25, 2, 1, pal.boot || pal.tunicLight);
  // flat where the lit arm overlaps, so arm-lit + body-lit don't stack into a
  // light-dark-light stripe
  R(11, 15, 1, 1, suitL); R(11, 16, 1, 1, suit); R(20, 15, 1, 2, suitD);
  R(12, 17, 1, 4, suitL); R(19, 17, 1, 4, suitD);
  // sweetheart neckline: a soft-shaded V of bare skin against the dark fabric
  R(13, 16, 6, 1, skin);
  R(13, 16, 1, 1, skinD); R(18, 16, 1, 1, skinD);
  R(14, 17, 4, 1, skin);
  // a small pink ribbon rosette with a pale knot, pinned at the bust
  R(15, 18, 2, 1, trim);
  R(13, 19, 6, 1, trim);
  R(15, 19, 2, 1, trimL);
  R(15, 20, 2, 1, trim);

  drawBunnyArm(p, pal, 9, 16 + b, pose.lArm, "l");
  drawBunnyArm(p, pal, 21, 16 + b, pose.rArm, "r");

  // neck + head
  R(14, 14, 4, 1, skinD);
  R(10, 6, 12, 8, skin);
  R(10, 13, 12, 1, skinD);

  if (back) {
    // crown with a centre part
    R(9, 3, 14, 3, hair);
    R(10, 3, 5, 1, hairL); R(18, 3, 3, 1, hairL);
    R(9, 3, 1, 3, hairD); R(22, 3, 1, 3, hairD);
    R(10, 6, 12, 8, hair);
    R(10, 6, 1, 8, hairD); R(21, 6, 1, 8, hairD);
    R(15, 5, 2, 1, hairL);
    // the crown throws a shadow down the middle of the fall, and the nape
    // darkens where the hair gathers — that gives the skull its roundness
    R(15, 6, 2, 1, hairD);
    R(15, 7, 2, 6, hairD);
    R(11, 13, 10, 1, hairD);
    // the long silver fall parts into two low curtains, framing the back bow
    R(8, 13, 4, 6, hair); R(20, 13, 4, 6, hair);
    R(8, 19, 2, 1, hair); R(22, 19, 2, 1, hair);
    R(11, 19, 1, 1, hair); R(20, 19, 1, 1, hair);
    R(9, 20, 1, 1, hair); R(22, 20, 1, 1, hair);
    R(8, 20, 1, 1, hair); R(23, 20, 1, 1, hair);
    // strand grooves + a sheen where light clips each curtain's outer edge
    R(8, 13, 1, 7, hairL); R(23, 13, 1, 7, hairL);
    R(9, 13, 1, 7, hairD); R(22, 13, 1, 7, hairD);
    // a wisp of hair escaping past each shoulder
    R(7, 14, 1, 4, hair); M(7, 14, 1, 4, hair);
    // a fluffy pom tail peeking out above the skirt
    R(14, 18, 4, 1, pal.tail || hairL);
    R(13, 19, 6, 1, pal.tail || hairL);
    R(14, 20, 4, 1, pal.tail || hairL);
    R(15, 21, 2, 1, pal.tailShade || hairD);
    R(17, 18, 1, 1, pal.tailShade || hairD);
    R(16, 19, 1, 1, pal.tailShade || hairD);
    R(14, 18, 2, 1, hairL);
    R(13, 19, 1, 1, hairL);
    R(14, 19, 1, 1, hairL);
  } else {
    // hime-cut side locks tapering past the jaw
    R(8, 4, 2, 7, hair); M(8, 4, 2, 7, hair);
    R(8, 4, 1, 7, hairD); M(8, 4, 1, 7, hairD);
    R(9, 11, 2, 3, hair); M(9, 11, 2, 3, hair);
    R(9, 11, 1, 3, hairD); M(9, 11, 1, 3, hairD);
    R(10, 14, 1, 2, hair); M(10, 14, 1, 2, hair);
    // hair cap + broken top shine
    R(9, 3, 14, 3, hair);
    R(10, 3, 4, 1, hairL); R(18, 3, 4, 1, hairL);
    R(15, 4, 2, 1, hairL);
    R(9, 3, 1, 3, hairD); M(9, 3, 1, 3, hairD);
    R(12, 4, 1, 2, hairD); M(12, 4, 1, 2, hairD);
    // fringe: a solid row then tapered points
    R(10, 6, 12, 1, hair);
    R(11, 7, 3, 1, hair);
    R(14, 7, 4, 1, hair);
    R(18, 7, 3, 1, hair);
    R(13, 6, 1, 1, hairD); R(18, 6, 1, 1, hairD);
    // two big bright violets
    bunnyEye(p, pal, 11, 8 + b, lash, false);
    bunnyEye(p, pal, 11, 8 + b, lash, true);
    // blush + a small smile
    R(11, 12, 2, 1, pal.blush || trim);
    M(11, 12, 2, 1, pal.blush || trim);
    R(15, 12, 2, 1, pal.lip || pal.mouth || trim);
  }
  // choker — a deep-rose band hugging the throat, with a pale gem at the front
  R(14, 15, 4, 1, pal.mouth || pal.lip || trim);
  if (!back) R(15, 15, 2, 1, trimL);
  drawEarsFront(p, pal, b, true, bounce, back);
}

function drawBunnySide(p, pal, pose) {
  const b = pose.bob;
  const bounce = -b;
  const R = (x, y, w, h, c) => p.rect(x, y + b, w, h, c);
  const skin = pal.skin, skinD = pal.skinShade;
  const hair = pal.hair, hairD = pal.hairDark, hairL = pal.hairLight;
  const suit = pal.tunic, suitD = pal.tunicDark, suitL = pal.tunicLight;
  const trim = pal.belt;
  const lash = pal.eyeDeep || pal.eye;
  const tail = pal.tail || hairL;

  drawBunnyLeg(p, pal, 14, pose.rLeg, b, true);
  drawBunnyLeg(p, pal, 15, pose.lLeg, b, false);

  // bodice in profile
  R(12, 15, 8, 3, suit);
  R(13, 18, 6, 3, suit);
  R(12, 15, 1, 3, suitD);
  R(13, 18, 1, 3, suitD);
  R(19, 15, 1, 3, suitD);
  R(19, 18, 1, 3, suitD);
  R(18, 16, 2, 2, suitL);
  R(17, 16, 2, 1, trim);   // chest piping
  R(17, 17, 2, 1, trim);   // a hint of the bow from the side
  // flared skirt sweeping back off the hip, with a white lace hem
  R(12, 21, 8, 1, suit);
  R(11, 22, 10, 2, suit);
  R(11, 22, 1, 2, suitD);
  R(20, 22, 1, 2, suitD);
  R(17, 21, 3, 1, suitL);
  R(11, 24, 10, 1, pal.boot || pal.tunicLight);
  R(11, 25, 2, 1, pal.boot || pal.tunicLight);
  R(19, 25, 2, 1, pal.boot || pal.tunicLight);

  // near arm
  const ax = 14 + (pose.lArm.dx || 0);
  R(ax, 16, 3, 3, suit);
  R(ax, 19, 3, 3, skin);
  R(ax, 16, 1, 3, suitD);
  R(ax + 2, 19, 1, 3, skinD);
  R(ax, 18, 3, 1, trim);               // sleeve trim
  R(ax, 22, 3, 1, pal.mouth || trim);  // cuff
  R(ax, 22, 1, 1, trim);
  R(ax, 23, 3, 1, skin);

  // neck + head
  R(16, 14, 4, 1, skinD);
  R(10, 6, 12, 8, skin);
  R(10, 13, 12, 1, skinD);

  // long ponytail gathered at the nape, streaming down behind
  R(6, 9, 4, 3, hair);
  R(5, 12, 4, 5, hair);
  R(5, 17, 3, 3, hair);
  R(6, 20, 2, 1, hair);
  R(4, 12, 1, 8, hairD);    // trailing shadow edge
  R(7, 9, 1, 3, hairD);     // seam where the tail leaves the nape
  R(5, 13, 2, 4, hairL);    // sheen down the tail
  R(7, 20, 1, 1, hairD);    // tapered tip point

  // head hair + fringe over the brow
  R(9, 3, 13, 3, hair);
  R(10, 3, 4, 1, hairL); R(16, 3, 3, 1, hairL);
  R(8, 4, 4, 9, hair);
  R(8, 4, 1, 9, hairD);
  R(15, 6, 7, 2, hair);
  R(21, 6, 1, 4, hair);
  R(21, 6, 1, 1, hairD);
  R(13, 4, 1, 2, hairD);
  R(6, 9, 3, 2, trim);      // pink tie wrapping the base of the tail
  R(6, 10, 2, 1, pal.mouth || trim);
  R(6, 9, 1, 1, pal.buckle || trim);

  // profile face
  bunnyEyeSide(p, pal, 18, 8 + b, lash);
  R(22, 11, 1, 1, skin);   // nose tip
  R(19, 12, 2, 1, pal.mouth || pal.lip || trim);
  R(16, 12, 1, 1, pal.blush || trim);
  R(16, 14, 4, 1, trim);   // choker

  // fluffy pom tail on the hip
  R(9, 19, 3, 1, tail);
  R(8, 20, 4, 1, tail);
  R(8, 21, 4, 1, tail);
  R(9, 22, 2, 1, pal.tailShade || hairD);
  R(9, 20, 1, 1, hairL);

  drawEarsSide(p, pal, b, true, bounce);
}

// ---- signature kit renderer -----------------------------------------------
// Palettes carrying a `feat` object get extra gear drawn around the shared
// body. Back-layer gear (capes, hood shells, ponytails) draws before the body
// so the body sits on top of it; front-layer gear (hats, robes, pauldrons,
// halos, quivers) draws after it. `view` is "front" | "back" | "side": "back"
// is the away-facing front render (there is no face to frame), "side" the
// profile that faces +x and gets mirrored for the left-facing direction.
//
// Every helper receives the bob-aware rect writer R, so gear rides the same
// one-pixel idle/walk bob as the torso it hangs from.

// lighten/darken a hex colour by `amt` (-255..255), so a feature only needs one
// authored colour instead of a full shade set
function shade(hex, amt) {
  const c = rgb(hex);
  const h = (v) => Math.max(0, Math.min(255, Math.round(v + amt))).toString(16).padStart(2, "0");
  return "#" + h(c[0]) + h(c[1]) + h(c[2]);
}

// a cloak hanging behind the body: broad at the shoulders, flaring to a hem
// just above the boots, with a standing collar and two clasps at the throat
function featCapeBack(p, pal, R, view) {
  const f = pal.feat;
  const c = typeof f.cape === "string" ? f.cape : pal.tunic;
  const cd = f.capeDark || shade(c, -44);
  const cl = f.capeLight || shade(c, 36);
  const clasp = f.capeClasp || "#e0b74a";
  if (view === "side") {
    R(6, 13, 6, 14, c);
    R(5, 17, 2, 10, c);
    R(5, 25, 8, 2, cd);
    R(6, 13, 1, 13, cl);
    R(10, 13, 1, 13, cd);
    R(12, 13, 2, 2, clasp);
    return;
  }
  R(6, 13, 20, 13, c);
  R(5, 21, 22, 6, c);
  R(5, 26, 22, 1, cd);
  R(6, 13, 2, 13, cl);
  R(23, 13, 2, 13, cd);
  R(12, 11, 8, 3, c);
  R(12, 11, 8, 1, cl);
  R(9, 13, 3, 2, clasp);
  R(20, 13, 3, 2, clasp);
}

// from behind, the cloak hides the whole back rather than just peeking out
function featCapeBackCover(p, pal, R) {
  const f = pal.feat;
  const c = typeof f.cape === "string" ? f.cape : pal.tunic;
  const cd = f.capeDark || shade(c, -44);
  const cl = f.capeLight || shade(c, 36);
  R(7, 14, 18, 13, c);
  R(6, 22, 20, 5, c);
  R(6, 27, 20, 1, cd);
  R(7, 14, 2, 13, cl);
  R(23, 14, 2, 13, cd);
  R(11, 22, 1, 5, cd);
  R(15, 24, 2, 4, cd);
  R(20, 22, 1, 5, cd);
  R(12, 11, 8, 3, c);
  R(12, 11, 8, 1, cl);
}

// an arrow quiver slung over the right shoulder, fletchings poking up
function featQuiver(p, pal, R, view) {
  const f = pal.feat;
  const body = f.quiver === true ? "#6a4a2a" : f.quiver;
  const bd = shade(body, -34);
  const shaft = f.quiverShaft || "#c9a86a";
  const fl = f.quiverFletch || "#e2dcc8";
  if (view === "side") {
    R(6, 9, 3, 10, body);
    R(6, 9, 1, 10, bd);
    R(7, 4, 1, 5, shaft);
    R(9, 3, 1, 5, shaft);
    R(7, 3, 1, 2, fl);
    R(9, 2, 1, 2, fl);
    return;
  }
  R(22, 8, 4, 11, body);
  R(24, 8, 2, 11, bd);
  R(23, 3, 1, 6, shaft);
  R(25, 2, 1, 6, shaft);
  R(23, 2, 1, 2, fl);
  R(25, 1, 1, 2, fl);
}

// long hair gathered at the nape and hanging past the shoulder
function featPonytail(p, pal, R, view) {
  const f = pal.feat;
  const hair = f.ponytailColor || pal.hair;
  const hd = pal.hairDark || shade(hair, -36);
  const hl = pal.hairLight || shade(hair, 40);
  const tie = f.ponytailTie || pal.belt;
  if (view === "side") {
    R(6, 6, 4, 3, hair);
    R(5, 9, 3, 6, hair);
    R(5, 15, 2, 6, hair);
    R(5, 21, 1, 3, hd);
    R(7, 6, 1, 2, hl);
    R(7, 5, 4, 1, tie);
    return;
  }
  R(21, 5, 2, 4, hair);
  R(22, 9, 2, 5, hair);
  R(23, 14, 1, 4, hair);
  R(23, 18, 1, 2, hd);
  R(21, 5, 2, 1, tie);
  R(21, 6, 1, 3, hl);
}

// the hood's shell: a head-shaped blob behind everything, so the head and face
// punch a hole in it and the cowl reads as framing rather than a pasted lid
function featHoodShell(p, pal, R, view) {
  const c = pal.feat.hoodColor || pal.tunic;
  if (view === "side") {
    R(8, 3, 13, 11, c);
    R(8, 12, 14, 5, c);
    return;
  }
  R(9, 3, 14, 11, c);
  R(8, 12, 16, 5, c);
}

function featHoodFront(p, pal, R, view) {
  const f = pal.feat;
  const c = f.hoodColor || pal.tunic;
  const cd = f.hoodDark || pal.tunicDark || shade(c, -40);
  const cl = f.hoodLight || pal.tunicLight || shade(c, 34);
  const peak = f.hoodPeak;
  // a hood whose crown sits one row lower leaves room for a halo to hover above
  const top = f.hoodLow ? 4 : 3;
  const win = top + 3;
  if (view === "side") {
    R(8, top + 1, 8, 12 - top, c);
    R(9, top, 12, 3, c);
    R(19, top + 1, 3, 3, c);
    R(8, 13, 13, 4, c);
    R(8, top + 1, 1, 12 - top, cl);
    R(15, top, 1, 13 - top, cd);
    R(9, top, 10, 1, cl);
    if (peak) { R(11, top - 2, 6, 1, c); R(10, top - 1, 9, 1, c); R(12, top - 2, 4, 1, cl); }
    return;
  }
  R(9, top, 14, 3, c);
  R(8, 13, 16, 4, c);
  if (view === "back") R(9, win, 14, 13 - win, c);
  else { R(9, win, 3, 13 - win, c); R(20, win, 3, 13 - win, c); }
  R(9, top, 1, 13 - top, cl);
  R(21, top, 2, 13 - top, cd);
  R(9, top, 8, 1, cl);
  R(8, 13, 16, 1, cl);
  R(8, 13, 1, 4, cd);
  R(23, 13, 1, 4, cd);
  if (peak) { R(13, top - 2, 6, 1, c); R(12, top - 1, 8, 1, cl); }
  if (f.hoodDeep && view !== "back") {
    R(12, win, 8, 13 - win, "#0a0712");
    R(13, 9, 2, 2, pal.eye);
    R(17, 9, 2, 2, pal.eye);
    if (pal.eyeLight) { R(13, 9, 1, 1, pal.eyeLight); R(17, 9, 1, 1, pal.eyeLight); }
  }
}

// headwear. Each kind is a small silhouette built over the hair cap (y4-6) and
// the top of the skull; the face window stays open so the eyes always read.
function featHat(p, pal, R, view) {
  const f = pal.feat;
  const kind = f.hat;
  const base = f.hatColor || pal.tunic;
  const bd = f.hatDark || shade(base, -42);
  const bl = f.hatLight || shade(base, 36);

  if (kind === "bandana") {
    const c = f.bandana || pal.belt;
    const cdk = shade(c, -40), cbl = shade(c, 32);
    if (view === "side") {
      R(10, 5, 12, 2, c);
      R(10, 5, 12, 1, cbl);
      R(7, 6, 3, 2, c);
      R(6, 9, 2, 4, c);
      R(6, 13, 1, 2, cdk);
      return;
    }
    R(10, 5, 12, 2, c);
    R(10, 5, 12, 1, cbl);
    R(8, 5, 3, 2, c);
    R(8, 6, 2, 1, cdk);
    R(8, 7, 2, 3, c);
    R(7, 10, 2, 3, c);
    R(7, 13, 1, 2, cdk);
    return;
  }

  if (kind === "cap") {
    R(11, 3, 10, 4, base);
    R(13, 2, 6, 1, base);
    R(11, 3, 10, 1, bl);
    R(11, 6, 10, 1, bd);
    R(9, 6, 2, 1, base);
    R(21, 6, 2, 1, base);
    return;
  }

  if (kind === "feathercap") {
    const fc = f.feather || "#e8b64a";
    R(10, 3, 12, 4, base);
    R(12, 2, 8, 1, base);
    R(10, 3, 12, 1, bl);
    R(10, 6, 12, 1, bd);
    const fcd = shade(fc, -40);
    if (view === "side") {
      R(9, 4, 1, 3, fc);
      R(8, 3, 1, 3, fc);
      R(7, 2, 1, 3, fc);
      R(7, 2, 1, 1, fcd);
    } else {
      R(21, 4, 1, 3, fc);
      R(22, 3, 1, 3, fc);
      R(23, 2, 1, 3, fc);
      R(23, 2, 1, 1, fcd);
    }
    return;
  }

  if (kind === "cowboy") {
    const band = f.hatBand || "#3a2a1a";
    R(10, 2, 12, 4, base);
    R(12, 1, 8, 1, base);
    R(10, 2, 12, 1, bl);
    R(10, 4, 12, 1, band);
    R(15, 1, 2, 1, bd);
    R(6, 6, 20, 2, base);
    R(6, 7, 20, 1, bd);
    R(7, 5, 2, 2, base);
    R(23, 5, 2, 2, base);
    R(7, 5, 1, 1, bl);
    R(23, 5, 1, 1, bl);
    return;
  }

  if (kind === "witch") {
    const band = f.hatBand || "#4a3a6a";
    R(19, 1, 2, 1, base);
    R(16, 2, 4, 1, base);
    R(13, 3, 7, 1, base);
    R(10, 4, 12, 1, base);
    R(10, 4, 4, 1, bl);
    R(21, 1, 1, 4, bd);
    R(11, 5, 10, 1, band);
    R(15, 5, 2, 1, f.hatBuckle || "#e0b74a");
    R(7, 6, 18, 2, base);
    R(7, 7, 18, 1, bd);
    R(7, 6, 18, 1, bl);
    R(7, 6, 2, 2, bd);
    R(23, 6, 2, 2, bd);
    return;
  }

  if (kind === "crown") {
    const g = f.crown || "#e8c766";
    const gd = f.crownDark || shade(g, -48);
    const gl = f.crownLight || shade(g, 40);
    R(10, 4, 12, 2, g);
    R(10, 4, 12, 1, gl);
    R(10, 2, 3, 2, g);
    R(14, 1, 4, 3, g);
    R(19, 2, 3, 2, g);
    R(15, 1, 2, 1, f.crownGem || "#d8354a");
    R(10, 2, 1, 2, gd);
    R(12, 2, 1, 2, gd);
    R(14, 1, 1, 3, gd);
    R(17, 1, 1, 3, gd);
    R(19, 2, 1, 2, gd);
    R(21, 2, 1, 2, gd);
    return;
  }

  if (kind === "helm") {
    const mt = f.metal || "#9aa4bb";
    const md = f.metalDark || shade(mt, -44);
    const ml = f.metalLight || shade(mt, 40);
    const pl = f.plume || "#c0392b";
    if (view === "side") {
      R(9, 3, 8, 11, mt);
      R(10, 2, 11, 2, mt);
      R(17, 5, 1, 6, md);
      R(17, 11, 5, 3, mt);
      R(9, 3, 1, 11, md);
      R(10, 2, 11, 1, ml);
      R(13, 1, 4, 2, pl);
      R(11, 2, 3, 2, pl);
      return;
    }
    R(9, 2, 14, 3, mt);
    R(10, 4, 12, 3, mt);
    if (view === "back") {
      R(9, 4, 14, 10, mt);
      R(15, 7, 2, 6, md);
    } else {
      R(9, 5, 3, 9, mt);
      R(20, 5, 3, 9, mt);
      R(15, 6, 2, 6, md);
      R(15, 6, 1, 6, mt);
    }
    R(9, 2, 1, 12, md);
    R(22, 2, 1, 12, md);
    R(10, 2, 12, 1, ml);
    R(15, 1, 2, 1, pl);
    R(14, 2, 4, 1, pl);
    R(16, 3, 2, 1, pl);
    return;
  }
}

// a full-length robe: a V of vestment over the chest plus a flared skirt that
// stops short of the boots. `robeOpen` keeps the tunic showing between two
// hanging front panels (a haori), so the belt and tunic colour still read.
function featRobe(p, pal, R, view) {
  const f = pal.feat;
  const c = typeof f.robe === "string" ? f.robe : pal.tunic;
  const cd = f.robeDark || shade(c, -44);
  const cl = f.robeLight || shade(c, 34);
  const open = f.robeOpen;
  if (view === "side") {
    R(13, 15, 5, 2, c);
    if (!open) {
      R(12, 15, 2, 4, c);
      R(13, 17, 2, 3, c);
      R(12, 15, 1, 5, cd);
    }
    R(11, 23, 9, 1, c);
    R(10, 24, 11, 1, c);
    R(9, 25, 13, 1, c);
    R(8, 26, 15, 1, c);
    R(8, 27, 15, 1, cd);
    R(13, 24, 1, 3, cd);
    R(9, 24, 1, 3, cl);
    return;
  }
  if (view === "back") {
    R(11, 15, 10, 8, c);
    R(11, 15, 10, 1, cl);
    R(11, 15, 1, 8, cd);
    R(20, 15, 1, 8, cd);
  } else if (open) {
    R(9, 15, 4, 8, c);
    R(19, 15, 4, 8, c);
    R(12, 15, 1, 8, cd);
    R(19, 15, 1, 8, cd);
    R(9, 15, 4, 1, cl);
    R(19, 15, 4, 1, cl);
  } else {
    R(12, 15, 2, 3, c);
    R(18, 15, 2, 3, c);
    R(13, 17, 1, 3, c);
    R(18, 17, 1, 3, c);
    R(14, 19, 2, 4, c);
    R(16, 19, 2, 4, c);
    R(12, 15, 1, 7, cd);
    R(19, 15, 1, 7, cd);
    R(12, 15, 1, 1, cl);
  }
  R(10, 23, 12, 1, c);
  R(9, 24, 14, 1, c);
  R(8, 25, 16, 1, c);
  R(7, 26, 18, 1, c);
  R(7, 27, 18, 1, cd);
  R(10, 23, 12, 1, cl);
  R(11, 24, 1, 3, cd);
  R(20, 24, 1, 3, cd);
  R(15, 25, 2, 3, cd);
  R(13, 24, 1, 3, cl);
  R(18, 24, 1, 3, cl);
}

// bolted-on shoulder plates, sized past the arms so they widen the silhouette
function featPauldrons(p, pal, R, view) {
  const f = pal.feat;
  const mt = typeof f.pauldrons === "string" ? f.pauldrons : (f.metal || "#9aa4bb");
  const md = f.pauldronDark || shade(mt, -44);
  const ml = f.pauldronLight || shade(mt, 38);
  if (view === "side") {
    R(12, 14, 5, 3, mt);
    R(12, 14, 5, 1, ml);
    R(12, 16, 5, 1, md);
    if (f.pauldronSpikes) R(13, 12, 1, 2, ml);
    return;
  }
  R(8, 14, 4, 3, mt);
  R(20, 14, 4, 3, mt);
  R(8, 14, 4, 1, ml);
  R(20, 14, 4, 1, ml);
  R(8, 16, 4, 1, md);
  R(20, 16, 4, 1, md);
  R(8, 14, 1, 3, md);
  R(23, 14, 1, 3, md);
  if (f.pauldronSpikes) {
    R(9, 12, 1, 2, ml);
    R(11, 13, 1, 1, ml);
    R(21, 12, 1, 2, ml);
    R(20, 13, 1, 1, ml);
  }
}

// a muffler round the neck with a loose end trailing past the shoulder
function featScarf(p, pal, R, view) {
  const f = pal.feat;
  const c = typeof f.scarf === "string" ? f.scarf : pal.tunicLight;
  const cd = f.scarfDark || shade(c, -42);
  const cl = f.scarfLight || shade(c, 36);
  if (view === "side") {
    R(12, 14, 8, 2, c);
    R(12, 14, 8, 1, cl);
    R(8, 15, 3, 7, c);
    R(8, 21, 3, 2, cd);
    return;
  }
  R(11, 14, 10, 2, c);
  R(11, 14, 10, 1, cl);
  if (view === "back") {
    R(11, 16, 3, 2, c);
    R(11, 18, 2, 3, c);
    R(11, 21, 1, 1, cd);
    R(11, 16, 1, 5, cl);
  } else {
    R(19, 16, 3, 2, c);
    R(20, 18, 2, 3, c);
    R(21, 21, 1, 1, cd);
    R(19, 16, 1, 5, cl);
  }
}

// a cloth half-mask over the mouth and jaw
function featMask(p, pal, R, view) {
  if (view === "back") return;
  const f = pal.feat;
  const c = typeof f.mask === "string" ? f.mask : (pal.tunicDark || "#2a2a33");
  const cd = shade(c, -34);
  const cl = shade(c, 30);
  if (view === "side") {
    R(16, 11, 5, 3, c);
    R(16, 11, 5, 1, cl);
    R(16, 13, 5, 1, cd);
    return;
  }
  R(11, 11, 10, 3, c);
  R(11, 11, 10, 1, cl);
  R(11, 13, 10, 1, cd);
}

// a full beard flowing off the jaw onto the chest
function featBeard(p, pal, R, view) {
  if (view === "back") return;
  const hair = pal.feat.beardColor || pal.hair;
  const hd = pal.hairDark || shade(hair, -36);
  if (view === "side") {
    R(15, 12, 5, 3, hair);
    R(16, 11, 2, 1, hair);
    R(15, 14, 4, 1, hd);
    return;
  }
  R(12, 12, 8, 1, hair);
  R(13, 13, 6, 1, hair);
  R(14, 14, 4, 1, hd);
  R(13, 11, 1, 1, hair);
  R(18, 11, 1, 1, hair);
  R(12, 12, 1, 2, hd);
  R(19, 12, 1, 2, hd);
}

// a belt strap over one shoulder with a pouch hanging at the opposite hip
function featSatchel(p, pal, R, view) {
  const f = pal.feat;
  const c = typeof f.satchel === "string" ? f.satchel : "#6a4a2a";
  const cd = f.satchelDark || shade(c, -40);
  const cl = shade(c, 32);
  const bk = f.satchelBuckle || "#e0b74a";
  if (view === "side") {
    R(14, 15, 4, 2, c);
    R(14, 15, 4, 1, cl);
    R(6, 21, 5, 5, c);
    R(6, 21, 5, 1, cd);
    R(6, 24, 5, 1, bk);
    return;
  }
  R(18, 15, 2, 2, c);
  R(16, 16, 2, 2, c);
  R(14, 17, 2, 2, c);
  R(12, 18, 2, 2, c);
  R(11, 19, 2, 4, c);
  R(11, 19, 1, 4, cl);
  R(6, 22, 5, 5, c);
  R(6, 22, 5, 1, cd);
  R(6, 25, 5, 1, bk);
  R(9, 22, 1, 5, cd);
}

// antlers branching off the crown
function featAntlers(p, pal, R, view) {
  const c = typeof pal.feat.antlers === "string" ? pal.feat.antlers : "#c9b06a";
  const cd = shade(c, -40);
  const cl = shade(c, 36);
  if (view === "side") {
    R(13, 2, 1, 4, c);
    R(11, 2, 2, 1, c);
    R(11, 1, 1, 1, c);
    R(15, 3, 1, 2, c);
    R(11, 1, 1, 1, cd);
    R(13, 2, 1, 1, cl);
    return;
  }
  R(11, 2, 1, 4, c);
  R(9, 2, 2, 1, c);
  R(9, 1, 1, 1, c);
  R(12, 4, 1, 1, c);
  R(20, 2, 1, 4, c);
  R(21, 2, 2, 1, c);
  R(22, 1, 1, 1, c);
  R(19, 4, 1, 1, c);
  R(9, 1, 1, 1, cd);
  R(22, 1, 1, 1, cd);
  R(11, 2, 1, 1, cl);
}

// a ring of light hovering over the crown
function featHalo(p, pal, R, view) {
  const c = typeof pal.feat.halo === "string" ? pal.feat.halo : "#f5e06a";
  const cl = shade(c, 42);
  const cd = shade(c, -40);
  if (view === "side") {
    R(12, 1, 8, 1, c);
    R(13, 1, 6, 1, cl);
    R(11, 2, 2, 1, c);
    R(19, 2, 2, 1, c);
    return;
  }
  R(10, 1, 12, 1, c);
  R(12, 1, 8, 1, cl);
  R(10, 2, 1, 1, c);
  R(21, 2, 1, 1, c);
}

// hair shapes that break the shared helmet-of-hair silhouette
function featHairStyle(p, pal, R, view) {
  const f = pal.feat;
  const hair = f.hairColor || pal.hair;
  const hd = pal.hairDark || shade(hair, -34);
  const hl = pal.hairLight || shade(hair, 40);
  if (f.hairStyle === "spiky") {
    if (view === "side") {
      R(11, 3, 2, 1, hair);
      R(13, 2, 3, 1, hair);
      R(16, 3, 3, 1, hair);
      R(19, 2, 2, 1, hair);
      R(13, 2, 1, 1, hl);
      R(16, 3, 1, 1, hd);
      return;
    }
    R(11, 3, 2, 1, hair);
    R(13, 3, 1, 1, hd);
    R(14, 2, 2, 1, hair);
    R(16, 1, 2, 1, hair);
    R(18, 3, 2, 1, hair);
    R(14, 2, 1, 1, hl);
    return;
  }
  if (f.hairStyle === "topknot") {
    const tie = f.topknotTie || pal.belt;
    R(14, 2, 4, 2, hair);
    R(15, 1, 2, 1, hair);
    R(14, 2, 2, 1, hl);
    R(14, 4, 4, 1, tie);
  }
}

function drawFeatBack(p, pal, b, view) {
  const f = pal.feat;
  if (!f) return;
  const R = (x, y, w, h, c) => p.rect(x, y + b, w, h, c);
  if (f.cape) featCapeBack(p, pal, R, view);
  if (f.hood) featHoodShell(p, pal, R, view);
  if (f.hairStyle === "ponytail") featPonytail(p, pal, R, view);
}

function drawFeatFront(p, pal, b, view) {
  const f = pal.feat;
  if (!f) return;
  const R = (x, y, w, h, c) => p.rect(x, y + b, w, h, c);
  if (f.hairStyle) featHairStyle(p, pal, R, view);
  if (f.robe) featRobe(p, pal, R, view);
  if (f.scarf) featScarf(p, pal, R, view);
  if (f.mask) featMask(p, pal, R, view);
  if (f.beard) featBeard(p, pal, R, view);
  if (f.satchel) featSatchel(p, pal, R, view);
  if (f.antlers) featAntlers(p, pal, R, view);
  if (f.pauldrons) featPauldrons(p, pal, R, view);
  if (f.hood) featHoodFront(p, pal, R, view);
  if (f.quiver) featQuiver(p, pal, R, view);
  if (f.hat) featHat(p, pal, R, view);
  if (f.cape && view === "back") featCapeBackCover(p, pal, R);
  if (f.halo) featHalo(p, pal, R, view);
}

function drawFront(p, pal, pose, back) {
  const b = pose.bob;
  const view = back ? "back" : "front";
  drawFeatBack(p, pal, b, view);
  drawLeg(p, pal, 12, 3, pose.lLeg, pal, b, "l");
  drawLeg(p, pal, 17, 3, pose.rLeg, pal, b, "r");
  const R = (x, y, w, h, c) => p.rect(x, y + b, w, h, c);
  // torso
  R(11, 15, 10, 9, pal.tunic);
  R(11, 15, 10, 1, pal.tunicLight);
  R(11, 15, 1, 9, pal.tunicDark);
  R(20, 15, 1, 9, pal.tunicDark);
  R(14, 16, 4, 1, pal.tunicLight);
  // belt
  R(11, 22, 10, 2, pal.belt);
  R(15, 22, 2, 2, pal.buckle);
  if (pal.skirt) drawSkirtFront(p, pal, b, back);
  // arms
  drawArmFront(p, pal, 9, 16 + b, pose.lArm, "l");
  drawArmFront(p, pal, 21, 16 + b, pose.rArm, "r");
  // neck + head
  R(14, 14, 4, 1, pal.skinShade);
  R(11, 7, 10, 7, pal.skin);
  R(11, 13, 10, 1, pal.skinShade);
  if (back) {
    R(11, 4, 10, 9, pal.hair);
    R(10, 5, 1, 8, pal.hair);
    R(21, 5, 1, 8, pal.hair);
    R(11, 4, 10, 1, pal.hairLight);
    R(11, 10, 10, 3, pal.hairDark);
    if (pal.tail) {
      R(14, 22, 4, 3, pal.tail);
      R(15, 22, 2, 1, pal.hairLight || pal.tail);
    }
    if (pal.longHair) {
      R(10, 3, 12, 2, pal.hair);
      R(11, 3, 10, 1, pal.hairLight);
      R(10, 5, 1, 17, pal.hair);
      R(21, 5, 1, 17, pal.hair);
      R(10, 20, 1, 4, pal.hairDark);
      R(21, 20, 1, 4, pal.hairDark);
      R(8, 8, 2, 9, pal.hair);
      R(8, 15, 2, 4, pal.hairDark);
    }
  } else {
    R(11, 4, 10, 3, pal.hair);
    R(10, 5, 1, 4, pal.hair);
    R(21, 5, 1, 4, pal.hair);
    R(11, 4, 10, 1, pal.hairLight);
    R(11, 6, 10, 1, pal.hair);
    R(11, 7, 1, 6, pal.skinShade);
    R(20, 7, 1, 6, pal.skinShade);
    R(12, 8, 2, 1, pal.hairDark);
    R(18, 8, 2, 1, pal.hairDark);
    R(13, 9, 2, 2, pal.eye);
    R(17, 9, 2, 2, pal.eye);
    if (pal.eyeLight) { R(13, 9, 1, 1, pal.eyeLight); R(17, 9, 1, 1, pal.eyeLight); }
    R(15, 11, 2, 1, pal.mouth || pal.skinShade);
    if (pal.longHair) {
      R(10, 3, 12, 2, pal.hair);
      R(11, 3, 10, 1, pal.hairLight);
      R(9, 6, 2, 15, pal.hair);
      R(21, 6, 2, 15, pal.hair);
      R(9, 19, 2, 4, pal.hairDark);
      R(21, 19, 2, 4, pal.hairDark);
      R(9, 6, 1, 12, pal.hairLight);
    }
  }
  drawFeatFront(p, pal, b, view);
  drawEarsFront(p, pal, b);
}

function drawSide(p, pal, pose) {
  const b = pose.bob;
  drawFeatBack(p, pal, b, "side");
  // far leg peeks 1px behind the near leg so both read at every pose
  drawLeg(p, pal, 14, 3, pose.rLeg, { pants: pal.pantsDark, boot: pal.bootDark }, b, "l");
  drawLeg(p, pal, 15, 3, pose.lLeg, pal, b, "l");
  const R = (x, y, w, h, c) => p.rect(x, y + b, w, h, c);
  // torso
  R(12, 15, 8, 9, pal.tunic);
  R(12, 15, 8, 1, pal.tunicLight);
  R(12, 15, 1, 9, pal.tunicDark);
  R(19, 15, 1, 9, pal.tunicDark);
  R(12, 22, 8, 2, pal.belt);
  R(17, 22, 2, 2, pal.buckle);
  if (pal.skirt) drawSkirtSide(p, pal, b);
  // near arm
  const ax = 14 + pose.lArm.dx;
  R(ax, 16, 3, 4, pal.tunic);
  R(ax, 20, 3, 3, pal.skin);
  R(ax, 16, 1, 4, pal.tunicDark);
  R(ax + 1, 16, 1, 1, pal.tunicLight);
  // neck + head (profile facing +x)
  R(14, 14, 4, 1, pal.skinShade);
  R(11, 7, 10, 7, pal.skin);
  R(11, 13, 10, 1, pal.skinShade);
  R(10, 4, 11, 3, pal.hair);
  R(10, 4, 10, 1, pal.hairLight);
  R(10, 5, 4, 8, pal.hair);
  R(16, 6, 5, 1, pal.hair);
  R(11, 4, 1, 3, pal.hairDark);
  R(18, 9, 2, 2, pal.eye);
  if (pal.eyeLight) R(18, 9, 1, 1, pal.eyeLight);
  R(21, 10, 1, 2, pal.skinShade);
  if (pal.longHair) {
    R(10, 3, 11, 2, pal.hair);
    R(10, 3, 10, 1, pal.hairLight);
    R(9, 5, 5, 17, pal.hair);
    R(9, 5, 1, 17, pal.hairLight);
    R(9, 19, 5, 4, pal.hairDark);
    R(14, 12, 2, 8, pal.hair);
    R(19, 12, 1, 5, pal.hair);
  }
  drawFeatFront(p, pal, b, "side");
  drawEarsSide(p, pal, b);
}

export function renderFrame({ palette = PALETTES.hero, dir = "down", anim = "idle", frame = 0 } = {}) {
  const pal = palette;
  const pose = poseFor(anim, frame, dir);
  const p = new Pix(FRAME_W, FRAME_H);
  const front = pal.bunny ? drawBunnyFront : drawFront;
  const profile = pal.bunny ? drawBunnySide : drawSide;
  if (dir === "down") front(p, pal, pose, false);
  else if (dir === "up") front(p, pal, pose, true);
  else if (dir === "right") profile(p, pal, pose);
  else {
    const side = new Pix(FRAME_W, FRAME_H);
    profile(side, pal, pose);
    p.d.set(side.flipX().d);
  }
  p.outline(pal.outline);
  return p;
}

export function frameCount(anim) {
  if (anim === "idle") return IDLE_FRAMES;
  if (anim === "dash") return DASH_FRAMES;
  if (anim === "attack") return ATTACK_FRAMES;
  return WALK_FRAMES;
}

// Builds a sheet: one row per (anim, direction), columns = frames.
export function buildSpriteSheet({ palette = PALETTES.hero, scale = 1 } = {}) {
  const rows = [];
  for (const anim of ANIMS) {
    for (const dir of DIRECTIONS) rows.push({ anim, dir });
  }
  const cols = Math.max(IDLE_FRAMES, WALK_FRAMES, DASH_FRAMES, ATTACK_FRAMES);
  const cellW = FRAME_W * scale;
  const cellH = FRAME_H * scale;
  const canvas = document.createElement("canvas");
  canvas.width = cols * cellW;
  canvas.height = rows.length * cellH;
  const ctx = canvas.getContext("2d");
  ctx.imageSmoothingEnabled = false;
  const index = {};
  for (let r = 0; r < rows.length; r++) {
    const { anim, dir } = rows[r];
    const n = frameCount(anim);
    index[`${anim}_${dir}`] = { row: r, frames: n };
    for (let f = 0; f < n; f++) {
      const pix = renderFrame({ palette, dir, anim, frame: f });
      const fc = pix.toCanvas();
      ctx.drawImage(fc, 0, 0, FRAME_W, FRAME_H, f * cellW, r * cellH, cellW, cellH);
    }
  }
  return { canvas, rows, cellW, cellH, cols, index };
}

// Cached per-frame canvases for scene drawing: [anim][dir][frame] -> canvas
export function buildFrameCanvases({ palette = PALETTES.hero } = {}) {
  const out = {};
  for (const anim of ANIMS) {
    out[anim] = {};
    for (const dir of DIRECTIONS) {
      const n = frameCount(anim);
      out[anim][dir] = [];
      for (let f = 0; f < n; f++) out[anim][dir].push(renderFrame({ palette, dir, anim, frame: f }).toCanvas());
    }
  }
  return out;
}

// ---- monsters -------------------------------------------------------------
// Procedurally drawn enemies for the wave-survival game: squishy "slime"s,
// floating "wisp"s, robed "caster"s (ranged) and floating "eye"s (ranged).
// Same 32x32 grid and outline pass as the characters, so they sit consistently
// in the world.

export const MONSTER_FRAMES = 4;

export const MONSTERS = {
  slimeGreen: {
    type: "slime", glow: "#9ce68f",
    palette: { body: "#5fbf5f", dark: "#33793a", light: "#9ce68f", eye: "#122010", glint: "#efffe8", outline: "#12200f" },
  },
  slimeBlue: {
    type: "slime", glow: "#8fd6f5",
    palette: { body: "#5aa8d8", dark: "#2f6f96", light: "#a4e2fb", eye: "#0d1c26", glint: "#eaf8ff", outline: "#0d1a24" },
  },
  slimePurple: {
    type: "slime", glow: "#c9a8f5",
    palette: { body: "#9a72d6", dark: "#5d3f96", light: "#c9a8f5", eye: "#1a1030", glint: "#f6f0ff", outline: "#181030" },
  },
  slimeRed: {
    type: "slime", glow: "#f5a294",
    palette: { body: "#d9605a", dark: "#932f2c", light: "#f5a294", eye: "#2a0f0f", glint: "#fff0ee", outline: "#2a0e0c" },
  },
  wispBlue: {
    type: "wisp", glow: "#a8e6ff",
    palette: { body: "#7fd4ff", dark: "#2f7fb8", light: "#dcf6ff", eye: "#0d2233", glint: "#ffffff", outline: "#0b1d2b" },
  },
  wispPink: {
    type: "wisp", glow: "#ffc2e4",
    palette: { body: "#ff9ad2", dark: "#b8568f", light: "#ffe0f2", eye: "#331020", glint: "#ffffff", outline: "#2c0d20" },
  },
  casterRed: {
    type: "caster", glow: "#ff9a7a",
    palette: {
      robe: "#c05a4a", robeDark: "#7d2f28", robeLight: "#ef8f78",
      trim: "#f2c96a", eye: "#ffe9b0", orb: "#ffb06a", orbGlow: "#fff0d0", outline: "#2a0e0c",
    },
  },
  casterPurple: {
    type: "caster", glow: "#c9a8f5",
    palette: {
      robe: "#7a52b8", robeDark: "#452c74", robeLight: "#a982e0",
      trim: "#d9c2f5", eye: "#f2e0ff", orb: "#c9a8f5", orbGlow: "#f6f0ff", outline: "#1a1030",
    },
  },
  eyeBlue: {
    type: "eye", glow: "#a8e6ff",
    palette: {
      sclera: "#e2f4ff", lid: "#a8cfe6", body: "#4f9fd8", dark: "#2f6f96",
      pupil: "#0b1a26", glint: "#ffffff", outline: "#0b1d2b",
    },
  },
  eyeGold: {
    type: "eye", glow: "#ffd98a",
    palette: {
      sclera: "#fff6de", lid: "#e8cd8a", body: "#dda63a", dark: "#8f6516",
      pupil: "#241a06", glint: "#ffffff", outline: "#241a06",
    },
  },
  // wave-boss: a hulking horned demon lord (drawn at 2x in the game)
  demonLord: {
    type: "demon", glow: "#ff7a9a",
    palette: {
      body: "#7a3a6a", dark: "#47203f", light: "#c06aa0",
      horn: "#e8d8b0", trim: "#f2c96a", cloakDark: "#2a1226",
      eye: "#ff4a6a", eyeGlow: "#ffd0d8", outline: "#1a0814",
    },
  },
  // hulking ogre brute: slow, tough, and wind-up charges with a spiked club
  brute: {
    type: "brute", glow: "#b8d86a",
    palette: {
      body: "#6a7a52", dark: "#3f4a2e", light: "#9cb074",
      horn: "#e8dcc0", club: "#8a6a3a", eye: "#ff8a3a", eyeGlow: "#ffe0a0",
      outline: "#181d10",
    },
  },
  // wraith reaper: a fast hooded scythe-bearer that blinks into a dash
  reaper: {
    type: "reaper", glow: "#8ce6ff",
    palette: {
      robe: "#3a2a4a", robeDark: "#1c1230", hood: "#503a6a",
      blade: "#c9d2e2", bladeGlow: "#8ce6ff", eye: "#6ce6ff", glow2: "#ffffff",
      outline: "#0a0612",
    },
  },
  // bone warlock: a spellcaster that looses three-shot fans (caster body)
  warlock: {
    type: "caster", glow: "#9ce68f",
    palette: {
      robe: "#5a7a4a", robeDark: "#33472a", robeLight: "#83a86a",
      trim: "#d8cfa0", eye: "#c9ff9a", orb: "#9ce68f", orbGlow: "#eaffe0", outline: "#141a0c",
    },
  },
  // crimson eye: a fast, hard-hitting flying shooter (eye body)
  eyeRed: {
    type: "eye", glow: "#ff9a8a",
    palette: {
      sclera: "#ffdcd6", lid: "#e6a89a", body: "#d84a3a", dark: "#9a2f24",
      pupil: "#2a0a06", glint: "#ffffff", outline: "#2a0a06",
    },
  },
  // second wave-boss: a floating crowned lich (drawn at 2x in the game)
  lich: {
    type: "lich", glow: "#8ce6d0",
    palette: {
      robe: "#2a2050", robeDark: "#160f30", robeLight: "#4a3a80",
      trim: "#c9b06a", bone: "#e8e2d0", boneLight: "#fbf8ee", boneDark: "#b3a98e",
      eye: "#7cf0c0", orb: "#8ce6d0", orbGlow: "#eafff6", outline: "#0a0812",
    },
  },
  // ---- Hollow Caverns ----
  // crystal slime: a glassy teal slime that shatters light
  slimeCrystal: {
    type: "slime", glow: "#9cf5e6",
    palette: { body: "#5ad6c0", dark: "#2f8f80", light: "#9cf5e6", eye: "#08201c", glint: "#eafffb", outline: "#07201b" },
  },
  // the cave boss: a hulking stone golem warden (drawn at 2x)
  stoneWarden: {
    type: "brute", glow: "#7ae6ff",
    palette: {
      body: "#7a7f86", dark: "#464b52", light: "#a8aeb6",
      horn: "#d8dbe0", club: "#5a5f66", eye: "#7ae6ff", eyeGlow: "#d0f6ff",
      outline: "#1a1e24",
    },
  },
  // ---- Ashen Hellscape ----
  // ash demon: a soot-black demon wreathed in embers (demon body)
  demonAsh: {
    type: "demon", glow: "#ff7a3a",
    palette: {
      body: "#4a3a48", dark: "#2a1f2c", light: "#7a5a68",
      horn: "#d8c8a8", trim: "#ff7a3a", cloakDark: "#160f16",
      eye: "#ff5a2a", eyeGlow: "#ffd0a0", outline: "#0e0810",
    },
  },
  // ---- Celestia ----
  // golden wisp: a radiant mote of light
  wispGold: {
    type: "wisp", glow: "#fff2c2",
    palette: { body: "#ffd76a", dark: "#b8862a", light: "#fff2c2", eye: "#2a1e05", glint: "#ffffff", outline: "#2a1e05" },
  },
  // radiant reaper: a white-robed seraphic blade-bearer
  reaperLight: {
    type: "reaper", glow: "#fff2c2",
    palette: {
      robe: "#e8e2f0", robeDark: "#b9b0cc", hood: "#f8f4ff",
      blade: "#ffd98a", bladeGlow: "#fff2c2", eye: "#ffe08a", glow2: "#ffffff",
      outline: "#5a5470",
    },
  },
  // the Celestia boss: a golden-crowned seraph (drawn at 2x)
  seraph: {
    type: "lich", glow: "#ffe08a",
    palette: {
      robe: "#f4ecd8", robeDark: "#d8cba8", robeLight: "#fffaf0",
      trim: "#ffd166", bone: "#fff6de", boneLight: "#ffffff", boneDark: "#e0d3b0",
      eye: "#ffe08a", orb: "#ffd166", orbGlow: "#fff6de", outline: "#7a6a3a",
    },
  },
  // ---- The Abyssal Rift (endgame) ----
  // rift demon: a hulking void-corrupted demon wreathed in violet fire
  voidmaw: {
    type: "demon", glow: "#b48cff",
    palette: {
      body: "#3a2a5a", dark: "#1e1436", light: "#6a4aa0",
      horn: "#c9b0ff", trim: "#b48cff", cloakDark: "#120a22",
      eye: "#c96aff", eyeGlow: "#e8d0ff", outline: "#0a0616",
    },
  },
  // rift sovereign: a floating, cyan-lit abyssal lord (drawn at 2x)
  abysslord: {
    type: "lich", glow: "#8fe6ff",
    palette: {
      robe: "#1e2050", robeDark: "#101034", robeLight: "#3a3a80",
      trim: "#8fe6ff", bone: "#cfe0f0", boneLight: "#f0f8ff", boneDark: "#8fa4c0",
      eye: "#8fe6ff", orb: "#66d0ff", orbGlow: "#d8f6ff", outline: "#060a18",
    },
  },
};

// A dome whose width and height trade off across the squish cycle.
function drawSlime(p, pal, frame) {
  const squish = [0, 0.4, 0.7, 0.4][frame % MONSTER_FRAMES];
  const cx = 16;
  const yBot = 29;
  const H = 15 - squish * 4.5;
  const halfW = 9.5 + squish * 3;
  for (let i = 0; i <= Math.ceil(H); i++) {
    const y = yBot - i;
    if (y < 1) break;
    const t = Math.min(1, i / H);
    const half = Math.max(1, Math.round(halfW * Math.sqrt(Math.max(0, 1 - t * t))));
    let col = pal.body;
    if (t > 0.7) col = pal.light;
    else if (t < 0.26) col = pal.dark;
    p.rect(cx - half, y, half * 2, 1, col);
  }
  p.rect(cx - 5, Math.round(yBot - H) + 3, 3, 2, pal.light);
  const ey = Math.round(yBot - H * 0.6);
  const ex = Math.round(halfW * 0.44);
  p.rect(cx - ex - 1, ey, 2, 3, pal.eye);
  p.rect(cx + ex - 1, ey, 2, 3, pal.eye);
  if (pal.glint) {
    p.set(cx - ex - 1, ey, pal.glint);
    p.set(cx + ex - 1, ey, pal.glint);
  }
  p.rect(cx - 1, ey + 4, 2, 1, pal.eye);
}

function drawWisp(p, pal, frame) {
  const f = frame % MONSTER_FRAMES;
  const bob = [0, -1, -2, -1][f];
  const cx = 16, cy = 15 + bob, R = 6;
  for (let y = -R; y <= R; y++) {
    const half = Math.round(Math.sqrt(Math.max(0, R * R - y * y)));
    if (half <= 0) continue;
    let col = pal.body;
    if (y <= -Math.round(R * 0.4)) col = pal.light;
    else if (y >= Math.round(R * 0.45)) col = pal.dark;
    p.rect(cx - half, cy + y, half * 2, 1, col);
  }
  for (let y = -R; y <= 0; y++) {
    const half = Math.round(Math.sqrt(Math.max(0, R * R - y * y)));
    if (half <= 0) continue;
    p.set(cx - half - 1, cy + y, pal.light);
    p.set(cx + half, cy + y, pal.light);
  }
  const wob = [0, 1, 0, -1][f];
  p.rect(cx - 2 + wob, cy + R + 1, 3, 2, pal.dark);
  p.rect(cx - 1 + wob, cy + R + 3, 2, 2, pal.dark);
  p.set(cx + wob, cy + R + 5, pal.dark);
  p.rect(cx - 3, cy - 1, 2, 2, pal.eye);
  p.rect(cx + 1, cy - 1, 2, 2, pal.eye);
  if (pal.glint) {
    p.set(cx - 3, cy - 1, pal.glint);
    p.set(cx + 1, cy - 1, pal.glint);
  }
}

// A hooded robed figure holding a staff with a pulsing orb. Ranged attacker.
function drawCaster(p, pal, frame) {
  const f = frame % MONSTER_FRAMES;
  const bob = [0, -1, 0, 1][f];
  const cx = 15;
  const yTop = 12 + bob;
  const yBot = 29;
  for (let y = yTop; y <= yBot; y++) {
    const t = (y - yTop) / (yBot - yTop);
    const half = Math.round(3.4 + t * 4.2);
    const col = t > 0.74 ? pal.robeDark : pal.robe;
    p.rect(cx - half, y, half * 2, 1, col);
  }
  // sash
  const sy = yTop + Math.round((yBot - yTop) * 0.45);
  p.rect(cx - 7, sy, 14, 2, pal.trim);
  p.rect(cx - 7, sy + 1, 14, 1, pal.robeDark);
  // shoulders
  p.rect(cx - 5, yTop, 10, 2, pal.robeLight);
  // hood
  for (let y = 5 + bob; y <= 13 + bob; y++) {
    const t = (y - (5 + bob)) / 8;
    const half = Math.round(5 - t * 1.2);
    p.rect(cx - half, y, half * 2, 1, pal.robeDark);
  }
  p.rect(cx - 5, 5 + bob, 10, 1, pal.robeLight);
  // dark face opening with two glowing eyes
  p.rect(cx - 4, 8 + bob, 8, 5, "#0b0710");
  p.rect(cx - 3, 10 + bob, 2, 2, pal.eye);
  p.rect(cx + 1, 10 + bob, 2, 2, pal.eye);
  // staff + orb
  p.rect(cx + 7, 7 + bob, 2, 21 - bob, pal.trim);
  p.rect(cx + 7, 7 + bob, 1, 21 - bob, pal.robeDark);
  const orbR = [3, 4, 3, 2][f];
  const ox = cx + 8, oy = 5 + bob;
  for (let y = -orbR; y <= orbR; y++) {
    const half = Math.round(Math.sqrt(Math.max(0, orbR * orbR - y * y)));
    if (half <= 0) continue;
    p.rect(ox - half, oy + y, half * 2, 1, pal.orb);
  }
  p.rect(ox - 2, oy - 2, 2, 2, pal.orbGlow);
  p.set(ox + 1, oy + 1, pal.orbGlow);
  // feet peeking out of the robe
  p.rect(cx - 4, yBot + 1, 3, 1, pal.outline);
  p.rect(cx + 2, yBot + 1, 3, 1, pal.outline);
}

// A big floating eyeball with wispy tendrils. Ranged attacker.
function drawEye(p, pal, frame) {
  const f = frame % MONSTER_FRAMES;
  const bob = [0, -1, -2, -1][f];
  const cx = 16, cy = 14 + bob, R = 7;
  const disc = (ox, oy, r, col) => {
    for (let y = -r; y <= r; y++) {
      const half = Math.round(Math.sqrt(Math.max(0, r * r - y * y)));
      if (half <= 0) continue;
      p.rect(ox - half, oy + y, half * 2, 1, col);
    }
  };
  disc(cx, cy, R, pal.sclera);
  disc(cx, cy + Math.round(R * 0.6), R - 2, pal.lid || pal.sclera);
  const ix = cx + (f === 1 ? 1 : f === 3 ? -1 : 0);
  disc(ix, cy, 4, pal.body);
  disc(ix, cy, 2, pal.pupil);
  p.rect(ix - 2, cy - 3, 2, 2, pal.glint);
  // tendrils trailing beneath
  const wob = [0, 1, 0, -1][f];
  for (let i = 0; i < 3; i++) {
    const tx = cx - 5 + i * 5 + wob;
    p.rect(tx, cy + R + 1, 2, 2, pal.dark);
    p.rect(tx + (i % 2 ? 1 : -1), cy + R + 3, 2, 2, pal.dark);
  }
  p.rect(cx - R - 1, cy - 1, 1, 3, pal.dark);
  p.rect(cx + R, cy - 1, 1, 3, pal.dark);
}

// A hulking horned boss. Same 32x32 grid as everything else, but the game
// scales it up x2 so it towers over the mobs.
function drawDemon(p, pal, frame) {
  const f = frame % MONSTER_FRAMES;
  const bob = [0, -1, -1, 0][f];
  const cx = 16;
  const B = pal.body, D = pal.dark, L = pal.light, T = pal.trim, H = pal.horn;
  // cape silhouette sweeping out behind the body
  for (let y = 11 + bob; y <= 27; y++) {
    const t = (y - (11 + bob)) / 16;
    const half = Math.round(6 + t * 8);
    p.rect(cx - half, y, half * 2, 1, pal.cloakDark);
  }
  // legs + hooves
  p.rect(cx - 8, 23, 5, 7, D);
  p.rect(cx + 3, 23, 5, 7, D);
  p.rect(cx - 9, 29, 6, 2, B);
  p.rect(cx + 3, 29, 6, 2, B);
  // torso + chest trim
  p.rect(cx - 7, 14 + bob, 14, 10, B);
  p.rect(cx - 7, 14 + bob, 14, 1, L);
  p.rect(cx - 7, 14 + bob, 1, 10, D);
  p.rect(cx + 6, 14 + bob, 1, 10, D);
  p.rect(cx - 2, 15 + bob, 4, 8, T);
  p.rect(cx - 1, 16 + bob, 2, 6, D);
  // arms + claws
  p.rect(cx - 10, 15 + bob, 3, 9, D);
  p.rect(cx + 7, 15 + bob, 3, 9, D);
  p.rect(cx - 11, 23 + bob, 5, 3, B);
  p.rect(cx + 6, 23 + bob, 5, 3, B);
  p.rect(cx - 11, 25 + bob, 5, 1, D);
  p.rect(cx + 6, 25 + bob, 5, 1, D);
  // head
  p.rect(cx - 6, 5 + bob, 12, 9, B);
  p.rect(cx - 6, 5 + bob, 12, 1, L);
  p.rect(cx - 6, 13 + bob, 12, 1, D);
  // glowing maw
  p.rect(cx - 4, 11 + bob, 8, 2, "#140610");
  p.rect(cx - 3, 11 + bob, 1, 1, pal.eyeGlow);
  p.rect(cx - 1, 11 + bob, 1, 1, pal.eyeGlow);
  p.rect(cx + 1, 11 + bob, 1, 1, pal.eyeGlow);
  // eyes
  p.rect(cx - 4, 7 + bob, 2, 2, pal.eye);
  p.rect(cx + 2, 7 + bob, 2, 2, pal.eye);
  p.set(cx - 4, 7 + bob, pal.eyeGlow);
  p.set(cx + 2, 7 + bob, pal.eyeGlow);
  // swept horns
  for (let i = 0; i < 5; i++) {
    const rise = Math.round(i * 0.6);
    p.rect(cx - 7 - rise, 4 + bob - i, 2, 2, H);
    p.rect(cx + 6 + rise, 4 + bob - i, 2, 2, H);
  }
  // crown spikes
  for (let i = -1; i <= 1; i++) p.rect(cx + i * 3 - 1, 4 + bob, 2, 2, T);
}

// A hunched, heavily-built ogre with shoulder plates, tusks and a spiked club.
// Slow melee bruiser that winds up a charge.
function drawBrute(p, pal, frame) {
  const f = frame % MONSTER_FRAMES;
  const bob = [0, -1, -1, 0][f];
  const cx = 16;
  const B = pal.body, D = pal.dark, L = pal.light, H = pal.horn;
  // legs + stubby feet
  p.rect(cx - 8, 24, 6, 5, D);
  p.rect(cx + 2, 24, 6, 5, D);
  p.rect(cx - 9, 28, 7, 2, B);
  p.rect(cx + 2, 28, 7, 2, B);
  // broad torso
  p.rect(cx - 9, 13 + bob, 18, 12, B);
  p.rect(cx - 9, 13 + bob, 18, 2, L);
  p.rect(cx - 9, 13 + bob, 1, 12, D);
  p.rect(cx + 8, 13 + bob, 1, 12, D);
  p.rect(cx - 5, 19 + bob, 10, 5, D);
  // shoulder plates
  p.rect(cx - 12, 12 + bob, 5, 5, D);
  p.rect(cx + 7, 12 + bob, 5, 5, D);
  p.rect(cx - 12, 12 + bob, 5, 1, L);
  p.rect(cx + 7, 12 + bob, 5, 1, L);
  // arms
  p.rect(cx - 13, 16 + bob, 3, 8, B);
  p.rect(cx + 10, 16 + bob, 3, 8, B);
  // spiked club in the near hand
  p.rect(cx + 12, 13 + bob, 2, 12, D);
  p.rect(cx + 9, 7 + bob, 8, 7, pal.club || D);
  p.rect(cx + 9, 7 + bob, 8, 2, L);
  p.rect(cx + 9, 7 + bob, 2, 2, H);
  p.rect(cx + 15, 10 + bob, 2, 2, H);
  // head sunk between the shoulders
  p.rect(cx - 5, 6 + bob, 10, 7, B);
  p.rect(cx - 5, 6 + bob, 10, 1, L);
  p.rect(cx - 5, 12 + bob, 10, 1, D);
  // eyes + tusks
  p.rect(cx - 4, 8 + bob, 2, 2, pal.eye);
  p.rect(cx + 2, 8 + bob, 2, 2, pal.eye);
  p.set(cx - 4, 8 + bob, pal.eyeGlow);
  p.set(cx + 2, 8 + bob, pal.eyeGlow);
  p.rect(cx - 7, 4 + bob, 2, 3, H);
  p.rect(cx + 5, 4 + bob, 2, 3, H);
  p.rect(cx - 2, 12 + bob, 1, 2, H);
  p.rect(cx + 1, 12 + bob, 1, 2, H);
}

// A hooded wraith trailing tattered cloth, carrying a curved scythe. Fast and
// prone to sudden dashes.
function drawReaper(p, pal, frame) {
  const f = frame % MONSTER_FRAMES;
  const bob = [0, -1, -2, -1][f];
  const cx = 16;
  // tattered robe
  for (let y = 10 + bob; y <= 28; y++) {
    const t = (y - (10 + bob)) / 18;
    const half = Math.round(4 + t * 5);
    p.rect(cx - half, y, half * 2, 1, t > 0.72 ? pal.robeDark : pal.robe);
    if (t > 0.5 && (y + f) % 3 === 0) p.rect(cx - half, y, half * 2, 1, pal.robeDark);
  }
  // hood
  for (let y = 4 + bob; y <= 13 + bob; y++) {
    const t = (y - (4 + bob)) / 9;
    const half = Math.round(5 - t * 1.6);
    p.rect(cx - half, y, half * 2, 1, pal.robeDark);
  }
  p.rect(cx - 5, 4 + bob, 10, 1, pal.hood);
  // shadowed face with burning eyes
  p.rect(cx - 4, 7 + bob, 8, 5, "#07060c");
  p.rect(cx - 3, 9 + bob, 2, 2, pal.eye);
  p.rect(cx + 1, 9 + bob, 2, 2, pal.eye);
  p.set(cx - 3, 9 + bob, pal.glow2 || "#ffffff");
  p.set(cx + 1, 9 + bob, pal.glow2 || "#ffffff");
  // scythe: shaft on the near side, curved blade sweeping over the hood
  p.rect(cx + 6, 6 + bob, 2, 22 - bob, pal.blade);
  p.rect(cx + 6, 6 + bob, 1, 22 - bob, pal.robeDark);
  p.rect(cx + 1, 5 + bob, 6, 2, pal.bladeGlow);
  p.rect(cx, 7 + bob, 4, 1, pal.bladeGlow);
  p.set(cx, 9 + bob, pal.bladeGlow);
  p.rect(cx + 7, 5 + bob, 2, 2, pal.robeDark);
  // reaching arm
  p.rect(cx + 4, 14 + bob, 3, 3, pal.robe);
}

// A floating crowned skull in violet robes, orb-topped staff in hand. The
// second wave-boss; draw big and slow.
function drawLich(p, pal, frame) {
  const f = frame % MONSTER_FRAMES;
  const bob = [0, -2, -1, -2][f];
  const cx = 16;
  // robe
  for (let y = 13 + bob; y <= 30; y++) {
    const t = (y - (13 + bob)) / 17;
    const half = Math.round(5 + t * 7);
    p.rect(cx - half, y, half * 2, 1, t > 0.72 ? pal.robeDark : pal.robe);
  }
  // collar
  p.rect(cx - 7, 13 + bob, 14, 3, pal.trim);
  p.rect(cx - 7, 14 + bob, 14, 1, pal.robeDark);
  // skull
  p.rect(cx - 5, 3 + bob, 10, 9, pal.bone);
  p.rect(cx - 5, 3 + bob, 10, 1, pal.boneLight);
  p.rect(cx - 5, 11 + bob, 10, 1, pal.boneDark);
  // jaw
  p.rect(cx - 4, 12 + bob, 8, 2, pal.bone);
  p.rect(cx - 3, 12 + bob, 1, 1, pal.boneDark);
  p.rect(cx + 2, 12 + bob, 1, 1, pal.boneDark);
  // eye sockets
  p.rect(cx - 4, 6 + bob, 3, 3, "#0a0612");
  p.rect(cx + 1, 6 + bob, 3, 3, "#0a0612");
  p.rect(cx - 3, 7 + bob, 1, 1, pal.eye);
  p.rect(cx + 2, 7 + bob, 1, 1, pal.eye);
  // crown
  p.rect(cx - 5, 2 + bob, 10, 1, pal.trim);
  p.rect(cx - 5, 0 + bob, 2, 2, pal.trim);
  p.rect(cx - 1, -1 + bob, 2, 3, pal.trim);
  p.rect(cx + 3, 0 + bob, 2, 2, pal.trim);
  // staff + pulsing orb
  p.rect(cx + 8, 6 + bob, 2, 22 - bob, pal.trim);
  p.rect(cx + 8, 6 + bob, 1, 22 - bob, pal.robeDark);
  const orbR = [3, 4, 3, 2][f];
  const ox = cx + 9, oy = 4 + bob;
  for (let y = -orbR; y <= orbR; y++) {
    const half = Math.round(Math.sqrt(Math.max(0, orbR * orbR - y * y)));
    if (half <= 0) continue;
    p.rect(ox - half, oy + y, half * 2, 1, pal.orb);
  }
  p.rect(ox - 1, oy - 1, 2, 2, pal.orbGlow);
}

export function renderMonsterFrame({ type = "slime", palette = MONSTERS.slimeGreen.palette, frame = 0 } = {}) {
  const p = new Pix(FRAME_W, FRAME_H);
  if (type === "wisp") drawWisp(p, palette, frame);
  else if (type === "caster") drawCaster(p, palette, frame);
  else if (type === "eye") drawEye(p, palette, frame);
  else if (type === "demon") drawDemon(p, palette, frame);
  else if (type === "brute") drawBrute(p, palette, frame);
  else if (type === "reaper") drawReaper(p, palette, frame);
  else if (type === "lich") drawLich(p, palette, frame);
  else drawSlime(p, palette, frame);
  p.outline(palette.outline || "#12201a");
  return p;
}

// { [kind]: [canvas, ...] } — one canvas per animation frame.
export function buildMonsterCanvases() {
  const out = {};
  for (const [name, def] of Object.entries(MONSTERS)) {
    out[name] = [];
    for (let f = 0; f < MONSTER_FRAMES; f++) {
      out[name].push(renderMonsterFrame({ type: def.type, palette: def.palette, frame: f }).toCanvas());
    }
  }
  return out;
}

// ---- weapons --------------------------------------------------------------
// Small pixel-art gun icons for the shop/wish cards (24x16 logical pixels,
// drawn in the weapon's own colours and scaled up with the same Pix pipeline).

export const GUN_SHAPES = ["pistol", "rifle", "scatter", "cannon", "staff", "sword", "bloodsword", "hammer", "bow", "book", "nunchaku"];

function drawGunShape(p, shape, pal) {
  const B = pal.body, D = pal.dark, A = pal.accent, G = pal.glow;
  if (shape === "pistol") {
    p.rect(6, 6, 11, 4, B);
    p.rect(6, 6, 11, 1, A);
    p.rect(6, 9, 11, 1, D);
    p.rect(17, 7, 5, 2, D);
    p.rect(21, 6, 2, 4, A);
    p.rect(7, 10, 4, 5, D);
    p.rect(7, 10, 3, 1, B);
    p.rect(9, 12, 2, 2, A);
  } else if (shape === "rifle") {
    p.rect(1, 7, 4, 4, D);
    p.rect(4, 7, 15, 4, B);
    p.rect(4, 7, 15, 1, A);
    p.rect(4, 10, 15, 1, D);
    p.rect(19, 8, 5, 2, D);
    p.rect(8, 4, 7, 2, D);
    p.rect(9, 4, 5, 1, B);
    p.rect(11, 11, 3, 4, D);
    p.rect(12, 12, 2, 2, A);
  } else if (shape === "scatter") {
    p.rect(6, 6, 8, 6, B);
    p.rect(6, 6, 8, 1, A);
    p.rect(6, 11, 8, 1, D);
    p.rect(13, 5, 9, 2, D);
    p.rect(13, 8, 9, 2, D);
    p.rect(20, 5, 2, 5, A);
    p.rect(6, 12, 4, 3, D);
    p.rect(5, 14, 6, 1, D);
    p.rect(9, 12, 3, 1, A);
  } else if (shape === "cannon") {
    p.rect(3, 7, 7, 6, B);
    p.rect(3, 7, 7, 1, A);
    p.rect(3, 12, 7, 1, D);
    p.rect(9, 6, 11, 8, B);
    p.rect(9, 6, 11, 1, A);
    p.rect(9, 13, 11, 1, D);
    p.rect(19, 4, 3, 12, D);
    p.rect(21, 4, 1, 12, A);
    p.rect(11, 8, 2, 2, D);
    p.rect(16, 10, 2, 2, D);
    p.rect(4, 13, 4, 3, D);
  } else if (shape === "staff") {
    // staff: diagonal rod topped with a bright gem finial
    for (let i = 0; i < 12; i++) p.rect(3 + i, 14 - i, 2, 2, i % 2 ? D : B);
    p.rect(3, 13, 3, 2, A);
    const ox = 17, oy = 5, R = 4;
    for (let y = -R; y <= R; y++) {
      const half = R - Math.abs(y);
      p.rect(ox - half, oy + y, half * 2 + 1, 1, B);
    }
    for (let y = -2; y <= 2; y++) {
      const half = 2 - Math.abs(y);
      p.rect(ox - half, oy + y, half * 2 + 1, 1, A);
    }
    p.rect(ox - 1, oy - 1, 1, 1, G);
  } else if (shape === "sword") {
    // straight blade with a crossguard and a wrapped grip
    p.rect(1, 6, 3, 4, D);
    p.rect(1, 6, 3, 1, A);
    p.set(1, 9, A);
    p.rect(4, 3, 2, 10, D);
    p.rect(4, 3, 2, 1, A);
    p.rect(6, 5, 13, 6, B);
    p.rect(6, 5, 13, 1, A);
    p.rect(7, 8, 11, 1, D);
    p.rect(19, 6, 2, 4, B);
    p.rect(21, 7, 1, 2, A);
  } else if (shape === "bloodsword") {
    // long jagged greatsword with a dark red blade and a glowing edge
    p.rect(0, 6, 5, 4, D);
    p.rect(0, 6, 5, 1, A);
    p.set(0, 9, A);
    p.set(1, 8, G);
    p.rect(5, 3, 2, 10, D);
    p.rect(5, 3, 2, 1, A);
    p.rect(5, 12, 2, 1, A);
    p.rect(7, 5, 14, 6, B);
    p.rect(7, 5, 14, 1, A);
    p.rect(7, 10, 14, 1, D);
    for (let i = 0; i < 5; i++) p.set(8 + i * 3, 10, A);
    p.rect(21, 5, 3, 6, G);
    p.rect(21, 5, 3, 1, A);
    p.rect(22, 7, 1, 2, "#ffffff");
  } else if (shape === "hammer") {
    // heavy head on a wooden shaft
    p.rect(2, 9, 4, 5, D);
    p.rect(2, 9, 4, 1, A);
    p.rect(5, 7, 8, 3, D);
    p.rect(11, 3, 10, 9, B);
    p.rect(11, 3, 10, 1, A);
    p.rect(11, 11, 10, 1, D);
    p.rect(15, 5, 3, 5, A);
    p.set(14, 6, G);
    p.set(18, 6, G);
  } else if (shape === "bow") {
    // curved limb, taut string, and a nocked arrow
    for (const [x, y] of [[13, 1], [10, 2], [8, 4], [7, 7], [7, 9], [8, 12], [10, 14], [13, 15]]) p.rect(x, y, 2, 2, B);
    p.rect(13, 1, 2, 1, A);
    p.rect(13, 14, 2, 1, A);
    for (let y = 2; y <= 14; y++) p.set(14, y, A);
    p.rect(9, 6, 2, 4, D);
    p.rect(4, 7, 12, 1, D);
    p.rect(16, 6, 2, 3, B);
    p.set(18, 7, A);
    p.rect(4, 5, 1, 5, A);
  } else if (shape === "book") {
    // open spellbook, spines down the middle, runes aglow
    p.rect(4, 4, 16, 9, B);
    p.rect(4, 4, 16, 1, A);
    p.rect(4, 12, 16, 1, D);
    p.rect(11, 4, 2, 9, D);
    p.rect(6, 6, 4, 5, A);
    p.rect(14, 6, 4, 5, A);
    p.rect(7, 7, 2, 3, G);
    p.rect(15, 7, 2, 3, G);
    p.rect(10, 2, 2, 2, A);
  } else if (shape === "nunchaku") {
    // twin batons joined by a short chain
    p.rect(1, 3, 9, 3, B);
    p.rect(1, 3, 9, 1, A);
    p.rect(1, 5, 9, 1, D);
    p.rect(8, 4, 3, 1, D);
    p.rect(14, 10, 9, 3, B);
    p.rect(14, 10, 9, 1, A);
    p.rect(14, 12, 9, 1, D);
    p.rect(13, 11, 3, 1, D);
    p.rect(10, 6, 2, 2, D);
    p.rect(12, 8, 2, 2, D);
    p.set(11, 7, G);
    p.set(13, 9, G);
  }
}

export function renderGunIcon({ shape = "pistol", body = "#9aa0b0", dark = "#5a6070", accent = "#e8eaf0", glow = null, scale = 1 } = {}) {
  const p = new Pix(24, 16);
  drawGunShape(p, shape, { body, dark, accent, glow: glow || accent });
  p.outline("#0e1016");
  const src = p.toCanvas();
  const s = Math.max(1, Math.round(scale));
  const c = document.createElement("canvas");
  c.width = p.w * s;
  c.height = p.h * s;
  const x = c.getContext("2d");
  x.imageSmoothingEnabled = false;
  x.drawImage(src, 0, 0, p.w, p.h, 0, 0, c.width, c.height);
  c.className = "px";
  return c;
}
