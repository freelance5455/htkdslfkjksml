/**
 * Mizo_q TikTok Toolkit — Unfollow Manager V6.0 (background.js)
 *
 * Key V6.0 Responsibilities:
 * 1. Central Branding Configuration (BRAND_CONFIG) shared across background, popup, notifications, and exports.
 * 2. Manifest V3 Background Task Orchestration independent of the popup lifecycle.
 * 3. Mobile & Quetta Browser compatibility: tracks executionState ('actively_processing',
 *    'suspended_by_os', 'awaiting_verification', 'standby'), handles Android app-switching
 *    visibility changes, and reconciles queue state after OS suspension or worker restart.
 * 4. Safe CAPTCHA / Verification pause & manual resolution recovery without bypassing security checks.
 * 5. Smart Stop & Automatic CSV Export on Stop, Normal Completion, and Session Limit Reached
 *    with duplicate-export prevention, 3-tier download fallback, and one-tap retry.
 * 6. Supported Browser Notifications (session_started, session_completed, session_paused,
 *    verification_required, rate_limit_detected, export_completed, export_failed,
 *    browser_recovery_required) with noncritical notification filtering.
 * 7. Real Session Analytics computation from recorded history events.
 */

'use strict';

const BRAND_CONFIG = Object.freeze({
  brandName: 'Mizo_q',
  productTitle: 'Mizo_q TikTok Toolkit',
  productSubtitle: 'Unfollow Manager V6.0',
  fullTitle: 'Mizo_q TikTok Toolkit — Unfollow Manager V6.0',
  version: '5.0.0',
  versionLabel: 'V6.0',
  monogram: 'MQ',
  csvFilePrefix: 'tiktok-unfollower-session',
  iconPath: 'icons/icon128.png',
  bgAssetPath: 'icons/mizo-bg-pattern.svg'
});

const MAX_SESSION_LIMIT = 10000;
const MAX_HISTORY_RECORDS = 20000;
const SESSION_LIMIT_PRESETS = [20, 50, 100, 500, 1000, 5000, 10000];
const VALID_THEME_VARIANTS = ['midnight_nebula', 'cyber_indigo', 'obsidian_glass'];

const VALID_QUEUE_STATES = [
  'idle',
  'scanning',
  'processing',
  'paused',
  'recovering',
  'rate_limited',
  'verification_required',
  'completed',
  'stopped',
  'failed'
];

const DEFAULT_SETTINGS = {
  minDelayMs: 2000,
  maxDelayMs: 4000,
  maxActionsPerSession: 100,
  limitPreset: '100',
  maxScanDurationSec: 3600,
  skipMutuals: true,
  autoRefresh: true,
  autoScan: true,
  autoScroll: true,
  autoExportCsv: true,
  notificationsEnabled: true,
  criticalNotificationsOnly: false,
  reducedMotion: false,
  themeVariant: 'midnight_nebula',
  ambientOrbs: true,
  confirmBulkActions: true,
  confirmIndividualDestructive: false,
  executionMode: 'auto',
  followerRemovalMethod: 'native_remove'
};

const CRITICAL_NOTIFICATION_TYPES = new Set([
  'verification_required',
  'rate_limit_detected',
  'export_failed',
  'browser_recovery_required'
]);

function createDefaultCounts(configuredLimit = 100) {
  return {
    scanned: 0,
    queued: 0,
    total: 0,
    success: 0,
    skipped: 0,
    pending: 0,
    failed: 0,
    uncertain: 0,
    mutualProtected: 0,
    uncertainSkipped: 0,
    configuredLimit: Number(configuredLimit) || 100,
    remaining: Number(configuredLimit) || 100
  };
}

function createDefaultMetrics() {
  return {
    sessionStartTime: null,
    accumulatedElapsedMs: 0,
    lastResumeTime: null,
    discoveredPerMin: 0,
    completedPerMin: 0,
    elapsedFormatted: '0s'
  };
}

const DEFAULT_QUEUE_STATE = {
  status: 'idle',
  executionState: 'standby', // 'actively_processing' | 'suspended_by_os' | 'awaiting_verification' | 'standby'
  tabType: 'following',
  automationActive: false,
  isSimulatedData: false,
  simulatedTotalAvailable: 50,
  sessionId: null,
  targetTabId: null,
  targetUrl: null,
  profileUsername: null,
  expectedRefreshTabId: null,
  refreshCount: 0,
  hasUncertainActionInFlight: false,
  inFlightUsername: null,
  captchaResolvedReadyToResume: false,
  lastSuccessfulAction: null, // { username, displayName, action, timestamp }
  lastExport: null, // { sessionId, filename, timestamp, recordCount, status, errorDetails, triggerReason }
  lastNotification: null, // { type, title, message, timestamp, critical, deliveredViaApi }
  exportedSessionIds: [],
  scanOutcome: null,
  queue: [],
  discoveredUsernames: [],
  processedUsernames: [],
  uncertainUsernames: [],
  loggedActionKeys: [],
  counts: createDefaultCounts(100),
  metrics: createDefaultMetrics(),
  consecutiveFailures: 0,
  interruptionReason: null,
  securityWarning: null,
  completionReport: null,
  lastCheckpointAt: null,
  lastUpdated: null
};

const orchestrator = {
  isLoopRunning: false,
  activeLoopToken: 0,
  delayCancelFn: null,
  forceDownloadFailureForTest: false,
  lastNotificationByKey: new Map()
};

function cancelableSleep(ms) {
  return new Promise((resolve) => {
    const timer = setTimeout(() => {
      orchestrator.delayCancelFn = null;
      resolve();
    }, ms);
    orchestrator.delayCancelFn = () => {
      clearTimeout(timer);
      orchestrator.delayCancelFn = null;
      resolve();
    };
  });
}

function abortOrchestratorSleep() {
  if (typeof orchestrator.delayCancelFn === 'function') {
    orchestrator.delayCancelFn();
  }
}

function normalizeQueueStatus(status) {
  if (status === 'running') return 'processing';
  if (status === 'paused_recovery') return 'recovering';
  if (status === 'halted_security') return 'verification_required';
  if (VALID_QUEUE_STATES.includes(status)) return status;
  return 'idle';
}

function computeExecutionState(status, currentExecState) {
  const norm = normalizeQueueStatus(status);
  if (norm === 'verification_required' || norm === 'rate_limited') {
    return 'awaiting_verification';
  }
  if (norm === 'scanning' || norm === 'processing') {
    if (currentExecState === 'suspended_by_os') return 'suspended_by_os';
    return 'actively_processing';
  }
  if (norm === 'recovering' && currentExecState === 'suspended_by_os') {
    return 'suspended_by_os';
  }
  return 'standby';
}

function formatElapsedMs(ms) {
  const totalSec = Math.max(0, Math.floor((Number(ms) || 0) / 1000));
  const hrs = Math.floor(totalSec / 3600);
  const mins = Math.floor((totalSec % 3600) / 60);
  const secs = totalSec % 60;
  if (hrs > 0) return `${hrs}h ${mins}m ${secs}s`;
  if (mins > 0) return `${mins}m ${secs}s`;
  return `${secs}s`;
}

/**
 * Format timestamp as YYYY-MM-DD-HH-mm-ss for automatic CSV filenames.
 */
function formatCsvFilenameTimestamp(dateInput = new Date()) {
  const d = dateInput instanceof Date ? dateInput : new Date(dateInput);
  const pad = (n) => String(n).padStart(2, '0');
  const yyyy = d.getFullYear();
  const mm = pad(d.getMonth() + 1);
  const dd = pad(d.getDate());
  const hh = pad(d.getHours());
  const min = pad(d.getMinutes());
  const ss = pad(d.getSeconds());
  return `${yyyy}-${mm}-${dd}-${hh}-${min}-${ss}`;
}

/**
 * Escape a single CSV cell per RFC 4180 and neutralize spreadsheet formula injection.
 */
function escapeCsvCell(value) {
  if (value === null || value === undefined) return '';
  let str = String(value);
  if (/^[=+\-@]/.test(str) && !/^@[a-zA-Z0-9_.]/.test(str)) {
    str = `'${str}`;
  }
  const needsQuotes = /[",\r\n]/.test(str);
  if (needsQuotes) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

/**
 * Generate RFC 4180 CSV string with UTF-8 BOM and exact V5 column order:
 * Username, Display Name, Requested Action, Result, Timestamp, Session ID, Skip Reason, Error Details
 */
function generateSessionCsvString(records) {
  const headers = [
    'Username',
    'Display Name',
    'Requested Action',
    'Result',
    'Timestamp',
    'Session ID',
    'Skip Reason',
    'Error Details'
  ];

  const rows = [headers.map(escapeCsvCell).join(',')];
  const list = Array.isArray(records) ? records : [];

  for (let i = 0; i < list.length; i++) {
    const item = list[i];
    const row = [
      item.username ? `@${String(item.username).replace(/^@/, '')}` : '',
      item.displayName || '',
      item.action || '',
      item.result || '',
      item.timestamp || '',
      item.sessionId || '',
      item.skipReason || '',
      item.errorDetails || ''
    ];
    rows.push(row.map(escapeCsvCell).join(','));
  }

  return '\uFEFF' + rows.join('\r\n');
}

function updateLiveMetrics(queueState, configuredLimit) {
  const qs = queueState;
  const limit = Number(configuredLimit || qs.counts?.configuredLimit || 100);
  const counts = qs.counts || createDefaultCounts(limit);
  counts.configuredLimit = limit;
  counts.remaining = Math.max(0, limit - (counts.success || 0));

  const metrics = qs.metrics || createDefaultMetrics();
  const now = Date.now();
  let totalElapsedMs = Number(metrics.accumulatedElapsedMs || 0);
  if (['scanning', 'processing'].includes(qs.status) && metrics.lastResumeTime) {
    totalElapsedMs += Math.max(0, now - metrics.lastResumeTime);
  }

  const elapsedMinutes = totalElapsedMs / 60000;
  if (elapsedMinutes >= 0.005) {
    metrics.discoveredPerMin = Number(((counts.scanned || 0) / elapsedMinutes).toFixed(1));
    metrics.completedPerMin = Number(((counts.success || 0) / elapsedMinutes).toFixed(1));
  } else {
    metrics.discoveredPerMin = counts.scanned || 0;
    metrics.completedPerMin = counts.success || 0;
  }
  metrics.elapsedFormatted = formatElapsedMs(totalElapsedMs);
  qs.counts = counts;
  qs.metrics = metrics;
  return qs;
}

function validateSettings(raw) {
  const input = raw && typeof raw === 'object' ? raw : {};
  const errors = [];

  let minDelayMs = Number(input.minDelayMs ?? DEFAULT_SETTINGS.minDelayMs);
  let maxDelayMs = Number(input.maxDelayMs ?? DEFAULT_SETTINGS.maxDelayMs);
  let maxActionsPerSession = Number(input.maxActionsPerSession ?? DEFAULT_SETTINGS.maxActionsPerSession);
  let maxScanDurationSec = Number(input.maxScanDurationSec ?? DEFAULT_SETTINGS.maxScanDurationSec);

  if (!Number.isFinite(minDelayMs) || minDelayMs < 0 || minDelayMs > 60000) {
    errors.push('Minimum delay must be between 0 ms and 60,000 ms (60s).');
    minDelayMs = Math.max(0, Math.min(60000, Number.isFinite(minDelayMs) ? Math.round(minDelayMs) : DEFAULT_SETTINGS.minDelayMs));
  } else {
    minDelayMs = Math.round(minDelayMs);
  }

  if (!Number.isFinite(maxDelayMs) || maxDelayMs < 0 || maxDelayMs > 120000) {
    errors.push('Maximum delay must be between 0 ms and 120,000 ms (120s).');
    maxDelayMs = Math.max(0, Math.min(120000, Number.isFinite(maxDelayMs) ? Math.round(maxDelayMs) : DEFAULT_SETTINGS.maxDelayMs));
  } else {
    maxDelayMs = Math.round(maxDelayMs);
  }

  if (minDelayMs > maxDelayMs) {
    errors.push('Minimum delay cannot exceed maximum delay.');
  }

  if (
    !Number.isFinite(maxActionsPerSession) ||
    maxActionsPerSession < 1 ||
    maxActionsPerSession > MAX_SESSION_LIMIT ||
    !Number.isInteger(maxActionsPerSession)
  ) {
    errors.push(`Maximum actions per session must be a whole number between 1 and ${MAX_SESSION_LIMIT.toLocaleString()}.`);
    maxActionsPerSession = Math.max(
      1,
      Math.min(MAX_SESSION_LIMIT, Number.isFinite(maxActionsPerSession) ? Math.round(maxActionsPerSession) : DEFAULT_SETTINGS.maxActionsPerSession)
    );
  }

  if (!Number.isFinite(maxScanDurationSec) || maxScanDurationSec < 10 || maxScanDurationSec > 86400) {
    errors.push('Maximum scan duration must be between 10 and 86,400 seconds.');
    maxScanDurationSec = Math.max(10, Math.min(86400, Number.isFinite(maxScanDurationSec) ? Math.round(maxScanDurationSec) : DEFAULT_SETTINGS.maxScanDurationSec));
  } else {
    maxScanDurationSec = Math.round(maxScanDurationSec);
  }

  const limitPreset = SESSION_LIMIT_PRESETS.includes(maxActionsPerSession)
    ? String(maxActionsPerSession)
    : 'custom';

  const executionMode = input.executionMode === 'guided' ? 'guided' : 'auto';
  const followerRemovalMethod = input.followerRemovalMethod === 'guided_block_unblock'
    ? 'guided_block_unblock'
    : 'native_remove';
  const themeVariant = VALID_THEME_VARIANTS.includes(input.themeVariant)
    ? input.themeVariant
    : DEFAULT_SETTINGS.themeVariant;

  const sanitized = {
    minDelayMs,
    maxDelayMs: Math.max(minDelayMs, maxDelayMs),
    maxActionsPerSession,
    limitPreset: input.limitPreset === 'custom' ? 'custom' : limitPreset,
    maxScanDurationSec,
    skipMutuals: typeof input.skipMutuals === 'boolean' ? input.skipMutuals : DEFAULT_SETTINGS.skipMutuals,
    autoRefresh: typeof input.autoRefresh === 'boolean' ? input.autoRefresh : DEFAULT_SETTINGS.autoRefresh,
    autoScan: typeof input.autoScan === 'boolean' ? input.autoScan : DEFAULT_SETTINGS.autoScan,
    autoScroll: typeof input.autoScroll === 'boolean' ? input.autoScroll : DEFAULT_SETTINGS.autoScroll,
    autoExportCsv: typeof input.autoExportCsv === 'boolean' ? input.autoExportCsv : DEFAULT_SETTINGS.autoExportCsv,
    notificationsEnabled: typeof input.notificationsEnabled === 'boolean' ? input.notificationsEnabled : DEFAULT_SETTINGS.notificationsEnabled,
    criticalNotificationsOnly: typeof input.criticalNotificationsOnly === 'boolean' ? input.criticalNotificationsOnly : DEFAULT_SETTINGS.criticalNotificationsOnly,
    reducedMotion: typeof input.reducedMotion === 'boolean' ? input.reducedMotion : DEFAULT_SETTINGS.reducedMotion,
    themeVariant,
    ambientOrbs: typeof input.ambientOrbs === 'boolean' ? input.ambientOrbs : DEFAULT_SETTINGS.ambientOrbs,
    confirmBulkActions: typeof input.confirmBulkActions === 'boolean' ? input.confirmBulkActions : DEFAULT_SETTINGS.confirmBulkActions,
    confirmIndividualDestructive: typeof input.confirmIndividualDestructive === 'boolean' ? input.confirmIndividualDestructive : DEFAULT_SETTINGS.confirmIndividualDestructive,
    executionMode,
    followerRemovalMethod
  };

  return {
    valid: errors.length === 0,
    errors,
    settings: sanitized
  };
}

/**
 * Dispatch a browser notification using chrome.notifications when supported and permitted by settings.
 * Respects notificationsEnabled and criticalNotificationsOnly, and throttles duplicate alerts.
 */
async function dispatchExtensionNotification(type, title, message, sessionId = null) {
  try {
    const { settings, queueState } = await chrome.storage.local.get(['settings', 'queueState']);
    const s = settings || DEFAULT_SETTINGS;
    const isCritical = CRITICAL_NOTIFICATION_TYPES.has(type);

    if (s.notificationsEnabled === false) {
      return { ok: false, suppressed: 'notifications_disabled', type };
    }
    if (s.criticalNotificationsOnly && !isCritical) {
      return { ok: false, suppressed: 'noncritical_filtered', type };
    }

    const dedupeKey = `${type}:${sessionId || 'global'}`;
    const now = Date.now();
    const lastSent = orchestrator.lastNotificationByKey.get(dedupeKey) || 0;
    if (!isCritical && now - lastSent < 3000) {
      return { ok: false, suppressed: 'throttled', type };
    }
    orchestrator.lastNotificationByKey.set(dedupeKey, now);

    const brandedTitle = `${BRAND_CONFIG.brandName} • ${title}`;
    let deliveredViaApi = false;

    if (typeof chrome !== 'undefined' && chrome.notifications && typeof chrome.notifications.create === 'function') {
      try {
        const notifId = `mizo-q-${type}-${now}`;
        await new Promise((resolve) => {
          try {
            const maybePromise = chrome.notifications.create(
              notifId,
              {
                type: 'basic',
                iconUrl: BRAND_CONFIG.iconPath,
                title: brandedTitle,
                message: String(message || ''),
                priority: isCritical ? 2 : 0
              },
              () => resolve()
            );
            if (maybePromise && typeof maybePromise.then === 'function') {
              maybePromise.then(() => resolve()).catch(() => resolve());
            }
          } catch (_e) {
            resolve();
          }
        });
        deliveredViaApi = true;
      } catch (_err) {
        deliveredViaApi = false;
      }
    }

    const record = {
      type,
      title: brandedTitle,
      message: String(message || ''),
      critical: isCritical,
      deliveredViaApi,
      timestamp: new Date(now).toISOString(),
      sessionId: sessionId || (queueState && queueState.sessionId) || null
    };

    if (queueState && typeof queueState === 'object') {
      queueState.lastNotification = record;
      await chrome.storage.local.set({ queueState });
    }

    return { ok: true, notification: record };
  } catch (_err) {
    return { ok: false, error: 'Notification dispatch failed' };
  }
}

/**
 * Compute real session analytics from recorded actionHistory, exportHistory, and current queueState.
 * Never invents statistics; clearly labels incomplete sessions.
 */
function computeSessionAnalytics(actionHistory, exportHistory, queueState, sessionRegistry = {}) {
  const historyList = Array.isArray(actionHistory) ? actionHistory : [];
  const exportsList = Array.isArray(exportHistory) ? exportHistory : [];
  const registry = sessionRegistry && typeof sessionRegistry === 'object' ? sessionRegistry : {};
  const sessionsMap = new Map();

  // Seed from registry if present
  for (const [sid, meta] of Object.entries(registry)) {
    if (!sid || !meta) continue;
    sessionsMap.set(sid, {
      sessionId: sid,
      startTime: meta.startTime || meta.timestamp || null,
      endTime: meta.endTime || null,
      durationFormatted: meta.durationFormatted || '0s',
      requestedAction: meta.requestedAction || 'unfollow',
      status: meta.status || 'completed',
      isIncomplete: Boolean(meta.isIncomplete),
      scanned: Number(meta.scanned || 0),
      successful: 0,
      skipped: 0,
      failed: 0,
      uncertain: 0,
      totalRecorded: 0,
      exportStatus: 'not_exported',
      exportFilename: null
    });
  }

  // Aggregate from recorded actionHistory events (chronological order from oldest to newest)
  for (let i = historyList.length - 1; i >= 0; i--) {
    const item = historyList[i];
    if (!item || !item.sessionId) continue;
    const sid = item.sessionId;
    let sess = sessionsMap.get(sid);
    if (!sess) {
      sess = {
        sessionId: sid,
        startTime: item.timestamp || null,
        endTime: item.timestamp || null,
        durationFormatted: '—',
        requestedAction: item.action || 'unfollow',
        status: 'completed',
        isIncomplete: false,
        scanned: 0,
        successful: 0,
        skipped: 0,
        failed: 0,
        uncertain: 0,
        totalRecorded: 0,
        exportStatus: 'not_exported',
        exportFilename: null
      };
      sessionsMap.set(sid, sess);
    }

    if (!sess.startTime || (item.timestamp && item.timestamp < sess.startTime)) {
      sess.startTime = item.timestamp;
    }
    if (!sess.endTime || (item.timestamp && item.timestamp > sess.endTime)) {
      sess.endTime = item.timestamp;
    }
    if (item.action) {
      sess.requestedAction = item.action;
    }

    sess.totalRecorded++;
    if (item.result === 'success') sess.successful++;
    else if (item.result === 'skipped') sess.skipped++;
    else if (item.result === 'failed') sess.failed++;
    else if (item.result === 'uncertain') sess.uncertain++;
  }

  // Overlay current queueState if active or recent
  if (queueState && queueState.sessionId) {
    const curSid = queueState.sessionId;
    const existing = sessionsMap.get(curSid) || {
      sessionId: curSid,
      startTime: queueState.metrics?.sessionStartTime
        ? new Date(queueState.metrics.sessionStartTime).toISOString()
        : queueState.lastUpdated,
      endTime: queueState.lastUpdated,
      durationFormatted: queueState.metrics?.elapsedFormatted || '0s',
      requestedAction: queueState.tabType === 'followers' ? 'remove_follower' : 'unfollow',
      status: queueState.status || 'idle',
      isIncomplete: !['completed', 'idle'].includes(queueState.status),
      scanned: queueState.counts?.scanned || 0,
      successful: queueState.counts?.success || 0,
      skipped: queueState.counts?.skipped || 0,
      failed: queueState.counts?.failed || 0,
      uncertain: queueState.counts?.uncertain || 0,
      totalRecorded: 0,
      exportStatus: 'not_exported',
      exportFilename: null
    };

    existing.status = queueState.status || existing.status;
    existing.isIncomplete = !['completed', 'idle'].includes(existing.status);
    existing.durationFormatted = queueState.metrics?.elapsedFormatted || existing.durationFormatted;
    existing.scanned = Math.max(existing.scanned, queueState.counts?.scanned || 0);
    existing.successful = Math.max(existing.successful, queueState.counts?.success || 0);
    existing.skipped = Math.max(existing.skipped, queueState.counts?.skipped || 0);
    existing.failed = Math.max(existing.failed, queueState.counts?.failed || 0);
    existing.uncertain = Math.max(existing.uncertain, queueState.counts?.uncertain || 0);
    sessionsMap.set(curSid, existing);
  }

  // Attach export statuses
  for (const exp of exportsList) {
    if (!exp || !exp.sessionId) continue;
    const sess = sessionsMap.get(exp.sessionId);
    if (sess) {
      sess.exportStatus = exp.status || 'downloaded';
      sess.exportFilename = exp.filename || null;
    }
  }

  // Compute duration where startTime & endTime exist but durationFormatted is '—'
  for (const sess of sessionsMap.values()) {
    if ((!sess.durationFormatted || sess.durationFormatted === '—') && sess.startTime && sess.endTime) {
      const diff = Math.max(0, new Date(sess.endTime).getTime() - new Date(sess.startTime).getTime());
      sess.durationFormatted = formatElapsedMs(diff);
    }
  }

  return Array.from(sessionsMap.values()).sort((a, b) => {
    const tA = a.endTime || a.startTime || '';
    const tB = b.endTime || b.startTime || '';
    return tB.localeCompare(tA);
  });
}

async function updateActionBadge(queueState) {
  try {
    if (!chrome.action || !chrome.action.setBadgeText) return;
    const status = normalizeQueueStatus(queueState && queueState.status ? queueState.status : 'idle');
    let text = '';
    let color = '#7C3AED';

    if (status === 'scanning') {
      text = 'SCAN';
      color = '#06B6D4';
    } else if (status === 'processing') {
      const done = queueState.counts?.success || 0;
      text = done > 999 ? `${Math.floor(done / 1000)}k+` : String(done || 'RUN');
      color = '#7C3AED';
    } else if (status === 'paused') {
      text = 'PAU';
      color = '#38BDF8';
    } else if (status === 'recovering') {
      text = 'REC';
      color = '#F59E0B';
    } else if (status === 'rate_limited') {
      text = 'RATE';
      color = '#EF4444';
    } else if (status === 'verification_required') {
      text = 'VER';
      color = '#EF4444';
    } else if (status === 'completed') {
      text = 'DONE';
      color = '#10B981';
    } else if (status === 'failed') {
      text = 'ERR';
      color = '#DC2626';
    }

    await chrome.action.setBadgeText({ text });
    if (text) {
      await chrome.action.setBadgeBackgroundColor({ color });
    }
  } catch (_err) {
    // Ignore badge errors in mobile/headless environments
  }
}

async function ensureStorageInitialized() {
  const data = await chrome.storage.local.get([
    'settings',
    'queueState',
    'actionHistory',
    'exportHistory',
    'lastSessionCsv',
    'sessionRegistry'
  ]);
  const updates = {};

  let activeSettings;
  if (!data.settings || typeof data.settings !== 'object') {
    activeSettings = { ...DEFAULT_SETTINGS };
    updates.settings = activeSettings;
  } else {
    activeSettings = validateSettings({ ...DEFAULT_SETTINGS, ...data.settings }).settings;
    updates.settings = activeSettings;
  }

  let activeQueueState;
  if (!data.queueState || typeof data.queueState !== 'object') {
    activeQueueState = {
      ...DEFAULT_QUEUE_STATE,
      counts: createDefaultCounts(activeSettings.maxActionsPerSession),
      metrics: createDefaultMetrics()
    };
    updates.queueState = activeQueueState;
  } else {
    const normStatus = normalizeQueueStatus(data.queueState.status);
    activeQueueState = {
      ...DEFAULT_QUEUE_STATE,
      ...data.queueState,
      status: normStatus,
      executionState: computeExecutionState(normStatus, data.queueState.executionState),
      counts: {
        ...createDefaultCounts(activeSettings.maxActionsPerSession),
        ...(data.queueState.counts || {})
      },
      metrics: {
        ...createDefaultMetrics(),
        ...(data.queueState.metrics || {})
      }
    };
    updateLiveMetrics(activeQueueState, activeSettings.maxActionsPerSession);
    updates.queueState = activeQueueState;
  }

  if (!Array.isArray(data.actionHistory)) {
    updates.actionHistory = [];
  }
  if (!Array.isArray(data.exportHistory)) {
    updates.exportHistory = [];
  }
  if (!data.sessionRegistry || typeof data.sessionRegistry !== 'object') {
    updates.sessionRegistry = {};
  }

  await chrome.storage.local.set(updates);
  await updateActionBadge(activeQueueState);
  return {
    settings: activeSettings,
    queueState: activeQueueState,
    actionHistory: Array.isArray(data.actionHistory) ? data.actionHistory : [],
    exportHistory: Array.isArray(data.exportHistory) ? data.exportHistory : [],
    lastSessionCsv: data.lastSessionCsv || null,
    sessionRegistry: data.sessionRegistry && typeof data.sessionRegistry === 'object' ? data.sessionRegistry : {}
  };
}

async function saveCheckpoint(patch = {}) {
  const { queueState: current, settings, sessionRegistry } = await chrome.storage.local.get([
    'queueState',
    'settings',
    'sessionRegistry'
  ]);
  const limit = settings?.maxActionsPerSession || DEFAULT_SETTINGS.maxActionsPerSession;
  const base = current && typeof current === 'object' ? current : { ...DEFAULT_QUEUE_STATE };

  const prevStatus = normalizeQueueStatus(base.status);
  const nextStatus = patch.status ? normalizeQueueStatus(patch.status) : prevStatus;

  const mergedMetrics = {
    ...(base.metrics || createDefaultMetrics()),
    ...(patch.metrics || {})
  };

  const now = Date.now();
  const wasActive = ['scanning', 'processing'].includes(prevStatus);
  const isNowActive = ['scanning', 'processing'].includes(nextStatus);

  if (!wasActive && isNowActive) {
    if (!mergedMetrics.sessionStartTime) mergedMetrics.sessionStartTime = now;
    mergedMetrics.lastResumeTime = now;
  } else if (wasActive && !isNowActive && mergedMetrics.lastResumeTime) {
    mergedMetrics.accumulatedElapsedMs = (mergedMetrics.accumulatedElapsedMs || 0) + Math.max(0, now - mergedMetrics.lastResumeTime);
    mergedMetrics.lastResumeTime = null;
  }

  const nextExecState = patch.executionState
    ? patch.executionState
    : computeExecutionState(nextStatus, base.executionState);

  const merged = {
    ...base,
    ...patch,
    status: nextStatus,
    executionState: nextExecState,
    counts: {
      ...(base.counts || createDefaultCounts(limit)),
      ...(patch.counts || {})
    },
    metrics: mergedMetrics,
    lastCheckpointAt: new Date(now).toISOString(),
    lastUpdated: new Date(now).toISOString()
  };

  updateLiveMetrics(merged, limit);

  const reg = sessionRegistry && typeof sessionRegistry === 'object' ? { ...sessionRegistry } : {};
  if (merged.sessionId) {
    const prevMeta = reg[merged.sessionId] || {};
    reg[merged.sessionId] = {
      sessionId: merged.sessionId,
      startTime: merged.metrics?.sessionStartTime
        ? new Date(merged.metrics.sessionStartTime).toISOString()
        : (prevMeta.startTime || merged.lastUpdated),
      endTime: new Date(now).toISOString(),
      durationFormatted: merged.metrics?.elapsedFormatted || '0s',
      requestedAction: merged.tabType === 'followers' ? 'remove_follower' : 'unfollow',
      status: merged.status,
      isIncomplete: !['completed', 'idle'].includes(merged.status),
      scanned: merged.counts?.scanned || 0
    };
  }

  await chrome.storage.local.set({ queueState: merged, sessionRegistry: reg });
  await updateActionBadge(merged);
  return merged;
}

async function appendHistoryEntryIdempotent(entry, queueStateRef = null, loggedKeysSet = null, pendingBuffer = null) {
  if (!entry || typeof entry.username !== 'string' || !entry.username.trim()) {
    return { ok: false, error: 'History entry requires a valid username.' };
  }

  const cleanUsername = String(entry.username).trim().replace(/^@/, '');
  const sessionId = String(entry.sessionId || (queueStateRef && queueStateRef.sessionId) || 'manual');
  const action = String(entry.action || 'unfollow');
  const result = String(entry.result || 'failed');
  const actionKey = `${sessionId}:${action}:${cleanUsername.toLowerCase()}:${result}`;

  if (loggedKeysSet instanceof Set) {
    if (loggedKeysSet.has(actionKey)) {
      return { ok: true, duplicatePrevented: true };
    }
    loggedKeysSet.add(actionKey);
  } else if (queueStateRef && Array.isArray(queueStateRef.loggedActionKeys)) {
    if (queueStateRef.loggedActionKeys.includes(actionKey)) {
      return { ok: true, duplicatePrevented: true };
    }
    queueStateRef.loggedActionKeys.push(actionKey);
  }

  const sanitizedEntry = {
    id: entry.id || `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    username: cleanUsername,
    displayName: String(entry.displayName || '').trim(),
    action,
    result,
    timestamp: entry.timestamp || new Date().toISOString(),
    skipReason: String(entry.skipReason || ''),
    errorDetails: String(entry.errorDetails || ''),
    sessionId
  };

  if (Array.isArray(pendingBuffer)) {
    pendingBuffer.push(sanitizedEntry);
    return { ok: true, entry: sanitizedEntry, buffered: true };
  }

  const { actionHistory } = await chrome.storage.local.get(['actionHistory']);
  const list = Array.isArray(actionHistory) ? actionHistory : [];

  const recentDuplicate = list.slice(0, 50).some(
    (item) =>
      item.sessionId === sessionId &&
      item.action === action &&
      String(item.username).toLowerCase() === cleanUsername.toLowerCase() &&
      item.result === result &&
      result === 'success'
  );
  if (recentDuplicate) {
    return { ok: true, duplicatePrevented: true };
  }

  list.unshift(sanitizedEntry);
  if (list.length > MAX_HISTORY_RECORDS) {
    list.length = MAX_HISTORY_RECORDS;
  }
  await chrome.storage.local.set({ actionHistory: list });
  return { ok: true, entry: sanitizedEntry, totalHistory: list.length };
}

async function flushHistoryBuffer(pendingBuffer) {
  if (!Array.isArray(pendingBuffer) || pendingBuffer.length === 0) return;
  const { actionHistory } = await chrome.storage.local.get(['actionHistory']);
  const list = Array.isArray(actionHistory) ? actionHistory : [];
  for (let i = 0; i < pendingBuffer.length; i++) {
    list.unshift(pendingBuffer[i]);
  }
  pendingBuffer.length = 0;
  if (list.length > MAX_HISTORY_RECORDS) {
    list.length = MAX_HISTORY_RECORDS;
  }
  await chrome.storage.local.set({ actionHistory: list });
}

async function sendTabMessage(tabId, message) {
  if (!tabId || typeof chrome === 'undefined' || !chrome.tabs || !chrome.tabs.sendMessage) {
    return { ok: false, missingTab: true, error: 'Target TikTok tab is not available.' };
  }
  try {
    const res = await chrome.tabs.sendMessage(tabId, message);
    return res || { ok: false, error: 'Empty response from TikTok tab.' };
  } catch (_err) {
    return {
      ok: false,
      contentScriptMissing: true,
      error: 'Could not communicate with the TikTok tab (tab may have closed or been suspended).'
    };
  }
}

/**
 * Attempt to download CSV via chrome.downloads API or content-script DOM fallback.
 * Never claims 'downloaded' unless confirmed by the browser API or DOM trigger.
 */
async function performBrowserCsvDownload(filename, csvContent, targetTabId) {
  if (orchestrator.forceDownloadFailureForTest) {
    return {
      ok: false,
      status: 'failed',
      errorDetails: 'Simulated browser download failure. CSV data is safely preserved for retry.'
    };
  }

  // Tier 1: Try chrome.downloads.download if supported
  if (typeof chrome !== 'undefined' && chrome.downloads && typeof chrome.downloads.download === 'function') {
    try {
      const dataUrl = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csvContent);
      const downloadId = await new Promise((resolve, reject) => {
        try {
          const maybePromise = chrome.downloads.download(
            { url: dataUrl, filename, saveAs: false },
            (id) => {
              if (chrome.runtime && chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
              } else {
                resolve(id);
              }
            }
          );
          if (maybePromise && typeof maybePromise.then === 'function') {
            maybePromise.then(resolve).catch(reject);
          }
        } catch (err) {
          reject(err);
        }
      });

      if (downloadId !== undefined && downloadId !== null) {
        return {
          ok: true,
          status: 'downloaded',
          method: 'chrome_downloads_api',
          downloadId
        };
      }
    } catch (_downloadErr) {
      // Fall through to Tier 2 DOM download fallback for mobile browsers like Quetta
    }
  }

  // Tier 2: Content script DOM Blob download trigger in active TikTok tab
  if (targetTabId) {
    const domRes = await sendTabMessage(targetTabId, {
      type: 'TRIGGER_DOM_CSV_DOWNLOAD',
      filename,
      csvContent
    });
    if (domRes && domRes.ok && domRes.downloadedViaDom) {
      return {
        ok: true,
        status: 'downloaded',
        method: 'content_script_dom_blob'
      };
    }
  }

  // Tier 3: Preserved in local storage for one-tap manual / popup download retry
  return {
    ok: false,
    status: 'failed',
    errorDetails: 'Automatic background download was blocked or unsupported by the browser. CSV data is preserved — tap Retry CSV Download.'
  };
}

/**
 * Finalize session log and execute Automatic CSV Export (on Stop, Completion, or Limit Reached).
 * Prevents duplicate exports if Stop is pressed repeatedly for the same session.
 */
async function finalizeAndExportSessionCsv(triggerReason = 'stopped', forceRetry = false) {
  const { queueState, actionHistory, exportHistory } = await ensureStorageInitialized();
  const sessionId = queueState.sessionId || `sess-${Date.now()}`;
  const exportedIds = Array.isArray(queueState.exportedSessionIds) ? [...queueState.exportedSessionIds] : [];

  // Prevent duplicate export if already exported for this session (unless user clicked Retry)
  if (!forceRetry && exportedIds.includes(sessionId) && queueState.lastExport && queueState.lastExport.sessionId === sessionId) {
    return {
      ok: true,
      duplicateExportPrevented: true,
      exportRecord: queueState.lastExport
    };
  }

  const actionName = queueState.tabType === 'followers' ? 'remove_follower' : 'unfollow';
  const sessionRecords = (Array.isArray(actionHistory) ? actionHistory : [])
    .filter((item) => item.sessionId === sessionId);

  // Include any remaining pending or uncertain queue items that haven't been logged yet
  // so the CSV contains all recorded and queued session items with accurate statuses.
  const loggedUserSet = new Set(sessionRecords.map((r) => String(r.username).toLowerCase()));
  const combinedRecords = [...sessionRecords];

  for (const qItem of (queueState.queue || [])) {
    if (!qItem || !qItem.username) continue;
    const key = qItem.username.toLowerCase();
    if (loggedUserSet.has(key)) continue;
    loggedUserSet.add(key);

    const accurateResult = qItem.status === 'uncertain'
      ? 'uncertain'
      : qItem.status === 'skipped'
        ? 'skipped'
        : qItem.status === 'failed'
          ? 'failed'
          : 'pending'; // Never label an unverified or unexecuted item as 'success'

    combinedRecords.push({
      username: qItem.username,
      displayName: qItem.displayName || qItem.username,
      action: actionName,
      result: accurateResult,
      timestamp: new Date().toISOString(),
      sessionId,
      skipReason: accurateResult === 'pending' ? `unprocessed_at_${triggerReason}` : '',
      errorDetails: ''
    });
  }

  const now = new Date();
  const filename = (forceRetry && queueState.lastExport && queueState.lastExport.filename)
    ? queueState.lastExport.filename
    : `${BRAND_CONFIG.csvFilePrefix}-${formatCsvFilenameTimestamp(now)}.csv`;

  const csvContent = generateSessionCsvString(combinedRecords);
  const dlResult = await performBrowserCsvDownload(filename, csvContent, queueState.targetTabId);

  if (!exportedIds.includes(sessionId)) {
    exportedIds.push(sessionId);
  }

  const exportRecord = {
    id: `exp-${Date.now()}`,
    sessionId,
    filename,
    recordCount: combinedRecords.length,
    timestamp: now.toISOString(),
    triggerReason,
    status: dlResult.status, // 'downloaded' | 'failed'
    method: dlResult.method || 'preserved_in_storage',
    errorDetails: dlResult.errorDetails || ''
  };

  const updatedExportHistory = [
    exportRecord,
    ...(Array.isArray(exportHistory) ? exportHistory.filter((e) => e.sessionId !== sessionId || !forceRetry) : [])
  ].slice(0, 100);

  // Always preserve CSV data in storage even if the browser download fails
  await chrome.storage.local.set({
    exportHistory: updatedExportHistory,
    lastSessionCsv: {
      sessionId,
      filename,
      csvContent,
      recordCount: combinedRecords.length,
      timestamp: now.toISOString(),
      status: dlResult.status
    }
  });

  await saveCheckpoint({
    exportedSessionIds: exportedIds,
    lastExport: exportRecord
  });

  if (dlResult.ok) {
    await dispatchExtensionNotification(
      'export_completed',
      'Export Completed',
      `Saved ${filename} (${combinedRecords.length.toLocaleString()} records).`,
      sessionId
    );
  } else {
    await dispatchExtensionNotification(
      'export_failed',
      'Export Needs Retry',
      `Could not auto-download ${filename}. Your CSV is preserved locally — tap Retry CSV Download.`,
      sessionId
    );
  }

  return {
    ok: dlResult.ok,
    duplicateExportPrevented: false,
    exportRecord,
    csvContent
  };
}

async function refreshTabAndWait(tabId, timeoutMs = 8000) {
  const { queueState } = await chrome.storage.local.get(['queueState']);
  const qs = queueState || { ...DEFAULT_QUEUE_STATE };

  if (qs.hasUncertainActionInFlight) {
    return {
      ok: false,
      error: 'Refused to refresh page while an action has an uncertain outcome. Verify current account state first.'
    };
  }

  const refreshCount = Number(qs.refreshCount || 0);
  if (refreshCount >= 2) {
    return {
      ok: false,
      refreshLimitReached: true,
      error: 'Maximum automatic refresh limit (2 per session) reached to prevent refresh loops.'
    };
  }

  await saveCheckpoint({
    expectedRefreshTabId: tabId,
    refreshCount: refreshCount + 1
  });

  if (!chrome.tabs || typeof chrome.tabs.reload !== 'function') {
    return { ok: false, error: 'Chrome tabs reload API unavailable.' };
  }

  return new Promise((resolve) => {
    let settled = false;
    const timer = setTimeout(async () => {
      if (settled) return;
      settled = true;
      if (chrome.tabs.onUpdated && chrome.tabs.onUpdated.removeListener) {
        chrome.tabs.onUpdated.removeListener(onUpdatedListener);
      }
      await saveCheckpoint({ expectedRefreshTabId: null });
      resolve({ ok: true, timedOutWaitingComplete: true, tabId });
    }, timeoutMs);

    async function onUpdatedListener(updatedTabId, changeInfo, tab) {
      if (updatedTabId !== tabId) return;
      if (changeInfo.status === 'complete') {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        if (chrome.tabs.onUpdated && chrome.tabs.onUpdated.removeListener) {
          chrome.tabs.onUpdated.removeListener(onUpdatedListener);
        }
        await saveCheckpoint({ expectedRefreshTabId: null });
        resolve({
          ok: true,
          tabId,
          url: (tab && tab.url) || changeInfo.url || ''
        });
      }
    }

    if (chrome.tabs.onUpdated && chrome.tabs.onUpdated.addListener) {
      chrome.tabs.onUpdated.addListener(onUpdatedListener);
    }

    Promise.resolve(chrome.tabs.reload(tabId)).catch(async (err) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (chrome.tabs.onUpdated && chrome.tabs.onUpdated.removeListener) {
        chrome.tabs.onUpdated.removeListener(onUpdatedListener);
      }
      await saveCheckpoint({ expectedRefreshTabId: null });
      resolve({ ok: false, error: err && err.message ? err.message : 'Tab reload failed.' });
    });
  });
}

function evaluateAccountEligibility(account, skipMutuals) {
  if (!account || !account.username) {
    return { eligible: false, reason: 'invalid_account' };
  }
  if (account.relationshipState === 'not_following' || account.relationshipState === 'removed') {
    return { eligible: false, reason: 'already_processed_in_dom' };
  }
  if (skipMutuals) {
    if (account.mutualStatus === 'mutual') {
      return { eligible: false, reason: 'mutual_protected' };
    }
    if (account.mutualStatus === 'unknown') {
      return { eligible: false, reason: 'mutual_status_uncertain' };
    }
  }
  return { eligible: true, reason: null };
}

async function enqueueDiscoveredBatch(qs, settings, discoveredList, discoveredSet, queuedSet, processedSet, loggedKeysSet, historyBuffer) {
  const limit = Number(settings.maxActionsPerSession || 100);
  const tabType = qs.tabType || 'following';
  const actionName = tabType === 'followers' ? 'remove_follower' : 'unfollow';
  let newlyQueuedCount = 0;

  for (const acc of (Array.isArray(discoveredList) ? discoveredList : [])) {
    if (!acc || !acc.username) continue;
    const key = String(acc.username).trim().replace(/^@/, '').toLowerCase();
    if (!key) continue;

    const isNewDiscovery = !discoveredSet.has(key);
    if (isNewDiscovery) {
      discoveredSet.add(key);
      qs.counts.scanned = discoveredSet.size;
    }

    if (queuedSet.has(key) || processedSet.has(key)) {
      continue;
    }

    const elig = evaluateAccountEligibility(acc, settings.skipMutuals);
    if (!elig.eligible) {
      if (isNewDiscovery && (elig.reason === 'mutual_protected' || elig.reason === 'mutual_status_uncertain')) {
        processedSet.add(key);
        qs.counts.skipped = (qs.counts.skipped || 0) + 1;
        if (elig.reason === 'mutual_protected') {
          qs.counts.mutualProtected = (qs.counts.mutualProtected || 0) + 1;
        } else {
          qs.counts.uncertainSkipped = (qs.counts.uncertainSkipped || 0) + 1;
        }
        await appendHistoryEntryIdempotent({
          username: acc.username,
          displayName: acc.displayName || acc.username,
          action: actionName,
          result: 'skipped',
          skipReason: elig.reason,
          sessionId: qs.sessionId
        }, qs, loggedKeysSet, historyBuffer);
      }
      continue;
    }

    if ((qs.counts.queued || 0) >= limit) {
      continue;
    }

    qs.queue.push({
      username: acc.username,
      displayName: acc.displayName || acc.username,
      mutualStatus: acc.mutualStatus || 'non_mutual',
      status: 'pending'
    });
    queuedSet.add(key);
    qs.counts.queued = (qs.counts.queued || 0) + 1;
    qs.counts.total = qs.counts.queued;
    qs.counts.pending = (qs.counts.pending || 0) + 1;
    newlyQueuedCount++;
  }

  return newlyQueuedCount;
}

/**
 * Reconcile persisted queue with live TikTok page state before continuing
 * after Android OS suspension, service worker restart, or manual CAPTCHA resolution.
 */
async function reconcileQueueWithPage(qs) {
  if (qs.isSimulatedData || !qs.targetTabId) {
    qs.hasUncertainActionInFlight = false;
    qs.inFlightUsername = null;
    return { ok: true, reconciled: true };
  }

  const processedSet = new Set((qs.processedUsernames || []).map((u) => u.toLowerCase()));

  const candidatesToVerify = new Set([
    ...(Array.isArray(qs.uncertainUsernames) ? qs.uncertainUsernames : []),
    ...(qs.inFlightUsername ? [qs.inFlightUsername] : [])
  ]);

  const remainingUncertain = [];
  for (const username of candidatesToVerify) {
    if (!username) continue;
    const key = username.toLowerCase();
    const ver = await sendTabMessage(qs.targetTabId, {
      type: 'VERIFY_ACCOUNT_STATE',
      username,
      listType: qs.tabType || 'following'
    });

    if (ver && ver.ok && ver.actionCompleted) {
      const qItem = (qs.queue || []).find((i) => i.username.toLowerCase() === key);
      if (qItem && qItem.status !== 'success') {
        if (qItem.status === 'pending') {
          qs.counts.pending = Math.max(0, (qs.counts.pending || 1) - 1);
        } else if (qItem.status === 'uncertain') {
          qs.counts.uncertain = Math.max(0, (qs.counts.uncertain || 1) - 1);
        }
        qItem.status = 'success';
      }
      if (!processedSet.has(key)) {
        processedSet.add(key);
        qs.counts.success = (qs.counts.success || 0) + 1;
        const nowIso = new Date().toISOString();
        qs.lastSuccessfulAction = {
          username,
          displayName: username,
          action: qs.tabType === 'followers' ? 'remove_follower' : 'unfollow',
          timestamp: nowIso
        };
        await appendHistoryEntryIdempotent({
          username,
          displayName: username,
          action: qs.tabType === 'followers' ? 'remove_follower' : 'unfollow',
          result: 'success',
          timestamp: nowIso,
          sessionId: qs.sessionId
        }, qs);
      }
    } else if (qs.uncertainUsernames && qs.uncertainUsernames.includes(username)) {
      remainingUncertain.push(username);
    }
  }

  qs.processedUsernames = Array.from(processedSet);
  qs.uncertainUsernames = remainingUncertain;
  qs.hasUncertainActionInFlight = false;
  qs.inFlightUsername = null;
  return { ok: true, reconciled: true };
}

/**
 * Helper to pause on CAPTCHA / Verification and start the passive resolution watcher in content.js.
 */
async function triggerVerificationPause(qs, challengeType, message) {
  const haltStatus = challengeType === 'rate_limited' ? 'rate_limited' : 'verification_required';
  const warnText = message || 'TikTok verification challenge detected. Complete verification manually in the browser, then tap Resume.';
  await saveCheckpoint({
    status: haltStatus,
    executionState: 'awaiting_verification',
    inFlightUsername: null,
    captchaResolvedReadyToResume: false,
    securityWarning: warnText
  });
  if (haltStatus === 'rate_limited') {
    await dispatchExtensionNotification(
      'rate_limit_detected',
      'Rate Limit Detected',
      warnText,
      qs.sessionId
    );
  } else {
    await dispatchExtensionNotification(
      'verification_required',
      'Verification Required',
      warnText,
      qs.sessionId
    );
  }
  if (qs.targetTabId) {
    await sendTabMessage(qs.targetTabId, {
      type: 'START_CAPTCHA_WATCHER',
      listType: qs.tabType || 'following'
    });
  }
}

/**
 * 16-Step Background Task Orchestrator Loop.
 */
async function runBackgroundSessionLoop() {
  if (orchestrator.isLoopRunning) return;
  orchestrator.isLoopRunning = true;
  const loopToken = ++orchestrator.activeLoopToken;
  const loopStartWallClock = Date.now();
  const historyBuffer = [];

  try {
    let { queueState: qs, settings: s } = await ensureStorageInitialized();
    const tabType = qs.tabType || 'following';
    const actionName = tabType === 'followers' ? 'remove_follower' : 'unfollow';

    const discoveredSet = new Set((qs.discoveredUsernames || []).map((u) => u.toLowerCase()));
    const processedSet = new Set((qs.processedUsernames || []).map((u) => u.toLowerCase()));
    const queuedSet = new Set((qs.queue || []).map((i) => i.username.toLowerCase()));
    const loggedKeysSet = new Set(Array.isArray(qs.loggedActionKeys) ? qs.loggedActionKeys : []);

    let queueCursor = 0;

    await reconcileQueueWithPage(qs);

    if (!qs.isSimulatedData && s.autoScan) {
      qs = await saveCheckpoint({ status: 'scanning', executionState: 'actively_processing' });
      let inspectRes = await sendTabMessage(qs.targetTabId, { type: 'INSPECT_PAGE_STATE' });

      if (
        (!inspectRes || !inspectRes.ok) &&
        !inspectRes?.unsupportedUrl &&
        s.autoRefresh &&
        (qs.refreshCount || 0) < 1 &&
        !qs.hasUncertainActionInFlight &&
        qs.targetTabId
      ) {
        const refRes = await refreshTabAndWait(qs.targetTabId, 8000);
        if (orchestrator.activeLoopToken !== loopToken) return;
        if (refRes && refRes.ok) {
          await cancelableSleep(450);
          inspectRes = await sendTabMessage(qs.targetTabId, { type: 'INSPECT_PAGE_STATE' });
        }
      }

      if (orchestrator.activeLoopToken !== loopToken) return;

      if (!inspectRes || !inspectRes.ok) {
        await saveCheckpoint({
          status: 'failed',
          executionState: 'standby',
          automationActive: false,
          interruptionReason: (inspectRes && inspectRes.error) || 'Target TikTok tab is unavailable.'
        });
        await dispatchExtensionNotification(
          'browser_recovery_required',
          'Browser Recovery Required',
          (inspectRes && inspectRes.error) || 'Target TikTok tab is unavailable.',
          qs.sessionId
        );
        return;
      }

      if (inspectRes.securityChallenge && inspectRes.securityChallenge.detected) {
        await triggerVerificationPause(qs, inspectRes.securityChallenge.type, inspectRes.securityChallenge.message);
        return;
      }

      if (inspectRes.loggedOut) {
        await triggerVerificationPause(qs, 'verification_required', 'TikTok login required before scanning or processing.');
        return;
      }

      if (inspectRes.profileContext && inspectRes.profileContext.unavailable) {
        await saveCheckpoint({
          status: 'failed',
          executionState: 'standby',
          automationActive: false,
          interruptionReason: inspectRes.profileContext.unavailableReason || 'TikTok profile is unavailable.'
        });
        return;
      }

      if (inspectRes.profileContext && inspectRes.profileContext.profileUsername) {
        qs.profileUsername = inspectRes.profileContext.profileUsername;
      }

      const listMatches = inspectRes.hasOpenList &&
        (inspectRes.activeModalTab === tabType || inspectRes.activeModalTab === 'unknown');

      if (!listMatches) {
        const openRes = await sendTabMessage(qs.targetTabId, { type: 'OPEN_PROFILE_LIST', listType: tabType });
        if (orchestrator.activeLoopToken !== loopToken) return;
        if (!openRes || !openRes.ok) {
          if (openRes && openRes.securityHalt) {
            await triggerVerificationPause(qs, openRes.challengeType, openRes.securityWarning);
            return;
          }
          await saveCheckpoint({
            status: 'failed',
            executionState: 'standby',
            automationActive: false,
            interruptionReason: (openRes && openRes.error) || `Could not open ${tabType} list automatically.`
          });
          return;
        }
      }

      const initialScan = await sendTabMessage(qs.targetTabId, {
        type: 'SCAN_ACCOUNTS',
        listType: tabType,
        options: { resetDiscoveryCache: qs.counts.scanned === 0 }
      });

      if (orchestrator.activeLoopToken !== loopToken) return;
      if (!initialScan || !initialScan.ok) {
        if (initialScan && initialScan.securityHalt) {
          await triggerVerificationPause(qs, initialScan.challengeType, initialScan.securityWarning);
          return;
        }
        await saveCheckpoint({
          status: 'failed',
          executionState: 'standby',
          automationActive: false,
          interruptionReason: (initialScan && initialScan.error) || 'Initial scan failed.'
        });
        return;
      }

      await enqueueDiscoveredBatch(qs, s, initialScan.accounts || [], discoveredSet, queuedSet, processedSet, loggedKeysSet, historyBuffer);
      await flushHistoryBuffer(historyBuffer);
      qs = await saveCheckpoint({
        profileUsername: qs.profileUsername,
        queue: qs.queue,
        discoveredUsernames: Array.from(discoveredSet),
        processedUsernames: Array.from(processedSet),
        loggedActionKeys: Array.from(loggedKeysSet),
        counts: qs.counts
      });
    }

    // Main incremental loop
    while (orchestrator.activeLoopToken === loopToken) {
      const configuredLimit = Number(s.maxActionsPerSession || 100);

      if (!['scanning', 'processing'].includes(normalizeQueueStatus(qs.status))) {
        break;
      }

      if ((qs.counts.success || 0) >= configuredLimit) {
        await flushHistoryBuffer(historyBuffer);
        updateLiveMetrics(qs, configuredLimit);
        const report = `Session limit reached (${qs.counts.success.toLocaleString()} / ${configuredLimit.toLocaleString()} completed in ${qs.metrics.elapsedFormatted}). Scanned: ${qs.counts.scanned.toLocaleString()}, Queued: ${qs.counts.queued.toLocaleString()}, Skipped: ${qs.counts.skipped.toLocaleString()} (${qs.counts.mutualProtected.toLocaleString()} mutuals protected), Failed: ${qs.counts.failed.toLocaleString()}.`;
        await saveCheckpoint({
          status: 'completed',
          executionState: 'standby',
          automationActive: false,
          scanOutcome: 'limit_reached',
          completionReport: report,
          discoveredUsernames: Array.from(discoveredSet),
          processedUsernames: Array.from(processedSet),
          loggedActionKeys: Array.from(loggedKeysSet),
          counts: qs.counts,
          metrics: qs.metrics
        });
        await dispatchExtensionNotification(
          'session_completed',
          'Session Completed',
          report,
          qs.sessionId
        );
        if (s.autoExportCsv !== false) {
          await finalizeAndExportSessionCsv('limit_reached', false);
        }
        break;
      }

      let nextItem = null;
      while (queueCursor < (qs.queue || []).length) {
        if (qs.queue[queueCursor].status === 'pending') {
          nextItem = qs.queue[queueCursor];
          break;
        }
        queueCursor++;
      }

      if (!nextItem) {
        const elapsedSec = (Date.now() - loopStartWallClock) / 1000;
        const reachedDurationLimit = elapsedSec >= (s.maxScanDurationSec || 3600);
        const reachedQueueCap = (qs.counts.queued || 0) >= configuredLimit;

        if (!s.autoScroll || reachedDurationLimit || reachedQueueCap) {
          await flushHistoryBuffer(historyBuffer);
          updateLiveMetrics(qs, configuredLimit);
          const reasonText = reachedQueueCap
            ? `Processed all ${qs.counts.queued.toLocaleString()} queued accounts for this session limit.`
            : reachedDurationLimit
              ? `Reached maximum scan duration (${s.maxScanDurationSec}s).`
              : 'All queued accounts processed.';
          const report = `${reasonText} Scanned: ${qs.counts.scanned.toLocaleString()}, Completed: ${qs.counts.success.toLocaleString()}, Skipped: ${qs.counts.skipped.toLocaleString()} (${qs.counts.mutualProtected.toLocaleString()} mutuals protected), Failed: ${qs.counts.failed.toLocaleString()} in ${qs.metrics.elapsedFormatted}.`;
          await saveCheckpoint({
            status: 'completed',
            executionState: 'standby',
            automationActive: false,
            scanOutcome: reachedQueueCap ? 'limit_reached' : reachedDurationLimit ? 'max_duration_reached' : 'completed',
            completionReport: report,
            discoveredUsernames: Array.from(discoveredSet),
            processedUsernames: Array.from(processedSet),
            loggedActionKeys: Array.from(loggedKeysSet),
            counts: qs.counts,
            metrics: qs.metrics
          });
          await dispatchExtensionNotification(
            'session_completed',
            'Session Completed',
            report,
            qs.sessionId
          );
          if (s.autoExportCsv !== false) {
            await finalizeAndExportSessionCsv('completed', false);
          }
          break;
        }

        let scrollRes;
        if (qs.isSimulatedData) {
          const totalSimAvailable = Number(qs.simulatedTotalAvailable || Math.max(configuredLimit * 2, 100));
          if (discoveredSet.size < totalSimAvailable) {
            const batchSize = Math.min(500, totalSimAvailable - discoveredSet.size);
            const simBatch = [];
            for (let b = 0; b < batchSize; b++) {
              const idx = discoveredSet.size + b + 1;
              const isMutual = idx % 10 === 0;
              const isUnknown = !isMutual && (idx % 25 === 0);
              simBatch.push({
                username: `sim.user.${idx}`,
                displayName: `Simulated User ${idx}`,
                mutualStatus: isMutual ? 'mutual' : isUnknown ? 'unknown' : 'non_mutual',
                relationshipState: isMutual ? 'friends' : isUnknown ? 'unknown' : (tabType === 'followers' ? 'follower_only' : 'following'),
                buttonText: isMutual ? 'Friends' : isUnknown ? '...' : (tabType === 'followers' ? 'Follow back' : 'Following')
              });
            }
            scrollRes = {
              ok: true,
              scrollStatus: 'loaded_more',
              accounts: simBatch,
              newlyDiscovered: simBatch
            };
          } else {
            scrollRes = {
              ok: true,
              scrollStatus: 'exhausted',
              accounts: [],
              newlyDiscovered: []
            };
          }
        } else {
          qs = await saveCheckpoint({ status: 'scanning', executionState: 'actively_processing' });
          scrollRes = await sendTabMessage(qs.targetTabId, {
            type: 'SCROLL_AND_SCAN',
            listType: tabType,
            options: { maxRetries: 3, retryDelayMs: 320 }
          });
        }

        if (orchestrator.activeLoopToken !== loopToken) break;

        if (!scrollRes || !scrollRes.ok) {
          await flushHistoryBuffer(historyBuffer);
          if (scrollRes && scrollRes.securityHalt) {
            await triggerVerificationPause(qs, scrollRes.challengeType, scrollRes.securityWarning);
            break;
          }
          if (scrollRes && scrollRes.scrollStatus === 'modal_closed') {
            const msg = scrollRes.error || 'TikTok account list closed during scrolling. Verify and resume.';
            await saveCheckpoint({
              status: 'recovering',
              interruptionReason: msg
            });
            await dispatchExtensionNotification(
              'browser_recovery_required',
              'Browser Recovery Required',
              msg,
              qs.sessionId
            );
            break;
          }
          await saveCheckpoint({
            status: 'failed',
            executionState: 'standby',
            automationActive: false,
            interruptionReason: (scrollRes && scrollRes.error) || 'List scrolling failed.'
          });
          break;
        }

        await enqueueDiscoveredBatch(
          qs,
          s,
          scrollRes.newlyDiscovered || scrollRes.accounts || [],
          discoveredSet,
          queuedSet,
          processedSet,
          loggedKeysSet,
          historyBuffer
        );

        if (!qs.isSimulatedData || s.minDelayMs > 0) {
          await flushHistoryBuffer(historyBuffer);
          qs = await saveCheckpoint({
            queue: qs.queue,
            discoveredUsernames: Array.from(discoveredSet),
            processedUsernames: Array.from(processedSet),
            loggedActionKeys: Array.from(loggedKeysSet),
            counts: qs.counts
          });
        }

        const hasPendingNow = queueCursor < (qs.queue || []).length;
        if (!hasPendingNow && (scrollRes.scrollStatus === 'exhausted' || scrollRes.scrollStatus === 'stalled')) {
          await flushHistoryBuffer(historyBuffer);
          updateLiveMetrics(qs, configuredLimit);
          const endReason = scrollRes.scrollStatus === 'stalled'
            ? 'List scrolling stalled after retries (no additional accounts loaded).'
            : 'List exhausted (no additional accounts available to load).';
          const report = `${endReason} Scanned: ${qs.counts.scanned.toLocaleString()}, Queued: ${qs.counts.queued.toLocaleString()}, Completed: ${qs.counts.success.toLocaleString()}, Skipped: ${qs.counts.skipped.toLocaleString()} (${qs.counts.mutualProtected.toLocaleString()} mutuals protected), Failed: ${qs.counts.failed.toLocaleString()} in ${qs.metrics.elapsedFormatted}.`;
          await saveCheckpoint({
            status: 'completed',
            executionState: 'standby',
            automationActive: false,
            scanOutcome: scrollRes.scrollStatus,
            completionReport: report,
            discoveredUsernames: Array.from(discoveredSet),
            processedUsernames: Array.from(processedSet),
            loggedActionKeys: Array.from(loggedKeysSet),
            counts: qs.counts,
            metrics: qs.metrics
          });
          await dispatchExtensionNotification(
            'session_completed',
            'Session Completed',
            report,
            qs.sessionId
          );
          if (s.autoExportCsv !== false) {
            await finalizeAndExportSessionCsv('completed', false);
          }
          break;
        }

        continue;
      }

      const normUser = nextItem.username.toLowerCase();

      if (processedSet.has(normUser)) {
        nextItem.status = 'skipped';
        queueCursor++;
        qs.counts.skipped = (qs.counts.skipped || 0) + 1;
        qs.counts.pending = Math.max(0, (qs.counts.pending || 1) - 1);
        await appendHistoryEntryIdempotent({
          username: nextItem.username,
          displayName: nextItem.displayName,
          action: actionName,
          result: 'skipped',
          skipReason: 'duplicate_in_session',
          sessionId: qs.sessionId
        }, qs, loggedKeysSet, historyBuffer);
        continue;
      }

      qs.inFlightUsername = nextItem.username;
      qs.status = 'processing';
      qs.executionState = 'actively_processing';

      let execResult;
      if (qs.isSimulatedData) {
        if (s.minDelayMs > 0) {
          await cancelableSleep(Math.min(25, s.minDelayMs));
        }
        if (orchestrator.activeLoopToken !== loopToken) break;
        const elig = evaluateAccountEligibility(nextItem, s.skipMutuals);
        if (!elig.eligible) {
          execResult = { ok: true, result: 'skipped', skipReason: elig.reason };
        } else {
          execResult = { ok: true, result: 'success' };
        }
      } else {
        await saveCheckpoint({ status: 'processing', executionState: 'actively_processing', inFlightUsername: nextItem.username });
        execResult = await sendTabMessage(qs.targetTabId, {
          type: 'EXECUTE_ACTION',
          payload: {
            username: nextItem.username,
            actionType: actionName,
            skipMutuals: s.skipMutuals,
            executionMode: s.executionMode,
            followerRemovalMethod: s.followerRemovalMethod,
            confirmedDestructive: true
          }
        });
      }

      if (orchestrator.activeLoopToken !== loopToken) break;

      if (execResult && execResult.securityHalt) {
        await appendHistoryEntryIdempotent({
          username: nextItem.username,
          displayName: nextItem.displayName,
          action: actionName,
          result: 'failed',
          errorDetails: execResult.errorDetails || 'Security challenge or rate limit detected',
          sessionId: qs.sessionId
        }, qs, loggedKeysSet, historyBuffer);
        await flushHistoryBuffer(historyBuffer);
        await triggerVerificationPause(qs, execResult.challengeType, execResult.errorDetails);
        break;
      }

      if (execResult && execResult.ok && execResult.result === 'success') {
        nextItem.status = 'success';
        queueCursor++;
        processedSet.add(normUser);
        qs.counts.success = (qs.counts.success || 0) + 1;
        qs.counts.pending = Math.max(0, (qs.counts.pending || 1) - 1);
        qs.consecutiveFailures = 0;
        qs.inFlightUsername = null;
        qs.hasUncertainActionInFlight = false;
        const nowIso = new Date().toISOString();
        qs.lastSuccessfulAction = {
          username: nextItem.username,
          displayName: nextItem.displayName || nextItem.username,
          action: actionName,
          timestamp: nowIso
        };

        await appendHistoryEntryIdempotent({
          username: nextItem.username,
          displayName: nextItem.displayName,
          action: actionName,
          result: 'success',
          timestamp: nowIso,
          sessionId: qs.sessionId
        }, qs, loggedKeysSet, historyBuffer);

        if (!qs.isSimulatedData || s.minDelayMs > 0 || qs.counts.success % 500 === 0 || qs.counts.success >= configuredLimit) {
          await flushHistoryBuffer(historyBuffer);
          qs = await saveCheckpoint({
            status: 'processing',
            executionState: 'actively_processing',
            lastSuccessfulAction: qs.lastSuccessfulAction,
            queue: qs.queue.slice(queueCursor),
            discoveredUsernames: Array.from(discoveredSet),
            processedUsernames: Array.from(processedSet),
            loggedActionKeys: Array.from(loggedKeysSet),
            counts: qs.counts,
            consecutiveFailures: 0,
            inFlightUsername: null,
            hasUncertainActionInFlight: false
          });
          queueCursor = 0;
        }
      } else if (execResult && execResult.ok && execResult.result === 'skipped') {
        nextItem.status = 'skipped';
        queueCursor++;
        processedSet.add(normUser);
        qs.counts.skipped = (qs.counts.skipped || 0) + 1;
        qs.counts.pending = Math.max(0, (qs.counts.pending || 1) - 1);
        qs.inFlightUsername = null;
        if (execResult.skipReason === 'mutual_protected') {
          qs.counts.mutualProtected = (qs.counts.mutualProtected || 0) + 1;
        } else if (execResult.skipReason === 'mutual_status_uncertain') {
          qs.counts.uncertainSkipped = (qs.counts.uncertainSkipped || 0) + 1;
        }

        await appendHistoryEntryIdempotent({
          username: nextItem.username,
          displayName: nextItem.displayName,
          action: actionName,
          result: 'skipped',
          skipReason: execResult.skipReason || 'skipped',
          sessionId: qs.sessionId
        }, qs, loggedKeysSet, historyBuffer);
      } else if (execResult && execResult.result === 'uncertain') {
        nextItem.status = 'uncertain';
        queueCursor++;
        qs.counts.uncertain = (qs.counts.uncertain || 0) + 1;
        qs.counts.pending = Math.max(0, (qs.counts.pending || 1) - 1);
        if (!Array.isArray(qs.uncertainUsernames)) qs.uncertainUsernames = [];
        if (!qs.uncertainUsernames.includes(normUser)) qs.uncertainUsernames.push(normUser);

        await appendHistoryEntryIdempotent({
          username: nextItem.username,
          displayName: nextItem.displayName,
          action: actionName,
          result: 'uncertain',
          errorDetails: execResult.errorDetails || 'Action outcome uncertain; verification required before retry.',
          sessionId: qs.sessionId
        }, qs, loggedKeysSet, historyBuffer);
        await flushHistoryBuffer(historyBuffer);

        const reasonMsg = execResult.errorDetails || `Outcome for @${nextItem.username} is uncertain. Re-verify page state before resuming.`;
        await saveCheckpoint({
          status: 'recovering',
          executionState: 'standby',
          hasUncertainActionInFlight: true,
          inFlightUsername: nextItem.username,
          uncertainUsernames: qs.uncertainUsernames,
          queue: qs.queue.slice(queueCursor),
          discoveredUsernames: Array.from(discoveredSet),
          processedUsernames: Array.from(processedSet),
          loggedActionKeys: Array.from(loggedKeysSet),
          counts: qs.counts,
          interruptionReason: reasonMsg
        });
        await dispatchExtensionNotification(
          'browser_recovery_required',
          'Browser Recovery Required',
          reasonMsg,
          qs.sessionId
        );
        break;
      } else {
        nextItem.status = 'failed';
        queueCursor++;
        qs.counts.failed = (qs.counts.failed || 0) + 1;
        qs.counts.pending = Math.max(0, (qs.counts.pending || 1) - 1);
        qs.consecutiveFailures = (qs.consecutiveFailures || 0) + 1;
        qs.inFlightUsername = null;
        const errText = (execResult && (execResult.errorDetails || execResult.error)) || 'Action verification failed.';

        await appendHistoryEntryIdempotent({
          username: nextItem.username,
          displayName: nextItem.displayName,
          action: actionName,
          result: 'failed',
          errorDetails: errText,
          sessionId: qs.sessionId
        }, qs, loggedKeysSet, historyBuffer);

        if (qs.consecutiveFailures >= 3) {
          await flushHistoryBuffer(historyBuffer);
          const pauseReason = `Paused automatically after ${qs.consecutiveFailures} consecutive failures: ${errText}`;
          await saveCheckpoint({
            status: 'paused',
            executionState: 'standby',
            queue: qs.queue.slice(queueCursor),
            discoveredUsernames: Array.from(discoveredSet),
            processedUsernames: Array.from(processedSet),
            loggedActionKeys: Array.from(loggedKeysSet),
            counts: qs.counts,
            consecutiveFailures: qs.consecutiveFailures,
            inFlightUsername: null,
            interruptionReason: pauseReason
          });
          await dispatchExtensionNotification(
            'session_paused',
            'Session Paused',
            pauseReason,
            qs.sessionId
          );
          break;
        }
      }

      if ((qs.counts.success || 0) >= configuredLimit) {
        await flushHistoryBuffer(historyBuffer);
        updateLiveMetrics(qs, configuredLimit);
        const report = `Session limit reached (${qs.counts.success.toLocaleString()} / ${configuredLimit.toLocaleString()} completed in ${qs.metrics.elapsedFormatted}). Scanned: ${qs.counts.scanned.toLocaleString()}, Queued: ${qs.counts.queued.toLocaleString()}, Skipped: ${qs.counts.skipped.toLocaleString()} (${qs.counts.mutualProtected.toLocaleString()} mutuals protected), Failed: ${qs.counts.failed.toLocaleString()}.`;
        await saveCheckpoint({
          status: 'completed',
          executionState: 'standby',
          automationActive: false,
          lastSuccessfulAction: qs.lastSuccessfulAction,
          scanOutcome: 'limit_reached',
          completionReport: report,
          queue: qs.queue.slice(queueCursor),
          discoveredUsernames: Array.from(discoveredSet),
          processedUsernames: Array.from(processedSet),
          loggedActionKeys: Array.from(loggedKeysSet),
          counts: qs.counts,
          metrics: qs.metrics
        });
        await dispatchExtensionNotification(
          'session_completed',
          'Session Completed',
          report,
          qs.sessionId
        );
        if (s.autoExportCsv !== false) {
          await finalizeAndExportSessionCsv('limit_reached', false);
        }
        break;
      }

      if (!qs.isSimulatedData || s.minDelayMs > 0) {
        const min = Math.max(0, Number(s.minDelayMs) || 0);
        const max = Math.max(min, Number(s.maxDelayMs) || min);
        const delayMs = qs.isSimulatedData ? min : Math.floor(min + Math.random() * (max - min + 1));
        if (delayMs > 0) {
          await cancelableSleep(delayMs);
        }
      }
    }
  } finally {
    await flushHistoryBuffer(historyBuffer);
    if (orchestrator.activeLoopToken === loopToken) {
      orchestrator.isLoopRunning = false;
    }
  }
}

async function recoverWorkerSessionIfNeeded() {
  if (orchestrator.isLoopRunning) {
    return { ok: true, alreadyRunning: true };
  }
  const { queueState } = await ensureStorageInitialized();
  if (
    queueState &&
    queueState.automationActive &&
    ['scanning', 'processing'].includes(normalizeQueueStatus(queueState.status))
  ) {
    runBackgroundSessionLoop();
    return { ok: true, recoveredAndResumed: true };
  }
  return { ok: true, recoveredAndResumed: false };
}

if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onInstalled) {
  chrome.runtime.onInstalled.addListener(() => {
    ensureStorageInitialized();
  });
}

if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onStartup) {
  chrome.runtime.onStartup.addListener(() => {
    recoverWorkerSessionIfNeeded();
  });
}

if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.onUpdated) {
  chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
    try {
      const { queueState } = await chrome.storage.local.get(['queueState']);
      if (!queueState || queueState.targetTabId !== tabId) return;

      if (queueState.expectedRefreshTabId === tabId) {
        return;
      }

      const activeStatuses = ['scanning', 'processing', 'running'];
      if (activeStatuses.includes(queueState.status)) {
        const isReloading = changeInfo.status === 'loading';
        const urlChanged = Boolean(changeInfo.url && queueState.targetUrl && changeInfo.url !== queueState.targetUrl);
        const leftTikTok = Boolean(
          (changeInfo.url && !/^https:\/\/(www|m)\.tiktok\.com\//i.test(changeInfo.url)) ||
          (tab && tab.url && !/^https:\/\/(www|m)\.tiktok\.com\//i.test(tab.url))
        );

        if (isReloading || urlChanged || leftTikTok) {
          orchestrator.activeLoopToken++;
          abortOrchestratorSleep();
          const reason = leftTikTok
            ? 'Tab navigated away from TikTok. Return to your TikTok profile and confirm recovery to resume.'
            : 'TikTok page reloaded or navigated during active session. Re-verify the profile and list before resuming.';
          await saveCheckpoint({
            status: 'recovering',
            executionState: 'standby',
            interruptionReason: reason
          });
          await dispatchExtensionNotification(
            'browser_recovery_required',
            'Browser Recovery Required',
            reason,
            queueState.sessionId
          );
        }
      }
    } catch (_err) {
      // Safe fallback
    }
  });
}

if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.onRemoved) {
  chrome.tabs.onRemoved.addListener(async (tabId) => {
    try {
      const { queueState } = await chrome.storage.local.get(['queueState']);
      if (!queueState || queueState.targetTabId !== tabId) return;

      if (['scanning', 'processing', 'running', 'paused'].includes(queueState.status)) {
        orchestrator.activeLoopToken++;
        abortOrchestratorSleep();
        const reason = 'The active TikTok tab was closed. Open TikTok, navigate to your profile, and confirm recovery to resume.';
        await saveCheckpoint({
          status: 'recovering',
          executionState: 'standby',
          targetTabId: null,
          interruptionReason: reason
        });
        await dispatchExtensionNotification(
          'browser_recovery_required',
          'Browser Recovery Required',
          reason,
          queueState.sessionId
        );
      }
    } catch (_err) {
      // Safe fallback
    }
  });
}

if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (!message || typeof message.type !== 'string') {
      sendResponse({ ok: false, error: 'Invalid message format.' });
      return false;
    }

    (async () => {
      try {
        switch (message.type) {
          case 'GET_STATE': {
            const state = await ensureStorageInitialized();
            if (
              state.queueState.automationActive &&
              ['scanning', 'processing'].includes(state.queueState.status) &&
              state.queueState.executionState !== 'suspended_by_os' &&
              !orchestrator.isLoopRunning
            ) {
              runBackgroundSessionLoop();
            }
            const sessionAnalytics = computeSessionAnalytics(
              state.actionHistory,
              state.exportHistory,
              state.queueState,
              state.sessionRegistry
            );
            sendResponse({
              ok: true,
              brandConfig: BRAND_CONFIG,
              isLoopRunning: orchestrator.isLoopRunning,
              settings: state.settings,
              queueState: state.queueState,
              actionHistory: state.actionHistory,
              exportHistory: state.exportHistory,
              lastSessionCsv: state.lastSessionCsv,
              sessionAnalytics
            });
            break;
          }

          case 'SAVE_SETTINGS': {
            const validation = validateSettings(message.settings);
            if (!validation.valid) {
              sendResponse({
                ok: false,
                errors: validation.errors,
                settings: validation.settings
              });
              return;
            }
            await chrome.storage.local.set({ settings: validation.settings });
            const { queueState } = await chrome.storage.local.get(['queueState']);
            if (queueState) {
              updateLiveMetrics(queueState, validation.settings.maxActionsPerSession);
              await chrome.storage.local.set({ queueState });
            }
            sendResponse({
              ok: true,
              settings: validation.settings
            });
            break;
          }

          case 'RESET_SETTINGS': {
            const freshSettings = { ...DEFAULT_SETTINGS };
            await chrome.storage.local.set({ settings: freshSettings });
            const { queueState } = await chrome.storage.local.get(['queueState']);
            if (queueState) {
              updateLiveMetrics(queueState, freshSettings.maxActionsPerSession);
              await chrome.storage.local.set({ queueState });
            }
            sendResponse({
              ok: true,
              settings: freshSettings
            });
            break;
          }

          case 'START_SESSION': {
            const { settings } = await ensureStorageInitialized();
            const opts = message.options && typeof message.options === 'object' ? message.options : {};
            const tabType = opts.tabType === 'followers' ? 'followers' : 'following';
            const limit = Number(settings.maxActionsPerSession || 100);
            const sessionId = opts.sessionId || `sess-${Date.now()}`;

            const preselected = Array.isArray(opts.initialQueue) ? opts.initialQueue : [];
            const prediscovered = Array.isArray(opts.discoveredAccounts) ? opts.discoveredAccounts : [];

            const discoveredSet = new Set();
            const queuedSet = new Set();
            const processedSet = new Set();
            const initialQueue = [];
            let mutualProtected = 0;
            let uncertainSkipped = 0;

            for (const acc of prediscovered) {
              if (!acc || !acc.username) continue;
              const k = acc.username.toLowerCase();
              discoveredSet.add(k);
              if (settings.skipMutuals) {
                if (acc.mutualStatus === 'mutual') mutualProtected++;
                else if (acc.mutualStatus === 'unknown') uncertainSkipped++;
              }
            }

            for (const item of preselected) {
              if (!item || !item.username) continue;
              const k = item.username.toLowerCase();
              if (queuedSet.has(k) || initialQueue.length >= limit) continue;
              const elig = evaluateAccountEligibility(item, settings.skipMutuals);
              if (!elig.eligible) continue;
              discoveredSet.add(k);
              queuedSet.add(k);
              initialQueue.push({
                username: item.username,
                displayName: item.displayName || item.username,
                mutualStatus: item.mutualStatus || 'non_mutual',
                status: 'pending'
              });
            }

            const now = Date.now();
            const newQueueState = await saveCheckpoint({
              status: initialQueue.length > 0 ? 'processing' : 'scanning',
              executionState: 'actively_processing',
              tabType,
              automationActive: true,
              isSimulatedData: Boolean(opts.isSimulatedData),
              simulatedTotalAvailable: Number(opts.simulatedTotalAvailable || Math.max(limit * 2, 100)),
              sessionId,
              targetTabId: opts.targetTabId || null,
              targetUrl: opts.targetUrl || null,
              profileUsername: opts.profileUsername || null,
              refreshCount: 0,
              hasUncertainActionInFlight: false,
              inFlightUsername: null,
              captchaResolvedReadyToResume: false,
              lastSuccessfulAction: null,
              lastExport: null,
              scanOutcome: null,
              queue: initialQueue,
              discoveredUsernames: Array.from(discoveredSet),
              processedUsernames: Array.from(processedSet),
              uncertainUsernames: [],
              loggedActionKeys: [],
              counts: {
                scanned: discoveredSet.size,
                queued: initialQueue.length,
                total: initialQueue.length,
                success: 0,
                skipped: 0,
                pending: initialQueue.length,
                failed: 0,
                uncertain: 0,
                mutualProtected,
                uncertainSkipped,
                configuredLimit: limit,
                remaining: limit
              },
              metrics: {
                sessionStartTime: now,
                accumulatedElapsedMs: 0,
                lastResumeTime: now,
                discoveredPerMin: 0,
                completedPerMin: 0,
                elapsedFormatted: '0s'
              },
              consecutiveFailures: 0,
              interruptionReason: null,
              securityWarning: null,
              completionReport: null
            });

            await dispatchExtensionNotification(
              'session_started',
              'Session Started',
              `Started ${tabType === 'followers' ? 'Follower Removal' : 'Unfollow'} session (limit: ${limit.toLocaleString()} actions).`,
              sessionId
            );

            runBackgroundSessionLoop();
            sendResponse({ ok: true, queueState: newQueueState });
            break;
          }

          case 'PAUSE_SESSION': {
            orchestrator.activeLoopToken++;
            abortOrchestratorSleep();
            const pausedState = await saveCheckpoint({
              status: 'paused',
              executionState: 'standby',
              interruptionReason: 'Paused by user.'
            });
            await dispatchExtensionNotification(
              'session_paused',
              'Session Paused',
              `Session paused at ${pausedState.counts?.success || 0} completed actions.`,
              pausedState.sessionId
            );
            sendResponse({ ok: true, queueState: pausedState });
            break;
          }

          case 'RESUME_SESSION': {
            const { queueState, settings } = await ensureStorageInitialized();
            await reconcileQueueWithPage(queueState);
            const hasPending = (queueState.queue || []).some((i) => i.status === 'pending');
            const resumedState = await saveCheckpoint({
              status: hasPending ? 'processing' : 'scanning',
              executionState: 'actively_processing',
              automationActive: true,
              captchaResolvedReadyToResume: false,
              securityWarning: null,
              queue: queueState.queue,
              processedUsernames: queueState.processedUsernames,
              uncertainUsernames: queueState.uncertainUsernames,
              hasUncertainActionInFlight: false,
              inFlightUsername: null,
              lastSuccessfulAction: queueState.lastSuccessfulAction,
              counts: queueState.counts,
              interruptionReason: null
            });
            if ((resumedState.counts.success || 0) < (settings.maxActionsPerSession || 100)) {
              runBackgroundSessionLoop();
            }
            sendResponse({ ok: true, queueState: resumedState });
            break;
          }

          case 'STOP_SESSION': {
            orchestrator.activeLoopToken++;
            abortOrchestratorSleep();
            const { queueState, settings } = await ensureStorageInitialized();

            // If Stop is pressed repeatedly on an already-stopped session, prevent duplicate export
            if (queueState.status === 'stopped' && queueState.lastExport && queueState.lastExport.sessionId === queueState.sessionId) {
              sendResponse({
                ok: true,
                duplicateExportPrevented: true,
                queueState,
                exportResult: {
                  ok: true,
                  duplicateExportPrevented: true,
                  exportRecord: queueState.lastExport
                }
              });
              return;
            }

            if (queueState.targetTabId) {
              await sendTabMessage(queueState.targetTabId, { type: 'CLEAR_GUIDED_OVERLAY' });
            }
            updateLiveMetrics(queueState, settings.maxActionsPerSession);
            const c = queueState.counts;
            const report = `Stopped by user after ${queueState.metrics.elapsedFormatted}. Scanned: ${c.scanned.toLocaleString()}, Queued: ${c.queued.toLocaleString()}, Completed: ${c.success.toLocaleString()}, Skipped: ${c.skipped.toLocaleString()}, Failed: ${c.failed.toLocaleString()}.`;

            await saveCheckpoint({
              status: 'stopped',
              executionState: 'standby',
              automationActive: false,
              inFlightUsername: null,
              interruptionReason: 'Stopped by user.',
              completionReport: report
            });

            // Automatically finalize session log and export CSV upon Stop
            const exportResult = await finalizeAndExportSessionCsv('stopped', false);
            const latest = await ensureStorageInitialized();
            sendResponse({
              ok: true,
              duplicateExportPrevented: exportResult.duplicateExportPrevented,
              queueState: latest.queueState,
              exportResult
            });
            break;
          }

          case 'RETRY_CSV_DOWNLOAD': {
            const retryRes = await finalizeAndExportSessionCsv('manual_retry', true);
            const latest = await ensureStorageInitialized();
            sendResponse({
              ok: retryRes.ok,
              queueState: latest.queueState,
              exportResult: retryRes
            });
            break;
          }

          case 'LIFECYCLE_VISIBILITY_CHANGE': {
            const { queueState } = await ensureStorageInitialized();
            const isHidden = Boolean(message.hidden);

            if (isHidden) {
              // Android app switch / browser backgrounded while task is active
              if (['scanning', 'processing'].includes(queueState.status)) {
                const reason = 'Browser or TikTok tab was backgrounded on Android. Progress checkpoint saved.';
                const updated = await saveCheckpoint({
                  executionState: 'suspended_by_os',
                  interruptionReason: reason
                });
                await dispatchExtensionNotification(
                  'browser_recovery_required',
                  'Task Suspended by Browser',
                  reason,
                  queueState.sessionId
                );
                sendResponse({ ok: true, queueState: updated });
                return;
              }
            } else {
              // User returned to Quetta / TikTok tab
              if (queueState.executionState === 'suspended_by_os') {
                await reconcileQueueWithPage(queueState);
                if (queueState.automationActive && ['scanning', 'processing'].includes(queueState.status)) {
                  const updated = await saveCheckpoint({
                    executionState: 'actively_processing',
                    interruptionReason: null,
                    queue: queueState.queue,
                    processedUsernames: queueState.processedUsernames,
                    counts: queueState.counts
                  });
                  if (!orchestrator.isLoopRunning) {
                    runBackgroundSessionLoop();
                  }
                  sendResponse({ ok: true, recoveredFromSuspension: true, queueState: updated });
                  return;
                } else {
                  const updated = await saveCheckpoint({
                    status: 'recovering',
                    executionState: 'standby',
                    interruptionReason: 'Session recovered after Android background suspension. Verify page state and tap Resume.'
                  });
                  sendResponse({ ok: true, recoveredFromSuspension: true, queueState: updated });
                  return;
                }
              }
            }
            sendResponse({ ok: true, queueState });
            break;
          }

          case 'CAPTCHA_RESOLVED_REVALIDATED': {
            const { queueState } = await ensureStorageInitialized();
            if (['verification_required', 'rate_limited'].includes(queueState.status)) {
              await reconcileQueueWithPage(queueState);
              const updated = await saveCheckpoint({
                status: 'paused',
                executionState: 'standby',
                captchaResolvedReadyToResume: true,
                securityWarning: null,
                interruptionReason: 'Verification challenge resolved and TikTok list revalidated. Tap Resume to continue.'
              });
              sendResponse({ ok: true, queueState: updated });
              return;
            }
            sendResponse({ ok: true, queueState });
            break;
          }

          case 'UPDATE_QUEUE_STATE': {
            const merged = await saveCheckpoint(message.queueState || {});
            sendResponse({ ok: true, queueState: merged });
            break;
          }

          case 'RESET_QUEUE_STATE': {
            orchestrator.activeLoopToken++;
            abortOrchestratorSleep();
            const { settings } = await ensureStorageInitialized();
            const reset = {
              ...DEFAULT_QUEUE_STATE,
              counts: createDefaultCounts(settings.maxActionsPerSession),
              metrics: createDefaultMetrics(),
              lastUpdated: new Date().toISOString()
            };
            await chrome.storage.local.set({ queueState: reset });
            await updateActionBadge(reset);
            sendResponse({ ok: true, queueState: reset });
            break;
          }

          case 'REFRESH_TAB_AND_WAIT': {
            const tabId = Number(message.tabId);
            if (!Number.isFinite(tabId)) {
              sendResponse({ ok: false, error: 'Valid tabId is required for REFRESH_TAB_AND_WAIT.' });
              return;
            }
            const res = await refreshTabAndWait(tabId, message.timeoutMs || 8000);
            sendResponse(res);
            break;
          }

          case 'APPEND_HISTORY_ENTRY': {
            const res = await appendHistoryEntryIdempotent(message.entry);
            sendResponse(res);
            break;
          }

          case 'CLEAR_HISTORY': {
            const scope = message.scope === 'session' ? 'session' : 'all';
            if (scope === 'session' && message.sessionId) {
              const { actionHistory, sessionRegistry } = await chrome.storage.local.get(['actionHistory', 'sessionRegistry']);
              const filtered = (Array.isArray(actionHistory) ? actionHistory : []).filter(
                (item) => item.sessionId !== message.sessionId
              );
              const reg = sessionRegistry && typeof sessionRegistry === 'object' ? { ...sessionRegistry } : {};
              delete reg[message.sessionId];
              await chrome.storage.local.set({ actionHistory: filtered, sessionRegistry: reg });
              sendResponse({ ok: true, actionHistory: filtered });
            } else {
              await chrome.storage.local.set({ actionHistory: [], sessionRegistry: {} });
              sendResponse({ ok: true, actionHistory: [] });
            }
            break;
          }

          case 'CONTENT_HEARTBEAT': {
            const rec = await recoverWorkerSessionIfNeeded();
            sendResponse(rec);
            break;
          }

          default:
            sendResponse({ ok: false, error: `Unknown message type: ${message.type}` });
        }
      } catch (err) {
        sendResponse({ ok: false, error: err && err.message ? err.message : 'Background worker error' });
      }
    })();

    return true;
  });
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    BRAND_CONFIG,
    MAX_SESSION_LIMIT,
    MAX_HISTORY_RECORDS,
    SESSION_LIMIT_PRESETS,
    VALID_QUEUE_STATES,
    DEFAULT_SETTINGS,
    DEFAULT_QUEUE_STATE,
    orchestrator,
    normalizeQueueStatus,
    computeExecutionState,
    formatCsvFilenameTimestamp,
    escapeCsvCell,
    generateSessionCsvString,
    validateSettings,
    dispatchExtensionNotification,
    computeSessionAnalytics,
    updateActionBadge,
    ensureStorageInitialized,
    saveCheckpoint,
    appendHistoryEntryIdempotent,
    finalizeAndExportSessionCsv,
    reconcileQueueWithPage,
    runBackgroundSessionLoop,
    recoverWorkerSessionIfNeeded,
    refreshTabAndWait
  };
}
