// ==========================================
// ✅ GET FULL COOKIE VIA chrome.cookies API
// (HttpOnly cookies সহ)
// ==========================================
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {

    // ==========================================
    // ✅ GET FULL COOKIE
    // ==========================================
    if (request.action === "getFullCookie") {
        console.log("🍪 Getting full cookies via chrome.cookies...");

        let allCookies = [];
        let pending = 3;

        const merge = (cookies) => {
            if (cookies && cookies.length > 0) {
                cookies.forEach(c => {
                    const key = c.name + "@" + c.domain;
                    // Remove duplicate
                    const idx = allCookies.findIndex(x => (x.name + "@" + x.domain) === key);
                    if (idx === -1) {
                        allCookies.push(c);
                    } else {
                        allCookies[idx] = c;
                    }
                });
            }
            pending--;
            if (pending <= 0) {
                // Build cookie string
                const cookieStr = allCookies.map(c => c.name + "=" + c.value).join("; ");

                const hasSessionId = allCookies.some(c => c.name === "sessionid");
                const hasRur = allCookies.some(c => c.name === "rur");
                const hasCsrf = allCookies.some(c => c.name === "csrftoken");
                const hasDsUserId = allCookies.some(c => c.name === "ds_user_id");
                const hasDatr = allCookies.some(c => c.name === "datr");
                const hasMid = allCookies.some(c => c.name === "mid");

                console.log("🍪 Total cookies: " + allCookies.length);
                console.log("  ds_user_id: " + hasDsUserId);
                console.log("  sessionid: " + hasSessionId);
                console.log("  rur: " + hasRur);
                console.log("  csrftoken: " + hasCsrf);
                console.log("  datr: " + hasDatr);
                console.log("  mid: " + hasMid);

                sendResponse({
                    success: true,
                    fullCookie: cookieStr,
                    count: allCookies.length,
                    hasSessionId: hasSessionId,
                    hasRur: hasRur,
                    hasCsrf: hasCsrf,
                    hasDsUserId: hasDsUserId
                });
            }
        };

        chrome.cookies.getAll({ domain: ".instagram.com" }, (c1) => merge(c1));
        chrome.cookies.getAll({ domain: "instagram.com" }, (c2) => merge(c2));
        chrome.cookies.getAll({ domain: "www.instagram.com" }, (c3) => merge(c3));

        return true;
    }

    // ==========================================
    // ✅ NUCLEAR DATA CLEAR (আপনার পুরনো কাজ করা কোড)
    // ==========================================
    if (request.action === "clearData") {
        console.log("⚡ NUCLEAR CLEAR START ⚡");

        let pending = 7;
        let responded = false;

        const sendResponseOnce = (status) => {
            if (responded) return;
            responded = true;
            try { sendResponse({ status: status }); } catch (e) {}
        };

        const done = (label) => {
            pending--;
            console.log("✅ " + label + " (pending: " + pending + ")");
            if (pending <= 0) {
                console.log("✅✅✅ ALL CLEARED!");
                sendResponseOnce("done");
            }
        };

        // TASK 1
        try {
            chrome.cookies.getAll({}, (cookies) => {
                const targets = (cookies || []).filter(c => {
                    if (!c.domain) return false;
                    const d = c.domain.toLowerCase();
                    return d.includes("instagram") || d.includes("facebook") ||
                           d.includes("meta") || d.includes("cdninstagram") ||
                           d.includes("fbcdn") || d.includes("fb.com");
                });

                console.log("🍪 PASS 1: " + targets.length + " cookies");

                if (targets.length === 0) { done("cookies-pass1"); return; }

                let n = 0;
                const total = targets.length;

                targets.forEach(c => {
                    const domain = c.domain.replace(/^\./, "");
                    const urls = [
                        "https://" + domain + c.path,
                        "http://" + domain + c.path,
                        "https://" + domain + "/",
                        "http://" + domain + "/"
                    ];
                    let urlsDone = 0;
                    urls.forEach(url => {
                        try {
                            chrome.cookies.remove({ url: url, name: c.name }, () => {
                                urlsDone++;
                                if (urlsDone >= 4) {
                                    n++;
                                    if (n >= total) done("cookies-pass1");
                                }
                            });
                        } catch (e) {
                            urlsDone++;
                            if (urlsDone >= 4) {
                                n++;
                                if (n >= total) done("cookies-pass1");
                            }
                        }
                    });
                });
            });
        } catch (e) { done("cookies-pass1 (err)"); }

        // TASK 2
        try {
            chrome.browsingData.removeCookies({
                "origins": [
                    "https://www.instagram.com",
                    "https://instagram.com",
                    "https://m.instagram.com",
                    "https://www.facebook.com",
                    "https://facebook.com",
                    "https://auth.meta.com"
                ]
            }, () => { done("removeCookies"); });
        } catch (e) { done("removeCookies (err)"); }

        // TASK 3
        try {
            chrome.browsingData.remove({
                "origins": [
                    "https://www.instagram.com",
                    "https://instagram.com",
                    "https://www.facebook.com",
                    "https://facebook.com"
                ]
            }, {
                "cache": true,
                "cacheStorage": true,
                "cookies": true,
                "fileSystems": true,
                "indexedDB": true,
                "localStorage": true,
                "passwords": false,
                "serviceWorkers": true,
                "webSQL": true
            }, () => { done("browsingData-specific"); });
        } catch (e) { done("browsingData-specific (err)"); }

        // TASK 4
        try {
            chrome.browsingData.remove({
                "since": 0
            }, {
                "cache": true,
                "cacheStorage": true,
                "cookies": false,
                "fileSystems": true,
                "indexedDB": true,
                "localStorage": false,
                "serviceWorkers": true
            }, () => { done("globalCache"); });
        } catch (e) { done("globalCache (err)"); }

        // TASK 5
        setTimeout(() => {
            try {
                chrome.cookies.getAll({}, (cookies) => {
                    const targets = (cookies || []).filter(c => {
                        if (!c.domain) return false;
                        const d = c.domain.toLowerCase();
                        return d.includes("instagram") || d.includes("facebook") || d.includes("meta");
                    });
                    console.log("🍪 PASS 2: " + targets.length + " cookies");
                    if (targets.length === 0) { done("cookies-pass2"); return; }
                    let n = 0;
                    const total = targets.length;
                    targets.forEach(c => {
                        const domain = c.domain.replace(/^\./, "");
                        try {
                            chrome.cookies.remove({ url: "https://" + domain, name: c.name }, () => {
                                n++;
                                if (n >= total) done("cookies-pass2");
                            });
                        } catch (e) {
                            n++;
                            if (n >= total) done("cookies-pass2");
                        }
                    });
                });
            } catch (e) { done("cookies-pass2 (err)"); }
        }, 400);

        // TASK 6
        setTimeout(() => {
            try {
                chrome.cookies.getAll({}, (cookies) => {
                    const targets = (cookies || []).filter(c => {
                        if (!c.domain) return false;
                        const d = c.domain.toLowerCase();
                        return d.includes("instagram") || d.includes("facebook") || d.includes("meta");
                    });
                    console.log("🍪 PASS 3: " + targets.length + " cookies");
                    if (targets.length === 0) { done("cookies-pass3"); return; }
                    let n = 0;
                    const total = targets.length;
                    targets.forEach(c => {
                        const domain = c.domain.replace(/^\./, "");
                        try {
                            chrome.cookies.remove({ url: "http://" + domain + c.path, name: c.name }, () => {
                                n++;
                                if (n >= total) done("cookies-pass3");
                            });
                        } catch (e) {
                            n++;
                            if (n >= total) done("cookies-pass3");
                        }
                    });
                });
            } catch (e) { done("cookies-pass3 (err)"); }
        }, 800);

        // TASK 7
        setTimeout(() => {
            try {
                chrome.cookies.getAll({}, (cookies) => {
                    const remaining = (cookies || []).filter(c => {
                        if (!c.domain) return false;
                        const d = c.domain.toLowerCase();
                        return d.includes("instagram") || d.includes("facebook") || d.includes("meta");
                    });
                    console.log("🍪 FINAL CHECK: " + remaining.length + " cookies remaining");
                    if (remaining.length > 0) {
                        remaining.forEach(c => {
                            console.log("   ⚠️ Still: " + c.name + " @ " + c.domain);
                        });
                    }
                    done("final-check");
                });
            } catch (e) { done("final-check (err)"); }
        }, 1500);

        // SAFETY TIMEOUT
        setTimeout(() => {
            if (!responded) {
                console.log("⚠️ SAFETY TIMEOUT");
                sendResponseOnce("timeout-done");
            }
        }, 4000);

        return true;
    }

    if (request.action === "getSuccess") {
        chrome.storage.local.get(['successEmails'], (d) => {
            sendResponse({ emails: d.successEmails || [] });
        });
        return true;
    }
});