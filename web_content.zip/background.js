// ABUSE BYPASSER v1.0

let logs = [];
let stats = { bypassed: 0, detected: 0 };

// Open dashboard on icon click
chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html') });
});

// Open dashboard on install
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ logs: [], stats: { bypassed: 0, detected: 0 } });
});

// Handle messages - DON'T return true unless async response needed
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  
  if (message.action === 'log' && message.log) {
    // Add log entry
    const entry = {
      type: message.log.type || 'info',
      message: message.log.message || '',
      url: message.log.url || '',
      pageUrl: sender.tab?.url || '',
      tabId: sender.tab?.id,
      timestamp: message.log.time || Date.now()
    };
    
    logs.push(entry);
    if (entry.type === 'bypass') stats.bypassed++;
    if (entry.type === 'detect') stats.detected++;
    
    // Keep last 500
    while (logs.length > 500) logs.shift();
    
    // Save to storage
    chrome.storage.local.set({ logs, stats });
    
    // No response needed - don't return true
    return;
  }
  
  if (message.action === 'getLogs') {
    sendResponse({ logs, stats });
    return; // Sync response
  }
  
  if (message.action === 'clearLogs') {
    logs = [];
    stats = { bypassed: 0, detected: 0 };
    chrome.storage.local.set({ logs, stats });
    return;
  }
});

// Load logs from storage on startup
chrome.storage.local.get(['logs', 'stats'], (result) => {
  if (result.logs) logs = result.logs;
  if (result.stats) stats = result.stats;
});
