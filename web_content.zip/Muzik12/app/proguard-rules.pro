# Release derlemesinde minifyEnabled kapalı; şimdilik ek kural gerekmiyor.
