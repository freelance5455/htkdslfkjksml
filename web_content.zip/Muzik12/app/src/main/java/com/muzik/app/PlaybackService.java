package com.muzik.app;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.util.Size;

import androidx.annotation.OptIn;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.Timeline;
import androidx.media3.common.util.BitmapLoader;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.session.MediaSession;
import androidx.media3.session.MediaSessionService;

import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.ListeningExecutorService;
import com.google.common.util.concurrent.MoreExecutors;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;

/**
 * Arka planda çalma servisi (Media3 ExoPlayer + MediaSession).
 * Kilit ekranı, bildirim paneli ve kulaklık/Bluetooth düğmeleri MediaSession ile çalışır.
 * Kuyruk, şarkı ve konum kaydedilir; uygulama/servis kapanıp açılınca kaldığı yerden devam eder.
 */
@OptIn(markerClass = UnstableApi.class)
public class PlaybackService extends MediaSessionService {

    private static final String TAG = "MuzikPlayback";
    private static final String PREFS = "muzik_state";

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private MediaSession mediaSession;
    private ExoPlayer player;
    private SharedPreferences prefs;
    private boolean destroyed = false;
    private int errorStreak = 0;

    private final Runnable periodicSave = new Runnable() {
        @Override
        public void run() {
            savePosition();
            mainHandler.postDelayed(this, 5000);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        player = new ExoPlayer.Builder(this)
                .setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(C.USAGE_MEDIA)
                        .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                        .build(), true)             // ses odağını (arama vb.) yönet
                .setHandleAudioBecomingNoisy(true)  // kulaklık çıkınca duraklat
                .setWakeMode(C.WAKE_MODE_LOCAL)     // ekran kapalıyken de çalsın
                .build();
        player.setRepeatMode(Player.REPEAT_MODE_ALL);
        player.addListener(playerListener);

        PendingIntent openApp = PendingIntent.getActivity(
                this, 0,
                new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        mediaSession = new MediaSession.Builder(this, player)
                .setSessionActivity(openApp)
                .setCallback(new SessionCallback(getPackageName()))
                .setBitmapLoader(new ThumbnailBitmapLoader(this))
                .build();

        restoreState();
    }

    @Override
    public MediaSession onGetSession(MediaSession.ControllerInfo controllerInfo) {
        return mediaSession;
    }

    /** Uygulama son uygulamalardan silinirse: çalıyorsa devam et, değilse servisi kapat. */
    @Override
    public void onTaskRemoved(Intent rootIntent) {
        Player p = mediaSession == null ? null : mediaSession.getPlayer();
        if (p == null || !p.getPlayWhenReady() || p.getMediaItemCount() == 0) {
            stopSelf();
        }
    }

    @Override
    public void onDestroy() {
        destroyed = true;
        mainHandler.removeCallbacksAndMessages(null);
        if (player != null) savePosition();
        if (mediaSession != null) {
            mediaSession.getPlayer().release();
            mediaSession.release();
            mediaSession = null;
        }
        super.onDestroy();
    }

    // ------------------------------------------------------------------ kayıt / geri yükleme

    private long currentId() {
        MediaItem item = player.getCurrentMediaItem();
        if (item == null) return 0L;
        try {
            return Long.parseLong(item.mediaId);
        } catch (NumberFormatException e) {
            return 0L;
        }
    }

    /** Kuyruğun tamamını + modları + konumu kaydeder (kuyruk/mod değişince). */
    private void saveQueue() {
        if (destroyed || player == null) return;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < player.getMediaItemCount(); i++) {
            if (i > 0) sb.append(',');
            sb.append(player.getMediaItemAt(i).mediaId);
        }
        prefs.edit()
                .putString("queue", sb.toString())
                .putLong("current", currentId())
                .putLong("pos", Math.max(0, player.getCurrentPosition()))
                .putBoolean("shuffle", player.getShuffleModeEnabled())
                .putInt("repeat", player.getRepeatMode())
                .apply();
    }

    /** Sadece mevcut şarkı + konumu kaydeder (hafif). */
    private void savePosition() {
        if (player == null) return;
        prefs.edit()
                .putLong("current", currentId())
                .putLong("pos", Math.max(0, player.getCurrentPosition()))
                .apply();
    }

    private void restoreState() {
        final String queue = prefs.getString("queue", "");
        if (queue == null || queue.isEmpty()) return;
        final long current = prefs.getLong("current", 0L);
        final long pos = prefs.getLong("pos", 0L);
        final boolean shuffle = prefs.getBoolean("shuffle", false);
        final int repeat = prefs.getInt("repeat", Player.REPEAT_MODE_ALL);
        final Context appContext = getApplicationContext();

        new Thread(() -> {
            List<MusicLibrary.Song> all = MusicLibrary.scan(appContext);
            if (all == null) return;
            Map<Long, MusicLibrary.Song> byId = new HashMap<>();
            for (MusicLibrary.Song s : all) byId.put(s.id, s);

            final List<MediaItem> items = new ArrayList<>();
            int idx = 0;
            for (String part : queue.split(",")) {
                try {
                    long id = Long.parseLong(part.trim());
                    MusicLibrary.Song s = byId.get(id);
                    if (s == null) continue; // silinmiş dosya
                    if (id == current) idx = items.size();
                    items.add(MusicLibrary.toMediaItem(s));
                } catch (NumberFormatException ignored) {
                }
            }
            if (items.isEmpty()) return;
            final int startIndex = idx;

            mainHandler.post(() -> {
                // Servis kapandıysa ya da arayüz bu arada bir kuyruk kurduysa dokunma
                if (destroyed || player == null || player.getMediaItemCount() > 0) return;
                player.setMediaItems(items, startIndex, pos);
                player.setShuffleModeEnabled(shuffle);
                player.setRepeatMode(repeat);
                player.prepare(); // oynatmadan hazırla
            });
        }, "muzik-restore").start();
    }

    // ------------------------------------------------------------------ oynatıcı olayları

    private final Player.Listener playerListener = new Player.Listener() {
        @Override
        public void onIsPlayingChanged(boolean isPlaying) {
            mainHandler.removeCallbacks(periodicSave);
            if (isPlaying) {
                errorStreak = 0;
                mainHandler.postDelayed(periodicSave, 5000);
            } else {
                savePosition();
            }
        }

        @Override
        public void onMediaItemTransition(MediaItem mediaItem, int reason) {
            savePosition();
        }

        @Override
        public void onTimelineChanged(Timeline timeline, int reason) {
            if (reason == Player.TIMELINE_CHANGE_REASON_PLAYLIST_CHANGED) saveQueue();
        }

        @Override
        public void onShuffleModeEnabledChanged(boolean shuffleModeEnabled) {
            saveQueue();
        }

        @Override
        public void onRepeatModeChanged(int repeatMode) {
            saveQueue();
        }

        // Bozuk / silinmiş bir dosya çalmayı durdurmasın: sıradakine geç
        @Override
        public void onPlayerError(PlaybackException error) {
            Log.w(TAG, "Oynatma hatası (" + error.getErrorCodeName() + "), sıradaki şarkıya geçiliyor", error);
            errorStreak++;
            if (errorStreak < player.getMediaItemCount()) {
                player.seekToNextMediaItem();
                player.prepare();
                player.play();
            } else {
                Log.e(TAG, "Kuyruktaki hiçbir parça çalınamadı.");
            }
        }
    };

    // ------------------------------------------------------------------ oturum erişimi

    /**
     * Servis AndroidManifest'te exported="true": tek sebebi sistemin (bildirim paneli,
     * kilit ekranı, Bluetooth/Android Auto) bu servise bağlanabilmesi gerekliliğidir.
     * Gerçek erişim denetimi burada: sadece sistemin güvendiği denetleyiciler ve uygulamanın
     * kendisi kabul edilir; başka bir uygulama komut gönderemez.
     */
    private static class SessionCallback implements MediaSession.Callback {
        private final String ownPackage;

        SessionCallback(String ownPackage) {
            this.ownPackage = ownPackage;
        }

        @Override
        public MediaSession.ConnectionResult onConnect(
                MediaSession session, MediaSession.ControllerInfo controller) {
            if (controller.isTrusted() || ownPackage.equals(controller.getPackageName())) {
                return new MediaSession.ConnectionResult.AcceptedResultBuilder(session).build();
            }
            Log.w(TAG, "Reddedilen bağlantı denemesi: " + controller.getPackageName());
            return MediaSession.ConnectionResult.reject();
        }

        /** Sadece mediaId (şarkı kimliği) ile gelen istekleri çalınabilir hâle getirir. */
        @Override
        public ListenableFuture<List<MediaItem>> onAddMediaItems(
                MediaSession session, MediaSession.ControllerInfo controller, List<MediaItem> mediaItems) {
            List<MediaItem> resolved = new ArrayList<>();
            for (MediaItem item : mediaItems) {
                if (item.localConfiguration != null) {
                    resolved.add(item);
                    continue;
                }
                try {
                    long id = Long.parseLong(item.mediaId);
                    resolved.add(item.buildUpon().setUri(MusicLibrary.uriFor(id)).build());
                } catch (NumberFormatException e) {
                    resolved.add(item);
                }
            }
            return Futures.immediateFuture(resolved);
        }
    }

    /** Bildirim / kilit ekranı kapağı: dosyanın gömülü albüm kapağını MediaStore'dan alır. */
    private static class ThumbnailBitmapLoader implements BitmapLoader {
        private final Context context;
        private final ListeningExecutorService executor =
                MoreExecutors.listeningDecorator(Executors.newSingleThreadExecutor());

        ThumbnailBitmapLoader(Context context) {
            this.context = context.getApplicationContext();
        }

        @Override
        public boolean supportsMimeType(String mimeType) {
            return true;
        }

        @Override
        public ListenableFuture<Bitmap> decodeBitmap(byte[] data) {
            return executor.submit(() -> {
                Bitmap b = BitmapFactory.decodeByteArray(data, 0, data.length);
                if (b == null) throw new IllegalStateException("Kapak çözümlenemedi");
                return b;
            });
        }

        @Override
        public ListenableFuture<Bitmap> loadBitmap(Uri uri) {
            return executor.submit(() -> {
                return context.getContentResolver().loadThumbnail(uri, new Size(512, 512), null);
            });
        }
    }
}
