package com.muzik.app;

import android.Manifest;
import android.content.ContentUris;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.util.Log;

import androidx.core.content.ContextCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;

import java.util.ArrayList;
import java.util.List;

/** Telefondaki TÜM ses dosyalarını MediaStore'dan okur. Uygulama ve oynatma servisi ortak kullanır. */
final class MusicLibrary {

    private static final String TAG = "MuzikLibrary";

    private MusicLibrary() {}

    static final class Song {
        long id;            // MediaStore _ID (aynı zamanda mediaId)
        String title;
        String artist = ""; // bilinmiyorsa boş
        String album = "";
        String folder = "";
        long durationMs;
        long added;         // eklenme zamanı (saniye)
    }

    static String audioPermission() {
        return Build.VERSION.SDK_INT >= 33
                ? Manifest.permission.READ_MEDIA_AUDIO
                : Manifest.permission.READ_EXTERNAL_STORAGE;
    }

    static boolean hasAudioPermission(Context context) {
        return ContextCompat.checkSelfPermission(context, audioPermission())
                == PackageManager.PERMISSION_GRANTED;
    }

    static Uri collection() {
        return MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL);
    }

    static Uri uriFor(long id) {
        return ContentUris.withAppendedId(collection(), id);
    }

    static MediaItem toMediaItem(Song s) {
        Uri uri = uriFor(s.id);
        MediaMetadata.Builder md = new MediaMetadata.Builder()
                .setTitle(s.title)
                .setArtworkUri(uri) // bildirim kapağı: PlaybackService.ThumbnailBitmapLoader okur
                .setIsPlayable(true)
                .setIsBrowsable(false);
        if (!s.artist.isEmpty()) md.setArtist(s.artist);
        if (!s.album.isEmpty()) md.setAlbumTitle(s.album);
        return new MediaItem.Builder()
                .setMediaId(String.valueOf(s.id))
                .setUri(uri)
                .setMediaMetadata(md.build())
                .build();
    }

    /**
     * Dahili depolama + SD karttaki tüm ses dosyaları. Zil/bildirim/alarm sesleri hariç.
     * İzin yoksa ya da sorgu başarısız olursa null döner.
     */
    static List<Song> scan(Context context) {
        if (!hasAudioPermission(context)) return null;

        String[] projection = {
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.DISPLAY_NAME,
                MediaStore.Audio.Media.RELATIVE_PATH,
                MediaStore.Audio.Media.DATE_ADDED,
                MediaStore.Audio.Media.IS_RINGTONE,
                MediaStore.Audio.Media.IS_NOTIFICATION,
                MediaStore.Audio.Media.IS_ALARM,
                MediaStore.Audio.Media.IS_PENDING
        };

        List<Song> out = new ArrayList<>();
        try (Cursor c = context.getContentResolver().query(collection(), projection, null, null, null)) {
            if (c == null) {
                Log.w(TAG, "MediaStore sorgusu null döndü.");
                return null;
            }
            int idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID);
            int titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE);
            int artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST);
            int albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM);
            int durCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION);
            int nameCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME);
            int pathCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.RELATIVE_PATH);
            int addedCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED);
            int ringCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.IS_RINGTONE);
            int notifCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.IS_NOTIFICATION);
            int alarmCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.IS_ALARM);
            int pendingCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.IS_PENDING);

            while (c.moveToNext()) {
                if (c.getInt(ringCol) == 1 || c.getInt(notifCol) == 1
                        || c.getInt(alarmCol) == 1 || c.getInt(pendingCol) == 1) continue;
                long duration = c.getLong(durCol);
                if (duration <= 0) continue; // süresi bilinmeyen/bozuk dosya çalınamaz

                String displayName = c.getString(nameCol);
                if (displayName == null) displayName = "";
                String title = c.getString(titleCol);
                title = title == null ? "" : title.trim();
                if (title.isEmpty()) {
                    int dot = displayName.lastIndexOf('.');
                    title = dot > 0 ? displayName.substring(0, dot) : displayName;
                }

                Song s = new Song();
                s.id = c.getLong(idCol);
                s.title = title;
                s.artist = clean(c.getString(artistCol));
                s.album = clean(c.getString(albumCol));
                String folder = c.getString(pathCol);
                s.folder = folder == null ? "" : folder;
                s.durationMs = duration;
                s.added = c.getLong(addedCol);
                out.add(s);
            }
        } catch (Exception e) {
            Log.e(TAG, "Ses dosyaları taranamadı", e);
            return null;
        }
        return out;
    }

    private static String clean(String v) {
        if (v == null) return "";
        v = v.trim();
        return v.equalsIgnoreCase("<unknown>") ? "" : v;
    }
}
