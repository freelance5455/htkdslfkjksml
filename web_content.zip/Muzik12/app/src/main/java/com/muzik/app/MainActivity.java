package com.muzik.app;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.content.pm.PackageManager;
import android.database.ContentObserver;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Log;
import android.util.LruCache;
import android.util.Size;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;

import com.google.common.util.concurrent.ListenableFuture;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Arayüz (index.html) bir WebView içinde gösterilir. Oynatma, tarama ve kayıt işleri
 * yerel tarafta (PlaybackService, MusicLibrary) yapılır; sayfa sadece komut gönderir.
 */
public class MainActivity extends Activity {

    private static final String TAG = "MuzikApp";
    private static final int REQ_PERMS = 100;
    // Sayfa sanal bir adresten (sadece uygulamanın içinde) yüklenir; internet izni yoktur.
    private static final String HOST = "muzik.local";

    private WebView webView;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService scanExecutor = Executors.newSingleThreadExecutor();

    private volatile Map<Long, MusicLibrary.Song> songMap = new HashMap<>();
    private volatile String songsJson = "null"; // "null" = henüz taranmadı
    private volatile int refreshCounter = 0;
    private String lastPushedJson = null;

    private ContentObserver libraryObserver;
    private boolean observerRegistered = false;
    private final Runnable rescanRunnable = this::refreshSongs;

    private ListenableFuture<MediaController> controllerFuture;
    private MediaController controller;
    private Runnable pendingAction;

    // Albüm kapakları: id -> JPEG baytları (en fazla ~8 MB)
    private final LruCache<Long, byte[]> artCache = new LruCache<Long, byte[]>(8 * 1024 * 1024) {
        @Override
        protected int sizeOf(Long key, byte[] value) {
            return value.length;
        }
    };
    private final Set<Long> artFailed = ConcurrentHashMap.newKeySet();

    // ------------------------------------------------------------------ yaşam döngüsü

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#0B0B0B"));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#0B0B0B"));
        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        // Kenardan kenara çizimde durum/gezinme çubuğu ve klavye sayfanın üstüne binmesin
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars()
                    | WindowInsetsCompat.Type.displayCutout()
                    | WindowInsetsCompat.Type.ime());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);   // sıralama / süre filtresi tercihleri
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        webView.setWebViewClient(new AppWebViewClient());
        webView.addJavascriptInterface(new MusicBridge(), "AndroidMusic");
        webView.loadUrl("https://" + HOST + "/index.html");

        libraryObserver = new ContentObserver(handler) {
            @Override
            public void onChange(boolean selfChange) {
                // Telefona müzik eklenip silinince kısa bir beklemeyle yeniden tara
                handler.removeCallbacks(rescanRunnable);
                handler.postDelayed(rescanRunnable, 1500);
            }
        };

        if (MusicLibrary.hasAudioPermission(this)) {
            startLibrary();
        }
        requestNeededPermissions();
    }

    @Override
    protected void onStart() {
        super.onStart();
        connectController();
    }

    @Override
    protected void onStop() {
        disconnectController();
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (observerRegistered) {
            getContentResolver().unregisterContentObserver(libraryObserver);
            observerRegistered = false;
        }
        scanExecutor.shutdownNow();
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private void requestNeededPermissions() {
        List<String> need = new ArrayList<>();
        if (!MusicLibrary.hasAudioPermission(this)) need.add(MusicLibrary.audioPermission());
        if (Build.VERSION.SDK_INT >= 33
                && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.POST_NOTIFICATIONS); // bildirim/kilit ekranı kontrolleri için
        }
        if (!need.isEmpty()) {
            ActivityCompat.requestPermissions(this, need.toArray(new String[0]), REQ_PERMS);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_PERMS) return;
        if (MusicLibrary.hasAudioPermission(this)) {
            startLibrary();
        } else {
            Log.w(TAG, "Müzik/ses izni reddedildi.");
            callJs("window.onPermissionDenied&&window.onPermissionDenied()");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Ayarlardan izin verilip dönüldüyse kütüphaneyi başlat
        if (!observerRegistered && MusicLibrary.hasAudioPermission(this)) startLibrary();
    }

    /** İzin varken: değişiklikleri izlemeye başla ve ilk taramayı yap. */
    private void startLibrary() {
        if (!observerRegistered) {
            getContentResolver().registerContentObserver(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, true, libraryObserver);
            observerRegistered = true;
        }
        refreshSongs();
    }

    private void callJs(String script) {
        WebView w = webView;
        if (w != null) w.evaluateJavascript(script, null);
    }

    // ------------------------------------------------------------------ WebView: sanal adres

    private static WebResourceResponse notFound() {
        return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found",
                new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
    }

    private class AppWebViewClient extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            Uri u = request.getUrl();
            // Uygulama dışına hiçbir istek çıkmaz
            if (!"https".equals(u.getScheme()) || !HOST.equals(u.getHost())) return notFound();
            String path = u.getPath() == null ? "" : u.getPath();

            if (path.equals("/") || path.equals("/index.html")) {
                try {
                    InputStream in = getAssets().open("index.html");
                    return new WebResourceResponse("text/html", "utf-8", in);
                } catch (IOException e) {
                    Log.e(TAG, "index.html açılamadı", e);
                    return notFound();
                }
            }
            if (path.startsWith("/art/")) {
                return artResponse(path.substring("/art/".length()));
            }
            return notFound();
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return true; // sayfa başka bir adrese gidemez
        }
    }

    /** /art/<şarkı id> isteklerine ses dosyasının gömülü kapağını döner. */
    private WebResourceResponse artResponse(String idText) {
        long id;
        try {
            id = Long.parseLong(idText);
        } catch (NumberFormatException e) {
            return notFound();
        }
        if (!MusicLibrary.hasAudioPermission(this)) return notFound();

        byte[] data = artCache.get(id);
        if (data == null) {
            if (artFailed.contains(id)) return notFound();
            try {
                Bitmap bmp = getContentResolver().loadThumbnail(MusicLibrary.uriFor(id), new Size(192, 192), null);
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                bmp.compress(Bitmap.CompressFormat.JPEG, 85, out);
                data = out.toByteArray();
                artCache.put(id, data);
            } catch (Exception e) {
                artFailed.add(id); // kapak yok: tekrar tekrar denemeyelim
                return notFound();
            }
        }
        Map<String, String> headers = new HashMap<>();
        headers.put("Cache-Control", "max-age=3600");
        WebResourceResponse r = new WebResourceResponse("image/jpeg", null, new ByteArrayInputStream(data));
        r.setResponseHeaders(headers);
        return r;
    }

    // ------------------------------------------------------------------ oynatıcı bağlantısı

    private void connectController() {
        if (controllerFuture != null) return;
        SessionToken token = new SessionToken(this, new ComponentName(this, PlaybackService.class));
        final ListenableFuture<MediaController> future =
                new MediaController.Builder(this, token).buildAsync();
        controllerFuture = future;
        future.addListener(() -> {
            if (controllerFuture != future) return;
            try {
                controller = future.get();
            } catch (Exception e) {
                Log.e(TAG, "Oynatma servisine bağlanılamadı", e);
                return;
            }
            controller.addListener(playerListener);
            if (pendingAction != null) {
                Runnable r = pendingAction;
                pendingAction = null;
                r.run();
            }
            pushState();
            scheduleTick();
        }, ContextCompat.getMainExecutor(this));
    }

    private void disconnectController() {
        handler.removeCallbacks(ticker);
        pendingAction = null;
        if (controller != null) {
            controller.removeListener(playerListener);
            controller = null;
        }
        if (controllerFuture != null) {
            MediaController.releaseFuture(controllerFuture);
            controllerFuture = null;
        }
    }

    private final Player.Listener playerListener = new Player.Listener() {
        @Override
        public void onEvents(Player player, Player.Events events) {
            pushState();
            scheduleTick();
        }
    };

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            pushState();
            scheduleTick();
        }
    };

    /** Çalarken ilerleme çubuğu için yarım saniyede bir durum gönder. */
    private void scheduleTick() {
        handler.removeCallbacks(ticker);
        MediaController c = controller;
        if (c != null && c.isPlaying()) handler.postDelayed(ticker, 500);
    }

    private void onController(Runnable action) {
        if (controller != null) action.run();
        else pendingAction = action;
    }

    // ------------------------------------------------------------------ komutlar

    private boolean sameQueue(MediaController c, List<MusicLibrary.Song> queue) {
        if (c.getMediaItemCount() != queue.size()) return false;
        for (int i = 0; i < queue.size(); i++) {
            if (!String.valueOf(queue.get(i).id).equals(c.getMediaItemAt(i).mediaId)) return false;
        }
        return true;
    }

    /**
     * Sayfanın gösterdiği (süzülmüş + sıralanmış) listeyi kuyruk yapar ve verilen şarkıdan başlar.
     * Şarkılar sıra numarasıyla değil kalıcı kimlikleriyle seçilir.
     */
    private void playQueue(String startIdText, String idsJson) {
        MediaController c = controller;
        if (c == null) return;
        long startId;
        List<MusicLibrary.Song> queue = new ArrayList<>();
        try {
            startId = Long.parseLong(startIdText);
            JSONArray arr = new JSONArray(idsJson);
            Map<Long, MusicLibrary.Song> map = songMap;
            for (int i = 0; i < arr.length(); i++) {
                MusicLibrary.Song s = map.get(arr.getLong(i));
                if (s != null) queue.add(s);
            }
        } catch (NumberFormatException | JSONException e) {
            Log.e(TAG, "Geçersiz çalma isteği", e);
            return;
        }
        int index = -1;
        for (int i = 0; i < queue.size(); i++) {
            if (queue.get(i).id == startId) {
                index = i;
                break;
            }
        }
        if (index < 0) {
            Log.w(TAG, "Seçilen şarkı artık listede yok: " + startId);
            return;
        }
        if (sameQueue(c, queue)) {
            c.seekTo(index, 0);
        } else {
            List<MediaItem> items = new ArrayList<>(queue.size());
            for (MusicLibrary.Song s : queue) items.add(MusicLibrary.toMediaItem(s));
            c.setMediaItems(items, index, 0);
        }
        c.prepare();
        c.play();
    }

    private void togglePlay() {
        MediaController c = controller;
        if (c == null || c.getMediaItemCount() == 0) return;
        if (c.getPlayWhenReady()) {
            c.pause();
        } else {
            c.prepare();
            c.play();
        }
    }

    private void skipNext() {
        MediaController c = controller;
        if (c == null || c.getMediaItemCount() == 0) return;
        c.seekToNextMediaItem();
        c.prepare();
        c.play();
    }

    private void skipPrevious() {
        MediaController c = controller;
        if (c == null || c.getMediaItemCount() == 0) return;
        c.seekToPreviousMediaItem();
        c.prepare();
        c.play();
    }

    private void cycleRepeat() {
        MediaController c = controller;
        if (c == null) return;
        int mode = c.getRepeatMode();
        if (mode == Player.REPEAT_MODE_ALL) c.setRepeatMode(Player.REPEAT_MODE_ONE);
        else if (mode == Player.REPEAT_MODE_ONE) c.setRepeatMode(Player.REPEAT_MODE_OFF);
        else c.setRepeatMode(Player.REPEAT_MODE_ALL);
    }

    // ------------------------------------------------------------------ arayüze durum gönder

    private void pushState() {
        if (webView == null) return;
        JSONObject o = new JSONObject();
        try {
            MediaController c = controller;
            MediaItem item = c == null ? null : c.getCurrentMediaItem();
            o.put("id", item == null ? "" : item.mediaId);
            o.put("title", item == null || item.mediaMetadata.title == null
                    ? "" : item.mediaMetadata.title.toString());
            o.put("artist", item == null || item.mediaMetadata.artist == null
                    ? "" : item.mediaMetadata.artist.toString());
            o.put("playing", c != null && c.getPlayWhenReady());
            o.put("pos", c == null ? 0 : Math.max(0, c.getCurrentPosition()));
            long d = c == null ? 0 : c.getDuration();
            o.put("dur", d == C.TIME_UNSET ? 0 : Math.max(0, d));
            o.put("shuffle", c != null && c.getShuffleModeEnabled());
            o.put("repeat", c == null ? Player.REPEAT_MODE_ALL : c.getRepeatMode());
        } catch (JSONException e) {
            Log.e(TAG, "Durum JSON'u oluşturulamadı", e);
        }
        callJs("window.onState&&window.onState(" + o + ")");
    }

    // ------------------------------------------------------------------ şarkı listesi

    private void refreshSongs() {
        final int myId = ++refreshCounter;
        runOnUiThread(() -> callJs("window.onScan&&window.onScan(true)"));
        scanExecutor.execute(() -> {
            List<MusicLibrary.Song> list = MusicLibrary.scan(getApplicationContext());
            if (myId != refreshCounter) return; // daha yeni bir tarama başladı
            if (list == null) {
                // İzin yok / sorgu başarısız: eldeki listeyi bozma
                runOnUiThread(() -> callJs("window.onScan&&window.onScan(false)"));
                return;
            }

            Map<Long, MusicLibrary.Song> map = new HashMap<>(list.size() * 2);
            JSONArray arr = new JSONArray();
            for (MusicLibrary.Song s : list) {
                map.put(s.id, s);
                try {
                    JSONObject o = new JSONObject();
                    o.put("id", s.id);
                    o.put("title", s.title);
                    o.put("artist", s.artist);
                    o.put("album", s.album);
                    o.put("folder", s.folder);
                    o.put("dur", s.durationMs);
                    o.put("added", s.added);
                    arr.put(o);
                } catch (JSONException e) {
                    Log.e(TAG, "Şarkı JSON'a çevrilemedi: " + s.title, e);
                }
            }
            final String newJson = arr.toString();
            songMap = map;
            songsJson = newJson;

            runOnUiThread(() -> {
                // Liste gerçekten değişmediyse sayfayı yeniden çizdirme
                if (!newJson.equals(lastPushedJson)) {
                    lastPushedJson = newJson;
                    callJs("window.setSongs&&window.setSongs(" + newJson + ")");
                }
                callJs("window.onScan&&window.onScan(false)");
            });
        });
    }

    // ------------------------------------------------------------------ WebView köprüsü

    public class MusicBridge {
        @JavascriptInterface
        public String getMusic() {
            return songsJson;
        }

        @JavascriptInterface
        public void ready() {
            runOnUiThread(() -> pushState());
        }

        @JavascriptInterface
        public void rescan() {
            runOnUiThread(() -> {
                if (MusicLibrary.hasAudioPermission(MainActivity.this)) startLibrary();
                else requestNeededPermissions();
            });
        }

        @JavascriptInterface
        public void playQueue(String startId, String idsJson) {
            runOnUiThread(() -> onController(() -> MainActivity.this.playQueue(startId, idsJson)));
        }

        @JavascriptInterface
        public void toggle() {
            runOnUiThread(() -> onController(() -> togglePlay()));
        }

        @JavascriptInterface
        public void next() {
            runOnUiThread(() -> onController(() -> skipNext()));
        }

        @JavascriptInterface
        public void prev() {
            runOnUiThread(() -> onController(() -> skipPrevious()));
        }

        @JavascriptInterface
        public void seekTo(long positionMs) {
            runOnUiThread(() -> {
                if (controller != null) controller.seekTo(positionMs);
            });
        }

        @JavascriptInterface
        public void setShuffle(boolean enabled) {
            runOnUiThread(() -> onController(() -> {
                if (controller != null) controller.setShuffleModeEnabled(enabled);
            }));
        }

        @JavascriptInterface
        public void cycleRepeat() {
            runOnUiThread(() -> onController(() -> MainActivity.this.cycleRepeat()));
        }
    }
}
