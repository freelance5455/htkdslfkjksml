MÜZİK v1.2 - ANDROID (HTML arayüz + küçük yerel kabuk)

Telefondaki TÜM ses dosyalarını kendi bulan, arka planda çalmaya devam eden ve
kilit ekranı / bildirim panelinden kontrol edilen müzik çalar.

SÜRÜM GEÇMİŞİ
  1.1  Önceki sürüm: HTML arayüz + Java oynatma servisi. Müzik, projedeki "muzik"
       klasöründen ve telefonun Müzik klasöründen listeleniyordu.
  1.2  Bu sürüm (aşağıdaki yenilikler).

1.2'DE YENİ OLANLAR
  - Telefondaki TÜM ses dosyaları otomatik bulunur (dahili depolama + SD kart).
    Sistem zil/bildirim/alarm sesleri hariç. "muzik" klasörü artık gerekmiyor.
  - Telefona müzik eklenince / silinince liste kendiliğinden güncellenir.
  - Arama (Türkçe harflere duyarlı: ad, sanatçı, albüm, klasör).
  - Sıralama: A-Z, Sanatçı, Yeni eklenen. Liste Türkçe alfabe sırasındadır.
  - Karıştır ve tekrar (kapalı / tümü / tek şarkı) düğmeleri, "Karışık çal".
  - Kaldığın yerden devam: kuyruk, şarkı, konum, karıştır/tekrar kaydedilir;
    uygulama kapanıp açılınca (hatta bildirimden) kaldığı yerden sürer.
  - Albüm kapakları listede, oynatıcıda, bildirimde ve kilit ekranında.
  - Kısa sesleri (sesli mesaj, kayıt) gizleme: ayarlar > 30 / 60 sn filtresi.
  - Binlerce şarkıda da akıcı liste (parça parça yüklenir).
  - Klavye açılınca arayüz sıkışmaz, Android 15 kenar boşlukları düzgün.
  - Servise yalnızca sistem (bildirim paneli, kilit ekranı, Bluetooth) ve
    uygulamanın kendisi bağlanabilir; başka uygulama müziği kontrol edemez.
  - Uygulamanın internet izni yoktur; arayüz sanal bir adresten yerel yüklenir.

SINIRLAR (dürüst not)
  - Minimum Android 10 (API 29). (1.1 Android 8'i destekliyordu.)
  - Tarama Android'in medya dizininden (MediaStore) yapılır. ".nomedia" içeren
    klasörlerdeki veya Android'in dizine eklemediği dosyalar listede görünmez.
    Her klasörü gezmek "tüm dosyalara erişim" izni ister; bilerek kullanılmadı.
  - Kaydedilen durum (kuyruk, konum) basit uygulama deposunda tutulur; ayrı bir
    veritabanı (Room) yok. Kütüphane her açılışta yeniden taranır (hızlıdır).
  - Bluetooth düğmeleri ve Android Auto gerçek cihazda denenmedi.

APK OLUŞTURMA - YÖNTEM 1: Android Studio
  1) Projeyi Android Studio ile aç, Gradle senkronizasyonunu bekle.
  2) Build > Build Bundle(s) / APK(s) > Build APK(s)
  3) APK: app/build/outputs/apk/debug/app-debug.apk
     Telefona at ve dokunarak kur (bilinmeyen kaynaklara izin ver).

APK OLUŞTURMA - YÖNTEM 2: Android Studio olmadan (GitHub)
  1) github.com'da yeni bir depo aç, bu projenin TÜM dosyalarını yükle
     (gizli ".github" klasörü de dahil).
  2) Depoda Actions sekmesi > "APK olustur" çalışır (2-4 dk).
  3) Bittiğinde çalışmanın altındaki "Muzik-v1.2-APK" dosyasını indir,
     içinden Muzik-v1.2.apk çıkar. Telefona at ve kur.

SABİT İMZA (yeni APK'yı eskinin üstüne kurabilmek için)
  Varsayılan olarak her derleme farklı bir "debug" anahtarıyla imzalanır; Android
  bunu farklı uygulama sayıp güncellemeyi reddeder (önce eskisini kaldırman gerekir).
  Kalıcı çözüm: SABİT bir anahtar üret ve her derlemede onu kullan.

  1) Bir kerelik anahtar üret (Java kuruluysa):
       keytool -genkeypair -v -keystore muzik-release.keystore -alias muzik -keyalg RSA -keysize 2048 -validity 36500
     Parolaları not al, dosyayı KAYBETME.

  2) GitHub için: repo Settings > Secrets and variables > Actions > New repository secret
       MUZIK_KEYSTORE_BASE64  -> "base64 -w0 muzik-release.keystore" çıktısı
       MUZIK_STORE_PASSWORD   -> keystore parolası
       MUZIK_KEY_ALIAS        -> muzik
       MUZIK_KEY_PASSWORD     -> anahtar parolası

  3) Android Studio için: muzik-release.keystore dosyasını proje köküne koy ve
     yine proje köküne "keystore.properties" oluştur:
       storeFile=muzik-release.keystore
       storePassword=...
       keyAlias=muzik
       keyPassword=...
     (Bu iki dosyayı GitHub'a yükleme; .gitignore zaten dışarıda tutar.)

  Hiçbiri yapılmazsa uygulama yine derlenir ve çalışır; sadece güncellemelerde
  önce eski sürümü kaldırman gerekir.

İZİNLER
  İlk açılışta "müzik ve ses" ve "bildirim" izni istenir. Bildirim izni verilmezse
  kilit ekranı / bildirim paneli kontrolleri görünmeyebilir. Müzik izni reddedilirse
  uygulama bunu ekranda söyler; ayarlardan verip yenile düğmesine dokun.

PROJE YAPISI
  app/src/main/assets/index.html          Arayüz (HTML/CSS/JS) - görünümü buradan değiştir
  app/src/main/java/com/muzik/app/
    MainActivity.java     WebView kabuğu, izinler, tarama, HTML <-> Android köprüsü
    PlaybackService.java  ExoPlayer + MediaSession, arka planda çalma, durum kaydı
    MusicLibrary.java     MediaStore taraması (telefondaki tüm ses dosyaları)
  Uygulama adı: app/src/main/res/values/strings.xml
