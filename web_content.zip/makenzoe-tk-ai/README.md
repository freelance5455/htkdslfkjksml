# MAKENZOE TK AI ASSISTANT
Needs Node 20.6+. No npm install required.
1. Copy `.env.example` to `.env`; set ADMIN_EMAILS, ADMIN_PASSWORD and your AI keys.
2. `npm start`, then open http://localhost:3000 (host on Render/Railway/VPS for a public https URL).
3. Log in with the owner email/password to see the Admin tab (approve or reject payments).
4. WhatsApp: Meta for Developers > WhatsApp > Configuration > webhook `https://YOUR-URL/webhook`, your VERIFY_TOKEN, subscribe to "messages".
5. Users: sign up (email, password, phone), choose a username, get 200 free messages/month.
   Upgrading = pay, submit approval code + proof, owner approves in Admin.
`assets/padding.bin` is filler to make the zip ~5 MB; delete it any time.

## Extra AI agents
Add any of GEMINI / MISTRAL / DEEPSEEK / XAI / LLAMA / OPENAI keys. WhatsApp replies race every agent that has a key and send the first answer.
## Offline
The app installs like an app (browser menu > Add to Home Screen), opens without internet, keeps your chat history, answers maths/time/date offline, and saves other messages to send when you're back online. A full AI model can't run offline in this version.

## One combined agent
With COMBINE=on, ChatGPT, Llama, Gemini, Mistral, DeepSeek and Grok (whichever have keys) write quick drafts in parallel (max COUNCIL_MS), then Claude searches the web, checks them and streams one final answer. Set COMBINE=off for the fastest possible replies.

## Plans
$1 = 1 week, $3 = 2 weeks, $10 = 1 month, all unlimited messages. When you approve a payment in the Admin tab the user is subscribed automatically for that period (renewals add on to the time left).

## Admin panel
Sign in with an owner email (password from .env, or Google) and you land in Admin: approve payments, see who is online and chatting, read chats, message everyone or one user, block users, and edit the AI (instructions, model, free messages, welcome message, banner, on/off switches). Changes are live immediately.
## Google & phone login
Set GOOGLE_CLIENT_ID to show "Continue with Google". Users can also log in with their phone number + password. (SMS one-time codes need an SMS provider and aren't included.)
