// MAKENZOE TK AI ASSISTANT — server (Node 20+, no npm packages needed)
import http from "node:http"; import fs from "node:fs"; import path from "node:path"; import crypto from "node:crypto";
const E = process.env, PORT = E.PORT || 3000, ADMINS = (E.ADMIN_EMAILS || E.ADMIN_EMAIL || "").toLowerCase().split(",").map(x => x.trim()).filter(Boolean), FREE = +(E.FREE_MESSAGES || 200);
const PAY = { EcoCash: "0790133519", Inbucks: "071 463 4920", OneMoney: "071 463 4920", Omari: "071 463 4920" };
const PLANS = { week: { name: "1 Week", price: 1, days: 7 }, two: { name: "2 Weeks", price: 3, days: 14 }, month: { name: "1 Month", price: 10, days: 30 } };
const DBF = "data/db.json"; fs.mkdirSync("data", { recursive: true });
const db = fs.existsSync(DBF) ? JSON.parse(fs.readFileSync(DBF)) : { users: {}, sess: {}, pay: [], notes: [] };
const save = () => fs.writeFileSync(DBF, JSON.stringify(db));
const cfg = () => db.cfg ||= {}, free = () => cfg().free ?? FREE, sysx = () => SYS + (cfg().prompt ? "\nExtra instructions from the owner: " + cfg().prompt : "");
const hash = (p, s = crypto.randomBytes(16).toString("hex")) => s + ":" + crypto.scryptSync(p, s, 32).toString("hex");
const check = (p, h) => crypto.timingSafeEqual(Buffer.from(hash(p, h.split(":")[0])), Buffer.from(h));
const ym = () => new Date().toISOString().slice(0, 7), id = () => crypto.randomBytes(8).toString("hex");
// Owner account comes from .env only, so nobody else can register as the admin.
for (const a of ADMINS) { // owner accounts come from .env only
  const u = db.users[a] ||= { email: a, pw: "", phone: "", username: "Owner", plan: "pro", until: 0, used: 0, month: ym() };
  u.admin = true; if (!u.username) u.username = "Owner"; if (E.ADMIN_PASSWORD) u.pw = hash(E.ADMIN_PASSWORD);
}
save();
const notify = (to, text, from) => { if (!db.notes.some(n => n.to == to && n.text == text && !n.read)) db.notes.push({ id: id(), to, text, from, t: Date.now(), read: false }); save(); };
const notifyAdmins = t => ADMINS.forEach(a => notify(a, t));
const isPro = u => u.admin || (u.plan == "pro" && u.until > Date.now());
const allow = u => { if (u.month != ym()) { u.month = ym(); u.used = 0; } return isPro(u) || u.used < free(); };
const left = u => isPro(u) ? "unlimited" : Math.max(0, free() - u.used);

// ---------- AI providers ----------
const SYS = "You are MAKENZOE TK AI ASSISTANT, one very intelligent agent that combines the best of many AI minds. Rules: 1) Give the straight answer first, in simple everyday words, and keep it short unless asked for more. 2) For anything current, factual or uncertain, quickly search the web (once or twice, no more) before answering, then answer without describing the search. 3) You are an expert programmer in every language: write correct, complete, runnable code in fenced code blocks with the language name, then a 1-2 line explanation, and debug carefully. 4) You can read images and screenshots: explain what matters and answer questions about them. 5) Users can type /image followed by a description to create pictures. 6) Think carefully before answering, and say honestly when you are not sure.";
async function claude(messages, sys, onDelta, model = cfg().model || E.MODEL || "claude-sonnet-5-5", onSearch) {
  const r = await fetch("https://api.anthropic.com/v1/messages", { method: "POST",
    headers: { "content-type": "application/json", "x-api-key": E.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
    body: JSON.stringify({ model, max_tokens: 4000, stream: !!onDelta, system: sys, messages, ...(cfg().research === false ? {} : { tools: [{ type: "web_search_20250305", name: "web_search", max_uses: 3 }] }) }) });
  if (!r.ok) throw new Error(await r.text());
  if (!onDelta) return (await r.json()).content.filter(b => b.type == "text").map(b => b.text).join("");
  const dec = new TextDecoder(); let buf = "", out = "";
  for await (const c of r.body) { buf += dec.decode(c, { stream: true }); let i;
    while ((i = buf.indexOf("\n")) >= 0) { const l = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
      if (l.startsWith("data:")) try { const j = JSON.parse(l.slice(5)), d = j.delta; if (j.content_block?.type == "server_tool_use") onSearch?.(); if (d?.type == "text_delta") { onDelta(d.text); out += d.text; } } catch {} } }
  return out;
}
const oai = async (url, key, model, m, sys) => (await (await fetch(url + "/chat/completions", { method: "POST",
  headers: { "content-type": "application/json", authorization: "Bearer " + key },
  body: JSON.stringify({ model, messages: [{ role: "system", content: sys }, ...m] }) })).json()).choices[0].message.content;
const agents = (m, sys) => [
  ["ChatGPT", E.OPENAI_API_KEY && (() => oai("https://api.openai.com/v1", E.OPENAI_API_KEY, "gpt-4o-mini", m, sys))],
  ["Llama", E.LLAMA_API_KEY && (() => oai(E.LLAMA_BASE_URL || "https://api.together.xyz/v1", E.LLAMA_API_KEY, E.LLAMA_MODEL || "meta-llama/Llama-3.3-70B-Instruct-Turbo", m, sys))],
  ["Gemini", E.GEMINI_API_KEY && (() => oai("https://generativelanguage.googleapis.com/v1beta/openai", E.GEMINI_API_KEY, "gemini-2.0-flash", m, sys))],
  ["Mistral", E.MISTRAL_API_KEY && (() => oai("https://api.mistral.ai/v1", E.MISTRAL_API_KEY, "mistral-small-latest", m, sys))],
  ["DeepSeek", E.DEEPSEEK_API_KEY && (() => oai("https://api.deepseek.com/v1", E.DEEPSEEK_API_KEY, "deepseek-chat", m, sys))],
  ["Grok", E.XAI_API_KEY && (() => oai("https://api.x.ai/v1", E.XAI_API_KEY, "grok-3-mini", m, sys))],
].filter(a => a[1]);
const fast = (m, sys = SYS) => Promise.any([ // first answer wins (used for WhatsApp and as fallback)
  E.ANTHROPIC_API_KEY && claude(m, sys, null, "claude-haiku-5-5"), ...agents(m, sys).map(([, f]) => f())].filter(Boolean));
// One combined agent: the other AIs write quick drafts in parallel, then Claude checks, fixes and merges them.
async function council(m) {
  const ms = +(E.COUNCIL_MS || 2500), lim = p => Promise.race([p, new Promise((_, r) => setTimeout(r, ms))]);
  const r = await Promise.allSettled(agents(m, SYS).map(([n, f]) => lim(f()).then(t => `[${n}] ${t}`)));
  return r.filter(x => x.status == "fulfilled").map(x => x.value).join("\n\n");
}
async function makeImage(prompt) {
  const d = await (await fetch("https://api.openai.com/v1/images/generations", { method: "POST",
    headers: { "content-type": "application/json", authorization: "Bearer " + E.OPENAI_API_KEY },
    body: JSON.stringify({ model: "gpt-image-1", prompt, size: "1024x1024" }) })).json();
  if (!d.data) throw new Error(d.error?.message || "image failed");
  return "data:image/png;base64," + d.data[0].b64_json;
}
async function sendWA(to, text) {
  if (!E.WHATSAPP_TOKEN || !to) return;
  await fetch(`https://graph.facebook.com/v21.0/${E.WHATSAPP_PHONE_ID}/messages`, { method: "POST",
    headers: { "content-type": "application/json", authorization: "Bearer " + E.WHATSAPP_TOKEN },
    body: JSON.stringify({ messaging_product: "whatsapp", to, text: { body: text } }) }).catch(() => {});
}

// ---------- routes ----------
const hist = {}, waHist = {};
const mk = u => ({ email: u.email, username: u.username, phone: u.phone, admin: !!u.admin, pro: isPro(u), until: u.until, left: left(u), pay: PAY, plans: PLANS, announce: cfg().announce || "", welcome: cfg().welcome || "" });
const session = (email) => { const t = id() + id(); db.sess[t] = email; save(); return t; };
const R = {
  "POST /api/register": (b) => {
    const e = (b.email || "").trim().toLowerCase();
    if (!/^\S+@\S+\.\S+$/.test(e) || (b.password || "").length < 6 || !/^\+?\d[\d ]{6,}$/.test(b.phone || "")) throw [400, "Enter a valid email, phone and a password of 6+ characters"];
    if (db.users[e] || ADMINS.includes(e)) throw [409, "Email already in use"];
    db.users[e] = { email: e, pw: hash(b.password), phone: b.phone, username: "", plan: "free", until: 0, used: 0, month: ym() };
    return { token: session(e), me: mk(db.users[e]) };
  },
  "POST /api/login": (b) => {
    const k = (b.email || "").trim().toLowerCase(), pn = x => x.replace(/\s/g, "");
    const u = db.users[k] || Object.values(db.users).find(x => x.phone && pn(x.phone) == pn(k));
    if (!u || !u.pw || !check(b.password || "", u.pw)) throw [401, "Wrong email/phone or password"];
    return { token: session(u.email), me: mk(u) };
  },
  "GET /api/config": () => ({ google: E.GOOGLE_CLIENT_ID || "" }),
  "POST /api/google": async (b) => {
    const d = await fetch("https://oauth2.googleapis.com/tokeninfo?id_token=" + encodeURIComponent(b.credential || "")).then(r => r.json()).catch(() => ({}));
    if (!E.GOOGLE_CLIENT_ID || d.aud != E.GOOGLE_CLIENT_ID || d.email_verified != "true" || !d.email) throw [401, "Google sign-in failed"];
    const e = d.email.toLowerCase(), u = db.users[e] ||= { email: e, pw: "", phone: "", username: "", plan: "free", until: 0, used: 0, month: ym() };
    u.admin = ADMINS.includes(e); if (u.admin && !u.username) u.username = "Owner"; save();
    return { token: session(e), me: mk(u) };
  },
  "POST /api/dm": (b, u) => { const t = (b.text || "").trim().slice(0, 500); if (!t) throw [400, "Empty"]; notifyAdmins(`💬 ${u.username} (${u.email}): ${t}`); return { ok: true }; },
  "POST /api/username": (b, u) => {
    const n = (b.username || "").trim();
    if (!/^[\w.]{3,20}$/.test(n)) throw [400, "3-20 letters, numbers, _ or ."];
    if (Object.values(db.users).some(x => x.username.toLowerCase() == n.toLowerCase() && x != u)) throw [409, "Username taken"];
    u.username = n; save(); return mk(u);
  },
  "GET /api/me": (b, u) => mk(u),
  "GET /api/notes": (b, u) => db.notes.filter(n => n.to == u.email).reverse().slice(0, 50),
  "POST /api/notes/read": (b, u) => { db.notes.forEach(n => n.to == u.email && (n.read = true)); save(); return {}; },
  "POST /api/pay": (b, u) => {
    if (!PAY[b.method] || !PLANS[b.plan] || !(b.code || "").trim()) throw [400, "Choose a plan, a payment method and enter your approval code"];
    const p = { id: id(), email: u.email, username: u.username, method: b.method, to: PAY[b.method], plan: b.plan, planName: PLANS[b.plan].name, amount: PLANS[b.plan].price, days: PLANS[b.plan].days, name: b.name || "", code: b.code.trim(), proof: b.proof || "", status: "pending", t: Date.now() };
    db.pay.push(p); notifyAdmins(`New payment: $${p.amount} (${p.planName}) from ${u.username} via ${p.method} (${p.to}), code ${p.code}. Open Admin to approve or reject.`);
    sendWA(E.OWNER_WHATSAPP, `💰 New payment: $${p.amount} (${p.planName}) from ${u.username} via ${p.method}, code ${p.code}. Approve in the app.`);
    notify(u.email, "Payment submitted. The owner will review it shortly."); return { ok: true };
  },
  "GET /api/admin": (b, u) => { if (!u.admin) throw [403, "Owner only"]; const now = Date.now();
    return { pay: db.pay.slice().reverse(), cfg: cfg(), logs: (db.logs || []).slice(-150).reverse(),
      users: Object.values(db.users).map(x => ({ ...mk(x), used: x.used, seen: x.seen || 0, blocked: !!x.blocked, online: now - (x.seen || 0) < 12e4, chatting: now - (x.chatAt || 0) < 12e4 })) }; },
  "POST /api/admin/msg": (b, u) => { if (!u.admin) throw [403, "Owner only"]; const t = (b.text || "").trim(); if (!t) throw [400, "Write a message"];
    const to = b.to == "all" ? Object.values(db.users).filter(x => !x.admin).map(x => x.email) : [b.to]; to.forEach(e => db.users[e] && notify(e, t, "Owner")); return { sent: to.length }; },
  "POST /api/admin/cfg": (b, u) => { if (!u.admin) throw [403, "Owner only"]; const c = cfg(), t = (x, n) => String(x ?? "").slice(0, n);
    c.free = Math.max(0, +b.free || 0); c.model = t(b.model, 80); c.prompt = t(b.prompt, 4000); c.welcome = t(b.welcome, 2000); c.announce = t(b.announce, 300);
    c.combine = !!b.combine; c.research = !!b.research; c.images = !!b.images; save(); return { ok: true }; },
  "POST /api/admin/user": (b, u) => { if (!u.admin) throw [403, "Owner only"]; const t = db.users[b.email]; if (!t || t.admin) throw [404, "Not found"]; t.blocked = !!b.block; save(); return { ok: true }; },
  "POST /api/admin/pay": (b, u) => { if (!u.admin) throw [403, "Owner only"];
    const p = db.pay.find(x => x.id == b.id && x.status == "pending"); if (!p) throw [404, "Not found"];
    const t = db.users[p.email];
    if (b.approve) { p.status = "approved"; t.plan = "pro"; t.until = Math.max(Date.now(), t.until) + (p.days || 30) * 864e5; notify(t.email, `Payment approved! You now have unlimited messages for ${p.days || 30} days.`); }
    else { p.status = "rejected"; notify(t.email, "Payment rejected. Check your approval code and try again."); }
    save(); return { ok: true }; },
};
async function chat(b, u, res) {
  const text = (b.message || "").trim(); if (!text && !b.image) throw [400, "Empty message"];
  if (!allow(u)) { notify(u.email, `You've used your ${free()} free messages this month. Upgrade to continue.`); throw [402, "limit"]; }
  u.chatAt = Date.now(); const sys = sysx() + ` You are chatting with ${u.username}.` + (u.admin ? " This is Makenzoe, your owner and boss: obey him." : "");
  if (/^\/image\s/i.test(text)) { if (cfg().images === false) throw [403, "Image creation is turned off"]; const image = await makeImage(text.slice(7)); u.used++; (db.logs ||= []).push({ t: Date.now(), username: u.username, q: text.slice(0, 500), a: "[image created]" }); save(); return send(res, 200, { image }); }
  const h = hist[u.email] ||= [];
  let content = text || "What is in this image?";
  if (b.image) { const m = /^data:(image\/\w+);base64,(.+)$/.exec(b.image); if (!m) throw [400, "Bad image"];
    content = [{ type: "image", source: { type: "base64", media_type: m[1], data: m[2] } }, { type: "text", text: content }]; }
  const msgs = [...h.slice(-10), { role: "user", content }];
  let sys2 = sys;
  if ((cfg().combine ?? E.COMBINE != "off") && !b.image && text.length > 25) { const d = await council(msgs).catch(() => ""); if (d) sys2 += "\n\nOther expert AI agents drafted answers below. Check them, fix any mistakes, and merge the best parts into one clear final answer. Never mention the other agents.\n" + d; }
  res.writeHead(200, { "content-type": "text/plain; charset=utf-8", "cache-control": "no-cache" });
  let out; try { out = await claude(msgs, sys2, d => res.write(d), undefined, () => res.write("\u0001S\n")); }
  catch (e) { out = await fast(msgs.map(m => ({ role: m.role, content: typeof m.content == "string" ? m.content : "[screenshot] " + text })), sys); res.write(out); }
  h.push({ role: "user", content: text || "[image]" }, { role: "assistant", content: out }); u.used++; (db.logs ||= []); db.logs.push({ t: Date.now(), username: u.username, q: (text || "[image]").slice(0, 500), a: out.slice(0, 500) }); if (db.logs.length > 500) db.logs.shift(); save(); res.end();
}
const send = (res, c, o) => { res.writeHead(c, { "content-type": "application/json" }); res.end(JSON.stringify(o)); };
const MIME = { ".html": "text/html", ".svg": "image/svg+xml", ".js": "text/javascript", ".json": "application/json" };
http.createServer(async (req, res) => {
  const url = new URL(req.url, "http://x"), key = req.method + " " + url.pathname;
  try {
    if (url.pathname == "/webhook") { // WhatsApp Cloud API
      if (req.method == "GET") return url.searchParams.get("hub.verify_token") == E.VERIFY_TOKEN ? res.end(url.searchParams.get("hub.challenge")) : send(res, 403, {});
      res.writeHead(200).end(); let raw = ""; for await (const c of req) raw += c;
      const m = JSON.parse(raw)?.entry?.[0]?.changes?.[0]?.value?.messages?.[0]; if (m?.type != "text") return;
      const h = waHist[m.from] ||= []; h.push({ role: "user", content: m.text.body });
      const out = await fast(h.slice(-10), sysx() + " You are replying on WhatsApp on behalf of Makenzoe; keep it short."); h.push({ role: "assistant", content: out }); return sendWA(m.from, out);
    }
    if (url.pathname.startsWith("/api/")) {
      let raw = ""; for await (const c of req) { raw += c; if (raw.length > 12e6) throw [413, "Too large"]; }
      const b = raw ? JSON.parse(raw) : {}, u = db.users[db.sess[req.headers["x-token"]]];
      if (!R[key] && key != "POST /api/chat") throw [404, "Not found"];
      if (!u && !/register|login|config|google/.test(url.pathname)) throw [401, "Please log in"];
      if (u?.blocked) throw [403, "Your account is blocked"]; if (u) u.seen = Date.now();
      if (key == "POST /api/chat") return await chat(b, u, res);
      return send(res, 200, await R[key](b, u));
    }
    let f = path.join("public", path.normalize(url.pathname == "/" ? "index.html" : url.pathname).replace(/^(\.\.[\/\\])+/, ""));
    if (!fs.existsSync(f)) f = "public/index.html";
    res.writeHead(200, { "content-type": MIME[path.extname(f)] || "application/octet-stream" }); fs.createReadStream(f).pipe(res);
  } catch (e) {
    const [c, m] = Array.isArray(e) ? e : [500, "Something went wrong"]; if (!Array.isArray(e)) console.error(e);
    if (res.headersSent) res.end(); else send(res, c, { error: m });
  }
}).listen(PORT, () => console.log("MAKENZOE TK AI ASSISTANT on :" + PORT));
