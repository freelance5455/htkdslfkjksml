NovaChat — Human-polished local-first prototype

Open index.html in a modern browser. No server or account is required for the interface and local conversation history.

Important: this build is a polished foundation, not yet a full embedded AI model. The next engineering step is to package a compatible on-device language model (for example WebAssembly/WebGPU) and connect it to the chat UI.
