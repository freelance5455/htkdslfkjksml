package com.wkscripts.painelcmdwk;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.provider.Settings;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.File;
import java.text.DecimalFormat;

public class MainActivity extends Activity {
    private WebView webView;
    private final DecimalFormat numberFormat = new DecimalFormat("#,##0.0");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(android.graphics.Color.rgb(7, 10, 9));
        window.setNavigationBarColor(android.graphics.Color.rgb(7, 10, 9));
        window.getDecorView().setSystemUiVisibility(0);

        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(7, 10, 9));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.setSafeBrowsingEnabled(true);
        }
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(this), "Android");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void openSystemScreen(String action) {
        try {
            Intent intent = new Intent(action);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception firstError) {
            try {
                Intent fallback = new Intent(Settings.ACTION_SETTINGS);
                fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(fallback);
            } catch (Exception ignored) {
                Toast.makeText(this, "Tela de configurações indisponível neste aparelho.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private String formatBytes(long bytes) {
        if (bytes < 0) return "Indisponível";
        double value = bytes;
        String[] units = {"B", "KB", "MB", "GB", "TB"};
        int index = 0;
        while (value >= 1024 && index < units.length - 1) {
            value /= 1024;
            index++;
        }
        return numberFormat.format(value) + " " + units[index];
    }

    private boolean isNetworkConnected() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return false;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Network network = cm.getActiveNetwork();
                if (network == null) return false;
                NetworkCapabilities caps = cm.getNetworkCapabilities(network);
                return caps != null && (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                        || caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                        || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
                        || caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN));
            }
            return cm.getActiveNetworkInfo() != null && cm.getActiveNetworkInfo().isConnected();
        } catch (Exception e) {
            return false;
        }
    }

    public class AndroidBridge {
        private final MainActivity activity;

        AndroidBridge(MainActivity activity) {
            this.activity = activity;
        }

        @JavascriptInterface
        public String getDeviceInfo() {
            JSONObject result = new JSONObject();
            try {
                Intent batteryIntent = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
                int level = 0;
                int scale = 100;
                int status = -1;
                if (batteryIntent != null) {
                    level = batteryIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0);
                    scale = batteryIntent.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
                    status = batteryIntent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                }
                int battery = scale > 0 ? Math.round((level * 100f) / scale) : 0;
                boolean charging = status == BatteryManager.BATTERY_STATUS_CHARGING
                        || status == BatteryManager.BATTERY_STATUS_FULL;

                ActivityManager.MemoryInfo memory = new ActivityManager.MemoryInfo();
                ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
                if (am != null) am.getMemoryInfo(memory);

                StatFs stat = new StatFs(Environment.getDataDirectory().getAbsolutePath());
                long totalStorage = stat.getTotalBytes();
                long freeStorage = stat.getAvailableBytes();

                result.put("battery", battery);
                result.put("charging", charging);
                result.put("ramTotal", formatBytes(memory.totalMem));
                result.put("ramAvailable", formatBytes(memory.availMem));
                result.put("storageTotal", formatBytes(totalStorage));
                result.put("storageFree", formatBytes(freeStorage));
                result.put("network", isNetworkConnected() ? "Conectado" : "Sem conexão");
                result.put("androidVersion", Build.VERSION.RELEASE);
                result.put("device", Build.MANUFACTURER + " " + Build.MODEL);
            } catch (Exception e) {
                try { result.put("error", "Não foi possível consultar todos os dados."); }
                catch (Exception ignored) {}
            }
            return result.toString();
        }

        @JavascriptInterface
        public String clearOwnCache() {
            long before = directorySize(new File(getCacheDir(), "wk_temp"));
            boolean cleared = deleteContents(new File(getCacheDir(), "wk_temp"));
            File temp = new File(getCacheDir(), "wk_temp");
            if (!temp.exists()) temp.mkdirs();
            final String message = cleared
                    ? "Cache temporário deste painel limpo. Espaço liberado: " + formatBytes(before)
                    : "Não foi possível limpar todos os arquivos temporários.";
            runOnUiThread(() -> {
                if (webView != null) webView.clearCache(true);
                Toast.makeText(activity, message, Toast.LENGTH_LONG).show();
            });
            return message;
        }

        @JavascriptInterface
        public void openBatterySettings() {
            runOnUiThread(() -> openSystemScreen(Settings.ACTION_BATTERY_SAVER_SETTINGS));
        }

        @JavascriptInterface
        public void openStorageSettings() {
            runOnUiThread(() -> openSystemScreen(Settings.ACTION_INTERNAL_STORAGE_SETTINGS));
        }

        @JavascriptInterface
        public void openAppSettings() {
            runOnUiThread(() -> openSystemScreen(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS));
        }

        @JavascriptInterface
        public void openWifiSettings() {
            runOnUiThread(() -> openSystemScreen(Settings.ACTION_WIFI_SETTINGS));
        }

        @JavascriptInterface
        public void openNetworkSettings() {
            runOnUiThread(() -> openSystemScreen(Settings.ACTION_WIRELESS_SETTINGS));
        }

        @JavascriptInterface
        public void shareLogs(String text) {
            final String safeText = text == null ? "Sem registros." : text;
            runOnUiThread(() -> {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_SUBJECT, "PAINEL CMD WK - Logs");
                send.putExtra(Intent.EXTRA_TEXT, safeText);
                startActivity(Intent.createChooser(send, "Exportar logs"));
            });
        }
    }

    private long directorySize(File file) {
        if (!file.exists()) return 0;
        if (file.isFile()) return file.length();
        long total = 0;
        File[] children = file.listFiles();
        if (children != null) for (File child : children) total += directorySize(child);
        return total;
    }

    private boolean deleteContents(File file) {
        if (!file.exists()) return true;
        if (file.isFile()) return file.delete();
        boolean ok = true;
        File[] children = file.listFiles();
        if (children != null) {
            for (File child : children) ok &= deleteContents(child);
        }
        return ok && (file.equals(new File(getCacheDir(), "wk_temp")) || file.delete());
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("Android");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
