# CGD — Étape 6.8 : écran 08, Tactique et composition (disposition FM27)

- L'onglet « Tactique » ouvre maintenant deux sous-écrans : « Tactique et composition » (par défaut) et « Terrain de match ».
- Consignes du club : formation (Centre, Ailes, Mixte), style (Attaque, Équilibré, Prudent), rythme (Normal, Rapide), enregistrées dans `state.options.tactics`.
- Aperçu du damier : la formation colore en doré les colonnes que le club cherche à occuper ; la position de départ des pions reste fixée par les règles.
- Le choix du titulaire se fait dans la préparation du match (écran 09), qui affiche aussi les consignes.
- Navigation : « Voir le terrain » (écran 08) → terrain ; « Tactique » et « Voir les tactiques » (écran 10) → écran 08.
- Code : `src/tactics.js`, `src/tactics-ui.js`, branchements dans `src/app.js`, styles dans le bloc `fm27-terrain`, tests dans `tests/tactics.test.js`.
- Important : les consignes n'ont pas encore d'effet sur le jeu ; elles serviront au bouton « Simuler » (non branché).
