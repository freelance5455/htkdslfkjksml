package com.damavaram.voterfinder;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceError;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Base64;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Hosts the Voter Finder page (assets/index.html) and exposes the "Android" bridge used by the page
 * for Salesforce sync and file export. All network work runs on a background thread; results are
 * delivered to the page with window.onSfResult / window.onSfAuth / window.onSaveDone.
 */
public class MainActivity extends Activity {

    private static final int REQ_SAVE = 41, REQ_PICK = 42;
    private static final String PAGE = "file:///android_asset/index.html";

    private WebView web;
    private FrameLayout root;
    private LinearLayout loginPanel;      // in-app Salesforce login window
    private boolean loginHandled;
    private Sf sf;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private byte[] pendingSave;
    private String pendingSaveName;
    private ValueCallback<Uri[]> pendingPick;
    private volatile String pendingAuth;   // login result kept until the page has received it

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        sf = new Sf(new PrefsKv(this), new TokenStore(this));
        web = new WebView(this);
        root = new FrameLayout(this);
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setTextZoom(100);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                String u = req.getUrl().toString();
                if (u.startsWith("file:///android_asset/")) return false;
                openExternal(req.getUrl());          // tel:, https: links etc. open outside the app
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (pendingPick != null) pendingPick.onReceiveValue(null);
                pendingPick = cb;
                try { startActivityForResult(p.createIntent(), REQ_PICK); }
                catch (ActivityNotFoundException e) { pendingPick = null; return false; }
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl(PAGE);   // always a fresh page: tags and settings live in storage, not in the screen
        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    /** Login redirect: com.damavaram.voterfinder://oauth?code=...&state=... */
    private void handleIntent(Intent intent) {
        Uri d = intent == null ? null : intent.getData();
        if (d == null || !"com.damavaram.voterfinder".equals(d.getScheme())) return;
        final String uri = d.toString();
        intent.setData(null);
        io.execute(() -> {
            JSONObject r;
            try { r = sf.handleRedirect(uri); } catch (Exception e) { r = err(e); }
            deliverAuth(r);
        });
    }

    // ------------------------------------------------------------------ in-app login

    /**
     * Shows the Salesforce login page inside the app and catches the redirect to
     * com.damavaram.voterfinder://oauth directly, so the result always comes back to the app.
     * This window has no JavaScript bridge: Salesforce pages cannot call the app.
     */
    private void openLogin(String url) {
        closeLogin();
        loginHandled = false;
        loginPanel = new LinearLayout(this);
        loginPanel.setOrientation(LinearLayout.VERTICAL);
        loginPanel.setBackgroundColor(Color.WHITE);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(Color.rgb(43, 58, 140));
        TextView title = new TextView(this);
        title.setText("Salesforce login");
        title.setTextColor(Color.WHITE);
        title.setTextSize(17);
        title.setPadding(36, 24, 12, 24);
        Button cancel = new Button(this);
        cancel.setText("Cancel");
        cancel.setOnClickListener(v -> cancelLogin("Login cancelled."));
        bar.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        bar.addView(cancel, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        WebView lw = new WebView(this);
        WebSettings s = lw.getSettings();
        s.setJavaScriptEnabled(true);          // Salesforce login needs JavaScript
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        lw.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                String u = req.getUrl().toString();
                if (u.startsWith(Sf.REDIRECT)) { finishLogin(u); return true; }
                return false;
            }

            @Override
            public void onPageStarted(WebView v, String u, android.graphics.Bitmap icon) {
                if (u != null && u.startsWith(Sf.REDIRECT)) { v.stopLoading(); finishLogin(u); }
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest req, WebResourceError e) {
                if (!req.isForMainFrame()) return;
                String u = req.getUrl().toString();
                if (u.startsWith(Sf.REDIRECT)) { finishLogin(u); return; }
                sf.log("Login page could not load: " + e.getDescription() + " (" + u + ")");
                cancelLogin("Could not open the Salesforce login page (" + e.getDescription()
                        + "). Check the My Domain URL and the internet connection.");
            }
        });
        loginPanel.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        loginPanel.addView(lw, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(loginPanel, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        lw.loadUrl(url);
    }

    private void finishLogin(String redirectUri) {
        if (loginHandled) return;
        loginHandled = true;
        closeLogin();
        io.execute(() -> {
            JSONObject r;
            try { r = sf.handleRedirect(redirectUri); } catch (Exception e) { r = err(e); }
            deliverAuth(r);
        });
    }

    private void cancelLogin(String message) {
        if (loginHandled) return;
        loginHandled = true;
        closeLogin();
        sf.log(message);
        JSONObject r = new JSONObject();
        try { r.put("ok", false); r.put("error", "auth"); r.put("message", message); } catch (Exception ignore) { }
        deliverAuth(r);
    }

    private void closeLogin() {
        if (loginPanel == null) return;
        View p = loginPanel;
        loginPanel = null;
        root.removeView(p);
        for (int i = 0; i < ((LinearLayout) p).getChildCount(); i++) {
            View c = ((LinearLayout) p).getChildAt(i);
            if (c instanceof WebView) ((WebView) c).destroy();
        }
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (loginPanel != null) { cancelLogin("Login cancelled."); return; }
        web.evaluateJavascript("(window.onBack&&window.onBack())?'1':'0'", v -> {
            if (!"\"1\"".equals(v)) {
                if (web.canGoBack()) web.goBack(); else MainActivity.super.onBackPressed();
            }
        });
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_PICK) {
            if (pendingPick != null) pendingPick.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            pendingPick = null;
        } else if (req == REQ_SAVE) {
            final byte[] bytes = pendingSave; final String name = pendingSaveName;
            pendingSave = null;
            if (res != RESULT_OK || data == null || data.getData() == null || bytes == null) { saveDone(false, "Not saved"); return; }
            final Uri uri = data.getData();
            io.execute(() -> {
                try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                    if (os == null) throw new IllegalStateException("cannot open file");
                    os.write(bytes);
                    saveDone(true, "Saved " + name);
                } catch (Exception e) { saveDone(false, "Could not save: " + e.getMessage()); }
            });
        }
    }

    @Override
    protected void onDestroy() {
        io.shutdown();
        web.destroy();
        super.onDestroy();
    }

    // ------------------------------------------------------------------ helpers

    private void openExternal(Uri u) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, u)); }
        catch (ActivityNotFoundException e) { toast("No app can open this link."); }
    }

    private void toast(String m) { runOnUiThread(() -> Toast.makeText(this, m, Toast.LENGTH_SHORT).show()); }

    /** JSON as a JavaScript argument (JSON is valid JS once line/paragraph separators are escaped). */
    static String jsArg(JSONObject o) {
        return o.toString().replace("\u2028", "\\u2028").replace("\u2029", "\\u2029");
    }

    static String jsStr(String s) { return JSONObject.quote(s == null ? "" : s).replace("\u2028", "\\u2028").replace("\u2029", "\\u2029"); }

    static JSONObject err(Exception e) {
        JSONObject o = new JSONObject();
        try { o.put("ok", false); o.put("error", "app"); o.put("message", String.valueOf(e.getMessage())); } catch (Exception ignore) { }
        return o;
    }

    /** Sends a login result to the page; if the page is not ready yet it collects it via sfPendingAuth(). */
    private void deliverAuth(JSONObject r) {
        final String arg = jsArg(r);
        pendingAuth = arg;
        runOnUiThread(() -> web.evaluateJavascript("window.onSfAuth?(window.onSfAuth(" + arg + "),'1'):'0'", v -> {
            if ("\"1\"".equals(v)) pendingAuth = null;
        }));
    }

    private void js(String code) { runOnUiThread(() -> web.evaluateJavascript(code, null)); }

    private void result(String reqId, JSONObject r) {
        js("window.onSfResult&&window.onSfResult(" + jsStr(reqId) + "," + jsArg(r) + ")");
    }

    private void saveDone(boolean ok, String msg) {
        js("window.onSaveDone&&window.onSaveDone(" + ok + "," + jsStr(msg) + ")");
    }

    // ------------------------------------------------------------------ bridge

    /** Methods callable from the page as window.Android.x(...). Runs on a WebView binder thread. */
    class Bridge {

        @JavascriptInterface public String sfGetConfig() {
            try { return sf.config().toString(); } catch (Exception e) { return "{}"; }
        }

        /** Called by the page once loaded: returns (and clears) a login result that arrived earlier. */
        @JavascriptInterface public String sfPendingAuth() {
            String a = pendingAuth; pendingAuth = null;
            return a == null ? "" : a;
        }

        @JavascriptInterface public String sfLog() { return sf.logText(); }

        @JavascriptInterface public String sfSetConfig(String domain, String clientId, String clientSecret, String mode) {
            try { return sf.setConfig(domain, clientId, clientSecret, mode).toString(); } catch (Exception e) { return err(e).toString(); }
        }

        /** User mode: opens the Salesforce login page in the browser. App mode: logs in directly. */
        @JavascriptInterface public void sfLogin() {
            if ("app".equals(sf.mode())) {
                io.execute(() -> {
                    JSONObject r;
                    try { r = sf.loginApp(); } catch (Exception e) { r = err(e); }
                    deliverAuth(r);
                });
                return;
            }
            try {
                String u = sf.authUrl();
                runOnUiThread(() -> openLogin(u));
            } catch (Exception e) {
                deliverAuth(err(e));
            }
        }

        @JavascriptInterface public void sfLogout() {
            io.execute(() -> {
                JSONObject r;
                try { r = sf.logout(); } catch (Exception e) { r = err(e); }
                runOnUiThread(() -> CookieManager.getInstance().removeAllCookies(null));   // next login starts clean
                deliverAuth(r);
            });
        }

        @JavascriptInterface public void sfPush(String reqId, String changesJson) {
            io.execute(() -> {
                JSONObject r;
                try { r = sf.push(changesJson); } catch (Exception e) { r = err(e); }
                result(reqId, r);
            });
        }

        @JavascriptInterface public void sfPull(String reqId, String sinceMs) {
            io.execute(() -> {
                JSONObject r;
                long since = 0;
                try { since = Long.parseLong(sinceMs.trim()); } catch (Exception ignore) { }
                try { r = sf.pull(since); } catch (Exception e) { r = err(e); }
                result(reqId, r);
            });
        }

        @JavascriptInterface public void sfTest(String reqId) {
            io.execute(() -> {
                JSONObject r;
                try { r = sf.test(); } catch (Exception e) { r = err(e); }
                result(reqId, r);
            });
        }

        /** Asks the user where to save (works on every Android version, no storage permission). */
        @JavascriptInterface public void saveFile(String name, String mime, String b64) {
            try {
                pendingSave = Base64.getDecoder().decode(b64);
                pendingSaveName = name;
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType(mime);
                i.putExtra(Intent.EXTRA_TITLE, name);
                runOnUiThread(() -> {
                    try { startActivityForResult(i, REQ_SAVE); }
                    catch (ActivityNotFoundException e) { shareFile(name, mime, b64); }
                });
            } catch (Exception e) { saveDone(false, "Could not save: " + e.getMessage()); }
        }

        @JavascriptInterface public void shareFile(String name, String mime, String b64) {
            try {
                String safe = name.replaceAll("[^A-Za-z0-9._-]", "_");
                File f = new File(ShareProvider.dir(MainActivity.this), safe);
                try (FileOutputStream os = new FileOutputStream(f)) { os.write(Base64.getDecoder().decode(b64)); }
                Uri u = Uri.parse("content://" + ShareProvider.AUTHORITY + "/" + safe);
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType(mime);
                i.putExtra(Intent.EXTRA_STREAM, u);
                i.setClipData(ClipData.newRawUri(safe, u));
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                runOnUiThread(() -> startActivity(Intent.createChooser(i, name)));
            } catch (Exception e) { saveDone(false, "Could not share: " + e.getMessage()); }
        }

        @JavascriptInterface public void copyText(String text) {
            runOnUiThread(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Voter Finder", text));
                toast("Copied");
            });
        }

        @JavascriptInterface public void shareText(String title, String text) {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_SUBJECT, title);
            i.putExtra(Intent.EXTRA_TEXT, text);
            runOnUiThread(() -> startActivity(Intent.createChooser(i, title)));
        }
    }
}
