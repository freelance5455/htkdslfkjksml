package com.damavaram.voterfinder;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.NoRouteToHostException;
import java.net.ProtocolException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Salesforce connection for the Voter Finder app. Plain Java (no Android classes) so it can be
 * tested off-device. Storage is injected: {@code prefs} for plain settings, {@code secure} for the
 * client secret and tokens (encrypted on the phone by TokenStore).
 *
 * Login modes:
 *   "user" - OAuth 2.0 authorization code + PKCE in the browser; client secret sent if one is saved.
 *   "app"  - OAuth 2.0 client credentials (client id + secret only, no sign-in page).
 */
public class Sf {

    public interface Kv {
        String get(String key);
        void put(String key, String value);
        void remove(String key);
    }

    public static final String API = "v62.0";
    public static final String REDIRECT = "com.damavaram.voterfinder://oauth";
    static final int BATCH = 200;
    static final DateTimeFormatter SF_TIME = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSxx");

    /** Thrown when no valid token can be obtained; the user must log in again. */
    public static class AuthException extends Exception {
        public AuthException(String m) { super(m); }
    }

    /** HTTP status + body. */
    static class Resp {
        final int code; final String body;
        Resp(int code, String body) { this.code = code; this.body = body; }
        boolean ok() { return code >= 200 && code < 300; }
    }

    final Kv prefs, secure;
    int timeoutMs = 30000;
    private final SecureRandom rnd = new SecureRandom();
    private final java.util.ArrayDeque<String> logLines = new java.util.ArrayDeque<>();

    /** Connection log shown in Settings. Never contains the client secret or tokens. */
    public synchronized void log(String line) {
        String t = java.time.LocalTime.now().withNano(0).toString();
        logLines.addLast(t + "  " + line);
        while (logLines.size() > 80) logLines.removeFirst();
    }

    public synchronized String logText() {
        return logLines.isEmpty() ? "No connection activity yet." : String.join("\n", logLines);
    }

    static String mask(String s) {
        s = nz(s);
        return s.length() <= 8 ? "****" : s.substring(0, 4) + "..." + s.substring(s.length() - 4);
    }

    public Sf(Kv prefs, Kv secure) { this.prefs = prefs; this.secure = secure; }

    // ------------------------------------------------------------------ settings

    static String nz(String s) { return s == null ? "" : s; }

    public String deviceId() {
        String d = prefs.get("device_id");
        if (d == null || d.isEmpty()) { d = UUID.randomUUID().toString(); prefs.put("device_id", d); }
        return d;
    }

    public String mode() { String m = prefs.get("mode"); return "app".equals(m) ? "app" : "user"; }

    public boolean loggedIn() { return !nz(secure.get("access_token")).isEmpty() || !nz(secure.get("refresh_token")).isEmpty(); }

    public JSONObject config() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("domain", nz(prefs.get("domain")));
        o.put("clientId", nz(prefs.get("client_id")));
        o.put("hasSecret", !nz(secure.get("client_secret")).isEmpty());
        o.put("mode", mode());
        o.put("loggedIn", loggedIn());
        o.put("user", nz(prefs.get("user_name")));
        o.put("instance", nz(prefs.get("instance_url")));
        o.put("deviceId", deviceId());
        return o;
    }

    /** Normalises the My Domain URL: trims, adds https://, removes trailing slashes and paths. */
    static String normDomain(String d) {
        d = nz(d).trim();
        if (d.isEmpty()) return "";
        if (!d.startsWith("http://") && !d.startsWith("https://")) d = "https://" + d;
        d = d.replaceFirst("^http://", "https://");
        int slash = d.indexOf('/', "https://".length());
        if (slash > 0) d = d.substring(0, slash);
        return d;
    }

    /**
     * Saves settings. An empty clientSecret keeps the saved one; changing domain, client id or mode
     * signs out, because old tokens belong to the old settings.
     */
    public JSONObject setConfig(String domain, String clientId, String clientSecret, String mode) throws JSONException {
        String d = normDomain(domain), c = nz(clientId).trim(), m = "app".equals(mode) ? "app" : "user";
        JSONObject r = new JSONObject();
        if (d.isEmpty() || c.isEmpty()) { r.put("ok", false); r.put("message", "My Domain URL and Client ID are required."); return r; }
        boolean changed = !d.equals(nz(prefs.get("domain"))) || !c.equals(nz(prefs.get("client_id"))) || !m.equals(mode());
        prefs.put("domain", d); prefs.put("client_id", c); prefs.put("mode", m);
        String s = nz(clientSecret).trim();
        if (!s.isEmpty()) { secure.put("client_secret", s); changed = true; }
        if (changed) clearTokens();
        log("Settings saved: " + d + ", client ID " + mask(c) + ", secret " + (nz(secure.get("client_secret")).isEmpty() ? "not set" : "saved") + ", login type " + m);
        if ("app".equals(m) && nz(secure.get("client_secret")).isEmpty()) {
            r.put("ok", false); r.put("message", "App-only login needs the Client Secret."); return r;
        }
        r.put("ok", true); r.put("message", changed ? "Saved. Log in to continue." : "Saved.");
        return r;
    }

    void clearTokens() {
        secure.remove("access_token"); secure.remove("refresh_token");
        prefs.remove("instance_url"); prefs.remove("identity_url"); prefs.remove("user_name");
    }

    // ------------------------------------------------------------------ login

    static String b64url(byte[] b) { return Base64.getUrlEncoder().withoutPadding().encodeToString(b); }

    static String enc(String s) {
        try { return URLEncoder.encode(s, "UTF-8"); } catch (Exception e) { throw new RuntimeException(e); }
    }

    static String form(Map<String, String> m) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> e : m.entrySet()) {
            if (e.getValue() == null || e.getValue().isEmpty()) continue;
            if (sb.length() > 0) sb.append('&');
            sb.append(enc(e.getKey())).append('=').append(enc(e.getValue()));
        }
        return sb.toString();
    }

    /** Browser URL for user login. Saves the PKCE verifier and state for {@link #handleRedirect}. */
    public String authUrl() throws Exception {
        String d = nz(prefs.get("domain")), c = nz(prefs.get("client_id"));
        if (d.isEmpty() || c.isEmpty()) throw new IllegalStateException("Enter My Domain URL and Client ID first.");
        byte[] v = new byte[48]; rnd.nextBytes(v);
        String verifier = b64url(v);
        String challenge = b64url(MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII)));
        byte[] s = new byte[16]; rnd.nextBytes(s);
        String state = b64url(s);
        secure.put("pkce_verifier", verifier); prefs.put("oauth_state", state);
        log("Opening login page " + d + "/services/oauth2/authorize");
        return d + "/services/oauth2/authorize?response_type=code"
                + "&client_id=" + enc(c) + "&redirect_uri=" + enc(REDIRECT)
                + "&code_challenge=" + challenge + "&code_challenge_method=S256"
                + "&scope=" + enc("api refresh_token") + "&state=" + state;
    }

    static Map<String, String> query(String uri) {
        Map<String, String> m = new HashMap<>();
        int q = uri.indexOf('?');
        if (q < 0) return m;
        String qs = uri.substring(q + 1);
        int h = qs.indexOf('#'); if (h >= 0) qs = qs.substring(0, h);
        for (String p : qs.split("&")) {
            int e = p.indexOf('=');
            try {
                if (e > 0) m.put(URLDecoder.decode(p.substring(0, e), "UTF-8"), URLDecoder.decode(p.substring(e + 1), "UTF-8"));
            } catch (Exception ignore) { }
        }
        return m;
    }

    /** Completes user login from the redirect URI com.damavaram.voterfinder://oauth?code=...&state=... */
    public JSONObject handleRedirect(String uri) throws JSONException {
        Map<String, String> q = query(uri);
        log("Login reply received: " + (q.containsKey("code") ? "authorization code" : q.containsKey("error") ? "error " + q.get("error") : "no code"));
        if (q.containsKey("error")) return fail("auth", "Salesforce: " + nz(q.get("error_description")).replace('+', ' ') + " (" + q.get("error") + ")");
        String state = prefs.get("oauth_state");
        if (state == null || !state.equals(q.get("state"))) return fail("auth", "Login reply did not match this app. Tap Log in again.");
        prefs.remove("oauth_state");
        Map<String, String> f = new java.util.LinkedHashMap<>();
        f.put("grant_type", "authorization_code");
        f.put("code", q.get("code"));
        f.put("client_id", prefs.get("client_id"));
        f.put("client_secret", secure.get("client_secret"));
        f.put("redirect_uri", REDIRECT);
        f.put("code_verifier", secure.get("pkce_verifier"));
        secure.remove("pkce_verifier");
        return tokenRequest(f, true);
    }

    /** App-only login with client id + secret. */
    public JSONObject loginApp() throws JSONException {
        if (nz(secure.get("client_secret")).isEmpty()) return fail("auth", "App-only login needs the Client Secret.");
        Map<String, String> f = new java.util.LinkedHashMap<>();
        f.put("grant_type", "client_credentials");
        f.put("client_id", prefs.get("client_id"));
        f.put("client_secret", secure.get("client_secret"));
        return tokenRequest(f, true);
    }

    JSONObject tokenRequest(Map<String, String> f, boolean identity) throws JSONException {
        Resp r;
        try {
            log("Token request (" + f.get("grant_type") + ") to " + nz(prefs.get("domain")));
            r = http("POST", nz(prefs.get("domain")) + "/services/oauth2/token", form(f), "application/x-www-form-urlencoded", null);
        } catch (IOException e) { log("Token request failed: " + e.getClass().getSimpleName() + " " + e.getMessage()); return netFail(e); }
        JSONObject j = parseObj(r.body);
        if (!r.ok() || !j.has("access_token")) {
            String err = j.optString("error", "http_" + r.code), desc = j.optString("error_description", r.body);
            log("Token request refused: HTTP " + r.code + " " + err + " - " + desc);
            if ("invalid_client".equals(err) || "invalid_client_id".equals(err))
                return fail("auth", "Client ID or Client Secret is wrong: " + desc + " (" + err + ")");
            return fail("auth", "Login failed: " + desc + " (" + err + ")");
        }
        secure.put("access_token", j.getString("access_token"));
        if (j.has("refresh_token")) secure.put("refresh_token", j.getString("refresh_token"));
        prefs.put("instance_url", j.optString("instance_url", prefs.get("domain")));
        if (j.has("id")) prefs.put("identity_url", j.getString("id"));
        if (identity) loadIdentity();
        log("Connected: instance " + nz(prefs.get("instance_url")) + (nz(prefs.get("user_name")).isEmpty() ? "" : ", user " + prefs.get("user_name")));
        JSONObject o = new JSONObject();
        o.put("ok", true); o.put("user", nz(prefs.get("user_name")));
        return o;
    }

    void loadIdentity() {
        String id = prefs.get("identity_url");
        if (id == null || id.isEmpty()) return;
        try {
            Resp r = http("GET", id, null, null, secure.get("access_token"));
            if (r.ok()) {
                JSONObject j = parseObj(r.body);
                String n = j.optString("display_name", j.optString("username", ""));
                if (!n.isEmpty()) prefs.put("user_name", n);
            }
        } catch (Exception ignore) { }
    }

    /** Gets a fresh access token: refresh token (user mode) or client credentials (app mode). */
    void renew() throws AuthException, IOException, JSONException {
        if ("app".equals(mode())) {
            JSONObject r = loginApp();
            if (!r.optBoolean("ok")) {
                if ("offline".equals(r.optString("error"))) throw new ConnectException(r.optString("message"));
                throw new AuthException(r.optString("message"));
            }
            return;
        }
        String rt = secure.get("refresh_token");
        if (rt == null || rt.isEmpty()) throw new AuthException("Please log in to Salesforce.");
        Map<String, String> f = new java.util.LinkedHashMap<>();
        f.put("grant_type", "refresh_token");
        f.put("refresh_token", rt);
        f.put("client_id", prefs.get("client_id"));
        f.put("client_secret", secure.get("client_secret"));
        Resp r = http("POST", nz(prefs.get("domain")) + "/services/oauth2/token", form(f), "application/x-www-form-urlencoded", null);
        JSONObject j = parseObj(r.body);
        log("Token renewal: HTTP " + r.code + (r.ok() ? "" : " " + j.optString("error")));
        if (!r.ok() || !j.has("access_token")) {
            clearTokens();
            String err = j.optString("error", "http_" + r.code);
            if ("invalid_client".equals(err) || "invalid_client_id".equals(err))
                throw new AuthException("Client ID or Client Secret is wrong (" + err + "). Check Salesforce settings.");
            throw new AuthException("Login expired (" + err + "). Please log in again.");
        }
        secure.put("access_token", j.getString("access_token"));
        if (j.has("instance_url")) prefs.put("instance_url", j.getString("instance_url"));
    }

    public JSONObject logout() throws JSONException {
        String t = secure.get("refresh_token");
        if (t == null || t.isEmpty()) t = secure.get("access_token");
        if (t != null && !t.isEmpty()) {
            try { http("POST", nz(prefs.get("domain")) + "/services/oauth2/revoke", "token=" + enc(t), "application/x-www-form-urlencoded", null); }
            catch (Exception ignore) { }
        }
        clearTokens();
        log("Logged out");
        JSONObject o = new JSONObject(); o.put("ok", true); o.put("message", "Logged out.");
        return o;
    }

    // ------------------------------------------------------------------ HTTP

    Resp http(String method, String url, String body, String contentType, String bearer) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setRequestMethod(method);
        } catch (ProtocolException e) {
            // Some HttpURLConnection versions refuse PATCH: Salesforce accepts POST + _HttpMethod=PATCH.
            c.disconnect();
            c = (HttpURLConnection) new URL(url + (url.contains("?") ? "&" : "?") + "_HttpMethod=" + method).openConnection();
            c.setRequestMethod("POST");
        }
        c.setConnectTimeout(timeoutMs);
        c.setReadTimeout(timeoutMs);
        c.setUseCaches(false);
        c.setRequestProperty("Accept", "application/json");
        if (bearer != null) c.setRequestProperty("Authorization", "Bearer " + bearer);
        if (body != null) {
            byte[] b = body.getBytes(StandardCharsets.UTF_8);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", contentType + "; charset=UTF-8");
            c.setFixedLengthStreamingMode(b.length);
            try (OutputStream os = c.getOutputStream()) { os.write(b); }
        }
        int code = c.getResponseCode();
        InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
        String text = "";
        if (in != null) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            in.close();
            text = new String(bo.toByteArray(), StandardCharsets.UTF_8);
        }
        c.disconnect();
        return new Resp(code, text);
    }

    /** Authenticated REST call; renews the token once on 401. */
    Resp api(String method, String pathOrUrl, String jsonBody) throws IOException, AuthException, JSONException {
        if (!loggedIn()) {
            if ("app".equals(mode())) renew();
            else throw new AuthException("Please log in to Salesforce.");
        }
        if (nz(secure.get("access_token")).isEmpty()) renew();
        String url = pathOrUrl.startsWith("http") ? pathOrUrl : nz(prefs.get("instance_url")) + pathOrUrl;
        Resp r = http(method, url, jsonBody, "application/json", secure.get("access_token"));
        if (r.code == 401) {
            renew();
            url = pathOrUrl.startsWith("http") ? pathOrUrl : nz(prefs.get("instance_url")) + pathOrUrl;
            r = http(method, url, jsonBody, "application/json", secure.get("access_token"));
            if (r.code == 401) { clearTokens(); throw new AuthException("Salesforce refused the login. Please log in again."); }
        }
        return r;
    }

    // ------------------------------------------------------------------ results

    static JSONObject parseObj(String s) {
        try { return new JSONObject(s == null || s.isEmpty() ? "{}" : s); } catch (JSONException e) { return new JSONObject(); }
    }

    static JSONObject fail(String error, String message) throws JSONException {
        JSONObject o = new JSONObject(); o.put("ok", false); o.put("error", error); o.put("message", message);
        return o;
    }

    static JSONObject netFail(Exception e) throws JSONException {
        if (e instanceof SocketTimeoutException) return fail("timeout", "Salesforce did not answer in time. Try again.");
        if (e instanceof UnknownHostException || e instanceof ConnectException || e instanceof NoRouteToHostException || e instanceof SocketException)
            return fail("offline", "No internet connection.");
        return fail("offline", "Network error: " + e.getMessage());
    }

    /** First error message from a Salesforce error body: [{"message":..,"errorCode":..}] */
    static String sfError(Resp r) {
        try {
            JSONArray a = new JSONArray(r.body);
            if (a.length() > 0) { JSONObject e = a.getJSONObject(0); return e.optString("errorCode") + ": " + e.optString("message"); }
        } catch (Exception ignore) { }
        return "HTTP " + r.code + " " + (r.body.length() > 300 ? r.body.substring(0, 300) : r.body);
    }

    static String iso(long ms) { return Instant.ofEpochMilli(ms).toString(); }

    static long ms(Object sfTime) {
        if (sfTime == null || sfTime == JSONObject.NULL) return 0;
        String s = sfTime.toString();
        try { return OffsetDateTime.parse(s, SF_TIME).toInstant().toEpochMilli(); }
        catch (Exception e) { try { return Instant.parse(s).toEpochMilli(); } catch (Exception x) { return 0; } }
    }

    static String str(JSONObject o, String k) {
        if (o == null || !o.has(k) || o.isNull(k)) return "";
        return o.optString(k, "");
    }

    // ------------------------------------------------------------------ sync

    /**
     * Sends changes. Input: [{"e":EPIC,"p":"TDP"?,"pt":ms?,"v":"Vote"?,"vt":ms?}]. Only the fields present are sent.
     * Output: {"ok":true,"results":[{"e","success","code"?,"message"?}]} plus "error"/"message" if it stopped early.
     */
    public JSONObject push(String changesJson) throws JSONException {
        JSONArray in = new JSONArray(changesJson);
        JSONArray results = new JSONArray();
        JSONObject out = new JSONObject();
        String dev = deviceId();
        for (int start = 0; start < in.length(); start += BATCH) {
            int end = Math.min(in.length(), start + BATCH);
            JSONArray recs = new JSONArray();
            for (int i = start; i < end; i++) {
                JSONObject c = in.getJSONObject(i);
                JSONObject r = new JSONObject();
                JSONObject attr = new JSONObject(); attr.put("type", "Voter__c");
                r.put("attributes", attr);
                r.put("EPIC__c", c.getString("e"));
                if (c.has("p")) { r.put("Party__c", c.getString("p")); r.put("Party_Updated_At__c", iso(c.getLong("pt"))); }
                if (c.has("v")) { r.put("Voting_Status__c", c.getString("v")); r.put("Status_Updated_At__c", iso(c.getLong("vt"))); }
                r.put("Last_Device_Id__c", dev);
                recs.put(r);
            }
            JSONObject body = new JSONObject();
            body.put("allOrNone", false);
            body.put("records", recs);
            Resp r;
            try {
                r = api("PATCH", "/services/data/" + API + "/composite/sobjects/Voter__c/EPIC__c", body.toString());
            } catch (AuthException e) {
                log("Sync stopped: " + e.getMessage());
                return partial(out, results, "auth", e.getMessage());
            } catch (IOException e) {
                log("Sync stopped: " + e.getClass().getSimpleName() + " " + e.getMessage());
                JSONObject f = netFail(e);
                return partial(out, results, f.getString("error"), f.getString("message"));
            }
            log("Sync batch of " + recs.length() + ": HTTP " + r.code);
            if (!r.ok()) return partial(out, results, "http", sfError(r));
            JSONArray a;
            try { a = new JSONArray(r.body); } catch (JSONException e) { return partial(out, results, "http", "Unexpected reply from Salesforce."); }
            for (int i = 0; i < a.length() && start + i < end; i++) {
                JSONObject s = a.getJSONObject(i);
                JSONObject res = new JSONObject();
                res.put("e", in.getJSONObject(start + i).getString("e"));
                res.put("success", s.optBoolean("success"));
                if (!s.optBoolean("success")) {
                    JSONArray errs = s.optJSONArray("errors");
                    JSONObject e0 = errs != null && errs.length() > 0 ? errs.getJSONObject(0) : new JSONObject();
                    res.put("code", e0.optString("statusCode", "ERROR"));
                    res.put("message", e0.optString("message", "Rejected by Salesforce"));
                }
                results.put(res);
            }
        }
        out.put("ok", true);
        out.put("results", results);
        return out;
    }

    static JSONObject partial(JSONObject out, JSONArray results, String error, String message) throws JSONException {
        out.put("ok", results.length() > 0);
        out.put("results", results);
        out.put("error", error);
        out.put("message", message);
        return out;
    }

    /**
     * Fetches voters changed after sinceMs (0 = all).
     * Output: {"ok":true,"rows":[{"e","p","pt","v","vt","by"}],"stamp":ms of newest SystemModstamp}
     */
    public JSONObject pull(long sinceMs) throws JSONException {
        String soql = "SELECT EPIC__c, Party__c, Party_Updated_At__c, Voting_Status__c, Status_Updated_At__c, Tagged_By__r.Name, SystemModstamp"
                + " FROM Voter__c WHERE EPIC__c != null"
                + (sinceMs > 0 ? " AND SystemModstamp > " + Instant.ofEpochMilli(sinceMs).truncatedTo(ChronoUnit.SECONDS).toString() : "")
                + " ORDER BY SystemModstamp";
        String next = "/services/data/" + API + "/query?q=" + enc(soql);
        JSONArray rows = new JSONArray();
        long stamp = sinceMs;
        try {
            while (next != null) {
                Resp r = api("GET", next, null);
                log("Refresh query: HTTP " + r.code);
                if (!r.ok()) return fail("http", sfError(r));
                JSONObject j = parseObj(r.body);
                JSONArray recs = j.optJSONArray("records");
                if (recs != null) for (int i = 0; i < recs.length(); i++) {
                    JSONObject s = recs.getJSONObject(i);
                    JSONObject o = new JSONObject();
                    o.put("e", str(s, "EPIC__c").toUpperCase());
                    o.put("p", str(s, "Party__c"));
                    o.put("pt", ms(s.opt("Party_Updated_At__c")));
                    o.put("v", str(s, "Voting_Status__c"));
                    o.put("vt", ms(s.opt("Status_Updated_At__c")));
                    JSONObject by = s.has("Tagged_By__r") && !s.isNull("Tagged_By__r") ? s.optJSONObject("Tagged_By__r") : null;
                    o.put("by", str(by, "Name"));
                    rows.put(o);
                    stamp = Math.max(stamp, ms(s.opt("SystemModstamp")));
                }
                next = j.optBoolean("done", true) ? null : str(j, "nextRecordsUrl");
                if (next != null && next.isEmpty()) next = null;
            }
        } catch (AuthException e) {
            log("Refresh stopped: " + e.getMessage());
            return fail("auth", e.getMessage());
        } catch (IOException e) {
            log("Refresh stopped: " + e.getClass().getSimpleName() + " " + e.getMessage());
            return netFail(e);
        }
        log("Refresh received " + rows.length() + " records");
        JSONObject out = new JSONObject();
        out.put("ok", true); out.put("rows", rows); out.put("stamp", stamp);
        return out;
    }

    /** Step-by-step connection check: settings, login, object and fields. */
    public JSONObject test() throws JSONException {
        JSONArray steps = new JSONArray();
        JSONObject out = new JSONObject();
        out.put("steps", steps);
        boolean set = !nz(prefs.get("domain")).isEmpty() && !nz(prefs.get("client_id")).isEmpty();
        steps.put(step("Settings saved", set, set ? prefs.get("domain") : "Enter My Domain URL and Client ID."));
        if (!set) { out.put("ok", false); return out; }
        try {
            Resp r = api("GET", "/services/data/" + API + "/sobjects/Voter__c/describe", null);
            steps.put(step("Login", true, "Signed in" + (nz(prefs.get("user_name")).isEmpty() ? "" : " as " + prefs.get("user_name"))));
            if (r.code == 404) { steps.put(step("Voter__c object", false, "Not found or no access: deploy the package and assign Voter_User.")); out.put("ok", false); return out; }
            if (!r.ok()) { steps.put(step("Voter__c object", false, sfError(r))); out.put("ok", false); return out; }
            JSONObject d = parseObj(r.body);
            steps.put(step("Voter__c object", d.optBoolean("updateable"), d.optBoolean("updateable") ? "Readable and editable" : "No edit access: assign permission set Voter_User."));
            Map<String, JSONObject> fields = new HashMap<>();
            JSONArray fa = d.optJSONArray("fields");
            if (fa != null) for (int i = 0; i < fa.length(); i++) fields.put(fa.getJSONObject(i).optString("name"), fa.getJSONObject(i));
            String[] edit = {"Party__c", "Party_Updated_At__c", "Voting_Status__c", "Status_Updated_At__c", "Last_Device_Id__c"};
            String[] read = {"EPIC__c", "Tagged_By__c"};
            StringBuilder missing = new StringBuilder();
            for (String f : edit) { JSONObject x = fields.get(f); if (x == null || !x.optBoolean("updateable")) missing.append(f).append(x == null ? " (missing) " : " (read-only) "); }
            for (String f : read) if (!fields.containsKey(f)) missing.append(f).append(" (missing) ");
            boolean fok = missing.length() == 0;
            steps.put(step("Fields", fok, fok ? "All 7 sync fields available" : missing.toString().trim()));
            boolean ycp = false;
            JSONObject party = fields.get("Party__c");
            JSONArray pv = party == null ? null : party.optJSONArray("picklistValues");
            if (pv != null) for (int i = 0; i < pv.length(); i++) if ("YCP to TDP".equals(pv.getJSONObject(i).optString("value"))) ycp = true;
            steps.put(step("Party values", ycp, ycp ? "TDP, YCP, YCP to TDP, NA" : "\"YCP to TDP\" missing: redeploy the package."));
            Resp c = api("GET", "/services/data/" + API + "/query?q=" + enc("SELECT COUNT() FROM Voter__c WHERE EPIC__c != null"), null);
            int n = parseObj(c.body).optInt("totalSize", -1);
            steps.put(step("Voter records", n > 0, n >= 0 ? n + " voters visible" : sfError(c)));
            out.put("ok", fok && ycp && n > 0 && d.optBoolean("updateable"));
        } catch (AuthException e) {
            steps.put(step("Login", false, e.getMessage()));
            out.put("ok", false);
        } catch (IOException e) {
            steps.put(step("Connection", false, netFail(e).getString("message")));
            out.put("ok", false);
        }
        return out;
    }

    static JSONObject step(String name, boolean ok, String detail) throws JSONException {
        JSONObject s = new JSONObject(); s.put("name", name); s.put("ok", ok); s.put("detail", detail);
        return s;
    }
}
