package com.damavaram.voterfinder;

import android.content.Context;
import android.content.SharedPreferences;

/** Plain settings (domain, client id, mode, user name, device id). Nothing secret is stored here. */
public class PrefsKv implements Sf.Kv {
    private final SharedPreferences sp;
    public PrefsKv(Context ctx) { sp = ctx.getSharedPreferences("sf_config", Context.MODE_PRIVATE); }
    @Override public String get(String k) { return sp.getString(k, null); }
    @Override public void put(String k, String v) { sp.edit().putString(k, v).apply(); }
    @Override public void remove(String k) { sp.edit().remove(k).apply(); }
}
