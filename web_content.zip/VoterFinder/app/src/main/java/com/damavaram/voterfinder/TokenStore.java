package com.damavaram.voterfinder;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Encrypted key-value store for the client secret and OAuth tokens. Each value is encrypted with
 * AES-256-GCM using a key that never leaves Android Keystore. Values are unreadable if copied off
 * the phone, and allowBackup=false keeps them out of cloud backups.
 */
public class TokenStore implements Sf.Kv {

    private static final String ALIAS = "dmv_tokens";
    private final SharedPreferences sp;

    public TokenStore(Context ctx) {
        sp = ctx.getSharedPreferences("sf_secure", Context.MODE_PRIVATE);
    }

    private SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(ALIAS)) return ((KeyStore.SecretKeyEntry) ks.getEntry(ALIAS, null)).getSecretKey();
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build());
        return kg.generateKey();
    }

    @Override
    public synchronized String get(String k) {
        String v = sp.getString(k, null);
        if (v == null) return null;
        try {
            ByteBuffer b = ByteBuffer.wrap(Base64.getDecoder().decode(v));
            byte[] iv = new byte[12];
            b.get(iv);
            byte[] ct = new byte[b.remaining()];
            b.get(ct);
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, iv));
            return new String(c.doFinal(ct), StandardCharsets.UTF_8);
        } catch (Exception e) {
            sp.edit().remove(k).apply();   // unreadable (e.g. key reset): forget it, user logs in again
            return null;
        }
    }

    @Override
    public synchronized void put(String k, String v) {
        if (v == null) { remove(k); return; }
        try {
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.ENCRYPT_MODE, key());
            byte[] iv = c.getIV();
            byte[] ct = c.doFinal(v.getBytes(StandardCharsets.UTF_8));
            ByteBuffer b = ByteBuffer.allocate(iv.length + ct.length);
            b.put(iv).put(ct);
            sp.edit().putString(k, Base64.getEncoder().encodeToString(b.array())).apply();
        } catch (Exception e) {
            throw new IllegalStateException("Could not store a secret securely: " + e.getMessage(), e);
        }
    }

    @Override
    public synchronized void remove(String k) {
        sp.edit().remove(k).apply();
    }
}
