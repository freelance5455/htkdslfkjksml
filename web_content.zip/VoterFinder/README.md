# Voter Finder - Android app with Salesforce sync

The app shows the Damavaram voter list (assets/index.html) and syncs TDP / YCP / YCP to TDP / NA tags and
Vote / Outside with Salesforce object Voter__c. Deploy damavaram-salesforce-package.zip to the org first.

## 1. Build the APK

Option A: GitHub, no Android Studio needed
1. Create a PRIVATE repository on github.com and upload the contents of this VoterFinder folder
   (including the hidden .github folder). The voter data is inside, so keep the repository private.
2. Open the repository's Actions tab > "Build APK" > Run workflow (it also runs on every push).
3. When the run is green (about 5-10 minutes), open it and download "VoterFinder-apk" (a zip with app-debug.apk).

Option B: Android Studio
1. Android Studio (Ladybug 2024.2 or newer) > Open > select this VoterFinder folder. Let Gradle sync finish
   (first sync downloads Gradle 8.9 and the Android plugin, so it needs internet once).
2. If asked, install Android SDK Platform 35.
3. Build > Build App Bundle(s) / APK(s) > Build APK(s).
4. Copy app/build/outputs/apk/debug/app-debug.apk to each phone and open it ("Install unknown apps" = allow).

## 2. Salesforce: External Client App (Setup > External Client App Manager > New)
- Enable OAuth. Callback URL: com.damavaram.voterfinder://oauth
- Scopes: Manage user data via APIs (api); Perform requests at any time (refresh_token, offline_access)
- Flows: Authorization Code flow ON. PKCE: ON (the app always sends it).
- "Require secret for Web Server Flow" and "Require secret for Refresh Token Flow": ON or OFF both work;
  the app sends the secret when you have entered one.
- Policies: Permitted users = Admin approved users are pre-authorized, add permission set Voter_User.
  Refresh token policy = valid until revoked. IP relaxation = relax IP restrictions.
- Only for "App only" login: also enable Client Credentials Flow and set Run As to a user who has the
  Voter_User permission set. Every phone then works as that one user (Tagged By shows that user).
- Save, then open Consumer Key and Secret: copy both.

## 3. Connect each phone
1. Open Voter Finder > Filters > Salesforce > Settings.
2. Enter My Domain URL (Setup > My Domain, e.g. https://yourorg.my.salesforce.com), Client ID (Consumer Key)
   and Client Secret (Consumer Secret). Choose Login type.
3. Tap Log in. "Each user logs in": the Salesforce login page opens INSIDE the app; sign in and tap Allow.
   The window closes by itself and Settings shows "Connected to Salesforce as <name>" in green, or the
   reason in red (wrong secret, cancelled, page could not load...). "App only": no page, it connects directly.
   Your details stay saved on the phone: the secret box stays empty on purpose and shows "saved".
4. Tap Test connection: every line must show a tick.
5. Tap Refresh once to load all tags, then tag voters and tap Sync to Salesforce.

## If login does not work
Settings > Show log lists every step (settings saved, login page opened, token request, HTTP code and the
Salesforce error text). It never shows the secret or tokens. Common messages:
- "Could not open the Salesforce login page": wrong My Domain URL or no internet.
- "redirect_uri_mismatch" on the Salesforce page: Callback URL must be exactly com.damavaram.voterfinder://oauth
- "Client ID or Client Secret is wrong (invalid_client)": copy both again from the External Client App.
- "invalid_grant": PKCE not enabled on the External Client App, or the login took too long: tap Log in again.
- "OAUTH_APP_ACCESS_DENIED" / "user is not admin approved": assign permission set Voter_User and add it to the
  app's Policies > Permitted users.

## How sync works
- Every tap is saved on the phone and queued. Sync to Salesforce sends only the queued changes, 200 per call,
  and only the fields that changed. A change leaves the queue only when Salesforce accepts that record.
- Refresh downloads records changed since the last refresh and applies them, except voters with an unsynced
  local change (those keep the phone's value until the next Sync).
- If two phones tag the same voter, the later tap wins (Salesforce trigger VoterPartyGuard).
- Offline: nothing is lost; the header shows "n waiting to sync".

## Security
- The Client Secret and tokens are stored encrypted (AES-256-GCM, key in Android Keystore), never in the page
  and never in the APK. allowBackup=false keeps them out of cloud backups. HTTPS only.
- Anyone holding the phone unlocked can use the app: use a screen lock.

## Files
- MainActivity.java   WebView host, JavaScript bridge "Android", login redirect, file save/share
- Sf.java             Salesforce login (code + PKCE + secret, or client credentials), sync, refresh, test
- TokenStore.java     encrypted storage for secret and tokens
- PrefsKv.java        plain settings (domain, client id, login type, user name, device id)
- ShareProvider.java  shares exported CSV / PDF files with other apps
- assets/index.html   the Voter Finder page (data + photos built in)

## Tested / not tested
- Tested off-device: Sf.java against a simulated Salesforce (29 checks: both login types, PKCE, wrong secret,
  sync batches, conflicts, paging, expired and revoked tokens, offline); the page's sync logic in a browser
  with a simulated app (queue, retap during sync, refresh keeps local changes, rejections, offline).
- Compiled against Android API signatures, but NOT built with the Android SDK or run on a phone or a real org.
  Send any Gradle or runtime error message for a fix.
