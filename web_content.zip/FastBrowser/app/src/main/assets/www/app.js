const $ = s => document.querySelector(s);
const P = {
  search:'<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  back:'<path d="M5 12h14M13 6l6 6-6 6"/>',
  fwd:'<path d="M19 12H5M11 6l-6 6 6 6"/>',
  reload:'<path d="M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7"/>',
  home:'<path d="M3 11l9-8 9 8M5 10v10h5v-6h4v6h5V10"/>',
  ext:'<path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>',
  dots:'<circle cx="12" cy="5" r="1.2"/><circle cx="12" cy="12" r="1.2"/><circle cx="12" cy="19" r="1.2"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  inc:'<path d="M3 14h18M6 14l1.6-7h8.8L18 14"/><circle cx="8" cy="18" r="2.4"/><circle cx="16" cy="18" r="2.4"/>',
  star:'<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
  mark:'<path d="M6 3h12v18l-6-4-6 4z"/>',
  clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  down:'<path d="M12 4v11M7 11l5 5 5-5M5 20h14"/>',
  set:'<path d="M4 7h9M17 7h3M4 17h3M11 17h9"/><circle cx="15" cy="7" r="2"/><circle cx="9" cy="17" r="2"/>',
  power:'<path d="M12 3v9M6.3 6.8a8 8 0 1 0 11.4 0"/>',
  x:'<path d="M6 6l12 12M18 6L6 18"/>',
  lock:'<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
  warn:'<path d="M12 4l9 16H3z"/><path d="M12 10v4M12 17h.01"/>',
  trash:'<path d="M5 7h14M10 7V4h4v3M7 7l1 13h8l1-13"/>',
  cloud:'<path d="M7 18a4 4 0 0 1-.5-8A6 6 0 0 1 18 9.5 4 4 0 0 1 17 18z"/><path d="M4 4l16 16"/>'
};
const ic = (n, s = 22) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${P[n]}</svg>`;
const bolt = s => `<svg width="${s}" height="${s}" viewBox="0 0 24 24"><path d="M13 2L4 14h6l-1 8 9-12h-6z" fill="#FF6A1F"/></svg>`;

const store = {
  get(k, d) { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} }
};
let bookmarks = store.get('bm', []), hist = store.get('hist', []), cfg = store.get('cfg', { engine: 'google', dark: false });
const engines = {
  google: 'https://www.google.com/search?igu=1&q=',
  bing: 'https://www.bing.com/search?q=',
  ddg: 'https://duckduckgo.com/?q='
};
const sites = [
  ['G', 'گوگل', 'https://www.google.com/webhp?igu=1', '#4285F4'],
  ['▶', 'یوتیوب', 'https://m.youtube.com', '#E62117'],
  ['W', 'ویکی‌پدیا', 'https://fa.m.wikipedia.org', '#3B3F4A'],
  ['آ', 'آپارات', 'https://www.aparat.com', '#E5195F'],
  ['د', 'دیجی‌کالا', 'https://www.digikala.com', '#EF394E'],
  ['IG', 'اینستاگرام', 'https://www.instagram.com', '#C13584']
];
let tabs = [], cur = null, counter = 0;
const host = u => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch { return u; } };

/* tabs */
function newTab(inc) {
  cur = { id: ++counter, url: '', inc: !!inc, h: [], pos: -1 };
  tabs.push(cur); closeSheet(); render();
}
function switchTab(id) { cur = tabs.find(t => t.id === id); closeSheet(); render(); }
function closeTab(id) {
  tabs = tabs.filter(t => t.id !== id);
  if (!tabs.length) newTab(false); else if (cur.id === id) cur = tabs[tabs.length - 1];
  render(); openTabs();
}

/* navigation */
function toURL(t) {
  t = t.trim();
  if (/^https?:\/\//i.test(t)) return t;
  if (/^[\w-]+(\.[\w-]+)+(\/\S*)?$/.test(t)) return 'https://' + t;
  return engines[cfg.engine] + encodeURIComponent(t);
}
function go(text, back) {
  if (!text.trim()) return;
  const u = toURL(text);
  cur.url = u;
  if (!back) { cur.h = cur.h.slice(0, cur.pos + 1); cur.h.push(u); cur.pos++; }
  if (!cur.inc) { hist.unshift({ url: u }); hist = hist.slice(0, 100); store.set('hist', hist); }
  render();
}
function progress(start) {
  const p = $('#prog');
  if (start) {
    p.style.transition = 'none'; p.style.width = '0'; p.style.opacity = 1; p.offsetWidth;
    p.style.transition = 'width 6s cubic-bezier(.1,.7,.2,1)'; p.style.width = '85%';
  } else {
    p.style.transition = 'width .25s, opacity .4s .25s'; p.style.width = '100%'; p.style.opacity = 0;
  }
}
function toast(m) {
  const t = $('#toast'); t.textContent = m; t.style.opacity = 1;
  clearTimeout(toast.id); toast.id = setTimeout(() => t.style.opacity = 0, 1800);
}

function render() {
  document.body.classList.toggle('dark', cfg.dark);
  document.body.classList.toggle('inc', cur.inc);
  $('#tabcount').textContent = tabs.length;
  const online = navigator.onLine, has = !!cur.url;
  $('#home').style.display = has ? 'none' : 'block';
  $('#err').style.display = has && !online ? 'block' : 'none';
  $('#frame').style.display = has && online ? 'block' : 'none';
  $('#url').value = cur.url;
  $('#lock').innerHTML = !has ? ic('search', 18) : cur.url.startsWith('https') ? ic('lock', 18) : ic('warn', 18);
  $('#tag').textContent = cur.inc ? 'حالت ناشناس: تاریخچه ذخیره نمی‌شود' : 'سبک و سریع برای هر گوشی';
  $('#bFwd').classList.toggle('off', cur.pos >= cur.h.length - 1);
  if (has && online && $('#frame').dataset.src !== cur.url) {
    $('#frame').dataset.src = cur.url; $('#frame').src = cur.url; progress(true);
  }
  if (!has) $('#frame').dataset.src = '';
  renderBookmarks();
}
function renderBookmarks() {
  $('#bmwrap').innerHTML = bookmarks.length
    ? `<div class="sec">علاقه‌مندی‌ها</div><div class="chips">${bookmarks.map(b =>
        `<button class="chip" onclick="go('${b.url}')">${host(b.url)}</button>`).join('')}</div>` : '';
}

/* sheets */
function openSheet(h) { $('#sheet').innerHTML = h; $('#sheet').style.display = $('#bg').style.display = 'block'; }
function closeSheet() { $('#sheet').style.display = $('#bg').style.display = 'none'; }
const row = (icon, text, fn) => `<button class="row" onclick="${fn}">${ic(icon)}<span>${text}</span></button>`;

function openTabs() {
  openSheet(`<div class="h">تب‌ها</div>
    <div class="two"><button class="big" onclick="newTab(false)">${ic('plus', 20)} تب جدید</button>
    <button class="big" onclick="newTab(true)">${ic('inc', 20)} تب ناشناس</button></div>
    <div class="tabgrid">${tabs.map(t => `
      <div class="tcard ${t === cur ? 'on' : ''}" onclick="switchTab(${t.id})">
        <div class="t"><b>${t.url ? host(t.url)[0].toUpperCase() : ic('home', 15)}</b>
        <button onclick="event.stopPropagation();closeTab(${t.id})" aria-label="بستن تب">${ic('x', 18)}</button></div>
        <div class="n">${t.inc ? 'ناشناس' : t.url ? host(t.url) : 'صفحه اصلی'}</div></div>`).join('')}</div>`);
}
function openMenu() {
  openSheet(
    row('plus', 'تب جدید', 'newTab(false)') + row('inc', 'تب ناشناس جدید', 'newTab(true)') +
    row('star', 'افزودن به علاقه‌مندی‌ها', 'addBookmark()') + row('mark', 'علاقه‌مندی‌ها', 'openList(\'bm\')') +
    row('clock', 'تاریخچه', 'openList(\'hist\')') + row('down', 'دانلودها', 'openDownloads()') +
    row('set', 'تنظیمات', 'openSettings()') + row('power', 'خروج', 'tabs=[];newTab(false)'));
}
function addBookmark() {
  closeSheet();
  if (!cur.url) return toast('اول یک صفحه باز کنید');
  if (bookmarks.some(b => b.url === cur.url)) return toast('قبلاً ذخیره شده بود');
  bookmarks.push({ url: cur.url }); store.set('bm', bookmarks); renderBookmarks(); toast('به علاقه‌مندی‌ها اضافه شد');
}
function openList(kind) {
  const arr = kind === 'bm' ? bookmarks : hist;
  const title = kind === 'bm' ? 'علاقه‌مندی‌ها' : 'تاریخچه';
  const empty = kind === 'bm' ? 'هنوز چیزی ذخیره نکرده‌اید. در منو «افزودن به علاقه‌مندی‌ها» را بزنید.'
                              : 'تاریخچه خالی است. صفحه‌هایی که باز کنید اینجا می‌آیند.';
  openSheet(`<div class="h">${title}</div>` + (arr.length
    ? arr.map(x => `<button class="row" onclick="closeSheet();go('${x.url}')"><div><div>${host(x.url)}</div><small>${x.url}</small></div></button>`).join('') +
      row('trash', 'پاک کردن همه', `clearList('${kind}')`)
    : `<div class="empty">${empty}</div>`));
}
function clearList(kind) {
  if (kind === 'bm') { bookmarks = []; store.set('bm', []); renderBookmarks(); } else { hist = []; store.set('hist', []); }
  closeSheet(); toast(kind === 'bm' ? 'علاقه‌مندی‌ها پاک شد' : 'تاریخچه پاک شد');
}
function openDownloads() {
  openSheet(`<div class="h">دانلودها</div><div class="empty">دانلودها را مرورگر اصلی گوشی مدیریت می‌کند.<br>
    برای دانلود، صفحه را با دکمهٔ باز کردن در مرورگر اصلی (پایین صفحه) باز کنید.</div>`);
}
function openSettings() {
  openSheet(`<div class="h">تنظیمات</div>
    <div class="row"><span>موتور جستجو</span><span class="end"><select id="eng" onchange="cfg.engine=this.value;store.set('cfg',cfg)">
      <option value="google">Google</option><option value="bing">Bing</option><option value="ddg">DuckDuckGo</option></select></span></div>
    <div class="row"><span>حالت تاریک</span><span class="end"><input type="checkbox" ${cfg.dark ? 'checked' : ''}
      onchange="cfg.dark=this.checked;store.set('cfg',cfg);render()"></span></div>
    ${row('trash', 'پاک کردن تاریخچه', "clearList('hist')")}`);
  $('#eng').value = cfg.engine;
}

/* wiring */
$('#sm').innerHTML = bolt(46); $('#hm').innerHTML = bolt(26);
$('#go').innerHTML = ic('search', 19); $('#hgo').innerHTML = ic('search', 22);
$('#btnMenu').innerHTML = ic('dots'); $('#errico').innerHTML = ic('cloud', 64);
$('#bBack').innerHTML = ic('back'); $('#bFwd').innerHTML = ic('fwd'); $('#bReload').innerHTML = ic('reload');
$('#bHome').innerHTML = ic('home'); $('#bOpen').innerHTML = ic('ext');
$('#tiles').innerHTML = sites.map(s => `<button class="tile" onclick="go('${s[2]}')"><i style="background:${s[3]}">${s[0]}</i>${s[1]}</button>`).join('');

$('#go').onclick = () => { go($('#url').value); $('#url').blur(); };
$('#hgo').onclick = () => { go($('#hs').value); $('#hs').value = ''; };
$('#url').onkeydown = e => { if (e.key === 'Enter') $('#go').click(); };
$('#url').onfocus = e => e.target.select();
$('#hs').onkeydown = e => { if (e.key === 'Enter') $('#hgo').click(); };
$('#btnTabs').onclick = openTabs; $('#btnMenu').onclick = openMenu; $('#bg').onclick = closeSheet;
$('#frame').onload = () => progress(false);
$('#bHome').onclick = () => { cur.url = ''; render(); };
$('#bReload').onclick = () => { if (cur.url) { progress(true); $('#frame').src = cur.url; } };
$('#bOpen').onclick = () => {
  if (!cur.url) return;
  if (window.Android) Android.openExternal(cur.url); else window.open(cur.url, '_blank');
};
$('#bBack').onclick = () => { if (cur.pos > 0) { cur.pos--; go(cur.h[cur.pos], true); } else { cur.url = ''; render(); } };
$('#bFwd').onclick = () => { if (cur.pos < cur.h.length - 1) { cur.pos++; go(cur.h[cur.pos], true); } };
addEventListener('online', render); addEventListener('offline', render);

newTab(false);
setTimeout(() => { $('#splash').style.opacity = 0; setTimeout(() => $('#splash').remove(), 400); }, 2000);

/* Android back button: returns true if the page handled it */
window.handleBack = () => {
  if ($('#sheet').style.display === 'block') { closeSheet(); return true; }
  if (cur.url) { $('#bBack').click(); return true; }
  return false;
};
