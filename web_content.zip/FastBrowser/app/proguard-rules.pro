# Fast Browser: no special ProGuard rules needed
