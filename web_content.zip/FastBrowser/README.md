# Fast Browser — پروژهٔ اندروید (WebView)

مرورگر سبک و سریع با HTML/CSS/JS که داخل یک اپ اندروید اجرا می‌شود.

## ساخت APK (راه آسان: Android Studio)
1. فایل ZIP را از حالت فشرده خارج کن.
2. Android Studio (نسخهٔ Koala یا جدیدتر) را باز کن: File ← Open ← پوشهٔ FastBrowser.
3. صبر کن Gradle Sync تمام شود (بار اول اینترنت لازم است).
4. از منو: Build ← Build Bundle(s) / APK(s) ← Build APK(s).
5. فایل خروجی اینجاست: app/build/outputs/apk/debug/app-debug.apk
6. فایل را روی گوشی کپی کن و نصب کن (نصب از منبع ناشناس را فعال کن).

## ساخت APK از ترمینال
اگر Gradle نصب داری: `gradle wrapper` را یک‌بار در پوشهٔ پروژه اجرا کن تا gradlew ساخته شود،
بعد `./gradlew assembleDebug`.

## ساختار
- app/src/main/assets/www/  ← index.html, style.css, app.js (خود مرورگر)
- app/src/main/java/.../MainActivity.kt ← WebView، دکمهٔ برگشت، دانلود، باز کردن در مرورگر اصلی
- app/src/main/AndroidManifest.xml ← مجوزها و تنظیمات اپ
- web-standalone/fast-browser.html ← همان برنامه در یک فایل (برای تست در مرورگر)

## محدودیت‌ها
- سایت‌هایی که نمایش داخل iframe را ممنوع کرده‌اند (مثل یوتیوب و اینستاگرام) خالی می‌مانند؛
  از دکمهٔ ↗ پایین صفحه برای باز کردن در مرورگر اصلی استفاده کن.
- فونت وزیرمتن از اینترنت بارگیری می‌شود؛ آفلاین، فونت پیش‌فرض گوشی جایگزین می‌شود.
- حداقل اندروید ۸ (API 26).
