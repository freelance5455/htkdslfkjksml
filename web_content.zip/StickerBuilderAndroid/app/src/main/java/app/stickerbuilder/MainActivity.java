package app.stickerbuilder;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.ByteArrayInputStream;
import java.util.Locale;
import java.util.Map;
import java.util.HashMap;
import android.util.Base64;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 4102;
    private static final String APP_HOST = "sticker.app";
    private WebView webView;
    private ValueCallback<Uri[]> pendingFileCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStatusBarColors();

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(238, 245, 255));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setLongClickable(false);
        webView.setHapticFeedbackEnabled(false);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.addJavascriptInterface(new DownloadBridge(), "NativeApp");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("https".equals(uri.getScheme()) && APP_HOST.equals(uri.getHost())) {
                    String path = uri.getPath();
                    if (path == null || "/".equals(path) || "/index.html".equals(path)) {
                        try {
                            return new WebResourceResponse("text/html", "UTF-8", getAssets().open("index.html"));
                        } catch (Exception ignored) {
                            return errorResponse();
                        }
                    }
                    return errorResponse();
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                return !("https".equals(uri.getScheme()) && APP_HOST.equals(uri.getHost()));
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                installNativeDownloadHook();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (pendingFileCallback != null) {
                    pendingFileCallback.onReceiveValue(null);
                    pendingFileCallback = null;
                }
                pendingFileCallback = filePathCallback;
                try {
                    Intent intent = fileChooserParams.createIntent();
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    pendingFileCallback = null;
                    filePathCallback.onReceiveValue(null);
                    showToast("باز کردن انتخاب‌گر فایل ممکن نشد");
                    return false;
                }
            }
        });

        boolean restored = false;
        if (savedInstanceState != null) {
            android.webkit.WebBackForwardList history = webView.restoreState(savedInstanceState);
            restored = history != null && history.getSize() > 0;
        }
        if (!restored) {
            webView.loadUrl("https://" + APP_HOST + "/index.html");
        }
    }

    private WebResourceResponse errorResponse() {
        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
    }

    private void setStatusBarColors() {
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(238, 245, 255));
        window.setNavigationBarColor(Color.rgb(238, 245, 255));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.setNavigationBarContrastEnforced(false);
            window.setStatusBarContrastEnforced(false);
        }
    }

    private void installNativeDownloadHook() {
        String js = "(function(){window.downloadCanvas=function(type,filename,quality){try{var c=document.getElementById('canvas');if(!c){return;}if(typeof render==='function'){render(false);}c.toBlob(function(blob){if(!blob){NativeApp.notify('ساخت فایل خروجی ناموفق بود');return;}var r=new FileReader();r.onloadend=function(){try{var data=String(r.result).split(',')[1];NativeApp.saveFile(data,filename,type);}catch(e){NativeApp.notify('ذخیره فایل انجام نشد');}};r.readAsDataURL(blob);},type,quality); }catch(e){NativeApp.notify('ساخت خروجی ناموفق بود');}};})();";
        webView.evaluateJavascript(js, null);
    }

    private class DownloadBridge {
        @JavascriptInterface
        public void saveFile(String encoded, String name, String mimeType) {
            try {
                if (encoded == null || encoded.length() > 20_000_000) {
                    showToast("فایل خروجی بیش از حد بزرگ است");
                    return;
                }
                byte[] bytes = Base64.decode(encoded, Base64.DEFAULT);
                String safeName = safeFilename(name, mimeType);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    saveWithMediaStore(bytes, safeName, mimeType);
                } else {
                    saveAppDownload(bytes, safeName);
                }
                showToast("فایل در پوشه دانلودها ذخیره شد: " + safeName);
            } catch (Exception e) {
                showToast("ذخیره فایل ناموفق بود");
            }
        }

        @JavascriptInterface
        public void notify(String message) {
            showToast(message == null ? "" : message);
        }
    }

    private String safeFilename(String name, String mimeType) {
        String fallback = "sticker." + (mimeType != null && mimeType.contains("webp") ? "webp" : "png");
        if (name == null || name.trim().isEmpty()) return fallback;
        String cleaned = name.replaceAll("[\\\\/:*?\"<>|\\r\\n]", "_").trim();
        if (cleaned.length() > 100) cleaned = cleaned.substring(cleaned.length() - 100);
        if (!cleaned.contains(".")) cleaned += mimeType != null && mimeType.contains("webp") ? ".webp" : ".png";
        return cleaned;
    }

    private void saveWithMediaStore(byte[] bytes, String filename, String mimeType) throws Exception {
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, filename);
        values.put(MediaStore.MediaColumns.MIME_TYPE, mimeType == null ? "application/octet-stream" : mimeType);
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/StickerBuilder");
        values.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new Exception("Could not create download");
        try (OutputStream out = getContentResolver().openOutputStream(uri)) {
            if (out == null) throw new Exception("Could not open download");
            out.write(bytes);
            out.flush();
        } catch (Exception ex) {
            getContentResolver().delete(uri, null, null);
            throw ex;
        }
        ContentValues done = new ContentValues();
        done.put(MediaStore.MediaColumns.IS_PENDING, 0);
        getContentResolver().update(uri, done, null, null);
    }

    private void saveAppDownload(byte[] bytes, String filename) throws Exception {
        File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        if (dir == null) dir = getFilesDir();
        if (!dir.exists() && !dir.mkdirs()) throw new Exception("Could not create folder");
        File file = new File(dir, filename);
        try (FileOutputStream out = new FileOutputStream(file)) {
            out.write(bytes);
            out.flush();
        }
    }

    private void showToast(final String message) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (pendingFileCallback == null) return;
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null) {
                Uri selected = data.getData();
                if (selected != null) result = new Uri[]{selected};
                else if (data.getClipData() != null && data.getClipData().getItemCount() > 0) {
                    result = new Uri[]{data.getClipData().getItemAt(0).getUri()};
                }
            }
            pendingFileCallback.onReceiveValue(result);
            pendingFileCallback = null;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onDestroy() {
        if (pendingFileCallback != null) {
            pendingFileCallback.onReceiveValue(null);
            pendingFileCallback = null;
        }
        if (webView != null) {
            webView.stopLoading();
            webView.removeJavascriptInterface("NativeApp");
            webView.destroy();
        }
        super.onDestroy();
    }
}
