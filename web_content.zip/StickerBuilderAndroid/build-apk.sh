#!/usr/bin/env bash
set -euo pipefail
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle is missing. Open this folder in Android Studio to install/configure the Gradle toolchain." >&2
  exit 2
fi
if [[ -z "${ANDROID_HOME:-}" && -z "${ANDROID_SDK_ROOT:-}" ]]; then
  echo "ANDROID_HOME/ANDROID_SDK_ROOT is not configured. Open this project in Android Studio first." >&2
  exit 2
fi
gradle --no-daemon assembleDebug
printf '\nAPK created at: %s\n' "$PWD/app/build/outputs/apk/debug/app-debug.apk"
