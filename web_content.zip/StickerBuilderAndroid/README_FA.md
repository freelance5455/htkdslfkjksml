# پروژه اندرویدی «ساخت استیکر»

این پروژه نسخه فعلی `index.html` را داخل برنامه اندرویدی WebView بسته‌بندی می‌کند. رابط و منطق ساخت استیکر داخل دارایی محلی برنامه است؛ برای باز شدن برنامه به اینترنت نیاز نیست.

## وضعیت فایل APK
در محیطی که این پروژه آماده شده، Android SDK، ابزارهای build اندروید و Gradle نصب نیستند و سرورهای دانلود ابزارها نیز از محیط قابل دسترس نیستند؛ بنابراین **APK کامپایل‌شده در اینجا تولید نشده است**. این ZIP سورس آماده برای ساخت APK در Android Studio است و نباید آن را با فایل APK اشتباه گرفت.

## ساخت APK در Android Studio
1. Android Studio را در رایانه باز کنید.
2. گزینه **Open** را بزنید و پوشه `StickerBuilderAndroid` را انتخاب کنید.
3. اجازه دهید Android Studio وابستگی‌های Gradle و Android SDK Platform 35 را دریافت و پروژه را Sync کند.
4. از منوی **Build → Build Bundle(s) / APK(s) → Build APK(s)** را انتخاب کنید.
5. پس از اتمام ساخت، APK آزمایشی در مسیر زیر قرار می‌گیرد:
   `app/build/outputs/apk/debug/app-debug.apk`
6. فایل `app-debug.apk` را به گوشی منتقل کنید و نصب آن را تأیید کنید. در صورت درخواست اندروید، اجازه نصب از همان منبع را فعال کنید.

## امکانات پوسته اندرویدی
- نمایش HTML در WebView با مبدأ محلی امن برای پشتیبانی از `localStorage` و `IndexedDB`.
- باز کردن انتخاب‌گر فایل اندروید برای بارگذاری تصویر و فونت.
- ذخیره خروجی PNG و WEBP در `Downloads/StickerBuilder` در اندروید 10 به بعد.
- نگه‌داشتن نسخه فعلی برنامه در `app/src/main/assets/index.html`.

## مشخصات پروژه
- Application ID: `app.stickerbuilder`
- حداقل Android: API 23 (Android 6.0)
- Target SDK: 34
- Compile SDK: 35
- نسخه برنامه: 1.0.0
