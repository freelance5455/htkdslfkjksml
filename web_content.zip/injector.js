// Alone Bypasser 1.0 - Injector
// Fixed message channel errors

(function() {
  'use strict';
  
  // Inject bypass script into page context
  const script = document.createElement('script');
  script.src = chrome.runtime.getURL('bypass.js');
  script.onload = () => script.remove();
  (document.head || document.documentElement).appendChild(script);
  
  // Listen for logs from bypass.js via postMessage
  window.addEventListener('message', (event) => {
    if (event.data?.source === 'abuse-bypasser' && event.data.log) {
      // Use try-catch and don't expect response
      try {
        chrome.runtime.sendMessage({ action: 'log', log: event.data.log });
      } catch(e) {
        // Extension context may be invalidated - ignore
      }
    }
  });
})();
