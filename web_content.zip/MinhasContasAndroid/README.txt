MINHAS CONTAS - PROJETO ANDROID

Este projeto transforma a interface do Minhas Contas em um aplicativo Android usando WebView.

COMO GERAR O APK:
1. Instale o Android Studio no computador.
2. Abra esta pasta no Android Studio.
3. Espere o Gradle terminar de sincronizar.
4. Vá em Build > Build APK(s).
5. O APK será criado em app/build/outputs/apk/debug/app-debug.apk.

O aplicativo salva as contas localmente no aparelho.

Observação: este pacote é o projeto-fonte, não um APK já compilado.
