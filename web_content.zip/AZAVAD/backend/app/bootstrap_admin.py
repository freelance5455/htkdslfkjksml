"""Create the first administrator interactively; no default password is embedded."""
import getpass
import re

from .main import connect_db, initialize_db
from .security import hash_password


def main():
    initialize_db()
    username = input("Initial administrator username (3-64 letters/digits/._-): ").strip()
    if not re.fullmatch(r"[A-Za-z0-9_.-]{3,64}", username):
        raise SystemExit("Invalid username")
    password = getpass.getpass("Administrator password (minimum 16 characters): ")
    confirm = getpass.getpass("Repeat password: ")
    if len(password) < 16 or password != confirm:
        raise SystemExit("Password too short or confirmation mismatch")
    with connect_db() as connection:
        count = connection.execute("SELECT COUNT(*) FROM users WHERE role='admin'").fetchone()[0]
        if count:
            raise SystemExit("An administrator already exists; refusing to create another bootstrap admin")
        connection.execute("INSERT INTO users(username,password_hash,role) VALUES(?,?,'admin')", (username, hash_password(password)))
    print("Administrator created. Store credentials in a password manager; do not share them.")


if __name__ == "__main__":
    main()
