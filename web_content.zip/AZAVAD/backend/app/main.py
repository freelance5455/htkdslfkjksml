from contextlib import asynccontextmanager, contextmanager
from datetime import datetime, timedelta, timezone
import os
import re
import sqlite3
import hashlib
import hmac
import base64
import json
from urllib.parse import urlparse
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from pathlib import Path
from typing import Annotated, Literal

from fastapi import Depends, FastAPI, Header, HTTPException, Request, Response
from fastapi.responses import StreamingResponse
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import secrets
import math
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .security import hash_password, new_session_token, token_digest, verify_password

APP_ENV = os.getenv("AZAVAD_ENV", "development").strip().lower()
if APP_ENV not in {"development", "test", "production"}:
    raise RuntimeError("AZAVAD_ENV must be one of: development, test, production")
DB_PATH = Path(os.getenv("AZAVAD_DEV_DB", "azavad_dev.sqlite3"))
SESSION_HOURS = int(os.getenv("AZAVAD_SESSION_HOURS", "12"))
LOGIN_FAILURE_LIMIT = 10
LOGIN_FAILURE_WINDOW = timedelta(minutes=15)
REGISTRATION_ATTEMPT_LIMIT = 5
REGISTRATION_WINDOW = timedelta(hours=1)
USERNAME_RE = re.compile(r"^[a-zA-Z0-9_.-]{3,64}$")
BACKUP_MAX_FILE_BYTES = 10_000_000_000
BACKUP_CHUNK_BYTES = 8 * 1024 * 1024
BACKUP_DEFAULT_QUOTA_BYTES = 50 * 1024 * 1024 * 1024
BACKUP_ROOT = Path(os.getenv("AZAVAD_BACKUP_DIR", "azavad_backups"))


@contextmanager
def connect_db():
    connection = sqlite3.connect(DB_PATH, timeout=10)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    try:
        yield connection
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def initialize_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with connect_db() as connection:
        connection.execute("PRAGMA journal_mode = WAL")
        connection.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE COLLATE NOCASE,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('user','operator','admin')),
            disabled INTEGER NOT NULL DEFAULT 0 CHECK(disabled IN (0,1)),
            created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
        );
        CREATE TABLE IF NOT EXISTS sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            token_hash TEXT NOT NULL UNIQUE,
            created_at TEXT NOT NULL,
            expires_at TEXT NOT NULL,
            revoked_at TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_sessions_token ON sessions(token_hash);
        CREATE TABLE IF NOT EXISTS auth_failures (
            key_hash TEXT PRIMARY KEY,
            window_started_at TEXT NOT NULL,
            failures INTEGER NOT NULL CHECK(failures >= 0),
            updated_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_auth_failures_updated ON auth_failures(updated_at);
        CREATE TABLE IF NOT EXISTS registration_attempts (
            key_hash TEXT PRIMARY KEY,
            window_started_at TEXT NOT NULL,
            attempts INTEGER NOT NULL CHECK(attempts >= 0),
            updated_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_registration_attempts_updated ON registration_attempts(updated_at);
        CREATE TABLE IF NOT EXISTS consent_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            feature TEXT NOT NULL,
            policy_version TEXT NOT NULL,
            granted INTEGER NOT NULL CHECK(granted IN (0,1)),
            purpose TEXT NOT NULL DEFAULT 'standard',
            expires_at TEXT,
            owner_confirmed INTEGER NOT NULL DEFAULT 0 CHECK(owner_confirmed IN (0,1)),
            created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
        );
        CREATE INDEX IF NOT EXISTS idx_consent_user ON consent_records(user_id, id);
        CREATE TABLE IF NOT EXISTS devices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            device_key TEXT NOT NULL,
            display_name TEXT NOT NULL,
            app_version TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
            last_seen_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
            UNIQUE(user_id, device_key)
        );
        CREATE INDEX IF NOT EXISTS idx_devices_user ON devices(user_id, id);
        CREATE TABLE IF NOT EXISTS device_heartbeats (
            device_id INTEGER PRIMARY KEY REFERENCES devices(id) ON DELETE CASCADE,
            battery_percent INTEGER CHECK(battery_percent BETWEEN 0 AND 100),
            charging INTEGER NOT NULL DEFAULT 0 CHECK(charging IN (0,1)),
            network_connected INTEGER NOT NULL DEFAULT 0 CHECK(network_connected IN (0,1)),
            app_foreground INTEGER NOT NULL DEFAULT 0 CHECK(app_foreground IN (0,1)),
            android_version TEXT NOT NULL DEFAULT '',
            app_version TEXT NOT NULL DEFAULT '',
            reported_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
        );
        CREATE TABLE IF NOT EXISTS remote_commands (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            device_id INTEGER NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
            command_type TEXT NOT NULL,
            status TEXT NOT NULL CHECK(status IN ('pending','delivered','accepted','rejected','running','completed','failed','expired','cancelled')),
            requires_owner_confirmation INTEGER NOT NULL DEFAULT 1 CHECK(requires_owner_confirmation IN (0,1)),
            requested_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
            created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
            expires_at TEXT NOT NULL,
            updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
            result_summary TEXT NOT NULL DEFAULT '',
            stop_requested INTEGER NOT NULL DEFAULT 0 CHECK(stop_requested IN (0,1))
        );
        CREATE INDEX IF NOT EXISTS idx_remote_commands_device_status ON remote_commands(device_id,status,id);
        CREATE INDEX IF NOT EXISTS idx_remote_commands_user ON remote_commands(user_id,id);
        CREATE TABLE IF NOT EXISTS screen_frames (
            device_id INTEGER PRIMARY KEY REFERENCES devices(id) ON DELETE CASCADE,
            command_id INTEGER NOT NULL REFERENCES remote_commands(id) ON DELETE CASCADE,
            jpeg_blob BLOB NOT NULL,
            sha256 TEXT NOT NULL,
            captured_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS notification_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            event_fingerprint TEXT NOT NULL,
            encrypted_payload BLOB NOT NULL,
            posted_at INTEGER NOT NULL,
            received_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
            UNIQUE(user_id, event_fingerprint)
        );
        CREATE INDEX IF NOT EXISTS idx_notification_events_owner ON notification_events(user_id, posted_at DESC);
        CREATE TABLE IF NOT EXISTS security_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            device_id INTEGER REFERENCES devices(id) ON DELETE SET NULL,
            event_type TEXT NOT NULL,
            severity TEXT NOT NULL CHECK(severity IN ('low','medium','high')),
            confidence TEXT NOT NULL CHECK(confidence IN ('low','medium','high')),
            description TEXT NOT NULL,
            recommended_action TEXT NOT NULL,
            source TEXT NOT NULL DEFAULT 'client_reported',
            created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
            resolved_at TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_security_events_user ON security_events(user_id, id);
        CREATE INDEX IF NOT EXISTS idx_security_events_created ON security_events(created_at, id);
        CREATE TABLE IF NOT EXISTS audit_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            actor_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
            actor_id_snapshot INTEGER,
            action TEXT NOT NULL,
            target_type TEXT NOT NULL,
            target_id TEXT,
            outcome TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
            prev_hash TEXT,
            entry_hash TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_events(created_at, id);
        CREATE TABLE IF NOT EXISTS library_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            slug TEXT NOT NULL UNIQUE,
            title TEXT NOT NULL,
            category TEXT NOT NULL,
            summary TEXT NOT NULL,
            body TEXT NOT NULL,
            source_url TEXT NOT NULL,
            verified_at TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','published')),
            updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
        );
        CREATE TABLE IF NOT EXISTS library_versions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            item_id INTEGER NOT NULL REFERENCES library_items(id) ON DELETE CASCADE,
            version INTEGER NOT NULL CHECK(version >= 1),
            payload_json TEXT NOT NULL,
            content_sha256 TEXT NOT NULL,
            signature_b64 TEXT NOT NULL,
            signing_key_id TEXT NOT NULL,
            published_at TEXT NOT NULL,
            UNIQUE(item_id, version)
        );
        CREATE INDEX IF NOT EXISTS idx_library_versions_item ON library_versions(item_id, version DESC);
        CREATE TABLE IF NOT EXISTS backup_objects (
            id TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            filename TEXT NOT NULL,
            content_type TEXT NOT NULL,
            size_bytes INTEGER NOT NULL CHECK(size_bytes >= 0 AND size_bytes <= 10000000000),
            chunk_size INTEGER NOT NULL,
            chunk_count INTEGER NOT NULL,
            status TEXT NOT NULL CHECK(status IN ('uploading','complete','failed')),
            sha256 TEXT,
            created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
            completed_at TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_backup_objects_owner ON backup_objects(user_id, created_at DESC);
        CREATE TABLE IF NOT EXISTS backup_chunks (
            backup_id TEXT NOT NULL REFERENCES backup_objects(id) ON DELETE CASCADE,
            chunk_index INTEGER NOT NULL CHECK(chunk_index >= 0),
            plain_size INTEGER NOT NULL CHECK(plain_size >= 0 AND plain_size <= 8388608),
            plain_sha256 TEXT NOT NULL,
            stored_name TEXT NOT NULL,
            PRIMARY KEY(backup_id, chunk_index)
        );
        """)
        # Upgrade existing development databases in place; production needs versioned migrations.
        consent_columns = {row["name"] for row in connection.execute("PRAGMA table_info(consent_records)").fetchall()}
        if "purpose" not in consent_columns:
            connection.execute("ALTER TABLE consent_records ADD COLUMN purpose TEXT NOT NULL DEFAULT 'standard'")
        if "expires_at" not in consent_columns:
            connection.execute("ALTER TABLE consent_records ADD COLUMN expires_at TEXT")
        if "owner_confirmed" not in consent_columns:
            connection.execute("ALTER TABLE consent_records ADD COLUMN owner_confirmed INTEGER NOT NULL DEFAULT 0")
        remote_command_columns = {row["name"] for row in connection.execute("PRAGMA table_info(remote_commands)").fetchall()}
        if "stop_requested" not in remote_command_columns:
            connection.execute("ALTER TABLE remote_commands ADD COLUMN stop_requested INTEGER NOT NULL DEFAULT 0 CHECK(stop_requested IN (0,1))")
        audit_columns = {row["name"] for row in connection.execute("PRAGMA table_info(audit_events)").fetchall()}
        added_chain_columns = False
        added_actor_snapshot = "actor_id_snapshot" not in audit_columns
        if added_actor_snapshot:
            connection.execute("ALTER TABLE audit_events ADD COLUMN actor_id_snapshot INTEGER")
            connection.execute("UPDATE audit_events SET actor_id_snapshot=actor_user_id WHERE actor_id_snapshot IS NULL")
            added_chain_columns = True
        for column in ("prev_hash", "entry_hash"):
            if column not in audit_columns:
                connection.execute(f"ALTER TABLE audit_events ADD COLUMN {column} TEXT")
                added_chain_columns = True
        if added_chain_columns or connection.execute("SELECT 1 FROM audit_events WHERE entry_hash IS NULL LIMIT 1").fetchone():
            previous_hash = None
            rows = connection.execute("SELECT * FROM audit_events ORDER BY id").fetchall()
            for row in rows:
                record = {
                    "id": row["id"], "actor_id_snapshot": row["actor_id_snapshot"], "action": row["action"],
                    "target_type": row["target_type"], "target_id": row["target_id"],
                    "outcome": row["outcome"], "created_at": row["created_at"], "prev_hash": previous_hash,
                }
                entry_hash = hashlib.sha256(_canonical_json(record)).hexdigest()
                connection.execute("UPDATE audit_events SET prev_hash=?,entry_hash=? WHERE id=?", (previous_hash, entry_hash, row["id"]))
                previous_hash = entry_hash


def audit(actor_id, action, target_type, target_id=None, outcome="success"):
    """Append a chained audit record. This is tamper-evident, not a substitute for external immutable storage."""
    with connect_db() as connection:
        connection.execute("BEGIN IMMEDIATE")
        previous = connection.execute("SELECT id,entry_hash FROM audit_events ORDER BY id DESC LIMIT 1").fetchone()
        record_id = (previous["id"] + 1) if previous else 1
        previous_hash = previous["entry_hash"] if previous else None
        created_at = datetime.now(timezone.utc).isoformat()
        record = {
            "id": record_id, "actor_id_snapshot": actor_id, "action": action, "target_type": target_type,
            "target_id": str(target_id) if target_id is not None else None, "outcome": outcome,
            "created_at": created_at, "prev_hash": previous_hash,
        }
        entry_hash = hashlib.sha256(_canonical_json(record)).hexdigest()
        connection.execute(
            "INSERT INTO audit_events(id,actor_user_id,actor_id_snapshot,action,target_type,target_id,outcome,created_at,prev_hash,entry_hash) VALUES(?,?,?,?,?,?,?,?,?,?)",
            (record_id, actor_id, actor_id, action, target_type, record["target_id"], outcome, created_at, previous_hash, entry_hash),
        )


def production_readiness_blockers() -> list[str]:
    """Keep the development scaffold from being mistaken for a production-ready service."""
    return [
        "PostgreSQL adapter and reviewed versioned schema migrations are not implemented",
        "distributed rate limiting and abuse monitoring are not configured",
        "administrator MFA and account recovery are not implemented",
        "production TLS, secret management and deployment-specific monitoring are not verified",
        "encrypted off-host backups and a production restore drill are not verified",
        "independent security review and load testing are not completed",
    ]


@asynccontextmanager
async def lifespan(app: FastAPI):
    if APP_ENV == "production":
        blockers = production_readiness_blockers()
        if blockers:
            joined = "; ".join(blockers)
            raise RuntimeError(f"AZAVAD production startup blocked until release blockers are resolved: {joined}")
    initialize_db()
    yield


app = FastAPI(
    title="AZAVAD API",
    version="0.2.0-dev",
    description=("Development API with account registration, opaque revocable sessions, consent records, "
                 "device registry, account export/deletion, and audit events. A basic SQLite-backed "
                 "login limiter is included; distributed abuse protection, TLS, production storage, "
                 "monitoring, and independent security review are still required before public deployment."),
    docs_url="/docs" if APP_ENV == "development" else None,
    redoc_url=None,
    openapi_url="/openapi.json" if APP_ENV == "development" else None,
    lifespan=lifespan,
)


@app.middleware("http")
async def add_security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    if request.url.path.startswith("/v1/"):
        response.headers["Cache-Control"] = "no-store"
    if request.url.path == "/admin" or request.url.path.startswith("/admin/"):
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
            "connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'"
        )
    return response


class RegisterInput(BaseModel):
    username: str = Field(min_length=3, max_length=64, pattern=r"^[a-zA-Z0-9_.-]+$")
    password: str = Field(min_length=12, max_length=256)


class AdminCreateUserInput(BaseModel):
    username: str = Field(min_length=3, max_length=64, pattern=r"^[a-zA-Z0-9_.-]+$")
    password: str = Field(min_length=12, max_length=256)
    role: str = Field(default="user", pattern=r"^(user|operator)$")


class AdminUserPatch(BaseModel):
    disabled: bool


class LoginInput(BaseModel):
    username: str = Field(min_length=3, max_length=64)
    password: str = Field(min_length=1, max_length=256)


class AccountDeleteInput(BaseModel):
    password: str = Field(min_length=1, max_length=256)
    confirm: bool


LIBRARY_CATEGORIES = {
    "first_aid", "environment", "digital_security", "technical_reference", "general"
}


class LibraryItemInput(BaseModel):
    slug: str = Field(min_length=3, max_length=80, pattern=r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
    title: str = Field(min_length=3, max_length=200)
    category: str = Field(min_length=1, max_length=40)
    summary: str = Field(min_length=1, max_length=500)
    body: str = Field(min_length=1, max_length=100_000)
    source_url: str = Field(min_length=8, max_length=2048)
    verified_at: str = Field(min_length=10, max_length=10, pattern=r"^\d{4}-\d{2}-\d{2}$")

    def validate_content(self):
        if self.category not in LIBRARY_CATEGORIES:
            raise HTTPException(status_code=422, detail="Unsupported library category")
        parsed = urlparse(self.source_url)
        if parsed.scheme != "https" or not parsed.netloc or parsed.username or parsed.password:
            raise HTTPException(status_code=422, detail="source_url must be a valid HTTPS URL without embedded credentials")
        try:
            datetime.strptime(self.verified_at, "%Y-%m-%d")
        except ValueError:
            raise HTTPException(status_code=422, detail="verified_at must be a valid calendar date")
        return self


class LibraryItemPatch(BaseModel):
    title: str | None = Field(default=None, min_length=3, max_length=200)
    category: str | None = Field(default=None, min_length=1, max_length=40)
    summary: str | None = Field(default=None, min_length=1, max_length=500)
    body: str | None = Field(default=None, min_length=1, max_length=100_000)
    source_url: str | None = Field(default=None, min_length=8, max_length=2048)
    verified_at: str | None = Field(default=None, min_length=10, max_length=10, pattern=r"^\d{4}-\d{2}-\d{2}$")


class UserView(BaseModel):
    id: int
    username: str
    role: str
    disabled: bool
    created_at: str


class SessionView(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_at: str


SENSITIVE_CONSENT_FEATURES = {"camera", "microphone", "file_access", "screen_share"}


class ConsentInput(BaseModel):
    feature: str = Field(min_length=1, max_length=100, pattern=r"^[a-zA-Z0-9_.-]+$")
    policy_version: str = Field(min_length=1, max_length=40)
    granted: bool
    purpose: str = Field(default="standard", min_length=1, max_length=80)
    # Sensitive-capability consent defaults to one year when no duration is supplied.
    # Hours remain supported for older clients; callers may provide only one duration field.
    expires_in_days: int | None = Field(default=None, ge=1, le=365)
    expires_in_hours: int | None = Field(default=None, ge=1, le=8760)
    owner_confirmed: bool = False


class ConsentView(BaseModel):
    id: int
    feature: str
    policy_version: str
    granted: bool
    purpose: str = "standard"
    expires_at: str | None = None
    owner_confirmed: bool = False
    created_at: str


class DeviceInput(BaseModel):
    device_key: str = Field(min_length=8, max_length=128, pattern=r"^[a-zA-Z0-9_.:-]+$")
    display_name: str = Field(min_length=1, max_length=100)
    app_version: str = Field(min_length=1, max_length=40)


class DeviceView(BaseModel):
    id: int
    device_key: str
    display_name: str
    app_version: str
    created_at: str
    last_seen_at: str


class DeviceHeartbeatInput(BaseModel):
    battery_percent: int | None = Field(default=None, ge=0, le=100)
    charging: bool = False
    network_connected: bool = False
    app_foreground: bool = True
    android_version: str = Field(default="", max_length=40)
    app_version: str = Field(default="", max_length=40)


REMOTE_COMMAND_CONSENT_FEATURE = {
    "backup_create_request": "backup",
    "file_picker_request": "file_access",
    "notification_sync_request": "notifications",
    "screen_share_request": "screen_share",
    "camera_session_request": "camera",
    "microphone_session_request": "microphone",
    "location_once_request": "location",
    "location_session_request": "background_location",
}


def _cancel_commands_for_consent(connection, user_id: int, feature: str, reason: str) -> int:
    """Cancel not-yet-running requests tied to a consent decision; running actions need device-side stop."""
    now = datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")
    if feature == "remote_panel":
        cursor = connection.execute(
            "UPDATE remote_commands SET status='cancelled',updated_at=?,result_summary=? "
            "WHERE user_id=? AND status IN ('pending','delivered','accepted')",
            (now, reason, user_id),
        )
        # A consent revocation cannot truthfully mark a running OS session stopped.
        # Signal the client and keep the session running until the client confirms stop.
        stop_cursor = connection.execute(
            "UPDATE remote_commands SET stop_requested=1,updated_at=?,result_summary=? "
            "WHERE user_id=? AND command_type IN ('screen_share_request','location_session_request') "
            "AND status='running' AND stop_requested=0",
            (now, reason + "; stop requested, awaiting device acknowledgement", user_id),
        )
        connection.execute("DELETE FROM screen_frames WHERE device_id IN (SELECT id FROM devices WHERE user_id=?)", (user_id,))
        return cursor.rowcount + stop_cursor.rowcount
    command_type = next((kind for kind, needed in REMOTE_COMMAND_CONSENT_FEATURE.items() if needed == feature), None)
    if command_type is None:
        return 0
    cursor = connection.execute(
        "UPDATE remote_commands SET status='cancelled',updated_at=?,result_summary=? "
        "WHERE user_id=? AND command_type=? AND status IN ('pending','delivered','accepted')",
        (now, reason, user_id, command_type),
    )
    if command_type == "screen_share_request":
        connection.execute("DELETE FROM screen_frames WHERE device_id IN (SELECT id FROM devices WHERE user_id=?)", (user_id,))
    if command_type in {"screen_share_request", "location_session_request"}:
        stop_cursor = connection.execute(
            "UPDATE remote_commands SET stop_requested=1,updated_at=?,result_summary=? "
            "WHERE user_id=? AND command_type=? AND status='running' AND stop_requested=0",
            (now, reason + "; stop requested, awaiting device acknowledgement", user_id, command_type),
        )
        return cursor.rowcount + stop_cursor.rowcount
    return cursor.rowcount


REMOTE_COMMAND_TYPES = {
    "device_status": False,
    "backup_create_request": True,
    "file_picker_request": True,
    "notification_sync_request": True,
    "screen_share_request": True,
    "camera_session_request": True,
    "microphone_session_request": True,
    "location_once_request": True,
    "location_session_request": True,
}


class RemoteCommandCreateInput(BaseModel):
    command_type: str = Field(min_length=1, max_length=60)
    expires_in_minutes: int = Field(default=10, ge=1, le=30)


class RemoteCommandResultInput(BaseModel):
    status: Literal["accepted", "rejected", "running", "completed", "failed"]
    result_summary: str = Field(default="", max_length=500)


class RemoteCommandView(BaseModel):
    id: int
    device_id: int
    command_type: str
    status: str
    requires_owner_confirmation: bool
    created_at: str
    expires_at: str
    updated_at: str
    # Must be part of the response schema so the admin panel can actually display
    # the Android client's result (e.g. device status or owner-approved location).
    result_summary: str = ""
    stop_requested: bool = False


class NotificationRecordInput(BaseModel):
    package: str = Field(min_length=1, max_length=150)
    title: str = Field(default="", max_length=300)
    text: str = Field(default="", max_length=1000)
    postedAt: int = Field(ge=0, le=9_999_999_999_999)


class NotificationSyncInput(BaseModel):
    items: list[NotificationRecordInput] = Field(min_length=1, max_length=100)


class SecurityEventInput(BaseModel):
    event_type: Literal[
        "permission_revoked", "unusual_server_access", "outdated_app_version",
        "component_integrity_mismatch", "sync_sequence_error", "invalid_admin_privilege"
    ]
    device_key: str | None = Field(default=None, min_length=8, max_length=128, pattern=r"^[a-zA-Z0-9_.:-]+$")


class SecurityEventView(BaseModel):
    id: int
    event_type: str
    severity: str
    confidence: str
    description: str
    recommended_action: str
    source: str
    created_at: str
    resolved_at: str | None


EVENT_RULES = {
    "permission_revoked": ("medium", "medium", "A permission previously used by an enabled feature was reported as revoked.", "Review the permission and disable dependent features if needed."),
    "unusual_server_access": ("medium", "low", "The client reported an unusual server-access pattern; this is not proof of compromise.", "Review authenticated server logs and revoke sessions if independently warranted."),
    "outdated_app_version": ("low", "high", "The client reported that its app version is behind the configured policy.", "Check the official release channel and update when a verified release is available."),
    "component_integrity_mismatch": ("high", "low", "The client reported an integrity-check mismatch; client reports can be inaccurate.", "Verify with trusted telemetry and reinstall only from a trusted distribution source if needed."),
    "sync_sequence_error": ("low", "medium", "The client reported a synchronization sequence error.", "Retry synchronization safely and inspect server-side request identifiers."),
    "invalid_admin_privilege": ("high", "medium", "A client reported an operation rejected for insufficient administrator privileges.", "Review the relevant audit record; do not treat this event alone as evidence of intrusion."),
}


def _library_private_key() -> Ed25519PrivateKey | None:
    encoded = os.getenv("AZAVAD_LIBRARY_SIGNING_PRIVATE_KEY_B64", "").strip()
    key_file = os.getenv("AZAVAD_LIBRARY_SIGNING_PRIVATE_KEY_FILE", "").strip()
    if not encoded and key_file:
        try:
            encoded = Path(key_file).read_text(encoding="ascii").strip()
        except OSError as exc:
            raise HTTPException(status_code=503, detail="Library signing key configuration is invalid") from exc
    if not encoded:
        return None
    try:
        raw = base64.b64decode(encoded, validate=True)
        if len(raw) != 32:
            raise ValueError("Ed25519 private key must be 32 raw bytes")
        return Ed25519PrivateKey.from_private_bytes(raw)
    except (ValueError, TypeError) as exc:
        raise HTTPException(status_code=503, detail="Library signing key configuration is invalid") from exc


def _public_key_b64(key: Ed25519PublicKey) -> str:
    raw = key.public_bytes(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw)
    return base64.b64encode(raw).decode("ascii")


def _library_key_id(key: Ed25519PublicKey) -> str:
    return hashlib.sha256(key.public_bytes(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw)).hexdigest()[:16]


def _canonical_json(payload: dict) -> bytes:
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _library_version_view(row):
    payload = json.loads(row["payload_json"])
    return {**payload, "content_sha256": row["content_sha256"], "signature": row["signature_b64"],
            "signing_key_id": row["signing_key_id"], "published_at": row["published_at"]}


def current_user(authorization: Annotated[str | None, Header()] = None):
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="Authentication required", headers={"WWW-Authenticate": "Bearer"})
    token = authorization[7:].strip()
    if len(token) < 32:
        raise HTTPException(status_code=401, detail="Invalid or expired session")
    now = datetime.now(timezone.utc).isoformat()
    with connect_db() as connection:
        row = connection.execute("""
            SELECT u.id, u.username, u.role, u.disabled, u.created_at
            FROM sessions s JOIN users u ON u.id=s.user_id
            WHERE s.token_hash=? AND s.revoked_at IS NULL AND s.expires_at>? AND u.disabled=0
        """, (token_digest(token), now)).fetchone()
    if row is None:
        raise HTTPException(status_code=401, detail="Invalid or expired session")
    return dict(row)


def require_roles(*roles):
    def checker(user=Depends(current_user)):
        if user["role"] not in roles:
            raise HTTPException(status_code=403, detail="Insufficient permissions")
        return user
    return checker


def login_attempt_keys(username: str, request: Request) -> tuple[str, str]:
    # Enforce both per-username/IP and per-IP limits so changing usernames does not bypass throttling.
    # Store only digests; never persist raw client addresses or submitted usernames in this table.
    client_host = request.client.host if request.client else "unknown-client"
    user_material = f"user\0{username.casefold()}\0{client_host}".encode("utf-8")
    ip_material = f"ip\0{client_host}".encode("utf-8")
    return hashlib.sha256(user_material).hexdigest(), hashlib.sha256(ip_material).hexdigest()


def login_is_limited(key_hash: str, now: datetime) -> bool:
    with connect_db() as connection:
        row = connection.execute(
            "SELECT window_started_at,failures FROM auth_failures WHERE key_hash=?", (key_hash,)
        ).fetchone()
    if row is None or row["failures"] < LOGIN_FAILURE_LIMIT:
        return False
    try:
        started = datetime.fromisoformat(row["window_started_at"])
    except ValueError:
        # Fail closed on corrupt limiter state; an operator can clear the row after investigation.
        return True
    return now - started < LOGIN_FAILURE_WINDOW


def record_login_failure(key_hash: str, now: datetime) -> None:
    now_text = now.isoformat()
    window_cutoff = (now - LOGIN_FAILURE_WINDOW).isoformat()
    with connect_db() as connection:
        connection.execute("""
            INSERT INTO auth_failures(key_hash,window_started_at,failures,updated_at)
            VALUES(?,?,1,?)
            ON CONFLICT(key_hash) DO UPDATE SET
              failures=CASE WHEN auth_failures.window_started_at<=? THEN 1 ELSE auth_failures.failures+1 END,
              window_started_at=CASE WHEN auth_failures.window_started_at<=? THEN excluded.window_started_at ELSE auth_failures.window_started_at END,
              updated_at=excluded.updated_at
        """, (key_hash, now_text, now_text, window_cutoff, window_cutoff))
        # Bound storage growth in the development SQLite database.
        connection.execute("DELETE FROM auth_failures WHERE updated_at<?", (window_cutoff,))


def clear_login_failures(key_hash: str) -> None:
    with connect_db() as connection:
        connection.execute("DELETE FROM auth_failures WHERE key_hash=?", (key_hash,))


def check_and_record_registration_attempt(request: Request, now: datetime) -> bool:
    """Atomically throttle registration per direct client address; intended for single-instance dev use."""
    client_host = request.client.host if request.client else "unknown-client"
    key_hash = hashlib.sha256(f"register\0{client_host}".encode("utf-8")).hexdigest()
    now_text = now.isoformat()
    cutoff = (now - REGISTRATION_WINDOW).isoformat()
    with connect_db() as connection:
        connection.execute("BEGIN IMMEDIATE")
        row = connection.execute(
            "SELECT window_started_at,attempts FROM registration_attempts WHERE key_hash=?", (key_hash,)
        ).fetchone()
        if row is not None:
            try:
                window_started = datetime.fromisoformat(row["window_started_at"])
            except ValueError:
                # Fail closed if the limiter state is malformed.
                return False
            if now - window_started < REGISTRATION_WINDOW and row["attempts"] >= REGISTRATION_ATTEMPT_LIMIT:
                return False
            if window_started <= now - REGISTRATION_WINDOW:
                connection.execute(
                    "UPDATE registration_attempts SET window_started_at=?,attempts=1,updated_at=? WHERE key_hash=?",
                    (now_text, now_text, key_hash),
                )
            else:
                connection.execute(
                    "UPDATE registration_attempts SET attempts=attempts+1,updated_at=? WHERE key_hash=?",
                    (now_text, key_hash),
                )
        else:
            connection.execute(
                "INSERT INTO registration_attempts(key_hash,window_started_at,attempts,updated_at) VALUES(?,?,1,?)",
                (key_hash, now_text, now_text),
            )
        connection.execute("DELETE FROM registration_attempts WHERE updated_at<?", (cutoff,))
    return True


@app.get("/health")
def health():
    # Process-only readiness; production should expose a separate, bounded dependency health check.
    return {"status": "ok", "scope": "process-only", "version": app.version}


@app.post("/v1/auth/register", response_model=UserView, status_code=201)
def register(payload: RegisterInput, request: Request):
    now = datetime.now(timezone.utc)
    if not check_and_record_registration_attempt(request, now):
        raise HTTPException(status_code=429, detail="Registration temporarily limited; try again later",
                            headers={"Retry-After": str(int(REGISTRATION_WINDOW.total_seconds()))})
    if not USERNAME_RE.fullmatch(payload.username):
        raise HTTPException(status_code=422, detail="Invalid username")
    try:
        with connect_db() as connection:
            existing = connection.execute("SELECT id FROM users WHERE username=?", (payload.username,)).fetchone()
            if existing:
                raise HTTPException(status_code=409, detail="Username unavailable")
            cursor = connection.execute(
                "INSERT INTO users(username,password_hash,role) VALUES(?,?, 'user')",
                (payload.username, hash_password(payload.password)),
            )
            row = connection.execute("SELECT id,username,role,disabled,created_at FROM users WHERE id=?", (cursor.lastrowid,)).fetchone()
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=409, detail="Username unavailable")
    audit(row["id"], "account.register", "user", row["id"])
    return UserView(**dict(row))


@app.post("/v1/auth/login", response_model=SessionView)
def login(payload: LoginInput, request: Request):
    now = datetime.now(timezone.utc)
    user_attempt_key, ip_attempt_key = login_attempt_keys(payload.username, request)
    if login_is_limited(user_attempt_key, now) or login_is_limited(ip_attempt_key, now):
        # Do not create an unbounded audit row for every blocked request; that would enable log-flooding.
        raise HTTPException(status_code=429, detail="Too many failed login attempts; try again later", headers={"Retry-After": str(int(LOGIN_FAILURE_WINDOW.total_seconds()))})
    with connect_db() as connection:
        user = connection.execute("SELECT * FROM users WHERE username=? COLLATE NOCASE", (payload.username,)).fetchone()
    if user is None or user["disabled"] or not verify_password(payload.password, user["password_hash"]):
        record_login_failure(user_attempt_key, now)
        record_login_failure(ip_attempt_key, now)
        audit(user["id"] if user else None, "auth.login", "session", None, "denied")
        raise HTTPException(status_code=401, detail="Invalid username or password", headers={"WWW-Authenticate": "Bearer"})
    clear_login_failures(user_attempt_key)
    token = new_session_token()
    now = datetime.now(timezone.utc)
    expires = now + timedelta(hours=max(1, min(SESSION_HOURS, 24)))
    with connect_db() as connection:
        connection.execute(
            "INSERT INTO sessions(user_id,token_hash,created_at,expires_at) VALUES(?,?,?,?)",
            (user["id"], token_digest(token), now.isoformat(), expires.isoformat()),
        )
    audit(user["id"], "auth.login", "session", None)
    return SessionView(access_token=token, expires_at=expires.isoformat())


@app.post("/v1/auth/logout", status_code=204)
def logout(user=Depends(current_user), authorization: Annotated[str | None, Header()] = None):
    token = authorization[7:].strip()
    now = datetime.now(timezone.utc).isoformat()
    with connect_db() as connection:
        connection.execute("UPDATE sessions SET revoked_at=? WHERE token_hash=? AND revoked_at IS NULL", (now, token_digest(token)))
    audit(user["id"], "auth.logout", "session")
    return None


@app.post("/v1/auth/logout-all", status_code=204)
def logout_all(user=Depends(current_user)):
    now = datetime.now(timezone.utc).isoformat()
    with connect_db() as connection:
        connection.execute("UPDATE sessions SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL", (now, user["id"]))
    audit(user["id"], "auth.logout_all", "user", user["id"])
    return None


@app.get("/v1/auth/me", response_model=UserView)
def me(user=Depends(current_user)):
    with connect_db() as connection:
        row = connection.execute("SELECT id,username,role,disabled,created_at FROM users WHERE id=?", (user["id"],)).fetchone()
    return UserView(**dict(row))


@app.get("/v1/account/export")
def export_own_account(user=Depends(current_user)):
    """Export the authenticated user's own application-managed records, excluding credentials and tokens."""
    with connect_db() as connection:
        account = connection.execute(
            "SELECT id,username,role,disabled,created_at FROM users WHERE id=?", (user["id"],)
        ).fetchone()
        consents = connection.execute(
            "SELECT feature,policy_version,granted,created_at FROM consent_records WHERE user_id=? ORDER BY id", (user["id"],)
        ).fetchall()
        devices = connection.execute(
            "SELECT device_key,display_name,app_version,created_at,last_seen_at FROM devices WHERE user_id=? ORDER BY id", (user["id"],)
        ).fetchall()
        events = connection.execute(
            "SELECT event_type,severity,confidence,description,recommended_action,source,created_at,resolved_at FROM security_events WHERE user_id=? ORDER BY id", (user["id"],)
        ).fetchall()
        audit_rows = connection.execute(
            "SELECT action,target_type,target_id,outcome,created_at FROM audit_events WHERE actor_user_id=? ORDER BY id", (user["id"],)
        ).fetchall()
    return {
        "schema_version": 1,
        "account": dict(account),
        "consents": [{**dict(row), "granted": bool(row["granted"])} for row in consents],
        "devices": [dict(row) for row in devices],
        "security_events": [dict(row) for row in events],
        "audit_events": [dict(row) for row in audit_rows],
        "excluded_data": ["password hashes", "session tokens and token digests", "other users' records"],
    }


@app.delete("/v1/account", status_code=204)
def delete_own_account(payload: AccountDeleteInput, user=Depends(current_user)):
    """Permanently delete the authenticated user's account and account-scoped records."""
    if not payload.confirm:
        raise HTTPException(status_code=400, detail="Explicit account deletion confirmation required")
    with connect_db() as connection:
        row = connection.execute("SELECT password_hash FROM users WHERE id=?", (user["id"],)).fetchone()
        if row is None or not verify_password(payload.password, row["password_hash"]):
            raise HTTPException(status_code=401, detail="Password confirmation failed")
        stored = connection.execute("SELECT c.stored_name FROM backup_chunks c JOIN backup_objects b ON b.id=c.backup_id WHERE b.user_id=?", (user["id"],)).fetchall()
        # Remove the owner's encrypted backup chunks before cascading the metadata deletion.
        for item in stored:
            try:
                (BACKUP_ROOT / item["stored_name"]).unlink(missing_ok=True)
            except OSError as exc:
                raise HTTPException(status_code=503, detail="Could not securely remove stored backup data; account deletion was cancelled") from exc
        connection.execute("DELETE FROM users WHERE id=?", (user["id"],))
    # Preserve a minimal non-identifying operational record after account-scoped rows are detached.
    audit(None, "account.delete", "user")
    return None


@app.get("/v1/admin/devices")
def admin_list_devices(user=Depends(require_roles("admin"))):
    with connect_db() as connection:
        rows = connection.execute("""
            SELECT d.id,d.user_id,u.username,d.device_key,d.display_name,d.app_version,d.created_at,d.last_seen_at,
                   h.battery_percent,h.charging,h.network_connected,h.app_foreground,h.android_version,h.reported_at AS heartbeat_at
            FROM devices d JOIN users u ON u.id=d.user_id
            LEFT JOIN device_heartbeats h ON h.device_id=d.id
            ORDER BY d.last_seen_at DESC,d.id DESC LIMIT 500
        """).fetchall()
    result = []
    for row in rows:
        item = dict(row)
        item["charging"] = bool(item["charging"]) if item["charging"] is not None else None
        item["network_connected"] = bool(item["network_connected"]) if item["network_connected"] is not None else None
        item["app_foreground"] = bool(item["app_foreground"]) if item["app_foreground"] is not None else None
        result.append(item)
    return result


@app.get("/v1/admin/users", response_model=list[UserView])
def admin_list_users(user=Depends(require_roles("admin"))):
    with connect_db() as connection:
        rows = connection.execute("SELECT id,username,role,disabled,created_at FROM users ORDER BY id").fetchall()
    return [UserView(**dict(row)) for row in rows]


@app.post("/v1/admin/users", response_model=UserView, status_code=201)
def admin_create_user(payload: AdminCreateUserInput, user=Depends(require_roles("admin"))):
    if not USERNAME_RE.fullmatch(payload.username):
        raise HTTPException(status_code=422, detail="Invalid username")
    try:
        with connect_db() as connection:
            cursor = connection.execute(
                "INSERT INTO users(username,password_hash,role) VALUES(?,?,?)",
                (payload.username, hash_password(payload.password), payload.role),
            )
            row = connection.execute("SELECT id,username,role,disabled,created_at FROM users WHERE id=?", (cursor.lastrowid,)).fetchone()
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=409, detail="Username unavailable")
    audit(user["id"], "admin.user_create", "user", row["id"])
    return UserView(**dict(row))


@app.patch("/v1/admin/users/{user_id}", response_model=UserView)
def admin_set_user_disabled(user_id: int, payload: AdminUserPatch, user=Depends(require_roles("admin"))):
    if user_id == user["id"] and payload.disabled:
        raise HTTPException(status_code=409, detail="Administrators cannot disable their own active account")
    with connect_db() as connection:
        target = connection.execute("SELECT id,role,disabled FROM users WHERE id=?", (user_id,)).fetchone()
        if target is None:
            raise HTTPException(status_code=404, detail="User not found")
        if payload.disabled and target["role"] == "admin" and not target["disabled"]:
            active_admins = connection.execute("SELECT COUNT(*) FROM users WHERE role='admin' AND disabled=0").fetchone()[0]
            if active_admins <= 1:
                raise HTTPException(status_code=409, detail="Cannot disable the last active administrator")
        connection.execute("UPDATE users SET disabled=? WHERE id=?", (int(payload.disabled), user_id))
        if payload.disabled:
            now = datetime.now(timezone.utc).isoformat()
            connection.execute("UPDATE sessions SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL", (now, user_id))
        row = connection.execute("SELECT id,username,role,disabled,created_at FROM users WHERE id=?", (user_id,)).fetchone()
    audit(user["id"], "admin.user_disable" if payload.disabled else "admin.user_enable", "user", user_id)
    return UserView(**dict(row))


@app.get("/v1/library/signing-key")
def library_signing_key():
    key = _library_private_key()
    if key is None:
        raise HTTPException(status_code=503, detail="Library signing is not configured")
    public_key = key.public_key()
    return {"algorithm": "Ed25519", "key_id": _library_key_id(public_key), "public_key_b64": _public_key_b64(public_key)}


@app.get("/v1/library")
def list_published_library():
    with connect_db() as connection:
        rows = connection.execute("""
            SELECT v.* FROM library_versions v
            JOIN (SELECT item_id, MAX(version) AS version FROM library_versions GROUP BY item_id) latest
              ON latest.item_id=v.item_id AND latest.version=v.version
            ORDER BY v.item_id
        """).fetchall()
    return [_library_version_view(row) for row in rows]


@app.get("/v1/library/{slug}")
def get_published_library_item(slug: str):
    with connect_db() as connection:
        row = connection.execute("""
            SELECT v.* FROM library_versions v JOIN library_items i ON i.id=v.item_id
            WHERE i.slug=? ORDER BY v.version DESC LIMIT 1
        """, (slug,)).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="Published library item not found")
    return _library_version_view(row)


@app.get("/v1/admin/library")
def admin_list_library(user=Depends(require_roles("admin"))):
    with connect_db() as connection:
        rows = connection.execute("""
            SELECT i.id,i.slug,i.title,i.category,i.summary,i.body,i.source_url,i.verified_at,i.status,i.updated_at,
                   (SELECT MAX(version) FROM library_versions v WHERE v.item_id=i.id) AS published_version
            FROM library_items i ORDER BY i.id DESC
        """).fetchall()
    return [dict(row) for row in rows]


@app.post("/v1/admin/library", status_code=201)
def admin_create_library_item(payload: LibraryItemInput, user=Depends(require_roles("admin"))):
    payload.validate_content()
    now = datetime.now(timezone.utc).isoformat()
    try:
        with connect_db() as connection:
            cursor = connection.execute("""
                INSERT INTO library_items(slug,title,category,summary,body,source_url,verified_at,status,updated_at)
                VALUES(?,?,?,?,?,?,?,'draft',?)
            """, (payload.slug,payload.title,payload.category,payload.summary,payload.body,payload.source_url,payload.verified_at,now))
            item_id = cursor.lastrowid
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=409, detail="Library slug already exists")
    audit(user["id"], "admin.library.create", "library_item", item_id)
    return {"id": item_id, "slug": payload.slug, "status": "draft", "published_version": None}


@app.patch("/v1/admin/library/{item_id}")
def admin_update_library_item(item_id: int, payload: LibraryItemPatch, user=Depends(require_roles("admin"))):
    updates = payload.model_dump(exclude_unset=True)
    if any(value is None for value in updates.values()):
        raise HTTPException(status_code=422, detail="Library fields cannot be null; omit unchanged fields")
    if not updates:
        raise HTTPException(status_code=400, detail="No changes supplied")
    with connect_db() as connection:
        row = connection.execute("SELECT * FROM library_items WHERE id=?", (item_id,)).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="Library item not found")
        merged = {key: row[key] for key in ("title","category","summary","body","source_url","verified_at")}
        merged.update({key: value for key, value in updates.items() if value is not None})
        candidate = LibraryItemInput(slug=row["slug"], **merged)
        candidate.validate_content()
        updates["status"] = "draft"
        updates["updated_at"] = datetime.now(timezone.utc).isoformat()
        connection.execute("UPDATE library_items SET " + ",".join(f"{key}=?" for key in updates) + " WHERE id=?", (*updates.values(), item_id))
    audit(user["id"], "admin.library.update", "library_item", item_id)
    return {"id": item_id, "slug": row["slug"], "status": "draft", "changes": sorted(payload.model_dump(exclude_unset=True).keys())}


@app.post("/v1/admin/library/{item_id}/publish")
def admin_publish_library_item(item_id: int, user=Depends(require_roles("admin"))):
    key = _library_private_key()
    if key is None:
        raise HTTPException(status_code=503, detail="Library signing is not configured; refusing unsigned publication")
    with connect_db() as connection:
        # Serialize version allocation so concurrent publish requests cannot reuse a version number.
        connection.execute("BEGIN IMMEDIATE")
        item = connection.execute("SELECT * FROM library_items WHERE id=?", (item_id,)).fetchone()
        if item is None:
            raise HTTPException(status_code=404, detail="Library item not found")
        payload_model = LibraryItemInput(**{field: item[field] for field in ("slug","title","category","summary","body","source_url","verified_at")})
        payload_model.validate_content()
        latest = connection.execute("SELECT MAX(version) FROM library_versions WHERE item_id=?", (item_id,)).fetchone()[0]
        version = (latest or 0) + 1
        published_at = datetime.now(timezone.utc).isoformat()
        payload = {"schema_version": 1, "slug": item["slug"], "title": item["title"], "category": item["category"],
                   "summary": item["summary"], "body": item["body"], "source_url": item["source_url"],
                   "verified_at": item["verified_at"], "version": version}
        canonical = _canonical_json(payload)
        digest = hashlib.sha256(canonical).hexdigest()
        signature = base64.b64encode(key.sign(canonical)).decode("ascii")
        public_key = key.public_key()
        key_id = _library_key_id(public_key)
        connection.execute("""INSERT INTO library_versions(item_id,version,payload_json,content_sha256,signature_b64,signing_key_id,published_at)
                              VALUES(?,?,?,?,?,?,?)""", (item_id,version,canonical.decode("utf-8"),digest,signature,key_id,published_at))
        connection.execute("UPDATE library_items SET status='published',updated_at=? WHERE id=?", (published_at,item_id))
    audit(user["id"], "admin.library.publish", "library_item", item_id)
    return {**payload, "content_sha256": digest, "signature": signature, "signing_key_id": key_id, "published_at": published_at}


@app.post("/v1/consents", response_model=ConsentView, status_code=201)
def create_consent(payload: ConsentInput, user=Depends(current_user)):
    # Sensitive capability consent is an auditable preference only. It never grants
    # Android runtime permissions or authorizes a server to trigger capture remotely.
    if payload.feature in SENSITIVE_CONSENT_FEATURES and payload.granted:
        if not payload.owner_confirmed:
            raise HTTPException(status_code=422, detail="Explicit device-owner confirmation is required")
        if payload.purpose != "emergency_safety":
            raise HTTPException(status_code=422, detail="Sensitive capabilities require the emergency_safety purpose")
        if payload.expires_in_hours is not None and payload.expires_in_days is not None:
            raise HTTPException(status_code=422, detail="Specify only one consent duration field")
    elif payload.feature in SENSITIVE_CONSENT_FEATURES and payload.purpose not in {"standard", "emergency_safety"}:
        raise HTTPException(status_code=422, detail="Unsupported consent purpose")

    expires_at = None
    if payload.feature in SENSITIVE_CONSENT_FEATURES and payload.granted:
        # Default duration requested by product policy: 365 days, revocable at any time.
        if payload.expires_in_days is not None:
            duration = timedelta(days=payload.expires_in_days)
        elif payload.expires_in_hours is not None:
            duration = timedelta(hours=payload.expires_in_hours)
        else:
            duration = timedelta(days=365)
        expires_at = (datetime.now(timezone.utc) + duration).isoformat()
    elif payload.expires_in_days is not None:
        expires_at = (datetime.now(timezone.utc) + timedelta(days=payload.expires_in_days)).isoformat()
    elif payload.expires_in_hours is not None:
        expires_at = (datetime.now(timezone.utc) + timedelta(hours=payload.expires_in_hours)).isoformat()
    with connect_db() as connection:
        # A new consent decision supersedes the previous decision for that feature.
        connection.execute("UPDATE consent_records SET granted=0 WHERE user_id=? AND feature=? AND granted=1", (user["id"], payload.feature))
        cursor = connection.execute(
            "INSERT INTO consent_records(user_id,feature,policy_version,granted,purpose,expires_at,owner_confirmed) VALUES(?,?,?,?,?,?,?)",
            (user["id"], payload.feature, payload.policy_version, int(payload.granted), payload.purpose,
             expires_at, int(payload.owner_confirmed)),
        )
        row = connection.execute("SELECT * FROM consent_records WHERE id=?", (cursor.lastrowid,)).fetchone()
        if not payload.granted:
            _cancel_commands_for_consent(
                connection, user["id"], payload.feature,
                f"Cancelled because owner denied or revoked {payload.feature} consent",
            )
    audit(user["id"], "consent.grant" if payload.granted else "consent.deny", "consent", row["id"])
    return ConsentView(id=row["id"], feature=row["feature"], policy_version=row["policy_version"],
                       granted=bool(row["granted"]), purpose=row["purpose"], expires_at=row["expires_at"],
                       owner_confirmed=bool(row["owner_confirmed"]), created_at=row["created_at"])


class BackupCreateInput(BaseModel):
    filename: str = Field(min_length=1, max_length=255)
    size_bytes: int = Field(ge=0, le=BACKUP_MAX_FILE_BYTES)
    content_type: str = Field(default="application/octet-stream", min_length=3, max_length=150, pattern=r"^[A-Za-z0-9.+-]+/[A-Za-z0-9.+-]+$")


def _backup_key() -> bytes:
    configured = os.getenv("AZAVAD_BACKUP_ENCRYPTION_KEY", "").strip()
    if configured:
        try:
            raw = base64.urlsafe_b64decode(configured + "=" * (-len(configured) % 4))
        except Exception as exc:
            raise HTTPException(status_code=503, detail="Backup encryption key is invalid") from exc
        if len(raw) != 32:
            raise HTTPException(status_code=503, detail="Backup encryption key must decode to 32 bytes")
        return raw
    if APP_ENV == "production":
        raise HTTPException(status_code=503, detail="Server-side backup encryption is not configured")
    # Development-only key: backups cannot be safely moved between environments.
    return hashlib.sha256(b"AZAVAD-DEVELOPMENT-ONLY-BACKUP-KEY-DO-NOT-USE-IN-PRODUCTION").digest()


def _require_backup_consent(user_id: int):
    now = datetime.now(timezone.utc).isoformat()
    with connect_db() as connection:
        row = connection.execute("""SELECT granted, owner_confirmed, purpose, expires_at FROM consent_records
            WHERE user_id=? AND feature='backup' ORDER BY id DESC LIMIT 1""", (user_id,)).fetchone()
    if (row is None or not row["granted"] or not row["owner_confirmed"] or row["purpose"] != "backup"
            or (row["expires_at"] is not None and row["expires_at"] <= now)):
        raise HTTPException(status_code=403, detail="Active explicit owner consent for server backups is required")


def _owned_backup(backup_id: str, user_id: int):
    with connect_db() as connection:
        row = connection.execute("SELECT * FROM backup_objects WHERE id=? AND user_id=?", (backup_id, user_id)).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="Backup not found")
    return dict(row)


@app.post("/v1/backups", status_code=201)
def create_backup(payload: BackupCreateInput, user=Depends(current_user)):
    _require_backup_consent(user["id"])
    _backup_key()  # Fail closed if encryption is unavailable/misconfigured.
    clean_name = Path(payload.filename.replace("\\", "/")).name
    clean_name = re.sub(r"[\\x00-\\x1f\\x7f]", "_", clean_name).strip()[:255] or "backup.bin"
    quota = int(os.getenv("AZAVAD_BACKUP_QUOTA_BYTES", str(BACKUP_DEFAULT_QUOTA_BYTES)))
    with connect_db() as connection:
        connection.execute("BEGIN IMMEDIATE")
        used = connection.execute("SELECT COALESCE(SUM(size_bytes),0) AS n FROM backup_objects WHERE user_id=? AND status IN ('uploading','complete')", (user["id"],)).fetchone()["n"]
        if used + payload.size_bytes > quota:
            raise HTTPException(status_code=413, detail="Account backup quota exceeded")
        backup_id = secrets.token_urlsafe(18)
        chunks = max(1, math.ceil(payload.size_bytes / BACKUP_CHUNK_BYTES))
        connection.execute("INSERT INTO backup_objects(id,user_id,filename,content_type,size_bytes,chunk_size,chunk_count,status) VALUES(?,?,?,?,?,?,?,'uploading')",
            (backup_id,user["id"],clean_name,payload.content_type,payload.size_bytes,BACKUP_CHUNK_BYTES,chunks))
    BACKUP_ROOT.mkdir(parents=True, exist_ok=True)
    audit(user["id"], "backup.create", "backup", backup_id)
    return {"id": backup_id, "chunk_size": BACKUP_CHUNK_BYTES, "chunk_count": chunks, "max_file_bytes": BACKUP_MAX_FILE_BYTES, "status": "uploading"}


@app.get("/v1/backups/{backup_id}/status")
def backup_upload_status(backup_id: str, user=Depends(current_user)):
    _require_backup_consent(user["id"])
    backup = _owned_backup(backup_id, user["id"])
    with connect_db() as connection:
        rows = connection.execute("SELECT chunk_index,plain_size FROM backup_chunks WHERE backup_id=? ORDER BY chunk_index", (backup_id,)).fetchall()
    return {"id": backup_id, "status": backup["status"], "filename": backup["filename"],
            "size_bytes": backup["size_bytes"], "chunk_size": backup["chunk_size"],
            "chunk_count": backup["chunk_count"], "sha256": backup["sha256"],
            "uploaded_chunks": [{"index": row["chunk_index"], "size_bytes": row["plain_size"]} for row in rows]}


@app.put("/v1/backups/{backup_id}/chunks/{chunk_index}")
async def upload_backup_chunk(backup_id: str, chunk_index: int, request: Request, user=Depends(current_user)):
    _require_backup_consent(user["id"])
    _backup_key()
    backup = _owned_backup(backup_id, user["id"])
    if backup["status"] != "uploading":
        raise HTTPException(status_code=409, detail="Backup upload is not active")
    if chunk_index < 0 or chunk_index >= backup["chunk_count"]:
        raise HTTPException(status_code=404, detail="Chunk index is outside the upload")
    expected = min(backup["chunk_size"], max(0, backup["size_bytes"] - chunk_index * backup["chunk_size"]))
    declared = request.headers.get("content-length")
    if declared is None:
        raise HTTPException(status_code=411, detail="Content-Length is required for bounded chunk uploads")
    if not declared.isdigit() or int(declared) != expected:
        raise HTTPException(status_code=413, detail="Chunk size does not match expected length")
    data = await request.body()
    if len(data) != expected:
        raise HTTPException(status_code=413, detail="Chunk size does not match expected length")
    digest = hashlib.sha256(data).hexdigest()
    nonce = secrets.token_bytes(12)
    encrypted = nonce + AESGCM(_backup_key()).encrypt(nonce, data, f"{backup_id}:{chunk_index}".encode())
    BACKUP_ROOT.mkdir(parents=True, exist_ok=True)
    stored_name = f"{backup_id}.{chunk_index}.enc"
    target = BACKUP_ROOT / stored_name
    temp = BACKUP_ROOT / (stored_name + ".tmp")
    temp.write_bytes(encrypted)
    os.replace(temp, target)
    with connect_db() as connection:
        connection.execute("INSERT INTO backup_chunks(backup_id,chunk_index,plain_size,plain_sha256,stored_name) VALUES(?,?,?,?,?) ON CONFLICT(backup_id,chunk_index) DO UPDATE SET plain_size=excluded.plain_size,plain_sha256=excluded.plain_sha256,stored_name=excluded.stored_name",
            (backup_id,chunk_index,len(data),digest,stored_name))
    return {"id": backup_id, "chunk_index": chunk_index, "size_bytes": len(data), "sha256": digest, "stored_encrypted": True}


@app.post("/v1/backups/{backup_id}/complete")
def complete_backup(backup_id: str, user=Depends(current_user)):
    _require_backup_consent(user["id"])
    key = _backup_key()
    backup = _owned_backup(backup_id, user["id"])
    if backup["status"] != "uploading":
        if backup["status"] == "complete":
            return {"id": backup_id, "status": "complete", "size_bytes": backup["size_bytes"], "sha256": backup["sha256"]}
        raise HTTPException(status_code=409, detail="Backup is not in an uploadable state")
    with connect_db() as connection:
        rows = connection.execute("SELECT * FROM backup_chunks WHERE backup_id=? ORDER BY chunk_index", (backup_id,)).fetchall()
    if len(rows) != backup["chunk_count"] or any(row["chunk_index"] != i for i, row in enumerate(rows)):
        raise HTTPException(status_code=409, detail="Upload is incomplete; one or more chunks are missing")
    total = 0
    digest = hashlib.sha256()
    aes = AESGCM(key)
    for row in rows:
        blob = (BACKUP_ROOT / row["stored_name"]).read_bytes()
        if len(blob) < 13:
            raise HTTPException(status_code=500, detail="Stored chunk is corrupt")
        try:
            plain = aes.decrypt(blob[:12], blob[12:], f"{backup_id}:{row['chunk_index']}".encode())
        except Exception as exc:
            raise HTTPException(status_code=500, detail="Stored chunk failed authentication") from exc
        if len(plain) != row["plain_size"] or hashlib.sha256(plain).hexdigest() != row["plain_sha256"]:
            raise HTTPException(status_code=500, detail="Stored chunk integrity check failed")
        total += len(plain)
        digest.update(plain)
    if total != backup["size_bytes"]:
        raise HTTPException(status_code=409, detail="Uploaded size does not match declared size")
    sha = digest.hexdigest()
    completed_at = datetime.now(timezone.utc).isoformat()
    with connect_db() as connection:
        connection.execute("UPDATE backup_objects SET status='complete',sha256=?,completed_at=? WHERE id=? AND user_id=?", (sha,completed_at,backup_id,user["id"]))
    audit(user["id"], "backup.complete", "backup", backup_id)
    return {"id": backup_id, "status": "complete", "size_bytes": total, "sha256": sha, "encrypted_at_rest": True}


@app.get("/v1/backups")
def list_backups(user=Depends(current_user)):
    with connect_db() as connection:
        rows = connection.execute("SELECT id,filename,content_type,size_bytes,sha256,status,created_at,completed_at FROM backup_objects WHERE user_id=? AND status='complete' ORDER BY created_at DESC", (user["id"],)).fetchall()
        pending = connection.execute("SELECT id,filename,size_bytes,status,created_at FROM backup_objects WHERE user_id=? AND status='uploading' ORDER BY created_at DESC", (user["id"],)).fetchall()
    return {"items": [dict(row) for row in rows], "pending": [dict(row) for row in pending],
            "max_file_bytes": BACKUP_MAX_FILE_BYTES,
            "quota_bytes": int(os.getenv("AZAVAD_BACKUP_QUOTA_BYTES", str(BACKUP_DEFAULT_QUOTA_BYTES)))}


@app.get("/v1/backups/{backup_id}/download")
def download_backup(backup_id: str, user=Depends(current_user)):
    # Revoking future backup consent must not lock the owner out of already-stored copies.
    key = _backup_key()
    backup = _owned_backup(backup_id, user["id"])
    if backup["status"] != "complete":
        raise HTTPException(status_code=409, detail="Backup is not complete")
    with connect_db() as connection:
        rows = [dict(r) for r in connection.execute("SELECT * FROM backup_chunks WHERE backup_id=? ORDER BY chunk_index", (backup_id,)).fetchall()]
    if len(rows) != backup["chunk_count"]:
        raise HTTPException(status_code=500, detail="Backup metadata is incomplete")
    filename = backup["filename"].replace('"', "")
    def stream():
        aes = AESGCM(key)
        total = 0
        digest = hashlib.sha256()
        for row in rows:
            blob = (BACKUP_ROOT / row["stored_name"]).read_bytes()
            plain = aes.decrypt(blob[:12], blob[12:], f"{backup_id}:{row['chunk_index']}".encode())
            if len(plain) != row["plain_size"] or hashlib.sha256(plain).hexdigest() != row["plain_sha256"]:
                raise RuntimeError("Backup chunk integrity verification failed")
            total += len(plain)
            digest.update(plain)
            yield plain
        if total != backup["size_bytes"] or digest.hexdigest() != backup["sha256"]:
            raise RuntimeError("Backup integrity verification failed")
    audit(user["id"], "backup.download", "backup", backup_id)
    return StreamingResponse(stream(), media_type=backup["content_type"], headers={
        "Content-Disposition": f'attachment; filename="{filename}"',
        "Content-Length": str(backup["size_bytes"]),
        "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff",
    })


@app.delete("/v1/backups/{backup_id}", status_code=204)
def delete_backup(backup_id: str, user=Depends(current_user)):
    backup = _owned_backup(backup_id, user["id"])
    with connect_db() as connection:
        rows = connection.execute("SELECT stored_name FROM backup_chunks WHERE backup_id=?", (backup_id,)).fetchall()
        connection.execute("DELETE FROM backup_objects WHERE id=? AND user_id=?", (backup_id,user["id"]))
    for row in rows:
        try: (BACKUP_ROOT / row["stored_name"]).unlink(missing_ok=True)
        except OSError: pass
    audit(user["id"], "backup.delete", "backup", backup_id)
    return Response(status_code=204)


@app.get("/v1/consents", response_model=list[ConsentView])
def list_consents(user=Depends(current_user)):
    with connect_db() as connection:
        rows = connection.execute("SELECT * FROM consent_records WHERE user_id=? ORDER BY id", (user["id"],)).fetchall()
    return [ConsentView(id=r["id"], feature=r["feature"], policy_version=r["policy_version"],
                        granted=bool(r["granted"]), purpose=r["purpose"], expires_at=r["expires_at"],
                        owner_confirmed=bool(r["owner_confirmed"]), created_at=r["created_at"]) for r in rows]


@app.get("/v1/consents/effective", response_model=list[ConsentView])
def effective_consents(user=Depends(current_user)):
    now = datetime.now(timezone.utc).isoformat()
    with connect_db() as connection:
        rows = connection.execute("""SELECT c.* FROM consent_records c
            JOIN (SELECT feature, MAX(id) AS latest_id FROM consent_records WHERE user_id=? GROUP BY feature) latest
            ON latest.latest_id=c.id
            WHERE c.user_id=? AND c.granted=1 AND (c.expires_at IS NULL OR c.expires_at>?) ORDER BY c.feature""",
            (user["id"], user["id"], now)).fetchall()
    return [ConsentView(id=r["id"], feature=r["feature"], policy_version=r["policy_version"],
                        granted=True, purpose=r["purpose"], expires_at=r["expires_at"],
                        owner_confirmed=bool(r["owner_confirmed"]), created_at=r["created_at"]) for r in rows]


@app.post("/v1/consents/{consent_id}/revoke", response_model=ConsentView)
def revoke_consent(consent_id: int, user=Depends(current_user)):
    with connect_db() as connection:
        row = connection.execute("SELECT * FROM consent_records WHERE id=? AND user_id=?", (consent_id, user["id"])).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Consent record not found")
        if not row["granted"]:
            raise HTTPException(status_code=409, detail="Consent is already inactive")
        connection.execute("UPDATE consent_records SET granted=0 WHERE id=?", (consent_id,))
        updated = connection.execute("SELECT * FROM consent_records WHERE id=?", (consent_id,)).fetchone()
        _cancel_commands_for_consent(
            connection, user["id"], updated["feature"],
            f"Cancelled because owner revoked {updated['feature']} consent",
        )
    audit(user["id"], "consent.revoke", "consent", consent_id)
    return ConsentView(id=updated["id"], feature=updated["feature"], policy_version=updated["policy_version"],
                       granted=False, purpose=updated["purpose"], expires_at=updated["expires_at"],
                       owner_confirmed=bool(updated["owner_confirmed"]), created_at=updated["created_at"])


def _notification_key() -> bytes:
    configured = os.getenv("AZAVAD_PERSONAL_DATA_ENCRYPTION_KEY", "").strip()
    if configured:
        try:
            raw = base64.urlsafe_b64decode(configured + "=" * (-len(configured) % 4))
        except Exception as exc:
            raise HTTPException(status_code=503, detail="Personal-data encryption key is invalid") from exc
        if len(raw) != 32:
            raise HTTPException(status_code=503, detail="Personal-data encryption key must decode to 32 bytes")
        return raw
    if APP_ENV == "production":
        raise HTTPException(status_code=503, detail="Personal-data encryption is not configured")
    return hashlib.sha256(b"AZAVAD-DEVELOPMENT-ONLY-PERSONAL-DATA-KEY-DO-NOT-USE-IN-PRODUCTION").digest()


def _require_notification_consent(user_id: int):
    now = datetime.now(timezone.utc).isoformat()
    with connect_db() as connection:
        row = connection.execute(
            "SELECT granted,owner_confirmed,expires_at FROM consent_records WHERE user_id=? AND feature='notifications' ORDER BY id DESC LIMIT 1",
            (user_id,),
        ).fetchone()
    if row is None or not row["granted"] or not row["owner_confirmed"] or (row["expires_at"] and row["expires_at"] <= now):
        raise HTTPException(status_code=403, detail="Active owner-confirmed notification consent is required")


@app.post("/v1/notification-events/sync")
def sync_notification_events(payload: NotificationSyncInput, user=Depends(current_user)):
    _require_notification_consent(user["id"])
    inserted = 0
    with connect_db() as connection:
        for item in payload.items:
            canonical = json.dumps([item.package, item.title, item.text, item.postedAt], ensure_ascii=False, separators=(",", ":"))
            key = _notification_key()
            fingerprint = hmac.new(key, canonical.encode("utf-8"), hashlib.sha256).hexdigest()
            nonce = secrets.token_bytes(12)
            plaintext = json.dumps({"package": item.package, "title": item.title, "text": item.text}, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
            ciphertext = nonce + AESGCM(key).encrypt(nonce, plaintext, f"{user['id']}:{fingerprint}".encode("utf-8"))
            cursor = connection.execute(
                "INSERT OR IGNORE INTO notification_events(user_id,event_fingerprint,encrypted_payload,posted_at) VALUES(?,?,?,?)",
                (user["id"], fingerprint, ciphertext, item.postedAt),
            )
            inserted += cursor.rowcount
        total = connection.execute("SELECT COUNT(*) FROM notification_events WHERE user_id=?", (user["id"],)).fetchone()[0]
        # Keep the most recent 500 records per account to bound stored personal data.
        connection.execute("DELETE FROM notification_events WHERE user_id=? AND id NOT IN (SELECT id FROM notification_events WHERE user_id=? ORDER BY posted_at DESC,id DESC LIMIT 500)", (user["id"], user["id"]))
    audit(user["id"], "notification.sync", "notification_events", inserted)
    return {"received": len(payload.items), "inserted": inserted, "retained_limit": 500, "count": min(total, 500)}


@app.get("/v1/notification-events")
def list_notification_events(user=Depends(current_user)):
    _require_notification_consent(user["id"])
    with connect_db() as connection:
        rows = connection.execute("SELECT id,event_fingerprint,encrypted_payload,posted_at,received_at FROM notification_events WHERE user_id=? ORDER BY posted_at DESC,id DESC LIMIT 200", (user["id"],)).fetchall()
    items = []
    key = _notification_key()
    for row in rows:
        blob = bytes(row["encrypted_payload"])
        try:
            payload = json.loads(AESGCM(key).decrypt(blob[:12], blob[12:], f"{user['id']}:{row['event_fingerprint']}".encode("utf-8")).decode("utf-8"))
        except Exception as exc:
            raise HTTPException(status_code=503, detail="Notification record failed authentication; check encryption key and database integrity") from exc
        items.append({"id": row["id"], "package": payload["package"], "title": payload["title"], "text": payload["text"], "postedAt": row["posted_at"], "received_at": row["received_at"]})
    return {"items": items, "count": len(items), "retained_limit": 500}


@app.delete("/v1/notification-events", status_code=204)
def clear_notification_events(user=Depends(current_user)):
    with connect_db() as connection:
        connection.execute("DELETE FROM notification_events WHERE user_id=?", (user["id"],))
    audit(user["id"], "notification.clear", "notification_events")
    return None


@app.post("/v1/devices", response_model=DeviceView, status_code=201)
def register_device(payload: DeviceInput, user=Depends(current_user)):
    with connect_db() as connection:
        existing = connection.execute("SELECT id FROM devices WHERE user_id=? AND device_key=?", (user["id"], payload.device_key)).fetchone()
        if existing:
            connection.execute("UPDATE devices SET display_name=?,app_version=?,last_seen_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=?", (payload.display_name, payload.app_version, existing["id"]))
            row = connection.execute("SELECT * FROM devices WHERE id=?", (existing["id"],)).fetchone()
            status_code = 200
        else:
            cursor = connection.execute("INSERT INTO devices(user_id,device_key,display_name,app_version) VALUES(?,?,?,?)", (user["id"], payload.device_key, payload.display_name, payload.app_version))
            row = connection.execute("SELECT * FROM devices WHERE id=?", (cursor.lastrowid,)).fetchone()
    audit(user["id"], "device.register", "device", row["id"])
    return DeviceView(**{k: row[k] for k in DeviceView.model_fields})


@app.post("/v1/devices/{device_id}/heartbeat")
def report_device_heartbeat(device_id: int, payload: DeviceHeartbeatInput, user=Depends(current_user)):
    """Store minimal operational health data while the owner-approved app is active."""
    now = datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")
    with connect_db() as connection:
        device = connection.execute("SELECT id FROM devices WHERE id=? AND user_id=?", (device_id, user["id"])).fetchone()
        if device is None:
            raise HTTPException(status_code=404, detail="Device not found")
        consent = connection.execute("SELECT granted,owner_confirmed,expires_at FROM consent_records WHERE user_id=? AND feature='remote_panel' ORDER BY id DESC LIMIT 1", (user["id"],)).fetchone()
        if consent is None or not consent["granted"] or not consent["owner_confirmed"] or (consent["expires_at"] and consent["expires_at"] <= now):
            raise HTTPException(status_code=403, detail="Active owner-confirmed remote_panel consent is required")
        connection.execute("""INSERT INTO device_heartbeats(device_id,battery_percent,charging,network_connected,app_foreground,android_version,app_version,reported_at)
            VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(device_id) DO UPDATE SET battery_percent=excluded.battery_percent,charging=excluded.charging,
            network_connected=excluded.network_connected,app_foreground=excluded.app_foreground,android_version=excluded.android_version,
            app_version=excluded.app_version,reported_at=excluded.reported_at""",
            (device_id, payload.battery_percent, int(payload.charging), int(payload.network_connected), int(payload.app_foreground), payload.android_version, payload.app_version, now))
        connection.execute("UPDATE devices SET last_seen_at=? WHERE id=?", (now, device_id))
    return {"ok": True, "device_id": device_id, "reported_at": now, "retention": "latest state only"}


@app.get("/v1/devices", response_model=list[DeviceView])
def list_devices(user=Depends(current_user)):
    with connect_db() as connection:
        rows = connection.execute("SELECT * FROM devices WHERE user_id=? ORDER BY id", (user["id"],)).fetchall()
    return [DeviceView(**{k: r[k] for k in DeviceView.model_fields}) for r in rows]


def _device_status_snapshot(connection, device_id: int, owner_id: int) -> dict:
    device = connection.execute(
        "SELECT * FROM devices WHERE id=? AND user_id=?", (device_id, owner_id)
    ).fetchone()
    if device is None:
        raise HTTPException(status_code=404, detail="Device not found")

    heartbeat = connection.execute(
        "SELECT * FROM device_heartbeats WHERE device_id=?", (device_id,)
    ).fetchone()
    now = datetime.now(timezone.utc)
    last_seen = device["last_seen_at"]
    try:
        seen_at = datetime.fromisoformat(last_seen.replace("Z", "+00:00"))
        age_seconds = max(0, int((now - seen_at).total_seconds()))
        connection_state = "online" if age_seconds <= 90 else "offline"
    except (TypeError, ValueError):
        age_seconds = None
        connection_state = "unknown"

    consents = {}
    for row in connection.execute(
        """SELECT c.feature,c.granted,c.owner_confirmed,c.expires_at,c.created_at
           FROM consent_records c
           JOIN (SELECT feature,MAX(id) AS latest_id FROM consent_records
                 WHERE user_id=? GROUP BY feature) latest ON latest.latest_id=c.id
           WHERE c.user_id=?""",
        (owner_id, owner_id),
    ).fetchall():
        expires = row["expires_at"]
        valid = not expires or expires > now.isoformat(timespec="milliseconds").replace("+00:00", "Z")
        consents[row["feature"]] = {
            "granted": bool(row["granted"]),
            "owner_confirmed": bool(row["owner_confirmed"]),
            "expires_at": expires,
            "effective": bool(row["granted"]) and bool(row["owner_confirmed"]) and valid,
            "updated_at": row["created_at"],
        }

    active = connection.execute(
        """SELECT id,command_type,status,created_at,updated_at,expires_at,
                  stop_requested,result_summary
           FROM remote_commands
           WHERE device_id=? AND status IN ('pending','delivered','accepted','running')
           ORDER BY id DESC LIMIT 100""",
        (device_id,),
    ).fetchall()

    return {
        "device": {key: device[key] for key in DeviceView.model_fields},
        "connection": {
            "state": connection_state,
            "last_seen_at": last_seen,
            "age_seconds": age_seconds,
            "heartbeat_received": heartbeat is not None,
        },
        "telemetry": ({
            "battery_percent": heartbeat["battery_percent"],
            "charging": bool(heartbeat["charging"]),
            "network_connected": bool(heartbeat["network_connected"]),
            "app_foreground": bool(heartbeat["app_foreground"]),
            "android_version": heartbeat["android_version"],
            "app_version": heartbeat["app_version"],
            "reported_at": heartbeat["reported_at"],
        } if heartbeat is not None else None),
        "consents": consents,
        "active_commands": [{
            "id": row["id"], "command_type": row["command_type"], "status": row["status"],
            "created_at": row["created_at"], "updated_at": row["updated_at"],
            "expires_at": row["expires_at"], "stop_requested": bool(row["stop_requested"]),
            "result_summary": row["result_summary"],
        } for row in active],
        "server_time": now.isoformat(timespec="milliseconds").replace("+00:00", "Z"),
    }


@app.put("/v1/devices/{device_id}/screen-sessions/{command_id}/frame")
async def upload_screen_frame(device_id: int, command_id: int, request: Request, user=Depends(current_user)):
    """Accept one bounded JPEG frame only for a running, owner-approved screen-share session."""
    content_type = request.headers.get("content-type", "").split(";", 1)[0].strip().lower()
    if content_type != "image/jpeg":
        raise HTTPException(status_code=415, detail="Only image/jpeg frames are accepted")
    chunks = []
    frame_size = 0
    async for chunk in request.stream():
        frame_size += len(chunk)
        if frame_size > 512 * 1024:
            raise HTTPException(status_code=413, detail="Frame must be between 1 byte and 512 KiB")
        chunks.append(chunk)
    frame = b"".join(chunks)
    if not frame:
        raise HTTPException(status_code=413, detail="Frame must be between 1 byte and 512 KiB")
    if not frame.startswith(b"\xff\xd8") or not frame.endswith(b"\xff\xd9"):
        raise HTTPException(status_code=422, detail="Frame is not a valid JPEG payload")
    now = datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")
    digest = hashlib.sha256(frame).hexdigest()
    with connect_db() as connection:
        device = connection.execute("SELECT id FROM devices WHERE id=? AND user_id=?", (device_id, user["id"])).fetchone()
        if device is None:
            raise HTTPException(status_code=404, detail="Device not found")
        consent = connection.execute("SELECT granted,owner_confirmed,expires_at FROM consent_records WHERE user_id=? AND feature='screen_share' ORDER BY id DESC LIMIT 1", (user["id"],)).fetchone()
        if consent is None or not consent["granted"] or not consent["owner_confirmed"] or (consent["expires_at"] and consent["expires_at"] <= now):
            raise HTTPException(status_code=403, detail="Active owner-confirmed screen_share consent is required")
        command = connection.execute("SELECT id,status,stop_requested,command_type FROM remote_commands WHERE id=? AND device_id=? AND user_id=?", (command_id, device_id, user["id"])).fetchone()
        if command is None or command["command_type"] != "screen_share_request" or command["status"] != "running" or command["stop_requested"]:
            raise HTTPException(status_code=409, detail="No active screen-sharing session accepts frames")
        connection.execute("""INSERT INTO screen_frames(device_id,command_id,jpeg_blob,sha256,captured_at) VALUES(?,?,?,?,?)
            ON CONFLICT(device_id) DO UPDATE SET command_id=excluded.command_id,jpeg_blob=excluded.jpeg_blob,sha256=excluded.sha256,captured_at=excluded.captured_at""",
            (device_id, command_id, frame, digest, now))
        connection.execute("UPDATE devices SET last_seen_at=? WHERE id=?", (now, device_id))
    return {"ok": True, "device_id": device_id, "command_id": command_id, "captured_at": now, "sha256": digest, "bytes": len(frame)}


@app.get("/v1/admin/devices/{device_id}/screen-frame")
def admin_get_screen_frame(device_id: int, user=Depends(require_roles("admin"))):
    """Return the latest frame only while the corresponding approved session is running."""
    now = datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")
    with connect_db() as connection:
        row = connection.execute("""SELECT f.jpeg_blob,f.sha256,f.captured_at,f.command_id,d.user_id,c.status,c.stop_requested,
                (SELECT granted FROM consent_records WHERE user_id=d.user_id AND feature='screen_share' ORDER BY id DESC LIMIT 1) AS consent_granted,
                (SELECT owner_confirmed FROM consent_records WHERE user_id=d.user_id AND feature='screen_share' ORDER BY id DESC LIMIT 1) AS consent_confirmed,
                (SELECT expires_at FROM consent_records WHERE user_id=d.user_id AND feature='screen_share' ORDER BY id DESC LIMIT 1) AS consent_expires
            FROM devices d LEFT JOIN screen_frames f ON f.device_id=d.id
            LEFT JOIN remote_commands c ON c.id=f.command_id WHERE d.id=?""", (device_id,)).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="Device not found")
        if row["jpeg_blob"] is None:
            raise HTTPException(status_code=404, detail="No screen frame received yet")
        if row["status"] != "running" or row["stop_requested"] or not row["consent_granted"] or not row["consent_confirmed"] or (row["consent_expires"] and row["consent_expires"] <= now):
            raise HTTPException(status_code=410, detail="Screen-sharing session is no longer active")
        payload = bytes(row["jpeg_blob"])
        digest = row["sha256"]
        captured_at = row["captured_at"]
    return Response(content=payload, media_type="image/jpeg", headers={"Cache-Control":"no-store, no-cache, must-revalidate", "Pragma":"no-cache", "X-AZAVAD-SHA256":digest, "X-AZAVAD-Captured-At":captured_at})


@app.get("/v1/devices/{device_id}/status")
def get_own_device_status(device_id: int, user=Depends(current_user)):
    """Return owner-scoped telemetry and real server-side command/consent state."""
    with connect_db() as connection:
        return _device_status_snapshot(connection, device_id, user["id"])


@app.get("/v1/admin/devices/{device_id}/status")
def admin_get_device_status(device_id: int, user=Depends(require_roles("admin"))):
    """Administrative operational view; status is unknown when no valid heartbeat exists."""
    with connect_db() as connection:
        owner = connection.execute("SELECT user_id FROM devices WHERE id=?", (device_id,)).fetchone()
        if owner is None:
            raise HTTPException(status_code=404, detail="Device not found")
        return _device_status_snapshot(connection, device_id, owner["user_id"])


@app.delete("/v1/devices/{device_id}", status_code=204)
def revoke_device(device_id: int, user=Depends(current_user)):
    with connect_db() as connection:
        row = connection.execute("SELECT id FROM devices WHERE id=? AND user_id=?", (device_id, user["id"])).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="Device not found")
        now = datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")
        connection.execute(
            "UPDATE remote_commands SET status='cancelled',updated_at=?,result_summary='Cancelled because device was unpaired' "
            "WHERE device_id=? AND status IN ('pending','delivered','accepted')",
            (now, device_id),
        )
        connection.execute("DELETE FROM devices WHERE id=? AND user_id=?", (device_id, user["id"]))
    audit(user["id"], "device.revoke", "device", device_id)
    return None


@app.post("/v1/admin/devices/{device_id}/commands", response_model=RemoteCommandView, status_code=201)
def admin_create_remote_command(device_id: int, payload: RemoteCommandCreateInput, user=Depends(require_roles("admin"))):
    """Queue a bounded request. Sensitive actions are prompts, never remote activation."""
    if payload.command_type not in REMOTE_COMMAND_TYPES:
        raise HTTPException(status_code=422, detail="Unsupported command type")
    requires_confirmation = REMOTE_COMMAND_TYPES[payload.command_type]
    expires_at = (datetime.now(timezone.utc) + timedelta(minutes=payload.expires_in_minutes)).isoformat(timespec="milliseconds").replace("+00:00", "Z")
    with connect_db() as connection:
        device = connection.execute("SELECT id,user_id FROM devices WHERE id=?", (device_id,)).fetchone()
        if device is None:
            raise HTTPException(status_code=404, detail="Device not found")
        # Server-side gate: the Android client must synchronize the owner's unified decision
        # as an owner-confirmed `remote_panel` consent before panel requests can be queued.
        consent = connection.execute("SELECT granted,owner_confirmed,expires_at FROM consent_records WHERE user_id=? AND feature='remote_panel' ORDER BY id DESC LIMIT 1", (device["user_id"],)).fetchone()
        now_iso = datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")
        if consent is None or not consent["granted"] or not consent["owner_confirmed"] or (consent["expires_at"] and consent["expires_at"] <= now_iso):
            raise HTTPException(status_code=403, detail="Active owner-confirmed remote_panel consent is required")
        cursor = connection.execute("INSERT INTO remote_commands(user_id,device_id,command_type,status,requires_owner_confirmation,requested_by,expires_at) VALUES(?,?,?,'pending',?,?,?)",
            (device["user_id"], device_id, payload.command_type, int(requires_confirmation), user["id"], expires_at))
        row = connection.execute("SELECT * FROM remote_commands WHERE id=?", (cursor.lastrowid,)).fetchone()
    audit(user["id"], "remote_command.queued", "remote_command", row["id"])
    return RemoteCommandView(**{**dict(row), "requires_owner_confirmation": bool(row["requires_owner_confirmation"])})


@app.get("/v1/admin/commands", response_model=list[RemoteCommandView])
def admin_list_remote_commands(user=Depends(require_roles("admin"))):
    with connect_db() as connection:
        rows = connection.execute("SELECT * FROM remote_commands ORDER BY id DESC LIMIT 200").fetchall()
    return [RemoteCommandView(**{**dict(row), "requires_owner_confirmation": bool(row["requires_owner_confirmation"])}) for row in rows]


@app.get("/v1/devices/{device_id}/commands/pending", response_model=list[RemoteCommandView])
def device_poll_remote_commands(device_id: int, user=Depends(current_user)):
    """Authenticated owner-device polling endpoint. Android must show a local prompt for sensitive requests."""
    now = datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")
    with connect_db() as connection:
        device = connection.execute("SELECT id FROM devices WHERE id=? AND user_id=?", (device_id, user["id"])).fetchone()
        if device is None:
            raise HTTPException(status_code=404, detail="Device not found")
        consent = connection.execute("SELECT granted,owner_confirmed,expires_at FROM consent_records WHERE user_id=? AND feature='remote_panel' ORDER BY id DESC LIMIT 1", (user["id"],)).fetchone()
        consent_active = consent is not None and bool(consent["granted"]) and bool(consent["owner_confirmed"]) and not (consent["expires_at"] and consent["expires_at"] <= now)
        connection.execute("UPDATE devices SET last_seen_at=? WHERE id=?", (now, device_id))
        if not consent_active:
            # After revocation, allow only the narrow stop-signal channel so an already-running
            # session can be told to stop. No new/pending work is delivered without consent.
            rows = connection.execute("SELECT * FROM remote_commands WHERE device_id=? AND status='running' AND stop_requested=1 ORDER BY id LIMIT 40", (device_id,)).fetchall()
            return [RemoteCommandView(**{**dict(row), "requires_owner_confirmation": bool(row["requires_owner_confirmation"])}) for row in rows]
        connection.execute("UPDATE remote_commands SET status='expired',updated_at=? WHERE device_id=? AND status IN ('pending','delivered') AND expires_at<=?", (now, device_id, now))
        rows = connection.execute("SELECT * FROM remote_commands WHERE device_id=? AND (status IN ('pending','delivered') OR (status='cancelled' AND updated_at>=strftime('%Y-%m-%dT%H:%M:%fZ','now','-5 minutes')) OR (status='running' AND stop_requested=1)) ORDER BY id LIMIT 40", (device_id,)).fetchall()
        pending_ids = [row["id"] for row in rows if row["status"] == "pending"]
        if pending_ids:
            connection.executemany("UPDATE remote_commands SET status='delivered',updated_at=? WHERE id=? AND status='pending'", [(now, command_id) for command_id in pending_ids])
    return [RemoteCommandView(**{**dict(row), "status": ("delivered" if row["status"] == "pending" else row["status"]), "updated_at": (now if row["status"] == "pending" else row["updated_at"]), "requires_owner_confirmation": bool(row["requires_owner_confirmation"])}) for row in rows]


@app.post("/v1/devices/{device_id}/commands/{command_id}/result", response_model=RemoteCommandView)
def device_report_remote_command(device_id: int, command_id: int, payload: RemoteCommandResultInput, user=Depends(current_user)):
    now = datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")
    with connect_db() as connection:
        row = connection.execute("SELECT * FROM remote_commands WHERE id=? AND device_id=? AND user_id=?", (command_id, device_id, user["id"])).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="Command not found")
        if row["status"] not in {"pending", "delivered", "accepted", "running"}:
            raise HTTPException(status_code=409, detail="Command is no longer active")
        if row["expires_at"] <= now:
            connection.execute("UPDATE remote_commands SET status='expired',updated_at=? WHERE id=?", (now, command_id))
            raise HTTPException(status_code=409, detail="Command expired")
        if row["requires_owner_confirmation"] and payload.status in {"running", "completed"} and row["status"] not in {"accepted", "running"}:
            raise HTTPException(status_code=409, detail="Owner must explicitly accept this request on the device first")
        if payload.status == "accepted" and not row["requires_owner_confirmation"]:
            raise HTTPException(status_code=422, detail="This command does not use an owner approval step")
        allowed_transitions = {
            "pending": {"delivered", "accepted", "rejected", "failed", "completed"},
            "delivered": {"accepted", "rejected", "failed", "completed"},
            "accepted": {"running", "rejected", "failed", "completed"},
            "running": {"completed", "failed"},
        }
        current_status = row["status"]
        if payload.status != current_status and payload.status not in allowed_transitions.get(current_status, set()):
            raise HTTPException(status_code=409, detail=f"Invalid command status transition: {current_status} -> {payload.status}")
        connection.execute("UPDATE remote_commands SET status=?,result_summary=?,updated_at=? WHERE id=?", (payload.status, payload.result_summary.strip(), now, command_id))
        if row["command_type"] == "screen_share_request" and payload.status in {"completed", "failed", "rejected"}:
            connection.execute("DELETE FROM screen_frames WHERE device_id=? AND command_id=?", (device_id, command_id))
        updated = connection.execute("SELECT * FROM remote_commands WHERE id=?", (command_id,)).fetchone()
    audit(user["id"], "remote_command." + payload.status, "remote_command", command_id)
    return RemoteCommandView(**{**dict(updated), "requires_owner_confirmation": bool(updated["requires_owner_confirmation"])})


@app.post("/v1/admin/commands/{command_id}/cancel", response_model=RemoteCommandView)
def admin_cancel_remote_command(command_id: int, user=Depends(require_roles("admin"))):
    """Cancel queued requests or signal stop for supported long-running sessions."""
    now = datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")
    audit_action = "remote_command.cancelled_by_admin"
    with connect_db() as connection:
        row = connection.execute("SELECT * FROM remote_commands WHERE id=?", (command_id,)).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="Command not found")
        if row["status"] == "running":
            if row["command_type"] not in {"screen_share_request", "location_session_request"}:
                raise HTTPException(status_code=409, detail="This action has no remote-stop handler; stop it on the device.")
            if not row["stop_requested"]:
                connection.execute("UPDATE remote_commands SET stop_requested=1,updated_at=?,result_summary='Stop requested by administrator; awaiting device acknowledgement' WHERE id=?", (now, command_id))
            audit_action = "remote_command.stop_requested"
            updated = connection.execute("SELECT * FROM remote_commands WHERE id=?", (command_id,)).fetchone()
        else:
            if row["status"] not in {"pending", "delivered", "accepted"}:
                raise HTTPException(status_code=409, detail="Command is no longer active")
            connection.execute("UPDATE remote_commands SET status='cancelled',updated_at=?,result_summary='Cancelled by administrator' WHERE id=?", (now, command_id))
            updated = connection.execute("SELECT * FROM remote_commands WHERE id=?", (command_id,)).fetchone()
    audit(user["id"], audit_action, "remote_command", command_id)
    return RemoteCommandView(**{**dict(updated), "requires_owner_confirmation": bool(updated["requires_owner_confirmation"])})

@app.post("/v1/events", response_model=SecurityEventView, status_code=201)
def submit_security_event(payload: SecurityEventInput, user=Depends(current_user)):
    severity, confidence, description, action = EVENT_RULES[payload.event_type]
    device_id = None
    if payload.device_key is not None:
        with connect_db() as connection:
            device = connection.execute("SELECT id FROM devices WHERE user_id=? AND device_key=?", (user["id"], payload.device_key)).fetchone()
        if device is None:
            raise HTTPException(status_code=404, detail="Device not found")
        device_id = device["id"]
    with connect_db() as connection:
        cursor = connection.execute(
            "INSERT INTO security_events(user_id,device_id,event_type,severity,confidence,description,recommended_action,source) VALUES(?,?,?,?,?,?,?,'client_reported')",
            (user["id"], device_id, payload.event_type, severity, confidence, description, action),
        )
        row = connection.execute("SELECT * FROM security_events WHERE id=?", (cursor.lastrowid,)).fetchone()
    audit(user["id"], "security_event.report", "security_event", row["id"])
    return SecurityEventView(**{k: row[k] for k in SecurityEventView.model_fields})


@app.get("/v1/events", response_model=list[SecurityEventView])
def list_own_security_events(user=Depends(current_user)):
    with connect_db() as connection:
        rows = connection.execute("SELECT * FROM security_events WHERE user_id=? ORDER BY id DESC LIMIT 200", (user["id"],)).fetchall()
    return [SecurityEventView(**{k: row[k] for k in SecurityEventView.model_fields}) for row in rows]


@app.get("/v1/admin/events", response_model=list[dict])
def admin_list_security_events(user=Depends(require_roles("admin"))):
    with connect_db() as connection:
        rows = connection.execute("""
            SELECT e.id,e.user_id,u.username,e.device_id,e.event_type,e.severity,e.confidence,
                   e.description,e.recommended_action,e.source,e.created_at,e.resolved_at
            FROM security_events e JOIN users u ON u.id=e.user_id ORDER BY e.id DESC LIMIT 500
        """).fetchall()
    return [dict(row) for row in rows]


@app.post("/v1/admin/events/{event_id}/resolve", status_code=204)
def admin_resolve_event(event_id: int, user=Depends(require_roles("admin"))):
    now = datetime.now(timezone.utc).isoformat()
    with connect_db() as connection:
        row = connection.execute("SELECT id,resolved_at FROM security_events WHERE id=?", (event_id,)).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="Event not found")
        if row["resolved_at"] is not None:
            raise HTTPException(status_code=409, detail="Event already resolved")
        connection.execute("UPDATE security_events SET resolved_at=? WHERE id=?", (now, event_id))
    audit(user["id"], "admin.security_event.resolve", "security_event", event_id)
    return None


@app.get("/v1/audit", response_model=list[dict])
def list_own_audit(user=Depends(current_user)):
    with connect_db() as connection:
        rows = connection.execute("SELECT action,target_type,target_id,outcome,created_at FROM audit_events WHERE actor_user_id=? ORDER BY id DESC LIMIT 200", (user["id"],)).fetchall()
    return [dict(r) for r in rows]


@app.get("/v1/admin/audit", response_model=list[dict])
def admin_audit(user=Depends(require_roles("admin"))):
    with connect_db() as connection:
        rows = connection.execute("SELECT actor_user_id,actor_id_snapshot,action,target_type,target_id,outcome,created_at FROM audit_events ORDER BY id DESC LIMIT 500").fetchall()
    return [dict(r) for r in rows]


@app.get("/v1/admin/audit/integrity")
def admin_verify_audit_integrity(user=Depends(require_roles("admin"))):
    with connect_db() as connection:
        rows = connection.execute("SELECT * FROM audit_events ORDER BY id").fetchall()
    previous_hash = None
    for row in rows:
        if row["prev_hash"] != previous_hash:
            return {"valid": False, "checked_entries": len(rows), "first_invalid_id": row["id"], "reason": "previous_hash_mismatch"}
        record = {
            "id": row["id"], "actor_id_snapshot": row["actor_id_snapshot"], "action": row["action"],
            "target_type": row["target_type"], "target_id": row["target_id"], "outcome": row["outcome"],
            "created_at": row["created_at"], "prev_hash": row["prev_hash"],
        }
        expected_hash = hashlib.sha256(_canonical_json(record)).hexdigest()
        if not row["entry_hash"] or row["entry_hash"] != expected_hash:
            return {"valid": False, "checked_entries": len(rows), "first_invalid_id": row["id"], "reason": "entry_hash_mismatch"}
        previous_hash = row["entry_hash"]
    return {"valid": True, "checked_entries": len(rows), "first_invalid_id": None, "reason": None}


# Same-origin admin interface. Static files do not grant privileges; every API route still checks roles.
ADMIN_DIR = Path(__file__).resolve().parents[2] / "admin"
if ADMIN_DIR.is_dir():
    app.mount("/admin", StaticFiles(directory=str(ADMIN_DIR), html=True), name="admin")
