import os
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
import base64
from pathlib import Path
from unittest.mock import patch
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization
from fastapi.testclient import TestClient
from starlette.requests import Request

tmpdir = tempfile.TemporaryDirectory()
os.environ["AZAVAD_DEV_DB"] = str(Path(tmpdir.name) / "test.sqlite3")

from app.main import app, check_and_record_registration_attempt, connect_db, initialize_db, production_readiness_blockers
from app.security import hash_password


class ApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        initialize_db()
        with connect_db() as conn:
            conn.execute("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)", ("admin_test", hash_password("A-secure-test-password-123"), "admin"))

    def setUp(self):
        # Isolate per-client throttling state between tests; each test uses TestClient's same peer address.
        with connect_db() as conn:
            conn.execute("DELETE FROM auth_failures")
            conn.execute("DELETE FROM registration_attempts")
        self.context = TestClient(app)
        self.client = self.context.__enter__()

    def tearDown(self):
        self.context.__exit__(None, None, None)

    def register_and_login(self, username="test_user"):
        response = self.client.post("/v1/auth/register", json={"username": username, "password": "long-test-password-123"})
        self.assertEqual(response.status_code, 201, response.text)
        response = self.client.post("/v1/auth/login", json={"username": username, "password": "long-test-password-123"})
        self.assertEqual(response.status_code, 200, response.text)
        return {"Authorization": "Bearer " + response.json()["access_token"]}

    def test_backup_requires_explicit_owner_consent(self):
        headers = self.register_and_login("backup_no_consent")
        response = self.client.post("/v1/backups", headers=headers, json={"filename": "note.txt", "size_bytes": 4})
        self.assertEqual(response.status_code, 403, response.text)

    def test_encrypted_backup_upload_list_download_and_delete(self):
        headers = self.register_and_login("backup_owner")
        consent = self.client.post("/v1/consents", headers=headers, json={
            "feature": "backup", "policy_version": "1.0", "granted": True,
            "purpose": "backup", "owner_confirmed": True, "expires_in_days": 365,
        })
        self.assertEqual(consent.status_code, 201, consent.text)
        backup_root = Path(tmpdir.name) / "backup_objects_test"
        with patch("app.main.BACKUP_ROOT", backup_root), patch("app.main.BACKUP_CHUNK_BYTES", 8):
            payload = b"sensitive sample backup contents"
            created = self.client.post("/v1/backups", headers=headers, json={
                "filename": "notes.txt", "size_bytes": len(payload), "content_type": "text/plain",
            })
            self.assertEqual(created.status_code, 201, created.text)
            backup_id = created.json()["id"]
            missing = self.client.post(f"/v1/backups/{backup_id}/complete", headers=headers)
            self.assertEqual(missing.status_code, 409, missing.text)
            for index in range(4):
                chunk = payload[index * 8:(index + 1) * 8]
                uploaded = self.client.put(f"/v1/backups/{backup_id}/chunks/{index}", headers={**headers, "Content-Type": "application/octet-stream"}, content=chunk)
                self.assertEqual(uploaded.status_code, 200, uploaded.text)
                if index == 0:
                    status = self.client.get(f"/v1/backups/{backup_id}/status", headers=headers)
                    self.assertEqual(status.status_code, 200, status.text)
                    self.assertEqual([item["index"] for item in status.json()["uploaded_chunks"]], [0])
            encrypted_files = list(backup_root.glob("*.enc"))
            self.assertEqual(len(encrypted_files), 4)
            self.assertTrue(all(payload not in item.read_bytes() for item in encrypted_files))
            completed = self.client.post(f"/v1/backups/{backup_id}/complete", headers=headers)
            self.assertEqual(completed.status_code, 200, completed.text)
            listed = self.client.get("/v1/backups", headers=headers)
            self.assertEqual(listed.status_code, 200, listed.text)
            self.assertEqual(listed.json()["items"][0]["sha256"], __import__("hashlib").sha256(payload).hexdigest())
            downloaded = self.client.get(f"/v1/backups/{backup_id}/download", headers=headers)
            self.assertEqual(downloaded.status_code, 200, downloaded.text)
            self.assertEqual(downloaded.content, payload)
            deleted = self.client.delete(f"/v1/backups/{backup_id}", headers=headers)
            self.assertEqual(deleted.status_code, 204, deleted.text)
            self.assertEqual(self.client.get("/v1/backups", headers=headers).json()["items"], [])

    def test_backup_rejects_files_over_10_gb(self):
        headers = self.register_and_login("backup_too_large")
        self.client.post("/v1/consents", headers=headers, json={
            "feature": "backup", "policy_version": "1.0", "granted": True,
            "purpose": "backup", "owner_confirmed": True, "expires_in_days": 365,
        })
        response = self.client.post("/v1/backups", headers=headers, json={
            "filename": "too-large.bin", "size_bytes": 10_000_000_000 + 1,
        })
        self.assertEqual(response.status_code, 422, response.text)

    def test_notification_sync_requires_explicit_active_consent(self):
        headers = self.register_and_login("notification_no_consent")
        payload = {"items": [{"package": "com.example", "title": "Test", "text": "Private notice", "postedAt": 1760000000000}]}
        response = self.client.post("/v1/notification-events/sync", headers=headers, json=payload)
        self.assertEqual(response.status_code, 403, response.text)

    def test_notification_sync_is_deduplicated_owner_scoped_and_deletable(self):
        headers = self.register_and_login("notification_owner")
        other_headers = self.register_and_login("notification_other")
        consent = self.client.post("/v1/consents", headers=headers, json={
            "feature": "notifications", "policy_version": "1.0", "granted": True,
            "purpose": "device_monitoring", "owner_confirmed": True, "expires_in_days": 365,
        })
        self.assertEqual(consent.status_code, 201, consent.text)
        item = {"package": "com.example", "title": "Example", "text": "Sample body", "postedAt": 1760000000000}
        first = self.client.post("/v1/notification-events/sync", headers=headers, json={"items": [item]})
        self.assertEqual(first.status_code, 200, first.text)
        self.assertEqual(first.json()["inserted"], 1)
        duplicate = self.client.post("/v1/notification-events/sync", headers=headers, json={"items": [item]})
        self.assertEqual(duplicate.status_code, 200, duplicate.text)
        self.assertEqual(duplicate.json()["inserted"], 0)
        listed = self.client.get("/v1/notification-events", headers=headers)
        self.assertEqual(listed.status_code, 200, listed.text)
        self.assertEqual(listed.json()["count"], 1)
        self.assertEqual(listed.json()["items"][0]["text"], "Sample body")
        with connect_db() as conn:
            stored = conn.execute("SELECT encrypted_payload FROM notification_events WHERE user_id=(SELECT id FROM users WHERE username=?)", ("notification_owner",)).fetchone()
        self.assertIsNotNone(stored)
        self.assertNotIn(b"Sample body", bytes(stored["encrypted_payload"]))
        self.assertEqual(self.client.get("/v1/notification-events", headers=other_headers).status_code, 403)
        self.assertEqual(self.client.delete("/v1/notification-events", headers=headers).status_code, 204)
        self.assertEqual(self.client.get("/v1/notification-events", headers=headers).json()["count"], 0)

    def test_device_heartbeat_requires_consent_and_updates_admin_status(self):
        owner_headers = self.register_and_login("heartbeat_owner")
        registered = self.client.post("/v1/devices", headers=owner_headers, json={
            "device_key": "device-key-heartbeat-001", "display_name": "Heartbeat Android", "app_version": "0.2-test"
        })
        self.assertEqual(registered.status_code, 201, registered.text)
        device_id = registered.json()["id"]
        payload = {"battery_percent": 73, "charging": True, "network_connected": True,
                   "app_foreground": True, "android_version": "16", "app_version": "0.2-test"}
        denied = self.client.post(f"/v1/devices/{device_id}/heartbeat", headers=owner_headers, json=payload)
        self.assertEqual(denied.status_code, 403, denied.text)
        consent = self.client.post("/v1/consents", headers=owner_headers, json={
            "feature": "remote_panel", "policy_version": "2.0", "granted": True,
            "purpose": "device_monitoring", "owner_confirmed": True, "expires_in_days": 365,
        })
        self.assertEqual(consent.status_code, 201, consent.text)
        heartbeat = self.client.post(f"/v1/devices/{device_id}/heartbeat", headers=owner_headers, json=payload)
        self.assertEqual(heartbeat.status_code, 200, heartbeat.text)
        self.assertTrue(heartbeat.json()["ok"])
        admin_login = self.client.post("/v1/auth/login", json={"username": "admin_test", "password": "A-secure-test-password-123"})
        admin_headers = {"Authorization": "Bearer " + admin_login.json()["access_token"]}
        rows = self.client.get("/v1/admin/devices", headers=admin_headers)
        self.assertEqual(rows.status_code, 200, rows.text)
        device = next(item for item in rows.json() if item["id"] == device_id)
        self.assertEqual(device["battery_percent"], 73)
        self.assertTrue(device["charging"])
        self.assertTrue(device["network_connected"])
        self.assertTrue(device["app_foreground"])
        self.assertIsNotNone(device["heartbeat_at"])

    def test_device_status_is_owner_scoped_and_reports_unknown_until_heartbeat(self):
        owner_headers = self.register_and_login("status_owner")
        other_headers = self.register_and_login("status_other")
        registered = self.client.post("/v1/devices", headers=owner_headers, json={
            "device_key": "device-key-status-001", "display_name": "Status Android", "app_version": "0.3-test"
        })
        self.assertEqual(registered.status_code, 201, registered.text)
        device_id = registered.json()["id"]

        status = self.client.get(f"/v1/devices/{device_id}/status", headers=owner_headers)
        self.assertEqual(status.status_code, 200, status.text)
        self.assertEqual(status.json()["connection"]["state"], "online")
        self.assertFalse(status.json()["connection"]["heartbeat_received"])
        self.assertIsNone(status.json()["telemetry"])

        denied = self.client.get(f"/v1/devices/{device_id}/status", headers=other_headers)
        self.assertEqual(denied.status_code, 404, denied.text)

        admin_login = self.client.post("/v1/auth/login", json={
            "username": "admin_test", "password": "A-secure-test-password-123"
        })
        admin_headers = {"Authorization": "Bearer " + admin_login.json()["access_token"]}
        admin_status = self.client.get(f"/v1/admin/devices/{device_id}/status", headers=admin_headers)
        self.assertEqual(admin_status.status_code, 200, admin_status.text)
        self.assertEqual(admin_status.json()["device"]["id"], device_id)
        self.assertEqual(admin_status.json()["connection"]["state"], "online")

    def test_device_status_exposes_consent_effectiveness_and_running_commands(self):
        owner_headers = self.register_and_login("status_consent_owner")
        registered = self.client.post("/v1/devices", headers=owner_headers, json={
            "device_key": "device-key-status-consent-001", "display_name": "Status Consent Android", "app_version": "0.3-test"
        })
        self.assertEqual(registered.status_code, 201, registered.text)
        device_id = registered.json()["id"]
        consent = self.client.post("/v1/consents", headers=owner_headers, json={
            "feature": "remote_panel", "policy_version": "2.0", "granted": True,
            "purpose": "device_monitoring", "owner_confirmed": True, "expires_in_days": 365,
        })
        self.assertEqual(consent.status_code, 201, consent.text)
        status = self.client.get(f"/v1/devices/{device_id}/status", headers=owner_headers)
        self.assertEqual(status.status_code, 200, status.text)
        self.assertTrue(status.json()["consents"]["remote_panel"]["effective"])
        self.assertEqual(status.json()["active_commands"], [])

    def test_remote_command_queue_requires_unified_consent_and_owner_approval(self):
        owner_headers = self.register_and_login("remote_command_owner")
        registered = self.client.post("/v1/devices", headers=owner_headers, json={
            "device_key": "device-key-remote-001", "display_name": "Test Android", "app_version": "dev"
        })
        self.assertEqual(registered.status_code, 201, registered.text)
        device_id = registered.json()["id"]
        admin_login = self.client.post("/v1/auth/login", json={"username": "admin_test", "password": "A-secure-test-password-123"})
        self.assertEqual(admin_login.status_code, 200, admin_login.text)
        admin_headers = {"Authorization": "Bearer " + admin_login.json()["access_token"]}
        denied = self.client.post(f"/v1/admin/devices/{device_id}/commands", headers=admin_headers,
                                  json={"command_type": "camera_session_request"})
        self.assertEqual(denied.status_code, 403, denied.text)
        consent = self.client.post("/v1/consents", headers=owner_headers, json={
            "feature": "remote_panel", "policy_version": "2.0", "granted": True,
            "purpose": "device_monitoring", "owner_confirmed": True, "expires_in_days": 365,
        })
        self.assertEqual(consent.status_code, 201, consent.text)
        queued = self.client.post(f"/v1/admin/devices/{device_id}/commands", headers=admin_headers,
                                  json={"command_type": "camera_session_request", "expires_in_minutes": 10})
        self.assertEqual(queued.status_code, 201, queued.text)
        command_id = queued.json()["id"]
        self.assertTrue(queued.json()["requires_owner_confirmation"])
        polled = self.client.get(f"/v1/devices/{device_id}/commands/pending", headers=owner_headers)
        self.assertEqual(polled.status_code, 200, polled.text)
        self.assertEqual(polled.json()[0]["id"], command_id)
        premature = self.client.post(f"/v1/devices/{device_id}/commands/{command_id}/result", headers=owner_headers,
                                     json={"status": "running", "result_summary": ""})
        self.assertEqual(premature.status_code, 409, premature.text)
        accepted = self.client.post(f"/v1/devices/{device_id}/commands/{command_id}/result", headers=owner_headers,
                                   json={"status": "accepted", "result_summary": "Owner approved on device"})
        self.assertEqual(accepted.status_code, 200, accepted.text)
        running = self.client.post(f"/v1/devices/{device_id}/commands/{command_id}/result", headers=owner_headers,
                                   json={"status": "running", "result_summary": "Visible session started"})
        self.assertEqual(running.status_code, 200, running.text)
        self.assertEqual(running.json()["result_summary"], "Visible session started")
        admin_list = self.client.get("/v1/admin/commands", headers=admin_headers)
        self.assertEqual(admin_list.status_code, 200, admin_list.text)
        self.assertEqual(admin_list.json()[0]["status"], "running")
        self.assertEqual(admin_list.json()[0]["result_summary"], "Visible session started")
        revoked = self.client.post(f"/v1/consents/{consent.json()['id']}/revoke", headers=owner_headers)
        self.assertEqual(revoked.status_code, 200, revoked.text)
        # Server-side cancellation can invalidate queued prompts, but cannot claim to stop
        # an action already running on Android. That action must be stopped on-device.
        self.assertEqual(self.client.get("/v1/admin/commands", headers=admin_headers).json()[0]["status"], "running")
        revoked_poll = self.client.get(f"/v1/devices/{device_id}/commands/pending", headers=owner_headers)
        self.assertEqual(revoked_poll.status_code, 200, revoked_poll.text)
        self.assertEqual(revoked_poll.json(), [])  # after revocation, only stop signals are allowed; none exist for camera UI
        self.assertEqual(self.client.get(f"/v1/devices/{device_id}/commands/pending", headers=self.register_and_login("other_remote_user")).status_code, 404)

    def test_posting_remote_panel_consent_denial_cancels_active_requests(self):
        owner_headers = self.register_and_login("remote_command_deny")
        registered = self.client.post("/v1/devices", headers=owner_headers, json={
            "device_key": "device-key-remote-deny", "display_name": "Test Android", "app_version": "dev"
        })
        self.assertEqual(registered.status_code, 201, registered.text)
        admin_login = self.client.post("/v1/auth/login", json={"username": "admin_test", "password": "A-secure-test-password-123"})
        admin_headers = {"Authorization": "Bearer " + admin_login.json()["access_token"]}
        consent_payload = {"feature": "remote_panel", "policy_version": "2.0", "granted": True,
                           "purpose": "device_monitoring", "owner_confirmed": True, "expires_in_days": 365}
        self.assertEqual(self.client.post("/v1/consents", headers=owner_headers, json=consent_payload).status_code, 201)
        queued = self.client.post(f"/v1/admin/devices/{registered.json()['id']}/commands", headers=admin_headers,
                                  json={"command_type": "file_picker_request"})
        self.assertEqual(queued.status_code, 201, queued.text)
        denied = self.client.post("/v1/consents", headers=owner_headers, json={
            "feature": "remote_panel", "policy_version": "2.0", "granted": False,
            "purpose": "device_monitoring", "owner_confirmed": True,
        })
        self.assertEqual(denied.status_code, 201, denied.text)
        listed = self.client.get("/v1/admin/commands", headers=admin_headers)
        self.assertEqual(listed.json()[0]["status"], "cancelled")

    def test_revoking_feature_consent_cancels_matching_queued_request(self):
        owner_headers = self.register_and_login("camera_consent_revoke")
        registered = self.client.post("/v1/devices", headers=owner_headers, json={
            "device_key": "device-key-camera-revoke", "display_name": "Test Android", "app_version": "dev"
        })
        self.assertEqual(registered.status_code, 201, registered.text)
        device_id = registered.json()["id"]
        self.client.post("/v1/consents", headers=owner_headers, json={
            "feature": "remote_panel", "policy_version": "2.0", "granted": True,
            "purpose": "device_monitoring", "owner_confirmed": True, "expires_in_days": 365,
        })
        camera_consent = self.client.post("/v1/consents", headers=owner_headers, json={
            "feature": "camera", "policy_version": "1.0", "granted": True,
            "purpose": "emergency_safety", "owner_confirmed": True, "expires_in_days": 365,
        })
        self.assertEqual(camera_consent.status_code, 201, camera_consent.text)
        admin_login = self.client.post("/v1/auth/login", json={"username": "admin_test", "password": "A-secure-test-password-123"})
        admin_headers = {"Authorization": "Bearer " + admin_login.json()["access_token"]}
        queued = self.client.post(f"/v1/admin/devices/{device_id}/commands", headers=admin_headers,
                                  json={"command_type": "camera_session_request"})
        self.assertEqual(queued.status_code, 201, queued.text)
        revoked = self.client.post(f"/v1/consents/{camera_consent.json()['id']}/revoke", headers=owner_headers)
        self.assertEqual(revoked.status_code, 200, revoked.text)
        commands = self.client.get("/v1/admin/commands", headers=admin_headers).json()
        command = next(item for item in commands if item["id"] == queued.json()["id"])
        self.assertEqual(command["status"], "cancelled")
        self.assertIn("camera consent", command["result_summary"])

    def test_admin_can_cancel_active_remote_request_and_invalid_transitions_are_rejected(self):
        owner_headers = self.register_and_login("remote_command_cancel_owner")
        registered = self.client.post("/v1/devices", headers=owner_headers, json={
            "device_key": "device-key-remote-cancel", "display_name": "Test Android", "app_version": "dev"
        })
        self.assertEqual(registered.status_code, 201, registered.text)
        device_id = registered.json()["id"]
        self.client.post("/v1/consents", headers=owner_headers, json={
            "feature": "remote_panel", "policy_version": "2.0", "granted": True,
            "purpose": "device_monitoring", "owner_confirmed": True, "expires_in_days": 365,
        })
        admin_login = self.client.post("/v1/auth/login", json={"username": "admin_test", "password": "A-secure-test-password-123"})
        admin_headers = {"Authorization": "Bearer " + admin_login.json()["access_token"]}
        queued = self.client.post(f"/v1/admin/devices/{device_id}/commands", headers=admin_headers,
                                  json={"command_type": "camera_session_request"})
        self.assertEqual(queued.status_code, 201, queued.text)
        command_id = queued.json()["id"]
        # A sensitive command cannot skip the on-device approval state.
        invalid = self.client.post(f"/v1/devices/{device_id}/commands/{command_id}/result", headers=owner_headers,
                                   json={"status": "completed", "result_summary": "should not be accepted"})
        self.assertEqual(invalid.status_code, 409, invalid.text)
        cancelled = self.client.post(f"/v1/admin/commands/{command_id}/cancel", headers=admin_headers)
        self.assertEqual(cancelled.status_code, 200, cancelled.text)
        self.assertEqual(cancelled.json()["status"], "cancelled")
        self.assertEqual(cancelled.json()["result_summary"], "Cancelled by administrator")
        poll_after_cancel = self.client.get(f"/v1/devices/{device_id}/commands/pending", headers=owner_headers)
        self.assertEqual(poll_after_cancel.status_code, 200, poll_after_cancel.text)
        self.assertTrue(any(item["id"] == command_id and item["status"] == "cancelled" for item in poll_after_cancel.json()))
        after_cancel = self.client.post(f"/v1/devices/{device_id}/commands/{command_id}/result", headers=owner_headers,
                                        json={"status": "accepted", "result_summary": "late acceptance"})
        self.assertEqual(after_cancel.status_code, 409, after_cancel.text)
        repeated_cancel = self.client.post(f"/v1/admin/commands/{command_id}/cancel", headers=admin_headers)
        self.assertEqual(repeated_cancel.status_code, 409, repeated_cancel.text)


    def test_screen_frame_requires_active_consent_and_running_session(self):
        owner_headers = self.register_and_login("screen_frame_owner")
        registered = self.client.post("/v1/devices", headers=owner_headers, json={
            "device_key": "screen-frame-device-key", "display_name": "Screen Test Android", "app_version": "dev"
        })
        self.assertEqual(registered.status_code, 201, registered.text)
        device_id = registered.json()["id"]
        frame = b"\xff\xd8" + b"sample-jpeg-data" + b"\xff\xd9"
        denied = self.client.put(f"/v1/devices/{device_id}/screen-sessions/1/frame", headers={**owner_headers, "Content-Type": "image/jpeg"}, content=frame)
        self.assertEqual(denied.status_code, 403, denied.text)
        consent = self.client.post("/v1/consents", headers=owner_headers, json={
            "feature": "screen_share", "policy_version": "1.0", "granted": True,
            "purpose": "emergency_safety", "owner_confirmed": True, "expires_in_days": 365,
        })
        self.assertEqual(consent.status_code, 201, consent.text)
        remote_consent = self.client.post("/v1/consents", headers=owner_headers, json={
            "feature": "remote_panel", "policy_version": "2.0", "granted": True,
            "purpose": "device_monitoring", "owner_confirmed": True, "expires_in_days": 365,
        })
        self.assertEqual(remote_consent.status_code, 201, remote_consent.text)
        admin_login = self.client.post("/v1/auth/login", json={"username": "admin_test", "password": "A-secure-test-password-123"})
        admin_headers = {"Authorization": "Bearer " + admin_login.json()["access_token"]}
        queued = self.client.post(f"/v1/admin/devices/{device_id}/commands", headers=admin_headers, json={"command_type": "screen_share_request"})
        self.assertEqual(queued.status_code, 201, queued.text)
        command_id = queued.json()["id"]
        for status in ("accepted", "running"):
            result = self.client.post(f"/v1/devices/{device_id}/commands/{command_id}/result", headers=owner_headers, json={"status": status, "result_summary": "owner-approved test"})
            self.assertEqual(result.status_code, 200, result.text)
        uploaded = self.client.put(f"/v1/devices/{device_id}/screen-sessions/{command_id}/frame", headers={**owner_headers, "Content-Type": "image/jpeg"}, content=frame)
        self.assertEqual(uploaded.status_code, 200, uploaded.text)
        self.assertEqual(uploaded.json()["sha256"], __import__("hashlib").sha256(frame).hexdigest())
        view = self.client.get(f"/v1/admin/devices/{device_id}/screen-frame", headers=admin_headers)
        self.assertEqual(view.status_code, 200, view.text)
        self.assertEqual(view.content, frame)
        bad = self.client.put(f"/v1/devices/{device_id}/screen-sessions/{command_id}/frame", headers={**owner_headers, "Content-Type": "image/jpeg"}, content=b"not-jpeg")
        self.assertEqual(bad.status_code, 422, bad.text)
        self.client.post(f"/v1/admin/commands/{command_id}/cancel", headers=admin_headers)
        stopped = self.client.get(f"/v1/admin/devices/{device_id}/screen-frame", headers=admin_headers)
        self.assertEqual(stopped.status_code, 410, stopped.text)

    def test_running_monitoring_session_stop_is_signalled_and_remains_running_until_ack(self):
        owner_headers = self.register_and_login("remote_stop_owner")
        registered = self.client.post("/v1/devices", headers=owner_headers, json={
            "device_key": "device-key-remote-stop", "display_name": "Stop Test Android", "app_version": "dev"
        })
        self.assertEqual(registered.status_code, 201, registered.text)
        device_id = registered.json()["id"]
        consent = self.client.post("/v1/consents", headers=owner_headers, json={
            "feature": "remote_panel", "policy_version": "2.0", "granted": True,
            "purpose": "device_monitoring", "owner_confirmed": True, "expires_in_days": 365,
        })
        admin_login = self.client.post("/v1/auth/login", json={"username": "admin_test", "password": "A-secure-test-password-123"})
        admin_headers = {"Authorization": "Bearer " + admin_login.json()["access_token"]}
        queued = self.client.post(f"/v1/admin/devices/{device_id}/commands", headers=admin_headers,
                                  json={"command_type": "screen_share_request"})
        self.assertEqual(queued.status_code, 201, queued.text)
        command_id = queued.json()["id"]
        for status, summary in (("accepted", "Owner accepted system prompt"), ("running", "Visible session started")):
            response = self.client.post(f"/v1/devices/{device_id}/commands/{command_id}/result", headers=owner_headers,
                                        json={"status": status, "result_summary": summary})
            self.assertEqual(response.status_code, 200, response.text)
        stop = self.client.post(f"/v1/admin/commands/{command_id}/cancel", headers=admin_headers)
        self.assertEqual(stop.status_code, 200, stop.text)
        self.assertEqual(stop.json()["status"], "running")
        self.assertTrue(stop.json()["stop_requested"])
        self.assertIn("awaiting device acknowledgement", stop.json()["result_summary"])
        # Revoking umbrella consent must still allow the device to receive this stop signal,
        # while blocking every new/pending command.
        revoked = self.client.post(f"/v1/consents/{consent.json()['id']}/revoke", headers=owner_headers)
        self.assertEqual(revoked.status_code, 200, revoked.text)
        poll = self.client.get(f"/v1/devices/{device_id}/commands/pending", headers=owner_headers)
        self.assertEqual(poll.status_code, 200, poll.text)
        signal = next(item for item in poll.json() if item["id"] == command_id)
        self.assertTrue(signal["stop_requested"])
        self.assertEqual(signal["status"], "running")
        ack = self.client.post(f"/v1/devices/{device_id}/commands/{command_id}/result", headers=owner_headers,
                               json={"status": "completed", "result_summary": "Session stopped on device after stop signal"})
        self.assertEqual(ack.status_code, 200, ack.text)
        self.assertEqual(ack.json()["status"], "completed")

    def test_remote_command_rejects_arbitrary_command_types(self):
        owner_headers = self.register_and_login("remote_command_invalid")
        registered = self.client.post("/v1/devices", headers=owner_headers, json={
            "device_key": "device-key-remote-002", "display_name": "Test Android", "app_version": "dev"
        })
        admin_login = self.client.post("/v1/auth/login", json={"username": "admin_test", "password": "A-secure-test-password-123"})
        admin_headers = {"Authorization": "Bearer " + admin_login.json()["access_token"]}
        self.client.post("/v1/consents", headers=owner_headers, json={
            "feature": "remote_panel", "policy_version": "2.0", "granted": True,
            "purpose": "device_monitoring", "owner_confirmed": True, "expires_in_days": 365,
        })
        response = self.client.post(f"/v1/admin/devices/{registered.json()['id']}/commands", headers=admin_headers,
                                    json={"command_type": "shell_exec", "expires_in_minutes": 10})
        self.assertEqual(response.status_code, 422, response.text)

    def test_health(self):
        response = self.client.get("/health")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["status"], "ok")

    def test_production_readiness_gate_lists_unresolved_blockers(self):
        blockers = production_readiness_blockers()
        self.assertTrue(any("PostgreSQL" in blocker for blocker in blockers))
        self.assertTrue(any("MFA" in blocker for blocker in blockers))
        self.assertGreaterEqual(len(blockers), 5)

    def test_registration_login_me(self):
        headers = self.register_and_login()
        response = self.client.get("/v1/auth/me", headers=headers)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["username"], "test_user")
        self.assertEqual(response.json()["role"], "user")

    def test_duplicate_registration_rejected(self):
        self.assertEqual(self.client.post("/v1/auth/register", json={"username": "dupe_user", "password": "long-test-password-123"}).status_code, 201)
        self.assertEqual(self.client.post("/v1/auth/register", json={"username": "dupe_user", "password": "long-test-password-123"}).status_code, 409)

    def test_username_uniqueness_is_case_insensitive(self):
        first = self.client.post("/v1/auth/register", json={"username": "CaseUser", "password": "long-test-password-123"})
        second = self.client.post("/v1/auth/register", json={"username": "caseuser", "password": "long-test-password-123"})
        self.assertEqual(first.status_code, 201, first.text)
        self.assertEqual(second.status_code, 409, second.text)

    def test_registration_rate_limit_is_per_client_and_has_retry_after(self):
        for index in range(5):
            response = self.client.post("/v1/auth/register", json={
                "username": f"signup_user_{index}", "password": "long-test-password-123"})
            self.assertEqual(response.status_code, 201, f"attempt {index + 1}: {response.text}")
        blocked = self.client.post("/v1/auth/register", json={
            "username": "signup_user_blocked", "password": "long-test-password-123"})
        self.assertEqual(blocked.status_code, 429, blocked.text)
        self.assertEqual(blocked.headers.get("Retry-After"), "3600")
        with connect_db() as conn:
            rows = conn.execute("SELECT key_hash,attempts FROM registration_attempts").fetchall()
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["attempts"], 5)
        self.assertEqual(len(rows[0]["key_hash"]), 64)

    def test_registration_rate_limit_window_expires(self):
        request = Request({
            "type": "http", "http_version": "1.1", "method": "POST", "scheme": "http",
            "path": "/v1/auth/register", "raw_path": b"/v1/auth/register", "query_string": b"",
            "headers": [], "client": ("192.0.2.123", 12345), "server": ("testserver", 80),
        })
        now = datetime.now(timezone.utc)
        for _ in range(5):
            self.assertTrue(check_and_record_registration_attempt(request, now))
        self.assertFalse(check_and_record_registration_attempt(request, now))
        self.assertTrue(check_and_record_registration_attempt(request, now + timedelta(hours=1, seconds=1)))

    def test_login_rate_limit_after_repeated_failures(self):
        for attempt in range(10):
            response = self.client.post("/v1/auth/login", json={"username":"rate_limit_user", "password":"wrong-password"})
            self.assertEqual(response.status_code, 401, f"attempt {attempt + 1}: {response.text}")
        limited = self.client.post("/v1/auth/login", json={"username":"rate_limit_user", "password":"wrong-password"})
        self.assertEqual(limited.status_code, 429, limited.text)
        self.assertIn("Retry-After", limited.headers)
        with connect_db() as conn:
            rows = conn.execute("SELECT key_hash,failures FROM auth_failures WHERE failures>=10").fetchall()
        self.assertGreaterEqual(len(rows), 2)  # both per-username/IP and per-IP buckets
        self.assertTrue(all(len(row["key_hash"]) == 64 for row in rows))

    def test_login_limit_cannot_be_bypassed_by_changing_usernames(self):
        for index in range(10):
            response = self.client.post("/v1/auth/login", json={"username":f"missing_user_{index}", "password":"wrong-password"})
            self.assertEqual(response.status_code, 401, f"attempt {index + 1}: {response.text}")
        blocked = self.client.post("/v1/auth/login", json={"username":"another_missing_user", "password":"wrong-password"})
        self.assertEqual(blocked.status_code, 429, blocked.text)

    def test_successful_login_clears_prior_failures(self):
        self.assertEqual(self.client.post("/v1/auth/register", json={"username":"clear_limit_user", "password":"long-test-password-123"}).status_code, 201)
        with connect_db() as conn:
            before = conn.execute("SELECT COUNT(*) FROM auth_failures").fetchone()[0]
        self.assertEqual(self.client.post("/v1/auth/login", json={"username":"clear_limit_user", "password":"wrong-password"}).status_code, 401)
        with connect_db() as conn:
            after_failure = conn.execute("SELECT COUNT(*) FROM auth_failures").fetchone()[0]
        self.assertEqual(after_failure, before + 2)
        success = self.client.post("/v1/auth/login", json={"username":"clear_limit_user", "password":"long-test-password-123"})
        self.assertEqual(success.status_code, 200, success.text)
        self.assertIsNotNone(success.json().get("access_token"))
        with connect_db() as conn:
            after_success = conn.execute("SELECT COUNT(*) FROM auth_failures").fetchone()[0]
        self.assertEqual(after_success, after_failure - 1)  # user bucket cleared; IP bucket remains

    def test_protected_route_and_logout_revocation(self):
        self.assertEqual(self.client.get("/v1/consents").status_code, 401)
        headers = self.register_and_login("logout_user")
        self.assertEqual(self.client.post("/v1/auth/logout", headers=headers).status_code, 204)
        self.assertEqual(self.client.get("/v1/auth/me", headers=headers).status_code, 401)

    def test_session_token_is_not_stored_in_plaintext_and_logout_all_revokes(self):
        headers = self.register_and_login("session_owner")
        token = headers["Authorization"].split(" ", 1)[1]
        with connect_db() as conn:
            row = conn.execute("SELECT token_hash FROM sessions WHERE user_id=(SELECT id FROM users WHERE username='session_owner')").fetchone()
        self.assertNotEqual(row["token_hash"], token)
        self.assertEqual(len(row["token_hash"]), 64)
        self.assertEqual(self.client.post("/v1/auth/logout-all", headers=headers).status_code, 204)
        self.assertEqual(self.client.get("/v1/auth/me", headers=headers).status_code, 401)

    def test_account_export_and_confirmed_deletion(self):
        headers = self.register_and_login("privacy_user")
        consent = self.client.post("/v1/consents", headers=headers, json={"feature":"offline_library", "policy_version":"1.0", "granted":True})
        self.assertEqual(consent.status_code, 201)
        exported = self.client.get("/v1/account/export", headers=headers)
        self.assertEqual(exported.status_code, 200, exported.text)
        self.assertEqual(exported.json()["account"]["username"], "privacy_user")
        self.assertEqual(len(exported.json()["consents"]), 1)
        self.assertNotIn("password_hash", exported.text)
        self.assertNotIn("access_token", exported.text)
        missing_confirmation = self.client.request("DELETE", "/v1/account", headers=headers, json={"password":"long-test-password-123", "confirm":False})
        self.assertEqual(missing_confirmation.status_code, 400)
        wrong_password = self.client.request("DELETE", "/v1/account", headers=headers, json={"password":"incorrect-password", "confirm":True})
        self.assertEqual(wrong_password.status_code, 401)
        deleted = self.client.request("DELETE", "/v1/account", headers=headers, json={"password":"long-test-password-123", "confirm":True})
        self.assertEqual(deleted.status_code, 204, deleted.text)
        self.assertEqual(self.client.get("/v1/auth/me", headers=headers).status_code, 401)
        with connect_db() as conn:
            self.assertIsNone(conn.execute("SELECT id FROM users WHERE username='privacy_user'").fetchone())
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM consent_records WHERE user_id=(SELECT id FROM users WHERE username='privacy_user')").fetchone()[0], 0)
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM audit_events WHERE action='account.delete'").fetchone()[0], 1)

    def test_user_can_only_read_own_consent_and_devices(self):
        h1 = self.register_and_login("owner_user")
        h2 = self.register_and_login("other_user")
        created = self.client.post("/v1/consents", headers=h1, json={"feature":"offline_library", "policy_version":"1.0", "granted":True})
        self.assertEqual(created.status_code, 201)
        self.assertEqual(len(self.client.get("/v1/consents", headers=h1).json()), 1)
        self.assertEqual(self.client.get("/v1/consents", headers=h2).json(), [])
        device = self.client.post("/v1/devices", headers=h1, json={"device_key":"device-key-123", "display_name":"My phone", "app_version":"0.2.0"})
        self.assertEqual(device.status_code, 201)
        device_id = device.json()["id"]
        self.assertEqual(self.client.delete(f"/v1/devices/{device_id}", headers=h2).status_code, 404)
        self.assertEqual(len(self.client.get("/v1/devices", headers=h1).json()), 1)

    def test_admin_device_inventory_lists_only_metadata(self):
        headers = self.register_and_login("device_inventory_owner")
        created = self.client.post("/v1/devices", headers=headers, json={
            "device_key": "device-key-123456", "display_name": "Android Test", "app_version": "0.2.0-dev",
        })
        self.assertEqual(created.status_code, 201, created.text)
        denied = self.client.get("/v1/admin/devices", headers=headers)
        self.assertEqual(denied.status_code, 403)
        admin_login = self.client.post("/v1/auth/login", json={"username": "admin_test", "password": "A-secure-test-password-123"})
        self.assertEqual(admin_login.status_code, 200, admin_login.text)
        admin_headers = {"Authorization": "Bearer " + admin_login.json()["access_token"]}
        response = self.client.get("/v1/admin/devices", headers=admin_headers)
        self.assertEqual(response.status_code, 200, response.text)
        row = next(item for item in response.json() if item["device_key"] == "device-key-123456")
        self.assertEqual(row["username"], "device_inventory_owner")
        self.assertNotIn("notification", row)
        self.assertNotIn("file", row)

    def test_admin_route_rejects_regular_user(self):
        headers = self.register_and_login("regular_user")
        self.assertEqual(self.client.get("/v1/admin/users", headers=headers).status_code, 403)
        admin_login = self.client.post("/v1/auth/login", json={"username":"admin_test", "password":"A-secure-test-password-123"})
        self.assertEqual(admin_login.status_code, 200)
        admin_headers = {"Authorization":"Bearer " + admin_login.json()["access_token"]}
        self.assertEqual(self.client.get("/v1/admin/users", headers=admin_headers).status_code, 200)

    def test_invalid_feature_rejected(self):
        headers = self.register_and_login("validation_user")
        response = self.client.post("/v1/consents", headers=headers, json={"feature":"not allowed!", "policy_version":"1.0", "granted":True})
        self.assertEqual(response.status_code, 422)

    def test_sensitive_capability_consent_requires_owner_confirmation_and_emergency_purpose(self):
        headers = self.register_and_login("sensitive_consent_user")
        base = {"feature":"camera", "policy_version":"1.0", "granted":True,
                "purpose":"emergency_safety", "expires_in_hours":24}
        missing_confirmation = self.client.post("/v1/consents", headers=headers, json=base)
        self.assertEqual(missing_confirmation.status_code, 422, missing_confirmation.text)
        wrong_purpose = self.client.post("/v1/consents", headers=headers,
            json={**base, "owner_confirmed":True, "purpose":"standard"})
        self.assertEqual(wrong_purpose.status_code, 422, wrong_purpose.text)
        accepted = self.client.post("/v1/consents", headers=headers,
            json={**base, "owner_confirmed":True})
        self.assertEqual(accepted.status_code, 201, accepted.text)
        body = accepted.json()
        self.assertTrue(body["owner_confirmed"])
        self.assertTrue(body["expires_at"])
        self.assertEqual(body["purpose"], "emergency_safety")
        self.assertEqual([c["feature"] for c in self.client.get("/v1/consents/effective", headers=headers).json()], ["camera"])

    def test_sensitive_consent_defaults_to_one_year_and_can_be_revoked(self):
        headers = self.register_and_login("annual_consent_user")
        before = datetime.now(timezone.utc)
        response = self.client.post("/v1/consents", headers=headers, json={
            "feature":"file_access", "policy_version":"1.0", "granted":True,
            "purpose":"emergency_safety", "owner_confirmed":True})
        self.assertEqual(response.status_code, 201, response.text)
        body = response.json()
        expires_at = datetime.fromisoformat(body["expires_at"])
        remaining = expires_at - before
        self.assertGreater(remaining, timedelta(days=364, hours=23))
        self.assertLessEqual(remaining, timedelta(days=365, seconds=2))
        self.assertEqual([item["feature"] for item in self.client.get("/v1/consents/effective", headers=headers).json()], ["file_access"])
        revoked = self.client.post(f"/v1/consents/{body['id']}/revoke", headers=headers)
        self.assertEqual(revoked.status_code, 200, revoked.text)
        self.assertEqual(self.client.get("/v1/consents/effective", headers=headers).json(), [])

    def test_sensitive_consent_rejects_conflicting_duration_fields(self):
        headers = self.register_and_login("duration_conflict_user")
        response = self.client.post("/v1/consents", headers=headers, json={
            "feature":"camera", "policy_version":"1.0", "granted":True,
            "purpose":"emergency_safety", "owner_confirmed":True,
            "expires_in_days":30, "expires_in_hours":48})
        self.assertEqual(response.status_code, 422, response.text)

    def test_sensitive_consent_can_be_revoked_and_is_owner_scoped(self):
        owner = self.register_and_login("consent_revoke_owner")
        other = self.register_and_login("consent_revoke_other")
        response = self.client.post("/v1/consents", headers=owner, json={
            "feature":"microphone", "policy_version":"1.0", "granted":True,
            "purpose":"emergency_safety", "expires_in_hours":48, "owner_confirmed":True})
        self.assertEqual(response.status_code, 201, response.text)
        consent_id = response.json()["id"]
        self.assertEqual(self.client.post(f"/v1/consents/{consent_id}/revoke", headers=other).status_code, 404)
        revoked = self.client.post(f"/v1/consents/{consent_id}/revoke", headers=owner)
        self.assertEqual(revoked.status_code, 200, revoked.text)
        self.assertFalse(revoked.json()["granted"])
        self.assertEqual(self.client.get("/v1/consents/effective", headers=owner).json(), [])
        self.assertEqual(self.client.post(f"/v1/consents/{consent_id}/revoke", headers=owner).status_code, 409)

    def test_admin_can_create_and_disable_non_admin_user(self):
        admin_login = self.client.post("/v1/auth/login", json={"username":"admin_test", "password":"A-secure-test-password-123"})
        admin_headers = {"Authorization":"Bearer " + admin_login.json()["access_token"]}
        created = self.client.post("/v1/admin/users", headers=admin_headers, json={"username":"managed_user", "password":"long-test-password-123", "role":"user"})
        self.assertEqual(created.status_code, 201, created.text)
        user_id = created.json()["id"]
        user_headers = self.register_and_login("managed_session_user")
        session_user_id = self.client.get("/v1/auth/me", headers=user_headers).json()["id"]
        disabled_session_user = self.client.patch(f"/v1/admin/users/{session_user_id}", headers=admin_headers, json={"disabled":True})
        self.assertEqual(disabled_session_user.status_code, 200, disabled_session_user.text)
        self.assertEqual(self.client.get("/v1/auth/me", headers=user_headers).status_code, 401)
        disabled = self.client.patch(f"/v1/admin/users/{user_id}", headers=admin_headers, json={"disabled":True})
        self.assertEqual(disabled.status_code, 200, disabled.text)
        self.assertTrue(disabled.json()["disabled"])
        login = self.client.post("/v1/auth/login", json={"username":"managed_user", "password":"long-test-password-123"})
        self.assertEqual(login.status_code, 401)

    def test_admin_cannot_disable_own_account(self):
        admin_login = self.client.post("/v1/auth/login", json={"username":"admin_test", "password":"A-secure-test-password-123"})
        admin_headers = {"Authorization":"Bearer " + admin_login.json()["access_token"]}
        admin_id = self.client.get("/v1/auth/me", headers=admin_headers).json()["id"]
        response = self.client.patch(f"/v1/admin/users/{admin_id}", headers=admin_headers, json={"disabled":True})
        self.assertEqual(response.status_code, 409, response.text)
        self.assertEqual(self.client.get("/v1/auth/me", headers=admin_headers).status_code, 200)


    def test_security_event_rules_and_admin_resolution(self):
        user_headers = self.register_and_login("event_owner")
        event = self.client.post("/v1/events", headers=user_headers, json={"event_type":"component_integrity_mismatch"})
        self.assertEqual(event.status_code, 201, event.text)
        self.assertEqual(event.json()["severity"], "high")
        self.assertEqual(event.json()["confidence"], "low")
        self.assertIn("inaccurate", event.json()["description"])
        self.assertEqual(len(self.client.get("/v1/events", headers=user_headers).json()), 1)
        admin_login = self.client.post("/v1/auth/login", json={"username":"admin_test", "password":"A-secure-test-password-123"})
        admin_headers = {"Authorization":"Bearer " + admin_login.json()["access_token"]}
        listed = self.client.get("/v1/admin/events", headers=admin_headers)
        self.assertEqual(listed.status_code, 200)
        self.assertEqual(len(listed.json()), 1)
        event_id = event.json()["id"]
        self.assertEqual(self.client.post(f"/v1/admin/events/{event_id}/resolve", headers=admin_headers).status_code, 204)
        self.assertEqual(self.client.post(f"/v1/admin/events/{event_id}/resolve", headers=admin_headers).status_code, 409)

    def _library_payload(self, slug="heat-safety-basics"):
        return {
            "slug": slug,
            "title": "Heat safety basics",
            "category": "environment",
            "summary": "Recognize and reduce heat-related risks.",
            "body": "Move to a cooler place and seek professional help for severe symptoms.",
            "source_url": "https://www.who.int/health-topics/heatwaves",
            "verified_at": "2026-10-28",
        }

    def test_library_draft_hidden_and_unsigned_publish_refused(self):
        admin_login = self.client.post("/v1/auth/login", json={"username":"admin_test", "password":"A-secure-test-password-123"})
        admin_headers = {"Authorization":"Bearer " + admin_login.json()["access_token"]}
        created = self.client.post("/v1/admin/library", headers=admin_headers, json=self._library_payload())
        self.assertEqual(created.status_code, 201, created.text)
        item_id = created.json()["id"]
        self.assertEqual(self.client.get("/v1/library").json(), [])
        unsigned = self.client.post(f"/v1/admin/library/{item_id}/publish", headers=admin_headers)
        self.assertEqual(unsigned.status_code, 503, unsigned.text)
        self.assertEqual(self.client.get("/v1/library/heat-safety-basics").status_code, 404)

    def test_library_published_payload_has_valid_ed25519_signature_and_immutable_version(self):
        private_key = Ed25519PrivateKey.generate()
        raw_private = private_key.private_bytes(encoding=serialization.Encoding.Raw, format=serialization.PrivateFormat.Raw, encryption_algorithm=serialization.NoEncryption())
        encoded_private = base64.b64encode(raw_private).decode("ascii")
        admin_login = self.client.post("/v1/auth/login", json={"username":"admin_test", "password":"A-secure-test-password-123"})
        admin_headers = {"Authorization":"Bearer " + admin_login.json()["access_token"]}
        with patch.dict(os.environ, {"AZAVAD_LIBRARY_SIGNING_PRIVATE_KEY_B64": encoded_private}):
            created = self.client.post("/v1/admin/library", headers=admin_headers, json=self._library_payload("signed-heat-safety-basics"))
            self.assertEqual(created.status_code, 201, created.text)
            item_id = created.json()["id"]
            published = self.client.post(f"/v1/admin/library/{item_id}/publish", headers=admin_headers)
            self.assertEqual(published.status_code, 200, published.text)
            public_key_response = self.client.get("/v1/library/signing-key")
            self.assertEqual(public_key_response.status_code, 200, public_key_response.text)
            public_key_raw = base64.b64decode(public_key_response.json()["public_key_b64"])
            public_key = Ed25519PrivateKey.from_private_bytes(raw_private).public_key()
            expected_public_raw = public_key.public_bytes(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw)
            self.assertEqual(public_key_raw, expected_public_raw)
            payload_fields = {key: published.json()[key] for key in ("schema_version","slug","title","category","summary","body","source_url","verified_at","version")}
            canonical = __import__("json").dumps(payload_fields, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
            public_key.verify(base64.b64decode(published.json()["signature"]), canonical)
            self.assertEqual(published.json()["content_sha256"], __import__("hashlib").sha256(canonical).hexdigest())
            first_version = self.client.get("/v1/library/signed-heat-safety-basics").json()
            self.assertEqual(first_version["version"], 1)
            changed = self.client.patch(f"/v1/admin/library/{item_id}", headers=admin_headers, json={"summary":"Updated summary after review."})
            self.assertEqual(changed.status_code, 200, changed.text)
            # Editing a draft must not mutate the previously published public version.
            still_published = self.client.get("/v1/library/signed-heat-safety-basics").json()
            self.assertEqual(still_published["summary"], first_version["summary"])
            republished = self.client.post(f"/v1/admin/library/{item_id}/publish", headers=admin_headers)
            self.assertEqual(republished.status_code, 200, republished.text)
            self.assertEqual(republished.json()["version"], 2)
            self.assertEqual(self.client.get("/v1/library/signed-heat-safety-basics").json()["summary"], "Updated summary after review.")

    def test_library_signing_misconfiguration_fails_closed(self):
        with patch.dict(os.environ, {"AZAVAD_LIBRARY_SIGNING_PRIVATE_KEY_B64": "not-a-valid-key"}, clear=False):
            response = self.client.get("/v1/library/signing-key")
        self.assertEqual(response.status_code, 503, response.text)
        self.assertIn("configuration is invalid", response.json()["detail"])

    def test_library_patch_rejects_explicit_null_fields(self):
        admin_login = self.client.post("/v1/auth/login", json={"username":"admin_test", "password":"A-secure-test-password-123"})
        admin_headers = {"Authorization":"Bearer " + admin_login.json()["access_token"]}
        created = self.client.post("/v1/admin/library", headers=admin_headers, json=self._library_payload("null-field-check"))
        self.assertEqual(created.status_code, 201, created.text)
        response = self.client.patch(f"/v1/admin/library/{created.json()['id']}", headers=admin_headers, json={"summary":None})
        self.assertEqual(response.status_code, 422, response.text)

    def test_library_rejects_non_admin_and_untrusted_sources(self):
        user_headers = self.register_and_login("library_regular_user")
        self.assertEqual(self.client.get("/v1/admin/library", headers=user_headers).status_code, 403)
        admin_login = self.client.post("/v1/auth/login", json={"username":"admin_test", "password":"A-secure-test-password-123"})
        admin_headers = {"Authorization":"Bearer " + admin_login.json()["access_token"]}
        bad = self._library_payload("unsafe-source-item")
        bad["source_url"] = "http://example.com/article"
        response = self.client.post("/v1/admin/library", headers=admin_headers, json=bad)
        self.assertEqual(response.status_code, 422, response.text)
        bad = self._library_payload("invalid-category-item")
        bad["category"] = "weapons"
        response = self.client.post("/v1/admin/library", headers=admin_headers, json=bad)
        self.assertEqual(response.status_code, 422, response.text)

    def test_audit_chain_detects_tampering(self):
        admin_login = self.client.post("/v1/auth/login", json={"username":"admin_test", "password":"A-secure-test-password-123"})
        admin_headers = {"Authorization":"Bearer " + admin_login.json()["access_token"]}
        valid = self.client.get("/v1/admin/audit/integrity", headers=admin_headers)
        self.assertEqual(valid.status_code, 200, valid.text)
        self.assertTrue(valid.json()["valid"], valid.text)
        with connect_db() as conn:
            target_id = conn.execute("SELECT id FROM audit_events ORDER BY id DESC LIMIT 1").fetchone()["id"]
            conn.execute("UPDATE audit_events SET action='tampered_action' WHERE id=?", (target_id,))
        tampered = self.client.get("/v1/admin/audit/integrity", headers=admin_headers)
        self.assertEqual(tampered.status_code, 200, tampered.text)
        self.assertFalse(tampered.json()["valid"], tampered.text)
        self.assertEqual(tampered.json()["first_invalid_id"], target_id)
        self.assertEqual(self.client.get("/v1/admin/audit/integrity").status_code, 401)

    def test_admin_console_is_served_with_security_headers(self):
        response = self.client.get("/admin/")
        self.assertEqual(response.status_code, 200)
        self.assertIn("АЗАВАД", response.text)
        self.assertEqual(response.headers.get("X-Content-Type-Options"), "nosniff")
        self.assertEqual(response.headers.get("X-Frame-Options"), "DENY")
        self.assertIn("default-src 'self'", response.headers.get("Content-Security-Policy", ""))
        self.assertIn("camera=()", response.headers.get("Permissions-Policy", ""))


def tearDownModule():
    tmpdir.cleanup()


if __name__ == "__main__":
    unittest.main()
