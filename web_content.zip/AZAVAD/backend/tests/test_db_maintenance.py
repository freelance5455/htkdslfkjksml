import os
from pathlib import Path
import sqlite3
from contextlib import contextmanager
import tempfile
import unittest

from scripts.db_maintenance import backup, restore, verify_sqlite


@contextmanager
def open_db(path):
    connection = sqlite3.connect(path)
    try:
        yield connection
        connection.commit()
    finally:
        connection.close()


class DatabaseMaintenanceTests(unittest.TestCase):
    def setUp(self):
        self.tempdir = tempfile.TemporaryDirectory()
        self.root = Path(self.tempdir.name)
        self.source = self.root / "source.sqlite3"
        with open_db(self.source) as db:
            db.execute("PRAGMA foreign_keys=ON")
            db.executescript("CREATE TABLE users(id INTEGER PRIMARY KEY, username TEXT UNIQUE); CREATE TABLE notes(id INTEGER PRIMARY KEY, user_id INTEGER REFERENCES users(id), body TEXT);")
            db.execute("INSERT INTO users(username) VALUES('alpha')")
            db.execute("INSERT INTO notes(user_id, body) VALUES(1, 'sensitive record')")

    def tearDown(self):
        self.tempdir.cleanup()

    def test_backup_and_restore_round_trip(self):
        backup_path = self.root / "backups" / "snapshot.sqlite3"
        digest = backup(self.source, backup_path)
        self.assertEqual(len(digest), 64)
        self.assertEqual(backup_path.stat().st_mode & 0o777, 0o600)
        destination = self.root / "restored.sqlite3"
        restore(backup_path, destination)
        verify_sqlite(destination)
        with open_db(destination) as db:
            self.assertEqual(db.execute("SELECT body FROM notes").fetchone()[0], "sensitive record")
            self.assertEqual(db.execute("PRAGMA foreign_key_check").fetchall(), [])

    def test_backup_refuses_overwrite(self):
        backup_path = self.root / "snapshot.sqlite3"
        backup(self.source, backup_path)
        with self.assertRaises(FileExistsError):
            backup(self.source, backup_path)

    def test_restore_requires_explicit_force_for_existing_destination(self):
        backup_path = self.root / "snapshot.sqlite3"
        backup(self.source, backup_path)
        destination = self.root / "destination.sqlite3"
        with open_db(destination) as db:
            db.execute("CREATE TABLE sentinel(value TEXT)")
        with self.assertRaises(FileExistsError):
            restore(backup_path, destination)
        restore(backup_path, destination, force=True)
        with open_db(destination) as db:
            self.assertEqual(db.execute("SELECT username FROM users").fetchone()[0], "alpha")

    def test_tampered_backup_is_rejected_without_changing_destination(self):
        backup_path = self.root / "snapshot.sqlite3"
        backup(self.source, backup_path)
        with backup_path.open("ab") as stream:
            stream.write(b"tamper")
        destination = self.root / "destination.sqlite3"
        with open_db(destination) as db:
            db.execute("CREATE TABLE sentinel(value TEXT)")
            db.execute("INSERT INTO sentinel VALUES('preserve')")
        with self.assertRaisesRegex(ValueError, "checksum mismatch"):
            restore(backup_path, destination, force=True)
        with open_db(destination) as db:
            self.assertEqual(db.execute("SELECT value FROM sentinel").fetchone()[0], "preserve")

    def test_restore_rejects_backup_without_checksum(self):
        backup_path = self.root / "orphan.sqlite3"
        backup(self.source, backup_path)
        backup_path.with_suffix(backup_path.suffix + ".sha256").unlink()
        with self.assertRaisesRegex(ValueError, "checksum file is missing"):
            restore(backup_path, self.root / "target.sqlite3")


if __name__ == "__main__":
    unittest.main()
