# AZAVAD backend (development)

Requires Python 3.11+.

```bash
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell: .venv\\Scripts\\Activate.ps1
pip install -r requirements.txt
pip install httpx  # test client
python -m app.bootstrap_admin  # optional; creates first admin interactively
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Run tests: `python -m unittest discover -s tests -v`.

API docs: `http://127.0.0.1:8000/docs`. Health: `/health` (process-only).

## Implemented development endpoints
- `POST /v1/auth/register` — creates a regular user; passwords require at least 12 characters.
- `POST /v1/auth/login` — issues a random opaque bearer token, storing only its SHA-256 digest.
- `GET /v1/auth/me`, `POST /v1/auth/logout`, `POST /v1/auth/logout-all`.
- `GET /v1/admin/users` and `GET /v1/admin/audit` — administrator-only.
- `POST/GET /v1/consents` — scoped to the authenticated account.
- `POST/GET /v1/devices`, `DELETE /v1/devices/{id}` — account-scoped device registry.
- `GET /v1/audit` — current user's audit entries.

The initial administrator is created via the interactive bootstrap command; there is no embedded default admin password.

## Important deployment limits
This is an engineering scaffold, not a production deployment. Before exposing it to a network, add a reviewed identity strategy, distributed login/registration rate limiting, MFA for privileged accounts, PostgreSQL + migrations, CSRF/CORS policy appropriate to the deployed clients, TLS, centralized secret management, session lifecycle policy, structured security monitoring, backup/restore drills, dependency scanning, and independent security testing. The current SQLite schema is initialized at startup and is not yet migration-managed. Do not use the development server as a public endpoint.

## Encrypted server backups (development scaffold)

- `POST /v1/consents` with `feature=backup`, `granted=true`, `purpose=backup`, and `owner_confirmed=true` records explicit owner approval for server backup. The app sends this only when the owner toggles the backup-consent control.
- `POST /v1/backups` reserves a backup object up to 10 GB; `PUT /v1/backups/{id}/chunks/{index}` uploads bounded 8 MiB chunks; `POST /v1/backups/{id}/complete` verifies all chunks and final SHA-256.
- `GET /v1/backups` lists the authenticated owner's completed copies; `GET /v1/backups/{id}/download` streams a copy for restore; `DELETE /v1/backups/{id}` deletes it.
- Each chunk is encrypted at rest with AES-256-GCM and authenticated associated data. HTTPS is required by the Android client. The development fallback key is intentionally non-production and must never protect real user data.
- Before any non-development deployment, generate a random 32-byte key and set it in the secret manager as URL-safe base64 `AZAVAD_BACKUP_ENCRYPTION_KEY`. Example generation command: `python -c "import secrets,base64; print(base64.urlsafe_b64encode(secrets.token_bytes(32)).decode().rstrip('='))"`. Keep the key separate from the backup volume and preserve it securely; losing it makes encrypted backups unrecoverable. Rotating it requires a planned re-encryption migration.
- `AZAVAD_BACKUP_DIR` must point to persistent storage; `AZAVAD_BACKUP_QUOTA_BYTES` sets per-account quota (default 50 GiB). Ensure the volume has sufficient free space and operational monitoring. Local encrypted chunks are not off-host disaster recovery; production still needs independent encrypted off-site copies and restore drills.
- Revoking backup consent blocks new uploads and continuation, but does not block the owner from listing, downloading, or deleting copies already stored. Deleting the account removes its backup chunks and metadata.
- Incomplete uploads are cleaned up by the Android client when a transfer fails; operators should periodically reconcile orphaned encrypted chunk files after crashes.
