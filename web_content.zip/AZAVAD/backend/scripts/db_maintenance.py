#!/usr/bin/env python3
"""Create and restore verified SQLite backups for AZAVAD development deployments.

Backups contain sensitive account data. Keep them in an access-controlled location.
This utility is not a substitute for encrypted off-host production backups.
"""
from __future__ import annotations

import argparse
import hashlib
import hmac
import os
from pathlib import Path
import sqlite3
import sys
import tempfile
from contextlib import closing


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify_sqlite(path: Path) -> None:
    try:
        with closing(sqlite3.connect(f"file:{path.resolve()}?mode=ro", uri=True)) as db:
            integrity = db.execute("PRAGMA integrity_check").fetchone()
            if not integrity or integrity[0] != "ok":
                raise ValueError("SQLite integrity_check failed")
            foreign_key_errors = db.execute("PRAGMA foreign_key_check").fetchall()
            if foreign_key_errors:
                raise ValueError("SQLite foreign_key_check failed")
            # Force a read of schema metadata to reject arbitrary non-database files.
            db.execute("SELECT name FROM sqlite_master LIMIT 1").fetchone()
    except (sqlite3.DatabaseError, OSError) as exc:
        raise ValueError("File is not a readable, valid SQLite database") from exc


def backup(source: Path, destination: Path) -> str:
    source = source.resolve()
    destination = destination.resolve()
    if not source.is_file():
        raise ValueError("Source database does not exist")
    if source == destination:
        raise ValueError("Backup destination must differ from source database")
    if destination.exists() or destination.with_suffix(destination.suffix + ".sha256").exists():
        raise FileExistsError("Backup destination or checksum already exists; choose a new path")
    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=f".{destination.name}.", suffix=".tmp", dir=destination.parent)
    os.close(fd)
    temporary = Path(temp_name)
    try:
        with closing(sqlite3.connect(f"file:{source}?mode=ro", uri=True)) as src, closing(sqlite3.connect(temporary)) as dst:
            src.backup(dst)
        os.chmod(temporary, 0o600)
        verify_sqlite(temporary)
        digest = sha256_file(temporary)
        os.replace(temporary, destination)
        checksum_path = destination.with_suffix(destination.suffix + ".sha256")
        checksum_tmp = checksum_path.with_suffix(checksum_path.suffix + ".tmp")
        checksum_tmp.write_text(f"{digest}  {destination.name}\n", encoding="ascii")
        os.chmod(checksum_tmp, 0o600)
        os.replace(checksum_tmp, checksum_path)
        return digest
    finally:
        temporary.unlink(missing_ok=True)


def restore(backup_path: Path, destination: Path, force: bool = False) -> str:
    backup_path = backup_path.resolve()
    destination = destination.resolve()
    checksum_path = backup_path.with_suffix(backup_path.suffix + ".sha256")
    if not backup_path.is_file() or not checksum_path.is_file():
        raise ValueError("Backup or its .sha256 checksum file is missing")
    expected = checksum_path.read_text(encoding="ascii").split()[0]
    actual = sha256_file(backup_path)
    if len(expected) != 64 or not hmac.compare_digest(expected, actual):
        raise ValueError("Backup checksum mismatch")
    verify_sqlite(backup_path)
    if backup_path == destination:
        raise ValueError("Restore source and destination must differ")
    if destination.exists() and not force:
        raise FileExistsError("Destination exists; pass --force to replace it")
    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=f".{destination.name}.", suffix=".restore.tmp", dir=destination.parent)
    os.close(fd)
    temporary = Path(temp_name)
    try:
        with closing(sqlite3.connect(f"file:{backup_path}?mode=ro", uri=True)) as src, closing(sqlite3.connect(temporary)) as dst:
            src.backup(dst)
        os.chmod(temporary, 0o600)
        verify_sqlite(temporary)
        os.replace(temporary, destination)
        return actual
    finally:
        temporary.unlink(missing_ok=True)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    backup_parser = sub.add_parser("backup", help="Create a consistent, checksum-verified backup")
    backup_parser.add_argument("source", type=Path)
    backup_parser.add_argument("destination", type=Path)
    restore_parser = sub.add_parser("restore", help="Verify and restore a backup")
    restore_parser.add_argument("backup", type=Path)
    restore_parser.add_argument("destination", type=Path)
    restore_parser.add_argument("--force", action="store_true", help="Replace an existing destination after verification")
    args = parser.parse_args(argv)
    try:
        if args.command == "backup":
            digest = backup(args.source, args.destination)
            print(f"Backup verified. SHA-256: {digest}")
        else:
            digest = restore(args.backup, args.destination, args.force)
            print(f"Restore verified. SHA-256: {digest}")
        return 0
    except (ValueError, FileExistsError, OSError, sqlite3.DatabaseError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
