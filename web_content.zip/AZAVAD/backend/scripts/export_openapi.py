"""Export the current FastAPI contract to docs/openapi.json."""
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(root / "backend"))
from app.main import app  # noqa: E402

out = root / "docs" / "openapi.json"
out.write_text(json.dumps(app.openapi(), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(f"Wrote {out} with {len(app.openapi()['paths'])} paths")
