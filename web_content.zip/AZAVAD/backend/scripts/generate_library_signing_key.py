#!/usr/bin/env python3
"""Generate an Ed25519 key pair for AZAVAD library publication.

Keep the private key outside the repository and backups that are accessible to
untrusted operators. The server expects the private file to contain base64 of
32 raw Ed25519 private-key bytes.
"""
import argparse
import base64
import os
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--private-output", required=True, help="Path outside the repository for the secret private key")
    parser.add_argument("--public-output", required=True, help="Path for the public key to pin in clients")
    args = parser.parse_args()
    private_path = Path(args.private_output).expanduser().resolve()
    public_path = Path(args.public_output).expanduser().resolve()
    if private_path == public_path:
        parser.error("private and public output paths must differ")
    if private_path.exists() or public_path.exists():
        parser.error("refusing to overwrite an existing key file")

    private_path.parent.mkdir(parents=True, exist_ok=True)
    public_path.parent.mkdir(parents=True, exist_ok=True)
    private_key = Ed25519PrivateKey.generate()
    private_raw = private_key.private_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PrivateFormat.Raw,
        encryption_algorithm=serialization.NoEncryption(),
    )
    public_raw = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    created_paths = []
    try:
        fd = os.open(private_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        created_paths.append(private_path)
        with os.fdopen(fd, "w", encoding="ascii") as stream:
            stream.write(base64.b64encode(private_raw).decode("ascii") + "\n")
        fd = os.open(public_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
        created_paths.append(public_path)
        with os.fdopen(fd, "w", encoding="ascii") as stream:
            stream.write(base64.b64encode(public_raw).decode("ascii") + "\n")
    except Exception:
        # Remove only files created by this invocation, never an existing file.
        for path in created_paths:
            try:
                path.unlink()
            except OSError:
                pass
        raise
    print(f"Private key written with mode 0600: {private_path}")
    print(f"Public key written: {public_path}")
    print("Configure AZAVAD_LIBRARY_SIGNING_PRIVATE_KEY_FILE to point to the private file.")
    print("Pin the public key in clients out-of-band; do not trust a key fetched from the same untrusted server alone.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
