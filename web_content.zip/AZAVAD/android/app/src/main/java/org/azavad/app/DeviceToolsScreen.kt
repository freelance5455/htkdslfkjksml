package org.azavad.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.IntentFilter
import android.os.BatteryManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.media.projection.MediaProjectionManager
import android.location.Location
import android.location.LocationListener
import android.os.CancellationSignal
import android.os.Looper
import android.os.Build
import android.graphics.Bitmap
import android.net.Uri
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.database.Cursor
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.security.MessageDigest
import java.util.UUID

private const val PREFS = "azavad_preferences"
private const val NOTIFICATION_OPT_IN = "notification_monitor_enabled"
private const val NOTIFICATION_LOG = "notification_local_log"
private const val MAX_FILE_BYTES = 10_000_000_000L

@Composable
fun DeviceToolsScreen(accessToken: String?, api: ApiClient) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val prefs = remember { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    var message by remember { mutableStateOf("Действия запускаются владельцем. Серверная передача начинается только после отдельного согласия и нажатия кнопки.") }
    var cameraConsent by remember { mutableStateOf(consentActive(prefs, "camera")) }
    var audioConsent by remember { mutableStateOf(consentActive(prefs, "microphone")) }
    var filesConsent by remember { mutableStateOf(consentActive(prefs, "files")) }
    var screenShareConsent by remember { mutableStateOf(consentActive(prefs, "screen_share")) }
    var pendingScreenCommandId by remember { mutableStateOf<Int?>(null) }
    var monitorEnabled by remember { mutableStateOf(consentActive(prefs, "notifications")) }
    var backupConsent by remember { mutableStateOf(consentActive(prefs, "backup")) }
    var notificationCount by remember { mutableStateOf(readNotificationLog(context).length()) }
    var busy by remember { mutableStateOf(false) }
    var registeredDeviceId by remember { mutableStateOf(prefs.getInt("registered_device_id", -1)) }
    var activeRemoteCommandId by remember { mutableStateOf<Int?>(null) }
    var consentResyncAttempted by remember { mutableStateOf(false) }
    val remoteCommands = remember { mutableStateListOf<JSONObject>() }
    LaunchedEffect(accessToken) {
        val token = accessToken ?: return@LaunchedEffect
        val deviceKey = prefs.getString("registered_device_key", null) ?: UUID.randomUUID().toString().also {
            prefs.edit().putString("registered_device_key", it).apply()
        }
        val displayName = "${Build.MANUFACTURER} ${Build.MODEL}".trim().take(100).ifBlank { "Android device" }
        val appVersion = runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "unknown" }.getOrDefault("unknown")
        runCatching {
            val registered = api.registerDevice(token, deviceKey, displayName, appVersion)
            val id = registered.optInt("id", -1)
            if (id <= 0) throw IOException("Сервер не вернул ID устройства")
            prefs.edit().putInt("registered_device_id", id).apply()
            registeredDeviceId = id
        }.onFailure { message = "Устройство сохранено локально; регистрация на сервере пока не удалась: ${it.message}" }
    }
    LaunchedEffect(accessToken, registeredDeviceId) {
        val token = accessToken ?: return@LaunchedEffect
        if (registeredDeviceId <= 0) return@LaunchedEffect
        while (true) {
            if (lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) try {
                val heartbeat = readDeviceHeartbeat(context, true)
                api.reportDeviceHeartbeat(token, registeredDeviceId, heartbeat)
                val incoming = api.pollRemoteCommands(token, registeredDeviceId)
                val visible = mutableListOf<JSONObject>()
                for (i in 0 until incoming.length()) {
                    val command = incoming.getJSONObject(i)
                    if (command.optBoolean("stop_requested")) {
                        val commandId = command.optInt("id")
                        if (command.optString("command_type") == "screen_share_request") {
                            runCatching {
                                context.startService(Intent(context, ScreenShareService::class.java).apply {
                                    action = ScreenShareService.ACTION_STOP
                                    putExtra(ScreenShareService.EXTRA_COMMAND_ID, commandId)
                                })
                                api.reportRemoteCommand(token, registeredDeviceId, commandId, "completed", "Screen capture stopped locally after server stop request; device acknowledged session end.")
                                activeRemoteCommandId = null
                            message = "Трансляция экрана остановлена; сервер получил подтверждение устройства."
                            }.onFailure { message = "Не удалось подтвердить остановку трансляции: ${it.message}" }
                        } else {
                            message = "Сервер запросил остановку сессии #$commandId; для этого типа нет активного локального обработчика."
                        }
                        continue
                    } else if (command.optString("status") == "cancelled") {
                        // Cancelled requests are intentionally not surfaced as actionable prompts.
                        continue
                    } else if (command.optString("command_type") == "device_status") {
                        val appVersion = runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "unknown" }.getOrDefault("unknown")
                        val status = readDeviceHeartbeat(context, true)
                        api.reportRemoteCommand(token, registeredDeviceId, command.optInt("id"), "completed",
                            "AZAVAD active; Android ${Build.VERSION.RELEASE}; ${Build.MANUFACTURER} ${Build.MODEL}; app $appVersion; battery=${status.opt("battery_percent")}; charging=${status.optBoolean("charging")}; network=${status.optBoolean("network_connected")}; foreground=true")
                    } else visible.add(command)
                }
                remoteCommands.clear()
                remoteCommands.addAll(visible)
                consentResyncAttempted = false
            } catch (e: Exception) {
                if ((e.message?.contains("consent", ignoreCase = true) == true || e.message?.contains("403") == true) &&
                    !consentResyncAttempted && prefs.getBoolean("consent_v1", false) &&
                    prefs.getLong("consent_expires_at", 0L) > System.currentTimeMillis()) {
                    consentResyncAttempted = true
                    runCatching { api.setRemotePanelConsent(token, true) }
                        .onFailure { message = "Не удалось синхронизировать общее согласие с сервером: ${it.message}" }
                } else if (remoteCommands.isEmpty() && !consentResyncAttempted) {
                    message = "Очередь удалённых запросов пока недоступна: ${e.message}"
                }
            }
            delay(10_000)
        }
    }
    val candidates = remember { mutableStateListOf<File>() }
    val backups = remember { mutableStateListOf<JSONObject>() }
    val pendingBackups = remember { mutableStateListOf<JSONObject>() }
    var restoreBackupId by remember { mutableStateOf<String?>(null) }
    var locationStatusVersion by remember { mutableStateOf(0) }
    var backgroundLocationConsent by remember { mutableStateOf(consentActive(prefs, "background_location")) }
    var locationConsent by remember { mutableStateOf(consentActive(prefs, "location")) }
    val foregroundLocationGranted = remember(locationStatusVersion) {
        context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }
    val backgroundLocationGranted = remember(locationStatusVersion, foregroundLocationGranted) {
        if (Build.VERSION.SDK_INT < 29) foregroundLocationGranted
        else context.checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED
    }
    val locationServicesEnabled = remember(locationStatusVersion) {
        runCatching {
            val manager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            if (Build.VERSION.SDK_INT >= 28) manager.isLocationEnabled
            else manager.isProviderEnabled(LocationManager.GPS_PROVIDER) || manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
        }.getOrDefault(false)
    }
    val foregroundLocationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
        locationStatusVersion++
        val hasForeground = results[Manifest.permission.ACCESS_COARSE_LOCATION] == true ||
            results[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (hasForeground && Build.VERSION.SDK_INT >= 29 && context.checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            message = "Теперь откройте сведения о приложении → Разрешения → Местоположение и выберите разрешение в фоновом режиме / «Разрешить всегда», если такой пункт доступен."
            context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}")))
        } else {
            message = if (hasForeground) "Разрешение на местоположение проверено. Это пока только настройка доступа; автоматическая передача координат в этой версии не реализована."
                else "Доступ к местоположению не предоставлен. Можно продолжить пользоваться остальными функциями."
        }
    }

    val screenProjectionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val commandId = pendingScreenCommandId
        pendingScreenCommandId = null
        val token = accessToken
        if (commandId == null || token == null || registeredDeviceId <= 0) return@rememberLauncherForActivityResult
        if (result.resultCode != Activity.RESULT_OK || result.data == null) {
            activeRemoteCommandId = null
            scope.launch { runCatching { api.reportRemoteCommand(token, registeredDeviceId, commandId, "failed", "Владелец отменил системное разрешение MediaProjection; захват экрана не запускался.") } }
            message = "Разрешение на демонстрацию экрана отменено. Передача не запущена."
        } else {
            scope.launch {
                try {
                    api.reportRemoteCommand(token, registeredDeviceId, commandId, "running", "Android MediaProjection system prompt accepted; preparing visible foreground screen-sharing service.")
                    val serviceIntent = Intent(context, ScreenShareService::class.java).apply {
                        putExtra(ScreenShareService.EXTRA_DEVICE_ID, registeredDeviceId)
                        putExtra(ScreenShareService.EXTRA_COMMAND_ID, commandId)
                        putExtra(ScreenShareService.EXTRA_RESULT_CODE, result.resultCode)
                        putExtra(ScreenShareService.EXTRA_RESULT_DATA, result.data)
                    }
                    if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(serviceIntent) else context.startService(serviceIntent)
                    message = "Трансляция экрана запущена. В строке состояния Android отображается активная сессия; остановка доступна через панель."
                } catch (e: Exception) {
                    activeRemoteCommandId = null
                    runCatching { api.reportRemoteCommand(token, registeredDeviceId, commandId, "failed", "Не удалось запустить MediaProjection service: ${e.message}") }
                    message = "Не удалось запустить трансляцию: ${e.message}"
                }
            }
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap: Bitmap? ->
        val remoteId = activeRemoteCommandId
        activeRemoteCommandId = null
        if (bitmap == null) {
            message = "Съёмка отменена."
            if (remoteId != null && accessToken != null && registeredDeviceId > 0) scope.launch { runCatching { api.reportRemoteCommand(accessToken, registeredDeviceId, remoteId, "failed", "Владелец отменил съёмку.") } }
            Unit
        } else runCatching {
            val dir = File(context.filesDir, "owner-captured").apply { mkdirs() }
            val out = File(dir, "photo_${System.currentTimeMillis()}.jpg")
            FileOutputStream(out).use { if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 92, it)) throw IOException("JPEG encoding failed") }
            candidates.add(out)
            message = "Фото сохранено: ${out.name}. Нажмите «Передать выбранные файлы», чтобы вручную создать серверную копию."
            if (remoteId != null && accessToken != null && registeredDeviceId > 0) scope.launch { runCatching { api.reportRemoteCommand(accessToken, registeredDeviceId, remoteId, "completed", "Владелец сделал фото через открытый интерфейс камеры; файл сохранён локально.") } }
        }.onFailure { e ->
            message = "Не удалось сохранить фото: ${e.message}"
            if (remoteId != null && accessToken != null && registeredDeviceId > 0) scope.launch { runCatching { api.reportRemoteCommand(accessToken, registeredDeviceId, remoteId, "failed", "Не удалось сохранить фото: ${e.message}") } }
        }
    }
    val audioLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val remoteId = activeRemoteCommandId
        activeRemoteCommandId = null
        val uri = result.data?.data
        if (result.resultCode != Activity.RESULT_OK || uri == null) {
            message = "Запись отменена или диктофон не вернул файл."
            if (remoteId != null && accessToken != null && registeredDeviceId > 0) scope.launch { runCatching { api.reportRemoteCommand(accessToken, registeredDeviceId, remoteId, "failed", "Владелец отменил запись или диктофон не вернул файл.") } }
            Unit
        } else runCatching {
            val dir = File(context.filesDir, "owner-captured").apply { mkdirs() }
            val out = File(dir, "audio_${System.currentTimeMillis()}${extensionFor(context, uri, ".m4a")}")
            copyUriToFile(context, uri, out)
            candidates.add(out)
            message = "Аудиофайл сохранён: ${out.name}. Передача на сервер не начнётся без отдельного действия."
            if (remoteId != null && accessToken != null && registeredDeviceId > 0) scope.launch { runCatching { api.reportRemoteCommand(accessToken, registeredDeviceId, remoteId, "completed", "Владелец записал звук через открытый системный диктофон; файл сохранён локально.") } }
        }.onFailure { e ->
            message = "Не удалось сохранить аудио: ${e.message}"
            if (remoteId != null && accessToken != null && registeredDeviceId > 0) scope.launch { runCatching { api.reportRemoteCommand(accessToken, registeredDeviceId, remoteId, "failed", "Не удалось сохранить аудио: ${e.message}") } }
        }
    }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
        val remoteId = activeRemoteCommandId
        activeRemoteCommandId = null
        if (uris.isEmpty()) {
            message = "Выбор файлов отменён."
            if (remoteId != null && accessToken != null && registeredDeviceId > 0) scope.launch { runCatching { api.reportRemoteCommand(accessToken, registeredDeviceId, remoteId, "failed", "Владелец отменил выбор файлов.") } }
        }
        else {
            var copied = 0
            try {
                val dir = File(context.filesDir, "owner-selected-files").apply { mkdirs() }
                uris.forEach { uri ->
                    val display = displayName(context, uri).replace(Regex("[^A-Za-z0-9._-]"), "_").take(100).ifBlank { "selected_file" }
                    val target = File(dir, "${System.currentTimeMillis()}_${copied}_$display")
                    try { copyUriToFile(context, uri, target); candidates.add(target); copied++ }
                    catch (e: Exception) { target.delete(); throw e }
                }
                message = "Скопировано файлов: $copied. Лимит одного файла — 10 GB; серверная передача выполняется отдельно по кнопке."
                if (remoteId != null && accessToken != null && registeredDeviceId > 0) scope.launch { runCatching { api.reportRemoteCommand(accessToken, registeredDeviceId, remoteId, "completed", "Владелец выбрал и локально подготовил $copied файл(ов); передача не запускалась.") } }
            } catch (e: Exception) {
                message = "Ошибка копирования: ${e.message}"
                if (remoteId != null && accessToken != null && registeredDeviceId > 0) scope.launch { runCatching { api.reportRemoteCommand(accessToken, registeredDeviceId, remoteId, "failed", "Ошибка выбора/копирования файлов: ${e.message}") } }
            }
        }
    }
    val restorePicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri: Uri? ->
        val id = restoreBackupId
        restoreBackupId = null
        if (uri == null || id == null) message = "Восстановление отменено."
        else if (accessToken == null) message = "Войдите в аккаунт для восстановления."
        else scope.launch {
            busy = true
            try {
                val output = context.contentResolver.openOutputStream(uri) ?: throw IOException("Не удалось открыть файл для записи")
                output.use { api.downloadBackup(accessToken, id, it) }
                message = "Файл восстановлен и сохранён в выбранное место."
            } catch (e: Exception) { message = "Ошибка восстановления: ${e.message}" }
            finally { busy = false }
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Медиа и резервирование", style = MaterialTheme.typography.headlineSmall)
        Text("Камера, микрофон и файлы доступны по явному действию. Никакая передача на сервер не выполняется автоматически.", color = MaterialTheme.colorScheme.secondary)
        if (accessToken != null) {
            Card { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Запросы внешней панели", style = MaterialTheme.typography.titleMedium)
                Text(if (registeredDeviceId > 0) "ID устройства: $registeredDeviceId. Проверка очереди выполняется, пока этот экран открыт." else "Ожидается регистрация устройства на сервере.", color = MaterialTheme.colorScheme.secondary)
                if (remoteCommands.isEmpty()) Text("Ожидающих запросов нет.")
                remoteCommands.forEach { command ->
                    val id = command.optInt("id")
                    val type = command.optString("command_type")
                    val title = when (type) {
                        "backup_create_request" -> "Создать резервную копию выбранных файлов"
                        "file_picker_request" -> "Открыть системный выбор файлов"
                        "notification_sync_request" -> "Передать историю уведомлений"
                        "screen_share_request" -> "Начать демонстрацию экрана на панели"
                        "camera_session_request" -> "Открыть камеру по запросу панели"
                        "microphone_session_request" -> "Открыть диктофон по запросу панели"
                        "location_once_request" -> "Передать текущую геопозицию один раз"
                        "location_session_request" -> "Запрос временной геолокации (не реализовано)"
                        else -> type
                    }
                    Text("Запрос #$id: $title", fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                    Text("Срок: ${command.optString("expires_at")}. Ничего не запустится без вашего нажатия.", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(enabled = !busy && activeRemoteCommandId == null, onClick = {
                            val token = accessToken
                            if (token == null || registeredDeviceId <= 0) return@Button
                            scope.launch {
                                busy = true
                                try {
                                    api.reportRemoteCommand(token, registeredDeviceId, id, "accepted", "Владелец подтвердил запрос на устройстве.")
                                    when (type) {
                                        "screen_share_request" -> if (screenShareConsent) {
                                            pendingScreenCommandId = id
                                            activeRemoteCommandId = id
                                            val manager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                                            message = "Подтвердите системный запрос Android на демонстрацию экрана. Передача начнётся только после вашего согласия."
                                            screenProjectionLauncher.launch(manager.createScreenCaptureIntent())
                                        } else api.reportRemoteCommand(token, registeredDeviceId, id, "failed", "Нет отдельного согласия владельца на демонстрацию экрана.")
                                        "file_picker_request" -> if (filesConsent) {
                                            activeRemoteCommandId = id
                                            api.reportRemoteCommand(token, registeredDeviceId, id, "running", "Открывается системный файловый интерфейс.")
                                            filePicker.launch(arrayOf("*/*"))
                                        } else api.reportRemoteCommand(token, registeredDeviceId, id, "failed", "Владелец не включил согласие на выбор файлов.")
                                        "camera_session_request" -> if (cameraConsent) {
                                            activeRemoteCommandId = id
                                            api.reportRemoteCommand(token, registeredDeviceId, id, "running", "Открывается системный интерфейс камеры.")
                                            cameraLauncher.launch(null)
                                        } else api.reportRemoteCommand(token, registeredDeviceId, id, "failed", "Владелец не включил согласие на камеру.")
                                        "microphone_session_request" -> if (audioConsent) {
                                            val intent = Intent("android.provider.MediaStore.RECORD_SOUND")
                                            if (intent.resolveActivity(context.packageManager) != null) {
                                                activeRemoteCommandId = id
                                                api.reportRemoteCommand(token, registeredDeviceId, id, "running", "Открывается системный диктофон.")
                                                audioLauncher.launch(intent)
                                            } else api.reportRemoteCommand(token, registeredDeviceId, id, "failed", "Системный диктофон не найден.")
                                        } else api.reportRemoteCommand(token, registeredDeviceId, id, "failed", "Владелец не включил согласие на микрофон.")
                                        "location_once_request" -> if (locationConsent && foregroundLocationGranted && locationServicesEnabled) {
                                            api.reportRemoteCommand(token, registeredDeviceId, id, "running", "Владелец подтвердил однократный запрос геопозиции; получаем свежую координату.")
                                            val location = getFreshLocation(context)
                                                ?: throw IOException("Не удалось получить свежую геопозицию за 15 секунд. Проверьте GPS и разрешение Android.")
                                            val capturedAt = java.time.Instant.ofEpochMilli(location.time).toString()
                                            val summary = "Owner-approved one-time location; lat=${"%.6f".format(java.util.Locale.US, location.latitude)}; lon=${"%.6f".format(java.util.Locale.US, location.longitude)}; accuracy_m=${"%.1f".format(java.util.Locale.US, location.accuracy)}; captured_at=$capturedAt"
                                            api.reportRemoteCommand(token, registeredDeviceId, id, "completed", summary)
                                            message = "Однократная геопозиция передана в панель по вашему подтверждению."
                                        } else api.reportRemoteCommand(token, registeredDeviceId, id, "failed", "Нужны отдельное согласие на однократную геопозицию, разрешение Android в активном режиме и включённые службы геолокации.")
                                        "notification_sync_request" -> if (monitorEnabled && readNotificationLog(context).length() > 0) {
                                            api.reportRemoteCommand(token, registeredDeviceId, id, "running", "Передаётся история уведомлений после подтверждения владельца.")
                                            val result = api.syncNotificationHistory(token, readNotificationLog(context))
                                            api.reportRemoteCommand(token, registeredDeviceId, id, "completed", "Передано записей: ${result.optInt("inserted")}; только история, выбранная владельцем настройкой уведомлений.")
                                            message = "Запрос панели выполнен: синхронизирована история уведомлений."
                                        } else api.reportRemoteCommand(token, registeredDeviceId, id, "failed", "Нет активного согласия или локальной истории уведомлений.")
                                        "backup_create_request" -> if (backupConsent && candidates.isNotEmpty()) {
                                            api.reportRemoteCommand(token, registeredDeviceId, id, "running", "Передаётся резервная копия ранее выбранных владельцем файлов.")
                                            var uploaded = 0
                                            candidates.toList().forEach { file -> api.uploadBackup(token, file); uploaded++ }
                                            api.reportRemoteCommand(token, registeredDeviceId, id, "completed", "Создано резервных копий: $uploaded.")
                                            message = "Запрос панели выполнен: создано резервных копий $uploaded."
                                        } else api.reportRemoteCommand(token, registeredDeviceId, id, "failed", "Нужно согласие на резервирование и хотя бы один заранее выбранный файл.")
                                        else -> api.reportRemoteCommand(token, registeredDeviceId, id, "failed", "Обработчик этой функции ещё не реализован. Никакая сенсорная/экранная сессия не была запущена.")
                                    }
                                    remoteCommands.removeAll { it.optInt("id") == id }
                                } catch (e: Exception) {
                                    message = "Не удалось выполнить запрос #$id: ${e.message}"
                                    runCatching { api.reportRemoteCommand(token, registeredDeviceId, id, "failed", "Ошибка выполнения: ${e.message}") }
                                    remoteCommands.removeAll { it.optInt("id") == id }
                                } finally { busy = false }
                            }
                        }) { Text("Разрешить") }
                        OutlinedButton(enabled = !busy && activeRemoteCommandId == null, onClick = {
                            val token = accessToken
                            if (token == null || registeredDeviceId <= 0) return@OutlinedButton
                            scope.launch {
                                runCatching { api.reportRemoteCommand(token, registeredDeviceId, id, "rejected", "Владелец отклонил запрос на устройстве.") }
                                    .onFailure { message = "Не удалось передать отказ на сервер: ${it.message}" }
                                remoteCommands.removeAll { it.optInt("id") == id }
                            }
                        }) { Text("Отклонить") }
                    }
                }
            } }
        }
        Card { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Однократная геопозиция", style = MaterialTheme.typography.titleMedium)
            Text("Разрешает передать координаты только после отдельного запроса панели и вашего нажатия «Разрешить». Используется активное разрешение Android; постоянное отслеживание не запускается.")
            ConsentRow("Разрешаю однократную передачу геопозиции по моему подтверждению (365 дней, можно отозвать)", locationConsent) { granted ->
                locationConsent = granted
                setConsent(prefs, "location", granted)
                message = if (granted) "Согласие на однократную геопозицию сохранено локально." else "Согласие на геопозицию отозвано локально."
                accessToken?.let { token -> scope.launch {
                    runCatching { api.setDeviceConsent(token, "location", granted) }
                        .onSuccess { message = if (granted) "Согласие на однократную геопозицию сохранено на сервере и действует до 365 дней." else "Согласие на геопозицию отозвано на сервере." }
                        .onFailure { e -> message = "Состояние изменено локально, но сервер не обновлён: ${e.message}" }
                } }
            }
            Text("Однократная геопозиция доступна: ${if (locationConsent && foregroundLocationGranted && locationServicesEnabled) "да" else "нет — проверьте согласие, разрешение и службы местоположения"}.", color = MaterialTheme.colorScheme.secondary)
        } }
        Card { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Фоновая геолокация", style = MaterialTheme.typography.titleMedium)
            Text("Отдельное согласие на разрешение Android. Разрешение само по себе не запускает слежение и не отправляет координаты на сервер; передача геопозиции ещё не реализована.")
            ConsentRow("Согласен разрешить приложению доступ к местоположению в фоновом режиме (365 дней, можно отозвать)", backgroundLocationConsent) { granted ->
                if (!granted) {
                    backgroundLocationConsent = false
                    setConsent(prefs, "background_location", false)
                    message = "Согласие отозвано в AZAVAD. Чтобы отозвать системное разрешение Android, откройте настройки разрешений приложения."
                    accessToken?.let { token -> scope.launch { runCatching { api.setDeviceConsent(token, "background_location", false) }.onFailure { e -> message = "Согласие отозвано локально, но серверный журнал не синхронизирован: ${e.message}" } } }
                } else {
                    backgroundLocationConsent = true
                    setConsent(prefs, "background_location", true)
                    accessToken?.let { token -> scope.launch { runCatching { api.setDeviceConsent(token, "background_location", true) }.onFailure { e -> message = "Согласие сохранено локально, но серверный журнал не синхронизирован: ${e.message}" } } }
                    if (!foregroundLocationGranted) {
                        foregroundLocationLauncher.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
                    } else if (Build.VERSION.SDK_INT >= 29 && !backgroundLocationGranted) {
                        message = "Откройте сведения о приложении → Разрешения → Местоположение и выберите разрешение в фоновом режиме / «Разрешить всегда», если такой пункт доступен."
                        context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}")))
                    } else {
                        message = "Системное разрешение на местоположение уже предоставлено. Фоновая передача координат в этой версии ещё не реализована."
                    }
                }
            }
            Text("Статус: ${if (foregroundLocationGranted) "доступ в активном режиме есть" else "нет разрешения на местоположение"}; ${if (backgroundLocationGranted) "фоновое разрешение есть" else "фоновое разрешение отсутствует"}; ${if (locationServicesEnabled) "службы геолокации включены" else "службы геолокации выключены"}.", color = MaterialTheme.colorScheme.secondary)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = backgroundLocationConsent, onClick = {
                    if (!foregroundLocationGranted) foregroundLocationLauncher.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
                    else {
                        context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}")))
                        message = "Проверьте разрешение местоположения в системных настройках, затем вернитесь и нажмите «Обновить статус»."
                    }
                }) { Text("Настроить разрешение") }
                OutlinedButton(onClick = { locationStatusVersion++ }) { Text("Обновить статус") }
            }
        } }
        Card { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Мониторинг экрана", style = MaterialTheme.typography.titleMedium)
            Text("Трансляция запускается только после вашего подтверждения запроса в AZAVAD и системного разрешения Android. Во время передачи отображается постоянное уведомление. Кадры передаются на сервер только для активной сессии.")
            ConsentRow("Разрешаю демонстрацию экрана по отдельному запросу и системному подтверждению Android (до 365 дней, можно отозвать)", screenShareConsent) { granted ->
                screenShareConsent = granted
                setConsent(prefs, "screen_share", granted)
                if (!granted) {
                    context.stopService(Intent(context, ScreenShareService::class.java))
                    activeRemoteCommandId?.let { id -> accessToken?.let { token -> scope.launch { runCatching { api.reportRemoteCommand(token, registeredDeviceId, id, "failed", "Владелец отозвал согласие на демонстрацию экрана.") } } } }
                    activeRemoteCommandId = null
                }
                accessToken?.let { token -> scope.launch {
                    runCatching { api.setDeviceConsent(token, "screen_share", granted) }
                        .onSuccess { message = if (granted) "Согласие на демонстрацию экрана сохранено на сервере. Системное подтверждение Android всё равно требуется." else "Согласие на демонстрацию экрана отозвано; локальная служба остановлена." }
                        .onFailure { e -> message = "Состояние изменено локально, но сервер не обновлён: ${e.message}" }
                } }
            }
            Text("Состояние: ${if (screenShareConsent) "согласие включено" else "согласие выключено"}. Согласие не заменяет системный диалог Android.", color = MaterialTheme.colorScheme.secondary)
        } }
        Card { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Камера", style = MaterialTheme.typography.titleMedium)
            Text("Сделать снимок через системный интерфейс и сохранить его в приватном хранилище.")
            ConsentRow("Разрешаю использовать камеру по моему действию", cameraConsent) { granted ->
                cameraConsent = granted; setConsent(prefs, "camera", granted)
                accessToken?.let { token -> scope.launch { runCatching { api.setDeviceConsent(token, "camera", granted) }.onFailure { e -> message = "Локальное согласие обновлено, но серверный журнал не синхронизирован: ${e.message}" } } }
            }
            Button(enabled = cameraConsent && !busy, onClick = { cameraLauncher.launch(null) }) { Text("Сделать фото") }
        } }
        Card { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Диктофон", style = MaterialTheme.typography.titleMedium)
            Text("Запись выполняется в отдельном системном приложении, которое само показывает состояние записи.")
            ConsentRow("Разрешаю запись звука по моему действию", audioConsent) { granted ->
                audioConsent = granted; setConsent(prefs, "microphone", granted)
                accessToken?.let { token -> scope.launch { runCatching { api.setDeviceConsent(token, "microphone", granted) }.onFailure { e -> message = "Локальное согласие обновлено, но серверный журнал не синхронизирован: ${e.message}" } } }
            }
            Button(enabled = audioConsent && !busy, onClick = {
                val intent = Intent("android.provider.MediaStore.RECORD_SOUND")
                if (intent.resolveActivity(context.packageManager) != null) audioLauncher.launch(intent)
                else message = "Не найдено системное приложение-диктофон с поддержкой записи."
            }) { Text("Открыть диктофон") }
        } }
        Card { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Выбор файлов", style = MaterialTheme.typography.titleMedium)
            Text("Выберите конкретные документы через системный файловый интерфейс. Файлы больше 10 GB отклоняются.")
            ConsentRow("Разрешаю копировать только выбранные мной файлы", filesConsent) { granted ->
                filesConsent = granted; setConsent(prefs, "files", granted)
                accessToken?.let { token -> scope.launch { runCatching { api.setDeviceConsent(token, "file_access", granted) }.onFailure { e -> message = "Локальное согласие обновлено, но серверный журнал не синхронизирован: ${e.message}" } } }
            }
            Button(enabled = filesConsent && !busy, onClick = { filePicker.launch(arrayOf("*/*")) }) { Text("Выбрать файлы") }
            Text("Подготовлено к резервированию: ${candidates.size} файл(ов)")
            candidates.takeLast(8).forEach { Text("• ${it.name} (${formatBytes(it.length())})", style = MaterialTheme.typography.bodySmall) }
        } }
        Card { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Мониторинг уведомлений", style = MaterialTheme.typography.titleMedium)
            Text("Доступ Notification Listener включается владельцем в системных настройках Android. История шифруется локально. Передача на сервер — отдельной кнопкой; сервер хранит не более 500 последних записей и показывает их только владельцу аккаунта.")
            ConsentRow("Разрешаю локально сохранять последние уведомления", monitorEnabled) { granted ->
                monitorEnabled = granted; setConsent(prefs, "notifications", granted); prefs.edit().putBoolean(NOTIFICATION_OPT_IN, granted).apply()
                if (!granted) { EncryptedLocalStore.remove(context, NOTIFICATION_LOG); notificationCount = 0 }
                accessToken?.let { token -> scope.launch { runCatching { api.setDeviceConsent(token, "notifications", granted) }.onFailure { e -> message = "Локальное согласие обновлено, но серверный журнал не синхронизирован: ${e.message}" } } }
            }
            Button(onClick = { if (monitorEnabled) context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) else message = "Сначала включите согласие на локальное сохранение уведомлений." }) { Text("Открыть настройки Android") }
            Text("Локально сохранено: $notificationCount уведомлений")
            Button(enabled = monitorEnabled && !busy && accessToken != null && notificationCount > 0, onClick = {
                val token = accessToken ?: return@Button
                busy = true
                scope.launch {
                    try {
                        val result = api.syncNotificationHistory(token, readNotificationLog(context))
                        message = "Передача завершена: добавлено ${result.optInt("inserted")} новых записей. На сервере хранится до 500 последних уведомлений."
                    } catch (e: Exception) { message = "Не удалось отправить историю: ${e.message}" }
                    finally { busy = false }
                }
            }) { Text("Отправить историю на сервер") }
            OutlinedButton(enabled = accessToken != null && !busy, onClick = {
                val token = accessToken ?: return@OutlinedButton
                busy = true
                scope.launch {
                    try { api.clearNotificationHistory(token); message = "Серверная история уведомлений удалена." }
                    catch (e: Exception) { message = "Не удалось удалить серверную историю: ${e.message}" }
                    finally { busy = false }
                }
            }) { Text("Удалить историю с сервера") }
            OutlinedButton(enabled = monitorEnabled && !busy, onClick = {
                val log = readNotificationLog(context)
                val out = File(File(context.filesDir, "owner-selected-files").apply { mkdirs() }, "notification_history_${System.currentTimeMillis()}.json")
                runCatching { out.writeText(log.toString(2), Charsets.UTF_8); candidates.add(out); message = "История уведомлений добавлена в список файлов для резервирования." }
                    .onFailure { message = "Не удалось подготовить экспорт уведомлений: ${it.message}" }
            }) { Text("Добавить историю в резервную копию") }
            OutlinedButton(onClick = { EncryptedLocalStore.remove(context, NOTIFICATION_LOG); notificationCount = 0; message = "Локальная история уведомлений очищена." }) { Text("Очистить историю") }
        } }
        Card { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Защищённая серверная копия", style = MaterialTheme.typography.titleMedium)
            Text("Передача идёт частями по HTTPS. Сервер шифрует каждый блок при хранении, проверяет целостность и позволяет восстановить файл. Максимум 10 GB на файл; квота аккаунта настраивается сервером.")
            ConsentRow("Разрешаю хранить выбранные мной файлы в резервной копии на сервере (365 дней, отзыв в любой момент)", backupConsent) { granted ->
                if (!granted) {
                    backupConsent = false; setConsent(prefs, "backup", false)
                    scope.launch { runCatching { if (accessToken != null) api.setBackupConsent(accessToken, false) }.onFailure { message = "Локально согласие отозвано; серверное обновление не удалось: ${it.message}" } }
                } else if (accessToken == null) message = "Для серверного резервирования сначала войдите в аккаунт."
                else scope.launch {
                    busy = true
                    try { api.setBackupConsent(accessToken, true); backupConsent = true; setConsent(prefs, "backup", true); message = "Согласие на резервирование сохранено на сервере и действует до 365 дней; его можно отозвать раньше." }
                    catch (e: Exception) { backupConsent = false; setConsent(prefs, "backup", false); message = "Не удалось зарегистрировать согласие на сервере: ${e.message}" }
                    finally { busy = false }
                }
            }
            Button(enabled = backupConsent && accessToken != null && candidates.isNotEmpty() && !busy, onClick = {
                val token = accessToken ?: return@Button
                scope.launch {
                    busy = true
                    var success = 0
                    try {
                        candidates.toList().forEach { file ->
                            if (!file.exists() || !file.isFile) throw IOException("Файл недоступен: ${file.name}")
                            if (file.length() > MAX_FILE_BYTES) throw IOException("Файл больше 10 GB: ${file.name}")
                            message = "Передача ${file.name}: 0%"
                            val resumeKey = backupResumeKey(file)
                            val resumeId = prefs.getString(resumeKey, null)
                            api.uploadBackup(token, file, resumeId,
                                onUploadId = { id -> prefs.edit().putString(resumeKey, id).apply() },
                                onProgress = { sent, total ->
                                    val percent = if (total == 0L) 100 else ((sent * 100) / total).toInt()
                                    message = "Передача ${file.name}: $percent% (${formatBytes(sent)} / ${formatBytes(total)})"
                                })
                            prefs.edit().remove(resumeKey).apply()
                            candidates.remove(file)
                            success++
                        }
                        message = "Резервная копия завершена: $success файл(ов). Сервер подтвердил целостность."
                        refreshBackups(api, token, backups, pendingBackups)
                    } catch (e: Exception) { message = "Передача приостановлена: ${e.message}. Повторный запуск продолжит загрузку с уже переданных блоков." }
                    finally { busy = false }
                }
            }) { Text(if (busy) "Выполняется…" else "Передать выбранные файлы") }
            OutlinedButton(enabled = backupConsent && accessToken != null && !busy, onClick = {
                val token = accessToken ?: return@OutlinedButton
                scope.launch { busy = true; try { refreshBackups(api, token, backups, pendingBackups); message = "Список резервных копий обновлён." } catch (e: Exception) { message = "Не удалось получить список копий: ${e.message}" } finally { busy = false } }
            }) { Text("Обновить список копий") }
            if (pendingBackups.isNotEmpty()) {
                Text("Незавершённые загрузки", style = MaterialTheme.typography.titleSmall)
                pendingBackups.forEach { item ->
                    val id = item.optString("id")
                    Text("${item.optString("filename")} · ${formatBytes(item.optLong("size_bytes"))}", style = MaterialTheme.typography.bodySmall)
                    OutlinedButton(enabled = !busy, onClick = {
                        val token = accessToken
                        if (token != null) scope.launch { busy = true; try { api.deleteBackup(token, id); pendingBackups.remove(item); message = "Незавершённая загрузка удалена." } catch (e: Exception) { message = "Удаление не удалось: ${e.message}" } finally { busy = false } }
                    }) { Text("Удалить незавершённую") }
                }
            }
            if (backups.isNotEmpty()) {
                Text("Серверные копии", style = MaterialTheme.typography.titleSmall)
                backups.forEach { item ->
                    val id = item.optString("id")
                    Text("${item.optString("filename")} · ${formatBytes(item.optLong("size_bytes"))}", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(enabled = !busy, onClick = { restoreBackupId = id; restorePicker.launch(item.optString("filename", "restored_backup.bin")) }) { Text("Восстановить") }
                        OutlinedButton(enabled = !busy, onClick = {
                            val token = accessToken
                            if (token != null) scope.launch { busy = true; try { api.deleteBackup(token, id); backups.remove(item); message = "Резервная копия удалена." } catch (e: Exception) { message = "Удаление не удалось: ${e.message}" } finally { busy = false } }
                        }) { Text("Удалить") }
                    }
                }
            }
        } }
        Card { Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text("Статус", style = MaterialTheme.typography.titleSmall)
            Text(message, color = MaterialTheme.colorScheme.secondary)
            if (accessToken == null) Text("Войдите в аккаунт, чтобы включить серверное резервирование и восстановление.", color = MaterialTheme.colorScheme.error)
        } }
    }
}

private suspend fun refreshBackups(api: ApiClient, token: String, target: MutableList<JSONObject>, pendingTarget: MutableList<JSONObject>) {
    val response = api.listBackups(token)
    val result = response.optJSONArray("items") ?: JSONArray()
    val pending = response.optJSONArray("pending") ?: JSONArray()
    target.clear(); pendingTarget.clear()
    for (i in 0 until result.length()) target.add(result.getJSONObject(i))
    for (i in 0 until pending.length()) pendingTarget.add(pending.getJSONObject(i))
}

private fun backupResumeKey(file: File): String {
    val identity = "${file.absolutePath}:${file.length()}:${file.lastModified()}".toByteArray(Charsets.UTF_8)
    val digest = MessageDigest.getInstance("SHA-256").digest(identity).joinToString("") { "%02x".format(it) }
    return "backup_pending_$digest"
}

class AzavadNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(NOTIFICATION_OPT_IN, false) || !consentActive(prefs, "notifications")) return
        val extras = sbn.notification.extras
        val entry = JSONObject().put("package", sbn.packageName.take(150))
            .put("title", extras.getCharSequence("android.title")?.toString()?.take(300).orEmpty())
            .put("text", extras.getCharSequence("android.text")?.toString()?.take(1000).orEmpty())
            .put("postedAt", sbn.postTime)
        synchronized(AzavadNotificationListener::class.java) {
            val old = try { JSONArray(EncryptedLocalStore.read(this, NOTIFICATION_LOG) ?: "[]") } catch (_: Exception) { JSONArray() }
            val next = JSONArray()
            val start = (old.length() - 98).coerceAtLeast(0)
            for (i in start until old.length()) next.put(old.getJSONObject(i))
            next.put(entry)
            EncryptedLocalStore.write(this, NOTIFICATION_LOG, next.toString())
        }
    }
}

private fun readDeviceHeartbeat(context: Context, foreground: Boolean): JSONObject {
    val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
    val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
    val battery = if (level >= 0 && scale > 0) ((level * 100f) / scale).toInt().coerceIn(0, 100) else -1
    val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
    val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
    val connected = runCatching {
        val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = manager.activeNetwork ?: return@runCatching false
        val caps = manager.getNetworkCapabilities(network) ?: return@runCatching false
        caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }.getOrDefault(false)
    val appVersion = runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "unknown" }.getOrDefault("unknown")
    val result = JSONObject().put("charging", charging).put("network_connected", connected)
        .put("app_foreground", foreground).put("android_version", Build.VERSION.RELEASE ?: "unknown")
        .put("app_version", appVersion)
    if (battery >= 0) result.put("battery_percent", battery) else result.put("battery_percent", JSONObject.NULL)
    return result
}

private suspend fun getFreshLocation(context: Context): Location? {
    val coarse = context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    val fine = context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    if (!coarse && !fine) throw SecurityException("Android location permission was not granted")
    val manager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    val providers = manager.getProviders(true).filter { provider ->
        runCatching { manager.getProvider(provider) != null }.getOrDefault(false) &&
            (provider == LocationManager.GPS_PROVIDER || provider == LocationManager.NETWORK_PROVIDER || provider == LocationManager.PASSIVE_PROVIDER)
    }.sortedBy { if (it == LocationManager.GPS_PROVIDER && fine) 0 else if (it == LocationManager.NETWORK_PROVIDER) 1 else 2 }
    for (provider in providers) {
        val freshCached = runCatching { manager.getLastKnownLocation(provider) }.getOrNull()
        if (freshCached != null && System.currentTimeMillis() - freshCached.time in 0L..60_000L && freshCached.accuracy <= 250f) return freshCached
        val fresh = withTimeoutOrNull(15_000) {
            suspendCancellableCoroutine<Location?> { continuation ->
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val cancellation = CancellationSignal()
                    continuation.invokeOnCancellation { cancellation.cancel() }
                    try {
                        manager.getCurrentLocation(provider, cancellation, context.mainExecutor) { location ->
                            if (continuation.isActive) continuation.resume(location)
                        }
                    } catch (e: SecurityException) {
                        if (continuation.isActive) continuation.resume(null)
                    }
                } else {
                    val listener = object : LocationListener {
                        override fun onLocationChanged(location: Location) {
                            if (continuation.isActive) continuation.resume(location)
                            runCatching { manager.removeUpdates(this) }
                        }
                        @Deprecated("Deprecated in API 29") override fun onStatusChanged(provider: String?, status: Int, extras: android.os.Bundle?) = Unit
                        override fun onProviderEnabled(provider: String) = Unit
                        override fun onProviderDisabled(provider: String) = Unit
                    }
                    continuation.invokeOnCancellation { runCatching { manager.removeUpdates(listener) } }
                    try { manager.requestSingleUpdate(provider, listener, Looper.getMainLooper()) }
                    catch (e: SecurityException) { if (continuation.isActive) continuation.resume(null) }
                    catch (e: IllegalArgumentException) { if (continuation.isActive) continuation.resume(null) }
                }
            }
        }
        if (fresh != null && System.currentTimeMillis() - fresh.time in 0L..120_000L) return fresh
    }
    return null
}

@Composable
private fun ConsentRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = checked, onCheckedChange = onChange); Text(label) }
}

private fun consentActive(prefs: android.content.SharedPreferences, feature: String): Boolean {
    val granted = prefs.getBoolean("consent_$feature", false)
    val expires = prefs.getLong("consent_${feature}_expires", 0L)
    return granted && System.currentTimeMillis() < expires
}

private fun setConsent(prefs: android.content.SharedPreferences, feature: String, granted: Boolean) {
    val edit = prefs.edit().putBoolean("consent_$feature", granted)
    if (granted) edit.putLong("consent_${feature}_expires", System.currentTimeMillis() + 365L * 24 * 60 * 60 * 1000)
    else edit.putLong("consent_${feature}_expires", 0L)
    edit.apply()
}

private fun readNotificationLog(context: Context): JSONArray = try {
    JSONArray(EncryptedLocalStore.read(context, NOTIFICATION_LOG) ?: "[]")
} catch (_: Exception) { JSONArray() }

private fun copyUriToFile(context: Context, uri: Uri, target: File) {
    val input = context.contentResolver.openInputStream(uri) ?: throw IOException("Не удалось открыть выбранный файл")
    val temp = File(target.parentFile, target.name + ".partial")
    try {
        input.use { source -> temp.outputStream().use { output ->
            val buffer = ByteArray(64 * 1024)
            var total = 0L
            while (true) {
                val read = source.read(buffer)
                if (read < 0) break
                total += read
                if (total > MAX_FILE_BYTES) throw IOException("Файл превышает 10 GB")
                output.write(buffer, 0, read)
            }
        } }
        if (!temp.renameTo(target)) throw IOException("Не удалось завершить копирование файла")
    } finally { temp.delete() }
}

private fun displayName(context: Context, uri: Uri): String {
    var name = "selected_file"
    val cursor: Cursor? = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
    cursor?.use { if (it.moveToFirst()) name = it.getString(0) ?: name }
    return name
}

private fun extensionFor(context: Context, uri: Uri, fallback: String): String {
    val name = displayName(context, uri)
    val dot = name.lastIndexOf('.')
    return if (dot >= 0 && dot < name.lastIndex) name.substring(dot).take(10) else fallback
}

private fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val units = listOf("KiB", "MiB", "GiB", "TiB")
    var value = bytes.toDouble(); var index = -1
    do { value /= 1024.0; index++ } while (value >= 1024 && index < units.lastIndex)
    return "%.2f %s".format(java.util.Locale.US, value, units[index])
}
