package org.azavad.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import android.graphics.Bitmap
import android.graphics.Rect
import android.graphics.PixelFormat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.concurrent.atomic.AtomicBoolean

/** Transparent, owner-approved screen sharing. Android's MediaProjection system consent is mandatory. */
class ScreenShareService : Service() {
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var lastFrameAt = 0L
    private var deviceId = -1
    private var commandId = -1
    private val stopped = AtomicBoolean(false)
    private val uploading = AtomicBoolean(false)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            if (intent.getIntExtra(EXTRA_COMMAND_ID, commandId) == commandId) stopCapture()
            return START_NOT_STICKY
        }
        if (projection != null) return START_NOT_STICKY
        deviceId = intent?.getIntExtra(EXTRA_DEVICE_ID, -1) ?: -1
        commandId = intent?.getIntExtra(EXTRA_COMMAND_ID, -1) ?: -1
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val resultData = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java) else intent?.getParcelableExtra(EXTRA_RESULT_DATA) as? Intent
        if (deviceId <= 0 || commandId <= 0 || resultData == null || resultCode != android.app.Activity.RESULT_OK) {
            stopSelf(); return START_NOT_STICKY
        }
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, resultData)
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(metrics)
            val scale = minOf(1.0, 720.0 / metrics.widthPixels.toDouble())
            val width = (metrics.widthPixels * scale).toInt().coerceAtLeast(1)
            val height = (metrics.heightPixels * scale).toInt().coerceAtLeast(1)
            val density = metrics.densityDpi
            thread = HandlerThread("azavad-screen-capture").also { it.start() }
            handler = Handler(thread!!.looper)
            reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            reader!!.setOnImageAvailableListener({ source -> captureLatest(source) }, handler)
            projection!!.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopCapture() }
            }, handler)
            display = projection!!.createVirtualDisplay("AZAVAD owner-approved screen sharing", width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler)
        } catch (_: Exception) {
            stopCapture()
        }
        return START_NOT_STICKY
    }

    private fun captureLatest(source: ImageReader) {
        if (stopped.get()) return
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastFrameAt < 900) return
        val image = try { source.acquireLatestImage() } catch (_: Exception) { null } ?: return
        try {
            val plane = image.planes.firstOrNull() ?: return
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * image.width
            val paddedWidth = image.width + rowPadding / pixelStride
            val raw = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
            raw.copyPixelsFromBuffer(plane.buffer)
            val bitmap = Bitmap.createBitmap(raw, 0, 0, image.width, image.height)
            raw.recycle()
            val out = ByteArrayOutputStream()
            var quality = 55
            do {
                out.reset()
                bitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)
                quality -= 10
            } while (out.size() > 480 * 1024 && quality >= 25)
            bitmap.recycle()
            val jpeg = out.toByteArray()
            if (jpeg.size <= 512 * 1024 && uploading.compareAndSet(false, true)) {
                lastFrameAt = now
                val token = SecureTokenStore(this).read()
                if (token == null) { uploading.set(false); stopCapture(); return }
                scope.launch {
                    try { ApiClient().uploadScreenFrame(token, deviceId, commandId, jpeg) }
                    catch (e: Exception) {
                        // A revoked consent or server stop signal invalidates the stream. Acknowledge
                        // the local stop so the panel does not mistake a request for completion.
                        if (e.message?.contains("consent", true) == true || e.message?.contains("active screen-sharing", true) == true || e.message?.contains("403") == true || e.message?.contains("409") == true) {
                            runCatching { ApiClient().reportRemoteCommand(token, deviceId, commandId, "completed", "Screen capture stopped locally because the server rejected further frames; session ended.") }
                            stopCapture()
                        }
                    } finally { uploading.set(false) }
                }
            }
        } catch (_: Exception) {
            // A malformed or transient frame is skipped; no data is written to disk.
        } finally { image.close() }
    }

    private fun stopCapture() {
        if (!stopped.compareAndSet(false, true)) return
        runCatching { display?.release() }; display = null
        runCatching { reader?.setOnImageAvailableListener(null, null) }
        runCatching { reader?.close() }; reader = null
        runCatching { projection?.stop() }; projection = null
        runCatching { thread?.quitSafely() }; thread = null; handler = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "AZAVAD — демонстрация экрана", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Показывает, когда владелец разрешил трансляцию экрана"
            })
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setContentTitle("AZAVAD: экран передаётся")
            .setContentText("Трансляция активна по системному разрешению Android. Откройте AZAVAD, чтобы остановить её.")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true).build()
    }

    override fun onDestroy() {
        stopCapture()
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "org.azavad.app.action.STOP_SCREEN_SHARE"
        const val EXTRA_DEVICE_ID = "device_id"
        const val EXTRA_COMMAND_ID = "command_id"
        const val EXTRA_RESULT_CODE = "projection_result_code"
        const val EXTRA_RESULT_DATA = "projection_result_data"
        private const val CHANNEL_ID = "azavad_screen_share"
        private const val NOTIFICATION_ID = 4102
    }
}
