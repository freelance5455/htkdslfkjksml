package org.azavad.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

private data class KnowledgeItem(
    val id: String,
    val title: String,
    val category: String,
    val summary: String,
    val sourceTitle: String,
    val sourceUrl: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AzavadApp() }
    }
}

@Composable
private fun AzavadApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("azavad_preferences", 0) }
    val tokenStore = remember { SecureTokenStore(context) }
    val api = remember { ApiClient() }
    val scope = rememberCoroutineScope()
    var consentAccepted by remember { mutableStateOf(prefs.getBoolean("consent_v1", false) && System.currentTimeMillis() < prefs.getLong("consent_expires_at", 0L)) }
    var backgroundConsent by remember { mutableStateOf(prefs.getBoolean("background_sync_consent", false)) }
    var selectedScreen by remember { mutableStateOf("Обучение") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var registerMode by remember { mutableStateOf(false) }
    var sessionUser by remember { mutableStateOf<JSONObject?>(null) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var query by remember { mutableStateOf("") }
    var pendingExportJson by remember { mutableStateOf<String?>(null) }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri == null) {
            pendingExportJson = null
            message = "Экспорт отменён. Файл не создан."
        } else {
            try {
                val exportText = pendingExportJson ?: throw IllegalStateException("Нет подготовленных данных экспорта.")
                val output = context.contentResolver.openOutputStream(uri)
                    ?: throw java.io.IOException("Не удалось открыть выбранный файл для записи.")
                output.use { it.write(exportText.toByteArray(Charsets.UTF_8)) }
                pendingExportJson = null
                message = "Экспорт данных сохранён в выбранное место. Храните файл в безопасном месте."
            } catch (e: Exception) {
                pendingExportJson = null
                message = e.message ?: "Не удалось сохранить файл экспорта."
            }
        }
    }
    val library = remember { loadLibrary(context.assets.open("library.json").bufferedReader().use { it.readText() }) }

    LaunchedEffect(consentAccepted) {
        if (consentAccepted) {
            val token = tokenStore.read()
            if (token != null) {
                try { sessionUser = api.me(token) }
                catch (e: Exception) {
                    tokenStore.clear()
                    sessionUser = null
                    message = "Сессия недоступна; локальный токен очищен: ${e.message}"
                }
            }
        }
    }

    LaunchedEffect(consentAccepted, sessionUser != null) {
        if (consentAccepted && sessionUser != null) {
            val token = tokenStore.read() ?: return@LaunchedEffect
            val expiry = prefs.getLong("consent_expires_at", 0L)
            if (expiry > System.currentTimeMillis()) {
                runCatching { api.setRemotePanelConsent(token, true) }
                    .onFailure { message = "Общее согласие действует локально, но серверная синхронизация удалённой панели не удалась: ${it.message}. Удалённые запросы будут недоступны до синхронизации." }
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFFA6D8BF), onPrimary = Color(0xFF102019),
        background = Color(0xFF101419), surface = Color(0xFF191F26),
        onBackground = Color(0xFFE9EDF2), onSurface = Color(0xFFE9EDF2),
        secondary = Color(0xFF9CA8B5)
    )) {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            if (!consentAccepted) {
                ConsentScreen(
                    onAccept = {
                        val acceptedAt = System.currentTimeMillis()
                        prefs.edit().putBoolean("consent_v1", true)
                            .putBoolean("background_sync_consent", false)
                            .putString("consent_version", "2.0")
                            .putString("consent_scope", "account;device_status;owner_selected_files;notification_sync;screen_share;camera;microphone;location;backup_restore;remote_panel_requests")
                            .putLong("consent_timestamp", acceptedAt)
                            .putLong("consent_expires_at", acceptedAt + 365L * 24 * 60 * 60 * 1000)
                            .apply()
                        backgroundConsent = false
                        consentAccepted = true
                    }
                )
            } else {
                Column(modifier = Modifier.fillMaxSize().padding(18.dp)) {
                    Header()
                    Spacer(Modifier.height(16.dp))
                    if (sessionUser != null) {
                        Text("Вы вошли как ${sessionUser?.optString("username") ?: "пользователь"}", color = MaterialTheme.colorScheme.secondary)
                    }
                    NavBar(selectedScreen) { selectedScreen = it }
                    Spacer(Modifier.height(14.dp))
                    when (selectedScreen) {
                        "Обучение" -> EducationScreen(onOpenReference = { selectedScreen = "Справочник" })
                        "Главная" -> HomeScreen(
                            isLoggedIn = sessionUser != null,
                            onOpen = { selectedScreen = it },
                            serverUrl = BuildConfig.API_BASE_URL
                        )
                        "Безопасность" -> SecurityScreen(
                            backgroundConsent = backgroundConsent,
                            onOpenAccount = { selectedScreen = "Аккаунт" },
                            onBackgroundConsentChange = {
                                backgroundConsent = it
                                prefs.edit().putBoolean("background_sync_consent", it).apply()
                            },
                            onRevokeConsent = {
                                val tokenForRevocation = tokenStore.read()
                                prefs.edit().putBoolean("consent_v1", false)
                                    .putBoolean("background_sync_consent", false).apply()
                                backgroundConsent = false
                                consentAccepted = false
                                sessionUser = null
                                tokenStore.clear()
                                message = "Общее согласие отозвано локально. Синхронизация серверного отзыва выполняется отдельно; разрешения Android при необходимости отзовите в системных настройках."
                                if (tokenForRevocation != null) scope.launch {
                                    runCatching { api.setRemotePanelConsent(tokenForRevocation, false) }
                                        .onFailure { message = "Согласие отозвано локально, но серверный отзыв не синхронизирован: ${it.message}. Подключитесь к серверу и повторите отзыв, если удалённая панель ранее была включена." }
                                    runCatching { api.logout(tokenForRevocation) }
                                }
                            },
                            onLogout = {
                                scope.launch {
                                    val token = tokenStore.read()
                                    if (token != null) runCatching { api.logout(token) }
                                    tokenStore.clear()
                                    sessionUser = null
                                    message = "Сессия завершена на этом устройстве."
                                }
                            }
                        )
                        "Справочник" -> LibraryScreen(library, query, { query = it })
                        "Устройство" -> DeviceScreen()
                        "Медиа" -> DeviceToolsScreen(accessToken = tokenStore.read(), api = api)
                        "Аккаунт" -> AccountScreen(
                            username = username,
                            password = password,
                            registerMode = registerMode,
                            busy = busy,
                            message = message,
                            isLoggedIn = sessionUser != null,
                            onUsername = { username = it },
                            onPassword = { password = it },
                            onRegisterMode = { registerMode = it },
                            onSubmit = {
                                scope.launch {
                                    busy = true; message = ""
                                    try {
                                        if (registerMode) api.register(username.trim(), password)
                                        val result = api.login(username.trim(), password)
                                        val token = result.getString("access_token")
                                        tokenStore.save(token)
                                        sessionUser = api.me(token)
                                        password = ""
                                        message = "Вход выполнен."
                                    } catch (e: Exception) {
                                        message = e.message ?: "Не удалось выполнить запрос."
                                    } finally { busy = false }
                                }
                            },
                            onLogout = {
                                scope.launch {
                                    val token = tokenStore.read()
                                    if (token != null) runCatching { api.logout(token) }
                                    tokenStore.clear(); sessionUser = null
                                    message = "Вы вышли из аккаунта."
                                }
                            }
                        )
                        "Данные" -> DataScreen(
                            consentVersion = prefs.getString("consent_version", "1.0") ?: "1.0",
                            isLoggedIn = sessionUser != null,
                            busy = busy,
                            message = message,
                            onExport = {
                                scope.launch {
                                    busy = true; message = ""
                                    try {
                                        val token = tokenStore.read() ?: throw IllegalStateException("Сначала войдите в аккаунт.")
                                        pendingExportJson = api.exportAccount(token).toString(2)
                                        exportLauncher.launch("azavad-account-export.json")
                                    } catch (e: Exception) {
                                        pendingExportJson = null
                                        message = e.message ?: "Не удалось подготовить экспорт."
                                    } finally { busy = false }
                                }
                            },
                            onDelete = { confirmedPassword ->
                                scope.launch {
                                    busy = true; message = ""
                                    try {
                                        val token = tokenStore.read() ?: throw IllegalStateException("Сначала войдите в аккаунт.")
                                        api.deleteAccount(token, confirmedPassword)
                                        tokenStore.clear(); sessionUser = null
                                        message = "Аккаунт и связанные серверные данные удалены. Локальный офлайн-справочник сохранён."
                                    } catch (e: Exception) {
                                        message = e.message ?: "Не удалось удалить аккаунт."
                                    } finally { busy = false }
                                }
                            },
                            onWithdraw = {
                                scope.launch {
                                    val token = tokenStore.read()
                                    val serverRevoked = if (token != null) {
                                        try { api.logout(token); true } catch (_: Exception) { false }
                                    } else true
                                    prefs.edit().putBoolean("consent_v1", false).putBoolean("background_sync_consent", false).apply()
                                    tokenStore.clear(); sessionUser = null; consentAccepted = false
                                    message = if (serverRevoked) "Согласие отозвано; локальная сессия очищена." else "Локальное согласие отозвано и токен очищен. Серверная сессия могла остаться активной до истечения срока; подключитесь к серверу для её отзыва."
                                }
                            }
                        )
                        else -> HomeScreen(sessionUser != null, { selectedScreen = it }, BuildConfig.API_BASE_URL)
                    }
                    if (message.isNotBlank() && selectedScreen != "Аккаунт") {
                        Spacer(Modifier.height(10.dp))
                        Text(message, color = MaterialTheme.colorScheme.secondary, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun Header() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Surface(color = Color(0xFF26352F), shape = MaterialTheme.shapes.medium) {
            Text("A", modifier = Modifier.padding(horizontal = 15.dp, vertical = 9.dp), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text("AZAVAD", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Обучение первой помощи и безопасность", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
        }
    }
}

@Composable
private fun NavBar(selected: String, onSelect: (String) -> Unit) {
    val rows = listOf(
        listOf("Обучение", "Главная", "Справочник"),
        listOf("Безопасность", "Устройство", "Медиа"),
        listOf("Аккаунт", "Данные")
    )
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        rows.forEach { rowItems ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                rowItems.forEach { item ->
                    if (item == selected) Button(onClick = { onSelect(item) }, modifier = Modifier.weight(1f)) { Text(item, maxLines = 1) }
                    else OutlinedButton(onClick = { onSelect(item) }, modifier = Modifier.weight(1f)) { Text(item, maxLines = 1) }
                }
                if (rowItems.size < 3) Spacer(Modifier.weight((3 - rowItems.size).toFloat()))
            }
        }
    }
}

@Composable
private fun EducationScreen(onOpenReference: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Тактическая медицина: основы первой помощи", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Учебный материал для ознакомления. Он не заменяет практический курс, указания диспетчера экстренной службы или медицинского специалиста.", color = MaterialTheme.colorScheme.secondary)
        InfoCard("1. Безопасность места", "Перед приближением оцените угрозы для себя, пострадавшего и окружающих. Не входите в опасную зону; вызовите экстренные службы и следуйте указаниям диспетчера.", "") { }
        InfoCard("2. Первичная оценка", "Проверьте реакцию человека и нормальное дыхание. Попросите конкретного человека вызвать помощь и принести AED/автоматический наружный дефибриллятор, если он доступен.", "") { }
        InfoCard("3. Сильное кровотечение", "При безопасном доступе приложите устойчивое прямое давление к ране чистой тканью или перевязочным материалом. Не извлекайте застрявшие предметы; при тяжёлом кровотечении срочно вызывайте помощь.", "") { }
        InfoCard("4. Нет нормального дыхания", "Позвоните в экстренную службу на громкой связи и следуйте инструкциям диспетчера по сердечно-лёгочной реанимации. Используйте AED, если он доступен, и выполняйте голосовые подсказки устройства.", "") { }
        InfoCard("5. Ожидание помощи", "Защитите человека от холода, наблюдайте за дыханием и изменениями состояния. Не давайте еду, напитки или лекарства без соответствующих указаний. Не перемещайте человека с подозрением на травму позвоночника, если нет непосредственной опасности.", "") { }
        InfoCard("6. Учебный чек-лист", "Безопасность места → вызов экстренной помощи → проверка реакции и дыхания → помощь по уровню подготовки → наблюдение до прибытия специалистов.", "Открыть справочник") { onOpenReference() }
        Text("В экстренной ситуации используйте местный номер экстренной службы. Доступность служб и протоколы могут различаться по стране.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
    }
}

@Composable
private fun ConsentScreen(onAccept: () -> Unit) {
    var accepted by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Header(); Spacer(Modifier.height(24.dp))
        Text("Одно согласие — все функции AZAVAD", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("Мы сделали настройку максимально простой. Прочитайте краткое описание и подтвердите одно общее согласие. Оно действует 365 дней и может быть отозвано в настройках приложения.", color = MaterialTheme.colorScheme.secondary)
        Spacer(Modifier.height(18.dp))
        Card { Column(Modifier.padding(16.dp)) {
            Text("Что охватывает согласие", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("""• Учётная запись, связь с сервером и состояние устройства.
• Фоновая синхронизация и журнал уведомлений.
• Передача выбранных вами файлов, резервное копирование и восстановление.
• Запросы на демонстрацию экрана, использование камеры, микрофона и геолокации.
• Получение запросов от вашей внешней панели и отправка результатов.""")
            Spacer(Modifier.height(8.dp))
            Text("Общее согласие разрешает приложению предлагать эти функции, когда они доступны. Оно не означает постоянную запись или наблюдение и не обходит системные ограничения Android. Для функций, требующих системного разрешения (например, захвата экрана, камеры, микрофона, уведомлений или фоновой геолокации), Android может показать отдельный запрос или экран настроек. Вы можете отказать в конкретной функции, остановить её или отозвать общее согласие.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
        } }
        Spacer(Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = accepted, onCheckedChange = { accepted = it })
            Text("Я добровольно даю общее согласие на описанные функции на срок 365 дней и понимаю, что могу отозвать его.")
        }
        Spacer(Modifier.height(14.dp))
        Button(onClick = onAccept, enabled = accepted, modifier = Modifier.fillMaxWidth()) { Text("Дать согласие и продолжить") }
    }
}

@Composable
private fun HomeScreen(isLoggedIn: Boolean, onOpen: (String) -> Unit, serverUrl: String) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Центр безопасности", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Состояние функций показывается явно. Неизвестное состояние не считается безопасным.", color = MaterialTheme.colorScheme.secondary)
        InfoCard("Справочник", "Материалы доступны офлайн на этом устройстве.", "Открыть справочник") { onOpen("Справочник") }
        InfoCard("Устройство", "Диагностика Android пока частично реализована.", "Проверить статус") { onOpen("Устройство") }
        InfoCard("Учётная запись", if (isLoggedIn) "Сессия активна на этом устройстве." else "Войдите, чтобы использовать серверные функции.", if (isLoggedIn) "Открыть аккаунт" else "Войти") { onOpen("Аккаунт") }
        Card { Column(Modifier.padding(16.dp)) {
            Text("Подключение API", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Text(serverUrl, color = MaterialTheme.colorScheme.secondary, style = MaterialTheme.typography.bodySmall)
            Text("Для подключения задайте AZAVAD_API_BASE_URL в Gradle properties. Сервер должен иметь действительный HTTPS-сертификат.", style = MaterialTheme.typography.bodySmall)
        } }
    }
}

@Composable
private fun InfoCard(title: String, body: String, action: String, onClick: () -> Unit) {
    Card { Column(Modifier.fillMaxWidth().padding(16.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp)); Text(body, color = MaterialTheme.colorScheme.secondary)
        if (action.isNotBlank()) {
            Spacer(Modifier.height(12.dp)); OutlinedButton(onClick = onClick) { Text(action) }
        }
    } }
}

@Composable
private fun SecurityScreen(backgroundConsent: Boolean, onOpenAccount: () -> Unit, onBackgroundConsentChange: (Boolean) -> Unit, onRevokeConsent: () -> Unit, onLogout: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Настройки безопасности", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Card { Column(Modifier.padding(16.dp)) {
            Text("Фоновые функции", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Разрешение на фоновую синхронизацию")
                    Text("Сейчас фоновая синхронизация ещё не реализована. Переключатель сохраняет только ваше предпочтение.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                }
                Switch(checked = backgroundConsent, onCheckedChange = onBackgroundConsentChange)
            }
        } }
        InfoCard("История событий", "Журнал аудита сервера доступен после входа; локальная история ещё не подключена.", "Перейти к аккаунту", onOpenAccount)
        OutlinedButton(onClick = onRevokeConsent, modifier = Modifier.fillMaxWidth()) { Text("Отозвать общее согласие и завершить сессию") }
        OutlinedButton(onClick = onLogout) { Text("Завершить серверную сессию") }
    }
}

@Composable
private fun LibraryScreen(items: List<KnowledgeItem>, query: String, onQuery: (String) -> Unit) {
    val filtered = items.filter { "${it.title} ${it.category} ${it.summary}".contains(query, ignoreCase = true) }
    Column(modifier = Modifier.fillMaxSize()) {
        Text("Автономный справочник", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = query, onValueChange = onQuery, modifier = Modifier.fillMaxWidth(), label = { Text("Поиск по материалам") }, singleLine = true)
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(filtered, key = { it.id }) { item ->
                Card { Column(Modifier.fillMaxWidth().padding(15.dp)) {
                    Text(item.category.uppercase(), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall)
                    Spacer(Modifier.height(5.dp)); Text(item.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp)); Text(item.summary)
                    if (item.sourceTitle.isNotBlank()) {
                        Spacer(Modifier.height(8.dp)); Text("Источник: ${item.sourceTitle}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                        if (item.sourceUrl.isNotBlank()) Text(item.sourceUrl, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    }
                } }
            }
            if (filtered.isEmpty()) item { Text("Ничего не найдено.", color = MaterialTheme.colorScheme.secondary) }
        }
    }
}

@Composable
private fun DeviceScreen() {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Диагностика устройства", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        InfoCard("Версия Android", android.os.Build.VERSION.RELEASE ?: "Не определено", "") { }
        InfoCard("Уровень API", android.os.Build.VERSION.SDK_INT.toString(), "") { }
        InfoCard("Модель устройства", "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}", "") { }
        Card { Column(Modifier.padding(16.dp)) {
            Text("Проверки безопасности", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            Text("Состояние шифрования, блокировки экрана, целостности приложения и обновлений безопасности ещё не проверяется. Не интерпретируйте этот экран как полный аудит устройства.", color = MaterialTheme.colorScheme.secondary)
        } }
    }
}

@Composable
private fun AccountScreen(
    username: String, password: String, registerMode: Boolean, busy: Boolean, message: String,
    isLoggedIn: Boolean, onUsername: (String) -> Unit, onPassword: (String) -> Unit,
    onRegisterMode: (Boolean) -> Unit, onSubmit: () -> Unit, onLogout: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Учётная запись", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        if (isLoggedIn) {
            Text("Серверная сессия активна.", color = MaterialTheme.colorScheme.primary)
            OutlinedButton(onClick = onLogout) { Text("Выйти и отозвать сессию") }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!registerMode) Button(onClick = { onRegisterMode(false) }, modifier = Modifier.weight(1f)) { Text("Вход") }
                else OutlinedButton(onClick = { onRegisterMode(false) }, modifier = Modifier.weight(1f)) { Text("Вход") }
                if (registerMode) Button(onClick = { onRegisterMode(true) }, modifier = Modifier.weight(1f)) { Text("Регистрация") }
                else OutlinedButton(onClick = { onRegisterMode(true) }, modifier = Modifier.weight(1f)) { Text("Регистрация") }
            }
            OutlinedTextField(value = username, onValueChange = onUsername, modifier = Modifier.fillMaxWidth(), label = { Text("Имя пользователя") }, singleLine = true)
            OutlinedTextField(value = password, onValueChange = onPassword, modifier = Modifier.fillMaxWidth(), label = { Text("Пароль (не менее 12 символов)") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
            Button(onClick = onSubmit, enabled = !busy && username.length >= 3 && password.isNotEmpty(), modifier = Modifier.fillMaxWidth()) {
                Text(if (busy) "Выполняется…" else if (registerMode) "Создать аккаунт и войти" else "Войти")
            }
            if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.secondary)
            Text("Пароль передаётся только по HTTPS. Не используйте этот сервер в интернете до настройки production-защиты.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
        }
    }
}

@Composable
private fun DataScreen(
    consentVersion: String,
    isLoggedIn: Boolean,
    busy: Boolean,
    message: String,
    onExport: () -> Unit,
    onDelete: (String) -> Unit,
    onWithdraw: () -> Unit
) {
    var deletePassword by remember { mutableStateOf("") }
    var confirmDelete by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Согласия и данные", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Card { Column(Modifier.padding(16.dp)) {
            Text("Локальное согласие", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp)); Text("Версия политики: $consentVersion")
            Text("Отзыв очищает локальную сессию и отключает согласие в приложении. Если серверная сессия ещё активна, приложение пытается отозвать её до удаления токена.", color = MaterialTheme.colorScheme.secondary)
            Spacer(Modifier.height(12.dp)); Button(onClick = onWithdraw, enabled = !busy) { Text("Отозвать согласие и очистить локальную сессию") }
        } }
        Card { Column(Modifier.padding(16.dp)) {
            Text("Экспорт серверных данных", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            Text("Создаёт JSON-файл с данными вашего аккаунта, согласиями, устройствами, событиями и доступной историей аудита. Пароль и токены в экспорт не включаются.", color = MaterialTheme.colorScheme.secondary)
            Spacer(Modifier.height(10.dp))
            Button(onClick = onExport, enabled = isLoggedIn && !busy, modifier = Modifier.fillMaxWidth()) {
                Text(if (busy) "Выполняется…" else "Экспортировать мои данные")
            }
            if (!isLoggedIn) Text("Для экспорта войдите в аккаунт.", color = MaterialTheme.colorScheme.secondary, style = MaterialTheme.typography.bodySmall)
        } }
        Card { Column(Modifier.padding(16.dp)) {
            Text("Удаление аккаунта", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.error)
            Spacer(Modifier.height(6.dp))
            Text("Необратимо удаляет серверный аккаунт и связанные с ним записи. Локальный офлайн-справочник останется на устройстве. Перед удалением экспортируйте данные, если они нужны.", color = MaterialTheme.colorScheme.secondary)
            if (isLoggedIn) {
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = deletePassword,
                    onValueChange = { deletePassword = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Введите пароль для подтверждения") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    enabled = !busy
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = confirmDelete, onCheckedChange = { confirmDelete = it }, enabled = !busy)
                    Text("Я понимаю, что удаление серверных данных необратимо.")
                }
                Button(
                    onClick = {
                        onDelete(deletePassword)
                        deletePassword = ""
                        confirmDelete = false
                    },
                    enabled = !busy && deletePassword.isNotBlank() && confirmDelete,
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Удалить мой аккаунт") }
            } else Text("Для удаления аккаунта войдите в него.", color = MaterialTheme.colorScheme.secondary, style = MaterialTheme.typography.bodySmall)
        } }
        if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.secondary)
        Text("Удаление аккаунта удаляет данные в активной базе приложения; удаление из внешних резервных копий зависит от политики хранения сервера.", color = MaterialTheme.colorScheme.secondary, style = MaterialTheme.typography.bodySmall)
    }
}

private fun loadLibrary(json: String): List<KnowledgeItem> {
    val array = JSONArray(json)
    return (0 until array.length()).mapNotNull { index ->
        val item = array.optJSONObject(index) ?: return@mapNotNull null
        KnowledgeItem(
            id = item.optString("id"), title = item.optString("title"),
            category = item.optString("category"), summary = item.optString("summary"),
            sourceTitle = item.optString("sourceTitle"), sourceUrl = item.optString("sourceUrl")
        )
    }
}
