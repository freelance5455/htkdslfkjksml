package org.azavad.app

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Encrypts sensitive local strings (such as notification history) using a device-bound Android Keystore key. */
object EncryptedLocalStore {
    private const val PREFS = "azavad_encrypted_local_data"
    private const val ALIAS = "azavad.localdata.aes.v1"

    private fun key(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (keyStore.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true).build())
        return generator.generateKey()
    }

    fun write(context: Context, name: String, value: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("${name}_iv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
            .putString("${name}_data", Base64.encodeToString(encrypted, Base64.NO_WRAP)).apply()
    }

    fun read(context: Context, name: String): String? {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val iv = prefs.getString("${name}_iv", null)
        val data = prefs.getString("${name}_data", null)
        if (iv != null && data != null) {
            return try {
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)))
                String(cipher.doFinal(Base64.decode(data, Base64.NO_WRAP)), Charsets.UTF_8)
            } catch (_: Exception) {
                remove(context, name)
                null
            }
        }
        // Migrate a legacy plaintext value once, then remove the plaintext copy.
        val legacyPrefs = context.getSharedPreferences("azavad_preferences", Context.MODE_PRIVATE)
        val legacy = legacyPrefs.getString(name, null) ?: return null
        return try {
            write(context, name, legacy)
            legacyPrefs.edit().remove(name).apply()
            legacy
        } catch (_: Exception) {
            legacyPrefs.edit().remove(name).apply()
            null
        }
    }

    fun remove(context: Context, name: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .remove("${name}_iv").remove("${name}_data").apply()
        context.getSharedPreferences("azavad_preferences", Context.MODE_PRIVATE).edit().remove(name).apply()
    }
}
