package org.azavad.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import org.json.JSONArray
import java.io.IOException
import java.io.File
import java.io.OutputStream
import java.io.RandomAccessFile
import java.util.concurrent.TimeUnit

class ApiClient(private val baseUrl: String = BuildConfig.API_BASE_URL) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .callTimeout(20, TimeUnit.SECONDS)
        .build()
    private val jsonType = "application/json; charset=utf-8".toMediaType()
    private val backupClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .callTimeout(0, TimeUnit.MILLISECONDS)
        .build()
    private val backupChunkBytes = 8 * 1024 * 1024
    private val maxBackupBytes = 10_000_000_000L

    suspend fun setRemotePanelConsent(token: String, granted: Boolean): JSONObject = request(
        path = "/v1/consents", method = "POST", token = token,
        body = JSONObject().put("feature", "remote_panel").put("policy_version", "2.0")
            .put("granted", granted).put("purpose", "device_monitoring")
            .put("owner_confirmed", true).put("expires_in_days", 365)
    )

    suspend fun reportDeviceHeartbeat(token: String, deviceId: Int, status: JSONObject): JSONObject = request(
        path = "/v1/devices/$deviceId/heartbeat", method = "POST", token = token, body = status
    )

    suspend fun pollRemoteCommands(token: String, deviceId: Int): JSONArray = withContext(Dispatchers.IO) {
        if (!baseUrl.startsWith("https://", ignoreCase = true)) throw IOException("Remote requests require HTTPS")
        val req = Request.Builder().url("$baseUrl/v1/devices/$deviceId/commands/pending")
            .header("Accept", "application/json").header("Authorization", "Bearer $token").get().build()
        client.newCall(req).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail = runCatching { JSONObject(body).optString("detail") }.getOrDefault("Request failed (${response.code})")
                throw IOException(detail.ifBlank { "Request failed (${response.code})" })
            }
            JSONArray(body)
        }
    }

    suspend fun uploadScreenFrame(token: String, deviceId: Int, commandId: Int, jpeg: ByteArray): JSONObject = withContext(Dispatchers.IO) {
        if (!baseUrl.startsWith("https://", ignoreCase = true)) throw IOException("Screen sharing requires HTTPS")
        if (jpeg.isEmpty() || jpeg.size > 512 * 1024) throw IOException("Screen frame must be between 1 byte and 512 KiB")
        val req = Request.Builder().url("$baseUrl/v1/devices/$deviceId/screen-sessions/$commandId/frame")
            .header("Authorization", "Bearer $token")
            .header("Content-Type", "image/jpeg")
            .put(jpeg.toRequestBody("image/jpeg".toMediaType()))
            .build()
        client.newCall(req).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail = runCatching { JSONObject(body).optString("detail") }.getOrDefault("Frame upload failed (${response.code})")
                throw IOException(detail.ifBlank { "Frame upload failed (${response.code})" })
            }
            JSONObject(body)
        }
    }

    suspend fun reportRemoteCommand(token: String, deviceId: Int, commandId: Int, status: String, summary: String): JSONObject {
        require(status in setOf("accepted", "rejected", "running", "completed", "failed")) { "Unsupported command status" }
        return request(path = "/v1/devices/$deviceId/commands/$commandId/result", method = "POST", token = token,
            body = JSONObject().put("status", status).put("result_summary", summary.take(500)))
    }

    suspend fun setDeviceConsent(token: String, feature: String, granted: Boolean): JSONObject {
        val sensitive = feature in setOf("camera", "microphone", "file_access", "screen_share")
        return request(path = "/v1/consents", method = "POST", token = token,
            body = JSONObject().put("feature", feature).put("policy_version", "1.0")
                .put("granted", granted).put("purpose", if (sensitive) "emergency_safety" else "device_monitoring")
                .put("owner_confirmed", true).put("expires_in_days", 365))
    }

    suspend fun setBackupConsent(token: String, granted: Boolean): JSONObject = request(
        path = "/v1/consents", method = "POST", token = token,
        body = JSONObject().put("feature", "backup").put("policy_version", "1.0")
            .put("granted", granted).put("purpose", "backup")
            .put("owner_confirmed", true).put("expires_in_days", 365)
    )

    suspend fun registerDevice(token: String, deviceKey: String, displayName: String, appVersion: String): JSONObject =
        request(path = "/v1/devices", method = "POST", token = token,
            body = JSONObject().put("device_key", deviceKey).put("display_name", displayName).put("app_version", appVersion))

    suspend fun listBackups(token: String): JSONObject = request(path = "/v1/backups", token = token)

    suspend fun syncNotificationHistory(token: String, history: JSONArray): JSONObject {
        if (history.length() == 0) throw IOException("Нет уведомлений для отправки")
        val batch = JSONArray()
        val start = (history.length() - 100).coerceAtLeast(0)
        for (i in start until history.length()) batch.put(history.getJSONObject(i))
        return request(path = "/v1/notification-events/sync", method = "POST", token = token,
            body = JSONObject().put("items", batch))
    }

    suspend fun listNotificationHistory(token: String): JSONObject = request(path = "/v1/notification-events", token = token)

    suspend fun clearNotificationHistory(token: String) {
        withContext(Dispatchers.IO) {
            if (!baseUrl.startsWith("https://", ignoreCase = true)) throw IOException("Notification sync requires HTTPS")
            val req = Request.Builder().url("$baseUrl/v1/notification-events")
                .header("Authorization", "Bearer $token").delete().build()
            client.newCall(req).execute().use { response ->
                if (!response.isSuccessful) throw IOException("Notification history deletion failed (${response.code})")
            }
        }
    }

    suspend fun uploadBackup(
        token: String,
        file: File,
        resumeId: String? = null,
        onUploadId: (String) -> Unit = {},
        onProgress: (Long, Long) -> Unit = { _, _ -> }
    ): JSONObject = withContext(Dispatchers.IO) {
        if (!baseUrl.startsWith("https://", ignoreCase = true)) throw IOException("Backup requires HTTPS")
        val size = file.length()
        val initialModifiedAt = file.lastModified()
        if (!file.isFile || size < 0 || size > maxBackupBytes) throw IOException("File must be a readable file no larger than 10 GB")
        val init = if (resumeId == null) {
            request(path = "/v1/backups", method = "POST", token = token,
                body = JSONObject().put("filename", file.name).put("size_bytes", size)
                    .put("content_type", java.net.URLConnection.guessContentTypeFromName(file.name) ?: "application/octet-stream"))
        } else {
            request(path = "/v1/backups/$resumeId/status", token = token)
        }
        val id = init.getString("id")
        if (init.optString("status") == "complete") return@withContext init
        if (init.optLong("size_bytes", size) != size) throw IOException("The selected file changed; this upload cannot be resumed")
        val chunkSize = init.optInt("chunk_size", backupChunkBytes)
        if (chunkSize !in 1..backupChunkBytes) throw IOException("Server returned an unsupported chunk size")
        onUploadId(id)
        val chunkCount = init.optInt("chunk_count", maxOf(1, ((size + chunkSize - 1) / chunkSize).toInt()))
        val received = mutableSetOf<Int>()
        val uploaded = init.optJSONArray("uploaded_chunks")
        if (uploaded != null) for (i in 0 until uploaded.length()) received.add(uploaded.getJSONObject(i).optInt("index", -1))
        var sent = 0L
        for (index in received) {
            if (index in 0 until chunkCount) sent += minOf(chunkSize.toLong(), (size - index.toLong() * chunkSize).coerceAtLeast(0))
        }
        withContext(Dispatchers.Main) { onProgress(sent.coerceAtMost(size), size) }
        try {
            RandomAccessFile(file, "r").use { input ->
                for (index in 0 until chunkCount) {
                    val expected = minOf(chunkSize.toLong(), (size - index.toLong() * chunkSize).coerceAtLeast(0)).toInt()
                    if (index in received) continue
                    val chunk = ByteArray(expected)
                    input.seek(index.toLong() * chunkSize)
                    input.readFully(chunk)
                    val chunkRequest = Request.Builder().url("$baseUrl/v1/backups/$id/chunks/$index")
                        .header("Authorization", "Bearer $token")
                        .header("Accept", "application/json")
                        .put(chunk.toRequestBody("application/octet-stream".toMediaType()))
                        .build()
                    backupClient.newCall(chunkRequest).execute().use { response ->
                        val bodyText = response.body?.string().orEmpty()
                        if (!response.isSuccessful) throw IOException("Chunk $index upload failed (${response.code}): ${try { JSONObject(bodyText).optString("detail") } catch (_: Exception) { "server error" }}")
                    }
                    sent += expected
                    withContext(Dispatchers.Main) { onProgress(sent.coerceAtMost(size), size) }
                }
            }
            if (file.length() != size || file.lastModified() != initialModifiedAt) {
                throw IOException("The local file changed during upload; this backup was left resumable but not finalized")
            }
            request(path = "/v1/backups/$id/complete", method = "POST", token = token)
        } catch (e: Exception) {
            // Keep the encrypted staging chunks and the ID so a later attempt can resume.
            throw e
        }
    }

    suspend fun deleteBackup(token: String, backupId: String) {
        withContext(Dispatchers.IO) {
            if (!baseUrl.startsWith("https://", ignoreCase = true)) throw IOException("Backup requires HTTPS")
            val request = Request.Builder().url("$baseUrl/v1/backups/$backupId")
                .header("Authorization", "Bearer $token").delete().build()
            backupClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) throw IOException("Backup deletion failed (${response.code})")
            }
        }
    }

    suspend fun downloadBackup(token: String, backupId: String, destination: OutputStream) = withContext(Dispatchers.IO) {
        if (!baseUrl.startsWith("https://", ignoreCase = true)) throw IOException("Backup requires HTTPS")
        val request = Request.Builder().url("$baseUrl/v1/backups/$backupId/download")
            .header("Authorization", "Bearer $token").get().build()
        backupClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                val body = response.body?.string().orEmpty()
                throw IOException("Restore failed (${response.code}): ${try { JSONObject(body).optString("detail") } catch (_: Exception) { "server error" }}")
            }
            val source = response.body?.byteStream() ?: throw IOException("Empty backup response")
            source.use { it.copyTo(destination, 64 * 1024) }
            destination.flush()
        }
    }

    suspend fun register(username: String, password: String): JSONObject = request(
        path = "/v1/auth/register",
        method = "POST",
        body = JSONObject().put("username", username).put("password", password)
    )

    suspend fun login(username: String, password: String): JSONObject = request(
        path = "/v1/auth/login",
        method = "POST",
        body = JSONObject().put("username", username).put("password", password)
    )

    suspend fun me(token: String): JSONObject = request(path = "/v1/auth/me", token = token)

    suspend fun exportAccount(token: String): JSONObject = request(path = "/v1/account/export", token = token)

    suspend fun deleteAccount(token: String, password: String) {
        request(
            path = "/v1/account",
            method = "DELETE",
            token = token,
            body = JSONObject().put("password", password).put("confirm", true)
        )
    }

    suspend fun logout(token: String) {
        request(path = "/v1/auth/logout", method = "POST", token = token)
    }

    private suspend fun request(
        path: String,
        method: String = "GET",
        token: String? = null,
        body: JSONObject? = null
    ): JSONObject = withContext(Dispatchers.IO) {
        if (!baseUrl.startsWith("https://", ignoreCase = true)) {
            throw IOException("API URL must use HTTPS. Configure AZAVAD_API_BASE_URL in Gradle properties.")
        }
        val builder = Request.Builder().url(baseUrl + path)
            .header("Accept", "application/json")
        if (token != null) builder.header("Authorization", "Bearer $token")
        if (body != null) builder.method(method, body.toString().toRequestBody(jsonType))
        else if (method != "GET") builder.method(method, ByteArray(0).toRequestBody(null))
        client.newCall(builder.build()).execute().use { response ->
            val text = response.body?.string().orEmpty()
            val parsed = try { if (text.isBlank()) JSONObject() else JSONObject(text) }
            catch (_: Exception) { JSONObject() }
            if (!response.isSuccessful) {
                val detail = parsed.optString("detail", "Request failed (${response.code})")
                throw IOException(detail)
            }
            parsed
        }
    }
}
