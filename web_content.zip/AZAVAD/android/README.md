# AZAVAD Android client

## Build
- Android Studio with JDK 17+
- Android SDK Platform 35
- Gradle dependencies resolved by Android Studio

Open this directory as the project root, sync Gradle, then run the `app` configuration on an emulator/device.

The API URL is compiled from the Gradle property `AZAVAD_API_BASE_URL`; default is `https://localhost:8443` and will not work unless a valid HTTPS endpoint is available. Set it to a real HTTPS host for integration. The app intentionally rejects plain HTTP and the manifest disables cleartext traffic.

## Implemented in this prototype
- First-run umbrella consent with version, timestamp, 365-day expiry, and visible revoke action.
- Registration/login UI; token encryption using Android Keystore AES-GCM.
- Server registration and persistence of the registered device ID.
- Server synchronization of the unified `remote_panel` consent when an authenticated session is available; the server fails closed if consent is missing or expired.
- Typed remote-request queue with explicit on-device Accept/Reject controls. Polling runs only while the device-tools screen is resumed.
- Owner-approved request handlers for device status, opening the visible system camera UI, opening the visible system recorder, the Android document picker, notification-history sync, and backup upload of files the owner previously selected.
- Short-lived requests, result reporting, server audit events, and cancellation when the owner revokes remote-panel consent.

## Not implemented / not verified
- Screen sharing / MediaProjection streaming and one-time or time-limited location delivery. Such requests are explicitly failed instead of being represented as completed.
- Camera/microphone streaming to the panel. The current handlers save local files only and do not transmit media.
- A real Android Gradle build, APK installation, emulator/physical-device validation, and full panel-to-phone end-to-end tests.
- Full device encryption/screen-lock diagnostics, verified signed content updates, complete data cleanup workflow, and production hardening.

No hidden activation or arbitrary shell-command execution is implemented. Sensitive actions require an on-device confirmation and visible Android UI/system permissions.


## Device media and server backups
- Camera capture is started only from the visible user action and uses the Android system camera preview; microphone recording is handed off to a visible system recorder.
- The notification listener requires the owner to enable it in Android settings. The local notification history is encrypted using a device-bound Android Keystore AES-GCM key. Notification history is not automatically uploaded; the owner must add an export to the backup queue.
- File selection uses Android's system document picker. Files are streamed to the app's private directory and capped at 10,000,000,000 bytes per file.
- Server backup requires login and a separate, explicit 365-day consent that can be revoked. Uploads use 8 MiB HTTPS chunks, resume from server-confirmed chunks after interruptions, and are integrity-checked before being marked complete. Restore always asks the owner to choose the destination.
- To enable server backup in a real deployment, configure `AZAVAD_BACKUP_ENCRYPTION_KEY` as a random 32-byte URL-safe Base64 key in the server secret manager and set a persistent `AZAVAD_BACKUP_DIR`. Do not use the development fallback key for real data.
- The Android Gradle build, APK installation, and real-device tests remain unverified in this environment.

### Background location permission
The Media screen contains a separate, revocable consent and a guided Android permission flow for foreground/background location. On Android 11+, the user must complete the background-location choice in system settings. The screen reports the permission state and whether device location services are enabled. This is only permission setup; this version does not collect or transmit location coordinates.

