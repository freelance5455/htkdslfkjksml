(() => {
  const $ = (id) => document.getElementById(id);
  let token = null;
  let me = null;
  let commandRefreshTimer = null;
  let screenPreviewTimer = null;
  let screenFrameObjectUrl = null;
  const loginPanel = $('login-panel');
  const dashboard = $('dashboard');
  const sessionControls = $('session-controls');

  function notify(message, bad = false) {
    const el = $('notice');
    el.textContent = message;
    el.className = 'notice show' + (bad ? ' bad' : '');
  }
  async function api(path, options = {}) {
    const headers = new Headers(options.headers || {});
    headers.set('Content-Type', 'application/json');
    if (token) headers.set('Authorization', `Bearer ${token}`);
    const response = await fetch(path, { ...options, headers });
    if (response.status === 204) return null;
    const body = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(body.detail || `Request failed (${response.status})`);
    return body;
  }
  function cell(text) {
    const td = document.createElement('td');
    td.textContent = text == null ? '—' : String(text);
    return td;
  }
  function pill(text, off = false) {
    const span = document.createElement('span');
    span.className = 'pill' + (off ? ' off' : '');
    span.textContent = text;
    return span;
  }
  async function loadUsers() {
    const tbody = $('users-table');
    tbody.replaceChildren();
    const users = await api('/v1/admin/users');
    $('user-count').textContent = users.length;
    for (const user of users) {
      const tr = document.createElement('tr');
      tr.append(cell(user.id), cell(user.username), cell(user.role));
      const state = document.createElement('td');
      state.append(pill(user.disabled ? 'Отключён' : 'Активен', user.disabled));
      tr.append(state);
      const actionCell = document.createElement('td');
      if (user.id !== me.id) {
        const button = document.createElement('button');
        button.className = 'secondary row-action';
        button.textContent = user.disabled ? 'Включить' : 'Отключить';
        button.addEventListener('click', async () => {
          button.disabled = true;
          try {
            await api(`/v1/admin/users/${user.id}`, { method: 'PATCH', body: JSON.stringify({ disabled: !user.disabled }) });
            notify(user.disabled ? 'Учётная запись активирована; войдите заново.' : 'Учётная запись отключена, её активные сессии отозваны.');
            await loadUsers();
          } catch (e) { notify(e.message, true); button.disabled = false; }
        });
        actionCell.append(button);
      } else actionCell.textContent = 'Текущая учётная запись';
      tr.append(actionCell); tbody.append(tr);
    }
  }
  async function loadLibrary() {
    const items = await api('/v1/admin/library');
    const tbody = $('library-table'); tbody.replaceChildren();
    for (const item of items) {
      const tr = document.createElement('tr');
      tr.append(cell(item.id), cell(`${item.title} (${item.slug})`), cell(item.category), cell(item.status === 'published' ? 'Опубликован' : 'Черновик'), cell(item.published_version ?? '—'));
      const actionCell = document.createElement('td');
      const button = document.createElement('button'); button.className = 'secondary row-action'; button.textContent = 'Опубликовать';
      button.addEventListener('click', async () => {
        button.disabled = true;
        try {
          const result = await api(`/v1/admin/library/${item.id}/publish`, { method: 'POST' });
          notify(`Материал опубликован: версия ${result.version}, подпись Ed25519 сформирована.`);
          await loadLibrary(); await loadAudit();
        } catch (e) { notify(e.message, true); button.disabled = false; }
      });
      actionCell.append(button); tr.append(actionCell); tbody.append(tr);
    }
    if (!items.length) { const tr = document.createElement('tr'); const td = cell('Материалов пока нет'); td.colSpan = 6; td.className = 'muted'; tr.append(td); tbody.append(tr); }
  }
  async function loadAudit() {
    const rows = await api('/v1/admin/audit');
    $('audit-count').textContent = rows.length;
    const tbody = $('audit-table'); tbody.replaceChildren();
    for (const item of rows) {
      const tr = document.createElement('tr');
      tr.append(cell(item.created_at), cell(item.actor_user_id), cell(item.action), cell(`${item.target_type}${item.target_id ? ' #' + item.target_id : ''}`), cell(item.outcome));
      tbody.append(tr);
    }
  }

  async function loadDevices() {
    const devices = await api('/v1/admin/devices');
    const tbody = $('devices-table'); tbody.replaceChildren();
    for (const device of devices) {
      const tr = document.createElement('tr');
      const heartbeatAt = device.heartbeat_at ? Date.parse(device.heartbeat_at) : NaN;
      const hasHeartbeat = Number.isFinite(heartbeatAt);
      const online = hasHeartbeat && (Date.now() - heartbeatAt) < 45000;
      const connectionLabel = !hasHeartbeat ? 'СТАТУС НЕИЗВЕСТЕН' : online ? 'НА СВЯЗИ' : 'НЕ В СЕТИ';
      const battery = Number.isInteger(device.battery_percent) ? ` · батарея ${device.battery_percent}%` : '';
      const charging = device.charging === true ? ' · зарядка' : '';
      const network = device.network_connected === true ? ' · сеть есть' : device.network_connected === false ? ' · нет сети' : '';
      const foreground = device.app_foreground === true ? ' · приложение открыто' : device.app_foreground === false ? ' · приложение неактивно' : '';
      const statusText = `${connectionLabel}${battery}${charging}${network}${foreground} · последняя связь: ${device.heartbeat_at || device.last_seen_at || 'неизвестно'}`;
      tr.append(cell(device.username), cell(device.display_name), cell(device.app_version), cell(device.device_key), cell(statusText));
      const action = document.createElement('td');
      const select = document.createElement('select');
      select.setAttribute('aria-label', `Запрос для ${device.display_name}`);
      const choices = [
        ['device_status', 'Проверить статус'], ['backup_create_request', 'Запросить резервную копию'],
        ['file_picker_request', 'Запросить выбор файлов'], ['notification_sync_request', 'Запросить синхронизацию уведомлений'],
        ['screen_share_request', 'Запросить показ экрана'], ['camera_session_request', 'Запросить сессию камеры'],
        ['microphone_session_request', 'Запросить сессию микрофона'], ['location_once_request', 'Запросить геолокацию один раз'],
        ['location_session_request', 'Запросить временную передачу геолокации']
      ];
      for (const [value, label] of choices) { const option = document.createElement('option'); option.value = value; option.textContent = label; select.append(option); }
      const button = document.createElement('button'); button.className = 'secondary row-action'; button.textContent = 'Отправить запрос';
      button.addEventListener('click', async () => {
        button.disabled = true;
        try { await api(`/v1/admin/devices/${device.id}/commands`, { method: 'POST', body: JSON.stringify({ command_type: select.value, expires_in_minutes: 10 }) }); notify('Запрос добавлен в очередь. Для чувствительных функций требуется подтверждение на телефоне.'); await loadCommands(); }
        catch (e) { notify(e.message, true); }
        finally { button.disabled = false; }
      });
      action.append(select, button); tr.append(action); tbody.append(tr);
    }
    const screenSelect = $('screen-device-select');
    if (screenSelect) {
      const previous = screenSelect.value;
      screenSelect.replaceChildren();
      const placeholder = document.createElement('option'); placeholder.value = ''; placeholder.textContent = 'Выберите устройство'; screenSelect.append(placeholder);
      for (const device of devices) {
        const option = document.createElement('option'); option.value = String(device.id); option.textContent = `${device.username} · ${device.display_name} (#${device.id})`; screenSelect.append(option);
      }
      if ([...screenSelect.options].some(option => option.value === previous)) screenSelect.value = previous;
    }
    if (!devices.length) { const tr = document.createElement('tr'); const td = cell('Устройства пока не зарегистрированы'); td.colSpan = 6; td.className = 'muted'; tr.append(td); tbody.append(tr); }
  }

  async function loadCommands() {
    const commands = await api('/v1/admin/commands');
    const devices = await api('/v1/admin/devices');
    const deviceNames = new Map(devices.map(d => [d.id, `${d.username} · ${d.display_name}`]));
    const tbody = $('commands-table'); tbody.replaceChildren();
    for (const command of commands) {
      const tr = document.createElement('tr');
      tr.append(cell(command.id), cell(deviceNames.get(command.device_id) || `#${command.device_id}`), cell(command.command_type), cell(command.status), cell(command.expires_at), cell(command.result_summary));
      const actionCell = document.createElement('td');
      if (['pending', 'delivered', 'accepted'].includes(command.status)) {
        const cancel = document.createElement('button'); cancel.className = 'secondary row-action'; cancel.textContent = 'Отменить';
        cancel.addEventListener('click', async () => {
          cancel.disabled = true;
          try { await api(`/v1/admin/commands/${command.id}/cancel`, { method: 'POST' }); notify(`Запрос #${command.id} отменён.`); await loadCommands(); await loadDevices(); }
          catch (e) { notify(e.message, true); cancel.disabled = false; }
        });
        actionCell.append(cancel);
      } else if (command.status === 'running' && ['screen_share_request', 'location_session_request'].includes(command.command_type)) {
        if (command.stop_requested) {
          actionCell.textContent = 'Остановка запрошена · ожидается подтверждение устройства';
        } else {
          const stop = document.createElement('button'); stop.className = 'secondary row-action'; stop.textContent = 'Запросить остановку';
          stop.addEventListener('click', async () => {
            stop.disabled = true;
            try { await api(`/v1/admin/commands/${command.id}/cancel`, { method: 'POST' }); notify(`Для сессии #${command.id} отправлен запрос остановки; дождитесь подтверждения устройства.`); await loadCommands(); }
            catch (e) { notify(e.message, true); stop.disabled = false; }
          });
          actionCell.append(stop);
        }
      } else actionCell.textContent = command.status === 'running' ? 'Нет удалённой остановки для этого действия' : '—';
      tr.append(actionCell); tbody.append(tr);
    }
    if (!commands.length) { const tr = document.createElement('tr'); const td = cell('Запросов пока нет'); td.colSpan = 7; td.className = 'muted'; tr.append(td); tbody.append(tr); }
  }

  async function loadEvents() {
    const events = await api('/v1/admin/events');
    const tbody = $('events-table'); tbody.replaceChildren();
    for (const event of events) {
      const tr = document.createElement('tr');
      tr.append(cell(event.created_at), cell(event.username), cell(event.event_type), cell(`${event.severity} / ${event.confidence}`), cell(event.resolved_at ? 'Закрыто' : 'Открыто'));
      const actionCell = document.createElement('td');
      if (!event.resolved_at) {
        const button = document.createElement('button'); button.className = 'secondary row-action'; button.textContent = 'Закрыть';
        button.addEventListener('click', async () => {
          button.disabled = true;
          try { await api(`/v1/admin/events/${event.id}/resolve`, { method: 'POST' }); notify('Событие закрыто и действие записано в аудит.'); await loadEvents(); await loadAudit(); }
          catch (e) { notify(e.message, true); button.disabled = false; }
        });
        actionCell.append(button);
      } else if (command.status === 'running' && ['screen_share_request', 'location_session_request'].includes(command.command_type)) {
        if (command.stop_requested) {
          actionCell.textContent = 'Остановка запрошена · ожидается подтверждение устройства';
        } else {
          const stop = document.createElement('button'); stop.className = 'secondary row-action'; stop.textContent = 'Запросить остановку';
          stop.addEventListener('click', async () => {
            stop.disabled = true;
            try { await api(`/v1/admin/commands/${command.id}/cancel`, { method: 'POST' }); notify(`Для сессии #${command.id} отправлен запрос остановки; дождитесь подтверждения устройства.`); await loadCommands(); }
            catch (e) { notify(e.message, true); stop.disabled = false; }
          });
          actionCell.append(stop);
        }
      } else actionCell.textContent = command.status === 'running' ? 'Нет удалённой остановки для этого действия' : '—';
      tr.append(actionCell); tbody.append(tr);
    }
  }
  function closeScreenPreview() {
    if (screenPreviewTimer) { clearInterval(screenPreviewTimer); screenPreviewTimer = null; }
    if (screenFrameObjectUrl) { URL.revokeObjectURL(screenFrameObjectUrl); screenFrameObjectUrl = null; }
    const img = $('screen-frame'); if (img) { img.hidden = true; img.removeAttribute('src'); }
    const stop = $('screen-preview-stop'); if (stop) stop.disabled = true;
    const start = $('screen-preview-start'); if (start) start.disabled = false;
    if ($('screen-preview-status')) $('screen-preview-status').textContent = 'Просмотр закрыт';
  }
  async function fetchScreenFrame() {
    const deviceId = $('screen-device-select').value;
    if (!token || !deviceId) return;
    const response = await fetch(`/v1/admin/devices/${encodeURIComponent(deviceId)}/screen-frame`, { headers: { Authorization: `Bearer ${token}`, Accept: 'image/jpeg' }, cache: 'no-store' });
    if (!response.ok) {
      const body = await response.json().catch(() => ({}));
      $('screen-preview-status').textContent = response.status === 404 ? 'Ожидается первый кадр' : (body.detail || `Поток недоступен (${response.status})`);
      return;
    }
    const blob = await response.blob();
    if (screenFrameObjectUrl) URL.revokeObjectURL(screenFrameObjectUrl);
    screenFrameObjectUrl = URL.createObjectURL(blob);
    const img = $('screen-frame'); img.src = screenFrameObjectUrl; img.hidden = false;
    const capturedAt = response.headers.get('X-AZAVAD-Captured-At') || 'время неизвестно';
    $('screen-preview-status').textContent = 'Кадры поступают';
    $('screen-frame-meta').textContent = `Последний кадр: ${capturedAt} · ${Math.round(blob.size / 1024)} KiB · SHA-256: ${response.headers.get('X-AZAVAD-SHA256') || 'не предоставлен'}`;
  }
  function openScreenPreview() {
    closeScreenPreview();
    if (!$('screen-device-select').value) { notify('Сначала выберите устройство.', true); return; }
    $('screen-preview-start').disabled = true; $('screen-preview-stop').disabled = false;
    $('screen-preview-status').textContent = 'Ожидание кадров…';
    fetchScreenFrame().catch(e => { $('screen-preview-status').textContent = e.message; });
    screenPreviewTimer = setInterval(() => fetchScreenFrame().catch(e => { $('screen-preview-status').textContent = e.message; }), 1500);
  }

  async function refresh() {
    try { await Promise.all([loadUsers(), loadAudit(), loadEvents(), loadLibrary(), loadDevices(), loadCommands()]); $('api-status').textContent = 'API доступен'; }
    catch (e) { notify(e.message, true); }
  }
  function showDashboard(user) {
    me = user; loginPanel.hidden = true; dashboard.hidden = false; sessionControls.hidden = false;
    $('identity').textContent = `${user.username} · ${user.role}`;
    $('role-stat').textContent = user.role;
    refresh();
    if (commandRefreshTimer) clearInterval(commandRefreshTimer);
    // Keep command statuses/results current while the administrator is signed in.
    commandRefreshTimer = setInterval(() => {
      if (token && !dashboard.hidden) {
        loadCommands().catch(() => {});
        loadDevices().catch(() => {});
      }
    }, 10000);
  }
  $('login-form').addEventListener('submit', async (event) => {
    event.preventDefault(); $('login-error').textContent = '';
    const form = new FormData(event.currentTarget);
    try {
      const session = await api('/v1/auth/login', { method: 'POST', body: JSON.stringify({ username: form.get('username'), password: form.get('password') }) });
      token = session.access_token;
      const user = await api('/v1/auth/me');
      if (user.role !== 'admin') { token = null; throw new Error('Эта панель доступна только администраторам.'); }
      showDashboard(user);
    } catch (e) { $('login-error').textContent = e.message; }
  });
  $('logout').addEventListener('click', async () => {
    try { if (token) await api('/v1/auth/logout', { method: 'POST' }); } catch (_) {}
    token = null; me = null;
    closeScreenPreview();
    if (commandRefreshTimer) { clearInterval(commandRefreshTimer); commandRefreshTimer = null; }
    dashboard.hidden = true; loginPanel.hidden = false; sessionControls.hidden = true; $('login-form').reset();
  });
  $('screen-preview-start').addEventListener('click', openScreenPreview);
  $('screen-preview-stop').addEventListener('click', closeScreenPreview);
  $('screen-device-select').addEventListener('change', () => { if (screenPreviewTimer) openScreenPreview(); });
  $('refresh-users').addEventListener('click', () => loadUsers().catch(e => notify(e.message, true)));
  $('refresh-devices').addEventListener('click', () => loadDevices().catch(e => notify(e.message, true)));
  $('refresh-commands').addEventListener('click', () => loadCommands().catch(e => notify(e.message, true)));
  $('refresh-audit').addEventListener('click', () => loadAudit().catch(e => notify(e.message, true)));
  $('verify-audit-integrity').addEventListener('click', async () => {
    try { const result = await api('/v1/admin/audit/integrity'); if (result.valid) notify(`Цепочка аудита цела: проверено записей — ${result.checked_entries}.`); else notify(`Нарушение целостности аудита: запись #${result.first_invalid_id} (${result.reason}).`, true); }
    catch (e) { notify(e.message, true); }
  });
  $('refresh-library').addEventListener('click', () => loadLibrary().catch(e => notify(e.message, true)));
  $('create-library-form').addEventListener('submit', async (event) => {
    event.preventDefault(); const form = new FormData(event.currentTarget);
    const payload = Object.fromEntries(form.entries());
    try { await api('/v1/admin/library', { method: 'POST', body: JSON.stringify(payload) }); event.currentTarget.reset(); notify('Черновик сохранён. Проверьте источник и содержание перед публикацией.'); await loadLibrary(); await loadAudit(); }
    catch (e) { notify(e.message, true); }
  });
  $('refresh-events').addEventListener('click', () => loadEvents().catch(e => notify(e.message, true)));
  $('create-user-form').addEventListener('submit', async (event) => {
    event.preventDefault(); const form = new FormData(event.currentTarget);
    try {
      await api('/v1/admin/users', { method: 'POST', body: JSON.stringify({ username: form.get('username'), password: form.get('password'), role: form.get('role') }) });
      event.currentTarget.reset(); notify('Учётная запись создана. Передайте пароль владельцу безопасным способом.'); await loadUsers();
    } catch (e) { notify(e.message, true); }
  });
})();
