#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
python -m compileall -q backend/app backend/tests backend/scripts
(cd backend && python -W error::ResourceWarning -m unittest discover -s tests -v)
node --check admin/app.js
python backend/scripts/export_openapi.py
