# Data Inventory — Initial Proposal

This is a design proposal, not a legal assessment. Final retention and consent text must be reviewed for the deployment jurisdiction.

| Data category | Purpose | Default location | Server transfer | Retention / deletion | Consent boundary |
|---|---|---|---|---|---|
| Account identifier | Sign-in and account management | Server; local session token | Required for account features | Delete according to account policy; revoke sessions immediately | Required before account creation |
| Consent decision and policy version | Prove selected feature choices | Local and server audit record | Yes, when account/sync enabled | Retain minimal audit record for defined policy period | Each feature separately opted in |
| Device diagnostics | Show supported security posture | Device | Only selected diagnostic summary | Short, documented period; delete when no longer needed | Separate opt-in for each transmitted category |
| Security events | Explain risks and support incident response | Local first | Only enabled event types | Bounded retention and access logging | Explain event categories before activation |
| Offline library content | Read reference materials offline | Device | Download of public/versioned packages | Replace old package after verified update | No sensitive personal data required |
| Sync queue metadata | Reliable offline sync | Device | Only when connectivity returns | Remove after acknowledged sync and conflict resolution | Follows the feature that generated the queue item |
| Admin audit records | Accountability for privileged actions | Server | Not applicable | Tamper-resistant retention policy | Admin notice and organizational policy |

Never collect messages, gallery contents, microphone or camera data as a general-purpose monitoring feature. Each future data field requires a purpose, access policy, retention period and deletion behavior before implementation.
