# Local container runbook (development only)

Prerequisites: Docker Engine and Docker Compose plugin.

```bash
# From repository root
 docker compose up --build -d
 docker compose logs -f azavad-api
```

The API binds to `127.0.0.1:8000` only. Open `http://127.0.0.1:8000/docs` and `http://127.0.0.1:8000/admin/` on the same machine.

Create the first administrator interactively:

```bash
docker compose exec azavad-api python -m app.bootstrap_admin
```

Stop the service with `docker compose down`. Persistent development data remains in the `azavad_data` volume. `docker compose down -v` deletes that volume and is destructive.

## Limits
This container is a local development setup, not a production deployment. It uses SQLite, has no TLS termination, no MFA, only a development SQLite-backed login-failure limiter (not a production rate limiter), and no automated backup/restore. It is bound to localhost deliberately. For remote access, design a production deployment with a reverse proxy and valid TLS, hardened identity controls, PostgreSQL migrations, secret management, monitoring, backups and an independent security review; do not simply expose port 8000.

## Library signing key (development/pilot preparation)

Generate a key pair outside the repository; do not commit the private key or put it in ordinary logs/backups:

```sh
python backend/scripts/generate_library_signing_key.py \
  --private-output /etc/azavad/secrets/library-signing.private.b64 \
  --public-output /etc/azavad/library-signing.public.b64
```

The private file is created with mode `0600` and contains base64-encoded 32-byte Ed25519 private key material. Configure the backend environment variable `AZAVAD_LIBRARY_SIGNING_PRIVATE_KEY_FILE` to the private-file path and restart the service. Alternatively, a base64 value can be supplied through `AZAVAD_LIBRARY_SIGNING_PRIVATE_KEY_B64` by a secret manager. The base64 environment variable takes precedence over the file setting.

Before any client relies on signatures, pin the expected public key through a trusted release/configuration channel. Do not simply trust a key downloaded from the same server as the content. Key rotation, client-side rollback protection and production secret-manager integration remain release blockers. Without a configured private key, publication returns HTTP 503 rather than publishing unsigned material.
