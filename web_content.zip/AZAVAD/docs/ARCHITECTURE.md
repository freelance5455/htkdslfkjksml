# AZAVAD Architecture Baseline

## Components
1. Native Android client: consent/settings, supported diagnostics, local data store, offline knowledge library.
2. Optional background agent: only explicitly enabled functions, using supported Android APIs.
3. Backend API: authentication/authorization, consent/policy service, device and event service, content service, audit.
4. Database and backup/restore process.
5. Administrator web console with least-privilege roles and MFA.

## Trust boundaries
- Android application sandbox and local database.
- Untrusted network between client and API.
- API service and persistent storage.
- Privileged administrator console.
- Content authoring and signed update pipeline.

## Rules
- Deny by default and authorize protected operations server-side.
- Granular, versioned consent must be viewable and revocable.
- Minimize collected data; private content stays local unless a disclosed feature explicitly requires otherwise.
- No covert access to messages, camera, microphone, gallery or arbitrary files.
- No hidden persistence or permission bypass.
- Destructive operations are limited to app-managed data and require confirmation.
- Distinguish “not checked” from “healthy”.
- Verify content integrity and apply offline updates atomically.
- Never commit production secrets.

## Proposed stack
Kotlin Android, Room, WorkManager and Android Keystore; FastAPI, SQLAlchemy/Alembic and PostgreSQL; separate web admin client; Docker for local development.
