# AZAVAD — Remote Panel Implementation Plan

Status date: 2026-10-28

## Goal
Provide an owner-controlled remote panel for a paired Android device. The panel may request permitted actions, but the Android client remains the authority for device-level permissions. No arbitrary shell execution, hidden camera/microphone activation, silent screen capture, or unrestricted filesystem browsing is part of this design.

## Verified baseline in this source archive
- Backend regression suite: 44 tests passed after adding remote-command queue and result-summary regression coverage with `python -W error::ResourceWarning -m unittest discover -s tests -v`.
- Backend Python bytecode compilation passed.
- Admin JavaScript syntax check passed with `node --check admin/app.js`.
- Android compilation, APK assembly, emulator/physical-device tests, and full remote panel-to-device round trip have not been verified. No Gradle executable or wrapper is present in the Android project in this environment.

## Required interaction model
1. The owner signs in on the device and pairs it with their account.
2. Every sensitive feature has its own consent record. The default expiry is 365 days, but the owner can revoke it sooner; local Android permission state must also be checked.
3. The external panel creates a narrowly typed, short-lived request for a paired device. It cannot submit arbitrary commands or code.
4. The Android app receives the request and displays a persistent, clear status. For system-controlled actions, Android's own consent/permission UI is shown on-device.
5. The app returns a minimal result and audit event. The panel shows pending, accepted, denied, expired, and completed states.
6. Revoking consent, unpairing the device, logging out, or expiring the request prevents further execution. Revocation should cancel pending requests of that feature.

## Implementation stages

### R1 — Device command protocol
- Add per-device command records with a strict enum, creation/expiry timestamps, status, idempotency key, and audit linkage.
- Initial allowed types: `SYNC_NOTIFICATION_HISTORY`, `OPEN_SCREEN_SHARE_PROMPT`, `OPEN_OWNER_FILE_PICKER`, and `STOP_FEATURE`.
- Reject arbitrary command strings, URLs, scripts, shell commands, and paths.
- Require device ownership, active session, current consent, and rate limits on every create/poll/ack/result operation.
- Commands expire quickly (suggested default: 2 minutes) and are single-use.

### R2 — Android polling and execution
- Use WorkManager or a foreground service only where Android background-execution rules permit it; show a persistent notification for any ongoing foreground task.
- Poll only while paired and signed in, with bounded backoff and cancellation on logout/unpair/revocation.
- `SYNC_NOTIFICATION_HISTORY` sends only the bounded local log after both local and server consent checks.
- `OPEN_SCREEN_SHARE_PROMPT` may open a visible activity that calls Android MediaProjection consent flow. Capture cannot begin unless the user accepts the system dialog. Stop promptly when the projection is revoked, consent expires, or the owner presses Stop.
- `OPEN_OWNER_FILE_PICKER` opens Android's Storage Access Framework picker; only user-selected URIs can be uploaded. Never scan the whole filesystem.
- `STOP_FEATURE` stops the requested supported feature and clears pending work.

### R3 — External panel
- Device list shows pairing status, last-seen timestamp, app version, and feature consent state only.
- Action buttons create typed requests and show a confirmation that the phone may require on-device approval.
- Show request status and safe result summaries; notification contents and file contents remain owner-only and must never appear in administrator inventory.
- Add unpair/revoke controls and clear status when a device is offline.

### R4 — Screen-sharing transfer
- Add MediaProjection only after R1/R2 and consent UX tests pass.
- Use a visible foreground service and an explicit stop control. Do not attempt to suppress Android's screen-capture indicators or system prompts.
- Send frames only during an active owner-approved session, over TLS, with bounded frame rate/resolution and no default recording/retention.
- No capture of secure surfaces or attempts to bypass Android restrictions.

### R5 — Release gates
- Automated tests for ownership isolation, consent expiry/revocation, command replay, command expiry, idempotency, and rate limits.
- Android unit/instrumentation tests for notification-listener enable/disable, MediaProjection approval/denial/stop, picker cancellation, offline recovery, and logout.
- Verify TLS configuration, production secrets, database migrations, backup/restore, dependency scanning, and independent security review.
- Build a reproducible signed release APK and test installation/update/uninstall on supported Android versions.

## Current blockers
- A bounded typed remote-command queue and panel request controls are now present in source. Commands require an active owner-confirmed `remote_panel` consent record, expire within 1–30 minutes, reject arbitrary command strings, and are cancelled when that consent is revoked.
- The Android client now polls the queue in the foreground, renders Accept/Reject controls, and executes the limited owner-approved handlers documented below. It is still not a fully verified end-to-end remote-control product.
- Screen sharing through MediaProjection and time-limited location sessions are not implemented. One-time location delivery is now wired to a separate revocable consent, an on-device approval, Android's foreground location permission, enabled location services, and a fresh location result; the result summary is returned to the admin panel. Camera and microphone requests open visible local system UI and save local files only; they do not stream media to the panel.
- Android build and device validation are still outstanding; no APK has been produced.
- Production deployment controls, PostgreSQL migrations, MFA/recovery, and independent security review remain incomplete.

## Acceptance criterion
Do not describe AZAVAD as remotely operational until an end-to-end test proves: an owner signs in, pairs a device, grants one feature, requests that feature from the panel, sees any required Android system prompt, receives a result, revokes consent, and confirms the same request is then rejected. Repeat with an unauthorized account and an expired command; both must fail closed.


## Single-consent UX update — 2026-10-28

Product requirement: minimize cognitive and interaction burden for a person in difficult field conditions. The first-run flow uses one plain-language consent and one confirmation checkbox for the full disclosed AZAVAD capability set; the consent is recorded with version, timestamp, explicit scope, and a default 365-day expiry. A visible revoke action clears local consent and ends the local session. Background sync remains off until separately implemented and tested; accepting umbrella consent is not a claim that a feature is active.

The umbrella consent is not a bypass for Android runtime/system permissions. Screen capture, camera, microphone, notification access, and background location may require their own Android system dialogs/settings and must remain stoppable. The app must show the feature status and never represent a system permission as granted until the OS confirms it. Revocation must stop future app-side collection/sync where implemented; the app should direct the user to Android settings to revoke OS-level grants. Before production, consent scope, server-side grant synchronization, expiry enforcement, and revocation propagation must be covered by integration tests.


## Remote request queue update — 2026-10-28

Implemented in source: typed per-device requests (`device_status`, backup request, owner file picker request, notification sync request, screen-share request, camera/microphone session requests, one-time location request, and time-limited location-session request); short expiry; admin queue view; owner-authenticated device poll/result endpoints; strict status transitions requiring explicit owner acceptance before sensitive requests can run; audit entries; server-side `remote_panel` consent gate; pending/in-progress request cancellation when the owner revokes that consent. The panel only creates requests. It cannot send arbitrary shell commands, scripts, filesystem paths, or URLs.

Android integration now synchronizes the one-year unified consent to the server when an authenticated session is available, registers and persists the server device ID, and polls the typed queue while the device-tools screen is resumed. The on-device queue presents explicit Accept/Reject controls. Implemented handlers: device status, opening the Android camera UI after owner acceptance, opening the system recorder after owner acceptance, owner-picked files, notification-history sync, and backup upload for files the owner previously selected. The camera and audio handlers use visible system UI and only save local files; they do not stream media to the panel. The polling loop pauses while the app is not resumed. One-time location delivery is now implemented in source with separate consent, explicit on-device acceptance, active Android location permission, and fresh-location timeout handling. Remaining: screen sharing/MediaProjection streaming and time-limited location sessions are not implemented and return explicit failure results rather than pretending to work. Full Android build, emulator/device validation, and end-to-end panel-to-phone testing still require an Android SDK/Gradle build environment. Android OS permissions and MediaProjection approval remain mandatory.

## Implemented follow-up: device health heartbeat

The client now posts a small heartbeat only while the Device Tools screen is resumed. It includes battery %, charging, validated network connectivity, foreground state, Android version and app version. The API requires an active owner-confirmed `remote_panel` consent and the admin inventory shows online/offline freshness. Only the latest status is retained. This does not include screen content, microphone audio, camera video, or background location.

Remaining release gates: implement MediaProjection with the Android system consent prompt and visible foreground session; validate screen-share transport and authorized panel rendering; run Gradle build and real-device end-to-end tests. Until those gates pass, screen monitoring is not complete.

## Lifecycle hardening update — 2026-10-28

- Server validates legal command status transitions.
- Administrators can cancel queued/delivered/accepted requests. Recent cancellations are visible to the Android polling client so stale prompts can be dismissed.
- Running actions cannot be remotely stopped through this generic cancellation endpoint; the panel clearly says to stop them on the device. A proper stop signal must be implemented alongside each long-running session before any such session is enabled.
- 46 backend tests pass, including cancellation and state transition checks. Android compilation/device validation and full screen-sharing remain release blockers.


## Monitoring/control lifecycle increment — 2026-10-28

- Added `stop_requested` to remote command state, with an in-place SQLite migration for existing development databases.
- Admin cancellation now signals stop for a running screen-share or time-limited location session rather than falsely marking it cancelled. The session remains `running` until Android reports a terminal result. Other running actions fail closed with an explicit message that they have no remote-stop handler.
- Device polling includes stop-signalled running sessions. After umbrella-consent revocation, the device can still poll a narrow stop-only channel, but receives no new/pending work. Android deliberately does not claim a session has stopped merely because a signal was received; the relevant local session handler must stop the resource and report a terminal state.
- Revoking unified remote-panel consent or the matching screen/location consent signals stop for matching running sessions and cancels queued requests.
- Admin panel exposes “Request stop” only for the typed long-running session classes and displays that device acknowledgement is still pending.
- Added regression coverage for signal delivery and terminal acknowledgement. Backend suite: 48 tests pass.

Important remaining blocker: Android MediaProjection screen-sharing and the actual client-side stop handler are not implemented in this increment. Therefore this is lifecycle protocol groundwork, not a claim that screen monitoring or remote stop is already operational. Real-device integration remains a release gate.
