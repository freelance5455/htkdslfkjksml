# Initial Role / Permission Matrix

`✓` means permitted only within the assigned tenant/scope and after authentication. `—` means denied by default.

| Capability | End user | Support operator | Security analyst | Administrator | Auditor |
|---|---:|---:|---:|---:|---:|
| View own consent and revoke optional features | ✓ | — | — | — | — |
| View own device status | ✓ | — | — | — | — |
| View scoped, minimized device status | — | ✓ | ✓ | ✓ | — |
| View security events | Own events | Scoped metadata | Scoped events | Scoped events | Read-only audit scope |
| Change security policy | — | — | Propose only | ✓ with audit | — |
| Manage user accounts | Own account | Limited support actions | — | ✓ | — |
| View admin audit log | — | — | Scoped | ✓ | ✓ read-only |
| Publish signed library package | — | — | Review | Authorized publisher role only | — |
| Trigger deletion of app-managed data | Own device with confirmation | — | — | Cannot bypass device-side policy | — |

Production authorization must be enforced server-side for every request. Hiding a button in the UI is not authorization. Privileged accounts require MFA; emergency recovery must be auditable and must not create a hidden universal account.
