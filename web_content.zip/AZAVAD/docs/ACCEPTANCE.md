# Initial Acceptance Checklist

## Consent and privacy
- [ ] First-run explanation lists data categories, purpose, background behavior and server functions.
- [ ] Optional features have separate, versioned consent and can be revoked.
- [ ] Refusing an optional permission does not block unrelated offline content.
- [ ] Data inventory, retention and deletion behavior are documented.

## Android
- [ ] Native app builds reproducibly with pinned toolchain.
- [ ] Permission denial/revocation is handled without crashes.
- [ ] “Not checked” is never displayed as “secure”.
- [ ] Offline library works without network and survives process restart.
- [ ] Background work uses supported APIs and reports OS limitations.
- [x] Notification sync API requires active owner-confirmed consent, encrypts payloads at rest, deduplicates records, and is account-scoped (backend tests pass).
- [ ] Notification sync has been compiled and verified on a physical Android device.
- [ ] Screen sharing via Android MediaProjection with foreground service and explicit owner approval is implemented and tested.

## Backend and admin
- [ ] Authentication and object-level authorization are enforced server-side.
- [ ] Privileged accounts require MFA.
- [ ] Administrative actions are audited without recording secrets.
- [ ] Rate limits, schema validation and safe error handling are tested.
- [ ] Backups are restored successfully in a documented drill.

## Updates and resilience
- [ ] Content and app update integrity is verified before activation.
- [ ] Interrupted sync resumes safely; duplicate operations are idempotent.
- [ ] Database migration and rollback/recovery procedures are tested.
- [ ] Critical security findings block release until resolved or formally accepted.

## Release evidence
- [ ] Build artifacts and exact toolchain versions recorded.
- [ ] Unit, integration, Android, reliability and security test reports saved.
- [ ] Known limitations and residual risks documented.
