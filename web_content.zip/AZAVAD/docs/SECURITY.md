# Security status and release blockers

## Implemented in the development scaffold
- PBKDF2-HMAC-SHA256 password hashing with per-password random salts.
- Random opaque session tokens; server persists only token digests.
- Session expiration, logout, logout-all, and session invalidation when an account is disabled.
- Role checks for administrator routes and user-scoped access to consent/device data.
- Initial administrator bootstrap with interactive password entry; no hardcoded default password.
- Audit records for selected account, consent, device, admin and security-event actions.
- Event classification rules carry a severity and a separate confidence level. Client-reported events are explicitly not treated as proof of compromise and trigger no irreversible action. Administrators can mark an event resolved; the action is audited.
- Android session token encryption using an AES-GCM key held in Android Keystore.
- Android client refuses API URLs that are not HTTPS.

## Release blockers
1. Move from SQLite/startup schema creation to PostgreSQL with reviewed, versioned migrations.
2. Replace the single-instance SQLite login/registration throttles with distributed edge controls; add abuse monitoring, password reset/recovery, and MFA for privileged accounts. The development scaffold currently limits failed login attempts to 10 per 15 minutes per username/client pair and client address, and registration to 5 attempts per hour per client address.
3. Configure production TLS, secure deployment, secrets, CORS policy, headers, log redaction and monitoring.
4. Review session revocation, password change, account deletion, retention and data export semantics.
5. Add request IDs, idempotency where needed, audit integrity controls, backup encryption and restore drills.
6. Add signed library manifests/content updates and rollback protection.
7. Complete Android tests, dependency scanning, static analysis, integration tests and independent security review.
8. Do not release if any critical finding remains unresolved.

## Deployment guard
- `AZAVAD_ENV` accepts `development`, `test`, or `production`. Interactive API documentation and the OpenAPI route are enabled only in development mode.
- Production startup currently fails closed while release blockers remain. This is intentional: the SQLite development backend is not a supported production data store and deployment controls have not been independently verified.

## Scope restrictions
AZAVAD is not designed to secretly inspect private messages, gallery, microphone, camera or arbitrary user files. Device actions must be scoped, disclosed and confirmed. Security heuristics must remain explainable and cannot independently trigger irreversible actions.

## Library publication controls
- Library drafts are administrator-only; public routes expose immutable published snapshots only.
- Publication requires a configured Ed25519 private key; unsigned publication fails closed with HTTP 503.
- Each published snapshot includes a canonical JSON payload, SHA-256 digest, Ed25519 signature, version number, key ID and publication timestamp. Source URLs are restricted to HTTPS, categories are allow-listed, and verification dates are validated.
- The private key can be read from a file path or an environment value; a helper generates private files with mode `0600` outside the repository.
- Remaining risks: clients must pin/authenticate the public key out-of-band; client-side rollback prevention and a reviewed key-rotation process are not yet implemented. A compromised administrator can still publish harmful but validly signed content, so editorial review and audit controls remain necessary.


## Audit integrity
- Audit entries are appended with a SHA-256 hash chain; each entry hashes its stable actor-ID snapshot, event fields, timestamp and prior entry hash. Account deletion may null the relational actor reference, but it does not rewrite the snapshot used by the chain.
- Administrators can verify the chain through `/v1/admin/audit/integrity`; the web console exposes the same check. A regression test mutates an existing event and confirms that verification reports the affected record.
- This is tamper-evidence within the application database, not cryptographic proof against a database administrator who can rewrite the entire chain. Production still needs external/immutable log export, access separation and monitored integrity checks.

## Advance consent for sensitive device capabilities
- The server records separate owner-confirmed consent decisions for `camera`, `microphone`, and `file_access`; positive consent for these capabilities requires the `emergency_safety` purpose and explicit confirmation; it defaults to 365 days, and the owner may choose a shorter duration (up to 365 days) or revoke it at any time.
- The owner can review decisions through `/v1/consents` and `/v1/consents/effective`, choose a shorter duration through `expires_in_days` or the legacy `expires_in_hours` field, and revoke an individual decision through `/v1/consents/{id}/revoke`. Consent records are account-scoped and revocations are audited.
- This server-side record is a policy/audit layer, not proof that the actual device owner physically confirmed the prompt. A future client must require local unlocked-device confirmation and Android runtime permission at point of use, clearly show recording/file-selection state, and honour Android permission revocation.
- Prior consent does not authorize covert capture, bypass OS permissions, or remote activation by an operator. No server endpoint exists to remotely switch on a camera/microphone or browse arbitrary files. File access must be limited to files explicitly selected by the owner through Android's system picker; camera/microphone use must be visible, user-initiated, and narrowly scoped.
- Expired consent is not effective. A new decision supersedes any prior active decision for the same feature. Emergency/captivity context is not a mechanism to override local device controls or safety/privacy safeguards.
