# Initial Threat Model

Ratings are preliminary and require validation against deployment context.

| Threat | Impact | Initial control | Validation still required |
|---|---|---|---|
| Lost/stolen device | App-data exposure | Platform encryption, minimize stored data, short sessions | Test supported Android versions |
| Stolen credentials | Unauthorized actions | Strong authentication, rate limiting, revocation, admin MFA | Identity and abuse tests |
| Compromised administrator | Data/policy abuse | RBAC, separation of duties, audit trail | Insider and takeover review |
| API authorization flaw | Cross-account data access | Deny by default, object-level authorization | Negative authorization tests |
| Network interception | Data disclosure | TLS and certificate validation | Deployment and device tests |
| Replayed requests | Duplicate operations | Idempotency keys and expiry where appropriate | Endpoint-specific tests |
| Malicious update | Compromised client/content | Signed releases and content manifests | Signing-key and recovery review |
| Connectivity loss | Remote features unavailable | Offline-first content and durable sync queue | Conflict/power-loss tests |
| Corrupt local database | Data loss | Transactions, schema versioning, recovery | Recovery drills |
| Excessive collection | Privacy harm | Data inventory, granular opt-in, retention policy | Review each feature |
| Overbroad admin access | Privacy violation | No arbitrary private-data browsing; least privilege | Authorization and UI review |
| Accidental deletion | Data loss | Preview, explicit confirmation, scoped operations | Cancellation/replay tests |

## Required before pilot
Complete data inventory, role matrix, authentication/recovery design, negative authorization tests, dependency/secret scanning, backup restore drill and independent security review.
| Coercive or covert use of camera/microphone/files | Serious privacy and physical safety harm | Separate expiring owner consent; local OS permission and visible user action required; no remote capture endpoints; file picker scope | Client-side implementation and red-team verification required |
