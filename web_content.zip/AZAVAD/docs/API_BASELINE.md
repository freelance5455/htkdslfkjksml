# API Baseline — v0.2.0-dev

The live development schema is generated from FastAPI at `/openapi.json`; interactive docs are available at `/docs`.

## Health
- `GET /health` — process-only health check; does not prove database health or system security.

## Authentication
- `POST /v1/auth/register` — create regular account.
- `POST /v1/auth/login` — receive opaque bearer token.
- `GET /v1/auth/me` — authenticated profile.
- `POST /v1/auth/logout` — revoke current session.
- `POST /v1/auth/logout-all` — revoke all sessions for current account.
- `GET /v1/account/export` — export the current account’s application-managed records, excluding credentials and token material.
- `DELETE /v1/account` — permanently delete the current account and account-scoped records; requires password and explicit confirmation.
- Login failures are throttled per username/client-address and per client-address; this SQLite-backed mechanism is a development baseline, not distributed production protection.

## Consents and devices
- `POST /v1/consents`, `GET /v1/consents` — authenticated account-scoped consent records.
- `POST /v1/devices`, `GET /v1/devices`, `DELETE /v1/devices/{device_id}` — account-scoped device registry.

## Security events and audit
- `POST /v1/events`, `GET /v1/events` — submit/list the current account's allow-listed security events.
- `GET /v1/audit` — current account's audit records.
- `GET /v1/admin/events`, `POST /v1/admin/events/{event_id}/resolve` — administrator-only event triage.
- `GET /v1/admin/users`, `POST /v1/admin/users`, `PATCH /v1/admin/users/{user_id}` — administrator-only account management (create user/operator and disable/enable).
- `GET /v1/admin/audit` — administrator-only audit view, including immutable actor-ID snapshot.
- `GET /v1/admin/audit/integrity` — administrator-only verification of the audit hash chain; returns the first invalid record when tampering or chain damage is detected.

## Important limitations
Current persistence is SQLite with startup-created tables. Account export and confirmed account deletion are exposed in the API and wired into the Android data screen; device-side execution has not been verified. The API is a development scaffold with a basic SQLite-backed login-failure limiter but without distributed abuse protection, MFA, PostgreSQL migrations, or production deployment hardening. Keep it bound to localhost until those controls and an independent security review are complete.

## Offline library and signed publication
- `GET /v1/library` — list latest published immutable versions only.
- `GET /v1/library/{slug}` — retrieve the latest published version by slug.
- `GET /v1/library/signing-key` — current Ed25519 public key and key ID; returns 503 until a signing key is configured.
- `GET /v1/admin/library` — administrator-only draft/current item inventory.
- `POST /v1/admin/library` — administrator-only draft creation. Categories are allow-listed; source URL must be HTTPS; a verification date is required.
- `PATCH /v1/admin/library/{item_id}` — administrator-only draft edit. The public published snapshot remains unchanged until a new publication.
- `POST /v1/admin/library/{item_id}/publish` — administrator-only immutable version publication. Refuses to publish if signing is not configured. Each version contains a SHA-256 digest and Ed25519 signature over canonical JSON.

The server exposes the current public key for development convenience, but clients must pin or otherwise authenticate the expected public key out-of-band. Fetching both content and its public key from the same untrusted endpoint does not establish authenticity. Version monotonicity is provided by the server; client-side rollback prevention and key-rotation trust are not yet implemented.
