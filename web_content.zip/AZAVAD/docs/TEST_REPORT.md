# Test Report — AZAVAD v0.2.0-dev

Execution date: 2026-10-28. Environment: Python 3.13.5, FastAPI 0.128.2, Pydantic 2.13.5, HTTPX 0.28.1, Node.js 22.16.0.

## Executed checks

| Check | Result | Notes |
|---|---|---|
| Python bytecode compilation | PASS | `python -m compileall -q backend/app backend/tests backend/scripts` |
| Backend test suite | PASS — 35 tests | `python -W error::ResourceWarning -m unittest discover -s tests -v` |
| Admin JavaScript syntax | PASS | `node --check admin/app.js` |
| OpenAPI generation | PASS | 27 paths exported to `docs/openapi.json` |
| SQLite backup/restore | PASS — 5 dedicated tests | Round-trip, file permissions, no-overwrite default, checksum tampering, missing checksum, integrity and foreign-key checks |
| ZIP integrity | PASS | `unzip -t AZAVAD_Initial_Scaffold.zip` |
| Android Gradle build | NOT RUN | Gradle executable and Android SDK are not installed in this environment; recent account-data UI integration is source-reviewed only |
| Android emulator/device install | NOT RUN | No Android runtime available here |
| Docker image/Compose start | NOT RUN | Docker runtime not available in this environment |
| GitHub Actions | NOT RUN | Workflow was authored but has not run on GitHub |
| Production security assessment | NOT RUN | Requires deployment-specific independent review |

## Backend tests covered

- Process health endpoint.
- Account registration and login.
- Duplicate registration rejection.
- Authenticated profile access.
- Protected route denial without credentials.
- Session logout and revocation.
- Logout-all revocation and token digest storage.
- Consent and device ownership boundaries.
- Sensitive-capability consent for camera, microphone and file access requires explicit owner confirmation and emergency-safety purpose; it defaults to 365 days, supports shorter durations, and can be revoked by the owner at any time. Conflicting duration fields are rejected; effective-consent listing excludes inactive decisions.
- Role-based denial for regular users and access for administrators.
- Administrator account disable flow, self-disable prevention and session denial.
- Case-insensitive username uniqueness.
- Login failure throttling and successful-login reset.
- Registration throttling: 5 attempts per client address per hour, `429` plus `Retry-After`, hashed limiter keys, and automatic reset after the one-hour window.
- Production readiness guard reports unresolved blockers; production startup fails closed, and interactive docs/OpenAPI endpoints are disabled outside development mode.
- Allow-listed security event classification, confidence/severity distinction, and audited resolution.
- Static admin console route availability and baseline browser security headers/CSP.
- Input validation for feature identifiers.
- Account data export excludes credentials/tokens; self-deletion requires password and explicit confirmation, revokes the session, and cascades account-scoped records.
- Library publication refuses unsigned updates; Ed25519 signatures are verified in tests, published versions remain immutable while a draft is edited, and new publication increments the version.
- Library API rejects non-admin access, non-HTTPS source URLs, unsupported categories, explicit null patches and invalid signing configuration.
- Audit hash chain validates normal entries and detects deliberate mutation; verification requires administrator authentication.

## Limitations

Passing these tests does not prove production security, concurrency safety under load, Android compilation, accessibility, TLS deployment, data recovery, or resilience against real attackers. The audit hash chain is tamper-evident but can be recomputed by an attacker with unrestricted database write access; external immutable logging is still needed. The test database is temporary and test-only. Production release remains blocked by the items in `docs/SECURITY.md` and `docs/PROGRESS.md`.


Additional regression coverage in this iteration: one-year default consent expiry and revocation; conflicting consent-duration rejection; case-insensitive username uniqueness; administrator self-disable prevention; immediate session revocation when an account is disabled; registration abuse throttling and expiry-window reset.

Login abuse-control checks: ten invalid attempts receive the generic authentication failure; the next attempt receives HTTP 429 with Retry-After. Both per-username/address and per-address buckets are exercised, including changing usernames to bypass attempts. A valid login succeeds after a prior failure. This is a single-instance development control, not a distributed production rate limiter. Registration is separately limited to five attempts per direct client address per hour; a successful registration request consumes one attempt, including a duplicate-username attempt. Requests rejected by schema validation do not reach the limiter.

Backend account export/deletion was tested using the temporary test database. Android export-to-file and account-deletion UI wiring was added, but could not be compiled or run in this environment. Retention policy, operational deletion from external backups, legal requirements, and production recovery behavior remain unverified.

Library signing tests use an ephemeral Ed25519 key generated inside the test process; no production private key is included in the repository. Key generation helper and file-mode behavior were source-reviewed; client key pinning and rollback protection are not implemented.


Sensitive-capability consent tests verify required owner confirmation and emergency-safety purpose, the 365-day default, duration validation, revocation and cross-account denial. These server-side records do not themselves grant Android runtime permissions or allow remote capture.


SQLite maintenance utility was exercised against temporary test databases only. A production restore drill, encrypted off-host storage, retention policy, and backup authenticity controls remain unverified.

## Latest incremental verification — 2026-10-28

- Backend unittest suite: 46 passed (`python -W error::ResourceWarning -m unittest discover -s tests -q`).
- `node --check admin/app.js`: passed.
- `python -m compileall -q backend/app backend/scripts`: passed.
- OpenAPI document regenerated: 42 paths.
- Not run: Android Gradle build, APK signing, emulator tests, physical-device end-to-end tests. The current environment does not contain a Gradle executable/wrapper or Android SDK.

## Screen-monitoring implementation slice — 2026-10-28

- Backend unittest suite: PASS — 51 tests.
- New screen-frame test covers owner consent, running command requirement, JPEG payload validation, SHA-256 metadata, authenticated admin retrieval, and rejection after a stop request.
- `node --check admin/app.js`: PASS.
- OpenAPI export: regenerated by `bash scripts-checks.sh`.
- Android Gradle build/APK: NOT RUN — no Gradle executable/wrapper or Android SDK available in this environment.
- Physical device/emulator: NOT RUN. Do not treat the MediaProjection integration as device-validated until a build and a full Android-to-server-to-panel test succeeds.
- File browser: NOT COMPLETE; the existing SAF picker and owner backup upload are not yet a panel-side browse/download workflow.

## First-aid learning entry screen — 2026-10-28

- Added an introductory first-aid learning screen and made it the first screen after the app's consent gate.
- Updated the launcher label and header to disclose AZAVAD branding and the learning focus.
- Not verified: Android compilation, device rendering, accessibility review, medical content review by a qualified clinician, and APK packaging. The content is introductory only and must not be represented as certified tactical-medicine training.
