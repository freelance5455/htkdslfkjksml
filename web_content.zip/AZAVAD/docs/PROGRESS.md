# Progress Log — 2026-10-28

## Stage A — requirements and architecture
- [x] Translate Master Prompt v1.0 into component boundaries and development sequence.
- [x] Architecture and trust boundaries.
- [x] Initial threat model, data inventory, role matrix, acceptance criteria.

## Stage B/C — backend foundation
- [x] FastAPI service with versioned `/v1` endpoints.
- [x] SQLite development schema for users, revocable sessions, consents, devices, security events and audit events.
- [x] PBKDF2-HMAC-SHA256 password hashing with per-password random salts.
- [x] Opaque high-entropy session tokens; only token digests persisted; expiry, logout, logout-all and account-disable revocation.
- [x] Role checks for administrator routes; account-scoped consent and device access.
- [x] Regression tests for case-insensitive username uniqueness, self-disable prevention and active-session revocation on account disable.
- [x] Advance, granular, expiring owner-consent records for camera, microphone and file access; owner-scoped revocation and effective-consent endpoint. Sensitive consent requires explicit owner confirmation and emergency-safety purpose; it defaults to 365 days, accepts shorter owner-selected durations, and can be revoked at any time; no remote capture API is exposed.
- [x] Interactive first-admin bootstrap without a default password.
- [x] Security event rules with separate severity/confidence, recommendations and auditable resolution.
- [x] Same-origin admin web console: login, users, disable/enable, event review/resolution, audit log.
- [x] Local-only Docker Compose development deployment and non-root container configuration.
- [x] CI workflow for backend tests, Python compile, admin JS syntax and OpenAPI consistency; added an Android debug-build job for GitHub Actions (not yet executed).
- [x] Backend tests: **35 passed** with `ResourceWarning` treated as error, including signature verification, immutable published snapshots, draft isolation and rejection of unsigned publication.
- [x] JavaScript syntax check for admin console.
- [ ] PostgreSQL integration and schema migrations.
- [x] SQLite-backed login throttling: 10 failed attempts per username/client-address pair and per client address per 15 minutes, with hashed limiter keys and regression tests.
- [x] Separate registration abuse throttle: 5 attempts per direct client address per hour, hashed address key, atomic update and `Retry-After`; expiry-window and API behavior tests pass. Single-instance development control only; distributed edge limiting is still required.
- [x] Authenticated account data export and password-confirmed self-deletion for application-managed records.
- [x] Baseline HTTP security headers and a strict same-origin Content Security Policy for the administrator console.
- [x] Fail-closed production startup gate while required production controls remain incomplete; interactive API docs/OpenAPI endpoints are disabled outside development mode.
- [x] Tamper-evident audit hash chain, actor-ID snapshot resilient to account deletion, and admin integrity-verification endpoint/UI.
- [ ] Distributed edge rate limiting, password recovery and MFA.
- [x] SQLite prototype backup/restore utility with SHA-256 verification, temporary-file restore validation, overwrite guard and file permissions; 5 tests pass.
- [ ] Production deployment, TLS, monitoring, encrypted off-host backups, retention and a production restore drill.

## Stage D — Android
- [x] Native Kotlin/Compose project scaffold and navigation.
- [x] First-run consent gate; optional background-sync preference defaults off.
- [x] Offline knowledge library bundled in app with source labels/links and local search.
- [x] Registration/login UI wired to API client requiring HTTPS.
- [x] Session token encrypted with Android Keystore AES-GCM.
- [x] Basic device information shown with explicit warning that full diagnostics are not implemented.
- [x] User-initiated account export to a SAF-selected JSON file and password-confirmed account deletion wired to the API (Android compile/runtime verification still pending).
- [ ] Android Gradle build and APK installation (local SDK/Gradle not available; CI build job added but not yet executed).
- [ ] Local database, full diagnostics, server event/device integration, background work and data cleanup.
- [ ] Physical device/emulator regression and accessibility tests.

## Stages E–I — remaining
- [x] Library API for draft creation/editing and public retrieval of immutable published versions.
- [x] Ed25519 signatures and SHA-256 digests for published library snapshots; unsigned publication fails closed.
- [x] Admin console forms for draft creation, inventory and publish action.
- [x] Key generation helper with private file permissions and deployment instructions.
- [ ] Client-side public-key pinning, rollback protection and reviewed key rotation.
- [ ] PostgreSQL integration and schema migrations.
- [ ] Production server configuration and complete admin capabilities.
- [ ] Complete data protection, retention schedules and recovery flows; account export/deletion is implemented but needs broader integration review.
- [ ] Integration/reliability tests, dependency scanning and independent security review.
- [ ] Reproducible signed release APK and deployment runbook.

## Verification status
The 35 backend tests and JavaScript syntax check passed in this environment. Docker image/Compose startup and GitHub Actions have not been executed here. Python bytecode compilation passed. Android build/install, production deployment, penetration testing and backup restoration have not been performed. The app and backend remain development prototypes.

## Resume commands
- Backend: `cd backend && python -W error::ResourceWarning -m unittest discover -s tests -v`
- Admin JS: `node --check admin/app.js`
- Android: open `android/` in Android Studio with JDK 17 and SDK 35; sync and build.

## Stage D — owner-initiated device tools (2026-10-28 follow-up)
- [x] Added a dedicated Media screen with separate local consent toggles for camera, microphone/recorder, selected-file copying, and notification logging; grants expire after 365 days by default and can be revoked in the app.
- [x] Camera action uses Android's system camera preview and saves only after the user presses the button; no background capture.
- [x] Recorder action launches an installed system recorder and copies its returned recording into app-private storage; no background recording.
- [x] Selected-file copying uses Android's document picker and copies only files explicitly selected by the owner, with a 10 GB decimal per-file cap.
- [x] Added a NotificationListenerService gated by a separate in-app opt-in and Android's explicit notification-listener settings; at most 100 recent notification records are retained locally; no automatic server transmission.
- [ ] Server-side encrypted backup of user-selected media/files and authenticated restore is NOT implemented. The existing account JSON export is not a full device backup.
- [ ] Sync local grants to server-side consent records and verify expiry/revocation end-to-end.
- [ ] Build Android app with SDK/JDK, run emulator/device tests, validate notification settings flow and media intents.

## Device tools and server backup modernization — 2026-10-28

Implemented in source (build/physical device still unverified):
- Added explicit owner-consent-gated backup API with per-user quota and 10 GB maximum file size.
- Added resumable-by-chunk upload protocol using 8 MiB chunks, AES-256-GCM per-chunk encryption at rest, authenticated chunk metadata, final SHA-256 verification, listing, streaming restore/download, and deletion.
- Added Android API client for chunked upload and streaming restore; failed transfers attempt to delete the incomplete server object.
- Replaced the old 25 MiB client-side cap with 10 GB and streaming copy logic.
- Added explicit UI for backup consent, manually selected uploads, notification-history export to the user's upload queue, listing, restore destination selection, and deletion.
- Server account deletion now removes the user's encrypted backup chunks before cascading metadata.
- Added tests for explicit consent, encrypted upload/list/download/delete round trip, and rejection above 10 GB.

Verification: backend test suite now has 38 tests and passes. Android Gradle build/APK, real-device testing, sustained 10 GB load tests, storage-full tests, and production key-management/restore drills have not been run in this environment. Do not label the Android client as release-ready until those checks pass.

## Background location permission update
- Added Android coarse/fine/background location declarations and a separate, revocable opt-in in the device UI.
- Added foreground permission request, system-settings handoff for background permission, and visible permission/location-services status.
- No coordinate collection or server upload is implemented in this update; no hidden capture is enabled. Android background location does not bypass camera/microphone while-in-use restrictions.
- Android APK build/device validation remains outstanding because the environment lacks a configured Android SDK/Gradle wrapper.



## Owner-controlled notification synchronization — 2026-10-28 follow-up

- [x] Added `/v1/notification-events/sync` with active, owner-confirmed consent enforcement and batches limited to 100 entries.
- [x] Added account-scoped read endpoint and explicit deletion endpoint; no admin endpoint exposes notification content.
- [x] Notification payloads are encrypted with AES-256-GCM in SQLite; deduplication fingerprints use HMAC, and payload identity is authenticated as associated data.
- [x] Server retains at most 500 newest events per account; API returns up to 200 per read.
- [x] Android UI offers a separate, user-triggered upload action and an explicit server-history deletion action.
- [x] Android registers a locally generated random device key after authenticated Device Tools access; administrator inventory shows only account/device metadata, never notification or file contents.
- [x] Added regression tests for consent enforcement, deduplication, owner isolation, deletion, and ciphertext storage.
- [ ] Android compilation and real-device synchronization remain unverified because the environment does not provide Gradle/Android SDK.
- [ ] Screen capture sharing through Android MediaProjection, foreground-service UX, and owner-confirmed transfer to the server remain unimplemented. No covert screen capture is implemented.

Verification after this increment: 41 backend tests pass; Python compilation and admin JavaScript syntax check pass; OpenAPI document regenerated with 36 paths.


## Remote panel implementation plan (2026-10-28)
- Added `docs/REMOTE_PANEL_ROADMAP.md` with the staged device-command protocol, Android execution rules, panel UX, screen-sharing constraints, release gates, and end-to-end acceptance criteria.
- Re-ran the current source archive: 41 backend tests passed; Python compile and admin JavaScript syntax checks passed.
- No Android build was run: this environment has no Gradle executable or Gradle wrapper in the project. APK and physical-device functionality remain unverified.


## Simplified all-capabilities consent — 2026-10-28
- [x] Replaced separate first-run checkboxes with one plain-language umbrella consent for the disclosed capability set.
- [x] Records consent version, timestamp, scope, and a 365-day expiry; expired/missing expiry is treated as no active consent.
- [x] Added a visible revoke action that clears local consent and local session.
- [x] Clearly states that umbrella consent does not bypass Android system permission dialogs, grant unavailable features, or imply continuous recording.
- [ ] Android build, device tests, server-side consent sync, and end-to-end revocation/expiry enforcement remain unverified.


## 2026-10-28 — remote request queue integration

- Added `remote_commands` persistence with typed request allowlist, per-device ownership, 1–30 minute expiry, status transitions, result summaries and audit events.
- Added admin API to queue/list requests and an admin-panel device action selector plus queue view.
- Added owner-authenticated device polling and result-report endpoints. Polling is retryable for delivered requests; sensitive requests cannot enter `running` before owner acceptance.
- The queue requires an active, owner-confirmed `remote_panel` consent record. Revoking it cancels pending/in-progress requests; the client poll endpoint fails closed if consent is missing or expired.
- Added regression coverage: 43 backend tests pass; `node --check admin/app.js` and Python compile checks pass.
- Remaining: Android client does not yet synchronize the single-consent decision to `remote_panel`, poll/approve requests, or execute feature handlers. MediaProjection screen sharing and actual camera/microphone/location session flows remain unimplemented. Do not claim end-to-end remote operation yet.


## 2026-10-28 — Android request queue client integration

- Added API calls for server-synchronized unified `remote_panel` consent, pending-request polling, and typed result reporting.
- Persisted the registered server device ID. The client polls only while the device-tools screen is resumed and displays explicit on-device Accept/Reject controls.
- Connected owner-approved requests to the visible Android camera UI, system recorder, system document picker, notification history sync, and backups of files already selected by the owner. Media is saved locally; this queue does not stream camera/microphone content to the panel.
- Added a single consent re-sync attempt when polling indicates that the server consent is missing/expired. Local revocation attempts to send a server revocation before the server session is logged out. If the device is offline, server revocation cannot be guaranteed until connectivity returns.
- Removed duplicate remote-command route definitions so the strict owner-confirmed consent gate is the only route implementation.
- Validation: backend unit tests, Python compile checks, and JavaScript syntax check pass. Kotlin syntax scan found no parser errors, but a true Android Gradle build is unavailable because this environment has no Gradle wrapper/Android SDK dependencies. Screen sharing and location delivery are explicitly not implemented; no APK or end-to-end claim is made.


## 2026-10-28 — remote monitoring hardening follow-up

- Fixed the `RemoteCommandView` response schema to include `result_summary`, so the admin queue can display data returned by Android rather than silently omitting it.
- Added an admin-panel queue refresh every five seconds while an administrator is signed in; the timer stops on logout.
- Implemented one-time owner-approved location reporting: separate revocable consent, on-device Accept/Reject, current Android foreground permission and location-services checks, fresh location acquisition with timeout, and a bounded result summary returned to the panel. No background tracking loop was added.
- Added regression assertions proving that command result summaries survive the API response and appear in the admin queue.
- Verification: 44 backend tests pass; Python compile and JavaScript syntax checks pass. Android SDK/Gradle are unavailable here, so Kotlin/Android build and physical-device behavior remain unverified. MediaProjection screen streaming and continuous/time-limited location sessions remain unimplemented.

## 2026-10-28 — live device health heartbeat

- Added an owner-authenticated `/v1/devices/{device_id}/heartbeat` endpoint gated by active owner-confirmed `remote_panel` consent.
- The Android client reports only minimal operational telemetry while the Device Tools screen is visible: battery percentage, charging state, validated network connectivity, app foreground state, Android version and app version. The server stores only the latest state, not a history stream.
- Admin device inventory now shows heartbeat freshness and online/offline status; panel refreshes device health every 10 seconds while the admin is signed in.
- Command polling refreshes `last_seen_at`; missing/expired consent fails closed.
- Added regression test for consent gating and admin visibility. Verification: 45 backend tests pass; Python compile and JavaScript syntax checks pass.
- This is live operational health monitoring, not screen viewing. MediaProjection screen sharing and APK/device testing are still outstanding; no Android SDK/Gradle is installed in this environment.

## 2026-10-28 — remote request lifecycle hardening

- Added an explicit server-side command transition graph to reject invalid state jumps (for example, a completed request cannot be moved back to running).
- Added administrator cancellation for queued, delivered, or accepted requests, with an audit event and a reason visible in the queue.
- The Android polling response includes recent cancellations for five minutes so an open client can dismiss stale prompts; late acceptance is rejected by the server.
- The panel only offers cancellation for requests that have not started. It explicitly indicates that an already-running action must be stopped on the device because remote stop is not supported for such actions yet.
- Added regression tests for cancellation, cancellation propagation, and late/invalid state changes.
- Verification: 46 backend tests pass; Python compile, OpenAPI generation, and admin JavaScript syntax checks pass. Android Gradle build and physical-device testing remain unverified because the environment has no Android SDK or Gradle wrapper.

## Consent lifecycle hardening follow-up — 2026-10-28

- [x] Revoking/denying a feature-specific consent cancels matching queued, delivered, and accepted remote requests (camera, microphone, selected-file access, notifications, backup, screen-share prompt, and location request types).
- [x] Unpairing a device cancels its queued/delivered/accepted requests before removing the device record.
- [x] Lifecycle cancellation no longer falsely marks already-running actions as stopped. Running actions remain visibly running until stopped/reported on the device; generic server cancellation cannot terminate an Android activity or system capture session.
- [x] Added regression coverage for feature-specific consent revocation and updated unified-consent lifecycle assertions.
- [x] Backend test suite: 47 passed; Python compilation and admin JavaScript syntax check passed.
- [ ] Android build, on-device stop propagation, end-to-end panel validation, and release gates remain outstanding.


## Monitoring and remote-session lifecycle hardening — 2026-10-28

- [x] Added persistent `stop_requested` state to remote commands, including upgrade migration for existing SQLite development databases.
- [x] Admin stop action signals supported long-running session types without falsely changing `running` to `cancelled`; device acknowledgement is required to reach a terminal state.
- [x] Device polling delivers stop signals, including through a narrow stop-only channel after umbrella-consent revocation; Android explicitly avoids treating receipt of a signal as proof of successful stop.
- [x] Unified or feature-specific consent revocation now requests stop for matching running screen-share/location sessions while cancelling queued requests.
- [x] Admin UI displays the distinction between a stop request and a confirmed stop.
- [x] Added regression test for stop signal delivery and acknowledgement.
- [ ] Implement the Android MediaProjection foreground session and a real local stop handler; screen monitoring remains not implemented.
- [ ] Add real-device end-to-end test of panel → backend → Android → actual stop → confirmed result.
- [ ] Android Gradle build and APK validation still require a configured SDK/JDK build environment.

Verification for this increment: 48 backend tests passed; Python compile and admin JavaScript syntax checks pass. No APK or physical-device test was performed.


## Monitoring/control lifecycle iteration v4 — 2026-10-28

Implemented in this iteration:
- Added owner-scoped `GET /v1/devices/{device_id}/status` and admin `GET /v1/admin/devices/{device_id}/status` snapshots.
- Status responses separate connection freshness, whether a heartbeat has ever been received, latest available telemetry, effective consent decisions, and active command/session state.
- Device status reports `unknown` when timestamps cannot be interpreted; the admin UI no longer incorrectly labels a device with no heartbeat as definitely offline.
- Added tests for owner isolation, administrative status access, consent effectiveness, and status without a heartbeat.
- Regenerated OpenAPI documentation for the new endpoints.

Verification:
- Backend unittest suite: 50 tests passed.
- Python compilation: passed.
- Admin JavaScript syntax check: passed.
- Android Gradle build and real-device end-to-end tests: not performed in this environment; screen streaming and remote SAF browsing remain incomplete and must not be represented as production-ready.

## Screen monitoring implementation slice — 2026-10-28

- [x] Added a bounded `PUT /v1/devices/{device_id}/screen-sessions/{command_id}/frame` endpoint. It accepts JPEG frames up to 512 KiB only for the authenticated device's active `screen_share_request`, with an unexpired owner-confirmed screen-share consent.
- [x] Added latest-frame storage in SQLite, SHA-256 metadata, and an admin-only frame endpoint that refuses to return frames after the session is stopped or consent is no longer effective.
- [x] Added deletion of stored frame data on screen-share consent revocation, umbrella remote-panel consent revocation, and final session result.
- [x] Added a visible Android foreground service based on `MediaProjection`, with mandatory Android system confirmation, an ongoing notification, bounded JPEG frames, HTTPS upload, and local stop on server rejection.
- [x] Added a separate revocable `screen_share` consent preference and routed `screen_share_request` through the system capture permission flow.
- [x] Added an admin preview section that fetches authenticated JPEG frames without putting bearer tokens into image URLs.
- [x] Added backend regression coverage for no-consent rejection, active session gating, JPEG validation, upload hash, admin retrieval, and stop-request denial.
- [ ] Android compilation and runtime behavior are not verified here: no Gradle executable/wrapper or Android SDK is installed in the execution environment.
- [ ] Real-device screen capture, Android 14/15 foreground-service behavior, sustained frame rate, network-loss stop, and end-to-end panel preview still require a physical-device or emulator run.
- [ ] Remote file browser remains incomplete. Existing owner-selected file picker and encrypted backup/upload flows are not yet a browsable panel-side file manager.

Verification in this iteration: 51 backend tests passed; `node --check admin/app.js` passed; OpenAPI generation was run. APK and Android device tests were not run.

## Transparent first-aid learning entry screen — 2026-10-28

- Added an actual first-aid learning screen as the initial in-app destination, with introductory lessons on scene safety, initial assessment, severe bleeding, CPR/AED, and waiting for professional help.
- The launcher label and header explicitly identify the app as AZAVAD and describe the first-aid learning focus; device-management capabilities remain in separately named navigation sections and are not disguised as medical lessons.
- Learning content is introductory and directs users to local emergency services and professional instruction. It is not a substitute for accredited practical training.
- Android build and on-device rendering have not been verified in this environment.
