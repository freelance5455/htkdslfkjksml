# АЗАВАД — инженерный прототип

**Статус:** development prototype; не предназначен для публичной production-эксплуатации. Android-приложение пока не собрано, сервер не прошёл независимый аудит безопасности, а production-развёртывание и восстановление резервной копии не проверены.

## Состав

- `backend/` — FastAPI API: регистрация и вход, отзыв сессий, роли, согласия, устройства, события безопасности, аудит, экспорт/удаление аккаунта и API автономной библиотеки.
- `admin/` — same-origin административная панель: пользователи, события, аудит и управление публикациями библиотеки.
- `android/` — исходный проект Kotlin/Compose. Сборка APK здесь не подтверждена; по просьбе владельца проекта текущий приоритет — серверная инфраструктура.
- `infra/`, `Dockerfile`, `docker-compose.yml` — заготовки локального развёртывания.
- `docs/` — архитектура, модель угроз, инвентаризация данных, матрица ролей, API, ограничения и журнал прогресса.

## Локальная разработка backend

Требуется Python 3.11+.

```sh
cd backend
python -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
pip install -r requirements-dev.txt
uvicorn app.main:app --reload
```

По умолчанию используется SQLite-файл для разработки. Создайте первого администратора интерактивной командой из `backend/`:

```sh
python -m app.bootstrap_admin
```

Тесты запускаются из корня проекта:

```sh
./scripts-checks.sh
```

## Подписанная публикация библиотеки

Материалы создаются как черновики и публикуются через административную панель/API. Публикация требует Ed25519-ключа и отклоняется, если ключ отсутствует или некорректен. Генерация ключей и переменные окружения описаны в `docs/DEPLOYMENT_DEV.md`. Приватный ключ нельзя помещать в репозиторий. До использования обновлений клиент должен закреплять доверенный публичный ключ вне того же недоверенного канала доставки; защита клиента от отката и процедура ротации ключа ещё не реализованы.

## Проверенное в текущей среде

- 34 серверных теста проходят, включая проверку ограничения частоты регистрации (5 попыток за час на клиентский адрес в односерверном режиме) и сброса лимита после окончания окна.
- Проверены синтаксис административного JavaScript, компиляция Python-исходников, OpenAPI и основные файлы конфигурации.
- Проверены подпись Ed25519 и неизменность уже опубликованной версии при редактировании черновика.
- Добавлен fail-closed барьер запуска в `AZAVAD_ENV=production` до закрытия production blockers; интерактивная документация API отключена вне development-режима.

Не выполнялись: Android-сборка/установка, Docker runtime, запуск GitHub Actions, production deployment, нагрузочные испытания, pentest и производительное восстановление резервной копии. Ограничители регистрации и входа рассчитаны только на один экземпляр сервиса; перед публичным развёртыванием необходим распределённый лимитер на reverse proxy/API gateway. См. `docs/TEST_REPORT.md`, `docs/SECURITY.md` и `docs/PROGRESS.md`.

## Резервная копия и восстановление SQLite (прототип)

Скрипт `backend/scripts/db_maintenance.py` делает согласованную SQLite-копию, проверяет `integrity_check` и внешние ключи, записывает SHA-256 sidecar-файл и ограничивает права файлов резервной копии до `0600` на POSIX-системах. Восстановление сначала проверяет контрольную сумму и базу во временном файле; существующий файл назначения не заменяется без `--force`.

```sh
# Из корня проекта — укажите реальный путь к dev-базе и новый путь резервной копии
python backend/scripts/db_maintenance.py backup backend/azavad_dev.sqlite3 /secure-backups/azavad-2026-10-28.sqlite3

# Восстановление в новый файл (безопаснее сначала восстановить отдельно и проверить)
python backend/scripts/db_maintenance.py restore /secure-backups/azavad-2026-10-28.sqlite3 /tmp/azavad-restored.sqlite3
```

Файлы резервных копий содержат персональные данные и должны храниться в защищённом месте. SHA-256 обнаруживает случайное повреждение, но не подтверждает подлинность против злоумышленника, который может заменить и базу, и sidecar. Это локальный инструмент для SQLite-прототипа, а не замена зашифрованным off-host копиям, контролю доступа и проверке восстановления в production.


## Owner-initiated device tools (development status)
The Android Media screen provides owner-triggered photo capture through the system camera preview, a system-recorder handoff, copying of files selected through Android's document picker (10 GB decimal per file), and optional local notification history encrypted with a device-bound Android Keystore key. Server backup is a separate explicit opt-in. Selected files upload in 8 MiB chunks over HTTPS, are encrypted per chunk at rest, can resume after interruption, and can be listed, restored to a user-selected destination, or deleted. No media, selected file, or notification is automatically uploaded.

**Important limitation:** authenticated encrypted server backup/restore of these files is not yet implemented. The existing account export covers application-managed account data only and must not be described as a full-device backup. Android compilation and real-device testing remain pending.

### Background location permission (current scope)
The Android app now declares coarse, fine, and background location permissions and provides an explicit opt-in/settings flow with a status check. This is permission onboarding only: this revision does **not** collect or upload coordinates, and does not claim live tracking. Any future location-sharing feature must be visibly enabled by the device owner, show a persistent foreground-service notification while active, report timestamp/accuracy and stale status, and include an easy stop/revoke control. Background location permission does not authorize background camera or microphone capture.


## Notification history synchronization

Android notification history can be uploaded only through a separate owner action with active owner-confirmed consent. Payloads are AES-256-GCM encrypted in the database, HMAC-deduplicated, owner-scoped, and retained to 500 records. Configure `AZAVAD_PERSONAL_DATA_ENCRYPTION_KEY` with a secret 32-byte URL-safe Base64 key before production. Android build and device tests remain outstanding.
