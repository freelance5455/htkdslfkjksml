package com.example.tabung

import android.app.*
import android.content.*
import android.os.Build
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class Remind : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val p = c.getSharedPreferences("w", Context.MODE_PRIVATE)
        if (i.action == Intent.ACTION_BOOT_COMPLETED) {
            plan(c, p.getBoolean("on", false), p.getInt("h", 20), p.getInt("m", 0), p.getInt("dm", ALL_DAYS))
            return
        }
        val j = JSONObject(p.getString("j", "{}")!!)
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        if (j.optBoolean("d") && j.optString("dt") == today) return // sudah nabung hari ini
        val dow = Calendar.getInstance().get(Calendar.DAY_OF_WEEK) - 1 // 0 = Minggu
        if (((p.getInt("dm", ALL_DAYS) shr dow) and 1) == 0) return // hari ini tidak dipilih
        show(c)
    }

    companion object {
        // Bit 0 = Minggu ... bit 6 = Sabtu. 127 = semua hari
        const val ALL_DAYS = 127

        fun show(c: Context) {
            val j = JSONObject(c.getSharedPreferences("w", Context.MODE_PRIVATE).getString("j", "{}")!!)
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("r", "Pengingat nabung", NotificationManager.IMPORTANCE_DEFAULT))
            val pi = PendingIntent.getActivity(c, 2, Intent(c, MainActivity::class.java).putExtra("fill", true), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, "r") else Notification.Builder(c)
            val nama = j.optString("n")
            val isi = if (nama.isNotEmpty()) "Progres “$nama”: ${j.optInt("p")}%. Ketuk untuk isi hari ini." else "Kamu belum nabung hari ini. Ketuk untuk isi."
            nm.notify(1, b.setSmallIcon(android.R.drawable.ic_menu_my_calendar).setContentTitle("Waktunya nabung 🐷").setContentText(isi).setContentIntent(pi).setAutoCancel(true).build())
        }

        fun plan(c: Context, on: Boolean, h: Int, m: Int, days: Int) {
            c.getSharedPreferences("w", Context.MODE_PRIVATE).edit().putBoolean("on", on).putInt("h", h).putInt("m", m).putInt("dm", days).apply()
            val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = PendingIntent.getBroadcast(c, 3, Intent(c, Remind::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            am.cancel(pi)
            if (!on) return
            val t = Calendar.getInstance()
            t.set(Calendar.HOUR_OF_DAY, h); t.set(Calendar.MINUTE, m); t.set(Calendar.SECOND, 0)
            if (t.timeInMillis <= System.currentTimeMillis()) t.add(Calendar.DAY_OF_MONTH, 1)
            am.setInexactRepeating(AlarmManager.RTC_WAKEUP, t.timeInMillis, AlarmManager.INTERVAL_DAY, pi)
        }
    }
}
