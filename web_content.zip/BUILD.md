# Building AirTouch with ZIP2APK / any Gradle build server

Project root = the zip root (`settings.gradle.kts` is at the top level, single module `:app`).

| Item | Value |
|---|---|
| Build command | `./gradlew assembleDebug` (or `assembleRelease` – debug-signed, installable) |
| APK output | `app/build/outputs/apk/debug/app-debug.apk` |
| JDK | 17 |
| Android SDK | platform `android-34`, build-tools `34.0.0` (set `ANDROID_HOME`, or `sdk.dir` in `local.properties`) |
| Gradle | 8.7, AGP 8.5.2, Kotlin 1.9.24 |
| Network during build | needs Google Maven + Maven Central (dependencies incl. MediaPipe `tasks-vision`) |
| Hand model | bundled automatically if the build machine has internet; otherwise the app downloads it once (button in the app) |

`./gradlew` works without `gradle-wrapper.jar`: it uses the wrapper jar if present, else `gradle` from PATH,
else downloads Gradle 8.7 from the URL in `gradle/wrapper/gradle-wrapper.properties`.

Modules/files: single module `:app`; Kotlin sources in `app/src/main/java/com/suraj/airtouch/`; HTML start page in `app/src/main/assets/www/`.

STATUS: NOT TESTED IN THIS ENVIRONMENT (no JDK/Android SDK/Gradle/network here). The Kotlin sources and the
gradlew script were only syntax-reviewed, never compiled.
