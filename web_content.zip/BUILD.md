# BUILD — Public Data Mode
1. Upload ZIP ini ke HTML-to-APK builder. `index.html` ada di root.
2. Deploy folder `backend/` ke server HTTPS yang bisa mengakses internet.
3. Di APK > API Settings, isi URL backend.
4. Data publik diperbarui otomatis sekitar 5 menit saat backend tersedia.
5. Status data harus dianggap DELAYED/PUBLIC, bukan realtime resmi IDX.


### Backend provider setup
On the backend server, copy `backend/.env.example` to `.env` and set GOAPI_API_KEY and/or ALPHAVANTAGE_API_KEY. Do not put keys in the Android/Web APK.
