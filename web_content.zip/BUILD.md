# Kisu-Game-Booster

npm install
npm run build
npx cap add android
npx cap sync android
cd android && ./gradlew assembleDebug

APK: android/app/build/outputs/apk/debug/app-debug.apk
