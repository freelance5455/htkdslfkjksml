# BUILD

1. Upload ZIP ini ke builder HTML-to-APK yang menerima `index.html` di root.
2. Tidak perlu GitHub/GitLab.
3. Setelah APK jadi, isi URL backend pada Pengaturan API.
4. Endpoint scanner yang dipakai: `/scan?market=IDX&universe=all` (market dapat US/HK/JP/SG/GLOBAL).

Catatan: mode demo bukan data real-time. Untuk semua saham dan sinyal live, gunakan provider data pasar berlisensi melalui backend. Jangan simpan API secret provider di APK.
