# Phone build

Recommended: HTML to App / HTML to APK style builders that accept a website ZIP.

Rules:
- `index.html` must remain at ZIP root.
- Do not nest the whole project inside another folder.
- Upload the ZIP, set app name to MasterFlow Trading, then Build APK.

The free tiers of some current builders accept ZIP + index.html and output a signed APK. Check the builder's current limits before upload.
