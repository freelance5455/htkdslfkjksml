# Build the APK (needs Node 18+, Android Studio / JDK 17)
npm install
npx cap add android
npx cap sync
cd android && ./gradlew assembleDebug
# APK: android/app/build/outputs/apk/debug/app-debug.apk
# (or: npx cap open android -> Build > Build APK)
