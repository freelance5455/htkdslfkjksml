# World Soccer Player

Versão inicial instalável (PWA) do simulador de carreira.

## Instalar no Android
1. Hospede esta pasta em um endereço HTTPS (por exemplo, GitHub Pages ou Netlify).
2. Abra o endereço no Chrome do Android.
3. Abra o menu ⋮ e selecione **Instalar app** ou **Adicionar à tela inicial**.
4. Abra pelo ícone instalado. O app guarda o progresso neste dispositivo e possui cache offline após o primeiro carregamento.

> Importante: abrir `index.html` diretamente como arquivo não instala o PWA. É necessário servir por HTTPS ou localhost.

## Conteúdo incluído
- Criação de jogador e perfil.
- Dashboard de carreira.
- Atributos, treino, energia, moral e forma.
- Central de partidas com escolhas por lance e placar.
- Contratos e transferências simplificadas.
- Caixa de entrada, notícias e histórico.
- Dinheiro infinito ativado na edição pessoal.
- Salvamento automático local e exportação de backup.
- Manifesto, ícones e service worker para instalação/offline.

## Próximas expansões recomendadas
Motor de partidas mais profundo, calendário completo, ligas e elencos licenciados ou fictícios, scouting, negociações detalhadas, lesões, imprensa, seleção nacional, premiações, patrocinadores, academia de base, temporadas e nuvem.

Esta é uma base jogável de protótipo, não um jogo AAA nem um APK assinado. Para publicar como APK/AAB, será necessário empacotar com Capacitor ou desenvolver a versão Android nativa e assinar o pacote.
