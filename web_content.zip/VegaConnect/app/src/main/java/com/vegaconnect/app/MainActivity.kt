package com.vegaconnect.app

import android.Manifest
import android.app.Activity
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.ParcelUuid
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.net.URL
import java.net.URLEncoder
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.UUID
import java.util.concurrent.Executors
import javax.net.ssl.HttpsURLConnection
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private val serviceId = UUID.fromString("6e400001-b5a3-f393-e0a9-e50e24dcca9e")
    private val writeId = UUID.fromString("6e400002-b5a3-f393-e0a9-e50e24dcca9e")
    private val notifyId = UUID.fromString("6e400003-b5a3-f393-e0a9-e50e24dcca9e")
    private val cccd = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    private val io = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView
    private lateinit var deviceList: LinearLayout
    private lateinit var city: EditText
    private lateinit var format: Spinner
    private lateinit var unit: Spinner
    private var scanner: BluetoothLeScanner? = null
    private var gatt: BluetoothGatt? = null
    private var writeChar: BluetoothGattCharacteristic? = null
    private var notifyChar: BluetoothGattCharacteristic? = null
    private val found = linkedMapOf<String, BluetoothDevice>()
    private var weather: Wx? = null
    private var place = ""

    data class Day(val temp:Int,val max:Int,val min:Int,val code:Int,val wind:Int,val humidity:Int,val visibility:Int,val uv:Int,val precip:Int,val sunrise:IntArray=intArrayOf(0,0,0),val sunset:IntArray=intArrayOf(0,0,0))
    data class Wx(val current:Day,val days:List<Day>)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(16,42,58)
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,22,24,28); setBackgroundColor(0xFFF1F5F8.toInt()) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        content.addView(label("VEGA CONNECT", 26, 0xFF102A3A.toInt(), true))
        content.addView(label("Companion app • early development build", 14, 0xFF536675.toInt()))
        content.addView(section("1  Watch connection"))
        content.addView(button("Scan for Vega Neo", true) { requestBleAndScan() })
        deviceList = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        content.addView(deviceList)
        content.addView(section("2  Weather"))
        city = EditText(this).apply { hint="City (for example, Delhi)"; singleLine=true }
        content.addView(city)
        content.addView(button("Get weather", false) { fetchWeather() })
        content.addView(button("Send weather to watch", true) { sendWeather() })
        content.addView(section("3  Sync format"))
        format = Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Newer format • 7-day forecast", "Legacy format • 3-day forecast")) }
        content.addView(format)
        unit = Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Celsius", "Fahrenheit")) }
        content.addView(unit)
        content.addView(section("Status & limitations"))
        status = label("Ready. Turn on Bluetooth, then scan for your watch.", 14, 0xFF334B5A.toInt())
        content.addView(status)
        content.addView(label("This is a clean native foundation, not a replacement for all DaFit features yet. Watch compatibility and weather packet formats must be verified on the actual Vega Neo hardware. Keep the official app available until testing is complete.",13,0xFF536675.toInt()))
    }

    private fun label(s:String,size:Int,color:Int,bold:Boolean=false)=TextView(this).apply { text=s; textSize=size.toFloat(); setTextColor(color); if(bold) setTypeface(null,1); setPadding(0,8,0,8) }
    private fun section(s:String)=label(s,18,0xFF176B87.toInt(),true).apply { setPadding(0,22,0,8) }
    private fun button(s:String,primary:Boolean,action:()->Unit)=Button(this).apply { text=s; isAllCaps=false; setOnClickListener { action() }; if(primary) setTextColor(0xFF176B87.toInt()) }
    private fun say(s:String){ runOnUiThread { status.text=s } }

    private fun hasBlePermissions():Boolean = if(Build.VERSION.SDK_INT>=31) checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED else checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED
    private fun requestBleAndScan(){
        val perms=if(Build.VERSION.SDK_INT>=31) arrayOf(Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT) else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if(!hasBlePermissions()){ requestPermissions(perms,41); return }
        scan()
    }
    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){ super.onRequestPermissionsResult(requestCode,permissions,grantResults); if(requestCode==41 && grantResults.isNotEmpty() && grantResults.all{it==PackageManager.PERMISSION_GRANTED}) scan() else say("Bluetooth permission is needed to scan and connect.") }
    @Suppress("MissingPermission") private fun scan(){
        val manager=getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter=manager.adapter
        if(adapter==null || !adapter.isEnabled){ say("Please turn on Bluetooth."); return }
        scanner=adapter.bluetoothLeScanner; found.clear(); deviceList.removeAllViews(); say("Scanning for nearby Bluetooth devices…")
        val cb=object:ScanCallback(){ override fun onScanResult(type:Int,result:ScanResult){ val d=result.device; val key=d.address; if(!found.containsKey(key)){ found[key]=d; runOnUiThread { deviceList.addView(button("${d.name ?: "Unknown device"}  •  ${d.address}",false){ connect(d) }) } } }; override fun onScanFailed(errorCode:Int){ say("BLE scan failed: $errorCode") } }
        scanner?.startScan(listOf(ScanFilter.Builder().setServiceUuid(ParcelUuid(serviceId)).build()),ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(),cb)
        window.decorView.postDelayed({ try { scanner?.stopScan(cb) } catch(_:Exception){}; if(found.isEmpty()) say("No matching devices found. Keep the watch nearby and try again.") else say("Found ${found.size} device(s). Select your watch above.") },12000)
    }
    @Suppress("MissingPermission") private fun connect(device:BluetoothDevice){
        say("Connecting to ${device.name ?: device.address}…")
        gatt?.close()
        gatt=device.connectGatt(this,false,object:BluetoothGattCallback(){
            override fun onConnectionStateChange(g:BluetoothGatt,statusCode:Int,newState:Int){ if(newState==BluetoothProfile.STATE_CONNECTED){ g.discoverServices() } else if(newState==BluetoothProfile.STATE_DISCONNECTED){ writeChar=null; say("Watch disconnected.") } }
            override fun onServicesDiscovered(g:BluetoothGatt,statusCode:Int){ val svc=g.getService(serviceId); writeChar=svc?.getCharacteristic(writeId); notifyChar=svc?.getCharacteristic(notifyId); if(writeChar==null){ say("The expected watch service was not found."); return }; val n=notifyChar; if(n!=null){ g.setCharacteristicNotification(n,true); n.getDescriptor(cccd)?.let{ it.value=BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE; g.writeDescriptor(it) } }; say("Connected to ${device.name ?: "watch"}. Get weather, then send.") }
            override fun onCharacteristicChanged(g:BluetoothGatt,c:BluetoothGattCharacteristic,value:ByteArray){ say("Watch replied (${value.size} bytes).") }
        })
    }

    private fun fetchWeather(){ val name=city.text.toString().trim(); if(name.isEmpty()){ say("Enter a city name first."); return }; say("Looking up weather for $name…"); io.execute { try {
        val geo=JSONObject(URL("https://geocoding-api.open-meteo.com/v1/search?name="+URLEncoder.encode(name,"UTF-8")+"&count=1&language=en&format=json").readText())
        val results=geo.optJSONArray("results") ?: throw Exception("City not found")
        if(results.length()==0) throw Exception("City not found")
        val p=results.getJSONObject(0); val lat=p.getDouble("latitude"); val lon=p.getDouble("longitude"); place=p.optString("name",name)
        val url="https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m,visibility&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max,precipitation_probability_max&timezone=auto&forecast_days=7"
        val j=JSONObject(URL(url).readText()); val c=j.getJSONObject("current"); val d=j.getJSONObject("daily")
        fun arr(key:String,i:Int)=d.getJSONArray(key).optDouble(i,0.0)
        val days=(0 until d.getJSONArray("time").length()).map { i-> val sunrise=d.getJSONArray("sunrise").optString(i); val sunset=d.getJSONArray("sunset").optString(i); Day(arr("temperature_2m_max",i).roundToInt(),arr("temperature_2m_max",i).roundToInt(),arr("temperature_2m_min",i).roundToInt(),watchCode(arr("weather_code",i).roundToInt()),0,0,0,arr("uv_index_max",i).roundToInt(),arr("precipitation_probability_max",i).roundToInt(),clock(sunrise),clock(sunset)) }
        val cur=Day(c.optDouble("temperature_2m").roundToInt(),days.firstOrNull()?.max?:0,days.firstOrNull()?.min?:0,watchCode(c.optInt("weather_code")),c.optDouble("wind_speed_10m").roundToInt(),c.optInt("relative_humidity_2m"),(c.optDouble("visibility",0.0)/1000).roundToInt(),days.firstOrNull()?.uv?:0,days.firstOrNull()?.precip?:0)
        weather=Wx(cur,days); say("Weather loaded for $place • ${cur.temp}°C • ${days.size}-day forecast.")
    } catch(e:Exception){ say("Weather error: ${e.message}") } } }
    private fun clock(s:String):IntArray=try{ val t=s.substringAfter('T').split(':'); intArrayOf(t[0].toInt(),t[1].toInt(),0) }catch(_:Exception){intArrayOf(0,0,0)}
    private fun watchCode(c:Int)=when(c){0,1->1;2->2;3->3;45,48->9;51,53,55->13;56,57,66,67->18;61,63,80,81->4;65,82->14;71,77->16;73,85->8;75,86->17;95->5;96,99->6;else->0}

    private fun sendWeather(){ val w=weather; val ch=writeChar; if(w==null||ch==null){say("Connect your watch and load weather first.");return}; say("Sending weather packets…"); io.execute { try {
        val packets=mutableListOf(frame(byteArrayOf(0x02,0x1d),byteArrayOf(if(unit.selectedItemPosition==0)0 else 1)))
        val newer=format.selectedItemPosition==0
        val days=(if(newer) w.days.take(7) else w.days.take(3)).toMutableList(); while(days.size<(if(newer)7 else 3)) days.add(Day(0,0,0,0,0,0,0,0,0))
        val stamp=nowBytes(); val cityBytes=place.toByteArray(Charsets.UTF_8).take(66).toByteArray().copyOf(66)
        if(newer){ val current=stamp+cityBytes+weather2(w.current); val forecast=stamp+cityBytes+days.flatMap{weather2(it).toList()}.toByteArray(); packets.add(frame(byteArrayOf(0x04,0x0c),current)); packets.add(frame(byteArrayOf(0x04,0x0d),forecast)) }
        else { packets.add(frame(byteArrayOf(0x04,0x04),stamp+weather1(w.current))); packets.add(frame(byteArrayOf(0x04,0x05),stamp+days.flatMap{weather1(it).toList()}.toByteArray())) }
        for(packet in packets){ writeBle(packet); Thread.sleep(400) }
        say("Packets sent. Check the watch; protocol acceptance still needs physical-device verification.")
    }catch(e:Exception){say("Send failed: ${e.message}")} } }
    private fun nowBytes():ByteArray { val c=java.util.Calendar.getInstance(); return byteArrayOf((c.get(java.util.Calendar.YEAR)-2000).toByte(),(c.get(java.util.Calendar.MONTH)+1).toByte(),c.get(java.util.Calendar.DAY_OF_MONTH).toByte(),c.get(java.util.Calendar.HOUR_OF_DAY).toByte(),c.get(java.util.Calendar.MINUTE).toByte(),c.get(java.util.Calendar.SECOND).toByte()) }
    private fun weather2(d:Day):ByteArray { val b=ByteBuffer.allocate(20).order(ByteOrder.LITTLE_ENDIAN); b.put(d.temp.toByte()).put(d.max.toByte()).put(d.min.toByte()).putShort(d.code.toShort()).put(d.wind.toByte()).put(d.humidity.toByte()).put(d.visibility.toByte()).put(d.uv.toByte()).putShort(d.precip.toShort()); d.sunrise.forEach{b.put(it.toByte())}; d.sunset.forEach{b.put(it.toByte())}; b.putShort(0).put(0); return b.array() }
    private fun weather1(d:Day)=byteArrayOf(d.temp.toByte(),d.max.toByte(),d.min.toByte(),d.code.toByte(),d.wind.toByte(),d.humidity.toByte(),d.visibility.toByte(),d.uv.toByte(),(d.precip and 255).toByte(),(d.precip shr 8).toByte())
    private fun frame(key:ByteArray,payload:ByteArray):ByteArray { val size=payload.size+9; val out=ByteArray(size); out[0]=0xAB.toByte(); out[1]=1; out[2]=((size-6) shr 8).toByte(); out[3]=(size-6).toByte(); out[6]=key[0];out[7]=key[1];out[8]=0;payload.copyInto(out,9);var crc=0; for(i in 6 until out.size){crc=crc xor (out[i].toInt() and 255);repeat(8){crc=if((crc and 1)!=0)(crc ushr 1) xor 0xA001 else crc ushr 1}};out[4]=(crc shr 8).toByte();out[5]=crc.toByte();return out }
    @Suppress("MissingPermission") private fun writeBle(data:ByteArray){ val g=gatt?:throw Exception("Not connected"); val c=writeChar?:throw Exception("Write channel unavailable"); var offset=0; while(offset<data.size){ val end=minOf(offset+20,data.size); val part=data.copyOfRange(offset,end); if(Build.VERSION.SDK_INT>=33){ val result=g.writeCharacteristic(c,part,BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT); if(result!=BluetoothStatusCodes.SUCCESS) throw Exception("BLE write failed: $result") } else { c.writeType=BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT; c.value=part; if(!g.writeCharacteristic(c)) throw Exception("BLE write failed") }; Thread.sleep(80); offset=end } }
    override fun onDestroy(){ super.onDestroy(); try{scanner?.stopScan(object:ScanCallback(){})}catch(_:Exception){}; gatt?.close(); io.shutdownNow() }
}
