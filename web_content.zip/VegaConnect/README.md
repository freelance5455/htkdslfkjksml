# Vega Connect — Android Studio starter (0.1.0)

This is the first native Android Studio project foundation for the Vega Connect companion-app effort.

## Included in this starter
- Native Android app shell with a fresh Vega Connect identity.
- BLE scan filtered for the Nordic-UART-style service UUID used in the supplied weather HTML.
- GATT connection and characteristic discovery.
- Open-Meteo city geocoding and current/7-day weather retrieval.
- A native Kotlin port of the supplied HTML's CRC-16/ARC frame structure and v1/v2 weather payload layouts.
- Celsius/Fahrenheit selection and 20-byte BLE chunk writes.
- The original supplied HTML preserved under `docs/` as a reference.

## Important status — not a finished replacement app
The uploaded `com.beatxp.dafit(1).zip` is a **decompiled source export**, not an Android Studio project: it contains thousands of extracted Java/XML files and CFR decompiler notes, and it has no Gradle build files or wrapper. Decompiled code also contains methods the decompiler could not reconstruct. This starter therefore does not yet restore the complete DaFit feature set (health history, sleep, sport modes, notifications, watch faces, firmware update, account/cloud features, etc.). Those features require careful protocol and dependency reconstruction and testing.

The weather protocol values and payload structure are ported from the user-supplied HTML. They have not been independently verified against a physical Vega Neo / Vega Neon watch. In particular, the app's packet acceptance, GATT write mode/MTU timing, device variant, and v1/v2 selection need real-watch testing. Keep the official DaFit app installed and paired as a fallback until validation is complete.

## Open in Android Studio
1. Extract the ZIP.
2. Open the `VegaConnect` folder (the folder containing `settings.gradle.kts`).
3. Allow Android Studio to download the Android Gradle Plugin and Kotlin plugin dependencies.
4. Build > Make Project, then Run on an Android phone.

This environment did not have an Android SDK/Gradle installation available, so no APK has been built or device-tested here. Android Studio should use JDK 17 and Android SDK 35 for the configured build.

## Device test sequence
1. Install and open Vega Connect.
2. Enable Bluetooth and grant the requested nearby-device permissions.
3. Disconnect the watch from DaFit before testing; BLE watches commonly allow only one active companion connection.
4. Scan and select the watch only if it exposes the expected service.
5. Fetch weather by city, then try the selected packet format and inspect the watch.
6. Record whether the watch acknowledges or displays the data before treating sync as confirmed.

## Weather source
Open-Meteo public geocoding and forecast endpoints. An internet connection is required.
