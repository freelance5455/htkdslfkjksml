# Packaging THE LAST SIGNAL as an Android APK

> **Status: instructions only.** No APK was built while developing the game (the build environment had no Android SDK and no access to the npm registry), so none of the commands below were executed by me. They follow the documented workflows of each tool; expect to adjust version numbers.
>
> Before you package anything: the game itself is a normal website (`dist/`). If you only need it on your own phone, *Install app* from Chrome (see README, section 1A) gives the same fullscreen-landscape experience with no APK at all.

All three routes below are free. Pick one.

## Option 1 — Capacitor (offline APK, game files bundled inside)
Needs: Node 18+, Android Studio (includes the SDK and a JDK).

```bash
cd the-last-signal
npm run build                                   # produces dist/
npm install --save-dev @capacitor/core @capacitor/cli
npm install @capacitor/android
npx cap init "The Last Signal" com.yourname.lastsignal --web-dir dist
npx cap add android
npx cap sync android
```
Then make two small edits in the generated `android/` project:

1. `android/app/src/main/AndroidManifest.xml` — on the `<activity>` add `android:screenOrientation="sensorLandscape"` (landscape, either direction).
2. Keep the screen immersive (hides the navigation / status bars). In `MainActivity.java` (or `.kt`) add, inside the class:
   ```java
   @Override public void onWindowFocusChanged(boolean hasFocus) {
     super.onWindowFocusChanged(hasFocus);
     if (hasFocus) getWindow().getDecorView().setSystemUiVisibility(
       android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
       | android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
       | android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
   }
   ```
Build: `npx cap open android` → Android Studio → **Build ▸ Build Bundle(s) / APK(s) ▸ Build APK(s)** (debug APK, installable directly), or **Generate Signed Bundle / APK** for a release build (you create a free keystore yourself).
Or from a terminal: `cd android && ./gradlew assembleDebug` → `android/app/build/outputs/apk/debug/app-debug.apk`.

Notes: the game runs in the system WebView (same engine as Chrome, WebGL2 + WebAudio). The service worker the game registers is not needed inside the APK; it is harmless. Audio starts on the first tap, as in Chrome.

## Option 2 — Trusted Web Activity with Bubblewrap (APK that opens your hosted PWA)
Needs: the game hosted over **HTTPS** (see README 1A), Node 18+, JDK 17 + Android SDK (Bubblewrap offers to download them on first run).

```bash
npm install -g @bubblewrap/cli
mkdir tls-apk && cd tls-apk
bubblewrap init --manifest=https://YOUR-HOST/path/manifest.webmanifest
bubblewrap build          # creates app-release-signed.apk (and an .aab); it asks you to create a signing key
```
In the `init` questions choose orientation **landscape** and display **fullscreen**. To remove the browser address bar you must also publish a Digital Asset Links file at `https://YOUR-HOST/.well-known/assetlinks.json` containing the SHA-256 fingerprint of your signing key (`bubblewrap fingerprint` / the Bubblewrap docs show the exact JSON).

## Option 3 — PWABuilder (web UI, no local SDK)
1. Host the game over HTTPS.
2. Open <https://www.pwabuilder.com>, enter the URL, and run the report (the manifest and service worker in `dist/` are what it looks for).
3. **Package for stores ▸ Android** → download the zip → it contains a signed APK/AAB and instructions for the Digital Asset Links file.

## Sideloading the APK
Copy the `.apk` to the phone → open it → allow *Install unknown apps* for the file manager when asked. (Or `adb install app-debug.apk`.)

## Checks after packaging
* Landscape locked and fullscreen immersive.
* Tap START: the music/ambience must start (audio unlock) and the touch controls must respond.
* Rotate / background the app: the game pauses by itself.
* Settings ▸ Quality: if it stutters on the device, pick **Low**.
