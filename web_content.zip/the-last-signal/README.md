# THE LAST SIGNAL — Chapter 1: Vajra Deep

A first-person 3D survival-horror game that runs in a browser, built for **Android Chrome in landscape**.
You are Sgt. Kabir Sen. A radio message comes from a research station in India that has been sealed for 17 years:

> *"Please... help me get out of here. But if you hear your own voice... DO NOT ANSWER."*

The entrance locks behind you. Something lives inside, it cannot see well, and it hears everything.

* **One self-contained file** (`dist/index.html`, ~264 KB). No assets to download, no network calls at runtime, no accounts, no API keys, **no microphone**.
* Everything is procedural: geometry, textures, decals, the monster model, every sound and the speech-like radio voices.
* Custom **WebGL2** renderer (no Three.js — see "Technical decisions").
* Free tools only: Node + esbuild to build; the game itself needs nothing.

---

## 1. Play it

### A. Install it as an app on Android (recommended)
1. Put the contents of `dist/` on any free static host that serves **HTTPS** (GitHub Pages, Netlify Drop, Cloudflare Pages, …).
2. Open the URL in **Chrome on the phone** → ⋮ menu → **Install app** (or *Add to Home screen*).
3. Launch it from the home screen: it opens fullscreen, landscape, and works **offline** after the first load (service worker).

### B. Test on your own Wi-Fi
```bash
npm run serve            # = python3 -m http.server 8080 --directory dist
```
Open `http://<your-PC-LAN-IP>:8080/` in Chrome on the phone. The game runs, but plain-HTTP LAN addresses are not a "secure context", so Chrome will not offer *Install* or offline caching.
For the full install experience while developing, use USB debugging and `adb reverse tcp:8080 tcp:8080`, then open `http://localhost:8080` on the phone (localhost counts as secure).

### C. Just copy one file
Copy `dist/index.html` to the phone and open it with Chrome. It is fully self-contained. (Chrome may restrict storage for local files; if it does, *Continue* will not survive closing the tab. Use A or B for saves.)

Tap **START**: the game goes fullscreen and asks for landscape. If your phone has auto-rotate off, rotate it manually — in portrait the game shows a *rotate your device* screen and pauses.
Desktop browsers work too (keyboard + mouse), which is how most of the testing was done.

### Controls
| Touch (Android) | |
|---|---|
| Left half, drag | Move. Push the stick to its edge to **sprint** (loud!) |
| Right half, drag | Look |
| **USE** | Take, read, open, hide. Some actions are **hold** (generator starter, hatch wheel) |
| **FLASH** | Flashlight on/off (drains a battery) |
| **CROUCH** | Toggle. Quiet and harder to see |
| **RADIO** / **BAG** | Tune stations / items and documents |
| While hiding: **BREATH** (hold) and **LEAVE** | |

| Keyboard + mouse | |
|---|---|
| W A S D · Shift · C | Move · sprint · crouch |
| Mouse (click to capture) · F | Look · flashlight |
| E / Space (hold) · R · B · Q | Use · answer a voice · hold breath · leave hiding |
| Tab / I · Esc / P | Bag · pause |

URL options (handy for testing): `?q=low|medium|high` forces a graphics tier, `?debug=1` shows an fps / AI overlay, `?nosw=1` skips the service worker.

Settings (menu or pause): graphics **Auto / Low / Medium / High**, brightness, FOV, head bob, camera shake, look sensitivity, invert Y, push-stick-to-sprint, left-handed layout, vibration, master / music / effects volume, mute, subtitles, gameplay hints.

---

## 2. Build from source
```bash
npm install          # installs esbuild (the only dev dependency)
npm run build        # minified single-file bundle  ->  dist/index.html (+ manifest, icons, sw.js)
npm run dev          # same, unminified (readable stack traces)
npm test             # 45 Node logic checks (see "Tests")
```
`dist/` is already built and included, so you can skip this step just to play.

### Project structure
```
build.mjs                 bundles src/ into ONE dist/index.html (esbuild, IIFE, target chrome84) and copies the PWA files
src/
  index.template.html     page shell; the build injects CSS, UI fragments and JS
  main.js                 boot sequence, quality tier choice, audio unlock, fullscreen/landscape, pause-on-hide, render loop
  pwa/                    manifest.webmanifest, sw.js (offline cache), launcher icons
  css/  ui/               premium dark UI (red accents): menu, settings, controls, HUD, pause, bag, modals, game over, chapter complete
  engine/                 custom WebGL2 renderer + shaders, procedural textures, mesh builder, particles, math, noise
  world/                  grid world (28 areas, 18 doors, 54 lights), chunk builder, level layout, rooms, props, decals, power circuits
  game/
    game.js               orchestrator: modes, simulation step, saves, audio steering, quality governor
    player.js input.js    first-person movement / stamina / flashlight / hiding; touch joystick + look pad + buttons, keyboard + mouse
    monster.js nav.js     "The Listener": 7-state AI + A* navigation (see below)
    monster-model.js      procedural articulated monster model
    story.js data.js      objectives, scripted events, monster stages, checkpoints; all story text, codes and tuning constants
    actions.js interact.js  puzzles and interaction targeting
    state.js ui.js render.js game-world.js   saves/settings, DOM UI, per-frame rendering, world<->state glue
  audio/                  procedural WebAudio: engine (buses, reverb, positional), sfx (one-shots), scape (continuous layers)
tests/
  run-logic-tests.mjs     Node tests (npm test)        validate-layout.mjs   level geometry validator
  headless.mjs            builds the real world in Node with a stub renderer
  play/                   Playwright + headless Chrome end-to-end tests (Python)  — see "Tests"
tools/make-icons.py       regenerates the launcher icons (Pillow)
docs/APK.md               packaging as an Android APK
```

---

## 3. How it works

**The chapter** (8 sections, 28 areas): ① surface courtyard & entrance ramp → ② lobby (the blast door slams and locks), security checkpoint & guard room → ③ laboratory wing (corridors, break room, lockers, decontamination) → ④ research room & a hidden room → ⑤ generator hall → ⑥ storage hall & supervisor cage → ⑦ link corridor, ante-room and **Chamber Zero** (the Array) → ⑧ escape tunnel, surface hatch and the way out.

**Progression**: find the Level-1 keycard (locker code from a notice) → lab door → fuse from the break room → fuse box (power, and the monster wakes) → rack-panel puzzle from the whiteboard → fuel + breaker order from the generator placard + hold the starter (very loud) → tune the radio to **88.4** to hear the cage code → Level-3 keycard → tune **104.7** *next to the Array* to hear the null sequence → silence the Array (a wrong code is a surge the whole station hears) → the monster goes berserk → run to the hatch and hold the wheel. Eight checkpoints autosave.

**"The Listener"** (monster) — a real 7-state machine: *Idle, Patrol, Investigate, Search, Chase, Attack, Return*.
* **Hearing**: your noise radius depends on what you do — sprint 13 m, walk 5.2 m, crouch 1.6 m, standing still 0.4 m; hiding while holding breath 0 m. Doors (9 m, blast doors 20 m), wrong keypad codes, breakers, the radio, the generator (28–70 m) and the array surge (95 m) are heard too. Walls muffle sound (×1.7 distance).
* **Vision**: 8.5 m base range in a ±57° cone (wider when chasing); your torch pointed at it makes you visible at 15 m, standing in a lit room 12 m; sprinting ×1.2, crouching ×0.62. Awareness builds up; it never sees through walls.
* **Movement**: grid A* with wall-proximity cost and string-pulling; it opens doors itself (taking time), cannot pass locked / unpowered ones, never teleports (tests assert maximum per-frame step and that it never ends up inside a wall). Patrol 1.55 m/s, investigate 2.5, chase 3.7 → 4.5 m/s.
* **Hiding**: when a search ends at a cabinet/locker/crate it checks the nearest ones. Odds of finding you: 7 % while you hold your breath, 50 % normally, 100 % if you gasped or it watched you go in.
* **"Your own voice"**: occasionally a voice calls to you from the dark. Pressing **ANSWER** (R) in the short window is the mistake the radio warned about. No microphone is ever used — the imitation is synthesised.

**Audio**: no audio files. Footsteps by surface, breathing, heartbeat, doors, generator, radio static and speech-like voices, whispers, drips, the chase score, jumpscares and an output limiter, all synthesised with WebAudio; sounds are positional with wall occlusion; volume/mute settings.

**Performance**: Low / Medium / High tiers (render-resolution cap, light count, shadow map on High only, particle density). *Auto* picks a tier from the device (touch devices start on Medium, Low on ≤2 GB RAM) and a governor steps the tier down if the frame time stays above ~34 ms. Area-link culling, chunked static meshes, ≤ ~140 draw calls and ≤ ~13 k triangles per frame in the tests. WebGL context loss is handled.

### Technical decisions (and why)
* **No Three.js.** The brief preferred it "if supported"; the build environment could not reach the npm registry, so Three.js could not be installed; a small purpose-built WebGL2 renderer was written instead (which also keeps the whole game at ~264 KB).
* **One file.** The game is easy to hand to a phone, host anywhere, or wrap in an APK.
* **Grid level, continuous movement.** The facility is a 1 m grid (126 × 80) carved into rooms; collision, line of sight and AI navigation are cheap and exactly testable in Node.

---

## 4. Tests
Run `npm test` for the logic tests. The browser tests need Python, `pip install playwright pillow` and Chrome (paths in `tests/play/lib.py`); each is a separate script: `python3 tests/play/chain.py`.

| What | How | Covers |
|---|---|---|
| `npm test` — **45 checks** (Node) | real world + real `Nav` / `Grid` / `Monster` / `GameState` | layout validity, items & puzzle data consistency (codes match their clues, every document placed), resource economy, collision (40 k random steps), line of sight, A* reachability of every item / hiding place / waypoint, locked-door semantics, path speed, saves (round trip / corrupt data), monster: patrol without teleporting, hearing, vision modifiers (crouch / sprint / torch / lit rooms / walls / facing away), chase → attack → death, hiding odds (7 % / 50 % / 100 %), losing you, doors, speed scaling |
| `play/chain.py` | headless Chrome, a bot driving the real game and **real UI clicks** | the whole chapter start → *Chapter Complete*: every puzzle (right and wrong answers), radio, power, doors, objectives, cage, array, hatch |
| `play/ai.py`, `hide.py` | real `Game.step` | state transitions, no teleporting, noise & vision, attack / death / retry, hiding & being found |
| `play/mobile.py` | 844×390 touch emulation, multi-touch via CDP | joystick, look pad, buttons, hold-use, pause / settings flow |
| `play/save.py` | | checkpoints, *Continue*, pickups restored, corrupt save |
| `play/governor.py`, `perf*.py` | | auto-quality steps down only on slow frames and respects explicit choice; draw-call / triangle budget per tier |
| `play/audio.py` | analyser on the output | all 46 one-shot sounds and 8 ambience layers produce signal and none exceed the limiter ceiling |
| `play/pwa.py` | local HTTP server | manifest and icons valid, service worker activates, the game **boots and starts a new game offline** |
| `play/tour.py` | screenshots | all 28 areas rendered and visually checked |

The final run was made against the **minified production bundle**.

---

## 5. Implemented features
Core: first-person movement (walk / sprint with stamina / crouch), mouse + keyboard and touch (floating joystick, look pad, on-screen buttons, left-handed layout), flashlight with battery drain and flicker, batteries (13 in the level) and medkits (6), interaction prompts with hold-actions, keys / keycards, documents (13 papers + 2 radio transcripts) in a bag, doors (metal / blast / shutter / rack) with power and key locks, 31 hiding spots (cabinets, lockers, crates) with breath holding, health and death → Game Over → retry from checkpoint, 8 autosaved checkpoints, *Continue*, pause, objective HUD, subtitles, chapter-complete statistics, 2 secrets.

Puzzles: locker keypad, supervisor-cage keypad (code from the radio), rack panel (from a whiteboard), breaker order (placard), fuse box, fuel + generator starter, Array null-sequence console (code from the radio, only receivable beside the Array), hatch wheel.

Atmosphere: dynamic lights with flicker and power circuits, fog, dust and spark / blood / steam particles, decals, flashlight with optional shadow map on High, vignette, film grain, chromatic aberration, damage flash, radio static and glitch post effects, camera shake, heartbeat and breathing that follow danger, chase music, scripted scares, the voice imitation event, procedural WebAudio sound design.

UI: premium dark UI with red accents — loading bar, main menu (Start, Continue, Settings, Controls), pause, bag / inventory, objective, settings, controls, radio tuner, Game Over, Chapter Complete; no page scroll; rotate-device screen; auto pause on tab hide / rotation.

---

## 6. Known limitations — please read
Things I could **not** verify in the build environment, so I am not claiming them:
* **Real Android devices.** Nothing was run on a physical phone or emulator. Frame rates, thermals, GPU quirks and memory on *your* mid-range phone are unmeasured; all rendering tests ran in headless desktop Chrome with a *software* GL rasteriser. Relative costs (Low : Medium : High ≈ 1 : 1.9 : 3.6) and draw/triangle budgets were measured; absolute fps was not. The Auto governor and the three tiers exist for this reason — if it stutters, choose **Low**.
* **How the audio sounds.** It was checked numerically (every sound produces signal, nothing clips, no errors), but nobody has listened to the mix. Expect to tune volumes. The synthesised voices are intentionally robotic.
* **Touch feel.** Multi-touch was tested with synthetic touch events; ergonomics on real glass (thumb reach, button sizes) are unverified.
* **APK packaging.** Instructions are in `docs/APK.md`, but no APK was built (no Android SDK / npm network access here).
* **Balance by real players.** Difficulty was tuned by simulation, not by human playtesting. A speed-running bot finishes in about 5 minutes of game time; a first-time player will take much longer (not measured).

Design limits: Chapter 1 only; one save slot; English only; no gamepad support; Chrome / Chromium-based browsers on Android and desktop are the targets (iOS Safari is untested); stylised low-poly visuals; the monster uses grid navigation, so very tight furniture gaps can make it take detours.
