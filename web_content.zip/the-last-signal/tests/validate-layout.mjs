// Level sanity checks: overlaps, door placement, connectivity, height continuity. Also dumps a PNG-able map.
import { Grid } from '../src/world/grid.js';
import { AREAS, DOORS, START, LIGHTS } from '../src/world/layout.js';
import fs from 'node:fs';

const g = new Grid();
let errors = 0;
const err = (m) => { console.error('  ✗ ' + m); errors++; };
const ok = (m) => console.log('  ✓ ' + m);

// 1. areas do not overlap
let overlap = 0;
for (let i = 0; i < AREAS.length; i++) for (let j = i + 1; j < AREAS.length; j++) {
  const a = AREAS[i], b = AREAS[j];
  if (a.x0 < b.x1 && b.x0 < a.x1 && a.z0 < b.z1 && b.z0 < a.z1) { err(`areas overlap: ${a.id} / ${b.id}`); overlap++; }
}
if (!overlap) ok(`${AREAS.length} areas, no overlaps`);

// 2. areas inside the grid; each area fully surrounded by a solid ring or a door/neighbour
for (const a of AREAS) if (a.x0 < 1 || a.z0 < 1 || a.x1 > g.W - 1 || a.z1 > g.H - 1) err(`area ${a.id} touches grid edge`);

// 3. doors: both sides walkable (area cells), wall row solid on the other cells
for (const d of DOORS) {
  const gd = g.doors[g.doorIndex[d.id]];
  for (const c of gd.cells) {
    const x = c % g.W, z = Math.floor(c / g.W);
    const nb = d.axis === 'x' ? [[x, z - 1], [x, z + 1]] : [[x - 1, z], [x + 1, z]];
    for (const [nx, nz] of nb) { const k = nz * g.W + nx; if (g.solid[k] || g.doorAt[k] >= 0 && g.doorAt[k] !== g.doorIndex[d.id]) err(`door ${d.id} cell (${x},${z}) neighbour (${nx},${nz}) not walkable`); }
    // lateral neighbours must be solid (door sits inside a wall) unless the opening spans a shared boundary
    const lat = d.axis === 'x' ? [[x - 1, z], [x + 1, z]] : [[x, z - 1], [x, z + 1]];
    for (const [nx, nz] of lat) { const k = nz * g.W + nx; if (!g.solid[k] && g.doorAt[k] !== g.doorIndex[d.id]) err(`door ${d.id} cell (${x},${z}) lateral (${nx},${nz}) is not wall`); }
  }
}
ok(`${DOORS.length} doors checked`);

// 4. height continuity across every pair of adjacent walkable cells
let steps = 0;
for (let z = 0; z < g.H; z++) for (let x = 0; x < g.W; x++) {
  if (g.solid[z * g.W + x]) continue;
  for (const [dx, dz] of [[1, 0], [0, 1]]) {
    const nx = x + dx, nz = z + dz;
    if (nx >= g.W || nz >= g.H || g.solid[nz * g.W + nx]) continue;
    const y0 = g.floorY(x + 0.5, z + 0.5), y1 = g.floorY(nx + 0.5, nz + 0.5);
    if (Math.abs(y0 - y1) > 0.6) { err(`floor step ${(y1 - y0).toFixed(2)}m between (${x},${z}) and (${nx},${nz})`); steps++; }
  }
}
if (!steps) ok('floor heights continuous (max step < 0.6 m)');

// 5. connectivity from START ignoring locks (doors treated as passable)
const seen = new Uint8Array(g.W * g.H); const q = [[Math.floor(START.x), Math.floor(START.z)]]; seen[q[0][1] * g.W + q[0][0]] = 1;
while (q.length) { const [x, z] = q.pop(); for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const nx = x + dx, nz = z + dz; if (nx < 0 || nz < 0 || nx >= g.W || nz >= g.H) continue; const k = nz * g.W + nx; if (g.solid[k] || seen[k]) continue; seen[k] = 1; q.push([nx, nz]); } }
for (const a of AREAS) { const k = Math.floor((a.z0 + a.z1) / 2) * g.W + Math.floor((a.x0 + a.x1) / 2); if (!seen[k]) err(`area ${a.id} unreachable from start`); }
ok('every area reachable from the start (locks ignored)');

// 6. lights inside their area
for (const l of LIGHTS) { const ai = g.areaAt(l.x, l.z); if (ai < 0 || g.areas[ai].id !== l.area) err(`light at (${l.x},${l.z}) not inside area ${l.area} (is ${ai < 0 ? 'solid' : g.areas[ai].id})`); }
ok(`${LIGHTS.length} lights checked`);

// map dump for visual inspection
const rgba = Buffer.alloc(g.W * g.H * 4);
for (let i = 0; i < g.W * g.H; i++) {
  let c = [14, 14, 18];
  if (!g.solid[i]) { const a = g.areas[g.area[i]]; const y = g.floorY((i % g.W) + 0.5, Math.floor(i / g.W) + 0.5); const v = 90 + (y + 10) * 9; c = a && a.outdoor ? [60, 90, 70] : [v, v * 0.9, v * 0.8]; }
  if (g.doorAt[i] >= 0) c = [200, 60, 50];
  rgba.set([...c, 255], i * 4);
}
fs.writeFileSync(process.argv[2] || '/tmp/map.rgba', rgba);
console.log(errors ? `\n${errors} problem(s)` : '\nlayout OK');
process.exit(errors ? 1 : 0);
