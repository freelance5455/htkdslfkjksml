import sys
from lib import *
BOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bot.js')
def call(pg, expr):
    return pg.evaluate(expr)
with session('preserve=1&q=low') as (pg, logs):
    pg.add_script_tag(path=BOT)
    pg.click('[data-act=start]')
    pg.wait_for_timeout(600)
    call(pg, "__bot.god(true)")
    print('start', call(pg, "__bot.state()"))
    # skip the title card time: sim a bit
    call(pg, "__bot.sim(60)")
    r = call(pg, "__bot.useOn('n_brief')"); print('use n_brief', r)
    print('modal', call(pg, "__tls.ui.modal"), 'note title:', call(pg, "document.getElementById('note-title').textContent"))
    print(shot(pg, 'chain1_note'))
    pg.click('#note [data-act=close-modal]')
    pg.wait_for_timeout(200)
    print('modal after close', call(pg, "__tls.ui.modal"))
    r = call(pg, "__bot.goTo(44.5, 62.5)"); print('goto lobby', r)
    print(call(pg, "__bot.state()"))
    call(pg, "__bot.sim(90)")
    print('after slam', call(pg, "__bot.state()"))
    print('blast door:', call(pg, "(()=>{const g=__tls.world.grid;const d=g.doors[g.doorIndex.d_blast];return {t:d.t,locked:d.locked,target:d.target}})()"))
    print(shot(pg, 'chain1_lobby'))
    flush(logs)
