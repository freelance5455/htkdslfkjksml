"""Hiding: enter a locker via the real interact path, monster searches nearby hide spots, breath-hold odds, leaving the spot."""
import sys, json
from lib import *
BOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bot.js')
fails = []
def ok(cond, msg):
    print(('  PASS ' if cond else '  FAIL ') + msg)
    if not cond: fails.append(msg)
def J(pg, e): return pg.evaluate(e)
with session('preserve=1&q=low') as (pg, logs):
    pg.add_script_tag(path=BOT); pg.click('[data-act=start]'); pg.wait_for_timeout(400)
    J(pg, "__bot.sim(30); const w=__tls.world; w.circ.lab=1; w.circCur={...w.circ}; __tls.game.story.mimicT=1e9; __tls.game.story.whisperT=1e9; 1")
    J(pg, "(()=>{const g=__tls.world.grid; g.doors[g.doorIndex.d_ck_lab].locked=false;})()")
    print('=== hide in lab locker h_lab1 (49.6,22.2) via the interaction system')
    r = J(pg, "(()=>{const g=__tls.game; __bot.god(true); return __bot.useOn('h_lab1')})()"); print('  useOn', r)
    J(pg, "__bot.sim(40)")
    st = J(pg, "(()=>{const P=__tls.game.player; return {hidden: !!P.hidden, x:+P.x.toFixed(2), z:+P.z.toFixed(2), ui: !document.getElementById('hidebtns').classList.contains('hidden'), slit: !document.getElementById('slit').classList.contains('hidden'), actionsHidden: document.getElementById('actions').classList.contains('hidden')}})()")
    print('  ', st)
    ok(st['hidden'], 'player is hidden after using the locker')
    ok(st['ui'] and st['slit'], 'hide UI (breath button + door slit) shown'); ok(st['actionsHidden'], 'regular action buttons hidden while hiding')
    shot(pg, 'hide_inside')
    print('=== monster searches: place it at the locker front, awareness high, player holding breath vs not')
    def trial(hold, n=12, sure=False):
        found = 0
        for i in range(n):
            J(pg, f"""(()=>{{const g=__tls.game,M=g.monster,P=g.player; __bot.god(false); P.health=100; P.alive=true;
              if (!P.hidden) {{ g.beginHide(__tls.world.content.hides.find(h=>h.id==='h_lab1')); }}
              g.hideDelay=0; if(!P.hidden) P.enterHide(g.hideSpot);
              M.spawn(49.5, 23.5, Math.PI, {{grace:0}}); M.setZones(['lab']); M.hideSeen = {'__tls.world.content.hides.find(h=>h.id===\"h_lab1\")' if sure else 'null'};
              M._beginSearch([49.6, 22.2]); P.breath=1; }})()""")
            r = J(pg, f"""(()=>{{const g=__tls.game,M=g.monster,P=g.player; let found=false;
              for (let k=0;k<30*14;k++) {{ g.input.held.{'add' if hold else 'delete'}('breath'); g.step(1/30); if (M.state===4||M.state===5||!P.hidden) {{ found=true; break; }} if (M.state===6) break; }}
              g.input.held.delete('breath'); return {{found, st:M.stateName, hidden:!!P.hidden}} }})()""")
            if r['found']: found += 1
            J(pg, "(()=>{const g=__tls.game; if (g.player.hidden) {} else { g.player.alive=true; g.player.health=100; } g.monster.active=false; })()")
        return found
    f_hold = trial(True, 14); f_nohold = trial(False, 14)
    print(f'  found while holding breath: {f_hold}/14   while not holding: {f_nohold}/14')
    ok(f_hold <= 5, f'holding breath makes hiding reliable ({f_hold}/14 found)')
    ok(f_nohold > f_hold, f'not holding breath is riskier ({f_nohold} vs {f_hold})')
    print('=== leave the hiding spot with the LEAVE button')
    J(pg, "(()=>{const g=__tls.game,P=g.player; g.monster.active=false; P.alive=true; P.health=100; __bot.god(true); if(!P.hidden){g.beginHide(__tls.world.content.hides.find(h=>h.id==='h_lab1')); g.hideDelay=0; P.enterHide(g.hideSpot);} g.ui.setHidden(true);})()")
    J(pg, "__bot.sim(30)")
    pg.click('#hidebtns [data-press=leave]'); pg.wait_for_timeout(500); J(pg, "__bot.sim(20)")
    st = J(pg, "(()=>{const P=__tls.game.player; return {hidden: !!P.hidden, x:+P.x.toFixed(2), z:+P.z.toFixed(2), actions: !document.getElementById('actions').classList.contains('hidden')}})()")
    print('  ', st); ok(not st['hidden'] and st['actions'], 'LEAVE button steps out and restores the controls')
    flush(logs, 10)
print('FAILS:', len(fails)); [print(' -', f) for f in fails]
