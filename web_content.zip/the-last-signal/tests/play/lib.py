"""Shared helpers for headless-Chrome playtests of dist/index.html (SwiftShader WebGL2).
Usage from a test script:  from lib import *;  with session(...) as (pg, logs): ..."""
import os, sys, time, json, contextlib
from playwright.sync_api import sync_playwright

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
SHOTS = os.environ.get('SHOTS', '/tmp/claude-0/-home-claude/96030653-8af7-555a-b70d-fbd14367d1f7/scratchpad/shots')
os.makedirs(SHOTS, exist_ok=True)
URL = 'file://' + os.path.join(ROOT, 'dist', 'index.html')
ARGS = ['--no-sandbox', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--autoplay-policy=no-user-gesture-required', '--disable-background-timer-throttling', '--disable-renderer-backgrounding']

@contextlib.contextmanager
def session(query='', size=(960, 540), mobile=False, dpr=1):
    logs = []
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path='/usr/bin/google-chrome', headless=True, args=ARGS)
        ctx = b.new_context(viewport={'width': size[0], 'height': size[1]}, device_scale_factor=dpr, has_touch=mobile, is_mobile=mobile)
        pg = ctx.new_page()
        pg.on('console', lambda m: logs.append(f'[{m.type}] {m.text}'))
        pg.on('pageerror', lambda e: logs.append(f'[pageerror] {e}'))
        pg.goto(URL + ('?' + query if query else ''))
        try:
            pg.wait_for_function('window.__ready === true', timeout=120000)
        except Exception as e:
            logs.append('[timeout waiting for __ready] ' + str(e)[:200])
        try:
            yield pg, logs
        finally:
            b.close()

def shot(pg, name):
    path = os.path.join(SHOTS, name + '.png'); pg.screenshot(path=path); return path

def ev(pg, js):
    return pg.evaluate(js)

def flush(logs, n=30):
    for l in logs[-n:]: print(l[:600])
    logs.clear()
