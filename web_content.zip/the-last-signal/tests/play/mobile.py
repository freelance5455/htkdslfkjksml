"""Mobile emulation (landscape 844x390, touch, dpr 2): real multi-touch via CDP -> joystick, look pad, buttons, hold-use, pause/settings flow."""
import sys, json, math
from lib import *
BOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bot.js')
fails = []
def ok(cond, msg):
    print(('  PASS ' if cond else '  FAIL ') + msg)
    if not cond: fails.append(msg)
def J(pg, e): return pg.evaluate(e)

with session('preserve=1&q=low&debug=1', size=(844, 390), mobile=True, dpr=2) as (pg, logs):
    cdp = pg.context.new_cdp_session(pg)
    def touch(kind, pts):
        cdp.send('Input.dispatchTouchEvent', {'type': kind, 'touchPoints': [{'x': x, 'y': y, 'id': i} for i, (x, y) in pts.items()]})
    pg.add_script_tag(path=BOT)
    print('coarse pointer:', J(pg, "matchMedia('(pointer:coarse)').matches"), ' viewport', J(pg, "[innerWidth, innerHeight, devicePixelRatio]"))
    shot(pg, 'm_menu')
    pg.tap('[data-act=start]'); pg.wait_for_timeout(1500)
    ok(J(pg, "__tls.game.mode") == 'play', 'Start works by touch tap')
    J(pg, "__bot.sim(150)"); pg.wait_for_timeout(300)   # let the intro fade settle
    shot(pg, 'm_play')
    # ---- joystick: drag up in the left zone -> forward movement
    p0 = J(pg, "[__tls.game.player.x, __tls.game.player.z]")
    touch('touchStart', {1: (150, 250)}); touch('touchMove', {1: (150, 220)}); touch('touchMove', {1: (150, 190)})
    pg.wait_for_timeout(1800)
    ok(J(pg, "__tls.game.input.my") > 0.5, f'joystick drag up gives forward axis (my={J(pg, "__tls.game.input.my"):.2f})')
    shot(pg, 'm_joystick')
    touch('touchEnd', {})
    pg.wait_for_timeout(300)
    p1 = J(pg, "[__tls.game.player.x, __tls.game.player.z]")
    print('   moved', [round(a-b, 2) for a, b in zip(p1, p0)])
    ok(math.hypot(p1[0]-p0[0], p1[1]-p0[1]) > 0.3, 'player moved with the on-screen joystick')
    ok(J(pg, "__tls.game.input.my") == 0, 'releasing the stick stops movement')
    # ---- look pad: drag right in the right zone -> yaw changes
    y0 = J(pg, "__tls.game.player.yaw")
    touch('touchStart', {2: (600, 160)}); 
    for i in range(1, 9): touch('touchMove', {2: (600 + i * 25, 160)}); pg.wait_for_timeout(30)
    touch('touchEnd', {}); pg.wait_for_timeout(200)
    y1 = J(pg, "__tls.game.player.yaw"); print('   yaw', round(y0, 3), '->', round(y1, 3))
    ok(abs(y1 - y0) > 0.3, 'look pad drag turns the camera')
    # pitch
    pt0 = J(pg, "__tls.game.player.pitch"); touch('touchStart', {2: (600, 160)})
    for i in range(1, 7): touch('touchMove', {2: (600, 160 - i * 18)}); pg.wait_for_timeout(30)
    touch('touchEnd', {}); pg.wait_for_timeout(150); pt1 = J(pg, "__tls.game.player.pitch"); ok(abs(pt1 - pt0) > 0.1, f'vertical drag changes pitch ({pt0:.2f}->{pt1:.2f})')
    # ---- simultaneous: move + look at the same time (two fingers)
    p0 = J(pg, "[__tls.game.player.x, __tls.game.player.z, __tls.game.player.yaw]")
    touch('touchStart', {1: (150, 250), 2: (600, 160)}); touch('touchMove', {1: (150, 190), 2: (600, 160)})
    for i in range(1, 8): touch('touchMove', {1: (150, 190), 2: (600 + i * 20, 160)}); pg.wait_for_timeout(60)
    pg.wait_for_timeout(600); touch('touchEnd', {}); pg.wait_for_timeout(200)
    p1 = J(pg, "[__tls.game.player.x, __tls.game.player.z, __tls.game.player.yaw]")
    ok(math.hypot(p1[0]-p0[0], p1[1]-p0[1]) > 0.2 and abs(p1[2]-p0[2]) > 0.2, 'multi-touch: walking and looking at the same time')
    # ---- buttons
    def tap_btn(sel, hold=0):
        b = pg.locator(sel); box = b.bounding_box(); cx, cy = box['x'] + box['width']/2, box['y'] + box['height']/2
        touch('touchStart', {5: (cx, cy)}); pg.wait_for_timeout(hold or 60); touch('touchEnd', {}); pg.wait_for_timeout(250)
    on0 = J(pg, "__tls.game.player.fl.on"); tap_btn('#btn-flash'); pg.wait_for_timeout(200)
    ok(J(pg, "__tls.game.player.fl.on") != on0, 'FLASH button toggles the flashlight'); shot(pg, 'm_flash')
    tap_btn('#btn-crouch'); pg.wait_for_timeout(200); ok(J(pg, "__tls.game.player.wantCrouch") is True, 'CROUCH button toggles crouch'); tap_btn('#btn-crouch')
    # sprint hold
    b = pg.locator('#btn-sprint').bounding_box(); touch('touchStart', {7: (b['x']+b['width']/2, b['y']+b['height']/2)}); pg.wait_for_timeout(200)
    ok(J(pg, "__tls.game.input.isHeld('sprint')"), 'SPRINT button is a hold'); touch('touchEnd', {}); pg.wait_for_timeout(150); ok(not J(pg, "__tls.game.input.isHeld('sprint')"), 'SPRINT releases')
    # ---- pause menu by touch
    tap_btn('[data-press=pause]'); pg.wait_for_timeout(400)
    ok(J(pg, "__tls.game.mode") == 'pause' and J(pg, "!document.getElementById('pause').classList.contains('hidden')"), 'PAUSE opens the pause menu'); shot(pg, 'm_pause')
    pg.tap('#pause [data-act=settings]'); pg.wait_for_timeout(400); ok(J(pg, "!document.getElementById('settings').classList.contains('hidden')"), 'Settings opens over the pause menu'); shot(pg, 'm_settings')
    # settings: change graphics quality + sensitivity through the real controls
    pg.tap('#settings [data-set=quality] button[data-v=low]'); pg.wait_for_timeout(1500); ok(J(pg, "__tls.R.qname") == 'low' and J(pg, "__tls.settings.quality") == 'low', 'quality segment switches the renderer tier')
    pg.tap('#settings [data-set=mute]'); pg.wait_for_timeout(200); ok(J(pg, "__tls.settings.mute") is True and J(pg, "__tls.E.vol.mute") is True, 'mute toggle reaches the audio engine')
    pg.tap('#settings [data-set=mute]'); pg.wait_for_timeout(200)
    sl = pg.locator('#settings input[data-set=sens]'); sl.evaluate("(e)=>{e.value=1.6; e.dispatchEvent(new Event('input'))}"); pg.wait_for_timeout(150)
    ok(abs(J(pg, "__tls.settings.sens") - 1.6) < 0.01 and abs(J(pg, "__tls.game.input.sens") - 1.6) < 0.01, 'sensitivity slider applies to input')
    pg.tap('#settings [data-act=close-settings]'); pg.wait_for_timeout(300)
    pg.tap('#pause [data-act=controls]'); pg.wait_for_timeout(300); shot(pg, 'm_controls'); pg.tap('#controls [data-act=close-controls]'); pg.wait_for_timeout(200)
    pg.tap('#pause [data-act=resume]'); pg.wait_for_timeout(400); ok(J(pg, "__tls.game.mode") == 'play', 'Resume returns to play')
    # ---- inventory by touch
    tap_btn('[data-press=inventory]'); pg.wait_for_timeout(400); ok(J(pg, "__tls.ui.modal") == 'inv', 'BAG opens inventory'); shot(pg, 'm_inv'); pg.tap('#inv [data-act=close-modal]'); pg.wait_for_timeout(250)
    # ---- portrait: rotate overlay and auto-pause
    pg.set_viewport_size({'width': 390, 'height': 844}); pg.wait_for_timeout(500)
    ok(J(pg, "!document.getElementById('rotate').classList.contains('hidden')"), 'portrait shows the rotate-device overlay'); ok(J(pg, "__tls.game.mode") in ('pause',), f'game auto-pauses in portrait (mode {J(pg, "__tls.game.mode")})'); shot(pg, 'm_portrait')
    pg.set_viewport_size({'width': 844, 'height': 390}); pg.wait_for_timeout(500)
    ok(J(pg, "document.getElementById('rotate').classList.contains('hidden')"), 'rotate overlay hides in landscape')
    flush(logs, 12)
print('FAILS:', len(fails)); [print(' -', f) for f in fails]
