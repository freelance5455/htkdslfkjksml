"""Full-chapter playthrough with the test bot (movement via the real input/physics/nav) + real DOM clicks for every UI puzzle.
Usage: python3 chain.py [stop_after_step_number]"""
import sys, json
from lib import *
BOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bot.js')
STOP = int(sys.argv[1]) if len(sys.argv) > 1 else 99
fails = []
def J(pg, e): return pg.evaluate(e)
def state(pg):
    s = J(pg, "__bot.state()"); s['flagset'] = set(s['flags'].split(',')); s['keyset'] = set(s['keys'].split(',')); return s
def modal(pg, name, t=4000):
    try: pg.wait_for_function(f"__tls.ui.modal === '{name}'", timeout=t); return True
    except Exception: return False
def ok(cond, msg, pg=None):
    print(('  PASS ' if cond else '  FAIL ') + msg)
    if not cond:
        fails.append(msg)
        if pg: shot(pg, 'FAIL_' + str(len(fails)))
    return cond
def use(pg, id, **o):
    r = J(pg, f"__bot.useOn({json.dumps(id)}, {json.dumps(o)})")
    ok(r.get('ok'), f'use {id} -> {r}', pg); return r
def go(pg, x, z, **o):
    r = J(pg, f"__bot.goTo({x},{z},{json.dumps(o)})")
    ok(r.get('ok'), f'goto ({x},{z}) -> {r}', pg); return r
def read(pg, id):
    r = use(pg, id)
    if r.get('ok'):
        ok(J(pg, "__tls.ui.modal") == 'note', f'note modal open for {id}')
        pg.click('#note [data-act=close-modal]'); pg.wait_for_timeout(120); J(pg, "__bot.sim(2)")
def sim(pg, n): J(pg, f"__bot.sim({n})")
def step(n, title):
    print(f'\n=== STEP {n}: {title}'); return n <= STOP

with session('preserve=1&q=low&debug=1') as (pg, logs):
    pg.add_script_tag(path=BOT)
    if step(1, 'new game'):
        pg.click('[data-act=start]'); pg.wait_for_timeout(500); J(pg, "__bot.god(true)"); sim(pg, 30)
        s = state(pg); ok(s['mode'] == 'play' and s['obj'] == 'start', f'playing, objective start: {s}')
    if step(2, 'courtyard -> lobby, blast door slams'):
        read(pg, 'n_brief'); go(pg, 44.5, 62.5); sim(pg, 120)
        s = state(pg); ok('blast' in s['flagset'] and s['obj'] == 'lobby', f'blast door sealed, objective lobby: {s["flags"]} / {s["obj"]}')
        ok(J(pg, "(()=>{const g=__tls.world.grid;const d=g.doors[g.doorIndex.d_blast];return d.t===0&&d.locked})()"), 'blast door closed + locked')
    if step(3, 'checkpoint + guard room + locker 4 keypad'):
        read(pg, 'n_closure'); read(pg, 'n_shiftlog'); read(pg, 'n_guardnote')
        r = use(pg, 'locker4')
        ok(J(pg, "__tls.ui.modal") == 'keypad', 'keypad modal open')
        shot(pg, 'chain_keypad')
        for d in '0000': pg.click(f'#kp-pad [data-k="{d}"]')
        pg.wait_for_timeout(900)
        ok(J(pg, "__tls.ui.modal") == 'keypad', 'wrong code keeps keypad open (resets)')
        for d in '1406': pg.click(f'#kp-pad [data-k="{d}"]')
        pg.wait_for_timeout(900); sim(pg, 3)
        s = state(pg); ok('keycard1' in s['keys'] and J(pg, "__tls.ui.modal") is None, f'keycard1 acquired, keypad closed: {s["keys"]}')
        ok(s['obj'] in ('labdoor',) , f'objective -> labdoor (got {s["obj"]})')
    if step(4, 'lab door (keycard) + fuse pickup'):
        r = J(pg, "__bot.touchDoor('d_ck_lab')"); print('  touch lab door', r); ok(r['door']['locked'] is False and r['door']['t'] > 0.9, 'lab door unlocked by keycard and opened', pg)
        go(pg, 48.5, 35.5); sim(pg, 30)
        s = state(pg); ok(s['obj'] in ('fuse', 'fuseBox'), f'objective fuse (got {s["obj"]}) after entering lab wing')
        use(pg, 'fuse'); s = state(pg); ok('fuse' in s['keys'], 'fuse picked up')
    if step(5, 'fuse box -> lab power, monster stage'):
        use(pg, 'fusebox'); sim(pg, 60); s = state(pg); ok('fuseInstalled' in s['flagset'], f'fuse installed: {s["flags"]}')
        ok(J(pg, "__tls.world.circ.lab") == 1, 'lab circuit on')
        print('  state:', s)
        shot(pg, 'chain_labpower')
    if step(6, 'research room: notes + rack panel puzzle'):
        for n in ['rao_note', 'research1', 'whiteboard']: read(pg, n)
        use(pg, 'panel'); ok(J(pg, "__tls.ui.modal") == 'panel', 'panel modal open'); shot(pg, 'chain_panel')
        sws = pg.query_selector_all('#pn-row .sw'); print('  switches:', len(sws), [s.get_attribute('class') for s in sws])
        # solution [1,0,0,1] from initial [0,1,1,0]: toggle all four
        for i in range(4): pg.click(f'#pn-row .sw:nth-child({i+1})'); pg.wait_for_timeout(80)
        pg.wait_for_timeout(700); sim(pg, 5)
        s = state(pg); ok('panelSolved' in s['flagset'], f'panel solved: {s["flags"]}')
    if step(7, 'secret room'):
        go(pg, 24.0, 20.9); sim(pg, 30)
        use(pg, 'keycard3_s'); read(pg, 'n_secret'); s = state(pg); ok('keycard3' in s['keys'] and s['flags'].find('x') >= -1, f'keycard3 from secret room: {s["keys"]}')
        print('  secrets:', J(pg, "__tls.game.state.secrets"))
    if step(8, 'generator: fuel, placard, breakers (wrong order then right), starter'):
        use(pg, 'fuel'); read(pg, 'placard')
        use(pg, 'breaker1'); sim(pg, 5)
        ok('breakersOk' not in state(pg)['flagset'], 'breaker 1 first is the wrong order (trips)')
        sim(pg, 40)
        ok(J(pg, "(__tls.game.state.puzzle.br||[]).length") == 0, 'tripped breakers reset')
        for n in (2, 3, 1): use(pg, f'breaker{n}'); sim(pg, 8)
        s = state(pg); ok('breakersOk' in s['flagset'], f'breakers solved 2-3-1: {s["flags"]}')
        use(pg, 'genfuel'); s = state(pg); ok('genFueled' in s['flagset'], 'generator fuelled')
        r = use(pg, 'starter', hold=3.4); sim(pg, 10)
        s = state(pg); ok('gen' in s['flagset'], f'generator running: {s["flags"]}'); ok(J(pg, "__tls.world.circ.gen") == 1, 'gen circuit on')
        print('  obj:', s['obj'], 'stage', s['stage']); shot(pg, 'chain_gen')
    if step(9, 'radio 88.4 staff channel -> cage code -> cage'):
        pg.click('[data-press=radio]'); ok(modal(pg, 'radio'), 'radio opens from HUD button', pg)
        J(pg, "(()=>{const r=document.getElementById('rd-range');r.value=884;r.dispatchEvent(new Event('input'))})()")
        sim(pg, 20); print('  radio info:', J(pg, "__tls.game.radioInfo()")); shot(pg, 'chain_radio')
        for _ in range(40):
            sim(pg, 30)
            if 'staff' in J(pg, "__tls.game.state.notes"): break
        ok('staff' in J(pg, "__tls.game.state.notes"), 'staff transcript captured into documents', pg)
        pg.click('#radio [data-act=close-modal]'); pg.wait_for_timeout(150); sim(pg, 3)
        go(pg, 69.5, 29.5); sim(pg, 5)   # in front of the storage shutter
        r = use(pg, 'cagekeypad'); ok(J(pg, "__tls.ui.modal") == 'keypad', 'cage keypad open')
        for d in '7319': pg.click(f'#kp-pad [data-k="{d}"]')
        pg.wait_for_timeout(900); sim(pg, 10); ok('cageOpen' in state(pg)['flagset'], 'cage opened with 7319')
        sim(pg, 90); use(pg, 'keycard3'); read(pg, 'n_cage'); print('  ', state(pg)['obj'])
    if step(10, 'ante-room, chamber, array console (wrong then right)'):
        r = J(pg, "__bot.touchDoor('d_ante')"); print('  ante', r); ok(r['door']['locked'] is False, 'ante door accepts keycard 3')
        go(pg, 94.0, 36.5); r = J(pg, "__bot.touchDoor('d_ch')"); print('  chamber door', r); ok(r['door']['t'] > 0.9, 'chamber door opened (powered)')
        go(pg, 99.5, 27.2); read(pg, 'n_chamber')
        # radio is weak outside the array zone, locks inside
        pg.click('[data-press=radio]'); ok(modal(pg, 'radio'), 'radio opens (chamber)', pg)
        J(pg, "(()=>{const r=document.getElementById('rd-range');r.value=1047;r.dispatchEvent(new Event('input'))})()")
        sim(pg, 20); info = J(pg, "__tls.game.radioInfo()"); print('  radio info in chamber:', info); ok(info['locked'], 'carrier 104.7 locks inside the array zone', pg)
        for _ in range(40):
            sim(pg, 30)
            if 'carrier' in J(pg, "__tls.game.state.notes"): break
        ok('carrier' in J(pg, "__tls.game.state.notes"), 'carrier transcript (null sequence) captured', pg)
        pg.click('#radio [data-act=close-modal]'); pg.wait_for_timeout(150); sim(pg, 3)
        use(pg, 'arraycon'); ok(J(pg, "__tls.ui.modal") == 'array', 'array console open'); shot(pg, 'chain_array')
        pg.click('#ar-go'); pg.wait_for_timeout(1000); sim(pg, 5)
        ok('arrayDone' not in state(pg)['flagset'], 'wrong sequence (000) rejected / surge'); print('  consoleLock', J(pg, "__tls.game.consoleLock"))
        sim(pg, 30 * 8)
        use(pg, 'arraycon')
        for i, n in enumerate([4, 1, 7]):
            for _ in range(n): pg.click(f'#ar-row .dial:nth-child({i+1}) button:first-child')
        shot(pg, 'chain_array2')
        pg.click('#ar-go'); pg.wait_for_timeout(1200); sim(pg, 10)
        s = state(pg); ok('arrayDone' in s['flagset'] and 'escape' in s['flagset'], f'array silenced -> escape: {s["flags"]}'); print('  obj', s['obj'], 'stage', s['stage'])
    if step(11, 'escape: route to hatch, wheel hold, exit, chapter complete'):
        J(pg, "(()=>{const g=__tls.game; g.monster.speedMul=1.0})()")
        r = J(pg, "__bot.touchDoor('d_esc')"); print('  esc door', r)
        # run (the bot walks; sprint to keep ahead of the berserk monster) to the hatch wheel
        r = use(pg, 'wheel', hold=5.6); print('  wheel', r); sim(pg, 20)
        s = state(pg); ok('exitWheel' in s['flagset'], f'hatch unsealed: {s["flags"]}', pg); shot(pg, 'chain_wheel')
        r = J(pg, "__bot.goTo(117.0,43.5,{})"); ok(r.get('ok') or r.get('why') == 'mode end', f'walk out (or the chapter already ended by itself): {r}', pg); sim(pg, 30)
        s = state(pg); ok('complete' in s['flagset'], f'chapter completed flag: {s["mode"]}', pg)
        sim(pg, 30 * 5)
        ok(J(pg, "!document.getElementById('complete').classList.contains('hidden')"), 'Chapter Complete screen visible', pg)
        print('  stats:', J(pg, "document.getElementById('cp-stats').innerText.replace(/\\n/g,' | ')"))
        pg.wait_for_timeout(600); shot(pg, 'chain_complete')
    print('\nstate:', state(pg)); flush(logs, 20)
print('\nFAILS:', len(fails)); [print(' -', f) for f in fails]
