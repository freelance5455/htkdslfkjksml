"""Monster AI scenarios driven through the real Game.step (no rendering): states, hearing, vision, chase, hiding, attack, death/retry."""
import sys, json
from lib import *
BOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bot.js')
fails = []
def ok(cond, msg):
    print(('  PASS ' if cond else '  FAIL ') + msg)
    if not cond: fails.append(msg)
def J(pg, e): return pg.evaluate(e)

SETUP = """
window.__ai = {
  M: () => __tls.game.monster, G: () => __tls.game, P: () => __tls.game.player,
  setup(mx, mz, px, pz, o = {}) {
    const g = __tls.game, M = g.monster, P = g.player;
    P.setPos(px, pz, o.pyaw ?? 0); P.alive = true; P.health = 100; P.god = false; P.hidden = null; P.fl.on = !!o.fl; P.wantCrouch = !!o.crouch;
    M.spawn(mx, mz, o.myaw ?? 0, { grace: o.grace ?? 0 }); M.setZones(o.zones || ['lab', 'front', 'service', 'deep']); M.speedMul = 1;
    g.state.stage = Math.max(g.state.stage, 2);
    g.story.mimicT = 1e9; g.story.whisperT = 1e9;   // keep the scripted scares out of the AI experiments
    g.player.stamina = 100;
  },
  // run n steps; returns timeline of state changes, max per-step displacement and min distance to player
  run(n, o = {}) {
    const g = __tls.game, M = g.monster, P = g.player, I = g.input, tl = []; let last = -1, maxStep = 0, px = M.x, pz = M.z, minD = 99, hits = 0, hp0 = P.health;
    for (let i = 0; i < n; i++) {
      if (o.each) o.each(i);
      g.step(1 / 30);
      if (M.state !== last) { tl.push([+(i / 30).toFixed(1), M.stateName]); last = M.state; }
      maxStep = Math.max(maxStep, Math.hypot(M.x - px, M.z - pz)); px = M.x; pz = M.z; minD = Math.min(minD, Math.hypot(M.x - P.x, M.z - P.z));
      if (o.until && o.until()) break;
    }
    return { tl, maxStepPerTick: +maxStep.toFixed(3), minDist: +minD.toFixed(1), end: M.stateName, mx: +M.x.toFixed(1), mz: +M.z.toFixed(1), hp: Math.round(P.health), steps: n };
  },
};
"""
with session('preserve=1&q=low') as (pg, logs):
    pg.add_script_tag(path=BOT); J(pg, "1"); pg.click('[data-act=start]'); pg.wait_for_timeout(400)
    J(pg, SETUP.replace('window.__ai', 'window.__ai'))
    pg.evaluate(SETUP)
    J(pg, "__bot.sim(30)")
    # make sure the lab is powered/open so the monster can roam
    J(pg, "(()=>{const w=__tls.world; w.circ.lab=1; w.circCur={...w.circ}; const g=w.grid; for (const id of ['d_ck_lab']) g.doors[g.doorIndex[id]].locked=false;})()")

    print('\n=== A: idle -> patrol -> idle, no teleporting (player far away)')
    J(pg, "__ai.setup(48.5, 25, 8, 63)")
    r = J(pg, "__ai.run(30*70)"); print('  ', json.dumps(r)[:600])
    names = {t[1] for t in r['tl']}
    ok('Patrol' in names and 'Idle' in names, f'cycled Idle/Patrol: {sorted(names)}')
    ok(r['maxStepPerTick'] < 0.25, f'continuous movement (max step/tick {r["maxStepPerTick"]} m)')
    ok(r['mx'] != 48.5 or r['mz'] != 25, 'monster actually moved')

    print('\n=== B: hears a footstep-level noise -> Investigate -> Search -> Return/Patrol')
    J(pg, "__ai.setup(48.5, 22, 8, 63)")
    J(pg, "__bot.sim(10)")
    J(pg, "(()=>{__tls.game.monster.state=0; __tls.game.noise(48.5, 30, 13, 'noise')})()")
    r = J(pg, "__ai.run(30*60)"); print('  ', json.dumps(r)[:700])
    seq = [t[1] for t in r['tl']]
    ok('Investigate' in seq, f'noise -> Investigate (timeline {seq[:8]})')
    ok('Search' in seq, 'arrives and Searches')
    ok(seq.index('Search') > seq.index('Investigate') if 'Search' in seq and 'Investigate' in seq else False, 'Search follows Investigate')
    ok('Return' in seq or 'Patrol' in seq, 'gives up and returns to patrol')

    print('\n=== C: far noise is ignored (outside hearing radius), crouch whispers')
    J(pg, "__ai.setup(48.5, 22, 8, 63)"); J(pg, "__bot.sim(5)")
    J(pg, "__tls.game.noise(48.5, 33, 5.2, 'step')")  # 11 m away, walking noise radius 5.2
    r = J(pg, "__ai.run(60)"); ok('Investigate' not in [t[1] for t in r['tl']], f'walking noise 11 m away not heard: {r["tl"]}')

    print('\n=== D: vision: lit + flashlight in LOS -> Chase; crouched + dark -> unseen at range')
    # lab corridor lc1 runs along x=48.5 z 19..37: monster at z=21 facing south (+z), player 9 m away in the corridor
    J(pg, "__ai.setup(48.5, 21, 48.5, 30, { myaw: Math.PI, pyaw: 0, fl: true })")
    J(pg, "(()=>{const P=__tls.game.player; P.yaw=0; P.pitch=0})()")   # facing -z, toward the monster
    r = J(pg, "__ai.run(30*6, { each: () => { const P=__tls.game.player; P.yaw=0; P.fl.battery=100; }, until: () => __tls.game.monster.state===4 })"); print('  ', json.dumps(r)[:500])
    ok('Chase' in [t[1] for t in r['tl']], f'flashlight at 9 m in the monster\'s view triggers chase: {[t for t in r["tl"]]}')
    J(pg, "__ai.setup(48.5, 21, 48.5, 30, { myaw: Math.PI, pyaw: 0, fl: false, crouch: true })")
    J(pg, "(()=>{const w=__tls.world; for (const l of w.lights) l.mult=0.0;})()")  # lights out
    J(pg, "(()=>{const M=__tls.game.monster; M._idleFor=1e9; M.timer=0;})()")        # hold the monster still (otherwise it may legitimately patrol INTO view)
    r = J(pg, "__ai.run(30*5, { each: () => { const P=__tls.game.player; P.wantCrouch=true; P.yaw=0; } })"); print('  ', json.dumps(r)[:500])
    ok('Chase' not in [t[1] for t in r['tl']], f'crouched in the dark, 9 m away: not noticed ({[t[1] for t in r["tl"]]})')
    J(pg, "(()=>{const w=__tls.world; for (const l of w.lights) l.mult=1;})()")

    print('\n=== E: sprinting player is heard and chased; monster speed vs player speed')
    J(pg, "__ai.setup(48.5, 21, 48.5, 33, { myaw: Math.PI, pyaw: 0 })")
    r = J(pg, "__ai.run(30*5, { each: () => { const g=__tls.game, P=g.player, I=g.input; P.yaw=0; I.mx=0; I.my=1; I.held.add('sprint'); } })"); J(pg, "(()=>{const I=__tls.game.input; I.my=0; I.held.delete('sprint')})()")
    print('  ', json.dumps(r)[:500]); ok('Chase' in [t[1] for t in r['tl']] or r['end'] in ('Attack', 'Chase'), 'sprinting near it provokes a chase/attack')

    print('\n=== F: attack -> player hurt -> death sequence -> game over -> retry from checkpoint')
    J(pg, "__ai.setup(48.5, 25, 48.5, 25.9, { myaw: 0, pyaw: Math.PI })")
    J(pg, "(()=>{const M=__tls.game.monster; M.awareness=1.3})()")
    r = J(pg, "__ai.run(30*6, { until: () => __tls.game.mode !== 'play' })"); print('  ', json.dumps(r)[:500])
    ok(J(pg, "__tls.game.mode") in ('dying', 'dead'), f'player died: mode={J(pg, "__tls.game.mode")}')
    J(pg, "__bot.sim(30*5)")
    ok(J(pg, "__tls.game.mode") == 'dead', 'dying sequence ends in dead state')
    ok(J(pg, "!document.getElementById('gameover').classList.contains('hidden')"), 'Game Over screen visible')
    shot(pg, 'ai_gameover')
    pg.click('#gameover [data-act=retry]'); pg.wait_for_timeout(300); J(pg, "__bot.sim(10)")
    st = J(pg, "(()=>{const g=__tls.game,P=g.player;return {mode:g.mode,hp:P.health,alive:P.alive,x:P.x,z:P.z,mon:g.monster.active,deaths:g.state.deaths,cp:g.state.checkpoint}})()")
    print('  after retry:', st); ok(st['mode'] == 'play' and st['alive'] and st['hp'] >= 60 and st['deaths'] >= 1, 'retry restores the player at the last checkpoint with deaths counted')
    print('\nlogs:'); flush(logs, 10)
print('\nFAILS:', len(fails)); [print(' -', f) for f in fails]
