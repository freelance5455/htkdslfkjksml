"""Audio sanity: every procedural sound must produce signal (not silent, not clipping); continuous layers respond to game state."""
import json
from lib import *
BOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bot.js')
with session('preserve=1&q=low') as (pg, logs):
    pg.add_script_tag(path=BOT); pg.click('[data-act=start]'); pg.wait_for_timeout(500)
    J = pg.evaluate
    print('audio ctx:', J("(()=>{const E=__tls.E; return {ready:E.ready, state:E.ctx&&E.ctx.state, sr:E.ctx&&E.ctx.sampleRate, t0:E.ctx&&E.ctx.currentTime}})()"))
    pg.wait_for_timeout(400); print('clock advancing:', J("__tls.E.ctx.currentTime"))
    J("""(()=>{
      const E=__tls.E, S=__tls.game.sfx; window.__an = E.ctx.createAnalyser(); __an.fftSize=2048; (E.lim||E.comp).connect(__an); window.__buf=new Float32Array(2048);
      window.__measure = async (fn, ms=1300) => { let peak=0, ss=0, n=0; const t0=performance.now(); fn(); while (performance.now()-t0 < ms) { __an.getFloatTimeDomainData(__buf); for (let i=0;i<__buf.length;i++){ const v=__buf[i]; if (Math.abs(v)>peak) peak=Math.abs(v); ss+=v*v; n++; } await new Promise(r=>setTimeout(r,25)); } return {peak:+peak.toFixed(3), rms:+Math.sqrt(ss/n).toFixed(4)}; };
      // keep the continuous layers quiet during one-shot measurements
      __tls.game.scape.update(0.016,{outdoor:false,power:0,threat:0,chase:0,alarm:false,genOn:false,radio:{on:false,stat:1,car:0,shift:0},sfx:S});
    })()""")
    P = "__tls.game.player.x"
    tests = [
     ("step floor", "S.step('floor',1,false)"), ("step tile", "S.step('tile',1,false)"), ("step metal", "S.step('metal',1,false)"), ("step dirt", "S.step('dirt',1,false)"), ("step sprint", "S.step('floor',1.3,false)"), ("step crouch", "S.step('floor',1,true)"),
     ("breath out", "S.breath('out',1)"), ("breath gasp", "S.breath('gasp',1.4)"), ("heartbeat", "S.heart(1)"), ("hurt", "S.hurt()"), ("heal", "S.heal()"), ("pickup", "S.pickup('battery')"), ("pickup note", "S.pickup('note')"),
     ("flash on", "S.flash(true)"), ("flash dead", "S.flashDead()"), ("reload", "S.reload()"), ("ui tap", "S.ui('tap')"), ("keypad key", "S.key(1)"), ("keypad ok", "S.keyOk()"), ("keypad bad", "S.keyBad()"),
     ("switch", "S.switchClick(__tls.game.player.x+1,__tls.game.player.z)"), ("spark", "S.spark(__tls.game.player.x+2,__tls.game.player.z)"), ("surge", "S.surge()"), ("generator start", "S.generator(70,21.5)"), ("stamp", "S.stamp(__tls.game.player.x+1,__tls.game.player.z,1)"),
     ("door open", "S.door(__tls.game.player.x+2,__tls.game.player.z,'open','metal')"), ("door slam", "S.door(__tls.game.player.x+2,__tls.game.player.z,'slam','blast')"), ("door locked", "S.door(__tls.game.player.x+2,__tls.game.player.z,'locked','metal')"), ("hide door", "S.hideDoor(__tls.game.player.x+1,__tls.game.player.z,true)"),
     ("wheel", "S.wheel(__tls.game.player.x+1,__tls.game.player.z)"), ("monster step", "S.mstep(__tls.game.player.x+4,__tls.game.player.z,false)"), ("monster run step", "S.mstep(__tls.game.player.x+4,__tls.game.player.z,true)"),
     ("monster breath", "S.mvocal(__tls.game.player.x+4,__tls.game.player.z,'breath')"), ("monster growl", "S.mvocal(__tls.game.player.x+4,__tls.game.player.z,'growl')"), ("monster roar", "S.mvocal(__tls.game.player.x+4,__tls.game.player.z,'roar')"), ("monster sniff", "S.mvocal(__tls.game.player.x+4,__tls.game.player.z,'sniff')"), ("monster click", "S.mvocal(__tls.game.player.x+4,__tls.game.player.z,'click')"), ("monster screech", "S.mvocal(__tls.game.player.x+4,__tls.game.player.z,'screech')"),
     ("jumpscare", "S.jumpscare()"), ("radio voice", "S.voice('Please help me get out of here.',{radio:true,pitch:215,speed:0.8,seed:3})"), ("your voice (mimic)", "S.voice('Hello? Is anyone there?',{pitch:118,mimic:true,x:__tls.game.player.x+6,z:__tls.game.player.z,vol:1.2})"),
     ("whisper", "S.whisper(__tls.game.player.x+3,__tls.game.player.z)"), ("drip", "S.drip(__tls.game.player.x+3,__tls.game.player.z)"), ("alert", "S.alert()"), ("stinger", "S.stinger(1)"), ("chime", "S.chime(1)"),
    ]
    bad = []
    print(f"{'sound':20} {'peak':>7} {'rms':>8}")
    for name, code in tests:
        r = J(f"(async()=>{{const S=__tls.game.sfx; return await __measure(()=>{{ {code} }}, 1500)}})()")
        flag = '  SILENT' if r['peak'] < 0.002 else '  CLIPS' if r['peak'] > 0.995 else ''
        print(f"{name:20} {r['peak']:>7} {r['rms']:>8}{flag}")
        if flag: bad.append((name, flag.strip()))
    print('\n-- continuous layers (rms of 2 s of mixed output)')
    scen = [("silence/menu-ish (power off)", "{outdoor:false,power:0,threat:0,chase:0,alarm:false,genOn:false,radio:{on:false,stat:1,car:0,shift:0}}"),
            ("outdoors wind", "{outdoor:true,power:0,threat:0,chase:0,alarm:false,genOn:false,radio:{on:false,stat:1,car:0,shift:0}}"),
            ("powered rooms hum", "{outdoor:false,power:1,threat:0,chase:0,alarm:false,genOn:false,radio:{on:false,stat:1,car:0,shift:0}}"),
            ("tension (monster near)", "{outdoor:false,power:1,threat:0.7,chase:0,alarm:false,genOn:false,radio:{on:false,stat:1,car:0,shift:0}}"),
            ("CHASE score", "{outdoor:false,power:1,threat:1,chase:1,alarm:false,genOn:false,radio:{on:false,stat:1,car:0,shift:0}}"),
            ("generator running", "{outdoor:false,power:1,threat:0,chase:0,alarm:false,genOn:true,genX:__tls.game.player.x+3,genZ:__tls.game.player.z,radio:{on:false,stat:1,car:0,shift:0}}"),
            ("alarm (array silenced)", "{outdoor:false,power:1,threat:0,chase:0,alarm:true,genOn:false,radio:{on:false,stat:1,car:0,shift:0}}"),
            ("radio static", "{outdoor:false,power:1,threat:0,chase:0,alarm:false,genOn:false,radio:{on:true,stat:1,car:0,shift:0}}")]
    for name, st in scen:
        r = J(f"""(async()=>{{const g=__tls.game,S=g.sfx; const st={st}; st.sfx=S; let peak=0,ss=0,n=0; const t0=performance.now();
           while (performance.now()-t0<2200) {{ g.scape.update(0.05, st); if (performance.now()-t0>900) {{ __an.getFloatTimeDomainData(__buf); for (let i=0;i<__buf.length;i++){{const v=__buf[i]; if(Math.abs(v)>peak)peak=Math.abs(v); ss+=v*v; n++;}} }} await new Promise(r=>setTimeout(r,50)); }}
           return {{peak:+peak.toFixed(3), rms:+Math.sqrt(ss/Math.max(1,n)).toFixed(4)}} }})()""")
        print(f"{name:30} peak {r['peak']:>6} rms {r['rms']:>8}")
    print('\nsilent/clipping sounds:', bad or 'none')
    flush(logs, 10)
