from lib import *
BOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bot.js')
with session('preserve=1&q=low') as (pg, logs):
    pg.add_script_tag(path=BOT)
    pg.click('[data-act=start]'); pg.wait_for_timeout(300)
    print(pg.evaluate("""(() => {
      const g = __tls.game, P = g.player, C = __tls.world.content; __bot.god(true);
      P.setPos(68.78, 13.92, 0); const out = [];
      for (const id of ['breaker1','breaker2','breaker3']) {
        const o = C.interacts.find(a => a.id === id);
        __bot.face(o.x, o.y, o.z); g.step(1/30); g.step(1/30);
        const t = g.target;
        const ey = P.eyeY, cp = Math.cos(P.pitch), dir = [Math.sin(P.yaw)*cp, Math.sin(P.pitch), -Math.cos(P.yaw)*cp];
        const res = [];
        for (const b of C.interacts.filter(a => a.kind === 'breaker')) { const dx=b.x-P.x, dy=b.y-ey, dz=b.z-P.z, d=Math.hypot(dx,dy,dz); res.push(b.id+': d='+d.toFixed(2)+' cs='+((dx*dir[0]+dy*dir[1]+dz*dir[2])/d).toFixed(3)+' los='+__tls.world.grid.los(P.x,P.z,b.x,b.z,true)); }
        out.push({ facing: id, target: t ? t.obj.id : null, res });
      }
      return JSON.stringify(out, null, 1);
    })()"""))
    flush(logs)
