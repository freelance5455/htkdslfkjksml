"""PWA check over http://localhost: manifest valid, icons present, service worker activates, game reloads and boots OFFLINE."""
import json, os, subprocess, sys, time, urllib.request
from playwright.sync_api import sync_playwright
from lib import ROOT, ARGS
fails = []
def ok(c, m):
    print(('  PASS ' if c else '  FAIL ') + m)
    if not c: fails.append(m)
PORT = 8765
srv = subprocess.Popen([sys.executable, '-m', 'http.server', str(PORT), '--bind', '127.0.0.1', '--directory', os.path.join(ROOT, 'dist')], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1.0)
try:
    base = f'http://127.0.0.1:{PORT}/'
    man = json.load(urllib.request.urlopen(base + 'manifest.webmanifest'))
    ok(man['display'] == 'fullscreen' and man['orientation'] == 'landscape' and man['start_url'] and man['name'], f"manifest: {man['name']} / {man['display']} / {man['orientation']}")
    sizes = {i['sizes'] for i in man['icons']}; ok({'192x192', '512x512'} <= sizes and any(i['purpose'] == 'maskable' for i in man['icons']), f'icons declared: {sorted(sizes)}')
    from PIL import Image
    import io
    for i in man['icons']:
        im = Image.open(io.BytesIO(urllib.request.urlopen(base + i['src']).read())); ok(f"{im.size[0]}x{im.size[1]}" == i['sizes'], f"icon {i['src']} is really {im.size}")
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path='/usr/bin/google-chrome', headless=True, args=ARGS)
        ctx = b.new_context(viewport={'width': 960, 'height': 540}); pg = ctx.new_page(); logs = []
        pg.on('console', lambda m: logs.append(f'[{m.type}] {m.text}')); pg.on('pageerror', lambda e: logs.append(f'[pageerror] {e}'))
        pg.goto(base + '?preserve=1&q=low'); pg.wait_for_function('window.__ready === true', timeout=120000)
        reg = pg.evaluate("navigator.serviceWorker.ready.then(r => new Promise(res => { const w = r.active; const done = () => res({scope: r.scope, state: w.state}); if (w.state === 'activated') done(); else w.addEventListener('statechange', () => w.state === 'activated' && done()); }))"); print('  sw:', reg)
        ok(reg['state'] == 'activated', 'service worker activated')
        pg.wait_for_timeout(1500)
        keys = pg.evaluate("caches.keys()"); ok(any(k.startswith('tls-') for k in keys), f'cache created: {keys}')
        cached = pg.evaluate("caches.open(%s).then(c => c.keys()).then(ks => ks.map(k => new URL(k.url).pathname))" % json.dumps(keys[0])); print('  cached:', cached)
        ok('__VERSION__' not in keys[0] and len(keys[0]) > 8, f'cache name carries a real build hash: {keys[0]}')
        ok(all(x in cached for x in ['/', '/index.html', '/manifest.webmanifest', '/icon-192.png']), 'shell + manifest + icons precached')
        ok(pg.evaluate("!!document.querySelector('link[rel=manifest]')"), 'manifest <link> attached over http')
        # now go offline: the server is the only network, stop it by blocking via the context
        ctx.set_offline(True); pg.reload(); pg.wait_for_function('window.__ready === true', timeout=120000)
        ok(pg.evaluate("document.title") == 'THE LAST SIGNAL' and pg.evaluate("!!window.__tls"), 'game reloads and boots completely OFFLINE')
        pg.click('[data-act=start]'); pg.wait_for_timeout(600); ok(pg.evaluate("__tls.game.mode") == 'play', 'new game starts offline')
        errs = [l for l in logs if l.startswith('[error]') or l.startswith('[pageerror]')]; ok(not errs, 'no console errors: ' + '; '.join(errs)[:200])
        b.close()
finally:
    srv.terminate()
print('\nFAILS:', len(fails)); [print(' -', f) for f in fails]
