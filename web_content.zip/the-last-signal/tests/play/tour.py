"""Visual tour: one screenshot per level area (flashlight on, power on except the emergency circuit), tiled into contact sheets."""
import json, sys
from lib import *
from PIL import Image, ImageDraw
BOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bot.js')
Q = sys.argv[1] if len(sys.argv) > 1 else 'high'
with session(f'preserve=1&q={Q}', size=(800, 450), dpr=1) as (pg, logs):
    pg.add_script_tag(path=BOT); pg.click('[data-act=start]'); pg.wait_for_timeout(400)
    J = pg.evaluate
    J("__bot.god(true); const w=__tls.world; for (const k in w.circ) w.circ[k]= k==='emerg'?0:1; w.circCur={...w.circ}; for (const d of w.grid.doors) d.locked=false; __tls.game.monster.active=false; __tls.game.story.mimicT=1e9; __tls.game.story.whisperT=1e9; document.getElementById('hud').style.display='none'; document.getElementById('titlecard').style.display='none'; 1")
    areas = J("__tls.world.grid.areas.map((a,i)=>({i, id:a.id, x0:a.x0, z0:a.z0, x1:a.x1, z1:a.z1}))")
    files = []
    for a in areas:
        w, h = a['x1'] - a['x0'], a['z1'] - a['z0']
        if w >= h:   # long along x: stand near the west end looking east
            x, z, yaw = a['x0'] + min(2.0, w * 0.2), a['z0'] + h / 2, 1.5708
        else:
            x, z, yaw = a['x0'] + w / 2, a['z1'] - min(2.0, h * 0.2), 0.0
        if a['id'] == 'courtyard': x, z, yaw = 9, 63, 1.5708
        J(f"(()=>{{const g=__tls.game,P=g.player; P.setPos({x},{z},{yaw}); P.pitch=-0.04; P.fl.on=true; P.fl.battery=100; __bot.sim(20); g.fade=0; g.fadeTo=0;}})()")
        pg.wait_for_timeout(250); J("__tls.game.frame(1/30); __tls.game.frame(1/30)")
        f = os.path.join(SHOTS, f"tour_{Q}_{a['i']:02d}_{a['id']}.png"); pg.screenshot(path=f); files.append((a['id'], f))
    print('areas', len(files))
    # contact sheets of 4
    for s in range(0, len(files), 4):
        grp = files[s:s+4]; W, H = 800, 450
        sheet = Image.new('RGB', (W * 2, H * 2), (0, 0, 0))
        for k, (name, f) in enumerate(grp):
            im = Image.open(f).convert('RGB'); sheet.paste(im, ((k % 2) * W, (k // 2) * H)); d = ImageDraw.Draw(sheet); d.text(((k % 2) * W + 8, (k // 2) * H + 6), name, fill=(255, 220, 80))
        out = os.path.join(SHOTS, f"sheet_{Q}_{s // 4}.png"); sheet.save(out); print(out)
    flush(logs, 5)
