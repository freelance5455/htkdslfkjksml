"""Relative fragment cost of the quality tiers (SwiftShader executes the GPU work on the CPU, so gl.finish() timing is a proxy)."""
from lib import *
BOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bot.js')
with session('preserve=1&q=low', size=(844, 390), mobile=True, dpr=2) as (pg, logs):
    pg.add_script_tag(path=BOT); pg.click('[data-act=start]', timeout=60000) if False else pg.tap('[data-act=start]'); pg.wait_for_timeout(300)
    J = pg.evaluate
    J("__bot.god(true); const w=__tls.world; for (const k in w.circ) w.circ[k]=1; w.circCur={...w.circ}; for (const d of w.grid.doors) d.locked=false; 1")
    print('viewport', J("[innerWidth, innerHeight, devicePixelRatio]"))
    for spot in [('lab corridor', 48.5, 33, 3.14), ('chamber', 100, 24, 1.57), ('storage', 76, 66, 3.14)]:
        name, x, z, yaw = spot
        for q in ['low', 'medium', 'high']:
            J(f"(()=>{{__tls.settings.quality='{q}'; __tls.R.setQuality('{q}'); __tls.R.resize(innerWidth, innerHeight, devicePixelRatio); const g=__tls.game,P=g.player; P.setPos({x},{z},{yaw}); P.fl.on=true; P.fl.battery=100; g.monster.active=false;}})()")
            r = J("""(()=>{const g=__tls.game,R=__tls.R,gl=R.gl; for (let i=0;i<3;i++) g.frame(1/30); const px=new Uint8Array(4); const sync=()=>{gl.bindFramebuffer(gl.FRAMEBUFFER,null); gl.readPixels(0,0,1,1,gl.RGBA,gl.UNSIGNED_BYTE,px)}; sync(); const n=8, t0=performance.now(); for (let i=0;i<n;i++){ g.frame(1/30); sync(); } return {ms:+((performance.now()-t0)/n).toFixed(1), w:R.sw, h:R.sh, mp:+(R.sw*R.sh/1e6).toFixed(2)}})()""")
            print(f"{name:14} {q:7} {r['w']}x{r['h']} ({r['mp']} MP)  {r['ms']} ms/frame (software raster)")
    flush(logs, 5)
