"""Render budget probe: draw calls / triangles / JS ms per frame at each quality tier in representative rooms.
(SwiftShader is a CPU rasteriser, so GPU time here is meaningless; draws, tris and CPU-side JS cost are what we can measure.)"""
import json
from lib import *
BOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bot.js')
SPOTS = [  # name, x, z, yaw(rad)
  ('courtyard', 9, 63, 1.57), ('lobby', 36, 62, 1.57), ('checkpoint', 48, 46, 0), ('lab corridor', 48.5, 33, 3.14), ('research', 36, 24, 3.14),
  ('generator hall', 66, 20, 1.57), ('storage', 76, 66, 3.14), ('link corridor', 94, 45, 0), ('chamber/array', 100, 24, 1.57), ('hatch', 120, 33, 0),
]
with session('preserve=1&q=low') as (pg, logs):
    pg.add_script_tag(path=BOT); pg.click('[data-act=start]'); pg.wait_for_timeout(300)
    J = pg.evaluate
    J("__bot.god(true); const w=__tls.world; for (const k in w.circ) w.circ[k]=1; w.circCur={...w.circ}; for (const d of w.grid.doors) d.locked=false; 1")
    J("__tls.settings.quality='low'; 1")
    print(f"{'spot':16} {'q':7} {'draws':>6} {'tris(k)':>8} {'shadow':>6} {'step ms':>8} {'frame ms':>9}")
    rows = []
    for q in ['low', 'medium', 'high']:
        J(f"(()=>{{__tls.settings.quality='{q}'; __tls.R.setQuality('{q}'); __tls.R.resize(innerWidth, innerHeight, 1);}})()")
        for name, x, z, yaw in SPOTS:
            J(f"(()=>{{const g=__tls.game,P=g.player; P.setPos({x},{z},{yaw}); P.fl.on=true; P.fl.battery=100; g.monster.active=false;}})()")
            r = J("""(()=>{const g=__tls.game,R=__tls.R; let step=0, frame=0, n=14;
              for (let i=0;i<4;i++) g.frame(1/30);
              for (let i=0;i<n;i++){ const t0=performance.now(); g.step(1/30); const t1=performance.now(); g.frame(1/30); const t2=performance.now(); step+=t1-t0; frame+=t2-t1; }
              const s=R.stats.last; return {draws:s.draws, tris:Math.round(s.tris/1000), shadow:s.shadowDraws, step:+(step/n).toFixed(2), frame:+(frame/n).toFixed(1)}})()""")
            print(f"{name:16} {q:7} {r['draws']:>6} {r['tris']:>8} {r['shadow']:>6} {r['step']:>8} {r['frame']:>9}"); rows.append((name, q, r))
    for q in ['low', 'medium', 'high']:
        rr = [r for n, qq, r in rows if qq == q]
        print(f"MAX {q:7} draws {max(r['draws'] for r in rr)}  tris {max(r['tris'] for r in rr)}k  step {max(r['step'] for r in rr)} ms")
    print('buffer size', J("[__tls.R.sw, __tls.R.sh]"), 'quality', J("__tls.R.qname"))
    flush(logs, 10)
