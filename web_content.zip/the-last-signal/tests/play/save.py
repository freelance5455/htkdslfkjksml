"""Checkpoint saves, Continue after a page reload, retry-after-death restoring picked-up items, corrupt-save handling."""
import json
from lib import *
BOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bot.js')
fails = []
def ok(cond, msg):
    print(('  PASS ' if cond else '  FAIL ') + msg)
    if not cond: fails.append(msg)
def J(pg, e): return pg.evaluate(e)
with session('preserve=1&q=low') as (pg, logs):
    pg.add_script_tag(path=BOT)
    ok(J(pg, "document.getElementById('btn-continue').classList.contains('off')"), 'fresh install: Continue is disabled')
    pg.click('[data-act=start]'); pg.wait_for_timeout(400); J(pg, "__bot.god(true); __bot.sim(30)")
    # walk to the lobby (blast door slam = checkpoint 'lobby'), take the courtyard battery on the way
    print('  pick battery:', J(pg, "__bot.useOn('b_court')"))
    print('  goto:', J(pg, "__bot.goTo(44.5, 62.5)")); J(pg, "__bot.sim(150)")
    raw = J(pg, "localStorage.getItem('tls.save.v1')"); ok(bool(raw), 'save written to localStorage')
    sv = json.loads(raw); print('  save:', {k: sv[k] for k in ('checkpoint', 'objective', 'stage', 'playTime', 'items', 'pos')}); ok(sv['checkpoint'] == 'lobby' and sv['flags'].get('blast'), 'checkpoint "lobby" saved with blast flag')
    ok(sv['items']['battery'] == 2 and sv['taken'].get('b_court'), 'saved inventory + picked-up items')
    # progress after the checkpoint (not saved): take another battery + the medkit, then reload the page
    print('  after-cp pickups:', J(pg, "__bot.useOn('b_lobby')"))
    pg.reload(); pg.wait_for_function("window.__ready === true", timeout=120000); pg.wait_for_timeout(800)
    pg.add_script_tag(path=BOT)
    ok(not J(pg, "document.getElementById('btn-continue').classList.contains('off')"), 'after reload Continue is enabled'); print('  continue sub:', J(pg, "document.getElementById('cont-sub').textContent"))
    pg.click('[data-act=continue]'); pg.wait_for_timeout(500); J(pg, "__bot.god(true); __bot.sim(60)")
    st = J(pg, "(()=>{const g=__tls.game,P=g.player,S=g.state,gr=__tls.world.grid; return {mode:g.mode,x:+P.x.toFixed(1),z:+P.z.toFixed(1),items:S.items,obj:S.objective,blast:S.flag('blast'),taken:Object.keys(S.taken),door:{t:gr.doors[gr.doorIndex.d_blast].t,locked:gr.doors[gr.doorIndex.d_blast].locked}, lobbyBattery:__tls.world.content.pickups.find(p=>p.id==='b_lobby').taken, courtBattery:__tls.world.content.pickups.find(p=>p.id==='b_court').taken}})()")
    print('  restored:', st)
    ok(st['mode'] == 'play' and abs(st['x'] - 44.2) < 1.5 and abs(st['z'] - 62.5) < 1.5, 'player restored at the checkpoint position')
    ok(st['items']['battery'] == 2, 'inventory restored (checkpoint state, not the later pickup)'); ok(st['courtBattery'] and not st['lobbyBattery'], 'picked-up flags restored; the unsaved pickup is back in the world')
    ok(st['blast'] and st['door']['t'] == 0 and st['door']['locked'], 'sealed blast door restored'); ok(st['obj'] == 'lobby', 'objective restored')
    # die -> retry restores checkpoint and counts the death
    J(pg, "(()=>{const P=__tls.game.player; P.god=false; P.hurt(999,0,0)})()"); J(pg, "__bot.sim(30*5)")
    ok(J(pg, "__tls.game.mode") == 'dead', 'dead after lethal damage'); pg.click('#gameover [data-act=retry]'); pg.wait_for_timeout(400); J(pg, "__bot.sim(20)")
    ok(J(pg, "__tls.game.mode") == 'play' and J(pg, "__tls.game.state.deaths") == 1, 'retry puts you back in play with deaths=1')
    # to menu & new game confirm: starting a new game resets state
    J(pg, "__tls.game.pause()"); pg.click('#pause [data-act=to-menu]'); pg.wait_for_timeout(300)
    ok(J(pg, "__tls.game.mode") == 'menu' and J(pg, "!document.getElementById('menu').classList.contains('hidden')"), 'Main Menu from pause'); 
    # corrupt save -> Continue disabled, Start still works
    J(pg, "localStorage.setItem('tls.save.v1', '{not json')"); pg.reload(); pg.wait_for_function("window.__ready === true", timeout=120000); pg.wait_for_timeout(500)
    ok(J(pg, "document.getElementById('btn-continue').classList.contains('off')"), 'corrupt save: Continue disabled (no crash)')
    pg.click('[data-act=start]'); pg.wait_for_timeout(500); ok(J(pg, "__tls.game.mode") == 'play', 'New game still starts')
    flush(logs, 10)
print('FAILS:', len(fails)); [print(' -', f) for f in fails]
