// Test bot injected into the page: drives the REAL game (Game.step, Input, nav) deterministically.
(() => {
  const T = () => window.__tls;
  const bot = (window.__bot = {});
  const DT = 1 / 30;
  bot.sim = (n, dt = DT) => { const g = T().game; for (let i = 0; i < n; i++) g.step(dt); };
  bot.state = () => { const g = T().game, P = g.player, S = g.state, M = g.monster; return { mode: g.mode, x: +P.x.toFixed(2), z: +P.z.toFixed(2), hp: Math.round(P.health), stage: S.stage, obj: S.objective, flags: Object.keys(S.flags).filter((k) => S.flags[k]).join(','), keys: Object.keys(S.keys).filter((k) => S.keys[k]).join(','), items: JSON.stringify(S.items), notes: S.notes.length, mon: M.active ? `${M.stateName || M.state}@${M.x.toFixed(0)},${M.z.toFixed(0)}` : '-', modal: T().ui.modal }; };
  bot.face = (x, y, z) => { const P = T().game.player, dx = x - P.x, dz = z - P.z, hd = Math.hypot(dx, dz); P.yaw = Math.atan2(dx, -dz); P.pitch = Math.atan2(y - P.eyeY, hd); };
  bot.goTo = (x, z, o = {}) => {
    const g = T().game, P = g.player, I = g.input, nav = g.monster.nav, tol = o.tol ?? 0.45, max = o.max ?? 4000;
    let path = null, wi = 1, replan = 0, ck = 0, lx = P.x, lz = P.z, stuck = 0;
    for (let i = 0; i < max; i++) {
      if (g.mode !== 'play') { I.mx = I.my = 0; return { ok: false, why: 'mode ' + g.mode, at: [P.x, P.z] }; }
      if (T().ui.modal) { I.mx = I.my = 0; return { ok: false, why: 'modal ' + T().ui.modal }; }
      if (Math.hypot(x - P.x, z - P.z) < tol) { I.mx = I.my = 0; g.step(DT); return { ok: true, steps: i }; }
      if (!path || replan-- <= 0) { path = nav.path(P.x, P.z, x, z); wi = 1; replan = 40; if (!path) { I.mx = I.my = 0; return { ok: false, why: 'nopath', at: [+P.x.toFixed(1), +P.z.toFixed(1)], to: [x, z] }; } }
      while (wi < path.length - 1 && Math.hypot(path[wi][0] - P.x, path[wi][1] - P.z) < 0.45) wi++;
      const w = path[Math.min(wi, path.length - 1)];
      P.yaw = Math.atan2(w[0] - P.x, -(w[1] - P.z)); P.pitch = 0;
      I.mx = 0; I.my = 1; I.keys.clear(); if (o.sprint) I.held.add('sprint'); else I.held.delete('sprint');
      g.step(DT);
      if (++ck >= 30) { ck = 0; if (Math.hypot(P.x - lx, P.z - lz) < 0.25) { if (++stuck >= 3) { I.mx = I.my = 0; return { ok: false, why: 'stuck', at: [+P.x.toFixed(2), +P.z.toFixed(2)], to: [x, z], wp: w }; } replan = 0; } else stuck = 0; lx = P.x; lz = P.z; }
    }
    I.mx = I.my = 0; I.held.delete('sprint'); return { ok: false, why: 'timeout', at: [+P.x.toFixed(1), +P.z.toFixed(1)] };
  };
  const find = (id) => { const C = T().world.content; return C.interacts.find((a) => a.id === id) || C.pickups.find((a) => a.id === id) || C.hides.find((a) => a.id === id); };
  // choose a standing point 0.9..1.5 m from the object with clear line of sight, nearest to the player
  bot.standPoint = (o) => {
    const g = T().game, P = g.player, nav = g.monster.nav, gr = T().world.grid; let best = null, bd = 1e9;
    const ox = o.front ? o.front[0] : o.x, oz = o.front ? o.front[1] : o.z;
    for (let r = 0.75; r <= 1.25; r += 0.25) for (let a = 0; a < 24; a++) {
      const cx = ox + Math.cos(a * Math.PI / 12) * r, cz = oz + Math.sin(a * Math.PI / 12) * r;
      if (!nav.walkable(Math.floor(cx), Math.floor(cz), true)) continue;
      const rr = gr.resolve(cx, cz, 0.34); if (Math.hypot(rr.x - cx, rr.z - cz) > 0.01) continue;   // keep clear of walls
      if (!gr.los(cx, cz, o.x, o.z, true)) continue;
      const d = Math.hypot(cx - P.x, cz - P.z); if (d < bd) { bd = d; best = [cx, cz]; }
    }
    return best;
  };
  // walk up to a door (within its trigger distance) so keycards / proximity opening can act; returns the door state
  bot.touchDoor = (id, side = 1.3) => {
    const w = T().world, g = w.grid, d = g.doors[g.doorIndex[id]], P = T().game.player; const sp = bot.standPoint({ x: d.cx, z: d.cz });
    if (!sp) return { ok: false, why: 'no stand point for door ' + id };
    const r = bot.goTo(sp[0], sp[1], { tol: 0.2 }); bot.sim(40);
    return { ...r, door: { t: +d.t.toFixed(2), locked: d.locked } };
  };
  bot.pulse = (name, steps = 3) => { const I = T().game.input; I.held.add(name); bot.sim(steps); I.held.delete(name); bot.sim(1); };
  bot.useOn = (id, o = {}) => {
    const g = T().game, P = g.player, ob = find(id); if (!ob) return { ok: false, why: 'unknown ' + id };
    const sp = bot.standPoint(ob); if (!sp) return { ok: false, why: 'no stand point' };
    const r = bot.goTo(sp[0], sp[1], { tol: 0.14 }); if (!r.ok) return { ...r, step: 'goto ' + id };
    const y = ob.y !== undefined ? ob.y + (ob.type ? 0.08 : 0) : P.eyeY; bot.face(ob.x, y, ob.z); bot.sim(2);
    const tg = g.target; if (!tg || tg.obj.id !== id) return { ok: false, why: 'target is ' + (tg ? tg.obj.id : 'none') + ' not ' + id, at: [+P.x.toFixed(2), +P.z.toFixed(2)] };
    if (o.hold) { const I = g.input; I.held.add('use'); bot.sim(Math.ceil(o.hold * 30)); I.held.delete('use'); bot.sim(2); return { ok: true, held: o.hold }; }
    bot.pulse('use'); return { ok: true };
  };
  bot.closeNote = () => { const ui = T().ui; if (ui.modal) ui.closeModal(); bot.sim(1); };
  bot.god = (on = true) => { T().game.player.god = on; };
})();
