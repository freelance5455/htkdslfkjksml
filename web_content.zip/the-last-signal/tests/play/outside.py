"""Single-area visual check: outside/courtyard views at High quality (used to verify the rubble tint)."""
import os, sys
from lib import *
BOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bot.js')
with session('preserve=1&q=high', size=(960, 540), dpr=1) as (pg, logs):
    pg.add_script_tag(path=BOT); pg.click('[data-act=start]'); pg.wait_for_timeout(400)
    J = pg.evaluate
    J("__bot.god(true); __tls.game.monster.active=false; __tls.game.story.mimicT=1e9; __tls.game.story.whisperT=1e9; document.getElementById('hud').style.display='none'; document.getElementById('titlecard').style.display='none'; 1")
    print(J("__tls.world.grid.areas.filter(a=>/out|court|road|gate/i.test(a.id)).map(a=>a.id+' '+[a.x0,a.z0,a.x1,a.z1].join(','))"))
    views = {'outside_a': None}
    for i, (x, z, yaw) in enumerate([(110, 43.5, 1.5708), (112, 41, 0.6), (112, 46, 2.4), (121, 44, -1.57)]):
        J(f"(()=>{{const g=__tls.game,P=g.player; P.setPos({x},{z},{yaw}); P.pitch=-0.03; P.fl.on=true; P.fl.battery=100; __bot.sim(20); g.fade=0; g.fadeTo=0;}})()")
        pg.wait_for_timeout(250); J("__tls.game.frame(1/30); __tls.game.frame(1/30)")
        print(shot(pg, f'outside_{i}'))
    flush(logs, 5)
