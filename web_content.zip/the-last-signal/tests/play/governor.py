"""Auto-quality governor: slow frames step the tier down (high -> medium -> low), fast frames never do, an explicit choice is respected."""
import os
from lib import *
BOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bot.js')
fails = []
def ok(c, m):
    print(('  PASS ' if c else '  FAIL ') + m)
    if not c: fails.append(m)
with session('preserve=1&q=high') as (pg, logs):
    J = pg.evaluate
    pg.add_script_tag(path=BOT); pg.click('[data-act=start]'); pg.wait_for_timeout(500)
    print('settings.quality =', J("__tls.game.settings.quality"), ' tier =', J("__tls.R.qname"), ' canvas =', J("[__tls.R.canvas.width, __tls.R.canvas.height]"))
    ok(J("__tls.R.qname") == 'high', 'test starts on the high tier')
    # 60 fps-ish frames for 12 s of game time: no downgrade
    J("(()=>{const g=__tls.game; g.perf.sum=0; g.perf.n=0; g.perf.slow=0; for(let i=0;i<720;i++) g.perfTick(1/60)})()")
    ok(J("__tls.R.qname") == 'high', 'smooth 60 fps never lowers quality')
    # 25 fps (40 ms) frames: first drop after ~4 s, second after ~4 more
    seq = J("""(()=>{const g=__tls.game, out=[]; for(let i=0;i<20*25;i++){ g.perfTick(0.04); const q=__tls.R.qname; if(out[out.length-1]!==q) out.push(q); } return out})()""")
    print('  tier sequence under 25 fps:', seq)
    ok(seq == ['high', 'medium', 'low'], 'slow frames step high -> medium -> low and stop at low')
    c0 = J("[__tls.R.canvas.width, __tls.R.canvas.height]")
    J("__tls.game.frame(1/30); __tls.game.frame(1/30)"); pg.wait_for_timeout(200)
    ok(J("__tls.R.gl.getError()") == 0, 'renderer healthy after the automatic downgrade (no GL error)')
    print('  canvas after downgrade:', c0, ' auto-downgraded to:', J("__tls.game.autoDowngraded"))
    # explicit quality setting must never be overridden
    J("__tls.game.settings.quality='high'; __tls.R.setQuality('high'); __tls.game.perf.slow=0; for(let i=0;i<20*25;i++) __tls.game.perfTick(0.04)")
    ok(J("__tls.R.qname") == 'high', 'an explicit High setting is respected even when slow')
    ok(not_any := not [l for l in logs if 'error' in l.lower() or 'pageerror' in l], 'no console errors')
    flush(logs, 10)
print('\nFAILS:', len(fails)); [print(' -', f) for f in fails]
