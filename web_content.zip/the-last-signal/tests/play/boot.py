from lib import *
with session('preserve=1&q=medium') as (pg, logs):
    pg.wait_for_timeout(1500)
    print('title:', pg.title())
    print('boot hidden:', ev(pg, "document.getElementById('boot').classList.contains('hidden')"))
    print('menu visible:', ev(pg, "!document.getElementById('menu').classList.contains('hidden')"))
    print('mode:', ev(pg, "window.__tls && window.__tls.game.mode"))
    print(shot(pg, 'menu'))
    flush(logs)
