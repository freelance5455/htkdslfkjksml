"""Headless-Chrome helper: python3 shot.py <entry.js> <out.png> [query] [WxH]
Bundles a test entry with esbuild into a page, loads it with SwiftShader WebGL2, prints console output, saves a screenshot."""
import subprocess, sys, os, json, tempfile
from playwright.sync_api import sync_playwright

root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
entry, out = sys.argv[1], sys.argv[2]
query = sys.argv[3] if len(sys.argv) > 3 else ''
size = sys.argv[4] if len(sys.argv) > 4 else '960x540'
w, h = [int(x) for x in size.split('x')]
tmp = tempfile.mkdtemp()
js = os.path.join(tmp, 'bundle.js')
subprocess.check_call(['node', os.path.join(root, 'tests/smoke/bundle.mjs'), entry, js])
html = os.path.join(tmp, 'page.html')
open(html, 'w').write('<!doctype html><html><head><meta charset="utf-8"><style>html,body{margin:0;background:#000;overflow:hidden}canvas{width:100vw;height:100vh;display:block}</style></head><body><canvas id="gl"></canvas><script src="bundle.js"></script></body></html>')
with sync_playwright() as p:
    b = p.chromium.launch(executable_path='/usr/bin/google-chrome', headless=True,
        args=['--no-sandbox', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--autoplay-policy=no-user-gesture-required'])
    pg = b.new_page(viewport={'width': w, 'height': h})
    logs = []
    pg.on('console', lambda m: logs.append(f'[{m.type}] {m.text}'))
    pg.on('pageerror', lambda e: logs.append(f'[pageerror] {e}'))
    pg.goto('file://' + html + ('?' + query if query else ''))
    try:
        pg.wait_for_function('window.__done === true', timeout=90000)
    except Exception as e:
        logs.append('[timeout] ' + str(e)[:200])
    pg.wait_for_timeout(300)
    pg.screenshot(path=out)
    for l in logs[:40]: print(l[:1500])
    b.close()
print('saved', out)
