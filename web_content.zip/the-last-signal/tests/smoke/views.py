"""python3 views.py <entry.js> <out_prefix> '<json list of views>' [WxH] [query]
Renders each view {x,z,yaw,pitch,h,fl,exp} via window.__view and stitches a labelled contact sheet <out_prefix>_sheet.png"""
import subprocess, sys, os, json, tempfile
from playwright.sync_api import sync_playwright
from PIL import Image, ImageDraw

root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
entry, prefix, views = sys.argv[1], sys.argv[2], json.loads(sys.argv[3])
size = sys.argv[4] if len(sys.argv) > 4 else '800x450'
query = sys.argv[5] if len(sys.argv) > 5 else ''
w, h = [int(x) for x in size.split('x')]
tmp = tempfile.mkdtemp()
subprocess.check_call(['node', os.path.join(root, 'tests/smoke/bundle.mjs'), entry, os.path.join(tmp, 'bundle.js')])
open(os.path.join(tmp, 'page.html'), 'w').write('<!doctype html><html><head><meta charset="utf-8"><style>html,body{margin:0;background:#000;overflow:hidden}canvas{width:100vw;height:100vh;display:block}</style></head><body><canvas id="gl"></canvas><script src="bundle.js"></script></body></html>')
shots = []
with sync_playwright() as p:
    b = p.chromium.launch(executable_path='/usr/bin/google-chrome', headless=True,
        args=['--no-sandbox', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--autoplay-policy=no-user-gesture-required'])
    pg = b.new_page(viewport={'width': w, 'height': h})
    logs = []
    pg.on('console', lambda m: logs.append(f'[{m.type}] {m.text}'))
    pg.on('pageerror', lambda e: logs.append(f'[pageerror] {e}'))
    pg.goto('file://' + os.path.join(tmp, 'page.html') + ('?' + query if query else ''))
    pg.wait_for_function('window.__ready === true', timeout=120000)
    err = pg.evaluate('window.__error || null')
    if err:
        print('PAGE ERROR:', err[:2500]); b.close(); sys.exit(1)
    for i, v in enumerate(views):
        n = pg.evaluate('(v) => window.__view(v)', v)
        pg.wait_for_timeout(80)
        path = f'{prefix}_{i}.png'
        pg.screenshot(path=path)
        shots.append((path, v.get('name', str(i)), n))
    for l in logs[:30]: print(l[:1200])
    b.close()
cols = 2
rows = (len(shots) + cols - 1) // cols
sheet = Image.new('RGB', (cols * w, rows * h), (20, 20, 20))
for i, (path, name, n) in enumerate(shots):
    im = Image.open(path).convert('RGB')
    d = ImageDraw.Draw(im); d.rectangle((0, 0, 280, 16), fill=(0, 0, 0)); d.text((4, 2), f'{name}  (chunks drawn {n})', fill=(255, 220, 120))
    sheet.paste(im, ((i % cols) * w, (i // cols) * h))
sheet.save(prefix + '_sheet.png')
print('sheet', prefix + '_sheet.png', sheet.size)
