// Render smoke test: one lit room with every material type, flashlight, fog and post-processing.
import { Renderer, QUALITY } from '../../src/engine/renderer.js';
import { MeshBuilder } from '../../src/engine/mesh.js';
import { makeTexture, MATS } from '../../src/engine/textures.js';

const params = new URLSearchParams(location.search);
const q = params.get('q') || 'medium';
const canvas = document.getElementById('gl');
const R = new Renderer(canvas, { quality: q, preserve: true });
R.resize(innerWidth, innerHeight, devicePixelRatio);

const mats = {};
for (const [k, m] of Object.entries(MATS)) mats[k] = { ...m, tex: R.createTexture(makeTexture(m.tex, QUALITY[q].texSize)) };
mats.white = { tex: R.createTexture(makeTexture('white', 4)), emis: 3 };

const mk = (fn) => { const b = new MeshBuilder(); fn(b); return R.createMesh(b.finalize()); };
const W = 14, D = 10, H = 3.2;
const floor = mk((b) => b.flat(-W / 2, -D / 2, W / 2, D / 2, 0, true, { s: 2 }));
const ceil = mk((b) => b.flat(-W / 2, -D / 2, W / 2, D / 2, H, false, { s: 2, t: [0.6, 0.6, 0.6] }));
const walls = mk((b) => {
  b.wall(-W / 2, -D / 2, W / 2, -D / 2, 0, H, 0, 1, { s: 2, sv: 4 });
  b.wall(-W / 2, D / 2, W / 2, D / 2, 0, H, 0, -1, { s: 2, sv: 4 });
  b.wall(-W / 2, -D / 2, -W / 2, D / 2, 0, H, 1, 0, { s: 2, sv: 4 });
  b.wall(W / 2, -D / 2, W / 2, D / 2, 0, H, -1, 0, { s: 2, sv: 4 });
});
const tileWall = mk((b) => b.box(-6.6, 0, -1, -6.0, 3.2, 3, { s: 1.2 }));
const crate = mk((b) => { b.box(-1, 0, -3, 0.6, 1.1, -1.6, { s: 1 }); b.box(0.9, 0, -2.6, 1.8, 0.7, -1.8, { s: 1 }); });
const pipes = mk((b) => { b.tube(-6.4, 2.8, -4.8, 6.4, 2.8, -4.8, 0.14, 12, { s: 1 }); b.tube(-6.4, 2.5, -4.8, 6.4, 2.5, -4.8, 0.08, 10, { s: 1 }); });
const metalBox = mk((b) => b.box(3.5, 0, -0.5, 5, 1.6, 0.8, { s: 1 }));
const grate = mk((b) => b.box(-4, 0.01, 1.5, -2, 0.05, 3.5, { s: 1 }));
const lamp = mk((b) => b.box(-0.6, 2.95, -2.1, 0.6, 3.05, -1.9, {}));
const rock = mk((b) => b.sphere(2.5, 0.6, 2.8, 0.9, 10, 7, { s: 1 }));
const skinB = mk((b) => { b.tube(5.0, 0.05, 3.0, 5.0, 1.9, 3.0, 0.22, 10, { s: 0.6 }); b.sphere(5.0, 2.1, 3.0, 0.3, 10, 7, { s: 0.6 }); });

const lp = new Float32Array([0, 2.7, -2, 9, -4.5, 2.7, 3, 7]);
const lc = new Float32Array([1.8, 1.2, 0.7, 0, 0.3, 0.5, 1.2, 0]);
let t = 0;
function frame() {
  t += 1 / 30;
  const cam = { x: 0.5, y: 1.6, z: 4.2, yaw: parseFloat(params.get('yaw') || '-0.35'), pitch: -0.05, roll: 0, fov: 1.2, near: 0.1, far: 60 };
  const cp = Math.cos(cam.pitch);
  const dir = [Math.sin(cam.yaw) * cp, Math.sin(cam.pitch), -Math.cos(cam.yaw) * cp];
  R.begin(cam, {
    time: t, amb: [0.012, 0.013, 0.02], fog: [0.006, 0.008, 0.012, 0.05], exposure: 1.2,
    fl: [cam.x + 0.15, cam.y - 0.12, cam.z, 22], fd: [dir[0], dir[1], dir[2], 1], fc: [Math.cos(0.5), Math.cos(0.18)],
  });
  R.setLights(2, lp, lc);
  const list = [[floor, 'floor'], [ceil, 'conc'], [walls, 'wall'], [tileWall, 'tile'], [crate, 'wood'], [pipes, 'rust'], [metalBox, 'metal'], [grate, 'grate'], [rock, 'rock'], [skinB, 'skin']];
  if (R.shFbo && R.beginShadow(cam.x + 0.15, cam.y - 0.12, cam.z, dir[0], dir[1], dir[2], 1.1, 22)) {
    for (const [m] of list) R.drawDepth(m);
    R.endShadow();
  }
  for (const [m, k] of list) R.drawMesh(m, mats[k], 'lit');
  R.drawMesh(lamp, mats.white, 'emis');
  R.end({ vig: 0.7 });
}
let n = 0;
(function loop() { frame(); if (++n < 4) requestAnimationFrame(loop); else { window.__done = true; } })();
window.__err = null;
