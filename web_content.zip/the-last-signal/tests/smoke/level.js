// Level viewer: builds the real world (with content) and renders arbitrary camera views (driven from views.py).
import { Renderer } from '../../src/engine/renderer.js';
import { createMaterials } from '../../src/engine/materials.js';
import { World } from '../../src/world/world.js';
import { populate } from '../../src/world/content.js';
import { makeDecalMaterial } from '../../src/world/decals.js';
import { installDyn } from '../../src/world/dyn.js';

const params = new URLSearchParams(location.search);
const q = params.get('q') || 'medium';
const canvas = document.getElementById('gl');
const SKY = { hor: [0.05, 0.065, 0.1], zen: [0.004, 0.006, 0.02], moon: [0.52, 0.5, -0.69], dawn: 0 };
(async () => {
  try {
    const R = new Renderer(canvas, { quality: q, preserve: true });
    R.resize(innerWidth, innerHeight, 1);
    const mats = await createMaterials(R, q, null, { decal: makeDecalMaterial(R, q === 'low' ? 512 : 1024) });
    const world = new World();
    world.build(R, mats, populate);
    installDyn(world);
    if (params.get('power') !== '0') { for (const k in world.circ) world.circ[k] = k === 'emerg' ? 0 : 1; world.circCur = { ...world.circ }; }
    let t = 1;
    window.__world = world;
    window.__stats = () => ({ chunks: world.chunks.length, hides: world.content.hides.length, pickups: world.content.pickups.length, acts: world.content.interacts.length, props: world.grid.props.length });
    window.__view = (v) => {
      const g = world.grid, fy = g.floorY(v.x, v.z), a = g.areas[Math.max(0, g.areaAt(v.x, v.z))];
      const cam = { x: v.x, y: fy + (v.h ?? 1.6), z: v.z, yaw: v.yaw, pitch: v.pitch || 0, roll: 0, fov: 1.25, near: 0.08, far: 90 };
      const cp = Math.cos(cam.pitch), dir = [Math.sin(cam.yaw) * cp, Math.sin(cam.pitch), -Math.cos(cam.yaw) * cp];
      t += 0.37; world.update(0.016, t);
      R.begin(cam, {
        time: t, amb: world.ambient(Math.max(0, g.areaAt(v.x, v.z)), [0, 0, 0]), fog: a.outdoor ? [0.02, 0.03, 0.045, 0.028] : [0.008, 0.01, 0.013, 0.05], exposure: v.exp ?? 1.3,
        fl: [cam.x + 0.12, cam.y - 0.1, cam.z, 24], fd: [dir[0], dir[1], dir[2], v.fl ?? 1], fc: [Math.cos(0.55), Math.cos(0.2)], sky: a.outdoor ? SKY : null,
      });
      world.draw(R, cam);
      R.end({ vig: 0.6 });
      return world.drawn;
    };
    window.__ready = true;
  } catch (e) { window.__error = String(e && e.stack || e); console.error(window.__error); window.__ready = true; }
})();
