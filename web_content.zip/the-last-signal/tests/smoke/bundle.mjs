// node bundle.mjs <entry.js> <out.js>  -> unminified IIFE bundle for headless tests
import { createRequire } from 'node:module';
import path from 'node:path';
const require = createRequire(import.meta.url);
let esbuild;
for (const p of ['esbuild', '/opt/npm-tools/node_modules/esbuild']) { try { esbuild = require(p); break; } catch { /* next */ } }
const [entry, out] = process.argv.slice(2);
await esbuild.build({ entryPoints: [path.resolve(entry)], outfile: out, bundle: true, format: 'iife', target: 'chrome100', logLevel: 'warning' });
