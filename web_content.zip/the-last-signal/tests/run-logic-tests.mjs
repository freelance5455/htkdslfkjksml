// Logic tests for THE LAST SIGNAL. Pure Node (no browser, no GL): `npm test`.
// Builds the real World + level content with a stub renderer and exercises the real Nav / Grid / Monster / GameState code.
// The browser-level playthrough tests live in tests/play (Playwright + headless Chrome).
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import { makeWorld } from './headless.mjs';
import { START, AREAS, DOORS } from '../src/world/layout.js';
import { Nav } from '../src/game/nav.js';
import { Monster, S, STATE_NAMES } from '../src/game/monster.js';
import { CODES, STATIONS, NOTES, OBJECTIVES, TUNING } from '../src/game/data.js';
import { GameState, writeSave, readSave, hasSave, clearSave, STORE, SAVE_KEY } from '../src/game/state.js';

// ------------------------------------------------------------------ tiny harness
let pass = 0, fail = 0; const failed = [];
const group = (n) => console.log('\n' + n);
const test = (name, fn) => {
  try { fn(); pass++; console.log('  ✓ ' + name); }
  catch (e) { fail++; failed.push(name); console.log('  ✗ ' + name + '\n      ' + (e && e.message ? e.message : e)); }
};
const assert = (c, m = 'assertion failed') => { if (!c) throw new Error(m); };
const eq = (a, b, m = 'not equal') => { if (a !== b) throw new Error(`${m}: got ${JSON.stringify(a)}, expected ${JSON.stringify(b)}`); };
const near = (a, b, tol, m = 'not close') => { if (Math.abs(a - b) > tol) throw new Error(`${m}: got ${a}, expected ${b} +-${tol}`); };
// deterministic randomness for the whole run (Monster uses Math.random for waypoint picks and hide-search rolls)
const mulberry = (s) => () => { s |= 0; s = (s + 0x6d2b79f5) | 0; let t = Math.imul(s ^ (s >>> 15), 1 | s); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
const realRandom = Math.random;
const seed = (n) => { Math.random = mulberry(n); };

const w = makeWorld(), g = w.grid, C = w.content;
const cellOf = (x, z) => Math.floor(z) * g.W + Math.floor(x);
const areaId = (x, z) => { const i = g.areaAt(x, z); return i >= 0 ? g.areas[i].id : null; };

// ------------------------------------------------------------------ 1. level layout
group('1. level layout');
test('layout validator passes (overlaps, doors, heights, connectivity, lights)', () => {
  const r = spawnSync(process.execPath, [new URL('./validate-layout.mjs', import.meta.url).pathname, os.devNull], { encoding: 'utf8' });
  assert(r.status === 0, 'validate-layout.mjs failed:\n' + (r.stdout + r.stderr).split('\n').filter((l) => l.includes('✗') || /problem/.test(l)).join('\n'));
});
test('28 uniquely named areas and 18 doors (8 level sections incl. escape)', () => {
  eq(AREAS.length, 28, 'area count'); eq(new Set(AREAS.map((a) => a.id)).size, 28, 'unique area ids');
  eq(DOORS.length, 18, 'door count'); eq(new Set(DOORS.map((d) => d.id)).size, 18, 'unique door ids');
});
test('every pickup / interactable / hiding place / waypoint stands in open floor (not inside a wall)', () => {
  const bad = [];
  for (const p of C.pickups) if (g.solid[cellOf(p.x, p.z)]) bad.push('pickup ' + p.id);
  for (const a of C.interacts) { const k = cellOf(a.x, a.z); if (g.solid[k] && !a.wall) { /* wall-mounted interactables sit at the wall face; they must at least touch open floor */ let touch = false; for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) { const c = cellOf(a.x + dx, a.z + dz); if (!g.solid[c]) touch = true; } if (!touch) bad.push('interact ' + a.id); } }
  for (const h of C.hides) { if (g.solid[cellOf(h.front[0], h.front[1])]) bad.push('hide front ' + h.id); if (g.solid[cellOf(h.inside[0], h.inside[1])]) bad.push('hide inside ' + h.id); }
  for (const [z, pts] of Object.entries(C.patrol)) for (const [x, zz] of pts) if (g.solid[cellOf(x, zz)]) bad.push(`waypoint ${z} ${x},${zz}`);
  assert(!bad.length, bad.join(', '));
});
test('start position is open floor inside the courtyard', () => { eq(areaId(START.x, START.z), 'courtyard'); });
test('every door lock refers to a real circuit / key and has both sides walkable', () => {
  for (const d of g.doors) {
    if (d.lock.type === 'power') assert(d.lock.circuit in w.circ, `door ${d.id}: unknown circuit ${d.lock.circuit}`);
    if (d.lock.type === 'key') assert(typeof d.lock.item === 'string' && d.lock.item.length > 0, `door ${d.id}: key lock without item`);
    if (d.lock.type === 'script') assert(typeof d.lock.flag === 'string', `door ${d.id}: script lock without flag`);
  }
});

// ------------------------------------------------------------------ 2. content & puzzle data
group('2. content, resources and puzzle data');
test('every placed document exists in NOTES and every NOTES document is placed in the world', () => {
  const placed = new Set(C.interacts.filter((a) => a.note).map((a) => a.note));
  for (const id of placed) assert(NOTES[id], 'unknown note ' + id);
  for (const [id, n] of Object.entries(NOTES)) if (n.kind === 'doc') assert(placed.has(id), 'document never placed: ' + id);
});
test('required progression items exist: fuse, fuel can, a Level 3 keycard (cage + alternative)', () => {
  const n = (t) => C.pickups.filter((p) => p.type === t).length;
  eq(n('fuse'), 1, 'fuse'); eq(n('fuel'), 1, 'fuel'); assert(n('keycard3') >= 1, 'keycard3');
});
test('resource economy: enough batteries to finish (>= 30 min of torch), few enough to feel scarce (<= 60 min)', () => {
  const batt = C.pickups.filter((p) => p.type === 'battery').length + 1; // + the one the player starts with
  const minutes = (batt * TUNING.batteryCharge) / TUNING.batteryDrain / 60;
  assert(minutes >= 30 && minutes <= 60, `${batt} batteries = ${minutes.toFixed(0)} min of torch time`);
  const med = C.pickups.filter((p) => p.type === 'medkit').length;
  assert(med >= 4 && med <= 8, `${med} medkits`);
});
test('every pickup id is unique (saves track them by id)', () => { eq(new Set(C.pickups.map((p) => p.id)).size, C.pickups.length); });
test('locker code = day + month of the closure notice (14 JUNE -> 1406)', () => {
  assert(/14 JUNE/.test(NOTES.closure.body)); eq(CODES.locker, '1406'); assert(/day, then month/i.test(NOTES.guardnote.body));
});
const WORD = { zero: 0, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9 };
const spoken = (s) => [...s.matchAll(/\b(zero|one|two|three|four|five|six|seven|eight|nine)\b/gi)].map((m) => WORD[m[1].toLowerCase()]).join('');
test('cage code 7319 is what Dr. Rao reads out on the staff channel 88.4', () => {
  const st = STATIONS.find((s) => s.f === 88.4); assert(st, 'no 88.4 station');
  assert(st.lines.some((l) => spoken(l[1]).includes(CODES.cage) && /Seven\. Three\. One\. Nine/.test(l[1])), 'code not spoken'); eq(CODES.cage, '7319');
});
test('null sequence 417 is what the carrier (104.7, only audible near the Array) counts out', () => {
  const st = STATIONS.find((s) => s.f === 104.7); assert(st && st.needNear === 'array', 'carrier must require the array');
  assert(st.lines.some((l) => /Four\. One\. Seven/.test(l[1]))); eq(CODES.null, '417');
});
test('rack panel solution matches the whiteboard (filled = up)', () => {
  const row = NOTES.whiteboard.body.split('\n').find((l) => /[●○]/.test(l));
  const sol = [...row.matchAll(/[●○]/g)].map((m) => (m[0] === '●' ? 1 : 0)); assert(sol.join('') === CODES.panel.join(''), `board ${sol} vs ${CODES.panel}`);
});
test('breaker order matches the generator placard (2 - 3 - 1)', () => { assert(NOTES.placard.body.includes('2 - 3 - 1')); eq(CODES.breakers.join(''), '231'); });
test('three radio stations exist at distinct frequencies inside the tuner range', () => {
  eq(STATIONS.length, 3); eq(new Set(STATIONS.map((s) => s.f)).size, 3);
  for (const s of STATIONS) assert(s.f >= 85 && s.f <= 110, 'frequency ' + s.f);
});
test('the distress transmission and the "do not answer" warning are in the game text', () => {
  const dist = STATIONS.find((s) => s.id === 'distress').lines.map((l) => l[1]).join(' ');
  assert(/help me get out of here/i.test(dist) && /hear your own voice/i.test(dist) && /DO NOT ANSWER/.test(dist));
});
test('every objective id returned by Story.objective() has text', () => {
  const src = fs.readFileSync(new URL('../src/game/story.js', import.meta.url), 'utf8');
  const body = src.slice(src.indexOf('objective() {'), src.indexOf('refreshObjective'));
  const ids = [...body.matchAll(/return (?:f\('\w+'\) \? )?'(\w+)'(?: : '(\w+)')?/g)].flatMap((m) => [m[1], m[2]]).filter(Boolean);
  assert(ids.length >= 12, 'parsed too few ids: ' + ids); for (const id of ids) assert(OBJECTIVES[id], 'missing objective text for ' + id);
});

// ------------------------------------------------------------------ 3. collision & line of sight
group('3. collision and line of sight');
const freeCells = []; for (let z = 0; z < g.H; z++) for (let x = 0; x < g.W; x++) if (!g.solid[z * g.W + x] && g.doorAt[z * g.W + x] < 0) freeCells.push([x, z]);
const penetration = (x, z, r) => { // worst overlap of a circle with walls / closed doors / solid props
  let worst = 0;
  for (let cz = Math.floor(z - r); cz <= Math.floor(z + r); cz++) for (let cx = Math.floor(x - r); cx <= Math.floor(x + r); cx++) {
    if (!g.blockedCell(cx, cz)) continue;
    const nx = Math.max(cx, Math.min(x, cx + 1)), nz = Math.max(cz, Math.min(z, cz + 1)), d = Math.hypot(x - nx, z - nz); worst = Math.max(worst, r - d);
  }
  for (const p of g.props) { if (!p.solid) continue; const nx = Math.max(p.x0, Math.min(x, p.x1)), nz = Math.max(p.z0, Math.min(z, p.z1)), d = Math.hypot(x - nx, z - nz); worst = Math.max(worst, r - d); }
  return worst;
};
test('a walking circle never ends inside a wall or solid prop (40k random steps incl. 0.4 m frame spikes)', () => {
  seed(11); const r = 0.3; let worst = 0, steps = 0, inside = 0;
  for (let a = 0; a < 200; a++) {
    const c = freeCells[(Math.random() * freeCells.length) | 0]; let x = c[0] + 0.5, z = c[1] + 0.5, ang = Math.random() * 6.283;
    for (let i = 0; i < 200; i++) {
      if (Math.random() < 0.15) ang += (Math.random() - 0.5) * 3;
      const sp = Math.random() < 0.05 ? 0.41 : 0.02 + Math.random() * 0.07;   // 0.41 = sprint at the 0.1 s dt clamp
      const o = g.resolve(x + Math.cos(ang) * sp, z + Math.sin(ang) * sp, r); x = o.x; z = o.z; steps++;
      if (g.solid[cellOf(x, z)]) inside++; worst = Math.max(worst, penetration(x, z, r));
    }
  }
  eq(inside, 0, 'steps ending inside a solid cell'); console.log(`      (worst residual overlap ${(worst * 100).toFixed(1)} cm over ${steps} steps)`); assert(worst < 0.05, `worst penetration ${worst.toFixed(3)} m over ${steps} steps`);
});
test('a circle spawned overlapping a wall or closed door is pushed fully out (walls only: props can leave gaps narrower than the circle)', () => {
  seed(5); let bad = 0, n = 0; const props = g.props; g.props = [];
  try { for (let i = 0; i < 2000; i++) { const c = freeCells[(Math.random() * freeCells.length) | 0]; const o = g.resolve(c[0] + Math.random(), c[1] + Math.random(), 0.3); n++; if (penetration(o.x, o.z, 0.3) > 0.01) bad++; } } finally { g.props = props; }
  eq(bad, 0, `${bad}/${n} still overlapping`);
});
test('line of sight is symmetric and open inside a room', () => {
  seed(3); let asym = 0;
  for (let i = 0; i < 3000; i++) { const a = freeCells[(Math.random() * freeCells.length) | 0], b = freeCells[(Math.random() * freeCells.length) | 0]; const ax = a[0] + 0.5, az = a[1] + 0.5, bx = b[0] + 0.5, bz = b[1] + 0.5; if (g.los(ax, az, bx, bz, true) !== g.los(bx, bz, ax, az, true)) asym++; }
  assert(asym <= 6, `${asym}/3000 asymmetric pairs`);   // grid DDA can differ on exact corner grazes only
  const a = AREAS.find((q) => q.id === 'courtyard'); assert(g.los(a.x0 + 1.5, a.z0 + 1.5, a.x1 - 1.5, a.z1 - 1.5, true), 'diagonal across the open courtyard');
});
test('line of sight is blocked by walls and by closed doors, open again when the door opens', () => {
  const d = g.doors.find((q) => q.axis === 'x' && q.lock.type === 'key') || g.doors[0]; const cx = d.cx, cz = d.cz;
  const ax = d.axis === 'x' ? cx : cx - 2.5, az = d.axis === 'x' ? cz - 2.5 : cz, bx = d.axis === 'x' ? cx : cx + 2.5, bz = d.axis === 'x' ? cz + 2.5 : cz;
  const was = d.t; d.t = 0; assert(!g.los(ax, az, bx, bz, true), 'closed door must block sight'); d.t = 1; assert(g.los(ax, az, bx, bz, true), 'open door must not block'); d.t = was;
  // a random solid wall cell between two rooms
  let tested = 0; for (let z = 2; z < g.H - 2 && tested < 40; z++) for (let x = 2; x < g.W - 2 && tested < 40; x++) {
    if (!g.solid[z * g.W + x]) continue;
    if (!g.solid[z * g.W + x - 1] && !g.solid[z * g.W + x + 1] && g.doorAt[z * g.W + x - 1] < 0 && g.doorAt[z * g.W + x + 1] < 0) { assert(!g.los(x - 0.5, z + 0.5, x + 1.5, z + 0.5, true), `sight through wall at ${x},${z}`); tested++; }
  }
  assert(tested > 10, 'found too few single-thickness walls to test');
});

// ------------------------------------------------------------------ 4. navigation
group('4. monster navigation (A*)');
const nav = new Nav(w, 0.42);
const openAll = () => { w.canOpen = () => true; };
const realCanOpen = w.canOpen.bind(w);
test('every pickup, hiding place and patrol waypoint is reachable from the start (all doors openable, cage opened)', () => {
  openAll(); C.cageCol.solid = false; nav.rebuildProps();
  const targets = [];
  for (const p of C.pickups) targets.push(['pickup ' + p.id, p.x, p.z]);
  for (const h of C.hides) targets.push(['hide ' + h.id, h.front[0], h.front[1]]);
  for (const [z, pts] of Object.entries(C.patrol)) pts.forEach(([x, zz], i) => targets.push([`waypoint ${z}#${i}`, x, zz]));
  const bad = []; for (const [name, x, z] of targets) { const p = nav.path(START.x, START.z, x, z, 20000); if (!p) bad.push(name); }
  assert(!bad.length, 'unreachable: ' + bad.join(', '));
});
test('paths are collision-free: every segment passes the disc test and stays out of walls', () => {
  seed(21); let segs = 0;
  for (let i = 0; i < 120; i++) {
    const a = freeCells[(Math.random() * freeCells.length) | 0], b = freeCells[(Math.random() * freeCells.length) | 0];
    const p = nav.path(a[0] + 0.5, a[1] + 0.5, b[0] + 0.5, b[1] + 0.5, 20000); if (!p) continue;
    for (let k = 1; k < p.length; k++) {
      segs++; const n = Math.ceil(Math.hypot(p[k][0] - p[k - 1][0], p[k][1] - p[k - 1][1]) / 0.2);
      for (let s = 0; s <= n; s++) { const x = p[k - 1][0] + ((p[k][0] - p[k - 1][0]) * s) / n, z = p[k - 1][1] + ((p[k][1] - p[k - 1][1]) * s) / n; assert(!g.solid[cellOf(x, z)], `path crosses a wall at ${x.toFixed(2)},${z.toFixed(2)}`); }
    }
  }
  assert(segs > 100, 'too few path segments sampled: ' + segs);
});
test('the cage bars block the route until the cage is opened', () => {
  const kc = C.pickups.find((p) => p.id === 'keycard3'); C.cageCol.solid = true; nav.rebuildProps();
  const closed = nav.path(70, 72, kc.x, kc.z, 20000); C.cageCol.solid = false; nav.rebuildProps(); const open = nav.path(70, 72, kc.x, kc.z, 20000);
  assert(!closed || nav.pathLength(closed) > nav.pathLength(open) + 2, 'cage did not constrain the path'); assert(open, 'no path once opened');
});
test('locked / unpowered doors really block the monster (lab wing unreachable until its door is openable)', () => {
  w.canOpen = realCanOpen; for (const d of g.doors) d.t = d.open ? 1 : 0;
  const lab = C.patrol.lab[0], front = C.patrol.front[0];
  assert(nav.path(front[0], front[1], lab[0], lab[1], 20000) === null, 'monster could path into the locked lab wing');
  openAll(); assert(nav.path(front[0], front[1], lab[0], lab[1], 20000), 'no path once doors are openable'); w.canOpen = realCanOpen;
});
test('unreachable targets are rejected without a map-wide search (O(1) region check) and regions update when a door unlocks', () => {
  w.canOpen = realCanOpen; for (const d of g.doors) { d.t = d.open ? 1 : 0; delete d.target; } nav.rebuildProps();
  const lab = C.patrol.lab[0], front = C.patrol.front[0]; const t0 = process.hrtime.bigint(); let nulls = 0;
  for (let i = 0; i < 300; i++) if (nav.path(front[0], front[1], lab[0], lab[1], 20000) === null) nulls++;
  const per = Number(process.hrtime.bigint() - t0) / 1e6 / 300; eq(nulls, 300, 'lab waypoint must be unreachable while its door is locked'); assert(per < 0.2, 'unreachable query took ' + per.toFixed(3) + ' ms');
  const dl = g.doors.find((d) => d.id === 'd_ck_lab'); dl.locked = false; assert(nav.path(front[0], front[1], lab[0], lab[1], 20000), 'region cache did not refresh after the keycard door unlocked'); dl.locked = true;
  assert(nav.path(front[0], front[1], lab[0], lab[1], 20000) === null, 'region cache did not refresh after re-locking');
});
test('A* is fast enough for a phone: worst of 300 long searches < 25 ms in Node (budget ~5x slower on a mid-range phone)', () => {
  openAll(); seed(8); let worst = 0, tot = 0;
  for (let i = 0; i < 300; i++) { const a = freeCells[(Math.random() * freeCells.length) | 0], b = freeCells[(Math.random() * freeCells.length) | 0]; const t0 = process.hrtime.bigint(); nav.path(a[0] + 0.5, a[1] + 0.5, b[0] + 0.5, b[1] + 0.5); const dt = Number(process.hrtime.bigint() - t0) / 1e6; worst = Math.max(worst, dt); tot += dt; }
  console.log(`      (avg ${(tot / 300).toFixed(2)} ms, worst ${worst.toFixed(2)} ms)`); assert(worst < 25, 'worst ' + worst.toFixed(1) + ' ms'); w.canOpen = realCanOpen;
});

// ------------------------------------------------------------------ 5. save system
group('5. progress, saves and settings');
test('GameState serialises and parses back losslessly', () => {
  const s = new GameState(); s.set('blast'); s.keys.keycard1 = true; s.items.battery = 3; s.addNote('brief'); s.taken.b_court = true; s.objective = 'fuse'; s.stage = 2; s.health = 61; s.battery = 40; s.pos = { x: 5, z: 6, yaw: 1 }; s.puzzle = { panel: [1, 0, 0, 1] }; s.checkpoint = 'lab';
  const t = GameState.parse(s.serialize());
  eq(JSON.stringify(t.flags), JSON.stringify(s.flags)); eq(t.items.battery, 3); eq(t.keys.keycard1, true); eq(t.notes[0], 'brief'); eq(t.taken.b_court, true); eq(t.objective, 'fuse'); eq(t.stage, 2); eq(t.health, 61); eq(t.battery, 40); eq(t.pos.yaw, 1); eq(JSON.stringify(t.puzzle), '{"panel":[1,0,0,1]}'); eq(t.checkpoint, 'lab');
});
test('corrupt or foreign saves are rejected instead of crashing "Continue"', () => {
  for (const bad of ['', 'not json', '{"v":2}', 'null', '[]']) { let threw = false; try { GameState.parse(bad); } catch { threw = true; } assert(threw, 'accepted ' + JSON.stringify(bad)); }
  STORE.set(SAVE_KEY, '{"v":9,"flags":'); eq(hasSave(), false); eq(readSave(), null); clearSave();
});
test('write / has / read / clear round trip', () => {
  clearSave(); eq(hasSave(), false); const s = new GameState(); s.set('x'); s.health = 77; writeSave(s); eq(hasSave(), true); eq(readSave().health, 77); clearSave(); eq(hasSave(), false);
});
test('notes are de-duplicated', () => { const s = new GameState(); eq(s.addNote('a'), true); eq(s.addNote('a'), false); eq(s.notes.length, 1); });

// ------------------------------------------------------------------ 6. monster AI
group('6. monster AI state machine ("The Listener")');
const mkPlayer = (x, z, o = {}) => ({
  x, z, eyeY: 1.62, alive: true, hidden: null, holding: false, gasp: 0, sprinting: false, crouching: false, hp: 100, hits: 0, hitAt: [],
  fl: { on: false, power: 0 }, yaw: 0, forward() { return [Math.sin(this.yaw), -Math.cos(this.yaw)]; },
  exitHide() { this.hidden = null; },
  hurt(d) { this.hp -= d; this.hits++; this.hitAt.push(game.clock); if (this.hp <= 0) this.alive = false; },
  ...o,
});
let game;
const mkGame = (P) => { game = { world: w, player: P, difficulty: 1, clock: 0, ev: [], onMonsterState(s, why) { this.ev.push([this.clock, STATE_NAMES[s], why]); }, onMonsterAlert() {}, onMonsterChase() {} }; return game; };
// advance monster + world together like Game.step does
const run = (m, P, sec, fn) => { const dt = 1 / 30; for (let i = 0; i < sec / dt; i++) { game.clock += dt; w.update(dt, game.clock); m.update(dt, P); if (fn && fn(m, i) === false) break; } };
const open = () => { w.canOpen = () => true; nav.rebuildProps(); };
const reset = () => { w.canOpen = realCanOpen; for (const d of g.doors) { d.t = d.open ? 1 : 0; delete d.target; } C.cageCol.solid = true; };
const states = (ev) => ev.map((e) => e[1]);
const LEGAL = { Idle: ['Patrol', 'Investigate', 'Chase'], Patrol: ['Idle', 'Investigate', 'Chase'], Investigate: ['Search', 'Chase', 'Idle', 'Patrol'], Search: ['Return', 'Chase', 'Investigate'], Chase: ['Attack', 'Search', 'Investigate'], Attack: ['Chase', 'Idle'], Return: ['Patrol', 'Idle', 'Investigate', 'Chase', 'Search'] };

test('patrols its waypoints, never teleports and never ends up inside a wall (3 min)', () => {
  reset(); seed(42); open();
  const P = mkPlayer(110, 44); mkGame(P);
  const m = new Monster(game); m.setZones(['front', 'service']); const wp = C.patrol.front[0]; m.spawn(wp[0], wp[1], 0, { grace: 0 });
  let px = m.x, pz = m.z, maxStep = 0, inWall = 0, visited = new Set(), dist = 0;
  run(m, P, 180, () => { const s = Math.hypot(m.x - px, m.z - pz); maxStep = Math.max(maxStep, s); dist += s; px = m.x; pz = m.z; if (g.solid[cellOf(m.x, m.z)]) inWall++; visited.add(m.stateName); });
  assert(maxStep <= 4.5 * (1 / 30) + 1e-6, `max step ${maxStep.toFixed(3)} m/frame exceeds the chase speed cap`);
  eq(inWall, 0, 'frames inside a wall'); assert(visited.has('Idle') && visited.has('Patrol'), 'states seen: ' + [...visited]); assert(dist > 40, 'only moved ' + dist.toFixed(1) + ' m in 3 min');
  const tr = states(game.ev); for (let i = 1; i < tr.length; i++) assert(LEGAL[tr[i - 1]].includes(tr[i]), `illegal transition ${tr[i - 1]} -> ${tr[i]}`);
});
test('a noise sends it Investigate -> Search -> Return -> Patrol, walking there (no teleport)', () => {
  reset(); seed(7); open();
  const P = mkPlayer(110, 44); mkGame(P);
  const m = new Monster(game); m.setZones(['front']); const a = C.patrol.front[0]; m.spawn(a[0], a[1], 0, { grace: 0 });
  const far = C.patrol.front.map((p) => [p, Math.hypot(p[0] - m.x, p[1] - m.z)]).sort((x, y) => y[1] - x[1])[0][0];
  const d0 = Math.hypot(far[0] - m.x, far[1] - m.z); assert(d0 > 8, 'test waypoint too close: ' + d0);
  m.hear(far[0], far[1], d0 * 2.2, 'noise'); eq(m.heard.length, 1, 'noise was not queued');
  run(m, P, 1 / 30);   // one frame: the queued sound is processed
  eq(m.stateName, 'Investigate', 'noise did not trigger Investigate'); eq(m.target[0], far[0]);
  let beganSearchAt = null, px = m.x, pz = m.z, maxStep = 0;
  run(m, P, 150, () => { maxStep = Math.max(maxStep, Math.hypot(m.x - px, m.z - pz)); px = m.x; pz = m.z; if (m.stateName === 'Search' && !beganSearchAt) beganSearchAt = [m.x, m.z]; });
  const seq = states(game.ev); const iI = seq.indexOf('Investigate'), iS = seq.indexOf('Search'), iR = seq.indexOf('Return'), iP = seq.indexOf('Patrol', iR);
  assert(iI >= 0 && iS > iI && iR > iS && iP > iR, 'sequence was ' + seq.join(' > '));
  assert(beganSearchAt && Math.hypot(beganSearchAt[0] - far[0], beganSearchAt[1] - far[1]) < 3.5, 'started searching ' + (beganSearchAt ? Math.hypot(beganSearchAt[0] - far[0], beganSearchAt[1] - far[1]).toFixed(1) : '?') + ' m from the noise');
  assert(maxStep <= 4.5 / 30 + 1e-6, 'teleport-like step ' + maxStep);
});
test('noise too quiet or too far away is ignored; the grace period after spawning ignores everything', () => {
  reset(); seed(9); open(); const P = mkPlayer(110, 44); mkGame(P);
  const m = new Monster(game); m.setZones(['front']); const a = C.patrol.front[0]; m.spawn(a[0], a[1], 0, { grace: 5 });
  m.hear(a[0] + 4, a[1], 20, 'noise'); run(m, P, 0.1); assert(m.stateName !== 'Investigate', 'reacted during grace');
  m.grace = 0; m.hear(a[0] + 40, a[1], 8, 'noise'); eq(m.heard.length, 0, 'accepted a noise beyond 2x its loudness'); m.hear(a[0] + 7.9, a[1], 8, 'noise'); assert(m.heard.length <= 1);
});
test('vision: standing player 5 m ahead is spotted -> Chase -> Attack, hit = 52 dmg, once per 1.3 s, kills in 2 hits', () => {
  reset(); seed(13); open(); const lab = C.patrol.deep[0];
  const P = mkPlayer(lab[0], lab[1] - 6); P.fl.on = true; P.fl.power = 1; P.yaw = 0; mkGame(P);   // P looks north (-z); monster is north of P... put monster 5 m north of the player facing south
  const m = new Monster(game); m.setZones(['deep']); m.spawn(P.x, P.z - 5, Math.PI, { grace: 0 });
  assert(g.los(m.x, m.z, P.x, P.z), 'test placement has no line of sight (' + areaId(m.x, m.z) + ' / ' + areaId(P.x, P.z) + ')');
  P.yaw = 0;                                    // flashlight pointing at the monster
  let chaseAt = null, attackAt = null; run(m, P, 6, () => { if (m.stateName === 'Chase' && chaseAt === null) chaseAt = game.clock; if (m.stateName === 'Attack' && attackAt === null) attackAt = game.clock; if (!P.alive) return false; });
  assert(chaseAt !== null && chaseAt < 2.5, 'chase began at ' + chaseAt); assert(attackAt !== null && attackAt > chaseAt, 'attack at ' + attackAt);
  eq(P.hits >= 2, true, 'hits ' + P.hits); eq(P.alive, false, 'player should be dead after 2 hits (hp ' + P.hp + ')'); near(100 - P.hp, 104, 0.001, 'two hits of 52');
  near(P.hitAt[1] - P.hitAt[0], TUNING.hitCooldown, 0.1, 'hit spacing');
  run(m, P, 3); eq(m.stateName, 'Idle', 'must stand down after killing the player');
});
// straight, unobstructed 2D stretches of a given length that are either dark or lit (according to the monster's own light estimate)
const spots = (len, lit) => {
  for (let t = 0; t < 30; t++) w.update(1 / 30, t / 30);
  const probe = new Monster(mkGame(mkPlayer(0, 0))), out = [];
  for (const [cx, cz] of freeCells) for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
    const px = cx + 0.5, pz = cz + 0.5, mx = px + dx * len, mz = pz + dz * len, k = cellOf(mx, mz);
    if (mx < 1 || mz < 1 || mx > g.W - 1 || mz > g.H - 1 || g.solid[k] || g.doorAt[k] >= 0 || !g.los(mx, mz, px, pz)) continue;
    const l = probe._lightAt({ x: px, z: pz, eyeY: 1.62 }); if (lit ? l < 0.6 : l > 0.02) continue;
    out.push({ px, pz, mx, mz, yaw: Math.atan2(px - mx, -(pz - mz)), area: areaId(px, pz) });
  }
  return out;
};
// does the (idle, stationary) monster notice a player standing at the far end of the stretch within 6 s?
const noticed = (sp, setup) => {
  reset(); seed(17); open(); const P = mkPlayer(sp.px, sp.pz); mkGame(P);
  const m = new Monster(game); m.setZones(['lab']); m.spawn(sp.mx, sp.mz, sp.yaw, { grace: 0 }); m._idleFor = 1e9;
  if (setup) setup(P, m, sp); let saw = false; run(m, P, 6, () => { if (m.canSee || m.awareness > 0.3) saw = true; }); return saw;
};
const pick = (list) => list[Math.floor(list.length / 2)];
test('vision: dark rooms - crouching at 7 m is invisible, standing at 7 m is seen (range 5.3 vs 8.5 m)', () => {
  const l = spots(7, false); assert(l.length, 'no dark straight 7 m stretch in the level'); const sp = pick(l);
  assert(!noticed(sp, (P) => { P.crouching = true; }), 'crouched player seen at 7 m in the dark (' + sp.area + ')');
  assert(noticed(sp, (P) => { P.crouching = false; }), 'standing player NOT seen at 7 m in the dark (' + sp.area + ')');
});
test('vision: sprinting extends the range (9.5 m: walking unseen, sprinting seen)', () => {
  const l = spots(9.5, false); assert(l.length, 'no dark straight 9.5 m stretch'); const sp = pick(l);
  assert(!noticed(sp, () => {}), 'standing player seen beyond 8.5 m in the dark'); assert(noticed(sp, (P) => { P.sprinting = true; }), 'sprinting player not seen at 9.5 m');
});
test('vision: a torch pointed at the monster doubles your visibility (12 m: torch off unseen, torch on seen)', () => {
  const l = spots(12, false); if (!l.length) { console.log('      (skipped: no dark straight 12 m stretch in this level)'); return; } const sp = pick(l);
  assert(!noticed(sp, () => {}), 'seen at 12 m without a torch');
  assert(noticed(sp, (P, m, q) => { P.fl.on = true; P.fl.power = 1; P.yaw = Math.atan2(q.mx - q.px, -(q.mz - q.pz)); }), 'torch beam toward the monster not noticed at 12 m');
  assert(!noticed(sp, (P, m, q) => { P.fl.on = true; P.fl.power = 1; P.yaw = Math.atan2(q.mx - q.px, -(q.mz - q.pz)) + Math.PI; }), 'torch pointing AWAY should not extend range');
});
test('vision: lit rooms betray you (crouched at 7 m is seen when the room is lit)', () => {
  const l = spots(7, true); assert(l.length, 'no lit straight 7 m stretch'); assert(noticed(pick(l), (P) => { P.crouching = true; }), 'crouched player invisible in a lit room');
});
test('vision: a wall hides you even at 2 m, and a monster facing away does not see you at 7 m', () => {
  let tested = 0; for (let z = 2; z < g.H - 2 && tested < 1; z++) for (let x = 2; x < g.W - 2 && tested < 1; x++) {
    if (!g.solid[z * g.W + x] || g.solid[z * g.W + x - 1] || g.solid[z * g.W + x + 1] || g.doorAt[z * g.W + x - 1] >= 0 || g.doorAt[z * g.W + x + 1] >= 0) continue;
    const sp = { mx: x - 0.5, mz: z + 0.5, px: x + 1.5, pz: z + 0.5, yaw: Math.PI / 2 }; assert(!g.los(sp.mx, sp.mz, sp.px, sp.pz), 'test setup: wall does not block'); tested++;
    assert(!noticed(sp, () => {}), 'monster saw the player through a wall (' + areaId(x - 1, z) + ' / ' + areaId(x + 1, z) + ')');
  }
  eq(tested, 1, 'no wall found'); const sp = pick(spots(7, false)); assert(!noticed(sp, (P, m) => { m.yaw = sp.yaw + Math.PI; }), 'monster facing away still saw the player');
});
test('hiding: spotted player who is hidden is found with p=0.07 holding breath, 0.5 normally, 1.0 if gasping or watched going in', () => {
  const hide = C.hides[0]; const rate = (opts, sure = false, n = 500) => {
    let found = 0; seed(99);
    for (let i = 0; i < n; i++) {
      reset(); const P = mkPlayer(hide.inside[0], hide.inside[1], { hidden: hide, ...opts }); mkGame(P); const m = new Monster(game); m.spawn(hide.front[0], hide.front[1], 0, { grace: 0 }); m.setZones(['front']);
      m.setState(S.SEARCH, 'test'); m.searchT = 100; m.peek = { h: hide, t: 0, rolled: false, sure }; m.cur = { hide }; m.plan = []; m.stepIdx = 0;
      for (let k = 0; k < 40; k++) m.update(1 / 30, P);
      if (P.hidden === null) found++; hide.target = 0;
    }
    return found / n;
  };
  const held = rate({ holding: true }), normal = rate({}), gasp = rate({ gasp: 1 }), sure = rate({}, true);
  console.log(`      (found: holding breath ${(held * 100).toFixed(1)}%, normal ${(normal * 100).toFixed(1)}%, gasping ${(gasp * 100).toFixed(0)}%, watched ${(sure * 100).toFixed(0)}%)`);
  assert(held > 0.03 && held < 0.13, 'holding breath ' + held); assert(normal > 0.42 && normal < 0.58, 'normal ' + normal); eq(gasp, 1, 'gasping'); eq(sure, 1, 'watched');
});
test('after a chase it loses you (no sight, no sound) and goes Search -> Return -> Patrol instead of cheating', () => {
  reset(); seed(23); open(); const P = mkPlayer(110, 44); mkGame(P);
  const wp = C.patrol.deep; const m = new Monster(game); m.setZones(['deep']); m.spawn(wp[0][0], wp[0][1], 0, { grace: 0 });
  m.lastKnown = [wp[1][0], wp[1][1]]; m._startChase('test'); m.awareness = 1.3;
  run(m, P, 240); const seq = states(game.ev); assert(seq.includes('Chase') && seq.includes('Search'), 'sequence ' + seq.join(' > '));
  assert(['Patrol', 'Idle', 'Return'].includes(m.stateName), 'ended in ' + m.stateName);
  const tr = seq; for (let i = 1; i < tr.length; i++) assert(LEGAL[tr[i - 1]].includes(tr[i]), `illegal transition ${tr[i - 1]} -> ${tr[i]}`);
});
test('it opens doors itself when it is allowed to, takes time doing it, and cannot pass locked ones', () => {
  reset(); seed(31); const P = mkPlayer(110, 44); mkGame(P);
  const d = g.doors.find((q) => q.id === 'd_ck' || q.kind === 'metal') || g.doors[2]; const sideA = d.axis === 'x' ? [d.cx, d.cz - 2.2] : [d.cx - 2.2, d.cz], sideB = d.axis === 'x' ? [d.cx, d.cz + 2.2] : [d.cx + 2.2, d.cz];
  d.t = 0; delete d.target; w.canOpen = () => true;
  const m = new Monster(game); m.spawn(sideA[0], sideA[1], 0, { grace: 0 }); m.setZones(['front']); m._goto(sideB[0], sideB[1]); m.setState(S.INVESTIGATE, 'test'); m.target = sideB;
  let openedAt = null, passedAt = null; run(m, P, 12, () => { if (d.target === 1 && openedAt === null) openedAt = game.clock; if (Math.hypot(m.x - sideB[0], m.z - sideB[1]) < 0.8 && passedAt === null) passedAt = game.clock; });
  assert(openedAt !== null, 'never opened ' + d.id); assert(passedAt !== null && passedAt > openedAt + 0.3, 'passed at ' + passedAt + ' opened ' + openedAt);
  // locked: path must not exist through it
  d.t = 0; delete d.target; w.canOpen = () => false; const m2 = new Monster(game); m2.spawn(sideA[0], sideA[1], 0, { grace: 0 });
  const p2 = m2.nav.path(sideA[0], sideA[1], sideB[0], sideB[1]); if (p2) assert(m2.nav.pathLength(p2) > 12, 'found a shortcut through a locked door'); reset();
});
test('stage speedMul scales its pace (final "berserk" stage x1.35) and chase speed ramps up to a cap', () => {
  reset(); seed(2); open(); const P = mkPlayer(110, 44); mkGame(P);
  const pace = (mul) => { const m = new Monster(game); m.setZones(['deep']); const a = C.patrol.deep[0], b = C.patrol.deep[3]; m.spawn(a[0], a[1], 0, { grace: 0 }); m.speedMul = mul; m._goto(b[0], b[1]); m.setState(S.PATROL, 't'); let d = 0, px = m.x, pz = m.z; for (let i = 0; i < 90; i++) { m._follow(1 / 30, 1.55); d += Math.hypot(m.x - px, m.z - pz); px = m.x; pz = m.z; } return d; };
  const base = pace(1), fast = pace(1.35); assert(fast > base * 1.2 && fast < base * 1.5, `base ${base.toFixed(2)} fast ${fast.toFixed(2)}`);
  const m = new Monster(game); m.setZones(['deep']); const a = C.patrol.deep[0]; m.spawn(a[0], a[1], 0, { grace: 0 }); m._startChase('t'); m.lastKnown = [a[0] + 1, a[1]];
  let maxSpeed = 0; run(m, P, 60, () => { maxSpeed = Math.max(maxSpeed, m.speed); }); assert(maxSpeed <= 4.6, 'chase speed ' + maxSpeed); reset();
});
test('threat meter: 0 when inactive, 1 while chasing, scales with proximity otherwise', () => {
  reset(); const P = mkPlayer(60, 60); mkGame(P); const m = new Monster(game); m.spawn(60, 60, 0, { grace: 0, active: false }); eq(m.threat(P), 0);
  m.active = true; m.dist = 3; m.setState(S.CHASE, 't'); eq(m.threat(P), 1); m.setState(S.PATROL, 't'); m.dist = 3; const near_ = m.threat(P); m.dist = 30; const far_ = m.threat(P); assert(near_ > far_ && far_ === 0, `near ${near_} far ${far_}`);
});

// ------------------------------------------------------------------ summary
Math.random = realRandom;
console.log(`\n${pass} passed, ${fail} failed` + (fail ? `\nFAILED: ${failed.join('; ')}` : ''));
process.exit(fail ? 1 : 0);
