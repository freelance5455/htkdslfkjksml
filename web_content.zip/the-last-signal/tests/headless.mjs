// Builds the real World + content in Node with a stub renderer (no GL) for logic tests.
import { World } from '../src/world/world.js';
import { populate } from '../src/world/content.js';

export function makeWorld() {
  const R = { createMesh: (f) => ({ count: f.indices.length, bounds: f.bounds }), createTexture: () => ({}), q: { lights: 4 } };
  const mats = new Proxy({}, { get: (t, k) => (k in t ? t[k] : (t[k] = { tex: {}, bump: 0, spec: 0, shin: 8 })) });
  const w = new World();
  w.build(R, mats, populate);
  return w;
}
