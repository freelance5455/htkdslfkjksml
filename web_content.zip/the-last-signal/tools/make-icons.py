"""Regenerates the PWA / launcher icons in src/pwa (needs Pillow: pip install pillow). The PNGs are committed, so this is only needed to restyle them."""
import os
from PIL import Image, ImageDraw, ImageFilter
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src', 'pwa')
S = 4  # supersampling

def icon(size, maskable):
    N = size * S
    im = Image.new('RGB', (N, N), (6, 3, 4))
    px = im.load()
    cx, cy = N * 0.5, N * 0.5
    for y in range(N):                       # dark vignette with a faint red glow in the middle
        for x in range(N):
            d = ((x - cx) ** 2 + (y - cy) ** 2) ** 0.5 / (N * 0.7)
            g = max(0.0, 1 - d)
            px[x, y] = (int(6 + 46 * g * g), int(3 + 4 * g * g), int(4 + 7 * g * g))
    d = ImageDraw.Draw(im)
    k = 0.62 if maskable else 0.86          # maskable icons keep everything inside the central 80% safe zone
    R = N * 0.5 * k
    ox, oy = cx - R * 0.42, cy + R * 0.42   # transmitter sits low-left, signal arcs radiate up-right
    for i, (rad, w, a) in enumerate([(0.55, 0.075, 1.0), (0.95, 0.075, 0.72), (1.35, 0.075, 0.45)]):
        r = R * rad; col = tuple(int(c * a + b * (1 - a)) for c, b in zip((214, 28, 44), (10, 5, 6)))
        d.arc([ox - r, oy - r, ox + r, oy + r], start=-88, end=2, fill=col, width=int(R * w))
    r0 = R * 0.17
    d.ellipse([ox - r0 * 1.9, oy - r0 * 1.9, ox + r0 * 1.9, oy + r0 * 1.9], fill=(70, 10, 18))
    d.ellipse([ox - r0, oy - r0, ox + r0, oy + r0], fill=(236, 226, 214))
    im = im.filter(ImageFilter.GaussianBlur(S * 0.4)).resize((size, size), Image.LANCZOS)
    return im

for name, size, mask in [('icon-192.png', 192, False), ('icon-512.png', 512, False), ('icon-maskable-512.png', 512, True)]:
    icon(size, mask).save(os.path.join(OUT, name), optimize=True); print('wrote', name)
