// Grid world: carving, floor heights, collision, line-of-sight. Pure logic (no GL/DOM) so Node tests can run it.
import { GRID, AREAS, DOORS } from './layout.js';

export class Grid {
  constructor() {
    this.W = GRID.W; this.H = GRID.H;
    const n = this.W * this.H;
    this.solid = new Uint8Array(n).fill(1);
    this.area = new Int16Array(n).fill(-1);
    this.doorAt = new Int16Array(n).fill(-1);
    this.areas = AREAS; this.doors = DOORS.map((d) => ({ ...d, lock: { ...d.lock }, t: d.open ? 1 : 0, locked: d.lock.type === 'key' || d.lock.type === 'script' }));
    this.areaIndex = {}; this.doorIndex = {};
    this.props = [];            // AABB colliders {x0,z0,x1,z1,id,solid}
    this.propCell = new Uint8Array(n);
    this.occl = [];             // AABBs that block sight
    AREAS.forEach((a, i) => {
      this.areaIndex[a.id] = i;
      for (let z = a.z0; z < a.z1; z++) for (let x = a.x0; x < a.x1; x++) { const k = z * this.W + x; this.solid[k] = 0; this.area[k] = i; }
    });
    this.doors.forEach((d, i) => {
      this.doorIndex[d.id] = i;
      d.cells = [];
      for (let k = 0; k < d.w; k++) {
        const x = d.axis === 'x' ? d.x + k : d.x, z = d.axis === 'z' ? d.z + k : d.z, c = z * this.W + x;
        this.solid[c] = 0; this.doorAt[c] = i; d.cells.push(c);
        // door cells inherit the area of the first walkable neighbour (for lighting/culling)
        const nb = d.axis === 'x' ? [c - this.W, c + this.W] : [c - 1, c + 1];
        this.area[c] = this.area[nb[0]] >= 0 ? this.area[nb[0]] : this.area[nb[1]];
      }
      // centre of the doorway in world units
      d.cx = d.axis === 'x' ? d.x + d.w / 2 : d.x + 0.5; d.cz = d.axis === 'z' ? d.z + d.w / 2 : d.z + 0.5;
    });
  }
  idx(x, z) { return z * this.W + x; }
  inb(cx, cz) { return cx >= 0 && cz >= 0 && cx < this.W && cz < this.H; }
  areaAt(x, z) { const cx = Math.floor(x), cz = Math.floor(z); return this.inb(cx, cz) ? this.area[cz * this.W + cx] : -1; }
  // is this cell physically blocked right now (wall, closed door)?
  blockedCell(cx, cz) {
    if (!this.inb(cx, cz)) return true;
    const k = cz * this.W + cx;
    if (this.solid[k]) return true;
    const di = this.doorAt[k];
    return di >= 0 && this.doors[di].t < 0.85;
  }
  // continuous floor height for an area
  areaY(a, x, z) {
    const s = a.slope;
    if (!s) return a.y;
    const p = s.axis === 'x' ? (x - a.x0) / s.len : (z - a.z0) / s.len;
    return s.from + (s.to - s.from) * Math.min(1, Math.max(0, p));
  }
  floorY(x, z) {
    const cx = Math.floor(x), cz = Math.floor(z);
    if (!this.inb(cx, cz)) return 0;
    const ai = this.area[cz * this.W + cx];
    if (ai < 0) return 0;
    const a = this.areas[ai];
    return this.areaY(a, x, z);
  }
  ceilY(x, z) { const ai = this.areaAt(x, z); if (ai < 0) return 3; const a = this.areas[ai]; return this.areaY(a, x, z) + a.h; }

  // circle vs grid + prop AABBs: push the circle out of anything blocking. returns {x,z,hit}
  resolve(x, z, r) {
    let hit = false;
    for (let pass = 0; pass < 3; pass++) {
      const x0 = Math.floor(x - r), x1 = Math.floor(x + r), z0 = Math.floor(z - r), z1 = Math.floor(z + r);
      for (let cz = z0; cz <= z1; cz++) for (let cx = x0; cx <= x1; cx++) {
        if (!this.blockedCell(cx, cz)) continue;
        const nx = Math.max(cx, Math.min(x, cx + 1)), nz = Math.max(cz, Math.min(z, cz + 1));
        let dx = x - nx, dz = z - nz, d2 = dx * dx + dz * dz;
        if (d2 >= r * r) continue;
        hit = true;
        if (d2 < 1e-8) { // centre inside the cell: push along the shortest axis
          const l = x - cx, rr = cx + 1 - x, t = z - cz, b = cz + 1 - z, m = Math.min(l, rr, t, b);
          if (m === l) x = cx - r; else if (m === rr) x = cx + 1 + r; else if (m === t) z = cz - r; else z = cz + 1 + r;
        } else { const d = Math.sqrt(d2), p = r - d; x += (dx / d) * p; z += (dz / d) * p; }
      }
      for (const p of this.props) {
        if (!p.solid) continue;
        const nx = Math.max(p.x0, Math.min(x, p.x1)), nz = Math.max(p.z0, Math.min(z, p.z1));
        let dx = x - nx, dz = z - nz, d2 = dx * dx + dz * dz;
        if (d2 >= r * r) continue;
        hit = true;
        if (d2 < 1e-8) { const l = x - p.x0, rr = p.x1 - x, t = z - p.z0, b = p.z1 - z, m = Math.min(l, rr, t, b); if (m === l) x = p.x0 - r; else if (m === rr) x = p.x1 + r; else if (m === t) z = p.z0 - r; else z = p.z1 + r; }
        else { const d = Math.sqrt(d2), pu = r - d; x += (dx / d) * pu; z += (dz / d) * pu; }
      }
    }
    return { x, z, hit };
  }
  // 2D line of sight between two points. blocked by walls and closed doors (and props flagged occlude)
  los(ax, az, bx, bz, noProps = false) {
    let cx = Math.floor(ax), cz = Math.floor(az);
    const ex = Math.floor(bx), ez = Math.floor(bz);
    const dx = bx - ax, dz = bz - az;
    const sx = dx > 0 ? 1 : -1, sz = dz > 0 ? 1 : -1;
    const tdx = dx === 0 ? Infinity : Math.abs(1 / dx), tdz = dz === 0 ? Infinity : Math.abs(1 / dz);
    let tx = dx === 0 ? Infinity : ((dx > 0 ? cx + 1 - ax : ax - cx)) * tdx, tz = dz === 0 ? Infinity : ((dz > 0 ? cz + 1 - az : az - cz)) * tdz;
    for (let i = 0; i < 400; i++) {
      if (cx === ex && cz === ez) return noProps || this._occluded(ax, az, bx, bz);
      if (tx < tz) { cx += sx; tx += tdx; } else { cz += sz; tz += tdz; }
      if (this.blockedCell(cx, cz)) return cx === ex && cz === ez;
    }
    return noProps || this._occluded(ax, az, bx, bz);
  }
  _occluded(ax, az, bx, bz) {
    const dx = bx - ax, dz = bz - az, x0 = Math.min(ax, bx), x1 = Math.max(ax, bx), z0 = Math.min(az, bz), z1 = Math.max(az, bz);
    for (const o of this.occl) {
      if (o.x1 < x0 || o.x0 > x1 || o.z1 < z0 || o.z0 > z1) continue;
      let t0 = 0, t1 = 1, ok = true;
      for (let k = 0; k < 2 && ok; k++) {
        const p = k ? dz : dx, q = k ? az : ax, lo = k ? o.z0 : o.x0, hi = k ? o.z1 : o.x1;
        if (Math.abs(p) < 1e-9) { if (q < lo || q > hi) ok = false; } else { let a = (lo - q) / p, b = (hi - q) / p; if (a > b) { const t = a; a = b; b = t; } if (a > t0) t0 = a; if (b < t1) t1 = b; if (t0 > t1) ok = false; }
      }
      if (ok) return false;
    }
    return true;
  }
  // thick line of sight (circle radius r can travel straight from a to b)
  clear(ax, az, bx, bz, r) {
    const dx = bx - ax, dz = bz - az, l = Math.hypot(dx, dz) || 1, px = (-dz / l) * r, pz = (dx / l) * r;
    return this.los(ax, az, bx, bz) && this.los(ax + px, az + pz, bx + px, bz + pz) && this.los(ax - px, az - pz, bx - px, bz - pz);
  }
  addProp(p) {
    this.props.push(p);
    if (!p.solid) return;
    if (p.occlude) this.occl.push(p);
    for (let z = Math.floor(p.z0); z < Math.ceil(p.z1); z++) for (let x = Math.floor(p.x0); x < Math.ceil(p.x1); x++) {
      if (!this.inb(x, z)) continue;
      const ox = Math.min(p.x1, x + 1) - Math.max(p.x0, x), oz = Math.min(p.z1, z + 1) - Math.max(p.z0, z);
      if (ox * oz > 0.2) this.propCell[z * this.W + x] = 1;
    }
  }
}
