// Small hand-held pickup models (batteries, medkits, keycards ...). Each model = list of {mesh, mat, kind} parts.
import { MeshBuilder } from '../engine/mesh.js';

export const ITEM_INFO = {
  battery: { name: 'Battery', desc: 'Recharges the flashlight.', glow: [0.35, 1, 0.5], stack: true },
  medkit: { name: 'Medkit', desc: 'Restores health.', glow: [1, 0.3, 0.3], stack: true },
  fuse: { name: '20A Fuse', desc: 'Fits fuse box E-3 in the Lab Wing corridor.', glow: [1, 0.85, 0.3] },
  fuel: { name: 'Fuel Can', desc: 'Diesel for the backup generator.', glow: [1, 0.6, 0.2] },
  keycard1: { name: 'Keycard - Level 1', desc: 'Opens the Lab Wing door.', glow: [0.4, 0.8, 1] },
  keycard3: { name: 'Keycard - Level 3', desc: 'Opens the Chamber Zero access door.', glow: [1, 0.4, 0.4] },
  note: { name: 'Document', desc: 'Paper.', glow: [0.9, 0.9, 0.8] },
};

export function createItemModels(R, mats) {
  const out = {};
  const part = (key, fn, kind = 'lit') => { const mb = new MeshBuilder(); fn(mb); return { mesh: R.createMesh(mb.finalize()), mat: mats[key], kind }; };
  const T = (r, g, b) => ({ s: 1, t: [r, g, b], ao0: 0.9 });
  out.battery = [
    part('metal', (m) => { m.box(-0.07, 0, -0.04, 0.07, 0.2, 0.04, T(0.18, 0.2, 0.22)); m.box(-0.025, 0.2, -0.015, 0.025, 0.225, 0.015, T(0.8, 0.8, 0.8)); }),
    part('emis:white', (m) => { m.box(-0.071, 0.09, -0.041, 0.071, 0.12, 0.041, {}); }, 'emis'),
  ];
  out.medkit = [
    part('wall', (m) => { m.box(-0.17, 0, -0.1, 0.17, 0.2, 0.1, T(0.85, 0.85, 0.82)); }),
    part('wall', (m) => { m.box(-0.03, 0.06, 0.1, 0.03, 0.16, 0.103, T(0.7, 0.04, 0.04)); m.box(-0.06, 0.09, 0.1, 0.06, 0.13, 0.103, T(0.7, 0.04, 0.04)); }),
  ];
  out.fuse = [
    part('metal', (m) => { m.cyl(0, 0, 0, 0.022, 0.012, 8, T(0.7, 0.7, 0.7)); m.cyl(0, 0.118, 0, 0.022, 0.012, 8, T(0.7, 0.7, 0.7)); m.cyl(0, 0.012, 0, 0.018, 0.106, 8, T(0.95, 0.8, 0.3)); }),
  ];
  out.fuel = [
    part('rust', (m) => { m.box(-0.17, 0, -0.08, 0.17, 0.46, 0.08, T(0.85, 0.12, 0.1)); m.box(-0.17, 0.46, -0.08, -0.02, 0.5, 0.08, T(0.85, 0.12, 0.1)); m.cyl(0.1, 0.46, 0, 0.035, 0.1, 8, T(0.15, 0.15, 0.15)); }),
  ];
  const card = (c) => [
    part('wall', (m) => { m.box(-0.085, 0, -0.055, 0.085, 0.012, 0.055, T(c[0], c[1], c[2])); }),
    part('emis:white', (m) => { m.box(-0.07, 0.0125, 0.0, 0.07, 0.0135, 0.02, {}); }, 'emis'),
  ];
  out.keycard1 = card([0.15, 0.4, 0.75]); out.keycard3 = card([0.75, 0.15, 0.15]);
  out.note = [part('wall', (m) => { m.box(-0.1, 0, -0.14, 0.1, 0.008, 0.14, T(0.9, 0.86, 0.74)); m.box(-0.07, 0.008, -0.1, 0.07, 0.009, -0.09, T(0.2, 0.2, 0.2)); m.box(-0.07, 0.008, -0.06, 0.05, 0.009, -0.05, T(0.2, 0.2, 0.2)); m.box(-0.07, 0.008, -0.02, 0.06, 0.009, -0.01, T(0.2, 0.2, 0.2)); })];
  out.tape = [
    part('metal', (m) => { m.box(-0.07, 0, -0.045, 0.07, 0.04, 0.045, T(0.2, 0.2, 0.22)); }),
    part('emis:white', (m) => { m.box(0.04, 0.041, -0.01, 0.055, 0.043, 0.005, {}); }, 'emis'),
  ];
  return out;
}
