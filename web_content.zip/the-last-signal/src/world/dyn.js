// Draws content-owned dynamic meshes (array rings, levers, wheel, cage gate) and the swinging hide-spot door leaves.
import { m4 } from '../engine/math.js';

const M = m4.create();
export function installDyn(world) {
  const C = world.content;
  world.extraDraw.push((R, cam) => {
    const set = world.visSet;
    for (const id in C.objs) {
      const o = C.objs[id];
      if (!o.visible) continue;
      const dx = o.x - cam.x, dz = o.z - cam.z;
      if (dx * dx + dz * dz > 2500 || (set && o.ai >= 0 && !set[o.ai])) continue;
      const ch = world.chunkFor(o.x, o.z); if (ch) world._select(R, ch, cam);
      m4.fromTRS(M, o.x, o.y, o.z, o.rx, o.ry, o.rz, o.sx, o.sy, o.sz);
      for (const p of o.parts) R.drawMesh(p.mesh, p.mat, p.kind, M, 1, p.kind === 'emis' ? (o.tint || null) : null);
    }
    for (const h of C.hides) {
      if (h.occupied && h.ang < 0.04) continue;
      const dx = h.x - cam.x, dz = h.z - cam.z;
      if (dx * dx + dz * dz > 1600) continue;
      const ch = world.chunkFor(h.x + (h.front[0] - h.x) * 0.5, h.z + (h.front[1] - h.z) * 0.5); if (ch) world._select(R, ch, cam);
      m4.fromTRS(M, h.hx, h.y, h.hz, 0, h.rot0 - h.ang, 0, 1, 1, 1);
      R.drawMesh(h.mesh, h.mat, 'lit', M);
    }
  });
}
