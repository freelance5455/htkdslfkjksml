// Level data for Chapter 1: VAJRA DEEP RESEARCH STATION. 1 cell = 1 metre. x east, z south, y up.
// Areas are rectangles [x0,x1) x [z0,z1) carved from solid rock. Doors sit in 1-cell-thick wall rows between areas.
export const GRID = { W: 126, H: 80 };

const A = (id, x0, z0, x1, z1, y, h, o = {}) => ({ id, x0, z0, x1, z1, y, h, wall: 'wall', floor: 'floor', ceil: 'conc', tint: [1, 1, 1], ftint: [1, 1, 1], amb: [0.05, 0.055, 0.07], zone: 'lobby', reverb: 0.3, ...o });

export const AREAS = [
  // --- surface + entrance ---
  A('courtyard', 4, 56, 22, 70, 0, 6, { outdoor: true, wall: 'conc', floor: 'dirt', tint: [0.55, 0.6, 0.68], zone: 'surface', reverb: 0.05, amb: [0.07, 0.085, 0.12] }),
  A('ramp', 23, 60, 41, 66, 0, 4.4, { wall: 'conc', floor: 'floor', slope: { axis: 'x', from: 0, to: -4, len: 18 }, tint: [0.8, 0.82, 0.85], zone: 'lobby', reverb: 0.5 }),
  A('lobby', 41, 53, 57, 71, -4, 4.4, { floor: 'tile', ftint: [0.5, 0.52, 0.5], tint: [1, 0.95, 0.85], zone: 'lobby', reverb: 0.7 }),
  A('checkpoint', 41, 38, 57, 52, -4, 3.8, { floor: 'floor', tint: [0.95, 1, 0.95], zone: 'ck', reverb: 0.6 }),
  A('guard', 58, 40, 67, 49, -4, 3.2, { tint: [1, 0.92, 0.8], zone: 'ck', reverb: 0.3 }),
  // --- laboratory wing ---
  A('lc1', 47, 26, 50, 37, -4, 3.2, { floor: 'tile', ftint: [0.45, 0.5, 0.48], tint: [0.9, 1, 0.95], zone: 'lab', reverb: 0.6 }),
  A('lc2', 47, 19, 50, 26, -4, 3.2, { floor: 'tile', ftint: [0.45, 0.5, 0.48], tint: [0.9, 1, 0.95], zone: 'lab', reverb: 0.6 }),
  A('lc3', 47, 12, 50, 19, -4, 3.2, { floor: 'tile', ftint: [0.45, 0.5, 0.48], tint: [0.9, 1, 0.95], zone: 'lab', reverb: 0.6 }),
  A('sw', 30, 9, 47, 12, -4, 3.2, { floor: 'tile', ftint: [0.45, 0.5, 0.48], tint: [0.8, 0.95, 0.95], zone: 'lab', reverb: 0.6 }),
  A('sj', 47, 9, 50, 12, -4, 3.2, { floor: 'tile', ftint: [0.45, 0.5, 0.48], tint: [0.8, 0.95, 0.95], zone: 'lab', reverb: 0.6 }),
  A('se1', 50, 9, 66, 12, -4, 3.2, { floor: 'floor', tint: [0.85, 0.9, 0.9], zone: 'gen', reverb: 0.6 }),
  A('se2', 66, 9, 82, 12, -4, 3.2, { floor: 'floor', tint: [0.85, 0.9, 0.9], zone: 'gen', reverb: 0.6 }),
  A('research', 28, 13, 46, 30, -4, 3.6, { floor: 'tile', ftint: [0.5, 0.55, 0.55], tint: [0.9, 1, 1], zone: 'research', reverb: 0.7 }),
  A('secret', 16, 15, 27, 23, -4, 3.2, { floor: 'floor', tint: [0.8, 0.85, 0.8], zone: 'research', reverb: 0.4 }),
  A('break', 36, 31, 46, 36, -4, 3.2, { tint: [1, 0.9, 0.75], zone: 'lab', reverb: 0.3 }),
  A('lockers', 51, 13, 59, 24, -4, 3.2, { wall: 'tile', floor: 'tile', tint: [0.8, 0.85, 0.85], ftint: [0.5, 0.55, 0.55], zone: 'gen', reverb: 0.8 }),
  A('decon', 51, 27, 59, 35, -4, 3.2, { wall: 'tile', floor: 'tile', tint: [0.8, 0.9, 0.85], ftint: [0.5, 0.55, 0.55], zone: 'lab', reverb: 0.8 }),
  // --- power + storage ---
  A('gen', 60, 13, 80, 31, -4, 7, { wall: 'conc', floor: 'floor', ceil: 'metal', tint: [0.75, 0.78, 0.8], zone: 'gen', reverb: 0.9 }),
  A('sr', 68, 32, 72, 56, -4, 4.2, { wall: 'conc', floor: 'floor', slope: { axis: 'z', from: -4, to: -10, len: 24 }, tint: [0.7, 0.72, 0.75], zone: 'storage', reverb: 0.8 }),
  A('storage', 58, 56, 96, 77, -10, 5.5, { wall: 'rock', floor: 'floor', ceil: 'metal', tint: [0.8, 0.8, 0.8], zone: 'storage', reverb: 1 }),
  A('link', 93, 40, 96, 56, -10, 3.4, { wall: 'conc', floor: 'floor', tint: [0.7, 0.75, 0.8], zone: 'chamber', reverb: 0.7 }),
  A('ante', 91, 31, 98, 39, -10, 3.4, { wall: 'metal', floor: 'metal', tint: [0.8, 0.9, 1], zone: 'chamber', reverb: 0.6 }),
  A('chamber', 86, 8, 116, 30, -10, 10, { wall: 'metal', floor: 'metal', ceil: 'conc', tint: [0.7, 0.78, 0.9], zone: 'chamber', reverb: 1 }),
  // --- escape ---
  A('esc_a', 86, 4, 92, 7, -10, 3.2, { wall: 'conc', floor: 'floor', tint: [0.8, 0.75, 0.75], zone: 'esc', reverb: 0.6 }),
  A('esc_b', 92, 4, 120, 7, -10, 3.2, { wall: 'conc', floor: 'floor', slope: { axis: 'x', from: -10, to: -5, len: 26 }, tint: [0.8, 0.75, 0.75], zone: 'esc', reverb: 0.6 }),
  A('esc_c', 117, 7, 120, 30, -5, 3.2, { wall: 'conc', floor: 'floor', slope: { axis: 'z', from: -5, to: 0, len: 23 }, tint: [0.8, 0.75, 0.75], zone: 'esc', reverb: 0.6 }),
  A('hatch', 116, 30, 123, 38, 0, 5, { wall: 'conc', floor: 'floor', tint: [0.8, 0.8, 0.82], zone: 'esc', reverb: 0.7 }),
  A('outside', 108, 39, 125, 48, 0, 7, { outdoor: true, wall: 'conc', floor: 'dirt', tint: [0.6, 0.64, 0.72], zone: 'surface', reverb: 0.05, amb: [0.09, 0.1, 0.14] }),
];

// Doors: axis 'x' = the leaf spans x..x+w-1 on wall row z; axis 'z' = spans z..z+w-1 on wall column x.
// lock: none | key(item) | power(circuit) | script(flag) ; kind: sliding leaf style
const D = (id, x, z, w, axis, o = {}) => ({ id, x, z, w, axis, open: false, lock: { type: 'none' }, kind: 'metal', hgt: 2.7, slide: 1, ...o });
export const DOORS = [
  D('d_blast', 22, 61, 4, 'z', { kind: 'blast', hgt: 3.6, label: 'MAIN BLAST DOOR', open: true }),
  D('d_lobby_ck', 47, 52, 2, 'axis_x_placeholder'),
  D('d_guard', 57, 43, 2, 'z'),
  D('d_ck_lab', 47, 37, 3, 'x', { lock: { type: 'key', item: 'keycard1' }, label: 'LAB WING - LEVEL 1' }),
  D('d_rs_e', 46, 18, 2, 'z', { lock: { type: 'power', circuit: 'lab' }, label: 'RESEARCH' }),
  D('d_rs_n', 33, 12, 2, 'x', { lock: { type: 'power', circuit: 'lab' } }),
  D('d_br', 46, 33, 2, 'z'),
  D('d_lk_w', 50, 17, 2, 'z'),
  D('d_lk_e', 59, 17, 2, 'z'),
  D('d_dc', 50, 30, 2, 'z'),
  D('d_gn_n', 68, 12, 2, 'x'),
  D('d_stor', 68, 31, 4, 'x', { kind: 'shutter', hgt: 3.4, lock: { type: 'power', circuit: 'gen' }, label: 'STORAGE B2 - POWER REQUIRED' }),
  D('d_ante', 93, 39, 2, 'x', { lock: { type: 'key', item: 'keycard3' }, label: 'CHAMBER ACCESS - LEVEL 3' }),
  D('d_ch', 93, 30, 2, 'x', { lock: { type: 'power', circuit: 'gen' }, label: 'CHAMBER ZERO' }),
  D('d_esc', 88, 7, 2, 'x', { lock: { type: 'script', flag: 'escape' }, label: 'EMERGENCY EXIT' }),
  D('d_esc_sh', 106, 4, 3, 'z', { kind: 'shutter', hgt: 3.0, open: true, lock: { type: 'none' } }),
  D('d_exit', 118, 38, 2, 'x', { kind: 'blast', hgt: 3.6, lock: { type: 'script', flag: 'exitWheel' }, label: 'SURFACE EXIT' }),
  D('d_secret', 27, 17, 2, 'z', { kind: 'rack', lock: { type: 'script', flag: 'secretRack' } }),
];
DOORS.find((d) => d.id === 'd_lobby_ck').axis = 'x';

// Light fixtures. circuit: which power circuit feeds it. flick: none|flicker|pulse|dead
const L = (area, x, y, z, r, c, i, circuit, flick = 'none', extra = {}) => ({ area, x, y, z, r, c, i, circuit, flick, ...extra });
const WARM = [1, 0.72, 0.42], COLD = [0.6, 0.85, 1], SICK = [0.72, 0.95, 0.82], RED = [1, 0.1, 0.06], AMBER = [1, 0.55, 0.15];
export const LIGHTS = [
  // lobby: failing emergency lamps
  L('lobby', 46, 4.1, 58, 9, WARM, 0.9, 'lobby', 'flicker'), L('lobby', 52, 4.1, 64, 8, WARM, 0.6, 'lobby', 'pulse'), L('lobby', 47, 4.1, 67, 7, SICK, 0.4, 'lobby', 'dead'),
  L('ramp', 30, 4.0, 63, 8, [0.55, 0.65, 0.9], 0.5, 'always', 'pulse'),
  L('courtyard', 12, 5.2, 62, 12, [0.5, 0.6, 0.85], 0.7, 'always', 'none', { moon: true }),
  // checkpoint
  L('checkpoint', 46, 3.5, 44, 9, COLD, 0.8, 'ck', 'flicker'), L('checkpoint', 52, 3.5, 44, 8, COLD, 0.5, 'ck', 'dead'), L('checkpoint', 49, 3.5, 40, 7, AMBER, 0.45, 'ck', 'pulse'),
  L('guard', 62, 3.0, 44, 8, WARM, 0.8, 'ck', 'flicker'),
  // lab corridor + service corridors: dark until the fuse is replaced
  ...[30, 22, 15].map((z, k) => L(k === 0 ? 'lc1' : k === 1 ? 'lc2' : 'lc3', 48.5, 3.0, z, 7, SICK, 0.75, 'lab', k === 1 ? 'flicker' : 'none')),
  L('lc1', 48.5, 3.0, 34, 6, SICK, 0.6, 'lab', 'flicker'),
  L('sj', 48.5, 3.0, 10.5, 7, SICK, 0.7, 'lab', 'none'), L('sw', 40, 3.0, 10.5, 7, SICK, 0.6, 'lab', 'flicker'), L('sw', 33, 3.0, 10.5, 7, SICK, 0.6, 'lab', 'none'),
  L('research', 33, 3.4, 20, 11, COLD, 0.85, 'lab', 'flicker'), L('research', 40, 3.4, 20, 11, COLD, 0.7, 'lab', 'none'), L('research', 36, 3.4, 26, 10, COLD, 0.6, 'lab', 'dead'),
  L('secret', 21, 3.0, 19, 9, AMBER, 0.6, 'lab', 'pulse'),
  L('break', 41, 3.0, 33.5, 8, WARM, 0.7, 'lab', 'flicker'),
  L('lockers', 55, 3.0, 18, 9, COLD, 0.7, 'gen', 'flicker'), L('decon', 55, 3.0, 31, 9, SICK, 0.7, 'gen', 'none'),
  L('se1', 56, 3.0, 10.5, 7, SICK, 0.6, 'gen', 'none'), L('se1', 63, 3.0, 10.5, 7, SICK, 0.5, 'gen', 'flicker'), L('se2', 72, 3.0, 10.5, 7, SICK, 0.6, 'gen', 'none'),
  // generator hall: a pair of work lights on the emergency circuit, everything else needs the generator
  L('gen', 66, 6.5, 22, 14, AMBER, 0.7, 'gen', 'flicker'), L('gen', 74, 6.5, 22, 14, AMBER, 0.7, 'gen', 'none'), L('gen', 70, 6.5, 17, 12, COLD, 0.6, 'gen', 'pulse'),
  L('gen', 76, 2.5, 27, 8, [1, 0.5, 0.2], 0.9, 'always', 'pulse', { fx: 'gauge' }),
  L('sr', 70, 3.8, 38, 8, AMBER, 0.6, 'gen', 'none'), L('sr', 70, 3.8, 46, 8, AMBER, 0.6, 'gen', 'flicker'),
  // storage: big hall, lamps on aisles
  ...[[66, 62], [78, 62], [90, 62], [66, 70], [78, 70], [90, 70]].map(([x, z], k) => L('storage', x, 5.0, z, 12, k % 3 === 1 ? WARM : [0.9, 0.95, 1], 0.85, 'gen', k === 4 ? 'flicker' : 'none')),
  L('link', 94.5, 3.0, 48, 8, SICK, 0.6, 'gen', 'flicker'), L('link', 94.5, 3.0, 43, 7, SICK, 0.5, 'gen', 'none'),
  L('ante', 94.5, 3.0, 35, 8, [0.9, 0.9, 1], 0.7, 'gen', 'flicker'),
  L('chamber', 100, 9.0, 14, 18, [0.4, 0.6, 1], 0.9, 'gen', 'pulse'), L('chamber', 100, 9.0, 22, 18, [0.55, 0.7, 1], 0.7, 'gen', 'none'),
  L('chamber', 92, 8.0, 18, 14, COLD, 0.6, 'gen', 'flicker'), L('chamber', 108, 8.0, 18, 14, COLD, 0.6, 'gen', 'none'),
  // escape lights (red) come on when the array is silenced
  L('esc_a', 89, 3.0, 5, 8, RED, 1.1, 'emerg', 'pulse'),
  ...[96, 104, 112].map((x) => L('esc_b', x, 3.0, 5.5, 8, RED, 1.0, 'emerg', 'pulse')),
  ...[12, 20, 27].map((z) => L('esc_c', 118.5, 3.0, z, 8, RED, 1.0, 'emerg', 'pulse')),
  L('hatch', 119.5, 4.4, 34, 11, [0.9, 0.35, 0.2], 0.9, 'emerg', 'pulse'),
  L('outside', 116, 6.0, 44, 20, [0.6, 0.7, 1], 1.0, 'always', 'none', { moon: true }),
];

export const START = { x: 7.5, z: 63, yaw: Math.PI / 2 };
