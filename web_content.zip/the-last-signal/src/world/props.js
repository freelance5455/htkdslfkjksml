// Prop kit: furniture / machinery built from MeshBuilder primitives into the chunk meshes, with AABB colliders.
// Local prop space: x = right, z = depth with the FRONT facing +z; `face` rotates the front to n/e/s/w.
import { m4, rng } from '../engine/math.js';
import { MeshBuilder } from '../engine/mesh.js';
import { wallDecal, floorDecal } from './decals.js';

const FACE = { s: 0, e: Math.PI / 2, n: Math.PI, w: -Math.PI / 2 };
const QUART = (f) => ((Math.round(FACE[f] / (Math.PI / 2)) % 4) + 4) % 4;
export const DIRV = { s: [0, 1], e: [1, 0], n: [0, -1], w: [-1, 0] };
const M = m4.create();

export class Props {
  constructor(world, getChunk) {
    this.w = world; this.g = world.grid; this.getChunk = getChunk; this.R = rng(1234);
    this.hides = []; this.dyn = []; this.items = [];
  }
  y(x, z) { return this.g.floorY(x, z); }
  // run fn(mb, y) with the chunk builder for material `key`, transformed into prop space at (x,z) facing `face`
  with(key, x, z, face, fn, y0) {
    const ch = this.getChunk(x, z), mb = ch.mb(key), y = y0 ?? this.y(x, z);
    m4.fromTRS(M, x, y, z, 0, FACE[face] || 0, 0, 1, 1, 1);
    const prev = mb.xf(M.slice());
    fn(mb, 0);
    mb.xf(prev);
  }
  // register an axis-aligned collider from a local box (w wide, d deep) centred at (x,z)
  collide(x, z, face, w, d, o = {}) {
    const q = QUART(face), sw = q & 1 ? d : w, sd = q & 1 ? w : d;
    const p = { x0: x - sw / 2, x1: x + sw / 2, z0: z - sd / 2, z1: z + sd / 2, solid: o.solid !== false, occlude: !!o.occlude, id: o.id };
    this.g.addProp(p); return p;
  }
  // world position of a local offset (lx, lz) for a prop at (x,z,face)
  at(x, z, face, lx, lz) { const a = FACE[face] || 0, c = Math.cos(a), s = Math.sin(a); return [x + lx * c + lz * s, z - lx * s + lz * c]; }

  box(x, z, face, w, h, d, key = 'metal', o = {}) { this.with(key, x, z, face, (mb) => mb.box(-w / 2, o.y || 0, -d / 2, w / 2, (o.y || 0) + h, d / 2, { s: o.s || 1.5, t: o.t || [1, 1, 1], ao0: o.ao0 ?? 0.7, ao1: o.ao1 ?? 1 })); if (!o.nocol) this.collide(x, z, face, w, d, o); }

  desk(x, z, face, o = {}) {
    const w = o.w || 1.6, d = o.d || 0.78;
    this.with('wood', x, z, face, (mb) => {
      mb.box(-w / 2, 0.7, -d / 2, w / 2, 0.76, d / 2, { s: 1, t: o.t || [0.9, 0.85, 0.8] });
      mb.box(-w / 2 + 0.03, 0, -d / 2 + 0.03, -w / 2 + 0.07, 0.7, d / 2 - 0.03, { s: 1, t: [0.5, 0.5, 0.52], ao0: 0.6 });
      mb.box(w / 2 - 0.07, 0, -d / 2 + 0.03, w / 2 - 0.03, 0.7, d / 2 - 0.03, { s: 1, t: [0.5, 0.5, 0.52], ao0: 0.6 });
      mb.box(-w / 2 + 0.07, 0.25, -d / 2 + 0.03, w / 2 - 0.07, 0.7, -d / 2 + 0.06, { s: 1, t: [0.55, 0.55, 0.58], ao0: 0.7 });
      mb.box(w / 2 - 0.5, 0.1, -d / 2 + 0.06, w / 2 - 0.07, 0.68, d / 2 - 0.04, { s: 1, t: [0.6, 0.58, 0.55] });
    });
    this.with('metal', x, z, face, (mb) => { for (let i = 0; i < 3; i++) mb.box(w / 2 - 0.46, 0.14 + i * 0.2, d / 2 - 0.04, w / 2 - 0.1, 0.28 + i * 0.2, d / 2 - 0.02, { s: 1, t: [0.3, 0.3, 0.32] }); });
    if (o.screen) this.monitor(x, z, face, -0.25, -0.12, 0.76, o.screen);
    this.collide(x, z, face, w, d);
  }
  monitor(x, z, face, lx, lz, y, on = true) {
    this.with('metal', x, z, face, (mb) => { mb.box(lx - 0.28, y, lz - 0.14, lx + 0.28, y + 0.04, lz + 0.14, { s: 1, t: [0.2, 0.2, 0.22] }); mb.box(lx - 0.04, y, lz - 0.04, lx + 0.04, y + 0.2, lz + 0.04, { s: 1, t: [0.2, 0.2, 0.22] }); mb.box(lx - 0.32, y + 0.18, lz - 0.06, lx + 0.32, y + 0.56, lz + 0.01, { s: 1, t: [0.14, 0.14, 0.15] }); });
    if (on) this.with('emis:screen', x, z, face, (mb) => mb.q([lx - 0.29, y + 0.2, lz + 0.015, lx + 0.29, y + 0.2, lz + 0.015, lx + 0.29, y + 0.54, lz + 0.015, lx - 0.29, y + 0.54, lz + 0.015], 0, 0, 1, [0, 0, 1, 0, 1, 1, 0, 1], on === true ? [1, 1, 1] : on));
  }
  chair(x, z, face, o = {}) {
    this.with('metal', x, z, face, (mb) => {
      mb.box(-0.22, 0.44, -0.22, 0.22, 0.49, 0.22, { s: 1, t: o.t || [0.3, 0.32, 0.36] }); mb.box(-0.22, 0.49, -0.24, 0.22, 0.9, -0.2, { s: 1, t: o.t || [0.3, 0.32, 0.36] });
      mb.cyl(0, 0, 0, 0.025, 0.44, 6, { s: 1, t: [0.5, 0.5, 0.5] }); mb.box(-0.2, 0, -0.03, 0.2, 0.03, 0.03, { s: 1, t: [0.2, 0.2, 0.2] }); mb.box(-0.03, 0, -0.2, 0.03, 0.03, 0.2, { s: 1, t: [0.2, 0.2, 0.2] });
    });
  }
  table(x, z, face, w = 1.2, d = 0.7, h = 0.75, key = 'wood') { this.with(key, x, z, face, (mb) => { mb.box(-w / 2, h - 0.05, -d / 2, w / 2, h, d / 2, { s: 1, t: [0.85, 0.8, 0.75] }); for (const sx of [-1, 1]) for (const sz of [-1, 1]) mb.box(sx * (w / 2 - 0.06) - 0.025, 0, sz * (d / 2 - 0.06) - 0.025, sx * (w / 2 - 0.06) + 0.025, h - 0.05, sz * (d / 2 - 0.06) + 0.025, { s: 1, t: [0.45, 0.45, 0.47], ao0: 0.6 }); }); this.collide(x, z, face, w, d); }
  bench(x, z, face, w = 1.8) { this.with('metal', x, z, face, (mb) => { mb.box(-w / 2, 0.42, -0.2, w / 2, 0.47, 0.2, { s: 1, t: [0.35, 0.37, 0.4] }); mb.box(-w / 2, 0.47, -0.22, w / 2, 0.85, -0.18, { s: 1, t: [0.35, 0.37, 0.4] }); for (const sx of [-1, 1]) mb.box(sx * (w / 2 - 0.08) - 0.02, 0, -0.15, sx * (w / 2 - 0.08) + 0.02, 0.42, 0.15, { s: 1, t: [0.25, 0.25, 0.27], ao0: 0.6 }); }); this.collide(x, z, face, w, 0.45); }
  shelf(x, z, face, o = {}) {
    const w = o.w || 2, d = o.d || 0.55, h = o.h || 2.2, n = o.n || 4, R = this.R;
    this.with('metal', x, z, face, (mb) => {
      for (const sx of [-1, 1]) for (const sz of [-1, 1]) mb.box(sx * (w / 2 - 0.03) - 0.025, 0, sz * (d / 2 - 0.03) - 0.025, sx * (w / 2 - 0.03) + 0.025, h, sz * (d / 2 - 0.03) + 0.025, { s: 1, t: [0.3, 0.33, 0.37], ao0: 0.6 });
      for (let i = 0; i < n; i++) {
        const y = 0.12 + (i * (h - 0.2)) / (n - 1);
        mb.box(-w / 2, y, -d / 2, w / 2, y + 0.035, d / 2, { s: 1, t: [0.42, 0.44, 0.47] });
        if (o.empty) continue;
        let px = -w / 2 + 0.1;
        while (px < w / 2 - 0.3) { const bw = 0.2 + R() * 0.3, bh = 0.15 + R() * 0.3; if (R() > 0.28) mb.box(px, y + 0.035, -d / 2 + 0.06, px + bw, y + 0.035 + bh, d / 2 - 0.06, { s: 1.2, t: o.t || [0.55 + R() * 0.4, 0.5 + R() * 0.3, 0.4 + R() * 0.2], ao0: 0.7 }); px += bw + 0.06; }
      }
    });
    this.collide(x, z, face, w, d, { occlude: o.occlude });
  }
  crate(x, z, o = {}) {
    const s = o.s || 0.9, y = o.y ?? this.y(x, z), R = this.R, f = ['n', 'e', 's', 'w'][(R() * 4) | 0];
    this.with('wood', x, z, f, (mb) => { mb.box(-s / 2, 0, -s / 2, s / 2, s, s / 2, { s: 1, t: o.t || [0.75 + R() * 0.2, 0.65 + R() * 0.2, 0.5], ao0: 0.65 }); for (const k of [-1, 1]) { mb.box(-s / 2 - 0.01, 0.06, k * (s / 2 - 0.05) - 0.025, s / 2 + 0.01, s - 0.06, k * (s / 2 - 0.05) + 0.025, { s: 1, t: [0.55, 0.45, 0.35] }); } }, y);
    if (!o.nocol) this.collide(x, z, 's', s, s, { occlude: !!o.occlude });
  }
  stack(x, z, o = {}) { const n = o.n || 2; for (let i = 0; i < n; i++) this.crate(x + (i ? 0.05 : 0), z, { s: 0.9 - i * 0.05, y: this.y(x, z) + i * 0.88, nocol: i > 0, ...o }); }
  barrel(x, z, o = {}) { this.with(o.key || 'rust', x, z, 's', (mb) => { mb.cyl(0, 0, 0, 0.3, 0.95, 10, { s: 1.5, t: o.t || [0.7, 0.75, 0.8], ao0: 0.6 }); mb.cyl(0, 0.45, 0, 0.31, 0.04, 10, { s: 1, t: [0.5, 0.5, 0.5] }); }); this.collide(x, z, 's', 0.6, 0.6); }
  pillar(x, z, s = 0.8, o = {}) { const a = this.g.areas[this.g.areaAt(x, z)], y = this.y(x, z); this.with(o.key || 'conc', x, z, 's', (mb) => { mb.box(-s / 2, 0, -s / 2, s / 2, a.h, s / 2, { s: 2, t: o.t || [0.9, 0.9, 0.9], ao0: 0.55, ao1: 0.75 }); mb.box(-s / 2 - 0.05, 0, -s / 2 - 0.05, s / 2 + 0.05, 0.2, s / 2 + 0.05, { s: 2, t: [0.7, 0.7, 0.7] }); }, y); this.collide(x, z, 's', s, s, { occlude: true }); }
  locker(x, z, face, n = 3, o = {}) {
    const w = 0.5, R = this.R;
    this.with('metal', x, z, face, (mb) => {
      for (let i = 0; i < n; i++) {
        const lx = (i - (n - 1) / 2) * w, tt = o.t || [0.38 + R() * 0.08, 0.5 + R() * 0.05, 0.5 + R() * 0.1];
        mb.box(lx - w / 2, 0, -0.25, lx + w / 2 - 0.01, 1.9, 0.25, { s: 1, t: tt, ao0: 0.65 });
        mb.box(lx - w / 2 + 0.05, 1.5, 0.25, lx + w / 2 - 0.06, 1.75, 0.255, { s: 1, t: [0.1, 0.1, 0.11] });
        mb.box(lx + w / 2 - 0.1, 1.0, 0.25, lx + w / 2 - 0.07, 1.2, 0.27, { s: 1, t: [0.75, 0.75, 0.78] });
      }
    });
    this.collide(x, z, face, w * n, 0.5, { occlude: true });
  }
  // enclosure the player can hide in. front leaf is dynamic (swings open when entered/searched). returns the hide spot
  hide(id, kind, x, z, face, o = {}) {
    const w = o.w || 0.95, d = o.d || 0.75, h = o.h || 1.95, key = o.key || 'metal', t = o.t || [0.32, 0.38, 0.4];
    this.with(key, x, z, face, (mb) => {
      const T = 0.05;
      mb.box(-w / 2, 0, -d / 2, w / 2, h, -d / 2 + T, { s: 1, t, ao0: 0.6 });
      mb.box(-w / 2, 0, -d / 2, -w / 2 + T, h, d / 2, { s: 1, t, ao0: 0.6 });
      mb.box(w / 2 - T, 0, -d / 2, w / 2, h, d / 2, { s: 1, t, ao0: 0.6 });
      mb.box(-w / 2, h - T, -d / 2, w / 2, h, d / 2, { s: 1, t, ao0: 0.9 });
      mb.box(-w / 2, 0, -d / 2, w / 2, T, d / 2, { s: 1, t: [0.2, 0.2, 0.2] });
    });
    const col = this.collide(x, z, face, w, d, { occlude: true, id });
    // dynamic door leaf, hinged on the local -x edge, centred at the front plane
    const mb = new MeshBuilder();
    mb.box(0, 0, -0.02, w, h, 0.02, { s: 1, t, ao0: 0.7 });
    for (let i = 0; i < 6; i++) mb.box(w * 0.18, h * 0.62 + i * 0.045, 0.02, w * 0.82, h * 0.62 + i * 0.045 + 0.02, 0.03, { s: 1, t: [0.04, 0.04, 0.05] });
    mb.box(w * 0.8, h * 0.5, 0.02, w * 0.86, h * 0.56, 0.05, { s: 1, t: [0.7, 0.7, 0.72] });
    const [fx, fz] = this.at(x, z, face, 0, d / 2), [hx, hz] = this.at(x, z, face, -w / 2, d / 2), dv = DIRV[face];
    const spot = {
      id, kind, x, z, face, w, d, h, rot0: FACE[face], ang: 0, target: 0, mesh: this.w.R.createMesh(mb.finalize()), mat: this.w.mats[key], fx, fz, hx, hz, y: this.y(x, z), col,
      inside: [x + dv[0] * 0.02, z + dv[1] * 0.02], front: [x + dv[0] * (d / 2 + 0.7), z + dv[1] * (d / 2 + 0.7)], yaw: Math.atan2(dv[0], -dv[1]), occupied: false, checked: 0, eye: o.eye ?? 1.5,
    };
    this.hides.push(spot); return spot;
  }
  console(x, z, face, o = {}) {
    const w = o.w || 1.6, n = o.screens || 2;
    this.with('metal', x, z, face, (mb) => {
      mb.box(-w / 2, 0, -0.35, w / 2, 0.95, 0.35, { s: 1, t: [0.28, 0.3, 0.33], ao0: 0.6 });
      mb.box(-w / 2, 0.95, -0.35, w / 2, 1.5, -0.2, { s: 1, t: [0.22, 0.24, 0.27] });
      mb.box(-w / 2 + 0.1, 0.95, 0.0, w / 2 - 0.1, 0.985, 0.3, { s: 1, t: [0.12, 0.13, 0.15] });
    });
    this.with('emis:screen', x, z, face, (mb) => {
      const sw = (w - 0.2) / n;
      for (let i = 0; i < n; i++) { const x0 = -w / 2 + 0.1 + i * sw + 0.04, x1 = -w / 2 + 0.1 + (i + 1) * sw - 0.04; mb.q([x0, 1.02, -0.195, x1, 1.02, -0.195, x1, 1.42, -0.195, x0, 1.42, -0.195], 0, 0, 1, [0, 0, 1, 0, 1, 1, 0, 1], o.tint || [1, 1, 1]); }
    });
    this.collide(x, z, face, w, 0.7);
  }
  pipe(x0, y0, z0, x1, y1, z1, r = 0.07, o = {}) { const ch = this.getChunk((x0 + x1) / 2, (z0 + z1) / 2); ch.mb(o.key || 'rust').tube(x0, y0, z0, x1, y1, z1, r, 8, { s: 1, t: o.t || [0.75, 0.75, 0.78], ao0: 0.8 }); }
  // ceiling pipe bundle along x or z
  pipes(x0, z0, x1, z1, y, n = 2, o = {}) { const alongX = Math.abs(x1 - x0) > Math.abs(z1 - z0); for (let i = 0; i < n; i++) { const off = (i - (n - 1) / 2) * 0.2; if (alongX) this.pipe(x0, y + (i & 1) * 0.12, z0 + off, x1, y + (i & 1) * 0.12, z1 + off, 0.06 + (i % 2) * 0.03, o); else this.pipe(x0 + off, y + (i & 1) * 0.12, z0, x1 + off, y + (i & 1) * 0.12, z1, 0.06 + (i % 2) * 0.03, o); } }
  body(x, z, rot, o = {}) { // covered / bloodied body on the floor (cloth + shoes)
    const y = this.y(x, z), q = [0, 1, 2, 3][rot & 3], f = ['s', 'e', 'n', 'w'][q];
    this.with('wall', x, z, f, (mb) => { mb.box(-0.22, 0, -0.85, 0.22, 0.2, 0.8, { s: 1, t: o.t || [0.55, 0.52, 0.48], ao0: 0.6 }); mb.sphere(0, 0.14, -0.95, 0.14, 7, 4, { s: 1, t: [0.5, 0.4, 0.35] }); }, y);
    this.with('skin', x, z, f, (mb) => { mb.box(-0.14, 0, 0.78, -0.04, 0.09, 1.0, { s: 1, t: [0.15, 0.1, 0.09] }); mb.box(0.04, 0, 0.78, 0.14, 0.09, 1.0, { s: 1, t: [0.15, 0.1, 0.09] }); }, y);
  }
  decalMb(x, z) { return this.getChunk(x, z).mb('decal'); }
  wallDecal(name, x, y, z, n, w, h, o) { wallDecal(this.decalMb(x - (n === '+x' ? -0.2 : n === '-x' ? 0.2 : 0), z - (n === '+z' ? -0.2 : n === '-z' ? 0.2 : 0)), name, x, y, z, n, w, h, o); }
  floorDecal(name, x, z, w, h, rot = 0, o) { floorDecal(this.decalMb(x, z), name, x, this.y(x, z), z, w, h, rot, o); }
  // dynamic emissive / mesh objects drawn every frame by the game
  addDyn(d) { this.dyn.push(d); return d; }
}
