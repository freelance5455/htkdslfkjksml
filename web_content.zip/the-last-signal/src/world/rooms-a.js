// Surface courtyard, entrance ramp, lobby, security checkpoint, guard room.
import { jeep, fence, gatehouse, rubble, jersey, vending, xray, arch, cot } from './kit.js';

export function roomsSurface(C) {
  const P = C.P, fy = C.fy;
  // ---------------- courtyard (x4..21, z56..69) ----------------
  jeep(P, 11.5, 58.6, 'e');
  fence(P, 16, 56.0, 16, 60.2); fence(P, 16, 65.8, 16, 70.0);
  gatehouse(P, 18.6, 58.3, 'w');
  jersey(P, 12.8, 67.9, 's'); jersey(P, 10.2, 67.2, 'e');
  for (const [x, z] of [[5.2, 57.3], [5.9, 57.0], [20.3, 67.7], [20.9, 66.8]]) P.barrel(x, z);
  P.crate(19.4, 68.4); P.crate(5.0, 68.6, { s: 0.8 }); P.stack(6.3, 68.4);
  rubble(P, 14.4, 66.3, 8, 1.1); rubble(P, 6.3, 65.8, 6, 0.9);
  P.wallDecal('staff', 22, fy(21, 62.5) + 4.6, 62.5, '-x', 2.4, 1.2);
  P.wallDecal('hazard', 22, fy(21, 62.5) + 3.85, 62.5, '-x', 4, 0.3);
  P.floorDecal('splat1', 19.4, 62.4, 2.2, 2.2, 0.4); P.floorDecal('splat2', 20.4, 64.4, 1.4, 1.4, 1.9, { a: 0.8 });
  P.floorDecal('stain', 9, 63, 6, 6, 0.3, { a: 0.5 });
  C.pick('b_court', 'battery', 19.4, 68.4, 0.92);
  C.act('n_brief', 'note', 11.5, 60.4, 1.1, 1.8, 'Dashboard note', { note: 'brief', first: true });
  C.wp('surface', 8, 63);

  // ---------------- entrance ramp (x23..40, z60..65) ----------------
  const ry = (x) => -4 * (x - 23) / 18;
  P.pipe(24, ry(24) + 3.35, 60.14, 40.5, ry(40.5) + 3.35, 60.14, 0.09);
  P.pipe(24, ry(24) + 3.0, 60.14, 40.5, ry(40.5) + 3.0, 60.14, 0.06);
  P.pipe(24, ry(24) + 2.9, 65.86, 40.5, ry(40.5) + 2.9, 65.86, 0.05, { key: 'metal' });
  rubble(P, 37.8, 61.0, 6, 0.7);
  P.floorDecal('splat2', 34, 63.2, 1.8, 1.8, 2.2, { a: 0.85 }); P.floorDecal('splat1', 38, 62.4, 1.2, 1.2, 0.3, { a: 0.8 });
  P.floorDecal('hazard', 32, 64.7, 12, 0.45, 0, { a: 0.9 });
  C.zone('lobbyEntry', 43, 59, 46, 66);

  // ---------------- lobby (x41..56, z53..70, floor -4) ----------------
  const L = (x, z) => fy(x, z);
  P.desk(54.3, 61, 'w', { w: 5.5, d: 0.9, screen: [0.7, 0.9, 1] });
  P.chair(55.5, 59.5, 'w'); P.chair(55.5, 62.5, 'e');
  P.bench(43.3, 55.4, 'e'); P.bench(43.3, 68.0, 'e');
  for (const [x, z] of [[46, 57], [46, 66], [52, 57], [52, 66]]) P.pillar(x, z, 0.8);
  P.barrel(42.5, 53.9, { key: 'rust' }); P.barrel(55.4, 53.9);
  P.with('wall', 49, 68.3, 'n', (mb) => { mb.box(-0.3, 0, -0.3, 0.3, 0.55, 0.3, { s: 1, t: [0.5, 0.4, 0.35] }); mb.cyl(0, 0.55, 0, 0.04, 0.7, 5, { s: 1, t: [0.25, 0.2, 0.1] }); }); P.collide(49, 68.3, 's', 0.6, 0.6);
  P.body(50.2, 63.2, 1, { t: [0.5, 0.5, 0.46] });
  P.wallDecal('poster', 52, L(52, 54) + 1.8, 53, '+z', 1.1, 1.5);
  P.wallDecal('staff', 48, L(48, 54) + 3.3, 53, '+z', 2.0, 1.0);
  P.wallDecal('drips', 50.4, L(50, 54) + 1.6, 53, '+z', 1.0, 2.0, { a: 0.8 });
  P.wallDecal('poster', 57, L(56, 56) + 1.8, 56.5, '-x', 1.1, 1.5);
  P.wallDecal('exit', 41, L(41, 58) + 3.4, 58.2, '+x', 1.6, 0.8);
  P.floorDecal('splat1', 47.6, 54.6, 2.4, 2.4, 0.9); P.floorDecal('splat2', 50.5, 63.4, 2.0, 2.0, 2.7);
  P.floorDecal('hands', 46.6, 57.6, 2.2, 2.2, 1.2, { a: 0.7 });
  P.floorDecal('stain', 52, 66, 7, 7, 0, { a: 0.5 });
  P.hide('h_lobby1', 'cabinet', 56.6, 68.6, 'w', { w: 1.0, d: 0.75, key: 'metal', t: [0.3, 0.36, 0.34] });
  P.hide('h_lobby2', 'cabinet', 41.45, 69.1, 'e', { w: 1.0, d: 0.75, key: 'metal', t: [0.34, 0.33, 0.3] });
  C.pick('b_lobby', 'battery', 54.4, 60.0, 0.82);
  C.act('n_closure', 'note', 52, 53.6, 1.6, 1.9, 'Notice board', { note: 'closure' });
  C.wp('front', 49, 62); C.wp('front', 44, 56.5); C.wp('front', 53, 67);

  // ---------------- security checkpoint (x41..56, z38..51) ----------------
  P.desk(43.3, 46.1, 'n', { w: 3.6, d: 0.9, screen: [0.9, 0.8, 0.6] }); P.desk(53.2, 46.1, 'n', { w: 3.6, d: 0.9 });
  P.chair(43.2, 47.4, 's'); P.chair(53.4, 47.4, 's');
  arch(P, 48, 46.1, 's', 2.4);
  xray(P, 53.4, 41.2, 'w');
  P.locker(41.3, 42.2, 'e', 4);
  P.hide('h_ck1', 'locker', 41.38, 44.9, 'e', { w: 0.6, d: 0.6, key: 'metal', t: [0.3, 0.36, 0.4] });
  P.hide('h_ck2', 'cabinet', 56.6, 49.6, 'w', { w: 1.0, d: 0.75, key: 'metal', t: [0.34, 0.3, 0.3] });
  vending(P, 44.5, 39.2, 's');
  jersey(P, 45.8, 40.6, 'e');
  P.wallDecal('lab', 48, L(48, 39) + 3.1, 38, '+z', 2.4, 0.8);
  P.wallDecal('hazard', 48, L(48, 39) + 0.1, 38, '+z', 3.0, 0.2, { a: 0.9 });
  P.wallDecal('poster', 57, L(56, 50) + 1.8, 50.2, '-x', 1.1, 1.5);
  P.wallDecal('claws', 41, L(41, 48) + 1.5, 48.6, '+x', 1.6, 1.6, { a: 0.9 });
  P.wallDecal('drips', 52, L(52, 50) + 1.6, 52.0, '-z', 1.0, 2.0, { a: 0.7 });
  P.floorDecal('hazard', 48, 47.1, 5.2, 0.55, 0, { a: 0.9 });
  for (const [x, z, s, r] of [[48.2, 39.6, 1.8, 0.2], [47.6, 42.2, 1.2, 1.2], [49, 44.5, 1.6, 2.4], [48.4, 49.3, 1.4, 0.7]]) P.floorDecal(r > 1.5 ? 'splat2' : 'splat1', x, z, s, s, r, { a: 0.9 });
  P.floorDecal('stain', 50, 43, 8, 8, 1, { a: 0.45 });

  C.act('n_shiftlog', 'note', 43.4, 46.9, 1.0, 1.9, 'Security log', { note: 'shiftlog' });
  C.wp('front', 49, 44); C.wp('front', 45, 49); C.wp('front', 53, 40);

  // ---------------- guard room (x58..66, z40..48) ----------------
  P.desk(61.6, 40.8, 's', { w: 2.4, d: 0.8, screen: [1, 0.6, 0.5] });
  P.monitor(61.6, 40.8, 's', 0.55, -0.1, 0.76, [0.5, 0.9, 1]);
  P.chair(61.6, 42.1, 'n');
  cot(P, 59.3, 46.5, 'n');
  P.locker(66.72, 44.0, 'w', 5);
  P.hide('h_guard1', 'locker', 66.68, 41.9, 'w', { w: 0.6, d: 0.6, key: 'metal', t: [0.36, 0.4, 0.3] });
  P.hide('h_guard2', 'locker', 66.68, 46.7, 'w', { w: 0.6, d: 0.6, key: 'metal', t: [0.3, 0.34, 0.4] });
  P.table(63.2, 46.6, 's', 1.1, 0.7);
  P.wallDecal('staff', 58, L(59, 41.5) + 1.7, 41.6, '+x', 1.4, 0.7);
  P.wallDecal('claws', 63.2, L(63, 48) + 1.4, 49, '-z', 1.6, 1.6, { a: 0.9 });
  P.wallDecal('hands', 67, L(65, 42) + 1.2, 47.0, '-x', 1.2, 1.2, { a: 0.8 });
  P.floorDecal('splat1', 60.3, 44.2, 2.2, 2.2, 0.5); P.floorDecal('hands', 62.6, 43.4, 1.8, 1.8, 2.0, { a: 0.8 });
  P.pipe(58.1, 3.0 - 4, 40.2, 66.8, 3.0 - 4, 40.2, 0.05, { key: 'metal' });
  C.pick('m_guard', 'medkit', 59.3, 47.9, 0.12);
  C.pick('b_guard', 'battery', 63.2, 46.6, 0.78);
  C.act('n_guardnote', 'note', 58.4, 41.6, 1.6, 1.8, 'Pinned note', { note: 'guardnote' });
  C.act('locker4', 'keypad', 66.1, 44.0, 1.3, 1.7, 'Guard locker 4', { code: 'locker' });
  C.wp('front', 62, 44);
}
