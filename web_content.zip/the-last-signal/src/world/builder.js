// Turns the grid into renderable chunks: floors, ceilings, walls (merged runs), ramps, door frames.
// Material keys: 'wall','conc',... = lit; 'decal' = alpha-blended decal atlas; 'emis:<name>' = unlit emissive.
import { MeshBuilder } from '../engine/mesh.js';

export const TILE = 12;
const TS = { tile: 2, floor: 2, wall: 2, conc: 2, metal: 2, rock: 3, dirt: 3, grate: 1, wood: 1, rust: 1.5 };
const SV = { wall: 4 };
const CEIL_DIM = 0.62;

export class Chunk {
  constructor(ai, tx, tz) { this.ai = ai; this.tx = tx; this.tz = tz; this.mbs = {}; this.draws = []; this.cands = []; this.bounds = [1e9, 1e9, 1e9, -1e9, -1e9, -1e9]; this.cx = 0; this.cz = 0; }
  mb(key) { return this.mbs[key] || (this.mbs[key] = new MeshBuilder()); }
}

export function buildChunks(grid) {
  const map = new Map(), list = [];
  const get = (ai, tx, tz) => {
    const k = (ai * 64 + tz) * 64 + tx;
    let c = map.get(k);
    if (!c) { c = new Chunk(ai, tx, tz); map.set(k, c); list.push(c); }
    return c;
  };
  const W = grid.W;
  grid.areas.forEach((a, ai) => {
    for (let tz = Math.floor(a.z0 / TILE); tz <= Math.floor((a.z1 - 1) / TILE); tz++) for (let tx = Math.floor(a.x0 / TILE); tx <= Math.floor((a.x1 - 1) / TILE); tx++) {
      const x0 = Math.max(a.x0, tx * TILE), x1 = Math.min(a.x1, (tx + 1) * TILE), z0 = Math.max(a.z0, tz * TILE), z1 = Math.min(a.z1, (tz + 1) * TILE);
      const ch = get(ai, tx, tz);
      floorCeil(grid, ch, a, x0, z0, x1, z1);
      walls(grid, ch, a, x0, z0, x1, z1);
    }
  });
  grid.doors.forEach((d) => doorFrame(grid, d, get));
  for (const c of list) { c.cx = (c.bounds[0] + c.bounds[3]) / 2; c.cz = (c.bounds[2] + c.bounds[5]) / 2; }
  return list;
}

function floorCeil(grid, ch, a, x0, z0, x1, z1) {
  const fm = ch.mb(a.floor), s = TS[a.floor] || 2;
  const yAt = (x, z) => grid.areaY(a, x, z);
  if (!a.slope) fm.flat(x0, z0, x1, z1, a.y, true, { s, t: a.ftint });
  else fm.slope(x0, z0, x1, z1, yAt(x0, z0), yAt(x1, z0), yAt(x1, z1), yAt(x0, z1), true, { s, t: a.ftint });
  if (a.outdoor) return;
  const cm = ch.mb(a.ceil), cs = TS[a.ceil] || 2, ct = [a.tint[0] * CEIL_DIM, a.tint[1] * CEIL_DIM, a.tint[2] * CEIL_DIM];
  if (!a.slope) cm.flat(x0, z0, x1, z1, a.y + a.h, false, { s: cs, t: ct });
  else cm.slope(x0, z0, x1, z1, yAt(x0, z0) + a.h, yAt(x1, z0) + a.h, yAt(x1, z1) + a.h, yAt(x0, z1) + a.h, false, { s: cs, t: ct });
}

function walls(grid, ch, a, x0, z0, x1, z1) {
  const W = grid.W, mb = ch.mb(a.wall), s = TS[a.wall] || 2, sv = SV[a.wall] || s;
  const sol = (x, z) => !grid.inb(x, z) || grid.solid[z * W + x] === 1;
  const emit = (xa, za, xb, zb, nx, nz) => {
    if (!a.slope) {
      const y = a.y;
      mb.wall(xa, za, xb, zb, y, y + a.h, nx, nz, { s, sv, t: a.tint, vo: -y * (1 / sv) });
    } else {
      const along = Math.abs(xb - xa) > Math.abs(zb - za) ? 'x' : 'z', n = Math.round(Math.abs(xb - xa) + Math.abs(zb - za));
      for (let k = 0; k < n; k++) {
        const ax = along === 'x' ? xa + k : xa, az = along === 'z' ? za + k : za, bx = along === 'x' ? ax + 1 : xa, bz = along === 'z' ? az + 1 : za;
        const ya = grid.areaY(a, ax, az), yb = grid.areaY(a, bx, bz);
        mb.wallSlanted(ax, az, bx, bz, ya, ya + a.h, yb, yb + a.h, nx, nz, { s, sv, t: a.tint });
      }
    }
  };
  for (let z = z0; z < z1; z++) for (let x = x0; x < x1;) { // north walls (face +z)
    if (sol(x, z - 1)) { let e = x; while (e < x1 && sol(e, z - 1)) e++; emit(x, z, e, z, 0, 1); x = e; } else x++;
  }
  for (let z = z0; z < z1; z++) for (let x = x0; x < x1;) { // south walls (face -z)
    if (sol(x, z + 1)) { let e = x; while (e < x1 && sol(e, z + 1)) e++; emit(x, z + 1, e, z + 1, 0, -1); x = e; } else x++;
  }
  for (let x = x0; x < x1; x++) for (let z = z0; z < z1;) { // west walls (face +x)
    if (sol(x - 1, z)) { let e = z; while (e < z1 && sol(x - 1, e)) e++; emit(x, z, x, e, 1, 0); z = e; } else z++;
  }
  for (let x = x0; x < x1; x++) for (let z = z0; z < z1;) { // east walls (face -x)
    if (sol(x + 1, z)) { let e = z; while (e < z1 && sol(x + 1, e)) e++; emit(x + 1, z, x + 1, e, -1, 0); z = e; } else z++;
  }
}

// floor/ceiling/jambs/headers + trim around a doorway. The moving leaf is a separate dynamic mesh (see doors.js).
function doorFrame(grid, d, get) {
  const W = grid.W, ai0 = grid.area[d.cells[0]], a0 = grid.areas[ai0];
  const ch = get(ai0, Math.floor(d.cx / TILE), Math.floor(d.cz / TILE));
  const y = grid.areaY(a0, d.cx, d.cz), hg = d.hgt;
  const fm = ch.mb(a0.floor), mm = ch.mb('metal');
  const sol = (x, z) => !grid.inb(x, z) || grid.solid[z * W + x] === 1;
  const x0 = d.axis === 'x' ? d.x : d.x, x1 = d.axis === 'x' ? d.x + d.w : d.x + 1, z0 = d.axis === 'z' ? d.z : d.z, z1 = d.axis === 'z' ? d.z + d.w : d.z + 1;
  fm.flat(x0, z0, x1, z1, y, true, { s: 2, t: a0.ftint });
  ch.mb('conc').flat(x0, z0, x1, z1, y + hg, false, { s: 2, t: [0.5, 0.5, 0.5] });
  // lateral jambs (faces at the two ends of the opening) from floor to lintel
  const jt = [0.75, 0.75, 0.75];
  if (d.axis === 'x') {
    if (sol(x0 - 1, z0)) ch.mb('conc').wall(x0, z0, x0, z1, y, y + hg, 1, 0, { s: 2, t: jt });
    if (sol(x1, z0)) ch.mb('conc').wall(x1, z0, x1, z1, y, y + hg, -1, 0, { s: 2, t: jt });
  } else {
    if (sol(x0, z0 - 1)) ch.mb('conc').wall(x0, z0, x1, z0, y, y + hg, 0, 1, { s: 2, t: jt });
    if (sol(x0, z1)) ch.mb('conc').wall(x0, z1, x1, z1, y, y + hg, 0, -1, { s: 2, t: jt });
  }
  // headers: wall above the opening, on both room sides
  for (const side of [-1, 1]) {
    const nx = d.axis === 'z' ? x0 + (side < 0 ? -1 : 1) : x0, nz = d.axis === 'x' ? z0 + (side < 0 ? -1 : 1) : z0;
    const ai = grid.area[nz * W + nx]; if (ai < 0) continue;
    const a = grid.areas[ai], hc = get(ai, Math.floor(nx / TILE), Math.floor(nz / TILE)), top = grid.areaY(a, nx + 0.5, nz + 0.5) + a.h;
    if (top <= y + hg + 0.01) continue;
    const m = hc.mb(a.wall), s = TS[a.wall] || 2, sv = SV[a.wall] || s;
    if (d.axis === 'x') { const zz = side < 0 ? z0 : z1; m.wall(x0, zz, x1, zz, y + hg, top, 0, side < 0 ? -1 : 1, { s, sv, t: a.tint, ao0: 0.8, ao1: 0.8, vo: -y / sv }); }
    else { const xx = side < 0 ? x0 : x1; m.wall(xx, z0, xx, z1, y + hg, top, side < 0 ? -1 : 1, 0, { s, sv, t: a.tint, ao0: 0.8, ao1: 0.8, vo: -y / sv }); }
    // trim frame (posts + lintel) on this side
    const fr = 0.13, o = { s: 1, t: [0.55, 0.57, 0.6], ao: 0.9 };
    const off = side < 0 ? -0.02 : 0.02;
    if (d.axis === 'x') {
      const zz = side < 0 ? z0 - 0.06 + off : z1 + 0.06 + off;
      hc.mb('metal').box(x0 - fr, y, Math.min(zz, zz) - 0.06, x0, y + hg + fr, zz + 0.06, o);
      hc.mb('metal').box(x1, y, zz - 0.06, x1 + fr, y + hg + fr, zz + 0.06, o);
      hc.mb('metal').box(x0, y + hg, zz - 0.06, x1, y + hg + fr, zz + 0.06, o);
    } else {
      const xx = side < 0 ? x0 - 0.06 + off : x1 + 0.06 + off;
      hc.mb('metal').box(xx - 0.06, y, z0 - fr, xx + 0.06, y + hg + fr, z0, o);
      hc.mb('metal').box(xx - 0.06, y, z1, xx + 0.06, y + hg + fr, z1 + fr, o);
      hc.mb('metal').box(xx - 0.06, y + hg, z0, xx + 0.06, y + hg + fr, z1, o);
    }
  }
}

// upload all chunk meshes; mats maps material key -> renderer material {tex,...}
export function uploadChunks(chunks, R, mats) {
  for (const c of chunks) {
    c.draws.length = 0;
    for (const [key, mb] of Object.entries(c.mbs)) {
      if (mb.empty) continue;
      const kind = key === 'decal' ? 'decal' : key.startsWith('emis:') ? 'emis' : 'lit';
      const mat = mats[key];
      if (!mat) throw new Error('missing material ' + key);
      c.draws.push({ mesh: R.createMesh(mb.finalize()), mat, kind });
      for (let i = 0; i < 3; i++) { c.bounds[i] = Math.min(c.bounds[i], mb.bb[i]); c.bounds[i + 3] = Math.max(c.bounds[i + 3], mb.bb[i + 3]); }
    }
    c.mbs = null;
    c.cx = (c.bounds[0] + c.bounds[3]) / 2; c.cz = (c.bounds[2] + c.bounds[5]) / 2;
  }
}
