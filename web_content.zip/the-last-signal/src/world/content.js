// Level dressing + gameplay object placement. populate() is called by World.build before chunk upload.
import { Props } from './props.js';
import { MeshBuilder } from '../engine/mesh.js';
import { roomsSurface } from './rooms-a.js';
import { roomsLab } from './rooms-b.js';
import { roomsDeep } from './rooms-c.js';

export function populate(world, getChunk) {
  const P = new Props(world, getChunk);
  const g = world.grid;
  const C = {
    P, world, hides: P.hides, pickups: [], interacts: [], zones: [], patrol: {}, dyn: P.dyn, fx: [],
    fy: (x, z) => g.floorY(x, z),
    // pickup resting at height h above the floor
    pick(id, type, x, z, h = 0.05, o = {}) { const p = { id, type, x, z, y: g.floorY(x, z) + h, taken: false, ...o }; C.pickups.push(p); return p; },
    // interactable (note boards, panels, keypads, levers ...) positioned at height h above the floor
    act(id, kind, x, z, h, r, label, o = {}) { const a = { id, kind, x, z, y: g.floorY(x, z) + h, r, label, ...o }; C.interacts.push(a); return a; },
    zone(id, x0, z0, x1, z1) { C.zones.push({ id, x0, z0, x1, z1 }); },
    wp(zone, x, z) { (C.patrol[zone] = C.patrol[zone] || []).push([x, z]); },
    fxEmit(kind, x, y, z, o = {}) { C.fx.push({ kind, x, y, z, ...o }); },
    // movable mesh object drawn every frame: parts = { materialKey: (mb) => void } in object-local space
    dynObj(id, parts, o = {}) {
      const list = [];
      for (const [key, fn] of Object.entries(parts)) { const mb = new MeshBuilder(); fn(mb); if (!mb.empty) list.push({ mesh: world.R.createMesh(mb.finalize()), mat: world.mats[key], kind: key.startsWith('emis:') ? 'emis' : 'lit' }); }
      const d = { id, parts: list, x: 0, y: 0, z: 0, rx: 0, ry: 0, rz: 0, sx: 1, sy: 1, sz: 1, visible: true, tint: null, ai: -1, ...o };
      if (d.ai < 0) d.ai = g.areaAt(d.x, d.z);
      C.objs[id] = d; return d;
    },
    objs: {}, lamps: [],
  };
  world.content = C;
  roomsSurface(C); roomsLab(C); roomsDeep(C);
  for (const h of P.hides) world.hideSpots = P.hides;
}
