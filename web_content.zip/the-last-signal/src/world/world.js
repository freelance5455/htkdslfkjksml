// Runtime world: owns the grid, chunk meshes, light circuits/flicker, door animation, and the opaque/decal draw passes.
import { Grid } from './grid.js';
import { LIGHTS } from './layout.js';
import { buildChunks, uploadChunks, TILE } from './builder.js';
import { MeshBuilder } from '../engine/mesh.js';
import { m4, aabbVisible, damp } from '../engine/math.js';
import { hash2 } from '../engine/noise.js';

export function flick(kind, t, seed) {
  switch (kind) {
    case 'flicker': { const h = hash2(Math.floor(t * 9 + seed * 5), seed | 0); return (h < 0.1 ? 0.04 : h < 0.24 ? 0.45 : 1) * (0.88 + 0.12 * Math.sin(t * 3 + seed)); }
    case 'pulse': return 0.7 + 0.3 * Math.sin(t * 1.9 + seed * 3);
    case 'dead': return 0;
    default: return 1;
  }
}

export class World {
  constructor() {
    this.grid = new Grid();
    this.circ = { always: 1, lobby: 1, ck: 1, lab: 0, gen: 0, emerg: 0 };   // targets 0..1
    this.circCur = { ...this.circ };
    this.lights = LIGHTS.map((l, i) => {
      const ai = this.grid.areaIndex[l.area], a = this.grid.areas[ai];
      return { ...l, id: i, ai, wy: this.grid.areaY(a, l.x, l.z) + l.y, cur: 0, seed: i * 13.7 + 1.3, mult: 1 };
    });
    this.areaCirc = this.grid.areas.map((a, i) => { const l = this.lights.find((q) => q.ai === i && q.circuit !== 'always'); return l ? l.circuit : 'always'; });
    this.time = 0; this.chunks = []; this.drawn = 0; this.onDoor = null; this.extraDraw = []; this.content = null;
    this.links = this.grid.areas.map(() => new Map());
    this._buildLinks();
    this.sel = new Array(8); this.lp = new Float32Array(32); this.lc = new Float32Array(32);
    this.model = m4.create();
  }
  _buildLinks() {
    const g = this.grid, W = g.W;
    for (let z = 0; z < g.H; z++) for (let x = 0; x < g.W; x++) {
      const k = z * W + x; if (g.solid[k]) continue;
      for (const [dx, dz] of [[1, 0], [0, 1]]) {
        const nx = x + dx, nz = z + dz; if (nx >= g.W || nz >= g.H) continue;
        const n = nz * W + nx; if (g.solid[n]) continue;
        const a = g.area[k], b = g.area[n]; if (a < 0 || b < 0 || a === b) continue;
        const di = g.doorAt[k] >= 0 ? g.doorAt[k] : g.doorAt[n];
        for (const [p, q] of [[a, b], [b, a]]) {
          const cur = this.links[p].get(q) || { open: false, doors: new Set() };
          if (di >= 0) cur.doors.add(di); else cur.open = true;
          this.links[p].set(q, cur);
        }
      }
    }
  }
  // how strongly light from area b reaches area a (0..1)
  linkAmount(a, b) {
    if (a === b) return 1;
    const row = this.links[a]; if (!row) return 0;            // a / b can be -1 for a point outside every area (e.g. a camera for one frame)
    const l = row.get(b); if (!l) return 0;
    if (l.open) return 1;
    let m = 0; for (const di of l.doors) m = Math.max(m, this.grid.doors[di].t);
    return m;
  }
  chunkFor(x, z) {
    const ai = this.grid.areaAt(x, z); if (ai < 0) return null;
    return this.chunkMap.get((ai * 64 + Math.floor(z / TILE)) * 64 + Math.floor(x / TILE)) || null;
  }
  // populate(world, chunkFor) is called before upload so props/decals can add geometry
  build(R, mats, populate) {
    this.R = R; this.mats = mats;
    const chunks = buildChunks(this.grid);
    this.chunkMap = new Map(chunks.map((c) => [(c.ai * 64 + c.tz) * 64 + c.tx, c]));
    const getChunk = (x, z) => { const c = this.chunkFor(x, z); if (!c) throw new Error(`no chunk at ${x},${z}`); return c; };
    this._fixtureHousings(getChunk);
    if (populate) populate(this, getChunk);
    uploadChunks(chunks, R, mats);
    this.chunks = chunks;
    // candidate lights per chunk: same area or linked area, within reach
    for (const c of chunks) {
      c.cands = [];
      this.lights.forEach((l, i) => {
        if (l.ai !== c.ai && !this.links[c.ai].has(l.ai)) return;
        const b = c.bounds, dx = Math.max(b[0] - l.x, 0, l.x - b[3]), dz = Math.max(b[2] - l.z, 0, l.z - b[5]), dy = Math.max(b[1] - l.wy, 0, l.wy - b[4]);
        if (dx * dx + dy * dy + dz * dz < l.r * l.r) c.cands.push(i);
      });
    }
    // dynamic meshes: ceiling fixture glow + door leaves + status lamps
    const fx = new MeshBuilder(); fx.box(-0.55, -0.035, -0.11, 0.55, 0.035, 0.11, {});
    this.fixMesh = R.createMesh(fx.finalize());
    const cube = new MeshBuilder(); cube.box(-0.05, -0.05, -0.05, 0.05, 0.05, 0.05, {});
    this.cubeMesh = R.createMesh(cube.finalize());
    this.fixtures = this.lights.filter((l) => !l.moon && !l.fx).map((l) => {
      const a = this.grid.areas[l.ai], ry = (a.x1 - a.x0) > (a.z1 - a.z0) ? 0 : Math.PI / 2;
      const m = m4.create(); m4.fromTRS(m, l.x, this.grid.areaY(a, l.x, l.z) + a.h - 0.07, l.z, 0, ry, 0, 1, 1, 1);
      return { l, m };
    });
    this.doors = this.grid.doors; this.leaves = this.doors.map((d) => this._leaf(d));
  }
  _fixtureHousings(getChunk) {
    for (const l of this.lights) {
      if (l.moon || l.fx) continue;
      const a = this.grid.areas[l.ai], ch = getChunk(l.x, l.z), y = this.grid.areaY(a, l.x, l.z) + a.h;
      const along = (a.x1 - a.x0) > (a.z1 - a.z0), hx = along ? 0.62 : 0.17, hz = along ? 0.17 : 0.62;
      ch.mb('metal').box(l.x - hx, y - 0.1, l.z - hz, l.x + hx, y, l.z + hz, { s: 1, t: [0.35, 0.36, 0.38], ao: 0.7 });
    }
  }
  _leaf(d) {
    const a = this.grid.areas[this.grid.area[d.cells[0]]], y = this.grid.areaY(a, d.cx, d.cz), w = d.w, h = d.hgt, th = d.kind === 'blast' ? 0.34 : 0.14;
    const mb = new MeshBuilder(), O = { s: 1 };
    if (d.kind === 'shutter') {
      const n = Math.round(h / 0.16);
      for (let i = 0; i < n; i++) mb.box(-w / 2, i * (h / n), -0.06, w / 2, i * (h / n) + h / n - 0.02, 0.06, { s: 1, t: i % 2 ? [0.55, 0.57, 0.6] : [0.62, 0.64, 0.66], ao: 0.85 });
    } else if (d.kind === 'blast') {
      mb.box(-w / 2, 0, -th / 2, w / 2, h, th / 2, { s: 1.5, t: [0.55, 0.58, 0.6] });
      const nb = Math.round(w * 2.5);
      for (let i = 0; i < nb; i++) { const x0 = -w / 2 + (i * w) / nb; mb.box(x0, 0.35, th / 2, x0 + w / nb * 0.5, 0.75, th / 2 + 0.02, { s: 1, t: [0.95, 0.72, 0.1] }); mb.box(x0, h - 0.75, th / 2, x0 + w / nb * 0.5, h - 0.35, th / 2 + 0.02, { s: 1, t: [0.95, 0.72, 0.1] }); }
    } else if (d.kind === 'rack') {
      mb.box(-w / 2, 0, -0.3, w / 2, 2.4, 0.3, { s: 1, t: [0.2, 0.22, 0.25] });
      for (let i = 0; i < 7; i++) mb.box(-w / 2 + 0.08, 0.2 + i * 0.3, 0.3, w / 2 - 0.08, 0.42 + i * 0.3, 0.33, { s: 1, t: [0.1, 0.11, 0.13] });
    } else {
      mb.box(-w / 2, 0, -th / 2, w / 2, h, th / 2, { s: 1.2, t: [0.62, 0.65, 0.68] });
      mb.box(-w / 2 + 0.12, 0.25, th / 2, w / 2 - 0.12, h - 0.25, th / 2 + 0.03, { s: 1.2, t: [0.42, 0.45, 0.48] });
      mb.box(-w / 2 + 0.2, 1.0, th / 2 + 0.03, -w / 2 + 0.6, 1.08, th / 2 + 0.1, { s: 1, t: [0.8, 0.8, 0.82] });
      mb.box(-w / 2 + 0.2, 1.0, -th / 2 - 0.1, -w / 2 + 0.6, 1.08, -th / 2 - 0.03, { s: 1, t: [0.8, 0.8, 0.82] });
    }
    const mat = this.mats.metal;
    const m = m4.create();
    return { mesh: this.R.createMesh(mb.finalize()), mat, y, ry: d.axis === 'x' ? 0 : Math.PI / 2, m, d };
  }

  // power state of a door (true = lock's power circuit is energised)
  doorPowered(d) { return d.lock.type !== 'power' || this.circCur[d.lock.circuit] > 0.5; }
  doorLocked(d) { return d.locked || !this.doorPowered(d); }
  canOpen(d) { return !this.doorLocked(d); }
  setDoor(d, open, silent) {
    const target = open ? 1 : 0;
    if (d.target === target || (d.target === undefined && d.t === target)) { d.target = target; return; }
    d.target = target;
    if (!silent && this.onDoor) this.onDoor(d, open ? 'open' : 'close');
  }
  unlockDoor(d) { d.locked = false; if (this.onDoor) this.onDoor(d, 'unlock'); }

  setCircuit(name, v) { this.circ[name] = v; }
  // ambient colour for an area, dimmed when its power circuit is off
  ambient(ai, out) {
    const a = this.grid.areas[ai], p = 0.3 + 0.7 * Math.min(1, this.circCur[this.areaCirc[ai]] ?? 1);
    out[0] = a.amb[0] * p; out[1] = a.amb[1] * p; out[2] = a.amb[2] * p; return out;
  }
  update(dt, time) {
    this.time = time;
    for (const k in this.circ) this.circCur[k] = damp(this.circCur[k], this.circ[k], 6, dt);
    for (const l of this.lights) {
      const c = this.circCur[l.circuit] ?? 1;
      l.cur = c * flick(l.flick, time, l.seed) * l.i * l.mult;
    }
    for (const d of this.doors) {
      const tgt = d.target === undefined ? d.t : d.target;
      if (d.t !== tgt) {
        const sp = (d.fast ? 3.2 : d.kind === 'blast' ? 0.45 : d.kind === 'shutter' ? 0.9 : 1.5) * dt;
        const was = d.t; d.t = tgt > d.t ? Math.min(tgt, d.t + sp) : Math.max(tgt, d.t - sp);
        if (was >= 0.85 && d.t < 0.85 && this.onDoor) this.onDoor(d, 'blocked');
        if (d.t === tgt && this.onDoor) this.onDoor(d, tgt ? 'opened' : 'closed');
      }
    }
  }

  // pick the strongest lights for a chunk into R.lp/lc
  _select(R, c, cam) {
    const max = R.q.lights; let n = 0;
    const sel = this.sel, score = this._score || (this._score = new Float32Array(8));
    for (const i of c.cands) {
      const l = this.lights[i]; if (l.cur < 0.02) continue;
      const amt = this.linkAmount(c.ai, l.ai); if (amt < 0.05) continue;
      const dx = cam.x - l.x, dy = cam.y - l.wy, dz = cam.z - l.z;
      const s = (l.cur * amt * l.r * l.r) / (dx * dx + dy * dy + dz * dz + 9);
      let p = n < max ? n++ : -1;
      if (p < 0) { let w = 0; for (let k = 1; k < n; k++) if (score[k] < score[w]) w = k; if (score[w] >= s) continue; p = w; }
      sel[p] = l; score[p] = s;
    }
    const lp = this.lp, lc = this.lc;
    for (let k = 0; k < n; k++) {
      const l = sel[k], amt = this.linkAmount(c.ai, l.ai), I = l.cur * amt * 3.2;
      lp[k * 4] = l.x; lp[k * 4 + 1] = l.wy; lp[k * 4 + 2] = l.z; lp[k * 4 + 3] = l.r;
      lc[k * 4] = l.c[0] * I; lc[k * 4 + 1] = l.c[1] * I; lc[k * 4 + 2] = l.c[2] * I; lc[k * 4 + 3] = 0;
    }
    R.setLights(n, lp, lc);
  }
  // areas reachable from the camera's area through open boundaries / open doors (max 3 hops): closed doors hide what is behind them
  _visAreas(ai) {
    const n = this.grid.areas.length, set = this.visSet || (this.visSet = new Uint8Array(n));
    if (ai < 0) { set.fill(1); return set; }
    set.fill(0); set[ai] = 1;
    const q = [[ai, 0]];
    for (let h = 0; h < q.length; h++) {
      const [a, d] = q[h]; if (d >= 3) continue;
      for (const b of this.links[a].keys()) { if (set[b] || this.linkAmount(a, b) < 0.02) continue; set[b] = 1; q.push([b, d + 1]); }
    }
    return set;
  }
  visibleChunks(R, cam, far) {
    const out = [], p = R.planes, set = this._visAreas(this.grid.areaAt(cam.x, cam.z));
    for (const c of this.chunks) {
      if (!set[c.ai]) continue;
      const b = c.bounds, dx = Math.max(b[0] - cam.x, 0, cam.x - b[3]), dz = Math.max(b[2] - cam.z, 0, cam.z - b[5]);
      if (dx * dx + dz * dz > far * far) continue;
      if (!aabbVisible(p, b[0], b[1], b[2], b[3], b[4], b[5])) continue;
      out.push(c);
    }
    return out;
  }
  // opaque + emissive, then decals
  draw(R, cam, far = 60) {
    const vis = this.visibleChunks(R, cam, far); this.drawn = vis.length;
    for (const c of vis) {
      this._select(R, c, cam);
      for (const d of c.draws) if (d.kind === 'lit') R.drawMesh(d.mesh, d.mat, 'lit');
      for (const d of c.draws) if (d.kind === 'emis') R.drawMesh(d.mesh, d.mat, 'emis');
    }
    this.drawDynamic(R, cam);
    R.blend('alpha'); R.polyOffset(true);
    for (const c of vis) {
      let any = false;
      for (const d of c.draws) if (d.kind === 'decal') { if (!any) { this._select(R, c, cam); any = true; } R.drawMesh(d.mesh, d.mat, 'decal'); }
    }
    R.polyOffset(false); R.blend('off');
    this.visible = vis;
  }
  drawDynamic(R, cam) {
    const g = this.grid;
    // door leaves (lit with their area's lights)
    for (const lf of this.leaves) {
      const d = lf.d, dx = d.cx - cam.x, dz = d.cz - cam.z;
      if (dx * dx + dz * dz > 3600) continue;
      const sd = d.axis === 'x' ? (cam.z < d.cz ? -1.2 : 1.2) : (cam.x < d.cx ? -1.2 : 1.2); // light the leaf from the side the viewer is on
      const ch = this.chunkFor(d.axis === 'x' ? d.cx : d.cx + sd, d.axis === 'x' ? d.cz + sd : d.cz) || this.chunkFor(d.x + 0.5, d.z + 0.5);
      if (ch) this._select(R, ch, cam);
      const sl = d.slide * d.t * (d.kind === 'shutter' ? 0 : d.w), up = d.kind === 'shutter' ? d.t * (d.hgt + 0.1) : 0;
      const ox = d.axis === 'x' ? sl : 0, oz = d.axis === 'z' ? sl : 0;
      m4.fromTRS(lf.m, d.cx + ox, lf.y + up, d.cz + oz, 0, lf.ry, 0, 1, 1, 1);
      R.drawMesh(lf.mesh, lf.mat, 'lit', lf.m);
    }
    // ceiling fixtures (emissive), status lamps
    for (const f of this.fixtures) {
      const l = f.l, dx = l.x - cam.x, dz = l.z - cam.z;
      if (dx * dx + dz * dz > 2500) continue;
      const v = Math.min(1.6, l.cur * this.linkAmount(l.ai, l.ai) * 1.4);
      R.drawMesh(this.fixMesh, this.mats['emis:white'], 'emis', f.m, 1, [l.c[0] * v + 0.04, l.c[1] * v + 0.04, l.c[2] * v + 0.04]);
    }
    for (const d of this.doors) {
      if (d.kind === 'rack' && d.lock.type === 'script' && d.locked) continue;
      const dx = d.cx - cam.x, dz = d.cz - cam.z; if (dx * dx + dz * dz > 900) continue;
      const locked = this.doorLocked(d), col = !this.doorPowered(d) ? [0.18, 0.1, 0.02] : locked ? [1.4, 0.08, 0.05] : [0.1, 1.2, 0.25];
      const a = g.areas[g.area[d.cells[0]]], y = g.areaY(a, d.cx, d.cz) + 2.05, sd = d.hgt > 3 ? 0.1 : 0;
      const px = d.axis === 'x' ? d.x - 0.3 : d.cx, pz = d.axis === 'z' ? d.z - 0.3 : d.cz;
      for (const side of [-1, 1]) {
        m4.translation(this.model, d.axis === 'z' ? d.cx + side * (0.62 + sd) : px, y, d.axis === 'x' ? d.cz + side * (0.62 + sd) : pz);
        R.drawMesh(this.cubeMesh, this.mats['emis:white'], 'emis', this.model, 1, col);
      }
    }
    for (const f of this.extraDraw) f(R, cam);
  }
}
