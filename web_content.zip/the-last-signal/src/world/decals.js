// Decal atlas (blood, scratches, grime, hazard stripes, signs, graffiti) drawn at load time with Canvas2D, plus quad helpers.
// Atlas = 4x4 slots of 256px (1024x1024). Each sprite lives in one slot; its `uv` rect is the used part of the slot.
import { rng } from '../engine/math.js';

const SLOT = 256;
export const SPRITES = {
  splat1: { slot: 0, aspect: 1 }, splat2: { slot: 1, aspect: 1 }, drips: { slot: 2, aspect: 0.5 }, hands: { slot: 3, aspect: 1 },
  claws: { slot: 4, aspect: 1 }, scorch: { slot: 5, aspect: 1 }, stain: { slot: 6, aspect: 1 }, hazard: { slot: 7, aspect: 4 },
  exit: { slot: 8, aspect: 2 }, voltage: { slot: 9, aspect: 1 }, staff: { slot: 10, aspect: 2 }, lab: { slot: 11, aspect: 3 },
  storage: { slot: 12, aspect: 3 }, chamber: { slot: 13, aspect: 3 }, poster: { slot: 14, aspect: 0.72 }, scrawl: { slot: 15, aspect: 2 },
};
for (const k in SPRITES) {
  const s = SPRITES[k], c = s.slot % 4, r = (s.slot / 4) | 0;
  const w = s.aspect >= 1 ? SLOT : SLOT * s.aspect, h = s.aspect >= 1 ? SLOT / s.aspect : SLOT;
  const x0 = c * SLOT + (SLOT - w) / 2, y0 = r * SLOT + (SLOT - h) / 2;
  s.px = [x0, y0, w, h];
  s.uv = [x0 / (4 * SLOT), y0 / (4 * SLOT), (x0 + w) / (4 * SLOT), (y0 + h) / (4 * SLOT)];
}

function blob(g, cx, cy, r, R) { // organic blood blob with satellite droplets
  g.beginPath();
  const n = 18;
  for (let i = 0; i <= n; i++) {
    const a = (i / n) * Math.PI * 2, rr = r * (0.7 + 0.5 * R());
    const x = cx + Math.cos(a) * rr, y = cy + Math.sin(a) * rr;
    if (i === 0) g.moveTo(x, y); else g.lineTo(x, y);
  }
  g.closePath(); g.fill();
}

export function drawAtlas(canvas, size = 1024) {
  const g = canvas.getContext('2d'), R = rng(7), k = size / (4 * SLOT);
  g.scale(k, k);
  g.clearRect(0, 0, 4 * SLOT, 4 * SLOT);
  const at = (name, fn) => { const s = SPRITES[name], [x, y, w, h] = s.px; g.save(); g.beginPath(); g.rect(x, y, w, h); g.clip(); g.translate(x, y); fn(w, h); g.restore(); };
  const blood = (a) => `rgba(${70 + R() * 30 | 0},${4 + R() * 6 | 0},${6 + R() * 6 | 0},${a})`;
  for (const name of ['splat1', 'splat2']) at(name, (w, h) => {
    g.fillStyle = blood(0.92); blob(g, w / 2, h / 2, 62 + R() * 14, R);
    for (let i = 0; i < 26; i++) { const a = R() * 6.283, d = 70 + R() * 50; g.fillStyle = blood(0.5 + R() * 0.4); g.beginPath(); g.arc(w / 2 + Math.cos(a) * d, h / 2 + Math.sin(a) * d, 1.5 + R() * 6, 0, 6.283); g.fill(); }
    g.fillStyle = 'rgba(150,12,16,0.35)'; blob(g, w / 2 - 6, h / 2 - 8, 34, R);
  });
  at('drips', (w, h) => {
    for (let i = 0; i < 7; i++) { const x = 14 + R() * (w - 28), l = 40 + R() * (h - 60); g.fillStyle = blood(0.85); g.fillRect(x - 2, 6, 4 + R() * 2, l); g.beginPath(); g.arc(x, 6 + l, 4 + R() * 2, 0, 6.283); g.fill(); }
    g.fillStyle = blood(0.9); g.fillRect(0, 0, w, 14);
  });
  at('hands', (w, h) => { // smeared handprints
    for (let n = 0; n < 3; n++) {
      const x = 50 + n * 70 + R() * 20, y = 60 + R() * 60; g.save(); g.translate(x, y); g.rotate((R() - 0.5) * 0.6); g.fillStyle = blood(0.85);
      g.beginPath(); g.ellipse(0, 24, 20, 24, 0, 0, 6.283); g.fill();
      for (let f = -2; f <= 2; f++) { g.beginPath(); g.ellipse(f * 9, -6 - (2 - Math.abs(f)) * 5, 4.5, 15, f * 0.12, 0, 6.283); g.fill(); }
      g.fillRect(-4, 40, 10, 70 + R() * 40); g.restore();
    }
  });
  at('claws', (w, h) => {
    g.strokeStyle = 'rgba(8,8,8,0.9)'; g.lineCap = 'round';
    for (let n = 0; n < 4; n++) { g.lineWidth = 2 + R() * 3; g.beginPath(); const x = 40 + n * 46; g.moveTo(x, 20); g.bezierCurveTo(x + 10, 80, x - 12, 150, x + 8, 232); g.stroke(); g.strokeStyle = 'rgba(190,190,180,0.25)'; g.lineWidth = 1; g.beginPath(); g.moveTo(x + 3, 22); g.bezierCurveTo(x + 13, 82, x - 9, 152, x + 11, 230); g.stroke(); g.strokeStyle = 'rgba(8,8,8,0.9)'; }
  });
  at('scorch', (w, h) => { const gr = g.createRadialGradient(w / 2, h / 2, 6, w / 2, h / 2, 118); gr.addColorStop(0, 'rgba(0,0,0,0.88)'); gr.addColorStop(0.6, 'rgba(10,8,6,0.5)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.fillRect(0, 0, w, h); });
  at('stain', (w, h) => { for (let i = 0; i < 6; i++) { const gr = g.createRadialGradient(w / 2 + (R() - 0.5) * 90, h / 2 + (R() - 0.5) * 90, 4, w / 2, h / 2, 60 + R() * 60); gr.addColorStop(0, 'rgba(22,26,16,0.4)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.fillRect(0, 0, w, h); } });
  at('hazard', (w, h) => {
    g.fillStyle = '#d6a912'; g.fillRect(0, 0, w, h); g.fillStyle = '#16140e';
    for (let x = -h; x < w + h; x += 44) { g.beginPath(); g.moveTo(x, h); g.lineTo(x + 22, h); g.lineTo(x + 22 + h, 0); g.lineTo(x + h, 0); g.fill(); }
    g.strokeStyle = 'rgba(0,0,0,0.5)'; g.lineWidth = 3; g.strokeRect(1, 1, w - 2, h - 2);
  });
  const sign = (name, bg, fg, lines, o = {}) => at(name, (w, h) => {
    g.fillStyle = bg; g.fillRect(0, 0, w, h); g.strokeStyle = fg; g.lineWidth = 4; g.strokeRect(6, 6, w - 12, h - 12);
    g.fillStyle = fg; g.textAlign = 'center'; g.textBaseline = 'middle';
    const n = lines.length; lines.forEach((t, i) => { g.font = `bold ${o.sizes ? o.sizes[i] : Math.floor((h - 24) / n * 0.7)}px "Arial Narrow",Arial,sans-serif`; g.fillText(t, w / 2 + (o.dx || 0), 14 + ((i + 0.5) * (h - 28)) / n, w - 30); });
    for (let i = 0; i < 40; i++) { g.fillStyle = `rgba(0,0,0,${R() * 0.25})`; g.fillRect(R() * w, R() * h, 2 + R() * 12, 1 + R() * 2); }
  });
  sign('exit', '#0b5a2a', '#e8ffe8', ['EXIT  ➜'], { sizes: [64] });
  sign('voltage', '#c9a40e', '#141414', ['⚡', 'HIGH', 'VOLTAGE'], { sizes: [90, 46, 40] });
  sign('staff', '#2a1214', '#e9d9d0', ['STAFF ONLY', 'AUTHORISED ACCESS'], { sizes: [44, 22] });
  sign('lab', '#102a30', '#bfe9f0', ['LAB WING  ·  LEVEL 1'], { sizes: [46] });
  sign('storage', '#2b2a14', '#f0e7b0', ['STORAGE  B2'], { sizes: [58] });
  sign('chamber', '#2a0a0e', '#ffd6d6', ['CHAMBER  ZERO', 'AUTHORISED PERSONNEL ONLY'], { sizes: [48, 20] });
  at('poster', (w, h) => {
    g.fillStyle = '#d8d0c0'; g.fillRect(0, 0, w, h); g.fillStyle = '#7a0c12'; g.fillRect(0, 0, w, 62); g.fillStyle = '#f0e8dc'; g.textAlign = 'center'; g.font = 'bold 34px Arial'; g.fillText('SILENCE', w / 2, 40);
    g.fillStyle = '#222'; g.font = 'bold 22px Arial'; ['IS  SAFETY', '', 'DO NOT RESPOND', 'TO UNKNOWN', 'TRANSMISSIONS'].forEach((t, i) => g.fillText(t, w / 2, 100 + i * 28));
    g.strokeStyle = '#222'; g.lineWidth = 6; g.beginPath(); g.arc(w / 2, 232, 18, 0, 6.283); g.moveTo(w / 2 - 12, 244); g.lineTo(w / 2 + 12, 220); g.stroke();
    for (let i = 0; i < 60; i++) { g.fillStyle = `rgba(60,40,20,${R() * 0.2})`; g.fillRect(R() * w, R() * h, 3 + R() * 14, 2 + R() * 8); }
  });
  at('scrawl', (w, h) => {
    g.fillStyle = 'rgba(120,8,12,0.95)'; g.textAlign = 'center'; g.font = 'bold 70px "Comic Sans MS","Chalkboard SE",cursive';
    g.save(); g.translate(w / 2, h / 2 - 16); g.rotate(-0.05); g.fillText('DO NOT', 0, -4); g.fillText('ANSWER', 0, 64); g.restore();
    for (let i = 0; i < 30; i++) { g.fillStyle = blood(0.85); const x = 24 + R() * (w - 48); g.fillRect(x, h / 2 + 30, 2 + R() * 2, 20 + R() * 40); }
  });
  return canvas;
}

// quad on a vertical surface. n = outward normal direction ('+x','-x','+z','-z'); (x,y,z) = centre of the quad on the surface
export function wallDecal(mb, name, x, y, z, n, w, h, o = {}) {
  const s = SPRITES[name], [u0, v0, u1, v1] = s.uv, a = o.a ?? 1, t = [o.t?.[0] ?? 1, o.t?.[1] ?? 1, o.t?.[2] ?? 1];
  const nx = n === '+x' ? 1 : n === '-x' ? -1 : 0, nz = n === '+z' ? 1 : n === '-z' ? -1 : 0;
  const rx = nz, rz = -nx, off = 0.012, hw = w / 2, hh = h / 2;
  const P = (sx, sy) => [x + rx * hw * sx + nx * off, y + hh * sy, z + rz * hw * sx + nz * off];
  const bl = P(-1, -1), br = P(1, -1), tr = P(1, 1), tl = P(-1, 1);
  const f = o.flip ? [u1, u0] : [u0, u1];
  mb.q([...bl, ...br, ...tr, ...tl], nx, 0, nz, [f[0], v1, f[1], v1, f[1], v0, f[0], v0], t, [a, a, a, a]);
}
// quad lying on the floor (facing +y), rotated by `rot` radians
export function floorDecal(mb, name, x, y, z, w, h, rot = 0, o = {}) {
  const s = SPRITES[name], [u0, v0, u1, v1] = s.uv, a = o.a ?? 1, t = [o.t?.[0] ?? 1, o.t?.[1] ?? 1, o.t?.[2] ?? 1];
  const c = Math.cos(rot), sn = Math.sin(rot), hw = w / 2, hh = h / 2;
  const P = (sx, sz) => [x + (sx * hw) * c - (sz * hh) * sn, y + 0.012, z + (sx * hw) * sn + (sz * hh) * c];
  const bl = P(-1, 1), br = P(1, 1), tr = P(1, -1), tl = P(-1, -1);
  mb.q([...bl, ...br, ...tr, ...tl], 0, 1, 0, [u0, v1, u1, v1, u1, v0, u0, v0], t, [a, a, a, a]);
}
export function makeDecalMaterial(R, size = 1024) {
  const canvas = document.createElement('canvas'); canvas.width = canvas.height = size;
  drawAtlas(canvas, size);
  const tex = R.createTexture({ canvas, wrapS: 'clamp', wrapT: 'clamp', w: size, h: size });
  return { tex, bump: 0, spec: 0, shin: 8 };
}
