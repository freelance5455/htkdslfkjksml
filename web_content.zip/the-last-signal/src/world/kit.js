// Composite props built on top of Props primitives.
const T = (r, g, b, ao0 = 0.7) => ({ s: 1, t: [r, g, b], ao0 });

export function jeep(P, x, z, face) { // wrecked army jeep, length along local z
  P.with('metal', x, z, face, (mb) => {
    mb.box(-0.95, 0.35, -2.1, 0.95, 0.95, 2.1, { s: 2, t: [0.34, 0.42, 0.28], ao0: 0.5 });
    mb.box(-0.9, 0.95, -0.4, 0.9, 1.55, 0.9, { s: 2, t: [0.32, 0.4, 0.27] });
    mb.box(-0.95, 0.6, 2.1, 0.95, 0.9, 2.2, { s: 1, t: [0.2, 0.2, 0.2] });
  });
  P.with('metal', x, z, face, (mb) => {
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) { const wx = sx * 0.95, wz = sz * 1.35; mb.tube(wx - 0.12, 0.38, wz, wx + 0.12, 0.38, wz, 0.38, 12, { s: 1, t: [0.1, 0.1, 0.1] }); }
    mb.box(-0.85, 1.0, 0.89, 0.85, 1.5, 0.9, { s: 1, t: [0.05, 0.07, 0.08] }); // windscreen
    mb.box(-0.9, 0.5, -2.12, 0.9, 0.62, -2.08, { s: 1, t: [0.15, 0.15, 0.15] });
  });
  P.collide(x, z, face, 2.0, 4.3);
}
export function fence(P, x0, z0, x1, z1, h = 2.3, o = {}) {
  const alongX = Math.abs(x1 - x0) > Math.abs(z1 - z0), cx = (x0 + x1) / 2, cz = (z0 + z1) / 2, len = Math.hypot(x1 - x0, z1 - z0);
  P.with('grate', cx, cz, alongX ? 's' : 'e', (mb) => {
    mb.box(-len / 2, 0, -0.025, len / 2, h, 0.025, { s: 1, t: o.t || [0.45, 0.5, 0.52], ao0: 0.7 });
    for (let k = 0; k <= Math.round(len / 2.2); k++) mb.box(-len / 2 + k * (len / Math.round(len / 2.2)) - 0.04, 0, -0.06, -len / 2 + k * (len / Math.round(len / 2.2)) + 0.04, h + 0.1, 0.06, { s: 1, t: [0.22, 0.24, 0.26] });
  });
  P.collide(cx, cz, alongX ? 's' : 'e', len, 0.12);
}
export function gatehouse(P, x, z, face) {
  P.with('conc', x, z, face, (mb) => { mb.box(-1.6, 0, -1.4, 1.6, 2.6, 1.4, { s: 2, t: [0.6, 0.62, 0.62], ao0: 0.5 }); mb.box(-1.8, 2.6, -1.6, 1.8, 2.78, 1.6, { s: 2, t: [0.35, 0.36, 0.38] }); });
  P.with('metal', x, z, face, (mb) => { mb.box(-1.2, 1.2, 1.4, 0.6, 2.2, 1.43, { s: 1, t: [0.03, 0.04, 0.05] }); mb.box(0.9, 0.0, 1.4, 1.4, 2.0, 1.44, { s: 1, t: [0.3, 0.32, 0.34] }); });
  P.collide(x, z, face, 3.2, 2.8, { occlude: true });
}
export function rubble(P, x, z, n = 8, spread = 1.4) {
  const R = P.R;
  P.with('conc', x, z, 's', (mb) => {
    for (let i = 0; i < n; i++) { const w = 0.25 + R() * 0.7, h = 0.2 + R() * 0.5, d = 0.25 + R() * 0.6, px = (R() - 0.5) * spread * 2, pz = (R() - 0.5) * spread * 2; mb.box(px - w / 2, 0, pz - d / 2, px + w / 2, h, pz + d / 2, { s: 1.5, t: ((g0) => [g0 * (0.94 + R() * 0.1), g0, g0 * (0.88 + R() * 0.1)])(0.42 + R() * 0.3), ao0: 0.55 }); }
  });
  P.collide(x, z, 's', spread * 1.3, spread * 1.3);
}
export function jersey(P, x, z, face) { P.with('conc', x, z, face, (mb) => { mb.box(-1.0, 0, -0.3, 1.0, 0.45, 0.3, { s: 2, t: [0.7, 0.7, 0.68], ao0: 0.6 }); mb.box(-0.9, 0.45, -0.17, 0.9, 0.85, 0.17, { s: 2, t: [0.7, 0.7, 0.68] }); mb.box(-0.9, 0.62, 0.17, 0.9, 0.72, 0.175, { s: 1, t: [0.9, 0.7, 0.1] }); }); P.collide(x, z, face, 2.0, 0.6); }
export function vending(P, x, z, face) {
  P.with('metal', x, z, face, (mb) => { mb.box(-0.45, 0, -0.4, 0.45, 1.85, 0.4, { s: 1, t: [0.55, 0.12, 0.12], ao0: 0.6 }); mb.box(-0.38, 0.5, 0.4, 0.2, 1.7, 0.41, { s: 1, t: [0.05, 0.07, 0.08] }); });
  P.with('emis:white', x, z, face, (mb) => { mb.box(-0.37, 0.52, 0.41, 0.19, 1.68, 0.415, { skip: 0 }); }, undefined);
  P.collide(x, z, face, 0.9, 0.8);
}
export function cot(P, x, z, face) { P.with('metal', x, z, face, (mb) => { mb.box(-0.4, 0.3, -1.0, 0.4, 0.4, 1.0, { s: 1, t: [0.3, 0.32, 0.3] }); for (const sx of [-1, 1]) for (const sz of [-1, 1]) mb.box(sx * 0.38 - 0.02, 0, sz * 0.95 - 0.02, sx * 0.38 + 0.02, 0.3, sz * 0.95 + 0.02, T(0.2, 0.2, 0.2)); }); P.with('wall', x, z, face, (mb) => mb.box(-0.38, 0.4, -0.9, 0.38, 0.5, 0.9, { s: 1, t: [0.55, 0.5, 0.42], ao0: 0.8 })); P.collide(x, z, face, 0.85, 2.0); }
export function xray(P, x, z, face) { P.with('metal', x, z, face, (mb) => { mb.box(-1.1, 0, -0.45, 1.1, 0.8, 0.45, { s: 1, t: [0.3, 0.32, 0.35], ao0: 0.6 }); mb.box(-0.55, 0.8, -0.5, 0.55, 1.6, 0.5, { s: 1, t: [0.35, 0.37, 0.4] }); mb.box(-0.45, 0.8, 0.5, 0.45, 1.3, 0.52, { s: 1, t: [0.02, 0.02, 0.03] }); mb.box(-1.1, 0.8, -0.35, -0.6, 0.86, 0.35, { s: 1, t: [0.12, 0.12, 0.14] }); mb.box(0.6, 0.8, -0.35, 1.1, 0.86, 0.35, { s: 1, t: [0.12, 0.12, 0.14] }); }); P.collide(x, z, face, 2.2, 1.0); }
export function arch(P, x, z, face, w = 1.2) { P.with('metal', x, z, face, (mb) => { for (const s of [-1, 1]) mb.box(s * w / 2 - 0.08, 0, -0.14, s * w / 2 + 0.08, 2.3, 0.14, T(0.35, 0.37, 0.4, 0.6)); mb.box(-w / 2 - 0.08, 2.3, -0.16, w / 2 + 0.08, 2.5, 0.16, T(0.3, 0.32, 0.35)); }); P.with('emis:white', x, z, face, (mb) => { mb.box(-0.3, 2.31, 0.165, 0.3, 2.37, 0.17, {}); }, undefined); for (const s of [-1, 1]) { const [px, pz] = P.at(x, z, face, s * w / 2, 0); P.g.addProp({ x0: px - 0.1, x1: px + 0.1, z0: pz - 0.1, z1: pz + 0.1, solid: true }); } }
export function tank(P, x, z, r = 0.6, h = 2.6, tint = [0.3, 0.6, 0.4]) {
  P.with('metal', x, z, 's', (mb) => { mb.cyl(0, 0, 0, r + 0.08, 0.2, 14, T(0.25, 0.27, 0.3, 0.5)); mb.cyl(0, h - 0.2, 0, r + 0.08, 0.2, 14, T(0.25, 0.27, 0.3, 0.8)); for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2 + 0.78; mb.cyl(Math.cos(a) * (r + 0.02), 0.2, Math.sin(a) * (r + 0.02), 0.025, h - 0.4, 6, T(0.2, 0.2, 0.22)); } });
  P.with('emis:glass', x, z, 's', (mb) => { mb.cyl(0, 0.2, 0, r, h - 0.4, 14, { s: 1, t: tint }); }, undefined);
  P.collide(x, z, 's', r * 2 + 0.2, r * 2 + 0.2);
}
export function rack(P, x, z, face, n = 1) { for (let i = 0; i < n; i++) { const [px, pz] = P.at(x, z, face, i * 0.9, 0); P.with('metal', px, pz, face, (mb) => { mb.box(-0.4, 0, -0.4, 0.4, 2.2, 0.4, T(0.16, 0.17, 0.19, 0.6)); for (let k = 0; k < 9; k++) mb.box(-0.34, 0.15 + k * 0.23, 0.4, 0.34, 0.33 + k * 0.23, 0.42, T(0.07, 0.08, 0.09)); }); P.with('emis:white', px, pz, face, (mb) => { for (let k = 0; k < 9; k++) if ((k * 7 + i * 3) % 4 !== 0) mb.box(-0.3 + ((k * 5) % 6) * 0.1, 0.2 + k * 0.23, 0.421, -0.26 + ((k * 5) % 6) * 0.1, 0.23 + k * 0.23, 0.423, {}); }, undefined); P.collide(px, pz, face, 0.8, 0.8); } }
