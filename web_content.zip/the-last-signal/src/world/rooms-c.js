// Generator hall, storage ramp + hall, link, ante-room, Chamber Zero (the Array), escape tunnel, hatch, surface exit.
import { rubble, fence, tank, rack } from './kit.js';

export function roomsDeep(C) {
  const P = C.P, fy = C.fy, F = fy;
  // ---------------- generator hall (x60..79, z13..30, floor -4, h7) ----------------
  const gy = F(70, 21);
  P.with('metal', 70, 21, 's', (mb) => {
    mb.box(-4.3, 0, -1.8, 4.3, 0.25, 1.8, { s: 2, t: [0.2, 0.2, 0.22], ao0: 0.5 });
    mb.box(-3.2, 0.25, -1.3, 1.2, 1.9, 1.3, { s: 2, t: [0.34, 0.42, 0.3], ao0: 0.5 });
    mb.tube(1.2, 1.1, 0, 3.0, 1.1, 0, 0.8, 14, { s: 2, t: [0.3, 0.34, 0.4] });
    mb.box(3.0, 0.25, -1.1, 4.1, 1.55, 1.1, { s: 2, t: [0.62, 0.2, 0.14], ao0: 0.5 });
    mb.tube(4.1, 0.9, 0, 4.5, 0.9, 0, 0.1, 8, { s: 1, t: [0.2, 0.2, 0.2] });
    mb.cyl(-2.4, 1.9, 0, 0.22, 4.9, 10, { s: 1, t: [0.3, 0.3, 0.32] });
    mb.box(-1.0, 0.25, 1.3, 1.0, 1.8, 1.7, { s: 1, t: [0.28, 0.3, 0.33], ao0: 0.6 });
    for (let i = 0; i < 6; i++) mb.box(-3.2, 0.4 + i * 0.22, -1.32, 1.2, 0.5 + i * 0.22, -1.3, { s: 1, t: [0.15, 0.16, 0.17] });
  });
  P.with('emis:screen', 70, 21, 's', (mb) => { mb.q([-0.8, 1.2, 1.705, 0.8, 1.2, 1.705, 0.8, 1.6, 1.705, -0.8, 1.2, 1.705], 0, 0, 1, [0, 0, 1, 0, 1, 1, 0, 1], [1, 0.8, 0.4]); });
  P.collide(70, 21, 's', 8.6, 3.6);
  for (const [x, z] of [[63.5, 16.5], [63.5, 26.5], [76.5, 16.5], [76.5, 26.5]]) P.pillar(x, z, 0.9, { key: 'conc' });
  P.pipe(66.4, gy + 2.3, 20, 66.4, gy + 6.9, 20, 0.25); P.pipe(66.4, gy + 5.5, 20, 75, gy + 5.5, 20, 0.2); P.pipes(60.2, 13.3, 79.5, 13.3, gy + 5.6, 3);
  P.with('metal', 70, 13.1, 's', (mb) => { mb.box(-1.2, 1.0, -0.1, 1.2, 2.3, 0.1, { s: 1, t: [0.26, 0.28, 0.3] }); for (const lx of [-0.8, 0, 0.8]) mb.box(lx - 0.1, 1.4, 0.1, lx + 0.1, 1.9, 0.12, { s: 1, t: [0.05, 0.05, 0.06] }); });
  for (let i = 0; i < 3; i++) {
    const lx = 69.2 + i * 0.8;
    C.dynObj('br' + (i + 1), { 'metal': (mb) => { mb.box(-0.025, 0, -0.025, 0.025, 0.32, 0.025, { s: 1, t: [0.75, 0.75, 0.78] }); }, 'emis:white': (mb) => { mb.box(-0.05, 0.3, -0.05, 0.05, 0.4, 0.05, { t: [1, 0.15, 0.1] }); } }, { x: lx, y: gy + 1.5, z: 13.24, rx: 0 });
    C.act('breaker' + (i + 1), 'breaker', lx, 13.6, 1.65, 1.7, 'Breaker ' + (i + 1), { n: i + 1, cos: 0.95 });
  }
  C.act('placard', 'note', 66.2, 13.6, 1.6, 1.8, 'Generator placard', { note: 'placard' });
  C.act('genfuel', 'fuelport', 74.9, 21.0, 0.9, 1.7, 'Generator fuel intake');
  C.dynObj('starter', { metal: (mb) => { mb.box(-0.03, -0.35, -0.03, 0.03, 0.0, 0.03, { s: 1, t: [0.2, 0.2, 0.2] }); mb.box(-0.14, -0.4, -0.04, 0.14, -0.34, 0.04, { s: 1, t: [0.7, 0.1, 0.1] }); } }, { x: 70, y: gy + 1.25, z: 22.78 });
  C.act('starter', 'starter', 70, 23.2, 1.0, 1.7, 'Starter handle', { hold: true });
  P.wallDecal('staff', 66.2, gy + 2.5, 13, '+z', 1.0, 0.5); P.wallDecal('voltage', 73, gy + 1.8, 13, '+z', 0.9, 0.9); P.wallDecal('hazard', 70, gy + 0.2, 13, '+z', 6, 0.3);
  P.wallDecal('drips', 79.99, gy + 1.7, 24, '-x', 1.0, 2.0, { a: 0.8 }); P.wallDecal('claws', 60.0, gy + 1.5, 21.0, '+x', 1.6, 1.6, { a: 0.9 });
  P.shelf(60.35, 25.2, 'e', { w: 2.6, d: 0.55, h: 2.2, n: 4 }); P.shelf(60.35, 27.9, 'e', { w: 2.0, d: 0.55, h: 2.2, n: 4 });
  P.stack(78.6, 28.2); P.barrel(78.9, 24.8); P.barrel(78.9, 25.5); P.barrel(62.4, 14.2); rubble(P, 73, 27.6, 5, 0.7); P.crate(64, 28.9);
  P.hide('h_gen1', 'cabinet', 79.6, 15.6, 'w', { w: 1.0, d: 0.75, key: 'metal', t: [0.3, 0.34, 0.3] });
  P.hide('h_gen2', 'crate', 61.6, 29.6, 'n', { w: 1.3, d: 0.95, h: 1.4, key: 'wood', t: [0.7, 0.6, 0.48], eye: 0.95 });
  P.floorDecal('hazard', 70, 18.4, 9.5, 0.5, 0, { a: 0.9 }); P.floorDecal('hazard', 70, 23.6, 9.5, 0.5, 0, { a: 0.9 }); P.floorDecal('scorch', 66, 16.2, 4, 4, 0.3, { a: 0.8 });
  for (const [x, z, r] of [[62.4, 19.4, 0.4], [68.2, 24.8, 1.2], [76.0, 20.6, 2.2]]) P.floorDecal(r > 1 ? 'splat2' : 'splat1', x, z, 1.8, 1.8, r, { a: 0.85 });
  P.floorDecal('stain', 70, 22, 16, 14, 0, { a: 0.45 });
  C.pick('b_gen', 'battery', 78.4, 23.0, 0.0); C.pick('m_gen', 'medkit', 60.55, 27.9, 0.83);
  C.fxEmit('steam', 63.5, gy + 0.3, 29.0, {});
  C.wp('service', 70, 16); C.wp('service', 66, 26.5); C.wp('service', 76, 26);

  // ---------------- storage ramp (x68..70, z32..55) ----------------
  const yz = (z) => -4 - 6 * (z - 32) / 24;
  P.pipe(68.15, yz(33) + 3.3, 33, 68.15, yz(55.5) + 3.3, 55.5, 0.09); P.pipe(70.85, yz(33) + 3.3, 33, 70.85, yz(55.5) + 3.3, 55.5, 0.07);
  P.crate(68.65, 40.2, { s: 0.7 }); P.crate(70.4, 47.2, { s: 0.7 });
  P.wallDecal('storage', 69.5, gy + 4.7, 31, '-z', 3.0, 1.0); P.wallDecal('hazard', 68.01, yz(40) + 0.2, 44, '+x', 8, 0.25);
  P.floorDecal('splat2', 69.6, 38.4, 1.8, 1.8, 0.8, { a: 0.85 }); P.floorDecal('splat1', 69.4, 50.4, 1.6, 1.6, 2.0, { a: 0.85 });

  C.wp('deep', 70, 44);

  // ---------------- storage hall (x58..95, z56..76, floor -10) ----------------
  const sy = F(70, 60);
  const blocks = [[60.8, 63.6, 66.4], [72.6], [78.2, 80.9], [88.6, 91.3]];
  for (const z of [61, 65, 69, 73]) for (const cx of blocks.flat()) { if (z === 73 && cx < 67) continue; P.shelf(cx, z, 's', { w: cx === 72.6 ? 2.3 : 2.7, d: 0.6, h: 2.4, n: 4, occlude: true }); }
  P.stack(75.3, 63.0); P.stack(85.6, 67.0, { n: 3 }); P.crate(75.4, 71.0); P.crate(85.8, 59.5); P.barrel(92.4, 59.2); P.barrel(92.9, 59.8); rubble(P, 86, 75, 7, 0.9); rubble(P, 62, 58.4, 5, 0.6);
  P.hide('h_st1', 'crate', 63.4, 58.0, 's', { w: 1.3, d: 0.95, h: 1.4, key: 'wood', t: [0.65, 0.58, 0.45], eye: 0.95 });
  P.hide('h_st2', 'crate', 81.5, 58.0, 's', { w: 1.3, d: 0.95, h: 1.4, key: 'wood', t: [0.7, 0.6, 0.5], eye: 0.95 });
  P.hide('h_st3', 'cabinet', 74.9, 76.5, 'n', { w: 1.0, d: 0.75, key: 'metal', t: [0.3, 0.33, 0.35] });
  P.hide('h_st4', 'cabinet', 83.5, 76.5, 'n', { w: 1.0, d: 0.75, key: 'metal', t: [0.35, 0.32, 0.3] });
  P.hide('h_st5', 'crate', 92.0, 63.0, 'w', { w: 1.3, d: 0.95, h: 1.4, key: 'wood', t: [0.62, 0.55, 0.45], eye: 0.95 });
  // supervisor cage (SW corner)
  fence(P, 58.2, 72.0, 64.8, 72.0, 2.6); fence(P, 64.8, 72.0, 64.8, 73.5, 2.6); fence(P, 64.8, 75.1, 64.8, 76.9, 2.6);
  C.dynObj('cage_gate', { grate: (mb) => { mb.box(-0.8, 0, -0.03, 0.8, 2.5, 0.03, { s: 1, t: [0.45, 0.5, 0.52] }); } }, { x: 64.8, y: sy, z: 74.3, ry: Math.PI / 2 });
  C.cageCol = P.collide(64.8, 74.3, 'e', 1.6, 0.12, { id: 'cage' });
  P.shelf(60.6, 75.6, 'n', { w: 2.4, d: 0.55, h: 2.2, n: 4, empty: true }); P.crate(62.6, 73.0, { s: 0.8 });
  P.with('metal', 65.2, 75.3, 'e', (mb) => { mb.box(-0.06, 0, -0.06, 0.06, 1.2, 0.06, { s: 1, t: [0.25, 0.25, 0.27] }); mb.box(-0.12, 1.2, -0.1, 0.12, 1.5, 0.1, { s: 1, t: [0.14, 0.15, 0.17] }); });
  P.with('emis:screen', 65.2, 75.3, 'e', (mb) => { mb.q([-0.08, 1.25, 0.101, 0.08, 1.25, 0.101, 0.08, 1.45, 0.101, -0.08, 1.45, 0.101], 0, 0, 1, [0, 0, 1, 0, 1, 1, 0, 1], [1, 0.6, 0.3]); });
  C.act('cagekeypad', 'keypad', 65.7, 75.3, 1.35, 1.6, 'Cage keypad', { code: 'cage' });
  C.act('n_cage', 'note', 62.0, 71.5, 1.3, 1.8, 'Pinned notice', { note: 'cage' });
  C.pick('keycard3', 'keycard3', 60.9, 75.6, 0.83); C.pick('b_cage', 'battery', 60.2, 75.6, 0.16); C.pick('m_cage', 'medkit', 62.6, 73.0, 0.8);
  // nest at the east end
  P.with('skin', 91.5, 72.4, 's', (mb) => { mb.sphere(0, 0.3, 0, 1.3, 9, 6, { s: 1.5, t: [0.7, 0.45, 0.45] }); mb.sphere(1.4, 0.2, 0.9, 0.8, 8, 5, { s: 1.5, t: [0.6, 0.38, 0.38] }); mb.sphere(-1.3, 0.2, 0.7, 0.7, 8, 5, { s: 1.5, t: [0.65, 0.4, 0.4] }); mb.sphere(0.3, 0.2, -1.4, 0.9, 8, 5, { s: 1.5, t: [0.62, 0.4, 0.42] }); });
  P.collide(91.5, 72.4, 's', 3.4, 3.4);
  P.wallDecal('scrawl', 96, sy + 2.2, 70, '-x', 3.0, 1.5, { a: 0.95 }); P.wallDecal('claws', 96, sy + 1.4, 66, '-x', 1.6, 1.6, { a: 0.9 }); P.wallDecal('drips', 96, sy + 2.0, 74.5, '-x', 1.0, 2.0, { a: 0.9 });
  P.wallDecal('hands', 58, sy + 1.3, 66, '+x', 1.6, 1.6, { a: 0.8 }); P.wallDecal('storage', 80, sy + 3.5, 56, '+z', 3.0, 1.0); P.wallDecal('poster', 77, sy + 1.8, 77, '-z', 1.1, 1.5);
  for (const [x, z, r] of [[71, 58.5, 0.2], [74, 62.6, 1.3], [78, 63, 2.5], [83, 66.5, 0.7], [87, 70, 1.9], [89.5, 70.6, 0.4], [72, 74.8, 2.9]]) P.floorDecal(r > 1.2 ? 'splat2' : 'splat1', x, z, 1.7, 1.7, r, { a: 0.9 });
  P.floorDecal('splat2', 91.5, 72.4, 5, 5, 0.9, { a: 0.9 }); P.floorDecal('stain', 76, 66, 30, 14, 0, { a: 0.4 });
  for (const x of [72.5, 85.8]) P.floorDecal('hazard', x, 60.0, 0.5, 5, 1.5707, { a: 0.8 });
  P.pipes(58.5, 56.6, 95.5, 56.6, sy + 4.9, 3); P.pipes(95.4, 57, 95.4, 76.6, sy + 4.8, 2);
  C.pick('b_st1', 'battery', 75.4, 71.0, 0.9);
  for (const [x, z] of [[70, 58.5], [65.5, 58.5], [80, 58.2], [89, 58.5], [72, 63], [79, 67], [88, 66], [72, 75], [66, 67], [92, 74.5], [82, 74.5]]) C.wp('deep', x, z);

  // ---------------- link corridor (x93..95, z40..55) + ante-room (x91..97, z31..38) ----------------
  P.pipes(93.2, 41, 93.2, 55, F(94, 48) + 2.85, 2); P.pipes(95.8, 41, 95.8, 55, F(94, 48) + 2.7, 2, { key: 'metal' });
  P.hide('h_link', 'cabinet', 95.6, 47.5, 'w', { w: 1.0, d: 0.75, key: 'metal', t: [0.3, 0.3, 0.34] });
  P.wallDecal('chamber', 94, F(94, 41) + 3.0, 40, '+z', 1.5, 0.5); P.wallDecal('hazard', 93.01, F(93, 47) + 0.15, 47, '+x', 8, 0.22);
  P.wallDecal('claws', 96, F(95, 44) + 1.4, 44, '-x', 1.4, 1.4, { a: 0.9 }); P.wallDecal('drips', 93, F(94, 51) + 1.6, 51, '+x', 1.0, 2.0, { a: 0.8 });
  for (const [x, z, r] of [[94, 53, 0.2], [94.3, 49, 1.4], [93.8, 44, 2.6], [94, 41.5, 0.9]]) P.floorDecal(r > 1.2 ? 'splat2' : 'splat1', x, z, 1.5, 1.5, r, { a: 0.9 });
  C.wp('deep', 94.5, 48); C.wp('deep', 94.5, 43);
  P.bench(91.5, 34.5, 'e', 2.4); P.locker(97.74, 34.0, 'w', 4);
  P.hide('h_ante', 'locker', 97.68, 36.5, 'w', { w: 0.6, d: 0.6, key: 'metal', t: [0.32, 0.36, 0.42] });
  P.body(94.2, 36.0, 2, { t: [0.6, 0.6, 0.62] });
  P.wallDecal('staff', 91, F(91, 36) + 1.8, 35.5, '+x', 1.2, 0.6); P.wallDecal('scrawl', 94, F(94, 32) + 1.7, 31, '+z', 2.2, 1.1, { a: 0.9 });
  P.floorDecal('splat2', 94.2, 34.6, 2.2, 2.2, 0.5); P.floorDecal('scorch', 93.9, 31.9, 2.4, 2.4, 0.1, { a: 0.8 });
  C.pick('b_ante', 'battery', 91.7, 31.8, 0.0); C.wp('deep', 94, 35);

  // ---------------- Chamber Zero (x86..115, z8..29, floor -10, h10) ----------------
  const cy = F(100, 18), AX = 100.5, AZ = 17.5;
  P.with('metal', AX, AZ, 's', (mb) => {
    mb.cyl(0, 0, 0, 6.6, 0.2, 28, { s: 2, t: [0.3, 0.32, 0.36], ao0: 0.6 }); mb.cyl(0, 0.2, 0, 6.0, 0.3, 28, { s: 2, t: [0.22, 0.24, 0.28] });
    mb.cyl(0, 0.5, 0, 0.9, 9.0, 16, { s: 1.5, t: [0.32, 0.34, 0.4], ao0: 0.7 }); mb.cyl(0, 0.5, 0, 1.5, 0.6, 16, { s: 1.5, t: [0.26, 0.28, 0.32] });
    for (let i = 0; i < 6; i++) { const a = (i / 6) * Math.PI * 2; mb.tube(Math.cos(a) * 5.4, 0.5, Math.sin(a) * 5.4, Math.cos(a) * 1.1, 0.9, Math.sin(a) * 1.1, 0.12, 6, { s: 1, t: [0.1, 0.1, 0.12] }); }
  });
  P.collide(AX, AZ, 's', 8.0, 8.0);
  C.array = { x: AX, z: AZ, y: cy, rings: [] };
  [[3.1, 3.2, 0.5], [2.4, 5.3, -0.8], [1.8, 7.2, 1.2]].forEach(([R, h, sp], i) => {
    C.array.rings.push(C.dynObj('ring' + i, { metal: (mb) => { mb.torus(R, 0.14, 28, 8, { s: 1, t: [0.55, 0.58, 0.65] }); }, 'emis:white': (mb) => { mb.torus(R, 0.045, 28, 6, { t: [0.3, 0.55, 1.0] }); } }, { x: AX, y: cy + h, z: AZ, rx: Math.PI / 2, speed: sp, tint: [0.5, 0.8, 1.2] }));
  });
  C.dynObj('core', { 'emis:white': (mb) => { mb.sphere(0, 0, 0, 0.5, 10, 7, { t: [0.4, 0.7, 1.0] }); } }, { x: AX, y: cy + 4.3, z: AZ, tint: [1, 1, 1] });
  P.console(AX + 1.8, 26.6, 's', { w: 2.6, screens: 3, tint: [0.4, 0.9, 1] }); P.console(AX - 2.6, 26.6, 's', { w: 1.6, screens: 2, tint: [1, 0.6, 0.3] });
  C.act('arraycon', 'console', AX + 1.8, 26.6, 1.25, 2.0, 'Array control console');
  C.act('n_chamber', 'note', AX - 2.6, 26.6, 1.25, 1.8, 'Console log', { note: 'chamber' });
  C.zone('array', AX - 14, AZ - 14, AX + 14, AZ + 14);
  for (const [x, z] of [[89.5, 12], [89.5, 26], [112.5, 12], [112.5, 26]]) P.pillar(x, z, 1.0, { key: 'conc', t: [0.8, 0.85, 0.9] });
  for (let i = 0; i < 4; i++) tank(P, 114.4, 11 + i * 4, 0.9, 4.2, i === 2 ? [0.06, 0.08, 0.08] : [0.14, 0.45, 0.32]);
  rack(P, 86.45, 14.5, 'e', 4); rack(P, 86.45, 22, 'e', 3);
  P.hide('h_ch1', 'cabinet', 93.0, 8.4, 's', { w: 1.0, d: 0.75, key: 'metal', t: [0.3, 0.32, 0.36] }); P.hide('h_ch2', 'cabinet', 108.6, 8.4, 's', { w: 1.0, d: 0.75, key: 'metal', t: [0.34, 0.3, 0.3] });
  P.hide('h_ch3', 'cabinet', 86.4, 18.3, 'e', { w: 1.0, d: 0.75, key: 'metal', t: [0.3, 0.34, 0.3] }); P.hide('h_ch4', 'locker', 115.6, 27.5, 'w', { w: 0.6, d: 0.6, key: 'metal', t: [0.3, 0.3, 0.38] });
  P.body(97.4, 25.2, 0); P.body(104.6, 24.5, 1, { t: [0.55, 0.55, 0.6] }); rubble(P, 108.8, 22.8, 6, 0.8); P.crate(111.5, 28.4); P.stack(88.2, 28.6);
  P.wallDecal('chamber', 94, cy + 3.5, 30, '-z', 2.4, 0.8); P.wallDecal('scrawl', 116, cy + 3.2, 18, '-x', 3.4, 1.7, { a: 0.95 }); P.wallDecal('scrawl', 100.5, cy + 2.0, 8, '+z', 2.4, 1.2, { a: 0.9 });
  P.wallDecal('hands', 86, cy + 1.5, 26, '+x', 1.8, 1.8, { a: 0.85 }); P.wallDecal('exit', 88.5, cy + 3.3, 8, '+z', 1.6, 0.8); P.wallDecal('voltage', 98, cy + 1.8, 30, '-z', 0.9, 0.9);
  P.floorDecal('scorch', AX, AZ, 12, 12, 0.2, { a: 0.7 }); P.floorDecal('splat2', 97.5, 25.5, 2.6, 2.6, 0.7); P.floorDecal('splat1', 104.6, 24.6, 2.2, 2.2, 2.1); P.floorDecal('stain', 100, 19, 26, 18, 0, { a: 0.4 });
  for (const [x, z, r] of [[93.8, 28.8, 0.3], [95.4, 25, 1.5], [91, 20, 2.6], [90, 14, 0.8]]) P.floorDecal(r > 1.2 ? 'splat2' : 'splat1', x, z, 1.7, 1.7, r, { a: 0.9 });
  P.pipes(86.4, 8.4, 115.6, 8.4, cy + 9.3, 3); P.pipes(115.6, 9, 115.6, 29, cy + 9.0, 2);
  C.pick('b_ch1', 'battery', 97.0, 27.8, 0.0); C.pick('m_ch', 'medkit', 111.5, 28.4, 0.9);
  for (const [x, z] of [[92, 14], [108, 14], [108, 24], [92, 24], [100, 11]]) C.wp('chamber', x, z);

  // ---------------- escape tunnel + hatch + surface ----------------
  const ey = F(88, 5);
  P.pipes(86.2, 4.3, 91.9, 4.3, ey + 2.9, 2); P.wallDecal('exit', 89, ey + 2.95, 7, '-z', 1.5, 0.75); P.floorDecal('hazard', 89, 5.5, 5, 0.5, 0, { a: 0.9 });
  const ex = (x) => -10 + 5 * (x - 92) / 26;
  for (const x of [96, 112]) { P.pipe(x, ex(x) + 3.0, 4.15, x + 8, ex(x + 8) + 3.0, 4.15, 0.08); P.pipe(x, ex(x) + 2.7, 6.85, x + 8, ex(x + 8) + 2.7, 6.85, 0.05, { key: 'metal' }); }
  P.wallDecal('claws', 100, ex(100) + 1.4, 7, '-z', 1.5, 1.5, { a: 0.9 }); P.wallDecal('hands', 110, ex(110) + 1.2, 4, '+z', 1.5, 1.5, { a: 0.85 });
  C.fxEmit('steam', 98, ex(98) + 0.2, 4.6, {}); C.fxEmit('steam', 113, ex(113) + 0.2, 6.2, {}); C.fxEmit('drip', 102, ex(102) + 3.0, 5, {});
  const ez = (z) => -5 + 5 * (z - 7) / 23;
  P.pipe(117.2, ez(8) + 3.0, 8, 117.2, ez(29.5) + 3.0, 29.5, 0.08); P.pipe(119.8, ez(8) + 2.7, 8, 119.8, ez(29.5) + 2.7, 29.5, 0.06, { key: 'metal' });
  P.wallDecal('exit', 116, 2.6, 32, '+x', 1.6, 0.8);
  const hy = F(119, 34);
  P.crate(121.5, 31.2); P.barrel(116.9, 36.3); P.barrel(117.5, 36.7); P.hide('h_hatch', 'cabinet', 122.6, 34.5, 'w', { w: 1.0, d: 0.75, key: 'metal', t: [0.32, 0.32, 0.3] });
  P.wallDecal('hazard', 119, hy + 0.25, 38, '-z', 4, 0.3); P.wallDecal('poster', 116, hy + 1.8, 34.5, '+x', 1.1, 1.5); P.wallDecal('scorch', 119, hy + 1.6, 38, '-z', 3.2, 3.2, { a: 0.6 });
  P.floorDecal('splat2', 118.6, 33.5, 2.4, 2.4, 0.4); P.floorDecal('splat1', 120.6, 35.8, 1.4, 1.4, 1.9);
  C.dynObj('wheel', { metal: (mb) => { mb.torus(0.55, 0.05, 20, 6, { s: 1, t: [0.65, 0.2, 0.15] }); mb.box(-0.55, -0.03, -0.03, 0.55, 0.03, 0.03, { s: 1, t: [0.6, 0.18, 0.14] }); mb.box(-0.03, -0.55, -0.03, 0.03, 0.55, 0.03, { s: 1, t: [0.6, 0.18, 0.14] }); mb.cyl(0, 0, -0.02, 0.1, 0.12, 8, { s: 1, t: [0.5, 0.5, 0.5] }); } }, { x: 119, y: hy + 1.5, z: 37.8 });
  C.act('wheel', 'wheel', 119, 37.3, 1.5, 1.9, 'Hatch wheel', { hold: true });

  P.wallDecal('exit', 119, F(119, 42) + 4.6, 39, '+z', 1.6, 0.8);
  rubble(P, 112, 44, 8, 1.2); rubble(P, 121.5, 42, 6, 1.0); P.barrel(110.5, 40.5); P.barrel(122.5, 45.5); P.crate(114.5, 46.0);
  C.zone('outside', 111, 40, 123, 47);
  C.wp('chamber', 119, 20);
}
