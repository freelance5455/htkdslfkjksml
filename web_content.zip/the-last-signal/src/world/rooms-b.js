// Laboratory wing: corridors, break room, research room, secret room, service corridors, lockers, decon.
import { rubble, vending, cot, tank, rack } from './kit.js';

export function roomsLab(C) {
  const P = C.P, fy = C.fy, F = (x, z) => fy(x, z);
  // ---------------- lab corridor lc1..lc3 (x47..49) ----------------
  P.pipes(47.25, 36, 47.25, 12, F(48, 20) + 2.75, 2);
  cot(P, 47.55, 22.6, 'n');

  P.body(48.5, 14.6, 0, { t: [0.5, 0.48, 0.44] });
  P.hide('h_lab1', 'cabinet', 49.6, 22.2, 'w', { w: 1.0, d: 0.75, key: 'metal', t: [0.3, 0.34, 0.36] });
  P.hide('h_lab2', 'cabinet', 49.6, 33.4, 'w', { w: 1.0, d: 0.75, key: 'metal', t: [0.34, 0.34, 0.3] });
  P.with('metal', 49.9, 28.2, 'w', (mb) => { mb.box(-0.35, 1.1, -0.1, 0.35, 2.0, 0.1, { s: 1, t: [0.34, 0.36, 0.38] }); mb.box(-0.3, 1.15, 0.1, 0.3, 1.95, 0.12, { s: 1, t: [0.1, 0.11, 0.12] }); });
  C.lamps = [{ id: 'fusebox', x: 49.74, y: F(49, 28) + 1.75, z: 28.55 }];
  C.act('fusebox', 'fusebox', 49.7, 28.2, 1.5, 1.7, 'Fuse box E-3', { note: 'fusebox' });
  P.wallDecal('voltage', 50, F(49, 28) + 2.6, 28.2, '-x', 0.7, 0.7);
  P.wallDecal('staff', 47, F(47, 18.5) + 2.95, 18.9, '+x', 0.9, 0.45);
  P.wallDecal('hazard', 47.01, F(47, 30) + 0.12, 30, '+x', 4, 0.22);
  P.wallDecal('drips', 49.99, F(49, 16) + 1.6, 15.5, '-x', 0.9, 1.8, { a: 0.8 });
  P.wallDecal('claws', 47, F(47, 24) + 1.4, 24.0, '+x', 1.3, 1.3, { a: 0.9 });
  P.wallDecal('hands', 50, F(49, 33) + 1.2, 35.5, '-x', 1.0, 1.0, { a: 0.8 });
  for (const [x, z, r] of [[48.1, 35.2, 0.3], [48.6, 31.0, 1.4], [47.9, 27.0, 2.6], [48.3, 20.3, 0.8], [48.0, 17.0, 2.0], [48.5, 13.4, 0.1]]) P.floorDecal(r > 1.2 ? 'splat2' : 'splat1', x, z, 1.4, 1.4, r, { a: 0.85 });
  P.floorDecal('stain', 48.5, 24, 3, 12, 0, { a: 0.45 });
  C.wp('lab', 48, 31); C.wp('lab', 48, 22); C.wp('lab', 48, 15);

  // ---------------- break room (x36..45, z31..35) ----------------
  P.table(40.4, 33.2, 's', 1.6, 0.8); P.chair(39.4, 34.1, 'n'); P.chair(41.5, 34.2, 'n'); P.chair(40.4, 32.2, 's');
  vending(P, 36.5, 34.2, 'e');
  P.shelf(38.2, 35.65, 'n', { w: 1.8, d: 0.5, h: 2.2, n: 4 });
  P.hide('h_break', 'cabinet', 44.3, 31.4, 's', { w: 1.0, d: 0.75, key: 'metal', t: [0.32, 0.3, 0.34] });
  P.wallDecal('stain', 36, F(37, 33) + 1.2, 32.4, '+x', 1.6, 1.6, { a: 0.5 });
  P.floorDecal('splat1', 41.5, 33.6, 1.5, 1.5, 0.9); P.floorDecal('hands', 38, 33, 1.6, 1.6, 0.6, { a: 0.8 });
  C.pick('fuse', 'fuse', 38.5, 35.65, 2.16); C.pick('b_break', 'battery', 40.1, 33.1, 0.8);
  C.wp('lab', 41, 33);

  // ---------------- research room (x28..45, z13..29) ----------------
  P.with('wall', 40, 13.08, 's', (mb) => { mb.box(-1.6, 0.9, -0.06, 1.6, 2.25, 0.06, { s: 1, t: [0.85, 0.85, 0.82], ao0: 0.9 }); mb.box(-1.65, 0.86, -0.07, 1.65, 0.9, 0.12, { s: 1, t: [0.3, 0.3, 0.32] }); });
  P.with('wall', 40, 13.08, 's', (mb) => { for (let i = 0; i < 4; i++) mb.box(-1.1 + i * 0.6 - 0.12, 1.45, 0.061, -1.1 + i * 0.6 + 0.12, 1.69, 0.065, { s: 1, t: i === 0 || i === 3 ? [0.1, 0.1, 0.12] : [0.95, 0.95, 0.95] }); });
  C.act('whiteboard', 'note', 40, 13.7, 1.6, 2.2, 'Whiteboard', { note: 'whiteboard' });
  P.desk(30.6, 13.9, 's', { w: 1.6, screen: [0.5, 0.9, 1] }); P.chair(30.6, 15.0, 'n');
  P.desk(43.5, 13.9, 's', { w: 1.6, screen: [1, 0.7, 0.5] }); P.chair(43.5, 15.0, 'n');
  C.act('rao_note', 'note', 43.5, 14.6, 0.95, 1.9, 'Handwritten note', { note: 'rao_channel' });
  P.table(38.5, 18.6, 's', 7.5, 1.1, 0.95, 'metal'); P.table(38.5, 24.0, 's', 7.5, 1.1, 0.95, 'metal');
  P.with('metal', 38.5, 18.6, 's', (mb) => { for (let i = 0; i < 4; i++) mb.box(-3.2 + i * 1.8, 0.95, -0.2, -2.7 + i * 1.8, 1.25, 0.2, { s: 1, t: [0.3 + i * 0.08, 0.32, 0.36] }); });
  P.with('metal', 38.5, 24.0, 's', (mb) => { mb.cyl(-2.4, 0.95, 0, 0.18, 0.5, 8, { s: 1, t: [0.5, 0.55, 0.5] }); mb.box(0.2, 0.95, -0.3, 1.0, 1.15, 0.3, { s: 1, t: [0.2, 0.22, 0.25] }); });
  C.act('research1', 'note', 36.0, 19.7, 1.0, 1.9, 'Research log', { note: 'research1' });
  rack(P, 28.45, 16.0, 'e', 2); rack(P, 28.45, 20.3, 'e', 2);
  P.with('metal', 28.1, 23.3, 'e', (mb) => { mb.box(-0.45, 1.05, -0.05, 0.45, 1.6, 0.05, { s: 1, t: [0.25, 0.27, 0.3] }); });
  C.panel = { x: 28.18, y: F(28.5, 23.3) + 1.33, z: 23.3, zs: [22.97, 23.17, 23.37, 23.57] };
  C.act('panel', 'panel', 28.6, 23.3, 1.33, 1.8, 'Rack 7 service panel', {});
  for (const [x, z] of [[30.4, 28.4], [32.6, 28.4], [34.8, 28.4]]) tank(P, x, z, 0.55, 2.4, [0.25, 0.7, 0.4]);
  P.hide('h_res1', 'cabinet', 38.6, 29.6, 'n', { w: 1.0, d: 0.75, key: 'metal', t: [0.3, 0.34, 0.34] });
  P.hide('h_res2', 'cabinet', 43.2, 29.6, 'n', { w: 1.0, d: 0.75, key: 'metal', t: [0.34, 0.3, 0.3] });
  P.pipes(29, 13.3, 44, 13.3, F(36, 14) + 3.2, 3);
  P.wallDecal('poster', 46, F(44, 22) + 1.8, 22.0, '-x', 1.1, 1.5);
  P.wallDecal('scrawl', 46, F(44, 26) + 1.7, 26.0, '-x', 2.0, 1.0, { a: 0.9 });
  P.wallDecal('drips', 36, F(36, 29) + 1.5, 30.0, '-z', 1.0, 2.0, { a: 0.8 });
  P.wallDecal('exit', 33.5, F(34, 13) + 3.0, 13, '+z', 1.4, 0.7);
  for (const [x, z, r, n] of [[34, 21.2, 0.3, 'splat1'], [41.6, 26.2, 1.3, 'splat2'], [36.3, 16.2, 2.6, 'splat1'], [32.2, 24.5, 0.9, 'splat2']]) P.floorDecal(n, x, z, 2.0, 2.0, r, { a: 0.9 });
  P.floorDecal('stain', 38, 21, 14, 12, 0, { a: 0.4 });
  C.pick('b_res', 'battery', 31.4, 26.0, 0.0); C.pick('m_res', 'medkit', 44.4, 27.5, 0.05);
  C.wp('lab', 36, 21); C.wp('lab', 31, 15); C.wp('lab', 43, 26);

  // ---------------- secret room (x16..26, z15..22) ----------------
  P.desk(20.4, 20.9, 's', { w: 2.0, d: 0.8, screen: [0.9, 0.7, 0.3] }); P.chair(20.2, 19.8, 'n');
  cot(P, 24.4, 16.9, 'w');
  P.console(16.5, 18.6, 'e', { w: 1.8, tint: [1, 0.55, 0.2] });
  P.wallDecal('scrawl', 21.5, F(21, 16) + 1.7, 15, '+z', 2.2, 1.1, { a: 0.95 });
  P.wallDecal('poster', 26.99, F(26, 19.8) + 1.7, 20.1, '-x', 1.1, 1.5);
  P.stack(17.2, 21.1, { n: 2 }); P.crate(18.3, 21.4, { s: 0.7 });
  P.hide('h_secret', 'cabinet', 26.6, 21.4, 'w', { w: 1.0, d: 0.75, key: 'metal', t: [0.3, 0.3, 0.26] });
  P.floorDecal('splat2', 21.5, 17.5, 1.6, 1.6, 1.1, { a: 0.8 }); P.floorDecal('stain', 20, 18.5, 7, 6, 0.5, { a: 0.5 });
  C.pick('keycard3_s', 'keycard3', 19.5, 20.9, 0.78, { secret: true });
  C.pick('b_sec1', 'battery', 21.4, 20.9, 0.78); C.pick('m_sec', 'medkit', 24.4, 16.9, 0.52);
  C.act('n_secret', 'note', 20.4, 21.6, 0.95, 1.9, "Rao's diary", { note: 'secret', secret: true });
  C.wp('secret', 21, 18);

  // ---------------- service corridors sw, sj, se1, se2 (z9..11) ----------------
  P.pipes(30.2, 9.3, 46, 9.3, F(38, 10) + 2.8, 3); P.pipes(50, 11.7, 81.5, 11.7, F(60, 10) + 2.8, 3);
  P.pipes(66.2, 9.3, 81.5, 9.3, F(72, 10) + 2.6, 2, { key: 'metal' });
  P.hide('h_sw', 'cabinet', 38.2, 9.4, 's', { w: 1.0, d: 0.75, key: 'metal', t: [0.3, 0.32, 0.34] });
  P.hide('h_se1', 'cabinet', 58.4, 11.6, 'n', { w: 1.0, d: 0.75, key: 'metal', t: [0.34, 0.32, 0.3] });
  P.barrel(32.0, 10.6); P.barrel(32.7, 10.9); P.stack(44.6, 10.4); P.barrel(53.0, 9.6); P.barrel(53.7, 9.5); rubble(P, 64.5, 10.3, 5, 0.6); P.crate(75, 9.6);
  P.wallDecal('voltage', 41, F(40, 9) + 1.8, 9.0, '+z', 0.8, 0.8); P.wallDecal('drips', 62, F(62, 12) + 1.5, 12.0, '-z', 1.0, 2.0, { a: 0.8 });
  P.wallDecal('claws', 56, F(56, 9) + 1.4, 9.0, '+z', 1.4, 1.4, { a: 0.9 });
  for (const [x, z, r] of [[36, 10.3, 0.2], [43, 10.5, 1.1], [55, 10.4, 2.0], [68, 10.2, 0.6]]) P.floorDecal(r > 1 ? 'splat2' : 'splat1', x, z, 1.5, 1.5, r, { a: 0.85 });
  C.pick('b_sw', 'battery', 34.5, 10.6, 0.0);
  C.fxEmit('drip', 40.6, F(40, 10) + 2.9, 10.6, {}); C.fxEmit('drip', 62.0, F(62, 10) + 2.9, 10.2, {}); C.fxEmit('steam', 76, F(76, 10) + 0.4, 9.2, {});
  C.wp('lab', 38, 10.5); C.wp('service', 58, 10.5); C.wp('service', 72, 10.5);

  // ---------------- locker room (x51..58, z13..23) ----------------
  P.locker(54.5, 13.27, 's', 6);
  P.hide('h_lk1', 'locker', 52.2, 13.32, 's', { w: 0.6, d: 0.6, key: 'metal', t: [0.3, 0.4, 0.42] });
  P.hide('h_lk2', 'locker', 57.0, 13.32, 's', { w: 0.6, d: 0.6, key: 'metal', t: [0.4, 0.36, 0.3] });
  P.bench(54.5, 15.8, 's', 2.4); P.bench(54.5, 21.3, 'n', 2.4); P.body(57.2, 21.2, 0);
  P.wallDecal('drips', 51, F(51, 20) + 1.6, 20.5, '+x', 1.0, 2.0, { a: 0.8 }); P.wallDecal('hands', 59, F(58, 20) + 1.2, 21.6, '-x', 1.4, 1.4, { a: 0.8 });
  P.floorDecal('splat1', 54.2, 18.6, 2.0, 2.0, 0.4); P.floorDecal('splat2', 55.8, 20.4, 1.4, 1.4, 1.8, { a: 0.85 });
  C.pick('fuel', 'fuel', 54.5, 21.3, 0.5);
  C.wp('service', 55, 18);

  // ---------------- decon (x51..58, z27..34) ----------------
  for (let i = 0; i < 3; i++) { P.with('tile', 58.35, 28.0 + i * 1.35, 'w', (mb) => { mb.box(-0.55, 0, -0.5, 0.55, 2.3, 0.5, { s: 1.5, t: [0.7, 0.78, 0.74], ao0: 0.6 }); }); P.collide(58.35, 28.0 + i * 1.35, 'w', 1.0, 1.1); }
  P.bench(53.4, 33.0, 'n', 2.0); P.body(55.0, 30.6, 3);
  P.hide('h_dc', 'cabinet', 54.8, 34.6, 'n', { w: 1.0, d: 0.75, key: 'metal', t: [0.3, 0.36, 0.34] });
  P.wallDecal('hazard', 51.01, F(52, 28) + 0.14, 28.5, '+x', 2.4, 0.25); P.wallDecal('voltage', 51, F(52, 32) + 1.8, 32.8, '+x', 0.8, 0.8);
  P.floorDecal('splat2', 54.6, 31.2, 2.4, 2.4, 0.2); P.floorDecal('splat1', 52.8, 29.0, 1.4, 1.4, 1.4, { a: 0.85 }); P.floorDecal('hands', 56.6, 31.8, 1.6, 1.6, 2.4, { a: 0.8 });
  C.act('n_decon', 'note', 53.4, 33.0, 0.55, 1.8, 'Decon log', { note: 'decon' });
  C.pick('b_dc', 'battery', 52.7, 33.0, 0.5);
  C.wp('service', 55, 31);
}
