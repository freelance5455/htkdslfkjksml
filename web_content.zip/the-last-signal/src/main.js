// Entry point: boots the renderer, procedural assets, world, audio, input and UI, then runs the game loop.
import { Renderer, QUALITY } from './engine/renderer.js';
import { createMaterials } from './engine/materials.js';
import { World } from './world/world.js';
import { populate } from './world/content.js';
import { makeDecalMaterial } from './world/decals.js';
import { installDyn } from './world/dyn.js';
import { Input } from './game/input.js';
import { AudioEngine } from './audio/engine.js';
import { UI } from './game/ui.js';
import { Game } from './game/game.js';
import { loadSettings, readSave, hasSave } from './game/state.js';

const params = new URLSearchParams(location.search);
const $ = (id) => document.getElementById(id);
const coarse = () => { try { return matchMedia('(pointer:coarse)').matches; } catch { return false; } };

function pickTier(s) {
  if (s.quality && s.quality !== 'auto' && QUALITY[s.quality]) return s.quality;
  const forced = params.get('q'); if (forced && QUALITY[forced]) return forced;
  if (!coarse()) return 'high';
  const mem = navigator.deviceMemory || 4;
  return mem <= 2 ? 'low' : 'medium';
}
const mmss = (s) => { s = Math.floor(s); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };

let ui = null, booting = true;
function fatal(msg) {
  console.error(msg);
  if (ui) ui.bootError(msg); else { const e = $('boot-err'); if (e) { e.textContent = msg; e.classList.remove('hidden'); } }
  $('boot')?.classList.remove('hidden');
}
addEventListener('error', (e) => { if (booting) fatal('Error: ' + (e.message || e.error)); else console.error(e.error || e.message); });
addEventListener('unhandledrejection', (e) => { if (booting) fatal('Error: ' + (e.reason && e.reason.message || e.reason)); else console.error(e.reason); });

const tick = () => new Promise((r) => setTimeout(r, 0));

async function main() {
  const settings = loadSettings();
  ui = new UI(settings);
  ui.boot(0.02, 'Starting graphics engine');
  await tick();
  let R;
  const canvas = $('gl'), tier = pickTier(settings);
  try { R = new Renderer(canvas, { quality: tier, preserve: params.has('preserve') }); }
  catch (e) { fatal(String(e && e.message || e) + '  — THE LAST SIGNAL needs a browser with WebGL2 (Chrome on Android 8+ works).'); return; }
  const dpr = () => window.devicePixelRatio || 1;
  R.resize(innerWidth, innerHeight, dpr());

  ui.boot(0.06, 'Forging textures');
  const decal = makeDecalMaterial(R, tier === 'low' ? 512 : 1024);
  const mats = await createMaterials(R, tier, (f) => ui.boot(0.06 + f * 0.5), { decal });
  ui.boot(0.6, 'Building Vajra Deep'); await tick();
  const world = new World();
  world.build(R, mats, populate);
  installDyn(world);
  ui.boot(0.82, 'Tuning the dark'); await tick();

  const input = new Input($('ui'));
  const E = new AudioEngine();
  const game = new Game({ R, world, mats, input, E, settings, ui });
  ui.sfx = game.sfx;
  game.debug = params.has('debug');
  window.__tls = { game, R, world, ui, input, E, settings };

  // ---------------------------------------------------------------- audio unlock (needs a user gesture; never asks for the microphone)
  let audioTried = false;
  const unlock = () => {
    if (!audioTried) { audioTried = E.init() || E.failed; if (E.ready) { game.applySettings(); game.scape.build(); E.setReverb(0.5); } }
    E.resume();
  };
  ui.on.unlock = unlock;
  for (const ev of ['keydown', 'touchend', 'pointerup']) addEventListener(ev, unlock, { passive: true });

  // ---------------------------------------------------------------- full screen / orientation (Android Chrome)
  const goFull = () => {
    if (!coarse()) return;
    const el = document.documentElement;
    try { if (!document.fullscreenElement && el.requestFullscreen) el.requestFullscreen({ navigationUI: 'hide' }).then(() => { try { screen.orientation && screen.orientation.lock && screen.orientation.lock('landscape').catch(() => {}); } catch { /* ignore */ } }).catch(() => {}); } catch { /* ignore */ }
  };

  // ---------------------------------------------------------------- menu / screen actions
  const menuInfo = () => { const s = readSave(); return s ? `${mmss(s.playTime)} · ${s.deaths} death${s.deaths === 1 ? '' : 's'}` : ''; };
  const showMenu = () => ui.showMenu(hasSave(), menuInfo());
  Object.assign(ui.on, {
    start: () => { goFull(); game.newGame(); },
    continue: () => { if (!hasSave()) return; goFull(); game.continueGame(); },
    resume: () => game.resume(),
    'pause-inv': () => ui.openInventory(game.invCtl()),
    'restart-cp': () => game.restartCp(),
    'to-menu': () => { game.toMenu(); showMenu(); },
    retry: () => game.retry(),
    'replay-end': () => { game.newGame(); },
    settings: (k) => {
      game.applySettings();
      if (k === 'quality' || k === 'all') applyQuality();
    },
  });
  // graphics quality ('auto' follows the device and lets the frame-time governor step down if needed)
  function applyQuality() {
    const t = pickTier(settings);
    if (t !== R.qname) { R.setQuality(t); R.resize(innerWidth, innerHeight, dpr()); game.fx.setDust(Math.round(70 * R.q.particles) + 14, { x: 9, y: 1.6, z: 63, yaw: 0 }); }
    game.perf.slow = 0; ui.applySettings(settings);
  }

  // ---------------------------------------------------------------- resize / orientation / visibility
  const onResize = () => {
    R.resize(innerWidth, innerHeight, dpr());
    const portrait = coarse() && innerHeight > innerWidth * 1.05;
    ui.setRotate(portrait);
    if (portrait && game.mode === 'play') game.pause();
  };
  addEventListener('resize', onResize); addEventListener('orientationchange', () => setTimeout(onResize, 120));
  if (window.visualViewport) window.visualViewport.addEventListener('resize', onResize);
  onResize();
  const goBackground = () => { if (game.mode === 'play') game.pause(); if (E.ctx && E.ctx.state === 'running') { try { E.ctx.suspend(); } catch { /* ignore */ } } };
  document.addEventListener('visibilitychange', () => { if (document.hidden) goBackground(); else E.resume(); });
  addEventListener('pagehide', goBackground);
  addEventListener('blur', () => { if (game.mode === 'play' && coarse()) game.pause(); });
  document.addEventListener('fullscreenchange', () => setTimeout(onResize, 150));

  // ---------------------------------------------------------------- WebGL context loss
  R.onLost = () => { ui.toast('Graphics context lost - restoring...', 'bad', 6000); if (game.mode === 'play') game.pause(); };
  R.onRestored = () => { ui.toast('Graphics restored', undefined, 2000); };

  // ---------------------------------------------------------------- main loop
  let last = performance.now(), errs = 0;
  const loop = (now) => {
    requestAnimationFrame(loop);
    const dt = Math.min(0.1, Math.max(0, (now - last) / 1000)); last = now;
    if (R.lost || document.hidden) return;
    try { game.frame(dt); }
    catch (e) {
      errs++; if (errs <= 5) console.error('frame error', e);
      if (errs === 5) ui.toast('A rendering error occurred (see console).', 'bad', 5000);
      if (errs > 600) { fatal('Fatal error: ' + (e && e.message || e)); }
    }
  };
  showMenu();
  ui.boot(1, 'Ready');
  await tick();
  ui.bootDone(); booting = false;
  requestAnimationFrame((t) => { last = t; loop(t); });
  window.__ready = true;
  // installable + offline: only over http(s) (a file:// copy is already self-contained). Add ?nosw=1 to skip.
  if (/^https?:$/.test(location.protocol) && !/[?&]nosw=1/.test(location.search)) {
    const l = document.createElement('link'); l.rel = 'manifest'; l.href = 'manifest.webmanifest'; document.head.appendChild(l);
    if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(() => { /* offline support is optional */ });
  }
}

main().catch((e) => { fatal('Failed to start: ' + (e && e.stack || e)); window.__ready = true; window.__error = String(e && e.stack || e); });
