// What happens when the player uses something: pickups, documents, keypads, fuse box, rack panel, generator, array console, hatch wheel.
import { CODES, NOTES, STATIONS, TUNING } from './data.js';
import { ITEM_INFO } from '../world/items.js';

const GEN = [70, 21.5], BRK = [70, 13.4], ARR_CON = [102.3, 26.6], FUSE = [49.7, 28.2];

export function activate(game, tgt) {
  if (!tgt) return;
  const S = game.state;
  if (tgt.type === 'pickup') return pickup(game, tgt.obj);
  if (tgt.type === 'hide') return game.beginHide(tgt.obj);
  const a = tgt.obj;
  switch (a.kind) {
    case 'note': return readNote(game, a.note, a);
    case 'keypad': return keypad(game, a);
    case 'fusebox': if (S.flag('fuseInstalled')) game.toast('The fuse is in. Lab Wing power is on.'); else if (S.has('fuse')) installFuse(game); else { readNote(game, 'fusebox'); game.toast('A 20A cartridge fuse is missing.'); } return;
    case 'panel': return panel(game);
    case 'breaker': return breaker(game, a);
    case 'fuelport': return fuelport(game);
    case 'console': return arrayConsole(game);
    default: break;
  }
}

export function pickup(game, p) {
  const S = game.state, info = ITEM_INFO[p.type] || { name: p.type };
  p.taken = true; S.taken[p.id] = true;
  if (p.type === 'battery') { S.items.battery = (S.items.battery || 0) + 1; game.toast(`Battery picked up  (x${S.items.battery})`); }
  else if (p.type === 'medkit') { S.items.medkit = (S.items.medkit || 0) + 1; game.toast(`Medkit picked up  (x${S.items.medkit})`); }
  else { S.keys[p.type] = true; game.toast(`${info.name} acquired`, 'key'); }
  if (p.secret) { S.secrets++; game.toast('Secret found', 'key'); }
  game.sfx.pickup(p.type);
  game.story.onPickup(p);
}

export function readNote(game, id, a) {
  const S = game.state, n = NOTES[id]; if (!n) return;
  const first = S.addNote(id);
  game.sfx.pickup('note');
  game.ui.openNote(n, () => game.story.onNoteClosed(id, first));
  if (first) { game.toast('Document added to inventory'); if (a?.secret) S.secrets++; game.story.onNote(id); }
}

function keypad(game, a) {
  const S = game.state, code = CODES[a.code], done = a.code === 'locker' ? 'lockerOpen' : 'cageOpen';
  if (S.flag(done)) { game.toast(a.code === 'locker' ? 'Locker 4 is empty.' : 'The cage is already open.'); return; }
  game.ui.openKeypad({
    title: a.label, len: code.length,
    verify: (s) => { const ok = s === code; if (!ok) { game.noise(a.x, a.z, 7, 'door'); } return ok; },
    onOk: () => {
      S.set(done); game.sfx.keyOk();
      if (a.code === 'locker') { S.keys.keycard1 = true; game.toast('Locker open. Level 1 keycard acquired', 'key'); game.story.onPickup({ type: 'keycard1', id: 'locker4' }); }
      else { game.openCage(true); game.toast('Cage unlocked'); }
    },
  });
}

function installFuse(game) {
  const S = game.state, w = game.world;
  S.keys.fuse = false; S.set('fuseInstalled'); w.setCircuit('lab', 1);
  game.sfx.spark(FUSE[0], FUSE[1]); game.sfx.surge(FUSE[0], FUSE[1], 0.6); game.surge(1.4);
  game.noise(FUSE[0], FUSE[1], 34, 'gen', true);
  game.toast('Fuse installed. The Lab Wing hums to life.', 'key');
  game.story.onProgress('fuseInstalled');
}

function panel(game) {
  const S = game.state, P = S.puzzle;
  if (S.flag('panelSolved')) { game.toast('The rack door is already released.'); return; }
  if (!P.panel) P.panel = [0, 1, 1, 0];
  game.ui.openPanel({
    state: P.panel, solution: CODES.panel,
    onToggle: (i) => { P.panel[i] ^= 1; game.sfx.switchClick(28.5, 23.3); },
    onSolved: () => {
      S.set('panelSolved'); const d = game.world.grid.doors[game.world.grid.doorIndex.d_secret];
      game.world.unlockDoor(d); game.world.setDoor(d, true); d.stay = true;
      game.sfx.keyOk(); game.toast('A latch releases somewhere behind the rack...', 'key'); game.noise(28, 23, 14, 'door');
    },
  });
}

function breaker(game, a) {
  const S = game.state, P = S.puzzle, C = game.world.content;
  if (S.flag('breakersOk')) { game.toast('Breakers reset. The panel is humming.'); return; }
  P.br = P.br || [];
  if (P.br.includes(a.n)) { game.toast(`Breaker ${a.n} is already down.`); return; }
  P.br.push(a.n); C.objs['br' + a.n].tgt = 1.15; game.sfx.switchClick(a.x, a.z);
  const ok = P.br.every((v, i) => v === CODES.breakers[i]);
  if (!ok) {
    game.sfx.spark(BRK[0], BRK[1]); game.fx.sparks(a.x, a.y + 0.2, a.z - 0.3, 22); game.noise(BRK[0], BRK[1], 22, 'gen');
    game.toast('Wrong order. The breakers trip!'); game.shake(0.5); game.glitch(0.5);
    game.later(0.7, () => { for (const n of P.br) C.objs['br' + n].tgt = 0; P.br = []; });
  } else if (P.br.length === 3) {
    S.set('breakersOk'); for (const n of [1, 2, 3]) C.objs['br' + n].tint = [0.2, 1.2, 0.4];
    game.sfx.keyOk(); game.toast('Breakers reset. The panel hums.', 'key'); game.story.onProgress('breakersOk');
  } else game.toast(`Breaker ${a.n} reset  (${P.br.length}/3)`);
}

function fuelport(game) {
  const S = game.state;
  if (S.flag('genFueled')) { game.toast('The tank is full.'); return; }
  if (!S.has('fuel')) { game.toast('Fuel intake. The tank is empty.'); return; }
  S.keys.fuel = false; S.set('genFueled'); game.sfx.pickup('fuel'); game.toast('You pour the diesel in. Tank full.', 'key'); game.story.onProgress('genFueled');
  const E = game.E; if (E.ready) { const o = E.spatial(74.9, 21, { vol: 0.9 }).in, t = E.now; for (let i = 0; i < 6; i++) E.burst(o, 'pink', 'bandpass', 400 + i * 40, 300, 3, 0.2, 0.5, t + i * 0.2); }
}

function arrayConsole(game) {
  const S = game.state, P = S.puzzle;
  if (S.flag('arrayDone')) { game.toast('The Array is silent.'); return; }
  if (game.consoleLock > 0) { game.toast('Console recovering from the surge...'); return; }
  if (!P.dials) P.dials = [0, 0, 0];
  game.ui.openArray({
    dials: P.dials, code: CODES.null,
    onEngage: (ok) => { if (ok) arraySilenced(game); else arrayFail(game); },
    onDial: () => game.sfx.key(1),
  });
}
function arrayFail(game) {
  const C = game.world.content;
  game.sfx.surge(); game.surge(2.2); game.shake(0.9); game.glitch(1.2); game.consoleLock = 7;
  game.noise(ARR_CON[0], ARR_CON[1], 95, 'surge', true); game.toast('SURGE. Wrong sequence. It heard that.', 'bad');
  const core = C.objs.core; if (core) { core.tint = [1.6, 0.2, 0.1]; game.later(3.5, () => { if (!game.state.flag('arrayDone')) core.tint = [1, 1, 1]; }); }
  for (const r of C.array.rings) r.surge = 3;
  game.story.onSurge();
}
function arraySilenced(game) {
  const S = game.state, w = game.world, C = w.content;
  S.set('arrayDone'); S.set('escape');
  game.sfx.keyOk(); game.sfx.surge(undefined, undefined, 0.7); game.shake(0.6);
  const d = w.grid.doors[w.grid.doorIndex.d_esc]; w.unlockDoor(d); w.setDoor(d, true); d.stay = true;
  w.setCircuit('emerg', 1); game.story.onProgress('arrayDone');
}

// ---- hold-to-use interactions (generator starter, hatch wheel) -------------
export function holdTick(game, dt, tgt, held) {
  const S = game.state, C = game.world.content;
  const h = game.hold;
  if (!held || !tgt || tgt.type !== 'act' || !tgt.obj.hold) { if (h) { game.hold = null; game.releaseHold(h.kind); } return null; }
  const a = tgt.obj, kind = a.kind;
  const deny = (msg) => { if (!h) { if (msg) game.toast(msg); game.hold = { kind: 'x', t: 0 }; } return 0; };
  if (kind === 'starter') {
    if (S.flag('gen')) return deny('The generator is running.');
    if (!S.flag('genFueled')) return deny('Nothing happens. The tank is empty.');
    if (!S.flag('breakersOk')) return deny('The starter clicks. The breakers are tripped.');
  }
  if (kind === 'wheel' && S.flag('exitWheel')) return deny('');
  if (kind === 'wheel' && !S.flag('escape')) return deny('The wheel is locked.');
  const need = kind === 'starter' ? 2.8 : 5.2;
  let cur = h && h.kind === kind ? h : (game.hold = { kind, t: 0, n: 0 });
  if (cur.kind === 'x') return 0;
  cur.t += dt; cur.n -= dt;
  const o = C.objs[kind];
  if (kind === 'starter') { o.y = o.y0 - Math.min(0.28, cur.t * 0.5) + Math.sin(cur.t * 40) * 0.01; game.shake(0.12); }
  else { o.rz += dt * 1.6; }
  if (cur.n <= 0) {
    cur.n = kind === 'starter' ? 0.32 : 0.8;
    if (kind === 'starter') { game.sfx.stamp(GEN[0], GEN[1], 0.6); game.noise(GEN[0], GEN[1], 28, 'gen'); }
    else { game.sfx.wheel(a.x, a.z); game.noise(a.x, a.z, 22, 'gen'); }
  }
  if (cur.t >= need) {
    game.hold = null;
    if (kind === 'starter') {
      o.y = o.y0; S.set('gen'); game.world.setCircuit('gen', 1); game.sfx.generator(GEN[0], GEN[1]); game.surge(1.2); game.shake(0.8);
      game.noise(GEN[0], GEN[1], 70, 'gen', true); game.toast('The generator roars to life. Power restored.', 'key'); game.story.onProgress('gen');
    } else {
      S.set('exitWheel'); const d = game.world.grid.doors[game.world.grid.doorIndex.d_exit]; game.world.unlockDoor(d); game.world.setDoor(d, true); d.stay = true;
      game.sfx.stamp(a.x, a.z, 1.2); game.toast('The hatch unseals. GO!', 'key'); game.story.onProgress('exitWheel');
    }
    return 1;
  }
  return cur.t / need;
}

// ---- radio -------------------------------------------------------------------
export function radioStation(freq) { return STATIONS.find((s) => Math.abs(s.f - freq) < 0.16) || null; }
export const radioSignal = (freq) => { let best = 9; for (const s of STATIONS) best = Math.min(best, Math.abs(s.f - freq)); return best; };
export { TUNING };
