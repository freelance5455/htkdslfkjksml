// Game progress state, checkpoint saves and user settings. No DOM/GL dependencies except localStorage (guarded).
import { TUNING } from './data.js';

export const DEFAULT_SETTINGS = {
  quality: 'auto', sens: 1, invertY: false, master: 0.9, music: 0.7, sfx: 1, mute: false, brightness: 1, vibration: true,
  subtitles: true, stickSprint: true, leftHanded: false, headBob: true, shake: true, fov: 72, hints: true,
};

export const STORE = (() => {
  const mem = {};
  const ok = (() => { try { const k = '__t'; localStorage.setItem(k, '1'); localStorage.removeItem(k); return true; } catch { return false; } })();
  return {
    get(k) { try { return ok ? localStorage.getItem(k) : (mem[k] ?? null); } catch { return mem[k] ?? null; } },
    set(k, v) { try { if (ok) localStorage.setItem(k, v); else mem[k] = v; } catch { mem[k] = v; } },
    del(k) { try { if (ok) localStorage.removeItem(k); else delete mem[k]; } catch { delete mem[k]; } },
  };
})();

export function loadSettings() {
  try { const raw = STORE.get('tls.settings'); if (raw) return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) }; } catch { /* ignore */ }
  return { ...DEFAULT_SETTINGS };
}
export function saveSettings(s) { STORE.set('tls.settings', JSON.stringify(s)); }

export class GameState {
  constructor() { this.reset(); }
  reset() {
    this.flags = {};                       // story / puzzle flags
    this.items = { battery: 1, medkit: 0 };// stackable counts; one-off keys are flags in .keys
    this.keys = {};                        // fuse, fuel, keycard1, keycard3 -> true
    this.notes = [];                       // ids of collected documents (in order)
    this.taken = {};                       // pickup ids already collected
    this.objective = 'start';
    this.stage = 0;                        // monster pacing stage (0..5)
    this.health = TUNING.health; this.battery = 100; this.stamina = TUNING.stamina;
    this.playTime = 0; this.deaths = 0; this.secrets = 0;
    this.pos = null;                       // {x,z,yaw}
    this.circ = null; this.doors = null; this.puzzle = {};
    this.checkpoint = 'start';
  }
  has(k) { return !!this.keys[k]; }
  flag(k) { return !!this.flags[k]; }
  set(k, v = true) { this.flags[k] = v; }
  addNote(id) { if (!this.notes.includes(id)) { this.notes.push(id); return true; } return false; }
  serialize() {
    return JSON.stringify({ v: 1, flags: this.flags, items: this.items, keys: this.keys, notes: this.notes, taken: this.taken, objective: this.objective, stage: this.stage, health: this.health, battery: this.battery, playTime: this.playTime, deaths: this.deaths, secrets: this.secrets, pos: this.pos, circ: this.circ, doors: this.doors, puzzle: this.puzzle, checkpoint: this.checkpoint });
  }
  static parse(json) {
    const o = JSON.parse(json), s = new GameState();
    if (!o || o.v !== 1) throw new Error('bad save');
    Object.assign(s, { flags: o.flags || {}, items: o.items || {}, keys: o.keys || {}, notes: o.notes || [], taken: o.taken || {}, objective: o.objective || 'start', stage: o.stage | 0, health: o.health ?? 100, battery: o.battery ?? 100, playTime: o.playTime || 0, deaths: o.deaths | 0, secrets: o.secrets | 0, pos: o.pos || null, circ: o.circ || null, doors: o.doors || null, puzzle: o.puzzle || {}, checkpoint: o.checkpoint || 'start' });
    return s;
  }
}

export const SAVE_KEY = 'tls.save.v1';
export const hasSave = () => { try { const raw = STORE.get(SAVE_KEY); if (!raw) return false; GameState.parse(raw); return true; } catch { return false; } };
export function writeSave(state) { STORE.set(SAVE_KEY, state.serialize()); }
export function readSave() { try { const raw = STORE.get(SAVE_KEY); return raw ? GameState.parse(raw) : null; } catch { return null; } }
export function clearSave() { STORE.del(SAVE_KEY); }
