// DOM user interface: boot screen, menu, settings, HUD, prompts, subtitles, toasts and the modal cards (documents, keypad, panels, radio, bag).
import { DEFAULT_SETTINGS, saveSettings } from './state.js';
import { ITEM_INFO } from '../world/items.js';
import { NOTES } from './data.js';

const $ = (id) => document.getElementById(id);
const FMT = { sens: (v) => v.toFixed(2) + '×', brightness: (v) => Math.round(v * 100) + '%', fov: (v) => Math.round(v) + '°', master: (v) => Math.round(v * 100) + '%', music: (v) => Math.round(v * 100) + '%', sfx: (v) => Math.round(v * 100) + '%' };
const mmss = (s) => { s = Math.floor(s); const m = Math.floor(s / 60); return m + ':' + String(s % 60).padStart(2, '0'); };

export class UI {
  constructor(settings) {
    this.settings = settings; this.on = {}; this.sfx = null; this.modal = null; this.modalFreeze = false; this.answerShown = false; this._onClose = null; this._radioTimer = 0;
    this.last = {}; this.el = {};
    for (const id of ['boot', 'boot-fill', 'boot-msg', 'boot-err', 'menu', 'settings', 'controls', 'rotate', 'hud', 'pause', 'gameover', 'complete', 'modal', 'toasts', 'titlecard', 'prompt', 'pr-verb', 'pr-label', 'pr-hold', 'pr-fill', 'cross', 'subs', 'sub-who', 'sub-txt', 'obj-txt', 'objective', 'hp-fill', 'hp-txt', 'st-fill', 'bt-fill', 'bt-txt', 'nz-fill', 'q-bt', 'q-md', 'actions', 'hidebtns', 'slit', 'btn-answer', 'cpicon', 'btn-use', 'btn-flash', 'btn-crouch', 'btn-batt', 'btn-med', 'br-fill', 'flashfx', 'threatfx', 'debug', 'pause-obj', 'go-tip', 'cp-stats', 'btn-continue', 'cont-sub', 'menu-q', 'wavepath']) this.el[id] = $(id);
    this._bindActions(); this._bindSettings(); this._wave();
    this.applySettings(settings);
  }
  // ---------------------------------------------------------------- generic
  show(id) { this.el[id]?.classList.remove('hidden'); } hide(id) { this.el[id]?.classList.add('hidden'); }
  _bindActions() {
    document.addEventListener('click', (e) => {
      const b = e.target.closest('[data-act]'); if (!b) return;
      const a = b.dataset.act; if (this.on.unlock) this.on.unlock();
      this.sfx?.ui(a.startsWith('close') || a === 'resume' ? 'back' : 'tap');
      switch (a) {
        case 'settings': this.show('settings'); break;
        case 'controls': this.show('controls'); break;
        case 'close-settings': this.hide('settings'); break;
        case 'close-controls': this.hide('controls'); break;
        case 'close-modal': this.closeModal(); break;
        case 'reset-settings': Object.assign(this.settings, DEFAULT_SETTINGS); saveSettings(this.settings); this.applySettings(this.settings); this.on.settings?.('all'); break;
        default: this.on[a]?.();
      }
    });
    addEventListener('pointerdown', () => { this.on.unlock?.(); }, { once: false, passive: true });
  }
  _wave() {
    const p = this.el.wavepath; if (!p) return; let t = 0;
    const tick = () => { if (!this.el.menu.classList.contains('hidden')) { t += 0.06; let d = 'M0 20'; for (let x = 0; x <= 400; x += 5) { const e = Math.exp(-Math.pow((x - 200) / 90, 2)); d += ` L${x} ${20 + Math.sin(x * 0.12 + t * 3) * 14 * e * Math.sin(t * 1.3 + x * 0.02) + (Math.random() - 0.5) * 3 * (1 - e * 0.6)}`; } p.setAttribute('d', d); } this._wv = setTimeout(tick, 60); };
    tick();
  }
  // ---------------------------------------------------------------- boot
  boot(frac, msg) { this.el['boot-fill'].style.width = Math.round(frac * 100) + '%'; if (msg) this.el['boot-msg'].textContent = msg; }
  bootError(msg) { this.el['boot-err'].textContent = msg; this.show('boot-err'); this.el['boot-msg'].textContent = 'Cannot start'; }
  bootDone() { this.hide('boot'); }
  setRotate(on) { this.el.rotate.classList.toggle('hidden', !on); }
  // ---------------------------------------------------------------- menu / screens
  showMenu(hasSave, info) {
    for (const id of ['hud', 'pause', 'gameover', 'complete', 'settings', 'controls']) this.hide(id);
    this.closeModal(true); this.show('menu');
    this.el['btn-continue'].classList.toggle('off', !hasSave); this.el['cont-sub'].textContent = hasSave ? (info || 'CHECKPOINT') : '';
    this.el['menu-q'].textContent = 'GRAPHICS: ' + String(this.settings.quality).toUpperCase();
  }
  setPlaying(b) {
    if (b) { this.hide('menu'); this.hide('gameover'); this.hide('complete'); this.hide('pause'); this.show('hud'); } else { this.hide('hud'); }
    this.el.hud.classList.toggle('lefty', !!this.settings.leftHanded);
  }
  showPause() { this.show('pause'); }
  hidePause() { this.hide('pause'); this.hide('settings'); this.hide('controls'); }
  showGameOver(tip) { this.hide('hud'); this.el['go-tip'].textContent = tip || ''; this.show('gameover'); }
  hideGameOver() { this.hide('gameover'); }
  showComplete(s) {
    this.hide('hud'); const c = this.el['cp-stats'];
    c.innerHTML = `<div><b>${mmss(s.time)}</b>TIME</div><div><b>${s.deaths}</b>DEATHS</div><div><b>${s.secrets}</b>SECRETS</div><div><b>${s.notes}/${s.total}</b>DOCUMENTS</div>`;
    this.show('complete');
  }
  flashScreen(a) { this.el.flashfx.style.opacity = a; if (a > 0) setTimeout(() => { this.el.flashfx.style.transition = 'opacity .6s'; this.el.flashfx.style.opacity = 0; setTimeout(() => { this.el.flashfx.style.transition = ''; }, 700); }, 60); }
  // ---------------------------------------------------------------- settings
  _bindSettings() {
    const s = this.settings, root = $('settings');
    root.querySelectorAll('[data-set]').forEach((el) => {
      const k = el.dataset.set;
      const commit = () => { saveSettings(s); this.on.settings?.(k); this._refreshSettings(); };
      if (el.classList.contains('seg')) el.addEventListener('click', (e) => { const b = e.target.closest('button'); if (!b) return; s[k] = b.dataset.v; commit(); });
      else if (el.type === 'range') el.addEventListener('input', () => { s[k] = parseFloat(el.value); commit(); });
      else if (el.classList.contains('tog')) el.addEventListener('click', () => { s[k] = !s[k]; commit(); });
    });
  }
  _refreshSettings() {
    const s = this.settings;
    $('settings').querySelectorAll('[data-set]').forEach((el) => {
      const k = el.dataset.set, v = s[k];
      if (el.classList.contains('seg')) el.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.v === v));
      else if (el.type === 'range') { el.value = v; const o = el.parentElement.querySelector('output'); if (o) o.textContent = (FMT[k] || String)(v); }
      else if (el.classList.contains('tog')) el.classList.toggle('on', !!v);
    });
    this.el.hud.classList.toggle('lefty', !!s.leftHanded);
    this.el['menu-q'].textContent = 'GRAPHICS: ' + String(s.quality).toUpperCase();
  }
  applySettings(s) { this.settings = s; this._refreshSettings(); }
  // ---------------------------------------------------------------- HUD
  hud(d) {
    const L = this.last, e = this.el;
    const set = (key, v, fn) => { if (L[key] !== v) { L[key] = v; fn(v); } };
    set('hp', Math.round(d.health), (v) => { e['hp-fill'].style.transform = `scaleX(${v / 100})`; e['hp-txt'].textContent = v; e['hp-fill'].closest('.bar').classList.toggle('low', v < 30); });
    set('st', Math.round(d.stamina), (v) => { e['st-fill'].style.transform = `scaleX(${v / 100})`; });
    set('ex', d.exhausted, (v) => e['st-fill'].closest('.bar').classList.toggle('out', v));
    set('bt', Math.round(d.battery), (v) => { e['bt-fill'].style.transform = `scaleX(${v / 100})`; e['bt-txt'].textContent = v + '%'; e['bt-fill'].closest('.bar').classList.toggle('low', v < 20); });
    set('nz', Math.round(d.noise * 20), (v) => { e['nz-fill'].style.transform = `scaleX(${v / 20})`; });
    set('qb', d.items.battery | 0, (v) => { e['q-bt'].textContent = v; e['btn-batt'].classList.toggle('empty', !v); });
    set('qm', d.items.medkit | 0, (v) => { e['q-md'].textContent = v; e['btn-med'].classList.toggle('empty', !v); });
    set('fl', d.on, (v) => e['btn-flash'].classList.toggle('on', v));
    set('cr', d.crouch, (v) => e['btn-crouch'].classList.toggle('on', v));
    set('hd', d.hidden, (v) => this.setHidden(v));
    if (d.hidden) { set('br', Math.round(d.breath * 50), (v) => { e['br-fill'].style.transform = `scaleX(${v / 50})`; }); }
    set('th', Math.round(d.threat * 20), (v) => { e.threatfx.style.opacity = v / 20 * 0.9; });
    if (d.save > 0.05) { if (!L.cp) { L.cp = true; e.cpicon.classList.add('show'); setTimeout(() => { e.cpicon.classList.remove('show'); L.cp = false; }, 2400); } }
  }
  setHidden(b) { this.el.slit.classList.toggle('hidden', !b); this.el.hidebtns.classList.toggle('hidden', !b); this.el.actions.classList.toggle('hidden', b); this.last.hd = b; }
  prompt(verb, label, prog, hint) {
    const e = this.el, L = this.last, key = `${verb}|${label}|${hint ? 1 : 0}`;
    if (!verb && !label) { if (L.pk) { L.pk = ''; e.prompt.classList.add('hidden'); e.cross.classList.remove('act'); e['btn-use'].classList.remove('ready'); } return; }
    if (L.pk !== key) { L.pk = key; e.prompt.classList.remove('hidden'); e.prompt.classList.toggle('hint', !!hint); e['pr-verb'].textContent = verb || ''; e['pr-label'].textContent = label || ''; e.cross.classList.toggle('act', !!verb); e['btn-use'].classList.toggle('ready', !!verb); }
    const hp = prog !== null && prog !== undefined;
    e['pr-hold'].classList.toggle('on', hp); if (hp) e['pr-fill'].style.width = Math.round(Math.min(1, prog) * 100) + '%';
  }
  objective(text, flash) {
    if (!text) return;
    this.el['obj-txt'].textContent = text; this.el['pause-obj'].textContent = text;
    if (flash) { const o = this.el.objective; o.classList.remove('flash'); void o.offsetWidth; o.classList.add('flash'); }
  }
  subtitle(who, text, dur = 3.5, mimic = false) {
    const s = this.el.subs; this.el['sub-who'].textContent = who || ''; this.el['sub-txt'].textContent = text;
    s.classList.remove('hidden'); s.classList.toggle('rao', who === 'DR. RAO' || who === 'RADIO' || who === 'CARRIER'); s.classList.toggle('mimic', !!mimic);
    clearTimeout(this._st); this._st = setTimeout(() => s.classList.add('hidden'), dur * 1000);
  }
  toast(text, kind, ms = 3200) {
    const box = this.el.toasts;
    for (const old of box.children) if (old.textContent === text) { clearTimeout(old._t1); clearTimeout(old._t2); old.classList.remove('out'); old._t1 = setTimeout(() => old.classList.add('out'), ms); old._t2 = setTimeout(() => old.remove(), ms + 600); return; }   // same message: refresh instead of stacking
    const d = document.createElement('div'); d.className = 'toast' + (kind ? ' ' + kind : ''); d.textContent = text; box.appendChild(d);
    while (box.children.length > 3) box.removeChild(box.firstChild);
    d._t1 = setTimeout(() => d.classList.add('out'), ms); d._t2 = setTimeout(() => d.remove(), ms + 600);
  }
  titleCard(a, b) { const t = this.el.titlecard; t.querySelector('small').textContent = a; t.querySelector('b').textContent = b; t.classList.remove('hidden', 'show'); void t.offsetWidth; t.classList.add('show'); setTimeout(() => { t.classList.add('hidden'); t.classList.remove('show'); }, 6300); }
  showAnswer(b) { this.answerShown = b; this.el['btn-answer'].classList.toggle('hidden', !b); }
  cpIcon() { /* shown via hud() save flag */ }
  debug(text) { const d = this.el.debug; d.classList.remove('hidden'); d.textContent = text; }

  // ---------------------------------------------------------------- modals
  _open(id, freeze, onClose) {
    this.closeModal(true); this.modal = id; this.modalFreeze = freeze; this._onClose = onClose || null;
    this.show('modal'); $(id).classList.remove('hidden'); this.sfx?.ui('open');
  }
  closeModal(silent) {
    if (!this.modal) return;
    const id = this.modal, cb = this._onClose; this.modal = null; this._onClose = null; this.modalFreeze = false;
    $(id).classList.add('hidden'); this.hide('modal'); clearInterval(this._radioTimer); clearTimeout(this._mt);
    if (cb && !silent) cb();
  }
  openNote(n, onClose) {
    $('note-title').textContent = n.kind === 'radio' ? '📻 ' + n.title : n.title; $('note-body').textContent = n.body;
    this._open('note', true, onClose); $('note-body').scrollTop = 0;
  }
  openKeypad(c) {
    const disp = $('kp-disp'), pad = $('kp-pad'); let code = '';
    $('kp-title').textContent = (c.title || 'KEYPAD').toUpperCase();
    const draw = () => { disp.innerHTML = ''; for (let i = 0; i < c.len; i++) { const x = document.createElement('i'); x.textContent = code[i] ? '●' : '–'; disp.appendChild(x); } };
    const reset = () => { code = ''; disp.className = ''; draw(); };
    reset();
    pad.onclick = (e) => {
      const b = e.target.closest('button'); if (!b || disp.classList.contains('ok') || disp.classList.contains('bad')) return; const k = b.dataset.k;
      if (k === 'x') { this.closeModal(); return; } if (k === 'c') { code = ''; draw(); this.sfx?.key(0); return; }
      if (code.length >= c.len) return; code += k; draw(); this.sfx?.key(code.length);
      if (code.length === c.len) {
        if (c.verify(code)) { disp.className = 'ok'; this.sfx?.keyOk(); this._mt = setTimeout(() => { this.closeModal(true); c.onOk(); }, 500); }
        else { disp.className = 'bad'; this.sfx?.keyBad(); this._mt = setTimeout(reset, 650); }
      }
    };
    this._open('keypad', false);
  }
  openPanel(c) {
    const row = $('pn-row'); row.innerHTML = '';
    const check = () => { if (c.state.every((v, i) => v === c.solution[i])) { this._mt = setTimeout(() => { this.closeModal(true); c.onSolved(); }, 450); } };
    'ABCD'.split('').forEach((ch, i) => {
      const b = document.createElement('button'); b.className = 'sw' + (c.state[i] ? ' on' : ''); b.innerHTML = `<span class="lamp"></span><span class="lever"></span><b>${ch}</b>`;
      b.onclick = () => { c.onToggle(i); b.classList.toggle('on', !!c.state[i]); check(); };
      row.appendChild(b);
    });
    this._open('panel', false);
  }
  openArray(c) {
    const row = $('ar-row'), msg = $('ar-msg'); row.innerHTML = ''; msg.className = 'hintline'; msg.textContent = 'SET THE THREE DIALS TO THE NULL SEQUENCE';
    const outs = [];
    c.dials.forEach((v, i) => {
      const d = document.createElement('div'); d.className = 'dial';
      const up = document.createElement('button'), o = document.createElement('output'), dn = document.createElement('button');
      up.textContent = '▲'; dn.textContent = '▼'; o.textContent = v; outs.push(o);
      up.onclick = () => { c.dials[i] = (c.dials[i] + 1) % 10; o.textContent = c.dials[i]; c.onDial?.(); };
      dn.onclick = () => { c.dials[i] = (c.dials[i] + 9) % 10; o.textContent = c.dials[i]; c.onDial?.(); };
      d.append(up, o, dn); row.appendChild(d);
    });
    $('ar-go').onclick = () => {
      const ok = c.dials.join('') === c.code; msg.className = 'hintline ' + (ok ? 'ok' : 'bad'); msg.textContent = ok ? 'SEQUENCE ACCEPTED' : 'WRONG SEQUENCE';
      $('ar-go').onclick = null; this._mt = setTimeout(() => { this.closeModal(true); c.onEngage(ok); }, 700);
    };
    this._open('array', false);
  }
  openRadio(ctl) {
    const range = $('rd-range'), freq = $('rd-freq'), st = $('rd-status'), fill = $('rd-fill');
    const sync = () => { range.value = Math.round(ctl.freq * 10); freq.textContent = ctl.freq.toFixed(1); };
    sync();
    range.oninput = () => { ctl.tune(range.value / 10); freq.textContent = ctl.freq.toFixed(1); };
    const step = (d) => { ctl.tune(ctl.freq + d); sync(); };
    const hold = (btn, d) => { let t = 0, r = 0; const go = () => { step(d); r = setTimeout(go, 90); }; btn.onpointerdown = (e) => { e.preventDefault(); step(d); t = setTimeout(go, 380); }; const up = () => { clearTimeout(t); clearTimeout(r); }; btn.onpointerup = up; btn.onpointercancel = up; btn.onpointerleave = up; };
    hold($('rd-minus'), -0.1); hold($('rd-plus'), 0.1);
    this._open('radio', false, () => ctl.close());
    this._radioTimer = setInterval(() => {
      const i = ctl.info(); st.textContent = i.locked ? 'LOCKED · ' + i.name : i.weak ? 'WEAK CARRIER · MOVE CLOSER TO THE SOURCE' : 'STATIC';
      st.className = i.locked ? 'lock' : i.weak ? 'weak' : ''; fill.style.width = Math.round((1 - i.stat) * 100) + '%'; freq.textContent = i.freq.toFixed(1);
    }, 100);
  }
  openInventory(ctl) {
    const render = () => {
      const S = ctl.state, it = $('inv-items'), dc = $('inv-docs'); it.innerHTML = ''; dc.innerHTML = '';
      const row = (name, desc, btn, fn, cls = '') => { const r = document.createElement('div'); r.className = 'irow ' + cls; r.innerHTML = `<div>${name}<small>${desc}</small></div>`; if (btn) { const b = document.createElement('button'); b.textContent = btn; b.onclick = () => { fn(); render(); }; r.appendChild(b); } it.appendChild(r); };
      row(`Battery ×${S.items.battery | 0}`, ITEM_INFO.battery.desc, S.items.battery ? 'USE' : '', () => ctl.useBattery(), S.items.battery ? '' : 'empty');
      row(`Medkit ×${S.items.medkit | 0}`, ITEM_INFO.medkit.desc, S.items.medkit ? 'USE' : '', () => ctl.useMedkit(), S.items.medkit ? '' : 'empty');
      for (const k of ['keycard1', 'keycard3', 'fuse', 'fuel']) if (S.keys[k]) row(ITEM_INFO[k].name, ITEM_INFO[k].desc);
      if (!S.notes.length) { const e = document.createElement('div'); e.className = 'irow empty'; e.textContent = 'No documents yet'; dc.appendChild(e); }
      for (const id of S.notes) { const n = NOTES[id]; if (!n) continue; const b = document.createElement('button'); b.className = 'irow doc'; b.innerHTML = `<div>${n.kind === 'radio' ? '📻 ' : '📄 '}${n.title}<small>${n.kind === 'radio' ? 'Radio transcript' : 'Document'}</small></div>`; b.onclick = () => ctl.read(id); dc.appendChild(b); }
      $('inv-hp').textContent = Math.round(ctl.health()) + '%'; $('inv-bt').textContent = Math.round(ctl.battery()) + '%';
    };
    render(); this._open('inv', true);
  }
}
