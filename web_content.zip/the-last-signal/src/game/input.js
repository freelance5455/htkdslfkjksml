// Unified input: touch (floating joystick, look pad, on-screen buttons), keyboard + mouse for desktop testing.
import { clamp } from '../engine/math.js';

export class Input {
  constructor(root) {
    this.root = root;
    this.mx = 0; this.my = 0;            // movement axes (-1..1); my>0 = forward
    this.lookX = 0; this.lookY = 0;      // accumulated radians since last take()
    this.sprintHeld = false; this.edgeSprint = false;
    this.pressed = new Set();            // one-shot actions
    this.held = new Set();               // hold actions ("breath", "sprint")
    this.keys = new Set();
    this.enabled = false;                // gameplay input only while playing
    this.sens = 1; this.invertY = false; this.stickSprint = true; this.leftHanded = false;
    this.stick = { id: -1, ox: 0, oy: 0, x: 0, y: 0, active: false };
    this.look = { id: -1, x: 0, y: 0 };
    this.pointerLocked = false;
    this.vib = true;
    this._bind();
  }
  press(a) { if (this.enabled || a === 'pause') this.pressed.add(a); }
  take(a) { return this.pressed.delete(a); }
  clearEdges() { this.pressed.clear(); }
  isHeld(a) { return this.held.has(a); }
  takeLook() { const r = [this.lookX, this.lookY]; this.lookX = 0; this.lookY = 0; return r; }
  reset() { this.mx = this.my = 0; this.lookX = this.lookY = 0; this.held.clear(); this.keys.clear(); this.stick.active = false; this.stick.id = -1; this.look.id = -1; this.sprintHeld = false; this.edgeSprint = false; this._stickUI(); }

  _bind() {
    const $ = (id) => document.getElementById(id);
    this.elL = $('touch-move'); this.elR = $('touch-look'); this.elBase = $('joy-base'); this.elKnob = $('joy-knob');
    const L = this.elL, R = this.elR;
    // joystick (floating inside the left zone)
    L.addEventListener('pointerdown', (e) => {
      if (this.stick.id !== -1 || !this.enabled) return;
      e.preventDefault(); L.setPointerCapture(e.pointerId);
      const r = L.getBoundingClientRect(), vm = Math.min(innerWidth, innerHeight) / 100;
      const ox = clamp(e.clientX, r.left + 9 * vm, r.right - 9 * vm), oy = clamp(e.clientY, r.top + 9 * vm, r.bottom - 9 * vm);
      Object.assign(this.stick, { id: e.pointerId, ox, oy, x: e.clientX, y: e.clientY, active: true });
      this._stickUpdate(e); this._stickUI();
    });
    L.addEventListener('pointermove', (e) => { if (e.pointerId === this.stick.id) { e.preventDefault(); this._stickUpdate(e); } });
    const endStick = (e) => { if (e.pointerId !== this.stick.id) return; this.stick.id = -1; this.stick.active = false; this.mx = this.my = 0; this.edgeSprint = false; this._stickUI(); };
    L.addEventListener('pointerup', endStick); L.addEventListener('pointercancel', endStick); L.addEventListener('lostpointercapture', endStick);
    // look pad
    R.addEventListener('pointerdown', (e) => {
      if (this.look.id !== -1 || !this.enabled) return;
      e.preventDefault(); R.setPointerCapture(e.pointerId);
      this.look.id = e.pointerId; this.look.x = e.clientX; this.look.y = e.clientY;
    });
    R.addEventListener('pointermove', (e) => {
      if (e.pointerId !== this.look.id) return;
      e.preventDefault();
      const dx = e.clientX - this.look.x, dy = e.clientY - this.look.y;
      this.look.x = e.clientX; this.look.y = e.clientY;
      const k = 0.0042 * this.sens;
      this.lookX += clamp(dx, -140, 140) * k; this.lookY += clamp(dy, -140, 140) * k * (this.invertY ? -1 : 1);
    });
    const endLook = (e) => { if (e.pointerId === this.look.id) this.look.id = -1; };
    R.addEventListener('pointerup', endLook); R.addEventListener('pointercancel', endLook); R.addEventListener('lostpointercapture', endLook);
    // buttons
    document.querySelectorAll('[data-hold]').forEach((el) => {
      const a = el.dataset.hold;
      el.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); el.setPointerCapture(e.pointerId); this.held.add(a); el.classList.add('down'); this._buzz(8); });
      const up = (e) => { this.held.delete(a); el.classList.remove('down'); };
      el.addEventListener('pointerup', up); el.addEventListener('pointercancel', up); el.addEventListener('lostpointercapture', up);
    });
    document.querySelectorAll('[data-press]').forEach((el) => {
      el.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); el.classList.add('down'); this.press(el.dataset.press); this._buzz(10); });
      const up = () => el.classList.remove('down');
      el.addEventListener('pointerup', up); el.addEventListener('pointercancel', up); el.addEventListener('pointerleave', up);
    });
    // keyboard (desktop)
    const map = { KeyF: 'flash', KeyE: 'interact', Space: 'interact', KeyC: 'crouch', ControlLeft: 'crouch', Escape: 'pause', KeyP: 'pause', Tab: 'inventory', KeyI: 'inventory', KeyR: 'answer', KeyQ: 'leave' };
    addEventListener('keydown', (e) => {
      if (e.repeat) return;
      this.keys.add(e.code);
      if (map[e.code]) { if (e.code === 'Tab') e.preventDefault(); this.press(map[e.code]); }
      if (e.code === 'KeyB') this.held.add('breath');
    });
    addEventListener('keyup', (e) => { this.keys.delete(e.code); if (e.code === 'KeyB') this.held.delete('breath'); });
    addEventListener('blur', () => { this.keys.clear(); this.held.clear(); });
    // mouse look with pointer lock (desktop)
    const cv = document.getElementById('gl');
    cv.addEventListener('mousedown', () => { if (this.enabled && !this.pointerLocked && matchMedia('(pointer:fine)').matches) cv.requestPointerLock?.(); });
    document.addEventListener('pointerlockchange', () => { this.pointerLocked = document.pointerLockElement === cv; });
    addEventListener('mousemove', (e) => {
      if (!this.pointerLocked || !this.enabled) return;
      this.lookX += e.movementX * 0.0022 * this.sens; this.lookY += e.movementY * 0.0022 * this.sens * (this.invertY ? -1 : 1);
    });
    addEventListener('contextmenu', (e) => e.preventDefault());
    const SCROLLY = '.sgrid,.cgrid,#note-body,#inv-items,#inv-docs,.card,input';
    for (const ev of ['touchmove', 'gesturestart', 'dblclick']) document.addEventListener(ev, (e) => { if (ev === 'touchmove' && e.target.closest && e.target.closest(SCROLLY)) return; if (e.cancelable) e.preventDefault(); }, { passive: false });
  }
  _buzz(ms) { if (this.vib && navigator.vibrate) { try { navigator.vibrate(ms); } catch { /* ignore */ } } }
  _stickUpdate(e) {
    const s = this.stick, vm = Math.min(innerWidth, innerHeight) / 100, rad = 9 * vm;
    s.x = e.clientX; s.y = e.clientY;
    let dx = (s.x - s.ox) / rad, dy = (s.y - s.oy) / rad;
    const l = Math.hypot(dx, dy);
    if (l > 1) { dx /= l; dy /= l; }
    const m = Math.min(1, l);
    const dz = 0.14, mm = m < dz ? 0 : (m - dz) / (1 - dz);
    this.mx = l > 0 ? (dx / Math.max(l, 1e-6)) * mm * Math.min(l, 1) / Math.max(m, 1e-6) : 0;
    this.my = l > 0 ? (-dy / Math.max(l, 1e-6)) * mm * Math.min(l, 1) / Math.max(m, 1e-6) : 0;
    if (m < dz) { this.mx = 0; this.my = 0; }
    this.edgeSprint = this.stickSprint && l > 1.18 ;
    this._stickUI();
  }
  _stickUI() {
    const s = this.stick, b = this.elBase, k = this.elKnob;
    if (!b) return;
    if (!s.active) { b.classList.remove('on'); k.style.transform = 'translate(-50%,-50%)'; return; }
    const vm = Math.min(innerWidth, innerHeight) / 100, rad = 9 * vm;
    b.classList.add('on'); b.style.left = s.ox + 'px'; b.style.top = s.oy + 'px';
    let dx = s.x - s.ox, dy = s.y - s.oy; const l = Math.hypot(dx, dy);
    if (l > rad) { dx = (dx / l) * rad; dy = (dy / l) * rad; }
    k.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
    b.classList.toggle('sprint', this.edgeSprint);
  }
  // current movement vector + sprint flag, merging keyboard and touch
  axes() {
    let x = this.mx, y = this.my;
    const k = this.keys;
    if (k.size) {
      const kx = (k.has('KeyD') || k.has('ArrowRight') ? 1 : 0) - (k.has('KeyA') || k.has('ArrowLeft') ? 1 : 0);
      const ky = (k.has('KeyW') || k.has('ArrowUp') ? 1 : 0) - (k.has('KeyS') || k.has('ArrowDown') ? 1 : 0);
      if (kx || ky) { const l = Math.hypot(kx, ky); x = kx / l; y = ky / l; }
    }
    return { x, y, sprint: this.held.has('sprint') || this.edgeSprint || this.keys.has('ShiftLeft') || this.keys.has('ShiftRight') };
  }
}
