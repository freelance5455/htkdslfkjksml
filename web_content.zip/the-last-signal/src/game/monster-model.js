// Procedural articulated model of "the Listener" (Subject 9): a tall, emaciated, eyeless humanoid that hunts by sound.
// Local space: origin at the feet, front = -z. Parts are separate meshes posed every frame from the AI's animation state.
import { MeshBuilder } from '../engine/mesh.js';
import { m4 } from '../engine/math.js';

const SK = [0.74, 0.72, 0.66], DK = [0.42, 0.4, 0.38], BN = [0.95, 0.92, 0.8], MW = [0.06, 0.015, 0.02];
const T = (c, ao = 0.9, s = 1.4) => ({ s, t: c, ao0: ao });

export function createMonsterModel(R, mats) {
  const mk = (fn, key = 'skin') => { const mb = new MeshBuilder(); fn(mb); return { mesh: R.createMesh(mb.finalize()), mat: mats[key] || mats.skin || mats.wall }; };
  const P = {};
  // trunk (pivot = pelvis centre)
  P.torso = mk((m) => {
    m.box(-0.2, -0.05, -0.12, 0.2, 0.3, 0.12, T(SK));
    m.box(-0.1, 0.3, -0.09, 0.1, 0.44, 0.09, T(DK));
    m.box(-0.25, 0.42, -0.16, 0.25, 0.9, 0.15, T(SK));
    for (let i = 0; i < 5; i++) m.box(-0.255, 0.48 + i * 0.085, -0.165, 0.255, 0.5 + i * 0.085, -0.02, T(BN, 0.75));
    for (let i = 0; i < 7; i++) m.box(-0.06, 0.28 + i * 0.09, 0.15, 0.06, 0.3 + i * 0.09, 0.2, T(BN, 0.7));
    m.box(-0.36, 0.78, -0.1, 0.36, 0.92, 0.1, T(DK));
    m.box(-0.1, 0.9, -0.07, 0.1, 1.08, 0.07, T(DK));
  });
  // skull (pivot = base of the neck): long, smooth, no eyes
  P.head = mk((m) => {
    m.box(-0.115, 0.04, -0.2, 0.115, 0.34, 0.12, T(SK, 0.85, 1));
    m.box(-0.09, 0.3, -0.14, 0.09, 0.42, 0.1, T(SK, 0.9, 1));
    m.box(-0.1, 0.02, -0.215, 0.1, 0.1, -0.2, T(MW, 1, 1));
    m.box(-0.105, 0.2, -0.205, -0.085, 0.24, -0.2, T(DK, 0.8, 1)); m.box(0.085, 0.2, -0.205, 0.105, 0.24, -0.2, T(DK, 0.8, 1));
    for (let i = 0; i < 6; i++) m.box(-0.085 + i * 0.03, 0.095, -0.222, -0.07 + i * 0.03, 0.14, -0.215, T(BN, 1, 1));
  });
  // jaw (pivot = jaw hinge)
  P.jaw = mk((m) => {
    m.box(-0.095, -0.1, -0.2, 0.095, -0.03, 0.04, T(SK, 0.8, 1));
    m.box(-0.085, -0.03, -0.19, 0.085, 0.0, 0.02, T(MW, 1, 1));
    for (let i = 0; i < 5; i++) m.box(-0.07 + i * 0.035, 0.0, -0.195, -0.055 + i * 0.035, 0.05, -0.185, T(BN, 1, 1));
  });
  // arm segments hang along -y from the joint
  P.upper = mk((m) => { m.tube(0, 0, 0, 0, -0.66, 0, 0.05, 6, T(SK, 0.85)); m.box(-0.06, -0.1, -0.06, 0.06, 0.03, 0.06, T(DK)); });
  P.fore = mk((m) => {
    m.tube(0, 0, 0, 0, -0.68, 0, 0.04, 6, T(SK, 0.85));
    for (let i = 0; i < 4; i++) { const x = -0.04 + i * 0.027; m.tube(x, -0.68, 0, x * 1.4, -0.98, -0.03, 0.008, 4, T(BN, 1, 1)); }
  });
  P.thigh = mk((m) => { m.tube(0, 0, 0, 0, -0.56, 0, 0.065, 6, T(SK, 0.85)); m.box(-0.08, -0.08, -0.08, 0.08, 0.04, 0.08, T(DK)); });
  P.shin = mk((m) => { m.tube(0, 0, 0, 0, -0.56, 0, 0.045, 6, T(SK, 0.85)); m.box(-0.06, -0.6, -0.2, 0.06, -0.54, 0.05, T(DK)); });
  return P;
}

const S = Array.from({ length: 12 }, () => m4.create()), L = m4.create();
const mul = (o, a, x, y, z, rx = 0, ry = 0, rz = 0) => { m4.fromTRS(L, x, y, z, rx, ry, rz, 1, 1, 1); return m4.mul(o, a, L); };

export function drawMonster(R, P, mon, world, cam) {
  const g = world.grid, ai = g.areaAt(mon.x, mon.z);
  if (ai < 0 || (world.visSet && !world.visSet[ai])) return false;
  const dx = mon.x - cam.x, dz = mon.z - cam.z; if (dx * dx + dz * dz > 1600) return false;
  const ch = world.chunkFor(mon.x, mon.z); if (ch) world._select(R, ch, cam);
  const a = mon.anim, ph = a.phase, k = Math.min(1, a.speed / 2.6), t = mon.t, atk = a.attack, peek = a.peek;
  const lean = a.lean + atk * 0.35, sw = Math.sin(ph), cw = Math.cos(ph), br = Math.sin(t * 1.7) * 0.02;
  const bob = Math.abs(Math.sin(ph)) * 0.06 * k - 0.05 * lean;
  const root = S[0]; m4.fromTRS(root, mon.x, mon.y + bob, mon.z, 0, -mon.yaw, 0, 1, 1, 1);
  const pelvis = mul(S[1], root, 0, 1.12, 0, -lean * 0.5, sw * 0.12 * k, sw * 0.04 * k);
  const torso = mul(S[2], pelvis, 0, 0, 0, -lean * 0.7 + br, 0, 0);
  // legs
  for (const side of [-1, 1]) {
    const p = ph + (side > 0 ? 0 : Math.PI), sn = Math.sin(p), cn = Math.cos(p);
    const th = mul(S[3], root, side * 0.14, 1.12 + bob * 0, 0, sn * 0.8 * k + 0.05, 0, side * 0.03);
    R.drawMesh(P.thigh.mesh, P.thigh.mat, 'lit', th);
    const sh = mul(S[4], th, 0, -0.56, 0, -(Math.max(0, cn) * 1.05 * k + 0.12 + 0.2 * lean), 0, 0);
    R.drawMesh(P.shin.mesh, P.shin.mat, 'lit', sh);
  }
  R.drawMesh(P.torso.mesh, P.torso.mat, 'lit', torso);
  // head + jaw
  const hd = mul(S[5], torso, 0, 0.98, -0.02, 0.35 + lean * 0.5 + peek * 0.3 + Math.sin(t * 2.3) * 0.04, mon.headYaw * 0.9, Math.sin(t * 0.9) * 0.06 + peek * 0.2);
  R.drawMesh(P.head.mesh, P.head.mat, 'lit', hd);
  const jw = mul(S[6], hd, 0, 0.1, -0.02, -a.jaw * 0.55, 0, 0);
  R.drawMesh(P.jaw.mesh, P.jaw.mat, 'lit', jw);
  // arms: swing opposite to the legs, lift + reach when attacking, dangle when idle
  for (const side of [-1, 1]) {
    const p = ph + (side > 0 ? Math.PI : 0), sn = Math.sin(p);
    const reach = Math.max(atk * 1.7, mon.state === 4 ? 0.85 : 0, peek * 1.1);
    const up = mul(S[7], torso, side * 0.4, 0.82, 0, sn * 0.55 * k + reach + 0.12 - Math.sin(t * 1.1 + side) * 0.04, 0, side * (0.1 + 0.14 * (1 - reach)));
    R.drawMesh(P.upper.mesh, P.upper.mat, 'lit', up);
    const fo = mul(S[8], up, 0, -0.66, 0, -(0.25 + reach * 0.5 + Math.max(0, -sn) * 0.3 * k), 0, 0);
    R.drawMesh(P.fore.mesh, P.fore.mat, 'lit', fo);
  }
  return true;
}
