// Per-frame rendering: camera + lighting/fog parameters, flashlight (with optional shadow map), items, monster, particles, post effects.
import { m4, damp } from '../engine/math.js';
import { createMonsterModel, drawMonster } from './monster-model.js';
import { createItemModels, ITEM_INFO } from '../world/items.js';

const SKY = { hor: [0.05, 0.065, 0.1], zen: [0.004, 0.006, 0.02], moon: [0.52, 0.5, -0.69], dawn: 0 };
const FC = [Math.cos(0.55), Math.cos(0.2)];
const M = m4.create();
const FOG_IN = [0.008, 0.01, 0.013, 0.05];

export function setupRender(game) {
  const R = game.R, w = game.world;
  game.itemModels = createItemModels(R, game.mats);
  game.monsterModel = createMonsterModel(R, game.mats);
  game.glintBuf = new Float32Array(9 * 64); game.glintN = 0;
  game._amb = [0, 0, 0]; game._fog = [0, 0, 0, 0]; game._fl = [0, 0, 0, 22]; game._fd = [0, 0, -1, 0];
  w.extraDraw.push((R2, cam) => drawExtras(game, R2, cam));
}

function drawExtras(game, R, cam) {
  const w = game.world, C = w.content, set = w.visSet, t = game.time, buf = game.glintBuf; let n = 0;
  for (const p of C.pickups) {
    if (p.taken || (p.hidden && !game.state.flag(p.hidden))) continue;
    const dx = p.x - cam.x, dz = p.z - cam.z, d2 = dx * dx + dz * dz; if (d2 > 900) continue;
    const ai = w.grid.areaAt(p.x, p.z); if (ai < 0 || (set && !set[ai])) continue;
    const info = ITEM_INFO[p.type] || ITEM_INFO.note, model = game.itemModels[p.type]; if (!model) continue;
    const ch = w.chunkFor(p.x, p.z); if (ch) w._select(R, ch, cam);
    const yaw = (p.x * 12.9898 + p.z * 78.233) % 6.283 + (p.type === 'battery' ? 0 : 0.5);
    m4.fromTRS(M, p.x, p.y, p.z, 0, yaw, 0, 1, 1, 1);
    const pulse = 0.65 + 0.35 * Math.sin(t * 2.2 + p.x);
    for (const part of model) R.drawMesh(part.mesh, part.mat, part.kind, M, 1, part.kind === 'emis' ? [info.glow[0] * pulse, info.glow[1] * pulse, info.glow[2] * pulse] : null);
    if (n < 63 && d2 < 400) { const o = n++ * 9; buf[o] = p.x; buf[o + 1] = p.y + 0.14; buf[o + 2] = p.z; buf[o + 3] = info.glow[0] * 0.8; buf[o + 4] = info.glow[1] * 0.8; buf[o + 5] = info.glow[2] * 0.8; buf[o + 6] = 0.18 + 0.2 * pulse; buf[o + 7] = 0.1; buf[o + 8] = 0; }
  }
  game.glintN = n;
  // fuse box status lamp
  for (const l of C.lamps) {
    const dx = l.x - cam.x, dz = l.z - cam.z; if (dx * dx + dz * dz > 600) continue;
    const ok = game.state.flag('fuseInstalled'), col = ok ? [0.1, 1.2, 0.3] : [1.4, 0.1, 0.05] , k = ok ? 1 : 0.6 + 0.4 * Math.sin(t * 5);
    m4.translation(M, l.x, l.y, l.z);
    R.drawMesh(w.cubeMesh, w.mats['emis:white'], 'emis', M, 1, [col[0] * k, col[1] * k, col[2] * k]);
  }
  if (game.monster.active) drawMonster(R, game.monsterModel, game.monster, w, cam);
}

export function menuCam(game) {
  const t = game.time * 0.05;
  return { x: 9 + Math.sin(t * 1.3) * 1.4, y: 1.62 + Math.sin(t * 2.1) * 0.04, z: 63 + Math.sin(t * 0.9) * 0.9, yaw: Math.PI / 2 + Math.sin(t * 1.7) * 0.22, pitch: -0.02 + Math.sin(t * 2.6) * 0.02, roll: 0, fov: 1.2, near: 0.07, far: 90 };
}

export function renderFrame(game, dt) {
  const R = game.R, w = game.world, g = w.grid, P = game.player, st = game.settings, menu = game.mode === 'menu';
  const cam = menu ? menuCam(game) : P.camera(st.fov * Math.PI / 180);
  const sh = game.shakeAmt * (st.shake ? 1 : 0);
  if (sh > 0.001) { cam.x += (Math.random() - 0.5) * sh * 0.05; cam.y += (Math.random() - 0.5) * sh * 0.05; cam.yaw += (Math.random() - 0.5) * sh * 0.02; cam.roll += (Math.random() - 0.5) * sh * 0.03; }
  const ai = Math.max(0, g.areaAt(cam.x, cam.z)), a = g.areas[ai], outdoor = !!a.outdoor;
  const amb = w.ambient(ai, game._amb), fog = game._fog;
  const fb = outdoor ? [0.02, 0.03, 0.045, 0.026] : a.id === 'chamber' ? [0.008, 0.013, 0.026, 0.04] : FOG_IN;
  for (let i = 0; i < 4; i++) fog[i] = fb[i];
  // chase tint: the air itself reddens a little when it is hunting you
  const th = game.threatSm; fog[0] += th * 0.012;
  const cp = Math.cos(cam.pitch), fl = P.fl, rx = Math.cos(cam.yaw), rz = Math.sin(cam.yaw);
  const fpos = game._fl; fpos[0] = cam.x + rx * 0.14; fpos[1] = cam.y - 0.12; fpos[2] = cam.z + rz * 0.14; fpos[3] = 22;
  const fd = game._fd; fd[0] = menu ? Math.sin(cam.yaw) * cp : fl.dir[0]; fd[1] = menu ? 0 : fl.dir[1]; fd[2] = menu ? -Math.cos(cam.yaw) * cp : fl.dir[2]; fd[3] = menu ? 0 : fl.power;
  SKY.dawn = game.dawn;
  R.begin(cam, { time: game.time, amb, fog, exposure: 1.3, fl: fpos, fd, fc: FC, sky: outdoor ? SKY : null });
  if (R.q.shadow && fd[3] > 0.05 && !menu) {
    if (R.beginShadow(fpos[0], fpos[1], fpos[2], fd[0], fd[1], fd[2], 1.15, 24)) {
      for (const c of w.visibleChunks(R, cam, 28)) for (const d of c.draws) if (d.kind === 'lit') R.drawDepth(d.mesh);
      R.endShadow();
    }
  }
  w.draw(R, cam);
  game.fx.draw(R, cam, 1);
  if (game.glintN) R.drawSprites(game.glintBuf, game.glintN, true);
  const low = 1 - P.health / 100, hurt = P.hurtT;
  R.end({
    vig: 0.55 + 0.35 * low + (P.hidden ? 0.25 : 0) + th * 0.12,
    chroma: R.q.chroma + 0.004 * th + game.glitchAmt * 0.012 + hurt * 0.012,
    damage: Math.max(hurt * 0.9, low > 0.6 ? (0.2 + 0.12 * Math.sin(game.time * 5)) * ((low - 0.6) / 0.4) : 0),
    stat: th * 0.1 + game.glitchAmt * 0.45, fade: game.fade, glitch: game.glitchAmt, desat: low * 0.5, gamma: st.brightness, flash: game.flashAmt, rays: 1,
  });
  // decay transient effects
  game.shakeAmt = Math.max(0, game.shakeAmt - dt * 1.8); game.glitchAmt = Math.max(0, game.glitchAmt - dt * 1.4); game.flashAmt = Math.max(0, game.flashAmt - dt * 2.5);
  void damp;
}
