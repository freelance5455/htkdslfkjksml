// Picks what the player is looking at (pickup / interactable / hiding place) and builds the on-screen prompt.
import { ITEM_INFO } from '../world/items.js';

const VERB = { note: 'READ', keypad: 'ENTER CODE', fusebox: 'USE', panel: 'USE PANEL', breaker: 'PULL', fuelport: 'FILL', starter: 'HOLD TO START', console: 'USE', wheel: 'HOLD TO TURN' };

export function findTarget(game) {
  const P = game.player, w = game.world, C = w.content, g = w.grid;
  if (P.hidden || P.locked || !P.alive) return null;
  const ey = P.eyeY, cp = Math.cos(P.pitch), dir = [Math.sin(P.yaw) * cp, Math.sin(P.pitch), -Math.cos(P.yaw) * cp];
  let best = null, bs = -1e9;
  const consider = (type, obj, x, y, z, r, minCos, bonus = 0) => {
    const dx = x - P.x, dy = y - ey, dz = z - P.z, d = Math.hypot(dx, dy, dz);
    if (d > r) return;
    const cs = (dx * dir[0] + dy * dir[1] + dz * dir[2]) / (d || 1);
    if (cs < minCos && (d > 0.55 || type !== 'pickup')) return;
    const sc = cs * 2 - d / r + bonus;
    if (sc <= bs) return;
    if (!g.los(P.x, P.z, x, z, true)) return;
    best = { type, obj, d }; bs = sc;
  };
  for (const p of C.pickups) if (!p.taken) consider('pickup', p, p.x, p.y + 0.08, p.z, 1.9, 0.9, 0.3);
  for (const a of C.interacts) {
    if (a.hidden && !game.state.flag(a.hidden)) continue;
    consider('act', a, a.x, a.y, a.z, a.r, a.cos ?? 0.86);
  }
  for (const h of C.hides) {
    if (h.occupied) continue;
    const fx = h.front[0], fz = h.front[1], dd = Math.hypot(fx - P.x, fz - P.z);
    if (dd < 1.5) consider('hide', h, h.x, h.y + 1.0, h.z, 2.6, 0.84, 0.2);
  }
  if (!best) return null;
  const o = best.obj;
  if (best.type === 'pickup') { best.verb = 'TAKE'; best.label = ITEM_INFO[o.type]?.name || o.type; }
  else if (best.type === 'hide') { best.verb = 'HIDE'; best.label = o.kind === 'locker' ? 'in locker' : o.kind === 'crate' ? 'behind crate' : 'in cabinet'; }
  else { best.verb = VERB[o.kind] || 'USE'; best.label = o.label; best.hold = !!o.hold; if (o.kind === 'breaker') best.verb = game.state.flag('breakersOk') ? 'BREAKER' : 'PULL'; }
  return best;
}
