// World <-> game-state glue: reset the level to its initial condition, re-apply saved progress, animate dynamic props.
import { DOORS } from '../world/layout.js';

const hinge = { x: 64.8, z: 75.1 };

export function resetWorld(game) {
  const w = game.world, g = w.grid, C = w.content;
  g.doors.forEach((d, i) => {
    const o = DOORS[i]; d.t = o.open ? 1 : 0; d.target = undefined; d.lock = { ...o.lock }; d.label = o.label; d.locked = o.lock.type === 'key' || o.lock.type === 'script';   // power locks are governed by the circuit alone d.stay = false; d.fast = false; d.hold = 0;
  });
  for (const id of ['d_blast', 'd_esc_sh']) g.doors[g.doorIndex[id]].stay = true;
  w.circ = { always: 1, lobby: 1, ck: 1, lab: 0, gen: 0, emerg: 0 }; w.circCur = { ...w.circ };
  for (const p of C.pickups) p.taken = false;
  for (const h of C.hides) { h.ang = 0; h.target = 0; h.occupied = false; h.checked = 0; }
  if (C.cageCol) C.cageCol.solid = true;
  if (game.monster) game.monster.nav.rebuildProps();
  for (const n of [1, 2, 3]) { const o = C.objs['br' + n]; if (o) { o.rx = 0; o.tgt = 0; o.tint = null; } }
  const st = C.objs.starter; if (st) { if (st.y0 === undefined) st.y0 = st.y; st.y = st.y0; }
  const wh = C.objs.wheel; if (wh) wh.rz = 0;
  const cg = C.objs.cage_gate; if (cg) { if (cg.base === undefined) cg.base = { x: cg.x, z: cg.z, ry: cg.ry }; cg.open = 0; cg.openT = 0; cg.x = cg.base.x; cg.z = cg.base.z; cg.ry = cg.base.ry; }
  const core = C.objs.core; if (core) { core.tint = [1, 1, 1]; core.visible = true; }
  for (const r of (C.array?.rings || [])) { r.spin = 1; r.surge = 0; }
  game.hold = null; game.consoleLock = 0;
}

// re-apply everything the saved state implies (doors, power, props)
export function syncWorld(game) {
  const S = game.state, w = game.world, g = w.grid, C = w.content, d = (id) => g.doors[g.doorIndex[id]];
  for (const p of C.pickups) p.taken = !!S.taken[p.id];
  if (S.flag('fuseInstalled')) w.circ.lab = 1;
  if (S.flag('gen')) w.circ.gen = 1;
  if (S.flag('arrayDone')) { w.circ.emerg = 1; }
  w.circCur = { ...w.circ };
  if (S.flag('blast')) { const b = d('d_blast'); b.t = 0; b.stay = false; b.locked = true; b.lock = { type: 'script', flag: 'blastOpen' }; b.label = 'MAIN BLAST DOOR'; }
  if (S.flag('labOpen')) { const l = d('d_ck_lab'); l.locked = false; }
  if (S.flag('anteOpen')) d('d_ante').locked = false;
  if (S.flag('panelSolved')) { const s = d('d_secret'); s.locked = false; s.t = 1; s.stay = true; }
  if (S.flag('escape')) { const e = d('d_esc'); e.locked = false; e.t = 1; e.stay = true; }
  if (S.flag('exitWheel')) { const e = d('d_exit'); e.locked = false; e.t = 1; e.stay = true; const wh = C.objs.wheel; if (wh) wh.rz = 3.1; }
  const br = S.puzzle.br || [];
  if (S.flag('breakersOk')) for (const n of [1, 2, 3]) { const o = C.objs['br' + n]; o.rx = o.tgt = 1.15; o.tint = [0.2, 1.2, 0.4]; }
  else for (const n of br) { const o = C.objs['br' + n]; if (o) o.rx = o.tgt = 1.15; }
  if (S.flag('cageOpen')) openCage(game, true, true);
  if (S.flag('arrayDone')) arrayOff(game);
}

export function openCage(game, open, instant) {
  const C = game.world.content, o = C.objs.cage_gate; if (!o) return;
  o.open = open ? 1 : 0; if (instant) o.openT = o.open;
  if (C.cageCol) C.cageCol.solid = !open;
  game.monster.nav.rebuildProps();   // the gate is a collider the monster's pathing must know about
  if (open && !instant) game.sfx.door(64.8, 74.3, 'open', 'metal');
}
export function arrayOff(game) {
  const C = game.world.content; for (const r of C.array.rings) r.spin = 0;
  const core = C.objs.core; if (core) { core.tint = [0.05, 0.06, 0.08]; }
}

export function updateDyn(game, dt) {
  const w = game.world, C = w.content, t = game.time;
  for (const h of C.hides) { if (h.ang !== h.target) { h.ang += (h.target - h.ang) * Math.min(1, dt * 7); if (Math.abs(h.ang - h.target) < 0.01) h.ang = h.target; } }
  for (const id in C.objs) {
    const o = C.objs[id];
    if (o.tgt !== undefined && o.tgt !== o.rx && id.startsWith('br')) o.rx += (o.tgt - o.rx) * Math.min(1, dt * 12);
  }
  const cg = C.objs.cage_gate;
  if (cg && cg.openT !== cg.open) {
    cg.openT += Math.sign(cg.open - cg.openT) * Math.min(Math.abs(cg.open - cg.openT), dt * 0.9);
    const phi = -cg.openT * Math.PI / 2;
    cg.x = hinge.x - 0.8 * Math.sin(phi); cg.z = hinge.z - 0.8 * Math.cos(phi); cg.ry = Math.PI / 2 + phi;
  }
  const S = game.state, done = S.flag('arrayDone');
  C.array.rings.forEach((r, i) => {
    r.surge = Math.max(0, (r.surge || 0) - dt);
    const spin = (r.spin ?? 1);
    r.spinCur = (r.spinCur ?? 1) + (spin - (r.spinCur ?? 1)) * Math.min(1, dt * (done ? 0.6 : 2));
    r.ry += r.speed * dt * (r.spinCur * (1 + (r.surge > 0 ? 6 : 0)));
    r.rz = Math.sin(t * 0.6 + i * 2) * 0.07 * r.spinCur;
  });
  const core = C.objs.core;
  if (core && !done) { const k = 1 + 0.12 * Math.sin(t * 3.1) + (C.array.rings[0].surge > 0 ? 0.35 * Math.sin(t * 40) : 0); core.sx = core.sy = core.sz = k; }
  else if (core) { core.sx = core.sy = core.sz = 0.8; }
}
