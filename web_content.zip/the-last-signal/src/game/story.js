// Chapter 1 script: objectives, door logic, scripted scares, monster stages, mimic voice event, escape sequence, checkpoints.
import { OBJECTIVES, MIMIC } from './data.js';
import { S as MS } from './monster.js';

export const STAGE_ZONES = [[], ['lab', 'front'], ['lab', 'service', 'front'], ['lab', 'service', 'deep'], ['service', 'deep', 'chamber'], ['chamber', 'deep', 'service', 'lab']];
const DOOR_FLAG = { d_ck_lab: 'labOpen', d_ante: 'anteOpen' };
const HINT = { key: (d) => `LOCKED - ${d.label || 'keycard required'}`, power: () => 'NO POWER', script: (d) => (d.label ? `${d.label} - SEALED` : 'SEALED') };

export class Story {
  constructor(game) { this.g = game; this.reset(); }
  reset() {
    this.t = 0; this.inZone = {}; this.mimicT = 80; this.whisperT = 50; this.answerT = 0; this.cpWait = null; this.cpTimer = 0; this.shutter = 0; this.hintT = 0;
    this.scareT = 25; this.seenFirst = false; this.endT = -1; this.lastArea = '';
  }
  // ---------------------------------------------------------------- objectives
  objective() {
    const S = this.g.state, f = (k) => S.flag(k);
    if (f('exitWheel')) return 'done';
    if (f('arrayDone')) return f('hatchSeen') ? 'wheel' : 'escape';
    if (S.has('keycard3') || (f('gen') && f('cageOpen'))) return f('chamberSeen') ? 'array' : 'chamber';
    if (f('gen')) return 'cage';
    if (f('fuseInstalled')) return f('researchSeen') ? 'generator' : 'research';
    if (S.has('fuse')) return 'fuseBox';
    if (f('labOpen')) return 'fuse';
    if (S.has('keycard1')) return 'labdoor';
    if (f('blast')) return f('ckSeen') ? 'keycard' : 'lobby';
    return 'start';
  }
  refreshObjective(silent, force) {
    const k = this.objective(), S = this.g.state;
    if (force) { S.objective = k; this.g.ui.objective(OBJECTIVES[k], false); return; }
    if (k !== S.objective) { S.objective = k; if (!silent) { this.g.ui.objective(OBJECTIVES[k], true); this.g.sfx.chime(0.6); } else this.g.ui.objective(OBJECTIVES[k], false); }
  }
  stageNow() {
    const S = this.g.state, f = (k) => S.flag(k);
    return f('arrayDone') ? 5 : S.has('keycard3') || f('chamberSeen') ? 4 : f('gen') ? 3 : f('fuseInstalled') ? 2 : f('labOpen') ? 1 : 0;
  }
  // ---------------------------------------------------------------- game start / load
  begin(fresh) {
    const g = this.g; this.reset(); this.refreshObjective(true);
    if (fresh) {
      g.setFade(1); g.fadeTo = 0; g.fadeSpeed = 0.4;
      g.ui.titleCard('CHAPTER ONE', 'VAJRA DEEP');
      g.later(2.6, () => g.say('RADIO', 'Please... help me get out of here.', { voice: { radio: true, pitch: 215, speed: 0.8, seed: 3 }, dur: 3.6 }));
      g.later(6.6, () => g.say('RADIO', 'But if you hear your own voice... DO NOT ANSWER.', { voice: { radio: true, pitch: 215, speed: 0.8, seed: 5 }, dur: 4.4 }));
      g.later(11.6, () => g.say('SGT. SEN', 'Signal source is below. Time to go in.', { dur: 3.4 }));
      this.cp('start', true);
    }
  }
  // ---------------------------------------------------------------- checkpoints
  cp(id, force) {
    const g = this.g, M = g.monster;
    if (!force && M.active && (M.state === MS.CHASE || M.state === MS.ATTACK || M.dist < 10)) { this.cpWait = id; this.cpTimer = 0; return; }
    this.cpWait = null; g.saveCheckpoint(id);
  }
  // ---------------------------------------------------------------- hooks from actions
  onPickup(p) {
    const S = this.g.state;
    if (p.type === 'keycard1') this.cp('ck');
    else if (p.type === 'keycard3') { this.cp('storage'); this.g.toast('Level 3 access: the Chamber Zero door is beyond the link corridor.'); }
    else if (p.type === 'fuse') this.g.toast('Fuse box E-3 is in the Lab Wing corridor.');
    else if (p.type === 'fuel') this.g.toast('Generator hall: fuel intake on the right side.');
    this.refreshObjective(); void S;
  }
  onNote(id) {
    const g = this.g;
    if (id === 'rao_channel') { g.state.set('knowsRadio'); g.toast('Tip: the RADIO button tunes the field radio.'); }
  }
  onNoteClosed(id, first) {
    const g = this.g;
    if (id === 'brief' && first) g.say('SGT. SEN', 'Four hours. The source is down in that station.', { dur: 3.4 });
    if (id === 'secret' && first) g.say('SGT. SEN', 'She never got out...', { dur: 3 });
    this.refreshObjective();
  }
  onProgress(flag) {
    const g = this.g, S = g.state;
    if (flag === 'fuseInstalled') { this.cp('lab'); g.say('SGT. SEN', 'Lights are back. The fans are loud, though.', { dur: 3.2 }); }
    else if (flag === 'gen') { this.cp('gen'); this.stageCheck(); g.say('SGT. SEN', 'Power is up. That roar will carry through the whole station.', { dur: 3.8 }); }
    else if (flag === 'arrayDone') this.escapeStart();
    else if (flag === 'exitWheel') { g.say('SGT. SEN', 'Run!', { dur: 2 }); }
    this.stageCheck(); this.refreshObjective(); void S;
  }
  onSurge() { this.g.say('SGT. SEN', 'Wrong. Everything in here just heard that.', { dur: 3.2 }); }
  escapeStart() {
    const g = this.g, M = g.monster; this.stageCheck();
    g.sfx.surge(undefined, undefined, 0.5); g.surge(2.5); g.shake(0.5);
    g.say('DR. RAO', '...it is quiet. It is finally quiet. Go. Do not look back.', { voice: { radio: true, pitch: 215, speed: 0.75, seed: 11 }, dur: 5 });
    g.later(5.2, () => g.say('SGT. SEN', 'Array is down. The exit hatch is north-east. MOVE.', { dur: 3.6 }));
    if (!M.active) this.spawnMonster(5, true);
    M.speedMul = 1.35; M.setZones(STAGE_ZONES[5]);
    M.wake(102, 26); this.cp('escape');
  }
  // ---------------------------------------------------------------- monster stages
  spawnMonster(stage, quiet) {
    const g = this.g, M = g.monster, P = g.player, C = g.world.content;
    const pts = []; for (const z of STAGE_ZONES[Math.max(1, stage)]) for (const p of (C.patrol[z] || [])) pts.push(p);
    pts.sort((a, b) => Math.hypot(b[0] - P.x, b[1] - P.z) - Math.hypot(a[0] - P.x, a[1] - P.z));
    let pick = null;
    for (const p of pts.slice(0, 12)) { if (Math.hypot(p[0] - P.x, p[1] - P.z) < 18) continue; if (M.nav.path(p[0], p[1], P.x, P.z)) { pick = p; if (Math.random() < 0.45) break; } }
    if (!pick) pick = pts.find((p) => Math.hypot(p[0] - P.x, p[1] - P.z) > 10) || pts[0];
    if (!pick) return;
    M.setZones(STAGE_ZONES[stage]); M.spawn(pick[0], pick[1], Math.random() * 6.28, { grace: quiet ? 4 : 9 });
  }
  stageCheck() {
    const g = this.g, S = g.state, s = this.stageNow();
    if (s > S.stage) { S.stage = s; this.onStage(s); }
  }
  onStage(s) {
    const g = this.g, M = g.monster;
    M.setZones(STAGE_ZONES[s]);
    if (s >= 1 && !M.active) this.spawnMonster(s);
  }
  // ---------------------------------------------------------------- per-frame
  update(dt) {
    const g = this.g, S = g.state, P = g.player, w = g.world, C = w.content, M = g.monster;
    this.t += dt;
    // zones
    for (const z of C.zones) {
      const inside = P.x >= z.x0 && P.x <= z.x1 && P.z >= z.z0 && P.z <= z.z1;
      if (inside && !this.inZone[z.id]) this.onZone(z.id);
      this.inZone[z.id] = inside;
    }
    // areas
    const ai = w.grid.areaAt(P.x, P.z), id = ai >= 0 ? w.grid.areas[ai].id : '';
    if (id !== this.lastArea) { this.lastArea = id; this.onArea(id); }
    this.updateDoors(dt);
    this.scares(dt);
    if (this.cpWait) { this.cpTimer += dt; if (this.cpTimer > 1 && !(M.active && (M.state === MS.CHASE || M.state === MS.ATTACK || M.dist < 10))) this.cp(this.cpWait, true); }
    this.answerT = Math.max(0, this.answerT - dt); if (this.answerT <= 0 && g.ui.answerShown) g.ui.showAnswer(false);
    this.shutterBeat(dt);
    this.stageCheck(); this.refreshObjective();
    void S;
  }
  onZone(id) {
    const g = this.g, S = g.state, w = g.world;
    if (id === 'lobbyEntry' && !S.flag('blast')) this.blastSlam();
    else if (id === 'outside' && S.flag('exitWheel') && !S.flag('complete')) this.complete();
    void w;
  }
  onArea(id) {
    const g = this.g, S = g.state;
    if ((id === 'checkpoint' || id === 'guard') && !S.flag('ckSeen')) S.set('ckSeen');
    if (id === 'research' && !S.flag('researchSeen')) { S.set('researchSeen'); g.say('SGT. SEN', 'Research room. Whatever they were broadcasting, it started here.', { dur: 3.6 }); }
    if ((id === 'chamber') && !S.flag('chamberSeen')) { S.set('chamberSeen'); this.cp('chamber'); g.sfx.stinger(); g.say('SGT. SEN', 'The Array. It is still humming...', { dur: 3.2 }); }
    if (id === 'hatch' && !S.flag('hatchSeen')) S.set('hatchSeen');
    if (id === 'lc1' && !S.flag('labDark') && !S.flag('fuseInstalled')) { S.set('labDark'); g.hintOnce('flash', 'It is pitch black. Use the FLASH button for your flashlight.'); }
    if (id === 'storage' && !S.flag('storageSeen')) { S.set('storageSeen'); g.say('SGT. SEN', 'Shelving everywhere. Good cover... and good places for it to hide.', { dur: 3.6 }); }
  }
  blastSlam() {
    const g = this.g, S = g.state, w = g.world, d = w.grid.doors[w.grid.doorIndex.d_blast];
    S.set('blast'); d.fast = true; d.stay = false; w.setDoor(d, false); d.locked = true; d.lock = { type: 'script', flag: 'blastOpen' }; d.label = 'MAIN BLAST DOOR';
    g.later(0.65, () => { g.sfx.door(d.cx, d.cz, 'slam'); g.shake(0.7); g.surge(0.9); });
    g.later(1.8, () => g.say('SGT. SEN', 'The blast door... it just sealed behind me.', { dur: 3.4 }));
    g.later(4.8, () => g.sfx.whisper(g.player.x - 3, g.player.z + 2, 0.8));
    this.cp('lobby', true); this.refreshObjective();
  }
  complete() {
    const g = this.g, S = g.state; S.set('complete');
    g.endChapter();
  }
  // ---------------------------------------------------------------- doors
  updateDoors(dt) {
    const g = this.g, w = g.world, P = g.player, M = g.monster, S = g.state;
    let hintDoor = null;
    for (const d of w.doors) {
      const dp = Math.hypot(d.cx - P.x, d.cz - P.z), dm = M.active ? Math.hypot(d.cx - M.x, d.cz - M.z) : 99;
      d.hold = (d.hold || 0) - dt;
      if (dp < 2.4 || dm < 1.8) d.hold = 2.0;
      if (d.locked && d.lock.type === 'key' && dp < 2.1 && S.has(d.lock.item)) {
        w.unlockDoor(d); if (DOOR_FLAG[d.id]) S.set(DOOR_FLAG[d.id]); g.toast('Keycard accepted', 'key'); g.sfx.keyOk();
      }
      const locked = w.doorLocked(d);
      if (locked) {
        if ((d.target === 1 || d.t > 0) && !d.stay) w.setDoor(d, false);
        if (dp < 2.0 && !hintDoor) { const fwd = P.forward(); const vx = d.cx - P.x, vz = d.cz - P.z, l = Math.hypot(vx, vz) || 1; if ((fwd[0] * vx + fwd[1] * vz) / l > 0.35) hintDoor = d; }
        continue;
      }
      if (d.stay) { if (d.target !== 1) w.setDoor(d, true); continue; }
      if (dp < 1.9 || dm < 1.5 || d.hold > 0 && d.t > 0.5 && dp < 3.2) { if (d.target !== 1) w.setDoor(d, true); }
      else if (d.hold <= 0 && (d.target === 1 || d.t > 0)) w.setDoor(d, false);
    }
    this.hintT -= dt;
    if (hintDoor) { const d = hintDoor, txt = (HINT[d.lock.type] || HINT.script)(d); g.hint(txt); if (this.hintT <= 0) { this.hintT = 2.2; g.sfx.door(d.cx, d.cz, 'locked'); } }
  }
  onDoorEvent(d, ev, byMonster) {
    const g = this.g;
    if (ev === 'open' || ev === 'close') {
      g.sfx.door(d.cx, d.cz, ev, d.kind);
      // only doors the PLAYER is working are loud to the monster (it must not investigate the doors it opens / that close behind it)
      const P = g.player, nearPlayer = Math.hypot(d.cx - P.x, d.cz - P.z) < 3.4;
      if (!byMonster && nearPlayer) g.noise(d.cx, d.cz, ev === 'open' ? (d.kind === 'blast' ? 20 : 9) : 6, 'door');
      if (ev === 'open' && d.id === 'd_ck_lab' && !g.state.flag('monsterWoke')) {
        g.state.set('monsterWoke');
        g.later(0.9, () => { g.sfx.mvocal(48.5, 20, 'growl'); g.surge(0.5); });
        g.later(2.6, () => { g.say('SGT. SEN', 'Something is moving in there...', { dur: 3 }); });
        g.later(4.2, () => { this.stageCheck(); g.hintOnce('sound', 'It hunts by SOUND. Crouch to move quietly. Sprinting is loud.'); });
      }
    }
  }
  // ---------------------------------------------------------------- scares + voices
  scares(dt) {
    const g = this.g, S = g.state, P = g.player, M = g.monster;
    if (g.mode !== 'play') return;
    const calm = !M.active || (M.state !== MS.CHASE && M.state !== MS.ATTACK);
    // whispers
    this.whisperT -= dt;
    if (this.whisperT <= 0 && S.stage >= 1 && calm) { this.whisperT = 50 + Math.random() * 70; const a = Math.random() * 6.283; g.sfx.whisper(P.x + Math.cos(a) * 3, P.z + Math.sin(a) * 3); g.glitch(0.35); }
    // your voice
    this.mimicT -= dt;
    if (this.mimicT <= 0 && S.stage >= 2 && calm && !P.hidden && !S.flag('arrayDone')) {
      this.mimicT = 85 + Math.random() * 80;
      const line = MIMIC[(Math.random() * MIMIC.length) | 0], src = M.active && M.dist > 7 ? [M.x, M.z] : [P.x + (Math.random() - 0.5) * 30, P.z + (Math.random() - 0.5) * 30];
      g.say('YOUR VOICE', line, { voice: { pitch: 118, mimic: true, x: src[0], z: src[1], vol: 1.2, speed: 0.95 }, dur: 4, mimic: true });
      this.answerT = 7; g.ui.showAnswer(true); g.hintOnce('mimic', 'If you hear your own voice, DO NOT ANSWER.');
    }
  }
  answer() {
    const g = this.g, P = g.player, M = g.monster;
    if (this.answerT <= 0) return;
    this.answerT = 0; g.ui.showAnswer(false);
    g.say('SGT. SEN', 'Who is there?', { voice: { pitch: 118, vol: 0.9 }, dur: 2 });
    if (M.active) { M.speedMul = Math.max(M.speedMul, 1.15); M.hear(P.x, P.z, 80, 'voice', true); M.awareness = Math.max(M.awareness, 0.5); }
    g.sfx.stinger(0.8); g.toast('It heard you.', 'bad');
  }
  // the escape shutter: slams down between the player and a pursuing monster, then buckles open
  shutterBeat(dt) {
    const g = this.g, w = g.world, P = g.player, M = g.monster, S = g.state;
    const d = w.grid.doors[w.grid.doorIndex.d_esc_sh];
    if (this.shutter === 0) {
      if (S.flag('escape') && P.x > 111 && P.z < 8 && M.active && M.x < 107 && M.z < 9 && Math.hypot(M.x - P.x, M.z - P.z) < 16 && !S.flag('shutterDone')) {
        S.set('shutterDone'); this.shutter = 11; d.stay = false; d.fast = true; d.locked = true; d.lock = { type: 'script', flag: 'x' }; w.setDoor(d, false);
        g.later(0.15, () => { g.sfx.door(d.cx, d.cz, 'slam'); g.shake(0.8); }); g.say('SGT. SEN', 'The shutter dropped! It will not hold long...', { dur: 3.4 });
      }
    } else if (this.shutter > 0) {
      this.shutter -= dt;
      if (this.shutter < 8 && Math.random() < dt * 0.9) { g.sfx.stamp(d.cx - 1.5, d.cz, 1.2); g.shake(0.25); }
      if (this.shutter <= 0) { this.shutter = -1; d.locked = false; d.stay = true; d.fast = false; w.setDoor(d, true); g.sfx.stamp(d.cx, d.cz, 1.6); g.shake(0.8); }
    }
  }
}
