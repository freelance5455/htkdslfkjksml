// The game orchestrator: modes (menu / play / pause / dying / dead / end), simulation step, input handling, audio steering, saves.
import { Player } from './player.js';
import { Monster, S as MS } from './monster.js';
import { Particles } from '../engine/particles.js';
import { GameState, readSave, writeSave, hasSave } from './state.js';
import { Sfx } from '../audio/sfx.js';
import { Scape } from '../audio/scape.js';
import { Story } from './story.js';
import { findTarget } from './interact.js';
import { activate, holdTick, radioStation, radioSignal } from './actions.js';
import { resetWorld, syncWorld, updateDyn, openCage } from './game-world.js';
import { setupRender, renderFrame } from './render.js';
import { START } from '../world/layout.js';
import { TUNING, STATIONS, NOTES } from './data.js';
import { clamp } from '../engine/math.js';

const TIPS = ['It hunts by SOUND. Crouch to walk quietly; sprinting is loud.', 'Hide in a cabinet or locker and HOLD YOUR BREATH while it searches.', 'It cannot open locked doors. Closed doors also block its sight.', 'Your flashlight shows you the way, but light draws attention in the dark.', 'If you hear your own voice, do not answer it.', 'Batteries and medkits are hidden in most rooms. Search the shelves.'];

export class Game {
  constructor(o) {
    Object.assign(this, { R: o.R, world: o.world, mats: o.mats, input: o.input, E: o.E, settings: o.settings, ui: o.ui });
    this.sfx = new Sfx(this.E); this.scape = new Scape(this.E);
    this.state = new GameState(); this.player = new Player(this.world); this.monster = new Monster(this); this.fx = new Particles(900); this.story = new Story(this);
    this.mode = 'menu'; this.time = 0; this.difficulty = 1; this.dawn = 0;
    this.fade = 0; this.fadeTo = 0; this.fadeSpeed = 1; this.shakeAmt = 0; this.glitchAmt = 0; this.flashAmt = 0; this.threatSm = 0;
    this.clock = 0; this.timers = [];
    this.hold = null; this.holdProg = null; this.target = null; this.prevUse = false; this.hideDelay = 0; this.hideSpot = null; this.consoleLock = 0;
    this.hb = 1; this.br = 3; this.radioT = 0; this.hintT = 0; this.hinted = {}; this.dyingT = 0; this.hudT = 0; this.perf = { ms: 16, n: 0, sum: 0, slow: 0, fps: 60 }; this.saveFlash = 0;
    this.radio = { on: false, freq: 91.5, stat: 1, station: null, line: 0, next: 0, shift: 0 };
    this.world.onDoor = (d, ev) => this.story.onDoorEvent(d, ev, this.monster.opening);
    this.audioArea = -1;
    setupRender(this);
    this.fx.setDust(Math.round(70 * this.R.q.particles) + 14, { x: 9, y: 1.6, z: 63, yaw: 0 });
    resetWorld(this); this.world.update(0, 0);
    this.applySettings();
  }

  // ---------------------------------------------------------------- settings
  applySettings() {
    const s = this.settings, I = this.input, E = this.E;
    I.sens = s.sens; I.invertY = s.invertY; I.stickSprint = s.stickSprint; I.leftHanded = s.leftHanded; I.vib = s.vibration;
    E.vol.master = s.master; E.vol.music = s.music; E.vol.sfx = s.sfx; E.vol.mute = s.mute; E.applyVolumes();
    this.player.bobScale = s.headBob ? 1 : 0.2;
    this.ui.applySettings(s);
  }

  // ---------------------------------------------------------------- game-time scheduler (frozen while paused / reading, dropped on load)
  later(sec, fn) { this.timers.push({ at: this.clock + sec, fn }); }
  stepTimers(dt) {
    this.clock += dt; const T = this.timers;
    for (let i = 0; i < T.length; i++) if (T[i].at <= this.clock) { const t = T.splice(i--, 1)[0]; try { t.fn(); } catch (e) { console.error('timer', e); } }
  }

  // ---------------------------------------------------------------- helpers used by story / actions / monster
  say(speaker, text, o = {}) {
    if (this.settings.subtitles || o.force) this.ui.subtitle(speaker, text, o.dur ?? 3.5, !!o.mimic);
    if (o.voice && this.E.ready) this.sfx.voice(text, o.voice);
  }
  toast(text, kind) { this.ui.toast(text, kind); }
  hint(text) { this.hintText = text; this.hintT = 0.25; }
  hintOnce(key, text) { if (this.hinted[key] || !this.settings.hints) return; this.hinted[key] = true; this.ui.toast(text, 'hint', 5200); }
  noise(x, z, r, kind, force) { this.monster.hear(x, z, r, kind, force); }
  surge(a = 1) { for (const l of this.world.lights) l.mult = 0.15; this.surgeT = 0.35 * a; this.glitchAmt = Math.max(this.glitchAmt, 0.4 * a); }
  shake(a) { this.shakeAmt = Math.max(this.shakeAmt, a); }
  glitch(a) { this.glitchAmt = Math.max(this.glitchAmt, a); }
  setFade(f) { this.fade = f; }
  releaseHold(kind) { const o = this.world.content.objs.starter; if (kind === 'starter' && o) o.y = o.y0; }
  openCage(open, instant) { openCage(this, open, instant); }
  vibrate(ms) { if (this.settings.vibration && navigator.vibrate) { try { navigator.vibrate(ms); } catch { /* ignore */ } } }

  // monster callbacks ------------------------------------------------------
  onMonsterStep(m, run) { this.sfx.mstep(m.x, m.z, run); }
  onMonsterVocal(m, kind) { this.sfx.mvocal(m.x, m.z, kind); }
  onMonsterChase() { this.sfx.mvocal(this.monster.x, this.monster.z, 'roar'); this.glitch(0.6); this.vibrate(60); this.hintOnce('run', 'RUN, or break its line of sight and HIDE in a cabinet.'); }
  onMonsterAlert() { this.hintOnce('alert', 'Something heard you. Stay out of sight.'); }
  onMonsterHit() { this.sfx.mvocal(this.monster.x, this.monster.z, 'screech'); }
  onMonsterFound(h) { this.sfx.hideDoor(h.x, h.z, true); this.sfx.jumpscare(); this.shake(1); this.flashAmt = 0.5; this.vibrate(200); }
  onMonsterNearMiss(h) { this.sfx.mvocal(this.monster.x, this.monster.z, 'sniff'); this.hintOnce('breath', 'HOLD BREATH while it is close.'); }
  onMonsterState() { /* hook for debugging */ }

  // ---------------------------------------------------------------- state management
  saveCheckpoint(id) {
    const S = this.state, P = this.player, w = this.world;
    S.checkpoint = id; S.pos = { x: P.x, z: P.z, yaw: P.yaw }; S.health = Math.max(P.health, 30); S.battery = P.fl.battery; S.stamina = P.stamina; S.circ = { ...w.circ };
    writeSave(S); this.ui.cpIcon(); this.saveFlash = 1;
  }
  newGame() {
    this.state = new GameState(); this.applyState(true);
    const P = this.player; P.setPos(START.x, START.z, START.yaw); P.alive = true; P.health = TUNING.health; this.story.begin(true);
    this.startPlay();
  }
  continueGame() {
    const s = readSave(); if (!s) return this.newGame();
    this.state = s; this.applyState(false); this.story.begin(false); this.startPlay();
  }
  applyState(fresh) {
    const S = this.state, P = this.player, M = this.monster;
    this.timers.length = 0; resetWorld(this); syncWorld(this); this.hinted = fresh ? {} : this.hinted;
    P.alive = true; P.health = clamp(S.health, 60, TUNING.health); if (fresh) P.health = TUNING.health; P.fl.battery = S.battery; P.fl.on = false; P.fl.reload = 0; P.fl.dead = S.battery <= 0; P.stamina = TUNING.stamina; P.exhausted = false; P.hidden = null; P.locked = false; P.wantCrouch = false; P.hurtT = 0;
    if (S.pos) P.setPos(S.pos.x, S.pos.z, S.pos.yaw); else P.setPos(START.x, START.z, START.yaw);
    M.active = false; M.visible = false; M.heard.length = 0; this.fx.n = 0;
    this.story.reset(); this.hold = null; this.target = null; this.hideDelay = 0; this.dyingT = 0; this.fadeTo = 0; this.fade = 0; this.radio.on = false; this.dawn = 0;
    this.world.update(0, this.time);
    if (S.stage > 0) { M.setZones([]); this.story.onStage(S.stage); if (S.stage >= 5) { M.speedMul = 1.35; M.wake(102, 26); } }
    this.story.refreshObjective(true, true);
  }
  startPlay() {
    this.mode = 'play'; this.input.reset(); this.input.enabled = true; this.ui.setPlaying(true); this.E.resume(); this.scape.build(); this.E.applyVolumes();
    this.story.refreshObjective(true, true);
  }
  retry() { this.ui.hideGameOver(); this.state = readSave() || new GameState(); this.state.deaths++; this.applyState(false); this.fadeTo = 0; this.fade = 1; this.fadeSpeed = 1.2; this.story.begin(false); this.startPlay(); this.toast('Checkpoint loaded'); }
  // restart from the last checkpoint on purpose (pause menu): no death is counted
  restartCp() { this.ui.hidePause(); this.ui.closeModal(true); const s = readSave(); this.state = s || new GameState(); this.applyState(!s); if (!s) { const P = this.player; P.setPos(START.x, START.z, START.yaw); P.health = TUNING.health; } this.fadeTo = 0; this.fade = 1; this.fadeSpeed = 1.2; this.story.begin(!s); this.startPlay(); this.toast('Checkpoint loaded'); }
  toMenu() { this.timers.length = 0; this.mode = 'menu'; this.input.enabled = false; this.input.reset(); this.ui.setPlaying(false); this.ui.showMenu(hasSave()); this.fade = 0; this.fadeTo = 0; this.E.vol.master = this.settings.master; this.E.applyVolumes(); this.radio.on = false; }
  pause() { if (this.mode !== 'play') return; this.mode = 'pause'; this.input.enabled = false; this.input.reset(); this.ui.showPause(); if (this.E.ready) this.E.master.gain.setTargetAtTime(this.settings.mute ? 0 : this.settings.master * 0.25, this.E.now, 0.05); }
  resume() { if (this.mode !== 'pause') return; this.mode = 'play'; this.input.enabled = !this.ui.modal; this.ui.hidePause(); this.E.applyVolumes(); this.E.resume(); }
  endChapter() { this.mode = 'end'; this.input.enabled = false; this.input.reset(); this.fadeTo = 1; this.fadeSpeed = 0.35; this.ui.setPlaying(false); this.later(3.2, () => this.ui.showComplete(this.stats())); this.sfx.chime(1.2); }
  stats() { const S = this.state; return { time: S.playTime, deaths: S.deaths, secrets: S.secrets, notes: S.notes.length, total: Object.keys(NOTES).length }; }

  // ---------------------------------------------------------------- hiding
  beginHide(spot) {
    const P = this.player; if (this.hideDelay > 0 || P.hidden || spot.occupied) return;
    spot.target = 1.35; this.hideSpot = spot; this.hideDelay = 0.42; this.sfx.hideDoor(spot.x, spot.z, true); this.noise(spot.x, spot.z, 4, 'door');
  }
  leaveHide() {
    const P = this.player, s = P.hidden; if (!s) return;
    P.exitHide(); s.target = 1.25; this.later(0.65, () => { s.target = 0; }); this.sfx.hideDoor(s.x, s.z, true); this.ui.setHidden(false);
  }
  tuneRadio(f) { const r = this.radio; r.freq = clamp(Math.round(f * 10) / 10, 87.5, 108); this.scape.tuneBlip(r.freq); this.state.puzzle.freq = r.freq; }

  // ---------------------------------------------------------------- main update
  frame(dt) { this.step(dt); renderFrame(this, dt); this.perfTick(dt); }
  // the whole simulation step without drawing (the tests drive this directly)
  step(dt) {
    dt = Math.min(dt, 0.1); this.time += dt;
    const m = this.mode;
    this.fade += (this.fadeTo - this.fade) * Math.min(1, dt * this.fadeSpeed * 2.5);
    if (m === 'play') this.updatePlay(Math.min(dt, 0.05));
    else if (m === 'dying') this.updateDying(dt);
    else {
      this.world.update(m === 'pause' ? 0 : dt, this.time);
      if (m === 'menu') this.fx.update(dt, { x: 9, y: 1.6, z: 63, yaw: 1.57 }, this.world, null, 0);
      if (m === 'menu' || m === 'dead' || m === 'end') this.scape.update(dt, { outdoor: m !== 'dead', threat: 0, chase: 0, alarm: false, power: 0 });
    }
    if (m !== 'pause' && !(m === 'play' && this.ui.modal && this.ui.modalFreeze)) this.stepTimers(Math.min(dt, 0.05));
  }

  updatePlay(dt) {
    const P = this.player, M = this.monster, w = this.world, I = this.input, ui = this.ui, S = this.state, g = w.grid;
    const frozen = ui.modal && ui.modalFreeze;
    if (frozen) { w.update(0, this.time); return; }
    S.playTime += dt;
    I.enabled = !ui.modal && this.hideDelay <= 0;
    P.locked = !!ui.modal || this.hideDelay > 0;
    const look = I.takeLook(), ax = I.axes();
    const use = I.isHeld('use') || I.keys.has('KeyE') || I.keys.has('Space'), useEdge = use && !this.prevUse; this.prevUse = use;
    if (!ui.modal) {
      if (I.take('flash')) P.toggleFlash();
      if (I.take('crouch') && !P.hidden) P.wantCrouch = !P.wantCrouch;
      if (I.take('battery')) this.useBattery();
      if (I.take('medkit')) this.useMedkit();
      if (I.take('radio')) { this.radio.on = true; ui.openRadio(this.radioCtl()); }
      if (I.take('inventory')) ui.openInventory(this.invCtl());
      if (I.take('answer')) this.story.answer();
      if (I.take('leave') && P.hidden) this.leaveHide();
      if (I.take('pause')) { this.pause(); I.clearEdges(); return; }
    }
    I.clearEdges();
    // hiding transition
    if (this.hideDelay > 0) { this.hideDelay -= dt; if (this.hideDelay <= 0) { P.locked = false; P.enterHide(this.hideSpot); this.hideSpot.target = 0; this.sfx.hideDoor(this.hideSpot.x, this.hideSpot.z, false); ui.setHidden(true); this.hintOnce('hidden', 'HOLD BREATH (B / button) when it gets close. LEAVE to step out.'); } }
    // interaction
    const tgt = ui.modal || P.hidden ? null : findTarget(this); this.target = tgt;
    if (P.hidden && useEdge && !this.hideDelay) this.leaveHide();
    else if (tgt && tgt.hold) this.holdProg = holdTick(this, dt, tgt, use && !ui.modal);
    else { if (this.hold) holdTick(this, dt, null, false); this.holdProg = null; if (useEdge && tgt && !ui.modal) activate(this, tgt); }
    // simulation
    P.update(dt, ax, [look[0], look[1]], I.isHeld('breath') && !ui.modal);
    this.handlePlayerEvents();
    w.update(dt, this.time); updateDyn(this, dt);
    if (this.surgeT > 0) { this.surgeT -= dt; if (this.surgeT <= 0) for (const l of w.lights) l.mult = 1; }
    if (this.consoleLock > 0) this.consoleLock -= dt;
    M.update(dt, P);
    this.story.update(dt);
    const pc = this._pc || (this._pc = { x: 0, y: 0, z: 0, yaw: 0 }); pc.x = P.x; pc.y = P.eyeY; pc.z = P.z; pc.yaw = P.yaw;
    this.fx.update(dt, pc, w, w.content.fx, this.R.q);
    if (P.hurtT > 0.8 && Math.random() < dt * 20) this.fx.blood(P.x, P.eyeY - 0.3, P.z, 2);
    this.updateRadio(dt);
    this.updateAudio(dt);
    this.hudT -= dt; if (this.hudT <= 0) { this.hudT = 0.08; this.updateHud(); }
    void g;
  }
  handlePlayerEvents() {
    const P = this.player, M = this.monster, g = this.world.grid, ev = P.events;
    for (let i = 0; i < ev.length; i++) {
      const e = ev[i];
      switch (e.type) {
        case 'step': { const ai = g.areaAt(P.x, P.z), fl = ai >= 0 ? g.areas[ai].floor : 'floor'; this.sfx.step(fl === 'dirt' ? 'dirt' : fl === 'tile' ? 'tile' : fl === 'metal' ? 'metal' : 'floor', e.sprint ? 1.3 : 1, e.crouch); M.hear(P.x, P.z, P.noise, 'step'); break; }
        case 'exhausted': this.sfx.breath('gasp'); this.toast('Out of breath', 'hint', 1800); break;
        case 'gasp': this.sfx.breath('gasp', 1.4); M.hear(P.x, P.z, 7, 'noise'); this.toast('You gasp for air!', 'bad', 1800); break;
        case 'flashToggle': this.sfx.flash(e.on); break;
        case 'flashDead': this.sfx.flashDead(); this.toast('Flashlight battery is dead', 'bad', 2400); break;
        case 'reload': this.sfx.reload(); this.toast('Replacing battery...', undefined, 1500); break;
        case 'reloadDone': this.toast('Flashlight recharged', undefined, 1800); break;
        case 'hurt': this.sfx.hurt(); this.shake(0.8); this.glitch(0.5); this.vibrate(120); this.fx.blood(P.x, P.eyeY - 0.2, P.z, 18, e.dirX * 0.4, e.dirZ * 0.4); break;
        case 'dead': this.die(); break;
        default: break;
      }
    }
    ev.length = 0;
  }
  useBattery() {
    const S = this.state, P = this.player;
    if (P.fl.reload > 0) return;
    if (P.fl.battery > 92) { this.toast('Battery is still full', undefined, 1500); return; }
    if ((S.items.battery || 0) <= 0) { this.toast('No spare batteries', 'bad', 1800); return; }
    S.items.battery--; P.startReload();
  }
  useMedkit() {
    const S = this.state, P = this.player;
    if (P.health >= TUNING.health) { this.toast('Health is full', undefined, 1500); return; }
    if ((S.items.medkit || 0) <= 0) { this.toast('No medkits', 'bad', 1800); return; }
    S.items.medkit--; P.heal(TUNING.medkit); this.sfx.heal(); this.toast(`+${TUNING.medkit} health`, undefined, 1800);
  }
  die() {
    if (this.mode === 'dying') return;
    this.mode = 'dying'; this.dyingT = 0; this.input.enabled = false; this.input.reset(); this.ui.setPlaying(false); this.ui.closeModal();
    this.sfx.jumpscare(); this.flashAmt = 1; this.shake(1); this.vibrate(400); this.radio.on = false; this.ui.setHidden(false);
    this.scape.update(0, { chase: 0, threat: 0 });
  }
  updateDying(dt) {
    const P = this.player, M = this.monster; this.dyingT += dt;
    this.world.update(dt, this.time); M.update(dt, P); this.fx.update(dt, P.camera(1.2), this.world, null, 0);
    // the camera is dragged round to face the killer
    const ang = Math.atan2(M.x - P.x, -(M.z - P.z)); let d = ang - P.yaw; d = Math.atan2(Math.sin(d), Math.cos(d)); P.yaw += d * Math.min(1, dt * 7); P.pitch += (-0.12 - P.pitch) * Math.min(1, dt * 4);
    M.anim.attack = 0.7 + 0.3 * Math.sin(this.dyingT * 18); M.anim.jaw = 1;
    P.hurtT = 1;
    if (this.dyingT > 1.5) this.fadeTo = 1, this.fadeSpeed = 2;
    if (this.dyingT > 2.7 && this.mode === 'dying') { this.mode = 'dead'; this.ui.showGameOver(TIPS[(Math.random() * TIPS.length) | 0], hasSave()); }
  }

  // ---------------------------------------------------------------- radio
  radioCtl() {
    const g = this, r = this.radio;
    return { get freq() { return r.freq; }, tune: (f) => g.tuneRadio(f), info: () => g.radioInfo(), close: () => { r.on = false; } };
  }
  radioInfo() {
    const r = this.radio, st = radioStation(r.freq), near = this.story.inZone.array;
    return { freq: r.freq, locked: !!st && (!st.needNear || near), weak: !!st && st.needNear && !near, name: st ? st.name : '', stat: r.stat };
  }
  updateRadio(dt) {
    const r = this.radio, P = this.player, S = this.state, near = this.story.inZone.array;
    if (!r.on) { r.stat = 1; return; }
    const st = radioStation(r.freq), dist = radioSignal(r.freq), usable = st && (!st.needNear || near);
    r.stat = usable ? 0.07 : clamp(dist / 1.1, 0.22, 1) * (st && st.needNear && !near ? 0.7 : 1);
    r.shift = (Math.sin(this.time * 7) + Math.sin(this.time * 13.3)) * 300 * r.stat;
    this.radioT -= dt; if (this.radioT <= 0) { this.radioT = 1.4; this.noise(P.x, P.z, 3 + 8 * r.stat, 'radio'); }
    if (Math.random() < dt * 6 * r.stat) this.scape.crackle(r.stat);
    if (usable) {
      if (r.station !== st) { r.station = st; r.line = 0; r.next = this.time + 0.6; }
      if (this.time >= r.next) {
        const ln = st.lines[r.line], isRao = ln[0] === 'DR. RAO', dur = this.sfx.voice(ln[1], { radio: true, pitch: isRao ? 215 : ln[0] === 'CARRIER' ? 90 : 120, speed: 0.85, seed: (r.line + 1) * 7 + (st.f | 0), vol: 0.95 });
        this.say(ln[0], ln[1], { dur: Math.max(2.6, dur + 0.6), force: true });
        r.next = this.time + dur + (r.line === st.lines.length - 1 ? 7 : 1.0); r.line++;
        if (r.line >= st.lines.length) { r.line = 0; if (st.note && S.addNote(st.note)) { this.toast('Radio message added to documents', 'key'); this.story.onProgress('radio'); } }
      }
    } else r.station = null;
  }

  // ---------------------------------------------------------------- inventory UI controller
  invCtl() { const g = this; return { state: this.state, health: () => g.player.health, battery: () => g.player.fl.battery, useBattery: () => g.useBattery(), useMedkit: () => g.useMedkit(), read: (id) => g.ui.openNote(NOTES[id], () => {}) }; }

  // ---------------------------------------------------------------- audio steering + HUD
  updateAudio(dt) {
    const P = this.player, M = this.monster, w = this.world, g = w.grid, E = this.E, S = this.state;
    const ai = g.areaAt(P.x, P.z), a = ai >= 0 ? g.areas[ai] : g.areas[0];
    if (E.ready) {
      E.setListener(P.x, P.z, P.yaw); E.occlude = (x, z) => !g.los(P.x, P.z, x, z, true);
      if (ai !== this.audioArea) { this.audioArea = ai; E.setReverb(a.reverb); }
    }
    const chase = M.active && (M.state === MS.CHASE || M.state === MS.ATTACK) ? 1 : 0;
    const th = M.threat(P); this.threatSm += (Math.max(th, chase) - this.threatSm) * Math.min(1, dt * 1.5);
    this.scape.update(dt, { outdoor: !!a.outdoor, power: w.circCur[w.areaCirc[ai]] ?? 1, threat: this.threatSm, chase, genOn: S.flag('gen'), genX: 70, genZ: 21.5, alarm: S.flag('arrayDone') && !S.flag('complete'), radio: { on: this.radio.on, stat: this.radio.stat, car: this.radio.station && this.radio.station.id === 'carrier' ? 1 : 0, shift: this.radio.shift }, sfx: this.sfx });
    // heartbeat when hunted or badly hurt, laboured breathing when exhausted
    const low = 1 - P.health / TUNING.health, hbk = Math.max(this.threatSm * 0.9, low > 0.5 ? (low - 0.5) * 1.6 : 0);
    this.hb -= dt; if (hbk > 0.2 && this.hb <= 0) { this.hb = 1.15 - 0.6 * hbk; this.sfx.heart(0.35 + 0.65 * hbk); }
    this.br -= dt; if ((P.exhausted || P.stamina < 22) && !P.hidden && this.br <= 0) { this.br = 1.25; this.sfx.breath('out', 0.9); }
    if (P.hidden && !P.holding && M.active && M.dist < 12 && this.br <= 0) { this.br = 2.1; this.sfx.breath('out', 0.5); }
  }
  updateHud() {
    const P = this.player, S = this.state, tgt = this.target, ui = this.ui, M = this.monster;
    ui.hud({ health: P.health, stamina: P.stamina, exhausted: P.exhausted, battery: P.fl.battery, on: P.fl.on, reload: P.fl.reload > 0, noise: clamp(P.noise / 13, 0, 1), crouch: P.wantCrouch, hidden: !!P.hidden, breath: P.breath, holding: P.holding, items: S.items, flags: { radio: S.flag('knowsRadio') || S.notes.includes('rao_channel') || S.notes.includes('staff') }, threat: this.threatSm, save: this.saveFlash });
    this.saveFlash = Math.max(0, this.saveFlash - 0.08);
    if (this.hintT > 0) { this.hintT -= 0.08; ui.prompt(null, this.hintText, null, true); }
    else if (tgt) ui.prompt(tgt.verb, tgt.label, tgt.hold ? this.holdProg : null);
    else if (P.hidden) ui.prompt(null, null);
    else ui.prompt(null, null);
    if (this.debug) ui.debug(`${this.perf.fps | 0} fps  ${this.R.qname}  mon:${M.active ? M.stateName : '-'} aw:${M.awareness.toFixed(2)} d:${M.dist.toFixed(0)}  hp:${P.health | 0}  stage:${S.stage}  ${S.objective}`);
  }
  // simple frame-time governor: drops the quality tier if the device cannot keep ~30 fps
  perfTick(dt) {
    const p = this.perf; p.sum += dt; p.n++;
    if (p.sum < 2) return;
    p.ms = (p.sum / p.n) * 1000; p.fps = p.n / p.sum; p.sum = 0; p.n = 0;
    if (this.mode !== 'play' && this.mode !== 'menu') return;
    if (this.settings.quality !== 'auto') return;
    if (p.ms > 34) p.slow++; else p.slow = Math.max(0, p.slow - 1);
    if (p.slow >= 2) { p.slow = 0; const tier = this.R.qname === 'high' ? 'medium' : this.R.qname === 'medium' ? 'low' : null; if (tier) { this.R.setQuality(tier); this.R.resize(innerWidth, innerHeight, window.devicePixelRatio || 1); this.autoDowngraded = tier; if (this.mode === 'play') this.ui.toast(`Auto quality: graphics lowered to ${tier} to keep it smooth`, 'hint', 4200); } }
  }
}
