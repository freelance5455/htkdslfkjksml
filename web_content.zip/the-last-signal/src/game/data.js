// Story text, puzzle solutions and tuning constants for Chapter 1. Pure data (Node-testable).
export const CODES = { locker: '1406', cage: '7319', null: '417', panel: [1, 0, 0, 1], breakers: [2, 3, 1] };

export const STATIONS = [
  { f: 88.4, id: 'staff', name: 'STAFF CHANNEL', note: 'staff', lines: [
    ['DR. RAO', '...this is Dr. Meera Rao, staff emergency channel. If anyone can hear this...'],
    ['DR. RAO', 'The supervisor cage keypad. Seven. Three. One. Nine. The Level 3 card is inside.'],
    ['DR. RAO', 'Do not trust any voice that sounds like yours. Repeat. Seven. Three. One. Nine.'] ] },
  { f: 91.5, id: 'distress', name: 'DISTRESS LOOP', lines: [
    ['DR. RAO', 'Please... help me get out of here.'], ['DR. RAO', 'But if you hear your own voice... DO NOT ANSWER.'] ] },
  { f: 104.7, id: 'carrier', name: 'ARRAY CARRIER', needNear: 'array', note: 'carrier', lines: [
    ['CARRIER', '(a flat tone. Under it, a voice counting, very slowly)'],
    ['CARRIER', 'Null sequence. Four. One. Seven.'], ['CARRIER', 'Four. One. Seven. Four. One. Seven.'] ] },
];

export const NOTES = {
  brief: { title: 'Field Order 117/B', kind: 'doc', body: 'WESTERN SIGNALS UNIT - FIELD ORDER 117/B\n\nTO: Sgt. Kabir Sen (Signals)\n\nAt 02:14 an emergency carrier began repeating from VAJRA DEEP RESEARCH STATION. The station was sealed 17 years ago. It has no power, no staff and no listed survivors.\n\nLocate the transmitter. Record the source. Do NOT reply on any station frequency.\n\nYou have a torch, a field radio and four hours before the relief column arrives.\n\n- Col. R. Verma' },
  closure: { title: 'Notice of Closure', kind: 'doc', body: 'NOTICE OF CLOSURE\n\nBy order of the Ministry, VAJRA DEEP RESEARCH STATION is permanently sealed with effect from 14 JUNE 2009.\n\nAll research is terminated. All personnel are accounted for. All records are classified.\n\nDO NOT REOPEN.\nDO NOT BROADCAST.\n\n- Dr. S. Bhatt, Station Director' },
  shiftlog: { title: 'Security Log, 13 Jun', kind: 'doc', body: '22:40  Lab Wing dark again. Fuse E-3 blown. Spares are in the break room, top shelf. Not going in there tonight.\n\n23:05  Knocking from inside the Lab door. Three, pause, three.\n\n23:15  Pillai took his keycard and went to check. I told him not to.\n\n23:40  Pillai came back to the door. Did not use his keycard. He just stood there and said my name.\n\nIt was Pillai\'s voice.\nI never told him my name.' },
  guardnote: { title: 'Guard Locker 4', kind: 'doc', body: 'My keycard is in locker 4.\n\nIf anything happens to me: the combination is the date on the closure order. Day, then month.\n\nI know. I am not supposed to write it down.' },
  fusebox: { title: 'Fuse Box E-3', kind: 'doc', body: 'FUSE BOX E-3 - LAB WING\n\n20A cartridge fuse: MISSING\nReplacement stock: BREAK ROOM, top shelf.\n\nRe-energising the Lab Wing will wake the ventilation fans. Keep the noise down.' },
  research1: { title: 'Research Log, Day 61', kind: 'doc', body: 'DR. M. RAO - DAY 61\n\nSubject 9 no longer responds to light. It responds to sound only, and it answers us in OUR voices. Iyer\'s. Mine.\n\nThe Array\'s carrier seems to be teaching it.\n\nI have asked for the Array to be shut down. The Director says the Ministry wants more data.' },
  rao_channel: { title: 'Dr. Rao: Radio Note', kind: 'doc', body: 'STAFF RADIO NOTE\n\nEmergency staff channel: 88.4\nThe Array carrier: 104.7 - NEVER tune this unless you are standing beside the Array.\n\nIf you hear your own voice on any channel, do not answer.\nIt is not you.' },
  whiteboard: { title: 'Whiteboard: Rack 7', kind: 'doc', body: 'RACK 7 SERVICE PANEL - LAMP CHECK\n\n  A    B    C    D\n  ●    ○    ○    ●\n\n(filled = UP, empty = DOWN)\n\nThe rack door releases when the panel matches.' },
  placard: { title: 'Generator G-2 Placard', kind: 'doc', body: 'BACKUP GENERATOR G-2\n\n1. Fill the tank. Fuel intake is on the right.\n2. Reset the breakers IN ORDER:  2 - 3 - 1\n3. Pull the starter and HOLD until it catches.\n\nWARNING: start-up is LOUD. Close the doors behind you.' },
  decon: { title: 'Decon Log, Cycle 3', kind: 'doc', body: 'Subject 9 breached containment at 23:51. It reached the Lab Wing in under ten minutes.\n\nIt does not run toward light.\nIt runs toward NOISE.\n\nStay quiet. Stay in the dark. If it comes close, hold your breath.' },
  cage: { title: 'Supervisor Cage', kind: 'doc', body: 'KEYPAD CODE CHANGED after the breach.\nI memorised it from the staff channel. Dr. Rao reads it out on 88.4.\n\nThe Level 3 keycard is inside the cage.' },
  secret: { title: 'Rao\'s Diary', kind: 'doc', body: 'I came down here on the night of the breach. Iyer is the thing in the corridors now. I know his walk.\n\nIt cannot see well. It hears everything. It learns the voices it hears: mine, Iyer\'s, the guards\'. It learns yours.\n\nThe Array broadcasts what the creature repeats. A loop, feeding itself. The only way is to silence the Array at the source. Chamber Zero. Three dials. The null sequence, on the carrier.\n\nI will transmit as long as the battery lasts. Please. Come and get me out of here.\n\nBut if you hear your own voice...' },
  chamber: { title: 'Array Console', kind: 'doc', body: 'RESONANCE ARRAY - NULL SEQUENCE\n\nTo silence the Array: set the three dials to the NULL SEQUENCE broadcast on the carrier (104.7 MHz, in range of the Array), then ENGAGE.\n\nA wrong sequence causes a surge. Everything in the facility will hear it.' },
  staff: { title: 'Radio: Supervisor Cage Code', kind: 'radio', body: 'Dr. Rao, on 88.4:\n"The supervisor cage keypad. Seven. Three. One. Nine."' },
  carrier: { title: 'Radio: Null Sequence', kind: 'radio', body: 'The carrier, on 104.7, counting:\n"Four. One. Seven."' },
};

export const MIMIC = [
  'Hello? Is anyone there?', 'Kabir... I am hurt. Over here.', 'Please answer me. Please, I can hear you breathing.',
];

export const OBJECTIVES = {
  start: 'Find the way into the Vajra Deep station.',
  lobby: 'The main door has sealed. Search the checkpoint for another way through.',
  keycard: 'Find a Level 1 keycard. The guard room may have one.',
  labdoor: 'Use the keycard on the Lab Wing door.',
  fuse: 'The Lab Wing has no power. Find a 20A fuse for fuse box E-3.',
  fuseBox: 'Install the fuse in fuse box E-3 (Lab Wing corridor).',
  research: 'Search the Research Room for the source of the signal.',
  generator: 'Restart the backup generator: it needs fuel, the breaker panel reset in the right order, and the starter handle.',
  cage: 'Get the Level 3 keycard: the Storage B2 cage (code on the radio), or another way.',
  chamber: 'Reach Chamber Zero through the link corridor and the ante-room.',
  array: 'Tune the radio to the Array carrier beside the Array, then enter the null sequence.',
  escape: 'ESCAPE. Reach the surface hatch.',
  wheel: 'Turn the wheel to unseal the hatch. HOLD.',
  done: 'Get outside.',
};

export const TUNING = {
  walk: 2.3, sprint: 4.1, crouch: 1.15, eye: 1.62, eyeCrouch: 1.02, radius: 0.3,
  stamina: 100, staminaDrain: 24, staminaRegen: 15, staminaDelay: 1.1, staminaMin: 22,
  batteryDrain: 0.55, batteryCharge: 100, flashRange: 22,
  health: 100, medkit: 50, hit: 52, hitCooldown: 1.3,
};

export const CIRCUITS = ['always', 'lobby', 'ck', 'lab', 'gen', 'emerg'];
