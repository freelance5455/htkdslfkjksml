// First-person player: movement, collision, crouch, sprint stamina, head-bob, footsteps, flashlight + battery, health, hiding.
import { TUNING as T } from './data.js';
import { clamp, damp, wrapAngle } from '../engine/math.js';

export class Player {
  constructor(world) {
    this.w = world; this.g = world.grid;
    this.x = 0; this.z = 0; this.y = 0; this.yaw = 0; this.pitch = 0; this.vx = 0; this.vz = 0;
    this.crouchT = 0; this.wantCrouch = false; this.eye = T.eye;
    this.phase = 0; this.bobY = 0; this.bobX = 0; this.shake = 0; this.roll = 0; this.fov = 1.25;
    this.stamina = T.stamina; this.exhausted = false; this.sDelay = 0; this.sprinting = false; this.moving = false; this.speed = 0;
    this.health = T.health; this.hurtT = 0; this.alive = true; this.regen = 0;
    this.hidden = null; this.hideBlend = 0; this.breath = 1; this.holding = false; this.gasp = 0;
    this.noise = 0; this.stepSide = 0; this.stride = 0;
    this.fl = { on: false, battery: 100, flick: 0, reload: 0, dead: false, dir: [0, 0, -1], k: 1 };
    this.events = [];             // {type, ...} drained by the game each frame
    this.locked = false;          // true while a modal UI or cutscene owns input
    this.lastHit = 0;
  }
  setPos(x, z, yaw = this.yaw) { this.x = x; this.z = z; this.y = this.g.floorY(x, z); this.yaw = yaw; this.pitch = 0; this.vx = this.vz = 0; this.hidden = null; this.hideBlend = 0; }
  get crouching() { return this.crouchT > 0.5; }
  get eyeY() { return this.y + this.eye + this.bobY; }
  forward() { return [Math.sin(this.yaw), -Math.cos(this.yaw)]; }

  update(dt, ax, look, holdBreath) {
    if (!this.alive) return;
    this.lastHit += dt;
    if (this.hidden) { this._updateHidden(dt, look, holdBreath); this._updateFlash(dt); return; }
    // look
    if (!this.locked) {
      this.yaw = wrapAngle(this.yaw + look[0]); this.pitch = clamp(this.pitch + look[1], -1.25, 1.25);
    }
    // crouch smoothing
    this.crouchT = damp(this.crouchT, this.wantCrouch ? 1 : 0, 10, dt);
    const targetEye = T.eye + (T.eyeCrouch - T.eye) * this.crouchT;
    this.eye = damp(this.eye, targetEye, 14, dt);
    // intent
    let ix = this.locked ? 0 : ax.x, iy = this.locked ? 0 : ax.y;
    const mag = Math.min(1, Math.hypot(ix, iy));
    const canSprint = ax.sprint && iy > 0.2 && !this.wantCrouch && !this.exhausted && this.stamina > 1 && !this.locked;
    this.sprinting = canSprint && mag > 0.1;
    let speed = this.wantCrouch ? T.crouch : this.sprinting ? T.sprint : T.walk;
    if (iy < 0) speed *= 0.7;
    const sn = Math.sin(this.yaw), cs = Math.cos(this.yaw);
    const wx = (cs * ix + sn * iy), wz = (sn * ix - cs * iy);
    const l = Math.hypot(wx, wz) || 1;
    const tx = mag > 0.02 ? (wx / l) * speed * mag : 0, tz = mag > 0.02 ? (wz / l) * speed * mag : 0;
    const k = mag > 0.02 ? 11 : 15;
    this.vx = damp(this.vx, tx, k, dt); this.vz = damp(this.vz, tz, k, dt);
    // integrate with sub-steps + collision
    const dx = this.vx * dt, dz = this.vz * dt, n = Math.max(1, Math.ceil(Math.hypot(dx, dz) / 0.12));
    for (let i = 0; i < n; i++) {
      const r = this.g.resolve(this.x + dx / n, this.z + dz / n, T.radius);
      this.x = r.x; this.z = r.z;
    }
    this.speed = Math.hypot(this.vx, this.vz); this.moving = this.speed > 0.35;
    this.y = damp(this.y, this.g.floorY(this.x, this.z), 16, dt);
    // stamina
    if (this.sprinting && this.moving) { this.stamina = Math.max(0, this.stamina - T.staminaDrain * dt); this.sDelay = T.staminaDelay; if (this.stamina <= 0) { this.exhausted = true; this.events.push({ type: 'exhausted' }); } }
    else { this.sDelay -= dt; if (this.sDelay <= 0) this.stamina = Math.min(T.stamina, this.stamina + T.staminaRegen * dt * (this.moving ? 0.6 : 1)); }
    if (this.exhausted && this.stamina >= T.staminaMin) this.exhausted = false;
    // head bob + footsteps
    const stride = this.sprinting ? 1.55 : this.wantCrouch ? 0.95 : 1.15;
    if (this.moving) {
      this.phase += (this.speed * dt / stride) * Math.PI;
      const sprintK = this.sprinting ? 1.5 : 1;
      this.bobY = Math.sin(this.phase * 2) * 0.034 * sprintK * (this.bobScale ?? 1) * (this.wantCrouch ? 0.6 : 1);
      this.bobX = Math.cos(this.phase) * 0.018 * sprintK * (this.bobScale ?? 1);
      const s = Math.floor(this.phase / Math.PI);
      if (s !== this.stride) { this.stride = s; this.stepSide ^= 1; this.events.push({ type: 'step', side: this.stepSide, sprint: this.sprinting, crouch: this.wantCrouch }); }
    } else { this.bobY = damp(this.bobY, 0, 8, dt); this.bobX = damp(this.bobX, 0, 8, dt); }
    this.noise = !this.moving ? (this.exhausted ? 2.2 : 0.4) : this.sprinting ? 13 : this.wantCrouch ? 1.6 : 5.2;
    this.roll = damp(this.roll, -this.bobX * 0.6 + (this.vx * Math.cos(this.yaw) + this.vz * Math.sin(this.yaw)) * -0.012, 8, dt);
    this.shake = Math.max(0, this.shake - dt * 2.2); this.hurtT = Math.max(0, this.hurtT - dt);
    this.breath = Math.min(1, this.breath + dt * 0.5);
    this._updateFlash(dt);
  }
  _updateHidden(dt, look, holdBreath) {
    const h = this.hidden;
    this.hideBlend = Math.min(1, this.hideBlend + dt * 3.2);
    this.yaw = wrapAngle(h.yaw + clamp(wrapAngle(this.yaw - h.yaw) + look[0] * 0.8, -0.75, 0.75));
    this.pitch = clamp(this.pitch + look[1] * 0.8, -0.4, 0.4);
    this.eye = damp(this.eye, h.eye, 8, dt); this.bobY = 0; this.bobX = 0; this.roll = damp(this.roll, 0, 8, dt);
    this.x = damp(this.x, h.inside[0], 12, dt); this.z = damp(this.z, h.inside[1], 12, dt); this.speed = 0; this.moving = false; this.sprinting = false;
    this.vx = this.vz = 0;
    // breath holding: drains a meter, forced gasp when empty
    if (holdBreath && this.breath > 0.02 && this.gasp <= 0) { this.holding = true; this.breath = Math.max(0, this.breath - dt / 7); if (this.breath <= 0.02) { this.holding = false; this.gasp = 2.4; this.events.push({ type: 'gasp' }); } }
    else { this.holding = false; this.breath = Math.min(1, this.breath + dt * (this.gasp > 0 ? 0.12 : 0.28)); }
    this.gasp = Math.max(0, this.gasp - dt);
    this.noise = this.holding ? 0 : this.gasp > 0 ? 4.5 : 1.4;
    this.shake = Math.max(0, this.shake - dt * 2.2); this.hurtT = Math.max(0, this.hurtT - dt);
    this.stamina = Math.min(T.stamina, this.stamina + T.staminaRegen * dt);
  }
  enterHide(spot) { this.hidden = spot; this.hideBlend = 0; this.wantCrouch = false; this.breath = Math.max(this.breath, 0.6); this.gasp = 0; spot.occupied = true; spot.target = 0; this.events.push({ type: 'hide', spot }); }
  exitHide() { const s = this.hidden; if (!s) return; this.x = s.front[0]; this.z = s.front[1]; this.y = this.g.floorY(this.x, this.z); this.hidden = null; this.hideBlend = 0; s.occupied = false; this.eye = T.eye; this.events.push({ type: 'unhide', spot: s }); }

  // flashlight ----------------------------------------------------------
  toggleFlash() {
    const f = this.fl; if (f.reload > 0) return false;
    if (f.battery <= 0) { this.events.push({ type: 'flashDead' }); return false; }
    f.on = !f.on; this.events.push({ type: 'flashToggle', on: f.on }); return true;
  }
  startReload() { const f = this.fl; if (f.reload > 0) return false; f.reload = 1.5; f.wasOn = f.on; f.on = false; this.events.push({ type: 'reload' }); return true; }
  _updateFlash(dt) {
    const f = this.fl;
    if (f.reload > 0) { f.reload -= dt; if (f.reload <= 0) { f.reload = 0; f.battery = 100; f.dead = false; f.on = !!f.wasOn; this.events.push({ type: 'reloadDone' }); } }
    if (f.on) {
      f.battery = Math.max(0, f.battery - T.batteryDrain * dt);
      if (f.battery <= 0) { f.on = false; f.dead = true; this.events.push({ type: 'flashDead' }); }
    }
    // flicker when low
    let k = 1;
    if (f.on && f.battery < 18) { f.flick -= dt; if (f.flick < 0) { f.flick = 0.05 + Math.random() * (f.battery < 6 ? 0.5 : 1.4); f.k = Math.random() < (f.battery < 6 ? 0.55 : 0.25) ? 0.08 : 1; } k = f.k * (0.55 + 0.45 * Math.min(1, f.battery / 18)); } else f.k = 1;
    f.power = f.on ? k : 0;
    // direction follows the camera with a little lag
    const cp = Math.cos(this.pitch), fx = Math.sin(this.yaw) * cp, fy = Math.sin(this.pitch), fz = -Math.cos(this.yaw) * cp;
    const a = 1 - Math.exp(-16 * dt), d = f.dir;
    d[0] += (fx - d[0]) * a; d[1] += (fy - d[1]) * a; d[2] += (fz - d[2]) * a;
    const l = Math.hypot(d[0], d[1], d[2]) || 1; d[0] /= l; d[1] /= l; d[2] /= l;
  }

  hurt(amount, dirX = 0, dirZ = 0) {
    if (!this.alive || this.god) return;   // `god` is only ever set by the automated tests
    this.health = Math.max(0, this.health - amount); this.hurtT = 1; this.shake = 1; this.lastHit = 0;
    this.events.push({ type: 'hurt', amount, dirX, dirZ });
    if (this.health <= 0) { this.alive = false; this.events.push({ type: 'dead' }); }
  }
  heal(a) { this.health = Math.min(T.health, this.health + a); }
  camera(fov, aspectFix = 1) {
    const hb = this.hidden ? this.hideBlend : 0, sh = this.shake * this.shake;
    const t = performance.now() * 0.001;
    return {
      x: this.x + Math.cos(this.yaw) * this.bobX * 0.6 + Math.sin(t * 47) * sh * 0.012, y: this.eyeY + Math.sin(t * 53) * sh * 0.012, z: this.z + Math.sin(this.yaw) * this.bobX * 0.6,
      yaw: this.yaw + Math.sin(t * 31) * sh * 0.012, pitch: this.pitch, roll: this.roll + Math.sin(t * 41) * sh * 0.014, fov: fov * (1 - 0.06 * hb) * (this.sprinting ? 1.04 : 1), near: 0.07, far: 90,
    };
  }
}
