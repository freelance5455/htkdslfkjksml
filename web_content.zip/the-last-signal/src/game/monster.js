// "The Listener": a blind, sound-driven stalker. 7-state AI (Idle, Patrol, Investigate, Search, Chase, Attack, Return)
// with a hearing + vision awareness model, real A* pathing (no teleporting), door handling and hide-spot searching.
import { Nav } from './nav.js';
import { TUNING as T } from './data.js';
import { angleDiff, wrapAngle, clamp } from '../engine/math.js';

export const S = { IDLE: 0, PATROL: 1, INVESTIGATE: 2, SEARCH: 3, CHASE: 4, ATTACK: 5, RETURN: 6 };
export const STATE_NAMES = ['Idle', 'Patrol', 'Investigate', 'Search', 'Chase', 'Attack', 'Return'];
const SPD = { patrol: 1.55, investigate: 2.5, search: 1.6, return: 1.9, chase0: 3.7, chaseMax: 4.5 };

export class Monster {
  constructor(game) {
    this.game = game; this.w = game.world; this.g = this.w.grid; this.nav = new Nav(this.w, 0.42);
    this.x = 0; this.z = 0; this.y = 0; this.yaw = 0; this.headYaw = 0;
    this.active = false; this.visible = false; this.state = S.IDLE; this.timer = 0; this.t = 0; this.grace = 0;
    this.path = null; this.pi = 0; this.repath = 0; this.stuck = 0;
    this.awareness = 0; this.canSee = false; this.dist = 99; this.lastKnown = null; this.lastSeen = 99; this.chaseT = 0;
    this.heard = []; this.zones = ['front']; this.recent = []; this.sinceEncounter = 0;
    this.plan = []; this.peek = null; this.atk = 0; this.hitDone = false; this.searchT = 0; this.searchCenter = null;
    this.stepAcc = 0; this.vocalT = 3; this.speed = 0; this.anim = { phase: 0, speed: 0, lean: 0, jaw: 0, attack: 0, peek: 0 };
    this.hideSeen = null; this.log = []; this.speedMul = 1; this.opening = false;
  }
  get stateName() { return STATE_NAMES[this.state]; }
  setState(s, why = '') {
    if (this.state === s) return;
    this.state = s; this.timer = 0; this.stuck = 0;
    if (this.log.length > 30) this.log.shift(); this.log.push(`${this.t.toFixed(1)} ${STATE_NAMES[s]} ${why}`);
    this.game.onMonsterState?.(s, why);
  }
  spawn(x, z, yaw = 0, o = {}) {
    this.x = x; this.z = z; this.y = this.g.floorY(x, z); this.yaw = yaw; this.active = o.active !== false; this.visible = this.active;
    this.state = S.IDLE; this.timer = 1 + Math.random() * 3; this.awareness = 0; this.path = null; this.heard.length = 0; this.plan = []; this.peek = null;
    this.speedMul = 1; this.opening = false; this.grace = o.grace ?? 6; this.lastKnown = null; this.chaseT = 0; this.sinceEncounter = 0; this.atk = 0;
  }
  wake(x, z) { this.active = true; this.visible = true; if (x !== undefined) this.hear(x, z, 60, 'door', true); }
  setZones(z) { this.zones = z; }

  // ---------------- perception ----------------
  hear(x, z, loud, kind = 'noise', force = false) {
    if (!this.active || (this.grace > 0 && !force)) return;
    const d = Math.hypot(x - this.x, z - this.z);
    if (d > loud * 2) return;
    let eff = d;
    if (!this.g.los(this.x, this.z, x, z)) eff *= 1.7;
    if (eff > loud && !force) return;
    this.heard.push({ x, z, s: force ? 1 : 1 - eff / loud, kind, t: this.t });
  }
  _lightAt(P) { // rough illumination at the player: sum of nearby active lights (area-linked)
    const w = this.w, ai = this.g.areaAt(P.x, P.z); let s = 0;
    for (const l of w.lights) {
      if (l.cur < 0.05) continue; const amt = w.linkAmount(ai, l.ai); if (amt < 0.05) continue;
      const dx = l.x - P.x, dz = l.z - P.z, dy = l.wy - P.eyeY, d2 = dx * dx + dy * dy + dz * dz;
      if (d2 > l.r * l.r) continue; s += l.cur * amt * (1 - d2 / (l.r * l.r));
    }
    return s;
  }
  _see(dt, P) {
    const dx = P.x - this.x, dz = P.z - this.z, d = Math.hypot(dx, dz); this.dist = d;
    let see = false, range = 8.5;
    if (!P.hidden && P.alive && this.grace <= 0) {
      const fl = P.fl, tdx = -dx / (d || 1), tdz = -dz / (d || 1), pf = P.forward();
      const lit = fl.on && fl.power > 0.2 && (pf[0] * tdx + pf[1] * tdz) > 0.55;
      if (lit) range = 15; else if (this._lightAt(P) > 0.45) range = Math.max(range, 12);
      if (P.sprinting) range *= 1.2; if (P.crouching) range *= 0.62; if (this.state === S.CHASE) range *= 1.35;
      if (d < range) {
        const ang = Math.abs(angleDiff(this.yaw + this.headYaw * 0.6, Math.atan2(dx, -dz))), half = this.state === S.CHASE ? 1.9 : 1.0;
        if (ang < half || d < 2.2) see = this.g.los(this.x, this.z, P.x, P.z);
      }
      this.range = range;
      if (see) { const rate = (1 - d / range) * 2.2 + 0.35; this.awareness = Math.min(1.3, this.awareness + rate * dt * (this.state === S.CHASE ? 3 : 1)); }
      if (d < 1.5 && this.g.los(this.x, this.z, P.x, P.z)) { this.awareness = 1.3; see = true; }
    }
    if (!see) this.awareness = Math.max(0, this.awareness - 0.32 * dt);
    this.canSee = see;
    if (see) { this.lastKnown = [P.x, P.z]; this.lastSeen = 0; this.sinceEncounter = 0; } else this.lastSeen += dt;
  }

  // ---------------- main update ----------------
  update(dt, P) {
    if (!this.active) return;
    this.t += dt; this.timer += dt; this.sinceEncounter += dt; if (this.grace > 0) this.grace -= dt;
    this._see(dt, P);
    this._processHeard(P);
    // vision-driven transitions
    if (this.awareness >= 1 && this.state !== S.CHASE && this.state !== S.ATTACK && P.alive) { this._startChase('saw'); }
    else if (this.awareness > 0.42 && this.canSee && (this.state === S.IDLE || this.state === S.PATROL || this.state === S.RETURN)) { this._investigate(P.x, P.z, 'glimpse'); }
    switch (this.state) {
      case S.IDLE: this._idle(dt); break;
      case S.PATROL: this._patrol(dt); break;
      case S.INVESTIGATE: this._investigateTick(dt, P); break;
      case S.SEARCH: this._search(dt, P); break;
      case S.CHASE: this._chase(dt, P); break;
      case S.ATTACK: this._attack(dt, P); break;
      case S.RETURN: this._return(dt); break;
    }
    this.y = this.g.floorY(this.x, this.z);
    this._animate(dt);
    this._vocals(dt, P);
  }
  _processHeard(P) {
    if (!this.heard.length) return;
    let best = null; for (const h of this.heard) if (!best || h.s > best.s) best = h;
    this.heard.length = 0;
    if (this.state === S.ATTACK) return;
    this.awareness = Math.min(1.3, this.awareness + best.s * 0.55);
    if (this.state === S.CHASE) { if (best.s > 0.2) this.lastKnown = [best.x, best.z]; return; }
    if (best.kind === 'step' && best.s > 0.85 && !P.hidden) { this.awareness = 1.3; return; }
    if (best.s > 0.18 || best.kind === 'door' || best.kind === 'gen') this._investigate(best.x, best.z, best.kind);
  }
  _investigate(x, z, why) {
    if (this.state === S.INVESTIGATE && this.target && Math.hypot(this.target[0] - x, this.target[1] - z) < 2 && this.timer < 4) return;
    this.target = [x, z]; this.setState(S.INVESTIGATE, why); this._goto(x, z); this.game.onMonsterAlert?.(why);
  }
  _startChase(why) {
    this.chaseT = 0; this.sinceEncounter = 0; this.setState(S.CHASE, why); this.repath = 0; this.game.onMonsterChase?.();
  }

  // ---------------- states ----------------
  _idle(dt) {
    this.speed = 0; this.headYaw = Math.sin(this.t * 0.7) * 0.7 + Math.sin(this.t * 2.3) * 0.15;
    if (this.timer > 1.5 && this.timer > (this._idleFor ?? (this._idleFor = 2 + Math.random() * 3))) { this._idleFor = null; this._nextPatrol(); }
  }
  _nextPatrol() {
    const pts = []; for (const z of this.zones) for (const p of (this.w.content.patrol[z] || [])) pts.push(p);
    if (!pts.length) { this.setState(S.IDLE, 'no waypoints'); return; }
    const P = this.game.player;
    const pressure = clamp((this.sinceEncounter - 45) / 90, 0, 0.75);
    const cand = [];
    if (Math.random() < pressure) { const byD = pts.filter((p) => !this.recent.includes(p) && Math.hypot(p[0] - P.x, p[1] - P.z) > 4).sort((a, b) => Math.hypot(a[0] - P.x, a[1] - P.z) - Math.hypot(b[0] - P.x, b[1] - P.z)); if (byD[0]) cand.push(byD[0]); }
    for (let i = 0; i < 10; i++) { const p = pts[(Math.random() * pts.length) | 0]; if (!this.recent.includes(p) && Math.hypot(p[0] - this.x, p[1] - this.z) > 3) cand.push(p); }
    cand.push(...pts);
    for (const pick of cand) {
      if (this.nav.path(this.x, this.z, pick[0], pick[1])) {   // only waypoints that are reachable right now (locked/unpowered doors block)
        this.recent.push(pick); if (this.recent.length > 3) this.recent.shift();
        this.setState(S.PATROL, 'waypoint'); this._goto(pick[0], pick[1]); return;
      }
    }
    this.setState(S.IDLE, 'no reachable waypoint'); this._idleFor = 3;
  }
  _patrol(dt) {
    if (!this._follow(dt, SPD.patrol)) { this.setState(S.IDLE, 'arrived'); this._idleFor = null; }
  }
  _investigateTick(dt, P) {
    const arrived = !this._follow(dt, SPD.investigate);
    if (arrived || this.timer > 25) { this._beginSearch(this.target || [this.x, this.z]); }
  }
  _beginSearch(c) {
    this.searchCenter = c; this.searchT = 9 + Math.random() * 6; this.plan = []; this.peek = null;
    const hides = this.w.content.hides.filter((h) => Math.hypot(h.x - c[0], h.z - c[1]) < 9 && this.g.areaAt(h.x, h.z) >= 0);
    hides.sort((a, b) => Math.hypot(a.x - c[0], a.z - c[1]) - Math.hypot(b.x - c[0], b.z - c[1]));
    if (this.hideSeen) { this.plan.push({ hide: this.hideSeen, sure: true }); this.hideSeen = null; }
    for (const h of hides.slice(0, 3)) if (!this.plan.some((p) => p.hide === h)) this.plan.push({ hide: h });
    for (let i = 0; i < 2; i++) { const a = Math.random() * 6.283, r = 2 + Math.random() * 4, x = c[0] + Math.cos(a) * r, z = c[1] + Math.sin(a) * r; if (this.nav.walkable(Math.floor(x), Math.floor(z))) this.plan.push({ x, z }); }
    this.setState(S.SEARCH, 'arrived'); this.stepIdx = -1; this.path = null; this._nextSearchStep();
  }
  _nextSearchStep() {
    this.stepIdx++; this.peek = null;
    const st = this.plan[this.stepIdx];
    if (!st) { this.path = null; return false; }
    this.cur = st;
    if (st.hide) this._goto(st.hide.front[0], st.hide.front[1]); else this._goto(st.x, st.z);
    return true;
  }
  _search(dt, P) {
    this.searchT -= dt;
    this.headYaw = Math.sin(this.t * 1.6) * 0.9;
    if (this.peek) {
      const pk = this.peek; pk.t += dt; this.speed = 0;
      // face the hide spot
      this._turn(Math.atan2(pk.h.x - this.x, -(pk.h.z - this.z)), 6, dt);
      pk.h.target = clamp(pk.t / 0.5, 0, 1) * 1.5; this.anim.peek = 1;
      if (!pk.rolled && pk.t > 0.7) {
        pk.rolled = true;
        if (P.hidden === pk.h) {
          const p = pk.sure ? 1 : P.holding ? 0.07 : P.gasp > 0 ? 1 : 0.5;
          if (Math.random() < p) { this.game.onMonsterFound?.(pk.h); P.exitHide(); this._startChase('found you'); this.awareness = 1.3; this.lastKnown = [P.x, P.z]; return; }
          this.game.onMonsterNearMiss?.(pk.h);
        }
      }
      if (pk.t > 1.9) { pk.h.target = 0; pk.h.checked = this.t; this.anim.peek = 0; this.peek = null; if (!this._nextSearchStep()) this._endSearch(); }
      return;
    }
    if (this.path) {
      if (!this._follow(dt, SPD.search)) {
        if (this.cur && this.cur.hide) { this.peek = { h: this.cur.hide, t: 0, rolled: false, sure: !!this.cur.sure }; } else if (!this._nextSearchStep()) this._endSearch();
      }
    } else if (!this._nextSearchStep()) this._endSearch();
    if (this.searchT <= 0 && !this.peek) this._endSearch();
  }
  _endSearch() { this.setState(S.RETURN, 'search over'); this.awareness = 0; const z = this._nearestPatrol(); if (z) this._goto(z[0], z[1]); }
  _nearestPatrol() {
    let best = null, bd = 1e9;
    for (const zn of this.zones) for (const p of (this.w.content.patrol[zn] || [])) { const d = Math.hypot(p[0] - this.x, p[1] - this.z); if (d < bd) { bd = d; best = p; } }
    return best;
  }
  _return(dt) { if (!this._follow(dt, SPD.return)) this._nextPatrol(); }
  _chase(dt, P) {
    this.chaseT += dt;
    const sp = Math.min(SPD.chaseMax, SPD.chase0 + this.chaseT * 0.06) * (this.game.difficulty ?? 1);
    this.repath -= dt;
    const tgt = this.canSee ? [P.x, P.z] : this.lastKnown;
    if (tgt && (this.repath <= 0 || !this.path)) { this._goto(tgt[0], tgt[1]); this.repath = this.canSee ? 0.3 : 0.7; }
    const d = Math.hypot(P.x - this.x, P.z - this.z);
    if (d < 1.4 && P.alive && (this.canSee || !P.hidden)) { this.atk = 0; this.hitDone = false; this.setState(S.ATTACK, 'close'); return; }
    const moving = this._follow(dt, sp);
    if (!moving && !this.canSee) { // reached last known position without seeing the player
      this.setState(S.SEARCH, 'lost'); this._beginSearch(this.lastKnown || [this.x, this.z]); return;
    }
    if (this.lastSeen > 5.5 && !this.canSee) { this._beginSearch(this.lastKnown || [this.x, this.z]); }
    if (P.hidden && !this.canSee && this.lastSeen < 1.2 && Math.hypot(P.x - this.x, P.z - this.z) < 18) this.hideSeen = P.hidden; // it watched you slip in
  }
  _attack(dt, P) {
    this.atk += dt; this.speed = 0; this._turn(Math.atan2(P.x - this.x, -(P.z - this.z)), 9, dt);
    this.anim.attack = this.atk < 0.35 ? this.atk / 0.35 : Math.max(0, 1 - (this.atk - 0.35) / 0.5);
    if (!this.hitDone && this.atk >= 0.35) {
      this.hitDone = true;
      const d = Math.hypot(P.x - this.x, P.z - this.z);
      if (d < 1.9 && P.alive) { this.game.onMonsterHit?.(); P.hurt(T.hit, P.x - this.x, P.z - this.z); }
    }
    if (this.atk >= T.hitCooldown) {
      if (!P.alive) { this.setState(S.IDLE, 'killed'); return; }
      this.chaseT = Math.max(this.chaseT, 3); this.awareness = 1.3; this._startChase('again');
    }
  }

  // ---------------- movement ----------------
  _goto(x, z) {
    const p = this.nav.path(this.x, this.z, x, z);
    this.path = p; this.pi = p && p.length > 1 ? 1 : 0; this.pathEnd = [x, z];
    if (!p) { this.stuck += 1; }
    return !!p;
  }
  _turn(yaw, rate, dt) { const d = angleDiff(this.yaw, yaw), s = clamp(d, -rate * dt, rate * dt); this.yaw = wrapAngle(this.yaw + s); }
  // returns true while still travelling
  _follow(dt, speed) {
    speed *= this.speedMul;
    const p = this.path;
    if (!p || this.pi >= p.length) { this.speed = 0; return false; }
    const tx = p[this.pi][0], tz = p[this.pi][1], dx = tx - this.x, dz = tz - this.z, d = Math.hypot(dx, dz);
    if (d < 0.3) { this.pi++; if (this.pi >= p.length) { this.speed = 0; return false; } return true; }
    // doors ahead: open them (takes time), wait until open
    const ax = this.x + (dx / d) * 0.95, az = this.z + (dz / d) * 0.95, k = this.g.doorAt[Math.floor(az) * this.g.W + Math.floor(ax)];
    if (k >= 0) {
      const door = this.g.doors[k];
      if (door.t < 0.85) {
        if (this.w.canOpen(door)) { if (door.target !== 1) { this.opening = true; this.w.setDoor(door, true); this.opening = false; } this.speed = 0; this._turn(Math.atan2(dx, -dz), 5, dt); return true; }
        this.path = null; this.speed = 0; return false;
      }
    }
    this._turn(Math.atan2(dx, -dz), this.state === S.CHASE ? 8 : 4.5, dt);
    const facing = Math.abs(angleDiff(this.yaw, Math.atan2(dx, -dz)));
    const sp = speed * (facing > 1.2 ? 0.25 : 1);
    const step = Math.min(d, sp * dt), nx = this.x + (dx / d) * step, nz = this.z + (dz / d) * step;
    const r = this.g.resolve(nx, nz, 0.36);
    const moved = Math.hypot(r.x - this.x, r.z - this.z);
    this.x = r.x; this.z = r.z; this.speed = moved / dt;
    this.stepAcc += moved;
    const stride = this.state === S.CHASE ? 1.5 : 1.05;
    if (this.stepAcc > stride) { this.stepAcc = 0; this.game.onMonsterStep?.(this, this.state === S.CHASE); }
    if (moved < step * 0.25 && step > 0.001) { this.stuck += dt; if (this.stuck > 1.2) { this.stuck = 0; if (this.pathEnd) this._goto(this.pathEnd[0], this.pathEnd[1]); } } else this.stuck = 0;
    return true;
  }
  _animate(dt) {
    const a = this.anim, run = this.state === S.CHASE;
    a.phase += this.speed * dt * (run ? 1.9 : 2.4);
    a.speed = this.speed;
    a.lean += ((run ? 0.55 : this.state === S.INVESTIGATE ? 0.3 : this.state === S.SEARCH ? 0.2 : 0.1) - a.lean) * Math.min(1, dt * 5);
    a.jaw += (((this.state === S.CHASE || this.state === S.ATTACK) ? 0.8 + Math.sin(this.t * 22) * 0.15 : this.state === S.INVESTIGATE ? 0.25 : 0.06) - a.jaw) * Math.min(1, dt * 8);
    if (this.state !== S.ATTACK) a.attack *= Math.max(0, 1 - dt * 6);
    if (this.state !== S.IDLE && this.state !== S.SEARCH) this.headYaw *= Math.max(0, 1 - dt * 4);
  }
  _vocals(dt, P) {
    this.vocalT -= dt;
    if (this.vocalT > 0) return;
    const g = this.game, d = this.dist;
    switch (this.state) {
      case S.IDLE: g.onMonsterVocal?.(this, 'breath'); this.vocalT = 3.5 + Math.random() * 3; break;
      case S.PATROL: case S.RETURN: g.onMonsterVocal?.(this, Math.random() < 0.5 ? 'growl' : 'click'); this.vocalT = 4 + Math.random() * 4; break;
      case S.INVESTIGATE: g.onMonsterVocal?.(this, 'sniff'); this.vocalT = 1.8 + Math.random() * 1.5; break;
      case S.SEARCH: g.onMonsterVocal?.(this, Math.random() < 0.6 ? 'click' : 'sniff'); this.vocalT = 1.4 + Math.random(); break;
      case S.CHASE: g.onMonsterVocal?.(this, 'roar'); this.vocalT = 2.6 + Math.random() * 1.6; break;
      default: this.vocalT = 1;
    }
  }
  // 0..1 how threatening the monster currently is to the player (drives heartbeat/music/static)
  threat(P) {
    if (!this.active) return 0;
    const d = this.dist;
    if (this.state === S.CHASE || this.state === S.ATTACK) return 1;
    const near = clamp(1 - d / 22, 0, 1);
    return near * (this.state === S.INVESTIGATE || this.state === S.SEARCH ? 0.75 : 0.35) * (this.g.los(this.x, this.z, P.x, P.z) ? 1 : 0.6);
  }
}
