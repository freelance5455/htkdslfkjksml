// Grid navigation for the monster: A* (8-connected, wall-proximity cost) + string-pulling path smoothing.
// Pure logic (no GL/DOM) so it is unit-testable in Node.
const SQ2 = Math.SQRT2;
const DIRS = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];   // same order as the A* neighbour table

// does the segment a->b touch the axis-aligned box? (slab test)
function segHitsBox(ax, az, bx, bz, x0, z0, x1, z1) {
  let t0 = 0, t1 = 1; const dx = bx - ax, dz = bz - az;
  for (let k = 0; k < 2; k++) {
    const p = k ? dz : dx, q = k ? az : ax, lo = k ? z0 : x0, hi = k ? z1 : x1;
    if (Math.abs(p) < 1e-9) { if (q < lo || q > hi) return false; continue; }
    let a = (lo - q) / p, b = (hi - q) / p; if (a > b) { const t = a; a = b; b = t; }
    if (a > t0) t0 = a; if (b < t1) t1 = b; if (t0 > t1) return false;
  }
  return true;
}

class Heap {
  constructor(n) { this.k = new Float32Array(n); this.v = new Int32Array(n); this.n = 0; }
  clear() { this.n = 0; }
  push(key, val) {
    let i = this.n++;
    while (i > 0) { const p = (i - 1) >> 1; if (this.k[p] <= key) break; this.k[i] = this.k[p]; this.v[i] = this.v[p]; i = p; }
    this.k[i] = key; this.v[i] = val;
  }
  pop() {
    const top = this.v[0], key = this.k[--this.n], val = this.v[this.n];
    let i = 0;
    for (;;) {
      let c = i * 2 + 1; if (c >= this.n) break;
      if (c + 1 < this.n && this.k[c + 1] < this.k[c]) c++;
      if (this.k[c] >= key) break;
      this.k[i] = this.k[c]; this.v[i] = this.v[c]; i = c;
    }
    this.k[i] = key; this.v[i] = val; return top;
  }
}

export class Nav {
  constructor(world, radius = 0.42) {
    this.w = world; this.g = world.grid; this.W = this.g.W; this.H = this.g.H; this.r = radius;
    const n = this.W * this.H;
    this.gs = new Float32Array(n); this.from = new Int32Array(n); this.stamp = new Uint32Array(n); this.closed = new Uint32Array(n); this.sid = 0;
    this.heap = new Heap(n * 4); this.maxOpen = 0;
    this.pc = new Uint8Array(n); this.eb = new Uint8Array(n); this.nc = new Float32Array(n); this.cs = new Int32Array(n); this.csStack = new Int32Array(n); this.csDoors = null; this.ver = 0; this.csVer = -1; this.rebuildProps();
  }
  // props block a cell only if a disc of the monster's radius centred on the cell would touch them
  rebuildProps() {
    this.ver++;
    const g = this.g, r = this.r - 0.03; this.pc.fill(0);
    for (const p of g.props) {
      if (!p.solid) continue;
      for (let z = Math.floor(p.z0 - r); z <= Math.floor(p.z1 + r); z++) for (let x = Math.floor(p.x0 - r); x <= Math.floor(p.x1 + r); x++) {
        if (!g.inb(x, z)) continue;
        const cx = x + 0.5, cz = z + 0.5, nx = Math.max(p.x0, Math.min(cx, p.x1)), nz = Math.max(p.z0, Math.min(cz, p.z1));
        if ((cx - nx) ** 2 + (cz - nz) ** 2 < r * r) this.pc[z * this.W + x] = 1;
      }
    }
    // thin props (cage bars, rails) can sit BETWEEN two free cell centres: block the move across them (bit i = direction DIRS[i])
    this.eb.fill(0);
    for (const p of g.props) {
      if (!p.solid) continue;
      for (let z = Math.floor(p.z0) - 2; z <= Math.floor(p.z1) + 2; z++) for (let x = Math.floor(p.x0) - 2; x <= Math.floor(p.x1) + 2; x++) {
        if (!g.inb(x, z)) continue;
        const ax = x + 0.5, az = z + 0.5;
        for (let i = 0; i < 8; i++) {
          const inf = i < 4 ? 0 : 0.25;
          if (segHitsBox(ax, az, ax + DIRS[i][0], az + DIRS[i][1], p.x0 - inf, p.z0 - inf, p.x1 + inf, p.z1 + inf)) this.eb[z * this.W + x] |= 1 << i;
        }
      }
    }
    // wall-proximity cost per cell (static: ignores doors), so A* does O(1) lookups instead of 8 walkable() calls per neighbour
    for (let z = 0; z < this.H; z++) for (let x = 0; x < this.W; x++) this.nc[z * this.W + x] = this._near(x, z);
  }
  // can the monster stand in / pass through this cell right now?
  walkable(cx, cz, ignoreDoors = false) {
    const g = this.g;
    if (!g.inb(cx, cz)) return false;
    const k = cz * this.W + cx;
    if (g.solid[k] || this.pc[k]) return false;
    const di = g.doorAt[k];
    if (di >= 0 && !ignoreDoors) { const d = g.doors[di]; if (d.t < 0.85 && !(this.w.canOpen(d))) return false; }
    return true;
  }
  // connected components of the grid as the monster can use it RIGHT NOW (doors it cannot open count as walls). Cached until a door's
  // passability or the prop set changes, so asking for an unreachable target is O(1) instead of an exhaustive A* over the whole map.
  _components() {
    const ds = this.g.doors, W = this.W, H = this.H, cs = this.cs;
    let same = this.csVer === this.ver && this.csDoors && this.csDoors.length === ds.length;
    const now = new Uint8Array(ds.length); for (let i = 0; i < ds.length; i++) { now[i] = ds[i].t >= 0.85 || this.w.canOpen(ds[i]) ? 1 : 0; if (same && now[i] !== this.csDoors[i]) same = false; }
    if (same) return cs;
    this.csDoors = now; this.csVer = this.ver; cs.fill(0); let label = 0; const st = this.csStack;
    for (let z = 0; z < H; z++) for (let x = 0; x < W; x++) {
      const k0 = z * W + x; if (cs[k0] || !this.walkable(x, z)) continue;
      label++; let sp = 0; st[sp++] = k0; cs[k0] = label;
      while (sp) {
        const cur = st[--sp], cx = cur % W, cz = (cur / W) | 0;
        for (let i = 0; i < 4; i++) {
          if (this.eb[cur] & (1 << i)) continue;
          const nx = cx + DIRS[i][0], nz = cz + DIRS[i][1]; if (!this.walkable(nx, nz)) continue;
          const ni = nz * W + nx; if (cs[ni]) continue; cs[ni] = label; st[sp++] = ni;
        }
      }
    }
    return cs;
  }
  _near(cx, cz) { // wall-proximity penalty: prefer corridor centres
    let c = 0;
    for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) if ((dx || dz) && !this.walkable(cx + dx, cz + dz, true)) c += (dx && dz) ? 0.25 : 0.7;
    return c;
  }
  nearestWalkable(x, z, maxR = 6) {
    const cx = Math.floor(x), cz = Math.floor(z);
    if (this.walkable(cx, cz, true)) return [cx, cz];
    for (let r = 1; r <= maxR; r++) {
      let best = null, bd = 1e9;
      for (let dz = -r; dz <= r; dz++) for (let dx = -r; dx <= r; dx++) {
        if (Math.max(Math.abs(dx), Math.abs(dz)) !== r) continue;
        if (!this.walkable(cx + dx, cz + dz, true)) continue;
        const d = (cx + dx + 0.5 - x) ** 2 + (cz + dz + 0.5 - z) ** 2; if (d < bd) { bd = d; best = [cx + dx, cz + dz]; }
      }
      if (best) return best;
    }
    return null;
  }
  // returns array of [x,z] waypoints (world coords) from (sx,sz) to (tx,tz), or null
  path(sx, sz, tx, tz, maxNodes = 6000) {
    const W = this.W, s = this.nearestWalkable(sx, sz), t = this.nearestWalkable(tx, tz);
    if (!s || !t) return null;
    const si = s[1] * W + s[0], ti = t[1] * W + t[0];
    if (si === ti) return [[tx, tz]];
    { const c = this._components(), a = c[si], b = c[ti]; if (b === 0 || (a !== 0 && a !== b)) return null; }   // different regions right now: no search needed
    const id = ++this.sid, gs = this.gs, from = this.from, st = this.stamp, cl = this.closed, h = this.heap;
    h.clear(); gs[si] = 0; from[si] = -1; st[si] = id; h.push(0, si);
    const tcx = t[0], tcz = t[1];
    let found = false, expanded = 0;
    const NB = [[1, 0, 1], [-1, 0, 1], [0, 1, 1], [0, -1, 1], [1, 1, SQ2], [1, -1, SQ2], [-1, 1, SQ2], [-1, -1, SQ2]];
    while (h.n > 0 && expanded < maxNodes) {
      const cur = h.pop();
      if (cl[cur] === id) continue; cl[cur] = id; expanded++;
      if (cur === ti) { found = true; break; }
      const cx = cur % W, cz = (cur / W) | 0;
      for (let i = 0; i < 8; i++) {
        const nx = cx + NB[i][0], nz = cz + NB[i][1];
        if (!this.walkable(nx, nz) || (this.eb[cur] & (1 << i))) continue;
        if (NB[i][0] && NB[i][1] && (!this.walkable(cx + NB[i][0], cz) || !this.walkable(cx, cz + NB[i][1]))) continue;
        const ni = nz * W + nx;
        if (cl[ni] === id) continue;
        const ng = gs[cur] + NB[i][2] * (1 + this.nc[nz * W + nx] * 0.5);
        if (st[ni] !== id || ng < gs[ni]) {
          gs[ni] = ng; from[ni] = cur; st[ni] = id;
          const dx = Math.abs(nx - tcx), dz = Math.abs(nz - tcz);
          h.push(ng + (dx + dz) + (SQ2 - 2) * Math.min(dx, dz), ni);
        }
      }
    }
    if (!found) return null;
    const cells = []; for (let c = ti; c !== -1; c = from[c]) cells.push(c);
    cells.reverse();
    const pts = cells.map((c) => [(c % W) + 0.5, ((c / W) | 0) + 0.5]);
    pts[0] = [sx, sz];
    const out = this.smooth(pts);
    out[out.length - 1] = [tx, tz];
    if (!this.walkable(Math.floor(tx), Math.floor(tz), true)) out[out.length - 1] = [t[0] + 0.5, t[1] + 0.5];
    return out;
  }
  // can a disc of radius r walk the straight segment? (cell test along the segment, sampled)
  clearLine(ax, az, bx, bz) {
    const d = Math.hypot(bx - ax, bz - az), n = Math.max(1, Math.ceil(d / 0.25)), r = this.r - 0.05;
    for (let i = 0; i <= n; i++) {
      const x = ax + ((bx - ax) * i) / n, z = az + ((bz - az) * i) / n;
      for (const [ox, oz] of [[0, 0], [r, 0], [-r, 0], [0, r], [0, -r]]) if (!this.walkable(Math.floor(x + ox), Math.floor(z + oz))) return false;
    }
    const x0 = Math.min(ax, bx) - r, x1 = Math.max(ax, bx) + r, z0 = Math.min(az, bz) - r, z1 = Math.max(az, bz) + r;
    for (const p of this.g.props) {
      if (!p.solid || p.x1 < x0 || p.x0 > x1 || p.z1 < z0 || p.z0 > z1) continue;
      if (segHitsBox(ax, az, bx, bz, p.x0 - r, p.z0 - r, p.x1 + r, p.z1 + r)) return false;
    }
    return true;
  }
  // string-pulling: from each kept point jump to the furthest waypoint still reachable in a straight line.
  // Galloping + bisection keeps this O(log n) clearLine() calls per kept point (the old linear scan was 80% of a path request).
  smooth(pts) {
    if (pts.length <= 2) return pts;
    const out = [pts[0]], last = pts.length - 1; let i = 0;
    const vis = (j) => this.clearLine(pts[i][0], pts[i][1], pts[j][0], pts[j][1]);
    while (i < last) {
      let good = i + 1, bad = -1, step = 2;                   // the adjacent cell is always accepted
      while (good < last) { const j = Math.min(last, i + step); if (vis(j)) { good = j; step *= 2; } else { bad = j; break; } }
      if (bad > 0) { let lo = good, hi = bad; while (hi - lo > 1) { const mid = (lo + hi) >> 1; if (vis(mid)) lo = mid; else hi = mid; } good = lo; }
      out.push(pts[good]); i = good;
    }
    return out;
  }
  pathLength(p) { let l = 0; for (let i = 1; i < p.length; i++) l += Math.hypot(p[i][0] - p[i - 1][0], p[i][1] - p[i - 1][1]); return l; }
}
