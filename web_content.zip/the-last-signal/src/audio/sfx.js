// One-shot synthesised sound effects. Every method is safe to call before audio is unlocked (it simply does nothing).
const VOWELS = [[730, 1090, 2440], [530, 1840, 2480], [270, 2290, 3010], [570, 840, 2410], [300, 870, 2240], [660, 1720, 2410]];

export class Sfx {
  constructor(E) { this.E = E; }
  get on() { return this.E.ready; }

  // ---------------- player ----------------
  step(surf = 'floor', vol = 1, crouch = false) {
    const E = this.E; if (!E.ready || !E.reserve(0.3)) return;
    const t = E.now, out = E.dry({ vol: 0.55 * vol * (crouch ? 0.5 : 1), wet: 0.6 }), f = { tile: 1000, metal: 1250, dirt: 380, floor: 640 }[surf] || 640;
    E.burst(out, 'white', 'bandpass', f, f * 0.55, 0.9, 0.09, 0.9, t);
    E.tone(out, 'sine', 100, 46, 0.11, 0.7, t);
    if (surf === 'metal') E.tone(out, 'triangle', 1750, 1500, 0.2, 0.1, t + 0.01);
    if (surf === 'tile') E.burst(out, 'white', 'highpass', 3200, 3200, 1, 0.03, 0.25, t);
  }
  breath(kind = 'out', vol = 1) {
    const E = this.E; if (!E.ready || !E.reserve(1.2)) return;
    const t = E.now, out = E.dry({ vol: 0.45 * vol });
    if (kind === 'gasp') { E.burst(out, 'pink', 'bandpass', 1100, 2200, 1.4, 0.5, 1, t, 0.03); E.tone(out, 'sawtooth', 160, 120, 0.4, 0.05, t); }
    else if (kind === 'in') E.burst(out, 'pink', 'bandpass', 700, 1400, 1.2, 0.8, 0.8, t, 0.35);
    else E.burst(out, 'pink', 'bandpass', 1000, 480, 1.1, 0.9, 0.9, t, 0.15);
  }
  heart(vol = 1) {
    const E = this.E; if (!E.ready || !E.reserve(0.5)) return;
    const t = E.now, out = E.dry({ vol: 0.9 * vol });
    E.tone(out, 'sine', 64, 36, 0.16, 0.9, t, 0.008); E.tone(out, 'sine', 56, 34, 0.16, 0.7, t + 0.19, 0.008);
  }
  hurt(heavy = true) {
    const E = this.E; if (!E.ready) return; E.reserve(0.6);
    const t = E.now, out = E.dry({ vol: 1, wet: 0.5 });
    E.tone(out, 'sine', 120, 30, 0.35, 1.2, t, 0.004);
    E.burst(out, 'white', 'lowpass', 1800, 300, 0.8, 0.3, 0.9, t);
    if (heavy) { E.tone(out, 'sawtooth', 180, 90, 0.35, 0.25, t); E.burst(out, 'pink', 'bandpass', 900, 500, 2, 0.3, 0.4, t + 0.05); }
  }
  heal() { const E = this.E; if (!E.ready) return; const t = E.now, o = E.dry({ vol: 0.5 }); E.tone(o, 'sine', 440, 660, 0.4, 0.3, t, 0.05); E.tone(o, 'sine', 660, 990, 0.5, 0.25, t + 0.15, 0.05); E.burst(o, 'white', 'highpass', 4000, 4000, 1, 0.2, 0.1, t); }
  pickup(type) {
    const E = this.E; if (!E.ready) return; E.reserve(0.5);
    const t = E.now, o = E.dry({ vol: 0.6, wet: 0.4 });
    if (type === 'note') E.burst(o, 'white', 'highpass', 2500, 5000, 0.8, 0.28, 0.35, t, 0.04);
    else if (type === 'battery') { E.tone(o, 'square', 260, 240, 0.06, 0.18, t); E.tone(o, 'triangle', 880, 880, 0.25, 0.2, t + 0.07); }
    else if (type === 'medkit') { E.burst(o, 'white', 'bandpass', 1500, 900, 1.5, 0.15, 0.4, t); E.tone(o, 'triangle', 520, 520, 0.2, 0.15, t + 0.08); }
    else { E.tone(o, 'triangle', 1318, 1318, 0.5, 0.22, t, 0.002); E.tone(o, 'triangle', 1976, 1976, 0.7, 0.14, t + 0.06, 0.002); }
  }
  flash(on) {
    const E = this.E; if (!E.ready) return; const t = E.now, o = E.dry({ vol: 0.5 });
    E.burst(o, 'white', 'bandpass', on ? 2600 : 1800, 1200, 3, 0.03, 0.7, t); E.tone(o, 'square', on ? 900 : 620, 300, 0.04, 0.1, t);
  }
  flashDead() { const E = this.E; if (!E.ready) return; const t = E.now, o = E.dry({ vol: 0.4 }); E.tone(o, 'sawtooth', 180, 40, 0.5, 0.3, t); E.burst(o, 'white', 'bandpass', 900, 200, 1, 0.4, 0.2, t); }
  reload() { const E = this.E; if (!E.ready) return; const t = E.now, o = E.dry({ vol: 0.55, wet: 0.3 }); for (const d of [0, 0.35, 0.8, 1.25]) { E.burst(o, 'white', 'bandpass', 1500 + d * 400, 800, 4, 0.05, 0.7, t + d); E.tone(o, 'square', 300 - d * 80, 120, 0.05, 0.12, t + d); } }
  ui(kind = 'tap') { const E = this.E; if (!E.ready) return; const t = E.now, o = E.dry({ vol: 0.35, bus: E.sfx }); if (kind === 'open') { E.tone(o, 'sine', 300, 500, 0.12, 0.2, t); } else if (kind === 'back') E.tone(o, 'sine', 420, 260, 0.1, 0.2, t); else { E.tone(o, 'triangle', 700, 640, 0.06, 0.2, t); E.burst(o, 'white', 'highpass', 5000, 5000, 1, 0.02, 0.15, t); } }
  key(i = 0) { const E = this.E; if (!E.ready) return; const t = E.now, o = E.dry({ vol: 0.4 }); E.tone(o, 'square', 1300 + i * 40, 1300 + i * 40, 0.07, 0.14, t); E.tone(o, 'sine', 2600, 2600, 0.05, 0.05, t); }
  keyOk() { const E = this.E; if (!E.ready) return; const t = E.now, o = E.dry({ vol: 0.5 }); [1000, 1330, 1760].forEach((f, i) => E.tone(o, 'square', f, f, 0.13, 0.13, t + i * 0.09)); }
  keyBad() { const E = this.E; if (!E.ready) return; const t = E.now, o = E.dry({ vol: 0.5 }); E.tone(o, 'square', 190, 170, 0.35, 0.22, t); E.tone(o, 'square', 140, 130, 0.3, 0.2, t + 0.1); }
  switchClick(x, z) { const E = this.E; if (!E.ready) return; E.reserve(0.2); const s = x === undefined ? E.dry({ vol: 0.5 }) : E.spatial(x, z, { vol: 0.7, ref: 6 }).in, t = E.now; E.tone(s, 'square', 240, 90, 0.05, 0.3, t); E.burst(s, 'white', 'bandpass', 3000, 1500, 3, 0.04, 0.5, t); E.tone(s, 'triangle', 1400, 700, 0.09, 0.1, t + 0.04); }
  spark(x, z) { const E = this.E; if (!E.ready) return; E.reserve(0.7); const s = E.spatial(x, z, { vol: 1.1, ref: 7 }).in, t = E.now; E.burst(s, 'white', 'highpass', 2500, 7000, 0.8, 0.5, 0.9, t, 0.002); for (let i = 0; i < 5; i++) E.burst(s, 'white', 'bandpass', 4000, 2500, 3, 0.03, 0.8, t + Math.random() * 0.4); E.tone(s, 'sawtooth', 220, 60, 0.4, 0.3, t); }
  surge(x, z, vol = 1) {
    const E = this.E; if (!E.ready) return; E.reserve(2.5, 2);
    const s = x === undefined ? E.dry({ vol, wet: 0.8 }) : E.spatial(x, z, { vol: vol * 1.2, ref: 18, wet: 0.8 }).in, t = E.now;
    E.tone(s, 'sawtooth', 60, 900, 1.4, 0.5, t, 0.9); E.tone(s, 'square', 120, 1800, 1.3, 0.2, t, 0.9);
    E.tone(s, 'sine', 90, 24, 1.6, 1.1, t + 1.3, 0.01); E.burst(s, 'white', 'lowpass', 4000, 150, 0.6, 1.4, 0.9, t + 1.3, 0.01);
  }
  generator(x, z) { const E = this.E; if (!E.ready) return; E.reserve(3.2, 2); const s = E.spatial(x, z, { vol: 1.2, ref: 22, wet: 0.7 }).in, t = E.now; for (let i = 0; i < 7; i++) { E.tone(s, 'sawtooth', 50 + i * 4, 28 + i * 3, 0.17, 0.5, t + i * (0.34 - i * 0.03)); E.burst(s, 'brown', 'lowpass', 500, 120, 0.7, 0.16, 0.7, t + i * (0.34 - i * 0.03)); } E.tone(s, 'sawtooth', 45, 62, 1.4, 0.6, t + 2.1, 0.3); }
  zap(x, z) { this.spark(x, z); }
  stamp(x, z, vol = 1) { const E = this.E; if (!E.ready) return; E.reserve(1); const s = E.spatial(x, z, { vol, ref: 9, wet: 0.8 }).in, t = E.now; E.tone(s, 'sine', 80, 26, 0.5, 1.1, t, 0.003); E.burst(s, 'brown', 'lowpass', 700, 160, 0.7, 0.45, 0.9, t); E.burst(s, 'white', 'bandpass', 1800, 900, 2, 0.2, 0.4, t); }
  knock(x, z, n = 3, gap = 0.28) { const E = this.E; if (!E.ready) return; E.reserve(2); const s = E.spatial(x, z, { vol: 1, ref: 10, wet: 0.9 }).in, t = E.now; for (let i = 0; i < n; i++) { E.tone(s, 'sine', 130, 60, 0.18, 1, t + i * gap, 0.002); E.burst(s, 'white', 'bandpass', 700, 300, 1.2, 0.1, 0.8, t + i * gap); } }
  fall(x, z) { const E = this.E; if (!E.ready) return; E.reserve(1.4, 2); const s = E.spatial(x, z, { vol: 1, ref: 10, wet: 1 }).in, t = E.now; for (let i = 0; i < 6; i++) { E.tone(s, 'triangle', 1800 - i * 200 + Math.random() * 300, 1200, 0.25, 0.22, t + i * 0.08 * (1 + i * 0.3)); E.burst(s, 'white', 'bandpass', 2500, 1500, 5, 0.04, 0.5, t + i * 0.08 * (1 + i * 0.3)); } E.tone(s, 'sine', 90, 35, 0.4, 0.8, t, 0.002); }

  // ---------------- doors ----------------
  door(x, z, kind, big = 'metal') {
    const E = this.E; if (!E.ready) return; E.reserve(2.4, 2);
    const heavy = big === 'blast', shut = big === 'shutter', s = E.spatial(x, z, { vol: heavy ? 1.5 : 1, ref: heavy ? 14 : 8, wet: 0.7 }).in, t = E.now, L = heavy ? 2.1 : shut ? 1.2 : 0.8;
    if (kind === 'open' || kind === 'close') {
      const up = kind === 'open';
      E.tone(s, 'sawtooth', (heavy ? 45 : 95) * (up ? 1 : 1.4), (heavy ? 70 : 150) * (up ? 1.4 : 1), L, 0.11, t, 0.1);
      E.burst(s, 'pink', 'bandpass', up ? 450 : 900, up ? 1000 : 400, 0.9, L, 0.3, t, 0.08);
      E.tone(s, 'square', 170, 55, 0.1, 0.4, t, 0.003); E.burst(s, 'white', 'bandpass', 1500, 600, 3, 0.07, 0.6, t);
      E.tone(s, 'sine', 100, 40, 0.22, 0.8, t + L, 0.004); E.burst(s, 'white', 'bandpass', 1900, 800, 2.5, 0.1, 0.55, t + L);
    } else if (kind === 'slam') {
      E.tone(s, 'sine', 75, 22, 1.1, 1.4, t, 0.003); E.burst(s, 'brown', 'lowpass', 600, 90, 0.7, 1, 1, t); E.burst(s, 'white', 'bandpass', 1700, 700, 1.5, 0.35, 0.9, t);
      E.tone(s, 'triangle', 330, 290, 1.8, 0.25, t + 0.02, 0.003); E.tone(s, 'triangle', 530, 470, 1.4, 0.15, t + 0.02, 0.003);
    } else if (kind === 'unlock') { E.tone(s, 'square', 880, 880, 0.08, 0.2, t); E.tone(s, 'square', 1320, 1320, 0.12, 0.2, t + 0.1); E.burst(s, 'white', 'bandpass', 2000, 1200, 4, 0.06, 0.5, t + 0.2); }
    else if (kind === 'locked') { E.tone(s, 'square', 150, 140, 0.22, 0.25, t); E.tone(s, 'square', 110, 100, 0.18, 0.25, t + 0.12); E.burst(s, 'white', 'bandpass', 1200, 700, 3, 0.05, 0.5, t); }
  }
  hideDoor(x, z, open = true) { const E = this.E; if (!E.ready) return; E.reserve(0.7); const s = E.spatial(x, z, { vol: 0.9, ref: 6, wet: 0.5 }).in, t = E.now; E.burst(s, 'pink', 'bandpass', open ? 500 : 900, open ? 1500 : 500, 3, 0.38, 0.4, t, 0.1); E.tone(s, 'square', open ? 190 : 140, 70, 0.08, 0.3, t + (open ? 0 : 0.3)); E.tone(s, 'sine', 120, 50, 0.14, 0.5, t + (open ? 0.35 : 0.34)); }
  wheel(x, z) { const E = this.E; if (!E.ready) return; E.reserve(0.5); const s = E.spatial(x, z, { vol: 1, ref: 10, wet: 0.8 }).in, t = E.now; E.tone(s, 'sawtooth', 300 + Math.random() * 60, 240, 0.4, 0.14, t, 0.05); E.burst(s, 'white', 'bandpass', 1100, 600, 5, 0.3, 0.3, t); E.tone(s, 'sine', 70, 40, 0.2, 0.4, t + 0.1); }

  // ---------------- monster ----------------
  mstep(x, z, run) {
    const E = this.E; if (!E.ready || !E.reserve(0.5)) return;
    const s = E.spatial(x, z, { vol: run ? 1.5 : 1.15, ref: 7, wet: 0.7 }).in, t = E.now;
    E.tone(s, 'sine', 72, 28, 0.24, 1, t, 0.004); E.burst(s, 'brown', 'lowpass', 460, 180, 0.7, 0.17, 0.9, t); E.burst(s, 'white', 'bandpass', 2300, 1700, 6, 0.04, 0.3, t + 0.02);
  }
  growlRaw(out, f0, dur, vol, rough, t) {
    const E = this.E, o = E.osc('sawtooth', f0, t), o2 = E.osc('square', f0 * 0.5, t), lfo = E.osc('sine', 6 + rough * 6, t), lg = E.gain(f0 * 0.05 * rough);
    lfo.connect(lg); lg.connect(o.frequency); lg.connect(o2.frequency);
    o.frequency.linearRampToValueAtTime(f0 * 0.72, t + dur); o2.frequency.linearRampToValueAtTime(f0 * 0.36, t + dur);
    const mix = E.gain(0.0001), f1 = E.filt('bandpass', 420, 4), f2 = E.filt('bandpass', 1150, 5), g1 = E.gain(1), g2 = E.gain(0.55), ws = E.shaper();
    o.connect(f1); o.connect(f2); o2.connect(f1); f1.connect(g1); f2.connect(g2); g1.connect(ws); g2.connect(ws); ws.connect(mix); mix.connect(out);
    const ns = E.src('pink', false), nf = E.filt('bandpass', 800, 1.2), ng = E.gain(0.5 * rough); ns.connect(nf); nf.connect(ng); ng.connect(mix);
    E.env(mix, t, dur * 0.25, dur * 0.7, vol);
    for (const n of [o, o2, lfo, ns]) { n.start(t); n.stop(t + dur + 0.1); }
  }
  mvocal(x, z, kind) {
    const E = this.E; if (!E.ready) return; if (!E.reserve(2.2)) return;
    const s = E.spatial(x, z, { vol: kind === 'roar' ? 1.6 : 1, ref: kind === 'roar' ? 16 : 8, wet: 0.8 }).in, t = E.now;
    if (kind === 'breath') E.burst(s, 'pink', 'bandpass', 420, 260, 1.5, 1.5, 0.55, t, 0.5);
    else if (kind === 'growl') this.growlRaw(s, 78 + Math.random() * 20, 1.4, 0.55, 0.6, t);
    else if (kind === 'roar') { this.growlRaw(s, 120, 1.7, 1, 1.4, t); E.tone(s, 'sawtooth', 520, 210, 1.3, 0.22, t + 0.1, 0.2); E.burst(s, 'white', 'bandpass', 1800, 900, 1.2, 1.4, 0.35, t, 0.1); }
    else if (kind === 'sniff') { for (let i = 0; i < 3; i++) E.burst(s, 'white', 'bandpass', 2200 + i * 200, 1500, 2, 0.1, 0.4, t + i * 0.17, 0.02); }
    else if (kind === 'click') { for (let i = 0; i < 3; i++) { E.tone(s, 'sine', 2300 - i * 200, 1400, 0.03, 0.4, t + i * 0.12 + (i > 1 ? 0.15 : 0)); E.burst(s, 'white', 'bandpass', 3000, 2000, 6, 0.02, 0.3, t + i * 0.12); } }
    else if (kind === 'screech') { E.tone(s, 'sawtooth', 900, 2400, 0.9, 0.35, t, 0.05); E.tone(s, 'square', 1400, 3100, 0.8, 0.15, t, 0.05); }
  }
  jumpscare() {
    const E = this.E; if (!E.ready) return; E.reserve(2.5, 3);
    const o = E.dry({ vol: 1.2, wet: 0.5 }), t = E.now;
    E.burst(o, 'white', 'lowpass', 9000, 600, 0.6, 1.2, 1, t, 0.004);
    E.tone(o, 'sawtooth', 240, 1000, 0.9, 0.55, t, 0.01); E.tone(o, 'square', 330, 1650, 0.9, 0.3, t, 0.01);
    E.tone(o, 'sine', 80, 22, 1.4, 1.3, t, 0.004); this.growlRaw(o, 140, 1.2, 0.9, 1.6, t);
  }

  // ---------------- voices (formant synth: speech-like babble; the words appear as subtitles) ----------------
  voice(text, o = {}) {
    const E = this.E; if (!E.ready) return 0;
    const n = Math.max(3, Math.round(text.length / 2.4)), sylDur = 0.115 / (o.speed || 1), f0 = o.pitch || 118, t0 = E.now + 0.03;
    const total = n * sylDur * 1.25 + 0.2; if (!E.reserve(total + 0.5, 2)) return total;
    const out = o.x === undefined ? E.dry({ vol: o.vol ?? 0.8, bus: E.voice, wet: o.wet ?? 0.4 }) : E.spatial(o.x, o.z, { vol: o.vol ?? 1, bus: E.voice, ref: o.ref || 9, wet: 0.9 }).in;
    let chain = out;
    if (o.radio) { const hp = E.filt('highpass', 380, 0.8), lp = E.filt('lowpass', 3200, 0.9), ws = E.shaper(), g = E.gain(0.55); hp.connect(lp); lp.connect(ws); ws.connect(g); g.connect(out); chain = hp; }
    const car = E.osc('sawtooth', f0, t0), vib = E.osc('sine', 5.5, t0), vg = E.gain(f0 * 0.012); vib.connect(vg); vg.connect(car.frequency);
    const amp = E.gain(0.0001), fa = [E.filt('bandpass', 700, 9), E.filt('bandpass', 1200, 11), E.filt('bandpass', 2500, 12)], fg = [1, 0.55, 0.3];
    fa.forEach((f, i) => { const g = E.gain(fg[i]); car.connect(f); f.connect(g); g.connect(amp); });
    amp.connect(chain);
    const br = E.src('pink', false), bf = E.filt('bandpass', 3200, 1.5), bg = E.gain(0.0001); br.connect(bf); bf.connect(bg); bg.connect(amp);
    let t = t0, rnd = (o.seed || 7) * 9301 + 49297;
    const r = () => { rnd = (rnd * 9301 + 49297) % 233280; return rnd / 233280; };
    amp.gain.setValueAtTime(0.0001, t0);
    for (let i = 0; i < n; i++) {
      const v = VOWELS[(r() * VOWELS.length) | 0], d = sylDur * (0.8 + r() * 0.5), pitch = f0 * (1 + (r() - 0.5) * (o.mimic ? 0.5 : 0.22) + (i % 7 === 6 ? 0.12 : 0));
      fa.forEach((f, k) => f.frequency.linearRampToValueAtTime(v[k] * (o.formant || 1), t + 0.03));
      car.frequency.linearRampToValueAtTime(pitch, t + d);
      amp.gain.linearRampToValueAtTime(0.9, t + 0.025); amp.gain.setValueAtTime(0.9, t + d * 0.65); amp.gain.linearRampToValueAtTime(0.0001, t + d);
      bg.gain.setValueAtTime(0.35, t); bg.gain.linearRampToValueAtTime(0.0001, t + 0.04);
      t += d + (i % 4 === 3 ? sylDur * 0.9 : 0.01);
    }
    for (const x of [car, vib, br]) { x.start(t0); x.stop(t + 0.1); }
    if (o.mimic) { const car2 = E.osc('sawtooth', f0 * 1.5, t0), g2 = E.gain(0.35); car2.connect(g2); g2.connect(fa[0]); g2.connect(fa[1]); car2.start(t0); car2.stop(t + 0.1); car2.detune.value = 40; }
    return t - t0;
  }
  whisper(x, z, vol = 1) {
    const E = this.E; if (!E.ready || !E.reserve(2.4)) return;
    const s = E.spatial(x, z, { vol: 0.9 * vol, ref: 5, wet: 1, bus: E.voice }).in, t = E.now;
    for (let i = 0; i < 6; i++) { const f = 2400 + Math.random() * 2400; E.burst(s, 'white', 'bandpass', f, f * (0.6 + Math.random() * 0.5), 5, 0.22 + Math.random() * 0.2, 0.5, t + i * 0.28 + Math.random() * 0.1, 0.06); }
    E.burst(s, 'pink', 'bandpass', 900, 700, 2, 1.8, 0.2, t, 0.5);
  }
  drip(x, z) { const E = this.E; if (!E.ready || !E.reserve(0.6)) return; const s = E.spatial(x, z, { vol: 0.55, ref: 4, wet: 1 }).in, t = E.now, f = 1100 + Math.random() * 700; E.tone(s, 'sine', f, f * 0.55, 0.12, 0.5, t, 0.002); E.tone(s, 'sine', f * 1.6, f, 0.08, 0.15, t, 0.002); }
  alert(vol = 1) { const E = this.E; if (!E.ready) return; E.reserve(1.2); const o = E.dry({ vol: 0.55 * vol, wet: 0.5 }), t = E.now; E.tone(o, 'sawtooth', 80, 110, 1, 0.3, t, 0.4); E.tone(o, 'sine', 55, 40, 1.1, 0.6, t, 0.2); }
  stinger(vol = 1) { const E = this.E; if (!E.ready) return; E.reserve(2.4, 2); const o = E.dry({ vol: 0.7 * vol, bus: E.music, wet: 0.8 }), t = E.now; [233, 246.9, 330].forEach((f) => E.tone(o, 'sawtooth', f, f * 0.985, 2, 0.12, t, 0.08)); E.tone(o, 'sine', 55, 36, 2, 0.6, t, 0.02); E.burst(o, 'white', 'bandpass', 3500, 900, 1, 0.6, 0.2, t, 0.02); }
  chime(vol = 1) { const E = this.E; if (!E.ready) return; const o = E.dry({ vol: 0.45 * vol, bus: E.music, wet: 1 }), t = E.now; [523, 659, 784, 1046].forEach((f, i) => E.tone(o, 'sine', f, f, 2.2, 0.2, t + i * 0.22, 0.02)); }
}
