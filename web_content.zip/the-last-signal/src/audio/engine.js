// Procedural WebAudio engine: buses, shared noise buffers, convolution reverb, positional (pan / distance / wall-occlusion) helper.
// No audio files and no microphone: every sound in the game is synthesised here and in sfx.js.
const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

export class AudioEngine {
  constructor() {
    this.ctx = null; this.ready = false; this.failed = false;
    this.vol = { master: 0.9, music: 0.7, sfx: 1, mute: false };
    this.L = { x: 0, z: 0, yaw: 0 };       // listener
    this.occlude = null;                   // (x,z)=>true when walls separate the listener from the point
    this.reverb = 0.3; this.active = 0; this.stats = { played: 0, skipped: 0 };
  }
  init() {
    if (this.ctx) return true;
    if (this.failed) return false;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) { this.failed = true; return false; }
    let c;
    try { c = new AC({ latencyHint: 'interactive' }); } catch { try { c = new AC(); } catch { this.failed = true; return false; } }
    this.ctx = c;
    const g = (v = 1) => { const n = c.createGain(); n.gain.value = v; return n; };
    this.master = g(0.9); this.comp = c.createDynamicsCompressor();
    this.comp.threshold.value = -16; this.comp.knee.value = 20; this.comp.ratio.value = 6; this.comp.attack.value = 0.004; this.comp.release.value = 0.22;
    // output stage: compressor -> soft-knee limiter. The compressor's 4 ms attack lets a door slam / jumpscare transient through
    // above full scale; the limiter bends everything above ~0.62 smoothly and hard-ceilings at ~0.91 so the phone speaker never hard-clips.
    this.lim = c.createWaveShaper(); this.lim.curve = this._limiterCurve(0.62); this.lim.oversample = 'none';
    this.master.connect(this.comp); this.comp.connect(this.lim); this.lim.connect(c.destination);
    this.sfx = g(1); this.music = g(0.6); this.amb = g(0.8); this.voice = g(1);
    for (const b of [this.sfx, this.music, this.amb, this.voice]) b.connect(this.master);
    this.conv = c.createConvolver(); this.conv.buffer = this._ir(2.6);
    this.send = g(1); this.ret = g(0.8); this.send.connect(this.conv); this.conv.connect(this.ret); this.ret.connect(this.master);
    this.buf = { white: this._noise('white'), pink: this._noise('pink'), brown: this._noise('brown') };
    this.curve = this._curve(40);
    this.applyVolumes(); this.ready = true;
    return true;
  }
  resume() { if (this.ctx && this.ctx.state !== 'running') { try { this.ctx.resume(); } catch { /* ignore */ } } }
  get now() { return this.ctx.currentTime; }
  applyVolumes() {
    if (!this.ctx) return;
    const v = this.vol, t = this.now;
    this.master.gain.setTargetAtTime(v.mute ? 0 : v.master, t, 0.03);
    this.sfx.gain.setTargetAtTime(v.sfx, t, 0.03); this.amb.gain.setTargetAtTime(v.sfx * 0.8, t, 0.03); this.voice.gain.setTargetAtTime(v.sfx, t, 0.03);
    this.music.gain.setTargetAtTime(v.music * 0.65, t, 0.03);
  }
  setListener(x, z, yaw) { this.L.x = x; this.L.z = z; this.L.yaw = yaw; }
  setReverb(r) { this.reverb = r; if (this.ctx) this.send.gain.setTargetAtTime(0.25 + r * 0.9, this.now, 0.4); }

  _ir(sec) {
    const c = this.ctx, n = (c.sampleRate * sec) | 0, b = c.createBuffer(2, n, c.sampleRate);
    for (let ch = 0; ch < 2; ch++) {
      const d = b.getChannelData(ch); let lp = 0;
      for (let i = 0; i < n; i++) { const t = i / n; lp += (((Math.random() * 2 - 1) - lp) * (0.55 - 0.4 * t)); d[i] = lp * Math.pow(1 - t, 2.6) * (i < 400 ? i / 400 : 1); }
    }
    return b;
  }
  _noise(kind) {
    const c = this.ctx, n = (c.sampleRate * 2) | 0, b = c.createBuffer(1, n, c.sampleRate), d = b.getChannelData(0);
    if (kind === 'white') for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
    else if (kind === 'pink') { let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0; for (let i = 0; i < n; i++) { const w = Math.random() * 2 - 1; b0 = 0.99886 * b0 + w * 0.0555179; b1 = 0.99332 * b1 + w * 0.0750759; b2 = 0.969 * b2 + w * 0.153852; b3 = 0.8665 * b3 + w * 0.3104856; b4 = 0.55 * b4 + w * 0.5329522; b5 = -0.7616 * b5 - w * 0.016898; d[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + w * 0.5362) * 0.11; b6 = w * 0.115926; } }
    else { let l = 0; for (let i = 0; i < n; i++) { l = (l + 0.02 * (Math.random() * 2 - 1)) / 1.02; d[i] = l * 3.5; } }
    // crossfade the tail into the head so a loop over [0, n-f) is click-free
    const f = 2048; for (let i = 0; i < f; i++) { const a = i / f; d[i] = d[i] * a + d[n - f + i] * (1 - a); }
    this.loopEnd = (n - f) / c.sampleRate;
    return b;
  }
  // transfer curve for the output limiter: identity below `knee`, tanh shoulder above it (inputs beyond +-1 clamp to the last point)
  _limiterCurve(knee) {
    const n = 2049, c = new Float32Array(n), r = 1 - knee;
    for (let i = 0; i < n; i++) { const x = (i * 2) / (n - 1) - 1, a = Math.abs(x); c[i] = a <= knee ? x : Math.sign(x) * (knee + r * Math.tanh((a - knee) / r)); }
    return c;
  }
  _curve(k) { const n = 512, c = new Float32Array(n); for (let i = 0; i < n; i++) { const x = (i * 2) / n - 1; c[i] = ((3 + k) * x * 20 * (Math.PI / 180)) / (Math.PI + k * Math.abs(x)); } return c; }

  // ------- building blocks -------
  src(kind = 'white', loop = false, rate = 1) {
    const s = this.ctx.createBufferSource(); s.buffer = this.buf[kind]; s.loop = loop; s.playbackRate.value = rate;
    if (loop) { s.loopStart = 0; s.loopEnd = this.loopEnd; }
    return s;
  }
  osc(type, f, t = this.now) { const o = this.ctx.createOscillator(); o.type = type; o.frequency.setValueAtTime(f, t); return o; }
  gain(v = 1) { const g = this.ctx.createGain(); g.gain.value = v; return g; }
  filt(type, f, q = 1) { const n = this.ctx.createBiquadFilter(); n.type = type; n.frequency.value = f; n.Q.value = q; return n; }
  shaper() { const w = this.ctx.createWaveShaper(); w.curve = this.curve; w.oversample = 'none'; return w; }
  // admission control so a burst of sounds can never exhaust a phone's audio thread
  reserve(sec, weight = 1) {
    if (!this.ready || this.ctx.state !== 'running') return false;
    if (this.active > 44) { this.stats.skipped++; return false; }
    this.active += weight; this.stats.played++;
    setTimeout(() => { this.active -= weight; }, sec * 1000 + 80);
    return true;
  }
  // amplitude envelope on a gain node
  env(g, t, a, d, peak = 1, sustain = 0, rel = 0) {
    const p = g.gain; p.cancelScheduledValues(t); p.setValueAtTime(0.0001, t); p.linearRampToValueAtTime(peak, t + a);
    if (sustain > 0) { p.setValueAtTime(peak, t + a + sustain); }
    p.exponentialRampToValueAtTime(0.0001, t + a + sustain + d + rel);
    return t + a + sustain + d + rel;
  }
  // positional chain: returns the input node. bus = this.sfx | this.voice | this.amb
  spatial(x, z, o = {}) {
    const c = this.ctx, L = this.L, dx = x - L.x, dz = z - L.z, d = Math.hypot(dx, dz) || 0.001, bus = o.bus || this.sfx;
    const rx = Math.cos(L.yaw), rz = Math.sin(L.yaw), side = (dx * rx + dz * rz) / Math.max(d, 0.5);
    const ref = o.ref || 5, att = 1 / (1 + Math.pow(d / ref, 1.7)), occ = d > 2.2 && this.occlude ? this.occlude(x, z) : false;
    const g = c.createGain(); g.gain.value = (o.vol ?? 1) * att * (occ ? 0.5 : 1);
    const lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = occ ? 520 : clamp(16000 - d * 420, 1800, 16000);
    g.connect(lp);
    let tail = lp;
    if (c.createStereoPanner) { const p = c.createStereoPanner(); p.pan.value = clamp(side * Math.min(1, d / 1.4) * 0.9, -0.95, 0.95); lp.connect(p); tail = p; }
    tail.connect(bus);
    const w = c.createGain(); w.gain.value = this.reverb * (o.wet ?? 0.45) * (occ ? 1.1 : 0.8) * Math.min(1, 0.3 + d / 12); tail.connect(w); w.connect(this.send);
    return { in: g, d, occ };
  }
  // non-positional output (player's own sounds, UI): returns an input node on the bus
  dry(o = {}) {
    const g = this.ctx.createGain(); g.gain.value = o.vol ?? 1; g.connect(o.bus || this.sfx);
    if (o.wet) { const w = this.ctx.createGain(); w.gain.value = this.reverb * o.wet; g.connect(w); w.connect(this.send); }
    return g;
  }
  // convenience one-shot tone: frequency sweep f0 -> f1 over dur with an attack/decay envelope
  tone(out, type, f0, f1, dur, vol = 0.3, t = this.now, a = 0.005) {
    const o = this.osc(type, f0, t), g = this.gain(0.0001);
    o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    o.connect(g); g.connect(out);
    this.env(g, t, a, dur - a, vol); o.start(t); o.stop(t + dur + 0.05);
    return o;
  }
  // convenience one-shot filtered noise burst
  burst(out, kind, ftype, f0, f1, q, dur, vol = 0.3, t = this.now, a = 0.004) {
    const s = this.src(kind, false, 0.8 + Math.random() * 0.4), f = this.filt(ftype, f0, q), g = this.gain(0.0001);
    if (f1 && f1 !== f0) f.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    s.connect(f); f.connect(g); g.connect(out);
    this.env(g, t, a, dur - a, vol); s.start(t, Math.random() * 1.2); s.stop(t + dur + 0.05);
    return s;
  }
}
