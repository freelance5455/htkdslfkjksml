// Continuous layers: ambience (drone / wind / electrical hum / drips), generator rumble, alarm, radio static and the chase score.
// All layers run permanently at gain ~0 once built and are steered every frame by update() (cheap, glitch-free on phones).
export class Scape {
  constructor(E) { this.E = E; this.built = false; this.k = {}; this.beat = 0.3; this.step = 0; this.dripT = 4; this.hum = 0; this.cr = 0; }
  build() {
    const E = this.E; if (!E.ready || this.built) return; this.built = true;
    const t = E.now, k = this.k, g = (v = 0) => E.gain(v);
    // low drone: three detuned oscillators through a slowly moving low-pass
    k.drone = g(0); k.drone.connect(E.amb);
    const dl = E.filt('lowpass', 150, 0.7); dl.connect(k.drone);
    [['sine', 41.2, 0.6], ['sawtooth', 55, 0.35], ['sawtooth', 55.4, 0.35], ['sawtooth', 82.6, 0.18]].forEach(([ty, f, v]) => { const o = E.osc(ty, f, t), x = g(v); o.connect(x); x.connect(dl); o.start(t); });
    const dlfo = E.osc('sine', 0.06, t), dlg = g(70); dlfo.connect(dlg); dlg.connect(dl.frequency); dlfo.start(t); k.dl = dl;
    // wind (outdoors)
    k.wind = g(0); k.wind.connect(E.amb);
    const ws = E.src('pink', true), wf = E.filt('bandpass', 520, 0.7), wl = E.osc('sine', 0.11, t), wlg = g(260); ws.connect(wf); wf.connect(k.wind); wl.connect(wlg); wlg.connect(wf.frequency); ws.start(t); wl.start(t);
    // electrical hum of powered rooms
    k.hum = g(0); k.hum.connect(E.amb);
    [[100, 'sine', 1], [200, 'sawtooth', 0.12], [300, 'sine', 0.18]].forEach(([f, ty, v]) => { const o = E.osc(ty, f, t), x = g(v), lp = E.filt('lowpass', 700, 0.6); o.connect(x); x.connect(lp); lp.connect(k.hum); o.start(t); });
    // generator (positional rumble)
    k.gen = g(0); const glp = E.filt('lowpass', 260, 0.8); glp.connect(k.gen); k.genLp = glp;
    k.genPan = E.ctx.createStereoPanner ? E.ctx.createStereoPanner() : null;
    if (k.genPan) { k.gen.connect(k.genPan); k.genPan.connect(E.amb); } else k.gen.connect(E.amb);
    const gb = E.src('brown', true), gs = E.osc('sawtooth', 41, t), gs2 = E.osc('square', 20.5, t), gam = E.osc('sine', 11, t), gag = g(0.25), gm = g(0.5);
    gb.connect(glp); gs.connect(gm); gs2.connect(gm); gam.connect(gag); gag.connect(gm.gain); gm.connect(glp); gb.start(t); gs.start(t); gs2.start(t); gam.start(t);
    // tension pad (beating minor second)
    k.pad = g(0); k.pad.connect(E.music);
    [[110, 'sine'], [116.5, 'sine'], [220.6, 'triangle']].forEach(([f, ty], i) => { const o = E.osc(ty, f, t), x = g(i === 2 ? 0.2 : 0.6); o.connect(x); x.connect(k.pad); o.start(t); });
    // chase score: pulsing sub, dissonant cluster, shrieking top
    k.pulse = g(0); k.pulse.connect(E.music);
    const po = E.osc('sine', 55, t), pm = g(0.5), pl = E.osc('sine', 2.2, t), plg = g(0.5); po.connect(pm); pl.connect(plg); plg.connect(pm.gain); pm.connect(k.pulse); po.start(t); pl.start(t);
    k.cl = g(0); const cf = E.filt('lowpass', 500, 0.8); cf.connect(k.cl); k.cl.connect(E.music); k.cf = cf;
    [233.1, 246.9, 311.1, 349.2].forEach((f) => { const o = E.osc('sawtooth', f, t), x = g(0.18); o.connect(x); x.connect(cf); o.start(t); o.detune.value = (Math.random() - 0.5) * 30; });
    k.shr = g(0); k.shr.connect(E.music);
    const so = E.osc('sine', 1330, t), sv = E.osc('sine', 5.2, t), svg = g(26), so2 = E.osc('sine', 1397, t); sv.connect(svg); svg.connect(so.frequency); svg.connect(so2.frequency); so.connect(k.shr); so2.connect(k.shr); so.start(t); so2.start(t); sv.start(t);
    // alarm siren
    k.alarm = g(0); const al = E.filt('lowpass', 1800, 0.7); al.connect(k.alarm); k.alarm.connect(E.amb);
    const ao = E.osc('square', 700, t), ao2 = E.osc('sawtooth', 705, t), alf = E.osc('triangle', 0.9, t), alg = g(260); alf.connect(alg); alg.connect(ao.frequency); alg.connect(ao2.frequency);
    const am = g(0.3); ao.connect(am); ao2.connect(am); am.connect(al); ao.start(t); ao2.start(t); alf.start(t);
    // radio: static bed + tone
    k.rad = g(0); k.rad.connect(E.voice);
    const rs = E.src('white', true), rf = E.filt('bandpass', 1900, 0.5), rh = E.filt('highpass', 400, 0.7); rs.connect(rf); rf.connect(rh); rh.connect(k.rad); rs.start(t); k.rf = rf;
    k.carrier = g(0); k.carrier.connect(E.voice); const co = E.osc('sine', 440, t), co2 = E.osc('sine', 443, t); co.connect(k.carrier); co2.connect(k.carrier); co.start(t); co2.start(t);
  }
  _to(p, v, tau = 0.25) { p.setTargetAtTime(v, this.E.now, tau); }
  // s: { outdoor, power, threat, chase, genOn, genX, genZ, alarm, radio:{on, stat, car}, reverb }
  update(dt, s) {
    const E = this.E; if (!E.ready || !this.built) return;
    const k = this.k, th = s.threat || 0, ch = s.chase || 0;
    this._to(k.drone.gain, 0.2 + 0.1 * th + (s.outdoor ? -0.08 : 0), 0.8); this._to(k.dl.frequency, 150 + 240 * th, 1);
    this._to(k.wind.gain, s.outdoor ? 0.34 : 0.035, 0.8);
    this._to(k.hum.gain, s.outdoor ? 0 : 0.045 * (s.power ?? 0), 0.6);
    this._to(k.pad.gain, th * 0.16 * (1 - ch * 0.5), 0.6);
    this._to(k.pulse.gain, ch * 0.5, 0.35); this._to(k.cl.gain, ch * 0.22 + th * 0.03, 0.4); this._to(k.cf.frequency, 400 + 1900 * ch, 0.5); this._to(k.shr.gain, Math.max(0, ch - 0.7) * 0.18, 0.5);
    this._to(k.alarm.gain, s.alarm ? 0.4 : 0, 0.15);
    // generator rumble with distance falloff and wall occlusion
    if (s.genOn) {
      const L = E.L, dx = s.genX - L.x, dz = s.genZ - L.z, d = Math.hypot(dx, dz), occ = E.occlude ? E.occlude(s.genX, s.genZ) : false;
      this._to(k.gen.gain, 0.42 / (1 + Math.pow(d / 16, 1.5)) * (occ ? 0.55 : 1), 0.2); this._to(k.genLp.frequency, occ ? 150 : 280, 0.3);
      if (k.genPan) this._to(k.genPan.pan, Math.max(-0.8, Math.min(0.8, (dx * Math.cos(L.yaw) + dz * Math.sin(L.yaw)) / Math.max(d, 1) * Math.min(1, d / 6))), 0.15);
    } else this._to(k.gen.gain, 0, 0.5);
    // radio
    const r = s.radio || {};
    this._to(k.rad.gain, r.on ? 0.05 + 0.5 * (r.stat ?? 1) : 0, 0.08); this._to(k.rf.frequency, 1400 + (r.shift || 0), 0.1);
    this._to(k.carrier.gain, r.on && r.car ? 0.1 * r.car : 0, 0.1);
    // chase pulse: kick on the beat, offbeat hiss, a rising stinger every bar
    if (ch > 0.25) {
      this.beat -= dt;
      if (this.beat <= 0) {
        this.beat += 0.4; this.step = (this.step + 1) % 8; const t = E.now, o = E.dry({ vol: 0.55 * ch, bus: E.music });
        if (this.step % 2 === 0) { E.tone(o, 'sine', 95, 34, 0.2, 0.9, t, 0.003); E.burst(o, 'brown', 'lowpass', 300, 120, 0.7, 0.16, 0.5, t); }
        else E.burst(o, 'white', 'highpass', 6000, 6000, 1, 0.05, 0.25 * ch, t);
        if (this.step === 6) E.tone(o, 'sawtooth', 180, 720, 0.4, 0.12, t, 0.2);
        if (this.step === 0) E.burst(o, 'pink', 'bandpass', 500, 120, 0.8, 0.5, 0.7, t, 0.01);
      }
    } else this.beat = 0.2;
    // random drips / creaks in dark rooms
    this.dripT -= dt;
    if (this.dripT <= 0 && !s.outdoor) { this.dripT = 2.5 + Math.random() * 6; const a = Math.random() * 6.283, r2 = 3 + Math.random() * 9; s.sfx?.drip(E.L.x + Math.cos(a) * r2, E.L.z + Math.sin(a) * r2); }
  }
  crackle(vol = 1) { const E = this.E; if (!E.ready || !E.reserve(0.2)) return; const o = E.dry({ vol: 0.5 * vol, bus: E.voice }), t = E.now; E.burst(o, 'white', 'bandpass', 2500 + Math.random() * 3000, 1500, 2, 0.04, 0.7, t, 0.001); }
  tuneBlip(f) { const E = this.E; if (!E.ready) return; const o = E.dry({ vol: 0.25, bus: E.voice }), t = E.now, p = 500 + ((f - 87.5) / 20.5) * 1400; E.tone(o, 'sine', p, p * 0.94, 0.06, 0.25, t, 0.004); E.burst(o, 'white', 'bandpass', p * 2, p * 1.5, 3, 0.05, 0.25, t); }
}
