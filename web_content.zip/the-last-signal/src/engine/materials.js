// Builds GPU textures + renderer materials from the procedural recipes. Async so a loading bar can update.
import { makeTexture, MATS } from './textures.js';
import { QUALITY } from './renderer.js';

export async function createMaterials(R, quality, onProgress, extra = {}) {
  const size = QUALITY[quality].texSize, mats = {}, names = Object.keys(MATS), cache = {};
  const tick = () => new Promise((r) => setTimeout(r, 0));
  let i = 0;
  const total = names.length + 3;
  for (const k of names) {
    const m = MATS[k];
    const tex = cache[m.tex] || (cache[m.tex] = R.createTexture(makeTexture(m.tex, m.tex === 'skin' ? Math.min(128, size) : size)));
    mats[k] = { ...m, tex };
    if (onProgress) onProgress(++i / total);
    await tick();
  }
  mats['emis:white'] = { tex: R.createTexture(makeTexture('white', 4)), emis: 1 };
  mats['emis:screen'] = { tex: R.createTexture(makeTexture('screen', 64)), emis: 1.2 };
  mats['emis:glass'] = { tex: R.createTexture(makeTexture('glass', 16)), emis: 0.3 };
  for (const [k, v] of Object.entries(extra)) mats[k] = v; // e.g. decal atlas
  if (!mats.decal) mats.decal = { tex: R.createTexture(makeTexture('white', 4)), bump: 0, spec: 0, shin: 8 };
  if (onProgress) onProgress(1);
  return mats;
}
