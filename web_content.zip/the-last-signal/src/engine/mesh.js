// CPU-side geometry builder (GL independent so it can be unit-tested in Node).
// Vertex = pos(3f) nrm(3f) uv(2f) col(4 ubyte: tint rgb + baked AO) -> 36 bytes.
export const STRIDE = 36;
const WHITE = [1, 1, 1];
export const F_PX = 1, F_NX = 2, F_PZ = 4, F_NZ = 8, F_PY = 16, F_NY = 32; // face skip bits

export class MeshBuilder {
  constructor() {
    this.P = []; this.N = []; this.U = []; this.C = []; this.I = [];
    this.n = 0; this.mat = null;
    this.bb = [1e9, 1e9, 1e9, -1e9, -1e9, -1e9];
  }
  get empty() { return this.n === 0; }
  // set/clear the transform applied to everything added afterwards (rotation + translation only). returns previous.
  xf(m) { const p = this.mat; this.mat = m; return p; }

  v(x, y, z, nx, ny, nz, u, vv, r, g, b, a) {
    const m = this.mat;
    if (m) {
      const X = m[0] * x + m[4] * y + m[8] * z + m[12], Y = m[1] * x + m[5] * y + m[9] * z + m[13], Z = m[2] * x + m[6] * y + m[10] * z + m[14];
      const NX = m[0] * nx + m[4] * ny + m[8] * nz, NY = m[1] * nx + m[5] * ny + m[9] * nz, NZ = m[2] * nx + m[6] * ny + m[10] * nz;
      x = X; y = Y; z = Z; nx = NX; ny = NY; nz = NZ;
    }
    this.P.push(x, y, z); this.N.push(nx, ny, nz); this.U.push(u, vv);
    this.C.push(r, g, b, a);
    const bb = this.bb;
    if (x < bb[0]) bb[0] = x; if (y < bb[1]) bb[1] = y; if (z < bb[2]) bb[2] = z;
    if (x > bb[3]) bb[3] = x; if (y > bb[4]) bb[4] = y; if (z > bb[5]) bb[5] = z;
    return this.n++;
  }
  tri(a, b, c) { this.I.push(a, b, c); }
  // generic quad: p = 12 numbers (BL,BR,TR,TL as seen from outside), uv = 8 numbers
  q(p, nx, ny, nz, uv, t = WHITE, ao = [1, 1, 1, 1]) {
    const i0 = this.n;
    for (let k = 0; k < 4; k++) this.v(p[k * 3], p[k * 3 + 1], p[k * 3 + 2], nx, ny, nz, uv[k * 2], uv[k * 2 + 1], t[0], t[1], t[2], ao[k]);
    this.I.push(i0, i0 + 1, i0 + 2, i0, i0 + 2, i0 + 3);
  }

  // vertical wall face between (x0,z0)-(x1,z1) facing (nx,nz); u runs along the viewer's right so textures tile across segments
  wall(x0, z0, x1, z1, y0, y1, nx, nz, o = {}) {
    const rx = nz, rz = -nx; // viewer's right when looking at the face
    if ((x1 - x0) * rx + (z1 - z0) * rz < 0) { let t = x0; x0 = x1; x1 = t; t = z0; z0 = z1; z1 = t; }
    const s = 1 / (o.s || 2), sv = 1 / (o.sv || o.s || 2), t = o.t || WHITE, uo = (o.uo || 0), vo = (o.vo || 0);
    const ua = (x0 * rx + z0 * rz) * s + uo, ub = (x1 * rx + z1 * rz) * s + uo;
    const a0 = o.ao0 ?? 0.6, a1 = o.ao1 ?? 0.8, am = o.aom ?? 1.0;
    const rows = o.ramp === false ? [[y0, a0], [y1, a1]] : [[y0, a0], [Math.min(y0 + 0.9, (y0 + y1) / 2), am], [y1, a1]];
    for (let k = 0; k < rows.length - 1; k++) {
      const [ya, aa] = rows[k], [yb, ab] = rows[k + 1];
      this.q([x0, ya, z0, x1, ya, z1, x1, yb, z1, x0, yb, z0], nx, 0, nz,
        [ua, ya * sv + vo, ub, ya * sv + vo, ub, yb * sv + vo, ua, yb * sv + vo], t, [aa, aa, ab, ab]);
    }
  }
  // wall whose bottom/top heights differ at both ends (ramp side walls). v starts at 0 along the (sloped) floor line.
  wallSlanted(x0, z0, x1, z1, b0, t0, b1, t1, nx, nz, o = {}) {
    const rx = nz, rz = -nx;
    if ((x1 - x0) * rx + (z1 - z0) * rz < 0) { let t = x0; x0 = x1; x1 = t; t = z0; z0 = z1; z1 = t; t = b0; b0 = b1; b1 = t; t = t0; t0 = t1; t1 = t; }
    const s = 1 / (o.s || 2), sv = 1 / (o.sv || o.s || 2), t = o.t || WHITE;
    const ua = (x0 * rx + z0 * rz) * s, ub = (x1 * rx + z1 * rz) * s, a0 = o.ao0 ?? 0.6, a1 = o.ao1 ?? 0.8;
    this.q([x0, b0, z0, x1, b1, z1, x1, t1, z1, x0, t0, z0], nx, 0, nz, [ua, 0, ub, 0, ub, (t1 - b1) * sv, ua, (t0 - b0) * sv], t, [a0, a0, a1, a1]);
  }
  // horizontal face (floor: up=true faces +Y, ceiling: up=false faces -Y)
  flat(x0, z0, x1, z1, y, up, o = {}) {
    const s = 1 / (o.s || 2), t = o.t || WHITE, a = o.ao ?? 1, uo = o.uo || 0, vo = o.vo || 0;
    if (up) this.q([x0, y, z1, x1, y, z1, x1, y, z0, x0, y, z0], 0, 1, 0, [x0 * s + uo, -z1 * s + vo, x1 * s + uo, -z1 * s + vo, x1 * s + uo, -z0 * s + vo, x0 * s + uo, -z0 * s + vo], t, [a, a, a, a]);
    else this.q([x1, y, z1, x0, y, z1, x0, y, z0, x1, y, z0], 0, -1, 0, [-x1 * s + uo, -z1 * s + vo, -x0 * s + uo, -z1 * s + vo, -x0 * s + uo, -z0 * s + vo, -x1 * s + uo, -z0 * s + vo], t, [a, a, a, a]);
  }
  // sloped floor patch: heights at (x0,z0),(x1,z0),(x1,z1),(x0,z1)
  slope(x0, z0, x1, z1, ya, yb, yc, yd, up, o = {}) {
    const s = 1 / (o.s || 2), t = o.t || WHITE, a = o.ao ?? 1;
    const ex = x1 - x0, ez = z1 - z0;
    // normal from two edge vectors
    const ux = ex, uy = yb - ya, uz = 0, vx = 0, vy = yd - ya, vz = ez;
    let nx = vy * uz - vz * uy, ny = vz * ux - vx * uz, nz = vx * uy - vy * ux; // v x u (points up for a flat floor)
    const l = Math.hypot(nx, ny, nz) || 1; nx /= l; ny /= l; nz /= l;
    const uvs = [x0 * s, z0 * s, x1 * s, z0 * s, x1 * s, z1 * s, x0 * s, z1 * s];
    if (up) this.q([x0, yd, z1, x1, yc, z1, x1, yb, z0, x0, ya, z0], nx, ny, nz, [uvs[6], uvs[7], uvs[4], uvs[5], uvs[2], uvs[3], uvs[0], uvs[1]], t, [a, a, a, a]);
    else this.q([x1, yc, z1, x0, yd, z1, x0, ya, z0, x1, yb, z0], -nx, -ny, -nz, [uvs[4], uvs[5], uvs[6], uvs[7], uvs[0], uvs[1], uvs[2], uvs[3]], t, [a, a, a, a]);
  }

  box(x0, y0, z0, x1, y1, z1, o = {}) {
    const s = 1 / (o.s || 2), t = o.t || WHITE, k = o.skip || 0;
    const a0 = o.ao0 ?? o.ao ?? 1, a1 = o.ao1 ?? o.ao ?? 1, uo = o.uo || 0, vo = o.vo || 0;
    const A = [a0, a0, a1, a1];
    if (!(k & F_PX)) this.q([x1, y0, z1, x1, y0, z0, x1, y1, z0, x1, y1, z1], 1, 0, 0, [-z1 * s + uo, y0 * s + vo, -z0 * s + uo, y0 * s + vo, -z0 * s + uo, y1 * s + vo, -z1 * s + uo, y1 * s + vo], t, A);
    if (!(k & F_NX)) this.q([x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0], -1, 0, 0, [z0 * s + uo, y0 * s + vo, z1 * s + uo, y0 * s + vo, z1 * s + uo, y1 * s + vo, z0 * s + uo, y1 * s + vo], t, A);
    if (!(k & F_PZ)) this.q([x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1], 0, 0, 1, [x0 * s + uo, y0 * s + vo, x1 * s + uo, y0 * s + vo, x1 * s + uo, y1 * s + vo, x0 * s + uo, y1 * s + vo], t, A);
    if (!(k & F_NZ)) this.q([x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0], 0, 0, -1, [-x1 * s + uo, y0 * s + vo, -x0 * s + uo, y0 * s + vo, -x0 * s + uo, y1 * s + vo, -x1 * s + uo, y1 * s + vo], t, A);
    if (!(k & F_PY)) this.q([x0, y1, z1, x1, y1, z1, x1, y1, z0, x0, y1, z0], 0, 1, 0, [x0 * s + uo, -z1 * s + vo, x1 * s + uo, -z1 * s + vo, x1 * s + uo, -z0 * s + vo, x0 * s + uo, -z0 * s + vo], t, [a1, a1, a1, a1]);
    if (!(k & F_NY)) this.q([x1, y0, z1, x0, y0, z1, x0, y0, z0, x1, y0, z0], 0, -1, 0, [-x1 * s + uo, -z1 * s + vo, -x0 * s + uo, -z1 * s + vo, -x0 * s + uo, -z0 * s + vo, -x1 * s + uo, -z0 * s + vo], t, [a0, a0, a0, a0]);
  }
  // box given by centre + size
  boxC(cx, cy, cz, sx, sy, sz, o) { this.box(cx - sx / 2, cy - sy / 2, cz - sz / 2, cx + sx / 2, cy + sy / 2, cz + sz / 2, o); }

  // cylinder / pipe along an arbitrary axis from A to B
  tube(ax, ay, az, bx, by, bz, r, seg = 10, o = {}) {
    let dx = bx - ax, dy = by - ay, dz = bz - az;
    const len = Math.hypot(dx, dy, dz) || 1e-6; dx /= len; dy /= len; dz /= len;
    // helper not parallel to d
    const hx = Math.abs(dy) > 0.9 ? 1 : 0, hy = Math.abs(dy) > 0.9 ? 0 : 1;
    let ux = hy * dz, uy = -hx * dz, uz = hx * dy - hy * dx; // helper x d
    const ul = Math.hypot(ux, uy, uz) || 1; ux /= ul; uy /= ul; uz /= ul;
    const vx = dy * uz - dz * uy, vy = dz * ux - dx * uz, vz = dx * uy - dy * ux; // d x u
    const s = 1 / (o.s || 2), t = o.t || WHITE, a0 = o.ao0 ?? o.ao ?? 1, a1 = o.ao1 ?? o.ao ?? 1;
    const ring = (i) => { const th = (i / seg) * Math.PI * 2, c = Math.cos(th), si = Math.sin(th); return [c * ux + si * vx, c * uy + si * vy, c * uz + si * vz]; };
    const circ = Math.PI * 2 * r * s;
    for (let i = 0; i < seg; i++) {
      const n0 = ring(i), n1 = ring(i + 1);
      const i0 = this.n;
      this.v(ax + n0[0] * r, ay + n0[1] * r, az + n0[2] * r, n0[0], n0[1], n0[2], (i / seg) * circ, 0, t[0], t[1], t[2], a0);
      this.v(ax + n1[0] * r, ay + n1[1] * r, az + n1[2] * r, n1[0], n1[1], n1[2], ((i + 1) / seg) * circ, 0, t[0], t[1], t[2], a0);
      this.v(bx + n1[0] * r, by + n1[1] * r, bz + n1[2] * r, n1[0], n1[1], n1[2], ((i + 1) / seg) * circ, len * s, t[0], t[1], t[2], a1);
      this.v(bx + n0[0] * r, by + n0[1] * r, bz + n0[2] * r, n0[0], n0[1], n0[2], (i / seg) * circ, len * s, t[0], t[1], t[2], a1);
      this.I.push(i0, i0 + 1, i0 + 2, i0, i0 + 2, i0 + 3);
    }
    if (o.caps !== false) {
      for (const end of [0, 1]) {
        const px = end ? bx : ax, py = end ? by : ay, pz = end ? bz : az, sg = end ? 1 : -1;
        const c = this.v(px, py, pz, dx * sg, dy * sg, dz * sg, 0.5, 0.5, t[0], t[1], t[2], end ? a1 : a0);
        const idx = [];
        for (let i = 0; i <= seg; i++) {
          const n0 = ring(i), th = (i / seg) * Math.PI * 2;
          idx.push(this.v(px + n0[0] * r, py + n0[1] * r, pz + n0[2] * r, dx * sg, dy * sg, dz * sg, 0.5 + Math.cos(th) * 0.25, 0.5 + Math.sin(th) * 0.25, t[0], t[1], t[2], end ? a1 : a0));
        }
        for (let i = 0; i < seg; i++) { if (end) this.tri(c, idx[i], idx[i + 1]); else this.tri(c, idx[i + 1], idx[i]); }
      }
    }
  }
  cyl(cx, y0, cz, r, h, seg = 10, o = {}) { this.tube(cx, y0, cz, cx, y0 + h, cz, r, seg, o); }

  sphere(cx, cy, cz, r, seg = 8, rings = 5, o = {}) {
    const t = o.t || WHITE, a = o.ao ?? 1, s = 1 / (o.s || 2);
    for (let j = 0; j < rings; j++) {
      const p0 = (j / rings - 0.5) * Math.PI, p1 = ((j + 1) / rings - 0.5) * Math.PI;
      for (let i = 0; i < seg; i++) {
        const t0 = (i / seg) * Math.PI * 2, t1 = ((i + 1) / seg) * Math.PI * 2;
        const P = (th, ph) => [Math.cos(ph) * Math.cos(th), Math.sin(ph), Math.cos(ph) * Math.sin(th)];
        const bl = P(t1, p0), br = P(t0, p0), tr = P(t0, p1), tl = P(t1, p1);
        const i0 = this.n;
        for (const [q, u, vv] of [[bl, t1, p0], [br, t0, p0], [tr, t0, p1], [tl, t1, p1]])
          this.v(cx + q[0] * r, cy + q[1] * r, cz + q[2] * r, q[0], q[1], q[2], u * r * s, vv * r * s, t[0], t[1], t[2], a);
        this.I.push(i0, i0 + 1, i0 + 2, i0, i0 + 2, i0 + 3);
      }
    }
  }
  // torus around the Z axis at the origin (use xf() to orient/place it)
  torus(R, r, segR = 24, segr = 8, o = {}) {
    const t = o.t || WHITE, a = o.ao ?? 1, s = 1 / (o.s || 2);
    const P = (th, ph) => { const c = Math.cos(ph), cr = R + r * c; return [cr * Math.cos(th), cr * Math.sin(th), r * Math.sin(ph), c * Math.cos(th), c * Math.sin(th), Math.sin(ph)]; };
    for (let i = 0; i < segR; i++) for (let j = 0; j < segr; j++) {
      const t0 = (i / segR) * Math.PI * 2, t1 = ((i + 1) / segR) * Math.PI * 2, f0 = (j / segr) * Math.PI * 2, f1 = ((j + 1) / segr) * Math.PI * 2;
      const q = [P(t0, f0), P(t1, f0), P(t1, f1), P(t0, f1)], uv = [[t0, f0], [t1, f0], [t1, f1], [t0, f1]];
      const i0 = this.n;
      for (let k = 0; k < 4; k++) this.v(q[k][0], q[k][1], q[k][2], q[k][3], q[k][4], q[k][5], uv[k][0] * R * s, uv[k][1] * r * s, t[0], t[1], t[2], a);
      this.I.push(i0, i0 + 1, i0 + 2, i0, i0 + 2, i0 + 3);
    }
  }

  finalize() {
    const n = this.n, buf = new ArrayBuffer(n * STRIDE), f = new Float32Array(buf), b = new Uint8Array(buf);
    for (let i = 0; i < n; i++) {
      const o = (i * STRIDE) >> 2;
      f[o] = this.P[i * 3]; f[o + 1] = this.P[i * 3 + 1]; f[o + 2] = this.P[i * 3 + 2];
      f[o + 3] = this.N[i * 3]; f[o + 4] = this.N[i * 3 + 1]; f[o + 5] = this.N[i * 3 + 2];
      f[o + 6] = this.U[i * 2]; f[o + 7] = this.U[i * 2 + 1];
      const bo = i * STRIDE + 32;
      for (let k = 0; k < 4; k++) b[bo + k] = Math.max(0, Math.min(255, Math.round(this.C[i * 4 + k] * 255)));
    }
    return { buffer: buf, vertexCount: n, indices: new Uint32Array(this.I), bounds: this.bb.slice() };
  }
}

// Debug helper: returns number of triangles whose winding disagrees with the vertex normal.
export function badWinding(mb) {
  let bad = 0;
  for (let t = 0; t < mb.I.length; t += 3) {
    const a = mb.I[t] * 3, b = mb.I[t + 1] * 3, c = mb.I[t + 2] * 3, P = mb.P, N = mb.N;
    const e1 = [P[b] - P[a], P[b + 1] - P[a + 1], P[b + 2] - P[a + 2]], e2 = [P[c] - P[a], P[c + 1] - P[a + 1], P[c + 2] - P[a + 2]];
    const cr = [e1[1] * e2[2] - e1[2] * e2[1], e1[2] * e2[0] - e1[0] * e2[2], e1[0] * e2[1] - e1[1] * e2[0]];
    const area = Math.hypot(cr[0], cr[1], cr[2]);
    if (area < 1e-9) continue;
    if (cr[0] * N[a] + cr[1] * N[a + 1] + cr[2] * N[a + 2] <= 0) bad++;
  }
  return bad;
}
