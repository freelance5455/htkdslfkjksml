// Lightweight CPU particle system: flashlight dust motes, sparks, blood, steam, drips. Rendered as point sprites.
const F = 14; // floats per particle: x y z vx vy vz life max size r g b a type
const T = { SPARK: 1, BLOOD: 2, STEAM: 3, DRIP: 4, SPLASH: 5 };

export class Particles {
  constructor(max = 700) {
    this.max = max; this.p = new Float32Array(max * F); this.n = 0;
    this.addBuf = new Float32Array((max + 400) * 9); this.altBuf = new Float32Array((max + 400) * 9);
    this.dust = null; this.emit = []; this.rnd = Math.random;
  }
  setDust(count, cam) {
    this.dust = new Float32Array(count * 4);
    for (let i = 0; i < count; i++) this._respawnDust(i, cam, true);
  }
  _respawnDust(i, cam, any) {
    const d = this.dust, r = this.rnd;
    const a = (any ? r() * 6.283 : cam.yaw + (r() - 0.5) * 2.6), dist = 0.6 + r() * 7;
    d[i * 4] = cam.x + Math.sin(a) * dist; d[i * 4 + 1] = cam.y + (r() - 0.55) * 2.6; d[i * 4 + 2] = cam.z - Math.cos(a) * dist; d[i * 4 + 3] = r() * 6.283;
  }
  burst(type, x, y, z, n, o = {}) {
    const r = this.rnd;
    for (let i = 0; i < n && this.n < this.max; i++) {
      const k = this.n++ * F, p = this.p, sp = o.speed ?? 3, a = r() * 6.283, e = (r() - 0.2) * (o.spread ?? 1.2);
      p[k] = x; p[k + 1] = y; p[k + 2] = z;
      p[k + 3] = Math.cos(a) * sp * (0.3 + r()) * (o.hx ?? 1) + (o.vx ?? 0); p[k + 4] = e * sp * (0.4 + r()) + (o.vy ?? 0); p[k + 5] = Math.sin(a) * sp * (0.3 + r()) * (o.hz ?? 1) + (o.vz ?? 0);
      p[k + 6] = 0; p[k + 7] = (o.life ?? 0.7) * (0.6 + r() * 0.8); p[k + 8] = o.size ?? 0.04;
      const c = o.color || [1, 0.7, 0.3]; p[k + 9] = c[0]; p[k + 10] = c[1]; p[k + 11] = c[2]; p[k + 12] = o.alpha ?? 1; p[k + 13] = type;
    }
  }
  sparks(x, y, z, n = 16) { this.burst(T.SPARK, x, y, z, n, { speed: 3.4, spread: 1.6, life: 0.55, size: 0.035, color: [1.4, 0.8, 0.3] }); }
  blood(x, y, z, n = 14, dx = 0, dz = 0) { this.burst(T.BLOOD, x, y, z, n, { speed: 2.4, spread: 1.0, life: 0.9, size: 0.05, color: [0.28, 0.01, 0.015], alpha: 0.9, vx: dx, vz: dz }); }
  steam(x, y, z, n = 1) { this.burst(T.STEAM, x, y, z, n, { speed: 0.35, spread: 0.3, life: 2.6, size: 0.55, color: [0.55, 0.6, 0.62], alpha: 0.08, vy: 0.55 }); }
  update(dt, cam, world, fx, quality) {
    const p = this.p, g = world ? world.grid : null;
    for (let i = 0; i < this.n; i++) {
      const k = i * F, type = p[k + 13];
      p[k + 6] += dt;
      if (p[k + 6] >= p[k + 7]) { this._remove(i--); continue; }
      const grav = type === T.STEAM ? 0.1 : -9.8;
      p[k + 4] += (type === T.STEAM ? 0 : grav) * dt * (type === T.DRIP ? 0.9 : 0.6);
      p[k] += p[k + 3] * dt; p[k + 1] += p[k + 4] * dt; p[k + 2] += p[k + 5] * dt;
      if (type === T.STEAM) { p[k + 8] += dt * 0.35; p[k + 3] *= 0.98; p[k + 5] *= 0.98; }
      if (g && type !== T.STEAM && p[k + 4] < 0 && p[k + 1] < g.floorY(p[k], p[k + 2]) + 0.01) {
        if (type === T.DRIP) { this.burst(T.SPLASH, p[k], p[k + 1] + 0.01, p[k + 2], 2, { speed: 0.6, spread: 0.8, life: 0.25, size: 0.02, color: [0.6, 0.65, 0.7], alpha: 0.6 }); }
        this._remove(i--); continue;
      }
    }
    // ambient emitters from level content (drips, steam)
    if (fx && world) {
      for (const e of fx) {
        const dx = e.x - cam.x, dz = e.z - cam.z; if (dx * dx + dz * dz > 400) continue;
        e.t = (e.t ?? Math.random()) - dt;
        if (e.t <= 0) {
          if (e.kind === 'drip') { e.t = 0.7 + Math.random() * 1.6; this.burst(T.DRIP, e.x + (Math.random() - 0.5) * 0.05, e.y, e.z, 1, { speed: 0, life: 3, size: 0.025, color: [0.55, 0.62, 0.7], alpha: 0.75, vy: 0 }); }
          else if (e.kind === 'steam') { e.t = 0.18 + Math.random() * 0.25; this.steam(e.x + (Math.random() - 0.5) * 0.4, e.y, e.z + (Math.random() - 0.5) * 0.4, 1); }
        }
      }
    }
    // dust
    if (this.dust) {
      const d = this.dust, n = d.length / 4;
      for (let i = 0; i < n; i++) {
        const j = i * 4; d[j + 3] += dt * 0.8;
        d[j] += Math.sin(d[j + 3] * 1.3 + i) * 0.04 * dt; d[j + 1] += Math.sin(d[j + 3] * 0.9 + i * 2) * 0.03 * dt - 0.01 * dt; d[j + 2] += Math.cos(d[j + 3] * 1.1 + i * 3) * 0.04 * dt;
        const dx = d[j] - cam.x, dz = d[j + 2] - cam.z;
        if (dx * dx + dz * dz > 64) this._respawnDust(i, cam, false);
      }
    }
  }
  _remove(i) { const last = --this.n; if (i !== last) this.p.copyWithin(i * F, last * F, last * F + F); }
  draw(R, cam, alphaBoost = 1) {
    let na = 0, nb = 0; const A = this.addBuf, B = this.altBuf, p = this.p;
    if (this.dust) {
      const d = this.dust, n = d.length / 4;
      for (let i = 0; i < n; i++) { const o = na++ * 9, tw = 0.5 + 0.5 * Math.sin(d[i * 4 + 3] * 2.1); A[o] = d[i * 4]; A[o + 1] = d[i * 4 + 1]; A[o + 2] = d[i * 4 + 2]; A[o + 3] = 0.8; A[o + 4] = 0.85; A[o + 5] = 0.8; A[o + 6] = 0.5 * tw; A[o + 7] = 0.012 + 0.01 * tw; A[o + 8] = 1; }
    }
    for (let i = 0; i < this.n; i++) {
      const k = i * F, type = p[k + 13], u = p[k + 6] / p[k + 7], fade = type === T.STEAM ? Math.sin(Math.min(1, u) * 3.14159) : 1 - u;
      if (type === T.SPARK) { const o = na++ * 9; A[o] = p[k]; A[o + 1] = p[k + 1]; A[o + 2] = p[k + 2]; A[o + 3] = p[k + 9]; A[o + 4] = p[k + 10]; A[o + 5] = p[k + 11]; A[o + 6] = fade; A[o + 7] = p[k + 8]; A[o + 8] = 0; }
      else { const o = nb++ * 9; B[o] = p[k]; B[o + 1] = p[k + 1]; B[o + 2] = p[k + 2]; B[o + 3] = p[k + 9]; B[o + 4] = p[k + 10]; B[o + 5] = p[k + 11]; B[o + 6] = p[k + 12] * fade * alphaBoost; B[o + 7] = p[k + 8]; B[o + 8] = 0; }
    }
    if (nb) R.drawSprites(B, nb, false);
    if (na) R.drawSprites(A, na, true);
  }
}
