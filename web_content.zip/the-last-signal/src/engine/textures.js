// Procedural material textures. RGB = albedo (sRGB-ish), A = height (used for bump + specular mask).
import { fbm, vnoise, ridge, mix, ss, hash2, crackMask } from './noise.js';

const c8 = (v) => (v <= 0 ? 0 : v >= 1 ? 255 : (v * 255) | 0);
function gen(w, h, fn) {
  const d = new Uint8Array(w * h * 4), o = [0, 0, 0, 1];
  let i = 0;
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    fn((x + 0.5) / w, (y + 0.5) / h, o);
    d[i++] = c8(o[0]); d[i++] = c8(o[1]); d[i++] = c8(o[2]); d[i++] = c8(o[3]);
  }
  return { w, h, data: d };
}
const set = (o, r, g, b, a) => { o[0] = r; o[1] = g; o[2] = b; o[3] = a; };

// Each recipe: (size) -> {w,h,data,wrapT}
const RECIPES = {
  // painted corridor wall: dark dado to 1.2m, cream above. Texture covers 2m wide x 4m tall (v from floor).
  paint: (n) => { const cm = crackMask(n, n * 2, 5, n * 1.1, 21); return ({ ...gen(n, n * 2, (u, v, o) => {
    const hm = v * 4, ck = cm[((v * n * 2) | 0) * n + ((u * n) | 0)];
    const st = fbm(u, v, 5, 10, 4), sk = fbm(u, v, 14, 3, 3), pe = fbm(u, v, 7, 14, 4), mo = fbm(u, v, 12, 24, 3);
    let r, g, b, ht = 0.62 + 0.06 * vnoise(u * 90, v * 180, 90, 180);
    if (hm < 1.18) { r = 0.11; g = 0.22; b = 0.19; } else { r = 0.66; g = 0.63; b = 0.52; }
    const k = 0.62 + 0.55 * st; r *= k; g *= k; b *= k;
    const streak = ss(0.55, 0.78, sk) * (0.25 + v * 0.75) * 0.5; r *= 1 - streak; g *= 1 - streak; b *= 1 - streak * 0.9;
    const gr = 0.55 + 0.45 * ss(0, 0.6, hm); r *= gr; g *= gr; b *= gr;
    if (Math.abs(hm - 1.18) < 0.022) { r = g = b = 0.025; ht = 0.5; }
    else if (Math.abs(hm - 1.215) < 0.008) { r *= 1.35; g *= 1.35; b *= 1.3; }
    if (pe > 0.67) { const e = ss(0.67, 0.7, pe); const cn = 0.36 + 0.1 * st; r = mix(r, cn, e); g = mix(g, cn, e); b = mix(b, cn * 0.96, e); ht = mix(ht, 0.3 + 0.2 * st, e); }
    if (mo > 0.6 && (hm < 0.9 || hm > 3.2)) { const m = ss(0.6, 0.72, mo) * 0.65; r = mix(r, 0.08, m); g = mix(g, 0.16, m); b = mix(b, 0.07, m); }
    if (ck) { const e = ck / 255; r *= 1 - 0.8 * e; g *= 1 - 0.8 * e; b *= 1 - 0.8 * e; ht = mix(ht, 0.05, e); }
    set(o, r, g, b, ht);
  }), wrapT: 'clamp' }); },

  concrete: (n) => { const cm = crackMask(n, n, 4, n * 0.9, 33); return ({ ...gen(n, n, (u, v, o) => {
    const ck = cm[((v * n) | 0) * n + ((u * n) | 0)], nn = fbm(u, v, 8, 8, 5), pit = vnoise(u * 64, v * 64, 64, 64), st = fbm(u, v, 3, 3, 3), sk = fbm(u, v, 20, 2, 2);
    let k = 0.7 + 0.6 * nn; let ht = 0.5 + 0.4 * nn;
    k *= 1 - 0.2 * ss(0.5, 0.75, st) - 0.14 * ss(0.6, 0.85, sk);
    if (pit > 0.84) { k *= 0.45; ht *= 0.3; }
    const su = Math.abs(((u * 2) % 1) - 0.5), sv = Math.abs(((v * 2) % 1) - 0.5);
    if (su > 0.495 || sv > 0.495) { k *= 0.55; ht = 0.15; }
    const tx = (u * 4) % 1, ty = (v * 4) % 1;
    if (Math.hypot(tx - 0.5, ty - 0.5) < 0.05 && Math.floor(u * 4) % 2 === 0 && Math.floor(v * 4) % 2 === 0) { k *= 0.4; ht = 0.1; }
    if (ck) { const e = ck / 255; k *= 1 - 0.75 * e; ht = mix(ht, 0.04, e); }
    set(o, 0.46 * k, 0.47 * k, 0.45 * k, ht);
  }) }); },

  floor: (n) => ({ ...gen(n, n, (u, v, o) => {
    const nn = fbm(u, v, 6, 6, 4), sc = vnoise(u * 3, v * 140, 3, 140), sc2 = vnoise(u * 120, v * 4, 120, 4), wet = fbm(u, v, 6, 6, 3), oil = fbm(u, v, 9, 9, 3);
    let k = 0.62 + 0.55 * nn, ht = 0.5 + 0.2 * nn;
    if (sc > 0.86 || sc2 > 0.9) { k *= 1.25; ht -= 0.1; }
    if (wet > 0.6) { const w = ss(0.6, 0.7, wet); k *= 1 - 0.28 * w; ht = mix(ht, 0.97, w); }
    if (oil > 0.7) k *= 0.6;
    const su = Math.abs(((u * 2) % 1) - 0.5), sv = Math.abs(((v * 2) % 1) - 0.5);
    if (su > 0.493 || sv > 0.493) { k *= 0.5; ht = 0.1; }
    set(o, 0.31 * k, 0.31 * k, 0.3 * k, ht);
  }) }),

  tiles: (n) => { const cm = crackMask(n, n, 5, n * 0.45, 47); return ({ ...gen(n, n, (u, v, o) => {
    const ck = cm[((v * n) | 0) * n + ((u * n) | 0)], T = 6, tu = (u * T) % 1, tv = (v * T) % 1, id = Math.floor(u * T) + 7 * Math.floor(v * T);
    const dirt = fbm(u, v, 10, 10, 4), edge = Math.min(tu, 1 - tu, tv, 1 - tv);
    let k = (0.88 + 0.2 * hash2(id, 3)) * (0.5 + 0.7 * dirt), ht;
    let r = 0.72 * k, g = 0.76 * k, b = 0.72 * k;
    if (edge < 0.035) { r = g = b = 0.1 + 0.05 * dirt; ht = 0.15; }
    else { ht = 0.82 - 0.5 * ss(0.075, 0.035, edge); k = 0.7 + 0.3 * ss(0.035, 0.12, edge); r *= k; g *= k; b *= k; }
    if (ck) { const e = ck / 255; r *= 1 - 0.8 * e; g *= 1 - 0.8 * e; b *= 1 - 0.8 * e; ht = mix(ht, 0.05, e); }
    if (hash2(id, 9) > 0.93) { const c = ss(0.6, 1, tu + tv) * 0.5; r = mix(r, 0.12, c); g = mix(g, 0.12, c); b = mix(b, 0.1, c); }
    set(o, r, g, b, ht);
  }) }); },

  metal: (n) => ({ ...gen(n, n, (u, v, o) => {
    const br = vnoise(u * 4, v * 160, 4, 160), nn = fbm(u, v, 6, 6, 4), rs = fbm(u, v, 5, 5, 4), dr = fbm(u, v, 18, 2, 2);
    let k = 0.7 + 0.5 * nn + (br - 0.5) * 0.18, ht = 0.6 + 0.1 * br;
    let r = 0.3 * k, g = 0.32 * k, b = 0.34 * k;
    const sx = Math.abs(((u * 2) % 1) - 0.5), sy = Math.abs(((v * 2) % 1) - 0.5);
    if (sx > 0.488 || sy > 0.488) { r *= 0.35; g *= 0.35; b *= 0.35; ht = 0.12; }
    const rx = (u * 2) % 1, ry = (v * 2) % 1;
    for (const [cx, cy] of [[0.07, 0.07], [0.93, 0.07], [0.07, 0.93], [0.93, 0.93]]) if (Math.hypot(rx - cx, ry - cy) < 0.028) { r *= 1.5; g *= 1.5; b *= 1.5; ht = 0.97; }
    const ru = ss(0.64, 0.84, rs + 0.18 * ss(0.5, 1, dr) * (1 - v)) * 0.8;
    r = mix(r, 0.42 * (0.6 + nn), ru); g = mix(g, 0.2 * (0.6 + nn), ru); b = mix(b, 0.08, ru); ht = mix(ht, 0.5 + 0.3 * nn, ru);
    set(o, r, g, b, ht);
  }) }),

  grate: (n) => ({ ...gen(n, n, (u, v, o) => {
    const a = (u * 8) % 1, b = (v * 8) % 1, nn = fbm(u, v, 8, 8, 3);
    if (a < 0.3 || b < 0.3) { const k = 0.7 + 0.5 * nn; set(o, 0.26 * k, 0.27 * k, 0.28 * k, 0.85); }
    else set(o, 0.008, 0.008, 0.01, 0.0);
  }) }),

  rock: (n) => ({ ...gen(n, n, (u, v, o) => {
    const nn = fbm(u, v, 5, 5, 5), w = fbm(u, v, 12, 2, 3), cr = ridge(fbm(u, v, 4, 4, 4));
    let k = 0.45 + 0.9 * nn; k *= 1 - 0.4 * ss(0.55, 0.8, w);
    let ht = Math.pow(nn, 1.4);
    if (cr > 0.975) { k *= 0.3; ht *= 0.2; }
    set(o, 0.36 * k, 0.31 * k, 0.27 * k, ht);
  }) }),

  wood: (n) => ({ ...gen(n, n, (u, v, o) => {
    const P = 4, id = Math.floor(v * P), pv = (v * P) % 1;
    const grain = 0.5 + 0.5 * Math.sin((u * 6 + fbm(u, v, 4, 4, 3) * 5 + hash2(id, 1) * 9) * 6.28 * 2 + vnoise(u * 40, v * 6, 40, 6) * 2);
    let k = (0.62 + 0.5 * grain) * (0.8 + 0.4 * hash2(id, 5)), ht = 0.55 + 0.2 * grain;
    let r = 0.34 * k, g = 0.22 * k, b = 0.12 * k;
    if (pv < 0.04 || pv > 0.97) { r = g = b = 0.02; ht = 0.1; }
    const nx = (u * 2) % 1;
    if (Math.hypot(nx - 0.06, pv - 0.5) < 0.025) { r = g = b = 0.12; ht = 0.95; }
    set(o, r, g, b, ht);
  }) }),

  rust: (n) => ({ ...gen(n, n, (u, v, o) => {
    const nn = fbm(u, v, 6, 6, 5), fl = fbm(u, v, 9, 9, 3);
    let r = 0.38 * (0.5 + nn), g = 0.18 * (0.5 + nn), b = 0.08 * (0.5 + nn), ht = 0.4 + 0.5 * nn;
    if (fl > 0.6) { const e = ss(0.6, 0.66, fl); r = mix(r, 0.14, e); g = mix(g, 0.18, e); b = mix(b, 0.2, e); ht = mix(ht, 0.8, e); }
    set(o, r, g, b, ht);
  }) }),

  skin: (n) => ({ ...gen(n, n, (u, v, o) => {
    const nn = fbm(u, v, 7, 7, 5), vn = ridge(fbm(u, v, 6, 6, 3));
    let k = 0.55 + 0.9 * nn, r = 0.075 * k, g = 0.07 * k, b = 0.075 * k, ht = 0.4 + 0.45 * nn;
    if (vn > 0.955) { const e = ss(0.955, 0.975, vn); r = mix(r, 0.3, e); g = mix(g, 0.015, e); b = mix(b, 0.025, e); ht = mix(ht, 0.85, e); }
    set(o, r, g, b, ht);
  }) }),

  dirt: (n) => ({ ...gen(n, n, (u, v, o) => {
    const nn = fbm(u, v, 8, 8, 5), gr = vnoise(u * 48, v * 48, 48, 48), pd = fbm(u, v, 5, 5, 4), ms = fbm(u, v, 6, 6, 3);
    let k = 0.5 + 0.7 * nn + 0.25 * (gr - 0.5), r = 0.21 * k, g = 0.18 * k, b = 0.145 * k, ht = 0.45 + 0.4 * gr * nn;
    if (ms > 0.64) { const m = ss(0.64, 0.72, ms) * 0.6; r = mix(r, 0.05, m); g = mix(g, 0.1, m); b = mix(b, 0.04, m); }
    if (pd > 0.66) { const w = ss(0.66, 0.72, pd) * 0.75; r = mix(r, 0.05, w); g = mix(g, 0.055, w); b = mix(b, 0.07, w); ht = mix(ht, 0.98, w); }
    set(o, r, g, b, ht);
  }) }),

  white: () => gen(4, 4, (u, v, o) => set(o, 1, 1, 1, 1)),
  screen: (n) => gen(64, 64, (u, v, o) => {
    const ln = 0.55 + 0.45 * Math.sin(v * 64 * 3.14), nz = hash2((u * 64) | 0, (v * 64) | 0);
    set(o, 0.15 * ln * (0.4 + nz), 0.85 * ln * (0.3 + 0.7 * nz), 0.3 * ln * (0.4 + nz), 1);
  }),
  glass: () => gen(16, 16, (u, v, o) => set(o, 0.55, 0.7, 0.75, 0.18 + 0.1 * ss(0.4, 0.6, u * 0.7 + v * 0.3))),
};

export const TEXTURE_NAMES = Object.keys(RECIPES);
export function makeTexture(name, size) {
  const t = RECIPES[name](size);
  return { name, wrapT: t.wrapT || 'repeat', ...t };
}
// Material table: shader parameters per surface type (bump = height slope multiplier, spec = specular strength)
export const MATS = {
  wall: { tex: 'paint', bump: 2.4, spec: 0.12, shin: 22 },
  conc: { tex: 'concrete', bump: 3.2, spec: 0.08, shin: 14 },
  floor: { tex: 'floor', bump: 1.8, spec: 0.85, shin: 42 },
  tile: { tex: 'tiles', bump: 2.6, spec: 0.95, shin: 64 },
  metal: { tex: 'metal', bump: 2.2, spec: 0.9, shin: 52 },
  grate: { tex: 'grate', bump: 1.5, spec: 0.55, shin: 30 },
  rock: { tex: 'rock', bump: 4.5, spec: 0.18, shin: 12 },
  wood: { tex: 'wood', bump: 1.6, spec: 0.22, shin: 18 },
  rust: { tex: 'rust', bump: 3.2, spec: 0.3, shin: 20 },
  skin: { tex: 'skin', bump: 4.5, spec: 1.2, shin: 34 },
  dirt: { tex: 'dirt', bump: 3.8, spec: 0.45, shin: 18 },
};
