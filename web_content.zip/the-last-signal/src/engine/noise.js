// Tileable value noise used by the procedural texture generators (deterministic, no assets).
import { rng } from './math.js';

const L = 256;
const lat = new Float32Array(L * L);
{ const r = rng(90210); for (let i = 0; i < lat.length; i++) lat[i] = r(); }

// integer hash -> [0,1)
export const hash2 = (x, y) => {
  let h = (Math.imul(x | 0, 374761393) + Math.imul(y | 0, 668265263)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
};

// smooth noise, tileable with integer periods px,py (<= 256) in lattice units
export function vnoise(x, y, px, py) {
  const xi = Math.floor(x), yi = Math.floor(y), xf = x - xi, yf = y - yi;
  const x0 = ((xi % px) + px) % px, y0 = ((yi % py) + py) % py;
  const x1 = (x0 + 1) % px, y1 = (y0 + 1) % py;
  const a = lat[y0 * L + x0], b = lat[y0 * L + x1], c = lat[y1 * L + x0], d = lat[y1 * L + x1];
  const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}

// fractal noise; (x,y) in [0,1) texture space, base periods px,py, octaves double the frequency
export function fbm(x, y, px, py, oct = 4) {
  let s = 0, a = 0.5, f = 1, tot = 0;
  for (let i = 0; i < oct; i++) {
    s += a * vnoise(x * px * f, y * py * f, px * f, py * f);
    tot += a; a *= 0.5; f *= 2;
  }
  return s / tot;
}
export const ridge = (n) => 1 - Math.abs(n * 2 - 1);
export const mix = (a, b, t) => a + (b - a) * t;
export const ss = (a, b, x) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); };

// Random-walk crack lines (wraps at the edges so it still tiles). Returns Uint8Array(w*h): 255 = crack core, 128 = soft edge.
export function crackMask(w, h, count, len, seed) {
  const m = new Uint8Array(w * h), r = rng(seed);
  const plot = (x, y, v) => { const xi = (((x | 0) % w) + w) % w, yi = (((y | 0) % h) + h) % h; if (m[yi * w + xi] < v) m[yi * w + xi] = v; };
  for (let c = 0; c < count; c++) {
    let x = r() * w, y = r() * h, a = r() * 6.2832;
    const L = len * (0.5 + r());
    for (let i = 0; i < L; i++) {
      a += (r() - 0.5) * 0.7; x += Math.cos(a); y += Math.sin(a);
      plot(x, y, 255);
      if (r() < 0.5) plot(x + 1, y, 128);
      if (i > 12 && r() < 0.012) { // short side branch
        let bx = x, by = y, ba = a + (r() < 0.5 ? 1 : -1) * (0.6 + r() * 0.6);
        for (let k = 0; k < L * 0.25; k++) { ba += (r() - 0.5) * 0.8; bx += Math.cos(ba); by += Math.sin(ba); plot(bx, by, 255); }
      }
    }
  }
  return m;
}
