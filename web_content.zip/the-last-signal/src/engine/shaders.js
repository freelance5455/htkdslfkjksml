// GLSL ES 3.00 sources for the custom renderer. Quality flags compile different variants.
export const VERT_LIT = `#version 300 es
layout(location=0) in vec3 a_pos;
layout(location=1) in vec3 a_nrm;
layout(location=2) in vec2 a_uv;
layout(location=3) in vec4 a_col;
uniform mat4 u_vp;
uniform mat4 u_model;
out vec3 v_wp; out vec3 v_n; out vec2 v_uv; out vec4 v_col;
void main(){
  vec4 wp = u_model * vec4(a_pos, 1.0);
  v_wp = wp.xyz;
  v_n = mat3(u_model) * a_nrm;
  v_uv = a_uv; v_col = a_col;
  gl_Position = u_vp * wp;
}`;

// o: {bump, spec, shadow, decal, maxLights}
export function fragLit(o) {
  return `#version 300 es
precision highp float;
precision highp sampler2D;
${o.shadow ? 'precision highp sampler2DShadow;\n#define SHADOW' : ''}
${o.bump ? '#define BUMP' : ''}
${o.spec ? '#define SPEC' : ''}
${o.decal ? '#define DECAL' : ''}
#define MAXL ${o.maxLights}
in vec3 v_wp; in vec3 v_n; in vec2 v_uv; in vec4 v_col;
uniform sampler2D u_tex;
#ifdef SHADOW
uniform sampler2DShadow u_shadow; uniform mat4 u_shvp;
#endif
uniform vec3 u_cam; uniform vec3 u_amb; uniform vec4 u_fog;
uniform int u_nl; uniform vec4 u_lp[MAXL]; uniform vec4 u_lc[MAXL];
uniform vec4 u_fl;   // flashlight pos.xyz, range
uniform vec4 u_fd;   // flashlight dir.xyz, intensity
uniform vec4 u_fc;   // cos outer, cos inner
uniform vec4 u_mat;  // x bump slope, y specular, z shininess
uniform vec4 u_misc; // x time, y exposure, z decal alpha
out vec4 o_col;

mat3 cotangentFrame(vec3 N, vec3 p, vec2 uv){
  vec3 dp1 = dFdx(p), dp2 = dFdy(p);
  vec2 duv1 = dFdx(uv), duv2 = dFdy(uv);
  vec3 dp2perp = cross(dp2, N), dp1perp = cross(N, dp1);
  vec3 T = dp2perp * duv1.x + dp1perp * duv2.x;
  vec3 B = dp2perp * duv1.y + dp1perp * duv2.y;
  float invmax = inversesqrt(max(dot(T,T), dot(B,B)) + 1e-12);
  return mat3(T * invmax, B * invmax, N);
}
#ifdef SHADOW
float shadowAt(vec3 wp, vec3 N){
  vec4 sc = u_shvp * vec4(wp + N * 0.04, 1.0);
  vec3 p = sc.xyz / sc.w * 0.5 + 0.5;
  if (p.x < 0.0 || p.x > 1.0 || p.y < 0.0 || p.y > 1.0 || p.z > 1.0) return 1.0;
  p.z -= 0.0008;
  return texture(u_shadow, p);
}
#endif
void main(){
  vec3 N = normalize(v_n);
  vec3 toCam = u_cam - v_wp;
  float dist = length(toCam);
  vec3 V = toCam / dist;
  vec4 t0 = texture(u_tex, v_uv);
  float h0 = t0.a;
#ifdef BUMP
  if (u_mat.x > 0.0) {
    vec2 ts = 1.0 / vec2(textureSize(u_tex, 0));
    float hx = texture(u_tex, v_uv + vec2(ts.x, 0.0)).a;
    float hy = texture(u_tex, v_uv + vec2(0.0, ts.y)).a;
    float fade = 1.0 - smoothstep(5.0, 15.0, dist);
    vec2 g = vec2(hx - h0, hy - h0) * u_mat.x * fade;
    N = normalize(cotangentFrame(N, v_wp, v_uv) * vec3(-g, 1.0));
  }
#endif
  vec3 alb = t0.rgb * v_col.rgb;
  alb *= alb;
  vec3 diff = u_amb * v_col.a;
  vec3 spec = vec3(0.0);
  for (int i = 0; i < MAXL; i++) {
    if (i >= u_nl) break;
    vec3 L = u_lp[i].xyz - v_wp;
    float d2 = dot(L, L), r = u_lp[i].w;
    if (d2 > r * r) continue;
    float d = sqrt(d2); L /= d;
    float att = 1.0 - d / r; att *= att;
    float ndl = dot(N, L);
    vec3 lc = u_lc[i].rgb * att;
    diff += lc * max(ndl * 0.85 + 0.15, 0.0);
#ifdef SPEC
    spec += lc * pow(max(dot(N, normalize(L + V)), 0.0), u_mat.z) * step(0.0, ndl);
#endif
  }
  // flashlight (spot cone)
  vec3 FL = u_fl.xyz - v_wp;
  float fd = length(FL);
  vec3 FLn = FL / fd;
  float spot = smoothstep(u_fc.x, u_fc.y, dot(-FLn, u_fd.xyz));
  spot = spot * spot * (1.2 - 0.2 * spot);
  if (spot > 0.0 && u_fd.w > 0.0) {
    float fatt = clamp(1.0 - fd / u_fl.w, 0.0, 1.0);
    fatt = fatt * fatt * (1.0 + 1.6 / (1.0 + fd * 0.45));
    float ndl = max(dot(N, FLn), 0.0);
    float sh = 1.0;
#ifdef SHADOW
    sh = shadowAt(v_wp, v_n);
#endif
    vec3 fcol = vec3(1.0, 0.92, 0.78) * 2.3 * u_fd.w * spot * fatt * sh;
    diff += fcol * ndl;
#ifdef SPEC
    spec += fcol * pow(max(dot(N, normalize(FLn + V)), 0.0), u_mat.z) * step(0.0, ndl);
#endif
  }
  vec3 col = alb * diff;
#ifdef SPEC
  col += spec * u_mat.y * mix(0.35, 1.0, h0);
#endif
  float fogF = 1.0 - exp(-(u_fog.a * dist) * (u_fog.a * dist));
  col = mix(col, u_fog.rgb, fogF);
  col *= u_misc.y;
  col = col / (1.0 + col * 0.45);
  col = sqrt(col);
#ifdef DECAL
  o_col = vec4(col, t0.a * u_misc.z);
#else
  o_col = vec4(col, 1.0);
#endif
}`;
}

export const FRAG_EMIS = `#version 300 es
precision highp float;
precision highp sampler2D;
in vec3 v_wp; in vec3 v_n; in vec2 v_uv; in vec4 v_col;
uniform sampler2D u_tex; uniform vec3 u_cam; uniform vec4 u_fog; uniform vec4 u_mat; uniform vec4 u_misc; uniform vec3 u_tint;
out vec4 o_col;
void main(){
  vec4 t = texture(u_tex, v_uv);
  vec3 c = t.rgb * t.rgb * v_col.rgb * v_col.rgb * u_mat.w * u_tint;
  float dist = length(u_cam - v_wp);
  float fogF = 1.0 - exp(-(u_fog.a * dist) * (u_fog.a * dist));
  c = mix(c, u_fog.rgb, fogF);
  c *= u_misc.y;
  c = c / (1.0 + c * 0.45);
  o_col = vec4(sqrt(c), 1.0);
}`;

export const VERT_SPR = `#version 300 es
layout(location=0) in vec3 a_pos;
layout(location=1) in vec4 a_col;
layout(location=2) in vec2 a_sk;   // x = world size, y = kind (0 normal, 1 flashlight-lit dust)
uniform mat4 u_vp; uniform float u_psize;
uniform vec4 u_fl; uniform vec4 u_fd; uniform vec4 u_fc;
out vec4 v_c;
void main(){
  vec4 cp = u_vp * vec4(a_pos, 1.0);
  gl_Position = cp;
  gl_PointSize = clamp(a_sk.x * u_psize / max(cp.w, 0.05), 1.0, 64.0);
  vec4 c = a_col;
  if (a_sk.y > 0.5) {
    vec3 d = a_pos - u_fl.xyz; float l = length(d);
    float s = smoothstep(u_fc.x, u_fc.y, dot(d / max(l, 0.001), u_fd.xyz));
    c.a *= s * u_fd.w * (1.0 - clamp(l / u_fl.w, 0.0, 1.0));
  }
  v_c = c;
}`;
export const FRAG_SPR = `#version 300 es
precision highp float;
in vec4 v_c; uniform float u_add; uniform int u_lines;
out vec4 o_col;
void main(){
  float a = 1.0;
  if (u_lines == 0) {
    vec2 p = gl_PointCoord * 2.0 - 1.0;
    float r = dot(p, p);
    if (r > 1.0) discard;
    a = (1.0 - r); a *= a;
  }
  o_col = u_add > 0.5 ? vec4(v_c.rgb * v_c.a * a, 0.0) : vec4(v_c.rgb, v_c.a * a);
}`;

export const VERT_FS = `#version 300 es
out vec2 v_uv;
void main(){
  vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
  v_uv = p;
  gl_Position = vec4(p * 2.0 - 1.0, 0.999, 1.0);
}`;

export const FRAG_SKY = `#version 300 es
precision highp float;
in vec2 v_uv; out vec4 o_col;
uniform vec3 u_cr, u_cu, u_cf; uniform vec2 u_tan; uniform float u_time;
uniform vec3 u_hor, u_zen, u_moon; uniform float u_dawn;
float hash(vec2 p){ p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
float vn(vec2 p){ vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash(i), hash(i + vec2(1,0)), f.x), mix(hash(i + vec2(0,1)), hash(i + vec2(1,1)), f.x), f.y); }
void main(){
  vec2 ndc = v_uv * 2.0 - 1.0;
  vec3 rd = normalize(u_cr * ndc.x * u_tan.x + u_cu * ndc.y * u_tan.y + u_cf);
  float h = clamp(rd.y, 0.0, 1.0);
  vec3 col = mix(u_hor, u_zen, pow(h, 0.55));
  float md = dot(rd, u_moon);
  col += vec3(0.55, 0.62, 0.75) * smoothstep(0.9995, 0.9999, md) * (1.0 - u_dawn);
  col += vec3(0.10, 0.13, 0.20) * pow(max(md, 0.0), 40.0) * (1.0 - u_dawn);
  vec2 sp = rd.xz / (rd.y + 0.2);
  vec2 sg = rd.xz / (rd.y + 0.45) * 70.0; vec2 sid = floor(sg), sf = fract(sg) - 0.5;
  float st = step(0.985, hash(sid)) * smoothstep(0.26, 0.0, length(sf - (vec2(hash(sid + 3.1), hash(sid + 7.7)) - 0.5) * 0.4)) * smoothstep(0.1, 0.5, h) * (1.0 - u_dawn);
  col += vec3(0.8, 0.85, 1.0) * st * (0.4 + 0.6 * hash(sid + 1.7));
  vec2 cp = sp * 0.9 + vec2(u_time * 0.012, 0.0);
  float cl = vn(cp * 2.0) * 0.55 + vn(cp * 4.3) * 0.3 + vn(cp * 9.0) * 0.15;
  cl = smoothstep(0.45, 0.85, cl) * smoothstep(0.0, 0.25, h);
  col = mix(col, u_hor * 0.7 + 0.03, cl * 0.75);
  o_col = vec4(col, 1.0);
}`;

export const FRAG_POST = `#version 300 es
precision highp float;
precision highp sampler2D;
in vec2 v_uv; out vec4 o_col;
uniform sampler2D u_scene; uniform sampler2D u_depth;
uniform vec4 u_p0;   // time, vignette, grain, chroma
uniform vec4 u_p1;   // damage, static, fade, glitch
uniform vec4 u_p2;   // desaturate, 1/gamma, white flash, ray strength
uniform vec4 u_res;  // 1/w, 1/h, w, h
uniform vec4 u_fl, u_fd, u_fc;
uniform vec3 u_cr, u_cu, u_cf;
uniform vec4 u_cam;  // tanHalfX, tanHalfY, near, far
float hash(vec2 p){ p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
void main(){
  vec2 uv = v_uv;
  float t = u_p0.x;
  if (u_p1.w > 0.0) {
    float tick = floor(t * 14.0);
    float band = floor(uv.y * 28.0 + tick);
    if (hash(vec2(band, tick)) > 1.0 - u_p1.w * 0.55) uv.x += (hash(vec2(band, 7.0)) - 0.5) * 0.12 * u_p1.w;
  }
  vec2 dir = uv - 0.5;
  float ca = u_p0.w * (dot(dir, dir) * 2.0 + 0.25);
  vec3 col;
  if (ca > 0.0004) col = vec3(texture(u_scene, uv + dir * ca).r, texture(u_scene, uv).g, texture(u_scene, uv - dir * ca).b);
  else col = texture(u_scene, uv).rgb;
  if (u_p2.w > 0.0 && u_fd.w > 0.0) {
    float d = texture(u_depth, uv).r;
    float zn = d * 2.0 - 1.0;
    float zlin = 2.0 * u_cam.z * u_cam.w / (u_cam.w + u_cam.z - zn * (u_cam.w - u_cam.z));
    vec2 ndc = uv * 2.0 - 1.0;
    vec3 rd = normalize(u_cr * ndc.x * u_cam.x + u_cu * ndc.y * u_cam.y + u_cf);
    float td = min(zlin / max(dot(rd, u_cf), 0.2), u_fl.w);
    float cone = smoothstep(u_fc.x, u_fc.y, dot(rd, u_fd.xyz));
    float sc = cone * cone * (1.0 - exp(-td * 0.15)) * 0.5;
    col += vec3(1.0, 0.92, 0.78) * sc * u_fd.w * u_p2.w * (0.93 + 0.14 * hash(floor(uv * u_res.zw * 0.35) + floor(t * 9.0)));
  }
  float lum = dot(col, vec3(0.299, 0.587, 0.114));
  col = mix(col, vec3(lum), u_p2.x);
  float rad = length(dir);
  col = mix(col, vec3(0.5, 0.0, 0.02) * (0.7 + 0.3 * sin(t * 8.0)), u_p1.x * smoothstep(0.2, 0.75, rad) * 0.9);
  if (u_p1.y > 0.0) {
    float n = hash(uv * u_res.zw + fract(t) * 91.7);
    float ln = step(0.985, hash(vec2(floor(uv.y * u_res.w * 0.5), floor(t * 30.0))));
    col = mix(col, vec3(n * 0.8), clamp(u_p1.y * 0.85 + ln * u_p1.y * 0.5, 0.0, 1.0) * 0.9);
  }
  col *= 1.0 - smoothstep(0.30, 0.78, rad) * u_p0.y;
  col += (hash(uv * u_res.zw + fract(t) * 17.0) - 0.5) * u_p0.z;
  col = pow(max(col, 0.0), vec3(u_p2.y));
  col = mix(col, vec3(1.0), u_p2.z);
  col *= 1.0 - u_p1.z;
  o_col = vec4(col, 1.0);
}`;

export const VERT_DEPTH = `#version 300 es
layout(location=0) in vec3 a_pos;
uniform mat4 u_vp; uniform mat4 u_model;
void main(){ gl_Position = u_vp * (u_model * vec4(a_pos, 1.0)); }`;
export const FRAG_DEPTH = `#version 300 es
precision mediump float;
layout(location=0) out vec4 o_col;
void main(){ o_col = vec4(0.0); }`;
