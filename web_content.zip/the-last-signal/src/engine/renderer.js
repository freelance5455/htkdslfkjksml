// WebGL2 renderer: scene FBO (color + depth texture) -> post pass. Handles context loss by re-uploading CPU copies.
import { m4, frustumPlanes } from './math.js';
import { VERT_LIT, fragLit, FRAG_EMIS, VERT_SPR, FRAG_SPR, VERT_FS, FRAG_SKY, FRAG_POST, VERT_DEPTH, FRAG_DEPTH } from './shaders.js';
import { STRIDE } from './mesh.js';

export const QUALITY = {
  low: { maxPixels: 0.36e6, dprCap: 1, lights: 3, bump: false, spec: false, shadow: 0, rays: false, grain: 0.035, chroma: 0, particles: 0.35, texSize: 128 },
  medium: { maxPixels: 0.72e6, dprCap: 1.25, lights: 4, bump: true, spec: false, shadow: 0, rays: true, grain: 0.05, chroma: 0.004, particles: 0.7, texSize: 256 },
  high: { maxPixels: 1.3e6, dprCap: 1.5, lights: 6, bump: true, spec: true, shadow: 1024, rays: true, grain: 0.06, chroma: 0.006, particles: 1, texSize: 256 },
};
const MAXL_ALLOC = 8;

function compile(gl, type, src) {
  const s = gl.createShader(type);
  gl.shaderSource(s, src); gl.compileShader(s);
  if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) {
    const log = gl.getShaderInfoLog(s);
    throw new Error('Shader compile error: ' + log + '\n' + src.split('\n').map((l, i) => (i + 1) + ': ' + l).slice(0, 400).join('\n'));
  }
  return s;
}
function makeProgram(gl, vs, fs) {
  const p = gl.createProgram();
  gl.attachShader(p, compile(gl, gl.VERTEX_SHADER, vs));
  gl.attachShader(p, compile(gl, gl.FRAGMENT_SHADER, fs));
  gl.linkProgram(p);
  if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error('Program link error: ' + gl.getProgramInfoLog(p));
  const u = {}, n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
  for (let i = 0; i < n; i++) { const info = gl.getActiveUniform(p, i); u[info.name.replace(/\[0\]$/, '')] = gl.getUniformLocation(p, info.name); }
  return { p, u, frame: -1 };
}

export class Renderer {
  constructor(canvas, opts = {}) {
    this.canvas = canvas;
    const gl = canvas.getContext('webgl2', { alpha: false, antialias: false, depth: false, stencil: false, powerPreference: 'high-performance', preserveDrawingBuffer: !!opts.preserve });
    if (!gl) throw new Error('WebGL2 is not available in this browser.');
    this.gl = gl;
    this.res = [];
    this.aniso = gl.getExtension('EXT_texture_filter_anisotropic');
    this.maxAniso = this.aniso ? gl.getParameter(this.aniso.MAX_TEXTURE_MAX_ANISOTROPY_EXT) : 1;
    this.P = m4.create(); this.V = m4.create(); this.VP = m4.create(); this.R = m4.create(); this.ident = m4.create();
    this.planes = new Float32Array(24);
    this.lp = new Float32Array(MAXL_ALLOC * 4); this.lc = new Float32Array(MAXL_ALLOC * 4);
    this.nl = 0; this.frameId = 0; this.lost = false;
    this.stats = { draws: 0, tris: 0, shadowDraws: 0, last: { draws: 0, tris: 0, shadowDraws: 0 } };   // per-frame counters (last = previous frame)
    this.F = { amb: [0.02, 0.02, 0.03], fog: [0.01, 0.012, 0.015, 0.05], time: 0, exposure: 1, fl: [0, 0, 0, 20], fd: [0, 0, -1, 0], fc: [0.9, 0.95], cam: [0, 0, 0] };
    this.emptyVao = gl.createVertexArray();
    this.q = QUALITY[opts.quality || 'medium'];
    this.qname = opts.quality || 'medium';
    this.sw = 2; this.sh = 2;
    this.onLost = null; this.onRestored = null;
    canvas.addEventListener('webglcontextlost', (e) => { e.preventDefault(); this.lost = true; if (this.onLost) this.onLost(); });
    canvas.addEventListener('webglcontextrestored', () => { this.lost = false; this.restore(); if (this.onRestored) this.onRestored(); });
    this.buildPrograms();
    this.sprVao = null; this.sprBuf = null; this.sprCap = 0;
    this.buildTargets();
  }

  setQuality(name) { this.qname = name; this.q = QUALITY[name]; this.buildPrograms(); this.buildTargets(); }

  buildPrograms() {
    const gl = this.gl, q = this.q;
    const lit = (decal) => makeProgram(gl, VERT_LIT, fragLit({ bump: q.bump && !decal, spec: q.spec && !decal, shadow: !!q.shadow && !decal, decal, maxLights: q.lights }));
    this.pLit = lit(false); this.pDecal = lit(true);
    this.pEmis = makeProgram(gl, VERT_LIT, FRAG_EMIS);
    this.pSpr = makeProgram(gl, VERT_SPR, FRAG_SPR);
    this.pSky = makeProgram(gl, VERT_FS, FRAG_SKY);
    this.pPost = makeProgram(gl, VERT_FS, FRAG_POST);
    this.pDepth = q.shadow ? makeProgram(gl, VERT_DEPTH, FRAG_DEPTH) : null;
    this.lpv = this.lp.subarray(0, q.lights * 4); this.lcv = this.lc.subarray(0, q.lights * 4); // exact-size views for uniform upload
  }

  // (re)create scene + shadow targets
  buildTargets() {
    const gl = this.gl;
    for (const k of ['sceneFbo', 'sceneTex', 'depthTex', 'shFbo', 'shTex']) { const o = this[k]; if (o) { if (k.endsWith('Fbo')) gl.deleteFramebuffer(o); else gl.deleteTexture(o); this[k] = null; } }
    const w = this.sw, h = this.sh;
    this.sceneTex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, this.sceneTex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA8, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    for (const [k, v] of [[gl.TEXTURE_MIN_FILTER, gl.LINEAR], [gl.TEXTURE_MAG_FILTER, gl.LINEAR], [gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE], [gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE]]) gl.texParameteri(gl.TEXTURE_2D, k, v);
    this.depthTex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, this.depthTex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.DEPTH_COMPONENT24, w, h, 0, gl.DEPTH_COMPONENT, gl.UNSIGNED_INT, null);
    for (const [k, v] of [[gl.TEXTURE_MIN_FILTER, gl.NEAREST], [gl.TEXTURE_MAG_FILTER, gl.NEAREST], [gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE], [gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE]]) gl.texParameteri(gl.TEXTURE_2D, k, v);
    this.sceneFbo = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.sceneFbo);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, this.sceneTex, 0);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.TEXTURE_2D, this.depthTex, 0);
    if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) throw new Error('Scene framebuffer incomplete');
    if (this.q.shadow) {
      const S = this.q.shadow;
      this.shTex = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, this.shTex);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.DEPTH_COMPONENT24, S, S, 0, gl.DEPTH_COMPONENT, gl.UNSIGNED_INT, null);
      for (const [k, v] of [[gl.TEXTURE_MIN_FILTER, gl.LINEAR], [gl.TEXTURE_MAG_FILTER, gl.LINEAR], [gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE], [gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE], [gl.TEXTURE_COMPARE_MODE, gl.COMPARE_REF_TO_TEXTURE], [gl.TEXTURE_COMPARE_FUNC, gl.LEQUAL]]) gl.texParameteri(gl.TEXTURE_2D, k, v);
      this.shFbo = gl.createFramebuffer();
      gl.bindFramebuffer(gl.FRAMEBUFFER, this.shFbo);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.TEXTURE_2D, this.shTex, 0);
      gl.drawBuffers([gl.NONE]); gl.readBuffer(gl.NONE);
      if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) { this.q = { ...this.q, shadow: 0 }; this.buildPrograms(); }
      this.shVP = m4.create();
    }
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  }

  // size the drawing buffer from CSS size according to the quality pixel budget
  resize(cssW, cssH, dpr = 1) {
    const q = this.q;
    let scale = Math.min(dpr, q.dprCap, Math.sqrt(q.maxPixels / Math.max(1, cssW * cssH)));
    scale = Math.max(0.3, scale);
    const w = Math.max(2, Math.round(cssW * scale)), h = Math.max(2, Math.round(cssH * scale));
    if (w === this.sw && h === this.sh && this.canvas.width === w) return;
    this.sw = w; this.sh = h; this.canvas.width = w; this.canvas.height = h;
    this.buildTargets();
  }

  // ---- resources ----
  createTexture(src) { const t = { src, h: null }; this.res.push(t); this._tex(t); return t; }
  _tex(t) {
    const gl = this.gl, s = t.src, h = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, h);
    if (s.canvas) gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA8, gl.RGBA, gl.UNSIGNED_BYTE, s.canvas);
    else gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA8, s.w, s.h, 0, gl.RGBA, gl.UNSIGNED_BYTE, s.data);
    gl.generateMipmap(gl.TEXTURE_2D);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, s.wrapS === 'clamp' ? gl.CLAMP_TO_EDGE : gl.REPEAT);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, s.wrapT === 'clamp' ? gl.CLAMP_TO_EDGE : gl.REPEAT);
    if (this.aniso) gl.texParameterf(gl.TEXTURE_2D, this.aniso.TEXTURE_MAX_ANISOTROPY_EXT, Math.min(this.maxAniso, this.qname === 'low' ? 1 : 4));
    t.h = h;
  }
  createMesh(fin) { const m = { src: fin, count: fin.indices.length, bounds: fin.bounds, vao: null }; this.res.push(m); this._mesh(m); return m; }
  _mesh(m) {
    const gl = this.gl, f = m.src;
    m.vao = gl.createVertexArray(); gl.bindVertexArray(m.vao);
    const vbo = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, vbo); gl.bufferData(gl.ARRAY_BUFFER, f.buffer, gl.STATIC_DRAW);
    gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 3, gl.FLOAT, false, STRIDE, 0);
    gl.enableVertexAttribArray(1); gl.vertexAttribPointer(1, 3, gl.FLOAT, false, STRIDE, 12);
    gl.enableVertexAttribArray(2); gl.vertexAttribPointer(2, 2, gl.FLOAT, false, STRIDE, 24);
    gl.enableVertexAttribArray(3); gl.vertexAttribPointer(3, 4, gl.UNSIGNED_BYTE, true, STRIDE, 32);
    const ibo = gl.createBuffer(); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ibo); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, f.indices, gl.STATIC_DRAW);
    gl.bindVertexArray(null);
    m.vbo = vbo; m.ibo = ibo;
  }
  restore() {
    this.buildPrograms(); this.emptyVao = this.gl.createVertexArray(); this.sprVao = null; this.sprCap = 0;
    this.buildTargets();
    for (const r of this.res) { if (r.vao !== undefined) this._mesh(r); else this._tex(r); }
  }

  // ---- per frame ----
  // cam: {x,y,z,yaw,pitch,roll,fov,near,far}   frame: lighting/fog state (see main render)
  begin(cam, frame) {
    const gl = this.gl;
    this.frameId++;
    { const st = this.stats, l = st.last; l.draws = st.draws; l.tris = st.tris; l.shadowDraws = st.shadowDraws; st.draws = st.tris = st.shadowDraws = 0; }
    Object.assign(this.F, frame);
    this.cam = cam;
    const aspect = this.sw / this.sh;
    m4.perspective(this.P, cam.fov, aspect, cam.near, cam.far);
    const cp = Math.cos(cam.pitch), fx = Math.sin(cam.yaw) * cp, fy = Math.sin(cam.pitch), fz = -Math.cos(cam.yaw) * cp;
    m4.lookAt(this.V, cam.x, cam.y, cam.z, cam.x + fx, cam.y + fy, cam.z + fz);
    if (cam.roll) m4.mul(this.V, m4.rotZ(this.R, cam.roll), this.V);
    m4.mul(this.VP, this.P, this.V);
    frustumPlanes(this.planes, this.VP);
    const yaw = cam.yaw, rx = Math.cos(yaw), rz = Math.sin(yaw);
    this.fwd = [fx, fy, fz]; this.right = [rx, 0, rz];
    this.up = [-rz * fy, rz * fx - rx * fz, rx * fy]; // right x forward
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.sceneFbo);
    gl.viewport(0, 0, this.sw, this.sh);
    gl.depthMask(true); gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LEQUAL); gl.disable(gl.BLEND);
    gl.enable(gl.CULL_FACE); gl.cullFace(gl.BACK);
    const fc = this.F.fog;
    gl.clearColor(Math.sqrt(fc[0]), Math.sqrt(fc[1]), Math.sqrt(fc[2]), 1);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    if (frame.sky) this.drawSky(frame.sky);
  }
  tanHalf() { const t = Math.tan(this.cam.fov / 2); return [t * (this.sw / this.sh), t]; }
  drawSky(s) {
    const gl = this.gl, p = this.pSky, th = this.tanHalf();
    gl.useProgram(p.p); gl.disable(gl.DEPTH_TEST); gl.depthMask(false); gl.disable(gl.CULL_FACE);
    gl.uniform3fv(p.u.u_cr, this.right); gl.uniform3fv(p.u.u_cu, this.up); gl.uniform3fv(p.u.u_cf, this.fwd);
    gl.uniform2f(p.u.u_tan, th[0], th[1]); gl.uniform1f(p.u.u_time, this.F.time);
    gl.uniform3fv(p.u.u_hor, s.hor); gl.uniform3fv(p.u.u_zen, s.zen); gl.uniform3fv(p.u.u_moon, s.moon); gl.uniform1f(p.u.u_dawn, s.dawn || 0);
    gl.bindVertexArray(this.emptyVao); gl.drawArrays(gl.TRIANGLES, 0, 3);
    gl.enable(gl.DEPTH_TEST); gl.depthMask(true); gl.enable(gl.CULL_FACE);
  }
  _bind(p) {
    const gl = this.gl, u = p.u, F = this.F;
    gl.useProgram(p.p);
    if (p.frame === this.frameId) return;
    p.frame = this.frameId;
    if (u.u_vp) gl.uniformMatrix4fv(u.u_vp, false, this.VP);
    if (u.u_cam) gl.uniform3f(u.u_cam, this.cam.x, this.cam.y, this.cam.z);
    if (u.u_amb) gl.uniform3fv(u.u_amb, F.amb);
    if (u.u_fog) gl.uniform4fv(u.u_fog, F.fog);
    if (u.u_fl) { gl.uniform4fv(u.u_fl, F.fl); gl.uniform4fv(u.u_fd, F.fd); gl.uniform4f(u.u_fc, F.fc[0], F.fc[1], 0, 0); }
    if (u.u_misc) gl.uniform4f(u.u_misc, F.time, F.exposure, 1, 0);
    if (u.u_shvp && this.shVP) { gl.uniformMatrix4fv(u.u_shvp, false, this.shVP); gl.activeTexture(gl.TEXTURE2); gl.bindTexture(gl.TEXTURE_2D, this.shTex); gl.uniform1i(u.u_shadow, 2); gl.activeTexture(gl.TEXTURE0); }
    if (u.u_tex) gl.uniform1i(u.u_tex, 0);
    if (u.u_model) gl.uniformMatrix4fv(u.u_model, false, this.ident);
  }
  // set the active point lights (arrays of x,y,z,radius / r,g,b,0)
  setLights(n, lp, lc) {
    const q = Math.min(n, this.q.lights);
    this.nl = q;
    for (let i = 0; i < q * 4; i++) { this.lp[i] = lp[i]; this.lc[i] = lc[i]; }
  }
  // kind: 'lit' | 'decal' | 'emis'
  drawMesh(mesh, mat, kind = 'lit', model = null, alpha = 1, tint = null) {
    const gl = this.gl, p = kind === 'lit' ? this.pLit : kind === 'decal' ? this.pDecal : this.pEmis, u = p.u;
    this._bind(p);
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, mat.tex.h);
    gl.uniformMatrix4fv(u.u_model, false, model || this.ident);
    if (kind === 'emis') { gl.uniform4f(u.u_mat, 0, 0, 0, mat.emis ?? 1); gl.uniform3f(u.u_tint, tint ? tint[0] : 1, tint ? tint[1] : 1, tint ? tint[2] : 1); }
    else {
      gl.uniform4f(u.u_mat, mat.bump || 0, mat.spec || 0, mat.shin || 16, 0);
      gl.uniform1i(u.u_nl, this.nl); gl.uniform4fv(u.u_lp, this.lpv); gl.uniform4fv(u.u_lc, this.lcv);
    }
    if (kind === 'decal') gl.uniform4f(u.u_misc, this.F.time, this.F.exposure, alpha, 0);
    gl.bindVertexArray(mesh.vao);
    gl.drawElements(gl.TRIANGLES, mesh.count, gl.UNSIGNED_INT, 0); this.stats.draws++; this.stats.tris += mesh.count / 3;
  }
  blend(mode) { // 'alpha' | 'add' | 'off'
    const gl = this.gl;
    if (mode === 'off') { gl.disable(gl.BLEND); gl.depthMask(true); return; }
    gl.enable(gl.BLEND); gl.depthMask(false);
    if (mode === 'add') gl.blendFunc(gl.ONE, gl.ONE); else gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
  }
  polyOffset(on) { const gl = this.gl; if (on) { gl.enable(gl.POLYGON_OFFSET_FILL); gl.polygonOffset(-1, -2); } else gl.disable(gl.POLYGON_OFFSET_FILL); }

  // data: Float32Array of [x,y,z, r,g,b,a, size, kind] * count ; lines: 2 vertices per segment
  drawSprites(data, count, additive, lines = false) {
    if (count <= 0) return;
    const gl = this.gl, p = this.pSpr, F = this.F;
    if (!this.sprVao || this.sprCap < count * (lines ? 2 : 1)) {
      this.sprCap = Math.max(512, (count * 2) | 0);
      this.sprVao = gl.createVertexArray(); gl.bindVertexArray(this.sprVao);
      this.sprBuf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, this.sprBuf);
      gl.bufferData(gl.ARRAY_BUFFER, this.sprCap * 36, gl.DYNAMIC_DRAW);
      gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 36, 0);
      gl.enableVertexAttribArray(1); gl.vertexAttribPointer(1, 4, gl.FLOAT, false, 36, 12);
      gl.enableVertexAttribArray(2); gl.vertexAttribPointer(2, 2, gl.FLOAT, false, 36, 28);
    }
    gl.useProgram(p.p);
    gl.uniformMatrix4fv(p.u.u_vp, false, this.VP);
    gl.uniform1f(p.u.u_psize, this.sh * this.P[5] * 0.5);
    gl.uniform4fv(p.u.u_fl, F.fl); gl.uniform4fv(p.u.u_fd, F.fd); gl.uniform4f(p.u.u_fc, F.fc[0], F.fc[1], 0, 0);
    gl.uniform1f(p.u.u_add, additive ? 1 : 0); gl.uniform1i(p.u.u_lines, lines ? 1 : 0);
    gl.bindVertexArray(this.sprVao); gl.bindBuffer(gl.ARRAY_BUFFER, this.sprBuf);
    const n = lines ? count * 2 : count;
    gl.bufferSubData(gl.ARRAY_BUFFER, 0, data, 0, n * 9);
    this.blend(additive ? 'add' : 'alpha');
    gl.drawArrays(lines ? gl.LINES : gl.POINTS, 0, n); this.stats.draws++;
    this.blend('off');
  }

  // ---- flashlight shadow map (high quality only) ----
  beginShadow(px, py, pz, dx, dy, dz, fov, range) {
    if (!this.shFbo) return false;
    const gl = this.gl, P = m4.create(), V = m4.create();
    m4.perspective(P, fov, 1, 0.15, range);
    const up = Math.abs(dy) > 0.95;
    m4.lookAt(V, px, py, pz, px + dx, py + dy, pz + dz);
    if (up) return false;
    m4.mul(this.shVP, P, V);
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.shFbo);
    gl.viewport(0, 0, this.q.shadow, this.q.shadow);
    gl.clear(gl.DEPTH_BUFFER_BIT);
    gl.colorMask(false, false, false, false);
    gl.enable(gl.POLYGON_OFFSET_FILL); gl.polygonOffset(2, 4);
    gl.useProgram(this.pDepth.p);
    gl.uniformMatrix4fv(this.pDepth.u.u_vp, false, this.shVP);
    gl.uniformMatrix4fv(this.pDepth.u.u_model, false, this.ident);
    return true;
  }
  drawDepth(mesh, model) {
    const gl = this.gl;
    gl.uniformMatrix4fv(this.pDepth.u.u_model, false, model || this.ident);
    gl.bindVertexArray(mesh.vao); gl.drawElements(gl.TRIANGLES, mesh.count, gl.UNSIGNED_INT, 0); this.stats.shadowDraws++;
  }
  endShadow() {
    const gl = this.gl;
    gl.colorMask(true, true, true, true); gl.disable(gl.POLYGON_OFFSET_FILL);
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.sceneFbo); gl.viewport(0, 0, this.sw, this.sh);
  }

  // post-process to the canvas. fx: {vig, grain, chroma, damage, stat, fade, glitch, desat, gamma, flash, rays}
  end(fx) {
    const gl = this.gl, p = this.pPost, u = p.u, F = this.F, th = this.tanHalf();
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.viewport(0, 0, this.sw, this.sh);
    gl.disable(gl.DEPTH_TEST); gl.disable(gl.CULL_FACE); gl.disable(gl.BLEND); gl.depthMask(false);
    gl.useProgram(p.p);
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, this.sceneTex); gl.uniform1i(u.u_scene, 0);
    gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, this.depthTex); gl.uniform1i(u.u_depth, 1);
    gl.activeTexture(gl.TEXTURE0);
    gl.uniform4f(u.u_p0, F.time, fx.vig ?? 0.6, fx.grain ?? this.q.grain, fx.chroma ?? this.q.chroma);
    gl.uniform4f(u.u_p1, fx.damage || 0, fx.stat || 0, fx.fade || 0, fx.glitch || 0);
    gl.uniform4f(u.u_p2, fx.desat || 0, 1 / (fx.gamma || 1), fx.flash || 0, this.q.rays ? (fx.rays ?? 1) : 0);
    gl.uniform4f(u.u_res, 1 / this.sw, 1 / this.sh, this.sw, this.sh);
    gl.uniform4fv(u.u_fl, F.fl); gl.uniform4fv(u.u_fd, F.fd); gl.uniform4f(u.u_fc, F.fc[0], F.fc[1], 0, 0);
    gl.uniform3fv(u.u_cr, this.right); gl.uniform3fv(u.u_cu, this.up); gl.uniform3fv(u.u_cf, this.fwd);
    gl.uniform4f(u.u_cam, th[0], th[1], this.cam.near, this.cam.far);
    gl.bindVertexArray(this.emptyVao); gl.drawArrays(gl.TRIANGLES, 0, 3);
  }
}
