// Build script: bundles src/main.js + CSS + UI fragments into ONE self-contained dist/index.html
// Usage: node build.mjs [--dev]     (needs esbuild: `npm install`, or a global/local esbuild)
import { createRequire } from 'node:module';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';

const root = path.dirname(fileURLToPath(import.meta.url));
const require = createRequire(import.meta.url);
let esbuild = null;
for (const p of ['esbuild', '/opt/npm-tools/node_modules/esbuild']) {
  try { esbuild = require(p); break; } catch { /* try next */ }
}
if (!esbuild) {
  console.error('esbuild not found. Run `npm install` in this folder first.');
  process.exit(1);
}

const dev = process.argv.includes('--dev');
const read = (f) => fs.readFileSync(path.join(root, f), 'utf8');
const readDir = (dir, ext) =>
  fs.readdirSync(path.join(root, dir)).filter((f) => f.endsWith(ext)).sort()
    .map((f) => read(path.join(dir, f))).join('\n');

const result = await esbuild.build({
  entryPoints: [path.join(root, 'src/main.js')],
  bundle: true,
  write: false,
  format: 'iife',
  minify: !dev,
  target: ['chrome84'],
  legalComments: 'none',
  logLevel: 'warning',
});
const js = result.outputFiles[0].text.replace(/<\/script/gi, '<\\/script');
const css = readDir('src/css', '.css');
const ui = readDir('src/ui', '.html');
const html = read('src/index.template.html')
  .replace('/*__CSS__*/', () => css)
  .replace('<!--__UI__-->', () => ui)
  .replace('/*__JS__*/', () => js);

fs.mkdirSync(path.join(root, 'dist'), { recursive: true });
fs.writeFileSync(path.join(root, 'dist/index.html'), html);
// PWA files next to the game: manifest, icons, service worker (its cache version = hash of index.html, so a new build refreshes installed copies)
const version = crypto.createHash('sha1').update(html).digest('hex').slice(0, 10);
for (const f of fs.readdirSync(path.join(root, 'src/pwa'))) {
  const buf = fs.readFileSync(path.join(root, 'src/pwa', f));
  fs.writeFileSync(path.join(root, 'dist', f), f === 'sw.js' ? buf.toString('utf8').replace(/__VERSION__/g, version) : buf);
}
const kb = (n) => (n / 1024).toFixed(1) + ' KB';
console.log(`built dist/index.html  total ${kb(html.length)}  (js ${kb(js.length)}, css ${kb(css.length)}, ui ${kb(ui.length)})${dev ? '  [dev]' : ''}  + PWA files (sw cache tls-${version})`);
