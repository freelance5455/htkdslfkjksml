<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#090707"><title>VENOM STREAMING</title><link rel="manifest" href="manifest.webmanifest"><link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"><style>
:root{--bg:#090707;--panel:#171111;--gold:#f5c95c;--red:#e51b2b;--muted:#b7abab;--line:rgba(245,201,92,.22)}*{box-sizing:border-box;margin:0;padding:0}html{scroll-behavior:smooth;scroll-padding-top:85px}body{font-family:Inter,Arial,sans-serif;background:radial-gradient(ellipse at 80% 10%,#321013 0,transparent 34%),linear-gradient(180deg,#0b0808,#050505 70%);color:#fff;line-height:1.5;min-height:100vh}a{color:inherit;text-decoration:none}button,input,textarea,select{font:inherit}button{cursor:pointer}.wrap{width:min(1160px,92%);margin:auto}.header{position:sticky;top:0;z-index:50;background:#080606ed;backdrop-filter:blur(16px);border-bottom:1px solid #f5c95c20}.nav{min-height:76px;display:flex;align-items:center;justify-content:space-between;gap:18px}.brand{display:flex;align-items:center;gap:10px;font-size:25px;font-weight:900;letter-spacing:2px}.brand-mark{width:35px;height:35px;border:2px solid var(--gold);border-radius:50%;display:grid;place-items:center;color:var(--gold)}.brand small{display:block;color:var(--gold);font-size:9px;letter-spacing:5px}.nav-links{display:flex;align-items:center;gap:28px;font-size:14px;font-weight:700}.nav-links a:hover{color:var(--gold)}.admin-btn,.menu-toggle{width:43px;height:43px;border-radius:50%;border:1px solid var(--line);background:#1b1515;color:var(--gold);font-size:20px}.menu-toggle{display:none;border-radius:12px}.hero{padding:65px 0;min-height:440px;background:linear-gradient(90deg,#090707 0%,#090707dd 45%,#09070766),url('https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?auto=format&fit=crop&w=1600&q=85') center/cover}.hero-grid{display:grid;grid-template-columns:1fr .8fr;gap:30px;align-items:center}.eyebrow,.section-label{color:var(--gold);font-size:11px;font-weight:900;letter-spacing:3px;text-transform:uppercase}.hero h1{font-size:clamp(40px,6vw,68px);line-height:1.03;letter-spacing:-2px;margin:18px 0}.hero h1 span{color:var(--gold)}.hero p{max-width:490px;color:#c8bcbc;line-height:1.85;margin-bottom:25px}.btn-primary,.btn-buy{display:inline-flex;align-items:center;justify-content:center;border:0;border-radius:999px;background:linear-gradient(135deg,#ffdf86,#e9ae30);color:#130c04;font-weight:900;padding:14px 25px}.section{padding:60px 0}.section-head{text-align:center;margin-bottom:30px}.section h2{font-size:clamp(26px,3vw,36px);margin:8px 0}.section-sub{color:var(--muted);font-size:14px}.products-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,250px),1fr));gap:20px}.product-card{overflow:hidden;border-radius:20px;background:linear-gradient(145deg,#211616,#100c0c);border:1px solid var(--line);box-shadow:0 20px 45px #0006}.product-image,.product-image-fallback{width:100%;height:210px;object-fit:cover;background:#211616;display:grid;place-items:center}.product-image-fallback{color:var(--gold);font-weight:900;letter-spacing:3px}.product-body{padding:20px}.product-title{font-size:19px;font-weight:800}.product-desc{font-size:13px;color:var(--muted);line-height:1.7;min-height:42px;margin:8px 0 13px;white-space:pre-wrap}.product-price{font-size:27px;font-weight:900;color:var(--gold);margin-bottom:14px}.stock{font-size:11px;color:#a8e9bd;margin-bottom:12px}.btn-buy{width:100%;padding:13px}.empty-state{text-align:center;padding:40px;border:1px dashed var(--line);border-radius:16px;color:var(--muted);grid-column:1/-1}.about{background:#171010;border-block:1px solid #f5c95c18;text-align:center}.about p{max-width:650px;margin:14px auto 22px;color:var(--muted)}footer{padding:28px 0;color:var(--muted);font-size:13px}.footer-inner{display:flex;justify-content:space-between;gap:15px;flex-wrap:wrap}.modal-overlay{position:fixed;inset:0;z-index:1000;display:none;align-items:center;justify-content:center;padding:12px;background:#000d;backdrop-filter:blur(8px)}.modal-overlay.show{display:flex}.modal{width:min(620px,100%);max-height:94vh;overflow:auto;background:#171111;border:1px solid var(--line);border-radius:19px;padding:22px;box-shadow:0 25px 80px #000c}.modal h2{font-size:22px;margin-bottom:5px}.modal-sub{font-size:13px;color:var(--muted);margin-bottom:18px}.form-group{margin:12px 0}.form-group label{display:block;font-size:13px;margin-bottom:6px}.form-group input,.form-group textarea,.form-group select{width:100%;padding:12px;border-radius:9px;border:1px solid #4c3535;background:#0d0909;color:#fff;outline:none}.form-group textarea{min-height:75px}.form-actions{display:flex;gap:9px;flex-wrap:wrap;margin-top:14px}.btn-secondary,.btn-danger{border-radius:9px;padding:11px 14px;font-weight:750;font-size:13px}.btn-secondary{background:#2a1d1d;color:var(--gold);border:1px solid var(--line)}.btn-danger{background:#401518;color:#ffb9b9;border:1px solid #8d292e}.notice{display:none;padding:11px;border-radius:9px;font-size:13px;margin:12px 0}.notice.success,.notice.error{display:block}.notice.success{background:#0c2b1b;color:#8bf0b3}.notice.error{background:#351315;color:#ffb0b0}.tabs{display:flex;gap:7px;overflow:auto;margin:15px 0;padding-bottom:5px}.tab{white-space:nowrap;padding:9px 12px;border:1px solid var(--line);border-radius:9px;background:#0e0a0a;color:#e8d9b1;font-size:12px;font-weight:800}.tab.active{background:#4a2020;color:#fff}.admin-list{display:grid;gap:9px;margin-top:14px}.admin-item{display:flex;align-items:center;gap:10px;background:#0e0a0a;border:1px solid #ffffff12;border-radius:11px;padding:10px}.admin-item img{width:46px;height:46px;object-fit:cover;border-radius:7px}.admin-item-info{flex:1;min-width:0;font-size:12px;overflow-wrap:anywhere}.admin-item-info strong{display:block;font-size:13px}.admin-item-info span{color:var(--gold)}.admin-item-actions{display:flex;gap:5px;flex-wrap:wrap}.admin-item-actions button{padding:7px;font-size:11px}.order-card{background:#0d0909;border:1px solid #ffffff16;border-radius:12px;padding:13px;margin:10px 0;font-size:13px}.order-card strong{color:var(--gold)}.order-card img{max-width:100%;max-height:220px;display:block;margin:10px 0;border-radius:8px}.pix-qr-wrap{background:#fff;border-radius:12px;padding:12px;width:max-content;max-width:100%;margin:14px auto;min-height:220px;display:grid;place-items:center}.pix-code{font-size:11px;overflow-wrap:anywhere;background:#0b0808;padding:12px;border-radius:8px;user-select:all}.pix-actions{display:grid;gap:9px;margin-top:12px}.pix-copy{border:0;border-radius:999px;padding:14px;background:linear-gradient(135deg,#ffdf86,#e9ae30);font-weight:900}.muted{color:var(--muted);font-size:12px}.hidden{display:none!important}@media(max-width:760px){.nav{min-height:65px}.brand{font-size:20px}.menu-toggle{display:block}.nav-links{display:none;position:absolute;top:65px;left:0;right:0;background:#0c0808;padding:15px 4%;flex-direction:column;align-items:stretch}.nav-links.open{display:flex}.nav-links a{padding:10px}.admin-btn{width:100%;border-radius:10px}.hero{padding:45px 0}.hero-grid{grid-template-columns:1fr}.hero h1{font-size:44px}.section{padding:43px 0}.section-head{text-align:left}.footer-inner{flex-direction:column}.modal{padding:17px}.admin-item{align-items:flex-start}.admin-item-actions{flex-direction:column}}

.whatsapp-float{position:fixed;right:16px;bottom:16px;z-index:40;width:54px;height:54px;background:#25d366;color:#fff;border-radius:50%;display:grid;place-items:center;font-size:28px;box-shadow:0 6px 20px rgba(37,211,102,.4);transition:transform .2s;text-decoration:none}
.whatsapp-float:hover{transform:scale(1.08)}
@media(max-width:760px){.whatsapp-float{right:14px;bottom:14px;width:50px;height:50px;font-size:25px}}
</style></head><body>
<header class="header"><div class="wrap nav"><a href="#inicio" class="brand"><span class="brand-mark">V</span><span>VENOM<small>STREAMING</small></span></a><nav class="nav-links" id="navLinks"><a href="#inicio">Início</a><a href="#comprar">Comprar</a><a href="#sobre">Sobre</a><button class="admin-btn" id="openAdmin" aria-label="Painel administrativo">⚙</button></nav><button class="menu-toggle" id="mobileMenu">☰</button></div></header>
<main><section class="hero" id="inicio"><div class="wrap hero-grid"><div><div class="eyebrow">Entre no universo VENOM</div><h1>Seu entretenimento,<br><span>a qualquer hora.</span></h1><p>Confira os produtos disponíveis, escolha o que deseja e receba seu acesso após a confirmação do pagamento.</p><a href="#comprar" class="btn-primary">VER PRODUTOS ↘</a></div><div></div></div></section>
<section class="section" id="comprar"><div class="wrap"><div class="section-head"><div class="section-label">Catálogo</div><h2>Produtos disponíveis</h2><p class="section-sub">Veja os produtos, valores e disponibilidade em estoque.</p></div><div class="products-grid" id="products"><div class="empty-state">Carregando produtos...</div></div></div></section>
<section class="section about" id="sobre"><div class="wrap"><div class="section-label">Quem somos</div><h2>VENOM STREAMING</h2><p>Atendimento direto e uma experiência simples. Após o pagamento e a conferência do comprovante, seu acesso será liberado no aplicativo.</p></div></section></main><footer><div class="wrap footer-inner"><strong>VENOM STREAMING © <span id="year"></span></strong><span>Seus pedidos ficam disponíveis neste dispositivo pelo código do pedido.</span></div></footer>

<div class="modal-overlay" id="loginModal"><div class="modal"><h2>Painel administrativo</h2><p class="modal-sub">Área privada — acesso exclusivo do administrador.</p><div class="notice" id="loginNotice"></div><form id="loginForm"><div class="form-group"><label>Usuário</label><input id="username" value="admin" autocomplete="username" required></div><div class="form-group"><label>Senha</label><input id="password" type="password" autocomplete="current-password" required></div><div class="form-actions"><button class="btn-primary">Entrar</button><button type="button" class="btn-secondary close-modal">Cancelar</button></div></form></div></div>
<div class="modal-overlay" id="adminModal"><div class="modal"><h2>Configurações VENOM</h2><p class="modal-sub">Gerencie produtos, estoque de contas, pedidos e chave Pix.</p><div class="tabs"><button class="tab active" data-tab="orders">Pedidos</button><button class="tab" data-tab="productsAdmin">Produtos</button><button class="tab" data-tab="accounts">Contas</button><button class="tab" data-tab="settings">Configurações</button></div><div class="notice" id="adminNotice"></div>
<div id="tab-orders"><div id="ordersList" class="admin-list"></div></div>
<div id="tab-productsAdmin" class="hidden"><form id="productForm" enctype="multipart/form-data"><input type="hidden" name="id" id="productId"><input type="hidden" name="image_data" id="productImageData"><div class="form-group"><label>Nome do produto (Ex.: Netflix, Prime Video, Spotify)</label><input name="name" id="productName" maxlength="180" required></div><div class="form-group"><label>Preço (R$)</label><input name="price" id="productPrice" inputmode="decimal" placeholder="15,00" required></div><div class="form-group"><label>Descrição</label><textarea name="description" id="productDescription" placeholder="Ex.: Tela 4K UHD · 30 dias de acesso"></textarea></div><div class="form-group"><label>Foto do produto (Galeria do Celular ou Link)</label><div style="display:flex;flex-direction:column;gap:8px"><button type="button" id="triggerGallery" class="btn-secondary" style="width:100%;padding:14px;background:#2a1d1d;border:1px solid var(--gold);color:var(--gold);font-weight:800;border-radius:10px;text-align:center">📷 Escolher Foto da Galeria / Câmera</button><input type="file" name="image" id="productImageInput" accept="image/*" style="display:none"><span id="imageFileStatus" class="muted" style="font-size:12px;text-align:center">Nenhuma foto selecionada da galeria</span></div><div style="margin-top:8px"><input type="url" id="productImageUrl" placeholder="Ou cole o link (URL) da imagem (https://...)" style="width:100%;padding:12px;border-radius:9px;border:1px solid #4c3535;background:#0d0909;color:#fff"></div><div id="productImagePreview" style="margin-top:10px"></div></div><div class="form-actions"><button class="btn-primary" id="saveProduct">Salvar produto</button><button class="btn-secondary" type="button" id="clearProduct">Limpar</button></div></form><div class="admin-list" id="adminProducts"></div></div>
<div id="tab-accounts" class="hidden"><form id="accountForm"><div class="form-group"><label>Qual conta / serviço é?</label><select id="accountProduct"></select><small class="muted" style="display:block;margin-top:4px">Selecione o produto cadastrado acima (ou digite o nome abaixo se ainda não criou na aba Produtos).</small><input id="accountProductCustom" placeholder="Ou digite o nome do serviço (ex.: Netflix, Prime Video...)" style="margin-top:8px"></div><div class="form-group"><label>E-mail / usuário da conta</label><input id="accountEmail" placeholder="conta@email.com" required></div><div class="form-group"><label>Senha da conta</label><input id="accountPassword" placeholder="Senha da conta" required></div><button class="btn-primary">Adicionar conta ao estoque</button></form><p class="muted" style="margin-top:12px">As senhas não aparecem no catálogo. Somente o cliente do pedido liberado poderá ver os dados entregues.</p><div class="admin-list" id="accountsList"></div></div>
<div id="tab-settings" class="hidden"><form id="settingsForm"><div class="form-group"><label>Chave Pix</label><input id="pixKey" required></div><div class="form-group"><label>Nome do recebedor</label><input id="pixName" required></div><div class="form-group"><label>Cidade do recebedor</label><input id="pixCity" required></div><div class="form-group"><label>WhatsApp para contato (somente números)</label><input id="whatsapp"></div><div class="form-group"><label>Nome da loja</label><input id="storeName"></div><hr style="border-color:#ffffff18;margin:18px 0"><div class="form-group"><label>Novo usuário ADM (opcional)</label><input id="newUsername" placeholder="Deixe vazio para manter"></div><div class="form-group"><label>Nova senha ADM (opcional, mínimo 8 caracteres)</label><input id="newPassword" type="password" placeholder="Deixe vazio para manter"></div><button class="btn-primary">Salvar configurações</button></form></div>
<div class="form-actions" style="border-top:1px solid #ffffff18;padding-top:15px"><button class="btn-secondary" id="logoutBtn">Sair do ADM</button><button class="btn-secondary close-modal">Fechar</button></div></div></div>
<div class="modal-overlay" id="pixModal"><div class="modal"><div style="display:flex;justify-content:space-between;align-items:center"><div class="section-label">Pagamento via Pix</div><button class="btn-secondary" id="pixClose">Fechar ✕</button></div><h2 id="pixTitle">Finalizar compra</h2><p class="modal-sub" id="pixSubtitle"></p><div class="product-price" id="pixPrice"></div><div class="pix-qr-wrap"><div id="pixQr"></div></div><p class="muted" style="margin:10px 0">Escaneie o QR Code ou copie o código Pix. O valor desta cobrança é gerado conforme o preço do produto.</p><div id="pixCode" class="pix-code"></div><div class="pix-actions"><button class="pix-copy" id="copyPix">Copiar Pix Copia e Cola</button></div><hr style="border-color:#ffffff18;margin:18px 0"><h3 style="font-size:16px">Enviar comprovante</h3><p class="muted">Depois de pagar, envie a imagem do comprovante. Seu pedido ficará pendente até a conferência do administrador.</p><form id="proofForm"><input type="hidden" id="orderToken"><div class="form-group"><input type="file" id="proofFile" accept="image/jpeg,image/png,image/webp" required></div><button class="btn-primary">Enviar comprovante</button></form><div class="notice" id="pixNotice"></div><div id="orderTrack" class="order-card hidden"></div></div></div>
<div class="modal-overlay" id="trackModal"><div class="modal"><h2>Acompanhar pedido</h2><p class="modal-sub">Consulte o status de um pedido realizado neste dispositivo.</p><div class="form-group"><label>Código do pedido</label><input id="trackToken" placeholder="Cole o código do pedido"></div><button class="btn-primary" id="trackBtn">Consultar pedido</button><div id="trackResult" class="order-card hidden"></div><button class="btn-secondary close-modal" style="margin-top:14px">Fechar</button></div></div>
<script>window.VENOM_API_BASE="";</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script>
const $=id=>document.getElementById(id);
let currentProducts=[],activeOrder=null;
const money=n=>new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'}).format(Number(n)||0);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

function getBaseUrl(){
  return (localStorage.getItem('venom_api_base') || window.VENOM_API_BASE || '').trim().replace(/\/$/,'');
}
function getAdminToken(){
  return localStorage.getItem('venom_admin_token') || '';
}

// --- MODO LOCAL (FALLBACK CASO NÃO TENHA SERVIDOR REMOTO CONFIGURADO) ---
const LOCAL_KEY = 'venom_local_db_v1';
function getLocalDB(){
  const raw = localStorage.getItem(LOCAL_KEY);
  if(raw){
    try { return JSON.parse(raw); } catch(e){}
  }
  const init = {
    settings: { pix_key: 'd7a1cf48-6ca7-4af2-bdc7-e2024f6edcb85', pix_name: 'PAULO GUILHERME DOS SANTO', pix_city: 'SAO PAULO', whatsapp: '558296155634', store_name: 'VENOM STREAMING' },
    admin: { username: 'admin', password: 'Venom@2026#Acesso' },
    products: [],
    accounts: [],
    orders: [],
    next_product: 1,
    next_account: 1,
    next_order: 1
  };
  saveLocalDB(init);
  return init;
}
function saveLocalDB(db){
  localStorage.setItem(LOCAL_KEY, JSON.stringify(db));
}
function crc16(s){
  let crc=0xFFFF;
  for(let i=0;i<s.length;i++){
    crc ^= s.charCodeAt(i)<<8;
    for(let j=0;j<8;j++) crc=(crc&0x8000)?((crc<<1)^0x1021):(crc<<1);
    crc &= 0xFFFF;
  }
  return crc.toString(16).toUpperCase().padStart(4,'0');
}
function tlv(id,v){ return id + String(v.length).padStart(2,'0') + v; }
function buildPix(settings, amount, txid){
  const key=(settings.pix_key||'').trim();
  if(!key) throw Error('Cadastre sua chave Pix nas configurações do ADM.');
  const name=(settings.pix_name||'VENOM STREAMING').replace(/[^A-Za-z0-9 ]/g,'').slice(0,25) || 'VENOM STREAMING';
  const city=(settings.pix_city||'SAO PAULO').replace(/[^A-Za-z0-9 ]/g,'').slice(0,15) || 'SAO PAULO';
  const gui=tlv('00','br.gov.bcb.pix')+tlv('01',key);
  const payload=tlv('00','01')+tlv('01','11')+tlv('26',gui)+tlv('52','0000')+tlv('53','986')+tlv('54',Number(amount).toFixed(2))+tlv('58','BR')+tlv('59',name)+tlv('60',city)+tlv('62',tlv('05',(txid.replace(/[^A-Za-z0-9]/g,'').slice(0,25))||'VENOM'))+'6304';
  return payload+crc16(payload);
}
function fileToDataUrl(file, maxW=720){
  return new Promise((res,rej)=>{
    if(!file || !file.size) return res('');
    const r=new FileReader();
    r.onload=()=>{
      const raw=r.result;
      const im=new Image();
      im.onload=()=>{
        try{
          let w=im.width, h=im.height;
          if(w>maxW){ h=Math.round(h*(maxW/w)); w=maxW; }
          const cv=document.createElement('canvas');
          cv.width=w; cv.height=h;
          cv.getContext('2d').drawImage(im,0,0,w,h);
          res(cv.toDataURL('image/jpeg',0.82));
        }catch(e){ res(raw); }
      };
      im.onerror=()=>res(raw);
      im.src=raw;
    };
    r.onerror=()=>rej(Error('Erro ao ler imagem.'));
    r.readAsDataURL(file);
  });
}

async function localApi(action, opts={}){
  const db = getLocalDB();
  const baseAction = action.split('&')[0];
  let body = {};
  if(opts.body && typeof opts.body === 'string'){
    try { body = JSON.parse(opts.body); } catch(e){}
  }
  if(baseAction === 'products'){
    const items = db.products.filter(p=>p.active!==false).map(p=>({
      ...p,
      available: db.accounts.filter(a=>Number(a.product_id)===Number(p.id) && a.status==='available').length
    }));
    return { ok: true, products: items };
  }
  if(baseAction === 'status'){
    return { ok: true, loggedIn: sessionStorage.getItem('venom_local_adm') === '1' };
  }
  if(baseAction === 'login'){
    if(body.username === db.admin.username && body.password === db.admin.password){
      sessionStorage.setItem('venom_local_adm', '1');
      return { ok: true, message: 'Acesso autorizado (Modo Local).' };
    }
    throw Error('Usuário ou senha incorretos.');
  }
  if(baseAction === 'logout'){
    sessionStorage.removeItem('venom_local_adm');
    return { ok: true };
  }
  if(baseAction === 'create_order'){
    const pid = Number(body.product_id||0);
    const p = db.products.find(x=>Number(x.id)===pid && x.active!==false);
    if(!p) throw Error('Produto indisponível.');
    const stock = db.accounts.filter(a=>Number(a.product_id)===pid && a.status==='available').length;
    if(stock < 1) throw Error('Produto sem contas disponíveis no momento.');
    const id = db.next_order++;
    const token = 'VNM' + id + Math.random().toString(36).slice(2,10).toUpperCase();
    const o = { id, token, product_id: pid, product_name: p.name, price: Number(p.price), status: 'awaiting_proof', proof: '', account_id: null, created_at: new Date().toISOString() };
    db.orders.push(o);
    saveLocalDB(db);
    const pix = buildPix(db.settings, p.price, 'V'+id);
    return { ok: true, order: o, pix };
  }
  if(baseAction === 'upload_proof'){
    const fd = opts.body;
    const token = fd.get('token');
    const file = fd.get('proof');
    const o = db.orders.find(x=>x.token===token);
    if(!o) throw Error('Pedido não encontrado.');
    o.proof = await fileToDataUrl(file);
    o.status = 'pending';
    saveLocalDB(db);
    return { ok: true, message: 'Comprovante enviado. Seu pedido está pendente de conferência.' };
  }
  if(baseAction === 'order_status'){
    const m = action.match(/token=([^&]+)/);
    const token = m ? decodeURIComponent(m[1]) : '';
    const o = db.orders.find(x=>x.token===token);
    if(!o) throw Error('Pedido não encontrado.');
    const res = { id: o.id, product_name: o.product_name, price: o.price, status: o.status, created_at: o.created_at };
    if(o.status === 'released' && o.account_id){
      const acc = db.accounts.find(a=>Number(a.id)===Number(o.account_id));
      if(acc) res.credentials = { email: acc.email, password: acc.password };
    }
    return { ok: true, order: res };
  }
  if(sessionStorage.getItem('venom_local_adm') !== '1') throw Error('Acesso não autorizado.');
  if(baseAction === 'admin_products'){
    const items = db.products.map(p=>({
      ...p,
      available: db.accounts.filter(a=>Number(a.product_id)===Number(p.id) && a.status==='available').length
    }));
    return { ok: true, products: items };
  }
  if(baseAction === 'save'){
    const fd = opts.body;
    const id = Number(fd.get('id')||0);
    const name = String(fd.get('name')||'').trim();
    const priceRaw = String(fd.get('price')||'').replace(/[R$\s.]/g,'').replace(',','.');
    const price = Math.round(Number(priceRaw)*100)/100;
    const desc = String(fd.get('description')||'').trim();
    const imgFile = fd.get('image');
    const preData = String(fd.get('image_data')||'').trim();
    if(!name || !(price > 0)) throw Error('Informe nome e preço válido.');
    let imgData = preData;
    if(!imgData && imgFile && imgFile.size > 0){
      imgData = await fileToDataUrl(imgFile);
    }
    let existing = id > 0 ? db.products.find(x=>Number(x.id)===id) : null;
    if(existing){
      existing.name = name;
      existing.price = price;
      existing.description = desc;
      if(imgData) existing.image = imgData;
    } else {
      db.products.push({ id: db.next_product++, name, price, description: desc, image: imgData, active: true });
    }
    saveLocalDB(db);
    return { ok: true, message: 'Produto salvo com sucesso.' };
  }
  if(baseAction === 'delete'){
    db.products = db.products.filter(p=>Number(p.id)!==Number(body.id));
    saveLocalDB(db);
    return { ok: true, message: 'Produto excluído.' };
  }
  if(baseAction === 'add_account'){
    let pid = Number(body.product_id||0);
    const customName = String(body.custom_product_name||'').trim();
    if(!pid && customName){
      let found = db.products.find(x=>x.name.toLowerCase()===customName.toLowerCase());
      if(!found){
        found = { id: db.next_product++, name: customName, price: 10.00, description: 'Acesso ' + customName, image: '', active: true };
        db.products.push(found);
      }
      pid = found.id;
    }
    if(!pid || !body.email || !body.password) throw Error('Selecione qual é a conta/serviço e informe e-mail e senha.');
    db.accounts.push({ id: db.next_account++, product_id: pid, email: body.email.trim(), password: body.password, status: 'available', order_id: null });
    saveLocalDB(db);
    return { ok: true, message: 'Conta adicionada ao estoque.' };
  }
  if(baseAction === 'admin_accounts'){
    const list = db.accounts.map(a=>{
      const p = db.products.find(x=>Number(x.id)===Number(a.product_id));
      return { id: a.id, product_id: a.product_id, product_name: p?p.name:'Produto', email: a.email, status: a.status };
    });
    return { ok: true, accounts: list };
  }
  if(baseAction === 'delete_account'){
    db.accounts = db.accounts.filter(a=>Number(a.id)!==Number(body.id) || a.status!=='available');
    saveLocalDB(db);
    return { ok: true, message: 'Conta removida.' };
  }
  if(baseAction === 'settings_get'){
    return { ok: true, settings: db.settings, username: db.admin.username };
  }
  if(baseAction === 'settings_save'){
    ['pix_key','pix_name','pix_city','whatsapp','store_name'].forEach(k=>{ if(body[k]!==undefined) db.settings[k]=String(body[k]).trim(); });
    if(body.new_username) db.admin.username = String(body.new_username).trim();
    if(body.new_password){
      if(String(body.new_password).length < 8) throw Error('A nova senha precisa ter pelo menos 8 caracteres.');
      db.admin.password = String(body.new_password);
    }
    saveLocalDB(db);
    return { ok: true, message: 'Configurações salvas.' };
  }
  if(baseAction === 'admin_orders'){
    const list = [...db.orders].reverse().map(o=>({ ...o, proof_url: o.proof || '' }));
    return { ok: true, orders: list };
  }
  if(baseAction === 'release_order'){
    const o = db.orders.find(x=>Number(x.id)===Number(body.id));
    if(!o) throw Error('Pedido não encontrado.');
    const acc = db.accounts.find(a=>Number(a.product_id)===Number(o.product_id) && a.status==='available');
    if(!acc) throw Error('Não há conta disponível para este produto.');
    acc.status = 'delivered';
    acc.order_id = o.id;
    o.account_id = acc.id;
    o.status = 'released';
    saveLocalDB(db);
    return { ok: true, message: 'Conta liberada para o cliente.' };
  }
  throw Error('Ação desconhecida.');
}

// Campo opcional para URL do servidor PHP no modal de login
(function initServerField(){
  const form=$('loginForm');
  if(!form || $('serverUrl')) return;
  const div=document.createElement('div');
  div.className='form-group';
  div.innerHTML='<label>Servidor PHP Online (opcional)</label><input id="serverUrl" type="url" placeholder="Deixe vazio para usar direto no aparelho ou cole https://..." value="'+esc(getBaseUrl())+'">';
  form.insertBefore(div, form.firstChild);
})();

async function api(action,opts={}){
  const base=getBaseUrl();
  if(!base) return localApi(action, opts);
  const headers=new Headers(opts.headers||{});
  const tok=getAdminToken();
  if(tok) headers.set('X-Admin-Token',tok);
  opts.headers=headers;
  const r=await fetch(`${base}/api.php?action=${encodeURIComponent(action)}`,opts);
  const d=await r.json().catch(()=>{throw Error('A API não retornou JSON. Verifique o PHP na hospedagem.')});
  if(!r.ok||!d.ok) throw Error(d.message||'Falha na operação.');
  return d;
}

function resolveImgUrl(src){
  if(!src) return '';
  if(/^https?:\/\//i.test(src) || src.startsWith('data:')) return src;
  const base=getBaseUrl();
  return base ? `${base}/${src.replace(/^\//,'')}` : src;
}

function modal(id,on=true){$(id).classList.toggle('show',on)}
function notice(id,msg,ok=true){$(id).textContent=msg;$(id).className='notice '+(ok?'success':'error')}
function img(p,cls='product-image'){const u=resolveImgUrl(p.image);return u?`<img class="${cls}" src="${esc(u)}" alt="${esc(p.name)}" onerror="this.outerHTML='<div class=\'product-image-fallback\'>VENOM</div>'">`:`<div class="product-image-fallback">VENOM</div>`}

async function loadProducts(){
  try{
    const d=await api('products');
    currentProducts=d.products||[];
    let waNumber = d.whatsapp || '';
    if(!waNumber){
      // Tentar modo local db settings
      try { const ldb = getLocalDB(); waNumber = ldb.settings?.whatsapp || ''; } catch(e){}
    }
    const wf = $('whatsappFloat');
    if(wf && waNumber){
      const cleanWa = String(waNumber).replace(/\D/g,'');
      if(cleanWa){
        wf.href = 'https://wa.me/' + cleanWa + '?text=' + encodeURIComponent('Olá! Vim pelo aplicativo e preciso de suporte com um pedido.');
        wf.classList.remove('hidden');
      } else {
        wf.classList.add('hidden');
      }
    } else if(wf) {
      wf.classList.add('hidden');
    }

    const box=$('products');
    if(!currentProducts.length){box.innerHTML='<div class="empty-state">Nenhum produto disponível no momento.</div>';return}
    box.innerHTML=currentProducts.map(p=>`<article class="product-card">${img(p)}<div class="product-body"><h3 class="product-title">${esc(p.name)}</h3><p class="product-desc">${esc(p.description||'Consulte os detalhes deste produto.')}</p><div class="product-price">${money(p.price)}</div><div class="stock">${Number(p.available)} disponível(is)</div><button class="btn-buy" data-buy="${Number(p.id)}" ${Number(p.available)<1?'disabled style="opacity:.45"':''}>${Number(p.available)>0?'▦ Comprar com Pix':'Sem estoque'}</button></div></article>`).join('');
    box.querySelectorAll('[data-buy]').forEach(b=>b.onclick=()=>buy(Number(b.dataset.buy)));
  }catch(e){
    $('products').innerHTML=`<div class="empty-state">${esc(e.message)}</div>`;
  }
}

async function buy(id){
  try{
    const d=await api('create_order',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({product_id:id})});
    activeOrder=d.order;
    localStorage.setItem('venom_order_'+d.order.id,d.order.token);
    $('pixTitle').textContent=d.order.product_name;
    $('pixSubtitle').textContent='Pedido #'+d.order.id+' · Faça o pagamento e envie o comprovante.';
    $('pixPrice').textContent=money(d.order.price);
    $('pixCode').textContent=d.pix;
    $('orderToken').value=d.order.token;
    $('orderTrack').classList.remove('hidden');
    $('orderTrack').innerHTML='Pedido criado: <strong>#'+d.order.id+'</strong><br>Guarde este código para acompanhar sua compra:<br><code style="overflow-wrap:anywhere">'+esc(d.order.token)+'</code><br><span class="muted">Após pagar, envie o comprovante abaixo.</span>';
    $('pixQr').innerHTML='';
    if(window.QRCode) new QRCode($('pixQr'),{text:d.pix,width:210,height:210});
    else $('pixQr').textContent='QR indisponível. Use o código Pix.';
    $('pixNotice').className='notice';
    $('proofForm').reset();
    $('orderTrack').classList.add('hidden');
    modal('pixModal');
  }catch(e){alert(e.message)}
}

$('copyPix').onclick=async()=>{try{await navigator.clipboard.writeText($('pixCode').textContent);notice('pixNotice','Pix copiado. Confira o valor e o recebedor no aplicativo do banco.')}catch(e){notice('pixNotice','Selecione e copie o código Pix acima.',false)}};

$('proofForm').onsubmit=async e=>{
  e.preventDefault();
  try{
    const fd=new FormData();
    fd.append('token',$('orderToken').value);
    fd.append('proof',$('proofFile').files[0]);
    const d=await api('upload_proof',{method:'POST',body:fd});
    notice('pixNotice',d.message);
    $('orderTrack').classList.remove('hidden');
    $('orderTrack').innerHTML='Pedido enviado. Status: <strong>PENDENTE</strong>. Guarde o código do pedido: <br><code>'+esc($('orderToken').value)+'</code>';
    loadProducts();
  }catch(err){notice('pixNotice',err.message,false)}
};

$('pixClose').onclick=()=>modal('pixModal',false);

$('openAdmin').onclick=async()=>{
  if($('serverUrl')) $('serverUrl').value=getBaseUrl();
  try{
    const d=await api('status');
    if(d.loggedIn){modal('adminModal');await refreshAdmin()}
    else{notice('loginNotice','');modal('loginModal')}
  }catch(e){
    modal('loginModal');
    notice('loginNotice',e.message,false);
  }
};

$('loginForm').onsubmit=async e=>{
  e.preventDefault();
  try{
    const srv=($('serverUrl')?.value||'').trim().replace(/\/$/,'');
    if(srv) localStorage.setItem('venom_api_base',srv);
    else localStorage.removeItem('venom_api_base');
    const d=await api('login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:$('username').value,password:$('password').value})});
    if(d.token) localStorage.setItem('venom_admin_token',d.token);
    modal('loginModal',false);
    modal('adminModal');
    await refreshAdmin();
    await loadProducts();
  }catch(err){notice('loginNotice',err.message,false)}
};

document.querySelectorAll('.close-modal').forEach(b=>b.onclick=()=>{modal('loginModal',false);modal('adminModal',false);modal('trackModal',false)});
$('logoutBtn').onclick=async()=>{try{await api('logout')}catch(e){}localStorage.removeItem('venom_admin_token');modal('adminModal',false)};
$('mobileMenu').onclick=()=>$('navLinks').classList.toggle('open');
document.querySelectorAll('#navLinks a').forEach(a=>a.onclick=()=>$('navLinks').classList.remove('open'));
function updateImagePreview(src, label=''){
  $('productImageData').value = src || '';
  $('productImagePreview').innerHTML = src ? `<div style="display:flex;align-items:center;gap:10px;margin-top:8px"><img src="${esc(src)}" style="width:60px;height:60px;object-fit:cover;border-radius:8px;border:1px solid var(--line)"><span class="muted" style="font-size:12px">${esc(label || 'Foto pronta')}</span></div>` : '';
}
if($('triggerGallery')) $('triggerGallery').onclick = () => {
  if($('productImageInput')) $('productImageInput').click();
};
if($('productImageInput')) $('productImageInput').onchange=async e=>{
  const file=e.target.files && e.target.files[0];
  if(!file) return;
  try{
    const dataUrl = await fileToDataUrl(file);
    updateImagePreview(dataUrl, file.name);
    if($('imageFileStatus')) $('imageFileStatus').textContent = 'Foto selecionada: ' + file.name;
    $('productImageUrl').value = '';
  }catch(err){
    notice('adminNotice', err.message || 'Erro ao carregar foto da galeria.', false);
  }
};
if($('productImageUrl')) $('productImageUrl').oninput=e=>{
  const u=e.target.value.trim();
  if(u){
    updateImagePreview(u, 'Link da imagem');
    if($('productImageInput')) $('productImageInput').value = '';
  } else {
    updateImagePreview('', '');
  }
};

document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=async()=>{
  document.querySelectorAll('[data-tab]').forEach(x=>x.classList.toggle('active',x===b));
  ['orders','productsAdmin','accounts','settings'].forEach(t=>$('tab-'+t).classList.toggle('hidden',t!==b.dataset.tab));
  notice('adminNotice','');
  if(b.dataset.tab==='accounts'){ await adminProducts(); await adminAccounts(); }
  if(b.dataset.tab==='productsAdmin'){ await adminProducts(); }
});

async function refreshAdmin(){await Promise.all([adminProducts(),adminOrders(),adminAccounts(),settingsLoad()])}

async function adminProducts(){
  const d=await api('admin_products');
  const ps=d.products||[];
  $('adminProducts').innerHTML=ps.map(p=>`<div class="admin-item">${img(p,'admin-item-img')}<div class="admin-item-info"><strong>${esc(p.name)}</strong><span>${money(p.price)} · ${p.available} em estoque</span></div><div class="admin-item-actions"><button class="btn-secondary" data-edit="${p.id}">Editar</button><button class="btn-danger" data-del="${p.id}">Excluir</button></div></div>`).join('')||'<p class="muted">Nenhum produto cadastrado.</p>';
  const opts = ps.length
    ? '<option value="">-- Selecione o produto --</option>' + ps.map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('')
    : '<option value="">Nenhum produto cadastrado (digite o nome abaixo)</option>';
  $('accountProduct').innerHTML = opts;
  $('adminProducts').onclick=async e=>{
    const ed=e.target.closest('[data-edit]'),del=e.target.closest('[data-del]');
    if(ed){
      const p=ps.find(x=>x.id==ed.dataset.edit);
      $('productId').value=p.id;
      $('productName').value=p.name;
      $('productPrice').value=String(p.price).replace('.',',');
      $('productDescription').value=p.description||'';
      updateImagePreview(p.image||'', p.image ? 'Imagem atual mantida' : 'Nenhuma foto selecionada');
      document.querySelector('[data-tab="productsAdmin"]').click();
    }
    if(del&&confirm('Excluir este produto?')){await api('delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:Number(del.dataset.del)})});await adminProducts();await loadProducts()}
  };
}

$('productForm').onsubmit=async e=>{
  e.preventDefault();
  try{
    const fd=new FormData(e.target);
    if(!$('productImageData').value && $('productImageUrl').value.trim()){
      fd.set('image_data', $('productImageUrl').value.trim());
    }
    await api('save',{method:'POST',body:fd});
    e.target.reset();
    $('productId').value='';
    updateImagePreview('', 'Nenhuma foto selecionada');
    notice('adminNotice','Produto salvo com sucesso!');
    await adminProducts();
    await loadProducts();
  }catch(err){notice('adminNotice',err.message,false)}
};
$('clearProduct').onclick=()=>{$('productForm').reset();$('productId').value='';updateImagePreview('', 'Nenhuma foto selecionada')};

$('accountForm').onsubmit=async e=>{
  e.preventDefault();
  try{
    let pid = Number($('accountProduct').value||0);
    const customName = ($('accountProductCustom')?.value||'').trim();
    if(!pid && !customName){
      throw Error('Selecione qual é o produto/conta na lista ou digite o nome do serviço.');
    }
    if(!pid && customName && getBaseUrl()){
      const fd=new FormData();
      fd.append('name', customName);
      fd.append('price', '10,00');
      fd.append('description', 'Acesso ' + customName);
      await api('save',{method:'POST',body:fd});
      const prodRes = await api('admin_products');
      const created = (prodRes.products||[]).find(x=>x.name.toLowerCase()===customName.toLowerCase());
      if(created) pid = Number(created.id);
    }
    await api('add_account',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({product_id:pid,custom_product_name:customName,email:$('accountEmail').value,password:$('accountPassword').value})});
    e.target.reset();
    notice('adminNotice','Conta adicionada ao estoque com sucesso!');
    await adminAccounts();
    await adminProducts();
    await loadProducts();
  }catch(err){notice('adminNotice',err.message,false)}
};

async function adminAccounts(){
  const d=await api('admin_accounts');
  $('accountsList').innerHTML=(d.accounts||[]).map(a=>`<div class="admin-item"><div class="admin-item-info"><strong>${esc(a.product_name)}</strong><span>${esc(a.email)} · ${a.status==='available'?'Disponível':'Entregue'}</span></div>${a.status==='available'?`<button class="btn-danger" data-account-del="${a.id}">Excluir</button>`:''}</div>`).join('')||'<p class="muted">Nenhuma conta cadastrada.</p>';
  $('accountsList').onclick=async e=>{const b=e.target.closest('[data-account-del]');if(b&&confirm('Excluir esta conta disponível?')){await api('delete_account',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:Number(b.dataset.accountDel)})});await adminAccounts();await adminProducts();await loadProducts()}};
}

async function settingsLoad(){const d=await api('settings_get'),s=d.settings;$('pixKey').value=s.pix_key||'';$('pixName').value=s.pix_name||'';$('pixCity').value=s.pix_city||'';$('whatsapp').value=s.whatsapp||'';$('storeName').value=s.store_name||'';$('newUsername').value='';$('newPassword').value=''};
$('settingsForm').onsubmit=async e=>{e.preventDefault();try{const b={pix_key:$('pixKey').value,pix_name:$('pixName').value,pix_city:$('pixCity').value,whatsapp:$('whatsapp').value,store_name:$('storeName').value,new_username:$('newUsername').value,new_password:$('newPassword').value};const d=await api('settings_save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});notice('adminNotice',d.message);$('newPassword').value='';$('newUsername').value=''}catch(err){notice('adminNotice',err.message,false)}};

async function adminOrders(){
  const d=await api('admin_orders');
  const os=d.orders||[];
  $('ordersList').innerHTML=os.map(o=>`<div class="order-card"><strong>Pedido #${o.id} · ${esc(o.product_name)}</strong><br>Valor: ${money(o.price)}<br>Status: <strong>${o.status==='pending'?'PENDENTE':o.status==='released'?'LIBERADO':'AGUARDANDO COMPROVANTE'}</strong><br><span class="muted">${new Date(o.created_at).toLocaleString('pt-BR')}</span>${o.proof_url?`<a class="btn-secondary" style="display:inline-block;margin:9px 0" href="${esc(resolveImgUrl(o.proof_url))}" target="_blank">Ver comprovante</a>`:'<p class="muted">Comprovante ainda não enviado.</p>'}${o.status!=='released'?`<button class="btn-primary" data-release="${o.id}" style="display:block;margin-top:8px">Liberar conta</button>`:''}</div>`).join('')||'<p class="muted">Nenhum pedido recebido ainda.</p>';
  $('ordersList').onclick=async e=>{const b=e.target.closest('[data-release]');if(b&&confirm('Confirmou o pagamento e deseja liberar uma conta deste produto?')){try{const r=await api('release_order',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:Number(b.dataset.release)})});notice('adminNotice',r.message);await adminOrders();await adminAccounts();await adminProducts();await loadProducts()}catch(err){notice('adminNotice',err.message,false)}}};
}

$('year').textContent=new Date().getFullYear();
function openTrack(){modal('trackModal')}
const trackLink=document.createElement('button');trackLink.className='btn-secondary';trackLink.textContent='Acompanhar pedido';trackLink.style.cssText='position:fixed;left:16px;bottom:16px;z-index:30';trackLink.onclick=openTrack;document.body.appendChild(trackLink);
$('trackBtn').onclick=async()=>{try{const token=$('trackToken').value.trim();const d=await api('order_status&token='+encodeURIComponent(token));const o=d.order;let html=`Pedido #${o.id} · ${esc(o.product_name)}<br>Valor: ${money(o.price)}<br>Status: <strong>${o.status==='released'?'CONTA LIBERADA':o.status==='pending'?'PENDENTE DE CONFERÊNCIA':'AGUARDANDO COMPROVANTE'}</strong>`;if(o.credentials)html+=`<hr style="margin:12px 0;border-color:#ffffff22"><strong>Dados liberados</strong><br>E-mail: <code>${esc(o.credentials.email)}</code><br>Senha: <code>${esc(o.credentials.password)}</code>`;$('trackResult').innerHTML=html;$('trackResult').classList.remove('hidden')}catch(e){$('trackResult').textContent=e.message;$('trackResult').classList.remove('hidden')}};

loadProducts();
if('serviceWorker'in navigator)navigator.serviceWorker.register('./sw.js').catch(()=>{});
</script>

<a href="https://wa.me/" id="whatsappFloat" class="whatsapp-float hidden" target="_blank" aria-label="Suporte WhatsApp">💬</a>
</body>
</html>