
import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import multer from 'multer';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { GoogleGenAI } from '@google/genai';
import { OAuth2Client } from 'google-auth-library';

dotenv.config();
const app=express();
const ALLOWED=(process.env.CORS_ORIGIN||'').split(',').map(x=>x.trim()).filter(Boolean);
// O app Android carrega de file:///android_asset, cuja origem é "null": precisa ser aceita.
app.disable('x-powered-by');
app.use(cors({origin:(origin,cb)=>cb(null,!ALLOWED.length||!origin||origin==='null'||origin==='https://appassets.androidplatform.net'||ALLOWED.includes(origin)),methods:['GET','POST','OPTIONS'],allowedHeaders:['Content-Type','X-Gemini-API-Key','Authorization'],maxAge:86400}));
app.use(express.json({limit:'20mb'}));
const TMP=path.join(os.tmpdir(),'megaia-uploads');
fs.mkdirSync(TMP,{recursive:true});
const upload=multer({
 storage:multer.diskStorage({destination:(req,file,cb)=>cb(null,TMP),filename:(req,file,cb)=>cb(null,`${Date.now()}-${Math.random().toString(36).slice(2)}-${file.originalname.replace(/[^a-zA-Z0-9._-]/g,'_')}`)}),
 limits:{fileSize:(Number(process.env.MAX_FILE_SIZE_MB)||500)*1024*1024,files:125}
});
const MODEL=process.env.GEMINI_MODEL||'gemini-3.8-flash';
const FAST_MODEL=process.env.GEMINI_FAST_MODEL||'gemini-3.5-flash-lite';
const CHAT_PROMPT='Você é a MegaIA, uma assistente inteligente. Responda em português do Brasil, de forma clara e direta.';
const GAME_PROMPT='Você é o MegaIA Game Studio. Crie UM jogo completo em um único arquivo HTML (HTML, CSS e JS inline, sem bibliotecas nem recursos externos), com controles de toque e teclado, placar, game over e reiniciar. Responda com no máximo duas frases e depois o código dentro de UM bloco ```html.';
function withTimeout(promise,ms){let t;return Promise.race([promise,new Promise((_,rej)=>{t=setTimeout(()=>rej(Object.assign(new Error('O modelo demorou mais de '+Math.round(ms/1000)+' s.'),{timeout:true})),ms)})]).finally(()=>clearTimeout(t))}
async function quickText(client,message,game){
 const order=game?[MODEL,FAST_MODEL]:[FAST_MODEL,MODEL];let last;
 for(let i=0;i<order.length;i++){
  try{const r=await withTimeout(client.models.generateContent({model:order[i],contents:[{role:'user',parts:[{text:message}]}],config:{systemInstruction:game?GAME_PROMPT:CHAT_PROMPT}}),game?60000:(i?25000:5000));const t=(r.text||'').trim();if(t)return {reply:t,model:order[i]}}
  catch(e){last=e}
 }
 throw last||new Error('O modelo não retornou resposta.')}
function ai(req){const key=String(req.get('X-Gemini-API-Key')||process.env.GEMINI_API_KEY||'').trim();if(!key)throw new Error('Cole sua chave Gemini em Configurações ou configure GEMINI_API_KEY no ambiente do servidor.');return new GoogleGenAI({apiKey:key})}
function cleanFiles(files=[]){for(const f of files){try{fs.unlinkSync(f.path)}catch{}}}
function kind(mime){if(mime.startsWith('image/'))return 'image';if(mime.startsWith('video/'))return 'video';if(mime.startsWith('audio/'))return 'audio';if(mime==='application/pdf')return 'document';return null}
async function uploadToGemini(client,file){
 const mime=file.mimetype||'application/octet-stream';
 if(file.size>2*1024*1024*1024)throw new Error(`${file.originalname}: arquivo acima do limite de 2 GB da API de arquivos.`);
 if(mime==='application/pdf'&&file.size>50*1024*1024)throw new Error(`${file.originalname}: PDF acima de 50 MB.`);
 const uploaded=await client.files.upload({file:file.path,config:{mimeType:mime,displayName:file.originalname}});
 let current=uploaded;
 for(let i=0;i<90&&current.state&&String(current.state).toUpperCase().includes('PROCESSING');i++){
   await new Promise(r=>setTimeout(r,2000));
   current=await client.files.get({name:uploaded.name});
 }
 if(current.state&&String(current.state).toUpperCase().includes('FAILED'))throw new Error(`O provedor não conseguiu processar ${file.originalname}.`);
 return {type:kind(mime),uri:current.uri||uploaded.uri,mime_type:current.mimeType||mime,name:file.originalname};
}
function extractText(interaction){
 if(interaction.output_text)return interaction.output_text;
 const out=[];
 for(const step of (interaction.steps||[]))for(const c of (step.content||[]))if(c.type==='text'&&c.text)out.push(c.text);
 for(const item of (interaction.outputs||[]))if(item.type==='text'&&item.text)out.push(item.text);
 return out.join('\n').trim();
}

// ---------- Login com Google ----------
// O app obtém um ID token do Google (login nativo do Android). Aqui ele é VERIFICADO (assinatura, validade e
// audiência = GOOGLE_WEB_CLIENT_ID) e trocado por uma sessão assinada com SESSION_SECRET.
// Se GOOGLE_WEB_CLIENT_ID estiver vazio, o login no servidor fica desligado (comportamento antigo).
const GOOGLE_CLIENT_ID=(process.env.GOOGLE_WEB_CLIENT_ID||'').trim();
const SESSION_SECRET=process.env.SESSION_SECRET||crypto.randomBytes(32).toString('hex'); // sem SESSION_SECRET fixo, sessões caem a cada reinício
const SESSION_TTL=30*24*3600;
const ALLOWED_EMAILS=(process.env.ALLOWED_EMAILS||'').split(',').map(x=>x.trim().toLowerCase()).filter(Boolean);
const gClient=GOOGLE_CLIENT_ID?new OAuth2Client(GOOGLE_CLIENT_ID):null;
const b64u=b=>Buffer.from(b).toString('base64url');
function signSession(p){const body=b64u(JSON.stringify(p));return body+'.'+crypto.createHmac('sha256',SESSION_SECRET).update(body).digest('base64url')}
function readSession(t){try{const [body,sig]=String(t||'').split('.');if(!body||!sig)return null;
 const ok=crypto.createHmac('sha256',SESSION_SECRET).update(body).digest('base64url');
 if(sig.length!==ok.length||!crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(ok)))return null;
 const p=JSON.parse(Buffer.from(body,'base64url').toString());return p.exp>Date.now()/1000?p:null}catch{return null}}
function requireLogin(req,res,next){
 if(!gClient)return next();
 const m=/^Bearer (.+)$/.exec(req.get('Authorization')||'');const p=m&&readSession(m[1]);
 if(!p)return res.status(401).json({error:'Login necessário. Entre com sua conta Google no app.',code:'login_required'});
 req.user=p;next()}
app.post('/api/auth/google',async(req,res)=>{
 if(!gClient)return res.status(501).json({error:'Login Google não está ativo neste servidor (defina GOOGLE_WEB_CLIENT_ID).'});
 try{
  const ticket=await gClient.verifyIdToken({idToken:String(req.body.idToken||''),audience:GOOGLE_CLIENT_ID});
  const p=ticket.getPayload();
  if(!p||!p.sub)throw new Error('token sem identificador');
  if(p.email&&p.email_verified===false)return res.status(403).json({error:'E-mail do Google não verificado.'});
  if(ALLOWED_EMAILS.length&&!ALLOWED_EMAILS.includes(String(p.email||'').toLowerCase()))return res.status(403).json({error:'Esta conta não tem permissão para usar este servidor.'});
  const now=Math.floor(Date.now()/1000);
  res.json({session:signSession({sub:p.sub,email:p.email||'',name:p.name||'',iat:now,exp:now+SESSION_TTL}),expiresIn:SESSION_TTL,user:{sub:p.sub,email:p.email||'',name:p.name||'',picture:p.picture||''}})
 }catch(e){res.status(401).json({error:'Token do Google inválido ou expirado. Saia e entre de novo no app.'})}});
app.get('/api/me',requireLogin,(req,res)=>res.json({ok:true,user:req.user||null}));
app.get('/',(req,res)=>res.json({ok:true,service:'MegaIA',hint:'Use /api/health, /api/chat e /api/generate-image'}));
app.get('/api/ping',(req,res)=>res.json({ok:true,t:Date.now()}));
app.get('/api/health',(req,res)=>res.json({ok:true,onlineAIConfigured:!!process.env.GEMINI_API_KEY,model:MODEL,service:'MegaIA',limits:{words:10000,images:50,videos:50},loginRequired:!!gClient}));

app.post('/api/chat',requireLogin,upload.array('files',125),async(req,res)=>{
 const files=req.files||[];
 try{
  const message=String(req.body.message||'').trim();
  const images=files.filter(f=>f.mimetype.startsWith('image/')).length;
  const videos=files.filter(f=>f.mimetype.startsWith('video/')).length;
  if(images>50)return res.status(400).json({error:'Máximo de 50 fotos por envio.'});
  if(videos>50)return res.status(400).json({error:'Máximo de 50 vídeos por envio.'});
  if(!message&&!files.length)return res.status(400).json({error:'Envie uma mensagem ou arquivo.'});
  const total=files.reduce((s,f)=>s+f.size,0);
  const maxTotal=(Number(process.env.MAX_TOTAL_UPLOAD_GB)||5)*1024*1024*1024;
  if(total>maxTotal)return res.status(413).json({error:`O total dos anexos excede ${process.env.MAX_TOTAL_UPLOAD_GB||5} GB configurados no servidor.`});
  const client=ai(req);
  if(!files.length){const q=await quickText(client,message,req.body.mode==='game');return res.json({...q,processed:{images:0,videos:0,other:0}})}
  const media=[],plain=[];
  for(const file of files){
   const k=kind(file.mimetype);
   if(k){media.push(await uploadToGemini(client,file));}
   else if(file.mimetype.startsWith('text/')||/\.(txt|csv|json|md|xml)$/i.test(file.originalname)){
    const text=fs.readFileSync(file.path,'utf8');
    plain.push({type:'text',text:`\n\n[Conteúdo do arquivo ${file.originalname}]\n${text.slice(0,150000)}`});
   }else{
    throw new Error(`Formato não conectado: ${file.originalname}. Envie imagem, vídeo, áudio, PDF ou arquivo TXT/CSV/JSON/MD.`);
   }
  }
  const all=[{type:'text',text:message||'Analise os arquivos enviados e explique os principais pontos.'},...plain,...media];
  // Batch at most 10 videos per interaction, then synthesize if multiple batches are needed.
  const batches=[];let current=[],videoCount=0;
  for(const item of all.slice(1)){
    const isVideo=item.type==='video';
    if(current.length>=25||(isVideo&&videoCount>=10)){batches.push(current);current=[];videoCount=0}
    current.push(item);if(isVideo)videoCount++;
  }
  if(current.length)batches.push(current);
  if(!batches.length)batches.push([]);
  const prompt=all[0];
  const summaries=[];
  for(let i=0;i<batches.length;i++){
    const interaction=await client.interactions.create({model:MODEL,input:[prompt,...batches[i]]});
    summaries.push(extractText(interaction)||`Lote ${i+1} processado sem texto de saída.`);
  }
  let reply=summaries.length===1?summaries[0]:(await client.interactions.create({model:MODEL,input:[{type:'text',text:`Una os resultados abaixo em uma resposta clara e completa em português, sem omitir informações importantes:\n\n${summaries.map((s,i)=>`LOTE ${i+1}:\n${s}`).join('\n\n')}`}]})).output_text;
  res.json({reply:reply||summaries.join('\n\n'),model:MODEL,processed:{images,videos,other:files.length-images-videos}});
 }catch(e){res.status(500).json({error:e.message||'Erro interno ao processar mídia.'})}
 finally{cleanFiles(files)}
});

app.post('/api/generate-image',requireLogin,upload.none(),async(req,res)=>{
 try{
  const prompt=String(req.body.message||'').trim();
  if(!prompt)return res.status(400).json({error:'Descreva a imagem que deseja criar.'});
  const client=ai(req);
  const interaction=await client.interactions.create({
   model:process.env.GEMINI_IMAGE_MODEL||'gemini-3.1-flash-image',
   input:[{type:'text',text:prompt}],
   response_format:{type:'image',aspect_ratio:process.env.IMAGE_ASPECT_RATIO||'1:1'}
  });
  const images=[];
  for(const step of (interaction.steps||[]))if(step.type==='model_output')for(const block of (step.content||[]))if(block.type==='image'&&block.data)images.push({mimeType:block.mime_type||'image/png',data:block.data});
  for(const output of (interaction.outputs||[]))if(output.type==='image'&&output.data)images.push({mimeType:output.mime_type||'image/png',data:output.data});
  if(!images.length)throw new Error(extractText(interaction)||'O modelo não retornou uma imagem. Verifique se o modelo de imagem está disponível para sua chave e região.');
  res.json({images,model:process.env.GEMINI_IMAGE_MODEL||'gemini-3.1-flash-image'});
 }catch(e){res.status(500).json({error:e.message||'Falha na geração de imagem.'})}
});

app.use('/api',(req,res)=>res.status(404).json({error:`Rota não encontrada: ${req.method} /api${req.path}. Use o endereço base do servidor, sem /api.`}));
app.use((err,req,res,next)=>{const code=err.code==='LIMIT_FILE_SIZE'?413:err.code?.startsWith?.('LIMIT_')?400:(err.status||500);res.status(code).json({error:err.code==='LIMIT_FILE_SIZE'?'Arquivo maior que o limite do servidor.':(err.message||'Erro interno.')})});
const port=process.env.PORT||3000;
const server=app.listen(port,'0.0.0.0',()=>console.log(`MegaIA API ouvindo na porta ${port}`));
server.requestTimeout=0;server.keepAliveTimeout=65000;
