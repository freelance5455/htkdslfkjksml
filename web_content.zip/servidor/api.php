<?php
// VENOM STREAMING - API PHP. Requer PHP 8+ com sessões e permissões de escrita.
declare(strict_types=1);
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if ($origin !== '') {
    header('Access-Control-Allow-Origin: ' . $origin);
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Admin-Token');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
} else {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Admin-Token');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
}
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
    http_response_code(204);
    exit;
}
if (PHP_VERSION_ID >= 70300 && !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
    session_set_cookie_params(['samesite' => 'None', 'secure' => true, 'httponly' => true]);
}
session_start();
const DATA_FILE = __DIR__ . '/storage/data.json';
const UPLOAD_DIR = __DIR__ . '/uploads/';
const PROOF_DIR = __DIR__ . '/proofs/';
const MAX_UPLOAD = 5 * 1024 * 1024;

function out(array $data, int $status=200): never { http_response_code($status); header('Content-Type: application/json; charset=utf-8'); echo json_encode($data, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }
function read_data(): array {
    if (!is_file(DATA_FILE)) { $d=initial_data(); write_data($d); return $d; }
    $raw=@file_get_contents(DATA_FILE); $d=json_decode((string)$raw,true);
    return is_array($d) ? array_merge(initial_data(),$d) : initial_data();
}
function write_data(array $d): void { $fp=fopen(DATA_FILE,'c+'); if(!$fp) throw new RuntimeException('Não foi possível gravar os dados. Verifique as permissões da pasta storage.'); if(!flock($fp,LOCK_EX)){fclose($fp);throw new RuntimeException('Não foi possível bloquear o arquivo de dados.');} ftruncate($fp,0); rewind($fp); fwrite($fp,json_encode($d,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT)); fflush($fp); flock($fp,LOCK_UN); fclose($fp); }
function initial_data(): array {
 return ['settings'=>['pix_key'=>'','pix_name'=>'','pix_city'=>'','whatsapp'=>'558296155634','store_name'=>'VENOM STREAMING'], 'admin'=>['username'=>'admin','password_hash'=>password_hash('Venom@2026#Acesso',PASSWORD_DEFAULT)],'products'=>[],'accounts'=>[],'orders'=>[],'next_product'=>1,'next_account'=>1,'next_order'=>1];
}
function admin(): bool {
    if (!empty($_SESSION['venom_admin'])) return true;
    $tok = $_SERVER['HTTP_X_ADMIN_TOKEN'] ?? ($_GET['admin_token'] ?? '');
    if ($tok !== '') {
        $d = read_data();
        $saved = (string)($d['admin']['api_token'] ?? '');
        if ($saved !== '' && hash_equals($saved, (string)$tok)) return true;
    }
    return false;
}
function need_admin(): void { if(!admin()) out(['ok'=>false,'message'=>'Acesso não autorizado. Entre novamente no painel.'],401); }
function body_json(): array { $x=json_decode((string)file_get_contents('php://input'),true); return is_array($x)?$x:[]; }
function clean_price($v): float { $s=str_replace(['R$',' ','.'], '', (string)$v); $s=str_replace(',','.',$s); if(!is_numeric($s)) return 0; return round((float)$s,2); }
function crc16(string $s): string { $crc=0xFFFF; for($i=0,$n=strlen($s);$i<$n;$i++){ $crc ^= ord($s[$i])<<8; for($j=0;$j<8;$j++) $crc=($crc&0x8000)?(($crc<<1)^0x1021):($crc<<1); $crc &= 0xFFFF; } return strtoupper(str_pad(dechex($crc),4,'0',STR_PAD_LEFT)); }
function tlv(string $id,string $v): string { return $id.str_pad((string)strlen($v),2,'0',STR_PAD_LEFT).$v; }
function pix_payload(array $settings,float $amount,string $txid): string {
 $key=trim((string)($settings['pix_key']??'')); $name=substr(preg_replace('/[^A-Za-z0-9 ]/','',(string)($settings['pix_name']??'VENOM STREAMING')),0,25); $city=substr(preg_replace('/[^A-Za-z0-9 ]/','',(string)($settings['pix_city']??'SAO PAULO')),0,15);
 if($key==='') throw new RuntimeException('Cadastre sua chave Pix nas configurações do ADM.');
 $gui=tlv('00','br.gov.bcb.pix').tlv('01',$key);
 $payload=tlv('00','01').tlv('01','11').tlv('26',$gui).tlv('52','0000').tlv('53','986').tlv('54',number_format($amount,2,'.','')).tlv('58','BR').tlv('59',$name?:'VENOM STREAMING').tlv('60',$city?:'SAO PAULO').tlv('62',tlv('05',substr(preg_replace('/[^A-Za-z0-9]/','',$txid),0,25)?:'VENOM')).'6304';
 return $payload.crc16($payload);
}
function save_image(array $file,string $folder,string $prefix): string {
 if(($file['error']??UPLOAD_ERR_NO_FILE)===UPLOAD_ERR_NO_FILE) return '';
 if(($file['error']??1)!==UPLOAD_ERR_OK || ($file['size']??0)>MAX_UPLOAD) throw new RuntimeException('Imagem/comprovante inválido ou maior que 5 MB.');
 $info=@getimagesize($file['tmp_name']); if(!$info) throw new RuntimeException('O arquivo enviado não é uma imagem válida.');
 $mime=$info['mime']??''; $ext=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'][$mime]??''; if(!$ext) throw new RuntimeException('Formato não permitido. Use JPG, PNG, WEBP ou GIF.');
 if(!is_dir($folder) && !mkdir($folder,0755,true)) throw new RuntimeException('Não foi possível criar a pasta de arquivos.');
 $name=$prefix.'_'.bin2hex(random_bytes(12)).'.'.$ext; if(!move_uploaded_file($file['tmp_name'],$folder.$name)) throw new RuntimeException('Falha ao salvar o arquivo enviado.'); return $name;
}
function product_public(array $p,array $d): array { $p['available']=count(array_filter($d['accounts'],fn($a)=>(int)$a['product_id']===(int)$p['id']&&$a['status']==='available')); unset($p['internal']); return $p; }
try {
 $action=(string)($_GET['action']??''); $d=read_data();
 if($action==='products') { $items=array_map(fn($p)=>product_public($p,$d),array_values(array_filter($d['products'],fn($p)=>!empty($p['active'])))); out(['ok'=>true,'products'=>$items]); }
 if($action==='status') out(['ok'=>true,'loggedIn'=>admin()]);
 if($action==='login') { $b=body_json(); $u=(string)($b['username']??''); $p=(string)($b['password']??''); if(hash_equals((string)$d['admin']['username'],$u)&&password_verify($p,(string)$d['admin']['password_hash'])) { session_regenerate_id(true); $_SESSION['venom_admin']=true; $tok=bin2hex(random_bytes(24)); $d['admin']['api_token']=$tok; write_data($d); out(['ok'=>true,'message'=>'Acesso autorizado.','token'=>$tok]); } out(['ok'=>false,'message'=>'Usuário ou senha incorretos.'],401); }
 if($action==='logout') { $_SESSION=[]; @session_destroy(); if(isset($d['admin']['api_token'])){unset($d['admin']['api_token']);write_data($d);} out(['ok'=>true]); }
 if($action==='order_status') { $token=(string)($_GET['token']??''); foreach($d['orders'] as $o) if(hash_equals((string)$o['token'],$token)) { $result=['id'=>$o['id'],'product_name'=>$o['product_name'],'price'=>$o['price'],'status'=>$o['status'],'created_at'=>$o['created_at']]; if($o['status']==='released' && !empty($o['account_id'])) foreach($d['accounts'] as $a) if((int)$a['id']===(int)$o['account_id']) {$result['credentials']=['email'=>$a['email'],'password'=>$a['password']];break;} out(['ok'=>true,'order'=>$result]); } out(['ok'=>false,'message'=>'Pedido não encontrado.'],404); }
 if($action==='create_order') { $b=body_json(); $pid=(int)($b['product_id']??0); $p=null; foreach($d['products'] as $x) if((int)$x['id']===$pid && !empty($x['active'])) $p=$x; if(!$p) out(['ok'=>false,'message'=>'Produto indisponível.'],404); $stock=count(array_filter($d['accounts'],fn($a)=>(int)$a['product_id']===$pid&&$a['status']==='available')); if($stock<1) out(['ok'=>false,'message'=>'Produto sem contas disponíveis no momento.'],409); $id=$d['next_order']++; $token=bin2hex(random_bytes(24)); $o=['id'=>$id,'token'=>$token,'product_id'=>$pid,'product_name'=>$p['name'],'price'=>(float)$p['price'],'status'=>'awaiting_proof','proof'=>'','account_id'=>null,'created_at'=>date('c')]; $d['orders'][]=$o; write_data($d); $pix=pix_payload($d['settings'],(float)$p['price'],'V'.$id); out(['ok'=>true,'order'=>['id'=>$id,'token'=>$token,'product_name'=>$p['name'],'price'=>$p['price'],'status'=>$o['status']],'pix'=>$pix]); }
 if($action==='upload_proof') { $token=(string)($_POST['token']??''); $idx=null; foreach($d['orders'] as $i=>$o) if(hash_equals((string)$o['token'],$token)){$idx=$i;break;} if($idx===null) out(['ok'=>false,'message'=>'Pedido não encontrado.'],404); if($d['orders'][$idx]['status']==='released') out(['ok'=>false,'message'=>'Este pedido já foi liberado.'],409); if(empty($_FILES['proof'])) out(['ok'=>false,'message'=>'Selecione o comprovante.'],400); $fn=save_image($_FILES['proof'],PROOF_DIR,'proof'); $d['orders'][$idx]['proof']=$fn; $d['orders'][$idx]['status']='pending'; write_data($d); out(['ok'=>true,'message'=>'Comprovante enviado. Seu pedido está pendente de conferência.']); }
 need_admin();
 if($action==='admin_products') { out(['ok'=>true,'products'=>array_map(fn($p)=>product_public($p,$d),array_values($d['products']))]); }
 if($action==='settings_get') { out(['ok'=>true,'settings'=>$d['settings'],'username'=>$d['admin']['username']]); }
 if($action==='settings_save') { $b=body_json(); foreach(['pix_key','pix_name','pix_city','whatsapp','store_name'] as $k) if(isset($b[$k])) $d['settings'][$k]=trim((string)$b[$k]); if(!empty($b['new_username'])) $d['admin']['username']=trim((string)$b['new_username']); if(!empty($b['new_password'])) { if(strlen((string)$b['new_password'])<8) out(['ok'=>false,'message'=>'A nova senha precisa ter pelo menos 8 caracteres.'],400); $d['admin']['password_hash']=password_hash((string)$b['new_password'],PASSWORD_DEFAULT); } write_data($d); out(['ok'=>true,'message'=>'Configurações salvas.']); }
 if($action==='save') { $id=(int)($_POST['id']??0); $name=trim((string)($_POST['name']??'')); $price=clean_price($_POST['price']??''); if($name===''||$price<=0) out(['ok'=>false,'message'=>'Informe nome e preço válido.'],400); $image=''; if(isset($_FILES['image'])) $image=save_image($_FILES['image'],UPLOAD_DIR,'product'); $found=false; foreach($d['products'] as &$p) if((int)$p['id']===$id && $id>0){$p['name']=$name;$p['price']=$price;$p['description']=trim((string)($_POST['description']??''));if($image)$p['image']='uploads/'.$image;$found=true;break;} unset($p); if(!$found){$id=$d['next_product']++;$d['products'][]=['id'=>$id,'name'=>$name,'price'=>$price,'description'=>trim((string)($_POST['description']??'')),'image'=>$image?'uploads/'.$image:'','active'=>true];} write_data($d); out(['ok'=>true,'message'=>'Produto salvo com sucesso.']); }
 if($action==='delete') { $b=body_json();$id=(int)($b['id']??0);$d['products']=array_values(array_filter($d['products'],fn($p)=>(int)$p['id']!==$id));write_data($d);out(['ok'=>true,'message'=>'Produto excluído.']); }
 if($action==='add_account') { $b=body_json();$pid=(int)($b['product_id']??0);$email=trim((string)($b['email']??''));$pass=(string)($b['password']??'');$exists=false;foreach($d['products'] as $p)if((int)$p['id']===$pid)$exists=true;if(!$exists||$email===''||$pass==='')out(['ok'=>false,'message'=>'Selecione o produto e informe e-mail e senha.'],400);$id=$d['next_account']++;$d['accounts'][]=['id'=>$id,'product_id'=>$pid,'email'=>$email,'password'=>$pass,'status'=>'available','order_id'=>null];write_data($d);out(['ok'=>true,'message'=>'Conta adicionada ao estoque.']); }
 if($action==='admin_accounts') { $list=[];foreach($d['accounts'] as $a){$pname='Produto';foreach($d['products'] as $p)if((int)$p['id']===(int)$a['product_id'])$pname=$p['name'];$list[]=['id'=>$a['id'],'product_id'=>$a['product_id'],'product_name'=>$pname,'email'=>$a['email'],'status'=>$a['status']];}out(['ok'=>true,'accounts'=>$list]); }
 if($action==='delete_account') { $b=body_json();$id=(int)($b['id']??0);$d['accounts']=array_values(array_filter($d['accounts'],fn($a)=>(int)$a['id']!==$id || $a['status']!=='available'));write_data($d);out(['ok'=>true,'message'=>'Conta removida (se ainda estava disponível).']); }
 if($action==='admin_orders') { $list=[];foreach(array_reverse($d['orders']) as $o){$tok=$_SERVER['HTTP_X_ADMIN_TOKEN']??($_GET['admin_token']??'');$o['proof_url']=$o['proof']?('api.php?action=proof&id='.$o['id'].($tok?'&admin_token='.urlencode($tok):'')):'';unset($o['token']);$list[]=$o;}out(['ok'=>true,'orders'=>$list]); }
 if($action==='proof') { $id=(int)($_GET['id']??0);foreach($d['orders'] as $o)if((int)$o['id']===$id&&$o['proof']){$path=PROOF_DIR.basename($o['proof']);if(is_file($path)){header('Content-Type: '.(mime_content_type($path)?:'application/octet-stream'));header('Content-Disposition: inline; filename="comprovante"');readfile($path);exit;}}http_response_code(404);exit('Comprovante não encontrado.'); }
 if($action==='release_order') { $b=body_json();$id=(int)($b['id']??0);$oi=null;foreach($d['orders'] as $i=>$o)if((int)$o['id']===$id)$oi=$i;if($oi===null)out(['ok'=>false,'message'=>'Pedido não encontrado.'],404);if($d['orders'][$oi]['status']==='released')out(['ok'=>false,'message'=>'Pedido já liberado.']);$pid=(int)$d['orders'][$oi]['product_id'];$ai=null;foreach($d['accounts'] as $i=>$a)if((int)$a['product_id']===$pid&&$a['status']==='available'){$ai=$i;break;}if($ai===null)out(['ok'=>false,'message'=>'Não há conta disponível para este produto. Cadastre uma conta antes de liberar.'],409);$d['accounts'][$ai]['status']='delivered';$d['accounts'][$ai]['order_id']=$id;$d['orders'][$oi]['account_id']=$d['accounts'][$ai]['id'];$d['orders'][$oi]['status']='released';write_data($d);out(['ok'=>true,'message'=>'Conta liberada para o cliente.']); }
 out(['ok'=>false,'message'=>'Ação desconhecida.'],404);
} catch(Throwable $e) { out(['ok'=>false,'message'=>$e->getMessage()],500); }
