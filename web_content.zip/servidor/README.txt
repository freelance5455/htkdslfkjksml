VENOM STREAMING - PACOTE PWA/PHP

ARQUIVOS
- index.php: loja e interface administrativa.
- api.php: API, autenticação, produtos, estoque, pedidos, comprovantes e liberação.
- manifest.webmanifest + sw.js: instalação como aplicativo (PWA).
- storage/: dados privados em JSON.
- uploads/: imagens públicas dos produtos.
- proofs/: comprovantes privados.

INSTALAÇÃO NA INFINITYFREE
1. Envie TODO o conteúdo desta pasta para public_html (não envie a pasta externa venom_app como subpasta, a menos que queira o site em /venom_app).
2. Confirme que PHP 8+ está ativo.
3. Dê permissão de escrita para storage, uploads e proofs (normalmente 755; se a hospedagem exigir, 775).
4. Abra seu domínio em HTTPS. No Android/Chrome, menu ⋮ > Instalar app ou Adicionar à tela inicial.
5. A primeira abertura cria storage/data.json automaticamente.

ACESSO INICIAL DO ADM
Usuário: admin
Senha inicial: Venom@2026#Acesso
Entre pela engrenagem > Configurações e altere a senha/usuário.

PIX
Foi reaproveitada a chave Pix UUID que já estava embutida no HTML enviado: d7a1cf48-6ca7-4af2-bdc7-e2024f6edcb85.
O QR Code e o Pix Copia e Cola são gerados com o preço cadastrado no produto. Confira os dados do recebedor no seu banco antes de divulgar. Nome e cidade iniciais: PAULO GUILHERME DOS SANTO / Sao Paulo; ajuste na engrenagem se necessário.

FLUXO
- O cliente escolhe produto e gera pedido.
- O estoque disponível diminui quando uma conta é liberada; pedido sem estoque não é criado.
- O cliente envia comprovante (imagem até 5 MB); pedido fica PENDENTE.
- O administrador confere o comprovante e clica LIBERAR CONTA.
- O sistema associa uma conta disponível daquele produto e mostra e-mail/senha ao cliente na consulta do pedido.
- O cliente deve guardar o token/código exibido após enviar o comprovante. O botão Acompanhar pedido fica no canto inferior esquerdo.

SEGURANÇA E LIMITAÇÕES
- Produtos e quantidade em estoque são públicos; credenciais das contas e comprovantes não são expostos pelo endpoint público.
- Dados são armazenados em storage/data.json com bloqueio de escrita e proteção .htaccess. Mantenha backups regulares e HTTPS ativo.
- O pagamento NÃO é confirmado automaticamente pelo banco. O ADM precisa conferir o comprovante e o crédito na conta Pix antes de liberar.
- Esta versão não envia e-mail/notificação push automaticamente; o cliente consulta o pedido pelo token no próprio aplicativo.
- PWA instala pelo navegador e não é APK assinado da Play Store.
