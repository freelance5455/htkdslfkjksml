/* ============================================================
   Chat-I2 | ماژول ویژگی‌های پیشرفته
   شامل: Dark Mode, Forward, Edit, Delete, Pin, E2EE, Voice Call
   ============================================================ */

// ---------- ۱. Dark Mode ----------
function initTheme() {
    const savedTheme = localStorage.getItem('chat-i2-theme') || 'light';
    document.documentElement.setAttribute('data-theme', savedTheme);
    updateThemeButton();
}

function toggleTheme() {
    const current = document.documentElement.getAttribute('data-theme');
    const newTheme = current === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('chat-i2-theme', newTheme);
    updateThemeButton();
}

function updateThemeButton() {
    const btn = document.getElementById('themeBtn');
    if (btn) {
        const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
        btn.textContent = isDark ? '☀️' : '🌙';
    }
}

// ---------- ۲. E2EE (رمزنگاری سرتاسری) ----------
const E2EE = {
    keyPair: null,
    sharedKeys: {}, // uid -> CryptoKey

    async init() {
        // تولید جفت کلید ECDH برای این کاربر
        this.keyPair = await crypto.subtle.generateKey(
            { name: 'ECDH', namedCurve: 'P-256' },
            true,
            ['deriveKey']
        );
        // ذخیره کلید خصوصی در حافظه (در نسخه واقعی باید در IndexedDB ذخیره شود)
        console.log('✅ E2EE keys generated');
    },

    async exportPublicKey() {
        const raw = await crypto.subtle.exportKey('raw', this.keyPair.publicKey);
        return btoa(String.fromCharCode(...new Uint8Array(raw)));
    },

    async importPublicKey(base64) {
        const binary = atob(base64);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
        return crypto.subtle.importKey(
            'raw', bytes, { name: 'ECDH', namedCurve: 'P-256' }, true, []
        );
    },

    async deriveSharedKey(theirPublicKeyBase64) {
        const theirPublicKey = await this.importPublicKey(theirPublicKeyBase64);
        return crypto.subtle.deriveKey(
            { name: 'ECDH', public: theirPublicKey },
            this.keyPair.privateKey,
            { name: 'AES-GCM', length: 256 },
            false,
            ['encrypt', 'decrypt']
        );
    },

    async encrypt(sharedKey, plaintext) {
        const iv = crypto.getRandomValues(new Uint8Array(12));
        const encrypted = await crypto.subtle.encrypt(
            { name: 'AES-GCM', iv },
            sharedKey,
            new TextEncoder().encode(plaintext)
        );
        return {
            iv: btoa(String.fromCharCode(...iv)),
            ciphertext: btoa(String.fromCharCode(...new Uint8Array(encrypted)))
        };
    },

    async decrypt(sharedKey, encryptedData) {
        const iv = Uint8Array.from(atob(encryptedData.iv), c => c.charCodeAt(0));
        const ciphertext = Uint8Array.from(atob(encryptedData.ciphertext), c => c.charCodeAt(0));
        const decrypted = await crypto.subtle.decrypt(
            { name: 'AES-GCM', iv },
            sharedKey,
            ciphertext
        );
        return new TextDecoder().decode(decrypted);
    }
};

// ---------- ۳. WebRTC Voice Call ----------
const VoiceCall = {
    peerConnection: null,
    localStream: null,
    currentCallUser: null,
    isCallActive: false,

    async startCall(uid, name) {
        this.currentCallUser = { uid, name };
        this.isCallActive = true;

        // نمایش Overlay
        this.showCallOverlay(name, 'در حال تماس...');

        try {
            // دریافت میکروفون
            this.localStream = await navigator.mediaDevices.getUserMedia({ audio: true });

            // ساخت PeerConnection
            this.peerConnection = new RTCPeerConnection({
                iceServers: [{ urls: 'stun:stun.l.google.com:19302' }]
            });

            // اضافه کردن track صوتی
            this.localStream.getTracks().forEach(track => {
                this.peerConnection.addTrack(track, this.localStream);
            });

            // ارسال ICE candidates از طریق Ably
            this.peerConnection.onicecandidate = (event) => {
                if (event.candidate) {
                    sendWS({
                        type: 'call_ice',
                        to: uid,
                        from: currentUser.uid,
                        candidate: event.candidate
                    });
                }
            };

            // دریافت track از طرف مقابل
            this.peerConnection.ontrack = (event) => {
                const remoteAudio = new Audio();
                remoteAudio.srcObject = event.streams[0];
                remoteAudio.play();
                this.updateCallStatus('در حال مکالمه');
            };

            // ساخت Offer
            const offer = await this.peerConnection.createOffer();
            await this.peerConnection.setLocalDescription(offer);

            // ارسال Offer از طریق Ably
            sendWS({
                type: 'call_offer',
                to: uid,
                from: currentUser.uid,
                fromName: currentUser.name,
                sdp: offer
            });

        } catch (err) {
            console.error('Call error:', err);
            alert('دسترسی به میکروفون ممکن نیست');
            this.endCall();
        }
    },

    async handleOffer(msg) {
        if (this.isCallActive) {
            // اگر در حال تماس با کسی هستیم، رد کن
            sendWS({ type: 'call_reject', to: msg.from, from: currentUser.uid });
            return;
        }

        // نمایش پرسش برای پذیرش
        const accept = confirm(`${msg.fromName} در حال تماس با شماست. پاسخ می‌دهید؟`);
        if (!accept) {
            sendWS({ type: 'call_reject', to: msg.from, from: currentUser.uid });
            return;
        }

        this.currentCallUser = { uid: msg.from, name: msg.fromName };
        this.isCallActive = true;
        this.showCallOverlay(msg.fromName, 'در حال اتصال...');

        try {
            this.localStream = await navigator.mediaDevices.getUserMedia({ audio: true });

            this.peerConnection = new RTCPeerConnection({
                iceServers: [{ urls: 'stun:stun.l.google.com:19302' }]
            });

            this.localStream.getTracks().forEach(track => {
                this.peerConnection.addTrack(track, this.localStream);
            });

            this.peerConnection.onicecandidate = (event) => {
                if (event.candidate) {
                    sendWS({
                        type: 'call_ice',
                        to: msg.from,
                        from: currentUser.uid,
                        candidate: event.candidate
                    });
                }
            };

            this.peerConnection.ontrack = (event) => {
                const remoteAudio = new Audio();
                remoteAudio.srcObject = event.streams[0];
                remoteAudio.play();
                this.updateCallStatus('در حال مکالمه');
            };

            await this.peerConnection.setRemoteDescription(new RTCSessionDescription(msg.sdp));
            const answer = await this.peerConnection.createAnswer();
            await this.peerConnection.setLocalDescription(answer);

            sendWS({
                type: 'call_answer',
                to: msg.from,
                from: currentUser.uid,
                sdp: answer
            });

        } catch (err) {
            console.error('Answer error:', err);
            this.endCall();
        }
    },

    async handleAnswer(msg) {
        if (!this.peerConnection) return;
        try {
            await this.peerConnection.setRemoteDescription(new RTCSessionDescription(msg.sdp));
            this.updateCallStatus('در حال مکالمه');
        } catch (err) {
            console.error('Handle answer error:', err);
        }
    },

    async handleIce(msg) {
        if (!this.peerConnection) return;
        try {
            await this.peerConnection.addIceCandidate(new RTCIceCandidate(msg.candidate));
        } catch (err) {
            console.error('ICE error:', err);
        }
    },

    showCallOverlay(name, status) {
        let overlay = document.getElementById('callOverlay');
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.id = 'callOverlay';
            overlay.className = 'call-overlay';
            document.body.appendChild(overlay);
        }
        overlay.innerHTML = `
            <div class="call-avatar">${name.charAt(0).toUpperCase()}</div>
            <h2>${name}</h2>
            <p style="opacity:0.7;margin-top:10px;">${status}</p>
            <div class="call-actions">
                <button class="call-btn mute" id="muteCallBtn">🎤</button>
                <button class="call-btn end" id="endCallBtn">📞</button>
            </div>
        `;
        overlay.style.display = 'flex';
        document.getElementById('endCallBtn').onclick = () => this.endCall();
        document.getElementById('muteCallBtn').onclick = (e) => {
            const track = this.localStream.getAudioTracks()[0];
            track.enabled = !track.enabled;
            e.target.textContent = track.enabled ? '🎤' : '🔇';
        };
    },

    updateCallStatus(status) {
        const el = document.querySelector('.call-overlay p');
        if (el) el.textContent = status;
    },

    endCall() {
        if (this.peerConnection) {
            this.peerConnection.close();
            this.peerConnection = null;
        }
        if (this.localStream) {
            this.localStream.getTracks().forEach(t => t.stop());
            this.localStream = null;
        }
        if (this.currentCallUser) {
            sendWS({ type: 'call_end', to: this.currentCallUser.uid, from: currentUser.uid });
        }
        this.isCallActive = false;
        this.currentCallUser = null;
        const overlay = document.getElementById('callOverlay');
        if (overlay) overlay.style.display = 'none';
    }
};

// ---------- ۴. Pin / Archive / Forward ----------
function togglePinChat(type, id) {
    if (type === 'user') return; // فقط برای گروه و کانال
    const obj = type === 'group' ? groups[id] : channels[id];
    if (!obj) return;
    obj.pinned = !obj.pinned;
    type === 'group' ? persistGroups() : persistChannels();
    renderAllLists();
}

function toggleArchiveChat(type, id) {
    if (type === 'user') return;
    const obj = type === 'group' ? groups[id] : channels[id];
    if (!obj) return;
    obj.archived = !obj.archived;
    type === 'group' ? persistGroups() : persistChannels();
    renderAllLists();
}

// اصلاح renderGroupsList و renderChannelsList برای اعمال Pin و Archive
const _origRenderGroups = renderGroupsList;
renderGroupsList = function() {
    const all = Object.values(groups).filter(g => g.members && g.members.includes(currentUser.uid));
    const pinned = all.filter(g => g.pinned && !g.archived).sort((a,b) => (b.unread||0)-(a.unread||0));
    const normal = all.filter(g => !g.pinned && !g.archived).sort((a,b) => (b.unread||0)-(a.unread||0));
    const archived = all.filter(g => g.archived).sort((a,b) => (b.unread||0)-(a.unread||0));
    renderGenericList(groupsList, [...pinned, ...normal, ...archived], 'group', 'data-open-group');
};

const _origRenderChannels = renderChannelsList;
renderChannelsList = function() {
    const all = Object.values(channels).filter(c => c.mode === 'public' || (c.subscribers && c.subscribers.includes(currentUser.uid)));
    const pinned = all.filter(c => c.pinned && !c.archived).sort((a,b) => (b.unread||0)-(a.unread||0));
    const normal = all.filter(c => !c.pinned && !c.archived).sort((a,b) => (b.unread||0)-(a.unread||0));
    const archived = all.filter(c => c.archived).sort((a,b) => (b.unread||0)-(a.unread||0));
    renderGenericList(channelsList, [...pinned, ...normal, ...archived], 'channel', 'data-open-channel');
};

function renderGenericList(container, list, type, attr) {
    if (list.length === 0) {
        container.innerHTML = `<div class="empty-users"><div class="big-icon">${type === 'group' ? '👨‍👩‍👧' : '📢'}</div>موردی نیست.</div>`;
        return;
    }
    container.innerHTML = list.map(item => {
        const initial = (item.name || '?').charAt(0).toUpperCase();
        const lastMsg = item.lastMessage ? escapeHtml(item.lastMessage.slice(0, 40)) : (item.desc || '');
        const unread = item.unread ? `<span class="unread-badge">${item.unread}</span>` : '';
        const pinBadge = item.pinned ? '📌 ' : '';
        const archiveBadge = item.archived ? '📦 ' : '';
        const typeBadge = type === 'group' ? `${item.members.length} عضو` : `${item.subscribers.length} عضو`;
        return `<div class="user-item" ${attr}="${item.id}" style="${item.archived ? 'opacity:0.6;' : ''}">
            <div class="user-avatar ${type}">${initial}</div>
            <div class="user-info">
                <div class="name">${pinBadge}${archiveBadge}${escapeHtml(item.name)}<span class="type-badge ${type}">${typeBadge}</span></div>
                <div class="lastmsg">${lastMsg}</div>
            </div>${unread}</div>`;
    }).join('');
    container.querySelectorAll(`[${attr}]`).forEach(el => {
        el.addEventListener('click', () => type === 'group' ? openGroupChat(el.getAttribute(attr)) : openChannelChat(el.getAttribute(attr)));
    });
}

// ---------- ۵. اضافه کردن دکمه‌ها به هدر ----------
function addHeaderButtons() {
    const headerBtns = document.querySelector('.header-btns');
    if (!headerBtns) return;

    // Dark Mode
    const themeBtn = document.createElement('button');
    themeBtn.className = 'icon-btn';
    themeBtn.id = 'themeBtn';
    themeBtn.title = 'حالت تاریک/روشن';
    themeBtn.onclick = toggleTheme;
    headerBtns.insertBefore(themeBtn, headerBtns.firstChild);
    updateThemeButton();

    // Call Button در هدر چت
    const chatHeader = document.querySelector('.chat-header');
    if (chatHeader) {
        const callBtn = document.createElement('button');
        callBtn.className = 'icon-btn';
        callBtn.id = 'callBtn';
        callBtn.title = 'تماس صوتی';
        callBtn.textContent = '📞';
        callBtn.onclick = () => {
            if (!currentChat || currentChat.type !== 'user') {
                alert('فقط در چت خصوصی می‌توانید تماس بگیرید');
                return;
            }
            const peerPubKey = allUsersRegistry[currentChat.id]?.publicKey;
            VoiceCall.startCall(currentChat.id, currentChat.name);
        };
        // اضافه کردن قبل از دکمه اطلاعات
        const infoBtn = chatHeader.querySelector('#chatInfoBtn');
        if (infoBtn) chatHeader.insertBefore(callBtn, infoBtn);
    }
}

// ---------- راه‌اندازی ----------
document.addEventListener('DOMContentLoaded', async () => {
    initTheme();
    await E2EE.init();
    addHeaderButtons();
    console.log('✅ Advanced features loaded');
});

// شنونده برای پیام‌های WebRTC و E2EE
// این بخش باید در handleIncomingMessage اصلی ادغام شود، اما برای سادگی
// از یک MutationObserver یا تزریق به sendWS استفاده می‌کنیم.
// در اینجا یک listener روی Ably اضافه می‌کنیم:
if (ablyChannel) {
    ablyChannel.subscribe('message', (msg) => {
        try {
            const data = typeof msg.data === 'string' ? JSON.parse(msg.data) : msg.data;
            if (data.type === 'call_offer') VoiceCall.handleOffer(data);
            else if (data.type === 'call_answer') VoiceCall.handleAnswer(data);
            else if (data.type === 'call_ice') VoiceCall.handleIce(data);
            else if (data.type === 'call_end') VoiceCall.endCall();
            else if (data.type === 'call_reject') {
                alert('تماس رد شد');
                VoiceCall.endCall();
            }
        } catch (e) {}
    });
}