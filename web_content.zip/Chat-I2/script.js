/* ============================================================
   Chat-I2 | Real-time Messenger with Profiles & Contacts
   ============================================================ */

// ⚠️ کلید Ably خودت را اینجا بگذار
const ABLY_API_KEY = "ZIKwlA.gu6cag:exXhcj4ZdkkwAawN6k1B-UAPjV0vi3S4dLxaveZMmiA";

/* ============================================================
   IndexedDB
   ============================================================ */
const DB_NAME = 'chat-i2-db';
const DB_VERSION = 2;
let db = null;

function openDB() {
    return new Promise((resolve) => {
        const req = indexedDB.open(DB_NAME, DB_VERSION);
        req.onupgradeneeded = (e) => {
            const database = e.target.result;
            if (!database.objectStoreNames.contains('kv')) {
                database.createObjectStore('kv', { keyPath: 'key' });
            }
        };
        req.onsuccess = (e) => { db = e.target.result; resolve(db); };
        req.onerror = () => resolve(null);
    });
}

function dbGet(key) {
    return new Promise((resolve) => {
        if (!db) return resolve(null);
        const tx = db.transaction('kv', 'readonly');
        const req = tx.objectStore('kv').get(key);
        req.onsuccess = () => resolve(req.result ? req.result.value : null);
        req.onerror = () => resolve(null);
    });
}

function dbSet(key, value) {
    return new Promise((resolve) => {
        if (!db) return resolve();
        const tx = db.transaction('kv', 'readwrite');
        tx.objectStore('kv').put({ key, value });
        tx.oncomplete = () => resolve();
        tx.onerror = () => resolve();
    });
}

const saveTimers = {};
function scheduleSave(key, value, delay = 500) {
    if (saveTimers[key]) clearTimeout(saveTimers[key]);
    saveTimers[key] = setTimeout(() => dbSet(key, value), delay);
}

async function loadPersistedData() {
    try {
        const g = await dbGet('groups');
        const c = await dbGet('channels');
        const mh = await dbGet('messageHistory');
        const r = await dbGet('reactions');
        const read = await dbGet('readStatus');
        const contacts = await dbGet('contacts');
        const allUsers = await dbGet('allUsers');
        if (g) groups = g;
        if (c) channels = c;
        if (mh) messageHistory = mh;
        if (r) reactions = r;
        if (read) readStatus = read;
        if (contacts) contacts = contacts;
        if (allUsers) allUsersRegistry = allUsers;
    } catch (e) { console.warn('Load error', e); }
}

function persistGroups() { scheduleSave('groups', groups); }
function persistChannels() { scheduleSave('channels', channels); }
function persistHistory() { scheduleSave('messageHistory', messageHistory); }
function persistReactions() { scheduleSave('reactions', reactions); }
function persistReadStatus() { scheduleSave('readStatus', readStatus); }
function persistContacts() { scheduleSave('contacts', contacts); }
function persistAllUsers() { scheduleSave('allUsers', allUsersRegistry); }

/* ============================================================
   State
   ============================================================ */
let ably = null;
let ablyChannel = null;
let currentUser = null;
let currentChat = null;
let onlineUsers = {};      // uid -> { name, username, avatar, bio, lastSeen, unread, lastMessage }
let allUsersRegistry = {}; // uid -> { uid, name, username, avatar, bio }  (همه کاربران شناخته‌شده)
let contacts = {};         // uid -> { uid, name, username, avatar }
let groups = {};
let channels = {};
let messageHistory = {};
let reactions = {};
let readStatus = {};
let heartbeatTimer = null;
let cleanupInterval = null;
let notifEnabled = false;
let currentChatImageAttachment = null;
let replyingTo = null;
let mediaRecorder = null;
let audioChunks = [];
let recordingStartTime = 0;
let recordingTimer = null;
let isRecording = false;
let isCancelledRecording = false;
let profileAvatarData = null;
let pendingAvatarData = null;

/* ============================================================
   المان‌ها
   ============================================================ */
const authScreen = document.getElementById('authScreen');
const mainScreen = document.getElementById('mainScreen');
const chatScreen = document.getElementById('chatScreen');
const chatsList = document.getElementById('chatsList');
const contactsList = document.getElementById('contactsList');
const groupsList = document.getElementById('groupsList');
const channelsList = document.getElementById('channelsList');
const chatMessages = document.getElementById('chatMessages');
const messageInput = document.getElementById('messageInput');
const sendBtn = document.getElementById('sendBtn');
const authError = document.getElementById('authError');
const nameInput = document.getElementById('nameInput');
const usernameInput = document.getElementById('usernameInput');
const authSubmit = document.getElementById('authSubmit');
const connDot = document.getElementById('connDot');
const connText = document.getElementById('connText');
const myInfo = document.getElementById('myInfo');
const myAvatar = document.getElementById('myAvatar');
const createModal = document.getElementById('createModal');
const infoModal = document.getElementById('infoModal');
const profileModal = document.getElementById('profileModal');
const addContactModal = document.getElementById('addContactModal');
const chatInputBar = document.getElementById('chatInputBar');
const readonlyBar = document.getElementById('readonlyBar');
const imageInput = document.getElementById('imageInput');
const attachBtn = document.getElementById('attachBtn');
const micBtn = document.getElementById('micBtn');
const lightbox = document.getElementById('lightbox');
const lightboxImg = document.getElementById('lightboxImg');
const notifBtn = document.getElementById('notifBtn');
const chatSearchBar = document.getElementById('chatSearchBar');
const chatSearchInput = document.getElementById('chatSearchInput');
const searchChatBtn = document.getElementById('searchChatBtn');
const replyPreview = document.getElementById('replyPreview');
const replyName = document.getElementById('replyName');
const replyText = document.getElementById('replyText');
const voiceRecordOverlay = document.getElementById('voiceRecordOverlay');
const voiceRecordTime = document.getElementById('voiceRecordTime');
const voiceCancelBtn = document.getElementById('voiceCancelBtn');
const voiceSendBtn = document.getElementById('voiceSendBtn');

/* ============================================================
   Ably Connection
   ============================================================ */
function connectAbly() {
    setConnStatus('connecting', 'در حال اتصال...');
    try {
        if (ably) { try { ably.close(); } catch (e) {} }
        if (!ABLY_API_KEY || ABLY_API_KEY.includes('YOUR_') || !ABLY_API_KEY.includes(':')) {
            setConnStatus('offline', 'کلید Ably تنظیم نشده');
            console.error('❌ ABLY_API_KEY را تنظیم کنید');
            return;
        }

        ably = new Ably.Realtime({
            key: ABLY_API_KEY,
            clientId: currentUser ? currentUser.uid : 'anon_' + Math.random().toString(36).slice(2, 8),
            disconnectedRetryTimeout: 5000,
            suspendedRetryTimeout: 10000
        });

        ablyChannel = ably.channels.get('chat-i2-public-room');

        ably.connection.on('connected', () => {
            console.log('✅ Ably Connected');
            setConnStatus('online', 'متصل ✅');
            startHeartbeat();
            if (currentUser) {
                announcePresence();
                broadcastGroupsChannels();
            }
        });

        ably.connection.on('disconnected', () => {
            setConnStatus('offline', 'قطع شد - تلاش مجدد...');
            stopHeartbeat();
        });

        ably.connection.on('suspended', () => {
            setConnStatus('offline', 'اتصال معلق - تلاش مجدد...');
            stopHeartbeat();
        });

        ably.connection.on('failed', (err) => {
            console.error('❌ Ably Failed:', err);
            setConnStatus('offline', 'خطا در اتصال');
            stopHeartbeat();
            setTimeout(connectAbly, 5000);
        });

        ablyChannel.subscribe('message', (msg) => {
            try {
                const data = typeof msg.data === 'string' ? JSON.parse(msg.data) : msg.data;
                handleIncomingMessage(data);
            } catch (e) {}
        });
    } catch (e) {
        console.error(e);
        setConnStatus('offline', 'خطا در اتصال');
        setTimeout(connectAbly, 5000);
    }
}

function setConnStatus(status, text) {
    connDot.className = 'conn-dot ' + status;
    connText.textContent = text;
}

function sendWS(obj) {
    if (ablyChannel && ably && ably.connection.state === 'connected') {
        ablyChannel.publish('message', obj);
        return true;
    }
    return false;
}

function startHeartbeat() {
    stopHeartbeat();
    heartbeatTimer = setInterval(() => {
        if (ably && ably.connection.state === 'connected') {
            sendWS({ type: 'ping', uid: currentUser ? currentUser.uid : 'anon', time: Date.now() });
        }
    }, 25000);
}

function stopHeartbeat() {
    if (heartbeatTimer) { clearInterval(heartbeatTimer); heartbeatTimer = null; }
}

/* ============================================================
   نوتیفیکیشن
   ============================================================ */
async function requestNotification() {
    if (!('Notification' in window)) { alert('مرورگر پشتیبانی نمی‌کند'); return; }
    const perm = await Notification.requestPermission();
    if (perm === 'granted') {
        notifEnabled = true;
        notifBtn.classList.add('active-notif');
        try { new Notification('Chat-I2', { body: 'نوتیفیکیشن فعال شد ✅' }); } catch (e) {}
    } else alert('اجازه داده نشد');
}

function showNotification(title, body) {
    if (!notifEnabled) return;
    if (document.visibilityState === 'visible' && currentChat && currentChat.name === title) return;
    try {
        new Notification('Chat-I2 - ' + title, { body: String(body).slice(0, 100) });
    } catch (e) {}
}

notifBtn.addEventListener('click', () => {
    if (notifEnabled) {
        notifEnabled = false;
        notifBtn.classList.remove('active-notif');
        alert('خاموش شد');
    } else requestNotification();
});

/* ============================================================
   ثبت‌نام
   ============================================================ */
authSubmit.addEventListener('click', async () => {
    const name = nameInput.value.trim();
    const username = usernameInput.value.trim().toLowerCase();

    if (!name || name.length < 2) {
        authError.textContent = 'نام باید حداقل ۲ کاراکتر باشد';
        return;
    }
    if (!username || username.length < 3) {
        authError.textContent = 'نام کاربری باید حداقل ۳ کاراکتر باشد';
        return;
    }
    if (!/^[a-z0-9_]+$/.test(username)) {
        authError.textContent = 'نام کاربری فقط حروف انگلیسی، عدد و _';
        return;
    }

    authError.textContent = 'ثبت‌نام...';

    // بررسی یکتایی نام کاربری
    const existing = Object.values(allUsersRegistry).find(u => u.username === username);
    if (existing) {
        authError.textContent = 'این نام کاربری قبلاً گرفته شده';
        return;
    }

    const uid = 'u_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8);
    currentUser = {
        uid, name, username,
        avatar: null,
        bio: ''
    };

    // ثبت در رجیستری
    allUsersRegistry[uid] = { ...currentUser };
    persistAllUsers();

    localStorage.setItem('chat-i2-user', JSON.stringify(currentUser));
    authError.textContent = '';
    enterApp();
});

async function checkAutoLogin() {
    const saved = localStorage.getItem('chat-i2-user');
    if (saved) {
        try {
            currentUser = JSON.parse(saved);
            // اطمینان از وجود در رجیستری
            if (!allUsersRegistry[currentUser.uid]) {
                allUsersRegistry[currentUser.uid] = { ...currentUser };
                persistAllUsers();
            }
            await loadPersistedData();
            enterApp();
            return true;
        } catch (e) {}
    }
    await loadPersistedData();
    return false;
}

function enterApp() {
    authScreen.classList.add('hidden');
    mainScreen.classList.remove('hidden');
    chatScreen.classList.add('hidden');

    updateMyInfo();
    announcePresence();
    broadcastGroupsChannels();
    renderAllLists();

    if (!ably || ably.connection.state !== 'connected') connectAbly();

    if (cleanupInterval) clearInterval(cleanupInterval);
    cleanupInterval = setInterval(() => {
        announcePresence();
        cleanInactiveUsers();
        renderAllLists();
    }, 15000);
}

function updateMyInfo() {
    myInfo.textContent = `${currentUser.name} • @${currentUser.username}`;
    if (currentUser.avatar) {
        myAvatar.style.backgroundImage = `url(${currentUser.avatar})`;
        myAvatar.style.backgroundSize = 'cover';
        myAvatar.textContent = '';
    } else {
        myAvatar.style.backgroundImage = '';
        myAvatar.textContent = currentUser.name.charAt(0).toUpperCase();
    }
}

document.getElementById('logoutBtn').addEventListener('click', () => {
    if (!confirm('از حساب خارج می‌شوید؟')) return;
    localStorage.removeItem('chat-i2-user');
    sendWS({ type: 'leave', uid: currentUser.uid });
    stopHeartbeat();
    currentUser = null;
    currentChat = null;
    onlineUsers = {};
    authScreen.classList.remove('hidden');
    mainScreen.classList.add('hidden');
    chatScreen.classList.add('hidden');
    nameInput.value = '';
    usernameInput.value = '';
});

function announcePresence() {
    if (!currentUser) return;
    sendWS({
        type: 'presence',
        uid: currentUser.uid,
        name: currentUser.name,
        username: currentUser.username,
        avatar: currentUser.avatar || null,
        bio: currentUser.bio || ''
    });
}

/* ============================================================
   پروفایل
   ============================================================ */
myAvatar.addEventListener('click', () => openProfileModal());

function openProfileModal() {
    document.getElementById('profileName').value = currentUser.name || '';
    document.getElementById('profileUsername').value = currentUser.username || '';
    document.getElementById('profileBio').value = currentUser.bio || '';
    document.getElementById('profileError').textContent = '';
    pendingAvatarData = currentUser.avatar || null;
    renderProfileAvatar();
    profileModal.classList.remove('hidden');
}

function renderProfileAvatar() {
    const el = document.getElementById('profileAvatar');
    if (pendingAvatarData) {
        el.style.backgroundImage = `url(${pendingAvatarData})`;
        el.style.backgroundSize = 'cover';
        el.textContent = '';
    } else {
        el.style.backgroundImage = '';
        el.textContent = (document.getElementById('profileName').value || currentUser.name || '?').charAt(0).toUpperCase();
    }
}

document.getElementById('profileName').addEventListener('input', renderProfileAvatar);

document.getElementById('avatarInput').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) { alert('فقط عکس'); return; }
    if (file.size > 5 * 1024 * 1024) { alert('حداکثر ۵ مگابایت'); return; }
    try {
        pendingAvatarData = await compressImage(file, 300, 0.8);
        renderProfileAvatar();
    } catch (err) { alert('خطا در پردازش'); }
    e.target.value = '';
});

document.getElementById('closeProfileBtn').addEventListener('click', () => profileModal.classList.add('hidden'));
document.getElementById('cancelProfileBtn').addEventListener('click', () => profileModal.classList.add('hidden'));

document.getElementById('saveProfileBtn').addEventListener('click', async () => {
    const newName = document.getElementById('profileName').value.trim();
    const newUsername = document.getElementById('profileUsername').value.trim().toLowerCase();
    const newBio = document.getElementById('profileBio').value.trim();
    const errEl = document.getElementById('profileError');

    if (!newName || newName.length < 2) { errEl.textContent = 'نام حداقل ۲ کاراکتر'; return; }
    if (!newUsername || newUsername.length < 3) { errEl.textContent = 'نام کاربری حداقل ۳ کاراکتر'; return; }
    if (!/^[a-z0-9_]+$/.test(newUsername)) { errEl.textContent = 'نام کاربری فقط انگلیسی، عدد و _'; return; }

    // بررسی یکتایی (به جز خودم)
    const existing = Object.values(allUsersRegistry).find(u =>
        u.username === newUsername && u.uid !== currentUser.uid
    );
    if (existing) { errEl.textContent = 'این نام کاربری گرفته شده'; return; }

    currentUser.name = newName;
    currentUser.username = newUsername;
    currentUser.bio = newBio;
    currentUser.avatar = pendingAvatarData;

    allUsersRegistry[currentUser.uid] = { ...currentUser };
    persistAllUsers();
    localStorage.setItem('chat-i2-user', JSON.stringify(currentUser));

    updateMyInfo();
    announcePresence();
    sendWS({
        type: 'profile_update',
        uid: currentUser.uid,
        name: currentUser.name,
        username: currentUser.username,
        avatar: currentUser.avatar,
        bio: currentUser.bio
    });

    profileModal.classList.add('hidden');
});

/* ============================================================
   افزودن مخاطب
   ============================================================ */
document.getElementById('addContactBtn').addEventListener('click', () => {
    document.getElementById('searchUsernameInput').value = '';
    document.getElementById('addContactError').textContent = '';
    document.getElementById('searchResultArea').innerHTML = '';
    addContactModal.classList.remove('hidden');
});

document.getElementById('closeAddContactBtn').addEventListener('click', () => addContactModal.classList.add('hidden'));

document.getElementById('searchUserBtn').addEventListener('click', () => {
    const q = document.getElementById('searchUsernameInput').value.trim().toLowerCase();
    const errEl = document.getElementById('addContactError');
    const resultArea = document.getElementById('searchResultArea');

    errEl.textContent = '';
    resultArea.innerHTML = '';

    if (!q || q.length < 2) { errEl.textContent = 'حداقل ۲ کاراکتر وارد کن'; return; }

    const found = Object.values(allUsersRegistry).find(u =>
        u.username === q && u.uid !== currentUser.uid
    );

    if (!found) {
        resultArea.innerHTML = `<div class="empty-users" style="padding:20px;"><div class="big-icon">🔍</div>کاربری با این نام کاربری پیدا نشد</div>`;
        return;
    }

    const alreadyContact = !!contacts[found.uid];
    const initial = found.avatar
        ? `<div class="user-avatar" style="background-image:url(${found.avatar});background-size:cover;"></div>`
        : `<div class="user-avatar">${(found.name || '?').charAt(0).toUpperCase()}</div>`;

    resultArea.innerHTML = `
        <div class="user-item" style="margin-top:14px;">
            ${initial}
            <div class="user-info">
                <div class="name">${escapeHtml(found.name)}</div>
                <div class="lastmsg">@${escapeHtml(found.username)}</div>
            </div>
            ${alreadyContact
                ? '<span style="color:#4ade80;font-size:12px;">✓ مخاطب</span>'
                : `<button class="create-btn" id="doAddContactBtn" style="padding:8px 14px;font-size:13px;border-radius:10px;">افزودن</button>`
            }
        </div>
    `;

    if (!alreadyContact) {
        document.getElementById('doAddContactBtn').addEventListener('click', () => {
            contacts[found.uid] = {
                uid: found.uid,
                name: found.name,
                username: found.username,
                avatar: found.avatar || null
            };
            persistContacts();
            renderAllLists();
            addContactModal.classList.add('hidden');
            alert(`«${found.name}» به مخاطبین اضافه شد ✅`);
        });
    }
});

document.getElementById('searchUsernameInput').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') document.getElementById('searchUserBtn').click();
});

/* ============================================================
   دریافت پیام‌ها
   ============================================================ */
function handleIncomingMessage(msg) {
    if (!currentUser) return;
    if (msg.uid === currentUser.uid) return;

    // اگر کاربر جدیدی است که نمی‌شناسیم، به رجیستری اضافه کن
    if (msg.uid && msg.name && msg.type !== 'ping' && msg.type !== 'leave') {
        if (!allUsersRegistry[msg.uid]) {
            allUsersRegistry[msg.uid] = {
                uid: msg.uid,
                name: msg.name,
                username: msg.username || 'user_' + msg.uid.slice(-5),
                avatar: msg.avatar || null,
                bio: msg.bio || ''
            };
            persistAllUsers();
        } else {
            // بروزرسانی
            if (msg.name) allUsersRegistry[msg.uid].name = msg.name;
            if (msg.username) allUsersRegistry[msg.uid].username = msg.username;
            if (msg.avatar !== undefined) allUsersRegistry[msg.uid].avatar = msg.avatar;
            if (msg.bio !== undefined) allUsersRegistry[msg.uid].bio = msg.bio;
        }
    }

    switch (msg.type) {
        case 'ping': break;

        case 'presence':
            if (msg.uid) {
                onlineUsers[msg.uid] = onlineUsers[msg.uid] || {};
                onlineUsers[msg.uid].name = msg.name;
                onlineUsers[msg.uid].username = msg.username;
                onlineUsers[msg.uid].avatar = msg.avatar || null;
                onlineUsers[msg.uid].bio = msg.bio || '';
                onlineUsers[msg.uid].lastSeen = Date.now();
                renderAllLists();
            }
            break;

        case 'profile_update':
            if (msg.uid && allUsersRegistry[msg.uid]) {
                allUsersRegistry[msg.uid].name = msg.name;
                allUsersRegistry[msg.uid].username = msg.username;
                allUsersRegistry[msg.uid].avatar = msg.avatar;
                allUsersRegistry[msg.uid].bio = msg.bio;
                persistAllUsers();
                if (onlineUsers[msg.uid]) {
                    onlineUsers[msg.uid].name = msg.name;
                    onlineUsers[msg.uid].username = msg.username;
                    onlineUsers[msg.uid].avatar = msg.avatar;
                }
                // بروزرسانی مخاطبین
                if (contacts[msg.uid]) {
                    contacts[msg.uid].name = msg.name;
                    contacts[msg.uid].username = msg.username;
                    contacts[msg.uid].avatar = msg.avatar;
                    persistContacts();
                }
                renderAllLists();
                if (currentChat && currentChat.id === msg.uid) {
                    setupChatUI(msg.name, 'آنلاین', 'user');
                }
            }
            break;

        case 'chat': handleIncomingChat(msg); break;

        case 'group_create':
        case 'group_update':
            if (msg.group && msg.group.id) {
                const existing = groups[msg.group.id];
                groups[msg.group.id] = { ...msg.group, messages: existing?.messages, unread: existing?.unread, lastMessage: existing?.lastMessage };
                persistGroups();
                renderAllLists();
            }
            break;

        case 'channel_create':
        case 'channel_update':
            if (msg.channel && msg.channel.id) {
                const existing = channels[msg.channel.id];
                channels[msg.channel.id] = { ...msg.channel, messages: existing?.messages, unread: existing?.unread, lastMessage: existing?.lastMessage };
                persistChannels();
                renderAllLists();
            }
            break;

        case 'group_message': handleGroupMessage(msg); break;
        case 'channel_message': handleChannelMessage(msg); break;
        case 'reaction': handleReaction(msg); break;
        case 'read_receipt': handleReadReceipt(msg); break;

        case 'leave':
            if (msg.uid && onlineUsers[msg.uid]) {
                delete onlineUsers[msg.uid];
                renderAllLists();
            }
            break;
    }
}

function handleIncomingChat(msg) {
    const chatKey = 'user_' + msg.uid;
    if (!messageHistory[chatKey]) messageHistory[chatKey] = [];
    const msgObj = {
        id: msg.msgId || 'm_' + Date.now(),
        text: msg.text || '', time: msg.time, from: msg.uid,
        senderName: msg.name,
        image: msg.image || null,
        voice: msg.voice || null,
        voiceDuration: msg.voiceDuration || 0,
        replyTo: msg.replyTo || null
    };
    messageHistory[chatKey].push(msgObj);
    persistHistory();

    sendWS({ type: 'read_receipt', uid: currentUser.uid, msgId: msgObj.id });

    if (currentChat && currentChat.type === 'user' && currentChat.id === msg.uid) {
        addMessageToChat(msgObj, 'received');
    } else {
        onlineUsers[msg.uid] = onlineUsers[msg.uid] || { name: msg.name };
        onlineUsers[msg.uid].lastMessage = msg.image ? '📷 عکس' : msg.voice ? '🎤 ویس' : msg.text;
        onlineUsers[msg.uid].unread = (onlineUsers[msg.uid].unread || 0) + 1;
        renderAllLists();
        showNotification(msg.name, msg.image ? '📷 عکس فرستاد' : msg.voice ? '🎤 ویس فرستاد' : msg.text);
    }
}

function handleGroupMessage(msg) {
    const g = groups[msg.groupId];
    if (!g || !g.members || !g.members.includes(currentUser.uid)) return;
    const chatKey = 'group_' + msg.groupId;
    if (!messageHistory[chatKey]) messageHistory[chatKey] = [];
    const msgObj = {
        id: msg.msgId || 'm_' + Date.now(),
        text: msg.text || '', time: msg.time, from: msg.uid,
        senderName: msg.name, image: msg.image || null,
        voice: msg.voice || null, voiceDuration: msg.voiceDuration || 0,
        replyTo: msg.replyTo || null
    };
    messageHistory[chatKey].push(msgObj);
    persistHistory();
    sendWS({ type: 'read_receipt', uid: currentUser.uid, msgId: msgObj.id });

    if (currentChat && currentChat.type === 'group' && currentChat.id === msg.groupId) {
        addMessageToChat(msgObj, 'received');
    } else {
        g.unread = (g.unread || 0) + 1;
        g.lastMessage = msg.image ? '📷 عکس' : msg.voice ? '🎤 ویس' : msg.text;
        persistGroups(); renderAllLists();
        showNotification(g.name, `${msg.name}: ${msg.image ? '📷 عکس' : msg.voice ? '🎤 ویس' : msg.text}`);
    }
}

function handleChannelMessage(msg) {
    const c = channels[msg.channelId];
    if (!c) return;
    if (c.mode === 'private' && (!c.subscribers || !c.subscribers.includes(currentUser.uid))) return;
    const chatKey = 'channel_' + msg.channelId;
    if (!messageHistory[chatKey]) messageHistory[chatKey] = [];
    const msgObj = {
        id: msg.msgId || 'm_' + Date.now(),
        text: msg.text || '', time: msg.time, from: msg.uid,
        senderName: msg.name, image: msg.image || null,
        voice: msg.voice || null, voiceDuration: msg.voiceDuration || 0
    };
    messageHistory[chatKey].push(msgObj);
    persistHistory();
    sendWS({ type: 'read_receipt', uid: currentUser.uid, msgId: msgObj.id });

    if (currentChat && currentChat.type === 'channel' && currentChat.id === msg.channelId) {
        addMessageToChat(msgObj, 'received');
    } else {
        c.unread = (c.unread || 0) + 1;
        c.lastMessage = msg.image ? '📷 عکس' : msg.voice ? '🎤 ویس' : msg.text;
        persistChannels(); renderAllLists();
        showNotification(c.name, `${msg.name}: ${msg.image ? '📷 عکس' : msg.voice ? '🎤 ویس' : msg.text}`);
    }
}

function handleReaction(msg) {
    if (!msg.msgId || !msg.emoji) return;
    if (!reactions[msg.msgId]) reactions[msg.msgId] = {};
    if (!reactions[msg.msgId][msg.emoji]) reactions[msg.msgId][msg.emoji] = [];
    if (!reactions[msg.msgId][msg.emoji].includes(msg.uid)) reactions[msg.msgId][msg.emoji].push(msg.uid);
    persistReactions();
    if (currentChat) renderCurrentChat();
}

function handleReadReceipt(msg) {
    if (!msg.msgId) return;
    if (!readStatus[msg.msgId]) readStatus[msg.msgId] = [];
    if (!readStatus[msg.msgId].includes(msg.uid)) readStatus[msg.msgId].push(msg.uid);
    persistReadStatus();
    const tickEl = document.querySelector(`[data-msg-id="${msg.msgId}"] .read-tick`);
    if (tickEl) tickEl.classList.add('read');
}

/* ============================================================
   تب‌ها
   ============================================================ */
document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
        const target = tab.dataset.tab;
        document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t === tab));
        document.querySelectorAll('.list-view').forEach(v => v.classList.remove('active'));
        document.getElementById(target + 'List').classList.add('active');
    });
});

/* ============================================================
   رندر
   ============================================================ */
function renderAllLists() {
    renderUsersList();
    renderContactsList();
    renderGroupsList();
    renderChannelsList();
}

function userAvatarHtml(user, size = 46) {
    if (user.avatar) {
        return `<div class="user-avatar" style="background-image:url(${user.avatar});background-size:cover;background-position:center;"></div>`;
    }
    const initial = (user.name || '?').charAt(0).toUpperCase();
    return `<div class="user-avatar">${initial}</div>`;
}

function renderUsersList() {
    const users = Object.entries(onlineUsers);
    if (users.length === 0) {
        chatsList.innerHTML = `<div class="empty-users"><div class="big-icon">👥</div>هنوز کسی آنلاین نیست.</div>`;
        return;
    }
    users.sort((a, b) => (b[1].unread || 0) - (a[1].unread || 0));
    chatsList.innerHTML = users.map(([uid, u]) => {
        const avatarHtml = u.avatar
            ? `<div class="user-avatar" style="background-image:url(${u.avatar});background-size:cover;"><span class="dot"></span></div>`
            : `<div class="user-avatar">${(u.name || '?').charAt(0).toUpperCase()}<span class="dot"></span></div>`;
        const lastMsg = u.lastMessage ? escapeHtml(u.lastMessage.slice(0, 40)) : 'برای شروع کلیک کن';
        const unreadBadge = u.unread ? `<span class="unread-badge">${u.unread}</span>` : '';
        return `
            <div class="user-item" data-open-user="${uid}">
                ${avatarHtml}
                <div class="user-info">
                    <div class="name">${escapeHtml(u.name)} ${u.username ? `<span style="font-size:11px;color:#888;font-weight:400;">@${escapeHtml(u.username)}</span>` : ''}</div>
                    <div class="lastmsg">${lastMsg}</div>
                </div>
                ${unreadBadge}
            </div>`;
    }).join('');
    chatsList.querySelectorAll('[data-open-user]').forEach(el => {
        el.addEventListener('click', () => openUserChat(el.dataset.openUser));
    });
}

function renderContactsList() {
    const list = Object.values(contacts);
    if (list.length === 0) {
        contactsList.innerHTML = `<div class="empty-users">
            <div class="big-icon">👥</div>
            هنوز مخاطبی اضافه نکردی.<br>
            <small>روی 👤＋ بزن و با نام کاربری جستجو کن</small>
        </div>`;
        return;
    }
    contactsList.innerHTML = list.map(c => {
        const isOnline = !!onlineUsers[c.uid];
        const live = onlineUsers[c.uid] || c;
        const avatarHtml = live.avatar
            ? `<div class="user-avatar" style="background-image:url(${live.avatar});background-size:cover;">${isOnline ? '<span class="dot"></span>' : ''}</div>`
            : `<div class="user-avatar">${(live.name || '?').charAt(0).toUpperCase()}${isOnline ? '<span class="dot"></span>' : ''}</div>`;
        return `
            <div class="user-item" data-open-contact="${c.uid}">
                ${avatarHtml}
                <div class="user-info">
                    <div class="name">${escapeHtml(live.name)} ${live.username ? `<span style="font-size:11px;color:#888;font-weight:400;">@${escapeHtml(live.username)}</span>` : ''}</div>
                    <div class="lastmsg">${isOnline ? '🟢 آنلاین' : '⚪ آفلاین'}</div>
                </div>
            </div>`;
    }).join('');
    contactsList.querySelectorAll('[data-open-contact]').forEach(el => {
        el.addEventListener('click', () => openContactChat(el.dataset.openContact));
    });
}

function renderGroupsList() {
    const list = Object.values(groups).filter(g => g.members && g.members.includes(currentUser.uid));
    if (list.length === 0) {
        groupsList.innerHTML = `<div class="empty-users"><div class="big-icon">👨‍👩‍👧</div>هنوز گروهی نساخته‌اید.</div>`;
        return;
    }
    list.sort((a, b) => (b.unread || 0) - (a.unread || 0));
    groupsList.innerHTML = list.map(g => {
        const initial = (g.name || '?').charAt(0).toUpperCase();
        const lastMsg = g.lastMessage ? escapeHtml(g.lastMessage.slice(0, 40)) : (g.desc || 'گروه');
        const unreadBadge = g.unread ? `<span class="unread-badge">${g.unread}</span>` : '';
        return `
            <div class="user-item" data-open-group="${g.id}">
                <div class="user-avatar group">${initial}</div>
                <div class="user-info">
                    <div class="name">${escapeHtml(g.name)}<span class="type-badge group">${g.members.length} عضو</span></div>
                    <div class="lastmsg">${lastMsg}</div>
                </div>
                ${unreadBadge}
            </div>`;
    }).join('');
    groupsList.querySelectorAll('[data-open-group]').forEach(el => {
        el.addEventListener('click', () => openGroupChat(el.dataset.openGroup));
    });
}

function renderChannelsList() {
    const list = Object.values(channels).filter(c => {
        if (c.mode === 'public') return true;
        return c.subscribers && c.subscribers.includes(currentUser.uid);
    });
    if (list.length === 0) {
        channelsList.innerHTML = `<div class="empty-users"><div class="big-icon">📢</div>هنوز کانالی نساخته‌اید.</div>`;
        return;
    }
    list.sort((a, b) => (b.unread || 0) - (a.unread || 0));
    channelsList.innerHTML = list.map(c => {
        const initial = (c.name || '?').charAt(0).toUpperCase();
        const lastMsg = c.lastMessage ? escapeHtml(c.lastMessage.slice(0, 40)) : (c.desc || 'کانال');
        const unreadBadge = c.unread ? `<span class="unread-badge">${c.unread}</span>` : '';
        const modeBadge = c.mode === 'private' ? '🔒' : '🌐';
        return `
            <div class="user-item" data-open-channel="${c.id}">
                <div class="user-avatar channel">${initial}</div>
                <div class="user-info">
                    <div class="name">${escapeHtml(c.name)}<span class="type-badge channel">${modeBadge} ${c.subscribers.length} عضو</span></div>
                    <div class="lastmsg">${lastMsg}</div>
                </div>
                ${unreadBadge}
            </div>`;
    }).join('');
    channelsList.querySelectorAll('[data-open-channel]').forEach(el => {
        el.addEventListener('click', () => openChannelChat(el.dataset.openChannel));
    });
}

function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, (c) => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));
}

function cleanInactiveUsers() {
    const now = Date.now();
    Object.keys(onlineUsers).forEach(uid => {
        if (now - (onlineUsers[uid].lastSeen || 0) > 60000) delete onlineUsers[uid];
    });
}

/* ============================================================
   باز کردن چت‌ها
   ============================================================ */
function openUserChat(uid) {
    const user = onlineUsers[uid];
    if (!user) return;
    currentChat = { type: 'user', id: uid, name: user.name };
    if (onlineUsers[uid]) onlineUsers[uid].unread = 0;
    setupChatUI(user.name, 'آنلاین', 'user', user);
    renderCurrentChat();
    showChatScreen(true);
    updateReadonlyBar();
}

function openContactChat(uid) {
    const contact = contacts[uid];
    if (!contact) return;
    const live = onlineUsers[uid] || contact;
    currentChat = { type: 'user', id: uid, name: live.name };
    if (onlineUsers[uid]) onlineUsers[uid].unread = 0;
    setupChatUI(live.name, onlineUsers[uid] ? '🟢 آنلاین' : '⚪ آفلاین', 'user', live);
    renderCurrentChat();
    showChatScreen(true);
    updateReadonlyBar();
}

function openGroupChat(gid) {
    const g = groups[gid];
    if (!g) return;
    currentChat = { type: 'group', id: gid, name: g.name };
    g.unread = 0;
    persistGroups();
    setupChatUI(g.name, `👥 گروه • ${g.members.length} عضو`, 'group');
    renderCurrentChat();
    showChatScreen(true);
    updateReadonlyBar();
}

function openChannelChat(cid) {
    const c = channels[cid];
    if (!c) return;
    if (c.mode === 'private' && (!c.subscribers || !c.subscribers.includes(currentUser.uid))) {
        if (confirm(`عضویت در کانال خصوصی «${c.name}»؟`)) joinChannel(cid);
        return;
    }
    if (c.mode === 'public' && (!c.subscribers || !c.subscribers.includes(currentUser.uid))) joinChannel(cid);
    currentChat = { type: 'channel', id: cid, name: c.name };
    c.unread = 0;
    persistChannels();
    const modeText = c.mode === 'private' ? '🔒 خصوصی' : '🌐 عمومی';
    setupChatUI(c.name, `📢 کانال ${modeText} • ${c.subscribers.length} عضو`, 'channel');
    renderCurrentChat();
    showChatScreen(true);
    updateReadonlyBar();
}

function setupChatUI(name, status, type, userObj = null) {
    document.getElementById('chatName').textContent = name;
    const av = document.getElementById('chatAvatar');
    if (userObj && userObj.avatar) {
        av.style.backgroundImage = `url(${userObj.avatar})`;
        av.style.backgroundSize = 'cover';
        av.textContent = '';
    } else {
        av.style.backgroundImage = '';
        av.textContent = name.charAt(0).toUpperCase();
    }
    document.getElementById('chatStatus').textContent = status;
    chatMessages.innerHTML = '';
    currentChatImageAttachment = null;
    replyingTo = null;
    replyPreview.classList.add('hidden');
    document.getElementById('imagePreviewBar')?.remove();
}

function renderCurrentChat() {
    if (!currentChat) return;
    const chatKey = currentChat.type + '_' + currentChat.id;
    const history = messageHistory[chatKey] || [];
    chatMessages.innerHTML = '';
    if (history.length === 0) {
        chatMessages.innerHTML = `<div class="message system">شروع گفتگو 👋</div>`;
    } else {
        history.forEach(m => addMessageToChat(m, m.from === currentUser.uid ? 'sent' : 'received', false));
    }
    scrollToBottom();
}

function showChatScreen(show) {
    if (show) {
        mainScreen.classList.add('hidden');
        chatScreen.classList.remove('hidden');
        setTimeout(() => messageInput.focus(), 300);
    } else {
        chatScreen.classList.add('hidden');
        mainScreen.classList.remove('hidden');
        currentChat = null;
        chatMessages.innerHTML = '';
    }
}

document.getElementById('backBtn').addEventListener('click', () => {
    showChatScreen(false);
    renderAllLists();
});

function isChannelAdmin() {
    if (!currentChat || currentChat.type !== 'channel') return false;
    const c = channels[currentChat.id];
    return c && c.owner === currentUser.uid;
}

function updateReadonlyBar() {
    if (!currentChat) return;
    let canWrite = true;
    if (currentChat.type === 'channel' && !isChannelAdmin()) canWrite = false;
    if (canWrite) {
        chatInputBar.classList.remove('hidden');
        readonlyBar.classList.add('hidden');
    } else {
        chatInputBar.classList.add('hidden');
        readonlyBar.classList.remove('hidden');
    }
}

/* ============================================================
   جستجو در پیام‌ها
   ============================================================ */
searchChatBtn.addEventListener('click', () => {
    chatSearchBar.classList.toggle('hidden');
    if (!chatSearchBar.classList.contains('hidden')) chatSearchInput.focus();
});
document.getElementById('closeSearchBtn').addEventListener('click', () => {
    chatSearchBar.classList.add('hidden');
    chatSearchInput.value = '';
    renderCurrentChat();
});
chatSearchInput.addEventListener('input', () => {
    const query = chatSearchInput.value.trim().toLowerCase();
    if (!currentChat) return;
    const chatKey = currentChat.type + '_' + currentChat.id;
    const history = messageHistory[chatKey] || [];
    chatMessages.innerHTML = '';
    const filtered = query ? history.filter(m => m.text && m.text.toLowerCase().includes(query)) : history;
    if (filtered.length === 0) chatMessages.innerHTML = `<div class="message system">نتیجه‌ای یافت نشد</div>`;
    else filtered.forEach(m => addMessageToChat(m, m.from === currentUser.uid ? 'sent' : 'received', false));
});

/* ============================================================
   ارسال پیام
   ============================================================ */
function sendMessage() {
    if (!currentChat) return;
    const text = messageInput.value.trim();
    const image = currentChatImageAttachment;
    if (!text && !image) return;

    const time = new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' });
    const msgId = 'm_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6);
    const replyData = replyingTo ? { id: replyingTo.id, text: replyingTo.text, senderName: replyingTo.senderName } : null;

    const msgObj = {
        id: msgId, text, time, from: currentUser.uid,
        senderName: currentUser.name, image, voice: null,
        voiceDuration: 0, replyTo: replyData
    };

    const base = {
        uid: currentUser.uid, name: currentUser.name,
        username: currentUser.username, avatar: currentUser.avatar,
        text, time, image, msgId, replyTo: replyData
    };

    if (currentChat.type === 'user') {
        sendWS({ type: 'chat', ...base, to: currentChat.id });
    } else if (currentChat.type === 'group') {
        sendWS({ type: 'group_message', ...base, groupId: currentChat.id });
    } else if (currentChat.type === 'channel') {
        if (!isChannelAdmin()) return;
        sendWS({ type: 'channel_message', ...base, channelId: currentChat.id });
    }

    const chatKey = currentChat.type + '_' + currentChat.id;
    if (!messageHistory[chatKey]) messageHistory[chatKey] = [];
    messageHistory[chatKey].push(msgObj);
    persistHistory();
    addMessageToChat(msgObj, 'sent');

    messageInput.value = '';
    currentChatImageAttachment = null;
    replyingTo = null;
    replyPreview.classList.add('hidden');
    document.getElementById('imagePreviewBar')?.remove();
    messageInput.focus();
}

function addMessageToChat(m, type, animate = true) {
    const div = document.createElement('div');
    div.className = 'message ' + type;
    div.dataset.msgId = m.id;
    if (!animate) div.style.animation = 'none';
    if (m.image) div.classList.add('has-image');

    let html = '';

    if (m.replyTo) {
        html += `<div class="reply-content" style="border-right-color:${type === 'sent' ? 'rgba(255,255,255,0.5)' : '#667eea'}; margin-bottom:6px;">
            <div class="reply-name" style="color:${type === 'sent' ? 'rgba(255,255,255,0.9)' : '#667eea'};">${escapeHtml(m.replyTo.senderName || 'کاربر')}</div>
            <div class="reply-text" style="color:${type === 'sent' ? 'rgba(255,255,255,0.8)' : '#555'};">${escapeHtml((m.replyTo.text || '').slice(0, 50))}</div>
        </div>`;
    }

    if (m.senderName && type === 'received' && currentChat && currentChat.type !== 'user') {
        html += `<div class="sender-name">${escapeHtml(m.senderName)}</div>`;
    }

    if (m.image) html += `<img class="message-image" src="${m.image}" alt="عکس">`;

    if (m.voice) {
        const duration = m.voiceDuration || 0;
        html += `<div class="voice-message">
            <button class="voice-play-btn" data-voice="${m.voice}">▶</button>
            <div class="voice-wave">
                <span></span><span></span><span></span><span></span><span></span>
                <span></span><span></span><span></span><span></span><span></span>
                <span></span><span></span>
            </div>
            <span class="voice-duration">${formatDuration(duration)}</span>
        </div>`;
    }

    if (m.text) html += `<div class="${m.image || m.voice ? 'caption' : ''}">${escapeHtml(m.text)}</div>`;

    const msgReactions = reactions[m.id] || {};
    const reactionKeys = Object.keys(msgReactions).filter(e => msgReactions[e].length > 0);
    if (reactionKeys.length > 0) {
        html += `<div class="reactions-bar">`;
        reactionKeys.forEach(emoji => {
            html += `<span class="reaction-badge">${emoji} ${msgReactions[emoji].length}</span>`;
        });
        html += `</div>`;
    }

    html += `<span class="time">${m.time}`;
    if (type === 'sent') {
        const isRead = readStatus[m.id] && readStatus[m.id].length > 0;
        html += ` <span class="read-tick ${isRead ? 'read' : ''}">${isRead ? '✓✓' : '✓'}</span>`;
    }
    html += `</span>`;

    div.innerHTML = html;
    chatMessages.appendChild(div);
    scrollToBottom();

    if (m.image) {
        div.querySelector('.message-image')?.addEventListener('click', (e) => {
            lightboxImg.src = e.target.src;
            lightbox.classList.remove('hidden');
        });
    }

    if (m.voice) {
        div.querySelector('.voice-play-btn')?.addEventListener('click', (e) => {
            const audio = new Audio(e.target.dataset.voice);
            audio.play();
            e.target.textContent = '⏸';
            audio.onended = () => { e.target.textContent = '▶'; };
        });
    }

    let pressTimer;
    const startPress = () => { pressTimer = setTimeout(() => showReactionPicker(m.id, div), 500); };
    const endPress = () => clearTimeout(pressTimer);
    div.addEventListener('touchstart', startPress);
    div.addEventListener('touchend', endPress);
    div.addEventListener('mousedown', startPress);
    div.addEventListener('mouseup', endPress);
    div.addEventListener('mouseleave', endPress);

    div.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        if (type === 'received') {
            replyingTo = {
                id: m.id,
                text: m.text || (m.image ? '📷 عکس' : '🎤 ویس'),
                senderName: m.senderName || currentChat.name
            };
            replyName.textContent = replyingTo.senderName;
            replyText.textContent = replyingTo.text.slice(0, 50);
            replyPreview.classList.remove('hidden');
            messageInput.focus();
        }
    });
}

function showReactionPicker(msgId, element) {
    document.querySelectorAll('.reaction-picker').forEach(el => el.remove());
    const picker = document.createElement('div');
    picker.className = 'reaction-picker';
    const emojis = ['❤️', '😂', '😮', '😢', '👍', '🔥'];
    picker.innerHTML = emojis.map(e => `<button data-emoji="${e}">${e}</button>`).join('');
    element.appendChild(picker);

    picker.querySelectorAll('button').forEach(btn => {
        btn.addEventListener('click', () => {
            const emoji = btn.dataset.emoji;
            if (!reactions[msgId]) reactions[msgId] = {};
            if (!reactions[msgId][emoji]) reactions[msgId][emoji] = [];
            if (!reactions[msgId][emoji].includes(currentUser.uid)) reactions[msgId][emoji].push(currentUser.uid);
            else reactions[msgId][emoji] = reactions[msgId][emoji].filter(u => u !== currentUser.uid);
            persistReactions();
            sendWS({ type: 'reaction', uid: currentUser.uid, msgId, emoji });
            picker.remove();
            renderCurrentChat();
        });
    });
    setTimeout(() => picker.remove(), 4000);
}

function formatDuration(seconds) {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
}

function scrollToBottom() {
    requestAnimationFrame(() => {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    });
}

sendBtn.addEventListener('click', sendMessage);
messageInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); sendMessage(); }
});

/* ============================================================
   ضبط ویس
   ============================================================ */
micBtn.addEventListener('click', async () => {
    if (isRecording) { stopRecording(false); return; }
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaRecorder = new MediaRecorder(stream);
        audioChunks = [];
        isRecording = true;
        isCancelledRecording = false;

        mediaRecorder.ondataavailable = (e) => { if (e.data.size > 0) audioChunks.push(e.data); };

        mediaRecorder.onstop = () => {
            if (!isCancelledRecording && audioChunks.length > 0) {
                const blob = new Blob(audioChunks, { type: 'audio/webm' });
                const reader = new FileReader();
                reader.onload = () => sendVoiceMessage(reader.result, recordingStartTime);
                reader.readAsDataURL(blob);
            }
            stream.getTracks().forEach(t => t.stop());
            isRecording = false;
            voiceRecordOverlay.classList.add('hidden');
            micBtn.classList.remove('recording');
            if (recordingTimer) clearInterval(recordingTimer);
        };

        mediaRecorder.start();
        recordingStartTime = 0;
        micBtn.classList.add('recording');
        voiceRecordOverlay.classList.remove('hidden');
        voiceRecordTime.textContent = '00:00';

        recordingTimer = setInterval(() => {
            recordingStartTime++;
            const m = Math.floor(recordingStartTime / 60);
            const s = recordingStartTime % 60;
            voiceRecordTime.textContent = `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
            if (recordingStartTime >= 120) stopRecording(false);
        }, 1000);
    } catch (e) { alert('دسترسی به میکروفون داده نشد'); }
});

function stopRecording(cancelled) {
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
        isCancelledRecording = cancelled;
        mediaRecorder.stop();
    }
}

voiceCancelBtn.addEventListener('click', () => stopRecording(true));
voiceSendBtn.addEventListener('click', () => stopRecording(false));

function sendVoiceMessage(base64, duration) {
    if (!currentChat) return;
    const time = new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' });
    const msgId = 'm_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6);
    const msgObj = {
        id: msgId, text: '', time, from: currentUser.uid,
        senderName: currentUser.name, image: null,
        voice: base64, voiceDuration: duration, replyTo: null
    };

    const base = {
        uid: currentUser.uid, name: currentUser.name, text: '', time,
        voice: base64, voiceDuration: duration, msgId
    };

    if (currentChat.type === 'user') sendWS({ type: 'chat', ...base, to: currentChat.id });
    else if (currentChat.type === 'group') sendWS({ type: 'group_message', ...base, groupId: currentChat.id });

    const chatKey = currentChat.type + '_' + currentChat.id;
    if (!messageHistory[chatKey]) messageHistory[chatKey] = [];
    messageHistory[chatKey].push(msgObj);
    persistHistory();
    addMessageToChat(msgObj, 'sent');
}

/* ============================================================
   ارسال عکس
   ============================================================ */
attachBtn.addEventListener('click', () => imageInput.click());

imageInput.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) { alert('فقط عکس'); return; }
    if (file.size > 8 * 1024 * 1024) { alert('حداکثر ۸ مگابایت'); return; }
    try {
        const compressed = await compressImage(file, 900, 0.7);
        currentChatImageAttachment = compressed;
        showImagePreview(compressed);
    } catch (err) { alert('خطا'); }
    imageInput.value = '';
});

function compressImage(file, maxSize, quality) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => {
            const img = new Image();
            img.onload = () => {
                let { width, height } = img;
                if (width > height && width > maxSize) {
                    height = Math.round(height * maxSize / width);
                    width = maxSize;
                } else if (height > maxSize) {
                    width = Math.round(width * maxSize / height);
                    height = maxSize;
                }
                const canvas = document.createElement('canvas');
                canvas.width = width; canvas.height = height;
                canvas.getContext('2d').drawImage(img, 0, 0, width, height);
                resolve(canvas.toDataURL('image/jpeg', quality));
            };
            img.onerror = reject;
            img.src = e.target.result;
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}

function showImagePreview(dataUrl) {
    document.getElementById('imagePreviewBar')?.remove();
    const bar = document.createElement('div');
    bar.id = 'imagePreviewBar';
    bar.style.cssText = `position:absolute;bottom:calc(75px + env(safe-area-inset-bottom));left:12px;right:12px;background:white;border-radius:12px;padding:8px;box-shadow:0 4px 20px rgba(0,0,0,0.15);display:flex;align-items:center;gap:10px;z-index:5;`;
    bar.innerHTML = `<img src="${dataUrl}" style="width:60px;height:60px;border-radius:8px;object-fit:cover;">
        <div style="flex:1;"><div style="font-size:13px;font-weight:600;color:#333;">عکس آماده ارسال</div><div style="font-size:11px;color:#888;margin-top:2px;">برای ارسال ➤</div></div>
        <button id="removeImageBtn" style="background:#fee2e2;color:#dc2626;border:none;width:36px;height:36px;border-radius:50%;font-size:16px;cursor:pointer;font-family:inherit;">✕</button>`;
    chatScreen.appendChild(bar);
    document.getElementById('removeImageBtn').addEventListener('click', () => {
        currentChatImageAttachment = null;
        bar.remove();
    });
}

/* ============================================================
   Lightbox
   ============================================================ */
document.getElementById('lightboxClose').addEventListener('click', () => {
    lightbox.classList.add('hidden'); lightboxImg.src = '';
});
lightbox.addEventListener('click', (e) => {
    if (e.target === lightbox) { lightbox.classList.add('hidden'); lightboxImg.src = ''; }
});

/* ============================================================
   ساخت گروه / کانال
   ============================================================ */
let createType = 'group';

document.getElementById('createBtn').addEventListener('click', () => {
    createModal.classList.remove('hidden');
    document.getElementById('newName').value = '';
    document.getElementById('newDesc').value = '';
    document.getElementById('modalError').textContent = '';
    createType = 'group';
    document.querySelectorAll('.type-tab').forEach(t => t.classList.toggle('active', t.dataset.type === 'group'));
    document.getElementById('channelOptions').classList.add('hidden');
});

document.querySelectorAll('.type-tab').forEach(tab => {
    tab.addEventListener('click', () => {
        createType = tab.dataset.type;
        document.querySelectorAll('.type-tab').forEach(t => t.classList.toggle('active', t === tab));
        document.getElementById('channelOptions').classList.toggle('hidden', createType !== 'channel');
    });
});

document.getElementById('closeModalBtn').addEventListener('click', () => createModal.classList.add('hidden'));
document.getElementById('cancelCreateBtn').addEventListener('click', () => createModal.classList.add('hidden'));

document.getElementById('confirmCreateBtn').addEventListener('click', () => {
    const name = document.getElementById('newName').value.trim();
    const desc = document.getElementById('newDesc').value.trim();
    const errEl = document.getElementById('modalError');
    if (!name || name.length < 2) { errEl.textContent = 'نام حداقل ۲ کاراکتر'; return; }
    errEl.textContent = '';
    if (createType === 'group') createGroup(name, desc);
    else createChannel(name, desc, document.querySelector('input[name="chMode"]:checked').value);
    createModal.classList.add('hidden');
});

function createGroup(name, desc) {
    const id = 'g_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6);
    const group = {
        id, name, desc: desc || '', owner: currentUser.uid, ownerName: currentUser.name,
        members: [currentUser.uid], memberNames: { [currentUser.uid]: currentUser.name },
        admins: [currentUser.uid], createdAt: Date.now()
    };
    groups[id] = group;
    persistGroups();
    sendWS({ type: 'group_create', uid: currentUser.uid, name: currentUser.name, group });
    renderAllLists();
    alert(`گروه «${name}» ساخته شد ✅`);
}

function createChannel(name, desc, mode) {
    const id = 'c_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6);
    const channel = {
        id, name, desc: desc || '', owner: currentUser.uid, ownerName: currentUser.name, mode,
        subscribers: [currentUser.uid], subscriberNames: { [currentUser.uid]: currentUser.name },
        createdAt: Date.now()
    };
    channels[id] = channel;
    persistChannels();
    sendWS({ type: 'channel_create', uid: currentUser.uid, name: currentUser.name, channel });
    renderAllLists();
    alert(`کانال «${name}» ساخته شد ✅`);
}

function joinChannel(cid) {
    const c = channels[cid];
    if (!c) return;
    if (!c.subscribers) c.subscribers = [];
    if (!c.subscriberNames) c.subscriberNames = {};
    if (!c.subscribers.includes(currentUser.uid)) {
        c.subscribers.push(currentUser.uid);
        c.subscriberNames[currentUser.uid] = currentUser.name;
        persistChannels();
        sendWS({ type: 'channel_update', uid: currentUser.uid, name: currentUser.name, channel: c });
        renderAllLists();
    }
}

function broadcastGroupsChannels() {
    Object.values(groups).forEach(g => {
        if (g.members && g.members.includes(currentUser.uid)) {
            sendWS({ type: 'group_create', uid: currentUser.uid, name: currentUser.name, group: g });
        }
    });
    Object.values(channels).forEach(c => {
        if (c.subscribers && c.subscribers.includes(currentUser.uid)) {
            sendWS({ type: 'channel_create', uid: currentUser.uid, name: currentUser.name, channel: c });
        }
    });
}

/* ============================================================
   مودال اطلاعات
   ============================================================ */
document.getElementById('chatInfoBtn').addEventListener('click', openInfoModal);

function openInfoModal() {
    if (!currentChat) return;
    const infoTitle = document.getElementById('infoTitle');
    const infoAvatar = document.getElementById('infoAvatar');
    const infoName = document.getElementById('infoName');
    const infoUsername = document.getElementById('infoUsername');
    const infoDesc = document.getElementById('infoDesc');
    const infoMeta = document.getElementById('infoMeta');
    const infoMembers = document.getElementById('infoMembers');
    const infoActions = document.getElementById('infoActions');
    infoAvatar.className = 'info-avatar';
    infoAvatar.style.backgroundImage = '';
    infoUsername.textContent = '';
    infoActions.innerHTML = '';

    if (currentChat.type === 'user') {
        const u = allUsersRegistry[currentChat.id] || contacts[currentChat.id] || onlineUsers[currentChat.id] || {};
        infoTitle.textContent = 'اطلاعات کاربر';
        if (u.avatar) {
            infoAvatar.style.backgroundImage = `url(${u.avatar})`;
            infoAvatar.style.backgroundSize = 'cover';
            infoAvatar.textContent = '';
        } else {
            infoAvatar.textContent = (u.name || currentChat.name).charAt(0).toUpperCase();
        }
        infoName.textContent = u.name || currentChat.name;
        infoUsername.textContent = u.username ? '@' + u.username : '';
        infoDesc.textContent = u.bio || 'بدون بیوگرافی';
        infoMeta.innerHTML = `وضعیت: <strong>${onlineUsers[currentChat.id] ? '🟢 آنلاین' : '⚪ آفلاین'}</strong>`;

        // دکمه‌های افزودن/حذف مخاطب
        let actions = '';
        if (!contacts[currentChat.id]) {
            actions += `<button class="btn-primary" id="addThisContactBtn">افزودن به مخاطبین</button>`;
        } else {
            actions += `<button class="btn-secondary" id="removeThisContactBtn">حذف از مخاطبین</button>`;
        }
        infoActions.innerHTML = actions;

        document.getElementById('addThisContactBtn')?.addEventListener('click', () => {
            contacts[currentChat.id] = {
                uid: currentChat.id,
                name: u.name || currentChat.name,
                username: u.username || '',
                avatar: u.avatar || null
            };
            persistContacts();
            renderAllLists();
            infoModal.classList.add('hidden');
            alert('به مخاطبین اضافه شد ✅');
        });
        document.getElementById('removeThisContactBtn')?.addEventListener('click', () => {
            if (confirm('از مخاطبین حذف شود؟')) {
                delete contacts[currentChat.id];
                persistContacts();
                renderAllLists();
                infoModal.classList.add('hidden');
            }
        });
        infoMembers.innerHTML = '';

    } else if (currentChat.type === 'group') {
        const g = groups[currentChat.id];
        const isOwner = g.owner === currentUser.uid;
        const amIAdmin = isOwner || (g.admins && g.admins.includes(currentUser.uid));
        infoTitle.textContent = 'اطلاعات گروه';
        infoAvatar.className = 'info-avatar group';
        infoAvatar.textContent = g.name.charAt(0).toUpperCase();
        infoName.textContent = g.name;
        infoDesc.textContent = g.desc || 'بدون توضیحات';
        infoMeta.innerHTML = `سازنده: <strong>${escapeHtml(g.ownerName || '?')}</strong><br>تعداد اعضا: <strong>${g.members.length}</strong>`;
        infoMembers.innerHTML = `<h4>اعضا (${g.members.length})</h4>` + g.members.map(uid => {
            const reg = allUsersRegistry[uid] || {};
            const name = (g.memberNames && g.memberNames[uid]) || reg.name || onlineUsers[uid]?.name || 'ناشناس';
            const isUserAdmin = uid === g.owner || (g.admins && g.admins.includes(uid));
            const isMe = uid === currentUser.uid;
            let adminBtn = '';
            if (amIAdmin && !isMe) {
                adminBtn = isUserAdmin
                    ? `<button data-remove-admin="${uid}">🚫</button>`
                    : `<button data-add-admin="${uid}">👑</button>`;
            }
            return `<div class="member-item"><div class="mini-avatar">${name.charAt(0).toUpperCase()}</div><div class="member-name">${escapeHtml(name)}</div>${isUserAdmin ? '<span class="admin-badge">ادمین</span>' : ''}<div class="member-actions">${adminBtn}</div></div>`;
        }).join('');

        if (isOwner) {
            infoActions.innerHTML = `<button class="btn-danger" id="deleteGroupBtn">حذف گروه</button>`;
            document.getElementById('deleteGroupBtn').addEventListener('click', () => {
                if (confirm(`گروه «${g.name}» حذف شود؟`)) {
                    delete groups[g.id]; persistGroups();
                    infoModal.classList.add('hidden'); showChatScreen(false); renderAllLists();
                }
            });
        } else {
            infoActions.innerHTML = `<button class="btn-danger" id="leaveGroupBtn">خروج از گروه</button>`;
            document.getElementById('leaveGroupBtn').addEventListener('click', () => {
                if (confirm('خارج می‌شوید؟')) {
                    g.members = g.members.filter(u => u !== currentUser.uid);
                    delete g.memberNames[currentUser.uid]; persistGroups();
                    sendWS({ type: 'group_update', uid: currentUser.uid, name: currentUser.name, group: g });
                    infoModal.classList.add('hidden'); showChatScreen(false); renderAllLists();
                }
            });
        }
        infoMembers.querySelectorAll('[data-add-admin]').forEach(btn => btn.addEventListener('click', () => {
            const uid = btn.dataset.addAdmin;
            if (!g.admins) g.admins = [];
            if (!g.admins.includes(uid)) { g.admins.push(uid); persistGroups(); sendWS({ type: 'group_update', uid: currentUser.uid, name: currentUser.name, group: g }); openInfoModal(); }
        }));
        infoMembers.querySelectorAll('[data-remove-admin]').forEach(btn => btn.addEventListener('click', () => {
            const uid = btn.dataset.removeAdmin;
            g.admins = (g.admins || []).filter(u => u !== uid); persistGroups();
            sendWS({ type: 'group_update', uid: currentUser.uid, name: currentUser.name, group: g }); openInfoModal();
        }));

    } else if (currentChat.type === 'channel') {
        const c = channels[currentChat.id];
        const isOwner = c.owner === currentUser.uid;
        infoTitle.textContent = 'اطلاعات کانال';
        infoAvatar.className = 'info-avatar channel';
        infoAvatar.textContent = c.name.charAt(0).toUpperCase();
        infoName.textContent = c.name;
        infoDesc.textContent = c.desc || 'بدون توضیحات';
        infoMeta.innerHTML = `سازنده: <strong>${escapeHtml(c.ownerName || '?')}</strong><br>حالت: <strong>${c.mode === 'private' ? '🔒 خصوصی' : '🌐 عمومی'}</strong><br>تعداد اعضا: <strong>${c.subscribers.length}</strong>`;
        infoMembers.innerHTML = `<h4>اعضا (${c.subscribers.length})</h4>` + c.subscribers.map(uid => {
            const reg = allUsersRegistry[uid] || {};
            const name = (c.subscriberNames && c.subscriberNames[uid]) || reg.name || onlineUsers[uid]?.name || 'ناشناس';
            return `<div class="member-item"><div class="mini-avatar">${name.charAt(0).toUpperCase()}</div><div class="member-name">${escapeHtml(name)}</div>${uid === c.owner ? '<span class="admin-badge">ادمین</span>' : ''}</div>`;
        }).join('');

        if (isOwner) {
            infoActions.innerHTML = `<button class="btn-danger" id="deleteChannelBtn">حذف کانال</button>`;
            document.getElementById('deleteChannelBtn').addEventListener('click', () => {
                if (confirm(`حذف شود؟`)) {
                    delete channels[c.id]; persistChannels();
                    infoModal.classList.add('hidden'); showChatScreen(false); renderAllLists();
                }
            });
        } else {
            infoActions.innerHTML = `<button class="btn-danger" id="unsubChannelBtn">لغو عضویت</button>`;
            document.getElementById('unsubChannelBtn').addEventListener('click', () => {
                if (confirm('خارج می‌شوید؟')) {
                    c.subscribers = c.subscribers.filter(u => u !== currentUser.uid);
                    delete c.subscriberNames[currentUser.uid]; persistChannels();
                    sendWS({ type: 'channel_update', uid: currentUser.uid, name: currentUser.name, channel: c });
                    infoModal.classList.add('hidden'); showChatScreen(false); renderAllLists();
                }
            });
        }
    }
    infoModal.classList.remove('hidden');
}

document.getElementById('closeInfoBtn').addEventListener('click', () => infoModal.classList.add('hidden'));
document.getElementById('closeInfoFooterBtn').addEventListener('click', () => infoModal.classList.add('hidden'));

[createModal, infoModal, profileModal, addContactModal].forEach(modal => {
    modal.addEventListener('click', (e) => { if (e.target === modal) modal.classList.add('hidden'); });
});

/* ============================================================
   موبایل
   ============================================================ */
let lastTouchEnd = 0;
document.addEventListener('touchend', (e) => {
    const now = Date.now();
    if (now - lastTouchEnd <= 300) e.preventDefault();
    lastTouchEnd = now;
}, false);

if (window.visualViewport) {
    window.visualViewport.addEventListener('resize', scrollToBottom);
}

/* ============================================================
   شروع
   ============================================================ */
(async () => {
    await openDB();
    await checkAutoLogin();
    connectAbly();

    window.addEventListener('beforeunload', () => {
        if (currentUser) sendWS({ type: 'leave', uid: currentUser.uid });
        stopHeartbeat();
        dbSet('groups', groups);
        dbSet('channels', channels);
        dbSet('messageHistory', messageHistory);
        dbSet('reactions', reactions);
        dbSet('readStatus', readStatus);
        dbSet('contacts', contacts);
        dbSet('allUsers', allUsersRegistry);
    });
})();