CONTROLE MOTOBOY 3.0 — PACOTE CORRIGIDO

Correção: incluída a página inicial também no caminho web/index.html, que é o caminho solicitado pelo endereço interno appassets.androidplatform.net/web/index.html.

O projeto Android original permanece na pasta ControleMotoboyAndroid.

Recursos da página: tema automático do celular com alternância manual; salvamento automático em duas chaves locais; recuperação da cópia válida; exportação e importação de backup.

ATENÇÃO: mantenha a versão antiga instalada até confirmar que a nova abre corretamente.
