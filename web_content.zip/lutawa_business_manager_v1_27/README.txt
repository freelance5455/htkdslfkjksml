LUTAWA BUSINESS MANAGER — v1.27

Files:
- index.html: Main application
- sw.js: Service worker and offline cache
- manifest.webmanifest: PWA manifest

v1.27 updates:
- Print a dedicated 80mm thermal receipt whenever a customer pays an existing debt.
- Debt payment receipts show receipt number, customer, amount received, payment method, previous debt and remaining balance.
- Reprint debt payment receipts from Sales & POS > Debts Paid or from the Customer Ledger.
- Partial payments are supported on credit sales: enter the amount received now; the system calculates and records the outstanding balance.
- Partial payments made later from Customers & Debts reduce the remaining balance and preserve payment history.

Important:
- This is a local-first PWA. Records are stored in this browser/device using localStorage.
- Cloud sync, Firebase backend and production-grade authentication are not implemented.
- Printing requires a compatible Android print service or thermal printer and permission to open pop-ups.


Version 1.27: Fintech-inspired UI refresh with refined dashboard styling and mobile quick navigation. Existing business logic and local data storage retained.


Version 1.27 updates:
- Inventory products can be edited and deleted. Deletion requires an in-app confirmation (Delete / Cancel); historical sales remain intact.
- Account menu at the top-right includes Log out and Select mode: Light mode / Dark mode. Theme preference is saved on this device.
- Dark mode uses a navy-blue palette.


v1.27 updates:
- Improved dark-mode contrast and text readability across dashboard metrics, headings, panels, tables, form controls, account menu and mobile bottom navigation.
- Light mode remains unchanged.


v1.27: Sidebar and top header remain fixed while scrolling on desktop and mobile. On mobile, the sidebar remains a slide-out drawer.


v1.22: Removed dropdown arrow/chevron indicators from the account menu trigger and selection controls.


v1.23: Added confirmation dialogs to destructive delete actions and Sales & POS product return recording. Returns restore inventory stock, reduce sale revenue, adjust customer outstanding debt first, and record any cash refund and return history.


v1.27 updates:
- Application interface language is English only, including confirmation dialogs, sales returns, debt labels, settings messages, and backup/restore alerts.


v1.27: Updated login-page helper text with professional business workspace access guidance.


Version 1.27 UI/UX refinement: improved mobile spacing and responsive layouts, larger touch targets, clearer form controls, improved dashboard metric contrast in dark mode, more readable tables and cards, and accessibility focus states. Existing business data and calculation logic are unchanged.

Version 1.27: Improved login screen text contrast and responsive styling in light and dark modes.
