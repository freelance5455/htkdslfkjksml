TR Maintenance - React Project

Yeh ZIP APK nahi hai; yeh React source project hai, jise pehle online host/deploy karna hoga.

Aage ka rasta (sirf Android mobile se):
1. ZIP ko kisi browser-based coding workspace (jaise Replit) mein import karein.
2. Project ke andar `npm install` aur `npm run build` chalayein.
3. Project ko HTTPS website ke roop mein deploy karein.
4. Website ko PWA banane ke liye manifest, icons aur service worker jodein.
5. PWA ka HTTPS URL PWABuilder.com par daal kar Android package banayein.

Important:
- Is project mein localStorage use hota hai. Alag Owner/Staff/Customer phones mein data apne-aap share nahi hoga; iske liye Firebase/backend integration abhi bhi zaroori hai.
- ZIP se APK seedhe install nahi hoti.
- Google Play Store ke liye aam taur par AAB package aur signing/configuration ki zaroorat hoti hai.
