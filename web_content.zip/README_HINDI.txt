MYZEN AI - HTML UI STARTER

इस ZIP में:
- index.html: मुख्य स्क्रीन
- style.css: पूरी ब्लैक थीम और नीला 3D-जैसा animated orb
- app.js: Settings और फोटो/फाइल चुनने के बटन

कैसे देखें:
1. ZIP extract करें।
2. index.html को मोबाइल/कंप्यूटर ब्राउज़र में खोलें।

ध्यान दें:
यह UI prototype है। Gemini API, असली AI chat, voice input/output और चुनी गई फाइलों का AI विश्लेषण अभी इसमें कनेक्ट नहीं है।
Zip-to-APK वेबसाइट के लिए index.html ZIP के root में मौजूद है।
