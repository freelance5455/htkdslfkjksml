CONTROL CENTER ANDROID PROJECT

Folders:
- app/: Android Studio app module. Your HTML is stored at app/src/main/assets/index.html.
- APK/: जगह जहाँ build करने के बाद APK रख सकते हैं.

APK अभी शामिल नहीं है, क्योंकि APK बनाने के लिए Android SDK/Gradle build environment चाहिए.
APK बनाने के लिए:
1. Android Studio में इस project folder को Open करें.
2. Gradle sync पूरा होने दें.
3. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें.
4. APK app/build/outputs/apk/debug/app-debug.apk में बनेगा.
5. उस APK को APK/ folder में कॉपी कर सकते हैं.

नोट: यह एक WebView wrapper है. कुछ browser features (जैसे Notification, Battery API, Vibration और Wake Lock)
Android/WebView version और permissions पर निर्भर करेंगे.
