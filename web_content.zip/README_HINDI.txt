KisuFire AIM Android project

Is ZIP mein Android WebView app ka source project hai. Ye APK file nahi hai.

Features:
- Red-black KisuFire AIM interface
- 30-second target tap practice game
- Best/last score local storage
- Sensitivity notes save karna
- Hindi practice tips

Phone par use:
1. ZIP extract karo.
2. app/src/main/assets/index.html ko browser mein khol kar practice panel test kar sakte ho.
3. APK banane ke liye Android Studio ya kisi trusted Android cloud build service mein poora project import karke build APK karo.
4. Is project mein Gradle wrapper shamil nahi hai; build service/Android Studio Gradle setup karega.

Safety:
Ye app Free Fire se connect nahi hota, game files modify nahi karta aur automatic aim/headshots/damage hacks nahi deta.
