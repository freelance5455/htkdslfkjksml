SPB TRADERS Android Project (APK banane ke liye source)

Is ZIP mein Android Studio project aur app ka offline HTML prototype hai.
Yeh APK file nahi hai. APK banane ke liye Android Studio/Android SDK wale computer ki zaroorat hogi.

APK build:
1. Computer par Android Studio install karein.
2. Android Studio > Open > is ZIP ko extract karke SPB_TRADERS_Android_Project folder kholein.
3. Gradle sync complete hone dein.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) chunein.
5. APK app/build/outputs/apk/debug/app-debug.apk mein milega.

Prototype mein local device par data save hota hai. Data loss se bachne ke liye Backup/Export use karein.
IMPORTANT: Abhi multi-mobile live sync aur bill photo/PDF se automatic OCR/GST extraction production-ready nahi hai.
Real business use se pehle GST rules, invoice fields, security, backup, sync aur tax calculations ko verify/test karna zaroori hai.
