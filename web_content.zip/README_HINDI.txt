VS MUSICAL STUDIO - Live Loops
ADD LOOP FIXED FINAL

इस version में:
1. LOOP ADD के लिए केवल एक click/user gesture इस्तेमाल किया गया है।
2. Android WebView में touchend + click की double-trigger समस्या हटाई गई है।
3. MP3/WAV/M4A/AAC/OGG/FLAC/OPUS/AIFF files चुन सकते हैं।
4. चुना हुआ audio पहले खाली Loop slot में जुड़ता है।
5. Loop list में added loop दिखता है और tap करने पर चलता है।
6. एक समय में एक ही Loop चलता है; दूसरा शुरू करने पर पहला रुकता है।
7. Loop repeat होता है।
8. Volume और BPM controls बने हुए हैं।

महत्वपूर्ण:
अगर इसे ऐसे APK/WebView builder में बनाया गया है जिसमें Android WebView का native file chooser
(WebChromeClient/onShowFileChooser) enabled नहीं है, तो किसी भी HTML code से phone file picker
नहीं खुल सकता। ऐसे APK wrapper में native file chooser support जरूरी है।
