VS MUSICAL STUDIO - Live Loops
FIXED ADD LOOP VERSION

मुख्य सुधार:
1. LOOP ADD अब सीधे Android file picker खोलता है।
2. MP3/WAV/M4A/AAC/OGG/FLAC audio चुन सकते हैं।
3. चुना हुआ loop खाली slot में जुड़ता है।
4. एक समय में एक loop चलता है और दूसरा शुरू करने पर पहला रुकता है।
5. Loop लगातार repeat होता है।
6. Volume और BPM controls बने हुए हैं।
7. Touch controls बरकरार रखे गए हैं।
