SMART SERVICES CENTRE — Android App Project
=============================================

यह ZIP एक Android app का SOURCE PROJECT है, तैयार APK नहीं।
इसमें आपकी वेबसाइट की HTML/CSS/JS फाइलें ऐप के अंदर जोड़ी गई हैं।
ऐप फोन पर वेबसाइट दिखाएगी और Call/WhatsApp जैसे लिंक खोल सकेगी।

फ्री में APK बनाने के लिए:
1. इस ZIP को AndroidIDE या Android Studio वाले वातावरण में खोलें।
2. Project को Gradle sync होने दें। इंटरनेट और compatible JDK/Android SDK चाहिए।
3. Build मेनू से Build APK(s) चुनें।
4. APK आम तौर पर app/build/outputs/apk/debug/app-debug.apk में बनेगी।
5. APK अपने फोन में install करने से पहले केवल अपने भरोसेमंद build source से बनी फाइल इस्तेमाल करें।

मोबाइल पर:
- AndroidIDE की आधिकारिक जानकारी: https://github.com/AndroidIDEOfficial/AndroidIDE
- Android ऐप बिल्ड के लिए Gradle और Android SDK की जरूरत होती है।
- यह project Android Studio/AndroidIDE के compatible version में build करने के लिए बनाया गया है।
- यदि Gradle/SDK version की error आए, तो error का screenshot भेजें; उसी के अनुसार मदद की जा सकती है।

ऐप विवरण:
App name: SMART SERVICES CENTRE
Package: in.smartservicescentre.app
Version: 1.0
Minimum Android: Android 6.0 (API 23)

महत्वपूर्ण:
- यह प्रोजेक्ट अभी Play Store पर प्रकाशित नहीं है।
- इस ZIP में निजी ग्राहक डेटा/लॉगिन/भुगतान सुविधा नहीं है।
- APK build और install की सफलता आपके Android build environment पर निर्भर करेगी।
