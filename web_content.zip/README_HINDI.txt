JUNGLE TIGER RUN - Android starter project

Yeh Android Studio project hai. Ismein 3D endless-runner game ka playable starter version hai.
Abhi yeh final professional game nahi hai. 3D graphics procedural models se bane hain aur Three.js CDN load karne ke liye internet chahiye.

APK banane ke steps:
1. Computer/laptop mein Android Studio install karein.
2. Android Studio > Open par click karke is ZIP ko extract karne ke baad JungleTigerRun folder select karein.
3. Gradle sync hone dein. JDK 17 use karein.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) par click karein.
5. APK app/build/outputs/apk/debug/app-debug.apk mein milega.

Phone par test:
- APK install karein aur internet ON rakhein.
- Game landscape mode mein khulega.
- Left/Right buttons ya swipe se lane badlein; JUMP button ya swipe-up se jump karein.

Note: Is chat se APK compile/sign nahi hua hai. Yeh source project hai jisse Android Studio mein APK build kiya ja sakta hai.
