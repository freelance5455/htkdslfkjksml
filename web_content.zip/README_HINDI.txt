IMLI AI - WEB APK EDITION
===========================

यह ZIP खास तौर पर ऐसे ZIP-to-APK builders के लिए है जो website ZIP मांगते हैं।

IMPORTANT:
- index.html ZIP की ROOT में है.
- कोई extra top-level folder नहीं है.
- Mic के लिए APK/WebView को microphone permission देनी होगी.
- SpeechRecognition का support Android WebView/builder पर निर्भर करता है.
- Web APK Android की security restrictions के कारण दूसरे apps को native Accessibility Service की तरह पूरी तरह control नहीं कर सकता.
- Wi-Fi/Bluetooth/Settings commands कुछ builders में Android intent support पर निर्भर करेंगे.

ZIP में:
index.html
README_HINDI.txt
