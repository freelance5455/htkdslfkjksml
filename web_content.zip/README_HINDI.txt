KISHAN RUNNING WORLD — Android Studio Project

यह Android ऐप का प्रोजेक्ट है। इसमें गेम WebView के अंदर ऑफलाइन चलता है और आपका दिया हुआ फोटो कैरेक्टर के रूप में शामिल है।

APK बनाने के लिए:
1. कंप्यूटर पर Android Studio इंस्टॉल करें।
2. इस ZIP को Extract करें।
3. Android Studio में इस फोल्डर को Open करें।
4. Gradle Sync पूरा होने दें और Android SDK Platform 35 इंस्टॉल करें।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
6. APK app/build/outputs/apk/debug/app-debug.apk में बनेगी।

ध्यान दें: इस वातावरण में Android SDK/Gradle build tool उपलब्ध नहीं है, इसलिए यहां से compiled APK बनाना संभव नहीं हुआ। यह Android Studio में build होने वाला source project है।
