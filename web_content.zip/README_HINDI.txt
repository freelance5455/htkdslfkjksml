INFINITY RUNNER — ANDROID PROJECT
=================================

यह Android Studio / Gradle प्रोजेक्ट है, APK बनाने के लिए starter project है। यह ZIP खुद APK नहीं है।

इसमें:
- Temple/jungle theme वाला Three.js 3D runner prototype
- Swipe left/right lane movement, swipe up jump
- Obstacles, coins, in-game magnet, golden skin
- Browser localStorage आधारित score/coin saving
- Android WebView wrapper और INTERNET permission

ज़रूरी बातें:
- index.html में Three.js CDN से लोड होता है, इसलिए गेम शुरू करते समय इंटरनेट चाहिए।
- Android System WebView / Chrome WebView में ES modules और WebGL support होना चाहिए।
- यह starter project Android Studio के modern Gradle setup के लिए है; AIDE के हर version में यह सीधे build नहीं होगा।
- असली rewarded ads के लिए AdMob SDK और अपने ad unit IDs जोड़ने होंगे। अभी कोई वास्तविक ad नहीं है।
- UPI link खोलना payment verification नहीं है। असली paid unlock के लिए सुरक्षित server/payment verification चाहिए। इस prototype में shop केवल in-game coins इस्तेमाल करती है।
- यह playable prototype है; production-ready Temple Run clone या commercial game नहीं।

BUILD (Android Studio):
1. ZIP extract करें और Android Studio में extracted InfinityRunner_Android_Project folder खोलें.
2. Gradle sync पूरा होने दें. JDK 17 इस्तेमाल करें.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK आम तौर पर app/build/outputs/apk/debug/app-debug.apk में मिलेगा.

COMMAND LINE (Android SDK + JDK 17 के साथ):
    gradle assembleDebug
या project wrapper जोड़ने के बाद:
    ./gradlew assembleDebug

अगर Gradle wrapper नहीं है, Android Studio के installed Gradle से build करें या Android Studio में project sync कर wrapper generate करें.

फोन पर test:
- APK build होने के बाद app-debug.apk को फोन पर भेजें और install करें.
- Unknown apps install permission की जरूरत पड़ सकती है.
