DK TUBE INDIA – Android APK banane ke liye source project

ZAROORI:
- Is ZIP mein JavaScript/HTML/CSS source project hai, ready APK nahi.
- APK banane ke liye computer par Node.js, Android Studio aur Android SDK chahiye.
- Is demo mein upload kiya video sirf usi phone/browser mein local save hota hai.
- Alag-alag logon ke accounts, online video upload, shared likes/comments, subscriptions ke liye secure backend (jaise Supabase/Firebase), database, storage aur moderation chahiye.

APK build ke steps (computer par):
1. Node.js LTS aur Android Studio install karein.
2. ZIP extract karein aur is folder mein terminal kholein.
3. Command chalayein: npm install
4. Command chalayein: npx cap add android
5. Command chalayein: npx cap sync android
6. Command chalayein: npx cap open android
7. Android Studio mein Build > Build Bundle(s) / APK(s) > Build APK(s) chunein.
8. APK Android Studio ke app/build/outputs/apk/debug/ folder mein milegi.

Sirf JavaScript ko phone mein bhejne se APK apne aap nahi banti. APK ko install karne se pehle trusted build aur security review zaroor karein.
