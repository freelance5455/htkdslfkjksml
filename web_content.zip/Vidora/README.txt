VIDORA — Android-friendly prototype
Creator: MD TORIKUL ISLAM

HOW TO OPEN
1. Extract Vidora_Prototype.zip on your Android phone.
2. Tap index.html and open it with Chrome or another browser.
3. Internet is needed to open the external web shortcuts.

IMPORTANT
This is a front-end prototype, not a production APK.
Google login, real video hosting/upload, shared comments, server-backed messaging,
SMS access, and secure Owner Admin are NOT connected yet. They require backend
development, authentication setup, permissions, testing, and deployment.
