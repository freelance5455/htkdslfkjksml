package com.dormoed.wallet;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.view.WindowManager;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b) {
  super.onCreate(b);
  getWindow().setStatusBarColor(0xff08080a);
  getWindow().setNavigationBarColor(0xff08080a);
  WebView w = new WebView(this);
  w.setBackgroundColor(0xff08080a);
  WebSettings s = w.getSettings();
  s.setJavaScriptEnabled(true);
  s.setDomStorageEnabled(true);
  s.setAllowFileAccess(true);
  w.loadUrl("file:///android_asset/index.html");
  setContentView(w);
 }
 @Override public void onBackPressed() { super.onBackPressed(); }
}
