package com.example.anasheed

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import kotlin.math.ceil

class AudioPlaybackService : Service() {

    private var player: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var audioManager: AudioManager
    private var minVolume = 0

    private val stopAfterSession = Runnable { stopPlayback() }
    private val volumeEnforcer = object : Runnable {
        override fun run() {
            enforceMinimumVolume()
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        minVolume = ceil(max * 0.97).toInt().coerceIn(0, max)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopPlayback()
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildNotification())
        if (player == null) startPlayback()
        handler.removeCallbacks(stopAfterSession)
        handler.postDelayed(stopAfterSession, SESSION_LENGTH_MS)
        handler.removeCallbacks(volumeEnforcer)
        handler.post(volumeEnforcer)
        return START_NOT_STICKY
    }

    private fun startPlayback() {
        try {
            val afd = assets.openFd("anthem.mp3")
            player = MediaPlayer().apply {
                setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                isLooping = true
                setOnPreparedListener { it.start() }
                setOnErrorListener { _, _, _ -> stopPlayback(); true }
                prepareAsync()
            }
            afd.close()
            enforceMinimumVolume()
        } catch (_: Exception) {
            stopPlayback()
        }
    }

    private fun enforceMinimumVolume() {
        if (!::audioManager.isInitialized) return
        val current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        if (current < minVolume) {
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, minVolume, 0)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        return builder
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("dz zabbbbi")
            .setContentText("الصوت يعمل في الخلفية — جلسة 3 دقائق")
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "تشغيل الصوت",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun stopPlayback() {
        handler.removeCallbacks(stopAfterSession)
        handler.removeCallbacks(volumeEnforcer)
        try {
            player?.stop()
        } catch (_: Exception) { }
        player?.release()
        player = null
        stopForeground(true)
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        player?.release()
        player = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.example.anasheed.action.START_AUDIO"
        const val ACTION_STOP = "com.example.anasheed.action.STOP_AUDIO"
        private const val CHANNEL_ID = "dz_zabbbbi_audio"
        private const val NOTIFICATION_ID = 97022
        private const val SESSION_LENGTH_MS = 3L * 60L * 1000L
    }
}
