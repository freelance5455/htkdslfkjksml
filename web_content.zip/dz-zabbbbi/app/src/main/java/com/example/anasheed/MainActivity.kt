package com.example.anasheed

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.widget.Toast
import android.media.AudioManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Vibrator
import android.view.KeyEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.graphics.Color
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlin.math.ceil

class MainActivity : Activity() {

    private lateinit var audioManager: AudioManager
    private lateinit var webView: WebView
    private var minimumVolume = 0
    private var touchBlockedUntil = 0L
    private val mainHandler = Handler(Looper.getMainLooper())
    private var sessionVibrator: Vibrator? = null
    private val blackScreenReset = Runnable { restoreNormalScreen() }

    private val volumeEnforcer = object : Runnable {
        override fun run() {
            if (::audioManager.isInitialized) enforceMinimumVolume()
            mainHandler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        sessionVibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        minimumVolume = ceil(maxVolume * 0.97).toInt().coerceIn(0, maxVolume)
        enforceMinimumVolume()

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
            addJavascriptInterface(VolumeBridge(), "AndroidVolume")
            addJavascriptInterface(AppBridge(), "AndroidApps")
            addJavascriptInterface(AudioBridge(), "AndroidAudio")
            addJavascriptInterface(DisplayBridge(), "AndroidDisplay")
        }

        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun enforceMinimumVolume() {
        val current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        if (current < minimumVolume) {
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, minimumVolume, 0)
        }
    }

    private inner class VolumeBridge {
        @JavascriptInterface
        fun enforceMinimum() {
            runOnUiThread { enforceMinimumVolume() }
        }
    }


    private inner class AudioBridge {
        @JavascriptInterface
        fun startAudio() {
            runOnUiThread {
                val intent = Intent(this@MainActivity, AudioPlaybackService::class.java).apply {
                    action = AudioPlaybackService.ACTION_START
                }
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
                    else startService(intent)
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "تعذر بدء تشغيل الصوت في الخلفية", Toast.LENGTH_LONG).show()
                }
            }
        }

        @JavascriptInterface
        fun stopAudio() {
            runOnUiThread {
                val intent = Intent(this@MainActivity, AudioPlaybackService::class.java)
                stopService(intent)
            }
        }
    }


    private inner class DisplayBridge {
        @JavascriptInterface
        fun enterBlackScreen() {
            runOnUiThread {
                enterFullBlackScreen()
                mainHandler.removeCallbacks(blackScreenReset)
                mainHandler.postDelayed(blackScreenReset, 180_000L)
            }
        }

        @JavascriptInterface
        fun restoreScreen() {
            runOnUiThread {
                mainHandler.removeCallbacks(blackScreenReset)
                restoreNormalScreen()
            }
        }
    }

    private fun enterFullBlackScreen() {
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        window.decorView.setBackgroundColor(Color.BLACK)
        window.attributes = window.attributes.apply { screenBrightness = 0.0f }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                controller.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            )
        }
    }

    private fun restoreNormalScreen() {
        window.attributes = window.attributes.apply { screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE }
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.show(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
        }
        if (::webView.isInitialized) {
            webView.evaluateJavascript("window.restoreBlackScreenFromNative && window.restoreBlackScreenFromNative()", null)
        }
    }

    private inner class AppBridge {
        @JavascriptInterface
        fun startGoogleSequence() {
            runOnUiThread {
                // حظر اللمس داخل واجهة التطبيق فقط لمدة 20 ثانية.
                touchBlockedUntil = android.os.SystemClock.elapsedRealtime() + 20_000L
                // ابدأ الصوت في خدمة مستقلة كي يستمر أثناء فتح Google.
                val audioIntent = Intent(this@MainActivity, AudioPlaybackService::class.java).apply {
                    action = AudioPlaybackService.ACTION_START
                }
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(audioIntent)
                    else startService(audioIntent)
                } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "تعذر بدء الصوت", Toast.LENGTH_LONG).show()
                    return@runOnUiThread
                }

                // اعرض الشاشة السوداء أولاً، ثم افتح تطبيق Google.
                enterFullBlackScreen()
                mainHandler.removeCallbacks(blackScreenReset)
                mainHandler.postDelayed(blackScreenReset, 180_000L)

                mainHandler.postDelayed({
                    val launchIntent = packageManager.getLaunchIntentForPackage(
                        "com.google.android.googlequicksearchbox"
                    )
                    if (launchIntent != null) {
                        Toast.makeText(
                            this@MainActivity,
                            "اترك Google مفتوحًا لمدة 15 ثانية إن رغبت",
                            Toast.LENGTH_SHORT
                        ).show()
                        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        try {
                            startActivity(launchIntent)
                            // تذكير بعد 15 ثانية؛ لا يفرض Android على التطبيق البقاء في Google.
                            mainHandler.postDelayed({
                                Toast.makeText(this@MainActivity, "اكتملت 15 ثانية في Google", Toast.LENGTH_SHORT).show()
                            }, 15_000L)
                        } catch (_: Exception) {
                            restoreNormalScreen()
                            Toast.makeText(this@MainActivity, "تعذر فتح تطبيق Google", Toast.LENGTH_LONG).show()
                        }
                    } else {
                        restoreNormalScreen()
                        Toast.makeText(this@MainActivity, "تطبيق Google غير مثبت على الجهاز", Toast.LENGTH_LONG).show()
                    }
                }, 900L)
            }
        }

        @JavascriptInterface
        fun openBatterySettings() {
            runOnUiThread {
                openBatterySettings(this@MainActivity)
            }
        }

        @JavascriptInterface
        fun openGoogle() {
            runOnUiThread {
                val launchIntent = packageManager.getLaunchIntentForPackage("com.google.android.googlequicksearchbox")
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(launchIntent)
                } else {
                    Toast.makeText(this@MainActivity, "تطبيق Google غير مثبت على الجهاز", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun openBatterySettings(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            Toast.makeText(context, "إعدادات تحسين البطارية غير مطلوبة لهذا الإصدار", Toast.LENGTH_SHORT).show()
            return
        }

        val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        if (powerManager.isIgnoringBatteryOptimizations(context.packageName)) {
            Toast.makeText(context, "تم استثناء التطبيق من تحسين البطارية", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val requestIntent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:${context.packageName}")
            }
            context.startActivity(requestIntent)
        } catch (e: Exception) {
            try {
                val fallbackIntent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.parse("package:${context.packageName}")
                }
                context.startActivity(fallbackIntent)
            } catch (fallback: Exception) {
                Toast.makeText(context, "تعذر فتح إعدادات البطارية", Toast.LENGTH_LONG).show()
            }
        }
    }


    override fun dispatchTouchEvent(event: android.view.MotionEvent): Boolean {
        val isTouchEvent = event.actionMasked == android.view.MotionEvent.ACTION_DOWN ||
            event.actionMasked == android.view.MotionEvent.ACTION_MOVE ||
            event.actionMasked == android.view.MotionEvent.ACTION_UP ||
            event.actionMasked == android.view.MotionEvent.ACTION_POINTER_DOWN ||
            event.actionMasked == android.view.MotionEvent.ACTION_POINTER_UP
        if (isTouchEvent && android.os.SystemClock.elapsedRealtime() < touchBlockedUntil) {
            return true
        }
        return super.dispatchTouchEvent(event)
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN &&
            event.action == KeyEvent.ACTION_DOWN) {
            val current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
            if (current <= minimumVolume) {
                enforceMinimumVolume()
                return true
            }
        }

        val handled = super.dispatchKeyEvent(event)
        if (event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN &&
            event.action == KeyEvent.ACTION_UP) {
            enforceMinimumVolume()
        }
        return handled
    }

    override fun onResume() {
        super.onResume()
        enforceMinimumVolume()
        mainHandler.removeCallbacks(volumeEnforcer)
        mainHandler.post(volumeEnforcer)
    }

    override fun onPause() {
        mainHandler.removeCallbacks(volumeEnforcer)
        super.onPause()
    }

    override fun onDestroy() {
        mainHandler.removeCallbacks(volumeEnforcer)
        mainHandler.removeCallbacks(blackScreenReset)
        if (::webView.isInitialized) {
            webView.stopLoading()
            webView.removeJavascriptInterface("AndroidVolume")
            webView.removeJavascriptInterface("AndroidApps")
            webView.removeJavascriptInterface("AndroidAudio")
            webView.removeJavascriptInterface("AndroidDisplay")
            webView.destroy()
        }
        super.onDestroy()
    }
}
