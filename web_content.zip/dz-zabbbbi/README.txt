dz zabbbbi — مشروع Android Studio

واجهة التطبيق:
- زر واحد فقط: «افتح جوجل الآن».
- عند الضغط يبدأ الصوت عبر Foreground Service، ثم تُعرض طبقة سوداء كاملة ويُفتح تطبيق Google.
- الصوت يستمر في الخلفية لمدة تصل إلى 3 دقائق ثم يتوقف تلقائياً.
- يظهر تذكير بعد 15 ثانية من فتح Google.

الميزات التقنية المحفوظة:
- الحد الأدنى لمستوى صوت الوسائط يقارب 97% من الحد الأقصى المتاح، مع فرضه أثناء تشغيل خدمة الصوت.
- Foreground Service من نوع mediaPlayback لاستمرار الصوت عند الانتقال إلى Google.
- Wake mode للصوت وإشعار دائم أثناء التشغيل.
- فتح إعدادات استثناء تحسين البطارية موجود في طبقة Android، ولا يظهر كزر في الواجهة.
- اسم التطبيق: dz zabbbbi.

مهم بشأن مدة 15 ثانية:
Android لا يسمح لتطبيق عادي بإجبار المستخدم على البقاء داخل تطبيق Google أو منع زر الرجوع/الصفحة الرئيسية. لذلك يعرض التطبيق تذكيراً بعد 15 ثانية، لكنه لا يقفل Google ولا يمنع الخروج. يمكن للمستخدم تفعيل تثبيت الشاشة (Screen pinning) يدوياً من إعدادات Android إذا أراد ذلك، مع اتباع تعليمات جهازه.

مهم بشأن الشاشة السوداء:
- الشاشة السوداء هي واجهة داخل نشاط التطبيق مع إخفاء أشرطة النظام وخفض سطوع نافذته؛ ليست طبقة تظل فوق Google بعد فتحه.
- عند الرجوع إلى dz zabbbbi يبقى النشاط على وضعه الأسود حتى انتهاء مؤقت الثلاث دقائق أو استعادة الواجهة.
- قد يستطيع المستخدم إظهار أشرطة النظام بالسحب وفق سلوك Android.

الصلاحيات:
- FOREGROUND_SERVICE
- FOREGROUND_SERVICE_MEDIA_PLAYBACK
- FOREGROUND_SERVICE_SPECIAL_USE (موجود في Manifest لكنه غير مستخدم؛ الخدمة تعمل بالنوع mediaPlayback)
- WAKE_LOCK
- REQUEST_IGNORE_BATTERY_OPTIMIZATIONS

البناء:
1. فك ضغط الملف.
2. افتح مجلد dz-zabbbbi في Android Studio.
3. انتظر اكتمال Gradle Sync.
4. اختر Build > Build Bundle(s) / APK(s) > Build APK(s).
5. ستجد APK عادةً في app/build/outputs/apk/debug/.

ملاحظات:
- يجب تثبيت تطبيق Google الرسمي حتى يعمل زر الفتح.
- بعض هواتف Infinix/XOS تتضمن إدارة طاقة إضافية؛ قد يلزم السماح بالتشغيل التلقائي وعدم تقييد التطبيق من إعدادات البطارية.
- Android قد يوقف الخدمة في حالات استثنائية مثل فرض الإيقاف من إعدادات النظام أو نفاد البطارية.
- قيمة 97% تقرّب إلى أقرب درجة صوت يدعمها الهاتف، وليست نسبة مستمرة دقيقة.
- هذا مشروع Android Studio، وليس APK مبنياً أو مختبراً على هاتف فعلي.


Touch handling update:
After tapping "افتح جوجل الآن", touch input is ignored inside this app for up to 20 seconds. This does NOT disable touch in Google or Android system UI; ordinary apps cannot globally block another app's touch input. Google remains usable.
