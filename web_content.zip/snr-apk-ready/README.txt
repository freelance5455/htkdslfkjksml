APK BUILDER PACKAGE
This is a standalone static web app. Upload the contents of this folder or the ZIP to a Web-to-APK builder.
index.html must be at the ZIP root.
It connects to Binance Spot REST/WebSocket for live market data.
No trade execution. Signals are analysis only.
