# ANONYMOUX STUDIO 2.5.5 installation

1. Back up the live application directory and database before deployment.
2. Upload and extract the complete archive over the existing application. Do not overwrite private `config.local.php`, uploaded media, generated media or storage contents with sample files.
3. Keep PHP 8+, PDO, PDO_SQLITE (for SQLite deployments), OpenSSL and cURL enabled. Ensure outbound HTTPS to `api.flutterwave.com` and `api.fish.audio` is allowed.
4. Preserve the existing database and credentials. The package schema adds `sort_order`, `promo_badge` and `bonus_credits` using additive checks. If running migrations manually, execute migration `006_credit_package_options_<driver>.sql` only when those columns are not already present; the application bootstrap performs safe conditional upgrades itself.
5. Sign in as an administrator. Review Admin → Payments and confirm the four packages and Flutterwave test configuration before enabling live checkout.
6. Review Admin → Voice AI. Confirm the Fish Audio API key is active and the encryption secret is unchanged. Do not paste secrets into source files or browser code.
7. Test a Flutterwave test-mode purchase and verify the wallet ledger. Configure the webhook URL to `/api/flutterwave-webhook.php` and verify webhook secret hash settings.
8. Test Agent Studio with an account entitled to the Fish Audio Agents API. Check server logs for sanitized HTTP status/provider diagnostics if a provider request is rejected.
9. Confirm Explore remains available and `/shorts-studio.php` returns 404.

Do not enable production billing until test-mode payments, duplicate webhook handling and provider acceptance have been verified on the target host.
