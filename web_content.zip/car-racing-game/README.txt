🚗 CAR RACING GAME - HTML5
==========================

Yeh ek simple HTML5 Car Racing Game hai.
Mobile pe best chalega (touch controls + swipe).

KAISA KHELEIN:
--------------
- Left/Right buttons dabao ya swipe karo
- Obstacles se bacho
- Score badhao

APK BANANE KE LIYE (Android):
-----------------------------
Sabse aasan tarika:

1. Website: https://www.webintoapp.com/  ya  https://appsgeyser.com/
   - HTML folder upload karo
   - APK generate ho jayega

2. Cordova / Capacitor use karke (advanced):
   - npm install -g cordova
   - cordova create MyCarGame
   - www folder me ye files copy karo
   - cordova platform add android
   - cordova build android

3. Android Studio me WebView app banao aur index.html load karo.

Files:
- index.html
- style.css  
- script.js

Bas in 3 files ko zip me rakh ke upload kar sakte ho WebIntoApp jaise tools pe.
