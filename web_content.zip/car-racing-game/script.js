const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const scoreEl = document.getElementById('score');
const speedEl = document.getElementById('speed');
const highScoreEl = document.getElementById('highScore');
const startScreen = document.getElementById('start-screen');
const gameOverScreen = document.getElementById('game-over');
const finalScoreEl = document.getElementById('finalScore');
const startBtn = document.getElementById('startBtn');
const restartBtn = document.getElementById('restartBtn');
const leftBtn = document.getElementById('leftBtn');
const rightBtn = document.getElementById('rightBtn');

function resize() {
    const container = document.getElementById('game-container');
    canvas.width = container.clientWidth;
    canvas.height = container.clientHeight;
}
window.addEventListener('resize', resize);
resize();

// Game state
let gameRunning = false;
let score = 0;
let highScore = localStorage.getItem('carHighScore') || 0;
highScoreEl.textContent = 'High: ' + highScore;
let speed = 4.5;
let roadOffset = 0;
let carX = 0;
let carLane = 1;
const lanes = 3;
let obstacles = [];
let particles = [];
let lastObstacleTime = 0;
let keys = {};
let touchStartX = 0;
let shakeTime = 0;

// Better proportions
const carWidth = 54;
const carHeight = 100;

function getLaneX(lane) {
    const roadWidth = canvas.width * 0.72;
    const roadLeft = (canvas.width - roadWidth) / 2;
    const laneWidth = roadWidth / lanes;
    return roadLeft + lane * laneWidth + laneWidth / 2 - carWidth / 2;
}

function initGame() {
    score = 0;
    speed = 4.5;
    roadOffset = 0;
    carLane = 1;
    carX = getLaneX(carLane);
    obstacles = [];
    particles = [];
    lastObstacleTime = 0;
    shakeTime = 0;
    scoreEl.textContent = 'Score: 0';
    speedEl.textContent = 'Speed: ' + Math.floor(speed * 12);
}

function startGame() {
    initGame();
    startScreen.classList.add('hidden');
    gameOverScreen.classList.add('hidden');
    gameRunning = true;
    requestAnimationFrame(gameLoop);
}

function endGame() {
    gameRunning = false;
    // Explosion particles
    for (let i = 0; i < 25; i++) {
        particles.push({
            x: carX + carWidth / 2,
            y: canvas.height - carHeight - 20,
            vx: (Math.random() - 0.5) * 12,
            vy: (Math.random() - 0.5) * 12,
            life: 40 + Math.random() * 20,
            color: ['#ff4400', '#ff8800', '#ffcc00', '#fff'][Math.floor(Math.random() * 4)],
            size: 3 + Math.random() * 5
        });
    }
    shakeTime = 20;
    if (score > highScore) {
        highScore = score;
        localStorage.setItem('carHighScore', highScore);
        highScoreEl.textContent = 'High: ' + highScore;
    }
    finalScoreEl.textContent = 'Score: ' + score;
    setTimeout(() => {
        gameOverScreen.classList.remove('hidden');
    }, 600);
}

// Input
document.addEventListener('keydown', e => {
    keys[e.key] = true;
    if (e.key === 'ArrowLeft' || e.key === 'a') moveLeft();
    if (e.key === 'ArrowRight' || e.key === 'd') moveRight();
});
document.addEventListener('keyup', e => keys[e.key] = false);

leftBtn.addEventListener('touchstart', e => { e.preventDefault(); moveLeft(); });
rightBtn.addEventListener('touchstart', e => { e.preventDefault(); moveRight(); });
leftBtn.addEventListener('mousedown', () => moveLeft());
rightBtn.addEventListener('mousedown', () => moveRight());

canvas.addEventListener('touchstart', e => {
    touchStartX = e.touches[0].clientX;
});
canvas.addEventListener('touchend', e => {
    const dx = e.changedTouches[0].clientX - touchStartX;
    if (dx < -35) moveLeft();
    if (dx > 35) moveRight();
});

function moveLeft() {
    if (carLane > 0) carLane--;
}
function moveRight() {
    if (carLane < lanes - 1) carLane++;
}

function spawnObstacle() {
    const lane = Math.floor(Math.random() * lanes);
    // Avoid same lane as player sometimes
    const types = ['car', 'car', 'truck', 'cone', 'police'];
    const type = types[Math.floor(Math.random() * types.length)];
    const colors = ['#9b59b6', '#3498db', '#e67e22', '#1abc9c', '#e74c3c', '#f1c40f'];
    obstacles.push({
        lane: lane,
        y: -120,
        type: type,
        color: colors[Math.floor(Math.random() * colors.length)],
        width: type === 'truck' ? 58 : type === 'cone' ? 28 : 50,
        height: type === 'truck' ? 115 : type === 'cone' ? 45 : 95
    });
}

function update(dt) {
    if (!gameRunning && particles.length === 0) return;

    if (gameRunning) {
        speed += 0.0018;
        roadOffset += speed * 2.2;
        if (roadOffset > 45) roadOffset = 0;

        const targetX = getLaneX(carLane);
        carX += (targetX - carX) * 0.22;

        lastObstacleTime += dt;
        const spawnRate = Math.max(900 - speed * 35, 380);
        if (lastObstacleTime > spawnRate) {
            spawnObstacle();
            lastObstacleTime = 0;
        }

        for (let i = obstacles.length - 1; i >= 0; i--) {
            obstacles[i].y += speed * 1.55;
            if (obstacles[i].y > canvas.height + 60) {
                obstacles.splice(i, 1);
                score += 12;
                scoreEl.textContent = 'Score: ' + score;
            }
        }

        // Collision
        const carY = canvas.height - carHeight - 50;
        for (let obs of obstacles) {
            const obsX = getLaneX(obs.lane) + (carWidth - obs.width) / 2;
            if (obs.y + obs.height > carY + 15 && obs.y < carY + carHeight - 10 &&
                Math.abs(obsX - carX) < (carWidth + obs.width) / 2 - 12) {
                endGame();
                return;
            }
        }

        // Exhaust particles
        if (Math.random() < 0.4) {
            particles.push({
                x: carX + carWidth / 2 + (Math.random() - 0.5) * 10,
                y: canvas.height - 45,
                vx: (Math.random() - 0.5) * 1.5,
                vy: 2 + Math.random() * 2,
                life: 15 + Math.random() * 10,
                color: '#555',
                size: 2 + Math.random() * 3
            });
        }

        speedEl.textContent = 'Speed: ' + Math.floor(speed * 12);
    }

    // Particles update
    for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.life--;
        p.size *= 0.96;
        if (p.life <= 0) particles.splice(i, 1);
    }

    if (shakeTime > 0) shakeTime--;
}

function drawRoad() {
    const roadWidth = canvas.width * 0.72;
    const roadLeft = (canvas.width - roadWidth) / 2;

    // Dark grass with subtle pattern
    ctx.fillStyle = '#1a3a1a';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Grass texture lines
    ctx.strokeStyle = 'rgba(30, 70, 30, 0.4)';
    ctx.lineWidth = 1;
    for (let y = (roadOffset * 0.5) % 20; y < canvas.height; y += 20) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(roadLeft - 5, y);
        ctx.moveTo(roadLeft + roadWidth + 5, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
    }

    // Road base
    const grad = ctx.createLinearGradient(roadLeft, 0, roadLeft + roadWidth, 0);
    grad.addColorStop(0, '#2a2a2a');
    grad.addColorStop(0.05, '#3d3d3d');
    grad.addColorStop(0.95, '#3d3d3d');
    grad.addColorStop(1, '#2a2a2a');
    ctx.fillStyle = grad;
    ctx.fillRect(roadLeft, 0, roadWidth, canvas.height);

    // Yellow edge lines
    ctx.strokeStyle = '#f1c40f';
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.moveTo(roadLeft + 3, 0);
    ctx.lineTo(roadLeft + 3, canvas.height);
    ctx.moveTo(roadLeft + roadWidth - 3, 0);
    ctx.lineTo(roadLeft + roadWidth - 3, canvas.height);
    ctx.stroke();

    // White dashed lane lines
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 4;
    ctx.setLineDash([28, 22]);
    ctx.lineDashOffset = -roadOffset;

    for (let i = 1; i < lanes; i++) {
        const x = roadLeft + (roadWidth / lanes) * i;
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
    }
    ctx.setLineDash([]);
}

// ============ BETTER CAR DRAWING ============
function drawSportsCar(x, y, color, isPlayer = false) {
    ctx.save();
    
    // Shadow
    ctx.fillStyle = 'rgba(0,0,0,0.35)';
    ctx.beginPath();
    ctx.ellipse(x + carWidth/2, y + carHeight - 8, carWidth/2 + 4, 10, 0, 0, Math.PI * 2);
    ctx.fill();

    // Main body - sleek shape
    ctx.fillStyle = color;
    // Bottom body
    ctx.beginPath();
    ctx.moveTo(x + 4, y + 25);
    ctx.lineTo(x + carWidth - 4, y + 25);
    ctx.lineTo(x + carWidth - 2, y + carHeight - 22);
    ctx.lineTo(x + 2, y + carHeight - 22);
    ctx.closePath();
    ctx.fill();

    // Upper body / cabin
    ctx.fillStyle = shadeColor(color, -25);
    ctx.beginPath();
    ctx.moveTo(x + 10, y + 28);
    ctx.lineTo(x + carWidth - 10, y + 28);
    ctx.lineTo(x + carWidth - 14, y + 58);
    ctx.lineTo(x + 14, y + 58);
    ctx.closePath();
    ctx.fill();

    // Hood slope
    ctx.fillStyle = shadeColor(color, 15);
    ctx.beginPath();
    ctx.moveTo(x + 6, y + 25);
    ctx.lineTo(x + carWidth - 6, y + 25);
    ctx.lineTo(x + carWidth - 12, y + 12);
    ctx.lineTo(x + 12, y + 12);
    ctx.closePath();
    ctx.fill();

    // Roof
    ctx.fillStyle = shadeColor(color, -40);
    ctx.fillRect(x + 16, y + 32, carWidth - 32, 22);

    // Windshield
    const glassGrad = ctx.createLinearGradient(x, y + 30, x, y + 55);
    glassGrad.addColorStop(0, '#87ceeb');
    glassGrad.addColorStop(1, '#1a5276');
    ctx.fillStyle = glassGrad;
    ctx.beginPath();
    ctx.moveTo(x + 14, y + 30);
    ctx.lineTo(x + carWidth - 14, y + 30);
    ctx.lineTo(x + carWidth - 18, y + 52);
    ctx.lineTo(x + 18, y + 52);
    ctx.closePath();
    ctx.fill();

    // Side windows
    ctx.fillStyle = 'rgba(135, 206, 235, 0.7)';
    ctx.fillRect(x + 6, y + 38, 8, 16);
    ctx.fillRect(x + carWidth - 14, y + 38, 8, 16);

    // Rear spoiler (player only)
    if (isPlayer) {
        ctx.fillStyle = shadeColor(color, -50);
        ctx.fillRect(x + 8, y + 8, carWidth - 16, 6);
        ctx.fillRect(x + 6, y + 4, 6, 12);
        ctx.fillRect(x + carWidth - 12, y + 4, 6, 12);
    }

    // Headlights
    ctx.fillStyle = isPlayer ? '#fff9c4' : '#ffcccc';
    ctx.shadowColor = isPlayer ? '#ffee58' : '#ff6666';
    ctx.shadowBlur = isPlayer ? 12 : 6;
    ctx.beginPath();
    ctx.ellipse(x + 12, y + 18, 7, 4, 0, 0, Math.PI * 2);
    ctx.ellipse(x + carWidth - 12, y + 18, 7, 4, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    // Taillights
    ctx.fillStyle = '#ff1744';
    ctx.shadowColor = '#ff1744';
    ctx.shadowBlur = 8;
    ctx.fillRect(x + 8, y + carHeight - 20, 12, 6);
    ctx.fillRect(x + carWidth - 20, y + carHeight - 20, 12, 6);
    ctx.shadowBlur = 0;

    // Wheels
    ctx.fillStyle = '#111';
    // Front left
    ctx.beginPath();
    ctx.roundRect(x - 3, y + 28, 11, 22, 3);
    ctx.fill();
    // Front right
    ctx.beginPath();
    ctx.roundRect(x + carWidth - 8, y + 28, 11, 22, 3);
    ctx.fill();
    // Rear left
    ctx.beginPath();
    ctx.roundRect(x - 3, y + carHeight - 42, 11, 22, 3);
    ctx.fill();
    // Rear right
    ctx.beginPath();
    ctx.roundRect(x + carWidth - 8, y + carHeight - 42, 11, 22, 3);
    ctx.fill();

    // Wheel rims
    ctx.fillStyle = '#888';
    ctx.beginPath();
    ctx.arc(x + 2.5, y + 39, 4, 0, Math.PI * 2);
    ctx.arc(x + carWidth - 2.5, y + 39, 4, 0, Math.PI * 2);
    ctx.arc(x + 2.5, y + carHeight - 31, 4, 0, Math.PI * 2);
    ctx.arc(x + carWidth - 2.5, y + carHeight - 31, 4, 0, Math.PI * 2);
    ctx.fill();

    // Stripe for player
    if (isPlayer) {
        ctx.fillStyle = 'rgba(255,255,255,0.25)';
        ctx.fillRect(x + carWidth/2 - 4, y + 14, 8, carHeight - 36);
    }

    ctx.restore();
}

function shadeColor(color, percent) {
    const num = parseInt(color.replace('#', ''), 16);
    const amt = Math.round(2.55 * percent);
    const R = Math.max(0, Math.min(255, (num >> 16) + amt));
    const G = Math.max(0, Math.min(255, ((num >> 8) & 0x00FF) + amt));
    const B = Math.max(0, Math.min(255, (num & 0x0000FF) + amt));
    return '#' + (0x1000000 + R * 0x10000 + G * 0x100 + B).toString(16).slice(1);
}

function drawTruck(x, y, color) {
    ctx.save();
    // Shadow
    ctx.fillStyle = 'rgba(0,0,0,0.3)';
    ctx.beginPath();
    ctx.ellipse(x + 29, y + 105, 32, 9, 0, 0, Math.PI * 2);
    ctx.fill();

    // Cargo
    ctx.fillStyle = shadeColor(color, -20);
    ctx.fillRect(x + 2, y + 35, 54, 70);
    // Cargo lines
    ctx.strokeStyle = 'rgba(0,0,0,0.2)';
    ctx.lineWidth = 2;
    for (let i = 1; i < 4; i++) {
        ctx.beginPath();
        ctx.moveTo(x + 2, y + 35 + i * 17);
        ctx.lineTo(x + 56, y + 35 + i * 17);
        ctx.stroke();
    }

    // Cabin
    ctx.fillStyle = color;
    ctx.fillRect(x + 6, y + 5, 46, 35);
    
    // Cabin top
    ctx.fillStyle = shadeColor(color, -30);
    ctx.fillRect(x + 10, y + 8, 38, 18);

    // Windshield
    ctx.fillStyle = '#5dade2';
    ctx.fillRect(x + 12, y + 12, 34, 14);

    // Headlights
    ctx.fillStyle = '#fff9c4';
    ctx.fillRect(x + 8, y + 32, 10, 6);
    ctx.fillRect(x + 40, y + 32, 10, 6);

    // Wheels
    ctx.fillStyle = '#111';
    ctx.beginPath();
    ctx.roundRect(x - 2, y + 45, 12, 20, 3);
    ctx.roundRect(x + 48, y + 45, 12, 20, 3);
    ctx.roundRect(x - 2, y + 85, 12, 20, 3);
    ctx.roundRect(x + 48, y + 85, 12, 20, 3);
    ctx.fill();

    ctx.restore();
}

function drawCone(x, y) {
    ctx.save();
    // Shadow
    ctx.fillStyle = 'rgba(0,0,0,0.25)';
    ctx.beginPath();
    ctx.ellipse(x + 14, y + 42, 16, 6, 0, 0, Math.PI * 2);
    ctx.fill();

    // Cone body
    const grad = ctx.createLinearGradient(x, y, x + 28, y);
    grad.addColorStop(0, '#e67e22');
    grad.addColorStop(0.5, '#f39c12');
    grad.addColorStop(1, '#d35400');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(x + 14, y);
    ctx.lineTo(x, y + 42);
    ctx.lineTo(x + 28, y + 42);
    ctx.closePath();
    ctx.fill();

    // White stripes
    ctx.fillStyle = '#fff';
    ctx.beginPath();
    ctx.moveTo(x + 11, y + 12);
    ctx.lineTo(x + 5, y + 22);
    ctx.lineTo(x + 23, y + 22);
    ctx.lineTo(x + 17, y + 12);
    ctx.closePath();
    ctx.fill();

    ctx.beginPath();
    ctx.moveTo(x + 9, y + 26);
    ctx.lineTo(x + 3, y + 36);
    ctx.lineTo(x + 25, y + 36);
    ctx.lineTo(x + 19, y + 26);
    ctx.closePath();
    ctx.fill();

    // Base
    ctx.fillStyle = '#e67e22';
    ctx.fillRect(x - 2, y + 40, 32, 6);

    ctx.restore();
}

function drawPoliceCar(x, y) {
    drawSportsCar(x, y, '#2c3e50', false);
    // Light bar
    ctx.fillStyle = '#111';
    ctx.fillRect(x + 14, y + 8, 26, 8);
    // Flashing lights
    const flash = Math.floor(Date.now() / 150) % 2;
    ctx.fillStyle = flash ? '#e74c3c' : '#3498db';
    ctx.shadowColor = flash ? '#e74c3c' : '#3498db';
    ctx.shadowBlur = 10;
    ctx.fillRect(x + 15, y + 9, 11, 6);
    ctx.fillStyle = flash ? '#3498db' : '#e74c3c';
    ctx.shadowColor = flash ? '#3498db' : '#e74c3c';
    ctx.fillRect(x + 28, y + 9, 11, 6);
    ctx.shadowBlur = 0;
}

function drawObstacle(obs) {
    const x = getLaneX(obs.lane) + (carWidth - obs.width) / 2;
    const y = obs.y;

    if (obs.type === 'cone') {
        drawCone(x, y);
    } else if (obs.type === 'truck') {
        drawTruck(x, y, obs.color);
    } else if (obs.type === 'police') {
        drawPoliceCar(x, y);
    } else {
        drawSportsCar(x, y, obs.color, false);
    }
}

function drawParticles() {
    for (const p of particles) {
        ctx.globalAlpha = Math.min(1, p.life / 20);
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
    }
    ctx.globalAlpha = 1;
}

function draw() {
    ctx.save();
    // Screen shake
    if (shakeTime > 0) {
        const sx = (Math.random() - 0.5) * 8;
        const sy = (Math.random() - 0.5) * 8;
        ctx.translate(sx, sy);
    }

    ctx.clearRect(-10, -10, canvas.width + 20, canvas.height + 20);
    drawRoad();

    for (let obs of obstacles) {
        drawObstacle(obs);
    }

    drawParticles();

    if (gameRunning || particles.length > 0) {
        const carY = canvas.height - carHeight - 50;
        drawSportsCar(carX, carY, '#e74c3c', true);
    }

    ctx.restore();
}

let lastTime = 0;
function gameLoop(timestamp) {
    const dt = timestamp - lastTime || 16;
    lastTime = timestamp;

    update(dt);
    draw();

    if (gameRunning || particles.length > 0 || shakeTime > 0) {
        requestAnimationFrame(gameLoop);
    }
}

startBtn.addEventListener('click', startGame);
restartBtn.addEventListener('click', startGame);

// Initial draw
drawRoad();
drawSportsCar(getLaneX(1), canvas.height - carHeight - 50, '#e74c3c', true);
