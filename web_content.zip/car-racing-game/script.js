const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const scoreEl = document.getElementById('score');
const speedEl = document.getElementById('speed');
const highScoreEl = document.getElementById('highScore');
const startScreen = document.getElementById('start-screen');
const gameOverScreen = document.getElementById('game-over');
const finalScoreEl = document.getElementById('finalScore');
const startBtn = document.getElementById('startBtn');
const restartBtn = document.getElementById('restartBtn');
const leftBtn = document.getElementById('leftBtn');
const rightBtn = document.getElementById('rightBtn');

// Resize canvas
function resize() {
    const container = document.getElementById('game-container');
    canvas.width = container.clientWidth;
    canvas.height = container.clientHeight;
}
window.addEventListener('resize', resize);
resize();

// Game state
let gameRunning = false;
let score = 0;
let highScore = localStorage.getItem('carHighScore') || 0;
highScoreEl.textContent = 'High: ' + highScore;
let speed = 5;
let roadOffset = 0;
let carX = 0;
let carLane = 1; // 0,1,2
const lanes = 3;
let obstacles = [];
let lastObstacleTime = 0;
let keys = {};
let touchStartX = 0;

// Car properties
const carWidth = 50;
const carHeight = 90;

// Colors
const roadColor = '#444';
const lineColor = '#fff';
const grassColor = '#2d5a27';

function getLaneX(lane) {
    const roadWidth = canvas.width * 0.7;
    const roadLeft = (canvas.width - roadWidth) / 2;
    const laneWidth = roadWidth / lanes;
    return roadLeft + lane * laneWidth + laneWidth / 2 - carWidth / 2;
}

function initGame() {
    score = 0;
    speed = 5;
    roadOffset = 0;
    carLane = 1;
    carX = getLaneX(carLane);
    obstacles = [];
    lastObstacleTime = 0;
    scoreEl.textContent = 'Score: 0';
    speedEl.textContent = 'Speed: ' + Math.floor(speed * 10);
}

function startGame() {
    initGame();
    startScreen.classList.add('hidden');
    gameOverScreen.classList.add('hidden');
    gameRunning = true;
    requestAnimationFrame(gameLoop);
}

function endGame() {
    gameRunning = false;
    if (score > highScore) {
        highScore = score;
        localStorage.setItem('carHighScore', highScore);
        highScoreEl.textContent = 'High: ' + highScore;
    }
    finalScoreEl.textContent = 'Score: ' + score;
    gameOverScreen.classList.remove('hidden');
}

// Input
document.addEventListener('keydown', e => {
    keys[e.key] = true;
    if (e.key === 'ArrowLeft' || e.key === 'a') moveLeft();
    if (e.key === 'ArrowRight' || e.key === 'd') moveRight();
});
document.addEventListener('keyup', e => keys[e.key] = false);

leftBtn.addEventListener('touchstart', e => { e.preventDefault(); moveLeft(); });
rightBtn.addEventListener('touchstart', e => { e.preventDefault(); moveRight(); });
leftBtn.addEventListener('mousedown', () => moveLeft());
rightBtn.addEventListener('mousedown', () => moveRight());

// Swipe
canvas.addEventListener('touchstart', e => {
    touchStartX = e.touches[0].clientX;
});
canvas.addEventListener('touchend', e => {
    const dx = e.changedTouches[0].clientX - touchStartX;
    if (dx < -40) moveLeft();
    if (dx > 40) moveRight();
});

function moveLeft() {
    if (carLane > 0) carLane--;
}
function moveRight() {
    if (carLane < lanes - 1) carLane++;
}

// Obstacles
function spawnObstacle() {
    const lane = Math.floor(Math.random() * lanes);
    const types = ['car', 'truck', 'cone'];
    const type = types[Math.floor(Math.random() * types.length)];
    obstacles.push({
        lane: lane,
        y: -100,
        type: type,
        width: type === 'truck' ? 55 : type === 'cone' ? 30 : 45,
        height: type === 'truck' ? 110 : type === 'cone' ? 40 : 85
    });
}

function update(dt) {
    if (!gameRunning) return;

    // Speed increase
    speed += 0.002;
    roadOffset += speed * 2;
    if (roadOffset > 40) roadOffset = 0;

    // Move car smoothly
    const targetX = getLaneX(carLane);
    carX += (targetX - carX) * 0.2;

    // Spawn obstacles
    lastObstacleTime += dt;
    if (lastObstacleTime > Math.max(800 - speed * 30, 400)) {
        spawnObstacle();
        lastObstacleTime = 0;
    }

    // Update obstacles
    for (let i = obstacles.length - 1; i >= 0; i--) {
        obstacles[i].y += speed * 1.5;
        if (obstacles[i].y > canvas.height + 50) {
            obstacles.splice(i, 1);
            score += 10;
            scoreEl.textContent = 'Score: ' + score;
        }
    }

    // Collision
    const carY = canvas.height - carHeight - 40;
    for (let obs of obstacles) {
        const obsX = getLaneX(obs.lane) + (carWidth - obs.width) / 2;
        if (obs.y + obs.height > carY && obs.y < carY + carHeight &&
            Math.abs(obsX - carX) < (carWidth + obs.width) / 2 - 10) {
            endGame();
            return;
        }
    }

    speedEl.textContent = 'Speed: ' + Math.floor(speed * 10);
}

function drawRoad() {
    const roadWidth = canvas.width * 0.7;
    const roadLeft = (canvas.width - roadWidth) / 2;

    // Grass
    ctx.fillStyle = grassColor;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Road
    ctx.fillStyle = roadColor;
    ctx.fillRect(roadLeft, 0, roadWidth, canvas.height);

    // Lane lines
    ctx.strokeStyle = lineColor;
    ctx.lineWidth = 4;
    ctx.setLineDash([30, 20]);
    ctx.lineDashOffset = -roadOffset;

    for (let i = 1; i < lanes; i++) {
        const x = roadLeft + (roadWidth / lanes) * i;
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
    }
    ctx.setLineDash([]);

    // Road edges
    ctx.strokeStyle = '#ffcc00';
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.moveTo(roadLeft, 0);
    ctx.lineTo(roadLeft, canvas.height);
    ctx.moveTo(roadLeft + roadWidth, 0);
    ctx.lineTo(roadLeft + roadWidth, canvas.height);
    ctx.stroke();
}

function drawCar(x, y, color = '#e74c3c', isPlayer = true) {
    // Body
    ctx.fillStyle = color;
    ctx.fillRect(x, y + 15, carWidth, carHeight - 25);
    
    // Roof
    ctx.fillStyle = isPlayer ? '#c0392b' : '#922b21';
    ctx.fillRect(x + 8, y + 25, carWidth - 16, 35);
    
    // Windows
    ctx.fillStyle = '#3498db';
    ctx.fillRect(x + 12, y + 28, carWidth - 24, 15);
    ctx.fillRect(x + 12, y + 48, carWidth - 24, 10);
    
    // Wheels
    ctx.fillStyle = '#222';
    ctx.fillRect(x - 5, y + 20, 10, 20);
    ctx.fillRect(x + carWidth - 5, y + 20, 10, 20);
    ctx.fillRect(x - 5, y + carHeight - 40, 10, 20);
    ctx.fillRect(x + carWidth - 5, y + carHeight - 40, 10, 20);
    
    // Lights
    if (isPlayer) {
        ctx.fillStyle = '#f1c40f';
        ctx.fillRect(x + 5, y + carHeight - 15, 12, 8);
        ctx.fillRect(x + carWidth - 17, y + carHeight - 15, 12, 8);
    } else {
        ctx.fillStyle = '#e74c3c';
        ctx.fillRect(x + 5, y + 10, 12, 8);
        ctx.fillRect(x + carWidth - 17, y + 10, 12, 8);
    }
}

function drawObstacle(obs) {
    const x = getLaneX(obs.lane) + (carWidth - obs.width) / 2;
    const y = obs.y;

    if (obs.type === 'cone') {
        // Traffic cone
        ctx.fillStyle = '#e67e22';
        ctx.beginPath();
        ctx.moveTo(x + obs.width / 2, y);
        ctx.lineTo(x, y + obs.height);
        ctx.lineTo(x + obs.width, y + obs.height);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = '#fff';
        ctx.fillRect(x + 5, y + 15, obs.width - 10, 8);
        ctx.fillRect(x + 8, y + 30, obs.width - 16, 8);
    } else if (obs.type === 'truck') {
        // Truck
        ctx.fillStyle = '#2980b9';
        ctx.fillRect(x, y + 20, obs.width, obs.height - 30);
        ctx.fillStyle = '#1a5276';
        ctx.fillRect(x + 5, y + 30, obs.width - 10, 40);
        // Cabin
        ctx.fillStyle = '#3498db';
        ctx.fillRect(x + 5, y + 5, obs.width - 10, 25);
        // Wheels
        ctx.fillStyle = '#222';
        ctx.fillRect(x - 3, y + 40, 8, 18);
        ctx.fillRect(x + obs.width - 5, y + 40, 8, 18);
        ctx.fillRect(x - 3, y + obs.height - 35, 8, 18);
        ctx.fillRect(x + obs.width - 5, y + obs.height - 35, 8, 18);
    } else {
        // Enemy car
        drawCar(x, y, '#9b59b6', false);
    }
}

function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawRoad();

    // Draw obstacles
    for (let obs of obstacles) {
        drawObstacle(obs);
    }

    // Draw player car
    const carY = canvas.height - carHeight - 40;
    drawCar(carX, carY, '#e74c3c', true);
}

let lastTime = 0;
function gameLoop(timestamp) {
    if (!gameRunning) return;
    const dt = timestamp - lastTime;
    lastTime = timestamp;

    update(dt);
    draw();
    requestAnimationFrame(gameLoop);
}

startBtn.addEventListener('click', startGame);
restartBtn.addEventListener('click', startGame);

// Initial draw
drawRoad();
drawCar(getLaneX(1), canvas.height - carHeight - 40);
