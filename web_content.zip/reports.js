/* =========================================================
   MUEEN | REPORTS
   بوابة التقارير
========================================================= */

document.addEventListener("DOMContentLoaded", () => {

    "use strict";


    /* =====================================================
       HELPERS
    ===================================================== */

    function $(id) {

        return document.getElementById(id);

    }


    function goTo(page) {

        if (!page) return;

        window.location.href = page;

    }


    /* =====================================================
       REPORT NAVIGATION
    ===================================================== */

    const absenceButton =
        $("openAbsenceReport");


    const gradesButton =
        $("openGradesReport");


    if (absenceButton) {

        absenceButton.addEventListener(
            "click",
            () => {

                goTo(
                    "absence-report.html"
                );

            }
        );

    }


    if (gradesButton) {

        gradesButton.addEventListener(
            "click",
            () => {

                goTo(
                    "grades-report.html"
                );

            }
        );

    }


    /* =====================================================
       BOTTOM NAVIGATION
       نفس شريط تقرير الغياب
    ===================================================== */

    const navigationPages = {

        homeNavigation:
            "home.html",

        attendanceNavigation:
            "attendance.html",

        studentsNavigation:
            "students.html",

        scheduleNavigation:
            "schedule.html",

        gradesNavigation:
            "grades.html",

        reportsNavigation:
            "reports.html"

    };


    Object.keys(
        navigationPages
    ).forEach(id => {

        const button = $(id);

        if (!button) return;


        button.addEventListener(
            "click",
            () => {

                const page =
                    navigationPages[id];


                if (!page) return;


                /*
                 * إذا كان الزر هو الصفحة الحالية
                 * لا نعيد تحميل الصفحة.
                 */

                if (
                    id === "reportsNavigation"
                    &&
                    (
                        location.pathname.endsWith(
                            "reports.html"
                        )
                        ||
                        location.pathname === "/"
                        ||
                        location.pathname === ""
                    )
                ) {

                    return;

                }


                goTo(page);

            }
        );

    });


    /* =====================================================
       ACTIVE NAVIGATION
    ===================================================== */

    const navigationItems =
        document.querySelectorAll(
            ".navigation-item"
        );


    navigationItems.forEach(item => {

        item.classList.remove(
            "active"
        );

        item.removeAttribute(
            "aria-current"
        );

    });


    const currentNavigation =
        $("reportsNavigation");


    if (currentNavigation) {

        currentNavigation.classList.add(
            "active"
        );

        currentNavigation.setAttribute(
            "aria-current",
            "page"
        );

    }


    /* =====================================================
       KEYBOARD ACCESS
    ===================================================== */

    [
        absenceButton,
        gradesButton
    ].forEach(button => {

        if (!button) return;


        button.addEventListener(
            "keydown",
            event => {

                if (
                    event.key === "Enter"
                    ||
                    event.key === " "
                ) {

                    event.preventDefault();

                    button.click();

                }

            }
        );

    });


    /* =====================================================
       INITIALIZATION
    ===================================================== */

    console.log(
        "MUEEN | Reports gateway initialized."
    );

});