// 11. التقارير اليومية والشهرية
// ========================================
function reportCategory(h) {
  if (h.category) return h.category;

  const t = h.type || "";
  const device = String(h.device || "");

  if (t === "كمبيوتر" || device.includes("كمبيوتر")) return "كمبيوتر";

  if (["PS5", "PS4", "PS3", "بلايستيشن"].includes(t) ||
      device.includes("بلايستيشن")) return "بلايستيشن";

  if (t === "فيشة" || device.includes("فيشة")) return "فيشة";
  if (t === "بلياردو" || device.includes("بلياردو")) return "بلياردو";

  return "أخرى";
}

function reportHistoryDate(h) {
  if (h.date && /^\d{4}-\d{2}-\d{2}$/.test(h.date)) {
    return h.date;
  }

  const raw = Number(h.end) || Date.parse(h.end || "");
  return Number.isFinite(raw) && raw > 0
    ? localDate(new Date(raw))
    : "";
}

function reportMatches(h) {
  const date = reportHistoryDate(h);
  return reportMode === "daily"
    ? date === reportDate
    : date.startsWith(reportMonth);
}

function changeReportDate(value) {
  if (/^\d{4}-\d{2}-\d{2}$/.test(value)) reportDate = value;
  render();
}

function changeReportMonth(value) {
  if (/^\d{4}-\d{2}$/.test(value)) reportMonth = value;
  render();
}

function setReportMode(mode) {
  reportMode = mode;
  render();
}

function shiftReport(step) {
  if (reportMode === "daily") {
    const d = new Date(reportDate + "T12:00:00");
    d.setDate(d.getDate() + step);
    reportDate = localDate(d);
  } else {
    const d = new Date(reportMonth + "-01T12:00:00");
    d.setMonth(d.getMonth() + step);
    reportMonth = localMonth(d);
  }

  render();
}

function reportToday() {
  if (reportMode === "daily") {
    reportDate = localDate();
  } else {
    reportMonth = localMonth();
  }

  render();
}


function renderReports(c) {
  const histories = db.history.filter(reportMatches);
  const expenses = db.expenses.filter(expenseMatches);

  const categories = [
    ["كمبيوتر", "🖥️"],
    ["بلايستيشن", "🎮"],
    ["فيشة", "⚽"],
    ["بلياردو", "🎱"]
  ];

  const gameTotal = histories.reduce(
    (a, h) => a + (Number(h.game) || 0), 0
  );

  const ordersTotal = histories.reduce(
    (a, h) => a + (Number(h.orders) || 0), 0
  );

  const gross = histories.reduce(
    (a, h) => a + (
      Number(h.total) ||
      ((Number(h.game) || 0) + (Number(h.orders) || 0))
    ), 0
  );

  const expenseTotal = expenses.reduce(
    (a, e) => a + (Number(e.amount) || 0), 0
  );

  const net = gross - expenseTotal;

  const period = reportMode === "daily"
    ? reportDate
    : reportMonth;

  const categoryCards = categories.map(([key, icon]) => {
    const arr = histories.filter(
      h => reportCategory(h) === key
    );

    const amount = arr.reduce(
      (a, h) => a + (
        Number(h.total) ||
        ((Number(h.game) || 0) + (Number(h.orders) || 0))
      ), 0
    );

    return `
      <div class="report-stat card">
        <div class="report-stat-title">
          <span>${icon} ${key}</span>
          <span class="report-count">${arr.length}</span>
        </div>
        <small class="muted">عدد الجلسات</small>
        <strong>${arr.length}</strong>
        <div class="report-card-divider"></div>
        <small class="muted">إجمالي المبالغ</small>
        <strong class="report-amount">${cash(amount)}</strong>
      </div>
    `;
  }).join("");

  c.innerHTML = `
    <section class="reports-page">

      <div class="reports-heading">
        <div>
          <h2>📊 التقارير المالية</h2>
          <p class="muted">
            نظرة شاملة على الإيرادات والمصروفات وصافي الأرباح.
          </p>
        </div>
        <span class="report-period">
          ${reportMode === "daily" ? "تقرير يومي" : "تقرير شهري"}
        </span>
      </div>

      <div class="report-controls card">
        <div class="report-tabs">
          <button
            class="${reportMode === "daily" ? "primary" : ""}"
            onclick="setReportMode('daily')">
            📅 التقرير اليومي
          </button>

          <button
            class="${reportMode === "monthly" ? "primary" : ""}"
            onclick="setReportMode('monthly')">
            🗓️ التقرير الشهري
          </button>
        </div>

        <div class="report-date-navigation">
          <button onclick="shiftReport(-1)">→ السابق</button>
          <button onclick="reportToday()">اليوم / الشهر الحالي</button>
          <button onclick="shiftReport(1)">التالي ←</button>
        </div>

        <div class="field">
          <label for="${reportMode === "daily" ? "reportDate" : "reportMonth"}">
            ${reportMode === "daily" ? "تاريخ التقرير" : "شهر التقرير"}
          </label>

          ${
            reportMode === "daily"
              ? `<input id="reportDate" type="date"
                   value="${esc(reportDate)}"
                   onchange="changeReportDate(this.value)">`
              : `<input id="reportMonth" type="month"
                   value="${esc(reportMonth)}"
                   onchange="changeReportMonth(this.value)">`
          }
        </div>
      </div>

      <div class="reports-section-heading">
        <div>
          <h3>ملخص الأقسام</h3>
          <p class="muted">أداء كل نوع من الأجهزة والطاولات.</p>
        </div>
      </div>

      <div class="report-grid">
        ${categoryCards}

        <div class="report-stat card">
          <div class="report-stat-title">
            <span>🛒 الطلبات</span>
          </div>
          <small class="muted">إجمالي مبالغ الطلبات</small>
          <strong class="report-amount">${cash(ordersTotal)}</strong>
          <div class="report-card-divider"></div>
          <small class="muted">هذه المبالغ محسوبة ضمن الإيرادات.</small>
        </div>

        <div class="report-stat card">
          <div class="report-stat-title">
            <span>💸 المصروفات</span>
            <span class="report-count">${expenses.length}</span>
          </div>
          <small class="muted">عدد المصروفات</small>
          <strong>${expenses.length}</strong>
          <div class="report-card-divider"></div>
          <small class="muted">إجمالي المصروفات</small>
          <strong class="report-amount">${cash(expenseTotal)}</strong>
        </div>
      </div>

      <div class="reports-section-heading">
        <div>
          <h3>💰 الملخص المالي</h3>
          <p class="muted">نتيجة الفترة المحددة: ${esc(period)}</p>
        </div>
      </div>

      <div class="report-grid report-totals">
        <div class="card report-total-card">
          <span class="report-total-icon">🎮</span>
          <small class="muted">أجرة اللعب</small>
          <strong>${cash(gameTotal)}</strong>
        </div>

        <div class="card report-total-card">
          <span class="report-total-icon">📈</span>
          <small class="muted">إجمالي الإيرادات</small>
          <strong>${cash(gross)}</strong>
        </div>

        <div class="card report-total-card expense-card">
          <span class="report-total-icon">💸</span>
          <small class="muted">إجمالي المصروفات</small>
          <strong>${cash(expenseTotal)}</strong>
        </div>

        <div class="card report-total-card net-card">
          <span class="report-total-icon">✨</span>
          <small class="muted">الصافي بعد المصروفات</small>
          <strong>${cash(net)}</strong>
        </div>
      </div>

      <div class="reports-section-heading">
        <div>
          <h3>🎮 تفاصيل الجلسات</h3>
          <p class="muted">عدد الجلسات المغلقة: ${histories.length}</p>
        </div>
      </div>

      <div class="card table report-table-card">
        ${
          histories.length
            ? `<div class="report-table-scroll">
                <table>
                  <thead>
                    <tr>
                      <th>التاريخ</th>
                      <th>القسم</th>
                      <th>الجهاز</th>
                      <th>الزبون</th>
                      <th>أجرة اللعب</th>
                      <th>الطلبات</th>
                      <th>الإجمالي</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${histories.slice().sort(
                      (a, b) => (Number(b.end) || 0) - (Number(a.end) || 0)
                    ).map(h => `
                      <tr>
                        <td>${esc(reportHistoryDate(h) || "—")}</td>
                        <td>${esc(reportCategory(h))}</td>
                        <td>${esc(h.device || "—")}</td>
                        <td>${esc(h.customer || "—")}</td>
                        <td>${cash(h.game)}</td>
                        <td>${cash(h.orders)}</td>
                        <td><strong>${cash(
                          h.total ?? (
                            (Number(h.game) || 0) +
                            (Number(h.orders) || 0)
                          )
                        )}</strong></td>
                      </tr>
                    `).join("")}
                  </tbody>
                </table>
              </div>`
            : `<p class="muted report-empty">
                لا توجد جلسات مغلقة في هذه الفترة.
              </p>`
        }
      </div>

      <div class="reports-section-heading">
        <div>
          <h3>🧾 تفاصيل المصروفات</h3>
          <p class="muted">
            ${expenses.length} مصروف مسجل في الفترة المحددة.
          </p>
        </div>
      </div>

      <div class="card table report-table-card">
        ${
          expenses.length
            ? `<div class="report-table-scroll">
                <table>
                  <thead>
                    <tr>
                      <th>التاريخ</th>
                      <th>بيان المصروف</th>
                      <th>المبلغ</th>
                      <th>الإجراء</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${expenses.slice().sort(
                      (a, b) => String(b.date).localeCompare(String(a.date))
                    ).map(e => `
                      <tr>
                        <td>${esc(e.date)}</td>
                        <td>${esc(e.note)}</td>
                        <td><strong>${cash(e.amount)}</strong></td>
                        <td>
                          <div class="report-row-actions">
                            <button onclick="expenseForm(${e.id})">تعديل</button>
                            <button class="bad"
                              onclick="deleteExpense(${e.id})">حذف</button>
                          </div>
                        </td>
                      </tr>
                    `).join("")}
                  </tbody>
                </table>
              </div>`
            : `<p class="muted report-empty">
                لا توجد مصروفات في هذه الفترة.
              </p>`
        }
      </div>

    </section>
  `;
}


// ========================================
