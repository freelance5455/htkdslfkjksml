/* Report models (same layout as the desktop app). Depends on nothing. */
(function (root) {
  "use strict";
  const Rep = {};
  const BC = root.Barcodes || (typeof require !== "undefined" ? require("./barcodes.js") : null);
  Rep.LIST = [
    ["stock_in", "Stock In Report", "Goods received, with value at purchase price", true],
    ["stock_out", "Stock Out Report", "Goods sold or issued, with cost value", true],
    ["sales", "Sales Report (detail)", "Every sale with discounts, commission and profit", true],
    ["daily", "Daily Sales Report", "Sales totals for each day", true],
    ["weekly", "Weekly Sales Report", "Sales totals for each week (Mon-Sun)", true],
    ["monthly", "Monthly Sales Report", "Sales totals for each month", true],
    ["discounts", "Discounts Report", "Cash and bulk discounts given, by item", true],
    ["commission", "Commission Report", "Agent commission summary and detail", true],
    ["by_item", "Profit by Item Report", "Sales, cost and profit for each item", true],
    ["invoice_register", "Invoice Register", "All invoices and receipts with totals", true],
    ["barcode_labels", "Barcode Labels (print sheet)", "Printable labels with scannable barcodes", false],
    ["barcode_list", "Barcode List", "Every item with its barcode number and image", false],
    ["stock_on_hand", "Stock Valuation Report", "Current stock on hand and its value", false],
    ["reorder", "Low Stock / Reorder Report", "Items at or below their reorder level", false],
  ];
  const rnd2 = (x) => Number(Math.round(Number(Math.abs(x).toFixed(8) + "e2")) + "e-2"); // decimal-safe half-up
  const money = (v) => { const a = rnd2(v); return (v < 0 && a !== 0 ? "-$" : "$") + a.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
  const qf = (v) => String(Math.round(v * 1e6) / 1e6);
  const pct = (v) => (v * 100).toFixed(1) + "%";
  const col = (h, w, a) => ({ h, w, a: a || "l" });
  const cmp = (a, b) => (a < b ? -1 : a > b ? 1 : 0);
  const isoToday = () => new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);

  function weekStart(d) {
    const t = new Date(d.slice(0, 10) + "T00:00:00Z"), wd = (t.getUTCDay() + 6) % 7;
    t.setUTCDate(t.getUTCDate() - wd); return t;
  }
  const iso = (t) => t.toISOString().slice(0, 10);

  Rep.build = (state, key, from, to, opts) => {
    from = from || ""; to = to || ""; opts = opts || {};
    const items = state.items, log = state.log, byBc = {};
    for (const i of items) byBc[i.barcode] = i;
    const def = Rep.LIST.find((r) => r[0] === key), needsRange = def[3];
    const period = needsRange ? (!from && !to ? "All dates" : (from || "start") + " to " + (to || "today")) : "As of " + isoToday();
    const inr = (e) => { const d = e.date.slice(0, 10); return (!from || d >= from) && (!to || d <= to); };
    const srt = (rows) => rows.slice().sort((a, b) => cmp(a.date.slice(0, 10), b.date.slice(0, 10)) || a.id - b.id);
    const nm = (e) => { const it = byBc[e.barcode]; return [it ? it.sku : "", it ? it.name : e.barcode]; };
    const ins = srt(log.filter((e) => e.type === "IN" && inr(e))), outs = srt(log.filter((e) => e.type === "OUT" && inr(e)));
    const m = { title: def[1], period, landscape: false, cards: [], tables: [] };
    const sums = (rows) => {
      const s = { n: rows.length, qty: 0, gross: 0, cash: 0, bulk: 0, net: 0, comm: 0, cogs: 0, profit: 0 };
      for (const e of rows) { s.qty += e.qty; s.gross += e.gross; s.cash += e.cash_disc; s.bulk += e.bulk_disc; s.net += e.net; s.comm += e.commission; s.cogs += e.cogs; s.profit += e.profit; }
      return s;
    };
    const salesCards = (s) => [["Gross sales", money(s.gross)], ["Discounts", money(s.cash + s.bulk)], ["Net sales", money(s.net)], ["Commission", money(s.comm)], ["Profit", money(s.profit)]];
    const margin = (s) => pct(s.net ? s.profit / s.net : 0);
    const group = (rows, fn) => { const g = {}; for (const e of rows) (g[fn(e)] = g[fn(e)] || []).push(e); return g; };

    if (key === "stock_in") {
      let tq = 0, tv = 0; const rows = [];
      for (const e of ins) {
        const it = byBc[e.barcode], [sku, name] = nm(e), cost = it ? it.purchase_price : 0;
        rows.push([e.date.slice(0, 10), sku, name, qf(e.qty), money(cost), money(e.qty * cost), e.note]); tq += e.qty; tv += e.qty * cost;
      }
      m.cards = [["Entries", String(ins.length)], ["Units received", qf(tq)], ["Value at cost", money(tv)]];
      m.tables = [{ heading: "", cols: [col("Date", 12), col("SKU", 10), col("Item", 30), col("Qty", 8, "r"), col("Unit cost", 11, "r"), col("Value", 12, "r"), col("Note", 24)], rows, total: ["TOTAL", "", "", qf(tq), "", money(tv), ""] }];
    } else if (key === "stock_out") {
      let tq = 0, tc = 0; const rows = [];
      for (const e of outs) { const [sku, name] = nm(e); rows.push([e.date.slice(0, 10), sku, name, qf(e.qty), e.payment, e.agent, money(e.cogs), e.note]); tq += e.qty; tc += e.cogs; }
      m.cards = [["Entries", String(outs.length)], ["Units out", qf(tq)], ["Cost of goods", money(tc)]];
      m.tables = [{ heading: "", cols: [col("Date", 11), col("SKU", 9), col("Item", 26), col("Qty", 7, "r"), col("Payment", 9), col("Agent", 12), col("Cost value", 12, "r"), col("Note", 18)], rows, total: ["TOTAL", "", "", qf(tq), "", "", money(tc), ""] }];
    } else if (key === "sales") {
      m.landscape = true; const s = sums(outs), rows = outs.map((e) => { const [, name] = nm(e); return [e.date.slice(0, 10), name, qf(e.qty), e.payment, e.agent, money(e.gross), money(e.cash_disc), money(e.bulk_disc), money(e.net), money(e.commission), money(e.profit)]; });
      m.cards = salesCards(s);
      m.tables = [{ heading: "", cols: [col("Date", 10), col("Item", 24), col("Qty", 6, "r"), col("Payment", 8), col("Agent", 11), col("Gross", 10, "r"), col("Cash disc", 9, "r"), col("Bulk disc", 9, "r"), col("Net", 10, "r"), col("Commission", 10, "r"), col("Profit", 10, "r")], rows,
        total: ["TOTAL", "", qf(s.qty), "", "", money(s.gross), money(s.cash), money(s.bulk), money(s.net), money(s.comm), money(s.profit)] }];
    } else if (key === "daily" || key === "weekly" || key === "monthly") {
      const g = group(outs, (e) => { const d = e.date.slice(0, 10); if (key === "daily") return d; if (key === "monthly") return d.slice(0, 7); const w = weekStart(d), w2 = new Date(w); w2.setUTCDate(w2.getUTCDate() + 6); return iso(w) + " to " + iso(w2); });
      const rows = Object.keys(g).sort().map((k) => { const s = sums(g[k]); return [k, String(s.n), qf(s.qty), money(s.gross), money(s.cash + s.bulk), money(s.net), money(s.comm), money(s.profit), margin(s)]; });
      const s = sums(outs);
      m.landscape = true; m.cards = salesCards(s);
      m.tables = [{ heading: "", cols: [col({ daily: "Date", weekly: "Week", monthly: "Month" }[key], 22), col("Sales", 7, "r"), col("Units", 8, "r"), col("Gross", 12, "r"), col("Discounts", 11, "r"), col("Net", 12, "r"), col("Commission", 11, "r"), col("Profit", 12, "r"), col("Margin", 8, "r")], rows,
        total: ["TOTAL", String(s.n), qf(s.qty), money(s.gross), money(s.cash + s.bulk), money(s.net), money(s.comm), money(s.profit), margin(s)] }];
    } else if (key === "discounts" || key === "by_item") {
      const g = group(outs, (e) => e.barcode), s = sums(outs);
      const bcs = Object.keys(g).sort((a, b) => cmp(byBc[a] ? byBc[a].sku : a, byBc[b] ? byBc[b].sku : b));
      const rows = bcs.map((bc) => {
        const gs = sums(g[bc]), it = byBc[bc] || { sku: "", name: bc };
        if (key === "discounts") { const d = gs.cash + gs.bulk; return [it.name, qf(gs.qty), money(gs.gross), money(gs.cash), money(gs.bulk), money(d), pct(gs.gross ? d / gs.gross : 0)]; }
        return [it.name, it.sku, qf(gs.qty), money(gs.gross), money(gs.cash + gs.bulk), money(gs.net), money(gs.comm), money(gs.cogs), money(gs.profit), margin(gs)];
      });
      if (key === "discounts") {
        const d = s.cash + s.bulk;
        m.cards = [["Cash discounts", money(s.cash)], ["Bulk discounts", money(s.bulk)], ["Total discounts", money(d)], ["% of gross sales", pct(s.gross ? d / s.gross : 0)]];
        m.tables = [{ heading: "Discounts by item", cols: [col("Item", 28), col("Units", 8, "r"), col("Gross sales", 13, "r"), col("Cash disc", 12, "r"), col("Bulk disc", 12, "r"), col("Total disc", 12, "r"), col("% of gross", 10, "r")], rows,
          total: ["TOTAL", qf(s.qty), money(s.gross), money(s.cash), money(s.bulk), money(d), pct(s.gross ? d / s.gross : 0)] }];
      } else {
        m.landscape = true; m.cards = salesCards(s);
        m.tables = [{ heading: "", cols: [col("Item", 24), col("SKU", 9), col("Units", 7, "r"), col("Gross", 11, "r"), col("Discounts", 10, "r"), col("Net", 11, "r"), col("Commission", 10, "r"), col("Cost", 11, "r"), col("Profit", 11, "r"), col("Margin", 8, "r")], rows,
          total: ["TOTAL", "", qf(s.qty), money(s.gross), money(s.cash + s.bulk), money(s.net), money(s.comm), money(s.cogs), money(s.profit), margin(s)] }];
      }
    } else if (key === "commission") {
      const g = group(outs, (e) => (e.agent || "").trim() || "(no agent)"), s = sums(outs), ag = Object.keys(g).sort();
      const rows = ag.map((a) => { const gs = sums(g[a]); return [a, String(gs.n), qf(gs.qty), money(gs.net), money(gs.comm), pct(gs.net ? gs.comm / gs.net : 0)]; });
      const det = []; for (const a of ag) for (const e of g[a]) { const [, name] = nm(e); det.push([a, e.date.slice(0, 10), name, qf(e.qty), money(e.net), money(e.commission)]); }
      m.cards = [["Agents", String(ag.length)], ["Sales", String(s.n)], ["Net sales", money(s.net)], ["Commission payable", money(s.comm)]];
      m.tables = [
        { heading: "Summary by agent", cols: [col("Agent", 26), col("Sales", 9, "r"), col("Units", 9, "r"), col("Net sales", 16, "r"), col("Commission", 16, "r"), col("Effective %", 12, "r")], rows, total: ["TOTAL", String(s.n), qf(s.qty), money(s.net), money(s.comm), pct(s.net ? s.comm / s.net : 0)] },
        { heading: "Detail by sale", cols: [col("Agent", 16), col("Date", 13), col("Item", 30), col("Qty", 8, "r"), col("Net sales", 16, "r"), col("Commission", 16, "r")], rows: det, total: ["TOTAL", "", "", qf(s.qty), money(s.net), money(s.comm)] }];
    } else if (key === "invoice_register") {
      const invs = (state.invoices || []).filter((i) => inr(i)).sort((a, b) => cmp(a.date, b.date) || a.id - b.id);
      const live = invs.filter((i) => i.status !== "void"), sm = (f) => live.reduce((s, i) => s + i[f], 0);
      m.landscape = true;
      m.cards = [["Invoices", String(live.length)], ["Sales total", money(sm("total"))], ["Discounts", money(sm("discounts"))], ["Tax", money(sm("tax"))], ["Voided", String(invs.length - live.length)]];
      m.tables = [{ heading: "", cols: [col("Invoice #", 11), col("Date", 11), col("Customer", 22), col("Payment", 8), col("Agent", 11), col("Items", 6, "r"), col("Subtotal", 11, "r"), col("Discounts", 10, "r"), col("Tax", 8, "r"), col("Total", 11, "r"), col("Status", 8)],
        rows: invs.map((i) => [i.number, i.date, i.customer || "Walk-in", i.payment, i.agent, String(i.lines.length), money(i.subtotal), money(i.discounts), money(i.tax), money(i.total), i.status === "void" ? "VOID" : i.payment === "Cash" ? "Paid" : "Due"]),
        total: ["TOTAL", "", "", "", "", String(live.reduce((s, i) => s + i.lines.length, 0)), money(sm("subtotal")), money(sm("discounts")), money(sm("tax")), money(sm("total")), ""] }];
    } else if (key === "barcode_labels" || key === "barcode_list") {
      const cat = (opts.category || "").trim();
      const sel = items.filter((i) => !cat || i.category === cat).sort((a, b) => cmp(a.sku, b.sku));
      m.period = (cat ? "Category: " + cat : "All items") + "  |  " + sel.length + " items";
      if (key === "barcode_labels") {
        m.kind = "labels"; m.copies = Math.max(1, Math.floor(Number(opts.copies) || 1)); m.showPrice = opts.showPrice !== false;
        m.items = sel.map((i) => ({ sku: i.sku, name: i.name, barcode: i.barcode, price: money(i.selling_price) }));
      } else {
        const kinds = sel.map((i) => BC.encode(i.barcode).kind);
        m.cards = [["Items", String(sel.length)], ["EAN-13 / UPC-A", String(kinds.filter((k) => k !== "Code 128").length)], ["Code 128", String(kinds.filter((k) => k === "Code 128").length)]];
        m.tables = [{ heading: "", rowH: 34, cols: [col("#", 5, "r"), col("SKU", 11), col("Item", 26), col("Category", 14), col("Barcode number", 19), col("Type", 11), { h: "Barcode", w: 30, a: "l", img: true }],
          rows: sel.map((i, n) => [String(n + 1), i.sku, i.name, i.category, i.barcode, kinds[n], i.barcode]), total: null }];
      }
    } else if (key === "stock_on_hand" || key === "reorder") {
      const tin = {}, tout = {}; for (const e of log) { const t = e.type === "IN" ? tin : tout; t[e.barcode] = (t[e.barcode] || 0) + e.qty; }
      let tv = 0, tu = 0, nre = 0, nout = 0; const rows = [];
      for (const it of items.slice().sort((a, b) => cmp(a.sku, b.sku))) {
        const oh = (tin[it.barcode] || 0) - (tout[it.barcode] || 0), status = oh <= 0 ? "Out of Stock" : oh <= it.reorder_level ? "Reorder" : "OK";
        if (status === "Reorder") nre++; if (status === "Out of Stock") nout++;
        if (key === "stock_on_hand") { rows.push([it.sku, it.name, it.category, it.location, qf(oh), money(it.purchase_price), money(oh * it.purchase_price), status]); tv += oh * it.purchase_price; tu += oh; }
        else if (status !== "OK") { const est = it.reorder_qty * it.purchase_price; rows.push([it.sku, it.name, it.supplier, qf(oh), qf(it.reorder_level), qf(it.reorder_qty), money(est), status]); tv += est; }
      }
      if (key === "stock_on_hand") {
        m.cards = [["SKUs", String(items.length)], ["Units on hand", qf(tu)], ["Stock value (cost)", money(tv)], ["Reorder / out", nre + " / " + nout]];
        m.tables = [{ heading: "", cols: [col("SKU", 10), col("Item", 28), col("Category", 16), col("Location", 12), col("On hand", 9, "r"), col("Unit cost", 11, "r"), col("Stock value", 13, "r"), col("Status", 12)], rows, total: ["TOTAL", "", "", "", qf(tu), "", money(tv), ""] }];
      } else {
        m.cards = [["Items to reorder", String(nre)], ["Out of stock", String(nout)], ["Estimated order cost", money(tv)]];
        m.tables = [{ heading: "", cols: [col("SKU", 10), col("Item", 28), col("Supplier", 18), col("On hand", 9, "r"), col("Reorder level", 11, "r"), col("Order qty", 10, "r"), col("Est. cost", 12, "r"), col("Status", 12)], rows, total: ["TOTAL", "", "", "", "", "", money(tv), ""] }];
      }
    }
    return m;
  };

  // ---------- date range presets ----------
  Rep.preset = (name) => {
    const now = new Date(Date.now() - new Date().getTimezoneOffset() * 60000), t = isoToday();
    if (name === "today") return [t, t];
    if (name === "week") { const w = weekStart(t); const e = new Date(w); e.setUTCDate(e.getUTCDate() + 6); return [iso(w), iso(e)]; }
    if (name === "month") return [t.slice(0, 8) + "01", t];
    if (name === "year") return [t.slice(0, 4) + "-01-01", t];
    return ["", ""];
  };

  Rep.money = money;
  root.Rep = Rep;
  if (typeof module !== "undefined" && module.exports) module.exports = Rep;
})(typeof window !== "undefined" ? window : globalThis);
