Phone OS Simulator - HTML + Real Apps

ਇਸ ਪ੍ਰੋਜੈਕਟ ਵਿੱਚ HTML ਦੀ ਸਕ੍ਰੀਨ Android WebView ਵਿੱਚ ਚੱਲਦੀ ਹੈ। Java bridge ਫ਼ੋਨ ਦੀਆਂ launcher apps ਦੀ ਸੂਚੀ ਅਤੇ icons HTML ਨੂੰ ਦਿੰਦਾ ਹੈ। ਆਈਕਨ ਦਬਾਉਣ 'ਤੇ package name ਰਾਹੀਂ ਅਸਲੀ ਐਪ ਖੁੱਲ੍ਹਦੀ ਹੈ।

ZIP ਨੂੰ Android Studio ਜਾਂ ਭਰੋਸੇਯੋਗ Android build service ਵਿੱਚ ਇੱਕ Android Gradle project ਵਜੋਂ ਖੋਲ੍ਹੋ/build ਕਰੋ। ਇਹ ZIP ਪਹਿਲਾਂ ਤੋਂ ਬਣੀ APK ਨਹੀਂ ਹੈ।

HTML ਫ਼ਾਈਲ: app/src/main/assets/index.html
Java ਫ਼ਾਈਲ: app/src/main/java/com/example/phoneossimulator/MainActivity.java

ਨੋਟ: Android 11+ ਵਿੱਚ app visibility ਨਿਯਮਾਂ ਕਰਕੇ ਕੁਝ ਡਿਵਾਈਸਾਂ 'ਤੇ launcher app list ਸੀਮਿਤ ਹੋ ਸਕਦੀ ਹੈ। ਇਸ project ਵਿੱਚ launcher intent queries ਦਿੱਤੀਆਂ ਗਈਆਂ ਹਨ।
