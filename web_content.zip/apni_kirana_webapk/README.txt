Apni Kirana Store - Offline Web App package

Upload this ZIP to an HTML/ZIP-to-APK builder. The entry file is index.html.
The app stores its demo data in browser localStorage on the device. Keep app data intact; clearing app storage or uninstalling may erase locally stored records. Test backup/export before relying on it for business-critical records.

Suggested app name: Apni Kirana Store
