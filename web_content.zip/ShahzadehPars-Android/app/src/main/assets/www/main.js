import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { createWorld } from './rosie/roseblox.js';

let renderer;
try {
  renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'low-power' });
} catch (error) {
  console.warn('WebGL در این مرورگر یا محیط اجرا در دسترس نیست:', error);
  document.getElementById('menuText').textContent = 'برای اجرای کاخ سه‌بعدی باید WebGL و شتاب‌دهی سخت‌افزاری مرورگر فعال باشد. این بازی را در مرورگر دیگری باز کنید یا شتاب‌دهی گرافیکی را فعال کنید.';
  const startButton = document.getElementById('startBtn');
  if (startButton instanceof HTMLButtonElement) {
    startButton.disabled = true;
    startButton.textContent = 'گرافیک سه‌بعدی در دسترس نیست';
  }
}

if (renderer) {
  renderer.setPixelRatio(Math.min(1.5, devicePixelRatio));
  renderer.toneMapping = THREE.NeutralToneMapping;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.BasicShadowMap;
  document.getElementById('game-container').appendChild(renderer.domElement);

const scene = new THREE.Scene();
scene.background = new THREE.Color('#d89a5a');
scene.fog = new THREE.Fog('#d89a5a', 40, 140);
const camera = new THREE.PerspectiveCamera(60, 1, 0.1, 400);

function resize() {
  const w = innerWidth;
  const h = innerHeight;
  renderer.setSize(w, h);
  camera.aspect = w / h;
  const v = 2 * Math.atan(Math.tan(THREE.MathUtils.degToRad(60) / 2) / camera.aspect);
  camera.fov = Math.min(90, THREE.MathUtils.radToDeg(v));
  camera.updateProjectionMatrix();
}
addEventListener('resize', resize);
resize();

scene.add(new THREE.HemisphereLight('#ffe2b0', '#4a2c18', 1.2));
const sun = new THREE.DirectionalLight('#ffc27a', 2.6);
sun.position.set(-30, 50, 20);
sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
Object.assign(sun.shadow.camera, { left: -40, right: 40, top: 60, bottom: -60, far: 150 });
sun.target.position.set(0, 0, -50);
scene.add(sun, sun.target);

const texLoader = new THREE.TextureLoader();
texLoader.loadAsync('assets/persepolis-sunset.webp').then(tex => {
  tex.mapping = THREE.EquirectangularReflectionMapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = renderer.capabilities.getMaxAnisotropy();
  scene.background = tex;
  scene.environment = tex;
}).catch(() => {});

const stoneTex = texLoader.load('assets/sandstone-tile.webp');
stoneTex.colorSpace = THREE.SRGBColorSpace;
stoneTex.wrapS = stoneTex.wrapT = THREE.RepeatWrapping;
const goldMat = new THREE.MeshStandardMaterial({ color: '#f2c14e', metalness: 0.9, roughness: 0.3, emissive: '#5a3a08' });
const darkMat = new THREE.MeshStandardMaterial({ color: '#3a2414', roughness: 0.9 });
const bladeMat = new THREE.MeshStandardMaterial({ color: '#b8b8c0', metalness: 1, roughness: 0.25 });

function stoneMat(w, d) {
  const t = stoneTex.clone();
  t.repeat.set(Math.max(1, w / 3), Math.max(1, d / 3));
  t.needsUpdate = true;
  return new THREE.MeshStandardMaterial({ map: t, color: '#e8c89a', roughness: 0.85 });
}

const world = await createWorld();

function block(x, y, z, w, h, d, solid = true) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), stoneMat(w, d));
  mesh.position.set(x, y - h / 2, z);
  mesh.castShadow = mesh.receiveShadow = true;
  scene.add(mesh);
  const trim = new THREE.Mesh(new THREE.BoxGeometry(w + 0.04, 0.12, d + 0.04), goldMat);
  trim.position.set(x, y - 0.1, z);
  scene.add(trim);
  if (solid) {
    world.addStaticMesh(mesh);
  }
  return mesh;
}

function column(x, z, base, height) {
  const g = new THREE.Group();
  const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.7, 0.85, height, 16), stoneMat(2, height));
  shaft.position.y = height / 2;
  const capital = new THREE.Mesh(new THREE.BoxGeometry(3, 1.2, 1.2), goldMat);
  capital.position.y = height + 0.6;
  const bullL = new THREE.Mesh(new THREE.SphereGeometry(0.7, 10, 8), darkMat);
  bullL.position.set(-1.4, height + 0.9, 0);
  const bullR = bullL.clone();
  bullR.position.x = 1.4;
  g.add(shaft, capital, bullL, bullR);
  g.position.set(x, base, z);
  g.traverse(o => { o.castShadow = true; });
  scene.add(g);
}

// Level layout: start courtyard, gaps, climb, traps, puzzle bridge, gate.
block(0, 0, 0, 14, 4, 16);
block(0, -6, -40, 120, 1, 200, false); // abyss floor visual
block(0, 0, -12, 4, 4, 4);
block(0, 0.5, -18, 4, 4.5, 4);
block(0, 1, -24.5, 5, 5, 5);
block(0, 3.2, -31, 8, 7, 6); // high ledge (climb)
const checkpoints = [new THREE.Vector3(0, 0.2, 4), new THREE.Vector3(0, 3.4, -31), new THREE.Vector3(0, 3.4, -58), new THREE.Vector3(0, 3.4, -88)];
block(0, 3.2, -46, 6, 4, 26); // blade corridor
block(0, 3.2, -62, 10, 4, 8); // checkpoint 2
block(0, 3.2, -75, 5, 4, 14); // spike floor walk
block(0, 3.2, -88, 14, 4, 10); // puzzle platform
block(0, 3.2, -112, 14, 4, 12); // gate platform
for (let i = 0; i < 9; i++) {
  column(-9, -i * 13, -6, 18);
  column(9, -i * 13, -6, 18);
}

// Gate
const gate = new THREE.Group();
const postGeo = new THREE.BoxGeometry(1.2, 8, 1.2);
const p1 = new THREE.Mesh(postGeo, goldMat);
p1.position.set(-3, 4, 0);
const p2 = p1.clone();
p2.position.x = 3;
const lintel = new THREE.Mesh(new THREE.BoxGeometry(8, 1.4, 1.6), goldMat);
lintel.position.y = 8.6;
const portal = new THREE.Mesh(new THREE.PlaneGeometry(4.8, 8), new THREE.MeshBasicMaterial({ color: '#ffe7a0', transparent: true, opacity: 0.55 }));
portal.position.y = 4;
gate.add(p1, p2, lintel, portal);
gate.position.set(0, 3.2, -115);
scene.add(gate);

// Faravahar decals
const faraTex = texLoader.load('assets/faravahar-decal.webp');
faraTex.colorSpace = THREE.SRGBColorSpace;
function decal(size) {
  return new THREE.Mesh(new THREE.PlaneGeometry(size, size), new THREE.MeshBasicMaterial({ map: faraTex, transparent: true, depthWrite: false }));
}
const gateSign = decal(3);
gateSign.position.set(0, 12, -115);
scene.add(gateSign);
const plate = decal(2.4);
plate.rotation.x = -Math.PI / 2;
plate.position.set(4.5, 3.24, -89);
scene.add(plate);
const plateHint = decal(1.6);
plateHint.position.set(4.5, 5.5, -89);
scene.add(plateHint);

// Puzzle bridge (rises when plate is activated)
const bridgeMesh = new THREE.Mesh(new THREE.BoxGeometry(4, 1, 13), stoneMat(4, 13));
bridgeMesh.castShadow = bridgeMesh.receiveShadow = true;
scene.add(bridgeMesh);
const bridge = world.addBody({ type: 'kinematic', position: [0, -3, -99.5], shape: { type: 'box', size: [4, 1, 13] } });
bridge.bindObject(bridgeMesh);
let bridgeY = -3;
let puzzleSolved = false;

// Traps
const blades = [];
for (let i = 0; i < 4; i++) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(0.25, 2.4, 2.4), bladeMat);
  mesh.castShadow = true;
  scene.add(mesh);
  blades.push({ mesh, z: -37 - i * 5.5, phase: i * 1.3 });
}
const spikes = [];
for (let i = 0; i < 3; i++) {
  const mesh = new THREE.Mesh(new THREE.ConeGeometry(1.8, 1.6, 6), bladeMat);
  scene.add(mesh);
  spikes.push({ mesh, z: -71 - i * 4, phase: i * 1.1 });
}

// Player
let model = null;
try {
  model = await new GLTFLoader().loadAsync('assets/models/persian-prince.glb');
} catch (e) {
  model = null;
}
const player = await world.addPlayer({ camera, canvas: renderer.domElement, model, feet: [0, 0.2, 4], height: 1.8, view: 'third', touch: true, runSpeed: 8.5, jumpSpeed: 7, yaw: 0 });
scene.add(player.root);

// Audio
const music = new Audio('assets/audio/persian-theme.mp3');
music.loop = true;
music.volume = 0.5;
const chime = new Audio('assets/audio/stone-activate.mp3');
let actx = null;
function beep(freq, dur) {
  if (!actx) {
    return;
  }
  const o = actx.createOscillator();
  const g = actx.createGain();
  o.frequency.value = freq;
  g.gain.setValueAtTime(0.15, actx.currentTime);
  g.gain.exponentialRampToValueAtTime(0.001, actx.currentTime + dur);
  o.connect(g).connect(actx.destination);
  o.start();
  o.stop(actx.currentTime + dur);
}
function playChime() {
  chime.currentTime = 0;
  chime.play().catch(() => {});
}

// UI
const menu = document.getElementById('menu');
const msgEl = document.getElementById('msg');
const infoEl = document.getElementById('info');
const timeEl = document.getElementById('timeBox');
let msgTimer = 0;
function say(text, t = 2.5) {
  msgEl.textContent = text;
  msgEl.style.opacity = 1;
  msgTimer = t;
}
let checkpoint = 0;
let elapsed = 0;
let won = false;
let deaths = 0;
const fa = n => String(n).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);

document.getElementById('startBtn').onclick = () => {
  if (!actx) {
    actx = new AudioContext();
  }
  music.play().catch(() => {});
  if (won) {
    won = false;
    checkpoint = 0;
    elapsed = 0;
    deaths = 0;
    player.teleport(checkpoints[0].toArray());
  }
  menu.style.display = 'none';
  player.start();
  say('به سوی دروازه‌ی زرین!');
};
document.getElementById('pauseBtn').onclick = () => player.pause();

function respawn(reason) {
  deaths++;
  beep(120, 0.4);
  player.teleport(checkpoints[checkpoint].toArray());
  player.setVelocity([0, 0, 0]);
  say(reason);
}

const tmp = new THREE.Vector3();
let climbCooldown = 0;

function tryLedgeGrab() {
  const pos = player.position;
  const fwd = player.forward;
  const origin = [pos.x, pos.y + 0.9, pos.z];
  const wall = world.castRay(origin, [fwd.x, 0, fwd.z], { maxDistance: 1.0, exclude: player.body });
  if (!wall) {
    return false;
  }
  const above = [pos.x + fwd.x * 0.9, pos.y + 3.2, pos.z + fwd.z * 0.9];
  const top = world.castRay(above, [0, -1, 0], { maxDistance: 3.2, exclude: player.body });
  if (top && top.point.y > pos.y + 0.5) {
    player.setVelocity([fwd.x * 3, 10, fwd.z * 3]);
    climbCooldown = 0.5;
    beep(520, 0.15);
    say('لبه را گرفتی!', 1);
    return true;
  }
  return false;
}

function updateGame(dt) {
  if (won) {
    return;
  }
  elapsed += dt;
  climbCooldown -= dt;
  const t = elapsed;
  const pos = player.position;

  if (player.jumpPressed && climbCooldown <= 0) {
    tryLedgeGrab();
  }
  if (!player.grounded && player.jumpHeld && climbCooldown <= 0 && player.velocity.y < 1) {
    tryLedgeGrab();
  }

  blades.forEach(b => {
    const x = Math.sin(t * 1.8 + b.phase) * 2.6;
    b.mesh.position.set(x, 4.4, b.z);
    b.mesh.rotation.z = Math.sin(t * 1.8 + b.phase) * 0.6;
    tmp.set(x, 4.4, b.z);
    if (Math.abs(pos.x - x) < 0.6 && Math.abs(pos.z - b.z) < 1.3 && pos.y < 5) {
      respawn('تیغه تو را زد! زمان‌بندی را ببین.');
    }
  });
  spikes.forEach(s => {
    const up = Math.sin(t * 2 + s.phase) > 0.2;
    const y = up ? 3.6 : 2.2;
    s.mesh.position.set(0, THREE.MathUtils.damp(s.mesh.position.y || 2.2, y, 12, dt), s.z);
    if (up && s.mesh.position.y > 3.3 && Math.abs(pos.z - s.z) < 1.4 && pos.y < 4) {
      respawn('نیزه‌ها برخاستند! وقتی پایین‌اند بدو.');
    }
  });

  // Checkpoints
  for (let i = checkpoints.length - 1; i > checkpoint; i--) {
    if (pos.z < checkpoints[i].z + 2 && pos.y > 3) {
      checkpoint = i;
      playChime();
      say('پاسگاه ذخیره شد');
    }
  }

  // Puzzle plate
  if (!puzzleSolved && Math.hypot(pos.x - 4.5, pos.z + 89) < 1.4 && pos.y > 3) {
    puzzleSolved = true;
    playChime();
    say('فروهر بیدار شد... پل برمی‌خیزد!', 3);
  }
  if (puzzleSolved && bridgeY < 2.7) {
    bridgeY = Math.min(2.7, bridgeY + dt * 2.5);
    bridge.moveTo([0, bridgeY, -99.5]);
  }
  plate.material.color.setScalar(puzzleSolved ? 0.6 : 0.8 + Math.sin(t * 4) * 0.2);
  plateHint.position.y = 5.5 + Math.sin(t * 2) * 0.3;

  if (pos.y < -3) {
    respawn('به ورطه افتادی...');
  }
  if (pos.z < -113 && Math.abs(pos.x) < 3 && pos.y > 2) {
    won = true;
    playChime();
    player.pause();
    document.getElementById('menuText').innerHTML = `پیروزی! به دروازه‌ی زرین رسیدی.<br/>زمان: ${fa(Math.round(elapsed))} ثانیه — سقوط‌ها: ${fa(deaths)}`;
    document.getElementById('startBtn').textContent = 'دوباره';
    menu.style.display = 'flex';
  }
  infoEl.textContent = `پاسگاه ${fa(checkpoint)} / ۳`;
  timeEl.textContent = `${fa(Math.round(elapsed))} ث`;
}

const timer = new THREE.Timer();
renderer.setAnimationLoop(time => {
  timer.update(time);
  const dt = Math.min(0.05, Math.max(0, timer.getDelta()));
  world.advance(dt, { paused: !player.active, afterStep: step => updateGame(step) });
  if (!player.active && !won && menu.style.display === 'none') {
    document.getElementById('startBtn').textContent = 'ادامه';
    menu.style.display = 'flex';
  }
  if (msgTimer > 0) {
    msgTimer -= dt;
    if (msgTimer <= 0) {
      msgEl.style.opacity = 0;
    }
  }
  portal.material.opacity = 0.4 + Math.sin(time * 0.003) * 0.15;
  gateSign.lookAt(camera.position);
  renderer.render(scene, camera);
  });
}
