# Sound Direction
- Music: epic, mysterious Persian adventure theme (oud, santur, frame drums), medium energy, loop.
- SFX: magical stone activation (puzzle solved / checkpoint).
- Procedural Web Audio beeps for jump/hit.
- Audio starts on the first tap (Start button).
