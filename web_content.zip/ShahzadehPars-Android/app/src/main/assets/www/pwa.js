const installButton = document.getElementById('installBtn');
const installInfo = document.getElementById('installInfo');
let deferredPrompt = null;

const isStandalone = () => window.matchMedia('(display-mode: standalone)').matches || Reflect.get(navigator, 'standalone') === true;
const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);

if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js').catch(error => {
      console.warn('ذخیره‌ی آفلاین فعال نشد:', error);
    });
  });
}

if (installButton && !isStandalone()) {
  installButton.hidden = false;
  installButton.textContent = isIOS ? 'افزودن به صفحه‌ی اصلی' : 'نصب بازی';
}

window.addEventListener('beforeinstallprompt', event => {
  event.preventDefault();
  deferredPrompt = event;
  if (installButton) {
    installButton.hidden = false;
    installButton.textContent = 'نصب بازی';
  }
});

installButton?.addEventListener('click', async () => {
  if (deferredPrompt) {
    deferredPrompt.prompt();
    const choice = await deferredPrompt.userChoice;
    deferredPrompt = null;
    if (choice.outcome === 'accepted') installButton.hidden = true;
    return;
  }

  if (isIOS) {
    installInfo.textContent = 'در Safari روی دکمه‌ی اشتراک‌گذاری بزنید و «افزودن به صفحه‌ی اصلی» را انتخاب کنید.';
  } else {
    installInfo.textContent = 'از منوی مرورگر گزینه‌ی «Install app / نصب برنامه» یا «Add to Home screen / افزودن به صفحه‌ی اصلی» را انتخاب کنید. برای نصب و اجرای آفلاین، بازی باید از یک نشانی HTTPS باز شده باشد.';
  }
  installInfo.hidden = false;
});

window.addEventListener('appinstalled', () => {
  if (installButton) installButton.hidden = true;
  if (installInfo) installInfo.hidden = true;
});
