# Art Direction
- Cinematic Achaemenid palace (Persepolis): warm, aged sandstone, shining gold, dusty sunset light, mysterious atmosphere.
- Palette: sand #c9a46a, deep shadow brown #3a2414, gold #f2c14e, lapis blue accents #1f4e8c.
- Fonts: Cinzel Decorative (display), Alegreya (body).
- UI: dark translucent panels with a thin gold border, gold titles.
- Assets: prince model, sandstone relief texture, Faravahar decal, sunset palace skybox.
