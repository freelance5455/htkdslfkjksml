const CACHE_NAME = 'palace-golden-gate-v1';
const ROOT = new URL('./', self.registration.scope);
const local = path => new URL(path, ROOT).href;

const SHELL = [
  './',
  './index.html',
  './main.js',
  './pwa.js',
  './manifest.webmanifest',
  './rosebud/game-defaults.css',
  './rosebud/game-defaults.js',
  './rosie/roseblox.js',
  './assets/app-icon.svg',
  './assets/icons/icon-192.png',
  './assets/icons/icon-512.png'
].map(local);

const OFFLINE_FILES = [
  './assets/faravahar-decal.webp',
  './assets/persepolis-sunset.webp',
  './assets/sandstone-tile.webp',
  './assets/models/persian-prince.glb',
  './assets/audio/persian-theme.mp3',
  './assets/audio/stone-activate.mp3'
].map(local);

const OPTIONAL_MODULES = [
  'https://esm.sh/three@0.184.0',
  'https://esm.sh/three@0.184.0/addons/loaders/GLTFLoader.js',
  'https://esm.sh/@dimforge/rapier3d-compat@0.20.0'
];
const CACHEABLE_EXTERNAL_HOSTS = new Set(['esm.sh', 'fonts.googleapis.com', 'fonts.gstatic.com']);

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    await cache.addAll(SHELL);
    await Promise.all([...OFFLINE_FILES, ...OPTIONAL_MODULES].map(async url => {
      try {
        const response = await fetch(url, { cache: 'reload' });
        if (response.ok || response.type === 'opaque') await cache.put(url, response.clone());
      } catch {
        // Optional media and CDN modules can be cached on the first online visit.
      }
    }));
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const names = await caches.keys();
    await Promise.all(names.filter(name => name.startsWith('palace-golden-gate-') && name !== CACHE_NAME).map(name => caches.delete(name)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);
  const isLocal = url.origin === self.location.origin;
  if (!isLocal && !CACHEABLE_EXTERNAL_HOSTS.has(url.hostname)) return;

  event.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);
    const cached = await cache.match(request);

    if (request.mode === 'navigate') {
      try {
        const response = await fetch(request);
        if (response.ok) event.waitUntil(cache.put(local('./index.html'), response.clone()));
        return response;
      } catch {
        return cached || await cache.match(local('./index.html'));
      }
    }

    if (cached) {
      event.waitUntil(fetch(request).then(response => {
        if (response.ok || response.type === 'opaque') return cache.put(request, response.clone());
        return undefined;
      }).catch(() => {}));
      return cached;
    }

    try {
      const response = await fetch(request);
      if (response.ok || response.type === 'opaque') event.waitUntil(cache.put(request, response.clone()));
      return response;
    } catch (error) {
      const fallback = await cache.match(request);
      if (fallback) return fallback;
      throw error;
    }
  })());
});
