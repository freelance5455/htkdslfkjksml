# پروژه اندروید شاهزاده پارس

این پوشه یک پروژه Android Studio است که فایل‌های بازی را داخل برنامه‌ی WebView قرار می‌دهد.

## ساخت APK
1. Android Studio را نصب کنید.
2. از مسیر **File > Open** همین پوشه `ShahzadehPars-Android` را باز کنید.
3. اجازه دهید Gradle Sync انجام شود و Android SDK 35 را نصب کنید.
4. از منوی **Build > Build Bundle(s) / APK(s) > Build APK(s)** خروجی بگیرید.
5. APK معمولاً در مسیر `app/build/outputs/apk/debug/app-debug.apk` ساخته می‌شود.

## نکته
این پروژه برای ساخت APK آماده شده، اما فایل APK امضاشده در این محیط ساخته نشده است؛ ابزار Android SDK و Gradle در محیط فعلی موجود نیستند. ساخت نسخه انتشار (Release) نیز به کلید امضای خودتان نیاز دارد.
