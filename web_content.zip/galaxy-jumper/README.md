# Galaxy Jumper

A mobile-friendly 2D platformer made with plain HTML, CSS and JavaScript.

## Run it
1. Extract `galaxy-jumper.zip`.
2. Open `index.html` in a modern browser.
3. On Android, open the folder in a code editor with preview, or upload the files to a static host such as GitHub Pages.

No build tools, libraries, accounts, or internet connection are required.

## Controls
- Android: use ◀ / ▶ to move and ⬆ to jump.
- Keyboard: A/D or arrow keys to move; Space or Up to jump.
- Pause: tap Ⅱ or press Escape.

## Included
- 8 themed worlds with progressive difficulty and unlockable levels
- Coins and a completion bonus
- 50 character skins (buy with collected stardust)
- 100 achievements
- Synthesized sound effects using Web Audio
- Responsive touch controls
- Automatic progress saving with localStorage

## Notes
- Browser storage is local to the browser/device. Clearing browser data can erase progress.
- Sound starts after the first user interaction, as required by mobile browsers.
- This is an original starter game project. You can customize world layouts, colors, physics, and rewards in `game.js`.
