#!/bin/bash
set -e
npm install
npx cap add android
python3 apply-native.py
npx cap sync android
echo "تم. دابا: npx cap open android  (و من Android Studio: Build > Build APK)"
