package com.salati.app;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
public class PrayerReceiver extends BroadcastReceiver {
  @Override public void onReceive(Context c, Intent i) {
    PrayerCore.notifyDue(c);
    PrayerCore.scheduleNext(c);
    PrayerWidgetProvider.updateAll(c);
  }
}
