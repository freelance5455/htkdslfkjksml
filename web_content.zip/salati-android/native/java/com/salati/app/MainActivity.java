package com.salati.app;
import android.os.Bundle;
import androidx.core.view.WindowCompat;
import com.getcapacitor.BridgeActivity;
public class MainActivity extends BridgeActivity {
  @Override public void onCreate(Bundle b) {
    registerPlugin(PrayerPlugin.class);
    super.onCreate(b);
    int green = 0xFF062A22;
    getWindow().setStatusBarColor(green);
    getWindow().setNavigationBarColor(green);
    getWindow().getDecorView().setBackgroundColor(green);
    WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
    try { getBridge().getWebView().setBackgroundColor(green); } catch (Exception ignored) {}
  }
}
