package com.salati.app;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.SystemClock;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;

public class PrayerWidgetProvider extends AppWidgetProvider {
  static final int[] P = {R.id.p0, R.id.p1, R.id.p2, R.id.p3, R.id.p4};
  static final int[] N = {R.id.n0, R.id.n1, R.id.n2, R.id.n3, R.id.n4};
  static final int[] T = {R.id.t0, R.id.t1, R.id.t2, R.id.t3, R.id.t4};

  @Override public void onReceive(Context c, Intent i) {
    if (PrayerCore.ACT_TICK.equals(i.getAction())) {
      if (updateAll(c)) PrayerCore.scheduleTick(c);
      return;
    }
    super.onReceive(c, i);
  }
  @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) { updateAll(c); PrayerCore.scheduleTick(c); }
  @Override public void onEnabled(Context c) { PrayerCore.scheduleTick(c); }

  /** @return true if at least one widget is on the home screen */
  static boolean updateAll(Context c) {
    AppWidgetManager m = AppWidgetManager.getInstance(c);
    int[] ids = m.getAppWidgetIds(new ComponentName(c, PrayerWidgetProvider.class));
    if (ids.length == 0) return false;
    try { m.updateAppWidget(ids, build(c)); } catch (Exception ignored) {}
    return true;
  }

  static RemoteViews build(Context c) throws Exception {
    RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_prayer);
    v.setOnClickPendingIntent(R.id.root, PendingIntent.getActivity(c, 2, new Intent(c, MainActivity.class), PrayerCore.FLAGS));
    JSONObject d = PrayerCore.load(c);
    JSONArray a = d.optJSONArray("items");
    long now = System.currentTimeMillis();
    int ni = -1;
    if (a != null) for (int i = 0; i < a.length(); i++) if (a.getJSONObject(i).getLong("t") > now) { ni = i; break; }
    if (ni < 0) { v.setTextViewText(R.id.tvNext, "افتح التطبيق للتحديث"); return v; }

    JSONObject nx = a.getJSONObject(ni);
    long nt = nx.getLong("t");
    long pt = ni > 0 ? a.getJSONObject(ni - 1).getLong("t") : nt - 6 * 3600000L;
    v.setTextViewText(R.id.tvHijri, d.optString("hijri"));
    v.setTextViewText(R.id.tvCity, d.optString("city"));
    v.setTextViewText(R.id.tvNext, nx.optString("n"));
    v.setTextViewText(R.id.tvIn, d.optString("inl", "بعد "));
    if (Build.VERSION.SDK_INT >= 24) v.setChronometerCountDown(R.id.chrono, true);
    v.setChronometer(R.id.chrono, SystemClock.elapsedRealtime() + (nt - now), null, true);
    int prog = (int) Math.max(0, Math.min(1000, (nt - now) * 1000L / Math.max(1L, nt - pt)));
    v.setProgressBar(R.id.bar, 1000, prog, false);

    int start = ni - nx.optInt("o", 0);
    for (int j = 0; j < 5; j++) {
      int idx = start + j;
      if (idx < 0 || idx >= a.length()) continue;
      JSONObject it = a.getJSONObject(idx);
      boolean isNext = idx == ni;
      v.setTextViewText(N[j], it.optString("n"));
      v.setTextViewText(T[j], it.optString("tm"));
      v.setInt(P[j], "setBackgroundResource", isNext ? R.drawable.widget_next : R.drawable.widget_none);
      v.setTextColor(N[j], isNext ? 0xFFFFFFFF : 0xFFEBD08A);
      v.setTextColor(T[j], isNext ? 0xFFFFFFFF : 0xFFFBF8F1);
    }
    return v;
  }
}
