package com.salati.app;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import org.json.JSONArray;
import org.json.JSONObject;

public class PrayerCore {
  static final String CH = "prayer_time";
  static final String ACT_PRAYER = "com.salati.app.PRAYER";
  static final String ACT_TICK = "com.salati.app.TICK";
  static final int FLAGS = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;

  static SharedPreferences sp(Context c) { return c.getSharedPreferences("salati", 0); }

  static JSONObject load(Context c) {
    try { return new JSONObject(sp(c).getString("data", "{}")); } catch (Exception e) { return new JSONObject(); }
  }

  static final long PRE = 5 * 60000L;

  /** One exact alarm for the earliest upcoming event (5 min before, or prayer time); the receiver schedules the next. */
  static void scheduleNext(Context c) {
    try {
      JSONObject d = load(c);
      JSONArray a = d.optJSONArray("items");
      if (a == null) return;
      boolean pre = d.optBoolean("pre", true);
      long now = System.currentTimeMillis(), best = Long.MAX_VALUE;
      for (int i = 0; i < a.length(); i++) {
        long t = a.getJSONObject(i).getLong("t");
        if (pre && t - PRE > now) best = Math.min(best, t - PRE);
        if (t > now) best = Math.min(best, t);
      }
      if (best == Long.MAX_VALUE) return;
      AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
      PendingIntent pi = PendingIntent.getBroadcast(c, 1001, new Intent(c, PrayerReceiver.class).setAction(ACT_PRAYER), FLAGS);
      if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, best, pi);
      else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, best, pi);
    } catch (Exception ignored) {}
  }

  /** Refresh the widget at the next minute boundary. */
  static void scheduleTick(Context c) {
    AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
    long t = (System.currentTimeMillis() / 60000L + 1) * 60000L;
    PendingIntent pi = PendingIntent.getBroadcast(c, 1002, new Intent(c, PrayerWidgetProvider.class).setAction(ACT_TICK), FLAGS);
    am.setAndAllowWhileIdle(AlarmManager.RTC, t, pi);
  }

  static void notifyDue(Context c) {
    try {
      JSONObject d = load(c);
      JSONArray a = d.optJSONArray("items");
      if (a == null) return;
      boolean main = d.optBoolean("notif", true), pre = d.optBoolean("pre", true);
      long now = System.currentTimeMillis(), last = sp(c).getLong("last", 0), newLast = last;
      for (int i = 0; i < a.length(); i++) {
        JSONObject it = a.getJSONObject(i);
        long t = it.getLong("t");
        for (int k = 0; k < 2; k++) {
          long e = k == 0 ? t - PRE : t;
          boolean on = k == 0 ? pre : main;
          if (e <= now + 3000 && e > now - 10 * 60000L && e > last) {
            if (on) show(c, d.optString("title", "صلاتي"), it.optString(k == 0 ? "p" : "b"), e);
            newLast = Math.max(newLast, e);
          }
        }
      }
      if (newLast != last) sp(c).edit().putLong("last", newLast).apply();
    } catch (Exception ignored) {}
  }

  static void show(Context c, String title, String body, long t) {
    NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
    if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(new NotificationChannel(CH, "أوقات الصلاة", NotificationManager.IMPORTANCE_HIGH));
    Intent open = new Intent(c, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
    PendingIntent pi = PendingIntent.getActivity(c, 0, open, FLAGS);
    NotificationCompat.Builder b = new NotificationCompat.Builder(c, CH)
        .setSmallIcon(R.drawable.ic_stat_prayer).setContentTitle(title).setContentText(body)
        .setContentIntent(pi).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH)
        .setCategory(NotificationCompat.CATEGORY_REMINDER).setWhen(t).setShowWhen(true);
    nm.notify((int) (t / 60000L), b.build());
  }
}
