package com.salati.app;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
public class BootReceiver extends BroadcastReceiver {
  @Override public void onReceive(Context c, Intent i) {
    PrayerCore.scheduleNext(c);
    PrayerCore.scheduleTick(c);
    PrayerWidgetProvider.updateAll(c);
  }
}
