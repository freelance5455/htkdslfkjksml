package com.salati.app;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.IBinder;
import androidx.core.app.NotificationCompat;
import java.io.File;

/** Plays the adhan file chosen by the user, even when the app is closed. */
public class AdhanService extends Service {
  static final String CH = "prayer_adhan";
  static final String ACT_STOP = "com.salati.app.ADHAN_STOP";
  private MediaPlayer mp;

  @Override public IBinder onBind(Intent i) { return null; }

  @Override public int onStartCommand(Intent i, int flags, int startId) {
    if (i != null && ACT_STOP.equals(i.getAction())) { stopSelf(); return START_NOT_STICKY; }
    String title = i != null && i.getStringExtra("title") != null ? i.getStringExtra("title") : "صلاتي";
    String body = i != null && i.getStringExtra("body") != null ? i.getStringExtra("body") : "";
    NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
    if (Build.VERSION.SDK_INT >= 26) {
      NotificationChannel ch = new NotificationChannel(CH, "الأذان", NotificationManager.IMPORTANCE_HIGH);
      ch.setSound(null, null);
      nm.createNotificationChannel(ch);
    }
    PendingIntent open = PendingIntent.getActivity(this, 0,
        new Intent(this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP), PrayerCore.FLAGS);
    PendingIntent stop = PendingIntent.getService(this, 3, new Intent(this, AdhanService.class).setAction(ACT_STOP), PrayerCore.FLAGS);
    Notification n = new NotificationCompat.Builder(this, CH)
        .setSmallIcon(R.drawable.ic_stat_prayer).setContentTitle(title).setContentText(body)
        .setContentIntent(open).addAction(0, "إيقاف", stop).setOngoing(true)
        .setPriority(NotificationCompat.PRIORITY_HIGH).setCategory(NotificationCompat.CATEGORY_REMINDER).build();
    if (Build.VERSION.SDK_INT >= 29) startForeground(4001, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
    else startForeground(4001, n);
    try {
      if (mp != null) mp.release();
      mp = new MediaPlayer();
      mp.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
      mp.setDataSource(new File(getFilesDir(), "adhan.audio").getPath());
      mp.setOnCompletionListener(m -> stopSelf());
      mp.setOnErrorListener((m, w, e) -> { stopSelf(); return true; });
      mp.prepare();
      mp.start();
    } catch (Exception e) { stopSelf(); }
    return START_NOT_STICKY;
  }

  @Override public void onDestroy() {
    try { if (mp != null) { mp.release(); mp = null; } } catch (Exception ignored) {}
    stopForeground(true);
    super.onDestroy();
  }
}
