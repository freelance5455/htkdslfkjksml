package com.salati.app;
import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "Prayer")
public class PrayerPlugin extends Plugin {
  @PluginMethod
  public void sync(PluginCall call) {
    Context c = getContext();
    PrayerCore.sp(c).edit().putString("data", call.getData().toString()).apply();
    PrayerCore.scheduleNext(c);
    PrayerCore.scheduleTick(c);
    PrayerWidgetProvider.updateAll(c);
    if (Build.VERSION.SDK_INT >= 33 && getActivity() != null
        && ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
      ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.POST_NOTIFICATIONS}, 77);
    }
    call.resolve();
  }
}
