package com.salati.app;
import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.annotation.ActivityCallback;
import java.io.InputStream;
import android.content.Intent;
import android.util.Base64;
import com.getcapacitor.JSObject;
import java.io.File;
import java.io.FileOutputStream;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "Prayer")
public class PrayerPlugin extends Plugin {
  @PluginMethod
  public void sync(PluginCall call) {
    Context c = getContext();
    PrayerCore.sp(c).edit().putString("data", call.getData().toString()).apply();
    PrayerCore.scheduleNext(c);
    PrayerCore.scheduleTick(c);
    PrayerWidgetProvider.updateAll(c);
    if (Build.VERSION.SDK_INT >= 33 && getActivity() != null
        && ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
      ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.POST_NOTIFICATIONS}, 77);
    }
    call.resolve();
  }

  @PluginMethod
  public void saveAdhan(PluginCall call) {
    try {
      byte[] b = Base64.decode(call.getString("data", ""), Base64.DEFAULT);
      try (FileOutputStream o = new FileOutputStream(new File(getContext().getFilesDir(), "adhan.audio"))) { o.write(b); }
      call.resolve();
    } catch (Exception e) { call.reject("saveAdhan failed"); }
  }

  @PluginMethod
  public void hasAdhan(PluginCall call) {
    JSObject r = new JSObject();
    r.put("has", PrayerCore.hasAdhan(getContext()));
    r.put("path", new File(getContext().getFilesDir(), "adhan.audio").getAbsolutePath());
    call.resolve(r);
  }

  @PluginMethod
  public void stopAdhan(PluginCall call) {
    getContext().stopService(new Intent(getContext(), AdhanService.class));
    call.resolve();
  }

  /** Opens the phone's file picker for an audio file and stores it for the background adhan. */
  @PluginMethod
  public void pickAdhan(PluginCall call) {
    Intent i = new Intent(Intent.ACTION_GET_CONTENT);
    i.setType("audio/*");
    i.addCategory(Intent.CATEGORY_OPENABLE);
    startActivityForResult(call, Intent.createChooser(i, "Adhan"), "pickResult");
  }

  @ActivityCallback
  private void pickResult(PluginCall call, ActivityResult result) {
    if (call == null) return;
    if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) {
      call.reject("cancelled");
      return;
    }
    Uri u = result.getData().getData();
    File dst = new File(getContext().getFilesDir(), "adhan.audio");
    try (InputStream in = getContext().getContentResolver().openInputStream(u); FileOutputStream o = new FileOutputStream(dst)) {
      byte[] buf = new byte[65536];
      int n;
      while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
    } catch (Exception e) { call.reject("copy failed"); return; }
    String name = "";
    try (Cursor q = getContext().getContentResolver().query(u, null, null, null, null)) {
      if (q != null && q.moveToFirst()) { int ix = q.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (ix >= 0) name = q.getString(ix); }
    } catch (Exception ignored) {}
    JSObject r = new JSObject();
    r.put("name", name);
    r.put("path", dst.getAbsolutePath());
    call.resolve(r);
  }
}
