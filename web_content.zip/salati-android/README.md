# صلاتي: نسخة أندرويد (APK)

المتطلبات: Node 18+ ، JDK 17 ، Android Studio.

1. `./setup.sh`   (كيدير npm install + cap add android + كيزيد الجزء الأصلي)
2. `npx cap open android`  ثم  Build > Build APK(s)  (ولا من التيرمينال: `cd android && ./gradlew assembleDebug`)
3. الـ APK كيبان فـ `android/app/build/outputs/apk/debug/`

داخل التطبيق: فعّل الإشعارات ملي يطلبها الهاتف، ثم فعّل «إشعار على الجهاز» فالإعدادات.
الـ Widget: ضغطة طويلة على الشاشة الرئيسية > Widgets > صلاتي.

ملاحظة: بعض الهواتف (Xiaomi / Huawei / Oppo) خاصك تحيد تقييد البطارية على التطبيق، وإلا النظام يوقف المنبهات.
بعد تعديل أي ملف فـ www: `npx cap sync android`.
