import os,re,shutil
base='android/app/src/main'
for root,_,files in os.walk('native'):
    for f in files:
        src=os.path.join(root,f); dst=os.path.join(base,os.path.relpath(src,'native'))
        os.makedirs(os.path.dirname(dst),exist_ok=True); shutil.copy(src,dst)
mp=base+'/AndroidManifest.xml'; m=open(mp,encoding='utf-8').read()
if 'PrayerReceiver' not in m:
    perms='''    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>
    <uses-permission android:name="android.permission.USE_EXACT_ALARM"/>
    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" android:maxSdkVersion="32"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK"/>
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
'''
    recv='''        <service android:name=".AdhanService" android:exported="false" android:foregroundServiceType="mediaPlayback"/>
        <receiver android:name=".PrayerReceiver" android:exported="false"/>
        <receiver android:name=".BootReceiver" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED"/>
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>
                <action android:name="android.intent.action.TIMEZONE_CHANGED"/>
                <action android:name="android.intent.action.TIME_SET"/>
            </intent-filter>
        </receiver>
        <receiver android:name=".PrayerWidgetProvider" android:exported="true">
            <intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE"/></intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/prayer_widget_info"/>
        </receiver>
'''
    m=m.replace('<application',perms+'    <application',1).replace('</application>',recv+'    </application>',1)
    open(mp,'w',encoding='utf-8').write(m)
vp='android/variables.gradle'
if os.path.exists(vp):
    v=open(vp).read(); v=re.sub(r'minSdkVersion\s*=\s*\d+','minSdkVersion = 24',v); open(vp,'w').write(v)
print('native layer applied')
