ضع هنا ملفات الخطوط (اختياري):
Cairo.woff2, Amiri-Regular.woff2, Amiri-Bold.woff2, ReemKufi.woff2
بدونها يستعمل التطبيق خطوط أندرويد الافتراضية.
