MESTRE GORDÃO 2.1 — PROJETO ANDROID

Esta versão mantém a aplicação web original e adiciona uma camada de IA local mais inteligente, com busca semântica básica no catálogo de itens, contexto do personagem e envio correto do system prompt ao endpoint configurado.

GERAR APK
1. Instale Node.js e Android Studio/Android SDK em um computador.
2. Na pasta do projeto, execute: npm install
3. Execute: npx cap add android (caso a pasta android ainda não exista)
4. Execute: npx cap sync android
5. Abra no Android Studio: npx cap open android
6. Compile o APK pelo Android Studio.

ARQUITETURA DA IA
- Sem endpoint: o aplicativo continua funcional offline e responde perguntas rápidas usando os dados locais.
- Com endpoint: o app envia system prompt + histórico + contexto da ficha para o servidor configurado.
- Recomendação: em produção, use um proxy/backend seguro em vez de colocar uma chave de API permanente dentro do APK.

TECNOLOGIA
Capacitor + HTML/CSS/JavaScript.
