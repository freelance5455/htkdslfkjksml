NOVA CHAMPIONS — BY HOUSSNI (PWA package)

This package adds the branded splash screen and installable PWA metadata to the existing website. It is NOT yet a signed APK.

DEPLOY
1) Upload the contents of this ZIP to the existing Netlify site, replacing the site's files. Do not delete or reset Firebase data or rules.
2) Open the site over HTTPS in Chrome on Android. Use the browser menu > Install app (or Add to Home screen).
3) To create an Android APK, open PWABuilder (https://www.pwabuilder.com/), enter https://luminous-dasik-f8d955.netlify.app, run the checks, then choose Android package. Review package details and signing options before building.

NOTES
- App data and Firebase sync still require internet.
- The splash image is a custom fan-made design, not official EA SPORTS artwork.
- Keep the same Netlify domain so Firebase and existing links continue to work.
