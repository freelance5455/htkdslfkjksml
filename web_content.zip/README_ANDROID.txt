HÉSOM ANDROID — VERSÃO 1.1

Projeto Android revisado para manter as funções do Hésom com menor custo de memória e uma ponte nativa de reprodução mais segura.

PRINCIPAIS CORREÇÕES
- Media3/ExoPlayer + MediaSessionService para reprodução em segundo plano e controles do sistema.
- Fila nativa com anterior/próxima na tela bloqueada.
- Importação copia os arquivos para armazenamento privado do app, sem Base64.
- WebView usa WebViewAssetLoader em vez de acesso amplo a arquivos.
- Microfone só solicita permissão quando a função Hésom Ouviu é usada.
- Tráfego HTTP sem criptografia não é permitido pelo aplicativo.
- Proteção contra path traversal nos arquivos importados.
- Busca por voz continua disponível quando suportada pelo dispositivo.
- Vídeos locais, playlists, favoritos, histórico, letras/anotações e busca continuam no projeto.
- A configuração de reprodução automática é respeitada também pela fila nativa.

AUDITORIA ESTÁTICA
- Sintaxe JavaScript: aprovada.
- Referências JS a IDs HTML: aprovadas.
- IDs duplicados: nenhum encontrado.
- Base64 no fluxo de áudio: não encontrado.
- WebView com acesso amplo a arquivos: removido.
- Cleartext HTTP: removido.
- Fila MediaSession: presente.
- Proteção de caminhos: presente.

LIMITAÇÃO
Este ambiente não possui um Android SDK/Gradle completo, portanto o APK final precisa ser compilado e executado no Android Studio em um ambiente Android real. Isso é necessário para validar hardware, tela bloqueada, notificações e codecs específicos do aparelho.
