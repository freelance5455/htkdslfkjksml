ROADSTER STUNT RUSH 3D — ANDROID GAME ZIP

1. Extract this ZIP using ZArchiver.
2. Keep Roadster_Stunt_Rush_3D_UPGRADED.html and the models folder together.
3. Open the HTML file in Chrome. If Android Chrome blocks local 3D assets, serve the extracted folder using a local web server app.
4. Internet is required for the Three.js scripts loaded from the CDN.

Selected user models:
- Lamborghini Aventador: models/lambo/ (resized to ~4.6 units long, textured)
- Dominus Hover (replaces the old hover car / FBX Roadster): models/dominus/ with hover wheels
- Ferrari F40: models/ferrari/
- Jeep (replaces Military Hummer): models/jeep/
- Buggy (replaces Sand Buggy): models/sandbuggy/

The source OBJ models contain their own geometry; the model loader reads their MTL materials.

v3: bold Beach/Voxel/Jungle maps with longer render distance, Cybertruck obstacles, bold barricades, bigger + mega ramps, new blue/dark-yellow boss (shoots cylinders and triangles), Dune Monster wheels 2x.

v4: deeper bold colours (e.g. #66FF00 -> #008000), ramps only spawn after every 100 coins collected (mega every 3rd), slower score, Military Truck (models/miltruck) + Cybertruck obstacles, smooth drag/swipe touch steering.
