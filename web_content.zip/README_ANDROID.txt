# Starfall Defense — Android-ready project

## What's improved
- Added a boss battle at the end of each of the four chapters.
- The final Void Emperor has a much larger health pool and faster, triple-shot attacks.
- Increased enemy speed, meteor speed, spawn frequency, and tougher-enemy probability.
- Ship unlocks require completed rewarded ads: Comet needs 2; Phoenix and Phantom need 3.
- Revive requires a completed rewarded ad and is limited to once per mission. The old fake countdown ad was removed.
- Added Capacitor configuration so the game can be packaged as an Android WebView app.
- Kept the game self-contained and offline-friendly except for actual ad delivery.

## Build an APK
You need Node.js LTS, Android Studio, and an Android SDK installed.

1. Extract this folder.
2. Open a terminal in this folder and run:
   ```bash
   npm install
   npm run build
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
   If `android/` already exists, skip `npx cap add android`.
3. In Android Studio, wait for Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. For a release APK, configure your own signing key in Android Studio and use **Build > Generate Signed Bundle / APK**.

## Important: rewarded ads
The HTML now expects the native Android wrapper to expose:
`window.starfallShowRewardedAd()`, resolving to `true` only when the user earns the reward after a completed rewarded ad, and `false` otherwise.

This ZIP does **not** contain an ad-network SDK or ad-unit IDs. Real ads cannot run until you integrate a provider such as Google AdMob Rewarded Ads in the Android project and bridge its earned-reward callback to that function. Do not treat an ad being loaded or merely closed as a completed reward. Until that bridge is installed, ship unlocks and revive correctly remain unavailable rather than pretending a demo ad was watched.

## Troubleshooting conversion
- Do not try to rename the ZIP to `.apk`. Extract the project first.
- If an APK converter rejects the original ZIP, use the Capacitor workflow above to create a native Android project.
- If Android Studio reports SDK/Gradle errors, install the Android SDK Platform and Build-Tools recommended by Android Studio, then sync again.
- If you change `index.html`, run `npm run build` and `npx cap sync android` before rebuilding.

## Testing checklist
- Test touch controls on an Android device.
- Verify all four chapter bosses and the final boss.
- Verify rewarded-ad callbacks only grant ships/revive after the provider reports a completed reward.
- Test pause/resume, mission select, and device back behavior in the generated Android wrapper.
