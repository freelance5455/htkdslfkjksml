# DM Cricket -> APK (Capacitor)

Needs: Node 18+, JDK 17, Android Studio (or Android SDK command-line tools).

    npm i @capacitor/core @capacitor/android
    npm i -D @capacitor/cli
    npx cap add android
    npx cap sync android
    cd android && ./gradlew assembleDebug

APK appears at: android/app/build/outputs/apk/debug/app-debug.apk
(Or run `npx cap open android` and use Build > Build APK(s) in Android Studio.)

To edit the app, change www/index.html, then run `npx cap sync android` and rebuild.
For Play Store: Build > Generate Signed Bundle / APK in Android Studio.
