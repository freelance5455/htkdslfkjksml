AZMATSPIDER PACKS

CONTENTS
- index.html: complete responsive app interface and local app logic
- manifest.webmanifest: installable web-app metadata
- sw.js: offline app-shell cache

ADMIN PIN
6266

FEATURES
- Java, Bedrock and Both filters
- Mods, Addons, Shaders, Texture Packs, Resource Packs, Maps, Skins and Worlds
- Map subcategories: Survival, Horror, Skyblock, PvP, One Block, Adventure, Parkour, Multiplayer and Custom Worlds
- Search, favorites and download history
- Admin add, edit and delete packs
- Upload local pack files or attach HTTPS download links
- Ratings and reviews
- Download counter
- Dismissible ad-break placeholder after every two started downloads
- App branding/logo editor
- JSON backup and restore
- Responsive phone and desktop layout

RUN / INSTALL
For a quick preview, open index.html in a modern browser. For PWA installation and offline caching, host this folder on an HTTPS static host, open it in Chrome, then use the browser menu's Install app / Add to Home screen option.

IMPORTANT LIMITATIONS
This package is a complete front-end/PWA source bundle, not a signed Android APK. It does not include a hosted backend, shared cloud catalogue, real ad-network integration, Play Store signing, or server-side authentication. Admin changes, uploaded files, ratings, reviews and history are stored locally in the browser/device. The PIN is client-side and is suitable only for a personal/local admin gate, not for protecting a public production service. A shared multi-user public app requires a backend/database and secure authentication. The ad screen is a placeholder and does not display paid ads or generate revenue.

Only upload or link files you own or have permission to distribute. Check Minecraft version and loader compatibility before publishing packs.
