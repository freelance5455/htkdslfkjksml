Setbase GNSS — Android Studio Project

วิธีสร้าง APK:
1. เปิด Android Studio (ติดตั้ง Android SDK Platform 35)
2. File > Open > เลือกโฟลเดอร์ SetbaseGNSS_Android_Project
3. รอ Gradle Sync (ต้องมีอินเทอร์เน็ตครั้งแรกเพื่อดาวน์โหลดเครื่องมือ)
4. Build > Build Bundle(s) / APK(s) > Build APK(s)
5. ไฟล์อยู่ที่ app/build/outputs/apk/debug/app-debug.apk

แอปคำนวณออฟไลน์โดยใช้ HTML เดิมพร้อมตาราง GEOID ที่ฝังอยู่ในไฟล์
Bluetooth รองรับเฉพาะ Bluetooth Classic SPP ของอุปกรณ์ที่จับคู่ใน Android แล้ว
BLE ยังไม่รองรับใน native bridge นี้
คำสั่ง GNSS ขึ้นกับเฟิร์มแวร์ของเครื่องรับ ต้องทดสอบกับอุปกรณ์จริง
ยังไม่ได้ทดสอบ build หรือทดสอบการทำงานกับเครื่อง GNSS จริง
