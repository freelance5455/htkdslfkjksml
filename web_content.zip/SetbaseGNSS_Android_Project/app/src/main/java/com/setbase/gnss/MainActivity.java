package com.setbase.gnss;
import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.webkit.*;
import android.widget.Toast;
import android.os.Handler;
import android.os.Looper;
import java.io.*;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
 WebView web; BluetoothSocket socket; InputStream input; OutputStream output;
 final Handler ui=new Handler(Looper.getMainLooper()); volatile boolean connected=false;
 final String UUID_SPP="00001101-0000-1000-8000-00805F9B34FB";
 boolean permitted(){return Build.VERSION.SDK_INT<31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;}
 void js(String code){ui.post(()->{if(web!=null)web.evaluateJavascript(code,null);});}
 void status(String msg,boolean ok){js("window.onBtStatus("+JSONObject.quote(msg)+","+ok+")");}
 @Override public void onCreate(Bundle b){super.onCreate(b);web=new WebView(this);web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);web.getSettings().setAllowFileAccess(true);web.addJavascriptInterface(new Bridge(),"AndroidBT");web.setWebViewClient(new WebViewClient());setContentView(web);web.loadUrl("file:///android_asset/index.html");if(!permitted()&&Build.VERSION.SDK_INT>=31)requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},100);}
 class Bridge {
  @JavascriptInterface public String listPaired(){JSONObject result=new JSONObject();JSONArray devices=new JSONArray();try{if(!permitted()){result.put("ok",false);result.put("err","permission");return result.toString();}BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter();if(a==null||!a.isEnabled()){result.put("ok",false);result.put("err","off");return result.toString();}for(BluetoothDevice d:a.getBondedDevices()){JSONObject x=new JSONObject();x.put("name",d.getName()==null?"GNSS":d.getName());x.put("address",d.getAddress());devices.put(x);}result.put("ok",true);result.put("devices",devices);}catch(Exception e){try{result.put("ok",false);result.put("err",e.toString());}catch(Exception ignored){}}return result.toString();}
  @JavascriptInterface public void connect(String address){new Thread(()->{disconnectInternal();try{if(!permitted()){status("ต้องอนุญาต Bluetooth ก่อน",false);return;}BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter();if(a==null||!a.isEnabled())throw new IOException("Bluetooth ปิดอยู่");BluetoothDevice device=a.getRemoteDevice(address);status("กำลังเชื่อมต่อ "+device.getName(),false);a.cancelDiscovery();BluetoothSocket s=device.createRfcommSocketToServiceRecord(java.util.UUID.fromString(UUID_SPP));s.connect();socket=s;input=s.getInputStream();output=s.getOutputStream();connected=true;status("เชื่อมต่อแล้ว: "+device.getName(),true);byte[] buf=new byte[2048];int n;while(connected&&(n=input.read(buf))!=-1){String data=new String(buf,0,n,java.nio.charset.StandardCharsets.US_ASCII);js("window.onBtData("+JSONObject.quote(data)+")");}}catch(Exception e){status("Bluetooth: "+e.getMessage(),false);}finally{disconnectInternal();status("ตัดการเชื่อมต่อแล้ว",false);}}).start();}
  @JavascriptInterface public boolean send(String command){if(!connected||output==null)return false;try{synchronized(MainActivity.this){output.write(command.getBytes(java.nio.charset.StandardCharsets.US_ASCII));output.flush();}return true;}catch(Exception e){status("ส่งคำสั่งไม่สำเร็จ: "+e.getMessage(),false);return false;}}
  @JavascriptInterface public void disconnect(){disconnectInternal();status("ตัดการเชื่อมต่อแล้ว",false);}
  @JavascriptInterface public void copy(String text){ui.post(()->{android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);cm.setPrimaryClip(ClipData.newPlainText("Setbase",text));});}
 }
 synchronized void disconnectInternal(){connected=false;try{if(socket!=null)socket.close();}catch(Exception ignored){}socket=null;input=null;output=null;}
 @Override protected void onDestroy(){disconnectInternal();if(web!=null)web.destroy();super.onDestroy();}
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
