Waqar Stocks - Updated

1. Open Waqar_Stocks.html in a supported browser on your phone.
2. Import your stock list using Upload Excel / CSV. Expected headings: Item Number, Model (or Search Name), Colour/Color, System Stock.
3. Live summary at the top shows total system pieces, counted pieces across all four floors, and the difference. It updates whenever a quantity changes.
4. Download Excel (.xlsx) creates a tally report; Download CSV Report is also available.
5. Excel .xlsx/.xls import and Excel export load the SheetJS library from the internet, so those features need an internet connection when first used. CSV import/export and the stock tally itself work offline.
6. Data auto-saves in this browser on this phone. Use Save Backup to Downloads regularly; keep the JSON backup safe. Clearing browser data can erase local tally data.
7. Camera model text reading needs camera permission and an internet connection to load its OCR engine.
8. Google Drive automatic backup is not connected.
9. This is an HTML app, not an APK.
