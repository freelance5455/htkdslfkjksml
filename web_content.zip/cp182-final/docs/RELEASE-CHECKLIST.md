# Release checklist — V18.1 Final

## Done & tested (automated)
- [x] App: 7 languages, RTL, offline, alerts/stock/overdue logic, mobile layout (no overflow), cloud sync client, delete account
- [x] Server 1.3.0: auth, sync, conflicts, license, portal, audit, email OTP (Resend/webhook), account deletion, secrets, rate limits
- [x] `npm test` (3 server suites) · `npm run test:e2e` (2 devices + real server + UI) · build tool

## Remaining = servers & publishing (cannot be done inside this package)
- [ ] VPS + domain + HTTPS (docs/DEPLOY.md)  [ ] Resend domain verified  [ ] backups scheduled & restore tested
- [ ] Docker/Caddy/systemd files were written but NOT executed in my sandbox: do a dry run on your VPS first
- [ ] Install the APK on 2 real phones and repeat the sync scenario (create / edit / delete / offline then reconnect)
- [ ] Privacy policy + terms URL, store listing; Play Store requires an account-deletion web link too (use your support page)
- [ ] Android blocks cleartext http to public hosts: use the https endpoint
- [ ] Payments (Play Billing / Stripe) are not integrated: sell licenses manually via the admin endpoint at first

## Known limits (see ARCHITECTURE.md §6)
Whole-snapshot sync with record-level merge · JSON-file storage (pilot scale) · localStorage ~5 MB (no photos yet) · only owner role enforced.
