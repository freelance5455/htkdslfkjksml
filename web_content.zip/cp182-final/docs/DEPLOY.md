# Deploying Contractor Pro (server) — step by step

You need: a small VPS (1 vCPU / 1 GB, Ubuntu 22.04+), a domain, and a free Resend account (login codes by email).

## 1. Prepare
1. Buy/rent the VPS; point a DNS **A record** (e.g. `api.yourdomain.com`) to its IP.
2. In Resend: add & verify your sending domain, create an API key.
3. On the VPS: `curl -fsSL https://get.docker.com | sh`

## 2. Install
```sh
# upload this whole project folder to the VPS (scp / git), then:
cd contractor-pro/deploy
cp .env.example .env && nano .env      # set CP_DOMAIN, Resend key, mail-from
echo "CP_JWT_SECRET=$(openssl rand -base64 48)"  # paste into .env
echo "CP_ADMIN_KEY=$(openssl rand -base64 24)"   # paste into .env  (keep it private!)
docker compose up -d --build
curl https://api.yourdomain.com/health          # -> {"ok":true,...,"version":"1.3.0"}
```
HTTPS certificates are issued automatically by Caddy. In production the server refuses to start with `CP_OTP_MODE=console`.
Without Docker: use `contractor-pro.service` (systemd) behind any HTTPS reverse proxy; set `CP_TRUST_PROXY=1`.

## 3. Build the app with your address
```sh
node tools/build-app.js --endpoint https://api.yourdomain.com --out dist
```
Give `dist/` (root `index.html`) to your HTML-to-APK tool, sign the APK. Users only enter their email + code.

## 4. Licenses (you sell them; the server enforces them)
After a user signs in, get their id from the app/`GET /api/auth/me`, then:
```sh
curl -X POST https://api.yourdomain.com/api/admin/license/provision \
  -H "X-Admin-Key: $CP_ADMIN_KEY" -H "Content-Type: application/json" \
  -d '{"userId":"usr_...","plan":"pro","days":365}'
```

## 5. Operate
- Logs: `docker compose logs -f api` · Update: replace files, `docker compose up -d --build` (data lives in the `cpdata` volume).
- Backup (daily cron): `deploy/backup.sh <data.json> <dir>`; for Docker see the comment inside the script. Test a restore once.
- Monitoring: add an uptime check on `/health` (UptimeRobot etc.). Firewall: only 22, 80, 443.
- Delete-account: in-app button (Settings > Cloud > Delete cloud account) calls `POST /api/account/delete`.
