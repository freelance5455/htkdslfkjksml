#!/usr/bin/env node
// Usage: node tools/build-app.js --endpoint https://api.example.com [--out dist]
// Stamps your server address into the app so users never type it. Output: <out>/index.html (+ package.json).
const fs=require('fs'),path=require('path');
const a=process.argv.slice(2),get=k=>{const i=a.indexOf('--'+k);return i>=0?a[i+1]:''};
const ep=get('endpoint'),out=path.resolve(get('out')||'dist');
let u;try{u=new URL(ep)}catch(e){console.error('Give --endpoint https://your-domain');process.exit(1)}
const lan=/^(localhost|127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(u.hostname);
if(u.protocol!=='https:'&&!(u.protocol==='http:'&&lan)){console.error('Endpoint must be https (http only for LAN/localhost).');process.exit(1)}
const src=path.resolve(__dirname,'../app/index.html');let h=fs.readFileSync(src,'utf8');
if(h.split('const DEFAULT_ENDPOINT="";').length!==2){console.error('Marker not found in app');process.exit(1)}
h=h.replace('const DEFAULT_ENDPOINT="";','const DEFAULT_ENDPOINT='+JSON.stringify(u.origin)+';');
fs.mkdirSync(out,{recursive:true});fs.writeFileSync(path.join(out,'index.html'),h);
fs.copyFileSync(path.resolve(__dirname,'../app/package.json'),path.join(out,'package.json'));
console.log('OK ->',path.join(out,'index.html'),'endpoint',u.origin);
