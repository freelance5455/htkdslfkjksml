#!/bin/sh
# Daily backup, keeps 14 copies.  Usage: backup.sh <data.json> <backup-dir>   (cron: 15 3 * * * /path/backup.sh ...)
# Docker volume:  docker run --rm -v deploy_cpdata:/data -v $PWD/backups:/b alpine sh -c 'cp /data/data.json /b/data-$(date +%F).json'
set -eu
SRC="${1:?data file}"; DST="${2:?backup dir}"; mkdir -p "$DST"; umask 077
OUT="$DST/data-$(date +%Y%m%d-%H%M%S).json"
cp "$SRC" "$OUT" && node -e "JSON.parse(require('fs').readFileSync('$OUT','utf8'))" && echo "backup ok: $OUT"
ls -1t "$DST"/data-*.json | tail -n +15 | xargs -r rm -f
