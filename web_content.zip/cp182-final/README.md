# Contractor Pro V18.1 — FINAL (App + Server + Deployment)

- `app/index.html` — the APK-ready app (put `app/` contents in your HTML-to-APK tool; root `index.html` required).
- `server/` — Termux/VPS server 1.2.0 (`node server/server.js`). See `server/` env vars in the previous README notes below.
- `docs/ARCHITECTURE.md` — architecture, sync model, security, limits, roadmap.
- `docs/DEPLOY.md` — go-live guide (VPS + Docker + HTTPS + email codes + APK build).  `docs/RELEASE-CHECKLIST.md` — what is done / what remains.
- `deploy/` — Dockerfile, docker-compose, Caddyfile (auto-HTTPS), systemd unit, backup script, `.env.example`.  `tools/build-app.js` — stamps your server address into the app.

## Quick start (phone only, Termux)
```sh
pkg install nodejs && cd contractor-pro && node server/server.js
```
In the app: Settings > Cloud & Sync > set *Server endpoint* `http://<phone-ip>:8787`, enable sync, **Connect & Sync**.
Dev OTP codes are printed in the Termux console. For internet use put the server behind HTTPS (Android blocks cleartext
to public hosts) and set `CP_JWT_SECRET`, `CP_ADMIN_KEY`, `CP_CORS_ORIGIN`, `CP_TRUST_PROXY=1`.

## Tests
`npm test` (server) · `npm i -D playwright && npx playwright install chromium && npm run test:e2e`

Env: `PORT HOST CP_DATA_FILE CP_JWT_SECRET CP_ADMIN_KEY CP_CORS_ORIGIN CP_PUBLIC_BASE_URL CP_OTP_MODE CP_TRUST_PROXY CP_MAX_BODY_MB CP_SYNC_KEEP CP_OTP_IP_LIMIT CP_OTP_VERIFY_LIMIT`

Production OTP: `CP_OTP_MODE=resend` (`CP_RESEND_API_KEY`, `CP_MAIL_FROM`) or `webhook` (`CP_OTP_WEBHOOK_URL`, `CP_OTP_WEBHOOK_TOKEN`); production refuses `console`.


## V18.2 merge note
- App base: Contractor Pro V18.0 Smart Construction (including AI Drawing → Smart Estimate).
- Server/deployment stack: V18.1 Full Stack.
- Localization dictionary: V18.1 localization block merged with V18.0 Smart Estimate-specific keys.
- V17.5 Master remains untouched.
