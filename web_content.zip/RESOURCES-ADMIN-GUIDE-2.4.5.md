# Resources & Admin quick guide — 2.4.5

## Public Resources page

- `resources.php?tab=tools` lists published creative tools.
- `resources.php?tab=tutorials` lists published learning guides.
- Search and category filters work together.
- Results are paginated at 12 items per page; search and category selections are retained between pages.
- Draft items never appear in the public catalogue.

## Admin management

Open **Admin → Resources**.

### Creative tools
1. Open **+ Add tool**.
2. Enter the name, category, short summary and official HTTPS website.
3. Add platform/download links only when they point to the provider's official page.
4. Add compatibility, system requirements and installation notes as needed.
5. Upload a logo if available.
6. Set Featured if it should be promoted, then choose Draft or Published.
7. Save. Published items become visible in the public Creative Tools directory.

### Tutorials
1. Open **+ Add tutorial**.
2. Add a title, category, short summary and Markdown lesson content.
3. Add numbered steps using one line per step in the format `Step title | Step explanation`.
4. Upload a thumbnail and up to eight screenshots/GIFs per save.
5. Add related tools/tutorials and optional HTTPS video URLs.
6. Save as Draft while preparing, then publish when ready.
7. Use Preview from the admin list to review a draft before publishing.

When editing a tutorial, saved external video URLs are restored in the editor. Saving replaces the existing video-link set, preventing duplicate video entries. Uploaded images/GIFs remain attached unless individually removed.

### Categories
Open **Categories** and expand either Creative Tools or Tutorials. Add categories or update their name, slug, sort order and active state. Disabling a category hides it from public category filters but does not delete its resources.

## History

History is scoped to the signed-in account. Pending Lip Sync and Decart video jobs are checked automatically while the page is open. Completed image/video outputs can be previewed and downloaded. Failed/expired jobs include a link back to their workspace for a new attempt.

## Deployment safety

Preserve `config.local.php`, the live database and the existing `storage/` directory. Resource media is stored privately under `storage/resources/` and served through the authenticated `resource-media.php` endpoint.
