# ViralBoost

**Social Media Growth Tools** – Analytics & content-optimization toolkit for TikTok, YouTube and Instagram.

## Features

- Clean, Google-like search interface for public profile/video URLs
- Content Score, Engagement Potential & Audience Interest estimates
- Hashtag, keyword, caption and title suggestions
- Content improvement tips & call-to-action ideas
- One-click **7-Day Growth Plan** (content calendar, video ideas, hashtags, SEO keywords, captions)
- Local analysis history via browser `localStorage`
- Fully responsive, mobile-first dark theme with purple/blue gradients
- Zero server dependency – everything runs in the browser
- SEO-ready (title, meta description, Open Graph, semantic HTML, FAQ)

## Important Principles

- **Analytics & content optimization only**
- Does **not** increase views, likes, followers or engagement artificially
- No bots, proxies, automated viewing or fake traffic
- Never asks for passwords, cookies, session tokens or account credentials
- Only works with publicly accessible TikTok, YouTube and Instagram URLs

## File Structure

```
ViralBoost/
├── index.html          # Main page (semantic HTML + SEO)
├── style.css           # Dark-mode, mobile-first styles
├── script.js           # Client-side analysis & localStorage history
├── assets/
│   ├── favicon.svg
│   └── og-image.svg
└── README.md
```

## How to Deploy

1. Unzip the package.
2. Upload the entire `ViralBoost` folder to any static host (Netlify, Vercel, GitHub Pages, Cloudflare Pages, S3, etc.).
3. Point your domain to the folder (or open `index.html` locally).

No build step, no backend, no environment variables required.

## Local Testing

Open `index.html` in any modern browser, or serve the folder:

```bash
npx serve .
# or
python -m http.server 8080
```

## Browser Support

Chrome, Firefox, Safari, Edge (latest two versions). Works on Android and iOS browsers.

## License

Free to use and modify for personal or commercial projects. Attribution appreciated but not required.

---

Built for creators who want real growth through better content – not artificial numbers.
