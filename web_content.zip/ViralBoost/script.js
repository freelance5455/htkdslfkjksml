/**
 * ViralBoost – Client-side analytics & content optimization
 * No server calls, no credentials, no fake engagement.
 * All suggestions are generated locally from URL patterns + best-practice templates.
 */

(function () {
  "use strict";

  // ---------- Lock Screen ----------
  const VALID_USER = "577";
  const VALID_PASS = "mahfuj577";
  const LOCK_KEY = "viralboost_unlocked";

  const lockScreen = document.getElementById("lockScreen");
  const appContent = document.getElementById("appContent");
  const lockForm = document.getElementById("lockForm");
  const lockUser = document.getElementById("lockUser");
  const lockPass = document.getElementById("lockPass");
  const lockError = document.getElementById("lockError");

  function isUnlocked() {
    try {
      return sessionStorage.getItem(LOCK_KEY) === "1";
    } catch {
      return false;
    }
  }

  function unlockApp() {
    try {
      sessionStorage.setItem(LOCK_KEY, "1");
    } catch (_) {}
    if (lockScreen) lockScreen.style.display = "none";
    if (appContent) appContent.hidden = false;
  }

  function showLock() {
    if (lockScreen) lockScreen.style.display = "flex";
    if (appContent) appContent.hidden = true;
  }

  if (isUnlocked()) {
    unlockApp();
  } else {
    showLock();
  }

  if (lockForm) {
    lockForm.addEventListener("submit", function (e) {
      e.preventDefault();
      const u = (lockUser.value || "").trim();
      const p = (lockPass.value || "").trim();
      if (u === VALID_USER && p === VALID_PASS) {
        lockError.hidden = true;
        unlockApp();
      } else {
        lockError.hidden = false;
        lockPass.value = "";
        lockPass.focus();
      }
    });
  }

  // ---------- DOM ----------
  const urlInput = document.getElementById("urlInput");
  const analyzeBtn = document.getElementById("analyzeBtn");
  const clearBtn = document.getElementById("clearBtn");
  const searchHint = document.getElementById("searchHint");
  const dashboard = document.getElementById("dashboard");
  const urlDisplay = document.getElementById("urlDisplay");
  const contentScoreEl = document.getElementById("contentScore");
  const engagementRateEl = document.getElementById("engagementRate");
  const interestScoreEl = document.getElementById("interestScore");
  const hashtagList = document.getElementById("hashtagList");
  const keywordList = document.getElementById("keywordList");
  const captionList = document.getElementById("captionList");
  const titleList = document.getElementById("titleList");
  const tipList = document.getElementById("tipList");
  const ctaList = document.getElementById("ctaList");
  const growthPlanBtn = document.getElementById("growthPlanBtn");
  const growthPlan = document.getElementById("growthPlan");
  const planContent = document.getElementById("planContent");
  const newAnalysisBtn = document.getElementById("newAnalysisBtn");
  const historyList = document.getElementById("historyList");
  const clearHistoryBtn = document.getElementById("clearHistoryBtn");
  const menuToggle = document.getElementById("menuToggle");
  const nav = document.querySelector(".nav");

  // ---------- State ----------
  let currentAnalysis = null;

  // ---------- Helpers ----------
  function detectPlatform(url) {
    const u = url.toLowerCase();
    if (u.includes("tiktok.com") || u.includes("vm.tiktok.com")) return "tiktok";
    if (u.includes("youtube.com") || u.includes("youtu.be")) return "youtube";
    if (u.includes("instagram.com") || u.includes("instagr.am")) return "instagram";
    return "unknown";
  }

  function isValidUrl(str) {
    try {
      const u = new URL(str);
      if (!["http:", "https:"].includes(u.protocol)) return false;
      const host = u.hostname.toLowerCase();
      return (
        host.includes("tiktok.com") ||
        host.includes("youtube.com") ||
        host.includes("youtu.be") ||
        host.includes("instagram.com") ||
        host.includes("instagr.am")
      );
    } catch {
      return false;
    }
  }

  function extractHandle(url) {
    try {
      const u = new URL(url);
      const path = u.pathname.replace(/^\/+|\/+$/g, "");
      const parts = path.split("/");
      // @username or username
      for (const p of parts) {
        if (p.startsWith("@")) return p.slice(1);
        if (p && !["video", "reel", "p", "shorts", "watch", "channel", "c", "user"].includes(p.toLowerCase())) {
          return p;
        }
      }
      return "creator";
    } catch {
      return "creator";
    }
  }

  function pseudoRandom(seed, min, max) {
    // Deterministic pseudo-random from string seed (no real metrics)
    let h = 0;
    for (let i = 0; i < seed.length; i++) {
      h = (Math.imul(31, h) + seed.charCodeAt(i)) | 0;
    }
    const n = Math.abs(h % 1000) / 1000;
    return Math.floor(min + n * (max - min + 1));
  }

  // ---------- Content generators (templates only) ----------
  const HASHTAG_POOLS = {
    tiktok: [
      "#fyp", "#foryou", "#viral", "#tiktok", "#trending", "#foryoupage",
      "#learnontiktok", "#tiktoktips", "#contentcreator", "#growth",
      "#motivation", "#lifestyle", "#howto", "#tips", "#storytime",
      "#behindthescenes", "#dayinmylife", "#productivity", "#creativity", "#explore"
    ],
    youtube: [
      "#youtube", "#youtuber", "#subscribe", "#viral", "#trending",
      "#youtubeshorts", "#contentcreator", "#howto", "#tutorial", "#vlog",
      "#review", "#explained", "#tips", "#growth", "#seo",
      "#youtubealgorithm", "#newvideo", "#mustwatch", "#learn", "#creator"
    ],
    instagram: [
      "#instagram", "#instagood", "#reels", "#explore", "#viral",
      "#instadaily", "#photooftheday", "#contentcreator", "#growth",
      "#motivation", "#lifestyle", "#aesthetic", "#inspiration", "#tips",
      "#reelsinstagram", "#explorepage", "#igdaily", "#create", "#community", "#share"
    ],
    unknown: [
      "#content", "#creator", "#growth", "#viral", "#tips",
      "#motivation", "#lifestyle", "#howto", "#trending", "#explore"
    ]
  };

  const KEYWORD_POOLS = {
    tiktok: [
      "tiktok growth tips", "how to go viral on tiktok", "tiktok algorithm 2026",
      "best time to post on tiktok", "tiktok content ideas", "increase tiktok engagement",
      "tiktok hashtag strategy", "short form video tips", "tiktok for beginners", "trending sounds"
    ],
    youtube: [
      "youtube seo tips", "how to rank on youtube", "youtube thumbnail tips",
      "best time to upload youtube", "youtube content ideas", "increase youtube watch time",
      "youtube title formulas", "youtube algorithm 2026", "grow youtube channel", "youtube shorts strategy"
    ],
    instagram: [
      "instagram growth tips", "how to grow on instagram", "instagram reels tips",
      "best time to post instagram", "instagram content ideas", "increase instagram engagement",
      "instagram hashtag strategy", "reels algorithm", "instagram for creators", "story ideas"
    ],
    unknown: [
      "content growth tips", "social media strategy", "how to go viral",
      "best posting times", "engagement tips", "content ideas",
      "hashtag strategy", "caption tips", "audience growth", "creator tips"
    ]
  };

  function generateHashtags(platform, seed) {
    const pool = HASHTAG_POOLS[platform] || HASHTAG_POOLS.unknown;
    const count = 12;
    const selected = [];
    const used = new Set();
    for (let i = 0; i < count; i++) {
      const idx = pseudoRandom(seed + i, 0, pool.length - 1);
      if (!used.has(idx)) {
        used.add(idx);
        selected.push(pool[idx]);
      }
    }
    return selected;
  }

  function generateKeywords(platform, seed) {
    const pool = KEYWORD_POOLS[platform] || KEYWORD_POOLS.unknown;
    return pool.slice(0, 10);
  }

  function generateCaptions(platform, handle) {
    const templates = [
      `Just dropped something new 🔥 What do you think? Drop a comment below!`,
      `This one took me hours… but it was worth it. Save this for later 📌`,
      `If you're struggling with this, you're not alone. Here's what worked for me →`,
      `Quick tip that changed my content game 🚀 Follow for more ${handle ? "@" + handle : ""}`,
      `Which version do you prefer? A or B? Let me know in the comments 👇`,
      `The secret nobody talks about… (watch till the end)`,
      `Day in the life as a creator – real talk, no filter ✨`,
      `Tried this trend so you don't have to. Results surprised me!`
    ];
    return templates.slice(0, 5);
  }

  function generateTitles(platform, handle) {
    const base = handle ? handle : "Creator";
    const titles = [
      `How I Grew My Account in 30 Days (Honest Results)`,
      `The #1 Mistake Most Creators Make (And How to Fix It)`,
      `5 Content Ideas That Actually Get Views`,
      `Why Your Videos Aren't Going Viral (Simple Fix)`,
      `Best Time to Post in 2026 – Data-Backed Guide`,
      `${base}'s Secret Workflow for Consistent Content`,
      `Stop Doing This on ${platform === "youtube" ? "YouTube" : platform === "tiktok" ? "TikTok" : "Instagram"}`,
      `From 0 to Consistent Views – My Exact Strategy`
    ];
    return titles.slice(0, 5);
  }

  function generateTips(platform) {
    const common = [
      "Hook viewers in the first 3 seconds with a strong visual or question.",
      "Keep captions clear and add a single clear call-to-action.",
      "Use trending audio or formats only when they fit your niche.",
      "Post consistently – quality + frequency beats random spikes.",
      "Analyze your own top posts and double down on what already works.",
      "Add text overlays for viewers who watch without sound.",
      "End with a question or prompt to boost comments."
    ];
    const platformSpecific = {
      tiktok: [
        "Use 3–5 relevant hashtags; mix broad and niche.",
        "Duets and stitches can boost reach when done thoughtfully."
      ],
      youtube: [
        "Optimize title + thumbnail + first 15 seconds for click-through and retention.",
        "Include target keywords naturally in title, description and tags."
      ],
      instagram: [
        "Reels still drive the most discovery – prioritize short vertical video.",
        "Use a mix of broad and niche hashtags (5–10 total)."
      ]
    };
    return [...common.slice(0, 4), ...(platformSpecific[platform] || [])].slice(0, 6);
  }

  function generateCTAs() {
    return [
      "Follow for more tips like this ⚡",
      "Save this post so you can come back to it later",
      "Comment your biggest challenge below – I read every one",
      "Share this with a creator friend who needs it",
      "Turn on notifications so you never miss a new video"
    ];
  }

  function generateGrowthPlan(platform, handle) {
    const days = [
      { day: "Day 1", focus: "Hook & Value", idea: "Share a quick tip or myth-busting short that solves one pain point." },
      { day: "Day 2", focus: "Story / Behind-the-scenes", idea: "Show your process or a day-in-the-life clip to build connection." },
      { day: "Day 3", focus: "Trending Format", idea: "Adapt a current trend to your niche – keep it authentic." },
      { day: "Day 4", focus: "Educational Series", idea: "Part 1 of a mini-series (e.g. '3 steps to…')." },
      { day: "Day 5", focus: "Engagement Post", idea: "Ask a question or run a simple poll / this-or-that." },
      { day: "Day 6", focus: "Proof / Results", idea: "Share a before/after, testimonial or personal result." },
      { day: "Day 7", focus: "Community & CTA", idea: "Recap the week + clear call to follow / comment / save." }
    ];

    const videoIdeas = [
      "Myth vs Reality in your niche",
      "3 tools I use every day",
      "What I wish I knew when I started",
      "Quick routine that saves me hours",
      "Responding to common comments / DMs",
      "Behind the scenes of a recent post",
      "Hot take (respectful) on a trending topic",
      "Step-by-step tutorial (under 60s)",
      "Day in my life as a creator",
      "Q&A – answer 3 audience questions"
    ];

    const hashtags = generateHashtags(platform, handle + "plan").slice(0, 20);
    const keywords = generateKeywords(platform, handle + "seo");
    const captions = generateCaptions(platform, handle);

    return { days, videoIdeas, hashtags, keywords, captions };
  }

  // ---------- Analysis ----------
  function runAnalysis(url) {
    const platform = detectPlatform(url);
    const handle = extractHandle(url);
    const seed = url + Date.now().toString().slice(-4);

    // Scores are illustrative only – derived from deterministic pseudo-random for consistency per URL
    const contentScore = pseudoRandom(url, 62, 92);
    const engagementPotential = pseudoRandom(url + "eng", 4, 12) + "%";
    const interestScore = pseudoRandom(url + "int", 58, 88);

    const analysis = {
      url,
      platform,
      handle,
      contentScore,
      engagementPotential,
      interestScore,
      hashtags: generateHashtags(platform, seed),
      keywords: generateKeywords(platform, seed),
      captions: generateCaptions(platform, handle),
      titles: generateTitles(platform, handle),
      tips: generateTips(platform),
      ctas: generateCTAs(),
      timestamp: Date.now()
    };

    currentAnalysis = analysis;
    renderDashboard(analysis);
    saveToHistory(analysis);
    return analysis;
  }

  function renderDashboard(a) {
    dashboard.hidden = false;
    urlDisplay.textContent = a.url;
    contentScoreEl.textContent = a.contentScore;
    engagementRateEl.textContent = a.engagementPotential;
    interestScoreEl.textContent = a.interestScore;

    hashtagList.innerHTML = a.hashtags.map(t => `<span class="tag">${t}</span>`).join("");
    keywordList.innerHTML = a.keywords.map(k => `<span class="tag">${k}</span>`).join("");
    captionList.innerHTML = a.captions.map(c => `<li>${c}</li>`).join("");
    titleList.innerHTML = a.titles.map(t => `<li>${t}</li>`).join("");
    tipList.innerHTML = a.tips.map(t => `<li>${t}</li>`).join("");
    ctaList.innerHTML = a.ctas.map(c => `<li>${c}</li>`).join("");

    growthPlan.hidden = true;
    planContent.innerHTML = "";

    dashboard.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function renderGrowthPlan(plan) {
    let html = "";

    html += `<div class="plan-block"><h4>📅 7-Day Content Plan</h4><ul>`;
    plan.days.forEach(d => {
      html += `<li class="day-item"><span class="day-label">${d.day}</span><span><strong>${d.focus}:</strong> ${d.idea}</span></li>`;
    });
    html += `</ul></div>`;

    html += `<div class="plan-block"><h4>🎥 10 Video Ideas</h4><ul>`;
    plan.videoIdeas.forEach((v, i) => {
      html += `<li>${i + 1}. ${v}</li>`;
    });
    html += `</ul></div>`;

    html += `<div class="plan-block"><h4># 20 Relevant Hashtags</h4><div class="tag-list">`;
    plan.hashtags.forEach(h => {
      html += `<span class="tag">${h}</span>`;
    });
    html += `</div></div>`;

    html += `<div class="plan-block"><h4>🔑 10 SEO Keywords</h4><div class="tag-list">`;
    plan.keywords.forEach(k => {
      html += `<span class="tag">${k}</span>`;
    });
    html += `</div></div>`;

    html += `<div class="plan-block"><h4>✍️ 5 Caption Ideas</h4><ul>`;
    plan.captions.forEach(c => {
      html += `<li>${c}</li>`;
    });
    html += `</ul></div>`;

    planContent.innerHTML = html;
    growthPlan.hidden = false;
    growthPlan.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  // ---------- History (localStorage) ----------
  const HISTORY_KEY = "viralboost_history";
  const MAX_HISTORY = 15;

  function getHistory() {
    try {
      return JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]");
    } catch {
      return [];
    }
  }

  function saveToHistory(analysis) {
    let hist = getHistory();
    // Avoid exact duplicates of the same URL at the top
    hist = hist.filter(h => h.url !== analysis.url);
    hist.unshift({
      url: analysis.url,
      platform: analysis.platform,
      contentScore: analysis.contentScore,
      timestamp: analysis.timestamp
    });
    if (hist.length > MAX_HISTORY) hist = hist.slice(0, MAX_HISTORY);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(hist));
    renderHistory();
  }

  function renderHistory() {
    const hist = getHistory();
    if (hist.length === 0) {
      historyList.innerHTML = `<p class="empty-history">No analyses yet. Paste a URL above to get started.</p>`;
      return;
    }
    historyList.innerHTML = hist.map(h => {
      const date = new Date(h.timestamp).toLocaleString(undefined, {
        month: "short", day: "numeric", hour: "2-digit", minute: "2-digit"
      });
      return `
        <div class="history-item" data-url="${escapeAttr(h.url)}">
          <span class="url">${escapeHtml(h.url)}</span>
          <span class="date">${date} · Score ${h.contentScore}</span>
        </div>`;
    }).join("");

    historyList.querySelectorAll(".history-item").forEach(item => {
      item.addEventListener("click", () => {
        const url = item.dataset.url;
        urlInput.value = url;
        clearBtn.hidden = false;
        performAnalysis(url);
      });
    });
  }

  function clearHistory() {
    localStorage.removeItem(HISTORY_KEY);
    renderHistory();
  }

  function escapeHtml(str) {
    return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  function escapeAttr(str) {
    return str.replace(/"/g, "&quot;");
  }

  // ---------- UI actions ----------
  function setLoading(btn, loading) {
    const text = btn.querySelector(".btn-text");
    const loader = btn.querySelector(".btn-loader");
    btn.disabled = loading;
    if (text) text.hidden = loading;
    if (loader) loader.hidden = !loading;
  }

  function showHint(msg, isError = false) {
    searchHint.textContent = msg;
    searchHint.classList.toggle("error", isError);
  }

  function performAnalysis(url) {
    if (!isValidUrl(url)) {
      showHint("Please enter a valid public TikTok, YouTube or Instagram URL.", true);
      return;
    }
    showHint("Supports public TikTok, YouTube and Instagram links only.");
    setLoading(analyzeBtn, true);

    // Simulate brief processing (client-side only)
    setTimeout(() => {
      runAnalysis(url);
      setLoading(analyzeBtn, false);
    }, 600);
  }

  // ---------- Events ----------
  analyzeBtn.addEventListener("click", () => {
    const url = urlInput.value.trim();
    if (!url) {
      showHint("Please paste a profile or video URL first.", true);
      urlInput.focus();
      return;
    }
    performAnalysis(url);
  });

  urlInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      analyzeBtn.click();
    }
  });

  urlInput.addEventListener("input", () => {
    clearBtn.hidden = !urlInput.value;
    showHint("Supports public TikTok, YouTube and Instagram links only.");
  });

  clearBtn.addEventListener("click", () => {
    urlInput.value = "";
    clearBtn.hidden = true;
    urlInput.focus();
  });

  growthPlanBtn.addEventListener("click", () => {
    if (!currentAnalysis) return;
    setLoading(growthPlanBtn, true);
    setTimeout(() => {
      const plan = generateGrowthPlan(currentAnalysis.platform, currentAnalysis.handle);
      renderGrowthPlan(plan);
      setLoading(growthPlanBtn, false);
    }, 500);
  });

  newAnalysisBtn.addEventListener("click", () => {
    dashboard.hidden = true;
    urlInput.value = "";
    clearBtn.hidden = true;
    currentAnalysis = null;
    window.scrollTo({ top: 0, behavior: "smooth" });
    urlInput.focus();
  });

  clearHistoryBtn.addEventListener("click", () => {
    if (confirm("Clear all local analysis history?")) {
      clearHistory();
    }
  });

  // Mobile menu
  menuToggle.addEventListener("click", () => {
    nav.classList.toggle("open");
  });

  // Close mobile menu on link click
  nav.querySelectorAll("a").forEach(a => {
    a.addEventListener("click", () => nav.classList.remove("open"));
  });

  // Tool cards → focus search
  document.querySelectorAll(".tool-card").forEach(card => {
    card.addEventListener("click", () => {
      urlInput.focus();
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  });

  // Init
  renderHistory();
})();
