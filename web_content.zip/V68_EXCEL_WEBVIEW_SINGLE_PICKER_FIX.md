# V68 Excel WebView Single Picker Fix

Built from V67. The Excel import flow now uses one picker mechanism only: the real HTML `<input type=file>` is opened by the Choose File button, Android WebView receives it through `onShowFileChooser`, and the selected URI is returned to the WebView callback. The competing AndroidDPM native picker/result path is no longer used by the button. This avoids callback races that can leave DocumentsUI open on some TECNO/Android builds. Version 2.34 / versionCode 38.
