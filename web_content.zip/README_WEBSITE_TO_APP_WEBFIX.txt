CARD SCHOOL PRO V16 — WEBSITE TO APP / WEBVIEW FIX

This archive contains the same project at the archive root and under /web/.
The duplicate /web/ copy is intentional: some Android Website-to-App builders
load the packaged page as https://appassets.androidplatform.net/web/index.html.

Use the ZIP import option. Do not upload the README as the entry page.
The main entry point is index.html.

All local project paths are relative.
