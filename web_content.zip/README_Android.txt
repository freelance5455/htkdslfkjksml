GB STUDY — Android-friendly standalone build

1. Extract this ZIP.
2. Open GB_STUDY_Standalone.html in Chrome.
3. This standalone file has CSS, JavaScript, and the GB STUDY logo embedded, so relative CSS/image paths will not break.
4. If Chrome or a file viewer blocks scripts when opened from content://, upload the file to a static host (for example Netlify) and open the hosted HTTPS URL.
5. Demo admin password: ChangeMe123! Change it before sharing. This is a front-end demo only; it is not secure for public production use and changes are stored locally in the browser.
6. External links/banner links and platform URLs should be checked and configured by you.


Size optimization: embedded logo images were converted to high-quality WebP with transparency retained to reduce ZIP size. The app features and HTML/CSS/JS logic are unchanged.


Update: Admin platform icons now support either an uploaded photo or a direct image URL. Platform cards are narrower/shorter on mobile.
