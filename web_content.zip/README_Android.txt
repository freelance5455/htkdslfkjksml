Irfan Baloch Mobile Repair Shop — Android WebView package

1. Extract ZIP and select index.html as the app's start page.
2. If using Android Studio, place index.html and royal_logo.png in app/src/main/assets/
3. Load with WebViewAssetLoader at https://appassets.androidplatform.net/assets/index.html
   (recommended for secure local storage and browser APIs).
4. Enable JavaScript and DOM storage in WebView settings.
5. Enable file chooser/camera support in WebChromeClient for device photos.
6. WhatsApp PDF sharing needs Android native share integration (FileProvider + ACTION_SEND).
   A simple HTML-to-APK builder may not provide this.
7. Print/PDF functionality also needs WebView print support or native Android integration.
8. Data is stored locally in IndexedDB; uninstalling or clearing app data may delete records.
   Export JSON backups regularly.
9. This ZIP is web assets, not an installable APK.
