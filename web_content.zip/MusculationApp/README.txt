الطريقة 1 (بدون حاسوب - GitHub):
1) أنشئ مستودعًا جديدًا على github.com وارفع كل محتوى هذا المجلد (بما فيه مجلد .github).
2) تبويب Actions > Build APK > Run workflow.
3) بعد دقائق: افتح التشغيلة > Artifacts > musculation-apk > حمّل app-debug.apk وثبّته.

الطريقة 2 (Android Studio):
File > Open > اختر هذا المجلد > انتظر Sync > Build > Build APK(s).
الملف: app/build/outputs/apk/debug/app-debug.apk

الحد الأدنى: Android 10. لتعديل التطبيق عدّل app/src/main/assets/index.html.
