const fs = require('fs');
['index.html', 'login.html', 'otp.html'].forEach(file => {
    if (!fs.existsSync(file)) return;
    let html = fs.readFileSync(file, 'utf8');
    // Purana redirect hatao
    html = html.replace(/<script>if\(location\.protocol==="file:"\)[^<]*<\/script>/g, '');
    // Naya redirect
    const redirect = '<script>if(location.protocol==="file:"){location.replace("http://localhost:3102/user/' + file + '");}<\/script>\n';
    const headIdx = html.indexOf('<head>');
    if (headIdx !== -1) {
        const headEnd = headIdx + 6;
        html = html.slice(0, headEnd) + '\n' + redirect + html.slice(headEnd);
    }
    // API URL update
    html = html.replace(/http:\/\/localhost:\d+/g, 'http://localhost:3102');
    html = html.replace(/http:\/\/127\.0\.0\.1:\d+/g, 'http://localhost:3102');
    fs.writeFileSync(file, html);
    console.log('✅ ' + file + ' connected');
});
