const fs = require('fs');
let h = fs.readFileSync('about.html', 'utf8');

// Purana openLink function dhundo aur usko naye se replace karo
const oldFnRegex = /function openLink\(type\) \{[\s\S]*?\n\}/;

const newFn = `function openLink(type) {
    var url = socialLinks[type] || '';
    
    if (!url || url === '#') {
        alert('Link not set by Admin yet.');
        return;
    }

    if (type === 'instagram') {
        // Username nikaalo link se
        var username = "miss.aadiwashi.750";
        var match = url.match(/instagram\\.com\\/([^\\/?]+)/);
        if (match && match[1] && match[1] !== 'invites') {
            username = match[1];
        }
        
        // Android Intent use karo taaki seedha Instagram App khule
        var appUrl = 'instagram://user?username=' + username;
        var webUrl = 'https://www.instagram.com/' + username;
        
        // Pehle app kholne ki koshish karo
        var now = new Date().getTime();
        window.location.href = appUrl;
        
        // Agar 1.5 second me app nahi khula, toh browser me kholo
        setTimeout(function() {
            if (new Date().getTime() - now < 2000) {
                window.location.href = webUrl;
            }
        }, 1500);
        
        return;
    }

    // Baaki social links ke liye normal open karo
    window.open(url, '_blank');
}`;

h = h.replace(oldFnRegex, newFn);
fs.writeFileSync('about.html', h);
console.log('✅ Instagram link ab seedha App me khulega!');
