const fs = require('fs');
let h = fs.readFileSync('add-friend.html', 'utf8');

// Purana ID generation logic hatao
const oldJS = `
const myUserId = localStorage.getItem('iba_userId');
const myMobile = localStorage.getItem('iba_mobile') || '';
const myIbaId = 'IBA' + myMobile.slice(-6);
const myName = localStorage.getItem('iba_name') || 'Player';
`;

const newJS = `
const myUserId = localStorage.getItem('iba_userId');
const myName = localStorage.getItem('iba_name') || 'Player';
let myIbaId = 'IBA000000';

// Server se meri profile fetch karke IBA ID dikhao
async function loadMyId() {
    try {
        const res = await fetch(SERVER + '/api/user/profile/' + myUserId);
        const data = await res.json();
        if(data.success && data.profile) {
            const p = data.profile;
            // Agar accountId saved hai toh wo dikhao, warna mobile se generate karo
            if(p.accountId) {
                myIbaId = p.accountId;
            } else if(p.mobile) {
                myIbaId = 'IBA' + p.mobile.slice(-6);
            } else if(myUserId) {
                myIbaId = myUserId.replace('user_', 'IBA');
            }
            document.getElementById('myId').textContent = myIbaId;
        }
    } catch(e) {
        console.log('Error loading ID');
        // Fallback: userId se banao
        if(myUserId) {
            myIbaId = myUserId.replace('user_', 'IBA');
            document.getElementById('myId').textContent = myIbaId;
        }
    }
}
loadMyId();
`;

h = h.replace(oldJS, newJS);

// Purana "document.getElementById('myId').textContent = myIbaId;" hatao
h = h.replace("// Display my ID\ndocument.getElementById('myId').textContent = myIbaId;", "// My ID is loaded by loadMyId()");

fs.writeFileSync('add-friend.html', h);
console.log('✅ My ID fetch logic updated!');
