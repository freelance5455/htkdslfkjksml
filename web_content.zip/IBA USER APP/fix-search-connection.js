const fs = require('fs');
let h = fs.readFileSync('add-friend.html', 'utf8');

// Check karo agar SERVER variable sahi hai
if (!h.includes('const SERVER =')) {
    // Agar SERVER nahi hai, toh script ke shuru me add karo
    h = h.replace(
        "const myUserId =",
        "const SERVER = 'http://localhost:3102';\nconst myUserId ="
    );
}

// Search function me try-catch ke andar log add karo
h = h.replace(
    "result.innerHTML = '<div class=\"empty-state\"><div class=\"icon\">⏳</div><p>Searching...</p></div>';",
    "result.innerHTML = '<div class=\"empty-state\"><div class=\"icon\">⏳</div><p>Searching...</p></div>';\n        console.log('Fetching:', SERVER + '/api/find-user/' + input);"
);

fs.writeFileSync('add-friend.html', h);
console.log('✅ Search connection debug added!');
