const fs = require('fs');
let h = fs.readFileSync('edit-profile.html', 'utf8');

// 1. HTML me OTP input ke niche "Resend" button add karo
const oldOTPBox = `<div id="nameOtpBox" style="display:none; margin-top:12px;">
            <input type="number" class="nm-input" id="nameOtpInput" placeholder="Enter OTP" maxlength="6">
            <button class="nm-btn green" onclick="verifyNameOtp()">Verify & Update Name</button>
        </div>`;

const newOTPBox = `<div id="nameOtpBox" style="display:none; margin-top:12px;">
            <input type="number" class="nm-input" id="nameOtpInput" placeholder="Enter OTP" maxlength="6">
            <button class="nm-btn green" onclick="verifyNameOtp()">Verify & Update Name</button>
            
            <!-- RESEND OTP -->
            <div style="text-align:center; margin-top:12px; font-size:12px; color:#8a9bb8;">
                Didn't receive? <span id="resendNameBtn" onclick="resendNameOtp()" style="color:#ffc419; font-weight:700; cursor:pointer; text-decoration:underline;">Resend OTP</span>
                <span id="resendNameTimer" style="color:#5a6a85;"></span>
            </div>
        </div>`;

h = h.replace(oldOTPBox, newOTPBox);

// 2. JS me Resend function add karo
const resendJS = `
// RESEND NAME OTP
var resendTimer = null;

function startResendTimer() {
    var countdown = 30;
    var timerEl = document.getElementById('resendNameTimer');
    var btnEl = document.getElementById('resendNameBtn');
    
    if(!timerEl || !btnEl) return;
    
    clearInterval(resendTimer);
    btnEl.style.display = 'none';
    timerEl.textContent = '(Wait ' + countdown + 's)';
    
    resendTimer = setInterval(function() {
        countdown--;
        if(countdown <= 0) {
            clearInterval(resendTimer);
            timerEl.textContent = '';
            btnEl.style.display = 'inline';
        } else {
            timerEl.textContent = '(Wait ' + countdown + 's)';
        }
    }, 1000);
}

async function resendNameOtp() {
    var mobile = localStorage.getItem('iba_mobile');
    if(!mobile) return nmMsg('Mobile not found', 'error');
    
    nmMsg('Sending new OTP...', 'success');
    
    try {
        const res = await fetch(SERVER + '/api/user-auth/request-otp', {
            method: 'POST', headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ mobile })
        });
        const data = await res.json();
        
        if(data.success) {
            nmMsg('New OTP sent! Check Termux.', 'success');
            document.getElementById('nameOtpInput').value = '';
            startResendTimer();
        } else {
            nmMsg(data.error || 'Failed to resend', 'error');
        }
    } catch(e) {
        nmMsg('Server error', 'error');
    }
}
`;

h = h.replace('// NAME CHANGE LOGIC', '// NAME CHANGE LOGIC\n' + resendJS);

// 3. Jab pehli baar OTP send ho, toh timer start ho
h = h.replace(
    "document.getElementById('sendNameBtn').style.display = 'none';\n        } else {",
    "document.getElementById('sendNameBtn').style.display = 'none';\n            startResendTimer();\n        } else {"
);

fs.writeFileSync('edit-profile.html', h);
console.log('✅ Resend OTP option added!');
