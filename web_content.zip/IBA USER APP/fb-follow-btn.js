const fs = require('fs');
let h = fs.readFileSync('about.html', 'utf8');

// Facebook wale button ka text "LIKE" se "FOLLOW" karo
h = h.replace(
    '<button class="social-action-btn btn-facebook">LIKE</button>',
    '<button class="social-action-btn btn-facebook">FOLLOW</button>'
);

// Agar description bhi badalna hai toh "Like our page" -> "Follow our page"
h = h.replace(
    '<div class="social-sub">Like our page</div>',
    '<div class="social-sub">Follow our page</div>'
);

fs.writeFileSync('about.html', h);
console.log('✅ Facebook button changed to FOLLOW!');
