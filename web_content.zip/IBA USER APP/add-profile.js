const fs = require('fs');
let h = fs.readFileSync('dashboard.html', 'utf8');

if (h.includes('profilePage')) {
    console.log('already exists');
    process.exit(0);
}

// ===== PROFILE PAGE CSS =====
const profileCSS = `
.profile-page{position:fixed;inset:0;z-index:1000;background:linear-gradient(180deg,#050b1f 0%,#0a0f2e 50%,#050b1f 100%);transform:translateX(100%);transition:transform .4s cubic-bezier(.4,0,.2,1);overflow-y:auto;padding-bottom:90px}
.profile-page.show{transform:translateX(0)}
.profile-page::before{content:"";position:fixed;top:0;left:0;right:0;height:400px;background:radial-gradient(circle at 50% 0%,rgba(0,150,255,.25),transparent 60%);pointer-events:none}
.profile-header{position:sticky;top:0;z-index:10;display:flex;align-items:center;gap:14px;padding:16px 18px;background:rgba(5,11,31,.95);border-bottom:1px solid rgba(0,150,255,.15);backdrop-filter:blur(12px)}
.profile-back{width:42px;height:42px;border-radius:50%;background:rgba(0,150,255,.1);border:1px solid rgba(0,150,255,.3);color:#00a8ff;font-size:20px;cursor:pointer;display:grid;place-items:center;transition:.2s}
.profile-back:active{transform:scale(.9)}
.profile-title{font-size:22px;font-weight:900;letter-spacing:1px;color:#fff}

/* ===== 5D AVATAR ===== */
.profile-hero{position:relative;padding:30px 20px 20px;text-align:center;perspective:1000px}
.avatar-3d{position:relative;width:130px;height:130px;margin:0 auto 20px;transform-style:preserve-3d;animation:avatarFloat 4s ease-in-out infinite}
@keyframes avatarFloat{0%,100%{transform:translateY(0) rotateY(0deg)}50%{transform:translateY(-8px) rotateY(5deg)}}
.avatar-ring{position:absolute;inset:-8px;border-radius:50%;border:3px solid transparent;border-top-color:#0088ff;border-right-color:#00d4ff;animation:ringSpin 3s linear infinite}
.avatar-ring2{position:absolute;inset:-16px;border-radius:50%;border:2px solid transparent;border-bottom-color:#00a8ff;border-left-color:#00d4ff;animation:ringSpin 4s linear infinite reverse}
@keyframes ringSpin{to{transform:rotate(360deg)}}
.avatar-main{width:130px;height:130px;border-radius:50%;background:linear-gradient(135deg,#0088ff,#00d4ff);display:grid;place-items:center;font-size:48px;font-weight:900;color:#fff;border:4px solid #050b1f;box-shadow:0 0 30px rgba(0,150,255,.6),0 0 60px rgba(0,150,255,.3),inset 0 0 20px rgba(255,255,255,.2);overflow:hidden;position:relative;z-index:2}
.avatar-main img{width:100%;height:100%;object-fit:cover}
.avatar-glow{position:absolute;inset:-20px;border-radius:50%;background:radial-gradient(circle,rgba(0,150,255,.4),transparent 70%);animation:glowPulse 2s ease-in-out infinite}
@keyframes glowPulse{0%,100%{opacity:.5;transform:scale(1)}50%{opacity:1;transform:scale(1.1)}}

.profile-name{font-size:24px;font-weight:900;letter-spacing:.5px;color:#fff;margin-bottom:6px}
.profile-id-row{display:flex;align-items:center;justify-content:center;gap:8px;margin-bottom:14px}
.profile-id{font-size:13px;color:#6b8bb8;letter-spacing:1px;font-weight:600}
.verified-pill{display:inline-flex;align-items:center;gap:4px;background:rgba(0,200,83,.15);color:#00e676;border:1px solid rgba(0,200,83,.4);font-size:10px;font-weight:700;padding:3px 10px;border-radius:20px;letter-spacing:.5px}

/* ===== STATS ROW (5D) ===== */
.stats-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;padding:0 16px;margin-bottom:18px;max-width:520px;margin-left:auto;margin-right:auto}
.stat-3d{position:relative;background:linear-gradient(135deg,rgba(10,25,55,.8),rgba(5,11,31,.95));border:1px solid rgba(0,150,255,.25);border-radius:16px;padding:16px 10px;text-align:center;transition:.3s;overflow:hidden}
.stat-3d::before{content:"";position:absolute;top:0;left:-100%;width:100%;height:100%;background:linear-gradient(90deg,transparent,rgba(0,180,255,.1),transparent);animation:statShine 3s infinite}
@keyframes statShine{to{left:100%}}
.stat-3d:active{transform:translateY(-4px) scale(1.02);border-color:rgba(0,180,255,.6);box-shadow:0 10px 25px rgba(0,150,255,.3)}
.stat-ico{font-size:22px;margin-bottom:6px;display:block;filter:drop-shadow(0 0 8px rgba(0,150,255,.5))}
.stat-val{font-size:20px;font-weight:900;color:#fff;letter-spacing:-.5px;margin-bottom:3px}
.stat-val.blue{color:#00a8ff}
.stat-val.green{color:#00e676}
.stat-lbl{font-size:9px;color:#6b8bb8;letter-spacing:1.5px;font-weight:700;text-transform:uppercase}

/* ===== INFO CARD (5D) ===== */
.info-section{padding:0 16px;max-width:520px;margin:0 auto 18px}
.info-title{font-size:14px;font-weight:800;color:#a8bddc;letter-spacing:1px;text-transform:uppercase;margin-bottom:12px;padding-left:4px;display:flex;align-items:center;gap:8px}
.info-title::before{content:"";width:3px;height:16px;background:linear-gradient(180deg,#0088ff,#00d4ff);border-radius:2px}
.info-card{background:linear-gradient(135deg,rgba(10,25,55,.7),rgba(5,11,31,.9));border:1px solid rgba(0,150,255,.2);border-radius:16px;overflow:hidden;position:relative}
.info-card::before{content:"";position:absolute;top:0;left:20px;right:20px;height:1px;background:linear-gradient(90deg,transparent,rgba(0,180,255,.5),transparent)}
.info-row{display:flex;align-items:center;gap:14px;padding:16px 18px;border-bottom:1px solid rgba(0,150,255,.1);transition:.2s}
.info-row:last-child{border-bottom:none}
.info-row:active{background:rgba(0,150,255,.08)}
.info-icon{width:40px;height:40px;border-radius:12px;display:grid;place-items:center;font-size:18px;flex-shrink:0;background:linear-gradient(135deg,rgba(0,136,255,.2),rgba(0,212,255,.1));border:1px solid rgba(0,150,255,.3);box-shadow:0 0 12px rgba(0,150,255,.15)}
.info-text{flex:1;min-width:0}
.info-label{font-size:10px;color:#6b8bb8;letter-spacing:1.5px;font-weight:700;text-transform:uppercase;margin-bottom:3px}
.info-value{font-size:14px;color:#fff;font-weight:600;letter-spacing:.3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.info-value.mono{font-family:'Courier New',monospace;font-size:13px}

/* ===== ACTION BUTTONS ===== */
.action-section{padding:0 16px;max-width:520px;margin:0 auto 30px}
.action-btn-3d{position:relative;display:flex;align-items:center;gap:14px;width:100%;padding:16px 20px;margin-bottom:10px;background:linear-gradient(135deg,rgba(0,136,255,.15),rgba(0,212,255,.08));border:1px solid rgba(0,150,255,.3);border-radius:16px;color:#fff;font-size:15px;font-weight:700;letter-spacing:.3px;cursor:pointer;overflow:hidden;transition:.3s;text-align:left}
.action-btn-3d::before{content:"";position:absolute;top:0;left:-100%;width:100%;height:100%;background:linear-gradient(90deg,transparent,rgba(0,180,255,.15),transparent);transition:left .6s}
.action-btn-3d:active{transform:translateY(-2px);border-color:rgba(0,180,255,.6);box-shadow:0 8px 25px rgba(0,150,255,.3)}
.action-btn-3d:active::before{left:100%}
.action-btn-3d .ab-ico{width:40px;height:40px;border-radius:12px;background:linear-gradient(135deg,#0088ff,#00a8ff);display:grid;place-items:center;font-size:18px;flex-shrink:0;box-shadow:0 4px 12px rgba(0,150,255,.4)}
.action-btn-3d.logout-btn{background:linear-gradient(135deg,rgba(255,50,50,.12),rgba(5,11,31,.9));border-color:rgba(255,60,60,.3)}
.action-btn-3d.logout-btn .ab-ico{background:linear-gradient(135deg,#ff3b3b,#ff5555);box-shadow:0 4px 12px rgba(255,59,59,.4)}
.action-btn-3d.logout-btn:active{border-color:rgba(255,80,80,.6);box-shadow:0 8px 25px rgba(255,60,60,.3)}
.action-arrow{margin-left:auto;color:#5a7ba8;font-size:18px;transition:.3s}
.action-btn-3d:active .action-arrow{color:#00a8ff;transform:translateX(4px)}

/* Footer */
.profile-footer{text-align:center;padding:20px;font-size:11px;color:#3d4a66;letter-spacing:1px}
.profile-footer b{color:#00a8ff}
`;

h = h.replace('</style>', profileCSS + '\n</style>');

// ===== PROFILE PAGE HTML =====
const profileHTML = `
<div class="profile-page" id="profilePage">
    <div class="profile-header">
        <button class="profile-back" onclick="closeProfile()">‹</button>
        <div class="profile-title">Profile</div>
    </div>

    <div class="profile-hero">
        <div class="avatar-3d">
            <div class="avatar-glow"></div>
            <div class="avatar-ring"></div>
            <div class="avatar-ring2"></div>
            <div class="avatar-main" id="profileAvatar">P</div>
        </div>
        <div class="profile-name" id="profileName">Player</div>
        <div class="profile-id-row">
            <div class="profile-id" id="profileId">IBA0000000</div>
            <div class="verified-pill">✓ VERIFIED</div>
        </div>
    </div>

    <div class="stats-grid">
        <div class="stat-3d">
            <span class="stat-ico">🏆</span>
            <div class="stat-val blue" id="statMatches">0</div>
            <div class="stat-lbl">Matches</div>
        </div>
        <div class="stat-3d">
            <span class="stat-ico">🥇</span>
            <div class="stat-val green" id="statWins">0</div>
            <div class="stat-lbl">Wins</div>
        </div>
        <div class="stat-3d">
            <span class="stat-ico">💰</span>
            <div class="stat-val" id="statBalance">₹0</div>
            <div class="stat-lbl">Balance</div>
        </div>
    </div>

    <div class="info-section">
        <div class="info-title">Account Details</div>
        <div class="info-card">
            <div class="info-row">
                <div class="info-icon">📱</div>
                <div class="info-text">
                    <div class="info-label">Mobile Number</div>
                    <div class="info-value mono" id="infoMobile">+91 XXXXXXXXXX</div>
                </div>
            </div>
            <div class="info-row">
                <div class="info-icon">📧</div>
                <div class="info-text">
                    <div class="info-label">Gmail</div>
                    <div class="info-value" id="infoEmail">Not set</div>
                </div>
            </div>
            <div class="info-row">
                <div class="info-icon">🎂</div>
                <div class="info-text">
                    <div class="info-label">Date of Birth</div>
                    <div class="info-value" id="infoDob">Not set</div>
                </div>
            </div>
            <div class="info-row">
                <div class="info-icon">📅</div>
                <div class="info-text">
                    <div class="info-label">Joined On</div>
                    <div class="info-value" id="infoJoined">-</div>
                </div>
            </div>
        </div>
    </div>

    <div class="action-section">
        <button class="action-btn-3d" onclick="editProfile()">
            <div class="ab-ico">✏️</div>
            Edit Profile
            <span class="action-arrow">›</span>
        </button>
        <button class="action-btn-3d" onclick="comingSoon('Change Password')">
            <div class="ab-ico">🔒</div>
            Change Password
            <span class="action-arrow">›</span>
        </button>
        <button class="action-btn-3d" onclick="comingSoon('Notifications')">
            <div class="ab-ico">🔔</div>
            Notifications
            <span class="action-arrow">›</span>
        </button>
        <button class="action-btn-3d logout-btn" onclick="confirmLogout()">
            <div class="ab-ico">🚪</div>
            Logout
            <span class="action-arrow">›</span>
        </button>
    </div>

    <div class="profile-footer">Made with <span style="color:#ff4466">♥</span> by <b>IBA</b></div>
</div>
`;

h = h.replace('</body>', profileHTML + '\n</body>');

// ===== JS =====
const profileJS = `
function openProfile(){
    loadProfileData();
    document.getElementById('profilePage').classList.add('show');
    document.body.style.overflow = 'hidden';
}
function closeProfile(){
    document.getElementById('profilePage').classList.remove('show');
    document.body.style.overflow = '';
}

async function loadProfileData(){
    const userId = localStorage.getItem('iba_userId');
    const mobile = localStorage.getItem('iba_mobile') || '';
    const name = localStorage.getItem('iba_name') || 'Player';
    const photo = localStorage.getItem('iba_photo') || '';

    // Basic info
    document.getElementById('profileName').textContent = name;
    document.getElementById('profileId').textContent = userId ? userId.replace('user_','IBA') : 'IBA0000000';
    document.getElementById('infoMobile').textContent = '+91 ' + mobile;

    // Avatar
    const av = document.getElementById('profileAvatar');
    if(photo){
        av.innerHTML = '<img src="' + photo + '" alt="">';
    } else {
        av.textContent = name.charAt(0).toUpperCase();
    }

    // Server se profile fetch karo
    try{
        const r = await fetch('http://localhost:3102/api/user/profile/' + userId);
        const d = await r.json();
        if(d.success && d.profile){
            const p = d.profile;
            document.getElementById('profileName').textContent = p.name || name;
            if(p.photo){
                av.innerHTML = '<img src="' + p.photo + '" alt="">';
            }
            document.getElementById('infoEmail').textContent = p.email || 'Not set';
            document.getElementById('infoDob').textContent = p.dob ? formatDob(p.dob) : 'Not set';
            document.getElementById('infoJoined').textContent = p.joined ? formatDate(p.joined) : '-';
            document.getElementById('statBalance').textContent = '₹' + (p.balance || 0);
            document.getElementById('statMatches').textContent = (p.matches || []).length;
            document.getElementById('statWins').textContent = (p.wins || 0);
        }
    }catch(e){
        console.log('Profile load failed');
    }
}

function formatDob(dob){
    try{
        const d = new Date(dob);
        const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
        return d.getDate() + ' ' + months[d.getMonth()] + ' ' + d.getFullYear();
    }catch(e){ return dob; }
}
function formatDate(iso){
    try{
        const d = new Date(iso);
        const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
        return d.getDate() + ' ' + months[d.getMonth()] + ' ' + d.getFullYear();
    }catch(e){ return iso; }
}

function editProfile(){
    comingSoon('Edit Profile');
}

window.addEventListener('popstate', function(){
    if(document.getElementById('profilePage').classList.contains('show')){
        closeProfile();
    } else if(document.getElementById('morePage') && document.getElementById('morePage').classList.contains('show')){
        closeMore();
    }
});
`;

const lastScriptIdx2 = h.lastIndexOf('</script>');
h = h.slice(0, lastScriptIdx2) + profileJS + '\n' + h.slice(lastScriptIdx2);

// More page me Profile item update karo
h = h.replace(
    `onclick="moreAction('Profile')"`,
    `onclick="closeMore();setTimeout(openProfile,400)"`
);

// Dashboard me Profile button bhi update karo
h = h.replace(
    `onclick="comingSoon('Profile')"`,
    `onclick="openProfile()"`
);

fs.writeFileSync('dashboard.html', h);
console.log('✅ Profile page added!');
