const fs = require('fs');
let h = fs.readFileSync('settings.html', 'utf8');

// 1. Profile card me photo dikhane ka logic add karo
// Purana JS dhundo jahan profile load hoti hai
const oldProfileJS = `document.getElementById('profileName').textContent = userName;
document.getElementById('settingMobile').textContent = '+91 ' + userMobile;
document.getElementById('profileUid').textContent = 'UID: ' + (userId ? userId.replace('user_', '') : '00000000');
document.getElementById('profileEmail').textContent = userName.toLowerCase().replace(/\\s/g,'') + '@iba.com';

const av = document.getElementById('profileAvatar');
if(userPhoto) {
    av.innerHTML = '<img src="' + userPhoto + '">';
} else {
    av.textContent = userName.charAt(0).toUpperCase();
}`;

const newProfileJS = `document.getElementById('profileName').textContent = userName;
document.getElementById('settingMobile').textContent = '+91 ' + userMobile;
document.getElementById('profileUid').textContent = 'UID: ' + (userId ? userId.replace('user_', '') : '00000000');
document.getElementById('profileEmail').textContent = userName.toLowerCase().replace(/\\s/g,'') + '@iba.com';

// Photo load karo (server se latest)
const av = document.getElementById('profileAvatar');
const localPhoto = localStorage.getItem('iba_photo') || '';

if (localPhoto) {
    av.innerHTML = '<img src="' + localPhoto + '" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">';
} else {
    av.textContent = userName.charAt(0).toUpperCase();
}

// Server se latest photo fetch karo
async function fetchLatestPhoto() {
    try {
        const res = await fetch('http://localhost:3102/api/user/profile/' + userId);
        const data = await res.json();
        if(data.success && data.profile && data.profile.photo) {
            av.innerHTML = '<img src="' + data.profile.photo + '" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">';
            localStorage.setItem('iba_photo', data.profile.photo);
        }
    } catch(e) {}
}
if(userId) fetchLatestPhoto();`;

if (h.includes(oldProfileJS)) {
    h = h.replace(oldProfileJS, newProfileJS);
    console.log('✅ Settings photo logic updated!');
} else {
    // Agar exact match na mile toh fallback
    h = h.replace(
        "const av = document.getElementById('profileAvatar');",
        "const av = document.getElementById('profileAvatar');\nconst localPhoto = localStorage.getItem('iba_photo') || '';"
    );
    console.log('⚠️ Fallback used');
}

fs.writeFileSync('settings.html', h);
