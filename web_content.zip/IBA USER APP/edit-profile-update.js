const fs = require('fs');
let h = fs.readFileSync('edit-profile.html', 'utf8');

// 1. Gmail ko disabled se hatakar "Change" button lagao
const oldEmailHTML = `<div class="input-wrapper">
            <div class="input-icon">📧</div>
            <input type="email" class="form-input" id="emailInput" placeholder="yourname@gmail.com" disabled>
        </div>`;
const newEmailHTML = `<div class="input-wrapper" style="position:relative;">
            <div class="input-icon">📧</div>
            <input type="email" class="form-input" id="emailInput" placeholder="yourname@gmail.com" readonly style="padding-right:80px;">
            <button type="button" onclick="openGmailChange()" style="position:absolute; right:8px; top:50%; transform:translateY(-50%); background:rgba(255,195,25,0.15); color:#ffc419; border:1px solid rgba(255,195,25,0.3); padding:6px 12px; border-radius:8px; font-size:11px; font-weight:800; cursor:pointer;">CHANGE</button>
        </div>`;
h = h.replace(oldEmailHTML, newEmailHTML);

// 2. Gmail Change Modal (2-Step OTP) add karo
const modalHTML = `
<!-- GMAIL CHANGE MODAL -->
<div class="gmail-modal" id="gmailModal">
    <div class="gmail-box">
        <div class="gm-header">
            <h3>Change <span>Gmail</span></h3>
            <button onclick="closeGmailModal()">✕</button>
        </div>
        <p class="gm-desc">For security, we'll send an OTP to your <b>current Gmail</b> first.</p>

        <!-- Step 1: Old Email OTP -->
        <div id="step1">
            <div class="gm-info">Current Gmail: <span id="oldEmailDisplay">Loading...</span></div>
            <button class="gm-btn" onclick="sendOldOtp()" id="sendOldBtn">Send OTP to Old Gmail</button>
            <div id="oldOtpBox" style="display:none; margin-top:12px;">
                <input type="number" class="gm-input" id="oldOtpInput" placeholder="Enter OTP from old Gmail" maxlength="6">
                <button class="gm-btn green" onclick="verifyOldOtp()">Verify Old Gmail</button>
            </div>
        </div>

        <!-- Step 2: New Email OTP -->
        <div id="step2" style="display:none;">
            <div class="gm-info">Enter your new Gmail address:</div>
            <input type="email" class="gm-input" id="newEmailInput" placeholder="new@gmail.com">
            <button class="gm-btn" onclick="sendNewOtp()" id="sendNewBtn">Send OTP to New Gmail</button>
            <div id="newOtpBox" style="display:none; margin-top:12px;">
                <input type="number" class="gm-input" id="newOtpInput" placeholder="Enter OTP from new Gmail" maxlength="6">
                <button class="gm-btn green" onclick="verifyNewOtp()">Verify & Update Gmail</button>
            </div>
        </div>
        
        <div class="gm-msg" id="gmMsg"></div>
    </div>
</div>

<style>
/* MODAL STYLES */
.gmail-modal{position:fixed;inset:0;background:rgba(0,0,0,0.85);backdrop-filter:blur(10px);z-index:9999;display:none;align-items:center;justify-content:center;padding:20px}
.gmail-modal.show{display:flex}
.gmail-box{background:#0a1535;border:1px solid rgba(255,195,25,0.3);border-radius:24px;padding:24px;width:100%;max-width:380px;box-shadow:0 20px 50px rgba(0,0,0,0.8)}
.gm-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px}
.gm-header h3{font-size:20px;font-weight:900;color:#fff}
.gm-header h3 span{color:#ffc419}
.gm-header button{background:none;border:none;color:#6b8bb8;font-size:20px;cursor:pointer}
.gm-desc{font-size:12px;color:#8a9bb8;margin-bottom:20px;line-height:1.5}
.gm-desc b{color:#fff}
.gm-info{font-size:12px;color:#fff;margin-bottom:10px;padding:10px;background:rgba(255,255,255,0.05);border-radius:8px}
.gm-info span{color:#ffc419;font-weight:700}
.gm-input{width:100%;padding:14px;background:rgba(0,0,0,0.3);border:1px solid rgba(255,255,255,0.1);border-radius:12px;color:#fff;font-size:14px;margin-bottom:10px;outline:none;font-family:monospace}
.gm-input:focus{border-color:#ffc419}
.gm-btn{width:100%;padding:14px;background:linear-gradient(135deg,#ffc419,#ff9800);color:#000;border:none;border-radius:12px;font-size:14px;font-weight:800;cursor:pointer}
.gm-btn:active{transform:scale(0.98)}
.gm-btn.green{background:linear-gradient(135deg,#00b359,#00e676);color:#fff}
.gm-msg{text-align:center;font-size:12px;margin-top:12px;font-weight:600;min-height:16px}
.gm-msg.error{color:#ff3b3b}
.gm-msg.success{color:#00e676}
</style>
`;
h = h.replace('</body>', modalHTML + '\n</body>');

// 3. JS Logic add karo
const jsCode = `
// GMAIL CHANGE LOGIC
let oldEmailVal = '';
let newEmailVal = '';

function openGmailChange() {
    oldEmailVal = document.getElementById('emailInput').value;
    if (oldEmailVal === 'Not set' || !oldEmailVal) {
        alert('No Gmail set. Please set it first.');
        return;
    }
    document.getElementById('oldEmailDisplay').innerText = oldEmailVal;
    document.getElementById('gmailModal').classList.add('show');
    document.getElementById('step1').style.display = 'block';
    document.getElementById('step2').style.display = 'none';
    document.getElementById('gmMsg').innerText = '';
}

function closeGmailModal() {
    document.getElementById('gmailModal').classList.remove('show');
}

function gmMsg(text, type) {
    const m = document.getElementById('gmMsg');
    m.innerText = text;
    m.className = 'gm-msg ' + type;
}

async function sendOldOtp() {
    document.getElementById('sendOldBtn').innerText = 'Sending...';
    try {
        const res = await fetch(SERVER + '/api/user/send-otp-old-email', {
            method: 'POST', headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ userId })
        });
        const data = await res.json();
        if(data.success) {
            gmMsg('OTP sent to old Gmail! Check Termux.', 'success');
            document.getElementById('oldOtpBox').style.display = 'block';
            document.getElementById('sendOldBtn').style.display = 'none';
        } else {
            gmMsg(data.error || 'Failed', 'error');
            document.getElementById('sendOldBtn').innerText = 'Send OTP to Old Gmail';
        }
    } catch(e) {
        gmMsg('Server error', 'error');
        document.getElementById('sendOldBtn').innerText = 'Send OTP to Old Gmail';
    }
}

async function verifyOldOtp() {
    const otp = document.getElementById('oldOtpInput').value;
    if(otp.length < 4) return gmMsg('Enter valid OTP', 'error');
    try {
        const res = await fetch(SERVER + '/api/user/verify-old-email-otp', {
            method: 'POST', headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ userId, otp })
        });
        const data = await res.json();
        if(data.success) {
            gmMsg('Old Gmail verified! Now enter new Gmail.', 'success');
            document.getElementById('step1').style.display = 'none';
            document.getElementById('step2').style.display = 'block';
        } else {
            gmMsg(data.error || 'Invalid OTP', 'error');
        }
    } catch(e) {
        gmMsg('Server error', 'error');
    }
}

async function sendNewOtp() {
    newEmailVal = document.getElementById('newEmailInput').value.trim();
    if(!newEmailVal.includes('@')) return gmMsg('Enter valid Gmail', 'error');
    
    document.getElementById('sendNewBtn').innerText = 'Sending...';
    try {
        const res = await fetch(SERVER + '/api/user/send-otp-new-email', {
            method: 'POST', headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ userId, newEmail: newEmailVal })
        });
        const data = await res.json();
        if(data.success) {
            gmMsg('OTP sent to new Gmail! Check Termux.', 'success');
            document.getElementById('newOtpBox').style.display = 'block';
            document.getElementById('sendNewBtn').style.display = 'none';
        } else {
            gmMsg(data.error || 'Failed', 'error');
            document.getElementById('sendNewBtn').innerText = 'Send OTP to New Gmail';
        }
    } catch(e) {
        gmMsg('Server error', 'error');
        document.getElementById('sendNewBtn').innerText = 'Send OTP to New Gmail';
    }
}

async function verifyNewOtp() {
    const otp = document.getElementById('newOtpInput').value;
    if(otp.length < 4) return gmMsg('Enter valid OTP', 'error');
    try {
        const res = await fetch(SERVER + '/api/user/verify-new-email-otp', {
            method: 'POST', headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ userId, otp })
        });
        const data = await res.json();
        if(data.success) {
            gmMsg('Gmail updated successfully!', 'success');
            document.getElementById('emailInput').value = newEmailVal;
            setTimeout(closeGmailModal, 1500);
        } else {
            gmMsg(data.error || 'Invalid OTP', 'error');
        }
    } catch(e) {
        gmMsg('Server error', 'error');
    }
}
`;
h = h.replace('</script>', jsCode + '\n</script>');

fs.writeFileSync('edit-profile.html', h);
console.log('✅ Name & Gmail Edit with 2-Step OTP Ready!');
