/* ==================================================
   IBA TRANSLATIONS - Complete English + Hindi
================================================== */

const IBA_TRANSLATIONS = {
  en: {
    // Common
    "back": "Back", "save": "Save", "cancel": "Cancel", "done": "Done",
    "loading": "Loading...", "error": "Error", "success": "Success",
    "yes": "Yes", "no": "No", "ok": "OK", "close": "Close",

    // Bottom Nav
    "nav_home": "Home", "nav_matches": "Matches", "nav_wallet": "Wallet",
    "nav_results": "Results", "nav_more": "More",

    // Dashboard
    "verified": "Verified", "wallet_balance": "Wallet Balance",
    "add_money": "Add Money", "withdraw": "Withdraw", "my_qr": "My QR",
    "history": "History", "upcoming_matches": "Upcoming Matches",
    "view_all": "View All", "join_match": "Join Match",
    "entry": "Entry", "prize": "Prize", "per_kill": "Per Kill", "booyah": "Booyah",
    "battle_royale": "BATTLE ROYALE", "clash_squad": "CLASH SQUAD",
    "upcoming": "UPCOMING", "live": "LIVE", "completed": "COMPLETED",
    "join_now": "JOIN MATCH", "more_options": "More",

    // Profile
    "profile": "Profile", "my_profile": "My Profile",
    "change_photo": "CHANGE PROFILE PHOTO",
    "photo_note": "You can change only your profile photo.",
    "username": "Username", "mobile": "Mobile", "gmail": "Gmail",
    "dob": "Date of Birth", "user_id": "User ID",

    // More Menu
    "settings": "Settings", "support": "Support", "faqs": "FAQs",
    "about_iba": "About IBA", "logout": "Logout",

    // Settings Page
    "settings_title": "Settings", "settings_sub": "Manage Your App",
    "sec_notifications": "🔔 Notifications",
    "push_notif": "Push Notifications", "push_notif_sub": "Match alerts & updates",
    "app_sounds": "App Sounds", "app_sounds_sub": "In-app sound effects",
    "vibration": "Vibration", "vibration_sub": "Haptic feedback",
    "sec_security": "🔒 Security & Privacy",
    "change_pin": "Change PIN", "change_pin_sub": "Update your security PIN",
    "privacy": "Privacy", "privacy_sub": "Control your data",
    "sec_language": "🌐 Language", "app_language": "App Language",
    "sec_app_info": "📱 App Info",
    "clear_cache": "Clear Cache", "clear_cache_sub": "Free up space",
    "danger_zone": "⚠️ Danger Zone",
    "danger_text": "This action will reset all app data. This cannot be undone.",
    "reset_app": "🔄 Reset App Data",
    "choose_lang": "🌐 Choose Language",
    "select_lang_sub": "Select your preferred app language",
    "lang_en": "English", "lang_en_sub": "Default Language",
    "lang_hi": "हिन्दी", "lang_hi_sub": "Hindi (India)",

    // Support
    "support_title": "Support", "admin_name": "IBA Admin",
    "online": "Online", "start_conv": "Start a Conversation",
    "start_conv_sub": "Ask admin anything — send text, photo or file",
    "type_msg": "Type a message...",

    // FAQ
    "faq_title": "FAQs", "faq_sub": "Frequently Asked Questions",
    "faq_q1": "🎮 How to join IBA?",
    "faq_a1": "Enter mobile number → Verify OTP → Create account. Ready in 1 minute!",
    "faq_q2": "💰 How to add money to wallet?",
    "faq_a2": "Open Wallet → Tap Add Money → Enter amount → Pay via UPI. Admin will verify and approve.",
    "faq_q3": "🏆 How to join a match?",
    "faq_a3": "Open Matches → Select match → Pay entry fee → Room ID + Password will unlock.",
    "faq_q4": "🎁 When will I get the prize?",
    "faq_a4": "After match completion, Admin will verify and credit to your wallet within 24 hours.",
    "faq_q5": "💸 How to withdraw?",
    "faq_a5": "Open Wallet → Tap Withdraw → Enter amount → Provide UPI/Bank details → Submit. Admin processes in 1-24 hours.",
    "faq_q6": "🆔 What is my User ID?",
    "faq_a6": "Profile page shows your User ID (like IBA99620674). This is your unique identity.",
    "faq_q7": "📱 How to use QR code?",
    "faq_a7": "Open Wallet → Show My QR → Let others scan → Instant transfer.",
    "faq_q8": "🚨 How to report cheating?",
    "faq_a8": "During match, open Report Player section → Enter player number + details. Admin will verify and act.",
    "faq_q9": "🔒 Is my money safe?",
    "faq_a9": "Absolutely! Every transaction is saved in encrypted database. Every match has screenshot proof.",
    "faq_q10": "💬 How to contact support?",
    "faq_a10": "Go to More → Support → Send message to admin. We'll reply soon.",
    "faq_help": "💬 Still Need Help? Chat With Us",

    // About
    "about_title": "About IBA",
    "about_name": "Indian Battelle Arena", "about_tag": "Enter the Battle",
    "about_us": "🏆 About Us",
    "about_us_text": "INDIAN BATTELLE ARENA is a premium gaming platform where players participate in real-money tournaments to showcase their skill and win rewards.",
    "our_mission": "🎯 Our Mission",
    "mission_text": "Give every Indian gamer a professional gaming platform where they can earn through their skill.",
    "what_we_offer": "💎 What We Offer",
    "offer_modes": "🎮 Game Modes", "offer_modes_val": "BR · Lone Wolf · CS",
    "offer_money": "💰 Real Money", "offer_money_val": "Instant Payout",
    "offer_security": "🔒 Security", "offer_security_val": "100% Secure",
    "offer_support": "⚡ Support", "offer_support_val": "24/7 Chat",
    "app_info_title": "📋 App Info",
    "info_version": "Version", "info_platform": "Platform",
    "info_developer": "Developer", "info_country": "Country",
    "version_badge": "● Version 1.0.0 · Beta",
    "copyright": "© 2026 IBA · All Rights Reserved",

    // Wallet
    "wallet_title": "My Wallet",
    "my_wallet_qr": "📱 My Wallet QR",
    "scan_qr_sub": "Scan this QR to pay directly",
    "secure_badge": "🔒 100% Secure",
    "share_qr": "🔗 Share QR", "scan_pay": "📷 Scan & Pay",
    "withdraw_money": "💰 Withdraw Money",
    "amount": "Amount (₹)", "payout_method": "Payout Method",
    "payout_details": "Payout Details",
    "submit_withdraw": "💸 Submit Withdraw Request",
    "tab_qr": "QR", "tab_withdraw": "Withdraw", "tab_history": "History",
    "no_txn": "No transactions",
    "txn_note": "Add money to see history",
    "held": "Held",

    // Login/Register
    "welcome_gamer": "Welcome Back, Gamer",
    "enter_mobile": "Enter your registered mobile number",
    "mobile_label": "Mobile Number",
    "send_otp": "🔐 SEND OTP",
    "secure_access": "Secure Gaming Access",
    "otp_verification": "OTP Verification",
    "enter_otp": "Enter the 6-digit OTP sent to your registered mobile number.",
    "verify_otp": "🔐 VERIFY OTP",
    "resend_otp": "RESEND OTP",
    "didnt_receive": "Didn't receive OTP?",
    "create_account": "Create Account",
    "complete_profile": "Complete your profile to get your Room Manager ID",
    "add_photo": "ADD PROFILE PHOTO",
    "create_manager": "🎮 CREATE MANAGER ACCOUNT",
    "one_mobile": "One verified mobile = One account",
    "manager_id_note": "Your ID will be generated automatically",

    // Toasts
    "toast_photo_updated": "Photo updated successfully",
    "toast_logout": "Logged out successfully",
    "toast_image_error": "Please select an image",
    "toast_lang_changed": "Language changed successfully",

    // Alerts
    "alert_logout_title": "Are you sure you want to logout?",
    "alert_clear_cache": "Clear cached data? App will reload.",
    "alert_reset_app": "Reset all data? This cannot be undone!",
    "alert_reset_confirm": "Are you sure? Everything will be deleted.",
    "alert_cache_cleared": "Cache cleared ✅",
    "alert_app_reset": "App reset complete ✅",
    "alert_change_pin": "Change PIN feature coming soon",
    "alert_privacy": "Privacy settings coming soon"
  },

  hi: {
    // Common
    "back": "वापस", "save": "सेव", "cancel": "रद्द करें", "done": "हो गया",
    "loading": "लोड हो रहा है...", "error": "त्रुटि", "success": "सफलता",
    "yes": "हाँ", "no": "नहीं", "ok": "ठीक है", "close": "बंद करें",

    // Bottom Nav
    "nav_home": "होम", "nav_matches": "मैचेस", "nav_wallet": "वॉलेट",
    "nav_results": "रिजल्ट्स", "nav_more": "और",

    // Dashboard
    "verified": "वेरिफाइड", "wallet_balance": "वॉलेट बैलेंस",
    "add_money": "पैसे जोड़ें", "withdraw": "निकालें", "my_qr": "मेरा QR",
    "history": "इतिहास", "upcoming_matches": "आने वाले मैचेस",
    "view_all": "सभी देखें", "join_match": "मैच जॉइन करें",
    "entry": "एंट्री", "prize": "इनाम", "per_kill": "प्रति किल", "booyah": "बूयाह",
    "battle_royale": "बैटल रॉयल", "clash_squad": "क्लैश स्क्वाड",
    "upcoming": "आने वाला", "live": "लाइव", "completed": "पूरा हुआ",
    "join_now": "मैच जॉइन करें", "more_options": "और",

    // Profile
    "profile": "प्रोफाइल", "my_profile": "मेरी प्रोफाइल",
    "change_photo": "प्रोफाइल फोटो बदलें",
    "photo_note": "आप सिर्फ अपनी प्रोफाइल फोटो बदल सकते हैं।",
    "username": "यूज़रनेम", "mobile": "मोबाइल", "gmail": "जीमेल",
    "dob": "जन्म तिथि", "user_id": "यूज़र ID",

    // More Menu
    "settings": "सेटिंग्स", "support": "सपोर्ट", "faqs": "सवाल-जवाब",
    "about_iba": "IBA के बारे में", "logout": "लॉगआउट",

    // Settings Page
    "settings_title": "सेटिंग्स", "settings_sub": "अपना ऐप मैनेज करें",
    "sec_notifications": "🔔 नोटिफिकेशन",
    "push_notif": "पुश नोटिफिकेशन", "push_notif_sub": "मैच अलर्ट और अपडेट",
    "app_sounds": "ऐप साउंड्स", "app_sounds_sub": "इन-ऐप साउंड इफेक्ट्स",
    "vibration": "वाइब्रेशन", "vibration_sub": "हैप्टिक फीडबैक",
    "sec_security": "🔒 सुरक्षा और गोपनीयता",
    "change_pin": "PIN बदलें", "change_pin_sub": "अपना सुरक्षा PIN अपडेट करें",
    "privacy": "गोपनीयता", "privacy_sub": "अपना डेटा नियंत्रित करें",
    "sec_language": "🌐 भाषा", "app_language": "ऐप भाषा",
    "sec_app_info": "📱 ऐप जानकारी",
    "clear_cache": "कैश साफ करें", "clear_cache_sub": "स्पेस खाली करें",
    "danger_zone": "⚠️ खतरे का क्षेत्र",
    "danger_text": "यह सारा ऐप डेटा रीसेट कर देगा। इसे वापस नहीं लाया जा सकता।",
    "reset_app": "🔄 ऐप डेटा रीसेट करें",
    "choose_lang": "🌐 भाषा चुनें",
    "select_lang_sub": "अपनी पसंदीदा भाषा चुनें",
    "lang_en": "English", "lang_en_sub": "डिफ़ॉल्ट भाषा",
    "lang_hi": "हिन्दी", "lang_hi_sub": "हिन्दी (भारत)",

    // Support
    "support_title": "सपोर्ट", "admin_name": "IBA एडमिन",
    "online": "ऑनलाइन", "start_conv": "बातचीत शुरू करें",
    "start_conv_sub": "एडमिन से कुछ भी पूछें — टेक्स्ट, फोटो या फाइल भेजें",
    "type_msg": "मैसेज टाइप करें...",

    // FAQ
    "faq_title": "सवाल-जवाब", "faq_sub": "अक्सर पूछे जाने वाले सवाल",
    "faq_q1": "🎮 IBA में कैसे जॉइन करें?",
    "faq_a1": "मोबाइल नंबर डालें → OTP वेरिफाई करें → अकाउंट बनाएं। बस 1 मिनट में तैयार!",
    "faq_q2": "💰 वॉलेट में पैसे कैसे जोड़ें?",
    "faq_a2": "वॉलेट खोलें → पैसे जोड़ें दबाएं → राशि डालें → UPI से पे करें। एडमिन वेरिफाई करेगा।",
    "faq_q3": "🏆 मैच में कैसे जॉइन करें?",
    "faq_a3": "मैचेस खोलें → मैच चुनें → एंट्री फीस दें → रूम ID + पासवर्ड अनलॉक होगा।",
    "faq_q4": "🎁 इनाम कब मिलेगा?",
    "faq_a4": "मैच पूरा होने के बाद, एडमिन वेरिफाई करेगा और 24 घंटे में वॉलेट में क्रेडिट होगा।",
    "faq_q5": "💸 पैसे कैसे निकालें?",
    "faq_a5": "वॉलेट खोलें → निकालें दबाएं → राशि डालें → UPI/बैंक डिटेल दें → सबमिट करें। एडमिन 1-24 घंटे में प्रोसेस करेगा।",
    "faq_q6": "🆔 मेरा यूज़र ID क्या है?",
    "faq_a6": "प्रोफाइल पेज पर आपका यूज़र ID दिखता है (जैसे IBA99620674)। यह आपकी यूनिक पहचान है।",
    "faq_q7": "📱 QR कोड कैसे इस्तेमाल करें?",
    "faq_a7": "वॉलेट खोलें → मेरा QR दिखाएं → दूसरों को स्कैन करने दें → तुरंत ट्रांसफर।",
    "faq_q8": "🚨 चीटिंग कैसे रिपोर्ट करें?",
    "faq_a8": "मैच के दौरान रिपोर्ट प्लेयर सेक्शन खोलें → प्लेयर नंबर + डिटेल डालें। एडमिन वेरिफाई करेगा।",
    "faq_q9": "🔒 क्या मेरा पैसा सुरक्षित है?",
    "faq_a9": "बिल्कुल! हर ट्रांजैक्शन एन्क्रिप्टेड डेटाबेस में सेव होती है। हर मैच का स्क्रीनशॉट प्रूफ रहता है।",
    "faq_q10": "💬 सपोर्ट से कैसे बात करें?",
    "faq_a10": "More → सपोर्ट → एडमिन को मैसेज भेजें। हम जल्दी रिप्लाई करेंगे।",
    "faq_help": "💬 अभी भी मदद चाहिए? हमसे चैट करें",

    // About
    "about_title": "IBA के बारे में",
    "about_name": "इंडियन बैटल एरीना", "about_tag": "बैटल में उतरो",
    "about_us": "🏆 हमारे बारे में",
    "about_us_text": "इंडियन बैटल एरीना एक प्रीमियम गेमिंग प्लेटफ़ॉर्म है जहां खिलाड़ी रियल-मनी टूर्नामेंट में हिस्सा लेकर अपना स्किल दिखाते हैं और इनाम जीतते हैं।",
    "our_mission": "🎯 हमारा मिशन",
    "mission_text": "हर भारतीय गेमर को प्रोफेशनल गेमिंग प्लेटफ़ॉर्म देना जहां वे अपनी स्किल से कमा सकें।",
    "what_we_offer": "💎 हम क्या देते हैं",
    "offer_modes": "🎮 गेम मोड्स", "offer_modes_val": "BR · लोन वुल्फ · CS",
    "offer_money": "💰 रियल मनी", "offer_money_val": "इंस्टेंट पेआउट",
    "offer_security": "🔒 सुरक्षा", "offer_security_val": "100% सुरक्षित",
    "offer_support": "⚡ सपोर्ट", "offer_support_val": "24/7 चैट",
    "app_info_title": "📋 ऐप जानकारी",
    "info_version": "वर्जन", "info_platform": "प्लेटफ़ॉर्म",
    "info_developer": "डेवलपर", "info_country": "देश",
    "version_badge": "● वर्जन 1.0.0 · बीटा",
    "copyright": "© 2026 IBA · सर्वाधिकार सुरक्षित",

    // Wallet
    "wallet_title": "मेरा वॉलेट",
    "my_wallet_qr": "📱 मेरा वॉलेट QR",
    "scan_qr_sub": "सीधे भुगतान के लिए यह QR स्कैन करें",
    "secure_badge": "🔒 100% सुरक्षित",
    "share_qr": "🔗 QR शेयर करें", "scan_pay": "📷 स्कैन & पे",
    "withdraw_money": "💰 पैसे निकालें",
    "amount": "राशि (₹)", "payout_method": "पेआउट तरीका",
    "payout_details": "पेआउट विवरण",
    "submit_withdraw": "💸 निकासी अनुरोध भेजें",
    "tab_qr": "QR", "tab_withdraw": "निकालें", "tab_history": "इतिहास",
    "no_txn": "कोई ट्रांजैक्शन नहीं",
    "txn_note": "इतिहास देखने के लिए पैसे जोड़ें",
    "held": "होल्ड",

    // Login/Register
    "welcome_gamer": "वापसी पर स्वागत, गेमर",
    "enter_mobile": "अपना रजिस्टर्ड मोबाइल नंबर डालें",
    "mobile_label": "मोबाइल नंबर",
    "send_otp": "🔐 OTP भेजें",
    "secure_access": "सुरक्षित गेमिंग एक्सेस",
    "otp_verification": "OTP वेरिफिकेशन",
    "enter_otp": "अपने रजिस्टर्ड मोबाइल पर भेजा गया 6-डिजिट OTP डालें।",
    "verify_otp": "🔐 OTP वेरिफाई करें",
    "resend_otp": "OTP दोबारा भेजें",
    "didnt_receive": "OTP नहीं मिला?",
    "create_account": "अकाउंट बनाएं",
    "complete_profile": "अपना प्रोफाइल पूरा करें और अपनी ID पाएं",
    "add_photo": "प्रोफाइल फोटो जोड़ें",
    "create_manager": "🎮 अकाउंट बनाएं",
    "one_mobile": "एक वेरिफाइड मोबाइल = एक अकाउंट",
    "manager_id_note": "आपकी ID अपने आप बन जाएगी",

    // Toasts
    "toast_photo_updated": "फोटो सफलतापूर्वक अपडेट हो गई",
    "toast_logout": "सफलतापूर्वक लॉगआउट",
    "toast_image_error": "कृपया एक इमेज चुनें",
    "toast_lang_changed": "भाषा सफलतापूर्वक बदल गई",

    // Alerts
    "alert_logout_title": "क्या आप लॉगआउट करना चाहते हैं?",
    "alert_clear_cache": "कैश डेटा साफ करें? ऐप रीलोड होगा।",
    "alert_reset_app": "सारा डेटा रीसेट करें? इसे वापस नहीं लाया जा सकता!",
    "alert_reset_confirm": "पक्का? सब कुछ डिलीट हो जाएगा।",
    "alert_cache_cleared": "कैश साफ हो गया ✅",
    "alert_app_reset": "ऐप रीसेट पूरा ✅",
    "alert_change_pin": "PIN बदलने का फीचर जल्द आएगा",
    "alert_privacy": "प्राइवेसी सेटिंग्स जल्द आएंगी"
  }
};

/* =========================
   GET TRANSLATION
========================= */
function t(key){
  const lang = localStorage.getItem("iba_lang") || "en";
  const dict = IBA_TRANSLATIONS[lang] || IBA_TRANSLATIONS.en;
  return dict[key] || IBA_TRANSLATIONS.en[key] || key;
}

/* =========================
   APPLY TRANSLATIONS
========================= */
function applyTranslations(){
  document.querySelectorAll("[data-i18n]").forEach(el => {
    const key = el.getAttribute("data-i18n");
    const translation = t(key);
    if(translation) el.textContent = translation;
  });

  document.querySelectorAll("[data-i18n-placeholder]").forEach(el => {
    const key = el.getAttribute("data-i18n-placeholder");
    const translation = t(key);
    if(translation) el.placeholder = translation;
  });

  document.querySelectorAll("[data-i18n-alert]").forEach(el => {
    const key = el.getAttribute("data-i18n-alert");
    const translation = t(key);
    if(translation) el.setAttribute("data-alert-text", translation);
  });
}

/* =========================
   AUTO-APPLY ON LOAD
========================= */
if(document.readyState === "loading"){
  document.addEventListener("DOMContentLoaded", applyTranslations);
} else {
  applyTranslations();
}
