const fs = require('fs');
let h = fs.readFileSync('messages.html', 'utf8');

// 1. Custom Popup HTML add karo
const popupHTML = `
<!-- PREMIUM DELETE POPUP -->
<div class="delete-popup-overlay" id="deletePopup">
    <div class="delete-popup-box">
        <div class="delete-icon">🗑️</div>
        <h3>Remove Friend?</h3>
        <p>Are you sure you want to remove <b id="deleteFriendName">this friend</b> from your list? You can always add them back later.</p>
        <div class="delete-actions">
            <button class="del-cancel" onclick="closeDeletePopup()">CANCEL</button>
            <button class="del-confirm" onclick="confirmDelete()">REMOVE</button>
        </div>
    </div>
</div>

<style>
.delete-popup-overlay {
    position: fixed; inset: 0; z-index: 9999;
    background: rgba(0, 0, 0, 0.85);
    backdrop-filter: blur(8px);
    display: none;
    align-items: center;
    justify-content: center;
    padding: 20px;
}
.delete-popup-overlay.show { display: flex; }
.delete-popup-box {
    background: linear-gradient(180deg, #0a1535, #02040a);
    border: 1.5px solid rgba(255, 59, 59, 0.4);
    border-radius: 24px;
    padding: 30px 24px;
    max-width: 340px;
    width: 100%;
    text-align: center;
    box-shadow: 0 20px 60px rgba(255, 59, 59, 0.2);
    animation: popIn 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
}
@keyframes popIn {
    from { transform: scale(0.8); opacity: 0; }
    to { transform: scale(1); opacity: 1; }
}
.delete-icon {
    width: 70px; height: 70px;
    background: rgba(255, 59, 59, 0.15);
    border-radius: 50%;
    display: grid; place-items: center;
    font-size: 32px;
    margin: 0 auto 16px;
    border: 2px solid rgba(255, 59, 59, 0.3);
}
.delete-popup-box h3 {
    font-size: 20px; font-weight: 900; color: #fff; margin-bottom: 10px;
}
.delete-popup-box p {
    font-size: 13px; color: #a8bddc; line-height: 1.6; margin-bottom: 24px;
}
.delete-popup-box p b { color: #ffc419; }
.delete-actions {
    display: flex; gap: 12px;
}
.delete-actions button {
    flex: 1; padding: 14px; border-radius: 14px;
    font-size: 14px; font-weight: 900; cursor: pointer;
    letter-spacing: 1px; border: none;
    transition: 0.2s;
}
.delete-actions button:active { transform: scale(0.96); }
.del-cancel {
    background: rgba(255, 255, 255, 0.08);
    color: #fff;
    border: 1px solid rgba(255, 255, 255, 0.15) !important;
}
.del-confirm {
    background: linear-gradient(135deg, #ff3b3b, #cc0033);
    color: #fff;
    box-shadow: 0 6px 20px rgba(255, 59, 59, 0.4);
}
</style>
`;
h = h.replace('</body>', popupHTML + '\n</body>');

// 2. Purana deleteFriend function hatao aur naya lagao
const oldDeleteFn = /function deleteFriend\(\) \{[\s\S]*?\n\}/;
const newDeleteFn = `
var pendingDeleteFriendId = null;

function deleteFriend() {
    var urlParams = new URLSearchParams(window.location.search);
    var friendId = urlParams.get('friend');
    if(!friendId) { alert('No friend selected'); return; }
    
    pendingDeleteFriendId = friendId;
    
    // Friend ka naam dhoondo (localStorage se)
    var friends = JSON.parse(localStorage.getItem('iba_friends') || '[]');
    var friend = friends.find(function(f) { return f.userId === friendId; });
    var friendName = friend ? friend.name : 'this friend';
    
    document.getElementById('deleteFriendName').textContent = friendName;
    document.getElementById('deletePopup').classList.add('show');
    document.getElementById('dropdownMenu').classList.remove('show');
}

function closeDeletePopup() {
    document.getElementById('deletePopup').classList.remove('show');
    pendingDeleteFriendId = null;
}

function confirmDelete() {
    if(!pendingDeleteFriendId) return;
    var myId = localStorage.getItem('iba_userId');
    var friendId = pendingDeleteFriendId;
    
    fetch(SERVER + '/api/delete-friend/' + myId + '/' + friendId, { method: 'DELETE' })
        .then(function(res) { return res.json(); })
        .then(function(data) {
            // LocalStorage se bhi delete
            var friends = JSON.parse(localStorage.getItem('iba_friends') || '[]');
            friends = friends.filter(function(f) { return f.userId !== friendId; });
            localStorage.setItem('iba_friends', JSON.stringify(friends));
            
            closeDeletePopup();
            alert('✅ Friend removed!');
            window.location.href = 'add-friend.html';
        })
        .catch(function() {
            alert('Delete failed');
            closeDeletePopup();
        });
}
`;
h = h.replace(oldDeleteFn, newDeleteFn);

fs.writeFileSync('messages.html', h);
console.log('✅ Premium Delete Popup added!');
