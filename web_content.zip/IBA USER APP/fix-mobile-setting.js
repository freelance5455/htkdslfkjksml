const fs = require('fs');
let h = fs.readFileSync('settings.html', 'utf8');

// 1. Mobile Number wale item ka onclick hatao
h = h.replace(
    '<div class="setting-item" onclick="showToast(\'Change Mobile\')">',
    '<div class="setting-item" style="cursor: default;">'
);

// 2. Right side wale arrow (›) ki jagah Lock (🔒) icon lagao
h = h.replace(
    `<div class="setting-text">
                <div class="setting-name">Mobile Number</div>
                <div class="setting-desc" id="settingMobile">+91 0000000000</div>
            </div>
            <div class="setting-arrow">›</div>`,
    `<div class="setting-text">
                <div class="setting-name">Mobile Number</div>
                <div class="setting-desc" id="settingMobile">+91 0000000000</div>
            </div>
            <div class="setting-arrow" style="font-size: 16px; color: #ff3b3b;">🔒</div>`
);

fs.writeFileSync('settings.html', h);
console.log('✅ Mobile Number locked, popup removed!');
