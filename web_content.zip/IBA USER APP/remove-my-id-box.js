const fs = require('fs');
let h = fs.readFileSync('add-friend.html', 'utf8');

// 1. MY ID CARD ka HTML block poora hatao
const myIdCardRegex = /<!-- MY ID CARD -->[\s\S]*?<\/div>\s*<\/div>/;
h = h.replace(myIdCardRegex, '');

// 2. JS me se bhi loadMyId function aur uski call hatao (taaki error na aaye)
h = h.replace(/async function loadMyId\(\) \{[\s\S]*?loadMyId\(\);/g, '');

fs.writeFileSync('add-friend.html', h);
console.log('✅ YOUR IBA ID box removed successfully!');
