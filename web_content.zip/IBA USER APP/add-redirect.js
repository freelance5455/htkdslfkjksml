const fs = require('fs');
let html = fs.readFileSync('login.html', 'utf8');
if(html.includes('location.protocol==="file:"')){
    console.log('already exists');
    process.exit(0);
}
const redirect = '<script>if(location.protocol==="file:"){location.replace("http://localhost:3102/user/login.html");}<\/script>\n';
const headIdx = html.indexOf('<head>');
const headEnd = headIdx + 6;
html = html.slice(0, headEnd) + '\n' + redirect + html.slice(headEnd);
fs.writeFileSync('login.html', html);
console.log('✅ Redirect added to login.html');
