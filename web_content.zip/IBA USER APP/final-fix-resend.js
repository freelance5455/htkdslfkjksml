const fs = require('fs');
let h = fs.readFileSync('edit-profile.html', 'utf8');

// Line 605 wale purane button ko dhoondho
const oldBtn = '<button class="gm-btn green" onclick="verifyOldOtp()">Verify Old Gmail</button>';

// Uske theek baad Resend OTP ka box add karo
const newBtn = oldBtn + `
                <div style="text-align:center; margin-top:12px; font-size:12px; color:#8a9bb8;">
                    Didn't receive? <span id="resendOldBtn" onclick="resendOldOtp()" style="color:#ffc419; font-weight:700; cursor:pointer; text-decoration:underline;">Resend OTP</span>
                    <span id="resendOldTimer" style="color:#5a6a85;"></span>
                </div>`;

// Replace karo
if(h.includes(oldBtn)) {
    h = h.replace(oldBtn, newBtn);
    fs.writeFileSync('edit-profile.html', h);
    console.log('✅ HTML me Resend OTP add ho gaya!');
} else {
    console.log('❌ Button nahi mila, check karo file.');
}
