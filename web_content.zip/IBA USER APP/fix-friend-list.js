const fs = require('fs');
let h = fs.readFileSync('add-friend.html', 'utf8');

// 1. Purana loadMyFriends function aur addFriend function hatao
const startIdx = h.indexOf('// LOAD FRIENDS FROM SERVER');
const endIdx = h.indexOf('</script>');
if (startIdx !== -1 && endIdx !== -1) {
    h = h.slice(0, startIdx) + h.slice(endIdx);
}

// 2. Naya saaf JS code add karo
const newJS = `
var SERVER = "http://localhost:3102";

function searchFriend() {
    var input = document.getElementById('friendIdInput').value.trim().toUpperCase();
    var result = document.getElementById('resultArea');
    if(!input) { result.innerHTML = '<div class="error-card"><p>Enter IBA ID</p></div>'; return; }
    result.innerHTML = '<div class="empty-state"><p>Searching...</p></div>';
    
    fetch(SERVER + '/api/find-user/' + input)
        .then(function(res) { return res.json(); })
        .then(function(data) {
            if(data.success && data.user) {
                var u = data.user;
                result.innerHTML = '<div class="friend-card">' +
                    '<div class="friend-avatar">' + (u.photo ? '<img src="' + u.photo + '">' : u.name.charAt(0).toUpperCase()) + '</div>' +
                    '<div class="friend-name">' + u.name + '</div>' +
                    '<div class="friend-id">' + (u.accountId || input) + '</div>' +
                    '<button class="add-btn" onclick="addFriend(\\'' + u.userId + '\\', \\'' + u.name + '\\', \\'' + input + '\\', \\'' + (u.photo || '') + '\\')">+ ADD FRIEND</button>' +
                '</div>';
            } else {
                result.innerHTML = '<div class="error-card"><p>User not found</p></div>';
            }
        })
        .catch(function() { result.innerHTML = '<div class="error-card"><p>Server error</p></div>'; });
}

function addFriend(userId, name, ibaId, photo) {
    var myId = localStorage.getItem('iba_userId');
    fetch(SERVER + '/api/add-friend', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ myId: myId, friendId: userId, friendName: name, friendIbaId: ibaId, friendPhoto: photo })
    }).then(function() {
        alert('✅ Friend added!');
        document.getElementById('friendIdInput').value = '';
        document.getElementById('resultArea').innerHTML = '<div class="empty-state"><p>Search for a friend</p></div>';
        loadMyFriends();
    });
}

function loadMyFriends() {
    var myId = localStorage.getItem('iba_userId');
    var container = document.getElementById('friendsContainer');
    var countEl = document.getElementById('friendCount');
    if(!myId || !container) return;
    
    fetch(SERVER + '/api/my-friends/' + myId)
        .then(function(res) { return res.json(); })
        .then(function(data) {
            if(data.success && data.friends && data.friends.length > 0) {
                countEl.textContent = data.friends.length;
                container.innerHTML = data.friends.map(function(f) {
                    // Dhyan do: data me 'userId', 'name', 'ibaId' use ho raha hai
                    return '<div style="display:flex; align-items:center; gap:12px; padding:12px; background:rgba(10,21,53,0.6); border:1px solid rgba(255,255,255,0.1); border-radius:16px; margin-bottom:10px;">' +
                        '<div style="width:46px; height:46px; border-radius:50%; border:2px solid #ffc419; overflow:hidden; background:#0a1535; display:grid; place-items:center; font-size:18px; font-weight:900; flex-shrink:0;">' +
                            (f.photo ? '<img src="' + f.photo + '" style="width:100%;height:100%;object-fit:cover;">' : f.name.charAt(0).toUpperCase()) +
                        '</div>' +
                        '<div style="flex:1; min-width:0;">' +
                            '<div style="font-size:14px; font-weight:800; color:#fff;">' + f.name + '</div>' +
                            '<div style="font-size:11px; color:#ffc419; font-weight:700;">' + f.ibaId + '</div>' +
                        '</div>' +
                        '<button onclick="location.href=\\'messages.html?role=player&friend=' + f.userId + '\\'" style="padding:8px 12px; background:#ffc419; color:#000; border:none; border-radius:8px; font-size:11px; font-weight:900; margin-right:4px;">CHAT</button>' +
                        '<button onclick="deleteFriend(\\'' + f.userId + '\\', \\'' + f.name + '\\')" style="padding:8px 10px; background:rgba(255,59,59,0.15); color:#ff3b3b; border:1px solid rgba(255,59,59,0.3); border-radius:8px; font-size:14px;">🗑️</button>' +
                    '</div>';
                }).join('');
            } else {
                countEl.textContent = '0';
                container.innerHTML = '<div style="text-align:center; padding:20px; color:#6b8bb8; font-size:12px;">No friends yet.</div>';
            }
        });
}

function deleteFriend(friendId, friendName) {
    if(!confirm('Delete ' + friendName + '?')) return;
    var myId = localStorage.getItem('iba_userId');
    fetch(SERVER + '/api/delete-friend/' + myId + '/' + friendId, { method: 'DELETE' })
        .then(function() {
            alert('✅ Deleted!');
            loadMyFriends();
        });
}

window.onload = function() {
    loadMyFriends();
};
`;
h = h.replace('</script>', newJS + '\n</script>');

fs.writeFileSync('add-friend.html', h);
console.log('✅ Add Friend page completely FIXED!');
