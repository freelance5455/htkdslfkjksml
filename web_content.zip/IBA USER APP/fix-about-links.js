const fs = require('fs');
let h = fs.readFileSync('about.html', 'utf8');

// 1. Script tag ke shuru me link load karne ka logic add karo
const loadLinksJS = `
var SERVER = "http://localhost:3102";
var socialLinks = {};

async function loadSocialLinks() {
    try {
        const res = await fetch(SERVER + '/api/social-links');
        const data = await res.json();
        if (data.success && data.links) {
            socialLinks = data.links;
        }
    } catch(e) {
        console.log('Links load failed, using defaults');
    }
}

function openLink(type) {
    var url = socialLinks[type] || '#';
    if (url && url !== '#') {
        window.open(url, '_blank');
    } else {
        alert('Link not set by Admin yet.');
    }
}

// Page load hote hi links fetch karo
window.addEventListener('load', loadSocialLinks);
`;

h = h.replace('<script>', '<script>' + loadLinksJS);

// 2. Purane onclick links ko type se replace karo
h = h.replace(/onclick="openLink\('https:\/\/wa\.me\/[^']*'\)"/g, 'onclick="openLink(\'whatsapp\')"');
h = h.replace(/onclick="openLink\('https:\/\/t\.me\/[^']*'\)"/g, 'onclick="openLink(\'telegram\')"');
h = h.replace(/onclick="openLink\('https:\/\/instagram\.com\/[^']*'\)"/g, 'onclick="openLink(\'instagram\')"');
h = h.replace(/onclick="openLink\('https:\/\/facebook\.com\/[^']*'\)"/g, 'onclick="openLink(\'facebook\')"');
h = h.replace(/onclick="openLink\('https:\/\/youtube\.com\/[^']*'\)"/g, 'onclick="openLink(\'youtube\')"');

// 3. Purana openLink function hatao (agar hai)
h = h.replace(/function openLink\(url\) \{\s*window\.open\(url, '_blank'\);\s*\}/, '');

fs.writeFileSync('about.html', h);
console.log('✅ About page ab dynamic links fetch karega!');
