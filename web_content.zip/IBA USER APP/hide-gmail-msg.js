const fs = require('fs');
let h = fs.readFileSync('edit-profile.html', 'utf8');

// 1. Old Gmail wala message hatao
h = h.replace(
    "gmMsg('OTP sent to old Gmail! Check Termux.', 'success');",
    "// Message hidden"
);

// 2. New Gmail wala message bhi hatao (agar hai toh)
h = h.replace(
    "gmMsg('OTP sent to new Gmail! Check Termux.', 'success');",
    "// Message hidden"
);

// 3. Agar koi aur similar message bacha ho toh use bhi hatao
h = h.replace(/gmMsg\('OTP sent to [^']*Check Termux\.[^']*', 'success'\);/g, '');

fs.writeFileSync('edit-profile.html', h);
console.log('✅ "Check Termux" messages hidden!');
