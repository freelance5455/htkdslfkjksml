const fs = require('fs');
let h = fs.readFileSync('edit-profile.html', 'utf8');

// 1. HTML: Verify button ke theek baad Resend ka option daalo
const verifyBtn = `<button onclick="verifyOldOtp()" style="width:100%;padding:13px;background:linear-gradient(135deg,#00b359,#00e676);color:#fff;border:none;border-radius:12px;font-size:13px;font-weight:800;cursor:pointer">VERIFY OLD EMAIL</button>`;

const resendHTML = verifyBtn + `
<div style="text-align:center; margin-top:12px; font-size:12px; color:#8a9bb8;" id="resendOldBox">
    Didn't receive? <span id="resendOldBtn" onclick="resendOldOtp()" style="color:#ffc419; font-weight:700; cursor:pointer; text-decoration:underline;">Resend OTP</span>
    <span id="resendOldTimer" style="color:#5a6a85;"></span>
</div>`;

// Agar pehle se nahi hai toh add karo
if (!h.includes('resendOldBtn')) {
    h = h.replace(verifyBtn, resendHTML);
}

// 2. JS: Timer aur Resend function
const resendJS = `
// RESEND OLD GMAIL OTP
var resendOldTimerVar = null;

function startOldResendTimer() {
    var countdown = 30;
    var timerEl = document.getElementById('resendOldTimer');
    var btnEl = document.getElementById('resendOldBtn');
    if(!timerEl || !btnEl) return;
    
    clearInterval(resendOldTimerVar);
    btnEl.style.display = 'none';
    timerEl.textContent = '(Wait ' + countdown + 's)';
    
    resendOldTimerVar = setInterval(function() {
        countdown--;
        if(countdown <= 0) {
            clearInterval(resendOldTimerVar);
            timerEl.textContent = '';
            btnEl.style.display = 'inline';
        } else {
            timerEl.textContent = '(Wait ' + countdown + 's)';
        }
    }, 1000);
}

async function resendOldOtp() {
    try {
        const res = await fetch(SERVER + '/api/user/send-otp-old-email', {
            method: 'POST', headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ userId })
        });
        const data = await res.json();
        if(data.success) {
            document.getElementById('oldOtpInput').value = '';
            startOldResendTimer();
        } else {
            gmMsg(data.error || 'Failed to resend', 'error');
        }
    } catch(e) {
        gmMsg('Server error', 'error');
    }
}

// OTP send hone ke baad timer start karne ka function
function showOldOtpBox() {
    document.getElementById('oldOtpBox').style.display = 'block';
    document.getElementById('sendOldBtn').style.display = 'none';
    startOldResendTimer(); 
}
`;

if (!h.includes('function resendOldOtp')) {
    h = h.replace('</script>', resendJS + '\n</script>');
}

// 3. Jab OTP send ho toh timer start ho
if (h.includes("document.getElementById('oldOtpBox').style.display = 'block';")) {
    h = h.replace(
        "document.getElementById('oldOtpBox').style.display = 'block';",
        "document.getElementById('oldOtpBox').style.display = 'block';\n            startOldResendTimer();"
    );
}

fs.writeFileSync('edit-profile.html', h);
console.log('✅ Resend OTP code successfully added!');
