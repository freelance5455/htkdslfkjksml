const fs = require('fs');
let h = fs.readFileSync('about.html', 'utf8');

// Purana openLink function hatao
const oldFnRegex = /function openLink\(type\) \{[\s\S]*?\n\}/;

// Naya function jo link ko system browser me kholne ki koshish karega
const newFn = `function openLink(type) {
    var url = socialLinks[type] || '';
    
    if (!url) {
        alert('Link not set by Admin yet.');
        return;
    }

    // Agar URL me kachra hai (intent:// ya Hindi text), toh use saaf karo
    if (url.includes('intent://')) {
        var match = url.match(/instagram\\.com\\/([^\\/?]+)/);
        if (match && match[1]) url = 'https://www.instagram.com/' + match[1];
    }

    // Chrome Browser me kholne ke liye force karo
    // Android me "_system" ya "_blank" use karte hain
    if (type === 'instagram') {
        // Instagram link ke liye ek chhota sa fix
        window.location.href = url;
    } else {
        window.open(url, '_system');
    }
}`;

h = h.replace(oldFnRegex, newFn);
fs.writeFileSync('about.html', h);
console.log('✅ Link opening logic fixed!');
