const fs = require('fs');
let h = fs.readFileSync('edit-profile.html', 'utf8');

// 1. Niche wala Account ID block hatao
const bottomIdHTML = `<div class="form-group" style="margin-top:20px;">
        <label class="form-label">ACCOUNT ID (IBA ID)</label>
        <div class="input-wrapper">
            <div class="input-icon">🔢</div>
            <input type="text" class="form-input" id="accountIdInput" placeholder="Enter your unique ID" maxlength="15">
        </div>
    </div>
    <div class="info-text">Your IGN and UID will be used for match verification.</div>`;

// Naya block (Display Name ke upar) - thoda premium design ke saath
const newTopIdHTML = `<div class="form-group" style="background:rgba(255,195,25,0.05); border:1px solid rgba(255,195,25,0.3); padding:16px; border-radius:16px; margin-bottom:24px;">
        <label class="form-label" style="color:#ffc419; margin-bottom:12px; font-size:12px; letter-spacing:2px;">⭐ YOUR UNIQUE IBA ID</label>
        <div class="input-wrapper" style="background:#02040a; border-color:rgba(255,195,25,0.5);">
            <div class="input-icon" style="color:#ffc419; font-size:22px;">#</div>
            <input type="text" class="form-input" id="accountIdInput" placeholder="Enter your IBA ID" maxlength="15" style="font-weight:900; font-size:18px; color:#fff; letter-spacing:2px;">
        </div>
        <div style="font-size:10px; color:#8a9bb8; margin-top:8px; padding-left:4px;">This ID will be visible on your profile.</div>
    </div>

    <!-- ACCOUNT INFO -->
    <div class="form-group">
        <label class="form-label">DISPLAY NAME</label>`;

// 2. Replace karo
// Pehle niche wale ko hatao
h = h.replace(bottomIdHTML, '<div class="info-text">Your IGN and UID will be used for match verification.</div>');

// Ab upar wale ko add karo (Display Name section ke pehle)
h = h.replace(
    `<!-- ACCOUNT INFO -->
    <div class="form-group">
        <label class="form-label">DISPLAY NAME</label>`,
    newTopIdHTML
);

fs.writeFileSync('edit-profile.html', h);
console.log('✅ Account ID moved to top with Premium design!');
