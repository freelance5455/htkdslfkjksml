const fs = require('fs');
let h = fs.readFileSync('edit-profile.html', 'utf8');

// 1. HTML me Old Gmail OTP box ke niche Resend button add karo
const oldOtpBox = `<div id="oldOtpBox" style="display:none">
                <input type="tel" id="oldOtpInput" maxlength="6" inputmode="numeric" placeholder="Enter OTP from old email" style="width:100%;padding:13px;background:rgba(5,5,25,.8);border:1.5px solid rgba(80,100,255,.35);border-radius:12px;color:#fff;font-size:14px;font-weight:600;outline:none;letter-spacing:2px;text-align:center;margin-bottom:10px">
                <button onclick="verifyOldOtp()" style="width:100%;padding:13px;background:linear-gradient(135deg,#00b359,#00e676);color:#fff;border:none;border-radius:12px;font-size:13px;font-weight:800;cursor:pointer">VERIFY OLD EMAIL</button>
            </div>`;

const newOtpBox = `<div id="oldOtpBox" style="display:none">
                <input type="tel" id="oldOtpInput" maxlength="6" inputmode="numeric" placeholder="Enter OTP from old email" style="width:100%;padding:13px;background:rgba(5,5,25,.8);border:1.5px solid rgba(80,100,255,.35);border-radius:12px;color:#fff;font-size:14px;font-weight:600;outline:none;letter-spacing:2px;text-align:center;margin-bottom:10px">
                <button onclick="verifyOldOtp()" style="width:100%;padding:13px;background:linear-gradient(135deg,#00b359,#00e676);color:#fff;border:none;border-radius:12px;font-size:13px;font-weight:800;cursor:pointer">VERIFY OLD EMAIL</button>
                
                <!-- RESEND OTP -->
                <div style="text-align:center; margin-top:12px; font-size:12px; color:#8a9bb8;">
                    Didn't receive? <span id="resendOldBtn" onclick="resendOldOtp()" style="color:#ffc419; font-weight:700; cursor:pointer; text-decoration:underline;">Resend OTP</span>
                    <span id="resendOldTimer" style="color:#5a6a85;"></span>
                </div>
            </div>`;

h = h.replace(oldOtpBox, newOtpBox);

// 2. JS me Resend function add karo
const resendJS = `
// RESEND OLD GMAIL OTP
var resendOldTimerVar = null;

function startOldResendTimer() {
    var countdown = 30;
    var timerEl = document.getElementById('resendOldTimer');
    var btnEl = document.getElementById('resendOldBtn');
    
    if(!timerEl || !btnEl) return;
    
    clearInterval(resendOldTimerVar);
    btnEl.style.display = 'none';
    timerEl.textContent = '(Wait ' + countdown + 's)';
    
    resendOldTimerVar = setInterval(function() {
        countdown--;
        if(countdown <= 0) {
            clearInterval(resendOldTimerVar);
            timerEl.textContent = '';
            btnEl.style.display = 'inline';
        } else {
            timerEl.textContent = '(Wait ' + countdown + 's)';
        }
    }, 1000);
}

async function resendOldOtp() {
    try {
        const res = await fetch(SERVER + '/api/user/send-otp-old-email', {
            method: 'POST', headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ userId })
        });
        const data = await res.json();
        
        if(data.success) {
            document.getElementById('oldOtpInput').value = '';
            startOldResendTimer();
        } else {
            gmMsg(data.error || 'Failed to resend', 'error');
        }
    } catch(e) {
        gmMsg('Server error', 'error');
    }
}
`;

h = h.replace('// GMAIL CHANGE LOGIC', '// GMAIL CHANGE LOGIC\n' + resendJS);

// 3. Jab pehli baar OTP send ho, toh timer start ho
h = h.replace(
    "document.getElementById('oldOtpBox').style.display = 'block';\n            document.getElementById('sendOldBtn').style.display = 'none';",
    "document.getElementById('oldOtpBox').style.display = 'block';\n            document.getElementById('sendOldBtn').style.display = 'none';\n            startOldResendTimer();"
);

fs.writeFileSync('edit-profile.html', h);
console.log('✅ Resend OTP added to Gmail change!');
