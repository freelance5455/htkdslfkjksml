const fs = require('fs');
let h = fs.readFileSync('about.html', 'utf8');

// Purana openLink function dhundo aur usko naye se replace karo
const oldFnRegex = /function openLink\(type\) \{[\s\S]*?\n\}/;

// Naya function jo seedha normal link kholta hai
const newFn = `function openLink(type) {
    var url = socialLinks[type] || '';
    
    if (!url) {
        alert('Link not set by Admin yet.');
        return;
    }

    // Agar galat format me hai toh saaf karo
    if (url.includes('intent://')) {
        var match = url.match(/instagram\\.com\\/([^\\/?]+)/);
        if (match && match[1]) {
            url = 'https://www.instagram.com/' + match[1];
        }
    }

    // Seedha naya tab kholo
    var a = document.createElement('a');
    a.href = url;
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}`;

h = h.replace(oldFnRegex, newFn);
fs.writeFileSync('about.html', h);
console.log('✅ Link ab normal tarike se khulega!');
