const fs = require('fs');
let h = fs.readFileSync('edit-profile.html', 'utf8');

// 1. Purana text hatao (jisme "auto-generated" likha hai)
const oldText = `<div style="font-size:10px; color:#8a9bb8; margin-top:8px; padding-left:4px;">This ID is auto-generated and <span style="color:#ff3b3b;">cannot be changed</span>. Contact Admin for changes.</div>`;
h = h.replace(oldText, '');

// 2. Agar upar wala exact match na mile, toh regex se try karo
const regex = /<div style="font-size:10px; color:#8a9bb8; margin-top:8px; padding-left:4px;">[\s\S]*?<\/div>/;
if (regex.test(h)) {
    h = h.replace(regex, '');
    console.log('✅ Hint text removed (via regex)');
} else {
    console.log('✅ Hint text removed (direct match)');
}

fs.writeFileSync('edit-profile.html', h);
