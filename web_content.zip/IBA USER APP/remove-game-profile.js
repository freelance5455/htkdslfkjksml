const fs = require('fs');
let h = fs.readFileSync('settings.html', 'utf8');

// Game Profile wale poore setting item ko hatao
const gameProfileHTML = `<div class="setting-item" onclick="location.href='game-profile.html'">
            <div class="setting-icon">🎮</div>
            <div class="setting-text">
                <div class="setting-name">Game Profile</div>
                <div class="setting-desc">Free Fire IGN & UID</div>
            </div>
            <div class="setting-arrow">›</div>
        </div>`;

if (h.includes(gameProfileHTML)) {
    h = h.replace(gameProfileHTML, '');
    console.log('✅ Game Profile option removed!');
} else {
    // Agar exact match na mile toh regex se try karo
    const regex = /<div class="setting-item"[^>]*>\s*<div class="setting-icon">🎮<\/div>[\s\S]*?<\/div>\s*<\/div>/;
    if (regex.test(h)) {
        h = h.replace(regex, '');
        console.log('✅ Game Profile option removed (via regex)!');
    } else {
        console.log('❌ Could not find Game Profile item.');
    }
}

fs.writeFileSync('settings.html', h);
