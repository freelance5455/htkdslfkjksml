const fs = require('fs');
let h = fs.readFileSync('about.html', 'utf8');

// Purane play button emoji (▶️) wale icon ko naye SVG YouTube logo se replace karo
const oldYtIcon = `<div class="social-icon" style="background:rgba(255,0,0,0.15);">▶️</div>`;

const newYtIcon = `<div class="social-icon" style="background:#FF0000;">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.42a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.4 19c1.72.42 8.6.42 8.6.42s6.88 0 8.6-.42a2.78 2.78 0 0 0 1.94-2 29 29 0 0 0 .46-5.33 29 29 0 0 0-.46-5.33z" fill="#FFFFFF"></path>
                    <polygon points="9.75 15.02 15.5 11.75 9.75 8.48 9.75 15.02" fill="#FF0000"></polygon>
                </svg>
            </div>`;

if (h.includes(oldYtIcon)) {
    h = h.replace(oldYtIcon, newYtIcon);
    console.log('✅ YouTube ka asli logo lag gaya!');
} else {
    console.log('❌ Purana YouTube icon nahi mila.');
}

fs.writeFileSync('about.html', h);
