const fs = require('fs');
let h = fs.readFileSync('edit-profile.html', 'utf8');

// 1. Modal ka text change karo (Gmail -> Mobile)
h = h.replace(
    'Enter your new name. We\'ll send an OTP to your Gmail for verification.',
    'Enter your new name. We\'ll send an OTP to your mobile number for verification.'
);

h = h.replace(
    'Send OTP to Gmail',
    'Send OTP to Mobile'
);

// 2. JS me API endpoint change karo (email ki jagah mobile wala)
// Note: Humne pehle `request-otp` (mobile) banaya tha, wahi use karenge.

const oldSendFn = /async function sendNameOtp\(\) \{[\s\S]*?\n\}/;
const newSendFn = `async function sendNameOtp() {
    pendingName = document.getElementById('newNameInput').value.trim();
    if(pendingName.length < 2) return nmMsg('Name must be 2+ characters', 'error');

    document.getElementById('sendNameBtn').innerText = 'Sending...';
    try {
        // Mobile number se OTP request karo (Purana API /api/user-auth/request-otp)
        const mobile = localStorage.getItem('iba_mobile');
        
        if(!mobile) {
            nmMsg('Mobile number not found. Please login again.', 'error');
            document.getElementById('sendNameBtn').innerText = 'Send OTP to Mobile';
            return;
        }

        const res = await fetch(SERVER + '/api/user-auth/request-otp', {
            method: 'POST', headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ mobile })
        });
        const data = await res.json();
        
        if(data.success) {
            nmMsg('OTP sent to your mobile! Check Termux.', 'success');
            document.getElementById('nameOtpBox').style.display = 'block';
            document.getElementById('sendNameBtn').style.display = 'none';
        } else {
            nmMsg(data.error || 'Failed', 'error');
            document.getElementById('sendNameBtn').innerText = 'Send OTP to Mobile';
        }
    } catch(e) {
        nmMsg('Server error', 'error');
        document.getElementById('sendNameBtn').innerText = 'Send OTP to Mobile';
    }
}`;
h = h.replace(oldSendFn, newSendFn);

// 3. Verify function update karo
const oldVerifyFn = /async function verifyNameOtp\(\) \{[\s\S]*?\n\}/;
const newVerifyFn = `async function verifyNameOtp() {
    const otp = document.getElementById('nameOtpInput').value;
    if(otp.length < 4) return nmMsg('Enter valid OTP', 'error');
    
    const mobile = localStorage.getItem('iba_mobile');
    
    try {
        // 1. OTP verify karo (Purana mobile OTP API)
        const verifyRes = await fetch(SERVER + '/api/user-auth/verify-otp', {
            method: 'POST', headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ mobile, otp })
        });
        const verifyData = await verifyRes.json();
        
        if(!verifyData.success) {
            return nmMsg(verifyData.error || 'Invalid OTP', 'error');
        }
        
        // 2. OTP sahi hai, ab naam update karo
        const updateRes = await fetch(SERVER + '/api/user/update-profile', {
            method: 'POST', headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ userId, name: pendingName })
        });
        const updateData = await updateRes.json();
        
        if(updateData.success) {
            nmMsg('Name updated successfully!', 'success');
            document.getElementById('nameInput').value = pendingName;
            localStorage.setItem('iba_name', pendingName);
            setTimeout(closeNameModal, 1500);
        } else {
            nmMsg(updateData.error || 'Failed to update name', 'error');
        }
        
    } catch(e) {
        nmMsg('Server error', 'error');
    }
}`;
h = h.replace(oldVerifyFn, newVerifyFn);

fs.writeFileSync('edit-profile.html', h);
console.log('✅ Name change now uses Mobile OTP!');
