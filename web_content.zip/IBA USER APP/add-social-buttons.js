const fs = require('fs');
let h = fs.readFileSync('about.html', 'utf8');

// 1. CSS me Button ka design add karo
const btnCSS = `
.social-row {
    display: flex; align-items: center; gap: 14px;
    padding: 14px 16px; border-bottom: 1px solid rgba(255,255,255,0.05);
    cursor: pointer; transition: 0.2s;
}
.social-row:active { background: rgba(255,255,255,0.05); }
.social-icon { width: 42px; height: 42px; border-radius: 12px; display: grid; place-items: center; font-size: 20px; flex-shrink: 0; }
.social-text { flex: 1; }
.social-name { font-size: 14px; font-weight: 800; color: #fff; }
.social-sub { font-size: 11px; color: #6b8bb8; margin-top: 2px; }
.social-action-btn {
    padding: 8px 16px; border-radius: 10px;
    font-size: 11px; font-weight: 900; letter-spacing: 0.5px;
    color: #000; border: none; cursor: pointer;
    transition: 0.2s; text-transform: uppercase;
}
.social-action-btn:active { transform: scale(0.92); }
.btn-whatsapp { background: #25D366; }
.btn-telegram { background: #2AABEE; color: #fff; }
.btn-instagram { background: linear-gradient(45deg, #f09433, #dc2743); color: #fff; }
.btn-facebook { background: #1877F2; color: #fff; }
.btn-youtube { background: #FF0000; color: #fff; }
`;
h = h.replace('</style>', btnCSS + '\n</style>');

// 2. Har row me button add karo
h = h.replace(
    /onclick="openLink\('whatsapp'\)">[\s\S]*?<div class="social-arrow">›<\/div>/,
    `onclick="openLink('whatsapp')">
            <div class="social-icon" style="background:#25D366;">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"><path fill-rule="evenodd" clip-rule="evenodd" d="M12 2C6.477 2 2 6.477 2 12c0 1.76.455 3.414 1.253 4.854L2.043 22l5.278-1.383A9.956 9.956 0 0 0 12 22c5.523 22 10-4.477 10-10S17.523 2 12 2zm5.512 14.184c-.244.688-1.432 1.32-1.964 1.36-.532.04-1.04.184-2.96-.632-2.296-.972-3.752-3.352-3.864-3.504-.112-.152-.92-1.24-.92-2.368 0-1.128.584-1.68.792-1.912.208-.232.456-.288.608-.288.152 0 .304.008.44.016.144.008.336-.056.52.392.192.464.648 1.584.704 1.696.056.112.096.24.024.384-.072.144-.144.24-.288.392-.144.152-.296.336-.424.464-.144.144-.296.296-.128.584.168.288.752 1.24 1.608 2.008 1.104.984 1.92 1.232 2.192 1.368.272.136.432.112.592-.064.16-.176.688-.8.872-1.072.184-.272.368-.224.616-.136.248.088 1.576.744 1.848.88.272.136.456.2.52.312.064.112.064.656-.18 1.344z" fill="#ffffff"/></svg>
            </div>
            <div class="social-text">
                <div class="social-name">WhatsApp</div>
                <div class="social-sub">Chat with Admin</div>
            </div>
            <button class="social-action-btn btn-whatsapp">CHAT</button>`
);

h = h.replace(
    /onclick="openLink\('telegram'\)">[\s\S]*?<div class="social-arrow">›<\/div>/,
    `onclick="openLink('telegram')">
            <div class="social-icon" style="background:linear-gradient(180deg, #2AABEE, #229ED9);">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M21.944 2.942a1.5 1.5 0 0 0-1.573-.204L2.673 10.833c-1.153.473-1.162 2.097.014 2.567l4.481 1.792 2.075 6.634a1.5 1.5 0 0 0 2.435.655l2.786-2.501 4.196 3.079a1.5 1.5 0 0 0 2.336-.888l3-17.5a1.5 1.5 0 0 0-.052-1.729zm-3.339 4.02l-6.836 6.36a1.5 1.5 0 0 0-.464 1.085v2.762l-1.306-4.176 8.606-6.031z" fill="#FFFFFF"/></svg>
            </div>
            <div class="social-text">
                <div class="social-name">Telegram</div>
                <div class="social-sub">Join our channel</div>
            </div>
            <button class="social-action-btn btn-telegram">JOIN</button>`
);

h = h.replace(
    /onclick="openLink\('instagram'\)">[\s\S]*?<div class="social-arrow">›<\/div>/,
    `onclick="openLink('instagram')">
            <div class="social-icon" style="background:linear-gradient(45deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%);">
                <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg>
            </div>
            <div class="social-text">
                <div class="social-name">Instagram</div>
                <div class="social-sub">Follow us for updates</div>
            </div>
            <button class="social-action-btn btn-instagram">FOLLOW</button>`
);

h = h.replace(
    /onclick="openLink\('facebook'\)">[\s\S]*?<div class="social-arrow">›<\/div>/,
    `onclick="openLink('facebook')">
            <div class="social-icon" style="background:#1877F2;">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M22 12C22 6.477 17.523 2 12 2C6.477 2 2 6.477 2 12C2 16.991 5.657 21.128 10.438 21.878V14.891H7.898V12H10.438V9.797C10.438 7.291 11.93 5.907 14.215 5.907C15.309 5.907 16.453 6.102 16.453 6.102V8.562H15.193C13.95 8.562 13.562 9.333 13.562 10.124V12H16.336L15.893 14.891H13.562V21.878C18.343 21.128 22 16.991 22 12Z" fill="#ffffff"/></svg>
            </div>
            <div class="social-text">
                <div class="social-name">Facebook</div>
                <div class="social-sub">Like our page</div>
            </div>
            <button class="social-action-btn btn-facebook">LIKE</button>`
);

h = h.replace(
    /onclick="openLink\('youtube'\)">[\s\S]*?<div class="social-arrow">›<\/div>/,
    `onclick="openLink('youtube')">
            <div class="social-icon" style="background:#FF0000;">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.42a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.4 19c1.72.42 8.6.42 8.6.42s6.88 0 8.6-.42a2.78 2.78 0 0 0 1.94-2 29 29 0 0 0 .46-5.33 29 29 0 0 0-.46-5.33z" fill="#FFFFFF"></path><polygon points="9.75 15.02 15.5 11.75 9.75 8.48 9.75 15.02" fill="#FF0000"></polygon></svg>
            </div>
            <div class="social-text">
                <div class="social-name">YouTube</div>
                <div class="social-sub">Subscribe to our channel</div>
            </div>
            <button class="social-action-btn btn-youtube">SUBSCRIBE</button>`
);

fs.writeFileSync('about.html', h);
console.log('✅ Social action buttons added!');
