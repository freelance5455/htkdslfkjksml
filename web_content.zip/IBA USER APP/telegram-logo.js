const fs = require('fs');
let h = fs.readFileSync('about.html', 'utf8');

// Purane airplane emoji (✈️) wale icon ko naye SVG Telegram logo se replace karo
const oldTgIcon = `<div class="social-icon" style="background:rgba(0,136,204,0.15);">✈️</div>`;

const newTgIcon = `<div class="social-icon" style="background:linear-gradient(180deg, #2AABEE, #229ED9);">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <path d="M21.944 2.942a1.5 1.5 0 0 0-1.573-.204L2.673 10.833c-1.153.473-1.162 2.097.014 2.567l4.481 1.792 2.075 6.634a1.5 1.5 0 0 0 2.435.655l2.786-2.501 4.196 3.079a1.5 1.5 0 0 0 2.336-.888l3-17.5a1.5 1.5 0 0 0-.052-1.729zm-3.339 4.02l-6.836 6.36a1.5 1.5 0 0 0-.464 1.085v2.762l-1.306-4.176 8.606-6.031z" fill="#FFFFFF"></path>
                </svg>
            </div>`;

if (h.includes(oldTgIcon)) {
    h = h.replace(oldTgIcon, newTgIcon);
    console.log('✅ Telegram ka asli logo lag gaya!');
} else {
    console.log('❌ Purana Telegram icon nahi mila. Shayad HTML thoda alag hai.');
}

fs.writeFileSync('about.html', h);
