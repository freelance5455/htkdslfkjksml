const fs = require('fs');
let h = fs.readFileSync('about.html', 'utf8');

const oldFnRegex = /function openLink\(type\) \{[\s\S]*?\n\}/;

// Naya function jo browser force karega
const newFn = `function openLink(type) {
    var url = socialLinks[type] || '';
    
    if (!url) {
        alert('Link not set by Admin yet.');
        return;
    }

    // Agar URL me "invites" ya kachra hai toh saaf karo
    if (type === 'instagram') {
        // Username nikaalo
        var username = url.match(/instagram\\.com\\/([^\\/?]+)/);
        if (username && username[1] && username[1] !== 'invites' && username[1] !== 'contact') {
            url = 'https://www.instagram.com/' + username[1];
        } else {
            // Agar username nahi mila toh default
            url = 'https://www.instagram.com/miss.aadiwashi.750';
        }
    }

    // Link ko forcefully browser me kholo
    window.open(url, '_system');
}`;

h = h.replace(oldFnRegex, newFn);
fs.writeFileSync('about.html', h);
console.log('✅ Link ab browser me force khulega!');
