const fs = require('fs');
let h = fs.readFileSync('edit-profile.html', 'utf8');

// 1. OTP send hone par jo green message aata hai, usko hatao
h = h.replace(
    "nmMsg('New OTP sent!', 'success');",
    "// Message hidden"
);

// 2. Resend OTP par bhi jo message aata hai, usko hatao
h = h.replace(
    "nmMsg('New OTP sent!', 'success');",
    "// Message hidden"
);

fs.writeFileSync('edit-profile.html', h);
console.log('✅ "New OTP sent!" message hidden!');
