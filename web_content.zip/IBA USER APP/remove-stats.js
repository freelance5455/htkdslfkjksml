const fs = require('fs');
let h = fs.readFileSync('dashboard.html', 'utf8');

// Stats grid HTML hatao
const statsHTML = `<div class="stats-grid">
        <div class="stat-3d">
            <span class="stat-ico">🏆</span>
            <div class="stat-val blue" id="statMatches">0</div>
            <div class="stat-lbl">Matches</div>
        </div>
        <div class="stat-3d">
            <span class="stat-ico">🥇</span>
            <div class="stat-val green" id="statWins">0</div>
            <div class="stat-lbl">Wins</div>
        </div>
        <div class="stat-3d">
            <span class="stat-ico">💰</span>
            <div class="stat-val" id="statBalance">₹0</div>
            <div class="stat-lbl">Balance</div>
        </div>
    </div>`;

if (h.includes(statsHTML)) {
    h = h.replace(statsHTML, '');
    console.log('✅ Stats grid removed');
} else {
    // Regex se try karo
    const regex = /<div class="stats-grid">[\s\S]*?<\/div>\s*<\/div>\s*<\/div>\s*<\/div>/;
    if (regex.test(h)) {
        h = h.replace(regex, '');
        console.log('✅ Stats grid removed via regex');
    } else {
        console.log('❌ Stats grid not found');
    }
}

// JS me jo stats update karta hai wo hatao
h = h.replace(/document\.getElementById\('statBalance'\)\.textContent = '₹' \+ \(p\.balance \|\| 0\);/g, '');
h = h.replace(/document\.getElementById\('statMatches'\)\.textContent = \(p\.matches \|\| \[\]\)\.length;/g, '');
h = h.replace(/document\.getElementById\('statWins'\)\.textContent = \(p\.wins \|\| 0\);/g, '');

fs.writeFileSync('dashboard.html', h);
console.log('✅ Done!');
