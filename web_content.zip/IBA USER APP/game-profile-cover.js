const fs = require('fs');
let h = fs.readFileSync('game-profile.html', 'utf8');

// 1. Purana Banner HTML hatao aur naya Cover Photo wala lagao
const oldBannerRegex = /<div class="banner"[\s\S]*?<\/div>\s*<\/div>/;
const newBanner = `<div class="banner" id="coverBanner" onclick="document.getElementById('coverInput').click()">
    <div class="cover-photo" id="coverPhoto"></div>
    <div class="cover-overlay"></div>
    <div class="cover-content">
        <div class="cover-icon">🎮</div>
        <h2>Free Fire <span>Profile</span></h2>
        <p>Tap to change cover photo</p>
    </div>
    <div class="cover-edit-icon">📷</div>
    <input type="file" id="coverInput" accept="image/*" style="display:none" onchange="handleCoverUpload(event)">
</div>`;

h = h.replace(oldBannerRegex, newBanner);

// 2. CSS me Cover Photo ka design add karo
const coverCSS = `
/* COVER PHOTO BANNER */
.banner{
    margin: 20px;
    border-radius: 24px;
    position: relative;
    overflow: hidden;
    height: 200px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    border: 2px dashed rgba(255,195,25,0.4);
    background: rgba(10,21,53,0.6);
    transition: 0.3s;
}
.banner:active { transform: scale(0.98); }
.banner.has-photo { border: 2px solid #ffc419; }

.cover-photo{
    position: absolute; inset: 0;
    background-size: cover;
    background-position: center;
    z-index: 0;
    transition: 0.3s;
}
.cover-overlay{
    position: absolute; inset: 0;
    background: linear-gradient(to top, rgba(2,4,10,0.9), rgba(2,4,10,0.3));
    z-index: 1;
}
.cover-content{
    position: relative; z-index: 2;
    text-align: center;
}
.cover-icon{
    font-size: 50px;
    margin-bottom: 10px;
    filter: drop-shadow(0 0 20px rgba(255,195,25,0.5));
}
.banner h2{
    font-size: 24px; font-weight: 900; margin-bottom: 4px;
    text-shadow: 0 2px 10px rgba(0,0,0,0.8);
}
.banner h2 span { color: #ffc419; }
.banner p {
    font-size: 12px; color: #fff; opacity: 0.8;
    text-shadow: 0 2px 5px rgba(0,0,0,0.8);
}
.cover-edit-icon{
    position: absolute; top: 16px; right: 16px;
    width: 36px; height: 36px; border-radius: 50%;
    background: rgba(255,195,25,0.9);
    display: grid; place-items: center;
    font-size: 16px; z-index: 3;
    box-shadow: 0 4px 15px rgba(0,0,0,0.5);
}

/* PROFILE PHOTO (Chhota) */
.player-avatar-wrap{
    position: absolute; bottom: -40px; left: 50%; transform: translateX(-50%);
    width: 80px; height: 80px; z-index: 10; cursor: pointer;
}
.player-avatar{
    width: 80px; height: 80px; border-radius: 50%;
    background: #0a1535; border: 4px solid #02040a;
    display: grid; place-items: center; font-size: 32px;
    overflow: hidden; box-shadow: 0 0 20px rgba(0,0,0,0.8);
}
.player-avatar img { width: 100%; height: 100%; object-fit: cover; }
.avatar-edit-badge{
    position: absolute; bottom: 0; right: 0;
    width: 26px; height: 26px; border-radius: 50%;
    background: #ffc419; display: grid; place-items: center;
    font-size: 12px; border: 2px solid #02040a;
}

/* Profile Name niche */
.profile-name { text-align: center; margin-top: 50px; margin-bottom: 20px; }
.profile-name h3 { font-size: 22px; font-weight: 900; color: #fff; }
.profile-name p { font-size: 12px; color: #ffc419; font-weight: 700; letter-spacing: 1px; margin-top: 4px; }
`;

// Purani avatar CSS hatao
h = h.replace(/\/\* PLAYER AVATAR \*\/[\s\S]*?box-shadow:0 0 10px rgba\(0,0,0,0\.5\)\}/, '');
h = h.replace('</style>', coverCSS + '\n</style>');

// 3. Profile photo + Name ka structure add karo (banner ke just baad)
const profileInfoHTML = `
<div class="player-avatar-wrap" onclick="event.stopPropagation(); document.getElementById('avatarInput').click()">
    <div class="player-avatar" id="playerAvatar">👤</div>
    <div class="avatar-edit-badge">📷</div>
</div>
<input type="file" id="avatarInput" accept="image/*" style="display:none" onchange="handleAvatarUpload(event)">

<div class="profile-name">
    <h3 id="profileNameDisplay">Player</h3>
    <p>PLAYER ACCOUNT</p>
</div>
`;

// Banner ke closing div ke baad add karo
h = h.replace('</div>\n\n<!-- INFO CARD -->', '</div>\n' + profileInfoHTML + '\n<!-- INFO CARD -->');

// 4. JS me logic update karo
const coverJS = `
// COVER & AVATAR LOGIC
function loadPhotos() {
    const cover = localStorage.getItem('iba_cover');
    const avatar = localStorage.getItem('iba_photo');
    const name = localStorage.getItem('iba_name') || 'Player';
    
    if(cover) {
        document.getElementById('coverPhoto').style.backgroundImage = 'url(' + cover + ')';
        document.getElementById('coverBanner').classList.add('has-photo');
    }
    if(avatar) {
        document.getElementById('playerAvatar').innerHTML = '<img src="' + avatar + '">';
    }
    document.getElementById('profileNameDisplay').textContent = name;
}

function handleCoverUpload(e) {
    const file = e.target.files[0];
    if(!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
        document.getElementById('coverPhoto').style.backgroundImage = 'url(' + ev.target.result + ')';
        document.getElementById('coverBanner').classList.add('has-photo');
        localStorage.setItem('iba_cover', ev.target.result);
        alert('✅ Cover photo updated!');
    };
    reader.readAsDataURL(file);
    e.target.value = '';
}

function handleAvatarUpload(e) {
    const file = e.target.files[0];
    if(!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
        const img = new Image();
        img.onload = () => {
            const canvas = document.createElement('canvas');
            canvas.width = 300; canvas.height = 300;
            const ctx = canvas.getContext('2d');
            const size = Math.min(img.width, img.height);
            ctx.drawImage(img, (img.width-size)/2, (img.height-size)/2, size, size, 0, 0, 300, 300);
            const data = canvas.toDataURL('image/jpeg', 0.85);
            
            document.getElementById('playerAvatar').innerHTML = '<img src="' + data + '">';
            localStorage.setItem('iba_photo', data);
            
            const userId = localStorage.getItem('iba_userId');
            fetch(SERVER + '/api/user/update-profile', {
                method: 'POST', headers: {'Content-Type':'application/json'},
                body: JSON.stringify({ userId, photo: data })
            });
            alert('✅ Profile photo updated!');
        };
        img.src = ev.target.result;
    };
    reader.readAsDataURL(file);
    e.target.value = '';
}

loadPhotos();
`;

// Purana loadAvatar hatao aur naya add karo
h = h.replace(/\/\/ AVATAR LOGIC[\s\S]*?loadAvatar\(\);/, coverJS);

fs.writeFileSync('game-profile.html', h);
console.log('✅ Cover Photo + Profile Photo added!');
