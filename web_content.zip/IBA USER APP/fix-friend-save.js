const fs = require('fs');
let h = fs.readFileSync('add-friend.html', 'utf8');

// 1. "Friend Added" wale bade box ko hata kar simple chat option lagao
const oldSuccessCard = /<div class="success-card">[\s\S]*?<\/div>\s*<\/div>/;
const newSuccessCard = `
<div class="friend-card" style="border-color: #00e676; box-shadow: 0 0 30px rgba(0,230,118,0.2);">
    <div class="friend-avatar" style="border-color: #00e676;">
        \${photo ? '<img src="' + photo + '">' : name.charAt(0).toUpperCase()}
    </div>
    <div class="friend-name">\${name}</div>
    <div class="friend-id" style="background: rgba(0,230,118,0.15); color: #00e676; border-color: rgba(0,230,118,0.3);">\${ibaId}</div>
    
    <button class="btn-chat" onclick="location.href='messages.html?role=player&friend=\${userId}'" style="width: 100%; margin-top: 10px;">
        💬 CHAT NOW
    </button>
</div>
`;
h = h.replace(oldSuccessCard, newSuccessCard);

// 2. Friend ko Server par save karne ka logic (localStorage ki jagah)
h = h.replace(
    `function addFriend(userId, name, ibaId, photo) {
    friends.push({ userId, name, ibaId, photo });
    localStorage.setItem('iba_friends', JSON.stringify(friends));`,
    `async function addFriend(userId, name, ibaId, photo) {
    // Server par save karo
    try {
        await fetch(SERVER + '/api/add-friend', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                myId: localStorage.getItem('iba_userId'),
                friendId: userId,
                friendName: name,
                friendIbaId: ibaId,
                friendPhoto: photo
            })
        });
    } catch(e) { console.log('Save failed'); }
    
    // Local storage me bhi save karo (fast load ke liye)
    friends.push({ userId, name, ibaId, photo });
    localStorage.setItem('iba_friends', JSON.stringify(friends));`
);

fs.writeFileSync('add-friend.html', h);
console.log('✅ Friend Added box simplified & Server save added!');
