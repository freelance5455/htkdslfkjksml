const fs = require('fs');
let h = fs.readFileSync('support.html', 'utf8');

// renderMessage function me user avatar ke liye photo use karo
const oldRender = `function renderMessage(m){
    const isUser = m.from === 'user';
    const time = formatTime(m.time);
    const initial = isUser ? (userName.charAt(0).toUpperCase()) : '🎧';`;

const newRender = `function renderMessage(m){
    const isUser = m.from === 'user';
    const time = formatTime(m.time);
    const userPhoto = localStorage.getItem('iba_photo') || '';
    let initial;
    if (isUser) {
        if (userPhoto) {
            initial = '<img src="' + userPhoto + '" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:50%">';
        } else {
            initial = userName.charAt(0).toUpperCase();
        }
    } else {
        initial = '🎧';
    }`;

if (h.includes(oldRender)) {
    h = h.replace(oldRender, newRender);
    console.log('✅ Chat avatar fixed');
} else {
    // Regex fallback
    const regex = /const initial = isUser \? \(userName\.charAt\(0\)\.toUpperCase\(\)\) : '🎧';/;
    h = h.replace(regex, `const userPhoto = localStorage.getItem('iba_photo') || '';
    let initial;
    if (isUser) {
        if (userPhoto) {
            initial = '<img src="' + userPhoto + '" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:50%">';
        } else {
            initial = userName.charAt(0).toUpperCase();
        }
    } else {
        initial = '🎧';
    }`);
    console.log('✅ Chat avatar fixed (regex)');
}

fs.writeFileSync('support.html', h);
console.log('✅ Done!');
