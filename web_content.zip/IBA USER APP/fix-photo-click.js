const fs = require('fs');
let h = fs.readFileSync('dashboard.html', 'utf8');

// 1. Avatar ke andar img pe pointer-events:none lagao
if (!h.includes('.avatar-main img{')) {
    h = h.replace(
        '.avatar-main{',
        '.avatar-main img{pointer-events:none;user-select:none}\n.avatar-main{'
    );
    console.log('✅ img pointer-events fixed');
}

// 2. Avatar-main pe cursor pointer (agar nahi hai)
if (!h.includes('.avatar-main{cursor:pointer')) {
    h = h.replace(
        '.avatar-main{',
        '.avatar-main{cursor:pointer;'
    );
    console.log('✅ cursor pointer added');
}

// 3. Duplicate modal check karo aur hatao
const modalMatches = h.match(/id="viewPhotoModal"/g);
if (modalMatches && modalMatches.length > 1) {
    console.log('⚠️ ' + modalMatches.length + ' modals found, removing duplicates...');
    // Sirf last wala rakho, pehle wale hatao
    let count = 0;
    h = h.replace(/<div class="modal" id="viewPhotoModal">[\s\S]*?<\/div>\s*<\/div>\s*<\/div>/g, function(match) {
        count++;
        if (count === 1) return match;
        return '';
    });
}

// 4. viewPhoto function ko improve karo - agar photo nahi hai toh message
const oldFn = `function viewPhoto(){
    const photo = localStorage.getItem('iba_photo');
    if(!photo){
        if(typeof showToast === 'function') showToast('No photo uploaded');
        return;
    }
    document.getElementById('fullPhoto').src = photo;
    document.getElementById('viewPhotoModal').classList.add('show');
    document.body.style.overflow = 'hidden';
}`;

const newFn = `function viewPhoto(){
    // Photo check karo - localStorage se
    let photo = localStorage.getItem('iba_photo');
    
    // Agar localStorage me nahi hai, toh avatar img se lo
    if(!photo){
        const avatarImg = document.querySelector('.avatar-main img');
        if(avatarImg && avatarImg.src) photo = avatarImg.src;
    }
    
    if(!photo){
        if(typeof showToast === 'function'){ showToast('No photo uploaded'); }
        else { alert('No photo uploaded'); }
        return;
    }
    
    const img = document.getElementById('fullPhoto');
    const modal = document.getElementById('viewPhotoModal');
    
    if(!img || !modal){
        alert('Photo viewer not available');
        return;
    }
    
    img.src = photo;
    modal.classList.add('show');
    document.body.style.overflow = 'hidden';
    console.log('📸 Opening photo:', photo.substring(0, 50) + '...');
}`;

if (h.includes(oldFn)) {
    h = h.replace(oldFn, newFn);
    console.log('✅ viewPhoto improved');
} else {
    // Regex fallback
    h = h.replace(/function viewPhoto\(\)\{[\s\S]*?\n\}/, newFn);
    console.log('✅ viewPhoto replaced');
}

fs.writeFileSync('dashboard.html', h);
console.log('✅ Done!');
