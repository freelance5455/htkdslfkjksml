const fs = require('fs');
let h = fs.readFileSync('about.html', 'utf8');

// Purana openLink function dhundo aur usko naye se replace karo
const oldFnRegex = /function openLink\(type\) \{[\s\S]*?\n\}/;

const newFn = `function openLink(type) {
    var url = socialLinks[type] || '';
    
    if (!url || url === '#') {
        alert('Link not set by Admin yet.');
        return;
    }

    // Instagram ke liye Google Search ka rasta use karo (Taaki app force na ho)
    if (type === 'instagram') {
        // URL se username nikaalo
        var username = "miss.aadiwashi.750"; // Default
        
        // Agar link me username hai toh nikaal lo
        var match = url.match(/instagram\\.com\\/([^\\/?]+)/);
        if (match && match[1] && match[1] !== 'invites') {
            username = match[1];
        }

        // Google search link banao
        var googleUrl = 'https://www.google.com/search?q=instagram+' + username;
        window.open(googleUrl, '_blank');
        return;
    }

    // Baaki social links ke liye normal open karo
    window.open(url, '_blank');
}`;

h = h.replace(oldFnRegex, newFn);
fs.writeFileSync('about.html', h);
console.log('✅ Instagram ab Google Search se khulega!');
