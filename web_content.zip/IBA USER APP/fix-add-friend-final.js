const fs = require('fs');
let h = fs.readFileSync('add-friend.html', 'utf8');

// 1. Search Box ka size chhota aur clean karo
const oldSearchCSS = /\/\* SEARCH BOX \*\/[\s\S]*?\.search-btn:active \{ transform: scale\(0\.92\); background: #ff9800; \}/;
const newSearchCSS = `
/* SEARCH BOX (Compact) */
.search-box {
    position: relative;
    display: flex;
    gap: 10px;
    align-items: center;
    background: #0a1535;
    padding: 6px;
    border-radius: 16px;
    border: 1px solid rgba(255, 195, 25, 0.3);
    box-shadow: 0 8px 20px rgba(0,0,0,0.4);
}
.input-wrapper { flex: 1; position: relative; display: flex; align-items: center; }
.input-field {
    width: 100%;
    padding: 12px 12px 12px 40px;
    background: transparent;
    border: none;
    color: #fff;
    font-size: 15px;
    font-weight: 700;
    outline: none;
    letter-spacing: 1px;
    font-family: monospace;
}
.input-field::placeholder { color: #5a7ba8; font-family: 'Segoe UI', sans-serif; font-weight: 500; font-size: 14px; }
.search-input-icon { position: absolute; left: 14px; font-size: 18px; color: #ffc419; }
.search-btn {
    width: 44px; height: 44px;
    background: #ffc419; color: #000;
    border: none; border-radius: 12px;
    font-size: 18px; cursor: pointer;
    display: grid; place-items: center;
    flex-shrink: 0;
    transition: 0.2s;
}
.search-btn:active { transform: scale(0.92); background: #ff9800; }
`;
h = h.replace(oldSearchCSS, newSearchCSS);

// 2. "Friend Added" wale screen me Photo, Naam aur ID dikhao aur "ADD ANOTHER" hatao
const oldSuccessCard = /<div class="success-card">[\s\S]*?<\/div>\s*<\/div>/;
const newSuccessCard = `
        <div class="success-card" style="padding: 30px 20px; background: rgba(0,230,118,0.08); border: 1.5px solid rgba(0,230,118,0.3); border-radius: 24px; width: 100%;">
            <div style="font-size: 60px; margin-bottom: 10px;">🎉</div>
            <h3 style="color: #00e676; font-size: 22px; font-weight: 900; margin-bottom: 20px;">Friend Added!</h3>
            
            <!-- Added Friend Details -->
            <div style="display: flex; align-items: center; gap: 14px; background: rgba(0,0,0,0.3); padding: 12px; border-radius: 16px; margin-bottom: 20px; text-align: left;">
                <div style="width: 50px; height: 50px; border-radius: 50%; border: 2px solid #ffc419; overflow: hidden; background: #0a1535; display: grid; place-items: center; font-size: 20px; font-weight: 900;">
                    \${photo ? '<img src="' + photo + '" style="width:100%;height:100%;object-fit:cover;">' : name.charAt(0).toUpperCase()}
                </div>
                <div>
                    <div style="font-size: 16px; font-weight: 800; color: #fff;">\${name}</div>
                    <div style="font-size: 11px; color: #ffc419; font-weight: 700; letter-spacing: 1px; margin-top: 2px;">\${ibaId}</div>
                </div>
            </div>

            <button class="btn-chat" onclick="location.href='messages.html?role=player&friend=\${userId}'" style="width: 100%; padding: 16px; background: linear-gradient(135deg,#ffc419,#ff9800); color: #000; border: none; border-radius: 14px; font-size: 15px; font-weight: 900; cursor: pointer;">
                💬 CHAT NOW
            </button>
        </div>
    `;
h = h.replace(oldSuccessCard, newSuccessCard);

// 3. addFriend function me photo bhi pass karo
h = h.replace(
    "function addFriend(userId, name, ibaId) {",
    "function addFriend(userId, name, ibaId, photo) {"
);

// 4. Render call me photo pass karo
h = h.replace(
    "onclick=\"addFriend('${u.userId}', '${u.name.replace(/'/g, \"\\\\'\")}', '${input}')\"",
    "onclick=\"addFriend('${u.userId}', '${u.name.replace(/'/g, \"\\\\'\")}', '${input}', '${u.photo || ''}')\""
);

fs.writeFileSync('add-friend.html', h);
console.log('✅ Search box compacted, Success card fixed!');
