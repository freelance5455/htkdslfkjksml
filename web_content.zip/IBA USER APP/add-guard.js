const fs = require('fs');
let h = fs.readFileSync('dashboard.html', 'utf8');

if (h.includes('iba_dashboard_guard')) {
    console.log('already exists');
    process.exit(0);
}

// Dashboard load hone se pehle guard lagao
const guard = `
<script id="iba_dashboard_guard">
(async function(){
    const userId = localStorage.getItem('iba_userId');
    const mobile = localStorage.getItem('iba_mobile');

    // 1. Login hi nahi hai → login page
    if(!userId || !mobile){
        location.replace('login.html');
        return;
    }

    // 2. Server pe check karo user registered hai ya nahi
    try{
        const r = await fetch('http://localhost:3102/api/user/check/' + mobile);
        const d = await r.json();

        if(!d.success || !d.exists){
            // User file nahi hai → register page
            localStorage.clear();
            location.replace('login.html');
            return;
        }

        // 3. Check karo profile complete hai (name + photo + dob)
        const pr = await fetch('http://localhost:3102/api/user/profile/' + userId);
        const pd = await pr.json();
        if(pd.success && pd.profile){
            const p = pd.profile;
            if(!p.name || p.name === 'Player' || !p.photo || !p.dob || !p.email){
                // Profile incomplete → register page
                sessionStorage.setItem('iba_mobile', p.mobile);
                sessionStorage.setItem('iba_userId', p.userId);
                location.replace('register.html');
                return;
            }
        } else {
            localStorage.clear();
            location.replace('login.html');
            return;
        }
    }catch(e){
        // Server band hai → login page
        location.replace('login.html');
        return;
    }
})();
</script>
`;

// </head> ke turant baad insert karo
const headIdx = h.indexOf('</head>');
if (headIdx !== -1) {
    h = h.slice(0, headIdx) + guard + h.slice(headIdx);
    fs.writeFileSync('dashboard.html', h);
    console.log('✅ Dashboard guard added');
} else {
    console.log('❌ head not found');
}
