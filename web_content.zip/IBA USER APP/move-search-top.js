const fs = require('fs');
let h = fs.readFileSync('add-friend.html', 'utf8');

// 1. MY ID CARD ka HTML block nikaalo
const myIdCardRegex = /<!-- MY ID CARD -->[\s\S]*?<\/div>\s*<\/div>/;
const myIdCardMatch = h.match(myIdCardRegex);

if (myIdCardMatch) {
    const myIdCard = myIdCardMatch[0];
    
    // Usko HTML se hatao
    h = h.replace(myIdCard, '');
    
    // 2. Search Box ke theek baad daal do
    h = h.replace(
        /(<div class="search-box">[\s\S]*?<\/div>\s*<\/div>)/,
        '$1\n\n    ' + myIdCard
    );
    
    console.log('✅ Search box moved to top!');
} else {
    console.log('❌ MY ID CARD not found');
}

fs.writeFileSync('add-friend.html', h);
