const fs = require('fs');
let h = fs.readFileSync('add-friend.html', 'utf8');

// 1. Purana "Extra" chat button (jo card ke bahar hai) hatao
// Pichli baar humne 2 jagah render kiya tha, usko ek clean code se replace karo.
const oldSuccessCardRegex = /result\.innerHTML = `[\s\S]*?<\/div>\s*`;/;

const newSuccessCard = `result.innerHTML = \`
<div class="friend-card" style="border-color: #00e676; box-shadow: 0 0 30px rgba(0,230,118,0.2);">
    <div class="friend-avatar" style="border-color: #00e676;">
        \${photo ? '<img src="' + photo + '">' : name.charAt(0).toUpperCase()}
    </div>
    <div class="friend-name">\${name}</div>
    <div class="friend-id" style="background: rgba(0,230,118,0.15); color: #00e676; border-color: rgba(0,230,118,0.3);">\${ibaId}</div>
    
    <button class="btn-chat" onclick="location.href='messages.html?role=player&friend=\${userId}'" style="width: 100%; margin-top: 10px;">
        💬 CHAT NOW
    </button>
</div>
\`;`;

h = h.replace(oldSuccessCardRegex, newSuccessCard);

// 2. Extra CSS hatao (agar koi bacha ho)
h = h.replace(/\.btn-chat \{[\s\S]*?\.btn-chat:active \{ transform: scale\(0\.96\) \}/g, '');

fs.writeFileSync('add-friend.html', h);
console.log('✅ Extra Chat button removed!');
