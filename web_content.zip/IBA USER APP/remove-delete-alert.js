const fs = require('fs');
let h = fs.readFileSync('messages.html', 'utf8');

// 1. confirmDelete function me se "alert('✅ Friend removed!')" line hatao
h = h.replace(
    "closeDeletePopup();\n            alert('✅ Friend removed!');\n            window.location.href = 'add-friend.html';",
    "closeDeletePopup();\n            window.location.href = 'add-friend.html';"
);

// 2. Agar 'alert' line kisi aur jagah bachi ho toh use bhi hatao
h = h.replace(/alert\('✅ Friend removed!'\);/g, '');

fs.writeFileSync('messages.html', h);
console.log('✅ Delete alert removed!');
