const fs = require('fs');
let h = fs.readFileSync('dashboard.html', 'utf8');

// Check karo pehle se hai kya
if (h.includes('viewPhotoModal')) {
    console.log('ℹ️ Photo viewer already exists, updating...');
}

// ===== 1. Avatar pe onclick add karo (agar nahi hai) =====
if (!h.includes('onclick="viewPhoto()"') && h.includes('<div class="avatar-main" id="profileAvatar">')) {
    h = h.replace(
        '<div class="avatar-main" id="profileAvatar">',
        '<div class="avatar-main" id="profileAvatar" onclick="viewPhoto()" style="cursor:pointer">'
    );
    console.log('✅ Avatar onclick added');
}

// ===== 2. Photo View Modal + CSS + JS add karo (agar nahi hai) =====
if (!h.includes('viewPhotoModal')) {
    // CSS
    const photoCSS = `
.photo-view-modal{position:fixed;inset:0;z-index:9999;background:rgba(0,5,15,.96);backdrop-filter:blur(15px);display:none;align-items:center;justify-content:center;flex-direction:column;padding:20px}
.photo-view-modal.show{display:flex;animation:fadeIn .3s}
@keyframes fadeIn{from{opacity:0}to{opacity:1}}
.photo-view-img{max-width:90vw;max-height:65vh;border-radius:24px;border:3px solid rgba(0,150,255,.6);box-shadow:0 0 60px rgba(0,150,255,.7),0 0 120px rgba(0,150,255,.4);animation:zoomIn .4s cubic-bezier(.4,0,.2,1)}
@keyframes zoomIn{from{transform:scale(.5);opacity:0}to{transform:scale(1);opacity:1}}
.photo-view-close{margin-top:24px;padding:14px 40px;background:linear-gradient(135deg,#0088ff,#00a8ff);color:#fff;border:none;border-radius:14px;font-size:15px;font-weight:800;letter-spacing:1px;cursor:pointer;box-shadow:0 8px 25px rgba(0,150,255,.5);transition:.2s}
.photo-view-close:active{transform:scale(.96)}
.photo-view-label{margin-top:16px;color:#a8bddc;font-size:13px;letter-spacing:2px;font-weight:600}
`;

    h = h.replace('</style>', photoCSS + '\n</style>');

    // Modal HTML
    const modalHTML = `
<div class="photo-view-modal" id="viewPhotoModal">
    <img class="photo-view-img" id="fullPhoto" alt="Profile Photo">
    <div class="photo-view-label">PROFILE PHOTO</div>
    <button class="photo-view-close" onclick="closeViewPhoto()">CLOSE</button>
</div>
`;

    h = h.replace('</body>', modalHTML + '\n</body>');

    // JS
    const photoJS = `
function viewPhoto(){
    const photo = localStorage.getItem('iba_photo');
    if(!photo){
        if(typeof showToast === 'function') showToast('No photo uploaded');
        return;
    }
    document.getElementById('fullPhoto').src = photo;
    document.getElementById('viewPhotoModal').classList.add('show');
    document.body.style.overflow = 'hidden';
}
function closeViewPhoto(){
    document.getElementById('viewPhotoModal').classList.remove('show');
    document.body.style.overflow = '';
}
document.addEventListener('DOMContentLoaded', function(){
    const pv = document.getElementById('viewPhotoModal');
    if(pv){
        pv.addEventListener('click', function(e){
            if(e.target.id === 'viewPhotoModal') closeViewPhoto();
        });
    }
});
`;

    const lastScriptIdx = h.lastIndexOf('</script>');
    h = h.slice(0, lastScriptIdx) + photoJS + '\n' + h.slice(lastScriptIdx);

    console.log('✅ Photo viewer added');
}

// ===== 3. Avatar pe click cursor bhi add karo =====
h = h.replace(
    '.avatar-main{',
    '.avatar-main{cursor:pointer;'
);

// ===== 4. Avatar click indicator (zoom icon) =====
if (!h.includes('zoom-indicator')) {
    const zoomIcon = `
.avatar-main::after{content:"🔍";position:absolute;bottom:6px;right:6px;font-size:14px;width:26px;height:26px;border-radius:50%;background:rgba(0,150,255,.85);display:grid;place-items:center;opacity:0;transition:.3s;box-shadow:0 0 15px rgba(0,150,255,.6)}
.avatar-main:active::after,.avatar-main:hover::after{opacity:1}
`;
    h = h.replace('</style>', zoomIcon + '\n</style>');
}

fs.writeFileSync('dashboard.html', h);
console.log('✅ Done!');
