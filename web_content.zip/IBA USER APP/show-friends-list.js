const fs = require('fs');
let h = fs.readFileSync('add-friend.html', 'utf8');

// 1. HTML me Search ke niche "My Friends" section add karo
const friendsListHTML = `
    <!-- MY FRIENDS LIST -->
    <div class="my-friends-section" style="margin-top:24px;">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
            <h3 style="font-size:16px; font-weight:900; color:#fff;">👥 My Friends</h3>
            <span id="friendCount" style="font-size:12px; color:#ffc419; font-weight:700; background:rgba(255,195,25,0.1); padding:2px 8px; border-radius:6px;">0</span>
        </div>
        <div id="friendsContainer">
            <!-- Friends will load here -->
        </div>
    </div>
`;

// Search result ke baad add karo
h = h.replace(
    '<div class="result-area" id="resultArea">',
    friendsListHTML + '\n<div class="result-area" id="resultArea">'
);

// 2. JS me function add karo jo server se friends load kare aur dikhaye
const loadFriendsJS = `
// LOAD FRIENDS FROM SERVER
async function loadMyFriends() {
    var myId = localStorage.getItem('iba_userId');
    var container = document.getElementById('friendsContainer');
    var countEl = document.getElementById('friendCount');
    
    if(!myId) return;
    
    try {
        var res = await fetch(SERVER + '/api/my-friends/' + myId);
        var data = await res.json();
        
        if(data.success && data.friends && data.friends.length > 0) {
            countEl.textContent = data.friends.length;
            container.innerHTML = data.friends.map(function(f) {
                return '<div class="friend-item" style="display:flex; align-items:center; gap:12px; padding:12px; background:rgba(10,21,53,0.6); border:1px solid rgba(255,255,255,0.1); border-radius:16px; margin-bottom:10px;">' +
                    '<div style="width:46px; height:46px; border-radius:50%; border:2px solid #ffc419; overflow:hidden; background:#0a1535; display:grid; place-items:center; font-size:18px; font-weight:900; flex-shrink:0;">' +
                        (f.photo ? '<img src="' + f.photo + '" style="width:100%;height:100%;object-fit:cover;">' : f.name.charAt(0).toUpperCase()) +
                    '</div>' +
                    '<div style="flex:1; min-width:0;">' +
                        '<div style="font-size:14px; font-weight:800; color:#fff; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">' + f.name + '</div>' +
                        '<div style="font-size:11px; color:#ffc419; font-weight:700; letter-spacing:1px; margin-top:2px;">' + f.ibaId + '</div>' +
                    '</div>' +
                    '<button onclick="event.stopPropagation(); chatWithFriend(\\'' + f.userId + '\\')" style="padding:8px 12px; background:#ffc419; color:#000; border:none; border-radius:8px; font-size:11px; font-weight:900; cursor:pointer; margin-right:4px;">CHAT</button>' +
                    '<button onclick="event.stopPropagation(); deleteFriend(\\'' + f.userId + '\\', \\'' + f.name + '\\')" style="padding:8px 10px; background:rgba(255,59,59,0.15); color:#ff3b3b; border:1px solid rgba(255,59,59,0.3); border-radius:8px; font-size:14px; cursor:pointer;">🗑️</button>' +
                '</div>';
            }).join('');
        } else {
            countEl.textContent = '0';
            container.innerHTML = '<div style="text-align:center; padding:20px; color:#6b8bb8; font-size:12px;">No friends added yet. Search above to add.</div>';
        }
    } catch(e) {
        container.innerHTML = '<div style="text-align:center; padding:20px; color:#ff6b6b; font-size:12px;">Failed to load friends</div>';
    }
}

function chatWithFriend(userId) {
    location.href = 'messages.html?role=player&friend=' + userId;
}

async function deleteFriend(friendId, friendName) {
    if(!confirm('Delete ' + friendName + ' from friends?')) return;
    
    var myId = localStorage.getItem('iba_userId');
    
    try {
        var res = await fetch(SERVER + '/api/delete-friend/' + myId + '/' + friendId, {
            method: 'DELETE'
        });
        var data = await res.json();
        
        // LocalStorage se bhi delete karo
        var friends = JSON.parse(localStorage.getItem('iba_friends') || '[]');
        friends = friends.filter(function(f) { return f.userId !== friendId; });
        localStorage.setItem('iba_friends', JSON.stringify(friends));
        
        alert('✅ Friend deleted!');
        loadMyFriends(); // Refresh list
    } catch(e) {
        alert('Delete failed');
    }
}

// Page load hote hi friends list load karo
loadMyFriends();
`;

// JS me add karo
h = h.replace('</script>', loadFriendsJS + '\n</script>');

// 3. Friend add hone ke baad list refresh karo
h = h.replace(
    "function addFriend(userId, name, ibaId, photo) {",
    "function addFriend(userId, name, ibaId, photo) {\n    setTimeout(function() { loadMyFriends(); }, 1500);"
);

fs.writeFileSync('add-friend.html', h);
console.log('✅ Friends list added to Add Friend page!');
