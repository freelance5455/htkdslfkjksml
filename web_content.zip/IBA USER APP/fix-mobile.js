const fs = require('fs');
let h = fs.readFileSync('register.html', 'utf8');

// Purana auto-fill code hatao
h = h.replace(/\/\/ Agar OTP page se redirect hua hai[\s\S]*?toggleValid\('wrapMobile', true\);\n\}/g, '');

// Naya auto-fill code add karo
const newCode = `
// ===== AUTO-FILL MOBILE FROM OTP VERIFICATION =====
(function(){
    const verifiedMobile = sessionStorage.getItem('iba_mobile') || sessionStorage.getItem('iba_verified_mobile');
    const cameFromOtp = sessionStorage.getItem('iba_from_otp') === '1';

    if(verifiedMobile && verifiedMobile.length === 10){
        const mi = document.getElementById('mobileInput');
        if(mi){
            mi.value = verifiedMobile;
            mi.readOnly = true;
            mi.style.color = '#00e08a';
            mi.style.fontWeight = '700';
            mi.style.cursor = 'not-allowed';
            // Green checkmark dikhao
            const wrap = document.getElementById('wrapMobile');
            if(wrap){
                wrap.classList.add('valid');
                wrap.style.borderColor = 'rgba(0,224,138,.5)';
                wrap.style.background = 'rgba(0,224,138,.05)';
            }
            // Label update karo
            const label = wrap.parentElement.querySelector('label');
            if(label){
                label.innerHTML = 'Mobile Number <span style="color:#00e08a;font-size:11px">✓ VERIFIED</span>';
            }
        }
    }
})();
`;

// Script tag ke shuru me add karo
h = h.replace(
    "const SERVER = \"http://localhost:3102\";",
    "const SERVER = \"http://localhost:3102\";\n" + newCode
);

fs.writeFileSync('register.html', h);
console.log('✅ register.html updated');
