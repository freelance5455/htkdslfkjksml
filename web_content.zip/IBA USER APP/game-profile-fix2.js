const fs = require('fs');
let h = fs.readFileSync('game-profile.html', 'utf8');

// 1. Purana crop wala bekar code hatao
const startIdx = h.indexOf('// COVER & AVATAR LOGIC');
const endIdx = h.indexOf('loadPhotos();') + 12;
if(startIdx !== -1 && endIdx !== -1) {
    h = h.slice(0, startIdx) + h.slice(endIdx);
}

// 2. Simple Modal HTML add karo
const modalHTML = `
<!-- SIMPLE CROP MODAL -->
<div id="simpleCropModal" style="position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,0.95);display:none;flex-direction:column;align-items:center;justify-content:center;">
    <div style="position:relative; width:300px; height:300px; overflow:hidden; border-radius:50%; border:3px solid #ffc419; background:#000;">
        <img id="cropImg" style="position:absolute; width:100%; height:auto; cursor:grab; transform-origin:center;">
    </div>
    <input type="range" id="cropZoomSlider" min="1" max="3" step="0.1" value="1" style="width:250px; margin-top:30px;">
    <div style="display:flex; gap:15px; margin-top:20px;">
        <button onclick="document.getElementById('simpleCropModal').style.display='none'" style="padding:12px 24px; background:#333; color:#fff; border:none; border-radius:10px; font-weight:bold;">Cancel</button>
        <button id="cropSaveBtn" style="padding:12px 24px; background:#ffc419; color:#000; border:none; border-radius:10px; font-weight:bold;">Save Photo</button>
    </div>
</div>
`;
h = h.replace('</body>', modalHTML + '\n</body>');

// 3. Simple JS logic add karo
const jsCode = `
const SERVER = "http://localhost:3102";
let imgObj = new Image();
let currentType = '';
let isDragging = false;
let startX, startY, imgX = 0, imgY = 0;

// Load saved photos
function loadSavedPhotos() {
    const cover = localStorage.getItem('iba_cover');
    const avatar = localStorage.getItem('iba_photo');
    const name = localStorage.getItem('iba_name') || 'Player';
    
    if(cover) {
        document.getElementById('coverPhoto').style.backgroundImage = 'url(' + cover + ')';
        document.getElementById('coverBanner').classList.add('has-photo');
    }
    if(avatar) {
        document.getElementById('playerAvatar').innerHTML = '<img src="' + avatar + '">';
    }
    document.getElementById('profileNameDisplay').textContent = name;
}
loadSavedPhotos();

// Trigger File Input
function handleCoverUpload(e) {
    if(e.target.files[0]) {
        currentType = 'cover';
        startCrop(e.target.files[0]);
    }
}
function handleAvatarUpload(e) {
    if(e.target.files[0]) {
        currentType = 'avatar';
        startCrop(e.target.files[0]);
    }
}

// Start Crop Modal
function startCrop(file) {
    const reader = new FileReader();
    reader.onload = (ev) => {
        const cropImg = document.getElementById('cropImg');
        cropImg.src = ev.target.result;
        imgObj.src = ev.target.result;
        
        document.getElementById('cropZoomSlider').value = 1;
        cropImg.style.transform = 'scale(1)';
        
        // Center image initially
        cropImg.style.left = '0px';
        cropImg.style.top = '0px';
        imgX = 0; imgY = 0;
        
        document.getElementById('simpleCropModal').style.display = 'flex';
    };
    reader.readAsDataURL(file);
}

// Zoom Logic
document.getElementById('cropZoomSlider').addEventListener('input', (e) => {
    document.getElementById('cropImg').style.transform = 'scale(' + e.target.value + ')';
});

// Drag Logic (Touch)
const cropImgEl = document.getElementById('cropImg');
cropImgEl.addEventListener('touchstart', (e) => {
    isDragging = true;
    startX = e.touches[0].clientX - imgX;
    startY = e.touches[0].clientY - imgY;
});
cropImgEl.addEventListener('touchmove', (e) => {
    if(isDragging) {
        imgX = e.touches[0].clientX - startX;
        imgY = e.touches[0].clientY - startY;
        cropImgEl.style.left = imgX + 'px';
        cropImgEl.style.top = imgY + 'px';
    }
});
cropImgEl.addEventListener('touchend', () => isDragging = false);

// Save Crop
document.getElementById('cropSaveBtn').addEventListener('click', () => {
    const canvas = document.createElement('canvas');
    canvas.width = 300; canvas.height = 300;
    const ctx = canvas.getContext('2d');
    
    const img = document.getElementById('cropImg');
    const scale = parseFloat(document.getElementById('cropZoomSlider').value);
    
    // Draw circle
    ctx.beginPath();
    ctx.arc(150, 150, 150, 0, Math.PI*2);
    ctx.clip();
    
    ctx.drawImage(imgObj, (imgX * -1) + (150 - (imgObj.width * scale)/2), (imgY * -1) + (150 - (imgObj.height * scale)/2), imgObj.width * scale, imgObj.height * scale);
    
    const data = canvas.toDataURL('image/jpeg', 0.8);
    
    if(currentType === 'avatar') {
        localStorage.setItem('iba_photo', data);
        document.getElementById('playerAvatar').innerHTML = '<img src="' + data + '">';
        
        // Save to server
        const userId = localStorage.getItem('iba_userId');
        if(userId) {
            fetch(SERVER + '/api/user/update-profile', {
                method: 'POST', headers: {'Content-Type':'application/json'},
                body: JSON.stringify({ userId, photo: data })
            });
        }
    } else {
        localStorage.setItem('iba_cover', data);
        document.getElementById('coverPhoto').style.backgroundImage = 'url(' + data + ')';
    }
    
    document.getElementById('simpleCropModal').style.display = 'none';
    alert('✅ Photo Saved!');
});
`;
h = h.replace('</script>', jsCode + '\n</script>');

fs.writeFileSync('game-profile.html', h);
console.log('✅ SIMPLE CROP MODAL READY!');
