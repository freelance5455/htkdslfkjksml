const fs = require('fs');

// 1. Edit Profile Fix
let h = fs.readFileSync('edit-profile.html', 'utf8');

// Photo wrapper ko <label> me badlo (WebView me sabse reliable tarika)
const oldAvatar = `<div class="avatar-wrap" onclick="document.getElementById('photoInput').click()">`;
const newAvatar = `<label for="photoInput" class="avatar-wrap" style="cursor:pointer; display:block;">`;

if (h.includes(oldAvatar)) {
    h = h.replace(oldAvatar, newAvatar);
    
    // Input ko visible rakho par transparent karo (WebView ke liye)
    h = h.replace(
        '<input type="file" id="photoInput" accept="image/*" onchange="handlePhoto(event)">',
        '<input type="file" id="photoInput" accept="image/*" onchange="handlePhoto(event)" style="opacity:0; position:absolute; width:100px; height:100px; top:0; left:50%; transform:translateX(-50%); z-index:10; cursor:pointer;">'
    );
    
    // Purana closing div ko label se badlo
    h = h.replace(
        '</div>\n        <input type="file" id="photoInput"',
        '</label>\n        <input type="file" id="photoInput"'
    );
    
    console.log('✅ Edit Profile photo fixed!');
}

fs.writeFileSync('edit-profile.html', h);

// 2. Register Fix
let r = fs.readFileSync('register.html', 'utf8');

const oldRegAvatar = `<div class="photo-wrap" onclick="document.getElementById('photoInput').click()">`;
const newRegAvatar = `<label for="photoInput" class="photo-wrap" style="cursor:pointer; display:block;">`;

if (r.includes(oldRegAvatar)) {
    r = r.replace(oldRegAvatar, newRegAvatar);
    
    r = r.replace(
        '<input type="file" id="photoInput" accept="image/*" style="display:none;">',
        '<input type="file" id="photoInput" accept="image/*" style="opacity:0; position:absolute; width:120px; height:120px; top:0; left:50%; transform:translateX(-50%); z-index:10; cursor:pointer;">'
    );
    
    r = r.replace(
        '</div>\n            <input type="file" id="photoInput"',
        '</label>\n            <input type="file" id="photoInput"'
    );
    
    console.log('✅ Register photo fixed!');
}

fs.writeFileSync('register.html', r);
