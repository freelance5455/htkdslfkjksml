const fs = require('fs');
let h = fs.readFileSync('about.html', 'utf8');

// Purane openLink function ko hata kar naya lagao
const oldFnRegex = /function openLink\(type\) \{[\s\S]*?\n\}/;

const newFn = `function openLink(type) {
    var url = socialLinks[type] || '';
    
    // Agar link khali hai
    if (!url) {
        alert('Link not set by Admin yet.');
        return;
    }

    // Instagram link ko clean karo
    if (type === 'instagram') {
        // Agar URL me "intent://" ya "applink" hai toh use hatao
        if (url.includes('intent://') || url.includes('applink')) {
            // Extract username from URL
            var match = url.match(/instagram\\.com\\/([^\\/?]+)/);
            if (match && match[1]) {
                url = 'https://www.instagram.com/' + match[1];
            }
        }
        
        // Ensure https:// is present
        if (!url.startsWith('http')) {
            url = 'https://' + url;
        }
    }

    // Open the link in browser
    window.open(url, '_blank');
}`;

h = h.replace(oldFnRegex, newFn);

fs.writeFileSync('about.html', h);
console.log('✅ Instagram link opening fixed!');
