const fs = require('fs');
let h = fs.readFileSync('register.html', 'utf8');

// 1. Purana onclick wala div dhundo
const oldPhotoWrap = `<div class="photo-wrap" onclick="document.getElementById('photoInput').click()">`;

// 2. Usko label banao aur input ko uske andar daalo
const newPhotoWrap = `<label for="photoInput" class="photo-wrap" style="cursor:pointer;">`;

if (h.includes(oldPhotoWrap)) {
    h = h.replace(oldPhotoWrap, newPhotoWrap);
    // Label ko band karne ke liye closing tag dhundho (photo-preview ke baad ka </div>)
    // Waise humne input ko alag rakha hai, toh bas label use karna hai.
    
    // Input ko label ke saath connect karne ke liye usko label ke andar hi daal do
    h = h.replace(
        '<input type="file" id="photoInput" accept="image/*">',
        '' // Purana input hatao
    );
    
    // Naya input label ke andar daalo
    h = h.replace(
        '<div class="photo-badge">',
        '<input type="file" id="photoInput" accept="image/*" style="display:none;" onchange="handlePhotoUpload(event)">\n<div class="photo-badge">'
    );
    
    // Close label (pehle closing </div> tha, ab </label> hoga)
    h = h.replace(
        '</div>\n            <div class="photo-label">',
        '</label>\n            <div class="photo-label">'
    );
    
    // JS function ka naam update karo
    h = h.replace(/document\.getElementById\('photoInput'\)\.addEventListener\('change', function\(e\) \{/, 'function handlePhotoUpload(e) {');
    // Function ke end me extra bracket hatao (agar hai)
    h = h.replace(/reader\.readAsDataURL\(file\);\n    e\.target\.value = '';\n\}\);/, "reader.readAsDataURL(file);\n    e.target.value = '';\n}");
    
    console.log('✅ Register photo upload fixed for APK!');
} else {
    console.log('❌ Photo wrap nahi mila, manual check karo.');
}

fs.writeFileSync('register.html', h);
