const fs = require('fs');
let h = fs.readFileSync('about.html', 'utf8');

// openLink function ko dhundo aur usko naye code se replace karo
const oldFnRegex = /function openLink\(type\) \{[\s\S]*?\n\}/;

const newFn = `function openLink(type) {
    var url = socialLinks[type] || '';
    
    if (!url || url === '#') {
        alert('Link not set by Admin yet.');
        return;
    }

    // Agar URL me intent:// hai toh use saaf karo
    if (url.includes('intent://')) {
        var match = url.match(/instagram\\.com\\/([^\\/?]+)/);
        if (match && match[1]) {
            url = 'https://www.instagram.com/' + match[1];
        }
    }

    // Direct usi tab me kholo (naya tab block na ho)
    window.location.href = url;
}`;

if(oldFnRegex.test(h)) {
    h = h.replace(oldFnRegex, newFn);
    console.log('✅ openLink fixed!');
} else {
    // Agar function na mile toh script ke end me naya function daal do
    h = h.replace('</script>', newFn + '\n</script>');
    console.log('✅ openLink function added!');
}

fs.writeFileSync('about.html', h);
