const fs = require('fs');
let h = fs.readFileSync('add-friend.html', 'utf8');

// 1. Purana "empty-icon-wrap" (gol circle) hatao
h = h.replace(/<div class="empty-icon-wrap">👥<\/div>/g, '<div style="font-size:60px; margin-bottom:16px; opacity:0.8; filter: drop-shadow(0 0 15px rgba(0,168,255,0.3));">👥</div>');

// 2. CSS me se purana circle style hatao
h = h.replace(/\.empty-icon-wrap\{[^}]*\}/g, '');

// 3. Search Box ke background/glow ko thoda clean karo
h = h.replace(
    '.input-field:focus{border-color:#ffc419;box-shadow:0 0 30px rgba(255,195,25,0.2);background:rgba(20,30,60,0.9)}',
    '.input-field:focus{border-color:#ffc419;box-shadow:0 0 15px rgba(255,195,25,0.15);background:rgba(20,30,60,0.9)}'
);

// 4. Search Button ka glow halka karo
h = h.replace(
    '.search-btn{width:60px;height:60px;background:linear-gradient(135deg,#ffc419,#ff9800);color:#000;border:none;border-radius:18px;font-size:24px;cursor:pointer;box-shadow:0 8px 25px rgba(255,195,25,0.4);transition:0.2s;flex-shrink:0;display:grid;place-items:center}',
    '.search-btn{width:60px;height:60px;background:linear-gradient(135deg,#ffc419,#ff9800);color:#000;border:none;border-radius:18px;font-size:24px;cursor:pointer;box-shadow:0 4px 15px rgba(255,195,25,0.2);transition:0.2s;flex-shrink:0;display:grid;place-items:center}'
);

fs.writeFileSync('add-friend.html', h);
console.log('✅ Search area cleaned up!');
