const fs = require('fs');
let h = fs.readFileSync('support.html', 'utf8');

// 1. CSS add karo (bottom sheet)
const menuCSS = `
/* ATTACH MENU (Bottom Sheet) */
.attach-menu{position:fixed;inset:0;z-index:2000;background:rgba(0,5,15,.7);backdrop-filter:blur(8px);display:none;align-items:flex-end;justify-content:center;opacity:0;transition:.3s}
.attach-menu.show{display:flex;opacity:1}
.attach-sheet{background:linear-gradient(180deg,#0a1a3a,#050b1f);border-top-left-radius:24px;border-top-right-radius:24px;border-top:1px solid rgba(0,150,255,.3);padding:20px 20px 30px;width:100%;max-width:520px;transform:translateY(100%);transition:transform .35s cubic-bezier(.4,0,.2,1)}
.attach-menu.show .attach-sheet{transform:translateY(0)}
.attach-sheet-handle{width:40px;height:4px;background:rgba(0,150,255,.3);border-radius:2px;margin:0 auto 16px}
.attach-title{font-size:13px;font-weight:800;color:#00a8ff;letter-spacing:2px;text-align:center;margin-bottom:16px;text-transform:uppercase}
.attach-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:10px}
.attach-opt{display:flex;flex-direction:column;align-items:center;gap:8px;padding:16px 6px;background:linear-gradient(135deg,rgba(0,50,120,.3),rgba(10,20,50,.6));border:1px solid rgba(0,150,255,.25);border-radius:16px;cursor:pointer;transition:.2s}
.attach-opt:active{transform:scale(.95);border-color:rgba(0,180,255,.6);background:rgba(0,150,255,.15)}
.attach-opt .ao-ico{width:46px;height:46px;border-radius:14px;display:grid;place-items:center;font-size:24px;background:linear-gradient(135deg,#0088ff,#00a8ff);box-shadow:0 4px 15px rgba(0,150,255,.4)}
.attach-opt .ao-lbl{font-size:10px;font-weight:800;color:#fff;letter-spacing:.5px;text-transform:uppercase}
`;

h = h.replace('</style>', menuCSS + '\n</style>');

// 2. HTML add karo (input bar ke baad)
const menuHTML = `
<!-- ATTACH MENU -->
<div class="attach-menu" id="attachMenu">
    <div class="attach-sheet">
        <div class="attach-sheet-handle"></div>
        <div class="attach-title">Send Attachment</div>
        <div class="attach-grid">
            <div class="attach-opt" onclick="pickType('image')">
                <div class="ao-ico">📷</div>
                <div class="ao-lbl">Photo</div>
            </div>
            <div class="attach-opt" onclick="pickType('video')">
                <div class="ao-ico">🎥</div>
                <div class="ao-lbl">Video</div>
            </div>
            <div class="attach-opt" onclick="pickType('pdf')">
                <div class="ao-ico">📄</div>
                <div class="ao-lbl">PDF</div>
            </div>
            <div class="attach-opt" onclick="pickType('file')">
                <div class="ao-ico">📁</div>
                <div class="ao-lbl">File</div>
            </div>
        </div>
    </div>
</div>

<!-- HIDDEN INPUTS -->
<input type="file" id="imagePicker" accept="image/*" onchange="handleFiles(this.files); closeAttachMenu()" style="display:none">
<input type="file" id="videoPicker" accept="video/*" onchange="handleFiles(this.files); closeAttachMenu()" style="display:none">
<input type="file" id="pdfPicker" accept="application/pdf,.pdf" onchange="handleFiles(this.files); closeAttachMenu()" style="display:none">
<input type="file" id="filePicker" accept="*/*" onchange="handleFiles(this.files); closeAttachMenu()" style="display:none">
`;

// Purana file input hata do
h = h.replace(/<input type="file" id="fileInput"[^>]*>/g, '');

// Naya menu input-bar ke baad add karo
h = h.replace('<!-- IMAGE VIEWER -->', menuHTML + '\n<!-- IMAGE VIEWER -->');

// 3. Attach button ka onclick change karo
h = h.replace(
    `onclick="document.getElementById('fileInput').click()"`,
    `onclick="openAttachMenu()"`
);

// 4. JS functions add karo
const menuJS = `
// ===== ATTACH MENU =====
function openAttachMenu(){
    const m = document.getElementById('attachMenu');
    m.classList.add('show');
    document.body.style.overflow = 'hidden';
}
function closeAttachMenu(){
    const m = document.getElementById('attachMenu');
    m.classList.remove('show');
    document.body.style.overflow = '';
}
function pickType(type){
    const map = {
        image: 'imagePicker',
        video: 'videoPicker',
        pdf: 'pdfPicker',
        file: 'filePicker'
    };
    const id = map[type];
    if (id) {
        const el = document.getElementById(id);
        if (el) {
            closeAttachMenu();
            setTimeout(() => el.click(), 200);
        }
    }
}
document.getElementById('attachMenu').addEventListener('click', function(e){
    if (e.target.id === 'attachMenu') closeAttachMenu();
});
`;

const lastScriptIdx = h.lastIndexOf('</script>');
h = h.slice(0, lastScriptIdx) + menuJS + '\n' + h.slice(lastScriptIdx);

fs.writeFileSync('support.html', h);
console.log('✅ Attach menu added!');
