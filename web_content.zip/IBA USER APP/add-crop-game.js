const fs = require('fs');
let h = fs.readFileSync('game-profile.html', 'utf8');

// 1. Purane upload functions ko naye crop logic se replace karo
// (Cover Photo aur Profile Photo dono ke liye)

const oldJS = h.substring(h.indexOf('// COVER & AVATAR LOGIC'), h.indexOf('loadPhotos();') + 11);
const newJS = `
// COVER & AVATAR LOGIC WITH CROP
let currentCropType = ''; // 'cover' ya 'avatar'

function loadPhotos() {
    const cover = localStorage.getItem('iba_cover');
    const avatar = localStorage.getItem('iba_photo');
    const name = localStorage.getItem('iba_name') || 'Player';
    
    if(cover) {
        document.getElementById('coverPhoto').style.backgroundImage = 'url(' + cover + ')';
        document.getElementById('coverBanner').classList.add('has-photo');
    }
    if(avatar) {
        document.getElementById('playerAvatar').innerHTML = '<img src="' + avatar + '">';
    }
    document.getElementById('profileNameDisplay').textContent = name;
}

// File Select -> Open Crop Modal
function handleCoverUpload(e) {
    const file = e.target.files[0];
    if(!file) return;
    currentCropType = 'cover';
    openCropModal(file);
    e.target.value = '';
}

function handleAvatarUpload(e) {
    const file = e.target.files[0];
    if(!file) return;
    currentCropType = 'avatar';
    openCropModal(file);
    e.target.value = '';
}

function openCropModal(file) {
    const reader = new FileReader();
    reader.onload = (ev) => {
        cropImage.src = ev.target.result;
        document.getElementById('cropModal').classList.add('show');
    };
    reader.readAsDataURL(file);
}

// CROP LOGIC (Drag & Zoom)
let cropImage = new Image();
let cropScale = 1;
let cropOffsetX = 0, cropOffsetY = 0;
let cropDragStartX = 0, cropDragStartY = 0;
let cropDragging = false;
let cropBaseSize = 0;
let cropBoxSize = 0;
let pinchStartDist = 0;
let pinchStartScale = 1;

function initCrop() {
    const container = document.getElementById('cropContainer');
    cropBoxSize = container.offsetWidth;
    const canvas = document.getElementById('cropCanvas');
    canvas.width = cropBoxSize;
    canvas.height = cropBoxSize;
    
    // Cover ke liye rectangular, Avatar ke liye square (chhota)
    if(currentCropType === 'cover') {
        cropBaseSize = Math.max(cropBoxSize / cropImage.width, (cropBoxSize * 0.6) / cropImage.height); // 60% height for cover
    } else {
        cropBaseSize = Math.max(cropBoxSize / cropImage.width, cropBoxSize / cropImage.height);
    }
    
    cropScale = 1; cropOffsetX = 0; cropOffsetY = 0;
    document.getElementById('cropZoom').value = 1;
    drawCrop();
}

function drawCrop() {
    const canvas = document.getElementById('cropCanvas');
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, cropBoxSize, cropBoxSize);
    
    let drawW = cropImage.width * cropBaseSize * cropScale;
    let drawH = cropImage.height * cropBaseSize * cropScale;
    
    // Agar cover hai toh height factor adjust karo
    if(currentCropType === 'cover') {
        drawW = cropImage.width * cropBaseSize * cropScale;
        drawH = cropImage.height * cropBaseSize * cropScale;
    }
    
    const drawX = (cropBoxSize - drawW) / 2 + cropOffsetX;
    const drawY = (cropBoxSize - drawH) / 2 + cropOffsetY;
    
    ctx.drawImage(cropImage, drawX, drawY, drawW, drawH);
}

function clampCrop() {
    let drawW = cropImage.width * cropBaseSize * cropScale;
    let drawH = cropImage.height * cropBaseSize * cropScale;
    
    if(currentCropType === 'cover') {
        // Allow more vertical drag for cover
        const maxY = Math.max(0, (drawH - cropBoxSize) / 2);
        cropOffsetY = Math.max(-maxY, Math.min(maxY, cropOffsetY));
        cropOffsetX = 0; // No horizontal drag for cover
    } else {
        const maxX = Math.max(0, (drawW - cropBoxSize) / 2);
        const maxY = Math.max(0, (drawH - cropBoxSize) / 2);
        cropOffsetX = Math.max(-maxX, Math.min(maxX, cropOffsetX));
        cropOffsetY = Math.max(-maxY, Math.min(maxY, cropOffsetY));
    }
}

// Drag Events
function cropTouchStart(e) {
    if(e.touches.length === 1) {
        cropDragging = true;
        cropDragStartX = e.touches[0].clientX - cropOffsetX;
        cropDragStartY = e.touches[0].clientY - cropOffsetY;
    } else if(e.touches.length === 2) {
        cropDragging = false;
        pinchStartDist = getDist(e.touches);
        pinchStartScale = cropScale;
    }
}
function cropTouchMove(e) {
    e.preventDefault();
    if(e.touches.length === 1 && cropDragging) {
        cropOffsetX = e.touches[0].clientX - cropDragStartX;
        cropOffsetY = e.touches[0].clientY - cropDragStartY;
        clampCrop();
        drawCrop();
    } else if(e.touches.length === 2) {
        const dist = getDist(e.touches);
        cropScale = Math.min(4, Math.max(1, pinchStartScale * (dist / pinchStartDist)));
        document.getElementById('cropZoom').value = cropScale;
        clampCrop();
        drawCrop();
    }
}
function getDist(touches) {
    const dx = touches[0].clientX - touches[1].clientX;
    const dy = touches[0].clientY - touches[1].clientY;
    return Math.sqrt(dx*dx + dy*dy);
}

function saveCrop() {
    const canvas = document.getElementById('cropCanvas');
    let finalData = '';
    
    if(currentCropType === 'cover') {
        // Cover image is 800x400
        const outCanvas = document.createElement('canvas');
        outCanvas.width = 800; outCanvas.height = 400;
        const ctx = outCanvas.getContext('2d');
        
        const ratio = 800 / cropBoxSize;
        let drawW = cropImage.width * cropBaseSize * cropScale * ratio;
        let drawH = cropImage.height * cropBaseSize * cropScale * ratio;
        // For cover, we want full width
        drawH = drawW * (400/800);
        
        let drawX = 0;
        let drawY = (400 - drawH) / 2 + cropOffsetY * ratio;
        
        ctx.drawImage(cropImage, 0, 0, cropImage.width, cropImage.height, drawX, drawY, drawW, drawH);
        finalData = outCanvas.toDataURL('image/jpeg', 0.85);
        localStorage.setItem('iba_cover', finalData);
        document.getElementById('coverPhoto').style.backgroundImage = 'url(' + finalData + ')';
        document.getElementById('coverBanner').classList.add('has-photo');
        
    } else {
        // Avatar is 300x300
        const outCanvas = document.createElement('canvas');
        outCanvas.width = 300; outCanvas.height = 300;
        const ctx = outCanvas.getContext('2d');
        
        const ratio = 300 / cropBoxSize;
        let drawW = cropImage.width * cropBaseSize * cropScale * ratio;
        let drawH = cropImage.height * cropBaseSize * cropScale * ratio;
        let drawX = (300 - drawW) / 2 + cropOffsetX * ratio;
        let drawY = (300 - drawH) / 2 + cropOffsetY * ratio;
        
        ctx.drawImage(cropImage, drawX, drawY, drawW, drawH);
        finalData = outCanvas.toDataURL('image/jpeg', 0.85);
        localStorage.setItem('iba_photo', finalData);
        document.getElementById('playerAvatar').innerHTML = '<img src="' + finalData + '">';
        
        // Server save
        const userId = localStorage.getItem('iba_userId');
        fetch(SERVER + '/api/user/update-profile', {
            method: 'POST', headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ userId, photo: finalData })
        });
    }
    
    closeCropModal();
    alert('✅ Photo Set Successfully!');
}

function closeCropModal() {
    document.getElementById('cropModal').classList.remove('show');
}

loadPhotos();
`;

h = h.replace(oldJS, newJS);

// 2. Crop Modal HTML & CSS add karo
const cropModal = `
<!-- CROP MODAL -->
<div class="crop-modal" id="cropModal">
    <div class="crop-header">
        <h3>Adjust Your Photo</h3>
        <p>Drag & Zoom to set perfectly</p>
    </div>
    <div class="crop-container" id="cropContainer" onload="initCrop()">
        <canvas id="cropCanvas" oncontextmenu="return false;"></canvas>
        <div class="crop-frame"></div>
    </div>
    <div class="crop-controls">
        <input type="range" class="crop-slider" id="cropZoom" min="1" max="4" step="0.05" value="1" oninput="cropScale = parseFloat(this.value); clampCrop(); drawCrop();">
        <div class="crop-btns">
            <button class="crop-btn cancel" onclick="closeCropModal()">Cancel</button>
            <button class="crop-btn save" onclick="saveCrop()">Set Photo</button>
        </div>
    </div>
</div>

<style>
/* CROP MODAL */
.crop-modal{position:fixed;inset:0;z-index:9999;background:#000;display:none;flex-direction:column;align-items:center;justify-content:center;padding:20px}
.crop-modal.show{display:flex}
.crop-header{text-align:center;margin-bottom:20px}
.crop-header h3{color:#fff;font-size:20px;font-weight:900;margin-bottom:4px}
.crop-header p{color:#8a9bb8;font-size:12px}
.crop-container{width:85vw;max-width:350px;aspect-ratio:1;border-radius:20px;overflow:hidden;position:relative;background:#111;border:2px solid #ffc419}
.crop-container canvas{width:100%;height:100%;display:block}
.crop-controls{width:85vw;max-width:350px;margin-top:24px}
.crop-slider{width:100%;-webkit-appearance:none;height:6px;background:#333;border-radius:4px;outline:none;margin-bottom:20px}
.crop-slider::-webkit-slider-thumb{-webkit-appearance:none;width:24px;height:24px;border-radius:50%;background:#ffc419;cursor:pointer;box-shadow:0 0 10px #ffc419}
.crop-btns{display:flex;gap:12px}
.crop-btn{flex:1;padding:16px;border:none;border-radius:14px;font-size:14px;font-weight:900;cursor:pointer;font-family:inherit}
.crop-btn.cancel{background:rgba(255,255,255,0.1);color:#fff}
.crop-btn.save{background:#ffc419;color:#000;box-shadow:0 4px 15px rgba(255,195,25,0.4)}
</style>
`;

h = h.replace('</body>', cropModal + '\n</body>');

// 3. Modal khulte hi initCrop call karo
h = h.replace(
    "document.getElementById('cropModal').classList.add('show');",
    "document.getElementById('cropModal').classList.add('show');\n        setTimeout(() => { if(cropImage.width > 0) initCrop(); }, 100);\n        cropImage.onload = () => initCrop();"
);

// 4. Canvas events attach karo
const cropEvents = `
// Attach touch events to crop container
setTimeout(() => {
    const cc = document.getElementById('cropContainer');
    if(cc) {
        cc.addEventListener('touchstart', cropTouchStart, {passive: true});
        cc.addEventListener('touchmove', cropTouchMove, {passive: false});
        cc.addEventListener('touchend', () => cropDragging = false);
    }
}, 500);
`;
h = h.replace('loadPhotos();', 'loadPhotos();\n' + cropEvents);

fs.writeFileSync('game-profile.html', h);
console.log('✅ Crop & Adjust feature added!');
