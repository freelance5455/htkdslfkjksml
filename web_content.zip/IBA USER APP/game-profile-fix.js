const fs = require('fs');
let h = fs.readFileSync('game-profile.html', 'utf8');

// 1. Banner (upar wala hissa) me Player Avatar lagao
const oldBanner = `<div class="banner">
    <div class="banner-icon">🎮</div>
    <h2>Free Fire <span>Profile</span></h2>
    <p>Manage your in-game identity</p>
</div>`;

const newBanner = `<div class="banner" style="padding-top:20px;">
    <div class="player-avatar-wrap" onclick="document.getElementById('avatarInput').click()">
        <div class="player-avatar" id="playerAvatar">👤</div>
        <div class="avatar-edit-badge">📷</div>
    </div>
    <input type="file" id="avatarInput" accept="image/*" style="display:none" onchange="handleAvatarUpload(event)">
    <h2 style="margin-top:16px;">Free Fire <span>Profile</span></h2>
    <p>Manage your in-game identity</p>
</div>`;

h = h.replace(oldBanner, newBanner);

// 2. CSS me Avatar ka design add karo
const avatarCSS = `
/* PLAYER AVATAR */
.player-avatar-wrap{position:relative;width:100px;height:100px;margin:0 auto;cursor:pointer}
.player-avatar{width:100px;height:100px;border-radius:50%;background:linear-gradient(135deg,#0a1535,#000);border:3px solid #ffc419;display:grid;place-items:center;font-size:40px;color:#fff;overflow:hidden;box-shadow:0 0 30px rgba(255,195,25,0.4)}
.player-avatar img{width:100%;height:100%;object-fit:cover}
.avatar-edit-badge{position:absolute;bottom:0;right:0;width:32px;height:32px;border-radius:50%;background:#ffc419;display:grid;place-items:center;font-size:14px;border:3px solid #02040a;box-shadow:0 0 10px rgba(0,0,0,0.5)}
`;
h = h.replace('</style>', avatarCSS + '\n</style>');

// 3. Player Level wala box hatao
const oldLevelBox = `<div class="info-row">
        <div class="info-icon">⭐</div>
        <div class="info-content">
            <div class="info-label">PLAYER LEVEL</div>
            <div class="info-value">Level 1</div>
        </div>
    </div>`;
h = h.replace(oldLevelBox, '');

// 4. JS me avatar load aur upload ka logic add karo
const avatarJS = `
// AVATAR LOGIC
function loadAvatar() {
    const savedAvatar = localStorage.getItem('iba_photo');
    const av = document.getElementById('playerAvatar');
    if(savedAvatar) {
        av.innerHTML = '<img src="' + savedAvatar + '">';
    }
}

function handleAvatarUpload(e) {
    const file = e.target.files[0];
    if(!file) return;
    if(file.size > 5 * 1024 * 1024) {
        alert('Photo max 5MB');
        return;
    }
    const reader = new FileReader();
    reader.onload = (ev) => {
        const img = new Image();
        img.onload = () => {
            const canvas = document.createElement('canvas');
            canvas.width = 300; canvas.height = 300;
            const ctx = canvas.getContext('2d');
            const size = Math.min(img.width, img.height);
            const sx = (img.width - size) / 2;
            const sy = (img.height - size) / 2;
            ctx.drawImage(img, sx, sy, size, size, 0, 0, 300, 300);
            const data = canvas.toDataURL('image/jpeg', 0.85);
            
            // Update UI
            document.getElementById('playerAvatar').innerHTML = '<img src="' + data + '">';
            localStorage.setItem('iba_photo', data);
            
            // Save to server
            const userId = localStorage.getItem('iba_userId');
            fetch(SERVER + '/api/user/update-profile', {
                method: 'POST', headers: {'Content-Type':'application/json'},
                body: JSON.stringify({ userId, photo: data })
            });
            
            alert('✅ Profile photo updated!');
        };
        img.src = ev.target.result;
    };
    reader.readAsDataURL(file);
    e.target.value = '';
}

loadAvatar();
`;
h = h.replace('loadGameData();', 'loadGameData();\n' + avatarJS);

fs.writeFileSync('game-profile.html', h);
console.log('✅ Player Level removed, Avatar Upload added!');
