const fs = require('fs');
let html = fs.readFileSync('index.html', 'utf8');

// Overlay + check script
const checkCode = `
<div id="loadingOverlay" style="position:fixed;inset:0;z-index:99999;background:#02040a;color:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center;font-family:Arial,sans-serif">
  <img src="iba-logo.png" style="width:110px;height:110px;border-radius:20px;box-shadow:0 0 25px rgba(0,195,255,.6);margin-bottom:20px">
  <div id="loadSpin" style="width:40px;height:40px;border:4px solid rgba(0,195,255,.2);border-top-color:#00c3ff;border-radius:50%;animation:spin 1s linear infinite"></div>
  <p id="loadText" style="margin-top:20px;color:#00c3ff;font-size:14px;letter-spacing:1px">Connecting to server...</p>
  <style>@keyframes spin{to{transform:rotate(360deg)}}</style>
</div>
<script>
(async function(){
  const overlay = document.getElementById('loadingOverlay');
  const spin = document.getElementById('loadSpin');
  const txt = document.getElementById('loadText');
  if(!overlay) return;

  async function isServerUp(){
    try{
      const r = await fetch('http://localhost:3102/api/matches', {signal: AbortSignal.timeout(3000)});
      return r.ok;
    }catch(e){return false;}
  }

  let up = await isServerUp();
  if(up){
    overlay.style.transition = 'opacity .3s';
    overlay.style.opacity = '0';
    setTimeout(()=>overlay.remove(), 300);
  } else {
    spin.style.display = 'none';
    txt.innerHTML = '<h1 style="color:#ff4466;font-size:20px;margin-bottom:12px">⚠️ Server Offline</h1><p style="color:#8899bb;font-size:13px;max-width:280px;text-align:center;line-height:1.6;margin-bottom:20px">Server abhi chal nahi raha. Please thodi der baad try karo.</p><button onclick="location.reload()" style="padding:12px 30px;background:linear-gradient(90deg,#0066ff,#00c3ff);color:#fff;border:none;border-radius:10px;font-weight:bold;font-size:14px;cursor:pointer">🔄 RETRY</button>';
    // Auto retry har 5 sec
    setInterval(async ()=>{
      if(await isServerUp()) location.reload();
    }, 5000);
  }
})();
<\/script>
`;

// <body> tag ke turant baad insert karo
const bodyIdx = html.indexOf('<body');
if(bodyIdx === -1){ console.log('❌ <body> not found'); process.exit(1); }
const bodyEnd = html.indexOf('>', bodyIdx) + 1;

// Agar pehle se add ho chuka hai toh skip
if(html.includes('loadingOverlay')){ console.log('ℹ️ Check already exists'); process.exit(0); }

html = html.slice(0, bodyEnd) + checkCode + html.slice(bodyEnd);
fs.writeFileSync('index.html', html);
console.log('✅ Server check added to index.html');
