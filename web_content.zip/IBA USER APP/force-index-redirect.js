const fs = require('fs');
let h = fs.readFileSync('index.html', 'utf8');

// Purane redirect (login.html) ko hatao
h = h.replace(/window\.location\.replace\('login\.html'\);/g, '');
h = h.replace(/window\.location.href\s*=\s*'login\.html';/g, '');

// Naya code jo check karega
const newCheck = `
// AUTO REDIRECT LOGIC
var savedUserId = localStorage.getItem('iba_userId');
var savedMobile = localStorage.getItem('iba_mobile');

if (savedUserId && savedMobile) {
    window.location.replace('dashboard.html');
} else {
    window.location.replace('login.html');
}
`;

// Purana setTimeout dhundo aur naya daalo
const oldSetTimeout = /setTimeout\(\(\)\s*=>\s*\{[\s\S]*?\},\s*\d+\);/;
if (oldSetTimeout.test(h)) {
    h = h.replace(oldSetTimeout, `setTimeout(() => {${newCheck}}, 8100);`);
    console.log('✅ Redirect logic replaced via setTimeout!');
} else {
    // Agar setTimeout na mile toh seedha </script> se pehle daalo
    h = h.replace('</script>', newCheck + '\n</script>');
    console.log('✅ Redirect logic added before </script>!');
}

fs.writeFileSync('index.html', h);
