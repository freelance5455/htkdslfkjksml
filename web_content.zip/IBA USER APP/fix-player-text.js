const fs = require('fs');
let h = fs.readFileSync('dashboard.html', 'utf8');

// 1. "Player" text ko "Message Your Friend" se replace karo
h = h.replace(/<div class="msg-opt-title">Player<\/div>/g, '<div class="msg-opt-title">Message Your Friend</div>');

// 2. Description ko bhi update karo
h = h.replace(/<div class="msg-opt-desc">Chat with other players<\/div>/g, '<div class="msg-opt-desc">Send messages to your friends</div>');

// 3. Agar Player ka icon (👤) alag line me hai, toh use bhi check karo
h = h.replace(/<div class="msg-opt-title">\s*Player\s*<\/div>/g, '<div class="msg-opt-title">Message Your Friend</div>');

fs.writeFileSync('dashboard.html', h);
console.log('✅ Text updated to "Message Your Friend"');
