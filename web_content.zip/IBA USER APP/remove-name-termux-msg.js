const fs = require('fs');
let h = fs.readFileSync('edit-profile.html', 'utf8');

// 1. Purana lamba message hatao
h = h.replace(
    "nmMsg('OTP sent to your mobile! Check Termux.', 'success');",
    "// Message hidden"
);

// 2. Agar koi aur jagah similar text ho toh use bhi hatao
h = h.replace(/nmMsg\('OTP sent to your mobile![^']*', 'success'\);/g, '');

fs.writeFileSync('edit-profile.html', h);
console.log('✅ "Check Termux" message removed from Name change!');
