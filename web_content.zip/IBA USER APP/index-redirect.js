const fs = require('fs');
let h = fs.readFileSync('index.html', 'utf8');

// Purana redirect (window.location.replace('login.html')) dhundo aur hatao
h = h.replace(/window\.location\.replace\('login\.html'\);/g, '');

// Naya logic: Check if logged in, phir redirect karo
const newRedirectLogic = `
        // CHECK IF USER IS LOGGED IN
        var savedUserId = localStorage.getItem('iba_userId');
        var savedMobile = localStorage.getItem('iba_mobile');
        
        if (savedUserId && savedMobile) {
            window.location.replace('dashboard.html');
        } else {
            window.location.replace('login.html');
        }
`;

// Jahan bhi purana setTimeout redirect tha, wahan naya logic daalo
h = h.replace(/setTimeout\(\(\) => \{[\s\S]*?\}, 8600\);/, `setTimeout(() => {${newRedirectLogic}}, 8600);`);
h = h.replace(/setTimeout\(function\(\) \{[\s\S]*?\}, 8600\);/, `setTimeout(function() {${newRedirectLogic}}, 8600);`);

fs.writeFileSync('index.html', h);
console.log('✅ Index redirect logic fixed!');
