const fs = require('fs');
let h = fs.readFileSync('edit-profile.html', 'utf8');

// 1. Input box ko "readonly" aur style change karo (Lock dikhane ke liye)
h = h.replace(
    '<input type="text" class="form-input" id="accountIdInput" placeholder="Enter your IBA ID" maxlength="15" style="font-weight:900; font-size:18px; color:#fff; letter-spacing:2px;">',
    '<input type="text" class="form-input" id="accountIdInput" placeholder="Auto-generated" readonly style="font-weight:900; font-size:18px; color:#ffc419; letter-spacing:2px; cursor:not-allowed;">'
);

// 2. Upar lock icon add karo
h = h.replace(
    '<div class="input-icon" style="color:#ffc419; font-size:22px;">#</div>',
    '<div class="input-icon" style="color:#ffc419; font-size:20px;">🔒</div>'
);

// 3. Niche wala text change karo
h = h.replace(
    'This ID will be visible on your profile.',
    'This ID is auto-generated and <span style="color:#ff3b3b;">cannot be changed</span>. Contact Admin for changes.'
);

// 4. JS: Auto-generate logic (agar pehle se nahi hai toh)
// User ka ID agar profile me nahi hai, toh mobile se generate karo
h = h.replace(
    "document.getElementById('accountIdInput').value = p.accountId || '';",
    `let accId = p.accountId;
                if (!accId) {
                    // Auto-generate IBA ID from mobile number
                    const mob = localStorage.getItem('iba_mobile') || '00000';
                    accId = 'IBA' + mob.slice(-6);
                }
                document.getElementById('accountIdInput').value = accId;`
);

// 5. Save ke time ID na bheje (kyunki edit nahi ho sakti)
h = h.replace(
    "const accountId = document.getElementById('accountIdInput').value.trim();",
    "// ID is locked, don't send"
);

h = h.replace(
    "const body = { userId, name, ffName, ffUid, accountId };",
    "const body = { userId, name, ffName, ffUid };"
);

fs.writeFileSync('edit-profile.html', h);
console.log('✅ IBA ID Locked & Read-Only!');
