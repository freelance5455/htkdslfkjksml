const fs = require('fs');
let h = fs.readFileSync('messages.html', 'utf8');

// 1. Header me 3-dot (⋮) menu button add karo
h = h.replace(
    '<div class="header-title">💬 <span id="chatTitle">MESSAGES</span></div>',
    `<div class="header-title">💬 <span id="chatTitle">MESSAGES</span></div>
    <div class="menu-btn" onclick="toggleMenu()" style="width:40px;height:40px;border-radius:50%;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);color:#fff;font-size:20px;display:grid;place-items:center;cursor:pointer;">⋮</div>`
);

// 2. Dropdown Menu (Delete Option) add karo
const menuHTML = `
<div class="dropdown-menu" id="dropdownMenu">
    <div class="menu-item delete" onclick="deleteFriend()">
        <span>🗑️</span> Delete Friend
    </div>
</div>
`;
h = h.replace('</body>', menuHTML + '\n</body>');

// 3. CSS add karo
const menuCSS = `
.dropdown-menu{position:absolute;top:70px;right:20px;background:#0a1535;border:1px solid rgba(255,195,25,0.3);border-radius:12px;padding:8px;display:none;z-index:100;box-shadow:0 10px 30px rgba(0,0,0,0.8);min-width:180px;}
.dropdown-menu.show{display:block;}
.menu-item{display:flex;align-items:center;gap:10px;padding:12px 16px;color:#fff;font-size:14px;font-weight:700;cursor:pointer;border-radius:8px;}
.menu-item:active{background:rgba(255,255,255,0.05);}
.menu-item.delete{color:#ff3b3b;}
.menu-item.delete span{font-size:18px;}
`;
h = h.replace('</style>', menuCSS + '\n</style>');

// 4. JS Function add karo
const menuJS = `
function toggleMenu() {
    var menu = document.getElementById('dropdownMenu');
    menu.classList.toggle('show');
}

function deleteFriend() {
    var urlParams = new URLSearchParams(window.location.search);
    var friendId = urlParams.get('friend');
    var myId = localStorage.getItem('iba_userId');
    
    if(!friendId) {
        alert('No friend selected to delete');
        return;
    }
    
    if(!confirm('Are you sure you want to delete this friend?')) return;
    
    // Server se delete karo
    fetch(SERVER + '/api/delete-friend/' + myId + '/' + friendId, {
        method: 'DELETE'
    })
    .then(function(res) { return res.json(); })
    .then(function(data) {
        // LocalStorage se bhi delete karo
        var friends = JSON.parse(localStorage.getItem('iba_friends') || '[]');
        friends = friends.filter(function(f) { return f.userId !== friendId; });
        localStorage.setItem('iba_friends', JSON.stringify(friends));
        
        alert('✅ Friend deleted!');
        document.getElementById('dropdownMenu').classList.remove('show');
        window.location.href = 'add-friend.html';
    })
    .catch(function(e) {
        alert('Delete failed');
    });
}

// Close menu on outside click
document.addEventListener('click', function(e) {
    var menu = document.getElementById('dropdownMenu');
    if(menu && menu.classList.contains('show')) {
        if(!e.target.closest('.menu-btn') && !e.target.closest('.dropdown-menu')) {
            menu.classList.remove('show');
        }
    }
});
`;
h = h.replace('</script>', menuJS + '\n</script>');

fs.writeFileSync('messages.html', h);
console.log('✅ Delete option added to Chat!');
