const fs = require('fs');

// Dono files (register + edit-profile) me file input fix karo
['register.html', 'edit-profile.html'].forEach(function(file) {
    let h = fs.readFileSync(file, 'utf8');
    
    // File input ka style check karo - display:none hona chahiye
    if (!h.includes('#photoInput{display:none}') && !h.includes('#avatarInput{display:none}')) {
        // Inputs ko properly hide karo
        h = h.replace(
            '<input type="file" id="photoInput"',
            '<input type="file" id="photoInput" style="position:absolute;left:-9999px;opacity:0;"'
        );
        h = h.replace(
            '<input type="file" id="avatarInput"',
            '<input type="file" id="avatarInput" style="position:absolute;left:-9999px;opacity:0;"'
        );
    }
    
    fs.writeFileSync(file, h);
    console.log('✅ ' + file + ' fixed');
});
