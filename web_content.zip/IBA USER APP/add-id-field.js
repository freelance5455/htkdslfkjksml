const fs = require('fs');
let h = fs.readFileSync('edit-profile.html', 'utf8');

// Naya ID field (Free Fire UID ke baad) add karo
if (!h.includes('accountIdInput')) {
    const oldSection = `<div class="info-text">Your IGN and UID will be used for match verification.</div>`;
    
    const newSection = `<div class="form-group" style="margin-top:20px;">
        <label class="form-label">ACCOUNT ID (IBA ID)</label>
        <div class="input-wrapper">
            <div class="input-icon">🔢</div>
            <input type="text" class="form-input" id="accountIdInput" placeholder="Enter your unique ID" maxlength="15">
        </div>
    </div>
    <div class="info-text">Your IGN and UID will be used for match verification.</div>`;
    
    h = h.replace(oldSection, newSection);
}

// Load profile me accountId dikhao
if (!h.includes("accountIdInput.value = p.accountId")) {
    h = h.replace(
        "ffUidInput.value = p.ffUid || '';",
        "ffUidInput.value = p.ffUid || '';\n            document.getElementById('accountIdInput').value = p.accountId || '';"
    );
}

// Save profile me accountId bhejo
if (!h.includes("accountId: accountId")) {
    h = h.replace(
        "const body = { userId, name, ffName, ffUid };",
        "const accountId = document.getElementById('accountIdInput').value.trim();\n        const body = { userId, name, ffName, ffUid, accountId };"
    );
}

fs.writeFileSync('edit-profile.html', h);
console.log('✅ Edit Profile updated with Account ID field!');
