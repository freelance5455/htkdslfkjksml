const fs = require('fs');
let h = fs.readFileSync('messages.html', 'utf8');

// 1. Wapas <p> tag add karo (lekin is baar hide rakho taaki JS kaam kare)
// Delete icon ke theek baad aur actions ke theek pehle daal do
const oldHTML = `<div class="delete-icon">🗑️</div>
        <h3>Remove Friend?</h3>
        
        <div class="delete-actions">`;

const newHTML = `<div class="delete-icon">🗑️</div>
        <h3>Remove Friend?</h3>
        <p style="display:none;"><b id="deleteFriendName"></b></p>
        
        <div class="delete-actions">`;

if(h.includes(oldHTML)){
    h = h.replace(oldHTML, newHTML);
    console.log('✅ Hidden tag added back for JS');
} else {
    // Agar exact match na mile toh direct h3 ke baad daal do
    h = h.replace(
        '<h3>Remove Friend?</h3>',
        '<h3>Remove Friend?</h3>\n        <p style="display:none;"><b id="deleteFriendName"></b></p>'
    );
    console.log('✅ Hidden tag added via fallback');
}

fs.writeFileSync('messages.html', h);
console.log('✅ Delete Functionality Restored!');
