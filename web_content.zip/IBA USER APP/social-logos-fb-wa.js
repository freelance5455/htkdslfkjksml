const fs = require('fs');
let h = fs.readFileSync('about.html', 'utf8');

// 1. WhatsApp Logo (Green background with white icon)
const oldWaIcon = `<div class="social-icon" style="background:rgba(37,211,102,0.15);">💬</div>`;
const newWaIcon = `<div class="social-icon" style="background:#25D366;">
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M12 2C6.477 2 2 6.477 2 12c0 1.76.455 3.414 1.253 4.854L2.043 22l5.278-1.383A9.956 9.956 0 0 0 12 22c5.523 22 10-4.477 10-10S17.523 2 12 2zm5.512 14.184c-.244.688-1.432 1.32-1.964 1.36-.532.04-1.04.184-2.96-.632-2.296-.972-3.752-3.352-3.864-3.504-.112-.152-.92-1.24-.92-2.368 0-1.128.584-1.68.792-1.912.208-.232.456-.288.608-.288.152 0 .304.008.44.016.144.008.336-.056.52.392.192.464.648 1.584.704 1.696.056.112.096.24.024.384-.072.144-.144.24-.288.392-.144.152-.296.336-.424.464-.144.144-.296.296-.128.584.168.288.752 1.24 1.608 2.008 1.104.984 1.92 1.232 2.192 1.368.272.136.432.112.592-.064.16-.176.688-.8.872-1.072.184-.272.368-.224.616-.136.248.088 1.576.744 1.848.88.272.136.456.2.52.312.064.112.064.656-.18 1.344z" fill="#ffffff"/>
    </svg>
</div>`;

// 2. Facebook Logo (Blue background with white f)
const oldFbIcon = `<div class="social-icon" style="background:rgba(24,119,242,0.15);">📘</div>`;
const newFbIcon = `<div class="social-icon" style="background:#1877F2;">
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
        <path d="M22 12C22 6.477 17.523 2 12 2C6.477 2 2 6.477 2 12C2 16.991 5.657 21.128 10.438 21.878V14.891H7.898V12H10.438V9.797C10.438 7.291 11.93 5.907 14.215 5.907C15.309 5.907 16.453 6.102 16.453 6.102V8.562H15.193C13.95 8.562 13.562 9.333 13.562 10.124V12H16.336L15.893 14.891H13.562V21.878C18.343 21.128 22 16.991 22 12Z" fill="#ffffff"/>
    </svg>
</div>`;

// Replace
if (h.includes(oldWaIcon)) {
    h = h.replace(oldWaIcon, newWaIcon);
    console.log('✅ WhatsApp Logo Updated');
}
if (h.includes(oldFbIcon)) {
    h = h.replace(oldFbIcon, newFbIcon);
    console.log('✅ Facebook Logo Updated');
}

fs.writeFileSync('about.html', h);
