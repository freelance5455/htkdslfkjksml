const fs = require('fs');
let h = fs.readFileSync('edit-profile.html', 'utf8');

// 1. "Sending new OTP..." wala message hatao (Resend function se)
h = h.replace(
    "nmMsg('Sending new OTP...', 'success');",
    "// Sending message hidden"
);

// 2. Agar koi aur jagah bhi yeh message ho toh use bhi hatao
h = h.replace(/nmMsg\('Sending new OTP\.\.\.', 'success'\);/g, '');

fs.writeFileSync('edit-profile.html', h);
console.log('✅ "Sending new OTP..." message removed!');
