const fs = require('fs');
let h = fs.readFileSync('dashboard.html', 'utf8');

// ===== 1. AVATAR PHOTO FIX =====
// Avatar ke liye server se photo fetch karo
const oldAvatarCode = `const av = document.getElementById('userAvatar');
if(userPhoto){
    av.innerHTML = '<img src="' + userPhoto + '" alt="">';
} else {
    av.textContent = userName.charAt(0).toUpperCase();
}`;

const newAvatarCode = `const av = document.getElementById('userAvatar');

// Server se profile fetch karke photo dikhao
async function loadAvatar() {
    // Pehle localStorage try karo
    if (userPhoto && userPhoto.startsWith('data:')) {
        av.innerHTML = '<img src="' + userPhoto + '" alt="" style="width:100%;height:100%;object-fit:cover">';
        return;
    }
    // Server se fetch karo
    try {
        const r = await fetch(SERVER + '/api/user/profile/' + userId);
        const d = await r.json();
        if (d.success && d.profile && d.profile.photo) {
            av.innerHTML = '<img src="' + d.profile.photo + '" alt="" style="width:100%;height:100%;object-fit:cover">';
            localStorage.setItem('iba_photo', d.profile.photo);
        } else {
            av.textContent = userName.charAt(0).toUpperCase();
        }
    } catch(e) {
        av.textContent = userName.charAt(0).toUpperCase();
    }
}
loadAvatar();`;

h = h.replace(oldAvatarCode, newAvatarCode);

// ===== 2. MATCHES DYNAMIC LOAD =====
// Purane hardcoded matches hatao
const hardcodedMatchesRegex = /<!-- MATCH 1 -->[\s\S]*?<!-- MATCH 3 -->[\s\S]*?<\/div>\s*<\/div>/;
if (hardcodedMatchesRegex.test(h)) {
    h = h.replace(hardcodedMatchesRegex, `
    <!-- MATCHES CONTAINER (dynamic) -->
    <div id="matchesContainer">
        <div style="text-align:center;padding:40px 20px;color:#6b8bb8;font-size:13px">
            <div style="font-size:40px;margin-bottom:12px;opacity:.4">🎮</div>
            <div id="matchesLoadingText">Loading matches...</div>
        </div>
    </div>
    `);
    console.log('✅ Hardcoded matches removed');
} else {
    console.log('⚠️ Matches regex not matched, trying alternate');
    // Alternate: replace from "UPCOMING MATCHES" section end to closing
    const idx1 = h.indexOf('<!-- MATCH 1 -->');
    const idx2 = h.indexOf('</div>\n</div>\n\n<div class="bottom-nav">');
    if (idx1 !== -1 && idx2 !== -1) {
        h = h.slice(0, idx1) + `
        <div id="matchesContainer">
            <div style="text-align:center;padding:40px 20px;color:#6b8bb8;font-size:13px">
                <div style="font-size:40px;margin-bottom:12px;opacity:.4">🎮</div>
                <div id="matchesLoadingText">Loading matches...</div>
            </div>
        </div>
    ` + h.slice(idx2 + 6);
        console.log('✅ Hardcoded matches removed (alternate)');
    }
}

// ===== 3. JS: LOAD MATCHES FROM SERVER =====
const matchLoadJS = `
// ===== LOAD REAL MATCHES FROM SERVER 2 =====
async function loadMatches(){
    const box = document.getElementById('matchesContainer');
    if(!box) return;
    try {
        const r = await fetch(SERVER + '/api/matches');
        const d = await r.json();
        const matches = (d.matches || []).filter(m => m.status === 'UPCOMING' || !m.status);

        if(matches.length === 0){
            box.innerHTML = '<div style="text-align:center;padding:40px 20px;color:#6b8bb8;font-size:13px">' +
                '<div style="font-size:40px;margin-bottom:12px;opacity:.4">🎮</div>' +
                '<div style="font-weight:700;color:#a8bddc;margin-bottom:6px">No Matches Available</div>' +
                '<div style="font-size:11px;line-height:1.5">Naye matches jald hi aayenge.<br>Check back later!</div>' +
                '</div>';
            return;
        }

        box.innerHTML = matches.map(m => {
            const entry = m.entryFee || 0;
            const prize = m.prizePool || (entry * 50) || 500;
            const perKill = m.perKill || 5;
            const icon = m.gameType === 'CLASH SQUAD' ? '⚔' : '⚡';
            const type = m.roomName ? m.roomName.toUpperCase() : 'BATTLE ROYALE';

            return \`<div class="match-card">
                <div class="match-top">
                    <div class="match-type">\${icon} \${type}</div>
                    <div class="match-status">UPCOMING</div>
                </div>
                <div class="match-title">\${m.roomName || 'IBA Match'}</div>
                <div class="match-stats">
                    <div class="match-stat"><div class="ms-lbl">ENTRY</div><div class="ms-val blue">₹\${entry}</div></div>
                    <div class="match-stat"><div class="ms-lbl">PRIZE</div><div class="ms-val">₹\${prize}</div></div>
                    <div class="match-stat"><div class="ms-lbl">PER KILL</div><div class="ms-val">₹\${perKill}</div></div>
                </div>
                <button class="join-btn" onclick="joinMatch('\${m.id}','\${m.roomName}','\${entry}')">JOIN MATCH</button>
            </div>\`;
        }).join('');
    } catch(e) {
        box.innerHTML = '<div style="text-align:center;padding:40px 20px;color:#ff5577;font-size:13px">' +
            '<div style="font-size:40px;margin-bottom:12px">⚠️</div>' +
            '<div>Failed to load matches</div>' +
            '<button onclick="loadMatches()" style="margin-top:14px;padding:10px 20px;background:linear-gradient(135deg,#0088ff,#00a8ff);color:#fff;border:none;border-radius:10px;font-weight:700;cursor:pointer">RETRY</button>' +
            '</div>';
    }
}

// JOIN MATCH
async function joinMatch(matchId, roomName, entryFee){
    const userId = localStorage.getItem('iba_userId');
    if(!userId){ location.href = 'login.html'; return; }

    if(!confirm('Join ' + roomName + ' for ₹' + entryFee + '?')) return;

    try {
        const r = await fetch(SERVER + '/api/book-room', {
            method: 'POST', headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ userId, matchId, entryFee: Number(entryFee) })
        });
        const d = await r.json();
        if(d.success){
            alert('✅ Match joined successfully!');
        } else {
            alert('❌ ' + (d.error || 'Failed to join'));
        }
    } catch(e) {
        alert('❌ Server error');
    }
}

// Auto-load matches
loadMatches();
setInterval(loadMatches, 10000);
`;

// Script me add karo
const lastScript = h.lastIndexOf('</script>');
h = h.slice(0, lastScript) + matchLoadJS + '\n' + h.slice(lastScript);

fs.writeFileSync('dashboard.html', h);
console.log('✅ Dashboard updated!');
