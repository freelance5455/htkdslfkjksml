const fs = require('fs');
let h = fs.readFileSync('dashboard.html', 'utf8');

// 1. Popup ke Icons ko bright aur colorful banao
const oldIconsCSS = /\.msg-opt-icon\{[^}]*\}/;
const newIconsCSS = `
.msg-opt-icon{
    width: 50px; height: 50px; border-radius: 16px;
    display: grid; place-items: center;
    font-size: 24px; flex-shrink: 0;
    box-shadow: 0 4px 15px rgba(0,0,0,0.3);
}
/* Admin - Red Shield */
.msg-option:nth-child(2) .msg-opt-icon {
    background: linear-gradient(135deg, #ff3b3b, #cc0033);
    border: 1px solid rgba(255,100,100,0.5);
}
/* Room Manager - Blue/Green Gamepad */
.msg-option:nth-child(3) .msg-opt-icon {
    background: linear-gradient(135deg, #00a8ff, #0066ff);
    border: 1px solid rgba(100,180,255,0.5);
}
/* Player - Gold User */
.msg-option:nth-child(4) .msg-opt-icon {
    background: linear-gradient(135deg, #ffc419, #ff9800);
    border: 1px solid rgba(255,220,100,0.5);
}
`;
h = h.replace(oldIconsCSS, newIconsCSS);

// 2. Popup ka Background thoda aur dark aur premium karo
h = h.replace(
    '.msg-popup{background:#0a1535;',
    '.msg-popup{background:linear-gradient(180deg, #0e1c45 0%, #050b1f 100%);'
);

// 3. Option cards ko thoda bright karo
h = h.replace(
    '.msg-option{display:flex;align-items:center;gap:16px;padding:16px;background:rgba(255,255,255,0.05);',
    '.msg-option{display:flex;align-items:center;gap:16px;padding:16px;background:rgba(255,255,255,0.08);'
);

// 4. Option ke text ko thoda bright karo
h = h.replace(
    '.msg-opt-desc{font-size:11px;color:#6b8bb8}',
    '.msg-opt-desc{font-size:11px;color:#a8bddc}'
);

fs.writeFileSync('dashboard.html', h);
console.log('✅ Message Popup Icons Fixed!');
