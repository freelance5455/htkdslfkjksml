const fs = require('fs');
let h = fs.readFileSync('add-friend.html', 'utf8');

// 1. Friend Card ka CSS thoda aur premium karo (photo bada aur glowing)
const oldFriendCSS = /\.friend-card \{[\s\S]*?\.add-btn:active \{ transform: scale\(0\.96\); \}/;
const newFriendCSS = `
/* PREMIUM FRIEND CARD */
.friend-card {
    background: linear-gradient(135deg, rgba(10,21,53,0.95), rgba(5,10,25,0.98));
    border: 1.5px solid rgba(255,195,25,0.4);
    border-radius: 28px;
    padding: 30px 24px;
    display: flex; flex-direction: column; align-items: center; gap: 16px;
    width: 100%;
    box-shadow: 0 20px 50px rgba(0,0,0,0.8), inset 0 1px 0 rgba(255,255,255,0.05);
    position: relative;
    overflow: hidden;
}
.friend-card::before {
    content: ""; position: absolute; top: -50%; left: -50%; width: 200%; height: 200%;
    background: conic-gradient(from 0deg, transparent, rgba(255,195,25,0.1), transparent, rgba(0,168,255,0.1), transparent);
    animation: rotate 8s linear infinite; z-index: 0;
}
.friend-card > * { position: relative; z-index: 1; }

/* Bada Avatar (Profile Photo) */
.friend-avatar { 
    width: 110px; height: 110px; border-radius: 50%; 
    background: linear-gradient(135deg,#0a1535,#000); 
    border: 4px solid #ffc419; 
    display: grid; place-items: center; 
    font-size: 44px; font-weight: 900; color: #fff; 
    overflow: hidden; 
    box-shadow: 0 0 40px rgba(255,195,25,0.5), 0 0 80px rgba(0,168,255,0.2);
    margin-bottom: 8px;
}
.friend-avatar img { width: 100%; height: 100%; object-fit: cover; }

/* Naam Style */
.friend-name { 
    font-size: 24px; font-weight: 900; 
    color: #fff; text-align: center;
    text-shadow: 0 2px 10px rgba(0,0,0,0.5);
    letter-spacing: 0.5px;
    margin-bottom: 2px;
}

/* ID Style */
.friend-id { 
    font-size: 13px; color: #ffc419; font-weight: 800; 
    letter-spacing: 2px; background: rgba(255,195,25,0.15); 
    display: inline-block; padding: 6px 16px; border-radius: 10px; 
    border: 1px solid rgba(255,195,25,0.4);
}

/* Add Button */
.add-btn { 
    width: 100%; padding: 18px; 
    background: linear-gradient(135deg,#00b359,#00e676); 
    color: #fff; border: none; border-radius: 16px; 
    font-size: 16px; font-weight: 900; cursor: pointer; 
    letter-spacing: 1px;
    box-shadow: 0 8px 25px rgba(0,179,89,0.4);
    margin-top: 10px;
    display: flex; align-items: center; justify-content: center; gap: 8px;
}
.add-btn:active { transform: scale(0.96); }

@keyframes rotate { 100% { transform: rotate(360deg); } }
`;
h = h.replace(oldFriendCSS, newFriendCSS);

// 2. Search Result me Photo aur Naam sahi tarike se dikhao
// (Purana render logic hata kar naya lagao)
const oldRender = /result\.innerHTML = `[\s\S]*?<\/div>\s*`;/;
const newRender = `result.innerHTML = \`
                <div class="friend-card">
                    <div class="friend-avatar">
                        \${u.photo ? '<img src="' + u.photo + '" alt="' + u.name + '">' : u.name.charAt(0).toUpperCase()}
                    </div>
                    <div class="friend-name">\${u.name}</div>
                    <div class="friend-id">\${u.accountId || input}</div>
                    <button class="add-btn" onclick="addFriend('\${u.userId}', '\${u.name.replace(/'/g, "\\\\'")}', '\${input}')">
                        <span style="font-size:20px;">+</span> ADD FRIEND
                    </button>
                </div>
            \`;`;
h = h.replace(oldRender, newRender);

fs.writeFileSync('add-friend.html', h);
console.log('✅ Friend Card upgraded with Photo & Name!');
