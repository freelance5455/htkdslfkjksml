const fs = require('fs');
let h = fs.readFileSync('dashboard.html', 'utf8');

if (h.includes('morePage')) {
    console.log('already exists');
    process.exit(0);
}

// CSS
const moreCSS = `
.more-page{position:fixed;inset:0;z-index:1000;background:linear-gradient(180deg,#050b1f 0%,#0a0f2e 50%,#050b1f 100%);transform:translateX(100%);transition:transform .35s cubic-bezier(.4,0,.2,1);overflow-y:auto;padding-bottom:90px}
.more-page.show{transform:translateX(0)}
.more-page::before{content:"";position:fixed;top:0;left:0;right:0;height:300px;background:radial-gradient(circle at 50% 0%,rgba(0,150,255,.2),transparent 60%);pointer-events:none}
.more-header{position:sticky;top:0;z-index:10;display:flex;align-items:center;gap:14px;padding:16px 18px;background:rgba(5,11,31,.95);border-bottom:1px solid rgba(0,150,255,.15);backdrop-filter:blur(12px)}
.more-back{width:42px;height:42px;border-radius:50%;background:rgba(0,150,255,.1);border:1px solid rgba(0,150,255,.3);color:#00a8ff;font-size:20px;cursor:pointer;display:grid;place-items:center;transition:.2s}
.more-back:active{transform:scale(.9);background:rgba(0,150,255,.2)}
.more-title{font-size:22px;font-weight:900;letter-spacing:1px;color:#fff}
.more-menu{padding:18px 16px;max-width:520px;margin:0 auto}
.more-item{position:relative;display:flex;align-items:center;gap:16px;background:linear-gradient(135deg,rgba(10,25,55,.7),rgba(5,11,31,.9));border:1px solid rgba(0,150,255,.2);border-radius:16px;padding:18px 20px;margin-bottom:12px;cursor:pointer;overflow:hidden;transition:all .3s cubic-bezier(.4,0,.2,1)}
.more-item::before{content:"";position:absolute;top:0;left:-100%;width:100%;height:100%;background:linear-gradient(90deg,transparent,rgba(0,180,255,.15),transparent);transition:left .6s}
.more-item:active{transform:translateY(-3px) scale(1.02);border-color:rgba(0,180,255,.6);box-shadow:0 10px 30px rgba(0,150,255,.25)}
.more-item:active::before{left:100%}
.more-icon{width:44px;height:44px;border-radius:12px;display:grid;place-items:center;font-size:20px;flex-shrink:0;background:linear-gradient(135deg,rgba(0,136,255,.2),rgba(0,212,255,.1));border:1px solid rgba(0,150,255,.3);box-shadow:0 0 15px rgba(0,150,255,.15);transition:.3s}
.more-item:active .more-icon{box-shadow:0 0 25px rgba(0,180,255,.5);transform:rotate(-5deg) scale(1.1)}
.more-text{flex:1}
.more-label{font-size:15px;font-weight:700;color:#fff;letter-spacing:.3px;margin-bottom:2px}
.more-desc{font-size:11px;color:#6b8bb8;letter-spacing:.3px}
.more-arrow{color:#5a7ba8;font-size:18px;transition:.3s}
.more-item:active .more-arrow{color:#00a8ff;transform:translateX(4px)}
.more-item.logout-item{background:linear-gradient(135deg,rgba(255,50,50,.08),rgba(5,11,31,.9));border-color:rgba(255,60,60,.25)}
.more-item.logout-item .more-label{color:#ff6b6b}
.more-footer{text-align:center;padding:30px 20px 20px;font-size:11px;color:#3d4a66;letter-spacing:1px}
.more-footer b{color:#00a8ff;font-weight:800}
.more-footer .version{display:inline-block;background:rgba(0,150,255,.1);border:1px solid rgba(0,150,255,.25);padding:4px 12px;border-radius:20px;color:#00a8ff;font-weight:700;margin-top:8px;font-size:10px}
.confirm-overlay{position:fixed;inset:0;z-index:2000;background:rgba(0,5,15,.85);backdrop-filter:blur(8px);display:none;align-items:center;justify-content:center;padding:20px}
.confirm-overlay.show{display:flex}
.confirm-box{background:linear-gradient(180deg,#0a1a3a,#050b1f);border:1px solid rgba(255,60,60,.35);border-radius:20px;padding:28px 24px;max-width:340px;width:100%;text-align:center;box-shadow:0 20px 60px rgba(255,50,50,.2)}
.confirm-box .cb-icon{font-size:50px;margin-bottom:12px}
.confirm-box h3{font-size:20px;font-weight:800;color:#fff;margin-bottom:8px}
.confirm-box p{font-size:13px;color:#a8bddc;line-height:1.6;margin-bottom:22px}
.confirm-actions{display:flex;gap:10px}
.confirm-actions button{flex:1;padding:13px;border:none;border-radius:12px;font-size:14px;font-weight:800;letter-spacing:.5px;cursor:pointer;transition:.2s}
.confirm-actions .cancel{background:rgba(255,255,255,.08);color:#fff;border:1px solid rgba(255,255,255,.15)}
.confirm-actions .confirm-logout{background:linear-gradient(135deg,#ff3b3b,#ff5555);color:#fff}
.confirm-actions button:active{transform:scale(.97)}
`;

h = h.replace('</style>', moreCSS + '\n</style>');

// HTML
const moreHTML = `
<div class="more-page" id="morePage">
    <div class="more-header">
        <button class="more-back" onclick="closeMore()">‹</button>
        <div class="more-title">More</div>
    </div>
    <div class="more-menu">
        <div class="more-item" onclick="moreAction('Profile')">
            <div class="more-icon">👤</div>
            <div class="more-text"><div class="more-label">Profile</div><div class="more-desc">View and edit your profile</div></div>
            <div class="more-arrow">›</div>
        </div>
        <div class="more-item" onclick="moreAction('Settings')">
            <div class="more-icon">⚙️</div>
            <div class="more-text"><div class="more-label">Settings</div><div class="more-desc">App preferences and privacy</div></div>
            <div class="more-arrow">›</div>
        </div>
        <div class="more-item" onclick="moreAction('Support')">
            <div class="more-icon">🎧</div>
            <div class="more-text"><div class="more-label">Support</div><div class="more-desc">Get help from our team</div></div>
            <div class="more-arrow">›</div>
        </div>
        <div class="more-item" onclick="moreAction('FAQs')">
            <div class="more-icon">❓</div>
            <div class="more-text"><div class="more-label">FAQs</div><div class="more-desc">Frequently asked questions</div></div>
            <div class="more-arrow">›</div>
        </div>
        <div class="more-item" onclick="moreAction('About IBA')">
            <div class="more-icon">ℹ️</div>
            <div class="more-text"><div class="more-label">About IBA</div><div class="more-desc">About Indian Battelle Arena</div></div>
            <div class="more-arrow">›</div>
        </div>
        <div class="more-item logout-item" onclick="confirmLogout()">
            <div class="more-icon">🚪</div>
            <div class="more-text"><div class="more-label">Logout</div><div class="more-desc">Sign out from your account</div></div>
            <div class="more-arrow">›</div>
        </div>
    </div>
    <div class="more-footer">Made with <span style="color:#ff4466">♥</span> by <b>IBA</b><div class="version">v1.0.0</div></div>
</div>

<div class="confirm-overlay" id="confirmOverlay">
    <div class="confirm-box">
        <div class="cb-icon">🚪</div>
        <h3>Confirm Logout</h3>
        <p>Are you sure you want to logout from your account?</p>
        <div class="confirm-actions">
            <button class="cancel" onclick="closeConfirm()">Cancel</button>
            <button class="confirm-logout" onclick="doLogout()">Logout</button>
        </div>
    </div>
</div>
`;

h = h.replace('</body>', moreHTML + '\n</body>');

// JS
const moreJS = `
function openMore(){
    document.getElementById('morePage').classList.add('show');
    document.body.style.overflow = 'hidden';
}
function closeMore(){
    document.getElementById('morePage').classList.remove('show');
    document.body.style.overflow = '';
}
function moreAction(action){
    comingSoon(action);
}
function confirmLogout(){
    document.getElementById('confirmOverlay').classList.add('show');
}
function closeConfirm(){
    document.getElementById('confirmOverlay').classList.remove('show');
}
function doLogout(){
    localStorage.clear();
    sessionStorage.clear();
    location.replace('login.html');
}
document.getElementById('confirmOverlay').addEventListener('click', function(e){
    if(e.target.id === 'confirmOverlay') closeConfirm();
});
window.addEventListener('popstate', function(){
    if(document.getElementById('morePage').classList.contains('show')){
        closeMore();
    }
});
`;

const lastScriptIdx = h.lastIndexOf('</script>');
h = h.slice(0, lastScriptIdx) + moreJS + '\n' + h.slice(lastScriptIdx);

// More button update karo
const oldMoreBtn = `onclick="navClick(this,'More')"`;
const newMoreBtn = `onclick="navClick(this,'More');openMore()"`;
h = h.replace(oldMoreBtn, newMoreBtn);

fs.writeFileSync('dashboard.html', h);
console.log('✅ More page added!');
