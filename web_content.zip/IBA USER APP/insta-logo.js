const fs = require('fs');
let h = fs.readFileSync('about.html', 'utf8');

// Purane camera emoji (📸) wale icon ko naye SVG Instagram logo se replace karo
const oldInstaIcon = `<div class="social-icon" style="background:rgba(225,48,108,0.15);">📸</div>`;

const newInstaIcon = `<div class="social-icon" style="background:linear-gradient(45deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%);">
                <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                    <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                </svg>
            </div>`;

if (h.includes(oldInstaIcon)) {
    h = h.replace(oldInstaIcon, newInstaIcon);
    console.log('✅ Instagram ka asli logo lag gaya!');
} else {
    console.log('❌ Purana icon nahi mila.');
}

fs.writeFileSync('about.html', h);
