const fs = require('fs');
let h = fs.readFileSync('dashboard.html', 'utf8');

// Dashboard me back button prevent logic
const backScript = `
<script>
// Prevent going back to login page
history.pushState(null, null, location.href);
window.onpopstate = function () {
    history.go(1);
};
</script>
`;

// Check karo pehle se hai ya nahi
if (!h.includes('window.onpopstate')) {
    h = h.replace('</body>', backScript + '\n</body>');
}

fs.writeFileSync('dashboard.html', h);
console.log('✅ Back button prevention added!');
