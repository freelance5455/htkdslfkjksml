const fs = require('fs');
let h = fs.readFileSync('edit-profile.html', 'utf8');

// 1. Message change karo (Send OTP ke time)
h = h.replace(
    "nmMsg('OTP sent to your mobile! Check Termux.', 'success');",
    "nmMsg('New OTP sent!', 'success');"
);

// 2. Resend ke time wala message bhi change karo
h = h.replace(
    "nmMsg('New OTP sent! Check Termux.', 'success');",
    "nmMsg('New OTP sent!', 'success');"
);

fs.writeFileSync('edit-profile.html', h);
console.log('✅ Message updated to "New OTP sent!"');
