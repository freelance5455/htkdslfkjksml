const fs = require('fs');
let h = fs.readFileSync('edit-profile.html', 'utf8');

// 1. "GAME DETAILS" wala divider hatao
h = h.replace(/<div class="divider"><span>GAME DETAILS<\/span><\/div>/g, '');

// 2. Free Fire IGN wala field hatao
const ffNameHTML = /<div class="form-group">\s*<label class="form-label">FREE FIRE IGN \(IN-GAME NAME\)<\/label>[\s\S]*?<\/div>\s*<\/div>/;
h = h.replace(ffNameHTML, '');

// 3. Free Fire UID wala field hatao
const ffUidHTML = /<div class="form-group">\s*<label class="form-label">FREE FIRE UID<\/label>[\s\S]*?<\/div>\s*<\/div>/;
h = h.replace(ffUidHTML, '');

// 4. Niche wala text hatao ("Your IGN and UID will be used...")
h = h.replace(/<div class="info-text">Your IGN and UID will be used for match verification.<\/div>/g, '');

// 5. JS me se ffName aur ffUid ka reference hatao
h = h.replace(/const ffName = ffNameInput\.value\.trim\(\);/g, '');
h = h.replace(/const ffUid = ffUidInput\.value\.trim\(\);/g, '');
h = h.replace(/if \(ffName\) u\.ffName = ffName;/g, '');
h = h.replace(/if \(ffUid\) u\.ffUid = ffUid;/g, '');
h = h.replace(/ffName,/g, '');
h = h.replace(/ffUid,/g, '');

// 6. Load profile me se ffName/ffUid hatao (agar hain toh)
h = h.replace(/ffNameInput\.value = p\.ffName \|\| '';/g, '');
h = h.replace(/ffUidInput\.value = p\.ffUid \|\| '';/g, '');

fs.writeFileSync('edit-profile.html', h);
console.log('✅ Game Details removed from Edit Profile!');
