const fs = require('fs');
let h = fs.readFileSync('dashboard.html', 'utf8');

// Purana "Change Password" button ko "Change Gmail" karo
const oldPassBtn = `<button class="action-btn-3d" onclick="comingSoon('Change Password')">
            <div class="ab-ico">🔒</div>
            Change Password
            <span class="action-arrow">›</span>
        </button>`;

const newGmailBtn = `<button class="action-btn-3d" onclick="openChangeGmail()">
            <div class="ab-ico">📧</div>
            Change Gmail
            <span class="action-arrow">›</span>
        </button>`;

h = h.replace(oldPassBtn, newGmailBtn);

// Edit Profile ko name-only edit karo
const oldEditBtn = `<button class="action-btn-3d" onclick="editProfile()">
            <div class="ab-ico">✏️</div>
            Edit Profile
            <span class="action-arrow">›</span>
        </button>`;

const newEditBtn = `<button class="action-btn-3d" onclick="openEditName()">
            <div class="ab-ico">✏️</div>
            Change Name
            <span class="action-arrow">›</span>
        </button>`;

h = h.replace(oldEditBtn, newEditBtn);

// Avatar pe click handler add karo
h = h.replace(
    `<div class="avatar-main" id="profileAvatar">P</div>`,
    `<div class="avatar-main" id="profileAvatar" onclick="viewPhoto()">P</div>`
);

// ===== MODALS ADD KARO =====
const modals = `
<!-- VIEW PHOTO MODAL -->
<div class="modal" id="viewPhotoModal">
    <div style="position:relative;width:100%;max-width:400px;text-align:center">
        <img id="fullPhoto" style="max-width:100%;max-height:70vh;border-radius:20px;border:3px solid rgba(0,150,255,.5);box-shadow:0 0 60px rgba(0,150,255,.6)" />
        <button onclick="closeViewPhoto()" style="margin-top:20px;padding:12px 30px;background:linear-gradient(135deg,#0088ff,#00a8ff);color:#fff;border:none;border-radius:12px;font-size:14px;font-weight:800;cursor:pointer">CLOSE</button>
    </div>
</div>

<!-- CHANGE NAME MODAL -->
<div class="modal" id="changeNameModal">
    <div class="modal-box" style="text-align:left">
        <div style="text-align:center"><div class="mb-icon">✏️</div></div>
        <h3 style="text-align:center">Change Name</h3>
        <p style="text-align:center;margin-bottom:16px">Enter your new display name</p>
        <input type="text" id="newNameInput" maxlength="30" placeholder="Enter new name" style="width:100%;padding:14px;background:rgba(5,5,25,.8);border:1.5px solid rgba(80,100,255,.35);border-radius:12px;color:#fff;font-size:15px;font-weight:600;outline:none;margin-bottom:10px">
        <div id="nameMsg" style="font-size:12px;text-align:center;min-height:16px;font-weight:600;margin-bottom:14px"></div>
        <div style="display:flex;gap:10px">
            <button onclick="closeEditName()" style="flex:1;padding:14px;background:rgba(255,255,255,.08);color:#fff;border:1px solid rgba(255,255,255,.15);border-radius:12px;font-size:14px;font-weight:800;cursor:pointer">CANCEL</button>
            <button id="saveNameBtn" onclick="saveName()" style="flex:1;padding:14px;background:linear-gradient(135deg,#0088ff,#00a8ff);color:#fff;border:none;border-radius:12px;font-size:14px;font-weight:800;cursor:pointer">SAVE</button>
        </div>
    </div>
</div>

<!-- CHANGE GMAIL MODAL -->
<div class="modal" id="changeGmailModal">
    <div class="modal-box" style="text-align:left;max-width:380px">
        <div style="text-align:center"><div class="mb-icon">📧</div></div>
        <h3 style="text-align:center">Change Gmail</h3>
        <p style="text-align:center;margin-bottom:18px;font-size:12px">Step <span id="gmailStep">1</span> of 2</p>

        <!-- STEP 1: OLD EMAIL -->
        <div id="gmailStep1">
            <div style="background:rgba(80,120,255,.1);border:1px solid rgba(80,120,255,.3);border-radius:10px;padding:12px;margin-bottom:14px">
                <div style="font-size:10px;color:#6b8bb8;letter-spacing:1px;margin-bottom:4px">CURRENT EMAIL</div>
                <div id="oldEmailText" style="font-size:14px;color:#fff;font-weight:600;word-break:break-all">-</div>
            </div>
            <button id="sendOldOtpBtn" onclick="sendOldOtp()" style="width:100%;padding:13px;background:linear-gradient(135deg,#0088ff,#00a8ff);color:#fff;border:none;border-radius:12px;font-size:13px;font-weight:800;cursor:pointer;margin-bottom:12px">📧 SEND OTP TO OLD EMAIL</button>
            <div id="oldOtpBox" style="display:none">
                <input type="tel" id="oldOtpInput" maxlength="6" inputmode="numeric" placeholder="Enter OTP from old email" style="width:100%;padding:13px;background:rgba(5,5,25,.8);border:1.5px solid rgba(80,100,255,.35);border-radius:12px;color:#fff;font-size:14px;font-weight:600;outline:none;letter-spacing:2px;text-align:center;margin-bottom:10px">
                <button onclick="verifyOldOtp()" style="width:100%;padding:13px;background:linear-gradient(135deg,#00b359,#00e676);color:#fff;border:none;border-radius:12px;font-size:13px;font-weight:800;cursor:pointer">VERIFY OLD EMAIL</button>
            </div>
        </div>

        <!-- STEP 2: NEW EMAIL -->
        <div id="gmailStep2" style="display:none">
            <input type="email" id="newEmailInput" placeholder="Enter new Gmail" style="width:100%;padding:13px;background:rgba(5,5,25,.8);border:1.5px solid rgba(80,100,255,.35);border-radius:12px;color:#fff;font-size:14px;font-weight:600;outline:none;margin-bottom:10px">
            <button id="sendNewOtpBtn" onclick="sendNewOtp()" style="width:100%;padding:13px;background:linear-gradient(135deg,#0088ff,#00a8ff);color:#fff;border:none;border-radius:12px;font-size:13px;font-weight:800;cursor:pointer;margin-bottom:12px">📧 SEND OTP TO NEW EMAIL</button>
            <div id="newOtpBox" style="display:none">
                <input type="tel" id="newOtpInput" maxlength="6" inputmode="numeric" placeholder="Enter OTP from new email" style="width:100%;padding:13px;background:rgba(5,5,25,.8);border:1.5px solid rgba(80,100,255,.35);border-radius:12px;color:#fff;font-size:14px;font-weight:600;outline:none;letter-spacing:2px;text-align:center;margin-bottom:10px">
                <button onclick="verifyNewOtp()" style="width:100%;padding:13px;background:linear-gradient(135deg,#00b359,#00e676);color:#fff;border:none;border-radius:12px;font-size:13px;font-weight:800;cursor:pointer">VERIFY & UPDATE GMAIL</button>
            </div>
        </div>

        <div id="gmailMsg" style="font-size:12px;text-align:center;min-height:16px;font-weight:600;margin-top:12px"></div>
        <button onclick="closeChangeGmail()" style="width:100%;margin-top:14px;padding:12px;background:rgba(255,255,255,.08);color:#fff;border:1px solid rgba(255,255,255,.15);border-radius:12px;font-size:13px;font-weight:700;cursor:pointer">CANCEL</button>
    </div>
</div>
`;

h = h.replace('</body>', modals + '\n</body>');

// ===== JS FUNCTIONS =====
const jsCode = `
// ===== VIEW PHOTO =====
function viewPhoto(){
    const photo = localStorage.getItem('iba_photo');
    if(!photo){
        showToast('No photo uploaded');
        return;
    }
    document.getElementById('fullPhoto').src = photo;
    document.getElementById('viewPhotoModal').classList.add('show');
}
function closeViewPhoto(){
    document.getElementById('viewPhotoModal').classList.remove('show');
}
document.getElementById('viewPhotoModal').addEventListener('click', function(e){
    if(e.target.id === 'viewPhotoModal') closeViewPhoto();
});

// ===== CHANGE NAME =====
function openEditName(){
    const currentName = localStorage.getItem('iba_name') || '';
    document.getElementById('newNameInput').value = currentName;
    document.getElementById('nameMsg').textContent = '';
    document.getElementById('changeNameModal').classList.add('show');
    setTimeout(() => document.getElementById('newNameInput').focus(), 200);
}
function closeEditName(){
    document.getElementById('changeNameModal').classList.remove('show');
}
async function saveName(){
    const newName = document.getElementById('newNameInput').value.trim();
    const msg = document.getElementById('nameMsg');
    const btn = document.getElementById('saveNameBtn');
    if(newName.length < 2){ msg.style.color='#ff5577'; msg.textContent = 'Enter valid name (min 2 chars)'; return; }
    const userId = localStorage.getItem('iba_userId');
    btn.disabled = true; btn.textContent = 'SAVING...';
    try{
        const r = await fetch('http://localhost:3102/api/user/update-profile', {
            method: 'POST', headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ userId, name: newName })
        });
        const d = await r.json();
        if(d.success){
            localStorage.setItem('iba_name', newName);
            msg.style.color = '#00e676';
            msg.textContent = '✅ Name updated!';
            document.getElementById('profileName').textContent = newName;
            setTimeout(() => {
                closeEditName();
                showToast('✅ Name updated');
            }, 900);
        } else {
            msg.style.color = '#ff5577'; msg.textContent = '❌ ' + (d.error || 'Failed');
        }
    } catch(e){
        msg.style.color = '#ff5577'; msg.textContent = '❌ Server failed';
    }
    btn.disabled = false; btn.textContent = 'SAVE';
}

// ===== CHANGE GMAIL =====
function openChangeGmail(){
    const oldEmail = document.getElementById('infoEmail').textContent;
    if(!oldEmail || oldEmail === 'Not set'){
        showToast('No email found. Please set email first.');
        return;
    }
    document.getElementById('oldEmailText').textContent = oldEmail;
    document.getElementById('gmailStep').textContent = '1';
    document.getElementById('gmailStep1').style.display = 'block';
    document.getElementById('gmailStep2').style.display = 'none';
    document.getElementById('oldOtpBox').style.display = 'none';
    document.getElementById('newOtpBox').style.display = 'none';
    document.getElementById('oldOtpInput').value = '';
    document.getElementById('newOtpInput').value = '';
    document.getElementById('newEmailInput').value = '';
    document.getElementById('gmailMsg').textContent = '';
    document.getElementById('sendOldOtpBtn').textContent = '📧 SEND OTP TO OLD EMAIL';
    document.getElementById('sendOldOtpBtn').disabled = false;
    document.getElementById('changeGmailModal').classList.add('show');
}
function closeChangeGmail(){
    document.getElementById('changeGmailModal').classList.remove('show');
}
function gmailMsg(t, c){
    const m = document.getElementById('gmailMsg');
    m.style.color = c === 'error' ? '#ff5577' : (c === 'success' ? '#00e676' : '#5ddcff');
    m.textContent = t;
}

async function sendOldOtp(){
    const userId = localStorage.getItem('iba_userId');
    const btn = document.getElementById('sendOldOtpBtn');
    btn.disabled = true; btn.textContent = 'SENDING...';
    try{
        const r = await fetch('http://localhost:3102/api/user/send-otp-old-email', {
            method: 'POST', headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ userId })
        });
        const d = await r.json();
        if(d.success){
            gmailMsg('✅ OTP sent to OLD email (check Termux)', 'success');
            document.getElementById('oldOtpBox').style.display = 'block';
            btn.textContent = '📧 OTP SENT';
            document.getElementById('oldOtpInput').focus();
        } else {
            gmailMsg('❌ ' + (d.error || 'Failed'), 'error');
            btn.disabled = false; btn.textContent = '📧 SEND OTP TO OLD EMAIL';
        }
    } catch(e){
        gmailMsg('❌ Server failed', 'error');
        btn.disabled = false; btn.textContent = '📧 SEND OTP TO OLD EMAIL';
    }
}

async function verifyOldOtp(){
    const userId = localStorage.getItem('iba_userId');
    const otp = document.getElementById('oldOtpInput').value.trim();
    if(otp.length !== 6){ gmailMsg('❌ Enter 6-digit OTP', 'error'); return; }
    try{
        const r = await fetch('http://localhost:3102/api/user/verify-old-email-otp', {
            method: 'POST', headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ userId, otp })
        });
        const d = await r.json();
        if(d.success){
            gmailMsg('✅ Old email verified! Enter new Gmail', 'success');
            document.getElementById('gmailStep').textContent = '2';
            document.getElementById('gmailStep1').style.display = 'none';
            document.getElementById('gmailStep2').style.display = 'block';
            setTimeout(() => document.getElementById('newEmailInput').focus(), 200);
        } else {
            gmailMsg('❌ ' + (d.error || 'Invalid OTP'), 'error');
        }
    } catch(e){
        gmailMsg('❌ Server failed', 'error');
    }
}

async function sendNewOtp(){
    const userId = localStorage.getItem('iba_userId');
    const newEmail = document.getElementById('newEmailInput').value.trim();
    const btn = document.getElementById('sendNewOtpBtn');
    if(!/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(newEmail)){ gmailMsg('❌ Enter valid email', 'error'); return; }
    btn.disabled = true; btn.textContent = 'SENDING...';
    try{
        const r = await fetch('http://localhost:3102/api/user/send-otp-new-email', {
            method: 'POST', headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ userId, newEmail })
        });
        const d = await r.json();
        if(d.success){
            gmailMsg('✅ OTP sent to NEW email (check Termux)', 'success');
            document.getElementById('newOtpBox').style.display = 'block';
            btn.textContent = '📧 OTP SENT';
            document.getElementById('newOtpInput').focus();
        } else {
            gmailMsg('❌ ' + (d.error || 'Failed'), 'error');
            btn.disabled = false; btn.textContent = '📧 SEND OTP TO NEW EMAIL';
        }
    } catch(e){
        gmailMsg('❌ Server failed', 'error');
        btn.disabled = false; btn.textContent = '📧 SEND OTP TO NEW EMAIL';
    }
}

async function verifyNewOtp(){
    const userId = localStorage.getItem('iba_userId');
    const otp = document.getElementById('newOtpInput').value.trim();
    if(otp.length !== 6){ gmailMsg('❌ Enter 6-digit OTP', 'error'); return; }
    try{
        const r = await fetch('http://localhost:3102/api/user/verify-new-email-otp', {
            method: 'POST', headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ userId, otp })
        });
        const d = await r.json();
        if(d.success){
            gmailMsg('✅ Gmail updated successfully!', 'success');
            document.getElementById('infoEmail').textContent = d.email;
            setTimeout(() => {
                closeChangeGmail();
                showToast('✅ Gmail updated');
            }, 1200);
        } else {
            gmailMsg('❌ ' + (d.error || 'Invalid OTP'), 'error');
        }
    } catch(e){
        gmailMsg('❌ Server failed', 'error');
    }
}
`;

const lastScriptIdx3 = h.lastIndexOf('</script>');
h = h.slice(0, lastScriptIdx3) + jsCode + '\n' + h.slice(lastScriptIdx3);

fs.writeFileSync('dashboard.html', h);
console.log('✅ Profile features updated!');
