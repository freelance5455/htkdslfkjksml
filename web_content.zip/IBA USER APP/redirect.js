const fs = require('fs');
let html = fs.readFileSync('index.html', 'utf8');

if(html.includes('location.protocol==="file:"')){
    console.log('ℹ️ Redirect already exists');
    process.exit(0);
}

const redirectCode = `<script>if(location.protocol==="file:"){location.replace("http://localhost:3102/user/index.html");}</script>
`;

// <head> ke turant baad insert karo
const headIdx = html.indexOf('<head>');
if(headIdx === -1){ console.log('❌ <head> not found'); process.exit(1); }
const headEnd = headIdx + 6;

html = html.slice(0, headEnd) + '\n' + redirectCode + html.slice(headEnd);
fs.writeFileSync('index.html', html);
console.log('✅ Auto-redirect added!');
