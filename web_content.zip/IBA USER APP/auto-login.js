const fs = require('fs');
let h = fs.readFileSync('login.html', 'utf8');

// 1. Login page ke shuru me Auto-Login check add karo
const autoLoginScript = `
<script>
// AUTO-LOGIN CHECK
// Agar user pehle se logged in hai, toh dashboard par bhej do
(function() {
    var savedUserId = localStorage.getItem('iba_userId');
    var savedMobile = localStorage.getItem('iba_mobile');
    
    if (savedUserId && savedMobile) {
        // User logged in hai, seedha dashboard par bhejo
        window.location.replace('dashboard.html');
    }
})();
</script>
`;

// Yeh script </head> ke pehle daalo (taaki page load hote hi check ho jaye)
h = h.replace('</head>', autoLoginScript + '\n</head>');

fs.writeFileSync('login.html', h);
console.log('✅ Auto-Login check added to login.html!');
