const fs = require('fs');
let h = fs.readFileSync('add-friend.html', 'utf8');

// 1. Custom Success Popup HTML & CSS add karo
const popupHTML = `
<!-- PREMIUM ADD SUCCESS POPUP -->
<div class="success-popup-overlay" id="successPopup">
    <div class="success-popup-box">
        <div class="success-icon-circle">🎉</div>
        <h3>Friend Added!</h3>
        <p>Successfully added <b id="addedFriendName">Friend</b> to your list.</p>
        <button class="success-ok-btn" onclick="closeSuccessPopup()">AWESOME</button>
    </div>
</div>

<style>
.success-popup-overlay {
    position: fixed; inset: 0; z-index: 9999;
    background: rgba(0, 0, 0, 0.85);
    backdrop-filter: blur(8px);
    display: none;
    align-items: center;
    justify-content: center;
    padding: 20px;
}
.success-popup-overlay.show { display: flex; }
.success-popup-box {
    background: linear-gradient(180deg, #0a1535, #02040a);
    border: 1.5px solid rgba(0, 230, 118, 0.4);
    border-radius: 24px;
    padding: 30px 24px;
    max-width: 320px;
    width: 100%;
    text-align: center;
    box-shadow: 0 20px 60px rgba(0, 230, 118, 0.2);
    animation: popIn 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
}
@keyframes popIn {
    from { transform: scale(0.8); opacity: 0; }
    to { transform: scale(1); opacity: 1; }
}
.success-icon-circle {
    width: 80px; height: 80px;
    background: rgba(0, 230, 118, 0.15);
    border-radius: 50%;
    display: grid; place-items: center;
    font-size: 40px;
    margin: 0 auto 16px;
    border: 2px solid rgba(0, 230, 118, 0.4);
    animation: bounce 1s infinite alternate;
}
@keyframes bounce {
    to { transform: translateY(-8px); }
}
.success-popup-box h3 {
    font-size: 22px; font-weight: 900; color: #fff; margin-bottom: 8px;
}
.success-popup-box p {
    font-size: 13px; color: #a8bddc; line-height: 1.6; margin-bottom: 24px;
}
.success-popup-box p b { color: #00e676; }
.success-ok-btn {
    width: 100%; padding: 16px;
    background: linear-gradient(135deg, #00b359, #00e676);
    color: #fff; border: none; border-radius: 14px;
    font-size: 15px; font-weight: 900; letter-spacing: 1px;
    cursor: pointer;
    box-shadow: 0 8px 25px rgba(0, 179, 89, 0.4);
    transition: 0.2s;
}
.success-ok-btn:active { transform: scale(0.96); }
</style>
`;
h = h.replace('</body>', popupHTML + '\n</body>');

// 2. Purana alert('Friend added') hata kar naya popup dikhao
const oldAddFriendJS = `function addFriend(userId, name, ibaId, photo) {
    var myId = localStorage.getItem('iba_userId');
    fetch(SERVER + '/api/add-friend', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ myId: myId, friendId: userId, friendName: name, friendIbaId: ibaId, friendPhoto: photo })
    }).then(function() {
        alert('✅ Friend added!');
        document.getElementById('friendIdInput').value = '';
        document.getElementById('resultArea').innerHTML = '<div class="empty-state"><p>Search for a friend</p></div>';
        loadMyFriends();
    });
}`;

const newAddFriendJS = `function addFriend(userId, name, ibaId, photo) {
    var myId = localStorage.getItem('iba_userId');
    
    // Name dikhao popup me
    document.getElementById('addedFriendName').textContent = name;
    
    // Server pe save karo
    fetch(SERVER + '/api/add-friend', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ myId: myId, friendId: userId, friendName: name, friendIbaId: ibaId, friendPhoto: photo })
    }).then(function() {
        // Premium popup dikhao
        document.getElementById('successPopup').classList.add('show');
        
        // Search input clear karo
        document.getElementById('friendIdInput').value = '';
        document.getElementById('resultArea').innerHTML = '<div class="empty-state"><div class="icon">👥</div><p>Search for a friend by their IBA ID</p></div>';
    });
}

function closeSuccessPopup() {
    document.getElementById('successPopup').classList.remove('show');
    loadMyFriends(); // List refresh karo
}`;

h = h.replace(oldAddFriendJS, newAddFriendJS);

fs.writeFileSync('add-friend.html', h);
console.log('✅ Premium Success Popup added!');
