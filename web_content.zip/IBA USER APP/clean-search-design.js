const fs = require('fs');
let h = fs.readFileSync('add-friend.html', 'utf8');

// 1. Background ke peeche wale Yellow/Blue dhabbe (orbs) hatao
h = h.replace(/<div class="bg-orb orb-1"><\/div>/g, '');
h = h.replace(/<div class="bg-orb orb-2"><\/div>/g, '');

// 2. Body ka background ekdum clean dark gradient karo (koi dhabba nahi)
h = h.replace(
    /body\{background:radial-gradient\(circle at 50% 0%, #0a1535 0%, #02040a 60%, #000 100%\)\}/,
    'body{background: #02040a;}'
);

// 3. Search Box ko ekdum naya "Glass" look do
const oldSearchBox = /\/\* SEARCH BOX \*\/[\s\S]*?\.search-btn:active\{transform:scale\(0\.92\)\}/;
const newSearchBox = `
/* NEW CLEAN SEARCH BOX */
.search-section {
    background: linear-gradient(180deg, rgba(10, 21, 53, 0.4) 0%, rgba(2, 4, 10, 0) 100%);
    padding: 30px 20px;
    border-radius: 24px;
    margin-bottom: 20px;
    border: 1px solid rgba(255,255,255,0.05);
}
.search-box {
    position: relative;
    display: flex;
    gap: 12px;
    align-items: center;
    background: #0a1535; /* Dark solid */
    padding: 8px;
    border-radius: 20px;
    border: 1px solid rgba(255, 195, 25, 0.3);
    box-shadow: 0 10px 30px rgba(0,0,0,0.5);
}
.input-wrapper {
    flex: 1;
    position: relative;
    display: flex;
    align-items: center;
}
.input-field {
    width: 100%;
    padding: 16px 16px 16px 48px;
    background: transparent;
    border: none;
    color: #fff;
    font-size: 16px;
    font-weight: 700;
    outline: none;
    letter-spacing: 1px;
    font-family: monospace;
}
.input-field::placeholder {
    color: #5a7ba8;
    font-family: 'Segoe UI', sans-serif;
    font-weight: 500;
    letter-spacing: 0.5px;
}
.search-input-icon {
    position: absolute;
    left: 16px;
    font-size: 20px;
    color: #ffc419;
}
.search-btn {
    width: 52px;
    height: 52px;
    background: #ffc419;
    color: #000;
    border: none;
    border-radius: 14px;
    font-size: 20px;
    cursor: pointer;
    box-shadow: 0 4px 15px rgba(255, 195, 25, 0.3);
    transition: 0.2s;
    display: grid;
    place-items: center;
    flex-shrink: 0;
}
.search-btn:active {
    transform: scale(0.92);
    background: #ff9800;
}
`;
h = h.replace(oldSearchBox, newSearchBox);

// 4. Empty State Icon (👥) ko clean karo
h = h.replace(
    /<div style="font-size:60px; margin-bottom:16px; opacity:0.8; filter: drop-shadow\(0 0 15px rgba\(0,168,255,0\.3\)\);">👥<\/div>/,
    '<div style="font-size:60px; margin-bottom:20px; opacity:0.4; color:#fff;">👥</div>'
);

fs.writeFileSync('add-friend.html', h);
console.log('✅ Clean & Professional Search Box Ready!');
