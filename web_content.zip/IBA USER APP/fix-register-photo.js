const fs = require('fs');
let h = fs.readFileSync('register.html', 'utf8');

// Photo input handler dhundo aur simple banao
const simplePhotoLogic = `
// SIMPLE PHOTO UPLOAD
var croppedData = '';

document.getElementById('photoInput').addEventListener('change', function(e) {
    var file = e.target.files[0];
    if(!file) return;
    if(file.size > 10 * 1024 * 1024) {
        alert('Photo max 10MB');
        return;
    }
    
    var reader = new FileReader();
    reader.onload = function(ev) {
        var img = new Image();
        img.onload = function() {
            // Crop to square
            var canvas = document.createElement('canvas');
            canvas.width = 300;
            canvas.height = 300;
            var ctx = canvas.getContext('2d');
            var size = Math.min(img.width, img.height);
            var sx = (img.width - size) / 2;
            var sy = (img.height - size) / 2;
            ctx.drawImage(img, sx, sy, size, size, 0, 0, 300, 300);
            croppedData = canvas.toDataURL('image/jpeg', 0.85);
            
            // Show preview
            var preview = document.getElementById('photoImg');
            preview.src = croppedData;
            preview.style.display = 'block';
            document.getElementById('photoPreview').classList.add('has-image');
        };
        img.src = ev.target.result;
    };
    reader.readAsDataURL(file);
    e.target.value = '';
});
`;

// Purana crop modal logic hatao, naya simple lagao
// Photo input ke purane event listeners hatao
h = h.replace(/document\.getElementById\('photoInput'\)\.addEventListener\('change',[\s\S]*?\}\);/g, '');
h = h.replace(/function openCrop\(\)[\s\S]*?\n\}/g, '');
h = h.replace(/function closeCrop\(\)[\s\S]*?\n\}/g, '');
h = h.replace(/function drawCrop\(\)[\s\S]*?\n\}/g, '');
h = h.replace(/function clampOffset\(\)[\s\S]*?\n\}/g, '');
h = h.replace(/function saveCrop\(\)[\s\S]*?\n\}/g, '');

// Naya simple photo logic add karo
h = h.replace('// ===== LIVE VALIDATION =====', simplePhotoLogic + '\n// ===== LIVE VALIDATION =====');

fs.writeFileSync('register.html', h);
console.log('✅ Register photo upload simplified!');
