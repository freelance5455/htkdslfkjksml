const fs = require('fs');
let h = fs.readFileSync('edit-profile.html', 'utf8');

// Purana photo handler dhundo aur simple se replace karo
const oldHandler = /function handlePhoto\(e\) \{[\s\S]*?\n\}/;
const newHandler = `function handlePhoto(e) {
    var file = e.target.files[0];
    if(!file) return;
    if(file.size > 10 * 1024 * 1024) {
        alert('Photo max 10MB');
        return;
    }
    
    var reader = new FileReader();
    reader.onload = function(ev) {
        var img = new Image();
        img.onload = function() {
            var canvas = document.createElement('canvas');
            canvas.width = 300;
            canvas.height = 300;
            var ctx = canvas.getContext('2d');
            var size = Math.min(img.width, img.height);
            var sx = (img.width - size) / 2;
            var sy = (img.height - size) / 2;
            ctx.drawImage(img, sx, sy, size, size, 0, 0, 300, 300);
            newPhotoData = canvas.toDataURL('image/jpeg', 0.85);
            
            avatarPreview.innerHTML = '<img src="' + newPhotoData + '">';
        };
        img.src = ev.target.result;
    };
    reader.readAsDataURL(file);
    e.target.value = '';
}`;

h = h.replace(oldHandler, newHandler);
fs.writeFileSync('edit-profile.html', h);
console.log('✅ Profile photo handler fixed!');
