const fs = require('fs');
let h = fs.readFileSync('add-friend.html', 'utf8');

// 1. CSS ko replace karo (Premium 4D Design)
const newCSS = `
*{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent;font-family:'Segoe UI',system-ui,Arial,sans-serif}
html,body{width:100%;min-height:100vh;background:#02040a;color:#fff;overflow-x:hidden}
body{background:radial-gradient(circle at 50% 0%, #0a1535 0%, #02040a 60%, #000 100%)}

/* ANIMATED BACKGROUND ORBS */
.bg-orb{position:fixed;border-radius:50%;filter:blur(80px);z-index:0;pointer-events:none;opacity:0.4}
.orb-1{width:300px;height:300px;background:#ffc419;top:-100px;left:-100px;animation:float1 8s ease-in-out infinite}
.orb-2{width:250px;height:250px;background:#00a8ff;bottom:-100px;right:-100px;animation:float2 10s ease-in-out infinite}
@keyframes float1{0%,100%{transform:translate(0,0)}50%{transform:translate(40px,40px)}}
@keyframes float2{0%,100%{transform:translate(0,0)}50%{transform:translate(-40px,-40px)}}

/* HEADER */
.header{display:flex;align-items:center;padding:16px 20px;position:sticky;top:0;z-index:100;background:rgba(2,4,10,0.7);backdrop-filter:blur(20px);border-bottom:1px solid rgba(255,195,25,0.1)}
.back-btn{width:40px;height:40px;border-radius:50%;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);color:#fff;font-size:20px;display:grid;place-items:center;cursor:pointer;margin-right:16px}
.header-title{font-size:18px;font-weight:900;letter-spacing:1px;flex:1}
.header-title span{color:#ffc419}

/* MAIN CONTENT */
.main{padding:20px;position:relative;z-index:2}

/* MY ID CARD (Premium) */
.my-id-card{position:relative;background:linear-gradient(135deg, rgba(255,195,25,0.15), rgba(0,168,255,0.05));border:1.5px solid rgba(255,195,25,0.3);border-radius:24px;padding:24px;text-align:center;margin-bottom:24px;overflow:hidden;backdrop-filter:blur(10px);box-shadow:0 20px 40px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.1)}
.my-id-card::before{content:"";position:absolute;top:-50%;left:-50%;width:200%;height:200%;background:conic-gradient(from 0deg, transparent, rgba(255,195,25,0.2), transparent, rgba(0,168,255,0.2), transparent);animation:rotate 6s linear infinite;z-index:0}
@keyframes rotate{100%{transform:rotate(360deg)}}
.my-id-card > *{position:relative;z-index:1}
.my-id-label{font-size:11px;color:#fff;opacity:0.8;letter-spacing:3px;margin-bottom:8px;text-transform:uppercase}
.my-id-value{font-size:32px;font-weight:900;color:#ffc419;letter-spacing:2px;font-family:monospace;text-shadow:0 0 20px rgba(255,195,25,0.5);margin-bottom:8px}
.my-id-hint{font-size:12px;color:#a8bddc}

/* SEARCH SECTION */
.search-section{text-align:center;margin-bottom:24px}
.search-icon{font-size:60px;margin-bottom:12px;filter:drop-shadow(0 0 30px rgba(0,168,255,0.6));animation:floatIcon 3s ease-in-out infinite}
@keyframes floatIcon{0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)}}
.search-section h2{font-size:24px;font-weight:900;margin-bottom:6px}
.search-section h2 span{color:#ffc419}
.search-section p{font-size:13px;color:#8a9bb8;margin-bottom:20px}

/* SEARCH BOX */
.search-box{position:relative;display:flex;gap:10px;margin-bottom:24px}
.input-wrapper{flex:1;position:relative}
.input-field{width:100%;padding:18px 20px 18px 50px;background:rgba(10,21,53,0.8);border:1.5px solid rgba(255,195,25,0.3);border-radius:18px;color:#fff;font-size:16px;font-weight:700;outline:none;letter-spacing:1px;font-family:monospace;transition:0.3s;backdrop-filter:blur(10px)}
.input-field:focus{border-color:#ffc419;box-shadow:0 0 30px rgba(255,195,25,0.2);background:rgba(20,30,60,0.9)}
.input-field::placeholder{color:#3a4a6a;font-family:'Segoe UI',sans-serif;font-weight:500;letter-spacing:0.5px}
.search-input-icon{position:absolute;left:18px;top:50%;transform:translateY(-50%);font-size:18px;color:#ffc419}
.search-btn{width:60px;height:60px;background:linear-gradient(135deg,#ffc419,#ff9800);color:#000;border:none;border-radius:18px;font-size:24px;cursor:pointer;box-shadow:0 8px 25px rgba(255,195,25,0.4);transition:0.2s;flex-shrink:0;display:grid;place-items:center}
.search-btn:active{transform:scale(0.92)}

/* RESULT AREA */
.result-area{min-height:200px;display:flex;align-items:center;justify-content:center}

/* EMPTY STATE */
.empty-state{text-align:center;padding:40px 20px}
.empty-icon-wrap{width:100px;height:100px;margin:0 auto 20px;border-radius:50%;background:linear-gradient(135deg, rgba(255,195,25,0.1), rgba(0,168,255,0.1));border:1px dashed rgba(255,255,255,0.15);display:grid;place-items:center;font-size:40px;opacity:0.6}
.empty-state p{font-size:13px;color:#6b8bb8;line-height:1.6}

/* FRIEND CARD (Premium) */
.friend-card{position:relative;background:linear-gradient(135deg, rgba(10,21,53,0.9), rgba(5,10,25,0.95));border:1.5px solid rgba(0,168,255,0.3);border-radius:24px;padding:24px;display:flex;flex-direction:column;align-items:center;gap:16px;width:100%;box-shadow:0 20px 50px rgba(0,0,0,0.6), inset 0 1px 0 rgba(255,255,255,0.05);animation:popIn 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275)}
@keyframes popIn{from{transform:scale(0.8);opacity:0}to{transform:scale(1);opacity:1}}
.friend-avatar{width:90px;height:90px;border-radius:50%;background:linear-gradient(135deg,#0a1535,#000);border:3px solid #ffc419;display:grid;place-items:center;font-size:36px;font-weight:900;color:#fff;overflow:hidden;box-shadow:0 0 30px rgba(255,195,25,0.3)}
.friend-avatar img{width:100%;height:100%;object-fit:cover}
.friend-info{text-align:center}
.friend-name{font-size:20px;font-weight:900;margin-bottom:6px}
.friend-id{font-size:13px;color:#ffc419;font-weight:800;letter-spacing:2px;background:rgba(255,195,25,0.1);display:inline-block;padding:4px 12px;border-radius:8px;border:1px solid rgba(255,195,25,0.3)}
.add-btn{width:100%;padding:16px;background:linear-gradient(135deg,#00b359,#00e676);color:#fff;border:none;border-radius:16px;font-size:15px;font-weight:900;cursor:pointer;box-shadow:0 8px 25px rgba(0,179,89,0.4);letter-spacing:1px;margin-top:8px}
.add-btn:active{transform:scale(0.96)}

/* SUCCESS CARD */
.success-card{text-align:center;padding:40px 20px;background:linear-gradient(135deg, rgba(0,179,89,0.1), rgba(0,230,118,0.05));border:1.5px solid rgba(0,230,118,0.3);border-radius:24px;animation:popIn 0.4s ease-out}
.success-icon{font-size:70px;margin-bottom:16px;animation:bounce 1s ease infinite alternate}
@keyframes bounce{to{transform:translateY(-10px)}}
.success-card h3{color:#00e676;font-size:22px;font-weight:900;margin-bottom:8px}
.success-card p{color:#a8bddc;font-size:14px;margin-bottom:24px}
.success-actions{display:flex;flex-direction:column;gap:10px}
.btn-chat{padding:16px;background:linear-gradient(135deg,#ffc419,#ff9800);color:#000;border:none;border-radius:16px;font-size:15px;font-weight:900;cursor:pointer;box-shadow:0 8px 25px rgba(255,195,25,0.4)}
.btn-again{padding:14px;background:rgba(255,255,255,0.05);color:#fff;border:1px solid rgba(255,255,255,0.15);border-radius:16px;font-size:14px;font-weight:700;cursor:pointer}

/* ERROR CARD */
.error-card{background:rgba(255,59,59,0.1);border:1.5px solid rgba(255,59,59,0.3);border-radius:20px;padding:24px;text-align:center;max-width:400px;animation:shake 0.5s ease-in-out}
@keyframes shake{0%,100%{transform:translateX(0)}25%{transform:translateX(-8px)}75%{transform:translateX(8px)}}
.error-card .err-icon{font-size:40px;margin-bottom:12px}
.error-card p{color:#ff6b6b;font-size:14px;font-weight:700;line-height:1.5}
`;

// Replace style tag
h = h.replace(/<style>[\s\S]*?<\/style>/, '<style>' + newCSS + '</style>');

// 2. HTML Structure update karo (naya design)
const newHTML = `
<!-- BACKGROUND ORBS -->
<div class="bg-orb orb-1"></div>
<div class="bg-orb orb-2"></div>

<!-- HEADER -->
<div class="header">
    <div class="back-btn" onclick="history.back()">‹</div>
    <div class="header-title">👥 ADD <span>FRIEND</span></div>
</div>

<div class="main">

    <!-- MY ID CARD -->
    <div class="my-id-card">
        <div class="my-id-label">YOUR IBA ID</div>
        <div class="my-id-value" id="myId">IBA000000</div>
        <div class="my-id-hint">Share this ID with friends</div>
    </div>

    <!-- SEARCH SECTION -->
    <div class="search-section">
        <div class="search-icon">🔍</div>
        <h2>Find Your <span>Friend</span></h2>
        <p>Enter your friend's IBA ID to add them</p>
    </div>

    <div class="search-box">
        <div class="input-wrapper">
            <span class="search-input-icon">#</span>
            <input type="text" class="input-field" id="friendIdInput" placeholder="Enter IBA ID (e.g. IBA611802)" maxlength="20">
        </div>
        <button class="search-btn" onclick="searchFriend()">🔍</button>
    </div>

    <!-- RESULT AREA -->
    <div class="result-area" id="resultArea">
        <div class="empty-state">
            <div class="empty-icon-wrap">👥</div>
            <p>Search for a friend by their IBA ID<br>to start chatting with them</p>
        </div>
    </div>

</div>
`;

// Replace body content (script ke pehle tak)
const scriptIndex = h.indexOf('<script>');
const bodyStartIndex = h.indexOf('<body>') + 6;
h = h.slice(0, bodyStartIndex) + newHTML + '\n' + h.slice(scriptIndex);

// 3. JS Result rendering update karo (naya design)
h = h.replace(
    /result\.innerHTML = `[\s\S]*?<\/div>\s*<\/div>\s*`;/,
    `result.innerHTML = \`
                <div class="friend-card">
                    <div class="friend-avatar">\${u.photo ? '<img src="' + u.photo + '">' : u.name.charAt(0).toUpperCase()}</div>
                    <div class="friend-info">
                        <div class="friend-name">\${u.name}</div>
                        <div class="friend-id">\${u.accountId || input}</div>
                    </div>
                    <button class="add-btn" onclick="addFriend('\${u.userId}', '\${u.name}', '\${input}', '\${u.photo || ''}')">+ ADD FRIEND</button>
                </div>
            \`;`
);

// Success card update
h = h.replace(
    /result\.innerHTML = `[\s\S]*?<\/div>\s*`;/,
    `result.innerHTML = \`
        <div class="success-card">
            <div class="success-icon">🎉</div>
            <h3>Friend Added!</h3>
            <p>\${name} is now in your friend list</p>
            <div class="success-actions">
                <button class="btn-chat" onclick="location.href='messages.html?role=player&friend=\${userId}'">💬 CHAT NOW</button>
                <button class="btn-again" onclick="resetSearch()">+ ADD ANOTHER</button>
            </div>
        </div>
    \`;`
);

fs.writeFileSync('add-friend.html', h);
console.log('✅ Add Friend page upgraded to 4D Premium!');
