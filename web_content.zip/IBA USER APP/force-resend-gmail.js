const fs = require('fs');
let h = fs.readFileSync('edit-profile.html', 'utf8');

// 1. "VERIFY OLD EMAIL" button ke theek baad Resend OTP ka HTML add karo
const targetBtn = `<button onclick="verifyOldOtp()" style="width:100%;padding:13px;background:linear-gradient(135deg,#00b359,#00e676);color:#fff;border:none;border-radius:12px;font-size:13px;font-weight:800;cursor:pointer">VERIFY OLD EMAIL</button>`;

const resendHTML = targetBtn + `
                <!-- RESEND OTP -->
                <div style="text-align:center; margin-top:12px; font-size:12px; color:#8a9bb8;">
                    Didn't receive? <span id="resendOldBtn" onclick="resendOldOtp()" style="color:#ffc419; font-weight:700; cursor:pointer; text-decoration:underline;">Resend OTP</span>
                    <span id="resendOldTimer" style="color:#5a6a85;"></span>
                </div>`;

h = h.replace(targetBtn, resendHTML);

// 2. Resend function (JS) add karo (agar pehle se nahi hai)
if (!h.includes('function resendOldOtp')) {
    const resendJS = `
// RESEND OLD GMAIL OTP
var resendOldTimerVar = null;

function startOldResendTimer() {
    var countdown = 30;
    var timerEl = document.getElementById('resendOldTimer');
    var btnEl = document.getElementById('resendOldBtn');
    if(!timerEl || !btnEl) return;
    clearInterval(resendOldTimerVar);
    btnEl.style.display = 'none';
    timerEl.textContent = '(Wait ' + countdown + 's)';
    resendOldTimerVar = setInterval(function() {
        countdown--;
        if(countdown <= 0) {
            clearInterval(resendOldTimerVar);
            timerEl.textContent = '';
            btnEl.style.display = 'inline';
        } else {
            timerEl.textContent = '(Wait ' + countdown + 's)';
        }
    }, 1000);
}

async function resendOldOtp() {
    try {
        const res = await fetch(SERVER + '/api/user/send-otp-old-email', {
            method: 'POST', headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ userId })
        });
        const data = await res.json();
        if(data.success) {
            document.getElementById('oldOtpInput').value = '';
            startOldResendTimer();
        }
    } catch(e) { console.log(e); }
}
`;
    h = h.replace('</script>', resendJS + '\n</script>');
}

// 3. OTP send hone par timer start karo
h = h.replace(
    "document.getElementById('oldOtpBox').style.display = 'block';\n            document.getElementById('sendOldBtn').style.display = 'none';",
    "document.getElementById('oldOtpBox').style.display = 'block';\n            document.getElementById('sendOldBtn').style.display = 'none';\n            startOldResendTimer();"
);

fs.writeFileSync('edit-profile.html', h);
console.log('✅ Resend OTP force added!');
