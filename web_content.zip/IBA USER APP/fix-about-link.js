const fs = require('fs');
let h = fs.readFileSync('settings.html', 'utf8');

// Purana "About IBA" wala click hata kar naya link lagao
h = h.replace(/onclick="showToast\('About IBA'\)"/g, 'onclick="location.href=\'about.html\'"');

// Agar upar wala na mile, toh purana text dhundh kar replace karo
if (h.includes('showToast(\'About IBA\')')) {
    h = h.replace(/showToast\('About IBA'\)/g, "location.href='about.html'");
}

fs.writeFileSync('settings.html', h);
console.log('✅ Settings me About IBA ka link theek ho gaya!');
