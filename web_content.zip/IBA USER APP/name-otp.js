const fs = require('fs');
let h = fs.readFileSync('edit-profile.html', 'utf8');

// 1. Name field ko readonly karo aur uske aage CHANGE button lagao
const oldNameHTML = `<div class="form-group">
        <label class="form-label">DISPLAY NAME</label>
        <div class="input-wrapper">
            <div class="input-icon">👤</div>
            <input type="text" class="form-input" id="nameInput" placeholder="Enter your name" maxlength="30">
        </div>
    </div>`;

const newNameHTML = `<div class="form-group">
        <label class="form-label">DISPLAY NAME</label>
        <div class="input-wrapper" style="position:relative;">
            <div class="input-icon">👤</div>
            <input type="text" class="form-input" id="nameInput" placeholder="Enter your name" readonly style="padding-right:80px;">
            <button type="button" onclick="openNameChange()" style="position:absolute; right:8px; top:50%; transform:translateY(-50%); background:rgba(255,195,25,0.15); color:#ffc419; border:1px solid rgba(255,195,25,0.3); padding:6px 12px; border-radius:8px; font-size:11px; font-weight:800; cursor:pointer;">CHANGE</button>
        </div>
    </div>`;

h = h.replace(oldNameHTML, newNameHTML);

// 2. Name Change Modal add karo
const nameModalHTML = `
<!-- NAME CHANGE MODAL -->
<div class="name-modal" id="nameModal">
    <div class="name-box">
        <div class="nm-header">
            <h3>Change <span>Name</span></h3>
            <button onclick="closeNameModal()">✕</button>
        </div>
        <p class="nm-desc">Enter your new name. We'll send an OTP to your Gmail for verification.</p>

        <input type="text" class="nm-input" id="newNameInput" placeholder="Enter new name" maxlength="30">
        
        <button class="nm-btn" onclick="sendNameOtp()" id="sendNameBtn">Send OTP to Gmail</button>
        
        <div id="nameOtpBox" style="display:none; margin-top:12px;">
            <input type="number" class="nm-input" id="nameOtpInput" placeholder="Enter OTP" maxlength="6">
            <button class="nm-btn green" onclick="verifyNameOtp()">Verify & Update Name</button>
        </div>
        
        <div class="nm-msg" id="nmMsg"></div>
    </div>
</div>

<style>
/* NAME MODAL STYLES */
.name-modal{position:fixed;inset:0;background:rgba(0,0,0,0.85);backdrop-filter:blur(10px);z-index:9999;display:none;align-items:center;justify-content:center;padding:20px}
.name-modal.show{display:flex}
.name-box{background:#0a1535;border:1px solid rgba(255,195,25,0.3);border-radius:24px;padding:24px;width:100%;max-width:380px;box-shadow:0 20px 50px rgba(0,0,0,0.8)}
.nm-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px}
.nm-header h3{font-size:20px;font-weight:900;color:#fff}
.nm-header h3 span{color:#ffc419}
.nm-header button{background:none;border:none;color:#6b8bb8;font-size:20px;cursor:pointer}
.nm-desc{font-size:12px;color:#8a9bb8;margin-bottom:20px;line-height:1.5}
.nm-input{width:100%;padding:14px;background:rgba(0,0,0,0.3);border:1px solid rgba(255,255,255,0.1);border-radius:12px;color:#fff;font-size:14px;margin-bottom:10px;outline:none;font-family:monospace}
.nm-input:focus{border-color:#ffc419}
.nm-btn{width:100%;padding:14px;background:linear-gradient(135deg,#ffc419,#ff9800);color:#000;border:none;border-radius:12px;font-size:14px;font-weight:800;cursor:pointer}
.nm-btn:active{transform:scale(0.98)}
.nm-btn.green{background:linear-gradient(135deg,#00b359,#00e676);color:#fff}
.nm-msg{text-align:center;font-size:12px;margin-top:12px;font-weight:600;min-height:16px}
.nm-msg.error{color:#ff3b3b}
.nm-msg.success{color:#00e676}
</style>
`;
h = h.replace('</body>', nameModalHTML + '\n</body>');

// 3. JS Logic
const nameJS = `
// NAME CHANGE LOGIC
let pendingName = '';

function openNameChange() {
    document.getElementById('newNameInput').value = document.getElementById('nameInput').value;
    document.getElementById('nameModal').classList.add('show');
    document.getElementById('nameOtpBox').style.display = 'none';
    document.getElementById('sendNameBtn').style.display = 'block';
    document.getElementById('sendNameBtn').innerText = 'Send OTP to Gmail';
    document.getElementById('nmMsg').innerText = '';
}

function closeNameModal() {
    document.getElementById('nameModal').classList.remove('show');
}

function nmMsg(text, type) {
    const m = document.getElementById('nmMsg');
    m.innerText = text;
    m.className = 'nm-msg ' + type;
}

async function sendNameOtp() {
    pendingName = document.getElementById('newNameInput').value.trim();
    if(pendingName.length < 2) return nmMsg('Name must be 2+ characters', 'error');

    document.getElementById('sendNameBtn').innerText = 'Sending...';
    try {
        const res = await fetch(SERVER + '/api/user/send-name-otp', {
            method: 'POST', headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ userId })
        });
        const data = await res.json();
        if(data.success) {
            nmMsg('OTP sent to your Gmail! Check Termux.', 'success');
            document.getElementById('nameOtpBox').style.display = 'block';
            document.getElementById('sendNameBtn').style.display = 'none';
        } else {
            nmMsg(data.error || 'Failed', 'error');
            document.getElementById('sendNameBtn').innerText = 'Send OTP to Gmail';
        }
    } catch(e) {
        nmMsg('Server error', 'error');
        document.getElementById('sendNameBtn').innerText = 'Send OTP to Gmail';
    }
}

async function verifyNameOtp() {
    const otp = document.getElementById('nameOtpInput').value;
    if(otp.length < 4) return nmMsg('Enter valid OTP', 'error');
    
    try {
        const res = await fetch(SERVER + '/api/user/verify-name-otp', {
            method: 'POST', headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ userId, otp, newName: pendingName })
        });
        const data = await res.json();
        if(data.success) {
            nmMsg('Name updated successfully!', 'success');
            document.getElementById('nameInput').value = pendingName;
            localStorage.setItem('iba_name', pendingName);
            setTimeout(closeNameModal, 1500);
        } else {
            nmMsg(data.error || 'Invalid OTP', 'error');
        }
    } catch(e) {
        nmMsg('Server error', 'error');
    }
}
`;
h = h.replace('</script>', nameJS + '\n</script>');

fs.writeFileSync('edit-profile.html', h);
console.log('✅ Name Change with OTP Ready!');
