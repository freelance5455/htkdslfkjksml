const fs = require('fs');
let h = fs.readFileSync('dashboard.html', 'utf8');

// Logout item hatao (More page se)
const logoutHTML = `<div class="more-item logout-item" onclick="confirmLogout()">
            <div class="more-icon">🚪</div>
            <div class="more-text"><div class="more-label">Logout</div><div class="more-desc">Sign out from your account</div></div>
            <div class="more-arrow">›</div>
        </div>`;

if (h.includes(logoutHTML)) {
    h = h.replace(logoutHTML, '');
    console.log('✅ Logout removed from More page');
} else {
    // Regex fallback
    const regex = /<div class="more-item logout-item"[^>]*>[\s\S]*?<\/div>\s*<\/div>/;
    if (regex.test(h)) {
        h = h.replace(regex, '');
        console.log('✅ Logout removed via regex');
    } else {
        console.log('❌ Logout item not found');
    }
}

fs.writeFileSync('dashboard.html', h);
console.log('✅ Done!');
