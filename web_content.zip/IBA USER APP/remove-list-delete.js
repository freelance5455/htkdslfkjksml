const fs = require('fs');
let h = fs.readFileSync('add-friend.html', 'utf8');

// Friend list wale item me se Delete (🗑️) button hatao
const deleteBtnHTML = ` +
                        '<button class="fi-del-btn" onclick="openDeletePopup(\\'' + f.userId + '\\', \\'' + f.name + '\\')">🗑️</button>'`;

if (h.includes(deleteBtnHTML)) {
    h = h.replace(deleteBtnHTML, '');
    console.log('✅ Delete button removed from friend list!');
} else {
    // Agar exact match na mile toh regex se try karo
    const regex = /<button class="fi-del-btn"[^>]*>🗑️<\/button>/;
    if (regex.test(h)) {
        h = h.replace(regex, '');
        console.log('✅ Delete button removed via regex!');
    } else {
        console.log('❌ Delete button not found.');
    }
}

fs.writeFileSync('add-friend.html', h);
