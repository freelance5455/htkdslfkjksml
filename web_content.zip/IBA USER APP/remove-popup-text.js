const fs = require('fs');
let h = fs.readFileSync('messages.html', 'utf8');

// 1. HTML me se lamba message wala <p> tag hatao
const longTextHTML = `<p>Are you sure you want to remove <b id="deleteFriendName">this friend</b> from your list? You can always add them back later.</p>`;
h = h.replace(longTextHTML, '');

// 2. CSS me se bhi <p> ka style hatao (taaki koi extra space na bache)
h = h.replace(/\.delete-popup-box p \{[^}]*\}/g, '');
h = h.replace(/\.delete-popup-box p b \{[^}]*\}/g, '');

fs.writeFileSync('messages.html', h);
console.log('✅ Extra message removed from popup!');
