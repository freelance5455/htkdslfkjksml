const fs = require('fs');
let h = fs.readFileSync('about.html', 'utf8');

// Purana openLink function hatao
const oldFnRegex = /function openLink\(type\) \{[\s\S]*?\n\}/;

// Naya function jo force karega ki link browser me khule
const newFn = `function openLink(type) {
    var url = socialLinks[type] || '';
    
    if (!url) {
        alert('Link not set by Admin yet.');
        return;
    }

    // Agar Instagram ka link hai
    if (type === 'instagram') {
        // Ek temporary anchor tag banakar click karo (isse browser samajh jata hai ki URL hai)
        var a = document.createElement('a');
        a.href = url;
        a.target = '_blank';
        a.rel = 'noopener noreferrer';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    } else {
        // Baaki links ke liye normal open
        window.open(url, '_blank');
    }
}`;

h = h.replace(oldFnRegex, newFn);
fs.writeFileSync('about.html', h);
console.log('✅ Instagram link opening fixed using <a> tag!');
