const fs = require('fs');
let h = fs.readFileSync('dashboard.html', 'utf8');

// Purana navClick function dhoondo aur replace karo
const oldNavFn = `function navClick(el, page){
    document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
    el.classList.add('active');
    if(page === 'Home') return;
    if(page === 'Wallet'){ comingSoon('Wallet'); }
    else { comingSoon(page); }
}`;

const newNavFn = `function navClick(el, page){
    document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
    el.classList.add('active');
    if(page === 'Home') return;
    if(page === 'More'){ openMore(); return; }
    if(page === 'Wallet'){ comingSoon('Wallet'); }
    else { comingSoon(page); }
}`;

if (h.includes(oldNavFn)) {
    h = h.replace(oldNavFn, newNavFn);
    console.log('✅ navClick fixed');
} else {
    // Regex fallback
    const regex = /function navClick\(el, page\)\{[\s\S]*?\n\}/;
    const match = h.match(regex);
    if (match) {
        h = h.replace(match[0], newNavFn);
        console.log('✅ navClick fixed via regex');
    } else {
        console.log('❌ navClick function not found');
    }
}

// More button se duplicate openMore hatao (agar lag gaya ho)
h = h.replace(
    `onclick="navClick(this,'More');openMore()"`,
    `onclick="navClick(this,'More')"`
);

fs.writeFileSync('dashboard.html', h);
console.log('✅ Dashboard updated');
