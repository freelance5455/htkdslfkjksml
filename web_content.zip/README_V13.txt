V13 fixes dashboard total hours display. Durations are calculated in minutes and displayed as hours/minutes. Example 3:15 + 3:30 + 2:15 = 9 hours. No SQL changes required.
