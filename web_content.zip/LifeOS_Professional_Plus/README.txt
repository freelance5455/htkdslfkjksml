LifeOS Professional Plus — fresh standalone build

FILES
- index.html: complete offline-first LifeOS web app.

WHAT'S INCLUDED
- Custom player profile, HP, XP, editable ranks and rank icons.
- Task/quest planner, must-do tasks, events, flowchart and local planning advice.
- Subject/book/skill revision tracking; problem journal; obligations; to-do and shopping lists.
- Activity logging, progress charts based on saved records, 28-day activity map and consistency streak.
- Focus timer (15/25/45/60 minutes) with optional activity logging when complete.
- Targets, achievements, notes/search, contacts, constitution/rules, YouTube study search and explicit share action.
- Local browser storage, JSON backup export/import, and reset controls.
- Mobile layout, reduced-motion accessibility and no external JavaScript/CDN dependencies.

ANDROID PACKAGING
1. Extract this ZIP on your phone if your packaging app needs a folder, or upload the ZIP if it accepts website ZIPs.
2. Make sure index.html is the site entry point/root file.
3. Build a preview first, then test navigation, add/edit/delete, focus timer, chart, backup export/import, and reopen persistence on your actual device.
4. If the wrapper asks for a start URL, use the packaged local index.html entry rather than an unrelated external URL.

IMPORTANT LIMITATIONS
- This is a web app packaged by a third-party Android wrapper, not a native Android project.
- Records are stored in the wrapper's browser/WebView storage on that device. Clearing app data or uninstalling may erase them; export backups regularly.
- The focus timer is foreground-only and does not promise background timing after the app is closed.
- Social sharing and YouTube search require compatible installed apps/network access.
- JavaScript syntax and ZIP integrity were checked, but full device/AppOfWeb interaction testing has not been performed here. Test the generated APK before relying on it.
