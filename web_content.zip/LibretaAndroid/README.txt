LIBRETA — PROYECTO ANDROID

Este es el proyecto fuente de la app Android Libreta. Incluye la libreta original dentro de la aplicación, en una WebView local, y conserva almacenamiento web local del dispositivo.

IMPORTANTE: Este ZIP es el proyecto para generar el APK; no es todavía un archivo APK instalable.

Cómo generar el APK en un computador:
1. Instala Android Studio desde el sitio oficial de Android Developers.
2. Descomprime este ZIP.
3. En Android Studio, elige Open y selecciona la carpeta LibretaAndroid.
4. Espera a que Gradle termine de sincronizar.
5. Selecciona Build > Build APK(s).
6. Android Studio mostrará el enlace para localizar el APK generado (normalmente app/build/outputs/apk/debug/app-debug.apk).
7. Pasa app-debug.apk al teléfono Android y ábrelo para instalar. Puede pedir permiso para instalar apps desde esa fuente.

Requisitos habituales: Android Studio actualizado y conexión a Internet durante la primera sincronización. El proyecto usa Android Gradle Plugin 8.7.3, Kotlin 2.0.21 y compileSdk 35.

Notas:
- Las notas/dibujos se guardan en almacenamiento local de la app; borrar datos o desinstalar puede borrarlos. Haz exportaciones/copias de seguridad.
- Las funciones que dependen de servicios externos o del entorno de Claude podrían no funcionar dentro de esta app independiente.
- Este proyecto no incluye firma de publicación; el APK debug sirve para probar.
