using UnrealBuildTool;
public class ZonaZeroEditorTarget : TargetRules
{
    public ZonaZeroEditorTarget(TargetInfo Target) : base(Target)
    {
        Type = TargetType.Editor;
        DefaultBuildSettings = BuildSettingsVersion.Latest;
        IncludeOrderVersion = EngineIncludeOrderVersion.Latest;
        ExtraModuleNames.Add("ZonaZero");
    }
}
