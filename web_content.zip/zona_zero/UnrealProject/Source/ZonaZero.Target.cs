using UnrealBuildTool;
public class ZonaZeroTarget : TargetRules
{
    public ZonaZeroTarget(TargetInfo Target) : base(Target)
    {
        Type = TargetType.Game;
        DefaultBuildSettings = BuildSettingsVersion.Latest;
        IncludeOrderVersion = EngineIncludeOrderVersion.Latest;
        ExtraModuleNames.Add("ZonaZero");
    }
}
