using UnrealBuildTool;
// Servidor dedicado (requer Unreal compilada do código-fonte / GitHub)
public class ZonaZeroServerTarget : TargetRules
{
    public ZonaZeroServerTarget(TargetInfo Target) : base(Target)
    {
        Type = TargetType.Server;
        DefaultBuildSettings = BuildSettingsVersion.Latest;
        IncludeOrderVersion = EngineIncludeOrderVersion.Latest;
        ExtraModuleNames.Add("ZonaZero");
    }
}
