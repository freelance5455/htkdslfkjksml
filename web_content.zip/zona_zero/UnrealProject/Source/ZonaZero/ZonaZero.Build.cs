using UnrealBuildTool;
public class ZonaZero : ModuleRules
{
    public ZonaZero(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
        PublicDependencyModuleNames.AddRange(new string[] {
            "Core", "CoreUObject", "Engine", "InputCore", "EnhancedInput",
            "NetCore", "AIModule", "GameplayTasks", "NavigationSystem",
            "ChaosVehicles", "UMG", "Slate", "SlateCore"
        });
    }
}
