#include "Player/ZZCharacter.h"
#include "Player/ZZCharacterMovement.h"
#include "Combat/ZZLagCompensationComponent.h"
#include "GameFramework/GameStateBase.h"
#include "Net/UnrealNetwork.h"
#include "Kismet/GameplayStatics.h"
#include "Components/CapsuleComponent.h"

AZZCharacter::AZZCharacter(const FObjectInitializer& Init)
    : Super(Init.SetDefaultSubobjectClass<UZZCharacterMovement>(ACharacter::CharacterMovementComponentName))
{
    PrimaryActorTick.bCanEverTick = true;
    LagComp = CreateDefaultSubobject<UZZLagCompensationComponent>(TEXT("LagComp"));
    // Orçamento de rede: 30 Hz perto, cai para 5 Hz; relevância 250 m
    SetNetUpdateFrequency(30.f);
    SetMinNetUpdateFrequency(5.f);
    SetNetCullDistanceSquared(FMath::Square(25000.f));
    bReplicates = true;
}

void AZZCharacter::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& Out) const
{
    Super::GetLifetimeReplicatedProps(Out);
    DOREPLIFETIME(AZZCharacter, Health);
    DOREPLIFETIME_CONDITION(AZZCharacter, Shield, COND_OwnerOnly);   // escudo: só o dono precisa
    DOREPLIFETIME(AZZCharacter, Phase);
    DOREPLIFETIME_CONDITION(AZZCharacter, ActiveEmoteId, COND_SkipOwner);
}

void AZZCharacter::StartSprint() { if (auto* M = Cast<UZZCharacterMovement>(GetCharacterMovement())) M->SetWantsToSprint(true); }
void AZZCharacter::StopSprint()  { if (auto* M = Cast<UZZCharacterMovement>(GetCharacterMovement())) M->SetWantsToSprint(false); }

void AZZCharacter::Tick(float Dt)
{
    Super::Tick(Dt);
    if (Phase == EZZPlayerPhase::Freefall || Phase == EZZPlayerPhase::Gliding) TickAirborne(Dt);
    else if (Phase == EZZPlayerPhase::Ground && IsLocallyControlled()) TryAutoVault();
}

void AZZCharacter::TickAirborne(float Dt)
{
    // Roda em cliente (predição, via CMC Flying) e servidor; Server valida limites.
    auto* M = GetCharacterMovement();
    M->SetMovementMode(MOVE_Flying);
    const bool bGlide = Phase == EZZPlayerPhase::Gliding;
    const float Pitch = FMath::Clamp(GetControlRotation().Pitch > 180 ? GetControlRotation().Pitch - 360 : GetControlRotation().Pitch, -60.f, 20.f);
    const float Dive = FMath::GetMappedRangeValueClamped(FVector2D(20, -60), FVector2D(0, 1), Pitch); // 0 planeio, 1 mergulho
    const float V = bGlide ? GlideVertical : FMath::Lerp(GlideVertical, DiveVertical, Dive);
    const float H = bGlide ? GlideHorizontal : FMath::Lerp(GlideHorizontal, DiveHorizontal, Dive);
    FVector Fwd = FRotationMatrix(FRotator(0, GetControlRotation().Yaw, 0)).GetUnitAxis(EAxis::X);
    M->Velocity = Fwd * H + FVector(0, 0, V);
    if (HasAuthority())
    {
        const FVector Start = GetActorLocation();
        FHitResult Hit;
        GetWorld()->LineTraceSingleByChannel(Hit, Start, Start - FVector(0, 0, AutoOpenHeight), ECC_Visibility);
        if (Phase == EZZPlayerPhase::Freefall && Hit.bBlockingHit) Phase = EZZPlayerPhase::Gliding;   // abre automático a ~100 m
        if (Phase == EZZPlayerPhase::Gliding && M->IsMovingOnGround()) { Phase = EZZPlayerPhase::Ground; }
        if (Hit.bBlockingHit && Hit.Distance < 120.f) { Phase = EZZPlayerPhase::Ground; M->SetMovementMode(MOVE_Walking); }
    }
}

void AZZCharacter::Server_Jump_Implementation() { if (Phase == EZZPlayerPhase::InPlane) { Phase = EZZPlayerPhase::Freefall; SetActorHiddenInGame(false); } }
void AZZCharacter::Server_OpenParachute_Implementation() { if (Phase == EZZPlayerPhase::Freefall) Phase = EZZPlayerPhase::Gliding; }

void AZZCharacter::TryAutoVault()
{
    auto* M = Cast<UZZCharacterMovement>(GetCharacterMovement());
    if (!M || !M->IsMovingOnGround() || M->Velocity.SizeSquared2D() < 10000.f) return;
    const FVector Fwd = GetActorForwardVector(), Base = GetActorLocation() - FVector(0, 0, GetCapsuleComponent()->GetScaledCapsuleHalfHeight());
    FHitResult Low, High; FCollisionQueryParams Q(SCENE_QUERY_STAT(ZZVault), false, this);
    const bool bLow = GetWorld()->LineTraceSingleByChannel(Low, Base + FVector(0, 0, 40), Base + FVector(0, 0, 40) + Fwd * 70, ECC_Visibility, Q);
    const bool bHigh = GetWorld()->LineTraceSingleByChannel(High, Base + FVector(0, 0, M->VaultMaxHeight), Base + FVector(0, 0, M->VaultMaxHeight) + Fwd * 70, ECC_Visibility, Q);
    if (bLow && !bHigh) LaunchCharacter(FVector(0, 0, 520.f) + Fwd * 250.f, false, false);   // vault simples; trocar por Motion Warping + montage
}

void AZZCharacter::RequestFire(FVector Origin, FVector Dir)
{
    // Efeito local imediato (VFX/som) é feito em Blueprint; aqui só o envio.
    const double ViewTime = GetWorld()->GetGameState()->GetServerWorldTimeSeconds() - 0.1;   // delay de interpolação
    Server_Fire(Origin, Dir, ViewTime);
}
bool AZZCharacter::Server_Fire_Validate(FVector_NetQuantize O, FVector_NetQuantizeNormal D, double T)
{
    return FVector::Dist(O, GetPawnViewLocation()) < 300.f;   // origem próxima da câmera (anti-cheat básico)
}
void AZZCharacter::Server_Fire_Implementation(FVector_NetQuantize O, FVector_NetQuantizeNormal D, double ClientViewTime)
{
    const double Now = GetWorld()->GetTimeSeconds();
    if (Phase != EZZPlayerPhase::Ground || Now - LastFireTime < FireInterval * 0.9) return;   // cadência
    LastFireTime = Now;
    // ClientViewTime vem em "server world time"; converte para GetTimeSeconds do servidor (mesmo relógio no servidor)
    FVector HitPt;
    if (AActor* Hit = UZZLagCompensationComponent::RewindedSegmentTest(GetWorld(), this, O, O + D * WeaponRange, ClientViewTime, HitPt))
        UGameplayStatics::ApplyPointDamage(Hit, WeaponDamage, D, FHitResult(), GetController(), this, nullptr);
}

float AZZCharacter::TakeDamage(float Dmg, const FDamageEvent& E, AController* I, AActor* C)
{
    if (!HasAuthority() || Phase == EZZPlayerPhase::Dead) return 0.f;
    float Remaining = Dmg;
    const float Absorbed = FMath::Min(Shield, Remaining); Shield -= Absorbed; Remaining -= Absorbed;
    Health = FMath::Max(0.f, Health - Remaining);
    if (Health <= 0.f) Die(I);
    return Dmg;
}
void AZZCharacter::Die(AController* Killer)
{
    Phase = EZZPlayerPhase::Dead;
    GetCharacterMovement()->DisableMovement();
    GetMesh()->SetCollisionProfileName(TEXT("Ragdoll")); GetMesh()->SetSimulatePhysics(true);
    // TODO: notificar GameMode (OnPlayerKilled) para ranking/colocação
}
void AZZCharacter::OnRep_Health() {}   // gancho para HUD / feedback de dano

void AZZCharacter::RequestEmote(uint16 Id) { Server_Emote(Id); }
void AZZCharacter::Server_Emote_Implementation(uint16 Id) { ActiveEmoteId = Id; }   // anim roda local em cada cliente
