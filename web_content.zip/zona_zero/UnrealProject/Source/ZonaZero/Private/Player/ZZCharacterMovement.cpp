#include "Player/ZZCharacterMovement.h"
#include "GameFramework/Character.h"

UZZCharacterMovement::UZZCharacterMovement()
{
    MaxWalkSpeed = 600.f;
    MaxWalkSpeedCrouched = 280.f;
    BrakingDecelerationWalking = 2400.f;   // frenagem curta (sensação responsiva)
    MaxAcceleration = 2600.f;
    GroundFriction = 8.f;
    NavAgentProps.bCanCrouch = true;
    // Correção de rede suave para mobile (evita "teleportes" visuais)
    NetworkSmoothingMode = ENetworkSmoothingMode::Exponential;
    NetworkMaxSmoothUpdateDistance = 200.f;
    NetworkNoSmoothUpdateDistance = 200.f;
}

float UZZCharacterMovement::GetMaxSpeed() const
{
    float Base = Super::GetMaxSpeed();
    return (IsMovingOnGround() && !IsCrouching() && bWantsToSprint) ? Base * SprintSpeedMultiplier : Base;
}

void UZZCharacterMovement::UpdateFromCompressedFlags(uint8 Flags)
{
    Super::UpdateFromCompressedFlags(Flags);
    bWantsToSprint = (Flags & FSavedMove_Character::FLAG_Custom_0) != 0;
}

FNetworkPredictionData_Client* UZZCharacterMovement::GetPredictionData_Client() const
{
    if (!ClientPredictionData)
    {
        UZZCharacterMovement* Mutable = const_cast<UZZCharacterMovement*>(this);
        Mutable->ClientPredictionData = new FNetworkPredictionData_Client_ZZ(*this);
    }
    return ClientPredictionData;
}

void UZZCharacterMovement::FSavedMove_ZZ::Clear() { Super::Clear(); bSavedWantsToSprint = false; }
uint8 UZZCharacterMovement::FSavedMove_ZZ::GetCompressedFlags() const
{
    uint8 R = Super::GetCompressedFlags();
    if (bSavedWantsToSprint) R |= FLAG_Custom_0;
    return R;
}
bool UZZCharacterMovement::FSavedMove_ZZ::CanCombineWith(const FSavedMovePtr& New, ACharacter* C, float MaxDelta) const
{
    if (bSavedWantsToSprint != static_cast<FSavedMove_ZZ*>(New.Get())->bSavedWantsToSprint) return false;
    return Super::CanCombineWith(New, C, MaxDelta);
}
void UZZCharacterMovement::FSavedMove_ZZ::SetMoveFor(ACharacter* C, float Dt, FVector const& Accel, FNetworkPredictionData_Client_Character& CD)
{
    Super::SetMoveFor(C, Dt, Accel, CD);
    if (auto* M = Cast<UZZCharacterMovement>(C->GetCharacterMovement())) bSavedWantsToSprint = M->bWantsToSprint;
}
void UZZCharacterMovement::FSavedMove_ZZ::PrepMoveFor(ACharacter* C)
{
    Super::PrepMoveFor(C);
    if (auto* M = Cast<UZZCharacterMovement>(C->GetCharacterMovement())) M->bWantsToSprint = bSavedWantsToSprint;
}
