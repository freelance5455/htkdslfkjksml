#include "Combat/ZZLagCompensationComponent.h"
#include "GameFramework/Character.h"
#include "Components/CapsuleComponent.h"
#include "EngineUtils.h"
#include "Engine/World.h"

UZZLagCompensationComponent::UZZLagCompensationComponent()
{
    PrimaryComponentTick.bCanEverTick = true;
    SetIsReplicatedByDefault(false);
}

void UZZLagCompensationComponent::TickComponent(float Dt, ELevelTick Type, FActorComponentTickFunction* F)
{
    Super::TickComponent(Dt, Type, F);
    if (!GetOwner() || !GetOwner()->HasAuthority()) return;
    const double Now = GetWorld()->GetTimeSeconds();
    History.Add({Now, GetOwner()->GetActorLocation()});
    while (History.Num() > 2 && Now - History[0].Time > HistorySeconds) History.RemoveAt(0, 1, EAllowShrinking::No);
}

bool UZZLagCompensationComponent::GetLocationAt(double T, FVector& Out) const
{
    if (History.Num() == 0) return false;
    if (T <= History[0].Time) { Out = History[0].Location; return true; }
    for (int32 i = History.Num() - 1; i > 0; --i)
    {
        if (History[i - 1].Time <= T)
        {
            const double Span = History[i].Time - History[i - 1].Time;
            const float A = Span > KINDA_SMALL_NUMBER ? (T - History[i - 1].Time) / Span : 1.f;
            Out = FMath::Lerp(History[i - 1].Location, History[i].Location, FMath::Clamp(A, 0.f, 1.f));
            return true;
        }
    }
    Out = History.Last().Location; return true;
}

AActor* UZZLagCompensationComponent::RewindedSegmentTest(UWorld* World, AActor* Shooter, const FVector& Start, const FVector& End,
                                                         double ClientViewTime, FVector& OutHit)
{
    const double Now = World->GetTimeSeconds();
    AActor* Best = nullptr; float BestDist = TNumericLimits<float>::Max();
    for (TActorIterator<ACharacter> It(World); It; ++It)
    {
        ACharacter* C = *It;
        if (C == Shooter) continue;
        auto* Comp = C->FindComponentByClass<UZZLagCompensationComponent>();
        if (!Comp) continue;
        const double T = FMath::Clamp(ClientViewTime, Now - Comp->MaxRewindSeconds, Now);
        FVector Loc;
        if (!Comp->GetLocationAt(T, Loc)) continue;
        const UCapsuleComponent* Cap = C->GetCapsuleComponent();
        const float HH = Cap->GetScaledCapsuleHalfHeight() - Cap->GetScaledCapsuleRadius();
        const FVector A = Loc - FVector(0, 0, HH), B = Loc + FVector(0, 0, HH);
        FVector P1, P2;
        FMath::SegmentDistToSegment(Start, End, A, B, P1, P2);
        if (FVector::Dist(P1, P2) <= Cap->GetScaledCapsuleRadius())
        {
            const float D = FVector::Dist(Start, P1);
            if (D < BestDist) { BestDist = D; Best = C; OutHit = P1; }
        }
    }
    if (Best) // há parede no caminho?
    {
        FHitResult Wall; FCollisionQueryParams Q(SCENE_QUERY_STAT(ZZLOS), false, Shooter);
        if (World->LineTraceSingleByChannel(Wall, Start, OutHit, ECC_Visibility, Q) && Wall.GetActor() != Best) return nullptr;
    }
    return Best;
}
