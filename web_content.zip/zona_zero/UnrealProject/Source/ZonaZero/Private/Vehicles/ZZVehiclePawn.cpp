#include "Vehicles/ZZVehiclePawn.h"
#include "ChaosVehicleMovementComponent.h"
#include "Net/UnrealNetwork.h"
#include "Kismet/GameplayStatics.h"

AZZVehiclePawn::AZZVehiclePawn()
{
    PrimaryActorTick.bCanEverTick = true;
    bReplicates = true; SetReplicatingMovement(true);
    SetNetUpdateFrequency(30.f); SetMinNetUpdateFrequency(10.f);
}
void AZZVehiclePawn::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& O) const
{
    Super::GetLifetimeReplicatedProps(O);
    DOREPLIFETIME(AZZVehiclePawn, Health); DOREPLIFETIME(AZZVehiclePawn, Fuel);
}
void AZZVehiclePawn::Tick(float Dt)
{
    Super::Tick(Dt);
    if (!HasAuthority()) return;
    if (auto* VM = GetVehicleMovementComponent())
    {
        Fuel = FMath::Max(0.f, Fuel - FMath::Abs(VM->GetThrottleInput()) * FuelPerSecondAtFullThrottle * Dt);
        if (Fuel <= 0.f) VM->SetThrottleInput(0.f);
    }
}
float AZZVehiclePawn::TakeDamage(float Dmg, const FDamageEvent& E, AController* I, AActor* C)
{
    if (!HasAuthority() || Health <= 0.f) return 0.f;
    Health = FMath::Max(0.f, Health - Dmg);
    if (Health <= 0.f) Explode();
    return Dmg;
}
void AZZVehiclePawn::NotifyHit(UPrimitiveComponent* M, AActor* Other, UPrimitiveComponent* OC, bool bSM, FVector HL, FVector HN, FVector Impulse, const FHitResult& Hit)
{
    Super::NotifyHit(M, Other, OC, bSM, HL, HN, Impulse, Hit);
    if (HasAuthority()) { const float Dmg = FMath::Max(0.f, Impulse.Size() / 1000.f - 800.f) * 0.05f; if (Dmg > 0) TakeDamage(Dmg, FDamageEvent(), nullptr, Other); }
}
void AZZVehiclePawn::Explode()
{
    UGameplayStatics::ApplyRadialDamage(this, 120.f, GetActorLocation(), 600.f, nullptr, {this}, this, nullptr, true);
    // TODO: trocar para malha destruída + VFX (Niagara) via Multicast
}
void AZZVehiclePawn::OnRep_Health() {}
