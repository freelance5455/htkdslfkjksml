#include "AI/ZZBotController.h"
#include "BehaviorTree/BehaviorTree.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "Perception/AIPerceptionComponent.h"
#include "Perception/AISenseConfig_Sight.h"
#include "Perception/AISenseConfig_Hearing.h"

AZZBotController::AZZBotController()
{
    Perception = CreateDefaultSubobject<UAIPerceptionComponent>(TEXT("Perception"));
    auto* Sight = CreateDefaultSubobject<UAISenseConfig_Sight>(TEXT("Sight"));
    Sight->SightRadius = 8000.f; Sight->LoseSightRadius = 9000.f; Sight->PeripheralVisionAngleDegrees = 55.f;   // cone ~110°
    Sight->SetMaxAge(8.f);                                                                                      // memória de ~8 s
    Sight->DetectionByAffiliation.bDetectEnemies = Sight->DetectionByAffiliation.bDetectNeutrals = Sight->DetectionByAffiliation.bDetectFriendlies = true;
    auto* Hear = CreateDefaultSubobject<UAISenseConfig_Hearing>(TEXT("Hearing"));
    Hear->HearingRange = 4000.f; Hear->DetectionByAffiliation.bDetectEnemies = Hear->DetectionByAffiliation.bDetectNeutrals = true;
    Perception->ConfigureSense(*Sight); Perception->ConfigureSense(*Hear);
    Perception->SetDominantSense(Sight->GetSenseImplementation());
}
void AZZBotController::OnPossess(APawn* P)
{
    Super::OnPossess(P);
    Perception->OnPerceptionUpdated.AddDynamic(this, &AZZBotController::OnPerceptionUpdated);
    if (BehaviorTreeAsset) RunBehaviorTree(BehaviorTreeAsset);
}
void AZZBotController::OnPerceptionUpdated(const TArray<AActor*>& Actors)
{
    if (UBlackboardComponent* BB = GetBlackboardComponent())
        for (AActor* A : Actors)
            if (Cast<APawn>(A) && A != GetPawn()) { BB->SetValueAsObject(TEXT("TargetActor"), A); BB->SetValueAsVector(TEXT("LastKnownPos"), A->GetActorLocation()); break; }
}
void AZZBotController::AdaptDifficulty(float Human, float Rank) { SkillLevel = FMath::Clamp(Human + Rank, 0.f, 10.f); }
