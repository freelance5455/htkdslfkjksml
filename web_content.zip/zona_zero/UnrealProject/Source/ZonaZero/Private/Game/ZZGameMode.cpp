#include "Game/ZZGameMode.h"
#include "Game/ZZGameState.h"
#include "Player/ZZCharacter.h"
#include "AI/ZZBotController.h"
#include "EngineUtils.h"
#include "TimerManager.h"

AZZGameMode::AZZGameMode()
{
    bDelayedStart = true;
    GameStateClass = AZZGameState::StaticClass();
    DefaultPawnClass = AZZCharacter::StaticClass();
    BotControllerClass = AZZBotController::StaticClass();
    BotCharacterClass = AZZCharacter::StaticClass();
    PrimaryActorTick.bCanEverTick = true;
}
void AZZGameMode::BeginPlay() { Super::BeginPlay(); }
void AZZGameMode::Tick(float Dt) { Super::Tick(Dt); }

bool AZZGameMode::ReadyToStartMatch_Implementation()
{
    // Inicia quando lotar ou após o tempo de espera do lobby; bots completam as vagas.
    return GetMatchState() == MatchState::WaitingToStart && (GetNumPlayers() >= MaxParticipants || GetWorld()->GetTimeSeconds() > LobbyWaitSeconds);
}
void AZZGameMode::HandleMatchHasStarted()
{
    Super::HandleMatchHasStarted();
    FillWithBots();
    LaunchPlane();
    if (AZZGameState* GS = GetGameState<AZZGameState>()) GS->ServerBeginZone(FMath::Rand());
    GetWorldTimerManager().SetTimer(ZoneTimer, FTimerDelegate::CreateLambda([this]{ if (auto* G = GetGameState<AZZGameState>()) G->ServerTickZone(); }), 0.5f, true);
    GetWorldTimerManager().SetTimer(VictoryTimer, this, &AZZGameMode::CheckVictory, 1.f, true);
}
void AZZGameMode::FillWithBots()
{
    const int32 Missing = MaxParticipants - GetNumPlayers();
    for (int32 i = 0; i < Missing; ++i)
    {
        FActorSpawnParameters P; P.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
        AZZCharacter* Pawn = GetWorld()->SpawnActor<AZZCharacter>(BotCharacterClass, FTransform(FVector(FMath::FRandRange(-90000, 90000), FMath::FRandRange(-90000, 90000), 30000)), P);
        AController* C = GetWorld()->SpawnActor<AController>(BotControllerClass);
        if (Pawn && C) C->Possess(Pawn);
    }
}
void AZZGameMode::LaunchPlane()
{
    // Rota: dois pontos nas bordas, sorteados pelo servidor. O avião é 1 ator replicado; jogadores a bordo ficam "attached" e ocultos.
    // Em Blueprint: spawnar BP_Plane com Start/End e chamar Server_Jump nos pawns ao apertar SALTAR (ou no fim da rota).
}
void AZZGameMode::CheckVictory()
{
    int32 Alive = 0; AZZCharacter* Last = nullptr;
    for (TActorIterator<AZZCharacter> It(GetWorld()); It; ++It) if (It->Phase != EZZPlayerPhase::Dead) { ++Alive; Last = *It; }
    if (Alive <= 1) { GetWorldTimerManager().ClearTimer(VictoryTimer); EndMatch(); }
}
