#include "Game/ZZGameState.h"
#include "Player/ZZCharacter.h"
#include "Net/UnrealNetwork.h"
#include "EngineUtils.h"
#include "Kismet/GameplayStatics.h"

AZZGameState::AZZGameState()
{
    PrimaryActorTick.bCanEverTick = true;
    PrimaryActorTick.TickInterval = 0.5f;
    SetNetUpdateFrequency(2.f);
    Phases = { {90,60,0.70f,1}, {75,50,0.65f,2}, {60,45,0.60f,3}, {45,40,0.55f,5}, {40,35,0.50f,8}, {30,30,0.40f,12}, {20,25,0.00f,20} };
}
void AZZGameState::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& O) const
{
    Super::GetLifetimeReplicatedProps(O);
    DOREPLIFETIME(AZZGameState, ZoneCenterFrom); DOREPLIFETIME(AZZGameState, ZoneCenterTo);
    DOREPLIFETIME(AZZGameState, RadiusFrom); DOREPLIFETIME(AZZGameState, RadiusTo);
    DOREPLIFETIME(AZZGameState, PhaseIndex); DOREPLIFETIME(AZZGameState, PhaseStartServerTime);
}
void AZZGameState::ServerBeginZone(int32 Seed)
{
    Rng.Initialize(Seed);
    ZoneCenterFrom = ZoneCenterTo = FVector(0, 0, 0);
    RadiusFrom = RadiusTo = MapRadius; PhaseIndex = -1;
    AdvancePhase();
}
void AZZGameState::AdvancePhase()
{
    if (PhaseIndex + 1 >= Phases.Num()) return;
    ++PhaseIndex;
    ZoneCenterFrom = ZoneCenterTo; RadiusFrom = RadiusTo;
    const float NewR = RadiusFrom * Phases[PhaseIndex].RadiusFactor;
    const float MaxOff = FMath::Max(0.f, RadiusFrom - NewR);
    const float Ang = Rng.FRandRange(0, 2 * PI), Dist = Rng.FRand() * MaxOff;
    ZoneCenterTo = FVector(ZoneCenterFrom.X + FMath::Cos(Ang) * Dist, ZoneCenterFrom.Y + FMath::Sin(Ang) * Dist, 0);
    RadiusTo = NewR;
    PhaseStartServerTime = GetServerWorldTimeSeconds();
}
void AZZGameState::GetCurrentZone(FVector& C, float& R) const
{
    if (PhaseIndex < 0) { C = FVector::ZeroVector; R = MapRadius; return; }
    const FZZZonePhase& P = Phases[PhaseIndex];
    const double T = GetServerWorldTimeSeconds() - PhaseStartServerTime;
    const float A = FMath::Clamp((T - P.WaitSeconds) / FMath::Max(P.ShrinkSeconds, 0.01f), 0.0, 1.0);
    C = FMath::Lerp((FVector)ZoneCenterFrom, (FVector)ZoneCenterTo, A);
    R = FMath::Lerp(RadiusFrom, RadiusTo, A);
}
void AZZGameState::ServerTickZone()
{
    if (!HasAuthority() || PhaseIndex < 0) return;
    const FZZZonePhase& P = Phases[PhaseIndex];
    if (GetServerWorldTimeSeconds() - PhaseStartServerTime > P.WaitSeconds + P.ShrinkSeconds) AdvancePhase();
    FVector C; float R; GetCurrentZone(C, R);
    for (TActorIterator<AZZCharacter> It(GetWorld()); It; ++It)
        if (It->Phase == EZZPlayerPhase::Ground && FVector::Dist2D(It->GetActorLocation(), C) > R)
            UGameplayStatics::ApplyDamage(*It, P.DamagePerSecond * 0.5f, nullptr, this, nullptr);   // tick a cada 0,5 s
}
