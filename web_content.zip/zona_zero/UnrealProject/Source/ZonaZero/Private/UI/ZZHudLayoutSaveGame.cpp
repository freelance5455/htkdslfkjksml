#include "UI/ZZHudLayoutSaveGame.h"
#include "Kismet/GameplayStatics.h"
static const TCHAR* SlotName = TEXT("ZZ_HudLayouts");

UZZHudLayoutSaveGame* UZZHudLayoutSaveGame::LoadOrCreate()
{
    if (UGameplayStatics::DoesSaveGameExist(SlotName, 0))
        if (auto* S = Cast<UZZHudLayoutSaveGame>(UGameplayStatics::LoadGameFromSlot(SlotName, 0))) return S;
    auto* N = Cast<UZZHudLayoutSaveGame>(UGameplayStatics::CreateSaveGameObject(StaticClass()));
    N->Layouts.SetNum(3);
    N->Layouts[0].Name = TEXT("2 dedos"); N->Layouts[1].Name = TEXT("3 dedos"); N->Layouts[2].Name = TEXT("4 dedos");
    return N;
}
void UZZHudLayoutSaveGame::Save() { UGameplayStatics::SaveGameToSlot(this, SlotName, 0); }
