#pragma once
#include "CoreMinimal.h"
#include "GameFramework/GameMode.h"
#include "ZZGameMode.generated.h"

class AZZCharacter;

UCLASS()
class ZONAZERO_API AZZGameMode : public AGameMode
{
    GENERATED_BODY()
public:
    AZZGameMode();
    UPROPERTY(EditDefaultsOnly, Category="Match") int32 MaxParticipants = 50;
    UPROPERTY(EditDefaultsOnly, Category="Match") float LobbyWaitSeconds = 20.f;
    UPROPERTY(EditDefaultsOnly, Category="Match") TSubclassOf<AZZCharacter> BotCharacterClass;
    UPROPERTY(EditDefaultsOnly, Category="Match") TSubclassOf<AController> BotControllerClass;

    virtual void BeginPlay() override;
    virtual void Tick(float Dt) override;
    virtual bool ReadyToStartMatch_Implementation() override;
    virtual void HandleMatchHasStarted() override;
    UFUNCTION() void CheckVictory();
private:
    void FillWithBots();
    void LaunchPlane();
    FTimerHandle ZoneTimer;
    FTimerHandle VictoryTimer;
};
