#pragma once
#include "CoreMinimal.h"
#include "GameFramework/GameState.h"
#include "ZZGameState.generated.h"

USTRUCT(BlueprintType)
struct FZZZonePhase
{
    GENERATED_BODY()
    UPROPERTY(EditAnywhere) float WaitSeconds = 90.f;
    UPROPERTY(EditAnywhere) float ShrinkSeconds = 60.f;
    UPROPERTY(EditAnywhere) float RadiusFactor = 0.7f;
    UPROPERTY(EditAnywhere) float DamagePerSecond = 1.f;
};

/** A zona é determinística: replica-se só (centro, raio, fase, tempo de início) e o raio é calculado localmente. */
UCLASS()
class ZONAZERO_API AZZGameState : public AGameState
{
    GENERATED_BODY()
public:
    AZZGameState();
    UPROPERTY(EditDefaultsOnly, Category="Zone") TArray<FZZZonePhase> Phases;
    UPROPERTY(EditDefaultsOnly, Category="Zone") float MapRadius = 100000.f;   // 1 km

    UPROPERTY(ReplicatedUsing=OnRep_Zone, BlueprintReadOnly) FVector_NetQuantize ZoneCenterFrom;
    UPROPERTY(ReplicatedUsing=OnRep_Zone, BlueprintReadOnly) FVector_NetQuantize ZoneCenterTo;
    UPROPERTY(ReplicatedUsing=OnRep_Zone, BlueprintReadOnly) float RadiusFrom = 0.f;
    UPROPERTY(ReplicatedUsing=OnRep_Zone, BlueprintReadOnly) float RadiusTo = 0.f;
    UPROPERTY(ReplicatedUsing=OnRep_Zone, BlueprintReadOnly) int32 PhaseIndex = -1;
    UPROPERTY(ReplicatedUsing=OnRep_Zone, BlueprintReadOnly) double PhaseStartServerTime = 0.0;

    UFUNCTION() void OnRep_Zone() {}
    UFUNCTION(BlueprintPure) void GetCurrentZone(FVector& Center, float& Radius) const;
    void ServerBeginZone(int32 Seed);
    void ServerTickZone();
    virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& Out) const override;
private:
    FRandomStream Rng;
    void AdvancePhase();
};
