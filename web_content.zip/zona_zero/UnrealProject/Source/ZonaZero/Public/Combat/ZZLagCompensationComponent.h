#pragma once
#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "ZZLagCompensationComponent.generated.h"

struct FZZHistoryFrame { double Time = 0; FVector Location = FVector::ZeroVector; };

/** Guarda ~500 ms de posições (somente no servidor) para rebobinar alvos no momento do tiro. */
UCLASS(ClassGroup=(ZZ), meta=(BlueprintSpawnableComponent))
class ZONAZERO_API UZZLagCompensationComponent : public UActorComponent
{
    GENERATED_BODY()
public:
    UZZLagCompensationComponent();
    UPROPERTY(EditDefaultsOnly) float HistorySeconds = 0.5f;
    UPROPERTY(EditDefaultsOnly) float MaxRewindSeconds = 0.25f;

    virtual void TickComponent(float Dt, ELevelTick Type, FActorComponentTickFunction* F) override;

    /** Posição interpolada do dono em ServerTime. */
    bool GetLocationAt(double ServerTime, FVector& Out) const;

    /** Testa o segmento de tiro contra a cápsula dos outros personagens, rebobinados. Retorna o ator atingido. */
    static AActor* RewindedSegmentTest(UWorld* World, AActor* Shooter, const FVector& Start, const FVector& End,
                                       double ClientViewServerTime, FVector& OutHit);
private:
    TArray<FZZHistoryFrame> History;
};
