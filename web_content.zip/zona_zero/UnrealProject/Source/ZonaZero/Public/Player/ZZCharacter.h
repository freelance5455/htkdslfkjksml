#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "ZZCharacter.generated.h"

class UZZLagCompensationComponent;

UENUM(BlueprintType)
enum class EZZPlayerPhase : uint8 { InPlane, Freefall, Gliding, Ground, Dead };

UCLASS()
class ZONAZERO_API AZZCharacter : public ACharacter
{
    GENERATED_BODY()
public:
    AZZCharacter(const FObjectInitializer& Init);

    UPROPERTY(VisibleAnywhere) UZZLagCompensationComponent* LagComp;

    UPROPERTY(ReplicatedUsing=OnRep_Health, BlueprintReadOnly) float Health = 100.f;
    UPROPERTY(Replicated, BlueprintReadOnly) float Shield = 0.f;
    UPROPERTY(Replicated, BlueprintReadOnly) EZZPlayerPhase Phase = EZZPlayerPhase::Ground;
    UPROPERTY(Replicated, BlueprintReadOnly) uint16 ActiveEmoteId = 0;   // só o ID é replicado

    UFUNCTION() void OnRep_Health();
    UFUNCTION(BlueprintCallable) void StartSprint();
    UFUNCTION(BlueprintCallable) void StopSprint();
    UFUNCTION(BlueprintCallable) void RequestFire(FVector Origin, FVector Direction);
    UFUNCTION(BlueprintCallable) void RequestEmote(uint16 EmoteId);

    // Paraquedas
    UFUNCTION(Server, Reliable) void Server_Jump();           // salto do avião
    UFUNCTION(Server, Reliable) void Server_OpenParachute();

    virtual float TakeDamage(float Dmg, const FDamageEvent& E, AController* I, AActor* C) override;
    virtual void Tick(float Dt) override;
    virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& Out) const override;

protected:
    /** Cliente envia o instante do servidor que ele via (GameState->GetServerWorldTimeSeconds() - interp delay). */
    UFUNCTION(Server, Unreliable, WithValidation)
    void Server_Fire(FVector_NetQuantize Origin, FVector_NetQuantizeNormal Dir, double ClientViewServerTime);
    UFUNCTION(Server, Reliable) void Server_Emote(uint16 EmoteId);

    void Die(AController* Killer);
    void TryAutoVault();
    void TickAirborne(float Dt);

    UPROPERTY(EditDefaultsOnly, Category="ZZ|Fall") float DiveVertical = -6000.f, DiveHorizontal = 2000.f;
    UPROPERTY(EditDefaultsOnly, Category="ZZ|Fall") float GlideVertical = -2500.f, GlideHorizontal = 4000.f;
    UPROPERTY(EditDefaultsOnly, Category="ZZ|Fall") float AutoOpenHeight = 10000.f;   // 100 m
    UPROPERTY(EditDefaultsOnly, Category="ZZ|Combat") float WeaponDamage = 22.f, WeaponRange = 30000.f, FireInterval = 0.09f;
    double LastFireTime = 0;
};
