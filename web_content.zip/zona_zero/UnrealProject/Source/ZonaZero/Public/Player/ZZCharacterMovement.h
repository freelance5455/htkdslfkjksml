#pragma once
#include "CoreMinimal.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "ZZCharacterMovement.generated.h"

/** CMC com Sprint previsto pelo cliente (saved moves) => sem input lag e sem correção desnecessária. */
UCLASS()
class ZONAZERO_API UZZCharacterMovement : public UCharacterMovementComponent
{
    GENERATED_BODY()
public:
    UZZCharacterMovement();

    UPROPERTY(EditDefaultsOnly, Category="ZZ|Movement") float SprintSpeedMultiplier = 1.45f;
    UPROPERTY(EditDefaultsOnly, Category="ZZ|Movement") float VaultMaxHeight = 140.f;

    void SetWantsToSprint(bool bSprint) { bWantsToSprint = bSprint; }
    bool IsSprinting() const { return bWantsToSprint && Velocity.SizeSquared2D() > 100.f; }

    virtual float GetMaxSpeed() const override;
    virtual void UpdateFromCompressedFlags(uint8 Flags) override;
    virtual class FNetworkPredictionData_Client* GetPredictionData_Client() const override;

    bool bWantsToSprint = false;

    class FSavedMove_ZZ : public FSavedMove_Character
    {
    public:
        typedef FSavedMove_Character Super;
        uint8 bSavedWantsToSprint : 1;
        virtual void Clear() override;
        virtual uint8 GetCompressedFlags() const override;
        virtual bool CanCombineWith(const FSavedMovePtr& NewMove, ACharacter* C, float MaxDelta) const override;
        virtual void SetMoveFor(ACharacter* C, float InDeltaTime, FVector const& NewAccel, FNetworkPredictionData_Client_Character& ClientData) override;
        virtual void PrepMoveFor(ACharacter* C) override;
    };

    class FNetworkPredictionData_Client_ZZ : public FNetworkPredictionData_Client_Character
    {
    public:
        FNetworkPredictionData_Client_ZZ(const UCharacterMovementComponent& Cmc) : FNetworkPredictionData_Client_Character(Cmc) {}
        virtual FSavedMovePtr AllocateNewMove() override { return MakeShared<FSavedMove_ZZ>(); }
    };
};
