#pragma once
#include "CoreMinimal.h"
#include "GameFramework/SaveGame.h"
#include "ZZHudLayoutSaveGame.generated.h"

USTRUCT(BlueprintType)
struct FZZHudElement
{
    GENERATED_BODY()
    UPROPERTY(EditAnywhere, BlueprintReadWrite) FName Id;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) FVector2D Position = FVector2D(0.5, 0.5);   // 0..1
    UPROPERTY(EditAnywhere, BlueprintReadWrite) float ScalePercent = 100.f;                 // 50..200
    UPROPERTY(EditAnywhere, BlueprintReadWrite) float Opacity = 1.f;                        // 0..1
    UPROPERTY(EditAnywhere, BlueprintReadWrite) bool bVisible = true;
};
USTRUCT(BlueprintType)
struct FZZHudLayout
{
    GENERATED_BODY()
    UPROPERTY(EditAnywhere, BlueprintReadWrite) FString Name = TEXT("2 dedos");
    UPROPERTY(EditAnywhere, BlueprintReadWrite) TArray<FZZHudElement> Elements;
};

/** Até 3 layouts personalizados (2, 3 e 4 dedos). UI (UMG) arrasta/redimensiona e chama Save. */
UCLASS()
class ZONAZERO_API UZZHudLayoutSaveGame : public USaveGame
{
    GENERATED_BODY()
public:
    UPROPERTY(BlueprintReadWrite) TArray<FZZHudLayout> Layouts;   // tamanho 3
    UPROPERTY(BlueprintReadWrite) int32 ActiveLayout = 0;

    UFUNCTION(BlueprintCallable) static UZZHudLayoutSaveGame* LoadOrCreate();
    UFUNCTION(BlueprintCallable) void Save();
};
