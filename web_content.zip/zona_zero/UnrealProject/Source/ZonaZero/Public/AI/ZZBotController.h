#pragma once
#include "CoreMinimal.h"
#include "AIController.h"
#include "ZZBotController.generated.h"

class UBehaviorTree; class UAIPerceptionComponent;

UCLASS()
class ZONAZERO_API AZZBotController : public AAIController
{
    GENERATED_BODY()
public:
    AZZBotController();
    UPROPERTY(EditDefaultsOnly, Category="AI") UBehaviorTree* BehaviorTreeAsset;   // BT_Bot (macro) + EQS de cobertura
    UPROPERTY(BlueprintReadOnly, Category="AI") float SkillLevel = 5.f;            // 0..10

    // Parâmetros humanos de mira (derivados do nível)
    float ReactionTime() const { return FMath::GetMappedRangeValueClamped(FVector2D(0, 10), FVector2D(0.6f, 0.18f), SkillLevel); }
    float AimErrorDeg()  const { return FMath::GetMappedRangeValueClamped(FVector2D(0, 10), FVector2D(4.f, 0.6f), SkillLevel); }
    float GrenadeChance()const { return FMath::GetMappedRangeValueClamped(FVector2D(0, 10), FVector2D(0.1f, 0.9f), SkillLevel); }
    float FlankChance()  const { return FMath::GetMappedRangeValueClamped(FVector2D(0, 10), FVector2D(0.05f, 0.7f), SkillLevel); }

    /** Chamado pelo GameMode com a estimativa de habilidade humana (EMA de K/D, precisão...) + ajuste de patente. */
    void AdaptDifficulty(float HumanSkillEstimate, float RankBonus);

protected:
    virtual void OnPossess(APawn* InPawn) override;
    UPROPERTY(VisibleAnywhere) UAIPerceptionComponent* Perception;
    UFUNCTION() void OnPerceptionUpdated(const TArray<AActor*>& Actors);
};
