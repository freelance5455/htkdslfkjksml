#pragma once
#include "CoreMinimal.h"
#include "WheeledVehiclePawn.h"
#include "ZZVehiclePawn.generated.h"

UENUM(BlueprintType) enum class EZZVehicleType : uint8 { ArmoredAssault, DesertBuggy, MilitaryTruck, Supercar, FamilySUV, UrbanSedan, Motorcycle };

/** Base dos 7 veículos. Cada tipo = 1 Blueprint filho (malha, rodas Chaos, curva de torque) com esses valores. */
UCLASS()
class ZONAZERO_API AZZVehiclePawn : public AWheeledVehiclePawn
{
    GENERATED_BODY()
public:
    AZZVehiclePawn();
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly) EZZVehicleType Type = EZZVehicleType::FamilySUV;
    UPROPERTY(EditDefaultsOnly) float MaxHealth = 1000.f, MaxFuel = 100.f, FuelPerSecondAtFullThrottle = 0.4f;
    UPROPERTY(EditDefaultsOnly) int32 Seats = 5;
    UPROPERTY(ReplicatedUsing=OnRep_Health, BlueprintReadOnly) float Health = 1000.f;
    UPROPERTY(Replicated, BlueprintReadOnly) float Fuel = 100.f;

    UFUNCTION() void OnRep_Health();
    virtual void Tick(float Dt) override;
    virtual float TakeDamage(float Dmg, const FDamageEvent& E, AController* I, AActor* C) override;
    virtual void NotifyHit(UPrimitiveComponent* MyComp, AActor* Other, UPrimitiveComponent* OtherComp, bool bSelfMoved, FVector HitLoc, FVector HitNormal, FVector NormalImpulse, const FHitResult& Hit) override;
    virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& Out) const override;
protected:
    void Explode();
};
