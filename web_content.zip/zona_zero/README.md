# ZONA ZERO — Battle Royale (Documento de Design e Arquitetura)

Nome de trabalho: **ZONA ZERO** (original; não use nomes, personagens, armas ou assets de Free Fire ou Fortnite, só inspiração de gameplay/estilo).

Conceito: ritmo rápido de partida mobile (~10-15 min, 50 jogadores/bots) + visual estilizado vibrante com materiais e iluminação de alta qualidade.

## Índice
1. docs/01_direcao_de_arte.md
2. docs/02_mapas.md
3. docs/03_aviao_e_paraquedas.md
4. docs/04_movimentacao_animacoes_emotes.md
5. docs/05_veiculos.md
6. docs/06_hud_e_configuracoes.md
7. docs/07_lobby_perfil_patentes.md
8. docs/08_ia_dos_bots.md
9. docs/09_arquitetura_netcode.md  (FOCO PRINCIPAL)
10. docs/10_roadmap_e_riscos.md
11. pseudocodigo/ (servidor, cliente, bots, veículos, zona)

## Decisões-chave (resumo)
- Servidor **autoritativo** dedicado, tick de 30 Hz (movimento do dono a 60 Hz no cliente).
- **Client-side prediction + reconciliação**, interpolação de entidades remotas, **lag compensation** para tiros.
- **Interest management** em grade espacial: cada cliente só recebe o que é relevante.
- Bots rodam **no servidor** como jogadores simulados (sem custo de rede extra, mesmas regras).
- Qualidade gráfica em **camadas** (Baixo/Médio/Alto/Ultra): Ray Tracing/Lumen só em dispositivos topo de linha e PC.

## ATUALIZAÇÃO: Unreal Engine 5
O projeto agora tem implementação base em **Unreal Engine 5 (C++)**:
- `UnrealProject/` → projeto (.uproject), targets (Game/Editor/Server), módulo `ZonaZero`, configs de rede.
- `docs/11_unreal_engine5.md` → como abrir, mapa de classes, o que falta no Editor.
Observação: esqueleto não compilado/testado; veja o aviso no doc 11.

## HTML (somente para leitura offline)
Abra `html/index.html` com duplo clique: é a documentação completa em páginas HTML + referência do código-fonte. Não é o jogo; o jogo é o projeto Unreal em `UnrealProject/`.
