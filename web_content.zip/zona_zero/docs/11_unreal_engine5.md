# 11. Implementação em Unreal Engine 5

Engine definida: **Unreal Engine 5** (projeto em `UnrealProject/`, `EngineAssociation` 5.5; ajuste para a versão que você instalar).
Todo o código-fonte é C++ com Blueprints filhos para arte/animação/UI.

> Aviso honesto: este código é um esqueleto escrito sem acesso à engine; **não foi compilado nem testado aqui**. Espere pequenos ajustes de API na primeira compilação (varia entre 5.4/5.5/5.6).

## Pré-requisitos
- Unreal Engine 5.5+ (Launcher para Editor/cliente; **servidor dedicado exige a engine compilada do código-fonte via GitHub**).
- Visual Studio 2022 (workload "Game development with C++") ou Rider; Windows SDK.
- Para mobile: Android Studio/NDK conforme a versão da engine; Xcode para iOS.

## Como abrir
1. Copie `UnrealProject/` para uma pasta sem espaços.
2. Clique direito em `ZonaZero.uproject` → *Generate Visual Studio project files*.
3. Compile `ZonaZeroEditor` (Development Editor, Win64) e abra o projeto.
4. Servidor: compile o target `ZonaZeroServer`; rode `ZonaZeroServer.exe /Game/Maps/Island_Tropical -log`.
5. Cliente: `ZonaZero.exe 127.0.0.1 -log`.

## Mapa classe → feature
| Classe C++ | Função |
|---|---|
| `UZZCharacterMovement` | CMC com Sprint previsto (saved moves) = zero input lag + reconciliação nativa da Unreal |
| `AZZCharacter` | Vida/escudo, tiro (Server RPC), emote por ID, queda livre/paraquedas, auto-vault |
| `UZZLagCompensationComponent` | Histórico de 500 ms + rebobinar alvos no tiro (máx. 250 ms) |
| `AZZGameState` | Zona determinística: replica só centro/raio/fase/tempo; raio calculado local |
| `AZZGameMode` | Fila/lobby, completa com bots até 50, inicia avião e zona, condição de vitória |
| `AZZBotController` | AIPerception (visão 110°, audição, memória 8 s) + Behavior Tree + parâmetros humanos de mira por nível |
| `AZZVehiclePawn` | Base Chaos Vehicles com vida, combustível, dano por colisão; 7 Blueprints filhos |
| `UZZHudLayoutSaveGame` | 3 layouts de HUD (2/3/4 dedos) salvos em SaveGame |

## Netcode na Unreal (como cada item da seção 9 é atendido)
- **Prediction/reconciliação**: nativo do `CharacterMovementComponent` (usamos `FSavedMove` custom para o sprint).
- **Interpolação de remotos**: `NetworkSmoothingMode = Exponential` (config no CMC).
- **Servidor autoritativo**: Server RPCs com `WithValidation`; dano só no servidor.
- **Lag compensation**: `UZZLagCompensationComponent` (CMC não faz rewind de hitbox sozinho).
- **Interest management**: `NetCullDistanceSquared` (250 m) + `NetUpdateFrequency` 30→5 Hz (`SetMinNetUpdateFrequency`). Para escala maior, habilite **Replication Graph** (plugin) ou **Iris** (opcional, veja `DefaultEngine.ini`; confirme o status na sua versão).
- **Banda**: `MaxClientRate=15000`, `NetServerMaxTickRate=30`; `COND_OwnerOnly`/`COND_SkipOwner` nas propriedades; tipos `FVector_NetQuantize` nos RPCs.
- **Zona e emotes** replicam só dados mínimos (cálculo/animação local).

## Gráficos na Unreal (camadas)
- **Ultra/Alto (PC/console)**: Lumen (GI/reflexos), Virtual Shadow Maps, Nanite nos prédios e rochas, nuvens volumétricas (Volumetric Cloud + Sky Atmosphere), Niagara.
- **Mobile**: Mobile Forward renderer, iluminação baked + probes, sem Lumen/Nanite; LODs agressivos; usar *Device Profiles* e *Scalability* (Baixo/Médio/Alto).
- **Vegetação interativa**: Material com *Render Target* de influência (jogador/veículos desenham) + World Position Offset; PCG/Foliage instanciado.
- **Personagens**: MetaHuman não é adequado para mobile; use modelos próprios + Control Rig + Groom (PC) / hair cards (mobile).
- **Mapas**: World Partition + Data Layers; interiores modulares; Level Streaming por célula.
- **Animação**: Motion Matching (Pose Search), IK Rig/Control Rig para pés e mãos; Motion Warping para vault; Montages para armas e emotes (face por blendshapes/Morph Targets).
- **Enhanced Input** para controles de toque + Common UI/UMG para o editor de HUD (arrastar, escala, opacidade).

## Trabalho que ainda precisa ser feito no Editor (não dá para gerar via código)
1. Criar os Blueprints: `BP_ZZCharacter`, `BP_ZZBot`, `BP_Plane`, 7 × `BP_Vehicle_*`, `BP_ZZGameMode`.
2. Criar `BT_Bot`, `BB_Bot` (chaves `TargetActor`, `LastKnownPos`), EQS de cobertura e tasks (Cover, Flank, Heal, Smoke, Revive).
3. Montar os 3 mapas (World Partition), NavMesh, loot spawners.
4. UI: HUD, Mover HUD, lobby, loading, perfil, ranking (UMG).
5. Animações (retarget do mannequin), áudio (MetaSounds, voz por proximidade via Voice Chat/EOS), economia/loja (backend).
6. Backend de contas/matchmaking (ex.: Epic Online Services ou seu próprio) e orquestração dos servidores (Agones).

## Testes de rede no Editor
No console do cliente: `Net PktLag=80`, `Net PktLoss=5`, `Net PktLagVariance=20`. Rodar com *Play as Client*, *Number of Players* 4+ e *Dedicated Server* ligado.
