# 7. Lobby, Carregamento, Perfil e Patentes

## Lobby 3D
- Hangar/base militar interativo; personagem em idle com variações; iluminação de estúdio.
- Atalhos: Loja, Inventário, Modo, Missões, Eventos, **Iniciar Partida**. Slots de esquadrão.

## Tela de carregamento
Arte conceitual HD por mapa, dicas de gameplay na base, barra de progresso estilizada; streaming em background (mapa, personagens, armas essenciais).

## Perfil
K/D, taxa de vitória, precisão, sobrevivência média, medalhas, histórico de partidas, personagem com skins atuais.

## Patentes
Bronze → Prata → Ouro → Platina → Diamante → Mestre → **Elite do Jogo**.
- 3 níveis (I-III) por divisão, exceto Mestre e Elite.
- Pontos por colocação + abates (colocação pesa mais); proteção no início de temporada.
- Matchmaking por MMR oculto, separado dos pontos de patente.
- Emblema 3D animado por patente (low-poly + shader emissivo).
