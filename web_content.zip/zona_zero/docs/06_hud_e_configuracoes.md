# 6. HUD, Customização e Configurações

## HUD padrão
- Minimapa interativo (canto superior), bússola em graus, contador de vivos/abates.
- Base central: vida + escudo. Direita: slots verticais de armas + munição. Botões rápidos: tiro, mirar, pular, agachar/deitar, recarregar, veículo.
- Aviso de zona + timer.

## Editor de HUD (Mover HUD)
`HudElement { id, x, y (0..1), escala (50-200%), opacidade (0-100%), visível }`
- Arrastar, redimensionar, opacidade, pré-visualização em tempo real.
- **3 layouts salvos** (2, 3 ou 4 dedos): `HudLayout[3]` com nome e preset padrão.
- Snap/guias e detecção de sobreposição. Salvo localmente + sincronizado com a conta (JSON pequeno).

## Configurações
- Gráficos: resolução (escala 50-100%), FPS (30/60/90/120/Liberado), sombras, anti-aliasing, vegetação.
- Sensibilidade: geral, câmera e por mira (Red Dot, 2x, 4x, 8x), giroscópio opcional.
- Áudio: master, efeitos, música, **chat de voz 3D por proximidade** (atenuação por distância, oclusão simples, push-to-talk ou aberto).
