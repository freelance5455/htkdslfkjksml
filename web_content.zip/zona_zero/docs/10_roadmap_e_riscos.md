# 10. Roadmap e Riscos

## Fases
1. **Protótipo (2-3 meses)**: movimentação, tiro, mapa pequeno, 10 jogadores, netcode base.
2. **Vertical slice (3-4 meses)**: avião/paraquedas, zona, 1 mapa completo, 50 jogadores/bots, 3 veículos, HUD.
3. **Alfa (4-6 meses)**: 3 mapas, 7 veículos, bots táticos, lobby, perfil, patentes.
4. **Beta**: otimização por device, anti-cheat, escala, telemetria, soft launch regional.

## Riscos
| Risco | Mitigação |
|---|---|
| Escopo gigante | Vertical slice primeiro; kits modulares; cortes por prioridade |
| Performance mobile vs. visual | Camadas de qualidade, budgets por device, profiling contínuo |
| Lag/dessincronização | Testes de rede automatizados desde o protótipo |
| Bots "injustos" | Modelo humano de percepção/mira; sem informação privilegiada |
| IP | Arte e nomes 100% originais; revisão jurídica |

Um jogo deste escopo costuma exigir uma equipe grande e vários anos. Este pacote é a base de especificação e arquitetura, não o jogo pronto.
