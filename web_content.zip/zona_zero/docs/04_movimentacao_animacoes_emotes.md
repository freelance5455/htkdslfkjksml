# 4. Movimentação, Animações e Emotes

## Controlador
- Cápsula cinemática com aceleração/desaceleração curtas (fluido, sem "travar").
- Estados: Idle, Walk, Run, Sprint, Crouch, Prone, Jump, Vault, Climb, Swim, Drive, Dead.
- **Vaulting automático**: raycast frontal + altura < 1,4 m + espaço livre → vault com root motion curto.
- Mesma função de movimento no cliente (predição) e no servidor (autoridade): determinística.

## Animações (MoCap)
- Locomoção em Motion Matching (ou blendspaces 2D em mobile).
- Lean em curvas, frenagem com "plant" dos pés, IK de pés em terreno irregular.
- Conjuntos por categoria de arma: Pistola, SMG, Rifle, Sniper, Escopeta, Arremessável.
- Camada de upper body separada (mirar/recarregar correndo).

## Emotes
- `EmoteDef { id, clip, duração, loop, faceClip, lipSyncAudio, vfxId, interrompível }`.
- Expressões por blendshapes (clip facial separado); lip-sync por visemas pré-calculados.
- VFX de partículas ao ativar (lobby: completo; partida: reduzido, cancela ao tomar dano).
- Replicação: apenas `emoteId` + timestamp; a animação roda localmente em cada cliente.
