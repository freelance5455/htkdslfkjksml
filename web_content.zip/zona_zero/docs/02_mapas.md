# 2. Os 3 Mapas (Design de Nível)

Regras gerais: 50 jogadores; mapas de ~2 x 2 km; todos os edifícios com interior acessível e mobiliado; ~12-16 pontos de interesse (POIs) em 3 tiers de loot.

## Mapa 1 — Ilha Tropical Urbana
- Praias, selva densa (cobertura alta), centro urbano vertical, favela vertical em encosta (combate em 3D).
- POIs: Centro Alto (arranha-céus), Morro Vertical, Porto, Resort, Ruínas da Selva.
- Verticalidade: tirolesas, escadas, telhados conectados. Foco em combate dinâmico de curta/média distância.

## Mapa 2 — Deserto Tecnológico
- Dunas com **deformação de pegadas** (decals + heightmap local), cânions, oásis futuristas, bases militares.
- Tempestade de areia ocasional reduz visibilidade.
- POIs: Base Alfa, Oásis Neon, Cânion Profundo, Radar, Hangares.
- Veículo ideal: Buggy. Longas distâncias abertas.

## Mapa 3 — Fronteira Ártica Industrial
- Montanhas nevadas, lagos congelados (superfície de baixo atrito: deslizamento), nevascas, fábricas.
- Nevasca: visibilidade reduzida + som abafado. Pegadas na neve (rastro visível por 20 s).
- POIs: Fábrica Central, Refinaria, Lago Congelado, Mina, Estação de Pesquisa.

## Interiores 100% acessíveis (otimização)
- Kits modulares (salas reutilizáveis) e mobília instanciada.
- Streaming por células (World Partition / equivalente); interiores só carregam LOD completo perto do jogador.
- Oclusão por portais; sem luz dinâmica em interiores em Baixo/Médio (baked).

## Zona segura
7 fases, cada uma com espera + encolhimento; dano por segundo cresce a cada fase. Centro final sorteado no servidor por seed.
