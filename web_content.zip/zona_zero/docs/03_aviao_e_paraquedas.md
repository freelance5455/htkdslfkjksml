# 3. Fase Inicial: Avião e Paraquedas

## Avião
- Aeronave militar em rota aleatória (dois pontos nas bordas, seed do servidor), ~90 m/s, cruza o mapa em ~25 s (ajustável).
- HUD: rota no minimapa, contador de jogadores a bordo, botão **SALTAR**, salto automático ao fim da rota.
- Jogadores a bordo são entidades "anexadas" ao avião (não replicam posição individual; economiza rede).

## Queda livre (Skydive)
- Estados: `Plane → Freefall → Glide → Landing → Ground`.
- Mergulho (vertical ~60 m/s, horizontal ~20 m/s) ↔ planeio (vertical ~25 m/s, horizontal ~40 m/s).
- Transição de salto com blend de 0,25 s; FOV dinâmico.

## Paraquedas / Glider
- Abre automático a ~100 m; manual após 3 s de queda.
- Oscilação proporcional à curva (roll) e ao vento (ruído de Perlin); personagem segurando as alças (IK de mãos).
- Pouso suave → corrida direta (blend 0,15 s); pouso brusco → rolamento.
- Servidor valida limites de velocidade/altitude (anti-cheat).
