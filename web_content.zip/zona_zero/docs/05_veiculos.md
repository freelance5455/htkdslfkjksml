# 5. Sistema de Veículos (7 tipos)

| # | Veículo | Categoria | Vida | Vel. máx. | Assentos | Notas |
|---|---|---|---|---|---|---|
| 1 | Blindado de Assalto 4x4 | Militar | 1800 | 75 km/h | 4 | Vidros reforçados, lento |
| 2 | Buggy do Deserto | Militar | 700 | 115 km/h | 2 | Suspensão alta, ótimo em areia |
| 3 | Caminhão de Carga Militar | Militar | 2500 | 65 km/h | 6 | Blindagem frontal |
| 4 | Superesportivo | Normal | 450 | 170 km/h | 2 | Aderência alta, controle sensível |
| 5 | SUV Familiar | Normal | 1000 | 100 km/h | 5 | Equilibrado |
| 6 | Sedã Urbano | Normal | 800 | 95 km/h | 4 | Tração dianteira, consumo baixo |
| 7 | Motocicleta Urbana | Normal | 350 | 130 km/h | 2 | Ágil, piloto exposto |

(Valores iniciais para balanceamento; ajustar com telemetria.)

## Física
- Raycast por roda (mola/amortecedor) + curva de atrito de pneu (drift por ângulo de derrapagem).
- Combustível por throttle; vida por dano; fumaça < 40%, explosão em 0 (dano em área).
- Colisão destrutível: deformação visual por zonas (para-choque, capô, portas) + dano pelo impulso.

## Rede
- Veículo com autoridade do servidor; motorista envia inputs (throttle, steer, brake) e prediz localmente.
- Passageiros derivam posição do assento. Replicação a 20-30 Hz com interpolação; rodas/suspensão derivadas localmente.
