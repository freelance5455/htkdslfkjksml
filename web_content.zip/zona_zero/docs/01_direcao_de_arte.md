# 1. Direção de Arte e Gráficos

## Pilares visuais
- **Estilizado vibrante**: formas limpas, paleta saturada, silhuetas legíveis a 50 m (essencial para combate).
- **Qualidade técnica alta**: texturas PBR 2K (personagens 4K no lobby), iluminação global, sombras suaves.
- **Legibilidade > realismo**: inimigos nunca podem se perder no cenário (rim light sutil, contraste de silhueta).

## Tecnologia de render (camadas)
| Camada | Alvo | GI | Sombras | Vegetação |
|---|---|---|---|---|
| Baixo | Android entrada | Probes baked | Blob + 1 cascata | Billboards + vento no shader |
| Médio | Android médio | Probes + SSAO | 2 cascatas | Instanciada, interação simples |
| Alto | Topo mobile / console | GI dinâmica (Lumen SW / equivalente) | 3 cascatas | Interação por esferas de influência |
| Ultra | PC | Lumen HW / Ray Tracing | Virtual Shadow Maps | Física leve em folhagem |

Importante: Ray Tracing em tempo real não roda em celulares comuns. Por isso Ultra é PC/console; mobile usa GI baked + probes.

## Personagens
- 18-25k triângulos (LOD0), LODs até 2k a distância. Proporção heroica estilizada.
- Rig com 70-90 ossos (+ faciais para emotes); blendshapes para expressão e lip-sync.
- Cabelo: cartões com simulação de ossos (mobile) / strands (PC Ultra).
- Roupas: simulação de cloth em capas/jaquetas só em Alto+; ossos secundários em Baixo/Médio.
- Pele: subsurface falso (wrap lighting) em mobile, SSS real em PC.

## Céu e ambiente
- Ciclo dia/noite progressivo por partida (ex.: manhã → pôr do sol ao longo de ~15 min).
- Nuvens volumétricas (raymarch) em Alto+; skybox animado + camadas de nuvens 2D em Baixo/Médio.
- Vegetação interativa: textura de "influência" (render target) onde jogador/veículos escrevem posição; o vertex shader da grama curva as lâminas. Barato e funciona em mobile.

## Pipeline de arte
Conceito → blockout → modelagem → textura (Substance) → rig/anim → LODs → otimização → validação de performance em device-alvo.
