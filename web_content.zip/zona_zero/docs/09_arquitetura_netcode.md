# 9. Arquitetura Técnica e Netcode (50 jogadores/bots sem lag de input)

## 9.1 Visão geral
```
 [Cliente mobile/PC] <--UDP/QUIC--> [Game Server dedicado (1 partida = 1 processo)]
        |                                  |
   Prediction                      Simulação autoritativa
   Interpolation                   Bots (IA) | Zona | Loot
        |                                  |
 [Gateway / Matchmaker / Auth / Perfil / Loja]  <-- backend (HTTPS/gRPC)
```
- Servidor dedicado autoritativo: o cliente nunca decide dano, loot ou posição final.
- Orquestração: Kubernetes + Agones (ou similar), 1 partida por pod, autoscaling por fila.
- Regiões próximas (ex.: São Paulo): alvo RTT < 60 ms.

## 9.2 Transporte
- UDP (ou QUIC) com camada própria: canal **não confiável** (estado/inputs), **confiável ordenado** (dano, loot, morte), **confiável sequenciado** (chat).
- Pacotes < 1200 bytes (sem fragmentação). Criptografia + token de sessão assinado.

## 9.3 Tick rates
| Sistema | Taxa |
|---|---|
| Simulação do servidor | 30 Hz (opcional 60 Hz em competitivo) |
| Input do cliente | amostra 60 Hz, envio 30 Hz com 3 últimos inputs redundantes |
| Snapshots servidor → cliente | 20-30 Hz (adaptativo por relevância) |
| Veículos | 20-30 Hz |
| Zona/relógio | eventos confiáveis |

## 9.4 Sem sensação de lag no input
**Prediction + reconciliação**
1. Cliente aplica o input na hora (0 ms percebido).
2. Guarda buffer `(seq, input, estado)`.
3. Servidor devolve `(ackSeq, estado autoritativo)`.
4. Cliente descarta `<= ackSeq`; se divergir além do limiar, refaz os inputs pendentes sobre o estado do servidor e suaviza o erro (~100 ms; teleporte só se > 2 m).

**Interpolação de remotos**: render ~100 ms no passado (2-3 snapshots); extrapolação limitada (≤ 150 ms) em perda.

**Lag compensation (tiros)**
- Servidor guarda histórico de hitboxes (~500 ms em ring buffer).
- No tiro, usa o tick que o cliente via, **rebobina** os alvos, valida o hit e reverte. Limite de 250 ms (anti-abuso de ping alto).
- Efeito local imediato (VFX/som); dano confirmado pelo servidor (hitmarker).

## 9.5 Redução de banda
- **Interest management**: grade espacial (células de 64 m); relevância ~250 m, detalhe completo ~50 m.
- **Frequência por distância**: perto 30 Hz, médio 15 Hz, longe 5 Hz.
- **Delta compression** contra o último snapshot confirmado por cliente.
- **Quantização**: posição 3×20 bits relativa à célula; yaw 10 bits; pitch 8 bits; vida 8 bits; flags em bitfield.
- Entidades estáticas e animações derivadas (rodas, etc.) não são replicadas; avião = 1 entidade.

### Orçamento de banda (estimativa)
- ~14-18 bytes por entidade/atualização após quantização + delta.
- ~15 entidades × 18 B × 25 Hz ≈ 54 kbps + eventos/overhead ≈ **70-90 kbps** de download por cliente.
- Upload ≈ **20-25 kbps**. Servidor (50 clientes) ≈ 4,5 Mbps de saída por partida.
(Estimativas de projeto; validar com testes de carga.)

## 9.6 Orçamento de CPU do servidor
- Meta: tick < 12 ms a 30 Hz.
- Bots: EQS a 5-10 Hz, movimento a 30 Hz, fatiado por frame (round-robin).
- Física só em entidades ativas; broadphase por grade.
- Hipótese: 8-15 partidas por máquina de 16 vCPU (validar).

## 9.7 Ciclo da partida
Fila → lobby (completa com bots se faltar gente) → alocação de servidor → carregamento → avião → fases da zona → vitória → persistência assíncrona → progressão de patente.

## 9.8 Segurança e anti-cheat
- Servidor valida velocidade, altitude, cadência de tiro, munição, linha de visão, alcance de loot.
- **Fog-of-war de rede**: não envia inimigos fora do raio de relevância (corta boa parte de wallhack/ESP).
- Rate limit, detecção de anomalias, integridade do cliente (Play Integrity / App Attest).
- Telemetria: RTT, perda, correções por minuto, tick time, p95 do tamanho de snapshot.

## 9.9 Rede ruim
- Perda < 5%: redundância de inputs. 5-15%: reduzir snapshots de distantes. > 15%: só entidades críticas + indicador.
- Reconexão em 30 s com snapshot completo. Jitter buffer adaptativo (80-150 ms).

## 9.10 Engine (DEFINIDA: Unreal Engine 5 — ver doc 11)
Trade-offs considerados:
- **Unreal 5**: melhor visual (Lumen, Nanite, VSM), Iris/Replication Graph; mais pesado em mobile.
- **Unity (DOTS + Netcode for Entities)**: leve, forte em mobile; mais trabalho para visual de topo.
- Mobile como prioridade → Unity, ou UE5 com perfil mobile rigoroso; visual Ultra só em PC/console.

## 9.11 Testes de rede
Simulador (40-250 ms, jitter, perda 0-20%), clientes headless de carga (50+/partida), soak test de 2 h, replay determinístico para depurar dessincronização.
