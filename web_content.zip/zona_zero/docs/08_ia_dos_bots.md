# 8. Bots Super Inteligentes

## Arquitetura
Behavior Tree (macro) + Utility AI (tática) + NavMesh + Perception. Bots são "jogadores" no servidor: mesmos inputs e regras, sem visão privilegiada por padrão.

## Percepção
- Visão: cone de 110°, alcance por luz/clima, raycast de linha de visão.
- Audição: tiros, passos e veículos geram eventos de ruído com raio.
- Memória: última posição conhecida do alvo, decai em ~8 s.

## Comportamento tático
- **Cobertura**: EQS pontua pontos de cobertura (proteção, distância, saída).
- **Flanqueio**: rota alternativa com ângulo > 60° em relação ao atacante.
- **Recuo e cura**: vida < 35% → quebra a linha de visão, cura, retorna.
- **Fumaça + reviver** aliado caído.
- Movimento nunca em linha reta constante (strafe, variação de velocidade, peeks).

## Precisão sem "mira mágica"
Precisão vem de modelo humano: tempo de reação, aquisição de alvo, recuo, erro por movimento/distância. Níveis altos não "erram de propósito"; apenas têm parâmetros melhores.

## Adaptação de dificuldade
```
skill = EMA( f(K/D recente, precisão, tempo até 1º abate, posicionamento) )
nivelBot = clamp(skill + ajuste da patente, 0..10)
reação 600ms→180ms | erro de mira 4°→0.6° | granadas 10%→90% | flanqueio 5%→70%
```
Boa prática: sinalizar partidas com bots (exigência em algumas lojas/regiões).

Pseudocódigo em `pseudocodigo/bot_ai.pseudo`.
