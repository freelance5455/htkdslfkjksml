#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""المحلل الفلكي الشامل v0.2 - لوحة السماء الحية للأهواز.
Requires: pip install pyswisseph
Run: python astro_live_ahvaz_v0_2.py
Then open http://127.0.0.1:8765
"""
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
import json, math
try:
    import swisseph as swe
except ImportError:
    raise SystemExit('ثبت pyswisseph أولاً: pip install pyswisseph')

HOST='127.0.0.1'; PORT=8765
TZ=ZoneInfo('Asia/Tehran')
LAT=31.3297911630975; LON=48.7240142973449
CITY='الأهواز، إيران'
SIGNS=['الحمل','الثور','الجوزاء','السرطان','الأسد','العذراء','الميزان','العقرب','القوس','الجدي','الدلو','الحوت']
SYMBOLS=['♈','♉','♊','♋','♌','♍','♎','♏','♐','♑','♒','♓']
RULERS=['المريخ','الزهرة','عطارد','القمر','الشمس','عطارد','الزهرة','المريخ','المشتري','زحل','زحل','المشتري']
PLANETS=[('sun','الشمس','☉',swe.SUN),('moon','القمر','☽',swe.MOON),('mercury','عطارد','☿',swe.MERCURY),('venus','الزهرة','♀',swe.VENUS),('mars','المريخ','♂',swe.MARS),('jupiter','المشتري','♃',swe.JUPITER),('saturn','زحل','♄',swe.SATURN)]
OPTIONAL=[('uranus','أورانوس','♅',swe.URANUS),('neptune','نبتون','♆',swe.NEPTUNE),('pluto','بلوتو','♇',swe.PLUTO)]
FLAGS=swe.FLG_SWIEPH|swe.FLG_SPEED

# Traditional major aspects. A deliberately conservative orb is used for void-of-course.
ASPECTS=[(0,'اقتران',8),(60,'تسديس',6),(90,'تربيع',7),(120,'تثليث',7),(180,'مقابلة',8)]

def norm(x): return x%360

def sign_info(lon):
    i=int(norm(lon)//30); deg=norm(lon)-i*30
    return i, SIGNS[i], SYMBOLS[i], deg

def jd_for(dt_utc):
    u=dt_utc.astimezone(timezone.utc)
    h=u.hour+u.minute/60+u.second/3600+u.microsecond/3.6e9
    return swe.julday(u.year,u.month,u.day,h,swe.GREG_CAL)

def sunrise_sunset(dt_local):
    # Sunrise/sunset for the configured city using Swiss Ephemeris.
    local=dt_local.astimezone(TZ)
    jd=swe.julday(local.year,local.month,local.day,0,swe.GREG_CAL)
    geopos=(LON,LAT,0)
    rsmi=swe.CALC_RISE|swe.BIT_DISC_CENTER|swe.BIT_NO_REFRACTION
    def rt(jd0, flag):
        value, tret=swe.rise_trans(jd0,swe.SUN,rsmi|flag,geopos)
        return datetime.fromtimestamp((tret[0]-2440587.5)*86400,timezone.utc).astimezone(TZ)
    sunrise=rt(jd,swe.CALC_RISE)
    sunset=rt(jd,swe.CALC_SET)
    if sunset <= sunrise: sunset += __import__('datetime').timedelta(days=1)
    # next sunrise
    next_sunrise=rt(jd+1,swe.CALC_RISE)
    return sunrise,sunset,next_sunrise

PLANETARY_HOUR_ORDER=['الشمس','الزهرة','عطارد','القمر','زحل','المشتري','المريخ']
WEEKDAY_RULERS={0:'القمر',1:'المريخ',2:'عطارد',3:'المشتري',4:'الزهرة',5:'زحل',6:'الشمس'}

def planetary_hour(dt_local):
    local=dt_local.astimezone(TZ)
    sunrise,sunset,next_sunrise=sunrise_sunset(local)
    # Day hours: sunrise to sunset (12), night hours: sunset to next sunrise (12).
    if sunrise <= local < sunset:
        start,end=sunrise,sunset; is_day=True
    else:
        start,end=sunset,next_sunrise; is_day=False
    total=(end-start).total_seconds()/12.0
    n=int((local-start).total_seconds()//total)+1
    n=max(1,min(12,n))
    day_ruler=WEEKDAY_RULERS[local.weekday()]
    idx=PLANETARY_HOUR_ORDER.index(day_ruler)
    # Chaldean sequence advances one planet per hour.
    ruler=PLANETARY_HOUR_ORDER[(idx+(n-1)+(0 if is_day else 12))%7]
    hs=start+(n-1)*__import__('datetime').timedelta(seconds=total)
    he=start+n*__import__('datetime').timedelta(seconds=total)
    return {'number':n,'period':'نهارية' if is_day else 'ليلية','ruler':ruler,
            'start':hs.isoformat(),'end':he.isoformat(),
            'sunrise':sunrise.isoformat(),'sunset':sunset.isoformat(),
            'next_sunrise':next_sunrise.isoformat(),'day_ruler':day_ruler}

def calc(dt_local):
    jd=jd_for(dt_local)
    bodies={}
    for pid,name,sym,code in PLANETS+OPTIONAL:
        xx, _ = swe.calc_ut(jd, code, FLAGS)
        lon,speed=xx[0],xx[3]
        si,sn,ss,deg=sign_info(lon)
        bodies[pid]={'id':pid,'name':name,'symbol':sym,'longitude':lon,'speed':speed,'retrograde':speed<0,'sign_index':si,'sign':sn,'sign_symbol':ss,'degree':deg}
    cusps, ascmc = swe.houses_ex(jd, LAT, LON, b'P')
    asc=norm(ascmc[0]); mc=norm(ascmc[1])
    asi,asn,ass,adeg=sign_info(asc); mci,mcn,mcs,mdeg=sign_info(mc)
    # Whole Sign houses: sign containing Ascendant is house 1.
    for b in bodies.values():
        b['house']=((b['sign_index']-asi)%12)+1
    # Major aspects among traditional planets.
    aspect_list=[]
    ids=[p[0] for p in PLANETS]
    for i,a in enumerate(ids):
        for b in ids[i+1:]:
            d=abs(norm(bodies[a]['longitude']-bodies[b]['longitude'])); d=min(d,360-d)
            hit=None
            for angle,label,orb in ASPECTS:
                if abs(d-angle)<=orb: hit=(angle,label,round(abs(d-angle),2)); break
            if hit: aspect_list.append({'a':a,'b':b,'aspect':hit[1],'orb':hit[2],'angle':hit[0]})
    # Void of course: next major applying aspect of Moon to a traditional planet before sign change.
    moon=bodies['moon']; moon_lon=moon['longitude']; moon_si=moon['sign_index']; end=(moon_si+1)*30
    if end<=moon_lon: end+=30
    end_abs=moon_lon+(end-moon_lon)
    candidates=[]
    # Estimate future crossing of aspect target using current longitudinal speeds.
    ms=moon['speed']
    for pid in ids:
        if pid=='moon': continue
        p=bodies[pid]; ps=p['speed']
        for angle,label,orb in ASPECTS:
            if angle==0: pass
            # Applying means signed separation toward target aspect decreases toward zero.
            for direction in (1,-1):
                target=norm(p['longitude']+direction*angle)
                delta=norm(target-moon_lon)
                rel=ms-ps
                if rel>0 and delta>0:
                    t=delta/rel
                elif rel<0 and delta>0:
                    # alternative wrap trajectory
                    delta2=delta-360
                    t=delta2/rel if delta2/rel>0 else 999
                else: t=999
                if 0<t<2 and moon_lon+ms*t < end_abs+0.05:
                    candidates.append((t,pid,label))
    voc=len(candidates)==0
    next_aspect=None
    if candidates:
        _,pid,label=min(candidates,key=lambda x:x[0]); next_aspect={'planet':bodies[pid]['name'],'aspect':label}
    # Exact local date/time display.
    local=dt_local.astimezone(TZ)
    # Approximate end of current lunar sign by linear speed.
    remain=max(0,end_abs-moon_lon); hours=remain/max(abs(ms),0.01)
    sign_end=local.timestamp()+hours*3600
    return {
      'city':CITY,'lat':LAT,'lon':LON,'timezone':'Asia/Tehran','utc_offset':'+03:30',
      'local_iso':local.isoformat(),'local_display':local.strftime('%Y-%m-%d %H:%M:%S'),
      'jd':jd,'asc':{'longitude':asc,'sign':asn,'symbol':ass,'degree':adeg,'ruler':RULERS[asi]},
      'mc':{'longitude':mc,'sign':mcn,'symbol':mcs,'degree':mdeg},
      'moon':{**moon,'void_of_course':voc,'next_applying':next_aspect,'estimated_sign_end':datetime.fromtimestamp(sign_end,TZ).isoformat()},
      'retrogrades':[{'id':b['id'],'name':b['name'],'symbol':b['symbol'],'sign':b['sign'],'degree':b['degree']} for b in bodies.values() if b['retrograde']],
      'moon_in_scorpio':moon['sign_index']==7,
      'planets':list(bodies.values()),'aspects':aspect_list,'planetary_hour':planetary_hour(local)
    }

HTML='''<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>المحلل الفلكي الشامل — السماء الحية</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#0b1020;color:#eef2ff;font-family:system-ui,-apple-system,"Noto Sans Arabic",sans-serif}header{padding:18px 16px;border-bottom:1px solid #29304a;background:#11182c;position:sticky;top:0;z-index:2}h1{font-size:21px;margin:0 0 5px}.sub{color:#aab3ca;font-size:13px}.wrap{max-width:1100px;margin:auto;padding:14px}.grid{display:grid;grid-template-columns:1fr 1.35fr;gap:14px}.card{background:#121a30;border:1px solid #29304a;border-radius:18px;padding:15px;box-shadow:0 8px 30px #0003}.hero{display:grid;grid-template-columns:1fr 1fr;gap:10px}.stat{background:#0d1427;border-radius:14px;padding:13px}.label{font-size:12px;color:#9da8c2}.value{font-size:20px;font-weight:700;margin-top:4px}.good{color:#8ee6bd}.warn{color:#ffd27d}.bad{color:#ff9d9d}.row{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:10px 0;border-bottom:1px solid #242c43}.row:last-child{border:0}.pill{padding:5px 9px;border-radius:999px;background:#222b46;font-size:12px}.chartbox{display:flex;justify-content:center;align-items:center}.chart{width:min(86vw,620px);height:auto;aspect-ratio:1}.planet{font-size:18px}.small{font-size:12px;color:#9da8c2}.controls{display:flex;gap:8px;margin-bottom:10px}.btn{border:1px solid #39445f;background:#1a243d;color:#fff;padding:9px 13px;border-radius:10px;cursor:pointer}.btn.active{background:#34456f}.legend{display:flex;gap:12px;flex-wrap:wrap;font-size:12px;color:#b7c0d5;margin-top:8px}.note{font-size:12px;color:#9da8c2;line-height:1.7}.table{width:100%;border-collapse:collapse;font-size:13px}.table td,.table th{padding:8px;border-bottom:1px solid #242c43;text-align:right}.footer{color:#7f8aa4;font-size:11px;padding:12px 2px}@media(max-width:800px){.grid{grid-template-columns:1fr}.hero{grid-template-columns:1fr 1fr}}
</style></head><body><header><h1>المحلل الفلكي الشامل — السماء الحية</h1><div class="sub">الأهواز، إيران • التوقيت المحلي • تحديث مباشر</div></header><main class="wrap"><div class="controls"><button id="live" class="btn active">الآن</button><button id="freeze" class="btn">تثبيت</button><span id="status" class="small" style="align-self:center"></span></div><div class="grid"><section><div class="card"><div class="hero"><div class="stat"><div class="label">الطالع الآن</div><div id="asc" class="value">—</div><div id="ascruler" class="small">—</div></div><div class="stat"><div class="label">الساعة المحلية</div><div id="clock" class="value">—</div><div id="date" class="small">—</div></div><div class="stat"><div class="label">القمر</div><div id="moon" class="value">—</div><div id="moonstate" class="small">—</div></div><div class="stat"><div class="label">الحالة الخاصة</div><div id="special" class="value">—</div><div id="special2" class="small">—</div></div></div></div><div class="card" style="margin-top:14px"><h3 style="margin-top:0">الساعة الفلكية</h3><div class="row"><span>الساعة الحالية</span><b id="phour">—</b></div><div class="row"><span>حاكم الساعة</span><b id="phourruler">—</b></div><div class="row"><span>البداية</span><b id="phourstart">—</b></div><div class="row"><span>النهاية</span><b id="phourend">—</b></div><div class="row"><span>الشروق / الغروب</span><b id="suninfo">—</b></div></div></div><div class="card" style="margin-top:14px"><h3 style="margin-top:0">الكواكب المتراجعة الآن</h3><div id="retro"></div><p class="note">℞ تعني أن الحركة الظاهرية للكوكب متراجعة بالنسبة إلى الأرض، وفق الحساب الفلكي المستخدم في المحرك.</p></div><div class="card" style="margin-top:14px"><h3 style="margin-top:0">دلالة القمر</h3><div id="moonpanel"></div></div></section><section class="card"><div class="chartbox"><canvas id="chart" class="chart" width="700" height="700"></canvas></div><div class="legend"><span>خط أحمر = الطالع</span><span>خط علوي = MC</span><span>℞ = تراجع</span></div></section></div><div class="card" style="margin-top:14px"><h3 style="margin-top:0">مواضع الكواكب</h3><div style="overflow:auto"><table class="table"><thead><tr><th>الكوكب</th><th>البرج</th><th>الدرجة</th><th>البيت</th><th>الحركة</th></tr></thead><tbody id="planets"></tbody></table></div></div><div class="footer">هذه الأداة للقراءة الفلكية التقليدية/التفسيرية وليست أداة علمية للتنبؤ. إحداثيات الأهواز المستخدمة: 31.329791°N، 48.724014°E.</div></main>
<script>
let frozen=false,last=null, timer=null; const S=['الحمل','الثور','الجوزاء','السرطان','الأسد','العذراء','الميزان','العقرب','القوس','الجدي','الدلو','الحوت'], SS=['♈','♉','♊','♋','♌','♍','♎','♏','♐','♑','♒','♓'];
function fdeg(d){let s=d.toFixed(2);return s+'°'}
function api(){if(frozen)return; fetch('/api/chart').then(r=>r.json()).then(d=>{last=d;render(d)}).catch(e=>status.textContent='تعذر التحديث')}
function render(d){clock.textContent=d.local_display.split(' ')[1];date.textContent=d.local_display.split(' ')[0]+' • '+d.city;let ph=d.planetary_hour;phour.textContent=`${ph.period} رقم ${ph.number} من 12`;phourruler.textContent=ph.ruler;phourstart.textContent=new Date(ph.start).toLocaleTimeString('ar-AE',{hour12:false});phourend.textContent=new Date(ph.end).toLocaleTimeString('ar-AE',{hour12:false});suninfo.textContent=new Date(ph.sunrise).toLocaleTimeString('ar-AE',{hour12:false})+' / '+new Date(ph.sunset).toLocaleTimeString('ar-AE',{hour12:false});asc.textContent=`${d.asc.symbol} ${d.asc.sign} ${fdeg(d.asc.degree)}`;ascruler.textContent='حاكم الطالع: '+d.asc.ruler;moon.textContent=`${d.moon.sign_symbol} ${d.moon.sign} ${fdeg(d.moon.degree)}`;moonstate.textContent=`البيت ${d.moon.house} • ${d.moon.retrograde?'متراجع':'مباشر'}`;
let sp=[]; if(d.moon_in_scorpio)sp.push('القمر في العقرب'); if(d.moon.void_of_course)sp.push('القمر خالي المسار'); special.textContent=sp.length?sp.join(' • '):'لا حالة خاصة'; special.className='value '+(sp.length?'warn':'good'); special2.textContent=d.moon.void_of_course?(d.moon.next_applying?'لا اتصال رئيسي قادم قبل الخروج من البرج':'لا اتصال رئيسي قادم'):'يوجد اتصال تطبيقي رئيسي محتمل';
retro.innerHTML=d.retrogrades.length?d.retrogrades.map(x=>`<div class="row"><span class="planet">${x.symbol} ${x.name}</span><span>${x.sign} ${fdeg(x.degree)} <b class="bad">℞</b></span></div>`).join(''):'<div class="small">لا يوجد كوكب تقليدي/حديث متراجع الآن.</div>';
moonpanel.innerHTML=`<div class="row"><span>موقع القمر</span><b>${d.moon.sign_symbol} ${d.moon.sign} ${fdeg(d.moon.degree)}</b></div><div class="row"><span>خالي المسار</span><b class="${d.moon.void_of_course?'warn':'good'}">${d.moon.void_of_course?'نعم':'لا'}</b></div><div class="row"><span>نهاية البرج المقدّرة</span><b>${new Date(d.moon.estimated_sign_end).toLocaleString('ar-AE',{hour12:false})}</b></div>`;
planets.innerHTML=d.planets.map(x=>`<tr><td>${x.symbol} ${x.name}</td><td>${x.sign_symbol} ${x.sign}</td><td>${fdeg(x.degree)}</td><td>${x.house}</td><td class="${x.retrograde?'bad':''}">${x.retrograde?'℞ متراجع':'مباشر'}</td></tr>`).join(''); draw(d); status.textContent='محدّث';}
function draw(d){let c=document.getElementById('chart'),ctx=c.getContext('2d'),w=c.width,h=c.height,cx=w/2,cy=h/2,R=315;ctx.clearRect(0,0,w,h);ctx.fillStyle='#0b1020';ctx.fillRect(0,0,w,h);ctx.strokeStyle='#39445f';ctx.lineWidth=2;ctx.beginPath();ctx.arc(cx,cy,R,0,Math.PI*2);ctx.stroke();ctx.lineWidth=1;ctx.strokeStyle='#29304a';
for(let i=0;i<12;i++){let a=(i*30-d.asc.longitude)*Math.PI/180-Math.PI/2;ctx.beginPath();ctx.moveTo(cx,cy);ctx.lineTo(cx+R*Math.cos(a),cy+R*Math.sin(a));ctx.stroke();let mid=a+15*Math.PI/180;ctx.fillStyle='#b9c3db';ctx.font='20px sans-serif';ctx.textAlign='center';ctx.fillText(SS[i],cx+(R-24)*Math.cos(mid),cy+(R-24)*Math.sin(mid));}
// ascendant and MC
for(const [lon,color,width] of [[d.asc.longitude,'#ff7070',4],[d.mc.longitude,'#ffd36b',3]]){let a=(lon-d.asc.longitude)*Math.PI/180-Math.PI/2;ctx.strokeStyle=color;ctx.lineWidth=width;ctx.beginPath();ctx.moveTo(cx,cy);ctx.lineTo(cx+R*Math.cos(a),cy+R*Math.sin(a));ctx.stroke();}
let inner=190;ctx.strokeStyle='#29304a';ctx.beginPath();ctx.arc(cx,cy,inner,0,Math.PI*2);ctx.stroke();
let positions={}; d.planets.forEach((p,i)=>{let a=(p.longitude-d.asc.longitude)*Math.PI/180-Math.PI/2;let rr=inner-15-(i%2)*30;let x=cx+rr*Math.cos(a),y=cy+rr*Math.sin(a);positions[p.id]=[x,y];ctx.fillStyle=p.retrograde?'#ff9d9d':'#eef2ff';ctx.font='22px sans-serif';ctx.textAlign='center';ctx.fillText(p.symbol+(p.retrograde?'℞':''),x,y);});
// aspects between traditional planets
ctx.globalAlpha=.28; d.aspects.forEach(a=>{let p1=d.planets.find(p=>p.id===a.a),p2=d.planets.find(p=>p.id===a.b);if(!p1||!p2)return;let q1=positions[p1.id],q2=positions[p2.id];ctx.strokeStyle='#8ea0c7';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(q1[0],q1[1]);ctx.lineTo(q2[0],q2[1]);ctx.stroke()});ctx.globalAlpha=1;
ctx.fillStyle='#eef2ff';ctx.font='bold 18px sans-serif';ctx.fillText('الأهواز',cx,cy-8);ctx.font='13px sans-serif';ctx.fillStyle='#9da8c2';ctx.fillText('الخريطة الحية',cx,cy+16);}
setInterval(api,15000); api(); live.onclick=()=>{frozen=false;live.classList.add('active');freeze.classList.remove('active');api()}; freeze.onclick=()=>{frozen=!frozen;freeze.classList.toggle('active',frozen);live.classList.toggle('active',!frozen);status.textContent=frozen?'الخريطة مثبتة':'محدّث'};
</script></body></html>'''

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        p=urlparse(self.path).path
        if p=='/api/chart':
            now=datetime.now(TZ); data=calc(now); raw=json.dumps(data,ensure_ascii=False).encode('utf-8'); self.send_response(200); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Cache-Control','no-store'); self.end_headers(); self.wfile.write(raw); return
        if p=='/':
            raw=HTML.encode('utf-8'); self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(raw))); self.end_headers(); self.wfile.write(raw); return
        self.send_error(404)
    def log_message(self,*args): pass

if __name__=='__main__':
    print(f'افتح http://{HOST}:{PORT}')
    HTTPServer((HOST,PORT),Handler).serve_forever()
