package com.dadajuice.shop

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * دادا جوس شاپ — MainActivity (Kotlin)
 * WebView کے اندر Barcode Scanner اور Camera اجازت (onPermissionRequest) کو ہینڈل کرنے کا مکمل کوڈ
 */
class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var pendingPermissionRequest: PermissionRequest? = null
    private val CAMERA_REQUEST_CODE = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        configureWebView()

        // ایپ لوڈ کریں (لوکل ایساٹ یا لائیو سرور)
        // اگر لوکل HTML استعمال ہو رہا ہو:
        // webView.loadUrl("file:///android_asset/index.html")
        // یا آن لائن / PWA سرور:
        webView.loadUrl("https://ais-dev-pwcvmh5mmhxylbzcif3ebn-351295992140.asia-southeast1.run.app")
    }

    private fun configureWebView() {
        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.cacheMode = WebSettings.LOAD_DEFAULT

        webView.webViewClient = WebViewClient()

        // کیمرہ پرمیشن کے لیے WebChromeClient
        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest?) {
                if (request == null) return

                val requestedResources = request.resources
                var needsCamera = false
                for (res in requestedResources) {
                    if (res == PermissionRequest.RESOURCE_VIDEO_CAPTURE) {
                        needsCamera = true
                        break
                    }
                }

                if (needsCamera) {
                    // چیک کریں کہ کیا اینڈرائیڈ سسٹم کیمرہ اجازت مل چکی ہے
                    if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA)
                        == PackageManager.PERMISSION_GRANTED
                    ) {
                        // فوری اجازت دیں
                        request.grant(request.resources)
                    } else {
                        // رن ٹائم پر صارف سے اجازت مانگیں
                        pendingPermissionRequest = request
                        ActivityCompat.requestPermissions(
                            this@MainActivity,
                            arrayOf(Manifest.permission.CAMERA),
                            CAMERA_REQUEST_CODE
                        )
                    }
                } else {
                    request.grant(request.resources)
                }
            }

            override fun onPermissionRequestCanceled(request: PermissionRequest?) {
                super.onPermissionRequestCanceled(request)
                pendingPermissionRequest = null
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // کیمرہ اجازت مل گئی — WebView ریکوئسٹ گرانٹ کریں
                pendingPermissionRequest?.grant(pendingPermissionRequest?.resources)
                Toast.makeText(this, "کیمرہ اجازت فعال ہو گئی", Toast.LENGTH_SHORT).show()
            } else {
                // کیمرہ اجازت مسترد ہو گئی
                pendingPermissionRequest?.deny()
                Toast.makeText(this, "بارکوڈ اسکین کے لیے کیمرہ اجازت درکار ہے", Toast.LENGTH_LONG).show()
            }
            pendingPermissionRequest = null
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
