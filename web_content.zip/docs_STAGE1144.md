# CPLS V2 — Stage 1144

## Recent Sample Cadence Stabilization
- Cadence analysis now focuses on the most recent valid samples instead of mixing a long historical window with the live boundary.
- Invalid/future samples are excluded from cadence calculations.
- Duplicate/near-zero intervals are ignored when evaluating live cadence.
- The UI reports an unstable sampling rhythm and its observed interval range without fabricating data.
- Preserves gap, freshness, sample-count, candle integrity/merge, live continuity and chart interaction behavior.

Source ZIP stage only; APK build not performed.
