// سرور واسط «هوش مصنوعی همیار» — بدون وابستگی خارجی (Node.js 18 یا بالاتر)
// کلید API فقط در متغیر محیطی همین سرور نگه‌داری می‌شود و هرگز به اپلیکیشن نمی‌رسد.
import http from 'node:http';

const PORT = Number(process.env.PORT || 8787);
const API_KEY = process.env.ANTHROPIC_API_KEY || '';
const MODEL = process.env.MODEL || 'claude-sonnet-5-5';
const BASE = (process.env.ANTHROPIC_BASE_URL || 'https://api.anthropic.com').replace(/\/+$/, '');
const ORIGIN = process.env.ALLOWED_ORIGIN || '*'; // برای انتشار واقعی، نشانی دقیق اپ را بگذار
const MAX_BODY = Number(process.env.MAX_BODY_BYTES || 4_000_000);
const RATE = Number(process.env.RATE_LIMIT_PER_MIN || 20);

const MODES = {
  ask: 'به پرسش دانش‌آموز پاسخ بده.',
  solve: 'مسئله را مرحله‌به‌مرحله و با توضیح هر مرحله حل کن و در پایان پاسخ نهایی را بنویس.',
  explain: 'درس یا مفهوم را بسیار ساده و متناسب با سن دانش‌آموز توضیح بده.',
  example: 'مفهوم را با چند مثال حل‌شده و متنوع آموزش بده.',
  summary: 'درس را در قالب خلاصه منظم با نکات مهم و جمع‌بندی بنویس.',
  questions: 'چند نمونه سؤال متنوع (با ذکر سطح دشواری) همراه با پاسخ و توضیح بنویس.',
  exam: 'فقط و فقط یک آرایه JSON معتبر برگردان (بدون هیچ متن دیگر و بدون بلوک کد) از ۵ تا ۱۰ سؤال با این ساختار: {"type":"mcq","q":"...","options":["...","...","...","..."],"answer":0,"explain":"...","level":1} — برای درست/نادرست: {"type":"tf","q":"...","answer":true,"explain":"...","level":2} — برای جای‌خالی یا تشریحی: {"type":"blank"|"essay","q":"...","answer":"...","explain":"...","level":3}. answer در mcq اندیس گزینه درست از صفر است و level عددی بین ۱ تا ۳ است.',
  check: 'پاسخ دانش‌آموز را بررسی کن: درست یا نادرست بودن هر بخش را بگو، اشتباه‌ها را توضیح بده و پاسخ درست را مرحله‌به‌مرحله بنویس.'
};

function systemPrompt(mode, ctx) {
  const where = [ctx.grade, ctx.field, ctx.subject].filter(Boolean).join(' - ') || 'نامشخص';
  return [
    'تو «هوش مصنوعی همیار»، دستیار آموزشی برنامه «همیار هوشمند» برای دانش‌آموزان ایرانی هستی. همیشه به فارسی ساده و مناسب سن دانش‌آموز پاسخ بده.',
    `پایه/رشته/درس انتخاب‌شده: ${where}. پاسخ‌ها را متناسب با کتاب‌های رسمی درسی آموزش‌وپرورش ایران در همین سطح بنویس.`,
    'اگر از چیزی مطمئن نیستی، صریحاً بگو «مطمئن نیستم» و دانش‌آموز را به کتاب درسی یا معلم ارجاع بده. شماره صفحه، عین جمله کتاب یا منبع را هرگز نساز.',
    'اگر عکس سؤال ناخوانا بود، بگو و از دانش‌آموز بخواه واضح‌تر بفرستد.',
    'مخاطب ممکن است کودک یا نوجوان باشد: پاسخ‌ها باید امن، محترمانه و متناسب با سن باشند؛ محتوای جنسی صریح، راهنمایی آسیب‌زا، خشونت‌آمیز یا خطرناک ارائه نکن.',
    'اطلاعات هویتی، نشانی، شماره تماس، رمز عبور یا اطلاعات خصوصی دانش‌آموز را درخواست نکن؛ اگر کاربر چنین اطلاعاتی فرستاد، از بازنشر غیرضروری آن خودداری کن.',
    'وظیفه این پیام: ' + (MODES[mode] || MODES.ask)
  ].join('\n');
}

const hits = new Map();
function limited(ip) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < 60_000);
  arr.push(now);
  hits.set(ip, arr);
  return arr.length > RATE;
}

function send(res, code, obj) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Access-Control-Allow-Origin': ORIGIN, 'Access-Control-Allow-Headers': 'Content-Type', 'Access-Control-Allow-Methods': 'GET,POST,OPTIONS' });
  res.end(JSON.stringify(obj));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    let tooLarge = false;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > MAX_BODY) { tooLarge = true; chunks.length = 0; return; }
      if (!tooLarge) chunks.push(c);
    });
    req.on('end', () => tooLarge ? reject(new Error('too_large')) : resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

export function validate(b) {
  if (!b || typeof b !== 'object') return 'درخواست نامعتبر است.';
  if (!Array.isArray(b.messages) || b.messages.length === 0 || b.messages.length > 30) return 'پیام‌ها نامعتبر است.';
  for (const m of b.messages) {
    if (!['user', 'assistant'].includes(m?.role) || typeof m?.text !== 'string' || m.text.length > 8000) return 'پیام‌ها نامعتبر است.';
  }
  if (b.messages[b.messages.length - 1].role !== 'user') return 'آخرین پیام باید از دانش‌آموز باشد.';
  if (b.image && (typeof b.image.data !== 'string' || !['image/jpeg', 'image/png', 'image/webp'].includes(b.image.mediaType))) return 'تصویر نامعتبر است.';
  return '';
}

export function buildPayload(b) {
  const ctx = { grade: String(b.context?.grade || '').slice(0, 60), field: String(b.context?.field || '').slice(0, 60), subject: String(b.context?.subject || '').slice(0, 80) };
  const msgs = b.messages.map((m) => ({ role: m.role, content: m.text }));
  if (b.image) {
    const last = msgs[msgs.length - 1];
    last.content = [{ type: 'image', source: { type: 'base64', media_type: b.image.mediaType, data: b.image.data } }, { type: 'text', text: last.content }];
  }
  return { model: MODEL, max_tokens: 2000, system: systemPrompt(b.mode, ctx), messages: msgs };
}

export const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') return send(res, 204, {});
  const url = new URL(req.url, 'http://x');
  if (url.pathname === '/health') return send(res, 200, { ok: true, configured: !!API_KEY });
  if (url.pathname !== '/api/chat' || req.method !== 'POST') return send(res, 404, { error: 'یافت نشد.' });
  const ip = req.headers['x-forwarded-for']?.toString().split(',')[0].trim() || req.socket.remoteAddress || 'x';
  if (limited(ip)) return send(res, 429, { error: 'تعداد درخواست‌ها زیاد است؛ کمی بعد دوباره تلاش کن.' });
  if (!API_KEY) return send(res, 503, { error: 'کلید API روی سرور تنظیم نشده است.' });
  try {
    const body = JSON.parse(await readBody(req));
    const bad = validate(body);
    if (bad) return send(res, 400, { error: bad });
    const r = await fetch(BASE + '/v1/messages', { method: 'POST', headers: { 'content-type': 'application/json', 'x-api-key': API_KEY, 'anthropic-version': '2023-06-01' }, body: JSON.stringify(buildPayload(body)) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) return send(res, 502, { error: 'سرویس هوش مصنوعی خطا داد.' });
    const text = (j.content || []).filter((c) => c.type === 'text').map((c) => c.text).join('\n').trim();
    if (!text) return send(res, 502, { error: 'پاسخ خالی دریافت شد.' });
    return send(res, 200, { reply: text });
  } catch (e) {
    if (e?.message === 'too_large') return send(res, 413, { error: 'حجم درخواست زیاد است.' });
    return send(res, 400, { error: 'درخواست نامعتبر است.' });
  }
});

if (import.meta.url === `file://${process.argv[1]}`) {
  server.listen(PORT, () => console.log(`Hamyar AI proxy on :${PORT} (key ${API_KEY ? 'set' : 'MISSING'}, model ${MODEL})`));
}
