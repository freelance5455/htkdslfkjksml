// آزمون خودکار سرور واسط با یک سرویس بالادستی ساختگی (بدون اینترنت)
import http from 'node:http';
import assert from 'node:assert/strict';

const seen = [];
const up = http.createServer((req, res) => {
  let b = '';
  req.on('data', (c) => (b += c));
  req.on('end', () => { seen.push({ headers: req.headers, body: JSON.parse(b) }); res.setHeader('content-type', 'application/json'); res.end(JSON.stringify({ content: [{ type: 'text', text: 'پاسخ آزمایشی' }] })); });
});
await new Promise((r) => up.listen(0, r));
process.env.ANTHROPIC_BASE_URL = `http://127.0.0.1:${up.address().port}`;
process.env.ANTHROPIC_API_KEY = 'test-key';
process.env.RATE_LIMIT_PER_MIN = '5';
const { server } = await import('./server.mjs');
await new Promise((r) => server.listen(0, r));
const base = `http://127.0.0.1:${server.address().port}`;
const post = (b) => fetch(base + '/api/chat', { method: 'POST', body: JSON.stringify(b) });

let r = await (await fetch(base + '/health')).json();
assert.equal(r.ok, true); assert.equal(r.configured, true);

r = await post({ mode: 'solve', context: { grade: 'نهم متوسطه اول', subject: 'ریاضی نهم' }, messages: [{ role: 'user', text: 'x+2=5' }] });
assert.equal(r.status, 200); assert.equal((await r.json()).reply, 'پاسخ آزمایشی');
assert.equal(seen[0].headers['x-api-key'], 'test-key');
assert.ok(seen[0].body.system.includes('نهم متوسطه اول'));

r = await post({ mode: 'ask', messages: [{ role: 'user', text: 'عکس' }], image: { mediaType: 'image/jpeg', data: 'AAAA' } });
assert.equal(r.status, 200);
assert.equal(seen[1].body.messages[0].content[0].type, 'image');

r = await post({ messages: [] }); assert.equal(r.status, 400);
r = await post({ messages: [{ role: 'assistant', text: 'x' }] }); assert.equal(r.status, 400);
r = await post({ messages: [{ role: 'user', text: 'a' }], image: { mediaType: 'text/html', data: 'x' } }); assert.equal(r.status, 400);
r = await fetch(base + '/nope'); assert.equal(r.status, 404);
for (let i = 0; i < 6; i++) r = await post({ messages: [{ role: 'user', text: 'a' }] });
assert.equal(r.status, 429);
console.log('server tests passed');
server.close(); up.close();
