import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'ir.hamyar.hooshmand',
  appName: 'همیار هوشمند',
  webDir: 'dist'
};

export default config;
