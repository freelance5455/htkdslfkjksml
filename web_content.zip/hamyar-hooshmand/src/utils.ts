export const fa = (n: number | string) => String(n).replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[+d]);

export const toEn = (s: string) =>
  s
    .replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
    .replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)));

export const shuffle = <T,>(a: T[]): T[] => {
  const b = [...a];
  for (let i = b.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [b[i], b[j]] = [b[j], b[i]];
  }
  return b;
};

export const rand = (a: number, b: number) => a + Math.floor(Math.random() * (b - a + 1));
export const uid = () => Math.random().toString(36).slice(2, 10);

export const fmtTime = (sec: number) => {
  const s = Math.max(0, sec);
  return fa(String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'));
};

/* ---------- تقویم شمسی ---------- */
export const JMONTHS = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
export const WEEK = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه'];

const pad = (n: number) => String(n).padStart(2, '0');
export const toISO = (d: Date) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
export const todayISO = () => toISO(new Date());
export const parseISO = (s: string) => {
  const [y, m, d] = s.split('-').map(Number);
  return new Date(y, m - 1, d);
};
export const addDays = (s: string, n: number) => {
  const d = parseISO(s);
  d.setDate(d.getDate() + n);
  return toISO(d);
};
export const daysUntil = (s: string) => Math.round((parseISO(s).getTime() - parseISO(todayISO()).getTime()) / 86400000);
export const weekdayFa = (s: string) => WEEK[(parseISO(s).getDay() + 1) % 7];

const jfmt = new Intl.DateTimeFormat('fa-IR-u-ca-persian-nu-latn', { year: 'numeric', month: 'numeric', day: 'numeric' });
export function toJalali(s: string): { jy: number; jm: number; jd: number } {
  const p = jfmt.formatToParts(parseISO(s));
  const g = (t: string) => Number(p.find((x) => x.type === t)?.value ?? 0);
  return { jy: g('year'), jm: g('month'), jd: g('day') };
}
export function fromJalali(jy: number, jm: number, jd: number): string {
  const start = new Date(jy + 621, 2, 19);
  start.setDate(start.getDate() + Math.max(0, (jm - 1) * 30 - 3));
  let last = toISO(start);
  for (let i = 0; i < 50; i++) {
    const iso = addDays(toISO(start), i);
    const j = toJalali(iso);
    if (j.jy === jy && j.jm === jm) {
      last = iso;
      if (j.jd === jd) return iso;
    }
  }
  return last;
}
export const shamsi = (s: string) => {
  const j = toJalali(s);
  return fa(`${j.jd} ${JMONTHS[j.jm - 1]} ${j.jy}`);
};
export const fmtDate = (t: number) => shamsi(toISO(new Date(t)));
