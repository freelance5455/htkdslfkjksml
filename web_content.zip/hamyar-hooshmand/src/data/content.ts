import type { Book, Level, Lesson, Question } from './types';

// سال تحصیلی مرجع محتوا. پیش از انتشار، فهرست‌ها باید با کتاب‌های چاپ جاری تطبیق داده شوند.
export const CONTENT_YEAR = '۱۴۰۵–۱۴۰۶';

const SRC = `تألیفی «همیار هوشمند»، مطابق سرفصل کتاب رسمی (سال تحصیلی ${CONTENT_YEAR}) — پیش از انتشار با کتاب چاپ جاری تطبیق داده شود`;

const mathL1: Lesson = {
  id: 'g9-math-l1',
  title: 'مفهوم مجموعه و نمایش آن',
  content: {
    explain: [
      'مجموعه گروهی از اشیا یا عددهاست که به‌خوبی تعریف شده باشد؛ یعنی درباره هر چیز بتوانیم بگوییم عضو آن هست یا نیست.',
      'اگر a عضو مجموعه A باشد می‌نویسیم a ∈ A و اگر عضو نباشد می‌نویسیم a ∉ A.',
      'یک مجموعه را می‌توان با نوشتن اعضا داخل آکولاد نشان داد، مثل {۱، ۲، ۳}، یا با بیان ویژگی مشترک اعضا، مثل {x | x عدد طبیعی کوچک‌تر از ۴}.',
      'مجموعه‌ای که هیچ عضوی ندارد «مجموعه تهی» نام دارد و با { } یا ∅ نشان داده می‌شود.'
    ],
    steps: [
      'ابتدا مشخص کن اعضای مجموعه چه ویژگی‌ای دارند.',
      'اعضا را بدون تکرار داخل آکولاد بنویس؛ ترتیب نوشتن مهم نیست.',
      'برای بررسی عضویت، عدد یا شیء موردنظر را با اعضای مجموعه مقایسه کن و ∈ یا ∉ بگذار.',
      'برای شمردن اعضا، فقط اعضای متفاوت را بشمار.'
    ],
    examples: [
      { q: 'اگر A = {۱، ۲، ۳، ۴} باشد، رابطه عضویت ۳ و ۷ را با A بنویس.', a: '۳ ∈ A چون در مجموعه است و ۷ ∉ A چون در مجموعه نیست.' },
      { q: 'مجموعه اعداد اول کوچک‌تر از ۱۰ را با نوشتن اعضا نشان بده.', a: '{۲، ۳، ۵، ۷}' }
    ],
    tips: [
      'در یک مجموعه، عضو تکراری شمرده نمی‌شود: {۱، ۲، ۲، ۳} سه عضو دارد.',
      '{ } (تهی) با {۰} فرق دارد؛ {۰} یک عضو دارد.',
      'اعداد طبیعی از ۱ شروع می‌شوند.'
    ],
    summary: [
      'مجموعه = گروه خوش‌تعریف از اعضا.',
      '∈ یعنی عضو است، ∉ یعنی عضو نیست.',
      'مجموعه تهی عضوی ندارد.',
      'اعضای تکراری یک بار شمرده می‌شوند.'
    ],
    exercises: [
      { type: 'mcq', q: 'مجموعه اعداد طبیعی کوچک‌تر از ۱ کدام است؟', options: ['{۰}', '{ }', '{۱}', '{∅}'], answer: 1, explain: 'اعداد طبیعی از ۱ شروع می‌شوند، پس عددی کوچک‌تر از ۱ در آن‌ها نیست و مجموعه تهی است.' },
      { type: 'mcq', q: 'علامت ∈ چه معنایی دارد؟', options: ['عضو است', 'زیرمجموعه است', 'اجتماع', 'تهی'], answer: 0, explain: '∈ یعنی «عضو است».' },
      { type: 'mcq', q: 'اگر B = {x | x عدد اول و x < ۱۰} باشد، B کدام است؟', options: ['{۲، ۳، ۵، ۷}', '{۱، ۲، ۳، ۵، ۷}', '{۳، ۵، ۷}', '{۲، ۳، ۵، ۷، ۹}'], answer: 0, explain: '۱ عدد اول نیست و ۹ = ۳×۳ اول نیست؛ اعداد اول کمتر از ۱۰ عبارت‌اند از ۲، ۳، ۵ و ۷.' },
      { type: 'tf', q: 'مجموعه {۱، ۲، ۲، ۳} چهار عضو دارد.', answer: false, explain: 'عضو تکراری شمرده نمی‌شود؛ مجموعه سه عضو (۱، ۲، ۳) دارد.' },
      { type: 'blank', q: 'اگر A = {۲، ۴، ۶} باشد، تعداد اعضای A برابر ___ است.', answer: '3', explain: 'اعضا ۲، ۴ و ۶ هستند؛ یعنی سه عضو.' }
    ],
    source: SRC
  }
};

const mathL2: Lesson = {
  id: 'g9-math-l2',
  title: 'عددهای گویا و گنگ',
  content: {
    explain: [
      'عدد گویا عددی است که بتوان آن را به صورت a/b نوشت که a و b صحیح و b ≠ ۰ باشد.',
      'عددهای اعشاری متناهی (مثل ۰٫۲۵) و اعشاری متناوب (مثل ۰٫۳۳۳…) گویا هستند.',
      'عدد گنگ عددی است که نتوان آن را به صورت کسر نوشت؛ نمایش اعشاری آن نامتناهی و غیرمتناوب است، مثل √۲ و π.',
      'اجتماع عددهای گویا و گنگ، مجموعه عددهای حقیقی را می‌سازد.'
    ],
    steps: [
      'ببین آیا عدد را می‌توان به صورت کسر نوشت (مثلاً با ساده‌کردن رادیکال).',
      'اگر رادیکال عددی مربع کامل بود (مثل √۹ = ۳) عدد گویاست.',
      'اگر رادیکال مربع کامل نبود (مثل √۲) عدد گنگ است.'
    ],
    examples: [
      { q: '۰٫۲۵ گویاست یا گنگ؟', a: 'گویا؛ زیرا ۰٫۲۵ = ۱/۴.' },
      { q: '√۱۶ گویاست یا گنگ؟', a: 'گویا؛ زیرا √۱۶ = ۴ = ۴/۱.' }
    ],
    tips: ['هر عدد صحیح گویاست.', 'جذر عدد غیرمربع کامل گنگ است.'],
    summary: ['گویا = قابل‌نوشتن به صورت کسر.', 'گنگ = اعشاری نامتناهی و نامتناوب.', 'حقیقی = گویا ∪ گنگ.'],
    exercises: [
      { type: 'mcq', q: 'کدام عدد گنگ است؟', options: ['۰٫۲۵', '√۴', '√۲', '۱/۳'], answer: 2, explain: '√۲ مربع کامل نیست و اعشار آن نامتناهی و نامتناوب است.' },
      { type: 'mcq', q: 'مجموعه عددهای حقیقی اجتماع کدام دو مجموعه است؟', options: ['صحیح و طبیعی', 'گویا و گنگ', 'زوج و فرد', 'اول و مرکب'], answer: 1, explain: 'عددهای حقیقی از اجتماع عددهای گویا و گنگ ساخته می‌شود.' },
      { type: 'tf', q: 'عدد ۰٫۳۳۳… (۳ تکرارشونده) گویاست.', answer: true, explain: 'اعشار متناوب است و برابر ۱/۳ می‌شود.' },
      { type: 'tf', q: '√۹ عددی گنگ است.', answer: false, explain: '√۹ = ۳ و عدد صحیح، پس گویاست.' },
      { type: 'blank', q: '√۱۶ = ___', answer: '4', explain: '۴ × ۴ = ۱۶ پس جذر ۱۶ برابر ۴ است.' }
    ],
    source: SRC
  }
};

const empty = (id: string, title: string) => ({ id, title, lessons: [] as Lesson[] });

// فهرست فصل‌های ریاضی نهم؛ فقط درس‌های دارای محتوا پر شده‌اند و بقیه «تکمیل‌نشده» نمایش داده می‌شوند.
const STATIC_BOOKS: Book[] = [
  {
    id: 'g9-math', gradeId: 9, title: 'ریاضی نهم', icon: '📐', color: '#2f7be5',
    chapters: [
      { id: 'g9-math-c1', title: 'فصل ۱: مجموعه‌ها', lessons: [mathL1] },
      { id: 'g9-math-c2', title: 'فصل ۲: عددهای حقیقی', lessons: [mathL2] },
      empty('g9-math-c3', 'فصل ۳: استدلال و اثبات در هندسه'),
      empty('g9-math-c4', 'فصل ۴: توان و ریشه'),
      empty('g9-math-c5', 'فصل ۵: عبارت‌های جبری'),
      empty('g9-math-c6', 'فصل ۶: خط و معادله‌های خطی'),
      empty('g9-math-c7', 'فصل ۷: عبارت‌های گویا'),
      empty('g9-math-c8', 'فصل ۸: حجم و مساحت')
    ]
  },
  { id: 'g9-science', gradeId: 9, title: 'علوم تجربی نهم', icon: '🔬', color: '#22a77a', chapters: [] },
  { id: 'g9-farsi', gradeId: 9, title: 'فارسی نهم', icon: '📖', color: '#8a5cf0', chapters: [] },
  { id: 'g9-arabic', gradeId: 9, title: 'عربی نهم', icon: '🕌', color: '#e08a1e', chapters: [] },
  { id: 'g9-english', gradeId: 9, title: 'زبان انگلیسی نهم', icon: '🔤', color: '#e0486a', chapters: [] },
  { id: 'g9-social', gradeId: 9, title: 'مطالعات اجتماعی نهم', icon: '🌍', color: '#2aa6c9', chapters: [] },
  { id: 'g9-quran', gradeId: 9, title: 'آموزش قرآن نهم', icon: '📗', color: '#3d9a4a', chapters: [] },
  { id: 'g9-religion', gradeId: 9, title: 'پیام‌های آسمان نهم', icon: '☪️', color: '#5b6ee1', chapters: [] },
  { id: 'g9-work', gradeId: 9, title: 'کار و فناوری نهم', icon: '🛠️', color: '#c9733a', chapters: [] },
  { id: 'g9-thinking', gradeId: 9, title: 'تفکر و سبک زندگی نهم', icon: '💡', color: '#d1a21d', chapters: [] }
];

// پس از تعریف کتاب‌های ثابت: سال تحصیلی، سطح دشواری و برچسب وضعیت پاسخ‌ها
const ESSAY1: Question = { type: 'essay', q: 'مجموعه اعداد زوج طبیعی کوچک‌تر از ۱۰ را با نوشتن اعضا نشان بده.', answer: '{۲، ۴، ۶، ۸}', explain: 'اعداد طبیعی زوج کمتر از ۱۰ عبارت‌اند از ۲، ۴، ۶ و ۸.', level: 2 };
const ESSAY2: Question = { type: 'essay', q: 'توضیح بده چرا ۰٫۵ عددی گویاست.', answer: 'چون ۰٫۵ = ۵/۱۰ = ۱/۲ است و به صورت کسر دو عدد صحیح با مخرج غیرصفر نوشته می‌شود.', explain: 'هر عدد اعشاری متناهی را می‌توان به کسر تبدیل کرد.', level: 2 };
const LEVELS: Record<string, Level[]> = { 'g9-math-l1': [1, 1, 2, 1, 1], 'g9-math-l2': [1, 1, 1, 1, 1] };
mathL1.content!.exercises.push(ESSAY1);
mathL2.content!.exercises.push(ESSAY2);
for (const l of [mathL1, mathL2]) {
  l.content!.exercises.forEach((q, i) => {
    q.level = q.level ?? LEVELS[l.id][i] ?? 2;
    q.status = q.status ?? 'review'; // تألیفی: پیش از انتشار باید با منبع رسمی تطبیق داده شود
  });
}
STATIC_BOOKS.forEach((b) => {
  b.year = b.year ?? CONTENT_YEAR;
  b.sourceUrl = 'https://chap.sch.ir/';
});

export let BOOKS: Book[] = STATIC_BOOKS;

// ادغام کتاب‌های ثابت با محتوای افزوده‌شده توسط مدیر (کتاب هم‌شناسه، جایگزین کتاب ثابت می‌شود)
export function setCustomBooks(custom: Book[]) {
  BOOKS = [...STATIC_BOOKS.filter((b) => !custom.some((c) => c.id === b.id)), ...custom];
}
export const isStaticBook = (id: string) => STATIC_BOOKS.some((b) => b.id === id);
export const getStaticBook = (id: string) => STATIC_BOOKS.find((b) => b.id === id);

export const findBook = (id: string) => BOOKS.find((b) => b.id === id);

export const allLessons = () =>
  BOOKS.flatMap((b) => b.chapters.flatMap((c) => c.lessons.map((l) => ({ b, c, l }))));

export const findLesson = (id: string) => allLessons().find((x) => x.l.id === id);

export const bookQuestions = (b: Book): Question[] =>
  b.chapters.flatMap((c) => c.lessons.flatMap((l) => l.content?.exercises ?? []));

export const chapterQuestions = (c: { lessons: Lesson[] }): Question[] => c.lessons.flatMap((l) => l.content?.exercises ?? []);
