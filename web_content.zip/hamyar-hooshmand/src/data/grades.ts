import type { Grade } from './types';

const names = ['اول', 'دوم', 'سوم', 'چهارم', 'پنجم', 'ششم', 'هفتم', 'هشتم', 'نهم', 'دهم', 'یازدهم', 'دوازدهم'];

export const GRADES: Grade[] = names.map((n, i) => {
  const id = i + 1;
  const stage = id <= 6 ? 'ابتدایی' : id <= 9 ? 'متوسطه اول' : 'متوسطه دوم';
  return { id, title: `${n} ${stage}`, stage };
});

export const STAGES: Grade['stage'][] = ['ابتدایی', 'متوسطه اول', 'متوسطه دوم'];

export const FIELDS = ['علوم تجربی', 'ریاضی و فیزیک', 'ادبیات و علوم انسانی', 'علوم و معارف اسلامی', 'فنی و حرفه‌ای', 'کاردانش'];
export const TRACK_FIELDS = ['فنی و حرفه‌ای', 'کاردانش'];
export const gradeTitle = (id: number) => GRADES.find((g) => g.id === id)?.title ?? '';
