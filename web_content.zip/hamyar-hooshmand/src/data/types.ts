export interface Grade {
  id: number;
  title: string;
  stage: 'ابتدایی' | 'متوسطه اول' | 'متوسطه دوم';
}

export type Level = 1 | 2 | 3; // ۱ آسان، ۲ متوسط، ۳ سخت
export interface QMeta {
  explain: string;
  level?: Level;
  // verified = پاسخ با منبع رسمی تطبیق داده شده؛ review = نیازمند بررسی
  status?: 'verified' | 'review';
}

export type Question =
  | ({ type: 'mcq'; q: string; options: string[]; answer: number } & QMeta)
  | ({ type: 'tf'; q: string; answer: boolean } & QMeta)
  | ({ type: 'blank'; q: string; answer: string } & QMeta)
  | ({ type: 'essay'; q: string; answer: string } & QMeta);

export interface LessonContent {
  explain: string[];
  steps: string[];
  examples: { q: string; a: string }[];
  tips: string[];
  summary: string[];
  exercises: Question[];
  source: string;
}

export interface Lesson {
  id: string;
  title: string;
  content?: LessonContent;
}

export interface Chapter {
  id: string;
  title: string;
  lessons: Lesson[];
}

export interface Book {
  id: string;
  gradeId: number;
  title: string;
  icon: string;
  color: string;
  chapters: Chapter[];
  field?: string; // خالی = مشترک بین همه رشته‌ها
  track?: string; // زمینه/گروه/رشته برای فنی‌وحرفه‌ای و کاردانش
  year?: string; // سال تحصیلی
  cover?: string; // تصویر جلد (data URI)
  pdfUrl?: string; // پیوند PDF مجاز
  hasPdf?: boolean; // فایل PDF ذخیره‌شده در دستگاه
  sourceUrl?: string; // منبع رسمی
  archived?: boolean; // آرشیو (نسخه‌های قدیمی)
  custom?: boolean;
}

export type ExamKind = 'term1' | 'term2' | 'final' | 'chapter' | 'comprehensive' | 'custom';
export const EXAM_KINDS: Record<ExamKind, string> = {
  term1: 'امتحان نوبت اول',
  term2: 'امتحان نوبت دوم',
  final: 'نمونه امتحان نهایی',
  chapter: 'آزمون پایان فصل',
  comprehensive: 'آزمون جامع',
  custom: 'آزمون دلخواه'
};

export interface CustomExam {
  id: string;
  title: string;
  kind: ExamKind;
  gradeId?: number;
  field?: string;
  bookId?: string;
  minutes: number;
  questions: Question[];
  source: string;
  ai?: boolean;
}

export interface Track {
  id: string;
  gradeId: number;
  field: string;
  group: string;
  name: string;
}

export interface BookVersion {
  id: string;
  bookId: string;
  year: string;
  note: string;
  url: string;
  t: number;
}

export interface Custom {
  books: Book[];
  tracks: Track[];
  exams: CustomExam[];
  versions: BookVersion[];
  admin?: { salt: string; hash: string };
}

export const emptyCustom: Custom = { books: [], tracks: [], exams: [], versions: [] };
