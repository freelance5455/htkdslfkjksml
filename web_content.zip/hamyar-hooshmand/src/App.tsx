import { useCallback, useEffect, useRef, useState } from 'react';
import { AppCtx, AppState, defaultState, useApp } from './state';
import { kvGet, kvSet } from './db';
import { GRADES, STAGES } from './data/grades';
import { BOOKS, allLessons, findBook, findLesson, setCustomBooks } from './data/content';
import { Custom, emptyCustom } from './data/types';
import Quiz from './components/Quiz';
import { ALL_GAMES, CATS, medalOf } from './components/gameList';
import type { Cat } from './components/games';
import { APP } from './appinfo';
import { daysUntil, fa, fmtDate, shamsi, todayISO, weekdayFa } from './utils';
import { go } from './pages/Shared';
import { BookPage, GradePage } from './pages/Library';
import { ExamPage, Exams } from './pages/Exams';
import Answers from './pages/Answers';
import Planner from './pages/Planner';
import Assistant from './pages/Assistant';
import Admin from './pages/Admin';
import About from './pages/About';
import Settings from './pages/Settings';
import Welcome, { Splash } from './pages/Welcome';

const back = () => history.back();

function useRoute(): string[] {
  const read = () => (location.hash.replace(/^#\/?/, '') || '').split('/').filter(Boolean);
  const [r, setR] = useState<string[]>(read);
  useEffect(() => {
    const f = () => {
      setR(read());
      window.scrollTo(0, 0);
    };
    window.addEventListener('hashchange', f);
    return () => window.removeEventListener('hashchange', f);
  }, []);
  return r;
}

/* ---------- صفحه اصلی ---------- */
function Home() {
  const { s } = useApp();
  const [q, setQ] = useState('');
  const term = q.trim();
  const hits = term
    ? [
        ...BOOKS.filter((b) => b.title.includes(term)).map((b) => ({ k: 'b' + b.id, t: `📚 ${b.title}`, to: `/book/${b.id}` })),
        ...allLessons().filter(({ l, c }) => l.title.includes(term) || c.title.includes(term)).map(({ b, l }) => ({ k: l.id, t: `📝 ${l.title} — ${b.title}`, to: `/lesson/${l.id}` }))
      ]
    : [];
  const today = todayISO();
  const todayTasks = s.tasks.filter((t) => t.date === today && !t.done);
  const soonExams = s.planExams.filter((e) => daysUntil(e.date) >= 0 && daysUntil(e.date) <= 14).sort((a, b) => a.date.localeCompare(b.date));
  const g = s.profile.grade;

  const cards = [
    { t: 'کتاب‌های درسی', d: 'پایه‌ها و درس‌ها', c: '#2f7be5', i: '📚', to: g ? '/grade/' + g : '/grades' },
    { t: 'هوش مصنوعی همیار', d: 'پرسش، حل مسئله، آزمون', c: '#8a5cf0', i: '🤖', to: '/assistant' },
    { t: 'آزمون‌ها', d: 'تستی، تشریحی، نمره', c: '#e0a31e', i: '📝', to: '/exams' },
    { t: 'پاسخ‌نامه', d: 'پاسخ و علت درستی', c: '#22a77a', i: '✅', to: '/answers' },
    { t: 'برنامه‌ریزی', d: 'مطالعه، تکلیف، امتحان', c: '#2aa6c9', i: '🗓️', to: '/planner' },
    { t: 'سرگرمی', d: `${fa(ALL_GAMES.length)} بازی آموزشی`, c: '#e0486a', i: '🎮', to: '/games' }
  ];

  return (
    <div>
      <div className="hero">
        <img src="icons/icon-192.png" alt={APP.name} />
        <div>
          <h1>{APP.name}</h1>
          <p>{APP.slogan}</p>
          <small>{weekdayFa(today)} {shamsi(today)}</small>
        </div>
      </div>
      <input className="input" placeholder="🔍 جست‌وجوی سریع کتاب یا درس…" value={q} onChange={(e) => setQ(e.target.value)} />
      {term && (
        <div className="card">
          {hits.length ? hits.map((h) => <button key={h.k} className="list-item" onClick={() => go(h.to)}>{h.t}</button>) : <p className="muted">نتیجه‌ای پیدا نشد.</p>}
        </div>
      )}
      {(soonExams.length > 0 || todayTasks.length > 0) && (
        <div className="card warn-box">
          <b>🔔 یادآوری</b>
          {soonExams.slice(0, 3).map((e) => <div key={e.id}>🎯 {e.title} — {daysUntil(e.date) === 0 ? 'امروز!' : `${fa(daysUntil(e.date))} روز مانده`}</div>)}
          {todayTasks.length > 0 && <button className="list-item" onClick={() => go('/planner')}>📌 {fa(todayTasks.length)} کار برای امروز مانده است</button>}
        </div>
      )}
      <div className="cards">
        {cards.map((c) => (
          <button key={c.t} className="bigcard" style={{ background: c.c }} onClick={() => go(c.to)}>
            <span className="ico">{c.i}</span>
            <b>{c.t}</b>
            <small>{c.d}</small>
          </button>
        ))}
      </div>
      {s.history.length > 0 && (
        <>
          <h3>ادامه مطالعه</h3>
          {s.history.slice(0, 3).map((h) => {
            const f = findLesson(h.id);
            return f ? <button key={h.id + h.t} className="list-item card" onClick={() => go('/lesson/' + h.id)}>📖 {f.l.title} <small className="muted">— {f.b.title}</small></button> : null;
          })}
        </>
      )}
    </div>
  );
}

/* ---------- پایه‌ها ---------- */
function GradesPage() {
  return (
    <div>
      {STAGES.map((st) => (
        <div key={st}>
          <h3>{st}</h3>
          <div className="chips">
            {GRADES.filter((g) => g.stage === st).map((g) => (
              <button key={g.id} className="chip" onClick={() => go('/grade/' + g.id)}>{g.title}</button>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

/* ---------- درس ---------- */
function LessonPage({ id }: { id: string }) {
  const { s, up } = useApp();
  const [tab, setTab] = useState<'learn' | 'notes' | 'practice'>('learn');
  const f = findLesson(id);
  useEffect(() => {
    if (f) up((x) => ({ ...x, history: [{ id, t: Date.now() }, ...x.history.filter((h) => h.id !== id)].slice(0, 50) }));
  }, [id]);
  if (!f) return <p>درس پیدا نشد.</p>;
  const { b, c, l } = f;
  const ct = l.content;
  const marked = s.bookmarks.includes(id);
  return (
    <div>
      <div className="row between">
        <div>
          <h2>{l.title}</h2>
          <small className="muted">{b.title} — {c.title}</small>
        </div>
        <button className="star" onClick={() => up((x) => ({ ...x, bookmarks: marked ? x.bookmarks.filter((i) => i !== id) : [...x.bookmarks, id] }))}>{marked ? '⭐' : '☆'}</button>
      </div>
      {!ct ? (
        <div className="card warn-box">🚧 محتوای این درس هنوز تکمیل نشده است.</div>
      ) : (
        <>
          <div className="tabs">
            <button className={tab === 'learn' ? 'on' : ''} onClick={() => setTab('learn')}>آموزش</button>
            <button className={tab === 'notes' ? 'on' : ''} onClick={() => setTab('notes')}>جزوه</button>
            <button className={tab === 'practice' ? 'on' : ''} onClick={() => setTab('practice')}>تمرین</button>
          </div>

          {tab === 'learn' && (
            <div>
              <div className="card"><h3>توضیح ساده</h3>{ct.explain.map((p, i) => <p key={i}>{fa(p)}</p>)}</div>
              <div className="card"><h3>آموزش مرحله‌به‌مرحله</h3><ol>{ct.steps.map((p, i) => <li key={i}>{fa(p)}</li>)}</ol></div>
              <div className="card"><h3>مثال‌های حل‌شده</h3>{ct.examples.map((e, i) => <div key={i} className="example"><b>{fa(e.q)}</b><p>{fa(e.a)}</p></div>)}</div>
              <div className="card tip"><h3>⚠️ نکات مهم امتحانی</h3><ul>{ct.tips.map((p, i) => <li key={i}>{fa(p)}</li>)}</ul></div>
            </div>
          )}

          {tab === 'notes' && (
            <div>
              <div className="card print-area">
                <h2>جزوه: {l.title}</h2>
                <p className="muted small">{b.title} — {c.title}</p>
                <h3>خلاصه درس</h3>
                <ul>{ct.summary.map((p, i) => <li key={i}>{fa(p)}</li>)}</ul>
                <h3>نکات مهم</h3>
                <ul>{ct.tips.map((p, i) => <li key={i}>{fa(p)}</li>)}</ul>
                <h3>جمع‌بندی شب امتحان</h3>
                <ul>{ct.explain.map((p, i) => <li key={i}>{fa(p)}</li>)}</ul>
                <p className="muted small">منبع: {ct.source}</p>
              </div>
              <button className="btn primary full" onClick={() => window.print()}>🖨️ چاپ / ذخیره PDF</button>
            </div>
          )}

          {tab === 'practice' && (
            <Quiz
              title="تمرین پایان درس"
              questions={ct.exercises}
              onFinish={(sc, tot) => up((x) => ({ ...x, results: [{ id, title: l.title, score: sc, total: tot, t: Date.now() }, ...x.results].slice(0, 100) }))}
            />
          )}
          {tab !== 'notes' && <p className="muted small">منبع محتوا: {ct.source}</p>}
        </>
      )}
    </div>
  );
}


/* ---------- بازی‌ها ---------- */
function Games() {
  const { s } = useApp();
  const [cat, setCat] = useState<Cat | ''>('');
  const list = ALL_GAMES.filter((g) => !cat || g.cat === cat);
  return (
    <div>
      <h2>🎮 سرگرمی و بازی</h2>
      <p className="muted">{fa(ALL_GAMES.length)} بازی — امتیاز، رکورد و مدال هر بازی ذخیره می‌شود.</p>
      <div className="chips">
        <button className={'chip' + (cat === '' ? ' on' : '')} onClick={() => setCat('')}>همه</button>
        {CATS.map((c) => <button key={c} className={'chip' + (cat === c ? ' on' : '')} onClick={() => setCat(c)}>{c}</button>)}
      </div>
      <div className="cards two">
        {list.map((g) => (
          <button key={g.id} className="bigcard" style={{ background: g.color }} onClick={() => go('/game/' + g.id)}>
            <span className="ico">{g.icon}</span>
            <b>{g.title}</b>
            <small>{g.desc}</small>
            <small>{medalOf(g, s.scores[g.id] ?? 0).icon} رکورد: {fa(s.scores[g.id] ?? 0)} · {g.cat}</small>
          </button>
        ))}
      </div>
    </div>
  );
}

function GamePage({ id }: { id: string }) {
  const { s, up } = useApp();
  const g = ALL_GAMES.find((x) => x.id === id);
  const [k, setK] = useState(0);
  const [cur, setCur] = useState(0);
  const [newRec, setNewRec] = useState(false);
  const [help, setHelp] = useState(false);
  const best = useRef(s.scores[id] ?? 0);
  const counted = useRef('');
  // شمارش دفعات بازی (هر ورود و هر شروع مجدد)
  useEffect(() => {
    const key = id + ':' + k;
    if (counted.current === key) return;
    counted.current = key;
    up((x) => ({ ...x, gstats: { ...x.gstats, [id]: { plays: (x.gstats[id]?.plays ?? 0) + 1, last: x.gstats[id]?.last ?? 0, total: x.gstats[id]?.total ?? 0 } } }));
  }, [id, k]);
  if (!g) return <p>بازی پیدا نشد.</p>;

  const report = (sc: number) => {
    setCur(sc);
    if (sc > best.current) {
      best.current = sc;
      setNewRec(true);
    }
    up((x) => ({ ...x, scores: { ...x.scores, [id]: Math.max(x.scores[id] ?? 0, sc) }, gstats: { ...x.gstats, [id]: { plays: x.gstats[id]?.plays ?? 1, last: sc, total: (x.gstats[id]?.total ?? 0) + sc } } }));
  };
  const live = (sc: number) => setCur(sc);
  const restart = () => {
    setK(k + 1);
    setCur(0);
    setNewRec(false);
  };
  const rec = Math.max(best.current, s.scores[id] ?? 0);
  const m = medalOf(g, rec);

  return (
    <div>
      <div className="row between">
        <h2>{g.icon} {g.title}</h2>
        <button className="btn" onClick={restart}>🔄 شروع مجدد</button>
      </div>
      <div className="stats three">
        <div><small>امتیاز</small><b>{fa(cur)}</b></div>
        <div><small>🏅 رکورد</small><b>{fa(rec)}</b></div>
        <div><small>سطح</small><b>{m.icon}</b></div>
      </div>
      <small className="muted">{m.name}{m.next ? ` — تا مدال بعدی: ${fa(Math.max(0, m.next - rec))} امتیاز` : ' — بالاترین مدال'}</small>
      {newRec && <p className="win">🏆 رکورد جدید!</p>}
      <button className="btn full" onClick={() => setHelp(!help)}>{help ? 'بستن راهنما' : '❓ راهنمای بازی'}</button>
      {help && <div className="card">{g.help}</div>}
      <div className="card gamebox"><g.Comp key={k} report={report} live={live} /></div>
    </div>
  );
}

/* ---------- علاقه‌مندی‌ها و پیشرفت ---------- */
function Saved() {
  const { s } = useApp();
  const items = s.bookmarks.map(findLesson).filter(Boolean) as NonNullable<ReturnType<typeof findLesson>>[];
  const favBooks = s.bookFavs.map((id) => findBook(id)).filter(Boolean) as NonNullable<ReturnType<typeof findBook>>[];
  return (
    <div>
      <h2>⭐ علاقه‌مندی‌ها</h2>
      <h3>کتاب‌ها</h3>
      {favBooks.length === 0 && <p className="muted">کتابی نشان نشده است.</p>}
      {favBooks.map((b) => <button key={b.id} className="list-item card" onClick={() => go('/book/' + b.id)}>{b.icon} {b.title}</button>)}
      <h3>درس‌ها</h3>
      {items.length === 0 && <p className="muted">هنوز درسی را نشان نکرده‌ای. در صفحه هر درس روی ستاره بزن.</p>}
      {items.map(({ l, b }) => <button key={l.id} className="list-item card" onClick={() => go('/lesson/' + l.id)}>📝 {l.title} <small className="muted">— {b.title}</small></button>)}
    </div>
  );
}

function Progress() {
  const { s, up } = useApp();
  return (
    <div>
      <h2>📈 پیشرفت من</h2>
      <h3>گزارش نمرات</h3>
      {s.results.length === 0 && <p className="muted">هنوز آزمونی نداده‌ای.</p>}
      {s.results.slice(0, 10).map((r, i) => (
        <div className="card row between" key={i}>
          <span>{r.title}<br /><small className="muted">{fmtDate(r.t)}</small></span>
          <b>{r.total ? fa(Math.round((r.score / r.total) * 2000) / 100) : '—'} / ۲۰</b>
        </div>
      ))}
      <h3>تاریخچه مطالعه</h3>
      {s.history.length === 0 && <p className="muted">هنوز درسی نخوانده‌ای.</p>}
      {s.history.slice(0, 10).map((h) => {
        const f = findLesson(h.id);
        return f ? <button key={h.id} className="list-item card" onClick={() => go('/lesson/' + h.id)}>📖 {f.l.title} <small className="muted">{fmtDate(h.t)}</small></button> : null;
      })}
      <h3>جدول پیشرفت بازی‌ها</h3>
      <div className="card tablewrap">
        <table className="tbl">
          <thead><tr><th>بازی</th><th>دفعات</th><th>آخرین</th><th>رکورد</th><th>سطح</th></tr></thead>
          <tbody>
            {ALL_GAMES.map((g) => {
              const st = s.gstats[g.id];
              return <tr key={g.id}><td>{g.icon} {g.title}</td><td>{fa(st?.plays ?? 0)}</td><td>{fa(st?.last ?? 0)}</td><td>{fa(s.scores[g.id] ?? 0)}</td><td>{medalOf(g, s.scores[g.id] ?? 0).icon}</td></tr>;
            })}
          </tbody>
        </table>
      </div>
      <button className="btn" onClick={() => confirm('همه اطلاعات پیشرفت پاک شود؟') && up((x) => ({ ...defaultState, theme: x.theme, apiUrl: x.apiUrl, profile: x.profile }))}>پاک‌کردن اطلاعات پیشرفت</button>
    </div>
  );
}

function More() {
  const items = [
    ['🤖', 'هوش مصنوعی همیار', '/assistant'], ['🗓️', 'برنامه‌ریزی درسی', '/planner'], ['✅', 'پاسخ‌نامه', '/answers'],
    ['📈', 'پیشرفت من', '/progress'], ['⭐', 'علاقه‌مندی‌ها', '/saved'], ['🎓', 'همه پایه‌ها', '/grades'],
    ['⚙️', 'تنظیمات', '/settings'], ['🔐', 'پنل مدیریت', '/admin'], ['ℹ️', 'درباره ما', '/about']
  ];
  return (
    <div>
      <h2>بیشتر</h2>
      {items.map(([i, t, to]) => <button key={to} className="list-item card" onClick={() => go(to)}>{i} {t}</button>)}
    </div>
  );
}

/* ---------- پوسته برنامه ---------- */
export default function App() {
  const [s, setS] = useState<AppState | null>(null);
  const [custom, setCustom] = useState<Custom>(emptyCustom);
  const [splash, setSplash] = useState(true);
  const ref = useRef<AppState>(defaultState);
  const cref = useRef<Custom>(emptyCustom);
  const route = useRoute();

  useEffect(() => {
    const t = setTimeout(() => setSplash(false), 2300);
    Promise.all([kvGet<AppState>('state').catch(() => undefined), kvGet<Custom>('custom').catch(() => undefined)]).then(([v, c]) => {
      ref.current = { ...defaultState, ...(v ?? {}) };
      cref.current = { ...emptyCustom, ...(c ?? {}) };
      setCustomBooks(cref.current.books);
      setCustom(cref.current);
      setS(ref.current);
    });
    return () => clearTimeout(t);
  }, []);

  const up = useCallback((f: (x: AppState) => AppState) => {
    ref.current = f(ref.current);
    setS(ref.current);
    kvSet('state', ref.current).catch(() => {});
  }, []);

  const upCustom = useCallback((f: (x: Custom) => Custom) => {
    cref.current = f(cref.current);
    setCustomBooks(cref.current.books);
    setCustom(cref.current);
    kvSet('custom', cref.current).catch(() => {});
  }, []);

  useEffect(() => {
    if (s) document.documentElement.dataset.theme = s.theme;
  }, [s?.theme]);

  if (!s || splash) return <Splash />;

  const [a, b] = route;
  let page: JSX.Element;
  switch (a) {
    case 'grades': page = <GradesPage />; break;
    case 'grade': page = <GradePage id={Number(b)} />; break;
    case 'book': page = <BookPage id={b} />; break;
    case 'lesson': page = <LessonPage id={b} />; break;
    case 'exams': page = <Exams />; break;
    case 'exam': page = <ExamPage id={b} />; break;
    case 'answers': page = <Answers />; break;
    case 'planner': page = <Planner />; break;
    case 'assistant': page = <Assistant />; break;
    case 'games': page = <Games />; break;
    case 'game': page = <GamePage id={b} />; break;
    case 'saved': page = <Saved />; break;
    case 'progress': page = <Progress />; break;
    case 'more': page = <More />; break;
    case 'settings': page = <Settings />; break;
    case 'about': page = <About />; break;
    case 'admin': page = <Admin />; break;
    default: page = <Home />;
  }

  const nav = [
    { k: '', i: '🏠', t: 'خانه' },
    { k: 'grades', i: '📚', t: 'کتاب‌ها' },
    { k: 'exams', i: '📝', t: 'آزمون' },
    { k: 'games', i: '🎮', t: 'بازی' },
    { k: 'more', i: '☰', t: 'بیشتر' }
  ];

  return (
    <AppCtx.Provider value={{ s, up, custom, upCustom }}>
      {!s.profile.done ? (
        <Welcome />
      ) : (
        <>
          <header className="top">
            {a ? <button className="icon-btn" aria-label="بازگشت" onClick={back}>➡️</button> : <span className="icon-btn" />}
            <span className="brand"><img className="brandimg" src="icons/icon-192.png" alt="" />{APP.name}</span>
            <button className="icon-btn" aria-label="حالت شب و روز" onClick={() => up((x) => ({ ...x, theme: x.theme === 'dark' ? 'light' : 'dark' }))}>{s.theme === 'dark' ? '☀️' : '🌙'}</button>
          </header>
          <main className="page">{page}</main>
          <nav className="bottom">
            {nav.map((n) => (
              <button key={n.k} className={(a ?? '') === n.k ? 'on' : ''} onClick={() => go('/' + n.k)}>
                <span>{n.i}</span>
                <small>{n.t}</small>
              </button>
            ))}
          </nav>
        </>
      )}
    </AppCtx.Provider>
  );
}
