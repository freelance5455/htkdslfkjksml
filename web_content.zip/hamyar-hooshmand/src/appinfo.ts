// مشخصات رسمی برنامه (در درباره ما، صفحه شروع و تنظیمات نمایش داده می‌شود)
export const APP = {
  name: 'همیار هوشمند',
  slogan: 'یادگیری آسان، موفقیت قطعی',
  version: '۰٫۳٫۰',
  creator: 'امیر علی کریمی',
  company: 'مدرسه رستگاران',
  country: 'ایران',
  language: 'فارسی',
  direction: 'راست‌چین (RTL)',
  calendar: 'شمسی (هجری خورشیدی)',
  currency: 'تومان'
};

export const INFO_ROWS: [string, string][] = [
  ['نام برنامه', APP.name],
  ['نام سازنده', APP.creator],
  ['شرکت سازنده', APP.company],
  ['کشور هدف', APP.country],
  ['زبان اصلی', APP.language],
  ['جهت نمایش', APP.direction],
  ['تقویم', APP.calendar],
  ['واحد پول', APP.currency],
  ['نسخه', APP.version]
];
