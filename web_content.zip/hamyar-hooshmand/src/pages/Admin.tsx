import { useState } from 'react';
import { BOOKS, bookQuestions, chapterQuestions, findBook, getStaticBook, isStaticBook } from '../data/content';
import { FIELDS, GRADES, TRACK_FIELDS, gradeTitle } from '../data/grades';
import { Book, Chapter, Custom, CustomExam, EXAM_KINDS, ExamKind, Lesson, LessonContent, Question } from '../data/types';
import { kvSet } from '../db';
import { useApp } from '../state';
import { fa, shuffle, uid } from '../utils';
import { resizeImage } from './Shared';

/* ---------- ورود امن با PIN (PBKDF2 + نمک تصادفی) ---------- */
const hex = (b: ArrayBuffer) => Array.from(new Uint8Array(b)).map((x) => x.toString(16).padStart(2, '0')).join('');
async function hashPin(pin: string, salt: string) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(pin), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: new TextEncoder().encode(salt), iterations: 150000 }, key, 256);
  return hex(bits);
}

function Gate({ onOk }: { onOk: () => void }) {
  const { custom, upCustom } = useApp();
  const [pin, setPin] = useState('');
  const [pin2, setPin2] = useState('');
  const [msg, setMsg] = useState('');
  const setup = !custom.admin;
  const secure = typeof crypto !== 'undefined' && !!crypto.subtle;

  async function submit() {
    if (!secure) return setMsg('این بخش به محیط امن (HTTPS یا اپلیکیشن نصب‌شده) نیاز دارد.');
    if (setup) {
      if (pin.length < 6) return setMsg('رمز باید حداقل ۶ نویسه باشد.');
      if (pin !== pin2) return setMsg('تکرار رمز یکسان نیست.');
      const salt = hex(crypto.getRandomValues(new Uint8Array(16)).buffer);
      upCustom((c) => ({ ...c, admin: { salt, hash: '' } }));
      const h = await hashPin(pin, salt);
      upCustom((c) => ({ ...c, admin: { salt, hash: h } }));
      onOk();
    } else {
      const h = await hashPin(pin, custom.admin!.salt);
      if (h === custom.admin!.hash) onOk();
      else setMsg('رمز اشتباه است.');
    }
  }

  return (
    <div className="card">
      <h2>🔐 پنل مدیریت</h2>
      <p className="muted small">{setup ? 'برای اولین بار یک رمز مدیر تعیین کن (حداقل ۶ نویسه). توجه: این رمز فقط روی همین دستگاه ذخیره می‌شود و برای محتوای مشترک بین چند دستگاه باید از سرور مدیریت استفاده شود.' : 'رمز مدیر را وارد کن.'}</p>
      <input className="input" type="password" placeholder="رمز" value={pin} onChange={(e) => setPin(e.target.value)} />
      {setup && <input className="input" type="password" placeholder="تکرار رمز" value={pin2} onChange={(e) => setPin2(e.target.value)} />}
      <button className="btn primary full" onClick={submit}>{setup ? 'تعیین رمز و ورود' : 'ورود'}</button>
      {msg && <p className="win" style={{ color: '#e0486a' }}>{msg}</p>}
    </div>
  );
}

const lines = (s: string) => s.split('\n').map((x) => x.trim()).filter(Boolean);
const emptyContent = (): LessonContent => ({ explain: [], steps: [], examples: [], tips: [], summary: [], exercises: [], source: '' });

/* ---------- ویرایش درس ---------- */
function LessonEditor({ lesson, onSave, onClose }: { lesson: Lesson; onSave: (l: Lesson) => void; onClose: () => void }) {
  const c = lesson.content ?? emptyContent();
  const [title, setTitle] = useState(lesson.title);
  const [explain, setExplain] = useState(c.explain.join('\n'));
  const [steps, setSteps] = useState(c.steps.join('\n'));
  const [examples, setExamples] = useState(c.examples.map((e) => `${e.q} :: ${e.a}`).join('\n'));
  const [tips, setTips] = useState(c.tips.join('\n'));
  const [summary, setSummary] = useState(c.summary.join('\n'));
  const [source, setSource] = useState(c.source);
  const T = (label: string, v: string, f: (x: string) => void) => (<><label>{label}</label><textarea className="input" rows={3} value={v} onChange={(e) => f(e.target.value)} /></>);
  return (
    <div className="card">
      <b>ویرایش درس</b>
      <input className="input" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="عنوان درس" />
      {T('توضیح (هر خط یک پاراگراف)', explain, setExplain)}
      {T('آموزش مرحله‌به‌مرحله (هر خط یک مرحله)', steps, setSteps)}
      {T('مثال‌ها (هر خط: سؤال :: پاسخ)', examples, setExamples)}
      {T('نکات مهم امتحانی', tips, setTips)}
      {T('خلاصه درس', summary, setSummary)}
      <label>منبع و سال تحصیلی محتوا</label>
      <input className="input" value={source} onChange={(e) => setSource(e.target.value)} />
      <div className="row">
        <button className="btn primary" onClick={() => {
          if (!title.trim()) return alert('عنوان لازم است.');
          if (!source.trim() && (explain.trim() || steps.trim())) return alert('منبع محتوا را مشخص کن.');
          const ex = lines(examples).map((l) => { const [q, ...a] = l.split('::'); return { q: q.trim(), a: a.join('::').trim() }; });
          const has = explain.trim() || steps.trim() || ex.length || tips.trim() || summary.trim() || c.exercises.length;
          onSave({ ...lesson, title: title.trim(), content: has ? { ...c, explain: lines(explain), steps: lines(steps), examples: ex, tips: lines(tips), summary: lines(summary), source: source.trim() } : undefined });
        }}>ذخیره درس</button>
        <button className="btn" onClick={onClose}>بستن</button>
      </div>
    </div>
  );
}

/* ---------- کتاب‌ها ---------- */
function BookEditor({ init, onClose }: { init: Book; onClose: () => void }) {
  const { custom, upCustom } = useApp();
  const [b, setB] = useState<Book>(JSON.parse(JSON.stringify(init)));
  const [editing, setEditing] = useState<{ ci: number; li: number } | null>(null);
  const [msg, setMsg] = useState('');
  const set = (p: Partial<Book>) => setB((x) => ({ ...x, ...p }));
  const tracks = custom.tracks.filter((t) => t.gradeId === b.gradeId && t.field === b.field);

  const setCh = (ci: number, f: (c: Chapter) => Chapter) => setB((x) => ({ ...x, chapters: x.chapters.map((c, i) => (i === ci ? f(c) : c)) }));

  async function pdf(f?: File) {
    if (!f) return;
    if (f.size > 40 * 1024 * 1024) return setMsg('حجم PDF بیش از ۴۰ مگابایت است.');
    await kvSet('pdf:' + b.id, f);
    set({ hasPdf: true });
    setMsg('PDF ذخیره شد. فقط فایل‌هایی را بارگذاری کن که حق انتشارشان را داری یا از منبع رسمی مجاز هستند.');
  }

  function save() {
    if (!b.title.trim()) return alert('نام کتاب لازم است.');
    const nb = { ...b, title: b.title.trim(), custom: true };
    upCustom((c) => ({ ...c, books: [...c.books.filter((x) => x.id !== nb.id), nb] }));
    onClose();
  }

  if (editing) {
    const l = b.chapters[editing.ci].lessons[editing.li];
    return <LessonEditor lesson={l} onClose={() => setEditing(null)} onSave={(nl) => { setCh(editing.ci, (c) => ({ ...c, lessons: c.lessons.map((x, i) => (i === editing.li ? nl : x)) })); setEditing(null); }} />;
  }

  return (
    <div className="card">
      <b>{init.custom || isStaticBook(init.id) ? 'ویرایش کتاب' : 'کتاب جدید'}</b>
      <input className="input" placeholder="نام کتاب" value={b.title} onChange={(e) => set({ title: e.target.value })} />
      <div className="row">
        <select className="input" value={b.gradeId} onChange={(e) => set({ gradeId: +e.target.value })}>{GRADES.map((g) => <option key={g.id} value={g.id}>{g.title}</option>)}</select>
        <select className="input" value={b.field ?? ''} onChange={(e) => set({ field: e.target.value || undefined, track: undefined })}><option value="">مشترک همه رشته‌ها</option>{FIELDS.map((f) => <option key={f} value={f}>{f}</option>)}</select>
      </div>
      {b.field && TRACK_FIELDS.includes(b.field) && (
        <select className="input" value={b.track ?? ''} onChange={(e) => set({ track: e.target.value || undefined })}><option value="">زمینه/رشته…</option>{tracks.map((t) => <option key={t.id} value={t.name}>{t.group} — {t.name}</option>)}</select>
      )}
      <div className="row">
        <input className="input" placeholder="سال تحصیلی (مثلاً ۱۴۰۵-۱۴۰۶)" value={b.year ?? ''} onChange={(e) => set({ year: e.target.value })} />
        <input className="input" style={{ maxWidth: 70 }} placeholder="آیکون" value={b.icon} onChange={(e) => set({ icon: e.target.value })} />
        <input type="color" value={b.color} onChange={(e) => set({ color: e.target.value })} />
      </div>
      <input className="input" dir="ltr" placeholder="پیوند PDF رسمی (اختیاری)" value={b.pdfUrl ?? ''} onChange={(e) => set({ pdfUrl: e.target.value })} />
      <input className="input" dir="ltr" placeholder="منبع رسمی (مثلاً https://chap.sch.ir/)" value={b.sourceUrl ?? ''} onChange={(e) => set({ sourceUrl: e.target.value })} />
      <div className="row wrap">
        <label className="btn">🖼️ تصویر جلد<input type="file" accept="image/*" hidden onChange={async (e) => { const f = e.target.files?.[0]; if (f) set({ cover: await resizeImage(f, 320, 0.8) }); }} /></label>
        <label className="btn">📄 بارگذاری PDF<input type="file" accept="application/pdf" hidden onChange={(e) => pdf(e.target.files?.[0])} /></label>
        <label className="row"><input type="checkbox" checked={!!b.archived} onChange={(e) => set({ archived: e.target.checked })} /> آرشیو</label>
      </div>
      {b.cover && <img src={b.cover} className="cover" alt="جلد" />}
      {msg && <p className="muted small">{msg}</p>}

      <h3>فصل‌ها و درس‌ها</h3>
      {b.chapters.map((c, ci) => (
        <div className="card" key={c.id}>
          <div className="row"><input className="input" value={c.title} onChange={(e) => setCh(ci, (x) => ({ ...x, title: e.target.value }))} /><button className="star" onClick={() => confirm('فصل حذف شود؟') && setB((x) => ({ ...x, chapters: x.chapters.filter((_, i) => i !== ci) }))}>🗑️</button></div>
          {c.lessons.map((l, li) => (
            <div className="row between" key={l.id}>
              <span>📝 {l.title} {l.content ? '' : <span className="badge warn">تکمیل‌نشده</span>}</span>
              <span><button className="btn" onClick={() => setEditing({ ci, li })}>ویرایش</button><button className="star" onClick={() => setCh(ci, (x) => ({ ...x, lessons: x.lessons.filter((_, i) => i !== li) }))}>🗑️</button></span>
            </div>
          ))}
          <button className="btn" onClick={() => { const t = prompt('عنوان درس جدید؟'); if (t?.trim()) setCh(ci, (x) => ({ ...x, lessons: [...x.lessons, { id: `${b.id}-l${uid()}`, title: t.trim() }] })); }}>➕ درس</button>
        </div>
      ))}
      <button className="btn" onClick={() => { const t = prompt('عنوان فصل جدید؟'); if (t?.trim()) setB((x) => ({ ...x, chapters: [...x.chapters, { id: `${b.id}-c${uid()}`, title: t.trim(), lessons: [] }] })); }}>➕ فصل</button>
      <div className="row">
        <button className="btn primary" onClick={save}>ذخیره کتاب</button>
        <button className="btn" onClick={onClose}>انصراف</button>
        {isStaticBook(b.id) && custom.books.some((x) => x.id === b.id) && <button className="btn" onClick={() => { upCustom((c) => ({ ...c, books: c.books.filter((x) => x.id !== b.id) })); onClose(); }}>بازگشت به نسخه اصلی</button>}
        {b.custom && !isStaticBook(b.id) && custom.books.some((x) => x.id === b.id) && <button className="btn" onClick={() => { if (confirm('کتاب حذف شود؟')) { upCustom((c) => ({ ...c, books: c.books.filter((x) => x.id !== b.id) })); onClose(); } }}>🗑️ حذف کتاب</button>}
      </div>
    </div>
  );
}

function BooksTab() {
  const [edit, setEdit] = useState<Book | null>(null);
  if (edit) return <BookEditor init={edit} onClose={() => setEdit(null)} />;
  return (
    <div>
      <button className="btn primary full" onClick={() => setEdit({ id: 'b-' + uid(), gradeId: 9, title: '', icon: '📘', color: '#2f7be5', chapters: [], custom: true })}>➕ کتاب جدید</button>
      {BOOKS.map((b) => <div className="row between card" key={b.id}><span>{b.icon} {b.title}<br /><small className="muted">{gradeTitle(b.gradeId)} · {b.field ?? 'مشترک'} · {b.year ? fa(b.year) : '—'}{b.archived ? ' · آرشیو' : ''}</small></span><button className="btn" onClick={() => setEdit(b)}>ویرایش</button></div>)}
    </div>
  );
}

/* ---------- سؤال‌ها ---------- */
function QuestionsTab() {
  const { upCustom, custom } = useApp();
  const [bid, setBid] = useState(BOOKS.find((b) => b.chapters.some((c) => c.lessons.length))?.id ?? '');
  const book = findBook(bid);
  const lessons = book?.chapters.flatMap((c) => c.lessons) ?? [];
  const [lid, setLid] = useState('');
  const lesson = lessons.find((l) => l.id === lid) ?? lessons[0];
  const [type, setType] = useState<Question['type']>('mcq');
  const [q, setQ] = useState('');
  const [opts, setOpts] = useState('');
  const [ans, setAns] = useState('');
  const [exp, setExp] = useState('');
  const [level, setLevel] = useState(2);
  const [verified, setVerified] = useState(false);

  function commit(fn: (qs: Question[]) => Question[]) {
    if (!book || !lesson) return;
    const nb: Book = JSON.parse(JSON.stringify(book));
    const l = nb.chapters.flatMap((c) => c.lessons).find((x) => x.id === lesson.id)!;
    l.content = { ...(l.content ?? emptyContent()), source: l.content?.source || 'افزوده‌شده توسط مدیر' };
    l.content.exercises = fn(l.content.exercises);
    nb.custom = true;
    upCustom((c) => ({ ...c, books: [...c.books.filter((x) => x.id !== nb.id), nb] }));
  }

  function add() {
    if (!q.trim() || !exp.trim()) return alert('متن سؤال و توضیح پاسخ لازم است.');
    const base = { q: q.trim(), explain: exp.trim(), level: level as 1 | 2 | 3, status: (verified ? 'verified' : 'review') as 'verified' | 'review' };
    let item: Question;
    if (type === 'mcq') {
      const o = lines(opts);
      const a = parseInt(ans, 10);
      if (o.length < 2 || !(a >= 1 && a <= o.length)) return alert('حداقل دو گزینه بنویس و شماره گزینه درست را (از ۱) وارد کن.');
      item = { ...base, type: 'mcq', options: o, answer: a - 1 };
    } else if (type === 'tf') {
      if (ans !== 'true' && ans !== 'false') return alert('پاسخ را انتخاب کن.');
      item = { ...base, type: 'tf', answer: ans === 'true' };
    } else {
      if (!ans.trim()) return alert('پاسخ لازم است.');
      item = { ...base, type, answer: ans.trim() };
    }
    commit((qs) => [...qs, item]);
    setQ(''); setOpts(''); setAns(''); setExp('');
  }

  void custom;
  return (
    <div>
      <select className="input" value={bid} onChange={(e) => { setBid(e.target.value); setLid(''); }}>{BOOKS.filter((b) => b.chapters.some((c) => c.lessons.length)).map((b) => <option key={b.id} value={b.id}>{b.title}</option>)}</select>
      {lessons.length === 0 ? <p className="muted">ابتدا در تب «کتاب‌ها» فصل و درس بساز.</p> : (
        <>
          <select className="input" value={lesson?.id} onChange={(e) => setLid(e.target.value)}>{lessons.map((l) => <option key={l.id} value={l.id}>{l.title}</option>)}</select>
          <div className="card">
            <b>سؤال جدید</b>
            <select className="input" value={type} onChange={(e) => { setType(e.target.value as Question['type']); setAns(''); }}><option value="mcq">چهارگزینه‌ای</option><option value="tf">درست/نادرست</option><option value="blank">جای‌خالی</option><option value="essay">تشریحی</option></select>
            <textarea className="input" rows={2} placeholder="متن سؤال" value={q} onChange={(e) => setQ(e.target.value)} />
            {type === 'mcq' && <textarea className="input" rows={4} placeholder="گزینه‌ها (هر خط یک گزینه)" value={opts} onChange={(e) => setOpts(e.target.value)} />}
            {type === 'tf' ? <select className="input" value={ans} onChange={(e) => setAns(e.target.value)}><option value="">پاسخ…</option><option value="true">درست</option><option value="false">نادرست</option></select> : <input className="input" placeholder={type === 'mcq' ? 'شماره گزینه درست (از ۱)' : 'پاسخ'} value={ans} onChange={(e) => setAns(e.target.value)} />}
            <textarea className="input" rows={2} placeholder="توضیح علت درست بودن پاسخ" value={exp} onChange={(e) => setExp(e.target.value)} />
            <div className="row"><select className="input" value={level} onChange={(e) => setLevel(+e.target.value)}><option value={1}>آسان</option><option value={2}>متوسط</option><option value={3}>سخت</option></select><label className="row"><input type="checkbox" checked={verified} onChange={(e) => setVerified(e.target.checked)} /> با منبع رسمی تطبیق داده شد</label></div>
            <button className="btn primary full" onClick={add}>افزودن سؤال</button>
          </div>
          <h3>سؤال‌های این درس</h3>
          {(lesson?.content?.exercises ?? []).map((x, i) => (
            <div className="card" key={i}>
              <div>{fa(i + 1)}. {fa(x.q)} <span className="badge">{x.type}</span> <span className={'badge ' + (x.status === 'verified' ? 'ok' : 'warn')}>{x.status === 'verified' ? 'تأییدشده' : 'نیازمند بررسی'}</span></div>
              <div className="row">
                <button className="btn" onClick={() => commit((qs) => qs.map((z, k) => (k === i ? { ...z, status: z.status === 'verified' ? 'review' : 'verified' } : z)))}>{x.status === 'verified' ? 'علامت: نیازمند بررسی' : 'علامت: تأییدشده'}</button>
                <button className="btn" onClick={() => confirm('سؤال حذف شود؟') && commit((qs) => qs.filter((_, k) => k !== i))}>🗑️ حذف</button>
              </div>
            </div>
          ))}
        </>
      )}
    </div>
  );
}

/* ---------- آزمون‌ها ---------- */
function ExamsTab() {
  const { custom, upCustom } = useApp();
  const withQ = BOOKS.filter((b) => bookQuestions(b).length);
  const [title, setTitle] = useState('');
  const [kind, setKind] = useState<ExamKind>('term1');
  const [bid, setBid] = useState(withQ[0]?.id ?? '');
  const [cid, setCid] = useState('');
  const [count, setCount] = useState(10);
  const [minutes, setMinutes] = useState(30);
  const book = findBook(bid);
  function create() {
    if (!book || !title.trim()) return alert('عنوان و کتاب لازم است.');
    const base = cid ? chapterQuestions(book.chapters.find((c) => c.id === cid) ?? { lessons: [] }) : bookQuestions(book);
    const qs = shuffle(base).slice(0, count);
    if (!qs.length) return alert('سؤالی برای این بازه ثبت نشده است.');
    const ex: CustomExam = { id: 'ex-' + uid(), title: title.trim(), kind, gradeId: book.gradeId, field: book.field, bookId: book.id, minutes, questions: qs, source: `ساخته‌شده از سؤال‌های ${book.title}` };
    upCustom((c) => ({ ...c, exams: [...c.exams, ex] }));
    setTitle('');
  }
  return (
    <div>
      <div className="card">
        <b>ساخت آزمون جدید از سؤال‌های ثبت‌شده</b>
        <input className="input" placeholder="عنوان آزمون" value={title} onChange={(e) => setTitle(e.target.value)} />
        <select className="input" value={kind} onChange={(e) => setKind(e.target.value as ExamKind)}>{(Object.keys(EXAM_KINDS) as ExamKind[]).map((k) => <option key={k} value={k}>{EXAM_KINDS[k]}</option>)}</select>
        <select className="input" value={bid} onChange={(e) => { setBid(e.target.value); setCid(''); }}>{withQ.map((b) => <option key={b.id} value={b.id}>{b.title}</option>)}</select>
        <select className="input" value={cid} onChange={(e) => setCid(e.target.value)}><option value="">کل کتاب</option>{book?.chapters.filter((c) => chapterQuestions(c).length).map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}</select>
        <div className="row"><input className="input" type="number" min={1} value={count} onChange={(e) => setCount(+e.target.value)} /><input className="input" type="number" min={1} value={minutes} onChange={(e) => setMinutes(+e.target.value)} /></div>
        <small className="muted">تعداد سؤال / زمان (دقیقه)</small>
        <button className="btn primary full" onClick={create}>ساخت آزمون</button>
      </div>
      {custom.exams.map((e) => <div className="row between card" key={e.id}><span>{e.title}<br /><small className="muted">{EXAM_KINDS[e.kind]} · {fa(e.questions.length)} سؤال</small></span><button className="star" onClick={() => upCustom((c) => ({ ...c, exams: c.exams.filter((z) => z.id !== e.id) }))}>🗑️</button></div>)}
    </div>
  );
}

/* ---------- پایه‌ها و رشته‌ها ---------- */
function TracksTab() {
  const { custom, upCustom } = useApp();
  const [gradeId, setGradeId] = useState(10);
  const [field, setField] = useState(TRACK_FIELDS[0]);
  const [group, setGroup] = useState('');
  const [name, setName] = useState('');
  return (
    <div>
      <div className="card">
        <b>افزودن زمینه / گروه / رشته</b>
        <p className="muted small">فهرست رسمی را از منبع آموزش‌وپرورش وارد کن؛ برنامه خودش فهرستی نمی‌سازد.</p>
        <div className="row"><select className="input" value={gradeId} onChange={(e) => setGradeId(+e.target.value)}>{GRADES.filter((g) => g.id >= 10).map((g) => <option key={g.id} value={g.id}>{g.title}</option>)}</select><select className="input" value={field} onChange={(e) => setField(e.target.value)}>{TRACK_FIELDS.map((f) => <option key={f} value={f}>{f}</option>)}</select></div>
        <input className="input" placeholder="زمینه یا گروه (مثلاً صنعت)" value={group} onChange={(e) => setGroup(e.target.value)} />
        <input className="input" placeholder="نام رشته" value={name} onChange={(e) => setName(e.target.value)} />
        <button className="btn primary full" onClick={() => { if (group.trim() && name.trim()) { upCustom((c) => ({ ...c, tracks: [...c.tracks, { id: uid(), gradeId, field, group: group.trim(), name: name.trim() }] })); setName(''); } }}>افزودن</button>
      </div>
      {custom.tracks.map((t) => <div className="row between card" key={t.id}><span>{gradeTitle(t.gradeId)} · {t.field}<br /><small className="muted">{t.group} — {t.name}</small></span><button className="star" onClick={() => upCustom((c) => ({ ...c, tracks: c.tracks.filter((z) => z.id !== t.id) }))}>🗑️</button></div>)}
    </div>
  );
}

/* ---------- نسخه‌ها ---------- */
function VersionsTab() {
  const { custom, upCustom } = useApp();
  const [bid, setBid] = useState(BOOKS[0]?.id ?? '');
  const [year, setYear] = useState('');
  const [note, setNote] = useState('');
  const [url, setUrl] = useState('');
  function register() {
    const b = findBook(bid);
    if (!b || !year.trim()) return alert('کتاب و سال تحصیلی جدید لازم است.');
    const old: Book = { ...JSON.parse(JSON.stringify(b)), id: `${b.id}-arch-${uid()}`, title: `${b.title} (${b.year ?? 'قدیمی'})`, archived: true, custom: true };
    const cur: Book = { ...JSON.parse(JSON.stringify(b)), year: year.trim(), pdfUrl: url.trim() || b.pdfUrl, archived: false, custom: true };
    upCustom((c) => ({ ...c, books: [...c.books.filter((x) => x.id !== b.id), old, cur], versions: [...c.versions, { id: uid(), bookId: b.id, year: year.trim(), note: note.trim(), url: url.trim(), t: Date.now() }] }));
    setYear(''); setNote(''); setUrl('');
  }
  return (
    <div>
      <div className="card">
        <b>ثبت نسخه جدید کتاب</b>
        <p className="muted small">نسخه فعلی در آرشیو نگه داشته می‌شود و کتاب به سال جدید به‌روزرسانی می‌شود.</p>
        <select className="input" value={bid} onChange={(e) => setBid(e.target.value)}>{BOOKS.filter((b) => !b.archived).map((b) => <option key={b.id} value={b.id}>{b.title}</option>)}</select>
        <input className="input" placeholder="سال تحصیلی جدید" value={year} onChange={(e) => setYear(e.target.value)} />
        <input className="input" placeholder="توضیح تغییرات" value={note} onChange={(e) => setNote(e.target.value)} />
        <input className="input" dir="ltr" placeholder="پیوند PDF نسخه جدید (اختیاری)" value={url} onChange={(e) => setUrl(e.target.value)} />
        <button className="btn primary full" onClick={register}>ثبت نسخه</button>
      </div>
      {custom.versions.map((v) => <div className="card" key={v.id}>{findBook(v.bookId)?.title ?? v.bookId} — {fa(v.year)} <small className="muted">{v.note}</small></div>)}
    </div>
  );
}

/* ---------- داده ---------- */
function validCatalog(j: unknown): Book[] | null {
  const root = j && typeof j === 'object' ? j as { books?: unknown } : null;
  const arr = Array.isArray(j) ? j : root?.books;
  if (!Array.isArray(arr)) return null;
  const isText = (x: unknown): x is string => typeof x === 'string' && x.length <= 20000;
  const out: Book[] = [];
  const ids = new Set<string>();
  for (const raw of arr) {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
    const b = raw as Record<string, unknown>;
    if (!isText(b.id) || !b.id.trim() || ids.has(b.id) || !isText(b.title) || !b.title.trim() ||
        typeof b.gradeId !== 'number' || !Number.isInteger(b.gradeId) || b.gradeId < 1 || b.gradeId > 12 ||
        !Array.isArray(b.chapters) || b.chapters.length > 100) return null;
    ids.add(b.id);
    const chapterIds = new Set<string>();
    for (const ch of b.chapters) {
      if (!ch || typeof ch !== 'object' || Array.isArray(ch)) return null;
      const c = ch as Record<string, unknown>;
      if (!isText(c.id) || !c.id.trim() || chapterIds.has(c.id) || !isText(c.title) || !Array.isArray(c.lessons) || c.lessons.length > 300) return null;
      chapterIds.add(c.id);
      const lessonIds = new Set<string>();
      for (const le of c.lessons) {
        if (!le || typeof le !== 'object' || Array.isArray(le)) return null;
        const l = le as Record<string, unknown>;
        if (!isText(l.id) || !l.id.trim() || lessonIds.has(l.id) || !isText(l.title)) return null;
        lessonIds.add(l.id);
        if (l.content !== undefined) {
          if (!l.content || typeof l.content !== 'object' || Array.isArray(l.content)) return null;
          const ct = l.content as Record<string, unknown>;
          for (const key of ['explain', 'steps', 'tips', 'summary']) {
            if (ct[key] !== undefined && (!Array.isArray(ct[key]) || !(ct[key] as unknown[]).every(isText))) return null;
          }
          if (ct.examples !== undefined && (!Array.isArray(ct.examples) || !(ct.examples as unknown[]).every((e) => !!e && typeof e === 'object' && isText((e as Record<string, unknown>).q) && isText((e as Record<string, unknown>).a)))) return null;
          if (ct.exercises !== undefined && !Array.isArray(ct.exercises)) return null;
          if (ct.source !== undefined && !isText(ct.source)) return null;
        }
      }
    }
    out.push({ icon: '📘', color: '#2f7be5', ...b, chapters: b.chapters as Book['chapters'], custom: true } as Book);
  }
  return out;
}

function DataTab() {
  const { custom, upCustom } = useApp();
  const [msg, setMsg] = useState('');
  function exp() {
    const { admin, ...rest } = custom;
    void admin;
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([JSON.stringify(rest, null, 2)], { type: 'application/json' }));
    a.download = 'hamyar-content.json';
    a.click();
  }
  async function imp(f?: File) {
    if (!f) return;
    try {
      const j = JSON.parse(await f.text());
      const books = validCatalog(j);
      if (!books) throw new Error('bad');
      upCustom((c) => ({ ...c, books: [...c.books.filter((x) => !books.some((y) => y.id === x.id)), ...books], tracks: Array.isArray(j.tracks) ? [...c.tracks, ...j.tracks] : c.tracks, exams: Array.isArray(j.exams) ? [...c.exams, ...j.exams] : c.exams }));
      setMsg(`✅ ${fa(books.length)} کتاب وارد شد.`);
    } catch { setMsg('❌ فایل کاتالوگ معتبر نیست. ساختار: آرایه‌ای از کتاب‌ها با id، title، gradeId (۱ تا ۱۲) و chapters.'); }
  }
  return (
    <div className="card">
      <b>ورود و خروج محتوا (JSON)</b>
      <p className="muted small">برای ورود کاتالوگ رسمی کتاب‌ها: فایل JSON شامل آرایه‌ای از کتاب‌ها را وارد کن. نمونه ساختار در docs/CONTENT-FORMAT.md است.</p>
      <div className="row wrap"><button className="btn" onClick={exp}>⬇️ خروجی محتوا</button><label className="btn">⬆️ ورود کاتالوگ/محتوا<input type="file" accept="application/json" hidden onChange={(e) => imp(e.target.files?.[0])} /></label></div>
      {msg && <p className="win">{msg}</p>}
    </div>
  );
}

export default function Admin() {
  const [ok, setOk] = useState(false);
  const [tab, setTab] = useState('books');
  const tabs: [string, string][] = [['books', 'کتاب‌ها'], ['q', 'سؤال‌ها'], ['exams', 'آزمون‌ها'], ['tracks', 'پایه‌ها و رشته‌ها'], ['ver', 'نسخه‌ها'], ['data', 'داده']];
  if (!ok) return <Gate onOk={() => setOk(true)} />;
  return (
    <div>
      <div className="row between"><h2>🛠️ پنل مدیریت</h2><button className="btn" onClick={() => setOk(false)}>خروج</button></div>
      <div className="tabs wrapTabs">{tabs.map(([k, v]) => <button key={k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>{v}</button>)}</div>
      {tab === 'books' && <BooksTab />}
      {tab === 'q' && <QuestionsTab />}
      {tab === 'exams' && <ExamsTab />}
      {tab === 'tracks' && <TracksTab />}
      {tab === 'ver' && <VersionsTab />}
      {tab === 'data' && <DataTab />}
      <p className="muted small">{getStaticBook('g9-math') ? '' : ''}تغییرات روی همین دستگاه ذخیره می‌شود و آفلاین قابل‌استفاده است.</p>
    </div>
  );
}
