import { useState } from 'react';
import { APP } from '../appinfo';
import { FIELDS, GRADES } from '../data/grades';
import { useApp } from '../state';
import { Credits, InfoTable } from './Shared';

export function Splash() {
  return (
    <div className="splash-screen">
      <img src="icons/icon-512.png" alt={APP.name} />
      <h1>{APP.name}</h1>
      <p>{APP.slogan}</p>
      <Credits />
    </div>
  );
}

export default function Welcome() {
  const { s, up } = useApp();
  const [grade, setGrade] = useState<number>(s.profile.grade ?? 9);
  const [field, setField] = useState<string>(s.profile.field ?? '');
  const needsField = grade >= 10;
  return (
    <div className="page welcome">
      <div className="hero">
        <img src="icons/icon-192.png" alt={APP.name} />
        <div><h1>به {APP.name} خوش آمدی</h1><p>{APP.slogan}</p></div>
      </div>
      <h3>پایه تحصیلی‌ات را انتخاب کن</h3>
      <select className="input" value={grade} onChange={(e) => setGrade(+e.target.value)}>
        {GRADES.map((g) => <option key={g.id} value={g.id}>{g.title}</option>)}
      </select>
      {needsField && (
        <>
          <h3>رشته تحصیلی</h3>
          <select className="input" value={field} onChange={(e) => setField(e.target.value)}>
            <option value="">انتخاب کن…</option>
            {FIELDS.map((f) => <option key={f} value={f}>{f}</option>)}
          </select>
        </>
      )}
      <button className="btn primary full" disabled={needsField && !field} onClick={() => up((x) => ({ ...x, profile: { done: true, grade, field: needsField ? field : undefined }, fields: needsField ? { ...x.fields, [grade]: field } : x.fields }))}>شروع یادگیری</button>
      <button className="btn full" onClick={() => up((x) => ({ ...x, profile: { done: true } }))}>فعلاً رد می‌کنم</button>
      <InfoTable />
      <Credits />
    </div>
  );
}
