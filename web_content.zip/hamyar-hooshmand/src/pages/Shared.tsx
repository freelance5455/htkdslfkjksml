import { INFO_ROWS } from '../appinfo';
import { JMONTHS, fa, fromJalali, toJalali, todayISO } from '../utils';

export const go = (p: string) => {
  location.hash = p;
};

export function InfoTable() {
  return (
    <div className="card">
      {INFO_ROWS.map(([k, v]) => (
        <div className="row between info-row" key={k}>
          <span className="muted">{k}</span>
          <b>{v}</b>
        </div>
      ))}
    </div>
  );
}

export function Credits() {
  return (
    <div className="credits">
      <div>طراحی و توسعه توسط امیر علی کریمی</div>
      <div>شرکت سازنده: مدرسه رستگاران</div>
    </div>
  );
}

// انتخاب تاریخ شمسی؛ مقدار به‌صورت ISO میلادی ذخیره می‌شود
export function DatePick({ value, onChange }: { value: string; onChange: (iso: string) => void }) {
  const cur = toJalali(value || todayISO());
  const years = [cur.jy - 1, cur.jy, cur.jy + 1, cur.jy + 2].filter((y, i, a) => a.indexOf(y) === i);
  const set = (jy: number, jm: number, jd: number) => onChange(fromJalali(jy, jm, jd));
  return (
    <div className="row datepick">
      <select className="input" value={cur.jd} onChange={(e) => set(cur.jy, cur.jm, +e.target.value)}>
        {Array.from({ length: 31 }, (_, i) => i + 1).map((d) => <option key={d} value={d}>{fa(d)}</option>)}
      </select>
      <select className="input" value={cur.jm} onChange={(e) => set(cur.jy, +e.target.value, cur.jd)}>
        {JMONTHS.map((m, i) => <option key={m} value={i + 1}>{m}</option>)}
      </select>
      <select className="input" value={cur.jy} onChange={(e) => set(+e.target.value, cur.jm, cur.jd)}>
        {years.map((y) => <option key={y} value={y}>{fa(y)}</option>)}
      </select>
    </div>
  );
}

// نمودار میله‌ای ساده با SVG
export function BarChart({ values, labels, unit }: { values: number[]; labels: string[]; unit: string }) {
  const max = Math.max(1, ...values);
  const w = 300, h = 140, bw = w / values.length;
  return (
    <svg viewBox={`0 0 ${w} ${h + 30}`} className="chart" role="img">
      {values.map((v, i) => {
        const bh = (v / max) * h;
        return (
          <g key={i}>
            <rect x={i * bw + 6} y={h - bh} width={bw - 12} height={bh} rx={6} fill="var(--primary)" />
            <text x={i * bw + bw / 2} y={h - bh - 4} textAnchor="middle" fontSize="10" fill="var(--text)">{v ? fa(v) : ''}</text>
            <text x={i * bw + bw / 2} y={h + 16} textAnchor="middle" fontSize="9" fill="var(--muted)">{labels[i]}</text>
          </g>
        );
      })}
      <text x={4} y={h + 28} fontSize="9" fill="var(--muted)">{unit}</text>
    </svg>
  );
}

export function LineChart({ values, unit }: { values: number[]; unit: string }) {
  const w = 300, h = 120;
  if (values.length < 2) return <p className="muted small">برای نمایش نمودار حداقل دو آزمون لازم است.</p>;
  const pts = values.map((v, i) => `${(i / (values.length - 1)) * (w - 20) + 10},${h - (v / 20) * (h - 10) - 5}`);
  return (
    <svg viewBox={`0 0 ${w} ${h + 20}`} className="chart" role="img">
      <polyline points={pts.join(' ')} fill="none" stroke="var(--green)" strokeWidth="3" />
      {pts.map((p, i) => <circle key={i} cx={p.split(',')[0]} cy={p.split(',')[1]} r="4" fill="var(--green)" />)}
      <text x={4} y={h + 14} fontSize="9" fill="var(--muted)">{unit}</text>
    </svg>
  );
}

export async function resizeImage(file: File, max: number, quality = 0.85): Promise<string> {
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((res, rej) => {
      const i = new Image();
      i.onload = () => res(i);
      i.onerror = () => rej(new Error('image'));
      i.src = url;
    });
    const k = Math.min(1, max / Math.max(img.width, img.height));
    const c = document.createElement('canvas');
    c.width = Math.round(img.width * k);
    c.height = Math.round(img.height * k);
    c.getContext('2d')!.drawImage(img, 0, 0, c.width, c.height);
    return c.toDataURL('image/jpeg', quality);
  } finally {
    URL.revokeObjectURL(url);
  }
}
