import { useEffect, useRef, useState } from 'react';
import { BOOKS } from '../data/content';
import { FIELDS, GRADES, gradeTitle } from '../data/grades';
import type { CustomExam, Question } from '../data/types';
import { Chat, ChatMsg, useApp } from '../state';
import { fa, uid } from '../utils';
import { go, resizeImage } from './Shared';

const MODES: [string, string][] = [
  ['ask', '💬 پرسش و پاسخ'], ['solve', '🧮 حل مرحله‌به‌مرحله'], ['explain', '💡 توضیح ساده'], ['example', '📌 آموزش با مثال'],
  ['summary', '📋 خلاصه درس'], ['questions', '❓ تولید نمونه سؤال'], ['exam', '📝 ساخت آزمون'], ['check', '✔️ بررسی پاسخ من']
];

// اعتبارسنجی آزمون تولیدشده توسط هوش مصنوعی (هرگز بدون بررسی پذیرفته نمی‌شود)
function parseExam(text: string): Question[] | null {
  const a = text.indexOf('[');
  const b = text.lastIndexOf(']');
  if (a < 0 || b <= a) return null;
  try {
    const arr = JSON.parse(text.slice(a, b + 1));
    const out: Question[] = [];
    for (const x of arr) {
      if (typeof x?.q !== 'string' || typeof x?.explain !== 'string') continue;
      const base = { q: x.q, explain: x.explain, level: [1, 2, 3].includes(x.level) ? x.level : 2, status: 'review' as const };
      if (x.type === 'mcq' && Array.isArray(x.options) && x.options.length >= 2 && Number.isInteger(x.answer) && x.answer >= 0 && x.answer < x.options.length) out.push({ ...base, type: 'mcq', options: x.options.map(String), answer: x.answer });
      else if (x.type === 'tf' && typeof x.answer === 'boolean') out.push({ ...base, type: 'tf', answer: x.answer });
      else if ((x.type === 'blank' || x.type === 'essay') && typeof x.answer === 'string') out.push({ ...base, type: x.type, answer: x.answer });
    }
    return out.length ? out : null;
  } catch { return null; }
}

export default function Assistant() {
  const { s, up } = useApp();
  const [chatId, setChatId] = useState<string>('');
  const [grade, setGrade] = useState<number>(s.profile.grade ?? 9);
  const [field, setField] = useState<string>(s.profile.field ?? '');
  const [subject, setSubject] = useState('');
  const [mode, setMode] = useState('ask');
  const [text, setText] = useState('');
  const [img, setImg] = useState<string>('');
  const [busy, setBusy] = useState(false);
  const [showList, setShowList] = useState(false);
  const end = useRef<HTMLDivElement>(null);
  const chat = s.chats.find((c) => c.id === chatId);
  const subjects = BOOKS.filter((b) => b.gradeId === grade).map((b) => b.title);
  useEffect(() => { end.current?.scrollIntoView?.({ behavior: 'smooth' }); }, [chat?.msgs.length, busy]);

  const ctxLabel = `${gradeTitle(grade)}${grade >= 10 && field ? ' - ' + field : ''}${subject ? ' - ' + subject : ''}`;
  const save = (id: string, f: (c: Chat) => Chat) => up((x) => ({ ...x, chats: x.chats.map((c) => (c.id === id ? f(c) : c)) }));

  async function send() {
    const t = text.trim();
    if (!t && !img) return;
    let id = chatId;
    const userMsg: ChatMsg = { role: 'user', text: t || '(تصویر)', img: !!img };
    if (!chat) {
      id = uid();
      const c: Chat = { id, title: (t || 'تصویر').slice(0, 40), t: Date.now(), ctx: ctxLabel, msgs: [userMsg] };
      up((x) => ({ ...x, chats: [c, ...x.chats].slice(0, 50) }));
      setChatId(id);
    } else save(id, (c) => ({ ...c, t: Date.now(), msgs: [...c.msgs, userMsg] }));
    const image = img;
    setText(''); setImg('');
    const reply = (m: ChatMsg) => up((x) => ({ ...x, chats: x.chats.map((c) => (c.id === id ? { ...c, msgs: [...c.msgs, m] } : c)) }));

    if (!s.apiUrl) return reply({ role: 'assistant', text: '⚠️ سرویس هوش مصنوعی هنوز تنظیم نشده است. از «تنظیمات ← سرویس هوش مصنوعی» نشانی سرور را وارد کن (راهنما: docs/AI-SETUP.md). سایر بخش‌های برنامه بدون آن کار می‌کنند.' });
    if (!navigator.onLine) return reply({ role: 'assistant', text: '📴 اینترنت قطع است. دستیار هوشمند فقط آنلاین کار می‌کند؛ بخش‌های دیگر برنامه آفلاین در دسترس‌اند.' });

    setBusy(true);
    try {
      const history = [...(chat?.msgs ?? []), userMsg].slice(-12).map((m) => ({ role: m.role, text: m.text }));
      const body: Record<string, unknown> = { mode, context: { grade: gradeTitle(grade), field: grade >= 10 ? field : '', subject }, messages: history };
      if (image) body.image = { mediaType: 'image/jpeg', data: image.split(',')[1] };
      const ctl = new AbortController();
      const to = setTimeout(() => ctl.abort(), 90000);
      const r = await fetch(s.apiUrl.replace(/\/+$/, '') + '/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), signal: ctl.signal });
      clearTimeout(to);
      const j = await r.json().catch(() => ({}));
      if (!r.ok || typeof j.reply !== 'string') {
        reply({ role: 'assistant', text: '❌ ' + (j.error ?? 'پاسخ معتبری از سرویس دریافت نشد.') });
      } else if (mode === 'exam') {
        const qs = parseExam(j.reply);
        if (qs) {
          const ex: CustomExam = { id: 'ai-' + uid(), title: `آزمون هوش مصنوعی — ${subject || gradeTitle(grade)}`, kind: 'custom', minutes: Math.max(5, qs.length), questions: qs, source: 'تولیدشده توسط هوش مصنوعی همیار — نیازمند بررسی', ai: true };
          up((x) => ({ ...x, aiExams: [ex, ...x.aiExams].slice(0, 30) }));
          reply({ role: 'assistant', text: `✅ آزمونی با ${fa(qs.length)} سؤال ساخته شد. توجه: پاسخ‌های تولیدشده توسط هوش مصنوعی «نیازمند بررسی» هستند.`, examId: ex.id });
        } else reply({ role: 'assistant', text: '⚠️ ساختار آزمون معتبر نبود. دوباره تلاش کن.\n\n' + j.reply });
      } else reply({ role: 'assistant', text: j.reply });
    } catch (e) {
      reply({ role: 'assistant', text: '❌ ارتباط با سرویس برقرار نشد. نشانی سرویس و اینترنت را بررسی کن.' });
    } finally { setBusy(false); }
  }

  return (
    <div>
      <div className="row between"><h2>🤖 هوش مصنوعی همیار</h2><button className="btn" onClick={() => setShowList(!showList)}>🕘 تاریخچه</button></div>
      {!s.apiUrl && <div className="card warn-box">سرویس هوش مصنوعی تنظیم نشده است. <button className="btn" onClick={() => go('/settings')}>رفتن به تنظیمات</button></div>}
      {showList && (
        <div className="card">
          <button className="btn full" onClick={() => { setChatId(''); setShowList(false); }}>➕ گفت‌وگوی جدید</button>
          {s.chats.length === 0 && <p className="muted small">هنوز گفت‌وگویی ندارید.</p>}
          {s.chats.map((c) => (
            <div className="row between" key={c.id}>
              <button className="list-item" onClick={() => { setChatId(c.id); setShowList(false); }}>💬 {c.title}<br /><small className="muted">{c.ctx}</small></button>
              <button className="star" onClick={() => { up((x) => ({ ...x, chats: x.chats.filter((z) => z.id !== c.id) })); if (c.id === chatId) setChatId(''); }}>🗑️</button>
            </div>
          ))}
        </div>
      )}
      <div className="card">
        <div className="row wrap">
          <select className="input" value={grade} onChange={(e) => { setGrade(+e.target.value); setSubject(''); }}>{GRADES.map((g) => <option key={g.id} value={g.id}>{g.title}</option>)}</select>
          {grade >= 10 && <select className="input" value={field} onChange={(e) => setField(e.target.value)}><option value="">رشته…</option>{FIELDS.map((f) => <option key={f} value={f}>{f}</option>)}</select>}
        </div>
        <input className="input" list="subjects" placeholder="درس (مثلاً ریاضی نهم)" value={subject} onChange={(e) => setSubject(e.target.value)} />
        <datalist id="subjects">{subjects.map((x) => <option key={x} value={x} />)}</datalist>
        <div className="chips">{MODES.map(([k, v]) => <button key={k} className={'chip' + (mode === k ? ' on' : '')} onClick={() => setMode(k)}>{v}</button>)}</div>
      </div>

      <div className="chat">
        {!chat && <p className="muted center-text">سؤالت را بنویس یا عکس سؤال را بفرست. پاسخ‌ها با توجه به «{ctxLabel}» داده می‌شود.</p>}
        {chat?.msgs.map((m, i) => (
          <div key={i} className={'bubble ' + m.role}>
            {m.img && <div className="small">🖼️ تصویر پیوست شد</div>}
            <div style={{ whiteSpace: 'pre-wrap' }}>{m.text}</div>
            {m.examId && <button className="btn primary" onClick={() => go('/exam/' + m.examId)}>شروع آزمون</button>}
          </div>
        ))}
        {busy && <div className="bubble assistant">⏳ در حال پاسخ…</div>}
        <div ref={end} />
      </div>

      <div className="card">
        {img && <div className="row between"><img src={img} alt="پیوست" className="thumb" /><button className="btn" onClick={() => setImg('')}>حذف تصویر</button></div>}
        <textarea className="input" rows={3} placeholder={mode === 'check' ? 'سؤال و پاسخ خودت را بنویس…' : 'پیام خود را بنویس…'} value={text} onChange={(e) => setText(e.target.value)} />
        <div className="row">
          <label className="btn">📷 تصویر سؤال<input type="file" accept="image/*" hidden onChange={async (e) => { const f = e.target.files?.[0]; if (f) setImg(await resizeImage(f, 1280)); }} /></label>
          <button className="btn primary" style={{ flex: 1 }} disabled={busy} onClick={send}>ارسال</button>
        </div>
      </div>
    </div>
  );
}
