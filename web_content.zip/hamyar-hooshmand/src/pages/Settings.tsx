import { useState } from 'react';
import { FIELDS, GRADES } from '../data/grades';
import { AppState, defaultState, useApp } from '../state';
import { InfoTable, Credits, go } from './Shared';

export default function Settings() {
  const { s, up, custom } = useApp();
  const [msg, setMsg] = useState('');
  const [api, setApi] = useState(s.apiUrl);
  const grade = s.profile.grade ?? 0;

  async function test() {
    const base = api.trim().replace(/\/+$/, '');
    if (!base) return setMsg('ابتدا نشانی سرویس را وارد کن.');
    try {
      const r = await fetch(base + '/health');
      const j = await r.json();
      setMsg(j.ok ? (j.configured ? '✅ سرویس در دسترس و کلید API روی سرور تنظیم است.' : '⚠️ سرویس در دسترس است ولی کلید API روی سرور تنظیم نشده.') : '❌ پاسخ نامعتبر');
    } catch {
      setMsg('❌ اتصال به سرویس ممکن نشد (نشانی، اینترنت یا CORS را بررسی کن).');
    }
  }

  function exportData() {
    const blob = new Blob([JSON.stringify({ app: 'hamyar-hooshmand', state: s, custom }, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'hamyar-backup.json';
    a.click();
  }

  async function importData(f: File | undefined) {
    if (!f) return;
    try {
      const j = JSON.parse(await f.text());
      if (j.app !== 'hamyar-hooshmand' || typeof j.state !== 'object') throw new Error('bad');
      up((x) => ({ ...defaultState, ...x, ...(j.state as Partial<AppState>) }));
      setMsg('✅ اطلاعات پیشرفت بازیابی شد.');
    } catch {
      setMsg('❌ فایل پشتیبان معتبر نیست.');
    }
  }

  return (
    <div>
      <h2>⚙️ تنظیمات</h2>
      <div className="card">
        <b>ظاهر</b>
        <div className="row"><button className={'chip' + (s.theme === 'light' ? ' on' : '')} onClick={() => up((x) => ({ ...x, theme: 'light' }))}>☀️ روز</button><button className={'chip' + (s.theme === 'dark' ? ' on' : '')} onClick={() => up((x) => ({ ...x, theme: 'dark' }))}>🌙 شب</button></div>
      </div>
      <div className="card">
        <b>پروفایل تحصیلی</b>
        <select className="input" value={grade} onChange={(e) => up((x) => ({ ...x, profile: { ...x.profile, done: true, grade: +e.target.value || undefined } }))}>
          <option value={0}>انتخاب نشده</option>
          {GRADES.map((g) => <option key={g.id} value={g.id}>{g.title}</option>)}
        </select>
        {grade >= 10 && (
          <select className="input" value={s.profile.field ?? ''} onChange={(e) => up((x) => ({ ...x, profile: { ...x.profile, field: e.target.value }, fields: { ...x.fields, [grade]: e.target.value } }))}>
            <option value="">رشته…</option>
            {FIELDS.map((f) => <option key={f} value={f}>{f}</option>)}
          </select>
        )}
      </div>
      <div className="card">
        <b>سرویس هوش مصنوعی</b>
        <p className="muted small">نشانی سرور واسط (بدون کلید API). راهنما در فایل docs/AI-SETUP.md.</p>
        <input className="input" dir="ltr" placeholder="https://your-server.example.com" value={api} onChange={(e) => setApi(e.target.value)} />
        <div className="row"><button className="btn primary" onClick={() => { up((x) => ({ ...x, apiUrl: api.trim() })); setMsg('ذخیره شد.'); }}>ذخیره</button><button className="btn" onClick={test}>آزمایش اتصال</button></div>
      </div>
      <div className="card">
        <b>داده‌ها</b>
        <div className="row wrap">
          <button className="btn" onClick={exportData}>⬇️ پشتیبان‌گیری</button>
          <label className="btn">⬆️ بازیابی<input type="file" accept="application/json" hidden onChange={(e) => importData(e.target.files?.[0])} /></label>
          <button className="btn" onClick={() => confirm('همه اطلاعات پیشرفت پاک شود؟') && up((x) => ({ ...defaultState, theme: x.theme, apiUrl: x.apiUrl }))}>🗑️ پاک‌کردن پیشرفت</button>
        </div>
      </div>
      {msg && <p className="win">{msg}</p>}
      <h3>اطلاعات برنامه</h3>
      <InfoTable />
      <button className="btn full" onClick={() => go('/about')}>درباره ما</button>
      <button className="btn full" onClick={() => go('/admin')}>🔐 پنل مدیریت</button>
      <Credits />
    </div>
  );
}
