import { useState } from 'react';
import { BOOKS, bookQuestions } from '../data/content';
import type { Question } from '../data/types';
import { StatusBadge } from '../components/Quiz';
import { useApp } from '../state';
import { fa } from '../utils';

const label = (q: Question) => (q.type === 'mcq' ? q.options[q.answer] : q.type === 'tf' ? (q.answer ? 'درست' : 'نادرست') : q.answer);
const TN: Record<string, string> = { mcq: 'چهارگزینه‌ای', tf: 'درست/نادرست', blank: 'جای‌خالی', essay: 'تشریحی' };

export default function Answers() {
  const { s, custom } = useApp();
  const sources = [
    ...BOOKS.filter((b) => bookQuestions(b).length).map((b) => ({ id: 'b:' + b.id, title: b.title, groups: b.chapters.flatMap((c) => c.lessons.filter((l) => l.content?.exercises.length).map((l) => ({ name: `${c.title} — ${l.title}`, qs: l.content!.exercises }))) })),
    ...[...custom.exams, ...s.aiExams].map((e) => ({ id: 'e:' + e.id, title: `${e.ai ? '🤖 ' : ''}${e.title}`, groups: [{ name: 'سؤال‌ها', qs: e.questions }] }))
  ];
  const [sel, setSel] = useState(sources[0]?.id ?? '');
  const [onlyReview, setOnlyReview] = useState(false);
  const [q, setQ] = useState('');
  const src = sources.find((x) => x.id === sel);
  return (
    <div>
      <h2>✅ پاسخ‌نامه</h2>
      <p className="muted small">پاسخ‌های تأییدشده با منبع رسمی، برچسب «تأییدشده» دارند. پاسخ‌های دیگر «نیازمند بررسی» هستند و نباید به‌عنوان پاسخ رسمی تلقی شوند.</p>
      {sources.length === 0 ? <div className="card warn-box">🚧 هنوز پاسخ‌نامه‌ای ثبت نشده است.</div> : (
        <>
          <select className="input" value={sel} onChange={(e) => setSel(e.target.value)}>{sources.map((x) => <option key={x.id} value={x.id}>{x.title}</option>)}</select>
          <input className="input" placeholder="جست‌وجو در سؤال‌ها…" value={q} onChange={(e) => setQ(e.target.value)} />
          <label className="row"><input type="checkbox" checked={onlyReview} onChange={(e) => setOnlyReview(e.target.checked)} /> فقط «نیازمند بررسی»</label>
          {src?.groups.map((g, gi) => (
            <div key={gi}>
              <h3>{g.name}</h3>
              {g.qs.filter((x) => (!onlyReview || x.status !== 'verified') && (!q.trim() || x.q.includes(q.trim()))).map((x, i) => (
                <div className="card" key={i}>
                  <div className="qtext">{fa(i + 1)}. {fa(x.q)} <span className="badge">{TN[x.type]}</span></div>
                  <div>پاسخ: <b>{fa(label(x))}</b></div>
                  <div className="muted">علت درستی: {fa(x.explain)}</div>
                  <StatusBadge q={x} />
                </div>
              ))}
            </div>
          ))}
        </>
      )}
    </div>
  );
}
