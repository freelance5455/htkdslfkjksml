import { APP } from '../appinfo';
import { Credits, InfoTable } from './Shared';

export default function About() {
  return (
    <div>
      <div className="hero">
        <img src="icons/icon-192.png" alt={APP.name} />
        <div>
          <h1>{APP.name}</h1>
          <p>{APP.slogan}</p>
        </div>
      </div>
      <h3>درباره برنامه</h3>
      <p>«{APP.name}» یک سامانه آموزشی فارسی برای دانش‌آموزان ایران از پایه اول ابتدایی تا دوازدهم است: کتاب‌های درسی، آموزش گام‌به‌گام، پاسخ‌نامه، آزمون، برنامه‌ریزی مطالعه، بازی آموزشی و دستیار هوش مصنوعی.</p>
      <h3>اطلاعات برنامه</h3>
      <InfoTable />
      <p className="muted small">محتوای درسی بر پایه کتاب‌های رسمی آموزش‌وپرورش ایران تنظیم می‌شود و پیش از انتشار باید با نسخه چاپ جاری تطبیق داده شود. محتوای تکمیل‌نشده به‌صراحت «تکمیل‌نشده» نمایش داده می‌شود.</p>
      <Credits />
    </div>
  );
}
