import { useState } from 'react';
import { BOOKS, CONTENT_YEAR, bookQuestions, chapterQuestions, findBook } from '../data/content';
import { FIELDS, GRADES, TRACK_FIELDS, gradeTitle } from '../data/grades';
import type { Book } from '../data/types';
import { kvGet } from '../db';
import { useApp } from '../state';
import { fa, shamsi } from '../utils';
import { go } from './Shared';

const OFFICIAL = 'https://chap.sch.ir/';

function Cover({ b }: { b: Book }) {
  return b.cover ? <img className="cover" src={b.cover} alt={b.title} /> : <div className="cover" style={{ background: b.color }}>{b.icon}</div>;
}

function BookCard({ b }: { b: Book }) {
  const { s, up } = useApp();
  const fav = s.bookFavs.includes(b.id);
  return (
    <div className="bookcard">
      <button className="bookmain" onClick={() => go('/book/' + b.id)}>
        <Cover b={b} />
        <b>{b.title}</b>
        <small className="muted">{b.field ?? 'مشترک'}{b.track ? ` · ${b.track}` : ''}</small>
        <small className="muted">سال تحصیلی {b.year ? fa(b.year) : '—'}</small>
        <small>{b.chapters.length ? `${fa(b.chapters.length)} فصل` : 'تکمیل‌نشده'}</small>
      </button>
      <button className="star fav" aria-label="علاقه‌مندی" onClick={() => up((x) => ({ ...x, bookFavs: fav ? x.bookFavs.filter((i) => i !== b.id) : [...x.bookFavs, b.id] }))}>{fav ? '⭐' : '☆'}</button>
    </div>
  );
}

export function GradePage({ id }: { id: number }) {
  const { s, up, custom } = useApp();
  const [q, setQ] = useState('');
  const [track, setTrack] = useState('');
  const g = GRADES.find((x) => x.id === id);
  if (!g) return <p>پایه پیدا نشد.</p>;
  const needsField = id >= 10;
  const field = s.fields[id] ?? '';
  const hasTracks = TRACK_FIELDS.includes(field);
  const tracks = custom.tracks.filter((t) => t.gradeId === id && t.field === field);
  const groups = Array.from(new Set(tracks.map((t) => t.group)));
  const all = BOOKS.filter((b) => b.gradeId === id)
    .filter((b) => !needsField || !field || !b.field || b.field === field)
    .filter((b) => !hasTracks || !track || !b.track || b.track === track)
    .filter((b) => !q.trim() || b.title.includes(q.trim()));
  const current = all.filter((b) => !b.archived);
  const archive = all.filter((b) => b.archived);

  return (
    <div>
      <h2>{g.title}</h2>
      {needsField && (
        <>
          <p className="muted">رشته تحصیلی:</p>
          <div className="chips">
            {FIELDS.map((f) => (
              <button key={f} className={'chip' + (field === f ? ' on' : '')} onClick={() => { setTrack(''); up((x) => ({ ...x, fields: { ...x.fields, [id]: f } })); }}>{f}</button>
            ))}
          </div>
          {hasTracks && (
            <div className="card">
              <b>زمینه، گروه و رشته‌های {field}</b>
              {tracks.length === 0 ? (
                <p className="muted small">زمینه‌ها و رشته‌های این بخش هنوز ثبت نشده‌اند. مدیر می‌تواند از پنل مدیریت (بخش «پایه‌ها و رشته‌ها») فهرست رسمی را وارد کند. مرجع رسمی: chap.sch.ir</p>
              ) : (
                groups.map((gr) => (
                  <div key={gr}>
                    <small className="muted">{gr}</small>
                    <div className="chips">
                      {tracks.filter((t) => t.group === gr).map((t) => <button key={t.id} className={'chip' + (track === t.name ? ' on' : '')} onClick={() => setTrack(track === t.name ? '' : t.name)}>{t.name}</button>)}
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </>
      )}
      <input className="input" placeholder="جست‌وجوی نام کتاب…" value={q} onChange={(e) => setQ(e.target.value)} />
      {all.length === 0 ? (
        <div className="card warn-box">
          🚧 کتاب‌های این پایه{needsField && !field ? ' (پس از انتخاب رشته)' : ''} هنوز در برنامه ثبت نشده‌اند. برای جلوگیری از اطلاعات نادرست، فهرست ساختگی نمایش داده نمی‌شود. مدیر می‌تواند کتاب‌ها را از پنل مدیریت اضافه یا فهرست رسمی (JSON) را وارد کند.
          <br /><a href={OFFICIAL} target="_blank" rel="noopener noreferrer">مرجع رسمی کتاب‌ها: chap.sch.ir</a>
        </div>
      ) : (
        <>
          <p className="muted small">سال تحصیلی محتوای نمونه: {CONTENT_YEAR}. فهرست‌ها باید با فهرست رسمی هر سال تطبیق داده شوند.</p>
          <div className="cards two">{current.map((b) => <BookCard key={b.id} b={b} />)}</div>
          {archive.length > 0 && (
            <>
              <h3>🗄️ آرشیو (سال‌های گذشته)</h3>
              <div className="cards two">{archive.map((b) => <BookCard key={b.id} b={b} />)}</div>
            </>
          )}
        </>
      )}
    </div>
  );
}

function PdfButton({ b }: { b: Book }) {
  const [msg, setMsg] = useState('');
  async function open() {
    try {
      const blob = await kvGet<Blob>('pdf:' + b.id);
      if (!blob) return setMsg('فایل PDF در این دستگاه پیدا نشد.');
      window.open(URL.createObjectURL(blob), '_blank');
    } catch {
      setMsg('باز کردن PDF ممکن نشد.');
    }
  }
  return (
    <div>
      {b.pdfUrl && <a className="btn" href={b.pdfUrl} target="_blank" rel="noopener noreferrer">📄 مشاهده PDF (پیوند رسمی)</a>}
      {b.hasPdf && <button className="btn" onClick={open}>📄 باز کردن PDF ذخیره‌شده (آفلاین)</button>}
      {msg && <p className="muted small">{msg}</p>}
    </div>
  );
}

export function BookPage({ id }: { id: string }) {
  const { s, up, custom } = useApp();
  const [q, setQ] = useState('');
  const b = findBook(id);
  if (!b) return <p>کتاب پیدا نشد.</p>;
  const toggle = (lid: string) => up((x) => ({ ...x, bookmarks: x.bookmarks.includes(lid) ? x.bookmarks.filter((i) => i !== lid) : [...x.bookmarks, lid] }));
  const t = q.trim();
  const fav = s.bookFavs.includes(b.id);
  const versions = custom.versions.filter((v) => v.bookId === b.id);
  // جست‌وجو در عنوان فصل/درس و متن محتوای درس
  const textOf = (l: Book['chapters'][number]['lessons'][number]) => l.content ? [...l.content.explain, ...l.content.steps, ...l.content.tips, ...l.content.summary, ...l.content.examples.flatMap((e) => [e.q, e.a])].join(' ') : '';
  const lessonHit = (l: Book['chapters'][number]['lessons'][number]) => !t || l.title.includes(t) || textOf(l).includes(t);

  return (
    <div>
      <div className="row between">
        <h2>{b.icon} {b.title}</h2>
        <button className="star" onClick={() => up((x) => ({ ...x, bookFavs: fav ? x.bookFavs.filter((i) => i !== b.id) : [...x.bookFavs, b.id] }))}>{fav ? '⭐' : '☆'}</button>
      </div>
      <div className="card">
        <div className="row"><Cover b={b} />
          <div>
            <div>پایه: <b>{gradeTitle(b.gradeId)}</b></div>
            <div>رشته: <b>{b.field ?? 'مشترک'}</b>{b.track ? ` — ${b.track}` : ''}</div>
            <div>سال تحصیلی: <b>{b.year ? fa(b.year) : '—'}</b> {b.archived && <span className="badge warn">آرشیو</span>}</div>
            <a href={b.sourceUrl ?? OFFICIAL} target="_blank" rel="noopener noreferrer" className="small">منبع رسمی</a>
          </div>
        </div>
        <PdfButton b={b} />
        {versions.length > 0 && (
          <details>
            <summary>نسخه‌های ثبت‌شده ({fa(versions.length)})</summary>
            {versions.map((v) => <p key={v.id} className="small">{fa(v.year)} — {v.note || 'بدون توضیح'} <span className="muted">({shamsi(new Date(v.t).toISOString().slice(0, 10))})</span></p>)}
          </details>
        )}
      </div>
      {b.chapters.length === 0 ? (
        <div className="card warn-box">🚧 فهرست فصل‌ها و درس‌های این کتاب هنوز تکمیل نشده است.</div>
      ) : (
        <>
          <input className="input" placeholder="جست‌وجو در کتاب (عنوان و متن درس‌ها)…" value={q} onChange={(e) => setQ(e.target.value)} />
          {b.chapters.filter((c) => !t || c.title.includes(t) || c.lessons.some(lessonHit)).map((c) => (
            <div className="card" key={c.id}>
              <div className="row between"><b>{c.title}</b>{chapterQuestions(c).length > 0 && <button className="btn" onClick={() => go('/exam/' + c.id)}>آزمون فصل</button>}</div>
              {c.lessons.length === 0 && <p className="muted small">محتوای این فصل هنوز تکمیل نشده است.</p>}
              {c.lessons.filter((l) => !t || c.title.includes(t) || lessonHit(l)).map((l) => (
                <div className="row between" key={l.id}>
                  <button className="list-item" onClick={() => go('/lesson/' + l.id)}>📝 {l.title}</button>
                  <button className="star" aria-label="نشان‌کردن" onClick={() => toggle(l.id)}>{s.bookmarks.includes(l.id) ? '⭐' : '☆'}</button>
                </div>
              ))}
            </div>
          ))}
          {bookQuestions(b).length > 0 && <button className="btn primary full" onClick={() => go('/exam/' + b.id)}>آزمون پایان کتاب</button>}
        </>
      )}
    </div>
  );
}
