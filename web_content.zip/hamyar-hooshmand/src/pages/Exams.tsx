import { useState } from 'react';
import { BOOKS, allLessons, bookQuestions, chapterQuestions, findBook } from '../data/content';
import { EXAM_KINDS, ExamKind, Level, Question } from '../data/types';
import Quiz from '../components/Quiz';
import { useApp } from '../state';
import { fa, fmtDate, fmtTime, shuffle } from '../utils';
import { go } from './Shared';

type Rec = { id: string; title: string; score: number; total: number; t: number; level?: string; secs?: number };

function useSave() {
  const { up } = useApp();
  return (id: string, title: string, level?: string) => (sc: number, tot: number, secs: number) =>
    up((x) => ({ ...x, results: [{ id, title, score: sc, total: tot, t: Date.now(), level, secs } as Rec, ...x.results].slice(0, 200) }));
}

const TYPES: Record<string, string> = { all: 'همه', mcq: 'چهارگزینه‌ای', tf: 'درست/نادرست', blank: 'جای‌خالی', essay: 'تشریحی' };
const LEVELS: Record<string, string> = { all: 'همه سطوح', '1': 'آسان', '2': 'متوسط', '3': 'سخت' };

export function Exams() {
  const { s, custom } = useApp();
  const save = useSave();
  const [tab, setTab] = useState<'build' | 'ready' | 'records'>('build');
  const withQ = BOOKS.filter((b) => bookQuestions(b).length > 0);
  const [bookId, setBookId] = useState(withQ[0]?.id ?? '');
  const [chapterId, setChapterId] = useState('');
  const [type, setType] = useState('all');
  const [level, setLevel] = useState('all');
  const [count, setCount] = useState(10);
  const [minutes, setMinutes] = useState(0);
  const [run, setRun] = useState<{ qs: Question[]; min: number; title: string; lv: string } | null>(null);
  const book = findBook(bookId);

  function start() {
    if (!book) return;
    const base = chapterId ? chapterQuestions(book.chapters.find((c) => c.id === chapterId) ?? { lessons: [] }) : bookQuestions(book);
    let qs = base.filter((q) => type === 'all' || q.type === type).filter((q) => level === 'all' || q.level === (Number(level) as Level));
    qs = shuffle(qs).slice(0, Math.max(1, count));
    if (!qs.length) return alert('سؤالی با این شرایط پیدا نشد. محتوای بیشتر از پنل مدیریت اضافه می‌شود.');
    setRun({ qs, min: minutes || Math.max(1, qs.length), title: `آزمون ${book.title}`, lv: LEVELS[level] });
  }

  const ready = [...custom.exams, ...s.aiExams];
  const kinds = Object.keys(EXAM_KINDS) as ExamKind[];

  return (
    <div>
      <h2>📝 آزمون‌ها</h2>
      <div className="tabs">
        <button className={tab === 'build' ? 'on' : ''} onClick={() => setTab('build')}>ساخت آزمون</button>
        <button className={tab === 'ready' ? 'on' : ''} onClick={() => setTab('ready')}>آزمون‌های آماده</button>
        <button className={tab === 'records' ? 'on' : ''} onClick={() => setTab('records')}>سوابق</button>
      </div>

      {tab === 'build' && (run ? (
        <div>
          <button className="btn" onClick={() => setRun(null)}>⬅️ تنظیمات آزمون</button>
          <Quiz title={run.title} questions={run.qs} minutes={run.min} onFinish={save(bookId, run.title, run.lv)} />
        </div>
      ) : withQ.length === 0 ? (
        <div className="card warn-box">🚧 هنوز کتابی با سؤال ثبت نشده است.</div>
      ) : (
        <div className="card">
          <label>کتاب</label>
          <select className="input" value={bookId} onChange={(e) => { setBookId(e.target.value); setChapterId(''); }}>{withQ.map((b) => <option key={b.id} value={b.id}>{b.title}</option>)}</select>
          <label>بازه</label>
          <select className="input" value={chapterId} onChange={(e) => setChapterId(e.target.value)}>
            <option value="">آزمون جامع کتاب</option>
            {book?.chapters.filter((c) => chapterQuestions(c).length).map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}
          </select>
          <label>نوع سؤال</label>
          <div className="chips">{Object.entries(TYPES).map(([k, v]) => <button key={k} className={'chip' + (type === k ? ' on' : '')} onClick={() => setType(k)}>{v}</button>)}</div>
          <label>سطح دشواری</label>
          <div className="chips">{Object.entries(LEVELS).map(([k, v]) => <button key={k} className={'chip' + (level === k ? ' on' : '')} onClick={() => setLevel(k)}>{v}</button>)}</div>
          <div className="row">
            <div><label>تعداد سؤال</label><input className="input" type="number" min={1} value={count} onChange={(e) => setCount(+e.target.value)} /></div>
            <div><label>زمان (دقیقه؛ ۰ = خودکار)</label><input className="input" type="number" min={0} value={minutes} onChange={(e) => setMinutes(+e.target.value)} /></div>
          </div>
          <button className="btn primary full" onClick={start}>شروع آزمون</button>
        </div>
      ))}

      {tab === 'ready' && (
        <div>
          {ready.length === 0 && <div className="card warn-box">🚧 هنوز آزمون آماده‌ای ثبت نشده است. مدیر می‌تواند امتحان نوبت اول/دوم، نمونه امتحان نهایی و آزمون فصل را از پنل مدیریت بسازد. آزمون‌های «هوش مصنوعی همیار» هم اینجا ذخیره می‌شوند.</div>}
          {kinds.map((k) => {
            const list = ready.filter((e) => e.kind === k);
            return list.length ? (
              <div key={k}>
                <h3>{EXAM_KINDS[k]}</h3>
                {list.map((e) => <button key={e.id} className="list-item card" onClick={() => go('/exam/' + e.id)}>{e.ai ? '🤖' : '📄'} {e.title} <small className="muted">({fa(e.questions.length)} سؤال، {fa(e.minutes)} دقیقه){e.ai ? ' — نیازمند بررسی' : ''}</small></button>)}
              </div>
            ) : null;
          })}
          <h3>آزمون درس‌ها</h3>
          {allLessons().filter(({ l }) => l.content?.exercises.length).map(({ l, b }) => <button key={l.id} className="list-item card" onClick={() => go('/exam/' + l.id)}>📝 {l.title} <small className="muted">— {b.title}</small></button>)}
        </div>
      )}

      {tab === 'records' && (
        <div>
          {s.results.length === 0 && <p className="muted">هنوز آزمونی نداده‌ای.</p>}
          {s.results.map((r, i) => (
            <div className="card row between" key={i}>
              <span>{r.title}<br /><small className="muted">{fmtDate(r.t)}{r.level ? ` · ${r.level}` : ''}{r.secs ? ` · ${fmtTime(r.secs)}` : ''}</small></span>
              <b>{r.total ? fa(Math.round((r.score / r.total) * 2000) / 100) : '—'} / ۲۰</b>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export function ExamPage({ id }: { id: string }) {
  const { s, custom } = useApp();
  const save = useSave();
  const ex = [...custom.exams, ...s.aiExams].find((e) => e.id === id);
  const book = findBook(id);
  const lesson = allLessons().find((x) => x.l.id === id);
  const chapter = BOOKS.flatMap((b) => b.chapters).find((c) => c.id === id);
  let qs: Question[] = [];
  let title = '';
  let minutes = 0;
  if (ex) { qs = ex.questions; title = ex.title; minutes = ex.minutes; }
  else if (book) { qs = bookQuestions(book); title = `آزمون پایان کتاب ${book.title}`; }
  else if (chapter) { qs = chapterQuestions(chapter); title = `آزمون ${chapter.title}`; }
  else if (lesson) { qs = lesson.l.content?.exercises ?? []; title = `آزمون ${lesson.l.title}`; }
  if (!qs.length) return <p>آزمونی پیدا نشد.</p>;
  return <Quiz title={title} questions={qs} minutes={minutes || qs.length} onFinish={save(id, title)} />;
}
