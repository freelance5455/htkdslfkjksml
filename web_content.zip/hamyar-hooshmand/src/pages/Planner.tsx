import { useEffect, useRef, useState } from 'react';
import { useApp } from '../state';
import { addDays, daysUntil, fa, shamsi, todayISO, uid, weekdayFa } from '../utils';
import { BarChart, DatePick, LineChart } from './Shared';

export function studyMinutes(log: { date: string; minutes: number }[], from: string, to: string) {
  return log.filter((l) => l.date >= from && l.date <= to).reduce((n, l) => n + l.minutes, 0);
}

export default function Planner() {
  const { s, up } = useApp();
  const [tab, setTab] = useState<'today' | 'week' | 'tasks' | 'exams' | 'goals' | 'chart'>('today');
  const [title, setTitle] = useState('');
  const [date, setDate] = useState(todayISO());
  const [minutes, setMinutes] = useState(30);
  const [subject, setSubject] = useState('');
  const [kind, setKind] = useState<'study' | 'homework'>('study');
  const [exTitle, setExTitle] = useState('');
  const [exDate, setExDate] = useState(addDays(todayISO(), 7));
  const [goal, setGoal] = useState('');
  const [manual, setManual] = useState(20);
  const today = todayISO();

  // کرنومتر مطالعه
  const [running, setRunning] = useState(false);
  const [secs, setSecs] = useState(0);
  const t0 = useRef(0);
  useEffect(() => {
    if (!running) return;
    const id = setInterval(() => setSecs(Math.round((Date.now() - t0.current) / 1000)), 1000);
    return () => clearInterval(id);
  }, [running]);
  const logMinutes = (m: number) => m > 0 && up((x) => ({ ...x, studyLog: [...x.studyLog, { date: todayISO(), minutes: m }].slice(-400) }));
  function toggleTimer() {
    if (!running) { t0.current = Date.now(); setSecs(0); setRunning(true); return; }
    setRunning(false);
    logMinutes(Math.max(1, Math.round((Date.now() - t0.current) / 60000)));
  }

  function addTask() {
    if (!title.trim()) return;
    up((x) => ({ ...x, tasks: [...x.tasks, { id: uid(), title: title.trim(), date, minutes, subject: subject.trim(), kind, done: false }] }));
    setTitle('');
  }
  const toggleTask = (id: string) => up((x) => ({ ...x, tasks: x.tasks.map((t) => (t.id === id ? { ...t, done: !t.done } : t)) }));
  const delTask = (id: string) => up((x) => ({ ...x, tasks: x.tasks.filter((t) => t.id !== id) }));
  const TaskRow = ({ t }: { t: (typeof s.tasks)[number] }) => (
    <div className="row between card">
      <label className="row"><input type="checkbox" checked={t.done} onChange={() => toggleTask(t.id)} /><span style={{ textDecoration: t.done ? 'line-through' : 'none' }}>{t.kind === 'homework' ? '📚' : '⏱'} {t.title}{t.subject ? ` (${t.subject})` : ''} <small className="muted">· {fa(t.minutes)} دقیقه</small></span></label>
      <button className="star" onClick={() => delTask(t.id)} aria-label="حذف">🗑️</button>
    </div>
  );

  const week = Array.from({ length: 7 }, (_, i) => addDays(today, i));
  const last7 = Array.from({ length: 7 }, (_, i) => addDays(today, i - 6));
  const mins7 = last7.map((d) => studyMinutes(s.studyLog, d, d));
  const weekTotal = mins7.reduce((a, b) => a + b, 0);
  const pct = Math.min(100, Math.round((weekTotal / Math.max(1, s.weeklyGoal)) * 100));
  const scores = s.results.filter((r) => r.total > 0).slice(0, 10).reverse().map((r) => (r.score / r.total) * 20);
  const TABS: [typeof tab, string][] = [['today', 'امروز'], ['week', 'هفته'], ['tasks', 'تکالیف'], ['exams', 'امتحان‌ها'], ['goals', 'هدف‌ها'], ['chart', 'نمودار']];

  return (
    <div>
      <h2>🗓️ برنامه‌ریزی درسی</h2>
      <p className="muted small">امروز: {weekdayFa(today)} {shamsi(today)}</p>
      <div className="tabs wrapTabs">{TABS.map(([k, v]) => <button key={k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>{v}</button>)}</div>

      {(tab === 'today' || tab === 'week' || tab === 'tasks') && (
        <div className="card">
          <b>افزودن برنامه / تکلیف</b>
          <input className="input" placeholder="عنوان (مثلاً حل تمرین فصل ۱ ریاضی)" value={title} onChange={(e) => setTitle(e.target.value)} />
          <input className="input" placeholder="درس (اختیاری)" value={subject} onChange={(e) => setSubject(e.target.value)} />
          <DatePick value={date} onChange={setDate} />
          <div className="row">
            <input className="input" type="number" min={5} step={5} value={minutes} onChange={(e) => setMinutes(+e.target.value)} />
            <select className="input" value={kind} onChange={(e) => setKind(e.target.value as 'study' | 'homework')}><option value="study">مطالعه</option><option value="homework">تکلیف</option></select>
          </div>
          <button className="btn primary full" onClick={addTask}>ثبت</button>
        </div>
      )}

      {tab === 'today' && (
        <div>
          <div className="card center-text">
            <div className="bigq">{fa(String(Math.floor(secs / 60)).padStart(2, '0') + ':' + String(secs % 60).padStart(2, '0'))}</div>
            <button className="btn primary" onClick={toggleTimer}>{running ? '⏹ پایان و ثبت مطالعه' : '▶️ شروع کرنومتر مطالعه'}</button>
          </div>
          <h3>برنامه امروز</h3>
          {s.tasks.filter((t) => t.date === today).map((t) => <TaskRow key={t.id} t={t} />)}
          {s.tasks.filter((t) => t.date === today).length === 0 && <p className="muted">برای امروز برنامه‌ای ثبت نشده است.</p>}
        </div>
      )}

      {tab === 'week' && week.map((d) => (
        <div key={d}>
          <h3>{weekdayFa(d)} <small className="muted">{shamsi(d)}</small></h3>
          {s.tasks.filter((t) => t.date === d).map((t) => <TaskRow key={t.id} t={t} />)}
          {s.planExams.filter((e) => e.date === d).map((e) => <div className="card warn-box" key={e.id}>⚠️ امتحان: {e.title}</div>)}
        </div>
      ))}

      {tab === 'tasks' && (
        <div>
          <h3>تکالیف</h3>
          {s.tasks.filter((t) => t.kind === 'homework').sort((a, b) => a.date.localeCompare(b.date)).map((t) => <div key={t.id}><small className="muted">{shamsi(t.date)}</small><TaskRow t={t} /></div>)}
          {s.tasks.filter((t) => t.kind === 'homework').length === 0 && <p className="muted">تکلیفی ثبت نشده است.</p>}
        </div>
      )}

      {tab === 'exams' && (
        <div>
          <div className="card">
            <b>ثبت امتحان</b>
            <input className="input" placeholder="نام امتحان" value={exTitle} onChange={(e) => setExTitle(e.target.value)} />
            <DatePick value={exDate} onChange={setExDate} />
            <button className="btn primary full" onClick={() => { if (exTitle.trim()) { up((x) => ({ ...x, planExams: [...x.planExams, { id: uid(), title: exTitle.trim(), date: exDate }] })); setExTitle(''); } }}>ثبت</button>
          </div>
          {[...s.planExams].sort((a, b) => a.date.localeCompare(b.date)).map((e) => {
            const d = daysUntil(e.date);
            return <div className="row between card" key={e.id}><span>🎯 {e.title}<br /><small className="muted">{weekdayFa(e.date)} {shamsi(e.date)} — {d > 0 ? `${fa(d)} روز مانده` : d === 0 ? 'امروز!' : 'گذشته'}</small></span><button className="star" onClick={() => up((x) => ({ ...x, planExams: x.planExams.filter((z) => z.id !== e.id) }))}>🗑️</button></div>;
          })}
        </div>
      )}

      {tab === 'goals' && (
        <div>
          <div className="card">
            <b>هدف مطالعه هفتگی (دقیقه)</b>
            <input className="input" type="number" min={30} step={30} value={s.weeklyGoal} onChange={(e) => up((x) => ({ ...x, weeklyGoal: +e.target.value || 0 }))} />
            <div className="progress"><div style={{ width: pct + '%' }} /></div>
            <small className="muted">{fa(weekTotal)} از {fa(s.weeklyGoal)} دقیقه در ۷ روز اخیر ({fa(pct)}٪)</small>
            <div className="row"><input className="input" type="number" min={1} value={manual} onChange={(e) => setManual(+e.target.value)} /><button className="btn" onClick={() => logMinutes(manual)}>ثبت دستی دقیقه مطالعه</button></div>
          </div>
          <div className="card">
            <b>هدف‌های آموزشی</b>
            <div className="row"><input className="input" placeholder="مثلاً کسب نمره ۲۰ در ریاضی" value={goal} onChange={(e) => setGoal(e.target.value)} /><button className="btn primary" onClick={() => { if (goal.trim()) { up((x) => ({ ...x, goals: [...x.goals, { id: uid(), title: goal.trim(), done: false }] })); setGoal(''); } }}>افزودن</button></div>
            {s.goals.map((g) => <div className="row between" key={g.id}><label className="row"><input type="checkbox" checked={g.done} onChange={() => up((x) => ({ ...x, goals: x.goals.map((z) => (z.id === g.id ? { ...z, done: !z.done } : z)) }))} /> {g.title}</label><button className="star" onClick={() => up((x) => ({ ...x, goals: x.goals.filter((z) => z.id !== g.id) }))}>🗑️</button></div>)}
          </div>
        </div>
      )}

      {tab === 'chart' && (
        <div>
          <div className="card"><b>مطالعه ۷ روز اخیر (دقیقه)</b><BarChart values={mins7} labels={last7.map((d) => weekdayFa(d).slice(0, 3))} unit="دقیقه" /></div>
          <div className="card"><b>نمرات آزمون‌های اخیر (از ۲۰)</b><LineChart values={scores} unit="نمره" /></div>
        </div>
      )}
    </div>
  );
}
