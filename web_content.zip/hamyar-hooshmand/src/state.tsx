import { createContext, useContext } from 'react';
import type { Custom, CustomExam } from './data/types';

export interface ChatMsg { role: 'user' | 'assistant'; text: string; img?: boolean; examId?: string }
export interface Chat { id: string; title: string; t: number; ctx: string; msgs: ChatMsg[] }
export interface Task { id: string; title: string; date: string; minutes: number; subject: string; kind: 'study' | 'homework'; done: boolean }
export interface PlanExam { id: string; title: string; date: string }
export interface Goal { id: string; title: string; done: boolean }
export interface GameStat { plays: number; last: number; total: number }

export interface AppState {
  theme: 'light' | 'dark';
  profile: { done: boolean; grade?: number; field?: string };
  bookmarks: string[];
  bookFavs: string[];
  history: { id: string; t: number }[];
  results: { id: string; title: string; score: number; total: number; t: number; level?: string; secs?: number }[];
  scores: Record<string, number>;
  gstats: Record<string, GameStat>;
  fields: Record<string, string>;
  apiUrl: string;
  chats: Chat[];
  aiExams: CustomExam[];
  tasks: Task[];
  planExams: PlanExam[];
  goals: Goal[];
  weeklyGoal: number;
  studyLog: { date: string; minutes: number }[];
}

export const defaultState: AppState = {
  theme: 'light',
  profile: { done: false },
  bookmarks: [],
  bookFavs: [],
  history: [],
  results: [],
  scores: {},
  gstats: {},
  fields: {},
  apiUrl: '',
  chats: [],
  aiExams: [],
  tasks: [],
  planExams: [],
  goals: [],
  weeklyGoal: 300,
  studyLog: []
};

export interface Ctx {
  s: AppState;
  up: (f: (s: AppState) => AppState) => void;
  custom: Custom;
  upCustom: (f: (c: Custom) => Custom) => void;
}

export const AppCtx = createContext<Ctx>(null as unknown as Ctx);
export const useApp = () => useContext(AppCtx);
