import { useEffect, useState } from 'react';
import type { Question } from '../data/types';
import { fa, fmtTime, toEn } from '../utils';

type Ans = number | boolean | string | undefined;

const norm = (s: string) => toEn(s).replace(/\s/g, '').toLowerCase();

function isCorrect(q: Question, a: Ans): boolean {
  if (a === undefined || q.type === 'essay') return false;
  if (q.type === 'mcq') return a === q.answer;
  if (q.type === 'tf') return a === q.answer;
  return typeof a === 'string' && norm(a) === norm(q.answer);
}

function answerText(q: Question): string {
  if (q.type === 'mcq') return q.options[q.answer];
  if (q.type === 'tf') return q.answer ? 'درست' : 'نادرست';
  return q.answer;
}

export const StatusBadge = ({ q }: { q: Question }) =>
  q.status === 'verified' ? <span className="badge ok">تأییدشده</span> : <span className="badge warn">نیازمند بررسی</span>;

export default function Quiz(props: {
  title: string;
  questions: Question[];
  minutes?: number;
  onFinish?: (correct: number, total: number, secs: number) => void;
}) {
  const { questions, minutes, onFinish } = props;
  const [ans, setAns] = useState<Ans[]>(() => questions.map(() => undefined));
  const [done, setDone] = useState(false);
  const total = minutes ? Math.round(minutes * 60) : 0;
  const [left, setLeft] = useState(total);
  const [selfMark, setSelfMark] = useState<(boolean | undefined)[]>(() => questions.map(() => undefined));
  const [elapsed, setElapsed] = useState(0);

  useEffect(() => {
    if (done) return;
    const id = setInterval(() => {
      setElapsed((x) => x + 1);
      if (minutes) setLeft((x) => x - 1);
    }, 1000);
    return () => clearInterval(id);
  }, [minutes, done]);

  useEffect(() => {
    if (minutes && left <= 0 && !done) finish();
  }, [left]);

  const auto = questions.filter((q) => q.type !== 'essay');
  const correct = questions.reduce((n, q, i) => n + (isCorrect(q, ans[i]) ? 1 : 0), 0);
  const grade = auto.length ? Math.round((correct / auto.length) * 2000) / 100 : 0;
  const essays = questions.filter((q) => q.type === 'essay');
  const essayOk = selfMark.filter((m) => m === true).length;

  function finish() {
    setDone(true);
    onFinish?.(correct, auto.length, elapsed);
  }

  function reset() {
    setAns(questions.map(() => undefined));
    setSelfMark(questions.map(() => undefined));
    setDone(false);
    setElapsed(0);
    setLeft(total);
  }

  const set = (i: number, v: Ans) => setAns((a) => a.map((x, k) => (k === i ? v : x)));

  if (!questions.length) return <p className="muted">برای این بخش هنوز سؤالی ثبت نشده است.</p>;

  return (
    <div>
      <div className="row between">
        <b>{props.title}</b>
        {minutes && !done ? <span className={'timer' + (left < 30 ? ' warn' : '')}>⏱ {fmtTime(left)}</span> : null}
      </div>

      {done && (
        <div className="card result">
          {auto.length > 0 && <div className="big">{fa(grade)} <small>از ۲۰</small></div>}
          {auto.length > 0 && <div>{fa(correct)} پاسخ درست از {fa(auto.length)} سؤال خودکار</div>}
          {essays.length > 0 && <div className="muted">سؤال‌های تشریحی: پاسخ نمونه را ببین و خودت ارزیابی کن ({fa(essayOk)} از {fa(essays.length)} درست)</div>}
          <div className="muted small">زمان: {fmtTime(elapsed)}</div>
          <button className="btn" onClick={reset}>آزمون دوباره</button>
        </div>
      )}

      {questions.map((q, i) => {
        const ok = isCorrect(q, ans[i]);
        return (
          <div className={'card q' + (done && q.type !== 'essay' ? (ok ? ' ok' : ' bad') : '')} key={i}>
            <div className="qtext">{fa(i + 1)}. {fa(q.q)} {q.level ? <span className="badge">{['', 'آسان', 'متوسط', 'سخت'][q.level]}</span> : null}</div>

            {q.type === 'mcq' && (
              <div className="opts">
                {q.options.map((o, k) => (
                  <button key={k} disabled={done} className={'opt' + (ans[i] === k ? ' sel' : '')} onClick={() => set(i, k)}>{fa(o)}</button>
                ))}
              </div>
            )}

            {q.type === 'tf' && (
              <div className="opts two">
                <button disabled={done} className={'opt' + (ans[i] === true ? ' sel' : '')} onClick={() => set(i, true)}>درست</button>
                <button disabled={done} className={'opt' + (ans[i] === false ? ' sel' : '')} onClick={() => set(i, false)}>نادرست</button>
              </div>
            )}

            {q.type === 'blank' && (
              <input className="input" disabled={done} placeholder="پاسخ را بنویس" value={typeof ans[i] === 'string' ? (ans[i] as string) : ''} onChange={(e) => set(i, e.target.value)} />
            )}

            {q.type === 'essay' && (
              <textarea className="input" rows={3} disabled={done} placeholder="پاسخ تشریحی را بنویس" value={typeof ans[i] === 'string' ? (ans[i] as string) : ''} onChange={(e) => set(i, e.target.value)} />
            )}

            {done && (
              <div className="explain">
                {q.type !== 'essay' && <div>{ok ? '✅ درست' : '❌ نادرست'} — پاسخ صحیح: <b>{fa(answerText(q))}</b></div>}
                {q.type === 'essay' && (
                  <>
                    <div>پاسخ نمونه: <b>{fa(q.answer)}</b></div>
                    <div className="row">
                      <button className={'btn' + (selfMark[i] === true ? ' primary' : '')} onClick={() => setSelfMark((m) => m.map((x, k) => (k === i ? true : x)))}>پاسخم درست بود</button>
                      <button className={'btn' + (selfMark[i] === false ? ' primary' : '')} onClick={() => setSelfMark((m) => m.map((x, k) => (k === i ? false : x)))}>نادرست بود</button>
                    </div>
                  </>
                )}
                <div className="muted">{fa(q.explain)} <StatusBadge q={q} /></div>
              </div>
            )}
          </div>
        );
      })}

      {!done && <button className="btn primary full" onClick={finish}>پایان آزمون و مشاهده نمره</button>}
    </div>
  );
}
