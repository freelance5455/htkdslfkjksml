import { useEffect, useRef, useState } from 'react';
import { fa, shuffle } from '../utils';
import type { GameDef, P } from './games';

type QA = { q: string; o: string[]; a: number; lv: 1 | 2 | 3 };

// بانک سؤال‌های علوم و اطلاعات عمومی (موارد کاملاً معتبر و رایج)
const BANK: QA[] = [
  { q: 'آب از کدام عناصر ساخته شده است؟', o: ['هیدروژن و اکسیژن', 'کربن و نیتروژن', 'هلیم و آرگون', 'سدیم و کلر'], a: 0, lv: 1 },
  { q: 'کدام سیاره به «سیاره سرخ» معروف است؟', o: ['زهره', 'مریخ', 'مشتری', 'زحل'], a: 1, lv: 1 },
  { q: 'نزدیک‌ترین سیاره به خورشید کدام است؟', o: ['زمین', 'مریخ', 'تیر (عطارد)', 'زهره'], a: 2, lv: 1 },
  { q: 'بزرگ‌ترین سیاره منظومه شمسی کدام است؟', o: ['زحل', 'مشتری', 'اورانوس', 'نپتون'], a: 1, lv: 1 },
  { q: 'بلندترین قله ایران چیست؟', o: ['علم‌کوه', 'سبلان', 'دماوند', 'زردکوه'], a: 2, lv: 1 },
  { q: 'تعداد ماه‌های سال شمسی چند است؟', o: ['۱۰', '۱۱', '۱۲', '۱۳'], a: 2, lv: 1 },
  { q: 'اولین ماه سال شمسی کدام است؟', o: ['فروردین', 'مهر', 'دی', 'اسفند'], a: 0, lv: 1 },
  { q: 'پایتخت ژاپن کدام شهر است؟', o: ['اوساکا', 'توکیو', 'کیوتو', 'سئول'], a: 1, lv: 1 },
  { q: 'شاعر شاهنامه کیست؟', o: ['سعدی', 'حافظ', 'فردوسی', 'مولوی'], a: 2, lv: 1 },
  { q: 'سراینده «گلستان» و «بوستان» کیست؟', o: ['سعدی', 'نظامی', 'خیام', 'عطار'], a: 0, lv: 1 },
  { q: '۷ × ۸ برابر است با:', o: ['۵۴', '۵۶', '۶۴', '۴۸'], a: 1, lv: 1 },
  { q: 'جذر عدد ۱۴۴ چند است؟', o: ['۱۲', '۱۴', '۱۶', '۱۱'], a: 0, lv: 2 },
  { q: 'نماد شیمیایی طلا کدام است؟', o: ['Ag', 'Fe', 'Au', 'Cu'], a: 2, lv: 2 },
  { q: 'واحد اندازه‌گیری نیرو در SI چیست؟', o: ['ژول', 'نیوتون', 'وات', 'پاسکال'], a: 1, lv: 2 },
  { q: 'گیاهان در فتوسنتز چه گازی جذب می‌کنند؟', o: ['اکسیژن', 'نیتروژن', 'دی‌اکسید کربن', 'هیدروژن'], a: 2, lv: 2 },
  { q: 'صوت در کدام محیط منتشر نمی‌شود؟', o: ['هوا', 'آب', 'فولاد', 'خلأ'], a: 3, lv: 2 },
  { q: 'مجموع زاویه‌های داخلی هر چهارضلعی چند درجه است؟', o: ['۱۸۰', '۲۷۰', '۳۶۰', '۴۵۰'], a: 2, lv: 2 },
  { q: 'کوچک‌ترین عدد اول کدام است؟', o: ['۰', '۱', '۲', '۳'], a: 2, lv: 2 },
  { q: 'عدد اول بعد از ۷ کدام است؟', o: ['۸', '۹', '۱۱', '۱۳'], a: 2, lv: 2 },
  { q: '۲ به توان ۱۰ برابر است با:', o: ['۱۰۰۰', '۱۰۲۴', '۵۱۲', '۲۰۴۸'], a: 1, lv: 3 },
  { q: 'تعداد استخوان‌های بدن انسان بزرگسال تقریباً چند است؟', o: ['۱۰۶', '۲۰۶', '۳۰۶', '۴۰۶'], a: 1, lv: 3 },
  { q: 'کدام یک فلز نیست؟', o: ['آهن', 'مس', 'گوگرد', 'آلومینیوم'], a: 2, lv: 3 },
  { q: 'سرعت نور در خلأ تقریباً چقدر است؟', o: ['۳۰۰ کیلومتر بر ثانیه', '۳۰٬۰۰۰ کیلومتر بر ثانیه', '۳۰۰٬۰۰۰ کیلومتر بر ثانیه', '۳٬۰۰۰٬۰۰۰ کیلومتر بر ثانیه'], a: 2, lv: 3 },
  { q: 'مساحت دایره‌ای به شعاع r از کدام رابطه به دست می‌آید؟', o: ['2πr', 'πr²', 'πr', '2r²'], a: 1, lv: 3 }
];

function Knowledge({ report, live }: P) {
  const [stage, setStage] = useState<1 | 2 | 3>(1);
  const [list, setList] = useState<QA[]>(() => shuffle(BANK.filter((x) => x.lv === 1)).slice(0, 5));
  const [i, setI] = useState(0);
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(3);
  const [pick, setPick] = useState(-1);
  const [over, setOver] = useState(false);
  const [won, setWon] = useState(false);
  const sc = useRef(0);
  const q = list[i];

  function answer(k: number) {
    if (pick >= 0 || over) return;
    setPick(k);
    const ok = k === q.a;
    if (ok) {
      sc.current += 10 * stage;
      setScore(sc.current);
      live?.(sc.current);
    } else setLives((l) => l - 1);
    const nl = ok ? lives : lives - 1;
    setTimeout(() => {
      setPick(-1);
      if (nl <= 0) { setOver(true); report(sc.current); return; }
      if (i + 1 < list.length) return setI(i + 1);
      if (stage === 3) { setWon(true); setOver(true); report(sc.current); return; }
      const ns = (stage + 1) as 2 | 3;
      setStage(ns);
      setList(shuffle(BANK.filter((x) => x.lv === ns)).slice(0, 5));
      setI(0);
    }, 900);
  }

  if (over) return <div><p className="win">{won ? '🏆 هر سه مرحله را گذراندی!' : 'بازی تمام شد'} امتیاز: {fa(score)}</p></div>;
  return (
    <div>
      <div className="row between"><span>مرحله {fa(stage)} از ۳</span><span>{'❤️'.repeat(lives)}</span><span>⭐ {fa(score)}</span></div>
      <p className="muted small">سؤال {fa(i + 1)} از {fa(list.length)}</p>
      <div className="bigq" style={{ fontSize: 20 }}>{fa(q.q)}</div>
      <div className="opts">
        {q.o.map((t, k) => (
          <button key={k} className="opt" style={pick >= 0 ? { borderColor: k === q.a ? '#22a77a' : k === pick ? '#e0486a' : undefined } : undefined} onClick={() => answer(k)}>{fa(t)}</button>
        ))}
      </div>
    </div>
  );
}

// «عدد ضرب» — تمرین جدول ضرب با مرحله‌بندی
function Times({ report, live }: P) {
  const [level, setLevel] = useState(1);
  const [a, setA] = useState(2);
  const [b, setB] = useState(3);
  const [val, setVal] = useState('');
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(3);
  const [over, setOver] = useState(false);
  const [msg, setMsg] = useState('');
  const sc = useRef(0);
  const nq = (lv: number) => { const m = 4 + lv * 2; setA(2 + Math.floor(Math.random() * m)); setB(2 + Math.floor(Math.random() * m)); };
  useEffect(() => nq(1), []);

  function submit() {
    if (!val.trim()) return;
    const n = parseInt(val.replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d))), 10);
    if (n === a * b) {
      sc.current += 10 * level; setScore(sc.current); live?.(sc.current);
      const lv = Math.min(5, 1 + Math.floor(sc.current / 100));
      if (lv !== level) { setLevel(lv); setMsg(`🎉 مرحله ${fa(lv)}`); } else setMsg('✅');
      nq(lv);
    } else {
      setMsg(`❌ ${fa(a)} × ${fa(b)} = ${fa(a * b)}`);
      const nl = lives - 1; setLives(nl);
      if (nl <= 0) { setOver(true); report(sc.current); return; }
      nq(level);
    }
    setVal('');
  }
  if (over) return <p className="win">پایان! امتیاز: {fa(score)} — مرحله {fa(level)}</p>;
  return (
    <div>
      <div className="row between"><span>مرحله {fa(level)}</span><span>{'❤️'.repeat(lives)}</span><span>⭐ {fa(score)}</span></div>
      <div className="bigq" dir="ltr">{fa(a)} × {fa(b)} = ?</div>
      <input className="input" inputMode="numeric" value={val} onChange={(e) => setVal(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && submit()} placeholder="پاسخ" />
      <button className="btn primary full" onClick={submit}>ثبت</button>
      <p className="center-text">{msg}</p>
    </div>
  );
}

export const GAMES3: GameDef[] = [
  { id: 'knowledge', title: 'چالش دانش', icon: '🧪', desc: 'علوم، ریاضی و اطلاعات عمومی در ۳ مرحله', cat: 'آموزشی', color: '#5b6ee1', Comp: Knowledge },
  { id: 'times', title: 'جدول ضرب', icon: '✖️', desc: 'تمرین ضرب با مرحله‌های سخت‌تر', cat: 'آموزشی', color: '#2f7be5', Comp: Times }
];
