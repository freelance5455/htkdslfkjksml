import { useEffect, useMemo, useRef, useState } from 'react';
import { fa, rand, shuffle } from '../utils';

export type Cat = 'آموزشی' | 'فکری' | 'مهارتی';

// report: ثبت امتیاز (رکورد در صورت بیشتربودن ذخیره می‌شود) — live: نمایش امتیاز لحظه‌ای (اختیاری)
export type P = { report: (score: number) => void; live?: (score: number) => void };

export interface GameDef {
  id: string;
  title: string;
  icon: string;
  desc: string;
  help?: string;
  cat?: Cat;
  color: string;
  Comp: (p: P) => JSX.Element;
}

/* ---------- ۱. بازی حافظه ---------- */
function Memory({ report }: P) {
  const EM = ['🍎', '🚀', '⚽', '🌟', '🐱', '📚', '🎈', '🧩'];
  const mk = () => shuffle([...EM, ...EM]);
  const [cards, setCards] = useState<string[]>(mk);
  const [open, setOpen] = useState<number[]>([]);
  const [done, setDone] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  const lock = useRef(false);

  function flip(i: number) {
    if (lock.current || open.includes(i) || done.includes(i)) return;
    const n = [...open, i];
    setOpen(n);
    if (n.length < 2) return;
    const total = moves + 1;
    setMoves(total);
    lock.current = true;
    const [a, b] = n;
    if (cards[a] === cards[b]) {
      const nd = [...done, a, b];
      setTimeout(() => {
        setDone(nd);
        setOpen([]);
        lock.current = false;
        if (nd.length === cards.length) report(Math.max(10, 100 - (total - 8) * 5));
      }, 400);
    } else {
      setTimeout(() => {
        setOpen([]);
        lock.current = false;
      }, 800);
    }
  }

  function restart() {
    setCards(mk());
    setOpen([]);
    setDone([]);
    setMoves(0);
    lock.current = false;
  }

  return (
    <div>
      <p className="muted">جفت‌های یکسان را پیدا کن. حرکت‌ها: {fa(moves)}</p>
      <div className="grid4">
        {cards.map((c, i) => {
          const show = open.includes(i) || done.includes(i);
          return (
            <button key={i} className={'tile big' + (show ? ' shown' : '')} onClick={() => flip(i)}>
              {show ? c : '❓'}
            </button>
          );
        })}
      </div>
      {done.length === cards.length && <p className="win">🎉 آفرین! با {fa(moves)} حرکت تمام شد.</p>}
      <button className="btn" onClick={restart}>شروع دوباره</button>
    </div>
  );
}

/* ---------- ۲. سرعت ریاضی ---------- */
function mkMath() {
  const op = ['+', '-', '×'][rand(0, 2)];
  let a = rand(2, 20);
  let b = rand(2, 20);
  if (op === '-' && b > a) [a, b] = [b, a];
  if (op === '×') {
    a = rand(2, 12);
    b = rand(2, 12);
  }
  const ans = op === '+' ? a + b : op === '-' ? a - b : a * b;
  const s = new Set<number>([ans]);
  while (s.size < 4) s.add(ans + rand(-9, 9));
  return { q: `${fa(a)} ${op} ${fa(b)}`, ans, opts: shuffle([...s]) };
}

function MathSprint({ report }: P) {
  const [phase, setPhase] = useState<'idle' | 'run' | 'over'>('idle');
  const [t, setT] = useState(30);
  const [score, setScore] = useState(0);
  const [q, setQ] = useState(mkMath);
  const sc = useRef(0);

  useEffect(() => {
    if (phase !== 'run') return;
    const id = setInterval(() => setT((x) => x - 1), 1000);
    return () => clearInterval(id);
  }, [phase]);

  useEffect(() => {
    if (phase === 'run' && t <= 0) {
      setPhase('over');
      report(sc.current);
    }
  }, [t, phase]);

  function start() {
    sc.current = 0;
    setScore(0);
    setT(30);
    setQ(mkMath());
    setPhase('run');
  }

  function pick(o: number) {
    if (o === q.ans) {
      sc.current += 1;
      setScore(sc.current);
    }
    setQ(mkMath());
  }

  if (phase === 'idle') return <div><p>در ۳۰ ثانیه تا می‌توانی مسئله حل کن!</p><button className="btn primary" onClick={start}>شروع</button></div>;
  if (phase === 'over') return <div><p className="win">⏰ زمان تمام شد! امتیاز: {fa(score)}</p><button className="btn primary" onClick={start}>دوباره</button></div>;
  return (
    <div>
      <div className="row between"><span>⏱ {fa(t)}</span><span>⭐ {fa(score)}</span></div>
      <div className="bigq" dir="ltr">{q.q} = ?</div>
      <div className="opts two">
        {q.opts.map((o) => <button key={o} className="opt" onClick={() => pick(o)}>{fa(o)}</button>)}
      </div>
    </div>
  );
}

/* ---------- ۳. کلمه درهم‌ریخته ---------- */
const WORDS = ['مدرسه', 'کتابخانه', 'دانشمند', 'معلم', 'ریاضی', 'خورشید', 'مداد', 'دفتر', 'آزمایشگاه', 'کوشش', 'یادگیری', 'تلاش', 'پرچم', 'کارخانه'];

function Scramble({ report }: P) {
  const [list, setList] = useState(() => shuffle(WORDS).slice(0, 6));
  const [i, setI] = useState(0);
  const [guess, setGuess] = useState('');
  const [score, setScore] = useState(0);
  const [msg, setMsg] = useState('');
  const word = list[i];
  const scr = useMemo(() => {
    if (!word) return '';
    let s = word;
    for (let k = 0; k < 6 && s === word; k++) s = shuffle(word.split('')).join('');
    return s;
  }, [word]);

  function next(add: number) {
    const ns = score + add;
    setScore(ns);
    setGuess('');
    if (i + 1 >= list.length) {
      setI(list.length);
      report(ns);
    } else setI(i + 1);
  }

  function check() {
    if (guess.trim() === word) {
      setMsg('✅ درست بود!');
      next(1);
    } else setMsg('❌ دوباره امتحان کن');
  }

  function restart() {
    setList(shuffle(WORDS).slice(0, 6));
    setI(0);
    setScore(0);
    setGuess('');
    setMsg('');
  }

  if (i >= list.length) return <div><p className="win">پایان! امتیاز: {fa(score)} از {fa(list.length)}</p><button className="btn primary" onClick={restart}>دوباره</button></div>;
  return (
    <div>
      <p className="muted">کلمه {fa(i + 1)} از {fa(list.length)} — حروف را مرتب کن</p>
      <div className="row center wrap">{scr.split('').map((c, k) => <span key={k} className="tile">{c}</span>)}</div>
      <input className="input" value={guess} onChange={(e) => setGuess(e.target.value)} placeholder="کلمه درست را بنویس" onKeyDown={(e) => e.key === 'Enter' && check()} />
      <div className="row"><button className="btn primary" onClick={check}>بررسی</button><button className="btn" onClick={() => next(0)}>رد شدن</button></div>
      <p>{msg}</p>
    </div>
  );
}

/* ---------- ۴. دوز ---------- */
const LINES = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
function winner(b: string[]): string {
  for (const [x, y, z] of LINES) if (b[x] && b[x] === b[y] && b[x] === b[z]) return b[x];
  return b.every((c) => c) ? 'd' : '';
}
function minimax(b: string[], turn: string): number {
  const w = winner(b);
  if (w === 'O') return 1;
  if (w === 'X') return -1;
  if (w === 'd') return 0;
  const sc: number[] = [];
  b.forEach((c, i) => {
    if (!c) {
      const n = [...b];
      n[i] = turn;
      sc.push(minimax(n, turn === 'O' ? 'X' : 'O'));
    }
  });
  return turn === 'O' ? Math.max(...sc) : Math.min(...sc);
}
function aiMove(b: string[]): number {
  const empty = b.map((c, i) => (c ? -1 : i)).filter((i) => i >= 0);
  if (Math.random() < 0.3) return empty[rand(0, empty.length - 1)];
  let best = empty[0];
  let bs = -2;
  for (const i of empty) {
    const n = [...b];
    n[i] = 'O';
    const s = minimax(n, 'X');
    if (s > bs) {
      bs = s;
      best = i;
    }
  }
  return best;
}

function TicTacToe({ report }: P) {
  const [b, setB] = useState<string[]>(Array(9).fill(''));
  const [wins, setWins] = useState(0);
  const w = winner(b);

  function play(i: number) {
    if (b[i] || w) return;
    let n = [...b];
    n[i] = 'X';
    if (!winner(n)) n[aiMove(n)] = 'O';
    setB(n);
    if (winner(n) === 'X') {
      setWins(wins + 1);
      report(wins + 1);
    }
  }

  return (
    <div>
      <p className="muted">تو X هستی. برد در این نشست: {fa(wins)}</p>
      <div className="grid3">
        {b.map((c, i) => <button key={i} className="tile big" onClick={() => play(i)}>{c}</button>)}
      </div>
      {w && <p className="win">{w === 'X' ? '🎉 بردی!' : w === 'O' ? '😅 باختی' : '🤝 مساوی'}</p>}
      <button className="btn" onClick={() => setB(Array(9).fill(''))}>بازی جدید</button>
    </div>
  );
}

/* ---------- ۵. حدس عدد ---------- */
function Guess({ report }: P) {
  const [secret, setSecret] = useState(() => rand(1, 100));
  const [v, setV] = useState('');
  const [tries, setTries] = useState(0);
  const [msg, setMsg] = useState('عددی بین ۱ تا ۱۰۰ را حدس بزن');
  const [won, setWon] = useState(false);

  function go() {
    const n = parseInt(v.replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d))), 10);
    if (isNaN(n)) return;
    const t = tries + 1;
    setTries(t);
    setV('');
    if (n === secret) {
      setWon(true);
      setMsg(`🎉 درست حدس زدی! ${fa(t)} تلاش`);
      report(Math.max(10, 110 - t * 10));
    } else setMsg(n < secret ? '⬆️ بزرگ‌تر' : '⬇️ کوچک‌تر');
  }

  function restart() {
    setSecret(rand(1, 100));
    setTries(0);
    setWon(false);
    setV('');
    setMsg('عددی بین ۱ تا ۱۰۰ را حدس بزن');
  }

  return (
    <div>
      <p className="bigq">{msg}</p>
      {!won && <><input className="input" inputMode="numeric" value={v} onChange={(e) => setV(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && go()} /><button className="btn primary" onClick={go}>حدس بزن</button></>}
      <p className="muted">تلاش‌ها: {fa(tries)}</p>
      {won && <button className="btn" onClick={restart}>بازی جدید</button>}
    </div>
  );
}

/* ---------- ۶. مار ---------- */
const N = 16;
const C = 18;
type Pt = { x: number; y: number };
const spawn = (s: Pt[]): Pt => {
  let f: Pt;
  do f = { x: rand(0, N - 1), y: rand(0, N - 1) };
  while (s.some((p) => p.x === f.x && p.y === f.y));
  return f;
};

function Snake({ report }: P) {
  const cv = useRef<HTMLCanvasElement>(null);
  const g = useRef({ s: [{ x: 8, y: 8 }] as Pt[], d: { x: 1, y: 0 }, nd: { x: 1, y: 0 }, f: { x: 3, y: 3 }, score: 0 });
  const [score, setScore] = useState(0);
  const [run, setRun] = useState(false);
  const [over, setOver] = useState(false);
  const touch = useRef<Pt | null>(null);

  function draw() {
    const c = cv.current?.getContext('2d');
    if (!c) return;
    const s = g.current;
    c.fillStyle = '#e8f3ff';
    c.fillRect(0, 0, N * C, N * C);
    c.fillStyle = '#e0486a';
    c.fillRect(s.f.x * C + 2, s.f.y * C + 2, C - 4, C - 4);
    s.s.forEach((p, i) => {
      c.fillStyle = i === 0 ? '#1d5fd6' : '#22a77a';
      c.fillRect(p.x * C + 1, p.y * C + 1, C - 2, C - 2);
    });
  }

  function dir(dx: number, dy: number) {
    const s = g.current;
    if (dx === -s.d.x && dy === -s.d.y) return;
    s.nd = { x: dx, y: dy };
  }

  function start() {
    g.current = { s: [{ x: 8, y: 8 }], d: { x: 1, y: 0 }, nd: { x: 1, y: 0 }, f: { x: 3, y: 3 }, score: 0 };
    setScore(0);
    setOver(false);
    setRun(true);
  }

  useEffect(() => { draw(); }, []);

  useEffect(() => {
    if (!run) return;
    const id = setInterval(() => {
      const s = g.current;
      s.d = s.nd;
      const h = { x: s.s[0].x + s.d.x, y: s.s[0].y + s.d.y };
      if (h.x < 0 || h.y < 0 || h.x >= N || h.y >= N || s.s.some((p) => p.x === h.x && p.y === h.y)) {
        clearInterval(id);
        setRun(false);
        setOver(true);
        report(s.score);
        return;
      }
      s.s.unshift(h);
      if (h.x === s.f.x && h.y === s.f.y) {
        s.score += 1;
        setScore(s.score);
        s.f = spawn(s.s);
      } else s.s.pop();
      draw();
    }, 160);
    const key = (e: KeyboardEvent) => {
      if (e.key === 'ArrowUp') dir(0, -1);
      if (e.key === 'ArrowDown') dir(0, 1);
      if (e.key === 'ArrowLeft') dir(-1, 0);
      if (e.key === 'ArrowRight') dir(1, 0);
    };
    window.addEventListener('keydown', key);
    return () => {
      clearInterval(id);
      window.removeEventListener('keydown', key);
    };
  }, [run]);

  return (
    <div>
      <p className="muted">امتیاز: {fa(score)} {over && ' — بازی تمام شد'}</p>
      <canvas
        ref={cv}
        width={N * C}
        height={N * C}
        className="canvas"
        onTouchStart={(e) => { touch.current = { x: e.touches[0].clientX, y: e.touches[0].clientY }; }}
        onTouchEnd={(e) => {
          if (!touch.current) return;
          const dx = e.changedTouches[0].clientX - touch.current.x;
          const dy = e.changedTouches[0].clientY - touch.current.y;
          if (Math.abs(dx) > Math.abs(dy)) dir(dx > 0 ? 1 : -1, 0);
          else dir(0, dy > 0 ? 1 : -1);
        }}
      />
      <div className="dpad">
        <button className="opt" onClick={() => dir(0, -1)}>⬆️</button>
        <div className="row center"><button className="opt" onClick={() => dir(-1, 0)}>⬅️</button><button className="opt" onClick={() => dir(0, 1)}>⬇️</button><button className="opt" onClick={() => dir(1, 0)}>➡️</button></div>
      </div>
      {!run && <button className="btn primary" onClick={start}>{over ? 'دوباره' : 'شروع'}</button>}
    </div>
  );
}

/* ---------- ۷. درست یا نادرست ---------- */
const FACTS: [string, boolean][] = [
  ['خورشید یک ستاره است.', true],
  ['عدد ۱ عدد اول است.', false],
  ['مجموع زاویه‌های داخلی هر مثلث ۱۸۰ درجه است.', true],
  ['تهران پایتخت ایران است.', true],
  ['ایران در قاره آفریقا قرار دارد.', false],
  ['قلب انسان چهار حفره دارد.', true],
  ['جذر ۱۶ برابر ۸ است.', false],
  ['فتوسنتز در برگ‌های سبز گیاهان انجام می‌شود.', true],
  ['مساحت مستطیل برابر مجموع طول و عرض آن است.', false],
  ['دماوند بلندترین قله ایران است.', true],
  ['آب خالص در فشار یک اتمسفر در ۱۰۰ درجه سانتی‌گراد می‌جوشد.', true],
  ['زمین از مریخ دورتر از خورشید است.', false]
];

function TrueFalse({ report }: P) {
  const [list, setList] = useState(() => shuffle(FACTS).slice(0, 8));
  const [i, setI] = useState(0);
  const [score, setScore] = useState(0);
  const [fb, setFb] = useState('');

  function ans(v: boolean) {
    const ok = list[i][1] === v;
    const ns = score + (ok ? 1 : 0);
    setScore(ns);
    setFb(ok ? '✅ درست' : '❌ نادرست');
    setTimeout(() => {
      setFb('');
      setI(i + 1);
      if (i + 1 >= list.length) report(ns);
    }, 600);
  }

  function restart() {
    setList(shuffle(FACTS).slice(0, 8));
    setI(0);
    setScore(0);
  }

  if (i >= list.length) return <div><p className="win">امتیاز: {fa(score)} از {fa(list.length)}</p><button className="btn primary" onClick={restart}>دوباره</button></div>;
  return (
    <div>
      <p className="muted">سؤال {fa(i + 1)} از {fa(list.length)}</p>
      <div className="bigq">{fa(list[i][0])}</div>
      <div className="opts two"><button className="opt" disabled={!!fb} onClick={() => ans(true)}>درست</button><button className="opt" disabled={!!fb} onClick={() => ans(false)}>نادرست</button></div>
      <p>{fb}</p>
    </div>
  );
}

/* ---------- ۸. الگوی عددی ---------- */
function mkPattern() {
  const kind = rand(0, 2);
  let seq: number[] = [];
  if (kind === 0) {
    const a = rand(1, 10), d = rand(2, 9);
    seq = [0, 1, 2, 3, 4, 5].map((k) => a + k * d);
  } else if (kind === 1) {
    const a = rand(1, 4), r = rand(2, 3);
    seq = [0, 1, 2, 3, 4, 5].map((k) => a * Math.pow(r, k));
  } else {
    const s = rand(1, 4);
    seq = [0, 1, 2, 3, 4, 5].map((k) => (s + k) * (s + k));
  }
  const ans = seq[5];
  const o = new Set<number>([ans]);
  while (o.size < 4) o.add(ans + rand(-8, 8));
  return { shown: seq.slice(0, 5), ans, opts: shuffle([...o]) };
}

function Pattern({ report }: P) {
  const [r, setR] = useState(0);
  const [q, setQ] = useState(mkPattern);
  const [score, setScore] = useState(0);
  const TOTAL = 8;

  function pick(o: number) {
    const ns = score + (o === q.ans ? 1 : 0);
    setScore(ns);
    if (r + 1 >= TOTAL) report(ns);
    setR(r + 1);
    setQ(mkPattern());
  }

  if (r >= TOTAL) return <div><p className="win">امتیاز: {fa(score)} از {fa(TOTAL)}</p><button className="btn primary" onClick={() => { setR(0); setScore(0); setQ(mkPattern()); }}>دوباره</button></div>;
  return (
    <div>
      <p className="muted">مرحله {fa(r + 1)} از {fa(TOTAL)}</p>
      <div className="bigq" dir="ltr">{q.shown.map(fa).join(' ، ')} ، ?</div>
      <div className="opts two">{q.opts.map((o) => <button key={o} className="opt" onClick={() => pick(o)}>{fa(o)}</button>)}</div>
    </div>
  );
}

/* ---------- ۹. پازل کشویی ---------- */
function mkPuzzle(): number[] {
  let t = [1, 2, 3, 4, 5, 6, 7, 8, 0];
  let blank = 8;
  let prev = -1;
  for (let k = 0; k < 80; k++) {
    const r = Math.floor(blank / 3), c = blank % 3;
    const nb: number[] = [];
    if (r > 0) nb.push(blank - 3);
    if (r < 2) nb.push(blank + 3);
    if (c > 0) nb.push(blank - 1);
    if (c < 2) nb.push(blank + 1);
    const opts = nb.filter((x) => x !== prev);
    const m = opts[rand(0, opts.length - 1)];
    t = [...t];
    [t[blank], t[m]] = [t[m], t[blank]];
    prev = blank;
    blank = m;
  }
  return t;
}

function Sliding({ report }: P) {
  const [t, setT] = useState(mkPuzzle);
  const [moves, setMoves] = useState(0);
  const solved = t.every((v, i) => v === (i + 1) % 9);

  function mv(i: number) {
    if (solved) return;
    const b = t.indexOf(0);
    const dist = Math.abs(Math.floor(i / 3) - Math.floor(b / 3)) + Math.abs((i % 3) - (b % 3));
    if (dist !== 1) return;
    const n = [...t];
    [n[i], n[b]] = [n[b], n[i]];
    setT(n);
    setMoves(moves + 1);
    if (n.every((v, k) => v === (k + 1) % 9)) report(Math.max(10, 200 - (moves + 1)));
  }

  return (
    <div>
      <p className="muted">عددها را از ۱ تا ۸ مرتب کن. حرکت‌ها: {fa(moves)}</p>
      <div className="grid3">
        {t.map((v, i) => <button key={i} className={'tile big' + (v ? ' shown' : ' empty')} onClick={() => mv(i)}>{v ? fa(v) : ''}</button>)}
      </div>
      {solved && <p className="win">🎉 حل شد!</p>}
      <button className="btn" onClick={() => { setT(mkPuzzle()); setMoves(0); }}>پازل جدید</button>
    </div>
  );
}

export const GAMES: GameDef[] = [
  { id: 'memory', title: 'بازی حافظه', icon: '🧠', desc: 'جفت‌های یکسان را پیدا کن', color: '#2f7be5', Comp: Memory },
  { id: 'math', title: 'سرعت ریاضی', icon: '➕', desc: 'در ۳۰ ثانیه چند مسئله حل می‌کنی؟', color: '#22a77a', Comp: MathSprint },
  { id: 'scramble', title: 'کلمه درهم‌ریخته', icon: '🔤', desc: 'حروف را مرتب کن', color: '#8a5cf0', Comp: Scramble },
  { id: 'xo', title: 'دوز', icon: '❌', desc: 'با رایانه دوز بازی کن', color: '#e08a1e', Comp: TicTacToe },
  { id: 'guess', title: 'حدس عدد', icon: '🎯', desc: 'عدد پنهان را پیدا کن', color: '#e0486a', Comp: Guess },
  { id: 'snake', title: 'مار', icon: '🐍', desc: 'غذا بخور و بزرگ شو', color: '#3d9a4a', Comp: Snake },
  { id: 'truefalse', title: 'درست یا نادرست', icon: '✅', desc: 'معلومات عمومی و درسی', color: '#2aa6c9', Comp: TrueFalse },
  { id: 'pattern', title: 'الگوی عددی', icon: '🔢', desc: 'جمله بعدی دنباله چیست؟', color: '#d1a21d', Comp: Pattern },
  { id: 'sliding', title: 'پازل کشویی', icon: '🧩', desc: 'عددها را مرتب کن', color: '#c9733a', Comp: Sliding }
];
