import { GAMES } from './games';
import type { Cat, GameDef } from './games';
import { GAMES2 } from './games2';
import { GAMES3 } from './games3';

export type GameInfo = GameDef & { cat: Cat; help: string; medals: [number, number, number] };

export const CATS: Cat[] = ['آموزشی', 'فکری', 'مهارتی'];

// دسته‌بندی، راهنما و آستانه مدال‌های برنز/نقره/طلا برای هر بازی
const META: Record<string, { cat: Cat; help: string; medals: [number, number, number] }> = {
  memory: { cat: 'فکری', help: 'کارت‌ها را دو‌تا‌دو باز کن و جفت‌های یکسان را پیدا کن. هر چه حرکت کمتر، امتیاز بیشتر.', medals: [40, 70, 90] },
  math: { cat: 'آموزشی', help: 'در ۳۰ ثانیه تا می‌توانی مسئله ریاضی را درست حل کن.', medals: [8, 14, 20] },
  scramble: { cat: 'آموزشی', help: 'حروف درهم‌ریخته را مرتب کن و کلمه را بنویس.', medals: [2, 4, 6] },
  xo: { cat: 'فکری', help: 'با لمس خانه‌ها X بگذار و سه‌تایی بساز. هر برد یک امتیاز دارد.', medals: [1, 3, 5] },
  guess: { cat: 'فکری', help: 'عدد پنهان ۱ تا ۱۰۰ را با کمترین تعداد حدس پیدا کن.', medals: [40, 70, 90] },
  snake: { cat: 'مهارتی', help: 'با کشیدن انگشت یا دکمه‌ها مار را هدایت کن، غذا بخور و به دیوار و بدن نخور.', medals: [5, 12, 25] },
  truefalse: { cat: 'آموزشی', help: 'درست یا نادرست بودن هر جمله را مشخص کن.', medals: [4, 6, 8] },
  pattern: { cat: 'آموزشی', help: 'الگوی عددی را پیدا کن و جمله بعدی را انتخاب کن.', medals: [3, 5, 8] },
  sliding: { cat: 'فکری', help: 'خانه‌ها را جابه‌جا کن تا عددها از ۱ تا ۸ مرتب شوند.', medals: [60, 120, 170] },
  g2048: { cat: 'فکری', help: 'با کشیدن انگشت، خانه‌های هم‌عدد را ترکیب کن تا به ۲۰۴۸ برسی.', medals: [500, 2000, 5000] },
  flappy: { cat: 'مهارتی', help: 'با لمس صفحه پرنده را بالا ببر و از میان لوله‌ها رد شو.', medals: [3, 10, 25] },
  whack: { cat: 'مهارتی', help: 'موش‌ها را لمس کن (+۱) و به بمب‌ها دست نزن (−۲). زمان: ۳۰ ثانیه.', medals: [8, 15, 22] },
  catcher: { cat: 'مهارتی', help: 'سبد را با انگشت بکش و میوه‌ها را بگیر؛ بمب‌ها یک جان کم می‌کنند.', medals: [10, 25, 50] },
  simon: { cat: 'فکری', help: 'ترتیب نورهای رنگی را ببین و به همان ترتیب لمس کن. هر مرحله یک رنگ بیشتر دارد.', medals: [4, 8, 14] },
  stroop: { cat: 'آموزشی', help: 'رنگِ نوشته را انتخاب کن، نه معنی کلمه را. غلط یک امتیاز کم می‌کند.', medals: [8, 15, 22] },
  stack: { cat: 'مهارتی', help: 'با لمس، بلوک متحرک را رها کن تا دقیق روی بلوک قبلی بنشیند.', medals: [8, 20, 40] },
  breaker: { cat: 'مهارتی', help: 'نوار پایین را با انگشت حرکت بده، توپ را برگردان و آجرها را بشکن.', medals: [150, 400, 800] },
  hangman: { cat: 'آموزشی', help: 'حرف‌ها را انتخاب کن تا کلمه پنهان پیدا شود. شش اشتباه مجاز است.', medals: [20, 60, 120] },
  knowledge: { cat: 'آموزشی', help: 'به سؤال‌های علوم، ریاضی و عمومی پاسخ بده. سه مرحله و سه جان داری.', medals: [60, 150, 250] },
  times: { cat: 'آموزشی', help: 'حاصل ضرب را بنویس. با امتیاز بیشتر، عددها بزرگ‌تر می‌شوند.', medals: [50, 150, 300] }
};

export const ALL_GAMES: GameInfo[] = [...GAMES, ...GAMES2, ...GAMES3].map((g) => ({ ...g, ...(META[g.id] ?? { cat: 'فکری' as Cat, help: g.desc, medals: [10, 30, 60] as [number, number, number] }) }));

export function medalOf(g: GameInfo, best: number): { name: string; icon: string; next?: number } {
  const [b, s, gd] = g.medals;
  if (best >= gd) return { name: 'طلایی', icon: '🥇' };
  if (best >= s) return { name: 'نقره‌ای', icon: '🥈', next: gd };
  if (best >= b) return { name: 'برنزی', icon: '🥉', next: s };
  return { name: 'مبتدی', icon: '🎯', next: b };
}
