import { useEffect, useRef, useState } from 'react';
import type { PointerEvent as RPE } from 'react';
import { fa, rand, shuffle } from '../utils';
import type { GameDef, P } from './games';

/* ---------- ابزارهای مشترک بازی‌های بوم (canvas) ---------- */
const W = 320;
const H = 480;

function useLoop(step: (dt: number) => void) {
  const cb = useRef(step);
  cb.current = step;
  useEffect(() => {
    let id = 0;
    let last = performance.now();
    const f = (t: number) => {
      const dt = Math.min(0.04, (t - last) / 1000);
      last = t;
      cb.current(dt);
      id = requestAnimationFrame(f);
    };
    id = requestAnimationFrame(f);
    return () => cancelAnimationFrame(id);
  }, []);
}

const pt = (e: RPE<HTMLCanvasElement>) => {
  const r = e.currentTarget.getBoundingClientRect();
  return { x: ((e.clientX - r.left) * W) / r.width, y: ((e.clientY - r.top) * H) / r.height };
};

function label(c: CanvasRenderingContext2D, s: string, x: number, y: number, size = 22, color = '#fff') {
  c.fillStyle = color;
  c.font = `bold ${size}px Vazirmatn, Tahoma, sans-serif`;
  c.textAlign = 'center';
  c.textBaseline = 'middle';
  c.fillText(s, x, y);
}

function overlay(c: CanvasRenderingContext2D, lines: string[]) {
  c.fillStyle = 'rgba(10,30,70,.55)';
  c.fillRect(0, H / 2 - 70, W, 140);
  lines.forEach((l, i) => label(c, l, W / 2, H / 2 - 35 + i * 36, i === 0 ? 26 : 18));
}

/* ---------- ۱۰. دو هزار و چهل و هشت ---------- */
type Grid = number[][];
const emptyGrid = (): Grid => Array.from({ length: 4 }, () => Array(4).fill(0));

function addTile(g: Grid): Grid {
  const cells: [number, number][] = [];
  g.forEach((r, i) => r.forEach((v, j) => { if (!v) cells.push([i, j]); }));
  if (!cells.length) return g;
  const [i, j] = cells[rand(0, cells.length - 1)];
  const n = g.map((r) => [...r]);
  n[i][j] = Math.random() < 0.9 ? 2 : 4;
  return n;
}

function slideRow(row: number[]) {
  const a = row.filter((v) => v);
  const out: number[] = [];
  let gain = 0;
  for (let i = 0; i < a.length; i++) {
    if (a[i] === a[i + 1]) {
      out.push(a[i] * 2);
      gain += a[i] * 2;
      i++;
    } else out.push(a[i]);
  }
  while (out.length < 4) out.push(0);
  return { row: out, gain };
}

type Dir = 'L' | 'R' | 'U' | 'D';
function moveGrid(g: Grid, dir: Dir) {
  let gain = 0;
  const n = emptyGrid();
  for (let k = 0; k < 4; k++) {
    const line = dir === 'L' || dir === 'R' ? [...g[k]] : g.map((r) => r[k]);
    if (dir === 'R' || dir === 'D') line.reverse();
    const r = slideRow(line);
    gain += r.gain;
    const out = dir === 'R' || dir === 'D' ? [...r.row].reverse() : r.row;
    for (let m = 0; m < 4; m++) {
      if (dir === 'L' || dir === 'R') n[k][m] = out[m];
      else n[m][k] = out[m];
    }
  }
  const moved = n.some((r, i) => r.some((v, j) => v !== g[i][j]));
  return { g: n, gain, moved };
}

const canMove = (g: Grid) => (['L', 'R', 'U', 'D'] as Dir[]).some((d) => moveGrid(g, d).moved);

const TILE_COLORS: Record<number, string> = {
  0: 'rgba(120,150,190,.18)', 2: '#9ec5f8', 4: '#7fb2f2', 8: '#5da0ee', 16: '#3d8ae6', 32: '#22a77a',
  64: '#1e9a6e', 128: '#e0a31e', 256: '#e08a1e', 512: '#e0661e', 1024: '#e0486a', 2048: '#8a5cf0'
};

function Game2048({ report, live }: P) {
  const [g, setG] = useState<Grid>(() => addTile(addTile(emptyGrid())));
  const [score, setScore] = useState(0);
  const [over, setOver] = useState(false);
  const ref = useRef({ g, score, over });
  ref.current = { g, score, over };
  const start = useRef<{ x: number; y: number } | null>(null);

  function act(d: Dir) {
    const s = ref.current;
    if (s.over) return;
    const r = moveGrid(s.g, d);
    if (!r.moved) return;
    const ng = addTile(r.g);
    const ns = s.score + r.gain;
    setG(ng);
    setScore(ns);
    live?.(ns);
    if (r.gain > 0) report(ns);
    if (!canMove(ng)) {
      setOver(true);
      report(ns);
    }
  }

  useEffect(() => {
    const key = (e: KeyboardEvent) => {
      const m: Record<string, Dir> = { ArrowLeft: 'L', ArrowRight: 'R', ArrowUp: 'U', ArrowDown: 'D' };
      if (m[e.key]) {
        e.preventDefault();
        act(m[e.key]);
      }
    };
    window.addEventListener('keydown', key);
    return () => window.removeEventListener('keydown', key);
  }, []);

  const best = Math.max(...g.flat());
  return (
    <div>
      <p className="muted center-text">با کشیدن انگشت، خانه‌های هم‌عدد را ترکیب کن. امتیاز: {fa(score)}</p>
      <div
        className="board"
        onPointerDown={(e) => { start.current = { x: e.clientX, y: e.clientY }; }}
        onPointerUp={(e) => {
          if (!start.current) return;
          const dx = e.clientX - start.current.x;
          const dy = e.clientY - start.current.y;
          start.current = null;
          if (Math.max(Math.abs(dx), Math.abs(dy)) < 24) return;
          if (Math.abs(dx) > Math.abs(dy)) act(dx > 0 ? 'R' : 'L');
          else act(dy > 0 ? 'D' : 'U');
        }}
      >
        {g.flat().map((v, i) => (
          <div key={i} className="cell2048" style={{ background: TILE_COLORS[v] ?? '#8a5cf0', color: v <= 4 ? '#17304f' : '#fff', fontSize: v >= 1024 ? 18 : v >= 128 ? 22 : 26 }}>
            {v ? fa(v) : ''}
          </div>
        ))}
      </div>
      {best >= 2048 && <p className="win">🎉 به ۲۰۴۸ رسیدی!</p>}
      {over && <p className="win">بازی تمام شد — امتیاز: {fa(score)}</p>}
    </div>
  );
}

/* ---------- ۱۱. پرنده ---------- */
function Flappy({ report, live }: P) {
  const cv = useRef<HTMLCanvasElement>(null);
  const fresh = () => ({ phase: 'ready' as 'ready' | 'run' | 'over', y: 240, vy: 0, pipes: [] as { x: number; gap: number; done: boolean }[], next: 0, score: 0, overAt: 0 });
  const g = useRef(fresh());

  function flap() {
    const s = g.current;
    if (s.phase === 'ready') {
      s.phase = 'run';
      s.vy = -280;
      s.next = 0.5;
      live?.(0);
    } else if (s.phase === 'run') s.vy = -280;
    else if (performance.now() - s.overAt > 500) g.current = fresh();
  }

  useLoop((dt) => {
    const s = g.current;
    const c = cv.current?.getContext('2d');
    if (!c) return;
    const bx = 90;
    if (s.phase === 'run') {
      s.vy += 900 * dt;
      s.y += s.vy * dt;
      s.next -= dt;
      if (s.next <= 0) {
        s.pipes.push({ x: W + 10, gap: rand(120, H - 120), done: false });
        s.next = 1.6;
      }
      for (const p of s.pipes) {
        p.x -= 120 * dt;
        if (!p.done && p.x + 52 < bx) {
          p.done = true;
          s.score++;
          live?.(s.score);
        }
        if (bx + 12 > p.x && bx - 12 < p.x + 52 && (s.y - 12 < p.gap - 65 || s.y + 12 > p.gap + 65)) s.phase = 'over';
      }
      s.pipes = s.pipes.filter((p) => p.x > -60);
      if (s.y < 12 || s.y > H - 12) s.phase = 'over';
      if (s.phase === 'over') {
        s.overAt = performance.now();
        report(s.score);
      }
    }
    const sky = c.createLinearGradient(0, 0, 0, H);
    sky.addColorStop(0, '#6fb7ff');
    sky.addColorStop(1, '#d6efff');
    c.fillStyle = sky;
    c.fillRect(0, 0, W, H);
    c.fillStyle = '#22a77a';
    for (const p of s.pipes) {
      c.fillRect(p.x, 0, 52, p.gap - 65);
      c.fillRect(p.x, p.gap + 65, 52, H);
    }
    c.fillStyle = '#ffd23f';
    c.beginPath();
    c.arc(bx, s.y, 12, 0, Math.PI * 2);
    c.fill();
    c.fillStyle = '#17304f';
    c.beginPath();
    c.arc(bx + 4, s.y - 3, 2.5, 0, Math.PI * 2);
    c.fill();
    label(c, fa(s.score), W / 2, 40, 34);
    if (s.phase === 'ready') overlay(c, ['پرنده', 'برای پرواز لمس کن']);
    if (s.phase === 'over') overlay(c, ['برخورد کردی!', `امتیاز: ${fa(s.score)} — لمس برای شروع دوباره`]);
  });

  return <canvas ref={cv} width={W} height={H} className="gcanvas" onPointerDown={flap} />;
}

/* ---------- ۱۲. موش‌زنی ---------- */
function Whack({ report, live }: P) {
  const [phase, setPhase] = useState<'idle' | 'run' | 'over'>('idle');
  const [t, setT] = useState(30);
  const [score, setScore] = useState(0);
  const [cells, setCells] = useState<string[]>(Array(9).fill(''));
  const sc = useRef(0);

  useEffect(() => {
    if (phase !== 'run') return;
    const a = setInterval(() => setT((x) => x - 1), 1000);
    const b = setInterval(() => {
      const n: string[] = Array(9).fill('');
      const i = rand(0, 8);
      n[i] = 'm';
      if (Math.random() < 0.35) {
        const j = rand(0, 8);
        if (j !== i) n[j] = 'b';
      }
      setCells(n);
    }, 700);
    return () => {
      clearInterval(a);
      clearInterval(b);
    };
  }, [phase]);

  useEffect(() => {
    if (phase === 'run' && t <= 0) {
      setPhase('over');
      setCells(Array(9).fill(''));
      report(sc.current);
    }
  }, [t, phase]);

  function start() {
    sc.current = 0;
    setScore(0);
    setT(30);
    live?.(0);
    setPhase('run');
  }

  function hit(i: number) {
    if (phase !== 'run' || !cells[i]) return;
    sc.current = Math.max(0, sc.current + (cells[i] === 'm' ? 1 : -2));
    setScore(sc.current);
    live?.(sc.current);
    setCells((cs) => cs.map((v, k) => (k === i ? '' : v)));
  }

  return (
    <div>
      <div className="row between"><span>⏱ {fa(t)}</span><span>⭐ {fa(score)}</span></div>
      <p className="muted center-text">موش‌ها را بزن (+۱) و از بمب‌ها دوری کن (−۲)</p>
      <div className="holes">
        {cells.map((c, i) => (
          <button key={i} className="hole" onPointerDown={() => hit(i)}>{c === 'm' ? '🐹' : c === 'b' ? '💣' : ''}</button>
        ))}
      </div>
      {phase === 'idle' && <button className="btn primary full" onClick={start}>شروع</button>}
      {phase === 'over' && <><p className="win">⏰ تمام شد! امتیاز: {fa(score)}</p><button className="btn primary full" onClick={start}>دوباره</button></>}
    </div>
  );
}

/* ---------- ۱۳. سبد میوه ---------- */
function Catcher({ report, live }: P) {
  const cv = useRef<HTMLCanvasElement>(null);
  const FR = ['🍎', '🍊', '🍇', '🍓', '🍉'];
  const fresh = () => ({ phase: 'ready' as 'ready' | 'run' | 'over', x: 160, items: [] as { x: number; y: number; e: string; bomb: boolean }[], next: 0, lives: 3, score: 0, overAt: 0 });
  const g = useRef(fresh());

  function down(e: RPE<HTMLCanvasElement>) {
    const s = g.current;
    s.x = pt(e).x;
    if (s.phase === 'ready') {
      s.phase = 'run';
      live?.(0);
    } else if (s.phase === 'over' && performance.now() - s.overAt > 500) g.current = fresh();
  }

  useLoop((dt) => {
    const s = g.current;
    const c = cv.current?.getContext('2d');
    if (!c) return;
    if (s.phase === 'run') {
      s.next -= dt;
      if (s.next <= 0) {
        const bomb = Math.random() < 0.2;
        s.items.push({ x: rand(20, W - 20), y: -20, e: bomb ? '💣' : FR[rand(0, 4)], bomb });
        s.next = Math.max(0.35, 0.9 - s.score * 0.01);
      }
      const speed = Math.min(320, 130 + s.score * 3);
      for (const it of s.items) it.y += speed * dt;
      s.items = s.items.filter((it) => {
        if (it.y > H - 55 && it.y < H - 15 && Math.abs(it.x - s.x) < 42) {
          if (it.bomb) s.lives--;
          else {
            s.score++;
            live?.(s.score);
          }
          return false;
        }
        return it.y < H + 20;
      });
      if (s.lives <= 0) {
        s.phase = 'over';
        s.overAt = performance.now();
        report(s.score);
      }
    }
    const bg = c.createLinearGradient(0, 0, 0, H);
    bg.addColorStop(0, '#b9e4ff');
    bg.addColorStop(1, '#e6f7e9');
    c.fillStyle = bg;
    c.fillRect(0, 0, W, H);
    c.textAlign = 'center';
    c.textBaseline = 'middle';
    c.font = '30px serif';
    for (const it of s.items) c.fillText(it.e, it.x, it.y);
    c.font = '48px serif';
    c.fillText('🧺', s.x, H - 32);
    label(c, `${fa(s.score)}`, W / 2, 34, 32, '#17304f');
    c.font = '20px serif';
    c.textAlign = 'right';
    c.fillText('❤️'.repeat(Math.max(0, s.lives)), W - 10, 34);
    if (s.phase === 'ready') overlay(c, ['سبد میوه', 'سبد را بکش؛ از بمب دوری کن']);
    if (s.phase === 'over') overlay(c, ['بازی تمام شد', `امتیاز: ${fa(s.score)} — لمس برای شروع دوباره`]);
  });

  return <canvas ref={cv} width={W} height={H} className="gcanvas" onPointerDown={down} onPointerMove={(e) => { g.current.x = pt(e).x; }} />;
}

/* ---------- ۱۴. حافظه رنگ‌ها (سایمون) ---------- */
function Simon({ report, live }: P) {
  const COLORS = ['#e0486a', '#2f7be5', '#22a77a', '#e0a31e'];
  const [seq, setSeq] = useState<number[]>([]);
  const [phase, setPhase] = useState<'idle' | 'show' | 'input' | 'over'>('idle');
  const [lit, setLit] = useState(-1);
  const [pos, setPos] = useState(0);
  const timers = useRef<number[]>([]);
  useEffect(() => () => timers.current.forEach((t) => clearTimeout(t)), []);
  const later = (f: () => void, ms: number) => { timers.current.push(window.setTimeout(f, ms)); };

  function play(s: number[]) {
    setPhase('show');
    setPos(0);
    s.forEach((c, i) => {
      later(() => setLit(c), 600 + i * 700);
      later(() => setLit(-1), 600 + i * 700 + 450);
    });
    later(() => setPhase('input'), 600 + s.length * 700);
  }

  function start() {
    const s = [rand(0, 3)];
    setSeq(s);
    live?.(0);
    play(s);
  }

  function tap(c: number) {
    if (phase !== 'input') return;
    setLit(c);
    later(() => setLit(-1), 150);
    if (c !== seq[pos]) {
      setPhase('over');
      report(seq.length - 1);
      return;
    }
    if (pos + 1 === seq.length) {
      const s = [...seq, rand(0, 3)];
      live?.(seq.length);
      report(seq.length);
      setSeq(s);
      setPhase('show');
      later(() => play(s), 700);
    } else setPos(pos + 1);
  }

  return (
    <div>
      <p className="center-text">{phase === 'idle' ? 'ترتیب رنگ‌ها را به خاطر بسپار و تکرار کن' : phase === 'show' ? '👀 نگاه کن…' : phase === 'input' ? '👆 نوبت توست' : `❌ اشتباه شد! مرحله: ${fa(Math.max(0, seq.length - 1))}`}</p>
      <div className="simon">
        {COLORS.map((col, i) => (
          <button key={i} className="pad" style={{ background: col, opacity: lit === i ? 1 : 0.45, transform: lit === i ? 'scale(1.04)' : 'none' }} onPointerDown={() => tap(i)} />
        ))}
      </div>
      {(phase === 'idle' || phase === 'over') && <button className="btn primary full" onClick={start}>{phase === 'idle' ? 'شروع' : 'دوباره'}</button>}
    </div>
  );
}

/* ---------- ۱۵. رنگ و کلمه ---------- */
const SC = [{ n: 'قرمز', c: '#e53935' }, { n: 'آبی', c: '#1e66f5' }, { n: 'سبز', c: '#2e9e4f' }, { n: 'نارنجی', c: '#f08c00' }];
function mkStroop() {
  const w = rand(0, 3);
  let ink = rand(0, 3);
  if (Math.random() < 0.8) while (ink === w) ink = rand(0, 3);
  return { w, ink };
}

function Stroop({ report, live }: P) {
  const [phase, setPhase] = useState<'idle' | 'run' | 'over'>('idle');
  const [t, setT] = useState(30);
  const [score, setScore] = useState(0);
  const [q, setQ] = useState(mkStroop);
  const sc = useRef(0);

  useEffect(() => {
    if (phase !== 'run') return;
    const id = setInterval(() => setT((x) => x - 1), 1000);
    return () => clearInterval(id);
  }, [phase]);

  useEffect(() => {
    if (phase === 'run' && t <= 0) {
      setPhase('over');
      report(sc.current);
    }
  }, [t, phase]);

  function start() {
    sc.current = 0;
    setScore(0);
    setT(30);
    setQ(mkStroop());
    live?.(0);
    setPhase('run');
  }

  function pick(i: number) {
    sc.current = Math.max(0, sc.current + (i === q.ink ? 1 : -1));
    setScore(sc.current);
    live?.(sc.current);
    setQ(mkStroop());
  }

  if (phase === 'idle') return <div><p>رنگِ <b>نوشته</b> را انتخاب کن، نه معنی کلمه را!</p><button className="btn primary full" onClick={start}>شروع</button></div>;
  if (phase === 'over') return <div><p className="win">⏰ تمام شد! امتیاز: {fa(score)}</p><button className="btn primary full" onClick={start}>دوباره</button></div>;
  return (
    <div>
      <div className="row between"><span>⏱ {fa(t)}</span><span>⭐ {fa(score)}</span></div>
      <div className="bigq" style={{ color: SC[q.ink].c, fontSize: 40 }}>{SC[q.w].n}</div>
      <div className="opts two">{SC.map((x, i) => <button key={x.n} className="opt" onPointerDown={() => pick(i)}>{x.n}</button>)}</div>
    </div>
  );
}

/* ---------- ۱۶. برج‌سازی ---------- */
function Stack({ report, live }: P) {
  const cv = useRef<HTMLCanvasElement>(null);
  const BH = 22;
  const fresh = () => ({ phase: 'ready' as 'ready' | 'run' | 'over', blocks: [{ x: 80, w: 160 }], cur: { x: 0, w: 160, dir: 1 }, score: 0, overAt: 0, perfect: 0, msg: '' });
  const g = useRef(fresh());

  function tap() {
    const s = g.current;
    if (s.phase === 'ready') {
      s.phase = 'run';
      s.cur = { x: 0, w: s.blocks[0].w, dir: 1 };
      live?.(0);
      return;
    }
    if (s.phase === 'over') {
      if (performance.now() - s.overAt > 500) g.current = fresh();
      return;
    }
    const prev = s.blocks[s.blocks.length - 1];
    const cur = s.cur;
    const left = Math.max(cur.x, prev.x);
    const right = Math.min(cur.x + cur.w, prev.x + prev.w);
    const ov = right - left;
    if (ov <= 0) {
      s.phase = 'over';
      s.overAt = performance.now();
      report(s.score);
      return;
    }
    let nb: { x: number; w: number };
    if (Math.abs(cur.x - prev.x) < 5) {
      nb = { x: prev.x, w: prev.w };
      s.perfect++;
      s.msg = 'عالی! ✨';
    } else {
      nb = { x: left, w: ov };
      s.msg = '';
    }
    s.blocks.push(nb);
    s.score++;
    live?.(s.score);
    s.cur = { x: cur.x, w: nb.w, dir: cur.dir };
  }

  useLoop((dt) => {
    const s = g.current;
    const c = cv.current?.getContext('2d');
    if (!c) return;
    if (s.phase === 'run') {
      const speed = Math.min(330, 110 + s.score * 7);
      s.cur.x += s.cur.dir * speed * dt;
      if (s.cur.x + s.cur.w > W) {
        s.cur.x = W - s.cur.w;
        s.cur.dir = -1;
      }
      if (s.cur.x < 0) {
        s.cur.x = 0;
        s.cur.dir = 1;
      }
    }
    const bg = c.createLinearGradient(0, 0, 0, H);
    bg.addColorStop(0, '#16336b');
    bg.addColorStop(1, '#5aa0ff');
    c.fillStyle = bg;
    c.fillRect(0, 0, W, H);
    const oy = Math.max(0, s.blocks.length - 10) * BH;
    s.blocks.forEach((b, i) => {
      c.fillStyle = `hsl(${(i * 22) % 360},70%,58%)`;
      c.fillRect(b.x, H - 40 - (i + 1) * BH + oy, b.w, BH - 2);
    });
    if (s.phase === 'run') {
      const i = s.blocks.length;
      c.fillStyle = `hsl(${(i * 22) % 360},70%,58%)`;
      c.fillRect(s.cur.x, H - 40 - (i + 1) * BH + oy, s.cur.w, BH - 2);
    }
    label(c, fa(s.score), W / 2, 36, 34);
    if (s.msg) label(c, s.msg, W / 2, 72, 18, '#ffe27a');
    if (s.phase === 'ready') overlay(c, ['برج‌سازی', 'لمس کن تا بلوک را رها کنی']);
    if (s.phase === 'over') overlay(c, ['برج افتاد!', `طبقه: ${fa(s.score)} — لمس برای شروع دوباره`]);
  });

  return <canvas ref={cv} width={W} height={H} className="gcanvas" onPointerDown={tap} />;
}

/* ---------- ۱۷. آجرشکن ---------- */
function Breaker({ report, live }: P) {
  const cv = useRef<HTMLCanvasElement>(null);
  const mkBricks = () => {
    const cols = ['#e0486a', '#e08a1e', '#e0c01e', '#22a77a', '#2f7be5'];
    const b: { x: number; y: number; c: string; a: boolean }[] = [];
    for (let r = 0; r < 5; r++) for (let k = 0; k < 6; k++) b.push({ x: 10 + k * 50, y: 50 + r * 22, c: cols[r], a: true });
    return b;
  };
  const fresh = () => ({ phase: 'ready' as 'ready' | 'play' | 'over', px: 160, bx: 160, by: 440, vx: 0, vy: 0, bricks: mkBricks(), lives: 3, score: 0, level: 1, overAt: 0 });
  const g = useRef(fresh());

  function down(e: RPE<HTMLCanvasElement>) {
    const s = g.current;
    s.px = Math.min(W - 40, Math.max(40, pt(e).x));
    if (s.phase === 'ready') {
      s.vx = rand(-80, 80);
      s.vy = -(260 + (s.level - 1) * 25);
      s.phase = 'play';
      live?.(s.score);
    } else if (s.phase === 'over' && performance.now() - s.overAt > 500) g.current = fresh();
  }

  useLoop((dt) => {
    const s = g.current;
    const c = cv.current?.getContext('2d');
    if (!c) return;
    if (s.phase === 'ready') {
      s.bx = s.px;
      s.by = 440;
    }
    if (s.phase === 'play') {
      s.bx += s.vx * dt;
      s.by += s.vy * dt;
      if (s.bx < 6) { s.bx = 6; s.vx = Math.abs(s.vx); }
      if (s.bx > W - 6) { s.bx = W - 6; s.vx = -Math.abs(s.vx); }
      if (s.by < 6) { s.by = 6; s.vy = Math.abs(s.vy); }
      if (s.vy > 0 && s.by >= 442 && s.by <= 456 && Math.abs(s.bx - s.px) <= 44) {
        const sp = Math.hypot(s.vx, s.vy);
        s.vx = ((s.bx - s.px) / 44) * sp * 0.8;
        s.vy = -Math.sqrt(sp * sp - s.vx * s.vx);
        s.by = 441;
      }
      if (s.by > H + 10) {
        s.lives--;
        s.vx = 0;
        s.vy = 0;
        if (s.lives <= 0) {
          s.phase = 'over';
          s.overAt = performance.now();
          report(s.score);
        } else s.phase = 'ready';
      }
      for (const b of s.bricks) {
        if (b.a && s.bx > b.x - 6 && s.bx < b.x + 50 && s.by > b.y - 6 && s.by < b.y + 24) {
          b.a = false;
          s.score += 10;
          live?.(s.score);
          const dx = Math.min(Math.abs(s.bx - b.x), Math.abs(s.bx - (b.x + 44)));
          const dy = Math.min(Math.abs(s.by - b.y), Math.abs(s.by - (b.y + 18)));
          if (dx < dy) s.vx = -s.vx;
          else s.vy = -s.vy;
          break;
        }
      }
      if (s.bricks.every((b) => !b.a)) {
        s.level++;
        s.bricks = mkBricks();
        s.phase = 'ready';
        s.vx = 0;
        s.vy = 0;
        report(s.score);
      }
    }
    c.fillStyle = '#10264f';
    c.fillRect(0, 0, W, H);
    for (const b of s.bricks) if (b.a) { c.fillStyle = b.c; c.fillRect(b.x, b.y, 44, 18); }
    c.fillStyle = '#e8f3ff';
    c.fillRect(s.px - 40, 456, 80, 10);
    c.beginPath();
    c.arc(s.bx, s.by, 6, 0, Math.PI * 2);
    c.fillStyle = '#ffd23f';
    c.fill();
    label(c, `${fa(s.score)}`, 50, 22, 20);
    label(c, `مرحله ${fa(s.level)}`, W / 2, 22, 16, '#9ec5f8');
    c.font = '16px serif';
    c.textAlign = 'right';
    c.fillText('❤️'.repeat(Math.max(0, s.lives)), W - 8, 22);
    if (s.phase === 'ready') label(c, 'لمس کن تا توپ پرتاب شود', W / 2, 330, 16, '#9ec5f8');
    if (s.phase === 'over') overlay(c, ['بازی تمام شد', `امتیاز: ${fa(s.score)} — لمس برای شروع دوباره`]);
  });

  return <canvas ref={cv} width={W} height={H} className="gcanvas" onPointerDown={down} onPointerMove={(e) => { g.current.px = Math.min(W - 40, Math.max(40, pt(e).x)); }} />;
}

/* ---------- ۱۸. حدس کلمه (مرد آویزان) ---------- */
const HW: [string, string][] = [
  ['شیر', 'حیوان'], ['خرگوش', 'حیوان'], ['زرافه', 'حیوان'], ['کبوتر', 'حیوان'], ['دلفین', 'حیوان'],
  ['سیب', 'میوه'], ['انار', 'میوه'], ['گیلاس', 'میوه'], ['هندوانه', 'میوه'], ['انگور', 'میوه'],
  ['تهران', 'شهر'], ['شیراز', 'شهر'], ['اصفهان', 'شهر'], ['تبریز', 'شهر'], ['مشهد', 'شهر'],
  ['مثلث', 'درس'], ['خورشید', 'درس'], ['سلول', 'درس'], ['ریاضی', 'درس'], ['مدرسه', 'مدرسه']
];
const LETTERS = 'ا ب پ ت ث ج چ ح خ د ذ ر ز ژ س ش ص ض ط ظ ع غ ف ق ک گ ل م ن و ه ی'.split(' ');

function Hangman({ report, live }: P) {
  const [list] = useState(() => shuffle(HW));
  const [i, setI] = useState(0);
  const [used, setUsed] = useState<string[]>([]);
  const [score, setScore] = useState(0);
  const [over, setOver] = useState(false);
  const [word, cat] = list[i % list.length];
  const wrong = used.filter((l) => !word.includes(l)).length;
  const solved = word.split('').every((ch) => used.includes(ch));

  function pick(l: string) {
    if (over || solved || used.includes(l)) return;
    const nu = [...used, l];
    setUsed(nu);
    const w = nu.filter((x) => !word.includes(x)).length;
    if (w >= 6) {
      setOver(true);
      report(score);
    } else if (word.split('').every((ch) => nu.includes(ch))) {
      const ns = score + 10 + (6 - w);
      setScore(ns);
      live?.(ns);
      report(ns);
    }
  }

  return (
    <div>
      <div className="row between"><span>دسته: {cat}</span><span>{'❤️'.repeat(6 - wrong)}{'🖤'.repeat(wrong)}</span></div>
      <div className="row center wrap" dir="rtl">
        {word.split('').map((ch, k) => <span key={k} className="tile">{used.includes(ch) || over ? ch : '_'}</span>)}
      </div>
      {over && <p className="win">باختی! کلمه «{word}» بود. امتیاز: {fa(score)}</p>}
      {solved && !over && <><p className="win">🎉 درست بود!</p><button className="btn primary full" onClick={() => { setI(i + 1); setUsed([]); }}>کلمه بعدی</button></>}
      <div className="keys" dir="rtl">
        {LETTERS.map((l) => (
          <button key={l} className={'key' + (used.includes(l) ? (word.includes(l) ? ' good' : ' bad') : '')} disabled={used.includes(l) || over || solved} onClick={() => pick(l)}>{l}</button>
        ))}
      </div>
    </div>
  );
}

export const GAMES2: GameDef[] = [
  { id: 'g2048', title: '۲۰۴۸', icon: '🔢', desc: 'خانه‌های هم‌عدد را ترکیب کن', help: 'با کشیدن انگشت', cat: 'فکری', color: '#e0a31e', Comp: Game2048 },
  { id: 'flappy', title: 'پرنده', icon: '🐤', desc: 'از لابه‌لای لوله‌ها رد شو', cat: 'مهارتی', color: '#2aa6c9', Comp: Flappy },
  { id: 'whack', title: 'موش‌زنی', icon: '🔨', desc: 'موش‌ها را بزن، بمب نه!', cat: 'مهارتی', color: '#c9733a', Comp: Whack },
  { id: 'catcher', title: 'سبد میوه', icon: '🧺', desc: 'میوه بگیر، از بمب فرار کن', cat: 'مهارتی', color: '#3d9a4a', Comp: Catcher },
  { id: 'simon', title: 'حافظه رنگ‌ها', icon: '🎨', desc: 'ترتیب رنگ‌ها را تکرار کن', cat: 'فکری', color: '#8a5cf0', Comp: Simon },
  { id: 'stroop', title: 'رنگ و کلمه', icon: '🌈', desc: 'تمرین تمرکز و سرعت', cat: 'آموزشی', color: '#e0486a', Comp: Stroop },
  { id: 'stack', title: 'برج‌سازی', icon: '🏗️', desc: 'بلوک‌ها را دقیق روی هم بگذار', cat: 'مهارتی', color: '#5b6ee1', Comp: Stack },
  { id: 'breaker', title: 'آجرشکن', icon: '🧱', desc: 'با توپ همه آجرها را بشکن', cat: 'مهارتی', color: '#e08a1e', Comp: Breaker },
  { id: 'hangman', title: 'حدس کلمه', icon: '🔠', desc: 'کلمه پنهان را پیدا کن', cat: 'آموزشی', color: '#22a77a', Comp: Hangman }
];
