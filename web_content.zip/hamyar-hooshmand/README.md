# همیار هوشمند — نسخه ۰٫۳٫۰

سازنده: امیر علی کریمی — شرکت سازنده: مدرسه رستگاران (ایران، فارسی، راست‌چین، تقویم شمسی، واحد پول تومان)

اپلیکیشن آموزشی فارسی با React + TypeScript + PWA + IndexedDB + Capacitor.

## اجرای نسخه وب
نیازمند Node.js ۱۸ یا بالاتر:
```
npm install
npm run typecheck   # بررسی TypeScript
npm run dev         # اجرا در حالت توسعه
npm run build       # ساخت نسخه نهایی در dist
npm run preview
```

## ساخت APK
گزینه ۱ — روی کامپیوتر با Android Studio و JDK 17:
```
npm install && npm run build
npm run cap:add        # فقط بار اول
npm run cap:icons      # آیکون اندروید از assets/icon.png
npm run cap:sync
npm run cap:open       # باز شدن در Android Studio ← Build ← Build APK(s)
```
گزینه ۲ — ابری: فایل `.github/workflows/android.yml` را در GitHub اجرا کن (Actions ← Build Android APK) و APK را از Artifacts بردار.
APK نهایی برای انتشار باید با کلید امضای خودتان (keystore) امضا شود.

## هوش مصنوعی
راهنمای کامل: `docs/AI-SETUP.md` — کلید API فقط روی سرور واسط (`server/`) است.

## محتوا
قالب ورود کاتالوگ: `docs/CONTENT-FORMAT.md`. وضعیت امکانات و محدودیت پوشش کتاب‌ها: `docs/STATUS.md`.

**توجه مهم:** این ZIP بانک کامل کتاب‌های رسمی پایه اول تا دوازدهم نیست. در حال حاضر فقط دو درس نمونه ریاضی نهم داده آموزشی دارند. برای جلوگیری از پاسخ غلط، کتاب‌های دیگر تا زمان ورود محتوای مستند، تکمیل‌نشده نمایش داده می‌شوند.

## آزمون‌ها
- آزمون سرور هوش مصنوعی: `node server/test.mjs`
- بررسی TypeScript: `npm run typecheck`
- ساخت وب/PWA: `npm run build`
- ساخت APK آزمایشی: گردش‌کار `.github/workflows/android.yml` در GitHub Actions؛ برای انتشار عمومی، APK باید با کلید شخصی امضا شود.
