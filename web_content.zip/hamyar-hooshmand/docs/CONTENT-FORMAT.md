# قالب ورود کاتالوگ و محتوا (پنل مدیریت ← داده)

فایل JSON یک آرایه از کتاب‌ها یا شیئی با کلید `books` است. فقط محتوایی را وارد کن که از منبع رسمی (https://chap.sch.ir/) گرفته شده و حق انتشار آن را داری.
```json
[
  {
    "id": "g3-math", "title": "ریاضی سوم", "gradeId": 3,
    "year": "۱۴۰۵-۱۴۰۶", "sourceUrl": "https://chap.sch.ir/", "pdfUrl": "",
    "chapters": [
      { "id": "g3-math-c1", "title": "فصل ۱: ...", "lessons": [
        { "id": "g3-math-l1", "title": "درس ۱",
          "content": { "explain": ["..."], "steps": ["..."], "examples": [{"q":"...","a":"..."}],
                       "tips": ["..."], "summary": ["..."], "source": "منبع و سال", "exercises": [
            { "type": "mcq", "q": "...", "options": ["الف","ب","ج","د"], "answer": 0, "explain": "...", "level": 1, "status": "review" }
          ] } }
      ] }
    ]
  }
]
```
- `gradeId`: ۱ تا ۱۲؛ برای رشته‌ها: `"field": "علوم تجربی"` و برای فنی‌وحرفه‌ای/کاردانش `"track"`.
- نوع سؤال: `mcq` (answer = اندیس از صفر)، `tf` (true/false)، `blank` و `essay` (answer = متن).
- `status`: فقط وقتی `verified` بگذار که پاسخ با منبع رسمی تطبیق داده شده باشد؛ در غیر این صورت `review`.
- جلد: از پنل مدیریت بارگذاری شود. PDF: پیوند رسمی یا بارگذاری فایل مجاز.
