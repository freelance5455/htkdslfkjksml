# AtelierPro Web V1

## Lancer
- Décompresse le ZIP.
- Ouvre `index.html` dans un navigateur moderne.
- Pour tester le mode PWA/offline, héberge le dossier sur un serveur HTTPS ou lance un serveur local. Un double-clic sur index.html peut suffire pour la gestion locale mais ne permet pas toutes les fonctions PWA.

## Fonctions utilisables
- Navigation responsive desktop/mobile.
- Tableau de bord et compteurs.
- Ajout, modification, suppression et recherche pour clients, fournisseurs, employés, produits, matières, stocks, projets, dessins, bibliothèque, devis, commandes, factures, dépenses et machines.
- Paramètres de l'atelier.
- Sauvegarde JSON exportable et importable.
- Données sauvegardées dans le stockage local du navigateur.

## Limites importantes
- C'est une première version web locale, pas un service multi-utilisateur hébergé.
- Pas d'inscription/connexion réelle, pas d'OAuth Google, pas de base de données serveur.
- AYC Style n'est pas connecté à un modèle IA.
- Pas de moteur CAO 2D/3D ni de calcul structurel certifié.
- Les données restent dans le navigateur de l'appareil ; exporte souvent une sauvegarde.
- Ne stocke pas de données confidentielles ou mots de passe dans cette version.
- Pour la production : ajouter backend API, authentification sécurisée, base PostgreSQL, synchronisation, tests et HTTPS.
