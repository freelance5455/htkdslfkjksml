const $ = s => document.querySelector(s);
const today = new Date();
$("#today").textContent = today.toLocaleDateString("fr-FR",{weekday:"long",day:"numeric",month:"long",year:"numeric"});
const STORE_KEY = "atelierpro_web_v1";
const configs = {
 clients:{title:"Clients",desc:"Gère les coordonnées et l'historique de tes clients.",fields:[["nom","Nom / raison sociale","text",true],["type","Type","select",false,["Particulier","Entreprise"]],["telephone","Téléphone","tel"],["email","E-mail","email"],["adresse","Adresse","text"],["notes","Notes","textarea"]],cols:["Nom","Type","Téléphone","E-mail"],keys:["nom","type","telephone","email"]},
 fournisseurs:{title:"Fournisseurs",desc:"Répertoire de tes fournisseurs de matières et équipements.",fields:[["nom","Nom du fournisseur","text",true],["telephone","Téléphone","tel"],["email","E-mail","email"],["adresse","Adresse","text"],["conditions","Conditions de paiement","text"],["notes","Notes","textarea"]],cols:["Fournisseur","Téléphone","E-mail","Conditions"],keys:["nom","telephone","email","conditions"]},
 employes:{title:"Employés",desc:"Suivi de l'équipe et des informations professionnelles.",fields:[["nom","Nom complet","text",true],["matricule","Matricule","text"],["poste","Poste","text"],["telephone","Téléphone","tel"],["date_embauche","Date d'embauche","date"],["salaire","Salaire de base (MGA)","number"]],cols:["Nom","Matricule","Poste","Téléphone"],keys:["nom","matricule","poste","telephone"]},
 produits:{title:"Catalogue produits",desc:"Catalogue initial d'ouvrages métalliques et produits personnalisés.",fields:[["nom","Nom du produit","text",true],["categorie","Catégorie","text"],["code","Code produit","text"],["description","Description","textarea"]],cols:["Produit","Catégorie","Code","Description"],keys:["nom","categorie","code","description"]},
 matieres:{title:"Matières premières",desc:"Profils, tôles, nuances, dimensions et prix d'achat.",fields:[["nom","Désignation","text",true],["famille","Famille","select",false,["Acier","Inox","Aluminium","Cuivre","Autre"]],["forme","Forme / profil","text"],["dimension","Dimension / épaisseur","text"],["densite","Densité (kg/m³)","number"],["prix","Prix unitaire (MGA)","number"],["unite","Unité","select",false,["kg","m","m²","pièce","barre","tôle"]]],cols:["Désignation","Famille","Forme","Dimension","Prix (MGA)"],keys:["nom","famille","forme","dimension","prix"]},
 stocks:{title:"Stocks",desc:"Enregistre les quantités disponibles et surveille les seuils.",fields:[["matiere","Matière / article","text",true],["quantite","Quantité disponible","number",true],["unite","Unité","text"],["minimum","Seuil minimum","number"],["emplacement","Emplacement","text"]],cols:["Matière","Quantité","Unité","Seuil min.","Emplacement"],keys:["matiere","quantite","unite","minimum","emplacement"]},
 projets:{title:"Projets & fabrication",desc:"Organise les projets, étapes et dates de livraison.",fields:[["nom","Nom du projet","text",true],["client","Client","text"],["statut","Statut","select",false,["Étude","Devis","En attente","En fabrication","Terminé","Livré"]],["date_debut","Date de début","date"],["date_fin","Date prévue","date"],["budget","Budget prévu (MGA)","number"],["description","Description","textarea"]],cols:["Projet","Client","Statut","Début","Fin prévue"],keys:["nom","client","statut","date_debut","date_fin"]},
 dessins:{title:"Dessins techniques",desc:"Référencie les dessins, dimensions et fichiers de conception.",fields:[["nom","Nom du dessin","text",true],["projet","Projet lié","text"],["format","Format","select",false,["2D","3D","2D + 3D"]],["largeur","Largeur (mm)","number"],["hauteur","Hauteur (mm)","number"],["profondeur","Profondeur (mm)","number"],["fichier","Lien / chemin du fichier","text"],["notes","Notes techniques","textarea"]],cols:["Dessin","Projet","Format","Largeur (mm)","Hauteur (mm)"],keys:["nom","projet","format","largeur","hauteur"]},
 galerie:{title:"Bibliothèque visuelle",desc:"Ajoute des références d'ouvrages avec leur provenance et leur licence.",fields:[["titre","Titre de l'image","text",true],["categorie","Catégorie","text"],["url","URL de l'image","url",true],["source","Site source","text"],["auteur","Auteur","text"],["licence","Licence","text"],["notes","Notes","textarea"]],cols:["Titre","Catégorie","Source","Auteur","Licence"],keys:["titre","categorie","source","auteur","licence"]},
 devis:{title:"Devis",desc:"Prépare les offres commerciales et leurs montants.",fields:[["numero","Numéro de devis","text",true],["client","Client","text",true],["objet","Objet","text"],["date","Date","date"],["total","Montant total (MGA)","number",true],["statut","Statut","select",false,["Brouillon","Envoyé","Accepté","Refusé","Expiré"]]],cols:["N° devis","Client","Objet","Date","Total (MGA)","Statut"],keys:["numero","client","objet","date","total","statut"]},
 commandes:{title:"Commandes",desc:"Suivi des commandes et de leurs livraisons.",fields:[["numero","Numéro de commande","text",true],["client","Client","text",true],["date","Date commande","date"],["livraison","Livraison prévue","date"],["montant","Montant (MGA)","number"],["statut","Statut","select",false,["En attente","Confirmée","En fabrication","Prête","Livrée","Annulée"]]],cols:["N° commande","Client","Date","Livraison","Montant (MGA)","Statut"],keys:["numero","client","date","livraison","montant","statut"]},
 factures:{title:"Factures & paiements",desc:"Enregistre les factures, échéances et règlements reçus.",fields:[["numero","Numéro de facture","text",true],["client","Client","text",true],["date","Date facture","date"],["echeance","Date échéance","date"],["total","Total TTC (MGA)","number",true],["paye","Montant payé (MGA)","number"],["statut","Statut","select",false,["Non payée","Partiellement payée","Payée"]]],cols:["N° facture","Client","Date","Échéance","Total (MGA)","Payé (MGA)","Statut"],keys:["numero","client","date","echeance","total","paye","statut"]},
 depenses:{title:"Dépenses",desc:"Consigne les charges, achats et frais de fonctionnement.",fields:[["categorie","Catégorie","text",true],["description","Description","text"],["date","Date","date"],["montant","Montant (MGA)","number",true],["fournisseur","Fournisseur","text"]],cols:["Catégorie","Description","Date","Montant (MGA)","Fournisseur"],keys:["categorie","description","date","montant","fournisseur"]},
 machines:{title:"Machines & maintenance",desc:"Inventaire du matériel et suivi des opérations d'entretien.",fields:[["nom","Nom de la machine","text",true],["categorie","Catégorie","text"],["marque","Marque / modèle","text"],["numero_serie","N° de série","text"],["etat","État","select",false,["Opérationnelle","À réparer","En maintenance","Hors service"]],["maintenance","Prochaine maintenance","date"]],cols:["Machine","Catégorie","Marque / modèle","État","Maintenance"],keys:["nom","categorie","marque","etat","maintenance"]}
};
let db = loadDB(), currentPage="dashboard", editing=null;
function loadDB(){try{return JSON.parse(localStorage.getItem(STORE_KEY))||{atelier:{nom:"Mon atelier",devise:"MGA"},data:{}}}catch(e){return {atelier:{nom:"Mon atelier",devise:"MGA"},data:{}}}}
function saveDB(){localStorage.setItem(STORE_KEY,JSON.stringify(db));$("#workspaceName").textContent=db.atelier?.nom||"Mon atelier"}
function rows(key){return db.data[key]||[]}
function setRows(key,arr){db.data[key]=arr;saveDB()}
function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function money(v){return Number(v||0).toLocaleString("fr-FR")+" Ar"}
function toast(msg){let t=$("#toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2400)}
function go(page){currentPage=page;document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===page));$("#crumb").textContent=page==="dashboard"?"Tableau de bord":(configs[page]?.title||({ayc:"AYC Style",parametres:"Paramètres"}[page]||page));$("#sidebar").classList.remove("open");render()}
function heading(title,desc,button=""){return `<div class="page-heading"><div><div class="eyebrow">ATELIERPRO / ESPACE DE TRAVAIL</div><h1>${title}</h1><p>${desc}</p></div>${button}</div>`}
function stat(label,value,icon,note){return `<div class="stat"><div class="stat-top">${label}<span class="stat-icon">${icon}</span></div><div class="stat-value">${value}</div><div class="stat-note">${note}</div></div>`}
function renderDashboard(){
 const count=k=>rows(k).length, revenue=rows("devis").reduce((a,r)=>a+Number(r.total||0),0);
 return `${heading("Tableau de bord","Bienvenue dans ton espace de gestion d'atelier.")}<div class="hero"><div><h2>Construis, organise et développe ton atelier.</h2><p>Centralise tes clients, matières, projets et opérations dans AtelierPro.</p></div><div class="hero-mark">AP</div></div>
 <div class="stats">${stat("Clients",count("clients"),"♙","Fiches enregistrées")}${stat("Projets",count("projets"),"⚒","Projets suivis")}${stat("Produits",count("produits"),"▤","Références catalogue")}${stat("Total des devis",money(revenue),"▱","Montant cumulé saisi")}</div>
 <div class="dashboard-grid"><div class="panel"><h3>Accès rapide</h3><div class="quick-grid">${[["Nouveau client","clients","♙"],["Ajouter une matière","matieres","▥"],["Créer un projet","projets","⚒"],["Nouveau devis","devis","▱"],["Ajouter une commande","commandes","▣"],["Ouvrir les dessins","dessins","◇"]].map(x=>`<button class="quick" data-go="${x[1]}"><span>${x[2]}</span><b>${x[0]}</b></button>`).join("")}</div></div><div class="panel"><h3>État de l'application</h3><p style="font-size:12px;color:#718096;line-height:1.7">Mode local actif : les informations sont enregistrées dans le navigateur de cet appareil.</p><div class="badge green">Hors ligne disponible</div><div class="notice">Pense à exporter une sauvegarde JSON régulièrement. Les données du navigateur peuvent être perdues si tu effaces les données du site.</div></div></div>`;
}
function renderTable(key){
 const c=configs[key], data=rows(key);
 const add=`<button class="btn primary" id="addRecord">＋ Ajouter</button>`;
 return `${heading(c.title,c.desc,add)}<div class="toolbar"><input class="search" id="searchBox" placeholder="⌕ Rechercher dans ${c.title.toLowerCase()}..."><span class="badge">${data.length} enregistrement(s)</span></div><div class="table-card"><div class="table-wrap"><table><thead><tr>${c.cols.map(x=>`<th>${x}</th>`).join("")}<th>Actions</th></tr></thead><tbody id="tableBody">${tableRows(key,data)}</tbody></table></div></div>`;
}
function tableRows(key,data){
 const c=configs[key]; if(!data.length)return `<tr><td colspan="${c.cols.length+1}"><div class="empty">Aucune donnée pour le moment. Clique sur « Ajouter » pour commencer.</div></td></tr>`;
 return data.map((r,i)=>`<tr>${c.keys.map(k=>`<td>${k==="statut"?`<span class="badge ${/payée|terminé|livré|opérationnelle|accepté/i.test(r[k]||"")?"green":""}">${esc(r[k]||"—")}</span>`:esc(r[k]||"—")}</td>`).join("")}<td><div class="actions"><button class="tiny-btn" data-edit="${i}">Modifier</button><button class="tiny-btn delete" data-delete="${i}">Supprimer</button></div></td></tr>`).join("");
}
function renderSpecial(page){
 if(page==="ayc")return `${heading("AYC Style","Assistant intelligent de conception et d'aide à la fabrication.")}<div class="module-cards"><div class="module-card"><h4>Assistant de conception</h4><p>Préparer une description de produit, ses dimensions et ses matériaux avant de demander une proposition à un service IA connecté.</p></div><div class="module-card"><h4>Reconstruction depuis photo</h4><p>Prévoir l'import d'une photo, une dimension de référence et la validation humaine des mesures proposées.</p></div><div class="module-card"><h4>Connexion sécurisée</h4><p>La connexion IA doit passer par un backend. Ne place jamais une clé API secrète dans le code JavaScript public.</p></div></div><div class="notice">AYC Style n'est pas connecté à une IA dans cette version. Cette page décrit les points d'intégration.</div>`;
 if(page==="parametres")return `${heading("Paramètres","Personnalise les informations de ton atelier et gère tes sauvegardes.")}<div class="panel" style="max-width:650px"><form id="settingsForm"><div class="field"><label>Nom de l'atelier</label><input name="nom" required value="${esc(db.atelier?.nom||"")}"></div><div class="field" style="margin-top:12px"><label>Devise</label><select name="devise"><option value="MGA" ${db.atelier?.devise==="MGA"?"selected":""}>MGA — Ariary</option><option value="EUR">EUR — Euro</option><option value="USD">USD — Dollar</option></select></div><div style="margin-top:16px"><button class="btn primary">Enregistrer les paramètres</button></div></form><div class="notice">Compte et sécurité : cette version est locale, sans authentification multi-utilisateur ni inscription Google réelle.</div><button class="btn secondary" id="backupBtn" style="margin-top:12px">⇧ Exporter une sauvegarde</button></div>`;
 if(page==="galerie")return `${renderTable("galerie")}<div class="notice">Les URL d'images et les informations de licence doivent être vérifiées avant toute réutilisation. Les images elles-mêmes ne sont pas préchargées dans cette version.</div>`;
 return `${heading("Module","Espace de travail AtelierPro.")}`;
}
function render(){let html=currentPage==="dashboard"?renderDashboard():configs[currentPage]?renderTable(currentPage):renderSpecial(currentPage);$("#content").innerHTML=html;bindPage()}
function bindPage(){
 document.querySelectorAll("[data-go]").forEach(b=>b.onclick=()=>go(b.dataset.go));
 if($("#addRecord"))$("#addRecord").onclick=()=>openForm(currentPage);
 if($("#searchBox"))$("#searchBox").oninput=e=>{let q=e.target.value.toLowerCase();$("#tableBody").innerHTML=tableRows(currentPage,rows(currentPage).filter(r=>Object.values(r).join(" ").toLowerCase().includes(q)));bindTableActions()};
 bindTableActions();
 if($("#settingsForm"))$("#settingsForm").onsubmit=e=>{e.preventDefault();let f=new FormData(e.target);db.atelier={...db.atelier,nom:f.get("nom"),devise:f.get("devise")};saveDB();toast("Paramètres enregistrés");};
 if($("#backupBtn"))$("#backupBtn").onclick=exportData;
}
function bindTableActions(){
 document.querySelectorAll("[data-edit]").forEach(b=>b.onclick=()=>openForm(currentPage,Number(b.dataset.edit)));
 document.querySelectorAll("[data-delete]").forEach(b=>b.onclick=()=>{let i=Number(b.dataset.delete);if(confirm("Supprimer cet enregistrement ?")){let a=rows(currentPage);a.splice(i,1);setRows(currentPage,a);render();toast("Enregistrement supprimé")}})
}
function openForm(key,index=null){
 editing=index;let c=configs[key], record=index===null?{}:rows(key)[index];$("#modalTitle").textContent=(index===null?"Ajouter : ":"Modifier : ")+c.title;
 $("#formFields").innerHTML=c.fields.map(([name,label,type,required,opts])=>{let val=esc(record[name]??"");let control=type==="textarea"?`<textarea name="${name}">${val}</textarea>`:type==="select"?`<select name="${name}">${(opts||[]).map(o=>`<option ${record[name]===o?"selected":""}>${o}</option>`).join("")}</select>`:`<input name="${name}" type="${type}" value="${val}" ${required?"required":""} ${type==="number"?'step="any"':""}>`;return `<div class="field ${type==="textarea"?"full":""}"><label>${label}${required?" *":""}</label>${control}</div>`}).join("");
 $("#modalBackdrop").hidden=false;
}
function closeModal(){$("#modalBackdrop").hidden=true;editing=null}
$("#recordForm").onsubmit=e=>{e.preventDefault();let data=Object.fromEntries(new FormData(e.target).entries());let key=currentPage,a=rows(key);if(editing===null)a.push(data);else a[editing]=data;setRows(key,a);closeModal();render();toast("Enregistrement sauvegardé")};
$("#closeModal").onclick=closeModal;$("#cancelModal").onclick=closeModal;$("#modalBackdrop").onclick=e=>{if(e.target.id==="modalBackdrop")closeModal()};
function exportData(){let blob=new Blob([JSON.stringify(db,null,2)],{type:"application/json"});let a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="atelierpro-sauvegarde-"+new Date().toISOString().slice(0,10)+".json";a.click();URL.revokeObjectURL(a.href);toast("Sauvegarde exportée")}
function importData(file){let reader=new FileReader();reader.onload=()=>{try{let obj=JSON.parse(reader.result);if(!obj.data||!obj.atelier)throw Error();if(confirm("Remplacer les données actuelles par cette sauvegarde ?")){db=obj;saveDB();render();toast("Sauvegarde importée")}}catch(e){alert("Fichier de sauvegarde invalide.")}};reader.readAsText(file)}
$("#exportBtn").onclick=exportData;$("#importBtn").onclick=()=>$("#importFile").click();$("#importFile").onchange=e=>{if(e.target.files[0])importData(e.target.files[0]);e.target.value=""};
$("#menuBtn").onclick=()=>$("#sidebar").classList.toggle("open");
$("#navigation").onclick=e=>{let b=e.target.closest("[data-page]");if(b)go(b.dataset.page)};
function seed(){
 const sample={produits:[
 {code:"FER-001",nom:"Portail battant",categorie:"Portes et fermetures",description:"Modèle catalogue à personnaliser"},
 {code:"MOB-001",nom:"Table métallique",categorie:"Mobilier",description:"Structure tubulaire"},
 {code:"BAT-001",nom:"Garde-corps",categorie:"Construction",description:"À dimensionner selon le projet"},
 {code:"IND-001",nom:"Établi d'atelier",categorie:"Industrie",description:"Plan de travail métallique"}
 ]};
 if(!db.data.produits?.length)db.data.produits=sample.produits;
 saveDB();
}
seed();go("dashboard");

if ("serviceWorker" in navigator && location.protocol.startsWith("http")) { window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{})); }
