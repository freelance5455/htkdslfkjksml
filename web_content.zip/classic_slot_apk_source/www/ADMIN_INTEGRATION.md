# Classic Slot Firebase + Admin Panel

## Included admin dashboard
Open `/admin/` after deploying the folder. It authenticates with Firebase Email/Password and checks `users/{uid}.role == "admin"` before loading admin data.

## Collections

### `users/{uid}`
- `uid`, `memberNumber`, `email`, `displayName`, `role`, `balance`, `createdAt`, `updatedAt`
- New accounts default to role `user` and 1,250 virtual coins.
- Admin balance edits update the profile document. The signed-in frontend listens to this document and reflects admin-issued changes live.

### `depositRequests/{requestId}`
- `userId`, `memberNumber`, `userEmail`, `paymentMethod`, `transactionId`, `amountPKR`, `senderNumber`, `screenshotPath`, `status`, timestamps.
- Screenshot files are stored under `depositProofs/{uid}/...` in Firebase Storage.
- Admin dashboard previews the screenshot and lets an admin mark the request approved/rejected. On approval, admin can enter a virtual coin credit amount. The amount is optional; entering zero credits no coins.
- Verify every payment independently before approval. An uploaded screenshot alone is not proof of payment.

### `withdrawRequests/{requestId}`
- User, amount, method, account number/title, status, and timestamps.
- Admin can set pending/approved/rejected/paid. The dashboard does not send money.

### `users/{uid}/withdrawAccounts/{JazzCash|Easypaisa}`
- `method`, `accountNumber`, `accountTitle`, `updatedAt`.

## Set up the first admin
1. Register a normal account through the game frontend.
2. In Firebase Console > Firestore, open `users/{uid}` for that account.
3. Change `role` to the exact string `admin`.
4. Sign into `/admin/` using that email/password.

Do not add public admin registration. The rules allow admin-only writes based on this role field.

## Security and limitations
- Firestore rules prevent a normal user from changing their own balance or role.
- Users can only submit their own pending deposit/withdrawal requests; admin can review them.
- The frontend game spin/balance remains client-side game logic. For real money, use a trusted server-side ledger and verified payment provider workflow; do not rely on browser balance.
- Replace placeholders in `firebase-config.js` and deploy `firestore.rules` and `storage.rules` to your Firebase project before using the features. This archive cannot be pre-connected without the target Firebase project's web config.

## Activity feed
The dashboard includes a latest-200 activity feed with filters for spins, deposit/withdrawal submissions, deposit/withdrawal reviews, and admin balance adjustments. Events are written to the Firestore `activities` collection. Deploy the updated `firestore.rules` before using this feed. Client-reported spin activity is useful for support/monitoring but must not be treated as a tamper-proof financial record.
