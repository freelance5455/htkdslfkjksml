// Classic Slot Game Firebase Web configuration (public client identifiers).
window.CLASSIC_SLOT_FIREBASE_CONFIG = {
  apiKey: "AIzaSyDb5HKx3tZgmOx-x1VMumb3bMuRE4KSwzE",
  authDomain: "classic-slot-game.firebaseapp.com",
  databaseURL: "https://classic-slot-game-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "classic-slot-game",
  storageBucket: "classic-slot-game.firebasestorage.app",
  messagingSenderId: "791190206828",
  appId: "1:791190206828:web:39a3d33ae9f69ca4a99b49",
  measurementId: "G-8MNX4VC40K"
};
