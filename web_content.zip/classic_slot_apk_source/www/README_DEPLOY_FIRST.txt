CLASSIC SLOT - FRONTEND CANDIDATE (NOT FULL PRODUCTION)

Preserves old slot interface and Firebase deposit/withdraw form submission. Google Play Game gate is included. Initial new profile balance 100 (not recurring). Share link includes ref player number.

IMPORTANT: NOT READY FOR REAL-MONEY DEPLOY.
1. Firebase rules currently published may require balance=1250, and new profile balance=100 will FAIL until rules are reviewed and changed. The firestore.rules in this ZIP is a proposed rule file only, NOT automatically deployed by Netlify.
2. Referral attribution is captured, but five lucky-spin credit requires a secure backend. No automatic spins are awarded yet.
3. Slot spin outcomes and balance mutations are currently client-side. This is NOT secure for money or withdrawable balances.
4. Withdrawal approval and payment credit require a verified admin backend. Deposit proof needs Firebase Storage rules.
5. Firebase Authentication Google provider and authorized domain must be enabled.
6. Do NOT upload this to your production Netlify game before these dependencies are fixed and tested.
7. No actual cash payout or withdrawal is performed by the frontend.
