(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const config = window.CLASSIC_SLOT_FIREBASE_CONFIG || {};
  const configured = !!(window.firebase && config.apiKey && !String(config.apiKey).includes("PASTE_") &&
    config.projectId && !String(config.projectId).includes("PASTE_") &&
    config.appId && !String(config.appId).includes("PASTE_"));
  let auth = null, db = null, storage = null, currentUser = null, memberNumber = null, profileUnsubscribe = null;
  const status = (msg, good=false) => {
    const el = $("firebaseStatus"); if (!el) return;
    el.textContent = msg; el.style.display = "block";
    el.style.background = good ? "#12351f" : "#22102f";
    el.style.color = good ? "#a9ffc2" : "#ffe7a0";
    if (window.__fbStatusTimer) clearTimeout(window.__fbStatusTimer);
    window.__fbStatusTimer = setTimeout(() => { el.style.display = "none"; }, 6000);
  };
  const feedback = (msg, good=false) => {
    const el = $("fbAuthFeedback"); if (el) { el.textContent = msg; el.style.color = good ? "#9ff0b4" : "#ffb3b3"; }
  };
  const showAuth = () => { $("firebaseAuthModal").style.display = "flex"; $("fbAuthFeedback").textContent = ""; };
  window.openClassicSlotAuth = showAuth;
  const hideAuth = () => { $("firebaseAuthModal").style.display = "none"; };
  const requireUser = async () => {
    if (!configured) { status("Firebase config required: edit firebase-config.js first."); showAuth(); return false; }
    if (!currentUser) { status("Please sign in or create an account first."); showAuth(); return false; }
    return true;
  };
  function playerNumber(uid) { return "CS" + String(uid).replace(/[^a-zA-Z0-9]/g, "").slice(-10).toUpperCase(); }
  async function logActivity(type, details={}) {
    if (!db || !currentUser) return;
    try { await db.collection("activities").add({
      type, userId: currentUser.uid, userEmail: currentUser.email || "",
      memberNumber: memberNumber || "", details,
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    }); } catch (e) { console.warn("Activity log failed", e); }
  }
  window.logClassicSlotActivity = logActivity;
  async function ensureProfile(user) {
    const ref = db.collection("users").doc(user.uid);
    const snap = await ref.get();
    const generated = playerNumber(user.uid);
    if (!snap.exists) {
      await ref.set({
        uid: user.uid, memberNumber: generated, email: user.email || "",
        displayName: user.displayName || "", role: "user", balance: 0, welcomeBonusClaimed: false, luckySpins: 0, referredBy: (new URLSearchParams(location.search).get("ref") || "").slice(0,40),
        createdAt: firebase.firestore.FieldValue.serverTimestamp(),
        updatedAt: firebase.firestore.FieldValue.serverTimestamp()
      });
    } else {
      const data = snap.data() || {};
      if (!data.memberNumber) await ref.set({memberNumber: generated, updatedAt: firebase.firestore.FieldValue.serverTimestamp()}, {merge:true});
    }
    const fresh = await ref.get();
    const profile = fresh.data() || {};
    memberNumber = profile.memberNumber || generated; window.classicSlotMemberNumber = memberNumber;
    // Admin balance changes are pushed live to the signed-in player's screen.
    if (profile.balance !== undefined && Number.isFinite(Number(profile.balance))) {
      window.__classicSlotCloudBalance = Number(profile.balance);
      if (typeof window.applyClassicSlotCloudBalance === "function") window.applyClassicSlotCloudBalance(Number(profile.balance));
    }
    renderPlayer();
    await logActivity("profile_ready", {balance: Number(profile.balance || 0)});
  }
  function renderPlayer() {
    const info = $("fbPlayerInfo");
    if (currentUser) {
      if (info) { info.style.display = "block"; info.textContent = "Signed in: " + (currentUser.email || "Player") + " · Player number: " + memberNumber; }
      $("fbSignOut").style.display = "block";
      $("fbGoogleSignIn").style.display = "none";
      $("fbSignIn").style.display = "none"; $("fbRegister").style.display = "none";
      $("fbResetPassword").style.display = "none";
      $("fbEmail").style.display = "none"; $("fbPassword").style.display = "none";
    } else {
      if (info) info.style.display = "none";
      $("fbSignOut").style.display = "none";
      $("fbGoogleSignIn").style.display = "block";
      $("fbSignIn").style.display = "block"; $("fbRegister").style.display = "block";
      $("fbResetPassword").style.display = "block";
      $("fbEmail").style.display = ""; $("fbPassword").style.display = "";
    }
  }
  async function signIn() {
    if (!configured) { feedback("Open firebase-config.js and add your Firebase web app config."); return; }
    const email = $("fbEmail").value.trim(), password = $("fbPassword").value;
    if (!email || !password) { feedback("Enter email and password."); return; }
    try { await auth.signInWithEmailAndPassword(email, password); feedback("Signed in.", true); }
    catch (e) { feedback((e && e.message) || "Sign in failed."); }
  }
  async function register() {
    if (!configured) { feedback("Open firebase-config.js and add your Firebase web app config."); return; }
    const email = $("fbEmail").value.trim(), password = $("fbPassword").value;
    if (!email || password.length < 6) { feedback("Enter a valid email and password with at least 6 characters."); return; }
    try {
      await auth.createUserWithEmailAndPassword(email, password);
      feedback("Account created. Your player number is shown below.", true);
    } catch (e) { feedback((e && e.message) || "Account creation failed."); }
  }
  async function uploadProof(file, uid) {
    if (!file || !file.type || !file.type.startsWith("image/")) throw new Error("Choose a JPG, PNG, or other image screenshot.");
    if (file.size > 5 * 1024 * 1024) throw new Error("Screenshot must be 5 MB or smaller.");
    const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_").slice(-90) || "proof.jpg";
    const path = "depositProofs/" + uid + "/" + Date.now() + "_" + safeName;
    const ref = storage.ref().child(path);
    await ref.put(file, {contentType: file.type});
    return path;
  }
  async function submitDeposit() {
    const btn = $("paidSubmit"), feedbackEl = $("paidFeedback");
    if (!(await requireUser())) return;
    const method = $("paidPaymentMethod").value;
    const file = $("paymentScreenshot").files && $("paymentScreenshot").files[0];
    const tx = $("transactionId").value.trim();
    const amount = Number($("paidAmount").value);
    const senderNumber = $("senderNumber").value.replace(/\D/g, "");
    if (!method) { feedbackEl.textContent = "Select JazzCash or Easypaisa."; return; }
    if (!file) { feedbackEl.textContent = "Choose the payment screenshot from Gallery."; return; }
    if (!tx) { feedbackEl.textContent = "Enter the transaction ID."; return; }
    if (!(amount > 0 && amount <= 10000000)) { feedbackEl.textContent = "Enter a valid payment amount."; return; }
    if (!/^03\d{9}$/.test(senderNumber)) { feedbackEl.textContent = "Enter an 11-digit sender mobile number."; return; }
    btn.disabled = true; btn.textContent = "UPLOADING…";
    try {
      const screenshotPath = await uploadProof(file, currentUser.uid);
      const doc = {
        userId: currentUser.uid, memberNumber, userEmail: currentUser.email || "",
        paymentMethod: method, transactionId: tx, amountPKR: amount,
        senderNumber, screenshotPath, status: "pending",
        submittedAt: firebase.firestore.FieldValue.serverTimestamp(),
        updatedAt: firebase.firestore.FieldValue.serverTimestamp()
      };
      const ref = await db.collection("depositRequests").add(doc);
      await logActivity("deposit_submitted", {requestId: ref.id, amountPKR: amount, paymentMethod: method, transactionId: tx});
      feedbackEl.textContent = "Submitted to Firebase. Request ID: " + ref.id + " · Status: Pending admin review.";
      feedbackEl.style.color = "#9ff0b4";
      status("Deposit request sent to Firebase.", true);
    } catch (e) {
      feedbackEl.textContent = "Firebase submission failed: " + ((e && e.message) || "Please check config, rules, and Storage.");
      feedbackEl.style.color = "#ffb3b3";
    } finally { btn.disabled = false; btn.textContent = "SUBMIT PAYMENT DETAILS"; }
  }
  async function saveWithdrawAccountToCloud() {
    if (!(await requireUser())) return;
    const method = document.querySelector('[data-withdraw-method].selected')?.dataset.withdrawMethod || "JazzCash";
    const number = $("withdrawAccountNumber").value.trim().replace(/[\s-]/g, "");
    const title = $("withdrawAccountTitle").value.trim();
    if (!number || title.length < 2) return;
    try {
      await db.collection("users").doc(currentUser.uid).collection("withdrawAccounts").doc(method).set({
        method, accountNumber: number, accountTitle: title,
        updatedAt: firebase.firestore.FieldValue.serverTimestamp()
      }, {merge:true});
      status("Withdrawal account saved to Firebase.", true);
    } catch (e) { status("Account was saved locally, but Firebase sync failed: " + ((e && e.message) || "check Firestore rules.")); }
  }
  async function submitWithdraw() {
    if (!(await requireUser())) return;
    const amount = Number($("withdrawRequestAmount").value);
    const method = document.querySelector('[data-saved-method].selected')?.dataset.savedMethod || "JazzCash";
    if (!(amount > 0 && Number.isFinite(amount))) { status("Enter a valid withdrawal amount in virtual coins."); return; }
    try {
      const accountSnap = await db.collection("users").doc(currentUser.uid).collection("withdrawAccounts").doc(method).get();
      if (!accountSnap.exists) { status("Save this withdrawal account to Firebase first."); return; }
      const a = accountSnap.data();
      const ref = await db.collection("withdrawRequests").add({
        userId: currentUser.uid, memberNumber, userEmail: currentUser.email || "",
        amountPKR: Math.floor(amount), paymentMethod: method,
        accountNumber: a.accountNumber, accountTitle: a.accountTitle,
        status: "pending", submittedAt: firebase.firestore.FieldValue.serverTimestamp(),
        updatedAt: firebase.firestore.FieldValue.serverTimestamp()
      });
      await logActivity("withdrawal_submitted", {requestId: ref.id, amountPKR: Math.floor(amount), paymentMethod: method});
      $("withdrawFeedback").textContent = "Request sent to Firebase. Request ID: " + ref.id + " · Pending admin review.";
      $("withdrawFeedback").style.color = "#9ff0b4";
      status("Withdrawal request sent to Firebase.", true);
    } catch (e) { status("Withdrawal request failed: " + ((e && e.message) || "check Firestore rules.")); }
  }
  function init() {
    if (!configured) { status("Firebase not configured yet. Edit firebase-config.js before hosting."); }
    else {
      try {
        if (!firebase.apps.length) firebase.initializeApp(config);
        auth = firebase.auth(); db = firebase.firestore(); storage = firebase.storage();
        auth.onAuthStateChanged(async user => {
          currentUser = user || null;
          if (profileUnsubscribe) { profileUnsubscribe(); profileUnsubscribe = null; }
          if (user) {
            try {
              await ensureProfile(user); renderPlayer(); status("Signed in · Player number " + memberNumber, true);
              if (typeof window.classicSlotGateSignedIn === "function") window.classicSlotGateSignedIn();
              profileUnsubscribe = db.collection("users").doc(user.uid).onSnapshot(snap => {
                if (!snap.exists) return;
                const data = snap.data() || {};
                memberNumber = data.memberNumber || memberNumber; window.classicSlotMemberNumber = memberNumber;
                if (data.balance !== undefined && Number.isFinite(Number(data.balance))) {
                  window.__classicSlotCloudBalance = Number(data.balance);
                  if (typeof window.applyClassicSlotCloudBalance === "function") window.applyClassicSlotCloudBalance(Number(data.balance));
                }
                renderPlayer();
              }, err => status("Live balance sync failed: " + (err.message || "check Firestore rules.")));
            } catch (e) { status("Signed in, but profile setup failed: " + ((e && e.message) || "check Firestore rules.")); }
          } else { memberNumber = null; renderPlayer();
            if (typeof window.classicSlotGateSignedOut === "function") window.classicSlotGateSignedOut();
          }
        });
      } catch (e) { status("Firebase initialization error: " + ((e && e.message) || "check config.")); }
    }
    window.classicSlotGoogleLogin = async function () {
      if (!configured || !auth) throw new Error("Firebase authentication is not ready.");
      const provider = new firebase.auth.GoogleAuthProvider();
      try {
        await auth.signInWithPopup(provider);
      } catch (e) {
        if (e && ["auth/popup-blocked","auth/operation-not-supported-in-this-environment"].includes(e.code)) {
          await auth.signInWithRedirect(provider);
          return;
        }
        throw e;
      }
    };
    if (auth) auth.getRedirectResult().catch(e => status("Google sign-in error: " + (e.message || e.code)));
    const profileGoogle = $("profileGoogleRegister");
    if (profileGoogle) profileGoogle.addEventListener("click", async () => {
      if (currentUser) { showAuth(); feedback("You are already signed in as " + (currentUser.email || "your Google account"), true); return; }
      showAuth();
      const googleBtn = $("fbGoogleSignIn");
      if (googleBtn) googleBtn.scrollIntoView({block:"nearest"});
    });
    const profileEmail = $("profileEmailRegister");
    if (profileEmail) profileEmail.addEventListener("click", () => { showAuth(); $("fbEmail").focus(); });
    const originalRenderPlayer = renderPlayer;
    renderPlayer = function() {
      originalRenderPlayer();
      const label = $("profileAccountStatus");
      const help = $("profileBalanceHelp");
      const googleButton = $("profileGoogleRegister");
      const emailButton = $("profileEmailRegister");
      if (label) label.textContent = currentUser ? ((currentUser.displayName || currentUser.email || "Player") + " · " + (memberNumber || "Registered player")) : "Guest Player · Not registered";
      if (help) help.textContent = currentUser ? "Account linked to Firebase. New accounts start with 0 coins; existing balances are preserved." : "Register or sign in to save your player ID and cloud balance. New accounts start with 0 coins.";
      if (googleButton) googleButton.textContent = currentUser ? "✓ GOOGLE ACCOUNT CONNECTED" : "🌐 REGISTER / SIGN IN WITH GOOGLE";
      if (emailButton) emailButton.style.display = currentUser ? "none" : "";
    };
    $("fbGoogleSignIn").addEventListener("click", async () => {
      const btn = $("fbGoogleSignIn"); btn.disabled = true; btn.textContent = "Connecting to Google…";
      try { await window.classicSlotGoogleLogin(); feedback("Google account connected. New player accounts start with 0 coins.", true); }
      catch (e) { feedback((e && e.message) || "Google sign-in failed."); }
      finally { btn.disabled = false; btn.textContent = "🌐 Register / Sign in with Google"; }
    });
    $("fbSignIn").addEventListener("click", signIn);
    $("fbRegister").addEventListener("click", register);
    $("fbAuthClose").addEventListener("click", hideAuth);
    $("fbSignOut").addEventListener("click", async () => { try { await auth.signOut(); feedback("Signed out.", true); } catch(e) { feedback(e.message || "Sign out failed."); } });
    $("fbResetPassword").addEventListener("click", async () => {
      if (!configured) { feedback("Configure Firebase first."); return; }
      const email = $("fbEmail").value.trim(); if (!email) { feedback("Enter your email address first."); return; }
      try { await auth.sendPasswordResetEmail(email); feedback("Password reset email sent if the account exists.", true); }
      catch(e) { feedback(e.message || "Could not send reset email."); }
    });
    // Replace the legacy local-only paid status action with Firebase submission.
    $("paidSubmit").onclick = submitDeposit;
    // Existing game menu's login/logout actions are intercepted without changing game UI.
    document.querySelectorAll('[data-drawer="login"]').forEach(el => el.addEventListener("click", () => { setTimeout(showAuth, 0); }));
    document.querySelectorAll('[data-drawer="logout"]').forEach(el => el.addEventListener("click", async () => { if (auth && currentUser) { try { await auth.signOut(); } catch(_){} } }));
    $("saveWithdrawAccount").addEventListener("click", () => setTimeout(saveWithdrawAccountToCloud, 0));
    $("submitWithdrawRequest").addEventListener("click", submitWithdraw);
    // Require an authenticated Firebase account before opening payment request forms.
    $("paidStatusBtn").onclick = async () => {
      if (!(await requireUser())) return;
      $("modal").style.display = "none"; $("paidStatusModal").style.display = "flex"; $("paidFeedback").textContent = "";
    };
    $("withdrawBtn").onclick = async () => {
      if (!(await requireUser())) return;
      $("modal").style.display = "none";
      if (typeof window.showWithdrawModal === "function") window.showWithdrawModal();
      else $("withdrawModal").style.display = "flex";
    };
    renderPlayer();
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();
