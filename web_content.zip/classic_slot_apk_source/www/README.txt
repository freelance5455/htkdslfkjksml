CLASSIC SLOT — FRONTEND + FIREBASE ADMIN PACKAGE

PACKAGE CONTENTS
- index.html: Classic Slot virtual-coins game frontend.
- firebase-config.js: Firebase Web App config shared by frontend and admin panel.
- firebase-integration.js: Email/password authentication, unique CS player number, deposit proof upload, withdrawal request/account sync, and live admin-issued balance sync.
- admin/index.html + admin/admin.js: Admin dashboard for player lookup, manual virtual coin add/subtract, deposit screenshot review, approve/reject status, and withdrawal request status.
- firestore.rules + storage.rules + firebase.json: security rules and deployment config.
- ADMIN_INTEGRATION.md: schema, setup, and limitations.

IMPORTANT: THIS ZIP IS NOT PRE-CONNECTED TO YOUR FIREBASE PROJECT
Firebase settings are project-specific. Before the features can work, complete the one-time setup below. This is configuration, not editing the game code.

ONE-TIME FIREBASE SETUP
1. Open Firebase Console and select your project (or create one).
2. Authentication > Sign-in method > enable Email/Password.
3. Firestore Database > create the database.
4. Storage > get started and enable the bucket.
5. Project settings > Your apps > create/select Web app and copy its config values into firebase-config.js. Keep the same config for game and admin panel.
6. Install Firebase CLI on a computer, run `firebase login`, then from this folder run `firebase use --add` and select the project. Deploy rules with `firebase deploy --only firestore:rules,storage`.
7. Deploy the contents of this folder to Netlify as the game frontend. The admin page is at /admin/ on the same site, or deploy the `admin` folder as a separate site only if you adjust the relative config script path.
8. Register your own admin email using the game's account modal. In Firestore, open users/{that account's UID} and change role from "user" to "admin". Do not share admin credentials. Refresh /admin/ and sign in.
9. Open the game and sign in with a normal user account. Deposit requests and screenshots will appear in /admin/ when submitted. Admin can add virtual coins to a player; if the player is online, their displayed balance updates live.

PLAYER / ADMIN WORKFLOW
- Each account is a Firebase Authentication user with a unique UID and readable CS player number.
- A deposit request includes payment method, transaction ID, PKR amount, sender mobile, screenshot in Firebase Storage, and pending status.
- Admin must independently verify the payment in the payment provider account. Only then mark it approved; optionally enter the virtual coin amount to credit.
- Admin can also search a player and manually add/subtract virtual coins.
- Withdrawal requests and saved withdrawal account details are stored in Firestore and appear in admin panel.

LIMITATIONS / SAFETY
- This is a virtual-coin game. The admin balance controls are for virtual coins, not real-money wallet accounting.
- Firebase Web config is not secret, but never put service-account keys or private credentials in frontend files.
- The local slot spin itself remains client-side; this package does not implement a trusted server-side game ledger or cash payment/payout processor. Do not use the client-side game balance as proof of real-money funds.
- Configure and test the Firebase project and rules before public use. This package has not been connected to your project because your actual Firebase Web App config was not provided.

ADMIN DASHBOARD
- Upload the complete folder to Netlify; the dashboard is available at /admin/.
- Configure firebase-config.js once with your Firebase Web App config.
- Enable Email/Password Authentication, Firestore, and Storage.
- Deploy firestore.rules and storage.rules from this package using Firebase CLI or the Firebase Console.
- Create your admin user through Firebase Authentication, then set users/{that-auth-uid}.role = "admin" in Firestore.
- Sign in at /admin/ to review deposits, withdrawal requests, users, manual virtual coin balance changes, and recent activity.
- The activity list includes client-reported spins and request/admin events. It is operational telemetry, not tamper-proof accounting.

IMPORTANT LIMITATION
This is a browser-based virtual-coin game. Game spin outcomes and per-spin balance changes are calculated in the frontend and are not a secure server-side ledger. Do not use it to settle real-money gambling or payouts. A production-safe balance ledger requires trusted server-side Cloud Functions/API transactions and idempotency checks. Firebase config placeholders must be filled before any Firebase feature works.
