CLASSIC SLOT GAME - ANDROID APK SOURCE PACKAGE

Is ZIP mein game ka frontend aur Android app banane ke liye Capacitor wrapper shamil hai. Yeh APK file nahi hai; APK build karne ke liye computer par Android Studio aur Node.js chahiye.

WINDOWS / COMPUTER PAR APK BANANE KE STEPS:
1. ZIP ko extract karein.
2. Node.js LTS install karein: https://nodejs.org/
3. Android Studio install karein: https://developer.android.com/studio
4. Extract kiye hue folder mein Terminal / Command Prompt kholein.
5. Ye commands ek ek karke chalayein:
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
6. Android Studio mein project load hone dein.
7. Test APK ke liye menu se Build > Build Bundle(s) / APK(s) > Build APK(s) select karein.
8. APK Android Studio ke build/outputs/apk/ folder mein milegi.

IMPORTANT:
- App ID: com.classicslot.game
- Game files www/ folder mein hain.
- Google login Android app ke andar kaam karne ke liye Firebase Authentication mein Android app add karna, package name aur SHA-1/SHA-256 set karna, aur OAuth configuration check karna par sakta hai. Web login configuration apne aap Android login ki guarantee nahi deti.
- Is package mein real-money deposit/withdrawal ya Play Store approval ki guarantee nahi hai.
- ZIP ko Netlify par upload karne ke bajaye APK build ke liye use karein.
