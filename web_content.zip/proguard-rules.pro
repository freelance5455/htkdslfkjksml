# Keep default Android/Google Mobile Ads rules; add app-specific rules only if needed.
