// قالب التطبيق الناتج (Shell). يُبنى مرة واحدة على الكمبيوتر ويُضمَّن داخل تطبيق Askar APK Builder،
// ثم يقوم التطبيق على الهاتف بتعديل نسخة منه (الاسم، الحزمة، الأيقونة، الملفات) وتوقيعها.
// لا تغيّر القيم المؤقتة (ASKARPH / com.askartpl) لأن محرك البناء يبحث عنها بالحرف.
plugins {
    id("com.android.application")
}

android {
    namespace = "com.askar.shell"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.askartpl.placeholderappid.aaaaaaaa"
        minSdk = 21
        targetSdk = 34
        versionCode = 1
        versionName = "ASKARPH_VNAME"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            signingConfig = null // يخرج غير موقّع: shell-release-unsigned.apk
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    dependenciesInfo {
        includeInApk = false
        includeInBundle = false
    }
}
// بدون أي مكتبات خارجية حتى يبقى القالب صغيرًا (~ 30-60 KB)
