package com.askar.shell;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.webkit.CookieManager;
import android.webkit.MimeTypeMap;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * التطبيق الناتج: يعرض ملفات assets/www داخل WebView.
 * الملفات تُخدَم من https://appassets.androidplatform.net/ (أصل آمن، يعمل معه fetch و localStorage و ES modules)
 * الإعدادات تُقرأ من assets/askar_config.json الذي يكتبه Askar APK Builder.
 */
public class MainActivity extends Activity {
    static final String HOST = "appassets.androidplatform.net";
    static final String BASE = "https://" + HOST + "/";
    static final int FILE_CHOOSER = 41;

    WebView web;
    JSONObject cfg = new JSONObject();
    ValueCallback<Uri[]> pendingChooser;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        cfg = readConfig();
        applyOrientation(cfg.optString("orientation", "unspecified"));
        applyBars();

        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        boolean zoom = cfg.optBoolean("zoom", false);
        s.setSupportZoom(zoom);
        s.setBuiltInZoomControls(zoom);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);
        if (!cfg.optBoolean("internet", true)) s.setBlockNetworkLoads(true);
        if (Build.VERSION.SDK_INT >= 21) CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        web.setWebViewClient(new Client());
        web.setWebChromeClient(new Chrome());
        if (cfg.optBoolean("downloads", true)) web.setDownloadListener(this::onDownload);

        if (state != null) web.restoreState(state);
        else web.loadUrl(BASE + cfg.optString("entry", "index.html"));
    }

    @Override protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); if (web != null) web.saveState(out); }

    JSONObject readConfig() {
        try (InputStream in = getAssets().open("askar_config.json")) {
            byte[] b = readAll(in);
            return new JSONObject(new String(b, "UTF-8"));
        } catch (Exception e) { return new JSONObject(); }
    }

    static byte[] readAll(InputStream in) throws IOException {
        java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[16384]; int n;
        while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
        return o.toByteArray();
    }

    void applyOrientation(String o) {
        int v;
        switch (o) {
            case "portrait": v = ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT; break;
            case "landscape": v = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE; break;
            case "sensor": v = ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR; break;
            default: v = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;
        }
        setRequestedOrientation(v);
    }

    static int parseColor(String c, int def) { try { return Color.parseColor(c); } catch (Exception e) { return def; } }
    static boolean isLight(int c) { return (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) > 170; }

    @SuppressWarnings("deprecation")
    void applyBars() {
        if (Build.VERSION.SDK_INT < 21) return;
        Window w = getWindow();
        int status = parseColor(cfg.optString("statusBarColor", "#000000"), Color.BLACK);
        int nav = parseColor(cfg.optString("navBarColor", "#000000"), Color.BLACK);
        w.setStatusBarColor(status);
        w.setNavigationBarColor(nav);
        int flags = w.getDecorView().getSystemUiVisibility();
        if (Build.VERSION.SDK_INT >= 23 && isLight(status)) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (Build.VERSION.SDK_INT >= 26 && isLight(nav)) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        w.getDecorView().setSystemUiVisibility(flags);
        w.getDecorView().setBackgroundColor(Color.WHITE);
    }

    /* ---------------- local file server ---------------- */
    static final Map<String, String> MIME = new HashMap<>();
    static {
        MIME.put("html", "text/html"); MIME.put("htm", "text/html"); MIME.put("js", "text/javascript"); MIME.put("mjs", "text/javascript");
        MIME.put("css", "text/css"); MIME.put("json", "application/json"); MIME.put("svg", "image/svg+xml"); MIME.put("png", "image/png");
        MIME.put("jpg", "image/jpeg"); MIME.put("jpeg", "image/jpeg"); MIME.put("gif", "image/gif"); MIME.put("webp", "image/webp");
        MIME.put("ico", "image/x-icon"); MIME.put("woff", "font/woff"); MIME.put("woff2", "font/woff2"); MIME.put("ttf", "font/ttf");
        MIME.put("otf", "font/otf"); MIME.put("mp3", "audio/mpeg"); MIME.put("wav", "audio/wav"); MIME.put("ogg", "audio/ogg");
        MIME.put("m4a", "audio/mp4"); MIME.put("mp4", "video/mp4"); MIME.put("webm", "video/webm"); MIME.put("wasm", "application/wasm");
        MIME.put("txt", "text/plain"); MIME.put("xml", "text/xml"); MIME.put("pdf", "application/pdf"); MIME.put("csv", "text/csv");
        MIME.put("webmanifest", "application/manifest+json");
    }

    static String mimeOf(String path) {
        int dot = path.lastIndexOf('.');
        String ext = dot >= 0 ? path.substring(dot + 1).toLowerCase(Locale.ROOT) : "";
        String m = MIME.get(ext);
        if (m == null) m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
        return m == null ? "application/octet-stream" : m;
    }

    WebResourceResponse serve(Uri uri) {
        String path = uri.getPath();
        if (path == null || path.equals("/")) path = "/" + cfg.optString("entry", "index.html");
        if (path.endsWith("/")) path += "index.html";
        path = Uri.decode(path).substring(1);
        if (path.contains("..")) return notFound();
        String mime = mimeOf(path);
        try {
            InputStream in = getAssets().open("www/" + path);
            WebResourceResponse r = new WebResourceResponse(mime, mime.startsWith("text/") || mime.contains("json") || mime.contains("javascript") ? "UTF-8" : null, in);
            if (Build.VERSION.SDK_INT >= 21) {
                Map<String, String> h = new HashMap<>();
                h.put("Access-Control-Allow-Origin", "*");
                h.put("Cache-Control", "no-cache");
                r.setResponseHeaders(h);
            }
            return r;
        } catch (IOException e) {
            return notFound();
        }
    }

    WebResourceResponse notFound() {
        WebResourceResponse r = new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream("404".getBytes()));
        if (Build.VERSION.SDK_INT >= 21) r.setStatusCodeAndReasonPhrase(404, "Not Found");
        return r;
    }

    boolean isLocal(Uri u) { return u != null && HOST.equals(u.getHost()); }

    /** Decides what to do with a navigation. Returns true if WebView must NOT load it. */
    boolean handleNav(Uri u) {
        if (u == null) return false;
        String scheme = u.getScheme() == null ? "" : u.getScheme().toLowerCase(Locale.ROOT);
        if (isLocal(u) || scheme.equals("about") || scheme.equals("data") || scheme.equals("blob") || scheme.equals("javascript")) return false;
        if (scheme.equals("http") || scheme.equals("https")) {
            String mode = cfg.optString("externalLinks", "browser");
            if (mode.equals("inside")) return !cfg.optBoolean("internet", true);
            if (mode.equals("block")) { toast("الروابط الخارجية غير مسموحة في هذا التطبيق"); return true; }
            openExternal(u); return true;
        }
        // tel:, mailto:, whatsapp:, intent: ... → system
        if (scheme.equals("intent")) {
            try {
                Intent i = Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME);
                i.addCategory(Intent.CATEGORY_BROWSABLE); i.setComponent(null); i.setSelector(null);
                startActivity(i);
            } catch (Exception e) {
                String fb = u.getQueryParameter("browser_fallback_url");
                if (fb != null) openExternal(Uri.parse(fb)); else toast("لا يوجد تطبيق لفتح هذا الرابط");
            }
            return true;
        }
        openExternal(u);
        return true;
    }

    void openExternal(Uri u) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, u).addCategory(Intent.CATEGORY_BROWSABLE)); }
        catch (ActivityNotFoundException e) { toast("لا يوجد تطبيق لفتح هذا الرابط"); }
    }

    class Client extends WebViewClient {
        @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest req) {
            return isLocal(req.getUrl()) ? serve(req.getUrl()) : null;
        }
        @SuppressWarnings("deprecation")
        @Override public WebResourceResponse shouldInterceptRequest(WebView v, String url) {
            Uri u = Uri.parse(url); return isLocal(u) ? serve(u) : null;
        }
        @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
            if (!req.isForMainFrame()) return false;
            return handleNav(req.getUrl());
        }
        @SuppressWarnings("deprecation")
        @Override public boolean shouldOverrideUrlLoading(WebView v, String url) { return handleNav(Uri.parse(url)); }
    }

    class Chrome extends WebChromeClient {
        @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
            if (pendingChooser != null) pendingChooser.onReceiveValue(null);
            pendingChooser = cb;
            try { startActivityForResult(p.createIntent(), FILE_CHOOSER); }
            catch (ActivityNotFoundException e) { pendingChooser = null; toast("لا يوجد تطبيق لاختيار الملفات"); return false; }
            return true;
        }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        if (req == FILE_CHOOSER) {
            if (pendingChooser != null) pendingChooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            pendingChooser = null;
            return;
        }
        super.onActivityResult(req, res, data);
    }

    /* ---------------- downloads ---------------- */
    void onDownload(String url, String ua, String disposition, String mime, long len) {
        try {
            String name = URLUtil.guessFileName(url, disposition, mime);
            if (url.startsWith("data:")) { saveDataUrl(url, name, mime); return; }
            if (url.startsWith("blob:")) { toast("تنزيل blob غير مدعوم — استخدم رابط data: أو رابط http"); return; }
            if (!(url.startsWith("http://") || url.startsWith("https://"))) { toast("رابط تنزيل غير مدعوم"); return; }
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            r.setMimeType(mime);
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null) r.addRequestHeader("Cookie", cookie);
            r.addRequestHeader("User-Agent", ua);
            r.setTitle(name);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(r);
            toast("جارٍ التنزيل: " + name);
        } catch (Exception e) {
            toast("تعذّر التنزيل: " + e.getMessage());
        }
    }

    void saveDataUrl(String url, String name, String mime) throws IOException {
        int comma = url.indexOf(',');
        if (comma < 0) throw new IOException("رابط data غير صالح");
        String meta = url.substring(5, comma);
        byte[] data = meta.endsWith(";base64") ? Base64.decode(url.substring(comma + 1), Base64.DEFAULT) : Uri.decode(url.substring(comma + 1)).getBytes("UTF-8");
        if (meta.contains("/")) mime = meta.split(";")[0];
        if (Build.VERSION.SDK_INT < 29) { toast("حفظ هذا النوع من الملفات يتطلب أندرويد 10 أو أحدث"); return; }
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
        Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        if (u == null) throw new IOException("تعذّر إنشاء الملف");
        try (OutputStream o = getContentResolver().openOutputStream(u)) { if (o == null) throw new IOException("تعذّر الكتابة"); o.write(data); }
        toast("حُفظ في التنزيلات: " + name);
    }

    void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }

    @SuppressWarnings("deprecation")
    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    @Override protected void onPause() { super.onPause(); if (web != null) web.onPause(); }
    @Override protected void onResume() { super.onResume(); if (web != null) web.onResume(); }
    @Override protected void onDestroy() { if (web != null) { web.destroy(); web = null; } super.onDestroy(); }
}
