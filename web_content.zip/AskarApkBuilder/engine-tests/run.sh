#!/bin/sh
# يشغّل اختبارات محرك البناء على الكمبيوتر (يحتاج JDK 17+ فقط)
cd "$(dirname "$0")"
rm -rf out && mkdir out
javac -encoding UTF-8 -d out ../app/src/main/java/com/askar/apkbuilder/engine/*.java EngineTest.java && java -Djava.awt.headless=true -cp out EngineTest
