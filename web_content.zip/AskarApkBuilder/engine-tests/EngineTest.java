import com.askar.apkbuilder.engine.*;
import java.io.*;
import java.nio.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;

public class EngineTest {
    static int pass = 0, fail = 0;
    static void check(String name, boolean ok) { if (ok) pass++; else fail++; System.out.println((ok ? "PASS " : "FAIL ") + name); }

    /* ---------- tiny AXML writer (mimics aapt2 layout: UTF-16 pool, resource map, namespace, elements) ---------- */
    static List<String> pool = new ArrayList<>();
    static int s(String v) { int i = pool.indexOf(v); if (i >= 0) return i; pool.add(v); return pool.size() - 1; }
    static final String NS = "http://schemas.android.com/apk/res/android";

    static byte[] attr(String name, boolean androidNs, Object value) {
        ByteBuffer b = ByteBuffer.allocate(20).order(ByteOrder.LITTLE_ENDIAN);
        b.putInt(androidNs ? s(NS) : -1).putInt(s(name));
        if (value instanceof Integer) { b.putInt(-1).putShort((short) 8).put((byte) 0).put((byte) 0x10).putInt((Integer) value); }
        else { int si = s((String) value); b.putInt(si).putShort((short) 8).put((byte) 0).put((byte) 0x03).putInt(si); }
        return b.array();
    }
    static byte[] start(String name, byte[]... attrs) {
        int size = 16 + 20 + attrs.length * 20;
        ByteBuffer b = ByteBuffer.allocate(size).order(ByteOrder.LITTLE_ENDIAN);
        b.putShort((short) 0x0102).putShort((short) 16).putInt(size).putInt(1).putInt(-1);
        b.putInt(-1).putInt(s(name)).putShort((short) 20).putShort((short) 20).putShort((short) attrs.length).putShort((short) 0).putShort((short) 0).putShort((short) 0);
        for (byte[] a : attrs) b.put(a);
        return b.array();
    }
    static byte[] end(String name) {
        ByteBuffer b = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN);
        b.putShort((short) 0x0103).putShort((short) 16).putInt(24).putInt(1).putInt(-1).putInt(-1).putInt(s(name));
        return b.array();
    }
    static byte[] ns(int type) {
        ByteBuffer b = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN);
        b.putShort((short) type).putShort((short) 16).putInt(24).putInt(1).putInt(-1).putInt(s("android")).putInt(s(NS));
        return b.array();
    }
    static byte[] buildManifest() throws IOException {
        pool.clear();
        // aapt2 puts attribute names first (matching the resource map)
        String[] attrNames = {"versionCode", "versionName", "minSdkVersion", "targetSdkVersion", "name", "label", "icon", "authorities"};
        for (String a : attrNames) s(a);
        ByteArrayOutputStream body = new ByteArrayOutputStream();
        body.write(ns(0x0100));
        body.write(start("manifest", attr("versionCode", true, 1), attr("versionName", true, "ASKARPH_VNAME"), attr("package", false, "com.askartpl.placeholderappid.aaaaaaaa")));
        body.write(start("uses-sdk", attr("minSdkVersion", true, 21), attr("targetSdkVersion", true, 34))); body.write(end("uses-sdk"));
        body.write(start("uses-permission", attr("name", true, "android.permission.INTERNET"))); body.write(end("uses-permission"));
        body.write(start("uses-permission", attr("name", true, "android.permission.ACCESS_NETWORK_STATE"))); body.write(end("uses-permission"));
        body.write(start("permission", attr("name", true, "com.askartpl.placeholderappid.aaaaaaaa.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION"))); body.write(end("permission"));
        body.write(start("application", attr("label", true, "ASKARPH_APP_LABEL"), attr("icon", true, 0x7f010000)));
        body.write(start("activity", attr("name", true, "com.askar.shell.MainActivity"))); body.write(end("activity"));
        body.write(start("provider", attr("name", true, "x.Y"), attr("authorities", true, "com.askartpl.placeholderappid.aaaaaaaa.files"))); body.write(end("provider"));
        body.write(end("application"));
        body.write(end("manifest"));
        body.write(ns(0x0101));
        // resource map
        ByteBuffer rm = ByteBuffer.allocate(8 + attrNames.length * 4).order(ByteOrder.LITTLE_ENDIAN);
        rm.putShort((short) 0x0180).putShort((short) 8).putInt(8 + attrNames.length * 4);
        int[] ids = {0x0101021b, 0x0101021c, 0x0101020c, 0x01010270, 0x01010003, 0x01010001, 0x01010002, 0x01010018};
        for (int id : ids) rm.putInt(id);
        // UTF-16 pool
        ByteArrayOutputStream sd = new ByteArrayOutputStream();
        int[] offs = new int[pool.size()];
        for (int i = 0; i < pool.size(); i++) {
            offs[i] = sd.size(); String v = pool.get(i);
            sd.write(v.length() & 0xff); sd.write(v.length() >> 8);
            for (char c : v.toCharArray()) { sd.write(c & 0xff); sd.write(c >> 8); }
            sd.write(0); sd.write(0);
        }
        while (sd.size() % 4 != 0) sd.write(0);
        int ps = 28 + pool.size() * 4 + sd.size();
        ByteBuffer pb = ByteBuffer.allocate(ps).order(ByteOrder.LITTLE_ENDIAN);
        pb.putShort((short) 1).putShort((short) 28).putInt(ps).putInt(pool.size()).putInt(0).putInt(0).putInt(28 + pool.size() * 4).putInt(0);
        for (int o : offs) pb.putInt(o);
        pb.put(sd.toByteArray());
        int total = 8 + ps + rm.capacity() + body.size();
        ByteBuffer f = ByteBuffer.allocate(total).order(ByteOrder.LITTLE_ENDIAN);
        f.putShort((short) 3).putShort((short) 8).putInt(total).put(pb.array()).put(rm.array()).put(body.toByteArray());
        return f.array();
    }

    static byte[] png(int w, int rgb) throws IOException {
        BufferedImage im = new BufferedImage(w, w, BufferedImage.TYPE_INT_ARGB);
        for (int y = 0; y < w; y++) for (int x = 0; x < w; x++) im.setRGB(x, y, 0xff000000 | rgb);
        ByteArrayOutputStream o = new ByteArrayOutputStream(); ImageIO.write(im, "png", o); return o.toByteArray();
    }

    static void zipPut(ZipOutputStream z, String n, byte[] d, boolean stored) throws IOException {
        ZipEntry e = new ZipEntry(n);
        if (stored) { e.setMethod(ZipEntry.STORED); e.setSize(d.length); e.setCompressedSize(d.length); CRC32 c = new CRC32(); c.update(d); e.setCrc(c.getValue()); }
        z.putNextEntry(e); z.write(d); z.closeEntry();
    }

    public static void main(String[] a) throws Exception {
        File dir = new File("/tmp/apkbtest"); SafeZip.deleteRecursive(dir); dir.mkdirs();

        /* ---- AXML round trip ---- */
        byte[] man = buildManifest();
        Axml x = Axml.parse(man);
        check("parse: package attr", "com.askartpl.placeholderappid.aaaaaaaa".equals(x.getStringAttr("manifest", "package")));
        check("parse: minSdk=21", x.getIntAttr("uses-sdk", "minSdkVersion", -1) == 21);
        check("roundtrip identical", Arrays.equals(Axml.parse(x.toBytes()).toBytes(), x.toBytes()));
        check("roundtrip same byte length as original", x.toBytes().length == man.length);

        ApkAssembler.Options o = new ApkAssembler.Options();
        o.packageName = "com.askar.mathgame"; o.appName = "لعبة الرياضيات 🎲"; o.versionName = "1.2.0"; o.versionCode = 7; o.minSdk = 24; o.internet = false; o.configJson = "{}";
        ApkAssembler.Report rep = new ApkAssembler.Report();
        byte[] patched = ApkAssembler.patchManifest(man, o, rep);
        Axml p = Axml.parse(patched);
        check("patched package", "com.askar.mathgame".equals(p.getStringAttr("manifest", "package")));
        check("patched label (Arabic + emoji)", "لعبة الرياضيات 🎲".equals(p.getStringAttr("application", "label")));
        check("patched versionName", "1.2.0".equals(p.getStringAttr("manifest", "versionName")));
        check("patched versionCode", p.getIntAttr("manifest", "versionCode", -1) == 7);
        check("patched minSdk", p.getIntAttr("uses-sdk", "minSdkVersion", -1) == 24);
        check("targetSdk untouched", p.getIntAttr("uses-sdk", "targetSdkVersion", -1) == 34);
        check("INTERNET removed", p.elements("uses-permission").isEmpty());
        check("permission name renamed", p.getStringAttr("permission", "name").equals("com.askar.mathgame.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION"));
        check("provider authority renamed", p.getStringAttr("provider", "authorities").equals("com.askar.mathgame.files"));
        check("no placeholder left", !new String(patched, StandardCharsets.UTF_16LE).contains("askartpl"));
        check("activity class kept", p.getStringAttr("activity", "name").equals("com.askar.shell.MainActivity"));
        // chunk sizes / header consistency
        ByteBuffer pbuf = ByteBuffer.wrap(patched).order(ByteOrder.LITTLE_ENDIAN);
        check("header total size == file length", pbuf.getInt(4) == patched.length);
        check("pool size multiple of 4", pbuf.getInt(8 + 4) % 4 == 0);
        // resource map still right after pool, same length
        int poolSize = pbuf.getInt(12);
        check("resource map follows pool", (pbuf.getShort(8 + poolSize) & 0xffff) == 0x0180);
        // internet kept variant
        o.internet = true; Axml k = Axml.parse(ApkAssembler.patchManifest(man, o, new ApkAssembler.Report()));
        check("INTERNET kept when enabled", k.elements("uses-permission").size() == 2);
        // minSdk below template rejected
        o.minSdk = 19; boolean threw = false; try { ApkAssembler.patchManifest(man, o, new ApkAssembler.Report()); } catch (IllegalStateException e) { threw = true; } check("minSdk below template rejected", threw);
        o.minSdk = 24;
        // UTF-8 pool variant: flip flag and re-write
        // (aapt sometimes emits UTF-8 pools) — build by toggling flag on a parsed copy
        byte[] u8 = man.clone(); ByteBuffer ub = ByteBuffer.wrap(u8).order(ByteOrder.LITTLE_ENDIAN);
        // convert: parse, set flag via reflection-free path: re-encode through Axml with utf8 flag
        java.lang.reflect.Field fl = Axml.class.getDeclaredField("poolFlags"); fl.setAccessible(true);
        Axml ux = Axml.parse(man); fl.setInt(ux, 1 << 8); byte[] utf8Man = ux.toBytes();
        Axml up = Axml.parse(ApkAssembler.patchManifest(utf8Man, o, new ApkAssembler.Report()));
        check("UTF-8 pool: label patched", "لعبة الرياضيات 🎲".equals(up.getStringAttr("application", "label")));
        check("UTF-8 pool: package patched", "com.askar.mathgame".equals(up.getStringAttr("manifest", "package")));

        /* ---- package validation ---- */
        check("valid pkg", ApkAssembler.validatePackage("com.askar.app2") == null);
        check("invalid pkg single", ApkAssembler.validatePackage("askar") != null);
        check("invalid pkg digit start", ApkAssembler.validatePackage("com.1app") != null);
        check("invalid pkg keyword", ApkAssembler.validatePackage("com.class.app") != null);
        check("invalid pkg arabic", ApkAssembler.validatePackage("com.عسكر") != null);

        /* ---- SafeZip ---- */
        File evil = new File(dir, "evil.zip");
        try (ZipOutputStream z = new ZipOutputStream(new FileOutputStream(evil))) {
            zipPut(z, "site/index.html", "<h1>hi</h1>".getBytes(), false);
            zipPut(z, "site/css/a.css", "body{}".getBytes(), false);
            zipPut(z, "../../escape.txt", "x".getBytes(), false);
            zipPut(z, "/abs.txt", "x".getBytes(), false);
            zipPut(z, "site/lib/evil.so", "x".getBytes(), false);
            zipPut(z, "site/app.apk", "x".getBytes(), false);
            zipPut(z, "__MACOSX/site/._index.html", "x".getBytes(), false);
        }
        File ex = new File(dir, "ex"); ex.mkdirs();
        SafeZip.Result zr; try (InputStream in = new FileInputStream(evil)) { zr = SafeZip.extract(in, ex, null); }
        check("zip: 2 good files", zr.files == 2);
        check("zip: no escape", !new File(dir, "escape.txt").exists() && !new File("/tmp/escape.txt").exists());
        check("zip: skipped 4", zr.skipped.size() == 4);
        File web = SafeZip.unwrapSingleFolder(ex);
        check("zip: unwrap single folder", web.getName().equals("site"));
        threw = false; try { SafeZip.extract(new ByteArrayInputStream("not a zip".getBytes()), new File(dir, "bad"), null); } catch (IOException e) { threw = true; }
        check("zip: corrupt rejected", threw);

        /* ---- full assemble ---- */
        File tpl = new File(dir, "shell.apk");
        try (ZipOutputStream z = new ZipOutputStream(new FileOutputStream(tpl))) {
            zipPut(z, "AndroidManifest.xml", man, false);
            zipPut(z, "classes.dex", new byte[]{'d', 'e', 'x', '\n', '0', '3', '5', 0}, false);
            zipPut(z, "resources.arsc", new byte[]{2, 0, 12, 0, 0, 0, 0, 0}, true);
            zipPut(z, "res/mipmap-mdpi-v4/ic_launcher.png", png(48, 0x00ff00), true);
            zipPut(z, "res/xx.png", png(192, 0x00ff00), true); // shortened path, still matched by size
            zipPut(z, "assets/www/index.html", "OLD".getBytes(), false);
            zipPut(z, "META-INF/MANIFEST.MF", "x".getBytes(), false);
            zipPut(z, "META-INF/CERT.RSA", "x".getBytes(), false);
        }
        o.internet = true; o.configJson = "{\"entry\":\"index.html\"}";
        File out = new File(dir, "out-unsigned.apk");
        int[] last = {0};
        ApkAssembler.Report ar = ApkAssembler.assemble(tpl, web, o, px -> png(px, 0xff0000), out, new ApkAssembler.Progress() {
            public void step(String m, int pc) { last[0] = Math.max(last[0], pc); }
            public boolean isCancelled() { return false; }
        });
        List<String> ents = ApkAssembler.listEntries(out);
        check("assemble: www files added", ents.contains("assets/www/index.html") && ents.contains("assets/www/css/a.css"));
        check("assemble: config added", ents.contains("assets/askar_config.json"));
        check("assemble: old signature removed", !ents.contains("META-INF/CERT.RSA") && !ents.contains("META-INF/MANIFEST.MF"));
        check("assemble: 2 icons replaced", ar.iconsReplaced == 2);
        check("assemble: progress reported", last[0] >= 50);
        try (ZipFile z = new ZipFile(out)) {
            check("assemble: resources.arsc STORED", z.getEntry("resources.arsc").getMethod() == ZipEntry.STORED);
            byte[] idx = z.getInputStream(z.getEntry("assets/www/index.html")).readAllBytes();
            check("assemble: user index replaces template", new String(idx).equals("<h1>hi</h1>"));
            byte[] icon = z.getInputStream(z.getEntry("res/xx.png")).readAllBytes();
            BufferedImage bi = ImageIO.read(new ByteArrayInputStream(icon));
            check("assemble: icon is new (red, 192px)", bi.getWidth() == 192 && (bi.getRGB(5, 5) & 0xffffff) == 0xff0000);
            Axml am = Axml.parse(z.getInputStream(z.getEntry("AndroidManifest.xml")).readAllBytes());
            check("assemble: manifest patched inside apk", "com.askar.mathgame".equals(am.getStringAttr("manifest", "package")));
        }
        // cancel
        threw = false;
        try { ApkAssembler.assemble(tpl, web, o, null, new File(dir, "c.apk"), new ApkAssembler.Progress() { public void step(String m, int pc) {} public boolean isCancelled() { return true; } }); } catch (IOException e) { threw = e.getMessage().contains("أُلغيت"); }
        check("assemble: cancel works", threw);

        /* ---- keys ---- */
        CertUtil.SigningKey key = CertUtil.generate("أحمد عسكر", "Askar Online", "EG", 30);
        check("cert: self-signed verifies", true);
        check("cert: validity ~30y", key.cert.getNotAfter().getTime() - key.cert.getNotBefore().getTime() > 29L * 365 * 86400000);
        check("cert: SHA256withRSA", key.cert.getSigAlgName().equalsIgnoreCase("SHA256withRSA"));
        check("cert: subject has CN", key.cert.getSubjectX500Principal().getName().contains("CN="));
        File p12 = new File(dir, "k.p12");
        CertUtil.savePkcs12(key, "askar", "s3cret-pass".toCharArray(), p12);
        CertUtil.SigningKey back = CertUtil.loadPkcs12(p12, "s3cret-pass".toCharArray());
        check("p12: reload same cert", Arrays.equals(back.cert.getEncoded(), key.cert.getEncoded()));
        threw = false; try { CertUtil.loadPkcs12(p12, "wrong".toCharArray()); } catch (IOException e) { threw = e.getMessage().contains("كلمة المرور"); }
        check("p12: wrong password -> clear Arabic error", threw);
        System.out.println("fingerprint " + CertUtil.sha256Fingerprint(key.cert));

        System.out.println("\n" + pass + " passed, " + fail + " failed");
        System.exit(fail == 0 ? 0 : 1);
    }
}
