plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.askar.apkbuilder"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.askar.apkbuilder"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0-poc"
    }

    buildTypes {
        release {
            // مُعطّل عمدًا: apksig و Room يحتاجان قواعد ProGuard إضافية، والمرحلة الحالية إثبات فكرة
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildFeatures { compose = true }

    // القالب (shell) يُنسخ هنا تلقائيًا بعد بنائه
    sourceSets["main"].assets.srcDir(layout.buildDirectory.dir("generated/shellAsset"))

    androidResources {
        noCompress += "apk"
    }
    packaging {
        resources.excludes += setOf("META-INF/LICENSE*", "META-INF/NOTICE*")
    }
}

// يبني القالب أولًا ثم ينسخه إلى assets/template/shell_template.apk داخل تطبيق البناء
val copyShellTemplate by tasks.registering(Copy::class) {
    dependsOn(":shell:assembleRelease")
    from(rootProject.file("shell/build/outputs/apk/release/shell-release-unsigned.apk"))
    into(layout.buildDirectory.dir("generated/shellAsset/template"))
    rename { "shell_template.apk" }
}
tasks.named("preBuild") { dependsOn(copyShellTemplate) }

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")

    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    // مكتبة Google الرسمية لتوقيع APK والتحقق منه (v1 + v2 + v3) وتتولى المحاذاة zipalign
    implementation("com.android.tools.build:apksig:8.7.3")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}
