package com.askar.apkbuilder.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.askar.apkbuilder.MainActivity
import com.askar.apkbuilder.Nav
import com.askar.apkbuilder.Screen
import com.askar.apkbuilder.data.ProjectEntity
import kotlinx.coroutines.launch

private val IMPORT_TYPES = arrayOf("text/html", "application/zip", "application/x-zip-compressed", "application/octet-stream", "text/plain")

@Composable
fun HomeScreen(nav: Nav, activity: MainActivity) {
    val projects by app.db.projects().all().collectAsState(initial = null)
    val build by app.builder.ui.collectAsState()
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun doImport(uri: Uri) {
        if (busy) return
        busy = true
        scope.launch {
            try { val p = app.projects.import(uri); nav.go(Screen.Project(p.id)) }
            catch (e: Exception) { error = e.message ?: "تعذّر الاستيراد" }
            finally { busy = false }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) doImport(uri) }

    // ملف وصل من "فتح بواسطة" أو "مشاركة"
    LaunchedEffect(activity.incoming) {
        activity.incoming?.let { u -> activity.incoming = null; doImport(u) }
    }

    Page("Askar APK Builder", nav, actions = {
        IconButton(onClick = { nav.go(Screen.History) }) { Icon(Icons.AutoMirrored.Filled.List, "سجل البناء") }
        IconButton(onClick = { nav.go(Screen.Keys) }) { Icon(Icons.Filled.Lock, "مفاتيح التوقيع") }
        IconButton(onClick = { nav.go(Screen.Settings) }) { Icon(Icons.Filled.Settings, "الإعدادات") }
    }) { pad ->
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = pad.calculateTopPadding() + 8.dp, bottom = pad.calculateBottomPadding() + 24.dp)) {
            item {
                Card(Modifier.fillMaxWidth().padding(12.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("حوّل صفحة HTML أو مشروع ويب إلى تطبيق أندرويد", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("كل شيء يحدث على هاتفك بدون إنترنت وبدون سيرفر: استيراد ← إعدادات ← معاينة ← بناء وتوقيع ← تثبيت.",
                            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(enabled = !busy, onClick = { picker.launch(IMPORT_TYPES) }, modifier = Modifier.weight(1f)) { Text("استيراد HTML أو ZIP") }
                        }
                        if (busy) Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp); Spacer(Modifier.width(8.dp)); Text("جارٍ الاستيراد والفحص…")
                        }
                    }
                }
            }
            if (build.status == "running") item {
                OutlinedButton(onClick = { nav.go(Screen.Build) }, modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                    Text("يوجد بناء قيد التنفيذ (${build.percent}%) — اضغط للمتابعة")
                }
            }
            item {
                Text("مشاريعي", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
            }
            val list = projects
            if (list == null) item { Box(Modifier.fillMaxWidth().padding(24.dp), Alignment.Center) { CircularProgressIndicator() } }
            else if (list.isEmpty()) item {
                Text("لا توجد مشاريع بعد.\nاضغط \"استيراد HTML أو ZIP\" لتبدأ.", textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(32.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            else items(list, key = { it.id }) { p -> ProjectRow(p) { nav.go(Screen.Project(p.id)) } }
        }
    }
    ErrorDialog(error) { error = null }
}

@Composable
private fun ProjectRow(p: ProjectEntity, onClick: () -> Unit) {
    val bmp = remember(p.id, p.hasIcon, p.updatedAt) { app.projects.iconBitmap(p).asImageBitmap() }
    Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp).clickable(onClick = onClick)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Image(bmp, null, Modifier.size(48.dp).clip(RoundedCornerShape(10.dp)))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(p.appName, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(p.packageName, style = MaterialTheme.typography.bodySmall, maxLines = 1, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(2.dp))
                Text("${p.fileCount} ملف • ${fmtSize(p.sizeBytes)} • v${p.versionName}", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
