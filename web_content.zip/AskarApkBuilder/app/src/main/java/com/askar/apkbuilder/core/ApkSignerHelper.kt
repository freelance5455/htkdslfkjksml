package com.askar.apkbuilder.core

import com.android.apksig.ApkSigner
import com.android.apksig.ApkVerifier
import com.askar.apkbuilder.engine.CertUtil
import java.io.File

/** التوقيع والتحقق باستخدام مكتبة Google الرسمية apksig (نفس المستخدمة في Android Studio). */
object ApkSignerHelper {

    fun sign(unsigned: File, out: File, key: CertUtil.SigningKey, minSdk: Int) {
        val cfg = ApkSigner.SignerConfig.Builder("ASKAR", key.key, listOf(key.cert)).build()
        ApkSigner.Builder(listOf(cfg))
            .setInputApk(unsigned)
            .setOutputApk(out)
            .setMinSdkVersion(minSdk)
            .setV1SigningEnabled(minSdk < 24)   // v1 مطلوب فقط لأندرويد 6 وأقدم
            .setV2SigningEnabled(true)
            .setV3SigningEnabled(true)
            .build()
            .sign()
    }

    data class Verify(val ok: Boolean, val schemes: String, val errors: List<String>, val warnings: List<String>)

    fun verify(apk: File, minSdk: Int): Verify {
        val r = ApkVerifier.Builder(apk).setMinCheckedPlatformVersion(minSdk).build().verify()
        val errors = buildList {
            r.errors.forEach { add(it.toString()) }
            r.v1SchemeSigners.forEach { s -> s.errors.forEach { add("v1: $it") } }
            r.v2SchemeSigners.forEach { s -> s.errors.forEach { add("v2: $it") } }
            r.v3SchemeSigners.forEach { s -> s.errors.forEach { add("v3: $it") } }
        }
        val schemes = buildList {
            if (r.isVerifiedUsingV1Scheme) add("v1")
            if (r.isVerifiedUsingV2Scheme) add("v2")
            if (r.isVerifiedUsingV3Scheme) add("v3")
        }.joinToString(" + ")
        return Verify(r.isVerified, schemes, errors, r.warnings.map { it.toString() })
    }
}
