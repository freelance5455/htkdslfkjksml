package com.askar.apkbuilder.core

import android.os.StatFs
import com.askar.apkbuilder.AskarApp
import com.askar.apkbuilder.data.BuildEntity
import com.askar.apkbuilder.data.ProjectEntity
import com.askar.apkbuilder.engine.ApkAssembler
import com.askar.apkbuilder.engine.CertUtil
import com.askar.apkbuilder.engine.SafeZip
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/** مراحل البناء الحقيقية — تظهر كما هي في شاشة التقدم. */
val BUILD_STAGES = listOf(
    "فحص المشروع والمساحة المتاحة",
    "فتح مفتاح التوقيع",
    "تجهيز القالب",
    "تعديل المانيفست والأيقونات وإضافة الملفات",
    "توقيع APK ‏(v1/v2/v3) والمحاذاة",
    "التحقق من التوقيع",
    "حفظ النتيجة",
)

data class BuildUi(
    val status: String = "idle",          // idle | running | success | failed | cancelled
    val stage: Int = -1,
    val percent: Int = 0,
    val message: String = "",
    val log: List<String> = emptyList(),
    val buildId: Long = 0,
    val error: String? = null,
    val projectId: String? = null,
)

class BuildManager(private val app: AskarApp) {
    private val _ui = MutableStateFlow(BuildUi())
    val ui: StateFlow<BuildUi> = _ui
    private var job: Job? = null
    private val cancelled = AtomicBoolean(false)

    val isRunning get() = _ui.value.status == "running"

    private fun log(msg: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        _ui.value = _ui.value.copy(log = _ui.value.log + "[$t] $msg")
    }

    private fun stage(i: Int, pct: Int) {
        _ui.value = _ui.value.copy(stage = i, percent = pct, message = BUILD_STAGES[i])
        log("▶ " + BUILD_STAGES[i])
    }

    private fun checkCancel() { if (cancelled.get()) throw CancellationException("أُلغي البناء") }

    fun cancel() { if (isRunning) { cancelled.set(true); log("طلب إلغاء…") } }

    fun reset() { if (!isRunning) _ui.value = BuildUi() }

    /** ينسخ القالب من assets مرة لكل إصدار من التطبيق. */
    private fun templateFile(): File {
        // المفتاح = وقت آخر تثبيت/تحديث للتطبيق، حتى يُنسخ القالب الجديد بعد كل تحديث
        val stamp = runCatching { app.packageManager.getPackageInfo(app.packageName, 0).lastUpdateTime }.getOrDefault(0L)
        val out = File(app.filesDir, "template/shell_$stamp.apk")
        if (out.isFile && out.length() > 0) return out
        out.parentFile?.listFiles()?.forEach { it.delete() }
        out.parentFile?.mkdirs()
        try {
            app.assets.open("template/shell_template.apk").use { i -> out.outputStream().use { i.copyTo(it) } }
        } catch (e: IOException) {
            throw IOException("قالب التطبيق (shell_template.apk) غير موجود داخل Askar APK Builder. ابنِ المشروع كاملًا من Android Studio حتى تُنفَّذ مهمة copyShellTemplate.")
        }
        return out
    }

    fun start(p: ProjectEntity, keyId: String, password: CharArray) {
        if (isRunning) return
        cancelled.set(false)
        _ui.value = BuildUi(status = "running", stage = 0, message = "بدء البناء", projectId = p.id)
        job = app.scope.launch {
            val db = app.db
            val keyName = db.keys().get(keyId)?.name ?: "?"
            val buildId = db.builds().insert(BuildEntity(projectId = p.id, appName = p.appName, packageName = p.packageName,
                versionName = p.versionName, versionCode = p.versionCode, status = "running", startedAt = System.currentTimeMillis(), keyName = keyName))
            _ui.value = _ui.value.copy(buildId = buildId)
            val work = File(app.cacheDir, "build-$buildId").apply { mkdirs() }
            val t0 = System.currentTimeMillis()
            try {
                // 1) فحص
                stage(0, 2)
                val www = app.projects.www(p.id)
                if (!www.isDirectory) throw IOException("ملفات المشروع غير موجودة — أعد استيراده")
                ApkAssembler.validatePackage(p.packageName)?.let { throw IOException(it) }
                if (!File(www, p.entry).isFile) throw IOException("صفحة البداية ${p.entry} غير موجودة داخل المشروع")
                val size = SafeZip.dirSize(www)
                val free = StatFs(app.filesDir.path).availableBytes
                val need = size * 3 + 30L * 1024 * 1024
                log("حجم المشروع: ${size / 1024} KB — المساحة الحرة: ${free / 1048576} MB")
                if (free < need) throw IOException("المساحة غير كافية. مطلوب تقريبًا ${need / 1048576} MB والمتاح ${free / 1048576} MB")
                val scan = app.projects.scan(p)
                scan.missing.take(20).forEach { log("⚠ ملف مفقود: $it") }
                scan.warnings.forEach { log("⚠ $it") }
                checkCancel()

                // 2) المفتاح
                stage(1, 8)
                val key: CertUtil.SigningKey = try { app.keys.load(keyId, password) } finally { password.fill('\u0000') }
                log("المفتاح: $keyName")
                checkCancel()

                // 3) القالب
                stage(2, 12)
                val tpl = templateFile()
                log("القالب: ${tpl.length() / 1024} KB")

                // 4) التجميع
                stage(3, 15)
                val opts = ApkAssembler.Options().apply {
                    packageName = p.packageName; appName = p.appName.trim(); versionName = p.versionName.trim().ifEmpty { "1.0" }
                    versionCode = p.versionCode; minSdk = p.minSdk; internet = p.internet; configJson = app.projects.configJson(p)
                }
                val unsigned = File(work, "unsigned.apk")
                val report = ApkAssembler.assemble(tpl, www, opts, app.projects.iconProvider(p), unsigned, object : ApkAssembler.Progress {
                    override fun step(message: String, percent: Int) { _ui.value = _ui.value.copy(percent = 15 + percent * 50 / 100, message = message) }
                    override fun isCancelled() = cancelled.get()
                })
                report.log.forEach { log(it) }
                checkCancel()

                // 5) التوقيع
                stage(4, 70)
                val signed = File(work, "signed.apk")
                ApkSignerHelper.sign(unsigned, signed, key, p.minSdk)
                unsigned.delete()
                log("حجم الملف الموقّع: ${signed.length() / 1024} KB")
                checkCancel()

                // 6) التحقق
                stage(5, 88)
                val v = ApkSignerHelper.verify(signed, p.minSdk)
                v.warnings.take(5).forEach { log("تنبيه: $it") }
                if (!v.ok) { v.errors.forEach { log("✖ $it") }; throw IOException("فشل التحقق من التوقيع") }
                log("✔ التوقيع صحيح (${v.schemes})")

                // 7) الحفظ
                stage(6, 95)
                val outDir = File(app.filesDir, "builds").apply { mkdirs() }
                val safeName = p.appName.replace(Regex("[^\\p{L}\\p{N}._-]+"), "_").take(40).ifEmpty { "app" }
                val out = File(outDir, "${safeName}-v${opts.versionName}-$buildId.apk")
                if (!signed.renameTo(out)) { signed.copyTo(out, overwrite = true); signed.delete() }
                val secs = (System.currentTimeMillis() - t0) / 1000.0
                log("✔ تم البناء في ${"%.1f".format(Locale.US, secs)} ث")
                db.builds().update(db.builds().get(buildId)!!.copy(status = "success", finishedAt = System.currentTimeMillis(),
                    apkPath = out.path, apkSize = out.length(), certSha256 = CertUtil.sha256Fingerprint(key.cert),
                    message = "تم بنجاح", log = _ui.value.log.joinToString("\n")))
                pruneOldBuilds()
                _ui.value = _ui.value.copy(status = "success", stage = BUILD_STAGES.size, percent = 100, message = "تم بنجاح")
            } catch (e: Throwable) {
                val wasCancel = e is CancellationException || cancelled.get()
                val msg = if (wasCancel) "أُلغي البناء" else (e.message ?: e.javaClass.simpleName)
                log((if (wasCancel) "■ " else "✖ ") + msg)
                if (!wasCancel) e.cause?.message?.let { log("السبب: $it") }
                withContext(NonCancellable) {
                    db.builds().get(buildId)?.let {
                        db.builds().update(it.copy(status = if (wasCancel) "cancelled" else "failed", finishedAt = System.currentTimeMillis(),
                            message = msg, log = _ui.value.log.joinToString("\n")))
                    }
                }
                _ui.value = _ui.value.copy(status = if (wasCancel) "cancelled" else "failed", error = msg)
            } finally {
                password.fill('\u0000')
                SafeZip.deleteRecursive(work)
            }
        }
    }

    /** يحتفظ بآخر N ملفات APK فقط (السجل نفسه يبقى). */
    private suspend fun pruneOldBuilds() {
        val keep = app.prefs.keepBuilds
        app.db.builds().successful().drop(keep).forEach { b ->
            b.apkPath?.let { File(it).delete() }
            app.db.builds().update(b.copy(apkPath = null, message = "حُذف الملف تلقائيًا (الاحتفاظ بآخر $keep)"))
        }
    }
}
