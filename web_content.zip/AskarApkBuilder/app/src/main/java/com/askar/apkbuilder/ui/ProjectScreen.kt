@file:OptIn(ExperimentalLayoutApi::class)

package com.askar.apkbuilder.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.CompositionLocalProvider
import com.askar.apkbuilder.Nav
import com.askar.apkbuilder.Screen
import com.askar.apkbuilder.data.ProjectEntity
import com.askar.apkbuilder.engine.ApkAssembler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val SWATCHES = listOf("#1565C0", "#2859A5", "#173B70", "#0D47A1", "#00897B", "#2E7D32", "#6A1B9A", "#C62828", "#EF6C00", "#F39A35", "#212121", "#000000", "#FFFFFF", "#F5F7FB")
private val MIN_SDKS = listOf(21 to "5.0", 23 to "6.0", 24 to "7.0", 26 to "8.0", 28 to "9", 29 to "10")
private val ORIENTATIONS = listOf("unspecified" to "تلقائي", "portrait" to "طولي", "landscape" to "عرضي", "sensor" to "حسب الحساس")
private val LINK_MODES = listOf("browser" to "تفتح في المتصفح", "inside" to "داخل التطبيق", "block" to "ممنوعة")

private fun validColor(s: String) = Regex("^#([0-9a-fA-F]{6}|[0-9a-fA-F]{8})$").matches(s)

@Composable
fun ProjectScreen(nav: Nav, id: String) {
    val stored by app.db.projects().observe(id).collectAsState(initial = null)
    var draft by remember { mutableStateOf<ProjectEntity?>(null) }
    LaunchedEffect(stored?.id) { if (draft == null) draft = stored }
    // تحديثات من خارج النموذج (أيقونة / استبدال ملفات)
    LaunchedEffect(stored?.updatedAt, stored?.hasIcon, stored?.fileCount) {
        val s = stored; val d = draft
        if (s != null && d != null) draft = d.copy(hasIcon = s.hasIcon, entry = s.entry, fileCount = s.fileCount, sizeBytes = s.sizeBytes, sourceName = s.sourceName)
    }
    val p = draft
    if (p == null) { Page("المشروع", nav) { Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() } }; return }

    val scope = rememberCoroutineScope()
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var showBuild by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var scan by remember { mutableStateOf<com.askar.apkbuilder.core.ProjectStore.ScanResult?>(null) }
    val htmlFiles = remember(p.fileCount, p.sourceName) { app.projects.htmlFiles(p.id) }

    val pkgError = ApkAssembler.validatePackage(p.packageName)
    val nameError = if (p.appName.isBlank()) "اسم التطبيق مطلوب" else if (p.appName.length > 50) "الاسم طويل جدًا" else null
    val vcError = if (p.versionCode < 1) "رقم موجب" else null
    val colorError = !validColor(p.statusBarColor) || !validColor(p.navBarColor)
    val valid = pkgError == null && nameError == null && vcError == null && !colorError && p.versionName.isNotBlank()

    // حفظ تلقائي بعد التوقف عن الكتابة
    LaunchedEffect(p) {
        delay(500)
        if (valid && p != stored) app.db.projects().upsert(p.copy(updatedAt = System.currentTimeMillis()))
    }
    LaunchedEffect(p.entry, p.internet, p.fileCount) { scan = withContext(Dispatchers.IO) { app.projects.scan(p) } }

    val iconPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch { try { draft = app.projects.saveIcon(p, uri).let { s -> p.copy(hasIcon = s.hasIcon) } } catch (e: Exception) { error = e.message } }
    }
    val filesPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { busy = true; scope.launch {
            try { val n = app.projects.replaceFiles(p, uri); draft = p.copy(entry = n.entry, fileCount = n.fileCount, sizeBytes = n.sizeBytes, sourceName = n.sourceName) }
            catch (e: Exception) { error = e.message } finally { busy = false }
        } }
    }
    fun upd(f: (ProjectEntity) -> ProjectEntity) { draft = f(p) }

    Page(p.appName.ifBlank { "المشروع" }, nav) { pad ->
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(top = pad.calculateTopPadding(), bottom = pad.calculateBottomPadding() + 24.dp)) {

            Section("معلومات التطبيق") {
                OutlinedTextField(p.appName, { v -> upd { it.copy(appName = v) } }, label = { Text("اسم التطبيق (يظهر تحت الأيقونة)") },
                    singleLine = true, isError = nameError != null, supportingText = { nameError?.let { Text(it) } }, modifier = Modifier.fillMaxWidth())
                Ltr {
                    OutlinedTextField(p.packageName, { v -> upd { it.copy(packageName = v.trim()) } }, label = { Text("Package name") },
                        singleLine = true, isError = pkgError != null, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                        supportingText = { Text(pkgError ?: "معرّف فريد — لا تغيّره بعد نشر التطبيق وإلا سيُعتبر تطبيقًا آخر") }, modifier = Modifier.fillMaxWidth())
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Ltr { OutlinedTextField(p.versionName, { v -> upd { it.copy(versionName = v.take(30)) } }, label = { Text("versionName") }, singleLine = true, modifier = Modifier.weight(1f)) }
                    Ltr { OutlinedTextField(p.versionCode.toString(), { v -> upd { it.copy(versionCode = v.filter(Char::isDigit).take(9).toIntOrNull() ?: 0) } },
                        label = { Text("versionCode") }, singleLine = true, isError = vcError != null,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f)) }
                }
                Text("عند تحديث تطبيق مثبّت: زِد versionCode ووقّع بنفس المفتاح.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Section("الأيقونة") {
                val bmp = remember(p.hasIcon, p.appName, p.statusBarColor, stored?.updatedAt) { app.projects.iconBitmap(p).asImageBitmap() }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(bmp, "أيقونة", Modifier.size(72.dp).clip(RoundedCornerShape(16.dp)))
                    Spacer(Modifier.width(12.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Button(onClick = { iconPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) { Text("اختيار صورة") }
                        if (p.hasIcon) TextButton(onClick = { scope.launch { draft = p.copy(hasIcon = app.projects.clearIcon(p).hasIcon) } }) { Text("استخدام الأيقونة التلقائية") }
                    }
                }
                Text("تُقص الصورة مربعًا وتُولَّد منها 5 مقاسات (48 حتى 192 بكسل). الأفضل صورة مربعة 512×512.", style = MaterialTheme.typography.bodySmall)
            }

            Section("الألوان والاتجاه") {
                ColorPicker("لون شريط الحالة", p.statusBarColor) { v -> upd { it.copy(statusBarColor = v) } }
                ColorPicker("لون شريط التنقل", p.navBarColor) { v -> upd { it.copy(navBarColor = v) } }
                Text("اتجاه الشاشة")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ORIENTATIONS.forEach { (k, l) -> FilterChip(p.orientation == k, { upd { it.copy(orientation = k) } }, label = { Text(l) }) }
                }
            }

            Section("التوافق") {
                Text("أقل إصدار أندرويد يعمل عليه التطبيق")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    MIN_SDKS.forEach { (api, ver) -> FilterChip(p.minSdk == api, { upd { it.copy(minSdk = api) } }, label = { Text("أندرويد $ver") }) }
                }
                Text("targetSdk ثابت = 34 (من القالب).", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Section("السلوك") {
                SwitchRow("صلاحية الإنترنت", "أغلقها إذا كان مشروعك يعمل بالكامل بدون إنترنت", p.internet) { v -> upd { it.copy(internet = v) } }
                Text("الروابط الخارجية")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    LINK_MODES.forEach { (k, l) -> FilterChip(p.externalLinks == k, { upd { it.copy(externalLinks = k) } }, label = { Text(l) }) }
                }
                SwitchRow("السماح بالتنزيلات", "روابط التحميل تُحفظ في مجلد التنزيلات", p.downloads) { v -> upd { it.copy(downloads = v) } }
                SwitchRow("السماح بالتكبير (Zoom)", null, p.zoom) { v -> upd { it.copy(zoom = v) } }
            }

            Section("ملفات المشروع") {
                KeyValue("المصدر", p.sourceName)
                KeyValue("عدد الملفات", "${p.fileCount}")
                KeyValue("الحجم", fmtSize(p.sizeBytes))
                Text("صفحة البداية")
                htmlFiles.take(30).forEach { f ->
                    Row(Modifier.fillMaxWidth().selectable(p.entry == f) { upd { it.copy(entry = f) } }, verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(p.entry == f, { upd { it.copy(entry = f) } }); Ltr { Text(f, maxLines = 1) }
                    }
                }
                if (htmlFiles.size > 30) Text("… و${htmlFiles.size - 30} ملف HTML آخر", style = MaterialTheme.typography.bodySmall)
                OutlinedButton(enabled = !busy, onClick = { filesPicker.launch(arrayOf("text/html", "application/zip", "application/x-zip-compressed", "application/octet-stream")) }) {
                    Text(if (busy) "جارٍ الاستبدال…" else "تحديث الملفات (مع الإبقاء على الإعدادات)")
                }
            }

            Section("فحص المشروع") {
                val s = scan
                if (s == null) Text("جارٍ الفحص…")
                else if (s.missing.isEmpty() && s.warnings.isEmpty()) Text("✔ لم تُكتشف ملفات مفقودة", color = Color(0xFF2E7D32))
                else {
                    s.warnings.forEach { Text("⚠ $it", color = Color(0xFFEF6C00)) }
                    if (s.missing.isNotEmpty()) {
                        Text("ملفات مذكورة في الصفحات وغير موجودة (${s.missing.size}):", fontWeight = FontWeight.Bold)
                        s.missing.take(15).forEach { Ltr { Text("• $it", style = MaterialTheme.typography.bodySmall) } }
                    }
                }
                if (s != null && s.external.isNotEmpty()) Text("روابط خارجية: ${s.external.size} (تحتاج إنترنت)", style = MaterialTheme.typography.bodySmall)
                Text("الفحص يقرأ src/href/url() فقط؛ الملفات التي يحمّلها JavaScript ديناميكيًا تظهر في المعاينة.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { nav.go(Screen.Preview(p.id)) }, modifier = Modifier.fillMaxWidth()) { Text("معاينة داخل WebView") }
                Button(enabled = valid && !app.builder.isRunning, onClick = { showBuild = true }, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                    Text("بناء APK", fontWeight = FontWeight.Bold)
                }
                if (!valid) Text("صحّح الحقول المعلَّمة بالأحمر أولًا", color = MaterialTheme.colorScheme.error)
                TextButton(onClick = { confirmDelete = true }) { Text("حذف المشروع", color = MaterialTheme.colorScheme.error) }
            }
        }
    }

    if (showBuild) BuildDialog(onDismiss = { showBuild = false }, onKeys = { showBuild = false; nav.go(Screen.Keys) }) { keyId, pw ->
        showBuild = false
        scope.launch {
            val final = p.copy(updatedAt = System.currentTimeMillis())
            app.db.projects().upsert(final)
            app.prefs.defaultKeyId = keyId
            app.builder.start(final, keyId, pw)
            nav.go(Screen.Build)
        }
    }
    if (confirmDelete) ConfirmDialog("حذف المشروع؟", "ستُحذف ملفات المشروع وإعداداته من التطبيق. ملفات APK المبنية سابقًا تبقى في السجل.", "حذف", { confirmDelete = false }) {
        scope.launch { app.projects.delete(p); nav.back() }
    }
    ErrorDialog(error) { error = null }
}

@Composable
fun Ltr(content: @Composable () -> Unit) = CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr, content = content)

@Composable
private fun SwitchRow(title: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title)
            if (sub != null) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked, onChange)
    }
}

private fun parse(c: String): Color = runCatching { Color(android.graphics.Color.parseColor(c)) }.getOrDefault(Color.Gray)

@Composable
private fun ColorPicker(title: String, value: String, onChange: (String) -> Unit) {
    var text by remember(value) { mutableStateOf(value) }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(28.dp).clip(CircleShape).background(parse(value)).border(BorderStroke(1.dp, Color.Gray), CircleShape))
            Spacer(Modifier.width(8.dp))
            Text(title, Modifier.weight(1f))
            Ltr {
                OutlinedTextField(text, { t -> text = t.take(9); if (validColor(t)) onChange(t.uppercase()) }, singleLine = true,
                    isError = !validColor(text), modifier = Modifier.width(130.dp))
            }
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            SWATCHES.forEach { c ->
                Box(Modifier.size(30.dp).clip(CircleShape).background(parse(c))
                    .border(BorderStroke(if (c.equals(value, true)) 3.dp else 1.dp, if (c.equals(value, true)) MaterialTheme.colorScheme.primary else Color.LightGray), CircleShape)
                    .clickable { onChange(c) })
            }
        }
    }
}

/** اختيار مفتاح التوقيع ثم كلمة المرور. */
@Composable
private fun BuildDialog(onDismiss: () -> Unit, onKeys: () -> Unit, onStart: (String, CharArray) -> Unit) {
    val keys by app.db.keys().all().collectAsState(initial = null)
    var selected by remember { mutableStateOf(app.prefs.defaultKeyId) }
    var askPw by remember { mutableStateOf(false) }
    val list = keys
    if (askPw && selected != null) {
        PasswordDialog("كلمة مرور المفتاح", "تُستخدم لفتح مفتاح التوقيع فقط ولا تُحفظ.", confirmLabel = "ابدأ البناء", onDismiss = { askPw = false }) { pw -> onStart(selected!!, pw) }
        return
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("اختر مفتاح التوقيع") },
        text = {
            Column {
                when {
                    list == null -> CircularProgressIndicator()
                    list.isEmpty() -> Text("لا يوجد مفتاح توقيع بعد. أنشئ مفتاحًا جديدًا (مرة واحدة) واحتفظ بنسخة احتياطية منه.")
                    else -> list.forEach { k ->
                        Row(Modifier.fillMaxWidth().selectable(selected == k.id) { selected = k.id }, verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected == k.id, { selected = k.id })
                            Column { Text(k.name); Text(k.fingerprint.take(23) + "…", style = MaterialTheme.typography.bodySmall) }
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (list.isNullOrEmpty()) TextButton(onClick = onKeys) { Text("إدارة المفاتيح") }
            else TextButton(enabled = list.any { it.id == selected }, onClick = { askPw = true }) { Text("متابعة") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
    )
}
