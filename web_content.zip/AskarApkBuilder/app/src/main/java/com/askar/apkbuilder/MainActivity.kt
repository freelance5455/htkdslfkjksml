package com.askar.apkbuilder

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.askar.apkbuilder.ui.BuildScreen
import com.askar.apkbuilder.ui.HistoryScreen
import com.askar.apkbuilder.ui.HomeScreen
import com.askar.apkbuilder.ui.KeysScreen
import com.askar.apkbuilder.ui.PreviewScreen
import com.askar.apkbuilder.ui.ProjectScreen
import com.askar.apkbuilder.ui.ResultScreen
import com.askar.apkbuilder.ui.SettingsScreen

sealed class Screen {
    data object Home : Screen()
    data class Project(val id: String) : Screen()
    data class Preview(val id: String) : Screen()
    data object Build : Screen()
    data class Result(val buildId: Long) : Screen()
    data object History : Screen()
    data object Keys : Screen()
    data object Settings : Screen()
}

class Nav {
    val stack = mutableStateListOf<Screen>(Screen.Home)
    val current get() = stack.last()
    fun go(s: Screen) { stack.add(s) }
    fun back() { if (stack.size > 1) stack.removeAt(stack.lastIndex) }
    /** يستبدل الشاشة الحالية (مثلًا من شاشة البناء إلى النتيجة). */
    fun replace(s: Screen) { stack[stack.lastIndex] = s }
}

private val Blue = Color(0xFF1565C0)
private val LightColors = lightColorScheme(primary = Blue, secondary = Color(0xFFF39A35), background = Color(0xFFF5F7FB), surface = Color.White)
private val DarkColors = darkColorScheme(primary = Color(0xFF90CAF9), secondary = Color(0xFFFFB74D))

class MainActivity : ComponentActivity() {
    /** ملف مفتوح من تطبيق آخر (مشاركة / فتح بواسطة) ينتظر الاستيراد. */
    var incoming by mutableStateOf<Uri?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        incoming = extractUri(intent)
        val app = application as AskarApp
        setContent {
            val theme by app.prefs.theme.collectAsState()
            val dark = when (theme) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
            MaterialTheme(colorScheme = if (dark) DarkColors else LightColors) {
                // الواجهة عربية بالكامل، فنثبّت الاتجاه من اليمين لليسار حتى لو لغة الهاتف إنجليزية
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    AppRoot(this)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        extractUri(intent)?.let { incoming = it }
    }

    @Suppress("DEPRECATION")
    private fun extractUri(i: Intent?): Uri? = when (i?.action) {
        Intent.ACTION_VIEW -> i.data
        Intent.ACTION_SEND -> if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java) else i.getParcelableExtra(Intent.EXTRA_STREAM)
        else -> null
    }
}

@Composable
fun AppRoot(activity: MainActivity) {
    val nav = remember { Nav() }
    BackHandler(enabled = nav.stack.size > 1) { nav.back() }
    when (val s = nav.current) {
        Screen.Home -> HomeScreen(nav, activity)
        is Screen.Project -> ProjectScreen(nav, s.id)
        is Screen.Preview -> PreviewScreen(nav, s.id)
        Screen.Build -> BuildScreen(nav)
        is Screen.Result -> ResultScreen(nav, s.buildId)
        Screen.History -> HistoryScreen(nav)
        Screen.Keys -> KeysScreen(nav)
        Screen.Settings -> SettingsScreen(nav)
    }
}
