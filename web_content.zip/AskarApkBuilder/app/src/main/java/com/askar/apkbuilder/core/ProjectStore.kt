package com.askar.apkbuilder.core

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.provider.OpenableColumns
import com.askar.apkbuilder.data.AppDb
import com.askar.apkbuilder.data.ProjectEntity
import com.askar.apkbuilder.engine.ApkAssembler
import com.askar.apkbuilder.engine.SafeZip
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.util.Locale
import java.util.UUID

/** استيراد المشاريع وتخزين ملفاتها وفحصها وتجهيز الأيقونات. */
class ProjectStore(private val ctx: Context, private val db: AppDb, private val prefs: Prefs) {

    fun dir(id: String) = File(ctx.filesDir, "projects/$id")
    fun www(id: String) = File(dir(id), "www")
    fun iconFile(id: String) = File(dir(id), "icon.png")

    private fun displayName(uri: Uri): String {
        var name: String? = null
        runCatching {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) name = c.getString(0)
            }
        }
        return name ?: uri.lastPathSegment?.substringAfterLast('/') ?: "project"
    }

    /** ينسخ الملف المختار إلى ملف مؤقت (حتى نقدر نفحص نوعه بأمان). */
    private fun copyToTemp(uri: Uri): File {
        val tmp = File(ctx.cacheDir, "import-${System.nanoTime()}")
        ctx.contentResolver.openInputStream(uri)?.use { input ->
            tmp.outputStream().use { out -> input.copyTo(out, 64 * 1024) }
        } ?: throw IOException("تعذّر فتح الملف المختار")
        if (tmp.length() == 0L) { tmp.delete(); throw IOException("الملف المختار فارغ") }
        return tmp
    }

    private fun isZip(f: File): Boolean = FileInputStream(f).use { s ->
        val b = ByteArray(4); s.read(b) == 4 && b[0] == 'P'.code.toByte() && b[1] == 'K'.code.toByte() && b[2].toInt() == 3 && b[3].toInt() == 4
    }

    /** يملأ مجلد www من ملف HTML أو ZIP. يرجع اسم الملف الأصلي. */
    private fun fillWww(uri: Uri, target: File): String {
        val name = displayName(uri)
        val tmp = copyToTemp(uri)
        try {
            SafeZip.deleteRecursive(target)
            if (isZip(tmp)) {
                val unz = File(target.parentFile, "unzip-tmp"); SafeZip.deleteRecursive(unz); unz.mkdirs()
                val r = tmp.inputStream().use { SafeZip.extract(it, unz, null) }
                if (r.files == 0) throw IOException("لا توجد ملفات صالحة داخل ZIP")
                val root = SafeZip.unwrapSingleFolder(unz)
                if (!root.renameTo(target)) throw IOException("تعذّر نقل ملفات المشروع")
                if (root != unz) SafeZip.deleteRecursive(unz)
            } else {
                val lower = name.lowercase(Locale.ROOT)
                if (!(lower.endsWith(".html") || lower.endsWith(".htm"))) {
                    val head = tmp.inputStream().use { s -> ByteArray(512).let { b -> String(b, 0, maxOf(0, s.read(b))) } }.lowercase(Locale.ROOT)
                    if (!head.contains("<html") && !head.contains("<!doctype") && !head.contains("<body") && !head.contains("<script"))
                        throw IOException("الملف ليس HTML ولا ZIP. اختر ملف ‎.html أو ‎.zip")
                }
                target.mkdirs()
                if (!tmp.renameTo(File(target, "index.html"))) tmp.copyTo(File(target, "index.html"), overwrite = true)
            }
        } finally { tmp.delete() }
        return name
    }

    fun htmlFiles(id: String): List<String> =
        SafeZip.listFiles(www(id)).filter { it.lowercase(Locale.ROOT).let { n -> n.endsWith(".html") || n.endsWith(".htm") } }

    private fun pickEntry(files: List<String>): String? =
        files.firstOrNull { it.equals("index.html", true) }
            ?: files.filter { it.substringAfterLast('/').equals("index.html", true) }.minByOrNull { it.length }
            ?: files.firstOrNull()

    private fun randomSuffix(): String = (1..5).map { "abcdefghijklmnopqrstuvwxyz".random() }.joinToString("")

    private fun asciiSlug(s: String): String =
        s.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]"), "").let { if (it.isEmpty() || !it[0].isLetter()) "" else it.take(20) }

    suspend fun import(uri: Uri): ProjectEntity = withContext(Dispatchers.IO) {
        val id = UUID.randomUUID().toString()
        val d = dir(id); d.mkdirs()
        try {
            val src = fillWww(uri, www(id))
            val html = htmlFiles(id)
            val entry = pickEntry(html) ?: throw IOException("لا يوجد أي ملف HTML داخل المشروع")
            val base = src.substringBeforeLast('.').ifBlank { "تطبيقي" }
            val slug = asciiSlug(base).ifEmpty { "app" + randomSuffix() }
            val prefix = prefs.packagePrefix.trim('.').ifBlank { "com.askar" }
            var pkg = "$prefix.$slug"
            if (ApkAssembler.validatePackage(pkg) != null) pkg = "com.askar.app" + randomSuffix()
            val files = SafeZip.listFiles(www(id))
            val p = ProjectEntity(
                id = id, name = base, appName = base.take(30), packageName = pkg, entry = entry,
                sourceName = src, fileCount = files.size, sizeBytes = SafeZip.dirSize(www(id)),
            )
            db.projects().upsert(p)
            p
        } catch (e: Exception) {
            SafeZip.deleteRecursive(d); throw e
        }
    }

    /** يستبدل ملفات مشروع موجود مع الإبقاء على كل إعداداته. */
    suspend fun replaceFiles(p: ProjectEntity, uri: Uri): ProjectEntity = withContext(Dispatchers.IO) {
        val staging = File(dir(p.id), "www-new")
        val src = fillWww(uri, staging)
        val html = SafeZip.listFiles(staging).filter { it.endsWith(".html", true) || it.endsWith(".htm", true) }
        if (html.isEmpty()) { SafeZip.deleteRecursive(staging); throw IOException("لا يوجد أي ملف HTML داخل الملفات الجديدة") }
        SafeZip.deleteRecursive(www(p.id))
        if (!staging.renameTo(www(p.id))) throw IOException("تعذّر استبدال الملفات")
        val entry = if (html.contains(p.entry)) p.entry else pickEntry(html)!!
        val files = SafeZip.listFiles(www(p.id))
        val np = p.copy(entry = entry, sourceName = src, fileCount = files.size, sizeBytes = SafeZip.dirSize(www(p.id)), updatedAt = System.currentTimeMillis())
        db.projects().upsert(np); np
    }

    suspend fun delete(p: ProjectEntity) = withContext(Dispatchers.IO) {
        db.projects().delete(p.id); SafeZip.deleteRecursive(dir(p.id))
    }

    /* ------------------------------------------------ فحص المشروع قبل البناء */
    data class ScanResult(val missing: List<String>, val external: List<String>, val warnings: List<String>)

    private val refRegex = Regex("""(?:src|href|data-src|poster)\s*=\s*["']([^"'#]+)["']|url\(\s*["']?([^"')]+)["']?\s*\)""", RegexOption.IGNORE_CASE)

    fun scan(p: ProjectEntity): ScanResult {
        val root = www(p.id)
        val missing = linkedSetOf<String>(); val external = linkedSetOf<String>(); val warnings = mutableListOf<String>()
        val files = SafeZip.listFiles(root)
        if (!File(root, p.entry).isFile) warnings += "صفحة البداية ${p.entry} غير موجودة"
        for (rel in files) {
            val low = rel.lowercase(Locale.ROOT)
            if (!(low.endsWith(".html") || low.endsWith(".htm") || low.endsWith(".css"))) continue
            val f = File(root, rel)
            if (f.length() > 5_000_000) continue
            val text = runCatching { f.readText() }.getOrNull() ?: continue
            val baseDir = rel.substringBeforeLast('/', "")
            for (m in refRegex.findAll(text)) {
                val raw = (m.groupValues[1].ifEmpty { m.groupValues[2] }).trim()
                if (raw.isEmpty() || raw.contains("{{") || raw.contains("\${")) continue
                val l = raw.lowercase(Locale.ROOT)
                if (l.startsWith("http://") || l.startsWith("https://") || l.startsWith("//")) { external += raw.substringBefore('?').take(120); continue }
                if (l.startsWith("data:") || l.startsWith("mailto:") || l.startsWith("tel:") || l.startsWith("javascript:") || l.startsWith("blob:") || l.contains(":")) continue
                val path = raw.substringBefore('?')
                val resolved = if (path.startsWith("/")) path.trimStart('/') else normalize(if (baseDir.isEmpty()) path else "$baseDir/$path")
                if (resolved == null) { missing += "$raw (في $rel)"; continue }
                val target = File(root, Uri.decode(resolved))
                if (!(target.isFile || (target.isDirectory && File(target, "index.html").isFile))) missing += "$resolved (مطلوب في $rel)"
            }
        }
        if (!p.internet && external.isNotEmpty()) warnings += "المشروع يحمّل ${external.size} ملف/رابط من الإنترنت، لكن صلاحية الإنترنت مغلقة — هذه الأجزاء لن تعمل."
        if (p.sizeBytes > 150L * 1024 * 1024) warnings += "حجم المشروع كبير (${p.sizeBytes / 1048576} MB) — البناء سيأخذ وقتًا أطول."
        return ScanResult(missing.toList(), external.toList(), warnings)
    }

    private fun normalize(path: String): String? {
        val out = ArrayDeque<String>()
        for (part in path.split('/')) when (part) {
            "", "." -> {}
            ".." -> if (out.isEmpty()) return null else out.removeLast()
            else -> out.addLast(part)
        }
        return out.joinToString("/")
    }

    /* ------------------------------------------------ الأيقونة */
    suspend fun saveIcon(p: ProjectEntity, uri: Uri): ProjectEntity = withContext(Dispatchers.IO) {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        if (opts.outWidth <= 0) throw IOException("الصورة غير مدعومة")
        var sample = 1
        while (minOf(opts.outWidth, opts.outHeight) / (sample * 2) >= 512) sample *= 2
        val bmp = ctx.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: throw IOException("تعذّر قراءة الصورة")
        val side = minOf(bmp.width, bmp.height)
        val square = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
        val scaled = Bitmap.createScaledBitmap(square, 512, 512, true)
        iconFile(p.id).outputStream().use { scaled.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val np = p.copy(hasIcon = true, updatedAt = System.currentTimeMillis())
        db.projects().upsert(np); np
    }

    suspend fun clearIcon(p: ProjectEntity): ProjectEntity = withContext(Dispatchers.IO) {
        iconFile(p.id).delete()
        val np = p.copy(hasIcon = false, updatedAt = System.currentTimeMillis()); db.projects().upsert(np); np
    }

    /** أيقونة افتراضية: أول حرف من اسم التطبيق على لون شريط الحالة. */
    fun defaultIcon(p: ProjectEntity, size: Int = 512): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val bg = runCatching { Color.parseColor(p.statusBarColor) }.getOrDefault(Color.parseColor("#1565C0"))
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = bg }
        val r = size * 0.18f
        c.drawRoundRect(RectF(size * 0.04f, size * 0.04f, size * 0.96f, size * 0.96f), r, r, paint)
        val light = (0.299 * Color.red(bg) + 0.587 * Color.green(bg) + 0.114 * Color.blue(bg)) > 170
        paint.color = if (light) Color.parseColor("#202938") else Color.WHITE
        paint.typeface = Typeface.DEFAULT_BOLD
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = size * 0.5f
        val letter = p.appName.trim().take(1).ifEmpty { "A" }
        val y = size / 2f - (paint.descent() + paint.ascent()) / 2f
        c.drawText(letter, size / 2f, y, paint)
        return bmp
    }

    fun iconBitmap(p: ProjectEntity): Bitmap =
        (if (p.hasIcon) BitmapFactory.decodeFile(iconFile(p.id).path) else null) ?: defaultIcon(p)

    fun iconProvider(p: ProjectEntity): ApkAssembler.IconProvider {
        val src = iconBitmap(p)
        return ApkAssembler.IconProvider { px ->
            val s = Bitmap.createScaledBitmap(src, px, px, true)
            ByteArrayOutputStream().also { s.compress(Bitmap.CompressFormat.PNG, 100, it) }.toByteArray()
        }
    }

    /* ------------------------------------------------ ملف الإعدادات داخل التطبيق الناتج */
    fun configJson(p: ProjectEntity): String = JSONObject().apply {
        put("entry", p.entry)
        put("orientation", p.orientation)
        put("statusBarColor", p.statusBarColor)
        put("navBarColor", p.navBarColor)
        put("internet", p.internet)
        put("externalLinks", p.externalLinks)
        put("downloads", p.downloads)
        put("zoom", p.zoom)
        put("builtWith", "Askar APK Builder")
    }.toString()
}
