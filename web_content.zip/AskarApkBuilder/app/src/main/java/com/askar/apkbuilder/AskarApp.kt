package com.askar.apkbuilder

import android.app.Application
import com.askar.apkbuilder.core.BuildManager
import com.askar.apkbuilder.core.KeyManager
import com.askar.apkbuilder.core.Prefs
import com.askar.apkbuilder.core.ProjectStore
import com.askar.apkbuilder.data.AppDb
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class AskarApp : Application() {
    /** نطاق يعيش طوال عمر العملية: البناء لا يتوقف عند تدوير الشاشة أو تغيير الصفحة. */
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    lateinit var db: AppDb; private set
    lateinit var prefs: Prefs; private set
    lateinit var projects: ProjectStore; private set
    lateinit var keys: KeyManager; private set
    lateinit var builder: BuildManager; private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        db = AppDb.create(this)
        prefs = Prefs(this)
        projects = ProjectStore(this, db, prefs)
        keys = KeyManager(this, db)
        builder = BuildManager(this)
        // أي بناء كان "قيد التشغيل" عند إغلاق العملية يُسجَّل كفاشل بدل أن يبقى معلّقًا
        scope.launch {
            db.builds().markInterrupted(System.currentTimeMillis(), "توقف البناء لأن التطبيق أُغلق أثناء العمل. أعد المحاولة.")
        }
    }

    companion object { lateinit var instance: AskarApp; private set }
}
