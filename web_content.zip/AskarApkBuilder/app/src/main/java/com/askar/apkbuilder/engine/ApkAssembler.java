package com.askar.apkbuilder.engine;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/**
 * Builds an UNSIGNED apk from the pre-compiled shell template:
 *   1) patches the binary AndroidManifest.xml (package, label, versions, minSdk, INTERNET),
 *   2) replaces launcher icon PNGs (matched by pixel size, so it works even if paths were shortened),
 *   3) adds the user's web files under assets/www/ and the runtime config assets/askar_config.json.
 * Signing + zip alignment is done afterwards by apksig (see ApkSignerHelper.kt).
 */
public final class ApkAssembler {

    /** Placeholders compiled into the shell template (must match shell/build.gradle.kts + manifest). */
    public static final String PH_APP_ID = "com.askartpl.placeholderappid.aaaaaaaa";
    public static final String PH_LABEL = "ASKARPH_APP_LABEL";
    public static final String PH_VNAME = "ASKARPH_VNAME";

    public static final class Options {
        public String packageName;
        public String appName;
        public String versionName;
        public int versionCode;
        public int minSdk;              // 0 = keep template value
        public boolean internet;
        public String configJson;       // contents of assets/askar_config.json
    }

    public interface IconProvider { byte[] pngForSize(int px) throws IOException; }
    public interface Progress { void step(String message, int percent); boolean isCancelled(); }

    public static final class Report {
        public int iconsReplaced;
        public int webFiles;
        public final List<String> log = new ArrayList<>();
    }

    private static boolean isSignatureFile(String n) {
        if (!n.startsWith("META-INF/")) return false;
        String u = n.toUpperCase(Locale.ROOT);
        return u.equals("META-INF/MANIFEST.MF") || u.endsWith(".SF") || u.endsWith(".RSA") || u.endsWith(".DSA") || u.endsWith(".EC")
                || u.startsWith("META-INF/SIG-");
    }

    /** Validates a Java/Android package name. Returns an Arabic error or null. */
    public static String validatePackage(String p) {
        if (p == null || p.isEmpty()) return "اسم الحزمة مطلوب";
        if (p.length() > 150) return "اسم الحزمة طويل جدًا";
        if (!p.matches("[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z][a-zA-Z0-9_]*)+")) return "اسم الحزمة يجب أن يكون مثل com.askar.myapp (حروف إنجليزية وأرقام ونقاط، جزءان على الأقل، وكل جزء يبدأ بحرف)";
        String[] reserved = {"abstract","assert","boolean","break","byte","case","catch","char","class","const","continue","default","do","double","else","enum","extends","final","finally","float","for","goto","if","implements","import","instanceof","int","interface","long","native","new","package","private","protected","public","return","short","static","strictfp","super","switch","synchronized","this","throw","throws","transient","try","void","volatile","while","true","false","null"};
        for (String part : p.split("\\.")) for (String r : reserved) if (part.equals(r)) return "لا يمكن استخدام الكلمة \"" + r + "\" داخل اسم الحزمة";
        if (p.startsWith("com.askartpl.")) return "هذا الاسم محجوز للقالب الداخلي";
        return null;
    }

    public static int pngWidth(byte[] png) {
        if (png.length < 24 || (png[0] & 0xff) != 0x89 || png[1] != 'P' || png[2] != 'N' || png[3] != 'G') return -1;
        return ((png[16] & 0xff) << 24) | ((png[17] & 0xff) << 16) | ((png[18] & 0xff) << 8) | (png[19] & 0xff);
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] b = new byte[64 * 1024]; int n;
        while ((n = in.read(b)) > 0) o.write(b, 0, n);
        return o.toByteArray();
    }

    private static void putStored(ZipOutputStream z, String name, byte[] data) throws IOException {
        ZipEntry e = new ZipEntry(name);
        e.setMethod(ZipEntry.STORED);
        e.setSize(data.length); e.setCompressedSize(data.length);
        CRC32 c = new CRC32(); c.update(data); e.setCrc(c.getValue());
        e.setTime(0x2100000L); // fixed timestamp: reproducible output
        z.putNextEntry(e); z.write(data); z.closeEntry();
    }

    private static void putDeflated(ZipOutputStream z, String name, byte[] data) throws IOException {
        ZipEntry e = new ZipEntry(name);
        e.setMethod(ZipEntry.DEFLATED);
        e.setTime(0x2100000L);
        z.putNextEntry(e); z.write(data); z.closeEntry();
    }

    /** Files that are already compressed are stored as-is (faster build, same size). */
    private static boolean storeUncompressed(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        return n.endsWith(".png") || n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".webp") || n.endsWith(".gif")
                || n.endsWith(".mp3") || n.endsWith(".mp4") || n.endsWith(".ogg") || n.endsWith(".m4a") || n.endsWith(".webm")
                || n.endsWith(".woff") || n.endsWith(".woff2") || n.endsWith(".zip");
    }

    public static byte[] patchManifest(byte[] manifest, Options o, Report r) {
        Axml x = Axml.parse(manifest);
        int n = x.replaceInStrings(PH_APP_ID, o.packageName);
        if (n == 0) throw new IllegalStateException("القالب لا يحتوي على اسم الحزمة المؤقت — يبدو أن ملف القالب غير صحيح.");
        r.log.add("اسم الحزمة: " + o.packageName + " (" + n + " موضع)");
        if (x.replaceExact(PH_LABEL, o.appName) == 0) throw new IllegalStateException("القالب لا يحتوي على اسم التطبيق المؤقت.");
        r.log.add("اسم التطبيق: " + o.appName);
        if (x.replaceExact(PH_VNAME, o.versionName) == 0) r.log.add("تحذير: لم يُعثر على versionName المؤقت");
        if (x.setIntAttr("manifest", "versionCode", o.versionCode) == 0) throw new IllegalStateException("تعذّر ضبط versionCode في المانيفست.");
        r.log.add("الإصدار: " + o.versionName + " (" + o.versionCode + ")");
        if (o.minSdk > 0) {
            int tplMin = x.getIntAttr("uses-sdk", "minSdkVersion", 21);
            if (o.minSdk < tplMin) throw new IllegalStateException("أقل إصدار أندرويد مدعوم في القالب هو API " + tplMin);
            x.setIntAttr("uses-sdk", "minSdkVersion", o.minSdk);
            r.log.add("أقل إصدار أندرويد: API " + o.minSdk);
        }
        if (!o.internet) {
            int rem = x.removeLeafElements("uses-permission", "name", "android.permission.INTERNET");
            rem += x.removeLeafElements("uses-permission", "name", "android.permission.ACCESS_NETWORK_STATE");
            r.log.add("أُزيلت صلاحية الإنترنت (" + rem + ")");
        } else r.log.add("صلاحية الإنترنت: مفعّلة");
        return x.toBytes();
    }

    public static Report assemble(File template, File webRoot, Options o, IconProvider icons, File outUnsigned, Progress p) throws IOException {
        String err = validatePackage(o.packageName);
        if (err != null) throw new IOException(err);
        if (o.appName == null || o.appName.trim().isEmpty()) throw new IOException("اسم التطبيق مطلوب");
        if (o.versionCode < 1 || o.versionCode > 2100000000) throw new IOException("versionCode يجب أن يكون رقمًا موجبًا");
        Report r = new Report();
        List<String> webFiles = SafeZip.listFiles(webRoot);
        if (webFiles.isEmpty()) throw new IOException("مجلد المشروع فارغ");

        try (ZipFile tpl = new ZipFile(template);
             ZipOutputStream z = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(outUnsigned), 128 * 1024))) {
            z.setLevel(6);
            List<? extends ZipEntry> entries = java.util.Collections.list(tpl.entries());
            int i = 0;
            boolean manifestDone = false;
            for (ZipEntry e : entries) {
                if (p != null && p.isCancelled()) throw new IOException("أُلغيت العملية");
                String name = e.getName();
                i++;
                if (e.isDirectory() || isSignatureFile(name) || name.startsWith("assets/www/") || name.equals("assets/askar_config.json")) continue;
                byte[] data;
                try (InputStream in = tpl.getInputStream(e)) { data = readAll(in); }
                if (name.equals("AndroidManifest.xml")) {
                    if (p != null) p.step("تعديل ملف AndroidManifest.xml", 20);
                    try { data = patchManifest(data, o, r); }
                    catch (RuntimeException ex) { throw new IOException("فشل تعديل المانيفست: " + ex.getMessage(), ex); }
                    manifestDone = true;
                    putDeflated(z, name, data);
                    continue;
                }
                if (icons != null && name.startsWith("res/") && name.toLowerCase(Locale.ROOT).endsWith(".png")) {
                    int w = pngWidth(data);
                    if (w > 0) {
                        byte[] icon = icons.pngForSize(w);
                        if (icon != null) { data = icon; r.iconsReplaced++; }
                    }
                }
                if (name.equals("resources.arsc") || e.getMethod() == ZipEntry.STORED) putStored(z, name, data);
                else putDeflated(z, name, data);
                if (p != null) p.step("نسخ ملفات القالب", 10 + (i * 15 / Math.max(1, entries.size())));
            }
            if (!manifestDone) throw new IOException("القالب لا يحتوي على AndroidManifest.xml");
            r.log.add("استُبدلت أيقونات: " + r.iconsReplaced);

            putDeflated(z, "assets/askar_config.json", o.configJson.getBytes(StandardCharsets.UTF_8));
            int k = 0;
            for (String rel : webFiles) {
                if (p != null && p.isCancelled()) throw new IOException("أُلغيت العملية");
                if (SafeZip.isBlocked(rel)) { r.log.add("تخطّي ملف غير مسموح: " + rel); continue; }
                byte[] d;
                try (InputStream in = new FileInputStream(new File(webRoot, rel))) { d = readAll(in); }
                String entry = "assets/www/" + rel;
                if (storeUncompressed(rel)) putStored(z, entry, d); else putDeflated(z, entry, d);
                r.webFiles++;
                k++;
                if (p != null && (k % 10 == 0 || k == webFiles.size())) p.step("إضافة ملفات الموقع (" + k + "/" + webFiles.size() + ")", 25 + k * 35 / webFiles.size());
            }
            r.log.add("ملفات الويب المضافة: " + r.webFiles);
        }
        return r;
    }

    /** Lists entries of an APK (used by tests and by the result screen). */
    public static List<String> listEntries(File apk) throws IOException {
        List<String> out = new ArrayList<>();
        try (ZipFile z = new ZipFile(apk)) { Enumeration<? extends ZipEntry> e = z.entries(); while (e.hasMoreElements()) out.add(e.nextElement().getName()); }
        return out;
    }

    public static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] b = new byte[64 * 1024]; int n; while ((n = in.read(b)) > 0) out.write(b, 0, n);
    }
}
