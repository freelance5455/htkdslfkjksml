package com.askar.apkbuilder.ui

import android.annotation.SuppressLint
import android.net.Uri
import android.webkit.ConsoleMessage
import android.webkit.MimeTypeMap
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.askar.apkbuilder.Nav
import java.io.File
import java.io.FileInputStream
import java.util.Locale

private const val HOST = "appassets.androidplatform.net"

/** معاينة المشروع بنفس طريقة عرض التطبيق الناتج (نفس الأصل https://appassets…). */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun PreviewScreen(nav: Nav, id: String) {
    val p by app.db.projects().observe(id).collectAsState(initial = null)
    val project = p ?: run { Page("معاينة", nav) { Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() } }; return }
    val root = remember(id) { app.projects.www(id) }
    val missing = remember { mutableStateListOf<String>() }
    val console = remember { mutableStateListOf<String>() }
    var web by remember { mutableStateOf<WebView?>(null) }
    var showIssues by remember { mutableStateOf(false) }

    DisposableEffect(Unit) { onDispose { web?.destroy() } }

    Page("معاينة: ${project.appName}", nav, actions = {
        IconButton(onClick = { missing.clear(); console.clear(); web?.reload() }) { Icon(Icons.Filled.Refresh, "إعادة تحميل") }
    }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            val issues = missing.size + console.size
            Text(
                if (issues == 0) "✔ لا توجد أخطاء حتى الآن" else "⚠ ملفات مفقودة: ${missing.size} • أخطاء JavaScript: ${console.size} — اضغط للتفاصيل",
                color = Color.White,
                modifier = Modifier.fillMaxWidth().background(if (issues == 0) Color(0xFF2E7D32) else Color(0xFFEF6C00))
                    .clickable { showIssues = !showIssues }.padding(8.dp),
            )
            if (showIssues && issues > 0) LazyColumn(Modifier.fillMaxWidth().heightIn(max = 220.dp).background(MaterialTheme.colorScheme.surfaceVariant)) {
                items(missing) { Ltr { Text("404  $it", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(6.dp)) } }
                items(console) { Ltr { Text(it, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(6.dp)) } }
            }
            Ltr {
                AndroidView(modifier = Modifier.fillMaxSize(), factory = { ctx ->
                    WebView(ctx).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.allowFileAccess = false
                        settings.mediaPlaybackRequiresUserGesture = false
                        settings.setSupportZoom(project.zoom); settings.builtInZoomControls = project.zoom; settings.displayZoomControls = false
                        settings.blockNetworkLoads = !project.internet
                        webViewClient = object : WebViewClient() {
                            override fun shouldInterceptRequest(view: WebView, req: WebResourceRequest): WebResourceResponse? {
                                val u = req.url
                                if (u.host != HOST) return null
                                return serve(root, u, project.entry) { miss -> view.post { if (!missing.contains(miss)) missing.add(miss) } }
                            }
                            override fun shouldOverrideUrlLoading(view: WebView, req: WebResourceRequest): Boolean {
                                if (req.url.host == HOST || !req.isForMainFrame) return false
                                Toast.makeText(ctx, "رابط خارجي (${project.externalLinks}): ${req.url}", Toast.LENGTH_SHORT).show()
                                return project.externalLinks != "inside"
                            }
                        }
                        webChromeClient = object : WebChromeClient() {
                            override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                                if (m.messageLevel() == ConsoleMessage.MessageLevel.ERROR)
                                    console.add("JS: ${m.message()} (${m.sourceId()?.substringAfterLast('/')}:${m.lineNumber()})")
                                return true
                            }
                        }
                        loadUrl("https://$HOST/${project.entry}")
                        web = this
                    }
                })
            }
        }
    }
}

private fun serve(root: File, u: Uri, entry: String, onMissing: (String) -> Unit): WebResourceResponse {
    var path = Uri.decode(u.path ?: "/").trimStart('/')
    if (path.isEmpty()) path = entry
    if (path.endsWith("/")) path += "index.html"
    val f = File(root, path)
    val ok = !path.contains("..") && f.canonicalPath.startsWith(root.canonicalPath + File.separator) && f.isFile
    if (!ok) {
        onMissing(path)
        return WebResourceResponse("text/plain", "UTF-8", "404".byteInputStream()).apply { setStatusCodeAndReasonPhrase(404, "Not Found") }
    }
    val ext = f.extension.lowercase(Locale.ROOT)
    val mime = when (ext) {
        "js", "mjs" -> "text/javascript"; "css" -> "text/css"; "html", "htm" -> "text/html"; "json" -> "application/json"
        "svg" -> "image/svg+xml"; "wasm" -> "application/wasm"; "woff2" -> "font/woff2"
        else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }
    return WebResourceResponse(mime, if (mime.startsWith("text") || mime.contains("json")) "UTF-8" else null, FileInputStream(f))
}
