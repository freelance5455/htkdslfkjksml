package com.askar.apkbuilder.core

import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.IOException

/** حفظ / تثبيت / مشاركة الـ APK بالطرق الرسمية فقط. */
object OutputActions {
    const val APK_MIME = "application/vnd.android.package-archive"

    fun uriFor(ctx: Context, f: File): Uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)

    /** أندرويد 10+: يحفظ في Download/AskarAPK بدون أي صلاحيات. يرجع مسارًا مقروءًا. */
    fun saveToDownloads(ctx: Context, f: File, name: String): String {
        if (Build.VERSION.SDK_INT < 29) throw IOException("على أندرويد 9 وأقدم استخدم زر \"حفظ في مكان آخر\"")
        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, APK_MIME)
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/AskarAPK")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val cr = ctx.contentResolver
        val uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: throw IOException("تعذّر إنشاء الملف في التنزيلات")
        try {
            cr.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } } ?: throw IOException("تعذّر الكتابة")
            cr.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
        } catch (e: Exception) { cr.delete(uri, null, null); throw e }
        return "Download/AskarAPK/$name"
    }

    fun saveTo(ctx: Context, f: File, dest: Uri) {
        ctx.contentResolver.openOutputStream(dest)?.use { o -> f.inputStream().use { it.copyTo(o) } } ?: throw IOException("تعذّر الكتابة")
    }

    /** يرجع false إذا احتاج المستخدم أولًا لتفعيل "تثبيت تطبيقات غير معروفة" (ونفتح له الإعداد). */
    fun install(ctx: Context, f: File): Boolean {
        if (!ctx.packageManager.canRequestPackageInstalls()) {
            Toast.makeText(ctx, "فعّل \"السماح من هذا المصدر\" ثم ارجع واضغط تثبيت مرة أخرى", Toast.LENGTH_LONG).show()
            ctx.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return false
        }
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uriFor(ctx, f), APK_MIME)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return true
    }

    fun share(ctx: Context, f: File) {
        val i = Intent(Intent.ACTION_SEND).setType(APK_MIME)
            .putExtra(Intent.EXTRA_STREAM, uriFor(ctx, f))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, "مشاركة التطبيق").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun openDownloads(ctx: Context) {
        try { ctx.startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: ActivityNotFoundException) { Toast.makeText(ctx, "افتح تطبيق الملفات ← Download ← AskarAPK", Toast.LENGTH_LONG).show() }
    }
}
