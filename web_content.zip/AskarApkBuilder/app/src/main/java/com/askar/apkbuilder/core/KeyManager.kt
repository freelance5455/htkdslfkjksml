package com.askar.apkbuilder.core

import android.content.Context
import android.net.Uri
import com.askar.apkbuilder.data.AppDb
import com.askar.apkbuilder.data.KeyEntity
import com.askar.apkbuilder.engine.CertUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.io.File
import java.io.IOException
import java.util.UUID

/**
 * مفاتيح التوقيع. كل مفتاح محفوظ كملف PKCS12 مشفّر بكلمة مرور المستخدم داخل مساحة التطبيق الخاصة.
 * كلمة المرور لا تُحفظ أبدًا؛ تُطلب عند البناء أو التصدير.
 */
class KeyManager(private val ctx: Context, private val db: AppDb) {
    private val dir get() = File(ctx.filesDir, "keys").apply { mkdirs() }
    fun file(id: String) = File(dir, "$id.p12")

    private fun entity(id: String, name: String, k: CertUtil.SigningKey, imported: Boolean) = KeyEntity(
        id = id, name = name,
        subject = k.cert.subjectX500Principal.name,
        fingerprint = CertUtil.sha256Fingerprint(k.cert),
        validUntil = k.cert.notAfter.time,
        createdAt = System.currentTimeMillis(), imported = imported,
    )

    fun checkPassword(pw: CharArray): String? = when {
        pw.size < 8 -> "كلمة المرور يجب ألا تقل عن 8 أحرف"
        else -> null
    }

    suspend fun generate(name: String, org: String, password: CharArray): KeyEntity = withContext(Dispatchers.Default) {
        checkPassword(password)?.let { throw IOException(it) }
        val k = CertUtil.generate(name.ifBlank { "Askar Developer" }, org, null, 30)
        val id = UUID.randomUUID().toString()
        CertUtil.savePkcs12(k, "key0", password, file(id))
        val e = entity(id, name.ifBlank { "مفتاحي" }, k, false)
        db.keys().upsert(e); e
    }

    suspend fun import(uri: Uri, password: CharArray, name: String): KeyEntity = withContext(Dispatchers.IO) {
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IOException("تعذّر فتح الملف")
        if (bytes.size >= 4 && (bytes[0].toInt() and 0xff) == 0xFE && (bytes[1].toInt() and 0xff) == 0xED && (bytes[2].toInt() and 0xff) == 0xFE && (bytes[3].toInt() and 0xff) == 0xED)
            throw IOException("هذا ملف JKS وأندرويد لا يدعم قراءته. حوّله إلى p12 على الكمبيوتر بالأمر:\nkeytool -importkeystore -srckeystore my.jks -destkeystore my.p12 -deststoretype PKCS12")
        val k = CertUtil.loadPkcs12(ByteArrayInputStream(bytes), password)
        val id = UUID.randomUUID().toString()
        CertUtil.savePkcs12(k, "key0", password, file(id))
        val e = entity(id, name.ifBlank { "مفتاح مستورد" }, k, true)
        db.keys().upsert(e); e
    }

    suspend fun load(id: String, password: CharArray): CertUtil.SigningKey = withContext(Dispatchers.IO) {
        val f = file(id)
        if (!f.isFile) throw IOException("ملف المفتاح غير موجود")
        CertUtil.loadPkcs12(f, password)
    }

    /** نسخة احتياطية: الملف نفسه (مشفّر بكلمة المرور)، بعد التأكد أن كلمة المرور صحيحة. */
    suspend fun export(id: String, password: CharArray, dest: Uri) = withContext(Dispatchers.IO) {
        load(id, password)
        ctx.contentResolver.openOutputStream(dest)?.use { o -> file(id).inputStream().use { it.copyTo(o) } }
            ?: throw IOException("تعذّر الكتابة في المكان المختار")
    }

    suspend fun delete(id: String) = withContext(Dispatchers.IO) { file(id).delete(); db.keys().delete(id) }
}
