package com.askar.apkbuilder.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val appName: String,
    val packageName: String,
    val versionName: String = "1.0",
    val versionCode: Int = 1,
    val entry: String = "index.html",
    val hasIcon: Boolean = false,
    val statusBarColor: String = "#1565C0",
    val navBarColor: String = "#000000",
    val orientation: String = "unspecified",   // unspecified | portrait | landscape | sensor
    val minSdk: Int = 21,
    val internet: Boolean = true,
    val externalLinks: String = "browser",     // browser | inside | block
    val downloads: Boolean = true,
    val zoom: Boolean = false,
    val sourceName: String = "",
    val fileCount: Int = 0,
    val sizeBytes: Long = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "builds")
data class BuildEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: String,
    val appName: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Int,
    val status: String,             // running | success | failed | cancelled
    val startedAt: Long,
    val finishedAt: Long = 0,
    val apkPath: String? = null,
    val apkSize: Long = 0,
    val keyName: String = "",
    val certSha256: String = "",
    val message: String = "",
    val log: String = "",
)

@Entity(tableName = "keys")
data class KeyEntity(
    @PrimaryKey val id: String,
    val name: String,
    val subject: String,
    val fingerprint: String,
    val validUntil: Long,
    val createdAt: Long,
    val imported: Boolean,
)

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY updatedAt DESC") fun all(): Flow<List<ProjectEntity>>
    @Query("SELECT * FROM projects WHERE id = :id") fun observe(id: String): Flow<ProjectEntity?>
    @Query("SELECT * FROM projects WHERE id = :id") suspend fun get(id: String): ProjectEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(p: ProjectEntity)
    @Query("DELETE FROM projects WHERE id = :id") suspend fun delete(id: String)
}

@Dao
interface BuildDao {
    @Query("SELECT * FROM builds ORDER BY startedAt DESC") fun all(): Flow<List<BuildEntity>>
    @Query("SELECT * FROM builds WHERE id = :id") fun observe(id: Long): Flow<BuildEntity?>
    @Query("SELECT * FROM builds WHERE id = :id") suspend fun get(id: Long): BuildEntity?
    @Insert suspend fun insert(b: BuildEntity): Long
    @Update suspend fun update(b: BuildEntity)
    @Query("DELETE FROM builds WHERE id = :id") suspend fun delete(id: Long)
    @Query("SELECT * FROM builds WHERE status = 'success' AND apkPath IS NOT NULL ORDER BY startedAt DESC") suspend fun successful(): List<BuildEntity>
    @Query("UPDATE builds SET status = 'failed', finishedAt = :now, message = :msg WHERE status = 'running'")
    suspend fun markInterrupted(now: Long, msg: String)
}

@Dao
interface KeyDao {
    @Query("SELECT * FROM keys ORDER BY createdAt DESC") fun all(): Flow<List<KeyEntity>>
    @Query("SELECT * FROM keys WHERE id = :id") suspend fun get(id: String): KeyEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(k: KeyEntity)
    @Query("DELETE FROM keys WHERE id = :id") suspend fun delete(id: String)
}

@Database(entities = [ProjectEntity::class, BuildEntity::class, KeyEntity::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun projects(): ProjectDao
    abstract fun builds(): BuildDao
    abstract fun keys(): KeyDao

    companion object {
        fun create(ctx: Context): AppDb =
            Room.databaseBuilder(ctx, AppDb::class.java, "askar_builder.db").build()
    }
}
