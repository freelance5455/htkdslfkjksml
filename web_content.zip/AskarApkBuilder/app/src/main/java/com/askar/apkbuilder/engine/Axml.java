package com.askar.apkbuilder.engine;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Reader/writer for Android binary XML (the compiled AndroidManifest.xml inside an APK).
 * Supports the operations the builder needs:
 *  - replacing string-pool contents (package name, app label, version name),
 *  - setting integer attributes (versionCode, minSdkVersion),
 *  - removing simple elements (e.g. a uses-permission entry).
 * String indices never change, so the resource map and all references stay valid.
 */
public final class Axml {
    public static final int RES_XML_TYPE = 0x0003;
    public static final int RES_STRING_POOL_TYPE = 0x0001;
    public static final int RES_XML_START_ELEMENT_TYPE = 0x0102;
    public static final int RES_XML_END_ELEMENT_TYPE = 0x0103;
    public static final int TYPE_STRING = 0x03;
    public static final int TYPE_INT_DEC = 0x10;
    private static final int UTF8_FLAG = 1 << 8;

    /** One raw chunk after the string pool (resource map, namespace, element, cdata...). */
    public static final class Chunk {
        public final int type;
        public byte[] data; // full chunk bytes including header
        Chunk(int type, byte[] data) { this.type = type; this.data = data; }
    }

    public final List<String> strings = new ArrayList<>();
    private int poolFlags;
    private byte[] styleBlock = new byte[0];      // style offsets + style data, kept verbatim
    private int styleCount;
    public final List<Chunk> chunks = new ArrayList<>();

    public static Axml parse(byte[] file) {
        ByteBuffer b = ByteBuffer.wrap(file).order(ByteOrder.LITTLE_ENDIAN);
        if ((b.getShort(0) & 0xffff) != RES_XML_TYPE) throw new IllegalArgumentException("ليس ملف XML ثنائي لأندرويد");
        int headerSize = b.getShort(2) & 0xffff;
        int total = b.getInt(4);
        if (total > file.length) throw new IllegalArgumentException("ملف المانيفست تالف");
        Axml x = new Axml();
        int pos = headerSize;
        boolean poolSeen = false;
        while (pos + 8 <= total) {
            int type = b.getShort(pos) & 0xffff;
            int size = b.getInt(pos + 4);
            if (size < 8 || pos + size > total) throw new IllegalArgumentException("مقطع تالف في المانيفست");
            if (type == RES_STRING_POOL_TYPE && !poolSeen) { x.readPool(b, pos); poolSeen = true; }
            else { byte[] c = new byte[size]; System.arraycopy(file, pos, c, 0, size); x.chunks.add(new Chunk(type, c)); }
            pos += size;
        }
        if (!poolSeen) throw new IllegalArgumentException("لا يوجد String Pool في المانيفست");
        return x;
    }

    private void readPool(ByteBuffer b, int start) {
        int hs = b.getShort(start + 2) & 0xffff;
        int size = b.getInt(start + 4);
        int count = b.getInt(start + 8);
        styleCount = b.getInt(start + 12);
        poolFlags = b.getInt(start + 16);
        int stringsStart = b.getInt(start + 20);
        int stylesStart = b.getInt(start + 24);
        boolean utf8 = (poolFlags & UTF8_FLAG) != 0;
        int offBase = start + hs;
        for (int i = 0; i < count; i++) {
            int off = b.getInt(offBase + i * 4);
            int p = start + stringsStart + off;
            strings.add(utf8 ? readUtf8(b, p) : readUtf16(b, p));
        }
        // keep style offsets + style data verbatim (manifests normally have none)
        if (styleCount > 0) {
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            byte[] all = b.array();
            o.write(all, offBase + count * 4, styleCount * 4);
            o.write(all, start + stylesStart, size - stylesStart);
            styleBlock = o.toByteArray();
        }
    }

    private static int[] lenUtf8(ByteBuffer b, int p) {
        int v = b.get(p) & 0xff;
        if ((v & 0x80) != 0) return new int[]{((v & 0x7f) << 8) | (b.get(p + 1) & 0xff), 2};
        return new int[]{v, 1};
    }

    private static String readUtf8(ByteBuffer b, int p) {
        int[] u16 = lenUtf8(b, p); p += u16[1];
        int[] u8 = lenUtf8(b, p); p += u8[1];
        return new String(b.array(), p, u8[0], StandardCharsets.UTF_8);
    }

    private static String readUtf16(ByteBuffer b, int p) {
        int len = b.getShort(p) & 0xffff; p += 2;
        if ((len & 0x8000) != 0) { len = ((len & 0x7fff) << 16) | (b.getShort(p) & 0xffff); p += 2; }
        char[] c = new char[len];
        for (int i = 0; i < len; i++) c[i] = (char) (b.getShort(p + i * 2) & 0xffff);
        return new String(c);
    }

    private static void putLenUtf8(ByteArrayOutputStream o, int len) {
        if (len > 0x7fff) throw new IllegalArgumentException("نص طويل جدًا");
        if (len > 0x7f) { o.write(((len >> 8) & 0x7f) | 0x80); o.write(len & 0xff); } else o.write(len);
    }

    private byte[] writePool() {
        boolean utf8 = (poolFlags & UTF8_FLAG) != 0;
        ByteArrayOutputStream data = new ByteArrayOutputStream();
        int[] offsets = new int[strings.size()];
        for (int i = 0; i < strings.size(); i++) {
            offsets[i] = data.size();
            String s = strings.get(i);
            if (utf8) {
                byte[] bytes = s.getBytes(StandardCharsets.UTF_8);
                putLenUtf8(data, s.length());          // length in UTF-16 code units
                putLenUtf8(data, bytes.length);        // length in bytes
                data.write(bytes, 0, bytes.length);
                data.write(0);
            } else {
                int len = s.length();
                if (len > 0x7fff) { int hi = ((len >> 16) & 0x7fff) | 0x8000; data.write(hi & 0xff); data.write(hi >> 8); }
                data.write(len & 0xff); data.write((len >> 8) & 0xff);
                for (int k = 0; k < len; k++) { char ch = s.charAt(k); data.write(ch & 0xff); data.write(ch >> 8); }
                data.write(0); data.write(0);
            }
        }
        while (data.size() % 4 != 0) data.write(0);
        int headerSize = 28;
        int styleOffsetsLen = styleCount * 4;
        int stringsStart = headerSize + strings.size() * 4 + styleOffsetsLen;
        byte[] styleData = styleCount > 0 ? java.util.Arrays.copyOfRange(styleBlock, styleOffsetsLen, styleBlock.length) : new byte[0];
        int stylesStart = styleCount > 0 ? stringsStart + data.size() : 0;
        int size = stringsStart + data.size() + styleData.length;
        ByteBuffer o = ByteBuffer.allocate(size).order(ByteOrder.LITTLE_ENDIAN);
        o.putShort((short) RES_STRING_POOL_TYPE).putShort((short) headerSize).putInt(size)
         .putInt(strings.size()).putInt(styleCount).putInt(poolFlags & ~1 /* not sorted any more */)
         .putInt(stringsStart).putInt(stylesStart);
        for (int off : offsets) o.putInt(off);
        if (styleCount > 0) o.put(styleBlock, 0, styleOffsetsLen);
        o.put(data.toByteArray());
        o.put(styleData);
        return o.array();
    }

    public byte[] toBytes() {
        byte[] pool = writePool();
        int total = 8 + pool.length;
        for (Chunk c : chunks) total += c.data.length;
        ByteBuffer o = ByteBuffer.allocate(total).order(ByteOrder.LITTLE_ENDIAN);
        o.putShort((short) RES_XML_TYPE).putShort((short) 8).putInt(total);
        o.put(pool);
        for (Chunk c : chunks) o.put(c.data);
        return o.array();
    }

    /* ------------------------------------------------------------------ helpers */
    private static ByteBuffer bb(byte[] d) { return ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN); }

    public String str(int idx) { return idx >= 0 && idx < strings.size() ? strings.get(idx) : null; }

    /** Name of a start/end element chunk. */
    public String elementName(Chunk c) { return str(bb(c.data).getInt(16 + 4)); }

    public int attrCount(Chunk c) { return bb(c.data).getShort(16 + 12) & 0xffff; }

    private int attrOffset(Chunk c, int i) {
        ByteBuffer b = bb(c.data);
        int attrStart = b.getShort(16 + 8) & 0xffff, attrSize = b.getShort(16 + 10) & 0xffff;
        return 16 + attrStart + i * attrSize;
    }

    public String attrName(Chunk c, int i) { return str(bb(c.data).getInt(attrOffset(c, i) + 4)); }

    public int attrType(Chunk c, int i) { return bb(c.data).get(attrOffset(c, i) + 15) & 0xff; }

    public int attrData(Chunk c, int i) { return bb(c.data).getInt(attrOffset(c, i) + 16); }

    /** String value of an attribute (raw value or string-typed data), or null. */
    public String attrString(Chunk c, int i) {
        ByteBuffer b = bb(c.data);
        int raw = b.getInt(attrOffset(c, i) + 8);
        if (raw != -1) return str(raw);
        if (attrType(c, i) == TYPE_STRING) return str(attrData(c, i));
        return null;
    }

    public int findAttr(Chunk c, String name) {
        for (int i = 0; i < attrCount(c); i++) if (name.equals(attrName(c, i))) return i;
        return -1;
    }

    public List<Chunk> elements(String name) {
        List<Chunk> out = new ArrayList<>();
        for (Chunk c : chunks) if (c.type == RES_XML_START_ELEMENT_TYPE && name.equals(elementName(c))) out.add(c);
        return out;
    }

    /* ------------------------------------------------------------------ operations */
    /** Replace every occurrence of {@code from} inside pool strings. Returns number of strings changed. */
    public int replaceInStrings(String from, String to) {
        int n = 0;
        for (int i = 0; i < strings.size(); i++) {
            String s = strings.get(i);
            if (s.contains(from)) { strings.set(i, s.replace(from, to)); n++; }
        }
        return n;
    }

    /** Replace strings that are exactly equal to {@code from}. */
    public int replaceExact(String from, String to) {
        int n = 0;
        for (int i = 0; i < strings.size(); i++) if (strings.get(i).equals(from)) { strings.set(i, to); n++; }
        return n;
    }

    /** Set an integer attribute on every element named {@code element}. Returns number of attributes changed. */
    public int setIntAttr(String element, String attr, int value) {
        int n = 0;
        for (Chunk c : elements(element)) {
            int i = findAttr(c, attr);
            if (i < 0) continue;
            ByteBuffer b = bb(c.data);
            int off = attrOffset(c, i);
            b.putInt(off + 8, -1);                 // no raw string value
            b.putShort(off + 12, (short) 8);       // Res_value.size
            b.put(off + 14, (byte) 0);
            b.put(off + 15, (byte) TYPE_INT_DEC);
            b.putInt(off + 16, value);
            n++;
        }
        return n;
    }

    /** Read an integer attribute (first matching element), or {@code def}. */
    public int getIntAttr(String element, String attr, int def) {
        for (Chunk c : elements(element)) { int i = findAttr(c, attr); if (i >= 0 && attrType(c, i) >= 0x10 && attrType(c, i) <= 0x1f) return attrData(c, i); }
        return def;
    }

    /** Read a string attribute (first matching element), or null. */
    public String getStringAttr(String element, String attr) {
        for (Chunk c : elements(element)) { int i = findAttr(c, attr); if (i >= 0) return attrString(c, i); }
        return null;
    }

    /**
     * Remove elements named {@code element} whose attribute {@code attr} equals {@code value}
     * (only leaf elements: start chunk immediately followed by its end chunk). Returns count removed.
     */
    public int removeLeafElements(String element, String attr, String value) {
        int removed = 0;
        for (int k = 0; k < chunks.size() - 1; k++) {
            Chunk c = chunks.get(k);
            if (c.type != RES_XML_START_ELEMENT_TYPE || !element.equals(elementName(c))) continue;
            int i = findAttr(c, attr);
            if (i < 0 || !value.equals(attrString(c, i))) continue;
            Chunk end = chunks.get(k + 1);
            if (end.type != RES_XML_END_ELEMENT_TYPE || !element.equals(elementName(end))) continue;
            chunks.remove(k + 1); chunks.remove(k); k--; removed++;
        }
        return removed;
    }
}
