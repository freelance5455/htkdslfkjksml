package com.askar.apkbuilder.engine;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.Key;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Creates a signing key + self-signed X.509 certificate (no BouncyCastle needed),
 * and stores/loads it as a password-protected PKCS#12 file.
 */
public final class CertUtil {

    public static final class SigningKey {
        public final PrivateKey key;
        public final X509Certificate cert;
        public SigningKey(PrivateKey key, X509Certificate cert) { this.key = key; this.cert = cert; }
    }

    /* ---------------- minimal DER encoder ---------------- */
    private static byte[] tlv(int tag, byte[] v) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(tag);
        int n = v.length;
        if (n < 0x80) o.write(n);
        else if (n < 0x100) { o.write(0x81); o.write(n); }
        else if (n < 0x10000) { o.write(0x82); o.write(n >> 8); o.write(n & 0xff); }
        else { o.write(0x83); o.write(n >> 16); o.write((n >> 8) & 0xff); o.write(n & 0xff); }
        o.write(v, 0, v.length);
        return o.toByteArray();
    }
    private static byte[] cat(byte[]... parts) { ByteArrayOutputStream o = new ByteArrayOutputStream(); for (byte[] p : parts) o.write(p, 0, p.length); return o.toByteArray(); }
    private static byte[] seq(byte[]... p) { return tlv(0x30, cat(p)); }
    private static byte[] set(byte[]... p) { return tlv(0x31, cat(p)); }
    private static byte[] integer(BigInteger v) { return tlv(0x02, v.toByteArray()); }
    private static byte[] oid(String dotted) {
        String[] p = dotted.split("\\.");
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(Integer.parseInt(p[0]) * 40 + Integer.parseInt(p[1]));
        for (int i = 2; i < p.length; i++) {
            long v = Long.parseLong(p[i]);
            byte[] tmp = new byte[10]; int k = 0;
            do { tmp[k++] = (byte) (v & 0x7f); v >>= 7; } while (v > 0);
            for (int j = k - 1; j >= 0; j--) o.write(tmp[j] | (j > 0 ? 0x80 : 0));
        }
        return tlv(0x06, o.toByteArray());
    }
    private static byte[] time(Date d) {
        SimpleDateFormat f = new SimpleDateFormat(d.getTime() < 2524608000000L ? "yyMMddHHmmss'Z'" : "yyyyMMddHHmmss'Z'", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        byte[] s = f.format(d).getBytes(StandardCharsets.US_ASCII);
        return tlv(d.getTime() < 2524608000000L ? 0x17 : 0x18, s);  // UTCTime before 2050, else GeneralizedTime
    }
    private static byte[] name(String cn, String org, String country) {
        byte[] r = new byte[0];
        if (country != null && country.matches("[A-Z]{2}")) r = cat(r, set(seq(oid("2.5.4.6"), tlv(0x13, country.getBytes(StandardCharsets.US_ASCII)))));
        if (org != null && !org.isEmpty()) r = cat(r, set(seq(oid("2.5.4.10"), tlv(0x0c, org.getBytes(StandardCharsets.UTF_8)))));
        r = cat(r, set(seq(oid("2.5.4.3"), tlv(0x0c, cn.getBytes(StandardCharsets.UTF_8)))));
        return tlv(0x30, r);
    }

    /** Generates an RSA-2048 key and a self-signed certificate valid for {@code years}. */
    public static SigningKey generate(String commonName, String org, String country, int years) throws GeneralSecurityException {
        KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
        g.initialize(2048, new SecureRandom());
        KeyPair kp = g.generateKeyPair();
        byte[] algo = seq(oid("1.2.840.113549.1.1.11"), new byte[]{0x05, 0x00}); // sha256WithRSAEncryption, NULL
        byte[] serialBytes = new byte[16]; new SecureRandom().nextBytes(serialBytes); serialBytes[0] &= 0x7f; if (serialBytes[0] == 0) serialBytes[0] = 1;
        Date from = new Date(System.currentTimeMillis() - 24L * 3600 * 1000);
        Date to = new Date(from.getTime() + years * 365L * 24 * 3600 * 1000);
        byte[] subject = name(commonName, org, country);
        byte[] tbs = seq(
                tlv(0xa0, integer(BigInteger.valueOf(2))),
                integer(new BigInteger(1, serialBytes)),
                algo, subject, seq(time(from), time(to)), subject,
                kp.getPublic().getEncoded());
        Signature s = Signature.getInstance("SHA256withRSA");
        s.initSign(kp.getPrivate());
        s.update(tbs);
        byte[] sig = s.sign();
        byte[] certDer = seq(tbs, algo, tlv(0x03, cat(new byte[]{0}, sig)));
        X509Certificate cert = (X509Certificate) CertificateFactory.getInstance("X.509").generateCertificate(new ByteArrayInputStream(certDer));
        cert.verify(kp.getPublic());
        return new SigningKey(kp.getPrivate(), cert);
    }

    public static void savePkcs12(SigningKey k, String alias, char[] password, File file) throws GeneralSecurityException, IOException {
        KeyStore ks = KeyStore.getInstance("PKCS12");
        ks.load(null, null);
        ks.setKeyEntry(alias, k.key, password, new Certificate[]{k.cert});
        File tmp = new File(file.getPath() + ".tmp");
        try (FileOutputStream o = new FileOutputStream(tmp)) { ks.store(o, password); }
        if (file.exists() && !file.delete()) throw new IOException("تعذّر استبدال ملف المفتاح");
        if (!tmp.renameTo(file)) throw new IOException("تعذّر حفظ ملف المفتاح");
    }

    /** Loads the first private-key entry of a PKCS#12 file. Throws a clear Arabic message on a wrong password. */
    public static SigningKey loadPkcs12(InputStream in, char[] password) throws IOException {
        try {
            KeyStore ks = KeyStore.getInstance("PKCS12");
            ks.load(in, password);
            Enumeration<String> e = ks.aliases();
            while (e.hasMoreElements()) {
                String a = e.nextElement();
                if (!ks.isKeyEntry(a)) continue;
                Key key = ks.getKey(a, password);
                Certificate c = ks.getCertificate(a);
                if (key instanceof PrivateKey && c instanceof X509Certificate) return new SigningKey((PrivateKey) key, (X509Certificate) c);
            }
            throw new IOException("لم يُعثر على مفتاح توقيع داخل الملف.");
        } catch (IOException ex) {
            if (ex.getMessage() != null && ex.getMessage().startsWith("لم")) throw ex;
            throw new IOException("كلمة المرور غير صحيحة أو أن الملف ليس PKCS12 صالحًا (.p12 / .pfx).");
        } catch (GeneralSecurityException ex) {
            throw new IOException("تعذّر قراءة المفتاح: " + ex.getMessage());
        }
    }

    public static SigningKey loadPkcs12(File f, char[] password) throws IOException {
        try (FileInputStream in = new FileInputStream(f)) { return loadPkcs12(in, password); }
    }

    public static String sha256Fingerprint(X509Certificate c) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-256").digest(c.getEncoded());
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < d.length; i++) { if (i > 0) sb.append(':'); sb.append(String.format(Locale.US, "%02X", d[i])); }
            return sb.toString();
        } catch (Exception e) { return "?"; }
    }
}
