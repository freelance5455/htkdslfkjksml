package com.askar.apkbuilder.core

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    private val _theme = MutableStateFlow(sp.getString("theme", "system") ?: "system")
    val theme: StateFlow<String> = _theme
    fun setTheme(v: String) { sp.edit().putString("theme", v).apply(); _theme.value = v }

    var packagePrefix: String
        get() = sp.getString("pkgPrefix", "com.askar") ?: "com.askar"
        set(v) { sp.edit().putString("pkgPrefix", v).apply() }

    var keepBuilds: Int
        get() = sp.getInt("keepBuilds", 10)
        set(v) { sp.edit().putInt("keepBuilds", v.coerceIn(1, 100)).apply() }

    var defaultKeyId: String?
        get() = sp.getString("defaultKey", null)
        set(v) { sp.edit().putString("defaultKey", v).apply() }
}
