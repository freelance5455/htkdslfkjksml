package com.askar.apkbuilder.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.askar.apkbuilder.Nav
import com.askar.apkbuilder.data.KeyEntity
import com.askar.apkbuilder.engine.SafeZip
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/* ======================================================= مفاتيح التوقيع */
@Composable
fun KeysScreen(nav: Nav) {
    val keys by app.db.keys().all().collectAsState(initial = null)
    val scope = rememberCoroutineScope()
    var error by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var showGen by remember { mutableStateOf(false) }
    var importUri by remember { mutableStateOf<Uri?>(null) }
    var exportKey by remember { mutableStateOf<KeyEntity?>(null) }
    var exportPw by remember { mutableStateOf<CharArray?>(null) }
    var askExportPw by remember { mutableStateOf<KeyEntity?>(null) }
    var deleteKey by remember { mutableStateOf<KeyEntity?>(null) }

    val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { if (it != null) importUri = it }
    val exportPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/x-pkcs12")) { uri ->
        val k = exportKey; val pw = exportPw
        if (uri != null && k != null && pw != null) scope.launch {
            try { app.keys.export(k.id, pw, uri); info = "تم حفظ النسخة الاحتياطية. احتفظ بها مع كلمة المرور في مكان آمن خارج الهاتف." }
            catch (e: Exception) { error = e.message }
            finally { pw.fill('\u0000') }
        } else pw?.fill('\u0000')
        exportKey = null; exportPw = null
    }

    Page("مفاتيح التوقيع", nav) { pad ->
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(pad).padding(bottom = 24.dp)) {
            Section("لماذا المفتاح مهم؟") {
                Text("أندرويد يقبل تحديث التطبيق فقط إذا كان موقّعًا بنفس المفتاح. لو ضاع المفتاح أو كلمة مروره لن تستطيع تحديث تطبيقاتك المثبتة — فقط تثبيتها كتطبيق جديد بعد حذف القديم.",
                    style = MaterialTheme.typography.bodyMedium)
                Text("المفاتيح محفوظة داخل التطبيق كملفات PKCS12 مشفّرة بكلمة مرورك، وكلمة المرور لا تُحفظ أبدًا. حذف التطبيق أو مسح بياناته يحذف المفاتيح، لذلك صدّر نسخة احتياطية.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = !busy, onClick = { showGen = true }) { Text("إنشاء مفتاح جديد") }
                OutlinedButton(enabled = !busy, onClick = { importPicker.launch(arrayOf("application/x-pkcs12", "application/octet-stream", "*/*")) }) { Text("استيراد ‎.p12 / .pfx") }
            }
            if (busy) Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(); Text("  جارٍ العمل… (توليد RSA-2048 قد يأخذ ثواني)") }
            info?.let { Text("✔ $it", color = Color(0xFF2E7D32), modifier = Modifier.padding(12.dp)) }
            val l = keys
            if (l != null && l.isEmpty()) Text("لا توجد مفاتيح بعد.", Modifier.padding(16.dp))
            l?.forEach { k ->
                Section(k.name) {
                    KeyValue("النوع", if (k.imported) "مستورد" else "أُنشئ على الهاتف")
                    KeyValue("صالح حتى", fmtDate(k.validUntil).substring(0, 10))
                    Ltr { Text(k.subject, style = MaterialTheme.typography.bodySmall) }
                    Ltr { Text("SHA-256: ${k.fingerprint}", style = MaterialTheme.typography.bodySmall) }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { askExportPw = k }) { Text("نسخة احتياطية") }
                        TextButton(onClick = { deleteKey = k }) { Text("حذف", color = MaterialTheme.colorScheme.error) }
                    }
                }
            }
        }
    }

    if (showGen) GenerateKeyDialog(onDismiss = { showGen = false }) { name, org, pw ->
        showGen = false; busy = true
        scope.launch {
            try { val k = app.keys.generate(name, org, pw); app.prefs.defaultKeyId = k.id; info = "أُنشئ المفتاح \"${k.name}\". صدّر نسخة احتياطية الآن." }
            catch (e: Exception) { error = e.message } finally { pw.fill('\u0000'); busy = false }
        }
    }
    importUri?.let { uri ->
        PasswordDialog("كلمة مرور الملف", "أدخل كلمة مرور ملف ‎.p12 / .pfx. (ملفات JKS غير مدعومة على أندرويد — حوّلها أولًا إلى p12.)",
            onDismiss = { importUri = null }) { pw ->
            importUri = null; busy = true
            scope.launch {
                try { val k = app.keys.import(uri, pw, "مفتاح مستورد"); info = "تم استيراد المفتاح" ; if (app.prefs.defaultKeyId == null) app.prefs.defaultKeyId = k.id }
                catch (e: Exception) { error = e.message } finally { pw.fill('\u0000'); busy = false }
            }
        }
    }
    askExportPw?.let { k ->
        PasswordDialog("تأكيد كلمة المرور", "للتأكد أنك تتذكر كلمة المرور قبل حفظ النسخة الاحتياطية.", onDismiss = { askExportPw = null }) { pw ->
            askExportPw = null
            scope.launch {
                try { app.keys.load(k.id, pw); exportKey = k; exportPw = pw; exportPicker.launch("askar-key-${k.name.replace(Regex("[^\\p{L}\\p{N}]+"), "_")}.p12") }
                catch (e: Exception) { pw.fill('\u0000'); error = e.message }
            }
        }
    }
    deleteKey?.let { k ->
        ConfirmDialog("حذف المفتاح نهائيًا؟", "لن تستطيع تحديث التطبيقات الموقّعة به إلا إذا كانت لديك نسخة احتياطية منه.", "حذف", { deleteKey = null }) {
            scope.launch { app.keys.delete(k.id); if (app.prefs.defaultKeyId == k.id) app.prefs.defaultKeyId = null }
        }
    }
    ErrorDialog(error) { error = null }
}

@Composable
private fun GenerateKeyDialog(onDismiss: () -> Unit, onOk: (String, String, CharArray) -> Unit) {
    var name by remember { mutableStateOf("أحمد عسكر") }
    var org by remember { mutableStateOf("Askar Online") }
    var pw by remember { mutableStateOf("") }
    var pw2 by remember { mutableStateOf("") }
    val pwErr = when { pw.isNotEmpty() && pw.length < 8 -> "8 أحرف على الأقل"; pw2.isNotEmpty() && pw != pw2 -> "غير متطابقة"; else -> null }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("مفتاح توقيع جديد") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(name, { name = it.take(60) }, label = { Text("اسم المطوّر / المفتاح") }, singleLine = true)
                OutlinedTextField(org, { org = it.take(60) }, label = { Text("الجهة (اختياري)") }, singleLine = true)
                OutlinedTextField(pw, { pw = it }, label = { Text("كلمة المرور") }, singleLine = true, visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
                OutlinedTextField(pw2, { pw2 = it }, label = { Text("تأكيد كلمة المرور") }, singleLine = true, visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), isError = pwErr != null, supportingText = { pwErr?.let { Text(it) } })
                Text("RSA-2048 • صالح 30 سنة • SHA256withRSA", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(enabled = name.isNotBlank() && pw.length >= 8 && pw == pw2, onClick = { onOk(name.trim(), org.trim(), pw.toCharArray()); pw = ""; pw2 = "" }) { Text("إنشاء") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
    )
}

/* ======================================================= الإعدادات */
@Composable
fun SettingsScreen(nav: Nav) {
    val theme by app.prefs.theme.collectAsState()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var prefix by remember { mutableStateOf(app.prefs.packagePrefix) }
    var keep by remember { mutableStateOf(app.prefs.keepBuilds.toString()) }
    var cacheMsg by remember { mutableStateOf<String?>(null) }
    val version = remember { runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "?" }

    Page("الإعدادات", nav) { pad ->
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(pad).padding(bottom = 24.dp)) {
            Section("المظهر") {
                listOf("system" to "حسب النظام", "light" to "فاتح", "dark" to "داكن").forEach { (k, l) ->
                    Row(Modifier.fillMaxWidth().selectable(theme == k) { app.prefs.setTheme(k) }, verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(theme == k, { app.prefs.setTheme(k) }); Text(l)
                    }
                }
            }
            Section("المشاريع الجديدة") {
                Ltr {
                    OutlinedTextField(prefix, { prefix = it.trim(); if (Regex("[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z][a-zA-Z0-9_]*)*").matches(prefix)) app.prefs.packagePrefix = prefix },
                        label = { Text("بادئة Package الافتراضية") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
                Text("مثال: com.askar ← com.askar.mathgame", style = MaterialTheme.typography.bodySmall)
            }
            Section("التخزين") {
                OutlinedTextField(keep, { keep = it.filter(Char::isDigit).take(3); keep.toIntOrNull()?.let { n -> app.prefs.keepBuilds = n } },
                    label = { Text("عدد ملفات APK المحفوظة داخل التطبيق") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedButton(onClick = {
                    scope.launch {
                        val freed = withContext(Dispatchers.IO) {
                            val s = SafeZip.dirSize(ctx.cacheDir); ctx.cacheDir.listFiles()?.forEach { SafeZip.deleteRecursive(it) }
                            File(ctx.filesDir, "template").listFiles()?.forEach { it.delete() }; s
                        }
                        cacheMsg = "تم تحرير ${fmtSize(freed)}"
                    }
                }) { Text("مسح الملفات المؤقتة") }
                cacheMsg?.let { Text(it) }
            }
            Section("عن التطبيق") {
                KeyValue("الإصدار", version)
                Text("Askar APK Builder — من عسكر أونلاين. يبني ويوقّع التطبيقات على الهاتف بدون إنترنت وبدون سيرفر.", style = MaterialTheme.typography.bodyMedium)
                Text("التوقيع بمكتبة apksig الرسمية من Google.", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
            }
        }
    }
}
