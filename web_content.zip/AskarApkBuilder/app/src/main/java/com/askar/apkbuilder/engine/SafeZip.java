package com.askar.apkbuilder.engine;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipInputStream;

/** Safe ZIP extraction: blocks ZIP-Slip, absolute paths, executables, zip bombs. */
public final class SafeZip {
    public static final long MAX_TOTAL_BYTES = 300L * 1024 * 1024;   // 300 MB uncompressed
    public static final int MAX_ENTRIES = 5000;
    private static final String[] BLOCKED = {".apk", ".dex", ".so", ".jar", ".sh", ".bat", ".cmd", ".exe", ".dll", ".elf", ".bin", ".apks", ".xapk", ".aab", ".odex", ".class"};

    public static final class Result {
        public int files;
        public long bytes;
        public final List<String> skipped = new ArrayList<>();
    }

    public interface Cancel { boolean isCancelled(); }

    public static boolean isBlocked(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        for (String b : BLOCKED) if (n.endsWith(b)) return true;
        return false;
    }

    /** Normalises an entry name and returns null if it is unsafe. */
    public static String safeName(String raw) {
        if (raw == null) return null;
        String n = raw.replace('\\', '/');
        while (n.startsWith("./")) n = n.substring(2);
        if (n.startsWith("/") || n.matches("^[A-Za-z]:.*")) return null;
        for (String part : n.split("/")) if (part.equals("..")) return null;
        if (n.contains("\u0000")) return null;
        return n;
    }

    public static Result extract(InputStream in, File dest, Cancel cancel) throws IOException {
        Result r = new Result();
        String destPath = dest.getCanonicalPath() + File.separator;
        byte[] buf = new byte[64 * 1024];
        int entries = 0;
        try (ZipInputStream z = new ZipInputStream(in)) {
            ZipEntry e;
            while ((e = z.getNextEntry()) != null) {
                if (cancel != null && cancel.isCancelled()) throw new IOException("أُلغيت العملية");
                if (++entries > MAX_ENTRIES) throw new IOException("الملف المضغوط يحتوي على عدد كبير جدًا من الملفات (أكثر من " + MAX_ENTRIES + ").");
                String name = safeName(e.getName());
                if (name == null) { r.skipped.add(e.getName() + " (مسار غير آمن)"); continue; }
                if (name.startsWith("__MACOSX/") || name.endsWith(".DS_Store")) continue;
                File out = new File(dest, name);
                if (!out.getCanonicalPath().startsWith(destPath) && !(out.getCanonicalPath() + File.separator).equals(destPath)) { r.skipped.add(name + " (خارج مجلد المشروع)"); continue; }
                if (e.isDirectory()) { if (!out.isDirectory() && !out.mkdirs()) throw new IOException("تعذّر إنشاء مجلد: " + name); continue; }
                if (isBlocked(name)) { r.skipped.add(name + " (نوع ملف تنفيذي غير مسموح)"); continue; }
                File parent = out.getParentFile();
                if (parent != null && !parent.isDirectory() && !parent.mkdirs()) throw new IOException("تعذّر إنشاء مجلد: " + parent.getName());
                try (OutputStream o = new FileOutputStream(out)) {
                    int n;
                    while ((n = z.read(buf)) > 0) {
                        r.bytes += n;
                        if (r.bytes > MAX_TOTAL_BYTES) throw new IOException("حجم المشروع بعد فك الضغط أكبر من 300 ميجابايت.");
                        if (cancel != null && cancel.isCancelled()) throw new IOException("أُلغيت العملية");
                        o.write(buf, 0, n);
                    }
                }
                r.files++;
            }
        } catch (ZipException ze) {
            throw new IOException("الملف المضغوط تالف أو ليس ZIP صالحًا: " + ze.getMessage());
        }
        if (entries == 0) throw new IOException("الملف المضغوط فارغ أو تالف.");
        return r;
    }

    /** Lists files (relative paths) under a directory. */
    public static List<String> listFiles(File root) {
        List<String> out = new ArrayList<>();
        walk(root, "", out);
        return out;
    }

    private static void walk(File dir, String prefix, List<String> out) {
        File[] kids = dir.listFiles();
        if (kids == null) return;
        java.util.Arrays.sort(kids);
        for (File k : kids) {
            String rel = prefix + k.getName();
            if (k.isDirectory()) walk(k, rel + "/", out); else out.add(rel);
        }
    }

    /** If the whole project sits inside one top-level folder, returns that folder, else the root. */
    public static File unwrapSingleFolder(File root) {
        File[] kids = root.listFiles(f -> !f.getName().startsWith(".") && !f.getName().equals("__MACOSX"));
        if (kids != null && kids.length == 1 && kids[0].isDirectory()) return kids[0];
        return root;
    }

    public static long dirSize(File f) {
        if (f.isFile()) return f.length();
        long s = 0; File[] k = f.listFiles(); if (k != null) for (File c : k) s += dirSize(c); return s;
    }

    public static boolean deleteRecursive(File f) {
        if (f == null || !f.exists()) return true;
        File[] k = f.listFiles(); if (k != null) for (File c : k) deleteRecursive(c);
        return f.delete();
    }
}
