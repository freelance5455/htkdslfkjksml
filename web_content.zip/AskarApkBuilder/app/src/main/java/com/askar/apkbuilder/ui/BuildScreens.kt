package com.askar.apkbuilder.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.askar.apkbuilder.Nav
import com.askar.apkbuilder.Screen
import com.askar.apkbuilder.core.BUILD_STAGES
import com.askar.apkbuilder.core.OutputActions
import com.askar.apkbuilder.data.BuildEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private fun copyText(ctx: Context, text: String) {
    (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("log", text))
    Toast.makeText(ctx, "تم النسخ", Toast.LENGTH_SHORT).show()
}

@Composable
private fun LogBox(lines: List<String>, modifier: Modifier = Modifier) {
    Ltr {
        Box(modifier.fillMaxWidth().background(Color(0xFF111827)).padding(8.dp)) {
            Column(Modifier.verticalScroll(rememberScrollState(Int.MAX_VALUE)).horizontalScroll(rememberScrollState())) {
                lines.forEach { Text(it, color = Color(0xFFD1FAE5), fontFamily = FontFamily.Monospace, fontSize = 11.sp) }
            }
        }
    }
}

/* ======================================================= شاشة التقدم */
@Composable
fun BuildScreen(nav: Nav) {
    val ui by app.builder.ui.collectAsState()
    val ctx = LocalContext.current
    LaunchedEffect(ui.status) { if (ui.status == "success" && ui.buildId > 0) nav.replace(Screen.Result(ui.buildId)) }

    Page("بناء التطبيق", nav) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            LinearProgressIndicator(progress = { ui.percent / 100f }, modifier = Modifier.fillMaxWidth().height(8.dp))
            Text("${ui.percent}% — ${ui.message}", fontWeight = FontWeight.Bold)
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    BUILD_STAGES.forEachIndexed { i, s ->
                        val (mark, color) = when {
                            ui.status == "failed" && i == ui.stage -> "✖" to MaterialTheme.colorScheme.error
                            ui.status == "cancelled" && i == ui.stage -> "■" to Color.Gray
                            i < ui.stage || ui.status == "success" -> "✔" to Color(0xFF2E7D32)
                            i == ui.stage -> "●" to MaterialTheme.colorScheme.primary
                            else -> "○" to Color.Gray
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(mark, color = color, modifier = Modifier.width(24.dp)); Text(s, color = if (i <= ui.stage) MaterialTheme.colorScheme.onSurface else Color.Gray)
                            if (i == ui.stage && ui.status == "running") { Spacer(Modifier.width(8.dp)); CircularProgressIndicator(Modifier.height(14.dp).width(14.dp), strokeWidth = 2.dp) }
                        }
                    }
                }
            }
            if (ui.error != null) Text(ui.error!!, color = if (ui.status == "cancelled") Color.Gray else MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
            LogBox(ui.log, Modifier.weight(1f))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                when (ui.status) {
                    "running" -> OutlinedButton(onClick = { app.builder.cancel() }) { Text("إلغاء البناء") }
                    "idle" -> Text("لا يوجد بناء حاليًا")
                    else -> {
                        Button(onClick = { app.builder.reset(); nav.back() }) { Text("رجوع للمشروع") }
                        if (ui.status == "success") OutlinedButton(onClick = { nav.replace(Screen.Result(ui.buildId)) }) { Text("النتيجة") }
                    }
                }
                TextButton(onClick = { copyText(ctx, ui.log.joinToString("\n")) }) { Text("نسخ السجل") }
            }
        }
    }
}

/* ======================================================= شاشة النتيجة */
@Composable
fun ResultScreen(nav: Nav, buildId: Long) {
    val b by app.db.builds().observe(buildId).collectAsState(initial = null)
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var msg by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val build = b ?: run { Page("النتيجة", nav) { Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() } }; return }
    val file = build.apkPath?.let(::File)?.takeIf { it.isFile }
    val fileName = file?.name ?: "app.apk"
    val saveAs = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(OutputActions.APK_MIME)) { uri ->
        if (uri != null && file != null) scope.launch {
            try { withContext(Dispatchers.IO) { OutputActions.saveTo(ctx, file, uri) }; msg = "تم الحفظ" } catch (e: Exception) { error = e.message }
        }
    }

    Page("النتيجة", nav) { pad ->
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(pad).padding(bottom = 24.dp)) {
            Section(if (build.status == "success") "✔ تم بناء التطبيق" else "حالة البناء: ${statusAr(build.status)}") {
                KeyValue("التطبيق", build.appName)
                Ltr { KeyValue("Package", build.packageName) }
                KeyValue("الإصدار", "${build.versionName} (${build.versionCode})")
                KeyValue("الحجم", fmtSize(build.apkSize))
                KeyValue("المفتاح", build.keyName)
                KeyValue("التاريخ", fmtDate(build.startedAt))
                if (build.certSha256.isNotEmpty()) Ltr { Text("SHA-256: " + build.certSha256, style = MaterialTheme.typography.bodySmall) }
                if (build.message.isNotEmpty() && build.status != "success") Text(build.message, color = MaterialTheme.colorScheme.error)
            }
            if (file != null) Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { OutputActions.install(ctx, file) }, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("تثبيت التطبيق", fontWeight = FontWeight.Bold) }
                OutlinedButton(onClick = {
                    scope.launch {
                        try { val where = withContext(Dispatchers.IO) { OutputActions.saveToDownloads(ctx, file, fileName) }; msg = "حُفظ في: $where" }
                        catch (e: Exception) { error = e.message }
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("حفظ في التنزيلات") }
                OutlinedButton(onClick = { saveAs.launch(fileName) }, modifier = Modifier.fillMaxWidth()) { Text("حفظ في مكان آخر…") }
                OutlinedButton(onClick = { OutputActions.share(ctx, file) }, modifier = Modifier.fillMaxWidth()) { Text("مشاركة") }
                OutlinedButton(onClick = { OutputActions.openDownloads(ctx) }, modifier = Modifier.fillMaxWidth()) { Text("فتح مجلد التنزيلات") }
                msg?.let { Text("✔ $it", color = Color(0xFF2E7D32)) }
                Text("التثبيت يتم عبر شاشة أندرويد الرسمية. قد يظهر تحذير Play Protect لأن التطبيق غير منشور على المتجر — هذا طبيعي للتطبيقات الموقّعة محليًا.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else if (build.status == "success") Text("ملف APK لم يعد موجودًا (حُذف تلقائيًا أو يدويًا). أعد البناء.", Modifier.padding(16.dp))
            if (build.log.isNotEmpty()) Section("السجل") {
                LogBox(build.log.lines(), Modifier.heightIn(max = 300.dp))
                TextButton(onClick = { copyText(ctx, build.log) }) { Text("نسخ السجل") }
            }
        }
    }
    ErrorDialog(error) { error = null }
}

fun statusAr(s: String) = when (s) { "success" -> "ناجح"; "failed" -> "فشل"; "cancelled" -> "أُلغي"; "running" -> "قيد التنفيذ"; else -> s }

/* ======================================================= سجل البناء */
@Composable
fun HistoryScreen(nav: Nav) {
    val list by app.db.builds().all().collectAsState(initial = null)
    val scope = rememberCoroutineScope()
    var toDelete by remember { mutableStateOf<BuildEntity?>(null) }
    Page("سجل البناء", nav) { pad ->
        val l = list
        if (l == null) Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
        else if (l.isEmpty()) Box(Modifier.fillMaxSize().padding(pad), Alignment.Center) { Text("لا توجد عمليات بناء بعد") }
        else LazyColumn(contentPadding = PaddingValues(top = pad.calculateTopPadding(), bottom = pad.calculateBottomPadding() + 16.dp)) {
            items(l, key = { it.id }) { b ->
                Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp).clickable { nav.go(Screen.Result(b.id)) }) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        val c = when (b.status) { "success" -> Color(0xFF2E7D32); "failed" -> MaterialTheme.colorScheme.error; else -> Color.Gray }
                        Text(statusAr(b.status), color = c, fontWeight = FontWeight.Bold, modifier = Modifier.width(70.dp))
                        Column(Modifier.weight(1f)) {
                            Text("${b.appName} v${b.versionName}", fontWeight = FontWeight.Medium)
                            Text(fmtDate(b.startedAt) + (if (b.apkSize > 0) " • " + fmtSize(b.apkSize) else ""), style = MaterialTheme.typography.bodySmall)
                            if (b.status != "success" && b.message.isNotEmpty()) Text(b.message, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                        }
                        TextButton(onClick = { toDelete = b }) { Text("حذف") }
                    }
                }
            }
        }
    }
    toDelete?.let { b ->
        ConfirmDialog("حذف من السجل؟", "سيُحذف السجل وملف APK الخاص به (إن وُجد).", "حذف", { toDelete = null }) {
            scope.launch { withContext(Dispatchers.IO) { b.apkPath?.let { File(it).delete() }; app.db.builds().delete(b.id) } }
        }
    }
}
