set -e

cat > backend/tae_planner.py <<'EOF'
"""TAE planner functions: pure maths, no database.
Follows TAE document v1.0, with these deliberate changes:
  - smooth critical indicator is 2/(1+e^(S/tau)) so S=0 gives exactly 1
  - the urgency scale (tau_u) is separate from the critical-indicator scale (tau_k)
  - B1, B2 and the impact share are divided by their maximum (not n-1) so all
    terms of the priority score span 0..1
  - total spread adds every chapter's spread linearly (one student studies them
    in series and their estimate errors move together)
"""
import math
from collections import defaultdict, deque


def _exp(x):
    return math.exp(max(-60.0, min(60.0, x)))


def topo_order(nodes, preds):
    """Peeling (F4-F8). Returns order, depth, successors. Raises on a cycle (F5)."""
    indeg = {n: len(preds[n]) for n in nodes}
    succs = defaultdict(list)
    for n in nodes:
        for p in preds[n]:
            succs[p].append(n)
    depth = {n: 0 for n in nodes}
    queue = deque(n for n in nodes if indeg[n] == 0)
    order = []
    while queue:
        n = queue.popleft()
        order.append(n)
        for m in succs[n]:
            depth[m] = max(depth[m], depth[n] + 1)
            indeg[m] -= 1
            if indeg[m] == 0:
                queue.append(m)
    if len(order) != len(nodes):
        raise ValueError("Prerequisite cycle in the syllabus map")
    return order, depth, succs


def cpm(order, preds, succs, dur, horizon=None):
    """ES, EF, total, LF, slack (F10-F15). horizon overrides the project end."""
    ef = {}
    for n in order:
        ef[n] = max((ef[p] for p in preds[n]), default=0.0) + dur[n]
    total = max(ef.values(), default=0.0)
    end = total if horizon is None else horizon
    lf, ls = {}, {}
    for n in reversed(order):
        lf[n] = min((ls[s] for s in succs[n]), default=end)
        ls[n] = lf[n] - dur[n]
    return total, lf, {n: lf[n] - ef[n] for n in order}


def kappa(slack, tau):
    return min(1.0, 2.0 / (1.0 + _exp(slack / tau)))


def descendant_counts(order, succs):
    """B2: number of chapters reachable from each chapter (F20)."""
    reach = {}
    for n in reversed(order):
        s = set()
        for m in succs[n]:
            s.add(m)
            s |= reach[m]
        reach[n] = s
    return {n: len(reach[n]) for n in order}


def bottleneck(out_deg, b2, kap, w=(0.3, 0.4, 0.3)):
    d1 = max(1, max(out_deg.values()))
    d2 = max(1, max(b2.values()))
    return {i: w[0] * out_deg[i] / d1 + w[1] * b2[i] / d2 + w[2] * kap[i] for i in out_deg}


def effective_difficulty(order, preds, base, alpha=0.1):
    """c(i) = base(i) + alpha * sum of prerequisite difficulties (section 9.1)."""
    c = {}
    for n in order:
        c[n] = base[n] + alpha * sum(c[p] for p in preds[n])
    return c


def urgency(tr):
    vals = [max(v, 0.0) for v in tr.values()]
    tau = max(0.5, sum(vals) / len(vals))
    return {i: 1.0 / (1.0 + _exp((v - tau) / tau)) for i, v in tr.items()}


def priority(impact, urg, bott, effort, kap, a=(0.4, 0.2, 0.4), a5=0.15):
    return {i: a[0] * impact[i] + a[1] * urg[i] + a[2] * bott[i]
            - a5 * effort[i] * (1.0 - kap[i]) for i in impact}


def pert(o, m, p):
    return (o + 4 * m + p) / 6.0, (p - o) / 6.0


def normal_cdf(x):
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def on_time_probability(horizon, mu, sigma):
    if sigma <= 1e-9:
        return 1.0 if horizon >= mu else 0.0
    return normal_cdf((horizon - mu) / sigma)


def eta_days(remaining, velocity):
    return None if velocity <= 1e-9 else remaining / velocity
EOF

cat > backend/jee_plan.py <<'EOF'
"""Planner: joins the mastery engine with the TAE maths."""
import math
from datetime import date, timedelta

import jee_engine
import syllabus
import tae_planner as tae

TARGET_MASTERY = 70.0   # mastery that counts as "chapter done"
O_FACTOR, P_FACTOR = 0.7, 1.6   # optimistic / pessimistic hours vs likely


def _progress(ins):
    return {e["chapter"]: 0.0 if e.get("mastery") is None
            else min(1.0, e["mastery"] / TARGET_MASTERY) for e in ins["chapters"]}


def build(sessions, settings, today_iso):
    today = date.fromisoformat(today_iso)
    exam = date.fromisoformat(settings["exam_date"])
    hpd = float(settings["hours_per_day"])
    days_left = max(0, (exam - today).days)
    horizon = days_left * hpd

    subject = {c: s for s, chs in syllabus.SYLLABUS.items() for c in chs}
    names = list(subject)
    preds = {c: list(syllabus.PREREQS.get(c, [])) for c in names}
    for c, ps in preds.items():
        for p in ps:
            if p not in subject:
                raise ValueError(f"Unknown prerequisite '{p}' for '{c}'")
    order, depth, succs = tae.topo_order(names, preds)

    now = jee_engine.insights(sessions, today_iso)
    prev = jee_engine.insights(sessions, (today - timedelta(days=7)).isoformat())
    prog, prog_prev = _progress(now), _progress(prev)
    mastery = {e["chapter"]: e.get("mastery") for e in now["chapters"]}

    mu, sd = {}, {}
    for n in names:
        m = syllabus.HOURS.get(n, syllabus.DEFAULT_HOURS)
        mu[n], sd[n] = tae.pert(O_FACTOR * m, m, P_FACTOR * m)
    rem = {n: mu[n] * (1 - prog[n]) for n in names}
    rem_sd = {n: sd[n] * (1 - prog[n]) for n in names}

    # structure: critical chain, blocking, bottleneck
    chain, _, slack = tae.cpm(order, preds, succs, rem)
    kap = {n: tae.kappa(slack[n], max(1.0, 0.1 * chain)) for n in names}
    out_deg = {n: len(succs[n]) for n in names}
    b2 = tae.descendant_counts(order, succs)
    bott = tae.bottleneck(out_deg, b2, kap)

    # difficulty and effort
    weak = {n: 1 - prog[n] for n in names}
    diff = tae.effective_difficulty(order, preds, {n: 1 + weak[n] for n in names})
    raw_e = {n: diff[n] * rem[n] for n in names}
    e_max = max(raw_e.values()) or 1.0
    effort = {n: raw_e[n] / e_max for n in names}

    # deadlines from the exam horizon -> urgency
    _, lf, _ = tae.cpm(order, preds, succs, rem, horizon)
    tr = {n: lf[n] / hpd for n in names}
    urg = tae.urgency(tr)

    b2_max = max(1, max(b2.values()))
    impact = {n: 0.5 * b2[n] / b2_max + 0.5 * weak[n] for n in names}
    score = tae.priority(impact, urg, bott, effort, kap)

    todo = sorted((n for n in names if prog[n] < 1), key=lambda n: -score[n])
    next_up = []
    for n in todo[:5]:
        why = []
        if b2[n] >= 3:
            why.append(f"unlocks {b2[n]} later chapters")
        if kap[n] >= 0.5:
            why.append("on the critical chain")
        if mastery[n] is None:
            why.append("not tested yet")
        elif mastery[n] < 45:
            why.append(f"weak ({round(mastery[n])}%)")
        next_up.append({
            "chapter": n, "subject": subject[n], "priority": round(score[n], 3),
            "hours_left": round(rem[n], 1), "unlocks": b2[n],
            "mastery": mastery[n], "why": why,
            "do_first": [p for p in preds[n] if prog[p] < 0.5],
        })

    # feasibility (PERT, chapters studied in series)
    needed = sum(rem.values())
    sigma = sum(rem_sd.values())   # one student: estimate errors move together
    p_on = tae.on_time_probability(horizon, needed, sigma) if needed > 0 else 1.0
    verdict = "on_track" if p_on >= 0.8 else "tight" if p_on >= 0.4 else "behind"

    # rolling 7-day velocity and ETA (hours of progress per day)
    done_now = sum(mu[n] * prog[n] for n in names)
    done_prev = sum(mu[n] * prog_prev[n] for n in names)
    velocity = (done_now - done_prev) / 7.0
    eta = tae.eta_days(needed, velocity)
    eta_date = (today + timedelta(days=math.ceil(eta))).isoformat() \
        if eta is not None and eta < 3650 else None

    logged = sum(s["minutes"] for s in sessions
                 if 0 <= (today - date.fromisoformat(s["date"])).days < 7) / 60.0
    return {
        "days_left": days_left, "hours_per_day": hpd,
        "hours_available": round(horizon, 1), "hours_needed": round(needed, 1),
        "hours_sigma": round(sigma, 1), "p_on_time": round(p_on, 3),
        "verdict": verdict,
        "pace_needed": round(needed / days_left, 1) if days_left else None,
        "velocity": round(velocity, 2), "eta_date": eta_date,
        "burn_rate": round(logged / 7.0 / hpd, 2) if hpd else None,
        "chain_hours": round(chain, 1), "next_up": next_up,
    }
EOF

cat >> backend/syllabus.py <<'EOF'


# ---- Planner inputs (edit freely) ----
# Likely study hours per chapter (first learning + practice up to mastery 70).
DEFAULT_HOURS = 14
HOURS = {
    "Units and Measurements": 8, "Electromagnetic Waves": 6, "Semiconductors": 10,
    "Rotational Motion": 22, "Electrostatics": 22, "Current Electricity": 20,
    "Magnetism and Moving Charges": 20, "Thermodynamics": 18,
    "Some Basic Concepts": 12, "Periodic Table": 10, "Metallurgy": 8,
    "Practical Chemistry": 8, "Biomolecules and Polymers": 10,
    "Chemical Bonding": 18, "General Organic Chemistry": 22, "Hydrocarbons": 16,
    "Statistics": 8, "Complex Numbers": 16, "Matrices and Determinants": 16,
    "Permutations and Combinations": 18, "Probability": 16, "Conic Sections": 20,
    "3D Geometry": 18, "Indefinite Integrals": 20, "Definite Integrals and Area": 20,
    "Application of Derivatives": 22,
    "Limits, Continuity and Differentiability": 22,
}

# chapter -> chapters that should come first (must stay free of cycles)
PREREQS = {
    "Complex Numbers": ["Quadratic Equations", "Trigonometry"],
    "Sequences and Series": ["Quadratic Equations"],
    "Binomial Theorem": ["Permutations and Combinations"],
    "Probability": ["Permutations and Combinations"],
    "Inverse Trigonometry": ["Trigonometry", "Sets, Relations and Functions"],
    "Limits, Continuity and Differentiability": ["Sets, Relations and Functions", "Trigonometry"],
    "Application of Derivatives": ["Limits, Continuity and Differentiability"],
    "Indefinite Integrals": ["Application of Derivatives"],
    "Definite Integrals and Area": ["Indefinite Integrals"],
    "Differential Equations": ["Indefinite Integrals"],
    "Circles": ["Straight Lines"],
    "Conic Sections": ["Straight Lines", "Circles"],
    "3D Geometry": ["Vectors"],
    "Kinematics": ["Units and Measurements", "Vectors", "Trigonometry"],
    "Laws of Motion": ["Kinematics"],
    "Work, Energy and Power": ["Laws of Motion"],
    "Rotational Motion": ["Work, Energy and Power"],
    "Gravitation": ["Laws of Motion"],
    "Properties of Solids and Fluids": ["Laws of Motion"],
    "Oscillations and Waves": ["Work, Energy and Power"],
    "Thermodynamics": ["Kinetic Theory of Gases"],
    "Current Electricity": ["Electrostatics"],
    "Magnetism and Moving Charges": ["Current Electricity"],
    "Electromagnetic Induction and AC": ["Magnetism and Moving Charges"],
    "Electromagnetic Waves": ["Electromagnetic Induction and AC"],
    "Ray Optics": ["Trigonometry"],
    "Wave Optics": ["Ray Optics", "Electromagnetic Waves"],
    "Dual Nature of Matter": ["Electromagnetic Waves"],
    "Atoms and Nuclei": ["Dual Nature of Matter"],
    "Semiconductors": ["Current Electricity", "Atoms and Nuclei"],
    "Atomic Structure": ["Some Basic Concepts"],
    "Chemical Bonding": ["Atomic Structure"],
    "Periodic Table": ["Atomic Structure"],
    "s and p Block Elements": ["Periodic Table", "Chemical Bonding"],
    "d and f Block Elements": ["s and p Block Elements"],
    "Coordination Compounds": ["Chemical Bonding", "d and f Block Elements"],
    "Chemical Thermodynamics": ["Some Basic Concepts", "Thermodynamics"],
    "Chemical Equilibrium": ["Chemical Thermodynamics"],
    "Ionic Equilibrium": ["Chemical Equilibrium", "Quadratic Equations"],
    "Redox and Electrochemistry": ["Ionic Equilibrium"],
    "Chemical Kinetics": ["Some Basic Concepts"],
    "Solutions": ["Some Basic Concepts"],
    "General Organic Chemistry": ["Chemical Bonding"],
    "Hydrocarbons": ["General Organic Chemistry"],
    "Haloalkanes and Haloarenes": ["Hydrocarbons"],
    "Alcohols, Phenols and Ethers": ["Haloalkanes and Haloarenes"],
    "Aldehydes and Ketones": ["Alcohols, Phenols and Ethers"],
    "Carboxylic Acids and Derivatives": ["Aldehydes and Ketones"],
    "Amines": ["Carboxylic Acids and Derivatives"],
    "Biomolecules and Polymers": ["Aldehydes and Ketones"],
}
EOF

cat >> backend/jee_data.py <<'EOF'


# ---- planner settings ----
SETTING_DEFAULTS = {"exam_date": "2027-01-22", "hours_per_day": "8"}


def get_settings(con):
    con.execute("CREATE TABLE IF NOT EXISTS jee_settings "
                "(key TEXT PRIMARY KEY, value TEXT NOT NULL)")
    saved = dict(con.execute("SELECT key, value FROM jee_settings").fetchall())
    return {**SETTING_DEFAULTS, **saved}


def save_settings(con, p):
    exam = p.get("exam_date")
    Date.fromisoformat(exam if isinstance(exam, str) else "")
    try:
        hours = float(p.get("hours_per_day"))
    except (TypeError, ValueError):
        raise ValueError("Daily hours must be a number.")
    if not 1 <= hours <= 16:
        raise ValueError("Daily hours must be between 1 and 16.")
    get_settings(con)
    for key, value in (("exam_date", exam), ("hours_per_day", str(hours))):
        con.execute("INSERT INTO jee_settings (key, value) VALUES (?, ?) "
                    "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))
    con.commit()
    return get_settings(con)
EOF

python3 - <<'EOF'
p = "backend/jee_api.py"
s = open(p).read()
assert "jee_plan" not in s, "jee_api.py already patched"
a = "import jee_engine\n"
g = 'if path == "/api/jee/sessions":'
q = 'if path == "/api/jee/session":'
for x in (a, g, q):
    assert s.count(x) == 1, "unexpected jee_api.py layout: " + x
s = s.replace(a, a + "import jee_plan\n")
s = s.replace(g, '''if path == "/api/jee/settings":
            return h.send_json(200, {"settings": jee_data.get_settings(db)})
        if path == "/api/jee/plan":
            today = params.get("today", [date.today().isoformat()])[0]
            date.fromisoformat(today)
            return h.send_json(200, {"plan": jee_plan.build(
                jee_data.all_sessions(db), jee_data.get_settings(db), today)})
        ''' + g)
s = s.replace(q, '''if path == "/api/jee/settings":
            return h.send_json(200, {"settings": jee_data.save_settings(db, payload)})
        ''' + q)
open(p, "w").write(s)
print("jee_api.py patched")
EOF

cat > web/planner.js <<'EOF'
'use strict';
(() => {
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const todayISO = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
const fmt = iso => new Date(iso + 'T00:00:00').toLocaleDateString(undefined, {day:'numeric', month:'short', year:'numeric'});
const VERDICT = {on_track:['On track','strong'], tight:['Tight','developing'], behind:['Behind','weak']};
let timer;

async function api(path, opts) {
  const res = await fetch(path, opts);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

function markHours() {
  const v = Number($('pHours').value);
  document.querySelectorAll('[data-hours]').forEach(b => b.setAttribute('aria-pressed', Number(b.dataset.hours) === v));
}

function render(p) {
  const [label, st] = VERDICT[p.verdict];
  const pct = Math.round(p.p_on_time * 100);
  let pace = p.eta_date
    ? `At your current pace you finish around ${fmt(p.eta_date)}.`
    : 'Log sessions with questions to see your finish date.';
  if (p.days_left === 0) pace = 'The exam date has passed. Set a new date.';
  const need = p.pace_needed === null ? '' : `You need about ${p.pace_needed} h/day; you plan ${p.hours_per_day}. `;
  const burn = p.burn_rate !== null && p.burn_rate > 1 ? ' Your last 7 days ran above your daily limit.' : '';
  const next = p.next_up.map(e => `<div class="topic st-${e.mastery === null ? 'early' : e.mastery < 45 ? 'weak' : 'developing'}">
    <div class="topic-head"><b>${esc(e.chapter)}</b><span>${e.hours_left} h left</span></div>
    <small>${esc(e.subject)}${e.why.length ? ' · ' + esc(e.why.join(' · ')) : ''}</small>
    ${e.do_first.length ? `<p>Do first: ${esc(e.do_first.join(', '))}</p>` : ''}</div>`).join('');
  $('plannerBody').innerHTML = `
    <div class="strip"><div><strong>${p.days_left}</strong><span>days left</span></div>
      <div><strong>${p.hours_available}</strong><span>hours available</span></div>
      <div><strong>${p.hours_needed}</strong><span>hours needed</span></div></div>
    <div class="topic st-${st}" style="margin-top:14px"><div class="topic-head"><b>${label}</b><span>${pct}% chance to finish</span></div>
      <small>${need}${esc(pace)}${burn}</small>
      <div class="bar"><i style="width:${Math.max(2, pct)}%"></i></div></div>
    <h3 class="panel-title gap">Study next</h3>${next || '<p class="empty">Every chapter has reached the target.</p>'}
    <p class="muted explanatory">Hours per chapter are rough defaults in syllabus.py. Edit them to match you.</p>`;
}

async function load() {
  try {
    const {plan} = await api('/api/jee/plan?today=' + todayISO());
    render(plan);
  } catch (e) { $('plannerBody').innerHTML = `<p class="empty">Planner unavailable: ${esc(e.message)}</p>`; }
}

async function loadSettings() {
  try {
    const {settings} = await api('/api/jee/settings');
    $('pExam').value = settings.exam_date; $('pHours').value = settings.hours_per_day; markHours();
  } catch (e) {}
}

document.addEventListener('click', ev => {
  const b = ev.target.closest('[data-hours]');
  if (b) { $('pHours').value = b.dataset.hours; markHours(); }
});
$('pHours').addEventListener('input', markHours);
$('pSave').addEventListener('click', async () => {
  const msg = $('pMsg'); msg.style.color = ''; msg.textContent = '';
  try {
    await api('/api/jee/settings', {method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({exam_date: $('pExam').value, hours_per_day: Number($('pHours').value)})});
    msg.textContent = 'Saved'; setTimeout(() => msg.textContent = '', 2500); load();
  } catch (e) { msg.textContent = e.message; msg.style.color = '#ffb4ab'; }
});
// reload whenever jee.js redraws the "today" strip (after a session is saved or deleted)
new MutationObserver(() => { clearTimeout(timer); timer = setTimeout(load, 300); })
  .observe($('todayStrip'), {childList: true});

loadSettings().then(load);
})();
EOF

python3 - <<'EOF'
p = "web/jee.html"
s = open(p).read()
assert "plannerBody" not in s, "jee.html already patched"
anchor = '<section class="section-head"><div><p class="eyebrow">LOG</p>'
assert s.count(anchor) == 1 and s.count('<script src="jee.js"></script>') == 1
block = '''<section class="section-head"><div><p class="eyebrow">PLANNER</p><h2>Exam plan</h2></div></section>
<section class="panel">
  <div class="fields">
    <div class="field"><label for="pExam">Exam date</label><input id="pExam" type="date"></div>
    <div class="field"><label for="pHours">Study hours / day</label><input id="pHours" type="number" inputmode="decimal" min="1" max="16" step="0.5"></div>
  </div>
  <div class="chips gap"><button type="button" class="chip-btn" data-hours="6" aria-pressed="false">6 h</button><button type="button" class="chip-btn" data-hours="8" aria-pressed="false">8 h</button><button type="button" class="chip-btn" data-hours="12" aria-pressed="false">12 h</button></div>
  <button id="pSave" class="primary-btn">Save plan settings</button>
  <p id="pMsg" class="status" aria-live="polite"></p>
  <div id="plannerBody" class="gap"></div>
</section>

'''
s = s.replace(anchor, block + anchor)
s = s.replace('<script src="jee.js"></script>', '<script src="jee.js"></script>\n<script src="planner.js"></script>')
open(p, "w").write(s)
print("jee.html patched")
EOF

echo "Done. Restart the server: python server.py"
