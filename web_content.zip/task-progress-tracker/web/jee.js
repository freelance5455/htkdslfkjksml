'use strict';
(() => {
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const todayISO = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
const TYPES = [
  ['concept', 'Concept', 'Did not know the idea or formula'],
  ['calculation', 'Calculation', 'Right method, arithmetic or algebra slip'],
  ['silly', 'Silly', 'Misread, sign, unit, wrong option'],
  ['time', 'Time', 'Ran out of time or skipped']
];
const LABEL = {concept:'Concept', calculation:'Calculation', silly:'Silly', time:'Time', unclassified:'Untagged'};
const STATUS_TEXT = {weak:'Weak', developing:'Developing', strong:'Strong', early:'Too few questions', studied:'No questions yet', untouched:'Not started'};

let syllabus = {};
const form = { subject: null, chapter: null, err: {concept:0, calculation:0, silly:0, time:0} };

async function api(path, opts) {
  const res = await fetch(path, opts);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}
const post = (path, body) => api(path, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body)});
const num = id => { const v = $(id).value.trim(); return v === '' ? 0 : Number(v); };

function remember() {
  try { localStorage.setItem('jee-lab-last', JSON.stringify({subject:form.subject, chapter:form.chapter})); } catch (e) {}
}
function recall() {
  try { return JSON.parse(localStorage.getItem('jee-lab-last')) || {}; } catch (e) { return {}; }
}

/* ---------- form ---------- */
function renderSubjects() {
  $('subjectChips').innerHTML = Object.keys(syllabus).map(s =>
    `<button type="button" class="chip-btn" data-subject="${esc(s)}" aria-pressed="${s === form.subject}">${esc(s)}</button>`).join('');
}
function renderChapters() {
  $('chapterSel').innerHTML = (syllabus[form.subject] || []).map(c =>
    `<option ${c === form.chapter ? 'selected' : ''}>${esc(c)}</option>`).join('');
  form.chapter = $('chapterSel').value;
}
function renderSteppers() {
  $('mistakeSteppers').innerHTML = TYPES.map(([k, name, hint]) =>
    `<div class="stepper"><div><b>${name}</b><small>${hint}</small></div>
     <div class="step-ctl"><button type="button" data-dec="${k}" aria-label="Fewer ${name}">−</button><output>${form.err[k]}</output><button type="button" data-inc="${k}" aria-label="More ${name}">+</button></div></div>`).join('');
}
function wrongCount() { return Math.max(0, num('fAttempted') - num('fCorrect')); }
function updateHint() {
  const wrong = wrongCount(), tagged = Object.values(form.err).reduce((a, b) => a + b, 0);
  $('wrongCount').textContent = wrong;
  const hint = $('tagHint');
  hint.classList.remove('error');
  if (num('fCorrect') > num('fAttempted')) { hint.textContent = 'Correct is more than attempted.'; hint.classList.add('error'); }
  else if (tagged > wrong) { hint.textContent = `You tagged ${tagged} mistakes but only ${wrong} answers are wrong.`; hint.classList.add('error'); }
  else hint.textContent = wrong ? `${tagged} of ${wrong} wrong answers tagged. Untagged ones are fine but give vaguer advice.` : 'Nothing wrong to tag.';
}
function resetForm() {
  ['fMinutes','fAttempted','fCorrect','fNotes'].forEach(id => $(id).value = '');
  Object.keys(form.err).forEach(k => form.err[k] = 0);
  renderSteppers(); updateHint();
}

/* ---------- insights ---------- */
const bar = (pct, status) => `<div class="bar st-${status}"><i style="width:${Math.max(2, Math.min(100, pct))}%"></i></div>`;

function topicHTML(e, extra) {
  return `<div class="topic st-${e.status}"><div class="topic-head"><b>${esc(e.chapter)}</b><span>${e.mastery}%</span></div>
    <small>${esc(e.subject)} · ${e.correct}/${e.attempted} correct · last practised ${e.days_since === 0 ? 'today' : e.days_since + 'd ago'}</small>
    ${bar(e.mastery, e.status)}${extra}</div>`;
}

function renderInsights(ins) {
  const t = ins.today_totals;
  $('todayStrip').innerHTML = `<div class="strip">
    <div><strong>${t.minutes}</strong><span>minutes today</span></div>
    <div><strong>${t.attempted ? Math.round(100 * t.correct / t.attempted) + '%' : '–'}</strong><span>accuracy today</span></div>
    <div><strong>${ins.week_accuracy === null ? '–' : ins.week_accuracy + '%'}</strong><span>7-day accuracy</span></div></div>`;
  $('engineChip').textContent = ins.engine === 'default' ? 'default maths' : 'TAE maths';

  $('weakList').innerHTML = ins.weak.length ? ins.weak.map(e =>
    topicHTML(e, `<p>${e.dominant_mistake ? `<b>Mostly ${LABEL[e.dominant_mistake].toLowerCase()} mistakes.</b> ` : ''}${esc(e.advice)}</p>`)).join('')
    : '<p class="empty">Log a session with questions attempted and your weak chapters will appear here.</p>';

  $('dueList').innerHTML = ins.revision_due.length ? ins.revision_due.map(e =>
    `<div class="topic st-${e.status}"><div class="topic-head"><b>${esc(e.chapter)}</b><span>${Math.round(e.retention * 100)}% retained</span></div>
     <small>${esc(e.subject)} · not practised for ${e.days_since} days</small></div>`).join('')
    : '<p class="empty">Nothing is fading yet. Chapters appear here when your retention drops under 50%.</p>';

  const mix = ins.mistake_mix, order = ['concept','calculation','silly','time','unclassified'];
  $('mixBars').innerHTML = mix.total ? order.filter(k => mix.counts[k]).map(k => {
    const pct = Math.round(100 * mix.counts[k] / mix.total);
    return `<div class="analysis-bar-row"><div class="analysis-bar-label"><span>${LABEL[k]}</span><span>${mix.counts[k]} · ${pct}%</span></div><div class="analysis-bar-track"><div class="analysis-bar-fill" style="width:${pct}%"></div></div></div>`;
  }).join('') : '<p class="empty">No wrong answers logged in the last 30 days.</p>';

  $('subjectBlocks').innerHTML = Object.entries(ins.subjects).map(([name, s]) => {
    const rows = ins.chapters.filter(c => c.subject === name).map(c => {
      if (c.mastery === undefined) return `<div class="chap st-${c.status}"><div class="chap-top"><span style="color:var(--muted);font-weight:500;flex:1">${esc(c.chapter)}</span><span>${STATUS_TEXT[c.status]}</span></div></div>`;
      return `<div class="chap st-${c.status}"><div class="chap-top"><b>${esc(c.chapter)}</b><span>${c.mastery}%</span></div>${bar(c.mastery, c.status)}<small>${STATUS_TEXT[c.status]} · ${Math.round(c.retention * 100)}% retained · ${c.attempted} questions</small></div>`;
    }).join('');
    return `<details class="subject"><summary><b>${esc(name)}</b><span>${s.avg_mastery === null ? 'no scores yet' : 'avg ' + s.avg_mastery + '%'}<br>${s.started}/${s.chapters} chapters started</span></summary><div class="chap-list">${rows}</div></details>`;
  }).join('');
}

function renderRecent(list) {
  $('recentList').innerHTML = list.length ? list.map(s => {
    const wrong = s.attempted - s.correct;
    return `<div class="recent"><div>${esc(s.chapter)}<small>${esc(s.date)} · ${esc(s.subject)} · ${s.minutes}m · ${s.correct}/${s.attempted} correct${wrong ? ` · wrong: ${s.concept_err}C ${s.calculation_err}Calc ${s.silly_err}S ${s.time_err}T` : ''}</small>${s.notes ? `<small>${esc(s.notes)}</small>` : ''}</div><button data-del="${s.id}">Delete</button></div>`;
  }).join('') : '<p class="empty">No sessions yet.</p>';
}

async function refresh() {
  try {
    const [a, b] = await Promise.all([
      api('/api/jee/insights?today=' + todayISO()),
      api('/api/jee/sessions?limit=12')]);
    renderInsights(a.insights); renderRecent(b.sessions);
  } catch (e) { $('saveMsg').textContent = 'Could not load: ' + e.message; $('saveMsg').style.color = '#ffb4ab'; }
}

/* ---------- events ---------- */
document.addEventListener('click', async ev => {
  const t = ev.target.closest('button'); if (!t) return;
  if (t.dataset.subject) { form.subject = t.dataset.subject; form.chapter = null; renderSubjects(); renderChapters(); remember(); }
  else if (t.dataset.inc || t.dataset.dec) {
    const k = t.dataset.inc || t.dataset.dec;
    form.err[k] = Math.max(0, form.err[k] + (t.dataset.inc ? 1 : -1));
    renderSteppers(); updateHint();
  } else if (t.dataset.del) {
    if (!confirm('Delete this session?')) return;
    try { await post('/api/jee/session/delete', {id: Number(t.dataset.del)}); refresh(); } catch (e) { alert(e.message); }
  }
});
$('chapterSel').addEventListener('change', () => { form.chapter = $('chapterSel').value; remember(); });
['fAttempted', 'fCorrect'].forEach(id => $(id).addEventListener('input', updateHint));

$('saveSession').addEventListener('click', async () => {
  const msg = $('saveMsg'); msg.style.color = ''; msg.textContent = '';
  const body = {date: todayISO(), subject: form.subject, chapter: form.chapter,
    minutes: num('fMinutes'), attempted: num('fAttempted'), correct: num('fCorrect'),
    concept_err: form.err.concept, calculation_err: form.err.calculation,
    silly_err: form.err.silly, time_err: form.err.time, notes: $('fNotes').value.trim()};
  try {
    await post('/api/jee/session', body);
    msg.textContent = `Saved: ${form.chapter}`;
    resetForm(); refresh();
    setTimeout(() => msg.textContent = '', 3500);
  } catch (e) { msg.textContent = e.message; msg.style.color = '#ffb4ab'; }
});

(async function init() {
  try {
    syllabus = (await api('/api/jee/syllabus')).syllabus;
    const last = recall();
    form.subject = syllabus[last.subject] ? last.subject : Object.keys(syllabus)[0];
    form.chapter = (syllabus[form.subject] || []).includes(last.chapter) ? last.chapter : null;
    renderSubjects(); renderChapters(); renderSteppers(); updateHint();
    refresh();
  } catch (e) {
    $('saveMsg').textContent = 'Start the server with: python server.py  (' + e.message + ')';
    $('saveMsg').style.color = '#ffb4ab';
  }
})();
})();
