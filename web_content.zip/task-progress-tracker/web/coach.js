'use strict';
(() => {
const $ = id => document.getElementById(id);
const todayISO = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
const QUICK = ['What should I study today?', 'How am I doing?', 'What are my weak topics?', 'What should I revise?', 'What mistakes do I make most?'];

function add(who, text) {
  const d = document.createElement('div');
  d.className = 'msg ' + who;
  d.textContent = text;
  $('coachLog').appendChild(d);
  $('coachLog').scrollTop = $('coachLog').scrollHeight;
}

async function ask(text) {
  text = text.trim();
  if (!text) return;
  add('you', text);
  $('coachText').value = '';
  try {
    const res = await fetch('/api/jee/coach', {method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({message: text, today: todayISO()})});
    const data = await res.json().catch(() => ({}));
    add('coach', res.ok ? data.reply : (data.error || 'Something went wrong.'));
  } catch (e) { add('coach', 'Could not reach the server.'); }
}

$('coachChips').innerHTML = QUICK.map(q => `<button type="button" class="chip-btn" data-q="${q}">${q}</button>`).join('');
$('coachChips').addEventListener('click', ev => {
  const b = ev.target.closest('[data-q]');
  if (b) ask(b.dataset.q);
});
$('coachSend').addEventListener('click', () => ask($('coachText').value));
$('coachText').addEventListener('keydown', ev => { if (ev.key === 'Enter') ask($('coachText').value); });
add('coach', 'Hi! I read your plan and scores to answer. Tap a question below, type your own, or name a chapter like "Electrostatics".');
})();
