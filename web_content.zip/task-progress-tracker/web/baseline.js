'use strict';
(() => {
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const LEVELS = ['Not started', 'Basics', 'Good', 'Strong'];

async function api(path, opts) {
  const res = await fetch(path, opts);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

function updateCounts() {
  document.querySelectorAll('#baselineBox details').forEach(d => {
    const n = [...d.querySelectorAll('select')].filter(s => Number(s.value) > 0).length;
    d.querySelector('summary span').textContent = n ? `${n} rated` : 'none rated';
  });
}

async function init() {
  try {
    const [{syllabus}, {baseline}] = await Promise.all([api('/api/jee/syllabus'), api('/api/jee/baseline')]);
    $('baselineBox').innerHTML = Object.entries(syllabus).map(([subject, chapters]) => {
      const rows = chapters.map(c => `<div class="chap"><div class="chap-top">
        <span style="color:var(--text);font-weight:500;flex:1">${esc(c)}</span>
        <select data-ch="${esc(c)}" style="width:44%">${LEVELS.map((l, i) =>
          `<option value="${i}" ${(baseline[c] || 0) === i ? 'selected' : ''}>${l}</option>`).join('')}</select>
        </div></div>`).join('');
      return `<details class="subject"><summary><b>${esc(subject)}</b><span></span></summary><div class="chap-list">${rows}</div></details>`;
    }).join('');
    updateCounts();
    $('baselineBox').addEventListener('change', updateCounts);
  } catch (e) { $('baselineBox').innerHTML = `<section class="panel"><p class="empty">Could not load: ${esc(e.message)}</p></section>`; }
}

$('baselineSave').addEventListener('click', async () => {
  const msg = $('baselineMsg'); msg.style.color = ''; msg.textContent = '';
  const levels = {};
  document.querySelectorAll('#baselineBox select').forEach(s => { levels[s.dataset.ch] = Number(s.value); });
  try {
    await api('/api/jee/baseline', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({levels})});
    msg.textContent = 'Saved'; setTimeout(() => msg.textContent = '', 2500);
    window.dispatchEvent(new Event('jee-refresh'));
  } catch (e) { msg.textContent = e.message; msg.style.color = '#ffb4ab'; }
});

init();
})();
