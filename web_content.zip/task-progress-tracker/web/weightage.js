'use strict';
(() => {
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

async function api(path, opts) {
  const res = await fetch(path, opts);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

function updateCounts() {
  document.querySelectorAll('#weightBox details').forEach(d => {
    const n = [...d.querySelectorAll('input')].filter(i => i.value !== '').length;
    d.querySelector('summary span').textContent = n ? `${n} filled` : 'none filled';
  });
}

async function init() {
  try {
    const [{syllabus}, {weightage}] = await Promise.all([api('/api/jee/syllabus'), api('/api/jee/weightage')]);
    $('weightBox').innerHTML = Object.entries(syllabus).map(([subject, chapters]) => {
      const rows = chapters.map(c => `<div class="chap"><div class="chap-top">
        <span style="color:var(--text);font-weight:500;flex:1">${esc(c)}</span>
        <input type="number" inputmode="decimal" min="0" max="50" step="0.1" data-ch="${esc(c)}"
          value="${weightage[c] ?? ''}" placeholder="-" style="width:28%"></div></div>`).join('');
      return `<details class="subject"><summary><b>${esc(subject)}</b><span></span></summary><div class="chap-list">${rows}</div></details>`;
    }).join('');
    updateCounts();
    $('weightBox').addEventListener('input', updateCounts);
  } catch (e) { $('weightBox').innerHTML = `<section class="panel"><p class="empty">Could not load: ${esc(e.message)}</p></section>`; }
}

$('weightSave').addEventListener('click', async () => {
  const msg = $('weightMsg'); msg.style.color = ''; msg.textContent = '';
  const values = {};
  document.querySelectorAll('#weightBox input').forEach(i => { values[i.dataset.ch] = i.value === '' ? null : Number(i.value); });
  try {
    await api('/api/jee/weightage', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({values})});
    msg.textContent = 'Saved'; setTimeout(() => msg.textContent = '', 2500);
    window.dispatchEvent(new Event('jee-refresh'));
  } catch (e) { msg.textContent = e.message; msg.style.color = '#ffb4ab'; }
});

init();
})();
