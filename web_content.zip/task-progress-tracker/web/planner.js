'use strict';
(() => {
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const todayISO = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
const fmt = iso => new Date(iso + 'T00:00:00').toLocaleDateString(undefined, {day:'numeric', month:'short', year:'numeric'});
const VERDICT = {on_track:['On track','strong'], tight:['Tight','developing'], behind:['Behind','weak']};
let timer;

async function api(path, opts) {
  const res = await fetch(path, opts);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

function markHours() {
  const v = Number($('pHours').value);
  document.querySelectorAll('[data-hours]').forEach(b => b.setAttribute('aria-pressed', Number(b.dataset.hours) === v));
}

function render(p) {
  const [label, st] = VERDICT[p.verdict];
  const pct = Math.round(p.p_on_time * 100);
  let pace = p.eta_date
    ? `At your current pace you finish around ${fmt(p.eta_date)}.`
    : 'Log sessions with questions to see your finish date.';
  if (p.days_left === 0) pace = 'The exam date has passed. Set a new date.';
  const need = p.pace_needed === null ? '' : `You need about ${p.pace_needed} h/day; you plan ${p.hours_per_day}. `;
  const burn = p.burn_rate !== null && p.burn_rate > 1 ? ' Your last 7 days ran above your daily limit.' : '';
  const next = p.next_up.map(e => `<div class="topic st-${e.mastery === null ? 'early' : e.mastery < 45 ? 'weak' : 'developing'}">
    <div class="topic-head"><b>${esc(e.chapter)}</b><span>${e.hours_left} h left</span></div>
    <small>${esc(e.subject)}${e.why.length ? ' · ' + esc(e.why.join(' · ')) : ''}</small>
    ${e.do_first.length ? `<p>Do first: ${esc(e.do_first.join(', '))}</p>` : ''}</div>`).join('');
  $('plannerBody').innerHTML = `
    <div class="strip"><div><strong>${p.days_left}</strong><span>days left</span></div>
      <div><strong>${p.hours_available}</strong><span>hours available</span></div>
      <div><strong>${p.hours_needed}</strong><span>hours needed</span></div></div>
    <div class="topic st-${st}" style="margin-top:14px"><div class="topic-head"><b>${label}</b><span>${pct}% chance to finish</span></div>
      <small>${need}${esc(pace)}${burn}</small>
      <div class="bar"><i style="width:${Math.max(2, pct)}%"></i></div></div>
    <h3 class="panel-title gap">Study next</h3>${next || '<p class="empty">Every chapter has reached the target.</p>'}
    <p class="muted explanatory">Hours per chapter are rough defaults in syllabus.py. Edit them to match you.</p>`;
}

async function load() {
  try {
    const {plan} = await api('/api/jee/plan?today=' + todayISO());
    render(plan);
  } catch (e) { $('plannerBody').innerHTML = `<p class="empty">Planner unavailable: ${esc(e.message)}</p>`; }
}

async function loadSettings() {
  try {
    const {settings} = await api('/api/jee/settings');
    $('pExam').value = settings.exam_date; $('pHours').value = settings.hours_per_day; markHours();
  } catch (e) {}
}

document.addEventListener('click', ev => {
  const b = ev.target.closest('[data-hours]');
  if (b) { $('pHours').value = b.dataset.hours; markHours(); }
});
$('pHours').addEventListener('input', markHours);
$('pSave').addEventListener('click', async () => {
  const msg = $('pMsg'); msg.style.color = ''; msg.textContent = '';
  try {
    await api('/api/jee/settings', {method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({exam_date: $('pExam').value, hours_per_day: Number($('pHours').value)})});
    msg.textContent = 'Saved'; setTimeout(() => msg.textContent = '', 2500); load();
  } catch (e) { msg.textContent = e.message; msg.style.color = '#ffb4ab'; }
});
// reload whenever jee.js redraws the "today" strip (after a session is saved or deleted)
new MutationObserver(() => { clearTimeout(timer); timer = setTimeout(load, 300); })
  .observe($('todayStrip'), {childList: true});

loadSettings().then(load);
window.addEventListener('jee-refresh', load);
})();
