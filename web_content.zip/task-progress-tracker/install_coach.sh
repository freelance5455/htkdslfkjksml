set -e

cat > backend/jee_coach.py <<'EOF'
"""Rule-based coach: answers from the app's own numbers. No language model, nothing invented."""
import re
from datetime import date, timedelta

import jee_engine
import syllabus

STATUS = {"weak": "weak", "developing": "developing", "strong": "strong",
          "early": "too few questions yet", "studied": "studied, no questions yet",
          "untouched": "not started"}
HELP = ("I can answer from your own data. Try:\n"
        "- What should I study today?\n- How am I doing? / Will I finish in time?\n"
        "- What are my weak topics?\n- What should I revise?\n"
        "- What mistakes do I make most?\n- How is Physics going?\n"
        "- Or just name a chapter, e.g. Electrostatics")


def _has(text, *stems):
    return any(s in text for s in stems)


def _find_chapter(text):
    words = set(re.findall(r"[a-z0-9]+", text))
    best, best_key = None, (0, 0.0)
    for chapters in syllabus.SYLLABUS.values():
        for name in chapters:
            parts = [w for w in re.findall(r"[a-z0-9]+", name.lower()) if len(w) >= 4]
            score = sum(1 for w in parts if w in words)
            key = (score, score / len(parts) if parts else 0.0)
            if score and key > best_key:
                best, best_key = name, key
    return best


def _next(ins, plan):
    lines = []
    due = ins["revision_due"][:2]
    if due:
        lines.append("Revise first (fading): " + ", ".join(
            f"{e['chapter']} ({round(e['retention'] * 100)}% retained)" for e in due))
    if not plan["next_up"]:
        lines.append("Every chapter has reached the target.")
    else:
        lines.append("Study next:")
        for i, e in enumerate(plan["next_up"][:3], 1):
            bits = [f"{e['hours_left']:g} h left"] + e["why"]
            line = f"{i}. {e['chapter']} ({e['subject']}): " + ", ".join(bits)
            if e["do_first"]:
                line += f". Do first: {', '.join(e['do_first'])}"
            lines.append(line)
    lines.append("Log your session afterwards so the plan updates.")
    return "\n".join(lines)


def _progress(ins, plan):
    verdict = {"on_track": "on track", "tight": "tight", "behind": "behind"}[plan["verdict"]]
    text = (f"{plan['days_left']} days to your exam at {plan['hours_per_day']:g} h/day gives "
            f"{plan['hours_available']:g} h. About {plan['hours_needed']:g} h of work remain, so you are "
            f"{verdict} ({round(plan['p_on_time'] * 100)}% chance to finish).")
    if plan["pace_needed"] is not None:
        text += f" You would need about {plan['pace_needed']:g} h/day."
    if plan["eta_date"]:
        exam = date.fromisoformat(ins["today"]) + timedelta(days=plan["days_left"])
        text += f" At your current pace you finish around {plan['eta_date']}"
        text += ", which is after your exam." if plan["eta_date"] > exam.isoformat() else "."
    else:
        text += " Log sessions with questions to get a finish date."
    t = ins["today_totals"]
    text += f"\nToday: {t['minutes']} min, {t['attempted']} questions, {t['correct']} correct."
    if ins["week_accuracy"] is not None:
        text += f" Last 7 days accuracy: {ins['week_accuracy']}%."
    return text


def _weak(ins):
    if not ins["weak"]:
        return "No weak topics yet. Log sessions with questions and they will appear here."
    lines = ["Your weakest chapters:"]
    for e in ins["weak"][:3]:
        lines.append(f"- {e['chapter']} ({e['subject']}): {e['mastery']}%. {e['advice']}")
    return "\n".join(lines)


def _revise(ins):
    if not ins["revision_due"]:
        return "Nothing is fading yet. Chapters show up here when retention drops under 50%."
    lines = ["Revise these, they are fading:"]
    for e in ins["revision_due"]:
        lines.append(f"- {e['chapter']}: {round(e['retention'] * 100)}% retained, "
                     f"not practised for {e['days_since']} days")
    return "\n".join(lines)


def _mistakes(ins):
    mix = ins["mistake_mix"]
    if not mix["total"]:
        return "No wrong answers logged in the last 30 days."
    order = sorted(((k, v) for k, v in mix["counts"].items() if v), key=lambda kv: -kv[1])
    lines = ["Mistakes in the last 30 days:"]
    for k, v in order:
        lines.append(f"- {k}: {v} ({round(100 * v / mix['total'])}%)")
    lines.append(jee_engine.ADVICE[order[0][0]])
    return "\n".join(lines)


def _subject(ins, name):
    s = ins["subjects"][name]
    text = f"{name}: {s['started']} of {s['chapters']} chapters started"
    text += f", average mastery {s['avg_mastery']}%." if s["avg_mastery"] is not None else ", no scores yet."
    tested = [e for e in ins["chapters"] if e["subject"] == name and "mastery" in e]
    if tested:
        low = min(tested, key=lambda e: e["mastery"])
        text += f" Lowest: {low['chapter']} at {low['mastery']}%."
    return text


def _chapter(ins, name):
    e = next(c for c in ins["chapters"] if c["chapter"] == name)
    if e["status"] == "untouched":
        return f"{name}: not started. Log a session with questions to get a score."
    if "mastery" not in e:
        return f"{name}: {e['minutes']} min studied but no questions yet. Do a question set to get a score."
    when = "today" if e["days_since"] == 0 else f"{e['days_since']} days ago"
    return (f"{name}: mastery {e['mastery']}% ({STATUS[e['status']]}). {e['correct']}/{e['attempted']} correct, "
            f"last practised {when}, {round(e['retention'] * 100)}% retained.\n{e['advice']}")


def answer(message, ins, plan):
    text = message.lower().strip()[:300]
    if not text:
        return {"intent": "help", "reply": HELP}
    chapter = _find_chapter(text)
    if chapter:
        return {"intent": "chapter", "reply": _chapter(ins, chapter)}
    if _has(text, "weak", "worst", "struggl"):
        return {"intent": "weak", "reply": _weak(ins)}
    if _has(text, "revis", "forget", "fading", "retain"):
        return {"intent": "revise", "reply": _revise(ins)}
    if _has(text, "mistake", "error", "wrong"):
        return {"intent": "mistakes", "reply": _mistakes(ins)}
    if _has(text, "progress", "how am i", "doing", "on track", "behind", "finish", "eta",
            "exam", "days left", "deadline", "hours", "ready"):
        return {"intent": "progress", "reply": _progress(ins, plan)}
    for name in syllabus.SYLLABUS:
        if name.lower()[:4] in text:
            return {"intent": "subject", "reply": _subject(ins, name)}
    if _has(text, "next", "today", "study", "focus", "plan", "start", "priority", "should"):
        return {"intent": "next", "reply": _next(ins, plan)}
    return {"intent": "help", "reply": HELP}
EOF

python3 - <<'EOF'
def patch(path, pairs):
    s = open(path).read()
    for old, new in pairs:
        assert s.count(old) == 1, f"{path}: layout differs near: {old[:60]!r}"
        s = s.replace(old, new)
    open(path, "w").write(s)
    print(path, "patched")

patch("backend/jee_api.py", [
    ("import jee_plan\n", "import jee_plan\nimport jee_coach\n"),
    ('        if path == "/api/jee/weightage":\n            return h.send_json(200, {"weightage": jee_data.save_weightage(db, payload.get("values"))})\n',
     '        if path == "/api/jee/coach":\n'
     '            _apply_importance(db)\n'
     '            today = payload.get("today") or date.today().isoformat()\n'
     '            date.fromisoformat(today)\n'
     '            sessions = jee_data.all_sessions(db)\n'
     '            ins = jee_engine.insights(sessions, today)\n'
     '            plan = jee_plan.build(sessions, jee_data.get_settings(db), today, jee_data.get_baseline(db))\n'
     '            return h.send_json(200, jee_coach.answer(str(payload.get("message") or ""), ins, plan))\n'
     '        if path == "/api/jee/weightage":\n            return h.send_json(200, {"weightage": jee_data.save_weightage(db, payload.get("values"))})\n'),
])

patch("web/jee.html", [
    ('<section class="section-head"><div><p class="eyebrow">LOG</p>',
     """<section class="section-head"><div><p class="eyebrow">COACH</p><h2>Ask your coach</h2></div></section>
<section class="panel">
  <div id="coachLog" class="coach-log"></div>
  <div id="coachChips" class="chips gap"></div>
  <div class="coach-input"><input id="coachText" type="text" placeholder="Ask about your plan..." maxlength="200" autocomplete="off"><button id="coachSend" class="primary-btn">Send</button></div>
</section>

<section class="section-head"><div><p class="eyebrow">LOG</p>"""),
    ('<script src="weightage.js"></script>', '<script src="weightage.js"></script>\n<script src="coach.js"></script>'),
])
EOF

cat >> web/jee.css <<'EOF'

/* coach chat */
.coach-log{display:grid;gap:8px;max-height:46vh;overflow-y:auto;margin-bottom:6px}
.msg{padding:10px 12px;border-radius:14px;font-size:.88rem;line-height:1.45;white-space:pre-wrap}
.msg.you{justify-self:end;background:var(--accent);color:#0b1726;max-width:85%}
.msg.coach{justify-self:start;background:var(--panel2);border:1px solid var(--line);max-width:94%}
.coach-input{display:flex;gap:8px;margin-top:10px}
.coach-input input{flex:1;min-width:0;background:#0c1525;border:1px solid #31435d;border-radius:11px;padding:11px 12px;color:var(--text);font:inherit}
.coach-input .primary-btn{margin-top:0;width:auto;padding:0 18px}
EOF

cat > web/coach.js <<'EOF'
'use strict';
(() => {
const $ = id => document.getElementById(id);
const todayISO = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
const QUICK = ['What should I study today?', 'How am I doing?', 'What are my weak topics?', 'What should I revise?', 'What mistakes do I make most?'];

function add(who, text) {
  const d = document.createElement('div');
  d.className = 'msg ' + who;
  d.textContent = text;
  $('coachLog').appendChild(d);
  $('coachLog').scrollTop = $('coachLog').scrollHeight;
}

async function ask(text) {
  text = text.trim();
  if (!text) return;
  add('you', text);
  $('coachText').value = '';
  try {
    const res = await fetch('/api/jee/coach', {method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({message: text, today: todayISO()})});
    const data = await res.json().catch(() => ({}));
    add('coach', res.ok ? data.reply : (data.error || 'Something went wrong.'));
  } catch (e) { add('coach', 'Could not reach the server.'); }
}

$('coachChips').innerHTML = QUICK.map(q => `<button type="button" class="chip-btn" data-q="${q}">${q}</button>`).join('');
$('coachChips').addEventListener('click', ev => {
  const b = ev.target.closest('[data-q]');
  if (b) ask(b.dataset.q);
});
$('coachSend').addEventListener('click', () => ask($('coachText').value));
$('coachText').addEventListener('keydown', ev => { if (ev.key === 'Enter') ask($('coachText').value); });
add('coach', 'Hi! I read your plan and scores to answer. Tap a question below, type your own, or name a chapter like "Electrostatics".');
})();
EOF

echo "Done. Restart the server: python server.py"
