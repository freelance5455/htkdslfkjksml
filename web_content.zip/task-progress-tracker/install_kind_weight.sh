set -e

cat >> backend/jee_data.py <<'EOF'


# ---- past-paper weightage: average questions per paper, per chapter ----
def get_weightage(con):
    con.execute("CREATE TABLE IF NOT EXISTS jee_weightage "
                "(chapter TEXT PRIMARY KEY, avg_questions REAL NOT NULL)")
    return {r[0]: r[1] for r in con.execute("SELECT chapter, avg_questions FROM jee_weightage")}


def save_weightage(con, values):
    if not isinstance(values, dict):
        raise ValueError("values must be an object")
    known = {c for chs in syllabus.SYLLABUS.values() for c in chs}
    clean = {}
    for chapter, v in values.items():
        if chapter not in known:
            raise ValueError(f"Unknown chapter: {chapter}")
        if v is None or v == "":
            continue
        try:
            v = float(v)
        except (TypeError, ValueError):
            raise ValueError("Weightage must be a number.")
        if not 0 <= v <= 50:
            raise ValueError("Weightage must be between 0 and 50.")
        clean[chapter] = v
    get_weightage(con)
    con.execute("DELETE FROM jee_weightage")
    con.executemany("INSERT INTO jee_weightage (chapter, avg_questions) VALUES (?, ?)", clean.items())
    con.commit()
    return clean


def importance_map(con):
    """Factor 0.6 (rarely asked) to 1.1 (most asked); chapters left blank stay at 1.0."""
    w = get_weightage(con)
    top = max(w.values(), default=0)
    return {c: round(0.6 + 0.5 * v / top, 3) for c, v in w.items()} if top > 0 else {}
EOF

python3 - <<'EOF'
def patch(path, pairs):
    s = open(path).read()
    for old, new in pairs:
        assert s.count(old) == 1, f"{path}: layout differs near: {old[:60]!r}"
        s = s.replace(old, new)
    open(path, "w").write(s)
    print(path, "patched")

patch("backend/jee_data.py", [
    ('ERR_FIELDS = ("concept_err", "calculation_err", "silly_err", "time_err")\n',
     'ERR_FIELDS = ("concept_err", "calculation_err", "silly_err", "time_err")\n'
     'KINDS = ("learn", "revise", "practice", "mock")\n'),
    ('    con.execute("CREATE INDEX IF NOT EXISTS idx_jee_date ON jee_sessions(date)")\n    con.commit()\n',
     '    con.execute("CREATE INDEX IF NOT EXISTS idx_jee_date ON jee_sessions(date)")\n'
     '    cols = [r[1] for r in con.execute("PRAGMA table_info(jee_sessions)")]\n'
     '    if "kind" not in cols:\n'
     '        con.execute("ALTER TABLE jee_sessions ADD COLUMN kind TEXT NOT NULL DEFAULT \'practice\'")\n'
     '    con.commit()\n'),
    ('''    notes = str(p.get("notes") or "")[:300]
    cur = con.execute("""
        INSERT INTO jee_sessions (date, subject, chapter, minutes, attempted,
            correct, concept_err, calculation_err, silly_err, time_err, notes)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
        (day, subject, chapter, minutes, attempted, correct, *errs, notes))
''', '''    notes = str(p.get("notes") or "")[:300]
    kind = p.get("kind") or "practice"
    if kind not in KINDS:
        raise ValueError("Unknown session type.")
    cur = con.execute("""
        INSERT INTO jee_sessions (date, subject, chapter, minutes, attempted,
            correct, concept_err, calculation_err, silly_err, time_err, notes, kind)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
        (day, subject, chapter, minutes, attempted, correct, *errs, notes, kind))
'''),
])

patch("backend/jee_api.py", [
    ('def handle_get(h, parsed):',
     'def _apply_importance(db):\n'
     '    try:\n'
     '        import tae\n'
     '    except ImportError:\n'
     '        return\n'
     '    tae.IMPORTANCE = jee_data.importance_map(db)\n\n\n'
     'def handle_get(h, parsed):'),
    ('        if path == "/api/jee/insights":\n',
     '        if path == "/api/jee/insights":\n            _apply_importance(db)\n'),
    ('        if path == "/api/jee/plan":\n',
     '        if path == "/api/jee/weightage":\n'
     '            return h.send_json(200, {"weightage": jee_data.get_weightage(db)})\n'
     '        if path == "/api/jee/plan":\n            _apply_importance(db)\n'),
    ('        if path == "/api/jee/baseline":\n            return h.send_json(200, {"baseline": jee_data.save_baseline(db, payload.get("levels"))})\n',
     '        if path == "/api/jee/weightage":\n'
     '            return h.send_json(200, {"weightage": jee_data.save_weightage(db, payload.get("values"))})\n'
     '        if path == "/api/jee/baseline":\n            return h.send_json(200, {"baseline": jee_data.save_baseline(db, payload.get("levels"))})\n'),
])

patch("backend/tae.py", [
    ('''def revision_score(sessions):
    days = sorted({_day(s) for s in sessions if s["attempted"] > 0})
    revisions = sum(1 for a, b in zip(days, days[1:]) if (b - a).days >= REVISION_GAP_DAYS)
    return min(1.0, revisions / REVISIONS_PLANNED)
''', '''def revision_score(sessions):
    """Revisions = 'revise' sessions + practice days REVISION_GAP_DAYS or more after the previous one."""
    days = sorted({_day(s) for s in sessions if s["attempted"] > 0})
    gaps = {b for a, b in zip(days, days[1:]) if (b - a).days >= REVISION_GAP_DAYS}
    revised = {_day(s) for s in sessions if s.get("kind") == "revise"}
    return min(1.0, len(gaps | revised) / REVISIONS_PLANNED)
'''),
])

patch("web/jee.js", [
    ("const form = { subject: null, chapter: null, err:",
     "const form = { subject: null, chapter: null, kind: 'practice', err:"),
    ("function renderSteppers() {",
     """const KINDS = [['learn','Learn'],['revise','Revise'],['practice','Practice'],['mock','Mock']];
const KIND_LABEL = Object.fromEntries(KINDS);
function renderKinds() {
  $('kindChips').innerHTML = KINDS.map(([k, n]) =>
    `<button type="button" class="chip-btn" data-kind="${k}" aria-pressed="${k === form.kind}">${n}</button>`).join('');
}
function renderSteppers() {"""),
    ("  if (t.dataset.subject) { form.subject",
     "  if (t.dataset.kind) { form.kind = t.dataset.kind; renderKinds(); }\n  else if (t.dataset.subject) { form.subject"),
    ("silly_err: form.err.silly, time_err: form.err.time, notes: $('fNotes').value.trim()};",
     "silly_err: form.err.silly, time_err: form.err.time, notes: $('fNotes').value.trim(), kind: form.kind};"),
    ("renderSteppers(); updateHint();\n    refresh();",
     "renderKinds(); renderSteppers(); updateHint();\n    refresh();\n    window.addEventListener('jee-refresh', refresh);"),
    ("· ${esc(s.subject)} · ${s.minutes}m",
     "· ${esc(s.subject)} · ${KIND_LABEL[s.kind] || 'Practice'} · ${s.minutes}m"),
])

patch("web/jee.html", [
    ('<div class="field"><label>Subject</label>',
     '<div class="field"><label>Type</label><div id="kindChips" class="chips"></div></div>\n  <div class="field gap"><label>Subject</label>'),
    ('<section class="section-head"><div><p class="eyebrow">BASELINE</p>',
     """<section class="section-head"><div><p class="eyebrow">PAST PAPERS</p><h2>Chapter weightage</h2></div></section>
<div id="weightBox"></div>
<section class="panel">
  <p class="muted explanatory">For each chapter, enter the average number of questions it gets per paper (from past papers). Leave blank if unknown. Frequently asked chapters then need a higher mastery to count as ready.</p>
  <button id="weightSave" class="primary-btn">Save weightage</button>
  <p id="weightMsg" class="status" aria-live="polite"></p>
</section>

<section class="section-head"><div><p class="eyebrow">BASELINE</p>"""),
    ('<script src="baseline.js"></script>', '<script src="baseline.js"></script>\n<script src="weightage.js"></script>'),
])
EOF

cat > web/weightage.js <<'EOF'
'use strict';
(() => {
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

async function api(path, opts) {
  const res = await fetch(path, opts);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

function updateCounts() {
  document.querySelectorAll('#weightBox details').forEach(d => {
    const n = [...d.querySelectorAll('input')].filter(i => i.value !== '').length;
    d.querySelector('summary span').textContent = n ? `${n} filled` : 'none filled';
  });
}

async function init() {
  try {
    const [{syllabus}, {weightage}] = await Promise.all([api('/api/jee/syllabus'), api('/api/jee/weightage')]);
    $('weightBox').innerHTML = Object.entries(syllabus).map(([subject, chapters]) => {
      const rows = chapters.map(c => `<div class="chap"><div class="chap-top">
        <span style="color:var(--text);font-weight:500;flex:1">${esc(c)}</span>
        <input type="number" inputmode="decimal" min="0" max="50" step="0.1" data-ch="${esc(c)}"
          value="${weightage[c] ?? ''}" placeholder="-" style="width:28%"></div></div>`).join('');
      return `<details class="subject"><summary><b>${esc(subject)}</b><span></span></summary><div class="chap-list">${rows}</div></details>`;
    }).join('');
    updateCounts();
    $('weightBox').addEventListener('input', updateCounts);
  } catch (e) { $('weightBox').innerHTML = `<section class="panel"><p class="empty">Could not load: ${esc(e.message)}</p></section>`; }
}

$('weightSave').addEventListener('click', async () => {
  const msg = $('weightMsg'); msg.style.color = ''; msg.textContent = '';
  const values = {};
  document.querySelectorAll('#weightBox input').forEach(i => { values[i.dataset.ch] = i.value === '' ? null : Number(i.value); });
  try {
    await api('/api/jee/weightage', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({values})});
    msg.textContent = 'Saved'; setTimeout(() => msg.textContent = '', 2500);
    window.dispatchEvent(new Event('jee-refresh'));
  } catch (e) { msg.textContent = e.message; msg.style.color = '#ffb4ab'; }
});

init();
})();
EOF

echo "Done. Restart the server: python server.py"
