
'use strict';

(() => {
  const $ = id => document.getElementById(id);

  function escapeHTML(value) {
    return String(value ?? '').replace(/[&<>"']/g, c => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;',
      '"': '&quot;', "'": '&#39;'
    }[c]));
  }

  function minutesLabel(value) {
    const minutes = Number(value) || 0;
    const hours = Math.floor(minutes / 60);
    const remainder = Math.round(minutes % 60);
    return hours ? `${hours}h ${remainder}m` : `${remainder}m`;
  }

  function metric(label, value) {
    return `<div class="analysis-metric">
      <span>${escapeHTML(label)}</span>
      <strong>${escapeHTML(value)}</strong>
    </div>`;
  }

  function showMessage(message, isError = false) {
    const el = $('analysisStatus');
    el.textContent = message;
    el.classList.toggle('error', isError);
  }

  function renderAnalysis(data) {
    const tasks = data.tasks || [];

    $('analysisDate').textContent = data.date;
    $('analysisMetrics').innerHTML =
      metric('Recorded time', minutesLabel(data.total_actual_minutes)) +
      metric('Sessions', data.total_sessions) +
      metric('Activities', data.task_count) +
      metric('Completed units', tasks.reduce(
        (sum, task) => sum + (Number(task.completed_units) || 0), 0
      ));

    $('analysisChart').innerHTML = tasks.map(task => {
      const target = task.domain === 'JEE' ? 240 :
        task.domain === 'Volleyball' ? 45 : 0;
      const actual = Number(task.actual_minutes) || 0;
      const percent = target > 0 ? Math.min(100, actual / target * 100) : 0;
      const width = target > 0 ? Math.min(100, actual / target * 100) : 0;

      return `<div class="analysis-bar-row">
        <div class="analysis-bar-label">
          <span>${escapeHTML(task.task_name)}</span>
          <span>${minutesLabel(actual)}${target ? ` / ${target}m` : ''}</span>
        </div>
        <div class="analysis-bar-track">
          <div class="analysis-bar-fill ${actual >= target && target > 0 ? 'over-target' : ''}"
               style="width:${width}%"></div>
        </div>
        <small class="muted">${target ? `${Math.round(percent)}% of the default target` : 'No target configured for this activity'}</small>
      </div>`;
    }).join('') || '<p class="muted">No activity recorded for this day.</p>';

    $('analysisTasks').innerHTML = tasks.map(task =>
      `<div class="analysis-task">
        <h3>${escapeHTML(task.task_name)}</h3>
        <p>Category: ${escapeHTML(task.category || 'Uncategorised')}</p>
        <p>Time: ${minutesLabel(task.actual_minutes)} · Sessions: ${Number(task.sessions) || 0}</p>
        <p>Completed units: ${Number(task.completed_units) || 0}</p>
      </div>`
    ).join('') || '<p class="muted">No task details available.</p>';

    const conclusions = [];

    if (!tasks.length) {
      conclusions.push(['No recorded activity',
        'There is no observation data for this date.']);
    } else {
      conclusions.push(['Recorded activity',
        `${data.task_count} activities and ${data.total_sessions} sessions were recorded.`]);

      const longest = [...tasks].sort(
        (a, b) => b.actual_minutes - a.actual_minutes
      )[0];

      if (longest) {
        conclusions.push(['Most time recorded',
          `${longest.task_name} accounts for the most recorded minutes that day.`]);
      }

      const noUnits = tasks.filter(
        task => Number(task.completed_units) === 0
      );

      if (noUnits.length) {
        conclusions.push(['Activity data incomplete?',
          'Some activities have zero completed units recorded. This may mean units were not entered, not necessarily that no progress occurred.']);
      }
    }

    $('analysisConclusions').innerHTML = conclusions.map(([title, body]) =>
      `<div class="analysis-conclusion">
        <strong>${escapeHTML(title)}</strong>
        ${escapeHTML(body)}
      </div>`
    ).join('');

    showMessage(data.has_data
      ? 'Analysis generated from saved observations. No AI was used.'
      : 'No observation data exists for this date yet.');
  }

  async function loadAnalysis(day) {
    showMessage('Loading daily analytics…');
    $('analysisDate').textContent = day;
    $('analysisMetrics').innerHTML = '';
    $('analysisChart').innerHTML = '';
    $('analysisTasks').innerHTML = '';
    $('analysisConclusions').innerHTML = '';

    try {
      const response = await fetch(
        `/api/analytics/daily?date=${encodeURIComponent(day)}`,
        { cache: 'no-store' }
      );

      const result = await response.json();
      if (!response.ok) {
        throw new Error(result.error || 'Analytics request failed.');
      }

      renderAnalysis(result.analytics);
    } catch (error) {
      showMessage(error.message || 'Could not load daily analytics.', true);
    }
  }

  function bindHistory() {
    const history = $('historyList');
    if (!history) return;

    history.addEventListener('click', event => {
      const row = event.target.closest('[data-analysis-date]');
      if (!row) return;

      const day = row.dataset.analysisDate;
      if (!day) return;

      loadAnalysis(day);
      $('dailyAnalysis').scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      });
    });
  }

  window.loadDailyAnalysis = loadAnalysis;
  window.renderDailyAnalysis = renderAnalysis;

  document.addEventListener('DOMContentLoaded', bindHistory);
})();

