'use strict';
const STORAGE_KEY='daily-progress-tracker-v1';
const DEFAULT_TASKS=[
 {id:'jee',name:'JEE Preparation',subtitle:'Study time and question practice',icon:'📘',targetMinutes:240,fields:[{id:'minutes',label:'Study minutes',type:'number',min:0,max:1440,placeholder:'e.g. 180'},{id:'questions',label:'Questions attempted',type:'number',min:0,max:1000,placeholder:'e.g. 30'},{id:'correct',label:'Correct answers',type:'number',min:0,max:1000,placeholder:'e.g. 22'},{id:'revision',label:'Revision minutes',type:'number',min:0,max:1440,placeholder:'e.g. 30'}]},
 {id:'volleyball',name:'Home Volleyball + Exercise',subtitle:'Practice time and completed session',icon:'🏐',targetMinutes:45,fields:[{id:'minutes',label:'Practice minutes',type:'number',min:0,max:600,placeholder:'e.g. 45'},{id:'drills',label:'Drills completed',type:'number',min:0,max:100,placeholder:'e.g. 4'},{id:'exercise',label:'Exercise minutes',type:'number',min:0,max:300,placeholder:'e.g. 15'}]}
];
const $=id=>document.getElementById(id);
const todayISO=()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`};
const dateLabel=s=>new Date(`${s}T12:00:00`).toLocaleDateString(undefined,{weekday:'short',day:'numeric',month:'short',year:'numeric'});
function freshState(){return {version:1,targets:Object.fromEntries(DEFAULT_TASKS.map(t=>[t.id,t.targetMinutes])),records:{}}}
function load(){try{const x=JSON.parse(localStorage.getItem(STORAGE_KEY));if(x&&x.version===1&&x.records&&x.targets)return {...freshState(),...x,targets:{...freshState().targets,...x.targets}}}catch(e){}return freshState()}
let state=load(), selectedDate=todayISO(), draft={};
function recordFor(date){return state.records[date]||{tasks:{},note:''}}
function numberValue(v){const n=Number(v);return Number.isFinite(n)?Math.max(0,n):0}
function taskScore(task,entry){const target=numberValue(state.targets[task.id]);const mins=numberValue(entry?.minutes);return target>0?Math.min(100,mins/target*100):0}
function dayScore(date){const r=recordFor(date);return Math.round(DEFAULT_TASKS.reduce((sum,t)=>sum+taskScore(t,r.tasks[t.id]),0)/DEFAULT_TASKS.length)}
function saveState(){
 localStorage.setItem(STORAGE_KEY,JSON.stringify(state));
 return fetch('/api/state',{
  method:'POST',
  headers:{'Content-Type':'application/json'},
  body:JSON.stringify(state)
 }).then(response=>{
  if(!response.ok) throw new Error('SQLite save failed');
  return true;
 });
}
function renderForms(){const r=recordFor(selectedDate);$('taskForms').innerHTML=DEFAULT_TASKS.map(task=>{const e=r.tasks[task.id]||{};const fields=task.fields.map(f=>`<div class="field"><label for="${task.id}-${f.id}">${f.label}</label><input id="${task.id}-${f.id}" data-task="${task.id}" data-field="${f.id}" type="number" inputmode="numeric" min="${f.min}" max="${f.max}" placeholder="${f.placeholder}" value="${e[f.id]??''}"></div>`).join('');const score=Math.round(taskScore(task,e));return `<article class="task-card"><div class="task-title-row"><div><div class="task-name">${task.name}</div><div class="task-sub">Target: ${state.targets[task.id]} min/day</div></div><span class="task-mark">${task.icon}</span></div><div class="fields">${fields}</div><div class="task-bottom"><span class="muted">Target completion</span><div class="mini-progress"><span style="width:${score}%"></span></div><strong>${score}%</strong></div></article>`}).join('');$('dayNote').value=r.note||'';$('todayLabel').textContent=dateLabel(selectedDate);document.querySelectorAll('[data-task]').forEach(input=>input.addEventListener('input',()=>{const t=input.dataset.task,f=input.dataset.field;draft[t]??={};draft[t][f]=numberValue(input.value);const task=DEFAULT_TASKS.find(x=>x.id===t);const e={...(recordFor(selectedDate).tasks[t]||{}),...draft[t]};const score=Math.round(taskScore(task,e));const card=input.closest('.task-card');card.querySelector('.task-bottom strong').textContent=`${score}%`;card.querySelector('.mini-progress span').style.width=`${score}%`;}))}
function renderDashboard(){const dates=Object.keys(state.records).sort();const saved=dates.length;$('daysLogged').textContent=saved;const score=state.records[selectedDate]?dayScore(selectedDate):0;$('overallScore').textContent=`${score}%`;$('overallBar').style.width=`${score}%`;$('overallHint').textContent=state.records[selectedDate]?(score>=100?'All time targets met':score>=70?'Good progress—review what remains':'A partial day still counts; look at the trend'):'Log today\'s work to begin';const last7=Array.from({length:7},(_,i)=>{const d=new Date(`${selectedDate}T12:00:00`);d.setDate(d.getDate()-(6-i));return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`});const vals=last7.map(d=>state.records[d]?dayScore(d):0);const loggedVals=last7.filter(d=>state.records[d]).map(d=>dayScore(d));$('weekAverage').textContent=`${loggedVals.length?Math.round(loggedVals.reduce((a,b)=>a+b,0)/loggedVals.length):0}% avg`; $('weekChart').innerHTML=last7.map((d,i)=>`<div class="chart-day" title="${dateLabel(d)}: ${state.records[d]?vals[i]+'%':'No entry'}"><div class="chart-track"><div class="chart-fill" style="height:${state.records[d]?Math.max(2,vals[i]):0}%"></div></div><small>${new Date(`${d}T12:00:00`).toLocaleDateString(undefined,{weekday:'short'}).slice(0,2)}</small></div>`).join('');const hist=dates.filter(d=>d<=selectedDate).reverse().slice(0,5);$('historyList').innerHTML=hist.length?hist.map(d=>`<div class="history-row" data-analysis-date="${d}" tabindex="0" role="button" aria-label="Analyse ${dateLabel(d)}"><div>${dateLabel(d)}<small>${escapeHTML(state.records[d].note||'No note added')}</small></div><span class="history-score">${dayScore(d)}%</span><span class="history-open">Analyse →</span></div>`).join(''):'<p class="muted explanatory">Your saved days will appear here.</p>'}
function escapeHTML(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function render(){draft={};renderForms();renderDashboard()}
$('saveBtn').addEventListener('click',()=>{const r={tasks:{},note:$('dayNote').value.trim()};DEFAULT_TASKS.forEach(t=>{const prior=recordFor(selectedDate).tasks[t.id]||{};r.tasks[t.id]={};t.fields.forEach(f=>{const el=$(`${t.id}-${f.id}`);const raw=el.value.trim();if(raw!=='')r.tasks[t.id][f.id]=numberValue(raw);else if(prior[f.id]!==undefined){} });}); // Re-read the current form values directly, preserving empty fields as absent.
 DEFAULT_TASKS.forEach(t=>{t.fields.forEach(f=>{const el=$(`${t.id}-${f.id}`);if(el.value.trim()!=='')r.tasks[t.id][f.id]=numberValue(el.value);});const correct=r.tasks[t.id].correct,attempted=r.tasks[t.id].questions;if(correct!==undefined&&attempted!==undefined&&correct>attempted){r.tasks[t.id].correct=attempted;}});state.records[selectedDate]=r;saveState();render();$('saveStatus').textContent=`Saved ${dateLabel(selectedDate)} on this device.`;setTimeout(()=>$('saveStatus').textContent='',3500)});
$('todayBtn').addEventListener('click',()=>{selectedDate=todayISO();render()});
$('settingsBtn').addEventListener('click',()=>{ $('targetFields').innerHTML=DEFAULT_TASKS.map(t=>`<div class="target-field"><label for="target-${t.id}">${t.name}<small class="task-sub">minutes per day</small></label><input id="target-${t.id}" type="number" inputmode="numeric" min="1" max="1440" value="${state.targets[t.id]}"></div>`).join('');$('settingsDialog').showModal()});
$('saveSettingsBtn').addEventListener('click',()=>{DEFAULT_TASKS.forEach(t=>{state.targets[t.id]=Math.max(1,Math.min(1440,numberValue($(`target-${t.id}`).value)||t.targetMinutes))});saveState();setTimeout(render,0)});
$('exportBtn').addEventListener('click',()=>{const blob=new Blob([JSON.stringify({app:'Daily Progress Tracker',version:1,exportedAt:new Date().toISOString(),...state},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`task-progress-${todayISO()}.json`;a.click();URL.revokeObjectURL(url)});
// Import is intentionally opt-in and replaces data only after explicit confirmation.
const importButton=document.createElement('button');importButton.className='ghost-btn';importButton.textContent='Import backup';importButton.style.marginTop='10px';$('exportBtn').after(importButton);importButton.addEventListener('click',()=> $('importInput').click());$('importInput').addEventListener('change',async ev=>{const file=ev.target.files?.[0];if(!file)return;try{const data=JSON.parse(await file.text());if(data.version!==1||!data.records||!data.targets)throw new Error('This does not look like a tracker backup.');if(!confirm('Import this backup and replace the current tracker data? Export your current data first if you need a backup.'))return;state={version:1,targets:{...freshState().targets,...data.targets},records:data.records};saveState();render();alert('Backup imported.')}catch(err){alert(err.message||'Could not import this file.')}finally{ev.target.value=''}});
async function initStorage(){
 try{
  const response=await fetch('/api/state',{cache:'no-store'});
  if(!response.ok) throw new Error('Could not read SQLite state');
  const data=await response.json();

  if(data.state && data.state.version===1 &&
     data.state.records && data.state.targets){
   state={
    ...freshState(),
    ...data.state,
    targets:{...freshState().targets,...data.state.targets}
   };
   localStorage.setItem(STORAGE_KEY,JSON.stringify(state));
  }else{
   const saved=await fetch('/api/state',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify(state)
   });
   if(!saved.ok) throw new Error('Could not save initial state');
  }
 }catch(error){
  console.error('SQLite initialization:',error);
 }
 render();
}
initStorage();
