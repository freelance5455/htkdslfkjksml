import sqlite3
from pathlib import Path
from datetime import date as Date

DB_PATH = Path(__file__).resolve().parent / "taskprogress.db"


def connect(db_path=DB_PATH):
    con = sqlite3.connect(str(db_path))
    con.row_factory = sqlite3.Row

    con.execute("""
        CREATE TABLE IF NOT EXISTS observations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL,
            domain TEXT NOT NULL,
            category TEXT NOT NULL,
            task_type TEXT NOT NULL,
            task_name TEXT NOT NULL,
            estimated_minutes REAL,
            actual_minutes REAL NOT NULL CHECK(actual_minutes >= 0),
            planned_units REAL CHECK(planned_units IS NULL OR planned_units >= 0),
            completed_units REAL CHECK(completed_units IS NULL OR completed_units >= 0),
            outcome TEXT,
            notes TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            CHECK(estimated_minutes IS NULL OR estimated_minutes > 0)
        )
    """)

    con.execute("""
        CREATE TABLE IF NOT EXISTS app_state (
            id INTEGER PRIMARY KEY CHECK(id = 1),
            state_json TEXT NOT NULL,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)

    con.commit()
    return con


def add_observation(
    connection, date, domain, category, task_type, task_name,
    actual_minutes, estimated_minutes=None, planned_units=None,
    completed_units=None, outcome=None, notes=None
):
    if not all(
        isinstance(v, str) and v.strip()
        for v in (date, domain, category, task_type, task_name)
    ):
        raise ValueError("Date and task labels must be non-empty.")

    Date.fromisoformat(date)

    if actual_minutes < 0:
        raise ValueError("Actual duration cannot be negative.")
    if estimated_minutes is not None and estimated_minutes <= 0:
        raise ValueError("Estimated duration must be positive.")

    for value in (planned_units, completed_units):
        if value is not None and value < 0:
            raise ValueError("Unit counts cannot be negative.")

    cur = connection.execute("""
        INSERT INTO observations (
            date, domain, category, task_type, task_name,
            estimated_minutes, actual_minutes, planned_units,
            completed_units, outcome, notes
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        date, domain.strip(), category.strip(), task_type.strip(),
        task_name.strip(), estimated_minutes, actual_minutes,
        planned_units, completed_units, outcome, notes
    ))
    connection.commit()
    return cur.lastrowid


def get_observations(connection, domain=None, category=None):
    query = "SELECT * FROM observations WHERE 1=1"
    params = []

    if domain is not None:
        query += " AND domain = ?"
        params.append(domain)
    if category is not None:
        query += " AND category = ?"
        params.append(category)

    query += " ORDER BY date, id"
    return [
        dict(row)
        for row in connection.execute(query, params).fetchall()
    ]
   
def sync_observations_from_state(connection, state):
    """Insert or update observations derived from dashboard state."""
    targets = state.get("targets", {})
    records = state.get("records", {})

    task_configs = {
        "jee": {
            "domain": "JEE",
            "category": "JEE Preparation",
            "task_type": "study",
            "task_name": "JEE Preparation",
            "target_key": "jee",
        },
        "volleyball": {
            "domain": "Volleyball",
            "category": "Home Volleyball + Exercise",
            "task_type": "practice",
            "task_name": "Home Volleyball + Exercise",
            "target_key": "volleyball",
        },
    }

    for day, day_record in records.items():
        Date.fromisoformat(day)
        tasks = day_record.get("tasks", {})

        for task_key, config in task_configs.items():
            values = tasks.get(task_key, {})
            if not isinstance(values, dict) or not values:
                continue

            minutes = float(values.get("minutes") or 0)
            questions = values.get("questions")
            drills = values.get("drills")
            correct = values.get("correct")
            revision = values.get("revision")
            exercise = values.get("exercise")
            target = float(targets.get(config["target_key"]) or 0)

            activity_values = (
                [minutes, questions, correct, revision]
                if task_key == "jee"
                else [minutes, drills, exercise]
            )
            if not any(v not in (None, "", 0, "0") for v in activity_values):
                continue

            if minutes < 0 or target < 0:
                raise ValueError("Minutes and targets cannot be negative.")

            completed_units = questions if task_key == "jee" else drills
            details = (
                f"correct={correct}; revision_minutes={revision}"
                if task_key == "jee"
                else f"exercise_minutes={exercise}"
            )
            notes = day_record.get("note", "")

            identity = (
                day, config["domain"], config["category"],
                config["task_type"], config["task_name"]
            )

            existing = connection.execute("""
                SELECT id FROM observations
                WHERE date=? AND domain=? AND category=?
                  AND task_type=? AND task_name=?
                ORDER BY id LIMIT 1
            """, identity).fetchone()

            fields = (
                target if target > 0 else None,
                minutes,
                None,
                float(completed_units)
                if completed_units not in (None, "") else None,
                details,
                notes,
            )

            if existing:
                connection.execute("""
                    UPDATE observations
                    SET estimated_minutes=?, actual_minutes=?,
                        planned_units=?, completed_units=?,
                        outcome=?, notes=?
                    WHERE id=?
                """, (*fields, existing["id"]))
            else:
                connection.execute("""
                    INSERT INTO observations (
                        date, domain, category, task_type, task_name,
                        estimated_minutes, actual_minutes, planned_units,
                        completed_units, outcome, notes
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (*identity, *fields))

    connection.commit()

def close(connection):
    connection.close()
