# Daily Progress Tracker — MVP 1

A mobile-first local web app for tracking JEE preparation and home volleyball/exercise. No account, backend, API key, or AI call is used in this first version.

## Run on Android
1. Download and extract `task-progress-tracker.zip`.
2. Open the extracted folder in Spck Editor.
3. Open `index.html` using Spck's preview/local web server.
4. Enter sample values and press **Save today's progress**.
5. Close and reopen the page to confirm the browser preserves your data.

If using a local server in Termux, go into this folder and run `python -m http.server 8080`; then open `http://127.0.0.1:8080` in your browser. Keep the server running while using the app.

## What's included
- Daily entry for JEE and volleyball/exercise
- Editable minute targets
- Daily completion score, 7-day chart, recent history
- JSON export/import backup
- Local browser storage (`localStorage`)

## Important limitations
- This MVP is not yet an installed native Android app and has no offline service worker.
- Browser data can be lost if site data is cleared; export backups regularly.
- The current score measures target-minute completion only, not learning quality or skill development.
- AI and custom mathematics are deliberately not connected yet. Next step is to map your existing formulas to fields and outputs before implementing them. Cloud AI, if added later, must be opt-in and send only a selected summary.
- `localStorage` is local persistence, not encryption. Do not treat it as a secure vault.
