
import json
import sys
from pathlib import Path
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
from datetime import date

ROOT = Path(__file__).resolve().parent
WEB_DIR = ROOT / "web"
sys.path.insert(0, str(ROOT / "backend"))

import analytics  # noqa: E402
import data_layer  # noqa: E402
import jee_api  # noqa: E402

HOST = "127.0.0.1"
PORT = 8000


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(WEB_DIR), **kwargs)

    def send_json(self, status, payload):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = urlparse(self.path)

        if path.path.startswith("/api/jee/"):
            return jee_api.handle_get(self, path)

        if path.path == "/api/analytics/daily":
            params = parse_qs(path.query)
            day = params.get("date", [None])[0]

            if not day:
                return self.send_json(
                    400, {"error": "Missing date parameter"}
                )

            try:
                date.fromisoformat(day)
            except (ValueError, TypeError):
                return self.send_json(
                    400, {"error": "Invalid date; use YYYY-MM-DD"}
                )

            db = data_layer.connect()
            try:
                observations = data_layer.get_observations(db)
                result = analytics.analyze_day(observations, day)

                row = db.execute(
                    "SELECT state_json FROM app_state WHERE id=1"
                ).fetchone()

                state = json.loads(row["state_json"]) if row else {}
                targets = state.get("targets", {})

                result["targets"] = {
                    "jee": float(targets.get("jee") or 0),
                    "volleyball": float(targets.get("volleyball") or 0),
                }

                return self.send_json(200, {"analytics": result})

            except (ValueError, TypeError, KeyError) as exc:
                return self.send_json(400, {"error": str(exc)})

            finally:
                data_layer.close(db)

        if path.path == "/api/health":
            db = data_layer.connect()
            try:
                return self.send_json(200, {
                    "ok": True,
                    "database": "SQLite",
                    "date": date.today().isoformat()
                })
            finally:
                data_layer.close(db)

        if path.path == "/api/observations":
            params = parse_qs(path.query)
            domain = params.get("domain", [None])[0]
            category = params.get("category", [None])[0]

            db = data_layer.connect()
            try:
                records = data_layer.get_observations(
                    db, domain, category
                )
                return self.send_json(200, {"observations": records})
            finally:
                data_layer.close(db)

        if path.path == "/api/state":
            db = data_layer.connect()
            try:
                row = db.execute(
                    "SELECT state_json FROM app_state WHERE id=1"
                ).fetchone()

                state = json.loads(row["state_json"]) if row else None
                return self.send_json(200, {"state": state})
            finally:
                data_layer.close(db)

        return super().do_GET()

    def do_POST(self):
        path = urlparse(self.path).path

        if path.startswith("/api/jee/"):
            return jee_api.handle_post(self, path)

        if path not in ("/api/state", "/api/observations"):
            return self.send_json(
                404, {"error": "Endpoint not found"}
            )

        try:
            length = int(self.headers.get("Content-Length", "0"))

            if length <= 0 or length > 1_000_000:
                return self.send_json(
                    400, {"error": "Invalid request size"}
                )

            payload = json.loads(self.rfile.read(length))

        except (ValueError, json.JSONDecodeError):
            return self.send_json(400, {"error": "Invalid JSON"})

        db = data_layer.connect()

        try:
            if path == "/api/state":
                if not isinstance(payload, dict):
                    return self.send_json(
                        400, {"error": "State must be an object"}
                    )

                state_json = json.dumps(payload)

                db.execute("""
                    INSERT INTO app_state (id, state_json, updated_at)
                    VALUES (1, ?, CURRENT_TIMESTAMP)
                    ON CONFLICT(id) DO UPDATE SET
                        state_json=excluded.state_json,
                        updated_at=CURRENT_TIMESTAMP
                """, (state_json,))

                data_layer.sync_observations_from_state(db, payload)
                db.commit()

                return self.send_json(200, {"ok": True})

            required = (
                "date", "domain", "category", "task_type",
                "task_name", "actual_minutes"
            )

            if not isinstance(payload, dict) or any(
                key not in payload for key in required
            ):
                return self.send_json(
                    400, {"error": "Missing required observation fields"}
                )

            actual_minutes = float(payload["actual_minutes"])
            estimated = payload.get("estimated_minutes")
            planned = payload.get("planned_units")
            completed = payload.get("completed_units")

            observation_id = data_layer.add_observation(
                connection=db,
                date=payload["date"],
                domain=payload["domain"],
                category=payload["category"],
                task_type=payload["task_type"],
                task_name=payload["task_name"],
                actual_minutes=actual_minutes,
                estimated_minutes=(
                    float(estimated) if estimated not in (None, "") else None
                ),
                planned_units=(
                    float(planned) if planned not in (None, "") else None
                ),
                completed_units=(
                    float(completed) if completed not in (None, "") else None
                ),
                outcome=payload.get("outcome"),
                notes=payload.get("notes"),
            )

            return self.send_json(
                201, {"ok": True, "id": observation_id}
            )

        except (ValueError, TypeError, KeyError) as exc:
            db.rollback()
            return self.send_json(400, {"error": str(exc)})

        finally:
            data_layer.close(db)


if __name__ == "__main__":
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f"Task Progress Tracker running at http://{HOST}:{PORT}")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped.")
    finally:
        server.server_close()

