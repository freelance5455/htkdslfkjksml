"""HTTP handlers for /api/jee/*. Called from server.py."""
import json
from datetime import date

import data_layer
import jee_data
import jee_engine
import jee_plan
import jee_coach
import syllabus
from urllib.parse import parse_qs


def _apply_importance(db):
    try:
        import tae
    except ImportError:
        return
    tae.IMPORTANCE = jee_data.importance_map(db)


def handle_get(h, parsed):
    path, params = parsed.path, parse_qs(parsed.query)
    if path == "/api/jee/syllabus":
        return h.send_json(200, {"syllabus": syllabus.SYLLABUS})

    db = data_layer.connect()
    try:
        jee_data.ensure(db)
        if path == "/api/jee/settings":
            return h.send_json(200, {"settings": jee_data.get_settings(db)})
        if path == "/api/jee/baseline":
            return h.send_json(200, {"baseline": jee_data.get_baseline(db)})
        if path == "/api/jee/weightage":
            return h.send_json(200, {"weightage": jee_data.get_weightage(db)})
        if path == "/api/jee/plan":
            _apply_importance(db)
            today = params.get("today", [date.today().isoformat()])[0]
            date.fromisoformat(today)
            return h.send_json(200, {"plan": jee_plan.build(
                jee_data.all_sessions(db), jee_data.get_settings(db), today,
                jee_data.get_baseline(db))})
        if path == "/api/jee/sessions":
            limit = min(max(int(params.get("limit", ["15"])[0]), 1), 200)
            return h.send_json(200, {"sessions": jee_data.recent(db, limit)})
        if path == "/api/jee/insights":
            _apply_importance(db)
            today = params.get("today", [date.today().isoformat()])[0]
            date.fromisoformat(today)
            return h.send_json(200, {"insights": jee_engine.insights(
                jee_data.all_sessions(db), today)})
        return h.send_json(404, {"error": "Endpoint not found"})
    except (ValueError, TypeError) as exc:
        return h.send_json(400, {"error": str(exc)})
    finally:
        data_layer.close(db)


def handle_post(h, path):
    try:
        length = int(h.headers.get("Content-Length", "0"))
        if length <= 0 or length > 100_000:
            return h.send_json(400, {"error": "Invalid request size"})
        payload = json.loads(h.rfile.read(length))
        if not isinstance(payload, dict):
            raise ValueError("Body must be an object")
    except (ValueError, json.JSONDecodeError):
        return h.send_json(400, {"error": "Invalid JSON"})

    db = data_layer.connect()
    try:
        jee_data.ensure(db)
        if path == "/api/jee/coach":
            _apply_importance(db)
            today = payload.get("today") or date.today().isoformat()
            date.fromisoformat(today)
            sessions = jee_data.all_sessions(db)
            ins = jee_engine.insights(sessions, today)
            plan = jee_plan.build(sessions, jee_data.get_settings(db), today, jee_data.get_baseline(db))
            return h.send_json(200, jee_coach.answer(str(payload.get("message") or ""), ins, plan))
        if path == "/api/jee/weightage":
            return h.send_json(200, {"weightage": jee_data.save_weightage(db, payload.get("values"))})
        if path == "/api/jee/baseline":
            return h.send_json(200, {"baseline": jee_data.save_baseline(db, payload.get("levels"))})
        if path == "/api/jee/settings":
            return h.send_json(200, {"settings": jee_data.save_settings(db, payload)})
        if path == "/api/jee/session":
            return h.send_json(201, {"ok": True, "id": jee_data.add_session(db, payload)})
        if path == "/api/jee/session/delete":
            removed = jee_data.delete_session(db, payload.get("id"))
            return h.send_json(200, {"ok": True, "removed": removed})
        return h.send_json(404, {"error": "Endpoint not found"})
    except (ValueError, TypeError) as exc:
        db.rollback()
        return h.send_json(400, {"error": str(exc)})
    finally:
        data_layer.close(db)
