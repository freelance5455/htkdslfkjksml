"""Planner: joins the mastery engine with the TAE maths."""
import math
from datetime import date, timedelta

import jee_engine
import syllabus
import tae_planner as tae

TARGET_MASTERY = 70.0   # mastery that counts as "chapter done"
O_FACTOR, P_FACTOR = 0.7, 1.6   # optimistic / pessimistic hours vs likely


BASELINE_PROGRESS = {0: 0.0, 1: 0.35, 2: 0.65, 3: 0.9}   # self-rated start: none, basics, good, strong


def _progress(ins, baseline=None):
    """Tested chapters use their mastery; untested ones use the self-rated start."""
    baseline = baseline or {}
    return {e["chapter"]: BASELINE_PROGRESS[baseline.get(e["chapter"], 0)]
            if e.get("mastery") is None
            else min(1.0, e["mastery"] / TARGET_MASTERY) for e in ins["chapters"]}


def build(sessions, settings, today_iso, baseline=None):
    today = date.fromisoformat(today_iso)
    exam = date.fromisoformat(settings["exam_date"])
    hpd = float(settings["hours_per_day"])
    days_left = max(0, (exam - today).days)
    horizon = days_left * hpd

    subject = {c: s for s, chs in syllabus.SYLLABUS.items() for c in chs}
    names = list(subject)
    preds = {c: list(syllabus.PREREQS.get(c, [])) for c in names}
    for c, ps in preds.items():
        for p in ps:
            if p not in subject:
                raise ValueError(f"Unknown prerequisite '{p}' for '{c}'")
    order, depth, succs = tae.topo_order(names, preds)

    now = jee_engine.insights(sessions, today_iso)
    prev = jee_engine.insights(sessions, (today - timedelta(days=7)).isoformat())
    prog, prog_prev = _progress(now, baseline), _progress(prev, baseline)
    mastery = {e["chapter"]: e.get("mastery") for e in now["chapters"]}

    mu, sd = {}, {}
    for n in names:
        m = syllabus.HOURS.get(n, syllabus.DEFAULT_HOURS)
        mu[n], sd[n] = tae.pert(O_FACTOR * m, m, P_FACTOR * m)
    rem = {n: mu[n] * (1 - prog[n]) for n in names}
    rem_sd = {n: sd[n] * (1 - prog[n]) for n in names}

    # structure: critical chain, blocking, bottleneck
    chain, _, slack = tae.cpm(order, preds, succs, rem)
    kap = {n: tae.kappa(slack[n], max(1.0, 0.1 * chain)) for n in names}
    out_deg = {n: len(succs[n]) for n in names}
    b2 = tae.descendant_counts(order, succs)
    bott = tae.bottleneck(out_deg, b2, kap)

    # difficulty and effort
    weak = {n: 1 - prog[n] for n in names}
    diff = tae.effective_difficulty(order, preds, {n: 1 + weak[n] for n in names})
    raw_e = {n: diff[n] * rem[n] for n in names}
    e_max = max(raw_e.values()) or 1.0
    effort = {n: raw_e[n] / e_max for n in names}

    # deadlines from the exam horizon -> urgency
    _, lf, _ = tae.cpm(order, preds, succs, rem, horizon)
    tr = {n: lf[n] / hpd for n in names}
    urg = tae.urgency(tr)

    b2_max = max(1, max(b2.values()))
    impact = {n: 0.5 * b2[n] / b2_max + 0.5 * weak[n] for n in names}
    score = tae.priority(impact, urg, bott, effort, kap)

    todo = sorted((n for n in names if prog[n] < 1), key=lambda n: -score[n])
    next_up = []
    for n in todo[:5]:
        why = []
        if b2[n] >= 3:
            why.append(f"unlocks {b2[n]} later chapters")
        if kap[n] >= 0.5:
            why.append("on the critical chain")
        if mastery[n] is None:
            why.append("not tested yet")
        elif mastery[n] < 45:
            why.append(f"weak ({round(mastery[n])}%)")
        next_up.append({
            "chapter": n, "subject": subject[n], "priority": round(score[n], 3),
            "hours_left": round(rem[n], 1), "unlocks": b2[n],
            "mastery": mastery[n], "why": why,
            "do_first": [p for p in preds[n] if prog[p] < 0.5],
        })

    # feasibility (PERT, chapters studied in series)
    needed = sum(rem.values())
    sigma = sum(rem_sd.values())   # one student: estimate errors move together
    p_on = tae.on_time_probability(horizon, needed, sigma) if needed > 0 else 1.0
    verdict = "on_track" if p_on >= 0.8 else "tight" if p_on >= 0.4 else "behind"

    # rolling 7-day velocity and ETA (hours of progress per day)
    done_now = sum(mu[n] * prog[n] for n in names)
    done_prev = sum(mu[n] * prog_prev[n] for n in names)
    velocity = (done_now - done_prev) / 7.0
    eta = tae.eta_days(needed, velocity)
    eta_date = (today + timedelta(days=math.ceil(eta))).isoformat() \
        if eta is not None and eta < 3650 else None

    logged = sum(s["minutes"] for s in sessions
                 if 0 <= (today - date.fromisoformat(s["date"])).days < 7) / 60.0
    return {
        "days_left": days_left, "hours_per_day": hpd,
        "hours_available": round(horizon, 1), "hours_needed": round(needed, 1),
        "hours_sigma": round(sigma, 1), "p_on_time": round(p_on, 3),
        "verdict": verdict,
        "pace_needed": round(needed / days_left, 1) if days_left else None,
        "velocity": round(velocity, 2), "eta_date": eta_date,
        "burn_rate": round(logged / 7.0 / hpd, 2) if hpd else None,
        "chain_hours": round(chain, 1), "next_up": next_up,
    }
