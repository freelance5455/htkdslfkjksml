"""TAE planner functions: pure maths, no database.
Follows TAE document v1.0, with these deliberate changes:
  - smooth critical indicator is 2/(1+e^(S/tau)) so S=0 gives exactly 1
  - the urgency scale (tau_u) is separate from the critical-indicator scale (tau_k)
  - B1, B2 and the impact share are divided by their maximum (not n-1) so all
    terms of the priority score span 0..1
  - total spread adds every chapter's spread linearly (one student studies them
    in series and their estimate errors move together)
"""
import math
from collections import defaultdict, deque


def _exp(x):
    return math.exp(max(-60.0, min(60.0, x)))


def topo_order(nodes, preds):
    """Peeling (F4-F8). Returns order, depth, successors. Raises on a cycle (F5)."""
    indeg = {n: len(preds[n]) for n in nodes}
    succs = defaultdict(list)
    for n in nodes:
        for p in preds[n]:
            succs[p].append(n)
    depth = {n: 0 for n in nodes}
    queue = deque(n for n in nodes if indeg[n] == 0)
    order = []
    while queue:
        n = queue.popleft()
        order.append(n)
        for m in succs[n]:
            depth[m] = max(depth[m], depth[n] + 1)
            indeg[m] -= 1
            if indeg[m] == 0:
                queue.append(m)
    if len(order) != len(nodes):
        raise ValueError("Prerequisite cycle in the syllabus map")
    return order, depth, succs


def cpm(order, preds, succs, dur, horizon=None):
    """ES, EF, total, LF, slack (F10-F15). horizon overrides the project end."""
    ef = {}
    for n in order:
        ef[n] = max((ef[p] for p in preds[n]), default=0.0) + dur[n]
    total = max(ef.values(), default=0.0)
    end = total if horizon is None else horizon
    lf, ls = {}, {}
    for n in reversed(order):
        lf[n] = min((ls[s] for s in succs[n]), default=end)
        ls[n] = lf[n] - dur[n]
    return total, lf, {n: lf[n] - ef[n] for n in order}


def kappa(slack, tau):
    return min(1.0, 2.0 / (1.0 + _exp(slack / tau)))


def descendant_counts(order, succs):
    """B2: number of chapters reachable from each chapter (F20)."""
    reach = {}
    for n in reversed(order):
        s = set()
        for m in succs[n]:
            s.add(m)
            s |= reach[m]
        reach[n] = s
    return {n: len(reach[n]) for n in order}


def bottleneck(out_deg, b2, kap, w=(0.3, 0.4, 0.3)):
    d1 = max(1, max(out_deg.values()))
    d2 = max(1, max(b2.values()))
    return {i: w[0] * out_deg[i] / d1 + w[1] * b2[i] / d2 + w[2] * kap[i] for i in out_deg}


def effective_difficulty(order, preds, base, alpha=0.1):
    """c(i) = base(i) + alpha * sum of prerequisite difficulties (section 9.1)."""
    c = {}
    for n in order:
        c[n] = base[n] + alpha * sum(c[p] for p in preds[n])
    return c


def urgency(tr):
    vals = [max(v, 0.0) for v in tr.values()]
    tau = max(0.5, sum(vals) / len(vals))
    return {i: 1.0 / (1.0 + _exp((v - tau) / tau)) for i, v in tr.items()}


def priority(impact, urg, bott, effort, kap, a=(0.4, 0.2, 0.4), a5=0.15):
    return {i: a[0] * impact[i] + a[1] * urg[i] + a[2] * bott[i]
            - a5 * effort[i] * (1.0 - kap[i]) for i in impact}


def pert(o, m, p):
    return (o + 4 * m + p) / 6.0, (p - o) / 6.0


def normal_cdf(x):
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def on_time_probability(horizon, mu, sigma):
    if sigma <= 1e-9:
        return 1.0 if horizon >= mu else 0.0
    return normal_cdf((horizon - mu) / sigma)


def eta_days(remaining, velocity):
    return None if velocity <= 1e-9 else remaining / velocity
