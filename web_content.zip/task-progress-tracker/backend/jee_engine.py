"""JEE insight engine: chapter mastery, weak topics, revision due, mistake mix.

Default maths (placeholder until your TAE formulas are plugged in):
  accuracy   A = (w_correct + a) / (w_attempted + a + b)      Beta(a,b) prior,
               each session weighted by w = 0.5 ** (age_days / HALF_LIFE_DAYS)
  stability  S = BASE * (1 + ln(1 + practice_days)) * (0.5 + A)   [days]
  retention  R = exp(-days_since_last_practice / S)           forgetting curve
  confidence C = w_attempted / (w_attempted + K)
  mastery    M = 100 * A * R
  priority     = (100 - M) * (0.6 + 0.4 * C)

To use your own TAE mathematics, create tae.py next to this file with
    def score_chapter(c, today): -> dict
Any keys it returns (mastery, accuracy, retention, confidence, priority) replace
the defaults. `c` holds the chapter's raw and recency-weighted totals.
"""
import math
from datetime import date

import syllabus

HALF_LIFE_DAYS = 14.0
PRIOR_A = PRIOR_B = 2.0
BASE_STABILITY_DAYS = 5.0
CONFIDENCE_K = 8.0
REVISION_RETENTION = 0.5
MISTAKE_TYPES = ("concept", "calculation", "silly", "time")

ADVICE = {
    "concept": "Concept gaps: re-read theory and solved examples first, then do easy questions before hard ones.",
    "calculation": "Calculation slips: practise written calculation daily and keep every step on paper.",
    "silly": "Silly errors: slow down, re-read the question, check units, signs and the option you mark.",
    "time": "Time pressure: do short timed sets and skip-and-return on questions that stall.",
    "unclassified": "Tag the cause of each wrong answer so the next advice is specific.",
}

try:
    import tae  # optional, your own formulas
except ImportError:
    tae = None


def _days(a, b):
    return (date.fromisoformat(b) - date.fromisoformat(a)).days


def _collect(sessions, today):
    chapters = {}
    for s in sessions:
        age = _days(s["date"], today)
        if age < 0:
            continue  # ignore future-dated entries
        c = chapters.setdefault((s["subject"], s["chapter"]), {
            "subject": s["subject"], "chapter": s["chapter"],
            "w_attempted": 0.0, "w_correct": 0.0, "attempted": 0,
            "correct": 0, "minutes": 0.0, "days": set(), "last": s["date"],
            "w_mistakes": {k: 0.0 for k in (*MISTAKE_TYPES, "unclassified")},
            "sessions": [],
        })
        c["sessions"].append(s)
        w = 0.5 ** (age / HALF_LIFE_DAYS)
        c["w_attempted"] += w * s["attempted"]
        c["w_correct"] += w * s["correct"]
        c["attempted"] += s["attempted"]
        c["correct"] += s["correct"]
        c["minutes"] += s["minutes"]
        c["days"].add(s["date"])
        c["last"] = max(c["last"], s["date"])
        tagged = 0
        for k in MISTAKE_TYPES:
            n = s[k + "_err"]
            tagged += n
            c["w_mistakes"][k] += w * n
        c["w_mistakes"]["unclassified"] += w * max(0, s["attempted"] - s["correct"] - tagged)
    return chapters


def _default_score(c, today):
    a = (c["w_correct"] + PRIOR_A) / (c["w_attempted"] + PRIOR_A + PRIOR_B)
    t = max(0, _days(c["last"], today))
    s = BASE_STABILITY_DAYS * (1 + math.log(1 + len(c["days"]))) * (0.5 + a)
    r = math.exp(-t / s)
    conf = c["w_attempted"] / (c["w_attempted"] + CONFIDENCE_K)
    m = 100 * a * r
    return {"accuracy": a, "retention": r, "confidence": conf,
            "mastery": m, "priority": (100 - m) * (0.6 + 0.4 * conf)}


def _status(m, conf):
    if conf < 0.25:
        return "early"
    return "strong" if m >= 70 else "developing" if m >= 45 else "weak"


def _chapter_entry(c, today):
    entry = {"subject": c["subject"], "chapter": c["chapter"],
             "minutes": round(c["minutes"]), "attempted": c["attempted"],
             "correct": c["correct"], "practice_days": len(c["days"]),
             "last_date": c["last"], "days_since": max(0, _days(c["last"], today))}
    if c["attempted"] == 0:
        entry["status"] = "studied"  # time logged, no questions yet
        return entry

    score = _default_score(c, today)
    if tae is not None and hasattr(tae, "score_chapter"):
        try:
            score.update(tae.score_chapter(
                {k: v for k, v in c.items() if k != "days"}
                | {"practice_days": len(c["days"])}, today))
        except Exception as exc:  # a bug in tae.py must not break the app
            entry["tae_error"] = str(exc)[:120]

    entry.update({k: round(float(v), 3) for k, v in score.items()})
    entry["mastery"] = round(entry["mastery"], 1)
    entry["status"] = _status(entry["mastery"], entry["confidence"])

    mist = c["w_mistakes"]
    total = sum(mist.values())
    top = max(mist, key=mist.get)
    entry["dominant_mistake"] = top if total >= 1 else None
    entry["dominant_share"] = round(mist[top] / total, 2) if total >= 1 else None
    entry["advice"] = ADVICE[top] if total >= 1 else (
        "Do a focused set of 15-20 questions, then tag every mistake.")
    return entry


def insights(sessions, today):
    chapters = _collect(sessions, today)
    entries, subjects = [], {}

    for subject, names in syllabus.SYLLABUS.items():
        tested = []
        started = 0
        for name in names:
            c = chapters.get((subject, name))
            if c is None:
                entries.append({"subject": subject, "chapter": name, "status": "untouched"})
                continue
            started += 1
            e = _chapter_entry(c, today)
            entries.append(e)
            if "mastery" in e:
                tested.append(e["mastery"])
        subjects[subject] = {
            "chapters": len(names), "started": started,
            "coverage": round(100 * started / len(names)),
            "avg_mastery": round(sum(tested) / len(tested), 1) if tested else None,
            "tested": len(tested),
        }

    tested = [e for e in entries if "mastery" in e]
    weak = sorted((e for e in tested if e["mastery"] < 70),
                  key=lambda e: -e["priority"])[:5]
    due = sorted((e for e in tested if e["retention"] < REVISION_RETENTION),
                 key=lambda e: e["retention"])[:5]

    recent = [s for s in sessions if 0 <= _days(s["date"], today) < 30]
    mix = {k: sum(s[k + "_err"] for s in recent) for k in MISTAKE_TYPES}
    wrong = sum(s["attempted"] - s["correct"] for s in recent)
    mix["unclassified"] = max(0, wrong - sum(mix.values()))
    mix_total = sum(mix.values())

    week = [s for s in sessions if 0 <= _days(s["date"], today) < 7]
    w_att = sum(s["attempted"] for s in week)
    day_rows = [s for s in sessions if s["date"] == today]

    return {
        "today": today,
        "engine": "TAE plug-in" if tae is not None and hasattr(tae, "score_chapter") else "default",
        "today_totals": {
            "minutes": round(sum(s["minutes"] for s in day_rows)),
            "attempted": sum(s["attempted"] for s in day_rows),
            "correct": sum(s["correct"] for s in day_rows)},
        "week_accuracy": round(100 * sum(s["correct"] for s in week) / w_att) if w_att else None,
        "subjects": subjects,
        "chapters": entries,
        "weak": weak,
        "revision_due": due,
        "mistake_mix": {"counts": mix, "total": mix_total, "days": 30},
    }
