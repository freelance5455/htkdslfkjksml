"""Task Analyser Engine (TAE) — analytics foundation.

Pure calculations for daily summaries and task-system mathematics.
No database writes or hidden mutable state.
"""

from collections import defaultdict
from datetime import date
from math import isfinite


def validate_date(day):
    """Validate and return an ISO-format calendar date."""
    if not isinstance(day, str):
        raise ValueError("Date must be a string in YYYY-MM-DD format.")
    try:
        date.fromisoformat(day)
    except ValueError as exc:
        raise ValueError("Invalid date; use YYYY-MM-DD.") from exc
    return day


def validate_duration(value, name="duration", allow_zero=False):
    """Validate a finite, non-negative duration."""
    try:
        number = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be a number.") from exc

    minimum_invalid = number < 0 if allow_zero else number <= 0
    if not isfinite(number) or minimum_invalid:
        rule = "non-negative" if allow_zero else "greater than zero"
        raise ValueError(f"{name} must be {rule}.")
    return number


def analyze_day(observations, day):
    """Summarize saved observations for one calendar day."""
    validate_date(day)

    tasks = defaultdict(lambda: {
        "domain": "",
        "category": "",
        "task_name": "",
        "sessions": 0,
        "actual_minutes": 0.0,
        "completed_units": 0.0,
        "unit_sessions": 0,
    })

    for item in observations:
        if item.get("date") != day:
            continue

        key = (
            item.get("domain", ""),
            item.get("category", ""),
            item.get("task_name", ""),
        )
        task = tasks[key]
        task["domain"], task["category"], task["task_name"] = key
        task["sessions"] += 1
        task["actual_minutes"] += float(item.get("actual_minutes") or 0)

        completed = item.get("completed_units")
        if completed is not None:
            task["completed_units"] += float(completed)
            task["unit_sessions"] += 1

    task_list = []
    for task in tasks.values():
        task["actual_minutes"] = round(task["actual_minutes"], 2)
        task["actual_hours"] = round(task["actual_minutes"] / 60, 2)
        task["completed_units"] = round(task["completed_units"], 2)
        task_list.append(task)

    task_list.sort(key=lambda task: (
        task["domain"], task["task_name"]
    ))
    total_minutes = sum(task["actual_minutes"] for task in task_list)

    return {
        "date": day,
        "has_data": bool(task_list),
        "task_count": len(task_list),
        "total_sessions": sum(task["sessions"] for task in task_list),
        "total_actual_minutes": round(total_minutes, 2),
        "total_actual_hours": round(total_minutes / 60, 2),
        "tasks": task_list,
    }


def dependency_analysis(task_ids, dependencies):
    """Analyze a directed task graph.

    dependencies contains (prerequisite, dependent) pairs.
    Returns a topological order, dependency layers, and cycle status.
    """
    ids = list(task_ids)
    if len(set(ids)) != len(ids):
        raise ValueError("Task IDs must be unique.")

    known = set(ids)
    incoming = {task: 0 for task in ids}
    outgoing = {task: [] for task in ids}

    for prerequisite, dependent in dependencies:
        if prerequisite not in known or dependent not in known:
            raise ValueError("Dependencies must reference known task IDs.")
        if prerequisite == dependent:
            raise ValueError("A task cannot depend on itself.")
        if dependent not in outgoing[prerequisite]:
            outgoing[prerequisite].append(dependent)
            incoming[dependent] += 1

    ready = [task for task in ids if incoming[task] == 0]
    order = []
    depth = {task: 0 for task in ids}

    while ready:
        current = ready.pop(0)
        order.append(current)

        for dependent in outgoing[current]:
            depth[dependent] = max(
                depth[dependent], depth[current] + 1
            )
            incoming[dependent] -= 1
            if incoming[dependent] == 0:
                ready.append(dependent)

    has_cycle = len(order) != len(ids)
    layers = {}
    if not has_cycle:
        for task in order:
            layers.setdefault(depth[task], []).append(task)

    return {
        "has_cycle": has_cycle,
        "valid": not has_cycle,
        "topological_order": order if not has_cycle else [],
        "layers": [
            {"depth": level, "tasks": layers[level]}
            for level in sorted(layers)
        ],
        "in_degree": {
            task: len([
                source for source, target in dependencies
                if target == task
            ])
            for task in ids
        },
        "out_degree": {
            task: len(outgoing[task]) for task in ids
        },
    }
