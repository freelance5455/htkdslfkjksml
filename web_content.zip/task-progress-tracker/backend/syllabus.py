"""JEE chapter list (Main + Advanced). Edit freely: names here are what the app shows.
Chapters you already logged must keep their exact spelling."""

SYLLABUS = {
    "Physics": [
        "Units and Measurements", "Kinematics", "Laws of Motion",
        "Work, Energy and Power", "Rotational Motion", "Gravitation",
        "Properties of Solids and Fluids", "Thermodynamics",
        "Kinetic Theory of Gases", "Oscillations and Waves", "Electrostatics",
        "Current Electricity", "Magnetism and Moving Charges",
        "Electromagnetic Induction and AC", "Electromagnetic Waves",
        "Ray Optics", "Wave Optics", "Dual Nature of Matter",
        "Atoms and Nuclei", "Semiconductors",
    ],
    "Chemistry": [
        "Some Basic Concepts", "Atomic Structure", "Chemical Bonding",
        "Chemical Thermodynamics", "Chemical Equilibrium", "Ionic Equilibrium",
        "Redox and Electrochemistry", "Chemical Kinetics", "Solutions",
        "Solid State", "Periodic Table", "s and p Block Elements",
        "d and f Block Elements", "Coordination Compounds", "Metallurgy",
        "General Organic Chemistry", "Hydrocarbons",
        "Haloalkanes and Haloarenes", "Alcohols, Phenols and Ethers",
        "Aldehydes and Ketones", "Carboxylic Acids and Derivatives",
        "Amines", "Biomolecules and Polymers", "Practical Chemistry",
    ],
    "Maths": [
        "Sets, Relations and Functions", "Complex Numbers",
        "Quadratic Equations", "Sequences and Series",
        "Permutations and Combinations", "Binomial Theorem",
        "Matrices and Determinants", "Trigonometry", "Inverse Trigonometry",
        "Straight Lines", "Circles", "Conic Sections",
        "Limits, Continuity and Differentiability",
        "Application of Derivatives", "Indefinite Integrals",
        "Definite Integrals and Area", "Differential Equations", "Vectors",
        "3D Geometry", "Probability", "Statistics",
    ],
}
