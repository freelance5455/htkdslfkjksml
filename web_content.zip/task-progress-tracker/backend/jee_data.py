"""JEE practice sessions: storage only (no maths here)."""
from datetime import date as Date

import syllabus

ERR_FIELDS = ("concept_err", "calculation_err", "silly_err", "time_err")


def ensure(con):
    con.execute("""
        CREATE TABLE IF NOT EXISTS jee_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL,
            subject TEXT NOT NULL,
            chapter TEXT NOT NULL,
            minutes REAL NOT NULL DEFAULT 0 CHECK(minutes >= 0),
            attempted INTEGER NOT NULL DEFAULT 0 CHECK(attempted >= 0),
            correct INTEGER NOT NULL DEFAULT 0 CHECK(correct >= 0),
            concept_err INTEGER NOT NULL DEFAULT 0 CHECK(concept_err >= 0),
            calculation_err INTEGER NOT NULL DEFAULT 0 CHECK(calculation_err >= 0),
            silly_err INTEGER NOT NULL DEFAULT 0 CHECK(silly_err >= 0),
            time_err INTEGER NOT NULL DEFAULT 0 CHECK(time_err >= 0),
            notes TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )""")
    con.execute("CREATE INDEX IF NOT EXISTS idx_jee_date ON jee_sessions(date)")
    con.commit()


def _int(value, name):
    try:
        number = float(value or 0)
    except (TypeError, ValueError):
        raise ValueError(f"{name} must be a number.")
    if number < 0 or number != int(number):
        raise ValueError(f"{name} must be a whole number, 0 or more.")
    return int(number)


def add_session(con, p):
    day = p.get("date")
    Date.fromisoformat(day if isinstance(day, str) else "")
    subject, chapter = p.get("subject"), p.get("chapter")
    if chapter not in syllabus.SYLLABUS.get(subject, []):
        raise ValueError("Unknown subject or chapter.")

    try:
        minutes = float(p.get("minutes") or 0)
    except (TypeError, ValueError):
        raise ValueError("Minutes must be a number.")
    if minutes < 0 or minutes > 1440:
        raise ValueError("Minutes must be between 0 and 1440.")

    attempted = _int(p.get("attempted"), "Attempted")
    correct = _int(p.get("correct"), "Correct")
    if correct > attempted:
        raise ValueError("Correct cannot be more than attempted.")
    errs = [_int(p.get(f), f.replace("_err", "") + " mistakes") for f in ERR_FIELDS]
    if sum(errs) > attempted - correct:
        raise ValueError("Tagged mistakes cannot exceed wrong answers.")
    if minutes == 0 and attempted == 0:
        raise ValueError("Enter study minutes or questions attempted.")

    notes = str(p.get("notes") or "")[:300]
    cur = con.execute("""
        INSERT INTO jee_sessions (date, subject, chapter, minutes, attempted,
            correct, concept_err, calculation_err, silly_err, time_err, notes)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
        (day, subject, chapter, minutes, attempted, correct, *errs, notes))
    con.commit()
    return cur.lastrowid


def delete_session(con, session_id):
    cur = con.execute("DELETE FROM jee_sessions WHERE id=?", (int(session_id),))
    con.commit()
    return cur.rowcount


def all_sessions(con):
    return [dict(r) for r in con.execute(
        "SELECT * FROM jee_sessions ORDER BY date, id").fetchall()]


def recent(con, limit=15):
    return [dict(r) for r in con.execute(
        "SELECT * FROM jee_sessions ORDER BY date DESC, id DESC LIMIT ?",
        (limit,)).fetchall()]
