"""JEE practice sessions: storage only (no maths here)."""
from datetime import date as Date

import syllabus

ERR_FIELDS = ("concept_err", "calculation_err", "silly_err", "time_err")
KINDS = ("learn", "revise", "practice", "mock")


def ensure(con):
    con.execute("""
        CREATE TABLE IF NOT EXISTS jee_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL,
            subject TEXT NOT NULL,
            chapter TEXT NOT NULL,
            minutes REAL NOT NULL DEFAULT 0 CHECK(minutes >= 0),
            attempted INTEGER NOT NULL DEFAULT 0 CHECK(attempted >= 0),
            correct INTEGER NOT NULL DEFAULT 0 CHECK(correct >= 0),
            concept_err INTEGER NOT NULL DEFAULT 0 CHECK(concept_err >= 0),
            calculation_err INTEGER NOT NULL DEFAULT 0 CHECK(calculation_err >= 0),
            silly_err INTEGER NOT NULL DEFAULT 0 CHECK(silly_err >= 0),
            time_err INTEGER NOT NULL DEFAULT 0 CHECK(time_err >= 0),
            notes TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )""")
    con.execute("CREATE INDEX IF NOT EXISTS idx_jee_date ON jee_sessions(date)")
    cols = [r[1] for r in con.execute("PRAGMA table_info(jee_sessions)")]
    if "kind" not in cols:
        con.execute("ALTER TABLE jee_sessions ADD COLUMN kind TEXT NOT NULL DEFAULT 'practice'")
    con.commit()


def _int(value, name):
    try:
        number = float(value or 0)
    except (TypeError, ValueError):
        raise ValueError(f"{name} must be a number.")
    if number < 0 or number != int(number):
        raise ValueError(f"{name} must be a whole number, 0 or more.")
    return int(number)


def add_session(con, p):
    day = p.get("date")
    Date.fromisoformat(day if isinstance(day, str) else "")
    subject, chapter = p.get("subject"), p.get("chapter")
    if chapter not in syllabus.SYLLABUS.get(subject, []):
        raise ValueError("Unknown subject or chapter.")

    try:
        minutes = float(p.get("minutes") or 0)
    except (TypeError, ValueError):
        raise ValueError("Minutes must be a number.")
    if minutes < 0 or minutes > 1440:
        raise ValueError("Minutes must be between 0 and 1440.")

    attempted = _int(p.get("attempted"), "Attempted")
    correct = _int(p.get("correct"), "Correct")
    if correct > attempted:
        raise ValueError("Correct cannot be more than attempted.")
    errs = [_int(p.get(f), f.replace("_err", "") + " mistakes") for f in ERR_FIELDS]
    if sum(errs) > attempted - correct:
        raise ValueError("Tagged mistakes cannot exceed wrong answers.")
    if minutes == 0 and attempted == 0:
        raise ValueError("Enter study minutes or questions attempted.")

    notes = str(p.get("notes") or "")[:300]
    kind = p.get("kind") or "practice"
    if kind not in KINDS:
        raise ValueError("Unknown session type.")
    cur = con.execute("""
        INSERT INTO jee_sessions (date, subject, chapter, minutes, attempted,
            correct, concept_err, calculation_err, silly_err, time_err, notes, kind)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
        (day, subject, chapter, minutes, attempted, correct, *errs, notes, kind))
    con.commit()
    return cur.lastrowid


def delete_session(con, session_id):
    cur = con.execute("DELETE FROM jee_sessions WHERE id=?", (int(session_id),))
    con.commit()
    return cur.rowcount


def all_sessions(con):
    return [dict(r) for r in con.execute(
        "SELECT * FROM jee_sessions ORDER BY date, id").fetchall()]


def recent(con, limit=15):
    return [dict(r) for r in con.execute(
        "SELECT * FROM jee_sessions ORDER BY date DESC, id DESC LIMIT ?",
        (limit,)).fetchall()]


# ---- planner settings ----
SETTING_DEFAULTS = {"exam_date": "2027-01-22", "hours_per_day": "8"}


def get_settings(con):
    con.execute("CREATE TABLE IF NOT EXISTS jee_settings "
                "(key TEXT PRIMARY KEY, value TEXT NOT NULL)")
    saved = dict(con.execute("SELECT key, value FROM jee_settings").fetchall())
    return {**SETTING_DEFAULTS, **saved}


def save_settings(con, p):
    exam = p.get("exam_date")
    Date.fromisoformat(exam if isinstance(exam, str) else "")
    try:
        hours = float(p.get("hours_per_day"))
    except (TypeError, ValueError):
        raise ValueError("Daily hours must be a number.")
    if not 1 <= hours <= 16:
        raise ValueError("Daily hours must be between 1 and 16.")
    get_settings(con)
    for key, value in (("exam_date", exam), ("hours_per_day", str(hours))):
        con.execute("INSERT INTO jee_settings (key, value) VALUES (?, ?) "
                    "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))
    con.commit()
    return get_settings(con)


# ---- starting baseline (self-rated level per chapter, 0..3) ----
def get_baseline(con):
    con.execute("CREATE TABLE IF NOT EXISTS jee_baseline "
                "(chapter TEXT PRIMARY KEY, level INTEGER NOT NULL)")
    return {r[0]: r[1] for r in con.execute("SELECT chapter, level FROM jee_baseline")}


def save_baseline(con, levels):
    if not isinstance(levels, dict):
        raise ValueError("levels must be an object")
    known = {c for chs in syllabus.SYLLABUS.values() for c in chs}
    clean = {}
    for chapter, level in levels.items():
        if chapter not in known:
            raise ValueError(f"Unknown chapter: {chapter}")
        try:
            level = int(level)
        except (TypeError, ValueError):
            raise ValueError("Levels must be 0 to 3.")
        if level not in (0, 1, 2, 3):
            raise ValueError("Levels must be 0 to 3.")
        if level:
            clean[chapter] = level
    get_baseline(con)
    con.execute("DELETE FROM jee_baseline")
    con.executemany("INSERT INTO jee_baseline (chapter, level) VALUES (?, ?)", clean.items())
    con.commit()
    return clean


# ---- past-paper weightage: average questions per paper, per chapter ----
def get_weightage(con):
    con.execute("CREATE TABLE IF NOT EXISTS jee_weightage "
                "(chapter TEXT PRIMARY KEY, avg_questions REAL NOT NULL)")
    return {r[0]: r[1] for r in con.execute("SELECT chapter, avg_questions FROM jee_weightage")}


def save_weightage(con, values):
    if not isinstance(values, dict):
        raise ValueError("values must be an object")
    known = {c for chs in syllabus.SYLLABUS.values() for c in chs}
    clean = {}
    for chapter, v in values.items():
        if chapter not in known:
            raise ValueError(f"Unknown chapter: {chapter}")
        if v is None or v == "":
            continue
        try:
            v = float(v)
        except (TypeError, ValueError):
            raise ValueError("Weightage must be a number.")
        if not 0 <= v <= 50:
            raise ValueError("Weightage must be between 0 and 50.")
        clean[chapter] = v
    get_weightage(con)
    con.execute("DELETE FROM jee_weightage")
    con.executemany("INSERT INTO jee_weightage (chapter, avg_questions) VALUES (?, ?)", clean.items())
    con.commit()
    return clean


def importance_map(con):
    """Factor 0.6 (rarely asked) to 1.1 (most asked); chapters left blank stay at 1.0."""
    w = get_weightage(con)
    top = max(w.values(), default=0)
    return {c: round(0.6 + 0.5 * v / top, 3) for c, v in w.items()} if top > 0 else {}
