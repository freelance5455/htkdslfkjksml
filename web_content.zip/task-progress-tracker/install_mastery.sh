set -e

cat > backend/tae.py <<'EOF'
"""Pawan's mastery maths, v1. jee_engine calls score_chapter() for every chapter.

Per chapter, sessions are replayed in date order:
  between sessions   K falls:            K = K * e^(-GAMMA * days)
  at each session    evidence E = sum of concept accuracies C_r
                     uncertainty Un = C_expected / (1 + checks done so far)
                     S = Un / E          dK = 1 - e^(-1/S)
                     K = K + (1 - K) * dK        (K stays between 0 and 1)
Then   f = e^(-GAMMA * days since last practice)
       Ef_act = W_I*K + f*(W_R*R + W_Q*Q)      (K already carries its own decay)
       Un_E = Ef_exp / (1 + Ef_act)
       M = (Ef_act * Un_E - B) / M_exp * 100   (clamped to 0..100)
"""
import math
from datetime import date

# ---------------- numbers you can tune ----------------
GAMMA = 0.05              # forgetting speed per day; half-life = ln2/GAMMA = about 14 days
QUESTIONS_PER_CHECK = 5   # one "concept check" per 5 questions attempted in a session
EXPECTED_CHECKS = 8.0     # C_expected: concept checks a lesson is expected to need
W_I, W_R, W_Q = 0.4, 0.2, 0.4   # knowledge, revision, question accuracy (add up to 1)
REVISIONS_PLANNED = 3     # R = revisions done / this, capped at 1
REVISION_GAP_DAYS = 2     # a practice day this long after the previous one counts as a revision
EF_EXP = 1.0              # expected effort scale (weightage is applied through M_EXP in v1)
M_EXP = 0.5               # required mastery on the Ef scale; full effort (Ef_act = 1) gives exactly 0.5
B_PENALTY = 0.0           # blocking penalty B(i): not applied yet (the planner uses prerequisites)
IMPORTANCE = {}           # chapter name -> factor; 1.0 normal. Keep between 0.6 and 1.1.
# -------------------------------------------------------


def _day(s):
    return date.fromisoformat(s["date"])


def knowledge(sessions, today, importance=1.0):
    k, prev, checks = 0.0, None, 0.0
    c_expected = EXPECTED_CHECKS * importance
    for s in sessions:
        if s["attempted"] <= 0:
            continue
        d = _day(s)
        if prev is not None:
            k *= math.exp(-GAMMA * max(0, (d - prev).days))
        n = s["attempted"] / QUESTIONS_PER_CHECK
        evidence = (s["correct"] / s["attempted"]) * n
        un = c_expected / (1.0 + checks)
        dk = 1.0 - math.exp(-evidence / un) if evidence > 0 else 0.0
        k += (1.0 - k) * dk
        checks += n
        prev = d
    if prev is not None:
        k *= math.exp(-GAMMA * max(0, (today - prev).days))
    return k, prev


def revision_score(sessions):
    days = sorted({_day(s) for s in sessions if s["attempted"] > 0})
    revisions = sum(1 for a, b in zip(days, days[1:]) if (b - a).days >= REVISION_GAP_DAYS)
    return min(1.0, revisions / REVISIONS_PLANNED)


def accuracy(sessions, today):
    num = den = 0.0
    for s in sessions:
        if s["attempted"] > 0:
            w = math.exp(-GAMMA * max(0, (today - _day(s)).days))
            num += w * s["correct"]
            den += w * s["attempted"]
    return (num + 1.0) / (den + 2.0)


def score_chapter(c, today):
    today_d = date.fromisoformat(today)
    sessions = sorted(c["sessions"], key=lambda s: (s["date"], s.get("id", 0)))
    imp = IMPORTANCE.get(c["chapter"], 1.0)

    k, last = knowledge(sessions, today_d, imp)
    q = accuracy(sessions, today_d)
    r = revision_score(sessions)
    days_since = (today_d - last).days if last else 0
    f = math.exp(-GAMMA * max(0, days_since))
    ef_act = min(1.0, W_I * k + f * (W_R * r + W_Q * q))
    un_e = EF_EXP / (1.0 + ef_act)
    m = (ef_act * un_e - B_PENALTY) / (M_EXP * imp) * 100.0
    m = max(0.0, min(100.0, m))

    asked = sum(s["attempted"] for s in sessions)
    conf = asked / (asked + 10.0)
    return {
        "mastery": m, "accuracy": q, "confidence": conf,
        "retention": f,
        "priority": (100.0 - m) * (0.6 + 0.4 * conf),
        "knowledge": k, "revision": r, "effort": ef_act,
    }
EOF

python3 - <<'EOF'
p = "backend/jee_engine.py"
s = open(p).read()
assert '"sessions": []' not in s, "jee_engine.py already patched"
old = '''            "w_mistakes": {k: 0.0 for k in (*MISTAKE_TYPES, "unclassified")},
        })
        w = 0.5 ** (age / HALF_LIFE_DAYS)
'''
assert s.count(old) == 1, "unexpected jee_engine.py layout"
new = '''            "w_mistakes": {k: 0.0 for k in (*MISTAKE_TYPES, "unclassified")},
            "sessions": [],
        })
        c["sessions"].append(s)
        w = 0.5 ** (age / HALF_LIFE_DAYS)
'''
open(p, "w").write(s.replace(old, new))
print("jee_engine.py patched")
EOF

echo "Done. Restart the server: python server.py"
