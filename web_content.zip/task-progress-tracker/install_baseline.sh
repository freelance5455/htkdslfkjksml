set -e

cat >> backend/jee_data.py <<'EOF'


# ---- starting baseline (self-rated level per chapter, 0..3) ----
def get_baseline(con):
    con.execute("CREATE TABLE IF NOT EXISTS jee_baseline "
                "(chapter TEXT PRIMARY KEY, level INTEGER NOT NULL)")
    return {r[0]: r[1] for r in con.execute("SELECT chapter, level FROM jee_baseline")}


def save_baseline(con, levels):
    if not isinstance(levels, dict):
        raise ValueError("levels must be an object")
    known = {c for chs in syllabus.SYLLABUS.values() for c in chs}
    clean = {}
    for chapter, level in levels.items():
        if chapter not in known:
            raise ValueError(f"Unknown chapter: {chapter}")
        try:
            level = int(level)
        except (TypeError, ValueError):
            raise ValueError("Levels must be 0 to 3.")
        if level not in (0, 1, 2, 3):
            raise ValueError("Levels must be 0 to 3.")
        if level:
            clean[chapter] = level
    get_baseline(con)
    con.execute("DELETE FROM jee_baseline")
    con.executemany("INSERT INTO jee_baseline (chapter, level) VALUES (?, ?)", clean.items())
    con.commit()
    return clean
EOF

python3 - <<'EOF'
def patch(path, pairs):
    s = open(path).read()
    for old, new in pairs:
        assert s.count(old) == 1, f"{path}: layout differs near: {old[:50]!r}"
        s = s.replace(old, new)
    open(path, "w").write(s)
    print(path, "patched")

patch("backend/jee_api.py", [
    ('        if path == "/api/jee/plan":\n',
     '        if path == "/api/jee/baseline":\n'
     '            return h.send_json(200, {"baseline": jee_data.get_baseline(db)})\n'
     '        if path == "/api/jee/plan":\n'),
    ('jee_data.all_sessions(db), jee_data.get_settings(db), today)})',
     'jee_data.all_sessions(db), jee_data.get_settings(db), today,\n'
     '                jee_data.get_baseline(db))})'),
    ('        if path == "/api/jee/settings":\n            return h.send_json(200, {"settings": jee_data.save_settings(db, payload)})\n',
     '        if path == "/api/jee/baseline":\n'
     '            return h.send_json(200, {"baseline": jee_data.save_baseline(db, payload.get("levels"))})\n'
     '        if path == "/api/jee/settings":\n            return h.send_json(200, {"settings": jee_data.save_settings(db, payload)})\n'),
])

patch("backend/jee_plan.py", [
    ('def _progress(ins):\n    return {e["chapter"]: 0.0 if e.get("mastery") is None\n            else min(1.0, e["mastery"] / TARGET_MASTERY) for e in ins["chapters"]}\n',
     'BASELINE_PROGRESS = {0: 0.0, 1: 0.35, 2: 0.65, 3: 0.9}   # self-rated start: none, basics, good, strong\n\n\n'
     'def _progress(ins, baseline=None):\n'
     '    """Tested chapters use their mastery; untested ones use the self-rated start."""\n'
     '    baseline = baseline or {}\n'
     '    return {e["chapter"]: BASELINE_PROGRESS[baseline.get(e["chapter"], 0)]\n'
     '            if e.get("mastery") is None\n'
     '            else min(1.0, e["mastery"] / TARGET_MASTERY) for e in ins["chapters"]}\n'),
    ('def build(sessions, settings, today_iso):', 'def build(sessions, settings, today_iso, baseline=None):'),
    ('prog, prog_prev = _progress(now), _progress(prev)',
     'prog, prog_prev = _progress(now, baseline), _progress(prev, baseline)'),
])

patch("web/planner.js", [
    ('loadSettings().then(load);', "loadSettings().then(load);\nwindow.addEventListener('jee-refresh', load);"),
])

patch("web/jee.html", [
    ('<section class="panel"><h2 class="panel-title">How mastery is calculated</h2>',
     '''<section class="section-head"><div><p class="eyebrow">BASELINE</p><h2>Starting level</h2></div></section>
<div id="baselineBox"></div>
<section class="panel">
  <p class="muted explanatory">Rate chapters you already know. A rating is used only until you log questions on that chapter; after that, your real scores take over.</p>
  <button id="baselineSave" class="primary-btn">Save starting levels</button>
  <p id="baselineMsg" class="status" aria-live="polite"></p>
</section>

<section class="panel"><h2 class="panel-title">How mastery is calculated</h2>'''),
    ('<script src="planner.js"></script>', '<script src="planner.js"></script>\n<script src="baseline.js"></script>'),
])
EOF

cat > web/baseline.js <<'EOF'
'use strict';
(() => {
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const LEVELS = ['Not started', 'Basics', 'Good', 'Strong'];

async function api(path, opts) {
  const res = await fetch(path, opts);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

function updateCounts() {
  document.querySelectorAll('#baselineBox details').forEach(d => {
    const n = [...d.querySelectorAll('select')].filter(s => Number(s.value) > 0).length;
    d.querySelector('summary span').textContent = n ? `${n} rated` : 'none rated';
  });
}

async function init() {
  try {
    const [{syllabus}, {baseline}] = await Promise.all([api('/api/jee/syllabus'), api('/api/jee/baseline')]);
    $('baselineBox').innerHTML = Object.entries(syllabus).map(([subject, chapters]) => {
      const rows = chapters.map(c => `<div class="chap"><div class="chap-top">
        <span style="color:var(--text);font-weight:500;flex:1">${esc(c)}</span>
        <select data-ch="${esc(c)}" style="width:44%">${LEVELS.map((l, i) =>
          `<option value="${i}" ${(baseline[c] || 0) === i ? 'selected' : ''}>${l}</option>`).join('')}</select>
        </div></div>`).join('');
      return `<details class="subject"><summary><b>${esc(subject)}</b><span></span></summary><div class="chap-list">${rows}</div></details>`;
    }).join('');
    updateCounts();
    $('baselineBox').addEventListener('change', updateCounts);
  } catch (e) { $('baselineBox').innerHTML = `<section class="panel"><p class="empty">Could not load: ${esc(e.message)}</p></section>`; }
}

$('baselineSave').addEventListener('click', async () => {
  const msg = $('baselineMsg'); msg.style.color = ''; msg.textContent = '';
  const levels = {};
  document.querySelectorAll('#baselineBox select').forEach(s => { levels[s.dataset.ch] = Number(s.value); });
  try {
    await api('/api/jee/baseline', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({levels})});
    msg.textContent = 'Saved'; setTimeout(() => msg.textContent = '', 2500);
    window.dispatchEvent(new Event('jee-refresh'));
  } catch (e) { msg.textContent = e.message; msg.style.color = '#ffb4ab'; }
});

init();
})();
EOF

echo "Done. Restart the server: python server.py"
