"use strict";

const SUBJECTS = {
  math: "Mathématiques",
  pcm: "Physique-chimie et mathématiques",
  tech: "2I2D / MEI",
  itec: "ITEC",
  etlv: "ETLV",
  en: "Anglais",
  es: "Espagnol",
  fr: "Français anticipé",
  ph: "Philosophie",
  hg: "Histoire-géographie",
  emc: "EMC",
  eps: "EPS"
};
const BAC = [];
for (const y of ["Première", "Terminale"]) for (const [n, c] of [["Histoire-géographie", 3], ["LVA (dont ETLV)", 3], ["LVB", 3], ["Mathématiques", 3], ["EMC", 1]]) BAC.push([y + " · " + n, c, "Contrôle continu"]);
BAC.push(["Innovation technologique · première", 8, "Contrôle continu"], ["EPS · CCF", 6, "Contrôle continu"], ["Français écrit", 5, "Épreuves anticipées"], ["Français oral", 5, "Épreuves anticipées"], ["Mathématiques anticipées", 2, "Épreuves anticipées"], ["Philosophie", 4, "Épreuves terminales"], ["Physique-chimie et mathématiques", 16, "Épreuves terminales"], ["2I2D · écrit", 9, "Épreuves terminales"], ["2I2D · pratique ITEC", 7, "Épreuves terminales"], ["Grand oral", 12, "Épreuves terminales"]);
function fresh() {
  return {
    version: 3,
    subjects: Object.keys(SUBJECTS).map(id => ({
      id,
      name: SUBJECTS[id],
      coef: 1,
      show: true
    })),
    grades: [],
    official: {},
    sessions: [],
    answers: [],
    bac: {},
    settings: {
      goal: 15,
      daily: 10,
      theme: "sombre",
      group: false,
      groupCoef: 1,
      split: false,
      pcWeight: 1,
      msWeight: 1,
      mention: 14,
      level: 0,
      eps: "",
      periods: [["2026-09-01", "2026-11-30"], ["2026-12-01", "2027-03-15"], ["2027-03-16", "2027-08-31"]]
    }
  };
}
function day(d = new Date()) {
  return [d.getFullYear(), String(d.getMonth() + 1).padStart(2, "0"), String(d.getDate()).padStart(2, "0")].join("-");
}
function shift(d, n) {
  let t = new Date(d + "T12:00:00");
  t.setDate(t.getDate() + n);
  return day(t);
}
function term(d, date = day()) {
  let i = d.settings.periods.findIndex(p => date >= p[0] && date <= p[1]);
  return i < 0 ? date < d.settings.periods[0][0] ? 1 : date < d.settings.periods[1][0] ? 1 : date < d.settings.periods[2][0] ? 2 : 3 : i + 1;
}
function mean(v) {
  let a = 0,
    b = 0;
  for (const [x, w] of v) if (x != null && w > 0) {
    a += x * w;
    b += w;
  }
  return b ? a / b : null;
}
const equal = v => mean(v.map(x => [x, 1]));
const noteMean = gs => mean(gs.map(g => [20 * g.score / g.max, g.coef]));
function subjectAvg(d, id, t, extra) {
  if (!t) return equal([1, 2, 3].map(i => subjectAvg(d, id, i, extra)));
  let o = d.official[id + "-" + t];
  if (o && o.use) return o.value;
  let gs = d.grades.filter(g => g.sub === id && g.t === t);
  if (extra && extra.sub === id && extra.t === t) gs.push(extra);
  if (id === "pcm" && d.settings.split) return mean(["pc", "ms"].map((c, i) => [noteMean(gs.filter(g => g.cat === c)), i ? d.settings.msWeight : d.settings.pcWeight]));
  return noteMean(gs);
}
function groups(d, t, extra) {
  let items = d.subjects.map(s => ({
    id: s.id,
    v: subjectAvg(d, s.id, t, extra),
    w: s.coef
  }));
  if (d.settings.group) {
    let parts = items.filter(s => ["tech", "itec"].includes(s.id));
    items = items.filter(s => !parts.includes(s));
    if (parts.length) items.push({
      id: "group",
      v: t ? mean(parts.map(s => [s.v, s.w])) : equal([1, 2, 3].map(i => mean(parts.map(s => [subjectAvg(d, s.id, i, extra), s.w])))),
      w: d.settings.groupCoef
    });
  }
  return items;
}
function general(d, t, extra) {
  if (!t) return equal([1, 2, 3].map(i => general(d, i, extra)));
  let o = d.official["general-" + t];
  return o && o.use ? o.value : mean(groups(d, t, extra).map(s => [s.v, s.w]));
}
function streak(ss, today = day()) {
  let days = [...new Set(ss.filter(s => s.n >= 5 && s.date <= today).map(s => s.date))].sort();
  let run = 0,
    record = 0,
    last = "";
  for (let d of days) {
    run = last && shift(last, 1) === d ? run + 1 : 1;
    record = Math.max(record, run);
    last = d;
  }
  return {
    days,
    record,
    current: last === today || last === shift(today, -1) ? run : 0
  };
}
function exam(d) {
  let pts = 0,
    known = 0,
    w = 0,
    kw = 0;
  BAC.forEach((b, i) => {
    let item = d.bac[i];
    if (!item) return;
    w += b[1];
    pts += item.v * b[1];
    if (item.known) {
      kw += b[1];
      known += item.v * b[1];
    }
  });
  return {
    pts,
    known,
    w,
    kw
  };
}
function needed(lo, hi, target) {
  if (lo == null || hi == null) return null;
  if (target <= lo) return 0;
  if (hi + 1e-9 < target || hi === lo) return null;
  return Math.ceil((20 * (target - lo) / (hi - lo) - 1e-9) * 100) / 100;
}
const keyName = "sti2d.revision.v3";
function valid(d) {
  const obj = x => x && typeof x === "object" && !Array.isArray(x),
    str = x => typeof x === "string",
    id = x => str(x) && /^[a-zA-Z0-9_-]{1,90}$/.test(x) && !["constructor", "__proto__", "prototype"].includes(x),
    num = (x, a, b) => typeof x === "number" && Number.isFinite(x) && x >= a && x <= b,
    date = x => str(x) && /^\d{4}-\d\d-\d\d$/.test(x) && day(new Date(x + "T12:00:00")) === x,
    unique = xs => new Set(xs).size === xs.length,
    flag = x => typeof x === "boolean",
    pos = x => num(x, 0.000001, 1000000),
    tr = x => [1, 2, 3].includes(x);
  if (!obj(d) || d.version !== 3 || !obj(d.settings) || !obj(d.official) || !obj(d.bac) || !["grades", "subjects", "sessions", "answers"].every(k => Array.isArray(d[k]))) return false;
  if (d.papers !== undefined && (!Array.isArray(d.papers) || !d.papers.every(r => obj(r) && ["pcm2027", "itec2027"].includes(r.id) && date(r.date) && num(r.score, 0, 20)))) return false;
  if (d.legacy !== undefined && (!obj(d.legacy) || !Number.isSafeInteger(d.legacy.correct) || d.legacy.correct < 0 || !Array.isArray(d.legacy.days) || !d.legacy.days.every(date))) return false;
  let p = d.settings;
  if (!num(p.goal, 0, 20) || ![5, 10, 15, 20].includes(p.daily) || !["clair", "sombre"].includes(p.theme) || ![10, 12, 14, 16].includes(p.mention) || ![0, 1, 2, 3, 4, 5].includes(p.level) || !str(p.eps) || !flag(p.group) || !flag(p.split) || ![p.groupCoef, p.pcWeight, p.msWeight].every(pos) || !Array.isArray(p.periods) || p.periods.length !== 3 || !p.periods.every((a, i) => Array.isArray(a) && a.length === 2 && a.every(date) && a[0] <= a[1] && (!i || a[0] > p.periods[i - 1][1]))) return false;
  if (!d.subjects.every(s => obj(s) && id(s.id) && s.id !== "general" && s.id !== "group" && str(s.name) && s.name.trim() && num(s.coef, 0, 1e6) && flag(s.show)) || !unique(d.subjects.map(s => s.id))) return false;
  let ids = d.subjects.map(s => s.id);
  if (!d.grades.every(g => obj(g) && id(g.id) && ids.includes(g.sub) && tr(g.t) && date(g.date) && pos(g.max) && num(g.score, 0, g.max) && pos(g.coef) && str(g.name) && str(g.comment) && (g.sub === "pcm" ? ["ms", "pc"].includes(g.cat) : g.cat === "")) || !unique(d.grades.map(g => g.id))) return false;
  if (!Object.keys(d.official).every(k => ids.concat("general").some(s => [1, 2, 3].some(t => s + "-" + t === k)) && obj(d.official[k]) && num(d.official[k].value, 0, 20) && flag(d.official[k].use))) return false;
  if (!Object.keys(d.bac).every(k => String(+k) === k && BAC[k] && obj(d.bac[k]) && num(d.bac[k].v, 0, 20) && flag(d.bac[k].known))) return false;
  return d.answers.every(a => obj(a) && id(a.q) && id(a.ch) && date(a.date) && flag(a.ok) && num(a.xp, 0, 100) && num(a.sec, 0, 86400)) && d.sessions.every(s => obj(s) && date(s.date) && str(s.title) && Number.isInteger(s.n) && num(s.n, 1, 100) && Number.isInteger(s.right) && num(s.right, 0, s.n) && num(s.xp, 0, 1000) && flag(s.mock));
}
