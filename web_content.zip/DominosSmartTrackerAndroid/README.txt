DOMINOS SMART TRACKER — ANDROID APP PROJECT

This ZIP contains the Android Studio source project. It is not a compiled APK yet.

FEATURES
- 2, 3 or 4 player mode
- Double-six set (28 tiles)
- Mark tiles as Mine, Played, or Unknown
- Counts update automatically
- Saves tile marks on the phone
- Reset tracker
- Works offline after installation

HOW TO BUILD THE APK
1. Transfer this ZIP to a computer.
2. Install Android Studio: https://developer.android.com/studio
3. Extract this ZIP.
4. In Android Studio, choose Open and select the extracted DominosSmartTrackerAndroid folder.
5. Allow Gradle to sync and download required components.
6. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
7. Find the APK at app/build/outputs/apk/debug/app-debug.apk (Android Studio shows a notification with the path).
8. Transfer that APK to your Android phone and tap it to install. Your phone may ask you to allow installation from that source.

Building requires a computer with Android Studio and internet for the first setup. The installed tracker works offline.
