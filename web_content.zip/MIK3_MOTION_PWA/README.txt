MIK3 MOTION — PWA BUILD 01

This is a browser-based adaptation of the latest MIK3 MOTION Development Snapshot 04.

INSTALL
1. Extract this ZIP.
2. Upload the MIK3_MOTION_PWA folder (or its contents) to Netlify Drop.
3. Open the generated HTTPS URL in Chrome.
4. Use Chrome menu > Install app / Add to Home screen.

CURRENTLY IMPLEMENTED
- Import multiple local video files and preview them.
- Timeline list, reorder, remove, split, trim in/out points.
- Per-clip playback speed selection.
- Import audio files and list/remove them (audio is not mixed into export yet).
- Aspect ratio and frame rate settings.
- Browser-side WebM export using canvas capture + MediaRecorder, with MIK3 MOTION watermark.
- Project decision JSON export (source media is not embedded).
- Offline app shell via service worker after first successful load.

LIMITATIONS
- This is not feature-equivalent to the Android app or a professional desktop editor.
- Export is WebM, not MP4; browser support and memory vary by device.
- Audio tracks are imported/listed but not mixed into the exported video.
- Transitions, keyframes, colour grading, beat sync, and true multitrack editing are not implemented in this PWA build.
- Project JSON stores edit settings only; re-import source media after loading.
- Keep the tab active during export. Large/long videos may fail on phones due to memory and browser limits.
- Local media is processed in the browser and is not uploaded by this app.
