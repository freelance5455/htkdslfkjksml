package app.pacex.tracker;

import android.content.Context;
import android.location.Location;
import android.os.SystemClock;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

/**
 * App-private crash recovery record for an in-progress GPS activity. The web layer holds the
 * final user-visible workout JSON; this small independent record lets the foreground service
 * survive a killed WebView and lets the UI restore the active route on the next launch.
 */
final class WorkoutSessionStore {
    private static final String DIRECTORY = "pace-x-data";
    private static final String FILE = "active-workout-native.json";
    private final Context context;
    private JSONObject session;
    private Location lastAccepted;
    private float lastSpeedKmh;

    WorkoutSessionStore(Context context) {
        this.context = context.getApplicationContext();
        load();
    }

    synchronized boolean hasActive() { return session != null; }
    synchronized boolean isPaused() { return session != null && session.optBoolean("paused", false); }

    synchronized void start(String mode) {
        session = new JSONObject();
        try {
            session.put("active", true);
            session.put("id", "native-" + UUID.randomUUID());
            session.put("mode", mode);
            session.put("startTime", TimeUtil.iso(System.currentTimeMillis()));
            session.put("paused", false);
            session.put("elapsedSeconds", 0);
            session.put("segmentStartedElapsed", SystemClock.elapsedRealtime());
            session.put("distanceKm", 0d);
            session.put("route", new JSONArray());
        } catch (JSONException ignored) { }
        lastAccepted = null;
        lastSpeedKmh = 0;
        persist();
    }

    synchronized void pause() {
        if (session == null || session.optBoolean("paused")) return;
        long started = session.optLong("segmentStartedElapsed", SystemClock.elapsedRealtime());
        long elapsed = session.optLong("elapsedSeconds", 0) + Math.max(0, (SystemClock.elapsedRealtime() - started) / 1000);
        try { session.put("elapsedSeconds", elapsed); session.put("paused", true); } catch (JSONException ignored) { }
        persist();
    }

    synchronized void resume() {
        if (session == null || !session.optBoolean("paused")) return;
        try { session.put("paused", false); session.put("segmentStartedElapsed", SystemClock.elapsedRealtime()); } catch (JSONException ignored) { }
        persist();
    }

    /** Returns true only for a quality-filtered reading accepted into the route. */
    synchronized boolean addLocation(Location location) {
        if (session == null || isPaused() || location == null) return false;
        if (!location.hasAccuracy() || location.getAccuracy() > 35f) return false;
        long now = location.getTime() > 0 ? location.getTime() : System.currentTimeMillis();
        double addKm = 0;
        float speedKmh = location.hasSpeed() ? location.getSpeed() * 3.6f : 0f;
        if (lastAccepted != null) {
            long delta = now - lastAccepted.getTime();
            float metres = lastAccepted.distanceTo(location);
            if (delta <= 0 || metres < 3f) return false; // duplicates and sub-GPS-noise movements
            float calculatedKmh = (float) ((metres / 1000d) / (delta / 3_600_000d));
            String mode = session.optString("mode", "running");
            float limit = "walking".equals(mode) ? 12f : "cycling".equals(mode) ? 75f : 30f;
            if (calculatedKmh > limit || calculatedKmh > 100f) return false; // impossible jump
            if (lastSpeedKmh > 0 && Math.abs(calculatedKmh - lastSpeedKmh) > limit * .85f) return false;
            speedKmh = location.hasSpeed() ? location.getSpeed() * 3.6f : calculatedKmh;
            addKm = metres / 1000d;
        }
        try {
            JSONObject point = new JSONObject();
            point.put("latitude", location.getLatitude());
            point.put("longitude", location.getLongitude());
            point.put("accuracy", location.getAccuracy());
            point.put("speedMps", location.hasSpeed() ? location.getSpeed() : JSONObject.NULL);
            point.put("speedKmh", speedKmh);
            point.put("timestamp", TimeUtil.iso(now));
            session.getJSONArray("route").put(point);
            session.put("distanceKm", session.optDouble("distanceKm", 0d) + addKm);
        } catch (JSONException ignored) { return false; }
        lastAccepted = new Location(location);
        lastSpeedKmh = speedKmh;
        persist();
        return true;
    }

    synchronized JSONObject snapshot() {
        if (session == null) return null;
        try {
            JSONObject copy = new JSONObject(session.toString());
            long elapsed = copy.optLong("elapsedSeconds", 0);
            if (!copy.optBoolean("paused", false)) {
                elapsed += Math.max(0, (SystemClock.elapsedRealtime() - copy.optLong("segmentStartedElapsed", SystemClock.elapsedRealtime())) / 1000);
            }
            copy.put("elapsedSeconds", elapsed);
            copy.put("active", true);
            copy.remove("segmentStartedElapsed");
            return copy;
        } catch (JSONException e) { return session; }
    }

    synchronized void clear() {
        session = null; lastAccepted = null; lastSpeedKmh = 0;
        File file = file();
        if (file.exists()) file.delete();
    }

    private void load() {
        File file = file();
        if (!file.exists()) return;
        try (FileInputStream input = new FileInputStream(file)) {
            byte[] data = new byte[(int) file.length()];
            if (input.read(data) > 0) {
                session = new JSONObject(new String(data, StandardCharsets.UTF_8));
                if (!session.optBoolean("active", false)) session = null;
                if (session != null) {
                    JSONArray route = session.optJSONArray("route");
                    if (route != null && route.length() > 0) {
                        JSONObject p = route.optJSONObject(route.length() - 1);
                        if (p != null) {
                            lastAccepted = new Location("restored");
                            lastAccepted.setLatitude(p.optDouble("latitude")); lastAccepted.setLongitude(p.optDouble("longitude"));
                            lastAccepted.setAccuracy((float) p.optDouble("accuracy", 999));
                            lastAccepted.setTime(TimeUtil.parse(p.optString("timestamp", ""), System.currentTimeMillis()));
                            lastSpeedKmh = (float) p.optDouble("speedKmh", 0);
                        }
                    }
                }
            }
        } catch (Exception ignored) { session = null; }
    }

    private void persist() {
        if (session == null) return;
        File parent = new File(context.getFilesDir(), DIRECTORY);
        if (!parent.exists()) parent.mkdirs();
        File target = file(); File tmp = new File(parent, FILE + ".tmp");
        try (FileOutputStream output = new FileOutputStream(tmp, false)) {
            output.write(session.toString().getBytes(StandardCharsets.UTF_8));
            output.getFD().sync();
            if (target.exists() && !target.delete()) return;
            if (!tmp.renameTo(target)) {
                try (FileOutputStream fallback = new FileOutputStream(target, false)) { fallback.write(session.toString().getBytes(StandardCharsets.UTF_8)); }
                tmp.delete();
            }
        } catch (Exception ignored) { }
    }
    private File file() { return new File(new File(context.getFilesDir(), DIRECTORY), FILE); }
}
