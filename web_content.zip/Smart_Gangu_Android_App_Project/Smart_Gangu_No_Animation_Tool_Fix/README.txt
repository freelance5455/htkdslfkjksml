Smart Gangu — Mini Tool Toggle + Calendar Events Update

What's changed:
1. Notes/Excel corner three-dot menu still opens the mini-tool choices. Select Calculator, Calendar, or Clock to open its mini interface. Tap the corner three-dot button again while a mini tool is open to close it. Selecting a different mini tool switches the pop-up.
2. The Calendar month-view 🎉 corner panel now has “This month” and “Full year” views. It combines recurring observances, saved Smart Gangu events/reminders, and (for 2026) Amavasya, Purnima, and Ekadashi entries plus a small set of major festival dates.
3. Event list refreshes when changing months while the panel is open. Saved user events are read from Smart Gangu's own local storage.
4. Existing app design, Clock/Alarm/Stopwatch/Timer behavior, and no-animation setting are preserved.

Important calendar note:
- Bundled Amavasya/Purnima/Ekadashi data is for 2026 only and uses a general India reference; local Odia Panchang observance can differ.
- For other years, the list includes recurring observances and events saved by the user, and recommends checking a verified local Odia Panchang for lunar dates.
- This is an offline-first HTML prototype, not an Android APK. Browser alarms may not fire if the page is closed or background activity is restricted.

How to open:
1. Extract this ZIP.
2. Open Smart_Gangu_No_Animation_Tool_Fix/index.html in Chrome.
