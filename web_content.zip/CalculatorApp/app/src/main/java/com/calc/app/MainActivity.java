package com.calc.app;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
public class MainActivity extends Activity {
  WebView w;
  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    int bg = Color.parseColor("#18181A");
    getWindow().setStatusBarColor(bg);
    getWindow().setNavigationBarColor(bg);
    w = new WebView(this);
    w.setBackgroundColor(bg);
    WebSettings s = w.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    w.setWebViewClient(new WebViewClient());
    setContentView(w);
    w.loadUrl("file:///android_asset/index.html");
  }
  @Override public void onBackPressed() {
    w.evaluateJavascript("(function(){var s=document.querySelector('.sheet.on');if(s){s.classList.remove('on');return 1}return 0})()",
      v -> { if (!"1".equals(v)) finish(); });
  }
}
