Build the APK (free, about 10 minutes):
1. Install Android Studio (developer.android.com/studio).
2. File > Open > choose this CalculatorApp folder. Wait for Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Click "locate" in the popup: app-debug.apk is ready. Copy it to your phone and install it (allow "install unknown apps").
The calculator lives in app/src/main/assets/index.html.
