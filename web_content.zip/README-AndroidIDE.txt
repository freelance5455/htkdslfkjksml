Garage 110 - AndroidIDE

افتح هذا المجلد في AndroidIDE ثم Sync/Build.
المشروع يستخدم Android Gradle Plugin 8.0.2 وGradle 8.0.2.
إذا كان AndroidIDE يفرض إصدار Gradle مختلفاً، استخدم إصدار 8.x المتوافق معه.
