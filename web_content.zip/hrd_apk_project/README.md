# HRD Unit Management — Android 6.0.1 APK Project

This project wraps the supplied HTML app in a native Android WebView.

## Compatibility
- Minimum Android: 6.0 / API 23
- Target SDK: 28
- Portrait orientation
- JavaScript and DOM/localStorage enabled

## Build
Open this folder in Android Studio and choose Build > Build APK(s).

The HTML app is bundled at:
`app/src/main/assets/index.html`

## Important
The supplied HTML currently loads Tailwind CSS, Font Awesome and Google Fonts from CDNs. The app itself is bundled locally, but those visual libraries may require internet access unless replaced with local assets.
