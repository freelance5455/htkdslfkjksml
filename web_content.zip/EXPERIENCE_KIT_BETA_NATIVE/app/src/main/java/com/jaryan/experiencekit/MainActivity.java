package com.jaryan.experiencekit;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_PERMISSIONS = 7001;
    private static final int REQ_FILE = 7002;
    private static final String CHANNEL_ID = "experience_kit_system";

    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private PermissionRequest pendingWebPermission;

    private static boolean has(Context c, String p) {
        return Build.VERSION.SDK_INT < 23 || c.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createNotificationChannel();
        webView = new WebView(this);
        configureWebView();
        setContentView(webView);
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidNative");
        webView.loadUrl("file:///android_asset/index.html");
        // First-run permission onboarding: the user remains in control through standard Android dialogs.
        getWindow().getDecorView().postDelayed(() -> {
            if (!getPreferences(MODE_PRIVATE).getBoolean("permission_onboarding_shown", false)) {
                getPreferences(MODE_PRIVATE).edit().putBoolean("permission_onboarding_shown", true).apply();
                requestFunctionalPermissions();
            }
        }, 900);
    }

    private void configureWebView() {
        WebView.setWebContentsDebuggingEnabled(false);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                return !("file".equalsIgnoreCase(u.getScheme()) || "https".equalsIgnoreCase(u.getScheme()));
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try { startActivityForResult(intent, REQ_FILE); }
                catch (Exception e) { fileCallback = null; Toast.makeText(MainActivity.this, "انتخاب فایل در دسترس نیست.", Toast.LENGTH_SHORT).show(); return false; }
                return true;
            }

            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> handleWebPermission(request));
            }
        });
    }

    private boolean trustedOrigin(PermissionRequest request) {
        if (request == null || request.getOrigin() == null) return false;
        String origin = request.getOrigin().toString();
        return origin.startsWith("file:///android_asset/") || origin.startsWith("https://appassets.androidplatform.net/");
    }

    private void handleWebPermission(PermissionRequest request) {
        if (!trustedOrigin(request)) { request.deny(); return; }
        List<String> needed = new ArrayList<>();
        for (String r : request.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r) && !has(this, Manifest.permission.RECORD_AUDIO)) needed.add(Manifest.permission.RECORD_AUDIO);
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r) && !has(this, Manifest.permission.CAMERA)) needed.add(Manifest.permission.CAMERA);
        }
        pendingWebPermission = request;
        if (needed.isEmpty()) {
            request.grant(request.getResources());
            pendingWebPermission = null;
        } else {
            requestPermissions(needed.toArray(new String[0]), REQ_PERMISSIONS);
        }
    }

    private String[] functionalPermissions() {
        List<String> p = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 23) {
            p.add(Manifest.permission.CAMERA);
            p.add(Manifest.permission.RECORD_AUDIO);
        }
        if (Build.VERSION.SDK_INT >= 33) {
            p.add(Manifest.permission.READ_MEDIA_IMAGES);
            p.add(Manifest.permission.READ_MEDIA_VIDEO);
            p.add(Manifest.permission.READ_MEDIA_AUDIO);
            if (Build.VERSION.SDK_INT >= 34) p.add(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED);
            p.add(Manifest.permission.POST_NOTIFICATIONS);
        } else if (Build.VERSION.SDK_INT >= 23) {
            p.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        return p.toArray(new String[0]);
    }

    private void requestFunctionalPermissions() {
        List<String> needed = new ArrayList<>();
        for (String p : functionalPermissions()) if (!has(this, p)) needed.add(p);
        if (needed.isEmpty()) {
            if (webView != null) webView.evaluateJavascript("window.__nativePermissionRefresh && window.__nativePermissionRefresh()", null);
            return;
        }
        requestPermissions(needed.toArray(new String[0]), REQ_PERMISSIONS);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode != REQ_PERMISSIONS) return;
        if (pendingWebPermission != null) {
            PermissionRequest r = pendingWebPermission;
            boolean audioOk = true, videoOk = true;
            for (int i = 0; i < permissions.length; i++) {
                if (Manifest.permission.RECORD_AUDIO.equals(permissions[i])) audioOk = results[i] == PackageManager.PERMISSION_GRANTED;
                if (Manifest.permission.CAMERA.equals(permissions[i])) videoOk = results[i] == PackageManager.PERMISSION_GRANTED;
            }
            List<String> grant = new ArrayList<>();
            for (String resource : r.getResources()) {
                if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource) && audioOk && has(this, Manifest.permission.RECORD_AUDIO)) grant.add(resource);
                if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource) && videoOk && has(this, Manifest.permission.CAMERA)) grant.add(resource);
            }
            if (!grant.isEmpty()) r.grant(grant.toArray(new String[0])); else r.deny();
            pendingWebPermission = null;
        }
        if (webView != null) webView.evaluateJavascript("window.__nativePermissionRefresh && window.__nativePermissionRefresh()", null);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Experience Kit", NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("اعلان‌های سیستمی Experience Kit");
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    public class AndroidBridge {
        @JavascriptInterface public void requestPermissions() { runOnUiThread(MainActivity.this::requestFunctionalPermissions); }
        @JavascriptInterface public void openAppSettings() {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
            startActivity(i);
        }
        @JavascriptInterface public String permissionStatus() {
            try {
                JSONObject o = new JSONObject();
                o.put("camera", has(MainActivity.this, Manifest.permission.CAMERA));
                o.put("microphone", has(MainActivity.this, Manifest.permission.RECORD_AUDIO));
                if (Build.VERSION.SDK_INT >= 33) {
                    o.put("images", has(MainActivity.this, Manifest.permission.READ_MEDIA_IMAGES));
                    o.put("video", has(MainActivity.this, Manifest.permission.READ_MEDIA_VIDEO));
                    o.put("audio", has(MainActivity.this, Manifest.permission.READ_MEDIA_AUDIO));
                    o.put("visual_selected", Build.VERSION.SDK_INT >= 34 && has(MainActivity.this, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED));
                    o.put("notifications", has(MainActivity.this, Manifest.permission.POST_NOTIFICATIONS));
                } else {
                    o.put("storage", has(MainActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE));
                    o.put("notifications", true);
                }
                return o.toString();
            } catch (Exception e) { return "{}"; }
        }
        @JavascriptInterface public void notifyTest() {
            if (Build.VERSION.SDK_INT >= 33 && !has(MainActivity.this, Manifest.permission.POST_NOTIFICATIONS)) {
                Toast.makeText(MainActivity.this, "ابتدا مجوز اعلان را فعال کن.", Toast.LENGTH_SHORT).show(); return;
            }
            NotificationManager nm = getSystemService(NotificationManager.class);
            android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new android.app.Notification.Builder(MainActivity.this, CHANNEL_ID) : new android.app.Notification.Builder(MainActivity.this);
            b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Experience Kit").setContentText("سیستم اعلان فعال است.").setAutoCancel(true);
            nm.notify(9001, b.build());
        }
        @JavascriptInterface public boolean isNative() { return true; }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_FILE || fileCallback == null) return;
        Uri[] results = null;
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int n = data.getClipData().getItemCount(); results = new Uri[n];
                for (int i = 0; i < n; i++) results[i] = data.getClipData().getItemAt(i).getUri();
            } else if (data.getData() != null) results = new Uri[]{data.getData()};
        }
        fileCallback.onReceiveValue(results); fileCallback = null;
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.stopLoading(); webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
