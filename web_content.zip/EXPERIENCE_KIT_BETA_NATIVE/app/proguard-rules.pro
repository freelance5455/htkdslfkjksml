# No custom rules required for Beta native wrapper.
