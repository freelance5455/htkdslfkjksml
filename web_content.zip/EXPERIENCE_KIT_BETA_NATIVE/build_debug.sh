#!/usr/bin/env bash
set -euo pipefail
./gradlew assembleDebug
printf '\nAPK: app/build/outputs/apk/debug/app-debug.apk\n'
