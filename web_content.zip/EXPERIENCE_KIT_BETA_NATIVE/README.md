# Experience Kit Beta — Native Android Wrapper

این نسخه برای حل مشکل Alpha/Beta در لایه WebView ساخته شده است. نسخه قبلی فقط HTML را داخل یک APK سازنده ثالث قرار می‌داد؛ در نتیجه `input type=file`، `WebChromeClient.onShowFileChooser` و مسیر مجوزهای WebView در اختیار اپ نبود.

## معماری

Android Native Host → WebView → local Experience Kit → IndexedDB

Native Host مسئول است برای:
- Android runtime permissions
- WebView `onPermissionRequest` برای Camera/Microphone
- WebView `onShowFileChooser` برای انتخاب عکس/ویدئو/صوت/فایل
- Android App Settings
- Notification Channel + notification test
- JavaScript bridge: `AndroidNative`

## مجوزها

اعلام شده‌اند:
- CAMERA
- RECORD_AUDIO
- POST_NOTIFICATIONS (Android 13+)
- READ_MEDIA_IMAGES / VIDEO / AUDIO (Android 13+)
- READ_MEDIA_VISUAL_USER_SELECTED (Android 14+)
- READ_EXTERNAL_STORAGE فقط تا Android 12
- INTERNET

نکته: انتخاب فایل با System Document Picker انجام می‌شود و برای انتخاب فایل نیازی به مجوز گسترده حافظه ندارد. مجوزهای رسانه برای سازگاری و وضعیت‌سنجی سیستم در Permission Center اعلام شده‌اند.

## رفتار

در اولین اجرای نسخه Native، Android مجوزهای لازم را با دیالوگ استاندارد خودش درخواست می‌کند. کاربر تصمیم نهایی را می‌گیرد. اگر مجوزی قبلاً رد شده باشد، دکمه «تنظیمات Android» صفحه App Info سیستم را باز می‌کند.

## ساخت

پیش‌نیاز: Android SDK، JDK 17، Gradle 9.6 و Android build tools سازگار با compileSdk 37. یک Workflow آمادهٔ GitHub Actions نیز داخل پروژه قرار دارد.

```bash
./gradlew assembleDebug
```

خروجی:
`app/build/outputs/apk/debug/app-debug.apk`

## تست‌های این محیط

- JavaScript syntax: PASS
- Native source static inspection: PASS
- Manifest permission audit: PASS
- File chooser callback present: PASS
- WebView permission bridge present: PASS
- Notification channel present: PASS
- APK build در این محیط انجام نشده چون Android SDK/Gradle نصب نیست.
