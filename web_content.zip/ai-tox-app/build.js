// Builds ./www from src/patched.html, fully offline (no CDN calls at runtime).
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const root = __dirname;
const www = path.join(root, 'www');
const assets = path.join(www, 'assets');
const nm = (...p) => path.join(root, 'node_modules', ...p);

fs.rmSync(www, { recursive: true, force: true });
fs.mkdirSync(assets, { recursive: true });

let html = fs.readFileSync(path.join(root, 'src', 'patched.html'), 'utf8');

// 1) Remove CDN tags and the inline tailwind.config block
html = html
  .replace(/<script src="https:\/\/cdn\.tailwindcss\.com[^>]*><\/script>\s*/g, '')
  .replace(/<script src="https:\/\/cdn\.jsdelivr\.net\/npm\/chart\.js[^>]*><\/script>\s*/g, '')
  .replace(/<script src="https:\/\/cdnjs\.cloudflare\.com\/ajax\/libs\/html2pdf\.js[^>]*><\/script>\s*/g, '')
  .replace(/<link rel="preconnect"[^>]*>\s*/g, '')
  .replace(/<link href="https:\/\/fonts\.googleapis\.com[^>]*>\s*/g, '')
  .replace(/<script>\s*tailwind\.config\s*=[\s\S]*?<\/script>\s*/, '');

// 2) Local assets (Capacitor core is injected automatically by the native bridge)
const head =
  '<link rel="stylesheet" href="assets/fonts.css">\n' +
  '  <link rel="stylesheet" href="assets/tailwind.css">\n' +
  '  <script src="assets/chart.umd.js"></script>\n' +
  '  <script src="assets/html2pdf.bundle.min.js"></script>\n';
html = html.replace('</head>', '  ' + head + '</head>');

fs.writeFileSync(path.join(www, 'index.html'), html);

// 3) Tailwind -> static CSS
execSync(
  `npx tailwindcss -c tailwind.config.js -i src/input.css -o www/assets/tailwind.css --minify`,
  { cwd: root, stdio: 'inherit' }
);

// 4) JS libraries
fs.copyFileSync(nm('chart.js', 'dist', 'chart.umd.js'), path.join(assets, 'chart.umd.js'));
fs.copyFileSync(nm('html2pdf.js', 'dist', 'html2pdf.bundle.min.js'), path.join(assets, 'html2pdf.bundle.min.js'));

// 5) Fonts (latin subsets only) + generated fonts.css
const fontsDir = path.join(assets, 'files');
fs.mkdirSync(fontsDir, { recursive: true });
let fontsCss = '';
const addFont = (pkg, weights) => {
  for (const w of weights) {
    const cssFile = nm('@fontsource', pkg, `${w}.css`);
    let css = fs.readFileSync(cssFile, 'utf8');
    // keep only the latin @font-face block
    const blocks = css.split('@font-face').filter(b => /unicode-range: U\+0000-00FF/.test(b) || (!/unicode-range/.test(b) && b.trim()));
    css = blocks.map(b => '@font-face' + b).join('\n');
    css = css.replace(/url\(\.\/files\/([^)]+)\)/g, (m, f) => {
      const src = nm('@fontsource', pkg, 'files', f);
      if (fs.existsSync(src)) fs.copyFileSync(src, path.join(fontsDir, f));
      return `url(./files/${f})`;
    });
    fontsCss += css + '\n';
  }
};
addFont('inter', [400, 500, 600, 700, 800, 900]);
addFont('jetbrains-mono', [400, 500, 600, 700]);
fs.writeFileSync(path.join(assets, 'fonts.css'), fontsCss);

console.log('www/ built OK');
