import re, sys
s = open('src/original.html', encoding='utf-8').read()

def rep(old, new, count=1):
    global s
    assert s.count(old) >= 1, 'missing: ' + old[:70]
    s = s.replace(old, new, count)

# 1) CSS: keep the whole report inside the A4 page (no text/table overflow)
css = """
    /* ===== Report must stay fully inside the page ===== */
    #pdfPrintableContainer { width: 718px; max-width: 100%; box-sizing: border-box; overflow: hidden; background: #ffffff; }
    #pdfPrintableContainer, #pdfPrintableContainer * { box-sizing: border-box; overflow-wrap: anywhere; word-break: break-word; }
    #pdfPrintableContainer table { width: 100% !important; table-layout: fixed; border-collapse: collapse; }
    #pdfPrintableContainer th, #pdfPrintableContainer td { overflow-wrap: anywhere; word-break: break-word; white-space: normal; }
    #pdfPrintableContainer img { max-width: 100% !important; height: auto; }
    #pdfPrintableContainer h1, #pdfPrintableContainer h2, #pdfPrintableContainer h3 { page-break-after: avoid; }
    #pdfPrintableContainer tr, #pdfPrintableContainer img { page-break-inside: avoid; }
    #aiToxAutoReportContainer { overflow-wrap: anywhere; word-break: break-word; overflow-x: hidden; }
    #aiToxAutoReportContainer * { max-width: 100%; }
    .safe-area { padding-top: env(safe-area-inset-top); padding-bottom: env(safe-area-inset-bottom); }

    @media print {"""
rep("\n    @media print {", css)

# 2) Report wrapper: fit container width instead of fixed 780px
rep("padding:24px;max-width:780px;margin:0 auto;line-height:1.45;", "padding:6px 4px;width:100%;max-width:100%;margin:0;line-height:1.45;")
rep("justify-content:space-between;align-items:flex-end;\">", "justify-content:space-between;align-items:flex-end;gap:8px;flex-wrap:wrap;\">")

# 3) Images inside the report: never wider than the page
rep('style="width:520px;max-width:100%;height:auto;border:1px solid #0f172a;"', 'style="width:100%;max-width:100%;height:auto;border:1px solid #0f172a;"', 3)

# 4) html2pdf: render at the container width, A4 margins, smart page breaks
rep("windowWidth: 820,", "windowWidth: 718,")
rep("pdfContainer.classList.remove('hidden');", "pdfContainer.classList.remove('hidden');\n      pdfContainer.style.width = '718px';")
rep("pagebreak: { mode: ['avoid-all', 'css', 'legacy'] }", "pagebreak: { mode: ['css', 'legacy'], avoid: ['tr', 'img', 'h1', 'h2', 'h3'] }")
rep("margin: [8, 8, 8, 8],", "margin: [10, 8, 10, 8],")

# 5) Android: PDF save + share through Capacitor (anchor downloads do not work in a WebView)
old = "html2pdf().set(opt).from(pdfContainer).save().then(() => {"
new = """const done = () => {
            pdfContainer.classList.add('hidden');
            window.scrollTo(0, prevScrollY);
          };
          if (window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()) {
            html2pdf().set(opt).from(pdfContainer).outputPdf('datauristring').then(async (uri) => {
              try {
                const base64 = String(uri).split(',')[1];
                const Fs = window.Capacitor.Plugins.Filesystem;
                const Sh = window.Capacitor.Plugins.Share;
                const w = await Fs.writeFile({ path: filename, data: base64, directory: 'CACHE' });
                await Sh.share({ title: filename, url: w.uri, dialogTitle: 'AI TOX PDF' });
                showToast('PDF ready.');
              } catch (err) { showToast('Could not save PDF: ' + (err && err.message ? err.message : err)); }
              done();
            }).catch(() => { done(); showToast('PDF export failed.'); });
            return;
          }
          html2pdf().set(opt).from(pdfContainer).save().then(() => {"""
rep(old, new)

# 6) Standalone-in-Chrome button makes no sense inside the app
m = re.search(r"window\.addEventListener\('DOMContentLoaded', \(\) => \{(\s*)loadStoredState\(\);", s)
assert m, 'missing DOMContentLoaded'
inject = ("window.addEventListener('DOMContentLoaded', () => {\n"
 "      if (window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()) {\n"
 "        const b = document.getElementById('downloadChromeAppBtn'); if (b) b.style.display = 'none';\n"
 "        document.body.classList.add('safe-area');\n"
 "      }\n      loadStoredState();")
s = s[:m.start()] + inject + s[m.end():]

# 7) Android back button / viewport
rep('<meta name="viewport" content="width=device-width, initial-scale=1.0" />',
    '<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover" />')

open('src/patched.html', 'w', encoding='utf-8').write(s)
print('ok', len(s))

# 8) Owner key: only AMAX@#$ (case-sensitive, stored as SHA-256 hash, no other keys)
s = open('src/patched.html', encoding='utf-8').read()
sha_fn = r'''
    // Owner key check (SHA-256 hash only; the password itself is not stored in the page)
    const OWNER_KEY_SHA256 = '8f2e5b85a6e9af86139ffaf7949c3e4fbab75bf38051d08b7fe02ea8a617b76c';
    function sha256Hex(str) {
      const K = [], H = [];
      let n = 2, c = 0;
      while (c < 64) {
        let p = true;
        for (let i = 2; i * i <= n; i++) if (n % i === 0) { p = false; break; }
        if (p) {
          if (c < 8) H[c] = (Math.pow(n, 1 / 2) % 1 * 4294967296) | 0;
          K[c] = (Math.pow(n, 1 / 3) % 1 * 4294967296) | 0;
          c++;
        }
        n++;
      }
      const bytes = Array.from(new TextEncoder().encode(str));
      const bitLen = bytes.length * 8;
      bytes.push(0x80);
      while (bytes.length % 64 !== 56) bytes.push(0);
      for (let i = 7; i >= 0; i--) bytes.push(i >= 4 ? 0 : (bitLen >>> (i * 8)) & 255);
      const rotr = (x, k) => (x >>> k) | (x << (32 - k));
      for (let off = 0; off < bytes.length; off += 64) {
        const w = new Array(64);
        for (let i = 0; i < 16; i++) w[i] = (bytes[off + 4*i] << 24) | (bytes[off + 4*i + 1] << 16) | (bytes[off + 4*i + 2] << 8) | bytes[off + 4*i + 3];
        for (let i = 16; i < 64; i++) {
          const s0 = rotr(w[i-15], 7) ^ rotr(w[i-15], 18) ^ (w[i-15] >>> 3);
          const s1 = rotr(w[i-2], 17) ^ rotr(w[i-2], 19) ^ (w[i-2] >>> 10);
          w[i] = (w[i-16] + s0 + w[i-7] + s1) | 0;
        }
        let [a, b, c2, d, e, f, g, h] = H;
        for (let i = 0; i < 64; i++) {
          const S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
          const ch = (e & f) ^ (~e & g);
          const t1 = (h + S1 + ch + K[i] + w[i]) | 0;
          const S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
          const maj = (a & b) ^ (a & c2) ^ (b & c2);
          const t2 = (S0 + maj) | 0;
          h = g; g = f; f = e; e = (d + t1) | 0; d = c2; c2 = b; b = a; a = (t1 + t2) | 0;
        }
        H[0] = (H[0] + a) | 0; H[1] = (H[1] + b) | 0; H[2] = (H[2] + c2) | 0; H[3] = (H[3] + d) | 0;
        H[4] = (H[4] + e) | 0; H[5] = (H[5] + f) | 0; H[6] = (H[6] + g) | 0; H[7] = (H[7] + h) | 0;
      }
      return H.map(x => (x >>> 0).toString(16).padStart(8, '0')).join('');
    }
    function isOwnerKey(v) { return sha256Hex(String(v)) === OWNER_KEY_SHA256; }

    function isValidAccessCode('''
assert s.count('function isValidAccessCode(') == 1
s = s.replace('function isValidAccessCode(', sha_fn, 1)

m = re.search(r"const val = document\.getElementById\('ownerMasterPinInput'\)\.value\.trim\(\)\.toLowerCase\(\);", s)
assert m
s = s[:m.start()] + "const val = document.getElementById('ownerMasterPinInput').value;" + s[m.end():]
m = re.search(r"if \(val === '2026'[^\n]*isValidAccessCode\(val\)\) \{", s)
assert m
s = s[:m.start()] + "if (isOwnerKey(val)) {" + s[m.end():]
open('src/patched.html', 'w', encoding='utf-8').write(s)
print('owner key patched')

# ---------------------------------------------------------------------------
# 9) Remove Chrome-standalone + Load-5-Fold, and rebuild PDF export:
#    report is shown INSIDE the page (modal) + PDF save/share with fallbacks
# ---------------------------------------------------------------------------
s = open('src/patched.html', encoding='utf-8').read()

def cut_button(btn_id):
    global s
    m = re.search(r'<button id="%s"[\s\S]*?</button>' % btn_id, s)
    assert m, btn_id
    s = s[:m.start()] + s[m.end():]

def cut_div(div_id):
    global s
    st = s.index('<div id="%s"' % div_id)
    depth, i = 0, st
    for m in re.finditer(r'<div\b|</div>', s[st:]):
        depth += 1 if m.group(0).startswith('<div') else -1
        if depth == 0:
            s = s[:st] + s[st + m.end():]
            return
    raise AssertionError(div_id)

def cut_stmt(prefix):
    global s
    st = s.index(prefix)
    depth, i = 1, st + len(prefix)
    while depth:
        ch = s[i]
        depth += (ch == '(') - (ch == ')')
        i += 1
    while s[i] in ' \t': i += 1
    if s[i] == ';': i += 1
    s = s[:st] + s[i:]

cut_button('downloadChromeAppBtn')
cut_button('loadPresetBtn')
cut_div('chromeGuideModal')
for bid in ['downloadChromeAppBtn', 'redownloadStandaloneBtn', 'closeChromeGuideBtn', 'closeChromeGuideBtn2', 'loadPresetBtn']:
    cut_stmt("document.getElementById('%s').addEventListener(" % bid)
s = s.replace("const b = document.getElementById('downloadChromeAppBtn'); if (b) b.style.display = 'none';", "")

# --- CSS for the in-page preview (same fit rules as the PDF container)
prev_css = """
    #reportPreviewBody, #reportPreviewBody * { box-sizing: border-box; overflow-wrap: anywhere; word-break: break-word; }
    #reportPreviewBody table { width: 100% !important; table-layout: fixed; border-collapse: collapse; }
    #reportPreviewBody th, #reportPreviewBody td { overflow-wrap: anywhere; word-break: break-word; white-space: normal; }
    #reportPreviewBody img { max-width: 100% !important; height: auto; }
    #reportPreviewBody { font-size: 12px; }

    @media print {"""
assert s.count('\n    @media print {') == 1
s = s.replace('\n    @media print {', prev_css, 1)

# --- Modal markup
modal = """
  <!-- IN-PAGE REPORT VIEWER (report is always shown inside the page) -->
  <div id="reportPreviewModal" class="hidden fixed inset-0 z-[60] bg-slate-950/95 flex flex-col">
    <div class="bg-slate-900 text-white px-3 py-2 flex flex-wrap items-center justify-between gap-2 safe-area">
      <div class="text-xs font-bold">AI TOX — Scientific Report</div>
      <div class="flex items-center gap-2 flex-wrap">
        <button id="reportSavePdfBtn" type="button" disabled class="bg-rose-600 hover:bg-rose-500 disabled:opacity-60 text-white font-extrabold px-3 py-1.5 rounded-lg text-xs">Preparing PDF…</button>
        <button id="reportOpenPdfBtn" type="button" class="hidden bg-blue-600 hover:bg-blue-500 text-white font-bold px-3 py-1.5 rounded-lg text-xs">Open PDF</button>
        <button id="reportCloseBtn" type="button" class="bg-slate-700 hover:bg-slate-600 text-white font-bold px-3 py-1.5 rounded-lg text-xs">Close ✕</button>
      </div>
    </div>
    <div class="flex-1 overflow-y-auto bg-slate-300 p-2 sm:p-4">
      <div id="reportPreviewBody" class="mx-auto bg-white shadow-xl" style="max-width:760px;padding:10px;overflow:hidden;color:#0f172a;"></div>
    </div>
    <div id="reportPdfStatus" class="bg-slate-900 text-slate-300 text-[11px] px-3 py-1.5"></div>
  </div>

  <!-- HIDDEN PRINT/PDF RENDERING CONTAINER"""
assert s.count('<!-- HIDDEN PRINT/PDF RENDERING CONTAINER') == 1
s = s.replace('\n  <!-- HIDDEN PRINT/PDF RENDERING CONTAINER', modal, 1)

# --- Replace the tail of exportScientificPdfReport + drop downloadStandaloneChromeHtml
a = s.index("const pdfContainer = document.getElementById('pdfPrintableContainer');")
b = s.index("function renderVisitorsLog() {")
assert a < b
new_js = r"""const safeName = (res.name || 'Researcher').replace(/\s+/g, '_');
      const filename = `AI_TOX_Scientific_Report_${safeName}.pdf`;
      openReportPreview(reportInnerHtml, filename);
    }

    // ---------- In-page report viewer + PDF creation / saving ----------
    let _pdfBlob = null, _pdfBlobUrl = null, _pdfFilename = 'AI_TOX_Report.pdf', _capPlugins = {};

    function setPdfStatus(msg) {
      const el = document.getElementById('reportPdfStatus');
      if (el) el.textContent = msg || '';
    }

    function isNativeApp() {
      const cap = window.Capacitor;
      if (!cap) return false;
      if (typeof cap.isNativePlatform === 'function') return !!cap.isNativePlatform();
      if (typeof cap.getPlatform === 'function') return cap.getPlatform() !== 'web';
      return false;
    }

    function getCapPlugin(name) {
      const cap = window.Capacitor;
      if (!cap) return null;
      if (cap.Plugins && cap.Plugins[name]) return cap.Plugins[name];
      if (!_capPlugins[name] && typeof cap.registerPlugin === 'function') _capPlugins[name] = cap.registerPlugin(name);
      return _capPlugins[name] || null;
    }

    function blobToBase64(blob) {
      return new Promise((resolve, reject) => {
        const fr = new FileReader();
        fr.onload = () => resolve(String(fr.result).split(',')[1]);
        fr.onerror = () => reject(fr.error || new Error('read error'));
        fr.readAsDataURL(blob);
      });
    }

    function buildPdfBlob(reportHtml) {
      return new Promise((resolve, reject) => {
        if (typeof html2pdf === 'undefined') { reject(new Error('PDF engine not loaded')); return; }
        const c = document.getElementById('pdfPrintableContainer');
        c.innerHTML = reportHtml;
        c.classList.remove('hidden');
        c.style.width = '718px';
        const prevY = window.scrollY;
        window.scrollTo(0, 0);
        const finish = () => { c.classList.add('hidden'); c.innerHTML = ''; window.scrollTo(0, prevY); };
        setTimeout(() => {
          const opt = {
            margin: [10, 8, 10, 8],
            image: { type: 'jpeg', quality: 0.98 },
            html2canvas: { scale: 2, useCORS: true, scrollY: 0, scrollX: 0, windowWidth: 718, backgroundColor: '#ffffff' },
            jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
            pagebreak: { mode: ['css', 'legacy'], avoid: ['tr', 'img', 'h1', 'h2', 'h3'] }
          };
          html2pdf().set(opt).from(c).outputPdf('blob').then(blob => { finish(); resolve(blob); })
            .catch(err => { finish(); reject(err); });
        }, 250);
      });
    }

    function openReportPreview(reportHtml, filename) {
      const modal = document.getElementById('reportPreviewModal');
      const saveBtn = document.getElementById('reportSavePdfBtn');
      document.getElementById('reportPreviewBody').innerHTML = reportHtml;
      document.getElementById('reportOpenPdfBtn').classList.add('hidden');
      modal.classList.remove('hidden');
      modal.querySelector('.overflow-y-auto').scrollTop = 0;
      _pdfBlob = null;
      _pdfFilename = filename;
      if (_pdfBlobUrl) { try { URL.revokeObjectURL(_pdfBlobUrl); } catch (e) {} _pdfBlobUrl = null; }
      saveBtn.disabled = true;
      saveBtn.textContent = 'Preparing PDF…';
      setPdfStatus('The full report is shown below, inside the page. Preparing the PDF file…');
      buildPdfBlob(reportHtml).then(blob => {
        _pdfBlob = blob;
        saveBtn.disabled = false;
        saveBtn.textContent = 'Save / Share PDF';
        setPdfStatus('PDF is ready. Tap "Save / Share PDF".');
      }).catch(err => {
        saveBtn.textContent = 'PDF unavailable';
        setPdfStatus('Could not create the PDF file on this device. The full report is available below. (' + (err && err.message ? err.message : err) + ')');
      });
    }

    function closeReportPreview() {
      document.getElementById('reportPreviewModal').classList.add('hidden');
      document.getElementById('reportPreviewBody').innerHTML = '';
    }

    async function saveOrSharePdf() {
      if (!_pdfBlob) return;
      const blob = _pdfBlob, filename = _pdfFilename;
      // 1) Android app (Capacitor): write to cache and open the share sheet
      if (isNativeApp()) {
        try {
          const Fs = getCapPlugin('Filesystem'), Sh = getCapPlugin('Share');
          if (Fs && Sh) {
            const data = await blobToBase64(blob);
            const w = await Fs.writeFile({ path: filename, data, directory: 'CACHE' });
            await Sh.share({ title: filename, url: w.uri, dialogTitle: 'AI TOX PDF' });
            setPdfStatus('PDF saved / shared.');
            return;
          }
        } catch (e) {
          setPdfStatus('Native save failed (' + (e && e.message ? e.message : e) + '). Trying another way…');
        }
      }
      // 2) Web Share API with a file
      try {
        const file = new File([blob], filename, { type: 'application/pdf' });
        if (navigator.canShare && navigator.canShare({ files: [file] })) {
          await navigator.share({ files: [file], title: filename });
          setPdfStatus('PDF shared.');
          return;
        }
      } catch (e) { if (e && e.name === 'AbortError') return; }
      // 3) Classic download link
      try {
        _pdfBlobUrl = _pdfBlobUrl || URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = _pdfBlobUrl; a.download = filename;
        document.body.appendChild(a); a.click(); document.body.removeChild(a);
        document.getElementById('reportOpenPdfBtn').classList.remove('hidden');
        setPdfStatus('Download started. If nothing happened, tap "Open PDF".');
      } catch (e) {
        setPdfStatus('Saving is not supported here. You can read the full report below.');
      }
    }

    function openPdfInViewer() {
      if (!_pdfBlob) return;
      _pdfBlobUrl = _pdfBlobUrl || URL.createObjectURL(_pdfBlob);
      window.open(_pdfBlobUrl, '_blank');
    }

    """
s = s[:a] + new_js + s[b:]

# --- Wire listeners
m = re.search(r"document\.getElementById\('exportPdfBtnMain'\)\.addEventListener\('click', exportScientificPdfReport\);", s)
assert m
wire = m.group(0) + """
      document.getElementById('reportSavePdfBtn').addEventListener('click', saveOrSharePdf);
      document.getElementById('reportOpenPdfBtn').addEventListener('click', openPdfInViewer);
      document.getElementById('reportCloseBtn').addEventListener('click', closeReportPreview);"""
s = s[:m.start()] + wire + s[m.end():]

open('src/patched.html', 'w', encoding='utf-8').write(s)
print('step 9 ok', len(s))

# ---------------------------------------------------------------------------
# 10) Remove the domain everywhere + more robust PDF (print path, timeout, scale)
# ---------------------------------------------------------------------------
s = open('src/patched.html', encoding='utf-8').read()

def sub1(pattern, repl, flags=0):
    global s
    s, n = re.subn(pattern, repl, s, count=1, flags=flags)
    assert n == 1, 'no match: ' + pattern[:60]

# top bar: drop the whole domain pill (+ copy button)
i = s.index('<!-- Official Domain URL Bar -->')
st = s.index('<div', i)
depth = 0
for m in re.finditer(r'<div\b|</div>', s[st:]):
    depth += 1 if m.group(0).startswith('<div') else -1
    if depth == 0:
        s = s[:st] + s[st + m.end():]
        break
s = s.replace('<!-- Official Domain URL Bar -->', '')
assert s.count('max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2 text-xs') == 1
s = s.replace('max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2 text-xs', 'max-w-7xl mx-auto flex flex-wrap items-center justify-end gap-2 text-xs')

sub1(r'<span class="text-\[11px\] font-bold uppercase tracking-wider text-emerald-400">Official Domain:[^<]*</span>', '')
sub1(r' \(<span class="font-mono text-emerald-300">https://ai-tox\.ahmedaboganoub\.com</span>\)', '')
sub1(r'<span class="bg-slate-900 text-emerald-300[^"]*">\s*ai-tox\.ahmedaboganoub\.com\s*</span>', '')
sub1(r'https://ai-tox\.ahmedaboganoub\.com \| ahmedabugnoub@gmail\.com', 'ahmedabugnoub@gmail.com')
sub1(r"\n\s*domain: 'https://ai-tox\.ahmedaboganoub\.com',", '')
sub1(r' \(<span class="font-mono">ai-tox\.ahmedaboganoub\.com</span>\)', '')
sub1(r'<div>https://ai-tox\.ahmedaboganoub\.com</div>', '')
sub1(r"university: 'ai-tox\.ahmedaboganoub\.com'", "university: 'AI TOX'")
sub1(r' \(https://ai-tox\.ahmedaboganoub\.com\)', '')
cut_stmt("document.getElementById('copyDomainBtn').addEventListener(")
assert 'ahmedaboganoub' not in s.replace('com.ahmedaboganoub', ''), [m.start() for m in re.finditer('ahmedaboganoub', s)]

# ---- PDF robustness
s = s.replace("html2canvas: { scale: 2, useCORS: true, scrollY: 0, scrollX: 0, windowWidth: 718, backgroundColor: '#ffffff' },\n            jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },\n            pagebreak: { mode: ['css', 'legacy'], avoid: ['tr', 'img', 'h1', 'h2', 'h3'] }\n          };\n          html2pdf().set(opt).from(c).outputPdf('blob').then(blob => { finish(); resolve(blob); })\n            .catch(err => { finish(); reject(err); });",
              "html2canvas: { scale: (window.innerWidth < 900 ? 1.5 : 2), useCORS: true, scrollY: 0, scrollX: 0, windowWidth: 718, backgroundColor: '#ffffff', logging: false },\n            jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait', compress: true },\n            pagebreak: { mode: ['css', 'legacy'], avoid: ['tr', 'img', 'h1', 'h2', 'h3'] }\n          };\n          const timer = setTimeout(() => { finish(); reject(new Error('PDF creation timed out')); }, 90000);\n          html2pdf().set(opt).from(c).outputPdf('blob').then(blob => { clearTimeout(timer); finish(); resolve(blob); })\n            .catch(err => { clearTimeout(timer); finish(); reject(err); });")
assert 'PDF creation timed out' in s

# print stylesheet: print the in-page report (Save as PDF from the print dialog)
m = re.search(r'@media print \{.*?\n    \}', s, re.S)
assert m
s = s[:m.start()] + """@media print {
      body > *:not(#reportPreviewModal) { display: none !important; }
      #reportPreviewModal { position: static !important; display: block !important; background: #ffffff !important; }
      #reportPreviewModal.hidden { display: none !important; }
      .no-print { display: none !important; }
      #reportPreviewModal .overflow-y-auto { overflow: visible !important; background: #ffffff !important; padding: 0 !important; }
      #reportPreviewBody { box-shadow: none !important; max-width: 100% !important; width: 100% !important; padding: 0 !important; }
      @page { size: A4; margin: 10mm 8mm; }
    }""" + s[m.end():]

s = s.replace('flex flex-wrap items-center justify-between gap-2 safe-area">', 'flex flex-wrap items-center justify-between gap-2 safe-area no-print">')
s = s.replace('<div id="reportPdfStatus" class="bg-slate-900', '<div id="reportPdfStatus" class="no-print bg-slate-900')
s = s.replace('<button id="reportCloseBtn"', '<button id="reportPrintBtn" type="button" class="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-3 py-1.5 rounded-lg text-xs">Print / Save as PDF</button>\n        <button id="reportCloseBtn"', 1)
s = s.replace("document.getElementById('reportCloseBtn').addEventListener('click', closeReportPreview);",
              "document.getElementById('reportCloseBtn').addEventListener('click', closeReportPreview);\n      document.getElementById('reportPrintBtn').addEventListener('click', () => { try { window.print(); } catch (e) { setPdfStatus('Printing is not supported on this device.'); } });")
assert 'reportPrintBtn' in s and 'no-print' in s
open('src/patched.html', 'w', encoding='utf-8').write(s)
print('step 10 ok')
