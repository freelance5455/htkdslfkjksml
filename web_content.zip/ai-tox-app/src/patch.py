import re, sys
s = open('src/original.html', encoding='utf-8').read()

def rep(old, new, count=1):
    global s
    assert s.count(old) >= 1, 'missing: ' + old[:70]
    s = s.replace(old, new, count)

# 1) CSS: keep the whole report inside the A4 page (no text/table overflow)
css = """
    /* ===== Report must stay fully inside the page ===== */
    #pdfPrintableContainer { width: 718px; max-width: 100%; box-sizing: border-box; overflow: hidden; background: #ffffff; }
    #pdfPrintableContainer, #pdfPrintableContainer * { box-sizing: border-box; overflow-wrap: anywhere; word-break: break-word; }
    #pdfPrintableContainer table { width: 100% !important; table-layout: fixed; border-collapse: collapse; }
    #pdfPrintableContainer th, #pdfPrintableContainer td { overflow-wrap: anywhere; word-break: break-word; white-space: normal; }
    #pdfPrintableContainer img { max-width: 100% !important; height: auto; }
    #pdfPrintableContainer h1, #pdfPrintableContainer h2, #pdfPrintableContainer h3 { page-break-after: avoid; }
    #pdfPrintableContainer tr, #pdfPrintableContainer img { page-break-inside: avoid; }
    #aiToxAutoReportContainer { overflow-wrap: anywhere; word-break: break-word; overflow-x: hidden; }
    #aiToxAutoReportContainer * { max-width: 100%; }
    .safe-area { padding-top: env(safe-area-inset-top); padding-bottom: env(safe-area-inset-bottom); }

    @media print {"""
rep("\n    @media print {", css)

# 2) Report wrapper: fit container width instead of fixed 780px
rep("padding:24px;max-width:780px;margin:0 auto;line-height:1.45;", "padding:6px 4px;width:100%;max-width:100%;margin:0;line-height:1.45;")
rep("justify-content:space-between;align-items:flex-end;\">", "justify-content:space-between;align-items:flex-end;gap:8px;flex-wrap:wrap;\">")

# 3) Images inside the report: never wider than the page
rep('style="width:520px;max-width:100%;height:auto;border:1px solid #0f172a;"', 'style="width:100%;max-width:100%;height:auto;border:1px solid #0f172a;"', 3)

# 4) html2pdf: render at the container width, A4 margins, smart page breaks
rep("windowWidth: 820,", "windowWidth: 718,")
rep("pdfContainer.classList.remove('hidden');", "pdfContainer.classList.remove('hidden');\n      pdfContainer.style.width = '718px';")
rep("pagebreak: { mode: ['avoid-all', 'css', 'legacy'] }", "pagebreak: { mode: ['css', 'legacy'], avoid: ['tr', 'img', 'h1', 'h2', 'h3'] }")
rep("margin: [8, 8, 8, 8],", "margin: [10, 8, 10, 8],")

# 5) Android: PDF save + share through Capacitor (anchor downloads do not work in a WebView)
old = "html2pdf().set(opt).from(pdfContainer).save().then(() => {"
new = """const done = () => {
            pdfContainer.classList.add('hidden');
            window.scrollTo(0, prevScrollY);
          };
          if (window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()) {
            html2pdf().set(opt).from(pdfContainer).outputPdf('datauristring').then(async (uri) => {
              try {
                const base64 = String(uri).split(',')[1];
                const Fs = window.Capacitor.Plugins.Filesystem;
                const Sh = window.Capacitor.Plugins.Share;
                const w = await Fs.writeFile({ path: filename, data: base64, directory: 'CACHE' });
                await Sh.share({ title: filename, url: w.uri, dialogTitle: 'AI TOX PDF' });
                showToast('PDF ready.');
              } catch (err) { showToast('Could not save PDF: ' + (err && err.message ? err.message : err)); }
              done();
            }).catch(() => { done(); showToast('PDF export failed.'); });
            return;
          }
          html2pdf().set(opt).from(pdfContainer).save().then(() => {"""
rep(old, new)

# 6) Standalone-in-Chrome button makes no sense inside the app
m = re.search(r"window\.addEventListener\('DOMContentLoaded', \(\) => \{(\s*)loadStoredState\(\);", s)
assert m, 'missing DOMContentLoaded'
inject = ("window.addEventListener('DOMContentLoaded', () => {\n"
 "      if (window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()) {\n"
 "        const b = document.getElementById('downloadChromeAppBtn'); if (b) b.style.display = 'none';\n"
 "        document.body.classList.add('safe-area');\n"
 "      }\n      loadStoredState();")
s = s[:m.start()] + inject + s[m.end():]

# 7) Android back button / viewport
rep('<meta name="viewport" content="width=device-width, initial-scale=1.0" />',
    '<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover" />')

open('src/patched.html', 'w', encoding='utf-8').write(s)
print('ok', len(s))

# 8) Owner key: only AMAX@#$ (case-sensitive, stored as SHA-256 hash, no other keys)
s = open('src/patched.html', encoding='utf-8').read()
sha_fn = r'''
    // Owner key check (SHA-256 hash only; the password itself is not stored in the page)
    const OWNER_KEY_SHA256 = '8f2e5b85a6e9af86139ffaf7949c3e4fbab75bf38051d08b7fe02ea8a617b76c';
    function sha256Hex(str) {
      const K = [], H = [];
      let n = 2, c = 0;
      while (c < 64) {
        let p = true;
        for (let i = 2; i * i <= n; i++) if (n % i === 0) { p = false; break; }
        if (p) {
          if (c < 8) H[c] = (Math.pow(n, 1 / 2) % 1 * 4294967296) | 0;
          K[c] = (Math.pow(n, 1 / 3) % 1 * 4294967296) | 0;
          c++;
        }
        n++;
      }
      const bytes = Array.from(new TextEncoder().encode(str));
      const bitLen = bytes.length * 8;
      bytes.push(0x80);
      while (bytes.length % 64 !== 56) bytes.push(0);
      for (let i = 7; i >= 0; i--) bytes.push(i >= 4 ? 0 : (bitLen >>> (i * 8)) & 255);
      const rotr = (x, k) => (x >>> k) | (x << (32 - k));
      for (let off = 0; off < bytes.length; off += 64) {
        const w = new Array(64);
        for (let i = 0; i < 16; i++) w[i] = (bytes[off + 4*i] << 24) | (bytes[off + 4*i + 1] << 16) | (bytes[off + 4*i + 2] << 8) | bytes[off + 4*i + 3];
        for (let i = 16; i < 64; i++) {
          const s0 = rotr(w[i-15], 7) ^ rotr(w[i-15], 18) ^ (w[i-15] >>> 3);
          const s1 = rotr(w[i-2], 17) ^ rotr(w[i-2], 19) ^ (w[i-2] >>> 10);
          w[i] = (w[i-16] + s0 + w[i-7] + s1) | 0;
        }
        let [a, b, c2, d, e, f, g, h] = H;
        for (let i = 0; i < 64; i++) {
          const S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
          const ch = (e & f) ^ (~e & g);
          const t1 = (h + S1 + ch + K[i] + w[i]) | 0;
          const S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
          const maj = (a & b) ^ (a & c2) ^ (b & c2);
          const t2 = (S0 + maj) | 0;
          h = g; g = f; f = e; e = (d + t1) | 0; d = c2; c2 = b; b = a; a = (t1 + t2) | 0;
        }
        H[0] = (H[0] + a) | 0; H[1] = (H[1] + b) | 0; H[2] = (H[2] + c2) | 0; H[3] = (H[3] + d) | 0;
        H[4] = (H[4] + e) | 0; H[5] = (H[5] + f) | 0; H[6] = (H[6] + g) | 0; H[7] = (H[7] + h) | 0;
      }
      return H.map(x => (x >>> 0).toString(16).padStart(8, '0')).join('');
    }
    function isOwnerKey(v) { return sha256Hex(String(v)) === OWNER_KEY_SHA256; }

    function isValidAccessCode('''
assert s.count('function isValidAccessCode(') == 1
s = s.replace('function isValidAccessCode(', sha_fn, 1)

m = re.search(r"const val = document\.getElementById\('ownerMasterPinInput'\)\.value\.trim\(\)\.toLowerCase\(\);", s)
assert m
s = s[:m.start()] + "const val = document.getElementById('ownerMasterPinInput').value;" + s[m.end():]
m = re.search(r"if \(val === '2026'[^\n]*isValidAccessCode\(val\)\) \{", s)
assert m
s = s[:m.start()] + "if (isOwnerKey(val)) {" + s[m.end():]
open('src/patched.html', 'w', encoding='utf-8').write(s)
print('owner key patched')
