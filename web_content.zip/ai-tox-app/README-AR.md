# AI TOX — تطبيق أندرويد (APK)

## الطريقة 1: على جهازك (Android Studio)
المتطلبات: Node.js 18+ و JDK 17 و Android Studio (يثبّت Android SDK).

```
npm install
npx cap add android      # مرة واحدة فقط
npm run apk:debug
```
الملف الناتج: `android/app/build/outputs/apk/debug/app-debug.apk`
(انقله إلى الموبايل وثبّته، وفعّل «التثبيت من مصادر غير معروفة»).

## الطريقة 2: بدون Android Studio (GitHub Actions)
1. ارفع هذا المجلد إلى مستودع GitHub.
2. من تبويب Actions شغّل «Build AI TOX APK».
3. نزّل `app-debug.apk` من Artifacts.

## ما الذي تغيّر في الصفحة؟
- التقرير (PDF والمعاينة داخل الصفحة): عرض ثابت بحجم A4، الجداول `table-layout: fixed`، والنصوص تلتف داخل الخلايا، والصور بعرض 100% — لا شيء يخرج عن حدود الصفحة.
- أُزيل زر «Open Standalone in Google Chrome» وزر «Load 5-Fold Example Dataset».
- زر PDF الأحمر يفتح التقرير كاملاً داخل الصفحة أولاً، ثم زر «Save / Share PDF» لحفظ الملف أو مشاركته.
- كل المكتبات والخطوط محلية، فالتطبيق يعمل بدون إنترنت. (خط STIX Two Math غير مضمّن؛ تُستخدم Cambria Math / Times New Roman بدلاً منه.)

- أُزيل الدومين من كل مكان في الصفحة والتقرير.
- حفظ PDF: «Save / Share PDF» أولاً، وإن لم يعمل على جهازك فزر «Print / Save as PDF» (طباعة الصفحة إلى PDF) أو اقرأ التقرير داخل الصفحة.

## للنشر على Google Play
APK التجريبي (debug) للتجربة فقط. للنشر تحتاج AAB موقّعاً بمفتاحك: `./gradlew bundleRelease` ثم توقيعه.
