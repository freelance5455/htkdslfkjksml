module.exports = {
  content: ['./src/patched.html'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
        math: ['"STIX Two Math"', '"Cambria Math"', '"Times New Roman"', 'serif']
      }
    }
  }
};
