PAN SHOP KHATA - ANDROID PROJECT

This project wraps the supplied one-click HTML app in a native Android WebView.
It includes INTERNET permission, DOM/local storage, JavaScript, file chooser support,
and portrait orientation.

Open the folder in Android Studio and Build > Build APK(s).
The generated debug APK will be in app/build/outputs/apk/debug/.

The HTML source is app/src/main/assets/index.html.
