# Socle 3.1 — Attitudes et émotions des damistes en 3D

## Ajouts
- Présentation successive des deux camps au lancement d'une rencontre en vue 3D.
- Posture de réflexion pendant la recherche du coup de l'IA et au tour du joueur.
- Geste des bras avant l'animation d'un déplacement comportant une ou plusieurs prises.
- Réaction de célébration du camp vainqueur, puis posture de déception du camp battu.
- Animations procédurales intégrées aux figurines WebGL existantes : aucune ressource externe ni donnée de joueur inventée.

## Compatibilité et limites
- Les règles, les coups légaux, les chronomètres, les statistiques et les moteurs de compétition ne sont pas modifiés.
- Les animations émotionnelles sont visibles uniquement lorsque la vue 3D WebGL est activée.
- Les figurines restent stylisées et géométriques : ce socle n'est pas encore une modélisation humaine photoréaliste.
- La validation automatisée ne remplace pas un contrôle visuel sur navigateur et appareil mobile réels.
