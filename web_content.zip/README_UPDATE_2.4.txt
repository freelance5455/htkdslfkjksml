LoveDark v2.4

Changes:
- Reverted calendar scheduler to a single setInterval(2000) loop (one game day per two seconds) instead of recursive setTimeout scheduling.
- Refreshes day labels after rendering, including the phone mockup, from the same saved p.day value.
- Limits work to one shift per in-game day to prevent repeatedly farming salary in a single day.
- Reduced the strongest job payouts and freelance skill multiplier; difficulty income multipliers and monthly payout remain in place.

Compatibility preserved: applicationId/namespace com.mohamed.lovedark; save keys layl_life_save_v4 and layl_life_save_v3.
Validation: JavaScript syntax and ZIP integrity checked. Actual Android/WebView runtime testing is not available in this environment.
