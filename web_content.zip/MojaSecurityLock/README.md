# Moja Security Lock — Android Studio starter

This project gives you:
- A WebView UI built with HTML/CSS/JavaScript.
- Native Java bridge for setting/verifying a 4–8 digit PIN.
- Android BiometricPrompt fingerprint/biometric authentication.
- A list of launchable apps and saved per-app lock selections.

## Important limitation

**This starter does not yet block other apps from opening.** The app list toggles save lock preferences only. Android does not allow a normal WebView/HTML page to lock other apps. Actual enforcement requires an additional Android component (commonly an explicitly user-enabled AccessibilityService or usage-access monitoring plus a lock screen/overlay), and Android background-launch and overlay restrictions vary by OS/device. Do not describe this starter APK as a fully working system-wide app locker until enforcement is implemented and tested.

## Build the APK

1. Install the current Android Studio from the official Android developer site.
2. Unzip `MojaSecurityLock.zip`.
3. In Android Studio choose **Open**, then select the `MojaSecurityLock` folder.
4. Let Gradle sync. If asked, install Android SDK Platform 35 and a compatible JDK.
5. Connect your Android phone, enable Developer options and USB debugging, then press **Run**.
6. To create an APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
7. Android Studio shows the output location, usually `app/build/outputs/apk/debug/app-debug.apk`.
8. Transfer the APK to your phone and install it. Android may ask you to allow installation from that file manager.

## Test

- Launch Moja Security Lock and set a 4–8 digit PIN.
- Set up a fingerprint in Android Settings first.
- Unlock with PIN or fingerprint.
- View installed launchable apps and toggle saved lock preferences.

## Security notes

- PIN is stored as a SHA-256 hash in app-private SharedPreferences. This is a starter implementation, not a hardened credential store; production should use a salted, slow password hash or Android Keystore-backed design with rate limiting.
- `QUERY_ALL_PACKAGES` is restricted by Google Play policy. If distributing on Play, check current policy and request only permitted package visibility.
- BiometricPrompt confirms the device biometric, but this sample does not use biometric-gated encryption for stored app selections.
- The WebView only loads a local asset. Do not add untrusted remote pages or expose this JavaScript bridge to them.
- Test across Android versions and OEM devices before relying on it for privacy.
