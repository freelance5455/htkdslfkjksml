package com.moja.securitylock;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ApplicationInfo;
import android.content.pm.ResolveInfo;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import android.content.SharedPreferences;
import android.util.Base64;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.Executor;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private SharedPreferences prefs;
    private final String PREFS = "moja_secure_prefs";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        webView = new WebView(this);
        setContentView(webView);
        webView.getSettings().setJavaScriptEnabled(true);
        // The WebView loads only a local asset; do not load untrusted web pages here.
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AndroidBridge(), "MojaAndroid");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private String hashPin(String pin) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(pin.getBytes(StandardCharsets.UTF_8));
            return Base64.encodeToString(bytes, Base64.NO_WRAP);
        } catch (Exception e) {
            return "";
        }
    }

    private boolean validPin(String pin) {
        return pin != null && pin.matches("\\d{4,8}");
    }

    private void sendJs(String function, String value) {
        final String safe = JSONObject.quote(value == null ? "" : value);
        runOnUiThread(() -> webView.evaluateJavascript(function + "(" + safe + ")", null));
    }

    public class AndroidBridge {
        @JavascriptInterface
        public boolean hasPin() {
            return !prefs.getString("pin_hash", "").isEmpty();
        }

        @JavascriptInterface
        public String setPin(String pin) {
            if (!validPin(pin)) return "PIN must be 4 to 8 digits.";
            prefs.edit().putString("pin_hash", hashPin(pin)).apply();
            return "PIN saved on this device.";
        }

        @JavascriptInterface
        public boolean verifyPin(String pin) {
            if (!validPin(pin)) return false;
            String saved = prefs.getString("pin_hash", "");
            return !saved.isEmpty() && saved.equals(hashPin(pin));
        }

        @JavascriptInterface
        public String listApps() {
            JSONArray result = new JSONArray();
            try {
                Intent intent = new Intent(Intent.ACTION_MAIN, null);
                intent.addCategory(Intent.CATEGORY_LAUNCHER);
                PackageManager pm = getPackageManager();
                List<ResolveInfo> apps = pm.queryIntentActivities(intent, 0);
                Collections.sort(apps, (a, b) ->
                    String.valueOf(a.loadLabel(pm)).compareToIgnoreCase(String.valueOf(b.loadLabel(pm))));
                for (ResolveInfo info : apps) {
                    String pkg = info.activityInfo.packageName;
                    if (pkg.equals(getPackageName())) continue;
                    JSONObject item = new JSONObject();
                    item.put("name", String.valueOf(info.loadLabel(pm)));
                    item.put("packageName", pkg);
                    item.put("locked", prefs.getBoolean("locked_" + pkg, false));
                    result.put(item);
                }
            } catch (Exception ignored) {}
            return result.toString();
        }

        @JavascriptInterface
        public boolean setAppLocked(String packageName, boolean locked) {
            if (packageName == null || packageName.length() > 255 || packageName.contains("..")) return false;
            prefs.edit().putBoolean("locked_" + packageName, locked).apply();
            return true;
        }

        @JavascriptInterface
        public boolean isBiometricAvailable() {
            int result = BiometricManager.from(MainActivity.this)
                .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG
                    | BiometricManager.Authenticators.BIOMETRIC_WEAK);
            return result == BiometricManager.BIOMETRIC_SUCCESS;
        }

        @JavascriptInterface
        public void authenticateBiometric() {
            runOnUiThread(() -> {
                Executor executor = ContextCompat.getMainExecutor(MainActivity.this);
                BiometricPrompt prompt = new BiometricPrompt(MainActivity.this, executor,
                    new BiometricPrompt.AuthenticationCallback() {
                        @Override
                        public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                            super.onAuthenticationSucceeded(result);
                            sendJs("onBiometricResult", "success");
                        }
                        @Override
                        public void onAuthenticationFailed() {
                            super.onAuthenticationFailed();
                            sendJs("onBiometricResult", "failed");
                        }
                        @Override
                        public void onAuthenticationError(int errorCode, CharSequence errString) {
                            super.onAuthenticationError(errorCode, errString);
                            sendJs("onBiometricResult", "error:" + errString);
                        }
                    });
                BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                    .setTitle("Moja Security Lock")
                    .setSubtitle("Verify your identity")
                    .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG
                        | BiometricManager.Authenticators.BIOMETRIC_WEAK)
                    .setNegativeButtonText("Use PIN")
                    .build();
                prompt.authenticate(info);
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
