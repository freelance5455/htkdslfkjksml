let allApps = [];
function el(id){ return document.getElementById(id); }
function show(id){ el(id).classList.remove('hidden'); }
function hide(id){ el(id).classList.add('hidden'); }
function init(){
  if(!window.MojaAndroid){ el('setupMsg').textContent='Open this page inside the Android app.'; return; }
  if(MojaAndroid.hasPin()){ show('unlockPanel'); hide('setupPanel'); } else { show('setupPanel'); hide('unlockPanel'); }
}
function savePin(){
  const a=el('pin1').value, b=el('pin2').value;
  if(!/^\d{4,8}$/.test(a)){el('setupMsg').textContent='PIN must contain 4–8 digits.';return;}
  if(a!==b){el('setupMsg').textContent='PINs do not match.';return;}
  const result=MojaAndroid.setPin(a);
  el('setupMsg').textContent=result;
  el('pin1').value='';el('pin2').value='';
  show('unlockPanel');hide('setupPanel');
}
function unlockWithPin(){
  if(MojaAndroid.verifyPin(el('unlockPin').value)){
    el('unlockMsg').textContent='Unlocked.';hide('unlockPanel');show('mainPanel');loadApps();
  }else el('unlockMsg').textContent='Incorrect PIN. Try again.';
  el('unlockPin').value='';
}
function biometric(){
  if(!MojaAndroid.isBiometricAvailable()){el('unlockMsg').textContent='No enrolled fingerprint/biometric is available. Set it up in Android Settings.';return;}
  MojaAndroid.authenticateBiometric();
}
function onBiometricResult(result){
  if(result==='success'){hide('unlockPanel');show('mainPanel');loadApps();}
  else if(result==='failed'){el('unlockMsg').textContent='Biometric not recognized. Try again or use PIN.';}
  else {el('unlockMsg').textContent=result.replace('error:','');}
}
function loadApps(){
  try{allApps=JSON.parse(MojaAndroid.listApps()||'[]');renderApps(allApps);}
  catch(e){el('apps').innerHTML='<p class="muted">Could not load apps. Check Android package visibility settings.</p>';}
}
function filterApps(){const q=el('search').value.toLowerCase();renderApps(allApps.filter(a=>(a.name+' '+a.packageName).toLowerCase().includes(q)));}
function renderApps(apps){
  const root=el('apps');root.innerHTML='';
  if(!apps.length){root.innerHTML='<p class="muted">No launchable apps found.</p>';return;}
  apps.forEach(app=>{
    const row=document.createElement('div');row.className='appRow';
    const info=document.createElement('div');info.style.flex='1';
    const name=document.createElement('div');name.className='appName';name.textContent=app.name;
    const pkg=document.createElement('div');pkg.className='pkg';pkg.textContent=app.packageName;
    info.append(name,pkg);
    const btn=document.createElement('button');btn.className='toggle'+(app.locked?' on':'');btn.textContent=app.locked?'Locked':'Unlocked';
    btn.setAttribute('aria-pressed',String(app.locked));
    btn.onclick=()=>{const next=!app.locked;if(MojaAndroid.setAppLocked(app.packageName,next)){app.locked=next;btn.textContent=next?'Locked':'Unlocked';btn.classList.toggle('on',next);btn.setAttribute('aria-pressed',String(next));}};
    row.append(info,btn);root.appendChild(row);
  });
}
function changePin(){hide('mainPanel');show('setupPanel');el('setupMsg').textContent='Set a new PIN.';el('pin1').value='';el('pin2').value='';}
window.onBiometricResult=onBiometricResult;
window.addEventListener('load',init);
