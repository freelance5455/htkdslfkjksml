"use strict";

(() => {
  const $ = id => document.getElementById(id);

  const SIZE = 8;
  const BEST_KEY = "bb_premium_best_v1";
  const SOUND_KEY = "bb_premium_sound_v1";

  const COLORS = [
    "#4f91e8", "#f0ad3d", "#45b98b",
    "#ed7295", "#9474e8", "#36b8c8", "#e9814e"
  ];

  const COMBO_COLORS = [
    "#f0ad3d", "#ed7295", "#9474e8",
    "#45b98b", "#36b8c8", "#4f91e8", "#e9814e"
  ];

  const RAINBOW = [
    "#ff526f", "#ffad42", "#ffe85b",
    "#4fffb0", "#42dfff", "#a77aff", "#ff68dc"
  ];

  const BLOCK_SHAPES = [
    [[0,0],[1,0],[2,0],[2,1]],
    [[0,0],[0,1],[0,2],[1,0]],
    [[0,1],[1,1],[2,0],[2,1]],
    [[0,2],[1,0],[1,1],[1,2]],

    [[0,1],[1,1],[2,0],[2,1]],
    [[0,0],[1,0],[1,1],[1,2]],
    [[0,0],[0,1],[1,0],[2,0]],
    [[0,0],[0,1],[0,2],[1,2]],

    [[0,0],[0,1],[1,0],[1,1]],

    [
      [0,0],[0,1],[0,2],[0,3],
      [1,0],[1,1],[1,2],[1,3],
      [2,0],[2,1],[2,2],[2,3],
      [3,0],[3,1],[3,2],[3,3]
    ],

    [[0,0],[0,1],[0,2],[1,1]],
    [[0,0],[1,0],[1,1],[2,0]],
    [[0,1],[1,0],[1,1],[1,2]],
    [[0,1],[1,0],[1,1],[2,1]],

    [[0,1],[0,2],[1,0],[1,1]],
    [[0,0],[1,0],[1,1],[2,1]],
    [[0,0],[0,1],[1,1],[1,2]],
    [[0,1],[1,0],[1,1],[2,0]],

    [[0,0]],
    [[0,0],[0,1]],
    [[0,0],[0,1],[0,2]],
    [[0,0],[0,1],[0,2],[0,3]],
    [[0,0],[0,1],[0,2],[0,3],[0,4]]
  ];

  const boardEl = $("board");
  const boardWrap = $("boardWrap");
  const piecesEl = $("pieces");
  const scoreEl = $("score");
  const bestEl = $("best");
  const comboEl = $("combo");
  const scorePopup = $("scorePopup");
  const messageEl = $("subtitle");
  const globalParticles = $("floatLayerGlobal");

  let board = [];
  let pieces = [];
  let score = 0;
  let best = loadBest();

  let blockColor = COLORS[0];
  let comboColorIndex = 0;
  let soundEnabled = loadSoundSetting();

  let audioContext = null;
  let gameEnded = false;
  let clearing = false;
  let drag = null;
  let previewCells = [];
  let particleCount = 0;
  let scoreAnimationId = 0;
  let strikeCount = 0;
  let dragsWithoutStrike = 0;
  let moveMadeStrike = false;
  let lastPraise = "";
  let gameStartBest = best;

  let comboTimer = null;
  let popupTimer = null;
  let invalidTimer = null;
let gameOverTimer = null;

  /* =========================
     STORAGE
  ========================= */

  function loadBest() {
    try {
      const n = Number(localStorage.getItem(BEST_KEY));
      return Number.isFinite(n) && n > 0 ? n : 0;
    } catch (_) {
      return 0;
    }
  }

  function loadSoundSetting() {
    try {
      const value = localStorage.getItem(SOUND_KEY);
      return value === null ? true : value === "true";
    } catch (_) {
      return true;
    }
  }

  function saveBest() {
    try {
      localStorage.setItem(BEST_KEY, String(best));
    } catch (_) {}
  }

  function saveSoundSetting() {
    try {
      localStorage.setItem(SOUND_KEY, String(soundEnabled));
    } catch (_) {}
  }

  /* =========================
     HELPERS
  ========================= */

  function randomItem(array) {
    return array[Math.floor(Math.random() * array.length)];
  }

  function dimensions(shape) {
    let rows = 0;
    let cols = 0;

    shape.forEach(([r, c]) => {
      rows = Math.max(rows, r + 1);
      cols = Math.max(cols, c + 1);
    });

    return { rows, cols };
  }

  function formatNumber(n) {
    return Math.floor(n).toLocaleString("id-ID");
  }

  function setSubtitle(text) {
    if (messageEl) messageEl.textContent = text;
  }

  function getCell(row, col) {
    if (
      !boardEl ||
      row < 0 || row >= SIZE ||
      col < 0 || col >= SIZE
    ) return null;

    return boardEl.querySelector(
      `.cell[data-row="${row}"][data-col="${col}"]`
    );
  }

  /* =========================
     SCORE
  ========================= */

  function updateScore(animate = false) {
    if (!scoreEl) return;

    if (scoreAnimationId) {
      cancelAnimationFrame(scoreAnimationId);
      scoreAnimationId = 0;
    }

    if (!animate) {
      scoreEl.textContent = formatNumber(score);
    } else {
      const start =
        Number(scoreEl.textContent.replace(/\D/g, "")) || 0;

      const startedAt = performance.now();
      const duration = 220;

      function tick(now) {
        const p = Math.min(1, (now - startedAt) / duration);
        const eased = 1 - Math.pow(1 - p, 3);

        scoreEl.textContent = formatNumber(
          start + (score - start) * eased
        );

        if (p < 1) {
          scoreAnimationId = requestAnimationFrame(tick);
        } else {
          scoreAnimationId = 0;
          scoreEl.classList.remove("score-bump");
          void scoreEl.offsetWidth;
          scoreEl.classList.add("score-bump");
        }
      }

      scoreAnimationId = requestAnimationFrame(tick);
    }

    if (bestEl) bestEl.textContent = formatNumber(best);
    if ($("homeBest")) $("homeBest").textContent = formatNumber(best);
    if ($("gameOverBest")) {
      $("gameOverBest").textContent = formatNumber(best);
    }
  }

  function saveNewBest() {
    if (score > best) {
      best = score;
      saveBest();
    }

    updateScore(true);
  }

  // Skor dipercepat agar lebih mudah mencapai 500.000.
  function getPlacementScore(blockCount) {
    return blockCount * 1000;
  }

  function getClearScore(lineCount) {
    const rewards = {
      1: 10000,
      2: 30000,
      3: 70000,
      4: 150000,
      5: 200000,
      6: 250000,
      7: 300000,
      8: 400000,
      9: 450000,
      10: 500000,
      11: 550000,
      12: 600000,
      13: 650000,
      14: 700000,
      15: 750000,
      16: 800000
    };

    return rewards[Math.min(lineCount, 16)] || 800000;
  }

  function addGameScore(points) {
    score += Math.max(0, Number(points) || 0);
    saveNewBest();
  }

  /* =========================
     SOUND: MP3
     Taruh file MP3 di folder sounds.
     Tidak memakai suara sintetis sebagai
     pengganti untuk ketiga efek utama.
  ========================= */

  const gameAudio = {
    block: new Audio("sounds/block.mp3"),
    clear: new Audio("sounds/clear.mp3"),
    unbelievable: new Audio("sounds/unbelievable.mp3")
  };

  gameAudio.block.volume = 0.75;
  gameAudio.clear.volume = 0.85;
  gameAudio.unbelievable.volume = 1;

  Object.values(gameAudio).forEach(audio => {
    audio.preload = "auto";
  });

  function playMP3(type) {
    if (!soundEnabled) return;

    const audio = gameAudio[type];
    if (!audio) return;

    try {
      audio.pause();
      audio.currentTime = 0;

      const result = audio.play();
      if (result && typeof result.catch === "function") {
        result.catch(() => {
          // File MP3 mungkin belum tersedia atau belum bisa diputar.
        });
      }
    } catch (_) {}
  }

  function playPlaceSound() {
    playMP3("block");
  }

  function playClearSound() {
    playMP3("clear");
  }

  function playUnbelievableSound() {
    playMP3("unbelievable");
  }

  // Suara menu dan penolakan posisi tetap berupa bunyi pendek.
  function getAudioContext() {
    if (!soundEnabled) return null;

    try {
      const AudioClass =
        window.AudioContext || window.webkitAudioContext;

      if (!AudioClass) return null;

      if (!audioContext) audioContext = new AudioClass();

      if (audioContext.state === "suspended") {
        audioContext.resume().catch(() => {});
      }

      return audioContext;
    } catch (_) {
      return null;
    }
  }

  function tone(
    freq,
    duration,
    type = "sine",
    volume = 0.025,
    endFreq = null
  ) {
    const ctx = getAudioContext();
    if (!ctx) return;

    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const now = ctx.currentTime;

      osc.type = type;
      osc.frequency.setValueAtTime(freq, now);

      if (endFreq) {
        osc.frequency.exponentialRampToValueAtTime(
          Math.max(1, endFreq),
          now + duration
        );
      }

      gain.gain.setValueAtTime(volume, now);
      gain.gain.exponentialRampToValueAtTime(
        0.001,
        now + duration
      );

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + duration);
    } catch (_) {}
  }

  function playInvalidSound() {
    tone(180, 0.12, "sine", 0.035, 115);
  }

  function playMenuSound() {
    tone(500, 0.07, "sine", 0.025, 650);
  }

  /* =========================
     BOARD
  ========================= */

  function createEmptyBoard() {
    board = Array.from(
      { length: SIZE },
      () => Array(SIZE).fill(null)
    );
  }

  function renderBoard(animatedCells = []) {
    if (!boardEl) return;

    const fragment = document.createDocumentFragment();

    for (let r = 0; r < SIZE; r++) {
      for (let c = 0; c < SIZE; c++) {
        const cell = document.createElement("div");

        cell.className = "cell";
        cell.dataset.row = r;
        cell.dataset.col = c;

        if (board[r][c]) {
          cell.classList.add("filled");
          cell.style.setProperty("--block-color", board[r][c]);
        }

        if (animatedCells.some(p => p.r === r && p.c === c)) {
          cell.classList.add("placed-pop");

          cell.addEventListener("animationend", () => {
            cell.classList.remove("placed-pop");
          }, { once: true });
        }

        fragment.appendChild(cell);
      }
    }

    boardEl.replaceChildren(fragment);
  }

  /* =========================
     DIFFICULTY
  ========================= */

  function getDifficulty() {
    if (score >= 500000) {
      return {
        level: 3,
        label: "MODE STRATEGI",
        shapes: BLOCK_SHAPES.filter(shape => shape.length >= 3)
      };
    }

    if (score >= 100000) {
      return {
        level: 2,
        label: "MODE MENANTANG",
        shapes: BLOCK_SHAPES.filter(shape => shape.length <= 5)
      };
    }

    return {
      level: 1,
      label: "MODE SANTAI",
      shapes: BLOCK_SHAPES.filter(shape => shape.length <= 5)
    };
  }

  /* =========================
     PIECES
  ========================= */

  function canPlace(shape, row, col) {
    return shape.every(([r, c]) => {
      const rr = row + r;
      const cc = col + c;

      return (
        rr >= 0 && rr < SIZE &&
        cc >= 0 && cc < SIZE &&
        !board[rr][cc]
      );
    });
  }

  function canFitSomewhere(shape) {
    for (let r = 0; r < SIZE; r++) {
      for (let c = 0; c < SIZE; c++) {
        if (canPlace(shape, r, c)) return true;
      }
    }

    return false;
  }

  function makePiece() {
    const difficulty = getDifficulty();

    // Pilih blok yang masih bisa ditempatkan jika memungkinkan.
    const availableShapes = difficulty.shapes.filter(shape =>
      canFitSomewhere(shape)
    );

    const shape = randomItem(
      availableShapes.length ? availableShapes : difficulty.shapes
    );

    return {
      shape: shape.map(([r, c]) => [r, c]),
      used: false,
      color: blockColor
    };
  }

  function makePieces() {
    pieces = [makePiece(), makePiece(), makePiece()];
    renderPieces();
  }

  function renderPieces() {
    if (!piecesEl) return;

    cleanupDrag();
    piecesEl.replaceChildren();

    const fragment = document.createDocumentFragment();

    pieces.forEach((piece, index) => {
      const slot = document.createElement("div");
      slot.className = "piece-slot piece";
      slot.dataset.index = index;

      if (piece.used) slot.classList.add("used");

      const { rows, cols } = dimensions(piece.shape);
      const grid = document.createElement("div");

      grid.className = "piece-grid";
      grid.style.gridTemplateColumns =
        `repeat(${cols}, clamp(12px, 3.9vw, 20px))`;
      grid.style.gridTemplateRows =
        `repeat(${rows}, clamp(12px, 3.9vw, 20px))`;

      const occupied = new Set(
        piece.shape.map(([r, c]) => `${r},${c}`)
      );

      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          const block = document.createElement("div");

          if (occupied.has(`${r},${c}`)) {
            block.className = "mini-block";
            block.dataset.row = r;
            block.dataset.col = c;
            block.style.setProperty("--block-color", piece.color);
          } else {
            block.style.visibility = "hidden";
            block.style.pointerEvents = "none";
          }

          grid.appendChild(block);
        }
      }

      slot.appendChild(grid);

      slot.addEventListener("pointerdown", event => {
        const block = event.target.closest(".mini-block");

        if (
          !block || gameEnded || clearing ||
          piece.used || drag
        ) return;

        startDrag(
          event,
          index,
          Number(block.dataset.row),
          Number(block.dataset.col),
          block
        );
      });

      fragment.appendChild(slot);
    });

    piecesEl.appendChild(fragment);

    if ($("pieceCounter")) {
      $("pieceCounter").textContent =
        `${pieces.filter(p => !p.used).length} BLOK`;
    }
  }

  /* =========================
     DRAG AND DROP
  ========================= */

  function getMetrics() {
    const a = getCell(0, 0);
    const b = getCell(0, 1);
    const c = getCell(1, 0);

    if (!a || !b || !c) {
      return { w: 0, h: 0, gapX: 0, gapY: 0 };
    }

    const ar = a.getBoundingClientRect();
    const br = b.getBoundingClientRect();
    const cr = c.getBoundingClientRect();

    return {
      w: ar.width,
      h: ar.height,
      gapX: br.left - ar.right,
      gapY: cr.top - ar.bottom
    };
  }

  function startDrag(event, index, grabRow, grabCol, sourceBlock) {
    if (drag || clearing || gameEnded) return;

    event.preventDefault();

    const piece = pieces[index];
    if (!piece || piece.used) return;

    const rect = sourceBlock.getBoundingClientRect();
    const metrics = getMetrics();

    if (!metrics.w || !metrics.h || !rect.width || !rect.height) {
      return;
    }

    drag = {
      index,
      piece,
      grabRow,
      grabCol,
      pointerId: event.pointerId,
      offsetX: (event.clientX - rect.left) * metrics.w / rect.width,
      offsetY: (event.clientY - rect.top) * metrics.h / rect.height,
      cellW: metrics.w,
      cellH: metrics.h,
      gapX: metrics.gapX,
      gapY: metrics.gapY
    };

    createGhost();
    moveGhost(event.clientX, event.clientY);
    updatePreview(event.clientX, event.clientY);

    window.addEventListener("pointermove", onDragMove, {
      passive: false
    });
    window.addEventListener("pointerup", onDragEnd);
    window.addEventListener("pointercancel", onDragCancel);
  }

  function createGhost() {
    removeGhost();
    if (!drag) return;

    const ghost = document.createElement("div");
    ghost.id = "activeGhost";
    ghost.className = "drag-ghost";

    const { rows, cols } = dimensions(drag.piece.shape);

    ghost.style.gridTemplateColumns =
      `repeat(${cols}, ${drag.cellW}px)`;
    ghost.style.gridTemplateRows =
      `repeat(${rows}, ${drag.cellH}px)`;
    ghost.style.columnGap = `${drag.gapX}px`;
    ghost.style.rowGap = `${drag.gapY}px`;

    const occupied = new Set(
      drag.piece.shape.map(([r, c]) => `${r},${c}`)
    );

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const block = document.createElement("div");

        block.style.width = `${drag.cellW}px`;
        block.style.height = `${drag.cellH}px`;

        if (occupied.has(`${r},${c}`)) {
          block.className = "ghost-block";
          block.style.setProperty(
            "--block-color",
            drag.piece.color
          );
        } else {
          block.style.visibility = "hidden";
        }

        ghost.appendChild(block);
      }
    }

    document.body.appendChild(ghost);
  }

  function removeGhost() {
    $("activeGhost")?.remove();
  }

  function moveGhost(x, y) {
    if (!drag) return;

    const ghost = $("activeGhost");
    if (!ghost) return;

    const strideX = drag.cellW + drag.gapX;
    const strideY = drag.cellH + drag.gapY;

    ghost.style.left =
      `${x - drag.offsetX - drag.grabCol * strideX}px`;
    ghost.style.top =
      `${y - drag.offsetY - drag.grabRow * strideY}px`;
  }

  function getPointerCell(x, y) {
    const first = getCell(0, 0);
    const m = getMetrics();

    if (!first || !m.w || !m.h) return null;

    const rect = first.getBoundingClientRect();

    const col = Math.floor(
      (x - rect.left) / (m.w + m.gapX)
    );

    const row = Math.floor(
      (y - rect.top) / (m.h + m.gapY)
    );

    if (row < 0 || row >= SIZE || col < 0 || col >= SIZE) {
      return null;
    }

    const cell = getCell(row, col);
    if (!cell) return null;

    const cr = cell.getBoundingClientRect();

    if (
      x < cr.left || x > cr.right ||
      y < cr.top || y > cr.bottom
    ) return null;

    return { row, col };
  }

  function getDropPosition(x, y) {
    if (!drag) return null;

    const point = getPointerCell(x, y);
    if (!point) return null;

    return {
      row: point.row - drag.grabRow,
      col: point.col - drag.grabCol
    };
  }

  function onDragMove(event) {
    if (!drag || event.pointerId !== drag.pointerId) return;

    event.preventDefault();
    moveGhost(event.clientX, event.clientY);
    updatePreview(event.clientX, event.clientY);
  }

  function onDragEnd(event) {
    if (!drag || event.pointerId !== drag.pointerId) return;

    const current = drag;
    const pos = getDropPosition(event.clientX, event.clientY);

    cleanupDrag();

    if (!pos) {
      showInvalidDrop(null, null, "outside");
      return;
    }

    if (!canPlace(current.piece.shape, pos.row, pos.col)) {
      const collision = overlapsOccupied(
        current.piece.shape,
        pos.row,
        pos.col
      );

      showInvalidDrop(
        current.piece.shape,
        pos,
        collision ? "collision" : "outside"
      );

      return;
    }

    placePiece(current.index, pos.row, pos.col);
  }

  function onDragCancel() {
    cleanupDrag();
  }

  function cleanupDrag() {
    clearPreview();
    removeGhost();
    drag = null;

    window.removeEventListener("pointermove", onDragMove);
    window.removeEventListener("pointerup", onDragEnd);
    window.removeEventListener("pointercancel", onDragCancel);
  }

  function overlapsOccupied(shape, row, col) {
    return shape.some(([r, c]) => {
      const rr = row + r;
      const cc = col + c;

      return (
        rr >= 0 && rr < SIZE &&
        cc >= 0 && cc < SIZE &&
        Boolean(board[rr][cc])
      );
    });
  }

  /* =========================
     PREVIEW
  ========================= */

  function clearPreview() {
    previewCells.forEach(cell => {
      cell.classList.remove(
        "preview",
        "bad-preview",
        "rainbow-preview",
        "line-preview"
      );

      cell.style.removeProperty("--line-color");
      cell.style.removeProperty("--preview-color");
    });

    previewCells = [];
  }

  function updatePreview(x, y) {
    clearPreview();
    if (!drag) return;

    const pos = getDropPosition(x, y);
    if (!pos) return;

    const shape = drag.piece.shape;

    const inside = shape.every(([r, c]) => {
      const rr = pos.row + r;
      const cc = pos.col + c;

      return rr >= 0 && rr < SIZE && cc >= 0 && cc < SIZE;
    });

    if (!inside || overlapsOccupied(shape, pos.row, pos.col)) {
      shape.forEach(([r, c]) => {
        const cell = getCell(pos.row + r, pos.col + c);
        if (!cell) return;

        cell.classList.add("bad-preview");
        previewCells.push(cell);
      });

      return;
    }

    const simulated = board.map(row => row.slice());

    shape.forEach(([r, c]) => {
      simulated[pos.row + r][pos.col + c] = drag.piece.color;
    });

    const fullRows = [];
    const fullCols = [];

    for (let r = 0; r < SIZE; r++) {
      if (simulated[r].every(Boolean)) fullRows.push(r);
    }

    for (let c = 0; c < SIZE; c++) {
      if (simulated.every(row => Boolean(row[c]))) fullCols.push(c);
    }

    fullRows.forEach(r => {
      for (let c = 0; c < SIZE; c++) {
        const cell = getCell(r, c);
        if (!cell) continue;

        cell.classList.add("line-preview");
        cell.style.setProperty(
          "--line-color",
          RAINBOW[c % RAINBOW.length]
        );

        if (!previewCells.includes(cell)) previewCells.push(cell);
      }
    });

    fullCols.forEach(c => {
      for (let r = 0; r < SIZE; r++) {
        const cell = getCell(r, c);
        if (!cell) continue;

        cell.classList.add("line-preview");
        cell.style.setProperty(
          "--line-color",
          RAINBOW[r % RAINBOW.length]
        );

        if (!previewCells.includes(cell)) previewCells.push(cell);
      }
    });

    shape.forEach(([r, c]) => {
      const cell = getCell(pos.row + r, pos.col + c);
      if (!cell) return;

      if (!cell.classList.contains("line-preview")) {
        cell.classList.add("preview");
      }

      if (!previewCells.includes(cell)) previewCells.push(cell);
    });
  }

  function showInvalidDrop(shape, pos, reason) {
    const marked = [];

    if (shape && pos) {
      shape.forEach(([r, c]) => {
        const cell = getCell(pos.row + r, pos.col + c);
        if (!cell) return;

        cell.classList.add("bad-preview");
        marked.push(cell);
      });
    }

    boardWrap?.classList.remove("invalid-shake");
    void boardWrap?.offsetWidth;
    boardWrap?.classList.add("invalid-shake");
    boardEl?.classList.add("outside-flash");

    playInvalidSound();

    setSubtitle(
      reason === "collision"
        ? "Blok bertabrakan! Coba posisi lain."
        : "Blok keluar papan! Coba lagi."
    );

    if (navigator.vibrate) navigator.vibrate([35, 25, 35]);

    clearTimeout(invalidTimer);

    invalidTimer = setTimeout(() => {
      marked.forEach(cell => cell.classList.remove("bad-preview"));
      boardWrap?.classList.remove("invalid-shake");
      boardEl?.classList.remove("outside-flash");

      if (!gameEnded && !clearing) {
        setSubtitle("Susun blok dan pecahkan garis!");
      }
    }, 450);
  }
  
    /* =========================
     PLACE BLOCK
  ========================= */

  function placePiece(index, row, col) {
    if (gameEnded || clearing) return;

    const piece = pieces[index];
    if (!piece || piece.used) return;
    if (!canPlace(piece.shape, row, col)) return;

    moveMadeStrike = false;

    const placedCells = [];

    piece.shape.forEach(([r, c]) => {
      board[row + r][col + c] = piece.color;
      placedCells.push({ r: row + r, c: col + c });
    });

    piece.used = true;

    addGameScore(getPlacementScore(piece.shape.length));

    renderBoard(placedCells);
    renderPieces();
    playPlaceSound();

    const lines = findFullLines();

    if (lines.rows.length || lines.cols.length) {
      clearLines(lines);
    } else {
      afterMove();
    }
  }

  /* =========================
     LINE CLEAR
  ========================= */

  function findFullLines() {
    const rows = [];
    const cols = [];

    for (let r = 0; r < SIZE; r++) {
      if (board[r].every(Boolean)) rows.push(r);
    }

    for (let c = 0; c < SIZE; c++) {
      if (board.every(row => Boolean(row[c]))) cols.push(c);
    }

    return { rows, cols };
  }

  function clearLines(lines) {
    if (clearing || gameEnded) return;

    const rows = lines.rows || [];
    const cols = lines.cols || [];
    const totalLines = rows.length + cols.length;

    if (!totalLines) {
      afterMove();
      return;
    }

    clearing = true;
    moveMadeStrike = true;
    dragsWithoutStrike = 0;
    strikeCount++;

    const cellsToClear = new Set();

    rows.forEach(r => {
      for (let c = 0; c < SIZE; c++) {
        cellsToClear.add(`${r},${c}`);
      }
    });

    cols.forEach(c => {
      for (let r = 0; r < SIZE; r++) {
        cellsToClear.add(`${r},${c}`);
      }
    });

    const clearedCount = cellsToClear.size;
    const bonus = getClearScore(totalLines) + clearedCount * 100;

    addGameScore(bonus);

    cellsToClear.forEach(key => {
      const [r, c] = key.split(",").map(Number);
      const cell = getCell(r, c);

      if (cell) {
        cell.classList.add("clearing");
        createParticlesAtCell(cell);
      }
    });

    if (totalLines >= 4) {
      showPraise("UNBELIEVABLE!", bonus);
      playUnbelievableSound();

      comboColorIndex =
        (comboColorIndex + 1) % COMBO_COLORS.length;

      blockColor = COMBO_COLORS[comboColorIndex];

      pieces.forEach(piece => {
        if (!piece.used) piece.color = blockColor;
      });
    } else {
      const praise =
        totalLines >= 3 ? "SMART!" :
        totalLines === 2 ? "GOOD!" :
        "NICE!";

      showPraise(praise, bonus);
      playClearSound();
    }

    showCombo(
      strikeCount >= 3
        ? `🔥 STRIKE ${strikeCount}×`
        : `COMBO +${totalLines}`
    );

    setTimeout(() => {
      cellsToClear.forEach(key => {
        const [r, c] = key.split(",").map(Number);
        board[r][c] = null;
      });

      renderBoard();
      clearing = false;
      afterMove();
    }, 360);
  }
  
    /* =========================
     PRAISE, POPUP, COMBO
  ========================= */

  function showPraise(text, points) {
    lastPraise = text;

    if (scorePopup) {
      scorePopup.textContent = `${text} +${formatNumber(points)}`;
      scorePopup.classList.remove("show");
      void scorePopup.offsetWidth;
      scorePopup.classList.add("show");

      clearTimeout(popupTimer);

      popupTimer = setTimeout(() => {
        scorePopup.classList.remove("show");
      }, 1600);
    }

    setSubtitle(text);
  }

  function showCombo(text) {
    if (!comboEl) return;

    comboEl.textContent = text;
    comboEl.style.color = COMBO_COLORS[comboColorIndex];

    comboEl.classList.remove("show");
    void comboEl.offsetWidth;
    comboEl.classList.add("show");

    clearTimeout(comboTimer);

    comboTimer = setTimeout(() => {
      comboEl.classList.remove("show");
    }, 1600);
  }

  /* =========================
     PARTICLES
  ========================= */

  function createParticlesAtCell(cell) {
    if (!globalParticles || particleCount >= 120) return;

    const rect = cell.getBoundingClientRect();

    for (let i = 0; i < 4 && particleCount < 120; i++) {
      const particle = document.createElement("div");

      particle.className = "particle";
      particle.style.position = "fixed";
      particle.style.left = `${rect.left + rect.width / 2}px`;
      particle.style.top = `${rect.top + rect.height / 2}px`;
      particle.style.pointerEvents = "none";
      particle.style.zIndex = "9999";
      particle.style.background = randomItem(RAINBOW);
      particle.style.setProperty(
        "--dx",
        `${Math.random() * 90 - 45}px`
      );
      particle.style.setProperty(
        "--dy",
        `${Math.random() * 90 - 45}px`
      );

      particleCount++;
      globalParticles.appendChild(particle);

      const remove = () => {
        if (particle.isConnected) {
          particle.remove();
          particleCount = Math.max(0, particleCount - 1);
        }
      };

      particle.addEventListener("animationend", remove, { once: true });
      setTimeout(remove, 1100);
    }
  }


  /* =========================
     GAME FLOW
  ========================= */

  function afterMove() {
    if (gameEnded || clearing) return;

    if (!moveMadeStrike) {
      dragsWithoutStrike++;

      if (dragsWithoutStrike >= 3) {
        strikeCount = 0;
        dragsWithoutStrike = 0;

        if (comboEl) {
          comboEl.textContent = "";
          comboEl.classList.remove("show", "strike-glow");
        }
      }
    }

    if (pieces.length && pieces.every(piece => piece.used)) {
      makePieces();
    } else {
      renderPieces();
    }

    updateScore();

    if (isGameOver()) {
      endGame();
      return;
    }

    if (score >= 500000) {
      setSubtitle("🔥 MODE STRATEGI — Rencanakan langkahmu!");
    } else if (score >= 100000) {
      setSubtitle("⚡ MODE MENANTANG — Kamu makin jago!");
    } else {
      setSubtitle(lastPraise || "Susun blok dan pecahkan garis!");
    }
  }

  function isGameOver() {
    const remaining = pieces.filter(piece => !piece.used);

    if (!remaining.length) return false;

    return !remaining.some(piece => canFitSomewhere(piece.shape));
  }

  /* =========================
     GAME OVER
  ========================= */

  function endGame() {
    if (gameEnded) return;

    gameEnded = true;
    cleanupDrag();

    const isNewRecord = score > gameStartBest;

    saveNewBest();

    if ($("gameOverScore")) {
      $("gameOverScore").textContent = formatNumber(score);
    }

    if ($("gameOverBest")) {
      $("gameOverBest").textContent = formatNumber(best);
    }

    if ($("finalScore")) {
      $("finalScore").textContent = formatNumber(score);
    }

    if ($("newRecord")) {
      $("newRecord").textContent = isNewRecord
        ? "🏆 REKOR BARU!"
        : "COBA LAGI DAN PECAHKAN REKOR!";
    }

    const overlay = $("gameOverOverlay");
    setSubtitle("GAME OVER!");

    if (overlay) {
      // Pastikan overlay tidak menutupi game sebelum jeda selesai.
      overlay.classList.remove("show");
      overlay.classList.add("hidden");
      clearTimeout(gameOverTimer);
      gameOverTimer = setTimeout(() => {
        if (!gameEnded) return;
        overlay.style.removeProperty("display");
        overlay.style.pointerEvents = "auto";
        overlay.classList.remove("hidden");
        void overlay.offsetWidth;
        overlay.classList.add("show");
        tone(260, 0.25, "triangle", 0.035, 150);
        gameOverTimer = null;
      }, 1500);
    }
  }

  /* =========================
     OVERLAYS
  ========================= */

  function openOverlay(id) {
    const overlay = $(id);
    if (!overlay) return;

    overlay.classList.remove("hidden");

    if (id === "gameOverOverlay") {
      overlay.classList.remove("show");
      void overlay.offsetWidth;
      overlay.classList.add("show");
    }
  }

  function closeOverlay(id) {
    const overlay = $(id);
    if (!overlay) return;

    overlay.classList.remove("show");
    overlay.classList.add("hidden");
  }

  function closeAllOverlays() {
    document.querySelectorAll(".overlay").forEach(overlay => {
      overlay.classList.remove("show");
      overlay.classList.add("hidden");
    });

    // gameOverOverlay di index.html tidak memakai class "overlay",
    // jadi harus ditutup secara eksplisit agar tidak menahan sentuhan.
    const gameOver = $("gameOverOverlay");
    if (gameOver) {
      gameOver.classList.remove("show");
      gameOver.classList.add("hidden");
    }
  }

  /* =========================
     RESET GAME
  ========================= */

  function resetGame() {
    clearTimeout(gameOverTimer);
    gameOverTimer = null;
    cleanupDrag();

    score = 0;
    gameEnded = false;
    clearing = false;
    strikeCount = 0;
    dragsWithoutStrike = 0;
    moveMadeStrike = false;
    lastPraise = "";
    gameStartBest = best;

    blockColor = COLORS[0];
    comboColorIndex = 0;

    clearTimeout(comboTimer);
    clearTimeout(popupTimer);
    clearTimeout(invalidTimer);

    if (scoreAnimationId) {
      cancelAnimationFrame(scoreAnimationId);
      scoreAnimationId = 0;
    }

    if (globalParticles) {
      globalParticles.replaceChildren();
    }

    particleCount = 0;

    if (comboEl) {
      comboEl.textContent = "";
      comboEl.classList.remove("show", "strike-glow");
    }

    if (scorePopup) {
      scorePopup.textContent = "";
      scorePopup.classList.remove("show");
    }

    boardWrap?.classList.remove("invalid-shake");
    boardEl?.classList.remove("outside-flash");

    closeAllOverlays();
    const gameOverOverlay = $("gameOverOverlay");
    if (gameOverOverlay) {
      gameOverOverlay.style.setProperty("display", "none", "important");
      gameOverOverlay.style.pointerEvents = "none";
    }
    createEmptyBoard();
    renderBoard();
    updateScore();
    makePieces();
    updateSoundButton();

    setSubtitle("Susun blok dan pecahkan garis!");
  }

  /* =========================
     BUTTONS
  ========================= */

  $("menuBtn")?.addEventListener("click", () => {
    if (gameEnded || clearing) return;

    playMenuSound();
    openOverlay("menuOverlay");
  });

  $("resumeBtn")?.addEventListener("click", () => {
    closeOverlay("menuOverlay");
    playMenuSound();
  });

  $("restartBtn")?.addEventListener("click", () => {
    resetGame();
    playMenuSound();
  });

  $("descriptionBtn")?.addEventListener("click", () => {
    closeOverlay("menuOverlay");
    openOverlay("descriptionOverlay");
    playMenuSound();
  });

  $("homeDescBtn")?.addEventListener("click", () => {
    closeOverlay("homeOverlay");
    openOverlay("descriptionOverlay");
  });

  $("exitBtn")?.addEventListener("click", () => {
    closeOverlay("menuOverlay");
    openOverlay("exitOverlay");
  });

  $("confirmExitBtn")?.addEventListener("click", () => {
    cleanupDrag();
    closeAllOverlays();
    openOverlay("homeOverlay");
    playMenuSound();
  });

  $("homePlayBtn")?.addEventListener("click", () => {
    resetGame();
    playMenuSound();
  });

  // Tombol Play Again: pointerup lebih andal untuk sentuhan Android.
  const playAgainButton = $("playAgainBtn");
  if (playAgainButton) {
    const handlePlayAgain = event => {
      event.preventDefault();
      event.stopPropagation();
      if (playAgainButton.dataset.resetting === "1") return;
      playAgainButton.dataset.resetting = "1";

      clearTimeout(gameOverTimer);
      gameOverTimer = null;
      const gameOver = $("gameOverOverlay");
      if (gameOver) {
        gameOver.classList.remove("show");
        gameOver.classList.add("hidden");
        gameOver.style.setProperty("display", "none", "important");
        gameOver.style.pointerEvents = "none";
      }

      resetGame();
      playMenuSound();
      requestAnimationFrame(() => {
        playAgainButton.dataset.resetting = "0";
      });
    };

    playAgainButton.addEventListener("pointerup", handlePlayAgain, { passive: false });
    // Fallback untuk browser yang tidak mengirim PointerEvent.
    if (!window.PointerEvent) {
      playAgainButton.addEventListener("touchend", handlePlayAgain, { passive: false });
      playAgainButton.addEventListener("click", handlePlayAgain);
    }
  } else {
    console.error("Block Blast: tombol #playAgainBtn tidak ditemukan.");
  }

  $("gameHomeBtn")?.addEventListener("click", () => {
    closeAllOverlays();
    openOverlay("homeOverlay");

    if ($("homeBest")) {
      $("homeBest").textContent = formatNumber(best);
    }

    playMenuSound();
  });

  document.querySelectorAll("[data-close]").forEach(button => {
    button.addEventListener("click", () => {
      closeOverlay(button.dataset.close);
    });
  });

  /* =========================
     SOUND BUTTON
  ========================= */

  function updateSoundButton() {
    const button = $("soundBtn");
    const icon = $("soundIcon");

    if (button) {
      button.style.opacity = soundEnabled ? "1" : ".55";

      button.setAttribute(
        "aria-label",
        soundEnabled ? "Matikan suara" : "Nyalakan suara"
      );
    }

    if (icon) {
      icon.innerHTML = soundEnabled
        ? '<path d="M4 10v4h4l5 4V6l-5 4H4z M16 9a5 5 0 0 1 0 6"/>'
        : '<path d="M4 10v4h4l5 4V6l-5 4H4z M17 9l5 6m0-6-5 6"/>';
    }
  }

  $("soundBtn")?.addEventListener("click", () => {
    soundEnabled = !soundEnabled;

    saveSoundSetting();
    updateSoundButton();

    if (soundEnabled) playMenuSound();
  });

  /* =========================
     STARTUP
  ========================= */

  function init() {
    if (!boardEl || !piecesEl) {
      console.error(
        "Block Blast: #board atau #pieces tidak ditemukan. Periksa index.html."
      );
      return;
    }

    createEmptyBoard();
    renderBoard();
    updateScore();
    makePieces();
    updateSoundButton();

    gameStartBest = best;

    setSubtitle("Susun blok dan pecahkan garis!");

    if ($("homeOverlay")) {
      openOverlay("homeOverlay");
    }
  }

  init();
})();   


const bgMusic = new Audio("sounds/bgmusic.mp3");
bgMusic.loop = true;
bgMusic.volume = 0.15;

let bgMusicOn = localStorage.getItem("bb_music") !== "off";

function updateMusicButton() {
  const btn = document.getElementById("musicBtn");
  const icon = document.getElementById("musicIcon");

  if (icon) icon.textContent = bgMusicOn ? "👾" : "🔇";
  if (btn) btn.setAttribute("aria-pressed", String(bgMusicOn));
}

async function toggleMusic() {
  bgMusicOn = !bgMusicOn;
  localStorage.setItem("bb_music", bgMusicOn ? "on" : "off");

  if (bgMusicOn) {
    try {
      await bgMusic.play();
    } catch (error) {
      bgMusicOn = false;
      localStorage.setItem("bb_music", "off");
      alert("Musik gagal diputar. Periksa file sounds/bgmusic.mp3");
    }
  } else {
    bgMusic.pause();
    bgMusic.currentTime = 0;
  }

  updateMusicButton();
}

document.getElementById("musicBtn")?.addEventListener("click", toggleMusic);
updateMusicButton();
