# BithumbHelper 0.3.0 HTML-to-APK

이 프로젝트는 `app/src/main/assets/index.html`을 Android WebView로 표시하는 HTML 기반 앱입니다. HTML 파일을 수정하면 앱 화면도 함께 바뀝니다.

## HTML 단독 실행
`app/src/main/assets/index.html` 파일을 최신 Chrome에서 열 수 있습니다. 빗썸 공개 API 호출을 위해 인터넷 연결이 필요합니다. 브라우저의 CORS 정책이나 네트워크 환경에 따라 로컬 파일에서 API 호출이 제한될 수 있으므로, APK/WebView 또는 로컬 웹서버 실행을 권장합니다.

## APK 빌드
1. Android Studio에서 `BithumbHelper` 폴더를 엽니다.
2. Gradle JDK 17과 Android SDK Platform 35를 설치합니다.
3. `Build > Build Bundle(s) / APK(s) > Build APK(s)`를 선택합니다.
4. APK: `app/build/outputs/apk/debug/app-debug.apk`

또는 Android SDK와 Gradle이 설치된 환경에서 프로젝트 루트에서 `gradle assembleDebug`를 실행합니다. GitHub Actions workflow가 포함되어 있다면 저장소에 push한 뒤 Actions에서 APK 빌드를 실행할 수도 있습니다.

## 현재 HTML 버전 기능
- 빗썸 KRW 마켓 코인 검색/선택
- 1/5/15분, 1/4시간 봉 선택
- 장악형, 핀바, 모닝스타/이브닝스타, 적삼병/흑삼병 간이 탐지
- RSI(14), MACD, EMA20/50, ATR 기반 참고 가격
- 브라우저 알림 권한 요청

## 중요한 제한
- 이 HTML 버전은 앱 내부 차트를 읽지 않고, 사용자가 선택한 코인의 빗썸 공개 API 캔들 데이터를 분석합니다.
- HTML 단독 버전의 알림은 브라우저 알림 권한에 의존합니다. Android 네이티브 알림, 빗썸 실행 감지, 다른 앱 위 플로팅 창은 이 WebView HTML 버전에 연결되어 있지 않습니다. 해당 기능은 기존 네이티브 Kotlin 구현을 별도로 통합해야 합니다.
- 자동 주문은 지원하지 않습니다. 지표와 가격은 참고용이며 투자 조언이나 수익 보장이 아닙니다.
- HTML에서 사용하는 API 요청은 인터넷 연결이 필요하며 빗썸 API 정책/네트워크에 따라 실패할 수 있습니다.
