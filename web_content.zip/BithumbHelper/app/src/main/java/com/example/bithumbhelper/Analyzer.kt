package com.example.bithumbhelper

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

object Analyzer {
    fun analyze(c: List<Candle>): Signal {
        require(c.size >= 60) { "분석할 캔들이 부족합니다. 캔들 60개 이상이 필요합니다." }
        val closes = c.map { it.close }
        val last = c.last()
        val ma20 = closes.takeLast(20).average()
        val ma50 = closes.takeLast(50).average()
        val rsi = rsi(closes, 14)
        val macdLine = ema(closes, 12).last() - ema(closes, 26).last()
        val macdSeries = emaSeries(closes, 12).zip(emaSeries(closes, 26)) { a, b -> a - b }
        val macdSignal = ema(macdSeries, 9).last()
        val histogram = macdLine - macdSignal
        val pattern = detectPattern(c)
        val score = (if (ma20 > ma50) 1 else -1) +
            (if (histogram > 0) 1 else -1) +
            (if (rsi in 50.0..68.0) 1 else if (rsi < 42.0) -1 else 0) +
            when (pattern.second) { 2 -> 2; 1 -> 1; -1 -> -1; -2 -> -2; else -> 0 }
        val title = when { score >= 3 -> "매수 후보"; score <= -3 -> "매도 후보"; else -> "관망" }
        val atr = atr(c, 14).coerceAtLeast(last.close * 0.003)
        val entry = last.close
        val stop: Double
        val target: Double
        if (score >= 0) { stop = entry - atr * 1.5; target = entry + atr * 3.0 }
        else { stop = entry + atr * 1.5; target = entry - atr * 3.0 }
        val detail = "${pattern.first} · RSI ${"%.1f".format(rsi)} · MACD ${if (histogram >= 0) "상승" else "하락"} · MA20/50 ${if (ma20 >= ma50) "정배열" else "역배열"}"
        return Signal(title, detail, rsi, last.close, histogram, ma20, ma50, pattern.first, entry, stop, target, score)
    }

    private fun detectPattern(c: List<Candle>): Pair<String, Int> {
        val a = c[c.lastIndex - 2]; val b = c[c.lastIndex - 1]; val x = c.last()
        val body = abs(x.close - x.open).coerceAtLeast(x.close * 0.0001)
        val range = (x.high - x.low).coerceAtLeast(body)
        val lower = min(x.open, x.close) - x.low
        val upper = x.high - max(x.open, x.close)
        val bullEngulf = b.close < b.open && x.close > x.open && x.open <= b.close && x.close >= b.open
        val bearEngulf = b.close > b.open && x.close < x.open && x.open >= b.close && x.close <= b.open
        if (bullEngulf) return "상승 장악형" to 2
        if (bearEngulf) return "하락 장악형" to -2
        if (lower >= body * 2.0 && lower / range >= .55 && upper <= body && x.close > x.open) return "상승 핀바" to 1
        if (upper >= body * 2.0 && upper / range >= .55 && lower <= body && x.close < x.open) return "하락 핀바" to -1
        val bBody = abs(b.close - b.open)
        if (a.close < a.open && bBody < abs(a.close - a.open) * .55 && x.close > x.open && x.close > (a.open + a.close) / 2.0) return "모닝스타" to 2
        if (a.close > a.open && bBody < abs(a.close - a.open) * .55 && x.close < x.open && x.close < (a.open + a.close) / 2.0) return "이브닝스타" to -2
        val three = c.takeLast(3)
        if (three.all { it.close > it.open } && three[0].close < three[1].close && three[1].close < three[2].close) return "적삼병" to 2
        if (three.all { it.close < it.open } && three[0].close > three[1].close && three[1].close > three[2].close) return "흑삼병" to -2
        // Simplified three-method continuation: three small counter candles remain inside the first candle range, then breakout.
        if (c.size >= 5) {
            val w = c.takeLast(5)
            val first = w[0]; val middle = w.subList(1, 4); val last = w[4]
            if (first.close > first.open && middle.all { it.low >= first.low && it.high <= first.high && it.close < it.open } && last.close > first.high) return "상승 삼법형" to 2
            if (first.close < first.open && middle.all { it.high <= first.high && it.low >= first.low && it.close > it.open } && last.close < first.low) return "하락 삼법형" to -2
        }
        return "뚜렷한 패턴 없음" to 0
    }

    private fun rsi(values: List<Double>, period: Int): Double {
        val diffs = values.zipWithNext { a, b -> b - a }.takeLast(period)
        val gain = diffs.sumOf { max(0.0, it) } / period
        val loss = diffs.sumOf { max(0.0, -it) } / period
        return if (loss == 0.0) 100.0 else 100.0 - 100.0 / (1.0 + gain / loss)
    }
    private fun ema(values: List<Double>, period: Int): List<Double> = emaSeries(values, period)
    private fun emaSeries(values: List<Double>, period: Int): List<Double> {
        if (values.isEmpty()) return emptyList()
        val k = 2.0 / (period + 1.0)
        val out = ArrayList<Double>(values.size)
        var current = values.first()
        out.add(current)
        for (i in 1 until values.size) { current = values[i] * k + current * (1.0 - k); out.add(current) }
        return out
    }
    private fun atr(c: List<Candle>, period: Int): Double {
        val tr = c.zipWithNext().map { (p, x) -> max(x.high - x.low, max(abs(x.high - p.close), abs(x.low - p.close))) }
        return tr.takeLast(period).average()
    }
}
