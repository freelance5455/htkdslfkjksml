package com.example.bithumbhelper

import android.Manifest
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat

class AnalysisWebActivity : Activity() {
    private lateinit var webView: WebView
    private val channelId = "bithumb_web_signals"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            addJavascriptInterface(AndroidBridge(), "AndroidBridge")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(webView)
    }
    inner class AndroidBridge {
        @JavascriptInterface fun saveSelection(market: String, unit: Int) {
            getSharedPreferences("prefs", Context.MODE_PRIVATE).edit()
                .putString("market", market).putInt("unit", unit).apply()
        }
        @JavascriptInterface fun postSignal(title: String, side: String, message: String) {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.notify((title + side).hashCode(), NotificationCompat.Builder(this@AnalysisWebActivity, channelId)
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .setContentTitle("빗썸 차트 도우미 · $side")
                .setContentText(message).setAutoCancel(true).build())
        }
        @JavascriptInterface fun requestNotifications() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                    ActivityCompat.requestPermissions(this@AnalysisWebActivity, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 45)
            }
        }
    }
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(channelId, "빗썸 매매 신호", NotificationManager.IMPORTANCE_DEFAULT))
        }
    }
    @Suppress("DEPRECATION") override fun onBackPressed() { if (webView.canGoBack()) webView.goBack() else super.onBackPressed() }
    override fun onDestroy() { webView.destroy(); super.onDestroy() }
}
