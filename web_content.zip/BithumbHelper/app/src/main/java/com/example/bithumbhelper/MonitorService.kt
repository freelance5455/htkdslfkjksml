package com.example.bithumbhelper

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.*
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat
import java.util.Locale
import java.util.concurrent.Executors

class MonitorService : Service() {
    companion object {
        private const val BITHUMB_PACKAGE = "com.btckorea.bithumb"
        private const val CHANNEL = "bithumb_analysis"
        private const val FOREGROUND_ID = 101
        private const val ALERT_ID = 102
    }
    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var panel: View? = null
    private var lastAlertKey = ""
    private var lastAnalysisAt = 0L
    private var requestRunning = false
    private val ticker = object : Runnable {
        override fun run() {
            val active = isBithumbForeground()
            if (!active) {
                removePanel()
                lastAlertKey = ""
            } else {
                if (panel == null) showPanel()
                if (!requestRunning && System.currentTimeMillis() - lastAnalysisAt >= 15_000) refreshAnalysis()
            }
            handler.postDelayed(this, 2_000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(FOREGROUND_ID, notification("빗썸 앱 실행을 기다리는 중", ongoing = true))
        handler.post(ticker)
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    private fun isBithumbForeground(): Boolean {
        return try {
            val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val events = usm.queryEvents(now - 10 * 60_000L, now)
            val event = UsageEvents.Event()
            var lastPackage = ""
            var lastTime = 0L
            while (events.hasNextEvent()) {
                events.getNextEvent(event)
                val foreground = event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND ||
                    (Build.VERSION.SDK_INT >= 29 && event.eventType == UsageEvents.Event.ACTIVITY_RESUMED)
                if (foreground && event.timeStamp >= lastTime) {
                    lastTime = event.timeStamp
                    lastPackage = event.packageName ?: ""
                }
            }
            lastPackage == BITHUMB_PACKAGE
        } catch (_: Exception) { false }
    }

    private fun showPanel() {
        val prefs = getSharedPreferences("prefs", MODE_PRIVATE)
        val market = prefs.getString("market", "KRW-BTC") ?: "KRW-BTC"
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 14)
            setBackgroundColor(0xF21A2638.toInt())
        }
        val header = TextView(this).apply {
            text = "빗썸 분석 · ${market.substringAfter("KRW-")}     −"
            textSize = 14f; setTextColor(-1); setPadding(0, 0, 0, 6)
        }
        val body = TextView(this).apply {
            tag = "analysis_body"; text = "빗썸 시세를 분석하고 있습니다…"; textSize = 12f
            setTextColor(0xFFE5EDF8.toInt()); setPadding(0, 6, 0, 0)
        }
        box.addView(header); box.addView(body)
        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * .88).toInt(), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 8; y = 130 }
        // Drag the floating panel by touching its header.
        header.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0; private var startY = 0; private var touchX = 0f; private var touchY = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { startX = params.x; startY = params.y; touchX = e.rawX; touchY = e.rawY; return true }
                    MotionEvent.ACTION_MOVE -> { params.x = startX - (e.rawX - touchX).toInt(); params.y = startY + (e.rawY - touchY).toInt(); try { (getSystemService(WINDOW_SERVICE) as WindowManager).updateViewLayout(box, params) } catch (_: Exception) {}; return true }
                }
                return true
            }
        })
        try { (getSystemService(WINDOW_SERVICE) as WindowManager).addView(box, params); panel = box } catch (_: Exception) { panel = null }
    }

    private fun refreshAnalysis() {
        requestRunning = true
        lastAnalysisAt = System.currentTimeMillis()
        worker.execute {
            try {
                val prefs = getSharedPreferences("prefs", MODE_PRIVATE)
                val market = prefs.getString("market", "KRW-BTC") ?: "KRW-BTC"
                val unit = prefs.getInt("unit", 5)
                val signal = Analyzer.analyze(BithumbApi.candles(market, unit, 200))
                handler.post {
                    requestRunning = false
                    if (panel != null && isBithumbForeground()) {
                        panel?.findViewWithTag<TextView>("analysis_body")?.text = buildString {
                            append("${signal.title}  ·  ${unitLabel(unit)}\n")
                            append("${signal.detail}\n")
                            append("현재가  ${price(signal.last)}원\n")
                            if (signal.score > 0) {
                                append("매수 진입 후보  ${price(signal.entry)}원\n")
                                append("손절 후보  ${price(signal.stop)}원 · 목표가  ${price(signal.target)}원\n")
                            } else if (signal.score < 0) {
                                append("매도 관찰 기준가  ${price(signal.entry)}원\n")
                                append("상방 무효화  ${price(signal.stop)}원 · 하방 목표  ${price(signal.target)}원\n")
                            } else append("뚜렷한 방향이 없어 진입 가격 제안은 보류합니다.\n")
                            append("분석 점수 ${signal.score} · ATR 기준 참고 손익비 약 1:2")
                        }
                        if (signal.title != "관망") {
                            val key = "$market|$unit|${signal.title}|${signal.pattern}"
                            if (key != lastAlertKey) {
                                lastAlertKey = key
                                val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
                                nm.notify(ALERT_ID, notification("$market ${signal.title} · ${unitLabel(unit)} · ${signal.pattern}", ongoing = false))
                            }
                        } else lastAlertKey = ""
                    }
                }
            } catch (e: Exception) {
                handler.post {
                    requestRunning = false
                    panel?.findViewWithTag<TextView>("analysis_body")?.text = "분석 데이터를 가져오지 못했습니다.\n${e.message ?: "잠시 후 다시 시도합니다."}"
                }
            }
        }
    }

    private fun unitLabel(unit: Int) = when (unit) { 1 -> "1분봉"; 5 -> "5분봉"; 15 -> "15분봉"; 60 -> "1시간봉"; 240 -> "4시간봉"; else -> "${unit}분봉" }
    private fun price(v: Double): String {
        val decimals = when { v >= 1000.0 -> 0; v >= 1.0 -> 2; v >= 0.01 -> 4; else -> 8 }
        return String.format(Locale.KOREA, "%,.${decimals}f", v)
    }
    private fun removePanel() {
        panel?.let { try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {} }
        panel = null
    }
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "빗썸 분석 알림", NotificationManager.IMPORTANCE_DEFAULT))
        }
    }
    private fun notification(text: String, ongoing: Boolean) = NotificationCompat.Builder(this, CHANNEL)
        .setSmallIcon(android.R.drawable.ic_menu_info_details)
        .setContentTitle("빗썸 차트 도우미")
        .setContentText(text)
        .setOngoing(ongoing)
        .setAutoCancel(!ongoing)
        .build()

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        removePanel()
        worker.shutdownNow()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?) = null
}
