package com.example.bithumbhelper

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/** Opens the beginner-friendly analysis screen directly. */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startActivity(Intent(this, AnalysisWebActivity::class.java))
        finish()
    }
}
