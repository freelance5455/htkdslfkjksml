package com.example.bithumbhelper

import android.app.Activity
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.Manifest
import android.content.pm.PackageManager

/** HTML UI + one-time permission/setup screen for the Bithumb foreground monitor. */
class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showSetup()
        requestNotificationPermission()
    }

    private fun showSetup() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 40, 32, 28)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(TextView(this).apply {
            text = "빗썸 자동 분석 도우미"
            textSize = 23f
        })
        root.addView(TextView(this).apply {
            text = "처음 한 번만 권한을 허용하고 감시를 시작하세요.\n이 앱의 감시 서비스가 켜져 있으면 빗썸이 화면에 나타날 때 분석창이 자동으로 표시됩니다."
            textSize = 15f
            setPadding(0, 18, 0, 18)
        })
        status = TextView(this).apply { textSize = 13f; setPadding(0, 8, 0, 16) }
        root.addView(status)
        root.addView(Button(this).apply {
            text = "다른 앱 위에 표시 권한 허용"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else Toast.makeText(this@MainActivity, "이미 허용되어 있습니다.", Toast.LENGTH_SHORT).show()
            }
        }, matchWidth())
        root.addView(Button(this).apply {
            text = "사용정보 접근 권한 허용"
            setOnClickListener { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        }, matchWidth())
        root.addView(Button(this).apply {
            text = "자동 분석 감시 시작"
            setOnClickListener { startMonitorIfReady() }
        }, matchWidth())
        root.addView(Button(this).apply {
            text = "분석 화면 열기"
            setOnClickListener { startActivity(Intent(this@MainActivity, AnalysisWebActivity::class.java)) }
        }, matchWidth())
        setContentView(root)
        updateStatus()
    }

    private fun matchWidth(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = 10 }

    private fun hasUsageAccess(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun startMonitorIfReady() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "먼저 '다른 앱 위에 표시' 권한을 허용하세요.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (!hasUsageAccess()) {
            Toast.makeText(this, "먼저 '사용정보 접근' 권한을 허용하세요.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            return
        }
        val intent = Intent(this, MonitorService::class.java)
        ContextCompat.startForegroundService(this, intent)
        Toast.makeText(this, "자동 분석 감시를 시작했습니다. 이제 빗썸을 실행하세요.", Toast.LENGTH_LONG).show()
        updateStatus()
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 44)
        }
    }

    private fun updateStatus() {
        if (!::status.isInitialized) return
        status.text = "권한 상태\n화면 위 표시: ${if (Settings.canDrawOverlays(this)) "허용" else "미허용"}\n사용정보 접근: ${if (hasUsageAccess()) "허용" else "미허용"}"
    }

    override fun onResume() { super.onResume(); updateStatus() }
}
