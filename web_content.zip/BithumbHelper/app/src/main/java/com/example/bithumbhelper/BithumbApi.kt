package com.example.bithumbhelper

import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

data class Market(val code: String, val koreanName: String, val englishName: String) {
    val symbol: String get() = code.substringAfter("KRW-")
    val display: String get() = "$koreanName ($symbol)"
}

data class Candle(
    val open: Double, val high: Double, val low: Double,
    val close: Double, val volume: Double, val timestamp: Long = 0L
)

data class Signal(
    val title: String,
    val detail: String,
    val rsi: Double,
    val last: Double,
    val macd: Double,
    val maShort: Double,
    val maLong: Double,
    val pattern: String,
    val entry: Double,
    val stop: Double,
    val target: Double,
    val score: Int
)

object BithumbApi {
    private const val BASE = "https://api.bithumb.com"

    private fun get(path: String): String {
        val conn = (URL(BASE + path).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 8000
            readTimeout = 8000
            setRequestProperty("accept", "application/json")
            setRequestProperty("User-Agent", "BithumbHelper-Android/1.0")
        }
        try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IllegalStateException("빗썸 API 오류 ($code): ${body.take(120)}")
            return body
        } finally { conn.disconnect() }
    }

    fun markets(): List<Market> {
        val arr = JSONArray(get("/v1/market/all?isDetails=false"))
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val code = o.optString("market")
            if (!code.startsWith("KRW-")) null else Market(code, o.optString("korean_name", code), o.optString("english_name", code))
        }.sortedBy { it.koreanName }
    }

    fun candles(symbol: String, unit: Int, count: Int = 200): List<Candle> {
        require(unit in listOf(1, 5, 15, 60, 240)) { "지원하지 않는 시간봉입니다." }
        val market = if (symbol.startsWith("KRW-")) symbol.uppercase(Locale.ROOT) else "KRW-${symbol.uppercase(Locale.ROOT)}"
        val encoded = URLEncoder.encode(market, "UTF-8")
        val arr = JSONArray(get("/v1/candles/minutes/$unit?market=$encoded&count=${count.coerceIn(30, 200)}"))
        // Bithumb API returns newest first; indicators need oldest first.
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Candle(
                o.getDouble("opening_price"), o.getDouble("high_price"),
                o.getDouble("low_price"), o.getDouble("trade_price"),
                o.optDouble("candle_acc_trade_volume", 0.0), o.optLong("timestamp", 0L)
            )
        }.reversed()
    }
}
