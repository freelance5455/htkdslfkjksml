const display = document.getElementById("display");

    function addValue(value) {
        display.value += value;
    }

    function clearDisplay() {
        display.value = "";
    }

    function backspace() {
        display.value = display.value.slice(0, -1);
    }

    function percent() {
        if (display.value !== "") {
            display.value = Number(display.value) / 100;
        }
    }

    function calculate() {
        try {
            if (display.value === "") return;

            // Only allow calculator characters
            if (!/^[0-9+\-*/.() ]+$/.test(display.value)) {
                display.value = "Error";
                return;
            }

            display.value = Function(
                '"use strict"; return (' + display.value + ')'
            )();
        } catch {
            display.value = "Error";
        }
    }

    // Keyboard support
    document.addEventListener("keydown", function(event) {

        if (
            (event.key >= "0" && event.key <= "9") ||
            event.key === "+" ||
            event.key === "-" ||
            event.key === "*" ||
            event.key === "/" ||
            event.key === "."
        ) {
            addValue(event.key);
        }

        if (event.key === "Enter" || event.key === "=") {
            calculate();
        }

        if (event.key === "Backspace") {
            backspace();
        }

        if (event.key === "Escape") {
            clearDisplay();
        }

        if (event.key === "%") {
            percent();
        }
    });