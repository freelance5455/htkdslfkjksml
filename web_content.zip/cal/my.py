from PIL import Image, ImageOps
from pathlib import Path

src = Path("/mnt/data/background.jpg")
img = Image.open(src).convert("RGB")

# 4K UHD, preserving the original aspect ratio and cropping only if necessary.
target = (3840, 2160)
scale = max(target[0] / img.width, target[1] / img.height)
new_size = (round(img.width * scale), round(img.height * scale))
up = img.resize(new_size, Image.Resampling.LANCZOS)
up = ImageOps.fit(up, target, method=Image.Resampling.LANCZOS, centering=(0.5, 0.5))

# JPEG optimized for web.
out = Path("/mnt/data/background_4k_web.jpg")
up.save(out, "JPEG", quality=88, optimize=True, progressive=True, subsampling="4:2:0")

print(f"Created: {out}")
print(f"Original: {img.size[0]}×{img.size[1]}")
print(f"Output: {up.size[0]}×{up.size[1]}")
print(f"File size: {out.stat().st_size / 1024 / 1024:.2f} MB")
