let scene, camera, renderer;
let flashlight, flashlightLight, ambientLight;
let stalkers = [];
let moveForward = false, moveBackward = false, moveLeft = false, moveRight = false;
let moveVector = { x: 0, y: 0 };
let prevTime = performance.now();

let isGameRunning = false;
let flashlightOn = true;
let batteryPower = 100;

// Mobile Touch Look Variables
let lookTouchId = null;
let lastTouchX = 0, lastTouchY = 0;
let pitch = 0, yaw = 0;

function init() {
    // 1. Scene Setup
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x010103);
    scene.fog = new THREE.FogExp2(0x010103, 0.09);

    // 2. Camera Setup
    camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.set(0, 1.6, 12);
    camera.rotation.order = 'YXZ';

    // 3. Renderer Setup
    renderer = new THREE.WebGLRenderer({ canvas: document.getElementById('game-canvas'), antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    // 4. Lighting Setup
    ambientLight = new THREE.AmbientLight(0x05050a, 0.2);
    scene.add(ambientLight);

    // Flashlight SpotLight
    flashlightLight = new THREE.SpotLight(0xffffff, 4.0, 30, Math.PI / 5, 0.4, 1);
    flashlightLight.position.set(0, 0, 0);
    flashlightLight.castShadow = true;
    flashlightLight.shadow.mapSize.width = 512;
    flashlightLight.shadow.mapSize.height = 512;

    flashlight = new THREE.Object3D();
    flashlight.add(flashlightLight);
    flashlight.add(flashlightLight.target);
    flashlightLight.target.position.set(0, 0, -1);
    camera.add(flashlight);
    scene.add(camera);

    // 5. Build Environment
    buildEnvironment();

    // 6. Spawn Authentic Parallel Stalkers (LCrandom's style creature models)
    spawnParallelStalker(-10, 0, -15);
    spawnParallelStalker(12, 0, -25);
    spawnParallelStalker(-3, 0, -35);

    // Setup Listeners
    window.addEventListener('resize', onWindowResize);
    setupTouchControls();
    setupKeyboardControls();

    // Button event bindings with clear start triggers
    const startBtn = document.getElementById('start-btn');
    const restartBtn = document.getElementById('restart-btn');
    const flashBtn = document.getElementById('btn-flashlight');

    startBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        startGame();
    });
    startBtn.addEventListener('touchend', (e) => {
        e.stopPropagation();
        e.preventDefault();
        startGame();
    });

    restartBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        restartGame();
    });
    restartBtn.addEventListener('touchend', (e) => {
        e.stopPropagation();
        e.preventDefault();
        restartGame();
    });

    flashBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        toggleFlashlight();
    });
    flashBtn.addEventListener('touchend', (e) => {
        e.stopPropagation();
        e.preventDefault();
        toggleFlashlight();
    });

    animate();
}

function buildEnvironment() {
    // Ground
    const groundGeo = new THREE.PlaneGeometry(200, 200);
    const groundMat = new THREE.MeshStandardMaterial({ color: 0x0a100a, roughness: 0.95 });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);

    // Forest Trees
    const treeGeo = new THREE.CylinderGeometry(0.25, 0.45, 7, 6);
    const leavesGeo = new THREE.ConeGeometry(2.2, 5.5, 6);
    const barkMat = new THREE.MeshStandardMaterial({ color: 0x140a00 });
    const leavesMat = new THREE.MeshStandardMaterial({ color: 0x020d02 });

    for (let i = 0; i < 150; i++) {
        const x = (Math.random() - 0.5) * 160;
        const z = (Math.random() - 0.5) * 160;
        if (Math.abs(x) < 8 && Math.abs(z) < 8) continue;

        const trunk = new THREE.Mesh(treeGeo, barkMat);
        trunk.position.set(x, 3.5, z);
        trunk.castShadow = true;

        const leaves = new THREE.Mesh(leavesGeo, leavesMat);
        leaves.position.set(x, 6.5, z);
        leaves.castShadow = true;

        scene.add(trunk);
        scene.add(leaves);
    }

    // Wooden House
    const houseGroup = new THREE.Group();
    const wallMat = new THREE.MeshStandardMaterial({ color: 0x24130a, roughness: 0.8 });
    
    const backWall = new THREE.Mesh(new THREE.BoxGeometry(8, 4.5, 0.3), wallMat);
    backWall.position.set(0, 2.25, -4);
    
    const leftWall = new THREE.Mesh(new THREE.BoxGeometry(0.3, 4.5, 8), wallMat);
    leftWall.position.set(-4, 2.25, 0);

    const rightWall = new THREE.Mesh(new THREE.BoxGeometry(0.3, 4.5, 8), wallMat);
    rightWall.position.set(4, 2.25, 0);

    const roofGeo = new THREE.ConeGeometry(6.5, 3.2, 4);
    const roofMat = new THREE.MeshStandardMaterial({ color: 0x0d0704 });
    const roof = new THREE.Mesh(roofGeo, roofMat);
    roof.position.set(0, 6.0, 0);
    roof.rotation.y = Math.PI / 4;

    houseGroup.add(backWall, leftWall, rightWall, roof);
    houseGroup.traverse(child => {
        if (child.isMesh) {
            child.castShadow = true;
            child.receiveShadow = true;
        }
    });

    scene.add(houseGroup);
}

function spawnParallelStalker(x, y, z) {
    const stalkerGroup = new THREE.Group();
    
    // LCrandom's Parallel Stalker proportions:
    // Lanky black body, elongated limbs, wide creepy pale face with black sunken hollow eyes & wide grin
    const blackMat = new THREE.MeshBasicMaterial({ color: 0x000000 });
    const paleHeadMat = new THREE.MeshBasicMaterial({ color: 0xdcdcc8 });

    // Body / Torso (Ribcage silhouette style)
    const torso = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.1, 2.2, 6), blackMat);
    torso.position.y = 1.3;

    // Long Neck
    const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, 0.8, 6), blackMat);
    neck.position.y = 2.4;

    // Head (Oval pale head matching LC's Parallel creatures)
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.28, 8, 8), paleHeadMat);
    head.scale.set(0.8, 1.4, 0.8);
    head.position.y = 2.9;

    // Deep black hollow eyes & wide grin markings
    const eyeMat = new THREE.MeshBasicMaterial({ color: 0x050505 });
    const eye1 = new THREE.Mesh(new THREE.SphereGeometry(0.05, 4, 4), eyeMat);
    eye1.position.set(-0.1, 2.95, 0.18);
    const eye2 = new THREE.Mesh(new THREE.SphereGeometry(0.05, 4, 4), eyeMat);
    eye2.position.set(0.1, 2.95, 0.18);

    const mouth = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.22, 0.05), eyeMat);
    mouth.position.set(0, 2.75, 0.2);

    // Multi-jointed long dangling spider-like arms
    const armGeo = new THREE.CylinderGeometry(0.04, 0.03, 2.2, 4);
    const leftArm = new THREE.Mesh(armGeo, blackMat);
    leftArm.rotation.z = Math.PI / 3;
    leftArm.position.set(-0.6, 1.8, 0);

    const rightArm = new THREE.Mesh(armGeo, blackMat);
    rightArm.rotation.z = -Math.PI / 3;
    rightArm.position.set(0.6, 1.8, 0);

    stalkerGroup.add(torso, neck, head, eye1, eye2, mouth, leftArm, rightArm);
    stalkerGroup.position.set(x, y, z);
    scene.add(stalkerGroup);

    stalkers.push({
        mesh: stalkerGroup,
        speed: 0.028,
        initialPos: new THREE.Vector3(x, y, z)
    });
}

function setupTouchControls() {
    const joystickBase = document.getElementById('joystick-base');
    const joystickStick = document.getElementById('joystick-stick');
    let joystickTouchId = null;
    let baseRect = null;

    window.addEventListener('touchstart', (e) => {
        if (!isGameRunning) return;
        for (let i = 0; i < e.changedTouches.length; i++) {
            const touch = e.changedTouches[i];
            
            if (touch.clientX < window.innerWidth / 2 && joystickTouchId === null) {
                joystickTouchId = touch.identifier;
                baseRect = joystickBase.getBoundingClientRect();
                updateJoystick(touch);
            } 
            else if (touch.clientX >= window.innerWidth / 2 && lookTouchId === null) {
                lookTouchId = touch.identifier;
                lastTouchX = touch.clientX;
                lastTouchY = touch.clientY;
            }
        }
    });

    window.addEventListener('touchmove', (e) => {
        if (!isGameRunning) return;
        for (let i = 0; i < e.changedTouches.length; i++) {
            const touch = e.changedTouches[i];

            if (touch.identifier === joystickTouchId) {
                updateJoystick(touch);
            } else if (touch.identifier === lookTouchId) {
                const deltaX = touch.clientX - lastTouchX;
                const deltaY = touch.clientY - lastTouchY;
                lastTouchX = touch.clientX;
                lastTouchY = touch.clientY;

                yaw -= deltaX * 0.005;
                pitch -= deltaY * 0.005;
                pitch = Math.max(-Math.PI / 2.2, Math.min(Math.PI / 2.2, pitch));

                camera.rotation.x = pitch;
                camera.rotation.y = yaw;
            }
        }
    });

    const resetJoystick = (touchId) => {
        if (touchId === joystickTouchId) {
            joystickTouchId = null;
            moveVector = { x: 0, y: 0 };
            joystickStick.style.transform = `translate(0px, 0px)`;
        }
        if (touchId === lookTouchId) {
            lookTouchId = null;
        }
    };

    window.addEventListener('touchend', (e) => {
        for (let i = 0; i < e.changedTouches.length; i++) {
            resetJoystick(e.changedTouches[i].identifier);
        }
    });
    window.addEventListener('touchcancel', (e) => {
        for (let i = 0; i < e.changedTouches.length; i++) {
            resetJoystick(e.changedTouches[i].identifier);
        }
    });

    function updateJoystick(touch) {
        if (!baseRect) return;
        const centerX = baseRect.left + baseRect.width / 2;
        const centerY = baseRect.top + baseRect.height / 2;
        
        let dx = touch.clientX - centerX;
        let dy = touch.clientY - centerY;
        const maxDist = baseRect.width / 2;
        const dist = Math.sqrt(dx * dx + dy * dy);

        if (dist > maxDist) {
            dx = (dx / dist) * maxDist;
            dy = (dy / dist) * maxDist;
        }

        joystickStick.style.transform = `translate(${dx}px, ${dy}px)`;
        moveVector.x = dx / maxDist;
        moveVector.y = dy / maxDist;
    }
}

function setupKeyboardControls() {
    document.addEventListener('keydown', (e) => {
        switch (e.code) {
            case 'KeyW': moveForward = true; break;
            case 'KeyS': moveBackward = true; break;
            case 'KeyA': moveLeft = true; break;
            case 'KeyD': moveRight = true; break;
            case 'KeyF': toggleFlashlight(); break;
        }
    });
    document.addEventListener('keyup', (e) => {
        switch (e.code) {
            case 'KeyW': moveForward = false; break;
            case 'KeyS': moveBackward = false; break;
            case 'KeyA': moveLeft = false; break;
            case 'KeyD': moveRight = false; break;
        }
    });
}

function toggleFlashlight() {
    if (batteryPower <= 0) return;
    flashlightOn = !flashlightOn;
    flashlightLight.intensity = flashlightOn ? 4.0 : 0;
    document.getElementById('flashlight-status').innerText = flashlightOn ? "ON" : "OFF";
}

function startGame() {
    const startScreen = document.getElementById('start-screen');
    startScreen.style.display = 'none';
    isGameRunning = true;
}

function gameOver() {
    isGameRunning = false;
    document.getElementById('game-over').style.display = 'flex';
}

function restartGame() {
    document.getElementById('game-over').style.display = 'none';
    camera.position.set(0, 1.6, 12);
    pitch = 0; yaw = 0;
    camera.rotation.set(0, 0, 0);

    batteryPower = 100;
    flashlightOn = true;
    flashlightLight.intensity = 4.0;
    document.getElementById('flashlight-status').innerText = "ON";
    document.getElementById('battery-status').innerText = "100%";
    
    stalkers.forEach(s => s.mesh.position.copy(s.initialPos));
    isGameRunning = true;
}

function updateStalkers() {
    const cameraDir = new THREE.Vector3();
    camera.getWorldDirection(cameraDir);

    stalkers.forEach(stalker => {
        const stalkerPos = stalker.mesh.position;
        const dirToStalker = new THREE.Vector3().subVectors(stalkerPos, camera.position).normalize();
        
        const angle = cameraDir.angleTo(dirToStalker);
        const isLookingAtStalker = angle < (Math.PI / 3.5) && flashlightOn;
        const distance = camera.position.distanceTo(stalkerPos);

        if (distance < 1.3) {
            gameOver();
        }

        // Parallel Stalker mechanic: freezes or stops when caught in flashlight beam, stalks when unobserved
        if (isLookingAtStalker && distance < 25) {
            stalker.mesh.lookAt(camera.position.x, 0, camera.position.z);
        } else {
            stalker.mesh.lookAt(camera.position.x, 0, camera.position.z);
            stalker.mesh.translateZ(stalker.speed);
        }
    });
}

function animate() {
    requestAnimationFrame(animate);

    const time = performance.now();
    const delta = (time - prevTime) / 1000;
    prevTime = time;

    if (isGameRunning) {
        let inputZ = (Number(moveForward) - Number(moveBackward)) || -moveVector.y;
        let inputX = (Number(moveRight) - Number(moveLeft)) || moveVector.x;

        if (Math.abs(inputX) > 0.1 || Math.abs(inputZ) > 0.1) {
            const moveDir = new THREE.Vector3(inputX, 0, -inputZ).normalize();
            moveDir.applyQuaternion(camera.quaternion);
            moveDir.y = 0;
            camera.position.addScaledVector(moveDir, 3.2 * delta);
        }

        if (flashlightOn && batteryPower > 0) {
            batteryPower -= delta * 0.35;
            document.getElementById('battery-status').innerText = `${Math.max(0, Math.floor(batteryPower))}%`;
            if (batteryPower <= 0) {
                flashlightOn = false;
                flashlightLight.intensity = 0;
                document.getElementById('flashlight-status').innerText = "DEAD";
            }
        }

        updateStalkers();
    }

    renderer.render(scene, camera);
}

function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
}

window.onload = init;
