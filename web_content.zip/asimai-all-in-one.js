/* AsimAI All-in-One Workspace — additive integration layer. */
(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const waitForApp = (attempt = 0) => {
    const app = window.appInstance;
    if (app && app.conversations) return install(app);
    if (attempt < 80) setTimeout(() => waitForApp(attempt + 1), 250);
  };

  function install(app) {
    if (window.__asimAllInOneInstalled) return;
    window.__asimAllInOneInstalled = true;

    const sidebar = $('sidebar');
    if (sidebar && !$('openAllInOneBtn')) {
      const btn = document.createElement('button');
      btn.id = 'openAllInOneBtn'; btn.type = 'button';
      btn.className = 'w-full flex items-center gap-3 px-3 py-2.5 rounded-lg border border-orange-200/70 hover:bg-orange-50 text-sm font-semibold text-slate-700';
      btn.innerHTML = '<i class="fa-solid fa-grid-2 w-4 text-orange-500"></i><span>All-in-One Workspace</span>';
      const history = $('openHistorySidebarBtn');
      if (history?.parentElement) history.insertAdjacentElement('afterend', btn);
      else sidebar.prepend(btn);
      btn.addEventListener('click', () => { app.toggleSidebar?.(false); openHub(); });
    }

    const hub = document.createElement('section');
    hub.id = 'asimAllInOneHub'; hub.hidden = true;
    hub.innerHTML = `
      <header class="aio-head"><button id="aioBack" aria-label="Back to chat"><i class="fa-solid fa-arrow-left"></i></button><div><strong>AsimAI Workspace</strong><small>One place for your AI tools</small></div><span class="aio-status"><i></i> READY</span></header>
      <div class="aio-content">
        <section class="aio-welcome"><div><span class="aio-eyebrow">ALL-IN-ONE AI WORKSPACE</span><h1>Welcome back, <span id="aioUserName">there</span>.</h1><p>Your assistant, coding studio, voice tools and knowledge workspace—connected in one place.</p></div><div class="aio-orb"><i class="fa-solid fa-bolt"></i></div></section>
        <section class="aio-stats" aria-label="Usage overview">
          <article><small>Conversations</small><strong id="aioChats">0</strong><span>Saved in this browser</span></article>
          <article><small>Messages</small><strong id="aioMessages">0</strong><span>User + assistant messages</span></article>
          <article><small>Estimated tokens</small><strong id="aioTokens">0</strong><span>Approx. from saved text</span></article>
          <article><small>AI providers</small><strong id="aioProviders">0</strong><span>Configured API keys</span></article>
        </section>
        <h2 class="aio-section-title">Your tools</h2>
        <section class="aio-tools">
          <button data-aio="chat"><i class="fa-regular fa-comments"></i><b>AI Chat</b><small>Continue your conversations</small></button>
          <button data-aio="jarvis"><i class="fa-solid fa-microphone-lines"></i><b>JARVIS Voice</b><small>Hands-free voice assistant</small></button>
          <button data-aio="ide"><i class="fa-solid fa-code"></i><b>Coding Studio</b><small>Build, run and preview code</small></button>
          <button data-aio="history"><i class="fa-solid fa-clock-rotate-left"></i><b>Chat History</b><small>Read, reopen and organize chats</small></button>
          <button data-aio="knowledge"><i class="fa-solid fa-book-open"></i><b>Knowledge Base</b><small>Upload PDFs and ask questions</small></button>
          <button data-aio="analytics"><i class="fa-solid fa-chart-line"></i><b>Usage Analytics</b><small>Explore your usage trends</small></button>
          <button data-aio="prompts"><i class="fa-solid fa-bookmark"></i><b>Prompt Library</b><small>Reuse your saved prompts</small></button>
          <button data-aio="settings"><i class="fa-solid fa-sliders"></i><b>Settings & Personas</b><small>Customize your assistant</small></button>
        </section>
        <section class="aio-personal"><div class="aio-personal-head"><div><h2>Personal AI instructions</h2><p>Tell AsimAI how you prefer answers. These instructions are added to future AI requests.</p></div><i class="fa-solid fa-user-gear"></i></div>
          <textarea id="aioCustomInstructions" rows="4" maxlength="4000" placeholder="Example: Reply in Roman Urdu, explain technical topics step by step, and keep answers practical..."></textarea>
          <div class="aio-personal-foot"><small id="aioSaveState">Stored in this browser only</small><button id="aioSaveInstructions" type="button">Save instructions</button></div>
        </section>
        <section class="aio-security"><i class="fa-solid fa-shield-halved"></i><div><b>Privacy & security</b><p>Your chats, preferences and uploaded knowledge are stored locally in this browser unless a feature explicitly sends a request to your selected AI provider. Do not publish provider keys in frontend code; use a secure backend for public deployment.</p></div></section>
      </div>`;
    document.body.appendChild(hub);

    function updateStats() {
      const chats = app.conversations || [];
      const msgs = chats.flatMap(c => c.messages || []);
      const textChars = msgs.reduce((n, m) => n + String(m.text || m.content || '').length, 0);
      const keys = app.settings?.providerKeys || {};
      const providers = Object.values(keys).filter(v => String(v || '').trim()).length +
        ((app.settings?.apiKey && !keys[app.settings?.provider]) ? 1 : 0);
      $('aioChats').textContent = chats.length.toLocaleString();
      $('aioMessages').textContent = msgs.length.toLocaleString();
      $('aioTokens').textContent = Math.round(textChars / 4).toLocaleString();
      $('aioProviders').textContent = providers.toLocaleString();
      $('aioUserName').textContent = app.settings?.userName || 'there';
    }
    function openHub() {
      updateStats();
      $('aioCustomInstructions').value = app.settings?.customInstructions || '';
      hub.hidden = false; document.body.classList.add('aio-open');
    }
    function closeHub() { hub.hidden = true; document.body.classList.remove('aio-open'); }
    $('aioBack').addEventListener('click', closeHub);
    $('aioSaveInstructions').addEventListener('click', async () => {
      const value = $('aioCustomInstructions').value.trim();
      app.settings.customInstructions = value;
      try { await Storage.saveSettings(app.settings); $('aioSaveState').textContent = 'Saved successfully'; }
      catch (err) { $('aioSaveState').textContent = 'Could not save. Please retry.'; console.error('[AsimAI] Personal instructions save failed', err); }
    });
    hub.querySelectorAll('[data-aio]').forEach(button => button.addEventListener('click', () => {
      const action = button.dataset.aio; closeHub();
      switch (action) {
        case 'chat': break;
        case 'jarvis': app.jarvisModeBtn?.click(); break;
        case 'ide': $('openIdeBtn')?.click(); break;
        case 'history': app.openHistoryPage?.(); break;
        case 'knowledge': $('fileInput')?.click(); break;
        case 'analytics': $('openSettingsBtn')?.click(); setTimeout(() => $('openAnalyticsBtn')?.click(), 250); break;
        case 'prompts': $('promptLibraryBtn')?.click(); break;
        case 'settings': $('openSettingsBtn')?.click(); break;
      }
    }));
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && !hub.hidden) closeHub(); });
    app.openAllInOneWorkspace = openHub;
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => waitForApp());
  else waitForApp();
})();
