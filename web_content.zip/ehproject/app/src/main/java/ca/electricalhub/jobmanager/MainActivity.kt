package ca.electricalhub.jobmanager

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.webkit.DownloadListener
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import android.print.PrintAttributes
import android.print.PrintManager
import android.content.Context
import android.util.Base64
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.databaseEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.javaScriptCanOpenWindowsAutomatically = true
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AndroidPdfBridge(), "ElectricalHubAndroid")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                if (uri.scheme == "http" || uri.scheme == "https") {
                    // Keep web app and required online services in the WebView.
                    return false
                }
                return false
            }
        }
        webView.setDownloadListener(DownloadListener { url, _, contentDisposition, mimeType, _ ->
            if (url.startsWith("blob:")) {
                Toast.makeText(this, "Use the PDF save button in Electrical Hub.", Toast.LENGTH_LONG).show()
            } else if (url.startsWith("http://") || url.startsWith("https://")) {
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
                catch (_: Exception) { Toast.makeText(this, "Could not open download link.", Toast.LENGTH_LONG).show() }
            }
        })
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class AndroidPdfBridge {
        @JavascriptInterface
        fun savePdfBase64(fileName: String?, base64Data: String?) {
            runOnUiThread {
                try {
                    if (base64Data.isNullOrBlank()) throw IllegalArgumentException("Empty PDF")
                    val bytes = Base64.decode(base64Data, Base64.DEFAULT)
                    if (bytes.isEmpty()) throw IllegalArgumentException("Empty PDF")
                    val safeName = sanitizePdfName(fileName)
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                        put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                            put(MediaStore.Downloads.IS_PENDING, 1)
                        }
                    }
                    val resolver = contentResolver
                    val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        ?: throw IllegalStateException("Could not create Downloads file")
                    resolver.openOutputStream(uri).use { out: OutputStream? ->
                        if (out == null) throw IllegalStateException("Could not open Downloads file")
                        out.write(bytes)
                        out.flush()
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
                        resolver.update(uri, done, null, null)
                    }
                    Toast.makeText(this@MainActivity, "PDF saved to Downloads: $safeName", Toast.LENGTH_LONG).show()
                    webView.evaluateJavascript("document.getElementById('pdfDownloadStatus') && (document.getElementById('pdfDownloadStatus').textContent = 'PDF saved to your Android Downloads folder: ' + ${org.json.JSONObject.quote(safeName)});", null)
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "PDF save failed: ${e.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun sanitizePdfName(name: String?): String {
        val raw = name?.trim().orEmpty().ifBlank {
            "Electrical-Hub-${SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())}.pdf"
        }
        val cleaned = raw.replace(Regex("[^A-Za-z0-9._ -]"), "-").take(120)
        return if (cleaned.lowercase(Locale.ROOT).endsWith(".pdf")) cleaned else "$cleaned.pdf"
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
