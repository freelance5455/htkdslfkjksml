ELECTRICAL HUB JOB MANAGER — ANDROID PDF TEST PROJECT

This is a separate Android Studio project using the supplied V3.2.22 HTML file.
It adds a native Android bridge so JavaScript-generated PDF blobs can be saved to
Android's Downloads folder instead of relying on WebView's anchor download support.

IMPORTANT LIMITATIONS
- This is project source, not a ready-to-install APK.
- It has not been built or tested on a real Android device in this environment.
- The bundled HTML uses online Supabase and jsPDF CDN services; internet is required
  for those services unless their dependencies are bundled separately.
- This app uses a new application ID (ca.electricalhub.jobmanager). It will install
  alongside the old app. It cannot inherit the old app's local browser storage.
  Your existing cloud-synced jobs should be available after signing into the same
  account if cloud sync is working; verify before relying on it.
- Do not uninstall the current app or erase its data until the test app is verified.

BUILD
1. Install Android Studio from the official Android developer website on Windows.
2. Extract this ZIP to a normal folder.
3. In Android Studio choose Open and select the extracted ElectricalHubJobManager folder.
4. Allow Gradle sync and install Android SDK Platform 35 if prompted.
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Install the generated debug APK on the phone and test with a non-critical quotation.

The app saves PDFs to the Android Downloads collection using MediaStore. It does not
modify or replace the existing APK.
