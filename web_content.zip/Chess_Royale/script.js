const game = new Chess();
const boardEl = document.getElementById('board');
const statusMain = document.getElementById('statusMain');
const statusSub = document.getElementById('statusSub');
const moveList = document.getElementById('moveList');
const moveCount = document.getElementById('moveCount');
const currentPlayer = document.getElementById('currentPlayer');
const whitePlayer = document.getElementById('whitePlayer');
const blackPlayer = document.getElementById('blackPlayer');
const whiteTurn = document.getElementById('whiteTurn');
const blackTurn = document.getElementById('blackTurn');
const toastEl = document.getElementById('toast');
const promotionDialog = document.getElementById('promotionDialog');

const symbols = {
  wk:'♔', wq:'♕', wr:'♖', wb:'♗', wn:'♘', wp:'♙',
  bk:'♚', bq:'♛', br:'♜', bb:'♝', bn:'♞', bp:'♟'
};
let selected = null;
let legalTargets = [];
let orientation = 'w';
let lastMove = null;
let pendingPromotion = null;
let toastTimer = null;

function notify(message) {
  toastEl.textContent = message;
  toastEl.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toastEl.classList.remove('show'), 2100);
}
function squareName(row, col) {
  return 'abcdefgh'[col] + (8-row);
}
function displayCoordinates(row, col) {
  const whiteView = orientation === 'w';
  const rank = whiteView ? 8-row : row+1;
  const file = whiteView ? 'abcdefgh'[col] : 'hgfedcba'[col];
  return {rank, file};
}
function renderBoard() {
  boardEl.innerHTML = '';
  const board = game.board();
  for (let r=0;r<8;r++) {
    for (let c=0;c<8;c++) {
      const row = orientation === 'w' ? r : 7-r;
      const col = orientation === 'w' ? c : 7-c;
      const square = squareName(row,col);
      const piece = board[row][col];
      const el = document.createElement('button');
      el.className = `square ${(row+col)%2===0?'light':'dark'}`;
      el.dataset.square = square;
      el.setAttribute('role','gridcell');
      el.setAttribute('aria-label',square);
      if (selected === square) el.classList.add('selected');
      if (lastMove && (lastMove.from===square || lastMove.to===square)) el.classList.add('last-move');
      if (piece && piece.type==='k' && piece.color===game.turn() && game.in_check()) el.classList.add('check');

      if (piece) {
        const span = document.createElement('span');
        span.className = `piece ${piece.color==='w'?'white':'black'}`;
        span.textContent = symbols[piece.color+piece.type];
        el.appendChild(span);
      }
      if (legalTargets.includes(square)) {
        const mark = document.createElement('span');
        mark.className = piece ? 'legal-ring' : 'legal-dot';
        el.appendChild(mark);
      }
      const coords = displayCoordinates(row,col);
      if (c===0) {
        const rank = document.createElement('span');
        rank.className='coord rank';
        rank.textContent=coords.rank;
        el.appendChild(rank);
      }
      if (r===7) {
        const file = document.createElement('span');
        file.className='coord file';
        file.textContent=coords.file;
        el.appendChild(file);
      }
      el.addEventListener('click',()=>onSquareClick(square));
      boardEl.appendChild(el);
    }
  }
  renderStatus();
}
function renderStatus() {
  const turn = game.turn();
  whitePlayer.classList.toggle('active',turn==='w'&&!game.game_over());
  blackPlayer.classList.toggle('active',turn==='b'&&!game.game_over());
  whiteTurn.textContent = turn==='w'&&!game.game_over() ? 'دورك الآن' : 'انتظار';
  blackTurn.textContent = turn==='b'&&!game.game_over() ? 'دورك الآن' : 'انتظار';
  currentPlayer.textContent = turn==='w'?'الأبيض':'الأسود';
  moveCount.textContent = Math.ceil(game.history().length/2);
  if (game.in_checkmate()) {
    statusMain.textContent = `كش ملك — ${turn==='w'?'الأسود':'الأبيض'} يفوز!`;
    statusSub.textContent = 'انتهت المباراة. اضغط لعبة جديدة للبدء مجدداً.';
  } else if (game.in_stalemate()) {
    statusMain.textContent='تعادل — جمود';
    statusSub.textContent='لا توجد حركة قانونية والملك ليس في كش.';
  } else if (game.in_draw()) {
    statusMain.textContent='انتهت المباراة بالتعادل';
    statusSub.textContent='تحقق أحد شروط التعادل.';
  } else if (game.in_check()) {
    statusMain.textContent=`كش على ${turn==='w'?'الأبيض':'الأسود'}!`;
    statusSub.textContent='يجب حماية الملك من الهجوم.';
  } else {
    statusMain.textContent=turn==='w'?'دور الأبيض':'دور الأسود';
    statusSub.textContent='اختر قطعة ثم اضغط على المربع المطلوب.';
  }
  renderMoveList();
}
function renderMoveList() {
  const history = game.history();
  moveList.innerHTML='';
  if (!history.length) {
    moveList.innerHTML='<div class="empty-state">ستظهر النقلات هنا عند بدء اللعب.</div>';
    return;
  }
  for (let i=0;i<history.length;i+=2) {
    const row=document.createElement('div');
    row.className='move-row';
    const number=document.createElement('span');
    number.className='move-number';
    number.textContent=(i/2+1)+'.';
    const white=document.createElement('span');
    white.className='move-san';
    white.textContent=history[i];
    const black=document.createElement('span');
    black.className='move-san';
    black.textContent=history[i+1]||'…';
    if (i===history.length-1) white.classList.add('latest');
    if (i+1===history.length-1) black.classList.add('latest');
    row.append(number,white,black);
    moveList.appendChild(row);
  }
  moveList.scrollTop=moveList.scrollHeight;
}
function onSquareClick(square) {
  if (game.game_over()) return;
  const piece=game.get(square);
  if (selected) {
    const matching=legalTargets.includes(square);
    if (matching) {
      const moves=game.moves({square:selected,verbose:true}).filter(m=>m.to===square);
      const promotion=moves.find(m=>m.flags.includes('p'));
      if (promotion) {
        pendingPromotion={from:selected,to:square};
        promotionDialog.showModal();
        return;
      }
      makeMove(selected,square);
      return;
    }
  }
  if (piece && piece.color===game.turn()) {
    selected=square;
    legalTargets=game.moves({square,verbose:true}).map(m=>m.to);
  } else {
    selected=null;
    legalTargets=[];
  }
  renderBoard();
}
function makeMove(from,to,promotion='q') {
  const move=game.move({from,to,promotion});
  if (!move) { notify('حركة غير قانونية'); return; }
  lastMove={from:move.from,to:move.to};
  selected=null; legalTargets=[]; pendingPromotion=null;
  if (promotionDialog.open) promotionDialog.close();
  renderBoard();
  if (game.in_checkmate()) notify('كش ملك!');
  else if (game.in_check()) notify('كش!');
}
promotionDialog.querySelectorAll('[data-piece]').forEach(btn=>{
  btn.addEventListener('click',()=>{
    if (!pendingPromotion) return;
    makeMove(pendingPromotion.from,pendingPromotion.to,btn.dataset.piece);
  });
});
document.getElementById('undoBtn').addEventListener('click',()=>{
  const undone=game.undo();
  if (!undone) { notify('لا توجد نقلة للتراجع'); return; }
  game.undo(); // undo the opponent's preceding move as a pair, if present
  lastMove=null; selected=null; legalTargets=[];
  renderBoard();
});
document.getElementById('resetBtn').addEventListener('click',()=>{
  game.reset(); selected=null; legalTargets=[]; lastMove=null; renderBoard(); notify('تمت إعادة المباراة');
});
document.getElementById('newGameBtn').addEventListener('click',()=>{
  game.reset(); selected=null; legalTargets=[]; lastMove=null; orientation='w'; renderBoard(); notify('بدأت مباراة جديدة');
});
document.getElementById('flipBtn').addEventListener('click',()=>{
  orientation=orientation==='w'?'b':'w'; renderBoard();
});
document.getElementById('themeBtn').addEventListener('click',()=>{
  document.body.classList.toggle('light-theme');
});
document.getElementById('clearMovesBtn').addEventListener('click',()=>{
  moveList.innerHTML='<div class="empty-state">سجل النقلات مخفي. المباراة مستمرة.</div>';
});
renderBoard();
