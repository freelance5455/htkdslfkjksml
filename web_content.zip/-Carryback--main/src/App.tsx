/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useId } from 'react';

const MAX_ITER = 80;

interface OfferResult {
  H: number;
  D: number;
  L: number;
  apr: number;
  years: number;
  n: number;
  M: number;
  totalLoan: number;
  totalPaid: number;
  interest: number;
  interestPct: number;
  downPct: number;
}

interface MenuOption {
  apr: number;
  years: number;
  n: number;
  M: number;
  L: number;
  D: number;
  H: number;
}

// Bounded helpers: never throw unhandled, never infinite loop
function toNum(v: unknown, fallback: number): number {
  if (v === '' || v === null || v === undefined) return fallback;
  const n = typeof v === 'number' ? v : Number(v);
  if (!Number.isFinite(n) || isNaN(n)) return fallback;
  return n;
}

function clamp(n: number, min: number, max: number): number {
  if (!Number.isFinite(n) || isNaN(n)) return min;
  return Math.min(Math.max(n, min), max);
}

function factor(r: number, n: number): number {
  if (n <= 0) throw new Error('Term must be >0 months');
  if (Math.abs(r) < 1e-12) return 1 / n;
  const p = Math.pow(1 + r, n);
  if (!Number.isFinite(p) || p > 1e12) throw new Error('Overflow term too large');
  const denom = p - 1;
  if (Math.abs(denom) < 1e-12) throw new Error('Denom too small');
  const f = (r * p) / denom;
  if (!Number.isFinite(f)) throw new Error('Factor error');
  return f;
}

function solve_r(L: number, M: number, n: number): number {
  if (L <= 0 || n <= 0 || M <= 0) throw new Error('Loan, term, and monthly payment must be positive');
  const f_low = factor(1e-7, n);
  const f_high = factor(0.15, n); // monthly 15% rate (~180% APR)
  if (M < L * f_low * 0.999) {
    const minM = (L * f_low).toFixed(2);
    throw new Error(`Monthly $${M.toFixed(2)} too low even at 0% APR (min $${minM})`);
  }
  if (M > L * f_high * 1.001) {
    throw new Error(`Monthly $${M.toFixed(2)} too high exceeds 180% APR`);
  }
  let lo = 1e-7;
  let hi = 0.15;
  for (let i = 0; i < MAX_ITER; i++) {
    const mid = (lo + hi) / 2;
    const fm = L * factor(mid, n);
    if (fm > M) {
      hi = mid;
    } else {
      lo = mid;
    }
    if (hi - lo < 1e-9) break;
  }
  return (lo + hi) / 2;
}

const fmtCurrency = (val: number): string => {
  if (!Number.isFinite(val)) return '0.00';
  return val.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
};

const fmtNum = (val: number): string => {
  if (!Number.isFinite(val)) return '0';
  return Number.isInteger(val) ? val.toString() : val.toFixed(1);
};

// Pure Web Audio API chime - 100% offline, zero network requests, synthesized in real-time
function playCalculationChime() {
  try {
    const AudioContextClass =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    if (ctx.state === 'suspended') {
      ctx.resume().catch(() => {});
    }

    const t = ctx.currentTime;

    // First note: E5 (659.25 Hz)
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(587.33, t); // D5
    osc1.frequency.exponentialRampToValueAtTime(659.25, t + 0.06); // E5
    gain1.gain.setValueAtTime(0.08, t);
    gain1.gain.exponentialRampToValueAtTime(0.001, t + 0.22);
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    osc1.start(t);
    osc1.stop(t + 0.22);

    // Second note: C6 (1046.5 Hz) - bright confirmation ping
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(1046.5, t + 0.08);
    gain2.gain.setValueAtTime(0.12, t + 0.08);
    gain2.gain.exponentialRampToValueAtTime(0.0001, t + 0.42);
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    osc2.start(t + 0.08);
    osc2.stop(t + 0.42);
  } catch {
    // Graceful fallback if audio is not permitted by browser
  }
}

export default function App() {
  const hId = useId();
  const dId = useId();
  const aprId = useId();
  const yearsId = useId();
  const mId = useId();
  const solveForId = useId();

  // Inputs
  const [hStr, setHStr] = useState<string>('30000');
  const [dStr, setDStr] = useState<string>('9000');
  const [aprStr, setAprStr] = useState<string>('22');
  const [yearsStr, setYearsStr] = useState<string>('10');
  const [mStr, setMStr] = useState<string>('');
  const [solveFor, setSolveFor] = useState<string>('Auto');

  // Outputs
  const [warning, setWarning] = useState<string | null>(null);
  const [offer, setOffer] = useState<OfferResult | null>(null);
  const [menuMatrix, setMenuMatrix] = useState<MenuOption[] | null>(null);

  // Animation & Audio feedback
  const [calcKey, setCalcKey] = useState<number>(0);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [justCalculated, setJustCalculated] = useState<boolean>(false);

  // Core computation engine
  const runEngine = (
    currentH: string,
    currentD: string,
    currentApr: string,
    currentYears: string,
    currentM: string,
    targetSolveFor: string
  ) => {
    try {
      setWarning(null);
      setMenuMatrix(null);

      // Check how many non-empty parameters provided
      const hasH = currentH.trim() !== '';
      const hasD = currentD.trim() !== '';
      const hasApr = currentApr.trim() !== '';
      const hasYears = currentYears.trim() !== '';
      const hasM = currentM.trim() !== '';

      const count = [hasH, hasD, hasApr, hasYears, hasM].filter(Boolean).length;

      // Case: 1 to 3 params -> Generate exploratory menu matrix
      if (count >= 1 && count <= 3 && !hasM) {
        const rawH = toNum(currentH, 30000);
        const Hf = clamp(rawH, 100, 1e9);
        const Df = hasD ? clamp(toNum(currentD, Hf * 0.3), 0, Hf) : Hf * 0.3;
        const Lf = Hf - Df;

        const aprPresets = [15, 18, 22, 26];
        const yearsPresets = [7, 10, 15, 20];
        const options: MenuOption[] = [];

        for (const y of yearsPresets) {
          const nf = Math.round(y * 12);
          for (const a of aprPresets) {
            const rf = a / 100 / 12;
            const ff = factor(rf, nf);
            const calculatedM = Lf * ff;
            options.push({
              apr: a,
              years: y,
              n: nf,
              M: calculatedM,
              L: Lf,
              D: Df,
              H: Hf,
            });
          }
        }

        setMenuMatrix(options);

        // Also if we have at least H, APR, Years or H alone, compute an initial preview offer
        if (hasH && hasApr && hasYears) {
          // Fall through to 4-params solve with D=0.3H
        } else {
          setWarning(
            `Showing carryback rate & term matrix for $${fmtCurrency(Hf)} (30% down = $${fmtCurrency(Df)}). Select any tier below or complete the fields to generate a single offer.`
          );
          setOffer(null);
          return;
        }
      }

      // 4 or 5 params calculation
      let Hf = toNum(currentH, 0);
      let Df = toNum(currentD, 0);
      let aprf = toNum(currentApr, 0);
      let yearsf = toNum(currentYears, 0);
      let Mf = toNum(currentM, 0);

      // Determine solver target
      let target = targetSolveFor;
      if (target === 'Auto') {
        if (!hasM || currentM.trim() === '') target = 'M';
        else if (!hasH) target = 'H';
        else if (!hasD) target = 'D';
        else if (!hasYears) target = 'n';
        else if (!hasApr) target = 'r';
        else target = 'M'; // When all 5 are present, validate M
      }

      // Check validations before solving
      if (target !== 'H' && Hf <= 0) {
        throw new Error('Home Price H must be greater than $0 (up to $1,000,000,000).');
      }
      if (target !== 'H' && Hf > 1e9) {
        throw new Error('Home Price H cannot exceed $1,000,000,000.');
      }
      if (target !== 'D' && (Df < 0 || Df > Hf)) {
        throw new Error(`Down Payment D must be between $0 and Home Price ($${fmtCurrency(Hf)}).`);
      }
      if (target !== 'r' && (aprf < 0 || aprf > 100)) {
        throw new Error('APR must be between 0% and 100%.');
      }
      if (target !== 'n' && (yearsf < 0.1 || yearsf > 50)) {
        throw new Error('Years must be between 0.1 and 50 years (1 to 600 months).');
      }
      if (target !== 'M' && Mf <= 0) {
        throw new Error('Monthly Payment M must be greater than $0.');
      }

      let rf = aprf / 100 / 12;
      let nf = Math.round(yearsf * 12);
      let Lf = Hf - Df;

      let discrepancyWarning: string | null = null;

      // Execute specific solver
      if (target === 'M') {
        Lf = Hf - Df;
        if (Lf <= 0) {
          throw new Error('Down payment equals or exceeds Home Price. Amount Financed must be > 0.');
        }
        const ff = factor(rf, nf);
        const expectedM = Lf * ff;

        // If 5 parameters were provided, check discrepancy
        if (hasM && Mf > 0) {
          const errorPct = ((Mf - expectedM) / expectedM) * 100;
          if (Math.abs(errorPct) > 2) {
            discrepancyWarning = `Payment discrepancy: Specified Monthly ($${fmtCurrency(Mf)}) deviates by ${
              errorPct > 0 ? '+' : ''
            }${errorPct.toFixed(1)}% from exact amortisation ($${fmtCurrency(
              expectedM
            )}). Showing balanced offer at $${fmtCurrency(expectedM)}.`;
          }
        }
        Mf = expectedM;
      } else if (target === 'H') {
        const ff = factor(rf, nf);
        Hf = Df + Mf / ff;
        Lf = Hf - Df;
        if (Hf > 1e9) throw new Error('Calculated Home Price exceeds $1,000,000,000.');
      } else if (target === 'D') {
        const ff = factor(rf, nf);
        Df = Hf - Mf / ff;
        if (Df < 0) {
          throw new Error(
            `Down payment negative (-$${fmtCurrency(Math.abs(Df))}). Monthly payment ($${fmtCurrency(
              Mf
            )}) cannot cover loan amortisation.`
          );
        }
        Lf = Hf - Df;
      } else if (target === 'n') {
        Lf = Hf - Df;
        if (Lf <= 0) throw new Error('Amount Financed must be > 0.');
        if (Mf <= Lf * rf) {
          throw new Error(
            `Payment $${fmtCurrency(Mf)} is too low. Needs > $${fmtCurrency(
              Lf * rf
            )}/mo just to cover interest-only.`
          );
        }
        nf = Math.log(Mf / (Mf - Lf * rf)) / Math.log(1 + rf);
        if (!Number.isFinite(nf) || nf <= 0 || nf > 600) {
          throw new Error('Loan term exceeds allowable 50 years range.');
        }
        yearsf = nf / 12;
      } else if (target === 'r') {
        Lf = Hf - Df;
        if (Lf <= 0) throw new Error('Amount Financed must be > 0.');
        rf = solve_r(Lf, Mf, nf);
        aprf = rf * 12 * 100;
      }

      // Final calculations
      const totalLoan = Mf * nf;
      const totalPaid = totalLoan + Df;
      const interest = totalLoan - Lf;
      const interestPct = totalPaid > 0 ? (interest / totalPaid) * 100 : 0;
      const downPct = Hf > 0 ? (Df / Hf) * 100 : 0;

      if (discrepancyWarning) {
        setWarning(discrepancyWarning);
      }

      setOffer({
        H: Hf,
        D: Df,
        L: Lf,
        apr: aprf,
        years: yearsf,
        n: Math.round(nf),
        M: Mf,
        totalLoan,
        totalPaid,
        interest,
        interestPct,
        downPct,
      });
    } catch (err: unknown) {
      setOffer(null);
      setMenuMatrix(null);
      const msg = err instanceof Error ? err.message : 'Calculation error occurred.';
      setWarning(msg);
    }
  };

  // Run on initial load with example H=30000, D=9000, APR=22, Years=10, M=""
  useEffect(() => {
    runEngine('30000', '9000', '22', '10', '', 'Auto');
  }, []);

  const handleGenerate = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (soundEnabled) {
      playCalculationChime();
    }
    setCalcKey((prev) => prev + 1);
    setJustCalculated(true);
    setTimeout(() => setJustCalculated(false), 900);
    runEngine(hStr, dStr, aprStr, yearsStr, mStr, solveFor);
  };

  const selectMenuOption = (opt: MenuOption) => {
    if (soundEnabled) {
      playCalculationChime();
    }
    setCalcKey((prev) => prev + 1);
    setJustCalculated(true);
    setTimeout(() => setJustCalculated(false), 900);
    setHStr(opt.H.toString());
    setDStr(opt.D.toString());
    setAprStr(opt.apr.toString());
    setYearsStr(opt.years.toString());
    setMStr('');
    setSolveFor('Auto');
    runEngine(opt.H.toString(), opt.D.toString(), opt.apr.toString(), opt.years.toString(), '', 'Auto');
  };

  // Analysis paragraph generator strictly following the requested template
  const renderAnalysis = (data: OfferResult) => {
    const downPctNum = data.downPct;
    const tone =
      downPctNum < 20
        ? 'low upfront commitment'
        : downPctNum < 35
        ? 'balanced upfront commitment'
        : 'strong equity position with lower risk';

    const termTone =
      data.years <= 8
        ? 'short-term payoff'
        : data.years <= 12
        ? 'moderate term'
        : 'longer, more affordable term';

    const costTone =
      data.apr <= 18
        ? 'keeps borrowing cost efficient'
        : data.apr <= 24
        ? 'reflects current market pricing'
        : 'carries a premium rate';

    const affordability =
      data.M > 500
        ? `Monthly is on higher side, best suited for buyers with stable income above $${Math.round(
            data.M / 0.3
          )}/month (30% rule).`
        : 'Payment remains affordable for entry-level buyers and supports steady cash flow for the seller.';

    return (
      `This carryback offer is structured with a ${downPctNum.toFixed(
        1
      )}% down payment, giving a ${tone}. With ${fmtNum(data.years)} years (${
        data.n
      } months) at ${fmtNum(data.apr)}% APR, the monthly payment of $${fmtCurrency(
        data.M
      )} provides a ${termTone} that ${costTone}. Over the life of the loan, total interest of $${fmtCurrency(
        data.interest
      )} represents ${data.interestPct.toFixed(
        1
      )}% of total paid, leaving buyer with full ownership after $${fmtCurrency(
        data.totalPaid
      )} total investment. ${affordability}`
    );
  };

  return (
    <div className="bg-[#f5f5f7] min-h-screen py-8 px-4 flex flex-col justify-start">
      <div
        className="w-full max-w-[600px] mx-auto bg-white rounded-[22px] p-[22px] shadow-[0_10px_40px_rgba(0,0,0,0.08)] box-border"
        style={{ maxWidth: '600px', borderRadius: '22px', padding: '22px' }}
      >
        {/* BRANDING HEADER */}
        <div className="flex justify-between items-center w-full">
          <div
            className="text-[20px] font-[900] tracking-[-0.5px] text-[#111]"
            style={{ fontSize: '20px', fontWeight: 900, letterSpacing: '-0.5px' }}
          >
            Carryback Mortgage Calculator
          </div>
          <div
            className="text-[9px] bg-[#111] text-white px-[10px] py-[6px] rounded-[999px] tracking-[0.5px]"
            style={{
              fontSize: '9px',
              background: '#111',
              color: 'white',
              padding: '6px 10px',
              borderRadius: '999px',
              letterSpacing: '0.5px',
            }}
          >
            OFFLINE
          </div>
        </div>

        {/* CONSULTANT PILL */}
        <div className="mt-3">
          <div
            className="inline-block text-[13px] font-[700] bg-[#f1f1f3] px-[12px] py-[8px] rounded-[10px] border border-[#e6e6e8] text-[#111]"
            style={{
              fontSize: '13px',
              fontWeight: 700,
              background: '#f1f1f3',
              padding: '8px 12px',
              borderRadius: '10px',
              border: '1px solid #e6e6e8',
            }}
          >
            Emmanuel Magandi - Property Consultant
          </div>
        </div>

        {/* HERO FORMULA CARD (IMAGE 2) */}
        <div className="mt-4 mb-3 bg-white rounded-[14px] border border-[#e6e6e8] p-3.5 sm:p-4 text-center shadow-xs">
          <div className="w-full flex items-center justify-center">
            <div className="inline-flex items-center justify-center text-[14px] sm:text-[18px] font-sans font-medium text-[#111] select-none">
              <span>
                <span className="italic font-semibold">M</span> = (<span className="italic font-semibold">H</span> − <span className="italic font-semibold">D</span>) ×
              </span>
              <span className="text-[20px] sm:text-[26px] font-light text-[#555] leading-none ml-1 mr-0.5">[</span>
              <span className="inline-flex flex-col items-center justify-center px-1 text-[11px] sm:text-[13px] leading-tight">
                <span className="border-b border-[#111] pb-0.5">
                  <span className="italic font-semibold">r</span>(1 + <span className="italic font-semibold">r</span>)<sup>n</sup>
                </span>
                <span className="pt-0.5">
                  (1 + <span className="italic font-semibold">r</span>)<sup>n</sup> − 1
                </span>
              </span>
              <span className="text-[20px] sm:text-[26px] font-light text-[#555] leading-none mr-1 ml-0.5">]</span>
            </div>
          </div>
          <div className="text-[10px] sm:text-[11px] text-gray-500 font-normal mt-2 border-t border-[#f0f0f3] pt-2 leading-tight">
            M = Monthly Payment, H = Home Price, D = Down Payment, r = monthly rate, n = number of payments
          </div>
        </div>

        {/* CONDITION TO AVOID CONTRADICTION & ASSUMPTIONS (IMAGE 1) */}
        <div className="mb-4 bg-[#f8f8fa] border border-[#e6e6e8] rounded-[14px] p-3.5 sm:p-4 font-mono text-[10px] sm:text-[11px] text-[#222] leading-relaxed">
          <div className="font-bold text-[#111] tracking-wider text-[10.5px] uppercase">
            CONDITION TO AVOID CONTRADICTION
          </div>
          <div className="w-full border-b border-[#e2e2e6] my-1.5" />
          <div className="font-semibold text-[#111]">Let L = H - D  (financed principal)</div>

          <div className="mt-2 font-bold text-[#111]">Assumptions:</div>
          <div className="pl-1 space-y-0.5">
            <div>• D is cash paid at t = 0, NOT financed</div>
            <div>• 0 ≤ D ≤ H</div>
            <div>• Only L accrues interest</div>
            <div>• If D = H → L = 0 → M = 0 (cash purchase)</div>
          </div>

          <div className="mt-2">
            <div><span className="font-bold text-[#111]">Then:</span> M = L × factor</div>
            <div className="pl-6 text-[9.5px] sm:text-[10.5px] text-[#444]">factor = r(1+r)^n / ((1+r)^n - 1)</div>
          </div>

          <div className="mt-2 font-bold text-[#111]">Rewritten with L:</div>
          <div className="pl-2 space-y-0.5">
            <div>• M = L × factor</div>
            <div>• H = D + L = D + M/factor</div>
            <div>• D = H - L = H - M/factor</div>
            <div>• n = log( M/(M - Lr) ) / log(1+r)  [requires M &gt; Lr]</div>
            <div>• r: solve L×factor - M = 0 [numerically]</div>
          </div>

          <div className="mt-2 font-bold text-[#111]">Why (H-D) must be first:</div>
          <div className="pl-2 space-y-0.5 text-[#333]">
            <div>Interest applies ONLY to L = H-D</div>
            <div>Doing H×factor - D applies interest to D (wrong)</div>
          </div>
        </div>

        {/* INPUT GRID */}
        <form onSubmit={handleGenerate}>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-[10px]">
            <div>
              <label
                htmlFor={hId}
                className="block text-[10px] uppercase font-bold text-[#555]"
                style={{ fontSize: '10px', fontWeight: 'bold', color: '#555' }}
              >
                Home Price H ($)
              </label>
              <input
                id={hId}
                type="number"
                inputMode="decimal"
                value={hStr}
                onChange={(e) => setHStr(e.target.value)}
                placeholder="30000"
                className="w-full border border-[#ddd] rounded-[12px] p-[12px] mt-[5px] box-border text-[14px] text-[#111] focus:outline-none focus:border-[#111]"
                style={{
                  border: '1px solid #ddd',
                  borderRadius: '12px',
                  padding: '12px',
                  marginTop: '5px',
                  fontSize: '14px',
                }}
              />
            </div>

            <div>
              <label
                htmlFor={dId}
                className="block text-[10px] uppercase font-bold text-[#555]"
                style={{ fontSize: '10px', fontWeight: 'bold', color: '#555' }}
              >
                Down Payment D ($)
              </label>
              <input
                id={dId}
                type="number"
                inputMode="decimal"
                value={dStr}
                onChange={(e) => setDStr(e.target.value)}
                placeholder="9000"
                className="w-full border border-[#ddd] rounded-[12px] p-[12px] mt-[5px] box-border text-[14px] text-[#111] focus:outline-none focus:border-[#111]"
                style={{
                  border: '1px solid #ddd',
                  borderRadius: '12px',
                  padding: '12px',
                  marginTop: '5px',
                  fontSize: '14px',
                }}
              />
            </div>

            <div>
              <label
                htmlFor={aprId}
                className="block text-[10px] uppercase font-bold text-[#555]"
                style={{ fontSize: '10px', fontWeight: 'bold', color: '#555' }}
              >
                APR %
              </label>
              <input
                id={aprId}
                type="number"
                inputMode="decimal"
                step="any"
                value={aprStr}
                onChange={(e) => setAprStr(e.target.value)}
                placeholder="22"
                className="w-full border border-[#ddd] rounded-[12px] p-[12px] mt-[5px] box-border text-[14px] text-[#111] focus:outline-none focus:border-[#111]"
                style={{
                  border: '1px solid #ddd',
                  borderRadius: '12px',
                  padding: '12px',
                  marginTop: '5px',
                  fontSize: '14px',
                }}
              />
            </div>

            <div>
              <label
                htmlFor={yearsId}
                className="block text-[10px] uppercase font-bold text-[#555]"
                style={{ fontSize: '10px', fontWeight: 'bold', color: '#555' }}
              >
                Years
              </label>
              <input
                id={yearsId}
                type="number"
                inputMode="decimal"
                step="any"
                value={yearsStr}
                onChange={(e) => setYearsStr(e.target.value)}
                placeholder="10"
                className="w-full border border-[#ddd] rounded-[12px] p-[12px] mt-[5px] box-border text-[14px] text-[#111] focus:outline-none focus:border-[#111]"
                style={{
                  border: '1px solid #ddd',
                  borderRadius: '12px',
                  padding: '12px',
                  marginTop: '5px',
                  fontSize: '14px',
                }}
              />
            </div>

            <div>
              <label
                htmlFor={mId}
                className="block text-[10px] uppercase font-bold text-[#555]"
                style={{ fontSize: '10px', fontWeight: 'bold', color: '#555' }}
              >
                Monthly M
              </label>
              <input
                id={mId}
                type="number"
                inputMode="decimal"
                step="any"
                value={mStr}
                onChange={(e) => setMStr(e.target.value)}
                placeholder="auto"
                className="w-full border border-[#ddd] rounded-[12px] p-[12px] mt-[5px] box-border text-[14px] text-[#111] focus:outline-none focus:border-[#111]"
                style={{
                  border: '1px solid #ddd',
                  borderRadius: '12px',
                  padding: '12px',
                  marginTop: '5px',
                  fontSize: '14px',
                }}
              />
            </div>

            <div>
              <label
                htmlFor={solveForId}
                className="block text-[10px] uppercase font-bold text-[#555]"
                style={{ fontSize: '10px', fontWeight: 'bold', color: '#555' }}
              >
                Solve For
              </label>
              <select
                id={solveForId}
                value={solveFor}
                onChange={(e) => setSolveFor(e.target.value)}
                className="w-full border border-[#ddd] rounded-[12px] p-[12px] mt-[5px] box-border text-[14px] text-[#111] bg-white focus:outline-none focus:border-[#111]"
                style={{
                  border: '1px solid #ddd',
                  borderRadius: '12px',
                  padding: '12px',
                  marginTop: '5px',
                  fontSize: '14px',
                }}
              >
                <option value="Auto">Auto</option>
                <option value="M">M</option>
                <option value="H">H</option>
                <option value="D">D</option>
                <option value="n">n</option>
                <option value="r">r</option>
              </select>
            </div>
          </div>

          {/* Audio toggle and action header */}
          <div className="flex items-center justify-between mt-3 mb-1 text-[11px] text-gray-500">
            <span className="font-semibold text-gray-600 uppercase tracking-wider text-[10px]">
              Amortisation Actions
            </span>
            <button
              type="button"
              onClick={() => setSoundEnabled(!soundEnabled)}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-[8px] bg-[#f1f1f3] hover:bg-[#e6e6e9] text-[#222] transition-colors cursor-pointer text-[11px] font-semibold"
              title={soundEnabled ? 'Calculation sound enabled (click to mute)' : 'Calculation sound muted (click to enable)'}
            >
              <span>{soundEnabled ? '🔔' : '🔕'}</span>
              <span>{soundEnabled ? 'Sound On' : 'Sound Off'}</span>
            </button>
          </div>

          <button
            type="submit"
            className={`w-full text-white border-0 rounded-[12px] font-[900] p-[14px] mt-1 cursor-pointer transition-all duration-200 flex items-center justify-center gap-2 ${
              justCalculated
                ? 'bg-emerald-700 scale-[0.99] shadow-inner'
                : 'bg-[#111] hover:bg-[#262626] active:scale-[0.98]'
            }`}
            style={{
              width: '100%',
              borderRadius: '12px',
              fontWeight: 900,
              padding: '14px',
              cursor: 'pointer',
            }}
          >
            {justCalculated ? (
              <>
                <span className="text-[16px] leading-none">✓</span>
                <span>OFFER CALCULATED &amp; VERIFIED</span>
              </>
            ) : (
              <span>GENERATE CARRYBACK OFFER</span>
            )}
          </button>
        </form>

        {/* WARNING CONTAINER (id="warn") */}
        <div
          id="warn"
          style={{
            background: '#fff3cd',
            color: '#664d03',
            padding: '10px',
            borderRadius: '10px',
            fontSize: '12px',
            display: warning ? 'block' : 'none',
            whiteSpace: 'pre-wrap',
            marginTop: '12px',
          }}
        >
          {warning}
        </div>

        {/* 1-3 PARAMS MATRIX MENU */}
        {menuMatrix && menuMatrix.length > 0 && (
          <div className="mt-4 pt-4 border-t border-[#eee]">
            <div className="text-[11px] font-bold uppercase tracking-[1px] text-[#555] mb-2">
              Select Term & Rate Matrix Tier
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {menuMatrix.map((opt, idx) => (
                <button
                  key={`${opt.apr}-${opt.years}-${idx}`}
                  type="button"
                  onClick={() => selectMenuOption(opt)}
                  className="text-left p-2.5 rounded-[10px] border border-[#e6e6e8] bg-[#f9f9fb] hover:bg-[#111] hover:text-white transition-all cursor-pointer group"
                >
                  <div className="text-[11px] font-bold group-hover:text-white text-[#111]">
                    {opt.years} yrs @ {opt.apr}%
                  </div>
                  <div className="text-[12px] font-black group-hover:text-white text-[#111] mt-0.5">
                    ${fmtCurrency(opt.M)}/mo
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* OFFER CONTAINER (id="offer") */}
        <div
          id="offer"
          key={calcKey}
          className={calcKey > 0 ? 'animate-offer-pop' : ''}
          style={{
            background: '#111',
            color: 'white',
            borderRadius: '16px',
            padding: '18px',
            marginTop: '18px',
            display: offer ? 'block' : 'none',
          }}
        >
          {offer && (
            <>
              <div className="flex items-center justify-between pb-1">
                <div
                  className="text-[11px] opacity-60 tracking-[1.2px] uppercase font-bold"
                  style={{ fontSize: '11px', opacity: 0.6, letterSpacing: '1.2px', textTransform: 'uppercase' }}
                >
                  CARRYBACK DEAL OFFER
                </div>
                {calcKey > 0 && (
                  <span className="text-[9.5px] tracking-wider uppercase font-bold bg-white/10 text-emerald-300 px-2 py-0.5 rounded-full animate-badge-shine">
                    ✓ CALCULATED
                  </span>
                )}
              </div>

              <div
                className="flex justify-between items-center py-[9px] border-b border-[#262626] text-[14px]"
                style={{ padding: '9px 0', borderBottom: '1px solid #262626', fontSize: '14px' }}
              >
                <span className="text-gray-400">Home Price</span>
                <span className="font-semibold text-white">${fmtCurrency(offer.H)}</span>
              </div>

              <div
                className="flex justify-between items-center py-[9px] border-b border-[#262626] text-[14px]"
                style={{ padding: '9px 0', borderBottom: '1px solid #262626', fontSize: '14px' }}
              >
                <span className="text-gray-400">Down Payment</span>
                <span className="font-semibold text-white">
                  ${fmtCurrency(offer.D)} ({offer.downPct.toFixed(1)}%)
                </span>
              </div>

              <div
                className="flex justify-between items-center py-[9px] border-b border-[#262626] text-[14px]"
                style={{ padding: '9px 0', borderBottom: '1px solid #262626', fontSize: '14px' }}
              >
                <span className="text-gray-400">Amount Financed</span>
                <span className="font-semibold text-white">${fmtCurrency(offer.L)}</span>
              </div>

              <div
                className="flex justify-between items-center py-[9px] border-b border-[#262626] text-[14px]"
                style={{ padding: '9px 0', borderBottom: '1px solid #262626', fontSize: '14px' }}
              >
                <span className="text-gray-400">Rate</span>
                <span className="font-semibold text-white">{fmtNum(offer.apr)}% APR</span>
              </div>

              <div
                className="flex justify-between items-center py-[9px] border-b border-[#262626] text-[14px]"
                style={{ padding: '9px 0', borderBottom: '1px solid #262626', fontSize: '14px' }}
              >
                <span className="text-gray-400">Term</span>
                <span className="font-semibold text-white">{fmtNum(offer.years)} years</span>
              </div>

              <div
                className={`flex justify-between items-center py-[9px] border-b border-[#262626] text-[14px] rounded px-1 -mx-1 ${
                  calcKey > 0 ? 'animate-highlight-flash' : ''
                }`}
                style={{ padding: '9px 4px', borderBottom: '1px solid #262626', fontSize: '14px' }}
              >
                <span className="text-gray-400">Monthly</span>
                <span className="font-bold text-white text-[15px]">${fmtCurrency(offer.M)}</span>
              </div>

              <div
                className={`flex justify-between items-center py-[9px] text-[14px] rounded px-1 -mx-1 ${
                  calcKey > 0 ? 'animate-highlight-flash' : ''
                }`}
                style={{ padding: '9px 4px', fontSize: '14px' }}
              >
                <span className="text-gray-400">Total Paid</span>
                <span className="font-bold text-white text-[15px]">${fmtCurrency(offer.totalPaid)}</span>
              </div>
            </>
          )}
        </div>

        {/* ANALYSIS CONTAINER (id="analysis") */}
        <div
          id="analysis"
          style={{
            background: '#f9f9fb',
            border: '1px solid #e8e8ec',
            borderRadius: '14px',
            padding: '14px',
            fontSize: '13px',
            lineHeight: 1.65,
            display: offer ? 'block' : 'none',
            marginTop: '14px',
          }}
        >
          {offer && renderAnalysis(offer)}
        </div>
      </div>
    </div>
  );
}
