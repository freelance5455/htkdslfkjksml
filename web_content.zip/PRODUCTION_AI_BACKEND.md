# Smart v1.4 — Production AI Backend

Smart now has a server-side AI integration using the OpenAI Responses API.

## Architecture

Android app → HTTPS `/api/chat` → Smart backend → OpenAI Responses API

The OpenAI API key is intentionally kept on the server and is NOT embedded in the APK.

## Required before production

1. Deploy `backend/` to a Node.js 20+ HTTPS host.
2. Set `OPENAI_API_KEY` as a server secret.
3. Optionally set `OPENAI_MODEL` (default: `gpt-6-luna`).
4. Set `CORS_ORIGIN` to your dashboard origin.
5. Replace `BASE_URL` in `SmartAiClient.kt` with the deployed HTTPS backend URL.
6. Rebuild the Android APK/AAB.
7. Add authentication, persistent database-backed usage/entitlements, abuse/rate limiting, and Google Play subscription verification before a public commercial launch.

## Important

The AI backend provides natural-language intelligence. Android phone actions still require the appropriate Android APIs and user-granted permissions. The model is not given unrestricted control over the device.

OpenAI's current API guidance uses the Responses API for new integrations; the older Assistants API has been sunset. See the official migration documentation.
