# PETER MEDIE AI STUDIO — updated mobile app

## Included
- Dark purple mobile-first photo + video studio.
- Creator splash for 3 seconds on every app launch or return: **OJENYA PETER EGBE** (uppercase decorative serif).
- Google sign-in using Firebase Authentication.
- Text-to-image and text-to-video generation through Agnes AI.
- Image upload for image editing. Video generation is text-to-video in this build.
- Video aspect ratios 16:9, 9:16, 1:1; image ratios; downloadable result links.
- Video duration choices 5, 8, 10, 12 seconds.

## Important model limitations
The configured free video model `agnes-video-2.5-flash` documents 4–12 second clips. The interface and server both allow 5, 8, 10 and 12 seconds. Vertical 9:16 is selected by default for Reels, TikTok and Shorts. The image and video free offers, quotas, rate limits and availability may change. The owner must verify current free access and usage caps in the Agnes account before publishing. Do not advertise unlimited free generations. See the public API reference: https://github.com/1038lab/Agnes-AI/blob/main/references/api.md and model catalog: https://github.com/AgnesAI-Labs/skills/blob/main/agnes-ai-models/references/model_catalog.md

## Required setup before it works online
This is not plug-and-play until the owner configures Firebase and Agnes.

### 1. Firebase Google sign-in
1. Create a Firebase project at https://console.firebase.google.com/.
2. Add a Web app and copy its config values.
3. In Authentication > Sign-in method, enable Google.
4. In Authentication > Settings > Authorized domains, add the Netlify site domain.
5. Copy `.env.example` to `.env` and fill `VITE_FIREBASE_API_KEY`, `VITE_FIREBASE_AUTH_DOMAIN`, `VITE_FIREBASE_PROJECT_ID`, `VITE_FIREBASE_APP_ID`. These are public web config values, not private secrets.
6. Set the same project ID as Netlify environment variable `FIREBASE_PROJECT_ID`.

### 2. Agnes AI
1. Create/verify an Agnes Platform account and check that the selected image and `agnes-video-2.5-flash` models are currently available at $0 with a usable quota.
2. Add `AGNES_API_KEY` as a Netlify environment variable. Never put this key in frontend code or send it to users.

### 3. Deploy
1. Upload the contents of this project folder to a GitHub repository.
2. In Netlify choose Add new site > Import an existing project and connect that repository.
3. Set build command to `npm run build`, publish directory to `dist`, and functions directory to `netlify/functions`.
4. Add the Firebase `VITE_...` values as build environment variables, and add `FIREBASE_PROJECT_ID` plus `AGNES_API_KEY` as Netlify environment variables.
5. Trigger a fresh deploy after saving the variables. Netlify Drop alone does not deploy the serverless functions; do not use the simple drag-and-drop deploy for this project.

## Build
Run `npm install` and then `npm run build`. A successful deploy also requires the provider and Firebase setup above. This source package has not been tested against a live Agnes account because no private API key or Firebase project credentials are included.

## Security and limitations
The serverless functions verify Firebase ID tokens before calling Agnes. The Agnes API key remains server-side. Configure usage caps in the provider dashboard; frontend sign-in does not itself enforce per-user generation quotas. Generated files are downloadable, but this starter does not yet maintain a cloud project library. Free model promotions, quotas, and queue availability can change.
