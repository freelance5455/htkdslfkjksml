import React, { useEffect, useRef, useState } from 'react';
import { initializeApp, getApps } from 'firebase/app';
import { getAuth, GoogleAuthProvider, onAuthStateChanged, signInWithRedirect, getRedirectResult, signOut } from 'firebase/auth';
import { createRoot } from 'react-dom/client';
import {
  Plus, Clapperboard, Image as ImageIcon, UserRoundPlus,
  WandSparkles, Home, Folder, Settings, ArrowLeft, ArrowUp,
  ChevronDown, Video, Upload, X, Check, Sparkles, LogOut
} from 'lucide-react';
import './style.css';

const modelChoices = { image: ['Agnes Image 2.5 Flash'], video: ['Agnes Video 2.5 Flash'] };
const imageRatios = ['16:9', '4:3', '1:1', '3:4', '9:16'];
const videoRatios = ['16:9', '9:16', '1:1'];

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};
const firebaseReady = Object.values(firebaseConfig).every(Boolean);
const firebaseApp = firebaseReady ? (getApps()[0] || initializeApp(firebaseConfig)) : null;
const auth = firebaseApp ? getAuth(firebaseApp) : null;

function App() {
  const [screen, setScreen] = useState('home');
  const [user, setUser] = useState(null);
  const [authReady, setAuthReady] = useState(false);
  const [authMessage, setAuthMessage] = useState('');
  const [creatorToast, setCreatorToast] = useState(true);
  useEffect(() => {
    let timer;
    const showCreatorMessage = () => {
      setCreatorToast(true);
      if (timer) window.clearTimeout(timer);
      timer = window.setTimeout(() => setCreatorToast(false), 3000);
    };
    const handleVisibility = () => {
      if (document.visibilityState === 'visible') showCreatorMessage();
    };
    showCreatorMessage();
    document.addEventListener('visibilitychange', handleVisibility);
    window.addEventListener('pageshow', showCreatorMessage);
    return () => {
      if (timer) window.clearTimeout(timer);
      document.removeEventListener('visibilitychange', handleVisibility);
      window.removeEventListener('pageshow', showCreatorMessage);
    };
  }, []);
  useEffect(() => {
    if (!auth) { setAuthReady(true); return; }
    getRedirectResult(auth).catch(error => setAuthMessage(error.message || 'Google sign-in failed.')).finally(() => setAuthReady(true));
    return onAuthStateChanged(auth, nextUser => { setUser(nextUser); setAuthReady(true); });
  }, []);
  async function loginWithGoogle() {
    if (!auth) { setAuthMessage('Google sign-in is not configured yet. The site owner must add the Firebase web configuration.'); return; }
    try { setAuthMessage(''); await signInWithRedirect(auth, new GoogleAuthProvider()); }
    catch (error) { setAuthMessage(error.message || 'Google sign-in failed. Please try again.'); }
  }
  async function logout() { if (auth) await signOut(auth); }

  const [kind, setKind] = useState('image');
  const [ratio, setRatio] = useState('9:16');
  const [quantity, setQuantity] = useState(1);
  const [duration, setDuration] = useState(8);
  const [resultUrl, setResultUrl] = useState('');
  const [generating, setGenerating] = useState(false);
  const [model, setModel] = useState(modelChoices.image[0]);
  const [prompt, setPrompt] = useState('');
  const [showModels, setShowModels] = useState(false);
  const [reference, setReference] = useState(null);
  const [referenceData, setReferenceData] = useState('');
  const [notice, setNotice] = useState('');
  const fileRef = useRef(null);

  function startCreate(type = 'image') {
    setKind(type);
    setRatio('9:16');
    setModel(modelChoices[type][0]);
    setPrompt('');
    setReference(null);
    setReferenceData('');
    setResultUrl('');
    setDuration(8);
    setNotice('');
    setScreen('create');
  }
  function changeKind(type) {
    setKind(type);
    setRatio('9:16');
    setModel(modelChoices[type][0]);
    setShowModels(false);
  }
  async function generate() {
    if (!user) { setNotice('Please sign in with Google before generating.'); return; }
    if (!prompt.trim()) { setNotice('Write a prompt first, then tap generate.'); return; }
    if (reference && kind === 'video') { setNotice('Remove the photo reference to create a text-to-video clip.'); return; }
    setGenerating(true); setNotice('Sending your request to the AI service…'); setResultUrl('');
    try {
      const idToken = await user.getIdToken();
      const response = await fetch('/.netlify/functions/generate', {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${idToken}` },
        body: JSON.stringify({ prompt, kind, ratio, quantity: kind === 'video' ? 1 : quantity, duration, referenceData })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'The AI service could not process your request.');
      if (kind === 'image' && data.mediaUrl) {
        setResultUrl(data.mediaUrl); setNotice('Your image is ready. Tap Download to save it to your phone.');
      } else if (kind === 'video' && data.videoId) {
        setNotice('Your video is being created. Keep this page open while we check its progress.');
        let completed = false;
        for (let attempt = 0; attempt < 60; attempt++) {
          await new Promise(resolve => setTimeout(resolve, 10000));
          const statusResponse = await fetch(`/.netlify/functions/status?video_id=${encodeURIComponent(data.videoId)}`, { headers: { 'Authorization': `Bearer ${idToken}` } });
          const statusData = await statusResponse.json();
          if (!statusResponse.ok) throw new Error(statusData.error || 'Could not check video status.');
          if (statusData.status === 'completed') {
            if (!statusData.mediaUrl) throw new Error('The video task completed but the provider did not return a playable video URL.');
            setResultUrl(statusData.mediaUrl); setNotice('Your video is ready. Tap Download to save it to your phone.'); completed = true; break;
          }
          if (statusData.status === 'failed') throw new Error(statusData.error || 'The video generation failed. Try a different prompt.');
          setNotice(`Creating your video… ${Math.min(attempt + 1, 60)} checks completed.`);
        }
        if (!completed) throw new Error('This video is taking longer than expected. Try again later.');
      } else throw new Error('The AI service returned an incomplete result.');
    } catch (error) {
      setNotice(error.message || 'Generation failed. Check your connection and try again.');
    } finally { setGenerating(false); }
  }
  function handleReference(file) {
    setReference(file || null); setReferenceData('');
    if (!file) return;
    if (!file.type.startsWith('image/')) { setReference(null); setNotice('Please choose an image file as your reference.'); return; }
    if (file.size > 3 * 1024 * 1024) { setReference(null); setNotice('Please choose an image smaller than 3 MB.'); return; }
    const reader = new FileReader();
    reader.onload = () => setReferenceData(String(reader.result || ''));
    reader.onerror = () => setNotice('Could not read that image. Please try another file.');
    reader.readAsDataURL(file);
  }
  const title = screen === 'create' ? 'New creation' : screen === 'projects' ? 'Projects' : screen === 'settings' ? 'Settings' : '';

  return (
    <div className="phone-shell">
      {creatorToast && <div className="creator-splash" role="status" aria-live="polite">
        <span className="creator-splash-kicker">A CREATION BY</span>
        <strong>OJENYA PETER EGBE</strong>
        <span className="creator-splash-rule" />
      </div>}
      {!authReady && <div className="auth-loading">Loading your studio…</div>}
      {screen === 'home' && <>
        <header className="home-header">
          <div className="brand"><strong>PETER MEDIE</strong><span>AI STUDIO</span></div>
          <div className="header-actions">
            {user ? <button className="account-pill" onClick={logout} title="Sign out"><img src={user.photoURL || ''} alt=""/><span>{user.displayName?.split(' ')[0] || 'Account'}</span><LogOut size={15}/></button> : <button className="google-signin compact" onClick={loginWithGoogle}>Sign in</button>}
          </div>
        </header>
        {!user && <div className="signin-banner"><strong>Sign in to start creating</strong><span>Use your Google account to access the studio.</span><button className="google-signin" onClick={loginWithGoogle}><span className="google-g">G</span> Continue with Google</button>{authMessage && <small>{authMessage}</small>}</div>}
        <section className="quick-actions" aria-label="Creation tools">
          <button className="tool-card" onClick={() => startCreate('video')}>
            <div className="tool-art art-video"><Clapperboard size={47}/><span>VIDEO</span></div><b>Create video</b>
          </button>
          <button className="tool-card" onClick={() => startCreate('image')}>
            <div className="tool-art art-photo"><ImageIcon size={48}/><span>PHOTO</span></div><b>Create photo</b>
          </button>
          <button className="tool-card" onClick={() => startCreate('video')}>
            <div className="tool-art art-avatar"><UserRoundPlus size={48}/><span>AVATAR</span></div><b>Avatar video</b>
          </button>
          <button className="tool-card" onClick={() => startCreate('video')}>
            <div className="tool-art art-animate"><WandSparkles size={48}/><span>ANIMATE</span></div><b>Reel video</b>
          </button>
        </section>
        <section className="empty-projects">
          <div className="section-heading"><h1>Projects</h1><button className="new-button" onClick={() => startCreate('image')}><Plus size={21}/> New</button></div>
          <div className="empty-illustration"><div className="glow-orb"><Clapperboard size={76}/><span><Video size={29}/></span></div><Sparkles className="spark spark-one"/><Sparkles className="spark spark-two"/></div>
          <h2>No Projects Yet!</h2>
          <p>Start creating amazing videos and images<br/>with <strong>PETER MEDIE AI</strong></p>
          <button className="primary-button" onClick={() => startCreate('image')}><WandSparkles size={23}/> New Project</button>
        </section>
      </>}

      {screen === 'create' && <>
        <header className="sub-header">
          <button className="back-button" onClick={() => setScreen('home')} aria-label="Back"><ArrowLeft/></button>
          <div><span className="eyebrow">PETER MEDIE AI STUDIO</span><h1>{title}</h1></div>
          <button className="icon-button" onClick={() => setNotice('Your current creation settings are ready.')} aria-label="More"><span className="dots">•••</span></button>
        </header>
        <main className="create-main">
          <div className="workspace">
            <div className="workspace-icon">{kind === 'video' ? <Video size={32}/> : <ImageIcon size={32}/>}<Plus size={17}/></div>
            <p>Your {kind === 'video' ? 'video' : 'image'} will appear here</p>
            <span>Describe what you want to make below</span>
          </div>
          <section className="composer">
            <textarea value={prompt} onChange={e => setPrompt(e.target.value)} placeholder="What do you want to make?"/>
            {reference && <div className="file-chip"><Upload size={15}/><span>{reference.name}</span><button onClick={() => { setReference(null); setReferenceData(''); }} aria-label="Remove file"><X size={15}/></button></div>}
            <div className="composer-actions">
              {kind === 'image' && <><button className="add-reference" onClick={() => fileRef.current?.click()} aria-label="Add reference photo"><Plus size={27}/></button><input ref={fileRef} type="file" accept="image/*" hidden onChange={e => handleReference(e.target.files?.[0] || null)}/></>}
              <div className="composer-right"><span className="mode-chip">{kind === 'image' ? <ImageIcon size={16}/> : <Video size={16}/>} {kind === 'image' ? 'Image' : 'Video'} · x{quantity}</span><button className="generate-button" onClick={generate} aria-label="Generate"><ArrowUp size={25}/></button></div>
            </div>
          </section>
          <section className="settings-panel">
            <div className="credit-line">Free model only · provider limits may apply</div>
            <div className="mode-switch">
              <button className={kind === 'image' ? 'selected' : ''} onClick={() => changeKind('image')}><ImageIcon size={19}/> Image</button>
              <button className={kind === 'video' ? 'selected' : ''} onClick={() => changeKind('video')}><Video size={19}/> Video</button>
            </div>
            <div className="setting-label">Aspect ratio</div>
            <div className={'ratio-grid ' + (kind === 'video' ? 'two-ratios' : '')}>
              {(kind === 'image' ? imageRatios : videoRatios).map(r => <button key={r} className={ratio === r ? 'active' : ''} onClick={() => setRatio(r)}><span className={'ratio-shape shape-' + r.replace(':','-')}></span>{r}</button>)}
            </div>
            {kind === 'video' && <>
              <div className="setting-label">Video duration</div>
              <div className="duration-grid four-durations">{[5,8,10,12].map(seconds => <button key={seconds} className={duration === seconds ? 'active' : ''} onClick={() => setDuration(seconds)}>{seconds}s</button>)}</div>
              <p className="reference-hint">Vertical 9:16 is ideal for Reels, TikTok and YouTube Shorts.</p>
            </>}
            <div className="setting-label">Number of outputs</div>
            <div className="quantity-grid">{[1,2,3,4].map(n => <button key={n} className={quantity === n ? 'active' : ''} onClick={() => setQuantity(n)}>x{n}</button>)}</div>
            <div className="model-wrap">
              <button className="model-select" onClick={() => setShowModels(!showModels)}><span><Sparkles size={17}/>{model}</span><ChevronDown size={19}/></button>
              {showModels && <div className="model-menu">{modelChoices[kind].map(m => <button key={m} onClick={() => {setModel(m);setShowModels(false)}}>{m}{model === m && <Check size={16}/>}</button>)}</div>}
            </div>
            {notice && <p className="notice">{notice}</p>}
            {resultUrl && <><div className="result-preview">{kind === 'image' ? <img src={resultUrl} alt="Generated image"/> : <video src={resultUrl} controls playsInline/>}</div><a className="download-button" href={resultUrl} download><span>Download to phone</span><Upload size={18}/></a></>}
            <button className="generate-wide" onClick={generate} disabled={generating || !authReady}>{generating ? 'Generating…' : 'Generate'}</button>
          </section>
        </main>
      </>}

      {screen !== 'home' && screen !== 'create' && <>
        <header className="sub-header">
          <button className="back-button" onClick={() => setScreen('home')} aria-label="Back"><ArrowLeft/></button>
          <div><span className="eyebrow">PETER MEDIE AI STUDIO</span><h1>{title}</h1></div>
        </header>
        <div className="simple-empty"><Folder size={48}/><h2>{screen === 'projects' ? 'No Projects Yet!' : 'Studio settings'}</h2><p>{screen === 'projects' ? 'Download finished creations to keep them on your phone.' : 'Your app preferences will appear here.'}</p>{screen === 'projects' && <button className="primary-button" onClick={() => startCreate('image')}><Plus size={20}/> New Project</button>}</div>
      </>}

      <nav className="bottom-nav">
        <button className={screen === 'home' || screen === 'create' ? 'active' : ''} onClick={() => setScreen('home')}><Home/><span>Home</span></button>
        <button className={screen === 'projects' ? 'active' : ''} onClick={() => setScreen('projects')}><Folder/><span>Projects</span></button>
        <button className={screen === 'settings' ? 'active' : ''} onClick={() => setScreen('settings')}><Settings/><span>Settings</span></button>
      </nav>
    </div>
  );
}
createRoot(document.getElementById('root')).render(<App/>);
