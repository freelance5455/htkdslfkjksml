import { requireFirebaseUser } from './auth.mjs';
const json = (data, status=200) => new Response(JSON.stringify(data), { status, headers:{'Content-Type':'application/json','Cache-Control':'no-store'} });
export default async (request) => {
  if (request.method !== 'GET') return json({error:'Method not allowed'},405);
  try { await requireFirebaseUser(request); } catch (error) { return json({error:error.message || 'Sign-in required.'},401); }
  const key = process.env.AGNES_API_KEY;
  if (!key) return json({error:'AI provider key is not configured.'},503);
  const url = new URL(request.url);
  const videoId = url.searchParams.get('video_id');
  if (!videoId) return json({error:'Missing video ID.'},400);
  try {
    const model = 'agnes-video-2.5-flash';
    const upstream = await fetch(`https://apihub.agnes-ai.com/agnesapi?video_id=${encodeURIComponent(videoId)}&model_name=${encodeURIComponent(model)}`, { headers:{Authorization:`Bearer ${key}`} });
    const result = await upstream.json().catch(()=>({}));
    if (!upstream.ok) return json({error:result.error?.message || result.message || `Video status error (${upstream.status}).`},upstream.status);
    const status = String(result.status || '').toLowerCase();
    if (['completed','succeeded','success','done'].includes(status)) return json({status:'completed', mediaUrl:result.metadata?.url || result.url || result.data?.url || null});
    if (['failed','error','cancelled'].includes(status)) return json({status:'failed',error:result.error?.message || result.error || result.message || 'Video generation failed.'});
    return json({status:status || 'processing'});
  } catch (error) { return json({error:error.message || 'Could not check video status.'},500); }
};
