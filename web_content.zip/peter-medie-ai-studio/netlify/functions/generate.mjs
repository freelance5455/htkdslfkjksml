import { requireFirebaseUser } from './auth.mjs';
const API = 'https://apihub.agnes-ai.com/v1';
const json = (data, status=200) => new Response(JSON.stringify(data), { status, headers: { 'Content-Type':'application/json', 'Cache-Control':'no-store' } });
export default async (request) => {
  if (request.method !== 'POST') return json({error:'Method not allowed'},405);
  try { await requireFirebaseUser(request); } catch (error) { return json({error:error.message || 'Sign-in required.'},401); }
  const key = process.env.AGNES_API_KEY;
  if (!key) return json({error:'The studio owner has not connected the AI provider key yet.'},503);
  try {
    const body = await request.json();
    const prompt = String(body.prompt || '').trim().slice(0,4000);
    if (!prompt) return json({error:'Please enter a prompt.'},400);
    if (body.kind === 'video') {
      const seconds = Number(body.duration) || 8;
      if (![5,8,10,12].includes(seconds)) return json({error:'Choose 5, 8, 10 or 12 seconds.'},400);
      const ratio = ['16:9','9:16','1:1'].includes(body.ratio) ? body.ratio : '9:16';
      const payload = { model:'agnes-video-2.5-flash', prompt, size:'720P', seconds:String(seconds), n:1, mode:'text', aspect_ratio:ratio };
      if (body.referenceData) return json({error:'Photo references are currently supported for image editing. Create this video from its text prompt.'},400);
      const upstream = await fetch(`${API}/videos`, { method:'POST', headers:{ Authorization:`Bearer ${key}`, 'Content-Type':'application/json' }, body:JSON.stringify(payload) });
      const result = await upstream.json().catch(()=>({}));
      if (!upstream.ok) return json({error:result.error?.message || result.message || `Video provider error (${upstream.status}).`},upstream.status);
      const videoId = result.video_id || result.id || result.task_id || result.data?.video_id || result.data?.id;
      if (!videoId) return json({error:'The video provider did not return a task ID.'},502);
      return json({videoId});
    }
    const ratio = ['16:9','4:3','1:1','3:4','9:16'].includes(body.ratio) ? body.ratio : '9:16';
    const extra_body = { ratio, response_format:'url' };
    if (body.referenceData && String(body.referenceData).startsWith('data:image/')) extra_body.image = [body.referenceData];
    const payload = { model:'agnes-image-2.5-flash', prompt, size:'1K', n:Math.min(4,Math.max(1,Number(body.quantity)||1)), extra_body };
    const upstream = await fetch(`${API}/images/generations`, { method:'POST', headers:{ Authorization:`Bearer ${key}`, 'Content-Type':'application/json' }, body:JSON.stringify(payload) });
    const result = await upstream.json().catch(()=>({}));
    if (!upstream.ok) return json({error:result.error?.message || result.message || `Image provider error (${upstream.status}).`},upstream.status);
    const mediaUrl = result.data?.[0]?.url || (result.data?.[0]?.b64_json && `data:image/png;base64,${result.data[0].b64_json}`);
    if (!mediaUrl) return json({error:'The image provider did not return an image URL.'},502);
    return json({mediaUrl});
  } catch (error) { return json({error:error.message || 'Unexpected server error.'},500); }
};
