<?php
// ===== الإعدادات: عدّلها قبل الرفع =====
$DB_HOST = 'localhost';
$DB_NAME = 'YOUR_DB_NAME';
$DB_USER = 'YOUR_DB_USER';
$DB_PASS = 'YOUR_DB_PASSWORD';
$ACCESS_KEY = 'change-this-secret-key'; // مفتاح سري تشاركه مع أهلك فقط
// =====================================

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$key = $_SERVER['HTTP_X_KEY'] ?? '';
if (!hash_equals($ACCESS_KEY, $key)) {
    http_response_code(401);
    echo '{"error":"auth"}';
    exit;
}

try {
    $pdo = new PDO("mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4", $DB_USER, $DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
} catch (Exception $e) {
    http_response_code(500);
    echo '{"error":"db"}';
    exit;
}

$act = $_GET['action'] ?? 'get';

if ($act === 'get') {
    $r = $pdo->query('SELECT data, ver FROM app_state WHERE id = 1')->fetch(PDO::FETCH_ASSOC);
    // نطبع النص الخام كما هو لتفادي تحويل {} إلى []
    echo '{"ver":' . ($r ? (int)$r['ver'] : 0) . ',"state":' . ($r ? $r['data'] : 'null') . '}';
    exit;
}

if ($act === 'save' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $raw = file_get_contents('php://input');
    if (strlen($raw) > 4000000 || !is_array(json_decode($raw, true))) {
        http_response_code(400);
        echo '{"error":"bad"}';
        exit;
    }
    $pdo->prepare('INSERT INTO app_state (id, data, ver) VALUES (1, ?, 1)
                   ON DUPLICATE KEY UPDATE data = VALUES(data), ver = ver + 1')->execute([$raw]);
    $ver = (int)$pdo->query('SELECT ver FROM app_state WHERE id = 1')->fetchColumn();
    echo json_encode(['ok' => true, 'ver' => $ver]);
    exit;
}

http_response_code(404);
echo '{"error":"not_found"}';
