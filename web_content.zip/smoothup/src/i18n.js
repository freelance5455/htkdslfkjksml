export const T = {
  ar: {
    tagline: 'حسّن فيديوهاتك إلى 1080p و60 إطار/ثانية مباشرة في المتصفح — بدون رفع أي ملف إلى خادم.',
    drop: 'اسحب الفيديو وأفلته هنا أو اختره من جهازك', pick: 'اختيار فيديو',
    specs: 'المواصفات الفعلية للفيديو الأصلي', res: 'الدقة', fps: 'معدل الإطارات', bitrate: 'معدل البت', dur: 'المدة', size: 'الحجم',
    settings: 'إعدادات التحسين', quality: 'الجودة', fast: 'سريع', best: 'أعلى جودة (أبطأ)',
    range: 'الجزء المعالَج', r10: 'أول 10 ثوانٍ', r30: 'أول 30 ثانية', rall: 'الفيديو كامل',
    note: 'يتم تكبير الدقة إلى 1080p بفلتر Lanczos، ورفع الإطارات إلى 60 باستخدام استيفاء حركي (motion-compensated interpolation) عبر FFmpeg.wasm. هذا ليس نموذج ذكاء اصطناعي عصبي، وقد تحتوي المشاهد السريعة على بعض الشوائب. المعالجة في المتصفح بطيئة ومناسبة للمقاطع القصيرة.',
    start: 'ابدأ التحسين', cancel: 'إلغاء', analyzing: 'جارٍ تحليل الفيديو…', loading: 'جارٍ تحميل محرك FFmpeg…', enhancing: 'جارٍ تحسين الفيديو…',
    done: 'اكتمل التحسين ✓', already: 'الفيديو أصلاً 60 إطار/ثانية أو أكثر، لذا تم تغيير الدقة فقط.',
    compare: 'المقارنة', original: 'الأصلي', enhanced: 'المحسَّن', side: 'جنبًا إلى جنب', slider: 'شريط المقارنة', download: 'تحميل MP4',
    tt: 'معاينة ضغط تيك توك (محاكاة)', ttNote: 'محاكاة فقط وليست من تيك توك الفعلي: تقليل الدقة إلى 720p و30 إطارًا وبت منخفض لتقريب أثر الضغط.',
    ttBtn: 'إنشاء معاينة الضغط', ttTag: 'ضغط تيك توك (محاكاة)',
    notVideo: 'الملف المختار ليس فيديو.', unsupported: 'لا يدعم المتصفح قراءة هذا الفيديو.', tooBig: 'الملف كبير (أكثر من 500MB) وقد تنفد الذاكرة.',
    errFail: 'فشلت المعالجة: ', kbps: 'ك.بت/ث', fpsU: 'إطار/ث'
  },
  en: {
    tagline: 'Enhance your videos to 1080p / 60 FPS right in the browser — nothing is uploaded to a server.',
    drop: 'Drag & drop a video here or choose one from your device', pick: 'Choose video',
    specs: 'Original video specifications', res: 'Resolution', fps: 'Frame rate', bitrate: 'Bitrate', dur: 'Duration', size: 'File size',
    settings: 'Enhancement settings', quality: 'Quality', fast: 'Fast', best: 'Best quality (slower)',
    range: 'Part to process', r10: 'First 10 seconds', r30: 'First 30 seconds', rall: 'Whole video',
    note: 'Upscales to 1080p with Lanczos and raises the frame rate to 60 using motion-compensated interpolation in FFmpeg.wasm. This is not a neural AI model, and fast scenes may show artifacts. In-browser processing is slow, best for short clips.',
    start: 'Start enhancing', cancel: 'Cancel', analyzing: 'Analyzing video…', loading: 'Loading FFmpeg engine…', enhancing: 'Enhancing video…',
    done: 'Enhancement complete ✓', already: 'The video is already 60 FPS or more, so only the resolution was changed.',
    compare: 'Comparison', original: 'Original', enhanced: 'Enhanced', side: 'Side by side', slider: 'Slider', download: 'Download MP4',
    tt: 'TikTok compression preview (simulated)', ttNote: 'Simulation only, not real TikTok: reduces to 720p, 30 FPS and a low bitrate to approximate compression.',
    ttBtn: 'Generate compression preview', ttTag: 'TikTok (simulated)',
    notVideo: 'The selected file is not a video.', unsupported: 'Your browser cannot read this video.', tooBig: 'Large file (over 500MB); memory may run out.',
    errFail: 'Processing failed: ', kbps: 'kb/s', fpsU: 'FPS'
  }
};
