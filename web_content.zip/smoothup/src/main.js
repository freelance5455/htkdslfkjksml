import { FFmpeg } from '@ffmpeg/ffmpeg';
import { toBlobURL, fetchFile } from '@ffmpeg/util';
import { T } from './i18n.js';
import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';

const $ = s => document.querySelector(s);
let lang = localStorage.lang || 'ar';
let theme = localStorage.theme || (matchMedia('(prefers-color-scheme:dark)').matches ? 'dark' : 'light');
const t = k => T[lang][k] ?? k;
const urls = [];
let ff = null, file = null, meta = null, inName = '', enhURL = '';

function applyI18n() {
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  document.documentElement.dataset.theme = theme;
  document.querySelectorAll('[data-i18n]').forEach(e => (e.textContent = t(e.dataset.i18n)));
  $('#lang').textContent = lang === 'ar' ? 'EN' : 'عربي';
  if (meta) renderSpecs();
}
$('#lang').onclick = () => { lang = lang === 'ar' ? 'en' : 'ar'; localStorage.lang = lang; applyI18n(); };
$('#theme').onclick = () => { theme = theme === 'dark' ? 'light' : 'dark'; localStorage.theme = theme; applyI18n(); };

const setStatus = k => { const s = $('#status'); s.dataset.i18n = k || ''; s.textContent = k ? t(k) : ''; };
const showErr = m => { const e = $('#err'); e.textContent = m || ''; e.hidden = !m; };
const setProg = p => { $('#progWrap').hidden = p == null; $('#bar').style.width = Math.round((p || 0) * 100) + '%'; };

async function getFF() {
  if (ff) return ff;
  const f = new FFmpeg();
  const b = import.meta.env.BASE_URL + 'ffmpeg/';
  await f.load({
    coreURL: await toBlobURL(b + 'ffmpeg-core.js', 'text/javascript'),
    wasmURL: await toBlobURL(b + 'ffmpeg-core.wasm', 'application/wasm')
  });
  return (ff = f);
}

function renderSpecs() {
  const items = [
    ['res', `${meta.w}×${meta.h}`],
    ['fps', meta.fps ? `${meta.fps} ${t('fpsU')}` : '…'],
    ['bitrate', `${meta.br} ${t('kbps')}`],
    ['dur', `${meta.dur.toFixed(1)} s`],
    ['size', `${(meta.size / 1048576).toFixed(2)} MB`]
  ];
  $('#specs').innerHTML = items.map(([k, v]) => `<div><small>${t(k)}</small><b>${v}</b></div>`).join('');
}

async function loadFile(f) {
  showErr('');
  if (!f || !f.type.startsWith('video/')) return showErr(t('notVideo'));
  file = f;
  urls.forEach(URL.revokeObjectURL); urls.length = 0;
  $('#result').hidden = true; $('#cmp').innerHTML = ''; $('#ttCmp').innerHTML = '';
  const url = URL.createObjectURL(f); urls.push(url);
  const v = document.createElement('video');
  v.preload = 'metadata'; v.src = url;
  try {
    await new Promise((ok, no) => { v.onloadedmetadata = ok; v.onerror = () => no(new Error(t('unsupported'))); });
  } catch (e) { return showErr(e.message); }
  meta = { w: v.videoWidth, h: v.videoHeight, dur: v.duration, size: f.size, fps: null, br: Math.round((f.size * 8) / v.duration / 1000) };
  $('#orig').src = url; $('#info').hidden = false; renderSpecs();
  if (f.size > 5e8) showErr(t('tooBig'));
  setStatus('analyzing'); $('#start').disabled = true;
  try {
    const x = await getFF();
    inName = 'input.' + (f.name.split('.').pop().replace(/[^a-z0-9]/gi, '') || 'mp4');
    await x.writeFile(inName, await fetchFile(f));
    let log = ''; const h = ({ message }) => (log += message + '\n');
    x.on('log', h); await x.exec(['-i', inName]).catch(() => {}); x.off('log', h);
    const fp = log.match(/(\d+(?:\.\d+)?) fps/), br = log.match(/bitrate: (\d+) kb\/s/);
    if (fp) meta.fps = +(+fp[1]).toFixed(2);
    if (br) meta.br = +br[1];
    renderSpecs();
  } catch (e) { showErr(t('errFail') + e.message); }
  setStatus(''); $('#start').disabled = false;
}

async function run(args, outName) {
  const x = await getFF();
  const p = ({ progress }) => setProg(Math.min(1, Math.max(0, progress)));
  x.on('progress', p);
  try {
    const code = await x.exec(args);
    if (code !== 0) throw new Error('ffmpeg exit ' + code);
    const data = await x.readFile(outName);
    await x.deleteFile(outName).catch(() => {});
    return URL.createObjectURL(new Blob([data.buffer], { type: 'video/mp4' }));
  } finally { x.off('progress', p); }
}

const limit = () => (+$('#rng').value ? ['-t', $('#rng').value] : []);
const scale = h => `scale='if(gt(iw,ih),-2,${h})':'if(gt(iw,ih),${h},-2)':flags=lanczos`;

$('#start').onclick = async () => {
  showErr(''); $('#start').disabled = true; $('#cancel').hidden = false; setProg(0);
  try {
    setStatus('loading'); await getFF(); setStatus('enhancing');
    const best = $('#q').value === 'best';
    const vf = [scale(1080)];
    const needs = !meta.fps || meta.fps < 59;
    if (needs) vf.push(best
      ? 'minterpolate=fps=60:mi_mode=mci:mc_mode=aobmc:me_mode=bidir:vsbmc=1'
      : 'minterpolate=fps=60:mi_mode=mci:mc_mode=obmc:me_mode=bidir:me=epzs');
    const out = await run([...limit(), '-i', inName, '-vf', vf.join(','), '-c:v', 'libx264', '-preset', best ? 'veryfast' : 'ultrafast',
      '-crf', '20', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '160k', '-movflags', '+faststart', 'out.mp4'], 'out.mp4');
    urls.push(out); enhURL = out;
    $('#dl').href = out; $('#result').hidden = false;
    makeCompare($('#cmp'), urls[0], out, 'original', 'enhanced');
    setStatus(needs ? 'done' : 'already'); setProg(1);
    $('#result').scrollIntoView({ behavior: 'smooth' });
  } catch (e) { if (ff) showErr(t('errFail') + e.message); setStatus(''); setProg(null); }
  $('#start').disabled = false; $('#cancel').hidden = true;
};
$('#cancel').onclick = () => { ff?.terminate(); ff = null; setStatus(''); setProg(null); $('#cancel').hidden = true; if (file) loadFile(file); };

$('#ttBtn').onclick = async () => {
  $('#ttBtn').disabled = true; setProg(0);
  try {
    const out = await run([...limit(), '-i', inName, '-vf', scale(720), '-r', '30', '-c:v', 'libx264', '-preset', 'ultrafast',
      '-b:v', '1500k', '-maxrate', '1500k', '-bufsize', '3000k', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '96k', 'tt.mp4'], 'tt.mp4');
    urls.push(out); makeCompare($('#ttCmp'), out, enhURL, 'ttTag', 'enhanced');
  } catch (e) { showErr(t('errFail') + e.message); }
  setProg(null); $('#ttBtn').disabled = false;
};

function makeCompare(root, a, b, ka, kb) {
  root.innerHTML = `<div class="modes"><button data-m="side" class="on" data-i18n="side"></button><button data-m="slider" data-i18n="slider"></button></div>
  <div class="stage" style="--x:50%">
    <div class="pane"><video playsinline src="${a}"></video><span class="tag" data-i18n="${ka}"></span></div>
    <div class="pane r"><video playsinline muted src="${b}"></video><span class="tag" data-i18n="${kb}"></span></div>
    <div class="line"></div><input class="cut" type="range" min="0" max="100" value="50"></div>
  <div class="bar"><button class="pp">▶</button><input class="seek" type="range" min="0" max="1000" value="0"></div>`;
  const stage = root.querySelector('.stage'), [v1, v2] = root.querySelectorAll('video');
  const pp = root.querySelector('.pp'), seek = root.querySelector('.seek');
  root.querySelectorAll('.modes button').forEach(btn => (btn.onclick = () => {
    root.querySelectorAll('.modes button').forEach(x => x.classList.toggle('on', x === btn));
    stage.classList.toggle('slider', btn.dataset.m === 'slider');
  }));
  root.querySelector('.cut').oninput = e => stage.style.setProperty('--x', e.target.value + '%');
  pp.onclick = () => { if (v1.paused) { v2.currentTime = v1.currentTime; v1.play(); v2.play(); } else { v1.pause(); v2.pause(); } };
  v1.onplay = () => (pp.textContent = '❚❚'); v1.onpause = () => (pp.textContent = '▶'); v1.onended = () => v2.pause();
  v1.ontimeupdate = () => {
    if (v1.duration) seek.value = (v1.currentTime / v1.duration) * 1000;
    if (Math.abs(v2.currentTime - v1.currentTime) > 0.15) v2.currentTime = v1.currentTime;
  };
  seek.oninput = () => { const tt = (seek.value / 1000) * (v1.duration || 0); v1.currentTime = tt; v2.currentTime = tt; };
  applyI18n();
}

$('#dl').onclick = async e => {
  if (!Capacitor.isNativePlatform()) return;
  e.preventDefault();
  try {
    const blob = await (await fetch(enhURL)).blob();
    const data = await new Promise(r => { const fr = new FileReader(); fr.onload = () => r(fr.result.split(',')[1]); fr.readAsDataURL(blob); });
    const { uri } = await Filesystem.writeFile({ path: 'smoothup_1080p60.mp4', data, directory: Directory.Cache });
    await Share.share({ title: 'SmoothUp', url: uri });
  } catch (err) { if (!/cancel/i.test(err.message)) showErr(t('errFail') + err.message); }
};

const drop = $('#drop');
$('#pick').onclick = () => $('#file').click();
$('#file').onchange = e => loadFile(e.target.files[0]);
['dragover', 'dragenter'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('over'); }));
['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove('over'); }));
drop.addEventListener('drop', e => loadFile(e.dataTransfer.files[0]));
applyI18n();
