# SmoothUp — تحسين الفيديو في المتصفح / In-browser video enhancer

## التشغيل محليًا / Run locally
```
npm install
npm run dev        # http://localhost:5173 (Chrome)
```
## البناء / Build
```
npm run build      # الناتج في dist/
npm run preview
```
## النشر / Deploy (أي استضافة ملفات ثابتة / any static host)
- **Netlify**: اربط المستودع (الإعدادات في `netlify.toml`) أو اسحب مجلد `dist` إلى netlify.com/drop.
- **Vercel**: `npx vercel` (الإعدادات في `vercel.json`).
- **Cloudflare Pages / GitHub Pages**: Build command `npm run build`، Output `dist`.
يجب أن تكون الاستضافة عبر **HTTPS** (مثل كل المواقع العامة). محرك FFmpeg (`public/ffmpeg`) يُنسخ تلقائيًا ويُخدَّم من موقعك نفسه.

## ملاحظات مهمة / Notes
- المعالجة محلية 100%: لا يُرفع أي فيديو.
- رفع الإطارات بـ `minterpolate` (استيفاء حركي)، وليس نموذجًا عصبيًا. لاستخدام نموذج حقيقي مثل RIFE يمكن إضافة ONNX Runtime Web + WebGPU لاحقًا.
- المعالجة داخل المتصفح بطيئة جدًا لفيديوهات 1080p الطويلة؛ استخدم خيار «أول 10 ثوانٍ» للتجربة.
- معاينة تيك توك محاكاة فقط.

## تطبيق أندرويد APK / Android APK
المشروع مغلّف بـ Capacitor (مجلد `android/` جاهز).
**الطريقة 1 (الأسهل، بدون تثبيت شيء): GitHub Actions**
1. ارفع المشروع إلى مستودع GitHub جديد.
2. من تبويب Actions شغّل **Build APK** (يعمل تلقائيًا عند كل push).
3. حمّل `SmoothUp-debug.apk` من Artifacts وثبّته على الجوال (فعّل «التثبيت من مصادر غير معروفة»).

**الطريقة 2: Android Studio (JDK 17)**
```
npm install
npm run build
npx cap sync android
npx cap open android     # ثم Build > Build APK(s)
```
التحميل: زر «تحميل MP4» يفتح قائمة المشاركة لحفظ الفيديو في الجوال.
