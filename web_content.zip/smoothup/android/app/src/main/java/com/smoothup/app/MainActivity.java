package com.smoothup.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
