const $ = id => document.getElementById(id);
const upgrades = [
  {id:'cursor',name:'Sam Cursor',desc:'+1 coin per click',icon:'👆',base:15,kind:'click',amount:1},
  {id:'fan',name:'Sam Fan',desc:'+1 coin per second',icon:'💜',base:50,kind:'auto',amount:1},
  {id:'keyboard',name:'Sam Keyboard',desc:'+5 coins per click',icon:'⌨️',base:250,kind:'click',amount:5},
  {id:'bot',name:'Sam Bot',desc:'+8 coins per second',icon:'🤖',base:500,kind:'auto',amount:8},
  {id:'studio',name:'Sam Studio',desc:'+25 coins per second',icon:'🎮',base:2500,kind:'auto',amount:25},
  {id:'factory',name:'Sam Factory',desc:'+100 coins per second',icon:'🏭',base:12000,kind:'auto',amount:100},
  {id:'empire',name:'Sam Empire',desc:'+500 coins per second',icon:'👑',base:75000,kind:'auto',amount:500},
  {id:'portal',name:'Sam Portal',desc:'+2,500 coins per second',icon:'🌀',base:400000,kind:'auto',amount:2500}
];
const milestones=[{n:100,txt:'First 100',icon:'🥉'},{n:1000,txt:'Getting started',icon:'🥈'},{n:10000,txt:'Coin collector',icon:'🥇'},{n:100000,txt:'Sam millionaire',icon:'💎'},{n:1000000,txt:'Sam legend',icon:'👑'}];
let state={coins:0,total:0,power:0,owned:{},sound:true};
try{const saved=JSON.parse(localStorage.getItem('samsClickerSave'));if(saved)state={...state,...saved,owned:saved.owned||{}}}catch(e){}
const fmt=n=>Math.floor(n).toLocaleString('en-US');
function clickPower(){return (1+upgrades.filter(u=>u.kind==='click').reduce((s,u)=>s+(state.owned[u.id]||0)*u.amount,0))*(1+state.power*.1)}
function cps(){return upgrades.filter(u=>u.kind==='auto').reduce((s,u)=>s+(state.owned[u.id]||0)*u.amount,0)*(1+state.power*.1)}
function cost(u){return Math.floor(u.base*Math.pow(1.17,state.owned[u.id]||0))}
function save(){localStorage.setItem('samsClickerSave',JSON.stringify(state));$('saveState').textContent='● Saved'}
function toast(msg){const t=$('toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),1600)}
function sound(){if(!state.sound)return;try{const c=new (window.AudioContext||window.webkitAudioContext)(),o=c.createOscillator(),g=c.createGain();o.connect(g);g.connect(c.destination);o.frequency.value=520;g.gain.setValueAtTime(.045,c.currentTime);g.gain.exponentialRampToValueAtTime(.001,c.currentTime+.08);o.start();o.stop(c.currentTime+.08)}catch(e){}}
function render(){
 $('coins').textContent=fmt(state.coins);$('perClick').textContent=fmt(clickPower());$('perSecond').textContent=fmt(cps());$('totalEarned').textContent=fmt(state.total);$('power').textContent=state.power*10+'%';
 const progress=Math.min(100,state.coins/100000*100);$('progressFill').style.width=progress+'%';$('rebirthBtn').disabled=state.coins<100000;$('rebirthBtn').textContent=state.coins>=100000?'Rebirth for +1 Sam Power':'Rebirth at 100K coins';
 $('upgrades').innerHTML=upgrades.map(u=>{let c=cost(u),owned=state.owned[u.id]||0;return `<div class="upgrade"><div class="upgrade-icon">${u.icon}</div><div class="upgrade-info"><strong>${u.name}</strong><small>${u.desc}</small><small class="owned">Owned: ${owned}</small></div><button class="buy-btn" data-buy="${u.id}" ${state.coins<c?'disabled':''}>${fmt(c)} 🟡</button></div>`}).join('');
 $('achievementList').innerHTML=milestones.map(m=>`<div class="achievement ${state.total>=m.n?'unlocked':''}"><span class="medal">${m.icon}</span><span>${m.txt} <small>— ${fmt(m.n)} total coins</small></span></div>`).join('');
}
$('upgrades').addEventListener('click',e=>{const id=e.target.dataset.buy;if(!id)return;const u=upgrades.find(x=>x.id===id),c=cost(u);if(state.coins<c)return;state.coins-=c;state.owned[id]=(state.owned[id]||0)+1;sound();render();save()});
$('clickButton').addEventListener('click',e=>{let gain=clickPower();state.coins+=gain;state.total+=gain;sound();const f=document.createElement('div');f.className='float';f.textContent='+'+fmt(gain);f.style.left=e.clientX+'px';f.style.top=e.clientY+'px';document.body.appendChild(f);setTimeout(()=>f.remove(),850);render()});
$('rebirthBtn').addEventListener('click',()=>{if(state.coins<100000)return;state.power++;state.coins=0;state.owned={};toast('Sam Power increased! Permanent boost unlocked.');render();save()});
$('soundBtn').addEventListener('click',()=>{state.sound=!state.sound;$('soundBtn').textContent=state.sound?'♫':'♪';save();toast(state.sound?'Sound on':'Sound off')});
$('resetBtn').addEventListener('click',()=>{if(confirm('Reset all Sam Clicker progress? This cannot be undone.')){state={coins:0,total:0,power:0,owned:{},sound:state.sound};save();render();toast('Game reset')}}); 
setInterval(()=>{let gain=cps()/10;if(gain>0){state.coins+=gain;state.total+=gain;render()}},100);
setInterval(save,5000);render();