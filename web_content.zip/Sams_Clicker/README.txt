SAM'S CLICKER

HOW TO PLAY
1. Extract the ZIP file.
2. Open index.html in a modern browser (Chrome recommended).
3. Tap CLICK SAM to earn Sam Coins.
4. Buy upgrades to earn more per click or automatically every second.
5. Reach 100,000 coins to Rebirth. Each Rebirth gives a permanent 10% income boost.
6. Your progress saves automatically in your browser on this device.

FILES
- index.html: game page
- style.css: responsive purple theme and layout
- game.js: clicker logic, upgrades, saving and achievements

No installation or server is required. Internet is only used for the optional Google Fonts styling; the game itself works offline with fallback fonts.
