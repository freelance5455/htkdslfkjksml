document.addEventListener('DOMContentLoaded', () => {

    // AUDIO SYNTHESIZER FOR MECHANICAL KEYBOARD CLICK SOUND
    let audioCtx = null;

    function playMechanicalSound() {
        try {
            if (!audioCtx) {
                audioCtx = new (window.AudioContext || window.webkitAudioContext)();
            }
            if (audioCtx.state === 'suspended') {
                audioCtx.resume();
            }

            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();

            osc.type = 'sine';
            osc.frequency.setValueAtTime(600, audioCtx.currentTime);
            osc.frequency.exponentialRampToValueAtTime(120, audioCtx.currentTime + 0.04);

            gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.04);

            osc.connect(gain);
            gain.connect(audioCtx.destination);

            osc.start();
            osc.stop(audioCtx.currentTime + 0.04);
        } catch(e) {}
    }

    // ATTACH MECHANICAL SOUND
    document.addEventListener('click', (e) => {
        const target = e.target.closest('button, .glass-btn, .mini-glass-btn, .feature-btn, .segment-btn, .tab-btn, .game-card, li, .theme-select-btn, .sound-click, .top-profile-badge, select');
        if (target) {
            playMechanicalSound();
        }
    });

    // LOGIN LOGIC
    const loginBtn = document.getElementById('login-btn');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const loginError = document.getElementById('login-error');
    const loginScreen = document.getElementById('login-screen');
    const appScreen = document.getElementById('app-screen');

    if (loginBtn) {
        loginBtn.addEventListener('click', () => {
            const u = usernameInput.value.trim();
            const p = passwordInput.value.trim();

            if (u === 'Trinity123' && p === 'Trinity123') {
                loginScreen.classList.remove('active');
                appScreen.classList.add('active');
                showToast('Login Berhasil! Selamat datang di Trinity V1');
            } else {
                loginError.textContent = 'Username atau Password salah!';
            }
        });
    }

    // SIDEBAR TOGGLE
    const menuToggle = document.getElementById('menu-toggle');
    const sidebar = document.getElementById('sidebar');
    const sidebarOverlay = document.getElementById('sidebar-overlay');
    const closeSidebar = document.getElementById('close-sidebar');

    function toggleSidebar() {
        if (sidebar && sidebarOverlay) {
            sidebar.classList.toggle('open');
            sidebarOverlay.classList.toggle('active');
        }
    }

    if (menuToggle) menuToggle.addEventListener('click', toggleSidebar);
    if (closeSidebar) closeSidebar.addEventListener('click', toggleSidebar);
    if (sidebarOverlay) sidebarOverlay.addEventListener('click', toggleSidebar);

    // ROLE DROPDOWN SELECTION
    const roleSelect = document.getElementById('role-select');
    if (roleSelect) {
        roleSelect.addEventListener('change', () => {
            const val = roleSelect.value;
            roleSelect.className = `role-dropdown sound-click role-${val}`;
            const selectedText = roleSelect.options[roleSelect.selectedIndex].text;
            showToast(`Role diubah menjadi: [${selectedText}]`);
        });
    }

    // LOGOUT LOGIC
    function performLogout() {
        if (appScreen && loginScreen) {
            appScreen.classList.remove('active');
            loginScreen.classList.add('active');
            if (usernameInput) usernameInput.value = 'Trinity123';
            if (passwordInput) passwordInput.value = '';
            showToast('Berhasil Logout');
        }
    }

    const logoutBtn = document.getElementById('logout-btn');
    const logoutActionBtn = document.getElementById('btn-logout-action');
    if (logoutBtn) logoutBtn.addEventListener('click', () => { toggleSidebar(); performLogout(); });
    if (logoutActionBtn) logoutActionBtn.addEventListener('click', performLogout);

    // PROFILE PHOTO & BANNER CHANGE SYSTEM
    const avatarInput = document.getElementById('avatar-input');
    const bannerImg = document.getElementById('banner-img');
    const topProfileImg = document.getElementById('top-profile-img');
    const sidebarProfileImg = document.getElementById('sidebar-profile-img');

    function triggerPhotoUpload() {
        if (avatarInput) avatarInput.click();
    }

    const topProfileBtn = document.getElementById('top-profile-btn');
    const gantiFotoMenuBtn = document.getElementById('ganti-foto-menu-btn');
    const gantiFotoActionBtn = document.getElementById('btn-ganti-foto-action');

    if (topProfileBtn) topProfileBtn.addEventListener('click', triggerPhotoUpload);
    if (gantiFotoMenuBtn) gantiFotoMenuBtn.addEventListener('click', () => { toggleSidebar(); triggerPhotoUpload(); });
    if (gantiFotoActionBtn) gantiFotoActionBtn.addEventListener('click', triggerPhotoUpload);

    if (avatarInput) {
        avatarInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (event) => {
                    const imgData = event.target.result;
                    if (bannerImg) bannerImg.src = imgData;
                    if (topProfileImg) topProfileImg.src = imgData;
                    if (sidebarProfileImg) sidebarProfileImg.src = imgData;
                    showToast('Foto Profil & Banner Berhasil Diganti!');
                };
                reader.readAsDataURL(file);
            }
        });
    }

    // DEVELOPER MODAL
    const devModal = document.getElementById('developer-modal');
    function openDevModal() {
        if (devModal) devModal.classList.add('active');
    }

    const devMenuBtn = document.getElementById('dev-menu-btn');
    const devActionBtn = document.getElementById('btn-developer-action');

    if (devMenuBtn) devMenuBtn.addEventListener('click', () => { toggleSidebar(); openDevModal(); });
    if (devActionBtn) devActionBtn.addEventListener('click', openDevModal);

    // THEME SWITCHER SYSTEM
    window.setAppTheme = function(theme) {
        document.body.className = '';
        if (theme === 'glass-white') {
            document.body.classList.add('theme-glass-white');
            showToast('Tema diubah ke: Liquid Glass White');
        } else if (theme === 'retro') {
            document.body.classList.add('theme-retro');
            showToast('Tema diubah ke: Retro Cyber Grid');
        } else {
            document.body.classList.add('theme-glass-black');
            showToast('Tema diubah ke: Liquid Glass Black');
        }
        const themeModal = document.getElementById('theme-modal');
        if (themeModal) themeModal.classList.remove('active');
    };

    // SLIDE TABS
    const tabBtns = document.querySelectorAll('.tab-btn');
    const slides = document.querySelectorAll('.slide');

    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const index = btn.getAttribute('data-slide');
            tabBtns.forEach(b => b.classList.remove('active'));
            slides.forEach(s => s.classList.remove('active'));
            btn.classList.add('active');
            if (slides[index]) slides[index].classList.add('active');
        });
    });

    // PILIH TUJUAN (NOMOR / GRUP)
    const segmentBtns = document.querySelectorAll('.segment-btn');
    segmentBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            segmentBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            showToast(`Tujuan dipilih: ${btn.textContent}`);
        });
    });

    // FEATURE BUG TOGGLES
    const featureBtns = document.querySelectorAll('.feature-btn');
    featureBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            btn.classList.toggle('active');
            const featName = btn.getAttribute('data-feature');
            if (btn.classList.contains('active')) {
                showToast(`Fitur [${featName}] Aktif!`);
            } else {
                showToast(`Fitur [${featName}] Non-Aktif`);
            }
        });
    });

    // BUTTON MULAI
    const btnMulai = document.getElementById('btn-mulai');
    if (btnMulai) {
        btnMulai.addEventListener('click', () => {
            const targetNum = document.getElementById('target-number').value.trim();
            const activeSegment = document.querySelector('.segment-btn.active').textContent;

            if (!targetNum) {
                showToast('Harap isi Target Number!');
                return;
            }

            showToast(`Memproses ${activeSegment}: ${targetNum}...`);
        });
    }

    // GLOBAL CHAT SYSTEM
    const chatMessages = document.getElementById('chat-messages');
    const chatInput = document.getElementById('chat-input');
    const sendChatBtn = document.getElementById('send-chat-btn');

    function sendChatMessage() {
        if (!chatInput) return;
        const text = chatInput.value.trim();
        if (!text) return;

        const msgDiv = document.createElement('div');
        msgDiv.className = 'chat-msg self';
        msgDiv.innerHTML = `<span class="sender">TrinityUser (Anda)</span><p>${escapeHtml(text)}</p>`;
        if (chatMessages) {
            chatMessages.appendChild(msgDiv);
            chatInput.value = '';
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }
        showToast('Pesan terkirim ke Global Chat');

        setTimeout(() => {
            if (chatMessages) {
                const replyDiv = document.createElement('div');
                replyDiv.className = 'chat-msg';
                replyDiv.innerHTML = `<span class="sender">TrinityUser_99</span><p>Mantap bro, Trinity V1 gacor!</p>`;
                chatMessages.appendChild(replyDiv);
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }
        }, 1500);
    }

    if (sendChatBtn) sendChatBtn.addEventListener('click', sendChatMessage);
    if (chatInput) {
        chatInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') sendChatMessage();
        });
    }

    function escapeHtml(str) {
        return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    }

    // MODALS CLOSE SYSTEM
    const modals = document.querySelectorAll('.modal');
    document.querySelectorAll('.close-modal').forEach(btn => {
        btn.addEventListener('click', () => {
            modals.forEach(m => m.classList.remove('active'));
        });
    });

    document.querySelectorAll('.sidebar-menu li[data-modal]').forEach(item => {
        item.addEventListener('click', () => {
            toggleSidebar();
            const mId = item.getAttribute('data-modal');
            const targetModal = document.getElementById(mId);
            if (targetModal) targetModal.classList.add('active');
        });
    });

    // AUDIO PLAYER LOGIC
    let isPlaying = false;
    let songOscillator = null;
    let songGainNode = null;

    const playSongBtn = document.getElementById('play-song');
    const playIcon = document.getElementById('play-icon');
    const songTitle = document.getElementById('song-title');
    const playlistItems = document.querySelectorAll('.playlist-item');

    playlistItems.forEach(item => {
        item.addEventListener('click', () => {
            playlistItems.forEach(i => i.classList.remove('active'));
            item.classList.add('active');
            if (songTitle) songTitle.textContent = item.getAttribute('data-name');
            if (isPlaying) { stopAudioSound(); startAudioSound(item.getAttribute('data-type')); }
            showToast(`Lagu diputar: ${item.getAttribute('data-name')}`);
        });
    });

    if (playSongBtn) {
        playSongBtn.addEventListener('click', () => {
            const currentActive = document.querySelector('.playlist-item.active');
            const songType = currentActive ? currentActive.getAttribute('data-type') : 'synth';

            if (!isPlaying) {
                startAudioSound(songType);
                if (playIcon) playIcon.className = 'fa-solid fa-pause';
                isPlaying = true;
                showToast('Memutar Audio Musikal...');
            } else {
                stopAudioSound();
                if (playIcon) playIcon.className = 'fa-solid fa-play';
                isPlaying = false;
                showToast('Audio Dijeda');
            }
        });
    }

    function startAudioSound(type) {
        if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        if (songOscillator) stopAudioSound();

        songOscillator = audioCtx.createOscillator();
        songGainNode = audioCtx.createGain();

        let freq = 440;
        if (type === 'cyber') { songOscillator.type = 'sawtooth'; freq = 320; }
        else if (type === 'chill') { songOscillator.type = 'sine'; freq = 520; }
        else { songOscillator.type = 'triangle'; freq = 440; }

        songOscillator.frequency.setValueAtTime(freq, audioCtx.currentTime);
        songGainNode.gain.setValueAtTime(0.08, audioCtx.currentTime);

        songOscillator.connect(songGainNode);
        songGainNode.connect(audioCtx.destination);
        songOscillator.start();
    }

    function stopAudioSound() {
        if (songOscillator) {
            songOscillator.stop();
            songOscillator.disconnect();
            songOscillator = null;
        }
    }

    // SHOP CLAIM
    window.buyItem = function(name) {
        if (name.includes('5000K')) {
            showToast(`Menuju gerbang pembayaran IDR 5.000.000 untuk [${name}]...`);
        } else {
            showToast(`Item [${name}] Berhasil Diproses!`);
        }
    };

    // TOAST HELPER
    window.showToast = function(msg) {
        const toast = document.getElementById('toast');
        if (toast) {
            toast.textContent = msg;
            toast.classList.add('show');
            setTimeout(() => toast.classList.remove('show'), 2800);
        }
    };
});

// SYSTEM 10 MINIGAMES
const gameModal = document.getElementById('game-modal');
const gameTitleHeader = document.getElementById('game-title-header');
const gameBody = document.getElementById('game-body');

window.openGame = function(type) {
    if (gameModal) gameModal.classList.add('active');
    if (!gameBody) return;
    gameBody.innerHTML = '';

    if (type === 'clicker') {
        if (gameTitleHeader) gameTitleHeader.textContent = '1. Tap Booster';
        let score = 0, time = 10, timer = null;
        gameBody.innerHTML = `
            <p style="font-size:0.8rem;">Klik tombol sebanyak mungkin dalam 10 detik!</p>
            <h1 id="score-display" style="color:#38bdf8; font-size:2.5rem;">0</h1>
            <p id="time-display" style="font-size:0.8rem;">Sisa Waktu: 10s</p>
            <button id="tap-act-btn" class="glass-btn primary-btn sound-click" style="padding:15px 30px;">TAP DISINI!</button>
        `;
        const btn = document.getElementById('tap-act-btn');
        if (btn) {
            btn.onclick = () => {
                if (!timer) {
                    timer = setInterval(() => {
                        time--;
                        const td = document.getElementById('time-display');
                        if (td) td.textContent = `Sisa Waktu: ${time}s`;
                        if (time <= 0) {
                            clearInterval(timer);
                            btn.disabled = true;
                            showToast(`Game Selesai! Skor: ${score}`);
                        }
                    }, 1000);
                }
                if (time > 0) { 
                    score++; 
                    const sd = document.getElementById('score-display');
                    if (sd) sd.textContent = score; 
                }
            };
        }

    } else if (type === 'reaction') {
        if (gameTitleHeader) gameTitleHeader.textContent = '2. Refleks Cepat';
        gameBody.innerHTML = `
            <div id="react-box" class="glass-card sound-click" style="padding:30px; background:rgba(239,68,68,0.3); cursor:pointer;">
                <h3 id="react-txt">Tunggu warna hijau...</h3>
            </div>
        `;
        const box = document.getElementById('react-box');
        const txt = document.getElementById('react-txt');
        let start = 0, ready = false;
        const tout = setTimeout(() => {
            ready = true;
            if (box) box.style.background = 'rgba(16,185,129,0.4)';
            if (txt) txt.textContent = 'KLIK SEKARANG!';
            start = Date.now();
        }, Math.random() * 2000 + 1500);

        if (box) {
            box.onclick = () => {
                if (!ready) {
                    clearTimeout(tout);
                    if (txt) txt.textContent = 'Terlalu cepat! Coba lagi.';
                } else {
                    const diff = Date.now() - start;
                    if (txt) txt.textContent = `Waktu Reaksi: ${diff} ms!`;
                    showToast(`Waktu Reaksi: ${diff} ms`);
                }
            };
        }

    } else if (type === 'guess') {
        if (gameTitleHeader) gameTitleHeader.textContent = '3. Tebak Angka';
        const target = Math.floor(Math.random() * 100) + 1;
        let count = 0;
        gameBody.innerHTML = `
            <p style="font-size:0.8rem;">Tebak angka rahasia (1 - 100)</p>
            <input type="number" id="num-guess" class="segment-btn" placeholder="Input angka..." style="width:80%; text-align:center;">
            <button id="btn-guess" class="glass-btn primary-btn sound-click" style="padding:8px 20px;">Tebak</button>
            <p id="guess-res" style="color:#38bdf8; font-size:0.8rem;"></p>
        `;
        const bg = document.getElementById('btn-guess');
        if (bg) {
            bg.onclick = () => {
                const ng = document.getElementById('num-guess');
                if (!ng) return;
                const val = parseInt(ng.value);
                if (!val) return;
                count++;
                const res = document.getElementById('guess-res');
                if (!res) return;
                if (val === target) { res.textContent = `🎉 Benar! (${count}x coba)`; showToast('Tebakan Benar!'); }
                else if (val < target) { res.textContent = 'Terlalu KECIL!'; }
                else { res.textContent = 'Terlalu BESAR!'; }
            };
        }

    } else if (type === 'tictactoe') {
        if (gameTitleHeader) gameTitleHeader.textContent = '4. Tic Tac Toe';
        let b = ['', '', '', '', '', '', '', '', ''], p = 'X';
        let grid = '<div style="display:grid; grid-template-columns:repeat(3,55px); gap:6px;">';
        for(let i=0; i<9; i++) grid += `<button class="glass-btn tcell sound-click" data-i="${i}" style="height:55px; font-size:1.2rem;"></button>`;
        grid += '</div><p id="ttt-st" style="font-size:0.8rem;">Giliran: X</p>';
        gameBody.innerHTML = grid;

        document.querySelectorAll('.tcell').forEach(c => {
            c.onclick = () => {
                const i = c.getAttribute('data-i');
                if (b[i] !== '') return;
                b[i] = p; c.textContent = p;
                p = p === 'X' ? 'O' : 'X';
                const st = document.getElementById('ttt-st');
                if (st) st.textContent = `Giliran: ${p}`;
            };
        });

    } else if (type === 'memory') {
        if (gameTitleHeader) gameTitleHeader.textContent = '5. Memory Match';
        gameBody.innerHTML = `
            <p style="font-size:0.8rem;">Uji daya ingat emoji!</p>
            <h2 style="color:#38bdf8;">🔥 💎 ⚡ 👑</h2>
            <button class="glass-btn primary-btn sound-click" onclick="openGame('memory')">Acak Ulang</button>
        `;

    } else if (type === 'math') {
        if (gameTitleHeader) gameTitleHeader.textContent = '6. Math Speed';
        const n1 = Math.floor(Math.random()*25)+1, n2 = Math.floor(Math.random()*25)+1;
        gameBody.innerHTML = `
            <p style="font-size:0.8rem;">Hitung Cepat:</p>
            <h2>${n1} + ${n2} = ?</h2>
            <input type="number" id="math-ans" class="segment-btn" style="width:70%; text-align:center;">
            <button id="math-btn" class="glass-btn primary-btn sound-click" style="padding:8px 20px;">Jawab</button>
        `;
        const mb = document.getElementById('math-btn');
        if (mb) {
            mb.onclick = () => {
                const ma = document.getElementById('math-ans');
                if (!ma) return;
                const ans = parseInt(ma.value);
                if (ans === (n1+n2)) { showToast('Jawaban Benar!'); openGame('math'); }
                else { showToast('Salah! Coba lagi'); }
            };
        }

    } else if (type === 'coin') {
        if (gameTitleHeader) gameTitleHeader.textContent = '7. Lempar Koin';
        gameBody.innerHTML = `
            <div id="coin-res" style="font-size:3rem; color:#f59e0b;"><i class="fa-solid fa-coins"></i></div>
            <button id="flip-btn" class="glass-btn primary-btn sound-click" style="padding:10px 25px;">Lempar Koin</button>
        `;
        const fb = document.getElementById('flip-btn');
        if (fb) {
            fb.onclick = () => {
                const res = Math.random() > 0.5 ? 'ANGKA' : 'GAMBAR';
                const cr = document.getElementById('coin-res');
                if (cr) cr.textContent = res;
                showToast(`Hasil Koin: ${res}`);
            };
        }

    } else if (type === 'rps') {
        if (gameTitleHeader) gameTitleHeader.textContent = '8. Suwit Bot';
        gameBody.innerHTML = `
            <p style="font-size:0.8rem;">Pilih Pilihan Anda:</p>
            <div style="display:flex; gap:10px;">
                <button class="glass-btn sound-click" onclick="playRPS('Batu')">✊ Batu</button>
                <button class="glass-btn sound-click" onclick="playRPS('Gunting')">✌️ Gunting</button>
                <button class="glass-btn sound-click" onclick="playRPS('Kertas')">✋ Kertas</button>
            </div>
            <p id="rps-status" style="margin-top:10px; font-size:0.85rem; color:#38bdf8;"></p>
        `;

    } else if (type === 'dice') {
        if (gameTitleHeader) gameTitleHeader.textContent = '9. Dadu Keberuntungan';
        gameBody.innerHTML = `
            <div id="dice-num" style="font-size:3.5rem; color:#38bdf8;">🎲</div>
            <button id="roll-dice-btn" class="glass-btn primary-btn sound-click" style="padding:10px 25px;">Lempar Dadu</button>
        `;
        const rdb = document.getElementById('roll-dice-btn');
        if (rdb) {
            rdb.onclick = () => {
                const num = Math.floor(Math.random() * 6) + 1;
                const dn = document.getElementById('dice-num');
                if (dn) dn.textContent = num;
                showToast(`Dadu Muncul Angka: ${num}`);
            };
        }

    } else if (type === 'simon') {
        if (gameTitleHeader) gameTitleHeader.textContent = '10. Color Pattern';
        gameBody.innerHTML = `
            <p style="font-size:0.8rem;">Ikuti Urutan Warna Berkedip</p>
            <div style="display:grid; grid-template-columns:repeat(2,60px); gap:10px;">
                <div class="glass-btn sound-click" style="background:#ef4444; height:60px;" onclick="showToast('Merah Terpilih')"></div>
                <div class="glass-btn sound-click" style="background:#3b82f6; height:60px;" onclick="showToast('Biru Terpilih')"></div>
                <div class="glass-btn sound-click" style="background:#10b981; height:60px;" onclick="showToast('Hijau Terpilih')"></div>
                <div class="glass-btn sound-click" style="background:#f59e0b; height:60px;" onclick="showToast('Kuning Terpilih')"></div>
            </div>
        `;
    }
};

window.playRPS = function(user) {
    const opts = ['Batu', 'Gunting', 'Kertas'];
    const bot = opts[Math.floor(Math.random() * 3)];
    let res = '';
    if (user === bot) res = 'Seri!';
    else if ((user==='Batu'&&bot==='Gunting') || (user==='Gunting'&&bot==='Kertas') || (user==='Kertas'&&bot==='Batu')) res = 'Anda Menang! 🎉';
    else res = 'Bot Menang!';
    const rpsStatus = document.getElementById('rps-status');
    if (rpsStatus) rpsStatus.textContent = `Anda: ${user} vs Bot: ${bot} -> ${res}`;
};

window.closeGameModal = function() { 
    if (gameModal) gameModal.classList.remove('active'); 
};
