# Add project specific ProGuard rules here.
# minifyEnabled is off by default (see app/build.gradle) so these rules are
# only used if you turn shrinking on for a release build.

-keep class com.typex.app.ime.** { *; }
-keep class com.typex.app.ai.** { *; }
