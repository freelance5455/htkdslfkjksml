package com.typex.app.ai

// ============================================
// TYPEX AI CONFIGURATION
// INSERT YOUR API KEY HERE
// ============================================
object ApiConfig {

    /** Paste your API key between the quotes below. */
    const val API_KEY: String = "PASTE_YOUR_API_KEY_HERE"

    /**
     * Base URL of an OpenAI-compatible "chat completions" endpoint
     * (this exact request shape is supported by OpenAI itself and by many
     * other providers). AiClient posts to "$BASE_URL/chat/completions".
     * Change this if you're pointing TypeX at a different provider.
     */
    const val BASE_URL: String = "https://api.openai.com/v1"

    const val MODEL: String = "gpt-4o-mini"

    /** 0.0 = deterministic, 1.0 = very varied. */
    const val TEMPERATURE: Double = 0.4

    const val MAX_OUTPUT_TOKENS: Int = 300

    /** Connect + read timeout, in milliseconds. */
    const val TIMEOUT_MS: Int = 12000
}
// ============================================
// SECURITY NOTE (read this before shipping to real users):
// An API key embedded inside an APK can be extracted by anyone who has the
// APK file — this is NOT secure for a production app. The direct API-key
// approach above is meant for a prototype / for your own personal testing
// build only. A production version of TypeX should send rewrite/translate
// requests to your own small backend server, which holds the real API key
// and forwards the request — the app itself should never contain a key
// that can talk to a paid API on your behalf.
// ============================================
