package com.typex.app.data

import android.content.Context

/**
 * All TypeX preferences live here, backed by a single private SharedPreferences
 * file. Nothing typed by the user is ever stored — only these small settings.
 */
class PreferencesManager(context: Context) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    /** AI is OFF by default: the user has to opt in before anything can be sent anywhere. */
    fun isAiEnabled(): Boolean = prefs.getBoolean(KEY_AI_ENABLED, false)
    fun setAiEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_AI_ENABLED, enabled).apply()

    fun getDefaultLanguage(): String = prefs.getString(KEY_DEFAULT_LANG, "English") ?: "English"
    fun setDefaultLanguage(lang: String) = prefs.edit().putString(KEY_DEFAULT_LANG, lang).apply()

    fun isCompactKeys(): Boolean = prefs.getBoolean(KEY_COMPACT_KEYS, false)
    fun setCompactKeys(compact: Boolean) = prefs.edit().putBoolean(KEY_COMPACT_KEYS, compact).apply()

    companion object {
        private const val PREFS_NAME = "typex_prefs"
        private const val KEY_AI_ENABLED = "ai_enabled"
        private const val KEY_DEFAULT_LANG = "default_language"
        private const val KEY_COMPACT_KEYS = "compact_keys"
    }
}
