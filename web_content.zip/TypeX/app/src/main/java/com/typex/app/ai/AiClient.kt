package com.typex.app.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL

sealed class AiResult {
    data class Success(val text: String) : AiResult()
    data class Error(val message: String) : AiResult()
}

/**
 * Talks to an OpenAI-compatible chat-completions endpoint. Every call runs
 * on Dispatchers.IO and only ever happens because the user explicitly
 * tapped a tone or Translate — see TypeXKeyboardService, which is the only
 * caller and which gates every call behind the AI on/off switch.
 */
class AiClient {

    suspend fun rewrite(text: String, tone: ToneOption, defaultLanguage: String): AiResult {
        val system = "You rewrite short pieces of user text for a mobile keyboard app. " +
            "${tone.instruction} Preserve the original language and style (English, Hinglish, " +
            "or Tanglish) the user wrote in unless it is genuinely ambiguous, in which case lean " +
            "towards $defaultLanguage. Return ONLY the rewritten text: no quotes, no labels like " +
            "\"Here is your rewrite:\", no markdown, no explanation."
        return callChatApi(system, text)
    }

    suspend fun translate(text: String, targetLanguage: String): AiResult {
        val system = "You translate short pieces of user text for a mobile keyboard app. " +
            "Translate the user's text into natural, conversational $targetLanguage, preserving " +
            "meaning, intent and tone. Return ONLY the translated text: no quotes, no labels, " +
            "no explanation."
        return callChatApi(system, text)
    }

    private suspend fun callChatApi(systemPrompt: String, userText: String): AiResult =
        withContext(Dispatchers.IO) {
            if (ApiConfig.API_KEY.isBlank() || ApiConfig.API_KEY == "PASTE_YOUR_API_KEY_HERE") {
                return@withContext AiResult.Error("AI not configured")
            }
            if (userText.isBlank()) {
                return@withContext AiResult.Error("Nothing to rewrite")
            }
            // Keep the request small and fast: only the relevant tail of long text.
            val trimmedText = if (userText.length > 2000) userText.takeLast(2000) else userText

            var connection: HttpURLConnection? = null
            try {
                val url = URL("${ApiConfig.BASE_URL}/chat/completions")
                connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    doOutput = true
                    connectTimeout = ApiConfig.TIMEOUT_MS
                    readTimeout = ApiConfig.TIMEOUT_MS
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Authorization", "Bearer ${ApiConfig.API_KEY}")
                }

                val messages = JSONArray()
                    .put(JSONObject().put("role", "system").put("content", systemPrompt))
                    .put(JSONObject().put("role", "user").put("content", trimmedText))

                val body = JSONObject()
                    .put("model", ApiConfig.MODEL)
                    .put("messages", messages)
                    .put("temperature", ApiConfig.TEMPERATURE)
                    .put("max_tokens", ApiConfig.MAX_OUTPUT_TOKENS)

                connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

                val code = connection.responseCode
                if (code !in 200..299) {
                    return@withContext AiResult.Error(mapErrorCode(code))
                }

                val responseText = connection.inputStream.bufferedReader().use { it.readText() }
                val content = JSONObject(responseText)
                    .optJSONArray("choices")
                    ?.optJSONObject(0)
                    ?.optJSONObject("message")
                    ?.optString("content")
                    ?.trim()

                if (content.isNullOrBlank()) {
                    AiResult.Error("Couldn't rewrite")
                } else {
                    AiResult.Success(stripWrappingQuotes(content))
                }
            } catch (e: SocketTimeoutException) {
                AiResult.Error("Request timed out")
            } catch (e: IOException) {
                AiResult.Error("No internet connection")
            } catch (e: Exception) {
                AiResult.Error("Couldn't rewrite")
            } finally {
                connection?.disconnect()
            }
        }

    private fun mapErrorCode(code: Int): String = when (code) {
        401, 403 -> "Invalid API key"
        429 -> "Rate limit reached"
        in 500..599 -> "AI server error"
        else -> "Couldn't rewrite"
    }

    private fun stripWrappingQuotes(s: String): String {
        val t = s.trim()
        return if (t.length >= 2 && ((t.first() == '"' && t.last() == '"') || (t.first() == '\u201C' && t.last() == '\u201D'))) {
            t.substring(1, t.length - 1).trim()
        } else {
            t
        }
    }
}
