package com.typex.app.ime

import android.content.Context
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import com.typex.app.R
import com.typex.app.ai.ToneOption
import com.typex.app.ai.ToneOptions
import com.typex.app.data.PreferencesManager

/**
 * The whole TypeX keyboard surface, built entirely in code (no XML layout,
 * no deprecated android.inputmethodservice.KeyboardView). Two parts, top to
 * bottom:
 *  1. The AI toolbar: an on/off switch plus, when on, a horizontally
 *     scrolling row of tone chips and a Translate chip.
 *  2. A real QWERTY key layout with shift/caps, backspace, a symbols/letters
 *     toggle, space and enter.
 */
class TypeXKeyboardView(context: Context) : LinearLayout(context) {

    interface Listener {
        fun onChar(c: String)
        fun onBackspace()
        fun onEnter()
        fun onSpace()
        fun onShift()
        fun onSymbolsToggle()
        fun onAiToggle(enabled: Boolean)
        fun onTone(tone: ToneOption)
        fun onTranslate(targetLang: String)
    }

    private var listener: Listener? = null
    private val prefs = PreferencesManager(context)

    private lateinit var aiSwitch: SwitchCompat
    private lateinit var toneRow: HorizontalScrollView
    private lateinit var loadingBar: ProgressBar
    private lateinit var keysContainer: LinearLayout

    private var isShiftOn = false
    private var isCapsLockOn = false
    private var isSymbolsOn = false

    private val letterRows = listOf(
        listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p"),
        listOf("a", "s", "d", "f", "g", "h", "j", "k", "l"),
        listOf("z", "x", "c", "v", "b", "n", "m")
    )
    private val symbolRows = listOf(
        listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
        listOf("@", "#", "$", "_", "&", "-", "+", "(", ")"),
        listOf("*", "\"", "'", ":", ";", "!", "?")
    )

    init {
        orientation = VERTICAL
        setBackgroundColor(ContextCompat.getColor(context, R.color.typex_bg_black))
        setPadding(dp(6), dp(6), dp(6), dp(6))
        addView(buildToolbar())
        keysContainer = LinearLayout(context).apply {
            orientation = VERTICAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
        }
        addView(keysContainer)
        renderKeyRows()
    }

    /** Guarded so it's safe to set both before and after the toolbar views exist. */
    var aiEnabled: Boolean = prefs.isAiEnabled()
        set(value) {
            field = value
            if (::aiSwitch.isInitialized) aiSwitch.isChecked = value
            if (::toneRow.isInitialized) toneRow.visibility = if (value) View.VISIBLE else View.GONE
        }

    fun setListener(l: Listener) {
        listener = l
    }

    fun setLoading(loading: Boolean) {
        loadingBar.visibility = if (loading) View.VISIBLE else View.INVISIBLE
    }

    fun setShiftState(shift: Boolean, capsLock: Boolean) {
        isShiftOn = shift
        isCapsLockOn = capsLock
        renderKeyRows()
    }

    fun setSymbolsMode(on: Boolean) {
        isSymbolsOn = on
        renderKeyRows()
    }

    // ---------------- Toolbar: AI on/off + tone chips ----------------

    private fun buildToolbar(): LinearLayout {
        val toolbar = LinearLayout(context).apply {
            orientation = VERTICAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
        }

        val topRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
            setPadding(dp(4), dp(2), dp(4), dp(4))
        }

        val aiLabel = TextView(context).apply {
            text = context.getString(R.string.ai_label)
            setTextColor(ContextCompat.getColor(context, R.color.typex_text_primary))
            textSize = 13f
            layoutParams = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
        }

        loadingBar = ProgressBar(context).apply {
            layoutParams = LayoutParams(dp(18), dp(18)).apply { marginEnd = dp(10) }
            visibility = View.INVISIBLE
            indeterminateTintList = ContextCompat.getColorStateList(context, R.color.typex_green_accent)
        }

        aiSwitch = SwitchCompat(context).apply {
            isChecked = prefs.isAiEnabled()
            thumbTintList = ContextCompat.getColorStateList(context, R.color.typex_green_accent)
            trackTintList = ContextCompat.getColorStateList(context, R.color.typex_aluminium_light)
            setOnCheckedChangeListener { _, checked ->
                aiEnabled = checked
                listener?.onAiToggle(checked)
            }
        }

        topRow.addView(aiLabel)
        topRow.addView(loadingBar)
        topRow.addView(aiSwitch)
        toolbar.addView(topRow)

        toneRow = HorizontalScrollView(context).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
            visibility = if (prefs.isAiEnabled()) View.VISIBLE else View.GONE
        }
        val chipRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            setPadding(dp(2), dp(2), dp(2), dp(6))
        }
        chipRow.addView(buildTranslateChip())
        ToneOptions.ALL.forEach { tone -> chipRow.addView(buildToneChip(tone)) }
        toneRow.addView(chipRow)
        toolbar.addView(toneRow)

        return toolbar
    }

    private fun buildToneChip(tone: ToneOption): TextView = TextView(context).apply {
        text = tone.label
        setTextColor(ContextCompat.getColor(context, R.color.typex_text_primary))
        textSize = 12.5f
        isClickable = true
        isFocusable = true
        setPadding(dp(12), dp(6), dp(12), dp(6))
        background = chipDrawable(R.color.typex_aluminium, R.color.typex_aluminium_light)
        layoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply {
            marginEnd = dp(6)
        }
        setOnClickListener { listener?.onTone(tone) }
    }

    private fun buildTranslateChip(): TextView = TextView(context).apply {
        text = context.getString(R.string.translate_label)
        setTextColor(ContextCompat.getColor(context, R.color.typex_bg_black))
        textSize = 12.5f
        isClickable = true
        isFocusable = true
        setPadding(dp(12), dp(6), dp(12), dp(6))
        background = chipDrawable(R.color.typex_gold_accent, R.color.typex_gold_accent_dim)
        layoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply {
            marginEnd = dp(10)
        }
        setOnClickListener { listener?.onTranslate(prefs.getDefaultLanguage()) }
    }

    // ---------------- Key rows ----------------

    private fun renderKeyRows() {
        keysContainer.removeAllViews()
        val keyHeight = if (prefs.isCompactKeys()) dp(40) else dp(48)
        val rows = if (isSymbolsOn) symbolRows else letterRows
        rows.forEachIndexed { index, row -> keysContainer.addView(buildKeyRow(row, keyHeight, index)) }
        keysContainer.addView(buildBottomRow(keyHeight))
    }

    private fun buildKeyRow(keys: List<String>, keyHeight: Int, rowIndex: Int): LinearLayout {
        val row = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(4)
            }
        }
        if (!isSymbolsOn && rowIndex == 2) {
            val shiftColor = if (isShiftOn || isCapsLockOn) R.color.typex_green_accent else R.color.typex_text_primary
            row.addView(
                buildFunctionKey("\u21E7", 1.5f, keyHeight) { listener?.onShift() }
                    .apply { setTextColor(ContextCompat.getColor(context, shiftColor)) }
            )
        }
        keys.forEach { key -> row.addView(buildLetterKey(key, keyHeight)) }
        if (rowIndex == 2) {
            row.addView(buildFunctionKey("\u232B", 1.5f, keyHeight) { listener?.onBackspace() })
        }
        return row
    }

    private fun buildLetterKey(key: String, keyHeight: Int): TextView {
        val display = if ((isShiftOn || isCapsLockOn) && !isSymbolsOn) key.uppercase() else key
        return TextView(context).apply {
            text = display
            gravity = Gravity.CENTER
            textSize = 16f
            isClickable = true
            isFocusable = true
            setTextColor(ContextCompat.getColor(context, R.color.typex_text_primary))
            background = keyDrawable()
            layoutParams = LayoutParams(0, keyHeight, 1f).apply { marginStart = dp(3); marginEnd = dp(3) }
            setOnClickListener { listener?.onChar(display) }
        }
    }

    private fun buildFunctionKey(label: String, weight: Float, height: Int, action: () -> Unit): TextView =
        TextView(context).apply {
            text = label
            gravity = Gravity.CENTER
            textSize = 16f
            isClickable = true
            isFocusable = true
            setTextColor(ContextCompat.getColor(context, R.color.typex_text_primary))
            background = keyDrawable()
            layoutParams = LayoutParams(0, height, weight).apply { marginStart = dp(3); marginEnd = dp(3) }
            setOnClickListener { action() }
        }

    private fun buildBottomRow(keyHeight: Int): LinearLayout {
        val row = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(4)
            }
        }
        row.addView(
            buildFunctionKey(if (isSymbolsOn) "ABC" else "?123", 1.4f, keyHeight) {
                listener?.onSymbolsToggle()
            }
        )
        row.addView(buildFunctionKey(",", 0.8f, keyHeight) { listener?.onChar(",") })
        row.addView(
            TextView(context).apply {
                text = context.getString(R.string.space_label)
                gravity = Gravity.CENTER
                textSize = 13f
                isClickable = true
                isFocusable = true
                setTextColor(ContextCompat.getColor(context, R.color.typex_text_secondary))
                background = keyDrawable()
                layoutParams = LayoutParams(0, keyHeight, 4f).apply { marginStart = dp(3); marginEnd = dp(3) }
                setOnClickListener { listener?.onSpace() }
            }
        )
        row.addView(buildFunctionKey(".", 0.8f, keyHeight) { listener?.onChar(".") })
        row.addView(
            TextView(context).apply {
                text = "\u23CE"
                gravity = Gravity.CENTER
                textSize = 16f
                isClickable = true
                isFocusable = true
                setTextColor(ContextCompat.getColor(context, R.color.typex_bg_black))
                background = chipDrawable(R.color.typex_green_accent, R.color.typex_green_accent_dim)
                layoutParams = LayoutParams(0, keyHeight, 1.4f).apply { marginStart = dp(3); marginEnd = dp(3) }
                setOnClickListener { listener?.onEnter() }
            }
        )
        return row
    }

    // ---------------- Drawables ----------------

    private fun stateDrawable(radiusDp: Int, colorRes: Int, pressedColorRes: Int): Drawable {
        val normal = GradientDrawable().apply {
            cornerRadius = dp(radiusDp).toFloat()
            setColor(ContextCompat.getColor(context, colorRes))
        }
        val pressed = GradientDrawable().apply {
            cornerRadius = dp(radiusDp).toFloat()
            setColor(ContextCompat.getColor(context, pressedColorRes))
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), pressed)
            addState(intArrayOf(), normal)
        }
    }

    private fun keyDrawable() = stateDrawable(8, R.color.typex_key_bg, R.color.typex_key_pressed)
    private fun chipDrawable(colorRes: Int, pressedColorRes: Int) = stateDrawable(16, colorRes, pressedColorRes)

    private fun dp(value: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value.toFloat(), resources.displayMetrics).toInt()
}
