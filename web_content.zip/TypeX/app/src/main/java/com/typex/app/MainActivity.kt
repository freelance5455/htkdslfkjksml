package com.typex.app

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * TypeX's home screen. This activity does not, and cannot, silently install
 * TypeX as the system keyboard — only the user can do that, through
 * Android's own input-method settings / picker. What this screen does is
 * make that flow as short as possible.
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btnActivateKeyboard).setOnClickListener {
            // Opens Android's system "Manage keyboards" screen, where the
            // user enables TypeX.
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }

        findViewById<Button>(R.id.btnSelectKeyboard).setOnClickListener {
            // Opens the system input-method picker so the user can make
            // TypeX the active keyboard (relevant once it's already enabled).
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        }

        findViewById<ImageButton>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        val statusView = findViewById<TextView>(R.id.tvStatus)
        val enabledIds = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_INPUT_METHODS) ?: ""
        val currentId = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: ""
        statusView.text = when {
            currentId.contains(packageName) -> getString(R.string.status_active)
            enabledIds.contains(packageName) -> getString(R.string.status_enabled_not_selected)
            else -> getString(R.string.status_not_enabled)
        }
    }
}
