package com.typex.app

import android.os.Bundle
import android.widget.RadioGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import com.typex.app.data.PreferencesManager

class SettingsActivity : AppCompatActivity() {

    private lateinit var prefs: PreferencesManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        prefs = PreferencesManager(this)

        val aiSwitch = findViewById<SwitchCompat>(R.id.switchAiDefault)
        aiSwitch.isChecked = prefs.isAiEnabled()
        aiSwitch.setOnCheckedChangeListener { _, checked -> prefs.setAiEnabled(checked) }

        val langGroup = findViewById<RadioGroup>(R.id.radioGroupLanguage)
        langGroup.check(
            when (prefs.getDefaultLanguage()) {
                "Hinglish" -> R.id.radioHinglish
                "Tanglish" -> R.id.radioTanglish
                else -> R.id.radioEnglish
            }
        )
        langGroup.setOnCheckedChangeListener { _, checkedId ->
            val lang = when (checkedId) {
                R.id.radioHinglish -> "Hinglish"
                R.id.radioTanglish -> "Tanglish"
                else -> "English"
            }
            prefs.setDefaultLanguage(lang)
        }

        val compactSwitch = findViewById<SwitchCompat>(R.id.switchCompactKeys)
        compactSwitch.isChecked = prefs.isCompactKeys()
        compactSwitch.setOnCheckedChangeListener { _, checked -> prefs.setCompactKeys(checked) }
    }
}
