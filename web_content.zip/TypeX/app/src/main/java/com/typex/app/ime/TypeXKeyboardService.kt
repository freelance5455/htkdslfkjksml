package com.typex.app.ime

import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import com.typex.app.R
import com.typex.app.ai.AiClient
import com.typex.app.ai.AiResult
import com.typex.app.ai.ToneOption
import com.typex.app.data.PreferencesManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * TypeX's real Android input method. This is what makes Android treat TypeX
 * as an actual keyboard: it extends InputMethodService, is declared in
 * AndroidManifest.xml with the android.view.InputMethod intent-filter, and
 * is listed in Android's own keyboard settings once the user enables it
 * there — there is no way for an app to install itself as the system
 * keyboard without that user action, and this class doesn't try to.
 *
 * Normal typing (letters, backspace, space, enter, shift, symbols) always
 * works, AI on or off. AI network calls only ever happen inside
 * performAiRewrite/performAiTranslate, which only run when the user taps a
 * tone or Translate chip AND prefs.isAiEnabled() is true — there is no
 * keystroke-by-keystroke transmission anywhere in this class.
 */
class TypeXKeyboardService : InputMethodService() {

    private lateinit var keyboardView: TypeXKeyboardView
    private lateinit var prefs: PreferencesManager
    private val aiClient = AiClient()

    private var isShifted = false
    private var isCapsLock = false
    private var isSymbolsMode = false

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var activeAiJob: Job? = null
    private var isAiRequestInFlight = false

    override fun onCreate() {
        super.onCreate()
        prefs = PreferencesManager(this)
    }

    override fun onCreateInputView(): View {
        keyboardView = TypeXKeyboardView(this)
        keyboardView.aiEnabled = prefs.isAiEnabled()
        keyboardView.setListener(object : TypeXKeyboardView.Listener {
            override fun onChar(c: String) = commitChar(c)
            override fun onBackspace() = handleBackspace()
            override fun onEnter() = handleEnter()
            override fun onSpace() {
                currentInputConnection?.commitText(" ", 1)
            }
            override fun onShift() = toggleShift()
            override fun onSymbolsToggle() {
                isSymbolsMode = !isSymbolsMode
                keyboardView.setSymbolsMode(isSymbolsMode)
            }
            override fun onAiToggle(enabled: Boolean) {
                prefs.setAiEnabled(enabled)
            }
            override fun onTone(tone: ToneOption) = performAiRewrite(tone)
            override fun onTranslate(targetLang: String) = performAiTranslate(targetLang)
        })
        return keyboardView
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        isShifted = false
        isCapsLock = false
        isSymbolsMode = false
        // Re-sync with prefs every time the keyboard reappears, in case the
        // user changed the default from the Settings screen in the meantime.
        keyboardView.aiEnabled = prefs.isAiEnabled()
        keyboardView.setSymbolsMode(false)
        keyboardView.setShiftState(false, false)
    }

    // Keep our own toolbar+keys view visible instead of switching to the
    // system's fullscreen "extract" editing UI, which would hide it.
    override fun onEvaluateFullscreenMode(): Boolean = false

    // -------------------- Normal typing --------------------

    private fun commitChar(c: String) {
        currentInputConnection?.commitText(c, 1)
        if (isShifted && !isCapsLock) {
            isShifted = false
            keyboardView.setShiftState(false, false)
        }
    }

    private fun handleBackspace() {
        val ic = currentInputConnection ?: return
        val selected = ic.getSelectedText(0)
        if (!selected.isNullOrEmpty()) {
            ic.commitText("", 1)
        } else {
            ic.deleteSurroundingText(1, 0)
        }
    }

    private fun handleEnter() {
        val ic = currentInputConnection ?: return
        val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)
        if (action != null && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            ic.commitText("\n", 1)
        }
    }

    private fun toggleShift() {
        when {
            isCapsLock -> {
                isCapsLock = false
                isShifted = false
            }
            isShifted -> {
                isCapsLock = true
            }
            else -> {
                isShifted = true
            }
        }
        keyboardView.setShiftState(isShifted, isCapsLock)
    }

    // -------------------- AI text access --------------------

    private data class TargetText(val text: String, val isSelection: Boolean, val precedingLength: Int = 0)

    /**
     * Prefers an actual text selection. If nothing is selected, falls back
     * to the current line before the cursor (bounded by Android's
     * surrounding-text limits — TypeX never assumes it can see an app's
     * entire text field).
     */
    private fun getTargetText(): TargetText? {
        val ic = currentInputConnection ?: return null
        val selected = ic.getSelectedText(0)
        if (!selected.isNullOrEmpty()) {
            return TargetText(selected.toString(), isSelection = true)
        }
        val before = ic.getTextBeforeCursor(500, 0)?.toString() ?: ""
        if (before.isBlank()) return null
        val start = before.lastIndexOf('\n').let { if (it == -1) 0 else it + 1 }
        val snippet = before.substring(start).trimStart()
        if (snippet.isBlank()) return null
        return TargetText(snippet, isSelection = false, precedingLength = before.length - start)
    }

    private fun replaceTargetText(target: TargetText, newText: String) {
        val ic = currentInputConnection ?: return
        if (target.isSelection) {
            ic.commitText(newText, 1)
        } else {
            ic.deleteSurroundingText(target.precedingLength, 0)
            ic.commitText(newText, 1)
        }
    }

    // -------------------- AI actions --------------------

    private fun performAiRewrite(tone: ToneOption) {
        if (!prefs.isAiEnabled() || isAiRequestInFlight) return
        val target = getTargetText() ?: run {
            Toast.makeText(this, getString(R.string.error_no_text), Toast.LENGTH_SHORT).show()
            return
        }
        runAiOperation(target) { aiClient.rewrite(target.text, tone, prefs.getDefaultLanguage()) }
    }

    private fun performAiTranslate(targetLang: String) {
        if (!prefs.isAiEnabled() || isAiRequestInFlight) return
        val target = getTargetText() ?: run {
            Toast.makeText(this, getString(R.string.error_no_text), Toast.LENGTH_SHORT).show()
            return
        }
        runAiOperation(target) { aiClient.translate(target.text, targetLang) }
    }

    private fun runAiOperation(target: TargetText, op: suspend () -> AiResult) {
        // Cancel any in-flight request instead of piling requests up, and
        // guard with isAiRequestInFlight so a fast double-tap can't fire twice.
        activeAiJob?.cancel()
        isAiRequestInFlight = true
        keyboardView.setLoading(true)
        activeAiJob = serviceScope.launch {
            val result = op()
            isAiRequestInFlight = false
            keyboardView.setLoading(false)
            when (result) {
                is AiResult.Success -> replaceTargetText(target, result.text)
                is AiResult.Error ->
                    Toast.makeText(this@TypeXKeyboardService, result.message, Toast.LENGTH_SHORT).show()
                // On error the original text is left completely untouched.
            }
        }
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        activeAiJob?.cancel()
        isAiRequestInFlight = false
        keyboardView.setLoading(false)
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }
}
