package com.typex.app.ai

data class ToneOption(val id: String, val label: String, val instruction: String)

object ToneOptions {
    val ALL = listOf(
        ToneOption("professional", "Professional", "Rewrite in a professional, polished tone suitable for the workplace."),
        ToneOption("formal", "Formal", "Rewrite in a formal, respectful tone."),
        ToneOption("casual", "Casual", "Rewrite in a relaxed, casual, everyday tone."),
        ToneOption("friendly", "Friendly", "Rewrite in a warm, friendly tone."),
        ToneOption("confident", "Confident", "Rewrite in a confident, assertive tone."),
        ToneOption("polite", "Polite", "Rewrite in a courteous, polite tone."),
        ToneOption("short_clear", "Short & Clear", "Rewrite to be as short and clear as possible while keeping the meaning."),
        ToneOption("persuasive", "Persuasive", "Rewrite in a persuasive, compelling tone."),
        ToneOption("business", "Business", "Rewrite in a concise business-communication tone."),
        ToneOption("genz", "Gen Z", "Rewrite in a casual Gen Z internet style."),
        ToneOption("funny", "Funny", "Rewrite with light, natural humor."),
        ToneOption("natural", "Natural", "Rewrite so it sounds natural and conversational."),
        ToneOption("academic", "Academic", "Rewrite in a precise, academic tone."),
        ToneOption("creative", "Creative", "Rewrite with a creative, expressive style."),
        ToneOption("respectful", "Respectful", "Rewrite in a respectful, considerate tone.")
    )
}
