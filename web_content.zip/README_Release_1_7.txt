Soul Music Player Pro — Release 1.7

Atualização:
- Seletor de idioma diretamente no local da apresentação inicial indicado pelo usuário.
- Idioma salvo em localStorage e restaurado automaticamente.
- Idioma também disponível em Ajustes.
- Idiomas: Português (Brasil), English (US), Español, Français, Deutsch, Italiano e Português (Portugal).
- Alterar o idioma não apaga aparência, equalizador, letras, playlists, termos, permissões preparadas ou demais configurações.
- Todos os recursos anteriores foram mantidos.
