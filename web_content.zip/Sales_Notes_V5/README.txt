Sales Notes V8 - Supir per item + menu Laporan Penjualan terpisah.
Paket ini mempertahankan localStorage key sales-notes-final-v5 agar data lama di perangkat tetap terbaca. Jangan hapus data aplikasi/browser saat mengganti versi.
Buka index.html melalui APK Forge sebagai konten web.
