Sales Notes V7 FIX + ICONS
- Kasbon/Utang Toko dapat dihapus jika salah input.
- Setoran & Pengeluaran dapat ditambah, diedit, dan dihapus.
- Saldo = total setoran - total pengeluaran.
- Pending/Simpanan memakai saldo berjalan per produk.
- Icon/emoji V7 dikembalikan seperti versi sebelumnya.
- Offline/localStorage.
