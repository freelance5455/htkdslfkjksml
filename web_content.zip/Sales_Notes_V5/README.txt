SALES NOTES V5

Update utama:
- Rekap Pending/Simpanan memakai saldo berjalan per produk.
- Rumus: saldo sebelumnya + (Penjualan hari ini - Masuk Laporan hari ini).
- Positif = Pending, negatif = Simpanan, nol = Pas.
- Navigasi/menu dipertahankan dari versi yang sudah berfungsi.
- Cache/service worker dinaikkan ke V5.

Paket siap dimasukkan ke APK Forge.
