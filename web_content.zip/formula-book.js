/* Formula Book: general engineering references plus source-linked Air Conditioning, Refrigeration, and Cold Storage & Products formulas. */
const FORMULA_BOOK = [
  {
    "category": "Hydroelectric",
    "title": "Hydraulic power from flow and head",
    "formula": "Pₕ = ρ g Q H = γ Q H",
    "variables": "Pₕ = hydraulic power (W); ρ = water density (kg/m³); g = 9.81 m/s²; Q = flow rate (m³/s); H = net head (m); γ = ρg (N/m³).",
    "when": "Use for water flowing through a turbine or hydraulic system when flow rate and net head are known.",
    "derivation": "Available energy per unit mass is gH (J/kg). Mass flow rate is ṁ = ρQ (kg/s). Therefore Pₕ = ṁgH = ρQ gH. Since γ = ρg, Pₕ = γQH.",
    "shortcut": "For water, Pₕ (kW) ≈ 9.81 QH when Q is in m³/s and H is in metres."
  },
  {
    "category": "Hydroelectric",
    "title": "Electrical output of a hydro plant",
    "formula": "Pₒᵤₜ = ρ g Q H ηₜ ηg  (or Pₒᵤₜ = ρgQHηₒᵥₑᵣₐₗₗ)",
    "variables": "Pₒᵤₜ = electrical output (W); ηₜ = turbine efficiency; ηg = generator efficiency; ηoverall = combined efficiency.",
    "when": "Use when hydraulic input power is converted to electrical power.",
    "derivation": "Output power equals input power multiplied by efficiency. For components in series, ηoverall = ηₜηg (and include other component efficiencies only if stated).",
    "shortcut": "Pₒᵤₜ(kW) ≈ 9.81QHηoverall."
  },
  {
    "category": "Hydroelectric",
    "title": "Net head",
    "formula": "Hₙ = Hgross − hₗₒₛₛₑₛ",
    "variables": "Hₙ = net head (m); Hgross = gross elevation/head difference (m); hlosses = penstock and other hydraulic losses (m).",
    "when": "Use when losses are given or gross head must be converted to usable turbine head.",
    "derivation": "Energy available at the turbine is reduced by head dissipated through friction, bends, valves, and other losses.",
    "shortcut": "Subtract losses once; do not subtract tailwater twice if it is already included in the gross head definition."
  },
  {
    "category": "Hydroelectric",
    "title": "Flow rate through a pipe",
    "formula": "Q = A V = (πD²/4)V",
    "variables": "Q = volume flow rate (m³/s); A = cross-sectional area (m²); V = average velocity (m/s); D = pipe diameter (m).",
    "when": "Use for flow through a full circular pipe when diameter and average velocity are known.",
    "derivation": "Flow rate is the volume crossing a section per unit time. In time Δt, a fluid column of length VΔt passes, so Q = AV.",
    "shortcut": "Find area first, then multiply by velocity. Convert diameter to metres."
  },
  {
    "category": "Hydroelectric",
    "title": "Continuity equation",
    "formula": "Q₁ = Q₂  ⇒  A₁V₁ = A₂V₂",
    "variables": "A = flow area; V = average velocity.",
    "when": "For steady incompressible flow with no branches or leaks between sections.",
    "derivation": "Conservation of mass means the same volume per second passes each section for incompressible flow.",
    "shortcut": "If diameter halves, area becomes one-quarter, so velocity becomes four times as large."
  },
  {
    "category": "Hydroelectric",
    "title": "Hydraulic energy and power",
    "formula": "E = ρgV H;  P = E/t",
    "variables": "E = energy (J); V = water volume (m³); H = head (m); t = time (s).",
    "when": "Use when a volume of water falls through a known head over a given time.",
    "derivation": "Mass of water is m = ρV. Potential energy is E = mgH = ρVgH. Power is energy per unit time.",
    "shortcut": "For a steady flow, replace V/t with Q to get P = ρgQH."
  },
  {
    "category": "Hydroelectric",
    "title": "Specific speed of a turbine",
    "formula": "Nₛ = N√P / H^(5/4)",
    "variables": "Nₛ = specific speed (definition depends on unit convention); N = speed (rpm); P = power; H = head.",
    "when": "Use only with the same unit convention and definition used by the problem or reference table.",
    "derivation": "This is an empirical similarity parameter used to compare turbine types; its numerical value depends on the chosen units and power convention.",
    "shortcut": "Do not mix metric and US customary versions; check whether P is kW, hp, or another unit."
  },
  {
    "category": "Thermodynamics",
    "title": "First law for a closed system",
    "formula": "Q − W = ΔU + ΔKE + ΔPE",
    "variables": "Q = heat added to system; W = work done by system; U = internal energy; KE = kinetic energy; PE = potential energy.",
    "when": "Use for a fixed amount of matter in a control mass. With negligible kinetic and potential energy changes: Q − W = ΔU.",
    "derivation": "Energy entering as heat minus energy leaving as work equals the system energy change, by conservation of energy.",
    "shortcut": "Write the sign convention first: heat into system positive, work by system positive."
  },
  {
    "category": "Thermodynamics",
    "title": "Steady-flow energy equation",
    "formula": "q − wₛ = (h₂−h₁) + (V₂²−V₁²)/2 + g(z₂−z₁)",
    "variables": "q = heat per unit mass; ws = shaft work per unit mass; h = enthalpy; V = velocity; z = elevation.",
    "when": "Use for turbines, compressors, pumps, nozzles, diffusers, boilers, and condensers at steady state.",
    "derivation": "Apply energy conservation to a control volume; flow work is incorporated into enthalpy h = u + pv.",
    "shortcut": "Neglect only terms justified by the problem. Turbines often have heat, velocity, and elevation changes treated as negligible."
  },
  {
    "category": "Thermodynamics",
    "title": "Ideal-gas equation",
    "formula": "pV = mRT  or  pv = RT",
    "variables": "p = absolute pressure; V = total volume; m = mass; v = specific volume; R = gas constant; T = absolute temperature (K).",
    "when": "Use for gases approximated as ideal gases.",
    "derivation": "The ideal-gas state relation links pressure, volume, mass, and absolute temperature.",
    "shortcut": "Use absolute pressure and kelvin. For specific gas constant, R = Ru/M."
  },
  {
    "category": "Thermodynamics",
    "title": "Enthalpy definition",
    "formula": "h = u + pv",
    "variables": "h = specific enthalpy (kJ/kg); u = specific internal energy (kJ/kg); p = pressure; v = specific volume.",
    "when": "Used in steam tables and steady-flow devices.",
    "derivation": "Enthalpy combines internal energy with flow work per unit mass, pv.",
    "shortcut": "For steady-flow energy problems, use h values from the correct steam-table state."
  },
  {
    "category": "Thermodynamics",
    "title": "Sensible heating or cooling",
    "formula": "Q = mcₚ(T₂ − T₁)",
    "variables": "Q = heat transfer (kJ); m = mass (kg); cp = specific heat (kJ/kg·K); T = temperature (°C difference or K difference).",
    "when": "Use when specific heat is approximately constant and there is no phase change.",
    "derivation": "Specific heat is cp = (1/m)(dQ/dT). For constant cp, integrate to obtain Q = mcpΔT.",
    "shortcut": "Temperature differences have the same numerical value in °C and K."
  },
  {
    "category": "Thermodynamics",
    "title": "Boundary work: constant pressure",
    "formula": "W = p(V₂ − V₁)",
    "variables": "W = work done by system (J); p = constant absolute pressure; V = volume.",
    "when": "Use for a quasi-equilibrium constant-pressure expansion or compression.",
    "derivation": "Boundary work W = ∫p dV. If p is constant, W = p∫dV = p(V₂−V₁).",
    "shortcut": "Expansion gives positive work by the system under this sign convention; compression gives negative work."
  },
  {
    "category": "Thermodynamics",
    "title": "Isothermal ideal-gas process",
    "formula": "ΔU = 0;  W = mRT ln(V₂/V₁);  Q = W",
    "variables": "For an ideal gas at constant temperature; R is the specific gas constant.",
    "when": "Use for a reversible isothermal process of an ideal gas.",
    "derivation": "Ideal-gas internal energy depends only on temperature, so ΔT = 0 gives ΔU = 0. Reversible work is ∫p dV with p = mRT/V, giving the logarithmic expression. First law gives Q = W.",
    "shortcut": "Use volume ratio V₂/V₁, or pressure ratio p₁/p₂ for the same mass and temperature."
  },
  {
    "category": "Thermodynamics",
    "title": "Isobaric ideal-gas process",
    "formula": "W = p(V₂−V₁) = mR(T₂−T₁);  Q = mcₚΔT",
    "variables": "Pressure is constant; cp and R are specific gas properties.",
    "when": "Use for constant-pressure heating or cooling of an ideal gas.",
    "derivation": "Start with W = pΔV. From pV = mRT at constant p, pΔV = mRΔT. With ΔU = mcᵥΔT, first law gives Q = mcᵥΔT + mRΔT = mcₚΔT because cp = cv + R.",
    "shortcut": "At constant pressure, heat uses cp; boundary work uses R."
  },
  {
    "category": "Thermodynamics",
    "title": "Isochoric (constant-volume) process",
    "formula": "W = 0;  Q = ΔU = mcᵥ(T₂−T₁)",
    "variables": "cv = specific heat at constant volume.",
    "when": "Use for a rigid tank or any constant-volume ideal-gas process with negligible KE/PE changes.",
    "derivation": "Because volume does not change, W = ∫p dV = 0. The first law becomes Q = ΔU, and ΔU = mcvΔT for an ideal gas with constant cv.",
    "shortcut": "Rigid tank: no boundary work."
  },
  {
    "category": "Thermodynamics",
    "title": "Reversible adiabatic / isentropic ideal-gas relations",
    "formula": "pVᵏ = constant;  TV^(k−1) = constant;  T₂/T₁ = (p₂/p₁)^((k−1)/k)",
    "variables": "k = cp/cv; process is reversible and adiabatic; ideal gas with constant specific heats.",
    "when": "Use for idealized compressors, turbines, and piston-cylinder processes when the stated assumptions apply.",
    "derivation": "For a reversible adiabatic ideal gas, ds = 0 and the ideal-gas entropy relation yields the pressure-volume and temperature-pressure power laws.",
    "shortcut": "Use absolute temperatures and absolute pressures. These relations do not automatically apply to real steam."
  },
  {
    "category": "Thermodynamics",
    "title": "Polytropic process",
    "formula": "pVⁿ = constant;  W = (p₂V₂−p₁V₁)/(1−n), n ≠ 1",
    "variables": "n = polytropic exponent; p and V are endpoint pressures and volumes.",
    "when": "Use for a quasi-equilibrium gas process that follows pVⁿ = constant.",
    "derivation": "W = ∫p dV and p = C/Vⁿ. Integrating gives W = C(V₂^(1−n)−V₁^(1−n))/(1−n), equivalent to the endpoint formula.",
    "shortcut": "If n = 1, use the isothermal logarithmic form instead."
  },
  {
    "category": "Thermodynamics",
    "title": "Thermal efficiency of a heat engine",
    "formula": "ηₜₕ = Wₙₑₜ/Qᵢₙ = 1 − Qₒᵤₜ/Qᵢₙ",
    "variables": "Qin = heat supplied; Qout = heat rejected (magnitudes); Wnet = net work output.",
    "when": "Use for heat engines and idealized cycles.",
    "derivation": "Energy balance over a complete cycle gives Wnet = Qin − Qout. Divide by Qin to obtain the efficiency expression.",
    "shortcut": "Efficiency is a ratio; express as a percentage only at the end."
  },
  {
    "category": "Thermodynamics",
    "title": "Carnot efficiency",
    "formula": "ηCarnot = 1 − Tₗ/Tₕ",
    "variables": "Th = hot-reservoir absolute temperature (K); Tl = cold-reservoir absolute temperature (K).",
    "when": "Maximum theoretical efficiency between two thermal reservoirs.",
    "derivation": "For a reversible cycle, Qout/Qin = Tl/Th. Substitute into η = 1 − Qout/Qin.",
    "shortcut": "Temperatures must be in kelvin, never Celsius."
  },
  {
    "category": "Thermodynamics",
    "title": "Quality of a saturated liquid-vapor mixture",
    "formula": "x = (y − y_f)/(y_g − y_f);  y = y_f + x(y_g−y_f)",
    "variables": "x = quality (0 to 1); y may be v, u, h, or s; f = saturated liquid; g = saturated vapor.",
    "when": "Use only inside the saturation dome for a saturated liquid-vapor mixture.",
    "derivation": "A mixture property is the mass-weighted average: y = (1−x)yf + xyg. Rearranging gives the quality formula.",
    "shortcut": "Quality is vapor mass fraction, not volume fraction. Do not use it for superheated or compressed liquid states."
  },
  {
    "category": "Thermodynamics",
    "title": "Entropy change of an ideal gas",
    "formula": "Δs = cₚ ln(T₂/T₁) − R ln(p₂/p₁)",
    "variables": "Specific entropy change Δs; cp and R constant; absolute T and p.",
    "when": "Use for ideal-gas entropy change with constant specific heats.",
    "derivation": "Integrate ds = cp dT/T − R dp/p between states 1 and 2.",
    "shortcut": "Use natural logarithms and absolute values of temperature and pressure."
  },
  {
    "category": "Thermodynamics",
    "title": "Rankine cycle: thermal efficiency",
    "formula": "ηRankine = (wₜ − wₚ)/qᵢₙ = [(h₃−h₄)−(h₂−h₁)]/(h₃−h₂)",
    "variables": "Ideal simple Rankine state labels: 1 pump inlet, 2 pump outlet, 3 boiler outlet, 4 turbine outlet.",
    "when": "Use when enthalpies at the four cycle states are available.",
    "derivation": "Turbine work is h3−h4; pump work input is h2−h1; boiler heat input is h3−h2. Net work divided by heat input gives efficiency.",
    "shortcut": "Keep the state numbering from the diagram in the problem; not all books number states identically."
  },
  {
    "category": "Heat Transfer",
    "title": "Conduction through a plane wall",
    "formula": "Q̇ = kA(T₁−T₂)/L",
    "variables": "Qdot = heat-transfer rate (W); k = thermal conductivity; A = area; L = wall thickness.",
    "when": "Steady one-dimensional conduction through a plane wall with constant k and no internal heat generation.",
    "derivation": "Fourier’s law is Q̇ = −kA dT/dx. For a linear temperature profile across thickness L, magnitude becomes kAΔT/L.",
    "shortcut": "Thermal resistance form: Q̇ = ΔT/Rth, where Rth = L/(kA)."
  },
  {
    "category": "Heat Transfer",
    "title": "Convection heat transfer",
    "formula": "Q̇ = hA(Tₛ − T∞)",
    "variables": "h = convection coefficient (W/m²·K); A = area; Ts = surface temperature; T∞ = fluid temperature away from surface.",
    "when": "Use for heat exchange between a surface and a moving or still fluid.",
    "derivation": "Newton’s law of cooling models the rate as proportional to area and surface-to-fluid temperature difference.",
    "shortcut": "Use temperature difference in K or °C; make sure h and A use compatible units."
  },
  {
    "category": "Heat Transfer",
    "title": "Thermal radiation exchange with large surroundings",
    "formula": "Q̇ = εσA(Tₛ⁴ − Tₛᵤᵣʳ⁴)",
    "variables": "ε = emissivity; σ = 5.670×10⁻⁸ W/m²·K⁴; temperatures in kelvin.",
    "when": "Approximate net radiation from a small surface to large isothermal surroundings.",
    "derivation": "Net emitted radiation is the difference between emission proportional to Ts⁴ and irradiation absorbed from surroundings proportional to Tsurr⁴.",
    "shortcut": "Never use Celsius in a fourth-power radiation equation."
  },
  {
    "category": "Heat Transfer",
    "title": "Lumped capacitance cooling/heating",
    "formula": "(T(t)−T∞)/(Tᵢ−T∞) = exp[−hAt/(ρVcₚ)]",
    "variables": "Ti = initial temperature; T∞ = ambient fluid temperature; ρVcₚ = thermal capacitance.",
    "when": "Use when internal temperature gradients are negligible, typically Bi = hLc/k < 0.1.",
    "derivation": "Energy balance: −hA(T−T∞) = ρVcₚ dT/dt. Separate variables and integrate from Ti at t=0.",
    "shortcut": "Solve for time with t = (ρVcₚ/hA) ln[(Ti−T∞)/(T−T∞)]."
  },
  {
    "category": "Fluid Mechanics",
    "title": "Bernoulli equation",
    "formula": "p/(ρg) + V²/(2g) + z = constant",
    "variables": "p = static pressure; V = speed; z = elevation; terms are pressure, velocity, and elevation head.",
    "when": "Along a streamline for steady incompressible inviscid flow with no shaft work or losses between points.",
    "derivation": "It is the mechanical-energy balance per unit weight under the stated assumptions.",
    "shortcut": "With pumps, turbines, or losses, add the corresponding head terms rather than using the simple form unchanged."
  },
  {
    "category": "Fluid Mechanics",
    "title": "Darcy–Weisbach pipe head loss",
    "formula": "h_f = f (L/D) (V²/2g)",
    "variables": "f = Darcy friction factor; L = pipe length; D = diameter; V = mean velocity.",
    "when": "Estimate major friction head loss in a full pipe.",
    "derivation": "The Darcy–Weisbach relation expresses loss as friction factor times length-to-diameter ratio times velocity head.",
    "shortcut": "Confirm the problem uses Darcy f, not Fanning friction factor (which differs by a factor of four)."
  },
  {
    "category": "Fluid Mechanics",
    "title": "Hydrostatic pressure variation",
    "formula": "p₂ − p₁ = ρg(z₁ − z₂)",
    "variables": "p = pressure; ρ = fluid density; z = elevation measured upward.",
    "when": "For a static fluid of constant density.",
    "derivation": "Vertical force balance on a small fluid element gives dp/dz = −ρg; integrate between elevations.",
    "shortcut": "Pressure increases as you move downward. Distinguish gauge pressure from absolute pressure."
  },
  {
    "category": "Engineering Mechanics",
    "title": "Newton’s second law",
    "formula": "ΣF = ma;  ΣM = Iα (rotation about a fixed axis)",
    "variables": "ΣF = net force; m = mass; a = acceleration; ΣM = net moment; I = mass moment of inertia; α = angular acceleration.",
    "when": "Use for translational and rotational dynamics.",
    "derivation": "The net external force changes linear momentum; for constant mass this becomes ΣF = ma. Rotational form applies to fixed-axis rotation.",
    "shortcut": "Draw the free-body diagram first, then choose axes that simplify the equations."
  },
  {
    "category": "Engineering Mathematics",
    "title": "Quadratic equation",
    "formula": "ax² + bx + c = 0  ⇒  x = [−b ± √(b²−4ac)]/(2a)",
    "variables": "a, b, c = coefficients with a ≠ 0.",
    "when": "Use to solve a quadratic equation when factoring is not convenient.",
    "derivation": "Complete the square after dividing by a; the discriminant b²−4ac determines the number of real roots.",
    "shortcut": "Check the discriminant and keep the ± sign; substitute roots back if needed."
  },
  {
    "category": "Engineering Mathematics",
    "title": "Linear interpolation",
    "formula": "y = y₁ + [(x−x₁)/(x₂−x₁)](y₂−y₁)",
    "variables": "(x₁,y₁), (x₂,y₂) = two known tabulated points.",
    "when": "Estimate a property between two nearby table entries when linear interpolation is appropriate.",
    "derivation": "Assume y changes linearly between the points and use the line equation through both data points.",
    "shortcut": "Use neighboring values that bracket the target; do not extrapolate unless permitted."
  },
  {
    "category": "Air Conditioning",
    "topic": "Psychrometrics",
    "subject": "Air Conditioning",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE",
    "title": "Humidity ratio (general and saturated air)",
    "formula": "ω = 0.622 Pv/(P − Pv);  ωs = 0.622 Ps/(P − Ps);  Pv = φ Psat(Tdb)",
    "variables": "ω = kg water vapor/kg dry air; Pv = water-vapor partial pressure; P = total pressure; φ = relative humidity as a fraction; Psat(Tdb) = saturation pressure at dry-bulb temperature.",
    "when": "Use for unsaturated air when vapor pressure is known, saturated air at a specified temperature, or when relative humidity and saturation pressure are provided.",
    "derivation": "The general relation is ω = 0.622Pv/(P−Pv). At saturation, Pv = Ps, giving ωs = 0.622Ps/(P−Ps). Relative humidity gives Pv = φPsat(Tdb).",
    "shortcut": "Convert RH percent to a fraction first. For saturation, use Ps at the state temperature. Rearranged: Pv = ωP/(0.622 + ω). Use absolute total pressure.",
    "source": "IPE Aircon 1-29(1).pdf — Problems 1, 2, 3, 7, 9; PDF pages 1–5.",
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=1"
  },
  {
    "category": "Air Conditioning",
    "topic": "Psychrometrics",
    "subject": "Air Conditioning",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE",
    "title": "Specific volume of moist air per kg of dry air",
    "formula": "v = Rda T/(P − Pᵥ)",
    "variables": "v = m³/kg dry air; Rda ≈ 0.287 kPa·m³/(kg·K); T = absolute dry-bulb temperature (K); P−Pv = dry-air partial pressure (kPa).",
    "when": "Use for specific volume of a moist-air mixture when dry-bulb temperature and vapor partial pressure are known.",
    "derivation": "Apply the ideal-gas equation to the dry-air portion: (P−Pv)V = mda Rda T. Dividing by mda gives v = V/mda = Rda T/(P−Pv).",
    "shortcut": "First determine Pv from humidity ratio or relative humidity, then use T in kelvin and pressure in kPa.",
    "source": "IPE Aircon 1-29(1).pdf — Problems 1 and 7; PDF pages 1 and 4–5.",
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=1"
  },
  {
    "category": "Air Conditioning",
    "topic": "Psychrometrics",
    "subject": "Air Conditioning",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE",
    "title": "Approximate enthalpy of moist air",
    "formula": "h ≈ c_{pa}T_{db} + ωh_g(T_{db});  h ≈ 1.005T + ω(2500 + 1.88T)",
    "variables": "h = moist-air enthalpy (kJ/kg dry air); T and Tdb = dry-bulb temperature (°C); ω = kg water vapor/kg dry air; cpa ≈ 1.005 kJ/(kg·K); hg = vapor enthalpy from the source property table.",
    "when": "Use the reviewer’s table-based form when hg is obtained from a table, or the common approximate psychrometric equation when dry-bulb temperature and humidity ratio are known.",
    "derivation": "Moist-air enthalpy per kg dry air is the dry-air sensible enthalpy plus the water-vapor enthalpy contribution. The approximate equation combines the vapor latent and sensible terms; keep T in °C and h in kJ/kg dry air.",
    "shortcut": "Find humidity ratio first; then use one consistent enthalpy method. Do not mix a tabulated hg and an approximate vapor-enthalpy term in the same calculation.",
    "source": "IPE Aircon 1-29(1).pdf — Problems 3–4; Blue-Book-With-Solution-VIP.pdf — Problem 439 (original PDF page 134; extracted PDF page 82).",
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=82"
  },
  {
    "category": "Air Conditioning",
    "topic": "Psychrometrics",
    "subject": "Air Conditioning",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE",
    "title": "Relative humidity from dew-point temperature",
    "formula": "φ = Pv/Psat(Tdb);  Pv = Psat(Tdp)",
    "variables": "φ = relative humidity as a fraction; Tdb = dry-bulb temperature; Tdp = dew-point temperature; Psat(T) = saturation vapor pressure at temperature T.",
    "when": "Use when the dew point and dry-bulb temperature are given at the same total pressure.",
    "derivation": "At dew point, the vapor partial pressure equals the saturation pressure at Tdp. Relative humidity is actual vapor pressure divided by saturation pressure at Tdb.",
    "shortcut": "Find Psat at the dew point for Pv, then divide by Psat at the dry-bulb temperature. Multiply by 100 for percent.",
    "source": "IPE Aircon 1-29(1).pdf — Problem 8; PDF page 5.",
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=5"
  },
  {
    "category": "Air Conditioning",
    "topic": "Psychrometrics",
    "subject": "Air Conditioning",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE",
    "title": "Water-vapor mass from partial pressure",
    "formula": "m_v = p_v V/(R_v T);  p_v = φ p_{sat}(T)",
    "variables": "mv = water-vapor mass (kg); pv = vapor partial pressure (kPa); V = room volume (m³); Rv = water-vapor gas constant (0.4615 kJ/(kg·K)); T = absolute temperature (K); φ = relative humidity as a fraction; psat = saturation pressure at T.",
    "when": "Use when room volume, temperature, relative humidity, and saturation pressure are known. Use vapor partial pressure in the ideal-gas relation, not total atmospheric pressure.",
    "derivation": "First find the water-vapor partial pressure from pv = φ psat. Then apply the ideal-gas equation to the water vapor alone: pvV = mvRvT, rearranged for mv.",
    "shortcut": "Convert relative humidity percent to a fraction and temperature to kelvin; keep Rv, pressure and energy units consistent.",
    "source": "IPE Aircon 1-29(1).pdf — Problem 11; Blue-Book-With-Solution-VIP.pdf — Problem 442 (original PDF page 135; extracted PDF page 83).",
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=83"
  },
  {
    "category": "Air Conditioning",
    "topic": "Cooling Loads",
    "subject": "Air Conditioning",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE",
    "title": "Dry-air mass flow from volumetric airflow",
    "formula": "ṁda = V̇/v",
    "variables": "ṁda = dry-air mass flow rate (kg/s); V̇ = volumetric flow rate (m³/s); v = moist-air specific volume per kg dry air (m³/kg dry air).",
    "when": "Use to convert a measured volumetric airflow into dry-air mass flow when the specific volume is known.",
    "derivation": "Specific volume per kg of dry air is v = V/mda. Differentiating with respect to time gives Vdot = mdot_da v; rearrange.",
    "shortcut": "Use the specific volume matching the same air state as the volumetric flow. Convert minutes to seconds if the answer is required in kg/s.",
    "source": "IPE Aircon 1-29(1).pdf — Problems 5, 14, 25, 26, and 29; PDF pages 3, 7, 16–17, 20.",
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=3"
  },
  {
    "category": "Air Conditioning",
    "topic": "Cooling Loads",
    "subject": "Air Conditioning",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE",
    "title": "Refrigeration capacity from enthalpy change",
    "formula": "Q̇ = ṁda(h₁ − h₂)",
    "variables": "Qdot = cooling/refrigeration capacity (kW); mdot_da = dry-air mass flow (kg/s); h1 and h2 = inlet and outlet moist-air enthalpies (kJ/kg dry air).",
    "when": "Use for cooling or conditioning a moist-air stream when inlet/outlet enthalpies and dry-air mass flow are known.",
    "derivation": "For a steady-flow air stream with negligible kinetic/potential energy changes and no shaft work, heat removed equals mass flow times enthalpy decrease.",
    "shortcut": "Cooling removes enthalpy, so with state 1 entering and state 2 leaving, h1−h2 should be positive for a cooling load.",
    "source": "IPE Aircon 1-29(1).pdf — Problems 5, 25, and 26; PDF pages 3, 16–17.",
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=3"
  },
  {
    "category": "Air Conditioning",
    "topic": "Cooling Loads",
    "subject": "Air Conditioning",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE",
    "title": "Adiabatic mixing of two air streams",
    "formula": "h₃ = (ṁ₁h₁ + ṁ₂h₂)/(ṁ₁ + ṁ₂)",
    "variables": "ṁ1, ṁ2 = dry-air mass flow rates; h1, h2 = inlet enthalpies; h3 = mixed-air enthalpy. Use consistent dry-air basis.",
    "when": "Use for mixing outdoor air and return air in an air-conditioning system when the mixing process is treated as adiabatic.",
    "derivation": "Apply steady mass conservation and energy conservation: ṁ1+ṁ2=ṁ3 and ṁ1h1+ṁ2h2=ṁ3h3. Solve for h3.",
    "shortcut": "The mixed enthalpy must lie between the two inlet enthalpies for positive flow rates and adiabatic mixing.",
    "source": "IPE Aircon 1-29(1).pdf — Problem 6; PDF page 4.",
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=4"
  },
  {
    "category": "Air Conditioning",
    "topic": "Cooling Loads",
    "subject": "Air Conditioning",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE",
    "title": "Sensible heat ratio (SHR)",
    "formula": "SHR = Q̇s/Q̇total = Q̇s/(Q̇s + Q̇l)",
    "variables": "SHR = sensible heat ratio (dimensionless); Qdot_s = sensible load; Qdot_l = latent load; Qdot_total = total cooling load.",
    "when": "Use to find sensible load from total load, or when sensible and latent cooling loads are given.",
    "derivation": "Total cooling load is the sum of sensible and latent parts. Divide the sensible part by total load to define SHR.",
    "shortcut": "If SHR and total load are known, Qdot_s = SHR × Qdot_total. Check that SHR lies between 0 and 1.",
    "source": "IPE Aircon 1-29(1).pdf — Problems 10 and 13; PDF pages 6–7.",
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=6"
  },
  {
    "category": "Air Conditioning",
    "topic": "Cooling Loads",
    "subject": "Air Conditioning",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE",
    "title": "Coil bypass factor (source method)",
    "formula": "BF = (Tmean − Tout)/(Tmean − Tin)",
    "variables": "BF = bypass factor; Tmean = coil mean temperature as defined in the source; Tout = air outlet temperature; Tin = air inlet temperature. Temperatures must share the same scale.",
    "when": "Use the mean-coil-temperature relation shown in this reviewer problem. Other coil/ADP definitions may use a different form.",
    "derivation": "This is the temperature-ratio method as printed in the supplied reviewer. It compares outlet-to-mean temperature difference with inlet-to-mean difference.",
    "shortcut": "Read the stated definition carefully: do not substitute apparatus dew point for mean coil temperature unless the problem defines them as the same.",
    "source": "IPE Aircon 1-29(1).pdf — Problem 12; PDF pages 6–7.",
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=6"
  },
  {
    "category": "Air Conditioning",
    "topic": "Cooling Loads",
    "subject": "Air Conditioning",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE",
    "title": "Sensible cooling load",
    "formula": "Q̇s = ṁ cp (Troom − Tsupply)",
    "variables": "Qdot_s = sensible cooling rate (kW); mdot = mass flow rate (kg/s); cp = specific heat (kJ/kg·K); Troom and Tsupply = room and supply-air temperatures.",
    "when": "Use for the sensible part of a room cooling load when room and supply temperatures and air mass flow are known.",
    "derivation": "Sensible heat transfer with approximately constant cp is Qdot = mdot cp ΔT. The room loses heat when room air is warmer than supply air.",
    "shortcut": "Find the air mass flow first from the ideal-gas relation or specific volume. Keep cp and flow units consistent.",
    "source": "IPE Aircon 1-29(1).pdf — Problem 14; PDF page 7.",
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=7"
  },
  {
    "category": "Air Conditioning",
    "topic": "Cooling Loads",
    "subject": "Air Conditioning",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE",
    "title": "Tons of refrigeration conversion",
    "formula": "TR = Q̇(kW)/3.516;  1 TR ≈ 3.516 kW = 12,000 Btu/hr ≈ 211 kJ/min",
    "variables": "TR = tons of refrigeration; Qdot = heat-removal rate/cooling capacity. A ton of refrigeration is a rate of heat removal, not mass or electrical input power.",
    "when": "Use to convert cooling capacity between kW, Btu/hr, kJ/min and tons of refrigeration. Do not confuse cooling capacity with compressor input power.",
    "derivation": "The conversion follows from the standard refrigeration-ton definition. Divide cooling capacity in kW by about 3.516 to obtain TR; use the equivalent value for the given unit system.",
    "shortcut": "For kW to TR, divide by 3.516; for Btu/hr to TR, divide by 12,000. Keep heat rate and power dimensions consistent.",
    "source": "IPE Aircon 1-29(1).pdf — Problems 25, 26 and 29; Blue-Book-With-Solution-VIP.pdf — Problems 496; original PDF page(s) 147; extracted PDF page(s) 87.",
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=87"
  },
  {
    "category": "Air Conditioning",
    "topic": "Duct Flow",
    "subject": "Air Conditioning",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE",
    "title": "Duct pressure drop and velocity (Darcy–Weisbach)",
    "formula": "ΔP = f (L/D)(ρV²/2);  V = √[2 ΔP D/(f L ρ)]",
    "variables": "ΔP = pressure drop (Pa); f = Darcy friction factor; L = duct length (m); D = diameter (m); ρ = air density (kg/m³); V = mean velocity (m/s).",
    "when": "Use for friction pressure loss in a straight duct when velocity is known, or rearrange to find velocity from an allowable pressure drop, with the friction factor and density supplied.",
    "derivation": "The Darcy–Weisbach relation gives ΔP = f(L/D)(ρV²/2). Rearranging this same relation for V yields V = √[2ΔP D/(fLρ)].",
    "shortcut": "Use consistent SI units and the same friction-factor convention as the reviewer. This is the same equation rearranged, not a separate formula.",
    "source": "IPE Aircon 1-29(1).pdf — Problems 15 and 16; PDF page 8.",
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=8"
  },
  {
    "category": "Air Conditioning",
    "topic": "Duct Flow",
    "subject": "Air Conditioning",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE",
    "title": "Equivalent diameter of a rectangular duct",
    "formula": "De = 2ab/(a + b)",
    "variables": "De = equivalent diameter as used in this reviewer (m); a and b = rectangular duct side dimensions (m).",
    "when": "Use the reviewer’s rectangular-duct equivalent-diameter relation for the listed pressure-loss calculations.",
    "derivation": "This equation is the specific equivalent-diameter expression used by the supplied text. Other hydraulic-diameter definitions may differ; use the convention stated in the problem.",
    "shortcut": "Use the short and long side consistently; all lengths must use the same unit.",
    "source": "IPE Aircon 1-29(1).pdf — Problems 17 and 18; PDF pages 8–9.",
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=8"
  },
  {
    "category": "Air Conditioning",
    "topic": "Duct Flow",
    "subject": "Air Conditioning",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE",
    "title": "Continuity and Bernoulli at a duct junction",
    "formula": "Qmain = Qbranch + Qrun;  Q = AV;  p₁ + ρV₁²/2 = p₂ + ρV₂²/2 + ΔPloss",
    "variables": "Q = volume flow rate; A = duct area; V = mean velocity; p = static pressure; ΔPloss = pressure-loss term for the junction.",
    "when": "Use for the branch junction problem in the source when flow rates, cross-sectional areas, and the specified junction-loss model are provided.",
    "derivation": "Conservation of volume flow gives the continuity equation for steady incompressible flow. The energy equation between sections must include a junction-loss term when the source models losses.",
    "shortcut": "Calculate each branch velocity from Q/A before applying Bernoulli. Do not apply the no-loss Bernoulli equation unchanged across a fitting.",
    "source": "IPE Aircon 1-29(1).pdf — Problem 19; PDF pages 9–10.",
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=9"
  },
  {
    "category": "Air Conditioning",
    "topic": "Duct Flow",
    "subject": "Air Conditioning",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE",
    "title": "Static-pressure recovery across a sudden enlargement",
    "formula": "p₂ − p₁ = (ρ/2)(V₁² − V₂²);  V₂ = V₁(A₁/A₂)",
    "variables": "p1, p2 = upstream and downstream static pressures; ρ = air density; V1, V2 = mean velocities; A1, A2 = duct areas.",
    "when": "Use for the source’s static-pressure change model across a sudden enlargement when elevation is unchanged and losses are handled according to that model.",
    "derivation": "Apply continuity to relate the velocities, then the source’s Bernoulli-style static-pressure relationship. This is static pressure recovery; it is not the same as the irreversible total-pressure loss across a real expansion.",
    "shortcut": "Since the downstream area is larger, downstream velocity is lower and static pressure can rise. Distinguish static pressure difference from total-pressure loss.",
    "source": "IPE Aircon 1-29(1).pdf — Problem 20; PDF page 11.",
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=11"
  },
  {
    "category": "Air Conditioning",
    "topic": "Cooling Towers",
    "subject": "Air Conditioning",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE",
    "title": "Cooling-tower effectiveness (source definition)",
    "formula": "ηtower = (Thot,in − Tcold,out)/(Thot,in − Twb,in)",
    "variables": "ηtower = tower effectiveness/efficiency as defined by the reviewer; Thot,in = entering hot-water temperature; Tcold,out = leaving cooled-water temperature; Twb,in = entering-air wet-bulb temperature.",
    "when": "Use for the cooling-tower performance definition when entering hot-water temperature, leaving water temperature, and entering-air wet-bulb temperature are known.",
    "derivation": "The numerator is the actual water temperature range. The denominator is the maximum ideal cooling range down to the entering-air wet-bulb temperature.",
    "shortcut": "Use consistent temperature units; temperature differences can be in °C or K. Do not replace wet-bulb temperature with dry-bulb temperature.",
    "source": "IPE Aircon 1-29(1).pdf — Problems 21 and 22; PDF pages 11–13.",
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=11"
  },
  {
    "category": "Air Conditioning",
    "topic": "Cooling Towers",
    "subject": "Air Conditioning",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE",
    "title": "Cooling-water heat removal",
    "formula": "Q̇water = ṁw cp,w (Thot − Tcold)",
    "variables": "Qdot_water = heat removed from the water (kW); mdot_w = water mass flow (kg/s); cp,w = water specific heat (about 4.18 kJ/kg·K in the supplied examples); Thot, Tcold = inlet and outlet temperatures.",
    "when": "Use to compute heat removed from cooling water across a cooling tower or cooler when water mass flow and temperature change are known.",
    "derivation": "Apply the sensible heat relation per unit mass and multiply by mass flow rate.",
    "shortcut": "For water, cp ≈ 4.18 kJ/(kg·K) near ordinary cooling-water temperatures; use a table value if the problem specifies one.",
    "source": "IPE Aircon 1-29(1).pdf — Problems 21–24; PDF pages 11–15.",
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=11"
  },
  {
    "category": "Air Conditioning",
    "topic": "Cooling Towers",
    "subject": "Air Conditioning",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE",
    "title": "Cooling-tower evaporation and simplified make-up water",
    "formula": "ṁevap ≈ ṁmakeup = ṁda (ωout − ωin)",
    "variables": "ṁevap = evaporated water rate (kg/s); ṁda = dry-air mass flow (kg dry air/s); ωin, ωout = entering and leaving humidity ratios (kg water/kg dry air).",
    "when": "Use when the cooling-tower air gains moisture and the reviewer treats evaporation as the only water loss. For make-up water, use this simplified balance only when blowdown, drift, and leaks are neglected.",
    "derivation": "Water vapor gained by the air equals dry-air mass flow multiplied by the humidity-ratio increase. If evaporation is the only loss, that rate also equals the make-up water rate.",
    "shortcut": "Use humidity ratio (kg water/kg dry air), not RH percentage. Add blowdown and drift separately if specified.",
    "source": "IPE Aircon 1-29(1).pdf — Problems 23 and 24; PDF pages 13–15.",
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=13"
  },
  {
    "category": "Air Conditioning",
    "topic": "Cooling Towers",
    "subject": "Air Conditioning",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE",
    "title": "Cooling-tower air-side energy balance",
    "formula": "ṁw cp,w (Tin − Tout) ≈ ṁda (hout − hin)",
    "variables": "ṁw = water mass flow rate; cp,w = specific heat of water; Tin−Tout = water cooling range; ṁda = dry-air mass flow; hin, hout = air enthalpy per kg dry air.",
    "when": "Use for the steady cooling-tower energy balance when heat loss to surroundings and other energy terms are neglected.",
    "derivation": "Heat lost by the hot water is balanced by enthalpy gained by the air. The approximation assumes no significant external heat transfer and consistent steady-flow control volume boundaries.",
    "shortcut": "Keep enthalpy in kJ/kg dry air and mass-flow rates in kg/s to get kW.",
    "source": "IPE Aircon 1-29(1).pdf — Problems 23 and 24; PDF pages 13–15.",
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=13"
  },
  {
    "category": "Air Conditioning",
    "topic": "Drying",
    "subject": "Air Conditioning",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE",
    "title": "Dry-basis moisture content",
    "formula": "Xdb = mwater/mdry solid;  mwater removed = mdry solid (X₁ − X₂)",
    "variables": "Xdb = kg water/kg dry solid; mwater = water mass; mdry solid = dry-solids mass. X1 and X2 = initial and final moisture contents on a dry basis.",
    "when": "Use for drying problems when moisture content is explicitly stated on a dry basis and dry-solids mass is conserved.",
    "derivation": "Dry-basis moisture content is defined as water mass divided by dry-solid mass. The reduction in water mass equals dry-solid mass times the reduction in dry-basis moisture content.",
    "shortcut": "Do not interpret 215% dry-basis moisture as 215% of the total wet mass; Xdb can exceed 1.",
    "source": "IPE Aircon 1-29(1).pdf — Problems 27 and 28; PDF pages 17–20.",
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=17"
  },
  {
    "category": "Air Conditioning",
    "topic": "Drying",
    "subject": "Air Conditioning",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE",
    "title": "Dry-air requirement for moisture removal",
    "formula": "ṁda = ṁwater removed/(ωout − ωin)",
    "variables": "ṁda = dry-air mass flow rate; ṁwater removed = moisture removal rate; ωout and ωin = outlet and inlet humidity ratios.",
    "when": "Use when the required water removal rate and change in air humidity ratio are known.",
    "derivation": "Water vapor gained per kg of dry air is ωout−ωin. Multiplying by dry-air mass flow gives the water removal rate; rearrange to solve for dry-air flow.",
    "shortcut": "Confirm that ωout > ωin for a drying process that removes moisture from the product.",
    "source": "IPE Aircon 1-29(1).pdf — Problems 27 and 28; PDF pages 17–20.",
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=17"
  },
  {
    "category": "Air Conditioning",
    "topic": "Drying",
    "subject": "Air Conditioning",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE",
    "title": "Drying fan volumetric capacity",
    "formula": "V̇ = ṁda vout",
    "variables": "Vdot = required air volume flow rate (m³/s or m³/min); mdot_da = dry-air mass flow; vout = outlet-air specific volume per kg dry air.",
    "when": "Use to convert the dry-air mass flow requirement from a drying problem into fan volumetric capacity at the stated outlet-air condition.",
    "derivation": "Specific volume is volume per mass. Multiplying dry-air mass flow by the corresponding outlet specific volume gives the volumetric-flow rate.",
    "shortcut": "Use v at the state that the volume flow refers to. Keep kg/s with m³/kg for m³/s, or kg/min for m³/min.",
    "source": "IPE Aircon 1-29(1).pdf — Problem 27; PDF pages 17–19.",
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=17"
  },
  {
    "category": "Air Conditioning",
    "topic": "Drying",
    "subject": "Air Conditioning",
    "boardCategory": "PIPE",
    "sourceOrganization": "IPE",
    "title": "Wet-basis and dry-basis moisture conversion",
    "formula": "Xwb = Xdb/(1 + Xdb);  Xdb = Xwb/(1 − Xwb)",
    "variables": "Xwb = water mass/total wet material mass (fraction); Xdb = water mass/dry-solids mass (kg/kg).",
    "when": "Use to convert moisture content definitions when a drying problem explicitly states wet basis or dry basis.",
    "derivation": "Let dry-solid mass be md and water mass be mw. Then Xdb=mw/md while Xwb=mw/(md+mw). Substitute mw=Xdb md into the wet-basis definition and rearrange.",
    "shortcut": "Wet-basis fraction must be less than 1 (or 100%). Dry-basis moisture can exceed 100%.",
    "source": "IPE Aircon 1-29(1).pdf — Problem 28; PDF pages 19–20.",
    "sourceFile": "source-material/IPE Aircon 1-29(1).pdf#page=19"
  },
  {
    "category": "Refrigeration",
    "topic": "Safety & ventilation",
    "subject": "Refrigeration",
    "boardCategory": "PIPE",
    "sourceOrganization": "Blue Book — Air Conditioning / Refrigeration reviewer",
    "title": "Refrigerant-room ventilation and relief correlations (source method)",
    "formula": "Q = 100√G;  F = 0.138√G;  C = 3600 f D L",
    "variables": "Q = mechanical ventilation flow (ft³/min), G = refrigerant mass in lb for the Q relation; F = free aperture area (m²), G = refrigerant mass in kg for the F relation; C = relief-device capacity (kg/hr); f = stated refrigerant/code factor; D and L = vessel dimensions (m).",
    "when": "Use only for the specific ventilation and relief-device questions that state these source correlations. These are empirical/code-style equations, not universal design standards.",
    "derivation": "The coefficients encode the source method and prescribed units, so use the relation as supplied rather than deriving it from a general energy equation. The capacity relation converts a kg/s quantity to kg/hr by multiplying by 3600.",
    "shortcut": "Pick the relation by the requested quantity first. Confirm units before substitution: the two square-root formulas use different G units; for C, convert D and L to metres and include the ×3600 conversion.",
    "source": "Blue-Book-With-Solution-VIP.pdf — Problems 5, 6, 7; original PDF page(s) 1, 2; extracted PDF page(s) 7, 8, 9.",
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=7"
  },
  {
    "category": "Refrigeration",
    "topic": "COP, EER & heat balance",
    "subject": "Refrigeration",
    "boardCategory": "PIPE",
    "sourceOrganization": "Blue Book — Air Conditioning / Refrigeration reviewer",
    "title": "Refrigeration COP, EER, and heat-rejection balance",
    "formula": "COP_R = Q̇_L/Ẇ_c;  Q̇_H = Q̇_L + Ẇ_c;  EER ≈ 3.412 COP_R;  COP_R ≈ EER/3.412",
    "variables": "QdotL = refrigeration/cooling rate; QdotH = condenser heat-rejection rate; Wdotc = compressor input power; COPR = coefficient of performance (dimensionless); EER uses Btu/hr per W under the stated convention.",
    "when": "Use to move between cooling effect, input power, heat rejected, COP and EER for a refrigeration system when the relevant quantities are given.",
    "derivation": "COP is cooling rate divided by power input. For a steady cycle, heat rejected equals heat absorbed plus work input. The EER conversion follows from the unit convention (1 W ≈ 3.412 Btu/hr).",
    "shortcut": "If cooling rate and COP are known, Wdot = QdotL/COP. Do not mix Btu/hr with watts without using the EER conversion.",
    "source": "Blue-Book-With-Solution-VIP.pdf — Problems 23, 25, 304; original PDF page(s) 5, 6, 85; extracted PDF page(s) 12, 13, 64.",
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=12"
  },
  {
    "category": "Refrigeration",
    "topic": "Carnot cycles",
    "subject": "Refrigeration",
    "boardCategory": "PIPE",
    "sourceOrganization": "Blue Book — Air Conditioning / Refrigeration reviewer",
    "title": "Reversed Carnot refrigerator and heat-pump COP",
    "formula": "COP_R = T_L/(T_H − T_L);  COP_HP = T_H/(T_H − T_L);  kW/TR = 3.516/COP_R",
    "variables": "TL = low-reservoir absolute temperature; TH = high-reservoir absolute temperature; COPR = refrigerator COP; COPHP = heat-pump COP. Use K or °R, never raw °C/°F in the ratios.",
    "when": "Use for an ideal reversed Carnot refrigerator or heat pump operating between two temperature reservoirs, or to estimate the ideal kW/TR.",
    "derivation": "For a reversible cycle, QL/TL = QH/TH and W = QH − QL. Rearranging the heat ratio gives COPR = QL/W = TL/(TH−TL) and COPHP = QH/W = TH/(TH−TL).",
    "shortcut": "Convert both temperatures to an absolute scale before subtracting. Real systems perform below the Carnot limit.",
    "source": "Blue-Book-With-Solution-VIP.pdf — Problems 127, 211, 366; original PDF page(s) 39, 62, 105; extracted PDF page(s) 19, 33, 81.",
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=19"
  },
  {
    "category": "Refrigeration",
    "topic": "Vapor-compression cycle",
    "subject": "Refrigeration",
    "boardCategory": "PIPE",
    "sourceOrganization": "Blue Book — Air Conditioning / Refrigeration reviewer",
    "title": "Vapor-compression refrigeration rates and compressor energy balance",
    "formula": "Q̇_L = ṁ_r(h₁ − h₄);  Ẇ_c ≈ ṁ_r(h₂ − h₁);  Q̇_H = ṁ_r(h₂ − h₃);  COP = Q̇_L/Ẇ_c;  Ẇ_in − Q̇_loss = ṁ_r(h₂ − h₁)",
    "variables": "mdot_r = refrigerant mass flow (kg/s); h1–h4 = specific enthalpies at the labeled cycle states (kJ/kg); QdotL = evaporator load; QdotH = condenser load; Wdotc = compressor power. In the last form, heat loss is positive out of the compressor.",
    "when": "Use for the source’s ammonia/vapor-compression problems when cycle-state enthalpies and/or compressor work are known. The state numbering must match the problem diagram.",
    "derivation": "Each heat-transfer rate across a steady-flow component is mass flow times the enthalpy change. For a compressor with heat lost to surroundings, the steady-flow energy balance is input work minus heat loss equals the refrigerant enthalpy rise.",
    "shortcut": "Cooling effect per kg = h1−h4; refrigerant flow = QdotL/(h1−h4); compressor power is flow × (h2−h1). Check the state labels on the source cycle.",
    "source": "Blue-Book-With-Solution-VIP.pdf — Problems 216, 218, 223, 224, 341; original PDF page(s) 64, 66, 96; extracted PDF page(s) 38, 40, 45, 46, 69.",
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=38"
  },
  {
    "category": "Refrigeration",
    "topic": "Refrigerant properties",
    "subject": "Refrigeration",
    "boardCategory": "PIPE",
    "sourceOrganization": "Blue Book — Air Conditioning / Refrigeration reviewer",
    "title": "Wet-refrigerant enthalpy from quality",
    "formula": "h = h_f + x h_{fg}",
    "variables": "h = specific enthalpy of a saturated mixture (kJ/kg); hf = saturated-liquid enthalpy; hfg = latent enthalpy of vaporization; x = vapor quality, from 0 to 1.",
    "when": "Use when refrigerant is a saturated liquid-vapor mixture and quality x is given or must be used to obtain its enthalpy.",
    "derivation": "A saturated mixture contains liquid mass fraction (1−x) and vapor mass fraction x. The mixture enthalpy is (1−x)hf + xhg, which rearranges to hf + x(hg−hf) = hf + xhfg.",
    "shortcut": "Use x as a fraction, not a percent. This relation does not apply to superheated vapor or compressed liquid.",
    "source": "Blue-Book-With-Solution-VIP.pdf — Problems 225; original PDF page(s) 67; extracted PDF page(s) 47.",
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=47"
  },
  {
    "category": "Refrigeration",
    "topic": "Compressor sizing",
    "subject": "Refrigeration",
    "boardCategory": "PIPE",
    "sourceOrganization": "Blue Book — Air Conditioning / Refrigeration reviewer",
    "title": "Compressor volumetric efficiency and displacement",
    "formula": "η_v = V̇_{actual}/V̇_{displacement};  V̇_{actual} = ṁ_r v_1;  V̇_{displacement} = (πD²/4)LNn_c;  D = √[4V̇_{displacement}/(πLNn_c)]",
    "variables": "ηv = volumetric efficiency as a fraction; Vdot_actual = actual suction-vapor volume flow; Vdot_displacement = compressor swept displacement rate; mdot_r = refrigerant flow; v1 = suction specific volume; D = cylinder bore; L = stroke; N = revolutions per unit time (keep time basis consistent); nc = number of cylinders for the single-acting source convention.",
    "when": "Use to link refrigerant mass flow, suction specific volume, volumetric efficiency and the compressor displacement required by the source problems.",
    "derivation": "Volumetric efficiency is actual suction volume admitted divided by theoretical swept volume. Since Vdot_actual = mdot × v1, required displacement is Vdot_actual/ηv. For a single-acting cylinder, swept volume per stroke is (πD²/4)L; multiply by cycles per unit time and the cylinder count, then rearrange for D when bore equals the stated stroke convention.",
    "shortcut": "Find mass flow from capacity/cooling effect, then suction-volume flow, then displacement by dividing by ηv. Match N’s time unit to the desired displacement-rate unit and check whether the compressor is single- or double-acting.",
    "source": "Blue-Book-With-Solution-VIP.pdf — Problems 219, 307, 346; original PDF page(s) 65, 87, 97; extracted PDF page(s) 41, 67, 74.",
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=41"
  },
  {
    "category": "Refrigeration",
    "topic": "Absorption systems",
    "subject": "Refrigeration",
    "boardCategory": "PIPE",
    "sourceOrganization": "Blue Book — Air Conditioning / Refrigeration reviewer",
    "title": "Absorber solution concentration relation (source method)",
    "formula": "n = (1 − x₂)/(x₁ − x₂) − 1",
    "variables": "x1 and x2 = solution concentrations written as fractions (for example, 35% = 0.35); n = ratio defined in the source problem, with no units.",
    "when": "Use only for the absorber material-balance problem whose concentration and flow basis match the source solution.",
    "derivation": "The reviewer applies a solution mass balance using the change in ammonia concentration between the two solution strengths. This is a source-specific rearranged balance; the symbol n must retain the source problem’s definition.",
    "shortcut": "Convert percentage concentrations to decimals before substitution. Do not reuse this relation for a different definition of flow ratio without checking the original source.",
    "source": "Blue-Book-With-Solution-VIP.pdf — Problems 126; original PDF page(s) 39; extracted PDF page(s) 18.",
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=18"
  },
  {
    "category": "Refrigeration",
    "topic": "Heat pump performance",
    "subject": "Refrigeration",
    "boardCategory": "PIPE",
    "sourceOrganization": "Blue Book — Air Conditioning / Refrigeration reviewer",
    "title": "Heat-pump performance factor and electricity savings",
    "formula": "PF = Q̇_H/Ẇ;  Ẇ = Q̇_H/PF;  E_{HP} = E_{resistance}/PF",
    "variables": "PF = heating performance factor; QdotH = useful heating rate; Wdot = electric input power; EHP = electricity used by heat pump for the same heating requirement.",
    "when": "Use to compare an electric-resistance heater with a heat pump delivering the same amount of heat, or to calculate required heat-pump input.",
    "derivation": "Performance factor is useful heat delivered divided by electrical energy input. For an equivalent heating requirement, a heat pump with PF uses roughly 1/PF of the electrical energy of resistance heating.",
    "shortcut": "For energy cost savings, multiply the resistance-heater energy by (1−1/PF), then by the electricity price. Use this only when both cases deliver equal heat.",
    "source": "Blue-Book-With-Solution-VIP.pdf — Problems 215; original PDF page(s) 63; extracted PDF page(s) 37.",
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=37"
  },
  {
    "category": "Refrigeration",
    "topic": "Condenser load",
    "subject": "Refrigeration",
    "boardCategory": "PIPE",
    "sourceOrganization": "Blue Book — Air Conditioning / Refrigeration reviewer",
    "title": "Condenser heat-rejection factor (reviewer method)",
    "formula": "Q̇_H = F_{rejection} Q̇_L",
    "variables": "QdotH = condenser heat-rejection rate; QdotL = evaporator cooling capacity; Frejection = stated source heat-rejection factor.",
    "when": "Use only when the problem gives a heat-rejection factor and explicitly asks for the reviewer’s estimated condenser load.",
    "derivation": "The factor is a source-provided multiplier that estimates condenser load relative to refrigeration capacity. It is an empirical shortcut, not a replacement for QdotH = QdotL + Wdot when compressor input is known.",
    "shortcut": "Multiply the stated cooling capacity by the given factor and preserve the same heat-rate units.",
    "source": "Blue-Book-With-Solution-VIP.pdf — Problems 343; original PDF page(s) 96; extracted PDF page(s) 71.",
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=71"
  },
  {
    "category": "Refrigeration",
    "topic": "Batch cooling",
    "subject": "Refrigeration",
    "boardCategory": "PIPE",
    "sourceOrganization": "Blue Book — Air Conditioning / Refrigeration reviewer",
    "title": "Cooling time from sensible load and refrigeration rate",
    "formula": "Q = m c_p ΔT;  t = Q/Q̇_L",
    "variables": "Q = heat removed (kJ); m = product mass (kg); cp = specific heat (kJ/(kg·K)); ΔT = temperature drop; QdotL = average refrigeration rate (kJ/s or kW); t = time in compatible units.",
    "when": "Use for a batch cooled over time when a sensible temperature change is assumed and the average cooling capacity is known.",
    "derivation": "The sensible heat to remove is mass times specific heat times temperature change. Time equals total energy removed divided by average heat-removal rate.",
    "shortcut": "Make time units consistent: kJ divided by kJ/s gives seconds; kWh divided by kW gives hours. Add latent heat if the product freezes.",
    "source": "Blue-Book-With-Solution-VIP.pdf — Problems 153, 210; original PDF page(s) 46, 62; extracted PDF page(s) 24, 32.",
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=24"
  },
  {
    "category": "Cold Storage & Products",
    "topic": "Freezing loads",
    "subject": "Cold Storage & Products",
    "boardCategory": "PIPE",
    "sourceOrganization": "Blue Book — Air Conditioning / Refrigeration reviewer",
    "title": "Product cooling and freezing load in stages",
    "formula": "Q = m[c_{p,+}(T_i − T_f) + h_f + c_{p,−}(T_f − T_o)] + m_b c_b(T_i − T_o);  Q̇ = Q/Δt",
    "variables": "m = product mass; Ti = initial temperature; Tf = product freezing temperature; To = final temperature below freezing; cp,+ and cp,− = specific heats above and below freezing; hf = latent heat of freezing per kg; mb and cb = packaging mass and specific heat; Δt = freezing time.",
    "when": "Use for food/product freezing problems that cool above freezing, remove latent heat during the phase change, then cool below freezing. Add packaging load only when the package is included.",
    "derivation": "The load is the sum of sensible cooling above the freezing point, latent heat removed during freezing, sensible cooling below freezing, and (if stated) sensible cooling of the package. Divide by the allowed time for capacity.",
    "shortcut": "Use three product terms: above-freezing sensible + latent + below-freezing sensible. Add package load separately and include any stated loss factor only after computing the product load.",
    "source": "Blue-Book-With-Solution-VIP.pdf — Problems 177, 301, 303, 306; original PDF page(s) 52, 84, 85, 86; extracted PDF page(s) 27, 61, 63, 66.",
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=27"
  },
  {
    "category": "Cold Storage & Products",
    "topic": "Ice and water",
    "subject": "Cold Storage & Products",
    "boardCategory": "PIPE",
    "sourceOrganization": "Blue Book — Air Conditioning / Refrigeration reviewer",
    "title": "Cooling water with melting ice",
    "formula": "ṁ_w c_{p,w}(T_1 − T_2) = ṁ_{ice} h_f",
    "variables": "mdotw = water mass flow; cp,w = water specific heat; T1 and T2 = water inlet and outlet temperatures; mdotice = ice melt rate; hf = latent heat of fusion.",
    "when": "Use when water is cooled by ice melting at 0°C and the source neglects ice subcooling and warming of meltwater.",
    "derivation": "Heat lost by the water equals the latent heat absorbed by the melting ice. If the ice starts below 0°C or meltwater leaves above 0°C, include those additional sensible-heat terms.",
    "shortcut": "Keep both sides in the same heat-rate units. For colder ice or warmer meltwater, include sensible heating before/after fusion.",
    "source": "Blue-Book-With-Solution-VIP.pdf — Problems 121, 342; original PDF page(s) 37, 96; extracted PDF page(s) 16, 70.",
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=16"
  },
  {
    "category": "Air Conditioning",
    "topic": "Room cooling loads",
    "subject": "Air Conditioning",
    "boardCategory": "PIPE",
    "sourceOrganization": "Blue Book — Air Conditioning / Refrigeration reviewer",
    "title": "Room cooling load and required unit count",
    "formula": "Q̇_{total} = Q̇_{people} + Q̇_{lights} + Q̇_{envelope};  N = ceil(Q̇_{total}/Q̇_{unit})",
    "variables": "Qdot_total = total room heat gain; people = occupants; lights = lighting/appliance gain; envelope = wall/window solar and transmission gain; Qdot_unit = cooling capacity per unit; N = whole number of units.",
    "when": "Use for simple room-sizing questions where occupant, lighting and building-envelope loads are supplied and the capacity of one air conditioner is known.",
    "derivation": "At steady room temperature, the cooling system must remove the sum of the heat gains. Divide by the cooling capacity per unit and round up because a fractional unit cannot meet the design load.",
    "shortcut": "Convert all loads to the same unit (for example, kW or kJ/hr), add them, divide by unit capacity and round up.",
    "source": "Blue-Book-With-Solution-VIP.pdf — Problems 179; original PDF page(s) 53; extracted PDF page(s) 28.",
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=28"
  },
  {
    "category": "Air Conditioning",
    "topic": "Human heat gain",
    "subject": "Air Conditioning",
    "boardCategory": "PIPE",
    "sourceOrganization": "Blue Book — Air Conditioning / Refrigeration reviewer",
    "title": "Combined convection and thermal radiation",
    "formula": "Q̇ = hA(T_s − T_∞) + εσA(T_s⁴ − T_{sur}⁴)",
    "variables": "Qdot = total heat-transfer rate (W); h = convection coefficient (W/(m²·K)); A = exposed area (m²); Ts = surface temperature; T∞ = air temperature; Tsur = surrounding-surface temperature; ε = emissivity; σ = Stefan–Boltzmann constant.",
    "when": "Use when both convection to room air and thermal radiation to surrounding surfaces contribute to a body or surface heat loss.",
    "derivation": "Convection is hA(Ts−T∞). Radiation to large surroundings is εσA(Ts⁴−Tsur⁴). Add the rates when both mechanisms occur simultaneously.",
    "shortcut": "Use kelvin for the fourth-power radiation term. If only convection is requested, do not add radiation; if both are requested, do not omit either term.",
    "source": "Blue-Book-With-Solution-VIP.pdf — Problems 171; original PDF page(s) 51; extracted PDF page(s) 26.",
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=26"
  },
  {
    "category": "Air Conditioning",
    "topic": "Room heat gain",
    "subject": "Air Conditioning",
    "boardCategory": "PIPE",
    "sourceOrganization": "Blue Book — Air Conditioning / Refrigeration reviewer",
    "title": "Fan heat in a sealed, rigid room",
    "formula": "P Δt = m c_v(T_2 − T_1);  m = PV/(RT)",
    "variables": "P = fan electrical power converted to room internal energy (W); Δt = elapsed time (s); m = room-air mass; cv = constant-volume specific heat; T1/T2 = absolute initial/final air temperatures; V = room volume; R = specific gas constant.",
    "when": "Use for the source’s sealed-room idealization when all fan electrical work becomes internal energy of the air and wall/window heat transfer is neglected.",
    "derivation": "For a sealed rigid room, boundary work is zero. Under the source assumptions, electrical energy input equals the rise in internal energy, ΔU = m cv ΔT. Obtain mass from the ideal-gas relation using absolute pressure and temperature.",
    "shortcut": "Convert hours to seconds before using watts; compute air mass from PV= mRT, then solve for ΔT. This idealization does not describe a normal ventilated room.",
    "source": "Blue-Book-With-Solution-VIP.pdf — Problems 181, 195; original PDF page(s) 54, 58; extracted PDF page(s) 29, 31.",
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=29"
  },
  {
    "category": "Air Conditioning",
    "topic": "Fans & air distribution",
    "subject": "Air Conditioning",
    "boardCategory": "PIPE",
    "sourceOrganization": "Blue Book — Air Conditioning / Refrigeration reviewer",
    "title": "Fan head, fluid power and affinity laws",
    "formula": "H_t = H_s + V²/(2g);  P_{air} = ρg Q̇ H_t;  Q̇₂/Q̇₁ = N₂/N₁;  p₂/p₁ = (N₂/N₁)²;  Q̇ ∝ N D³",
    "variables": "Ht = total head (m of fluid); Hs = static head; V = air velocity (m/s); g = 9.81 m/s²; Pair = ideal fluid power (W); ρ = air density; Qdot = volume flow; N = fan speed; D = fan diameter; p = fan pressure for same fan diameter.",
    "when": "Use to calculate velocity head or ideal fluid power, or estimate flow/pressure changes for geometrically similar fan operation under the source’s affinity-law assumptions.",
    "derivation": "Total head includes static and velocity head. Ideal fluid power is density × gravity × volumetric flow × head. For a given fan diameter, flow scales with speed and pressure scales with speed squared; with geometric similarity, flow also scales with D³.",
    "shortcut": "For the same fan and diameter, use the flow ratio to find the speed ratio first, then square that ratio for pressure. These are ideal affinity relationships, not a substitute for the fan curve.",
    "source": "Blue-Book-With-Solution-VIP.pdf — Problems 131, 132, 184, 273; original PDF page(s) 40, 55, 77; extracted PDF page(s) 20, 21, 30, 53.",
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=20"
  },
  {
    "category": "Air Conditioning",
    "topic": "Cooling coils",
    "subject": "Air Conditioning",
    "boardCategory": "PIPE",
    "sourceOrganization": "Blue Book — Air Conditioning / Refrigeration reviewer",
    "title": "Cooling-coil face area from air flow",
    "formula": "A_{face} = Q̇_v/V_{face}",
    "variables": "Aface = coil frontal area (ft² or m²); Qdotv = air volumetric flow rate (ft³/min or m³/s); Vface = desired face velocity (ft/min or m/s). Use matching length/time units.",
    "when": "Use when supply airflow and an allowable/required coil face velocity are given.",
    "derivation": "Average velocity is volumetric flow divided by cross-sectional area. Rearranging Vface = Qdotv/Aface gives Aface = Qdotv/Vface.",
    "shortcut": "Keep flow and velocity units on matching time bases—for example, ft³/min divided by ft/min gives ft².",
    "source": "Blue-Book-With-Solution-VIP.pdf — Problems 350; original PDF page(s) 98; extracted PDF page(s) 78.",
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=78"
  },
  {
    "category": "Air Conditioning",
    "topic": "Temperature units",
    "subject": "Air Conditioning",
    "boardCategory": "PIPE",
    "sourceOrganization": "Blue Book — Air Conditioning / Refrigeration reviewer",
    "title": "Convert temperature differences between Celsius and Fahrenheit",
    "formula": "ΔT_C = (5/9) ΔT_F;  ΔT_F = (9/5) ΔT_C",
    "variables": "ΔTC = temperature difference in Celsius degrees; ΔTF = temperature difference in Fahrenheit degrees.",
    "when": "Use for temperature differences in heat-transfer equations. This scale-factor conversion is for differences, not absolute temperatures.",
    "derivation": "Absolute conversion is °C = (°F−32)×5/9. When subtracting two temperatures, the 32° offset cancels, leaving the 5/9 scale factor.",
    "shortcut": "For a temperature interval only, do not subtract 32. Convert absolute temperatures with the full equation when required.",
    "source": "Blue-Book-With-Solution-VIP.pdf — Problems 256; original PDF page(s) 73; extracted PDF page(s) 52.",
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=52"
  },
  {
    "category": "Air Conditioning",
    "topic": "Air mixing",
    "subject": "Air Conditioning",
    "boardCategory": "PIPE",
    "sourceOrganization": "Blue Book — Air Conditioning / Refrigeration reviewer",
    "title": "Sensible mixing temperature of two air streams",
    "formula": "ṁ_1 + ṁ_2 = ṁ_3;  T_3 = (ṁ_1 T_1 + ṁ_2 T_2)/(ṁ_1 + ṁ_2)",
    "variables": "T1/T2 = incoming stream temperatures; T3 = mixed temperature; mdot1/mdot2 = mass flow rates. Temperature may be °C or °F if all are on the same scale and cp is effectively the same.",
    "when": "Use for adiabatic mixing when only sensible temperature mixing is intended and both streams have the same specific heat with no moisture/phase effects.",
    "derivation": "An energy balance equates the sum of inlet sensible-energy rates to the outlet sensible-energy rate. With equal specific heats, cp cancels, giving the mass-weighted temperature.",
    "shortcut": "For humid air with meaningful humidity differences, use the enthalpy balance instead: h3=(mdot1h1+mdot2h2)/(mdot1+mdot2).",
    "source": "Blue-Book-With-Solution-VIP.pdf — Problems 299; original PDF page(s) 84; extracted PDF page(s) 59.",
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=59"
  },
  {
    "category": "Air Conditioning",
    "topic": "Psychrometrics",
    "subject": "Air Conditioning",
    "boardCategory": "PIPE",
    "sourceOrganization": "Blue Book — Air Conditioning / Refrigeration reviewer",
    "title": "Specific volume of dry air",
    "formula": "v_a = R_a T/P_a",
    "variables": "va = dry-air specific volume (m³/kg dry air); Ra ≈ 287 J/(kg·K); T = absolute temperature (K); Pa = dry-air partial pressure (Pa, or compatible units).",
    "when": "Use when dry-air gas constant, absolute temperature, and dry-air partial pressure are known. For moist air use the appropriate moist-air relation and vapor partial pressure.",
    "derivation": "Apply the ideal-gas relation to the dry-air component: Pa va = Ra T, then rearrange for specific volume.",
    "shortcut": "Use kelvin and pressure in pascals when Ra is in J/(kg·K); J = Pa·m³.",
    "source": "Blue-Book-With-Solution-VIP.pdf — Problems 451; original PDF page(s) 137; extracted PDF page(s) 84.",
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=84"
  },
  {
    "category": "Cold Storage & Products",
    "topic": "Insulation heat transfer",
    "subject": "Cold Storage & Products",
    "boardCategory": "PIPE",
    "sourceOrganization": "Blue Book — Air Conditioning / Refrigeration reviewer",
    "title": "Heat leak through insulation and composite flat walls",
    "formula": "Q̇ = kAΔT/L;  Q̇ = ΔT/[Σ(L_i/(k_i A))]",
    "variables": "Qdot = steady heat-transfer rate (W); k = thermal conductivity (W/(m·K)); A = area normal to heat flow (m²); ΔT = temperature difference (K); L = thickness (m). For composite layers, Li and ki are each layer’s thickness and conductivity.",
    "when": "Use for steady one-dimensional conduction through a single insulation layer or flat layers in series with the same area and negligible contact resistance.",
    "derivation": "For a single layer, conduction resistance is L/(kA) and heat rate is ΔT/R. For layers in series, add their thermal resistances and divide the overall temperature difference by total resistance.",
    "shortcut": "Use the area actually exposed to the temperature difference, include walls/ceiling/floor only as specified, and convert the rate to per hour if energy per hour is requested.",
    "source": "Blue-Book-With-Solution-VIP.pdf — Problems 356; original PDF page(s) 101; extracted PDF page(s) 80.",
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=80"
  },
  {
    "category": "Refrigeration",
    "topic": "Cooling capacity from air flow",
    "subject": "Refrigeration",
    "boardCategory": "PIPE",
    "sourceOrganization": "Blue Book — Air Conditioning / Refrigeration reviewer",
    "title": "Sensible cooling capacity from airflow (imperial units)",
    "formula": "Q̇ = ṁ c_p ΔT;  TR = Q̇/(12,000 Btu/hr)",
    "variables": "Qdot = sensible heat rate (Btu/hr); mdot = air mass flow rate; cp = air specific heat; ΔT = entering minus leaving temperature (°F difference); TR = tons of refrigeration.",
    "when": "Use for a dry-bulb sensible-cooling calculation when an air mass flow is available; convert the volumetric flow to mass flow if only CFM is given.",
    "derivation": "Sensible heat transfer rate equals mass flow times specific heat times the temperature drop. One refrigeration ton is approximately 12,000 Btu/hr.",
    "shortcut": "Do not multiply CFM directly by cp unless using a matching air-density shortcut. Convert volumetric flow to mass flow or use the specific shortcut explicitly stated in the question.",
    "source": "Blue-Book-With-Solution-VIP.pdf — Problems 349; original PDF page(s) 98; extracted PDF page(s) 77.",
    "sourceFile": "source-material/Aircon_Refrigeration_Problems_Extracted(1).pdf#page=77"
  }
];

// Normalize common plain-text / LaTeX-style math tokens for reliable offline display.
// This deliberately uses textContent (not innerHTML) so formula text remains safe.
function normalizeFormulaNotation(value) {
  let text = String(value ?? '');
  const commands = {
    '\\varepsilon': 'ε', '\\epsilon': 'ε', '\\sigma': 'σ', '\\rho': 'ρ',
    '\\mu': 'μ', '\\gamma': 'γ', '\\Delta': 'Δ', '\\delta': 'δ',
    '\\lambda': 'λ', '\\omega': 'ω', '\\Omega': 'Ω', '\\pi': 'π',
    '\\theta': 'θ', '\\eta': 'η', '\\alpha': 'α', '\\beta': 'β',
    '\\dot{Q}': 'Q̇', '\\dot{q}': 'q̇', '\\dot{m}': 'ṁ',
    '\\times': '×', '\\cdot': '·', '\\rightarrow': '→', '\\approx': '≈',
    '\\leq': '≤', '\\geq': '≥', '\\infty': '∞'
  };
  for (const [command, symbol] of Object.entries(commands)) {
    text = text.split(command).join(symbol);
  }
  // Also repair the literal word shown by older formula entries/screenshots.
  text = text.replace(/\bvarepsilon\b/g, 'ε').replace(/\bepsilon\b/g, 'ε');
  return text;
}

function formulaLinkQuestions(item) {
  const questions = window.getEngineeringReviewQuestions?.() || [];
  const normalize = value => String(value || '').toLowerCase().normalize('NFKD')
    .replace(/\\[a-z]+\{([^}]*)\}/g, '$1').replace(/[^a-z0-9]+/g, ' ').trim().replace(/\s+/g, ' ');
  const formulaKey = normalize(item.formula);
  const titleWords = normalize(`${item.title || ''} ${item.topic || ''}`)
    .split(' ').filter(w => w.length > 3 && !['formula','general','source','method','from','with','and','the','air','conditioning'].includes(w));
  const sourceText = `${item.source || ''} ${item.sourceFile || ''}`;
  const problemNums = new Set();
  // Parse explicit source problem references such as "Problems 23, 25, 304".
  for (const match of sourceText.matchAll(/problem(?:s)?\s*([0-9]+(?:\s*(?:,|and|&)\s*[0-9]+)*)/gi)) {
    for (const n of match[1].matchAll(/\d+/g)) problemNums.add(n[0]);
  }
  return questions.map(question => {
    const qText = `${question.prompt || ''} ${question.category || ''} ${question.subject || ''} ${question.formula || ''} ${question.shortcutFormula || ''}`;
    const qNorm = normalize(qText);
    const qFormula = normalize(`${question.formula || ''} ${question.shortcutFormula || ''}`);
    let score = 0, reason = '';
    const id = String(question.id || '');
    const idMatch = id.match(/(?:bluebook-aircon|bluebook|ipe-aircon)[-_]?0*(\d+)/i);
    const categoryMatch = String(question.category || '').match(/(?:problem|no\.?|#)\s*0*(\d+)/i);
    const promptProblem = String(question.prompt || '').match(/^\s*(?:problem\s*)?0*(\d+)\s*[.)]/i);
    const qNums = [idMatch?.[1], categoryMatch?.[1], promptProblem?.[1]].filter(Boolean);
    const sourceProblemMatch = qNums.some(n => { const sameNumber = problemNums.has(String(Number(n))); const sameSource = (/^(bluebook-aircon-|bluebook-)/i.test(id) && /Blue-Book|Blue Book/i.test(sourceText)) || (/^ipe-aircon-/i.test(id) && /IPE/i.test(sourceText)); return sameNumber && sameSource; });
    if (sourceProblemMatch) { score += 12; reason = 'Matches a problem number cited by this formula’s source.'; }
    if (formulaKey && qFormula && (qFormula.includes(formulaKey) || formulaKey.includes(qFormula)) && Math.min(qFormula.length,formulaKey.length) > 8) { score += 10; reason = 'Formula text matches the saved question relation.'; }
    const qWords = new Set(qNorm.split(' '));
    const overlap = titleWords.filter(word => qWords.has(word)).length;
    if (overlap >= 2) { score += Math.min(5, overlap); if (!reason) reason = 'Matches the formula topic and question wording.'; }
    if (item.subject && question.subject && normalize(item.subject) === normalize(question.subject)) score += 1;
    // Same subject alone is not a meaningful formula-to-question connection.
    if (score < 4) return null;
    if (!score) return null;
    if (!reason) reason = 'Related topic match; confirm the exact relation in the worked solution.';
    return {question, score, reason};
  }).filter(Boolean).sort((a,b) => b.score-a.score || String(a.question.category).localeCompare(String(b.question.category)))
    .slice(0, 8).map(({question, reason}) => ({question, reason}));
}

function findFormulaQuestions(item) {
  return formulaLinkQuestions(item);
}

(function initFormulaBook(){
  const root = document.querySelector('#formula-book');
  if (!root) return;
  const search = root.querySelector('#formula-search');
  const tabs = root.querySelector('#formula-category-tabs');
  const list = root.querySelector('#formula-results');
  const count = root.querySelector('#formula-count');
  let activeCategory = 'All';
  const categories = ['All', ...new Set(FORMULA_BOOK.map(item => item.category))];
  categories.forEach(category => {
    const button = document.createElement('button'); button.type = 'button'; button.className = 'formula-category-tab'; button.textContent = category; button.setAttribute('aria-pressed', String(category === activeCategory));
    button.addEventListener('click', () => { activeCategory = category; tabs.querySelectorAll('button').forEach(b => b.setAttribute('aria-pressed', String(b.textContent === activeCategory))); render(); });
    tabs.append(button);
  });
  function render(){
    const query = search.value.trim().toLowerCase();
    const results = FORMULA_BOOK.filter(item => (activeCategory === 'All' || item.category === activeCategory) && (!query || [item.category,item.topic,item.title,item.formula,item.variables,item.when,item.derivation,item.shortcut,item.source,item.subject,item.boardCategory,item.sourceOrganization].join(' ').toLowerCase().includes(query)));
    list.replaceChildren(); count.textContent = `${results.length} formula${results.length===1?'':'s'}`;
    if (!results.length){ const empty=document.createElement('p'); empty.className='muted'; empty.textContent='No formulas found. Try a broader search term or choose All.'; list.append(empty); return; }
    results.forEach(item => {
      const card=document.createElement('article'); card.className='formula-card';
      const top=document.createElement('div'); top.className='formula-card-top';
      const category=document.createElement('span'); category.className='pill formula-topic-pill'; category.textContent=item.topic || item.category;
      const title=document.createElement('h3'); title.textContent=item.title; top.append(category,title);
      const equation=document.createElement('div'); equation.className='formula-equation'; equation.setAttribute('aria-label','Formula equation');
      normalizeFormulaNotation(item.formula).split(/;\s*/).map(part=>part.trim()).filter(Boolean).forEach(part=>{const line=document.createElement('div');line.className='formula-equation-line';if (typeof window.renderMathInto === 'function') window.renderMathInto(line, part); else line.textContent=part;equation.append(line);});
      card.append(top,equation);
      if (item.source) {
        const source = document.createElement('p'); source.className = 'formula-source muted small';
        source.append(document.createTextNode('Source: '));
        if (item.sourceFile) {
          const sourceAnchor = document.createElement('a'); sourceAnchor.href = item.sourceFile; sourceAnchor.target = '_blank'; sourceAnchor.rel = 'noopener noreferrer'; sourceAnchor.textContent = item.source; source.append(sourceAnchor);
        } else source.append(document.createTextNode(item.source));
        card.append(source);
      }
      [['Symbols and units',item.variables],['When to use it',item.when],['Derivation / reasoning',item.derivation],['Exam shortcut',item.shortcut]].forEach(([heading,content])=>{const details=document.createElement('details'); details.className='formula-details'; if(heading === 'Symbols and units') details.open = true; const summary=document.createElement('summary'); summary.textContent=heading; if(heading === 'Symbols and units'){const parts=normalizeFormulaNotation(content).split(/;\s*/).map(s=>s.trim()).filter(Boolean); if(parts.length>1){const ul=document.createElement('ul');ul.className='formula-symbol-list';parts.forEach(part=>{const li=document.createElement('li'); if (typeof window.renderMathInto === 'function') window.renderMathInto(li, part); else li.textContent=part; ul.append(li);});details.append(summary,ul);}else{const p=document.createElement('p');if (typeof window.renderMathInto === 'function') window.renderMathInto(p, heading === 'Derivation / reasoning' ? normalizeFormulaNotation(content) : content); else p.textContent=heading === 'Derivation / reasoning' ? normalizeFormulaNotation(content) : content;details.append(summary,p);}}else{const p=document.createElement('p');if (typeof window.renderMathInto === 'function') window.renderMathInto(p, heading === 'Derivation / reasoning' ? normalizeFormulaNotation(content) : content); else p.textContent=heading === 'Derivation / reasoning' ? normalizeFormulaNotation(content) : content;details.append(summary,p);} card.append(details);});
      // Step 2: connect each formula to existing questions using exact formula text,
      // source problem references, and conservative topic/category matches.
      const linked = findFormulaQuestions(item);
      const links = document.createElement('section');
      links.className = 'formula-question-links';
      const linksHeading = document.createElement('h4');
      linksHeading.textContent = `Related questions (${linked.length})`;
      links.append(linksHeading);
      const linkIntro = document.createElement('p');
      linkIntro.className = 'muted small';
      linkIntro.textContent = 'Open an existing question that uses this relation. Source-matched links are shown first; broader topic matches are labelled.';
      links.append(linkIntro);
      if (!linked.length) {
        const empty = document.createElement('p'); empty.className = 'muted small';
        empty.textContent = 'No confident question match yet. Search the Question Library by formula topic or source problem number.';
        links.append(empty);
      } else {
        const linkList = document.createElement('div'); linkList.className = 'formula-question-link-list';
        linked.forEach(({question, reason}) => {
          const row = document.createElement('article'); row.className = 'formula-question-link';
          const title = document.createElement('strong'); title.textContent = question.category || question.subject || 'Engineering question';
          const reasonEl = document.createElement('span'); reasonEl.className = 'muted tiny'; reasonEl.textContent = reason;
          const prompt = document.createElement('p'); prompt.textContent = question.prompt || '';
          const button = document.createElement('button'); button.type = 'button';
          button.className = 'button button-secondary button-small'; button.textContent = 'Practice question →';
          button.addEventListener('click', () => {
            const opened = window.openEngineeringReviewQuestion?.(question.id);
            if (opened) {
              document.querySelector('.nav-button[data-view="practice"]')?.click();
              document.querySelector('.quiz-panel')?.scrollIntoView({behavior:'smooth', block:'start'});
            }
          });
          row.append(title, reasonEl, prompt, button); linkList.append(row);
        });
        links.append(linkList);
      }
      card.append(links);
      list.append(card);
    });
  }
  search.addEventListener('input', render);
  render();
})();
window.FORMULA_BOOK = FORMULA_BOOK;
