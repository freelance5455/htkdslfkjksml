/* JOSTECH — ÉCRANS PROFIL & ADMIN (ALLÈGE INDEX.HTML) */
(function () {
  var vp = document.getElementById("view-profile");
  if (vp) {
    vp.innerHTML = `
      <div id="auth-forms-wrap">
        <h2 class="metallic-text" style="margin-bottom:6px;">Espace Compte JOSTECH</h2>
        <p class="section-sub">Connectez-vous pour accéder à vos favoris, certificats ou à l'espace administrateur.</p>
        <div class="segmented-control" style="grid-template-columns:1fr 1fr; margin-bottom:16px;">
          <button id="auth-tab-login" class="active" onclick="switchAuthTab('login')">Connexion</button>
          <button id="auth-tab-register" onclick="switchAuthTab('register')">Inscription</button>
        </div>
        <form id="form-login" class="settings-card" onsubmit="handleLogin(event)">
          <label class="field-lbl">Adresse e-mail</label><input id="login-email" type="email" class="field-input" required placeholder="nom@jostech.edu" />
          <label class="field-lbl">Mot de passe</label><input id="login-pass" type="password" class="field-input" required placeholder="••••••" />
          <button type="submit" class="btn-primary full-width">Se connecter</button>
          <p class="setting-desc" style="margin-top:12px; margin-bottom:0;"><strong>Test Admin :</strong> <code>admin@jostech.edu</code> / <code>jostech2026</code></p>
        </form>
        <form id="form-register" class="settings-card" style="display:none;" onsubmit="handleRegister(event)">
          <label class="field-lbl">Nom complet</label><input id="reg-name" type="text" class="field-input" required placeholder="Ex: Mivumbi Jos..." />
          <label class="field-lbl">Adresse e-mail</label><input id="reg-email" type="email" class="field-input" required placeholder="etudiant@jostech.edu" />
          <label class="field-lbl">Mot de passe (6 car. min.)</label><input id="reg-pass" type="password" class="field-input" minlength="6" required placeholder="••••••" />
          <label class="legal-check"><input id="reg-legal" type="checkbox" required /><span>J'accepte les <a href="#" onclick="openLegalModal('cgu');return false;">CGU</a> et la <a href="#" onclick="openLegalModal('privacy');return false;">Confidentialité</a>.</span></label>
          <button type="submit" class="btn-primary full-width">Créer mon compte</button>
        </form>
      </div>
      <div id="profile-logged-wrap" style="display:none;">
        <div class="hero-banner">
          <span id="prof-role-badge" class="pill-badge"></span>
          <h2 id="prof-name" class="metallic-text" style="margin-top:8px;"></h2>
          <p id="prof-email" class="hero-desc" style="margin-bottom:14px;"></p>
          <div class="hero-actions">
            <button id="btn-open-admin" class="btn-primary" style="display:none;" onclick="navigateTo('admin')">⚙ Espace Administrateur</button>
            <button class="btn-secondary" onclick="logoutUser()">Se déconnecter</button>
          </div>
        </div>
        <div class="section-block"><div class="section-header"><h3>Mes leçons favorites (★)</h3></div><div id="profile-favorites-list" class="recent-list"></div></div>
        <div class="section-block"><div class="section-header"><h3>Mes Certificats JOSTECH</h3></div><div id="profile-certificates-list" class="recent-list"></div></div>
      </div>`;
  }

  var va = document.getElementById("view-admin");
  if (va) {
    va.innerHTML = `
      <button class="back-btn" onclick="navigateTo('profile')">← Retour au profil</button>
      <h2 class="metallic-text" style="margin-bottom:12px;">Espace Administrateur</h2>
      <div class="stats-grid" style="margin-bottom:18px;">
        <div class="stat-card"><span id="adm-stat-users" class="stat-value metallic-text">0</span><span class="stat-label">Comptes</span></div>
        <div class="stat-card"><span id="adm-stat-lessons" class="stat-value metallic-text">0</span><span class="stat-label">Leçons</span></div>
        <div class="stat-card"><span id="adm-stat-quizzes" class="stat-value metallic-text">0</span><span class="stat-label">Quiz</span></div>
        <div class="stat-card"><span id="adm-stat-reports" class="stat-value metallic-text">0</span><span class="stat-label">Signalements</span></div>
      </div>
      <div id="admin-tabs" class="segmented-control" style="margin-bottom:16px;">
        <button data-admin-tab="lesson" class="active" onclick="switchAdminTab('lesson')">+ Leçon</button>
        <button data-admin-tab="quiz" onclick="switchAdminTab('quiz')">+ Quiz /20</button>
        <button data-admin-tab="manage" onclick="switchAdminTab('manage')">Gestion</button>
      </div>
      <form id="admin-panel-lesson" class="admin-panel settings-card" onsubmit="handleAdminCreateLesson(event)">
        <h3>Publier une nouvelle leçon</h3><p class="setting-desc">Disponible immédiatement sans toucher au code.</p>
        <label class="field-lbl">Discipline</label><select id="adm-lesson-disc" class="field-input"></select>
        <label class="field-lbl">Niveau</label><select id="adm-lesson-lvl" class="field-input"><option value="1">Niveau 1 — Fondamental</option><option value="2">Niveau 2 — Intermédiaire</option><option value="3">Niveau 3 — Universitaire</option></select>
        <label class="field-lbl">Chapitre</label><input id="adm-lesson-chap" type="text" class="field-input" placeholder="Chapitre 1 : Introduction" />
        <label class="field-lbl">Titre</label><input id="adm-lesson-title" type="text" class="field-input" required placeholder="Leçon 1 : ..." />
        <label class="field-lbl">Durée</label><input id="adm-lesson-dur" type="text" class="field-input" placeholder="30 min" />
        <label class="field-lbl">Objectifs (1/ligne)</label><textarea id="adm-lesson-obj" class="field-input" rows="2"></textarea>
        <label class="field-lbl">Contenu détaillé</label><textarea id="adm-lesson-theory" class="field-input" rows="4" required></textarea>
        <label class="field-lbl">Bloc Code (optionnel)</label><textarea id="adm-lesson-code" class="field-input" rows="2"></textarea>
        <label class="field-lbl">Exercice (optionnel)</label><textarea id="adm-lesson-exq" class="field-input" rows="2"></textarea>
        <label class="field-lbl">Corrigé (optionnel)</label><textarea id="adm-lesson-exs" class="field-input" rows="2"></textarea>
        <button type="submit" class="btn-primary full-width">Publier la leçon</button>
      </form>
      <div id="admin-panel-quiz" class="admin-panel settings-card" style="display:none;">
        <h3>Créer un Quiz / Examen</h3>
        <label class="field-lbl">Discipline</label><select id="adm-quiz-disc" class="field-input"></select>
        <label class="field-lbl">Type</label><select id="adm-quiz-mode" class="field-input"><option value="training">Entraînement</option><option value="exam">Examen Officiel</option></select>
        <label class="field-lbl">Titre</label><input id="adm-quiz-title" type="text" class="field-input" placeholder="Quiz Réseaux" />
        <label class="field-lbl">Durée (min)</label><input id="adm-quiz-dur" type="number" class="field-input" value="10" />
        <hr style="border:0; border-top:1px solid var(--border-metal); margin:12px 0;" />
        <h4>Ajouter une question</h4>
        <label class="field-lbl">Question</label><input id="adm-q-text" type="text" class="field-input" />
        <label class="field-lbl">Choix (1/ligne)</label><textarea id="adm-q-opts" class="field-input" rows="3" placeholder="Réponse 1&#10;Réponse 2&#10;Réponse 3"></textarea>
        <label class="field-lbl">N° bonne réponse</label><input id="adm-q-right" type="number" class="field-input" value="1" min="1" />
        <label class="field-lbl">Explication</label><input id="adm-q-expl" type="text" class="field-input" />
        <button type="button" class="btn-secondary full-width" style="margin-bottom:10px;" onclick="addDraftQuestion()">+ Ajouter question</button>
        <div id="adm-draft-questions"></div>
        <button type="button" class="btn-primary full-width" onclick="publishAdminQuiz()">Publier l'évaluation</button>
      </div>
      <div id="admin-panel-manage" class="admin-panel" style="display:none;">
        <div class="settings-card"><h3>Sauvegarde JSON</h3><p class="setting-desc">Copier les cours et quiz créés.</p><button type="button" class="btn-primary full-width" onclick="exportAdminBackup()">Exporter JSON</button></div>
        <h3 style="margin:12px 0 8px;">Signalements</h3><div id="adm-reports-list"></div>
        <h3 style="margin:16px 0 8px;">Utilisateurs</h3><div id="adm-users-list" class="recent-list"></div>
      </div>`;
  }
})();