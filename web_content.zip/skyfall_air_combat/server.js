// SKYFALL LAN relay server. Run with Node.js after installing dependencies.
const WebSocket = require("ws");
const server = new WebSocket.Server({ host: "0.0.0.0", port: 3000 });
const rooms = new Map();
function send(ws, data) { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data)); }
function broadcast(room) {
  const players = {};
  for (const c of room.clients) if (c.readyState === WebSocket.OPEN && c.player) players[c.player.name + "_" + c.id] = c.player;
  for (const c of room.clients) send(c, { type: "state", players });
}
let nextId = 1;
server.on("connection", ws => {
  ws.id = nextId++;
  ws.on("message", raw => {
    let msg; try { msg = JSON.parse(raw.toString()); } catch { return; }
    if (msg.type === "join") {
      const code = String(msg.room || "SKY01").slice(0, 8);
      if (!rooms.has(code)) rooms.set(code, { clients: new Set() });
      ws.roomCode = code; ws.player = { name: String(msg.name || "PILOT").slice(0, 14), x: 480, y: 420, a: -1.57 };
      rooms.get(code).clients.add(ws); broadcast(rooms.get(code));
    } else if (msg.type === "position" && ws.roomCode && ws.player) {
      ws.player.x = Math.max(0, Math.min(960, Number(msg.x) || 0));
      ws.player.y = Math.max(0, Math.min(600, Number(msg.y) || 0));
      ws.player.a = Number(msg.a) || 0;
      broadcast(rooms.get(ws.roomCode));
    } else if (msg.type === "shot" && ws.roomCode && msg.shot) {
      // Relay visual shot events to the other pilots in this room.
      const room = rooms.get(ws.roomCode);
      if (room) for (const client of room.clients) {
        if (client !== ws) send(client, { type: "shot", from: ws.player?.name || "PILOT", shot: {
          x: Number(msg.shot.x) || 0, y: Number(msg.shot.y) || 0,
          vx: Number(msg.shot.vx) || 0, vy: Number(msg.shot.vy) || 0,
          life: Math.min(120, Math.max(1, Number(msg.shot.life) || 90))
        }});
      }
    }
  });
  ws.on("close", () => {
    if (ws.roomCode && rooms.has(ws.roomCode)) {
      const room = rooms.get(ws.roomCode); room.clients.delete(ws);
      if (!room.clients.size) rooms.delete(ws.roomCode); else broadcast(room);
    }
  });
});
console.log("SKYFALL LAN relay listening on ws://0.0.0.0:3000");
