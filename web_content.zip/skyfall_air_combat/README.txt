SKYFALL: AIR COMBAT — BUILD 0.1.0
================================

WHAT'S INCLUDED
- Top-down 2D airplane shooter prototype.
- Singleplayer wave survival and free-for-all bot practice.
- Configurable bot count, difficulty, behavior, aggression, accuracy and speed.
- Aircraft selection (visual variants reserved for future art upgrades).
- Analog on-screen joystick and FIRE button for phones; WASD / arrow keys + Space on keyboard.
- Map editor with water, land, forest, airbase, rock and erase tools.
- Local map save/load using browser storage.
- LAN room relay server for players on the same Wi-Fi.
- Responsive menu and HUD.

IMPORTANT LAN NOTE
The LAN server relays player positions and visual shot effects. It still does not synchronize bullet collisions, damage, maps, teams, or authoritative match state. LAN mode is an early multiplayer proof of concept, not finished competitive netcode.

RUN ON A COMPUTER
1. Install Node.js (LTS).
2. Extract the ZIP into a folder.
3. Open a terminal in that folder.
4. Run: npm install
5. Run: npm start
6. Find the host device's local Wi-Fi IPv4 address (for example 192.168.1.25).
7. Open index.html in a browser on each device, or serve the folder with a local static web server.
8. In LAN Operations, set server address to ws://HOST-IP:3000.
9. Everyone enters the same room code and a different pilot name, then taps JOIN ROOM.
10. Allow Node.js through the computer firewall on private networks if prompted.

ANDROID / ACODE
1. Extract the ZIP.
2. Open the skyfall_air_combat folder in Acode.
3. Open index.html and use Preview.
4. Singleplayer and Map Workshop work locally in the browser.
5. To use LAN, run server.js on a device/computer with Node.js and use its Wi-Fi IP address in the game.
6. A plain HTML-to-APK wrapper can package the singleplayer/editor experience. LAN still needs the separate relay server running somewhere on the same Wi-Fi.

CONTROLS
Desktop: WASD or arrow keys to move; Space to fire.
Mobile: move with the analog joystick at bottom-left; FIRE at bottom-right. Push the joystick farther from its center for faster movement.
Pause: top-right pause button.

CUSTOM MAPS
1. Open Map Workshop.
2. Choose a paint tool.
3. Tap/drag on the grid.
4. Name the map and tap SAVE MAP.
5. Saved maps appear in the Singleplayer map list.
Maps are saved in that browser's local storage. Clearing browser/app data may remove them.

TROUBLESHOOTING
- If LAN does not connect, verify both devices use the same Wi-Fi.
- Verify the server is running and use ws:// (not https://).
- Use the host's local IPv4 address, not 127.0.0.1 on another device.
- Ensure port 3000 is allowed by the firewall.
- Some APK preview wrappers restrict network connections; test LAN in a normal browser first.
- If the screen looks blank, open index.html in a modern browser and check that style.css and game.js are beside it.

PROJECT FILES
index.html   Menus, screens and canvas elements
style.css    Visual design and responsive layout
game.js      Game logic, bots, editor, controls and LAN client
server.js    Small WebSocket relay server for LAN
package.json Server dependency and start command
README.txt   Beginner setup guide

V0.2 UPGRADE NOTES
- Replaced the four-direction pad with a smooth analog joystick.
- Added three aircraft handling profiles (Falcon, Viper, Spectre).
- Added visual LAN shot-event relay.
- Added bot health bars and player name labels in LAN.
- Added additional aircraft propeller detail.

REMAINING DEVELOPMENT MILESTONES
- Authoritative LAN hit detection, damage, teams and match state.
- Full aircraft sprite sheets and animation.
- Sound effects, music and richer explosion animation.
- Terrain collision, destructible map objects and spawn placement.
- Room browser, reconnect handling and host controls.
