/* JOSTECH — MANUEL 10 : ANGLAIS INFORMATIQUE NIVEAU 3 */
registerLessonDetail(10, 3, "eng-3-1-1", {
  title: "Leçon 1 : Technical Writing, Bug Reports & Specialized IT",
  duration: "45 min (Manuel universitaire complet)",
  objectives: [
    "Rédiger un Bug Report professionnel et un fichier README.md clair en anglais.",
    "Formuler des revues de code constructives et des messages de commit standardisés.",
    "Maîtriser la terminologie avancée de Cybersécurité, Réseaux, IA et Cloud."
  ],
  prerequisites: ["Niveau 2 — Documentation anglaise."],
  sections: [
    {
      type: "theory",
      title: "1. Principes de la Rédaction Technique (Technical Writing)",
      text: "En ingénierie internationale, un écrit technique doit être clair, concis et factuel : phrases courtes à la voix active (ex: « Click Save » plutôt que « The Save button should be clicked by the user »), listes à puces et exemples reproductibles.\n\nUn bon README.md à la racine d'un projet présente toujours : Project Overview, Prerequisites, Installation Steps, Usage et License."
    },
    {
      type: "code",
      lang: "Modèle international de Bug Report & Conventional Commits",
      code: [
        "--- BUG REPORT (GitHub / Jira) ---",
        "Title: [BUG] Quiz timer keeps running after leaving exam view",
        "Environment: Android 14 / Chrome 131 / JOSTECH v1.1",
        "Steps to Reproduce: 1. Start Exam 2. Tap Home tab before finishing",
        "Expected Behavior: Timer stops immediately.",
        "Actual Behavior: Timer triggers auto-submit after 10 minutes.",
        "",
        "--- CONVENTIONAL COMMITS (Git) ---",
        "feat: add offline service worker caching",
        "fix: prevent timer leak when navigating away"
      ].join("\n")
    },
    {
      type: "table",
      title: "2. Terminologie spécialisée (Cyber, IA & Cloud)",
      headers: ["Domaine", "Termes anglais clés & traduction"],
      rows: [
        ["Cybersécurité", "Vulnerability (faille), Patch (correctif), Breach (fuite), Payload (charge utile), Mitigation."],
        ["Intelligence Artificielle", "Training dataset, Overfitting (surapprentissage), Inference, Weights, Hallucination."],
        ["Réseaux & Cloud", "Gateway (passerelle), Packet loss, Scalability (passage à l'échelle), Downtime (indisponibilité)."]
      ]
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Corriger un message de bug vague",
      question: "Un étudiant écrit : « Your quiz doesn't work, please fix it! ». Réécrivez ce signalement en anglais professionnel en supposant que le bouton Valider ne répond pas sur l'Examen de Réseaux.",
      solution: "Title: [BUG] Submit button unresponsive on Network Exam\nSteps to Reproduce: 1. Open Exams -> Network Exam 2. Answer all questions 3. Tap 'Valider /20'.\nExpected: Display score out of 20.\nActual: Nothing happens on screen."
    },
    {
      title: "Exercice 2 — Compléter le lexique spécialisé",
      question: "Complétez : « Due to high server load, the platform experienced 10 minutes of ___ (indisponibilité), so engineers improved ___ (passage à l'échelle) and applied a security ___ (correctif). »",
      solution: "1) downtime  |  2) scalability  |  3) patch."
    }
  ],
  summary: "La rédaction technique structurée (Expected vs Actual behavior, README, Conventional Commits) et le vocabulaire spécialisé IA/Cyber/Cloud permettent de collaborer efficacement à l'échelle mondiale.",
  references: ["Google Technical Writing Courses (developers.google.com/tech-writing)."]
});