# GameHub V3 — phone-only workflow

1. Create a GitHub account and a new repository from your phone.
2. Upload the contents of this project to the repository.
3. Open Actions and run **Build GameHub APK**.
4. Download the generated APK from the workflow's Artifacts section.
5. For the public website, enable GitHub Pages for the repository.
6. For REAL public uploads, connect a backend/database + object storage and add authentication and moderation. Do not put private backend keys in `config.js`.
7. Only publish games you own or have permission to distribute.

This project is a phone-friendly PWA plus an Android wrapper. The included GitHub Action builds the APK in the cloud, so no PC/Android Studio is required for the build.
