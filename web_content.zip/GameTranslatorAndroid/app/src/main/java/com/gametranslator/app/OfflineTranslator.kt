package com.gametranslator.app

import android.content.Context
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

/**
 * Translation is performed on the device. A language model is downloaded the first
 * time a language pair is used; no text is sent to an application-owned server.
 */
object OfflineTranslator {
    private val translators = ConcurrentHashMap<String, Translator>()
    private val locks = ConcurrentHashMap<String, Mutex>()

    suspend fun translate(
        context: Context,
        text: String,
        sourceTag: String,
        targetTag: String
    ): String {
        val input = text.trim()
        if (input.isEmpty()) return ""
        if (sourceTag == targetTag) return input

        val source = TranslateLanguage.fromLanguageTag(sourceTag)
            ?: error("لغة المصدر غير مدعومة في نموذج الترجمة: $sourceTag")
        val target = TranslateLanguage.fromLanguageTag(targetTag)
            ?: error("لغة الهدف غير مدعومة في نموذج الترجمة: $targetTag")
        val key = "$source>$target"
        val lock = locks.getOrPut(key) { Mutex() }

        return lock.withLock {
            withContext(Dispatchers.IO) {
                val translator = translators.getOrPut(key) {
                    val options = TranslatorOptions.Builder()
                        .setSourceLanguage(source)
                        .setTargetLanguage(target)
                        .build()
                    Translation.getClient(options)
                }
                // First use downloads the language pack to this device. This is free,
                // but it requires an internet connection for the initial download.
                Tasks.await(translator.downloadModelIfNeeded(DownloadConditions.Builder().build()))
                Tasks.await(translator.translate(input))
            }
        }
    }

    fun closeAll() {
        translators.values.forEach { runCatching { it.close() } }
        translators.clear()
        locks.clear()
    }
}
