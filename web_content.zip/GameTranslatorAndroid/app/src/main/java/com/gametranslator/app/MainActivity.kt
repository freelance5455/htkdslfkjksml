package com.gametranslator.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Games
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.util.Locale

private val Bg = Color(0xFF071B24)
private val SurfaceDark = Color(0xFF102D36)
private val CardDark = Color(0xFF123A43)
private val Neon = Color(0xFF35D6B0)
private val NeonBlue = Color(0xFF39C8E8)
private val Gold = Color(0xFFFFD34F)
private val TextMain = Color(0xFFEAF5F1)
private val Muted = Color(0xFFA9C2BE)

private data class AppLanguage(val code: String, val label: String)
private val appLanguages = listOf(
    AppLanguage("ar", "العربية"), AppLanguage("en", "English"),
    AppLanguage("fr", "Français"), AppLanguage("es", "Español"),
    AppLanguage("de", "Deutsch"), AppLanguage("it", "Italiano"),
    AppLanguage("pt", "Português"), AppLanguage("tr", "Türkçe"),
    AppLanguage("ja", "日本語"), AppLanguage("ko", "한국어"),
    AppLanguage("zh", "中文")
)

private enum class Page(val title: String) {
    HOME("الرئيسية"), SCREEN("ترجمة الشاشة"), FILES("ترجمة الملفات"),
    TEXT("ترجمة النصوص"), HISTORY("سجل الترجمة"), SETTINGS("الإعدادات"), SUPPORT("الدعم الفني")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(7, 27, 36)
        window.navigationBarColor = android.graphics.Color.rgb(7, 27, 36)
        setContent { GameTranslatorApp() }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 91)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GameTranslatorApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("game_translator_settings", Context.MODE_PRIVATE) }
    var page by rememberSaveable { mutableStateOf(Page.HOME) }
    var menuExpanded by remember { mutableStateOf(false) }
    var source by rememberSaveable { mutableStateOf(prefs.getString("source_language", "en") ?: "en") }
    var target by rememberSaveable { mutableStateOf(prefs.getString("target_language", "ar") ?: "ar") }
    var isRunning by remember { mutableStateOf(prefs.getBoolean("capture_running", false)) }
    var regionDialog by remember { mutableStateOf(false) }
    var selectedTheme by rememberSaveable { mutableStateOf(prefs.getInt("theme", 0)) }
    val history = remember { mutableStateListOf<String>().apply {
        val stored = runCatching { JSONArray(prefs.getString("history", "[]")) }.getOrNull()
        if (stored != null) for (i in 0 until stored.length()) add(stored.optString(i))
    } }
    val scope = rememberCoroutineScope()

    val projectionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val data = result.data
        if (result.resultCode == Activity.RESULT_OK && data != null) {
            prefs.edit()
                .putString("source_language", source)
                .putString("target_language", target)
                .apply()
            val serviceIntent = Intent(context, ScreenCaptureService::class.java).apply {
                action = ScreenCaptureService.ACTION_START
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
            }
            runCatching {
                ContextCompat.startForegroundService(context, serviceIntent)
                isRunning = true
                Toast.makeText(context, "بدأت جلسة الترجمة. اترك إشعارها ظاهراً أثناء اللعب.", Toast.LENGTH_LONG).show()
            }.onFailure {
                isRunning = false
                Toast.makeText(context, "تعذر بدء الخدمة: ${it.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        } else {
            isRunning = false
            Toast.makeText(context, "لم تتم الموافقة على التقاط الشاشة", Toast.LENGTH_SHORT).show()
        }
    }

    val openFileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    val loaded = withContext(Dispatchers.IO) { TranslationFileProcessor.readTextFile(context, uri) }
                    val extension = loaded.name.substringAfterLast('.', "txt").lowercase()
                    if (extension !in setOf("txt", "md", "srt", "json")) {
                        Toast.makeText(context, "النسخة الحالية تدعم TXT وMD وSRT وJSON فقط", Toast.LENGTH_LONG).show()
                        return@launch
                    }
                    prefs.edit().putString("source_language", source).putString("target_language", target).apply()
                    Toast.makeText(context, "تم فتح ${loaded.name}", Toast.LENGTH_SHORT).show()
                    // File page state is handled by the shared transfer holder below.
                    pendingFileName.value = loaded.name
                    pendingFileText.value = loaded.text
                    pendingTranslatedFile.value = ""
                    pendingFileStatus.value = "تم اختيار الملف. اضغط «ترجمة الملف» للمتابعة."
                } catch (e: Exception) {
                    pendingFileStatus.value = "تعذر قراءة الملف: ${e.localizedMessage ?: "خطأ"}"
                }
            }
        }
    }
    val saveFileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null && pendingTranslatedFile.value.isNotEmpty()) {
            scope.launch {
                runCatching {
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use {
                            it.write(pendingTranslatedFile.value)
                        } ?: error("تعذر حفظ الملف")
                    }
                }.onSuccess {
                    pendingFileStatus.value = "تم حفظ الملف المترجم بنجاح."
                }.onFailure {
                    pendingFileStatus.value = "فشل الحفظ: ${it.localizedMessage}"
                }
            }
        }
    }

    LaunchedEffect(page) {
        if (page == Page.SCREEN) {
            while (true) {
                isRunning = prefs.getBoolean("capture_running", false)
                delay(1000)
            }
        }
    }

    val accent = when (selectedTheme) {
        1 -> Color(0xFFB69CFF)
        2 -> Color(0xFF56E0A6)
        else -> Neon
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = accent, secondary = Gold, background = Bg, surface = SurfaceDark,
        onPrimary = Bg, onBackground = TextMain, onSurface = TextMain
    )) {
        androidx.compose.runtime.CompositionLocalProvider(
            androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl
        ) {
            Scaffold(
                modifier = Modifier.fillMaxSize().background(Bg).windowInsetsPadding(WindowInsets.safeDrawing),
                containerColor = Bg,
                topBar = {
                    TopAppBar(
                        title = {
                            Column {
                                Text("ترجمة الألعاب", color = TextMain, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                                Text(page.title, color = Muted, fontSize = 11.sp)
                            }
                        },
                        navigationIcon = {
                            Box {
                                IconButton(onClick = { menuExpanded = true }) {
                                    Icon(Icons.Default.Menu, contentDescription = "القائمة", tint = accent)
                                }
                                DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                                    Page.values().forEach { item ->
                                        DropdownMenuItem(
                                            text = { Text(item.title) },
                                            onClick = { page = item; menuExpanded = false }
                                        )
                                    }
                                }
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg)
                    )
                }
            ) { padding ->
                Box(Modifier.fillMaxSize().padding(padding)) {
                    when (page) {
                        Page.HOME -> HomePage(
                            onScreen = { page = Page.SCREEN },
                            onFiles = { page = Page.FILES },
                            onText = { page = Page.TEXT },
                            accent = accent
                        )
                        Page.TEXT -> TextTranslationPage(source, target, { source = it }, { target = it }, accent) { translated, original ->
                            addHistory(history, prefs, "نص: ${original.take(44)} → ${translated.take(50)}")
                        }
                        Page.FILES -> FileTranslationPage(
                            source = source,
                            target = target,
                            onSource = { source = it },
                            onTarget = { target = it },
                            accent = accent,
                            fileName = pendingFileName.value,
                            fileStatus = pendingFileStatus.value,
                            hasFile = pendingFileText.value.isNotEmpty(),
                            hasTranslated = pendingTranslatedFile.value.isNotEmpty(),
                            onChoose = { openFileLauncher.launch(arrayOf("text/*", "application/json", "application/x-subrip", "application/octet-stream")) },
                            onTranslate = {
                                scope.launch {
                                    pendingFileWorking.value = true
                                    pendingTranslatedFile.value = ""
                                    pendingFileStatus.value = "جارٍ تجهيز نموذج الترجمة..."
                                    try {
                                        pendingTranslatedFile.value = TranslationFileProcessor.translateDocument(
                                            pendingFileText.value, pendingFileName.value, source, target, context
                                        ) { message -> pendingFileStatus.value = message }
                                        pendingFileStatus.value = "اكتملت الترجمة. راجع الملف ثم احفظ النسخة الجديدة."
                                        addHistory(history, prefs, "ملف: ${pendingFileName.value}")
                                    } catch (e: Exception) {
                                        pendingFileStatus.value = "تعذرت الترجمة: ${e.localizedMessage ?: "خطأ غير معروف"}"
                                    } finally {
                                        pendingFileWorking.value = false
                                    }
                                }
                            },
                            onSave = {
                                val outputName = pendingFileName.value.substringBeforeLast('.', pendingFileName.value) + "_translated." + pendingFileName.value.substringAfterLast('.', "txt")
                                saveFileLauncher.launch(outputName)
                            },
                            working = pendingFileWorking.value
                        )
                        Page.SCREEN -> ScreenTranslationPage(
                            source, target,
                            onSource = { source = it }, onTarget = { target = it },
                            running = isRunning,
                            accent = accent,
                            onRegion = { regionDialog = true },
                            onStart = {
                                prefs.edit().putString("source_language", source).putString("target_language", target).apply()
                                if (!Settings.canDrawOverlays(context)) {
                                    context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")))
                                    Toast.makeText(context, "اسمح للتطبيق بالظهور فوق التطبيقات، ثم ارجع واضغط بدء الترجمة.", Toast.LENGTH_LONG).show()
                                } else {
                                    val manager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                                    projectionLauncher.launch(manager.createScreenCaptureIntent())
                                }
                            },
                            onStop = {
                                context.startService(Intent(context, ScreenCaptureService::class.java).setAction(ScreenCaptureService.ACTION_STOP))
                                isRunning = false
                            }
                        )
                        Page.HISTORY -> HistoryPage(history.toList(), accent) {
                            history.clear()
                            prefs.edit().putString("history", "[]").apply()
                        }
                        Page.SETTINGS -> SettingsPage(
                            theme = selectedTheme,
                            onTheme = { selectedTheme = it; prefs.edit().putInt("theme", it).apply() },
                            accent = accent
                        )
                        Page.SUPPORT -> SupportPage(accent)
                    }
                }
            }
        }

        if (regionDialog) {
            RegionPickerDialog(
                accent = accent,
                onDismiss = { regionDialog = false },
                onConfirm = { rect ->
                    prefs.edit()
                        .putFloat("region_left", rect.left)
                        .putFloat("region_top", rect.top)
                        .putFloat("region_right", rect.right)
                        .putFloat("region_bottom", rect.bottom)
                        .apply()
                    regionDialog = false
                    Toast.makeText(context, "تم حفظ منطقة الترجمة", Toast.LENGTH_SHORT).show()
                }
            )
        }
    }
}

// Transfer state for the document picker. It is intentionally held in process memory;
// the selected file and translated output are not uploaded anywhere.
private val pendingFileName = mutableStateOf("")
private val pendingFileText = mutableStateOf("")
private val pendingFileStatus = mutableStateOf("لم يتم اختيار ملف بعد")
private val pendingTranslatedFile = mutableStateOf("")
private val pendingFileWorking = mutableStateOf(false)

private fun addHistory(history: MutableList<String>, prefs: android.content.SharedPreferences, item: String) {
    history.add(0, "${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(java.util.Date())} • $item")
    while (history.size > 60) history.removeAt(history.lastIndex)
    val json = JSONArray().apply { history.forEach { put(it) } }
    prefs.edit().putString("history", json.toString()).apply()
}

@Composable
private fun PageColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().background(Bg).imePadding().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp)
    ) { content() }
}

@Composable
private fun HomePage(onScreen: () -> Unit, onFiles: () -> Unit, onText: () -> Unit, accent: Color) {
    PageColumn {
        Spacer(Modifier.height(8.dp))
        Text("🎮", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 48.sp)
        Text("ترجم ألعابك بلغتك", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, color = accent, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
        Text("ترجمة محلية على هاتفك دون خادم ترجمة مدفوع", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(4.dp))
        FeatureCard("الترجمة التلقائية للشاشة", "التقط النصوص الظاهرة في اللعبة واعرض ترجمتها في نافذة عائمة.", Icons.Default.Games, accent, onScreen)
        FeatureCard("الترجمة الجزئية للشاشة", "حدد مستطيلاً حول منطقة الحوار لتقليل المعالجة والبطارية.", Icons.Default.Translate, Gold, onScreen)
        FeatureCard("الترجمة عبر الملفات", "اختر ملف TXT أو SRT أو JSON يحتوي على نصوص اللعبة وترجمه ثم احفظ نسخة جديدة.", Icons.Default.FolderOpen, accent, onFiles)
        FeatureCard("الترجمة العادية", "اكتب أو الصق أي نص واختر اللغتين لترجمته محلياً.", Icons.Default.TextFields, Gold, onText)
        Spacer(Modifier.height(3.dp))
        InfoCard("معلومة عن المجانية", "لا توجد رسوم لكل ترجمة ولا خادم خاص بالتطبيق. يلزم اتصال بالإنترنت لتنزيل نموذج اللغة أول مرة؛ بعدها تعمل الترجمة دون اتصال.", accent)
    }
}

@Composable
private fun FeatureCard(title: String, description: String, icon: androidx.compose.ui.graphics.vector.ImageVector, accent: Color, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = CardDark),
        shape = RoundedCornerShape(18.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, accent.copy(alpha = .55f))
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(13.dp)) {
            Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(accent.copy(alpha = .12f)).border(1.dp, accent.copy(alpha = .65f), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(25.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(title, color = TextMain, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(description, color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
            }
        }
    }
}

@Composable
private fun InfoCard(title: String, body: String, accent: Color) {
    Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), border = androidx.compose.foundation.BorderStroke(1.dp, accent.copy(alpha = .25f))) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = accent, fontWeight = FontWeight.Bold)
            Text(body, color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
        }
    }
}

@Composable
private fun LanguagePicker(label: String, selected: String, onSelect: (String) -> Unit, accent: Color, enabled: Boolean = true) {
    var expanded by remember { mutableStateOf(false) }
    val current = appLanguages.firstOrNull { it.code == selected } ?: appLanguages[1]
    Box(Modifier.fillMaxWidth()) {
        OutlinedButton(onClick = { expanded = true }, enabled = enabled, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = TextMain)) {
            Column(Modifier.fillMaxWidth()) {
                Text(label, color = Muted, fontSize = 11.sp)
                Text(current.label, color = accent, fontWeight = FontWeight.SemiBold)
            }
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            appLanguages.forEach { language ->
                DropdownMenuItem(text = { Text(language.label) }, onClick = { onSelect(language.code); expanded = false })
            }
        }
    }
}

@Composable
private fun TextTranslationPage(
    source: String, target: String,
    onSource: (String) -> Unit, onTarget: (String) -> Unit,
    accent: Color, onTranslated: (String, String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    var input by rememberSaveable { mutableStateOf("") }
    var output by rememberSaveable { mutableStateOf("") }
    var status by rememberSaveable { mutableStateOf("اختر اللغتين ثم اكتب النص") }
    var working by remember { mutableStateOf(false) }
    PageColumn {
        Text("ترجمة النصوص", color = accent, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.weight(1f)) { LanguagePicker("من اللغة", source, onSource, accent) }
            Box(Modifier.weight(1f)) { LanguagePicker("إلى اللغة", target, onTarget, Gold) }
        }
        OutlinedTextField(
            value = input, onValueChange = { input = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 140.dp),
            label = { Text("النص المراد ترجمته") }, placeholder = { Text("اكتب أو الصق النص هنا") },
            minLines = 5, colors = fieldColors(accent)
        )
        AccentButton(if (working) "جارٍ الترجمة..." else "ترجمة النص", accent, enabled = input.isNotBlank() && !working) {
            scope.launch {
                working = true
                status = "قد يتم تنزيل نموذج اللغة أول مرة..."
                try {
                    output = OfflineTranslator.translate(context, input, source, target)
                    status = "اكتملت الترجمة على الجهاز"
                    onTranslated(output, input)
                } catch (e: Exception) {
                    status = "تعذرت الترجمة: ${e.localizedMessage ?: "تحقق من دعم اللغة والاتصال لتنزيل النموذج"}"
                } finally { working = false }
            }
        }
        Text(status, color = Muted, fontSize = 12.sp)
        if (output.isNotBlank()) {
            Card(colors = CardDefaults.cardColors(containerColor = CardDark), border = androidx.compose.foundation.BorderStroke(1.dp, accent.copy(alpha = .55f))) {
                Column(Modifier.fillMaxWidth().padding(14.dp)) {
                    Text("الترجمة", color = accent, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    SelectionContainer { Text(output, color = TextMain, lineHeight = 22.sp) }
                    OutlinedButton(onClick = { clipboard.setText(AnnotatedString(output)) }) { Text("نسخ الترجمة") }
                }
            }
        }
    }
}

@Composable
private fun FileTranslationPage(
    source: String, target: String,
    onSource: (String) -> Unit, onTarget: (String) -> Unit,
    accent: Color, fileName: String, fileStatus: String,
    hasFile: Boolean, hasTranslated: Boolean,
    onChoose: () -> Unit, onTranslate: () -> Unit, onSave: () -> Unit, working: Boolean
) {
    PageColumn {
        Text("ترجمة ملفات الألعاب", color = accent, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("اختر ملف نصوص أصلياً من اللعبة. سنترجم النصوص ونحافظ على بنية JSON أو توقيتات SRT قدر الإمكان، ثم نحفظ نسخة جديدة.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.weight(1f)) { LanguagePicker("لغة الملف", source, onSource, accent) }
            Box(Modifier.weight(1f)) { LanguagePicker("لغة الترجمة", target, onTarget, Gold) }
        }
        AccentButton("اختيار ملف من الهاتف", accent, onClick = onChoose)
        if (fileName.isNotBlank()) InfoCard("الملف المحدد", fileName, accent)
        Text(fileStatus, color = Muted, fontSize = 12.sp)
        AccentButton(if (working) "جارٍ ترجمة الملف..." else "ترجمة الملف", accent, enabled = hasFile && !working, onClick = onTranslate)
        AccentButton("حفظ النسخة المترجمة", Gold, enabled = hasTranslated && !working, onClick = onSave)
        InfoCard("الصيغ المدعومة حالياً", "TXT وMD للنصوص، SRT للترجمة الزمنية، وJSON مع ترجمة القيم النصية وترك المفاتيح كما هي. ملفات APK وPAK والحزم المشفرة غير مدعومة.", accent)
        InfoCard("مهم", "هذه الميزة تنشئ ملفاً مترجماً جديداً ولا تثبّت التعريب داخل اللعبة تلقائياً. تركيب الملف يعتمد على محرك اللعبة وصيغة التعديل الخاصة بها.", Gold)
    }
}

@Composable
private fun ScreenTranslationPage(
    source: String, target: String,
    onSource: (String) -> Unit, onTarget: (String) -> Unit,
    running: Boolean, accent: Color, onRegion: () -> Unit,
    onStart: () -> Unit, onStop: () -> Unit
) {
    PageColumn {
        Text("الترجمة التلقائية للشاشة", color = accent, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("ابدأ الالتقاط قبل فتح اللعبة. سيظهر صندوق الترجمة فوق التطبيقات. يجب إبقاء إشعار الخدمة ظاهراً.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.weight(1f)) { LanguagePicker("لغة اللعبة", source, onSource, accent, enabled = !running) }
            Box(Modifier.weight(1f)) { LanguagePicker("لغة الترجمة", target, onTarget, Gold, enabled = !running) }
        }
        AccentButton("تحديد منطقة الترجمة", accent, onClick = onRegion)
        if (running) {
            InfoCard("حالة الالتقاط", "جلسة التقاط الشاشة نشطة. إذا أوقفتها اللعبة أو النظام، وافق على التقاط الشاشة مجدداً من التطبيق.", accent)
            AccentButton("إيقاف الترجمة", Gold, onClick = onStop)
        } else {
            AccentButton("بدء الترجمة التلقائية", accent, onClick = onStart)
        }
        InfoCard("لتجنب التوقف", "الخدمة تعمل كخدمة أمامية بإشعار دائم، وتعالج إطاراً كل نحو 1.3 ثانية فقط. مع ذلك قد تفرض بعض الهواتف قيود بطارية، وقد تنتهي جلسة الالتقاط إذا أوقفها النظام أو المستخدم.", accent)
        InfoCard("ملاحظة اللغات", "يدعم OCR في هذه النسخة النصوص اللاتينية واليابانية والصينية والكورية. ترجمة النص العربي المكتوب على الشاشة تحتاج إلى محرك OCR إضافي غير مضمّن حالياً.", Gold)
        InfoCard("ملاحظة الخصوصية", "يُقرأ محتوى الشاشة بعد موافقتك الصريحة على MediaProjection. لا نرفع الصور أو النصوص إلى خادم تابع للتطبيق.", Gold)
    }
}

@Composable
private fun RegionPickerDialog(accent: Color, onDismiss: () -> Unit, onConfirm: (Rect) -> Unit) {
    var region by remember { mutableStateOf(Rect(0.06f, 0.66f, 0.94f, 0.96f)) }
    var dragStart by remember { mutableStateOf(Offset.Zero) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceDark,
        title = { Text("حدد منطقة الترجمة", color = TextMain, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("اسحب على النموذج لتحديد مكان الحوار. سيقرأ التطبيق هذا الجزء فقط من الشاشة.", color = Muted, fontSize = 12.sp)
                Canvas(
                    modifier = Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF07151F))
                        .pointerInput(Unit) {
                            detectDragGestures(
                                onDragStart = { start ->
                                    dragStart = Offset((start.x / size.width).coerceIn(0f, 1f), (start.y / size.height).coerceIn(0f, 1f))
                                    region = Rect(dragStart.x, dragStart.y, dragStart.x, dragStart.y)
                                },
                                onDrag = { change, _ ->
                                    val x = (change.position.x / size.width).coerceIn(0f, 1f)
                                    val y = (change.position.y / size.height).coerceIn(0f, 1f)
                                    region = Rect(
                                        minOf(dragStart.x, x).coerceIn(0f, .94f),
                                        minOf(dragStart.y, y).coerceIn(0f, .94f),
                                        maxOf(dragStart.x, x).coerceIn(.06f, 1f),
                                        maxOf(dragStart.y, y).coerceIn(.06f, 1f)
                                    )
                                    change.consume()
                                }
                            )
                        }
                ) {
                    drawRoundRect(Color(0xFF12303A), cornerRadius = androidx.compose.ui.geometry.CornerRadius(14.dp.toPx()))
                    // Decorative game HUD blocks in the preview.
                    drawRoundRect(Color(0xFF254752), topLeft = Offset(size.width * .05f, size.height * .08f), size = Size(size.width * .23f, size.height * .14f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(8.dp.toPx()))
                    drawRoundRect(Color(0xFF254752), topLeft = Offset(size.width * .74f, size.height * .12f), size = Size(size.width * .2f, size.height * .17f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(8.dp.toPx()))
                    val selected = Rect(region.left * size.width, region.top * size.height, region.right * size.width, region.bottom * size.height)
                    drawRect(Color(0x6635D6B0), Offset(selected.left, selected.top), Size(selected.width, selected.height))
                    drawRect(accent, Offset(selected.left, selected.top), Size(selected.width, selected.height), style = Stroke(3.dp.toPx()))
                    drawLine(Color.White.copy(alpha = .7f), Offset(0f, size.height * .82f), Offset(size.width, size.height * .82f), strokeWidth = 1.dp.toPx())
                }
                Text("المنطقة المحددة: ${(region.width * 100).toInt()}% من العرض × ${(region.height * 100).toInt()}% من الارتفاع", color = accent, fontSize = 11.sp)
                OutlinedButton(onClick = { region = Rect(0f, 0f, 1f, 1f) }, modifier = Modifier.fillMaxWidth()) { Text("إعادة تعيين إلى الشاشة كاملة") }
            }
        },
        confirmButton = { Button(onClick = { onConfirm(region) }, colors = ButtonDefaults.buttonColors(containerColor = accent)) { Text("حفظ المنطقة") } },
        dismissButton = { OutlinedButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun HistoryPage(entries: List<String>, accent: Color, onClear: () -> Unit) {
    PageColumn {
        Text("سجل الترجمة", color = accent, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        if (entries.isEmpty()) Text("لا توجد ترجمات محفوظة بعد.", color = Muted)
        entries.forEach { item ->
            Card(colors = CardDefaults.cardColors(containerColor = CardDark)) {
                Text(item, modifier = Modifier.fillMaxWidth().padding(12.dp), color = TextMain, fontSize = 13.sp)
            }
        }
        OutlinedButton(onClick = onClear, modifier = Modifier.fillMaxWidth()) { Text("مسح السجل") }
    }
}

@Composable
private fun SettingsPage(theme: Int, onTheme: (Int) -> Unit, accent: Color) {
    PageColumn {
        Text("الإعدادات", color = accent, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("مظهر التطبيق", color = TextMain, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("نيون أخضر", "بنفسجي", "نعناعي").forEachIndexed { index, title ->
                OutlinedButton(onClick = { onTheme(index) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.outlinedButtonColors(contentColor = if (theme == index) accent else TextMain)) {
                    Text(title, fontSize = 11.sp)
                }
            }
        }
        InfoCard("لغة الواجهة", "العربية في هذه النسخة الأولية. يمكن إضافة واجهة إنجليزية في إصدار لاحق.", accent)
        InfoCard("العمل دون إنترنت", "بعد تنزيل حزمة اللغة لأول مرة، تتم الترجمة محلياً. يمكنك تغيير الحزم لاحقاً من إعدادات النظام أو بإضافة مدير نماذج في إصدار قادم.", accent)
    }
}

@Composable
private fun SupportPage(accent: Color) {
    val clipboard = LocalClipboardManager.current
    var message by rememberSaveable { mutableStateOf("") }
    PageColumn {
        Text("الدعم الفني", color = accent, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("هذه النسخة لا تستخدم خادم دعم أو إرسالاً سحابياً. يمكنك نسخ ملاحظتك للاحتفاظ بها أو إرسالها بنفسك.", color = Muted, fontSize = 13.sp)
        OutlinedTextField(value = message, onValueChange = { message = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 150.dp), label = { Text("اكتب ملاحظتك") }, colors = fieldColors(accent), minLines = 5)
        AccentButton("نسخ الملاحظة", accent, enabled = message.isNotBlank()) { clipboard.setText(AnnotatedString(message)) }
    }
}

@Composable
private fun AccentButton(text: String, accent: Color, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp),
        colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Bg, disabledContainerColor = accent.copy(alpha = .25f)),
        shape = RoundedCornerShape(13.dp)
    ) { Text(text, fontWeight = FontWeight.Bold) }
}

@Composable
private fun fieldColors(accent: Color) = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
    focusedBorderColor = accent,
    unfocusedBorderColor = Muted.copy(alpha = .5f),
    focusedLabelColor = accent,
    unfocusedLabelColor = Muted,
    focusedTextColor = TextMain,
    unfocusedTextColor = TextMain,
    cursorColor = accent
)
