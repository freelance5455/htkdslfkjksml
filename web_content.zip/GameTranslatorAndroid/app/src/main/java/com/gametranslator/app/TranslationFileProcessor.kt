package com.gametranslator.app

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.ensureActive
import org.json.JSONArray
import org.json.JSONObject
import kotlin.coroutines.coroutineContext

object TranslationFileProcessor {
    data class LoadedFile(val name: String, val text: String, val mimeType: String)

    fun readTextFile(context: Context, uri: Uri): LoadedFile {
        val resolver = context.contentResolver
        val name = resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }
            ?: "game-text.txt"
        val mime = resolver.getType(uri) ?: "text/plain"
        val bytes = resolver.openInputStream(uri)?.use { it.readBytes() } ?: error("تعذر فتح الملف")
        require(bytes.size <= 8 * 1024 * 1024) { "حجم الملف أكبر من الحد الحالي وهو 8 ميغابايت" }
        val text = String(bytes, Charsets.UTF_8)
        return LoadedFile(name, text, mime)
    }

    suspend fun translateDocument(
        raw: String,
        fileName: String,
        source: String,
        target: String,
        context: Context,
        onProgress: (String) -> Unit = {}
    ): String {
        val extension = fileName.substringAfterLast('.', "txt").lowercase()
        return when (extension) {
            "json" -> {
                val trimmed = raw.trim()
                if (trimmed.startsWith("[")) {
                    val json = JSONArray(trimmed)
                    translateJsonArray(json, context, source, target, onProgress)
                    json.toString(2)
                } else {
                    val json = JSONObject(trimmed)
                    translateJsonObject(json, context, source, target, onProgress)
                    json.toString(2)
                }
            }
            "srt" -> translateSrt(raw, context, source, target, onProgress)
            "txt", "md" -> translatePlainText(raw, context, source, target, onProgress)
            else -> error("هذه الصيغة غير مدعومة بعد. جرّب TXT أو MD أو SRT أو JSON.")
        }
    }

    private suspend fun translateJsonObject(
        obj: JSONObject,
        context: Context,
        source: String,
        target: String,
        progress: (String) -> Unit
    ) {
        val keys = obj.keys().asSequence().toList()
        for ((index, key) in keys.withIndex()) {
            coroutineContext.ensureActive()
            val value = obj.opt(key)
            progress("ترجمة عناصر JSON: ${index + 1}/${keys.size}")
            when (value) {
                is String -> if (value.isNotBlank() && shouldTranslate(value)) {
                    obj.put(key, translatePlainText(value, context, source, target, progress))
                }
                is JSONObject -> translateJsonObject(value, context, source, target, progress)
                is JSONArray -> translateJsonArray(value, context, source, target, progress)
            }
        }
    }

    private suspend fun translateJsonArray(
        array: JSONArray,
        context: Context,
        source: String,
        target: String,
        progress: (String) -> Unit
    ) {
        for (index in 0 until array.length()) {
            coroutineContext.ensureActive()
            val value = array.opt(index)
            progress("ترجمة عناصر JSON: ${index + 1}/${array.length()}")
            when (value) {
                is String -> if (value.isNotBlank() && shouldTranslate(value)) {
                    array.put(index, translatePlainText(value, context, source, target, progress))
                }
                is JSONObject -> translateJsonObject(value, context, source, target, progress)
                is JSONArray -> translateJsonArray(value, context, source, target, progress)
            }
        }
    }

    private suspend fun translateSrt(
        raw: String,
        context: Context,
        source: String,
        target: String,
        progress: (String) -> Unit
    ): String {
        val separatorRegex = Regex("\\r?\\n[\\t ]*\\r?\\n")
        val blocks = separatorRegex.split(raw)
        val translated = ArrayList<String>(blocks.size)
        blocks.forEachIndexed { index, block ->
            coroutineContext.ensureActive()
            var lines = block.split(Regex("\\r?\\n")).toMutableList()
            val timeLine = lines.indexOfFirst { it.contains("-->") }
            val textStart = when {
                timeLine >= 0 -> timeLine + 1
                lines.size >= 3 && lines[0].trim().toIntOrNull() != null -> 2
                else -> 0
            }
            if (textStart < lines.size) {
                val body = lines.drop(textStart).joinToString("\n")
                if (body.isNotBlank()) {
                    progress("ترجمة مقاطع الترجمة: ${index + 1}/${blocks.size}")
                    val translatedBody = translatePlainText(body, context, source, target, progress)
                    val prefix = lines.take(textStart)
                    lines = (prefix + translatedBody.split("\n")).toMutableList()
                }
            }
            translated += lines.joinToString("\n")
        }
        return translated.joinToString("\n\n")
    }

    private suspend fun translatePlainText(
        raw: String,
        context: Context,
        source: String,
        target: String,
        progress: (String) -> Unit
    ): String {
        if (raw.isBlank()) return raw
        // Split by paragraphs first, then by bounded chunks to avoid sending a huge
        // localization file to one translation request.
        val paragraphRegex = Regex("(\\r?\\n){2,}")
        val paragraphs = paragraphRegex.split(raw)
        val separators = paragraphRegex.findAll(raw).map { it.value }.toList()
        val result = ArrayList<String>(paragraphs.size)
        paragraphs.forEachIndexed { index, paragraph ->
            coroutineContext.ensureActive()
            if (paragraph.isBlank() || !shouldTranslate(paragraph)) {
                result += paragraph
            } else {
                val chunks = splitIntoChunks(paragraph, 1800)
                val translatedChunks = ArrayList<String>(chunks.size)
                chunks.forEachIndexed { chunkIndex, chunk ->
                    progress("ترجمة الفقرة ${index + 1}/${paragraphs.size}، جزء ${chunkIndex + 1}/${chunks.size}")
                    translatedChunks += OfflineTranslator.translate(context, chunk, source, target)
                }
                result += translatedChunks.joinToString("")
            }
        }
        if (separators.isEmpty()) return result.joinToString("")
        return buildString {
            result.forEachIndexed { index, paragraph ->
                append(paragraph)
                if (index < separators.size) append(separators[index])
            }
        }
    }

    private fun splitIntoChunks(text: String, maxLength: Int): List<String> {
        if (text.length <= maxLength) return listOf(text)
        val chunks = mutableListOf<String>()
        var start = 0
        while (start < text.length) {
            var end = minOf(start + maxLength, text.length)
            if (end < text.length) {
                val boundary = text.lastIndexOfAny(charArrayOf(' ', '\n', '.', '!', '?', '。', '！', '？'), end - 1)
                if (boundary > start + maxLength / 2) end = boundary + 1
            }
            chunks += text.substring(start, end)
            start = end
        }
        return chunks
    }

    private fun shouldTranslate(value: String): Boolean {
        val trimmed = value.trim()
        val visibleLetters = trimmed.count { it.isLetter() }
        val looksLikeIdentifier = Regex("^[A-Za-z][A-Za-z0-9]*(?:[_./:-][A-Za-z0-9_.:/-]+)+$").matches(trimmed)
        val looksLikeUrl = trimmed.startsWith("http://", true) || trimmed.startsWith("https://", true)
        return visibleLetters >= 2 && !looksLikeIdentifier && !looksLikeUrl &&
            !trimmed.matches(Regex("[\\d\\s.,:;_\\-/\\\\]+"))
    }
}
