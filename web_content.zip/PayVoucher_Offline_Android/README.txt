PAYVOUCHER V3 — OFFLINE ANDROID DEMO

This is an Android Studio project wrapper around the existing PayVoucher V3 demo HTML.
The HTML is bundled inside the app, so the app does not need an internet connection to open or run its local demo screens.

IMPORTANT
- This is DEMO ONLY. It does not connect to providers, banks, payment rails, or the internet.
- No INTERNET permission is included in AndroidManifest.xml.
- Demo data is stored locally by the WebView/browser storage on this device. Clearing app data can reset it.
- This ZIP is the Android Studio SOURCE PROJECT, not a compiled APK.

BUILD AN APK
1. On a computer, install Android Studio.
2. Extract this ZIP.
3. In Android Studio choose Open and select the PayVoucher_Offline_Android folder.
4. Allow Android Studio to sync/download the Android Gradle Plugin and SDK components. This setup step normally needs internet the first time.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Find the APK in app/build/outputs/apk/debug/ and transfer it to your Android phone.
7. Install the APK. After installation, the app itself can open and run offline.

QUICK OFFLINE OPTION (NO APK BUILD)
Copy PayVoucher_V3_Complete_Demo.html to your phone and open it with a browser/file viewer that supports local HTML. It should run without internet because the page is self-contained, though browser file-opening behavior varies by device.
