DETECTIVE CREW 2: THE SECOND IDENTITY
====================================

CONTENTS
- index.html : complete lightweight browser game (HTML + CSS + JavaScript)
- This project is a prototype, not a signed Android APK.

RUN ON A LAPTOP
1. Extract the ZIP.
2. Double-click index.html.
3. Open with Chrome, Edge, Firefox, or another modern browser.

RUN ON ANDROID
- Copy index.html to the phone and open it with a browser/file viewer that supports local HTML.
- If the browser blocks local files, publish the folder as a static website (for example, GitHub Pages) and open the HTTPS link.
- To install it like an app, package the site using Capacitor or an Android WebView project, then build/sign it with Android Studio. This ZIP does not include a compiled APK.

MAKE AN ANDROID APK (developer computer required)
1. Install Node.js LTS and Android Studio with Android SDK.
2. Create a Capacitor project, then copy index.html into its web assets folder.
   Example commands in a terminal:
     npm create @capacitor/app
   Follow the prompts and choose a suitable app name/package ID.
3. Replace the generated web asset index.html with this game's index.html.
4. Add Android platform and open the project:
     npm install @capacitor/android
     npx cap add android
     npx cap sync android
     npx cap open android
5. In Android Studio, build a debug APK for testing. For sharing broadly, generate a signed release APK or publish through Google Play. Never share signing keys.

SECURITY AND PERFORMANCE NOTES
- The game has no remote JavaScript libraries, ads, analytics, login, or network calls in its code.
- Game progress is stored in browser localStorage. It is local convenience storage, not secure storage; users can reset or edit it. Do not store passwords, personal records, or secrets there.
- The story is fictional. Do not use real people's identity records in the game.
- No app can be guaranteed 100% hack-proof or lag-free on every phone. Test on target devices, keep Android/build tools updated, request no unnecessary permissions, and distribute only a signed build from a trusted source.
- CSS character art is lightweight 2.5D-style, not a full 3D model. Voice uses the device/browser speech synthesis if available; sound effects are generated tones. No downloaded voice/music files are required.
