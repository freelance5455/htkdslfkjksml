#!/system/bin/sh

# ============================================================
# GMS / BATTERY OPTIMIZATION DIAGNOSTIC
# Universal GMS Doze + XtremeBS
# READ-ONLY DIAGNOSTIC
# ============================================================

RESET='\033[0m'
GRAY='\033[0;90m'
WHITE='\033[1;37m'
GREEN='\033[0;32m'
LIGHT_BLUE='\033[38;5;39m'
YELLOW='\033[0;33m'
RED='\033[0;31m'
BROWN='\033[38;5;130m'

PASS_COUNT=0
WARN_COUNT=0
INFO_COUNT=0
FAIL_COUNT=0
WARN_DETAILS=""
FAIL_DETAILS=""

MODULE_DIR="/data/adb/modules"
GMS="com.google.android.gms"

UGD="$MODULE_DIR/universal-gms-doze"

XBS="$MODULE_DIR/XtremeBS"
XBS_CONF="/data/local/tmp/XtremeBS/XtremeBS.conf"
XBS_STATUS="/data/local/tmp/XtremeBS/XtremeBS.status"
XBS_LOG="/data/local/tmp/XtremeBS/XtremeBS.log"

clear

section() {
    printf '\n'
    printf '%b\n' "${BROWN}[$1] $2${RESET}"
    printf '%b\n' "${WHITE}--------------------------------------------------${RESET}"
}

pass() {
    printf '%b\n' "${GREEN}    [PASS]${RESET} ${GRAY}$1${RESET}"
    PASS_COUNT=$((PASS_COUNT+1))
}

warn() {
    printf '%b\n' "${YELLOW}    [WARN]${RESET} ${GRAY}$1${RESET}"
    WARN_COUNT=$((WARN_COUNT+1))

    if [ -z "$WARN_DETAILS" ]; then
        WARN_DETAILS="$1"
    else
        WARN_DETAILS="${WARN_DETAILS}\n$1"
    fi
}

info() {
    printf '%b\n' "${LIGHT_BLUE}    [INFO]${RESET} ${GRAY}$1${RESET}"
    INFO_COUNT=$((INFO_COUNT+1))
}

fail() {
    printf '%b\n' "${RED}    [FAIL]${RESET} ${GRAY}$1${RESET}"
    FAIL_COUNT=$((FAIL_COUNT+1))

    if [ -z "$FAIL_DETAILS" ]; then
        FAIL_DETAILS="$1"
    else
        FAIL_DETAILS="${FAIL_DETAILS}\n$1"
    fi
}

printf '%b\n' "${WHITE}==================================================${RESET}"
printf '%b\n' "${WHITE}             ANDROID GMS CHECK${RESET}"
printf '%b\n' "${WHITE}==================================================${RESET}"

# ============================================================
# 1. PLATFORM
# ============================================================

section "1" "PLATFORM"

ANDROID=$(getprop ro.build.version.release)
API=$(getprop ro.build.version.sdk)

printf '%b\n' "${GRAY}Android: ${ANDROID}${RESET}"
printf '%b\n' "${GRAY}API:     ${API}${RESET}"

if [ "${ANDROID}" = "15" ] && [ "${API}" = "35" ]; then
    pass "Android 15 / API 35 detected."
elif [ "${ANDROID}" = "16" ] && [ "${API}" = "36" ]; then
    pass "Android 16 / API 36 detected."
else
    warn "Unsupported Android version/API combination: Android ${ANDROID} / API ${API}"
fi

# ============================================================
# 2. MODULE STATE
# ============================================================

section "2" "MODULE STATE"

# ------------------------------------------------------------
# Universal GMS Doze
# ------------------------------------------------------------

if [ -d "$UGD" ]; then

    UGD_VERSION="$(grep '^version=' "$UGD/module.prop" 2>/dev/null | cut -d= -f2)"

    if [ -f "$UGD/disable" ] || [ -f "$UGD/remove" ]; then
        warn "Universal GMS Doze is disabled or scheduled for removal."
    else
        if [ -n "$UGD_VERSION" ]; then
            pass "Universal GMS Doze enabled — v$UGD_VERSION."
        else
            pass "Universal GMS Doze is installed and enabled."
        fi
    fi

else
    fail "Universal GMS Doze module is not installed."
fi

# ------------------------------------------------------------
# XtremeBS
# ------------------------------------------------------------

if [ -d "$XBS" ]; then

    XBS_VERSION="$(grep '^version=' "$XBS/module.prop" 2>/dev/null | cut -d= -f2)"

    if [ -f "$XBS/disable" ] || [ -f "$XBS/remove" ]; then
        warn "XtremeBS is disabled or scheduled for removal."
    else
        if [ -n "$XBS_VERSION" ]; then
            pass "XtremeBS enabled — $XBS_VERSION."
        else
            pass "XtremeBS is installed and enabled."
        fi
    fi

else
    fail "XtremeBS module is not installed."
fi

# ============================================================
# 3. LIVE OPERATING STATE
# ============================================================

section "3" "LIVE OPERATING STATE"

# ------------------------------------------------------------
# Google Play Services
# ------------------------------------------------------------

GMS_PACKAGE_INFO="$(dumpsys package "$GMS" 2>/dev/null)"
GMS_PATH="$(pm path "$GMS" 2>/dev/null)"

if [ -n "$GMS_PATH" ]; then
    pass "Google Play Services package is available."
else
    fail "Google Play Services package was not found."
fi

if echo "$GMS_PACKAGE_INFO" | grep -q "hidden=true"; then
    warn "Google Play Services is hidden."
else
    pass "Google Play Services is not hidden."
fi

if echo "$GMS_PACKAGE_INFO" | grep -q "suspended=true"; then
    warn "Google Play Services is suspended."
else
    pass "Google Play Services is not suspended."
fi

if echo "$GMS_PACKAGE_INFO" | grep -q "stopped=true"; then
    warn "Google Play Services is stopped."
else
    pass "Google Play Services is not stopped."
fi

# ------------------------------------------------------------
# Universal GMS Doze — live state
# ------------------------------------------------------------

DEVICE_IDLE="$(dumpsys deviceidle 2>/dev/null)"

if [ -n "$DEVICE_IDLE" ]; then
    pass "Android DeviceIdle service is responding."
else
    fail "Android DeviceIdle service did not return data."
fi

GMSC_OUTPUT=""

if command -v gmsc >/dev/null 2>&1; then
    GMSC_OUTPUT="$(gmsc 2>&1)"
    GMSC_LOWER="$(echo "$GMSC_OUTPUT" | tr '[:upper:]' '[:lower:]')"

    if echo "$GMSC_LOWER" | grep -q "not optimized"; then
        warn "GMSC reports that Google Play Services is NOT optimized."
    elif echo "$GMSC_LOWER" | grep -q "optimized"; then
        pass "GMSC reports that Google Play Services is optimized."
    else
        warn "GMSC returned output but optimization state was unclear."
    fi
else
    warn "GMSC command was not found."
fi

DEVICE_IDLE_WHITELIST="$(dumpsys deviceidle whitelist 2>/dev/null)"

if echo "$DEVICE_IDLE_WHITELIST" | grep -q "$GMS"; then
    warn "Google Play Services appears in the DeviceIdle whitelist."
else
    pass "Google Play Services is not present in the DeviceIdle whitelist."
fi

# ------------------------------------------------------------
# XtremeBS — live state
# ------------------------------------------------------------

if [ -f "$XBS_STATUS" ]; then

    XBS_DOZE="$(grep "^Doze:" "$XBS_STATUS" 2>/dev/null | cut -d: -f2- | sed 's/^ *//')"
    XBS_SCREEN="$(grep -i "^Screen:" "$XBS_STATUS" 2>/dev/null | cut -d: -f2- | sed 's/^ *//')"

    if [ -n "$XBS_DOZE" ]; then
        info "XtremeBS Doze state: $XBS_DOZE"
    else
        info "XtremeBS Doze state is not currently reported."
    fi

    if [ -n "$XBS_SCREEN" ]; then
        info "XtremeBS screen state: $XBS_SCREEN"
    fi

else
    warn "XtremeBS live status file is unavailable."
fi

# ============================================================
# 4. DIAGNOSTIC EVIDENCE
# ============================================================

section "4" "DIAGNOSTIC EVIDENCE"

# ------------------------------------------------------------
# Android Doze state
# ------------------------------------------------------------

DEEP_STATE="$(echo "$DEVICE_IDLE" | grep -i "mDeepState" | head -1)"
LIGHT_STATE="$(echo "$DEVICE_IDLE" | grep -i "mLightState" | head -1)"

if [ -n "$DEEP_STATE" ]; then
    info "Deep Doze: $DEEP_STATE"
fi

if [ -n "$LIGHT_STATE" ]; then
    info "Light Doze: $LIGHT_STATE"
fi

# ------------------------------------------------------------
# GMS process / idle state
# ------------------------------------------------------------

GMS_PIDS="$(pidof "$GMS" 2>/dev/null)"

if [ -n "$GMS_PIDS" ]; then
    info "GMS process currently running: PID(s) $GMS_PIDS"
else
    info "No GMS process is currently running."
fi

# ------------------------------------------------------------
# GMS AppOps
# ------------------------------------------------------------

GMS_APPOPS="$(cmd appops get "$GMS" 2>/dev/null)"

RUN_BG="$(echo "$GMS_APPOPS" | grep -i "RUN_ANY_IN_BACKGROUND" | head -1)"
WAKE_LOCK="$(echo "$GMS_APPOPS" | grep -i "WAKE_LOCK" | head -1)"

if [ -n "$RUN_BG" ]; then
    info "RUN_ANY_IN_BACKGROUND: $RUN_BG"
fi

if [ -n "$WAKE_LOCK" ]; then
    info "WAKE_LOCK: $WAKE_LOCK"
fi

# ------------------------------------------------------------
# XtremeBS configuration
# ------------------------------------------------------------

if [ -f "$XBS_CONF" ]; then

    XBS_DELAY="$(grep "^delay=" "$XBS_CONF" 2>/dev/null | cut -d= -f2)"
    XBS_LOG_LEVEL="$(grep "^log_level=" "$XBS_CONF" 2>/dev/null | cut -d= -f2)"

    if [ -n "$XBS_DELAY" ]; then
        info "XtremeBS event delay: ${XBS_DELAY}s"
    fi

    if [ -n "$XBS_LOG_LEVEL" ]; then
        info "XtremeBS log level: $XBS_LOG_LEVEL"
    fi

    SCREEN_BLOCK="$(sed -n '/^screen_off={/,/^}/p' "$XBS_CONF")"

    if echo "$SCREEN_BLOCK" | grep -q "doze=deep"; then
        pass "XtremeBS screen-off deep Doze is configured."
    else
        warn "XtremeBS screen-off deep Doze configuration was not detected."
    fi

    ANDROID_VERSION="$(getprop ro.build.version.release)"

    if [ "$ANDROID_VERSION" = "16" ]; then
        EXPECTED_CORES="cpu4 cpu5 cpu6 cpu7"
    elif [ "$ANDROID_VERSION" = "15" ]; then
        EXPECTED_CORES="cpu6 cpu7"
    else
        EXPECTED_CORES=""
    fi

    if [ -n "$EXPECTED_CORES" ]; then

        SCREEN_CORES="$(echo "$SCREEN_BLOCK" | grep "^disable_cores=" | cut -d= -f2)"

        if [ "$SCREEN_CORES" = "$EXPECTED_CORES" ]; then
            pass "XtremeBS screen-off CPU configuration matches Android $ANDROID_VERSION."
        elif [ -n "$SCREEN_CORES" ]; then
            warn "XtremeBS screen-off CPU configuration differs from the expected Android $ANDROID_VERSION setup."
            info "Configured CPU cores: $SCREEN_CORES"
            info "Expected CPU cores: $EXPECTED_CORES"
        else
            warn "XtremeBS screen-off CPU configuration was not detected."
        fi
    fi

else
    fail "XtremeBS configuration file does not exist."
fi

# ------------------------------------------------------------
# XtremeBS status evidence
# ------------------------------------------------------------

if [ -f "$XBS_STATUS" ]; then

    info "XtremeBS current status:"

    while IFS= read -r LINE; do
        [ -n "$LINE" ] && info "$LINE"
    done < "$XBS_STATUS"

fi

# ------------------------------------------------------------
# XtremeBS recent log evidence
# ------------------------------------------------------------

if [ -f "$XBS_LOG" ]; then

    info "Recent XtremeBS log entries:"

    tail -5 "$XBS_LOG" 2>/dev/null | while IFS= read -r LINE; do
        [ -n "$LINE" ] && info "$LINE"
    done

fi

# ------------------------------------------------------------
# Power / battery evidence
# ------------------------------------------------------------

POWER_DUMP="$(dumpsys power 2>/dev/null)"
BATTERY_DUMP="$(dumpsys battery 2>/dev/null)"

BATTERY_LEVEL="$(echo "$BATTERY_DUMP" | grep "^  level:" | cut -d: -f2 | sed 's/^ *//')"
BATTERY_STATUS="$(echo "$BATTERY_DUMP" | grep "^  status:" | cut -d: -f2 | sed 's/^ *//')"

case "$BATTERY_STATUS" in
    2) CHARGE_STATUS="CHARGING" ;;
    3) CHARGE_STATUS="DISCHARGING" ;;
    4) CHARGE_STATUS="NOT CHARGING" ;;
    5) CHARGE_STATUS="FULL" ;;
    *) CHARGE_STATUS="UNKNOWN" ;;
esac

info "Battery level: ${BATTERY_LEVEL:-unknown}%"
info "Charging status: $CHARGE_STATUS"

WAKEFULNESS="$(echo "$POWER_DUMP" | grep "mWakefulness=" | head -1)"

if [ -n "$WAKEFULNESS" ]; then
    info "$WAKEFULNESS"
fi

if echo "$POWER_DUMP" | grep -q "Battery Saver is currently: ON"; then
    info "Standard Android Battery Saver: ON"
elif echo "$POWER_DUMP" | grep -q "Battery Saver is currently: OFF"; then
    info "Standard Android Battery Saver: OFF"
fi

# ------------------------------------------------------------
# CPU evidence
# ------------------------------------------------------------

CPU_COUNT="$(find /sys/devices/system/cpu -maxdepth 1 -type d -name 'cpu[0-9]*' 2>/dev/null | wc -l)"
ONLINE_CPUS="$(cat /sys/devices/system/cpu/online 2>/dev/null)"

info "Detected CPU cores: $CPU_COUNT"
info "Currently online CPUs: ${ONLINE_CPUS:-unknown}"

# ============================================================
# 5. OVERALL DIAGNOSTIC RESULT
# ============================================================

section "5" "OVERALL DIAGNOSTIC RESULT"

printf '\n'
printf '%b\n' "${GREEN}    PASS: $PASS_COUNT${RESET}"
printf '%b\n' "${YELLOW}    WARN: $WARN_COUNT${RESET}"
printf '%b\n' "${LIGHT_BLUE}    INFO: $INFO_COUNT${RESET}"
printf '%b\n' "${RED}    FAIL: $FAIL_COUNT${RESET}"
printf '\n'

if [ "$FAIL_COUNT" -gt 0 ]; then

    printf '%b\n' "${RED}    OVERALL: ATTENTION REQUIRED${RESET}"
    printf '%b\n' "${GRAY}    One or more required components could not be confirmed.${RESET}"
    printf '\n'

    printf '%b\n' "${RED}    FAILURE DETAILS:${RESET}"

    printf '%b\n' "$FAIL_DETAILS" |
    while IFS= read -r DETAIL; do
        [ -n "$DETAIL" ] &&
        printf '%b\n' "${GRAY}      [FAIL] $DETAIL${RESET}"
    done

    if [ "$WARN_COUNT" -gt 0 ]; then
        printf '\n'
        printf '%b\n' "${YELLOW}    WARNING DETAILS:${RESET}"

        printf '%b\n' "$WARN_DETAILS" |
        while IFS= read -r DETAIL; do
            [ -n "$DETAIL" ] &&
            printf '%b\n' "${GRAY}      [WARN] $DETAIL${RESET}"
        done
    fi

elif [ "$WARN_COUNT" -gt 0 ]; then

    printf '%b\n' "${YELLOW}    OVERALL: NO CONFIRMED FAILURE - WARNINGS PRESENT${RESET}"
    printf '%b\n' "${GRAY}    No confirmed failure was detected, but some conditions require review.${RESET}"
    printf '\n'

    printf '%b\n' "${YELLOW}    WARNING DETAILS:${RESET}"

    printf '%b\n' "$WARN_DETAILS" |
    while IFS= read -r DETAIL; do
        [ -n "$DETAIL" ] &&
        printf '%b\n' "${GRAY}      [WARN] $DETAIL${RESET}"
    done

else

    printf '%b\n' "${GREEN}    OVERALL: CONFIGURATION AND CURRENT STATE ARE CONSISTENT${RESET}"
    printf '%b\n' "${GRAY}    Required components are installed, enabled, and responding normally.${RESET}"
    printf '%b\n' "${GRAY}    Live operating checks are consistent with the configured setup.${RESET}"

fi

printf '\n'
printf '%b\n' "${WHITE}--------------------------------------------------${RESET}"
printf '%b\n' "${WHITE}               GMS CHECK COMPLETE${RESET}"
printf '%b\n' "${WHITE}--------------------------------------------------${RESET}"
printf '\n'