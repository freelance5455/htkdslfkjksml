#!/system/bin/sh

RESET='\033[0m'
GRAY='\033[0;90m'
WHITE='\033[1;37m'
GREEN='\033[0;32m'
LIGHT_BLUE='\033[38;5;39m'
YELLOW='\033[0;33m'
RED='\033[0;31m'
BROWN='\033[38;5;130m'

PASS=0
INFO=0
WARN=0
FAIL=0
CLEANED=0

WARN_ITEMS=""
FAIL_ITEMS=""
CLEANED_ITEMS=""

pass() {
    printf '%b\n' "${GREEN}PASS:${RESET} ${GRAY}$1${RESET}"
    PASS=$((PASS + 1))
}

info() {
    printf '%b\n' "${LIGHT_BLUE}INFO:${RESET} ${GRAY}$1${RESET}"
    INFO=$((INFO + 1))
}

warn() {
    printf '%b\n' "${YELLOW}WARNING:${RESET} ${GRAY}$1${RESET}"
    WARN=$((WARN + 1))
    WARN_ITEMS="${WARN_ITEMS}- $1\n"
}

fail() {
    printf '%b\n' "${RED}FAIL:${RESET} ${GRAY}$1${RESET}"
    FAIL=$((FAIL + 1))
    FAIL_ITEMS="${FAIL_ITEMS}- $1\n"
}

cleaned() {
    printf '%b\n' "${GREEN}CLEANED:${RESET} ${GRAY}$1${RESET}"
    CLEANED=$((CLEANED + 1))
    CLEANED_ITEMS="${CLEANED_ITEMS}- $1\n"
}

section() {
    printf '\n'
    printf '%b\n' "${BROWN}[$1] $2${RESET}"
    printf '%b\n' "${WHITE}--------------------------------------------------${RESET}"
}

printf '%b\n' "${WHITE}==================================================${RESET}"
printf '%b\n' "${WHITE}             ANDROID MAGISK CHECK${RESET}"
printf '%b\n' "${WHITE}==================================================${RESET}"
printf '\n'

section "1" "PLATFORM"

ANDROID=$(getprop ro.build.version.release 2>/dev/null)
API=$(getprop ro.build.version.sdk 2>/dev/null)

printf '%b\n' "${GRAY}Android: $ANDROID${RESET}"
printf '%b\n' "${GRAY}API:     $API${RESET}"

if [ "$ANDROID" = "15" ] && [ "$API" = "35" ]; then
    pass "Android 15 / API 35 detected"
elif [ "$ANDROID" = "16" ] && [ "$API" = "36" ]; then
    pass "Android 16 / API 36 detected"
else
    warn "Unsupported Android version/API combination: Android $ANDROID / API $API"
fi

section "2" "MAGISK"

MAGISK_VERSION=$(magisk -v 2>/dev/null)

if [ -n "$MAGISK_VERSION" ]; then
    pass "Magisk detected: $MAGISK_VERSION"
else
    fail "Magisk executable or version unavailable"
fi

if [ "$(id -u)" = "0" ]; then
    pass "Running with root UID 0"
else
    fail "Script is not running as root"
fi

SELINUX=$(getenforce 2>/dev/null)

printf '%b\n' "${GRAY}SELinux: $SELINUX${RESET}"

if [ "$SELINUX" = "Enforcing" ]; then
    pass "SELinux is Enforcing"
else
    warn "SELinux mode is $SELINUX"
fi

if command -v su >/dev/null 2>&1; then
    ROOT_ID=$(su -c id 2>/dev/null)

    case "$ROOT_ID" in
        *"uid=0"*)
            info "su root access is available"
            ;;
        *)
            warn "su exists but root access could not be confirmed"
            ;;
    esac
else
    info "su binary not found in PATH"
fi

section "3" "MAGISK DAEMON"

if ps -A 2>/dev/null | grep -q '[m]agiskd'; then
    pass "magiskd is running"
else
    fail "magiskd is not running"
fi

if ps -A 2>/dev/null | grep -q '[z]ygiskd64'; then
    pass "zygiskd64 is running"
else
    warn "zygiskd64 was not detected"
fi

section "4" "MAGISK DIRECTORIES"

for DIR in /data/adb /data/adb/modules /data/adb/service.d /data/adb/post-fs-data.d
do
    if [ -d "$DIR" ]; then
        pass "$DIR exists"
    else
        fail "$DIR is missing"
    fi
done

section "5" "MODULE HEALTH"

MODULE_COUNT=0
MODULE_DISABLED=0

if [ -d /data/adb/modules ]; then

    for MODULE in /data/adb/modules/*
    do
        [ -d "$MODULE" ] || continue

        MODULE_COUNT=$((MODULE_COUNT + 1))
        ID=$(basename "$MODULE")

        printf '\n'
        printf '%b\n' "${LIGHT_BLUE}MODULE: $ID${RESET}"

        if [ -f "$MODULE/module.prop" ]; then

            NAME=$(grep '^name=' "$MODULE/module.prop" | cut -d= -f2-)
            VERSION=$(grep '^version=' "$MODULE/module.prop" | cut -d= -f2-)

            printf '%b\n' "${GRAY}Name: ${NAME:-unknown}${RESET}"
            printf '%b\n' "${GRAY}Version: ${VERSION:-unknown}${RESET}"

            pass "$ID has module.prop"

        else
            fail "$ID is missing module.prop"
        fi

        if [ -f "$MODULE/remove" ]; then
            warn "$ID is marked for removal"
        fi

        if [ -f "$MODULE/disable" ]; then
            MODULE_DISABLED=$((MODULE_DISABLED + 1))
            warn "$ID is disabled"
        fi

    done

else
    fail "Module directory unavailable"
fi

printf '\n'
printf '%b\n' "${GRAY}Installed modules: $MODULE_COUNT${RESET}"
printf '%b\n' "${GRAY}Disabled modules:  $MODULE_DISABLED${RESET}"

section "6" "BOOT SCRIPTS"

for DIR in /data/adb/post-fs-data.d /data/adb/service.d
do
    printf '\n'
    printf '%b\n' "${LIGHT_BLUE}DIRECTORY: $DIR${RESET}"

    if [ -d "$DIR" ]; then

        FILE_COUNT=$(find "$DIR" -type f 2>/dev/null | wc -l)

        if [ "$FILE_COUNT" -eq 0 ]; then
            pass "$DIR contains no scripts"
        else
            printf '%b\n' "${GRAY}Scripts found: $FILE_COUNT${RESET}"
            find "$DIR" -maxdepth 1 -type f -print 2>/dev/null
        fi
    fi
done

section "7" "MODULE EXECUTION SCRIPTS"

EXECUTION_FILES=""

if [ -d /data/adb/modules ]; then
    for MODULE in /data/adb/modules/*
    do
        [ -d "$MODULE" ] || continue
        [ -f "$MODULE/disable" ] && continue
        [ -f "$MODULE/remove" ] && continue

        for FILE in \
            "$MODULE/post-fs-data.sh" \
            "$MODULE/service.sh" \
            "$MODULE/boot-completed.sh"
        do
            [ -f "$FILE" ] || continue
            EXECUTION_FILES="${EXECUTION_FILES}${FILE}
"
        done
    done
fi

if [ -n "$EXECUTION_FILES" ]; then
    printf '%b\n' "${GRAY}${EXECUTION_FILES}${RESET}"
else
    info "No module execution scripts found."
fi

section "8" "ZYGISK"

ZYGISK_FILES=""

if [ -d /data/adb/modules ]; then
    for MODULE in /data/adb/modules/*
    do
        [ -d "$MODULE" ] || continue
        [ -f "$MODULE/disable" ] && continue
        [ -f "$MODULE/remove" ] && continue

        if [ -d "$MODULE/zygisk" ]; then
            find "$MODULE/zygisk" -type f -print 2>/dev/null
        fi

        find "$MODULE" -type f -name "libzygisk.so" -print 2>/dev/null
    done
fi

ACTIVE_ZYGISK=""

for FILE in /system/lib/libzygisk.so /system/lib64/libzygisk.so
do
    if [ -f "$FILE" ]; then
        ACTIVE_ZYGISK="${ACTIVE_ZYGISK}${FILE}
"
    fi
done

if [ -n "$ZYGISK_FILES" ] || [ -n "$ACTIVE_ZYGISK" ]; then

    pass "Zygisk files detected"

    if [ -n "$ZYGISK_FILES" ]; then
        printf '%b\n' "${GRAY}${ZYGISK_FILES}${RESET}"
    fi

    if [ -n "$ACTIVE_ZYGISK" ]; then
        printf '%b' "${GRAY}${ACTIVE_ZYGISK}${RESET}"
    fi

else
    warn "No Zygisk files detected"
fi

section "9" "TEMPORARY / BACKUP FILES"

TEMP_FILES=""

if [ -d /data/adb/modules ]; then
    TEMP_FILES=$(find /data/adb/modules -type f \
        \( -name ".tmp" -o -name ".bak" -o -name ".old" -o -name "~" \
        -o -name "*.tmp" -o -name "*.bak" -o -name "*.old" -o -name "*~" \) \
        -print 2>/dev/null)
fi

if [ -n "$TEMP_FILES" ]; then
    warn "Potential temporary or backup files found"
    printf '%b\n' "${YELLOW}${TEMP_FILES}${RESET}"
else
    pass "No obvious temporary or backup files found"
fi

section "10" "MAGISK MOUNTS"

MAGISK_MOUNTS=$(mount 2>/dev/null | grep -E 'magisk|/system/.+tmpfs|/product/.+tmpfs')

if [ -n "$MAGISK_MOUNTS" ]; then
    pass "Active Magisk mounts detected"
    printf '%b\n' "${GRAY}${MAGISK_MOUNTS}${RESET}"
else
    warn "No active Magisk mounts detected"
fi

section "11" "SERVICE.D REVIEW"

SERVICE_FOUND=0

if [ -d /data/adb/service.d ]; then

    for FILE in /data/adb/service.d/.[!.]* /data/adb/service.d/*
    do
        [ -f "$FILE" ] || continue

        SERVICE_FOUND=1
        NAME=$(basename "$FILE")

        if [ -x "$FILE" ]; then
            printf '%b\n' "${GREEN}ACTIVE SCRIPT: $NAME${RESET}"
        else
            warn "Non-executable service.d file: $NAME"
        fi
    done

fi

if [ "$SERVICE_FOUND" -eq 0 ]; then
    pass "No service.d scripts found"
fi

section "12" "MAGISK LOG"

if [ -f /cache/magisk.log ]; then

    LOG_ERRORS=$(grep -iE 'error|fail|failed|denied' /cache/magisk.log 2>/dev/null)

    if [ -n "$LOG_ERRORS" ]; then
        warn "Magisk log contains error/failure/denied entries"
        printf '%b\n' "${YELLOW}${LOG_ERRORS}${RESET}" | tail -30
    else
        pass "No obvious Magisk errors in current log"
    fi

else
    info "Magisk log not found at /cache/magisk.log"
fi

printf '\n'
printf '%b\n' "${WHITE}==================================================${RESET}"
printf '%b\n' "${WHITE}                 MAGISK SUMMARY${RESET}"
printf '%b\n' "${WHITE}==================================================${RESET}"
printf '\n'

printf '%b\n' "${GREEN}PASS:    $PASS${RESET}"
printf '%b\n' "${LIGHT_BLUE}INFO:    $INFO${RESET}"
printf '%b\n' "${YELLOW}WARNING: $WARN${RESET}"
printf '%b\n' "${RED}FAIL:    $FAIL${RESET}"
printf '%b\n' "${GREEN}CLEANED: $CLEANED${RESET}"
printf '\n'

if [ "$WARN" -gt 0 ]; then
    printf '%b\n' "${YELLOW}---------------- WARNING DETAILS ----------------${RESET}"
    printf "%b" "$WARN_ITEMS"
    printf '\n'
fi

if [ "$FAIL" -gt 0 ]; then
    printf '%b\n' "${RED}------------------ FAIL DETAILS -----------------${RESET}"
    printf "%b" "$FAIL_ITEMS"
    printf '\n'
fi

if [ "$CLEANED" -gt 0 ]; then
    printf '%b\n' "${GREEN}---------------- CLEANED ITEMS ------------------${RESET}"
    printf "%b" "$CLEANED_ITEMS"
    printf '\n'
fi

printf '%b\n' "${WHITE}--------------------------------------------------${RESET}"

if [ "$FAIL" -gt 0 ]; then
    printf '%b\n' "${RED}RESULT: FAIL${RESET}"
elif [ "$WARN" -gt 0 ]; then
    printf '%b\n' "${YELLOW}RESULT: WARNING - REVIEW ITEMS ABOVE${RESET}"
else
    printf '%b\n' "${GREEN}RESULT: PASS - NO PROBLEMS DETECTED${RESET}"
fi

printf '%b\n' "${WHITE}--------------------------------------------------${RESET}"
printf '\n'
printf '%b\n' "${GRAY}Questionable items are reported only.${RESET}"
printf '%b\n' "${GRAY}No questionable Magisk data is automatically deleted.${RESET}"
printf '\n'
printf '%b\n' "${WHITE}==================================================${RESET}"
printf '%b\n' "${WHITE}          MAGISK CHECK COMPLETE${RESET}"
printf '%b\n' "${WHITE}==================================================${RESET}"