#!/system/bin/sh

RESET='\033[0m'
GRAY='\033[0;90m'
WHITE='\033[1;37m'
GREEN='\033[0;32m'
LIGHT_BLUE='\033[38;5;39m'
YELLOW='\033[0;33m'
RED='\033[0;31m'
BROWN='\033[38;5;130m'

PASS=0
INFO=0
WARN=0
FAIL=0
CLEANED=0

WARN_ITEMS=""
FAIL_ITEMS=""
CLEANED_ITEMS=""

pass() {
printf '%b\n' "${GREEN}PASS:${RESET} ${GRAY}$1${RESET}"
PASS=$((PASS + 1))
}

info() {
printf '%b\n' "${LIGHT_BLUE}INFO:${RESET} ${GRAY}$1${RESET}"
INFO=$((INFO + 1))
}

warn() {
printf '%b\n' "${YELLOW}WARNING:${RESET} ${GRAY}$1${RESET}"
WARN=$((WARN + 1))
WARN_ITEMS="${WARN_ITEMS}- $1\n"
}

fail() {
printf '%b\n' "${RED}FAIL:${RESET} ${GRAY}$1${RESET}"
FAIL=$((FAIL + 1))
FAIL_ITEMS="${FAIL_ITEMS}- $1\n"
}

cleaned() {
printf '%b\n' "${GREEN}CLEANED:${RESET} ${GRAY}$1${RESET}"
CLEANED=$((CLEANED + 1))
CLEANED_ITEMS="${CLEANED_ITEMS}- $1\n"
}

section() {
printf '\n'
printf '%b\n' "${BROWN}[$1] $2${RESET}"
printf '%b\n' "${WHITE}--------------------------------------------------${RESET}"
}

settings_get() {
RESULT=$(settings get "$1" "$2" 2>/dev/null)

case "$RESULT" in
    "cmd: Failure"*|"Failure calling service"*|"Error:"*)
        return 1
        ;;
esac

if [ "$RESULT" = "null" ]; then
    return 1
fi

printf '%s\n' "$RESULT"
return 0
}

cmd_get() {
RESULT=$("$@" 2>/dev/null)

case "$RESULT" in
    "cmd: Failure"*|"Failure calling service"*|"Error:"*)
        return 1
        ;;
esac

if [ -z "$RESULT" ]; then
    return 1
fi

printf '%s\n' "$RESULT"
return 0
}

printf '%b\n' "${WHITE}==================================================${RESET}"
printf '%b\n' "${WHITE}          ANDROID SYSTEM HEALTH CHECK${RESET}"
printf '%b\n' "${WHITE}==================================================${RESET}"
printf '\n'

DEVICE=$(getprop ro.product.model 2>/dev/null)
MANUFACTURER=$(getprop ro.product.manufacturer 2>/dev/null)
BUILD=$(getprop ro.build.display.id 2>/dev/null)
BUILD_TYPE=$(getprop ro.build.type 2>/dev/null)
SECURITY_PATCH=$(getprop ro.build.version.security_patch 2>/dev/null)

printf '%b\n' "${GRAY}Device:  ${MANUFACTURER} ${DEVICE}${RESET}"
printf '%b\n' "${GRAY}Build:   ${BUILD}${RESET}"
printf '%b\n' "${GRAY}Patch:   ${SECURITY_PATCH}${RESET}"

section "1" "VERIFIED BOOT"

VB_STATE=$(getprop ro.boot.verifiedbootstate 2>/dev/null)
FLASH_LOCKED=$(getprop ro.boot.flash.locked 2>/dev/null)

if [ "$VB_STATE" = "green" ]; then
pass "Verified Boot state is green"
elif [ "$VB_STATE" = "orange" ]; then
info "Verified Boot state is orange"
elif [ -n "$VB_STATE" ]; then
info "Verified Boot state: $VB_STATE"
fi

if [ "$FLASH_LOCKED" = "1" ]; then
pass "Bootloader reports locked"
elif [ "$FLASH_LOCKED" = "0" ]; then
info "Bootloader reports unlocked"
fi

section "2" "SELINUX"

SELINUX=$(getenforce 2>/dev/null)

printf '%b\n' "${GRAY}SELinux: $SELINUX${RESET}"

if [ "$SELINUX" = "Enforcing" ]; then
pass "SELinux is Enforcing"
elif [ "$SELINUX" = "Permissive" ]; then
warn "SELinux is Permissive"
fi

section "3" "ADB + DEVELOPER ACCESS"

ADB_ENABLED=$(settings_get global adb_enabled)
ADB_WIFI=$(settings_get global adb_wifi_enabled)
DEVELOPMENT=$(settings_get global development_settings_enabled)
ADB_SECURE=$(getprop ro.adb.secure 2>/dev/null)

if [ "$ADB_ENABLED" = "1" ]; then
warn "USB debugging is enabled"
elif [ "$ADB_ENABLED" = "0" ]; then
pass "USB debugging is disabled"
fi

if [ "$ADB_WIFI" = "1" ]; then
warn "Wireless debugging is enabled"
elif [ "$ADB_WIFI" = "0" ]; then
pass "Wireless debugging is disabled"
fi

if [ "$DEVELOPMENT" = "1" ]; then
info "Developer options are enabled"
elif [ "$DEVELOPMENT" = "0" ]; then
pass "Developer options are disabled"
fi

if [ "$ADB_SECURE" = "1" ]; then
pass "ADB authentication is enabled"
elif [ "$ADB_SECURE" = "0" ]; then
warn "ADB authentication is disabled"
fi

section "4" "NETWORK CONFIGURATION"

PRIVATE_DNS=$(settings_get global private_dns_mode)

if [ -z "$PRIVATE_DNS" ]; then
PRIVATE_DNS=$(settings_get global private_dns_default_mode)
fi

case "$PRIVATE_DNS" in
off)
info "Private DNS is disabled"
;;
opportunistic)
info "Private DNS is automatic"
;;
hostname)
PRIVATE_DNS_HOST=$(settings_get global private_dns_specifier)

if [ -n "$PRIVATE_DNS_HOST" ]; then
    info "Private DNS provider: $PRIVATE_DNS_HOST"
else
    info "Private DNS provider mode is enabled"
fi
;;
"")
;;
*)
info "Private DNS mode: $PRIVATE_DNS"
;;
esac

HTTP_PROXY=$(settings_get global http_proxy)
GLOBAL_PROXY_HOST=$(settings_get global global_http_proxy_host)
GLOBAL_PROXY_PORT=$(settings_get global global_http_proxy_port)
GLOBAL_PROXY_PAC=$(settings_get global global_proxy_pac_url)

if [ -n "$HTTP_PROXY" ] && [ "$HTTP_PROXY" != ":0" ]; then

warn "System HTTP proxy is configured: $HTTP_PROXY"

elif [ -n "$GLOBAL_PROXY_HOST" ]; then

if [ -n "$GLOBAL_PROXY_PORT" ]; then
    warn "Global HTTP proxy is configured: ${GLOBAL_PROXY_HOST}:${GLOBAL_PROXY_PORT}"
else
    warn "Global HTTP proxy is configured: $GLOBAL_PROXY_HOST"
fi

elif [ -n "$GLOBAL_PROXY_PAC" ]; then

warn "Global proxy PAC URL is configured"

else

pass "No system HTTP proxy configured"

fi

section "5" "NETWORK EXPOSURE"

NETWORK_TOOL=""

if command -v ss >/dev/null 2>&1; then
NETWORK_TOOL="ss"
elif command -v netstat >/dev/null 2>&1; then
NETWORK_TOOL="netstat"
fi

if [ -n "$NETWORK_TOOL" ]; then

LISTENING=$($NETWORK_TOOL -lnt 2>/dev/null | grep "LISTEN")

if [ -n "$LISTENING" ]; then

echo "$LISTENING"

EXTERNAL_LISTENERS=$(printf '%s\n' "$LISTENING" | \
    grep -Ev '127\.0\.0\.1:|::ffff:127\.0\.0\.1:|\[::1\]:' | \
    grep -E '0\.0\.0\.0:|0:0:0:0:0:0:0:0:|\[::\]:|[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+:')

if [ -n "$EXTERNAL_LISTENERS" ]; then
    warn "Externally reachable TCP listening socket(s) detected"
else
    info "TCP listening socket(s) detected, but they are bound to loopback only"
fi

else
pass "No TCP listening sockets detected"
fi

else
info "Network socket inspection tool not installed"
fi

if command -v ip >/dev/null 2>&1; then

ROUTES=$(ip route 2>/dev/null)

if [ -n "$ROUTES" ]; then
    info "Active network routes detected"
    echo "$ROUTES"
fi

fi

section "6" "FIREWALL"

if command -v iptables >/dev/null 2>&1; then

FIREWALL_RULES=$(iptables -L -n 2>/dev/null | \
    grep -v '^Chain\|^target')

if [ -n "$FIREWALL_RULES" ]; then
    info "iptables rules detected"
else
    info "No readable iptables rules detected"
fi

fi

if command -v nft >/dev/null 2>&1; then
info "nftables command available"
fi

section "7" "SECURITY PROPERTIES"

DEBUGGABLE=$(getprop ro.debuggable 2>/dev/null)
SECURE=$(getprop ro.secure 2>/dev/null)
QEMU=$(getprop ro.kernel.qemu 2>/dev/null)

if [ "$DEBUGGABLE" = "1" ]; then

if [ "$BUILD_TYPE" = "userdebug" ]; then
    info "ro.debuggable is enabled for a userdebug build"
else
    warn "ro.debuggable is enabled"
fi

elif [ "$DEBUGGABLE" = "0" ]; then
pass "ro.debuggable is disabled"
fi

if [ "$SECURE" = "0" ]; then
warn "ro.secure is disabled"
elif [ "$SECURE" = "1" ]; then
info "ro.secure = 1"
fi

if [ "$QEMU" = "1" ]; then
warn "System reports emulator mode"
else
pass "System does not report emulator mode"
fi

section "8" "SPECIAL ACCESS"

ACCESSIBILITY=$(settings_get secure enabled_accessibility_services)

if [ -n "$ACCESSIBILITY" ]; then
info "Accessibility service(s) enabled:"
echo "$ACCESSIBILITY"
else
pass "No accessibility service enabled"
fi

INPUT_METHODS=$(settings_get secure enabled_input_methods)
DEFAULT_INPUT_METHOD=$(settings_get secure default_input_method)

if [ -n "$INPUT_METHODS" ]; then
info "Enabled input methods:"
echo "$INPUT_METHODS"
fi

if [ -n "$DEFAULT_INPUT_METHOD" ]; then
info "Default input method: $DEFAULT_INPUT_METHOD"
fi

section "9" "DEVICE ADMINISTRATION"

if command -v dumpsys >/dev/null 2>&1; then

DEVICE_POLICY=$(dumpsys device_policy 2>/dev/null)

if [ -n "$DEVICE_POLICY" ]; then

ACTIVE_ADMINS=$(printf '%s\n' "$DEVICE_POLICY" | \
    grep -E '^[[:space:]]*(Active admin|Active admins|Device Owner|Profile Owner|Device Owner Type)')

if [ -n "$ACTIVE_ADMINS" ]; then
    info "Device administration information detected"
    echo "$ACTIVE_ADMINS"
else
    pass "No active device administrator reported"
fi

fi

fi

section "10" "INSTALLED APPLICATIONS"

TOTAL_PACKAGES=$(dumpsys package packages 2>/dev/null |
    grep -c '^  Package \[')

if [ "$TOTAL_PACKAGES" -gt 0 ] 2>/dev/null; then
    info "Total packages: $TOTAL_PACKAGES"
    pass "Package database is accessible"
else
    warn "Unable to retrieve installed package information"
fi

section "11" "ACTIVE USERS & PROFILES"

USERS=""
USER_SOURCE=""

USERS=$(cmd user list 2>/dev/null)
if printf '%s\n' "$USERS" | grep -q "UserInfo{"; then
    USER_SOURCE="cmd user list"
else
    USERS=$(dumpsys user 2>/dev/null)
    if printf '%s\n' "$USERS" | grep -q "UserInfo{"; then
        USER_SOURCE="dumpsys user"
    else
        USERS=""
    fi
fi

if [ -n "$USERS" ]; then
    USER_COUNT=$(printf '%s\n' "$USERS" | grep -c "UserInfo{" 2>/dev/null)

    USER_NAME=$(printf '%s\n' "$USERS" |
        sed -n 's/.*UserInfo{[0-9]*:\([^:}]*\):.*/\1/p' |
        head -n 1)

    if [ -n "$USER_NAME" ]; then
        info "User name: $USER_NAME"
    fi

    info "Profiles/users detected: $USER_COUNT"

    if [ "$USER_COUNT" -gt 1 ] 2>/dev/null; then
    warn "Secondary user or profile detected"
else
    pass "No guest or secondary user detected"
fi
else
    warn "Unable to retrieve user/profile information"
fi

section "12" "SENSITIVE PATHS"

if [ -e "/system/app/Superuser.apk" ]; then
warn "Traditional Superuser application detected"
else
pass "No traditional Superuser application detected"
fi

section "13" "TEMPORARY LOCATIONS"

TMP_FILES=$(find /data/local/tmp -maxdepth 1 -type f 2>/dev/null)

if [ -n "$TMP_FILES" ]; then
    TMP_COUNT=$(printf '%s\n' "$TMP_FILES" | wc -l)
    info "Files in /data/local/tmp: $TMP_COUNT"
    printf '%s\n' "$TMP_FILES"
else
    pass "No regular files detected in /data/local/tmp"
fi

section "14" "RUNNING PROCESSES"

if command -v ps >/dev/null 2>&1; then

SUSPICIOUS_PROCESSES=$(ps -A 2>/dev/null | \
    grep -Ei '(^|[[:space:]/])sshd([[:space:]]|$)|(^|[[:space:]/])dropbear([[:space:]]|$)|(^|[[:space:]/])telnetd([[:space:]]|$)|(^|[[:space:]/])frpc([[:space:]]|$)|(^|[[:space:]/])frps([[:space:]]|$)|(^|[[:space:]/])netcat([[:space:]]|$)|(^|[[:space:]/])nc([[:space:]]|$)|(^|[[:space:]/])socat([[:space:]]|$)' | \
    grep -v 'grep -E' | \
    grep -v 'grep -Ei')

if [ -n "$SUSPICIOUS_PROCESSES" ]; then
warn "Potential remote-access or tunneling process detected"
echo "$SUSPICIOUS_PROCESSES"
else
pass "No common remote-access or tunneling processes detected"
fi

fi

section "15" "BOOT + CRASH EVIDENCE"

BOOT_REASON=$(getprop ro.boot.bootreason 2>/dev/null)

if [ -n "$BOOT_REASON" ]; then

case "$BOOT_REASON" in
    watchdog|kernel_panic|thermal|hard_reset|hw_reset)
        warn "Possible abnormal restart reason: $BOOT_REASON"
        ;;
    *)
        info "Boot reason: $BOOT_REASON"
        ;;
esac

fi

if [ -d "/data/tombstones" ]; then

TOMBSTONES=$(find /data/tombstones -maxdepth 1 -type f 2>/dev/null | wc -l)

if [ "$TOMBSTONES" -gt 0 ]; then
warn "Crash tombstone files detected: $TOMBSTONES"
else
pass "No crash tombstone files detected"
fi

fi

if [ -d "/data/anr" ]; then

ANR_COUNT=$(find /data/anr -maxdepth 1 -type f 2>/dev/null | wc -l)

if [ "$ANR_COUNT" -gt 0 ]; then
info "ANR records detected: $ANR_COUNT"
else
pass "No ANR records detected"
fi

fi

if [ -d "/sys/fs/pstore" ]; then

PSTORE_COUNT=$(find /sys/fs/pstore -maxdepth 1 -type f 2>/dev/null | wc -l)

if [ "$PSTORE_COUNT" -gt 0 ]; then
info "Persistent pstore records detected: $PSTORE_COUNT"
info "Pstore may contain evidence from previous kernel or reboot events"
else
pass "No pstore records detected"
fi

fi

section "16" "SECURITY PATCH"

if [ -n "$SECURITY_PATCH" ]; then

PATCH_EPOCH=$(date -d "$SECURITY_PATCH" +%s 2>/dev/null)
CURRENT_EPOCH=$(date +%s 2>/dev/null)

if [ -n "$PATCH_EPOCH" ] && [ -n "$CURRENT_EPOCH" ]; then

PATCH_AGE=$(( (CURRENT_EPOCH - PATCH_EPOCH) / 86400 ))

if [ "$PATCH_AGE" -le 120 ]; then
info "Security patch is approximately $PATCH_AGE days old"
else
warn "Security patch is approximately $PATCH_AGE days old"
fi

else
info "Security patch: $SECURITY_PATCH"
fi

else
warn "Security patch level could not be determined"
fi

section "17" "PROTECTED DIRECTORY"

printf '%b\n' "${LIGHT_BLUE}/data/local/tmp/XtremeBS${RESET}"
printf '%b\n' "${YELLOW}NOT TOUCHED${RESET}"
pass "XtremeBS directory protected"

printf '\n'
printf '%b\n' "${WHITE}==================================================${RESET}"
printf '%b\n' "${WHITE}              SYSTEM HEALTH SUMMARY${RESET}"
printf '%b\n' "${WHITE}==================================================${RESET}"
printf '\n'

printf '%b\n' "${GREEN}PASS:${RESET}    ${GRAY}$PASS${RESET}"
printf '%b\n' "${LIGHT_BLUE}INFO:${RESET}    ${GRAY}$INFO${RESET}"
printf '%b\n' "${YELLOW}WARNING:${RESET} ${GRAY}$WARN${RESET}"
printf '%b\n' "${RED}FAIL:${RESET}    ${GRAY}$FAIL${RESET}"
printf '%b\n' "${GREEN}CLEANED:${RESET} ${GRAY}$CLEANED${RESET}"
printf '\n'

if [ "$WARN" -gt 0 ]; then
printf '%b\n' "${YELLOW}---------------- WARNING DETAILS ----------------${RESET}"
printf "%b" "$WARN_ITEMS"
printf '\n'
fi

if [ "$FAIL" -gt 0 ]; then
printf '%b\n' "${RED}------------------ FAIL DETAILS -----------------${RESET}"
printf "%b" "$FAIL_ITEMS"
printf '\n'
fi

if [ "$CLEANED" -gt 0 ]; then
printf '%b\n' "${GREEN}---------------- CLEANED ITEMS ------------------${RESET}"
printf "%b" "$CLEANED_ITEMS"
printf '\n'
fi

printf '%b\n' "${WHITE}--------------------------------------------------${RESET}"

if [ "$FAIL" -gt 0 ]; then
printf '%b\n' "${RED}RESULT:${RESET} ${GRAY}FAIL${RESET}"
elif [ "$WARN" -gt 0 ]; then
printf '%b\n' "${YELLOW}RESULT:${RESET} ${GRAY}WARNING - REVIEW ITEMS ABOVE${RESET}"
else
printf '%b\n' "${GREEN}RESULT:${RESET} ${GRAY}PASS - NO PROBLEMS DETECTED${RESET}"
fi

printf '%b\n' "${WHITE}--------------------------------------------------${RESET}"
printf '\n'
printf '%b\n' "${GRAY}Questionable items are reported only.${RESET}"
printf '%b\n' "${GRAY}This audit is read-only.${RESET}"
printf '%b\n' "${GRAY}No files, modules, settings, permissions, or system components were modified.${RESET}"
printf '\n'

printf '%b\n' "${WHITE}==================================================${RESET}"
printf '%b\n' "${WHITE}       ANDROID SYSTEM HEALTH CHECK COMPLETE${RESET}"
printf '%b\n' "${WHITE}==================================================${RESET}"

exit 0