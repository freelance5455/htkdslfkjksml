#!/system/bin/sh

script_dir="/data/user/0/com.termoneplus/app_HOME"

green='\033[0;32m'
cyan='\033[38;5;39m'
white='\033[1;37m'
yellow='\033[0;33m'
red='\033[0;31m'
gray='\033[0;90m'
brown='\033[38;5;130m'
reset='\033[0m'

get_term_width() {
WIDTH="$(stty size 2>/dev/null | awk '{print $2}')"

case "$WIDTH" in
    ''|*[!0-9]*)
        WIDTH="${COLUMNS:-80}"
        ;;
esac

[ "$WIDTH" -lt 40 ] && WIDTH=40

printf '%s' "$WIDTH"
}

center_text() {
TEXT="$1"
WIDTH="$(get_term_width)"
LENGTH="${#TEXT}"
PADDING=$(( (WIDTH - LENGTH) / 2 ))

[ "$PADDING" -lt 0 ] && PADDING=0

printf "%*s%s\n" "$PADDING" "" "$TEXT"
}

menu_item() {
NUMBER="$1"
NAME="$2"
DESCRIPTION="$3"
COLOR="$4"

WIDTH="$(get_term_width)"
PREFIX="${NUMBER}. ${NAME}: "
PREFIX_LENGTH="${#PREFIX}"
AVAILABLE=$((WIDTH - PREFIX_LENGTH))

[ "$AVAILABLE" -lt 20 ] && AVAILABLE=20

FIRST_LINE=1
LINE=""

OLD_IFS="$IFS"
IFS=' '

for WORD in $DESCRIPTION; do
    if [ -z "$LINE" ]; then
        LINE="$WORD"
    elif [ $(( ${#LINE} + 1 + ${#WORD} )) -le "$AVAILABLE" ]; then
        LINE="$LINE $WORD"
    else
        if [ "$FIRST_LINE" -eq 1 ]; then
            printf '%b\n' "${COLOR}${PREFIX}${reset}${gray}${LINE}${reset}"
            FIRST_LINE=0
        else
            printf '%b\n' "${gray}   ${LINE}${reset}"
        fi

        LINE="$WORD"
        AVAILABLE=$((WIDTH - 3))
    fi
done

if [ "$FIRST_LINE" -eq 1 ]; then
    printf '%b\n' "${COLOR}${PREFIX}${reset}${gray}${LINE}${reset}"
else
    printf '%b\n' "${gray}   ${LINE}${reset}"
fi

IFS="$OLD_IFS"
}

pause_screen() {
printf "\n${yellow}press enter to return to the menu...${reset}"
read dummy
}

run_script() {
script="$1"

test -f "$script_dir/$script" || {
    printf "\n${red}error:${reset} ${gray}$script was not found.${reset}\n"
    pause_screen
    return
}

test -x "$script_dir/$script" || {
    printf "\n${yellow}making $script executable...${reset}\n"
    chmod 755 "$script_dir/$script"
}

printf "\n${cyan}starting $script...${reset}\n\n"
"$script_dir/$script"

printf "\n${green}script finished.${reset}\n"
pause_screen
}

run_detach() {
printf "\n${cyan}starting zygisk detach...${reset}\n\n"

/data/adb/modules/zygisk-detach/detach

printf "\n${green}zygisk detach finished.${reset}\n"
pause_screen
}

reload_xbs() {
printf "\n${cyan}reloading extreme battery saver configuration...${reset}\n\n"

XBSctl reload

printf "\n${green}extreme battery saver configuration reloaded.${reset}\n"
pause_screen
}

show_menu() {
clear

printf "${brown}"
center_text "---------------------------"
center_text "ANDROID SYSTEM UTILITY MENU"
center_text "---------------------------"
printf "${reset}\n"

menu_item "1" "🩺 health" \
    "checks system health, security, SELinux, verified boot, developer access, crash evidence, and security patch status." \
    "$cyan"
printf "\n"

menu_item "2" "🪄 magisk" \
    "checks Magisk, root access, modules, Zygisk, boot scripts, Magisk mounts, and logs." \
    "$cyan"
printf "\n"

menu_item "3" "🇬 gms" \
    "checks gms, doze, battery saver, related settings, services, and configuration." \
    "$cyan"
printf "\n"

menu_item "4" "🧹 clean" \
    "cleans temporary, cached, leftover, unnecessary system files, logs, and safe storage." \
    "$cyan"
printf "\n"

menu_item "5" "🔗 zygisk detach" \
    "detach or re-attach selected apps from google play updates and automatic updates." \
    "$cyan"
printf "\n"

menu_item "6" "⚡ extreme battery saver reload" \
    "reloads Extreme Battery Saver configuration and settings." \
    "$cyan"
printf "\n"

menu_item "q" "❌ quit" \
    "exit the android system utility menu and return to root shell." \
    "$red"
printf "\n"

printf "${white}------------------------------${reset}\n"
printf "${yellow}select an option [1-6, q]: ${reset}"
}

while :
do
show_menu

old_stty="$(stty -g 2>/dev/null)"

stty -icanon min 1 time 0 2>/dev/null
choice="$(dd bs=1 count=1 2>/dev/null)"

stty "$old_stty" 2>/dev/null

printf "\n"

case "$choice" in
    1)
        run_script "health.sh"
        ;;
    2)
        run_script "magisk.sh"
        ;;
    3)
        run_script "gms.sh"
        ;;
    4)
        run_script "clean.sh"
        ;;
    5)
        run_detach
        ;;
    6)
        reload_xbs
        ;;
    q|Q)
        clear
        printf "${green}android system utility menu closed.${reset}\n"
        su
        exit 0
        ;;
    *)
        printf "\n${red}invalid option.${reset} ${gray}please select 1, 2, 3, 4, 5, or 6, or q.${reset}\n"
        sleep 1
        ;;
esac

done