#!/system/bin/sh

RESET='\033[0m'
GRAY='\033[0;90m'
WHITE='\033[1;37m'
GREEN='\033[0;32m'
LIGHT_BLUE='\033[38;5;39m'
RED='\033[0;31m'
BROWN='\033[38;5;130m'

[ "$(id -u)" -ne 0 ] && {
    printf '%b\n' "${RED}[FAIL]${RESET} ${GRAY}Needs root${RESET}"
    exit 1
}

printf '%b\n' "${BROWN}======================================${RESET}"
printf '%b\n' "${BROWN}     MODERATE+ SYSTEM CLEANUP${RESET}"
printf '%b\n' "${BROWN}======================================${RESET}"

ST=$(df /data | awk 'NR==2 {print $4}')

PROTECTED="/data/local/tmp/XtremeBS"

section() {
    printf '\n'
    printf '%b\n' "${LIGHT_BLUE}[$1]${RESET} ${GRAY}$2${RESET}"
    printf '%b\n' "${WHITE}--------------------------------------------------${RESET}"
}

section "1/6" "Preserving system diagnostic logs..."

printf '%b\n' "${GRAY}Crash, ANR, tombstone and system log data will NOT be deleted.${RESET}"

section "2/6" "Cleaning temporary files..."

if [ -d /data/local/tmp ]; then
    find /data/local/tmp \
        -mindepth 1 \
        \( -path "$PROTECTED" -o -path "$PROTECTED"/* \) -prune -o \
        -type f \
        -mtime +1 \
        -delete \
        >/dev/null 2>&1
fi

if [ -d /data/tmp ]; then
    find /data/tmp \
        -type f \
        -mtime +1 \
        -delete \
        >/dev/null 2>&1
fi

section "3/6" "Cleaning package-manager cache..."

if [ -d /data/system/package_cache ]; then
    rm -rf /data/system/package_cache/* 2>/dev/null
fi

section "4/6" "Flushing filesystem buffers..."

sync

section "5/6" "Running filesystem TRIM..."

if [ -d /data ]; then
    fstrim -v /data 2>/dev/null
fi

if [ -d /cache ]; then
    fstrim -v /cache 2>/dev/null
fi

section "6/6" "Final filesystem synchronization..."

sync

EN=$(df /data | awk 'NR==2 {print $4}')
FD=$((EN - ST))

[ "$FD" -lt 0 ] && FD=0

printf '%b\n' "${WHITE}======================================${RESET}"
printf '%b\n' "${GREEN}       CLEANUP COMPLETE${RESET}"
printf '%b\n' "${GRAY}       Diagnostic Logs: PRESERVED${RESET}"
printf '%b\n' "${GRAY}       FSTRIM: ENABLED${RESET}"
printf '%b\n' "${GRAY}       Storage Freed: $((FD / 1024)) MB${RESET}"
printf '%b\n' "${WHITE}======================================${RESET}"