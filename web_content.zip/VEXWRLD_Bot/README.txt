VEXWRLD Bot - Android WebView starter project

What it does:
- Opens the Streamerviewerbot free TikTok followers page.
- Opens the free TikTok views page.
- Opens the site's home page.
- Keeps website functionality online inside Android WebView.

Important limitations:
- This is source code, not a compiled/installable APK.
- Build with Android Studio (Gradle plugin 8.6.1, compile SDK 35).
- The website controls its own countdowns and server rules. This app cannot remove them.
- The app does not generate followers/views itself.
- Never enter your TikTok password into third-party follower/view services.

Package: com.vexwrld.bot
Minimum Android: 6.0 (API 23)
