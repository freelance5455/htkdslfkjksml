package com.vexwrld.bot;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.FrameLayout;

public class MainActivity extends Activity {
    private static final String FOLLOWERS = "https://streamerviewerbot.com/free-tiktok-followers/";
    private static final String VIEWS = "https://streamerviewerbot.com/free-tiktok-views/";
    private static final String HOME = "https://streamerviewerbot.com/";
    private FrameLayout root;
    private WebView web;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(9,11,18));
        getWindow().setNavigationBarColor(Color.rgb(9,11,18));
        showDashboard();
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private Button action(String label, int color, View.OnClickListener click) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setTextSize(16); b.setBackground(bg(color, 28)); b.setPadding(18,16,18,16); b.setOnClickListener(click); return b;
    }
    private void showDashboard() {
        root = new FrameLayout(this);
        LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(24,30,24,24); page.setBackgroundColor(Color.rgb(9,11,18));
        TextView brand = text("VEXWRLD BOT", 13, Color.rgb(167,139,250), true);
        page.addView(brand);
        TextView title = text("TikTok tools", 30, Color.WHITE, true);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1,-2); tp.topMargin=12; page.addView(title,tp);
        TextView sub = text("A simple shortcut dashboard for the original website.", 14, Color.rgb(180,185,198), false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1,-2); sp.topMargin=8; page.addView(sub,sp);
        TextView section = text("SERVICES", 12, Color.rgb(150,155,172), true);
        LinearLayout.LayoutParams secp = new LinearLayout.LayoutParams(-1,-2); secp.topMargin=34; secp.bottomMargin=12; page.addView(section,secp);
        Button followers = action("Open free TikTok followers", Color.rgb(124,86,220), v -> open(FOLLOWERS));
        page.addView(followers, new LinearLayout.LayoutParams(-1,58));
        Button views = action("Open free TikTok views", Color.rgb(42,53,76), v -> open(VIEWS));
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1,58); vp.topMargin=14; page.addView(views,vp);
        Button website = action("Open website home", Color.rgb(42,53,76), v -> open(HOME));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1,54); hp.topMargin=14; page.addView(website,hp);
        TextView note = text("Safety note: never enter your TikTok password on a follower/view service. These services are not affiliated with TikTok and may affect account trust or violate platform rules. This app does not generate followers or views and cannot change website cooldowns.", 12, Color.rgb(175,181,196), false);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1,-2); np.topMargin=28; page.addView(note,np);
        root.addView(page); setContentView(root);
    }
    private void open(String url) {
        web = new WebView(this);
        WebSettings s = web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setLoadsImagesAutomatically(true); s.setJavaScriptCanOpenWindowsAutomatically(false);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient());
        web.loadUrl(url);
        setContentView(web);
    }
    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) { web.goBack(); return; }
        web = null; showDashboard();
    }
}
