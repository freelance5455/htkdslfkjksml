KING AI - Android WebView project

Is ZIP mein aapki original king-ai.html file Android app ke andar rakhi gayi hai.
App ka naam King AI hai. Photo picker / local photo editor ke liye WebView file chooser support diya gaya hai.

ZAROORI LIMITATION:
Aapki HTML file ka AI chat Claude ke environment ke `window.claude` SDK (sample, downloads, user, db) par nirbhar hai.
Normal Android APK/WebView mein yeh SDK automatically nahi milta. Isliye is demo APK wrapper mein:
- App interface khulega.
- Photo editor ke local filters chal sakte hain.
- Claude-powered AI chat, sign-in, owner studio, database aur downloads integration tab tak nahi chalenge jab tak unke liye alag supported backend / integration na banaya jaye.

APK banane ke liye:
1. ZIP ko computer par extract karein.
2. Android Studio mein "Open" karke KingAI folder select karein.
3. Android Gradle Plugin download/sync hone dein.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. app/build/outputs/apk/debug/app-debug.apk ko Android phone mein install karein.

Yeh Android Studio project hai, compiled APK nahi.
