package com.myway.floattimer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import org.json.JSONObject
import java.util.Locale
import kotlin.math.abs

/** Overlay service is independent from the WebView activity, so it can remain visible over other apps. */
class FloatingTimerService : Service() {
    private lateinit var wm: WindowManager
    private var clock: TextView? = null
    private var params: WindowManager.LayoutParams? = null
    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var stopwatch = false
    private var elapsedMs = 0L
    private var countdownMs = 5 * 60 * 1000L
    private var lastTick = System.currentTimeMillis()
    private var color = Color.WHITE
    private var opacity = 1f
    private var sizeSp = 24f
    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0
    private var moved = false

    private val ticker = object : Runnable {
        override fun run() {
            if (running) {
                val now = System.currentTimeMillis()
                val delta = (now - lastTick).coerceAtLeast(0L)
                if (stopwatch) elapsedMs += delta else countdownMs = (countdownMs - delta).coerceAtLeast(0L)
                lastTick = now
                if (!stopwatch && countdownMs == 0L) running = false
                updateText()
            }
            handler.postDelayed(this, 250L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showOverlaySafely()
        handler.post(ticker)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
            ACTION_START, ACTION_UPDATE, null -> {
                val payload = intent?.getStringExtra(EXTRA_PAYLOAD)
                if (!payload.isNullOrBlank()) applyPayload(payload)
                if (clock == null && ::wm.isInitialized) showOverlaySafely()
                updateText()
            }
        }
        return START_STICKY
    }

    private fun applyPayload(raw: String) {
        try {
            val json = JSONObject(raw)
            stopwatch = json.optString("mode", "countdown") == "stopwatch"
            running = if (stopwatch) json.optBoolean("swRunning", false) else json.optBoolean("countRunning", false)
            elapsedMs = json.optDouble("swElapsed", 0.0).toLong().coerceAtLeast(0L)
            countdownMs = (json.optDouble("countLeft", 300.0) * 1000.0).toLong().coerceAtLeast(0L)
            val deadline = json.optLong("countDeadline", 0L)
            if (!stopwatch && running && deadline > System.currentTimeMillis()) {
                countdownMs = (deadline - System.currentTimeMillis()).coerceAtLeast(0L)
            }
            val c = json.optString("color", "#ffffff")
            color = try { Color.parseColor(c) } catch (_: Exception) { Color.WHITE }
            opacity = json.optDouble("opacity", 1.0).toFloat().coerceIn(0.1f, 1f)
            sizeSp = json.optDouble("size", 24.0).toFloat().coerceIn(14f, 100f)
            lastTick = System.currentTimeMillis()
            clock?.apply { textSize = sizeSp; alpha = opacity; setTextColor(color) }
        } catch (_: Exception) { }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "플로팅 타이머", NotificationManager.IMPORTANCE_LOW).apply {
                description = "다른 앱을 사용하는 동안 타이머 표시를 유지합니다."
                setShowBadge(false)
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, CHANNEL_ID) else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        return builder.setContentTitle("플로팅 타이머 실행 중")
            .setContentText("홈 화면이나 카메라를 열어도 시계 표시를 유지합니다.")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentIntent(openIntent).setOngoing(true).setCategory(Notification.CATEGORY_SERVICE).build()
    }

    private fun showOverlaySafely() {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        try { showOverlay() } catch (_: Exception) { stopSelf() }
    }

    private fun showOverlay() {
        if (clock != null) return
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val tv = TextView(this).apply {
            text = "05:00"
            textSize = sizeSp
            setTextColor(color)
            alpha = opacity
            setShadowLayer(6f, 1f, 2f, Color.BLACK)
            setPadding(8, 4, 8, 4)
            setBackgroundColor(0x33000000)
            gravity = Gravity.CENTER
            contentDescription = "플로팅 타이머. 탭하면 시작 또는 일시정지, 드래그하면 이동"
            isClickable = true
        }
        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = 40; y = 180
        }
        tv.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; startX = lp.x; startY = lp.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt(); val dy = (event.rawY - downY).toInt()
                    if (abs(dx) > 6 || abs(dy) > 6) moved = true
                    if (moved) { lp.x = (startX + dx).coerceAtLeast(0); lp.y = (startY + dy).coerceAtLeast(0); try { wm.updateViewLayout(tv, lp) } catch (_: Exception) { } }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (!moved && event.action == MotionEvent.ACTION_UP) { running = !running; lastTick = System.currentTimeMillis(); updateText() }
                    true
                }
                else -> true
            }
        }
        clock = tv; params = lp; wm.addView(tv, lp); updateText()
    }

    private fun updateText() {
        val totalSeconds = ((if (stopwatch) elapsedMs else countdownMs) / 1000L).coerceAtLeast(0L)
        val h = totalSeconds / 3600L; val m = (totalSeconds % 3600L) / 60L; val s = totalSeconds % 60L
        val display = if (stopwatch) {
            val centi = (elapsedMs / 10L) % 100L
            val main = if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s) else String.format(Locale.US, "%02d:%02d", m, s)
            "$main.${String.format(Locale.US, "%02d", centi)}"
        } else if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s) else String.format(Locale.US, "%02d:%02d", m, s)
        clock?.text = display
        clock?.textSize = sizeSp
        clock?.alpha = opacity
        clock?.setTextColor(if (!stopwatch && countdownMs == 0L) Color.RED else color)
    }

    override fun onTaskRemoved(rootIntent: Intent?) { super.onTaskRemoved(rootIntent) }
    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        clock?.let { try { wm.removeView(it) } catch (_: Exception) { } }
        clock = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.myway.floattimer.START"
        const val ACTION_UPDATE = "com.myway.floattimer.UPDATE"
        const val ACTION_STOP = "com.myway.floattimer.STOP"
        const val EXTRA_PAYLOAD = "payload"
        private const val CHANNEL_ID = "floating_timer"
        private const val NOTIFICATION_ID = 1001
    }
}
