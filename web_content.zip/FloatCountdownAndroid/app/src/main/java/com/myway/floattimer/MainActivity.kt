package com.myway.floattimer

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var pendingPayload: String = "{}"
    private val overlayRequestCode = 501

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            addJavascriptInterface(OverlayBridge(), "AndroidOverlay")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(webView)
    }

    inner class OverlayBridge {
        @JavascriptInterface
        fun startFloatingClock(payload: String) {
            runOnUiThread {
                pendingPayload = payload
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "‘다른 앱 위에 표시’를 허용해 주세요.", Toast.LENGTH_LONG).show()
                    val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                    startActivityForResult(intent, overlayRequestCode)
                } else {
                    startFloatingService(payload)
                }
            }
        }

        @JavascriptInterface
        fun updateFloatingClock(payload: String) {
            val intent = Intent(this@MainActivity, FloatingTimerService::class.java).apply {
                action = FloatingTimerService.ACTION_UPDATE
                putExtra(FloatingTimerService.EXTRA_PAYLOAD, payload)
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startService(intent) else startService(intent)
            } catch (_: Exception) { }
        }

        @JavascriptInterface
        fun stopFloatingClock() {
            stopService(Intent(this@MainActivity, FloatingTimerService::class.java))
        }
    }

    private fun startFloatingService(payload: String) {
        val intent = Intent(this, FloatingTimerService::class.java).apply {
            action = FloatingTimerService.ACTION_START
            putExtra(FloatingTimerService.EXTRA_PAYLOAD, payload)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        Toast.makeText(this, "플로팅 시계를 시작했습니다. 홈 또는 카메라로 이동해 확인하세요.", Toast.LENGTH_LONG).show()
    }

    @Deprecated("Deprecated in Android API; retained for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == overlayRequestCode) {
            if (Settings.canDrawOverlays(this)) startFloatingService(pendingPayload)
            else Toast.makeText(this, "오버레이 권한이 없어 플로팅 시계를 시작하지 못했습니다.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
