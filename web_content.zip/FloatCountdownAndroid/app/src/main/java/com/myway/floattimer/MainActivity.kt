package com.myway.floattimer

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.ActivityNotFoundException
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var pendingPayload: String = "{}"
    private var waitingForOverlayPermission = false
    private val overlayRequestCode = 501

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            addJavascriptInterface(OverlayBridge(), "AndroidOverlay")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(webView)
    }

    inner class OverlayBridge {
        @JavascriptInterface
        fun startFloatingClock(payload: String) {
            runOnUiThread {
                pendingPayload = payload
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    waitingForOverlayPermission = true
                    Toast.makeText(this@MainActivity, "설정에서 ‘플로팅 타이머’의 ‘다른 앱 위에 표시’를 켜 주세요.", Toast.LENGTH_LONG).show()
                    openOverlayPermissionSettings()
                } else {
                    startFloatingService(payload)
                }
            }
        }

        @JavascriptInterface
        fun updateFloatingClock(payload: String) {
            pendingPayload = payload
            val intent = Intent(this@MainActivity, FloatingTimerService::class.java).apply {
                action = FloatingTimerService.ACTION_UPDATE
                putExtra(FloatingTimerService.EXTRA_PAYLOAD, payload)
            }
            try {
                if (!Settings.canDrawOverlays(this@MainActivity)) return
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this@MainActivity, "플로팅 시계 설정 전달 실패: ${e.message ?: "오류"}", Toast.LENGTH_SHORT).show() }
            }
        }

        @JavascriptInterface
        fun stopFloatingClock() {
            runOnUiThread {
                stopService(Intent(this@MainActivity, FloatingTimerService::class.java))
                Toast.makeText(this@MainActivity, "플로팅 시계를 종료했습니다.", Toast.LENGTH_SHORT).show()
            }
        }
    }


    /** Opens Android's special-access screen with manufacturer-compatible fallbacks. */
    private fun openOverlayPermissionSettings() {
        val appSpecific = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        val generic = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
        val appDetails = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        val candidates = listOf(appSpecific, generic, appDetails)
        var lastError: Exception? = null

        for (candidate in candidates) {
            try {
                // Do not gate this on resolveActivity(): package-visibility filtering can
                // incorrectly report null for Settings activities on some Android builds.
                startActivityForResult(candidate, overlayRequestCode)
                return
            } catch (e: ActivityNotFoundException) {
                lastError = e
            } catch (e: SecurityException) {
                lastError = e
            } catch (e: Exception) {
                lastError = e
            }
        }

        waitingForOverlayPermission = false
        AlertDialog.Builder(this)
            .setTitle("플로팅 권한 설정")
            .setMessage("설정 화면을 자동으로 열지 못했습니다. 휴대폰 설정에서 아래 순서로 직접 켜 주세요.\n\n설정 → 애플리케이션 → 플로팅 타이머 → 다른 앱 위에 표시 → 허용")
            .setPositiveButton("앱 설정 열기") { _, _ ->
                try {
                    startActivity(appDetails)
                } catch (_: Exception) {
                    Toast.makeText(this, "${lastError?.message ?: "설정 화면을 열 수 없습니다."}", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("닫기", null)
            .show()
    }

    private fun startFloatingService(payload: String) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "먼저 ‘다른 앱 위에 표시’ 권한을 허용해 주세요.", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(this, FloatingTimerService::class.java).apply {
            action = FloatingTimerService.ACTION_START
            putExtra(FloatingTimerService.EXTRA_PAYLOAD, payload)
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
            Toast.makeText(this, "플로팅 시계를 시작했습니다. 홈 버튼을 눌러 카메라에서 확인하세요.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "서비스 시작 실패: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated Android callback retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == overlayRequestCode && waitingForOverlayPermission) {
            waitingForOverlayPermission = false
            if (Settings.canDrawOverlays(this)) startFloatingService(pendingPayload)
            else Toast.makeText(this, "권한이 꺼져 있어 시계를 띄울 수 없습니다. 설정에서 허용해 주세요.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onResume() {
        super.onResume()
        // Some Android builds return from the overlay settings without delivering a useful result code.
        if (waitingForOverlayPermission && Settings.canDrawOverlays(this)) {
            waitingForOverlayPermission = false
            startFloatingService(pendingPayload)
        }
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
