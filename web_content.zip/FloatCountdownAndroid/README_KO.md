# 플로팅 타이머 Android 프로젝트 — HTML 브리지 연결판

## 이번 수정 사항
- 기존 HTML 화면을 Android WebView 안에 포함했습니다 (`app/src/main/assets/index.html`).
- HTML의 `AndroidOverlay.startFloatingClock`, `updateFloatingClock`, `stopFloatingClock` 호출을 실제 Kotlin Android 코드에 연결했습니다.
- `FloatingTimerService`가 포그라운드 서비스로 실행되고 `WindowManager`의 `TYPE_APPLICATION_OVERLAY` 창을 생성합니다. 따라서 앱 화면을 벗어나 홈 화면이나 카메라 앱을 열어도 시계를 화면 위에 표시할 수 있도록 구성했습니다.
- 처음 시작할 때 Android의 **다른 앱 위에 표시** 권한이 없으면 설정 화면을 열고, 권한 허용 후 대기 중인 타이머 설정으로 서비스를 시작합니다.
- HTML의 모드, 시간, 숫자 색상, 투명도, 크기 설정을 네이티브 오버레이 서비스로 전달합니다.
- 플로팅 시계를 탭하면 네이티브 서비스에서 시작/일시정지하고, 드래그하면 화면에서 위치를 옮깁니다.
- 서비스는 지속 알림을 사용하며 최근 앱 목록에서 앱을 밀어 닫는 동작만으로 종료되지 않도록 설정했습니다.

## APK 빌드 방법
1. ZIP 파일을 압축 해제합니다.
2. Android Studio에서 `FloatCountdownAndroid` 폴더를 엽니다.
3. Gradle 동기화를 마친 뒤 **Build > Build APK(s)** 를 실행합니다.
4. 생성된 APK를 휴대폰에 설치합니다.
5. 앱에서 **휴대폰 화면에 플로팅 시계 띄우기**를 누르고, Android 설정에서 **다른 앱 위에 표시**를 허용합니다.
6. 앱을 홈 화면으로 내리거나 카메라를 실행해 시계가 표시되는지 확인합니다.

## 중요한 제한 사항
- HTML 파일만 브라우저에서 열면 다른 앱 위에 표시할 수 없습니다. 이 ZIP 안의 Android 앱(WebView + Kotlin 서비스)으로 빌드해 사용해야 합니다.
- 이 환경에서는 실제 Android 기기에서 빌드/실행 테스트를 완료하지 않았습니다. Android Studio에서 빌드 후 기기에서 권한과 카메라 앱을 확인해 주세요.
- 일부 카메라 앱은 보안/개인정보 보호 정책에 따라 오버레이를 숨길 수 있습니다. 사용자가 앱을 Android 설정에서 **강제 종료**하면 서비스가 다시 시작되지 않을 수 있습니다.
- 타이머 숫자는 화면 위에 보이는 오버레이입니다. 저장된 사진이나 동영상 파일에 숫자를 합성하는 기능은 아닙니다.
