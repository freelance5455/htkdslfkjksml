import os, re, html, math
BASE='/tmp/ype/app/src/main/assets/item-images'
files=[f[:-4] for f in os.listdir(BASE) if f.endswith('.svg')]

fruit={'apple':'#d92b36','banana':'#f3c62f','orange':'#f28c28','lemon':'#f5d64b','lime':'#77b82a','mango':'#f3a31b','grapes':'#7b3fb7','watermelon':'#ef4c55','pineapple':'#e4b52f','papaya':'#f39a2d','avocado':'#6b9e3f','strawberry':'#e94b5b','blueberry':'#4664c8','peach':'#f4a47f','pear':'#a7c84a','coconut':'#8a5a38','dates':'#6d3b25','raisins':'#6b3a28','almonds':'#c58a4b','peanuts':'#d59b58'}
veg={'tomato':'#ef4b3f','potato':'#c99152','onion':'#c9a0c5','garlic':'#f4f0df','ginger':'#c58b43','carrot':'#ef7e28','cucumber':'#4f9d56','spinach':'#2f8b49','lettuce':'#72a85c','cabbage':'#8cb46a','broccoli':'#3e8e4c','cauliflower':'#f1f0dd','bell-pepper':'#e94a44','eggplant':'#7652a8','zucchini':'#6f9f4b','celery':'#7ba95b','peas':'#6aa84f','corn':'#e7c84d','beans':'#9b6541','lentils':'#c58d42','mushrooms':'#b98f6b'}

def title(n): return n.replace('-',' ').title()
def esc(s): return html.escape(s)

def svg_for(n):
    label=title(n)
    uid=re.sub(r'[^a-z0-9]','',n)[:16] or 'item'
    # common defs, transparent canvas, realistic floor shadow
    defs=f'''<defs>
      <linearGradient id="bg{uid}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity=".05"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient>
      <linearGradient id="metal{uid}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset=".22" stop-color="#dfe3ea"/><stop offset=".48" stop-color="#8f98a8"/><stop offset=".72" stop-color="#f5f7fa"/><stop offset="1" stop-color="#7f8796"/></linearGradient>
      <linearGradient id="white{uid}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset=".65" stop-color="#f2f3f6"/><stop offset="1" stop-color="#d7dae1"/></linearGradient>
      <linearGradient id="blue{uid}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#6fc6ff"/><stop offset=".45" stop-color="#1976d2"/><stop offset="1" stop-color="#0d3f8f"/></linearGradient>
      <linearGradient id="purple{uid}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#c28cff"/><stop offset=".45" stop-color="#7b2cff"/><stop offset="1" stop-color="#35116e"/></linearGradient>
      <filter id="shadow{uid}" x="-30%" y="-30%" width="160%" height="170%"><feDropShadow dx="0" dy="12" stdDeviation="10" flood-color="#000" flood-opacity=".34"/></filter>
      <filter id="soft{uid}"><feGaussianBlur stdDeviation="4"/></filter>
      <radialGradient id="shine{uid}" cx="28%" cy="18%"><stop offset="0" stop-color="#fff" stop-opacity=".72"/><stop offset=".3" stop-color="#fff" stop-opacity=".12"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient>
    </defs>'''
    body=[]
    # Fruits/veg: realistic-ish produce with highlights and contour
    if n in fruit or n in veg:
        c=(fruit|veg)[n]
        if n=='banana':
            body += [f'<path d="M55 164 Q83 203 151 190 Q187 183 203 145 Q190 136 179 145 Q159 165 129 166 Q96 166 70 139Z" fill="#f0c62f" stroke="#9d7d13" stroke-width="3" filter="url(#shadow{uid})"/>',
                     f'<path d="M68 145 Q92 177 144 172" fill="none" stroke="#fff" stroke-opacity=".35" stroke-width="7" stroke-linecap="round"/>']
        elif n=='watermelon':
            body += [f'<path d="M49 147 Q128 53 207 147 Q128 197 49 147Z" fill="#ef4c55" stroke="#3e7c44" stroke-width="8" filter="url(#shadow{uid})"/>',f'<path d="M52 147 Q128 191 204 147" fill="none" stroke="#f6f0d0" stroke-width="12"/>',f'<path d="M59 153 Q128 193 197 153" fill="none" stroke="#2e7b3d" stroke-width="9"/>']
        elif n=='pineapple':
            body += [f'<path d="M99 82 Q128 58 157 82 L175 119 Q174 174 128 192 Q82 174 81 119Z" fill="{c}" stroke="#9b7620" stroke-width="3" filter="url(#shadow{uid})"/>',f'<path d="M98 78 L82 45 L108 62 L118 31 L132 62 L158 36 L153 74" fill="#3d8d43" stroke="#286632" stroke-width="4"/>',f'<path d="M96 106 L158 164 M86 126 L148 180 M101 86 L169 145" stroke="#9b7620" stroke-width="4" opacity=".55"/>']
        else:
            if n in ['grapes','blueberry','raisins']:
                count=9 if n=='grapes' else 7
                for i in range(count):
                    x=90+(i%3)*28+(i//3)*8; y=92+(i%3)*27+(i//3)*17
                    body.append(f'<circle cx="{x}" cy="{y}" r="18" fill="{c}" stroke="#000" stroke-opacity=".12" stroke-width="2" filter="url(#shadow{uid})"/>')
                body.append(f'<path d="M128 66 Q139 42 158 48" fill="none" stroke="#5f4727" stroke-width="7" stroke-linecap="round"/>')
            else:
                shape='ellipse'
                if n in ['carrot','cucumber','zucchini','celery','ginger']: shape='capsule'
                if n in ['potato','tomato','apple','orange','lemon','lime','peach','pear','mango','avocado','strawberry','papaya']:
                    body.append(f'<ellipse cx="128" cy="132" rx="66" ry="74" fill="{c}" stroke="#000" stroke-opacity=".14" stroke-width="3" filter="url(#shadow{uid})"/>')
                elif n=='bell-pepper':
                    body.append(f'<path d="M76 103 Q88 72 112 86 Q128 70 144 86 Q168 72 180 103 Q188 157 128 188 Q68 157 76 103Z" fill="{c}" stroke="#000" stroke-opacity=".16" stroke-width="3" filter="url(#shadow{uid})"/>')
                elif n in ['broccoli','cauliflower','mushrooms','spinach','lettuce','cabbage']:
                    body.append(f'<path d="M70 148 Q60 105 91 99 Q93 66 122 81 Q145 58 165 85 Q196 82 188 117 Q203 140 179 155 Q154 177 128 174 Q96 177 70 148Z" fill="{c}" stroke="#000" stroke-opacity=".12" stroke-width="3" filter="url(#shadow{uid})"/>')
                else:
                    body.append(f'<ellipse cx="128" cy="135" rx="60" ry="72" fill="{c}" stroke="#000" stroke-opacity=".14" stroke-width="3" filter="url(#shadow{uid})"/>')
            body += [f'<ellipse cx="105" cy="101" rx="20" ry="12" fill="#fff" opacity=".24" transform="rotate(-25 105 101)"/>']
            if n in ['apple','pear','peach','mango','avocado','orange','lemon','lime','tomato']:
                body.append(f'<path d="M128 67 Q132 45 148 39" fill="none" stroke="#5a3b24" stroke-width="7" stroke-linecap="round"/>')
                body.append(f'<ellipse cx="154" cy="39" rx="17" ry="8" fill="#4f9d57" transform="rotate(-18 154 39)"/>')
    elif n in ['eggs','chicken','beef','pork','fish','tuna','sausage','ham']:
        # food pack / tray
        body.append(f'<ellipse cx="128" cy="174" rx="76" ry="20" fill="#000" opacity=".18"/>')
        if n=='eggs':
            body.append(f'<rect x="52" y="76" width="152" height="104" rx="18" fill="#d7b68d" stroke="#9d7b55" stroke-width="3" filter="url(#shadow{uid})"/>')
            for y in [100,132,164]:
                for x in [80,112,144,176]: body.append(f'<ellipse cx="{x}" cy="{y}" rx="17" ry="20" fill="url(#white{uid})" stroke="#c9cbd0" stroke-width="2"/>')
        else:
            body.append(f'<rect x="55" y="74" width="146" height="110" rx="18" fill="url(#white{uid})" stroke="#c5c9d0" stroke-width="3" filter="url(#shadow{uid})"/>')
            body.append(f'<rect x="70" y="93" width="116" height="56" rx="12" fill="{c if n in fruit else "#c93d48"}" opacity=".92"/>')
            body.append(f'<rect x="88" y="105" width="80" height="12" rx="6" fill="#fff" opacity=".88"/>')
    elif any(k in n for k in ['medicine','tablets','capsules','antibiotic','vitamin','supplement','paracetamol','ibuprofen','ointment','drops','spray','syrup','inhaler','bandage','gauze','thermometer','sanitizer','antiseptic','ors','electrolyte','tape','cotton','mask','lenses','antacid','allergy','cold','stomach','vapor','sleep','pet-medicine']):
        # clinical packaging
        if 'drops' in n or 'spray' in n or 'syrup' in n or 'sanitizer' in n or 'vapor' in n or 'ointment' in n:
            body.append(f'<path d="M95 65 h66 v18 q0 10 11 18 v68 q0 15-15 15H99q-15 0-15-15v-68q11-8 11-18z" fill="url(#blue{uid})" stroke="#274b7b" stroke-width="3" filter="url(#shadow{uid})"/>')
            body.append(f'<rect x="93" y="43" width="70" height="28" rx="8" fill="url(#white{uid})" stroke="#b7bec9" stroke-width="2"/>')
        else:
            body.append(f'<rect x="66" y="58" width="124" height="136" rx="12" fill="url(#white{uid})" stroke="#b9bec8" stroke-width="3" filter="url(#shadow{uid})"/>')
            body.append(f'<rect x="66" y="58" width="124" height="31" rx="12" fill="url(#purple{uid})"/>')
        body.append(f'<rect x="78" y="105" width="100" height="55" rx="8" fill="#fff" opacity=".96"/>')
        body.append(f'<rect x="89" y="118" width="78" height="9" rx="4" fill="#e5e7eb"/>')
        body.append(f'<rect x="89" y="136" width="52" height="8" rx="4" fill="#cfd4dc"/>')
        body.append(f'<circle cx="151" cy="137" r="10" fill="#e74c3c" opacity=".9"/>')
    elif any(k in n for k in ['shampoo','conditioner','body-wash','face-wash','cleanser','moisturizer','lotion','sunscreen','perfume','deodorant','hair-gel','hair-spray','hair-oil','hair-color','makeup','lipstick','foundation','mascara','nail-polish','razor','shaving','toothpaste','toothbrush','soap','hand-wash','lip-balm','eye-cream']):
        if n in ['toothpaste','shaving-cream','hair-gel']:
            body.append(f'<path d="M80 92 Q128 70 176 92 L169 174 Q128 188 87 174Z" fill="url(#purple{uid})" stroke="#4d2b83" stroke-width="3" filter="url(#shadow{uid})"/>')
        elif n in ['lipstick','nail-polish','mascara']:
            body.append(f'<rect x="92" y="83" width="72" height="94" rx="18" fill="url(#purple{uid})" stroke="#43246e" stroke-width="3" filter="url(#shadow{uid})"/>')
            body.append(f'<rect x="108" y="55" width="40" height="43" rx="10" fill="#c13a5a"/>')
        else:
            body.append(f'<path d="M96 68 h64 v18 q0 8 10 16 v71 q0 13-14 13H100q-14 0-14-13v-71q10-8 10-16z" fill="url(#purple{uid})" stroke="#4d2b83" stroke-width="3" filter="url(#shadow{uid})"/>')
            body.append(f'<rect x="94" y="48" width="68" height="25" rx="8" fill="url(#white{uid})" stroke="#c5c8cf" stroke-width="2"/>')
        body.append(f'<rect x="105" y="104" width="46" height="46" rx="8" fill="#fff" opacity=".92"/>')
        body.append(f'<path d="M114 119h28 M114 131h22" stroke="#aeb4bf" stroke-width="5" stroke-linecap="round"/>')
    elif any(k in n for k in ['detergent','dish','bleach','cleaner','air-freshener','insect','pesticide','sponge','broom','mop','trash','foil','wrap','tissue','toilet-paper','paper-towel','softener','washing-powder']):
        if n in ['sponge']:
            body.append(f'<rect x="69" y="85" width="118" height="72" rx="20" fill="#f3c23d" stroke="#b88d1d" stroke-width="3" filter="url(#shadow{uid})"/><path d="M82 102 Q112 88 145 101 T177 102" fill="none" stroke="#fff" stroke-opacity=".3" stroke-width="8"/>')
        elif n in ['broom','mop']:
            body.append(f'<path d="M140 50 L112 170" stroke="#8b6a45" stroke-width="12" stroke-linecap="round"/><path d="M78 163 Q128 145 178 163 L171 187 Q128 170 85 187Z" fill="#5c78b5" stroke="#35496e" stroke-width="3" filter="url(#shadow{uid})"/>')
        else:
            body.append(f'<path d="M86 62 h84 v20 q0 9 9 17 v79 q0 14-15 14H92q-15 0-15-14V99q9-8 9-17z" fill="url(#blue{uid})" stroke="#2f4f78" stroke-width="3" filter="url(#shadow{uid})"/>')
            body.append(f'<rect x="96" y="105" width="64" height="55" rx="9" fill="#fff" opacity=".92"/>')
            body.append(f'<path d="M108 119h40 M108 132h30" stroke="#aab1bc" stroke-width="6" stroke-linecap="round"/>')
    elif any(k in n for k in ['coffee','tea','green-tea','black-tea','herbal-tea','juice','water','soda','energy-drink','vinegar','protein-powder']):
        if n in ['coffee','tea','green-tea','black-tea','herbal-tea','protein-powder']:
            body.append(f'<path d="M76 66 Q128 45 180 66 L171 183 Q128 197 85 183Z" fill="url(#purple{uid})" stroke="#4a2d7c" stroke-width="3" filter="url(#shadow{uid})"/>')
        else:
            body.append(f'<path d="M99 53 h58 v20 q0 8 9 18 v85 q0 14-16 14H106q-16 0-16-14V91q9-10 9-18z" fill="url(#blue{uid})" stroke="#2d5684" stroke-width="3" filter="url(#shadow{uid})"/>')
        body.append(f'<rect x="91" y="104" width="74" height="55" rx="10" fill="#fff" opacity=".92"/>')
        body.append(f'<rect x="103" y="119" width="50" height="9" rx="4" fill="#aeb5bf"/>')
        body.append(f'<rect x="103" y="136" width="38" height="7" rx="3" fill="#c9ced5"/>')
    elif any(k in n for k in ['battery','bulb','glue','paint','ink','printer','markers','ruler','cat-treats','pet','engine-coolant','air-filter']):
        body.append(f'<rect x="62" y="65" width="132" height="132" rx="18" fill="url(#metal{uid})" stroke="#69717f" stroke-width="3" filter="url(#shadow{uid})"/>')
        body.append(f'<rect x="76" y="84" width="104" height="70" rx="12" fill="url(#purple{uid})"/>')
        body.append(f'<rect x="91" y="101" width="74" height="10" rx="5" fill="#fff" opacity=".9"/>')
        body.append(f'<rect x="91" y="120" width="50" height="8" rx="4" fill="#d9dce2" opacity=".9"/>')
    else:
        # generic premium grocery / household pack, still unique via color seed
        colors=['#4c8bf5','#7b4de8','#23a67a','#e78a2f','#e14c5a','#16a6b8']
        c=colors[sum(map(ord,n))%len(colors)]
        body.append(f'<path d="M70 70 Q128 45 186 70 L178 188 Q128 202 78 188Z" fill="{c}" stroke="#1d2634" stroke-opacity=".28" stroke-width="3" filter="url(#shadow{uid})"/>')
        body.append(f'<rect x="83" y="104" width="90" height="55" rx="10" fill="#fff" opacity=".93"/>')
        body.append(f'<rect x="97" y="118" width="62" height="8" rx="4" fill="#9ea6b2"/>')
        body.append(f'<rect x="97" y="134" width="44" height="7" rx="3" fill="#c7ccd4"/>')
    # common highlights and label
    body.append(f'<ellipse cx="108" cy="85" rx="22" ry="12" fill="#fff" opacity=".18" transform="rotate(-25 108 85)"/>')
    # tiny realistic brand-neutral label; no trademark claims
    short=esc(label[:18])
    body.append(f'<text x="128" y="153" text-anchor="middle" font-family="Arial, sans-serif" font-size="12" font-weight="700" fill="#273142" opacity=".86">{short}</text>')
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="256" height="256" viewBox="0 0 256 256">{defs}<rect width="256" height="256" fill="none"/><ellipse cx="128" cy="214" rx="76" ry="11" fill="#000" opacity=".22" filter="url(#soft{uid})"/>{''.join(body)}</svg>'''

for n in files:
    open(os.path.join(BASE,n+'.svg'),'w',encoding='utf-8').write(svg_for(n))
print('generated',len(files))
