package com.nationalmanager.game;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** WebView shell for the offline HTML football manager. */
public final class MainActivity extends Activity {
    private static final int PICK_FILE = 101;
    private static final int EXPORT_SAVE = 102;
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private String jsonToExport;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                             WindowManager.LayoutParams.FLAG_FULLSCREEN);
        webView = new WebView(this);
        webView.setBackgroundColor(0xff08111d);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view,
                    ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    startActivityForResult(intent, PICK_FILE);
                    return true;
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "Файловий менеджер не знайдено", Toast.LENGTH_LONG).show();
                    callback.onReceiveValue(null);
                    return false;
                }
            }
        });
        webView.addJavascriptInterface(new SaveBridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class SaveBridge {
        @JavascriptInterface public void exportSave(String json, String filename) {
            runOnUiThread(() -> {
                jsonToExport = json;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                String safeName = filename == null ? "National_Manager_Save.json"
                    : filename.replaceAll("[^a-zA-Z0-9._-]", "_");
                intent.putExtra(Intent.EXTRA_TITLE, safeName);
                try {
                    startActivityForResult(intent, EXPORT_SAVE);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this, "Не знайдено програму для збереження", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == PICK_FILE) {
            if (fileCallback != null) {
                Uri[] resultUris = WebChromeClient.FileChooserParams.parseResult(result, data);
                fileCallback.onReceiveValue(resultUris);
                fileCallback = null;
            }
        } else if (request == EXPORT_SAVE) {
            String json = jsonToExport;
            jsonToExport = null;
            if (result == RESULT_OK && data != null && data.getData() != null && json != null) {
                Uri uri = data.getData();
                new Thread(() -> {
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out == null) throw new IllegalStateException("Не вдалося відкрити файл");
                        out.write(json.getBytes(StandardCharsets.UTF_8));
                        runOnUiThread(() -> Toast.makeText(this,
                            "Кар’єру збережено", Toast.LENGTH_SHORT).show());
                    } catch (Exception e) {
                        runOnUiThread(() -> Toast.makeText(this,
                            "Помилка експорту сейву", Toast.LENGTH_LONG).show());
                    }
                }).start();
            }
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
