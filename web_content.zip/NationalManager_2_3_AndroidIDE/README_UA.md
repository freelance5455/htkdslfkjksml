# National Manager 2.3 — проект для AndroidIDE (Android)

## УВАГА: як зібрати на телефоні
AndroidIDE підтримує Java/Gradle. Цей архів містить готові Android-файли, HTML та іконку, але **не містить gradle-wrapper.jar** (цей файл згенерує AndroidIDE у своєму шаблоні).

1. Установи AndroidIDE з офіційного джерела й пройди Setup tools (JDK, SDK, Gradle).
2. Натисни **Create project** -> шаблон **Empty Activity (Java)**.
3. Вкажи назву `NationalManager` та package **com.nationalmanager.game**.
4. Створи проєкт і зачекай, доки Gradle Sync завершиться. AndroidIDE створить `gradlew`, `gradle/wrapper/gradle-wrapper.jar` та інші службові файли.
5. У файловому менеджері телефона розпакуй ЦЕЙ архів; скопіюй зі свіжої папки `app/src/main/` (разом з `assets`, `java`, `res`, `AndroidManifest.xml`) у `app/src/main/` проєкту AndroidIDE, із заміною файлів.
6. Скопіюй також `app/build.gradle`, `build.gradle`, `settings.gradle`, `gradle.properties` і `gradle/wrapper/gradle-wrapper.properties` з цього архіву у відповідні папки проєкту, але НЕ видаляй `gradlew` і `gradle/wrapper/gradle-wrapper.jar`, згенеровані AndroidIDE.
7. Повернися до AndroidIDE, синхронізуй проєкт (Gradle Sync). Переконайся, що SDK Platform 33 встановлений і використовується JDK 17.
8. Натисни **Quick Run / ▶**: AndroidIDE збере `assembleDebug` і запропонує встановити APK.
9. Готовий файл має бути в `<project>/app/build/outputs/apk/debug/app-debug.apk`.

## Як працює
- Java `MainActivity` відкриває `file:///android_asset/index.html` у WebView. Всі ресурси гри містяться локально.
- Експорт JSON сейву використовує Android-системний файловий діалог, імпорт використовує системний файловий вибір.
- Сейви Acode не переносяться автоматично. Спочатку експортуй сейв із Acode, потім імпортуй у версії APK.
- Якщо AndroidIDE видає помилку Sync або Build, сфотографуй/скопіюй ПЕРШИЙ рядок помилки внизу в Build Output.

## Обмеження
- Повне встановлення APK на телефоні не перевірене тут: доступного Android SDK / AndroidIDE для реальної компіляції в цьому середовищі немає.
- Це новий WebView APK проєкт для авторської гри, не оригінальний Java APK True Football.
- Для розповсюдження потрібен **release APK** із твоїм власним постійним ключем підпису; Quick Run формує тестовий debug APK.
