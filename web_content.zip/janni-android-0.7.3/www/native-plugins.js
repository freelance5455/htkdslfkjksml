// Native plugin bridge for Capacitor 7.
// This file is bundled before APK build; no API secrets are stored here.
import { Camera } from '@capacitor/camera';
import { Browser } from '@capacitor/browser';
import { LocalNotifications } from '@capacitor/local-notifications';
import { SpeechRecognition } from '@capacitor-community/speech-recognition';
import { TextToSpeech } from '@capacitor-community/text-to-speech';
import { VoiceRecorder } from 'capacitor-voice-recorder';

window.JANNI_NATIVE_PLUGINS = {
  Camera,
  Browser,
  LocalNotifications,
  SpeechRecognition,
  TextToSpeech,
  VoiceRecorder
};
