# يضيف أذونات Android المطلوبة إلى AndroidManifest.xml إن لم تكن موجودة
p = "android/app/src/main/AndroidManifest.xml"
s = open(p, encoding="utf-8").read()
perms = [l.strip() for l in open("android-manifest/permissions.xml", encoding="utf-8").read().splitlines()
         if l.strip().startswith("<uses-permission")]
missing = [l for l in perms if l not in s]
if missing:
    s = s.replace("<application", "\n    ".join(missing) + "\n    <application", 1)
    open(p, "w", encoding="utf-8").write(s)
print("permissions added:", len(missing))
