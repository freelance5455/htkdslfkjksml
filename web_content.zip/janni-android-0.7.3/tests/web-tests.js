const { chromium } = require('playwright');
const path = require('path');
const URL = 'file://' + require('path').resolve(process.argv[2] || 'www/index.html');
const results = [];
const ok = (name, cond, extra='') => { results.push([cond ? 'PASS' : 'FAIL', name, extra]); };
(async () => {
  const browser = await chromium.launch();
  // Scenario A: fresh install
  let ctx = await browser.newContext({ locale: 'ar-SA' });
  let page = await ctx.newPage();
  const errs = [];
  page.on('pageerror', e => errs.push(String(e)));
  await page.goto(URL);
  await page.waitForTimeout(500);
  let g = await page.textContent('#greetingText');
  ok('A1 fresh install greeting uses أبا يزيد', g.includes('أبا يزيد'), g);
  // assistant: add task, list tasks, save note
  await page.fill('#assistantInput', 'اضف مهمة اختبار الدواء');
  await page.click('#assistantSend');
  await page.waitForTimeout(400);
  let reply = await page.textContent('#assistantReply');
  ok('A2 add task via assistant', reply.includes('تمت إضافة المهمة'), reply);
  await page.fill('#assistantInput', 'احفظ ملاحظة اشتري الماء');
  await page.click('#assistantSend');
  await page.waitForTimeout(400);
  reply = await page.textContent('#assistantReply');
  ok('A3 save note via assistant', reply.includes('تم حفظ الملاحظة'), reply);
  await page.fill('#assistantInput', 'اعرض المهام');
  await page.click('#assistantSend');
  await page.waitForTimeout(400);
  reply = await page.textContent('#assistantReply');
  ok('A4 list tasks shows added task', reply.includes('اختبار الدواء'), reply);
  // persistence & timestamps
  const stored = await page.evaluate(() => JSON.parse(localStorage.getItem('janni.v1')));
  ok('A5 storage key janni.v1 kept', !!stored && stored.tasks.length === 1 && stored.notes.length === 1);
  ok('A6 createdAt present on task/note', !!stored.tasks[0].createdAt && !!stored.notes[0].updatedAt);
  // reload persists
  await page.reload(); await page.waitForTimeout(400);
  const after = await page.evaluate(() => JSON.parse(localStorage.getItem('janni.v1')));
  ok('A7 data survives reload', after.tasks.length === 1 && after.notes.length === 1);
  // settings: http rejected, https accepted
  await page.evaluate(() => document.getElementById('openSettings').click());
  await page.waitForTimeout(200);
  await page.fill('#setAiUrl', 'http://insecure.example/x');
  await page.click('#setSaveProfile');
  await page.waitForTimeout(300);
  let alertTxt = await page.textContent('#askText').catch(()=> '');
  let saved1 = await page.evaluate(() => JSON.parse(localStorage.getItem('janni.v1')).settings.aiUrl);
  ok('B1 http:// AI url rejected (not saved)', saved1 === '', 'saved=' + saved1);
  // dismiss ask overlay if open
  await page.evaluate(() => { const o=document.querySelector('.overlay.show, #askOverlay.show'); if(o) o.classList.remove('show'); });
  await page.fill('#setAiUrl', 'https://example.com/janni');
  await page.click('#setSaveProfile');
  await page.waitForTimeout(300);
  let saved2 = await page.evaluate(() => JSON.parse(localStorage.getItem('janni.v1')).settings.aiUrl);
  ok('B2 https AI url saved', saved2 === 'https://example.com/janni', saved2);
  const diag = await page.textContent('#diagBox');
  ok('B3 diagnostics states speaker verification NOT implemented', diag.includes('غير مُنفَّذ'), diag.slice(-80));
  await ctx.close();

  // Scenario C: legacy data migration (old default name + notes without timestamps)
  ctx = await browser.newContext({ locale: 'ar-SA' });
  page = await ctx.newPage();
  const errs2 = []; page.on('pageerror', e => errs2.push(String(e)));
  await page.addInitScript(() => {
    if (!sessionStorage.getItem('seeded')) {
      sessionStorage.setItem('seeded','1');
      localStorage.setItem('janni.v1', JSON.stringify({ settings: { name: 'صديقي', aiUrl: '' },
        tasks: [{ id: 't1', title: 'قديمة', done: false, date: '', created: 1700000000000 }],
        notes: [{ id: 'n1', title: 'n', text: 'ملاحظة قديمة', created: 1700000000000, updated: 1700000100000 }],
        reminders: [], contacts: [] }));
    }
  });
  await page.goto(URL); await page.waitForTimeout(500);
  const mig = await page.evaluate(() => JSON.parse(localStorage.getItem('janni.v1')));
  ok('C1 old default name migrated', mig.settings.name === 'أبا يزيد', mig.settings.name);
  ok('C2 old task kept (not deleted)', mig.tasks.length === 1 && mig.tasks[0].title === 'قديمة');
  ok('C3 old note kept with old fields + ISO timestamp', mig.notes[0].text === 'ملاحظة قديمة' && mig.notes[0].updated === 1700000100000 && typeof mig.notes[0].updatedAt === 'string');
  // Scenario D: reminder assistant still works (non-native path)
  await page.fill('#assistantInput', 'ذكرني بالدواء بعد دقيقتين');
  await page.click('#assistantSend');
  await page.waitForTimeout(600);
  const rem = await page.evaluate(() => JSON.parse(localStorage.getItem('janni.v1')).reminders.length);
  const rr = await page.textContent('#assistantReply');
  ok('D1 reminder created from voice/text command', rem === 1, rr);
  const bak = await page.evaluate(() => localStorage.getItem('janni.v1.backup-0.4'));
  ok('C5 original data backed up before migration', !!bak && bak.includes('صديقي'));
  // Scenario E: corrupt stored data must NOT be overwritten
  const ctxE = await browser.newContext({ locale: 'ar-SA' });
  const pE = await ctxE.newPage(); const errsE = []; pE.on('pageerror', e => errsE.push(String(e)));
  await pE.addInitScript(() => { if (!sessionStorage.getItem('s')) { sessionStorage.setItem('s','1'); localStorage.setItem('janni.v1', '{broken json'); } });
  await pE.goto(URL); await pE.waitForTimeout(400);
  await pE.fill('#assistantInput', 'اضف مهمة لن تحفظ'); await pE.click('#assistantSend'); await pE.waitForTimeout(300);
  const rawE = await pE.evaluate(() => localStorage.getItem('janni.v1'));
  ok('E1 corrupt data left untouched', rawE === '{broken json', rawE);
  ok('E2 no JS errors on corrupt data', errsE.length === 0, errsE.join(' | '));
  await ctxE.close();
  ok('C4 no JS page errors (migration scenario)', errs2.length === 0, errs2.join(' | '));
  ok('A8 no JS page errors (fresh scenario)', errs.length === 0, errs.join(' | '));
  // Scenario F: شاشة المحادثة مع جني. الطلبات إلى الخادم تُعترَض وهميًا (لا شبكة حقيقية)
  ctx = await browser.newContext({ locale: 'ar-SA' });
  page = await ctx.newPage();
  const errsF = []; page.on('pageerror', e => errsF.push(String(e)));
  await page.addInitScript(() => {
    if (!localStorage.getItem('seededF')) {
      localStorage.setItem('seededF', '1');
      localStorage.setItem('janni.v1', JSON.stringify({
        settings: { name: 'أبا يزيد', aiUrl: 'https://example.com/janni', voiceReply: false },
        tasks: [{ id: 'tk1', title: 'سرّ-مهمة-456', done: false, date: '', created: Date.now() }],
        notes: [{ id: 'nt1', title: 'سرّ', text: 'سرّ-ملاحظة-123', created: Date.now(), updated: Date.now() }],
        reminders: [], contacts: []
      }));
    }
  });
  const aiBodies = [];
  let aiReply = 'رد تجريبي من جني', aiStatus = 200;
  await page.route('https://example.com/janni', async route => {
    const headers = { 'access-control-allow-origin': '*', 'access-control-allow-headers': 'content-type' };
    if (route.request().method() === 'OPTIONS') return route.fulfill({ status: 204, headers });
    aiBodies.push(route.request().postData() || '');
    if (aiStatus !== 200) return route.fulfill({ status: aiStatus, headers, contentType: 'application/json', body: '{}' });
    return route.fulfill({ status: 200, headers, contentType: 'application/json', body: JSON.stringify({ reply: aiReply }) });
  });
  // نخدم الصفحة من أصل https عادي (مثل WebView في التطبيق) لتكون التخزين المحلي مستقرًا عند إعادة التحميل
  const pageHtmlF = require('fs').readFileSync(require('path').resolve(process.argv[2] || 'www/index.html'));
  await page.route('https://janni.local/**', r => r.fulfill({ status: 200, contentType: 'text/html; charset=utf-8', body: pageHtmlF }));
  await page.route('https://janni.local/config.js', r => r.fulfill({ status: 200, contentType: 'application/javascript', body: 'window.JANNI_CONFIG = { defaultAiUrl: "" };' }));
  await page.goto('https://janni.local/index.html'); await page.waitForTimeout(500);
  await page.click('#openChatTop'); await page.waitForTimeout(200);
  ok('F0 chat screen opens from header', await page.isVisible('#view-chat'));
  await page.fill('#chatInput', 'ما عاصمة السودان؟');
  await page.click('#chatSend');
  await page.waitForSelector('#chatList .bubble.ai', { timeout: 5000 });
  const aiTxt = await page.textContent('#chatList .bubble.ai .bcontent');
  ok('F1 AI reply shown in chat', aiTxt.includes('رد تجريبي من جني'), aiTxt);
  const sentF = JSON.parse(aiBodies[aiBodies.length - 1] || '{}');
  ok('F2 request has action chat and conversation history', sentF.action === 'chat' && Array.isArray(sentF.messages) && sentF.messages.at(-1).role === 'user' && sentF.messages.at(-1).content === 'ما عاصمة السودان؟');
  ok('F3 notes and tasks are never sent to the AI', !aiBodies.some(b => b.includes('سرّ-ملاحظة-123') || b.includes('سرّ-مهمة-456')));

  const PNG_1x1 = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=', 'base64');
  await page.setInputFiles('#chatFile', { name: 'photo.png', mimeType: 'image/png', buffer: PNG_1x1 });
  await page.waitForFunction(() => !document.getElementById('chatPreview').classList.contains('hidden'), null, { timeout: 4000 });
  ok('F4 attached image shows a preview', await page.isVisible('#chatPreviewImg'));
  aiReply = 'أرى صورة صغيرة';
  await page.fill('#chatInput', 'ما هذه الصورة؟');
  await page.click('#chatSend');
  await page.waitForFunction(() => document.querySelectorAll('#chatList .bubble.ai').length >= 2, null, { timeout: 5000 });
  const imgMsg = JSON.parse(aiBodies[aiBodies.length - 1]).messages.at(-1);
  ok('F5 image sent as base64 JPEG together with the question', !!imgMsg.image && imgMsg.image.mime === 'image/jpeg' && imgMsg.image.data.length > 20 && imgMsg.content === 'ما هذه الصورة؟');
  ok('F6 preview cleared after sending', await page.isHidden('#chatPreview'));

  aiReply = '**مهم**: زر https://example.com/a?x=1&y=2. <img src=x onerror="window.__xss=1">\n- نقطة\n```\nconsole.log(1)\n```\n[click](javascript:alert(1))';
  await page.fill('#chatInput', 'اختبار الروابط');
  await page.click('#chatSend');
  await page.waitForFunction(() => document.querySelectorAll('#chatList .bubble.ai').length >= 3, null, { timeout: 5000 });
  const info = await page.evaluate(() => {
    const last = [...document.querySelectorAll('#chatList .bubble.ai')].at(-1);
    return {
      links: [...last.querySelectorAll('a')].map(a => a.getAttribute('href')),
      imgs: last.querySelectorAll('img').length,
      xss: window.__xss === 1,
      strong: !!last.querySelector('strong'),
      pre: !!last.querySelector('pre.code'),
      jsLinks: last.querySelectorAll('a[href^="javascript"]').length
    };
  });
  ok('F7 only the https link becomes clickable', info.links.length === 1 && info.links[0].startsWith('https://example.com/a'), JSON.stringify(info.links));
  ok('F8 HTML in replies is escaped (no img, no script, no js links)', info.imgs === 0 && !info.xss && info.jsLinks === 0);
  ok('F9 bold, bullets and code blocks are rendered', info.strong && info.pre);

  aiStatus = 429;
  await page.fill('#chatInput', 'سؤال كثير');
  await page.click('#chatSend');
  await page.waitForFunction(() => document.querySelectorAll('#chatList .bubble.err').length >= 1, null, { timeout: 5000 });
  const errTxt = await page.textContent('#chatList .bubble.err');
  ok('F10 rate limit shows a friendly Arabic error', errTxt.includes('الحد المسموح'), errTxt);
  aiStatus = 200;

  await page.reload(); await page.waitForTimeout(400);
  const stF = await page.evaluate(() => JSON.parse(localStorage.getItem('janni.v1')).chat.length);
  const dbgF = await page.evaluate(() => ({ flag: localStorage.getItem('seededF'), corrupt: !!window.__janniCorrupt, aiUrl: JSON.parse(localStorage.getItem('janni.v1')).settings.aiUrl }));
  ok('F11 chat history survives reload', stF >= 6, stF + ' ' + JSON.stringify(dbgF));

  const callsBeforeOff = aiBodies.length;
  await page.click('#openSettings'); await page.waitForTimeout(150);
  await page.fill('#setAiUrl', '');
  await page.click('#setSaveProfile'); await page.waitForTimeout(200);
  await page.click('#openChatTop'); await page.waitForTimeout(150);
  await page.fill('#chatInput', 'مرحبا'); await page.click('#chatSend');
  await page.waitForTimeout(300);
  ok('F12 without an AI address, chat explains how to enable it', (await page.textContent('#chatList')).includes('غير مفعّل'));
  ok('F13 nothing leaves the device when AI is off', aiBodies.length === callsBeforeOff);
  ok('F14 no JS page errors in chat flows', errsF.length === 0, errsF.join(' | '));
  await ctx.close();

  // Scenario G: العنوان الافتراضي من config.js يُطبَّق تلقائيًا عند التثبيت، ولا يستبدل اختيار المستخدم
  const pageHtmlG = require('fs').readFileSync(require('path').resolve(process.argv[2] || 'www/index.html'));
  const serveG = async (page, seed) => {
    if (seed) await page.addInitScript(seed);
    await page.route('https://janni.local/**', r => r.fulfill({ status: 200, contentType: 'text/html; charset=utf-8', body: pageHtmlG }));
    await page.route('https://janni.local/config.js', r => r.fulfill({ status: 200, contentType: 'application/javascript', body: 'window.JANNI_CONFIG = { defaultAiUrl: "https://example.com/janni" };' }));
    await page.goto('https://janni.local/index.html'); await page.waitForTimeout(400);
    await page.click('#openSettings'); await page.waitForTimeout(150);
    return page.inputValue('#setAiUrl');
  };
  ctx = await browser.newContext({ locale: 'ar-SA' });
  page = await ctx.newPage();
  const errsG = []; page.on('pageerror', e => errsG.push(String(e)));
  const gFresh = await serveG(page, () => { if (!localStorage.getItem('seededG0')) { localStorage.setItem('seededG0', '1'); localStorage.removeItem('janni.v1'); } });
  ok('G1 fresh install gets the default AI address from config.js', gFresh === 'https://example.com/janni', gFresh);
  await ctx.close();

  ctx = await browser.newContext({ locale: 'ar-SA' });
  page = await ctx.newPage();
  const gCleared = await serveG(page, () => {
    if (!localStorage.getItem('seededG1')) {
      localStorage.setItem('seededG1', '1');
      localStorage.setItem('janni.v1', JSON.stringify({ settings: { name: 'أبا يزيد', aiUrl: '', aiTouched: true }, tasks: [], notes: [], reminders: [], contacts: [] }));
    }
  });
  ok('G2 an address the user cleared is not overwritten by the default', gCleared === '', gCleared);
  ok('G3 no JS page errors with config.js', errsG.length === 0, errsG.join(' | '));
  await ctx.close();

  // Scenario H: المضافات. إضافة خدمة ذكاء اصطناعي، وتفعيلها، ورفض العناوين غير الآمنة
  ctx = await browser.newContext({ locale: 'ar-SA' });
  page = await ctx.newPage();
  const errsH = []; page.on('pageerror', e => errsH.push(String(e)));
  await page.route('https://janni.local/**', r => r.fulfill({ status: 200, contentType: 'text/html; charset=utf-8', body: pageHtmlG }));
  await page.route('https://janni.local/config.js', r => r.fulfill({ status: 200, contentType: 'application/javascript', body: 'window.JANNI_CONFIG = { defaultAiUrl: "" };' }));
  const hBodies = [];
  await page.route('https://example.org/janni', async r => {
    if (r.request().method() === 'OPTIONS') return r.fulfill({ status: 204, headers: { 'access-control-allow-origin': '*', 'access-control-allow-headers': 'content-type' } });
    hBodies.push(r.request().postData() || '');
    return r.fulfill({ status: 200, headers: { 'access-control-allow-origin': '*' }, contentType: 'application/json', body: JSON.stringify({ reply: 'من خادم المضاف' }) });
  });
  await page.goto('https://janni.local/index.html'); await page.waitForTimeout(400);
  await page.click('#openSettings'); await page.waitForTimeout(150);
  ok('H0 presets are shown', (await page.locator('#addonPresets [data-preset]').count()) === 5);
  await page.fill('#addonName', 'Claude خاص');
  await page.selectOption('#addonType', 'ai');
  await page.fill('#addonUrl', 'http://insecure.example/x');
  await page.click('#addonAdd'); await page.waitForTimeout(150);
  ok('H1 http address rejected for add-ons', (await page.locator('#addonList .item').count()) === 0);
  await page.click('#askOk'); await page.waitForTimeout(100);
  await page.fill('#addonUrl', 'https://example.org/janni');
  await page.click('#addonAdd'); await page.waitForTimeout(150);
  ok('H2 AI add-on added', (await page.locator('#addonList .item').count()) === 1);
  await page.click('[data-addon-use]'); await page.waitForTimeout(150);
  const activeUrl = await page.evaluate(() => JSON.parse(localStorage.getItem('janni.v1')).settings.aiUrl);
  ok('H3 activating an AI add-on sets the chat server', activeUrl === 'https://example.org/janni', activeUrl);
  await page.click('#openChatTop'); await page.waitForTimeout(150);
  await page.fill('#chatInput', 'مرحبا'); await page.click('#chatSend');
  await page.waitForSelector('#chatList .bubble.ai', { timeout: 5000 });
  ok('H4 chat uses the activated add-on', (await page.textContent('#chatList .bubble.ai .bcontent')).includes('من خادم المضاف') && hBodies.length === 1);
  ok('H5 no JS page errors with add-ons', errsH.length === 0, errsH.join(' | '));
  await ctx.close();

  // Scenario I: مكتبة الذكاء الاصطناعي. جلب المزوّدين، اختيار أحدهم، وإرساله مع المحادثة
  ctx = await browser.newContext({ locale: 'ar-SA' });
  page = await ctx.newPage();
  const errsI = []; page.on('pageerror', e => errsI.push(String(e)));
  await page.route('https://janni.local/**', r => r.fulfill({ status: 200, contentType: 'text/html; charset=utf-8', body: pageHtmlG }));
  await page.route('https://janni.local/config.js', r => r.fulfill({ status: 200, contentType: 'application/javascript', body: 'window.JANNI_CONFIG = { defaultAiUrl: "" };' }));
  const iBodies = [];
  await page.route('https://example.net/janni', async r => {
    const headers = { 'access-control-allow-origin': '*', 'access-control-allow-headers': 'content-type' };
    if (r.request().method() === 'OPTIONS') return r.fulfill({ status: 204, headers });
    const body = JSON.parse(r.request().postData() || '{}');
    iBodies.push(body);
    if (body.action === 'providers') return r.fulfill({ status: 200, headers, contentType: 'application/json', body: JSON.stringify({ default: 'anthropic', providers: [
      { id: 'anthropic', name: 'Claude (Anthropic)', model: 'claude-haiku-5-5', enabled: true },
      { id: 'gemini', name: 'Gemini (Google)', model: 'gemini-3.8-flash', enabled: true },
      { id: 'openai', name: 'ChatGPT (OpenAI)', model: 'gpt-4o-mini', enabled: false }] }) });
    return r.fulfill({ status: 200, headers, contentType: 'application/json', body: JSON.stringify({ reply: 'رد من المزوّد', provider: body.provider || 'anthropic' }) });
  });
  await page.route('https://example.org/other', r => r.fulfill({ status: 200, headers: { 'access-control-allow-origin': '*' }, body: '{}' }));
  await page.goto('https://janni.local/index.html'); await page.waitForTimeout(400);
  await page.click('#openSettings'); await page.waitForTimeout(150);
  await page.fill('#setAiUrl', 'https://example.net/janni');
  await page.click('#setSaveProfile'); await page.waitForTimeout(150);
  await page.click('#aiLibRefresh'); await page.waitForTimeout(400);
  ok('I1 library lists Puter plus server providers with ready/not-configured state',
    (await page.locator('#aiLibList .item').count()) === 4 && (await page.textContent('#aiLibList')).includes('غير مُعدّ'));
  ok('I2 Puter and ready server providers can be picked, not-configured ones cannot', (await page.locator('[data-ai-pick]').count()) === 3);
  await page.click('[data-ai-pick="gemini"]'); await page.waitForTimeout(150);
  const picked = await page.evaluate(() => JSON.parse(localStorage.getItem('janni.v1')).settings);
  ok('I3 picked provider is stored', picked.aiProvider === 'gemini' && picked.aiProviderName === 'Gemini (Google)', String(picked.aiProvider));
  await page.click('#openChatTop'); await page.waitForTimeout(150);
  await page.fill('#chatInput', 'مرحبا'); await page.click('#chatSend');
  await page.waitForSelector('#chatList .bubble.ai', { timeout: 5000 });
  const chatReq = iBodies.filter(b => b.action === 'chat').at(-1) || {};
  ok('I4 chat request carries the chosen provider', chatReq.provider === 'gemini');
  ok('I5 chat notice shows the active provider', (await page.textContent('#chatNotice')).includes('Gemini (Google)'));
  await page.click('#openSettings'); await page.waitForTimeout(150);
  await page.click('#aiLibAuto'); await page.waitForTimeout(150);
  const auto = await page.evaluate(() => JSON.parse(localStorage.getItem('janni.v1')).settings.aiProvider);
  ok('I6 automatic clears the provider', auto === '', String(auto));
  await page.click('#aiLibRefresh'); await page.waitForTimeout(300);
  await page.click('[data-ai-pick="gemini"]'); await page.waitForTimeout(100);
  await page.fill('#setAiUrl', 'https://example.org/other');
  await page.click('#setSaveProfile'); await page.waitForTimeout(150);
  const afterSwitch = await page.evaluate(() => JSON.parse(localStorage.getItem('janni.v1')).settings.aiProvider);
  ok('I7 changing the server address clears the provider', afterSwitch === '', String(afterSwitch));
  ok('I8 no JS page errors in library flows', errsI.length === 0, errsI.join(' | '));
  await ctx.close();

  // Scenario J: مزوّد Puter المدمج يعمل بدون خادم، ويتعامل مع فشل تحميل Puter بوضوح
  const PUTER_FAKE = `window.__puterCalls = []; window.puter = { ai: { chat: async (messages, opts) => {
    window.__puterCalls.push({ messages, opts });
    return { message: { role: 'assistant', content: 'رد من Puter' } };
  } } };`;
  ctx = await browser.newContext({ locale: 'ar-SA' });
  page = await ctx.newPage();
  const errsJ = []; page.on('pageerror', e => errsJ.push(String(e)));
  await page.route('https://janni.local/**', r => r.fulfill({ status: 200, contentType: 'text/html; charset=utf-8', body: pageHtmlG }));
  await page.route('https://janni.local/config.js', r => r.fulfill({ status: 200, contentType: 'application/javascript', body: 'window.JANNI_CONFIG = { defaultAiUrl: "" };' }));
  await page.route('https://js.puter.com/v2/', r => r.fulfill({ status: 200, contentType: 'application/javascript', body: PUTER_FAKE }));
  let serverHitsJ = 0;
  await page.route('https://example.net/janni', r => { serverHitsJ++; return r.fulfill({ status: 500, body: '{}' }); });
  await page.goto('https://janni.local/index.html'); await page.waitForTimeout(400);
  await page.click('#openSettings'); await page.waitForTimeout(150);
  ok('J1 Puter option is listed without any server', (await page.locator('[data-ai-pick="puter"]').count()) === 1);
  await page.click('[data-ai-pick="puter"]'); await page.waitForTimeout(150);
  const jSet = await page.evaluate(() => JSON.parse(localStorage.getItem('janni.v1')).settings);
  ok('J2 Puter is stored as provider and no server address is needed', jSet.aiProvider === 'puter' && !jSet.aiUrl, String(jSet.aiProvider));
  await page.click('#openChatTop'); await page.waitForTimeout(150);
  await page.fill('#chatInput', 'ما عاصمة السودان؟'); await page.click('#chatSend');
  await page.waitForSelector('#chatList .bubble.ai', { timeout: 8000 });
  ok('J3 chat reply comes from Puter', (await page.textContent('#chatList .bubble.ai .bcontent')).includes('رد من Puter'));
  const pc = await page.evaluate(() => window.__puterCalls);
  ok('J4 Puter gets system prompt, the question and the model', pc.length === 1 && pc[0].messages[0].role === 'system' && pc[0].messages.at(-1).content === 'ما عاصمة السودان؟' && pc[0].opts.model === 'gpt-5.4-nano');
  ok('J5 server is not contacted when Puter is selected', serverHitsJ === 0, String(serverHitsJ));
  ok('J6 no JS page errors with Puter', errsJ.length === 0, errsJ.join(' | '));
  await ctx.close();

  // J7: فشل تحميل Puter يظهر رسالة خطأ واضحة داخل المحادثة
  ctx = await browser.newContext({ locale: 'ar-SA' });
  page = await ctx.newPage();
  const errsJ2 = []; page.on('pageerror', e => errsJ2.push(String(e)));
  await page.route('https://janni.local/**', r => r.fulfill({ status: 200, contentType: 'text/html; charset=utf-8', body: pageHtmlG }));
  await page.route('https://janni.local/config.js', r => r.fulfill({ status: 200, contentType: 'application/javascript', body: 'window.JANNI_CONFIG = { defaultAiUrl: "" };' }));
  await page.route('https://js.puter.com/v2/', r => r.abort());
  await page.addInitScript(() => {
    if (!localStorage.getItem('seedJ')) {
      localStorage.setItem('seedJ', '1');
      localStorage.setItem('janni.v1', JSON.stringify({ settings: { name: 'أبا يزيد', aiProvider: 'puter', aiProviderName: 'Puter' }, tasks: [], notes: [], reminders: [], contacts: [], chat: [] }));
    }
  });
  await page.goto('https://janni.local/index.html'); await page.waitForTimeout(300);
  await page.click('#openChatTop'); await page.waitForTimeout(150);
  await page.fill('#chatInput', 'مرحبا'); await page.click('#chatSend');
  await page.waitForSelector('#chatList .bubble.ai', { timeout: 8000 });
  const jErr = await page.textContent('#chatList .bubble.ai .bcontent');
  ok('J7 failed Puter load shows a clear Arabic error', jErr.includes('تعذّر تحميل خدمة Puter'), jErr);
  ok('J8 no unhandled JS errors when Puter fails to load', errsJ2.length === 0, errsJ2.join(' | '));
  await ctx.close();

  // Scenario K (0.7.1): أيقونات ثابتة، وزر ❓ مخفي داخل المحادثة، والرد الصوتي عبر Puter
  ctx = await browser.newContext({ locale: 'ar-SA' });
  page = await ctx.newPage();
  const errsK = []; page.on('pageerror', e => errsK.push(String(e)));
  await page.route('https://janni.local/**', r => r.fulfill({ status: 200, contentType: 'text/html; charset=utf-8', body: pageHtmlG }));
  await page.route('https://janni.local/config.js', r => r.fulfill({ status: 200, contentType: 'application/javascript', body: 'window.JANNI_CONFIG = { defaultAiUrl: "" };' }));
  await page.route('https://js.puter.com/v2/', r => r.fulfill({ status: 200, contentType: 'application/javascript', body: `
    window.__speech = []; window.__puterChat = 0;
    window.puter = { ai: {
      chat: async () => { window.__puterChat++; return { message: { role: 'assistant', content: 'رد صوتي تجريبي' } }; },
      txt2speech: async (text, opts) => { window.__speech.push({ text, opts }); return { play: async () => {} }; }
    } };` }));
  await page.addInitScript(() => {
    if (!localStorage.getItem('seedK')) {
      localStorage.setItem('seedK', '1');
      localStorage.setItem('janni.v1', JSON.stringify({ settings: { name: 'أبا يزيد', aiProvider: 'puter', aiProviderName: 'Puter', voiceReply: true }, tasks: [], notes: [], reminders: [], contacts: [], chat: [] }));
    }
  });
  await page.goto('https://janni.local/index.html'); await page.waitForTimeout(400);
  ok('K1 header has fixed shortcuts for tasks and files', (await page.locator('header [data-go="tasks"]').count()) === 1 && (await page.locator('header [data-go="recordings"]').count()) === 1);
  await page.click('header [data-go="tasks"]'); await page.waitForTimeout(150);
  ok('K2 header tasks shortcut opens the tasks view', await page.isVisible('#view-tasks'));
  await page.click('#openChatTop'); await page.waitForTimeout(150);
  ok('K3 floating ❓ button is hidden inside chat', !(await page.isVisible('#fabQA')));
  await page.fill('#chatInput', 'مرحبا'); await page.click('#chatSend');
  await page.waitForFunction(() => window.__speech && window.__speech.length === 1, null, { timeout: 8000 }).catch(() => {});
  const sp = await page.evaluate(() => window.__speech);
  ok('K4 reply is spoken through Puter when Puter is the provider', sp.length === 1 && sp[0].text === 'رد صوتي تجريبي', JSON.stringify(sp).slice(0, 120));
  ok('K5 no JS page errors in voice and icon flows', errsK.length === 0, errsK.join(' | '));
  await ctx.close();

  await browser.close();
  for (const r of results) console.log(r[0], r[1], r[2] ? '-- ' + r[2] : '');
  const fails = results.filter(r => r[0] === 'FAIL').length;
  console.log(`\n${results.length - fails}/${results.length} passed`);
})().catch(e => { console.error('RUNNER ERROR', e); process.exit(1); });
