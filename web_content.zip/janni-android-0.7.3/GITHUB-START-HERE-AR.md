# بدء بناء مفكرة جني من الهاتف

1. افتح رابط إنشاء مستودع GitHub: https://github.com/new
2. أنشئ مستودعًا باسم `janni-notebook`.
3. ارفع الملف `Janni-0.7.3-Sudanese.zip` إلى المستودع كما هو.
4. في GitHub افتح Add file ثم Create new file، واكتب اسم الملف:
   `.github/workflows/build-apk.yml`
5. افتح الملف `GITHUB-BOOTSTRAP.yml` الموجود داخل حزمة جني، وانسخ محتواه كاملًا إلى الملف الجديد، ثم احفظه (Commit changes).
6. افتح تبويب Actions، ثم Build Janni APK، ثم Run workflow.
7. بعد نجاح التشغيل افتح نتيجة التشغيل ونزّل Artifact باسم `janni-debug-apk`، ثم فك ضغطه وثبّت `app-debug.apk`.

ملاحظة: وجود ملف GitHub داخل ZIP يحفظه مع المشروع، لكن GitHub لا يشغّل Workflow وهو داخل ZIP. لذلك يلزم إنشاء نسخة منه في المسار `.github/workflows/build-apk.yml` داخل المستودع مرة واحدة.

رابط إنشاء المستودع: https://github.com/new
