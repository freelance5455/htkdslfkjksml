রুবি স্টোর v13 — Multi-device Cloud Sync

এই ZIP-এ Firebase Authentication + Firestore sync-এর কাঠামো যোগ করা হয়েছে।
চালু করতে একবার Firebase project তৈরি করে firebase-config.js-এ Web App config বসাতে হবে।

ধাপ ১: Firebase Console-এ একটি Project তৈরি করুন।
ধাপ ২: Authentication > Sign-in method > Email/Password চালু করুন।
ধাপ ৩: Firestore Database তৈরি করুন (Production mode)।
ধাপ ৪: firestore.rules-এর নিয়ম Firestore Rules-এ বসান।
ধাপ ৫: Project settings > Your apps > Web app থেকে config কপি করে firebase-config.js-এ বসান।
ধাপ ৬: index.html, firebase-config.js, manifest.webmanifest, sw.js একই folder/ZIP-এ রাখুন।
ধাপ ৭: ZIP-to-APK/PWA converter-এ RubyStore_web_apk_v13.zip ব্যবহার করুন।

গুরুত্বপূর্ণ: Firebase config-এ secret/private key থাকে না; Service Account JSON এই অ্যাপে দেবেন না।

ডেটা: প্রতিটি account-এর ডেটা users/{Firebase UID}-তে থাকে। ফলে একই email/password দিয়ে একাধিক device-এ login করলে একই cloud data দেখা যাবে।
