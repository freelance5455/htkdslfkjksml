ANIME FIGHT — PROJET ANDROID
============================

Ce dossier contient un projet Android Studio qui embarque le prototype Anime Fight dans une application Android en mode paysage.

IMPORTANT
---------
Ceci est le projet source prêt à compiler, pas encore un fichier APK compilé. Pour produire l'APK, Android Studio doit télécharger les composants Android/Gradle nécessaires et construire le projet.

ÉTAPES SUR UN ORDINATEUR
------------------------
1. Installe Android Studio depuis le site officiel Android Developers.
2. Décompresse AnimeFightAndroid.zip.
3. Dans Android Studio, choisis "Open" et sélectionne le dossier AnimeFightAndroid.
4. Accepte la synchronisation Gradle et l'installation éventuelle du SDK Android demandé.
5. Pour tester sur un téléphone : active les options développeur et le débogage USB sur le téléphone, connecte-le au PC, puis clique sur Run.
6. Pour créer un APK : menu Build > Build Bundle(s) / APK(s) > Build APK(s).
7. Android Studio affiche un lien vers l'APK généré. Tu peux ensuite transférer cet APK sur ton téléphone et l'installer. Android peut demander d'autoriser l'installation depuis cette source.

STRUCTURE
---------
app/src/main/assets/index.html : le jeu.
app/src/main/java/com/animefight/app/MainActivity.java : l'écran Android qui ouvre le jeu.
app/src/main/AndroidManifest.xml : configuration de l'application.

Le jeu fonctionne hors ligne, car son prototype est intégré dans les ressources de l'application.
