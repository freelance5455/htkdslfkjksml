MR,KHORASANI v1.6.5 — Android Build

1) android/ را در Android Studio باز کنید یا Workflow GitHub Actions را اجرا کنید.
2) API 36 SDK و Build Tools مربوط به آن را نصب کنید.
3) Release APK از app:assembleRelease ساخته می‌شود.
4) Artifact نهایی با نام MR-KHORASANI-v1.6.3-universal-release.apk در Actions ذخیره می‌شود.
