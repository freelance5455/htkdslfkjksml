STUDIO CRÉA — PROJET ANDROID WEBVIEW

Contenu :
- app/src/main/assets/index.html : éditeur graphique hors ligne
- projet Android WebView minimal pour créer une APK

IMPORTANT :
Ce dossier est le code source, pas une APK déjà compilée.
Pour compiler gratuitement sur Android :
1. Installe une application de développement Android compatible Gradle (par exemple AndroidIDE) depuis sa source officielle.
2. Décompresse ce dossier dans le stockage du téléphone.
3. Ouvre le dossier du projet dans l'IDE et laisse Gradle synchroniser les dépendances (connexion Internet nécessaire à cette étape).
4. Lance la tâche assembleDebug.
5. Récupère app/build/outputs/apk/debug/app-debug.apk puis installe-la.
La disponibilité et la compatibilité des IDE mobiles peuvent varier selon Android et la mémoire du téléphone.

Fonctionnalités :
- modèles intégrés, texte, formes, images et fonds
- formats réseaux sociaux / A4
- calques, déplacement, duplication, ordre avant/arrière
- annuler/rétablir pour les modifications suivies
- export PNG et sauvegarde/chargement de projet JSON
Limite : les images importées ne sont pas intégrées dans la sauvegarde JSON.
