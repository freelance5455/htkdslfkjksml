# ANONYMOUX STUDIO 2.4.4 — Resources and Lip Sync update

## Resources page

The authenticated user-facing resource centre is `resources.php`. It has two managed collections:

- **Creative Tools:** provider name, category, logo, summary, full description, official website, official download links by platform, pricing, version, compatibility, system requirements, installation notes, featured status and publication state.
- **Tutorials & Learning:** title, URL slug, category, summary, Markdown lesson body, ordered step-by-step instructions, estimated reading time, difficulty, thumbnail, uploaded screenshots/GIFs, hosted video links, related tools/tutorials, featured status and publication state.

Only published entries are visible to ordinary users. Draft entries remain available in the administrator manager for review and editing. Public search and category filters are applied server-side.

## Admin management

1. Sign in with an administrator account.
2. Open **Admin console → Resources**.
3. Use **Creative tools** to add or edit software listings. Enter the official provider URL and official download-page links; do not upload third-party installer binaries.
4. Use **Tutorials** to author a lesson, add ordered steps (`Step title | Explanation`, one per line), upload a thumbnail and screenshots/GIFs, add supported video URLs, and link related resources.
5. Save as **Draft** while preparing. Change Publication to **Published** to make the item visible on the Resources page.
6. Use **Categories** to add, rename, sort or disable categories. Disabling a category preserves its existing resources.
7. Review **Admin console → Activity logs** for recorded resource changes.

Resource image uploads are restricted to JPEG, PNG, WebP and GIF, validated by detected MIME type and image dimensions, and limited to 5 MB each. Uploaded media is stored under private application storage and served through `resource-media.php`. Tutorial Markdown is rendered through the application's restricted renderer; raw HTML and scripts are not enabled.

## Lip Sync sidebar entry

A dedicated `lip-sync.php` entry opens the existing Magic Hour Lip Sync mode in `video-studio.php`. It uses the existing authenticated session, API endpoint, request idempotency, provider polling, credits and result/history handling. The separate **Video Studio** sidebar entry continues to open the Decart video transformation workspace. The Lip Sync sidebar entry remains visible when the provider is disabled so users can see the configuration notice rather than encountering a dead link.

## Deployment

Upload the flattened ZIP contents over the existing application. Preserve the existing private `config.local.php` and the live `storage/` contents; do not replace or delete them. Ensure the PHP account can write to `storage/resources/` when resource images are uploaded. Existing resource tables are additive and are created by `resources_schema()` on application access.
