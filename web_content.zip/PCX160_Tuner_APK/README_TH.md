# PCX160 TUNER — Android GPS APK Project

โครงนี้เอา HTML ของ PCX160 TUNER มาใส่ใน Android WebView และขอสิทธิ์ Location จาก Android โดยตรง

## วิธี build
1. เปิดโฟลเดอร์นี้ด้วย Android Studio
2. รอ Gradle Sync
3. Build > Build APK(s)
4. ติดตั้ง APK ในมือถือ
5. เปิดแอปและกด Allow Location
6. เข้า GPS แล้วกด START GPS

## หมายเหตุ
- GPS ใน APK ใช้ `navigator.geolocation` ผ่าน WebView origin แบบ appassets ไม่ใช่ `file://`
- ต้องเปิด Location ของ Android ด้วย
- ความเร็ว GPS จริงจะขึ้นเมื่อเครื่องรับตำแหน่งได้
- HTML เดิมยังคง ECU WRITE ล็อกไว้
