# DersTakip Android (tek cihaz, hesapsız sürüm)

Güncel arayüzü (haftalık plan, konu takibi, ödül/ceza, rapor) Android WebView içine alır. İnternet ve hesap gerektirmez, veriler telefonda saklanır.

## APK üretme
1. Android Studio'yu kurun, bu klasörü **Open** ile açın, Gradle senkronizasyonunun bitmesini bekleyin (ilk seferde internet ister).
2. **Build > Build Bundle(s) / APK(s) > Build APK(s)**
3. Bildirimdeki **locate** ile `app/build/outputs/apk/debug/app-debug.apk` dosyasını bulun.
4. Dosyayı telefona gönderin, açarken **bilinmeyen kaynaklardan yüklemeye izin verin**.

Not: Öğretmen/veli–öğrenci hesapları ve canlı takip bu sürümde yok, onlar Firebase'li `DersTakip_Play_Proje` içindedir.
