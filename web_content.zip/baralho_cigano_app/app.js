const cards=[
[1,"O Cavaleiro","🐎","notícias • movimento • chegada","Positiva","Movimento, novidades e acontecimentos que começam a ganhar forma.","Algo entra em movimento. Observe notícias, convites e oportunidades."],
[2,"O Trevo","🍀","sorte • oportunidade • imprevisto","Positiva","Pequenas oportunidades, sorte passageira e leveza.","Uma chance breve pode surgir. Aproveite com simplicidade."],
[3,"O Navio","⛵","viagem • distância • expansão","Neutra","Deslocamentos, viagens, saudade e novos horizontes.","Pode apontar movimento físico ou emocional e planos distantes."],
[4,"A Casa","🏠","lar • família • segurança","Positiva","Lar, família, intimidade, estrutura e proteção.","Fala da vida doméstica, das raízes e de uma base estável."],
[5,"A Árvore","🌳","saúde • raízes • crescimento","Positiva","Vitalidade, amadurecimento, ancestralidade e processos lentos.","Resultados sólidos costumam vir com constância e paciência."],
[6,"As Nuvens","☁️","dúvida • confusão • incerteza","Desafiadora","Dúvidas, falta de clareza e pensamentos embaralhados.","Espere a poeira baixar antes de tirar conclusões."],
[7,"A Serpente","🐍","estratégia • desejo • complicação","Desafiadora","Estratégia, sedução, caminhos indiretos ou ciúmes.","Observe nuances. A carta não prova traição por si só."],
[8,"O Caixão","⚰️","fim • transformação • encerramento","Desafiadora","Encerramento de ciclo, pausa e transformação profunda.","Algo chega ao fim ou pede mudança. Seu sentido é simbólico."],
[9,"O Buquê","💐","alegria • presente • gentileza","Positiva","Alegria, convite, gentileza, reconhecimento e beleza.","Pode representar um gesto agradável ou uma surpresa."],
[10,"A Foice","🌾","corte • decisão • ruptura","Desafiadora","Corte, decisão rápida, separação e acontecimentos repentinos.","Pede atenção e discernimento diante de mudanças."],
[11,"O Chicote","⚡","conflito • repetição • tensão","Desafiadora","Discussões, cobranças, padrões repetidos e tensão.","Observe conflitos recorrentes e hábitos que se repetem."],
[12,"Os Pássaros","🐦","conversa • ansiedade • troca","Neutra","Conversas, notícias, agitação e troca de ideias.","Fala de comunicação e movimento mental."],
[13,"A Criança","🧸","começo • inocência • novidade","Positiva","Novos começos, curiosidade e espontaneidade.","Uma situação está no início e ainda está se desenvolvendo."],
[14,"A Raposa","🦊","esperteza • cautela • trabalho","Desafiadora","Astúcia, estratégia, autoproteção e trabalho.","Use inteligência prática e confira informações."],
[15,"O Urso","🐻","força • proteção • poder","Neutra","Força, proteção, autoridade e recursos.","Observe relações de poder, proteção e limites."],
[16,"A Estrela","⭐","esperança • inspiração • guia","Positiva","Esperança, inspiração, orientação e criatividade.","Uma carta de confiança no futuro e clareza de propósito."],
[17,"A Cegonha","🕊️","mudança • renovação • novidade","Positiva","Mudanças, transições e renovação.","Algo se transforma ou muda de lugar."],
[18,"O Cão","🐕","amizade • lealdade • apoio","Positiva","Amizade, companheirismo, confiança e lealdade.","Valorize alianças confiáveis e quem demonstra constância."],
[19,"A Torre","🏛️","isolamento • instituição • limites","Neutra","Estrutura, instituições, autonomia e recolhimento.","Pode representar formalidades ou a necessidade de espaço."],
[20,"O Jardim","🌷","social • encontros • público","Positiva","Vida social, grupos, eventos e visibilidade pública.","Fala de encontros, redes e ambientes coletivos."],
[21,"A Montanha","⛰️","obstáculo • demora • resistência","Desafiadora","Obstáculos, atrasos e desafios persistentes.","Há algo que pede esforço ou uma rota alternativa."],
[22,"Os Caminhos","🛤️","escolha • opções • direção","Neutra","Escolhas, alternativas e responsabilidade sobre a direção.","Avalie caminhos e consequências."],
[23,"Os Ratos","🐀","desgaste • perda • preocupação","Desafiadora","Desgaste, preocupação e pequenos prejuízos.","Identifique o que está drenando tempo ou tranquilidade."],
[24,"O Coração","❤️","amor • afeto • paixão","Positiva","Amor, carinho, paixão e vínculos afetivos.","Aponta para sentimentos, mas não garante reciprocidade."],
[25,"O Anel","💍","compromisso • parceria • ciclo","Positiva","Compromissos, acordos, parcerias e contratos.","Observe vínculos e responsabilidades assumidas."],
[26,"O Livro","📖","segredo • estudo • conhecimento","Neutra","Conhecimento, estudo, mistério e informação reservada.","Há algo a descobrir. Liga-se à aprendizagem e pesquisa."],
[27,"A Carta","✉️","mensagem • documento • notícia","Neutra","Mensagens, documentos, convites e informações.","Pode representar cartas, avisos ou notícias escritas."],
[28,"O Cigano","🧔","masculino • consulente • iniciativa","Neutra","Tradicionalmente representa uma figura masculina ou o consulente.","A interpretação depende de quem consulta e do método."],
[29,"A Cigana","👩","feminino • consulente • receptividade","Neutra","Tradicionalmente representa uma figura feminina ou a consulente.","A interpretação depende de quem consulta e do método."],
[30,"Os Lírios","🪷","paz • maturidade • harmonia","Positiva","Paz, serenidade, maturidade e sabedoria.","Convida à calma, conciliação e maturidade."],
[31,"O Sol","☀️","sucesso • clareza • energia","Positiva","Sucesso, vitalidade, clareza e reconhecimento.","Algo pode ganhar visibilidade e ficar mais claro."],
[32,"A Lua","🌙","intuição • emoções • reconhecimento","Neutra","Intuição, imaginação, sensibilidade e emoções.","Fala do mundo emocional, criatividade e percepção."],
[33,"A Chave","🗝️","solução • abertura • resposta","Positiva","Soluções, respostas e abertura de caminhos.","Algo essencial pode ser compreendido ou resolvido."],
[34,"Os Peixes","🐟","dinheiro • abundância • fluxo","Positiva","Recursos, dinheiro, abundância e negócios.","Observe finanças, trocas e autonomia material."],
[35,"A Âncora","⚓","estabilidade • segurança • persistência","Positiva","Estabilidade, segurança, persistência e trabalho.","Representa sustentação, mas pode alertar para apego."],
[36,"A Cruz","✝️","fardo • destino • fé","Desafiadora","Responsabilidades, provações, fé e aprendizados difíceis.","Pode simbolizar uma carga ou compromisso importante."]
];
let filtro="Todas",study=0;
const $=id=>document.getElementById(id);
function render(){let q=$("busca").value.toLocaleLowerCase("pt-BR");let a=cards.filter(c=>(filtro==="Todas"||c[4]===filtro)&&c.slice(1,7).join(" ").toLocaleLowerCase("pt-BR").includes(q));$("cartas").innerHTML=a.map(c=>`<button class="tile" data-id="${c[0]}"><small>${String(c[0]).padStart(2,"0")} / 36</small><span class="emoji">${c[2]}</span><h3>${c[1]}</h3><p>${c[3]}</p></button>`).join("")||"<p>Nenhuma carta encontrada. ✧</p>"}
$("cartas").onclick=e=>{let b=e.target.closest("[data-id]");if(!b)return;let c=cards.find(x=>x[0]===+b.dataset.id);$("msimbolo").textContent=c[2];$("mnumero").textContent="CARTA "+String(c[0]).padStart(2,"0");$("mtitulo").textContent=c[1];$("mchaves").textContent=c[3];$("msignificado").textContent=c[5];$("mpratica").textContent=c[6];$("modal").hidden=false};
$("fechar").onclick=()=>$("modal").hidden=true;$("modal").querySelector(".shade").onclick=()=>$("modal").hidden=true;
$("busca").oninput=render;$("filtros").onclick=e=>{let b=e.target.closest("[data-f]");if(!b)return;filtro=b.dataset.f;document.querySelectorAll("#filtros button").forEach(x=>x.classList.toggle("sel",x===b));render()};
document.querySelector("nav").onclick=e=>{let b=e.target.closest("[data-tab]");if(!b)return;document.querySelectorAll("nav button").forEach(x=>x.classList.toggle("active",x===b));document.querySelectorAll(".page").forEach(x=>x.classList.toggle("active",x.id===b.dataset.tab))};
function studyShow(){let c=cards[study];$("simbolo").textContent=c[2];$("numero").textContent=`CARTA ${String(c[0]).padStart(2,"0")} DE 36`;$("nome").textContent=c[1];$("chaves").textContent=c[3];$("significado").textContent=c[5]}
$("anterior").onclick=()=>{study=(study+35)%36;studyShow()};$("proxima").onclick=()=>{study=(study+1)%36;studyShow()};
let questions=[],qi=0,points=0,answered=false;
function quizStart(){questions=[...cards].sort(()=>Math.random()-.5).slice(0,5);qi=0;points=0;quizShow()}
function quizShow(){answered=false;let c=questions[qi];$("progresso").textContent=`PERGUNTA ${qi+1} DE 5`;$("qsimbolo").textContent=c[2];$("pergunta").textContent=c[1];$("feedback").textContent="";$("seguinte").hidden=true;$("seguinte").textContent=qi===4?"Ver resultado":"Próxima pergunta →";let opts=[c,...cards.filter(x=>x!==c).sort(()=>Math.random()-.5).slice(0,3)].sort(()=>Math.random()-.5);$("opcoes").innerHTML=opts.map(x=>`<button data-answer="${x[0]}">${x[3]}</button>`).join("")}
$("opcoes").onclick=e=>{let b=e.target.closest("[data-answer]");if(!b||answered)return;answered=true;let c=questions[qi],ok=+b.dataset.answer===c[0];if(ok)points++;[...$("opcoes").children].forEach(x=>{x.disabled=true;if(+x.dataset.answer===c[0])x.classList.add("correct");else if(x===b)x.classList.add("wrong")});$("feedback").textContent=ok?"✦ Isso! Boa associação.":`Uma associação-chave é: ${c[3]}.`;$("seguinte").hidden=false};
$("seguinte").onclick=()=>{if(qi<4){qi++;quizShow()}else{$("qsimbolo").textContent="🏆";$("pergunta").textContent=`Você acertou ${points} de 5!`;$("opcoes").innerHTML="";$("feedback").textContent="Continue explorando as cartas e tente novamente.";$("seguinte").textContent="Jogar novamente";$("seguinte").onclick=()=>{ $("seguinte").onclick=nextQuiz;quizStart()}}};
const nextQuiz=$("seguinte").onclick;render();studyShow();quizStart();