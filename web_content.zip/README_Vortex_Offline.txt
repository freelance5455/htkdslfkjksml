Vortex Script Studio - Offline Update

This package is based on the supplied index.html and keeps its general layout.

Included updates:
- Login now requires a registered account; unknown accounts cannot auto-register during login.
- Offline code workspace: text/file import, URL import (subject to CORS), basic line checks.
- UI accent color and background image customization.
- Text/emoji/image URL watermark.
- Project metadata fields and template export.
- Download filename can use the entered metadata filename.
- AI/API integration is not included.

Notes:
- LocalStorage account credentials are not secure storage; do not use important passwords.
- The code checker is only a basic heuristic, not a full language compiler.
- URL import may fail due to browser CORS policies.
- Existing toggle/category UI is retained as interface elements, but generated output is a metadata/template file and does not implement game cheats, bypasses, or exploit functions.
- The Key System checkbox is disabled and treated as a placeholder; it does not provide real authentication or encryption.
