# CryptoPulse V2 — Stage 1109

## Wallet CPLS
- CPLS is now always visible in Wallet, even when its balance is zero.
- Label: CryptoPulse · Sepolia.
- No fake CPLS price or on-chain balance is introduced.
- If a CPLS balance is later populated in local wallet state, the row reflects that quantity.
- Existing BTC/USDT and other holdings remain separate.

## Safety
- No mainnet deployment.
- No fabricated contract address or transaction.
