function changeDirection(action) {
  if (phase !== "running") {
    return;
  }

  // साँप को सीधे उल्टी दिशा में जाने से रोकना
  if (action === "left" && dir.x === 0) {
    nextDir = { x: -1, y: 0 };
  }

  if (action === "right" && dir.x === 0) {
    nextDir = { x: 1, y: 0 };
  }

  if (action === "up" && dir.y === 0) {
    nextDir = { x: 0, y: -1 };
  }

  if (action === "down" && dir.y === 0) {
    nextDir = { x: 0, y: 1 };
  }
}

var touchStartX = 0;
var touchStartY = 0;

var gameArea = document.getElementById("game");
var restartButton = document.getElementById("restart");

gameArea.addEventListener("pointerdown", function (event) {
  if (event.target === restartButton) {
    return;
  }

  if (phase !== "running") {
    return;
  }

  touchStartX = event.clientX;
  touchStartY = event.clientY;
});

gameArea.addEventListener("pointerup", function (event) {
  if (event.target === restartButton) {
    return;
  }

  if (phase !== "running") {
    return;
  }

  var dx = event.clientX - touchStartX;
  var dy = event.clientY - touchStartY;

  // Swipe control
  if (Math.abs(dx) > 12 || Math.abs(dy) > 12) {
    if (Math.abs(dx) > Math.abs(dy)) {
      changeDirection(dx > 0 ? "right" : "left");
    } else {
      changeDirection(dy > 0 ? "down" : "up");
    }

    return;
  }

  // Tap control
  var rect = canvas.getBoundingClientRect();

  var tapX = event.clientX - rect.left;
  var tapY = event.clientY - rect.top;

  var headX = (snake[0].x + 0.5) * CELL;
  var headY = (snake[0].y + 0.5) * CELL;

  var differenceX = tapX - headX;
  var differenceY = tapY - headY;

  if (Math.abs(differenceX) > Math.abs(differenceY)) {
    changeDirection(differenceX > 0 ? "right" : "left");
  } else {
    changeDirection(differenceY > 0 ? "down" : "up");
  }
});

// Keyboard control
document.addEventListener("keydown", function (event) {
  var keys = {
    ArrowLeft: "left",
    ArrowRight: "right",
    ArrowUp: "up",
    ArrowDown: "down"
  };

  if (keys[event.key]) {
    event.preventDefault();
    changeDirection(keys[event.key]);
  }
});

// Start and restart button
restartButton.addEventListener("click", function (event) {
  event.stopPropagation();
  start();
});