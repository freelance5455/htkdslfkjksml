const keys = {};
let yaw = 0, pitch = 0.25, velY = 0, onGround = true;
let joyX = 0, joyZ = 0, isScoped = false, isRunning = false;
let hudEditMode = false;

function performJump() {
  if (onGround) {
    velY = 0.31;
    onGround = false;
    if (typeof playSoundEffect === 'function') playSoundEffect('jump');
  }
}

window.addEventListener('keydown', function(e) {
  keys[e.code] = true;
  if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') {
    isRunning = true;
    const runEl = document.getElementById('btn-run');
    if (runEl) runEl.classList.add('active-state');
  }
  if (e.code === 'Digit1' && typeof selectGunSlot === 'function') selectGunSlot(1);
  if (e.code === 'Digit2' && typeof selectGunSlot === 'function') selectGunSlot(2);
  if (e.code === 'KeyQ' && typeof cycleActiveSlotGun === 'function') cycleActiveSlotGun();
  if (e.code === 'KeyG' && typeof deployPlayerGlooWall === 'function') deployPlayerGlooWall();
  if (e.code === 'KeyR' && typeof reloadGun === 'function') reloadGun();
  if (e.code === 'KeyH' && typeof useMedkit === 'function') useMedkit();
  if (e.code === 'Space') performJump();
});

window.addEventListener('keyup', function(e) {
  keys[e.code] = false;
  if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') {
    isRunning = false;
    const runEl = document.getElementById('btn-run');
    if (runEl) runEl.classList.remove('active-state');
  }
});

window.addEventListener('mousemove', function(e) {
  if (document.pointerLockElement === document.body) {
    yaw -= e.movementX * 0.003;
    pitch = Math.max(-0.4, Math.min(0.85, pitch + e.movementY * 0.003));
  }
});

window.addEventListener('mousedown', function(e) {
  const overlay = document.getElementById('overlay');
  if (overlay && overlay.style.display !== 'none') return;
  if (e.button === 0 && e.target.tagName === 'CANVAS') {
    if (document.pointerLockElement !== document.body && document.body.requestPointerLock) {
      try { document.body.requestPointerLock(); } catch (err) {}
    }
    if (typeof fireBullet === 'function' && typeof player !== 'undefined') {
      fireBullet(player, true);
    }
  }
  if (e.button === 2) toggleScope();
});

window.addEventListener('contextmenu', function(e) {
  e.preventDefault();
});

function toggleScope() {
  isScoped = !isScoped;
  camera.fov = isScoped ? 32 : (isRunning ? 73 : 65);
  camera.updateProjectionMatrix();
}

// Joystick
const joyZone = document.getElementById('joy-zone');
const joyStick = document.getElementById('joy-stick');
let joyTouchId = null;

function setStickOffset(nx, ny) {
  if (!joyZone || !joyStick) return;
  const maxR = Math.max(16, joyZone.clientWidth * 0.32);
  const px = nx * maxR;
  const py = ny * maxR;
  joyStick.style.transform = `translate(calc(-50% + ${px}px), calc(-50% + ${py}px))`;
}

function updateJoystick(touch) {
  if (!joyZone) return;
  const rect = joyZone.getBoundingClientRect();
  const cx = rect.left + rect.width / 2;
  const cy = rect.top + rect.height / 2;
  const dx = touch.clientX - cx;
  const dy = touch.clientY - cy;
  const maxDist = Math.max(18, rect.width * 0.35);
  const dist = Math.min(maxDist, Math.hypot(dx, dy));
  const angle = Math.atan2(dy, dx);
  const nx = dist === 0 ? 0 : (Math.cos(angle) * dist) / maxDist;
  const ny = dist === 0 ? 0 : (Math.sin(angle) * dist) / maxDist;
  setStickOffset(nx, ny);
  joyX = nx;
  joyZ = ny;
}

if (joyZone) {
  joyZone.addEventListener('touchstart', function(e) {
    if (hudEditMode) return;
    e.preventDefault();
    e.stopPropagation();
    const t = e.changedTouches[0];
    joyTouchId = t.identifier;
    updateJoystick(t);
  }, { passive: false });

  joyZone.addEventListener('touchmove', function(e) {
    if (hudEditMode) return;
    e.preventDefault();
    e.stopPropagation();
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === joyTouchId) {
        updateJoystick(e.changedTouches[i]);
        break;
      }
    }
  }, { passive: false });

  function resetJoystick(e) {
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === joyTouchId) {
        joyTouchId = null;
        setStickOffset(0, 0);
        joyX = 0;
        joyZ = 0;
        break;
      }
    }
  }

  joyZone.addEventListener('touchend', resetJoystick);
  joyZone.addEventListener('touchcancel', resetJoystick);
}

// Camera Drag on Canvas
let camTouchId = null, lastTouchX = 0, lastTouchY = 0;

renderer.domElement.addEventListener('touchstart', function(e) {
  if (camTouchId === null) {
    const t = e.changedTouches[0];
    camTouchId = t.identifier;
    lastTouchX = t.clientX;
    lastTouchY = t.clientY;
  }
}, { passive: true });

renderer.domElement.addEventListener('touchmove', function(e) {
  for (let i = 0; i < e.changedTouches.length; i++) {
    const t = e.changedTouches[i];
    if (t.identifier === camTouchId) {
      yaw -= (t.clientX - lastTouchX) * 0.006;
      pitch = Math.max(-0.4, Math.min(0.85, pitch + (t.clientY - lastTouchY) * 0.005));
      lastTouchX = t.clientX;
      lastTouchY = t.clientY;
      break;
    }
  }
}, { passive: true });

function resetCamTouch(e) {
  for (let i = 0; i < e.changedTouches.length; i++) {
    if (e.changedTouches[i].identifier === camTouchId) {
      camTouchId = null;
      break;
    }
  }
}

renderer.domElement.addEventListener('touchend', resetCamTouch);
renderer.domElement.addEventListener('touchcancel', resetCamTouch);

// Action Buttons
const btnFire = document.getElementById('btn-fire');
const btnJump = document.getElementById('btn-jump');
const btnScope = document.getElementById('btn-scope');
const btnRun = document.getElementById('btn-run');
const btnGlue = document.getElementById('btn-glue');
const btnGun1 = document.getElementById('btn-gun1');
const btnGun2 = document.getElementById('btn-gun2');

function triggerFire(e) {
  if (hudEditMode) return;
  if (e) { e.preventDefault(); e.stopPropagation(); }
  if (typeof fireBullet === 'function' && typeof player !== 'undefined') {
    fireBullet(player, true);
  }
}

function triggerJump(e) {
  if (hudEditMode) return;
  if (e) { e.preventDefault(); e.stopPropagation(); }
  performJump();
}

function triggerScope(e) {
  if (hudEditMode) return;
  if (e) { e.preventDefault(); e.stopPropagation(); }
  toggleScope();
}

function triggerGlue(e) {
  if (hudEditMode) return;
  if (e) { e.preventDefault(); e.stopPropagation(); }
  if (typeof deployPlayerGlooWall === 'function') deployPlayerGlooWall();
}

function startRun(e) {
  if (hudEditMode) return;
  if (e) { e.preventDefault(); e.stopPropagation(); }
  isRunning = true;
  if (btnRun) btnRun.classList.add('active-state');
  if (!isScoped) { camera.fov = 73; camera.updateProjectionMatrix(); }
}

function stopRun(e) {
  if (e) { e.stopPropagation(); }
  isRunning = false;
  if (btnRun) btnRun.classList.remove('active-state');
  if (!isScoped) { camera.fov = 65; camera.updateProjectionMatrix(); }
}

function triggerGun1(e) {
  if (hudEditMode) return;
  if (e) { e.preventDefault(); e.stopPropagation(); }
  if (typeof selectGunSlot === 'function') {
    if (typeof activeSlot !== 'undefined' && activeSlot === 1 && typeof cycleActiveSlotGun === 'function') {
      cycleActiveSlotGun();
    } else {
      selectGunSlot(1);
    }
  }
}

function triggerGun2(e) {
  if (hudEditMode) return;
  if (e) { e.preventDefault(); e.stopPropagation(); }
  if (typeof selectGunSlot === 'function') {
    if (typeof activeSlot !== 'undefined' && activeSlot === 2 && typeof cycleActiveSlotGun === 'function') {
      cycleActiveSlotGun();
    } else {
      selectGunSlot(2);
    }
  }
}

if (btnFire) {
  btnFire.addEventListener('touchstart', triggerFire, { passive: false });
  btnFire.addEventListener('mousedown', triggerFire);
}
if (btnJump) {
  btnJump.addEventListener('touchstart', triggerJump, { passive: false });
  btnJump.addEventListener('mousedown', triggerJump);
}
if (btnScope) {
  btnScope.addEventListener('touchstart', triggerScope, { passive: false });
  btnScope.addEventListener('mousedown', triggerScope);
}
if (btnGlue) {
  btnGlue.addEventListener('touchstart', triggerGlue, { passive: false });
  btnGlue.addEventListener('mousedown', triggerGlue);
}
if (btnRun) {
  btnRun.addEventListener('touchstart', startRun, { passive: false });
  btnRun.addEventListener('touchend', stopRun);
  btnRun.addEventListener('touchcancel', stopRun);
  btnRun.addEventListener('mousedown', startRun);
  window.addEventListener('mouseup', function() { if (isRunning && !keys['ShiftLeft']) stopRun(); });
}
if (btnGun1) {
  btnGun1.addEventListener('touchstart', triggerGun1, { passive: false });
  btnGun1.addEventListener('mousedown', triggerGun1);
}
if (btnGun2) {
  btnGun2.addEventListener('touchstart', triggerGun2, { passive: false });
  btnGun2.addEventListener('mousedown', triggerGun2);
}

// FREE FIRE STYLE DIRECT DRAG + SIZE HUD
const hudBar = document.getElementById('hud-bar');
const hudToggleBtn = document.getElementById('btn-hud-toggle');
const hudTip = document.getElementById('hud-tip');
const HUD_STORAGE_KEY = 'vsf_ff_hud_v8';

const hudIds = ['btn-fire', 'btn-jump', 'btn-scope', 'btn-run', 'btn-glue', 'btn-gun1', 'btn-gun2', 'joy-zone'];
const defaultHudConfig = {
  'btn-fire': { x: null, y: null, size: 68 },
  'btn-jump': { x: null, y: null, size: 50 },
  'btn-scope': { x: null, y: null, size: 50 },
  'btn-run': { x: null, y: null, size: 50 },
  'btn-glue': { x: null, y: null, size: 50 },
  'btn-gun1': { x: null, y: null, size: 96 },
  'btn-gun2': { x: null, y: null, size: 96 },
  'joy-zone': { x: null, y: null, size: 104 }
};

let hudConfig = JSON.parse(JSON.stringify(defaultHudConfig));
try {
  const saved = localStorage.getItem(HUD_STORAGE_KEY);
  if (saved) hudConfig = Object.assign(hudConfig, JSON.parse(saved));
} catch (err) {}

let selectedHudId = 'btn-fire';

function saveHudConfig() {
  try { localStorage.setItem(HUD_STORAGE_KEY, JSON.stringify(hudConfig)); } catch (err) {}
}

function isGunPair(id) {
  return id === 'btn-gun1' || id === 'btn-gun2';
}

function syncConnectedGunPair() {
  ensureCoords('btn-gun1');
  ensureCoords('btn-gun2');
  const w1 = hudConfig['btn-gun1'].size || 96;
  const w2 = hudConfig['btn-gun2'].size || 96;
  hudConfig['btn-gun2'].x = Math.min(window.innerWidth - w2 - 6, hudConfig['btn-gun1'].x + w1);
  hudConfig['btn-gun2'].y = hudConfig['btn-gun1'].y;
}

function updateSelectionVisual() {
  hudIds.forEach(function(id) {
    const el = document.getElementById(id);
    if (!el) return;
    const pairHighlight = hudEditMode && isGunPair(selectedHudId) && isGunPair(id);
    el.classList.toggle('hud-editable', hudEditMode);
    el.classList.toggle('hud-selected', hudEditMode && (selectedHudId === id || pairHighlight));
  });
  const labelMap = {
    'btn-fire': 'FIRE',
    'btn-jump': 'JUMP',
    'btn-scope': 'SCOPE',
    'btn-run': 'RUN',
    'btn-glue': 'GLOO WALL',
    'btn-gun1': 'GUN SLOTS (1 & 2)',
    'btn-gun2': 'GUN SLOTS (1 & 2)',
    'joy-zone': 'JOYSTICK'
  };
  if (hudTip) hudTip.innerText = (labelMap[selectedHudId] || 'BTN') + ' खींचें / साइज';
}

function applyHudConfig() {
  hudIds.forEach(function(id) {
    const el = document.getElementById(id);
    const cfg = hudConfig[id];
    if (!el || !cfg) return;
    if (cfg.size) {
      if (isGunPair(id)) {
        el.style.width = cfg.size + 'px';
        el.style.height = Math.round(cfg.size * 0.48) + 'px';
      } else {
        el.style.width = cfg.size + 'px';
        el.style.height = cfg.size + 'px';
        if (id === 'btn-fire') el.style.fontSize = Math.max(10, Math.round(cfg.size * 0.19)) + 'px';
        else if (id !== 'joy-zone') el.style.fontSize = Math.max(9, Math.round(cfg.size * 0.2)) + 'px';
      }
    }
    if (cfg.x !== null && cfg.y !== null) {
      el.style.left = cfg.x + 'px';
      el.style.top = cfg.y + 'px';
      el.style.right = 'auto';
      el.style.bottom = 'auto';
    }
  });
  updateSelectionVisual();
}

function ensureCoords(id) {
  const el = document.getElementById(id);
  if (!el) return;
  const rect = el.getBoundingClientRect();
  if (hudConfig[id].x === null || hudConfig[id].y === null) {
    hudConfig[id].x = Math.round(rect.left);
    hudConfig[id].y = Math.round(rect.top);
  }
  if (!hudConfig[id].size) {
    hudConfig[id].size = Math.round(rect.width);
  }
}

function resizeSelected(delta) {
  const id = selectedHudId;
  if (isGunPair(id)) {
    ensureCoords('btn-gun1');
    ensureCoords('btn-gun2');
    const nextSize = Math.max(74, Math.min(136, (hudConfig['btn-gun1'].size || 96) + delta));
    hudConfig['btn-gun1'].size = nextSize;
    hudConfig['btn-gun2'].size = nextSize;
    hudConfig['btn-gun1'].x = Math.max(6, Math.min(window.innerWidth - nextSize * 2 - 6, hudConfig['btn-gun1'].x));
    syncConnectedGunPair();
  } else {
    ensureCoords(id);
    const minS = id === 'joy-zone' ? 75 : 36;
    const maxS = id === 'joy-zone' ? 165 : 110;
    hudConfig[id].size = Math.max(minS, Math.min(maxS, (hudConfig[id].size || 50) + delta));
  }
  applyHudConfig();
  saveHudConfig();
}

let draggingId = null, dragTouchId = null, dragOffsetX = 0, dragOffsetY = 0;

hudIds.forEach(function(id) {
  const el = document.getElementById(id);
  if (!el) return;

  el.addEventListener('touchstart', function(e) {
    if (!hudEditMode) return;
    e.preventDefault();
    e.stopPropagation();
    selectedHudId = id;
    if (isGunPair(id)) syncConnectedGunPair();
    else ensureCoords(id);
    updateSelectionVisual();

    const anchorId = isGunPair(id) ? 'btn-gun1' : id;
    const t = e.changedTouches[0];
    draggingId = id;
    dragTouchId = t.identifier;
    dragOffsetX = t.clientX - hudConfig[anchorId].x;
    dragOffsetY = t.clientY - hudConfig[anchorId].y;
  }, { passive: false });

  el.addEventListener('mousedown', function(e) {
    if (!hudEditMode) return;
    e.preventDefault();
    e.stopPropagation();
    selectedHudId = id;
    if (isGunPair(id)) syncConnectedGunPair();
    else ensureCoords(id);
    updateSelectionVisual();

    const anchorId = isGunPair(id) ? 'btn-gun1' : id;
    draggingId = id;
    dragTouchId = 'mouse';
    dragOffsetX = e.clientX - hudConfig[anchorId].x;
    dragOffsetY = e.clientY - hudConfig[anchorId].y;
  });
});

function moveDraggedTarget(clientX, clientY) {
  if (!draggingId) return;
  if (isGunPair(draggingId)) {
    const w1 = hudConfig['btn-gun1'].size || 96;
    const w2 = hudConfig['btn-gun2'].size || 96;
    const h = Math.round((hudConfig['btn-gun1'].size || 96) * 0.48);
    hudConfig['btn-gun1'].x = Math.max(6, Math.min(window.innerWidth - (w1 + w2) - 6, clientX - dragOffsetX));
    hudConfig['btn-gun1'].y = Math.max(68, Math.min(window.innerHeight - h - 6, clientY - dragOffsetY));
    syncConnectedGunPair();
  } else {
    const size = hudConfig[draggingId].size || 50;
    hudConfig[draggingId].x = Math.max(6, Math.min(window.innerWidth - size - 6, clientX - dragOffsetX));
    hudConfig[draggingId].y = Math.max(68, Math.min(window.innerHeight - size - 6, clientY - dragOffsetY));
  }
  applyHudConfig();
}

window.addEventListener('touchmove', function(e) {
  if (!hudEditMode || !draggingId) return;
  for (let i = 0; i < e.changedTouches.length; i++) {
    const t = e.changedTouches[i];
    if (t.identifier === dragTouchId) {
      e.preventDefault();
      moveDraggedTarget(t.clientX, t.clientY);
      break;
    }
  }
}, { passive: false });

window.addEventListener('mousemove', function(e) {
  if (!hudEditMode || !draggingId || dragTouchId !== 'mouse') return;
  moveDraggedTarget(e.clientX, e.clientY);
});

window.addEventListener('touchend', function(e) {
  if (!draggingId) return;
  for (let i = 0; i < e.changedTouches.length; i++) {
    if (e.changedTouches[i].identifier === dragTouchId) {
      draggingId = null;
      dragTouchId = null;
      saveHudConfig();
      break;
    }
  }
});

window.addEventListener('mouseup', function() {
  if (dragTouchId === 'mouse') {
    draggingId = null;
    dragTouchId = null;
    saveHudConfig();
  }
});

if (hudToggleBtn) {
  hudToggleBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    hudEditMode = !hudEditMode;
    if (hudBar) hudBar.classList.toggle('open', hudEditMode);
    updateSelectionVisual();
  });
}

const sizeUpBtn = document.getElementById('hud-size-up');
if (sizeUpBtn) sizeUpBtn.addEventListener('click', function(e) { e.stopPropagation(); resizeSelected(6); });

const sizeDownBtn = document.getElementById('hud-size-down');
if (sizeDownBtn) sizeDownBtn.addEventListener('click', function(e) { e.stopPropagation(); resizeSelected(-6); });

const resetHudBtn = document.getElementById('hud-reset');
if (resetHudBtn) {
  resetHudBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    hudConfig = JSON.parse(JSON.stringify(defaultHudConfig));
    try { localStorage.removeItem(HUD_STORAGE_KEY); } catch (err) {}
    hudIds.forEach(function(id) {
      const el = document.getElementById(id);
      if (el) el.removeAttribute('style');
    });
    applyHudConfig();
  });
}

const closeHudBtn = document.getElementById('hud-close');
if (closeHudBtn) {
  closeHudBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    hudEditMode = false;
    draggingId = null;
    dragTouchId = null;
    if (hudBar) hudBar.classList.remove('open');
    updateSelectionVisual();
  });
}

applyHudConfig();
