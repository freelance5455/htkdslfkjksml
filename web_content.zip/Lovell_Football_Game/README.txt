LOVELL FOOTBALL — 3D-STYLE STARTER

HOW TO PLAY
1. Extract the ZIP file.
2. Open index.html in Chrome on your Android phone or a desktop browser.
3. Tap KICK OFF.
4. Use the arrow buttons to move your blue player.
5. Get near the ball and tap PASS or SHOOT.
6. Score in the goal on the right side. Restart Match resets the game.

ABOUT
This is a lightweight 2D canvas prototype with a 3D-style presentation. It is not a full 3D eFootball clone and is not an APK. It works offline in a modern browser and uses original placeholder graphics. To build a full 3D Android game, a game engine such as Godot or Unity would be the next step.
