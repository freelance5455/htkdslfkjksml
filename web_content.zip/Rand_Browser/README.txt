RAND BROWSER — Web home page starter

Files:
- index.html: responsive browser-style home page with branded RB logo, search, quick links and a basic tab strip.
- manifest.json: PWA metadata.

How to use:
1. Extract the ZIP.
2. Open index.html in a browser, or upload the files to a web host.
3. For an Android APK, this web project must be wrapped in an Android WebView project and built with Android Studio.

Important limitation:
This is a browser-style start page, not a full Chromium browser engine. The quick links open sites in new browser tabs. A true multi-tab browser with in-app web navigation, downloads, bookmarks, permissions and APK packaging requires native Android code (WebView/Chromium) and an Android build environment.
