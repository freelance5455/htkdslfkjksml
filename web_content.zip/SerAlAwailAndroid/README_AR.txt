مشروع بداية لتجهيز تطبيق أندرويد «سر الأوائل»

مهم: هذا ليس ملف APK جاهزًا للتثبيت. هذا مشروع مصدر يحتوي على نسخة HTML داخل www، ويحتاج إلى بناء APK على كمبيوتر باستخدام Node.js وAndroid Studio.

على كمبيوتر Windows:
1) ثبّتي Node.js إصدار LTS وAndroid Studio.
2) فكّي ضغط هذا الملف.
3) افتحي Terminal أو PowerShell داخل مجلد SerAlAwailAndroid.
4) شغّلي الأوامر التالية بالترتيب:
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
5) في Android Studio، انتظري انتهاء Gradle Sync.
6) من القائمة Build اختاري Build Bundle(s) / APK(s) ثم Build APK(s).
7) بعد نجاح البناء، ستجدين APK داخل android/app/build/outputs/apk/debug/ غالبًا باسم app-debug.apk.
8) اختبري APK على هاتفك. قبل إرساله للطلاب، اختبري جميع الصفحات والروابط على هاتف فعلي.

للتحديث لاحقًا بعد تعديل www/index.html:
   npx cap sync android
ثم أعيدي بناء APK.

ملاحظات:
- هذا المشروع يعمل كتطبيق أندرويد مستقل بواجهة WebView داخل التطبيق؛ لا يحتاج الطالب لفتح Chrome بنفسه.
- التطبيق الحالي تجريبي. الأقسام موجودة لكن محتوى الدروس الفعلي، إدارة المحتوى عبر الإنترنت، وحفظ البيانات المشترك تحتاج إلى تطوير إضافي.
- لا ترفعي ملفات APK إلى رابط عام إلا بعد اختبارها. استخدمي استضافة موثوقة وشاركي رابط HTTPS، أو Google Play عند استيفاء شروطه.
