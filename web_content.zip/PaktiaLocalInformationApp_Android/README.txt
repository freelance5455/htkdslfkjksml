Paktia Local Information App - Android project
Open this folder in Android Studio, then choose Build > Build APK(s).
The generated APK will be in app/build/outputs/apk/debug/.
