BUSINESS MANAGER PRO — OFFLINE HTML APP

INSTALL / OPEN
1. Extract the ZIP on your phone or computer.
2. Open index.html in a modern browser (Chrome recommended).
3. No internet or external libraries are required for normal use.

FEATURES
- Income, expenses and cash-flow overview
- Daily and yearly charts
- Product inventory with low-stock alerts
- Sales that automatically deduct stock and add income
- Printable invoices / receipts
- Customer and supplier records
- VAT calculator (default rate 15%, editable)
- Simple user-entered estimated tax calculator
- Business debts and payment tracking
- Multiple local business profiles
- PIN lock, light/dark theme
- Local browser storage and rolling local backup
- Export and restore backup JSON
- Monthly financial review and browser print-to-PDF

IMPORTANT LIMITATIONS
- Data is stored in this browser on this device. Browser storage is not encrypted. The PIN is a basic privacy barrier, not strong security.
- Export backups regularly and keep them somewhere safe. Clearing browser data can erase records.
- The app cannot silently create a PDF while completely closed. Open Reports and use “Save / print PDF”; select “Save as PDF”.
- Barcode scanning depends on browser support for BarcodeDetector, camera permissions and a secure context. If unavailable, enter barcode numbers manually.
- The tax calculator is only a simple estimate. It does not calculate official tax liability or replace professional tax advice.
- VAT rate is editable; confirm the correct rate and VAT treatment for your business.
