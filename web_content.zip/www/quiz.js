import { QUIZ_BANK, QUIZ_START_DATE } from "./quiz-bank.js";
import { database } from "./firebase.js";
import { ref, get, set, update } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-database.js";

const $=id=>document.getElementById(id);
const PLAYER_KEY="df_quiz_player_v1";
let player=null,quiz=null,quizDay=null,timer=null,quizPublishAt=0;
const bn=n=>Number(n).toLocaleString("bn-BD");
function pad(n){return String(n).padStart(2,"0");}
function dateKey(d=new Date()){return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;}
function savePlayer(){localStorage.setItem(PLAYER_KEY,JSON.stringify(player));}
function loadPlayer(){try{const m=JSON.parse(localStorage.getItem("df_global_member")||"null");if(m&&m.uid&&m.name)return {id:m.uid,name:m.name,createdAt:Date.now(),lastSeenAt:Date.now(),phone:m.phone};return null}catch{return null}}
function renderPlayer(){if(player){$("loginView").classList.add("hidden");$("quizView").classList.remove("hidden");$("hello").textContent=`আসসালামু আলাইকুম, ${player.name} 🌿`;}}
async function registerPlayer(name){const m=JSON.parse(localStorage.getItem("df_global_member")||"null");if(m?.uid){player={id:m.uid,name:m.name||name,phone:m.phone,createdAt:Date.now(),lastSeenAt:Date.now()};}else{const id=crypto.randomUUID?crypto.randomUUID():"p_"+Date.now()+Math.random().toString(36).slice(2);player={id,name,createdAt:Date.now(),lastSeenAt:Date.now()};}savePlayer();try{await set(ref(database,"quizUsers/"+player.id),player);}catch(e){console.warn("Quiz player profile could not be saved",e);}}
function showEmpty(message="আজকের কুইজ এখনো প্রকাশিত হয়নি।"){$("question").textContent=message;$("options").innerHTML="";$("success").classList.add("hidden");$("already").classList.add("hidden");}
async function loadQuiz(){
  quizDay=dateKey(new Date());
  $("quizDate").textContent=new Date(quizDay+"T12:00:00").toLocaleDateString("bn-BD",{day:"numeric",month:"long",year:"numeric"});
  try{
    const snap=await get(ref(database,"quizzes/"+quizDay));
    if(!snap.exists()){const start=new Date(QUIZ_START_DATE+"T00:00:00"),current=new Date(quizDay+"T00:00:00"),day=Math.floor((current-start)/86400000)+1;if(day>=1&&day<=QUIZ_BANK.length){const q=QUIZ_BANK[day-1];quiz={...q,publishAt:new Date(quizDay+"T08:00:00").getTime(),publishTime:"08:00",source:"built-in-100-day-bank"};quizPublishAt=Number(quiz.publishAt);if(quizPublishAt>Date.now()){quiz=null;showEmpty("আজকের কুইজ নির্ধারিত সময়ে প্রকাশ হবে।");startCountdown(quizPublishAt);return;}}else{quiz=null;quizPublishAt=0;showEmpty("১০০ দিনের কুইজ সিরিজ সম্পন্ন হয়েছে। নতুন সিরিজের জন্য অপেক্ষা করুন।");startCountdown();return;}}else{quiz=snap.val()||{};}
    const fallbackTime=quiz.publishTime||"08:00";
    quizPublishAt=Number(quiz.publishAt||new Date(quizDay+"T"+fallbackTime+":00").getTime());
    if(quizPublishAt>Date.now()){quiz=null;showEmpty("আজকের কুইজ নির্ধারিত সময়ে প্রকাশ হবে।");startCountdown(quizPublishAt);return;}
  }catch(e){quiz=null;quizPublishAt=0;showEmpty("কুইজ লোড করা যায়নি। কিছুক্ষণ পরে আবার চেষ্টা করুন।");console.warn(e);return;}
  renderQuiz();startCountdown();
}
function renderQuiz(){
  const q=$("question"),opts=$("options"),success=$("success"),already=$("already");success.classList.add("hidden");already.classList.add("hidden");opts.innerHTML="";$("quizView").dataset.answered="false";
  if(!quiz||!quiz.question||!Array.isArray(quiz.options)||quiz.options.length<4){showEmpty("আজকের কুইজটি এখনো প্রস্তুত নয়।");return;}
  q.textContent=(quiz.category?"["+quiz.category+"] ":"")+quiz.question;
  const labels=["A","B","C","D"];
  quiz.options.slice(0,4).forEach((text,i)=>{const b=document.createElement("button");b.type="button";b.className="option";b.innerHTML=`<span class="radio" aria-hidden="true"></span><span class="option-letter">${labels[i]}.</span><span class="option-label"></span>`;b.querySelector(".option-label").textContent=text||"";b.addEventListener("click",()=>submitAnswer(i,text,b));opts.appendChild(b);});
  checkAnswered();
}
async function checkAnswered(){if(!player||!quizDay)return;try{const s=await get(ref(database,`quizAnswers/${quizDay}/${player.id}`));if(s.exists())showAnswered(s.val()||{});}catch(e){console.warn(e)}}
function correctIndex(){const n=Number(quiz?.answerIndex);if(Number.isInteger(n)&&n>=0&&n<4)return n;const raw=String(quiz?.correctAnswer??quiz?.answer??"A").trim();const letter=["A","B","C","D"].indexOf(raw.toUpperCase());if(letter>=0)return letter;const byText=(quiz?.options||[]).findIndex(x=>String(x).trim()===raw);return byText>=0?byText:0;}
function renderFeedback(userIndex){
  const ci=correctIndex(),opts=document.querySelectorAll(".option");
  opts.forEach((el,i)=>{el.disabled=true;el.classList.add("disabled");if(i===ci)el.classList.add("answer-correct");if(i===userIndex&&i!==ci)el.classList.add("answer-wrong");if(i===userIndex)el.classList.add("selected");});
  const old=document.querySelector(".quiz-result");if(old)old.remove();
  const result=document.createElement("section");result.className="quiz-result "+(userIndex===ci?"is-correct":"is-wrong");result.setAttribute("role","status");result.setAttribute("aria-live","polite");
  const heading=document.createElement("h3");heading.textContent=userIndex===ci?"✅ সঠিক উত্তর!":"❌ ভুল উত্তর!";result.appendChild(heading);
  const yours=document.createElement("p");yours.className="result-user-answer";const yb=document.createElement("strong");yb.textContent="আপনার উত্তর: ";yours.append(yb,document.createTextNode(String(quiz.options?.[userIndex]??"উত্তর পাওয়া যায়নি")));result.appendChild(yours);
  if(userIndex!==ci){const correct=document.createElement("p");correct.className="result-correct-answer";const cb=document.createElement("strong");cb.textContent="সঠিক উত্তর: ";correct.append(cb,document.createTextNode(String(quiz.options?.[ci]??"উত্তর পাওয়া যায়নি")));result.appendChild(correct);}
  if(quiz.explanation){const exp=document.createElement("p");exp.className="result-explanation";exp.textContent="ব্যাখ্যা: "+String(quiz.explanation);result.appendChild(exp);}
  document.querySelector(".question-card")?.appendChild(result);$("success").querySelector("h2").textContent=userIndex===ci?"অভিনন্দন! উত্তর সঠিক হয়েছে।":"আপনি কুইজে অংশ নিয়েছেন।";$("success").querySelector("p").textContent=userIndex===ci?"আপনার উত্তর সঠিক হয়েছে। প্রতিদিন নতুন কুইজে অংশ নিন।":"আপনার উত্তর সংরক্ষণ করা হয়েছে। উপরের সঠিক উত্তরটি দেখে শিখে নিন।";$("success").classList.remove("hidden");$("already").classList.remove("hidden");$("quizView").dataset.answered="true";
}
function showAnswered(answer={}){renderFeedback(Number.isInteger(Number(answer.optionIndex))?Number(answer.optionIndex):-1);}
async function submitAnswer(index,text,button){if(!player||!quiz||!quizDay||button.disabled)return;document.querySelectorAll(".option").forEach(x=>x.disabled=true);
  const answer={playerId:player.id,name:player.name,quizDate:quizDay,question:quiz.question,optionIndex:index,optionLetter:["A","B","C","D"][index],answer:String(text||""),submittedAt:Date.now()};
  try{await set(ref(database,`quizAnswers/${quizDay}/${player.id}`),answer);await update(ref(database,"quizUsers/"+player.id),{lastSeenAt:Date.now()});renderFeedback(index);window.scrollTo({top:document.querySelector(".quiz-result").getBoundingClientRect().top+window.scrollY-30,behavior:"smooth"});}
  catch(e){document.querySelectorAll(".option").forEach(x=>x.disabled=false);button.classList.remove("selected");alert("উত্তর সংরক্ষণ করা যায়নি। ইন্টারনেট সংযোগ পরীক্ষা করে আবার চেষ্টা করুন।");console.error(e);}
}
function nextDayTarget(){const d=new Date();d.setDate(d.getDate()+1);d.setHours(0,0,0,0);return d;}
function startCountdown(targetOverride=0){clearInterval(timer);const el=$("countdown");const tick=()=>{const n=new Date();let target=targetOverride||nextDayTarget();if(quizPublishAt&&quizPublishAt>n.getTime())target=new Date(quizPublishAt);const ms=Math.max(0,target.getTime()-n.getTime()),sec=Math.floor(ms/1000),h=Math.floor(sec/3600),m=Math.floor((sec%3600)/60),s=sec%60;el.textContent=`⏳ ${targetOverride?"আজকের কুইজ প্রকাশ হবে":"পরবর্তী কুইজের সময়"} ${bn(h)} ঘণ্টা ${bn(m)} মিনিট ${bn(s)} সেকেন্ড পরে`;if(dateKey(n)!==quizDay){loadQuiz();}else if(!quiz && targetOverride && Date.now()>=target.getTime()){loadQuiz();}};tick();timer=setInterval(tick,1000);}

(async()=>{player=loadPlayer();if(player){player.lastSeenAt=Date.now();savePlayer();renderPlayer();try{await update(ref(database,"quizUsers/"+player.id),{lastSeenAt:player.lastSeenAt,name:player.name});}catch{}}else { location.replace("index.html?authRequired=1&returnTo=quiz.html"); return; }if(player)await loadQuiz();window.addEventListener("df-member-login",async e=>{const m=e.detail;if(!m?.uid)return;player={id:m.uid,name:m.name,phone:m.phone,createdAt:Date.now(),lastSeenAt:Date.now()};savePlayer();try{await set(ref(database,"quizUsers/"+player.id),player);}catch{}renderPlayer();await loadQuiz();});})();
