Bu papkaga three.min.js (r128) ni qo'ying (oflayn ishlashi uchun).
Yuklab olish: get-three.sh yoki get-three.bat (loyiha ildizida) ni ishga tushiring.
Fayl bo'lmasa, oyin internet orqali CDN dan yuklaydi va keyin kesh qiladi.
