/* ============================================================
   RadLedger — core (منطق خالص؛ بدون وابستگی به DOM)
   تقویم شمسی، قالب‌بندی، محاسبات حقوق و ساخت گزارش
   ============================================================ */
'use strict';

const FA = '۰۱۲۳۴۵۶۷۸۹', AR = '٠١٢٣٤٥٦٧٨٩', DAY_MS = 864e5;
const fa = (s) => String(s).replace(/\d/g, (d) => FA[d]);
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
const money = (n) => fa((Math.round(+n || 0) || 0).toLocaleString('en'));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
const pad = (n) => String(n).padStart(2, '0');
// تبدیل ارقام فارسی/عربی و جداکنندهها به عدد
const num = (s) => {
  const v = +String(s == null ? '' : s)
    .replace(/[۰-۹]/g, (d) => FA.indexOf(d))
    .replace(/[٠-٩]/g, (d) => AR.indexOf(d))
    .replace(/٫/g, '.')
    .replace(/[,٬،\s]/g, '');
  return isFinite(v) ? v : 0;
};
const dys = (n) => (Number.isInteger(n) ? fa(n) : fa(n.toFixed(1)));
const fv = (v, u) => (u == 'روز' ? dys(v) + ' روز' : money(v) + ' تومان');
const cv = (c) => (typeof c == 'number' ? (c === 0 ? '-' : Number.isInteger(c) ? money(c) : fa(c.toFixed(1))) : c);

const MN = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
const WD = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه'];
const WS = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];

/* ---------- تقویم ---------- */
const D = (i) => new Date(i + 'T12:00:00Z');
const iso = (d) => d.toISOString().slice(0, 10);
const addDays = (i, n) => iso(new Date(D(i).getTime() + n * DAY_MS));
const todayIso = () => { const n = new Date(); return iso(new Date(Date.UTC(n.getFullYear(), n.getMonth(), n.getDate()))); };
const ISO_RE = /^\d{4}-\d{2}-\d{2}$/;

function g2j(gy, gm, gd) {
  const gdm = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  let jy = gy <= 1600 ? 0 : 979;
  gy -= gy <= 1600 ? 621 : 1600;
  const g2 = gm > 2 ? gy + 1 : gy;
  let days = 365 * gy + ~~((g2 + 3) / 4) - ~~((g2 + 99) / 100) + ~~((g2 + 399) / 400) - 80 + gd + gdm[gm - 1];
  jy += 33 * ~~(days / 12053); days %= 12053;
  jy += 4 * ~~(days / 1461); days %= 1461;
  if (days > 365) { jy += ~~((days - 1) / 365); days = (days - 1) % 365; }
  const jm = days < 186 ? 1 + ~~(days / 31) : 7 + ~~((days - 186) / 30);
  const jd = 1 + (days < 186 ? days % 31 : (days - 186) % 30);
  return [jy, jm, jd];
}
// تبدیل دقیق و معکوس g2j (به‌جای حدس‌زدنِ تکراری در نسخهٔ قبل)
function j2g(jy, jm, jd) {
  jy += 1595;
  let days = -355668 + 365 * jy + ~~(jy / 33) * 8 + ~~(((jy % 33) + 3) / 4) + jd + (jm < 7 ? (jm - 1) * 31 : (jm - 7) * 30 + 186);
  let gy = 400 * ~~(days / 146097);
  days %= 146097;
  if (days > 36524) {
    gy += 100 * ~~(--days / 36524);
    days %= 36524;
    if (days >= 365) days++;
  }
  gy += 4 * ~~(days / 1461); days %= 1461;
  if (days > 365) { gy += ~~((days - 1) / 365); days = (days - 1) % 365; }
  let gd = days + 1;
  const sal = [0, 31, (gy % 4 == 0 && gy % 100 != 0) || gy % 400 == 0 ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  let gm;
  for (gm = 0; gm < 13; gm++) { if (gd <= sal[gm]) break; gd -= sal[gm]; }
  return [gy, gm, gd];
}
const J = (i) => { const d = D(i), r = g2j(d.getUTCFullYear(), d.getUTCMonth() + 1, d.getUTCDate()); return { y: r[0], m: r[1], d: r[2], w: (d.getUTCDay() + 1) % 7 }; };
const jIso = (y, m, d) => { const r = j2g(y, m, d); return r[0] + '-' + pad(r[1]) + '-' + pad(r[2]); };
const isLeapJ = (y) => { const r = j2g(y, 12, 30), b = g2j(r[0], r[1], r[2]); return b[0] == y && b[1] == 12 && b[2] == 30; };
const mLen = (y, m) => (m < 7 ? 31 : m < 12 ? 30 : isLeapJ(y) ? 30 : 29);
const validJ = (y, m, d) => y >= 1300 && y <= 1600 && m >= 1 && m <= 12 && d >= 1 && d <= mLen(y, m) && Number.isInteger(y) && Number.isInteger(m) && Number.isInteger(d);
const jd = (i) => { const j = J(i); return fa(j.y + '/' + pad(j.m) + '/' + pad(j.d)); };
const jfull = (i) => { const j = J(i); return WD[j.w] + ' ' + fa(j.d) + ' ' + MN[j.m - 1] + ' ' + fa(j.y); };

/* ---------- محاسبات حقوق ---------- */
const placeName = (db, id) => (db.places.find((p) => p.id == id) || {}).name || '-';
const workerName = (db, id) => (db.workers.find((w) => w.id == id) || {}).name || '؟';

// گزارش یک نیرو در بازهٔ [f, t] (تاریخ‌های میلادی ISO)
function workerReport(db, w, f, t) {
  const set = db.set, wage = w.wage || 0, hr = wage / (set.hpd > 0 ? set.hpd : 8);
  const rows = {}, inr = (x) => x.w == w.id && x.d >= f && x.d <= t;
  const row = (d) => rows[d] || (rows[d] = { d, pl: '-', st: '', ot: 0, late: 0, ld: 0, adv: 0, pay: 0, days: 0 });
  db.att.filter(inr).forEach((a) => {
    const r = row(a.d);
    r.pl = placeName(db, a.pl || w.pl);
    r.st = a.s == 1 ? 'حاضر' : a.s == 0.5 ? 'نیم‌روز' : 'غایب';
    r.ot = a.ot || 0;
    r.late = a.late || 0;
    r.ld = Math.round(Math.floor(r.late) * hr * (set.lf || 1));
    r.pay = Math.round(a.s * wage + r.ot * hr * (set.of || 1));
    r.days = a.s;
  });
  db.adv.filter(inr).forEach((a) => { row(a.d).adv += a.amt; });
  const rs = Object.values(rows).sort((a, b) => (a.d < b.d ? -1 : 1));
  const Q = (k) => rs.reduce((s, r) => s + (r[k] || 0), 0);
  const tr = db.trn.filter(inr).sort((a, b) => (a.d < b.d ? -1 : 1));
  const tt = tr.reduce((s, x) => s + x.amt, 0), gross = Q('pay'), ld = Q('ld'), adv = Q('adv'), net = gross + tt - ld - adv;
  return {
    wid: w.id, wname: w.name,
    name: w.name.replace(/[\[\]:*?\/\\]/g, '').slice(0, 24) || 'نیرو',
    title: w.name + (w.role ? ' — ' + w.role : ''),
    sub: ['دوره: ' + jd(f) + ' تا ' + jd(t), 'دستمزد روزانه: ' + money(wage) + ' تومان'],
    days: Q('days'), gross, tt, ld, adv, net, nt: tr.length,
    tables: [
      { h: ['تاریخ', 'روز', 'محل کار', 'وضعیت', 'اضافه‌کار (ساعت)', 'تاخیر (ساعت)', 'مساعده', 'کارکرد (تومان)'],
        r: rs.map((r) => [jd(r.d), WD[J(r.d).w], r.pl, r.st, r.ot, r.late, r.adv, r.pay]),
        f: [['جمع', '', '', '', Q('ot'), Q('late'), adv, gross]] },
      tr.length ? { t: 'کرایه ماشین (جداگانه)', h: ['تاریخ', 'روز', 'توضیحات', 'مبلغ'], r: tr.map((x) => [jd(x.d), WD[J(x.d).w], x.note || '', x.amt]), f: [['جمع کرایه', '', '', tt]] } : null,
    ].filter(Boolean),
    sum: [
      ['مجموع روز کارکرد', Q('days'), 'روز'],
      ['جمع دستمزد (با اضافه‌کار)', gross, 'تومان'],
      ['− کسر تاخیر (' + fa(Q('late')) + ' ساعت)', ld, 'تومان'],
      ['− مساعده', adv, 'تومان'],
      ...(tr.length ? [['مانده دستمزد (بدون کرایه)', gross - ld - adv, 'تومان'], ['کرایه ماشین — جداگانه (' + fa(tr.length) + ' مورد)', tt, 'تومان']] : []),
      [tr.length ? 'مبلغ کل قابل پرداخت (دستمزد + کرایه)' : 'مبلغ قابل پرداخت', net, 'تومان'],
    ],
  };
}

// محدودهٔ روزهای یک ماه شمسی با اصلاح ورودی نامعتبر
function monthRange(y, m, from, to) {
  const len = mLen(y, m), f0 = jIso(y, m, 1);
  const a = Math.min(Math.max(1, Math.floor(from) || 1), len);
  const b = Math.min(len, Math.max(a, Math.floor(to) || len));
  return { f: addDays(f0, a - 1), t: addDays(f0, b - 1), a, b, len };
}

// ساخت صفحات گزارش: [خلاصه؟, نیرو۱, نیرو۲, ...]
function buildReports(db, o) {
  const { f, t } = monthRange(o.y, o.m, o.from, o.to), per = 'دوره: ' + jd(f) + ' تا ' + jd(t);
  if (o.worker && o.worker != 'all') {
    const w = db.workers.find((x) => x.id == o.worker);
    return w ? [workerReport(db, w, f, t)] : [];
  }
  const hasRec = (w) => ['att', 'adv', 'trn'].some((k) => db[k].some((x) => x.w == w.id && x.d >= f && x.d <= t));
  const ws = db.workers.filter((w) => w.on !== 0 || hasRec(w));
  if (!ws.length) return [];
  const W = ws.map((w) => workerReport(db, w, f, t)), s = (k) => W.reduce((a, x) => a + x[k], 0);
  const ft = W.map((x, i) => [ws[i].name, ws[i].role || '', x.nt, x.tt]).filter((r) => r[3] > 0), fn = ft.reduce((a, r) => a + r[2], 0);
  const summary = {
    name: 'خلاصه', title: 'خلاصه پرداخت نیروها', sub: [per], isSummary: true,
    tables: [
      { h: ['نام', 'سمت', 'روز کارکرد', 'دستمزد', 'کرایه', 'کسر تاخیر', 'مساعده', 'قابل پرداخت'],
        r: W.map((x, i) => [ws[i].name, ws[i].role || '', x.days, x.gross, x.tt, x.ld, x.adv, x.net]),
        f: [['جمع', '', s('days'), s('gross'), s('tt'), s('ld'), s('adv'), s('net')]] },
      ft.length ? { t: 'کرایه ماشین — جداگانه برای هر نیرو', h: ['نام', 'سمت', 'تعداد', 'مبلغ کرایه'], r: ft, f: [['جمع', '', fn, s('tt')]] } : null,
    ].filter(Boolean),
    sum: [
      ['مجموع روز کارکرد همه نیروها', s('days'), 'روز'],
      ['جمع دستمزد همه نیروها', s('gross'), 'تومان'],
      ['− جمع کسر تاخیر', s('ld'), 'تومان'],
      ['− جمع مساعده', s('adv'), 'تومان'],
      ...(ft.length ? [['مانده دستمزد (بدون کرایه)', s('gross') - s('ld') - s('adv'), 'تومان'], ['جمع کرایه ماشین — جداگانه', s('tt'), 'تومان']] : []),
      [ft.length ? 'مجموع کل قابل پرداخت (دستمزد + کرایه)' : 'مجموع قابل پرداخت', s('net'), 'تومان'],
    ],
  };
  return [summary, ...W];
}

/* ---------- مدل دادهٔ پیش‌فرض و پاک‌سازی ---------- */
const DB_VERSION = 2;
const defaultDb = () => ({
  v: DB_VERSION, workers: [], places: [], att: [], adv: [], trn: [],
  set: { h1: 'نام شرکت / کارگاه', h2: 'گزارش کارکرد نیروها', h3: '', ft: '', hpd: 8, lf: 1, of: 1.4, col: '#4f46e5', lh: 1, lastBackup: 0 },
});
const sid = (x) => String(x == null ? '' : x).replace(/[^\w-]/g, '').slice(0, 40);
const fin = (x, d = 0) => (typeof x == 'number' && isFinite(x) ? x : d);
const str = (x, n) => String(x == null ? '' : x).replace(/[\u0000-\u001f]/g, ' ').slice(0, n);

// ورودی ناشناخته (localStorage / فایل بک‌آپ) را به مدل معتبر تبدیل می‌کند؛ در صورت نامعتبر بودن null
function normalizeDb(raw) {
  if (!raw || typeof raw != 'object' || !Array.isArray(raw.workers) || !Array.isArray(raw.att)) return null;
  const base = defaultDb(), out = defaultDb();
  const rs = raw.set && typeof raw.set == 'object' ? raw.set : {};
  const set = Object.assign({}, base.set, rs);
  const legacyLate = !rs.lh; // نسخه‌های قدیمی تاخیر را به دقیقه ذخیره می‌کردند
  ['tok', 'chat', 'auto'].forEach((k) => delete set[k]);
  out.set = {
    h1: str(set.h1, 80), h2: str(set.h2, 80), h3: str(set.h3, 120), ft: str(set.ft, 120),
    hpd: fin(+set.hpd, 8) > 0 ? +set.hpd : 8, lf: Math.max(0, fin(+set.lf, 1)), of: Math.max(0, fin(+set.of, 1.4)),
    col: /^#[0-9a-f]{6}$/i.test(set.col) ? set.col : '#4f46e5', lh: 1, lastBackup: fin(+set.lastBackup, 0),
  };
  const arr = (a) => (Array.isArray(a) ? a.filter((x) => x && typeof x == 'object') : []);
  out.places = arr(raw.places).map((p) => ({ id: sid(p.id) || uid(), name: str(p.name, 60) })).filter((p) => p.name);
  out.workers = arr(raw.workers).map((w) => ({ id: sid(w.id) || uid(), name: str(w.name, 60).trim(), role: str(w.role, 40), wage: Math.max(0, fin(+w.wage, 0)), pl: sid(w.pl), ph: str(w.ph, 24), on: w.on === 0 ? 0 : 1 })).filter((w) => w.name);
  const wid = new Set(out.workers.map((w) => w.id));
  const seen = new Set();
  out.att = arr(raw.att).map((a) => ({ id: sid(a.id) || uid(), w: sid(a.w), d: String(a.d), s: +a.s, pl: sid(a.pl), late: Math.max(0, legacyLate ? Math.floor(fin(+a.late, 0) / 60) : fin(+a.late, 0)), ot: Math.max(0, fin(+a.ot, 0)) }))
    .filter((a) => wid.has(a.w) && ISO_RE.test(a.d) && (a.s === 0 || a.s === 0.5 || a.s === 1))
    .filter((a) => { const k = a.w + '|' + a.d; if (seen.has(k)) return false; seen.add(k); return true; }) // هر نیرو در هر روز فقط یک رکورد
    .map((a) => { if (!a.late) delete a.late; if (!a.ot) delete a.ot; return a; });
  ['adv', 'trn'].forEach((k) => {
    out[k] = arr(raw[k]).map((x) => ({ id: sid(x.id) || uid(), w: sid(x.w), d: String(x.d), amt: fin(+x.amt, 0), note: str(x.note, 120) }))
      .filter((x) => wid.has(x.w) && ISO_RE.test(x.d) && x.amt > 0);
  });
  return out;
}

if (typeof module != 'undefined') module.exports = { fa, esc, money, num, uid, g2j, j2g, J, jIso, mLen, isLeapJ, validJ, jd, addDays, workerReport, buildReports, monthRange, normalizeDb, defaultDb, cv, fv, dys, MN, WD };
