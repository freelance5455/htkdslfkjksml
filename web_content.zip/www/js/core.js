/* Detox core: pure logic, no DOM. Works in browser (window.DetoxCore) and Node (tests). */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.DetoxCore = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var DAY = 864e5;
  var CHECKIN_HOUR = 8; // 8am: you confirm the previous day
  var MILESTONES = [1, 3, 7, 14, 21, 30, 45, 60, 90, 120, 180, 270, 365, 500, 730, 1000];
  var BONUS_AT = [7, 14, 30, 60, 90, 180, 365]; // streak days that drop a bonus handful
  var BONUS_BALLS = 10;
  var YELLOW_BALLS = 2;

  var HABITS = [
    { id: 'scroll', name: 'NoScroll', tag: 'Take your attention back', clean: 'scroll-free', last: 'scrolled' },
    { id: 'fap', name: 'NoFap', tag: 'Rebuild your focus and drive', clean: 'clean', last: 'relapsed' },
    { id: 'booze', name: 'NoBooze', tag: 'Wake up clear, every day', clean: 'sober', last: 'had a drink' },
    { id: 'drugs', name: 'Drug free', tag: 'One day at a time', clean: 'drug-free', last: 'used' }
  ];

  function habitById(id) {
    for (var i = 0; i < HABITS.length; i++) if (HABITS[i].id === id) return HABITS[i];
    return HABITS[0];
  }

  /* ---------- dates (local time, keys are YYYY-MM-DD) ---------- */
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function dayKey(ts) {
    var d = new Date(ts);
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  }
  function keyToDate(k) {
    var p = k.split('-');
    return new Date(+p[0], +p[1] - 1, +p[2]);
  }
  function addDays(k, n) {
    var d = keyToDate(k);
    d.setDate(d.getDate() + n);
    return dayKey(d.getTime());
  }
  function startOfDay(k) { return keyToDate(k).getTime(); }
  function endOfDay(k) { return startOfDay(addDays(k, 1)) - 1; }
  /* the moment day k can be confirmed: 8am the next morning */
  function checkinAt(k) {
    var d = keyToDate(addDays(k, 1));
    d.setHours(CHECKIN_HOUR, 0, 0, 0);
    return d.getTime();
  }
  function nextCheckin(now) {
    var d = new Date(now);
    d.setHours(CHECKIN_HOUR, 0, 0, 0);
    if (d.getTime() <= now) d.setDate(d.getDate() + 1);
    return d.getTime();
  }

  /* ---------- state ---------- */
  function uid() {
    return Math.random().toString(36).slice(2, 8) + Date.now().toString(36).slice(-5);
  }

  function create(habit, lastAt, now) {
    var s = {
      v: 1,
      habit: habit,
      createdAt: now,
      lastAt: lastAt,
      startDay: dayKey(lastAt),
      days: {},
      balls: { blue: 0, yellow: 0 },
      cracks: 0,
      best: 0,
      log: [],
      seen: { intro: false },
      settings: { lapseResets: true, reminders: true, sound: false },
      guardians: [null, null],
      server: '',
      acct: null,
      remoteSeen: []
    };
    backfill(s, now);
    return s;
  }

  /* trust the date the person typed: every full day since then counts as passed */
  function backfill(s, now) {
    var k = s.startDay, guard = 0;
    while (checkinAt(k) <= now && guard++ < 4000) {
      if (!s.days[k]) confirmDay(s, k, checkinAt(k), 'auto');
      k = addDays(k, 1);
    }
  }

  function pendingDays(s, now) {
    var out = [], k = s.startDay, guard = 0;
    while (checkinAt(k) <= now && guard++ < 4000) {
      if (!s.days[k]) out.push(k);
      k = addDays(k, 1);
    }
    return out;
  }

  function chainBefore(s, k) {
    var n = 0, p = addDays(k, -1);
    while (s.days[p] === 'b' && n < 4000) { n++; p = addDays(p, -1); }
    return n;
  }

  function ballsForBlue(streak) {
    return Math.min(3 + Math.floor((streak - 1) / 2), 12);
  }

  function pushLog(s, e) {
    e.id = uid();
    s.log.push(e);
    if (s.log.length > 300) s.log.splice(0, s.log.length - 300);
    return e;
  }

  /* BLUE: a day passed */
  function confirmDay(s, k, now, by) {
    var streak = chainBefore(s, k) + 1;
    var base = ballsForBlue(streak);
    var bonus = BONUS_AT.indexOf(streak) >= 0 ? BONUS_BALLS : 0;
    s.days[k] = 'b';
    s.balls.blue += base + bonus;
    s.cracks += 1;
    if (streak > s.best) s.best = streak;
    pushLog(s, { t: now, kind: 'b', day: k, add: base + bonus, bonus: bonus, streak: streak, by: by || 'me' });
    return { kind: 'b', day: k, blue: base + bonus, yellow: 0, removed: 0, bonus: bonus, streak: streak };
  }

  var RANK = { b: 1, y: 2, p: 3 };

  /* YELLOW lapse / PURPLE relapse. opts.day marks a pending past day, otherwise it happens now */
  function slip(s, kind, now, by, opts) {
    opts = opts || {};
    var past = !!opts.day;
    var k = past ? opts.day : dayKey(now);
    var at = past ? Math.min(now, endOfDay(k)) : now;
    var prev = s.days[k];
    var firstSlip = !(prev === 'y' || prev === 'p');
    if (!prev || RANK[kind] > RANK[prev]) s.days[k] = kind;
    var res = { kind: kind, day: k, blue: 0, yellow: 0, removed: 0, bonus: 0, streak: 0 };
    if (kind === 'y') {
      if (firstSlip) { s.balls.yellow += YELLOW_BALLS; res.yellow = YELLOW_BALLS; }
      if (s.settings.lapseResets) s.lastAt = Math.max(s.lastAt, at);
    } else {
      if (s.balls.blue > 0) { s.balls.blue -= 1; res.removed = 1; res.removedColor = 'blue'; }
      else if (s.balls.yellow > 0) { s.balls.yellow -= 1; res.removed = 1; res.removedColor = 'yellow'; }
      s.lastAt = Math.max(s.lastAt, at);
    }
    pushLog(s, { t: now, kind: kind, day: k, add: res.yellow, removed: res.removed, by: by || 'me' });
    return res;
  }

  /* an event from a guardian, applied once */
  function applyRemote(s, ev, now) {
    if (!ev || !ev.id || (ev.kind !== 'y' && ev.kind !== 'p')) return null;
    if (s.remoteSeen.indexOf(ev.id) >= 0) return null;
    s.remoteSeen.push(ev.id);
    if (s.remoteSeen.length > 200) s.remoteSeen.splice(0, s.remoteSeen.length - 200);
    var at = Math.min(+ev.at || now, now);
    var res = slip(s, ev.kind, at, 'guardian:' + (ev.by || 'Guardian'));
    res.by = ev.by || 'Guardian';
    return res;
  }

  /* ---------- derived numbers ---------- */
  function clock(ms) {
    var t = Math.max(0, Math.floor(ms / 1000));
    return { d: Math.floor(t / 86400), h: Math.floor((t % 86400) / 3600), m: Math.floor((t % 3600) / 60), s: t % 60, total: t };
  }

  function nextMilestone(totalSec) {
    var days = totalSec / 86400, prev = 0;
    for (var i = 0; i < MILESTONES.length; i++) {
      var m = MILESTONES[i];
      if (days < m) return { days: m, prev: prev, p: Math.max(0, Math.min(1, (days - prev) / (m - prev))) };
      prev = m;
    }
    return { days: prev, prev: prev, p: 1 };
  }

  function totalBalls(s) { return s.balls.blue + s.balls.yellow; }

  function counts(s) {
    var c = { b: 0, y: 0, p: 0 };
    for (var k in s.days) if (c[s.days[k]] !== undefined) c[s.days[k]]++;
    return c;
  }

  function lastRelapseAt(s) {
    for (var i = s.log.length - 1; i >= 0; i--) if (s.log[i].kind === 'p') return s.log[i].t;
    return 0;
  }

  /* sad | calm | happy | joy */
  function mood(s, now) {
    var r = lastRelapseAt(s);
    if (r && now - r < 6 * 3600e3) return 'sad';
    var n = totalBalls(s);
    if (n < 6) return 'calm';
    if (n < 40) return 'happy';
    return 'joy';
  }

  /* calendar cell for a day key */
  function dayState(s, k, now) {
    var today = dayKey(now);
    if (k < s.startDay) return { st: 'none' };
    var st = s.days[k];
    var o = { st: st || (k > today ? 'future' : (k === today ? 'today' : 'pending')), today: k === today, start: k === s.startDay };
    if (!st && k < today && checkinAt(k) > now) o.st = 'today';
    return o;
  }

  function publicSnapshot(s) {
    return { habit: s.habit, lastAt: s.lastAt, balls: totalBalls(s), best: s.best };
  }

  return {
    DAY: DAY, CHECKIN_HOUR: CHECKIN_HOUR, MILESTONES: MILESTONES, HABITS: HABITS,
    habitById: habitById, dayKey: dayKey, keyToDate: keyToDate, addDays: addDays,
    startOfDay: startOfDay, endOfDay: endOfDay, checkinAt: checkinAt, nextCheckin: nextCheckin,
    create: create, backfill: backfill, pendingDays: pendingDays, confirmDay: confirmDay,
    slip: slip, applyRemote: applyRemote, ballsForBlue: ballsForBlue, chainBefore: chainBefore,
    clock: clock, nextMilestone: nextMilestone, totalBalls: totalBalls, counts: counts,
    mood: mood, dayState: dayState, publicSnapshot: publicSnapshot, uid: uid
  };
});
