/* Detox native bridge: every call degrades quietly when not running inside Capacitor. */
(function () {
  'use strict';
  var C = window.Capacitor;
  var isNative = !!(C && C.isNativePlatform && C.isNativePlatform());
  var cache = {};

  function plug(name) {
    if (!isNative) return null;
    if (cache[name] !== undefined) return cache[name];
    var p = null;
    try {
      if (C.Plugins && C.Plugins[name]) p = C.Plugins[name];
      else if (C.registerPlugin) p = C.registerPlugin(name);
    } catch (e) { p = null; }
    cache[name] = p;
    return p;
  }
  function safe(p, fn) { try { var r = fn(p); if (r && r.catch) r.catch(function () {}); return r; } catch (e) {} }

  var CH = 'checkin', NOTE_ID = 8;

  var Native = {
    isNative: isNative,
    platform: isNative && C.getPlatform ? C.getPlatform() : 'web',

    /* kind: tap | soft | medium | heavy | success | warning | error */
    haptic: function (kind) {
      var H = plug('Haptics');
      if (H) {
        if (kind === 'success' || kind === 'warning' || kind === 'error') safe(H, function (h) { return h.notification({ type: kind.toUpperCase() }); });
        else safe(H, function (h) { return h.impact({ style: kind === 'heavy' ? 'HEAVY' : kind === 'medium' ? 'MEDIUM' : 'LIGHT' }); });
        return;
      }
      try { if (navigator.vibrate) navigator.vibrate(kind === 'heavy' ? 40 : kind === 'medium' ? 22 : 10); } catch (e) {}
    },

    prefs: (function () {
      var P = plug('Preferences');
      if (!P) return null;
      return {
        get: function (k) { return P.get({ key: k }).then(function (r) { return r && r.value; }); },
        set: function (k, v) { return P.set({ key: k, value: v }); }
      };
    })(),

    copy: function (text) {
      try { if (navigator.clipboard) return navigator.clipboard.writeText(text); } catch (e) {}
      var t = document.createElement('textarea');
      t.value = text; document.body.appendChild(t); t.select();
      try { document.execCommand('copy'); } catch (e) {}
      t.remove();
      return Promise.resolve();
    },

    share: function (o) {
      var S = plug('Share');
      if (S) return S.share({ title: o.title, text: o.text, url: o.url, dialogTitle: o.title });
      if (navigator.share) return navigator.share(o);
      return Native.copy((o.text ? o.text + ' ' : '') + (o.url || '')).then(function () { return 'copied'; });
    },

    /* ---- 8am check-in reminder ---- */
    notifyReady: function () {
      var N = plug('LocalNotifications');
      if (!N) return Promise.resolve(false);
      return N.checkPermissions().then(function (r) {
        if (r.display === 'granted') return true;
        return N.requestPermissions().then(function (q) { return q.display === 'granted'; });
      }).catch(function () { return false; });
    },
    scheduleCheckin: function (body) {
      var N = plug('LocalNotifications');
      if (!N) return Promise.resolve(false);
      return Native.notifyReady().then(function (ok) {
        if (!ok) return false;
        var mk = N.createChannel ? N.createChannel({ id: CH, name: 'Daily check-in', description: 'Your 8am check-in', importance: 4, visibility: 1, vibration: true }) : Promise.resolve();
        return Promise.resolve(mk).catch(function () {}).then(function () {
          return N.cancel({ notifications: [{ id: NOTE_ID }] }).catch(function () {});
        }).then(function () {
          return N.schedule({ notifications: [{
            id: NOTE_ID, title: 'Detox', body: body, channelId: CH, smallIcon: 'ic_stat_detox', iconColor: '#4F7CFF',
            schedule: { on: { hour: 8, minute: 0 }, allowWhileIdle: true }
          }] });
        }).then(function () { return true; });
      }).catch(function () { return false; });
    },
    cancelCheckin: function () {
      var N = plug('LocalNotifications');
      if (N) safe(N, function (n) { return n.cancel({ notifications: [{ id: NOTE_ID }] }); });
    },

    /* ---- app lifecycle ---- */
    onResume: function (cb) {
      document.addEventListener('visibilitychange', function () { if (!document.hidden) cb(); });
      var A = plug('App');
      if (A) safe(A, function (a) { return a.addListener('resume', cb); });
    },
    onBack: function (cb) {
      var A = plug('App');
      if (A) safe(A, function (a) { return a.addListener('backButton', cb); });
    },
    exit: function () { var A = plug('App'); if (A) safe(A, function (a) { return a.exitApp(); }); },

    /* a native plugin by name (null on the web or when it was not built in) */
    plugin: function (name) {
      if (!isNative) return null;
      try { if (C.isPluginAvailable && !C.isPluginAvailable(name)) return null; } catch (e) {}
      return plug(name);
    },
    /* detox://pair/... links, e.g. from a QR code scanned with the camera app */
    onLink: function (cb) {
      var A = plug('App');
      if (A) safe(A, function (a) { return a.addListener('appUrlOpen', function (e) { cb(e && e.url); }); });
    },

    /* dark = light icons on a dark bar */
    statusBar: function (dark, color) {
      var S = plug('StatusBar');
      if (S) {
        safe(S, function (s) { return s.setStyle({ style: dark ? 'DARK' : 'LIGHT' }); });
        if (color) safe(S, function (s) { return s.setBackgroundColor({ color: color }); });
      }
      var m = document.querySelector('meta[name=theme-color]');
      if (m && color) m.setAttribute('content', color);
    }
  };
  window.Native = Native;
})();
