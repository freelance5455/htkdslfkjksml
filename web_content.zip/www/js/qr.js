/* Detox QR encoder: byte mode, versions 1-10, error correction L or M. No libraries. Works in browsers and in Node. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(); else root.QR = factory();
})(this, function () {
  'use strict';

  /* ---- Reed-Solomon over GF(256) ---- */
  var EXP = new Uint8Array(512), LOG = new Uint8Array(256);
  (function () {
    var x = 1, i;
    for (i = 0; i < 255; i++) { EXP[i] = x; LOG[x] = i; x <<= 1; if (x & 0x100) x ^= 0x11d; }
    for (i = 255; i < 512; i++) EXP[i] = EXP[i - 255];
  })();
  function gmul(a, b) { return a && b ? EXP[LOG[a] + LOG[b]] : 0; }
  function rsGenerator(n) {
    var g = [1], i, j, next;
    for (i = 0; i < n; i++) {
      next = [];
      for (j = 0; j <= g.length; j++) next.push(0);
      for (j = 0; j < g.length; j++) { next[j] ^= g[j]; next[j + 1] ^= gmul(g[j], EXP[i]); }
      g = next;
    }
    return g;
  }
  function rsRemainder(data, n) {
    var g = rsGenerator(n), res = [], i, j, f;
    for (i = 0; i < n; i++) res.push(0);
    for (i = 0; i < data.length; i++) {
      f = data[i] ^ res.shift(); res.push(0);
      for (j = 0; j < n; j++) res[j] ^= gmul(g[j + 1], f);
    }
    return res;
  }

  /* ---- tables: [ecPerBlock, blocksA, dataA, blocksB, dataB] per version 1..10 ---- */
  var BLOCKS = {
    L: [null, [7, 1, 19, 0, 0], [10, 1, 34, 0, 0], [15, 1, 55, 0, 0], [20, 1, 80, 0, 0], [26, 1, 108, 0, 0],
        [18, 2, 68, 0, 0], [20, 2, 78, 0, 0], [24, 2, 97, 0, 0], [30, 2, 116, 0, 0], [18, 2, 68, 2, 69]],
    M: [null, [10, 1, 16, 0, 0], [16, 1, 28, 0, 0], [26, 1, 44, 0, 0], [18, 2, 32, 0, 0], [24, 2, 43, 0, 0],
        [16, 4, 27, 0, 0], [18, 4, 31, 0, 0], [22, 2, 38, 2, 39], [22, 3, 36, 2, 37], [26, 4, 43, 1, 44]]
  };
  var ECC_BITS = { L: 1, M: 0 };
  var ALIGN = [null, [], [6, 18], [6, 22], [6, 26], [6, 30], [6, 34], [6, 22, 38], [6, 24, 42], [6, 26, 46], [6, 28, 50]];

  function dataCapacity(v, ecc) { var b = BLOCKS[ecc][v]; return b[1] * b[2] + b[3] * b[4]; }

  function utf8(str) {
    if (typeof TextEncoder !== 'undefined') return Array.prototype.slice.call(new TextEncoder().encode(str));
    var s = unescape(encodeURIComponent(str)), out = [], i;
    for (i = 0; i < s.length; i++) out.push(s.charCodeAt(i));
    return out;
  }

  /* ---- bit buffer -> codewords ---- */
  function makeData(bytes, v, ecc) {
    var bits = [], cap = dataCapacity(v, ecc) * 8, i;
    function put(val, len) { for (var k = len - 1; k >= 0; k--) bits.push((val >>> k) & 1); }
    put(4, 4); put(bytes.length, v < 10 ? 8 : 16);
    for (i = 0; i < bytes.length; i++) put(bytes[i], 8);
    put(0, Math.min(4, cap - bits.length));
    while (bits.length % 8) bits.push(0);
    var out = [];
    for (i = 0; i < bits.length; i += 8) { var b = 0; for (var k = 0; k < 8; k++) b = (b << 1) | bits[i + k]; out.push(b); }
    for (var pad = 0xEC; out.length < cap / 8; pad = pad === 0xEC ? 0x11 : 0xEC) out.push(pad);
    return out;
  }

  function interleave(data, v, ecc) {
    var b = BLOCKS[ecc][v], ecLen = b[0], blocks = [], pos = 0, i, j;
    var sizes = [];
    for (i = 0; i < b[1]; i++) sizes.push(b[2]);
    for (i = 0; i < b[3]; i++) sizes.push(b[4]);
    sizes.forEach(function (n) { var d = data.slice(pos, pos + n); pos += n; blocks.push({ d: d, e: rsRemainder(d, ecLen) }); });
    var out = [], maxD = Math.max(b[2], b[4]);
    for (i = 0; i < maxD; i++) for (j = 0; j < blocks.length; j++) if (i < blocks[j].d.length) out.push(blocks[j].d[i]);
    for (i = 0; i < ecLen; i++) for (j = 0; j < blocks.length; j++) out.push(blocks[j].e[i]);
    return out;
  }

  /* ---- matrix ---- */
  function bit(x, i) { return (x >>> i) & 1; }

  function build(codewords, v, ecc) {
    var size = 17 + 4 * v, m = [], fn = [], y, x, i;
    for (y = 0; y < size; y++) { m.push(new Array(size).fill(0)); fn.push(new Array(size).fill(false)); }
    function setFn(px, py, dark) { m[py][px] = dark ? 1 : 0; fn[py][px] = true; }

    function finder(cx, cy) {
      for (var dy = -4; dy <= 4; dy++) for (var dx = -4; dx <= 4; dx++) {
        var d = Math.max(Math.abs(dx), Math.abs(dy)), px = cx + dx, py = cy + dy;
        if (px >= 0 && px < size && py >= 0 && py < size) setFn(px, py, d !== 2 && d !== 4);
      }
    }
    for (i = 0; i < size; i++) { setFn(6, i, i % 2 === 0); setFn(i, 6, i % 2 === 0); }
    finder(3, 3); finder(size - 4, 3); finder(3, size - 4);
    var pos = ALIGN[v], last = pos.length - 1;
    for (var a = 0; a < pos.length; a++) for (var b = 0; b < pos.length; b++) {
      if ((a === 0 && b === 0) || (a === 0 && b === last) || (a === last && b === 0)) continue;
      for (var dy = -2; dy <= 2; dy++) for (var dx = -2; dx <= 2; dx++)
        setFn(pos[a] + dx, pos[b] + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
    }

    function formatBits(mask) {
      var data = (ECC_BITS[ecc] << 3) | mask, rem = data;
      for (var k = 0; k < 10; k++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
      return ((data << 10) | rem) ^ 0x5412;
    }
    function drawFormat(mask) {
      var bits = formatBits(mask), k;
      for (k = 0; k <= 5; k++) setFn(8, k, bit(bits, k));
      setFn(8, 7, bit(bits, 6)); setFn(8, 8, bit(bits, 7)); setFn(7, 8, bit(bits, 8));
      for (k = 9; k < 15; k++) setFn(14 - k, 8, bit(bits, k));
      for (k = 0; k < 8; k++) setFn(size - 1 - k, 8, bit(bits, k));
      for (k = 8; k < 15; k++) setFn(8, size - 15 + k, bit(bits, k));
      setFn(8, size - 8, true);
    }
    drawFormat(0);
    if (v >= 7) {
      var rem = v;
      for (i = 0; i < 12; i++) rem = (rem << 1) ^ ((rem >>> 11) * 0x1F25);
      var vb = (v << 12) | rem;
      for (i = 0; i < 18; i++) {
        var col = bit(vb, i), aa = size - 11 + (i % 3), bb = Math.floor(i / 3);
        setFn(aa, bb, col); setFn(bb, aa, col);
      }
    }

    /* zig-zag data placement */
    var n = 0, total = codewords.length * 8, right, vert, j, up, py;
    for (right = size - 1; right >= 1; right -= 2) {
      if (right === 6) right = 5;
      for (vert = 0; vert < size; vert++) for (j = 0; j < 2; j++) {
        x = right - j; up = ((right + 1) & 2) === 0; py = up ? size - 1 - vert : vert;
        if (!fn[py][x] && n < total) { m[py][x] = bit(codewords[n >>> 3], 7 - (n & 7)); n++; }
      }
    }
    return { size: size, m: m, fn: fn, drawFormat: drawFormat };
  }

  function maskBit(mask, x, y) {
    switch (mask) {
      case 0: return (x + y) % 2 === 0;
      case 1: return y % 2 === 0;
      case 2: return x % 3 === 0;
      case 3: return (x + y) % 3 === 0;
      case 4: return (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0;
      case 5: return (x * y) % 2 + (x * y) % 3 === 0;
      case 6: return ((x * y) % 2 + (x * y) % 3) % 2 === 0;
      default: return ((x + y) % 2 + (x * y) % 3) % 2 === 0;
    }
  }
  function applyMask(q, mask) {
    for (var y = 0; y < q.size; y++) for (var x = 0; x < q.size; x++)
      if (!q.fn[y][x] && maskBit(mask, x, y)) q.m[y][x] ^= 1;
  }

  function penalty(m, size) {
    var score = 0, x, y, run, prev, dark = 0;
    function lines(get) {
      for (var a = 0; a < size; a++) {
        run = 1; prev = get(a, 0);
        for (var b = 1; b < size; b++) {
          var c = get(a, b);
          if (c === prev) { run++; if (run === 5) score += 3; else if (run > 5) score++; } else { run = 1; prev = c; }
        }
        var s = '';
        for (b = 0; b < size; b++) s += get(a, b);
        var k = -1;
        while ((k = s.indexOf('10111010000', k + 1)) >= 0) score += 40;
        k = -1;
        while ((k = s.indexOf('00001011101', k + 1)) >= 0) score += 40;
      }
    }
    lines(function (a, b) { return m[a][b]; });
    lines(function (a, b) { return m[b][a]; });
    for (y = 0; y < size - 1; y++) for (x = 0; x < size - 1; x++) {
      var c = m[y][x];
      if (c === m[y][x + 1] && c === m[y + 1][x] && c === m[y + 1][x + 1]) score += 3;
    }
    for (y = 0; y < size; y++) for (x = 0; x < size; x++) dark += m[y][x];
    var tot = size * size;
    score += (Math.ceil(Math.abs(dark * 20 - tot * 10) / tot) - 1) * 10;
    return score;
  }

  /* ---- public: encode text -> { size, version, rows[y][x] = 0/1 } ---- */
  function encode(text, ecc) {
    ecc = ecc === 'L' ? 'L' : 'M';
    var bytes = utf8(String(text)), v;
    for (v = 1; v <= 10; v++) {
      var need = 4 + (v < 10 ? 8 : 16) + bytes.length * 8;
      if (need <= dataCapacity(v, ecc) * 8) break;
    }
    if (v > 10) throw new Error('Text too long for this QR code');
    var cw = interleave(makeData(bytes, v, ecc), v, ecc);
    var best = null, bestScore = Infinity;
    for (var mask = 0; mask < 8; mask++) {
      var q = build(cw, v, ecc);
      applyMask(q, mask); q.drawFormat(mask);
      var sc = penalty(q.m, q.size);
      if (sc < bestScore) { bestScore = sc; best = { size: q.size, version: v, rows: q.m, mask: mask }; }
    }
    return best;
  }

  /* ---- drawing helpers ---- */
  function svg(text, opt) {
    opt = opt || {};
    var q = encode(text, opt.ecc), quiet = opt.quiet == null ? 4 : opt.quiet, n = q.size + quiet * 2, d = '';
    for (var y = 0; y < q.size; y++) {
      var x = 0;
      while (x < q.size) {
        if (q.rows[y][x]) { var s = x; while (x < q.size && q.rows[y][x]) x++; d += 'M' + (s + quiet) + ' ' + (y + quiet) + 'h' + (x - s) + 'v1h-' + (x - s) + 'z'; }
        else x++;
      }
    }
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + n + ' ' + n + '" shape-rendering="crispEdges">' +
      '<rect width="' + n + '" height="' + n + '" fill="' + (opt.bg || '#fff') + '"/><path d="' + d + '" fill="' + (opt.fg || '#0b1130') + '"/></svg>';
  }

  return { encode: encode, svg: svg, capacity: function (ecc) { return Math.floor((dataCapacity(10, ecc === 'L' ? 'L' : 'M') * 8 - 20) / 8); } };
});
