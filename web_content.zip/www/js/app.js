/* Detox app shell: boot, scrolling between timer and pit, theme flip, actions -> pit, reminders. */
(function () {
  'use strict';
  var $ = UI.$, C = DetoxCore, scroller, main, p = 0, isDay = false, started = false, tickT = 0;
  var clamp = function (v, a, b) { return Math.max(a, Math.min(b, v)); };

  function boot() {
    scroller = $('#scroller'); main = $('#main');
    Timer.build();
    Store.init().then(function (s) { if (s) start(false); else onboard(); });
  }

  function onboard() {
    $('#main').hidden = true;
    Onboarding.run().then(function (r) {
      Store.set(C.create(r.habit, r.lastAt, Date.now()), 'create');
      start(true);
      Onboarding.leave();
    });
  }

  function start(first) {
    if (started) { Timer.render(); return; }
    started = true;
    main.hidden = false;
    var s = Store.get();
    Timer.render();
    requestAnimationFrame(function () {
      Pit.init(); bindScroll(); onScroll();
      setTimeout(function () { Timer.toss(); }, first ? 650 : 350);
    });
    Timer.on('action', onAction);
    Timer.on('newday', function (d) { UI.toast('<b>Day ' + d + '.</b> Another full day. Keep going.', { dot: '#7c6bff' }); Native.haptic('success'); });
    clearInterval(tickT); tickT = setInterval(function () { Timer.tick(); chip(); }, 250);
    $('#btnCal').onclick = function () { Native.haptic('light'); Calendar.open(); };
    $('#btnSet').onclick = function () { Native.haptic('light'); Settings.open(); };
    $('#scrollHint').onclick = function () { scrollTo(1); };
    $('#pitCheckin').onclick = function () { scrollTo(0); };
    $('#habitPill').onclick = function () { scrollTo(p < .5 ? 1 : 0); };
    Native.onResume(function () { Timer.render(); Pit.refresh(); if (window.Sync) Sync.poll(); });
    Native.onBack(function () {
      if (UI.sheet.isOpen()) UI.sheet.close();
      else if (p > .5) scrollTo(0);
      else Native.exit();
    });
    Native.statusBar(true, '#070b25');
    reminders();
    if (window.Sync) Sync.start();
  }

  /* ---------- scroll: timer page <-> pit page ---------- */
  function bindScroll() { scroller.addEventListener('scroll', onScroll, { passive: true }); window.addEventListener('resize', onScroll); }
  function onScroll() {
    var h = scroller.clientHeight || 1;
    p = clamp(scroller.scrollTop / h, 0, 1);
    Timer.setScroll(p);
    $('#scrollHint').style.opacity = String(1 - clamp(p * 4, 0, 1));
    var day = p > .42;
    if (day !== isDay) {
      isDay = day; document.body.classList.toggle('is-day', day);
      Native.statusBar(!day, day ? '#a9dcff' : '#070b25');
      if (day) Native.haptic('medium');
    }
    Pit.setActive(p > .02);
    Timer.pause(false);
    if (p > .55 && !Store.get().seen.intro) Pit.intro();
  }
  function scrollTo(page) {
    return new Promise(function (res) {
      var target = page * scroller.clientHeight;
      if (Math.abs(scroller.scrollTop - target) < 4) return res();
      scroller.scrollTo({ top: target, behavior: 'smooth' });
      var t0 = performance.now();
      (function poll() {
        if (Math.abs(scroller.scrollTop - target) < 3 || performance.now() - t0 > 1400) return setTimeout(res, 120);
        requestAnimationFrame(poll);
      })();
    });
  }

  function chip() {
    var el = $('#pitCheckin'), pend = Timer.pending(), s = Store.get();
    if (!pend.length || !s) { if (!el.hidden) el.hidden = true; return; }
    var yk = C.addDays(C.dayKey(Date.now()), -1);
    var txt = 'Check in for ' + (pend[0] === yk ? 'yesterday' : UI.fmtDay(pend[0])) + ' ' + '↑';
    if (el.hidden) el.hidden = false;
    if (el.textContent !== txt) el.textContent = txt;
  }

  /* ---------- check-ins ---------- */
  function onAction(a) {
    var r = a.res, s = Store.get();
    if (a.remote) {
      Pit.apply(r, { silent: true });
      UI.toast('<b>' + UI.esc(a.by) + '</b> marked a ' + (r.kind === 'p' ? 'relapse' : 'lapse') + ' for you. Be kind to yourself. You are still on this.', { dot: r.kind === 'p' ? '#9b5cff' : '#ffc933', ms: 7000 });
      if (window.Sync) Sync.push();
      return;
    }
    var msg, dot, extra = '';
    if (r.kind === 'b') {
      msg = '<b>+' + r.blue + ' balls</b> are dropping into the pit' + (r.bonus ? ' <span style="opacity:.75">(includes a ' + r.bonus + '-ball milestone bonus)</span>' : '');
      dot = '#3f7cff';
    } else if (r.kind === 'y') {
      msg = '<b>Lapse logged.</b> ' + (r.yellow ? r.yellow + ' yellow balls roll in. ' : '') + (s.settings.lapseResets ? 'Timer restarted.' : 'Timer keeps running.');
      dot = '#ffc933';
    } else {
      msg = '<b>Relapse logged.</b> ' + (r.removed ? 'One ball leaves the pit. ' : '') + 'Tomorrow is a fresh start.';
      dot = '#9b5cff';
    }
    scrollTo(1).then(function () { Pit.apply(r); });
    UI.toast(msg, { dot: dot, action: 'Undo', ms: 6500, onAction: function () { undo(a.snap); } });
    if (window.Sync) Sync.push();
  }
  function undo(snap) {
    Store.restore(snap, 'undo');
    Timer.render(); Pit.refresh(); Native.haptic('light');
    UI.toast('Undone.', { ms: 2200 });
    if (window.Sync) Sync.push();
  }

  /* ---------- reminders ---------- */
  function reminders() {
    var s = Store.get(); if (!s) return;
    if (s.settings.reminders) {
      var h = C.habitById(s.habit);
      Native.scheduleCheckin('Good morning. Did you stay ' + h.clean + ' yesterday? Tap to check in.');
    } else Native.cancelCheckin();
  }

  function resetAll() {
    Native.cancelCheckin(); Store.clear(); location.reload();
  }

  window.App = { reminders: reminders, scrollTo: scrollTo, resetAll: resetAll, undo: undo,
    restart: function () { location.reload(); } };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
