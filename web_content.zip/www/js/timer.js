/* Detox timer page: live clock, progress ring, check-in banner, the three orbs, and the ball that gets thrown. */
(function () {
  'use strict';
  var $ = UI.$, C = DetoxCore, CIRC = 2 * Math.PI * 146;
  var listeners = {}, ticks = [], last = {}, pendCache = { min: -1, list: [] };
  var COLORS = { b: '#3f7cff', y: '#ffc933', p: '#9b5cff' };

  function on(ev, fn) { (listeners[ev] = listeners[ev] || []).push(fn); }
  function emit(ev, a) { (listeners[ev] || []).forEach(function (f) { try { f(a); } catch (e) { console.error(e); } }); }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function pending(force) {
    var now = Date.now(), m = Math.floor(now / 60000);
    if (force || pendCache.min !== m) { pendCache = { min: m, list: C.pendingDays(Store.get(), now) }; }
    return pendCache.list;
  }

  /* ---------- build ---------- */
  function build() {
    var g = $('#ringTicks'), html = '';
    for (var i = 0; i < 60; i++) {
      var a = i / 60 * Math.PI * 2, r1 = 131, r2 = i % 5 === 0 ? 124 : 127.5;
      html += '<line x1="' + (160 + Math.sin(a) * r1).toFixed(2) + '" y1="' + (160 - Math.cos(a) * r1).toFixed(2) +
        '" x2="' + (160 + Math.sin(a) * r2).toFixed(2) + '" y2="' + (160 - Math.cos(a) * r2).toFixed(2) + '"/>';
    }
    g.innerHTML = html; ticks = UI.$$('line', g);
    UI.$$('.orb-btn').forEach(function (b) {
      b.addEventListener('click', function () { press(b.dataset.kind, b); });
    });
    $('#whatBtn').onclick = explain;
  }

  /* ---------- per-second paint ---------- */
  function tick(force) {
    var s = Store.get(); if (!s) return;
    var now = Date.now(), ms = now - s.lastAt, c = C.clock(ms);
    if (force || c.total !== last.total) {
      last.total = c.total;
      if (force || c.d !== last.d) { $('#tDays').textContent = c.d; $('#tDaysU').textContent = c.d === 1 ? 'day' : 'days'; last.d = c.d; }
      $('#tH').textContent = pad(c.h); $('#tM').textContent = pad(c.m); $('#tS').textContent = pad(c.s);
      $('#miniTimer').textContent = c.d + 'd ' + pad(c.h) + ':' + pad(c.m) + ':' + pad(c.s);
      if (ticks.length) {
        if (last.tick != null) ticks[last.tick].style.stroke = '';
        last.tick = c.s; ticks[c.s].style.stroke = 'rgba(255,255,255,.9)';
      }
      var ms2 = C.nextMilestone(c.total);
      var off = CIRC * (1 - ms2.p);
      $('#ringArc').style.strokeDashoffset = off;
      var ang = -Math.PI / 2 + ms2.p * Math.PI * 2, head = $('#ringHead');
      head.setAttribute('cx', (160 + Math.cos(ang) * 146).toFixed(2)); head.setAttribute('cy', (160 + Math.sin(ang) * 146).toFixed(2));
      if (force || ms2.days !== last.ms) {
        last.ms = ms2.days;
        $('#tNext').innerHTML = 'Next milestone <b>' + UI.plural(ms2.days, 'day') + '</b>';
      }
      if (last.d !== undefined && last.prevD !== undefined && c.d > last.prevD && !force) emit('newday', c.d);
      last.prevD = c.d;
    }
    banner();
  }

  function banner() {
    var s = Store.get(), p = pending(), now = Date.now(), h = C.habitById(s.habit);
    var key = p.length + '|' + (p[0] || '') + '|' + C.dayKey(now);
    if (last.bannerKey === key && last.bannerMin === Math.floor(now / 60000)) return;
    last.bannerKey = key; last.bannerMin = Math.floor(now / 60000);
    var el = $('#banner'), blue = $('#oBlue');
    if (p.length) {
      var yk = C.addDays(C.dayKey(now), -1), when = p[0] === yk ? 'yesterday' : 'on <b>' + UI.fmtDay(p[0]) + '</b>';
      el.className = 'banner live';
      el.innerHTML = '<span>Check-in time. Did you stay <b>' + h.clean + '</b> ' + when + '?' + (p.length > 1 ? ' <i style="opacity:.7;font-style:normal">(+' + (p.length - 1) + ' more waiting)</i>' : '') + '</span>';
      blue.classList.add('ready'); blue.classList.remove('locked');
    } else {
      var n = C.nextCheckin(now), isToday = C.dayKey(n) === C.dayKey(now);
      el.className = 'banner';
      el.textContent = 'Next check-in ' + (isToday ? 'today' : 'tomorrow') + ' at 8:00';
      blue.classList.remove('ready'); blue.classList.add('locked');
    }
  }

  /* full repaint after the state changed under us */
  function render() {
    var s = Store.get(); if (!s) return;
    var h = C.habitById(s.habit);
    $('#habitName').textContent = h.name;
    $('#habitPill').querySelector('use').setAttribute('href', '#i-' + h.id);
    $('#tLabel').textContent = h.clean + ' for';
    $('#tSince').textContent = 'since ' + UI.fmtStamp(s.lastAt);
    ticks.forEach(function (t) { t.style.stroke = ''; });
    last = {}; pending(true); tick(true);
  }

  /* ---------- actions ---------- */
  function press(kind, btn) {
    btn.classList.remove('pop'); void btn.offsetWidth; btn.classList.add('pop');
    var r = btn.querySelector('.orb').getBoundingClientRect();
    if (kind === 'b') return blue(r);
    return slip(kind, r);
  }

  function blue(rect) {
    var p = pending(true), now = Date.now(), s = Store.get();
    if (!p.length) {
      Native.haptic('warning');
      UI.toast('<b>Day passed</b> opens at 8:00 each morning, when you check in for the day before.', { dot: COLORS.b });
      return;
    }
    var snap = Store.snapshot(), res;
    Store.update(function (st) { res = C.confirmDay(st, p[0], now, 'me'); }, 'action');
    UI.burst(rect.left + rect.width / 2, rect.top + rect.height / 2, COLORS.b, 18);
    Native.haptic('success');
    pending(true); render();
    emit('action', { res: res, by: 'me', snap: snap });
  }

  function slip(kind, rect) {
    var s = Store.get(), p = pending(true), day = p[0] || null, h = C.habitById(s.habit);
    var yk = C.addDays(C.dayKey(Date.now()), -1);
    var label = !day ? 'today' : (day === yk ? 'yesterday' : UI.fmtDay(day));
    var lapse = kind === 'y';
    Native.haptic('medium');
    UI.confirm({
      title: lapse ? 'Log a lapse?' : 'Log a relapse?',
      text: lapse
        ? 'We will mark <b>' + label + '</b> yellow. ' + (s.settings.lapseResets ? 'Your timer restarts, but ' : '') + 'because you were honest, a couple of yellow balls roll into the pit. Nothing is taken away.'
        : 'We will mark <b>' + label + '</b> purple. Your timer restarts and <b>one ball</b> leaves the pit. Just one. Tomorrow is a fresh start, and the elephant is still here.',
      ok: lapse ? 'Log lapse' : 'Log relapse', cancel: 'Not now', tone: lapse ? 'primary' : 'danger'
    }).then(function (yes) {
      if (!yes) return;
      apply(kind, { day: day }, 'me', rect);
    });
  }

  /* shared by buttons and guardians */
  function apply(kind, o, by, rect) {
    var snap = Store.snapshot(), res, now = Date.now();
    Store.update(function (st) { res = C.slip(st, kind, now, by === 'me' ? 'me' : 'guardian:' + by, { day: (o && o.day) || null }); }, 'action');
    if (rect) UI.burst(rect.left + rect.width / 2, rect.top + rect.height / 2, COLORS[kind], 14);
    Native.haptic(kind === 'p' ? 'heavy' : 'warning');
    pending(true); render();
    emit('action', { res: res, by: by, snap: snap });
  }

  function applyRemote(ev) {
    var snap = Store.snapshot(), res;
    Store.update(function (st) { res = C.applyRemote(st, ev, Date.now()); }, 'remote');
    if (!res) return null;
    Native.haptic('heavy');
    pending(true); render();
    emit('action', { res: res, by: res.by, snap: snap, remote: true });
    return res;
  }

  function explain() {
    var h = C.habitById(Store.get().habit);
    UI.sheet.open({
      title: 'The three colours',
      build: function (b) {
        b.innerHTML =
          '<p style="color:var(--ink-2);font-size:15px;line-height:1.55;margin-bottom:6px">Every morning at 8:00 you check in for the day before.</p>' +
          [['blue', 'Blue · Day passed', 'You stayed ' + h.clean + ' all day. The mesh bag cracks and fresh balls tumble into the pit. The longer your streak, the more balls fall.'],
           ['yellow', 'Yellow · Lapse', 'A slip. Your timer restarts, but you were honest, so a couple of yellow balls roll in. Nothing is taken away.'],
           ['purple', 'Purple · Relapse', 'You fell back. Your timer restarts and one ball leaves the pit. Just one, and tomorrow is a fresh start.']]
          .map(function (r) { return '<div class="row" style="align-items:flex-start;padding:16px 4px"><i class="orb ' + r[0] + '" style="width:46px;height:46px;flex:none"></i><div class="t"><b>' + r[1] + '</b><span>' + r[2] + '</span></div></div>'; }).join('') +
          '<p style="color:var(--ink-3);font-size:13.5px;line-height:1.5;margin-top:10px">Your guardians can press Lapse or Relapse for you if you ever cannot do it yourself.</p>';
      }
    });
  }

  /* ---------- the ball: thrown up, hangs in the air, falls into the pit as you scroll ---------- */
  var ball = { el: null, t0: 0, raf: 0, p: 0, tossing: false, bob: true };
  function geom() {
    var main = $('#main').getBoundingClientRect(), rb = $('#ringBox').getBoundingClientRect();
    var hover = Math.max(main.top + 78, rb.top - 66);
    return { W: main.width, H: main.height, hover: hover, land: main.height * 0.52, x: main.width / 2 - 29 };
  }
  function ballFrame(now) {
    var g = geom(), t = now - ball.t0, p = ball.p, y, x = g.x, rot = 0, sc = 1;
    if (ball.tossing) {
      var T1 = 1250, T2 = 1850;
      if (t < T1) { var u = t / T1, e = 1 - Math.pow(1 - u, 3); y = g.H + 70 + (g.hover - 34 - (g.H + 70)) * e; x += Math.sin(u * 3) * 9; rot = u * 380; sc = .8 + .2 * e; }
      else if (t < T2) { var v = (t - T1) / (T2 - T1), e2 = v * v * (3 - 2 * v); y = g.hover - 34 + 34 * e2; rot = 380 + v * 40; }
      else { ball.tossing = false; ball.t0 = now; y = g.hover; }
    } else {
      var tt = now - ball.t0;
      y = g.hover + Math.sin(tt / 640) * 7 * (1 - p); x += Math.sin(tt / 1100) * 3 * (1 - p); rot = 420 + Math.sin(tt / 900) * 10;
    }
    if (p > 0) {
      var f = Math.min(1, p * 1.06); f = f * f * (1.4 - .4 * f);
      y = y + (g.land - y) * f; rot += p * 260; sc = 1 + p * .1;
    }
    var op = p > .9 ? Math.max(0, 1 - (p - .9) / .1) : 1;
    ball.el.style.opacity = op;
    ball.el.style.transform = 'translate3d(' + x.toFixed(1) + 'px,' + y.toFixed(1) + 'px,0) rotate(' + rot.toFixed(0) + 'deg) scale(' + sc.toFixed(3) + ')';
    ball.raf = requestAnimationFrame(ballFrame);
  }
  function toss() {
    ball.el = ball.el || $('#heroBall');
    ball.tossing = true; ball.t0 = performance.now();
    if (!ball.raf) ball.raf = requestAnimationFrame(ballFrame);
  }
  function setScroll(p) { ball.p = p; }
  function pause(v) {
    if (v && ball.raf) { cancelAnimationFrame(ball.raf); ball.raf = 0; }
    else if (!v && !ball.raf && ball.el) ball.raf = requestAnimationFrame(ballFrame);
  }

  window.Timer = { build: build, tick: tick, render: render, on: on, apply: apply, applyRemote: applyRemote, pending: pending,
    toss: toss, setScroll: setScroll, pause: pause, explain: explain };
})();
