/* ============================================================
   RadLedger — ذخیره‌سازی (localStorage + آینهٔ native)، بک‌آپ و بازیابی
   ============================================================ */
'use strict';

let db = defaultDb();
const NATIVE = () => { const C = window.Capacitor; return !!(C && C.isNativePlatform && C.isNativePlatform()); };
const plug = (n) => { try { return NATIVE() && window.Capacitor.Plugins && window.Capacitor.Plugins[n]; } catch (e) { return null; } };

// آینهٔ داده در SharedPreferences اندروید؛ اگر WebView پاک شد داده برمی‌گردد
const mirrorTimers = {};
function mirror(key, value) {
  const P = plug('Preferences');
  if (!P) return;
  clearTimeout(mirrorTimers[key]);
  mirrorTimers[key] = setTimeout(() => { try { P.set({ key, value }); } catch (e) { /* ignore */ } }, 1500);
}
async function recover(key) {
  const P = plug('Preferences');
  if (!P) return null;
  try { const r = await P.get({ key }); return r && r.value ? r.value : null; } catch (e) { return null; }
}
function lsSet(key, value) {
  try { localStorage.setItem(key, value); } catch (e) { toast('حافظه پر است؛ بک‌آپ بگیرید'); }
  mirror(key, value);
}

function save() { lsSet('wf', JSON.stringify(db)); }

async function loadDb() {
  let raw = null, recovered = false;
  try { raw = JSON.parse(localStorage.getItem('wf') || 'null'); } catch (e) { raw = null; }
  let d = normalizeDb(raw);
  if (!d) {
    const m = await recover('wf');
    if (m) { try { d = normalizeDb(JSON.parse(m)); recovered = !!d; } catch (e) { d = null; } }
  }
  db = d || defaultDb();
  if (d) lsSet('wf', JSON.stringify(db)); // ثبت نسخهٔ پاک‌سازی‌شده/مهاجرت‌یافته
  return recovered;
}

/* ---------- ذخیره / اشتراک فایل ---------- */
async function saveFile(name, blob) {
  const FS = plug('Filesystem'), SH = plug('Share');
  if (FS && SH) {
    try {
      const data = await new Promise((res, rej) => { const f = new FileReader(); f.onload = () => res(f.result.split(',')[1]); f.onerror = rej; f.readAsDataURL(blob); });
      const w = await FS.writeFile({ path: name, data, directory: 'CACHE' });
      await SH.share({ title: name, url: w.uri, dialogTitle: 'ذخیره / ارسال فایل' });
      return true;
    } catch (e) {
      if (!/cancel/i.test((e && e.message) || '')) toast('خطا: ' + ((e && e.message) || e));
      return false;
    }
  }
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  return true;
}

async function backup() {
  const j = J(todayIso());
  const payload = { app: 'RadLedger', exported: new Date().toISOString(), ...db };
  const ok = await saveFile(`radledger-backup-${j.y}-${pad(j.m)}-${pad(j.d)}.json`, new Blob([JSON.stringify(payload)], { type: 'application/json' }));
  if (ok) { db.set.lastBackup = Date.now(); save(); R(); }
}

function restore(el) {
  const f = el.files[0];
  el.value = '';
  if (!f) return;
  const r = new FileReader();
  r.onload = () => {
    let d = null;
    try { d = normalizeDb(JSON.parse(r.result)); } catch (e) { d = null; }
    if (!d) return toast('فایل بک‌آپ معتبر نیست');
    const info = `${d.workers.length} نیرو، ${d.att.length} ثبت حضور`;
    if (!confirm(`اطلاعات فعلی با فایل بک‌آپ (${info}) جایگزین شود؟`)) return;
    db = d; save(); R(); toast('بازیابی انجام شد');
  };
  r.onerror = () => toast('خواندن فایل ناموفق بود');
  r.readAsText(f);
}

async function wipeAll() {
  if (!confirm('همهٔ اطلاعات (نیروها، حضور، مالی) برای همیشه پاک شود؟')) return;
  if (!confirm('آخرین هشدار: این کار قابل بازگشت نیست مگر بک‌آپ داشته باشید. ادامه می‌دهید؟')) return;
  db = defaultDb();
  try { localStorage.removeItem('wf'); } catch (e) { /* ignore */ }
  const P = plug('Preferences');
  if (P) { try { await P.remove({ key: 'wf' }); } catch (e) { /* ignore */ } }
  location.reload();
}
