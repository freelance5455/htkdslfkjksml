/* Detox store: one JSON blob in localStorage, mirrored to native Preferences when available. */
(function () {
  'use strict';
  var KEY = 'detox.v1';
  var state = null, subs = [], mirrorTimer = 0;

  function normalize(s) {
    if (!s || typeof s !== 'object') return null;
    s.days = s.days || {};
    s.balls = s.balls || { blue: 0, yellow: 0 };
    s.log = s.log || [];
    s.seen = s.seen || { intro: false };
    s.settings = Object.assign({ lapseResets: true, reminders: true }, s.settings || {});
    s.guardians = s.guardians && s.guardians.length === 2 ? s.guardians : [null, null];
    s.remoteSeen = s.remoteSeen || [];
    s.server = s.server || '';
    s.cracks = s.cracks || 0;
    s.best = s.best || 0;
    return s;
  }

  function readLocal() {
    try { var raw = localStorage.getItem(KEY); return raw ? JSON.parse(raw) : null; } catch (e) { return null; }
  }

  function persist() {
    var raw = JSON.stringify(state);
    try { localStorage.setItem(KEY, raw); } catch (e) {}
    clearTimeout(mirrorTimer);
    mirrorTimer = setTimeout(function () {
      var N = window.Native;
      if (N && N.prefs) N.prefs.set(KEY, raw);
    }, 250);
  }

  function emit(why) {
    for (var i = 0; i < subs.length; i++) { try { subs[i](state, why); } catch (e) { console.error(e); } }
  }

  var Store = {
    /* resolves with the saved state, or null for a first launch */
    init: function () {
      state = normalize(readLocal());
      if (state) return Promise.resolve(state);
      var N = window.Native;
      if (N && N.prefs) {
        return N.prefs.get(KEY).then(function (raw) {
          if (raw) { try { state = normalize(JSON.parse(raw)); } catch (e) {} }
          if (state) { try { localStorage.setItem(KEY, raw); } catch (e) {} }
          return state;
        }, function () { return null; });
      }
      return Promise.resolve(null);
    },
    get: function () { return state; },
    set: function (s, why) { state = normalize(s); persist(); emit(why || 'set'); return state; },
    /* mutate in place, then save + notify */
    update: function (fn, why) { var r = fn(state); persist(); emit(why || 'update'); return r; },
    clear: function () {
      state = null;
      try { localStorage.removeItem(KEY); } catch (e) {}
      var N = window.Native;
      if (N && N.prefs) N.prefs.set(KEY, '');
      emit('clear');
    },
    snapshot: function () { return JSON.stringify(state); },
    restore: function (raw, why) { state = normalize(JSON.parse(raw)); persist(); emit(why || 'restore'); },
    subscribe: function (fn) { subs.push(fn); return function () { subs = subs.filter(function (f) { return f !== fn; }); }; }
  };
  window.Store = Store;
})();
