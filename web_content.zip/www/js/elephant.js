/* Detox elephant: drawn procedurally on canvas, with a walk cycle, moods and a few playful behaviours. */
(function () {
  'use strict';
  var COL = { base: '#a9b6d6', light: '#d3dcf1', dark: '#7c8bb4', far: '#8a98bf', ear: '#f6b8ca', ear2: '#ee9ab6', tusk: '#fffaf0', nail: '#eef2fd', eye: '#161c33' };
  var TAU = Math.PI * 2;
  var rnd = function (a, b) { return a + Math.random() * (b - a); };
  var clamp = function (v, a, b) { return Math.max(a, Math.min(b, v)); };

  var E = {
    x: -200, y: 0, sc: 1, dir: 1, mood: 'calm', t: 0, step: 0, speed: 0, target: null, arrive: null,
    hopT: -1, hopH: 34, tossT: -1, tossDone: false, sq: 0, blink: 0, nextBlink: 2, nextAct: 3, bonk: 0,
    earA: 0, trunkTh: 74, trunkCurl: 90, smile: 0.5, bounds: [60, 300], env: {}, joyT: 0
  };

  function rr(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y); ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r); ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r); ctx.quadraticCurveTo(x, y, x + r, y); ctx.closePath();
  }

  function leg(ctx, hx, swing, color, lift) {
    ctx.save(); ctx.translate(hx, -74); ctx.rotate(swing);
    var len = 78 - lift;
    var g = ctx.createLinearGradient(-24, 0, 24, 0); g.addColorStop(0, color); g.addColorStop(1, color);
    ctx.fillStyle = color; rr(ctx, -23, -4, 46, len + 4, 20); ctx.fill();
    ctx.fillStyle = COL.nail;
    for (var i = 0; i < 3; i++) { ctx.beginPath(); ctx.ellipse(-10 + i * 10, len - 7, 5.2, 4, 0, 0, TAU); ctx.fill(); }
    ctx.restore();
  }

  function trunkPts() {
    var pts = [], N = 15, x = 150, y = -126, th = E.trunkTh * Math.PI / 180, L = 9.6;
    var curl = E.trunkCurl * Math.PI / 180;
    for (var i = 0; i < N; i++) {
      var f = i / (N - 1), r = 25 - 15 * Math.pow(f, 0.8);
      pts.push({ x: x, y: y, r: r, a: th });
      th -= curl * (0.35 + f * 1.3) / N;
      x += Math.cos(th) * L; y += Math.sin(th) * L;
    }
    return pts;
  }

  function draw(ctx) {
    var s = E, sq = s.sq, mood = s.mood;
    var bob = Math.abs(Math.sin(s.step)) * (s.speed ? 4 : 0) + Math.sin(s.t * 1.7) * 1.2;
    ctx.save();
    ctx.translate(s.x, s.y);
    ctx.scale(s.dir * s.sc * (1 + .1 * sq), s.sc * (1 - .1 * sq));
    var sw = s.speed ? Math.sin(s.step) * 0.34 : Math.sin(s.t * 2) * .02;
    var hop = s.hopT >= 0 ? 1 : 0;
    // far legs
    leg(ctx, -28, -sw, COL.far, hop * 10);
    leg(ctx, 42, sw, COL.far, hop * 10);
    ctx.translate(0, -bob);
    // tail
    ctx.strokeStyle = COL.dark; ctx.lineCap = 'round'; ctx.lineWidth = 8;
    var tw = Math.sin(s.t * 3.1) * (mood === 'sad' ? 2 : 9);
    ctx.beginPath(); ctx.moveTo(-108, -134); ctx.quadraticCurveTo(-138 - tw * .4, -112, -132 - tw, -76); ctx.stroke();
    ctx.fillStyle = COL.dark; ctx.beginPath(); ctx.ellipse(-132 - tw, -72, 7, 11, 0.1 * tw / 9, 0, TAU); ctx.fill();
    // body
    var bg = ctx.createRadialGradient(-20, -170, 20, -6, -122, 130);
    bg.addColorStop(0, COL.light); bg.addColorStop(.45, COL.base); bg.addColorStop(1, COL.dark);
    ctx.fillStyle = bg; ctx.beginPath(); ctx.ellipse(-6, -122, 110, 82, 0, 0, TAU); ctx.fill();
    // near legs
    leg(ctx, -70, sw, COL.base, hop * 10);
    leg(ctx, 82, -sw, COL.base, hop * 10);
    // ear
    ctx.save(); ctx.translate(76, -178); ctx.rotate(.34 + s.earA);
    var eg = ctx.createLinearGradient(-30, 0, 50, 110); eg.addColorStop(0, COL.base); eg.addColorStop(1, COL.dark);
    ctx.fillStyle = eg; earPath(ctx, 1); ctx.fill();
    var ig = ctx.createLinearGradient(0, 10, 0, 110); ig.addColorStop(0, COL.ear); ig.addColorStop(1, COL.ear2);
    ctx.fillStyle = ig; ctx.save(); ctx.translate(2, 10); ctx.scale(.74, .8); earPath(ctx, 1); ctx.fill(); ctx.restore();
    ctx.restore();
    // head + muzzle
    var hg = ctx.createRadialGradient(100, -190, 6, 118, -150, 70);
    hg.addColorStop(0, COL.light); hg.addColorStop(.5, COL.base); hg.addColorStop(1, COL.dark);
    ctx.fillStyle = hg;
    ctx.beginPath(); ctx.arc(118, -150, 60, 0, TAU); ctx.fill();
    ctx.beginPath(); ctx.ellipse(146, -128, 30, 34, .25, 0, TAU); ctx.fill();
    // trunk
    var pts = trunkPts(), i, p;
    ctx.fillStyle = 'rgba(70,84,128,.55)';
    for (i = pts.length - 1; i >= 0; i--) { p = pts[i]; ctx.beginPath(); ctx.arc(p.x + 3, p.y + 4, p.r, 0, TAU); ctx.fill(); }
    ctx.fillStyle = COL.base;
    for (i = pts.length - 1; i >= 0; i--) { p = pts[i]; ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, TAU); ctx.fill(); }
    ctx.strokeStyle = 'rgba(255,255,255,.2)'; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.lineWidth = 8;
    ctx.beginPath();
    for (i = 0; i < pts.length - 2; i++) { p = pts[i]; var hx = p.x - p.r * .32, hy = p.y - p.r * .38; i ? ctx.lineTo(hx, hy) : ctx.moveTo(hx, hy); }
    ctx.stroke();
    ctx.strokeStyle = 'rgba(70,84,128,.35)'; ctx.lineWidth = 1.6;
    for (i = 3; i < pts.length - 1; i += 2) {
      p = pts[i]; var nx = -Math.sin(p.a), ny = Math.cos(p.a);
      ctx.beginPath(); ctx.moveTo(p.x + nx * p.r * .75, p.y + ny * p.r * .75); ctx.lineTo(p.x - nx * p.r * .75, p.y - ny * p.r * .75); ctx.stroke();
    }
    var tip = pts[pts.length - 1];
    s.tip = { x: tip.x, y: tip.y };
    // tusk
    ctx.fillStyle = COL.tusk; ctx.strokeStyle = 'rgba(120,130,160,.35)'; ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.moveTo(150, -118); ctx.quadraticCurveTo(182, -110, 188, -84); ctx.quadraticCurveTo(170, -98, 146, -104); ctx.closePath(); ctx.fill(); ctx.stroke();
    // face
    var ex = 138, ey = -168, o = clamp(1 - s.blink, 0.05, 1);
    ctx.fillStyle = 'rgba(255,128,160,.42)'; ctx.beginPath(); ctx.ellipse(128, -142, 12, 8, 0, 0, TAU); ctx.fill();
    if (mood === 'joy' || s.joyT > 0) {
      ctx.strokeStyle = COL.eye; ctx.lineWidth = 3.4; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.arc(ex, ey + 4, 7.5, Math.PI * 1.12, Math.PI * 1.88); ctx.stroke();
    } else {
      ctx.fillStyle = COL.eye; ctx.beginPath(); ctx.ellipse(ex, ey, 6.4, 6.9 * o, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(ex + 2.2, ey - 2.4, 2.1, 0, TAU); ctx.fill();
      ctx.beginPath(); ctx.arc(ex - 2, ey + 2.2, 1, 0, TAU); ctx.fill();
    }
    ctx.strokeStyle = 'rgba(40,52,96,.6)'; ctx.lineWidth = 3; ctx.lineCap = 'round';
    if (mood === 'sad') { ctx.beginPath(); ctx.moveTo(128, -182); ctx.lineTo(148, -177); ctx.stroke(); }
    // smile: s.smile -1 (frown) .. 1 (big grin)
    var sm = s.smile;
    ctx.strokeStyle = '#4a5686'; ctx.lineWidth = 3.4;
    ctx.beginPath(); ctx.moveTo(116, -126); ctx.quadraticCurveTo(128, -126 + sm * 20 + 4, 142, -128 - sm * 8); ctx.stroke();
    if (sm > .75) { ctx.lineWidth = 2.4; ctx.beginPath(); ctx.moveTo(142, -128 - sm * 8); ctx.lineTo(145, -134 - sm * 6); ctx.stroke(); }
    ctx.restore();
  }

  function earPath(ctx) {
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.bezierCurveTo(54, -8, 82, 46, 52, 100);
    ctx.bezierCurveTo(34, 134, -24, 128, -38, 88);
    ctx.bezierCurveTo(-56, 38, -36, -2, 0, 0);
    ctx.closePath();
  }

  /* ---------- behaviour ---------- */
  var MOODS = {
    sad:   { smile: -.55, ear: .0,  flap: .15, trunk: 40,  curl: 40,  act: 0 },
    calm:  { smile: .45,  ear: .08, flap: .5,  trunk: 72,  curl: 80,  act: .55 },
    happy: { smile: .85,  ear: .1,  flap: .9,  trunk: 70,  curl: 100, act: 1 },
    joy:   { smile: 1,    ear: .12, flap: 1.5, trunk: 64,  curl: 120, act: 1.7 }
  };

  function place(x, y, sc, bounds) { E.x = x; E.y = y; E.sc = sc; if (bounds) E.bounds = bounds; }
  function walkTo(x, speed, done) { E.target = x; E.speed = speed || 40; E.arrive = done || null; }
  function setMood(m) { E.mood = MOODS[m] ? m : 'calm'; }
  function say(ms) { E.joyT = ms || 1.2; }
  function hop(h) { if (E.hopT < 0 && E.tossT < 0) { E.hopT = 0; E.hopH = h || 34; } }
  function toss() { if (E.tossT < 0 && E.hopT < 0) { E.tossT = 0; E.tossDone = false; } }
  function bonk() { E.bonk = 1; E.blink = 1; }

  function update(dt, env) {
    var s = E, m = MOODS[s.mood] || MOODS.calm;
    s.t += dt; env = env || s.env;
    // walking
    if (s.target != null) {
      var dx = s.target - s.x;
      if (Math.abs(dx) < 3) { s.target = null; s.speed = 0; var cb = s.arrive; s.arrive = null; if (cb) cb(); }
      else { s.dir = dx > 0 ? 1 : -1; s.x += s.dir * s.speed * dt; s.step += dt * s.speed * 0.058; }
    } else s.speed = 0;
    // hop
    if (s.hopT >= 0) {
      s.hopT += dt / 0.62;
      var u = Math.min(1, s.hopT);
      s.yOff = -s.hopH * s.sc * 4 * u * (1 - u);
      s.sq = u < .12 ? u / .12 * .9 : (u > .88 ? (u - .88) / .12 * .9 : (-.35 * Math.sin(u * Math.PI)));
      if (s.hopT >= 1) { s.hopT = -1; s.yOff = 0; s.sq = .8; if (env.onLand) env.onLand(s.x, s.y, 1); }
    } else { s.yOff = 0; s.sq *= Math.pow(.001, dt); }
    // blink
    s.nextBlink -= dt;
    if (s.nextBlink < 0) { s.blink = 1; s.nextBlink = rnd(2.2, 5); }
    s.blink = Math.max(0, s.blink - dt * 7);
    s.joyT = Math.max(0, s.joyT - dt);
    s.bonk = Math.max(0, s.bonk - dt * 2);
    // ears + trunk idle
    var flap = m.flap;
    s.earA = m.ear + (s.mood === 'sad' ? -.08 : Math.sin(s.t * (2.2 + flap * 2.2)) * .1 * (.4 + flap * .6) + .06 + Math.max(0, Math.sin(s.t * .7)) * .05 * flap) + s.bonk * .25;
    var tTh = m.trunk + Math.sin(s.t * 1.3) * 7 + (s.speed ? Math.sin(s.step * 2) * 6 : 0);
    var tCurl = m.curl + Math.sin(s.t * 1.9 + 1) * 18;
    // toss: dip, scoop, swing up, release
    if (s.tossT >= 0) {
      s.tossT += dt / 1.5;
      var q = s.tossT;
      if (q < .3) { var a = q / .3; tTh = lerp(tTh, 96, ease(a)); tCurl = lerp(tCurl, 30, ease(a)); }
      else if (q < .5) { var b = (q - .3) / .2; tTh = lerp(96, 88, b); tCurl = lerp(30, 110, ease(b)); }
      else if (q < .72) { var c = (q - .5) / .22; tTh = lerp(88, 18, ease(c)); tCurl = lerp(110, 190, ease(c)); }
      else { var d = Math.min(1, (q - .72) / .28); tTh = lerp(18, tTh, ease(d)); tCurl = lerp(190, tCurl, ease(d)); }
      if (q > .62 && !s.tossDone) { s.tossDone = true; if (env.onToss && s.tip) env.onToss(world(s.tip.x, s.tip.y), s.dir); }
      if (q >= 1) s.tossT = -1;
    }
    s.trunkTh += (tTh - s.trunkTh) * Math.min(1, dt * (s.tossT >= 0 ? 12 : 4));
    s.trunkCurl += (tCurl - s.trunkCurl) * Math.min(1, dt * (s.tossT >= 0 ? 12 : 4));
    s.smile += (m.smile - s.smile) * Math.min(1, dt * 3);
    // choose something to do
    s.nextAct -= dt;
    if (s.nextAct < 0 && s.target == null && s.hopT < 0 && s.tossT < 0 && !s.frozen) {
      var k = m.act;
      s.nextAct = rnd(1.4, 3.4) / Math.max(.5, k);
      if (k > 0) {
        var r = Math.random();
        if (s.mood === 'joy') { if (r < .38) hop(rnd(30, 46)); else if (r < .7) toss(); else wander(); }
        else if (s.mood === 'happy') { if (r < .22) hop(28); else if (r < .55) toss(); else wander(); }
        else { if (r < .5) wander(); else if (r < .7) toss(); }
      }
    }
  }
  function wander() {
    var b = E.bounds; E.target = rnd(b[0], b[1]); E.speed = rnd(26, 44); E.arrive = null;
  }
  function lerp(a, b, t) { return a + (b - a) * t; }
  function ease(t) { return t * t * (3 - 2 * t); }

  /* local (elephant space) -> world */
  function world(lx, ly) {
    var sx = E.dir * E.sc * (1 + .1 * E.sq), sy = E.sc * (1 - .1 * E.sq);
    return { x: E.x + lx * sx, y: E.y + (E.yOff || 0) + ly * sy };
  }
  /* circles that push balls around: feet, head, trunk tip */
  function colliders() {
    var out = [], sc = E.sc, y = E.yOff || 0;
    [-70, -28, 42, 82].forEach(function (lx) { var w = world(lx, -12); out.push({ x: w.x, y: w.y + y * 0, r: 24 * sc, k: 'foot' }); });
    var h = world(118, -150); out.push({ x: h.x, y: h.y, r: 54 * sc, k: 'head' });
    if (E.tip) { var t = world(E.tip.x, E.tip.y); out.push({ x: t.x, y: t.y, r: 13 * sc, k: 'tip' }); }
    return out;
  }
  function headWorld() { return world(118, -205); }

  window.Elephant = { state: E, draw: function (ctx) { E.y0 = E.y; var oy = E.yOff || 0; E.y += oy; draw(ctx); E.y -= oy; },
    update: update, place: place, walkTo: walkTo, setMood: setMood, hop: hop, toss: toss, bonk: bonk, say: say,
    colliders: colliders, head: headWorld, world: world };
})();
