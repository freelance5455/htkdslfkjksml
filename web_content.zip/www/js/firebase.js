let initializeApp,getApps,getAuth,signInAnonymously,getDatabase,ref,set,get,update,onValue,remove,runTransaction;
let sdkLoaded=false;
async function loadFirebaseSdk(){
  if(sdkLoaded)return;
  const base='https://www.gstatic.com/firebasejs/13.2.0/';
  const [appSdk,authSdk,dbSdk]=await Promise.all([
    import(/* @vite-ignore */ base+'firebase-app.js'),
    import(/* @vite-ignore */ base+'firebase-auth.js'),
    import(/* @vite-ignore */ base+'firebase-database.js')
  ]);
  ({initializeApp,getApps}=appSdk);({getAuth,signInAnonymously}=authSdk);
  ({getDatabase,ref,set,get,update,onValue,remove,runTransaction}=dbSdk);sdkLoaded=true;
}
let app=null,auth=null,db=null,uid=null,code=null,unsub=null,host=false;
const CHARS='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const makeCode=()=>Array.from({length:6},()=>CHARS[Math.floor(Math.random()*CHARS.length)]).join('');
const now=()=>Date.now();
const shuffle=items=>{const a=items.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;};
const safeCard=card=>({
  id:String(card.id||''),name:String(card.name||'Carta'),kind:card.kind||'creature',element:card.element||'Neutro',
  rarity:card.rarity||'Comum',atk:Number(card.atk)||0,def:Number(card.def)||0,hp:Number(card.hp)||0,
  cost:Number(card.cost)||0,ability:card.ability||'none',desc:String(card.desc||'').slice(0,140),
  level:Number(card.level)||1,generated:!!card.generated,zoeira:!!card.zoeira,hasPhoto:!!card.image,image:(typeof card.image==='string'&&card.image.length<=95000)?card.image:''
});
export async function connectFirebase(config){
  await loadFirebaseSdk();
  if(!config?.apiKey||!config?.databaseURL)throw Error('Configuração Firebase incompleta: apiKey e databaseURL são obrigatórios.');
  app=getApps().length?getApps()[0]:initializeApp(config);
  auth=getAuth(app);db=getDatabase(app);
  if(!auth.currentUser){const result=await signInAnonymously(auth);uid=result.user.uid;}else uid=auth.currentUser.uid;
  return {uid};
}
function need(){if(!db||!uid)throw Error('Conecte o Firebase primeiro.');}
function roomPath(suffix=''){need();if(!code)throw Error('Nenhuma sala ativa.');return 'rooms/'+code+(suffix?'/'+suffix:'');}
export const myUid=()=>uid;
export const roomCode=()=>code;
export const isHost=()=>host;
export async function createRoom({name,deck}){
  need();if(!Array.isArray(deck)||deck.length!==24)throw Error('O deck precisa ter 24 cartas.');
  if(code)await leaveRoom();
  let newCode=null;
  for(let attempt=0;attempt<8;attempt++){const candidate=makeCode();const existing=await get(ref(db,'rooms/'+candidate+'/public'));if(!existing.exists()){newCode=candidate;break;}}
  if(!newCode)throw Error('Não foi possível reservar um código de sala. Tente novamente.');
  code=newCode;host=true;
  const cards=shuffle(deck.map(safeCard)),privateData={hand:cards.slice(0,5),drawPile:cards.slice(5),lastDrawnTurn:0,hasTakenTurn:false,fatigue:0};
  const room={public:{hostUid:uid,createdAt:now(),phase:'lobby',members:{[uid]:{name:String(name||'Duelista').slice(0,24),ready:true,deckSize:24,joinedAt:now()}},game:null},private:{[uid]:privateData}};
  try{await set(ref(db,roomPath()),room);}catch(error){code=null;host=false;throw error;}
  return {code,host:true};
}
export async function joinRoom(roomCodeValue,{name,deck}){
  need();if(!Array.isArray(deck)||deck.length!==24)throw Error('O deck precisa ter 24 cartas.');
  if(code)await leaveRoom();
  const candidate=String(roomCodeValue||'').toUpperCase().replace(/[^A-Z0-9]/g,'');
  if(candidate.length!==6)throw Error('O código precisa ter 6 caracteres.');
  const base='rooms/'+candidate;
  const roomSnap=await get(ref(db,base+'/public'));
  if(!roomSnap.exists())throw Error('Sala não encontrada.');
  const publicRoom=roomSnap.val()||{};
  if(publicRoom.phase!=='lobby')throw Error('Esta sala não está mais aceitando jogadores.');
  const members=publicRoom.members||{};
  if(Object.keys(members).length>=2)throw Error('Esta sala já está cheia.');
  if(members[uid])throw Error('Você já está nesta sala.');
  code=candidate;host=false;
  const memberRef=ref(db,base+'/public/members/'+uid);
  try{
    await set(memberRef,{name:String(name||'Duelista 2').slice(0,24),ready:true,deckSize:24,joinedAt:now()});
    const cards=shuffle(deck.map(safeCard));
    await set(ref(db,base+'/private/'+uid),{hand:cards.slice(0,5),drawPile:cards.slice(5),lastDrawnTurn:0,hasTakenTurn:false,fatigue:0});
  }catch(error){try{await remove(memberRef);}catch{}code=null;host=false;throw error;}
  return {code,host:false};
}
export function listenRoom(callback){
  need();if(!code)throw Error('Nenhuma sala ativa.');if(unsub)unsub();
  unsub=onValue(ref(db,roomPath('public')),snapshot=>callback(snapshot.val()||null),error=>callback({error:error.message}));
  return unsub;
}
export async function startOnlineMatch(){
  need();if(!code||!host)throw Error('Somente quem criou a sala pode iniciar.');
  const publicSnap=await get(ref(db,roomPath('public'))),pub=publicSnap.val();
  if(!pub||pub.phase!=='lobby')throw Error('A sala não está no lobby.');
  const ids=Object.keys(pub.members||{});
  if(ids.length!==2)throw Error('A sala precisa ter dois jogadores.');
  if(ids.some(id=>!pub.members[id].ready))throw Error('Os dois duelistas precisam preparar os decks.');
  const players={};
  for(let i=0;i<ids.length;i++){
    const id=ids[i];
    // The host must never read the guest's private hand or draw pile.
    players[id]={uid:id,name:pub.members[id].name||('Duelista '+(i+1)),life:100,maxLife:100,energy:id===pub.hostUid?3:2,maxEnergy:10,active:null,bench:[],deckCount:19,handCount:5,graveCount:0,shield:0,reflect:0,trap:null,status:[],boost:0,defBoost:0,stun:0,usedAbility:false,attacked:false,attacksUsed:0,bonusAttacks:0,equipment:[],lastAbility:null,revived:false,doubleNext:false};
  }
  await set(ref(db,roomPath('public/game')),{phase:'playing',turnUid:pub.hostUid,turn:1,players,log:'A partida começou! É a vez do anfitrião.',winner:null,updatedAt:now()});
  await set(ref(db,roomPath('public/phase')),'playing');return true;
}
export async function getOwnPrivate(){need();const snapshot=await get(ref(db,roomPath('private/'+uid)));return snapshot.val()||null;}
async function transactGame(updateFn){
  need();const gameRef=ref(db,roomPath('public/game'));
  const result=await runTransaction(gameRef,current=>{
    if(!current||current.phase!=='playing'||current.winner||current.turnUid!==uid)return;
    return updateFn(current);
  });
  if(!result.committed)throw Error('Não é seu turno ou a partida já terminou. Atualize a sala.');
  return result.snapshot.val();
}
function opponentOf(game){const id=Object.keys(game.players||{}).find(playerId=>playerId!==uid);if(!id)throw Error('O adversário não está na sala.');return game.players[id];}
function onlineDamage(target,amount,source){
  let damage=Math.max(0,Math.round(Number(amount)||0));
  if(target.shield>0){const block=Math.min(target.shield,damage);target.shield-=block;damage-=block;}
  if(target.reflect>0&&damage>0){const reflected=Math.min(target.reflect,damage);target.reflect=0;source.life-=reflected;}
  if(target.active&&damage>0){target.active.currentHp-=damage;if(target.active.currentHp<=0){const dead=target.active;if(dead.ability==='revive'&&!target.revived){target.revived=true;target.active={...dead,currentHp:Math.max(1,Math.ceil(dead.hp*.35)),revived:true};}else{target.active=null;target.graveCount=(target.graveCount||0)+1;target.life-=12;}}}
  else if(damage>0)target.life-=damage;
  return damage;
}
function onlineStatus(target,type,turns,value){target.status=Array.isArray(target.status)?target.status:[];target.status=target.status.filter(item=>item.type!==type);target.status.push({type,turns,value});}
function useOnlineEffect(me,enemy,card,ability=card.ability){
  switch(ability){
    case'heal':me.life=Math.min(me.maxLife,me.life+25);break;
    case'mend':me.life=Math.min(me.maxLife,me.life+30);break;
    case'burn':onlineStatus(enemy,'burn',2,15);break;
    case'shield':me.shield+=35;break;
    case'drain':onlineDamage(enemy,20,me);me.life=Math.min(me.maxLife,me.life+20);break;
    case'rage':me.boost+=30;break;
    case'stun':enemy.stun=1;break;
    case'draw':return 2;
    case'poison':onlineStatus(enemy,'poison',3,10);break;
    case'reflect':me.reflect+=25;break;
    case'double':me.doubleNext=true;break;
    case'steal':{const n=Math.min(2,enemy.energy);enemy.energy-=n;me.energy=Math.min(me.maxEnergy,me.energy+n);break;}
    case'pierce':onlineDamage(enemy,(me.active?.atk||card.atk||40)+(me.active?.level||1)*4-(enemy.active?.def||0)*.1,me);break;
    case'freeze':onlineStatus(enemy,'freeze',2,25);break;
    case'cleanse':me.status=(me.status||[]).filter(s=>!['burn','poison','weaken','freeze'].includes(s.type));break;
    case'guard':me.defBoost+=35;me.shield+=15;break;
    case'haste':me.bonusAttacks=Math.max(me.bonusAttacks||0,1);break;
    case'weaken':onlineStatus(enemy,'weaken',2,20);break;
    case'copy':if(enemy.lastAbility&&enemy.lastAbility!=='copy'&&enemy.lastAbility!=='revive'&&enemy.lastAbility!=='none')return useOnlineEffect(me,enemy,me.active,enemy.lastAbility);me.shield+=15;break;
    case'fireball':onlineDamage(enemy,35,me);break;
    case'equipBlade':if(!me.active)throw Error('Equipe uma criatura antes da lâmina.');me.active.atk+=25;(me.equipment||(me.equipment=[])).push('Lâmina Prisma');break;
    case'equipArmor':if(!me.active)throw Error('Equipe uma criatura antes da armadura.');me.active.def+=30;me.active.currentHp+=20;me.active.hp+=20;(me.equipment||(me.equipment=[])).push('Armadura de Casca');break;
    case'trapSpike':if(me.trap)throw Error('Você já tem uma armadilha preparada.');me.trap={type:'spike',name:'Espinhos Ocultos'};break;
    case'trapMirror':if(me.trap)throw Error('Você já tem uma armadilha preparada.');me.trap={type:'mirror',name:'Espelho Quebrado'};break;
    case'boostTeam':if(!me.active)throw Error('Você precisa de uma criatura ativa.');me.active.atk+=15;me.active.def+=15;break;
    case'chaos':{const picks=['heal','burn','shield','fireball','poison','rage'];return useOnlineEffect(me,enemy,card,picks[Math.floor(Math.random()*picks.length)]);}
    case'none':case'revive':throw Error('Esta habilidade é passiva e não pode ser ativada.');
    default:throw Error('Habilidade não reconhecida.');
  }
  me.lastAbility=ability;return 0;
}
async function changePrivateAfterCard(index,drawAmount=0){
  const privateRef=ref(db,roomPath('private/'+uid));
  const result=await runTransaction(privateRef,current=>{
    if(!current||!Array.isArray(current.hand)||!current.hand[index])return;
    const hand=current.hand.slice();hand.splice(index,1);
    const drawPile=(current.drawPile||[]).slice();for(let i=0;i<drawAmount&&drawPile.length&&hand.length<8;i++)hand.push(drawPile.shift());
    return {...current,hand,drawPile};
  });
  if(!result.committed)throw Error('Não foi possível atualizar sua mão.');
  const priv=result.snapshot.val();try{await update(ref(db,roomPath('public/game/players/'+uid)),{handCount:(priv.hand||[]).length,deckCount:(priv.drawPile||[]).length});}catch(error){if(!error?.message?.toLowerCase().includes('permission')&&error?.code!=='PERMISSION_DENIED')throw error;}
  return priv;
}
export async function onlinePlayCard(index){
  const priv=await getOwnPrivate();const card=priv?.hand?.[index];if(!card)throw Error('Carta não encontrada na sua mão.');let drawAmount=0;
  const game=await transactGame(current=>{
    const me=current.players[uid],enemy=opponentOf(current);if(me.stun>0)throw Error('Você está atordoado: passe o turno.');
    if(card.cost>me.energy)throw Error('Energia insuficiente.');
    if(card.kind==='creature'){
      if(me.active&&me.bench.length>=2)throw Error('Campo e banco cheios.');
      me.energy-=card.cost;const instance={...card,currentHp:card.hp};if(!me.active)me.active=instance;else me.bench.push(instance);
    }else{
      if(card.kind==='gear'&&!me.active)throw Error('Equipe uma criatura antes de usar equipamento.');
      if(card.kind==='trap'&&me.trap)throw Error('Você já tem uma armadilha preparada.');
      me.energy-=card.cost;drawAmount=useOnlineEffect(me,enemy,card)||0;
      if(me.active&&me.active.element===card.element){me.active.atk+=5;me.shield+=5;}
    }
    current.log=me.name+' jogou '+card.name+'.';current.updatedAt=now();if(enemy.life<=0)current.winner=uid;else if(me.life<=0)current.winner=Object.keys(current.players).find(id=>id!==uid);return current;
  });
  await changePrivateAfterCard(index,drawAmount);return game;
}
export async function onlineSwitchBench(index){
  return transactGame(current=>{const me=current.players[uid];if(me.stun>0)throw Error('Você está atordoado.');if(!me.bench?.[index])throw Error('Não há carta nesta posição do banco.');if(me.energy<1)throw Error('Precisa de 1 energia para trocar.');me.energy--;const old=me.active;me.active=me.bench.splice(index,1)[0];if(old)me.bench.push(old);current.log=me.name+' fez uma troca tática.';current.updatedAt=now();return current;});
}
export async function onlineAttack(){
  return transactGame(current=>{
    const me=current.players[uid],enemy=opponentOf(current);if(me.stun>0)throw Error('Você está atordoado.');if(!me.active)throw Error('Invoque uma criatura.');if((me.attacksUsed||0)>=1+(me.bonusAttacks||0))throw Error('Você já atacou neste turno.');
    const bonus={Flora:{Chama:-8,Terra:10},Chama:{Flora:12,Maré:-10},Maré:{Chama:12,Raio:-10},Raio:{Maré:12,Terra:-8},Terra:{Raio:8,Flora:-8},Sombra:{Luz:-10,Arcano:8},Luz:{Sombra:12,Arcano:-5},Arcano:{Terra:5,Neutro:5}};
    const elemental=bonus[me.active.element]?.[enemy.active?.element]||0;
    const weaken=(me.status||[]).find(s=>s.type==='weaken')?.value||0,freeze=(me.status||[]).find(s=>s.type==='freeze')?.value||0;
    let amount=Math.max(8,me.active.atk+(me.boost||0)-weaken-freeze+elemental-(enemy.active?(enemy.active.def+(enemy.defBoost||0))*.25:0));
    if(enemy.trap){const trap=enemy.trap;enemy.trap=null;if(trap.type==='spike'){onlineDamage(me,30,enemy);if(!me.active||me.life<=0){current.winner=Object.keys(current.players).find(id=>id!==uid);current.updatedAt=now();return current;}}if(trap.type==='mirror')enemy.reflect+=40;}
    onlineDamage(enemy,amount,me);if(me.doubleNext){onlineDamage(enemy,amount*.6,me);me.doubleNext=false;}
    me.attacksUsed=(me.attacksUsed||0)+1;me.attacked=me.attacksUsed>=1+(me.bonusAttacks||0);current.log=me.name+' atacou e causou '+Math.round(amount)+' de dano.'+(elemental>0?' Vantagem elemental!':'');
    if(enemy.life<=0)current.winner=uid;else if(me.life<=0)current.winner=Object.keys(current.players).find(id=>id!==uid);current.updatedAt=now();return current;
  });
}
export async function onlineAbility(){
  const gameBefore=await get(ref(db,roomPath('public/game')));const before=gameBefore.val();const active=before?.players?.[uid]?.active;if(!active)throw Error('Sem criatura ativa.');const ability=active.ability;const passive=['none','revive'].includes(ability);if(passive)throw Error('Esta habilidade é passiva.');let drawAmount=0;
  const game=await transactGame(current=>{
    const me=current.players[uid],enemy=opponentOf(current);if(me.stun>0)throw Error('Você está atordoado.');if(!me.active)throw Error('Sem criatura ativa.');if(me.usedAbility)throw Error('Habilidade já usada neste turno.');
    const costs={drain:2,stun:2,double:2,haste:2,copy:2};const cost=costs[ability]||ABILITIES_COST(ability);if(me.energy<cost)throw Error('Energia insuficiente para esta habilidade.');me.energy-=cost;drawAmount=useOnlineEffect(me,enemy,me.active,ability);me.usedAbility=true;current.log=me.name+' ativou '+(ability||'uma habilidade')+'.';if(enemy.life<=0)current.winner=uid;else if(me.life<=0)current.winner=Object.keys(current.players).find(id=>id!==uid);current.updatedAt=now();return current;
  });
  if(drawAmount){await drawExtra(drawAmount);}
  return game;
}
function ABILITIES_COST(key){return ({heal:1,burn:1,shield:1,rage:1,draw:1,poison:1,reflect:1,steal:1,pierce:1,freeze:1,cleanse:1,guard:1,weaken:1,fireball:2})[key]??1;}
async function drawExtra(amount){
  const privateRef=ref(db,roomPath('private/'+uid));const result=await runTransaction(privateRef,current=>{if(!current)return;const hand=(current.hand||[]).slice(),pile=(current.drawPile||[]).slice();for(let i=0;i<amount&&pile.length&&hand.length<8;i++)hand.push(pile.shift());return {...current,hand,drawPile:pile};});
  if(result.committed){const priv=result.snapshot.val();try{await update(ref(db,roomPath('public/game/players/'+uid)),{handCount:(priv.hand||[]).length,deckCount:(priv.drawPile||[]).length});}catch(error){if(!error?.message?.toLowerCase().includes('permission')&&error?.code!=='PERMISSION_DENIED')throw error;}}
}
export async function onlineEndTurn(){
  return transactGame(current=>{
    const me=current.players[uid],nextId=Object.keys(current.players).find(id=>id!==uid),next=current.players[nextId];
    me.stun=0;me.attacked=false;me.attacksUsed=0;me.bonusAttacks=0;me.usedAbility=false;
    next.energy=Math.min(next.maxEnergy||10,(next.energy||0)+1);next.attacked=false;next.attacksUsed=0;next.bonusAttacks=0;next.usedAbility=false;next.boost=Math.max(0,(next.boost||0)-30);next.defBoost=Math.max(0,(next.defBoost||0)-35);next.doubleNext=false;
    const keep=[];for(const status of next.status||[]){if(status.type==='burn'||status.type==='poison')next.life-=status.value;status.turns--;if(status.turns>0)keep.push(status);}next.status=keep;
    current.turnUid=nextId;current.turn=(current.turn||1)+1;current.log='Turno de '+next.name+'.';if(next.life<=0)current.winner=uid;current.updatedAt=now();return current;
  });
}
export async function onlineDrawForTurn(turnNumber){
  need();const privateRef=ref(db,roomPath('private/'+uid));
  const result=await runTransaction(privateRef,current=>{
    if(!current||Number(current.lastDrawnTurn||0)>=Number(turnNumber))return;
    const hand=(current.hand||[]).slice(),pile=(current.drawPile||[]).slice();
    if(current.hasTakenTurn&&pile.length&&hand.length<8)hand.push(pile.shift());
    return {...current,hand,drawPile:pile,hasTakenTurn:true,lastDrawnTurn:Number(turnNumber)};
  });
  if(result.committed){const priv=result.snapshot.val();try{await update(ref(db,roomPath('public/game/players/'+uid)),{handCount:(priv.hand||[]).length,deckCount:(priv.drawPile||[]).length});}catch(error){if(!error?.message?.toLowerCase().includes('permission')&&error?.code!=='PERMISSION_DENIED')throw error;}}
}
export async function leaveRoom(){
  if(unsub){unsub();unsub=null;}
  if(db&&code&&uid){try{
    if(host){await set(ref(db,roomPath('public/phase')),'closed');}
    await remove(ref(db,roomPath('public/members/'+uid)));await remove(ref(db,roomPath('private/'+uid)));
  }catch(error){console.warn('Falha ao sair da sala:',error.message);}}
  code=null;host=false;
}
export function disconnectFirebase(){if(unsub){unsub();unsub=null;}}
