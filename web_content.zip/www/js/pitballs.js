/* Detox balls: glossy sprites + a small 2D physics world (grid-hashed circles). */
(function () {
  'use strict';
  var BLUE = ['#2f6bff', '#4f8bff', '#79b4ff', '#1f4fe0', '#a9d2ff', '#3a9bff'];
  var YELLOW = ['#ffc933', '#ffd95e', '#ffb21f', '#ffe58a'];
  var G = 1500, REST = .32, CAP = 210, LINE = 1e9;
  var list = [], queue = [], W = 0, H = 0, P = { left: 0, right: 0, floor: 0, top: 0 };
  var sprites = {}, grid = {}, hooks = {};
  var rnd = function (a, b) { return a + Math.random() * (b - a); };

  function hex(c) { return [parseInt(c.substr(1, 2), 16), parseInt(c.substr(3, 2), 16), parseInt(c.substr(5, 2), 16)]; }
  function shade(c, a) {
    var v = hex(c).map(function (x) { return Math.round(a >= 0 ? x + (255 - x) * a : x * (1 + a)); });
    return 'rgb(' + v.join(',') + ')';
  }
  function sprite(c) {
    if (sprites[c]) return sprites[c];
    var s = 96, cv = document.createElement('canvas'); cv.width = cv.height = s;
    var x = cv.getContext('2d');
    var g = x.createRadialGradient(36, 30, 3, 50, 50, 50);
    g.addColorStop(0, shade(c, .6)); g.addColorStop(.32, shade(c, .12)); g.addColorStop(.7, c); g.addColorStop(1, shade(c, -.5));
    x.fillStyle = g; x.beginPath(); x.arc(48, 48, 46, 0, 6.2832); x.fill();
    var rim = x.createRadialGradient(62, 70, 8, 62, 70, 40); rim.addColorStop(0, 'rgba(255,255,255,.28)'); rim.addColorStop(1, 'rgba(255,255,255,0)');
    x.fillStyle = rim; x.beginPath(); x.arc(48, 48, 46, 0, 6.2832); x.fill();
    x.save(); x.translate(33, 25); x.rotate(-.55);
    var h = x.createRadialGradient(0, 0, 1, 0, 0, 16); h.addColorStop(0, 'rgba(255,255,255,.95)'); h.addColorStop(1, 'rgba(255,255,255,0)');
    x.scale(1, .55); x.fillStyle = h; x.beginPath(); x.arc(0, 0, 16, 0, 6.2832); x.fill(); x.restore();
    x.strokeStyle = 'rgba(0,0,40,.18)'; x.lineWidth = 1.5; x.beginPath(); x.arc(48, 48, 45.2, 0, 6.2832); x.stroke();
    return (sprites[c] = cv);
  }
  function pick(fam) { var a = fam === 'y' ? YELLOW : BLUE; return a[(Math.random() * a.length) | 0]; }

  function init(w, h, pit, o) {
    W = w; H = h; P = pit; list = []; queue = []; hooks = o || {};
    var r = 11.6 * (pit.scale || 1), rows = Math.floor((pit.floor - pit.top - 6) / (r * 1.78)), per = Math.floor((pit.right - pit.left) / (r * 2.04));
    CAP = Math.max(40, Math.floor(rows * per * .93));
  }
  function setLine(y) { LINE = y; }
  function capacity() { return CAP; }
  function mk(x, y, fam, r) {
    return { x: x, y: y, vx: 0, vy: 0, r: r || rnd(10.6, 12.8) * (P.scale || 1), c: pick(fam), f: fam, z: Math.random() < .5 ? 0 : 1, die: 0 };
  }
  function counts() {
    var b = 0, y = 0;
    for (var i = 0; i < list.length; i++) { if (list[i].die) continue; if (list[i].f === 'y') y++; else b++; }
    return { b: b, y: y };
  }

  /* instant, pre-settled pile (rows from the floor up) */
  function fill(nb, ny) {
    list = []; queue = [];
    var total = nb + ny; if (total > CAP) { nb = Math.round(nb * CAP / total); ny = CAP - nb; total = CAP; }
    var fams = []; for (var i = 0; i < nb; i++) fams.push('b'); for (i = 0; i < ny; i++) fams.push('y');
    for (i = fams.length - 1; i > 0; i--) { var j = (Math.random() * (i + 1)) | 0, t = fams[i]; fams[i] = fams[j]; fams[j] = t; }
    var r = 11.6 * (P.scale || 1), step = r * 2.04, row = 0, k = 0;
    while (k < total && row < 60) {
      var off = row % 2 ? r : 0, y = P.floor - r - row * r * 1.78;
      for (var x = P.left + r + off + 1; x < P.right - r && k < total; x += step) { var b = mk(x + rnd(-1.4, 1.4), y + rnd(-1, 1), fams[k++]); list.push(b); }
      row++;
    }
    for (i = 0; i < 24; i++) step_(1 / 60, []);
    for (i = 0; i < list.length; i++) { list[i].vx = list[i].vy = 0; }
  }

  /* schedule balls to fall from (x,y) starting after `delay` seconds */
  function rain(fam, n, x, y, delay, gap) {
    for (var i = 0; i < n; i++) queue.push({ t: (delay || 0) + i * (gap || .11) + rnd(0, .05), fam: fam, x: x + rnd(-8, 8), y: y, vx: rnd(-55, 55), vy: rnd(40, 130) });
    queue.sort(function (a, b) { return a.t - b.t; });
  }
  function pending() { return queue.length; }

  function top() {
    var best = null;
    for (var i = 0; i < list.length; i++) { var b = list[i]; if (!b.die && (!best || b.y < best.y)) best = b; }
    return best;
  }
  /* relapse: the highest ball floats up and fades */
  function removeTop(fam) {
    var best = null;
    for (var i = 0; i < list.length; i++) { var b = list[i]; if (!b.die && (!fam || b.f === fam) && (!best || b.y < best.y)) best = b; }
    if (!best) return null;
    best.die = .001; best.vx = 0; best.vy = 0; best.z = 1;
    return { x: best.x, y: best.y };
  }
  function kick(x, y, power, rad) {
    for (var i = 0; i < list.length; i++) {
      var b = list[i], dx = b.x - x, dy = b.y - y, d = Math.sqrt(dx * dx + dy * dy);
      if (d < rad && !b.die) { var f = (1 - d / rad) * power; b.vx += dx / (d || 1) * f * rnd(.5, 1.1); b.vy += Math.min(0, dy / (d || 1)) * f - f * .35; }
    }
  }
  function launch(x, y, vx, vy) {
    var best = null, bd = 1e9;
    for (var i = 0; i < list.length; i++) { var b = list[i]; if (b.die) continue; var d = (b.x - x) * (b.x - x) + (b.y - y) * (b.y - y); if (d < bd) { bd = d; best = b; } }
    if (best && bd < 70 * 70) { best.vx = vx; best.vy = vy; best.y -= 4; return best; }
    return null;
  }

  function step_(dt, cols) {
    var i, j, b, n = list.length, sub = 2, L = P.left, R = P.right, F = P.floor;
    dt /= sub;
    for (var s = 0; s < sub; s++) {
      for (i = 0; i < n; i++) {
        b = list[i];
        if (b.die) continue;
        b.vy += G * dt; b.x += b.vx * dt; b.y += b.vy * dt;
        if (b.x < L + b.r) { b.x = L + b.r; b.vx = -b.vx * REST; }
        else if (b.x > R - b.r) { b.x = R - b.r; b.vx = -b.vx * REST; }
        if (b.y > F - b.r) { b.y = F - b.r; b.vy = Math.abs(b.vy) > 90 ? -b.vy * REST : 0; b.vx *= .88; }
        b.vx *= .9985;
        if (b.vx > 1300) b.vx = 1300; else if (b.vx < -1300) b.vx = -1300;
        if (b.vy > 1500) b.vy = 1500; else if (b.vy < -1300) b.vy = -1300;
      }
      for (var pass = 0; pass < 2; pass++) {
        grid = {};
        for (i = 0; i < n; i++) { b = list[i]; if (b.die) continue; var key = ((b.x / 26) | 0) + ((b.y / 26) | 0) * 1000; (grid[key] = grid[key] || []).push(i); }
        for (i = 0; i < n; i++) {
          b = list[i]; if (b.die) continue;
          var cx = (b.x / 26) | 0, cy = (b.y / 26) | 0;
          for (var gx = -1; gx <= 1; gx++) for (var gy = -1; gy <= 1; gy++) {
            var cell = grid[(cx + gx) + (cy + gy) * 1000]; if (!cell) continue;
            for (var q = 0; q < cell.length; q++) {
              j = cell[q]; if (j <= i) continue;
              var o = list[j], dx = o.x - b.x, dy = o.y - b.y, rr = b.r + o.r, d2 = dx * dx + dy * dy;
              if (d2 >= rr * rr || d2 === 0) continue;
              var d = Math.sqrt(d2), ov = (rr - d) / 2, nx = dx / d, ny = dy / d;
              b.x -= nx * ov; b.y -= ny * ov; o.x += nx * ov; o.y += ny * ov;
              var vn = (b.vx - o.vx) * nx + (b.vy - o.vy) * ny;
              if (vn > 0) { var imp = -(1 + REST) * vn / 2; b.vx += imp * nx; b.vy += imp * ny; o.vx -= imp * nx; o.vy -= imp * ny; }
            }
          }
          if (b.y > F - b.r) b.y = F - b.r;
        }
      }
      for (var c = 0; c < cols.length; c++) {
        var C = cols[c];
        for (i = 0; i < n; i++) {
          b = list[i]; if (b.die) continue;
          var ddx = b.x - C.x, ddy = b.y - C.y, mr = b.r + C.r, dd2 = ddx * ddx + ddy * ddy;
          if (dd2 >= mr * mr) continue;
          var dd = Math.sqrt(dd2) || .01, nnx = ddx / dd, nny = ddy / dd;
          b.x = C.x + nnx * mr; b.y = C.y + nny * mr;
          var rel = (b.vx - (C.vx || 0)) * nnx + (b.vy - (C.vy || 0)) * nny;
          if (rel < 0) { b.vx -= (1 + .45) * rel * nnx; b.vy -= (1 + .45) * rel * nny; }
          b.vx += (C.vx || 0) * .35; b.vy += Math.min(0, (C.vy || 0)) * .35;
          if (hooks.onHit && C.k === 'head' && b.vy > 60 && !b.hit) { b.hit = 1; hooks.onHit(C.k, b); }
          if (b.y > F - b.r) b.y = F - b.r;
        }
      }
    }
  }

  function step(dt, cols) {
    var i, b;
    // queued drops
    if (queue.length) {
      for (i = 0; i < queue.length; i++) queue[i].t -= dt;
      while (queue.length && queue[0].t <= 0) {
        var q = queue.shift(), nb = mk(q.x, q.y, q.fam); nb.vx = q.vx; nb.vy = q.vy; nb.z = 1;
        if (list.length >= CAP) { for (i = 0; i < list.length; i++) if (!list[i].die) { list.splice(i, 1); break; } }
        list.push(nb); if (hooks.onSpawn) hooks.onSpawn(nb);
      }
    }
    step_(dt, cols);
    for (i = list.length - 1; i >= 0; i--) {
      b = list[i];
      if (b.die) { b.die += dt * 1.1; b.y -= 70 * dt * (1 + b.die); b.x += Math.sin(b.die * 9) * 22 * dt; if (b.die >= 1) { if (hooks.onGone) hooks.onGone(b); list.splice(i, 1); } }
      else if (b.vy > 50 || b.vy < -50) b.z = b.z;
    }
  }

  function draw(ctx, z) {
    for (var i = 0; i < list.length; i++) {
      var b = list[i];
      if ((b.die ? 1 : (b.y < P.top - 4 ? 2 : (b.y > LINE ? 1 : 0))) !== z) continue;
      var r = b.r, sp = sprite(b.c);
      if (b.die) {
        var a = 1 - b.die, rr = r * (1 + b.die * .25);
        ctx.globalAlpha = Math.max(0, a); ctx.drawImage(sp, b.x - rr, b.y - rr, rr * 2, rr * 2);
        ctx.globalAlpha = Math.max(0, a) * Math.min(1, b.die * 3) * .75; ctx.fillStyle = '#9b5cff';
        ctx.beginPath(); ctx.arc(b.x, b.y, rr, 0, 6.2832); ctx.fill(); ctx.globalAlpha = 1;
      } else ctx.drawImage(sp, b.x - r, b.y - r, r * 2, r * 2);
    }
  }

  window.Balls = { init: init, fill: fill, rain: rain, pending: pending, removeTop: removeTop, kick: kick, launch: launch,
    step: step, draw: draw, counts: counts, top: top, sprite: sprite, shade: shade, setLine: setLine, capacity: capacity, BLUE: BLUE, YELLOW: YELLOW, CAP: CAP,
    size: function () { return list.length; }, _list: function () { return list; } };
})();
