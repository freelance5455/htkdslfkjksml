import {DB,saveDB,missionProgress,ABILITIES,ELEMENT_BONUS,makeRandomCard,uid} from './data.js';

let G=null;
const clone=value=>JSON.parse(JSON.stringify(value));
const shuffle=items=>{const a=items.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;};
const PASSIVE_ABILITIES=new Set(['none','revive']);
const ACTION_KINDS=new Set(['spell','gear','trap','support']);

function freshSide(name,deck,id,life=100,energy=2){
  return {uid:id,name,life,maxLife:life,energy,maxEnergy:10,deck:shuffle(deck.map(clone)),hand:[],active:null,bench:[],grave:[],status:[],shield:0,reflect:0,trap:null,equipment:[],boost:0,defBoost:0,stun:0,attacked:false,attacksUsed:0,bonusAttacks:0,usedAbility:false,revived:false,lastAbility:null,drawn:0,fatigue:0,hasTakenTurn:false,doubleNext:false};
}
function draw(side){
  if(side.hand.length>=8)return false;
  if(side.deck.length){side.hand.push(side.deck.pop());side.drawn++;return true;}
  side.fatigue++;side.life-=5*side.fatigue;return false;
}
function log(message){if(!G)return;G.log=message;G.actions++;}
function checkEnd(){if(!G||G.winner)return;if(G.sides.p1.life<=0)finish('p2');else if(G.sides.p2.life<=0)finish('p1');else if(G.turn>G.turnLimit)finish(G.sides.p1.life>=G.sides.p2.life?'p1':'p2');}
function addStatus(target,type,turns,value){target.status=target.status.filter(item=>item.type!==type);target.status.push({type,turns,value});}
function dealDamage(target,amount,source){
  let damage=Math.max(0,Math.round(Number(amount)||0));
  if(target.shield>0&&damage>0){const absorbed=Math.min(target.shield,damage);target.shield-=absorbed;damage-=absorbed;}
  if(target.reflect>0&&damage>0&&source){const reflected=Math.min(target.reflect,damage);target.reflect=0;source.life-=reflected;log('Reflexo devolveu '+reflected+' de dano!');}
  if(target.active&&damage>0){target.active.currentHp-=damage;if(target.active.currentHp<=0){const fallen=target.active;target.grave.push(fallen);target.active=null;if(fallen.boss){target.life=0;log('O CHEFE '+fallen.name+' foi derrotado!');}else if(fallen.ability==='revive'&&!target.revived){target.revived=true;target.active={...fallen,currentHp:Math.max(1,Math.ceil(fallen.hp*.35)),revived:true};log(fallen.name+' renasceu com Último Fôlego!');}else{target.life-=12;log(fallen.name+' foi derrotada: -12 PV do duelista.');}}}
  else if(damage>0)target.life-=damage;
  checkEnd();return damage;
}
function abilityEffect(user,target,card,ability=card?.ability){
  const active=user.active;
  switch(ability){
    case 'heal': user.life=Math.min(user.maxLife,user.life+25);break;
    case 'mend': user.life=Math.min(user.maxLife,user.life+30);break;
    case 'burn': addStatus(target,'burn',2,15);break;
    case 'shield': user.shield+=35;break;
    case 'drain': dealDamage(target,20,user);user.life=Math.min(user.maxLife,user.life+20);break;
    case 'rage': user.boost+=30;break;
    case 'stun': target.stun=1;break;
    case 'draw': draw(user);draw(user);break;
    case 'poison': addStatus(target,'poison',3,10);break;
    case 'reflect': user.reflect+=25;break;
    case 'double': user.doubleNext=true;break;
    case 'steal': {const amount=Math.min(2,target.energy);target.energy-=amount;user.energy=Math.min(user.maxEnergy,user.energy+amount);break;}
    case 'pierce': if(target.active){const raw=(active?.atk||card?.atk||40)+(active?.level||1)*4-target.active.def*.1;dealDamage(target,raw,user);}else dealDamage(target,active?.atk||card?.atk||40,user);break;
    case 'freeze': addStatus(target,'freeze',2,25);break;
    case 'cleanse': user.status=user.status.filter(s=>!['burn','poison','weaken','freeze'].includes(s.type));break;
    case 'guard': user.defBoost+=35;user.shield+=15;break;
    case 'haste': user.bonusAttacks=Math.max(user.bonusAttacks,1);break;
    case 'weaken': addStatus(target,'weaken',2,20);break;
    case 'copy': if(target.lastAbility&&!PASSIVE_ABILITIES.has(target.lastAbility)&&target.lastAbility!=='copy')abilityEffect(user,target,active,target.lastAbility);else user.shield+=15;break;
    case 'fireball': dealDamage(target,35,user);break;
    case 'equipBlade': if(!active)throw Error('Equipe uma criatura antes de usar a lâmina.');active.atk+=25;user.equipment.push('Lâmina Prisma');break;
    case 'equipArmor': if(!active)throw Error('Equipe uma criatura antes da armadura.');active.def+=30;active.currentHp+=20;active.hp+=20;user.equipment.push('Armadura de Casca');break;
    case 'trapSpike': if(user.trap)throw Error('Você já preparou uma armadilha.');user.trap={type:'spike',name:'Espinhos Ocultos'};break;
    case 'trapMirror': if(user.trap)throw Error('Você já preparou uma armadilha.');user.trap={type:'mirror',name:'Espelho Quebrado'};break;
    case 'boostTeam': if(!active)throw Error('Você precisa de uma criatura no campo.');active.atk+=15;active.def+=15;break;
    case 'chaos': {const effects=['heal','burn','shield','fireball','poison','rage'];const selected=effects[Math.floor(Math.random()*effects.length)];abilityEffect(user,target,card,selected);break;}
    case 'revive': case 'none': break;
    default: throw Error('Habilidade desconhecida: '+ability);
  }
  if(ability!=='copy')user.lastAbility=ability;
}
function statusAtTurnStart(side){
  const messages=[];
  for(const status of side.status){
    if(status.type==='burn'||status.type==='poison'){side.life-=status.value;messages.push((status.type==='burn'?'Queimadura':'Veneno')+' causou '+status.value+' PV.');}
    status.turns--;
  }
  side.status=side.status.filter(s=>s.turns>0);
  return messages;
}
function turnStart(side){
  side.energy=Math.min(side.maxEnergy,side.energy+1);side.attacked=false;side.attacksUsed=0;side.bonusAttacks=0;side.usedAbility=false;side.boost=Math.max(0,side.boost-30);side.defBoost=Math.max(0,side.defBoost-35);side.doubleNext=false;
  if(side.hasTakenTurn)draw(side);else side.hasTakenTurn=true;
  const statusMessages=statusAtTurnStart(side);if(statusMessages.length)log(statusMessages.join(' '));
  if(G?.mode==='zoeira'&&G.turn>1&&!G.winner){const rival=G.sides[side.uid==='p1'?'p2':'p1'];const events=[()=>{if(side.active)side.active.atk+=12;log('EVENTO ZOEIRA: adrenalina! '+side.name+' recebeu +12 ATQ.')},()=>{side.energy=Math.min(side.maxEnergy,side.energy+1);log('EVENTO ZOEIRA: chuva de energia! +1 ⚡ para '+side.name+'.')},()=>{draw(side);log('EVENTO ZOEIRA: carta surpresa! '+side.name+' comprou uma carta.')},()=>{side.life=Math.min(side.maxLife,side.life+12);log('EVENTO ZOEIRA: momento de sorte! '+side.name+' recuperou 12 PV.')},()=>{if(rival.active){addStatus(rival,'weaken',1,12);log('EVENTO ZOEIRA: vento de confusão! O rival perdeu 12 ATQ.')}else{side.shield+=12;log('EVENTO ZOEIRA: escudo engraçado! +12 de escudo.')}}];events[Math.floor(Math.random()*events.length)]();}
  checkEnd();
}
function spend(side,cost){if(side.energy<cost)throw Error('Energia insuficiente: precisa de '+cost+' ⚡.');side.energy-=cost;}
function assertCanAct(side){if(G?.winner)throw Error('A partida já terminou.');if(side.stun>0)throw Error('Sua vez está bloqueada por Atordoamento. Toque em Fim do turno para passar.');}
function removeCardFromHand(current){current.hand.splice(G.selected,1);G.selected=null;}

export function startGame({mode='classic',deckId,secondDeckId,carryLife=100,wave=1,difficulty='normal'}={}){
  const selectedDeck=DB.decks.find(deck=>deck.id===deckId)||DB.decks[0];if(!selectedDeck)throw Error('Crie um deck antes de jogar.');
  let playerCards=selectedDeck.cards.map(id=>DB.cards.find(card=>card.id===id)).filter(Boolean);
  if(mode==='draft')playerCards=Array.from({length:24},()=>makeRandomCard('Draft'));
  if(playerCards.length!==24)throw Error('O deck precisa conter exatamente 24 cartas válidas.');
  let opponentCards;
  if(mode==='same'){
    const second=DB.decks.find(deck=>deck.id===secondDeckId)||DB.decks.find(deck=>deck.id!==selectedDeck.id)||selectedDeck;
    opponentCards=second.cards.map(id=>DB.cards.find(card=>card.id===id)).filter(Boolean);if(opponentCards.length!==24)throw Error('O deck do Jogador 2 precisa ter 24 cartas.');
  }else opponentCards=playerCards.map(card=>({...card,id:uid()}));
  const playerLife=mode==='quick'?65:mode==='survival'?Math.max(1,carryLife):100;
  const enemyLife=mode==='boss'?300:mode==='quick'?65:mode==='survival'?Math.min(220,85+wave*18):100;
  const p1=freshSide(DB.player||'Duelista',playerCards,'p1',playerLife,3);
  const p2=freshSide(mode==='same'?'Jogador 2':mode==='boss'?'Guardião do Capítulo':mode==='survival'?'Rival da Onda '+wave:'Guardião da Arena',opponentCards,'p2',enemyLife,2);
  for(let i=0;i<5;i++){draw(p1);draw(p2);}p1.hasTakenTurn=true;
  if(mode==='boss'){const boss=makeRandomCard('Chefe');p2.active={...boss,name:'Dragão Ancestral',kind:'creature',atk:68,def:55,hp:300,currentHp:300,ability:'burn',cost:0,boss:true};p2.maxEnergy=10;}
  G={mode,wave,deckId,secondDeckId,difficulty:['easy','normal','hard'].includes(difficulty)?difficulty:'normal',turn:1,active:'p1',sides:{p1,p2},selected:null,log:'Duelo iniciado! Invoque uma criatura ou prepare uma carta de ação.',winner:null,round:0,turnLimit:mode==='quick'?16:60,started:Date.now(),actions:0,pendingPass:false};
  return snapshot();
}
export function snapshot(){return G?clone(G):null;}
export function configureBoss({name='Guardião do Capítulo',element='Sombra',attackBonus=0,hp=300,ability='burn'}={}){
  if(!G||G.mode!=='boss'||!G.sides.p2.active)throw Error('Não há chefe ativo para configurar.');
  const boss=G.sides.p2.active,side=G.sides.p2;
  boss.name=String(name).slice(0,32);boss.element=element;boss.atk+=Number(attackBonus)||0;
  boss.hp=Number(hp)||300;boss.currentHp=boss.hp;boss.ability=ability;boss.boss=true;
  side.name=boss.name;side.life=boss.hp;side.maxLife=boss.hp;
  log('O chefe '+boss.name+' entrou na arena!');
  return snapshot();
}
export function side(){return G?.sides[G.active];}
export function opponent(){return G?.sides[G.active==='p1'?'p2':'p1'];}
export function isLocalPass(){return G?.mode==='same';}
export function selectHand(index){if(!G||G.winner||G.pendingPass)return;const current=side();if(current.stun>0)return;if(index<0||index>=current.hand.length)return;G.selected=index;}
export function selectedCard(){const current=side();return G&&G.selected!==null?current.hand[G.selected]:null;}
export function canUseAbility(){const current=side();if(!G||G.winner||!current?.active||current.stun>0||current.usedAbility)return false;const ability=current.active.ability;return !PASSIVE_ABILITIES.has(ability)&&(current.energy>=(ABILITIES[ability]?.cost??1));}
export function canAttack(){const current=side();return !!(G&&!G.winner&&current?.active&&current.stun===0&&current.attacksUsed<1+current.bonusAttacks);}

export function playCard(){
  if(!G||G.winner)throw Error('Não há duelo ativo.');const current=side(),target=opponent(),card=selectedCard();assertCanAct(current);if(!card)throw Error('Selecione uma carta da mão.');
  if(card.kind==='creature'){
    if(card.cost>current.energy)throw Error('Energia insuficiente.');if(current.active&&current.bench.length>=2)throw Error('Campo e banco cheios. Troque uma criatura antes de invocar.');spend(current,card.cost);
    const instance={...clone(card),currentHp:card.hp,baseAtk:card.atk,baseDef:card.def,equipment:[]};if(!current.active){current.active=instance;log(card.name+' foi invocada no campo!');}else{current.bench.push(instance);log(card.name+' entrou no banco de reserva.');}
  }else{
    if(card.kind==='gear'&&!current.active)throw Error('Equipe uma criatura antes de usar equipamento.');if(card.kind==='trap'&&current.trap)throw Error('Você já tem uma armadilha preparada.');
    if(['equipBlade','equipArmor','boostTeam'].includes(card.ability)&&!current.active)throw Error('Esta habilidade precisa de uma criatura ativa.');if(['trapSpike','trapMirror'].includes(card.ability)&&current.trap)throw Error('Você já tem uma armadilha preparada.');if(PASSIVE_ABILITIES.has(card.ability))throw Error('Cartas de ação precisam de uma habilidade ativável.');
    if(['gear','support'].includes(card.kind)&&!current.active&&!['mend','heal','shield','fireball','burn','poison','trapSpike','trapMirror','chaos','draw'].includes(card.ability))throw Error('Esta carta precisa de uma criatura ativa.');
    spend(current,card.cost);abilityEffect(current,target,card);let combo='';if(current.active&&current.active.element===card.element){current.active.atk+=5;current.shield+=5;combo=' Combo elemental: +5 ATQ e +5 escudo!';}log(card.name+' foi ativada: '+(ABILITIES[card.ability]?.name||'efeito')+'.'+combo);
  }
  removeCardFromHand(current);checkEnd();return true;
}
export function activateAbility(){
  if(!G||G.winner)throw Error('Não há duelo ativo.');const current=side(),target=opponent();assertCanAct(current);if(!current.active)throw Error('Você precisa de uma criatura ativa.');const key=current.active.ability;
  if(PASSIVE_ABILITIES.has(key))throw Error('Esta habilidade é passiva e não precisa ser ativada.');if(current.usedAbility)throw Error('Você já ativou uma habilidade neste turno.');spend(current,ABILITIES[key]?.cost??1);current.usedAbility=true;abilityEffect(current,target,current.active,key);
  DB.abilitiesUsed=(DB.abilitiesUsed||0)+1;missionProgress('ability');saveDB();log('Habilidade '+(ABILITIES[key]?.name||key)+' ativada!');checkEnd();
}
export function attack(){
  if(!G||G.winner)throw Error('Não há duelo ativo.');const current=side(),target=opponent();assertCanAct(current);if(!current.active)throw Error('Invoque uma criatura antes de atacar.');if(current.attacksUsed>=1+current.bonusAttacks)throw Error('Você já utilizou todos os ataques deste turno.');
  const attacker=current.active,elementBonus=ELEMENT_BONUS[attacker.element]?.[target.active?.element]||0,weaken=current.status.find(s=>s.type==='weaken')?.value||0,freeze=current.status.find(s=>s.type==='freeze')?.value||0;
  let amount=Math.max(8,attacker.atk+current.boost-weaken-freeze+elementBonus-(target.active?(target.active.def+target.defBoost)*.25:0));if(target.active?.ability==='guard')amount*=.85;
  if(target.trap){const trap=target.trap;target.trap=null;if(trap.type==='spike'){dealDamage(current,30,target);if(!current.active||G.winner){log('A armadilha interrompeu o ataque!');return;}}if(trap.type==='mirror')target.reflect+=40;log('Armadilha ativada: '+trap.name+'!');}
  dealDamage(target,amount,current);if(current.doubleNext){dealDamage(target,amount*.6,current);current.doubleNext=false;}
  current.attacksUsed++;current.attacked=current.attacksUsed>=1+current.bonusAttacks;log(attacker.name+' atacou e causou '+Math.round(amount)+' de dano.'+(elementBonus>0?' Vantagem elemental!':elementBonus<0?' Resistência elemental.':''));checkEnd();
}
export function switchBench(index){const current=side();assertCanAct(current);if(!current.bench[index])throw Error('Não existe criatura nessa posição do banco.');spend(current,1);const old=current.active;current.active=current.bench.splice(index,1)[0];if(old)current.bench.push(old);log('Troca tática: '+current.active.name+' entrou no campo.');}
function finish(winner){
  if(!G||G.winner)return;G.winner=winner;if(G.mode==='same'){G.log=winner==='p1'?'Jogador 1 venceu o duelo!':'Jogador 2 venceu o duelo!';return;}
  const won=winner==='p1';DB.duels=(DB.duels||0)+1;
  if(won){const boss=G.mode==='boss';DB.wins++;DB.coins+=boss?180:G.mode==='survival'?50:35;DB.shards+=boss?5:2;DB.xp+=boss?65:30;DB.level=1+Math.floor(DB.xp/120);DB.rank=DB.wins>=25?'Diamante':DB.wins>=12?'Ouro':DB.wins>=5?'Prata':'Bronze';missionProgress('win');
    if(boss){DB.bossWins=(DB.bossWins||0)+1;DB.campaignWins=(DB.campaignWins||0)+1;DB.unlockedChapter=Math.min(6,(DB.unlockedChapter||1)+1);}if(G.mode==='survival')DB.campaignWins=(DB.campaignWins||0)+1;
    const active=G.sides.p1.active;if(active){const owned=DB.cards.find(card=>card.id===active.id);if(owned){owned.xp=(owned.xp||0)+25;if(owned.xp>=50){owned.xp-=50;owned.level=(owned.level||1)+1;owned.atk+=5;owned.def+=4;owned.hp+=8;}}}
  }else DB.losses=(DB.losses||0)+1;
  G.log=won?'VITÓRIA! Você conquistou a arena.':'DERROTA! Reorganize seu deck e tente novamente.';saveDB();missionProgress('duel');
}
function clearStunAndEnd(side){side.stun=0;side.attacked=false;side.attacksUsed=0;side.bonusAttacks=0;side.usedAbility=false;side.boost=Math.max(0,side.boost-30);side.defBoost=Math.max(0,side.defBoost-35);side.doubleNext=false;}
function cpuPlayCard(cpu,human,idx){const c=cpu.hand[idx];if(!c||c.cost>cpu.energy)return false;try{
  if(c.kind==='creature'){if(cpu.active&&cpu.bench.length>=2)return false;spend(cpu,c.cost);const inst={...clone(c),currentHp:c.hp,baseAtk:c.atk,baseDef:c.def,equipment:[]};if(!cpu.active)cpu.active=inst;else cpu.bench.push(inst);cpu.hand.splice(idx,1);return true;}
  if(c.kind==='gear'&&!cpu.active)return false;if(c.kind==='trap'&&cpu.trap)return false;if(['equipBlade','equipArmor','boostTeam'].includes(c.ability)&&!cpu.active)return false;if(PASSIVE_ABILITIES.has(c.ability))return false;
  spend(cpu,c.cost);abilityEffect(cpu,human,c);cpu.hand.splice(idx,1);return true;
}catch{return false}}
function cpuTurn(){
  if(!G||G.winner)return;const cpu=G.sides.p2,human=G.sides.p1;G.active='p2';
  if(cpu.stun>0){log(cpu.name+' está atordoado e perdeu a vez.');clearStunAndEnd(cpu);finishTurnToPlayer();return;}
  // The CPU builds a small board instead of leaving its reserve empty.
  if(!cpu.active||((G.difficulty==='hard'||(G.difficulty==='normal'&&cpu.energy>=4))&&cpu.bench.length<2)){
    let choices=cpu.hand.map((c,i)=>({c,i})).filter(x=>x.c.kind==='creature'&&x.c.cost<=cpu.energy).sort((a,b)=>((b.c.atk+b.c.def+b.c.hp*.25)-(a.c.atk+a.c.def+a.c.hp*.25)));
    if(G.difficulty==='easy')choices.reverse();if(choices[0])cpuPlayCard(cpu,human,choices[0].i);
  }
  if(cpu.active){
    const scoreAction=x=>({heal:cpu.life<65?10:1,mend:cpu.life<65?10:1,fireball:human.active?9:5,burn:7,poison:8,shield:cpu.life<60?10:3,equipBlade:cpu.active?7:0,equipArmor:cpu.active?6:0,trapSpike:6,trapMirror:5,draw:4,chaos:3,stun:9,rage:6,boostTeam:5})[x.ability]??1;
    const limit=G.difficulty==='easy'?0:G.difficulty==='hard'?2:1;let played=0;
    // Recalculate candidate indices after every removal so the CPU never plays a stale hand index.
    while(played<limit&&!G.winner){
      const candidates=cpu.hand.map((c,i)=>({c,i})).filter(x=>x.c.kind!=='creature'&&x.c.cost<=cpu.energy).sort((a,b)=>scoreAction(b.c)-scoreAction(a.c));
      if(!candidates.length||!cpuPlayCard(cpu,human,candidates[0].i))break;played++;
    }
    if(!cpu.usedAbility&&cpu.active&&!PASSIVE_ABILITIES.has(cpu.active.ability)&&cpu.energy>=(ABILITIES[cpu.active.ability]?.cost??1)){
      let key=cpu.active.ability,worth=G.difficulty==='hard'||(key==='heal'&&cpu.life<70)||(key==='shield'&&cpu.life<65)||(['burn','poison','stun','fireball','drain'].includes(key)&&human.life<85);
      if(worth){spend(cpu,ABILITIES[key]?.cost??1);cpu.usedAbility=true;abilityEffect(cpu,human,cpu.active,key);log(cpu.name+' ativou '+(ABILITIES[key]?.name||key)+'.');}
    }
    if(cpu.active&&human.active){let attacks=1+(cpu.bonusAttacks||0);for(let i=0;i<attacks&&!G.winner;i++){const elemental=ELEMENT_BONUS[cpu.active.element]?.[human.active.element]||0,weaken=cpu.status.find(s=>s.type==='weaken')?.value||0,freeze=cpu.status.find(s=>s.type==='freeze')?.value||0;const damage=Math.max(8,cpu.active.atk+(cpu.boost||0)-weaken-freeze+elemental-(human.active.def+(human.defBoost||0))*.25);if(human.trap){const trap=human.trap;human.trap=null;if(trap.type==='spike'){dealDamage(cpu,30,human);if(!cpu.active||G.winner)break;}if(trap.type==='mirror')human.reflect+=40;}dealDamage(human,damage,cpu);cpu.attacksUsed++;if(cpu.doubleNext){dealDamage(human,damage*.6,cpu);cpu.doubleNext=false;}log(cpu.name+' atacou e causou '+Math.round(damage)+' de dano.'+(elemental>0?' Vantagem elemental!':elemental<0?' Resistência elemental.':''));}}
    else if(cpu.active){human.life-=G.difficulty==='hard'?22:14;log(cpu.name+' realizou ataque direto!');}
  }else log(cpu.name+' não conseguiu invocar uma criatura.');
  checkEnd();if(!G.winner){clearStunAndEnd(cpu);finishTurnToPlayer();}
}
function finishTurnToPlayer(){if(!G||G.winner)return;G.active='p1';G.turn++;turnStart(G.sides.p1);G.selected=null;G.pendingPass=false;checkEnd();}
export function endTurn(){
  if(!G||G.winner)throw Error('Não há duelo ativo.');const current=side();
  if(G.mode==='same'){clearStunAndEnd(current);G.pendingPass=true;G.active=G.active==='p1'?'p2':'p1';G.turn++;G.selected=null;log('Passe o aparelho para '+side().name+'.');return;}
  if(G.active!=='p1')throw Error('Aguarde o seu turno.');clearStunAndEnd(current);G.selected=null;G.active='p2';turnStart(G.sides.p2);if(G.winner)return;cpuTurn();
}
export function passToNext(){if(!G||G.winner||G.mode!=='same'||!G.pendingPass)throw Error('Não há troca de jogador pendente.');G.pendingPass=false;G.selected=null;turnStart(side());checkEnd();}
export function abandon(){G=null;}
export function getState(){return snapshot();}
