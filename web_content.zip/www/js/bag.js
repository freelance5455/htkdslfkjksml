/* Detox mesh bag: a net bag of balls hanging from a ceiling rail. Each blue day cracks it a little more. */
(function () {
  'use strict';
  var BW = 136, BH = 152, PADX = 28, PADY = 18;
  var HOLES = [[0, .8], [-.4, .7], [.4, .7], [-.18, .9], [.2, .88], [-.6, .5], [.6, .5], [0, .55]];
  var S = { cx: 0, rail: 0, neck: 0, k: 1, cracks: 0, openT: 1, shake: 0, cv: null, t: 0, contents: null, W: 0 };
  var rnd = function (a, b) { return a + Math.random() * (b - a); };

  function outline(ctx) {
    ctx.beginPath();
    ctx.moveTo(-12, 0);
    ctx.bezierCurveTo(-BW * .62, BH * .18, -BW * .58, BH * .95, 0, BH);
    ctx.bezierCurveTo(BW * .58, BH * .95, BW * .62, BH * .18, 12, 0);
    ctx.closePath();
  }

  /* the balls sitting inside the bag (static, relaxed once) */
  function makeContents() {
    var arr = [], i, j, pal = Balls.BLUE.concat(['#e8f1ff', '#dbe8ff']);
    for (i = 0; i < 36; i++) arr.push({ x: rnd(-44, 44), y: rnd(46, 138), r: rnd(12.5, 16.5), c: pal[(Math.random() * pal.length) | 0] });
    for (var it = 0; it < 90; it++) {
      for (i = 0; i < arr.length; i++) for (j = i + 1; j < arr.length; j++) {
        var a = arr[i], b = arr[j], dx = b.x - a.x, dy = b.y - a.y, d = Math.sqrt(dx * dx + dy * dy) || .1, m = a.r + b.r - 2;
        if (d < m) { var p = (m - d) / 2; a.x -= dx / d * p; a.y -= dy / d * p; b.x += dx / d * p; b.y += dy / d * p; }
      }
      arr.forEach(function (o) {
        var ex = (o.x) / (58 - o.r * .55), ey = (o.y - 88) / (62 - o.r * .55), e = Math.sqrt(ex * ex + ey * ey);
        if (e > 1) { o.x = o.x / e; o.y = 88 + (o.y - 88) / e; }
      });
    }
    S.contents = arr;
  }

  function holePoly(idx, amt) {
    var h = HOLES[idx % HOLES.length], cyc = Math.floor(Math.max(0, S.cracks - 1 - idx) / HOLES.length);
    var cx = h[0] * BW * .5, cy = h[1] * BH, rho = Math.min(30, 19 + cyc * 3) * amt, pts = [];
    var seed = (idx + 1) * 9301 % 233280;
    for (var i = 0; i < 11; i++) {
      seed = (seed * 9301 + 49297) % 233280;
      var a = i / 11 * Math.PI * 2, r = rho * (.68 + seed / 233280 * .6);
      pts.push([cx + Math.cos(a) * r * .92, cy + Math.sin(a) * r * 1.25 - rho * .1]);
    }
    return { cx: cx, cy: cy, pts: pts, rho: rho };
  }

  function render() {
    var k = S.k, w = BW + PADX * 2, h = BH + PADY * 2;
    var cv = S.cv || (S.cv = document.createElement('canvas'));
    cv.width = Math.round(w * k); cv.height = Math.round(h * k);
    var x = cv.getContext('2d');
    x.setTransform(k, 0, 0, k, PADX * k + BW / 2 * k, PADY * k);
    // soft inner body so the bag reads as a bag, even through the holes
    x.save(); outline(x); x.clip();
    var bg = x.createLinearGradient(0, 0, 0, BH); bg.addColorStop(0, 'rgba(60,90,200,.20)'); bg.addColorStop(1, 'rgba(20,30,110,.34)');
    x.fillStyle = bg; x.fillRect(-BW, 0, BW * 2, BH);
    S.contents.forEach(function (o) { x.drawImage(Balls.sprite(o.c), o.x - o.r, o.y - o.r, o.r * 2, o.r * 2); });
    var sh = x.createLinearGradient(0, 0, 0, BH); sh.addColorStop(0, 'rgba(10,20,80,.38)'); sh.addColorStop(.5, 'rgba(10,20,80,.08)'); sh.addColorStop(1, 'rgba(10,20,80,.22)');
    x.fillStyle = sh; x.fillRect(-BW, 0, BW * 2, BH);
    x.restore();
    // net on its own layer so holes can be cut out of it
    var nc = document.createElement('canvas'); nc.width = cv.width; nc.height = cv.height;
    var n = nc.getContext('2d'); n.setTransform(k, 0, 0, k, PADX * k + BW / 2 * k, PADY * k);
    n.save(); outline(n); n.clip();
    var sp = 12.5, c;
    n.lineWidth = 1.5;
    for (c = -BH - BW; c < BH + BW; c += sp) {
      n.strokeStyle = 'rgba(255,255,255,.62)';
      n.beginPath(); n.moveTo(-BW, c + BW); n.lineTo(BW, c - BW); n.stroke();
      n.beginPath(); n.moveTo(-BW, c - BW); n.lineTo(BW, c + BW); n.stroke();
    }
    n.fillStyle = 'rgba(255,255,255,.95)';
    for (var gx = -BW; gx < BW; gx += sp) for (var gy = 0; gy < BH + sp; gy += sp) {
      n.beginPath(); n.arc(gx + ((gy / sp) % 2 ? sp / 2 : 0), gy, 1.5, 0, 6.2832); n.fill();
    }
    n.restore();
    // outline glow
    n.save(); outline(n); n.strokeStyle = 'rgba(190,215,255,.7)'; n.lineWidth = 2; n.stroke(); n.restore();
    // holes
    var i, p, hole;
    for (i = 0; i < Math.min(S.cracks, HOLES.length); i++) {
      var amt = (i === (S.cracks - 1) % HOLES.length) ? easeOutBack(S.openT) : 1;
      hole = holePoly(i, Math.max(.001, amt));
      n.save(); n.globalCompositeOperation = 'destination-out'; n.beginPath();
      hole.pts.forEach(function (q, j) { j ? n.lineTo(q[0], q[1]) : n.moveTo(q[0], q[1]); }); n.closePath(); n.fill(); n.restore();
      n.strokeStyle = 'rgba(255,255,255,.75)'; n.lineWidth = 1.3; n.lineCap = 'round';
      for (p = 0; p < hole.pts.length; p += 2) {
        var q0 = hole.pts[p], dx = q0[0] - hole.cx, dy = q0[1] - hole.cy, d = Math.sqrt(dx * dx + dy * dy) || 1, L = 5 + (p * 7 % 6) * amt;
        n.beginPath(); n.moveTo(q0[0], q0[1]); n.lineTo(q0[0] + dx / d * L + 1.5, q0[1] + dy / d * L + 2); n.stroke();
      }
    }
    x.setTransform(1, 0, 0, 1, 0, 0); x.drawImage(nc, 0, 0);
  }
  function easeOutBack(t) { var c1 = 1.9, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); }

  function init(cx, rail, k, cracks) {
    S.cx = cx; S.rail = rail; S.neck = rail + 26; S.k = k || 1; S.cracks = cracks || 0; S.openT = 1; S.shake = 0;
    if (!S.contents) makeContents();
    render();
  }
  function holeWorld(idx) {
    var h = holePoly(idx % HOLES.length, 1);
    return { x: S.cx + h.cx, y: S.neck + h.cy };
  }
  /* crack the bag a little more; returns where balls will fall from */
  function open() {
    S.cracks++; S.openT = 0; S.shake = 1; render();
    return holeWorld(S.cracks - 1);
  }
  function mouth() { return holeWorld(Math.max(0, S.cracks - 1)); }
  function update(dt) {
    S.t += dt;
    if (S.openT < 1) { S.openT = Math.min(1, S.openT + dt / .55); render(); }
    S.shake = Math.max(0, S.shake - dt * 1.6);
  }
  function draw(ctx) {
    var sway = Math.sin(S.t * .9) * .022 + Math.sin(S.t * 41) * .045 * S.shake * S.shake;
    // ceiling rail + carriage
    ctx.save();
    ctx.strokeStyle = 'rgba(28,40,110,.28)'; ctx.lineWidth = 5; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(26, S.rail); ctx.lineTo(S.W - 26, S.rail); ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,.35)'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(26, S.rail - 1.5); ctx.lineTo(S.W - 26, S.rail - 1.5); ctx.stroke();
    ctx.restore();
    ctx.save();
    ctx.translate(S.cx, S.rail); ctx.rotate(sway);
    var sq = 1 + S.shake * .02 * Math.sin(S.t * 30);
    ctx.fillStyle = '#25317a'; rrect(ctx, -11, -6, 22, 12, 5); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,.35)'; rrect(ctx, -9, -4.5, 18, 3, 2); ctx.fill();
    ctx.strokeStyle = '#d9b46a'; ctx.lineWidth = 3.2; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(0, 5); ctx.lineTo(0, 26 + 6); ctx.stroke();
    ctx.translate(0, 26); ctx.scale(sq, 1 / sq);
    var k = S.k; ctx.drawImage(S.cv, -(BW / 2 + PADX), -PADY, BW + PADX * 2, BH + PADY * 2);
    // gathered neck knot
    var g = ctx.createLinearGradient(-14, 0, 14, 0); g.addColorStop(0, '#c9a24f'); g.addColorStop(.5, '#f5dc9a'); g.addColorStop(1, '#b8903c');
    ctx.fillStyle = g; rrect(ctx, -14, -5, 28, 13, 6); ctx.fill();
    ctx.restore();
  }
  function rrect(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }

  window.Bag = { init: init, open: open, mouth: mouth, update: update, draw: draw, setWidth: function (w) { S.W = w; },
    setCracks: function (n) { S.cracks = n; S.openT = 1; render(); }, state: S };
})();
