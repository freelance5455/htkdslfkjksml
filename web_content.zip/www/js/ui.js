/* ============================================================
   RadLedger — رابط کاربری و اکشن‌ها
   همهٔ متن‌های کاربر با esc() امن می‌شوند.
   ============================================================ */
'use strict';

const $ = (s) => document.querySelector(s);
let S;
const initState = () => { const t = todayIso(), j = J(t); S = { tab: 'cal', sel: t, cy: j.y, cm: j.m, fin: 'adv', fw: '', ff: '', ry: j.y, rm: j.m, rf: 1, rt: 31, rw: 'all' }; };

let toastTimer;
function toast(s) { const t = $('#t'); t.textContent = s; t.style.display = 'block'; clearTimeout(toastTimer); toastTimer = setTimeout(() => (t.style.display = 'none'), 2800); }
const sheet = (h) => { $('#sh').innerHTML = h ? `<div class=bd onclick="sheet()"></div><div class=sh role=dialog>${h}</div>` : ''; };
const opts = (a, sel, ph) => (ph == null ? '' : `<option value="">${esc(ph)}</option>`) + a.map((x) => `<option value="${esc(x.id)}" ${x.id == sel ? 'selected' : ''}>${esc(x.name)}</option>`).join('');

const IC = {
  cal: '<rect x="3.5" y="5" width="17" height="15" rx="3"/><path d="M8 3v4M16 3v4M3.5 10h17"/>',
  wk: '<circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6"/><circle cx="17" cy="9" r="2.4"/><path d="M16 14.2c3 .2 5 2.4 5 5.8"/>',
  fin: '<path d="M4 7.5A2.5 2.5 0 0 1 6.5 5H18v3"/><rect x="4" y="8" width="16" height="11" rx="3"/><circle cx="15.5" cy="13.5" r="1.2"/>',
  rep: '<path d="M5 20V11M12 20V4M19 20v-6"/>',
  set: '<path d="M4 7h10M18 7h2M4 17h2M10 17h10"/><circle cx="16" cy="7" r="2"/><circle cx="8" cy="17" r="2"/>',
  plus: '<path d="M12 5v14M5 12h14"/>', trash: '<path d="M5 7h14M10 7V5h4v2M7 7l1 12h8l1-12"/>',
  chr: '<path d="M9 6l6 6-6 6"/>', chl: '<path d="M15 6l-6 6 6 6"/>',
  pdf: '<path d="M7 3h7l4 4v14H7zM14 3v4h4"/>', xls: '<rect x="4" y="4" width="16" height="16" rx="2"/><path d="M4 10h16M4 15h16M10 4v16"/>',
  save: '<path d="M12 4v11M7 11l5 5 5-5M5 20h14"/>', up: '<path d="M12 16V5M7 9l5-5 5 5M5 20h14"/>',
  ok: '<path d="M5 12.5l4.5 4.5L19 7.5"/>', today: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="2.5"/>',
};
const ic = (n) => `<svg class=ic viewBox="0 0 24 24" aria-hidden="true">${IC[n]}</svg>`;

/* ---------- رندر اصلی ---------- */
function R() {
  if (lstate().st != 'active') { $('#top').style.display = 'none'; $('#nav').innerHTML = ''; $('#app').innerHTML = lockView(); return; }
  const y = scrollY;
  $('#top').style.display = '';
  $('#nav').innerHTML = [['cal', 'تقویم'], ['wk', 'نیروها'], ['fin', 'مالی'], ['rep', 'گزارش'], ['set', 'تنظیمات']]
    .map(([k, t]) => `<button class="${S.tab == k ? 'a' : ''}" onclick="go('${k}')"><i>${ic(k)}</i>${t}</button>`).join('');
  $('#top').innerHTML = `<div class=hl><img src=icon.png alt=""><div><b>${esc(db.set.h1 || 'RadLedger')}</b><span>${jfull(todayIso())}</span></div></div>`;
  document.documentElement.style.setProperty('--p', db.set.col || '#4f46e5');
  $('#app').innerHTML = licBanner() + { cal: vCal, wk: vWk, fin: vFin, rep: vRep, set: vSet }[S.tab]();
  scrollTo(0, y);
}
function go(k) { S.tab = k; R(); scrollTo(0, 0); }

/* ---------- تقویم و حضور ---------- */
function mv(k) { S.cm += k; if (S.cm > 12) { S.cm = 1; S.cy++; } if (S.cm < 1) { S.cm = 12; S.cy--; } R(); }
function goToday() { const t = todayIso(), j = J(t); S.sel = t; S.cy = j.y; S.cm = j.m; R(); }
function vCal() {
  const f = jIso(S.cy, S.cm, 1), len = mLen(S.cy, S.cm), T = todayIso(), hi = addDays(f, len - 1), cnt = {};
  db.att.forEach((a) => { if (a.d >= f && a.d <= hi && a.s > 0) cnt[a.d] = (cnt[a.d] || 0) + 1; });
  let h = `<div class=card><div class=row><button onclick=mv(-1) aria-label="ماه قبل">${ic('chr')}</button><b>${MN[S.cm - 1]} ${fa(S.cy)}</b><button onclick=mv(1) aria-label="ماه بعد">${ic('chl')}</button></div><div class=grid>`
    + WS.map((w) => `<i>${w}</i>`).join('') + '<span></span>'.repeat(J(f).w);
  for (let d = 1; d <= len; d++) {
    const i = addDays(f, d - 1), c = cnt[i];
    h += `<button class="day${i == S.sel ? ' sel' : ''}${i == T ? ' today' : ''}${J(i).w == 6 ? ' fri' : ''}" onclick="selDay('${i}')">${fa(d)}${c ? `<u>${fa(c)}</u>` : ''}</button>`;
  }
  h += '</div>';
  if (S.sel != T || J(T).m != S.cm || J(T).y != S.cy) h += `<button class="pri ghost" style="margin-top:8px" onclick="goToday()">${ic('today')} برو به امروز</button>`;
  return h + '</div>' + vDay();
}
function selDay(i) { S.sel = i; R(); }
function vDay() {
  const ws = db.workers.filter((w) => w.on !== 0);
  let h = `<div class=card><div class=row><b>${jfull(S.sel)}</b>${ws.length ? `<button onclick="markAll()">${ic('ok')} همه حاضر</button>` : ''}</div>`;
  if (!db.workers.length) return h + '<p>ابتدا از بخش «نیروها» نیرو اضافه کنید.</p></div>';
  if (!ws.length) return h + '<p>همهٔ نیروها غیرفعال هستند.</p></div>';
  const rec = {}; db.att.forEach((a) => { if (a.d == S.sel) rec[a.w] = a; });
  const c = (v) => ws.filter((w) => rec[w.id] && rec[w.id].s === v).length;
  h += `<small>حاضر ${fa(c(1))} · نیم‌روز ${fa(c(0.5))} · غایب ${fa(c(0))} · ثبت‌نشده ${fa(ws.filter((w) => !rec[w.id]).length)}</small>`;
  return h + ws.map((w) => {
    const a = rec[w.id] || {};
    return `<div class=wr><b>${esc(w.name)}</b><small>${esc(w.role || '')}</small><div class=seg>${[[1, 'حاضر'], [0.5, 'نیم‌روز'], [0, 'غایب']].map(([v, t]) => `<button class="${a.s === v ? 'on' + v * 2 : ''}" onclick="st('${w.id}',${a.s === v ? 'null' : v})">${t}</button>`).join('')}</div>${a.s !== undefined ? `<div class=sub><input placeholder="تاخیر (ساعت)" inputmode=numeric value="${a.late ? fa(a.late) : ''}" onchange="pa('${w.id}','late',Math.max(0,Math.floor(num(this.value))))"><input placeholder="اضافه‌کار (ساعت)" inputmode=decimal value="${a.ot ? fa(a.ot) : ''}" onchange="pa('${w.id}','ot',Math.max(0,num(this.value)))"><select onchange="pa('${w.id}','pl',this.value)">${opts(db.places, a.pl || w.pl, 'محل کار')}</select></div>` : ''}</div>`;
  }).join('') + '</div>';
}
function st(w, v) {
  const i = db.att.findIndex((x) => x.w == w && x.d == S.sel);
  if (v === null) { if (i >= 0) db.att.splice(i, 1); }
  else if (i >= 0) db.att[i].s = v;
  else db.att.push({ id: uid(), w, d: S.sel, s: v, pl: (db.workers.find((x) => x.id == w) || {}).pl || '' });
  save(); R();
}
function pa(w, k, v) {
  const a = db.att.find((x) => x.w == w && x.d == S.sel);
  if (!a) return;
  if (k == 'ot' || k == 'late') { if (v) a[k] = v; else delete a[k]; } else a[k] = v;
  save();
}
function markAll() {
  let n = 0;
  db.workers.filter((w) => w.on !== 0).forEach((w) => {
    if (!db.att.some((x) => x.w == w.id && x.d == S.sel)) { db.att.push({ id: uid(), w: w.id, d: S.sel, s: 1, pl: w.pl || '' }); n++; }
  });
  save(); R(); toast(n ? fa(n) + ' نفر حاضر ثبت شد' : 'همه قبلاً ثبت شده‌اند');
}

/* ---------- نیروها و محل‌های کار ---------- */
function vWk() {
  const f = jIso(S.cy, S.cm, 1), t = addDays(f, mLen(S.cy, S.cm) - 1);
  return `<div class=card><div class=row><b>نیروها (${fa(db.workers.length)})</b><button class="pri inl" onclick="wForm()">${ic('plus')} نیروی جدید</button></div>`
    + db.workers.map((w) => {
      const x = workerReport(db, w, f, t);
      return `<div class=wr><div class=row><div><b>${esc(w.name)}</b><small>${esc(w.role || '—')} | روزمزد ${money(w.wage || 0)}${w.on === 0 ? ' | غیرفعال' : ''}</small></div><button onclick="wForm('${w.id}')">ویرایش</button></div><small>این ماه (${MN[S.cm - 1]}): ${dys(x.days)} روز — قابل پرداخت ${money(x.net)}</small></div>`;
    }).join('')
    + `</div><div class=card><div class=row><b>محل‌های کار</b><button onclick="plF()">${ic('plus')} افزودن</button></div>`
    + db.places.map((p) => `<div class=row style="margin-top:8px"><span>${esc(p.name)}</span><span><button onclick="plF('${p.id}')">ویرایش</button> <button class=dng onclick="plDel('${p.id}')">حذف</button></span></div>`).join('') + '</div>';
}
function plF(id) {
  const p = db.places.find((x) => x.id == id) || {};
  sheet(`<h3>${id ? 'ویرایش محل کار' : 'محل کار جدید'}</h3><input id=pnm placeholder="نام محل کار" value="${esc(p.name)}"><button class=pri onclick="plSave('${id || ''}')">ذخیره</button>`);
  setTimeout(() => { const e = $('#pnm'); if (e) e.focus(); }, 50);
}
function plSave(id) {
  const n = $('#pnm').value.trim();
  if (!n) return toast('نام را وارد کنید');
  if (id) db.places.find((x) => x.id == id).name = n; else db.places.push({ id: uid(), name: n });
  save(); sheet(); R();
}
function plDel(id) {
  if (!confirm('این محل کار حذف شود؟ (سوابق قبلی حفظ می‌شود)')) return;
  db.places = db.places.filter((p) => p.id != id);
  db.workers.forEach((w) => { if (w.pl == id) w.pl = ''; });
  db.att.forEach((a) => { if (a.pl == id) a.pl = ''; });
  save(); R();
}
function wForm(id) {
  const w = db.workers.find((x) => x.id == id) || {};
  sheet(`<h3>${id ? 'ویرایش نیرو' : 'نیروی جدید'}</h3><input id=n placeholder="نام و نام خانوادگی" value="${esc(w.name)}"><input id=r placeholder="سمت (مثلاً استادکار، کارگر)" value="${esc(w.role)}"><input id=g placeholder="دستمزد روزانه (تومان)" inputmode=numeric value="${w.wage || ''}"><select id=p>${opts(db.places, w.pl, 'محل کار پیش‌فرض')}</select><input id=ph placeholder="تلفن" inputmode=tel value="${esc(w.ph)}"><select id=on><option value=1>فعال</option><option value=0 ${w.on === 0 ? 'selected' : ''}>غیرفعال</option></select><button class=pri onclick="wSave('${id || ''}')">ذخیره</button>${id ? `<button class="pri ghost dng" onclick="wDel('${id}')">حذف نیرو و سوابق</button>` : ''}`);
}
function wSave(id) {
  const o = { name: $('#n').value.trim(), role: $('#r').value.trim(), wage: Math.max(0, num($('#g').value)), pl: $('#p').value, ph: $('#ph').value.trim(), on: +$('#on').value };
  if (!o.name) return toast('نام را وارد کنید');
  if (id) Object.assign(db.workers.find((x) => x.id == id), o); else db.workers.push({ id: uid(), ...o });
  save(); sheet(); R();
}
function wDel(id) {
  const n = ['att', 'adv', 'trn'].reduce((s, k) => s + db[k].filter((x) => x.w == id).length, 0);
  if (!confirm(`نیرو و ${fa(n)} رکورد مربوط به او برای همیشه حذف شود؟`)) return;
  db.workers = db.workers.filter((w) => w.id != id);
  ['att', 'adv', 'trn'].forEach((k) => { db[k] = db[k].filter((x) => x.w != id); });
  save(); sheet(); R();
}

/* ---------- مالی: مساعده و کرایه ماشین ---------- */
function vFin() {
  const k = S.fin, j = J(S.sel), L_ = k == 'adv' ? 'مساعده' : 'کرایه ماشین';
  const all = db[k].filter((x) => !S.ff || x.w == S.ff).sort((a, b) => (a.d < b.d ? 1 : a.d > b.d ? -1 : 0));
  const mt = all.filter((x) => { const q = J(x.d); return q.y == j.y && q.m == j.m; }).reduce((s, x) => s + x.amt, 0);
  return `<div class=card><div class=seg><button class="${k == 'adv' ? 'on2' : ''}" onclick="S.fin='adv';R()">مساعده</button><button class="${k == 'trn' ? 'on2' : ''}" onclick="S.fin='trn';R()">کرایه ماشین</button></div>
<select id=fw onchange="S.fw=this.value">${opts(db.workers, S.fw, 'انتخاب نیرو')}</select>
<div class=r3><input id=fy value="${fa(j.y)}" inputmode=numeric aria-label="سال"><input id=fm value="${fa(j.m)}" inputmode=numeric aria-label="ماه"><input id=fd value="${fa(j.d)}" inputmode=numeric aria-label="روز"></div><small>سال / ماه / روز (پیش‌فرض: روز انتخاب‌شده در تقویم)</small>
<input id=fa placeholder="مبلغ (تومان)" inputmode=numeric><input id=fn placeholder="توضیحات"><button class=pri onclick="fAdd()">ثبت ${L_}</button></div>
<div class=card><div class=row><b>${L_}‌ها</b><select style="width:auto;margin:0;max-width:55%" onchange="S.ff=this.value;R()">${opts(db.workers, S.ff, 'همهٔ نیروها')}</select></div><small style="margin-top:6px">جمع ${MN[j.m - 1]} ${fa(j.y)}: <b>${money(mt)}</b> تومان</small>`
    + all.slice(0, 60).map((x) => `<div class=row style="margin-top:8px"><div>${esc(workerName(db, x.w))}<small>${jd(x.d)} ${esc(x.note || '')}</small></div><div><b>${money(x.amt)}</b> <button class=dng onclick="fDel('${x.id}')" aria-label="حذف">${ic('trash')}</button></div></div>`).join('')
    + (all.length > 60 ? `<small style="margin-top:8px">${fa(all.length - 60)} مورد قدیمی‌تر در گزارش‌ها لحاظ می‌شود.</small>` : '') + '</div>';
}
function fAdd() {
  const w = $('#fw').value, a = num($('#fa').value), y = num($('#fy').value), m = num($('#fm').value), d = num($('#fd').value);
  if (!w || !(a > 0)) return toast('نیرو و مبلغ (بزرگ‌تر از صفر) را وارد کنید');
  if (!validJ(y, m, d)) return toast('تاریخ معتبر نیست');
  db[S.fin].push({ id: uid(), w, d: jIso(y, m, d), amt: Math.round(a), note: $('#fn').value.trim() });
  S.fw = w; save(); R(); toast('ثبت شد');
}
function fDel(id) { if (confirm('حذف شود؟')) { db[S.fin] = db[S.fin].filter((x) => x.id != id); save(); R(); } }

/* ---------- گزارش‌ها ---------- */
const tH = (t) => `${t.t ? `<b>${esc(t.t)}</b>` : ''}<div class=w><table><tr>${t.h.map((h) => `<th>${esc(h)}</th>`).join('')}</tr>${t.r.map((r) => '<tr>' + r.map((c) => `<td>${esc(cv(c))}</td>`).join('') + '</tr>').join('')}${t.f.map((r) => '<tr>' + r.map((c) => `<th class=tf>${esc(cv(c))}</th>`).join('') + '</tr>').join('')}</table></div>`;
function dash(W) {
  if (!W.length) return '';
  const s = (k) => W.reduce((a, x) => a + x[k], 0), mx = Math.max(1, ...W.map((x) => x.net));
  const pr = [['gross', 'دستمزد', '#4f46e5'], ['tt', 'کرایه', '#0ea5e9'], ['ld', 'کسر تاخیر', '#f59e0b'], ['adv', 'مساعده', '#ef4444']], tot = pr.reduce((a, p) => a + s(p[0]), 0) || 1;
  return `<div class=card><b>داشبورد کارکرد</b><div class=kp style="margin-top:10px"><div><small>مجموع قابل پرداخت</small><b style="color:var(--p)">${money(s('net'))}</b></div><div><small>مجموع دستمزد</small><b>${money(s('gross'))}</b></div><div><small>روز کارکرد</small><b>${dys(s('days'))}</b></div><div><small>مساعده</small><b>${money(s('adv'))}</b></div></div><div class=stk>${pr.map((p) => `<div style="width:${(s(p[0]) / tot) * 100}%;background:${p[2]}"></div>`).join('')}</div><div class=lg>${pr.map((p) => `<span><i style="background:${p[2]}"></i>${p[1]}: ${money(s(p[0]))}</span>`).join('')}</div>`
    + W.slice().sort((a, b) => b.net - a.net).map((x) => `<div class=bw><div class=row><span><b>${esc(x.wname)}</b> <small style="display:inline">${dys(x.days)} روز</small></span><b>${money(x.net)}</b></div><div class=tr><div style="width:${Math.max(2, (Math.max(0, x.net) / mx) * 100)}%"></div></div></div>`).join('') + '</div>';
}
const repArgs = () => ({ y: S.ry, m: S.rm, from: S.rf, to: S.rt, worker: S.rw });
function vRep() {
  const ps = db.workers.length ? buildReports(db, repArgs()) : [], p = ps[0], ys = [S.ry - 1, S.ry, S.ry + 1], R_ = monthRange(S.ry, S.rm, S.rf, S.rt);
  return `<div class=card><select onchange="S.rw=this.value;R()"><option value=all>همهٔ نیروها</option>${opts(db.workers, S.rw)}</select><div class=r3><select onchange="S.ry=+this.value;R()">${ys.map((y) => `<option ${y == S.ry ? 'selected' : ''} value=${y}>${fa(y)}</option>`).join('')}</select><select onchange="S.rm=+this.value;R()">${MN.map((m, i) => `<option value=${i + 1} ${i + 1 == S.rm ? 'selected' : ''}>${m}</option>`).join('')}</select><div></div></div><div class=r3><input value="${fa(R_.a)}" inputmode=numeric onchange="S.rf=num(this.value)||1;R()"><input value="${fa(R_.b)}" inputmode=numeric onchange="S.rt=num(this.value)||31;R()"><div></div></div><small>از روز / تا روز (ماه ${fa(R_.len)} روز دارد)</small><div class=seg><button class=on2 onclick="exp('pdf')">${ic('pdf')} خروجی PDF</button><button class=on1 onclick="exp('xlsx')">${ic('xls')} خروجی Excel</button></div></div>`
    + (p ? dash(p.isSummary ? ps.slice(1) : ps) : '')
    + (p ? `<div class=card><b>${esc(p.title)}</b><small>${esc(p.sub.join(' | '))}</small>${p.tables.map(tH).join('')}${p.sum.map(([l, v, u], i) => `<div class=row style="margin-top:8px;${i == p.sum.length - 1 ? 'font-weight:700;color:var(--p)' : ''}"><span>${esc(l)}</span><span>${fv(v, u)}</span></div>`).join('')}${ps.length > 1 ? '<small>برای جزئیات هر نیرو، خروجی بگیرید یا نیرو را انتخاب کنید.</small>' : ''}</div>` : '<div class=card>نیرویی ثبت نشده است.</div>');
}
let exporting = false;
async function exp(k) {
  if (exporting) return;
  const ps = buildReports(db, repArgs());
  if (!ps.length) return toast('نیرویی برای گزارش وجود ندارد');
  exporting = true; toast('در حال ساخت فایل…');
  try {
    await new Promise((r) => setTimeout(r, 30)); // اجازهٔ نمایش پیام
    const n = `report-${S.ry}-${pad(S.rm)}${S.rw == 'all' ? '' : '-' + (db.workers.findIndex((w) => w.id == S.rw) + 1)}`;
    await saveFile(n + '.' + k, k == 'pdf' ? toPdf(ps, db.set) : toXlsx(ps, db.set));
  } catch (e) { toast('خطا در ساخت فایل: ' + ((e && e.message) || e)); }
  exporting = false;
}

/* ---------- تنظیمات ---------- */
const sf = (k, l, kind) => `<small style="margin-top:8px">${l}</small><input value="${esc(db.set[k] == null ? '' : db.set[k])}" ${kind == 'num' ? 'inputmode=decimal' : ''} onchange="setS('${k}',this.value,'${kind || 'text'}')">`;
function setS(k, v, kind) {
  if (kind == 'num') {
    v = num(v);
    const ok = k == 'hpd' ? v > 0 && v <= 24 : k == 'of' ? v >= 0 && v <= 10 : v >= 0 && v <= 10;
    if (!ok) { toast('مقدار نامعتبر است'); return R(); }
  }
  db.set[k] = v; save();
}
function vSet() {
  const lb = db.set.lastBackup, days = lb ? Math.floor((Date.now() - lb) / DAY_MS) : null;
  const stale = db.workers.length && (days === null || days >= 14);
  return `${vProf()}<div class=card><b>تنظیم سربرگ گزارش‌ها</b>${sf('h1', 'عنوان اصلی (نام شرکت / کارگاه)')}${sf('h2', 'زیرعنوان')}${sf('h3', 'تلفن / آدرس')}${sf('ft', 'متن پایین صفحه')}<small style="margin-top:8px">رنگ سربرگ</small><input type=color value="${esc(db.set.col)}" onchange="db.set.col=this.value;save();R()"></div>
<div class=card><b>قوانین محاسبه</b>${sf('hpd', 'ساعت کار در روز', 'num')}${sf('lf', 'ضریب کسر تاخیر (۱ = هر ساعت کامل تاخیر معادل یک ساعت دستمزد؛ کمتر از یک ساعت حساب نمی‌شود)', 'num')}${sf('of', 'ضریب اضافه‌کار (مثلاً ۱.۴)', 'num')}</div>
<div class="card${stale ? ' warn' : ''}"><b>بک‌آپ</b><small style="margin-top:6px">${days === null ? 'هنوز بک‌آپ نگرفته‌اید.' : days === 0 ? 'آخرین بک‌آپ: امروز' : 'آخرین بک‌آپ: ' + fa(days) + ' روز پیش'}${stale ? ' — توصیه می‌شود بک‌آپ بگیرید و در تلگرام/ایمیل ذخیره کنید.' : ''}</small><button class=pri onclick="backup()">${ic('save')} گرفتن بک‌آپ</button><label class="pri grn lbl">${ic('up')} بارگذاری فایل بک‌آپ<input type=file accept=".json,application/json" hidden onchange="restore(this)"></label><button class="pri ghost dng" onclick="wipeAll()">پاک‌کردن همه اطلاعات</button></div>${vAbout()}`;
}
const vAbout = () => `<div class=card><div class=hl><img src=icon.png alt="" style="width:56px;height:56px"><div><b style="font-size:17px">RadLedger</b><small>نسخهٔ ${VER}</small></div></div><div class=wr style="margin-top:10px"><small>سازنده</small><b>شهیاد رحمانی</b><a class=btn href="${SUP}" target=_blank rel=noopener>تلگرام: t.me/RadOriginal</a></div></div>`;

/* ---------- راه‌اندازی ---------- */
async function boot() {
  initState();
  const recovered = await loadDb();
  await loadLicense();
  await devCode().catch(() => {});
  PV = L.lic ? await vfy(L.lic) : null;
  L.seen = Math.max(L.seen || 0, Date.now());
  lsave();
  R();
  if (recovered) toast('اطلاعات از نسخهٔ پشتیبان داخلی بازیابی شد');
  syncAndRefresh();
  startPoll();
  document.addEventListener('visibilitychange', () => { if (!document.hidden) syncAndRefresh(); });
  // دکمهٔ بازگشت اندروید
  const A = plug('App');
  if (A && A.addListener) {
    A.addListener('backButton', () => {
      if ($('#sh').innerHTML) return sheet();
      if (lstate().st == 'active' && S.tab != 'cal') return go('cal');
      A.exitApp();
    });
  }
}
