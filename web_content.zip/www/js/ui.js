/* Detox UI helpers: dom, toasts, sheets, confirm, bursts, formatting. */
(function () {
  'use strict';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function ic(name, cls) { return '<svg' + (cls ? ' class="' + cls + '"' : '') + '><use href="#i-' + name + '"/></svg>'; }
  var loc = (navigator.language || 'en-GB');
  function fmtDay(key) { return window.DetoxCore.keyToDate(key).toLocaleDateString(loc, { weekday: 'short', day: 'numeric', month: 'short' }); }
  function fmtDayLong(key) { return window.DetoxCore.keyToDate(key).toLocaleDateString(loc, { weekday: 'long', day: 'numeric', month: 'long' }); }
  function fmtTime(ts) { return new Date(ts).toLocaleTimeString(loc, { hour: '2-digit', minute: '2-digit' }); }
  function fmtStamp(ts) { return new Date(ts).toLocaleDateString(loc, { weekday: 'short', day: 'numeric', month: 'short' }) + ' · ' + fmtTime(ts); }
  function plural(n, w) { return n + ' ' + w + (n === 1 ? '' : 's'); }
  function ago(ms) {
    var c = window.DetoxCore.clock(ms), parts = [];
    if (c.d) parts.push(plural(c.d, 'day'));
    if (c.h) parts.push(plural(c.h, 'hour'));
    if (!c.d && (c.m || !parts.length)) parts.push(plural(c.m, 'minute'));
    return parts.slice(0, 2).join(' and ');
  }

  /* ---------- toasts ---------- */
  function toast(html, o) {
    o = o || {};
    var box = $('#toasts'), t = document.createElement('div');
    t.className = 'toast';
    t.innerHTML = (o.dot ? '<i class="dot" style="background:' + o.dot + ';box-shadow:0 0 12px ' + o.dot + '"></i>' : '') +
      '<div style="flex:1">' + html + '</div>' + (o.action ? '<button>' + esc(o.action) + '</button>' : '');
    box.appendChild(t);
    while (box.children.length > 1) box.firstChild.remove();
    var gone = false;
    function dismiss() {
      if (gone) return; gone = true; t.classList.add('out');
      setTimeout(function () { t.remove(); }, 380);
    }
    if (o.action) $('button', t).onclick = function () { dismiss(); if (o.onAction) o.onAction(); };
    setTimeout(dismiss, o.ms || (o.action ? 6000 : 4200));
    return { dismiss: dismiss };
  }

  /* ---------- bottom sheet ---------- */
  var sheetEl, scrimEl, open = false, onCloseCb = null;
  function initSheet() {
    sheetEl = $('#sheet'); scrimEl = $('#scrim');
    scrimEl.addEventListener('click', function () { sheet.close(); });
  }
  var sheet = {
    isOpen: function () { return open; },
    open: function (o) {
      if (!sheetEl) initSheet();
      if (open) { sheet.close(true); }
      sheetEl.className = 'sheet' + (o.tall ? ' tall' : '') + (o.cls ? ' ' + o.cls : '');
      sheetEl.innerHTML = '<div class="grab"></div><div class="sheet-h"><h2>' + esc(o.title || '') + '</h2>' +
        (o.noClose ? '<span></span>' : '<button class="icon-btn" data-x aria-label="Close">' + ic('close') + '</button>') +
        '</div><div class="sheet-b"></div>';
      var body = $('.sheet-b', sheetEl);
      var x = $('[data-x]', sheetEl); if (x) x.onclick = function () { sheet.close(); };
      onCloseCb = o.onClose || null;
      if (o.build) o.build(body, sheet.close);
      else if (o.html) body.innerHTML = o.html;
      attachDrag();
      requestAnimationFrame(function () { requestAnimationFrame(function () { sheetEl.classList.add('on'); scrimEl.classList.add('on'); }); });
      open = true;
      return body;
    },
    close: function (instant) {
      if (!open) return;
      open = false;
      sheetEl.classList.remove('on'); scrimEl.classList.remove('on');
      var cb = onCloseCb; onCloseCb = null;
      if (cb) { try { cb(); } catch (e) {} }
      if (instant) { sheetEl.innerHTML = ''; }
    }
  };
  function attachDrag() {
    var y0 = null, dy = 0;
    var h = sheetEl;
    function down(e) { if (e.target.closest('.sheet-b') && $('.sheet-b', sheetEl).scrollTop > 0) return; if (e.target.closest('button,input')) return; y0 = e.clientY; dy = 0; sheetEl.style.transition = 'none'; }
    function move(e) { if (y0 == null) return; dy = Math.max(0, e.clientY - y0); sheetEl.style.transform = 'translateY(' + dy + 'px)'; }
    function up() { if (y0 == null) return; sheetEl.style.transition = ''; sheetEl.style.transform = ''; var d = dy; y0 = null; if (d > 110) sheet.close(); }
    $('.grab', h).onpointerdown = down; $('.sheet-h', h).onpointerdown = down;
    window.onpointermove = move; window.onpointerup = up; window.onpointercancel = up;
  }

  /* yes/no sheet; resolves true when confirmed */
  function confirm(o) {
    return new Promise(function (res) {
      var done = false;
      function finish(v) { if (done) return; done = true; sheet.close(); res(v); }
      sheet.open({
        title: o.title, noClose: true, onClose: function () { if (!done) { done = true; res(false); } },
        build: function (body) {
          body.innerHTML = '<p style="font-size:15.5px;line-height:1.55;color:var(--ink-2);margin:2px 0 22px">' + (o.text || '') + '</p>' +
            '<div style="display:flex;flex-direction:column;gap:10px;padding-bottom:6px">' +
            '<button class="btn ' + (o.tone === 'danger' ? 'btn-danger' : 'btn-primary') + '" data-ok>' + esc(o.ok || 'Confirm') + '</button>' +
            '<button class="btn btn-ghost" data-no>' + esc(o.cancel || 'Cancel') + '</button></div>';
          $('[data-ok]', body).onclick = function () { finish(true); };
          $('[data-no]', body).onclick = function () { finish(false); };
        }
      });
    });
  }

  /* little particle burst from a point (viewport coords) */
  function burst(x, y, color, n) {
    var host = $('#app');
    for (var i = 0; i < (n || 14); i++) {
      var d = document.createElement('i');
      d.className = 'burst';
      var s = 5 + Math.random() * 7;
      d.style.cssText = 'left:' + x + 'px;top:' + y + 'px;width:' + s + 'px;height:' + s + 'px;background:' + color + ';box-shadow:0 0 10px ' + color;
      host.appendChild(d);
      var a = Math.random() * Math.PI * 2, r = 50 + Math.random() * 90;
      var an = d.animate([
        { transform: 'translate(-50%,-50%) scale(1)', opacity: 1 },
        { transform: 'translate(' + (Math.cos(a) * r - 4) + 'px,' + (Math.sin(a) * r - 4) + 'px) scale(.2)', opacity: 0 }
      ], { duration: 650 + Math.random() * 350, easing: 'cubic-bezier(.2,.8,.3,1)' });
      an.onfinish = (function (el) { return function () { el.remove(); }; })(d);
    }
  }

  window.UI = { $: $, $$: $$, esc: esc, ic: ic, fmtDay: fmtDay, fmtDayLong: fmtDayLong, fmtTime: fmtTime, fmtStamp: fmtStamp,
    plural: plural, ago: ago, toast: toast, sheet: sheet, confirm: confirm, burst: burst };
})();
