/* Detox P2P: pairing codes, end-to-end encryption (AES-GCM) and a tiny mailbox transport (ntfy.sh).
   Nothing here needs an account or a server of your own. The mailbox only ever sees scrambled text. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(); else root.P2P = factory();
})(this, function () {
  'use strict';
  var DEFAULT_SERVER = 'https://ntfy.sh';
  var fetchImpl = null;

  function cryptoObj() {
    if (typeof globalThis !== 'undefined' && globalThis.crypto && globalThis.crypto.subtle) return globalThis.crypto;
    throw new Error('Secure random numbers are not available on this device');
  }
  function rand(n) { var a = new Uint8Array(n); cryptoObj().getRandomValues(a); return a; }
  function b64e(bytes) {
    var s = '';
    for (var i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
    return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }
  function b64d(str) {
    str = String(str).replace(/-/g, '+').replace(/_/g, '/');
    while (str.length % 4) str += '=';
    var s = atob(str), a = new Uint8Array(s.length);
    for (var i = 0; i < s.length; i++) a[i] = s.charCodeAt(i);
    return a;
  }
  function hexId(n) { var a = rand(n || 8), s = ''; for (var i = 0; i < a.length; i++) s += (a[i] < 16 ? '0' : '') + a[i].toString(16); return s; }

  function newPair() { return { id: b64e(rand(16)), key: b64e(rand(32)) }; }
  function topic(id, dir) { return 'detox-' + id + '-' + dir; }

  /* ---- pairing code: what goes into the QR ---- */
  function enc(s) { return encodeURIComponent(s || '').replace(/\./g, '%2E'); }
  function encode(p) {
    var out = 'DTX1.' + p.id + '.' + p.key + '.' + (p.habit || '') + '.' + enc(p.name);
    if (p.server && p.server !== DEFAULT_SERVER) out += '.' + enc(p.server);
    return out;
  }
  function decode(text) {
    var m = String(text || '').match(/DTX1\.[A-Za-z0-9_-]{22}\.[A-Za-z0-9_-]{43}\.[a-z]*\.[^\s.]*(?:\.[^\s.]+)?/);
    if (!m) return null;
    var parts = m[0].split('.');
    try {
      if (b64d(parts[1]).length !== 16 || b64d(parts[2]).length !== 32) return null;
      var server = parts[5] ? decodeURIComponent(parts[5]) : DEFAULT_SERVER;
      if (!/^https?:\/\/[^\s]+$/i.test(server)) return null;
      return { id: parts[1], key: parts[2], habit: parts[3], name: decodeURIComponent(parts[4] || ''), server: server.replace(/\/+$/, '') };
    } catch (e) { return null; }
  }

  /* ---- encryption: AES-256-GCM, topic name bound in as associated data ---- */
  function aesKey(keyB64, usage) {
    return cryptoObj().subtle.importKey('raw', b64d(keyB64), { name: 'AES-GCM' }, false, [usage]);
  }
  function seal(keyB64, topicName, obj) {
    var iv = rand(12), te = new TextEncoder();
    return aesKey(keyB64, 'encrypt').then(function (k) {
      return cryptoObj().subtle.encrypt({ name: 'AES-GCM', iv: iv, additionalData: te.encode(topicName) }, k, te.encode(JSON.stringify(obj)));
    }).then(function (ct) {
      var c = new Uint8Array(ct), out = new Uint8Array(12 + c.length);
      out.set(iv, 0); out.set(c, 12);
      return b64e(out);
    });
  }
  /* resolves the object, or null when the text is not ours, was changed, or came from the wrong topic */
  function open(keyB64, topicName, text) {
    var raw;
    try { raw = b64d(String(text).trim()); } catch (e) { return Promise.resolve(null); }
    if (raw.length < 29) return Promise.resolve(null);
    return aesKey(keyB64, 'decrypt').then(function (k) {
      return cryptoObj().subtle.decrypt({ name: 'AES-GCM', iv: raw.slice(0, 12), additionalData: new TextEncoder().encode(topicName) }, k, raw.slice(12));
    }).then(function (pt) { return JSON.parse(new TextDecoder().decode(pt)); }, function () { return null; })
      .then(function (o) { return o && typeof o === 'object' ? o : null; }, function () { return null; });
  }

  /* ---- mailbox (ntfy-compatible: POST text to /topic, GET /topic/json?poll=1&since=...) ---- */
  function doFetch(url, opt) {
    var f = fetchImpl || (typeof fetch === 'function' ? fetch.bind(globalThis) : null);
    if (!f) return Promise.reject(new Error('No network'));
    var ctl = typeof AbortController === 'function' ? new AbortController() : null, t = 0;
    if (ctl) { opt.signal = ctl.signal; t = setTimeout(function () { ctl.abort(); }, 12000); }
    return f(url, opt).then(function (r) { clearTimeout(t); return r; }, function (e) { clearTimeout(t); throw e; });
  }
  function send(server, topicName, text) {
    return doFetch((server || DEFAULT_SERVER) + '/' + topicName, { method: 'POST', body: text }).then(function (r) {
      if (!r.ok) throw new Error('Mailbox said ' + r.status);
      return true;
    });
  }
  function pull(server, topicName, since) {
    var url = (server || DEFAULT_SERVER) + '/' + topicName + '/json?poll=1&since=' + (since ? Math.floor(since) : 'all');
    return doFetch(url, { method: 'GET' }).then(function (r) {
      if (!r.ok) throw new Error('Mailbox said ' + r.status);
      return r.text();
    }).then(function (txt) {
      var out = [];
      String(txt).split('\n').forEach(function (line) {
        line = line.trim(); if (!line) return;
        try { var j = JSON.parse(line); if (j.event === 'message' && j.message) out.push({ id: j.id, time: j.time || 0, message: j.message }); } catch (e) {}
      });
      return out;
    });
  }

  return {
    DEFAULT_SERVER: DEFAULT_SERVER, b64e: b64e, b64d: b64d, rand: rand, hexId: hexId,
    newPair: newPair, topic: topic, encode: encode, decode: decode, seal: seal, open: open, send: send, pull: pull,
    setFetch: function (f) { fetchImpl = f; }
  };
});
