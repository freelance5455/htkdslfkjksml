/* Detox QR scanning. Uses the phone's own scanner when the app was built with it, else the browser's
   BarcodeDetector. When neither exists the screens fall back to pasting the code. */
(function () {
  'use strict';
  var $ = UI.$;

  function nativeScanner() { return Native.plugin('BarcodeScanner'); }
  function webOk() { return !!(window.BarcodeDetector && navigator.mediaDevices && navigator.mediaDevices.getUserMedia); }
  function available() { return !!nativeScanner() || webOk(); }

  function viaNative(B) {
    var ready = B.isGoogleBarcodeScannerModuleAvailable ? B.isGoogleBarcodeScannerModuleAvailable() : Promise.resolve({ available: true });
    return Promise.resolve(ready).then(function (r) {
      if (r && r.available === false) {
        if (B.installGoogleBarcodeScannerModule) B.installGoogleBarcodeScannerModule().catch(function () {});
        UI.toast('Getting the scanner ready. Try again in a few seconds, or paste the code.', { dot: '#3f7cff' });
        return null;
      }
      return B.scan({ formats: ['QR_CODE'] }).then(function (res) {
        var b = res && res.barcodes && res.barcodes[0];
        return b ? (b.rawValue || b.displayValue || null) : null;
      });
    });
  }

  function viaWeb() {
    return new Promise(function (resolve) {
      var ov = document.createElement('div'), video = document.createElement('video'), stream = null, stopped = false, det;
      ov.className = 'scan-ov';
      ov.innerHTML = '<div class="scan-box"></div><p>Point the camera at the QR code</p><button class="btn btn-ghost">Cancel</button>';
      video.setAttribute('playsinline', ''); video.muted = true;
      ov.insertBefore(video, ov.firstChild);
      document.body.appendChild(ov);
      function done(v) { if (stopped) return; stopped = true; try { stream && stream.getTracks().forEach(function (t) { t.stop(); }); } catch (e) {} ov.remove(); resolve(v); }
      ov.querySelector('button').onclick = function () { done(null); };
      try { det = new window.BarcodeDetector({ formats: ['qr_code'] }); } catch (e) { return done(null); }
      navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false }).then(function (s) {
        if (stopped) { s.getTracks().forEach(function (t) { t.stop(); }); return; }
        stream = s; video.srcObject = s; return video.play();
      }).then(function () {
        (function loop() {
          if (stopped) return;
          det.detect(video).then(function (r) { if (r && r[0] && r[0].rawValue) done(r[0].rawValue); else setTimeout(loop, 220); }, function () { setTimeout(loop, 400); });
        })();
      }).catch(function () { UI.toast('The camera is not available. Paste the code instead.', { dot: '#ff5d7a' }); done(null); });
    });
  }

  /* resolves the text in the QR code, or null */
  function qr() {
    var B = nativeScanner();
    var p = B ? viaNative(B) : (webOk() ? viaWeb() : Promise.resolve(null));
    return p.catch(function () { UI.toast('Could not scan. Paste the code instead.', { dot: '#ff5d7a' }); return null; });
  }

  window.Scan = { available: available, qr: qr };
})();
