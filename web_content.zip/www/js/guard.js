/* Detox guardian mode: "Go guardian". Watch over someone's timer and press Lapse or Relapse for them.
   Pairing is a QR code (or pasted code); messages travel end-to-end encrypted through a public mailbox. */
(function () {
  'use strict';
  var $ = UI.$, esc = UI.esc, C = DetoxCore;
  var KEY = 'detox.guard.v1', st = { name: '', people: [] };
  var host, mode = 'list', opts = {}, tickT = 0, pollT = 0, busy = false, isOpen = false, cool = {}, draft = { code: '' };

  /* ---------- storage ---------- */
  function save() {
    var raw = JSON.stringify(st);
    try { localStorage.setItem(KEY, raw); } catch (e) {}
    if (Native.prefs) Native.prefs.set(KEY, raw);
  }
  function adopt(raw) {
    try { var j = JSON.parse(raw); if (j && j.people) { st = j; st.name = st.name || ''; return true; } } catch (e) {}
    return false;
  }
  function load() {
    var raw = null;
    try { raw = localStorage.getItem(KEY); } catch (e) {}
    if (raw && adopt(raw)) return Promise.resolve();
    if (Native.prefs) return Native.prefs.get(KEY).then(function (r) { if (r && adopt(r)) { try { localStorage.setItem(KEY, r); } catch (e) {} } }, function () {});
    return Promise.resolve();
  }
  function has() { return st.people.length > 0; }

  /* ---------- talking to the owner's phone ---------- */
  function sendMsg(p, obj) {
    var t = P2P.topic(p.id, 'g');
    return P2P.seal(p.key, t, obj).then(function (m) { return P2P.send(p.server, t, m); });
  }
  function hello(p) {
    p.hiAt = Date.now();
    return sendMsg(p, { v: 1, t: 'hi', at: Date.now(), by: st.name }).catch(function () { p.hiAt = 0; });
  }
  function take(p, o) {
    if (o.t === 'bye') { p.removed = true; return; }
    if (o.t === 'st' && (+o.at || 0) >= (p.snapAt || 0)) {
      p.snapAt = +o.at; p.owner = String(o.owner || p.owner || ''); p.habit = o.habit || p.habit;
      p.lastAt = +o.lastAt || p.lastAt; p.balls = +o.balls || 0; p.best = +o.best || 0;
      var acks = o.acks || [];
      p.outbox.forEach(function (e) { if (acks.indexOf(e.id) >= 0) e.acked = true; });
    }
  }
  function pollPerson(p) {
    var t = P2P.topic(p.id, 'o'), started = Math.floor(Date.now() / 1000);
    return P2P.pull(p.server, t, p.since).then(function (msgs) {
      return msgs.reduce(function (chain, m) {
        return chain.then(function () { return P2P.open(p.key, t, m.message).then(function (o) { if (o) take(p, o); }); });
      }, Promise.resolve());
    }).then(function () { p.since = started - 120; p.online = true; }, function () { p.online = false; });
  }
  function flush(p) {
    var now = Date.now();
    p.outbox = p.outbox.filter(function (e) { return now - e.at < 7 * 864e5 && !(e.acked && now - e.at > 864e5); });
    return p.outbox.reduce(function (chain, e) {
      if (e.acked || (e.sentAt && now - e.sentAt < 15 * 60e3)) return chain;
      return chain.then(function () {
        return sendMsg(p, { v: 1, t: 'ev', id: e.id, kind: e.kind, at: e.at, by: st.name }).then(function () { e.sentAt = Date.now(); }, function () {});
      });
    }, Promise.resolve());
  }
  function poll() {
    if (busy || !has()) return Promise.resolve();
    busy = true;
    return Promise.all(st.people.map(function (p) {
      if (p.removed) return null;
      return pollPerson(p).then(function () {
        var h = (!p.hiAt || Date.now() - p.hiAt > 6 * 3600e3) ? hello(p) : null;
        return Promise.resolve(h).then(function () { return flush(p); });
      });
    })).then(function () { busy = false; save(); if (isOpen && mode === 'list') render(); }, function () { busy = false; });
  }

  /* ---------- adding someone ---------- */
  function connect(codeText, myName) {
    var d = P2P.decode(codeText);
    if (!d) return { ok: false, why: 'That does not look like a Detox code. Ask them to show it again.' };
    if (!myName) return { ok: false, why: 'Add your name first, so they know it was you.' };
    st.name = myName;
    var p = null;
    st.people.forEach(function (x) { if (x.id === d.id) p = x; });
    if (!p) {
      p = { id: d.id, key: d.key, server: d.server, owner: d.name || '', habit: d.habit || '', lastAt: 0, balls: 0, best: 0, snapAt: 0, since: 0, hiAt: 0, removed: false, outbox: [], at: Date.now() };
      st.people.push(p);
    } else { p.removed = false; p.key = d.key; p.server = d.server; }
    save(); hello(p).then(function () { save(); poll(); });
    return { ok: true, person: p };
  }

  /* ---------- pressing the buttons ---------- */
  function press(p, kind) {
    var who = p.owner || 'them', relapse = kind === 'p';
    return UI.confirm({
      title: (relapse ? 'Mark a relapse for ' : 'Mark a lapse for ') + who + '?',
      text: relapse
        ? 'A relapse takes one ball out of their pit and restarts their timer. Only press it if they truly cannot do it themselves. They will see that it was you.'
        : 'A lapse is a slip. A few yellow balls roll into their pit and their timer restarts. They will see that it was you.',
      ok: relapse ? 'Yes, mark a relapse' : 'Yes, mark a lapse', tone: relapse ? 'danger' : 'primary', cancel: 'Not now'
    }).then(function (y) {
      if (!y) return;
      cool[p.id] = Date.now() + 20000;
      var ev = { id: P2P.hexId(8), kind: kind, at: Date.now(), sentAt: 0, acked: false };
      p.outbox.push(ev); save(); Native.haptic('success'); render();
      return sendMsg(p, { v: 1, t: 'ev', id: ev.id, kind: kind, at: ev.at, by: st.name })
        .then(function () { ev.sentAt = Date.now(); }, function () {}).then(function () { save(); if (isOpen) render(); });
    });
  }

  /* ---------- view ---------- */
  function clockText(ms) {
    var c = C.clock(Math.max(0, ms)), z = function (n) { return (n < 10 ? '0' : '') + n; };
    return c.d + 'd ' + z(c.h) + ':' + z(c.m) + ':' + z(c.s);
  }
  function habit(p) { try { return C.habitById(p.habit); } catch (e) { return null; } }
  function note(p) {
    var e = p.outbox[p.outbox.length - 1];
    if (!e) return p.snapAt ? '' : 'Waiting for ' + (p.owner || 'their phone') + ' to open Detox once. Then the clock appears here.';
    var what = e.kind === 'p' ? 'Relapse' : 'Lapse';
    if (e.acked) return what + ' delivered. ' + (p.owner || 'They') + ' has it.';
    if (e.sentAt) return what + ' sent. ' + (p.owner || 'They') + ' will get it the next time they open Detox.';
    return what + ' saved. It will send as soon as you are online.';
  }
  function card(p, i) {
    var h = habit(p), left = (cool[p.id] || 0) - Date.now(), lock = left > 0;
    if (p.removed) {
      return '<article class="gp"><div class="g-top"><div class="g-av empty">!</div><div class="t"><b>' + esc(p.owner || 'Someone') + '</b><span>Removed you as a guardian</span></div></div>' +
        '<div class="g-actions"><button class="btn btn-ghost" data-del="' + i + '">Clear this</button></div></article>';
    }
    var live = p.lastAt > 0;
    return '<article class="gp"><div class="g-top"><div class="g-av">' + esc((p.owner || '?').charAt(0).toUpperCase()) + '</div>' +
      '<div class="t"><b>' + esc(p.owner || 'Someone') + '</b><span>' + (h ? esc(h.name) : '') + (p.balls ? ' · ' + p.balls + ' balls in the pit' : '') + '</span></div></div>' +
      '<div class="gp-time">' + (live ? '<span class="n" data-t="' + i + '">' + clockText(Date.now() - p.lastAt) + '</span><span class="u">' + (h ? esc(h.clean) : 'clean') + ' for</span>'
        : '<span class="u">No update yet</span>') + '</div>' +
      '<div class="gp-btns">' +
      '<button class="orb-btn' + (lock ? ' locked' : '') + '" data-p="y" data-i="' + i + '"' + (lock ? ' disabled' : '') + '><i class="orb yellow"></i><b>Lapse</b><span>YELLOW</span></button>' +
      '<button class="orb-btn' + (lock ? ' locked' : '') + '" data-p="p" data-i="' + i + '"' + (lock ? ' disabled' : '') + '><i class="orb purple"></i><b>Relapse</b><span>PURPLE</span></button></div>' +
      '<p class="gp-note" data-note="' + i + '">' + esc(note(p)) + '</p>' +
      '<p class="gp-foot">' + (p.online === false ? 'Offline. Showing the last update. ' : '') + (p.snapAt ? (Date.now() - p.snapAt < 90000 ? 'Updated just now' : 'Updated ' + UI.ago(Date.now() - p.snapAt) + ' ago') : '') +
      ' <a href="#" data-del="' + i + '">Stop guarding</a></p></article>';
  }
  function listView() {
    var html = '<p class="g-lead">You are guarding ' + (st.people.length === 1 ? 'one person' : st.people.length + ' people') + '. If they cannot press <b>Lapse</b> or <b>Relapse</b> themselves, you can. You can never press <i>Day passed</i>.</p>';
    html += st.people.map(card).join('');
    html += '<button class="btn btn-ghost g-add" data-add>Guard someone else</button>';
    return html;
  }
  function addView() {
    return '<p class="g-lead">Ask them to open Detox, go to <b>Settings, Guardians</b> and tap <b>Invite someone</b>. Then scan the code on their screen.</p>' +
      '<div class="g-card"><div class="g-top"><div class="t"><b>Your name</b><span>So they know it was you</span></div></div>' +
      '<div class="g-form"><input class="field" id="gMy" maxlength="24" placeholder="e.g. Alex" value="' + esc(st.name || '') + '"></div></div>' +
      '<div class="g-card"><div class="g-top"><div class="t"><b>Their code</b><span>Scan it, or paste the text</span></div></div>' +
      (Scan.available() ? '<div class="g-actions"><button class="btn btn-primary" id="gScan">' + UI.ic('qr') + ' Scan their code</button></div>' : '') +
      '<div class="g-form" style="flex-direction:column"><textarea class="field g-code" id="gCode" rows="3" spellcheck="false" autocapitalize="off" autocomplete="off" placeholder="Paste the code here. It starts with DTX1">' + esc(draft.code) + '</textarea>' +
      '<button class="btn btn-primary" id="gGo" style="width:100%">Connect</button></div>' +
      '<p class="note" id="gErr" style="color:#ff8fa6;margin-top:10px" hidden></p></div>' +
      '<p class="note">Only you two can read what is sent. The code holds a secret key that never leaves your phones.</p>';
  }

  function render() {
    if (!host) return;
    var addOnly = !has() || mode === 'add';
    var back = (mode === 'add' && has()) || opts.canClose;
    var h = '<div class="g-head">' + (back ? '<button class="icon-btn" id="gBack" aria-label="Back">' + UI.ic('back') + '</button>' : '<span></span>') +
      '<h1>' + (addOnly ? 'Go guardian' : 'Guardian') + '</h1><span></span></div>';
    h += '<div class="g-body">' + (addOnly ? addView() : listView()) + '</div>';
    if (!opts.hasOwner && !opts.canClose) h += '<div class="g-foot"><button class="btn btn-ghost" id="gOwn">' + (addOnly ? 'I want my own timer instead' : 'I want my own timer too') + '</button></div>';
    var keep = host.scrollTop;
    host.innerHTML = h; host.scrollTop = keep;
    wire();
  }

  function wire() {
    var b = $('#gBack', host);
    if (b) b.onclick = function () { if (mode === 'add' && has()) { mode = 'list'; render(); } else close(); };
    var own = $('#gOwn', host);
    if (own) own.onclick = function () { close(); if (opts.onOwn) opts.onOwn(); };
    UI.$$('[data-add]', host).forEach(function (x) { x.onclick = function () { mode = 'add'; draft.code = ''; render(); }; });
    UI.$$('[data-p]', host).forEach(function (x) {
      x.onclick = function () { var p = st.people[+x.dataset.i]; if (p && (cool[p.id] || 0) < Date.now()) press(p, x.dataset.p); };
    });
    UI.$$('[data-del]', host).forEach(function (x) {
      x.onclick = function (e) {
        e.preventDefault();
        var i = +x.dataset.del, p = st.people[i];
        if (p.removed) { st.people.splice(i, 1); save(); render(); return; }
        UI.confirm({ title: 'Stop guarding ' + esc(p.owner || 'them') + '?', text: 'You will no longer see their timer or be able to press anything for them. They can invite you again.', ok: 'Stop guarding', tone: 'danger' })
          .then(function (y) { if (y) { st.people.splice(i, 1); save(); if (!has()) mode = 'add'; render(); } });
      };
    });
    var go = $('#gGo', host), code = $('#gCode', host), my = $('#gMy', host), err = $('#gErr', host);
    function fail(msg) { err.textContent = msg; err.hidden = false; Native.haptic('error'); }
    function tryConnect(text) {
      var r = connect(text, (my.value || '').trim());
      if (!r.ok) return fail(r.why);
      Native.haptic('success'); draft.code = ''; mode = 'list';
      UI.toast('<b>Connected.</b> You can now see ' + (r.person.owner ? esc(r.person.owner) + "'s" : 'their') + ' timer.', { dot: '#3f7cff' });
      render();
    }
    if (go) go.onclick = function () { draft.code = code.value; tryConnect(code.value); };
    if (code) code.oninput = function () { draft.code = code.value; };
    var sc = $('#gScan', host);
    if (sc) sc.onclick = function () {
      draft.code = code.value;
      Scan.qr().then(function (txt) { if (!txt) return; code.value = txt; draft.code = txt; if ((my.value || '').trim()) tryConnect(txt); else { fail('Add your name, then press Connect.'); my.focus(); } });
    };
  }

  function tick() {
    if (!isOpen) return;
    UI.$$('[data-t]', host).forEach(function (el) { var p = st.people[+el.dataset.t]; if (p && p.lastAt) el.textContent = clockText(Date.now() - p.lastAt); });
    var now = Date.now(), changed = false;
    Object.keys(cool).forEach(function (id) { if (cool[id] <= now) { delete cool[id]; changed = true; } });
    if (changed && mode === 'list') render();
  }

  /* ---------- open / close ---------- */
  function open(o) {
    opts = o || {};
    host = $('#guard'); if (!host) return;
    mode = (opts.add || !has()) ? 'add' : 'list';
    if (opts.code) draft.code = opts.code;
    isOpen = true; host.hidden = false; host.classList.add('on');
    Native.statusBar(true, '#070b25');
    render();
    clearInterval(tickT); clearInterval(pollT);
    tickT = setInterval(tick, 500);
    poll(); pollT = setInterval(function () { if (!document.hidden) poll(); }, 20000);
  }
  function close() {
    isOpen = false; if (host) { host.hidden = true; host.classList.remove('on'); }
    clearInterval(tickT); clearInterval(pollT);
    var day = document.body.classList.contains('is-day');
    Native.statusBar(!day, day ? '#a9dcff' : '#070b25');
    if (opts.onClose) opts.onClose();
  }
  function back() {
    if (!isOpen) return false;
    if (mode === 'add' && has()) { mode = 'list'; render(); } else if (opts.canClose) close(); else return false;
    return true;
  }

  window.Guard = { load: load, has: has, open: open, close: close, back: back, poll: poll, isOpen: function () { return isOpen; }, count: function () { return st.people.length; } };
})();
