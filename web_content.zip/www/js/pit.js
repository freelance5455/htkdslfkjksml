/* Detox ball pit scene: tub, balls, mesh bag, elephant, particles, first-run story. */
(function () {
  'use strict';
  var $ = UI.$, C = DetoxCore;
  var cv, ctx, dpr = 1, W = 0, H = 0, pit = {}, sc = 1, raf = 0, last = 0, active = false, ready = false;
  var lastDir = 1, parts = [], shown = 0, total = 0, prevCols = [], bubbleT = 0, introOn = false, lastBonk = 0, esc = 1;
  var rnd = function (a, b) { return a + Math.random() * (b - a); };
  var LINES = {
    sad: 'Rough one. He is not going anywhere.',
    calm: 'Your elephant is settling in.',
    happy: 'Your elephant is having fun!',
    joy: 'Your elephant is having the time of his life!'
  };

  /* ---------- layout ---------- */
  function layout() {
    var r = $('#pagePit').getBoundingClientRect();
    var nw = Math.round(r.width), nh = Math.round(r.height);
    if (!nw || !nh || (nw === W && nh === H && ready)) return false;
    W = nw; H = nh; dpr = Math.min(window.devicePixelRatio || 1, 2);
    cv.width = W * dpr; cv.height = H * dpr;
    sc = Math.max(.72, Math.min(1.25, Math.min(W / 390, H / 800)));
    esc = sc * .72;
    pit = { left: 12, right: W - 12, top: Math.round(H * .455), floor: Math.round(H * .79), scale: sc };
    var tb = $('.topbar').getBoundingClientRect();
    Bag.setWidth(W);
    Bag.init(W / 2, Math.round(tb.bottom + 12), Math.min(2, dpr), Store.get() ? Store.get().cracks : 0);
    Balls.init(W, H, pit, { onHit: onHit, onSpawn: onSpawn });
    Balls.setLine(pit.floor - 50 * esc);
    Elephant.place(Elephant.state.x < 0 && !Store.get().seen.intro ? -220 : (W / 2), pit.floor + 9 * sc, esc,
      [pit.left + 150 * esc, pit.right - 170 * esc]);
    Elephant.state.env = { onLand: onLand, onToss: onToss };
    return true;
  }

  /* ---------- state -> scene ---------- */
  function counts() { var s = Store.get(); return { b: s.balls.blue, y: s.balls.yellow }; }
  function loadInstant(opts) {
    var s = Store.get(), c = counts();
    opts = opts || {};
    Balls.fill(opts.maxBlue != null ? Math.min(c.b, opts.maxBlue) : c.b, opts.maxBlue != null ? 0 : c.y);
    total = c.b + c.y; shown = opts.maxBlue != null ? Math.min(c.b, opts.maxBlue) : total;
    Bag.setCracks(s.cracks);
    mood(); ui();
  }
  function mood() {
    var s = Store.get(), m = C.mood(s, Date.now());
    Elephant.setMood(m); return m;
  }
  function ui() {
    var s = Store.get(); if (!s) return;
    var n = Math.round(shown);
    $('#ballCount').textContent = n;
    $('#ballLabel').textContent = n === 1 ? 'ball in the pit' : 'balls in the pit';
    $('#moodLine').textContent = LINES[introOn ? 'calm' : C.mood(s, Date.now())];
  }

  /* ---------- elephant + ball callbacks ---------- */
  function onLand(x, y) { Balls.kick(x, y - 8 * sc, 360, 120 * sc); ring(x, y, '#fff'); }
  function onToss(pos, dir) {
    var b = Balls.launch(pos.x, pos.y, dir * rnd(70, 200), -rnd(640, 860));
    if (b) sparks(pos.x, pos.y, '#fff', 8, 90);
  }
  function onHit() {
    var now = performance.now();
    if (now - lastBonk > 900) { lastBonk = now; Elephant.bonk(); var h = Elephant.head(); sparks(h.x, h.y + 40 * sc, '#ffe58a', 8, 100); }
  }
  function onSpawn() { shown = Math.min(total, shown + 1); ui(); }

  /* ---------- particles ---------- */
  function sparks(x, y, color, n, sp) {
    for (var i = 0; i < n; i++) { var a = rnd(0, 6.283), v = rnd(.4, 1) * sp; parts.push({ t: 'p', x: x, y: y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 30, life: 0, max: rnd(.45, .9), c: color, s: rnd(2, 4.2) }); }
  }
  function ring(x, y, c) { parts.push({ t: 'r', x: x, y: y, vx: 0, vy: 0, life: 0, max: .55, c: c || '#fff', s: 8 }); }
  function confetti(x, y, n) {
    var cols = ['#4f8bff', '#ffc933', '#ff7aa8', '#ffffff', '#9b5cff', '#4fd1c5'];
    for (var i = 0; i < n; i++) parts.push({ t: 'c', x: x + rnd(-30, 30), y: y, vx: rnd(-230, 230), vy: rnd(-620, -260), life: 0, max: rnd(1.4, 2.4), c: cols[(Math.random() * cols.length) | 0], s: rnd(5, 9), r: rnd(0, 6), vr: rnd(-9, 9) });
  }
  function drawParts(dt) {
    for (var i = parts.length - 1; i >= 0; i--) {
      var p = parts[i]; p.life += dt;
      if (p.life >= p.max) { parts.splice(i, 1); continue; }
      var k = p.life / p.max;
      if (p.t === 'r') { ctx.globalAlpha = (1 - k) * .8; ctx.strokeStyle = p.c; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(p.x, p.y, p.s + k * 46, 0, 6.283); ctx.stroke(); continue; }
      p.vy += (p.t === 'c' ? 900 : 260) * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.vx *= .992;
      ctx.globalAlpha = p.t === 'c' ? Math.min(1, (1 - k) * 2) : 1 - k;
      ctx.fillStyle = p.c;
      if (p.t === 'c') { p.r += p.vr * dt; ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.r); ctx.fillRect(-p.s / 2, -p.s / 3, p.s, p.s * .6); ctx.restore(); }
      else { ctx.shadowColor = p.c; ctx.shadowBlur = 8; ctx.beginPath(); ctx.arc(p.x, p.y, p.s * (1 - k * .5), 0, 6.283); ctx.fill(); ctx.shadowBlur = 0; }
    }
    ctx.globalAlpha = 1;
  }

  /* ---------- drawing ---------- */
  function rr(x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
  function drawRoom() {
    var y0 = pit.floor + 36 * sc;
    var g = ctx.createLinearGradient(0, y0, 0, H); g.addColorStop(0, '#ecd0a2'); g.addColorStop(1, '#d9aa72');
    ctx.fillStyle = g; ctx.fillRect(0, y0 - 2, W, H - y0 + 2);
    ctx.strokeStyle = 'rgba(120,70,20,.10)'; ctx.lineWidth = 1;
    for (var y = y0 + 22; y < H; y += 26) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke(); }
    var sh = ctx.createLinearGradient(0, y0 - 2, 0, y0 + 22); sh.addColorStop(0, 'rgba(60,30,0,.28)'); sh.addColorStop(1, 'rgba(60,30,0,0)');
    ctx.fillStyle = sh; ctx.fillRect(0, y0 - 2, W, 24);
  }
  function drawBack() {
    var x = pit.left, y = pit.top - 6, w = pit.right - pit.left, h = pit.floor - y;
    var g = ctx.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, '#2c3a9c'); g.addColorStop(1, '#18205f');
    ctx.fillStyle = g; rr(x, y, w, h + 6, 22); ctx.fill();
    var sp = ctx.createRadialGradient(W / 2, pit.floor - 120 * sc, 10, W / 2, pit.floor - 120 * sc, W * .75);
    sp.addColorStop(0, 'rgba(160,190,255,.34)'); sp.addColorStop(1, 'rgba(160,190,255,0)');
    ctx.fillStyle = sp; rr(x, y, w, h + 6, 22); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,.07)';
    for (var yy = y + 26; yy < pit.floor - 10; yy += 34) for (var xx = x + 20 + ((yy / 34) % 2 ? 17 : 0); xx < pit.right - 8; xx += 34) { ctx.beginPath(); ctx.arc(xx, yy, 2, 0, 6.283); ctx.fill(); }
  }
  function drawFront() {
    var f = pit.floor, hgt = 36 * sc;
    // side posts
    [[0, pit.left + 2], [pit.right - 2, W]].forEach(function (p) {
      var g = ctx.createLinearGradient(p[0], 0, p[1], 0); g.addColorStop(0, '#2f3fa8'); g.addColorStop(1, '#1b2569');
      ctx.fillStyle = g; rr(p[0] - 4, pit.top - 20, p[1] - p[0] + 8, f - pit.top + 20 + hgt, 10); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,.18)'; rr(p[0] + 2, pit.top - 16, 3, f - pit.top + 10, 2); ctx.fill();
    });
    // padded slab
    var n = Math.max(4, Math.round(W / 84)), cw = (W - 6) / n;
    for (var i = 0; i < n; i++) {
      var x = 3 + i * cw, g2 = ctx.createLinearGradient(0, f - 2, 0, f + hgt);
      g2.addColorStop(0, '#4a5cd0'); g2.addColorStop(.35, '#2f3fa8'); g2.addColorStop(1, '#161f63');
      ctx.fillStyle = g2; rr(x + 1, f - 3, cw - 2, hgt + 4, 14); ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,.22)'; ctx.lineWidth = 1.5; rr(x + 5, f + 1, cw - 10, hgt - 8, 10); ctx.stroke();
      ctx.fillStyle = 'rgba(255,255,255,.2)'; rr(x + 9, f + 1, cw * .4, 3, 2); ctx.fill();
    }
  }

  function render(dt) {
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, W, H);
    drawRoom(); drawBack();
    Balls.draw(ctx, 0); Elephant.draw(ctx); Balls.draw(ctx, 1);
    drawFront(); Bag.draw(ctx); Balls.draw(ctx, 2); drawParts(dt);
  }

  /* ---------- loop ---------- */
  function frame(t) {
    raf = requestAnimationFrame(frame);
    var dt = Math.min(.033, (t - last) / 1000 || .016); last = t;
    Bag.update(dt);
    // keep the elephant's colliders moving with real velocity
    var cols = Elephant.colliders(), dirNow = Elephant.state.dir;
    if (dirNow !== lastDir || cols.length !== prevCols.length) { prevCols = []; lastDir = dirNow; }
    cols.forEach(function (c, i) {
      var p = prevCols[i];
      c.vx = p ? Math.max(-200, Math.min(200, (c.x - p.x) / dt)) : 0; c.vy = p ? Math.max(-200, Math.min(200, (c.y - p.y) / dt)) : 0;
    });
    prevCols = cols.map(function (c) { return { x: c.x, y: c.y }; });
    Elephant.update(dt, Elephant.state.env);
    Balls.step(dt, cols);
    if (bubbleT > 0) { bubbleT -= dt; placeBubble(); if (bubbleT <= 0) $('#bubble').classList.remove('on'); }
    render(dt);
  }
  function setActive(on) {
    if (!ready) return;
    if (on && !raf) { last = performance.now(); raf = requestAnimationFrame(frame); }
    else if (!on && raf) { cancelAnimationFrame(raf); raf = 0; }
    active = on;
  }

  /* ---------- speech bubble ---------- */
  function placeBubble() {
    var h = Elephant.head(), b = $('#bubble');
    b.style.left = Math.max(78, Math.min(W - 150, h.x)) + 'px'; b.style.top = Math.max(120, h.y - 6) + 'px';
  }
  function say(text, ms) {
    var b = $('#bubble'); b.textContent = text; placeBubble(); b.classList.add('on'); bubbleT = ms ? ms / 1000 : 3.2; Elephant.say(1.4);
  }

  /* ---------- reacting to check-ins ---------- */
  function apply(res, o) {
    o = o || {};
    var s = Store.get();
    total = s.balls.blue + s.balls.yellow;
    if (!ready || o.silent || !active) { loadInstant(); return; }
    if (res.kind === 'b' || (res.kind === 'y' && res.yellow)) {
      var fam = res.kind === 'b' ? 'b' : 'y', n = res.kind === 'b' ? res.blue : res.yellow;
      shown = total - n;
      var m = Bag.open();
      sparks(m.x, m.y, '#fff', 12, 120);
      Balls.rain(fam, n, m.x, m.y + 6, .45, Math.max(.07, Math.min(.12, 1.4 / n)));
      if (res.kind === 'b') {
        Elephant.hop(36); Elephant.setMood(C.mood(s, Date.now()) === 'sad' ? 'calm' : C.mood(s, Date.now()));
        var big = res.bonus > 0 || (res.streak && res.streak % 7 === 0);
        if (big) setTimeout(function () { var h = Elephant.head(); confetti(h.x, h.y, 70); }, 900);
        say(res.bonus ? 'A milestone! Look at all those balls!' : ['Wheee! Thank you!', 'More balls! Best day ever!', 'You did it again!'][(Math.random() * 3) | 0], 3600);
      } else { Elephant.hop(24); say('Yellow balls! Thanks for being honest.', 3600); }
    } else if (res.kind === 'p') {
      var gone = Balls.removeTop(res.removedColor === 'yellow' ? 'y' : 'b');
      if (gone) { sparks(gone.x, gone.y, '#9b5cff', 14, 120); ring(gone.x, gone.y, '#caa2ff'); }
      shown = total; Elephant.setMood('sad'); say("I'm still here. Tomorrow is a fresh start.", 4200);
    } else { shown = total; }
    mood(); ui();
  }

  /* ---------- first visit story ---------- */
  var coachPages = [
    ['Meet your elephant', 'He loves ball pits, and right now this one is a little empty. He is on his way in.'],
    ['Balls fall as you stay strong', 'Every clean day, the mesh bag above cracks open and balls tumble into the pit.'],
    ['More days, more fun', 'The longer you go, the more balls fall, and the more fun he has. Check in every morning at 8:00.']
  ];
  function showCoach(replay, done) {
    var el = $('#coach'), i = 0;
    el.hidden = false;
    function paint() {
      var p = coachPages[i], last_ = i === coachPages.length - 1;
      el.innerHTML = '<div class="step">' + (i + 1) + ' of ' + coachPages.length + '</div><h3>' + p[0] + '</h3><p>' + p[1] + '</p>' +
        (last_ ? '<div class="legend"><div><i class="orb blue"></i>Day passed</div><div><i class="orb yellow"></i>Lapse</div><div><i class="orb purple"></i>Relapse</div></div>' : '') +
        '<div class="foot"><div class="dots">' + coachPages.map(function (_, k) { return '<i class="' + (k === i ? 'on' : '') + '"></i>'; }).join('') + '</div>' +
        '<button class="btn btn-primary" id="coachNext">' + (last_ ? (replay ? 'Close' : "Let's go") : 'Next') + '</button></div>';
      el.style.animation = 'none'; void el.offsetWidth; el.style.animation = '';
      $('#coachNext').onclick = function () {
        Native.haptic('light');
        if (!last_) { i++; paint(); } else { el.hidden = true; if (done) done(); }
      };
    }
    paint();
  }
  function intro() {
    if (introOn || !ready) return; introOn = true;
    var s = Store.get(), c = counts(), seeded = Math.min(3, c.b);
    loadInstant({ maxBlue: seeded });
    var E = Elephant.state; E.x = -230; E.dir = 1; Elephant.setMood('calm'); E.frozen = true;
    setTimeout(function () {
      Elephant.walkTo(W * .42, 78, function () {
        E.frozen = false; Elephant.hop(30); say("Hi! I'm so glad you're here.", 3200);
        setTimeout(function () { showCoach(false, finishIntro); }, 1200);
      });
    }, 700);
  }
  function finishIntro() {
    var s = Store.get(), c = counts(), have = Balls.counts();
    Store.update(function (st) { st.seen.intro = true; });
    introOn = false;
    var needB = c.b - have.b, needY = c.y - have.y;
    if (needB > 0 || needY > 0) {
      total = c.b + c.y; shown = have.b + have.y;
      var m = Bag.open(); sparks(m.x, m.y, '#fff', 14, 120);
      if (needB > 0) Balls.rain('b', needB, m.x, m.y + 6, .5, Math.max(.05, Math.min(.12, 3 / needB)));
      if (needY > 0) Balls.rain('y', needY, m.x, m.y + 6, .5 + needB * .06, .1);
      setTimeout(function () { Elephant.hop(40); mood(); say('Look at all those balls from your clean days!', 3800); }, 1200);
    } else say('See you at 8:00 tomorrow for your first drop!', 3800);
  }
  function replayCoach() { showCoach(true); }

  /* ---------- init ---------- */
  function init() {
    cv = $('#pitCanvas'); ctx = cv.getContext('2d');
    var b = document.createElement('div'); b.className = 'bubble'; b.id = 'bubble'; $('#pagePit').appendChild(b);
    ready = true;
    layout(); refresh();
    if (window.ResizeObserver) new ResizeObserver(function () { if (layout()) refresh(); }).observe($('#pagePit'));
    $('#pitInfo').onclick = replayCoach;
  }
  function refresh() { if (!ready || !Store.get()) return; layout(); loadInstant(); render(.016); }
  function reset() { var E = Elephant.state; E.x = -230; introOn = false; }

  window.Pit = { init: init, refresh: refresh, setActive: setActive, apply: apply, intro: intro, say: say, replayCoach: replayCoach, reset: reset,
    isActive: function () { return active; }, confetti: function () { var h = Elephant.head(); confetti(h.x, h.y, 80); },
    introRunning: function () { return introOn; } };
})();
