/* Detox settings sheet. */
(function () {
  'use strict';
  var C = DetoxCore, $ = UI.$, esc = UI.esc;

  function row(id, title, sub, right, cls) {
    return '<div class="row' + (cls || '') + '" id="' + id + '"><div class="t"><b>' + title + '</b>' + (sub ? '<span>' + sub + '</span>' : '') + '</div>' + (right || '') + '</div>';
  }
  var sw = function (on, id) { return '<div class="switch' + (on ? ' on' : '') + '" data-sw="' + id + '"></div>'; };
  var chev = UI.ic('chev', 'chev');

  function open() {
    UI.sheet.open({ title: 'Settings', tall: true, build: function (b) { paint(b); } });
  }

  function paint(body) {
    var s = Store.get(), h = C.habitById(s.habit), gcount = s.guardians.filter(Boolean).length;
    body.innerHTML =
      '<div class="set-hero"><div class="ic">' + UI.ic(h.id) + '</div><div><b>' + h.name + '</b><span>Last time: ' + UI.fmtStamp(s.lastAt) + '</span></div></div>' +
      '<div class="sec-title">Check-in</div>' +
      row('rReminder', '8:00 reminder', 'A nudge every morning to check in for the day before', sw(s.settings.reminders, 'reminders')) +
      row('rLapse', 'A lapse restarts my timer', 'Off keeps the clock running through a lapse', sw(s.settings.lapseResets, 'lapseResets')) +
      row('rEdit', 'Adjust last time', 'Fix the moment your timer starts from', chev, ' tap') +
      '<div class="sec-title">People</div>' +
      row('rGuard', 'Guardians', gcount ? gcount + ' of 2 connected' : 'Two people who can log a lapse or relapse for you', chev, ' tap') +
      '<div class="sec-title">Protection</div>' +
      row('rNudge', 'Nudge', 'A gentle ball if you linger on adult sites', chev, ' tap') +
      '<div class="sec-title">Learn</div>' +
      row('rHow', 'How the ball pit works', 'Replay the elephant\'s story', chev, ' tap') +
      row('rCol', 'What the three colours mean', '', chev, ' tap') +
      '<div class="sec-title">Reset</div>' +
      row('rReset', '<span class="danger">Start over</span>', 'Erase everything and pick again', '', ' tap') +
      '<div class="ver">Detox 1.1</div>';
    UI.$$('[data-sw]', body).forEach(function (el) {
      el.parentNode.classList.add('tap');
      el.parentNode.onclick = function () {
        var k = el.dataset.sw, v = !Store.get().settings[k];
        Store.update(function (st) { st.settings[k] = v; });
        el.classList.toggle('on', v); Native.haptic('light');
        if (k === 'reminders') {
          if (v) Native.scheduleCheckin('Good morning. Did you stay ' + h.clean + ' yesterday? Tap to check in.').then(function (ok) {
            if (!ok && Native.isNative) UI.toast('Allow notifications for Detox in your phone settings to get the 8:00 nudge.', { dot: '#ffc933', ms: 6000 });
          }); else Native.cancelCheckin();
        }
      };
    });
    $('#rEdit', body).onclick = function () { editTime(); };
    $('#rGuard', body).onclick = function () { Guardians.open(); };
    $('#rNudge', body).onclick = function () { Nudge.open(); };
    Nudge.summary().then(function (t) { var sp = $('#rNudge .t span', body); if (sp) sp.textContent = t; });
    $('#rHow', body).onclick = function () { UI.sheet.close(); App.scrollTo(1).then(function () { Pit.replayCoach(); }); };
    $('#rCol', body).onclick = function () { UI.sheet.close(); setTimeout(Timer.explain, 450); };
    $('#rReset', body).onclick = function () {
      UI.confirm({ title: 'Start over?', text: 'This erases your timer, calendar, balls and guardians on this phone. This cannot be undone.', ok: 'Erase everything', tone: 'danger' })
        .then(function (y) { if (y) App.resetAll(); });
    };
  }

  function editTime() {
    var s = Store.get(), f = Onboarding.toFields(s.lastAt);
    UI.sheet.open({
      title: 'Adjust last time',
      build: function (b) {
        b.innerHTML = '<p style="color:var(--ink-2);font-size:15px;line-height:1.55">When did it last happen? Your calendar and balls are worked out again from this moment. Guardians and settings stay as they are.</p>' +
          '<div class="when-fields"><label><span>Date</span><input class="field" type="date" id="eDate" value="' + f.date + '" max="' + Onboarding.toFields(Date.now()).date + '"></label>' +
          '<label><span>Time</span><input class="field" type="time" id="eTime" value="' + f.time + '"></label></div>' +
          '<div class="when-preview" id="ePrev" style="margin-top:16px"></div>' +
          '<div style="margin-top:18px"><button class="btn btn-primary" id="eSave">Save</button></div>';
        var d = $('#eDate', b), t = $('#eTime', b), pv = $('#ePrev', b), sv = $('#eSave', b);
        function chk() {
          var v = Onboarding.fromFields(d.value, t.value), now = Date.now();
          pv.classList.remove('bad');
          if (isNaN(v)) { sv.disabled = true; pv.textContent = 'Pick a date and time.'; return NaN; }
          if (v > now + 60000) { sv.disabled = true; pv.classList.add('bad'); pv.textContent = "That's in the future."; return NaN; }
          sv.disabled = false; pv.innerHTML = "That's <b>" + UI.ago(now - v) + '</b> ago.'; return v;
        }
        d.oninput = t.oninput = chk; chk();
        sv.onclick = function () {
          var v = chk(); if (isNaN(v)) return;
          var old = Store.get(), n = C.create(old.habit, Math.min(v, Date.now()), Date.now());
          n.settings = old.settings; n.guardians = old.guardians; n.mailbox = old.mailbox; n.server = old.server; n.acct = old.acct; n.ownerName = old.ownerName;
          n.pollSeq = old.pollSeq; n.remoteSeen = old.remoteSeen; n.seen = old.seen;
          Store.set(n, 'edit'); Timer.render(); Pit.refresh(); Sync.push(true);
          UI.sheet.close(); Native.haptic('success'); UI.toast('Timer updated.', { dot: '#3f7cff' });
        };
      }
    });
  }

  window.Settings = { open: open };
})();
