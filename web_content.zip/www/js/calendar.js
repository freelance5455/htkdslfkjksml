/* Detox calendar: your whole time on the app, coloured by day, with a key at the bottom. */
(function () {
  'use strict';
  var C = DetoxCore, $ = UI.$;
  var KIND = { b: 'Day passed', y: 'Lapse', p: 'Relapse' };

  function monthCells(s, y, m, now) {
    var first = new Date(y, m, 1), lead = (first.getDay() + 6) % 7, n = new Date(y, m + 1, 0).getDate(), out = [], i;
    for (i = 0; i < lead; i++) out.push(null);
    for (i = 1; i <= n; i++) {
      var key = C.dayKey(new Date(y, m, i).getTime()), d = C.dayState(s, key, now);
      out.push({ n: i, key: key, d: d });
    }
    return out;
  }

  function cellHtml(c) {
    if (!c) return '<span></span>';
    var d = c.d, cls = ['cell'];
    if (d.st === 'b' || d.st === 'y' || d.st === 'p') cls.push(d.st);
    else if (d.st === 'pending') cls.push('pending');
    else if (d.st === 'none') cls.push('none');
    else if (d.st === 'future') cls.push('future');
    if (d.today) cls.push('today');
    if (d.start) cls.push('start');
    return '<div class="' + cls.join(' ') + '" data-k="' + c.key + '"><span>' + c.n + '</span></div>';
  }

  function open() {
    var s = Store.get(), now = Date.now(), h = C.habitById(s.habit);
    var sd = C.keyToDate(s.startDay), nd = new Date(now);
    var minM = sd.getFullYear() * 12 + sd.getMonth(), maxM = nd.getFullYear() * 12 + nd.getMonth(), cur = maxM;
    var counts = C.counts(s), streak = C.clock(now - s.lastAt).d, best = Math.max(s.best, streak);
    UI.sheet.open({
      title: 'Your journey', tall: true,
      build: function (body) {
        var sheetEl = body.parentNode;
        body.innerHTML =
          '<div class="stats"><div class="stat"><b>' + streak + '</b><span>Streak</span></div><div class="stat"><b>' + best + '</b><span>Best</span></div>' +
          '<div class="stat"><b>' + C.totalBalls(s) + '</b><span>Balls</span></div></div>' +
          '<div class="stats" style="margin-top:0"><div class="stat"><b style="color:#8cc0ff">' + counts.b + '</b><span>Passed</span></div>' +
          '<div class="stat"><b style="color:#ffd977">' + counts.y + '</b><span>Lapses</span></div><div class="stat"><b style="color:#caa2ff">' + counts.p + '</b><span>Relapses</span></div></div>' +
          '<div class="cal-nav"><button class="icon-btn" id="calPrev" aria-label="Previous month">' + UI.ic('back') + '</button><h3 id="calTitle"></h3>' +
          '<button class="icon-btn" id="calNext" aria-label="Next month" style="transform:scaleX(-1)">' + UI.ic('back') + '</button></div>' +
          '<div class="cal-week"><span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span><span>Sun</span></div>' +
          '<div class="cal-grid" id="calGrid"></div>' +
          '<div class="sec-title">Recent</div><div class="log" id="calLog"></div>';
        var key = document.createElement('div');
        key.className = 'key';
        key.innerHTML = '<div><i class="orb blue sm"></i>Day passed</div><div><i class="orb yellow sm"></i>Lapse</div><div><i class="orb purple sm"></i>Relapse</div>' +
          '<div><i class="ring-i"></i>Today</div><div><i class="dash-i"></i>Needs check-in</div><div><i class="dot-i"></i>Start</div>';
        sheetEl.appendChild(key);
        function paint() {
          var y = Math.floor(cur / 12), m = cur % 12;
          $('#calTitle').textContent = new Date(y, m, 1).toLocaleDateString(undefined, { month: 'long', year: 'numeric' });
          $('#calGrid').innerHTML = monthCells(s, y, m, now).map(cellHtml).join('');
          $('#calPrev').disabled = cur <= minM; $('#calNext').disabled = cur >= maxM;
          UI.$$('.cell.pending', body).forEach(function (el) {
            el.onclick = function () { UI.sheet.close(); App.scrollTo(0); };
          });
        }
        $('#calPrev').onclick = function () { if (cur > minM) { cur--; paint(); Native.haptic('light'); } };
        $('#calNext').onclick = function () { if (cur < maxM) { cur++; paint(); Native.haptic('light'); } };
        paint();
        var rows = s.log.slice(-8).reverse().map(function (e) {
          var who = e.by === 'auto' ? 'Carried over' : (e.by && e.by.indexOf('guardian:') === 0 ? 'By ' + UI.esc(e.by.slice(9)) : '');
          var extra = e.kind === 'b' ? '+' + e.add + ' balls' : e.kind === 'y' ? (e.add ? '+' + e.add + ' yellow balls' : 'Timer restarted') : (e.removed ? 'One ball left' : 'Timer restarted');
          var tone = e.kind === 'b' ? 'blue' : e.kind === 'y' ? 'yellow' : 'purple';
          return '<div class="row"><i class="orb ' + tone + ' sm"></i><div class="t"><b>' + KIND[e.kind] + ' · ' + UI.fmtDay(e.day) + '</b><span>' + extra + (who ? ' · ' + who : '') + '</span></div></div>';
        });
        $('#calLog').innerHTML = rows.length ? rows.join('') : '<p class="note" style="margin-top:0">Nothing yet. Your first check-in is at 8:00.</p>';
      },
      onClose: function () { var k = $('.key', $('#sheet')); if (k) setTimeout(function () { k.remove(); }, 500); }
    });
  }

  window.Calendar = { open: open };
})();
