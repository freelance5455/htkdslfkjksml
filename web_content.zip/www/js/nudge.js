/* Detox nudge setup: three screens (what it does, the permission, your list).
   The watching itself happens in the Android app (NudgeService). On the web this only explains it. */
(function () {
  'use strict';
  var $ = UI.$, esc = UI.esc, poll = 0, live = null, onPerm = null;

  function plugin() { return Native.plugin('Nudge'); }
  function status() {
    var P = plugin();
    if (!P) return Promise.resolve({ native: false });
    return P.status().then(function (r) { r.native = true; r.custom = r.custom || []; return r; }, function () { return { native: false }; });
  }
  function fmt(n) { try { return Number(n).toLocaleString(); } catch (e) { return String(n); } }

  function summary() {
    return status().then(function (r) {
      if (!r.native) return 'Works in the Android app';
      if (!r.accessibility) return 'Not set up yet';
      return r.enabled ? 'On · ' + fmt(r.builtIn + r.custom.length) + ' sites' : 'Set up, switched off';
    });
  }

  function dots(n) {
    return '<div class="nz-dots">' + [1, 2, 3].map(function (i) { return '<i' + (i === n ? ' class="on"' : '') + '></i>'; }).join('') + '</div>';
  }

  /* ---------- screen 1: what it does ---------- */
  function s1(body) {
    body.innerHTML = dots(1) + '<div class="nz-hero"><i class="orb blue"></i><span>Please don\'t</span></div>' +
      '<h3 class="nz-h">A nudge, not a wall</h3>' +
      '<p class="nz-p">If you stay on an adult site for a minute or two, a slow ball may drift across your screen with a quiet "Please don\'t" written on it.</p>' +
      '<ul class="nz-list">' +
      '<li><b>It never blocks anything.</b> The page keeps playing underneath. Ignore the ball and it leaves on its own.</li>' +
      '<li><b>Tap it and you go home.</b> Your phone takes you straight back to the home screen.</li>' +
      '<li><b>Not every time.</b> Sometimes nothing happens at all, on purpose, so you can never predict it.</li>' +
      '<li><b>It stays on your phone.</b> Nothing about the sites you visit is sent anywhere.</li></ul>' +
      '<button class="btn btn-primary" id="nzNext" style="width:100%;margin-top:18px">Continue</button>';
    $('#nzNext', body).onclick = function () { s2(body); };
  }

  /* ---------- screen 2: the permission, explained honestly ---------- */
  function s2(body) {
    body.innerHTML = dots(2) +
      '<h3 class="nz-h">One permission, explained</h3>' +
      '<p class="nz-p">Android calls it <b>Accessibility</b>. It is the only way an app can notice which site a browser is on and draw something above other apps.</p>' +
      '<div class="nz-cols"><div><h4>What Detox does</h4><ul><li>Reads the address bar of web browsers. Nothing else on the page</li><li>Draws the ball over your screen</li><li>Presses Home if you tap the ball</li></ul></div>' +
      '<div><h4>What it never does</h4><ul><li>Read passwords, messages or page content</li><li>Take screenshots or record what you type</li><li>Send anything off your phone</li></ul></div></div>' +
      '<p class="note">Android will show a stern warning that the service can "observe your actions" and "retrieve window content". That is the standard wording for every accessibility service.</p>' +
      '<div class="nz-status" id="nzPerm">Checking...</div>' +
      '<button class="btn btn-primary" id="nzOpen" style="width:100%;margin-top:12px">Open Accessibility settings</button>' +
      '<p class="note" style="margin-top:10px">Find <b>Detox nudge</b> (under Installed apps or Downloaded apps) and switch it on.</p>' +
      '<details style="margin-top:6px"><summary>The switch is greyed out or says "restricted"</summary>' +
      '<p class="note" style="margin-top:6px">Android blocks this for apps installed from a file. Open App info, tap the three dots at the top right, choose <b>Allow restricted settings</b>, then try the switch again.</p>' +
      '<button class="btn btn-ghost" id="nzInfo" style="width:100%;margin-top:6px">Open App info</button></details>' +
      '<button class="btn btn-primary" id="nzNext" style="width:100%;margin-top:18px" disabled>Continue</button>' +
      '<button class="ob-link" id="nzBack">Back</button>';
    var P = plugin(), pill = $('#nzPerm', body), next = $('#nzNext', body);
    function look() {
      status().then(function (r) {
        var on = !!r.accessibility;
        pill.className = 'nz-status ' + (on ? 'ok' : 'off');
        pill.textContent = on ? 'Switched on. Thank you.' : 'Not switched on yet';
        next.disabled = !on;
        if (on && !onPerm) { onPerm = true; Native.haptic('success'); }
      });
    }
    onPerm = null; look(); clearInterval(poll); poll = setInterval(look, 1200); live = look;
    $('#nzOpen', body).onclick = function () { if (P) P.openAccessibility().catch(function () {}); };
    $('#nzInfo', body).onclick = function () { if (P) P.openAppInfo().catch(function () {}); };
    $('#nzBack', body).onclick = function () { clearInterval(poll); s1(body); };
    next.onclick = function () {
      clearInterval(poll);
      status().then(function (r) { if (!r.enabled && P) return P.setEnabled({ enabled: true }); }).then(function () { s3(body); });
    };
  }

  /* ---------- screen 3: your list ---------- */
  function s3(body) {
    status().then(function (r) {
      var P = plugin(), custom = r.custom.slice();
      body.innerHTML = dots(3) +
        '<div class="nz-count"><b id="nzCount">' + fmt(r.builtIn + custom.length) + '</b><span>sites on your list</span></div>' +
        '<p class="note" style="text-align:center;margin-top:4px">' + fmt(r.builtIn) + ' come built in from the Block List Project adult list. They are packed inside the app and never leave your phone.</p>' +
        '<div class="row" style="margin-top:12px"><div class="t"><b>Nudge is on</b><span>' + (r.accessibility ? 'Watching your browsers quietly' : 'Needs the Accessibility permission first') + '</span></div>' +
        '<div class="switch' + (r.enabled ? ' on' : '') + '" id="nzSw"></div></div>' +
        '<div class="g-card"><div class="g-top"><div class="t"><b>Add your own sites</b><span>Anything you add is nudged just like the built-in list</span></div></div>' +
        '<div class="g-form"><input class="field" id="nzAdd" inputmode="url" autocapitalize="off" autocomplete="off" placeholder="example.com"><button class="btn btn-primary" id="nzPlus">Add</button></div>' +
        '<div id="nzMine"></div></div>' +
        '<p class="note" style="text-align:center">' + (r.taps ? 'You have tapped the ball ' + r.taps + (r.taps === 1 ? ' time.' : ' times.') + ' Every one counts.' : 'Nobody sees this. It only counts on your phone.') + '</p>' +
        '<button class="btn btn-ghost" id="nzHow" style="width:100%;margin-top:6px">How it works</button>';
      function paintMine() {
        $('#nzMine', body).innerHTML = custom.map(function (d, i) {
          return '<div class="row" style="min-height:46px"><div class="t"><b style="font-weight:500">' + esc(d) + '</b></div><button class="icon-btn" data-rm="' + i + '" aria-label="Remove ' + esc(d) + '">' + UI.ic('close') + '</button></div>';
        }).join('');
        $('#nzCount', body).textContent = fmt(r.builtIn + custom.length);
        UI.$$('[data-rm]', body).forEach(function (b) {
          b.onclick = function () { custom.splice(+b.dataset.rm, 1); save(); };
        });
      }
      function save() {
        if (!P) return;
        P.setCustom({ domains: custom }).then(function (res) { custom = (res && res.custom) || custom; paintMine(); }, function () {});
      }
      paintMine();
      $('#nzPlus', body).onclick = function () {
        var f = $('#nzAdd', body), v = f.value.trim();
        if (!v) return;
        if (!P) { UI.toast('Adding sites works in the Android app.', { dot: '#ffc933' }); return; }
        P.setCustom({ domains: custom.concat([v]) }).then(function (res) {
          var next = (res && res.custom) || custom;
          if (next.length === custom.length) { UI.toast("That doesn't look like a website address. Try something like example.com", { dot: '#ff5d7a' }); Native.haptic('error'); return; }
          custom = next; f.value = ''; Native.haptic('light'); paintMine();
        }, function () {});
      };
      $('#nzSw', body).onclick = function () {
        var el = this, v = !el.classList.contains('on');
        if (!P) return;
        if (v && !r.accessibility) { s2(body); return; }
        P.setEnabled({ enabled: v }).then(function () { el.classList.toggle('on', v); Native.haptic('light'); });
      };
      $('#nzHow', body).onclick = function () { s1(body); };
    });
  }

  function web(body) {
    body.innerHTML = '<div class="nz-hero"><i class="orb blue"></i></div><h3 class="nz-h">A nudge, not a wall</h3>' +
      '<p class="nz-p">If you linger on an adult site, a slow ball drifts across your screen with "Please don\'t" on it. It never blocks anything. Tap it and you go home.</p>' +
      '<p class="note">Watching your browser needs the Android app, because web pages are not allowed to see other apps. Build the APK from the project zip (the README shows how) and this screen turns into the real setup.</p>';
  }

  function open(step) {
    UI.sheet.open({ title: 'Nudge', tall: true, onClose: function () { clearInterval(poll); }, build: function (body) {
      status().then(function (r) {
        if (!r.native) return web(body);
        if (step === 1 || (!step && !r.accessibility)) return s1(body);
        if (step === 2) return s2(body);
        return s3(body);
      });
    } });
  }

  window.Nudge = { open: open, summary: summary, refresh: function () { if (live && UI.sheet.isOpen()) live(); } };
})();
