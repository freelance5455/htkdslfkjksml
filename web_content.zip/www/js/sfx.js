let audioContext=null;
const patterns={
  tap:[[520,.045,0]],card:[[440,.08,0],[660,.09,.07]],magic:[[520,.10,0],[780,.11,.09],[1040,.13,.19]],
  attack:[[190,.08,0],[120,.12,.07],[270,.08,.17]],win:[[523,.12,0],[659,.12,.13],[784,.18,.26],[1046,.28,.43]],
  lose:[[392,.14,0],[330,.16,.15],[262,.24,.32]],reward:[[660,.08,0],[880,.09,.08],[1175,.18,.17]],turn:[[350,.06,0],[470,.08,.08]]
};
function enabled(){try{return JSON.parse(localStorage.getItem('fotoduel_ultra_v3')||'{}').sound!==false}catch{return true}}
export function playSfx(kind='tap'){
  if(!enabled()||typeof window==='undefined')return;
  const Ctx=window.AudioContext||window.webkitAudioContext;if(!Ctx)return;
  try{
    audioContext=audioContext||new Ctx();
    if(audioContext.state==='suspended')audioContext.resume().catch(()=>{});
    const notes=patterns[kind]||patterns.tap,base=audioContext.currentTime;
    for(const [frequency,duration,offset] of notes){
      const osc=audioContext.createOscillator(),gain=audioContext.createGain();
      osc.type=kind==='attack'?'sawtooth':'sine';osc.frequency.setValueAtTime(frequency,base+offset);
      gain.gain.setValueAtTime(.0001,base+offset);gain.gain.exponentialRampToValueAtTime(.075,base+offset+.012);gain.gain.exponentialRampToValueAtTime(.0001,base+offset+duration);
      osc.connect(gain);gain.connect(audioContext.destination);osc.start(base+offset);osc.stop(base+offset+duration+.02);
    }
  }catch{/* Audio is an enhancement; the game remains playable without it. */}
}
