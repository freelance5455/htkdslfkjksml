/* Detox guardian sync: talks to the tiny relay (server/worker.js). Everything is optional and fails quietly offline. */
(function () {
  'use strict';
  var timer = 0, pushT = 0, busy = false, info = { online: null, last: 0 };

  function s() { return Store.get(); }
  function base() { var u = (s() && s().server) || ''; return u.replace(/\/+$/, ''); }
  function enabled() { return !!(base() && s().acct); }

  function call(method, path, body, url) {
    var opt = { method: method, headers: { 'content-type': 'application/json' } };
    if (body) opt.body = JSON.stringify(body);
    var ctl = window.AbortController ? new AbortController() : null;
    if (ctl) { opt.signal = ctl.signal; setTimeout(function () { ctl.abort(); }, 12000); }
    return fetch((url || base()) + path, opt).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) {
        if (!r.ok) { var e = new Error(j.error || ('HTTP ' + r.status)); e.status = r.status; throw e; }
        info.online = true; info.last = Date.now();
        return j;
      });
    }, function (e) { info.online = false; throw e; });
  }
  function normUrl(u) {
    u = (u || '').trim(); if (!u) return '';
    if (!/^https?:\/\//i.test(u)) u = 'https://' + u;
    return u.replace(/\/+$/, '');
  }

  var Sync = {
    info: info, enabled: enabled, normUrl: normUrl,

    ping: function (url) { return call('GET', '/api/ping', null, normUrl(url)).then(function (j) { if (j.name !== 'detox-relay') throw new Error('Not a Detox relay'); return j; }); },

    setServer: function (url) {
      var u = normUrl(url);
      return Sync.ping(u).then(function () {
        Store.update(function (st) { if (st.server !== u) { st.server = u; st.acct = null; st.guardians = [null, null]; st.pollSeq = 0; } });
        Sync.start(); return u;
      });
    },

    register: function () {
      if (s().acct) return Promise.resolve(s().acct);
      return call('POST', '/api/register', { habit: s().habit, owner: s().ownerName || '' }).then(function (j) {
        Store.update(function (st) { st.acct = { id: j.id, key: j.key }; });
        return s().acct;
      });
    },

    invite: function (slot, name) {
      return Sync.register().then(function (a) {
        return call('POST', '/api/invite', { id: a.id, key: a.key, slot: slot, name: name, owner: s().ownerName || '' });
      }).then(function (j) {
        Store.update(function (st) { st.guardians[slot] = { name: name, token: j.token, url: j.url, at: Date.now(), seen: 0 }; });
        Sync.push(true); Sync.start();
        return j;
      });
    },

    revoke: function (slot) {
      var a = s().acct;
      var done = function () { Store.update(function (st) { st.guardians[slot] = null; }); };
      if (!a) { done(); return Promise.resolve(); }
      return call('POST', '/api/revoke', { id: a.id, key: a.key, slot: slot }).then(done, function (e) { if (e.status === 404) done(); else throw e; });
    },

    /* tell the relay where the timer is, so a guardian sees a live clock */
    push: function (now) {
      if (!enabled()) return;
      clearTimeout(pushT);
      pushT = setTimeout(function () {
        var st = s(), a = st.acct; if (!a) return;
        call('POST', '/api/state', { id: a.id, key: a.key, habit: st.habit, owner: st.ownerName || '', lastAt: st.lastAt, balls: DetoxCore.totalBalls(st), best: st.best })
          .catch(function () {});
      }, now ? 50 : 1500);
    },

    /* pick up anything the guardians pressed */
    poll: function () {
      if (!enabled() || busy) return Promise.resolve();
      busy = true;
      var st = s(), a = st.acct;
      return call('GET', '/api/poll?id=' + encodeURIComponent(a.id) + '&key=' + encodeURIComponent(a.key) + '&after=' + (st.pollSeq || 0))
        .then(function (j) {
          var evs = j.events || [], top = st.pollSeq || 0;
          evs.forEach(function (ev) { top = Math.max(top, ev.seq || 0); Timer.applyRemote(ev); });
          Store.update(function (x) {
            x.pollSeq = top;
            (j.guardians || []).forEach(function (g) { if (x.guardians[g.slot]) x.guardians[g.slot].seen = g.seen || 0; });
          }, 'poll');
        }).catch(function () {}).then(function () { busy = false; });
    },

    start: function () {
      clearInterval(timer);
      if (!enabled()) return;
      Sync.poll(); Sync.push(true);
      timer = setInterval(function () { if (!document.hidden) Sync.poll(); }, 20000);
    }
  };
  window.Sync = Sync;
})();
