/* Detox guardian sync (owner side). No server of your own: guardians talk to this phone through
   an encrypted public mailbox (ntfy.sh by default). Everything fails quietly when offline. */
(function () {
  'use strict';
  var timer = 0, pushT = 0, busy = false, ticks = 0, info = { online: null, last: 0 };

  function s() { return Store.get(); }
  function server() { return (s() && s().mailbox) || P2P.DEFAULT_SERVER; }
  function slots() {
    var st = s(); if (!st) return [];
    return st.guardians.map(function (g, i) { return g && g.id ? i : -1; }).filter(function (i) { return i >= 0; });
  }
  function enabled() { return slots().length > 0; }
  function good() { info.online = true; info.last = Date.now(); }
  function bad() { info.online = false; }

  function codeFor(i) {
    var st = s(), g = st && st.guardians[i];
    return g ? P2P.encode({ id: g.id, key: g.key, habit: st.habit, name: st.ownerName || '', server: server() }) : '';
  }

  function invite(slot, name) {
    var p = P2P.newPair();
    Store.update(function (st) { st.guardians[slot] = { name: name, id: p.id, key: p.key, at: Date.now(), seen: 0, since: 0 }; });
    push(true); start();
    return codeFor(slot);
  }

  function revoke(slot) {
    var st = s(), g = st.guardians[slot];
    if (g && g.id) {
      var t = P2P.topic(g.id, 'o');
      P2P.seal(g.key, t, { v: 1, t: 'bye', at: Date.now() }).then(function (m) { return P2P.send(server(), t, m); }).catch(function () {});
    }
    Store.update(function (x) { x.guardians[slot] = null; });
    if (!enabled()) clearInterval(timer);
    return Promise.resolve();
  }

  /* tell the guardians where the timer is, so they see a live clock */
  function push(now) {
    if (!enabled()) return;
    clearTimeout(pushT);
    pushT = setTimeout(function () {
      var st = s(); if (!st) return;
      var snap = { v: 1, t: 'st', at: Date.now(), habit: st.habit, lastAt: st.lastAt, owner: st.ownerName || '',
        balls: DetoxCore.totalBalls(st), best: st.best || 0, acks: (st.remoteSeen || []).slice(-40) };
      slots().forEach(function (i) {
        var g = st.guardians[i], t = P2P.topic(g.id, 'o');
        P2P.seal(g.key, t, snap).then(function (m) { return P2P.send(server(), t, m); }).then(good, bad);
      });
    }, now ? 50 : 1500);
  }

  function handle(i, g, o) {
    if (o.t === 'hi') {
      Store.update(function (st) { var x = st.guardians[i]; if (x && x.id === g.id) x.seen = Math.max(x.seen || 0, +o.at || Date.now()); }, 'seen');
    } else if (o.t === 'ev' && o.id && (o.kind === 'y' || o.kind === 'p')) {
      Timer.applyRemote({ id: String(o.id), kind: o.kind, at: +o.at || Date.now(), by: g.name || 'Guardian' });
      Store.update(function (st) { var x = st.guardians[i]; if (x && x.id === g.id) x.seen = Date.now(); }, 'seen');
    }
  }

  function pollSlot(i) {
    var g = s().guardians[i]; if (!g || !g.id) return Promise.resolve();
    var t = P2P.topic(g.id, 'g'), started = Math.floor(Date.now() / 1000);
    return P2P.pull(server(), t, g.since).then(function (msgs) {
      good();
      return msgs.reduce(function (chain, m) {
        return chain.then(function () {
          return P2P.open(g.key, t, m.message).then(function (o) { if (o) handle(i, g, o); });
        });
      }, Promise.resolve());
    }).then(function () {
      Store.update(function (st) { var x = st.guardians[i]; if (x && x.id === g.id) x.since = started - 120; }, 'poll');
    }, bad);
  }

  function poll() {
    if (!enabled() || busy) return Promise.resolve();
    busy = true;
    return Promise.all(slots().map(pollSlot)).catch(function () {}).then(function () { busy = false; });
  }

  function start() {
    clearInterval(timer);
    if (!enabled()) return;
    poll(); push(true);
    timer = setInterval(function () {
      if (document.hidden) return;
      poll();
      if (++ticks % 45 === 0) push(true);
    }, 20000);
  }

  window.Sync = { info: info, enabled: enabled, codeFor: codeFor, invite: invite, revoke: revoke, push: push, poll: poll, start: start };
})();
