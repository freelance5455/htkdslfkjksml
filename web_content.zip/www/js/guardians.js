/* Detox guardians (owner side): invite up to two people with a QR code. No server to set up. */
(function () {
  'use strict';
  var $ = UI.$, esc = UI.esc, watch = 0;

  function stopWatch() { clearInterval(watch); watch = 0; }

  function open() {
    UI.sheet.open({ title: 'Guardians', tall: true, onClose: stopWatch, build: function (body) { paint(body); } });
  }

  function invMsg(name, code) {
    var s = Store.get(), h = DetoxCore.habitById(s.habit);
    return (s.ownerName ? s.ownerName : 'I') + (s.ownerName ? ' is' : "'m") + ' using Detox to stay ' + h.clean + ' and wants you as a guardian. ' +
      'If they cannot log a lapse or relapse themselves, you can do it for them. In Detox tap "Go guardian" and paste this code: ' + code;
  }

  function slot(s, i, form) {
    var g = s.guardians[i], n = i + 1;
    if (form === i) {
      return '<div class="g-card"><div class="g-top"><div class="g-av empty">' + n + '</div><div class="t"><b>Guardian ' + n + '</b><span>Who is it?</span></div></div>' +
        '<div class="g-form"><input class="field" id="gName' + i + '" maxlength="24" placeholder="Their name"><button class="btn btn-primary" data-create="' + i + '">Invite</button></div></div>';
    }
    if (!g || !g.id) {
      return '<div class="g-card"><div class="g-top"><div class="g-av empty">+</div><div class="t"><b>Guardian ' + n + '</b><span>Not invited yet</span></div></div>' +
        '<div class="g-actions"><button class="btn btn-ghost" data-add="' + i + '">Invite someone</button></div></div>';
    }
    var badge = g.seen ? '<span class="badge ok">connected</span>' : '<span class="badge wait">waiting</span>';
    return '<div class="g-card"><div class="g-top"><div class="g-av">' + esc(g.name.charAt(0).toUpperCase()) + '</div><div class="t"><b>' + esc(g.name) + badge + '</b><span>' +
      (g.seen ? 'Last heard from ' + UI.fmtStamp(g.seen) : 'Waiting for them to scan the code') + '</span></div></div>' +
      '<div class="g-actions"><button class="btn btn-ghost" data-show="' + i + '">' + UI.ic('qr') + ' Show code</button><button class="btn btn-ghost danger" data-del="' + i + '">Remove</button></div></div>';
  }

  function paint(body, form) {
    stopWatch();
    var s = Store.get(), any = Sync.enabled();
    var html = '<p style="color:var(--ink-2);font-size:15px;line-height:1.55">Pick up to two people you trust. If you ever do not have the strength to log a <b>lapse</b> or <b>relapse</b> yourself, they can do it for you. They can never press <i>Day passed</i>.</p>';
    html += '<div class="g-card"><div class="g-top"><div class="t"><b>Your name</b><span>So they know whose timer it is</span></div></div>' +
      '<div class="g-form"><input class="field" id="gOwner" maxlength="24" placeholder="e.g. Sam" value="' + esc(s.ownerName || '') + '"></div></div>';
    html += slot(s, 0, form) + slot(s, 1, form);
    html += '<div class="g-card"><div class="g-top"><div class="g-av empty">' + UI.ic('shield') + '</div><div class="t"><b>Guarding someone else?</b><span>Scan their code and watch over their timer</span></div></div>' +
      '<div class="g-actions"><button class="btn btn-primary" id="gGo">Go guardian</button></div></div>';
    html += '<p class="note">How it works: the QR code holds a secret key that only your two phones know. Messages go through a public mailbox, scrambled so nobody else can read them or press anything. There is no account and no server for you to run.</p>';
    html += '<details style="margin-top:6px"><summary>Advanced</summary><p class="note" style="margin-top:6px">Mailbox address. Leave it alone unless you run your own ntfy server. Change it before inviting anyone.</p>' +
      '<div class="g-form"><input class="field" id="gBox" inputmode="url" autocapitalize="off" autocomplete="off" ' + (any ? 'disabled ' : '') + 'value="' + esc(s.mailbox || P2P.DEFAULT_SERVER) + '"></div></details>';
    body.innerHTML = html;
    wire(body);
  }

  function showCode(body, i) {
    stopWatch();
    var s = Store.get(), g = s.guardians[i]; if (!g) return paint(body);
    var code = Sync.codeFor(i), svg;
    try { svg = QR.svg(code, { ecc: 'M', fg: '#0b1130' }); } catch (e) { svg = ''; }
    body.innerHTML = '<button class="btn btn-ghost" id="gBackList" style="width:auto;height:40px;padding:0 16px;font-size:14px">' + UI.ic('back') + ' Guardians</button>' +
      '<p style="color:var(--ink-2);font-size:15px;line-height:1.55;margin-top:14px">Show this to <b>' + esc(g.name) + '</b>. They open Detox, tap <b>Go guardian</b> and scan it.</p>' +
      '<div class="qr-card">' + svg + '</div><p class="qr-state" id="qrState"></p>' +
      '<div class="g-actions" style="margin-top:14px"><button class="btn btn-primary" id="gShare">' + UI.ic('share') + ' Send code</button><button class="btn btn-ghost" id="gCopy">Copy code</button></div>' +
      '<p class="note">Cannot scan in person? Tap <b>Send code</b> and they can paste it instead. Anyone with this code can act as ' + esc(g.name) + ', so only send it to them.</p>' +
      '<div class="code-line">' + esc(code) + '</div>';
    $('#gBackList', body).onclick = function () { paint(body); };
    $('#gShare', body).onclick = function () {
      Native.share({ title: 'Be my Detox guardian', text: invMsg(g.name, code) }).then(function (r) {
        if (r === 'copied') UI.toast('Invite copied. Paste it into a message.', { dot: '#3f7cff' });
      }, function () {});
    };
    $('#gCopy', body).onclick = function () { Native.copy(code); UI.toast('Code copied.', { dot: '#3f7cff' }); };
    var state = $('#qrState', body), shown = false;
    function look() {
      var x = Store.get().guardians[i];
      if (x && x.seen) {
        if (!shown) { shown = true; Native.haptic('success'); }
        state.className = 'qr-state ok';
        state.textContent = x.name + ' is connected. All set.';
      } else { state.className = 'qr-state'; state.textContent = 'Waiting for ' + g.name + ' to scan...'; }
    }
    look();
    watch = setInterval(function () { Sync.poll().then(look); }, 4000);
  }

  function wire(body) {
    var owner = $('#gOwner', body);
    if (owner) owner.onchange = owner.onblur = function () { Store.update(function (st) { st.ownerName = owner.value.trim(); }); Sync.push(true); };
    var box = $('#gBox', body);
    if (box) box.onchange = function () {
      var v = box.value.trim().replace(/\/+$/, '');
      if (v && !/^https?:\/\//i.test(v)) v = 'https://' + v;
      Store.update(function (st) { st.mailbox = (v && v !== P2P.DEFAULT_SERVER) ? v : ''; });
      box.value = v || P2P.DEFAULT_SERVER;
    };
    $('#gGo', body).onclick = function () {
      UI.sheet.close();
      setTimeout(function () { Guard.open({ canClose: true, hasOwner: true, add: true }); }, 350);
    };
    UI.$$('[data-add]', body).forEach(function (b) { b.onclick = function () { paint(body, +b.dataset.add); var f = $('#gName' + b.dataset.add, body); if (f) f.focus(); }; });
    UI.$$('[data-create]', body).forEach(function (b) {
      b.onclick = function () {
        var i = +b.dataset.create, name = ($('#gName' + i, body).value || '').trim();
        if (!name) { $('#gName' + i, body).focus(); return; }
        var o = $('#gOwner', body); if (o) Store.update(function (st) { st.ownerName = o.value.trim(); });
        try { Sync.invite(i, name); } catch (e) { UI.toast('Could not create the invite on this device.', { dot: '#ff5d7a' }); return; }
        Native.haptic('success'); showCode(body, i);
      };
    });
    UI.$$('[data-show]', body).forEach(function (b) { b.onclick = function () { showCode(body, +b.dataset.show); }; });
    UI.$$('[data-del]', body).forEach(function (b) {
      b.onclick = function () {
        var i = +b.dataset.del, g = Store.get().guardians[i];
        UI.confirm({ title: 'Remove ' + esc(g.name) + '?', text: 'They will no longer see your timer, and anything they send is ignored.', ok: 'Remove', tone: 'danger' }).then(function (y) {
          if (!y) return;
          Sync.revoke(i).then(function () { UI.sheet.open({ title: 'Guardians', tall: true, onClose: stopWatch, build: function (bd) { paint(bd); } }); });
        });
      };
    });
  }

  window.Guardians = { open: open };
})();
