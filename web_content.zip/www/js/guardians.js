/* Detox guardians UI: invite up to two people who can press Lapse / Relapse for you. */
(function () {
  'use strict';
  var $ = UI.$, esc = UI.esc;

  function invMsg(name, g) {
    var s = Store.get(), h = DetoxCore.habitById(s.habit);
    return (s.ownerName ? s.ownerName : 'I') + (s.ownerName ? ' is' : "'m") + ' using Detox to stay ' + h.clean + ' and asked you to be a guardian. ' +
      "You can mark a lapse or relapse if they can't. Open this link, no app needed: ";
  }

  function open() {
    UI.sheet.open({ title: 'Guardians', tall: true, build: function (body) { paint(body); } });
  }

  function paint(body, form) {
    var s = Store.get(), on = Sync.enabled() || !!s.server;
    var html = '<p style="color:var(--ink-2);font-size:15px;line-height:1.55">Pick up to two people you trust. If you ever do not have the strength to log a <b>lapse</b> or <b>relapse</b> yourself, they can do it for you. They can never press <i>Day passed</i>.</p>';
    html += '<div class="g-card"><div class="g-top"><div class="t"><b>Your name</b><span>So they know whose timer it is</span></div></div>' +
      '<div class="g-form"><input class="field" id="gOwner" maxlength="24" placeholder="e.g. Sam" value="' + esc(s.ownerName || '') + '"></div></div>';
    if (!s.server) {
      html += setupCard();
    } else {
      html += '<p class="note" style="margin-top:12px">Relay: <b style="color:var(--ink-2)">' + esc(s.server.replace(/^https?:\/\//, '')) + '</b> ' +
        (Sync.info.online === false ? '<span class="badge wait">offline</span>' : '<span class="badge ok">connected</span>') +
        ' <a href="#" id="gChange" style="color:var(--blue-2)">change</a></p>';
      [0, 1].forEach(function (i) { html += slot(s, i, form); });
    }
    html += '<p class="note">Guardians open a private link in their browser. When they press a button, your timer and pit update the next time Detox checks in (about every 20 seconds while it is open).</p>';
    body.innerHTML = html;
    wire(body);
  }

  function setupCard() {
    return '<div class="g-card"><div class="g-top"><div class="g-av empty">+</div><div class="t"><b>Connect your relay</b><span>One free, five-minute setup</span></div></div>' +
      '<div class="g-form"><input class="field" id="gServer" inputmode="url" autocapitalize="off" autocomplete="off" placeholder="https://detox-relay.you.workers.dev"><button class="btn btn-primary" id="gConnect">Connect</button></div>' +
      '<details style="margin-top:12px"><summary>How do I get a relay?</summary><ol class="steps">' +
      '<li>Make a free account at <code>cloudflare.com</code> and open <b>Workers &amp; Pages</b>.</li>' +
      '<li>Create a Worker, press <b>Edit code</b>, and paste in the file <code>server/worker.js</code> from the Detox zip. Deploy.</li>' +
      '<li>In the Worker settings, add a <b>KV namespace</b> binding named <code>DETOX</code>.</li>' +
      '<li>Copy the Worker address (ends in <code>workers.dev</code>) and paste it above.</li></ol></details></div>';
  }

  function slot(s, i, form) {
    var g = s.guardians[i], n = i + 1;
    if (form === i) {
      return '<div class="g-card"><div class="g-top"><div class="g-av empty">' + n + '</div><div class="t"><b>Guardian ' + n + '</b><span>Who is it?</span></div></div>' +
        '<div class="g-form"><input class="field" id="gName' + i + '" maxlength="24" placeholder="Their name"><button class="btn btn-primary" data-create="' + i + '">Invite</button></div></div>';
    }
    if (!g) {
      return '<div class="g-card"><div class="g-top"><div class="g-av empty">+</div><div class="t"><b>Guardian ' + n + '</b><span>Not invited yet</span></div></div>' +
        '<div class="g-actions"><button class="btn btn-ghost" data-add="' + i + '">Invite someone</button></div></div>';
    }
    var seen = g.seen ? '<span class="badge ok">opened</span>' : '<span class="badge wait">invited</span>';
    return '<div class="g-card"><div class="g-top"><div class="g-av">' + esc(g.name.charAt(0).toUpperCase()) + '</div><div class="t"><b>' + esc(g.name) + seen + '</b><span>' +
      (g.seen ? 'Last opened ' + UI.fmtStamp(g.seen) : 'Waiting for them to open the link') + '</span></div></div>' +
      '<div class="g-actions"><button class="btn btn-ghost" data-share="' + i + '">' + UI.ic('share') + ' Share link</button><button class="btn btn-ghost danger" data-del="' + i + '">Remove</button></div></div>';
  }

  function wire(body) {
    var owner = $('#gOwner', body);
    if (owner) owner.onchange = owner.onblur = function () { Store.update(function (st) { st.ownerName = owner.value.trim(); }); Sync.push(true); };
    var conn = $('#gConnect', body);
    if (conn) conn.onclick = function () {
      var v = $('#gServer', body).value; if (!v.trim()) return;
      conn.disabled = true; conn.textContent = 'Checking...';
      Sync.setServer(v).then(function () { Native.haptic('success'); paint(body); }, function () {
        conn.disabled = false; conn.textContent = 'Connect'; Native.haptic('error');
        UI.toast("Couldn't reach that relay. Check the address and that it is deployed.", { dot: '#ff5d7a' });
      });
    };
    var ch = $('#gChange', body);
    if (ch) ch.onclick = function (e) {
      e.preventDefault();
      UI.confirm({ title: 'Change relay?', text: 'Your current guardians will be disconnected and will need new invites.', ok: 'Change', tone: 'danger' }).then(function (y) {
        if (y) { Store.update(function (st) { st.server = ''; st.acct = null; st.guardians = [null, null]; st.pollSeq = 0; }); Sync.start(); UI.sheet.open({ title: 'Guardians', tall: true, build: function (bd) { paint(bd); } }); }
      });
    };
    UI.$$('[data-add]', body).forEach(function (b) { b.onclick = function () { paint(body, +b.dataset.add); var f = $('#gName' + b.dataset.add, body); if (f) f.focus(); }; });
    UI.$$('[data-create]', body).forEach(function (b) {
      b.onclick = function () {
        var i = +b.dataset.create, name = ($('#gName' + i, body).value || '').trim();
        if (!name) { $('#gName' + i, body).focus(); return; }
        b.disabled = true; b.textContent = '...';
        Sync.invite(i, name).then(function (j) { Native.haptic('success'); paint(body); share(i); }, function () {
          b.disabled = false; b.textContent = 'Invite'; Native.haptic('error');
          UI.toast("Couldn't create the invite. Are you online?", { dot: '#ff5d7a' });
        });
      };
    });
    UI.$$('[data-share]', body).forEach(function (b) { b.onclick = function () { share(+b.dataset.share); }; });
    UI.$$('[data-del]', body).forEach(function (b) {
      b.onclick = function () {
        var i = +b.dataset.del, g = Store.get().guardians[i];
        UI.confirm({ title: 'Remove ' + esc(g.name) + '?', text: 'Their link stops working straight away.', ok: 'Remove', tone: 'danger' }).then(function (y) {
          if (!y) return;
          Sync.revoke(i).then(function () { UI.sheet.open({ title: 'Guardians', tall: true, build: function (bd) { paint(bd); } }); }, function () { UI.toast("Couldn't remove them right now. Try again online.", { dot: '#ff5d7a' }); });
        });
      };
    });
  }

  function share(i) {
    var g = Store.get().guardians[i]; if (!g) return;
    Native.share({ title: 'Be my Detox guardian', text: invMsg(g.name, g), url: g.url }).then(function (r) {
      if (r === 'copied') UI.toast('Invite copied. Paste it into a message.', { dot: '#3f7cff' });
    }, function () {});
  }

  window.Guardians = { open: open };
})();
