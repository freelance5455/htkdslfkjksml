/* Detox onboarding: what do you want to quit, then when did you last do it. */
(function () {
  'use strict';
  var $ = UI.$, C = DetoxCore;
  var WHEN = {
    scroll: 'When did you last<br><em>scroll</em>?',
    fap: 'When was the<br><em>last time</em>?',
    booze: 'When did you last<br><em>drink</em>?',
    drugs: 'When did you last<br><em>use</em>?'
  };
  var ICON = { scroll: 'scroll', fap: 'fap', booze: 'booze', drugs: 'drugs' };
  var pad = function (n) { return (n < 10 ? '0' : '') + n; };
  function toFields(ts) {
    var d = new Date(ts);
    return { date: d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()), time: pad(d.getHours()) + ':' + pad(d.getMinutes()) };
  }
  function fromFields(date, time) {
    var p = (date || '').split('-'), t = (time || '').split(':');
    if (p.length !== 3 || t.length < 2) return NaN;
    return new Date(+p[0], +p[1] - 1, +p[2], +t[0], +t[1]).getTime();
  }

  function run(opts) {
    opts = opts || {};
    return new Promise(function (resolve) {
      var root = $('#onboard'), stepA = $('#obHabit'), stepB = $('#obWhen');
      var picked = opts.habit || null, ts = Date.now();
      root.hidden = false; root.classList.remove('leaving');
      stepA.hidden = false; stepB.hidden = true; stepA.classList.remove('out');

      /* step 1: habits */
      var list = $('#habitList'), next = $('#habitNext');
      list.innerHTML = C.HABITS.map(function (h) {
        return '<button class="habit' + (picked === h.id ? ' sel' : '') + '" data-id="' + h.id + '">' +
          '<span class="ic">' + UI.ic(ICON[h.id]) + '</span>' +
          '<span class="tx"><b>' + h.name + '</b><span>' + h.tag + '</span></span>' +
          '<span class="ck">' + UI.ic('check') + '</span></button>';
      }).join('');
      next.disabled = !picked;
      UI.$$('.habit', list).forEach(function (b) {
        b.onclick = function () {
          picked = b.dataset.id;
          UI.$$('.habit', list).forEach(function (x) { x.classList.toggle('sel', x === b); });
          next.disabled = false;
          Native.haptic('medium');
        };
      });
      next.onclick = function () {
        if (!picked) return;
        Native.haptic('light');
        stepA.classList.add('out');
        setTimeout(function () { stepA.hidden = true; showWhen(); }, 360);
      };

      /* step 2: when */
      var dEl = $('#whenDate'), tEl = $('#whenTime'), prev = $('#whenPreview'), go = $('#whenGo'), chips = $('#whenChips');
      function showWhen() {
        $('#whenTitle').innerHTML = WHEN[picked];
        stepB.hidden = false; stepB.style.animation = 'none'; void stepB.offsetWidth; stepB.style.animation = '';
        var now = Date.now();
        dEl.max = toFields(now).date;
        setTs(opts.lastAt || now);
        chips.innerHTML = [['Just now', 0], ['Earlier today', 3 * 3600e3], ['Yesterday', 864e5], ['3 days ago', 3 * 864e5],
          ['A week ago', 7 * 864e5], ['A month ago', 30 * 864e5]].map(function (c, i) {
          return '<button class="chip" data-ms="' + c[1] + '">' + c[0] + '</button>';
        }).join('');
        UI.$$('.chip', chips).forEach(function (b) {
          b.onclick = function () { setTs(Date.now() - (+b.dataset.ms)); Native.haptic('light'); mark(b); };
        });
      }
      function mark(b) { UI.$$('.chip', chips).forEach(function (x) { x.classList.toggle('on', x === b); }); }
      function setTs(v) {
        ts = v; var f = toFields(v); dEl.value = f.date; tEl.value = f.time; refresh();
      }
      function refresh() {
        var v = fromFields(dEl.value, tEl.value), now = Date.now();
        prev.classList.remove('bad');
        if (isNaN(v)) { go.disabled = true; prev.textContent = 'Pick a date and a time.'; return; }
        if (v > now + 60000) {
          go.disabled = true; prev.classList.add('bad');
          prev.textContent = "That's in the future. Pick a moment that has already happened.";
          return;
        }
        ts = Math.min(v, now); go.disabled = false;
        var ms = now - ts;
        prev.innerHTML = ms < 90000 ? 'Starting <b>right now</b>. Day one begins here.' :
          "That's <b>" + UI.ago(ms) + '</b> ago. Your timer starts from there.';
      }
      dEl.oninput = tEl.oninput = function () { mark(null); refresh(); };
      $('#whenBack').onclick = function () {
        stepB.hidden = true; stepA.hidden = false; stepA.classList.remove('out');
        stepA.style.animation = 'none'; void stepA.offsetWidth; stepA.style.animation = '';
      };
      go.onclick = function () {
        refresh(); if (go.disabled) return;
        Native.haptic('success');
        resolve({ habit: picked, lastAt: ts });
      };
    });
  }

  function leave() {
    var root = $('#onboard');
    root.classList.add('leaving');
    setTimeout(function () { root.hidden = true; }, 650);
  }

  window.Onboarding = { run: run, leave: leave, toFields: toFields, fromFields: fromFields };
})();
