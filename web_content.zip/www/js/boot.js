// Entry bootstrap shared by the HTML-to-APK root page and the Capacitor www page.
function memoryStorage() {
  const values = new Map();
  return {
    getItem: key => values.has(String(key)) ? values.get(String(key)) : null,
    setItem: (key, value) => values.set(String(key), String(value)),
    removeItem: key => values.delete(String(key)),
    clear: () => values.clear(),
    key: index => Array.from(values.keys())[index] ?? null,
    get length() { return values.size; }
  };
}

function prepareStorage() {
  try {
    const store = window.localStorage;
    const key = '__fotoduel_storage_test__';
    store.setItem(key, '1');
    store.removeItem(key);
    return true;
  } catch {
    try {
      Object.defineProperty(window, 'localStorage', { configurable: true, value: memoryStorage() });
      return false;
    } catch {
      return false;
    }
  }
}

function showStartupError(error) {
  const old = document.getElementById('fotoduel-startup-error');
  if (old) old.remove();
  const panel = document.createElement('section');
  panel.id = 'fotoduel-startup-error';
  panel.style.cssText = 'position:fixed;z-index:99999;inset:12px;overflow:auto;padding:20px;border:1px solid #d6a84c;border-radius:16px;background:#111a2d;color:#f4f6ff;font:14px/1.55 system-ui,sans-serif;box-shadow:0 12px 50px #000b';
  const title = document.createElement('h2'); title.textContent = 'O FOTO DUEL encontrou um erro ao iniciar.';
  const detail = document.createElement('pre'); detail.style.cssText = 'white-space:pre-wrap;overflow-wrap:anywhere;color:#ffbfca;font-size:12px';
  detail.textContent = String(error?.stack || error?.message || error || 'Erro desconhecido');
  const help = document.createElement('p'); help.textContent = 'Confira se o conversor incluiu as pastas www e src e se o APK permite JavaScript e armazenamento local.';
  panel.append(title, detail, help); document.body.append(panel);
  console.error('[FOTO DUEL startup]', error);
}

window.addEventListener('error', event => {
  if (event?.error) showStartupError(event.error);
});
window.addEventListener('unhandledrejection', event => {
  showStartupError(event?.reason || 'Falha assíncrona desconhecida');
});

const persistentStorage = prepareStorage();
try {
  await import('./main.js');
  document.documentElement.dataset.fotoduelState = 'ready';
  if (!persistentStorage) {
    const note = document.createElement('div');
    note.textContent = 'Aviso: este APK bloqueou o armazenamento permanente. O progresso pode ser perdido ao fechar o aplicativo.';
    note.style.cssText = 'position:fixed;z-index:60;left:8px;right:8px;bottom:72px;padding:10px;border:1px solid #d2a44c;border-radius:9px;background:#231d12;color:#ffdf9b;font:11px/1.4 system-ui,sans-serif;text-align:center';
    document.body.append(note);
  }
} catch (error) {
  showStartupError(error);
}
