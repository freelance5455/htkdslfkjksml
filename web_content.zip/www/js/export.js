/* ============================================================
   RadLedger — خروجی PDF و Excel (بدون کتابخانهٔ خارجی)
   ============================================================ */
'use strict';

/* ---------- PDF: هر صفحه یک canvas → JPEG → PDF ---------- */
function toPdf(pages, set) {
  const W = 1240, H = 1754, M = 50, cvs = [];
  let c, x, y;
  const font = (b, s) => `${b ? 'bold ' : ''}${s}px Vazirmatn,Tahoma,sans-serif`;
  const newPage = () => {
    c = document.createElement('canvas'); c.width = W; c.height = H;
    x = c.getContext('2d');
    x.fillStyle = '#fff'; x.fillRect(0, 0, W, H);
    x.direction = 'rtl'; x.textBaseline = 'middle';
    cvs.push(c);
    x.fillStyle = set.col; x.fillRect(0, 0, W, 150);
    x.fillStyle = '#fff'; x.textAlign = 'center';
    x.font = font(1, 44); x.fillText(set.h1 || '', W / 2, 50);
    x.font = font(0, 26); x.fillText(set.h2 || '', W / 2, 98);
    x.font = font(0, 20); x.fillText(set.h3 || '', W / 2, 130);
    x.fillStyle = '#666'; x.font = font(0, 20);
    x.fillText((set.ft ? set.ft + '  —  ' : '') + 'صفحه ' + fa(cvs.length), W / 2, H - 30);
    y = 180;
  };
  const cell = (s, cx, cy, w, b) => {
    let z = 24;
    do { x.font = font(b, z--); } while (x.measureText(s).width > w - 8 && z > 11);
    x.textAlign = 'center'; x.fillText(s, cx, cy);
  };
  const rowF = (r, ws, tot, fill, col, b) => {
    let rt = W - M;
    x.fillStyle = fill; x.fillRect(M, y, W - 2 * M, 44);
    r.forEach((v, i) => {
      const w = (ws[i] / tot) * (W - 2 * M);
      x.strokeStyle = '#bbb'; x.strokeRect(rt - w, y, w, 44);
      x.fillStyle = col; cell(cv(v), rt - w / 2, y + 23, w, b);
      rt -= w;
    });
    y += 44;
  };
  pages.forEach((p) => {
    newPage();
    x.fillStyle = '#111'; x.textAlign = 'right'; x.font = font(1, 34); x.fillText(p.title, W - M, y + 14); y += 44;
    x.font = font(0, 22); x.fillStyle = '#444';
    p.sub.forEach((s) => { x.fillText(s, W - M, y + 10); y += 32; });
    y += 10;
    p.tables.forEach((t) => {
      if (y > H - 200) newPage();
      if (t.t) { x.fillStyle = '#111'; x.textAlign = 'right'; x.font = font(1, 28); x.fillText(t.t, W - M, y + 14); y += 40; }
      const ws = t.h.map((h, i) => Math.min(16, Math.max(5, ...[h, ...t.r.map((q) => cv(q[i]))].map((s) => String(s).length))));
      const tot = ws.reduce((a, b) => a + b, 0);
      const hd = () => rowF(t.h, ws, tot, set.col, '#fff', 1);
      hd();
      t.r.forEach((r, i) => { if (y > H - 120) { newPage(); hd(); } rowF(r, ws, tot, i % 2 ? '#f3f3fa' : '#fff', '#111', 0); });
      t.f.forEach((r) => { if (y > H - 120) { newPage(); hd(); } rowF(r, ws, tot, '#e4e4f4', '#111', 1); });
      y += 30;
    });
    if (y > H - 100 - p.sum.length * 50) newPage();
    p.sum.forEach(([l, v, u], i) => {
      const last = i == p.sum.length - 1;
      x.fillStyle = last ? set.col : '#f3f3fa'; x.fillRect(M, y, W - 2 * M, 46);
      x.fillStyle = last ? '#fff' : '#111'; x.font = font(last, 26);
      x.textAlign = 'right'; x.fillText(l, W - M - 14, y + 24);
      x.textAlign = 'left'; x.fillText(fv(v, u), M + 14, y + 24);
      y += 50;
    });
  });

  // اسمبل PDF
  const enc = new TextEncoder(), P = [], O = [];
  let off = 0;
  const push = (b) => { if (typeof b == 'string') b = enc.encode(b); P.push(b); off += b.length; };
  const obj = (n, s) => { O[n] = off; push(n + ' 0 obj\n' + s + '\nendobj\n'); };
  const N = cvs.length;
  push('%PDF-1.4\n');
  obj(1, '<</Type/Catalog/Pages 2 0 R>>');
  obj(2, '<</Type/Pages/Kids[' + cvs.map((_, i) => 3 + i * 3 + ' 0 R').join(' ') + ']/Count ' + N + '>>');
  cvs.forEach((cv_, i) => {
    const b = 3 + i * 3, j = Uint8Array.from(atob(cv_.toDataURL('image/jpeg', 0.9).split(',')[1]), (ch) => ch.charCodeAt(0));
    obj(b, `<</Type/Page/Parent 2 0 R/MediaBox[0 0 595 842]/Resources<</XObject<</I ${b + 1} 0 R>>>>/Contents ${b + 2} 0 R>>`);
    O[b + 1] = off;
    push(`${b + 1} 0 obj\n<</Type/XObject/Subtype/Image/Width ${cv_.width}/Height ${cv_.height}/ColorSpace/DeviceRGB/BitsPerComponent 8/Filter/DCTDecode/Length ${j.length}>>\nstream\n`);
    push(j); push('\nendstream\nendobj\n');
    const q = 'q 595 0 0 842 0 0 cm /I Do Q';
    obj(b + 2, `<</Length ${q.length}>>\nstream\n${q}\nendstream`);
  });
  const xr = off, tt = 3 * N + 3;
  push('xref\n0 ' + tt + '\n0000000000 65535 f \n');
  for (let i = 1; i < tt; i++) push(String(O[i]).padStart(10, '0') + ' 00000 n \n');
  push(`trailer\n<</Size ${tt}/Root 1 0 R>>\nstartxref\n${xr}\n%%EOF`);
  return new Blob(P, { type: 'application/pdf' });
}

/* ---------- ZIP (بدون فشرده‌سازی) + CRC32 ---------- */
const crcT = (() => { const t = []; for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
const crc32 = (b) => { let c = -1; for (let i = 0; i < b.length; i++) c = crcT[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ -1) >>> 0; };
function zip(files) {
  const e = new TextEncoder(), u2 = (n) => [n & 255, (n >> 8) & 255], u4 = (n) => [n & 255, (n >> 8) & 255, (n >> 16) & 255, (n >>> 24) & 255];
  const Lc = [], Cd = [];
  let o = 0;
  for (const [n, s] of files) {
    const nb = e.encode(n), d = e.encode(s), c = crc32(d);
    const h = [0x50, 0x4b, 3, 4, 20, 0, 0, 8, 0, 0, 0, 0, 33, 0, ...u4(c), ...u4(d.length), ...u4(d.length), ...u2(nb.length), 0, 0];
    Lc.push(new Uint8Array(h), nb, d);
    Cd.push(new Uint8Array([0x50, 0x4b, 1, 2, 20, 0, 20, 0, 0, 8, 0, 0, 0, 0, 33, 0, ...u4(c), ...u4(d.length), ...u4(d.length), ...u2(nb.length), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ...u4(o)]), nb);
    o += h.length + nb.length + d.length;
  }
  const cs = Cd.reduce((a, b) => a + b.length, 0);
  return new Blob([...Lc, ...Cd, new Uint8Array([0x50, 0x4b, 5, 6, 0, 0, 0, 0, ...u2(files.length), ...u2(files.length), ...u4(cs), ...u4(o), 0, 0])], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
}

/* ---------- XLSX ---------- */
// سبک‌ها: 0 پیش‌فرض | 1 بولد | 2 متن+کادر | 3 عدد صحیح+کادر | 4 اعشاری+کادر | 5 سرستون | 6 جمع متن | 7 جمع صحیح | 8 جمع اعشاری
function toXlsx(pages, set) {
  const E = (s) => String(s).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').replace(/[<>&"]/g, (m) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;' }[m]));
  const NS = 'xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"';
  const colL = (j) => String.fromCharCode(65 + j);
  const cellXml = (v, st, a) => {
    if (typeof v == 'number') {
      const isInt = Number.isInteger(v), s = { 2: isInt ? 3 : 4, 3: isInt ? 3 : 4, 6: isInt ? 7 : 8, 7: isInt ? 7 : 8, 0: 0, 1: 1, 5: 5 }[st];
      return `<c r="${a}" s="${s == null ? 0 : s}"><v>${v}</v></c>`;
    }
    return `<c r="${a}" s="${st}" t="inlineStr"><is><t xml:space="preserve">${E(v)}</t></is></c>`;
  };
  const sheets = pages.map((p) => {
    // هر سلول: [مقدار، سبک]
    const rows = [[[set.h1, 1]], [[p.title, 1]], ...p.sub.map((s) => [[s, 0]]), []];
    p.tables.forEach((t) => {
      if (t.t) rows.push([[t.t, 1]]);
      rows.push(t.h.map((h) => [h, 5]), ...t.r.map((r) => r.map((c) => [c, 2])), ...t.f.map((r) => r.map((c) => [c, 6])), []);
    });
    p.sum.forEach((s) => rows.push([[s[0], 1], [s[1], 1], [s[2] || '', 0]]));
    return `<?xml version="1.0" encoding="UTF-8"?><worksheet ${NS}><sheetViews><sheetView rightToLeft="1" workbookViewId="0"/></sheetViews><cols><col min="1" max="12" width="19" customWidth="1"/></cols><sheetData>${rows.map((r, i) => `<row r="${i + 1}">${r.map(([v, b], j) => cellXml(v, b, colL(j) + (i + 1))).join('')}</row>`).join('')}</sheetData></worksheet>`;
  });
  const col = 'FF' + (/^#[0-9a-f]{6}$/i.test(set.col) ? set.col.slice(1) : '4F46E5').toUpperCase();
  const bd = '<border><left style="thin"><color rgb="FFBBBBBB"/></left><right style="thin"><color rgb="FFBBBBBB"/></right><top style="thin"><color rgb="FFBBBBBB"/></top><bottom style="thin"><color rgb="FFBBBBBB"/></bottom><diagonal/></border>';
  const xf = (num_, font_, fill, border, extra = '') => `<xf numFmtId="${num_}" fontId="${font_}" fillId="${fill}" borderId="${border}" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1"${extra ? ' applyAlignment="1">' + extra + '</xf>' : '/>'}`;
  const styles = `<?xml version="1.0" encoding="UTF-8"?><styleSheet ${NS}><numFmts count="1"><numFmt numFmtId="164" formatCode="#,##0.0"/></numFmts><fonts count="3"><font><sz val="11"/><name val="Tahoma"/></font><font><b/><sz val="11"/><name val="Tahoma"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Tahoma"/></font></fonts><fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="${col}"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFE4E4F4"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border>${bd}</borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="9">${[
    xf(0, 0, 0, 0), xf(0, 1, 0, 0), xf(0, 0, 0, 1), xf(3, 0, 0, 1), xf(164, 0, 0, 1),
    xf(0, 2, 2, 1, '<alignment horizontal="center" vertical="center" wrapText="1"/>'),
    xf(0, 1, 3, 1), xf(3, 1, 3, 1), xf(164, 1, 3, 1),
  ].join('')}</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;
  const H = '<?xml version="1.0" encoding="UTF-8"?>', RN = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships', PR = 'http://schemas.openxmlformats.org/package/2006/relationships';
  const sheetName = (p, i) => E(((i + 1) + '-' + p.name).replace(/[\[\]:*?\/\\]/g, '').slice(0, 31));
  return zip([
    ['[Content_Types].xml', H + `<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${sheets.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}</Types>`],
    ['_rels/.rels', H + `<Relationships xmlns="${PR}"><Relationship Id="rId1" Type="${RN}/officeDocument" Target="xl/workbook.xml"/></Relationships>`],
    ['xl/workbook.xml', H + `<workbook ${NS} xmlns:r="${RN}"><sheets>${pages.map((p, i) => `<sheet name="${sheetName(p, i)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('')}</sheets></workbook>`],
    ['xl/_rels/workbook.xml.rels', H + `<Relationships xmlns="${PR}">${sheets.map((_, i) => `<Relationship Id="rId${i + 1}" Type="${RN}/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('')}<Relationship Id="rId${sheets.length + 1}" Type="${RN}/styles" Target="styles.xml"/></Relationships>`],
    ['xl/styles.xml', styles],
    ...sheets.map((s, i) => [`xl/worksheets/sheet${i + 1}.xml`, s]),
  ]);
}

if (typeof module != 'undefined') module.exports = { toXlsx, zip, crc32, toPdf };
