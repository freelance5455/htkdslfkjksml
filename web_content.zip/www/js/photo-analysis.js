// FOTO DUEL — deterministic photo analysis. It measures image pixels only;
// it does not identify people, infer personal traits, or judge beauty.
const clamp = (value, min, max) => Math.max(min, Math.min(max, Math.round(value)));

export function analyzePixelData({ data, width, height }) {
  if (!data || !Number.isInteger(width) || !Number.isInteger(height) || width < 1 || height < 1 || data.length < width * height * 4) {
    throw new Error('Dados de imagem inválidos para análise.');
  }
  const count = width * height;
  let sumL = 0, sumL2 = 0, sumSat = 0, sumR = 0, sumG = 0, sumB = 0;
  const luminance = new Float32Array(count);
  for (let i = 0; i < count; i++) {
    const p = i * 4, r = data[p], g = data[p + 1], b = data[p + 2];
    const l = .2126 * r + .7152 * g + .0722 * b;
    luminance[i] = l; sumL += l; sumL2 += l * l;
    sumSat += Math.max(r, g, b) - Math.min(r, g, b);
    sumR += r; sumG += g; sumB += b;
  }
  let gradient = 0, gradientCount = 0;
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const i = y * width + x;
      if (x + 1 < width) { gradient += Math.abs(luminance[i] - luminance[i + 1]); gradientCount++; }
      if (y + 1 < height) { gradient += Math.abs(luminance[i] - luminance[i + width]); gradientCount++; }
    }
  }
  const meanL = sumL / count;
  const deviation = Math.sqrt(Math.max(0, sumL2 / count - meanL * meanL));
  const light = clamp(100 - Math.abs(meanL - 128) * .76, 0, 100);
  const contrast = clamp(deviation * 1.75, 0, 100);
  const color = clamp((sumSat / count) * .92, 0, 100);
  const detail = clamp((gradient / Math.max(1, gradientCount)) * 3.05, 0, 100);
  const score = clamp(light * .28 + contrast * .24 + color * .16 + detail * .32, 0, 100);
  const atk = clamp(24 + detail * .82 + contrast * .22, 10, 180);
  const def = clamp(25 + contrast * .68 + light * .34, 10, 180);
  const hp = clamp(60 + light * .53 + (100 - detail) * .34, 50, 240);
  const avgR = sumR / count, avgG = sumG / count, avgB = sumB / count;
  let element = 'Neutro';
  if (color < 13) element = meanL > 174 ? 'Luz' : meanL < 75 ? 'Sombra' : 'Neutro';
  else if (avgR > avgG * 1.12 && avgR > avgB * 1.10) element = 'Chama';
  else if (avgG > avgR * 1.08 && avgG > avgB * 1.06) element = 'Flora';
  else if (avgB > avgR * 1.08 && avgB > avgG * 1.03) element = 'Maré';
  else if (meanL > 180) element = 'Luz';
  else if (meanL < 72) element = 'Sombra';
  else element = 'Arcano';
  const rarity = score >= 91 ? 'Mítica' : score >= 82 ? 'Lendária' : score >= 69 ? 'Épica' : score >= 55 ? 'Rara' : score >= 39 ? 'Incomum' : 'Comum';
  const abilities = { Neutro: 'rage', Flora: 'heal', Chama: 'burn', Maré: 'shield', Raio: 'stun', Arcano: 'fireball', Terra: 'guard', Sombra: 'poison', Luz: 'reflect' };
  return { score, light, contrast, color, detail, atk, def, hp, rarity, element, ability: abilities[element] || 'rage' };
}

export function analyzeImageData(dataUrl) {
  return new Promise((resolve, reject) => {
    if (typeof Image === 'undefined' || typeof document === 'undefined') {
      reject(new Error('Análise por imagem só está disponível no navegador ou no APK.'));
      return;
    }
    const image = new Image();
    image.onerror = () => reject(new Error('Não foi possível abrir a fotografia para análise.'));
    image.onload = () => {
      try {
        const width = 96, height = 96;
        const canvas = document.createElement('canvas');
        canvas.width = width; canvas.height = height;
        const context = canvas.getContext('2d', { willReadFrequently: true, alpha: false });
        if (!context) throw new Error('Canvas indisponível neste aparelho.');
        context.fillStyle = '#777'; context.fillRect(0, 0, width, height);
        const scale = Math.min(width / image.naturalWidth, height / image.naturalHeight);
        const drawWidth = Math.max(1, image.naturalWidth * scale);
        const drawHeight = Math.max(1, image.naturalHeight * scale);
        context.drawImage(image, (width - drawWidth) / 2, (height - drawHeight) / 2, drawWidth, drawHeight);
        const pixels = context.getImageData(0, 0, width, height);
        resolve(analyzePixelData({ data: pixels.data, width, height }));
      } catch (error) { reject(error); }
    };
    image.src = dataUrl;
  });
}
