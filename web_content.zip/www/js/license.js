/* ============================================================
   RadLedger — سمت کلاینتِ لایسنس (امضای ECDSA، حالت آفلاین، پروفایل)
   ============================================================ */
'use strict';

const RLC = window.RL || {};
const API = (RLC.api || '').replace(/\/+$/, '');
const PUB = RLC.pub || null;
const GRACE = 14 * DAY_MS;         // حداکثر مدت کار آفلاین بدون تأیید سرور
const RECHECK = 30 * 60 * 1000;    // بررسی دوره‌ای هنگامی که اپ باز و فعال است
const FETCH_TIMEOUT = 12000;
const VER = '2.0.0';
const SUP = 'https://t.me/RadOriginal';

let L = {}, PV = null, busy = false, poll = 0, recheckTimer = 0;
const lsave = () => lsSet('rl', JSON.stringify(L));
const b64d = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
const phoneClean = (s) => String(s).replace(/[۰-۹]/g, (d) => FA.indexOf(d)).replace(/[٠-٩]/g, (d) => AR.indexOf(d)).replace(/[^\d+]/g, '');

async function loadLicense() {
  try { L = JSON.parse(localStorage.getItem('rl') || 'null') || {}; } catch (e) { L = {}; }
  if (!L.name && !L.code) {
    const m = await recover('rl');
    if (m) { try { L = JSON.parse(m) || {}; } catch (e) { L = {}; } }
  }
  if (typeof L != 'object' || Array.isArray(L)) L = {};
}

// کد دستگاه: هش پایدار از شناسهٔ دستگاه (بعد از نصب مجدد/پاک‌شدن داده تغییر نمی‌کند)
async function devCode() {
  if (L.code) return L.code;
  let id = '';
  try { const P = plug('Device'); if (P) { const r = await P.getId(); id = r.identifier || r.uuid || ''; } } catch (e) { /* ignore */ }
  if (!id) id = uid() + uid() + uid();
  const h = new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode('RadLedger|' + id)));
  const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  L.code = 'RL-' + Array.from(h.slice(0, 8), (b) => A[b % 32]).join('');
  lsave();
  return L.code;
}

async function vfy(r, n) {
  try {
    if (!PUB || !r || !r.p || !r.s) return null;
    const k = await crypto.subtle.importKey('jwk', PUB, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
    if (!(await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, k, b64d(r.s), new TextEncoder().encode(r.p)))) return null;
    const p = JSON.parse(r.p);
    if (p.c !== L.code || (n && p.n !== n)) return null;
    return p;
  } catch (e) { return null; }
}

async function api(url, opt) {
  const ac = new AbortController(), t = setTimeout(() => ac.abort(), FETCH_TIMEOUT);
  try { const res = await fetch(url, { ...opt, signal: ac.signal, cache: 'no-store' }); return await res.json(); }
  finally { clearTimeout(t); }
}

// reg=true → ثبت‌نام/به‌روزرسانی پروفایل؛ وگرنه فقط استعلام وضعیت
async function sync(reg) {
  if (!API) return 'cfg';
  await devCode();
  const n = uid() + uid();
  try {
    const r = reg
      ? await api(API + '/api/register', { method: 'POST', body: JSON.stringify({ c: L.code, n, name: L.name, phone: L.phone, biz: L.biz || '', ver: VER }) })
      : await api(API + '/api/status?c=' + encodeURIComponent(L.code) + '&n=' + n + '&v=' + VER);
    if (r && r.error === 'rate limited') return 'rate';
    const p = await vfy(r, n);
    if (!p) return 'bad';
    L.lic = { p: r.p, s: r.s };
    L.seen = Math.max(L.seen || 0, Date.now());
    lsave(); PV = p;
    if (!reg && p.st == 'none' && L.name) return sync(true); // رکورد روی سرور نیست → ثبت خودکار
    return 'ok';
  } catch (e) { return 'net'; }
}

function lstate() {
  if (!API) return { st: 'cfg' };
  if (!L.name || !L.phone) return { st: 'new' };
  const now = Math.max(Date.now(), L.seen || 0); // جلوگیری از عقب‌بردن ساعت
  if (!PV) return { st: 'offline' };
  if (PV.st != 'active') return { st: PV.st, exp: PV.exp };
  if (PV.exp && PV.exp < now) return { st: 'expired', exp: PV.exp };
  if (now - PV.iat > GRACE) return { st: 'recheck' };
  return { st: 'active', exp: PV.exp, plan: PV.plan, graceLeft: GRACE - (now - PV.iat) };
}

/* ---------- رابط کاربری لایسنس ---------- */
function pForm(sheetMode) {
  return `<div class=card><b>${L.name ? 'ویرایش پروفایل' : 'ثبت‌نام'}</b><small style="margin-top:6px">برای فعال‌سازی، مشخصات خود را وارد کنید. مدیر پس از بررسی، اپ را فعال می‌کند.</small>
<input id=pn placeholder="نام و نام خانوادگی" value="${esc(L.name)}" autocomplete=name><input id=pp placeholder="شماره تلفن" inputmode=tel value="${esc(L.phone)}" autocomplete=tel><input id=pb placeholder="نام شرکت / کارگاه (اختیاری)" value="${esc(L.biz)}">
<button class=pri onclick="pSave(${sheetMode ? 1 : 0})">${L.name ? 'ذخیره' : 'ثبت و ارسال درخواست'}</button>${L.name && !sheetMode ? '<button class="pri ghost" onclick="L.edit=0;R()">انصراف</button>' : ''}</div>`;
}
async function pSave(sheetMode) {
  const n = $('#pn').value.trim(), p = phoneClean($('#pp').value), b = $('#pb').value.trim();
  if (n.length < 3) return toast('نام را کامل وارد کنید');
  if (p.replace(/\D/g, '').length < 7) return toast('شمارهٔ تلفن معتبر نیست');
  Object.assign(L, { name: n, phone: p, biz: b, edit: 0 }); lsave();
  if (sheetMode) sheet();
  toast('در حال ارسال…');
  const r = await sync(true);
  toast(r == 'ok' ? 'پروفایل ثبت شد' : r == 'net' ? 'اینترنت در دسترس نیست؛ بعداً «بررسی وضعیت» را بزنید' : r == 'rate' ? 'تعداد درخواست زیاد است؛ کمی بعد تلاش کنید' : 'خطا در ارتباط با سرور');
  R(); startPoll();
}
const pEdit = () => sheet('<h3>ویرایش پروفایل</h3>' + pForm(1));
function cpCode() {
  const c = L.code || '';
  (navigator.clipboard ? navigator.clipboard.writeText(c) : Promise.reject()).then(() => toast('کد کپی شد'), () => toast(c));
}
async function chk() {
  if (busy) return;
  busy = true; toast('در حال بررسی…');
  const r = await sync(false);
  busy = false;
  toast(r == 'net' ? 'اتصال به اینترنت برقرار نیست' : r == 'bad' ? 'پاسخ سرور معتبر نیست' : r == 'ok' ? 'وضعیت به‌روز شد' : 'خطا در ارتباط با سرور');
  R();
}
function lockView() {
  const s = lstate(), head = `<div class=lk><img class=logo src=icon.png alt=""><h2>RadLedger</h2>`;
  if (s.st == 'cfg') return head + '<div class=card><b class=bad>آدرس سرور لایسنس تنظیم نشده</b><small style="margin-top:8px">فایل www/config.js را مطابق راهنما کامل کنید و دوباره بیلد بگیرید.</small></div></div>';
  if (s.st == 'new' || L.edit) return head + pForm(0) + '</div>';
  const M = {
    pending: ['⏳ در انتظار تأیید', 'درخواست شما برای مدیر ارسال شد. پس از تأیید، اپ خودکار باز می‌شود.'],
    blocked: ['⛔ دسترسی مسدود شده', 'برای اطلاعات بیشتر با پشتیبانی تماس بگیرید.'],
    expired: ['⌛ لایسنس منقضی شده', 'برای تمدید، کد دستگاه را برای پشتیبانی بفرستید. اطلاعات شما در اپ محفوظ است.'],
    recheck: ['📡 نیاز به اتصال اینترنت', 'برای بررسی لایسنس یک بار به اینترنت وصل شوید.'],
    offline: ['📡 اتصال به سرور برقرار نشد', 'اینترنت را بررسی کنید و دوباره تلاش کنید.'],
    none: ['⚠️ ثبت‌نام کامل نشد', 'اینترنت را بررسی کنید و «بررسی وضعیت» را بزنید.'],
  }[s.st] || ['', ''];
  return head + `<p><b>${M[0]}</b></p><p><small>${M[1]}</small></p><div class=card><small>کد دستگاه (به مدیر بدهید)</small><div class=cd>${esc(L.code)}</div><button class=pri onclick="cpCode()">کپی کد</button><button class="pri grn" onclick="chk()">بررسی وضعیت</button><a class=btn href="${SUP}" target=_blank rel=noopener>ارتباط با پشتیبانی (تلگرام)</a><button class="pri ghost" onclick="L.edit=1;R()">ویرایش پروفایل</button></div><p><small>${esc(L.name)} — ${esc(L.phone)}</small></p></div>`;
}
function licDays(s) { return s.exp ? Math.max(0, Math.ceil((s.exp - Date.now()) / DAY_MS)) : null; }
function vProf() {
  const s = lstate(), left = licDays(s);
  const ex = s.plan == 'life' ? 'دائمی ♾' : s.exp ? jd(iso(new Date(s.exp))) + ' (' + fa(left) + ' روز مانده)' : '—';
  return `<div class=card><b>پروفایل و لایسنس</b><div class=wr><small>نام</small>${esc(L.name)}<small style="margin-top:6px">تلفن</small>${esc(L.phone)}${L.biz ? `<small style="margin-top:6px">کارگاه</small>${esc(L.biz)}` : ''}</div><div class=wr><small>کد دستگاه</small><div class=cd style="font-size:18px">${esc(L.code)}</div><small style="margin-top:8px">وضعیت: <b style="color:var(--g)">فعال</b> | اعتبار تا: ${ex}</small></div><div class=seg><button onclick="pEdit()">ویرایش پروفایل</button><button onclick="cpCode()">کپی کد</button><button class=on2 onclick="chk()">بررسی لایسنس</button></div></div>`;
}
// هشدار نزدیک‌بودن انقضا
function licBanner() {
  const s = lstate();
  if (s.st != 'active') return '';
  const left = licDays(s);
  if (s.plan != 'life' && left != null && left <= 7) return `<div class="card warn"><b>⏰ لایسنس شما ${left ? fa(left) + ' روز دیگر' : 'امروز'} منقضی می‌شود</b><a class=btn href="${SUP}" target=_blank rel=noopener>تمدید از طریق تلگرام</a></div>`;
  if (s.graceLeft < 3 * DAY_MS) return `<div class="card warn"><b>📡 برای ادامهٔ کار، به‌زودی به اینترنت وصل شوید</b><small>لایسنس باید هر چند روز یک‌بار با سرور تأیید شود.</small></div>`;
  return '';
}

/* ---------- بررسی خودکار ---------- */
const sigOf = () => JSON.stringify(lstate().st + '|' + (lstate().exp || 0));
async function syncAndRefresh() {
  if (!API || !L.name || busy) return;
  busy = true;
  const b = sigOf();
  await sync(false);
  busy = false;
  if (sigOf() != b) { if (lstate().st == 'active') toast('وضعیت لایسنس به‌روز شد'); R(); }
}
function startPoll() {
  clearInterval(poll);
  poll = setInterval(async () => {
    if (!API || !L.name || busy || L.edit || document.hidden) return;
    if (lstate().st == 'active') return; // حالت فعال را تایمر آهسته بررسی می‌کند
    busy = true;
    const b = lstate().st;
    await sync(false);
    busy = false;
    if (lstate().st != b) { if (lstate().st == 'active') toast('لایسنس فعال شد ✅'); R(); }
  }, 10000);
  clearInterval(recheckTimer);
  recheckTimer = setInterval(() => { if (!document.hidden && lstate().st == 'active') syncAndRefresh(); }, RECHECK);
}
