# LIND-US Navigation V2.0

A webes prototípus korábbi funkciói megmaradtak. A natív Android Auto réteg első alkalommal képes geo:/Google Navigation célátadást fogadni, a célt Nominatim segítségével feloldani, OSRM útvonalat kérni, majd a kapott útvonalgeometriát az OSM térképre rajzolni. Az autós panelen a cél, távolság és becsült menetidő jelenik meg.

Ez még fejlesztői prototípus: folyamatok közötti route state, térképforgatás/útvonalvetítés és teljes navigációs lifecycle további munkát igényel. ZIP forráscsomag, nem APK; build és autós teszt még nem történt.
