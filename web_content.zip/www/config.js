// ===== تنظیمات لایسنس RadLedger =====
// فقط مقدار api را بعد از ساخت Worker کلادفلر کامل کنید. مثال:
//   api: 'https://radledger.myname.workers.dev'
// کلید pub «کلید عمومی» است و محرمانه نیست؛ دست نزنید.
window.RL = {
  api: '',
  pub: {"kty": "EC", "crv": "P-256", "x": "BiX1_BTzKHEBmw7SbVwKpdglhW_xllXmFHC7nXwfVa0", "y": "KjScXqbZ2Tok5xjyrz8ckqiZwIyrt03coRszFSEMiT4"}
};
