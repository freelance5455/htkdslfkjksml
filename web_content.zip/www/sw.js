const CACHE = "visitor-register-bensaddik-v1";
const CORE = ["./", "index.html", "style.css", "app.js", "manifest.json", "icon-192.png", "icon-512.png"];

self.addEventListener("install", e => {
  self.skipWaiting();
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(CORE)));
});

self.addEventListener("activate", e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", e => {
  if (e.request.method !== "GET") return;
  e.respondWith(
    caches.match(e.request).then(c =>
      c || fetch(e.request).then(r => {
        const copy = r.clone();
        caches.open(CACHE).then(x => x.put(e.request, copy));
        return r;
      }).catch(() => caches.match("index.html"))
    )
  );
});
