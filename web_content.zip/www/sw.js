/* Offline-first game assets; never cache multiplayer WebSocket traffic. */
const CACHE='zombie-bastion-pwa-v3-ultimate';
const FILES=['./','./index.html','./manifest.webmanifest','./icons/icon-192.png','./icons/icon-512.png'];
self.addEventListener('install', event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(FILES)).then(()=>self.skipWaiting())));
self.addEventListener('activate', event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key!==CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
 if(event.request.method!=='GET'||new URL(event.request.url).pathname==='/ws')return;
 const req=event.request;
 if(req.mode==='navigate'){
  event.respondWith(fetch(req).then(response=>response.ok?response:Promise.reject()).catch(()=>caches.match('./index.html')));
  return;
 }
 event.respondWith(caches.match(req).then(hit=>hit||fetch(req)));
});
