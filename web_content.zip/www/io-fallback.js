/*
 * io-fallback.js — طبقة الحفظ والاسترجاع للتطبيق المستقل (بدون منصة Whacka)
 *
 * المشكلة: غلاف APK عادةً هو WebView فقط، فلا يدعم:
 *   - تنزيل الملفات من روابط blob:      (التصدير + النسخ الاحتياطي)
 *   - نافذة اختيار الملفات <input file>  (الاسترجاع)
 * الحل: على أندرويد نعرض نافذة تسمح بـ «نسخ المحتوى» أو «مشاركته» أو «محاولة التنزيل»،
 * وعند الاسترجاع نسمح بالصق محتوى النسخة مباشرةً بجانب خيار اختيار الملف.
 * خارج أندرويد (متصفح عادي) يبقى السلوك الأصلي كما هو.
 */
(function () {
  'use strict';

  var IS_ANDROID = /Android/i.test(navigator.userAgent || '');
  var GREEN = '#065f46';

  /* ---------- أدوات مساعدة ---------- */

  function readText(blob) {
    return new Promise(function (resolve, reject) {
      var r = new FileReader();
      r.onload = function () { resolve(String(r.result)); };
      r.onerror = function () { reject(r.error || new Error('read failed')); };
      r.readAsText(blob);
    });
  }

  // CSV -> TSV: النص المفصول بـ Tab يتوزع تلقائياً على الأعمدة عند لصقه في Excel / Google Sheets
  function csvToTsv(csv) {
    var text = String(csv).replace(/^\uFEFF/, '');
    var rows = [], row = [], field = '', inQ = false, i, c;
    for (i = 0; i < text.length; i++) {
      c = text[i];
      if (inQ) {
        if (c === '"') {
          if (text[i + 1] === '"') { field += '"'; i++; } else { inQ = false; }
        } else { field += c; }
      } else if (c === '"') { inQ = true; }
      else if (c === ',') { row.push(field); field = ''; }
      else if (c === '\n') { row.push(field); rows.push(row); row = []; field = ''; }
      else if (c === '\r') { /* تجاهل */ }
      else { field += c; }
    }
    if (field !== '' || row.length) { row.push(field); rows.push(row); }
    return rows.map(function (r) {
      return r.map(function (f) {
        return /[\t\n"]/.test(f) ? '"' + f.replace(/"/g, '""') + '"' : f;
      }).join('\t');
    }).join('\n');
  }

  function copyText(text) {
    function legacy() {
      try {
        var ta = document.createElement('textarea');
        ta.value = text;
        ta.setAttribute('readonly', '');
        ta.style.cssText = 'position:fixed;top:0;left:0;width:1px;height:1px;opacity:0;';
        document.body.appendChild(ta);
        ta.focus();
        ta.select();
        ta.setSelectionRange(0, text.length);
        var ok = document.execCommand('copy');
        document.body.removeChild(ta);
        return ok;
      } catch (e) { return false; }
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(text).then(function () { return true; }, function () { return legacy(); });
    }
    return Promise.resolve(legacy());
  }

  function anchorDownload(blob, name) {
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = name;
    a.rel = 'noopener';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 10000);
  }

  function formatSize(n) {
    return n < 1024 * 1024 ? Math.max(1, Math.round(n / 1024)) + ' كيلوبايت' : (n / 1024 / 1024).toFixed(1) + ' ميغابايت';
  }

  /* ---------- المسار الأصلي (Capacitor): كتابة ملف فعلي + قائمة المشاركة ---------- */

  function cap() { return window.Capacitor || null; }
  function isNative() {
    var c = cap();
    return !!(c && typeof c.isNativePlatform === 'function' && c.isNativePlatform());
  }
  function blobToBase64(blob) {
    return new Promise(function (resolve, reject) {
      var r = new FileReader();
      r.onload = function () { resolve(String(r.result).split(',')[1] || ''); };
      r.onerror = function () { reject(r.error || new Error('read failed')); };
      r.readAsDataURL(blob);
    });
  }
  function nativeSave(blob, name) {
    var P = cap() && cap().Plugins;
    if (!P || !P.Filesystem || !P.Share) return Promise.reject(new Error('plugins missing'));
    return blobToBase64(blob).then(function (b64) {
      return P.Filesystem.writeFile({ path: name, data: b64, directory: 'CACHE' });
    }).then(function (res) {
      return P.Share.share({ title: name, url: res.uri, dialogTitle: 'حفظ الملف' });
    });
  }

  /* ---------- مكونات الواجهة ---------- */

  function el(tag, css, text) {
    var e = document.createElement(tag);
    if (css) e.style.cssText = css;
    if (text != null) e.textContent = text;
    return e;
  }

  function button(label, primary) {
    var b = el('button',
      'display:block;width:100%;box-sizing:border-box;border:' + (primary ? 'none' : '1px solid #cbd5e1') + ';border-radius:12px;' +
      'padding:13px 14px;margin-top:10px;font:inherit;font-size:14px;font-weight:700;cursor:pointer;' +
      'background:' + (primary ? GREEN : '#fff') + ';color:' + (primary ? '#fff' : '#334155') + ';', label);
    b.type = 'button';
    return b;
  }

  function sheet(title, onClose) {
    var overlay = el('div',
      'position:fixed;top:0;left:0;right:0;bottom:0;z-index:2147483000;background:rgba(0,0,0,.55);' +
      'display:flex;align-items:flex-end;justify-content:center;direction:rtl;');
    var card = el('div',
      'width:100%;max-width:460px;max-height:92%;overflow-y:auto;box-sizing:border-box;background:#fff;color:#1e293b;' +
      'border-radius:22px 22px 0 0;padding:18px 18px calc(18px + env(safe-area-inset-bottom,0px));' +
      'font-family:inherit;box-shadow:0 -10px 40px rgba(0,0,0,.25);');
    var head = el('div', 'display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;');
    head.appendChild(el('h3', 'margin:0;font-size:16px;font-weight:800;', title));
    var x = el('button', 'border:none;background:#f1f5f9;color:#64748b;width:34px;height:34px;border-radius:50%;font-size:18px;cursor:pointer;', '✕');
    x.type = 'button';
    x.setAttribute('aria-label', 'إغلاق');
    head.appendChild(x);
    card.appendChild(head);
    overlay.appendChild(card);
    document.body.appendChild(overlay);

    var closed = false;
    function close() {
      if (closed) return;
      closed = true;
      document.removeEventListener('keydown', onKey);
      if (overlay.parentNode) overlay.parentNode.removeChild(overlay);
      if (onClose) onClose();
    }
    function onKey(e) { if (e.key === 'Escape') close(); }
    document.addEventListener('keydown', onKey);
    x.addEventListener('click', close);
    overlay.addEventListener('click', function (e) { if (e.target === overlay) close(); });
    return { card: card, close: close };
  }

  function status(card) {
    var s = el('p', 'margin:10px 0 0;font-size:12px;font-weight:700;min-height:16px;color:#065f46;');
    card.appendChild(s);
    return function (msg, bad) { s.textContent = msg; s.style.color = bad ? '#b91c1c' : '#065f46'; };
  }

  /* ---------- الحفظ / التصدير ---------- */

  function save(blob, name) {
    if (isNative()) {
      return nativeSave(blob, name).catch(function (e) {
        // المستخدم أغلق قائمة المشاركة: ليس خطأً
        if (e && /cancel|dismiss/i.test(String(e.message || e))) return;
        return saveSheet(blob, name);
      });
    }
    if (!IS_ANDROID) { anchorDownload(blob, name); return Promise.resolve(); }
    return saveSheet(blob, name);
  }

  function saveSheet(blob, name) {
    return readText(blob).then(function (text) {
      return new Promise(function (resolve, reject) {
        var isCsv = /\.csv$/i.test(name);
        var acted = false;
        var s = sheet('حفظ الملف', function () { acted ? resolve() : reject(new Error('cancelled')); });
        var card = s.card;
        var say;

        card.appendChild(el('p', 'margin:0 0 4px;font-size:12.5px;line-height:1.7;color:#475569;',
          'هذا الجهاز لا يسمح للتطبيق بحفظ الملفات مباشرةً. استخدم إحدى الطرق التالية:'));
        var meta = el('p', 'margin:0;font-size:11px;color:#94a3b8;');
        var nm = el('span', 'direction:ltr;unicode-bidi:isolate;display:inline-block;', name);
        meta.appendChild(nm);
        meta.appendChild(document.createTextNode('  ·  ' + formatSize(blob.size)));
        card.appendChild(meta);

        var copyBtn = button(isCsv ? 'نسخ البيانات للصقها في Excel / Sheets' : 'نسخ النسخة الاحتياطية', true);
        card.appendChild(copyBtn);
        card.appendChild(el('p', 'margin:6px 0 0;font-size:11.5px;line-height:1.7;color:#64748b;',
          isCsv
            ? 'افتح Excel أو Google Sheets، والصق في الخلية A1 فتتوزع البيانات على الأعمدة تلقائياً.'
            : 'الصقها في ملاحظات أو أرسلها لنفسك (واتساب / تلغرام). وعند الاستعادة اختر «اللصق» وأدخل النص نفسه.'));

        var shareBtn = null;
        if (navigator.share) {
          shareBtn = button('مشاركة كنص (واتساب، تلغرام، البريد…)', false);
          card.appendChild(shareBtn);
        }
        var dlBtn = button('محاولة التنزيل كملف', false);
        card.appendChild(dlBtn);
        say = status(card);

        var payload = isCsv ? csvToTsv(text) : text;

        copyBtn.addEventListener('click', function () {
          copyText(payload).then(function (ok) {
            if (ok) { acted = true; say('تم النسخ ✓ — الصقه الآن في المكان الذي تريده.'); }
            else say('تعذّر النسخ تلقائياً على هذا الجهاز. جرّب «مشاركة» أو «محاولة التنزيل».', true);
          });
        });
        if (shareBtn) {
          shareBtn.addEventListener('click', function () {
            navigator.share({ title: name, text: payload }).then(function () {
              acted = true; say('تمت المشاركة ✓');
            }, function (e) {
              if (!e || e.name !== 'AbortError') say('تعذّرت المشاركة — جرّب «نسخ».', true);
            });
          });
        }
        dlBtn.addEventListener('click', function () {
          try {
            anchorDownload(blob, name);
            acted = true;
            say('تم طلب التنزيل. إن لم يظهر الملف في مجلد التنزيلات فاستخدم «نسخ».');
          } catch (e) { say('التنزيل غير مدعوم هنا — استخدم «نسخ».', true); }
        });
      });
    });
  }

  /* ---------- الاسترجاع ---------- */

  function pick(cb) {
    if (!IS_ANDROID || isNative()) {
      var inp = document.createElement('input');
      inp.type = 'file';
      inp.accept = '.json,application/json';
      inp.onchange = function () { if (inp.files && inp.files[0]) cb(inp.files[0]); };
      inp.click();
      return;
    }

    var s = sheet('استعادة نسخة احتياطية', null);
    var card = s.card;
    card.appendChild(el('p', 'margin:0 0 4px;font-size:12.5px;line-height:1.7;color:#475569;',
      'اختر ملف النسخة الاحتياطية، أو الصق محتواها مباشرةً إن لم تفتح نافذة اختيار الملفات.'));

    // الطريقة 1: اختيار ملف
    var fileLabel = el('label',
      'display:block;box-sizing:border-box;text-align:center;border-radius:12px;padding:13px 14px;margin-top:10px;' +
      'font-size:14px;font-weight:700;cursor:pointer;background:' + GREEN + ';color:#fff;', 'اختيار ملف النسخة الاحتياطية');
    var fileInput = el('input', 'display:none;');
    fileInput.type = 'file';
    fileInput.addEventListener('change', function () {
      var f = fileInput.files && fileInput.files[0];
      if (f) { s.close(); cb(f); }
    });
    fileLabel.appendChild(fileInput);
    card.appendChild(fileLabel);

    // الطريقة 2: لصق النص
    card.appendChild(el('p', 'margin:14px 0 6px;font-size:12px;font-weight:700;color:#334155;', 'أو الصق محتوى النسخة هنا:'));
    var ta = el('textarea',
      'width:100%;box-sizing:border-box;height:110px;border:1px solid #cbd5e1;border-radius:12px;padding:10px;' +
      'font:12px monospace;direction:ltr;text-align:left;resize:none;');
    ta.placeholder = '{"app":"تجاريك", ...}';
    card.appendChild(ta);
    var go = button('استعادة من النص الملصوق', false);
    card.appendChild(go);
    var say = status(card);

    go.addEventListener('click', function () {
      var text = ta.value.trim();
      if (!text) { say('الصق محتوى النسخة أولاً.', true); return; }
      s.close();
      cb(new Blob([text], { type: 'application/json' }));
    });
  }

  window.TijarikIO = { save: save, pick: pick, _csvToTsv: csvToTsv };
})();
