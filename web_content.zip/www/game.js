// منع القوائم السياقية والأحداث الافتراضية لللمس
document.addEventListener('contextmenu', e => e.preventDefault());
document.addEventListener('selectstart', e => e.preventDefault());
document.addEventListener('dragstart', e => e.preventDefault());

const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

// ضبط أبعاد Canvas
function resizeCanvas() {
    canvas.width = canvas.clientWidth;
    canvas.height = canvas.clientHeight;
}
window.addEventListener('resize', resizeCanvas);

// الحالة العامة للعبة
let gameState = {
    mode: localStorage.getItem('gameMode') || 'closed', // 'closed' or 'open'
    control: localStorage.getItem('controlType') || 'arrows', // 'arrows' or 'joystick'
    sound: localStorage.getItem('sound') !== 'false',
    score: 0,
    level: 1,
    lives: 3,
    highScore: parseInt(localStorage.getItem('highScore')) || 0,
    running: false
};

// عناصر الكائنات
let player = { x: 0, y: 0, radius: 12, speed: 3.5, baseSpeed: 3.5, vx: 0, vy: 0 };
let monsters = [];
let balls = [];
let walls = [];
let boostActive = false;
let boostCooldown = false;
let freezeActive = false;

// تهيئة واجهات المستخدم والـ Events
document.addEventListener('DOMContentLoaded', () => {
    resizeCanvas();
    setupUI();
});

function setupUI() {
    // تبويب الشاشات
    document.getElementById('btn-start').onclick = startGame;
    document.getElementById('btn-settings').onclick = () => showScreen('settings-screen');
    document.getElementById('btn-back-settings').onclick = () => showScreen('main-menu');
    document.getElementById('btn-restart').onclick = startGame;
    document.getElementById('btn-main-menu').onclick = () => showScreen('main-menu');
    document.getElementById('btn-next-level').onclick = nextLevel;

    // الخيارات
    const modeClosed = document.getElementById('mode-closed');
    const modeOpen = document.getElementById('mode-open');

    modeClosed.onclick = () => {
        gameState.mode = 'closed';
        localStorage.setItem('gameMode', 'closed');
        modeClosed.classList.add('active');
        modeOpen.classList.remove('active');
    };

    modeOpen.onclick = () => {
        gameState.mode = 'open';
        localStorage.setItem('gameMode', 'open');
        modeOpen.classList.add('active');
        modeClosed.classList.remove('active');
    };

    // التحكم
    const ctrlArrows = document.getElementById('ctrl-arrows');
    const ctrlJoy = document.getElementById('ctrl-joystick');

    ctrlArrows.onclick = () => {
        gameState.control = 'arrows';
        localStorage.setItem('controlType', 'arrows');
        ctrlArrows.classList.add('active');
        ctrlJoy.classList.remove('active');
        updateControlUI();
    };

    ctrlJoy.onclick = () => {
        gameState.control = 'joystick';
        localStorage.setItem('controlType', 'joystick');
        ctrlJoy.classList.add('active');
        ctrlArrows.classList.remove('active');
        updateControlUI();
    };

    // نسخ الرقم
    document.getElementById('btn-copy-num').onclick = () => {
        navigator.clipboard.writeText('01271712158');
        alert('تم نسخ الرقم بنجاح!');
    };

    setupControls();
}

function showScreen(id) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    document.getElementById(id).classList.add('active');
    if (id === 'game-container') resizeCanvas();
}

function updateControlUI() {
    if (gameState.control === 'arrows') {
        document.getElementById('arrow-controls').classList.remove('hidden');
        document.getElementById('joystick-container').classList.add('hidden');
    } else {
        document.getElementById('arrow-controls').classList.add('hidden');
        document.getElementById('joystick-container').classList.remove('hidden');
    }
}

// التحكم بالحركة
function setupControls() {
    const bindBtn = (id, vx, vy) => {
        const btn = document.getElementById(id);
        const start = (e) => { e.preventDefault(); player.vx = vx; player.vy = vy; };
        const end = (e) => { e.preventDefault(); player.vx = 0; player.vy = 0; };
        btn.addEventListener('touchstart', start);
        btn.addEventListener('touchend', end);
        btn.addEventListener('mousedown', start);
        btn.addEventListener('mouseup', end);
    };

    bindBtn('btn-up', 0, -1);
    bindBtn('btn-down', 0, 1);
    bindBtn('btn-left', -1, 0);
    bindBtn('btn-right', 1, 0);

    // زر السرعة
    const boostBtn = document.getElementById('btn-boost');
    boostBtn.onclick = triggerBoost;

    // Joystick Simple Implementation
    const joyBase = document.getElementById('joystick-base');
    const joyStick = document.getElementById('joystick-stick');

    joyBase.addEventListener('touchmove', (e) => {
        const touch = e.touches[0];
        const rect = joyBase.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;

        let dx = touch.clientX - centerX;
        let dy = touch.clientY - centerY;
        const dist = Math.hypot(dx, dy);
        const maxDist = 35;

        if (dist > maxDist) {
            dx = (dx / dist) * maxDist;
            dy = (dy / dist) * maxDist;
        }

        joyStick.style.transform = `translate(${dx}px, ${dy}px)`;
        player.vx = dx / maxDist;
        player.vy = dy / maxDist;
    });

    joyBase.addEventListener('touchend', () => {
        joyStick.style.transform = `translate(0px, 0px)`;
        player.vx = 0;
        player.vy = 0;
    });
}

function triggerBoost() {
    if (boostCooldown || boostActive) return;
    boostActive = true;
    player.speed = player.baseSpeed * 1.8;
    setTimeout(() => {
        player.speed = player.baseSpeed;
        boostActive = false;
        boostCooldown = true;
        setTimeout(() => boostCooldown = false, 4000); // Cooldown 4s
    }, 2500);
}

// بدء وقواعد اللعبة
function startGame() {
    gameState.score = 0;
    gameState.level = 1;
    gameState.lives = 3;
    showScreen('game-container');
    updateControlUI();
    initLevel();
    gameState.running = true;
    requestAnimationFrame(gameLoop);
}

function nextLevel() {
    gameState.level++;
    showScreen('game-container');
    initLevel();
    gameState.running = true;
    requestAnimationFrame(gameLoop);
}

function initLevel() {
    player.x = canvas.width / 2;
    player.y = canvas.height / 2;

    // إعداد الكرات
    balls = [];
    let numYellow = 10 + gameState.level * 2;
    for(let i=0; i<numYellow; i++) spawnBall('yellow');

    // كرة سرعة
    spawnBall('speed');

    // كرات التجميد بناءً على المرحلة
    let freezeCount = gameState.level >= 8 ? 3 : (gameState.level >= 4 ? 2 : 1);
    for(let i=0; i<freezeCount; i++) spawnBall('freeze');

    // إعداد الوحوش
    monsters = [];
    let monsterCount = gameState.level >= 10 ? 3 : (gameState.level >= 5 ? 2 : 1);

    // الـ Boss كل 10 مراحل
    if (gameState.level % 10 === 0) {
        monsters.push({
            x: 50, y: 50, radius: 25, speed: 2.2, isBoss: true, type: 'boss'
        });
    } else {
        for(let i=0; i<monsterCount; i++) {
            let speed = Math.min(2.0 + (gameState.level * 0.1), player.baseSpeed * 0.95);
            monsters.push({
                x: 30 + i*40, y: 30, radius: 14, 
                speed: i === 1 ? speed * 0.8 : speed, // تنوع أنواع الوحوش
                type: i === 1 ? 'slow' : 'normal'
            });
        }
    }
}

function spawnBall(type) {
    balls.push({
        x: Math.random() * (canvas.width - 40) + 20,
        y: Math.random() * (canvas.height - 40) + 20,
        radius: type === 'freeze' ? 9 : 7,
        type: type
    });
}

// الحلقة الأساسية للعبة
function gameLoop() {
    if (!gameState.running) return;

    update();
    render();

    requestAnimationFrame(gameLoop);
}

function update() {
    // حركة اللاعب
    player.x += player.vx * player.speed;
    player.y += player.vy * player.speed;

    // معالجة أطراف الخريطة (مفتوحة / مغلقة)
    if (gameState.mode === 'open') {
        if (player.x < 0) player.x = canvas.width;
        if (player.x > canvas.width) player.x = 0;
        if (player.y < 0) player.y = canvas.height;
        if (player.y > canvas.height) player.y = 0;
    } else {
        player.x = Math.max(player.radius, Math.min(canvas.width - player.radius, player.x));
        player.y = Math.max(player.radius, Math.min(canvas.height - player.radius, player.y));
    }

    // حركة الوحوش
    if (!freezeActive) {
        monsters.forEach(m => {
            let dx = player.x - m.x;
            let dy = player.y - m.y;
            let dist = Math.hypot(dx, dy);

            if (dist > 0) {
                m.x += (dx / dist) * m.speed;
                m.y += (dy / dist) * m.speed;
            }

            if (gameState.mode === 'open') {
                if (m.x < 0) m.x = canvas.width;
                if (m.x > canvas.width) m.x = 0;
                if (m.y < 0) m.y = canvas.height;
                if (m.y > canvas.height) m.y = 0;
            }

            // تصادم الوحش مع اللاعب
            if (dist < player.radius + m.radius) {
                gameState.lives--;
                document.getElementById('lives-val').innerText = '❤️'.repeat(gameState.lives);
                player.x = canvas.width / 2;
                player.y = canvas.height / 2;
                if (gameState.lives <= 0) {
                    gameOver();
                }
            }
        });
    }

    // جمع الكرات (اللاعب فقط يجمع كرات التجميد والكرات الأخرى)
    balls.forEach((b, index) => {
        let dist = Math.hypot(player.x - b.x, player.y - b.y);
        if (dist < player.radius + b.radius) {
            if (b.type === 'yellow') {
                gameState.score += 10;
            } else if (b.type === 'speed') {
                triggerBoost();
            } else if (b.type === 'freeze') {
                freezeActive = true;
                setTimeout(() => freezeActive = false, 3000); // تجميد 3 ثواني
            }
            balls.splice(index, 1);
            document.getElementById('score-val').innerText = gameState.score;
        }
    });

    // تحقق الفوز بالمرحلة
    if (balls.length === 0) {
        gameState.running = false;
        document.getElementById('win-score').innerText = gameState.score;
        showScreen('win-screen');
    }
}

function render() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // رسم الكرات
    balls.forEach(b => {
        ctx.beginPath();
        ctx.arc(b.x, b.y, b.radius, 0, Math.PI * 2);
        if (b.type === 'yellow') ctx.fillStyle = '#ffcc00';
        else if (b.type === 'speed') ctx.fillStyle = '#00ffcc';
        else if (b.type === 'freeze') ctx.fillStyle = '#0099ff';
        ctx.fill();
        ctx.closePath();
    });

    // رسم الوحوش
    monsters.forEach(m => {
        ctx.beginPath();
        ctx.arc(m.x, m.y, m.radius, 0, Math.PI * 2);
        ctx.fillStyle = freezeActive ? '#aaddff' : (m.isBoss ? '#ff0033' : '#ff3366');
        ctx.fill();
        ctx.closePath();
    });

    // رسم اللاعب
    ctx.beginPath();
    ctx.arc(player.x, player.y, player.radius, 0, Math.PI * 2);
    ctx.fillStyle = '#00d4ff';
    ctx.fill();
    ctx.closePath();
}

function gameOver() {
    gameState.running = false;
    if (gameState.score > gameState.highScore) {
        gameState.highScore = gameState.score;
        localStorage.setItem('highScore', gameState.highScore);
    }
    document.getElementById('go-level').innerText = gameState.level;
    document.getElementById('go-score').innerText = gameState.score;
    document.getElementById('go-highscore').innerText = gameState.highScore;
    showScreen('gameover-screen');
}
