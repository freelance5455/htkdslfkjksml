/* Offline local account gate. Credentials use PBKDF2-SHA-256; no remote service. */
(()=>{
"use strict";
const ACCOUNT_KEY="pjsa.local.account.v1";
const SESSION_KEY="pjsa.local.session.v1";
const DATA_KEY="studyCompanionSyllabusV2";
const $=id=>document.getElementById(id);
const gate=$("authGate"), shell=$("appShell"), msg=$("authMessage");
const enc=new TextEncoder();
const norm=s=>String(s||"").trim().toLowerCase();
const say=(t,ok=false)=>{msg.textContent=t;msg.classList.toggle("ok",ok)};
const read=()=>{try{return JSON.parse(localStorage.getItem(ACCOUNT_KEY)||"null")}catch{return null}};
const write=a=>localStorage.setItem(ACCOUNT_KEY,JSON.stringify(a));
const hex=b=>Array.from(new Uint8Array(b),x=>x.toString(16).padStart(2,"0")).join("");
const derive=async(password,salt)=>{
 const key=await crypto.subtle.importKey("raw",enc.encode(password),"PBKDF2",false,["deriveBits"]);
 return hex(await crypto.subtle.deriveBits({name:"PBKDF2",salt,iterations:310000,hash:"SHA-256"},key,256));
};
const random=n=>{const b=new Uint8Array(n);crypto.getRandomValues(b);return hex(b)};
const hashRecovery=async(code,salt)=>derive(norm(code),salt);
const show=tab=>{
 document.querySelectorAll("[data-auth-tab]").forEach(b=>b.classList.toggle("active",b.dataset.authTab===tab));
 ["login","signup","reset"].forEach(t=>$(t+"Form").hidden=t!==tab);
 say("");
};
const unlock=a=>{
 sessionStorage.setItem(SESSION_KEY,"1");
 gate.hidden=true; shell.hidden=false;
 window.dispatchEvent(new CustomEvent("pjsa-authenticated",{detail:{username:a.username,name:a.name}}));
};
const account=read();
if(sessionStorage.getItem(SESSION_KEY)==="1" && account){gate.hidden=true;shell.hidden=false}
else {gate.hidden=false;shell.hidden=true;show(account?"login":"signup")}
document.querySelectorAll("[data-auth-tab]").forEach(b=>b.addEventListener("click",()=>show(b.dataset.authTab)));
$("loginForm").addEventListener("submit",async e=>{
 e.preventDefault();try{
 const a=read(),u=norm($("loginEmail").value),p=$("loginPassword").value;
 if(!a||u!==a.username){say("Account not found on this device.");return}
 if(await derive(p,a.salt)!==a.passwordHash){say("Incorrect password.");return}
 $("loginPassword").value="";say("Login successful.",true);unlock(a);
 }catch{say("Secure login is unavailable on this device. Update Android System WebView and try again.")}
});
$("signupForm").addEventListener("submit",async e=>{
 e.preventDefault();try{
 if(read()){say("An account already exists on this device. Log in instead.");show("login");return}
 const name=$("signupName").value.trim(),username=norm($("signupEmail").value),p=$("signupPassword").value;
 if(!name||!username||p.length<8){say("Enter your name, username and a password of at least 8 characters.");return}
 if(p!==$("signupConfirm").value){say("Passwords do not match.");return}
 const salt=random(16),recovery=random(8).toUpperCase();
 const recoverySalt=random(16);
 const a={name,username,salt,passwordHash:await derive(p,salt),recoverySalt,recoveryHash:await hashRecovery(recovery,recoverySalt),resetDay:"",resetCount:0,createdAt:new Date().toISOString()};
 write(a);
 alert("SAVE THIS RECOVERY CODE NOW. It is shown only once. Keep it somewhere private: "+recovery);
 ["signupPassword","signupConfirm"].forEach(id=>$(id).value="");
 say("Account created. Save your recovery code safely.",true);unlock(a);
 }catch{say("Account creation failed. Secure cryptography is not available.")}
});
$("resetForm").addEventListener("submit",async e=>{
 e.preventDefault();try{
 const a=read(),u=norm($("resetEmail").value),code=$("recoveryCode").value,p=$("newPassword").value;
 if(!a||u!==a.username){say("Account not found.");return}
 const day=new Date().toLocaleDateString("en-CA");
 if(a.resetDay!==day){a.resetDay=day;a.resetCount=0}
 if(a.resetCount>=3){say("Daily password-reset limit reached (3 per day). Try again tomorrow.");return}
 if(p.length<8){say("New password must contain at least 8 characters.");return}
 if(await hashRecovery(code,a.recoverySalt)!==a.recoveryHash){say("Recovery code is incorrect.");return}
 const salt=random(16);a.salt=salt;a.passwordHash=await derive(p,salt);a.resetCount++;write(a);
 sessionStorage.removeItem(SESSION_KEY);say("Password reset. Please log in with your new password.",true);show("login");
 $("loginEmail").value=u;$("loginPassword").value="";
 }catch{say("Password reset failed.")}
});
window.PJSAAuth={
 logout(){sessionStorage.removeItem(SESSION_KEY);location.reload()},
 async verifyPassword(password){const a=read();return !!a&&await derive(password,a.salt)===a.passwordHash},
 deleteAccount(){localStorage.removeItem(ACCOUNT_KEY);localStorage.removeItem(DATA_KEY);sessionStorage.removeItem(SESSION_KEY);location.reload()},
 username(){return read()?.username||""}
};
})();
