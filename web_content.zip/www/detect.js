/* محرك كشف اللهب والدخان على إطارات الكاميرا الحقيقية (دالات نقية بلا واجهة).
   طريقة كلاسيكية بلا نموذج ذكاء اصطناعي: لون اللهب + ارتعاشه، ودخان رمادي متحرك على خلفية متعلَّمة. */
(function (g) {
  const W = 160, H = 90, N = W * H;
  const FT = [0.012, 0.008, 0.005, 0.003, 0.002];   // حد مساحة اللهب لكل مستوى حساسية
  const ST = [0.10, 0.07, 0.05, 0.035, 0.025];      // حد مساحة الدخان لكل مستوى حساسية

  function newState() { return { bg: null, prevF: new Uint8Array(N), n: 0 }; }

  function buildMask(rects) {            // rects: [{x,y,w,h}] بإحداثيات 0..1
    const m = new Uint8Array(N);
    (rects || []).forEach(r => {
      const x0 = Math.floor(r.x * W), x1 = Math.ceil((r.x + r.w) * W);
      const y0 = Math.floor(r.y * H), y1 = Math.ceil((r.y + r.h) * H);
      for (let y = Math.max(0, y0); y < Math.min(H, y1); y++)
        for (let x = Math.max(0, x0); x < Math.min(W, x1); x++) m[y * W + x] = 1;
    });
    return m;
  }

  // d: مصفوفة RGBA بطول N*4. المناطق المحجوبة (mask) لا تُحلَّل إطلاقاً.
  function analyze(st, d, mask, o) {
    const sens = Math.min(5, Math.max(1, (o && o.sens) || 3));
    if (!st.bg) {
      st.bg = new Float32Array(N);
      for (let i = 0; i < N; i++) st.bg[i] = (d[i * 4] * 299 + d[i * 4 + 1] * 587 + d[i * 4 + 2] * 114) / 1000;
    }
    const cur = new Uint8Array(N), ys = new Float32Array(N);
    let valid = 0, fl = 0, flick = 0, fg = 0, changed = 0;
    for (let i = 0; i < N; i++) {
      const r = d[i * 4], gg = d[i * 4 + 1], b = d[i * 4 + 2];
      const y = (r * 299 + gg * 587 + b * 114) / 1000; ys[i] = y;
      if (mask && mask[i]) { st.bg[i] = y; continue; }
      valid++;
      const v = Math.max(r, gg, b), s = v ? (v - Math.min(r, gg, b)) / v : 0;
      if (r > 200 && gg > 90 && gg <= r && b < gg * 0.75 && s > 0.4) { cur[i] = 1; fl++; }
      if (cur[i] !== st.prevF[i]) flick++;
      const diff = Math.abs(y - st.bg[i]);
      if (diff > 14) { changed++; if (s < 0.22 && y > 50 && y < 235) fg++; }
    }
    const globalChange = valid ? changed / valid : 0;
    for (let i = 0; i < N; i++) {                      // تحديث الخلفية
      const diff = Math.abs(ys[i] - st.bg[i]);
      st.bg[i] = globalChange > 0.6 ? ys[i] : st.bg[i] + (ys[i] - st.bg[i]) * (diff > 14 ? 0.01 : 0.05);
    }
    st.prevF = cur; const warm = st.n++ < 1;   // الإطار الأول بلا مرجع للمقارنة
    const flameRatio = valid ? fl / valid : 0, smokeRatio = valid ? fg / valid : 0;
    const flickRatio = fl ? flick / fl : 0, grayShare = changed ? fg / changed : 0;
    return {
      flame: !warm && flameRatio >= FT[sens - 1] && flickRatio >= 0.2,
      smoke: smokeRatio >= ST[sens - 1] && grayShare >= 0.6 && globalChange < 0.6,
      flameRatio, smokeRatio, flickRatio, grayShare, globalChange
    };
  }

  const api = { W, H, N, newState, buildMask, analyze };
  if (typeof module !== "undefined") module.exports = api;
  g.DET = api;
})(typeof window !== "undefined" ? window : globalThis);
