/* Dhonnobad Foundation Premium UI helpers — no Firebase/business logic changes. */
(()=>{'use strict';
 const reduce=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
 // Reading progress indicator
 const progress=document.createElement('div');
 progress.className='df-scroll-progress';
 progress.setAttribute('aria-hidden','true');
 document.body.appendChild(progress);
 const updateProgress=()=>{
   const doc=document.documentElement;
   const max=doc.scrollHeight-window.innerHeight;
   const ratio=max>0?Math.min(1,Math.max(0,window.scrollY/max)):0;
   progress.style.transform=`scaleX(${ratio})`;
 };
 window.addEventListener('scroll',updateProgress,{passive:true});
 window.addEventListener('resize',updateProgress,{passive:true});
 updateProgress();
 // Back-to-top is managed only by #topBtn in index.html and script.js.
 // Do not inject a second floating navigation button here.
 // Gentle press feedback; ignore form submission controls and links with navigation semantics.
 document.addEventListener('pointerdown',e=>{
   const el=e.target.closest('button,[role="button"],.feature-card,.staff-card,.moderator-profile-card');
   if(!el||reduce||el.disabled)return;
   el.classList.remove('df-press-feedback');
   requestAnimationFrame(()=>{el.classList.add('df-press-feedback');setTimeout(()=>el.classList.remove('df-press-feedback'),260)});
 },{passive:true});
 // Add current-year marker only to explicitly marked elements.
 document.querySelectorAll('[data-df-current-year]').forEach(el=>{el.textContent=String(new Date().getFullYear())});
})();
