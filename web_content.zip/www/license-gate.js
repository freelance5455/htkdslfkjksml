(function(){var s=document.createElement('style');s.textContent="#tj-gate{position:fixed;inset:0;z-index:99999;background:rgb(244,246,243);display:flex;align-items:center;justify-content:center;padding:24px;font-family:Tajawal,system-ui,sans-serif;direction:rtl;color:#14532d;padding-top:max(24px,env(safe-area-inset-top,0px));padding-bottom:max(24px,env(safe-area-inset-bottom,0px))}\n#tj-gate .box{width:100%;max-width:380px;background:#fff;border:1px solid rgba(2,44,34,.15);border-radius:24px;padding:28px 22px;text-align:center;box-shadow:0 8px 30px rgba(2,44,34,.12)}\n#tj-gate .stripe{height:6px;border-radius:99px;margin-bottom:22px;background:linear-gradient(90deg,#022c22,#059669)}\n#tj-gate h1{margin:0 0 6px;font-size:26px;font-weight:900;color:#022c22}\n#tj-gate p{margin:0 0 20px;font-size:13px;line-height:1.7;color:#475569}\n#tj-gate input{width:100%;box-sizing:border-box;height:58px;border-radius:16px;border:1.5px solid #cbd5e1;background:#f8fafc;color:#022c22;text-align:center;font-size:26px;font-weight:700;letter-spacing:10px;text-transform:uppercase;direction:ltr;outline:none;font-family:monospace;-webkit-user-select:text;user-select:text}\n#tj-gate input:focus{border-color:#059669;box-shadow:0 0 0 3px rgba(5,150,105,.25)}\n#tj-gate input.err{border-color:#ef4444}\n#tj-gate button{width:100%;height:52px;margin-top:14px;border:0;border-radius:16px;background:#059669;color:#fff;font-size:16px;font-weight:800;font-family:inherit;cursor:pointer}\n#tj-gate button:disabled{opacity:.4;cursor:not-allowed}\n#tj-gate .msg{min-height:20px;margin-top:12px;font-size:13px;color:#dc2626}";(document.head||document.documentElement).appendChild(s)})();

(function(){
  var SALT="28655ea367479eaa";
  var H=["cffa15c2929ed03e451531f315bf79ba75c9411973dda4264dd00608b492d392", "7e8ecf4563f3d151deb59be6f9389394f638fefed839b37272f175e0643faeca", "bd416836306cac76cb6f24dd57d609537d6e4e07788632a64dd112a55b8c33ee", "cea154cdf210f5e98b03c88651961b439ae5bc98ca66b99e999328691e826151", "6ef5f94eb8de24b524b8978235b117dc783a4afc7c75df1e79684d9b2e0ba756", "f5df8199f9a056e37e9a00f172f8b40fa0c2b928cd33c43b3619a48c7ebe5477", "eb18d1e6e2bb59d754d559ac804b3ed78903ae24b093220122d8456fb96b2988", "ae50c72d5b712823c604e3b75c7ee43ee7e208bce53f7cd1f4ee4fd82eb8359c", "48fd2683961c758f7f483399a0b971f23079eceac95f285f122ebe156e69ca57", "82fda2b034b2e2e565720d74bfba59d0b2c13f07fb38b31bbdd2a8dc96226db9", "32653b46009be03cd59db72b42486b84f8b412cd52046be0990dec420d3593bc", "87ba80c7161e512f9a7a810962da5e3e0f88a711ec5bf0f075cc2411dc165b04", "db91e88e7a725780c40fd20c7d429b2fc8d8005fb84912c486624d3f8e454405", "69a5bd5ab605f34e658c1a4eeadaecc615ac8ed196655fda51c8c11675c090e2", "9c8fb9aeac5cec59c5a3c3117756bc4f60a0a37f4fc0244f2f769da9a2a7cee2", "6d16e1175666b3e47c24570fd7c303cb754f31e3cc29a5ae0f0a330e467a4298", "0490c63d2ec3f672df7955189c69ed3e2331d1552e57b66e357859c9387e8fdb", "4b645968ea16ae684368e99d642ad7302df0ccdd0a19ecc6ca842c22d2a52eaf", "80ff1051b3ccc8359991402460444a584d14aa419ae518465791337850ec6ea0", "ba20ccd748c6cfd470ba6f4ca88135becbe64f9c9f32d732495b97da7d0c26e5", "1ca562235784036f9ccbedc4adb3ec59c4f4d5ae196f2e2ad674cb69b74ff75d", "fa4f8a7b5e0166b4407d97c416a984b8c34b74800052b02ddad52d7f0ca971d3", "bc8165fd55ceb0801f3f761bdfef23ed1143d4db93d6cd8f708617d7a2695471", "e24347ef055202e84f076db6c3606523fef19e93734ed8e6a03deebf17cd988d", "6ea3564acfd49869969f99d77329a0c4bdb6d49803a91d57e5331e14fd55111f", "2ee5e9ec1a45f0eb7522d4e15a3359d54220b463d8e60e6fa14e12c6ddca58b7", "92be510a4dbf886c244e8ffffad6877890214026b670d00966cfb4a909008868", "6adecfbde9dc57e51de5a3b015005abb131c3e2abd7f5ed6c84312e75fc39c0c", "00073b3704042095598de813d06e675f6980b28768c0a410ce37b8376f0c647c", "fcbac748aedb50b5eb094e4319ce4c259176ff2435aceb7765784fcba94a0f09", "335a95336af52bc58ccfac752fa00b6c73a667f99d341a45ded923738471910f", "722ccc385d64fbaf93083552587f3eb0b56a42e9c449ad1f96ad038372c63c65", "30c4b200ce6d1209a01a7c5da606483a089dfb8b39517ca3902bf42159374bfd", "89c78b965945991b769bef37ef3fdc1c2690bd2211b9a9f2fad1731f2a14aef0", "f47e2acd6c0ee85eecc22f261aeddc9fde678a6d908281bf42e95c8ff88ca87c", "81780591263212f1deb044927fc63719ab5b3c6f51c0174dae8c3eccaf8054da", "6be70c8ca266ffe44247d626c6ee2c28e965032bd511b7a2d59fa50469c7d4ca", "ca5444e8afeb907e924fb0ad023d372410c36092ed686b79be2993fa0384d78d", "fecc38fb10eccc0670ae9d637357d581e9f234cbbadf396f659df6eb393ffaba", "646410609ebdc63a1016cc48d18e75cac6033214108d802890a8851cd7466f83", "1fba1de4aa2ad0698ce1ebc958eb6c2e4cc2be3a9fe3b1024a46af3ba216dbf4", "48bbc1200460e992f84fd13638a5aaf3a56d4b561c6a377c4419001f2b30e081", "056ecce4428e4dcb7f7a9321e84b5fc11fb8742f93d0722eb3e86cb8e4e7ec03", "31811371dbac99f5814eb795a633fac514be0ad4567ded79ee7bcda373e45371", "c2a9baac6d263416369d4f2da8880a7185ff69dd2583b10a4d3d3bad0bafe9be", "858c5dce728b03e6bd7c081a0229d16273a94579dde828606b488abafa6ddd41", "b79476707a23240c9bf42fcf2c4c21ec420bd79a4fb769e23b4b8cb2a790e8dc", "82dde7fc58388686d6212dee9266e8b0bab06fce5da1408c7fff907932ac2ee3", "fa0790ff203f4c3102bd823696d9a24d689c93fafdd31de26065e12622513942", "aca19a44d50d70a4092724318ea2a0515da2cf5419a65fc9bcdd4dce8f46bbcb", "078d72030cc9f916822364903fcb00468a1ca2d3224d0e1358a7a94f1b39486f", "1d2c85f96bb0957824aa01c7e5ae79b1c0f18ea125b9de313cea843a614bdcfd", "6206717c2500e7b744d348a005dcc2d8f2fbb3d55412f028f641592b3618ccd7", "bed2c6e6617a21ba2e79d1ba9f8a1ae1093b441d9b693beb2eb41560d5c97190", "75d6b10bbf5160cfbdc475454eea4fc88cb444595c2e7b659ec32371cded8918", "33cc48a88bceed5d93c8d6b6e4d7f6b36db63f2995f09ccaf763f6f5dca5ee83", "3bbe41327dff1dc1e1e03fb60400f532b4ebf08a437c7d43abe13ab8f296ff16", "9eea8080da04c59a863cc67f1103f4eb93a41774bdbaedc31ac0ee2f47ad6f2c", "1619d956dd8b1d54583cba684dcf4df254bfba3e335909e1e2bab72ad11330a8", "0387b5d13b1619c3681d86e38c1704d5bf618879df40c254ab49836e15cafbc5", "906466b5e6a040ffeed6d6a131993c2fa66f9971f2f00d382c4dd00bcef56da8", "6e6eae3df92fa3cfdf90a6ef7f26d864f06474802a8fe9e2eec06a7b6b8dd82d", "b551d07f5264667f5c8d5ba219cc954b39bf0e07d92fc0a123ff31890b06bb45", "0db2e0cf0192430648d4f8ca9a5c6507a831ad96f96fbf3beab3c13a799a1481", "909458cd5bcebc253516ee231469417c9f9109d3ab35963214a17f24ef5b6cf8", "358f9b021b0a9fe804b430d857956f7326b08cdef283b1f2507865ff6e53ed4c", "c57991c33e19fd66486fa2063003fdde4ad77dd7200bce0c87f317f9a5897230", "ee82a369d528c849365c6c77473e1ad0922009bb5dfcec38d42285e779490ed7", "d10adb2bb1d6c9902622c5d39be3d4fc621204e7f56a6e15cffd549f5e8f7aa8", "a68c7db82d2c62f4edb3e95fc4726a567ec2bc7bcc9acd654ecd668f6e2fb170", "50dc6a5af154ed31d5cbb61a58545ef82dddcee8e08ffc77b2d0da66b0a60912", "12dba974ca34504b9595ab9206d343336988b766da69fe3e4b5c868f7500a5d5", "b496aecb69d6d70808f2c2835cf379a0e551803de71ad96d97862658b77892b6", "57a9afffde623a62e18939cd6349aee17fa7a9a856ae091a9687fac2a3dfded3", "4f0f60b9aa7684290545eb8e43ee6665e20f58c1a3bf11829cf874852334e91d", "c4ecaa1670e52cb888596db59851c0800cf0efcd4823251810266f0a6d991c80", "c91f6c37850441d22fa9d0dac6c6f0ff715f0f5f01778ad49b5d9d9d71474c1e", "952872127bf4076ed11dc96a073c260dd489917539c3e227fcf8168996350ef4", "da8bbab598bebb955cce83919fa5958678ef2d8e55492a9a7d575f48c11cc36b", "3b024d47597e0a36e097961277c8f6177cd8d99922eb176799e06d2120a0bbc2", "e3e8a6ed3c951d39620cab7195e6def18cf85b5eb3e06ecec59c57e51430f346", "e9b8c00e2dfbd1c27d821baf71cdd7a6fb24bcc437251b9fc135d95af879d732", "5c3fa89a0072fcb708f29efcc3546c1a999045939c96da33ceeda4428fcd2349", "70871dd0d8f3776558b3121f234d5c4abf7c0394129742d288cd7e2c3eef64e5", "8202de098643c26803a92a91b0264cf300f3c6ed2f4203e36fde1c482ac716bd", "011ba5aa82f4e0653b70bbe4143329c869f06517229eaefbc9c13a10a929559f", "d2ace7352b6f5fc9fa0f13246909f155d22c63f6175bdca5df2053b1bd2cd6a7", "fcf426cf2e7aa7f6f2c9ffdbbc6493fc641c937cd5d4b002dc0a53bac27ba333", "7d301d6b1a14d8562a99974411de9d42d4e1f84ddcaafb3a3eff5ddbbbc155be", "1c4375e2d5628bd3612319cda73443de12f15f8bf65b27b443731bd79cf0d574", "b5596a0a78924dcae6993680775880846e88c93b14a999b9dfebe795088556f9", "12573af17ec1b735176e57c33c2f85bd9b3e2e72beeaff6721feb268dafd0c20", "7a89e5bca0a0fd3156e1e5ec0094ecfb01e58043dc59d7c19f253d73299f829e", "53da7e1657fdda6235c8adf1e99cfb539e842d1dc447662b9e530205800c900a", "302b91a067febc9b11ba0ad8fd05e9d7e3ceb2c2a973e45215cb8616e5222def", "9debb6e8cde97f95255f5ecd6abf47c4f0b2542eed52122d1a346f3f219b375a", "84d401fc2f0c29dcb5be0c3fe18e898f7f09b557af7e65689d0db31227bece6e", "f1404c63e08e7b0db4473d37c5e7d4999904d40ce726c7f93e2af172fd22cd31", "821bd0d078c4b396ecf4dcc5090d7a5b0d744e85fd0efe6a5acd0ec217dde0e1", "55bc886e56150f684b5f00396f13974b4ba7862246f0b7dabda67884187607c0"];
  var LS="tj_lic_v1";
  function sha256(s){
    var K=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
    var h=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
    var b=[],i;
    for(i=0;i<s.length;i++)b.push(s.charCodeAt(i)&255);
    var l=b.length*8;
    b.push(0x80);
    while(b.length%64!==56)b.push(0);
    b.push(0,0,0,0,(l>>>24)&255,(l>>>16)&255,(l>>>8)&255,l&255);
    function rr(x,n){return(x>>>n)|(x<<(32-n))}
    for(var o=0;o<b.length;o+=64){
      var w=[];
      for(i=0;i<16;i++)w[i]=(b[o+i*4]<<24)|(b[o+i*4+1]<<16)|(b[o+i*4+2]<<8)|b[o+i*4+3];
      for(i=16;i<64;i++){
        var s0=rr(w[i-15],7)^rr(w[i-15],18)^(w[i-15]>>>3);
        var s1=rr(w[i-2],17)^rr(w[i-2],19)^(w[i-2]>>>10);
        w[i]=(w[i-16]+s0+w[i-7]+s1)|0;
      }
      var a=h[0],bb=h[1],c=h[2],d=h[3],e=h[4],f=h[5],g=h[6],hh=h[7];
      for(i=0;i<64;i++){
        var S1=rr(e,6)^rr(e,11)^rr(e,25);
        var ch=(e&f)^(~e&g);
        var t1=(hh+S1+ch+K[i]+w[i])|0;
        var S0=rr(a,2)^rr(a,13)^rr(a,22);
        var mj=(a&bb)^(a&c)^(bb&c);
        var t2=(S0+mj)|0;
        hh=g;g=f;f=e;e=(d+t1)|0;d=c;c=bb;bb=a;a=(t1+t2)|0;
      }
      h[0]=(h[0]+a)|0;h[1]=(h[1]+bb)|0;h[2]=(h[2]+c)|0;h[3]=(h[3]+d)|0;
      h[4]=(h[4]+e)|0;h[5]=(h[5]+f)|0;h[6]=(h[6]+g)|0;h[7]=(h[7]+hh)|0;
    }
    var out="";
    for(i=0;i<8;i++)out+=("00000000"+(h[i]>>>0).toString(16)).slice(-8);
    return out;
  }
  function norm(v){
    v=String(v||"");
    v=v.replace(/[\u0660-\u0669]/g,function(c){return String(c.charCodeAt(0)-1632)});
    v=v.replace(/[\u06F0-\u06F9]/g,function(c){return String(c.charCodeAt(0)-1776)});
    return v.toUpperCase().replace(/[^A-Z0-9]/g,"");
  }
  function hashOf(k){return sha256(SALT+k)}
  function valid(k){return k.length===5&&H.indexOf(hashOf(k))!==-1}
  function stored(){try{return localStorage.getItem(LS)}catch(e){return null}}
  function save(k){try{localStorage.setItem(LS,hashOf(k))}catch(e){}}

  window.__tijGate=function(start){
    var st=stored();
    if(st&&H.indexOf(st)!==-1){start();return}
    var root=document.getElementById("root");
    var g=document.createElement("div");g.id="tj-gate";
    g.innerHTML='<div class="box"><div class="stripe"></div><h1>تجاريك</h1><p>أدخل مفتاح المنتج المكوّن من 5 خانات (أرقام وحروف) لتفعيل البرنامج.</p><input id="tj-key" type="text" maxlength="9" inputmode="text" autocomplete="off" autocapitalize="characters" spellcheck="false" placeholder="•••••"><div class="msg" id="tj-msg"></div><button id="tj-btn" type="button">تفعيل</button></div>';
    document.body.appendChild(g);
    if(root)root.style.display="none";
    var inp=g.querySelector("#tj-key"),btn=g.querySelector("#tj-btn"),msg=g.querySelector("#tj-msg");
    var fails=0,lockUntil=0,timer=null;
    inp.addEventListener("input",function(){var n=norm(inp.value).slice(0,5);if(inp.value!==n)inp.value=n;inp.classList.remove("err");if(!lockUntil)msg.textContent=""});
    function tick(){
      var left=Math.ceil((lockUntil-Date.now())/1000);
      if(left<=0){clearInterval(timer);lockUntil=0;btn.disabled=false;msg.textContent="";return}
      msg.textContent="محاولات كثيرة خاطئة. انتظر "+left+" ثانية.";
    }
    function submit(){
      if(lockUntil&&Date.now()<lockUntil)return;
      var k=norm(inp.value);
      if(k.length!==5){msg.textContent="المفتاح يجب أن يكون 5 خانات.";inp.classList.add("err");return}
      if(valid(k)){
        save(k);
        if(timer)clearInterval(timer);
        g.parentNode.removeChild(g);
        if(root)root.style.display="";
        start();
      }else{
        fails++;
        inp.classList.add("err");
        msg.textContent="مفتاح المنتج غير صحيح.";
        if(fails%5===0){
          lockUntil=Date.now()+30000;btn.disabled=true;tick();
          timer=setInterval(tick,500);
        }
      }
    }
    btn.addEventListener("click",submit);
    inp.addEventListener("keydown",function(e){if(e.key==="Enter")submit()});
    setTimeout(function(){try{inp.focus()}catch(e){}},200);
  };
})();
