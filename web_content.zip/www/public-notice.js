import { database } from "./firebase.js";
import { ref, onValue } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-database.js";

const box = document.getElementById("publicNoticeList");
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({
  "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
}[c]));

function timeValue(n){
  const t = n?.publishedAt;
  const ms = typeof t === "number" ? t : Date.parse(t || "");
  return Number.isFinite(ms) ? ms : 0;
}

function formatDate(n){
  const ms = timeValue(n);
  if(!ms) return "";
  try { return new Intl.DateTimeFormat("bn-BD",{dateStyle:"medium",timeStyle:"short"}).format(new Date(ms)); }
  catch { return new Date(ms).toLocaleString("bn-BD"); }
}

function render(snapshot){
  if(!box) return;
  const rows=[];
  if(snapshot.exists()){
    snapshot.forEach(ch => rows.push({key:ch.key,...(ch.val()||{})}));
  }

  const now=Date.now();
  const active=rows
    .filter(n => n.active !== false)
    .filter(n => !n.expiresAt || Number(n.expiresAt) > now)
    .sort((a,b)=>
      Number(Boolean(b.pinned))-Number(Boolean(a.pinned)) ||
      timeValue(b)-timeValue(a)
    );

  if(!active.length){
    box.innerHTML=`<div class="notice-empty">
      <span>📭</span>
      <strong>এই মুহূর্তে কোনো নতুন নোটিশ নেই</strong>
      <p>নতুন ঘোষণা প্রকাশ হলে এখানে দেখা যাবে।</p>
    </div>`;
    return;
  }

  box.innerHTML=active.slice(0,12).map(n=>{
    const pinned=n.pinned ? '<span class="notice-tag pinned">📌 গুরুত্বপূর্ণ</span>' : '';
    const type=n.type==="urgent" ? '<span class="notice-tag urgent">⚠ জরুরি</span>' : '<span class="notice-tag normal">আপডেট</span>';
    return `<article class="public-notice-card ${n.pinned?'is-pinned':''}">
      <div class="public-notice-icon">${n.type==="urgent"?"⚠️":"📢"}</div>
      <div class="public-notice-body">
        <div class="notice-tags">${type}${pinned}</div>
        <h3>${esc(n.title||"নোটিশ")}</h3>
        <p>${esc(n.text||"")}</p>
        <time datetime="${esc(new Date(timeValue(n)||Date.now()).toISOString())}">${esc(formatDate(n))}</time>
      </div>
    </article>`;
  }).join("");
}

if(box){
  onValue(ref(database,"publicNotices"), render, error => {
    box.innerHTML=`<div class="notice-empty notice-error">
      <span>⚠️</span>
      <strong>নোটিশ এখন লোড করা যাচ্ছে না</strong>
      <p>ইন্টারনেট সংযোগ বা Firebase permission যাচাই করুন।</p>
    </div>`;
  });
}
