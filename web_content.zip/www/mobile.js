/* Infinity Elements — мобильный слой управления.
 * Игра читает ввод из глобальных объектов keys и mouse (WASD, ЛКМ, ПКМ, Пробел).
 * Здесь они заполняются с сенсорных элементов: плавающий джойстик слева,
 * кнопки атаки / особой способности / ульты справа. Код боя не изменён.
 */
(function () {
  'use strict';
  var isTouch = matchMedia('(pointer: coarse)').matches || 'ontouchstart' in window || /[?&]touch\b/.test(location.search);
  if (!isTouch) return;

  var html = document.documentElement;
  html.classList.add('tch');

  // ---------- разметка ----------
  var root = document.createElement('div');
  root.id = 'tc';
  root.innerHTML =
    '<div id="tcJoy"><div id="tcJoyBase"><div id="tcJoyKnob"></div></div></div>' +
    '<div id="tcBtns">' +
      '<div class="tcb" id="tcUlt" data-k="ult"><span>★</span><small>Ульта</small></div>' +
      '<div class="tcb" id="tcSpc" data-k="spc"><span>✦</span><small>Спец</small></div>' +
      '<div class="tcb" id="tcAtk" data-k="atk"><span>⚔</span><small>Атака</small></div>' +
    '</div>' +
    '<div id="tcTop">' +
      '<button type="button" id="tcSnd">🔊</button>' +
      '<button type="button" id="tcZoom">🔍</button>' +
      '<button type="button" id="tcScore">▤</button>' +
      '<button type="button" id="tcMenu">☰</button>' +
    '</div>';
  document.body.appendChild(root);

  var rot = document.createElement('div');
  rot.id = 'tcRot';
  rot.innerHTML = '<div>📱↻<br>Поверни телефон горизонтально</div>';
  document.body.appendChild(rot);

  var $ = function (id) { return document.getElementById(id); };
  function nudge() { try { if (typeof guestNudge === 'function') guestNudge(); } catch (e) {} }
  function fakeKey(type, code) {
    window.dispatchEvent(new KeyboardEvent(type, { code: code, key: code, bubbles: true, cancelable: true }));
  }

  // ---------- состояние ----------
  var aim = { mode: 'auto', ang: 0, dist: 320 };   // auto — на ближайшего врага; vec — по направлению стика
  var lastVec = { ox: 320, oy: 0 };
  var zoomSteps = [1, 1.5, 2], zoomIdx = 1, wasPlaying = false;

  function curState() { try { return state; } catch (e) { return ''; } }
  function me() { try { return players[myIndex]; } catch (e) { return null; } }
  function nearestEnemy(m) {
    var best = null, bd = 1e12;
    for (var i = 0; i < players.length; i++) {
      var p = players[i];
      if (!p || p === m || !p.alive || p.left) continue;
      if (m.team >= 0 && p.team === m.team) continue;
      var d = (p.x - m.x) * (p.x - m.x) + (p.y - m.y) * (p.y - m.y);
      if (d < bd) { bd = d; best = p; }
    }
    return best;
  }
  function applyAim() {
    var m = me(); if (!m) return;
    var ox, oy;
    if (aim.mode === 'vec') {
      ox = Math.cos(aim.ang) * aim.dist; oy = Math.sin(aim.ang) * aim.dist;
      lastVec.ox = ox; lastVec.oy = oy;
    } else {
      var e = nearestEnemy(m);
      if (e) { ox = e.x - m.x; oy = e.y - m.y; if (ox === 0 && oy === 0) ox = 1; lastVec.ox = ox; lastVec.oy = oy; }
      else { ox = lastVec.ox; oy = lastVec.oy; }
    }
    mouse.sx = view.x + (m.x + ox) * view.scale;
    mouse.sy = view.y + (m.y + oy) * view.scale;
  }

  // ---------- джойстик ----------
  var joy = $('tcJoy'), jBase = $('tcJoyBase'), jKnob = $('tcJoyKnob');
  var jPid = null, jx = 0, jy = 0, JR = 56;
  function setMove(nx, ny) {
    var T = 0.38;
    keys.KeyA = nx < -T; keys.KeyD = nx > T;
    keys.KeyW = ny < -T; keys.KeyS = ny > T;
  }
  function stopMove() { keys.KeyA = keys.KeyD = keys.KeyW = keys.KeyS = false; }
  joy.addEventListener('pointerdown', function (e) {
    if (jPid !== null) return;
    e.preventDefault();
    jPid = e.pointerId; joy.setPointerCapture(jPid);
    jx = e.clientX; jy = e.clientY;
    jBase.style.left = jx + 'px'; jBase.style.top = jy + 'px';
    jBase.classList.add('on');
    jKnob.style.transform = 'translate(-50%,-50%)';
    setMove(0, 0);
  });
  joy.addEventListener('pointermove', function (e) {
    if (e.pointerId !== jPid) return;
    var dx = e.clientX - jx, dy = e.clientY - jy, len = Math.hypot(dx, dy) || 1;
    var k = Math.min(1, len / JR);
    var nx = dx / len * k, ny = dy / len * k;
    jKnob.style.transform = 'translate(calc(-50% + ' + (nx * JR) + 'px), calc(-50% + ' + (ny * JR) + 'px))';
    setMove(len < 14 ? 0 : nx, len < 14 ? 0 : ny);
    nudge();
  });
  function joyEnd(e) {
    if (e.pointerId !== jPid) return;
    jPid = null; jBase.classList.remove('on'); stopMove(); nudge();
  }
  joy.addEventListener('pointerup', joyEnd);
  joy.addEventListener('pointercancel', joyEnd);

  // ---------- кнопки с прицеливанием: зажал и потянул — целишься ----------
  function bindAim(el, kind) {
    var pid = null, cx = 0, cy = 0;
    function drag(e) {
      var dx = e.clientX - cx, dy = e.clientY - cy, len = Math.hypot(dx, dy);
      if (len < 18) { aim.mode = 'auto'; return; }
      aim.mode = 'vec'; aim.ang = Math.atan2(dy, dx);
      aim.dist = 150 + Math.min(1, (len - 18) / 80) * 420;
    }
    el.addEventListener('pointerdown', function (e) {
      if (pid !== null) return;
      e.preventDefault();
      pid = e.pointerId; el.setPointerCapture(pid);
      var r = el.getBoundingClientRect(); cx = r.left + r.width / 2; cy = r.top + r.height / 2;
      el.classList.add('down');
      drag(e); applyAim();
      if (kind === 'atk') mouse.down = true;
      if (kind === 'spc') mouse.rdown = true;
      nudge();
    });
    el.addEventListener('pointermove', function (e) { if (e.pointerId === pid) { drag(e); applyAim(); } });
    function end(e) {
      if (e.pointerId !== pid) return;
      pid = null; el.classList.remove('down');
      if (kind === 'atk') mouse.down = false;
      if (kind === 'spc') mouse.rdown = false;
      if (kind === 'ult') {
        applyAim(); keys.Space = true; nudge();
        setTimeout(function () { keys.Space = false; nudge(); }, 170);
      }
      nudge();
    }
    el.addEventListener('pointerup', end);
    el.addEventListener('pointercancel', end);
  }
  bindAim($('tcAtk'), 'atk'); bindAim($('tcSpc'), 'spc'); bindAim($('tcUlt'), 'ult');

  // ---------- верхние кнопки ----------
  $('tcMenu').addEventListener('click', function () {
    if (!confirm('Выйти в меню?')) return;
    fakeKey('keydown', 'Escape'); fakeKey('keyup', 'Escape');
  });
  var sc = $('tcScore');
  sc.addEventListener('pointerdown', function (e) { e.preventDefault(); fakeKey('keydown', 'Tab'); });
  var scUp = function () { fakeKey('keyup', 'Tab'); };
  sc.addEventListener('pointerup', scUp); sc.addEventListener('pointercancel', scUp);
  $('tcSnd').addEventListener('click', function () {
    fakeKey('keydown', 'KeyM'); fakeKey('keyup', 'KeyM');
    this.textContent = this.textContent === '🔊' ? '🔇' : '🔊';
  });
  $('tcZoom').addEventListener('click', function () {
    zoomIdx = (zoomIdx + 1) % zoomSteps.length;
    devZoom.target = zoomSteps[zoomIdx];
  });

  // ---------- общий цикл ----------
  var ultBtn = $('tcUlt'), spcBtn = $('tcSpc');
  function tick() {
    var st = curState(), playing = st === 'playing' || st === 'dead';
    root.classList.toggle('on', playing);
    html.classList.toggle('ingame', playing);
    if (playing) {
      if (!wasPlaying) { devZoom.target = zoomSteps[zoomIdx]; }
      applyAim();
      var m = me();
      if (m) {
        try { ultBtn.classList.toggle('rdy', (m.ult || 0) >= ULT_NEED); ultBtn.style.setProperty('--p', Math.min(100, (m.ult || 0) / ULT_NEED * 100) + '%'); } catch (e) {}
        spcBtn.classList.toggle('cd', (m.rmbCd || 0) > 0.05);
      }
    } else if (wasPlaying) {
      stopMove(); mouse.down = mouse.rdown = false; keys.Space = false;
    }
    wasPlaying = playing;
    requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);

  // касание пустого места канваса в бою не должно превращаться в «клик мышью» (иначе ЛКМ мигает)
  var cv = $('game');
  if (cv) {
    var block = function (e) { var s = curState(); if (s === 'playing' || s === 'dead') e.preventDefault(); };
    cv.addEventListener('touchstart', block, { passive: false });
    cv.addEventListener('touchend', block, { passive: false });
  }

  // запрет контекстного меню и выделения на элементах управления
  ['contextmenu', 'selectstart', 'dragstart'].forEach(function (t) {
    root.addEventListener(t, function (e) { e.preventDefault(); });
  });

  // первый тап: полный экран и горизонталь (где браузер это позволяет)
  window.addEventListener('pointerdown', function first() {
    window.removeEventListener('pointerdown', first, true);
    try {
      var standalone = matchMedia('(display-mode: fullscreen), (display-mode: standalone)').matches;
      var el = document.documentElement;
      if (!standalone && !document.fullscreenElement) {
        var rq = el.requestFullscreen || el.webkitRequestFullscreen;
        if (rq) { var p = rq.call(el, { navigationUI: 'hide' }); if (p && p.catch) p.catch(function () {}); }
      }
      if (screen.orientation && screen.orientation.lock) { var q = screen.orientation.lock('landscape'); if (q && q.catch) q.catch(function () {}); }
    } catch (e) {}
  }, true);

  // установка как приложение (PWA)
  if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) {
    navigator.serviceWorker.register('sw.js').catch(function () {});
  }
})();
