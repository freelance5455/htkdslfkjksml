/* ads.js — طبقة إعلانات AdMob للعبة (يُحمَّل قبل script.js)
 * يدعم:
 *  1) إضافة Capacitor:  @capacitor-community/admob
 *  2) جسر Android WebView الموجود أصلًا (window.SnakeAds / window.AndroidAds)
 * في المتصفح العادي لا يفعل شيئًا، واللعبة تعمل كالمعتاد.
 */
(function(){
  'use strict';

  var CONFIG={
    // true = إعلانات تجريبية من Google (آمن أثناء التطوير). غيّرها إلى false عند النشر.
    testMode:true,
    // معرّفات الوحدات الإعلانية. القيم التالية تجريبية رسمية من Google؛ استبدلها بمعرّفاتك من لوحة AdMob.
    ids:{
      banner:'ca-app-pub-3940256099942544/6300978111',
      interstitial:'ca-app-pub-3940256099942544/1033173712',
      rewarded:'ca-app-pub-3940256099942544/5224354917'
    },
    interstitialEvery:3,   // إعلان بيني كل 3 فواصل (نهاية جولة / إكمال ليفل)
    minGapMs:90000         // لا يظهر إعلانان بينيان خلال أقل من 90 ثانية
  };

  var cap=window.Capacitor;
  var initDone=false,initP=null;
  var wantBanner=true,bannerShown=false;
  var interReady=false,interLoading=false;
  var breaksSince=0,lastInterAt=Date.now(),busy=false;

  function plugin(){
    try{
      if(!cap)return null;
      if(cap.isNativePlatform&&!cap.isNativePlatform())return null;
      if(cap.Plugins&&cap.Plugins.AdMob)return cap.Plugins.AdMob;
      if(cap.registerPlugin&&(!cap.isPluginAvailable||cap.isPluginAvailable('AdMob')))return cap.registerPlugin('AdMob');
    }catch(e){}
    return null;
  }
  function bridge(){return window.SnakeAds||window.AndroidAds||null;}

  function on(A,name,fn){
    try{return Promise.resolve(A.addListener(name,fn)).catch(function(){return null;});}
    catch(e){return Promise.resolve(null);}
  }
  function off(handles){
    (handles||[]).forEach(function(h){try{if(h&&h.remove)h.remove();}catch(e){}});
  }

  // ===== التهيئة + موافقة المستخدم (UMP) =====
  function consent(A){
    if(!A.requestConsentInfo)return Promise.resolve();
    return A.requestConsentInfo().then(function(info){
      if(info&&info.isConsentFormAvailable&&info.status==='REQUIRED')return A.showConsentForm();
    }).catch(function(){});
  }
  function init(){
    if(initP)return initP;
    var A=plugin();
    if(!A){initP=Promise.resolve(false);return initP;}
    initP=Promise.resolve()
      .then(function(){return A.initialize({initializeForTesting:CONFIG.testMode});})
      .then(function(){return consent(A);})
      .then(function(){initDone=true;preloadInterstitial();applyBanner();return true;})
      .catch(function(){return false;});
    return initP;
  }

  // ===== البانر =====
  function applyBanner(){
    var A=plugin();
    if(A){
      if(!initDone)return;
      if(wantBanner&&!bannerShown){
        bannerShown=true;
        A.showBanner({adId:CONFIG.ids.banner,adSize:'ADAPTIVE_BANNER',position:'BOTTOM_CENTER',margin:0,isTesting:CONFIG.testMode})
          .catch(function(){bannerShown=false;});
      }else if(!wantBanner&&bannerShown){
        bannerShown=false;
        A.removeBanner().catch(function(){});
      }
      return;
    }
    var b=bridge();
    if(b){
      try{
        if(wantBanner&&typeof b.showBanner==='function')b.showBanner();
        else if(!wantBanner&&typeof b.hideBanner==='function')b.hideBanner();
      }catch(e){}
    }
  }

  // ===== الإعلان البيني =====
  function preloadInterstitial(){
    var A=plugin();
    if(!A||!initDone||interReady||interLoading)return;
    interLoading=true;
    A.prepareInterstitial({adId:CONFIG.ids.interstitial,isTesting:CONFIG.testMode})
      .then(function(){interReady=true;})
      .catch(function(){})
      .then(function(){interLoading=false;});
  }
  function showInterstitialCap(A,done){
    var handles=[],finished=false,timer;
    function fin(){
      if(finished)return;finished=true;
      clearTimeout(timer);off(handles);
      interReady=false;lastInterAt=Date.now();breaksSince=0;
      preloadInterstitial();
      done();
    }
    timer=setTimeout(fin,120000);
    Promise.all([
      on(A,'onInterstitialAdDismissed',fin),
      on(A,'onInterstitialAdFailedToShow',fin)
    ]).then(function(hs){
      handles=hs;
      if(finished){off(hs);return;}
      return A.showInterstitial();
    }).catch(fin);
  }
  function showInterstitialNative(b,done){
    var finished=false,timer;
    function fin(){
      if(finished)return;finished=true;
      clearTimeout(timer);window.onSnakeInterstitialClosed=null;
      lastInterAt=Date.now();breaksSince=0;
      done();
    }
    window.onSnakeInterstitialClosed=fin;   // يستدعيه جسر Android عند إغلاق الإعلان
    timer=setTimeout(fin,120000);
    try{
      var r=b.showInterstitial();
      if(r&&typeof r.then==='function')r.then(fin,fin);
      else if(r===false)fin();
    }catch(e){fin();}
  }

  // فاصل طبيعي في اللعب: يُظهر إعلانًا بينيًا إن حان وقته، ثم ينفّذ next()
  function adBreak(next){
    if(busy)return;
    busy=true;
    var called=false;
    function go(){
      if(called)return;called=true;busy=false;
      try{next();}catch(e){if(window.console)console.error(e);}
    }
    breaksSince++;
    var A=plugin(),b=bridge();
    var due=breaksSince>=CONFIG.interstitialEvery&&(Date.now()-lastInterAt>=CONFIG.minGapMs);
    if(due){
      if(A&&initDone&&interReady){showInterstitialCap(A,go);return;}
      if(!A&&b&&typeof b.showInterstitial==='function'){showInterstitialNative(b,go);return;}
    }
    if(A)preloadInterstitial();
    go();
  }

  // ===== إعلان المكافأة =====
  function rewardedCap(A){
    return new Promise(function(resolve){
      var handles=[],earned=false,finished=false,timer;
      function fin(v){
        if(finished)return;finished=true;
        clearTimeout(timer);off(handles);
        lastInterAt=Date.now();breaksSince=0;
        resolve(!!v);
      }
      timer=setTimeout(function(){fin(earned);},180000);
      Promise.all([
        on(A,'onRewardedVideoAdReward',function(){earned=true;}),
        on(A,'onRewardedVideoAdDismissed',function(){fin(earned);}),
        on(A,'onRewardedVideoAdFailedToLoad',function(){fin(false);}),
        on(A,'onRewardedVideoAdFailedToShow',function(){fin(false);})
      ]).then(function(hs){
        handles=hs;
        if(finished){off(hs);return;}
        return A.prepareRewardVideoAd({adId:CONFIG.ids.rewarded,isTesting:CONFIG.testMode})
          .then(function(){return A.showRewardVideoAd();})
          .then(function(r){if(r)earned=true;});
      }).catch(function(){fin(false);});
    });
  }

  // إن كانت إضافة Capacitor موجودة ولا يوجد جسر خاص، نعرّف الجسر الذي يتوقعه script.js
  if(!window.SnakeAds&&!window.AndroidAds&&plugin()){
    window.SnakeAds={
      showRewardedAd:function(){
        return init().then(function(ok){
          var A=plugin();
          return(ok&&A)?rewardedCap(A):false;
        });
      }
    };
  }

  window.GameAds={
    init:init,
    banner:function(show){wantBanner=!!show;applyBanner();},
    adBreak:adBreak
  };

  init();
})();
