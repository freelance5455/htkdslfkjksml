// Gera imagens (PNG) das etiquetas no tema escuro do app e compartilha.
const CL={bg:'#12151c',card:'#1b2029',tx:'#e8ebf1',mut:'#9aa4b5',bd:'#2c3340',verm:'#ff6b5e',azul:'#6ea0ff'};
function mk(c,draw){
  const h={y:0};
  h.F=(sz,b)=>c.font=(b?'700 ':'400 ')+sz+'px system-ui,Roboto,Arial,sans-serif';
  h.T=(t,x,col)=>{if(draw){c.fillStyle=col;c.fillText(t,x,h.y)}};
  h.lines=(t,sz,b,mw)=>{h.F(sz,b);const out=[];let l='';for(const w of String(t).split(/\s+/)){const n=l?l+' '+w:w;if(l&&c.measureText(n).width>mw){out.push(l);l=w}else l=n}if(l)out.push(l);return out};
  h.par=(t,sz,b,col,x,mw)=>h.lines(t,sz,b,mw).forEach(l=>{h.F(sz,b);h.T(l,x,col);h.y+=sz*1.35});
  h.badge=(t,x,col)=>{h.F(22,0);const w=c.measureText(t).width+24;if(draw){c.strokeStyle=col;c.lineWidth=2;c.beginPath();(c.roundRect||c.rect).call(c,x,h.y,w,34,17);c.stroke();c.fillStyle=col;c.fillText(t,x+12,h.y+5)}return x+w+10};
  h.cab=(o,x,big)=>{
    const sz=big?44:32,azul=o.cor==='AZUL';h.F(sz,1);h.T(o.nota,x,CL.tx);const nw=c.measureText(o.nota).width;
    h.y+=big?8:2;let bx=x+nw+20;bx=h.badge(azul?'Azul':'Vermelha',bx,CL.mut);if(o.prio)bx=h.badge(o.prio,bx,CL.mut);if(o.status)h.badge(o.status,bx,azul?CL.azul:CL.verm);
    h.y+=big?50:44;
  };
  h.resumo=(o,x,mw,big)=>{
    h.par(o.desc,big?30:26,1,CL.tx,x,mw);
    if(o.equip)h.par(o.equip,big?26:22,0,CL.mut,x,mw);
    h.par([AREA[o.area]||o.area,CENTRO[o.centro]||o.centro,fd(o.data),o.notif].filter(Boolean).join(' · '),big?24:22,0,CL.mut,x,mw);
  };
  return h;
}
// Uma etiqueta, com todos os detalhes
function pintar(o,draw,c){
  const W=800,P=36,X=P+14,MW=W-X-P,h=mk(c,draw);c.textBaseline='top';h.y=P;
  h.F(22,0);h.T('Etiqueta de anomalia',X,CL.mut);h.y+=32;
  h.cab(o,X,true);h.y+=0;h.resumo(o,X,MW,true);
  h.y+=10;if(draw){c.fillStyle=CL.bd;c.fillRect(X,h.y,MW,2)}h.y+=18;
  const SKIP='nota cor prio status desc equip area centro data notif';
  for(const k of Object.keys(LAB)){
    let v=o[k];if(!v||SKIP.includes(k))continue;if(k==='prazo')v=fd(v);
    h.F(20,0);h.T(LAB[k],X,CL.mut);const sy=h.y;h.par(v,24,0,CL.tx,X+250,MW-250);h.y=Math.max(h.y,sy+30)+6;
  }
  h.y+=6;h.F(20,0);h.T('Lista atualizada até '+fd(cur.atualizado),X,CL.mut);h.y+=30;
  const H=h.y+P;if(draw){c.fillStyle=o.cor==='AZUL'?CL.azul:CL.verm;c.fillRect(0,0,14,H)}
  return H;
}
// Lista de etiquetas (cartões resumidos) ; hs guarda a altura de cada cartão
function pintarLista(L,titulo,draw,c,hs){
  const W=800,M=24,X=M+10+22,MW=W-M-22-X,h=mk(c,draw);c.textBaseline='top';h.y=M;
  h.F(40,1);h.T('Etiquetas programadas',M,CL.tx);h.y+=52;
  h.F(22,0);h.T(titulo,M,CL.mut);h.y+=44;
  L.forEach((o,i)=>{
    const y0=h.y;
    if(draw){c.fillStyle=CL.card;c.beginPath();(c.roundRect||c.rect).call(c,M,y0,W-2*M,hs[i],12);c.fill();c.fillStyle=o.cor==='AZUL'?CL.azul:CL.verm;c.fillRect(M,y0,10,hs[i])}
    h.y=y0+18;h.cab(o,X,false);h.resumo(o,X,MW,false);h.y+=12;
    const alt=draw?hs[i]:h.y-y0;if(!draw)hs[i]=alt;h.y=y0+alt+14;
  });
  return h.y+M;
}
function tela(H,fn){
  H=Math.ceil(H);const cv=document.createElement('canvas');cv.width=1600;cv.height=H*2;
  const c=cv.getContext('2d');c.scale(2,2);c.fillStyle=CL.bg;c.fillRect(0,0,800,H);fn(c);return cv;
}
const medir=()=>document.createElement('canvas').getContext('2d');
function imagemEtiqueta(o){const H=pintar(o,false,medir());return tela(H,c=>{c.fillStyle=CL.card;c.fillRect(0,0,800,H);pintar(o,true,c)})}
function imagensLista(L){
  const N=15,partes=Math.ceil(L.length/N),out=[];
  for(let i=0;i<partes;i++){
    const g=L.slice(i*N,(i+1)*N),t=L.length+' pendente(s) · '+fd(new Date().toISOString().slice(0,10))+(partes>1?' · parte '+(i+1)+' de '+partes:''),hs=[];
    const H=pintarLista(g,t,false,medir(),hs);out.push(tela(H,c=>pintarLista(g,t,true,c,hs)));
  }
  return out;
}
async function enviar(cvs,nomes,titulo){
  try{
    msg('Gerando imagem…',20000);
    const Pl=nativo()&&Capacitor.Plugins;
    if(Pl&&Pl.Filesystem&&Pl.Share){
      const uris=[];
      for(let i=0;i<cvs.length;i++)uris.push((await Pl.Filesystem.writeFile({path:nomes[i],data:cvs[i].toDataURL('image/png').split(',')[1],directory:'CACHE'})).uri);
      await Pl.Share.share({title:titulo,files:uris});
    }else{
      const files=await Promise.all(cvs.map(async(cv,i)=>new File([await new Promise(r=>cv.toBlob(r,'image/png'))],nomes[i],{type:'image/png'})));
      if(navigator.canShare&&navigator.canShare({files}))await navigator.share({files,title:titulo});
      else{files.forEach(f=>{const a=document.createElement('a');a.href=URL.createObjectURL(f);a.download=f.name;a.click()});msg('Imagem salva. Envie pelo WhatsApp.');return}
    }
    $('#msg').hidden=true;
  }catch(er){const t=String(er&&er.message||er);if(/cancel|abort/i.test(t+(er&&er.name)))$('#msg').hidden=true;else msg('Erro ao gerar/enviar a imagem: '+t,12000)}
}
const zapImg=o=>enviar([imagemEtiqueta(o)],['etiqueta-'+o.nota+'.png'],'Etiqueta de anomalia '+o.nota);
function zapLista(L){
  const cvs=imagensLista(L);
  return enviar(cvs,cvs.map((_,i)=>'programadas-'+(i+1)+'.png'),'Etiquetas programadas');
}
