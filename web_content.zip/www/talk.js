/* Dhonnobad AI — offline-first intent matching, Bengali/Banglish normalization, safe foundation KB, no API keys */
(()=>{
'use strict';
const $=id=>document.getElementById(id), chat=$('chat'), form=$('form'), input=$('input'), panel=$('panel'), modal=$('modal');
const WA='01733476806', HISTORY_KEY='df_ai_conversation_v5';
const NAV=[['সদস্যপদ / সদস্য ফর্ম','index.html#membership'],['অনুদান / ডোনেশন','donate.html'],['যোগাযোগ','index.html#contact'],['প্রতিষ্ঠাতা','index.html#about'],['কার্যক্রম','index.html#activities'],['হোম পেজ','index.html#home'],['কুইজ','quiz.html'],['দৈনন্দিন আমল','activity.html']];
// Privacy-conscious analytics: send only a broad topic and timestamp, never the raw prompt.
function logAIUsage(q){try{const raw=String(q||'').toLowerCase();let topic='general';if(/সদস্য|মেম্বার|member|membership|যোগদান/.test(raw))topic='membership';else if(/অনুদান|দান|donat|টাকা জমা|পেমেন্ট/.test(raw))topic='donation';else if(/নোটিশ|notice|ঘোষণা/.test(raw))topic='notices';else if(/যোগাযোগ|ফোন|হোয়াটসঅ্যাপ|whatsapp|contact/.test(raw))topic='contact';else if(/প্রতিষ্ঠাতা|কার্যক্রম|ফাউন্ডেশন|foundation/.test(raw))topic='foundation';else if(/নামাজ|ইসলাম|দোয়া|কুরআন|islam|quran/.test(raw))topic='islamic';const at=Date.now();try{const k='df_ai_usage_v2';const rows=JSON.parse(localStorage.getItem(k)||'[]');rows.push({topic,at});localStorage.setItem(k,JSON.stringify(rows.slice(-250)));}catch(_){}import('./firebase.js').then(async({database})=>{try{const {ref,push}=await import('https://www.gstatic.com/firebasejs/12.1.0/firebase-database.js');await push(ref(database,'aiAnalytics'),{topic,at});}catch(e){console.info('AI analytics write skipped; check Firebase Rules.');}}).catch(()=>{});}catch(_){}}

const FAQ=[
{q:'ধন্যবাদ ফাউন্ডেশন কী',a:'ধন্যবাদ ফাউন্ডেশন একটি স্বেচ্ছাসেবামূলক উদ্যোগ। এর মূল লক্ষ্য ছোট শিশুদের ইসলাম শিক্ষা দেওয়া এবং নামাজ পড়তে উদ্বুদ্ধ করা।',k:['ফাউন্ডেশন সম্পর্কে','প্রতিষ্ঠান কী','ধন্যবাদ ফাউন্ডেশন পরিচিতি','what is dhonnobad foundation']},
{q:'প্রতিষ্ঠাতা কে',a:'ধন্যবাদ ফাউন্ডেশনের প্রতিষ্ঠাতা আব্দুল্লাহ আল শাফি। তাঁর সঙ্গে শুরুতে ছিলেন সিয়াম ও আহেদুল মীর্জা।',k:['কে প্রতিষ্ঠা করেছে','প্রতিষ্ঠাতা নাম','founder','কে শুরু করেছে']},
{q:'ফাউন্ডেশন কোথায় অবস্থিত',a:'ধন্যবাদ ফাউন্ডেশনের অবস্থান গুল্লাকরোটিয়া, টাঙ্গাইল।',k:['ঠিকানা','কোথায়','লোকেশন','address','location']},
{q:'ফাউন্ডেশন কবে শুরু হয়',a:'ধন্যবাদ ফাউন্ডেশনের উদ্যোগ ২০২৪ সালে শুরু হয়। ২০২৬ সালে গুল্লা, করোটিয়া, টাঙ্গাইলে আনুষ্ঠানিক উদ্বোধন করা হয়।',k:['প্রতিষ্ঠার তারিখ','কবে শুরু','প্রতিষ্ঠাকাল','কোন সালে','শুরু কবে','উদ্বোধন কবে','কত সালে প্রতিষ্ঠিত','foundation started','founded']},
{q:'ফাউন্ডেশনের প্রতিষ্ঠাতা কে এবং তাঁর পরিচয় কী',a:'ধন্যবাদ ফাউন্ডেশনের প্রতিষ্ঠাতা আবদুল্লাহ আল শাফি। তিনি বর্তমানে অষ্টম শ্রেণিতে পড়াশোনা করেন। ইসলামের আলো ছড়িয়ে দেওয়ার উদ্দেশ্যে তিনি ফাউন্ডেশনটি গড়ে তুলেছেন। যেকোনো বিষয় স্পষ্টভাবে বুঝিয়ে বলতে পারা তাঁর বিশেষ গুণ।',k:['আবদুল্লাহ আল শাফি','আব্দুল্লাহ আল শাফি','শাফি সম্পর্কে','প্রতিষ্ঠাতার পরিচয়','founder profile']},
{q:'ফাউন্ডেশনের ঠিকানা কোথায়',a:'ধন্যবাদ ফাউন্ডেশনের কার্যক্রমের ঠিকানা: গুল্লা, করোটিয়া, টাঙ্গাইল, বাংলাদেশ।',k:['ঠিকানা','অবস্থান','লোকেশন','গুল্লা','করোটিয়া','টাঙ্গাইল কোথায়','address','location']},
{q:'যোগাযোগের ফোন ও ইমেইল কী',a:`অফিসিয়াল ফোন/WhatsApp: ${WA}। ইমেইল: dhonnobad61@gmail.com।`,k:['ফোন','মোবাইল','হোয়াটসঅ্যাপ','ইমেইল','email','contact details','যোগাযোগের তথ্য']},
{q:'সদস্য হতে মাসিক অনুদান না দিলে কী হয়',a:'সদস্যদের মাসিক ন্যূনতম অনুদান ৫০ টাকা। পরপর দুই মাস অনুদান না দিলে সদস্যপদ বাতিল হয়। পরে আবার যোগ দিতে নতুন ফর্ম পূরণ করে ৫০ টাকা অনুদান দিতে হবে; আগের বকেয়া দিতে হয় না।',k:['মাসিক চাঁদা','৫০ টাকা','দুই মাস','সদস্যপদ বাতিল','বকেয়া','membership rules']},
{q:'মূল লক্ষ্য কী',a:'ধন্যবাদ ফাউন্ডেশনের মূল লক্ষ্য ছোট শিশুদের ইসলাম শিক্ষা দেওয়া এবং তাদের নামাজ পড়তে উদ্বুদ্ধ করা।',k:['উদ্দেশ্য','লক্ষ্য','কাজের উদ্দেশ্য','mission']},
{q:'ভবিষ্যৎ পরিকল্পনা কী',a:'ভবিষ্যতে আরও বড় পরিসরে কাজ করা ধন্যবাদ ফাউন্ডেশনের লক্ষ্য।',k:['ভবিষ্যৎ লক্ষ্য','পরিকল্পনা','future plan']},
{q:'সদস্যদের গুণাবলি কী',a:'সদস্যদের মধ্যে সততা, ধৈর্য ও সর্বোচ্চ চেষ্টা করার মানসিকতাকে গুরুত্ব দেওয়া হয়।',k:['মূল্যবোধ','সদস্যদের গুণ','সততা ধৈর্য']},
{q:'সদস্য হতে কী কী লাগে',a:'সদস্য ফর্মে নাম, ফোন নম্বর, WhatsApp নম্বর ও ঠিকানা দিতে হয়। ইমেইল ঠিকানা এবং সদস্য হওয়ার কারণ ঐচ্ছিক।',k:['ফর্মে কী লাগে','কী তথ্য লাগবে','কাগজপত্র','নিবন্ধন তথ্য','কি কি দিতে হবে']},
{q:'সদস্য কীভাবে হব',a:'সদস্য হতে ওয়েবসাইটের সদস্য ফর্ম পূরণ করুন। চাইলে নিচের “সদস্য ফর্ম” পেজটি খুলে নিতে পারেন। আবেদনটি অ্যাডমিনরা পর্যালোচনা করেন এবং সাধারণত ৪৮ ঘণ্টার মধ্যে সিদ্ধান্তের প্রক্রিয়া সম্পন্ন হয়। চূড়ান্ত অনুমোদন দেন প্রতিষ্ঠাতা; WhatsApp-এ জানানো হবে।',k:['সদস্য হব','সদস্য হতে চাই','যোগদান','join','apply','মেম্বার হব','সদস্যপদ পেতে']},
{q:'সদস্যপদ অনুমোদনে কত সময় লাগে',a:'আবেদন পর্যালোচনা ও অনুমোদনে সাধারণত ৪৮ ঘণ্টা সময় লাগে। অ্যাডমিনরা আবেদন পর্যালোচনা করেন এবং চূড়ান্ত অনুমোদন দেন প্রতিষ্ঠাতা।',k:['কতদিন','কতক্ষণ','৪৮ ঘণ্টা','48 hours','approval','আবেদন স্ট্যাটাস']},
{q:'সদস্যপদ কে অনুমোদন করেন',a:'অ্যাডমিনরা আবেদন পর্যালোচনা করেন। সদস্যপদের চূড়ান্ত অনুমোদন দেন ফাউন্ডেশনের প্রতিষ্ঠাতা।',k:['কে অনুমোদন','approve','অনুমোদনকারী']},
{q:'সদস্য হতে বয়সসীমা আছে কি',a:'না, সদস্য হওয়ার জন্য নির্দিষ্ট কোনো বয়সসীমা নেই।',k:['বয়স','বয়স','age limit','কত বছর']},
{q:'মাসিক অনুদান কত',a:'সদস্যদের প্রতি মাসে কমপক্ষে ৫০ টাকা অনুদান দিতে হবে। সদস্য হতে প্রথমে ওয়েবসাইটের ফর্ম পূরণ করতে হয়; এরপর অ্যাডমিন অনুমোদন দিলে সদস্যপদ নিশ্চিত হয়।',k:['মাসে টাকা','চাঁদা','সদস্য ফি','monthly donation','৫০ টাকা','সর্বনিম্ন','মাসে কত']},
{q:'অনুদান কীভাবে দেব',a:'ওয়েবসাইটের ডোনেশন পেজে গিয়ে বিকাশ বা নগদের মাধ্যমে অনুদান দিতে পারেন। পেমেন্টের নির্দেশনা সেখানে দেখুন।',k:['দান করব','টাকা পাঠাব','বিকাশ','নগদ','donate','payment','অনুদান পদ্ধতি']},
{q:'দুই মাস অনুদান না দিলে কী হবে',a:'পরপর দুই মাস মাসিক অনুদান না দিলে সদস্যপদ বাতিল হবে। পরে নতুন করে সদস্য হতে নতুন ফর্ম পূরণ করে ৫০ টাকা অনুদান দিতে হবে। আগের বকেয়া দিতে হবে না।',k:['দুই মাস','অনুদান না দিলে','সদস্যপদ বাতিল','বকেয়া অনুদান','বকেয়া']},
{q:'দরিদ্র মানুষকে কোথায় আর্থিক সহায়তা দেওয়া হয়',a:'ধন্যবাদ ফাউন্ডেশন টাঙ্গাইল জেলার দরিদ্র ও অসহায় মানুষকে আর্থিক সহায়তা দেয়। প্রতি রমজানে ফাউন্ডেশন নিজ উদ্যোগে দরিদ্র মানুষ চিহ্নিত করে সহায়তা প্রদান করে।',k:['কোন জেলায়','টাঙ্গাইল','গরিবদের সাহায্য','আর্থিক সাহায্য','রমজানে সহায়তা']},
{q:'রমজানে ফাউন্ডেশন কী করে',a:'রমজানে দরিদ্র ও অসহায় মানুষের মধ্যে ইফতার বিতরণ করা হয়। এ সময় ফাউন্ডেশন নিজ উদ্যোগে দরিদ্র মানুষ চিহ্নিত করে আর্থিক সহায়তাও দেয়।',k:['ইফতার','রমজান','ইফতার বিতরণ','সাহায্য']},
{q:'অনুদান জমা দিয়ে স্ক্রিনশট দিতে হবে কি',a:'না, স্ক্রিনশট দেওয়া বাধ্যতামূলক নয়। ডোনেশন ফর্মে ট্রানজ্যাকশন আইডি দেওয়ার অপশন রয়েছে।',k:['ট্রানজেকশন আইডি','transaction id','প্রমাণ','স্ক্রিনশট','screenshot']},
{q:'শিশুদের আমল কার্যক্রম কীভাবে চলে',a:'শিশুদের বিভিন্ন আমলের ঘরসহ কাগজে ছাপানো একটি আমল শিট দেওয়া হয়। শিশুরা নিজেরা আমল অনুযায়ী ঘরগুলো পূরণ করে। তাদের ইবাদতে উৎসাহ দিতে উপহারও দেওয়া হয়। এটি আনুষ্ঠানিক কুরআন বা নামাজের ক্লাস হিসেবে বর্ণনা করা ঠিক হবে না।',k:['নামাজের চার্ট','টিক দিতে','নামাজ ট্র্যাকার','আমল শিট','কাগজে ছাপানো','পুরস্কার','নামাজের কর্মসূচি']},
{q:'কীভাবে সহযোগিতা করব',a:'অনুদান দিয়ে ধন্যবাদ ফাউন্ডেশনের কাজে সহযোগিতা করতে পারেন। অনুদানের জন্য ওয়েবসাইটের ডোনেশন পেজ ব্যবহার করুন।',k:['সহযোগিতা','সাহায্য','support','কীভাবে সাহায্য']},
{q:'সদস্যপদ বাতিল করব কীভাবে',a:`সদস্যপদ বাতিল করতে অফিসিয়াল WhatsApp নম্বর ${WA}-এ মেসেজ করে জানাতে হবে।`,k:['সদস্য বাতিল','সদস্যপদ ছাড়তে','cancel membership','বাতিল করব']},
{q:'বাতিলের পর আবার সদস্য হওয়া যাবে কি',a:'হ্যাঁ। পরপর দুই মাস অনুদান না দিলে সদস্যপদ বাতিল হয়। পরে আবার সদস্য হতে নতুন করে ফর্ম পূরণ করে ৫০ টাকা অনুদান দিতে হবে। আগের বকেয়া অনুদান দিতে হবে না; নতুন আবেদন অ্যাডমিন অনুমোদন করলে সদস্যপদ নিশ্চিত হবে।',k:['আবার সদস্য','পুনরায়','পুনরায়','rejoin','দুই মাস টাকা না দিলে','বকেয়া','বকেয়া','সদস্যপদ বাতিল']},
{q:'সমস্যা হলে কোথায় যোগাযোগ করব',a:`কোনো সমস্যা বা প্রশ্ন থাকলে ধন্যবাদ ফাউন্ডেশনের অফিসিয়াল WhatsApp নম্বর ${WA}-এ মেসেজ করুন।`,k:['অভিযোগ','সমস্যা','অ্যাডমিনকে','help','যোগাযোগ']},
{q:'যোগাযোগের নম্বর কী',a:`অফিসিয়াল WhatsApp নম্বর: ${WA}।`,k:['ফোন নম্বর','হোয়াটসঅ্যাপ','whatsapp number','contact number','মোবাইল নম্বর']},
{q:'ইমেইল কী',a:'ইমেইল: dhonnobad61@gmail.com',k:['email','ইমেইল ঠিকানা']},
{q:'ফেসবুক কোথায়',a:'ফাউন্ডেশনের ফেসবুক পেজ ও ওয়েবসাইটের মাধ্যমে তথ্য পাওয়া যাবে।',k:['facebook','ফেসবুক পেজ']},
{q:'সদস্যদের কোনো পদ আছে কি',a:'না, বর্তমানে সদস্যদের জন্য আলাদা কোনো পদ নেই; সাধারণ সদস্য হওয়ার ব্যবস্থা রয়েছে।',k:['পদ','পদবি','position','role']},
{q:'সদস্যপদ স্থায়ী কি',a:'সদস্যপদ স্থায়ী বলে জানানো হয়েছে। সদস্যপদ বাতিল করতে চাইলে অফিসিয়াল WhatsApp নম্বরে যোগাযোগ করতে হবে।',k:['স্থায়ী','স্থায়ী','permanent','কতদিন সদস্য']},
{q:'ফাউন্ডেশনের কার্যক্রম কী কী',a:'ধন্যবাদ ফাউন্ডেশনের কার্যক্রমের মধ্যে রয়েছে শিশুদের বিভিন্ন ইবাদতে উৎসাহ দেওয়া, কাগজে ছাপানো আমল শিটের মাধ্যমে আমল পূরণে উৎসাহিত করা এবং তাদের উপহার দেওয়া; রমজানে দরিদ্র ও অসহায় মানুষের মধ্যে ইফতার বিতরণ; এবং দরিদ্র ও অসহায় মানুষকে আর্থিক সহায়তা করা। দরিদ্র মানুষের আর্থিক সহায়তা টাঙ্গাইল জেলার মধ্যে পরিচালিত হয়।',k:['কী কী কাজ','কাজগুলো','কার্যক্রম','activities','কী করে','ইফতার','আর্থিক সহায়তা','গরিবদের সাহায্য']}
];
const ISLAM=[
['ইসলামের পাঁচটি স্তম্ভ কী','ইসলামের পাঁচটি স্তম্ভ হলো ঈমানের সাক্ষ্য (শাহাদাত), সালাত, যাকাত, সাওম (রোজা) ও হজ।',['পাঁচ স্তম্ভ','5 pillars']],
['এক দিনে ফরজ নামাজ কয় ওয়াক্ত','এক দিনে পাঁচ ওয়াক্ত ফরজ নামাজ রয়েছে: ফজর, যোহর, আসর, মাগরিব ও এশা।',['কয় ওয়াক্ত','নামাজ কতবার']],
['ফজরের ফরজ কয় রাকাত','ফজরের ফরজ নামাজ দুই রাকাত।',['ফজর রাকাত']],['যোহরের ফরজ কয় রাকাত','যোহরের ফরজ নামাজ চার রাকাত।',['যোহর রাকাত']],['আসরের ফরজ কয় রাকাত','আসরের ফরজ নামাজ চার রাকাত।',['আসর রাকাত']],['মাগরিবের ফরজ কয় রাকাত','মাগরিবের ফরজ নামাজ তিন রাকাত।',['মাগরিব রাকাত']],['এশার ফরজ কয় রাকাত','এশার ফরজ নামাজ চার রাকাত।',['এশা রাকাত']],['কুরআনে কয়টি সূরা','কুরআনে ১১৪টি সূরা রয়েছে।',['সূরা সংখ্যা']],['কুরআনে কয়টি পারা','কুরআন সাধারণভাবে ৩০ পারায় বিভক্ত।',['পারা সংখ্যা']],['কুরআন কী','কুরআন মুসলমানদের পবিত্র কিতাব এবং ইসলামী বিশ্বাস ও জীবনব্যবস্থার প্রধান উৎস।',[]],['হাদিস কী','রাসুলুল্লাহ ﷺ-এর কথা, কাজ, অনুমোদন ও বর্ণিত বৈশিষ্ট্য সম্পর্কিত বর্ণনাকে হাদিস বলা হয়।',[]],['ওজু কী','নামাজসহ কিছু ইবাদতের প্রস্তুতির জন্য শরিয়তসম্মতভাবে নির্দিষ্ট অঙ্গ ধোয়া বা মাসাহ করাকে ওজু বলা হয়।',[]],['যাকাত কী','নির্দিষ্ট শর্ত পূরণকারী সম্পদের ওপর শরিয়ত নির্ধারিত হারে যোগ্য ব্যক্তিদের দেওয়া ফরজ দানকে যাকাত বলা হয়।',[]],['রোজা কী','আল্লাহর ইবাদতের উদ্দেশ্যে সুবহে সাদিক থেকে সূর্যাস্ত পর্যন্ত নির্দিষ্ট বিষয় থেকে বিরত থাকাকে রোজা বলা হয়।',[]],['সদকা কী','আল্লাহর সন্তুষ্টির উদ্দেশ্যে স্বেচ্ছায় দান বা কল্যাণমূলক কাজকে সদকা বলা হয়।',[]]
].map(([q,a,k])=>({q,a,k}));
const STOP=new Set('আমি তুমি আপনি কি কী কে কোথায় কোথায় কবে কেন কিভাবে কীভাবে কেমন কত কোন কোনো একটি সম্পর্কে বলো বলুন জানাও জানতে চাই জানতে পারি হবে আছে হয় হয়না হবে না এর ও আর তো কি না the a an is are do does how what who when where tell me about please'.split(' '));
function norm(s){return String(s||'').toLowerCase().normalize('NFKC').replace(/[ঁংঃ]/g,'').replace(/[০-৯]/g,d=>'০১২৩৪৫৬৭৮৯'.indexOf(d)).replace(/[?!.،,;:ঃ।\-_/\\()[\]{}'"“”‘’`~!@#$%^&*+=<>|]/g,' ').replace(/\s+/g,' ').trim().replace(/হয়/g,'হয়').replace(/কী/g,'কি').replace(/করতে পারি/g,'করব').replace(/করবেন/g,'করব').replace(/কিভাবে/g,'কিভাবে');}
function words(s){return norm(s).split(' ').filter(x=>x.length>1&&!STOP.has(x));}
function sim(q,item){const n=norm(q), candidates=[item.q,...(item.k||[])].map(norm);let best=0;for(const c of candidates){if(!c)continue;if(n===c)return 1;if(n.includes(c)||c.includes(n)){best=Math.max(best,Math.min(.96,Math.min(n.length,c.length)/Math.max(n.length,c.length)+.25));}const a=new Set(words(n)),b=new Set(words(c));let inter=0;for(const x of a)if(b.has(x))inter++;const jac=inter/(new Set([...a,...b]).size||1);const containment=inter/(Math.min(a.size,b.size)||1);best=Math.max(best,jac*.72+containment*.28);}
// Synonym concept hooks add robust phrase-level matching.
const groups=[[/সদস্য|মেম্বার|member|membership|যোগদান|join|ভর্তি|যোগ দিতে/,['সদস্য','member','membership']],[/অনুদান|দান|চাঁদা|ডোনেশন|donat|টাকা|পেমেন্ট|বিকাশ|নগদ/,['অনুদান','donation','দান']],[/প্রতিষ্ঠাতা|founder|শুরু করেছে|গড়ে তুলেছে|প্রতিষ্ঠিত/,['প্রতিষ্ঠাতা','founder']],[/নামাজ|সালাত|prayer|salah|ইবাদত|আমল/,['নামাজ','সালাত']],[/যোগাযোগ|ফোন|নম্বর|হোয়াটসঅ্যাপ|whatsapp|contact|ইমেইল/,['যোগাযোগ','contact']],[/বাতিল|cancel|ছাড়তে|ত্যাগ|বকেয়া|বকেয়া/,['বাতিল','cancel']],[/কোথায়|কোথায়|ঠিকানা|অবস্থান|লোকেশন|address|location/,['কোথায়','ঠিকানা','অবস্থান']]];
for(const [re,terms] of groups){if(re.test(n)&&candidates.some(c=>terms.some(t=>c.includes(t))))best+=.10;}
return Math.min(1,best);}
function matchKB(q,arr){return arr.map(item=>({item,score:sim(q,item)})).sort((a,b)=>b.score-a.score)[0]||null;}
function inScope(q){return /(ধন্যবাদ|ফাউন্ডেশন|সদস্য|মেম্বার|অনুদান|ডোনেশন|দান|প্রতিষ্ঠাতা|মডারেটর|অ্যাডমিন|কার্যক্রম|যোগাযোগ|ওয়েবসাইট|ওয়েবসাইট|নামাজ|সালাত|রোজা|রমজান|কুরআন|কোরআন|হাদিস|দোয়া|দোয়া|যাকাত|সদকা|আল্লাহ|নবী|রাসুল|হালাল|হারাম|ইসলাম|whatsapp|membership|donation|foundation|founder|quran|salah|islam|dua|zakat|ramadan)/i.test(q);}
function navTarget(q){const n=norm(q);const wants=/(খুল|দেখাও|নিয়ে যাও|নিয়ে যাও|পেজ|ফর্ম|কোথায়|কোথায়|যেতে চাই|open|go to|page|form|link)/i.test(n);if(!wants)return null;let idx=-1;if(/সদস্য|মেম্বার|membership|member|যোগদান|নিবন্ধন|registration|ফর্ম/.test(n))idx=0;else if(/অনুদান|ডোনেশন|দান|donat|payment|বিকাশ|নগদ/.test(n))idx=1;else if(/যোগাযোগ|contact|ফোন|whatsapp/.test(n))idx=2;else if(/প্রতিষ্ঠাতা|founder/.test(n))idx=3;else if(/কার্যক্রম|activities/.test(n))idx=4;else if(/হোম|মূল পেজ|home/.test(n))idx=5;else if(/কুইজ|quiz/.test(n))idx=6;else if(/দৈনন্দিন আমল|আজকের আমল|আমল সেকশন|daily amal|activity/.test(n))idx=7;return idx>=0?NAV[idx]:null;}
let history=[];try{history=JSON.parse(localStorage.getItem(HISTORY_KEY)||'[]')}catch(_){history=[]}// Voice controls intentionally removed; the assistant is text-only.
// Conversational membership application; user confirms before submitting to the existing volunteers collection.
let applicationFlow=null;
const applicationFields=[['name','আপনার পূর্ণ নাম লিখুন।'],['phone','আপনার মোবাইল নম্বর লিখুন।'],['whatsapp','আপনার WhatsApp নম্বর লিখুন।'],['address','আপনার সম্পূর্ণ ঠিকানা লিখুন।'],['reason','আপনি কেন সদস্য হতে চান? (না চাইলে “বাদ” লিখুন।)']];
function startApplication(){applicationFlow={step:0,data:{}};addRow('চলুন, AI-এর মাধ্যমে সদস্য আবেদন করি। আবেদন জমা দেওয়ার আগে আপনার অনুমতি নেওয়া হবে। বন্ধ করতে “বাতিল” লিখুন।\n\n'+applicationFields[0][1],'ai');}
function isCancel(q){return /^(বাতিল|cancel|stop|বন্ধ)$/i.test(String(q||'').trim());}
async function submitMemberApplication(data){
  const {database}=await import('./firebase.js');
  const {ref,push}=await import('https://www.gstatic.com/firebasejs/12.1.0/firebase-database.js');
  const record={name:data.name,phone:data.phone,whatsapp:data.whatsapp,address:data.address,reason:data.reason||'',status:'Pending',createdAt:Date.now(),submittedAt:new Date().toISOString(),source:'AI Chatbot',archived:false};
  const result=await push(ref(database,'volunteers'),record);return result.key;
}
async function handleApplicationInput(q){
  if(!applicationFlow)return false;
  if(isCancel(q)){applicationFlow=null;addRow('আবেদন প্রক্রিয়া বাতিল করা হয়েছে। চাইলে পরে আবার শুরু করতে পারো।','ai');return true;}
  if(applicationFlow.step==='confirm'){
    if(/^(হ্যাঁ|জি|জী|ঠিক|জমা|submit|yes|confirm)$/i.test(q.trim())){const data=applicationFlow.data;applicationFlow={step:'sending',data};addRow('আবেদন জমা হচ্ছে…','ai');try{const key=await submitMemberApplication(data);applicationFlow=null;addRow('✅ তোমার সদস্য আবেদন সফলভাবে জমা হয়েছে। আবেদন নম্বর: '+key+'। অ্যাডমিন আবেদন পর্যালোচনা করবেন।','ai');}catch(e){applicationFlow={step:'confirm',data};addRow('❌ আবেদন জমা করা যায়নি। Firebase সংযোগ/Rules পরীক্ষা করে আবার “হ্যাঁ” লিখে চেষ্টা করো, অথবা সদস্য ফর্ম ব্যবহার করো।','ai');}return true;}
    if(/^(না|no|edit|পরিবর্তন)$/i.test(q.trim())){applicationFlow={step:0,data:{}};addRow('ঠিক আছে, আবার তথ্য নেওয়া শুরু করছি।\n'+applicationFields[0][1],'ai');return true;}
    addRow('আবেদন জমা দিতে “হ্যাঁ” অথবা নতুন করে শুরু করতে “না” লিখুন।','ai');return true;
  }
  const field=applicationFields[applicationFlow.step];if(!field)return false;let value=q.trim();if(field[0]==='reason'&&/^(বাদ|skip|না)$/i.test(value))value='';if(!value&&field[0]!=='reason'){addRow('এই তথ্যটি প্রয়োজন। অনুগ্রহ করে আবার লিখুন।\n'+field[1],'ai');return true;}
  if(field[0]==='phone'||field[0]==='whatsapp'){const digits=value.replace(/[^0-9+]/g,'');if(digits.replace(/\D/g,'').length<10){addRow('নম্বরটি সঠিক মনে হচ্ছে না। দেশের কোডসহ বা ১১ সংখ্যার নম্বর লিখুন।','ai');return true;}value=digits;}
  applicationFlow.data[field[0]]=value;applicationFlow.step++;
  if(applicationFlow.step<applicationFields.length){addRow(applicationFields[applicationFlow.step][1],'ai');return true;}
  const d=applicationFlow.data;applicationFlow.step='confirm';addRow('আপনার আবেদনের তথ্য যাচাই করুন:\nনাম: '+d.name+'\nমোবাইল: '+d.phone+'\nWhatsApp: '+d.whatsapp+'\nঠিকানা: '+d.address+'\nসদস্য হওয়ার কারণ: '+(d.reason||'উল্লেখ করা হয়নি')+'\n\nএই তথ্য দিয়ে আবেদন জমা দেব? “হ্যাঁ” বা “না” লিখুন।','ai');return true;
}
async function askGenerativeAI(q){
  // Send only a short, bounded window of prior chat for conversational continuity.
  // The current user message is the final history item, so exclude it here.
  const recentHistory=history.filter(x=>x&&['user','ai'].includes(x.role)&&typeof x.text==='string').slice(-7,-1).map(x=>({role:x.role==='user'?'user':'assistant',text:x.text.slice(0,700)}));
  try{const {getFunctions,httpsCallable}=await import('https://www.gstatic.com/firebasejs/12.1.0/firebase-functions.js');const {app}=await import('./firebase.js');const fn=httpsCallable(getFunctions(app,'us-central1'),'askFoundationAI');const res=await fn({message:String(q).slice(0,1800),history:recentHistory,language:(localStorage.getItem('df_language')||'bn')});const text=res?.data?.text;if(typeof text==='string'&&text.trim())return text.trim();}catch(e){console.info('Generative AI endpoint unavailable; using curated KB fallback.');}return null;
}

const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function save(){try{localStorage.setItem(HISTORY_KEY,JSON.stringify(history.slice(-100)))}catch(_){}}
function appendSafeMessage(bubble,text){
  // Render markdown-style links and bare HTTPS URLs without inserting arbitrary HTML.
  const re=/\[([^\]]+)\]\((https?:\/\/[^\s)]+|(?:index|donate|quiz|activity)\.html(?:#[^\s)]*)?)\)|(https?:\/\/[^\s<>]+)/g;
  let last=0,m; const src=String(text||'');
  while((m=re.exec(src))){ if(m.index>last)bubble.appendChild(document.createTextNode(src.slice(last,m.index)));
    const label=m[1]||m[3], href=m[2]||m[3];
    if(/^(https?:\/\/|index\.html|donate\.html|quiz\.html|activity\.html)/i.test(href)){
      const a=document.createElement('a');a.href=href;a.textContent=label;a.className='ai-inline-link';
      if(/^https?:/i.test(href)){a.target='_blank';a.rel='noopener noreferrer';}
      bubble.appendChild(a);
    } else bubble.appendChild(document.createTextNode(m[0]));
    last=re.lastIndex;
  }
  if(last<src.length)bubble.appendChild(document.createTextNode(src.slice(last)));
}
function addRow(text,role='ai',saveIt=true){const row=document.createElement('div');row.className='row '+(role==='user'?'user':'ai');if(role!=='user'){const avatar=document.createElement('img');avatar.src='dhonnobad-ai-round-button.png';avatar.alt='ধন্যবাদ AI';avatar.className='ai-message-avatar';row.appendChild(avatar)}const box=document.createElement('div');box.className='messageContent';const bubble=document.createElement('div');bubble.className='bubble';appendSafeMessage(bubble,text);box.appendChild(bubble);if(role==='ai'){const actions=document.createElement('div');actions.className='bubbleActions';const cp=document.createElement('button');cp.textContent='▣ কপি';cp.onclick=()=>navigator.clipboard?.writeText(text);actions.appendChild(cp);box.appendChild(actions)}row.appendChild(box);chat.appendChild(row);chat.scrollTop=chat.scrollHeight;if(saveIt){history.push({role,text,time:Date.now()});save()}return row;}
function showTyping(){const r=document.createElement('div');r.id='typing';r.className='row ai';r.innerHTML='<img src="dhonnobad-ai-round-button.png" alt="ধন্যবাদ AI" class="ai-message-avatar loading-avatar"><div class="messageContent"><div class="bubble typingDots">উত্তর খুঁজছি <i></i><i></i><i></i></div></div>';chat.appendChild(r);chat.scrollTop=chat.scrollHeight;return r;}

function addFounderProfileCard(){
  const row=document.createElement('div');row.className='row ai founder-ai-row';
  const avatar=document.createElement('img');avatar.src='dhonnobad-ai-round-button.png';avatar.alt='ধন্যবাদ AI';avatar.className='ai-message-avatar';row.appendChild(avatar);
  const box=document.createElement('div');box.className='messageContent';
  const card=document.createElement('article');card.className='founder-ai-card';
  card.innerHTML='<div class="founder-ai-top"><span class="founder-ai-mark">✦</span><div><small>DHONNOBAD FOUNDATION</small><b>প্রতিষ্ঠাতার পরিচিতি</b></div><span class="founder-ai-badge">প্রতিষ্ঠাতা</span></div><div class="founder-ai-name">আবদুল্লাহ আল শাফি</div><div class="founder-ai-facts"><div><span>শিক্ষাগত পরিচয়</span><b>বর্তমানে অষ্টম শ্রেণির শিক্ষার্থী</b></div><div><span>প্রতিষ্ঠার উদ্দেশ্য</span><b>ইসলামের আলো ছড়িয়ে দেওয়া</b></div><div><span>বিশেষ গুণ</span><b>যেকোনো বিষয় খুব ভালোভাবে ও স্পষ্টভাবে বুঝিয়ে বলতে পারেন</b></div></div><div class="founder-ai-foot">ধন্যবাদ ফাউন্ডেশন · মানবতার সেবায় অঙ্গীকার</div>';
  box.appendChild(card);row.appendChild(box);chat.appendChild(row);chat.scrollTop=chat.scrollHeight;history.push({role:'ai',text:'ধন্যবাদ ফাউন্ডেশনের প্রতিষ্ঠাতা আবদুল্লাহ আল শাফি। বর্তমানে অষ্টম শ্রেণির শিক্ষার্থী। প্রতিষ্ঠার উদ্দেশ্য: ইসলামের আলো ছড়িয়ে দেওয়া। বিশেষ গুণ: যেকোনো বিষয় স্পষ্টভাবে বুঝিয়ে বলতে পারেন।',time:Date.now()});save();
}

function greeting(q){const n=norm(q);if(/^(হ্যালো|হাই|hello|hi|hey)$/.test(n))return 'হ্যালো! 😊 আমি ধন্যবাদ AI। ফাউন্ডেশন সম্পর্কে কী জানতে চাও?';if(/আসসালামু আলাইকুম|^(সালাম)$/.test(n))return 'ওয়ালাইকুমুস সালাম! 🌿 কীভাবে সাহায্য করতে পারি?';if(/কেমন আছ/.test(n)||/how are you/.test(n))return 'আলহামদুলিল্লাহ, ভালো আছি। 😊 তোমাকে কীভাবে সাহায্য করতে পারি?';if(/^(ধন্যবাদ|thanks|thank you)$/.test(n))return 'তোমাকেও ধন্যবাদ! 🌸';return null;}
function answer(q){const n=norm(q);if(/প্রতিষ্ঠাতা|founder|শাফি/.test(n)&&/(বিস্তারিত|পরিচিতি|কে|সম্পর্কে|জীবনী|বর্ণনা|দায়িত্ব|দায়িত্ব|উদ্দেশ্য|পড়াশোনা|পড়াশোনা|গুণ|কেমন)/.test(n))return 'ধন্যবাদ ফাউন্ডেশনের প্রতিষ্ঠাতা আবদুল্লাহ আল শাফি। তিনি বর্তমানে অষ্টম শ্রেণিতে পড়াশোনা করেন। ইসলামের আলো ছড়িয়ে দেওয়ার উদ্দেশ্যে তিনি এই ফাউন্ডেশন গড়ে তুলেছেন। তাঁর বিশেষ গুণ হলো—তিনি যেকোনো বিষয় খুব ভালোভাবে ও স্পষ্টভাবে বুঝিয়ে বলতে পারেন।';if(/(সদস্য|মেম্বার|member|membership)/i.test(n)&&/(কত|কয়|কয়|সংখ্যা|মোট|বর্তমান|এখন পর্যন্ত|এখন|যুক্ত হয়েছেন|যুক্ত হয়েছেন|how many|count|number)/i.test(n))return 'ধন্যবাদ ফাউন্ডেশনের সদস্যসংখ্যা প্রকাশ না করার সিদ্ধান্ত নিয়েছেন ফাউন্ডেশনের প্রতিষ্ঠাতা, অ্যাডমিন ও মডারেটরবৃন্দ। তাই দুঃখিত, আমি ফাউন্ডেশনের মোট সদস্যসংখ্যা জানাতে পারব না। ফাউন্ডেশনের অন্যান্য তথ্য জানতে আমি সাহায্য করতে পারি।';const g=greeting(q);if(g)return g;const target=navTarget(q);if(target)return `পেজটি খুলে দিচ্ছি: ${target[0]}…`;const f=matchKB(q,FAQ), i=matchKB(q,ISLAM);const foundationHit=f&&f.score>=.36,islamHit=i&&i.score>=.43;if(foundationHit&&(!islamHit||f.score>=i.score-.04))return f.item.a;if(islamHit)return i.item.a;
// Supplement the curated mini-FAQ with the supplied offline Islamic knowledge entries only.
if(Array.isArray(window.KB)){const extra=window.KB.filter(x=>/islam/i.test(String(x.cat||''))).map(x=>({q:x.q,a:x.a,k:x.aliases||[]}));const hit=matchKB(q,extra);if(hit&&hit.score>=.47)return hit.item.a;}
// Common conversational aliases, explicit clarification instead of hallucination.
if(/সদস্য|মেম্বার|membership|member|যোগদান|join/i.test(q))return 'সদস্য হতে ওয়েবসাইটের সদস্য ফর্ম পূরণ করুন। নাম, ফোন নম্বর, WhatsApp নম্বর ও ঠিকানা আবশ্যক; ইমেইল ও সদস্য হওয়ার কারণ ঐচ্ছিক। চাইলে “সদস্য ফর্ম খুলে দাও” লিখুন।';
if(/অনুদান|ডোনেশন|দান|donat|বিকাশ|নগদ/i.test(q))return 'অনুদানের জন্য ওয়েবসাইটের ডোনেশন পেজে বিকাশ বা নগদ ব্যবহার করুন। বিস্তারিত নির্দেশনা পেজে রয়েছে।';
if(inScope(q))return `এই প্রশ্নের উত্তর আমার নলেজ বেসে নিশ্চিতভাবে নেই। দয়া করে ধন্যবাদ ফাউন্ডেশনের অফিসিয়াল WhatsApp নম্বর ${WA}-এ অ্যাডমিনকে মেসেজ করুন।`;
return 'আমি শুধুমাত্র ধন্যবাদ ফাউন্ডেশনের বিভিন্ন কাজে সাহায্য করার জন্য তৈরি। অন্য বিষয়ে উত্তর দিতে পারি না। 🌿';}
function directGuide(q){const n=norm(q);
  if(/হোয়াটসঅ্যাপ গ্রুপ|হোয়াটসঅ্যাপ গ্রুপ|whatsapp group|গ্রুপের লিংক|গ্রুপে যোগ|group link/.test(n)) return 'ধন্যবাদ ফাউন্ডেশনের অনুমোদিত WhatsApp গ্রুপের লিংক এখনো আমার নিশ্চিত তথ্যভান্ডারে নেই। ভুল লিংক না দেওয়ার জন্য লিংকটি অনুমান করছি না। অফিসিয়াল WhatsApp নম্বর 01733476806-এ যোগাযোগ করুন। [WhatsApp-এ মেসেজ করুন](https://wa.me/8801733476806)';
  if(/কুইজ.*(কিভাবে|কীভাবে|ব্যবহার|অংশগ্রহণ|উত্তর)|quiz.*(how|use|join)/.test(n)) return 'কুইজে অংশ নিতে প্রথমে লগইন করুন, তারপর কুইজ পেজ খুলে প্রশ্নের উত্তর নির্বাচন করুন। লগইন না থাকলে ওয়েবসাইট আপনাকে লগইন পেজে পাঠাবে। [কুইজ খুলুন](quiz.html)';
  if(/দৈনন্দিন আমল|আজকের আমল|আমল সেকশন|daily amal/.test(n)) return 'দৈনন্দিন আমল সেকশন ব্যবহার করতে প্রথমে লগইন করুন, তারপর আমল পেজ খুলুন। লগইন না থাকলে লগইন করতে বলা হবে। [দৈনন্দিন আমল খুলুন](activity.html)';
  if(/লগইন|login|অ্যাকাউন্ট তৈরি|নতুন অ্যাকাউন্ট|register|সাইন আপ/.test(n) && /(কিভাবে|কীভাবে|করব|করবো|খুল|তৈরি|how|help|পদ্ধতি)/.test(n)) return 'ওয়েবসাইটের হোম পেজে যান এবং সদস্য লগইন/অ্যাকাউন্ট অংশটি ব্যবহার করুন। লগইন বা নিবন্ধন বাটন খুঁজে না পেলে [হোম পেজ খুলুন](index.html) অথবা [যোগাযোগ পেজে যান](index.html#contact)।';
  if(/সদস্য ফর্ম|সদস্য হতে|সদস্যপদ ফর্ম/.test(n) && /(খুল|কোথায়|কোথায়|কিভাবে|কীভাবে|link|পূরণ)/.test(n)) return 'সদস্য ফর্মে নাম, মোবাইল, WhatsApp ও ঠিকানা পূরণ করুন। আবেদন জমা দেওয়ার পর অ্যাডমিন অনুমোদনের অপেক্ষা করুন। [সদস্য ফর্ম খুলুন](index.html#membership)';
  if(/ডোনেশন|অনুদান|দান/.test(n) && /(কিভাবে|কীভাবে|করব|করবো|পদ্ধতি|link|খুল)/.test(n)) return 'অনুদানের পদ্ধতি ও উপলভ্য পেমেন্ট নির্দেশনা দেখতে ডোনেশন পেজ খুলুন। [ডোনেশন পেজ খুলুন](donate.html)';
  return null;
}
async function process(q){q=String(q||'').trim();if(!q)return;logAIUsage(q);addRow(q,'user');input.value='';input.style.height='auto';
const guide=directGuide(q);if(guide){addRow(guide,'ai');return;}
if(/প্রতিষ্ঠাতা|founder|শাফি/.test(norm(q))&&/(বিস্তারিত|পরিচিতি|কে|সম্পর্কে|জীবনী|বর্ণনা|দায়িত্ব|দায়িত্ব|উদ্দেশ্য|পড়াশোনা|পড়াশোনা|গুণ|কেমন)/.test(norm(q))){addFounderProfileCard();return;}
if(applicationFlow){await handleApplicationInput(q);return;}
if(/(AI|এআই).*(সদস্য.*(আবেদন|হতে|হব))|সদস্য.*(AI|এআই).*(আবেদন|মাধ্যমে)|সদস্য.*(আবেদন করতে চাই|হতে চাই|আবেদন করব)/i.test(q)||/^(সদস্য হতে চাই|আমি সদস্য হতে চাই|apply membership)$/i.test(q)){startApplication();return;}
const target=navTarget(q);if(target){const msg=`ঠিক আছে, ${target[0]} পেজে নিয়ে যাচ্ছি…`;addRow(msg,'ai');setTimeout(()=>location.href=target[1],450);return;}
const t=showTyping();try{let a=await askGenerativeAI(q);if(!a)a=answer(q);t.remove();addRow(a,'ai');}catch(e){t.remove();const a=answer(q);addRow(a,'ai');}}
function resetWelcome(){chat.innerHTML='';chat.innerHTML=`<div class="welcome"><div class="heroIcon"><img src="dhonnobad-ai-round-button.png" alt="ধন্যবাদ AI" class="ai-hero-logo"></div><div class="kicker">DHONNOBAD FOUNDATION</div><h1>আসসালামু আলাইকুম! 👋</h1><p>আমি <b>ধন্যবাদ AI</b>। ফাউন্ডেশনের সদস্যপদ, অনুদান, কার্যক্রম ও যোগাযোগ সম্পর্কে সাহায্য করতে পারি। হালকা ইসলামিক প্রশ্নও করতে পারো।</p><div class="quickGrid"><button data-q="ধন্যবাদ ফাউন্ডেশন কী?">🏢 <span>ফাউন্ডেশন সম্পর্কে</span><b>›</b></button><button data-q="আমি AI-এর মাধ্যমে সদস্য আবেদন করতে চাই">🤝 <span>AI-এর মাধ্যমে সদস্য আবেদন</span><b>›</b></button><button data-q="মাসে কত টাকা অনুদান দিতে হয়?">💚 <span>অনুদান ও মাসিক অনুদান</span><b>›</b></button><button data-q="নামাজের কর্মসূচি কীভাবে চলে?">🕌 <span>নামাজের কর্মসূচি</span><b>›</b></button><button data-q="প্রতিষ্ঠাতা কে?">👤 <span>প্রতিষ্ঠাতা পরিচিতি</span><b>›</b></button><button data-q="যোগাযোগের WhatsApp নম্বর কী?">☎️ <span>যোগাযোগ</span><b>›</b></button></div><div class="welcomeNote">প্রশ্ন লিখে পাঠাও, আমি সাহায্য করার চেষ্টা করব।</div></div>`;chat.querySelectorAll('[data-q]').forEach(b=>b.onclick=()=>process(b.dataset.q));}
function openModal(title,html){$('title').textContent=title;$('body').innerHTML=html;modal.classList.remove('hidden');panel.classList.add('hidden')}
// Reliable menu/settings controls: every visible menu action is wired explicitly.
const menuButton=$('menu');
menuButton?.addEventListener('click',()=>{const isOpen=!panel.classList.contains('hidden');panel.classList.toggle('hidden',isOpen);menuButton.setAttribute('aria-expanded',String(!isOpen));});
document.addEventListener('click',e=>{if(!panel.classList.contains('hidden')&&!panel.contains(e.target)&&!menuButton?.contains(e.target)){panel.classList.add('hidden');menuButton?.setAttribute('aria-expanded','false');}});
$('new')?.addEventListener('click',()=>{history.length=0;save();resetWelcome();panel.classList.add('hidden');menuButton?.setAttribute('aria-expanded','false');input.focus();});
$('clear')?.addEventListener('click',()=>{openModal('কথোপকথন মুছুন','<p class="settings-copy">এই ডিভাইসে সংরক্ষিত কথোপকথনের ইতিহাস মুছে ফেলবেন?</p><div class="settings-actions"><button type="button" id="cancelClear" class="settings-secondary">না, রাখুন</button><button type="button" id="confirmClear" class="settings-danger">হ্যাঁ, মুছুন</button></div>');$('cancelClear').onclick=()=>modal.classList.add('hidden');$('confirmClear').onclick=()=>{history.length=0;save();resetWelcome();modal.classList.add('hidden')};});
$('foundationBtn')?.addEventListener('click',()=>openModal('ফাউন্ডেশন পরিচিতি','<p class="settings-copy">ধন্যবাদ ফাউন্ডেশন একটি স্বেচ্ছাসেবামূলক উদ্যোগ। শিশুদের ইবাদতে উৎসাহ, দরিদ্র ও অসহায় মানুষের পাশে দাঁড়ানো এবং মানবকল্যাণমূলক কাজ আমাদের লক্ষ্য।</p><a class="settings-link" href="index.html#about">ফাউন্ডেশন সম্পর্কে আরও জানুন ↗</a>'));
$('contactBtn')?.addEventListener('click',()=>openModal('যোগাযোগ ও সহায়তা','<p class="settings-copy">অফিসিয়াল ফোন/WhatsApp: <b>01733476806</b></p><div class="settings-actions"><a class="settings-link" href="https://wa.me/8801733476806" target="_blank" rel="noopener">WhatsApp-এ মেসেজ</a><a class="settings-link" href="tel:01733476806">ফোন করুন</a></div>'));
$('pagesBtn')?.addEventListener('click',()=>openModal('ওয়েবসাইটের পেজ','<div class="settings-page-grid"><a href="index.html">🏠 হোম পেজ</a><a href="donate.html">💚 ডোনেশন</a><a href="quiz.html">🧠 কুইজ</a><a href="activity.html">🌙 দৈনন্দিন আমল</a><a href="founder.html">👤 প্রতিষ্ঠাতা</a><a href="moderators.html">👥 মডারেটর</a></div>'));
$('aboutAI')?.addEventListener('click',()=>openModal('ধন্যবাদ AI সম্পর্কে','<p class="settings-copy">আমি ধন্যবাদ ফাউন্ডেশনের তথ্য, সদস্যপদ, অনুদান, কার্যক্রম ও সাধারণ ইসলামিক প্রশ্নে সহায়তা করার জন্য তৈরি। সব প্রশ্নের উত্তর নিশ্চিতভাবে জানা নাও থাকতে পারে; গুরুত্বপূর্ণ তথ্য অফিসিয়াল যোগাযোগের মাধ্যমে যাচাই করুন।</p>'));
form.addEventListener('submit',e=>{e.preventDefault();process(input.value)});input.addEventListener('input',()=>{input.style.height='auto';input.style.height=Math.min(input.scrollHeight,140)+'px'});input.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();form.requestSubmit()}});
$('historyBtn').onclick=()=>{const users=history.map((x,i)=>({...x,i})).filter(x=>x.role==='user').slice(-40).reverse();openModal('◷ আগের কথোপকথন',users.length?users.map(x=>`<div class="historyItem" data-i="${x.i}"><b>${esc(x.text)}</b><small>${new Date(x.time).toLocaleString('bn-BD')}</small></div>`).join(''):'<div class="empty">এখনও কোনো কথোপকথন নেই।</div>');document.querySelectorAll('.historyItem').forEach(el=>el.onclick=()=>{const idx=+el.dataset.i;chat.innerHTML='';history.slice(idx).forEach(x=>addRow(x.text,x.role==='user'?'user':'ai',false));modal.classList.add('hidden')});};
if(history.length){chat.innerHTML='';history.slice(-60).forEach(x=>addRow(x.text,x.role==='user'?'user':'ai',false));}else resetWelcome();
})();
