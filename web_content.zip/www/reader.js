// Leitor mínimo de .xlsx/.xlsm (sem bibliotecas). Funciona no navegador/Android WebView e no Node 18+.
(function(g){
const N=s=>String(s??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();
const dec=s=>s.replace(/&#x([0-9a-f]+);/gi,(_,h)=>String.fromCodePoint(parseInt(h,16))).replace(/&#(\d+);/g,(_,d)=>String.fromCodePoint(+d)).replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&apos;/g,"'").replace(/&amp;/g,'&');
const attrs=t=>{const o={};t.replace(/([\w:]+)="([^"]*)"/g,(_,k,v)=>o[k]=v);return o};
const inflate=async u=>new Uint8Array(await new Response(new Blob([u]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).arrayBuffer());
async function unzip(buf){
  const u=new Uint8Array(buf),dv=new DataView(buf),td=new TextDecoder();let e=u.length-22;
  while(e>=0&&dv.getUint32(e,true)!==0x06054b50)e--;
  if(e<0)throw new Error('Arquivo inválido (não é um Excel .xlsx/.xlsm).');
  const n=dv.getUint16(e+10,true);let p=dv.getUint32(e+16,true);const F={};
  for(let i=0;i<n;i++){
    const m=dv.getUint16(p+10,true),cs=dv.getUint32(p+20,true),nl=dv.getUint16(p+28,true),xl=dv.getUint16(p+30,true),cl=dv.getUint16(p+32,true),lo=dv.getUint32(p+42,true);
    F[td.decode(u.subarray(p+46,p+46+nl))]={m,cs,lo};p+=46+nl+xl+cl;
  }
  return async name=>{const f=F[name];if(!f)return null;const s=f.lo+30+dv.getUint16(f.lo+26,true)+dv.getUint16(f.lo+28,true),d=u.subarray(s,s+f.cs);return td.decode(f.m?await inflate(d):d)};
}
const col=r=>{let n=0;for(const c of r.replace(/\d+/g,''))n=n*26+c.charCodeAt(0)-64;return n-1};
function rowsOf(xml,sst){
  const out=[];
  xml.replace(/<row\b[^>]*?(?:\/>|>([\s\S]*?)<\/row>)/g,(_,b)=>{
    const r=[];
    if(b)b.replace(/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g,(_,a,x)=>{
      if(!x)return;const A=attrs(a),v=(x.match(/<v>([\s\S]*?)<\/v>/)||[])[1];let val=null;
      if(A.t==='s')val=sst[+v];
      else if(A.t==='inlineStr')val=dec((x.match(/<t\b[^>]*>([\s\S]*?)<\/t>/)||[,''])[1]);
      else if(v!==undefined)val=A.t==='str'?dec(v):(A.t==='b'||A.t==='e')?null:+v;
      r[col(A.r)]=val;
    });
    out.push(r);
  });
  return out;
}
// campo -> início do texto do cabeçalho (sem acento, minúsculo)
const KEYS=[['area','area'],['cor','tipo'],['centro','centro de trabalho'],['nota','nota'],['prio','prioridade'],['equip','denominacao do local'],['desc','descricao da anomalia'],['setor','setor'],['local','local de instalacao'],['quando','quando executar'],['notif','notificado por'],['data','data criacao'],['prazo','prazo programado'],['status','status'],['resp','responsavel'],['ordem','ordem'],['risco','ha risco'],['imed','providencia imediata'],['def','providencia definitiva'],['coment','comentarios']];
const iso=n=>typeof n==='number'?new Date(Math.round((n-25569)*864e5)).toISOString().slice(0,10):(n||null);
g.lerExcel=async buf=>{
  const get=await unzip(buf);
  const wb=await get('xl/workbook.xml'),rel=await get('xl/_rels/workbook.xml.rels');
  if(!wb||!rel)throw new Error('Arquivo não parece ser um Excel válido.');
  const rid={},sheets=[],sst=[];
  rel.replace(/<Relationship\b[^>]*>/g,t=>{const a=attrs(t);rid[a.Id]=a.Target});
  wb.replace(/<sheet\b[^>]*>/g,t=>{const a=attrs(t);sheets.push({n:dec(a.name),p:rid[a['r:id']]})});
  ((await get('xl/sharedStrings.xml'))||'').replace(/<si>([\s\S]*?)<\/si>/g,(_,b)=>{let s='';b.replace(/<rPh[\s\S]*?<\/rPh>/g,'').replace(/<t\b[^>]*>([\s\S]*?)<\/t>/g,(_,t)=>s+=dec(t));sst.push(s)});
  sheets.sort((a,b)=>(N(b.n)==='lista compl.')-(N(a.n)==='lista compl.'));
  for(const sh of sheets){
    if(/encerrada/i.test(sh.n)||!sh.p)continue;
    const xml=await get(sh.p.replace(/^\/?(xl\/)?/,'xl/'));if(!xml)continue;
    const R=rowsOf(xml,sst);
    const hi=R.slice(0,40).findIndex(r=>r&&r.some(c=>N(c)==='nota')&&r.some(c=>N(c).startsWith('descricao da anomalia')));
    if(hi<0)continue;
    const H=Array.from(R[hi],c=>N(c)),ix=KEYS.map(([,k])=>H.findIndex(h=>h.startsWith(k)));
    let atualizado=null;
    for(const r of R.slice(0,hi)){const j=r?Array.from(r,c=>N(c)).findIndex(c=>c.includes('atualizada ate')):-1;if(j>=0){atualizado=iso(r.slice(j+1).find(x=>typeof x==='number'));break}}
    const rows=[];
    for(const r of R.slice(hi+1)){
      if(!r)continue;
      const o=ix.map((i,j)=>{let v=i<0?null:r[i];if(v===''||v===undefined)v=null;const k=KEYS[j][0];
        if(k==='data'||k==='prazo')v=iso(v);else if(typeof v==='number')v=String(v);
        return typeof v==='string'?v.trim()||null:v});
      if(o[3])rows.push(o);
    }
    return {atualizado,cols:KEYS.map(k=>k[0]),rows};
  }
  throw new Error('Não encontrei a aba das etiquetas (colunas "Nota" e "Descrição da anomalia").');
};
})(globalThis);
