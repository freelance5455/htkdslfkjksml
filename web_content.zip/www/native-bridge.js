// Inside the Android app the WebView ignores "download" links for in-memory files,
// so the backup / CSV buttons would silently do nothing. This makes them open the
// Android share sheet instead (save to Drive, Files, WhatsApp, e-mail...).
// It only runs inside the native app; in a normal browser nothing changes.
(function () {
  var C = window.Capacitor;
  if (!C || !C.isNativePlatform || !C.isNativePlatform()) return;

  var blobs = {};
  var origCreate = URL.createObjectURL;
  URL.createObjectURL = function (b) {
    var u = origCreate.call(URL, b);
    blobs[u] = b;
    return u;
  };

  function toBase64(buf) {
    var s = '', bytes = new Uint8Array(buf), step = 0x8000;
    for (var i = 0; i < bytes.length; i += step) {
      s += String.fromCharCode.apply(null, bytes.subarray(i, i + step));
    }
    return btoa(s);
  }

  async function saveAndShare(blob, name) {
    var P = C.Plugins || {};
    if (!P.Filesystem || !P.Share) throw new Error('Filesystem/Share plugins are missing');
    var safe = String(name || 'file').replace(/[\\/:*?"<>|]/g, '_');
    var data = toBase64(await blob.arrayBuffer());
    var res = await P.Filesystem.writeFile({ path: safe, data: data, directory: 'CACHE' });
    await P.Share.share({ title: safe, url: res.uri, dialogTitle: 'حفظ الملف' });
  }

  var origClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    var blob = this.download && blobs[this.href];
    if (blob) {
      saveAndShare(blob, this.download).catch(function (e) {
        alert('تعذر حفظ الملف: ' + e.message);
      });
      return;
    }
    return origClick.apply(this, arguments);
  };
})();
