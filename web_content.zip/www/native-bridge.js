/* Pont Capacitor : n'a aucun effet dans un navigateur normal. */
(function () {
  var C = window.Capacitor;
  var native = !!(C && C.isNativePlatform && C.isNativePlatform());
  var NB = { isNative: native };
  window.NativeBridge = NB;
  if (!native) return;

  var P = C.Plugins || {};

  function toBase64(d) {
    return new Promise(function (res, rej) {
      var blob = d instanceof Blob ? d : (typeof d === "string" ? new Blob([d], { type: "text/plain;charset=utf-8" }) : new Blob([d]));
      var r = new FileReader();
      r.onload = function () { res(String(r.result).split(",")[1] || ""); };
      r.onerror = function () { rej(new Error("read failed")); };
      r.readAsDataURL(blob);
    });
  }

  function safeName(n) { return String(n).replace(/[\\/:*?"<>|]+/g, "_"); }

  /* Enregistre le fichier dans le cache puis ouvre la feuille de partage Android
     (enregistrer, WhatsApp, Gmail, imprimer...). */
  NB.saveShare = async function (name, data, text) {
    var FS = P.Filesystem, SH = P.Share;
    if (!FS || !SH) throw new Error("Plugins Filesystem/Share indisponibles");
    name = safeName(name);
    var b64 = await toBase64(data);
    await FS.writeFile({ path: name, data: b64, directory: "CACHE" });
    var u = await FS.getUri({ path: name, directory: "CACHE" });
    var o = { title: name, url: u.uri, dialogTitle: name };
    if (text) o.text = text;
    await SH.share(o);
  };

  /* navigator.share / canShare (fichiers) */
  try {
    Object.defineProperty(navigator, "canShare", {
      configurable: true,
      value: function (o) { return !!(o && o.files && o.files.length); }
    });
    Object.defineProperty(navigator, "share", {
      configurable: true,
      value: async function (o) {
        var f = o && o.files && o.files[0];
        if (f) { await NB.saveShare(f.name, await f.arrayBuffer(), o.text || o.title); return; }
        if (P.Share) await P.Share.share({ title: o && o.title, text: o && o.text, url: o && o.url });
      }
    });
  } catch (e) {}

  /* Notifications : API Notification -> LocalNotifications */
  var LN = P.LocalNotifications, perm = "default", nid = 1;
  function map(r) { var v = r && r.display; return v === "granted" ? "granted" : (v === "denied" ? "denied" : "default"); }
  function Ntf(title, opts) {
    if (!LN) return;
    opts = opts || {};
    nid = (nid % 100000) + 1;
    var id = (Math.floor(Date.now() / 1000) % 2000000) * 1000 + nid;
    LN.schedule({
      notifications: [{ id: id, title: String(title), body: String(opts.body || ""), schedule: { at: new Date(Date.now() + 400) } }]
    }).catch(function () {});
  }
  Ntf.requestPermission = function () {
    if (!LN) return Promise.resolve("denied");
    return LN.requestPermissions().then(function (r) { perm = map(r); return perm; }, function () { return "denied"; });
  };
  Object.defineProperty(Ntf, "permission", { get: function () { return perm; } });
  window.Notification = Ntf;
  if (LN) LN.checkPermissions().then(function (r) { perm = map(r); }, function () {});

  /* Liens externes (WhatsApp, e-mail...) : laisser Android les ouvrir */
  window.open = function (u) { if (u) location.href = u; return null; };

  /* Bouton Retour : fermer les fenêtres ouvertes, sinon quitter */
  if (P.App && P.App.addListener) {
    P.App.addListener("backButton", function () {
      var o = [].slice.call(document.querySelectorAll(".ov")).filter(function (x) { return !x.hidden; });
      if (o.length && typeof window.ov === "function") { window.ov(o[o.length - 1].id, 0); return; }
      P.App.exitApp();
    });
  }
})();
