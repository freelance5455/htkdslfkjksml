import { database } from "./firebase.js";
import { ref, onValue } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-database.js";

const pageKey = (() => {
 const f=(location.pathname.split("/").pop()||"index.html").toLowerCase();
 return ({"index.html":"index","founder.html":"founder","moderators.html":"moderators","donate.html":"donate","quiz.html":"quiz","activity.html":"activity","talk.html":"talk"})[f]||null;
})();
if(pageKey){
 const safeHtml = s => window.DOMPurify ? window.DOMPurify.sanitize(String(s||""),{USE_PROFILES:{html:true},FORBID_TAGS:["style","script","iframe","object","embed","form","input","textarea","select","option","meta","link"],FORBID_ATTR:["style"]}) : "";
 let lastApplied="";
 onValue(ref(database,"websiteLiveUI/published"),snap=>{
  if(!snap.exists())return;
  const root=snap.val()||{}, cfg=root.pages?.[pageKey];
  if(!cfg)return;
  const signature=JSON.stringify([cfg.css||"",cfg.html||"",cfg.selector||"",cfg.mode||""]);
  if(signature===lastApplied)return;
  lastApplied=signature;
  let style=document.getElementById("df-live-ui-published-css");
  if(!style){style=document.createElement("style");style.id="df-live-ui-published-css";document.head.appendChild(style);}
  style.textContent=String(cfg.css||"").slice(0,50000);
  const old=document.getElementById("df-live-ui-published-html");
  if(old)old.remove();
  if(cfg.html&&cfg.selector){
   try{
    const target=document.querySelector(String(cfg.selector).slice(0,180)), html=safeHtml(cfg.html);
    if(target&&html){
     const block=document.createElement("div");block.id="df-live-ui-published-html";block.innerHTML=html;
     if(cfg.mode==="replace")target.replaceChildren(block);
     else if(cfg.mode==="prepend")target.prepend(block);
     else target.append(block);
    }
   }catch(e){console.warn("Dhonnobad live UI: invalid selector or HTML",e);}
  }
 },e=>console.warn("Dhonnobad live UI settings could not be loaded.",e));
}
