(function(){
var data={machines:{},logs:{},config:{},blobs:{}},subs={},h,CAP=window.Capacitor&&window.Capacitor.Plugins||{};
function open(){return new Promise(function(ok,no){var r=indexedDB.open("mm",1);r.onupgradeneeded=function(){r.result.createObjectStore("s")};r.onsuccess=function(){ok(r.result)};r.onerror=no})}
function load(){return open().then(function(d){h=d;return new Promise(function(ok){var q=d.transaction("s").objectStore("s").get("data");q.onsuccess=function(){if(q.result)data=q.result;ok()};q.onerror=ok})})}
function save(){return new Promise(function(ok){var t=h.transaction("s","readwrite");t.objectStore("s").put(data,"data");t.oncomplete=ok;t.onerror=ok})}
function notify(c){(subs[c]||[]).forEach(function(f){f()})}
function snap(c){var o=data[c]||{};return{docs:Object.keys(o).map(function(id){return{id:id,data:function(){return o[id]}}})}}
var db={collection:function(c){return{
 onSnapshot:function(f){(subs[c]=subs[c]||[]).push(function(){f(snap(c))});setTimeout(function(){f(snap(c))},0)},
 doc:function(id){return{
  set:async function(v){(data[c]=data[c]||{})[id]=v;await save();notify(c)},
  delete:async function(){delete (data[c]||{})[id];await save();notify(c)},
  get:async function(){var v=(data[c]||{})[id];return{exists:!!v,data:function(){return v}}}}}}}};
var assets={upload:function(b){return new Promise(function(ok,no){var r=new FileReader();r.onload=async function(){var id="d"+Date.now().toString(36)+Math.random().toString(36).slice(2,6);data.blobs[id]=r.result;await save();ok({id:id,url:r.result})};r.onerror=no;r.readAsDataURL(b)})}};
async function saveFile(name,text,mime){
  if(CAP.Filesystem&&CAP.Share){var w=await CAP.Filesystem.writeFile({path:name,data:text,directory:"CACHE",encoding:"utf8"});await CAP.Share.share({title:name,files:[w.uri]});return}
  var a=document.createElement("a");a.href=URL.createObjectURL(new Blob([text],{type:mime||"text/plain"}));a.download=name;document.body.appendChild(a);a.click();a.remove()}
var downloads={save:function(o){return saveFile(o.filename,o.data,/csv/.test(o.filename)?"text/csv":"application/json")}};
window.__blob=function(i){return data.blobs[i]||""};
window.print=function(){
  var p=document.body.dataset.print,el=p==="labels"?document.getElementById("labels"):p==="label"?document.getElementById("labelbox"):document.getElementById("app");
  var css=document.querySelector("style").textContent,html='<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>'+css+'</style><body style="background:#fff;color:#000"><div id="app">'+el.innerHTML+'</div><script>setTimeout(function(){window.print()},500)<\/script>';
  saveFile("imprimir.html",html,"text/html")};
var ready=load();
window.claude={use:async function(n){await ready;return n==="db"?db:n==="assets"?assets:n==="downloads"?downloads:null}};
})();