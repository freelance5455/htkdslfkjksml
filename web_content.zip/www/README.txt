MASTER SHIELD preview package

This is a web-app preview, not an Android APK.
It can be opened in a browser. To install as an app-like shortcut:
1. Put the www folder on a secure HTTPS website.
2. Open that website in Chrome on Android.
3. Use Chrome menu > Add to Home screen / Install app.

A signed APK requires an Android build environment and signing step.
This package does not contain a compiled APK.
