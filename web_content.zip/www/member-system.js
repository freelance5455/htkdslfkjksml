import { app, auth, database } from './firebase.js';
import { signInAnonymously, signInWithCustomToken, onAuthStateChanged, setPersistence, browserLocalPersistence } from 'https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js';
import { getFunctions, httpsCallable } from 'https://www.gstatic.com/firebasejs/12.1.0/firebase-functions.js';
import { ref, get, set, update, push, onValue, runTransaction } from 'https://www.gstatic.com/firebasejs/12.1.0/firebase-database.js';

// Account recovery requests and review status are stored in Firebase Realtime Database.

const PHONE_RE = /^01\d{9}$/;
const functions = getFunctions(app);
let recoveryPollUnsub = null, recoveryCompleting = false;
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let currentMember = null, notificationUnsub = null, broadcastUnsub = null;
const $ = id => document.getElementById(id);
const redirectParams = new URLSearchParams(location.search);
const requestedReturn = ['quiz.html','activity.html','profile.html'].includes(redirectParams.get('returnTo')) ? redirectParams.get('returnTo') : '';
if(redirectParams.get('authRequired')==='1' && requestedReturn) sessionStorage.setItem('df_post_login_return', requestedReturn);
function finishLoginRedirect(){const target=sessionStorage.getItem('df_post_login_return');if(target){sessionStorage.removeItem('df_post_login_return');location.replace(target);return true;}return false;}

function injectUI(){
 const isMainPage = location.pathname.endsWith('/') || /(?:^|\/)index\.html$/i.test(location.pathname);
 if(!isMainPage) return;
 if(document.getElementById('memberSystemRoot')) return;
 const root=document.createElement('div'); root.id='memberSystemRoot'; root.innerHTML=`
 <button id="memberLoginButton" class="ms-login-fab" type="button" aria-haspopup="dialog">♙ <span>লগইন</span></button>
 <aside id="memberNotificationPanel" class="ms-notice-panel" aria-live="polite" hidden><div class="ms-panel-head"><strong>🔔 নোটিফিকেশন</strong><button id="msNoticeClose" type="button" aria-label="বন্ধ করুন">×</button></div><div id="msMemberGreeting" class="ms-greeting"></div><div id="msNotificationList"></div></aside>
 <div id="memberLoginModal" class="ms-modal" hidden><section class="ms-modal-card" role="dialog" aria-modal="true" aria-labelledby="msLoginTitle"><button id="msModalClose" class="ms-close" type="button" aria-label="বন্ধ করুন">×</button><div class="ms-icon">♙</div><h2 id="msLoginTitle">সদস্য লগইন</h2><div id="msAuthRequiredNotice" class="ms-auth-required" hidden>🔐 এই সেকশনটি ব্যবহার করতে আপনাকে প্রথমে লগইন করতে হবে। অনুগ্রহ করে আপনার অ্যাকাউন্টে লগইন করুন। লগইন করার পর আপনি কুইজ ও দৈনন্দিন আমল সেকশন ব্যবহার করতে পারবেন।</div><p>একটি বাংলাদেশি মোবাইল নম্বর সর্বোচ্চ ২টি ডিভাইস/ব্রাউজারে ব্যবহার করা যাবে। এই ব্রাউজারে লগইন সংরক্ষিত থাকবে।</p><form id="msLoginForm"><label>আপনার নাম<input id="msName" name="name" maxlength="80" required autocomplete="name" placeholder="পূর্ণ নাম"></label><label>মোবাইল নম্বর<input id="msPhone" name="phone" required inputmode="numeric" autocomplete="tel-national" maxlength="11" placeholder="01XXXXXXXXX"></label><p id="msLoginHelp" class="ms-privacy">নতুন হলে অ্যাকাউন্ট তৈরি হবে। আগে অ্যাকাউন্ট থাকলে নতুন ডিভাইস থেকে প্রবেশের জন্য অ্যাডমিন অনুমোদন লাগতে পারে।</p><button id="msLoginSubmit" type="submit">লগইন / নিবন্ধন</button><p id="msLoginStatus" role="status"></p><section id="msRecoveryBox" class="ms-recovery-box" hidden><div class="ms-recovery-icon">🛡️</div><h3>অ্যাকাউন্ট পুনরুদ্ধারের অনুমোদন</h3><p>এই ফোন নম্বরে আগে থেকেই অ্যাকাউন্ট আছে। অ্যাডমিনের কাছে ২৪ ঘণ্টার জন্য পুনরুদ্ধারের অনুরোধ পাঠান। অ্যাডমিন অনুমোদন করলে এই পেজ খোলা থাকলে স্বয়ংক্রিয়ভাবে পুরোনো অ্যাকাউন্টে লগইন হবে।</p><button id="msRequestRecovery" type="button">🔔 অ্যাডমিনের অনুমোদন চান</button><p id="msRecoveryStatus" role="status"></p></section></form></section></div>`;
 document.body.appendChild(root);
 const style=document.createElement('style'); style.textContent=`
 .ms-login-fab{position:fixed;z-index:9000;right:18px;top:16px;border:0;border-radius:999px;padding:6px 10px;min-height:32px;font-size:11px;background:linear-gradient(135deg,#0e7a58,#13a37a);color:white;font:700 12px system-ui;box-shadow:0 8px 22px #08745130;cursor:pointer}.ms-login-fab.ms-logged{background:linear-gradient(135deg,#173b32,#0e7a58)}
 .ms-modal[hidden],.ms-notice-panel[hidden],.ms-auth-required[hidden]{display:none!important}.ms-auth-required{margin:14px 0;padding:13px 14px;border:1px solid #b9e5d0;border-radius:14px;background:linear-gradient(135deg,#effcf5,#fff9e9);color:#14583f;font-size:13px;line-height:1.7;font-weight:650}.ms-modal{position:fixed;inset:0;z-index:10000;background:#071b16a8;backdrop-filter:blur(7px);display:grid;place-items:center;padding:18px}.ms-modal-card{position:relative;width:min(100%,430px);padding:28px;border-radius:24px;background:#fff;color:#17342c;box-shadow:0 30px 90px #001d1670;font-family:system-ui,sans-serif}.ms-modal-card h2{margin:8px 0;font-size:25px}.ms-modal-card>p{line-height:1.65;color:#5e706a;font-size:14px}.ms-icon{width:48px;height:48px;display:grid;place-items:center;border-radius:15px;background:#e5f7ef;font-size:26px}.ms-close,.ms-panel-head button{position:absolute;right:15px;top:13px;border:0;background:#eef4f1;border-radius:50%;width:32px;height:32px;font-size:22px;cursor:pointer}.ms-modal-card label{display:block;margin:14px 0;font-size:13px;font-weight:700}.ms-modal-card input{box-sizing:border-box;display:block;width:100%;margin-top:7px;border:1px solid #d6e3dd;border-radius:12px;padding:13px;font:inherit;outline-color:#13a37a}.ms-modal-card form>button{width:100%;padding:13px;border:0;border-radius:12px;background:#0e7a58;color:#fff;font-weight:800;cursor:pointer}.ms-privacy{font-size:12px!important;color:#8a5b21!important;background:#fff7e8;padding:10px;border-radius:10px}.ms-greeting{padding:12px 14px;background:#eaf8f1;border-radius:12px;margin:12px 0;color:#155b43}.ms-notice-panel{position:fixed;z-index:9500;right:16px;top:66px;width:min(370px,calc(100vw - 32px));max-height:min(72vh,620px);overflow:auto;background:#fff;color:#18362c;border:1px solid #dbe9e1;border-radius:18px;box-shadow:0 18px 60px #092b1e35;padding:14px;font-family:system-ui,sans-serif}.ms-panel-head{position:relative;padding:5px 36px 12px 2px;border-bottom:1px solid #e7efeb}.ms-panel-head button{top:0;right:0}.ms-notice-item{padding:13px 3px;border-bottom:1px solid #edf2ef}.ms-notice-item:last-child{border-bottom:0}.ms-notice-item strong{display:block;margin-bottom:5px}.ms-notice-item p{margin:0;white-space:pre-wrap;overflow-wrap:anywhere;line-height:1.55;font-size:14px}.ms-notice-item small{display:block;color:#7a8982;margin-top:7px}.ms-empty{color:#75847d;padding:16px 4px;font-size:14px}#msLoginStatus{font-size:13px;color:#b42318;margin-bottom:0}

 .ms-recovery-box{margin-top:16px;padding:17px;border:1px solid #c8e4d7;border-radius:17px;background:linear-gradient(145deg,#f0fbf5,#f5f8ff);box-shadow:0 10px 25px #174b3410}.ms-recovery-box[hidden]{display:none!important}.ms-recovery-icon{width:42px;height:42px;display:grid;place-items:center;background:#dff6e9;border-radius:13px;font-size:23px}.ms-recovery-box h3{font-size:17px;margin:10px 0 6px;color:#174b39}.ms-recovery-box p{font-size:13px;line-height:1.65;color:#566b61}.ms-recovery-box button{width:100%;padding:12px;border:0;border-radius:12px;background:linear-gradient(135deg,#0e7a58,#148bca);color:white;font-weight:800;cursor:pointer}.ms-recovery-box button:disabled{opacity:.6;cursor:wait}
 @media(max-width:600px){.ms-login-fab{right:10px;top:10px;min-height:30px;padding:6px 9px;font-size:11px}.ms-modal-card{padding:23px}.ms-notice-panel{right:10px;top:58px}}
 `; document.head.appendChild(style);
 const hasMemberSession=()=>{if(currentMember?.uid)return true;try{const m=JSON.parse(localStorage.getItem('df_global_member')||'null');return !!(m&&m.uid&&m.phone);}catch{return false;}};
 const openLoginModal=({required=false}={})=>{const notice=$('msAuthRequiredNotice');if(notice)notice.hidden=!required;$('memberLoginModal').hidden=false;setTimeout(()=>$('msName')?.focus(),40);};
 // Make every home-page login/profile entry open the real login form when logged out.
 $('memberLoginButton').addEventListener('click',()=>{ if(hasMemberSession()){ location.href='profile.html'; }else { openLoginModal(); } });
 document.querySelectorAll('a[href]').forEach(link=>{
   const href=(link.getAttribute('href')||'').split(/[?#]/)[0].replace(/^\.\//,'');
   if(href!=='profile.html')return;
   link.addEventListener('click',event=>{
     if(hasMemberSession())return;
     event.preventDefault();openLoginModal();
   });
 });
 $('msModalClose').addEventListener('click',()=> $('memberLoginModal').hidden=true);
 $('msNoticeClose').addEventListener('click',()=> $('memberNotificationPanel').hidden=true);
 $('memberLoginModal').addEventListener('click',e=>{if(e.target.id==='memberLoginModal')e.currentTarget.hidden=true;});
 $('msLoginForm').addEventListener('submit',registerMember);
 $('msRequestRecovery').addEventListener('click',requestRecovery);
 $('msPhone').addEventListener('input',()=>{ $('msRecoveryBox').hidden=true; $('msRecoveryStatus').textContent=''; });
}
async function registerMember(e){
 e.preventDefault();
 const name=$('msName').value.trim(), phone=$('msPhone').value.replace(/[\s-]/g,''), status=$('msLoginStatus'), btn=$('msLoginSubmit');
 if(name.length<2){status.textContent='কমপক্ষে ২ অক্ষরের নাম লিখুন।';return;}
 if(!PHONE_RE.test(phone)){status.textContent='বাংলাদেশি ১১ সংখ্যার মোবাইল নম্বর লিখুন (01XXXXXXXXX)।';return;}
 btn.disabled=true;status.style.color='#53665e';status.textContent='অ্যাকাউন্ট যাচাই হচ্ছে…';
 try{
  await setPersistence(auth,browserLocalPersistence);
  if(!auth.currentUser) await signInAnonymously(auth);
  const user=auth.currentUser;
  if(!user) throw new Error('লগইন সেশন তৈরি হয়নি। আবার চেষ্টা করুন।');
  const indexRef=ref(database,'memberPhoneIndex/'+phone);
  // One phone number can be linked to at most two distinct browser/device UIDs.
  // Keep the original `uid` field for compatibility with existing recovery/admin code.
  const claim=await runTransaction(indexRef,old=>{
   if(old===null) return {uid:user.uid,loginCount:1,createdAt:Date.now()};
   const entry=(typeof old==='string')?{uid:old}:old;
   if(!entry||!entry.uid) return {uid:user.uid,loginCount:1,createdAt:Date.now()};
   if(entry.uid===user.uid||entry.secondaryUid===user.uid) return entry;
   if(!entry.secondaryUid) return {...entry,secondaryUid:user.uid,loginCount:2,secondaryCreatedAt:Date.now()};
   return entry;
  });
  const index=claim.snapshot.val();
  const isAllowed=index && (index.uid===user.uid || index.secondaryUid===user.uid || index===user.uid);
  if(!claim.committed||!isAllowed){
   $('msRecoveryBox').hidden=false;
   status.style.color='#8a5b21';
   status.textContent='এই নম্বর দিয়ে সর্বোচ্চ দুইটি ডিভাইস/ব্রাউজারে লগইন করা যাবে। এই নম্বরটি ইতিমধ্যে দুইবার ব্যবহার হয়েছে। আবার প্রবেশ করতে অ্যাডমিনের কাছে রিকভারি রিকোয়েস্ট পাঠান।';
   return;
  }
  const profileRef=ref(database,'memberUsers/'+user.uid);
  const profileSnap=await get(profileRef);
  const profile=profileSnap.val()||{};
  if(profileSnap.exists()){
   if(profile.status==='deleted') throw new Error('এই অ্যাকাউন্টটি নিষ্ক্রিয়।');
   if(String(profile.phone||'')!==phone) throw new Error('এই অ্যাকাউন্টের ফোন নম্বর মেলেনি।');
   if(String(profile.name||'').trim().toLocaleLowerCase()!==name.toLocaleLowerCase()) throw new Error('এই ফোন নম্বরের সঙ্গে নামটি মিলছে না।');
   await update(profileRef,{lastSeenAt:Date.now()});
  }else{
   await set(profileRef,{name,phone,createdAt:Date.now(),registeredAt:Date.now(),lastSeenAt:Date.now(),status:'active',...(index.secondaryUid===user.uid?{linkedAs:'secondary'}:{})});
  }
  currentMember={uid:user.uid,name:profile.name||name,phone};
  localStorage.setItem('df_global_member',JSON.stringify(currentMember));
  window.dispatchEvent(new CustomEvent('df-member-login',{detail:currentMember}));
  $('memberLoginModal').hidden=true;
  $('memberLoginButton').innerHTML='👤 <span>আমার প্রোফাইল</span>';
  $('memberLoginButton').classList.add('ms-logged');
  startNotifications(user.uid);
  status.textContent=profileSnap.exists()?'':'অ্যাকাউন্ট তৈরি হয়েছে।';
  if(!profileSnap.exists()) setTimeout(()=>{location.href='profile.html';},700);
  if(finishLoginRedirect())return;
 }catch(err){console.error('Member login error',err);status.style.color='#b42318';status.textContent=(err?.message||'লগইন হয়নি। ইন্টারনেট সংযোগ পরীক্ষা করে আবার চেষ্টা করুন.');}
 finally{btn.disabled=false;}
}
async function requestRecovery(){
 const name=$('msName').value.trim(),phone=$('msPhone').value.replace(/[\\s-]/g,''),btn=$('msRequestRecovery'),out=$('msRecoveryStatus');
 if(name.length<2||!PHONE_RE.test(phone)){out.style.color='#b42318';out.textContent='আগে নাম ও সঠিক ১১ সংখ্যার ফোন নম্বর লিখুন।';return;}
 const requester=auth.currentUser;
 if(!requester){out.style.color='#b42318';out.textContent='রিকভারি অনুরোধ পাঠাতে আগে লগইন/নিবন্ধন করুন।';return;}
 btn.disabled=true;out.style.color='#53665e';out.textContent='Firebase-এ রিকভারি অনুরোধ পাঠানো হচ্ছে…';
 try{
  const idx=await get(ref(database,'memberPhoneIndex/'+phone));
  const targetUid=idx.val()?.uid || idx.val();
  if(!targetUid){throw new Error('এই ফোন নম্বরের পুরোনো অ্যাকাউন্ট খুঁজে পাওয়া যায়নি।');}
  const requestsRef=ref(database,'accountRecoveryRequests');
  const req=push(requestsRef);
  await set(req,{name,phone,targetUid:String(targetUid),requesterUid:requester.uid,status:'pending',createdAt:Date.now(),expiresAt:Date.now()+24*60*60*1000});
  sessionStorage.setItem('df_recovery_request_id',req.key);
  out.style.color='#176b4b';out.textContent='✅ অনুরোধ Firebase-এ জমা হয়েছে। অ্যাডমিন অনুমোদন করলে এই ডিভাইসে পুরোনো অ্যাকাউন্টে লগইনের চেষ্টা হবে।';
 }catch(err){console.error('Firebase recovery request failed',err);out.style.color='#b42318';out.textContent=err?.message||'অনুরোধ পাঠানো যায়নি। Firebase Database Rules পরীক্ষা করুন।';}
 finally{btn.disabled=false;}
}
function stopRecoveryPolling(){if(recoveryPollUnsub){recoveryPollUnsub();recoveryPollUnsub=null;}}
function startRecoveryPolling(requestId){
 if(!requestId||recoveryPollUnsub)return;
 const requestRef=ref(database,'accountRecoveryRequests/'+requestId);
 recoveryPollUnsub=onValue(requestRef,async snap=>{
  if(!snap.exists())return;
  const request=snap.val()||{};
  if(request.status==='rejected'){
   stopRecoveryPolling();sessionStorage.removeItem('df_recovery_request_id');
   const out=$('msRecoveryStatus');if(out){out.style.color='#b42318';out.textContent='অ্যাডমিন রিকভারি অনুরোধটি প্রত্যাখ্যান করেছেন।';}
   return;
  }
  if(request.status!=='approved'||recoveryCompleting)return;
  if(Number(request.expiresAt||0)&&Number(request.expiresAt)<Date.now()){
   stopRecoveryPolling();sessionStorage.removeItem('df_recovery_request_id');
   const out=$('msRecoveryStatus');if(out){out.style.color='#b42318';out.textContent='রিকভারি অনুরোধের মেয়াদ শেষ হয়েছে। নতুন অনুরোধ পাঠান।';}return;
  }
  const user=auth.currentUser;
  if(!user||user.uid!==request.requesterUid)return;
  recoveryCompleting=true;const out=$('msRecoveryStatus');if(out){out.style.color='#176b4b';out.textContent='✅ অনুমোদন পেয়েছেন। পুরোনো অ্যাকাউন্টে লগইন করা হচ্ছে…';}
  try{
   const completeRecovery=httpsCallable(functions,'completeApprovedRecovery');
   const result=await completeRecovery({requestId});
   if(!result.data?.token)throw new Error('লগইন টোকেন পাওয়া যায়নি।');
   await signInWithCustomToken(auth,result.data.token);
   stopRecoveryPolling();sessionStorage.removeItem('df_recovery_request_id');
   const profileSnap=await get(ref(database,'memberUsers/'+(auth.currentUser?.uid||'')));
   const profile=profileSnap.val()||{};
   if(!profileSnap.exists()||profile.status==='deleted')throw new Error('পুরোনো অ্যাকাউন্টটি সক্রিয় নয়।');
   currentMember={uid:auth.currentUser.uid,name:profile.name||request.name||'সদস্য',phone:profile.phone||request.phone};
   localStorage.setItem('df_global_member',JSON.stringify(currentMember));
   window.dispatchEvent(new CustomEvent('df-member-login',{detail:currentMember}));
   if($('memberLoginButton')){$('memberLoginButton').innerHTML='👤 <span>আমার প্রোফাইল</span>';$('memberLoginButton').classList.add('ms-logged');}
   $('memberLoginModal').hidden=true;startNotifications(currentMember.uid);
   if(out){out.style.color='#176b4b';out.textContent='🎉 সফল! আপনার পুরোনো অ্যাকাউন্টে লগইন হয়েছে।';}
   if(redirectParams.get('authRequired')==='1')finishLoginRedirect();
   else setTimeout(()=>{location.href='profile.html';},700);
  }catch(err){console.error('Approved recovery login failed',err);if(out){out.style.color='#b42318';out.textContent='অনুমোদন হয়েছে, কিন্তু লগইন সম্পন্ন হয়নি। Firebase Functions deploy এবং permissions পরীক্ষা করুন।';}}
  finally{recoveryCompleting=false;}
 },err=>{console.error('Recovery status listener failed',err);});
}
function renderNotifications(items){const box=$('msNotificationList'); if(!box)return; if(!items.length){box.innerHTML='<div class="ms-empty">এখনো কোনো নোটিফিকেশন নেই। নতুন নোটিশ এলে এখানে দেখা যাবে।</div>';return;} box.innerHTML=items.sort((a,b)=>(b.createdAt||0)-(a.createdAt||0)).map(n=>`<article class="ms-notice-item"><strong>${esc(n.title||'ধন্যবাদ ফাউন্ডেশন')}</strong><p>${esc(n.message||'')}</p><small>${n.createdAt?esc(new Date(n.createdAt).toLocaleString('bn-BD')):''}</small></article>`).join('');}
function startNotifications(uid){if(notificationUnsub)notificationUnsub();if(broadcastUnsub)broadcastUnsub();$('msMemberGreeting').textContent=`স্বাগতম, ${currentMember?.name||'সদস্য'}!`;
 let personal=[],broadcast=[];const refresh=()=>renderNotifications([...personal,...broadcast]);
 notificationUnsub=onValue(ref(database,'memberNotifications/'+uid),s=>{personal=[];if(s.exists())s.forEach(c=>personal.push({id:c.key,...(c.val()||{})}));refresh();},()=>{});
 broadcastUnsub=onValue(ref(database,'memberBroadcasts'),s=>{broadcast=[];if(s.exists())s.forEach(c=>broadcast.push({id:c.key,...(c.val()||{})}));refresh();},()=>{});
 $('memberLoginButton').title='আপনার প্রোফাইল খুলুন';
}
injectUI();
// Protected-section redirects return to the homepage and open the existing login modal.
if(redirectParams.get('authRequired')==='1') {
 let hasValidStoredMember=false;
 try{const m=JSON.parse(localStorage.getItem('df_global_member')||'null');hasValidStoredMember=!!(m&&m.uid&&m.phone);}catch{}
 if(!hasValidStoredMember){
  const notice=$('msAuthRequiredNotice'), modal=$('memberLoginModal');
  if(notice) notice.hidden=false;
  if(modal) modal.hidden=false;
  setTimeout(()=>$('msName')?.focus(),80);
 }
}
onAuthStateChanged(auth,async user=>{
 if(!user)return;
 const pendingRecovery=sessionStorage.getItem('df_recovery_request_id');if(pendingRecovery&&!recoveryPollTimer)startRecoveryPolling(pendingRecovery);
 try{const snap=await get(ref(database,'memberUsers/'+user.uid));if(!snap.exists())return;const d=snap.val()||{};if(d.status==='deleted'||!d.phone)return;currentMember={uid:user.uid,name:d.name||'সদস্য',phone:d.phone};localStorage.setItem('df_global_member',JSON.stringify(currentMember));window.dispatchEvent(new CustomEvent('df-member-login',{detail:currentMember}));if($('memberLoginButton')){$('memberLoginButton').innerHTML='👤 <span>আমার প্রোফাইল</span>';$('memberLoginButton').classList.add('ms-logged');startNotifications(user.uid);} if(redirectParams.get('authRequired')==='1')finishLoginRedirect();}
 catch(e){console.warn('Could not restore member session',e);}
});
