(function(){
  var N=16,S=20,cv=document.getElementById('c'),ctx=cv.getContext('2d');
  var scoreEl=document.getElementById('score'),menuBestEl=document.getElementById('menuBest');
  var menuBestApplesEl=document.getElementById('menuBestApples');
  var applesCountEl=document.getElementById('applesCount'),menuApplesEl=document.getElementById('menuApples');
  var finalApplesEl=document.getElementById('finalApples'),finalGameApplesEl=document.getElementById('finalGameApples');
  var shopApplesEl=document.getElementById('shopApples');
  var lvlEl=document.getElementById('lvl'),msg=document.getElementById('msg');
  var statScores=document.getElementById('stat-scores'),statTitle=document.getElementById('stat-title'),homeBtn=document.getElementById('homeBtn');
  var menuOverlay=document.getElementById('menuOverlay'),overOverlay=document.getElementById('overOverlay'),shopOverlay=document.getElementById('shopOverlay');
  var pauseOverlay=document.getElementById('pauseOverlay'),pauseBtn=document.getElementById('pauseBtn');
  var resumeBtn=document.getElementById('resumeBtn'),pauseRestartBtn=document.getElementById('pauseRestartBtn'),pauseMenuBtn=document.getElementById('pauseMenuBtn');
  var settingsOverlay=document.getElementById('settingsOverlay');
  var finalScoreEl=document.getElementById('finalScore'),newRecordMsg=document.getElementById('newRecordMsg'),overReason=document.getElementById('overReason');
  var newAppleRecordMsg=document.getElementById('newAppleRecordMsg');
  var helper3BonusMsg=document.getElementById('helper3BonusMsg');
  var padContainer=document.getElementById('padContainer'),padToggle=document.getElementById('padToggle'),soundToggle=document.getElementById('soundToggle');
  var revive150Btn=document.getElementById('revive150Btn'),revive500Btn=document.getElementById('revive500Btn');
  var reviveSection=document.getElementById('reviveSection'),powerChoiceSection=document.getElementById('powerChoiceSection');
  var choice1Btn=document.getElementById('choice1'),choice2Btn=document.getElementById('choice2');
  var fpsSelect=document.getElementById('fpsSelect');
  var graphicsQualitySelect=document.getElementById('graphicsQualitySelect');
  var graphicsQuality='medium';
  var shopBtn=document.getElementById('shopBtn'),closeShopBtn=document.getElementById('closeShopBtn');
  var settingsBtn=document.getElementById('settingsBtn'),closeSettingsBtn=document.getElementById('closeSettingsBtn'),resetSkinBtn=document.getElementById('resetSkinBtn');
  var nightmareToggleBtn=document.getElementById('nightmareToggleBtn'),darkModeToggleBtn=document.getElementById('darkModeToggleBtn');
  var nightmareBadge=document.getElementById('nightmareBadge');
  var buySkin1Btn=document.getElementById('buySkin1'),buySkin2Btn=document.getElementById('buySkin2');
  var tabSkins=document.getElementById('tabSkins'),tabHelpers=document.getElementById('tabHelpers');
  var skinsList=document.getElementById('skinsList'),helpersList=document.getElementById('helpersList');
  var buyHelper1Btn=document.getElementById('buyHelper1'),buyHelper2Btn=document.getElementById('buyHelper2');
  var buyHelper3Btn=document.getElementById('buyHelper3'),buyHelper4Btn=document.getElementById('buyHelper4');
  var menuAdventureBtn=document.getElementById('menuAdventure'),storyOverlay=document.getElementById('storyOverlay');
  var storyChapterTitle=document.getElementById('storyChapterTitle'),storyProgress=document.getElementById('storyProgress');
  var storyDescription=document.getElementById('storyDescription'),storyObjective=document.getElementById('storyObjective');
  var storyStartBtn=document.getElementById('storyStartBtn'),storyBackBtn=document.getElementById('storyBackBtn');
  var adventureCompleteOverlay=document.getElementById('adventureCompleteOverlay');
  var adventureCompleteTitle=document.getElementById('adventureCompleteTitle'),adventureCompleteText=document.getElementById('adventureCompleteText');
  var adventureRewardText=document.getElementById('adventureRewardText'),adventureNextBtn=document.getElementById('adventureNextBtn');
  var adventureMenuBtn=document.getElementById('adventureMenuBtn'),gameModeLabel=document.getElementById('gameModeLabel');
  var accountNameInput=document.getElementById('accountNameInput'),saveAccountBtn=document.getElementById('saveAccountBtn');
  var accountStatus=document.getElementById('accountStatus'),userAccountBadge=document.getElementById('userAccountBadge');
  var exportSaveBtn=document.getElementById('exportSaveBtn'),importSaveBtn=document.getElementById('importSaveBtn'),importSaveInput=document.getElementById('importSaveInput');
  var tabBoost=document.getElementById('tabBoost'),boostList=document.getElementById('boostList');
  var buyShieldBtn=document.getElementById('buyShieldBtn'),buyH1UpBtn=document.getElementById('buyH1UpBtn'),shieldStockEl=document.getElementById('shieldStock');
  var tabCharge=document.getElementById('tabCharge'),chargeList=document.getElementById('chargeList');
  var buySlowBtn=document.getElementById('buySlowBtn'),slowStockEl=document.getElementById('slowStock');
  var buyFarmerUpBtn=document.getElementById('buyFarmerUpBtn'),buyLootUpBtn=document.getElementById('buyLootUpBtn'),buyWizUpBtn=document.getElementById('buyWizUpBtn');
  var buyPack1Btn=document.getElementById('buyPack1Btn'),buyPack5Btn=document.getElementById('buyPack5Btn'),watchAdShopBtn=document.getElementById('watchAdShopBtn');
  var chargeStatusEl=document.getElementById('chargeStatus'),chargeNoteEl=document.getElementById('chargeNote');
  var pregameOverlay=document.getElementById('pregameOverlay'),pregameShieldBtn=document.getElementById('pregameShieldBtn'),pregameSlowBtn=document.getElementById('pregameSlowBtn');
  var pregameStartBtn=document.getElementById('pregameStartBtn'),pregameBackBtn=document.getElementById('pregameBackBtn');
  var buyHelper5Btn=document.getElementById('buyHelper5'),buyPowerUpBtn=document.getElementById('buyPowerUpBtn'),effBarEl=document.getElementById('effBar');
  var musicOnChk=document.getElementById('musicOnChk'),musicVolRange=document.getElementById('musicVolRange'),sfxOnChk=document.getElementById('sfxOnChk'),sfxVolRange=document.getElementById('sfxVolRange');
  var mangoCountEl=document.getElementById('mangoCount'),menuMangoesEl=document.getElementById('menuMangoes'),shopMangoesEl=document.getElementById('shopMangoes'),gameMangoMsg=document.getElementById('gameMangoMsg');
  var zoneLabelEl=document.getElementById('zoneLabel');
  var fpsValueEl=document.getElementById('fpsValue'),fpsSettingsValueEl=document.getElementById('fpsSettingsValue');
  var reviveAdBtn=document.getElementById('reviveAdBtn'),adStatusEl=document.getElementById('adStatus');


  var DIFF={easy:{speed:170,every:2,walls:false},normal:{speed:130,every:1,walls:false},hard:{speed:100,every:1,walls:true}};
  var ADV_GOAL=10,ADV_LEVELS=10,LEVEL_REWARD=15;
  var CHAPTERS=[
    {name:'صحوة الغابة',diff:'easy',reward:150,
     story:'كان الثعبان يعيش سعيدًا مع حبيبته الثعبانة الوردية، حتى جاء الثعبان الأسود في ليلة مظلمة وخطفها وهرب بها. أقسم البطل أن يعيدها مهما كان الثمن، وبدأ رحلته من الغابة. اجمع 10 تفاحات في كل ليفل لتزداد قوتك.',
     bossName:'العقرب الحجري',bossEmoji:'🦂',bossNeed:3,throwEvery:2400,fall:150,moveMs:230,bigEvery:4000,bigFall:190,
     bossStory:'العقرب الحجري يرمي حجارة صغيرة، وكل 4 ثوانٍ يرمي حجرًا ضخمًا يغطي 3 مربعات! بعد 30 ثانية يظهر حرف B، اجمع 3 حروف B لتدمير الزعيم.',
     outro:'تحطّم العقرب الحجري وانفتح طريق الكهف. أثر الثعبانة الوردية يقودك إلى الأمام!'},
    {name:'كهف الصخور',diff:'hard',reward:220,
     story:'في عمق الكهف وجد البطل وشاحًا يخص الثعبانة الوردية. الثعبان الأسود مرّ من هنا! جدران الكهف قاتلة هنا (الصعوبة صعبة)، فانتبه.',
     bossName:'عملاق الكهف',bossEmoji:'👹',bossNeed:4,throwEvery:2300,fall:130,moveMs:190,poolEvery:5000,
     bossStory:'عملاق الكهف يرمي برَكًا تغطي اللوحة طولًا كل 5 ثوانٍ وتختفي بعد 10 ثوانٍ، وتبطّئ ثعبانك! الصعوبة صعبة والجدران قاتلة. اجمع 4 حروف B بعد 30 ثانية.',
     outro:'سقط عملاق الكهف! سمعت من بعيد صدى صوت الثعبانة الوردية تنادي من وادي العواصف.'},
    {name:'وادي العواصف',diff:'normal',reward:300,
     story:'الرياح تعصف في الوادي وقوى غامضة تظهر في كل مكان. اجمع التفاح واستفد من القوى قبل أن تختفي.',
     bossName:'تنين العاصفة',bossEmoji:'🐲',bossNeed:7,throwEvery:0,fall:115,moveMs:160,dashEvery:3000,
     bossStory:'تنين العاصفة يندفع نحوك كل 3 ثوانٍ على طول الصف أو العمود كله! اخرج من الخط الأحمر قبل أن يصل. اجمع 7 حروف B بعد 30 ثانية.',
     outro:'هدأت العاصفة بعد سقوط التنين، وظهرت قلعة سوداء على الأفق. هناك يحتجزون الثعبانة الوردية!'},
    {name:'قلعة الظلال',diff:'normal',reward:420,
     story:'وصلت إلى قلعة الثعبان الأسود. الجليد يغطي الممرات والبرد يشتد، فاحذر كل حركة وأنت تقترب من حبيبتك.',
     bossName:'فارس الظلال',bossEmoji:'💀',bossNeed:9,throwEvery:0,fall:100,moveMs:130,iceEvery:6000,
     bossStory:'فارس الظلال يحاول تجميدك ثم يرميك بحجر الثلج! كل 6 ثوانٍ تظهر 4 خطوط جليد عشوائية (أفقية أو عمودية). إن تجمّدت اضغط الأسهم بسرعة لتكسر الجليد. اجمع 9 حروف B بعد 30 ثانية.',
     outro:'سقط فارس الظلال وانفتحت البوابة الأخيرة. الثعبان الأسود ينتظرك في عرينه!'},
    {name:'عرين الثعبان الأسود',diff:'hard',reward:700,
     story:'هذا هو العرين الأخير. الثعبانة الوردية سجينة في الداخل، والثعبان الأسود يعرف أنك قادم. لا مجال للتراجع.',
     bossName:'الثعبان الأسود',bossEmoji:'🐍',bossNeed:20,throwEvery:1800,fall:95,moveMs:110,strikeEvery:10000,dark:true,
     bossStory:'الثعبان الأسود يُغرق العرين في الظلام ويرمي 3 أحجار كبيرة تغطي اللوحة كلها! الطريق الوحيد للنجاة هو حرف G الذي يظهر قبل الضربة، التقطه قبل أن تموت. اجمع 20 حرف B بعد 30 ثانية.',
     outro:'انكسر ختم الثعبان الأسود وتحررت الثعبانة الوردية! عادا معًا إلى الغابة، وعاد النور إلى العالم.'}
  ];
  var SNAKE_COLORS=[
    {id:'green',n:'أخضر',c:'#2d8a2d'},{id:'blue',n:'أزرق',c:'#2f80ed',h:'#1f5fbf',s:'#8bbcff'},
    {id:'red',n:'أحمر',c:'#d62828',h:'#a31515',s:'#ff8a8a'},{id:'purple',n:'بنفسجي',c:'#8e44ad',h:'#5a2a8c',s:'#d2a8f0'},
    {id:'orange',n:'برتقالي',c:'#f08a00',h:'#b85c00',s:'#ffd08a'},{id:'pink',n:'وردي',c:'#ec407a',h:'#c2185b',s:'#ffb3cf'},
    {id:'cyan',n:'سماوي',c:'#00acc1',h:'#007c91',s:'#8ceaf5'},{id:'yellow',n:'أصفر',c:'#e6c200',h:'#b59b00',s:'#fff3a0'},
    {id:'white',n:'أبيض',c:'#eceff1',h:'#b0bec5',s:'#ffffff'}
  ];
  // ===== المناطق: عادية 55% (كلاسيكي فقط) · كهف مظلم 20% · حمام البراكين 15% · صحراء 10% =====
  var ZONE_INFO={
    normal:{n:'المنطقة العادية',i:'🌿',tint:null,track:'game',w:53},
    cave:{n:'الكهف المظلم',i:'🕳️',tint:'rgba(0,0,0,0.28)',track:'cave',w:20},
    volcano:{n:'حمام البراكين',i:'🌋',tint:'rgba(150,30,0,0.22)',track:'volcano',w:15},
    desert:{n:'الصحراء',i:'🏜️',tint:'rgba(230,190,110,0.40)',track:'desert',w:10},
    ice:{n:'المنطقة الجليدية',i:'❄️',tint:'rgba(150,210,255,0.30)',track:'ice',w:2}
  };
  // مناطق فصول المغامرة (الفصل كله): 1 عادية · 2 صحراء · 3 براكين · 4 جليد · 5 عادية (والزعيم الأخير في الكهف المظلم)
  var CHAPTER_ZONES=['normal','desert','volcano','ice','normal'];
  var ICE_SLOW=1.8,ICE_CUBE_EVERY=5000,ICE_CUBE_LIFE=10000,ICE_CUBES_PER_WAVE=3,ICE_MANGO_CHANCE=0.88,ICE_MANGO_EVERY=5;
  var iceCubes=[],iceT=0;
  var ZONE_EVERY=5,DESERT_HAZE=0.30;
  var zone='normal',advZoneBlock=-1,advZone='cave';
  function rollZone(includeNormal){
    var keys=Object.keys(ZONE_INFO).filter(function(k){return includeNormal||k!=='normal';});
    var total=keys.reduce(function(a,k){return a+ZONE_INFO[k].w;},0),r=Math.random()*total;
    for(var i=0;i<keys.length;i++){r-=ZONE_INFO[keys[i]].w;if(r<0)return keys[i];}
    return keys[keys.length-1];
  }
  var snakeColor='green',adventureLevel=0,boss=null;
  var controlMode='both',swipeThreshold=20,dirQueue=[];
  var controlSelect=document.getElementById('controlSelect'),swipeSelect=document.getElementById('swipeSelect');
  var diffKey='normal',best=0,bestApples=0,apples=0,soundOn=true,padVisible=true,inGame=false,paused=false;
  var currentFps=60,targetFpsInterval=1000/60;
  var accountProfile={name:'',id:'',createdAt:0};
  var gameMode='classic',adventureChapter=0,adventureFinished=false;
  var shieldCharges=0,mangoes=0,shieldStock=0,slowStock=0,h1Up=false,farmerUp=false,lootUp=false,wizUp=false,powerUp=false;
  var gameMangoesEarned=0,h2Count=0,frozenT=0,mg=null;
  var pendingShield=false,pendingSlow=false,pregameStartFn=null,choiceShield=true,choiceSlow=true;
  var pendingPurchase=null,rewardPurpose='revive';
  var activeSkin='default';
  var unlockedSkins={default:true, skin1:false, skin2:false, old:false, small:false, black:false, invisible:false, strong:false};
  var unlockedHelpers={h1:false, h2:false, h3:false, h4:false, h5:false};
  
  // مساعد واحد فقط يمكن تجهيزه واستخدامه في الجيم (null أو 'h1' أو 'h2' أو 'h3' أو 'h4')
  var activeHelper = null;
  var developerMode=false;

  var nightmareMode=false;
  var darkMode=false;
  var hasUsedRewardedRevive=false;
  var gameApplesEarned=0;
  var h1Timer=0, h2Timer=0, h4Timer=0;
  var fpsFrameCount=0,fpsWindowStart=0,measuredFps=0,rewardAdPending=false;

  function bestKey(){return 'snakeBest_'+diffKey+(nightmareMode?'_nm':'')}
  function bestApplesKey(){return 'snakeBestApples_'+diffKey+(nightmareMode?'_nm':'')}

  function updateAccountUI(){
    var name=(accountProfile&&accountProfile.name)||'';
    if(accountNameInput)accountNameInput.value=name;
    if(userAccountBadge){
      userAccountBadge.textContent=name?'👤 '+name:'';
      userAccountBadge.style.display=name?'inline-block':'none';
    }
    if(accountStatus)accountStatus.textContent=name?'تم حفظ ملف اللاعب محليًا باسم '+name+'.':'اللعب كضيف على هذا الجهاز.';
  }

  function isRewardedAdReady(){
    var bridge=window.SnakeAds||window.AndroidAds;
    return !!(bridge&&(typeof bridge.showRewardedAd==='function'||typeof bridge.showRewarded==='function'));
  }
  function updateAdStatus(){
    var ready=isRewardedAdReady();
    if(adStatusEl)adStatusEl.textContent=ready?'الإعلان المكافئ متصل عبر تطبيق Android.':'الإعلانات غير مهيأة: اربط AdMob في مشروع Android لتفعيل المكافأة.';
    if(reviveAdBtn){
      reviveAdBtn.disabled=!ready||hasUsedRewardedRevive;
      reviveAdBtn.textContent=hasUsedRewardedRevive?'✅ استُخدم إعلان الإحياء في هذه الجولة':(ready?'🎬 مشاهدة إعلان مكافأة للإحياء':'🎬 إعلان الإحياء غير متاح');
    }
    updateChargeUI();
  }
  function handleRewardedAdResult(earned){
    if(!rewardAdPending)return;
    rewardAdPending=false;
    var purpose=rewardPurpose;
    if(purpose==='shop'){
      if(earned){
        apples+=100;mangoes+=5;saveData();
        if(chargeNoteEl)chargeNoteEl.textContent='🎉 اكتمل الإعلان! حصلت على +100 🍎 و +5 🥭.';
        sfx('coins');
      }else{
        if(chargeNoteEl)chargeNoteEl.textContent='لم يكتمل الإعلان؛ لم تُمنح المكافأة.';
      }
      updateAdStatus();
      return;
    }
    updateAdStatus();
    if(earned){
      hasUsedRewardedRevive=true;
      msg.textContent='🎉 اكتملت مشاهدة الإعلان! تم إحياؤك.';
      updateAdStatus();
      reviveGame(null);
    }else{
      if(adStatusEl)adStatusEl.textContent='لم يكتمل الإعلان؛ لم تُمنح مكافأة الإحياء.';
      if(reviveAdBtn)reviveAdBtn.disabled=false;
    }
  }
  // يستدعيه جسر Android بعد معرفة نتيجة الإعلان المكافئ.
  window.onSnakeRewardedAdResult=handleRewardedAdResult;

  function showRewardedAd(purpose){
    purpose=(purpose==='shop')?'shop':'revive';
    if(!isRewardedAdReady()||rewardAdPending||(purpose==='revive'&&hasUsedRewardedRevive)){updateAdStatus();return;}
    rewardPurpose=purpose;
    var bridge=window.SnakeAds||window.AndroidAds;
    var show=bridge.showRewardedAd||bridge.showRewarded;
    rewardAdPending=true;
    if(purpose==='revive'){
      if(reviveAdBtn){reviveAdBtn.disabled=true;reviveAdBtn.textContent='⏳ جاري تحميل الإعلان...';}
      if(adStatusEl)adStatusEl.textContent='جارٍ طلب الإعلان المكافئ...';
    }else{
      if(chargeNoteEl)chargeNoteEl.textContent='⏳ جاري تحميل الإعلان...';
      if(watchAdShopBtn)watchAdShopBtn.disabled=true;
    }
    try{
      var result=show.call(bridge);
      if(result&&typeof result.then==='function'){
        result.then(function(value){handleRewardedAdResult(value===true||!!(value&&value.rewarded));})
          .catch(function(){handleRewardedAdResult(false);});
      }else if(typeof result==='boolean'){
        handleRewardedAdResult(result);
      }
      // إذا أعاد الجسر undefined فسيُنتظر callback: window.onSnakeRewardedAdResult(true/false).
    }catch(e){handleRewardedAdResult(false);}
  }

  // ===== الشراء بالمال الحقيقي (Google Play Billing عبر جسر Android) =====
  var PACKS=[
    {id:'pack_1usd',apples:600,mangoes:30,btn:buyPack1Btn},
    {id:'pack_5usd',apples:3000,mangoes:150,btn:buyPack5Btn}
  ];
  function getBillingBridge(){return window.SnakeBilling||window.AndroidBilling;}
  function isBillingReady(){var b=getBillingBridge();return !!(b&&typeof b.purchase==='function');}
  function updateChargeUI(){
    if(!chargeStatusEl)return;
    var billing=isBillingReady(),ads=isRewardedAdReady();
    chargeStatusEl.textContent=(billing?'الدفع متصل عبر Google Play. ':'الشراء بالمال الحقيقي غير مفعّل في نسخة الويب (يتطلب Google Play Billing في تطبيق Android). ')
      +(ads?'الإعلان المكافئ جاهز.':'الإعلان المكافئ غير مهيأ (يتطلب AdMob).');
    PACKS.forEach(function(pk){pk.btn.disabled=!billing||!!pendingPurchase;});
    watchAdShopBtn.disabled=!ads||rewardAdPending;
  }
  function handlePurchaseResult(productId,ok){
    if(!pendingPurchase||pendingPurchase!==productId)return;
    pendingPurchase=null;
    var pack=PACKS.filter(function(pk){return pk.id===productId;})[0];
    if(ok&&pack){
      apples+=pack.apples;mangoes+=pack.mangoes;saveData();
      chargeNoteEl.textContent='✅ تم الشراء بنجاح: +'+pack.apples+' 🍎 و +'+pack.mangoes+' 🥭';
      sfx('coins');
    }else{
      chargeNoteEl.textContent='لم تكتمل عملية الشراء؛ لم تُضف أي مكافأة.';
    }
    updateChargeUI();
  }
  // يستدعيه جسر Android بعد تأكيد Google Play للشراء: window.onSnakePurchaseResult('pack_1usd', true)
  window.onSnakePurchaseResult=handlePurchaseResult;
  function buyPack(pack){
    var bridge=getBillingBridge();
    if(!isBillingReady()||pendingPurchase){updateChargeUI();return;}
    pendingPurchase=pack.id;
    chargeNoteEl.textContent='⏳ جاري فتح نافذة الدفع...';
    updateChargeUI();
    try{
      var result=bridge.purchase(pack.id);
      if(result&&typeof result.then==='function'){
        result.then(function(v){handlePurchaseResult(pack.id,v===true||!!(v&&v.purchased));})
          .catch(function(){handlePurchaseResult(pack.id,false);});
      }else if(typeof result==='boolean'){
        handlePurchaseResult(pack.id,result);
      }
      // إذا أعاد الجسر undefined فسيُنتظر callback: window.onSnakePurchaseResult(productId,true/false).
    }catch(e){handlePurchaseResult(pack.id,false);}
  }
  PACKS.forEach(function(pk){pk.btn.onclick=function(){buyPack(pk);};});
  watchAdShopBtn.onclick=function(){showRewardedAd('shop');};

  function buildColorPickers(){
    ['colorPicker','colorPickerStory'].forEach(function(id){
      var box=document.getElementById(id);if(!box)return;
      box.innerHTML='';
      SNAKE_COLORS.forEach(function(col){
        var b=document.createElement('button');
        b.type='button';b.className='swatch'+(col.id===snakeColor?' on':'');
        b.style.background=col.c;b.title=col.n;b.setAttribute('aria-label','لون '+col.n);
        b.onclick=function(){
          snakeColor=col.id;activeSkin='default';saveData();buildColorPickers();updateShopUI();draw();
          sfx('equip');
        };
        box.appendChild(b);
      });
    });
  }

  function updateStoryUI(){
    var ch=CHAPTERS[Math.min(adventureChapter,CHAPTERS.length-1)];
    if(!ch)return;
    var isBoss=adventureLevel===ADV_LEVELS-1;
    storyChapterTitle.textContent='الفصل '+(adventureChapter+1)+': '+ch.name;
    storyProgress.textContent='الفصل '+(adventureChapter+1)+' من '+CHAPTERS.length+' · الليفل '+(adventureLevel+1)+' من '+ADV_LEVELS+(adventureFinished?' · اكتملت القصة':'');
    if(adventureFinished)storyDescription.textContent='لقد أنقذت الثعبانة الوردية وهزمت الثعبان الأسود! يمكنك إعادة المواجهة الأخيرة للتحدي.';
    else storyDescription.textContent=isBoss?('👹 الزعيم: '+ch.bossName+'. '+ch.bossStory):ch.story;
    if(isBoss)storyObjective.textContent='المهمة: تفادَ هجمات الزعيم، وبعد 30 ث اجمع '+ch.bossNeed+' حرف B (حرف B يدمّر الزعيم فقط). المكافأة: '+ch.reward+' 🍎';
    else storyObjective.textContent='المهمة: اجمع '+ADV_GOAL+' تفاحات للفوز بالليفل. المكافأة: '+(LEVEL_REWARD+adventureChapter*5)+' 🍎';
    storyStartBtn.textContent=adventureFinished?'إعادة المواجهة الأخيرة':(isBoss?'واجه الزعيم':'ابدأ الليفل '+(adventureLevel+1));
  }

  function updateAdventureHUD(){
    if(!gameModeLabel)return;
    if(gameMode==='adventure'){
      gameModeLabel.style.display='inline';
      if(boss)gameModeLabel.textContent='👹 ف'+(adventureChapter+1)+' · B '+boss.got+'/'+boss.need;
      else gameModeLabel.textContent='📖 ف'+(adventureChapter+1)+'-ل'+(adventureLevel+1)+' · '+eaten+'/'+ADV_GOAL;
    }else{
      gameModeLabel.style.display='none';
    }
  }

  function updateCurrencyUI(){
    applesCountEl.textContent=apples;menuApplesEl.textContent=apples+' 🍎';shopApplesEl.textContent=apples;
    mangoCountEl.textContent=mangoes;menuMangoesEl.textContent=mangoes+' 🥭';shopMangoesEl.textContent=mangoes;
  }

  function updateBoostUI(){
    if(!buyShieldBtn)return;
    shieldStockEl.textContent='لديك: '+shieldStock+' 🛡️';
    buyShieldBtn.disabled=mangoes<1;
    slowStockEl.textContent='لديك: '+slowStock+' 🐢';
    buySlowBtn.disabled=mangoes<5;
    [[buyH1UpBtn,h1Up,50],[buyFarmerUpBtn,farmerUp,70],[buyLootUpBtn,lootUp,100],[buyWizUpBtn,wizUp,150],[buyPowerUpBtn,powerUp,170]].forEach(function(u){
      u[0].textContent=u[1]?'تم الشراء ✓':'ترقية · '+u[2]+' 🥭';
      u[0].disabled=u[1]||mangoes<u[2];
    });
  }

  buyShieldBtn.onclick=function(){
    if(mangoes<1){warn('تحتاج 1 🥭 منجة لشراء الدرع.');return;}
    mangoes--;shieldStock++;saveData();sfx('buy');
  };
  buySlowBtn.onclick=function(){
    if(mangoes<5){warn('تحتاج 5 🥭 منجات لشراء تعزيز البطء.');return;}
    mangoes-=5;slowStock++;saveData();sfx('buy');
  };
  function setupUpgrade(btn,isOwned,own,cost,name){
    btn.onclick=function(){
      if(isOwned())return;
      if(mangoes<cost){warn('تحتاج '+cost+' 🥭 منجة لتطوير '+name+'.');return;}
      mangoes-=cost;own();saveData();sfx('buy');
    };
  }
  setupUpgrade(buyH1UpBtn,function(){return h1Up;},function(){h1Up=true;},50,'مُدمّر الصخور');
  setupUpgrade(buyFarmerUpBtn,function(){return farmerUp;},function(){farmerUp=true;},70,'مزارع التفاح');
  setupUpgrade(buyLootUpBtn,function(){return lootUp;},function(){lootUp=true;},100,'حارس الغنائم');
  setupUpgrade(buyWizUpBtn,function(){return wizUp;},function(){wizUp=true;},150,'ساحر القوى');
  setupUpgrade(buyPowerUpBtn,function(){return powerUp;},function(){powerUp=true;},170,'مساعد القوة');

  function applyDarkMode(){
    if(darkMode){
      document.documentElement.setAttribute('data-theme','dark');
      darkModeToggleBtn.textContent='مُفعّل';
      darkModeToggleBtn.style.background='#28a745';
    } else {
      document.documentElement.setAttribute('data-theme','light');
      darkModeToggleBtn.textContent='مُعطل';
      darkModeToggleBtn.style.background='#46553f';
    }
  }
  function applyNightmareUI(){
    if(nightmareMode){
      nightmareToggleBtn.textContent='مُفعّل (2X)';
      nightmareToggleBtn.style.background='#d9534f';
      nightmareBadge.style.display='inline-block';
    } else {
      nightmareToggleBtn.textContent='مُعطل';
      nightmareToggleBtn.style.background='#46553f';
      nightmareBadge.style.display='none';
    }
  }


  function loadData(){
    best=0;try{best=+localStorage.getItem(bestKey())||0}catch(e){}
    bestApples=0;try{bestApples=+localStorage.getItem(bestApplesKey())||0}catch(e){}
    try{apples=+localStorage.getItem('snakeApples')||0}catch(e){}
    try{
      var savedSkins=JSON.parse(localStorage.getItem('snakeSkins')||'null');
      if(savedSkins&&typeof savedSkins==='object'){
        var baseSkins={default:true,skin1:false,skin2:false,old:false,small:false,black:false,invisible:false,strong:false};
        Object.keys(savedSkins).forEach(function(k){baseSkins[k]=!!savedSkins[k];});
        baseSkins.default=true;unlockedSkins=baseSkins;
      }
      var savedActive=localStorage.getItem('snakeActiveSkin');
      if(savedActive) activeSkin=savedActive;
      var savedHelpers=JSON.parse(localStorage.getItem('snakeHelpers')||'null');
      if(savedHelpers&&typeof savedHelpers==='object'){var baseH={h1:false,h2:false,h3:false,h4:false,h5:false};Object.keys(savedHelpers).forEach(function(k){baseH[k]=!!savedHelpers[k];});unlockedHelpers=baseH;}
      
      var savedSingleHelper = localStorage.getItem('snakeSingleActiveHelper');
      if(savedSingleHelper && unlockedHelpers[savedSingleHelper]) {
        activeHelper = savedSingleHelper;
      } else {
        activeHelper = null;
      }


      nightmareMode = localStorage.getItem('snakeNightmare') === 'true';
      darkMode = localStorage.getItem('snakeDarkMode') === 'true';
      var savedProfile=JSON.parse(localStorage.getItem('snakeProfile')||'null');
      if(savedProfile&&typeof savedProfile==='object')accountProfile=savedProfile;
      mangoes=Math.max(0,+localStorage.getItem('snakeMangoes')||0);
      shieldStock=Math.max(0,+localStorage.getItem('snakeShieldStock')||0);
      h1Up=localStorage.getItem('snakeH1Up')==='true';
      slowStock=Math.max(0,+localStorage.getItem('snakeSlowStock')||0);
      farmerUp=localStorage.getItem('snakeFarmerUp')==='true';
      lootUp=localStorage.getItem('snakeLootUp')==='true';
      wizUp=localStorage.getItem('snakeWizUp')==='true';
      powerUp=localStorage.getItem('snakePowerHelperUp')==='true';
      var mo=localStorage.getItem('snakeMusicOn'),so=localStorage.getItem('snakeSfxOn');
      if(mo!==null)musicOn=(mo==='true');
      if(so!==null)sfxOn=(so==='true');
      var mv=parseFloat(localStorage.getItem('snakeMusicVol')),sv=parseFloat(localStorage.getItem('snakeSfxVol'));
      if(!isNaN(mv))musicVol=Math.max(0,Math.min(1,mv));
      if(!isNaN(sv))sfxVol=Math.max(0,Math.min(1,sv));
      adventureChapter=Math.max(0,Math.min(CHAPTERS.length-1,+localStorage.getItem('snakeAdventureChapter')||0));
      adventureFinished=localStorage.getItem('snakeAdventureFinished')==='true';
      adventureLevel=Math.max(0,Math.min(ADV_LEVELS-1,+localStorage.getItem('snakeAdventureLevel')||0));
      var cm=localStorage.getItem('snakeControlMode');
      if(cm==='both'||cm==='swipe'||cm==='pad')controlMode=cm;
      var st=+localStorage.getItem('snakeSwipeThreshold');
      if(st===12||st===20||st===32)swipeThreshold=st;
      var sc=localStorage.getItem('snakeColor');
      if(sc&&SNAKE_COLORS.some(function(x){return x.id===sc;}))snakeColor=sc;
    }catch(e){}
    try{
      currentFps=+localStorage.getItem('snakeFps')||60;
      if([30,60,90,120,144,165,240].indexOf(currentFps)<0)currentFps=60;
      fpsSelect.value=String(currentFps);
      targetFpsInterval=1000/currentFps;
    }catch(e){}
    try{
      var savedQuality=localStorage.getItem('snakeGraphicsQuality');
      if(savedQuality==='low'||savedQuality==='medium'||savedQuality==='high'||savedQuality==='ultra')graphicsQuality=savedQuality;
      if(graphicsQualitySelect)graphicsQualitySelect.value=graphicsQuality;
      applyGraphicsUI();
    }catch(e){}

    applyDarkMode();
    applyNightmareUI();
    buildColorPickers();
    applyControls();
    updateAccountUI();
    updateAdStatus();
    menuBestEl.textContent=best;
    menuBestApplesEl.textContent=bestApples+' 🍎';
    updateCurrencyUI();updateBoostUI();
    updateShopUI();applyAudioUI();refreshDeveloperModeUI();
  }

  function saveData(){
    try{
      localStorage.setItem('snakeApples',apples);
      localStorage.setItem('snakeDeveloperMode',developerMode?'true':'false');
      localStorage.setItem('snakeSkins',JSON.stringify(unlockedSkins));
      localStorage.setItem('snakeActiveSkin',activeSkin);
      localStorage.setItem('snakeHelpers',JSON.stringify(unlockedHelpers));
      localStorage.setItem('snakeSingleActiveHelper', activeHelper || '');
      localStorage.setItem('snakeNightmare',nightmareMode);
      localStorage.setItem('snakeDarkMode',darkMode);
      localStorage.setItem('snakeFps',currentFps);
      localStorage.setItem('snakeProfile',JSON.stringify(accountProfile));
      localStorage.setItem('snakeMangoes',mangoes);
      localStorage.setItem('snakeShieldStock',shieldStock);
      localStorage.setItem('snakeH1Up',h1Up);
      localStorage.setItem('snakeSlowStock',slowStock);
      localStorage.setItem('snakeFarmerUp',farmerUp);
      localStorage.setItem('snakeLootUp',lootUp);
      localStorage.setItem('snakeWizUp',wizUp);
      localStorage.setItem('snakePowerHelperUp',powerUp);
      localStorage.setItem('snakeMusicOn',musicOn);
      localStorage.setItem('snakeSfxOn',sfxOn);
      localStorage.setItem('snakeMusicVol',musicVol);
      localStorage.setItem('snakeSfxVol',sfxVol);
      localStorage.setItem('snakeAdventureChapter',adventureChapter);
      localStorage.setItem('snakeAdventureFinished',adventureFinished);
      localStorage.setItem('snakeAdventureLevel',adventureLevel);
      localStorage.setItem('snakeColor',snakeColor);
      localStorage.setItem('snakeControlMode',controlMode);
      localStorage.setItem('snakeSwipeThreshold',swipeThreshold);
    }catch(e){}
    updateCurrencyUI();updateBoostUI();updateShopUI();
    updateAccountUI();
  }

  var SKINS=[
    {id:'skin1',btn:buySkin1Btn,cost:1000,cur:'a'},
    {id:'skin2',btn:buySkin2Btn,cost:2500,cur:'a'},
    {id:'old',btn:document.getElementById('buySkinOld'),cost:30,cur:'m'},
    {id:'small',btn:document.getElementById('buySkinSmall'),cost:55,cur:'m'},
    {id:'black',btn:document.getElementById('buySkinBlack'),cost:570,cur:'m'},
    {id:'invisible',btn:document.getElementById('buySkinInvisible'),cost:65,cur:'m'},
    {id:'strong',btn:document.getElementById('buySkinStrong'),cost:75,cur:'m'}
  ];
  function skinShields(){return activeSkin==='small'?1:(activeSkin==='black'?3:(activeSkin==='strong'?1:0));}

  function updateShopUI(){
    SKINS.forEach(function(sk){
      if(!sk.btn)return;
      var icon=sk.cur==='m'?' 🥭':' 🍎',bal=sk.cur==='m'?mangoes:apples;
      if(unlockedSkins[sk.id]){
        sk.btn.textContent=(activeSkin===sk.id)?'مُفعّل ✓':'تفعيل';
        sk.btn.disabled=(activeSkin===sk.id);
      }else{
        sk.btn.textContent=sk.cost+icon;
        sk.btn.disabled=bal<sk.cost;
      }
    });

    var helpersListData = [
      {id:'h1', btn:buyHelper1Btn, cost:100},
      {id:'h2', btn:buyHelper2Btn, cost:350},
      {id:'h3', btn:buyHelper3Btn, cost:500},
      {id:'h4', btn:buyHelper4Btn, cost:800},
      {id:'h5', btn:buyHelper5Btn, cost:1200}
    ];
    helpersListData.forEach(function(item){
      if(unlockedHelpers[item.id]){
        var isEquipped = (activeHelper === item.id);
        item.btn.textContent = isEquipped ? 'مُجهّز ✓' : 'تجهيز';
        item.btn.disabled = isEquipped;
        item.btn.style.background = isEquipped ? '#28a745' : '#556b4f';
        item.btn.style.color = '#fff';
      } else {
        item.btn.textContent = item.cost + ' 🍎';
        item.btn.disabled = apples < item.cost;
        item.btn.style.background = '#cfe3a8';
        item.btn.style.color = '#1f2b19';
      }
    });
  }

  function setupHelperBtn(id, btn, cost, name){
    btn.onclick = function(){
      if(unlockedHelpers[id]){
        // تبديل: مساعد واحد فقط يمكن تجهيزه، وإذا ضغطت على المُجهّز يتم إلغاؤه
        activeHelper = (activeHelper === id) ? null : id;
        saveData(); updateShopUI(); sfx('equip');
        return;
      }
      if(apples >= cost){
        apples -= cost;
        unlockedHelpers[id] = true;
        activeHelper = id; // تجهيز المساعد الجديد تلقائياً وإلغاء أي مساعد سابق
        saveData(); updateShopUI(); sfx('buy');
      } else {
        warn('لا توجد تفاحات كافية لشراء ' + name + '! تحتاج ' + cost + ' تفاحة.');
      }
    };
  }
  setupHelperBtn('h1', buyHelper1Btn, 100, 'مُدمّر الصخور');
  setupHelperBtn('h2', buyHelper2Btn, 350, 'مزارع التفاح');
  setupHelperBtn('h3', buyHelper3Btn, 500, 'حارس الغنائم');
  setupHelperBtn('h4', buyHelper4Btn, 800, 'ساحر القوى');
  setupHelperBtn('h5', buyHelper5Btn, 1200, 'مساعد القوة');

  function showShopTab(name){
    skinsList.style.display=(name==='skins')?'flex':'none';
    helpersList.style.display=(name==='helpers')?'flex':'none';
    boostList.style.display=(name==='boost')?'flex':'none';
    chargeList.style.display=(name==='charge')?'flex':'none';
    [[tabSkins,'skins'],[tabHelpers,'helpers'],[tabBoost,'boost'],[tabCharge,'charge']].forEach(function(t){
      var on=(t[1]===name);
      t[0].style.background=on?'#cfe3a8':'#384632';t[0].style.color=on?'#1f2b19':'#fff';
    });
    updateBoostUI();
  }
  tabSkins.onclick=function(){showShopTab('skins');};
  tabHelpers.onclick=function(){showShopTab('helpers');};
  tabBoost.onclick=function(){showShopTab('boost');};
  tabCharge.onclick=function(){showShopTab('charge');updateChargeUI();};

  var developerCodeInput=document.getElementById('developerCodeInput');
  var developerCodeBtn=document.getElementById('developerCodeBtn');
  var developerModeStatus=document.getElementById('developerModeStatus');
  var developerModeOffBtn=document.getElementById('developerModeOffBtn');
  function refreshDeveloperModeUI(){
    if(!developerModeStatus)return;
    developerModeStatus.textContent=developerMode?'🟢 وضع المطوّر مفعّل — عناصر المتجر الداخلية مفتوحة':'🔒 وضع المطوّر غير مفعّل';
    developerModeOffBtn.style.display=developerMode?'block':'none';
    developerCodeBtn.textContent=developerMode?'مفعّل ✓':'تفعيل';
    developerCodeBtn.disabled=developerMode;
  }
  function enableDeveloperMode(){
    developerMode=true;
    apples=999999; mangoes=999999;
    Object.keys(unlockedSkins).forEach(function(k){unlockedSkins[k]=true;});
    unlockedSkins.default=true;
    Object.keys(unlockedHelpers).forEach(function(k){unlockedHelpers[k]=true;});
    if(!activeHelper)activeHelper='h1';
    shieldStock=99; slowStock=99;
    h1Up=true; farmerUp=true; lootUp=true; wizUp=true; powerUp=true;
    saveData(); updateShopUI(); updateBoostUI(); updateCurrencyUI(); updateChargeUI();
    refreshDeveloperModeUI();
    if(developerModeStatus)developerModeStatus.textContent='🟢 تم تفعيل وضع المطوّر وفتح عناصر المتجر الداخلية.';
    if(developerCodeInput)developerCodeInput.value='';
  }
  developerCodeBtn.onclick=function(){
    if(developerMode)return;
    if((developerCodeInput.value||'').trim()==='ASS334489'){
      enableDeveloperMode();
    }else{
      developerModeStatus.textContent='❌ الرمز غير صحيح. حاول مرة أخرى.';
      developerCodeInput.value='';
    }
  };
  developerCodeInput.addEventListener('keydown',function(e){if(e.key==='Enter')developerCodeBtn.click();});
  developerModeOffBtn.onclick=function(){
    developerMode=false; saveData(); refreshDeveloperModeUI();
    if(developerModeStatus)developerModeStatus.textContent='🔒 تم إيقاف وضع المطوّر. العناصر التي فُتحت سابقًا تبقى محفوظة.';
  };
  refreshDeveloperModeUI();

  SKINS.forEach(function(sk){
    if(!sk.btn)return;
    sk.btn.onclick=function(){
      if(unlockedSkins[sk.id]){
        activeSkin=sk.id;saveData();updateShopUI();sfx('equip');return;
      }
      var bal=sk.cur==='m'?mangoes:apples;
      if(bal>=sk.cost){
        if(sk.cur==='m')mangoes-=sk.cost;else apples-=sk.cost;
        unlockedSkins[sk.id]=true;activeSkin=sk.id;
        saveData();updateShopUI();sfx('buy');
      }else{
        warn('رصيدك غير كافٍ! تحتاج '+sk.cost+(sk.cur==='m'?' 🥭 منجة.':' 🍎 تفاحة.'));
      }
    };
  });

  nightmareToggleBtn.onclick=function(){
    nightmareMode = !nightmareMode;
    applyNightmareUI();
    saveData();
    loadData();
    sfx(nightmareMode?'weak':'powerEnd');
  };

  darkModeToggleBtn.onclick=function(){
    darkMode = !darkMode;
    applyDarkMode();
    saveData();
    draw();
    sfx('click');
  };

  resetSkinBtn.onclick=function(){
    activeSkin='default';saveData();updateShopUI();sfx('equip');
  };

  fpsSelect.onchange=function(){
    currentFps=+fpsSelect.value||60;
    targetFpsInterval=1000/currentFps;
    lastRenderTime=0;
    saveData();
    sfx('click');
  };
  if(graphicsQualitySelect)graphicsQualitySelect.onchange=function(){
    graphicsQuality=graphicsQualitySelect.value;
    U_LITE=false;uSlow=0;
    try{localStorage.setItem('snakeGraphicsQuality',graphicsQuality);}catch(e){}
    applyGraphicsUI();draw();sfx('click');
  };

  settingsBtn.onclick=function(){
    menuOverlay.style.display='none';
    settingsOverlay.style.display='flex';
  };
  closeSettingsBtn.onclick=function(){
    settingsOverlay.style.display='none';
    menuOverlay.style.display='flex';
    draw();
  };

  saveAccountBtn.onclick=function(){
    var name=(accountNameInput.value||'').trim().replace(/[<>]/g,'').slice(0,18);
    if(!name){warn('اكتب اسمًا صالحًا للاعب.');return;}
    accountProfile.name=name;
    if(!accountProfile.id)accountProfile.id='local-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,7);
    if(!accountProfile.createdAt)accountProfile.createdAt=Date.now();
    saveData();
    accountStatus.textContent='تم حفظ حساب '+name+' على هذا الجهاز.';
  };
  exportSaveBtn.onclick=function(){
    try{
      var data={};
      for(var i=0;i<localStorage.length;i++){
        var key=localStorage.key(i);
        if(key&&key.indexOf('snake')===0)data[key]=localStorage.getItem(key);
      }
      data.snakeProfile=JSON.stringify(accountProfile);
      var blob=new Blob([JSON.stringify({app:'Snake Adventure',version:2,exportedAt:new Date().toISOString(),data:data},null,2)],{type:'application/json'});
      var url=URL.createObjectURL(blob),a=document.createElement('a');
      a.href=url;a.download='snake-adventure-save.json';document.body.appendChild(a);a.click();a.remove();
      setTimeout(function(){URL.revokeObjectURL(url);},1000);
      accountStatus.textContent='تم تنزيل النسخة الاحتياطية. احتفظ بالملف لنقل تقدمك.';
    }catch(e){warn('تعذر تصدير الحفظ في هذا المتصفح.');}
  };
  importSaveBtn.onclick=function(){importSaveInput.click();};
  importSaveInput.onchange=function(){
    var file=importSaveInput.files&&importSaveInput.files[0];if(!file)return;
    var reader=new FileReader();
    reader.onload=function(){
      try{
        var backup=JSON.parse(reader.result),data=backup&&backup.data;
        if(!data||typeof data!=='object')throw new Error('invalid backup');
        Object.keys(data).forEach(function(key){if(key.indexOf('snake')===0&&typeof data[key]==='string')localStorage.setItem(key,data[key]);});
        loadData();updateShopUI();draw();
        accountStatus.textContent='تم استرجاع النسخة الاحتياطية بنجاح.';
        warn('تم استرجاع تقدم اللعبة.');
      }catch(e){warn('ملف النسخة الاحتياطية غير صالح أو تالف.');}
      importSaveInput.value='';
    };
    reader.onerror=function(){warn('تعذرت قراءة الملف.');importSaveInput.value='';};
    reader.readAsText(file);
  };

  function openAdventureStory(){
    menuOverlay.style.display='none';shopOverlay.style.display='none';settingsOverlay.style.display='none';
    overOverlay.style.display='none';pauseOverlay.style.display='none';adventureCompleteOverlay.style.display='none';
    updateStoryUI();storyOverlay.style.display='flex';
  }
  menuAdventureBtn.onclick=openAdventureStory;
  storyBackBtn.onclick=function(){storyOverlay.style.display='none';menuOverlay.style.display='flex';};
  function startAdventureLevel(){beginGame(doStartAdventure);}
  function doStartAdventure(){
    sfx('start');
    if(adventureFinished){adventureChapter=CHAPTERS.length-1;adventureLevel=ADV_LEVELS-1;}
    var chapter=CHAPTERS[adventureChapter];diffKey=chapter.diff;
    document.querySelectorAll('#diff button').forEach(function(b){b.classList.toggle('on',b.dataset.k===diffKey);});
    gameMode='adventure';storyOverlay.style.display='none';adventureCompleteOverlay.style.display='none';
    statTitle.style.display='none';statScores.style.display='flex';homeBtn.style.display='block';
    inGame=true;reset();go();
    msg.textContent=(adventureLevel===ADV_LEVELS-1)?('👹 '+chapter.bossName+' — تفادَ الهجمات!'):('📖 '+chapter.name+' · ليفل '+(adventureLevel+1)+' — اجمع '+ADV_GOAL+' تفاحات. المنطقة: '+ZONE_INFO[zone].i+' '+ZONE_INFO[zone].n);
  }
  storyStartBtn.onclick=startAdventureLevel;
  adventureNextBtn.onclick=function(){
    adventureCompleteOverlay.style.display='none';
    if(adventureFinished){showMenu();msg.textContent='🏆 أنقذت الثعبانة الوردية وأنهيت القصة بالكامل!';}
    else if(adventureLevel===0||adventureLevel===ADV_LEVELS-1){openAdventureStory();}
    else{startAdventureLevel();}
  };
  adventureMenuBtn.onclick=function(){showMenu();};

  shopBtn.onclick=function(){
    menuOverlay.style.display='none';
    shopOverlay.style.display='flex';
    updateCurrencyUI();
    updateShopUI();updateBoostUI();
  };
  closeShopBtn.onclick=function(){
    shopOverlay.style.display='none';
    menuOverlay.style.display='flex';
    draw();
  };

  // ===== محرك الصوت: مؤثرات بطابع الأركيد + موسيقى تُولَّد برمجيًا =====
  var audioCtx=null,masterGain=null,sfxGain=null,musicGain=null,noiseBuf=null;
  var musicOn=true,sfxOn=true,musicVol=0.5,sfxVol=0.8,audioUnlocked=false;
  function applyVolumes(){
    if(!audioCtx)return;
    sfxGain.gain.value=(soundOn&&sfxOn)?sfxVol:0;
    musicGain.gain.value=(soundOn&&musicOn)?musicVol*0.5:0;
  }
  function getAudioContext(){
    if(!audioCtx){
      var AC=window.AudioContext||window.webkitAudioContext;
      if(AC){
        audioCtx=new AC();
        masterGain=audioCtx.createGain();masterGain.connect(audioCtx.destination);
        sfxGain=audioCtx.createGain();sfxGain.connect(masterGain);
        musicGain=audioCtx.createGain();musicGain.connect(masterGain);
        applyVolumes();
      }
    }
    if(audioCtx&&audioCtx.state==='suspended'&&!document.hidden)audioCtx.resume();
    return audioCtx;
  }
  function toneAt(freq,type,t0,dur,vol,dest,to){
    var ac=audioCtx;if(!ac)return;
    var osc=ac.createOscillator(),g=ac.createGain();
    osc.type=type;osc.frequency.setValueAtTime(freq,t0);
    if(to)osc.frequency.exponentialRampToValueAtTime(Math.max(20,to),t0+dur);
    g.gain.setValueAtTime(0.0001,t0);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002,vol),t0+Math.min(0.01,dur/3));
    g.gain.exponentialRampToValueAtTime(0.0001,t0+dur);
    osc.connect(g);g.connect(dest);
    osc.start(t0);osc.stop(t0+dur+0.03);
  }
  function noiseAt(t0,dur,vol,ftype,f0,f1,dest){
    var ac=audioCtx;if(!ac)return;
    if(!noiseBuf){
      noiseBuf=ac.createBuffer(1,ac.sampleRate,ac.sampleRate);
      var d=noiseBuf.getChannelData(0);for(var i=0;i<d.length;i++)d[i]=Math.random()*2-1;
    }
    var src=ac.createBufferSource();src.buffer=noiseBuf;src.loop=true;
    var f=ac.createBiquadFilter();f.type=ftype||'lowpass';f.frequency.setValueAtTime(f0||1200,t0);
    if(f1)f.frequency.exponentialRampToValueAtTime(Math.max(20,f1),t0+dur);
    var g=ac.createGain();g.gain.setValueAtTime(Math.max(0.0002,vol),t0);g.gain.exponentialRampToValueAtTime(0.0001,t0+dur);
    src.connect(f);f.connect(g);g.connect(dest);
    src.start(t0);src.stop(t0+dur+0.03);
  }
  function tone(freq,type,dur,vol,opt){
    var ac=getAudioContext();if(!ac)return;opt=opt||{};
    toneAt(freq,type||'square',ac.currentTime+(opt.delay||0),dur,vol||0.06,sfxGain,opt.to);
  }
  function noise(dur,vol,opt){
    var ac=getAudioContext();if(!ac)return;opt=opt||{};
    noiseAt(ac.currentTime+(opt.delay||0),dur,vol||0.08,opt.type,opt.freq,opt.to,sfxGain);
  }
  function arp(freqs,type,step,dur,vol){freqs.forEach(function(f,i){tone(f,type,dur,vol,{delay:i*step});});}

  var SFX={
    click:function(){tone(1400,'square',0.03,0.03);},
    turn:function(){tone(380,'square',0.025,0.02,{to:460});},
    eat:function(){tone(660,'square',0.05,0.06);tone(990,'square',0.07,0.06,{delay:0.05});},
    mango:function(){arp([784,988,1319,1568],'triangle',0.06,0.09,0.07);},
    mangoSpawn:function(){arp([880,1175,1568],'triangle',0.06,0.1,0.06);},
    power:function(){tone(400,'square',0.18,0.06,{to:1200});tone(600,'triangle',0.2,0.05,{to:1800,delay:0.06});},
    weak:function(){tone(700,'sawtooth',0.3,0.07,{to:120});noise(0.12,0.05,{freq:800});},
    powerEnd:function(){tone(660,'triangle',0.1,0.05);tone(440,'triangle',0.14,0.05,{delay:0.09});},
    shield:function(){tone(1200,'triangle',0.08,0.08);tone(800,'square',0.18,0.06,{to:300,delay:0.04});noise(0.1,0.06,{type:'highpass',freq:3000});},
    hit:function(){noise(0.25,0.16,{freq:2400,to:200});tone(220,'sawtooth',0.3,0.08,{to:60});},
    over:function(){arp([392,330,262,196],'square',0.18,0.22,0.07);tone(98,'sawtooth',0.6,0.06,{delay:0.7,to:50});},
    win:function(){arp([523,659,784,1047,784,1047,1319],'square',0.09,0.14,0.06);arp([262,330,392,523,392,523,659],'triangle',0.09,0.14,0.05);},
    levelUp:function(){arp([523,659,784,1047],'square',0.07,0.09,0.06);},
    buy:function(){tone(988,'square',0.07,0.06);tone(1319,'square',0.16,0.06,{delay:0.07});},
    equip:function(){tone(520,'triangle',0.08,0.05);tone(780,'triangle',0.1,0.05,{delay:0.06});},
    error:function(){tone(140,'sawtooth',0.18,0.08);tone(110,'sawtooth',0.2,0.08,{delay:0.12});},
    coins:function(){arp([1319,1568,1976],'square',0.07,0.08,0.05);},
    throwStone:function(){noise(0.22,0.07,{type:'bandpass',freq:500,to:1800});},
    bigStone:function(){noise(0.4,0.12,{freq:400,to:100});tone(90,'sawtooth',0.4,0.09,{to:45});},
    splash:function(){noise(0.35,0.09,{type:'bandpass',freq:1500,to:400});tone(500,'sine',0.2,0.05,{to:200});},
    dashWarn:function(){tone(300,'square',0.08,0.05);tone(300,'square',0.08,0.05,{delay:0.14});},
    dash:function(){noise(0.35,0.1,{freq:2500,to:300});tone(160,'sawtooth',0.3,0.08,{to:600});},
    iceWarn:function(){arp([1568,1976,2349],'sine',0.05,0.14,0.04);},
    iceStrike:function(){noise(0.2,0.1,{type:'highpass',freq:3000});tone(2000,'triangle',0.25,0.06,{to:600});},
    freeze:function(){noise(0.3,0.1,{type:'highpass',freq:2500});tone(1200,'sine',0.4,0.07,{to:200});},
    iceTap:function(){tone(1800,'square',0.03,0.05);noise(0.05,0.05,{type:'highpass',freq:4000});},
    unfreeze:function(){tone(500,'square',0.05,0.05,{to:900});noise(0.12,0.08,{type:'highpass',freq:2000});},
    strikeWarn:function(){tone(110,'sawtooth',0.5,0.1,{to:70});tone(220,'square',0.12,0.05,{delay:0.5});tone(220,'square',0.12,0.05,{delay:0.7});},
    strikeFall:function(){noise(0.7,0.14,{freq:600,to:80});tone(70,'sawtooth',0.7,0.1,{to:40});},
    bHit:function(){noise(0.1,0.1,{type:'highpass',freq:3000});tone(880,'square',0.07,0.07);tone(1320,'square',0.12,0.07,{delay:0.06});},
    bAppear:function(){arp([880,1175,1568],'triangle',0.06,0.1,0.06);},
    gGet:function(){arp([988,1319,1760,2093],'sine',0.05,0.14,0.07);},
    revive:function(){arp([262,330,392,523,659],'triangle',0.06,0.1,0.07);},
    helper:function(){tone(600,'triangle',0.08,0.05);tone(900,'triangle',0.1,0.05,{delay:0.07});},
    ghost:function(){tone(500,'sine',0.35,0.05,{to:900});tone(750,'sine',0.35,0.04,{to:350,delay:0.1});},
    slim:function(){tone(700,'triangle',0.2,0.06,{to:350});},
    tick:function(){tone(1000,'square',0.03,0.04);},
    start:function(){arp([392,523,659,784],'square',0.07,0.08,0.05);},
    pause:function(){tone(500,'square',0.06,0.05);tone(350,'square',0.1,0.05,{delay:0.06});},
    resume:function(){tone(350,'square',0.06,0.05);tone(500,'square',0.1,0.05,{delay:0.06});}
  };
  function sfx(name){
    if(!soundOn||!sfxOn)return;
    try{var f=SFX[name];if(f)f();}catch(e){}
  }
  // للتوافق مع النداءات القديمة
  function playTone(freq,type,duration,vol){
    if(!soundOn||!sfxOn)return;
    try{tone(freq,type||'square',duration||0.1,Math.min(0.12,vol||0.05));}catch(e){}
  }
  function warn(m){sfx('error');alert(m);}

  // ----- الموسيقى (3 مقطوعات: القائمة، اللعب، الزعيم) -----
  function NOTE(m){return 440*Math.pow(2,(m-69)/12);}
  var TRACKS={
    menu:{bpm:96,chords:[[60,64,67],[57,60,64],[53,57,60],[55,59,62]],
      arp:[0,null,1,null,2,null,1,null,3,null,2,null,1,null,2,null],arpWave:'triangle',arpVol:0.07,
      melody:[[2,null,null,null,1,null,0,null,1,null,null,null,2,null,3,null],[3,null,2,null,null,null,1,null,2,null,null,null,0,null,null,null],
              [0,null,1,null,2,null,null,null,3,null,2,null,1,null,null,null],[2,null,null,null,3,null,2,null,1,null,0,null,null,null,null,null]],
      leadWave:'square',leadVol:0.035,leadLen:3,bass:[0,8],bassLen:6,kick:[],snare:[],hat:[4,12]},
    game:{bpm:132,chords:[[57,60,64],[53,57,60],[60,64,67],[55,59,62]],
      arp:[0,2,1,2,0,2,1,2,3,5,4,5,3,5,4,5],arpWave:'square',arpVol:0.04,
      melody:[[3,null,null,2,null,4,null,3,null,null,2,null,1,null,2,null],[4,null,3,null,2,null,null,1,null,2,null,3,null,null,null,null],
              [3,null,4,null,3,null,null,2,null,null,3,null,4,null,null,null],[2,null,null,3,null,2,null,null,1,null,2,null,3,null,null,null]],
      leadWave:'square',leadVol:0.05,leadLen:2.2,bass:[0,4,8,12],bassLen:3,kick:[0,8],snare:[4,12],hat:[2,6,10,14]},
    boss:{bpm:150,chords:[[50,53,57],[46,50,53],[48,52,55],[45,49,52]],
      arp:[0,0,3,0,0,0,3,0,1,1,4,1,1,1,4,1],arpWave:'sawtooth',arpVol:0.035,
      melody:[[5,null,null,null,4,null,null,null,3,null,null,null,4,null,5,null],[5,null,4,null,3,null,null,null,2,null,null,null,3,null,null,null],
              [4,null,null,5,null,null,4,null,3,null,null,null,2,null,3,null],[5,null,null,null,5,null,4,null,3,null,2,null,1,null,null,null]],
      leadWave:'square',leadVol:0.045,leadLen:2,bass:[0,2,4,6,8,10,12,14],bassLen:1.6,kick:[0,4,8,12],snare:[4,12],hat:[1,3,5,7,9,11,13,15]}
  };
  // مقطوعات المناطق
  TRACKS.cave={bpm:76,chords:[[45,48,52],[41,45,48],[43,46,50],[40,44,47]],
      arp:[0,null,null,null,2,null,null,null,1,null,null,null,3,null,null,null],arpWave:'sine',arpVol:0.07,
      melody:[[null,null,null,null,null,null,null,null,5,null,null,null,null,null,null,null],[null,null,null,null,4,null,null,null,null,null,null,null,null,null,null,null],
              [null,null,null,null,null,null,null,null,null,null,3,null,null,null,null,null],[5,null,null,null,null,null,null,null,4,null,null,null,null,null,null,null]],
      leadWave:'triangle',leadVol:0.04,leadLen:6,bass:[0,8],bassLen:12,kick:[0],snare:[],hat:[]};
  TRACKS.volcano={bpm:118,chords:[[38,41,44],[37,40,44],[36,39,43],[37,41,44]],
      arp:[0,0,2,0,0,0,2,0,1,1,3,1,1,1,3,1],arpWave:'sawtooth',arpVol:0.035,
      melody:[[5,null,null,null,5,null,4,null,null,null,3,null,null,null,null,null],[4,null,null,null,4,null,3,null,null,null,2,null,null,null,null,null],
              [3,null,null,null,3,null,2,null,null,null,1,null,null,null,null,null],[4,null,5,null,null,null,4,null,3,null,null,null,2,null,null,null]],
      leadWave:'square',leadVol:0.04,leadLen:2.4,bass:[0,3,6,8,11,14],bassLen:2.2,kick:[0,6,8,14],snare:[4,12],hat:[2,6,10,14]};
  TRACKS.desert={bpm:100,chords:[[57,61,64],[58,62,65],[57,61,64],[55,59,62]],
      arp:[0,null,1,2,null,1,null,2,0,null,1,2,null,1,2,null],arpWave:'triangle',arpVol:0.05,
      melody:[[3,null,4,null,3,null,null,2,null,null,1,null,0,null,null,null],[4,null,3,null,2,null,null,1,null,null,0,null,null,null,null,null],
              [3,null,4,null,5,null,null,4,null,null,3,null,2,null,null,null],[2,null,null,1,null,0,null,null,1,null,2,null,null,null,null,null]],
      leadWave:'sawtooth',leadVol:0.028,leadLen:3,bass:[0,6,8],bassLen:4,kick:[0,10],snare:[4,12],hat:[2,6,8,14]};
  TRACKS.ice={bpm:84,chords:[[62,65,69],[58,62,65],[60,64,67],[57,60,64]],
      arp:[3,null,4,null,5,null,4,null,3,null,5,null,4,null,2,null],arpWave:'sine',arpVol:0.06,
      melody:[[null,null,null,null,5,null,null,null,null,null,4,null,null,null,null,null],[null,null,3,null,null,null,null,null,4,null,null,null,null,null,null,null],
              [null,null,null,null,5,null,null,null,null,null,3,null,null,null,null,null],[4,null,null,null,null,null,3,null,null,null,null,null,2,null,null,null]],
      leadWave:'triangle',leadVol:0.035,leadLen:5,bass:[0,8],bassLen:10,kick:[0],snare:[],hat:[4,12]};
  var music={track:null,timer:null,step:0,next:0};
  function playMusicStep(tr,step,t){
    var bar=Math.floor(step/16)%tr.chords.length,st=step%16,ch=tr.chords[bar];
    var spb=60/tr.bpm/4,arpT=[ch[0],ch[1],ch[2],ch[0]+12,ch[1]+12,ch[2]+12];
    var a=tr.arp[st];
    if(a!==null&&a!==undefined)toneAt(NOTE(arpT[a]),tr.arpWave,t,spb*1.5,tr.arpVol,musicGain);
    var mel=tr.melody[bar%tr.melody.length][st];
    if(mel!==null&&mel!==undefined)toneAt(NOTE(ch[mel%3]+12*(1+Math.floor(mel/3))),tr.leadWave,t,spb*tr.leadLen,tr.leadVol,musicGain);
    if(tr.bass.indexOf(st)>=0)toneAt(NOTE(ch[0]-24+((st%8===4)?12:0)),'triangle',t,spb*tr.bassLen,0.16,musicGain);
    if(tr.kick.indexOf(st)>=0)toneAt(150,'sine',t,0.12,0.3,musicGain,45);
    if(tr.snare.indexOf(st)>=0)noiseAt(t,0.1,0.07,'bandpass',1800,null,musicGain);
    if(tr.hat.indexOf(st)>=0)noiseAt(t,0.03,0.03,'highpass',7000,null,musicGain);
  }
  function musicTick(){
    var ac=audioCtx;if(!ac||!music.track)return;
    var tr=TRACKS[music.track],spb=60/tr.bpm/4;
    if(music.next<ac.currentTime)music.next=ac.currentTime+0.05;
    while(music.next<ac.currentTime+0.15){
      playMusicStep(tr,music.step,music.next);
      music.next+=spb;music.step++;
    }
  }
  function stopMusic(){
    if(music.timer){clearInterval(music.timer);music.timer=null;}
    music.track=null;
  }
  function startMusic(name){
    var ac=getAudioContext();if(!ac||!TRACKS[name])return;
    stopMusic();
    music.track=name;music.step=0;music.next=ac.currentTime+0.05;
    music.timer=setInterval(musicTick,40);musicTick();
  }
  function desiredTrack(){
    if(document.hidden)return null;
    if(!inGame)return 'menu';
    if(over_||paused||!running)return null;
    return boss?'boss':(ZONE_INFO[zone]?ZONE_INFO[zone].track:'game');
  }
  function syncMusic(){
    var want=(soundOn&&musicOn&&audioUnlocked)?desiredTrack():null;
    if(want===music.track)return;
    if(want===null){stopMusic();return;}
    startMusic(want);
  }
  function unlockAudio(){
    if(!audioUnlocked){audioUnlocked=true;getAudioContext();}
    else if(audioCtx&&audioCtx.state==='suspended'&&!document.hidden)audioCtx.resume();
    syncMusic();
  }
  ['pointerdown','touchstart','keydown','click'].forEach(function(ev){document.addEventListener(ev,unlockAudio,{passive:true});});
  document.addEventListener('visibilitychange',function(){
    if(audioCtx){try{document.hidden?audioCtx.suspend():audioCtx.resume();}catch(e){}}
    syncMusic();
  });
  // صوت نقرة خفيف لكل الأزرار (ما عدا أسهم التحكم)
  document.addEventListener('click',function(e){
    var b=e.target&&e.target.closest?e.target.closest('button'):null;
    if(b&&!b.closest('.pad'))sfx('click');
  },true);
  setInterval(syncMusic,300);
  function applyAudioUI(){
    if(musicOnChk)musicOnChk.checked=musicOn;
    if(sfxOnChk)sfxOnChk.checked=sfxOn;
    if(musicVolRange)musicVolRange.value=Math.round(musicVol*100);
    if(sfxVolRange)sfxVolRange.value=Math.round(sfxVol*100);
    applyVolumes();
  }
  if(musicOnChk)musicOnChk.onchange=function(){musicOn=musicOnChk.checked;applyVolumes();saveData();syncMusic();};
  if(sfxOnChk)sfxOnChk.onchange=function(){sfxOn=sfxOnChk.checked;applyVolumes();saveData();sfx('eat');};
  if(musicVolRange)musicVolRange.oninput=function(){musicVol=(+musicVolRange.value)/100;applyVolumes();};
  if(musicVolRange)musicVolRange.onchange=function(){saveData();};
  if(sfxVolRange)sfxVolRange.oninput=function(){sfxVol=(+sfxVolRange.value)/100;applyVolumes();};
  if(sfxVolRange)sfxVolRange.onchange=function(){saveData();sfx('eat');};
  function haptic(){if(window.navigator&&window.navigator.vibrate)try{window.navigator.vibrate(15)}catch(e){}}

  var snake,dir,next,food,stones,score,eaten,level,running=false,speed,over_=false,pw=null,effs=[],invisT=0,skinTimer=0,strongSlims=0,slowActive=false;
  var lastFrameTime=0, accumulator=0, frameTick=0;
  var V={u:[0,-1],d:[0,1],l:[-1,0],r:[1,0]};

  function occupied(x,y){
    return snake.some(function(s){return s[0]===x&&s[1]===y})||stones.some(function(s){return s[0]===x&&s[1]===y})||(food&&food[0]===x&&food[1]===y)||(pw&&pw.x===x&&pw.y===y)||(mg&&mg.x===x&&mg.y===y)||iceCubes.some(function(c){return c.x===x&&c.y===y;});
  }
  function placeFood(){
    var x,y;do{x=Math.floor(Math.random()*N);y=Math.floor(Math.random()*N)}while(occupied(x,y));
    food=[x,y];
  }
  function spawnMango(){
    var x,y,t=0;
    do{x=Math.floor(Math.random()*N);y=Math.floor(Math.random()*N);t++;}while(occupied(x,y)&&t<200);
    if(occupied(x,y))return;
    mg={x:x,y:y,life:110};
    msg.textContent='🥭 ظهرت منجة! التقطها بسرعة';sfx('mangoSpawn');
  }
  function placeObstacle(lava){
    var h=snake[0],x,y,t=0;
    do{
      x=Math.floor(Math.random()*N);y=Math.floor(Math.random()*N);t++;
      var near=Math.abs(x-h[0])<=3&&Math.abs(y-h[1])<=3;
    }while((occupied(x,y)||(near&&t<200))&&t<400);
    if(!occupied(x,y))stones.push(lava?[x,y,1]:[x,y]);
  }
  // في حمام البراكين: مع كل حجر تظهر مادة حمراء (حمم) تُنهي اللعبة عند لمسها
  function placeStone(){
    placeObstacle(false);
    if(zone==='volcano')placeObstacle(true);
  }
  function updateZoneUI(){
    if(!zoneLabelEl)return;
    if(inGame){zoneLabelEl.style.display='inline';zoneLabelEl.textContent=ZONE_INFO[zone].i;zoneLabelEl.title=ZONE_INFO[zone].n;}
    else zoneLabelEl.style.display='none';
  }
  // اختيار المنطقة عند بدء الجولة: كلاسيكي = عادية، مغامرة = حسب الفصل (والزعيم الأخير في الكهف المظلم)
  function pickStartZone(){
    iceCubes=[];iceT=0;
    if(gameMode!=='adventure'){zone='normal';return;}
    if(adventureChapter===CHAPTERS.length-1&&adventureLevel===ADV_LEVELS-1){zone='cave';return;}
    zone=CHAPTER_ZONES[adventureChapter]||'normal';
  }
  function baseSpeed(){
    var spd = Math.max(55, DIFF[diffKey].speed - (level-1)*(gameMode==='adventure'?3:8));
    if(nightmareMode) spd = Math.max(28, Math.round(spd / 2));
    return spd;
  }
  function reset(){
    snake=(activeSkin==='small')?[[8,8]]:[[8,8],[7,8],[6,8]];dir=V.r;next=V.r;score=0;eaten=0;level=1;stones=[];food=null;over_=false;pw=null;effs=[];invisT=0;skinTimer=0;strongSlims=0;slowActive=false;
    hasUsedRewardedRevive = false;
    paused=false;dirQueue=[];
    if(pauseOverlay)pauseOverlay.style.display='none';
    gameApplesEarned = 0;
    h1Timer = 0; h2Timer = 0; h4Timer = 0;
    shieldCharges=skinShields();frozenT=0;mg=null;gameMangoesEarned=0;
    if(inGame){
      if(pendingShield&&shieldStock>0){shieldStock--;shieldCharges++;saveData();}
      if(pendingSlow&&slowStock>0){slowStock--;slowActive=true;saveData();}
      pendingShield=false;pendingSlow=false;
    }
    level=(gameMode==='adventure')?adventureLevel+1:1;boss=null;
    pickStartZone();
    speed=baseSpeed();scoreEl.textContent=0;lvlEl.textContent=level;
    if(gameMode==='adventure'&&adventureLevel===ADV_LEVELS-1){initBoss();food=null;}else placeFood();
    updateAdventureHUD();updateZoneUI();updateAdStatus();draw();
  }

  // القوى (خضراء) وقوى الضعف (حمراء)؛ المدة بالمللي ثانية
  var PW={
    slow:{l:'S',i:'🐢',n:'قوة البطء: الثعبان أبطأ',d:8000},
    x2:{l:'2',i:'✖',n:'قوة مضاعفة: النقاط ×2',d:8000},
    ghost:{l:'G',i:'👻',n:'قوة الشبح: تعبر الأحجار',d:6000},
    clear:{l:'C',i:'🧹',n:'قوة التنظيف: أُزيلت الأحجار',d:0},
    shrink:{l:'M',i:'📏',n:'قوة الحجم: عاد الثعبان صغيراً',d:0},
    fast:{l:'S',i:'⚡',n:'⚠️ ضعف السرعة: ثعبانك أسرع بالضعف!',d:7000,bad:true},
    rev:{l:'I',i:'🔄',n:'⚠️ ضعف العكس: حركات ثعبانك معكوسة!',d:7000,bad:true}
  };
  var PK=['slow','x2','ghost','clear','shrink'];
  var WK=['fast','rev'];
  var INV_DIR={u:'d',d:'u',l:'r',r:'l'};
  // مساعد القوة: القوى ×2 (×3 بعد التعزيز) وقوى الضعف ÷2 (÷3 بعد التعزيز)
  function effDuration(t){
    var d=PW[t].d;
    if(activeHelper==='h5'){d=PW[t].bad?d/(powerUp?3:2):d*(powerUp?3:2);}
    return Math.round(d);
  }
  function inPool(){
    if(!boss||!boss.pools||!boss.pools.length)return false;
    var h=snake[0];
    return boss.pools.some(function(pl){return pl.age>=700&&h[0]>=pl.x&&h[0]<pl.x+pl.w;});
  }
  function hasEff(t){return effs.some(function(e){return e.t===t;});}
  function isGhost(){return hasEff('ghost')||invisT>0;}
  function curSpeed(){return Math.round(baseSpeed()*(hasEff('slow')?1.6:1)*(hasEff('fast')?0.5:1)*(activeSkin==='old'?1.3:1)*(slowActive?1/0.75:1)*(inPool()?1.9:1)*(zone==='ice'?ICE_SLOW:1))}
  function spawnPower(){
    var x,y,t=0;do{x=Math.floor(Math.random()*N);y=Math.floor(Math.random()*N);t++}while(occupied(x,y)&&t<200);
    if(occupied(x,y))return;
    var list=(Math.random()<0.35)?WK:PK;
    pw={x:x,y:y,t:list[Math.floor(Math.random()*list.length)],life:70};
  }
  function activate(t, customMsg){
    var p=PW[t];
    msg.textContent = customMsg || p.n;
    sfx(p.bad?'weak':'power');haptic();
    if(t==='clear'){stones=[];iceCubes=[];return}
    if(t==='shrink'){if(snake.length>3){snake=snake.slice(0,3);}return;}
    effs=effs.filter(function(e){return e.t!==t;});
    var dur=effDuration(t);
    effs.push({t:t,left:dur,max:dur});
    speed=curSpeed();updateEffBar();
  }
  // يُنقص الوقت المتبقي للقوى وقوى الضعف (بالمللي ثانية)
  function tickEffects(dt){
    if(!effs.length)return;
    var ended=false;
    effs.forEach(function(e){e.left-=dt;if(e.left<=0)ended=true;});
    if(ended){
      effs=effs.filter(function(e){return e.left>0;});
      msg.textContent='';speed=curSpeed();sfx('powerEnd');
    }
  }
  var lastEffSig='';
  function updateEffBar(){
    if(!effBarEl)return;
    var items=[];
    if(inGame&&!over_){
      effs.forEach(function(e){
        var pp=PW[e.t];
        items.push({c:pp.bad?'bad':'good',txt:pp.i+' '+pp.l+' '+Math.ceil(Math.max(0,e.left)/1000)+'ث',pct:Math.max(0,Math.min(100,e.left/e.max*100))});
      });
      if(invisT>0)items.push({c:'good',txt:'👻 '+Math.ceil(invisT/1000)+'ث',pct:Math.min(100,invisT/3500*100)});
      if(frozenT>0)items.push({c:'bad',txt:'🧊 '+Math.ceil(frozenT/1000)+'ث',pct:Math.min(100,frozenT/2400*100)});
    }
    var sig=items.map(function(i){return i.c+i.txt+Math.round(i.pct/5);}).join('|');
    if(sig===lastEffSig)return;
    lastEffSig=sig;
    effBarEl.innerHTML=items.map(function(i){return '<span class="eff-chip '+i.c+'" style="--p:'+Math.round(i.pct)+'%">'+i.txt+'</span>';}).join('');
  }
  function applyControls(){
    if(controlSelect)controlSelect.value=controlMode;
    if(swipeSelect)swipeSelect.value=String(swipeThreshold);
    padVisible=controlMode!=='swipe';
    padContainer.classList.toggle('hidden',!padVisible);
    padToggle.style.opacity=padVisible?'1':'0.5';
  }
  if(controlSelect)controlSelect.onchange=function(){controlMode=controlSelect.value;applyControls();saveData();sfx('click');};
  if(swipeSelect)swipeSelect.onchange=function(){swipeThreshold=+swipeSelect.value||20;saveData();sfx('click');};

  function setDir(k){
    if(paused||!inGame||over_)return;
    if(frozenT>0){
      frozenT=Math.max(0,frozenT-350);sfx(frozenT<=0?'unfreeze':'iceTap');haptic();
      if(frozenT<=0)msg.textContent='💥 كسرت الجليد!';
      return;
    }
    if(hasEff('rev'))k=INV_DIR[k]||k;
    var d=V[k];if(!d)return;
    var ref=dirQueue.length?dirQueue[dirQueue.length-1]:dir;
    if(d[0]===ref[0]&&d[1]===ref[1])return;
    if(d[0]===-ref[0]&&d[1]===-ref[1])return;
    if(dirQueue.length<2)dirQueue.push(d);
    next=d;sfx('turn');haptic();
    if(!running&&inGame&&!over_)go();
  }
  
  var gameLoopId=null;
  function go(){
    if(running)return;
    if(over_)reset();
    paused=false;pauseOverlay.style.display='none';pauseBtn.style.display=inGame?'flex':'none';
    running=true;msg.textContent='';overOverlay.style.display='none';
    lastFrameTime=performance.now();
    lastRenderTime=lastFrameTime;fpsWindowStart=lastFrameTime;fpsFrameCount=0;
    accumulator=0;
    if(gameLoopId)cancelAnimationFrame(gameLoopId);
    gameLoopId=requestAnimationFrame(mainLoop);
  }

  function pauseGame(){
    if(!inGame||!running||over_)return;
    running=false;paused=true;sfx('pause');
    if(gameLoopId)cancelAnimationFrame(gameLoopId);
    pauseOverlay.style.display='flex';
    pauseBtn.textContent='▶';pauseBtn.setAttribute('aria-label','استكمال اللعب');
    msg.textContent='';
    draw();
  }

  function resumeGame(){
    sfx('resume');
    if(!inGame||!paused||over_)return;
    paused=false;pauseOverlay.style.display='none';pauseBtn.textContent='⏸';
    pauseBtn.setAttribute('aria-label','إيقاف مؤقت');
    running=true;lastFrameTime=performance.now();lastRenderTime=lastFrameTime;fpsWindowStart=lastFrameTime;fpsFrameCount=0;accumulator=0;
    if(gameLoopId)cancelAnimationFrame(gameLoopId);
    gameLoopId=requestAnimationFrame(mainLoop);
  }

  function togglePause(){if(running)pauseGame();else if(paused)resumeGame();}

  function updateHelpers(dt){
    // المساعد الواحد المُجهّز فقط هو من يعمل
    if(activeHelper === 'h1'){
      h1Timer += dt;
      if(h1Up){
        if(h1Timer >= 20000){
          h1Timer = 0;
          if(stones.length > 0){
            stones = [];
            msg.textContent = '🪨 مُدمّر الصخور أخفى كل الحجارة!';
            sfx('helper');
            setTimeout(function(){ if(running && msg.textContent.indexOf('🪨')===0) msg.textContent=''; }, 1800);
          }
        }
      }else if(h1Timer >= 15000){
        h1Timer = 0;
        if(stones.length > 0){
          var idx = Math.floor(Math.random() * stones.length);
          stones.splice(idx, 1);
          msg.textContent = '🪨 مُدمّر الصخور أزال حجراً!';
          sfx('helper');
          setTimeout(function(){ if(running && msg.textContent.indexOf('🪨')===0) msg.textContent=''; }, 1800);
        }
      }
    } else if(activeHelper === 'h4'){
      h4Timer += dt;
      if(h4Timer >= (wizUp?20000:40000)){
        h4Timer = 0;
        var pool = PK.slice(), picks = [], n = wizUp ? 2 : 1;
        while(n-- > 0 && pool.length){picks.push(pool.splice(Math.floor(Math.random()*pool.length),1)[0]);}
        picks.forEach(function(pk){activate(pk);});
        msg.textContent = '⚡ ساحر القوى منحك: ' + picks.map(function(pk){return PW[pk].n.split(':')[0];}).join(' + ');
      }
    }

    // قدرات المظاهر
    if(activeSkin === 'invisible'){
      skinTimer += dt;
      if(skinTimer >= 15000){
        skinTimer = 0;
        if(Math.random() < 0.10){invisT = 3500;msg.textContent = '👻 اختفى الثعبان لثوانٍ!';sfx('ghost');}
      }
      if(invisT > 0){invisT -= dt;if(invisT <= 0){invisT = 0;msg.textContent = '';}}
    } else if(activeSkin === 'strong'){
      skinTimer += dt;
      if(skinTimer >= 20000 && strongSlims < 3 && snake.length > 3){
        skinTimer = 0;strongSlims++;
        snake = snake.slice(0, Math.max(3, snake.length - 3));
        msg.textContent = '💪 الثعبان القوي نحف! (' + strongSlims + '/3)';sfx('slim');
      }
    }
  }

  // ===== معركة الزعيم =====
  function initBoss(){
    var ch=CHAPTERS[adventureChapter];
    boss={need:ch.bossNeed,got:0,elapsed:0,bx:Math.floor(N/2),moveT:0,
      throwT:ch.throwEvery||0,bigT:ch.bigEvery||0,poolT:ch.poolEvery||0,dashT:ch.dashEvery||0,iceT:ch.iceEvery||0,strikeT:ch.strikeEvery?8000:0,
      shots:[],pools:[],dash:null,ice:null,strike:null,
      letter:null,letterT:0,gLetter:null,lastSec:-1,announced:false};
    frozenT=0;
  }
  function shotCells(sh){
    var c=[],i;
    if(sh.big){for(i=-1;i<=1;i++){if(sh.x+i>=0&&sh.x+i<N)c.push([sh.x+i,sh.y]);}}
    else c.push([sh.x,sh.y]);
    return c;
  }
  function shotHit(){
    if(!boss||isGhost())return false;
    for(var i=0;i<boss.shots.length;i++){
      var cells=shotCells(boss.shots[i]);
      for(var k=0;k<cells.length;k++){
        var cx=cells[k][0],cy=cells[k][1];
        if(snake.some(function(g){return g[0]===cx&&g[1]===cy;})){boss.shots.splice(i,1);return true;}
      }
    }
    return false;
  }
  // أحجار الثعبان الأسود الكبيرة الثلاثة (تغطي كل اللوحة) — حرف G وحده ينجّيك
  var BANDS=[[0,4],[5,10],[11,15]];
  function bandHit(){
    if(!boss||!boss.strike||boss.strike.phase!=='fall'||boss.strike.prot)return false;
    var st=boss.strike;
    for(var i=0;i<3;i++){
      var by=Math.floor((st.t-i*250)/70)-1;
      if(by<0)continue;
      for(var k=0;k<snake.length;k++){
        var g=snake[k];
        if(g[0]>=BANDS[i][0]&&g[0]<=BANDS[i][1]&&(g[1]===by||g[1]===by-1))return true;
      }
    }
    return false;
  }
  function iceTouchesSnake(lines){
    return lines.some(function(ln){
      return snake.some(function(g){return ln.axis==='row'?g[1]===ln.idx:g[0]===ln.idx;});
    });
  }
  function spawnLetter(){
    var x,y,t=0;
    do{x=Math.floor(Math.random()*N);y=1+Math.floor(Math.random()*(N-1));t++;}while(occupied(x,y)&&t<300);
    boss.letter={x:x,y:y};boss.letterT=0;
  }
  function updateBoss(dt){
    var ch=CHAPTERS[adventureChapter],i;
    dt=Math.min(dt,100);
    boss.elapsed+=dt;
    if(frozenT>0){frozenT-=dt;if(frozenT<=0){frozenT=0;msg.textContent='';}}

    // الزعيم يتبع عمود رأس الثعبان
    boss.moveT+=dt;
    if(boss.moveT>=ch.moveMs){
      boss.moveT=0;var hx=snake[0][0];
      if(boss.bx<hx)boss.bx++;else if(boss.bx>hx)boss.bx--;
    }

    // حجارة صغيرة
    if(ch.throwEvery){
      boss.throwT-=dt;
      if(boss.throwT<=0){
        boss.shots.push({x:boss.bx,y:1,t:0});boss.throwT=ch.throwEvery;
        sfx('throwStone');
      }
    }
    // الزعيم 1: حجر كبير كل 4 ثوانٍ يغطي 3 مربعات
    if(ch.bigEvery){
      boss.bigT-=dt;
      if(boss.bigT<=0){
        boss.shots.push({x:boss.bx,y:1,t:0,big:true});boss.bigT=ch.bigEvery;
        sfx('bigStone');shk(5);
      }
    }
    // الزعيم 2: برك تغطي العمود كله كل 5 ثوانٍ وتختفي بعد 10 ثوانٍ
    if(ch.poolEvery){
      boss.poolT-=dt;
      if(boss.poolT<=0){
        boss.poolT=ch.poolEvery;
        var px=Math.max(0,Math.min(N-2,snake[0][0]+Math.floor(Math.random()*7)-3));
        boss.pools.push({x:px,w:2,age:0});sfx('splash');
      }
      for(i=boss.pools.length-1;i>=0;i--){
        boss.pools[i].age+=dt;
        if(boss.pools[i].age>=10700)boss.pools.splice(i,1);
      }
    }
    // الزعيم 3: يندفع نحوك على طول الصف أو العمود كل 3 ثوانٍ
    if(ch.dashEvery){
      boss.dashT-=dt;
      if(!boss.dash&&boss.dashT<=0){
        var axis=Math.random()<0.5?'row':'col',hd=snake[0];
        boss.dash={axis:axis,idx:axis==='row'?hd[1]:hd[0],t:0,run:false,pos:0,dir:Math.random()<0.5?1:-1,hit:false};
        boss.dash.pos=boss.dash.dir>0?-1:N;
        boss.dashT=ch.dashEvery;
        sfx('dashWarn');
      }
      var d=boss.dash;
      if(d){
        d.t+=dt;
        if(!d.run){
          if(d.t>=700){d.run=true;sfx('dash');shk(4);}
        }else{
          var oldPos=d.pos;d.pos+=d.dir*dt*(N+2)/420;
          var ca=Math.floor(Math.min(oldPos,d.pos)),cb=Math.floor(Math.max(oldPos,d.pos));
          if(!d.hit&&!isGhost()){
            for(var c=ca;c<=cb;c++){
              if(c<0||c>=N)continue;
              var dx=d.axis==='row'?c:d.idx,dy=d.axis==='row'?d.idx:c;
              if(snake.some(function(g){return g[0]===dx&&g[1]===dy;})){
                d.hit=true;handleCollision('صدمك '+ch.bossName+'!');if(!running)return;break;
              }
            }
          }
          if((d.dir>0&&d.pos>N+1)||(d.dir<0&&d.pos<-2))boss.dash=null;
        }
      }
    }
    // الزعيم 4: 4 خطوط جليد عشوائية كل 6 ثوانٍ؛ من يلمسها يتجمّد ثم يُرمى بحجر ثلج
    if(ch.iceEvery){
      boss.iceT-=dt;
      if(!boss.ice&&boss.iceT<=0){
        var lines=[],used={};
        while(lines.length<4){
          var ax=Math.random()<0.5?'row':'col',ix=Math.floor(Math.random()*N),key=ax+ix;
          if(used[key])continue;used[key]=1;lines.push({axis:ax,idx:ix});
        }
        boss.ice={t:0,phase:'warn',lines:lines};boss.iceT=ch.iceEvery;
        msg.textContent='❄️ ابتعد عن خطوط الجليد الزرقاء!';sfx('iceWarn');
      }
      if(boss.ice){
        var ic=boss.ice;ic.t+=dt;
        if(ic.phase==='warn'&&ic.t>=1300){
          ic.phase='strike';ic.t=0;sfx('iceStrike');shk(6);
          if(!isGhost()&&iceTouchesSnake(ic.lines)){
            frozenT=2400;sfx('freeze');
            boss.shots.push({x:snake[0][0],y:1,t:0,ice:true});
            msg.textContent='🧊 تجمّدت! اضغط الأسهم بسرعة لتكسر الجليد!';haptic();
          }
        }else if(ic.phase==='strike'&&ic.t>=450){boss.ice=null;}
      }
    }
    // الثعبان الأسود: ضربة 3 أحجار كبيرة، وحرف G وحده يحميك
    if(ch.strikeEvery){
      if(!boss.strike){
        boss.strikeT-=dt;
        if(boss.strikeT<=0){
          var gx,gy,tries=0,hh=snake[0];
          do{gx=Math.floor(Math.random()*N);gy=2+Math.floor(Math.random()*(N-2));tries++;}
          while((occupied(gx,gy)||Math.abs(gx-hh[0])+Math.abs(gy-hh[1])<4)&&tries<200);
          boss.strike={phase:'warn',t:0,prot:false};
          boss.gLetter={x:gx,y:gy};
          msg.textContent='⚠️ 3 أحجار كبيرة قادمة! التقط حرف G الآن!';
          sfx('strikeWarn');
        }
      }else{
        var stk=boss.strike;stk.t+=dt;
        if(stk.phase==='warn'){
          if(stk.t>=4200){stk.phase='fall';stk.t=0;boss.gLetter=null;sfx('strikeFall');shk(10);}
        }else{
          if(bandHit()){end('سحقتك أحجار الثعبان الأسود الكبيرة! كان عليك التقاط حرف G.');return;}
          if(stk.t>=70*(N+3)+800){
            boss.strike=null;boss.strikeT=ch.strikeEvery;
            msg.textContent=stk.prot?'🛡️ نجوت من الضربة الكبرى!':'';
          }
        }
      }
    }

    // الحجارة المتساقطة
    for(i=boss.shots.length-1;i>=0;i--){
      var sh=boss.shots[i],fallMs=sh.ice?85:(sh.big?ch.bigFall:ch.fall);
      sh.t+=dt;
      while(sh.t>=fallMs){sh.t-=fallMs;sh.y++;}
      if(sh.y>=N)boss.shots.splice(i,1);
    }
    if(shotHit()){handleCollision('أصابك حجر '+ch.bossName+'!');if(!running)return;}

    // ظهور حرف B بعد 30 ثانية
    if(boss.elapsed<30000){
      var sec=Math.ceil((30000-boss.elapsed)/1000);
      if(sec!==boss.lastSec){
        boss.lastSec=sec;
        if(!boss.strike&&frozenT<=0&&!boss.ice)msg.textContent='⏳ حرف B يظهر بعد '+sec+' ث — تفادَ الهجمات!';
        if(sec<=3)sfx('tick');
      }
    }else{
      if(!boss.announced){boss.announced=true;msg.textContent='🔤 ظهر حرف B! اجمع '+boss.need+' حروف لتدمير الزعيم.';sfx('bAppear');}
      if(!boss.letter)spawnLetter();
      else{boss.letterT+=dt;if(boss.letterT>=9000)spawnLetter();}
    }
  }

  // المنطقة الجليدية: 3 مكعبات ثلج كل 5 ثوانٍ، وتختفي بعد 10 ثوانٍ
  function updateZoneHazards(dt){
    if(zone!=='ice'){if(iceCubes.length)iceCubes=[];return;}
    dt=Math.min(dt,100);
    var i;
    for(i=iceCubes.length-1;i>=0;i--){iceCubes[i].age+=dt;if(iceCubes[i].age>=ICE_CUBE_LIFE)iceCubes.splice(i,1);}
    iceT+=dt;
    if(iceT>=ICE_CUBE_EVERY){
      iceT=0;
      var h=snake[0];
      for(i=0;i<ICE_CUBES_PER_WAVE;i++){
        var x,y,t=0;
        do{x=Math.floor(Math.random()*N);y=Math.floor(Math.random()*N);t++;}
        while((occupied(x,y)||(Math.abs(x-h[0])<=2&&Math.abs(y-h[1])<=2)||(boss&&y===0))&&t<300);
        if(!occupied(x,y))iceCubes.push({x:x,y:y,age:0});
      }
      sfx('iceWarn');
    }
  }

  function mainLoop(timestamp){
    if(!running)return;
    var dt=timestamp-lastFrameTime;
    lastFrameTime=timestamp;
    accumulator+=dt;

    updateHelpers(dt);
    tickEffects(dt);
    updateZoneHazards(dt);
    if(boss){updateBoss(dt);if(!running)return;}

    var currentInterval=curSpeed();
    while(accumulator>=currentInterval){
      accumulator-=currentInterval;
      step();
      if(!running)return;
    }

    if(timestamp-lastRenderTime>=targetFpsInterval){
      lastRenderTime=timestamp;
      frameTick++;
      draw();
      fpsFrameCount++;
      if(!fpsWindowStart)fpsWindowStart=timestamp;
      if(timestamp-fpsWindowStart>=500){
        measuredFps=Math.round(fpsFrameCount*1000/(timestamp-fpsWindowStart));
        if(fpsValueEl)fpsValueEl.textContent=measuredFps;
        if(fpsSettingsValueEl)fpsSettingsValueEl.textContent=measuredFps+' FPS';
        fpsFrameCount=0;fpsWindowStart=timestamp;
        if(isU()&&!U_LITE&&currentFps>=60&&measuredFps<38){
          if(++uSlow>=4){U_LITE=true;applyGraphicsUI();msg.textContent='⚙️ خُفّفت مؤثرات سوبر ألترا تلقائيًا لتثبيت الأداء';setTimeout(function(){if(running&&msg.textContent.indexOf('⚙️')===0)msg.textContent='';},3500);}
        }else uSlow=0;
      }
    }
    gameLoopId=requestAnimationFrame(mainLoop);
  }
  var lastRenderTime=0;

  function handleCollision(why){
    if(shieldCharges>0){
      var safe=findSafeReviveDirection();
      if(safe){
        fx('shield',snake[0][0],snake[0][1]);shieldCharges--;dir=safe;next=safe;dirQueue=[];
        msg.textContent='🛡️ درع الثعبان أنقذك! المتبقي: '+shieldCharges;
        sfx('shield');haptic();
        return;
      }
    }
    end(why);
  }

  function step(){
    if(frozenT>0)return;
    if(dirQueue.length)next=dirQueue.shift();
    dir=next;
    var nx=snake[0][0]+dir[0],ny=snake[0][1]+dir[1];var ghost=isGhost();
    if(DIFF[diffKey].walls){if(nx<0||ny<0||nx>=N||ny>=N)return handleCollision('اصطدمت بالجدار!')}
    else{nx=(nx+N)%N;ny=(ny+N)%N}
    if(!ghost){
      var hitSt=stones.filter(function(s){return s[0]===nx&&s[1]===ny;})[0];
      if(hitSt)return handleCollision(hitSt[2]?'🌋 احترقت بالحمم البركانية!':'اصطدمت بحجر!');
      if(iceCubes.some(function(c){return c.x===nx&&c.y===ny;}))return handleCollision('🧊 اصطدمت بمكعب ثلج!');
    }
    var willEat=!!food&&food[0]===nx&&food[1]===ny;
    var body=willEat?snake:snake.slice(0,-1);
    if(!ghost&&body.some(function(s){return s[0]===nx&&s[1]===ny}))return handleCollision('عضّيت نفسك!');
    snake.unshift([nx,ny]);
    if(boss){
      if(shotHit()){handleCollision('أصابك حجر '+CHAPTERS[adventureChapter].bossName+'!');if(!running)return;}
      if(bandHit()){end('سحقتك أحجار الثعبان الأسود الكبيرة! كان عليك التقاط حرف G.');return;}
      if(boss.gLetter&&boss.gLetter.x===nx&&boss.gLetter.y===ny){
        fx('ghit',nx,ny);boss.gLetter=null;if(boss.strike)boss.strike.prot=true;
        msg.textContent='🛡️ حرف G! أنت محمي من الضربة الكبرى';
        sfx('gGet');haptic();
      }
      // حرف B يدمّر الزعيم فقط ولا يغيّر حجم الثعبان
      if(boss.letter&&boss.letter.x===nx&&boss.letter.y===ny){
        fx('bhit',nx,ny);boss.got++;boss.letter=null;
        score+=50*(nightmareMode?2:1);scoreEl.textContent=score;
        sfx('bHit');haptic();updateAdventureHUD();
        if(boss.got>=boss.need){completeAdventureLevel();return;}
        msg.textContent='💥 ضربة للزعيم! B '+boss.got+'/'+boss.need;
      }
    }
    if(mg&&mg.x===nx&&mg.y===ny){
      fx('mango',nx,ny);mg=null;mangoes++;gameMangoesEarned++;saveData();
      msg.textContent='🥭 +1 منجة!';sfx('mango');haptic();
    }
    if(pw&&pw.x===nx&&pw.y===ny){var pt=pw.t;fx('power',nx,ny,!!(PW[pt]&&PW[pt].bad));pw=null;activate(pt)}
    if(willEat){
      fx('eat',nx,ny);
      eaten++;
      var mult = (hasEff('x2')?2:1) * (nightmareMode?2:1);
      score += 10 * level * mult;
      scoreEl.textContent=score;
      
      var gainedApples = nightmareMode ? 2 : 1;
      apples += gainedApples;
      gameApplesEarned += gainedApples;
      saveData();
      if(activeHelper==='h2'){
        h2Count++;
        var farmNeed=farmerUp?10:15,farmGain=farmerUp?55:45;
        if(h2Count>=farmNeed){
          h2Count=0;apples+=farmGain;gameApplesEarned+=farmGain;
          if(farmerUp){mangoes++;gameMangoesEarned++;}
          saveData();
          msg.textContent='🍎 مزارع التفاح منحك +'+farmGain+' تفاحة'+(farmerUp?' و +1 🥭':'')+'!';sfx('coins');
          setTimeout(function(){ if(running && msg.textContent.indexOf('🍎')===0) msg.textContent=''; }, 2000);
        }
      }
      var mEvery=(zone==='ice')?ICE_MANGO_EVERY:10,mProb=(zone==='ice')?ICE_MANGO_CHANCE:0.7;
      if(gameMode==='classic'&&eaten%mEvery===0&&!mg&&Math.random()<mProb)spawnMango();

      sfx('eat');haptic();
      if(gameMode!=='adventure'&&eaten%5===0){
        level++;lvlEl.textContent=level;stones=[];
        speed=baseSpeed();msg.textContent='المستوى '+level+'! أُزيلت الأحجار';
        sfx('levelUp');
        if((level-1)%ZONE_EVERY===0){
          zone=rollZone(true);iceCubes=[];iceT=0;updateZoneUI();
          msg.textContent='المستوى '+level+' — المنطقة: '+ZONE_INFO[zone].i+' '+ZONE_INFO[zone].n;
        }
        setTimeout(function(){if(running&&msg.textContent.indexOf('المستوى')===0)msg.textContent=''},2500);
      }else if(eaten%DIFF[diffKey].every===0){placeStone()}
      placeFood();
    }else snake.pop();
    if(mg){mg.life--;if(mg.life<=0)mg=null}
    if(pw){pw.life--;if(pw.life<=0)pw=null}
    else if(!effs.length&&Math.random()<0.03)spawnPower();
    if(gameMode==='adventure'){
      updateAdventureHUD();
      if(!boss&&eaten>=ADV_GOAL){completeAdventureLevel();return;}
    }
  }

  function completeAdventureLevel(){
    if(!running||gameMode!=='adventure')return;
    running=false;over_=true;paused=false;
    if(gameLoopId)cancelAnimationFrame(gameLoopId);
    pauseBtn.style.display='none';
    var ch=CHAPTERS[adventureChapter],doneLevel=adventureLevel,doneChapter=adventureChapter;
    var isBoss=doneLevel===ADV_LEVELS-1,isLastChapter=doneChapter===CHAPTERS.length-1;
    var isFinal=isBoss&&isLastChapter,alreadyClaimed=isFinal&&adventureFinished;
    var reward=alreadyClaimed?0:(isBoss?ch.reward:LEVEL_REWARD+doneChapter*5);
    apples+=reward;gameApplesEarned+=reward;
    // المنجة: فرصة 70% بعد إتمام 10 تفاحات (أو هزيمة الزعيم)، وحارس الغنائم يضاعفها
    var mangoGain=(!alreadyClaimed&&Math.random()<(zone==='ice'?ICE_MANGO_CHANCE:0.7))?1:0;
    if(mangoGain&&activeHelper==='h3')mangoGain*=(lootUp?3:2);
    mangoes+=mangoGain;frozenT=0;
    if(isFinal)adventureFinished=true;
    else if(isBoss){adventureChapter=doneChapter+1;adventureLevel=0;}
    else adventureLevel=doneLevel+1;
    boss=null;
    if(score>best){best=score;try{localStorage.setItem(bestKey(),best)}catch(e){}}
    if(gameApplesEarned>bestApples){bestApples=gameApplesEarned;try{localStorage.setItem(bestApplesKey(),bestApples)}catch(e){}}
    saveData();
    if(isFinal){
      adventureCompleteTitle.textContent='🏆 أنقذت الثعبانة الوردية!';
      adventureCompleteText.textContent=ch.outro;
      adventureNextBtn.textContent='إنهاء والعودة للقائمة';
    }else if(isBoss){
      adventureCompleteTitle.textContent='🎉 هُزم '+ch.bossName+'!';
      adventureCompleteText.textContent=ch.outro;
      adventureNextBtn.textContent='الفصل '+(adventureChapter+1);
    }else{
      adventureCompleteTitle.textContent='✅ اكتمل الليفل '+(doneLevel+1)+' من '+ADV_LEVELS;
      adventureCompleteText.textContent=(adventureLevel===ADV_LEVELS-1)?'اقتربت من الزعيم! استعد للمواجهة وتفادَ هجماته.':'أحسنت! خطوة أخرى تقرّبك من الثعبانة الوردية.';
      adventureNextBtn.textContent=(adventureLevel===ADV_LEVELS-1)?'مواجهة الزعيم':'الليفل '+(adventureLevel+1);
    }
    adventureRewardText.textContent=(alreadyClaimed?'لا توجد مكافأة إضافية لإعادة الفصل.':'المكافأة: +'+reward+' 🍎'+(mangoGain?' و +'+mangoGain+' 🥭':' (لم تظهر منجة هذه المرة)'))+' · رصيدك: '+apples+' 🍎 · '+mangoes+' 🥭';
    adventureCompleteOverlay.style.display='flex';
    updateAdventureHUD();sfx('win');
  }

  function end(why){
    running=false;paused=false;over_=true;effs=[];invisT=0;pw=null;
    pauseOverlay.style.display='none';pauseBtn.style.display='none';
    if(gameLoopId)cancelAnimationFrame(gameLoopId);
    sfx('hit');setTimeout(function(){sfx('over');},260);haptic();
    var ultraDeath=isU()&&snake&&snake.length;
    if(ultraDeath)fx('die',snake[0][0],snake[0][1]);

    // المساعد الثالث (حارس الغنائم): يُضاعف التفاح الذي أخذته في الجيم بعد الموت
    if(activeHelper === 'h3' && gameApplesEarned > 0){
      var extraApples = gameApplesEarned*(lootUp?2:1);
      apples += extraApples;
      gameApplesEarned += extraApples;
      saveData();
      helper3BonusMsg.textContent = '💎 حارس الغنائم زوّد تفاح الجيم ('+(lootUp?'×3':'×2')+') (+' + extraApples + ' 🍎)!';
      helper3BonusMsg.style.display = 'block';
    } else {
      helper3BonusMsg.style.display = 'none';
    }

    if(gameMangoesEarned>0){
      var mangoTotal=gameMangoesEarned;
      if(activeHelper==='h3'){mangoes+=gameMangoesEarned*(lootUp?2:1);mangoTotal=gameMangoesEarned*(lootUp?3:2);saveData();}
      gameMangoMsg.textContent='🥭 منجة الجيم: '+mangoTotal+(activeHelper==='h3'?' (زوّدها حارس الغنائم '+(lootUp?'×3':'×2')+')':'')+' · رصيدك: '+mangoes+' 🥭';
      gameMangoMsg.style.display='block';
    }else{
      gameMangoMsg.style.display='none';
    }

    var isNew=false;
    if(score>best){best=score;menuBestEl.textContent=best;isNew=true;try{localStorage.setItem(bestKey(),best)}catch(e){}}

    var isNewAppleRecord = false;
    if(gameApplesEarned > bestApples){
      bestApples = gameApplesEarned;
      menuBestApplesEl.textContent = bestApples + ' 🍎';
      isNewAppleRecord = true;
      try{localStorage.setItem(bestApplesKey(), bestApples)}catch(e){}
    }

    overReason.textContent=why;
    finalScoreEl.textContent=score;
    finalGameApplesEl.textContent=gameApplesEarned;
    finalApplesEl.textContent=apples;
    newRecordMsg.style.display=isNew?'block':'none';
    newAppleRecordMsg.style.display=isNewAppleRecord?'block':'none';
    
    updateAdStatus();
    revive150Btn.disabled=(apples<150);
    revive500Btn.disabled=(apples<500);
    reviveSection.style.display='flex';
    powerChoiceSection.style.display='none';
    if(ultraDeath){
      overOverlay.style.display='none';uTail();
      setTimeout(function(){if(over_&&!running)overOverlay.style.display='flex';},850);
    }else overOverlay.style.display='flex';
    draw();
  }

  function findSafeReviveDirection(){
    var head=snake[0];
    var candidates=[V.u,V.d,V.l,V.r];
    for(var i=0;i<candidates.length;i++){
      var d=candidates[i],nx=head[0]+d[0],ny=head[1]+d[1];
      if(DIFF[diffKey].walls){
        if(nx<0||ny<0||nx>=N||ny>=N)continue;
      }else{
        nx=(nx+N)%N;ny=(ny+N)%N;
      }
      var blockedByStone=stones.some(function(st){return st[0]===nx&&st[1]===ny;})||iceCubes.some(function(c){return c.x===nx&&c.y===ny;});
      var blockedByBody=snake.slice(0,-1).some(function(seg){return seg[0]===nx&&seg[1]===ny;});
      if(!blockedByStone&&!blockedByBody)return d;
    }
    return null;
  }

  function reviveGame(chosenPower){
    sfx('revive');
    over_=false;paused=false;pauseOverlay.style.display='none';overOverlay.style.display='none';pauseBtn.style.display='flex';pauseBtn.textContent='⏸';pauseBtn.setAttribute('aria-label','إيقاف مؤقت');
    stones=stones.filter(function(s){return !(s[0]===snake[0][0]&&s[1]===snake[0][1]);});
    var safeDirection=findSafeReviveDirection();
    if(safeDirection){
      dir=safeDirection;next=safeDirection;dirQueue=[];
    }else{
      snake=[[8,8],[7,8],[6,8]];
      stones=stones.filter(function(st){return !snake.some(function(seg){return seg[0]===st[0]&&seg[1]===st[1];});});
      dir=V.r;next=V.r;dirQueue=[];
      if(food&&snake.some(function(seg){return seg[0]===food[0]&&seg[1]===food[1];})){food=null;placeFood();}
      msg.textContent='تم نقلك إلى مكان آمن لتكمل الجولة.';
    }
    if(chosenPower){activate(chosenPower);}
    if(boss){
      boss.shots=[];boss.dash=null;boss.ice=null;boss.strike=null;boss.gLetter=null;boss.pools=[];
      if(CHAPTERS[adventureChapter].strikeEvery)boss.strikeT=6000;
    }
    frozenT=0;
    running=true;
    lastFrameTime=performance.now();lastRenderTime=lastFrameTime;fpsWindowStart=lastFrameTime;fpsFrameCount=0;
    accumulator=0;
    gameLoopId=requestAnimationFrame(mainLoop);
  }

  reviveAdBtn.onclick=function(){showRewardedAd('revive');};

  revive150Btn.onclick=function(){
    if(apples>=150){apples-=150;saveData();reviveGame(null);}
  };

  revive500Btn.onclick=function(){
    if(apples<500)return;
    apples-=500;saveData();
    var keys=PK.slice();
    var p1=keys.splice(Math.floor(Math.random()*keys.length),1)[0];
    var p2=keys.splice(Math.floor(Math.random()*keys.length),1)[0];
    choice1Btn.textContent=PW[p1].n.split(':')[0];
    choice2Btn.textContent=PW[p2].n.split(':')[0];
    choice1Btn.onclick=function(){reviveGame(p1);};
    choice2Btn.onclick=function(){reviveGame(p2);};
    reviveSection.style.display='none';
    powerChoiceSection.style.display='block';
  };

  function drawRoundRect(x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
    ctx.fill();
  }

  function drawSnakeSegment(x, y, idx, total){
    var px = x * S, py = y * S;
    var isHead = (idx === 0);
    var isTail = (idx === total - 1 && total > 1);

    var headColor = darkMode ? '#9be564' : '#1b3811';
    var bodyColor = darkMode ? '#6ab04c' : '#2d5a1e';
    var stripeColor = darkMode ? '#badc58' : '#4a8536';

    var custom=null,outline=false;
    for(var ci=0;ci<SNAKE_COLORS.length;ci++){if(SNAKE_COLORS[ci].id===snakeColor&&snakeColor!=='green')custom=SNAKE_COLORS[ci];}
    if(activeSkin === 'default' && custom){
      headColor = custom.h; bodyColor = custom.c; stripeColor = custom.s;
    } else if(activeSkin === 'old'){
      headColor = '#6e6a5e'; bodyColor = '#a29c8a'; stripeColor = '#e2dccb';
    } else if(activeSkin === 'small'){
      headColor = '#1b97c9'; bodyColor = '#7fd4f0'; stripeColor = '#e6f8ff';
    } else if(activeSkin === 'black'){
      headColor = '#000000'; bodyColor = '#1d1d1d'; stripeColor = '#d32f2f'; outline = true;
    } else if(activeSkin === 'invisible'){
      headColor = '#7e94b8'; bodyColor = '#c3d3ea'; stripeColor = '#ffffff';
    } else if(activeSkin === 'strong'){
      headColor = '#5c1a00'; bodyColor = '#c0501a'; stripeColor = '#ffb27a';
    } else if(activeSkin === 'skin1'){
      headColor = '#ffd700'; bodyColor = '#e69500'; stripeColor = '#fff099';
    } else if(activeSkin === 'skin2'){
      headColor = '#00ffff'; bodyColor = '#b300b3'; stripeColor = '#ff80ff';
    } else if(nightmareMode && activeSkin==='default'){
      headColor = '#ff3838'; bodyColor = '#b31212'; stripeColor = '#ff7979';
    }

    if(graphicsQuality==='ultra'&&!darkMode&&activeSkin==='default'&&!custom&&!nightmareMode){headColor='#9be564';bodyColor='#6ab04c';stripeColor='#badc58';}
    uPal.head=headColor;uPal.body=bodyColor;uPal.stripe=stripeColor;

    if(isHead){
      if(Math.floor(frameTick / 8) % 2 === 0){
        ctx.fillStyle = '#d9534f';
        var lx = px + S/2 + dir[0]*(S/2 + 2);
        var ly = py + S/2 + dir[1]*(S/2 + 2);
        ctx.fillRect(lx - 2, ly - 2, 4, 4);
      }

      if(outline){ctx.fillStyle = '#9e9e9e';drawRoundRect(px, py, S, S, 7);}
      if(graphicsQuality!=='low'){
        var hg=ctx.createLinearGradient(px,py,px+S,py+S);
        hg.addColorStop(0,headColor);hg.addColorStop(1,bodyColor);
        ctx.fillStyle=hg;
        if(graphicsQuality==='high'||graphicsQuality==='ultra'){ctx.shadowColor=headColor;ctx.shadowBlur=graphicsQuality==='ultra'?10:7;}
      }else ctx.fillStyle=headColor;
      drawRoundRect(px + 1, py + 1, S - 2, S - 2, 6);
      ctx.shadowBlur=0;
      if(graphicsQuality!=='low'){
        ctx.fillStyle='rgba(255,255,255,.24)';drawRoundRect(px+4,py+3,S-10,3,2);
      }

      var eye1X, eye1Y, eye2X, eye2Y;
      if(dir[0] === 1){
        eye1X = px + 13; eye1Y = py + 5;
        eye2X = px + 13; eye2Y = py + 13;
      } else if(dir[0] === -1){
        eye1X = px + 5; eye1Y = py + 5;
        eye2X = px + 5; eye2Y = py + 13;
      } else if(dir[1] === -1){
        eye1X = px + 5; eye1Y = py + 5;
        eye2X = px + 13; eye2Y = py + 5;
      } else {
        eye1X = px + 5; eye1Y = py + 13;
        eye2X = px + 13; eye2Y = py + 13;
      }

      ctx.fillStyle = '#ffffff';
      ctx.beginPath(); ctx.arc(eye1X, eye1Y, 2.6, 0, Math.PI*2); ctx.fill();
      ctx.beginPath(); ctx.arc(eye2X, eye2Y, 2.6, 0, Math.PI*2); ctx.fill();

      ctx.fillStyle = '#000000';
      ctx.beginPath(); ctx.arc(eye1X + dir[0]*0.8, eye1Y + dir[1]*0.8, 1.3, 0, Math.PI*2); ctx.fill();
      ctx.beginPath(); ctx.arc(eye2X + dir[0]*0.8, eye2Y + dir[1]*0.8, 1.3, 0, Math.PI*2); ctx.fill();

    } else {
      var pad = isTail ? 4 : 2;
      var radius = isTail ? 6 : 4;
      if(outline){ctx.fillStyle = '#9e9e9e';drawRoundRect(px + pad - 1, py + pad - 1, S - pad*2 + 2, S - pad*2 + 2, radius + 1);}
      if(graphicsQuality!=='low'){
        var bg=ctx.createLinearGradient(px,py,px+S,py+S);
        bg.addColorStop(0,stripeColor);bg.addColorStop(.45,bodyColor);bg.addColorStop(1,headColor);
        ctx.fillStyle=bg;
        if(graphicsQuality==='high'||graphicsQuality==='ultra'){ctx.shadowColor=bodyColor;ctx.shadowBlur=graphicsQuality==='ultra'?7:4;}
      }else ctx.fillStyle = bodyColor;
      drawRoundRect(px + pad, py + pad, S - pad*2, S - pad*2, radius);
      ctx.shadowBlur=0;
      if(graphicsQuality!=='low'){
        ctx.fillStyle='rgba(255,255,255,.16)';drawRoundRect(px+pad+2,py+pad+2,S-pad*2-5,2,1);
      }

      if(!isTail && idx % 2 === 1){
        ctx.fillStyle = stripeColor;
        drawRoundRect(px + 6, py + 6, S - 12, S - 12, 2);
      }
    }
    if(graphicsQuality==='ultra')uGloss(px,py,isHead);
  }

  function drawBossLayer(ink,lcd){
    if(!boss)return;
    var ch=CHAPTERS[adventureChapter],cx=boss.bx*S+S/2,i,blink=Math.floor(frameTick/4)%2===0;
    ctx.textAlign='center';ctx.textBaseline='middle';

    // البرك (الزعيم 2)
    boss.pools.forEach(function(pl){
      if(pl.age<700){
        if(blink){ctx.fillStyle='rgba(52,152,219,0.22)';ctx.fillRect(pl.x*S,0,pl.w*S,N*S);}
      }else if(10700-pl.age>2500||blink){
        ctx.fillStyle='rgba(52,152,219,0.42)';ctx.fillRect(pl.x*S,0,pl.w*S,N*S);
        ctx.fillStyle='rgba(255,255,255,0.35)';
        for(var yy=0;yy<N;yy++)ctx.fillRect(pl.x*S+3+((yy+frameTick)%3)*3,yy*S+8,5,2);
      }
    });
    // ممر الاندفاع (الزعيم 3)
    var dsx=cx,dsy=S/2,dashing=false;
    if(boss.dash){
      var dd=boss.dash;
      ctx.fillStyle=dd.run?'rgba(217,83,79,0.5)':(blink?'rgba(217,83,79,0.32)':'rgba(217,83,79,0.12)');
      if(dd.axis==='row')ctx.fillRect(0,dd.idx*S,N*S,S);else ctx.fillRect(dd.idx*S,0,S,N*S);
      if(dd.run){
        dashing=true;
        dsx=dd.axis==='row'?dd.pos*S+S/2:dd.idx*S+S/2;
        dsy=dd.axis==='row'?dd.idx*S+S/2:dd.pos*S+S/2;
      }
    }
    // خطوط الجليد (الزعيم 4)
    if(boss.ice){
      var ic=boss.ice;
      ic.lines.forEach(function(ln){
        ctx.fillStyle=ic.phase==='strike'?'rgba(210,245,255,0.85)':(blink?'rgba(120,200,255,0.38)':'rgba(120,200,255,0.15)');
        if(ln.axis==='row')ctx.fillRect(0,ln.idx*S,N*S,S);else ctx.fillRect(ln.idx*S,0,S,N*S);
      });
    }
    // تحذير الحجر الكبير (الزعيم 1) والصغير
    if(boss.bigT>0&&boss.bigT<=700&&blink){
      ctx.fillStyle='rgba(217,83,79,0.3)';
      ctx.fillRect(Math.max(0,boss.bx-1)*S,S,Math.min(N,boss.bx+2)*S-Math.max(0,boss.bx-1)*S,N*S-S);
    }
    if(boss.throwT>0&&boss.throwT<=600&&blink){
      ctx.fillStyle='#d9534f';ctx.font='bold 14px sans-serif';ctx.fillText('!',cx,S+S/2);
    }
    // جسم الزعيم
    if(adventureChapter===CHAPTERS.length-1){
      ctx.fillStyle='#161616';
      for(i=4;i>=1;i--)drawRoundRect(cx-i*11-7,4+i,14-i,12-i,4);
      drawRoundRect(cx-10,0,20,20,7);
      ctx.fillStyle='#ff2d2d';ctx.beginPath();ctx.arc(cx-4,8,2.2,0,Math.PI*2);ctx.fill();
      ctx.beginPath();ctx.arc(cx+4,8,2.2,0,Math.PI*2);ctx.fill();
    }else{
      ctx.font=(dashing?'26px':'24px')+' serif';ctx.fillStyle='#000';ctx.fillText(ch.bossEmoji,dashing?dsx:cx,dashing?dsy:S/2+1);
    }
    // الحجارة
    boss.shots.forEach(function(sh){
      if(sh.big){
        var x0=Math.max(0,sh.x-1),x1=Math.min(N-1,sh.x+1);
        ctx.fillStyle='#5a3a20';drawRoundRect(x0*S+1,sh.y*S+1,(x1-x0+1)*S-2,S-2,7);
        ctx.fillStyle='#8a6038';ctx.fillRect(x0*S+7,sh.y*S+6,5,5);ctx.fillRect(x1*S+8,sh.y*S+9,5,5);
      }else if(sh.ice){
        ctx.fillStyle='#bfe9ff';drawRoundRect(sh.x*S+2,sh.y*S+2,S-4,S-4,5);
        ctx.fillStyle='#ffffff';ctx.fillRect(sh.x*S+6,sh.y*S+6,4,4);
      }else{
        ctx.fillStyle='#6b4226';drawRoundRect(sh.x*S+2,sh.y*S+2,S-4,S-4,5);
        ctx.fillStyle='#a8764a';ctx.fillRect(sh.x*S+6,sh.y*S+6,4,4);
      }
    });
  }

  // طبقة تُرسم فوق كل شيء: الظلام، أحجار الثعبان الأسود، حروف B و G
  function drawBossOverlay(){
    if(!boss)return;
    var ch=CHAPTERS[adventureChapter],blink=Math.floor(frameTick/4)%2===0,st=boss.strike,h=snake[0];
    ctx.textAlign='center';ctx.textBaseline='middle';
    if(ch.dark){
      var hx=h[0]*S+S/2,hy=h[1]*S+S/2;
      var g=ctx.createRadialGradient(hx,hy,S*1.7,hx,hy,S*4.6);
      g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(0,0,0,0.97)');
      ctx.fillStyle=g;ctx.fillRect(0,0,N*S,N*S);
    }
    if(st){
      if(st.phase==='warn'){
        if(blink){ctx.fillStyle='rgba(217,83,79,0.16)';ctx.fillRect(0,0,N*S,N*S);}
        ctx.fillStyle='#ff6b6b';ctx.font='bold 13px sans-serif';
        ctx.fillText('⚠ احضر G خلال '+Math.max(0,Math.ceil((4200-st.t)/1000))+' ث',N*S/2,S*1.5);
      }else{
        for(var i=0;i<3;i++){
          var by=Math.floor((st.t-i*250)/70)-1;
          if(by<0)continue;
          ctx.fillStyle=st.prot?'rgba(120,200,120,0.4)':'#5a4632';
          drawRoundRect(BANDS[i][0]*S+1,(by-1)*S,(BANDS[i][1]-BANDS[i][0]+1)*S-2,2*S,6);
          if(!st.prot){ctx.fillStyle='#8a6d4a';ctx.fillRect(BANDS[i][0]*S+8,(by-1)*S+8,6,6);}
        }
      }
    }
    if(boss.gLetter){
      var gx=boss.gLetter.x*S,gy=boss.gLetter.y*S;
      ctx.save();ctx.shadowColor='#7CFC00';ctx.shadowBlur=blink?16:6;
      ctx.fillStyle='#7CFC00';drawRoundRect(gx+1,gy+1,S-2,S-2,5);ctx.restore();
      ctx.fillStyle='#10300a';ctx.font='bold 15px sans-serif';ctx.fillText('G',gx+S/2,gy+S/2+1);
    }
    if(boss.letter&&(boss.letterT<6500||blink)){
      var lx=boss.letter.x*S,ly=boss.letter.y*S;
      ctx.save();ctx.shadowColor='#ffd700';ctx.shadowBlur=ch.dark?12:0;
      ctx.fillStyle='#ffd700';drawRoundRect(lx+1,ly+1,S-2,S-2,5);ctx.restore();
      ctx.fillStyle='#1b2c18';ctx.font='bold 15px sans-serif';ctx.fillText('B',lx+S/2,ly+S/2+1);
    }
    if(adventureChapter===CHAPTERS.length-1){
      var qx=N*S-42,qy=3;
      ctx.fillStyle='#ff9ccc';drawRoundRect(qx,qy+3,10,11,4);drawRoundRect(qx+11,qy+3,10,11,4);
      ctx.fillStyle='#ff4fa3';drawRoundRect(qx+22,qy+1,14,15,5);
      ctx.fillStyle='#ffffff';ctx.fillRect(qx+29,qy+5,3,3);
      ctx.font='11px serif';ctx.fillStyle='#000';ctx.fillText('💗',qx+18,qy+20);
    }
    if(st&&st.prot){
      ctx.strokeStyle='#7CFC00';ctx.lineWidth=2;ctx.beginPath();
      ctx.arc(h[0]*S+S/2,h[1]*S+S/2,S*0.85,0,Math.PI*2);ctx.stroke();
    }
  }

  // طبقة المنطقة: ظلام الكهف، دخان البراكين، غبار الصحراء (يقلل الرؤية 30%)
  function drawZoneOverlay(){
    var i,x,y;
    if(zone==='cave'&&snake&&snake.length&&!(boss&&CHAPTERS[adventureChapter].dark)){
      var h=snake[0],hx=h[0]*S+S/2,hy=h[1]*S+S/2;
      var g=ctx.createRadialGradient(hx,hy,S*1.7,hx,hy,S*4.6);
      g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(0,0,0,0.97)');
      ctx.fillStyle=g;ctx.fillRect(0,0,N*S,N*S);
      if(food&&Math.floor(frameTick/10)%2===0){
        ctx.fillStyle='rgba(255,110,110,0.75)';ctx.beginPath();ctx.arc(food[0]*S+S/2,food[1]*S+S/2,2.5,0,Math.PI*2);ctx.fill();
      }
    }else if(zone==='desert'){
      ctx.fillStyle='rgba(222,184,120,'+DESERT_HAZE+')';ctx.fillRect(0,0,N*S,N*S);
      ctx.fillStyle='rgba(240,215,160,0.5)';
      for(i=0;i<16;i++){
        x=((i*53+frameTick*(2+i%3))%340)-10;y=(i*37+(i%5)*11)%320;
        ctx.fillRect(x,y,8,1);
      }
    }else if(zone==='ice'){
      ctx.fillStyle='rgba(230,248,255,0.9)';
      for(i=0;i<18;i++){
        x=(i*47+Math.sin((frameTick+i*9)/14)*8+320)%320;y=((frameTick*1.2+i*53)%330)-5;
        ctx.fillRect(x,y,2,2);
      }
    }else if(zone==='volcano'){
      ctx.fillStyle='rgba(255,90,0,'+(0.05+0.03*Math.sin(frameTick/8))+')';ctx.fillRect(0,0,N*S,N*S);
      ctx.fillStyle='rgba(255,160,40,0.8)';
      for(i=0;i<12;i++){
        x=(i*29+((i*7)%5)*13)%320;y=320-((frameTick*1.5+i*41)%330);
        ctx.fillRect(x,y,2,2);
      }
    }
  }

  // =====================================================================
  //  وضع «سوبر ألترا» — إضاءة ديناميكية شبيهة بالـ Ray Tracing
  //  (إضاءة لكل نقطة وعنصر · ظلال ممتدة · لمعان وانعكاسات · Bloom · جسيمات · اهتزاز)
  // =====================================================================
  var U_SCALE=1,U_LITE=false,uSlow=0,uLastT=0,uShake=0,uFlash=0,uTime=0,uKey={x:-50,y:-70},uTailOn=false;
  var uParts=[],uRings=[],uMotes=[],uSprites={};
  var uPal={head:'#9be564',body:'#6ab04c',stripe:'#badc58'};
  function uMake(n){var c=document.createElement('canvas');c.width=c.height=n;return c;}
  var uShCv=uMake(160),uShCtx=uShCv.getContext('2d');
  var uB1=uMake(160),uB1c=uB1.getContext('2d'),uB2=uMake(80),uB2c=uB2.getContext('2d'),uB3=uMake(40),uB3c=uB3.getContext('2d');
  var U_MOTE={normal:[190,255,150],cave:[120,170,255],volcano:[255,150,60],desert:[255,225,160],ice:[205,238,255]};

  function isU(){return graphicsQuality==='ultra';}
  function shk(n){if(isU())uShake=Math.max(uShake,n);}
  function hexRGB(h){h=String(h||'#ffffff').replace('#','');if(h.length===3)h=h[0]+h[0]+h[1]+h[1]+h[2]+h[2];var n=parseInt(h,16)||0;return [(n>>16)&255,(n>>8)&255,n&255];}
  function applyGraphicsUI(){
    var u=isU(),dpr=window.devicePixelRatio||1,i;
    document.body.classList.toggle('ultra',u);
    U_SCALE=u?(U_LITE?1:Math.min(2,Math.max(1.25,dpr))):1;
    var sz=Math.round(320*U_SCALE);
    if(cv.width!==sz){cv.width=sz;cv.height=sz;}
    if(u&&!uMotes.length)for(i=0;i<22;i++)uMotes.push({x:Math.random()*320,y:Math.random()*320,ph:Math.random()*6.283,sp:.6+Math.random()*1.2,r:2+Math.random()*2.5});
    if(!u){uParts=[];uRings=[];uShake=0;}
  }
  function uSprite(rgb){
    var k=rgb[0]+','+rgb[1]+','+rgb[2],s=uSprites[k];
    if(s)return s;
    s=uMake(96);var c=s.getContext('2d'),g=c.createRadialGradient(48,48,0,48,48,48);
    g.addColorStop(0,'rgba('+k+',.8)');g.addColorStop(.18,'rgba('+k+',.46)');g.addColorStop(.5,'rgba('+k+',.16)');g.addColorStop(1,'rgba('+k+',0)');
    c.fillStyle=g;c.fillRect(0,0,96,96);
    return (uSprites[k]=s);
  }
  function uGlow(x,y,r,a,rgb){ctx.globalAlpha=a>1?1:a;ctx.drawImage(uSprite(rgb),x-r,y-r,r*2,r*2);}

  // ---------- الجسيمات والمؤثرات ----------
  function uEmit(x,y,rgb,n,spd,life,size,o){
    o=o||{};var cap=U_LITE?220:520,i,a,v,l;
    for(i=0;i<n&&uParts.length<cap;i++){
      a=Math.random()*6.283;v=spd*(.3+Math.random()*.9);l=life*(.6+Math.random()*.6);
      uParts.push({x:x+(o.jit?(Math.random()-.5)*o.jit:0),y:y+(o.jit?(Math.random()-.5)*o.jit:0),vx:Math.cos(a)*v,vy:Math.sin(a)*v-(o.up||0),l:l,m:l,s:size*(.6+Math.random()*.8),c:rgb,g:o.g||0,d:o.d||.9});
    }
  }
  function uRing(x,y,rgb,v,l,w){uRings.push({x:x,y:y,r:3,v:v,l:l,m:l,c:rgb,w:w||2});}
  function fx(kind,cx,cy,flag){
    if(!isU())return;
    var x=cx*S+S/2,y=cy*S+S/2,c;
    if(kind==='eat'){
      uEmit(x,y,[255,90,80],28,130,.7,7);uEmit(x,y,[255,225,160],14,80,.5,5);
      uRing(x,y,[255,120,100],120,.45);uFlash=Math.max(uFlash,.5);
    }else if(kind==='mango'){
      uEmit(x,y,[255,190,40],36,160,.9,8,{g:70});uEmit(x,y,[255,240,170],18,100,.7,5);
      uRing(x,y,[255,200,70],150,.6,3);uRing(x,y,[255,240,170],90,.5);uFlash=Math.max(uFlash,.8);
    }else if(kind==='power'){
      c=flag?[255,80,80]:[120,255,150];
      uEmit(x,y,c,26,140,.8,6);uEmit(x,y,[255,255,255],10,90,.5,4);
      uRing(x,y,c,130,.55,3);uRing(x,y,c,70,.4);uFlash=Math.max(uFlash,.6);
    }else if(kind==='bhit'){
      uEmit(x,y,[255,215,60],42,200,.9,8,{g:50});uEmit(x,y,[255,255,200],16,120,.6,5);
      uRing(x,y,[255,215,60],170,.6,3);uRing(x,y,[255,160,40],100,.5);uShake=Math.max(uShake,5);uFlash=Math.max(uFlash,.8);
    }else if(kind==='ghit'){
      uEmit(x,y,[124,252,0],30,150,.8,6);uRing(x,y,[124,252,0],140,.5,3);uFlash=Math.max(uFlash,.6);
    }else if(kind==='shield'){
      uEmit(x,y,[120,210,255],28,170,.8,6);uRing(x,y,[120,210,255],170,.55,3);uRing(x,y,[255,255,255],100,.4);
      uShake=Math.max(uShake,4);uFlash=Math.max(uFlash,.7);
    }else if(kind==='die'){
      c=hexRGB(uPal.stripe);
      uEmit(x,y,c,70,220,1.1,8,{g:90});uEmit(x,y,[255,120,60],44,280,.85,7);uEmit(x,y,[255,255,255],20,340,.4,4);
      uRing(x,y,[255,110,70],220,.7,4);uRing(x,y,[255,255,255],140,.5,2);
      for(var i=2;i<snake.length;i+=2)uEmit(snake[i][0]*S+S/2,snake[i][1]*S+S/2,hexRGB(uPal.body),4,110,.8,6,{g:60});
      uShake=12;uFlash=1;
    }
  }
  function uUpdate(dt){
    var i,p,r,f,t=uTime,k;
    for(i=uParts.length-1;i>=0;i--){
      p=uParts[i];p.l-=dt;
      if(p.l<=0){uParts.splice(i,1);continue;}
      p.vy+=p.g*dt;f=Math.pow(p.d,dt*60);p.vx*=f;p.vy*=f;p.x+=p.vx*dt;p.y+=p.vy*dt;
    }
    for(i=uRings.length-1;i>=0;i--){r=uRings[i];r.l-=dt;if(r.l<=0){uRings.splice(i,1);continue;}r.r+=r.v*dt;r.v*=Math.pow(.93,dt*60);}
    uShake*=Math.pow(.88,dt*60);if(uShake<.25)uShake=0;
    uFlash*=Math.pow(.9,dt*60);if(uFlash<.02)uFlash=0;
    for(i=0;i<uMotes.length;i++){
      var m=uMotes[i];
      m.x+=Math.cos(t*m.sp+m.ph)*9*dt;
      m.y+=(zone==='volcano'?-16:(zone==='ice'?10:Math.sin(t*m.sp*.7+m.ph)*7))*dt;
      if(m.y<-8)m.y=328;if(m.y>328)m.y=-8;if(m.x<-8)m.x=328;if(m.x>328)m.x=-8;
    }
    if(!snake||!snake.length)return;
    var live=running||over_;
    if(running){
      var h=snake[0],hc=hexRGB(uPal.stripe);
      if(Math.random()<dt*38)uEmit(h[0]*S+S/2,h[1]*S+S/2,hc,1,16,.55,4.5,{jit:8});
      if(food&&Math.random()<dt*9)uEmit(food[0]*S+S/2,food[1]*S+S/2,[255,120,100],1,10,.7,3.5,{up:16,jit:8});
      for(i=0;i<stones.length;i++){
        if(stones[i][2]&&Math.random()<dt*4)uEmit(stones[i][0]*S+S/2,stones[i][1]*S+S/2,[255,150,40],1,12,1,3.5,{up:34,jit:10,g:-20});
      }
      for(i=0;i<iceCubes.length;i++){
        if(Math.random()<dt*2.5)uEmit(iceCubes[i].x*S+S/2,iceCubes[i].y*S+S/2,[200,240,255],1,10,.8,3.5,{up:8,jit:14});
      }
      if(boss){
        if(boss.letter&&Math.random()<dt*16)uEmit(boss.letter.x*S+S/2,boss.letter.y*S+S/2,[255,220,80],1,26,.7,3.5,{jit:14});
        if(boss.gLetter&&Math.random()<dt*16)uEmit(boss.gLetter.x*S+S/2,boss.gLetter.y*S+S/2,[140,255,60],1,26,.7,3.5,{jit:14});
      }
      if(mg&&Math.random()<dt*14)uEmit(mg.x*S+S/2,mg.y*S+S/2,[255,200,80],1,22,.7,3.5,{jit:12});
    }
  }
  function uBegin(){
    var now=performance.now(),dt=uLastT?Math.min(.05,Math.max(0,(now-uLastT)/1000)):.016;
    uLastT=now;uTime+=dt;
    uKey=food?{x:food[0]*S+S/2,y:food[1]*S+S/2}:{x:-50,y:-70};
    uUpdate(dt);
    if(uShake>0)ctx.translate((Math.random()-.5)*uShake,(Math.random()-.5)*uShake);
  }
  // استمرار الرسم لحظات بعد الموت لإظهار الانفجار
  function uTail(){
    if(!isU()||uTailOn)return;
    uTailOn=true;var t0=performance.now();
    (function f(){
      if(running||!over_||performance.now()-t0>900){uTailOn=false;return;}
      frameTick++;draw();requestAnimationFrame(f);
    })();
  }

  // ---------- اللوحة (أرضية زجاجية لامعة) ----------
  function uBoard(){
    var i,g;
    g=ctx.createLinearGradient(0,0,320,320);
    g.addColorStop(0,'#101c15');g.addColorStop(.5,'#09120d');g.addColorStop(1,'#040806');
    ctx.fillStyle=g;ctx.fillRect(-24,-24,368,368);
    for(i=0;i<N;i++)for(var j=0;j<N;j++){
      ctx.fillStyle=((i+j)&1)?'rgba(255,255,255,.022)':'rgba(255,255,255,.008)';
      ctx.fillRect(i*S+.5,j*S+.5,S-1,S-1);
    }
    ctx.strokeStyle='rgba(110,255,170,.07)';ctx.lineWidth=.6;ctx.beginPath();
    for(i=0;i<=N;i++){ctx.moveTo(i*S,0);ctx.lineTo(i*S,320);ctx.moveTo(0,i*S);ctx.lineTo(320,i*S);}
    ctx.stroke();
    g=ctx.createRadialGradient(90,60,10,170,170,320);
    g.addColorStop(0,'rgba(140,230,190,.07)');g.addColorStop(.5,'rgba(60,120,100,.02)');g.addColorStop(1,'rgba(0,0,0,0)');
    ctx.fillStyle=g;ctx.fillRect(0,0,320,320);
  }

  // ---------- ظلال ممتدة (إسقاط من مصدر الضوء) ----------
  function uCast(s,x,y,w,h,lx,ly,maxLen){
    var cx=x+w/2,cy=y+h/2,d=Math.sqrt((cx-lx)*(cx-lx)+(cy-ly)*(cy-ly))||1,len=Math.min(maxLen,600/Math.max(d,24));
    var ps=[[x,y],[x+w,y],[x+w,y+h],[x,y+h]],qs=[],i,j,vx,vy,vd;
    for(i=0;i<4;i++){vx=ps[i][0]-lx;vy=ps[i][1]-ly;vd=Math.sqrt(vx*vx+vy*vy)||1;qs.push([ps[i][0]+vx/vd*len,ps[i][1]+vy/vd*len]);}
    for(i=0;i<4;i++){j=(i+1)&3;s.beginPath();s.moveTo(ps[i][0],ps[i][1]);s.lineTo(ps[j][0],ps[j][1]);s.lineTo(qs[j][0],qs[j][1]);s.lineTo(qs[i][0],qs[i][1]);s.closePath();s.fill();}
  }
  function uShadows(){
    if(!snake||!snake.length)return;
    var s=uShCtx,i,hd=snake[0],hx=hd[0]*S+S/2,hy=hd[1]*S+S/2;
    s.setTransform(1,0,0,1,0,0);s.clearRect(0,0,160,160);
    s.setTransform(.5,0,0,.5,0,0);s.fillStyle='#000';
    stones.forEach(function(st){
      if(st[2])return;
      var x=st[0]*S+2,y=st[1]*S+2;
      uCast(s,x,y,S-4,S-4,hx,hy,22);uCast(s,x,y,S-4,S-4,-80,-100,8);
    });
    iceCubes.forEach(function(c){var x=c.x*S+2,y=c.y*S+2;uCast(s,x,y,S-4,S-4,hx,hy,16);uCast(s,x,y,S-4,S-4,-80,-100,6);});
    if(boss&&boss.shots)boss.shots.forEach(function(sh){if(!sh.big){uCast(s,sh.x*S+3,sh.y*S+3,S-6,S-6,-80,-100,7);}});
    if(!hasEff('ghost')&&invisT<=0){
      for(i=snake.length-1;i>=0;i--){s.beginPath();s.arc(snake[i][0]*S+S/2+2.6,snake[i][1]*S+S/2+3.8,S*.4,0,6.283);s.fill();}
    }
    if(food){s.beginPath();s.ellipse(food[0]*S+S/2+2.5,food[1]*S+S/2+5,S*.34,S*.26,0,0,6.283);s.fill();}
    ctx.save();ctx.globalAlpha=.55;ctx.imageSmoothingEnabled=true;ctx.drawImage(uShCv,0,0,320,320);ctx.restore();
  }

  // ---------- مصادر الضوء ----------
  function uBuildLights(){
    var L=[],t=uTime,i,h=snake[0],hc=hexRGB(uPal.stripe),bc=hexRGB(uPal.body),inv=invisT>0?.3:1;
    if(frozenT>0)hc=[150,220,255];
    L.push({x:h[0]*S+S/2,y:h[1]*S+S/2,r:70,a:.5*inv,c:hc});
    var cap=U_LITE?4:22,n=0,s;
    for(i=1;i<snake.length&&n<cap;i+=2){n++;s=snake[i];L.push({x:s[0]*S+S/2,y:s[1]*S+S/2,r:30,a:.2*(1-i/snake.length*.55)*inv,c:bc});}
    if(food){var pl=.85+.15*Math.sin(t*5);L.push({x:food[0]*S+S/2,y:food[1]*S+S/2,r:80*pl,a:.7,c:[255,60,50]});}
    if(mg)L.push({x:mg.x*S+S/2,y:mg.y*S+S/2,r:62,a:.65,c:[255,170,40]});
    if(pw)L.push({x:pw.x*S+S/2,y:pw.y*S+S/2,r:54,a:pw.life>15?.55:.3,c:PW[pw.t]&&PW[pw.t].bad?[255,70,70]:[130,255,150]});
    stones.forEach(function(st){
      if(st[2]){var fl=.8+.2*Math.sin(t*9+st[0]*3+st[1]*2);L.push({x:st[0]*S+S/2,y:st[1]*S+S/2,r:52,a:.62*fl,c:[255,110,30]});}
    });
    iceCubes.forEach(function(c){L.push({x:c.x*S+S/2,y:c.y*S+S/2,r:38,a:.42,c:[130,210,255]});});
    if(boss){
      if(boss.shots)boss.shots.forEach(function(sh){
        L.push({x:sh.x*S+S/2,y:sh.y*S+S/2,r:sh.big?60:(sh.ice?38:34),a:sh.big?.5:.4,c:sh.ice?[140,215,255]:[255,160,70]});
      });
      if(boss.letter)L.push({x:boss.letter.x*S+S/2,y:boss.letter.y*S+S/2,r:50,a:.75,c:[255,215,60]});
      if(boss.gLetter)L.push({x:boss.gLetter.x*S+S/2,y:boss.gLetter.y*S+S/2,r:54,a:.75,c:[124,252,0]});
      L.push({x:boss.bx*S+S/2,y:10,r:54,a:adventureChapter===CHAPTERS.length-1?.45:.25,c:adventureChapter===CHAPTERS.length-1?[255,40,40]:[255,200,150]});
    }
    return L;
  }
  function uDots(L){
    var i,j,k,l,I,R,G,B,dx,dy,d2,kk,x,y,m,rad,halo=!U_LITE;
    for(i=0;i<N;i++)for(j=0;j<N;j++){
      x=i*S+S/2;y=j*S+S/2;I=R=G=B=0;
      for(k=0;k<L.length;k++){
        l=L[k];dx=x-l.x;dy=y-l.y;d2=dx*dx+dy*dy;
        if(d2<l.r*l.r){kk=1-Math.sqrt(d2)/l.r;kk=kk*kk*l.a;I+=kk;R+=l.c[0]*kk;G+=l.c[1]*kk;B+=l.c[2]*kk;}
      }
      if(I>.02){
        m=I>1.4?1.4:I;R=(R/I)|0;G=(G/I)|0;B=(B/I)|0;rad=1.2+1.9*m;
        if(halo&&m>.4){ctx.fillStyle='rgba('+R+','+G+','+B+','+(.13*m)+')';ctx.beginPath();ctx.arc(x,y,5+4*m,0,6.283);ctx.fill();}
        ctx.fillStyle='rgba('+R+','+G+','+B+','+Math.min(1,.28+.72*m)+')';
        ctx.beginPath();ctx.arc(x,y,rad,0,6.283);ctx.fill();
      }else{
        ctx.fillStyle='rgba(130,185,150,.15)';ctx.beginPath();ctx.arc(x,y,1.1,0,6.283);ctx.fill();
      }
    }
  }
  function uStreak(x,y,len,rgb,a){
    var g=ctx.createLinearGradient(x-len,y,x+len,y),k=rgb[0]+','+rgb[1]+','+rgb[2];
    g.addColorStop(0,'rgba('+k+',0)');g.addColorStop(.5,'rgba('+k+','+a+')');g.addColorStop(1,'rgba('+k+',0)');
    ctx.fillStyle=g;ctx.fillRect(x-len,y-.8,len*2,1.6);
    g=ctx.createLinearGradient(x,y-len*.6,x,y+len*.6);
    g.addColorStop(0,'rgba('+k+',0)');g.addColorStop(.5,'rgba('+k+','+(a*.8)+')');g.addColorStop(1,'rgba('+k+',0)');
    ctx.fillStyle=g;ctx.fillRect(x-.7,y-len*.6,1.4,len*1.2);
  }
  function uLights(){
    if(!snake||!snake.length)return;
    var L=uBuildLights(),i,l,p,a,boost=1+uFlash*.6,t=uTime,mc=U_MOTE[zone]||U_MOTE.normal;
    ctx.save();ctx.globalCompositeOperation='lighter';
    for(i=0;i<L.length;i++){l=L[i];uGlow(l.x,l.y,l.r,l.a*boost,l.c);}
    uDots(L);
    ctx.globalAlpha=1;
    for(i=0;i<(U_LITE?10:uMotes.length);i++){
      p=uMotes[i];a=.2+.35*(.5+.5*Math.sin(t*2*p.sp+p.ph));
      uGlow(p.x,p.y,p.r*3.2,a,mc);
    }
    ctx.restore();
  }
  // طبقة المؤثرات فوق العناصر: لمعات النجوم، الجسيمات، الموجات
  function uFx(){
    var i,p,a,t=uTime;
    ctx.save();ctx.globalCompositeOperation='lighter';ctx.globalAlpha=1;
    var pulse=.6+.4*Math.sin(t*6);
    if(food)uStreak(food[0]*S+S/2,food[1]*S+S/2,30,[255,170,150],.5*pulse);
    if(mg)uStreak(mg.x*S+S/2,mg.y*S+S/2,26,[255,220,120],.5*pulse);
    if(boss&&boss.letter)uStreak(boss.letter.x*S+S/2,boss.letter.y*S+S/2,24,[255,235,150],.5*pulse);
    for(i=0;i<uParts.length;i++){
      p=uParts[i];a=p.l/p.m;uGlow(p.x,p.y,p.s*2.3*(.4+.6*a),a,p.c);
    }
    for(i=0;i<uRings.length;i++){
      p=uRings[i];a=p.l/p.m;
      ctx.globalAlpha=Math.min(1,a*.95);ctx.lineWidth=p.w*(.4+a);
      ctx.strokeStyle='rgb('+p.c[0]+','+p.c[1]+','+p.c[2]+')';
      ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,6.283);ctx.stroke();
    }
    ctx.restore();
  }

  // ---------- لمسات أخيرة: Bloom · تعتيم الحواف · انعكاس الزجاج ----------
  function uPost(){
    ctx.setTransform(U_SCALE,0,0,U_SCALE,0,0);
    ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
    uB1c.imageSmoothingEnabled=true;uB2c.imageSmoothingEnabled=true;uB3c.imageSmoothingEnabled=true;
    uB1c.drawImage(cv,0,0,cv.width,cv.height,0,0,160,160);
    uB2c.drawImage(uB1,0,0,160,160,0,0,80,80);
    uB3c.drawImage(uB2,0,0,80,80,0,0,40,40);
    ctx.imageSmoothingEnabled=true;ctx.globalCompositeOperation='lighter';
    ctx.globalAlpha=.20;ctx.drawImage(uB2,0,0,320,320);
    ctx.globalAlpha=.14;ctx.drawImage(uB3,0,0,320,320);
    ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
    var g=ctx.createRadialGradient(160,160,95,160,160,235);
    g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(0,0,0,.6)');
    ctx.fillStyle=g;ctx.fillRect(0,0,320,320);
    g=ctx.createLinearGradient(0,0,320,320);
    g.addColorStop(0,'rgba(255,255,255,.075)');g.addColorStop(.38,'rgba(255,255,255,0)');
    ctx.fillStyle=g;ctx.fillRect(0,0,320,320);
    var cx=-70+((uTime%6.5)/6.5)*460;
    g=ctx.createLinearGradient(cx-34,0,cx+34,26);
    g.addColorStop(0,'rgba(255,255,255,0)');g.addColorStop(.5,'rgba(255,255,255,.06)');g.addColorStop(1,'rgba(255,255,255,0)');
    ctx.fillStyle=g;ctx.fillRect(0,0,320,320);
    ctx.lineWidth=1.2;
    ctx.strokeStyle='rgba(255,255,255,.18)';ctx.beginPath();ctx.moveTo(.6,319);ctx.lineTo(.6,.6);ctx.lineTo(319,.6);ctx.stroke();
    ctx.strokeStyle='rgba(0,0,0,.45)';ctx.beginPath();ctx.moveTo(319.4,.6);ctx.lineTo(319.4,319.4);ctx.lineTo(.6,319.4);ctx.stroke();
  }
  function uStone(x,y){
    var g=ctx.createLinearGradient(x+2,y+2,x+S-2,y+S-2);
    g.addColorStop(0,'#9aa596');g.addColorStop(.5,'#5d665a');g.addColorStop(1,'#2e352c');
    ctx.fillStyle=g;drawRoundRect(x+2,y+2,S-4,S-4,5);
    ctx.strokeStyle='rgba(255,255,255,.38)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x+4,y+S-6);ctx.lineTo(x+4,y+5);ctx.lineTo(x+S-6,y+4);ctx.stroke();
    ctx.fillStyle='rgba(0,0,0,.34)';ctx.fillRect(x+7,y+8,4,3);ctx.fillRect(x+11,y+12,3,3);
  }
  function uGloss(px,py,isHead){
    var cx=px+S/2,cy=py+S/2,dx=uKey.x-cx,dy=uKey.y-cy,d=Math.sqrt(dx*dx+dy*dy)||1,near=Math.max(0,1-d/170),ang;
    dx/=d;dy/=d;ang=Math.atan2(dy,dx);
    ctx.save();ctx.globalCompositeOperation='lighter';
    ctx.fillStyle='rgba(255,255,255,'+((isHead?.10:.08)+.22*near)+')';
    ctx.beginPath();ctx.ellipse(cx+dx*3.4,cy+dy*3.4,isHead?2.6:3.3,isHead?1.7:2,ang,0,6.283);ctx.fill();
    ctx.strokeStyle='rgba(130,255,210,'+(.12+.1*near)+')';ctx.lineWidth=1.2;
    ctx.beginPath();ctx.arc(cx,cy,S*.36,ang+Math.PI-.9,ang+Math.PI+.9);ctx.stroke();
    ctx.restore();
  }

  function draw(){
    updateEffBar();
    var U=isU();
    ctx.setTransform(U_SCALE,0,0,U_SCALE,0,0);ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
    var cs=getComputedStyle(document.documentElement);
    var lcd=cs.getPropertyValue('--lcd'),ink=cs.getPropertyValue('--ink'),gh=cs.getPropertyValue('--ghost');
    if(U){uBegin();ink='#a8e07a';lcd='#0b120d';gh='rgba(130,185,150,.15)';uBoard();}
    else if(graphicsQuality==='low'){ctx.fillStyle=lcd;ctx.fillRect(0,0,320,320);}
    else {var board=ctx.createLinearGradient(0,0,320,320);board.addColorStop(0,lcd);board.addColorStop(1,darkMode?'#101810':'#b9d69a');ctx.fillStyle=board;ctx.fillRect(0,0,320,320);}
    if(graphicsQuality==='high'){ctx.save();ctx.strokeStyle='rgba(255,255,255,.07)';ctx.lineWidth=1;ctx.strokeRect(1,1,318,318);ctx.restore();}
    var zt=ZONE_INFO[zone]&&ZONE_INFO[zone].tint;
    if(zt){ctx.fillStyle=zt;ctx.fillRect(0,0,320,320);}
    ctx.fillStyle=gh;
    if(!U)for(var i=0;i<N;i++)for(var j=0;j<N;j++)ctx.fillRect(i*S+9,j*S+9,2,2);
    if(DIFF[diffKey].walls){
      if(U){ctx.save();ctx.shadowColor='#ff5a3c';ctx.shadowBlur=12;ctx.strokeStyle='#ff8a5a';ctx.lineWidth=3;ctx.strokeRect(2,2,316,316);ctx.restore();}
      else{ctx.strokeStyle=ink;ctx.lineWidth=4;ctx.strokeRect(2,2,316,316)}
    }
    if(U){uShadows();uLights();}
    
    if(hasEff('ghost')){
      ctx.strokeStyle=ink;
      ctx.lineWidth=2;
      snake.forEach(function(s){ctx.strokeRect(s[0]*S+2,s[1]*S+2,S-4,S-4)});
    } else {
      if(invisT>0)ctx.globalAlpha=0.12;
      for(var k = snake.length - 1; k >= 0; k--){
        drawSnakeSegment(snake[k][0], snake[k][1], k, snake.length);
      }
      ctx.globalAlpha=1;
    }

    if(pw&&(pw.life>15||pw.life%2===0)){
      var px=pw.x*S,py=pw.y*S;
      ctx.font='bold 13px sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';
      if(PW[pw.t].bad){
        ctx.fillStyle='#c62828';drawRoundRect(px+1,py+1,S-2,S-2,4);
        ctx.strokeStyle='#ffcdd2';ctx.lineWidth=1.5;ctx.strokeRect(px+3,py+3,S-6,S-6);
        ctx.fillStyle='#ffffff';ctx.fillText(PW[pw.t].l,px+S/2,py+S/2+1);
      }else{
        ctx.strokeStyle=ink;ctx.lineWidth=2;ctx.strokeRect(px+2,py+2,S-4,S-4);
        ctx.fillStyle=ink;ctx.fillText(PW[pw.t].l,px+S/2,py+S/2+1);
      }
    }
    
    if(food){
      ctx.save();ctx.shadowColor='rgba(255,70,70,.65)';ctx.shadowBlur=9;
      ctx.fillStyle='#e64b4b';
      drawRoundRect(food[0]*S+3,food[1]*S+4,S-6,S-7, 5);ctx.restore();
      ctx.fillStyle='#556b4f';
      ctx.fillRect(food[0]*S+9,food[1]*S+1,3,4);
      if(graphicsQuality!=='low'){ctx.fillStyle='rgba(255,255,255,.72)';ctx.beginPath();ctx.arc(food[0]*S+7,food[1]*S+8,2,0,Math.PI*2);ctx.fill();}
    }

    if(mg&&(mg.life>25||mg.life%2===0)){
      ctx.save();ctx.shadowColor='rgba(255,167,38,.8)';ctx.shadowBlur=8;
      ctx.font='17px serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle='#000';
      ctx.fillText('🥭',mg.x*S+S/2,mg.y*S+S/2+1);ctx.restore();
    }

    drawBossLayer(ink,lcd);
    iceCubes.forEach(function(c){
      var left=ICE_CUBE_LIFE-c.age;
      if(left<2000&&Math.floor(frameTick/4)%2===0)return;
      var x=c.x*S,y=c.y*S;
      ctx.fillStyle='#8fd3ff';drawRoundRect(x+1,y+1,S-2,S-2,4);
      ctx.fillStyle='#d9f3ff';ctx.fillRect(x+4,y+4,S-10,4);
      ctx.fillStyle='#ffffff';ctx.fillRect(x+4,y+4,3,3);
      ctx.strokeStyle='#4aa3d8';ctx.lineWidth=1.5;ctx.strokeRect(x+2,y+2,S-4,S-4);
    });
    stones.forEach(function(s){
      var x=s[0]*S,y=s[1]*S;
      if(s[2]){
        var pulse=Math.floor(frameTick/6)%2===0;
        ctx.save();ctx.shadowColor='rgba(255,80,0,.9)';ctx.shadowBlur=pulse?12:6;
        ctx.fillStyle=pulse?'#ff3b0f':'#e02a00';drawRoundRect(x+1,y+1,S-2,S-2,5);ctx.restore();
        ctx.fillStyle='#ffb12b';ctx.fillRect(x+5,y+5,4,4);ctx.fillRect(x+11,y+10,4,4);
        ctx.fillStyle='#fff1a8';ctx.fillRect(x+8,y+12,2,2);
        return;
      }
      if(U){uStone(x,y);return;}
      ctx.fillStyle=ink;
      drawRoundRect(x+2,y+2,S-4,S-4, 3);
      ctx.fillStyle=lcd;ctx.fillRect(x+6,y+6,3,3);ctx.fillRect(x+11,y+11,3,3);
    });

    if(frozenT>0){
      ctx.fillStyle='rgba(150,220,255,0.65)';
      snake.forEach(function(sg){ctx.fillRect(sg[0]*S+1,sg[1]*S+1,S-2,S-2);});
      ctx.font='14px serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle='#000';
      ctx.fillText('🧊',snake[0][0]*S+S/2,snake[0][1]*S+S/2);
    }
    if(U)uFx();
    drawZoneOverlay();
    drawBossOverlay();
    if(U)uPost();
  }

  function showMenu(){
    running=false;paused=false;inGame=false;over_=false;
    if(gameLoopId)cancelAnimationFrame(gameLoopId);
    statScores.style.display='none';
    pauseOverlay.style.display='none';pauseBtn.style.display='none';pauseBtn.textContent='⏸';pauseBtn.setAttribute('aria-label','إيقاف مؤقت');
    statTitle.style.display='block';
    homeBtn.style.display='none';
    menuOverlay.style.display='flex';
    overOverlay.style.display='none';
    shopOverlay.style.display='none';
    settingsOverlay.style.display='none';
    storyOverlay.style.display='none';adventureCompleteOverlay.style.display='none';
    gameMode='classic';boss=null;mg=null;frozenT=0;zone='normal';updateZoneUI();pendingShield=false;pendingSlow=false;pregameOverlay.style.display='none';updateAdventureHUD();
    msg.textContent='';loadData();draw();
  }
  // ===== سؤال التعزيزات قبل بدء كل جيم =====
  function renderPregame(){
    pregameShieldBtn.style.display=shieldStock>0?'block':'none';
    pregameSlowBtn.style.display=slowStock>0?'block':'none';
    pregameShieldBtn.textContent='🛡️ درع الحماية (لديك '+shieldStock+'): '+(choiceShield?'سأستخدمه ✓':'لن أستخدمه');
    pregameSlowBtn.textContent='🐢 تعزيز البطء (لديك '+slowStock+'): '+(choiceSlow?'سأستخدمه ✓':'لن أستخدمه');
    pregameShieldBtn.classList.toggle('on',choiceShield);
    pregameSlowBtn.classList.toggle('on',choiceSlow);
  }
  function beginGame(startFn){
    if(shieldStock<=0&&slowStock<=0){pendingShield=false;pendingSlow=false;startFn();return;}
    pregameStartFn=startFn;renderPregame();pregameOverlay.style.display='flex';
  }
  pregameShieldBtn.onclick=function(){choiceShield=!choiceShield;renderPregame();};
  pregameSlowBtn.onclick=function(){choiceSlow=!choiceSlow;renderPregame();};
  pregameBackBtn.onclick=function(){pregameOverlay.style.display='none';pregameStartFn=null;};
  pregameStartBtn.onclick=function(){
    var useS=choiceShield&&shieldStock>0,useL=choiceSlow&&slowStock>0;
    pendingShield=useS;pendingSlow=useL;
    pregameOverlay.style.display='none';
    var f=pregameStartFn;pregameStartFn=null;
    if(f)f();
    var note=[];if(useS)note.push('🛡️ الدرع مفعّل');if(useL)note.push('🐢 البطء مفعّل');
    if(note.length)msg.textContent=(msg.textContent?msg.textContent+' · ':'')+note.join(' · ');
  };

  function startGameFromMenu(){beginGame(doStartClassic);}
  function doStartClassic(){
    sfx('start');
    h2Count=0;gameMode='classic';storyOverlay.style.display='none';adventureCompleteOverlay.style.display='none';
    menuOverlay.style.display='none';
    statTitle.style.display='none';
    statScores.style.display='flex';
    homeBtn.style.display='block';
    inGame=true;reset();go();
  }

  document.addEventListener('keydown',function(e){
    var key=e.key;
    if(key==='p'||key==='P'||key===' '){
      if(inGame&&!over_){e.preventDefault();togglePause();}
      return;
    }
    var m={ArrowUp:'u',ArrowDown:'d',ArrowLeft:'l',ArrowRight:'r',w:'u',W:'u',s:'d',S:'d',a:'l',A:'l',d:'r',D:'r'}[key];
    if(m){e.preventDefault();setDir(m)}
    if(key==='Escape'&&inGame)showMenu();
  });
  pauseBtn.addEventListener('click',togglePause);
  resumeBtn.addEventListener('click',resumeGame);
  pauseRestartBtn.addEventListener('click',function(){beginGame(function(){reset();go();});});
  pauseMenuBtn.addEventListener('click',showMenu);
  document.addEventListener('visibilitychange',function(){
    if(document.hidden&&inGame&&running)pauseGame();
  });
  document.querySelectorAll('.pad button').forEach(function(b){
    b.addEventListener('pointerdown',function(e){e.preventDefault();setDir(b.dataset.d);});
    b.addEventListener('keydown',function(e){if(e.key==='Enter'){e.preventDefault();setDir(b.dataset.d);}});
  });
  
  document.getElementById('menuStart').addEventListener('click',startGameFromMenu);
  document.getElementById('restartBtn').addEventListener('click',function(){beginGame(function(){reset();go();});});
  document.getElementById('toMenuBtn').addEventListener('click',showMenu);
  homeBtn.addEventListener('click',showMenu);

  document.querySelectorAll('#diff button').forEach(function(b){
    b.addEventListener('click',function(){
      diffKey=b.dataset.k;
      document.querySelectorAll('#diff button').forEach(function(x){x.classList.toggle('on',x===b)});
      loadData();sfx('click');
    });
  });

  soundToggle.addEventListener('click',function(){
    soundOn=!soundOn;soundToggle.textContent=soundOn?'🔊':'🔇';
    applyVolumes();syncMusic();if(soundOn)sfx('click');
  });
  padToggle.addEventListener('click',function(){
    padVisible=!padVisible;padContainer.classList.toggle('hidden',!padVisible);
    padToggle.style.opacity=padVisible?'1':'0.5';
  });

  // ===== التحكم باللمس: اسحب في أي مكان على الشاشة، ويُحسب الاتجاه فورًا أثناء السحب =====
  var swipeId=null,swipeX=0,swipeY=0;
  function findTouch(list,id){
    for(var i=0;i<list.length;i++)if(list[i].identifier===id)return list[i];
    return null;
  }
  document.addEventListener('touchstart',function(e){
    if(!inGame||paused||over_||controlMode==='pad')return;
    if(swipeId!==null)return;
    var t=e.changedTouches[0];
    swipeId=t.identifier;swipeX=t.clientX;swipeY=t.clientY;
  },{passive:true});
  document.addEventListener('touchmove',function(e){
    if(swipeId===null)return;
    if(!inGame||paused||over_||controlMode==='pad'){swipeId=null;return;}
    var t=findTouch(e.changedTouches,swipeId);if(!t)return;
    if(e.cancelable)e.preventDefault();
    var dx=t.clientX-swipeX,dy=t.clientY-swipeY;
    if(Math.max(Math.abs(dx),Math.abs(dy))<swipeThreshold)return;
    setDir(Math.abs(dx)>Math.abs(dy)?(dx>0?'r':'l'):(dy>0?'d':'u'));
    swipeX=t.clientX;swipeY=t.clientY; // نقطة جديدة: يمكنك الالتفاف مرة أخرى دون رفع إصبعك
  },{passive:false});
  function endSwipe(e){if(swipeId!==null&&findTouch(e.changedTouches,swipeId))swipeId=null;}
  document.addEventListener('touchend',endSwipe,{passive:true});
  document.addEventListener('touchcancel',endSwipe,{passive:true});
  // اللمس على لوحة اللعبة قبل بدء الحركة (الثعبان واقف) يبدأ الجولة
  cv.addEventListener('contextmenu',function(e){e.preventDefault();});

  loadData();reset();updateAdStatus();
})();
