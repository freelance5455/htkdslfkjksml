(function(){
  var N=16,S=20,cv=document.getElementById('c'),ctx=cv.getContext('2d');
  var scoreEl=document.getElementById('score'),menuBestEl=document.getElementById('menuBest');
  var menuBestApplesEl=document.getElementById('menuBestApples');
  var applesCountEl=document.getElementById('applesCount'),menuApplesEl=document.getElementById('menuApples');
  var finalApplesEl=document.getElementById('finalApples'),finalGameApplesEl=document.getElementById('finalGameApples');
  var shopApplesEl=document.getElementById('shopApples');
  var lvlEl=document.getElementById('lvl'),msg=document.getElementById('msg');
  var statScores=document.getElementById('stat-scores'),statTitle=document.getElementById('stat-title'),homeBtn=document.getElementById('homeBtn');
  var menuOverlay=document.getElementById('menuOverlay'),overOverlay=document.getElementById('overOverlay'),shopOverlay=document.getElementById('shopOverlay');
  var pauseOverlay=document.getElementById('pauseOverlay'),pauseBtn=document.getElementById('pauseBtn');
  var resumeBtn=document.getElementById('resumeBtn'),pauseRestartBtn=document.getElementById('pauseRestartBtn'),pauseMenuBtn=document.getElementById('pauseMenuBtn');
  var settingsOverlay=document.getElementById('settingsOverlay');
  var finalScoreEl=document.getElementById('finalScore'),newRecordMsg=document.getElementById('newRecordMsg'),overReason=document.getElementById('overReason');
  var newAppleRecordMsg=document.getElementById('newAppleRecordMsg');
  var helper3BonusMsg=document.getElementById('helper3BonusMsg');
  var padContainer=document.getElementById('padContainer'),padToggle=document.getElementById('padToggle'),soundToggle=document.getElementById('soundToggle');
  var revive150Btn=document.getElementById('revive150Btn'),revive500Btn=document.getElementById('revive500Btn');
  var reviveSection=document.getElementById('reviveSection'),powerChoiceSection=document.getElementById('powerChoiceSection');
  var choice1Btn=document.getElementById('choice1'),choice2Btn=document.getElementById('choice2');
  var fpsSelect=document.getElementById('fpsSelect');
  var shopBtn=document.getElementById('shopBtn'),closeShopBtn=document.getElementById('closeShopBtn');
  var settingsBtn=document.getElementById('settingsBtn'),closeSettingsBtn=document.getElementById('closeSettingsBtn'),resetSkinBtn=document.getElementById('resetSkinBtn');
  var nightmareToggleBtn=document.getElementById('nightmareToggleBtn'),darkModeToggleBtn=document.getElementById('darkModeToggleBtn');
  var nightmareBadge=document.getElementById('nightmareBadge');
  var buySkin1Btn=document.getElementById('buySkin1'),buySkin2Btn=document.getElementById('buySkin2');
  var tabSkins=document.getElementById('tabSkins'),tabHelpers=document.getElementById('tabHelpers');
  var skinsList=document.getElementById('skinsList'),helpersList=document.getElementById('helpersList');
  var buyHelper1Btn=document.getElementById('buyHelper1'),buyHelper2Btn=document.getElementById('buyHelper2');
  var buyHelper3Btn=document.getElementById('buyHelper3'),buyHelper4Btn=document.getElementById('buyHelper4');
  var menuAdventureBtn=document.getElementById('menuAdventure'),storyOverlay=document.getElementById('storyOverlay');
  var storyChapterTitle=document.getElementById('storyChapterTitle'),storyProgress=document.getElementById('storyProgress');
  var storyDescription=document.getElementById('storyDescription'),storyObjective=document.getElementById('storyObjective');
  var storyStartBtn=document.getElementById('storyStartBtn'),storyBackBtn=document.getElementById('storyBackBtn');
  var adventureCompleteOverlay=document.getElementById('adventureCompleteOverlay');
  var adventureCompleteTitle=document.getElementById('adventureCompleteTitle'),adventureCompleteText=document.getElementById('adventureCompleteText');
  var adventureRewardText=document.getElementById('adventureRewardText'),adventureNextBtn=document.getElementById('adventureNextBtn');
  var adventureMenuBtn=document.getElementById('adventureMenuBtn'),gameModeLabel=document.getElementById('gameModeLabel');
  var accountNameInput=document.getElementById('accountNameInput'),saveAccountBtn=document.getElementById('saveAccountBtn');
  var accountStatus=document.getElementById('accountStatus'),userAccountBadge=document.getElementById('userAccountBadge');
  var exportSaveBtn=document.getElementById('exportSaveBtn'),importSaveBtn=document.getElementById('importSaveBtn'),importSaveInput=document.getElementById('importSaveInput');
  var tabBoost=document.getElementById('tabBoost'),boostList=document.getElementById('boostList');
  var buyShieldBtn=document.getElementById('buyShieldBtn'),buyH1UpBtn=document.getElementById('buyH1UpBtn'),shieldStockEl=document.getElementById('shieldStock');
  var tabCharge=document.getElementById('tabCharge'),chargeList=document.getElementById('chargeList');
  var buySlowBtn=document.getElementById('buySlowBtn'),slowStockEl=document.getElementById('slowStock');
  var buyFarmerUpBtn=document.getElementById('buyFarmerUpBtn'),buyLootUpBtn=document.getElementById('buyLootUpBtn'),buyWizUpBtn=document.getElementById('buyWizUpBtn');
  var buyPack1Btn=document.getElementById('buyPack1Btn'),buyPack5Btn=document.getElementById('buyPack5Btn'),watchAdShopBtn=document.getElementById('watchAdShopBtn');
  var chargeStatusEl=document.getElementById('chargeStatus'),chargeNoteEl=document.getElementById('chargeNote');
  var pregameOverlay=document.getElementById('pregameOverlay'),pregameShieldBtn=document.getElementById('pregameShieldBtn'),pregameSlowBtn=document.getElementById('pregameSlowBtn');
  var pregameStartBtn=document.getElementById('pregameStartBtn'),pregameBackBtn=document.getElementById('pregameBackBtn');
  var mangoCountEl=document.getElementById('mangoCount'),menuMangoesEl=document.getElementById('menuMangoes'),shopMangoesEl=document.getElementById('shopMangoes'),gameMangoMsg=document.getElementById('gameMangoMsg');
  var fpsValueEl=document.getElementById('fpsValue'),fpsSettingsValueEl=document.getElementById('fpsSettingsValue');
  var reviveAdBtn=document.getElementById('reviveAdBtn'),adStatusEl=document.getElementById('adStatus');


  var DIFF={easy:{speed:170,every:2,walls:false},normal:{speed:130,every:1,walls:false},hard:{speed:100,every:1,walls:true}};
  var ADV_GOAL=10,ADV_LEVELS=10,LEVEL_REWARD=15;
  var CHAPTERS=[
    {name:'صحوة الغابة',diff:'easy',reward:150,
     story:'كان الثعبان يعيش سعيدًا مع حبيبته الثعبانة الوردية، حتى جاء الثعبان الأسود في ليلة مظلمة وخطفها وهرب بها. أقسم البطل أن يعيدها مهما كان الثمن، وبدأ رحلته من الغابة. اجمع 10 تفاحات في كل ليفل لتزداد قوتك.',
     bossName:'العقرب الحجري',bossEmoji:'🦂',bossNeed:3,throwEvery:2400,fall:150,moveMs:230,bigEvery:4000,bigFall:190,
     bossStory:'العقرب الحجري يرمي حجارة صغيرة، وكل 4 ثوانٍ يرمي حجرًا ضخمًا يغطي 3 مربعات! بعد 30 ثانية يظهر حرف B، اجمع 3 حروف B لتدمير الزعيم.',
     outro:'تحطّم العقرب الحجري وانفتح طريق الكهف. أثر الثعبانة الوردية يقودك إلى الأمام!'},
    {name:'كهف الصخور',diff:'hard',reward:220,
     story:'في عمق الكهف وجد البطل وشاحًا يخص الثعبانة الوردية. الثعبان الأسود مرّ من هنا! جدران الكهف قاتلة هنا (الصعوبة صعبة)، فانتبه.',
     bossName:'عملاق الكهف',bossEmoji:'👹',bossNeed:4,throwEvery:2300,fall:130,moveMs:190,poolEvery:5000,
     bossStory:'عملاق الكهف يرمي برَكًا تغطي اللوحة طولًا كل 5 ثوانٍ وتختفي بعد 10 ثوانٍ، وتبطّئ ثعبانك! الصعوبة صعبة والجدران قاتلة. اجمع 4 حروف B بعد 30 ثانية.',
     outro:'سقط عملاق الكهف! سمعت من بعيد صدى صوت الثعبانة الوردية تنادي من وادي العواصف.'},
    {name:'وادي العواصف',diff:'normal',reward:300,
     story:'الرياح تعصف في الوادي وقوى غامضة تظهر في كل مكان. اجمع التفاح واستفد من القوى قبل أن تختفي.',
     bossName:'تنين العاصفة',bossEmoji:'🐲',bossNeed:7,throwEvery:0,fall:115,moveMs:160,dashEvery:3000,
     bossStory:'تنين العاصفة يندفع نحوك كل 3 ثوانٍ على طول الصف أو العمود كله! اخرج من الخط الأحمر قبل أن يصل. اجمع 7 حروف B بعد 30 ثانية.',
     outro:'هدأت العاصفة بعد سقوط التنين، وظهرت قلعة سوداء على الأفق. هناك يحتجزون الثعبانة الوردية!'},
    {name:'قلعة الظلال',diff:'normal',reward:420,
     story:'وصلت إلى قلعة الثعبان الأسود. الجليد يغطي الممرات والبرد يشتد، فاحذر كل حركة وأنت تقترب من حبيبتك.',
     bossName:'فارس الظلال',bossEmoji:'💀',bossNeed:9,throwEvery:0,fall:100,moveMs:130,iceEvery:6000,
     bossStory:'فارس الظلال يحاول تجميدك ثم يرميك بحجر الثلج! كل 6 ثوانٍ تظهر 4 خطوط جليد عشوائية (أفقية أو عمودية). إن تجمّدت اضغط الأسهم بسرعة لتكسر الجليد. اجمع 9 حروف B بعد 30 ثانية.',
     outro:'سقط فارس الظلال وانفتحت البوابة الأخيرة. الثعبان الأسود ينتظرك في عرينه!'},
    {name:'عرين الثعبان الأسود',diff:'hard',reward:700,
     story:'هذا هو العرين الأخير. الثعبانة الوردية سجينة في الداخل، والثعبان الأسود يعرف أنك قادم. لا مجال للتراجع.',
     bossName:'الثعبان الأسود',bossEmoji:'🐍',bossNeed:20,throwEvery:1800,fall:95,moveMs:110,strikeEvery:10000,dark:true,
     bossStory:'الثعبان الأسود يُغرق العرين في الظلام ويرمي 3 أحجار كبيرة تغطي اللوحة كلها! الطريق الوحيد للنجاة هو حرف G الذي يظهر قبل الضربة، التقطه قبل أن تموت. اجمع 20 حرف B بعد 30 ثانية.',
     outro:'انكسر ختم الثعبان الأسود وتحررت الثعبانة الوردية! عادا معًا إلى الغابة، وعاد النور إلى العالم.'}
  ];
  var SNAKE_COLORS=[
    {id:'green',n:'أخضر',c:'#2d8a2d'},{id:'blue',n:'أزرق',c:'#2f80ed',h:'#1f5fbf',s:'#8bbcff'},
    {id:'red',n:'أحمر',c:'#d62828',h:'#a31515',s:'#ff8a8a'},{id:'purple',n:'بنفسجي',c:'#8e44ad',h:'#5a2a8c',s:'#d2a8f0'},
    {id:'orange',n:'برتقالي',c:'#f08a00',h:'#b85c00',s:'#ffd08a'},{id:'pink',n:'وردي',c:'#ec407a',h:'#c2185b',s:'#ffb3cf'},
    {id:'cyan',n:'سماوي',c:'#00acc1',h:'#007c91',s:'#8ceaf5'},{id:'yellow',n:'أصفر',c:'#e6c200',h:'#b59b00',s:'#fff3a0'},
    {id:'white',n:'أبيض',c:'#eceff1',h:'#b0bec5',s:'#ffffff'}
  ];
  var snakeColor='green',adventureLevel=0,boss=null;
  var controlMode='both',swipeThreshold=20,dirQueue=[];
  var controlSelect=document.getElementById('controlSelect'),swipeSelect=document.getElementById('swipeSelect');
  var diffKey='normal',best=0,bestApples=0,apples=0,soundOn=true,padVisible=true,inGame=false,paused=false;
  var currentFps=60,targetFpsInterval=1000/60;
  var accountProfile={name:'',id:'',createdAt:0};
  var gameMode='classic',adventureChapter=0,adventureFinished=false;
  var shieldCharges=0,mangoes=0,shieldStock=0,slowStock=0,h1Up=false,farmerUp=false,lootUp=false,wizUp=false;
  var gameMangoesEarned=0,h2Count=0,frozenT=0,mg=null;
  var pendingShield=false,pendingSlow=false,pregameStartFn=null,choiceShield=true,choiceSlow=true;
  var pendingPurchase=null,rewardPurpose='revive';
  var activeSkin='default';
  var unlockedSkins={default:true, skin1:false, skin2:false, old:false, small:false, black:false, invisible:false, strong:false};
  var unlockedHelpers={h1:false, h2:false, h3:false, h4:false};
  
  // مساعد واحد فقط يمكن تجهيزه واستخدامه في الجيم (null أو 'h1' أو 'h2' أو 'h3' أو 'h4')
  var activeHelper = null;

  var nightmareMode=false;
  var darkMode=false;
  var hasUsedRewardedRevive=false;
  var gameApplesEarned=0;
  var h1Timer=0, h2Timer=0, h4Timer=0;
  var fpsFrameCount=0,fpsWindowStart=0,measuredFps=0,rewardAdPending=false;

  function bestKey(){return 'snakeBest_'+diffKey+(nightmareMode?'_nm':'')}
  function bestApplesKey(){return 'snakeBestApples_'+diffKey+(nightmareMode?'_nm':'')}

  function updateAccountUI(){
    var name=(accountProfile&&accountProfile.name)||'';
    if(accountNameInput)accountNameInput.value=name;
    if(userAccountBadge){
      userAccountBadge.textContent=name?'👤 '+name:'';
      userAccountBadge.style.display=name?'inline-block':'none';
    }
    if(accountStatus)accountStatus.textContent=name?'تم حفظ ملف اللاعب محليًا باسم '+name+'.':'اللعب كضيف على هذا الجهاز.';
  }

  function isRewardedAdReady(){
    var bridge=window.SnakeAds||window.AndroidAds;
    return !!(bridge&&(typeof bridge.showRewardedAd==='function'||typeof bridge.showRewarded==='function'));
  }
  function updateAdStatus(){
    var ready=isRewardedAdReady();
    if(adStatusEl)adStatusEl.textContent=ready?'الإعلان المكافئ متصل عبر تطبيق Android.':'الإعلانات غير مهيأة: اربط AdMob في مشروع Android لتفعيل المكافأة.';
    if(reviveAdBtn){
      reviveAdBtn.disabled=!ready||hasUsedRewardedRevive;
      reviveAdBtn.textContent=hasUsedRewardedRevive?'✅ استُخدم إعلان الإحياء في هذه الجولة':(ready?'🎬 مشاهدة إعلان مكافأة للإحياء':'🎬 إعلان الإحياء غير متاح');
    }
    updateChargeUI();
  }
  function handleRewardedAdResult(earned){
    if(!rewardAdPending)return;
    rewardAdPending=false;
    var purpose=rewardPurpose;
    if(purpose==='shop'){
      if(earned){
        apples+=100;mangoes+=5;saveData();
        if(chargeNoteEl)chargeNoteEl.textContent='🎉 اكتمل الإعلان! حصلت على +100 🍎 و +5 🥭.';
        playTone(900,'triangle',0.2,0.08);
      }else{
        if(chargeNoteEl)chargeNoteEl.textContent='لم يكتمل الإعلان؛ لم تُمنح المكافأة.';
      }
      updateAdStatus();
      return;
    }
    updateAdStatus();
    if(earned){
      hasUsedRewardedRevive=true;
      msg.textContent='🎉 اكتملت مشاهدة الإعلان! تم إحياؤك.';
      updateAdStatus();
      reviveGame(null);
    }else{
      if(adStatusEl)adStatusEl.textContent='لم يكتمل الإعلان؛ لم تُمنح مكافأة الإحياء.';
      if(reviveAdBtn)reviveAdBtn.disabled=false;
    }
  }
  // يستدعيه جسر Android بعد معرفة نتيجة الإعلان المكافئ.
  window.onSnakeRewardedAdResult=handleRewardedAdResult;

  function showRewardedAd(purpose){
    purpose=(purpose==='shop')?'shop':'revive';
    if(!isRewardedAdReady()||rewardAdPending||(purpose==='revive'&&hasUsedRewardedRevive)){updateAdStatus();return;}
    rewardPurpose=purpose;
    var bridge=window.SnakeAds||window.AndroidAds;
    var show=bridge.showRewardedAd||bridge.showRewarded;
    rewardAdPending=true;
    if(purpose==='revive'){
      if(reviveAdBtn){reviveAdBtn.disabled=true;reviveAdBtn.textContent='⏳ جاري تحميل الإعلان...';}
      if(adStatusEl)adStatusEl.textContent='جارٍ طلب الإعلان المكافئ...';
    }else{
      if(chargeNoteEl)chargeNoteEl.textContent='⏳ جاري تحميل الإعلان...';
      if(watchAdShopBtn)watchAdShopBtn.disabled=true;
    }
    try{
      var result=show.call(bridge);
      if(result&&typeof result.then==='function'){
        result.then(function(value){handleRewardedAdResult(value===true||!!(value&&value.rewarded));})
          .catch(function(){handleRewardedAdResult(false);});
      }else if(typeof result==='boolean'){
        handleRewardedAdResult(result);
      }
      // إذا أعاد الجسر undefined فسيُنتظر callback: window.onSnakeRewardedAdResult(true/false).
    }catch(e){handleRewardedAdResult(false);}
  }

  // ===== الشراء بالمال الحقيقي (Google Play Billing عبر جسر Android) =====
  var PACKS=[
    {id:'pack_1usd',apples:600,mangoes:30,btn:buyPack1Btn},
    {id:'pack_5usd',apples:3000,mangoes:150,btn:buyPack5Btn}
  ];
  function getBillingBridge(){return window.SnakeBilling||window.AndroidBilling;}
  function isBillingReady(){var b=getBillingBridge();return !!(b&&typeof b.purchase==='function');}
  function updateChargeUI(){
    if(!chargeStatusEl)return;
    var billing=isBillingReady(),ads=isRewardedAdReady();
    chargeStatusEl.textContent=(billing?'الدفع متصل عبر Google Play. ':'الشراء بالمال الحقيقي غير مفعّل في نسخة الويب (يتطلب Google Play Billing في تطبيق Android). ')
      +(ads?'الإعلان المكافئ جاهز.':'الإعلان المكافئ غير مهيأ (يتطلب AdMob).');
    PACKS.forEach(function(pk){pk.btn.disabled=!billing||!!pendingPurchase;});
    watchAdShopBtn.disabled=!ads||rewardAdPending;
  }
  function handlePurchaseResult(productId,ok){
    if(!pendingPurchase||pendingPurchase!==productId)return;
    pendingPurchase=null;
    var pack=PACKS.filter(function(pk){return pk.id===productId;})[0];
    if(ok&&pack){
      apples+=pack.apples;mangoes+=pack.mangoes;saveData();
      chargeNoteEl.textContent='✅ تم الشراء بنجاح: +'+pack.apples+' 🍎 و +'+pack.mangoes+' 🥭';
      playTone(1000,'triangle',0.3,0.1);
    }else{
      chargeNoteEl.textContent='لم تكتمل عملية الشراء؛ لم تُضف أي مكافأة.';
    }
    updateChargeUI();
  }
  // يستدعيه جسر Android بعد تأكيد Google Play للشراء: window.onSnakePurchaseResult('pack_1usd', true)
  window.onSnakePurchaseResult=handlePurchaseResult;
  function buyPack(pack){
    var bridge=getBillingBridge();
    if(!isBillingReady()||pendingPurchase){updateChargeUI();return;}
    pendingPurchase=pack.id;
    chargeNoteEl.textContent='⏳ جاري فتح نافذة الدفع...';
    updateChargeUI();
    try{
      var result=bridge.purchase(pack.id);
      if(result&&typeof result.then==='function'){
        result.then(function(v){handlePurchaseResult(pack.id,v===true||!!(v&&v.purchased));})
          .catch(function(){handlePurchaseResult(pack.id,false);});
      }else if(typeof result==='boolean'){
        handlePurchaseResult(pack.id,result);
      }
      // إذا أعاد الجسر undefined فسيُنتظر callback: window.onSnakePurchaseResult(productId,true/false).
    }catch(e){handlePurchaseResult(pack.id,false);}
  }
  PACKS.forEach(function(pk){pk.btn.onclick=function(){buyPack(pk);};});
  watchAdShopBtn.onclick=function(){showRewardedAd('shop');};

  function buildColorPickers(){
    ['colorPicker','colorPickerStory'].forEach(function(id){
      var box=document.getElementById(id);if(!box)return;
      box.innerHTML='';
      SNAKE_COLORS.forEach(function(col){
        var b=document.createElement('button');
        b.type='button';b.className='swatch'+(col.id===snakeColor?' on':'');
        b.style.background=col.c;b.title=col.n;b.setAttribute('aria-label','لون '+col.n);
        b.onclick=function(){
          snakeColor=col.id;activeSkin='default';saveData();buildColorPickers();updateShopUI();draw();
          playTone(600,'sine',0.08,0.04);
        };
        box.appendChild(b);
      });
    });
  }

  function updateStoryUI(){
    var ch=CHAPTERS[Math.min(adventureChapter,CHAPTERS.length-1)];
    if(!ch)return;
    var isBoss=adventureLevel===ADV_LEVELS-1;
    storyChapterTitle.textContent='الفصل '+(adventureChapter+1)+': '+ch.name;
    storyProgress.textContent='الفصل '+(adventureChapter+1)+' من '+CHAPTERS.length+' · الليفل '+(adventureLevel+1)+' من '+ADV_LEVELS+(adventureFinished?' · اكتملت القصة':'');
    if(adventureFinished)storyDescription.textContent='لقد أنقذت الثعبانة الوردية وهزمت الثعبان الأسود! يمكنك إعادة المواجهة الأخيرة للتحدي.';
    else storyDescription.textContent=isBoss?('👹 الزعيم: '+ch.bossName+'. '+ch.bossStory):ch.story;
    if(isBoss)storyObjective.textContent='المهمة: تفادَ هجمات الزعيم، وبعد 30 ث اجمع '+ch.bossNeed+' حرف B (حرف B يدمّر الزعيم فقط). المكافأة: '+ch.reward+' 🍎';
    else storyObjective.textContent='المهمة: اجمع '+ADV_GOAL+' تفاحات للفوز بالليفل. المكافأة: '+(LEVEL_REWARD+adventureChapter*5)+' 🍎';
    storyStartBtn.textContent=adventureFinished?'إعادة المواجهة الأخيرة':(isBoss?'واجه الزعيم':'ابدأ الليفل '+(adventureLevel+1));
  }

  function updateAdventureHUD(){
    if(!gameModeLabel)return;
    if(gameMode==='adventure'){
      gameModeLabel.style.display='inline';
      if(boss)gameModeLabel.textContent='👹 ف'+(adventureChapter+1)+' · B '+boss.got+'/'+boss.need;
      else gameModeLabel.textContent='📖 ف'+(adventureChapter+1)+'-ل'+(adventureLevel+1)+' · '+eaten+'/'+ADV_GOAL;
    }else{
      gameModeLabel.style.display='none';
    }
  }

  function updateCurrencyUI(){
    applesCountEl.textContent=apples;menuApplesEl.textContent=apples+' 🍎';shopApplesEl.textContent=apples;
    mangoCountEl.textContent=mangoes;menuMangoesEl.textContent=mangoes+' 🥭';shopMangoesEl.textContent=mangoes;
  }

  function updateBoostUI(){
    if(!buyShieldBtn)return;
    shieldStockEl.textContent='لديك: '+shieldStock+' 🛡️';
    buyShieldBtn.disabled=mangoes<1;
    slowStockEl.textContent='لديك: '+slowStock+' 🐢';
    buySlowBtn.disabled=mangoes<5;
    [[buyH1UpBtn,h1Up,50],[buyFarmerUpBtn,farmerUp,70],[buyLootUpBtn,lootUp,100],[buyWizUpBtn,wizUp,150]].forEach(function(u){
      u[0].textContent=u[1]?'تم الشراء ✓':'ترقية · '+u[2]+' 🥭';
      u[0].disabled=u[1]||mangoes<u[2];
    });
  }

  buyShieldBtn.onclick=function(){
    if(mangoes<1){alert('تحتاج 1 🥭 منجة لشراء الدرع.');return;}
    mangoes--;shieldStock++;saveData();playTone(900,'triangle',0.18,0.08);
  };
  buySlowBtn.onclick=function(){
    if(mangoes<5){alert('تحتاج 5 🥭 منجات لشراء تعزيز البطء.');return;}
    mangoes-=5;slowStock++;saveData();playTone(900,'triangle',0.18,0.08);
  };
  function setupUpgrade(btn,isOwned,own,cost,name){
    btn.onclick=function(){
      if(isOwned())return;
      if(mangoes<cost){alert('تحتاج '+cost+' 🥭 منجة لتطوير '+name+'.');return;}
      mangoes-=cost;own();saveData();playTone(990,'triangle',0.2,0.1);
    };
  }
  setupUpgrade(buyH1UpBtn,function(){return h1Up;},function(){h1Up=true;},50,'مُدمّر الصخور');
  setupUpgrade(buyFarmerUpBtn,function(){return farmerUp;},function(){farmerUp=true;},70,'مزارع التفاح');
  setupUpgrade(buyLootUpBtn,function(){return lootUp;},function(){lootUp=true;},100,'حارس الغنائم');
  setupUpgrade(buyWizUpBtn,function(){return wizUp;},function(){wizUp=true;},150,'ساحر القوى');

  function applyDarkMode(){
    if(darkMode){
      document.documentElement.setAttribute('data-theme','dark');
      darkModeToggleBtn.textContent='مُفعّل';
      darkModeToggleBtn.style.background='#28a745';
    } else {
      document.documentElement.setAttribute('data-theme','light');
      darkModeToggleBtn.textContent='مُعطل';
      darkModeToggleBtn.style.background='#46553f';
    }
  }
  function applyNightmareUI(){
    if(nightmareMode){
      nightmareToggleBtn.textContent='مُفعّل (2X)';
      nightmareToggleBtn.style.background='#d9534f';
      nightmareBadge.style.display='inline-block';
    } else {
      nightmareToggleBtn.textContent='مُعطل';
      nightmareToggleBtn.style.background='#46553f';
      nightmareBadge.style.display='none';
    }
  }


  function loadData(){
    best=0;try{best=+localStorage.getItem(bestKey())||0}catch(e){}
    bestApples=0;try{bestApples=+localStorage.getItem(bestApplesKey())||0}catch(e){}
    try{apples=+localStorage.getItem('snakeApples')||0}catch(e){}
    try{
      var savedSkins=JSON.parse(localStorage.getItem('snakeSkins')||'null');
      if(savedSkins&&typeof savedSkins==='object'){
        var baseSkins={default:true,skin1:false,skin2:false,old:false,small:false,black:false,invisible:false,strong:false};
        Object.keys(savedSkins).forEach(function(k){baseSkins[k]=!!savedSkins[k];});
        baseSkins.default=true;unlockedSkins=baseSkins;
      }
      var savedActive=localStorage.getItem('snakeActiveSkin');
      if(savedActive) activeSkin=savedActive;
      var savedHelpers=JSON.parse(localStorage.getItem('snakeHelpers')||'null');
      if(savedHelpers) unlockedHelpers=savedHelpers;
      
      var savedSingleHelper = localStorage.getItem('snakeSingleActiveHelper');
      if(savedSingleHelper && unlockedHelpers[savedSingleHelper]) {
        activeHelper = savedSingleHelper;
      } else {
        activeHelper = null;
      }


      nightmareMode = localStorage.getItem('snakeNightmare') === 'true';
      darkMode = localStorage.getItem('snakeDarkMode') === 'true';
      var savedProfile=JSON.parse(localStorage.getItem('snakeProfile')||'null');
      if(savedProfile&&typeof savedProfile==='object')accountProfile=savedProfile;
      mangoes=Math.max(0,+localStorage.getItem('snakeMangoes')||0);
      shieldStock=Math.max(0,+localStorage.getItem('snakeShieldStock')||0);
      h1Up=localStorage.getItem('snakeH1Up')==='true';
      slowStock=Math.max(0,+localStorage.getItem('snakeSlowStock')||0);
      farmerUp=localStorage.getItem('snakeFarmerUp')==='true';
      lootUp=localStorage.getItem('snakeLootUp')==='true';
      wizUp=localStorage.getItem('snakeWizUp')==='true';
      adventureChapter=Math.max(0,Math.min(CHAPTERS.length-1,+localStorage.getItem('snakeAdventureChapter')||0));
      adventureFinished=localStorage.getItem('snakeAdventureFinished')==='true';
      adventureLevel=Math.max(0,Math.min(ADV_LEVELS-1,+localStorage.getItem('snakeAdventureLevel')||0));
      var cm=localStorage.getItem('snakeControlMode');
      if(cm==='both'||cm==='swipe'||cm==='pad')controlMode=cm;
      var st=+localStorage.getItem('snakeSwipeThreshold');
      if(st===12||st===20||st===32)swipeThreshold=st;
      var sc=localStorage.getItem('snakeColor');
      if(sc&&SNAKE_COLORS.some(function(x){return x.id===sc;}))snakeColor=sc;
    }catch(e){}
    try{
      currentFps=+localStorage.getItem('snakeFps')||60;
      if([30,60,90,120,144,165,240].indexOf(currentFps)<0)currentFps=60;
      fpsSelect.value=String(currentFps);
      targetFpsInterval=1000/currentFps;
    }catch(e){}

    applyDarkMode();
    applyNightmareUI();
    buildColorPickers();
    applyControls();
    updateAccountUI();
    updateAdStatus();
    menuBestEl.textContent=best;
    menuBestApplesEl.textContent=bestApples+' 🍎';
    updateCurrencyUI();updateBoostUI();
    updateShopUI();
  }

  function saveData(){
    try{
      localStorage.setItem('snakeApples',apples);
      localStorage.setItem('snakeSkins',JSON.stringify(unlockedSkins));
      localStorage.setItem('snakeActiveSkin',activeSkin);
      localStorage.setItem('snakeHelpers',JSON.stringify(unlockedHelpers));
      localStorage.setItem('snakeSingleActiveHelper', activeHelper || '');
      localStorage.setItem('snakeNightmare',nightmareMode);
      localStorage.setItem('snakeDarkMode',darkMode);
      localStorage.setItem('snakeFps',currentFps);
      localStorage.setItem('snakeProfile',JSON.stringify(accountProfile));
      localStorage.setItem('snakeMangoes',mangoes);
      localStorage.setItem('snakeShieldStock',shieldStock);
      localStorage.setItem('snakeH1Up',h1Up);
      localStorage.setItem('snakeSlowStock',slowStock);
      localStorage.setItem('snakeFarmerUp',farmerUp);
      localStorage.setItem('snakeLootUp',lootUp);
      localStorage.setItem('snakeWizUp',wizUp);
      localStorage.setItem('snakeAdventureChapter',adventureChapter);
      localStorage.setItem('snakeAdventureFinished',adventureFinished);
      localStorage.setItem('snakeAdventureLevel',adventureLevel);
      localStorage.setItem('snakeColor',snakeColor);
      localStorage.setItem('snakeControlMode',controlMode);
      localStorage.setItem('snakeSwipeThreshold',swipeThreshold);
    }catch(e){}
    updateCurrencyUI();updateBoostUI();updateShopUI();
    updateAccountUI();
  }

  var SKINS=[
    {id:'skin1',btn:buySkin1Btn,cost:1000,cur:'a'},
    {id:'skin2',btn:buySkin2Btn,cost:2500,cur:'a'},
    {id:'old',btn:document.getElementById('buySkinOld'),cost:30,cur:'m'},
    {id:'small',btn:document.getElementById('buySkinSmall'),cost:55,cur:'m'},
    {id:'black',btn:document.getElementById('buySkinBlack'),cost:570,cur:'m'},
    {id:'invisible',btn:document.getElementById('buySkinInvisible'),cost:65,cur:'m'},
    {id:'strong',btn:document.getElementById('buySkinStrong'),cost:75,cur:'m'}
  ];
  function skinShields(){return activeSkin==='small'?1:(activeSkin==='black'?3:(activeSkin==='strong'?1:0));}

  function updateShopUI(){
    SKINS.forEach(function(sk){
      if(!sk.btn)return;
      var icon=sk.cur==='m'?' 🥭':' 🍎',bal=sk.cur==='m'?mangoes:apples;
      if(unlockedSkins[sk.id]){
        sk.btn.textContent=(activeSkin===sk.id)?'مُفعّل ✓':'تفعيل';
        sk.btn.disabled=(activeSkin===sk.id);
      }else{
        sk.btn.textContent=sk.cost+icon;
        sk.btn.disabled=bal<sk.cost;
      }
    });

    var helpersListData = [
      {id:'h1', btn:buyHelper1Btn, cost:100},
      {id:'h2', btn:buyHelper2Btn, cost:350},
      {id:'h3', btn:buyHelper3Btn, cost:500},
      {id:'h4', btn:buyHelper4Btn, cost:800}
    ];
    helpersListData.forEach(function(item){
      if(unlockedHelpers[item.id]){
        var isEquipped = (activeHelper === item.id);
        item.btn.textContent = isEquipped ? 'مُجهّز ✓' : 'تجهيز';
        item.btn.disabled = isEquipped;
        item.btn.style.background = isEquipped ? '#28a745' : '#556b4f';
        item.btn.style.color = '#fff';
      } else {
        item.btn.textContent = item.cost + ' 🍎';
        item.btn.disabled = apples < item.cost;
        item.btn.style.background = '#cfe3a8';
        item.btn.style.color = '#1f2b19';
      }
    });
  }

  function setupHelperBtn(id, btn, cost, name){
    btn.onclick = function(){
      if(unlockedHelpers[id]){
        // تبديل: مساعد واحد فقط يمكن تجهيزه، وإذا ضغطت على المُجهّز يتم إلغاؤه
        activeHelper = (activeHelper === id) ? null : id;
        saveData(); updateShopUI(); playTone(600,'sine',0.1,0.05);
        return;
      }
      if(apples >= cost){
        apples -= cost;
        unlockedHelpers[id] = true;
        activeHelper = id; // تجهيز المساعد الجديد تلقائياً وإلغاء أي مساعد سابق
        saveData(); updateShopUI(); playTone(880,'sine',0.2,0.1);
      } else {
        alert('لا توجد تفاحات كافية لشراء ' + name + '! تحتاج ' + cost + ' تفاحة.');
      }
    };
  }
  setupHelperBtn('h1', buyHelper1Btn, 100, 'مُدمّر الصخور');
  setupHelperBtn('h2', buyHelper2Btn, 350, 'مزارع التفاح');
  setupHelperBtn('h3', buyHelper3Btn, 500, 'حارس الغنائم');
  setupHelperBtn('h4', buyHelper4Btn, 800, 'ساحر القوى');

  function showShopTab(name){
    skinsList.style.display=(name==='skins')?'flex':'none';
    helpersList.style.display=(name==='helpers')?'flex':'none';
    boostList.style.display=(name==='boost')?'flex':'none';
    chargeList.style.display=(name==='charge')?'flex':'none';
    [[tabSkins,'skins'],[tabHelpers,'helpers'],[tabBoost,'boost'],[tabCharge,'charge']].forEach(function(t){
      var on=(t[1]===name);
      t[0].style.background=on?'#cfe3a8':'#384632';t[0].style.color=on?'#1f2b19':'#fff';
    });
    updateBoostUI();
  }
  tabSkins.onclick=function(){showShopTab('skins');};
  tabHelpers.onclick=function(){showShopTab('helpers');};
  tabBoost.onclick=function(){showShopTab('boost');};
  tabCharge.onclick=function(){showShopTab('charge');updateChargeUI();};

  SKINS.forEach(function(sk){
    if(!sk.btn)return;
    sk.btn.onclick=function(){
      if(unlockedSkins[sk.id]){
        activeSkin=sk.id;saveData();updateShopUI();playTone(600,'sine',0.1,0.05);return;
      }
      var bal=sk.cur==='m'?mangoes:apples;
      if(bal>=sk.cost){
        if(sk.cur==='m')mangoes-=sk.cost;else apples-=sk.cost;
        unlockedSkins[sk.id]=true;activeSkin=sk.id;
        saveData();updateShopUI();playTone(880,'sine',0.2,0.1);
      }else{
        alert('رصيدك غير كافٍ! تحتاج '+sk.cost+(sk.cur==='m'?' 🥭 منجة.':' 🍎 تفاحة.'));
      }
    };
  });

  nightmareToggleBtn.onclick=function(){
    nightmareMode = !nightmareMode;
    applyNightmareUI();
    saveData();
    loadData();
    playTone(nightmareMode?700:400,'sawtooth',0.12,0.05);
  };

  darkModeToggleBtn.onclick=function(){
    darkMode = !darkMode;
    applyDarkMode();
    saveData();
    draw();
    playTone(500,'sine',0.08,0.04);
  };

  resetSkinBtn.onclick=function(){
    activeSkin='default';saveData();updateShopUI();playTone(500,'sine',0.1,0.05);
  };

  fpsSelect.onchange=function(){
    currentFps=+fpsSelect.value||60;
    targetFpsInterval=1000/currentFps;
    lastRenderTime=0;
    saveData();
    playTone(500,'sine',0.06,0.04);
  };

  settingsBtn.onclick=function(){
    menuOverlay.style.display='none';
    settingsOverlay.style.display='flex';
  };
  closeSettingsBtn.onclick=function(){
    settingsOverlay.style.display='none';
    menuOverlay.style.display='flex';
    draw();
  };

  saveAccountBtn.onclick=function(){
    var name=(accountNameInput.value||'').trim().replace(/[<>]/g,'').slice(0,18);
    if(!name){alert('اكتب اسمًا صالحًا للاعب.');return;}
    accountProfile.name=name;
    if(!accountProfile.id)accountProfile.id='local-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,7);
    if(!accountProfile.createdAt)accountProfile.createdAt=Date.now();
    saveData();
    accountStatus.textContent='تم حفظ حساب '+name+' على هذا الجهاز.';
  };
  exportSaveBtn.onclick=function(){
    try{
      var data={};
      for(var i=0;i<localStorage.length;i++){
        var key=localStorage.key(i);
        if(key&&key.indexOf('snake')===0)data[key]=localStorage.getItem(key);
      }
      data.snakeProfile=JSON.stringify(accountProfile);
      var blob=new Blob([JSON.stringify({app:'Snake Adventure',version:2,exportedAt:new Date().toISOString(),data:data},null,2)],{type:'application/json'});
      var url=URL.createObjectURL(blob),a=document.createElement('a');
      a.href=url;a.download='snake-adventure-save.json';document.body.appendChild(a);a.click();a.remove();
      setTimeout(function(){URL.revokeObjectURL(url);},1000);
      accountStatus.textContent='تم تنزيل النسخة الاحتياطية. احتفظ بالملف لنقل تقدمك.';
    }catch(e){alert('تعذر تصدير الحفظ في هذا المتصفح.');}
  };
  importSaveBtn.onclick=function(){importSaveInput.click();};
  importSaveInput.onchange=function(){
    var file=importSaveInput.files&&importSaveInput.files[0];if(!file)return;
    var reader=new FileReader();
    reader.onload=function(){
      try{
        var backup=JSON.parse(reader.result),data=backup&&backup.data;
        if(!data||typeof data!=='object')throw new Error('invalid backup');
        Object.keys(data).forEach(function(key){if(key.indexOf('snake')===0&&typeof data[key]==='string')localStorage.setItem(key,data[key]);});
        loadData();updateShopUI();draw();
        accountStatus.textContent='تم استرجاع النسخة الاحتياطية بنجاح.';
        alert('تم استرجاع تقدم اللعبة.');
      }catch(e){alert('ملف النسخة الاحتياطية غير صالح أو تالف.');}
      importSaveInput.value='';
    };
    reader.onerror=function(){alert('تعذرت قراءة الملف.');importSaveInput.value='';};
    reader.readAsText(file);
  };

  function openAdventureStory(){
    menuOverlay.style.display='none';shopOverlay.style.display='none';settingsOverlay.style.display='none';
    overOverlay.style.display='none';pauseOverlay.style.display='none';adventureCompleteOverlay.style.display='none';
    updateStoryUI();storyOverlay.style.display='flex';
  }
  menuAdventureBtn.onclick=openAdventureStory;
  storyBackBtn.onclick=function(){storyOverlay.style.display='none';menuOverlay.style.display='flex';};
  function startAdventureLevel(){beginGame(doStartAdventure);}
  function doStartAdventure(){
    if(adventureFinished){adventureChapter=CHAPTERS.length-1;adventureLevel=ADV_LEVELS-1;}
    var chapter=CHAPTERS[adventureChapter];diffKey=chapter.diff;
    document.querySelectorAll('#diff button').forEach(function(b){b.classList.toggle('on',b.dataset.k===diffKey);});
    gameMode='adventure';storyOverlay.style.display='none';adventureCompleteOverlay.style.display='none';
    statTitle.style.display='none';statScores.style.display='flex';homeBtn.style.display='block';
    inGame=true;reset();go();
    msg.textContent=(adventureLevel===ADV_LEVELS-1)?('👹 '+chapter.bossName+' — تفادَ الهجمات!'):('📖 '+chapter.name+' · ليفل '+(adventureLevel+1)+' — اجمع '+ADV_GOAL+' تفاحات.');
  }
  storyStartBtn.onclick=startAdventureLevel;
  adventureNextBtn.onclick=function(){
    adventureCompleteOverlay.style.display='none';
    if(adventureFinished){showMenu();msg.textContent='🏆 أنقذت الثعبانة الوردية وأنهيت القصة بالكامل!';}
    else if(adventureLevel===0||adventureLevel===ADV_LEVELS-1){openAdventureStory();}
    else{startAdventureLevel();}
  };
  adventureMenuBtn.onclick=function(){showMenu();};

  shopBtn.onclick=function(){
    menuOverlay.style.display='none';
    shopOverlay.style.display='flex';
    updateCurrencyUI();
    updateShopUI();updateBoostUI();
  };
  closeShopBtn.onclick=function(){
    shopOverlay.style.display='none';
    menuOverlay.style.display='flex';
    draw();
  };

  var audioCtx=null;
  function getAudioContext(){
    if(!audioCtx){var AC=window.AudioContext||window.webkitAudioContext;if(AC)audioCtx=new AC();}
    if(audioCtx&&audioCtx.state==='suspended')audioCtx.resume();
    return audioCtx;
  }
  function playTone(freq,type,duration,vol){
    if(!soundOn)return;
    try{
      var ac=getAudioContext();if(!ac)return;
      var osc=ac.createOscillator(),gain=ac.createGain();
      osc.type=type||'square';osc.frequency.setValueAtTime(freq,ac.currentTime);
      gain.gain.setValueAtTime(vol||0.05,ac.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001,ac.currentTime+duration);
      osc.connect(gain);gain.connect(ac.destination);
      osc.start();osc.stop(ac.currentTime+duration);
    }catch(e){}
  }
  function haptic(){if(window.navigator&&window.navigator.vibrate)try{window.navigator.vibrate(15)}catch(e){}}

  var snake,dir,next,food,stones,score,eaten,level,running=false,speed,over_=false,pw=null,effs=[],invisT=0,skinTimer=0,strongSlims=0,slowActive=false;
  var lastFrameTime=0, accumulator=0, frameTick=0;
  var V={u:[0,-1],d:[0,1],l:[-1,0],r:[1,0]};

  function occupied(x,y){
    return snake.some(function(s){return s[0]===x&&s[1]===y})||stones.some(function(s){return s[0]===x&&s[1]===y})||(food&&food[0]===x&&food[1]===y)||(pw&&pw.x===x&&pw.y===y)||(mg&&mg.x===x&&mg.y===y);
  }
  function placeFood(){
    var x,y;do{x=Math.floor(Math.random()*N);y=Math.floor(Math.random()*N)}while(occupied(x,y));
    food=[x,y];
  }
  function spawnMango(){
    var x,y,t=0;
    do{x=Math.floor(Math.random()*N);y=Math.floor(Math.random()*N);t++;}while(occupied(x,y)&&t<200);
    if(occupied(x,y))return;
    mg={x:x,y:y,life:110};
    msg.textContent='🥭 ظهرت منجة! التقطها بسرعة';playTone(1000,'triangle',0.15,0.07);
  }
  function placeStone(){
    var h=snake[0],x,y,t=0;
    do{
      x=Math.floor(Math.random()*N);y=Math.floor(Math.random()*N);t++;
      var near=Math.abs(x-h[0])<=3&&Math.abs(y-h[1])<=3;
    }while((occupied(x,y)||(near&&t<200))&&t<400);
    if(!occupied(x,y))stones.push([x,y]);
  }
  function baseSpeed(){
    var spd = Math.max(55, DIFF[diffKey].speed - (level-1)*(gameMode==='adventure'?3:8));
    if(nightmareMode) spd = Math.max(28, Math.round(spd / 2));
    return spd;
  }
  function reset(){
    snake=(activeSkin==='small')?[[8,8]]:[[8,8],[7,8],[6,8]];dir=V.r;next=V.r;score=0;eaten=0;level=1;stones=[];food=null;over_=false;pw=null;effs=[];invisT=0;skinTimer=0;strongSlims=0;slowActive=false;
    hasUsedRewardedRevive = false;
    paused=false;dirQueue=[];
    if(pauseOverlay)pauseOverlay.style.display='none';
    gameApplesEarned = 0;
    h1Timer = 0; h2Timer = 0; h4Timer = 0;
    shieldCharges=skinShields();frozenT=0;mg=null;gameMangoesEarned=0;
    if(inGame){
      if(pendingShield&&shieldStock>0){shieldStock--;shieldCharges++;saveData();}
      if(pendingSlow&&slowStock>0){slowStock--;slowActive=true;saveData();}
      pendingShield=false;pendingSlow=false;
    }
    level=(gameMode==='adventure')?adventureLevel+1:1;boss=null;
    speed=baseSpeed();scoreEl.textContent=0;lvlEl.textContent=level;
    if(gameMode==='adventure'&&adventureLevel===ADV_LEVELS-1){initBoss();food=null;}else placeFood();
    updateAdventureHUD();updateAdStatus();draw();
  }

  var PW={
    slow:{l:'S',n:'قوة البطء: الثعبان أبطأ',d:45},
    x2:{l:'2',n:'قوة مضاعفة: النقاط ×2',d:50},
    ghost:{l:'G',n:'قوة الشبح: تعبر الأحجار',d:40},
    clear:{l:'C',n:'قوة التنظيف: أُزيلت الأحجار',d:0},
    shrink:{l:'M',n:'قوة الحجم: عاد الثعبان صغيراً',d:0}
  };
  var PK=['slow','x2','ghost','clear','shrink'];
  function inPool(){
    if(!boss||!boss.pools||!boss.pools.length)return false;
    var h=snake[0];
    return boss.pools.some(function(pl){return pl.age>=700&&h[0]>=pl.x&&h[0]<pl.x+pl.w;});
  }
  function hasEff(t){return effs.some(function(e){return e.t===t;});}
  function isGhost(){return hasEff('ghost')||invisT>0;}
  function curSpeed(){return Math.round(baseSpeed()*(hasEff('slow')?1.6:1)*(activeSkin==='old'?1.3:1)*(slowActive?1/0.75:1)*(inPool()?1.9:1))}
  function spawnPower(){
    var x,y,t=0;do{x=Math.floor(Math.random()*N);y=Math.floor(Math.random()*N);t++}while(occupied(x,y)&&t<200);
    if(occupied(x,y))return;
    pw={x:x,y:y,t:PK[Math.floor(Math.random()*PK.length)],life:70};
  }
  function activate(t, customMsg){
    var p=PW[t];
    msg.textContent = customMsg || p.n;
    playTone(600,'triangle',0.15,0.08);haptic();
    if(t==='clear'){stones=[];return}
    if(t==='shrink'){if(snake.length>3){snake=snake.slice(0,3);}return;}
    effs=effs.filter(function(e){return e.t!==t;});
    effs.push({t:t,left:p.d});
    if(t==='slow'){speed=curSpeed();}
  }
  function endEff(){
    effs=effs.filter(function(e){return e.left>0;});
    msg.textContent='';speed=curSpeed();
  }
  function applyControls(){
    if(controlSelect)controlSelect.value=controlMode;
    if(swipeSelect)swipeSelect.value=String(swipeThreshold);
    padVisible=controlMode!=='swipe';
    padContainer.classList.toggle('hidden',!padVisible);
    padToggle.style.opacity=padVisible?'1':'0.5';
  }
  if(controlSelect)controlSelect.onchange=function(){controlMode=controlSelect.value;applyControls();saveData();playTone(500,'sine',0.06,0.04);};
  if(swipeSelect)swipeSelect.onchange=function(){swipeThreshold=+swipeSelect.value||20;saveData();playTone(500,'sine',0.06,0.04);};

  function setDir(k){
    if(paused||!inGame||over_)return;
    if(frozenT>0){
      frozenT=Math.max(0,frozenT-350);playTone(700,'square',0.03,0.03);haptic();
      if(frozenT<=0)msg.textContent='💥 كسرت الجليد!';
      return;
    }
    var d=V[k];if(!d)return;
    var ref=dirQueue.length?dirQueue[dirQueue.length-1]:dir;
    if(d[0]===ref[0]&&d[1]===ref[1])return;
    if(d[0]===-ref[0]&&d[1]===-ref[1])return;
    if(dirQueue.length<2)dirQueue.push(d);
    next=d;playTone(220,'sine',0.04,0.02);haptic();
    if(!running&&inGame&&!over_)go();
  }
  
  var gameLoopId=null;
  function go(){
    if(running)return;
    if(over_)reset();
    paused=false;pauseOverlay.style.display='none';pauseBtn.style.display=inGame?'flex':'none';
    running=true;msg.textContent='';overOverlay.style.display='none';
    lastFrameTime=performance.now();
    lastRenderTime=lastFrameTime;fpsWindowStart=lastFrameTime;fpsFrameCount=0;
    accumulator=0;
    if(gameLoopId)cancelAnimationFrame(gameLoopId);
    gameLoopId=requestAnimationFrame(mainLoop);
  }

  function pauseGame(){
    if(!inGame||!running||over_)return;
    running=false;paused=true;
    if(gameLoopId)cancelAnimationFrame(gameLoopId);
    pauseOverlay.style.display='flex';
    pauseBtn.textContent='▶';pauseBtn.setAttribute('aria-label','استكمال اللعب');
    msg.textContent='';
    draw();
  }

  function resumeGame(){
    if(!inGame||!paused||over_)return;
    paused=false;pauseOverlay.style.display='none';pauseBtn.textContent='⏸';
    pauseBtn.setAttribute('aria-label','إيقاف مؤقت');
    running=true;lastFrameTime=performance.now();lastRenderTime=lastFrameTime;fpsWindowStart=lastFrameTime;fpsFrameCount=0;accumulator=0;
    if(gameLoopId)cancelAnimationFrame(gameLoopId);
    gameLoopId=requestAnimationFrame(mainLoop);
  }

  function togglePause(){if(running)pauseGame();else if(paused)resumeGame();}

  function updateHelpers(dt){
    // المساعد الواحد المُجهّز فقط هو من يعمل
    if(activeHelper === 'h1'){
      h1Timer += dt;
      if(h1Up){
        if(h1Timer >= 20000){
          h1Timer = 0;
          if(stones.length > 0){
            stones = [];
            msg.textContent = '🪨 مُدمّر الصخور أخفى كل الحجارة!';
            playTone(520,'sine',0.15,0.07);
            setTimeout(function(){ if(running && msg.textContent.indexOf('🪨')===0) msg.textContent=''; }, 1800);
          }
        }
      }else if(h1Timer >= 15000){
        h1Timer = 0;
        if(stones.length > 0){
          var idx = Math.floor(Math.random() * stones.length);
          stones.splice(idx, 1);
          msg.textContent = '🪨 مُدمّر الصخور أزال حجراً!';
          playTone(520,'sine',0.12,0.06);
          setTimeout(function(){ if(running && msg.textContent.indexOf('🪨')===0) msg.textContent=''; }, 1800);
        }
      }
    } else if(activeHelper === 'h4'){
      h4Timer += dt;
      if(h4Timer >= (wizUp?20000:40000)){
        h4Timer = 0;
        var pool = PK.slice(), picks = [], n = wizUp ? 2 : 1;
        while(n-- > 0 && pool.length){picks.push(pool.splice(Math.floor(Math.random()*pool.length),1)[0]);}
        picks.forEach(function(pk){activate(pk);});
        msg.textContent = '⚡ ساحر القوى منحك: ' + picks.map(function(pk){return PW[pk].n.split(':')[0];}).join(' + ');
      }
    }

    // قدرات المظاهر
    if(activeSkin === 'invisible'){
      skinTimer += dt;
      if(skinTimer >= 15000){
        skinTimer = 0;
        if(Math.random() < 0.10){invisT = 3500;msg.textContent = '👻 اختفى الثعبان لثوانٍ!';playTone(300,'sine',0.3,0.06);}
      }
      if(invisT > 0){invisT -= dt;if(invisT <= 0){invisT = 0;msg.textContent = '';}}
    } else if(activeSkin === 'strong'){
      skinTimer += dt;
      if(skinTimer >= 20000 && strongSlims < 3 && snake.length > 3){
        skinTimer = 0;strongSlims++;
        snake = snake.slice(0, Math.max(3, snake.length - 3));
        msg.textContent = '💪 الثعبان القوي نحف! (' + strongSlims + '/3)';playTone(500,'triangle',0.2,0.07);
      }
    }
  }

  // ===== معركة الزعيم =====
  function initBoss(){
    var ch=CHAPTERS[adventureChapter];
    boss={need:ch.bossNeed,got:0,elapsed:0,bx:Math.floor(N/2),moveT:0,
      throwT:ch.throwEvery||0,bigT:ch.bigEvery||0,poolT:ch.poolEvery||0,dashT:ch.dashEvery||0,iceT:ch.iceEvery||0,strikeT:ch.strikeEvery?8000:0,
      shots:[],pools:[],dash:null,ice:null,strike:null,
      letter:null,letterT:0,gLetter:null,lastSec:-1,announced:false};
    frozenT=0;
  }
  function shotCells(sh){
    var c=[],i;
    if(sh.big){for(i=-1;i<=1;i++){if(sh.x+i>=0&&sh.x+i<N)c.push([sh.x+i,sh.y]);}}
    else c.push([sh.x,sh.y]);
    return c;
  }
  function shotHit(){
    if(!boss||isGhost())return false;
    for(var i=0;i<boss.shots.length;i++){
      var cells=shotCells(boss.shots[i]);
      for(var k=0;k<cells.length;k++){
        var cx=cells[k][0],cy=cells[k][1];
        if(snake.some(function(g){return g[0]===cx&&g[1]===cy;})){boss.shots.splice(i,1);return true;}
      }
    }
    return false;
  }
  // أحجار الثعبان الأسود الكبيرة الثلاثة (تغطي كل اللوحة) — حرف G وحده ينجّيك
  var BANDS=[[0,4],[5,10],[11,15]];
  function bandHit(){
    if(!boss||!boss.strike||boss.strike.phase!=='fall'||boss.strike.prot)return false;
    var st=boss.strike;
    for(var i=0;i<3;i++){
      var by=Math.floor((st.t-i*250)/70)-1;
      if(by<0)continue;
      for(var k=0;k<snake.length;k++){
        var g=snake[k];
        if(g[0]>=BANDS[i][0]&&g[0]<=BANDS[i][1]&&(g[1]===by||g[1]===by-1))return true;
      }
    }
    return false;
  }
  function iceTouchesSnake(lines){
    return lines.some(function(ln){
      return snake.some(function(g){return ln.axis==='row'?g[1]===ln.idx:g[0]===ln.idx;});
    });
  }
  function spawnLetter(){
    var x,y,t=0;
    do{x=Math.floor(Math.random()*N);y=1+Math.floor(Math.random()*(N-1));t++;}while(occupied(x,y)&&t<300);
    boss.letter={x:x,y:y};boss.letterT=0;
  }
  function updateBoss(dt){
    var ch=CHAPTERS[adventureChapter],i;
    dt=Math.min(dt,100);
    boss.elapsed+=dt;
    if(frozenT>0){frozenT-=dt;if(frozenT<=0){frozenT=0;msg.textContent='';}}

    // الزعيم يتبع عمود رأس الثعبان
    boss.moveT+=dt;
    if(boss.moveT>=ch.moveMs){
      boss.moveT=0;var hx=snake[0][0];
      if(boss.bx<hx)boss.bx++;else if(boss.bx>hx)boss.bx--;
    }

    // حجارة صغيرة
    if(ch.throwEvery){
      boss.throwT-=dt;
      if(boss.throwT<=0){
        boss.shots.push({x:boss.bx,y:1,t:0});boss.throwT=ch.throwEvery;
        playTone(170,'square',0.08,0.05);
      }
    }
    // الزعيم 1: حجر كبير كل 4 ثوانٍ يغطي 3 مربعات
    if(ch.bigEvery){
      boss.bigT-=dt;
      if(boss.bigT<=0){
        boss.shots.push({x:boss.bx,y:1,t:0,big:true});boss.bigT=ch.bigEvery;
        playTone(110,'sawtooth',0.2,0.07);
      }
    }
    // الزعيم 2: برك تغطي العمود كله كل 5 ثوانٍ وتختفي بعد 10 ثوانٍ
    if(ch.poolEvery){
      boss.poolT-=dt;
      if(boss.poolT<=0){
        boss.poolT=ch.poolEvery;
        var px=Math.max(0,Math.min(N-2,snake[0][0]+Math.floor(Math.random()*7)-3));
        boss.pools.push({x:px,w:2,age:0});playTone(300,'sine',0.15,0.06);
      }
      for(i=boss.pools.length-1;i>=0;i--){
        boss.pools[i].age+=dt;
        if(boss.pools[i].age>=10700)boss.pools.splice(i,1);
      }
    }
    // الزعيم 3: يندفع نحوك على طول الصف أو العمود كل 3 ثوانٍ
    if(ch.dashEvery){
      boss.dashT-=dt;
      if(!boss.dash&&boss.dashT<=0){
        var axis=Math.random()<0.5?'row':'col',hd=snake[0];
        boss.dash={axis:axis,idx:axis==='row'?hd[1]:hd[0],t:0,run:false,pos:0,dir:Math.random()<0.5?1:-1,hit:false};
        boss.dash.pos=boss.dash.dir>0?-1:N;
        boss.dashT=ch.dashEvery;
        playTone(200,'sawtooth',0.2,0.06);
      }
      var d=boss.dash;
      if(d){
        d.t+=dt;
        if(!d.run){
          if(d.t>=700){d.run=true;playTone(140,'sawtooth',0.25,0.08);}
        }else{
          var oldPos=d.pos;d.pos+=d.dir*dt*(N+2)/420;
          var ca=Math.floor(Math.min(oldPos,d.pos)),cb=Math.floor(Math.max(oldPos,d.pos));
          if(!d.hit&&!isGhost()){
            for(var c=ca;c<=cb;c++){
              if(c<0||c>=N)continue;
              var dx=d.axis==='row'?c:d.idx,dy=d.axis==='row'?d.idx:c;
              if(snake.some(function(g){return g[0]===dx&&g[1]===dy;})){
                d.hit=true;handleCollision('صدمك '+ch.bossName+'!');if(!running)return;break;
              }
            }
          }
          if((d.dir>0&&d.pos>N+1)||(d.dir<0&&d.pos<-2))boss.dash=null;
        }
      }
    }
    // الزعيم 4: 4 خطوط جليد عشوائية كل 6 ثوانٍ؛ من يلمسها يتجمّد ثم يُرمى بحجر ثلج
    if(ch.iceEvery){
      boss.iceT-=dt;
      if(!boss.ice&&boss.iceT<=0){
        var lines=[],used={};
        while(lines.length<4){
          var ax=Math.random()<0.5?'row':'col',ix=Math.floor(Math.random()*N),key=ax+ix;
          if(used[key])continue;used[key]=1;lines.push({axis:ax,idx:ix});
        }
        boss.ice={t:0,phase:'warn',lines:lines};boss.iceT=ch.iceEvery;
        msg.textContent='❄️ ابتعد عن خطوط الجليد الزرقاء!';playTone(400,'triangle',0.2,0.06);
      }
      if(boss.ice){
        var ic=boss.ice;ic.t+=dt;
        if(ic.phase==='warn'&&ic.t>=1300){
          ic.phase='strike';ic.t=0;playTone(900,'triangle',0.2,0.08);
          if(!isGhost()&&iceTouchesSnake(ic.lines)){
            frozenT=2400;
            boss.shots.push({x:snake[0][0],y:1,t:0,ice:true});
            msg.textContent='🧊 تجمّدت! اضغط الأسهم بسرعة لتكسر الجليد!';haptic();
          }
        }else if(ic.phase==='strike'&&ic.t>=450){boss.ice=null;}
      }
    }
    // الثعبان الأسود: ضربة 3 أحجار كبيرة، وحرف G وحده يحميك
    if(ch.strikeEvery){
      if(!boss.strike){
        boss.strikeT-=dt;
        if(boss.strikeT<=0){
          var gx,gy,tries=0,hh=snake[0];
          do{gx=Math.floor(Math.random()*N);gy=2+Math.floor(Math.random()*(N-2));tries++;}
          while((occupied(gx,gy)||Math.abs(gx-hh[0])+Math.abs(gy-hh[1])<4)&&tries<200);
          boss.strike={phase:'warn',t:0,prot:false};
          boss.gLetter={x:gx,y:gy};
          msg.textContent='⚠️ 3 أحجار كبيرة قادمة! التقط حرف G الآن!';
          playTone(120,'sawtooth',0.4,0.1);
        }
      }else{
        var stk=boss.strike;stk.t+=dt;
        if(stk.phase==='warn'){
          if(stk.t>=4200){stk.phase='fall';stk.t=0;boss.gLetter=null;playTone(90,'sawtooth',0.5,0.1);}
        }else{
          if(bandHit()){end('سحقتك أحجار الثعبان الأسود الكبيرة! كان عليك التقاط حرف G.');return;}
          if(stk.t>=70*(N+3)+800){
            boss.strike=null;boss.strikeT=ch.strikeEvery;
            msg.textContent=stk.prot?'🛡️ نجوت من الضربة الكبرى!':'';
          }
        }
      }
    }

    // الحجارة المتساقطة
    for(i=boss.shots.length-1;i>=0;i--){
      var sh=boss.shots[i],fallMs=sh.ice?85:(sh.big?ch.bigFall:ch.fall);
      sh.t+=dt;
      while(sh.t>=fallMs){sh.t-=fallMs;sh.y++;}
      if(sh.y>=N)boss.shots.splice(i,1);
    }
    if(shotHit()){handleCollision('أصابك حجر '+ch.bossName+'!');if(!running)return;}

    // ظهور حرف B بعد 30 ثانية
    if(boss.elapsed<30000){
      var sec=Math.ceil((30000-boss.elapsed)/1000);
      if(sec!==boss.lastSec){
        boss.lastSec=sec;
        if(!boss.strike&&frozenT<=0&&!boss.ice)msg.textContent='⏳ حرف B يظهر بعد '+sec+' ث — تفادَ الهجمات!';
      }
    }else{
      if(!boss.announced){boss.announced=true;msg.textContent='🔤 ظهر حرف B! اجمع '+boss.need+' حروف لتدمير الزعيم.';playTone(900,'triangle',0.2,0.08);}
      if(!boss.letter)spawnLetter();
      else{boss.letterT+=dt;if(boss.letterT>=9000)spawnLetter();}
    }
  }

  function mainLoop(timestamp){
    if(!running)return;
    var dt=timestamp-lastFrameTime;
    lastFrameTime=timestamp;
    accumulator+=dt;

    updateHelpers(dt);
    if(boss){updateBoss(dt);if(!running)return;}

    var currentInterval=curSpeed();
    while(accumulator>=currentInterval){
      accumulator-=currentInterval;
      step();
      if(!running)return;
    }

    if(timestamp-lastRenderTime>=targetFpsInterval){
      lastRenderTime=timestamp;
      frameTick++;
      draw();
      fpsFrameCount++;
      if(!fpsWindowStart)fpsWindowStart=timestamp;
      if(timestamp-fpsWindowStart>=500){
        measuredFps=Math.round(fpsFrameCount*1000/(timestamp-fpsWindowStart));
        if(fpsValueEl)fpsValueEl.textContent=measuredFps;
        if(fpsSettingsValueEl)fpsSettingsValueEl.textContent=measuredFps+' FPS';
        fpsFrameCount=0;fpsWindowStart=timestamp;
      }
    }
    gameLoopId=requestAnimationFrame(mainLoop);
  }
  var lastRenderTime=0;

  function handleCollision(why){
    if(shieldCharges>0){
      var safe=findSafeReviveDirection();
      if(safe){
        shieldCharges--;dir=safe;next=safe;dirQueue=[];
        msg.textContent='🛡️ درع الثعبان أنقذك! المتبقي: '+shieldCharges;
        playTone(680,'triangle',0.16,0.07);haptic();
        return;
      }
    }
    end(why);
  }

  function step(){
    if(frozenT>0)return;
    if(dirQueue.length)next=dirQueue.shift();
    dir=next;
    var nx=snake[0][0]+dir[0],ny=snake[0][1]+dir[1];var ghost=isGhost();
    if(DIFF[diffKey].walls){if(nx<0||ny<0||nx>=N||ny>=N)return handleCollision('اصطدمت بالجدار!')}
    else{nx=(nx+N)%N;ny=(ny+N)%N}
    if(!ghost&&stones.some(function(s){return s[0]===nx&&s[1]===ny}))return handleCollision('اصطدمت بحجر!');
    var willEat=!!food&&food[0]===nx&&food[1]===ny;
    var body=willEat?snake:snake.slice(0,-1);
    if(!ghost&&body.some(function(s){return s[0]===nx&&s[1]===ny}))return handleCollision('عضّيت نفسك!');
    snake.unshift([nx,ny]);
    if(boss){
      if(shotHit()){handleCollision('أصابك حجر '+CHAPTERS[adventureChapter].bossName+'!');if(!running)return;}
      if(bandHit()){end('سحقتك أحجار الثعبان الأسود الكبيرة! كان عليك التقاط حرف G.');return;}
      if(boss.gLetter&&boss.gLetter.x===nx&&boss.gLetter.y===ny){
        boss.gLetter=null;if(boss.strike)boss.strike.prot=true;
        msg.textContent='🛡️ حرف G! أنت محمي من الضربة الكبرى';
        playTone(1200,'triangle',0.25,0.1);haptic();
      }
      // حرف B يدمّر الزعيم فقط ولا يغيّر حجم الثعبان
      if(boss.letter&&boss.letter.x===nx&&boss.letter.y===ny){
        boss.got++;boss.letter=null;
        score+=50*(nightmareMode?2:1);scoreEl.textContent=score;
        playTone(760,'triangle',0.12,0.08);haptic();updateAdventureHUD();
        if(boss.got>=boss.need){completeAdventureLevel();return;}
        msg.textContent='💥 ضربة للزعيم! B '+boss.got+'/'+boss.need;
      }
    }
    if(mg&&mg.x===nx&&mg.y===ny){
      mg=null;mangoes++;gameMangoesEarned++;saveData();
      msg.textContent='🥭 +1 منجة!';playTone(1100,'triangle',0.15,0.08);haptic();
    }
    if(pw&&pw.x===nx&&pw.y===ny){var pt=pw.t;pw=null;activate(pt)}
    if(willEat){
      eaten++;
      var mult = (hasEff('x2')?2:1) * (nightmareMode?2:1);
      score += 10 * level * mult;
      scoreEl.textContent=score;
      
      var gainedApples = nightmareMode ? 2 : 1;
      apples += gainedApples;
      gameApplesEarned += gainedApples;
      saveData();
      if(activeHelper==='h2'){
        h2Count++;
        var farmNeed=farmerUp?10:15,farmGain=farmerUp?55:45;
        if(h2Count>=farmNeed){
          h2Count=0;apples+=farmGain;gameApplesEarned+=farmGain;
          if(farmerUp){mangoes++;gameMangoesEarned++;}
          saveData();
          msg.textContent='🍎 مزارع التفاح منحك +'+farmGain+' تفاحة'+(farmerUp?' و +1 🥭':'')+'!';playTone(780,'sine',0.18,0.08);
          setTimeout(function(){ if(running && msg.textContent.indexOf('🍎')===0) msg.textContent=''; }, 2000);
        }
      }
      if(gameMode==='classic'&&eaten%10===0&&!mg&&Math.random()<0.7)spawnMango();

      playTone(440,'square',0.08,0.06);haptic();
      if(gameMode!=='adventure'&&eaten%5===0){
        level++;lvlEl.textContent=level;stones=[];
        speed=baseSpeed();msg.textContent='المستوى '+level+'! أُزيلت الأحجار';
        playTone(880,'sine',0.2,0.08);
        setTimeout(function(){if(running&&msg.textContent.indexOf('المستوى')===0)msg.textContent=''},1500);
      }else if(eaten%DIFF[diffKey].every===0){placeStone()}
      placeFood();
    }else snake.pop();
    if(mg){mg.life--;if(mg.life<=0)mg=null}
    if(pw){pw.life--;if(pw.life<=0)pw=null}
    else if(!effs.length&&Math.random()<0.03)spawnPower();
    if(effs.length){effs.forEach(function(e){e.left--;});if(effs.some(function(e){return e.left<=0;}))endEff();}
    if(gameMode==='adventure'){
      updateAdventureHUD();
      if(!boss&&eaten>=ADV_GOAL){completeAdventureLevel();return;}
    }
  }

  function completeAdventureLevel(){
    if(!running||gameMode!=='adventure')return;
    running=false;over_=true;paused=false;
    if(gameLoopId)cancelAnimationFrame(gameLoopId);
    pauseBtn.style.display='none';
    var ch=CHAPTERS[adventureChapter],doneLevel=adventureLevel,doneChapter=adventureChapter;
    var isBoss=doneLevel===ADV_LEVELS-1,isLastChapter=doneChapter===CHAPTERS.length-1;
    var isFinal=isBoss&&isLastChapter,alreadyClaimed=isFinal&&adventureFinished;
    var reward=alreadyClaimed?0:(isBoss?ch.reward:LEVEL_REWARD+doneChapter*5);
    apples+=reward;gameApplesEarned+=reward;
    // المنجة: فرصة 70% بعد إتمام 10 تفاحات (أو هزيمة الزعيم)، وحارس الغنائم يضاعفها
    var mangoGain=(!alreadyClaimed&&Math.random()<0.7)?1:0;
    if(mangoGain&&activeHelper==='h3')mangoGain*=(lootUp?3:2);
    mangoes+=mangoGain;frozenT=0;
    if(isFinal)adventureFinished=true;
    else if(isBoss){adventureChapter=doneChapter+1;adventureLevel=0;}
    else adventureLevel=doneLevel+1;
    boss=null;
    if(score>best){best=score;try{localStorage.setItem(bestKey(),best)}catch(e){}}
    if(gameApplesEarned>bestApples){bestApples=gameApplesEarned;try{localStorage.setItem(bestApplesKey(),bestApples)}catch(e){}}
    saveData();
    if(isFinal){
      adventureCompleteTitle.textContent='🏆 أنقذت الثعبانة الوردية!';
      adventureCompleteText.textContent=ch.outro;
      adventureNextBtn.textContent='إنهاء والعودة للقائمة';
    }else if(isBoss){
      adventureCompleteTitle.textContent='🎉 هُزم '+ch.bossName+'!';
      adventureCompleteText.textContent=ch.outro;
      adventureNextBtn.textContent='الفصل '+(adventureChapter+1);
    }else{
      adventureCompleteTitle.textContent='✅ اكتمل الليفل '+(doneLevel+1)+' من '+ADV_LEVELS;
      adventureCompleteText.textContent=(adventureLevel===ADV_LEVELS-1)?'اقتربت من الزعيم! استعد للمواجهة وتفادَ هجماته.':'أحسنت! خطوة أخرى تقرّبك من الثعبانة الوردية.';
      adventureNextBtn.textContent=(adventureLevel===ADV_LEVELS-1)?'مواجهة الزعيم':'الليفل '+(adventureLevel+1);
    }
    adventureRewardText.textContent=(alreadyClaimed?'لا توجد مكافأة إضافية لإعادة الفصل.':'المكافأة: +'+reward+' 🍎'+(mangoGain?' و +'+mangoGain+' 🥭':' (لم تظهر منجة هذه المرة)'))+' · رصيدك: '+apples+' 🍎 · '+mangoes+' 🥭';
    adventureCompleteOverlay.style.display='flex';
    updateAdventureHUD();playTone(1000,'triangle',0.35,0.1);
  }

  function end(why){
    running=false;paused=false;over_=true;effs=[];invisT=0;pw=null;
    pauseOverlay.style.display='none';pauseBtn.style.display='none';
    if(gameLoopId)cancelAnimationFrame(gameLoopId);
    playTone(130,'sawtooth',0.3,0.1);haptic();

    // المساعد الثالث (حارس الغنائم): يُضاعف التفاح الذي أخذته في الجيم بعد الموت
    if(activeHelper === 'h3' && gameApplesEarned > 0){
      var extraApples = gameApplesEarned*(lootUp?2:1);
      apples += extraApples;
      gameApplesEarned += extraApples;
      saveData();
      helper3BonusMsg.textContent = '💎 حارس الغنائم زوّد تفاح الجيم ('+(lootUp?'×3':'×2')+') (+' + extraApples + ' 🍎)!';
      helper3BonusMsg.style.display = 'block';
    } else {
      helper3BonusMsg.style.display = 'none';
    }

    if(gameMangoesEarned>0){
      var mangoTotal=gameMangoesEarned;
      if(activeHelper==='h3'){mangoes+=gameMangoesEarned*(lootUp?2:1);mangoTotal=gameMangoesEarned*(lootUp?3:2);saveData();}
      gameMangoMsg.textContent='🥭 منجة الجيم: '+mangoTotal+(activeHelper==='h3'?' (زوّدها حارس الغنائم '+(lootUp?'×3':'×2')+')':'')+' · رصيدك: '+mangoes+' 🥭';
      gameMangoMsg.style.display='block';
    }else{
      gameMangoMsg.style.display='none';
    }

    var isNew=false;
    if(score>best){best=score;menuBestEl.textContent=best;isNew=true;try{localStorage.setItem(bestKey(),best)}catch(e){}}

    var isNewAppleRecord = false;
    if(gameApplesEarned > bestApples){
      bestApples = gameApplesEarned;
      menuBestApplesEl.textContent = bestApples + ' 🍎';
      isNewAppleRecord = true;
      try{localStorage.setItem(bestApplesKey(), bestApples)}catch(e){}
    }

    overReason.textContent=why;
    finalScoreEl.textContent=score;
    finalGameApplesEl.textContent=gameApplesEarned;
    finalApplesEl.textContent=apples;
    newRecordMsg.style.display=isNew?'block':'none';
    newAppleRecordMsg.style.display=isNewAppleRecord?'block':'none';
    
    updateAdStatus();
    revive150Btn.disabled=(apples<150);
    revive500Btn.disabled=(apples<500);
    reviveSection.style.display='flex';
    powerChoiceSection.style.display='none';
    overOverlay.style.display='flex';
    draw();
  }

  function findSafeReviveDirection(){
    var head=snake[0];
    var candidates=[V.u,V.d,V.l,V.r];
    for(var i=0;i<candidates.length;i++){
      var d=candidates[i],nx=head[0]+d[0],ny=head[1]+d[1];
      if(DIFF[diffKey].walls){
        if(nx<0||ny<0||nx>=N||ny>=N)continue;
      }else{
        nx=(nx+N)%N;ny=(ny+N)%N;
      }
      var blockedByStone=stones.some(function(st){return st[0]===nx&&st[1]===ny;});
      var blockedByBody=snake.slice(0,-1).some(function(seg){return seg[0]===nx&&seg[1]===ny;});
      if(!blockedByStone&&!blockedByBody)return d;
    }
    return null;
  }

  function reviveGame(chosenPower){
    over_=false;paused=false;pauseOverlay.style.display='none';overOverlay.style.display='none';pauseBtn.style.display='flex';pauseBtn.textContent='⏸';pauseBtn.setAttribute('aria-label','إيقاف مؤقت');
    stones=stones.filter(function(s){return !(s[0]===snake[0][0]&&s[1]===snake[0][1]);});
    var safeDirection=findSafeReviveDirection();
    if(safeDirection){
      dir=safeDirection;next=safeDirection;dirQueue=[];
    }else{
      snake=[[8,8],[7,8],[6,8]];
      stones=stones.filter(function(st){return !snake.some(function(seg){return seg[0]===st[0]&&seg[1]===st[1];});});
      dir=V.r;next=V.r;dirQueue=[];
      if(food&&snake.some(function(seg){return seg[0]===food[0]&&seg[1]===food[1];})){food=null;placeFood();}
      msg.textContent='تم نقلك إلى مكان آمن لتكمل الجولة.';
    }
    if(chosenPower){activate(chosenPower);}
    if(boss){
      boss.shots=[];boss.dash=null;boss.ice=null;boss.strike=null;boss.gLetter=null;boss.pools=[];
      if(CHAPTERS[adventureChapter].strikeEvery)boss.strikeT=6000;
    }
    frozenT=0;
    running=true;
    lastFrameTime=performance.now();lastRenderTime=lastFrameTime;fpsWindowStart=lastFrameTime;fpsFrameCount=0;
    accumulator=0;
    gameLoopId=requestAnimationFrame(mainLoop);
  }

  reviveAdBtn.onclick=function(){showRewardedAd('revive');};

  revive150Btn.onclick=function(){
    if(apples>=150){apples-=150;saveData();reviveGame(null);}
  };

  revive500Btn.onclick=function(){
    if(apples<500)return;
    apples-=500;saveData();
    var keys=PK.slice();
    var p1=keys.splice(Math.floor(Math.random()*keys.length),1)[0];
    var p2=keys.splice(Math.floor(Math.random()*keys.length),1)[0];
    choice1Btn.textContent=PW[p1].n.split(':')[0];
    choice2Btn.textContent=PW[p2].n.split(':')[0];
    choice1Btn.onclick=function(){reviveGame(p1);};
    choice2Btn.onclick=function(){reviveGame(p2);};
    reviveSection.style.display='none';
    powerChoiceSection.style.display='block';
  };

  function drawRoundRect(x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
    ctx.fill();
  }

  function drawSnakeSegment(x, y, idx, total){
    var px = x * S, py = y * S;
    var isHead = (idx === 0);
    var isTail = (idx === total - 1 && total > 1);

    var headColor = darkMode ? '#9be564' : '#1b3811';
    var bodyColor = darkMode ? '#6ab04c' : '#2d5a1e';
    var stripeColor = darkMode ? '#badc58' : '#4a8536';

    var custom=null,outline=false;
    for(var ci=0;ci<SNAKE_COLORS.length;ci++){if(SNAKE_COLORS[ci].id===snakeColor&&snakeColor!=='green')custom=SNAKE_COLORS[ci];}
    if(activeSkin === 'default' && custom){
      headColor = custom.h; bodyColor = custom.c; stripeColor = custom.s;
    } else if(activeSkin === 'old'){
      headColor = '#6e6a5e'; bodyColor = '#a29c8a'; stripeColor = '#e2dccb';
    } else if(activeSkin === 'small'){
      headColor = '#1b97c9'; bodyColor = '#7fd4f0'; stripeColor = '#e6f8ff';
    } else if(activeSkin === 'black'){
      headColor = '#000000'; bodyColor = '#1d1d1d'; stripeColor = '#d32f2f'; outline = true;
    } else if(activeSkin === 'invisible'){
      headColor = '#7e94b8'; bodyColor = '#c3d3ea'; stripeColor = '#ffffff';
    } else if(activeSkin === 'strong'){
      headColor = '#5c1a00'; bodyColor = '#c0501a'; stripeColor = '#ffb27a';
    } else if(activeSkin === 'skin1'){
      headColor = '#ffd700'; bodyColor = '#e69500'; stripeColor = '#fff099';
    } else if(activeSkin === 'skin2'){
      headColor = '#00ffff'; bodyColor = '#b300b3'; stripeColor = '#ff80ff';
    } else if(nightmareMode && activeSkin==='default'){
      headColor = '#ff3838'; bodyColor = '#b31212'; stripeColor = '#ff7979';
    }

    if(isHead){
      if(Math.floor(frameTick / 8) % 2 === 0){
        ctx.fillStyle = '#d9534f';
        var lx = px + S/2 + dir[0]*(S/2 + 2);
        var ly = py + S/2 + dir[1]*(S/2 + 2);
        ctx.fillRect(lx - 2, ly - 2, 4, 4);
      }

      if(outline){ctx.fillStyle = '#9e9e9e';drawRoundRect(px, py, S, S, 7);}
      ctx.fillStyle = headColor;
      drawRoundRect(px + 1, py + 1, S - 2, S - 2, 6);

      var eye1X, eye1Y, eye2X, eye2Y;
      if(dir[0] === 1){
        eye1X = px + 13; eye1Y = py + 5;
        eye2X = px + 13; eye2Y = py + 13;
      } else if(dir[0] === -1){
        eye1X = px + 5; eye1Y = py + 5;
        eye2X = px + 5; eye2Y = py + 13;
      } else if(dir[1] === -1){
        eye1X = px + 5; eye1Y = py + 5;
        eye2X = px + 13; eye2Y = py + 5;
      } else {
        eye1X = px + 5; eye1Y = py + 13;
        eye2X = px + 13; eye2Y = py + 13;
      }

      ctx.fillStyle = '#ffffff';
      ctx.beginPath(); ctx.arc(eye1X, eye1Y, 2.6, 0, Math.PI*2); ctx.fill();
      ctx.beginPath(); ctx.arc(eye2X, eye2Y, 2.6, 0, Math.PI*2); ctx.fill();

      ctx.fillStyle = '#000000';
      ctx.beginPath(); ctx.arc(eye1X + dir[0]*0.8, eye1Y + dir[1]*0.8, 1.3, 0, Math.PI*2); ctx.fill();
      ctx.beginPath(); ctx.arc(eye2X + dir[0]*0.8, eye2Y + dir[1]*0.8, 1.3, 0, Math.PI*2); ctx.fill();

    } else {
      var pad = isTail ? 4 : 2;
      var radius = isTail ? 6 : 4;
      if(outline){ctx.fillStyle = '#9e9e9e';drawRoundRect(px + pad - 1, py + pad - 1, S - pad*2 + 2, S - pad*2 + 2, radius + 1);}
      ctx.fillStyle = bodyColor;
      drawRoundRect(px + pad, py + pad, S - pad*2, S - pad*2, radius);

      if(!isTail && idx % 2 === 1){
        ctx.fillStyle = stripeColor;
        drawRoundRect(px + 6, py + 6, S - 12, S - 12, 2);
      }
    }
  }

  function drawBossLayer(ink,lcd){
    if(!boss)return;
    var ch=CHAPTERS[adventureChapter],cx=boss.bx*S+S/2,i,blink=Math.floor(frameTick/4)%2===0;
    ctx.textAlign='center';ctx.textBaseline='middle';

    // البرك (الزعيم 2)
    boss.pools.forEach(function(pl){
      if(pl.age<700){
        if(blink){ctx.fillStyle='rgba(52,152,219,0.22)';ctx.fillRect(pl.x*S,0,pl.w*S,N*S);}
      }else if(10700-pl.age>2500||blink){
        ctx.fillStyle='rgba(52,152,219,0.42)';ctx.fillRect(pl.x*S,0,pl.w*S,N*S);
        ctx.fillStyle='rgba(255,255,255,0.35)';
        for(var yy=0;yy<N;yy++)ctx.fillRect(pl.x*S+3+((yy+frameTick)%3)*3,yy*S+8,5,2);
      }
    });
    // ممر الاندفاع (الزعيم 3)
    var dsx=cx,dsy=S/2,dashing=false;
    if(boss.dash){
      var dd=boss.dash;
      ctx.fillStyle=dd.run?'rgba(217,83,79,0.5)':(blink?'rgba(217,83,79,0.32)':'rgba(217,83,79,0.12)');
      if(dd.axis==='row')ctx.fillRect(0,dd.idx*S,N*S,S);else ctx.fillRect(dd.idx*S,0,S,N*S);
      if(dd.run){
        dashing=true;
        dsx=dd.axis==='row'?dd.pos*S+S/2:dd.idx*S+S/2;
        dsy=dd.axis==='row'?dd.idx*S+S/2:dd.pos*S+S/2;
      }
    }
    // خطوط الجليد (الزعيم 4)
    if(boss.ice){
      var ic=boss.ice;
      ic.lines.forEach(function(ln){
        ctx.fillStyle=ic.phase==='strike'?'rgba(210,245,255,0.85)':(blink?'rgba(120,200,255,0.38)':'rgba(120,200,255,0.15)');
        if(ln.axis==='row')ctx.fillRect(0,ln.idx*S,N*S,S);else ctx.fillRect(ln.idx*S,0,S,N*S);
      });
    }
    // تحذير الحجر الكبير (الزعيم 1) والصغير
    if(boss.bigT>0&&boss.bigT<=700&&blink){
      ctx.fillStyle='rgba(217,83,79,0.3)';
      ctx.fillRect(Math.max(0,boss.bx-1)*S,S,Math.min(N,boss.bx+2)*S-Math.max(0,boss.bx-1)*S,N*S-S);
    }
    if(boss.throwT>0&&boss.throwT<=600&&blink){
      ctx.fillStyle='#d9534f';ctx.font='bold 14px sans-serif';ctx.fillText('!',cx,S+S/2);
    }
    // جسم الزعيم
    if(adventureChapter===CHAPTERS.length-1){
      ctx.fillStyle='#161616';
      for(i=4;i>=1;i--)drawRoundRect(cx-i*11-7,4+i,14-i,12-i,4);
      drawRoundRect(cx-10,0,20,20,7);
      ctx.fillStyle='#ff2d2d';ctx.beginPath();ctx.arc(cx-4,8,2.2,0,Math.PI*2);ctx.fill();
      ctx.beginPath();ctx.arc(cx+4,8,2.2,0,Math.PI*2);ctx.fill();
    }else{
      ctx.font=(dashing?'26px':'24px')+' serif';ctx.fillStyle='#000';ctx.fillText(ch.bossEmoji,dashing?dsx:cx,dashing?dsy:S/2+1);
    }
    // الحجارة
    boss.shots.forEach(function(sh){
      if(sh.big){
        var x0=Math.max(0,sh.x-1),x1=Math.min(N-1,sh.x+1);
        ctx.fillStyle='#5a3a20';drawRoundRect(x0*S+1,sh.y*S+1,(x1-x0+1)*S-2,S-2,7);
        ctx.fillStyle='#8a6038';ctx.fillRect(x0*S+7,sh.y*S+6,5,5);ctx.fillRect(x1*S+8,sh.y*S+9,5,5);
      }else if(sh.ice){
        ctx.fillStyle='#bfe9ff';drawRoundRect(sh.x*S+2,sh.y*S+2,S-4,S-4,5);
        ctx.fillStyle='#ffffff';ctx.fillRect(sh.x*S+6,sh.y*S+6,4,4);
      }else{
        ctx.fillStyle='#6b4226';drawRoundRect(sh.x*S+2,sh.y*S+2,S-4,S-4,5);
        ctx.fillStyle='#a8764a';ctx.fillRect(sh.x*S+6,sh.y*S+6,4,4);
      }
    });
  }

  // طبقة تُرسم فوق كل شيء: الظلام، أحجار الثعبان الأسود، حروف B و G
  function drawBossOverlay(){
    if(!boss)return;
    var ch=CHAPTERS[adventureChapter],blink=Math.floor(frameTick/4)%2===0,st=boss.strike,h=snake[0];
    ctx.textAlign='center';ctx.textBaseline='middle';
    if(ch.dark){
      var hx=h[0]*S+S/2,hy=h[1]*S+S/2;
      var g=ctx.createRadialGradient(hx,hy,S*1.7,hx,hy,S*4.6);
      g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(0,0,0,0.97)');
      ctx.fillStyle=g;ctx.fillRect(0,0,N*S,N*S);
    }
    if(st){
      if(st.phase==='warn'){
        if(blink){ctx.fillStyle='rgba(217,83,79,0.16)';ctx.fillRect(0,0,N*S,N*S);}
        ctx.fillStyle='#ff6b6b';ctx.font='bold 13px sans-serif';
        ctx.fillText('⚠ احضر G خلال '+Math.max(0,Math.ceil((4200-st.t)/1000))+' ث',N*S/2,S*1.5);
      }else{
        for(var i=0;i<3;i++){
          var by=Math.floor((st.t-i*250)/70)-1;
          if(by<0)continue;
          ctx.fillStyle=st.prot?'rgba(120,200,120,0.4)':'#5a4632';
          drawRoundRect(BANDS[i][0]*S+1,(by-1)*S,(BANDS[i][1]-BANDS[i][0]+1)*S-2,2*S,6);
          if(!st.prot){ctx.fillStyle='#8a6d4a';ctx.fillRect(BANDS[i][0]*S+8,(by-1)*S+8,6,6);}
        }
      }
    }
    if(boss.gLetter){
      var gx=boss.gLetter.x*S,gy=boss.gLetter.y*S;
      ctx.save();ctx.shadowColor='#7CFC00';ctx.shadowBlur=blink?16:6;
      ctx.fillStyle='#7CFC00';drawRoundRect(gx+1,gy+1,S-2,S-2,5);ctx.restore();
      ctx.fillStyle='#10300a';ctx.font='bold 15px sans-serif';ctx.fillText('G',gx+S/2,gy+S/2+1);
    }
    if(boss.letter&&(boss.letterT<6500||blink)){
      var lx=boss.letter.x*S,ly=boss.letter.y*S;
      ctx.save();ctx.shadowColor='#ffd700';ctx.shadowBlur=ch.dark?12:0;
      ctx.fillStyle='#ffd700';drawRoundRect(lx+1,ly+1,S-2,S-2,5);ctx.restore();
      ctx.fillStyle='#1b2c18';ctx.font='bold 15px sans-serif';ctx.fillText('B',lx+S/2,ly+S/2+1);
    }
    if(adventureChapter===CHAPTERS.length-1){
      var qx=N*S-42,qy=3;
      ctx.fillStyle='#ff9ccc';drawRoundRect(qx,qy+3,10,11,4);drawRoundRect(qx+11,qy+3,10,11,4);
      ctx.fillStyle='#ff4fa3';drawRoundRect(qx+22,qy+1,14,15,5);
      ctx.fillStyle='#ffffff';ctx.fillRect(qx+29,qy+5,3,3);
      ctx.font='11px serif';ctx.fillStyle='#000';ctx.fillText('💗',qx+18,qy+20);
    }
    if(st&&st.prot){
      ctx.strokeStyle='#7CFC00';ctx.lineWidth=2;ctx.beginPath();
      ctx.arc(h[0]*S+S/2,h[1]*S+S/2,S*0.85,0,Math.PI*2);ctx.stroke();
    }
  }

  function draw(){
    var cs=getComputedStyle(document.documentElement);
    var lcd=cs.getPropertyValue('--lcd'),ink=cs.getPropertyValue('--ink'),gh=cs.getPropertyValue('--ghost');
    ctx.fillStyle=lcd;ctx.fillRect(0,0,320,320);
    ctx.fillStyle=gh;
    for(var i=0;i<N;i++)for(var j=0;j<N;j++)ctx.fillRect(i*S+9,j*S+9,2,2);
    if(DIFF[diffKey].walls){ctx.strokeStyle=ink;ctx.lineWidth=4;ctx.strokeRect(2,2,316,316)}
    
    if(hasEff('ghost')){
      ctx.strokeStyle=ink;
      ctx.lineWidth=2;
      snake.forEach(function(s){ctx.strokeRect(s[0]*S+2,s[1]*S+2,S-4,S-4)});
    } else {
      if(invisT>0)ctx.globalAlpha=0.12;
      for(var k = snake.length - 1; k >= 0; k--){
        drawSnakeSegment(snake[k][0], snake[k][1], k, snake.length);
      }
      ctx.globalAlpha=1;
    }

    if(pw&&(pw.life>15||pw.life%2===0)){
      var px=pw.x*S,py=pw.y*S;ctx.strokeStyle=ink;ctx.lineWidth=2;ctx.strokeRect(px+2,py+2,S-4,S-4);
      ctx.fillStyle=ink;ctx.font='bold 13px sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';
      ctx.fillText(PW[pw.t].l,px+S/2,py+S/2+1);
    }
    
    if(food){
      ctx.save();ctx.shadowColor='rgba(255,70,70,.65)';ctx.shadowBlur=9;
      ctx.fillStyle='#e64b4b';
      drawRoundRect(food[0]*S+3,food[1]*S+4,S-6,S-7, 5);ctx.restore();
      ctx.fillStyle='#556b4f';
      ctx.fillRect(food[0]*S+9,food[1]*S+1,3,4);
    }

    if(mg&&(mg.life>25||mg.life%2===0)){
      ctx.save();ctx.shadowColor='rgba(255,167,38,.8)';ctx.shadowBlur=8;
      ctx.font='17px serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle='#000';
      ctx.fillText('🥭',mg.x*S+S/2,mg.y*S+S/2+1);ctx.restore();
    }

    drawBossLayer(ink,lcd);
    stones.forEach(function(s){
      var x=s[0]*S,y=s[1]*S;
      ctx.fillStyle=ink;
      drawRoundRect(x+2,y+2,S-4,S-4, 3);
      ctx.fillStyle=lcd;ctx.fillRect(x+6,y+6,3,3);ctx.fillRect(x+11,y+11,3,3);
    });

    if(frozenT>0){
      ctx.fillStyle='rgba(150,220,255,0.65)';
      snake.forEach(function(sg){ctx.fillRect(sg[0]*S+1,sg[1]*S+1,S-2,S-2);});
      ctx.font='14px serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle='#000';
      ctx.fillText('🧊',snake[0][0]*S+S/2,snake[0][1]*S+S/2);
    }
    drawBossOverlay();
  }

  function showMenu(){
    running=false;paused=false;inGame=false;over_=false;
    if(gameLoopId)cancelAnimationFrame(gameLoopId);
    statScores.style.display='none';
    pauseOverlay.style.display='none';pauseBtn.style.display='none';pauseBtn.textContent='⏸';pauseBtn.setAttribute('aria-label','إيقاف مؤقت');
    statTitle.style.display='block';
    homeBtn.style.display='none';
    menuOverlay.style.display='flex';
    overOverlay.style.display='none';
    shopOverlay.style.display='none';
    settingsOverlay.style.display='none';
    storyOverlay.style.display='none';adventureCompleteOverlay.style.display='none';
    gameMode='classic';boss=null;mg=null;frozenT=0;pendingShield=false;pendingSlow=false;pregameOverlay.style.display='none';updateAdventureHUD();
    msg.textContent='';loadData();draw();
  }
  // ===== سؤال التعزيزات قبل بدء كل جيم =====
  function renderPregame(){
    pregameShieldBtn.style.display=shieldStock>0?'block':'none';
    pregameSlowBtn.style.display=slowStock>0?'block':'none';
    pregameShieldBtn.textContent='🛡️ درع الحماية (لديك '+shieldStock+'): '+(choiceShield?'سأستخدمه ✓':'لن أستخدمه');
    pregameSlowBtn.textContent='🐢 تعزيز البطء (لديك '+slowStock+'): '+(choiceSlow?'سأستخدمه ✓':'لن أستخدمه');
    pregameShieldBtn.classList.toggle('on',choiceShield);
    pregameSlowBtn.classList.toggle('on',choiceSlow);
  }
  function beginGame(startFn){
    if(shieldStock<=0&&slowStock<=0){pendingShield=false;pendingSlow=false;startFn();return;}
    pregameStartFn=startFn;renderPregame();pregameOverlay.style.display='flex';
  }
  pregameShieldBtn.onclick=function(){choiceShield=!choiceShield;renderPregame();};
  pregameSlowBtn.onclick=function(){choiceSlow=!choiceSlow;renderPregame();};
  pregameBackBtn.onclick=function(){pregameOverlay.style.display='none';pregameStartFn=null;};
  pregameStartBtn.onclick=function(){
    var useS=choiceShield&&shieldStock>0,useL=choiceSlow&&slowStock>0;
    pendingShield=useS;pendingSlow=useL;
    pregameOverlay.style.display='none';
    var f=pregameStartFn;pregameStartFn=null;
    if(f)f();
    var note=[];if(useS)note.push('🛡️ الدرع مفعّل');if(useL)note.push('🐢 البطء مفعّل');
    if(note.length)msg.textContent=(msg.textContent?msg.textContent+' · ':'')+note.join(' · ');
  };

  function startGameFromMenu(){beginGame(doStartClassic);}
  function doStartClassic(){
    h2Count=0;gameMode='classic';storyOverlay.style.display='none';adventureCompleteOverlay.style.display='none';
    menuOverlay.style.display='none';
    statTitle.style.display='none';
    statScores.style.display='flex';
    homeBtn.style.display='block';
    inGame=true;reset();go();
  }

  document.addEventListener('keydown',function(e){
    var key=e.key;
    if(key==='p'||key==='P'||key===' '){
      if(inGame&&!over_){e.preventDefault();togglePause();}
      return;
    }
    var m={ArrowUp:'u',ArrowDown:'d',ArrowLeft:'l',ArrowRight:'r',w:'u',W:'u',s:'d',S:'d',a:'l',A:'l',d:'r',D:'r'}[key];
    if(m){e.preventDefault();setDir(m)}
    if(key==='Escape'&&inGame)showMenu();
  });
  pauseBtn.addEventListener('click',togglePause);
  resumeBtn.addEventListener('click',resumeGame);
  pauseRestartBtn.addEventListener('click',function(){beginGame(function(){reset();go();});});
  pauseMenuBtn.addEventListener('click',showMenu);
  document.addEventListener('visibilitychange',function(){
    if(document.hidden&&inGame&&running)pauseGame();
  });
  document.querySelectorAll('.pad button').forEach(function(b){
    b.addEventListener('pointerdown',function(e){e.preventDefault();setDir(b.dataset.d);});
    b.addEventListener('keydown',function(e){if(e.key==='Enter'){e.preventDefault();setDir(b.dataset.d);}});
  });
  
  document.getElementById('menuStart').addEventListener('click',startGameFromMenu);
  document.getElementById('restartBtn').addEventListener('click',function(){beginGame(function(){reset();go();});});
  document.getElementById('toMenuBtn').addEventListener('click',showMenu);
  homeBtn.addEventListener('click',showMenu);

  document.querySelectorAll('#diff button').forEach(function(b){
    b.addEventListener('click',function(){
      diffKey=b.dataset.k;
      document.querySelectorAll('#diff button').forEach(function(x){x.classList.toggle('on',x===b)});
      loadData();playTone(300,'sine',0.05,0.03);
    });
  });

  soundToggle.addEventListener('click',function(){
    soundOn=!soundOn;soundToggle.textContent=soundOn?'🔊':'🔇';
    if(soundOn)playTone(500,'sine',0.05,0.03);
  });
  padToggle.addEventListener('click',function(){
    padVisible=!padVisible;padContainer.classList.toggle('hidden',!padVisible);
    padToggle.style.opacity=padVisible?'1':'0.5';
  });

  // ===== التحكم باللمس: اسحب في أي مكان على الشاشة، ويُحسب الاتجاه فورًا أثناء السحب =====
  var swipeId=null,swipeX=0,swipeY=0;
  function findTouch(list,id){
    for(var i=0;i<list.length;i++)if(list[i].identifier===id)return list[i];
    return null;
  }
  document.addEventListener('touchstart',function(e){
    if(!inGame||paused||over_||controlMode==='pad')return;
    if(swipeId!==null)return;
    var t=e.changedTouches[0];
    swipeId=t.identifier;swipeX=t.clientX;swipeY=t.clientY;
  },{passive:true});
  document.addEventListener('touchmove',function(e){
    if(swipeId===null)return;
    if(!inGame||paused||over_||controlMode==='pad'){swipeId=null;return;}
    var t=findTouch(e.changedTouches,swipeId);if(!t)return;
    if(e.cancelable)e.preventDefault();
    var dx=t.clientX-swipeX,dy=t.clientY-swipeY;
    if(Math.max(Math.abs(dx),Math.abs(dy))<swipeThreshold)return;
    setDir(Math.abs(dx)>Math.abs(dy)?(dx>0?'r':'l'):(dy>0?'d':'u'));
    swipeX=t.clientX;swipeY=t.clientY; // نقطة جديدة: يمكنك الالتفاف مرة أخرى دون رفع إصبعك
  },{passive:false});
  function endSwipe(e){if(swipeId!==null&&findTouch(e.changedTouches,swipeId))swipeId=null;}
  document.addEventListener('touchend',endSwipe,{passive:true});
  document.addEventListener('touchcancel',endSwipe,{passive:true});
  // اللمس على لوحة اللعبة قبل بدء الحركة (الثعبان واقف) يبدأ الجولة
  cv.addEventListener('contextmenu',function(e){e.preventDefault();});

  loadData();reset();updateAdStatus();
})();
