/* =========================================================
   FAIRY TALES ENGLISH STORY APP

   Blogger:
   https://fairyenglishstory.blogspot.com/

   Firebase:
   fairy-english-story
========================================================= */


/* =========================================================
   FIREBASE IMPORTS
========================================================= */

import {
  initializeApp
} from
"https://www.gstatic.com/firebasejs/12.2.1/firebase-app.js";


import {
  getAuth,
  signInAnonymously
} from
"https://www.gstatic.com/firebasejs/12.2.1/firebase-auth.js";


import {
  getFirestore,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  increment,
  collection,
  addDoc,
  query,
  orderBy,
  getDocs,
  serverTimestamp,
  runTransaction
} from
"https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";


/* =========================================================
   FIREBASE CONFIG
========================================================= */

const firebaseConfig = {

  apiKey:
    "AIzaSyDKw04a-EP_2HqfMOqjUkgfo-n0xp3yGHg",

  authDomain:
    "fairy-english-story.firebaseapp.com",

  projectId:
    "fairy-english-story",

  storageBucket:
    "fairy-english-story.firebasestorage.app",

  messagingSenderId:
    "214833715146",

  appId:
    "1:214833715146:web:a407b307042819b6db6133",

  measurementId:
    "G-RYF5966W0Y"

};


/* =========================================================
   INITIALIZE FIREBASE
========================================================= */

const app =
  initializeApp(firebaseConfig);


const auth =
  getAuth(app);


const db =
  getFirestore(app);


/* =========================================================
   BLOGGER
========================================================= */

const BLOG_URL =
  "https://fairyenglishstory.blogspot.com/";


const FEED_URL =
  BLOG_URL +
  "feeds/posts/default" +
  "?alt=json-in-script" +
  "&max-results=50";


/* =========================================================
   VARIABLES
========================================================= */

let allStories = [];

let currentCommentStory = null;


/* =========================================================
   HTML ELEMENTS
========================================================= */

const storiesContainer =
  document.getElementById(
    "storiesContainer"
  );


const loading =
  document.getElementById(
    "loading"
  );


const errorBox =
  document.getElementById(
    "errorBox"
  );


const errorText =
  document.getElementById(
    "errorText"
  );


const noResults =
  document.getElementById(
    "noResults"
  );


const searchInput =
  document.getElementById(
    "searchInput"
  );


const refreshBtn =
  document.getElementById(
    "refreshBtn"
  );


const retryBtn =
  document.getElementById(
    "retryBtn"
  );


const year =
  document.getElementById(
    "year"
  );


const commentModal =
  document.getElementById(
    "commentModal"
  );


const closeCommentBtn =
  document.getElementById(
    "closeCommentBtn"
  );


const commentStoryTitle =
  document.getElementById(
    "commentStoryTitle"
  );


const commentsList =
  document.getElementById(
    "commentsList"
  );


const commentInput =
  document.getElementById(
    "commentInput"
  );


const submitCommentBtn =
  document.getElementById(
    "submitCommentBtn"
  );


year.textContent =
  new Date().getFullYear();


/* =========================================================
   START APP
========================================================= */

startApp();


async function startApp() {

  try {

    /*
      Anonymous Firebase login.
    */

    await signInAnonymously(
      auth
    );


    console.log(
      "Firebase user:",
      auth.currentUser.uid
    );


    /*
      Load Blogger stories.
    */

    loadStories();


  } catch (error) {

    console.error(
      "Firebase authentication error:",
      error
    );


    showError(
      "Firebase login failed. Enable Anonymous Authentication in Firebase Console."
    );

  }

}


/* =========================================================
   BLOGGER JSONP
========================================================= */

function loadStories() {

  showLoading();

  hideError();


  const oldScript =
    document.getElementById(
      "bloggerFeedScript"
    );


  if (oldScript) {

    oldScript.remove();

  }


  const callbackName =
    "bloggerCallback_" +
    Date.now();


  window[callbackName] =
    function(data) {

      try {

        processBloggerData(
          data
        );

      } catch (error) {

        console.error(
          error
        );


        showError(
          "Could not process Blogger stories."
        );

      } finally {

        cleanupCallback(
          callbackName
        );

      }

    };


  const script =
    document.createElement(
      "script"
    );


  script.id =
    "bloggerFeedScript";


  script.src =
    FEED_URL +
    "&callback=" +
    callbackName;


  script.async =
    true;


  script.onerror =
    function() {

      cleanupCallback(
        callbackName
      );


      showError(
        "Could not connect to Blogger."
      );

    };


  document.body.appendChild(
    script
  );


  setTimeout(
    function() {

      if (
        !loading.classList.contains(
          "hidden"
        )
      ) {

        cleanupCallback(
          callbackName
        );


        showError(
          "Blogger feed is taking too long to respond."
        );

      }

    },
    15000
  );

}


/* =========================================================
   PROCESS BLOGGER DATA
========================================================= */

function processBloggerData(
  data
) {

  if (
    !data ||
    !data.feed ||
    !data.feed.entry
  ) {

    allStories = [];

    renderStories(
      []
    );

    hideLoading();

    return;

  }


  allStories =
    data.feed.entry.map(
      function(entry) {

        return convertEntry(
          entry
        );

      }
    );


  renderStories(
    allStories
  );


  hideLoading();

}


/* =========================================================
   CONVERT BLOGGER POST
========================================================= */

function convertEntry(
  entry
) {

  const title =
    entry.title &&
    entry.title.$t
      ? entry.title.$t
      : "Untitled Story";


  const content =
    entry.content &&
    entry.content.$t
      ? entry.content.$t
      : "";


  const url =
    getPostUrl(
      entry
    );


  const date =
    entry.published &&
    entry.published.$t
      ? entry.published.$t
      : "";


  const image =
    getFirstImage(
      content
    );


  const description =
    getDescription(
      content
    );


  return {

    id:
      createPostId(
        entry
      ),

    title:
      title,

    content:
      content,

    description:
      description,

    image:
      image,

    url:
      url,

    date:
      date

  };

}


/* =========================================================
   POST URL
========================================================= */

function getPostUrl(
  entry
) {

  if (
    !entry.link
  ) {

    return BLOG_URL;

  }


  for (
    const link of entry.link
  ) {

    if (
      link.rel ===
      "alternate"
    ) {

      return link.href;

    }

  }


  return BLOG_URL;

}


/* =========================================================
   POST ID
========================================================= */

function createPostId(
  entry
) {

  if (
    entry.id &&
    entry.id.$t
  ) {

    return entry.id.$t
      .replace(
        /[^a-zA-Z0-9]/g,
        "_"
      );

  }


  return encodeURIComponent(
    entry.title &&
    entry.title.$t
      ? entry.title.$t
      : Math.random()
  );

}


/* =========================================================
   IMAGE
========================================================= */

function getFirstImage(
  html
) {

  if (!html) {

    return "";

  }


  const parser =
    new DOMParser();


  const doc =
    parser.parseFromString(
      html,
      "text/html"
    );


  const img =
    doc.querySelector(
      "img"
    );


  if (img) {

    return (
      img.getAttribute(
        "src"
      ) ||
      img.getAttribute(
        "data-src"
      ) ||
      ""
    );

  }


  return "";

}


/* =========================================================
   DESCRIPTION
========================================================= */

function getDescription(
  html
) {

  if (!html) {

    return "";

  }


  const parser =
    new DOMParser();


  const doc =
    parser.parseFromString(
      html,
      "text/html"
    );


  const text =
    doc.body
      ? doc.body.textContent
      : "";


  return text
    .replace(
      /\s+/g,
      " "
    )
    .trim()
    .substring(
      0,
      180
    );

}


/* =========================================================
   RENDER STORIES
========================================================= */

function renderStories(
  stories
) {

  storiesContainer.innerHTML =
    "";


  noResults.classList.add(
    "hidden"
  );


  if (
    !stories ||
    stories.length === 0
  ) {

    noResults.classList.remove(
      "hidden"
    );

    return;

  }


  stories.forEach(
    function(story) {

      const card =
        createStoryCard(
          story
        );


      storiesContainer.appendChild(
        card
      );


      /*
        Load Firebase statistics.
      */

      loadStatistics(
        story
      );

    }
  );

}


/* =========================================================
   STORY CARD
========================================================= */

function createStoryCard(
  story
) {

  const card =
    document.createElement(
      "article"
    );


  card.className =
    "story-card";


  /* IMAGE */

  const image =
    document.createElement(
      "img"
    );


  image.className =
    "story-image";


  image.alt =
    story.title;


  image.src =
    story.image ||
    createPlaceholder(
      story.title
    );


  image.onerror =
    function() {

      this.src =
        createPlaceholder(
          story.title
        );

    };


  /* BODY */

  const body =
    document.createElement(
      "div"
    );


  body.className =
    "story-body";


  /* TITLE */

  const title =
    document.createElement(
      "h3"
    );


  title.className =
    "story-title";


  title.textContent =
    story.title;


  /* DATE */

  const date =
    document.createElement(
      "div"
    );


  date.className =
    "story-date";


  date.textContent =
    formatDate(
      story.date
    );


  /* DESCRIPTION */

  const description =
    document.createElement(
      "p"
    );


  description.className =
    "story-description";


  description.textContent =
    story.description ||
    "Read this amazing story.";


  /* STATS */

  const stats =
    document.createElement(
      "div"
    );


  stats.className =
    "story-stats";


  const views =
    document.createElement(
      "span"
    );


  views.className =
    "stat";


  views.dataset.views =
    story.id;


  views.textContent =
    "👁️ 0";


  const likes =
    document.createElement(
      "span"
    );


  likes.className =
    "stat";


  likes.dataset.likes =
    story.id;


  likes.textContent =
    "❤️ 0";


  stats.appendChild(
    views
  );


  stats.appendChild(
    likes
  );


  /* ACTIONS */

  const actions =
    document.createElement(
      "div"
    );


  actions.className =
    "story-actions";


  /* READ */

  const readButton =
    document.createElement(
      "a"
    );


  readButton.className =
    "read-btn";


  readButton.href =
    story.url;


  readButton.target =
    "_blank";


  readButton.rel =
    "noopener noreferrer";


  readButton.textContent =
    "📖 Read Story";


  /*
    View count when Read Story is clicked.
  */

  readButton.addEventListener(
    "click",
    function() {

      recordView(
        story
      );

    }
  );


  /* LIKE */

  const likeButton =
    document.createElement(
      "button"
    );


  likeButton.className =
    "like-btn";


  likeButton.type =
    "button";


  likeButton.textContent =
    "♡";


  updateLikeState(
    likeButton,
    story
  );


  likeButton.addEventListener(
    "click",
    async function() {

      await toggleLike(
        story,
        likeButton
      );

    }
  );


  /* COMMENT */

  const commentButton =
    document.createElement(
      "button"
    );


  commentButton.className =
    "comment-btn";


  commentButton.type =
    "button";


  commentButton.textContent =
    "💬";


  commentButton.addEventListener(
    "click",
    function() {

      openComments(
        story
      );

    }
  );


  /* SHARE */

  const shareButton =
    document.createElement(
      "button"
    );


  shareButton.className =
    "share-btn";


  shareButton.type =
    "button";


  shareButton.textContent =
    "🔗";


  shareButton.addEventListener(
    "click",
    function() {

      shareStory(
        story
      );

    }
  );


  actions.appendChild(
    readButton
  );


  actions.appendChild(
    likeButton
  );


  actions.appendChild(
    commentButton
  );


  actions.appendChild(
    shareButton
  );


  body.appendChild(
    title
  );


  body.appendChild(
    date
  );


  body.appendChild(
    description
  );


  body.appendChild(
    stats
  );


  body.appendChild(
    actions
  );


  card.appendChild(
    image
  );


  card.appendChild(
    body
  );


  return card;

}


/* =========================================================
   FIRESTORE STORY DOCUMENT
========================================================= */

function storyRef(
  story
) {

  return doc(
    db,
    "stories",
    story.id
  );

}


/* =========================================================
   LOAD STATISTICS
========================================================= */

async function loadStatistics(
  story
) {

  try {

    const ref =
      storyRef(
        story
      );


    const snapshot =
      await getDoc(
        ref
      );


    if (
      snapshot.exists()
    ) {

      const data =
        snapshot.data();


      updateStatisticsUI(
        story.id,
        data.likes || 0,
        data.views || 0
      );

    } else {

      updateStatisticsUI(
        story.id,
        0,
        0
      );

    }


    updateLikeUI(
      story
    );

  } catch (error) {

    console.error(
      "Statistics error:",
      error
    );

  }

}


/* =========================================================
   UPDATE STATISTICS UI
========================================================= */

function updateStatisticsUI(
  storyId,
  likes,
  views
) {

  const likesElement =
    document.querySelector(
      `[data-likes="${storyId}"]`
    );


  const viewsElement =
    document.querySelector(
      `[data-views="${storyId}"]`
    );


  if (likesElement) {

    likesElement.textContent =
      "❤️ " +
      likes;

  }


  if (viewsElement) {

    viewsElement.textContent =
      "👁️ " +
      views;

  }

}


/* =========================================================
   VIEW
========================================================= */

async function recordView(
  story
) {

  /*
    Avoid counting the same device
    repeatedly during the same session.
  */

  const key =
    "viewed_" +
    story.id;


  if (
    sessionStorage.getItem(
      key
    )
  ) {

    return;

  }


  sessionStorage.setItem(
    key,
    "true"
  );


  try {

    const ref =
      storyRef(
        story
      );


    await setDoc(
      ref,
      {

        title:
          story.title,

        url:
          story.url,

        views:
          increment(1),

        updatedAt:
          serverTimestamp()

      },
      {
        merge: true
      }
    );


    loadStatistics(
      story
    );


  } catch (error) {

    console.error(
      "View error:",
      error
    );

  }

}


/* =========================================================
   LIKE
========================================================= */

async function toggleLike(
  story,
  button
) {

  if (
    !auth.currentUser
  ) {

    alert(
      "Please wait for Firebase login."
    );

    return;

  }


  const uid =
    auth.currentUser.uid;


  const likeRef =
    doc(
      db,
      "stories",
      story.id,
      "likes",
      uid
    );


  const storyDocument =
    storyRef(
      story
    );


  try {

    const likeSnapshot =
      await getDoc(
        likeRef
      );


    if (
      likeSnapshot.exists()
    ) {

      /*
        UNLIKE
      */

      /*
        Delete is imported below
        dynamically to keep code
        simple.
      */

      const {
        deleteDoc
      } = await import(
        "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js"
      );


      await deleteDoc(
        likeRef
      );


      await setDoc(
        storyDocument,
        {

          title:
            story.title,

          url:
            story.url,

          likes:
            increment(-1),

          updatedAt:
            serverTimestamp()

        },
        {
          merge: true
        }
      );


      button.classList.remove(
        "liked"
      );


      button.textContent =
        "♡";


    } else {

      /*
        LIKE
      */

      await setDoc(
        likeRef,
        {

          uid:
            uid,

          createdAt:
            serverTimestamp()

        }
      );


      await setDoc(
        storyDocument,
        {

          title:
            story.title,

          url:
            story.url,

          likes:
            increment(1),

          updatedAt:
            serverTimestamp()

        },
        {
          merge: true
        }
      );


      button.classList.add(
        "liked"
      );


      button.textContent =
        "❤️";

    }


    loadStatistics(
      story
    );


  } catch (error) {

    console.error(
      "Like error:",
      error
    );


    alert(
      "Like could not be saved. Check Firestore Rules."
    );

  }

}


/* =========================================================
   UPDATE LIKE STATE
========================================================= */

async function updateLikeState(
  button,
  story
) {

  if (
    !auth.currentUser
  ) {

    return;

  }


  try {

    const likeRef =
      doc(
        db,
        "stories",
        story.id,
        "likes",
        auth.currentUser.uid
      );


    const snapshot =
      await getDoc(
        likeRef
      );


    if (
      snapshot.exists()
    ) {

      button.classList.add(
        "liked"
      );


      button.textContent =
        "❤️";

    }

  } catch (error) {

    console.error(
      error
    );

  }

}


/* =========================================================
   UPDATE LIKE UI
========================================================= */

function updateLikeUI(
  story
) {

  const buttons =
    document.querySelectorAll(
      ".like-btn"
    );


  buttons.forEach(
    function(button) {

      /*
        State is checked when user
        clicks or data loads.
      */

    }
  );

}


/* =========================================================
   COMMENTS
========================================================= */

async function openComments(
  story
) {

  currentCommentStory =
    story;


  commentStoryTitle.textContent =
    story.title;


  commentModal.classList.remove(
    "hidden"
  );


  commentInput.value =
    "";


  await loadComments(
    story
  );

}


/* =========================================================
   LOAD COMMENTS
========================================================= */

async function loadComments(
  story
) {

  commentsList.innerHTML =
    '<div class="no-comments">Loading comments...</div>';


  try {

    const commentsRef =
      collection(
        db,
        "stories",
        story.id,
        "comments"
      );


    const commentsQuery =
      query(
        commentsRef,
        orderBy(
          "createdAt",
          "desc"
        )
      );


    const snapshot =
      await getDocs(
        commentsQuery
      );


    commentsList.innerHTML =
      "";


    if (
      snapshot.empty
    ) {

      commentsList.innerHTML =
        '<div class="no-comments">No comments yet. Be the first!</div>';

      return;

    }


    snapshot.forEach(
      function(documentSnapshot) {

        const data =
          documentSnapshot.data();


        const item =
          document.createElement(
            "div"
          );


        item.className =
          "comment-item";


        const name =
          document.createElement(
            "div"
          );


        name.className =
          "comment-name";


        name.textContent =
          "👤 " +
          (
            data.name ||
            "Anonymous Reader"
          );


        const text =
          document.createElement(
            "div"
          );


        text.className =
          "comment-text";


        text.textContent =
          data.text ||
          "";


        const date =
          document.createElement(
            "div"
          );


        date.className =
          "comment-date";


        date.textContent =
          formatFirebaseDate(
            data.createdAt
          );


        item.appendChild(
          name
        );


        item.appendChild(
          text
        );


        item.appendChild(
          date
        );


        commentsList.appendChild(
          item
        );

      }
    );


  } catch (error) {

    console.error(
      "Comment loading error:",
      error
    );


    commentsList.innerHTML =
      '<div class="no-comments">Comments could not be loaded.</div>';

  }

}


/* =========================================================
   POST COMMENT
========================================================= */

submitCommentBtn.addEventListener(
  "click",
  async function() {

    if (
      !currentCommentStory
    ) {

      return;

    }


    const text =
      commentInput.value
        .trim();


    if (!text) {

      alert(
        "Please write a comment."
      );

      return;

    }


    if (
      text.length > 500
    ) {

      alert(
        "Comment must be under 500 characters."
      );

      return;

    }


    if (
      !auth.currentUser
    ) {

      alert(
        "Firebase login is not ready."
      );

      return;

    }


    submitCommentBtn.disabled =
      true;


    submitCommentBtn.textContent =
      "Posting...";


    try {

      const commentsRef =
        collection(
          db,
          "stories",
          currentCommentStory.id,
          "comments"
        );


      await addDoc(
        commentsRef,
        {

          uid:
            auth.currentUser.uid,

          name:
            "Anonymous Reader",

          text:
            text,

          createdAt:
            serverTimestamp()

        }
      );


      commentInput.value =
        "";


      await loadComments(
        currentCommentStory
      );


    } catch (error) {

      console.error(
        "Comment error:",
        error
      );


      alert(
        "Comment could not be posted. Check Firestore Rules."
      );

    }


    submitCommentBtn.disabled =
      false;


    submitCommentBtn.textContent =
      "Post Comment";

  }
);


/* =========================================================
   CLOSE COMMENTS
========================================================= */

closeCommentBtn.addEventListener(
  "click",
  closeComments
);


commentModal.addEventListener(
  "click",
  function(event) {

    if (
      event.target ===
      commentModal
    ) {

      closeComments();

    }

  }
);


function closeComments() {

  commentModal.classList.add(
    "hidden"
  );

  currentCommentStory =
    null;

}


/* =========================================================
   SEARCH
========================================================= */

searchInput.addEventListener(
  "input",
  function() {

    const queryText =
      this.value
        .toLowerCase()
        .trim();


    if (!queryText) {

      renderStories(
        allStories
      );

      return;

    }


    const filtered =
      allStories.filter(
        function(story) {

          return (

            story.title
              .toLowerCase()
              .includes(
                queryText
              )

            ||

            story.description
              .toLowerCase()
              .includes(
                queryText
              )

          );

        }
      );


    renderStories(
      filtered
    );

  }
);


/* =========================================================
   SHARE
========================================================= */

async function shareStory(
  story
) {

  const shareData = {

    title:
      story.title,

    text:
      "Read: " +
      story.title,

    url:
      story.url

  };


  if (
    navigator.share
  ) {

    try {

      await navigator.share(
        shareData
      );

    } catch (error) {

      console.log(
        "Share cancelled."
      );

    }

    return;

  }


  try {

    await navigator.clipboard.writeText(
      story.url
    );


    alert(
      "Story link copied!"
    );

  } catch (error) {

    prompt(
      "Copy story link:",
      story.url
    );

  }

}


/* =========================================================
   DATE
========================================================= */

function formatDate(
  dateString
) {

  if (!dateString) {

    return "";

  }


  const date =
    new Date(
      dateString
    );


  if (
    isNaN(
      date.getTime()
    )
  ) {

    return "";

  }


  return date.toLocaleDateString(
    "en-IN",
    {

      day:
        "numeric",

      month:
        "short",

      year:
        "numeric"

    }
  );

}


/* =========================================================
   FIREBASE TIMESTAMP DATE
========================================================= */

function formatFirebaseDate(
  timestamp
) {

  if (
    !timestamp
  ) {

    return "Just now";

  }


  try {

    const date =
      timestamp.toDate();


    return date.toLocaleString(
      "en-IN",
      {

        day:
          "numeric",

        month:
          "short",

        year:
          "numeric",

        hour:
          "numeric",

        minute:
          "2-digit"

      }
    );

  } catch (error) {

    return "Recently";

  }

}


/* =========================================================
   PLACEHOLDER
========================================================= */

function createPlaceholder(
  title
) {

  return (
    "https://placehold.co/800x450/" +
    "?text=" +
    encodeURIComponent(
      title.substring(
        0,
        30
      )
    )
  );

}


/* =========================================================
   LOADING
========================================================= */

function showLoading() {

  loading.classList.remove(
    "hidden"
  );

  storiesContainer.innerHTML =
    "";

  noResults.classList.add(
    "hidden"
  );

}


function hideLoading() {

  loading.classList.add(
    "hidden"
  );

}


/* =========================================================
   ERROR
========================================================= */

function showError(
  message
) {

  hideLoading();


  errorText.textContent =
    message;


  errorBox.classList.remove(
    "hidden"
  );

}


function hideError() {

  errorBox.classList.add(
    "hidden"
  );

}


/* =========================================================
   REFRESH
========================================================= */

refreshBtn.addEventListener(
  "click",
  function() {

    loadStories();

  }
);


retryBtn.addEventListener(
  "click",
  function() {

    startApp();

  }
);


/* =========================================================
   CLEAN BLOGGER CALLBACK
========================================================= */

function cleanupCallback(
  callbackName
) {

  try {

    delete window[
      callbackName
    ];

  } catch (error) {

    window[
      callbackName
    ] = undefined;

  }


  const script =
    document.getElementById(
      "bloggerFeedScript"
    );


  if (script) {

    script.remove();

  }

}