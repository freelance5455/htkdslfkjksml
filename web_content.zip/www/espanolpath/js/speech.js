// speech.js
// Tudo relacionado a voz: texto-para-fala (Web Speech Synthesis) para
// ouvir o vocabulário/frases, reconhecimento de fala (Web Speech
// Recognition) para a prática de "Falar" e para a gravação pelo
// microfone na aba "Gravar", e a análise local de um arquivo de
// áudio/vídeo enviado (duração, silêncio, variação de energia — sem
// transcrição real).

import { D } from "./data.js";
import { state, dn, xp, save } from "./state.js";
import { esc, norm, toast } from "./utils.js";

// Acesso ao plugin nativo Capacitor Text-to-Speech, quando o app está
// empacotado como APK (window.Capacitor presente). Em uma página web comum
// (sem Capacitor) isso retorna null e cai para a Web Speech API abaixo —
// o WebView do Android muitas vezes não expõe speechSynthesis com vozes
// instaladas, por isso o plugin nativo é a forma confiável de ter áudio
// dentro do app empacotado.
function nativeTTS() {
  try {
    return window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()
      ? window.Capacitor.Plugins.TextToSpeech
      : null;
  } catch (e) {
    return null;
  }
}

export function say(t, slow) {
  const T = nativeTTS();
  if (T) {
    document.body.classList.add("speaking");
    T.speak({ text: t, lang: "es-ES", rate: slow ? 0.6 : 0.88, pitch: 1, volume: 1, category: "ambient" })
      .catch(() => toast("Áudio indisponível neste dispositivo."))
      .finally(() => document.body.classList.remove("speaking"));
    return;
  }
  try {
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(t);
    u.lang = "es-ES";
    u.rate = slow ? 0.6 : 0.88;
    u.onstart = () => document.body.classList.add("speaking");
    u.onend = u.onerror = () => document.body.classList.remove("speaking");
    speechSynthesis.speak(u);
  } catch (e) {
    toast("Áudio indisponível neste navegador.");
  }
}

// Reproduz o áudio de vocabulário (w), listening (l) ou fala (f) do dia atual.
export function sp(k, i, slow, render) {
  const d = D[state.day];
  say(k == "w" ? d.w[i][0] : k == "l" ? d.l[i][0] : d.f[i], slow);
}

// Marca uma atividade (pronúncia/escrita/escuta/fala) como concluída e
// concede XP (10 para escrita/fala, 5 para pronúncia/escuta), igual ao
// comportamento original.
export function mark(k, render) {
  const x = dn(state.day);
  if (!x[k]) {
    x[k] = 1;
    xp(k[0] == "w" || k[0] == "f" ? 10 : 5);
  }
  save();
  render();
}

export function speak(k, render) {
  const R = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!R) {
    state.SR[k] = { ok: 0, t: "Seu navegador não reconhece fala. Repita em voz alta e toque em Feito." };
    render();
    return;
  }
  const r = new R();
  r.lang = "es-ES";
  state.mic = k;
  render();

  r.onresult = (e) => {
    const h = norm(e.results[0][0].transcript).split(" ");
    const t = norm(D[state.day].f[k]).split(" ");
    const ok = t.filter((w) => h.includes(w)).length / t.length >= 0.6;
    state.SR[k] = {
      ok,
      t: ok
        ? "Excelente pronúncia!"
        : "Entendi «" + esc(e.results[0][0].transcript) + "». Ouça o modelo e tente de novo.",
    };
    state.mic = null;
    if (ok) mark("f" + k, render);
    else render();
  };
  r.onerror = () => {
    state.mic = null;
    toast("Não consegui ouvir. Verifique o microfone.");
    render();
  };
  r.onend = () => {
    if (state.mic == k) {
      state.mic = null;
      render();
    }
  };
  r.start();
}

// ===== Gravar + reconhecer (aba "Gravar") =====
// Pede acesso ao microfone, grava com MediaRecorder (para o usuário poder
// ouvir a própria fala depois) e, em paralelo, usa a Web Speech
// Recognition API para transcrever o que foi dito. Ao final, compara a
// transcrição com o vocabulário (w) e as frases (f) do dia atual,
// indicando o que foi reconhecido e o que não foi — uma aproximação de
// correção de pronúncia (depende do reconhecedor de fala do navegador,
// não é uma análise fonética real).
export function startMicRecording(render) {
  const R = window.SpeechRecognition || window.webkitSpeechRecognition;

  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    toast("Seu navegador não permite acesso ao microfone.");
    return;
  }
  if (!R) {
    toast("Seu navegador não tem reconhecimento de fala. Tente o Chrome ou Edge.");
    return;
  }

  state.recording = true;
  state.recTranscript = "";
  state.recResult = null;
  render();

  navigator.mediaDevices
    .getUserMedia({ audio: true })
    .then((stream) => {
      let chunks = [];
      const mr = new MediaRecorder(stream);
      mr.ondataavailable = (e) => chunks.push(e.data);
      mr.onstop = () => {
        const blob = new Blob(chunks, { type: "audio/webm" });
        state.recBlobUrl = URL.createObjectURL(blob);
      };
      mr.start();

      const recognizer = new R();
      recognizer.lang = "es-ES";
      recognizer.continuous = true;
      recognizer.interimResults = false;

      state._recStream = stream;
      state._recognizer = recognizer;
      state._mediaRecorder = mr;

      recognizer.onresult = (e) => {
        let text = "";
        for (let i = e.resultIndex; i < e.results.length; i++) {
          text += e.results[i][0].transcript + " ";
        }
        state.recTranscript += text;
        render();
      };
      recognizer.onerror = () => {
        toast("Não consegui ouvir. Verifique o microfone.");
      };
      recognizer.start();
    })
    .catch(() => {
      state.recording = false;
      toast("Permissão de microfone negada ou indisponível.");
      render();
    });
}

export function stopMicRecording(render) {
  if (state._recognizer) {
    try {
      state._recognizer.stop();
    } catch (e) {
      /* já parado */
    }
    state._recognizer = null;
  }
  if (state._mediaRecorder && state._mediaRecorder.state !== "inactive") {
    state._mediaRecorder.stop();
  }
  state._mediaRecorder = null;
  if (state._recStream) {
    state._recStream.getTracks().forEach((t) => t.stop());
    state._recStream = null;
  }
  state.recording = false;

  const d = D[state.day];
  const heard = norm(state.recTranscript).split(" ").filter(Boolean);

  if (!heard.length) {
    state.recResult = {
      ok: false,
      summary: "Não entendi nenhuma palavra. Fale mais alto e perto do microfone, e tente de novo.",
      matched: [],
      missed: [],
    };
    render();
    return;
  }

  // Compara com o vocabulário (w) e as frases de fala (f) do dia atual.
  const targets = [...d.w.map((w) => w[0]), ...d.f];
  const matched = [];
  const missed = [];
  targets.forEach((phrase) => {
    const words = norm(phrase).split(" ").filter(Boolean);
    const hits = words.filter((w) => heard.includes(w)).length;
    const ratio = words.length ? hits / words.length : 0;
    if (ratio >= 0.6) matched.push(phrase);
    else missed.push(phrase);
  });

  const ok = matched.length > 0;
  if (ok) xp(15, "🎙️ Fala reconhecida");

  const transcriptEsc = esc(state.recTranscript.trim());
  state.recResult = {
    ok,
    summary: ok
      ? "Reconheci «" + transcriptEsc + "». Encontrei " + matched.length + " palavra(s)/frase(s) do dia na sua fala."
      : "Entendi «" + transcriptEsc + "», mas não bateu com o vocabulário do dia. Ouça o modelo (🔊) e tente repetir mais perto do texto.",
    matched,
    missed: missed.slice(0, 5),
  };
  render();
}

// Análise local (no dispositivo) de um áudio/vídeo enviado na seção
// "Gravar": decodifica o arquivo, mede duração e, por janelas de
// 100ms, a energia RMS do sinal — para distinguir fala real de
// silêncio ou ruído/música contínuos. Não faz reconhecimento de texto.
export async function analyze(file) {
  const o = document.getElementById("out");
  if (!file) return;
  o.textContent = "Analisando…";
  try {
    const ac = new (window.AudioContext || window.webkitAudioContext)();
    const b = await ac.decodeAudioData(await file.arrayBuffer());
    const dur = b.duration;

    if (dur < 30) {
      o.innerHTML = `<span class="text-rose-600 font-bold">Seu envio tem ${dur.toFixed(
        0
      )}s. Grave pelo menos 30 segundos falando.</span>`;
      return;
    }

    const c = b.getChannelData(0);
    const w = Math.floor(b.sampleRate * 0.1);
    const r = [];
    for (let i = 0; i + w < c.length; i += w) {
      let s = 0;
      for (let j = 0; j < w; j += 8) s += c[i + j] * c[i + j];
      r.push(Math.sqrt(s / (w / 8)));
    }

    const m = r.reduce((a, x) => a + x, 0) / r.length;
    const sd = Math.sqrt(r.reduce((a, x) => a + (x - m) ** 2, 0) / r.length);
    const act = r.filter((x) => x > 0.01).length / r.length;
    const cv = sd / (m || 1);

    if (act < 0.3) {
      o.innerHTML =
        '<span class="text-rose-600 font-bold">Quase não há voz neste arquivo. Fale mais perto do microfone e tente de novo.</span>';
      return;
    }
    if (cv < 0.45 || act > 0.97) {
      o.innerHTML =
        '<span class="text-rose-600 font-bold">Esse som parece contínuo (ruído ou música), sem pausas naturais de fala. Envie uma fala autêntica.</span>';
      return;
    }

    const ws = D[state.day].w.slice(0, 3).map((z) => z[0]).join("», «");
    xp(20);
    o.innerHTML = `<div class="text-emerald-600 font-bold">🎉 ¡Muy bien! ${dur.toFixed(
      0
    )}s de fala com ritmo natural.</div><p class="mt-2">Dicas: repita devagar «${esc(
      ws
    )}» e compare com o 🔊 da aula. Em espanhol as vogais são curtas e sempre iguais (a, e, i, o, u) e o «r» inicial vibra forte. Errar faz parte, continue falando todo dia! 💪</p>`;
  } catch (e) {
    o.innerHTML =
      '<span class="text-rose-600 font-bold">Não consegui ler esse arquivo. Tente outro formato (mp3, m4a, mp4).</span>';
  }
}
