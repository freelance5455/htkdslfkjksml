// templates.js
// Funções de template: cada uma recebe o estado atual (via imports de
// state.js) e retorna uma string HTML para a seção correspondente.
// Não têm efeito colateral — quem decide QUANDO renderizar é app.js.
// Os atributos onclick="..." continuam chamando funções globais
// (expostas em window por app.js), igual ao app original: trocar isso
// por listeners event-delegation é uma refatoração futura possível,
// mas fora do escopo desta (preservar comportamento 1:1).
//
// Layout (Opção 3 — abas horizontais, full-width): a tela de lição une
// Gramática/Vocabulário/Escrita/Escuta/Fala/Quiz numa única seção com
// sub-abas (state.pt), em vez de telas separadas "Aula Atual" e
// "Prática & Quiz".

import { D, RD } from "./data.js";
import { state, S, N, LV, dn, cnt, open, canFin, need, levelDone } from "./state.js";
import { esc, EM, BP, BS, CARD, ROW } from "./utils.js";

export function hero(sub) {
  const d = D[state.day];
  const l = LV[state.lvI];
  const dd = S.comp.includes(state.day);
  return `<div class="${CARD} mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4"><div><div class="flex flex-wrap items-center gap-2 mb-1.5"><span class="px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold bg-red-500/10 text-red-600 dark:text-red-300 border border-red-500/20">${l.c} • DIA ${state.day + 1} DE ${D.length}</span>${
    dd
      ? '<span class="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">✓ Concluído</span>'
      : ""
  }</div><h1 class="font-serif text-xl sm:text-2xl font-bold">${esc(d.t)}</h1><p class="text-xs text-[var(--text-muted)] mt-1">${
    dd ? "Você já concluiu este dia." : need()
  }</p></div><div class="flex flex-wrap gap-2 shrink-0">${sub}<button class="fin ${BP}" onclick="finish()" ${
    dd || !canFin() ? "disabled" : ""
  }>${dd ? "Dia concluído ✓" : "Concluir dia (+50 XP)"}</button></div></div>`;
}

// Painel "Gramática": explicação da regra do dia + navegação entre dias.
function grammarPanel(d) {
  return `<article class="${CARD} space-y-5"><div class="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-red-600 dark:text-red-400 font-bold mb-2"><i data-lucide="book-open" class="w-3.5 h-3.5"></i>Estrutura & Gramática</div><h2 class="font-serif text-xl font-bold mb-3">${esc(
    d.t
  )}</h2><p class="grammar">${esc(d.g)}</p>
 <div class="flex items-center justify-between gap-3 pt-2"><button ${
   state.day == 0 ? "disabled" : ""
 } onclick="selDay(${state.day - 1})" class="saas-card px-4 py-2.5 rounded-xl text-xs font-bold disabled:opacity-40">← Dia anterior</button><button ${
    state.day + 1 >= D.length ? "disabled" : ""
  } onclick="selDay(${state.day + 1})" class="saas-card px-4 py-2.5 rounded-xl text-xs font-bold disabled:opacity-40">Próximo dia →</button></div></article>`;
}

// Painel "Vocabulário": lista de palavras do dia com áudio (TTS).
function vocabPanel(d) {
  return `<div class="${CARD}"><div class="flex items-center justify-between mb-4"><div><span class="text-[11px] font-mono uppercase tracking-wider text-amber-600 dark:text-amber-400 font-bold">Pronúncia</span><h3 class="font-serif text-lg font-bold">Vocabulário & Áudio</h3></div><span class="text-xs font-mono text-[var(--text-muted)]">${cnt(
    state.day,
    "p"
  )}/${N.p}</span></div><div class="space-y-3">${d.w
    .map(
      (w, k) =>
        `<div class="${ROW} space-y-2.5"><div class="flex items-start justify-between gap-2"><div><span class="font-serif text-lg font-bold block leading-tight">${esc(
          w[0]
        )}</span><span class="text-xs text-[var(--text-muted)]">${esc(
          w[1]
        )}</span></div><div class="wv flex items-end gap-0.5"><span></span><span></span><span></span></div></div><div class="flex items-center gap-2"><button onclick="sp('w',${k},0)" class="flex-1 py-1.5 px-3 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold flex items-center justify-center gap-1.5"><i data-lucide="volume-2" class="w-3.5 h-3.5"></i>Ouvir</button><button onclick="sp('w',${k},1)" class="${BS}">Lento</button><button onclick="mark('p${k}')" class="${BS}">${
          dn(state.day)["p" + k] ? "✔" : "Pratiquei"
        }</button></div></div>`
    )
    .join("")}</div></div>`;
}

// Tela unificada da lição: sub-abas Gramática | Vocabulário | Escrita |
// Escuta | Fala | Quiz, todas full-width (sem grid de colunas).
export function lesson() {
  const d = D[state.day];
  const TABS = [
    ["g", "Gramática", "book-open"],
    ["v", "Vocabulário", "volume-2"],
    ["w", "Escrita", "pen-tool"],
    ["l", "Escuta", "headphones"],
    ["f", "Fala", "mic"],
    ["q", "Quiz", "check-circle-2"],
  ];
  const validPt = TABS.map((t) => t[0]);
  const pt = validPt.includes(state.pt) ? state.pt : "g";

  return (
    hero("") +
    `<div class="${CARD} mb-6"><div class="flex gap-2 overflow-x-auto pb-1">${TABS.map(
      ([k, t, i]) =>
        `<button onclick="setPt('${k}')" class="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold whitespace-nowrap transition ${
          pt == k ? "bg-red-600 text-white shadow-sm" : "bg-[var(--bg-subtle)] text-[var(--text-muted)]"
        }"><i data-lucide="${i}" class="w-4 h-4"></i>${t}${
          k == "q"
            ? dn(state.day).q
              ? " ✔"
              : ""
            : k == "g" || k == "v"
            ? ""
            : ` ${cnt(state.day, k)}/${N[k]}`
        }</button>`
    ).join("")}</div></div>
 <div class="space-y-4">${core(d, pt)}</div>`
  );
}

export function core(d, ptOverride) {
  const x = dn(state.day);
  const pt = ptOverride || state.pt;

  if (pt == "g") return grammarPanel(d);
  if (pt == "v") return vocabPanel(d);

  if (pt == "w")
    return d.b
      .map(
        (b, k) =>
          `<div class="${ROW} space-y-2"><p class="text-sm sm:text-base font-medium">${k + 1}. <strong>${esc(
            b[0]
          )}</strong></p><div class="flex flex-col sm:flex-row gap-2"><input id="wi${k}" type="text" ${
            x["w" + k] ? "disabled" : ""
          } value="${x["w" + k] ? esc(b[1]) : ""}" placeholder="Digite a resposta…" onkeydown="if(event.key=='Enter')chk(${k})" class="flex-1 px-3.5 py-2 rounded-xl bg-[var(--bg-card)] border border-[var(--border-crisp)] text-sm focus:outline-none focus:ring-2 focus:ring-red-500 ${
            x["w" + k] ? "border-emerald-500" : ""
          }"><button onclick="chk(${k})" class="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold">${
            x["w" + k] ? "✔" : "Verificar"
          }</button></div><div id="wf${k}" class="text-xs font-bold"></div></div>`
      )
      .join("");

  if (pt == "l")
    return d.l
      .map(
        (s, k) =>
          `<div class="${ROW} space-y-3"><div class="flex flex-wrap items-center justify-between gap-2"><span class="font-mono text-xs font-bold text-[var(--text-muted)]">FAIXA #0${
            k + 1
          }</span><div class="flex flex-wrap gap-2"><button onclick="sp('l',${k},0)" class="px-3.5 py-1.5 rounded-xl bg-red-600 text-white text-xs font-bold flex items-center gap-1.5"><i data-lucide="play" class="w-3.5 h-3.5"></i>Ouvir</button><button onclick="sp('l',${k},1)" class="${BS}">Lento</button><button onclick="$('lr${k}').classList.toggle('hidden')" class="${BS}">Transcrição</button><button onclick="mark('l${k}')" class="${BS}">${
            x["l" + k] ? "✔" : "Entendi"
          }</button></div></div><div id="lr${k}" class="hidden p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-sm"><b>${esc(
            s[0]
          )}</b><br><span class="text-[var(--text-muted)]">${esc(s[1])}</span></div></div>`
      )
      .join("");

  if (pt == "f")
    return d.f
      .map(
        (f, k) =>
          `<div class="${ROW} space-y-3"><div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3"><div><span class="text-[10px] font-mono uppercase text-[var(--text-muted)]">Frase ${
            k + 1
          }</span><p class="font-serif text-lg font-bold">${esc(
            f
          )}</p></div><div class="flex gap-2 shrink-0"><button onclick="sp('f',${k},0)" class="${BS} flex items-center gap-1.5"><i data-lucide="volume-2" class="w-4 h-4"></i>Modelo</button><button onclick="speak(${k})" class="px-4 py-2 rounded-xl ${
            state.mic == k ? "bg-rose-600 animate-pulse" : "bg-red-600 hover:bg-red-700"
          } text-white text-xs font-bold flex items-center gap-1.5"><i data-lucide="mic" class="w-4 h-4"></i>${
            state.mic == k ? "Ouvindo…" : "Falar"
          }</button><button onclick="mark('f${k}')" class="${BS}">${
            x["f" + k] ? "✔" : "Feito"
          }</button></div></div>${
            state.SR[k]
              ? `<div class="p-3 rounded-xl text-xs font-semibold ${
                  state.SR[k].ok
                    ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300"
                    : "bg-amber-500/15 text-amber-700 dark:text-amber-300"
                }">${state.SR[k].t}</div>`
              : ""
          }</div>`
      )
      .join("");

  // pt == "q": quiz diário
  if (x.q)
    return `<div class="${CARD} ok text-emerald-600 dark:text-emerald-400 font-bold">✔ Quiz aprovado! Você já pode concluir este dia quando completar o resto.</div>`;

  if (!state.Q)
    return `<div class="${CARD} space-y-3"><h2 class="font-serif text-xl font-bold">Quiz de revisão</h2><p class="text-sm text-[var(--text-muted)]">10 perguntas sobre as palavras do dia. Acerte 7 ou mais para aprovar.</p><button class="${BP}" onclick="quiz()">Começar quiz</button></div>`;

  const q = state.Q.q[state.Q.i];
  if (!q)
    return `<div class="${CARD} space-y-3"><b class="text-rose-600">${state.Q.s}/10, tente de novo!</b><br><button class="${BP}" onclick="quiz()">Refazer</button></div>`;

  return `<div class="${CARD} space-y-4"><div class="text-xs font-mono text-[var(--text-muted)]">Pergunta ${
    state.Q.i + 1
  }/10</div><p class="font-serif text-xl font-bold">O que significa «${esc(
    q.p
  )}»?</p><div class="grid grid-cols-1 sm:grid-cols-2 gap-3">${q.o
    .map(
      (o, i) =>
        `<button onclick="ans(${i})" class="p-4 rounded-2xl border-2 border-[var(--border-crisp)] bg-[var(--bg-card)] hover:border-red-500 font-bold text-sm text-left">${esc(
          o
        )}</button>`
    )
    .join("")}</div></div>`;
}

export function flashcards() {
  const deck = [];
  D.forEach((d, i) => {
    if (open(i)) d.w.forEach((w) => deck.push({ e: w[0], p: w[1], t: d.t }));
  });
  const c = deck[state.fc % deck.length];
  return `<div class="max-w-2xl mx-auto space-y-6"><div class="flex items-center justify-between"><div><span class="text-xs font-mono uppercase tracking-wider text-red-600 dark:text-red-400 font-bold">Revisão espaçada</span><h1 class="font-serif text-2xl font-bold">Flashcards 3D</h1></div><span class="font-mono text-xs text-[var(--text-muted)]">${
    (state.fc % deck.length) + 1
  } / ${deck.length}</span></div>
 <div class="p3d h-80 cursor-pointer" onclick="toggleFlip()"><div class="relative w-full h-full t3d ${
   state.flip ? "ry" : ""
 }"><div class="absolute inset-0 bfh saas-card rounded-3xl p-8 flex flex-col justify-between items-center text-center"><span class="px-3 py-1 rounded-full text-[11px] font-mono font-bold bg-red-500/10 text-red-600 dark:text-red-300">${esc(
    c.t
  )}</span><h2 class="font-serif text-4xl sm:text-5xl font-bold">${esc(
    c.e
  )}</h2><div class="flex items-center gap-3"><button onclick="event.stopPropagation();say('${c.e.replace(
    /'/g,
    "\\'"
  )}',0)" class="px-4 py-2 rounded-full bg-red-600 text-white text-xs font-bold flex items-center gap-1.5"><i data-lucide="volume-2" class="w-4 h-4"></i>Ouvir</button><span class="text-xs text-[var(--text-muted)]">Toque para virar</span></div></div>
 <div class="absolute inset-0 bfh ry rounded-3xl p-8 bg-gradient-to-br from-stone-900 to-red-950 text-white border border-red-500/30 shadow-xl flex flex-col justify-center items-center text-center"><span class="text-xs font-mono text-red-200 mb-3">SIGNIFICADO</span><h3 class="font-serif text-3xl font-bold text-amber-300">${esc(
    c.p
  )}</h3></div></div></div>
 <div class="grid grid-cols-3 gap-3">${[
   ["Difícil", "text-rose-600", 0, "Rever logo"],
   ["Bom", "text-amber-600", 5, "+5 XP"],
   ["Dominado", "text-emerald-600", 10, "+10 XP"],
 ]
   .map(
     ([n, c, p, s]) =>
       `<button onclick="adv(${p})" class="saas-card py-3.5 rounded-2xl text-center"><span class="block text-sm font-bold ${c}">${n}</span><span class="text-[11px] text-[var(--text-muted)]">${s}</span></button>`
   )
   .join("")}</div></div>`;
}

export function exCard(l) {
  const ok = levelDone(l);
  const b = (S.exam || {})[l.c];
  return `<div class="${CARD} flex flex-col sm:flex-row sm:items-center justify-between gap-4"><div><h3 class="font-serif text-lg font-bold">🏁 Quiz final do nível ${
    l.c
  }</h3><p class="text-sm text-[var(--text-muted)]">20 perguntas sorteadas de todo o nível (10 de vocabulário e 10 de lacunas). Aprovação com 14 acertos.${
    b != null ? " Melhor nota: " + b + "/20." : ""
  }</p></div><button class="${BP}" onclick="startExam()" ${ok ? "" : "disabled"}>${
    ok ? "Iniciar quiz" : "🔒 Conclua o nível"
  }</button></div>`;
}

// Aba "Trilha & Dias": lista os módulos CEFR (A1-C2) e a grade de dias do
// nível ativo. É aqui que ficam os detalhes de progresso que antes viviam
// na sidebar (resumo compacto agora está só no header).
export function roadmap() {
  const l = LV[state.lvI];
  return `<div class="space-y-6"><div class="flex flex-wrap items-center justify-between gap-3"><div><span class="text-xs font-mono uppercase tracking-wider text-red-600 dark:text-red-400 font-bold">Currículo estruturado</span><h1 class="font-serif text-2xl font-bold">Trilha ${
    l.c
  } · ${l.n}</h1></div><div class="flex gap-2 flex-wrap">${LV.map(
    (x, i) =>
      `<button onclick="selLevel(${i})" class="px-3.5 py-2 rounded-xl text-xs font-bold border ${
        i == state.lvI ? "bg-red-600 text-white border-red-600" : "saas-card"
      }">${EM[x.c]} ${x.c}</button>`
  ).join("")}</div></div>
 <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">${D.slice(l.a, l.b + 1)
   .map((d, j) => {
     const i = l.a + j;
     const dd = S.comp.includes(i);
     const op = open(i);
     const n = cnt(i, "p") + cnt(i, "w") + cnt(i, "l") + cnt(i, "f") + (dn(i).q ? 1 : 0);
     return `<button onclick="selDay(${i})" class="saas-card text-left p-5 rounded-2xl flex flex-col justify-between gap-4 hover:border-red-500/50 ${
       op ? "" : "lk"
     } ${i == state.day ? "ring-2 ring-red-500" : ""}"><div><div class="flex items-center justify-between mb-2"><span class="font-mono text-xs font-bold px-2.5 py-0.5 rounded-md bg-[var(--bg-subtle)]">DIA ${
       i + 1
     }</span>${
       dd
         ? '<span class="text-xs font-bold text-emerald-600">✓ Concluído</span>'
         : op
         ? '<span class="text-xs text-amber-600 font-semibold">Em andamento</span>'
         : '<span class="text-xs text-[var(--text-muted)]">🔒 Bloqueado</span>'
     }</div><h3 class="font-bold text-base">${esc(
       d.t
     )}</h3></div><div class="flex justify-between text-xs text-[var(--text-muted)] pt-3 border-t border-[var(--border-crisp)]"><span>${n}/35 atividades · ${Math.floor(
       (S.secs[i] || 0) / 60
     )} min</span><span class="font-bold text-red-600 dark:text-red-400">${
       op ? "Estudar →" : ""
     }</span></div></button>`;
   })
   .join("")}</div>${exCard(l)}</div>`;
}

export function exam() {
  if (!state.X) return roadmap();
  const t = state.X.q.length;

  if (state.X.i < t) {
    const q = state.X.q[state.X.i];
    return `<div class="max-w-2xl mx-auto ${CARD} space-y-4"><div class="flex justify-between text-xs font-mono text-[var(--text-muted)]"><span>QUIZ FINAL ${
      state.X.lv
    }</span><span>${state.X.i + 1}/${t}</span></div><div class="w-full h-1.5 rounded-full bg-black/10 dark:bg-white/10"><div class="h-full bg-red-600 rounded-full" style="width:${
      (state.X.i / t) * 100
    }%"></div></div><p class="font-serif text-xl font-bold">${esc(
      q.t
    )}</p><div class="grid grid-cols-1 sm:grid-cols-2 gap-3">${q.o
      .map(
        (o, i) =>
          `<button onclick="exAns(${i})" class="p-4 rounded-2xl border-2 border-[var(--border-crisp)] bg-[var(--bg-card)] hover:border-red-500 font-bold text-sm text-left">${esc(
            o
          )}</button>`
      )
      .join("")}</div></div>`;
  }

  const ok = state.X.s >= 14;
  return `<div class="max-w-2xl mx-auto ${CARD} text-center space-y-4"><div class="text-5xl">${
    ok ? "🏆" : "📚"
  }</div><h2 class="font-serif text-2xl font-bold">${state.X.s}/${t} acertos</h2><p class="text-sm text-[var(--text-muted)]">${
    ok
      ? "Aprovado! Você domina o nível " + state.X.lv + "."
      : "Faltaram " + (14 - state.X.s) + " acertos para a aprovação (14). Revise os dias e tente de novo."
  }</p><div class="flex justify-center gap-3"><button class="${BP}" onclick="startExam()">Refazer</button><button class="${BS}" onclick="setSec('roadmap')">Voltar à trilha</button></div></div>`;
}

export function rec() {
  const rr = state.recResult;
  return `<div class="max-w-2xl mx-auto space-y-4">
 <div class="${CARD} space-y-3">
  <span class="text-xs font-mono uppercase tracking-wider text-red-600 dark:text-red-400 font-bold">Fala livre</span>
  <h1 class="font-serif text-2xl font-bold">Grave sua fala</h1>
  <p class="text-sm text-[var(--text-muted)]">Toque em Gravar, fale em espanhol as palavras ou frases do seu dia atual, e toque em Parar. O que você disser é comparado com o vocabulário e as frases do dia para indicar o que foi reconhecido.</p>
  <div class="flex flex-wrap items-center gap-3">
   <button onclick="${state.recording ? "stopRec()" : "startRec()"}" class="${
    state.recording ? "bg-rose-600 animate-pulse" : "bg-red-600 hover:bg-red-700"
  } text-white text-sm font-bold px-5 py-2.5 rounded-xl flex items-center gap-2"><i data-lucide="${
    state.recording ? "square" : "mic"
  }" class="w-4 h-4"></i>${state.recording ? "Parar" : "Gravar"}</button>
   ${
     state.recording
       ? `<span class="text-xs text-[var(--text-muted)]">Ouvindo… diga as palavras do dia em voz alta.</span>`
       : ""
   }
  </div>
  ${
    rr
      ? `<div class="p-3 rounded-xl text-sm font-semibold ${
          rr.ok
            ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300"
            : "bg-amber-500/15 text-amber-700 dark:text-amber-300"
        }">${rr.summary}${
          rr.matched.length
            ? `<div class="mt-2 text-xs font-normal">✔ Reconhecidas: ${rr.matched.map((m) => esc(m)).join(", ")}</div>`
            : ""
        }${
          rr.missed.length
            ? `<div class="mt-1 text-xs font-normal">○ Não reconhecidas (tente de novo): ${rr.missed
                .map((m) => esc(m))
                .join(", ")}</div>`
            : ""
        }</div>`
      : ""
  }
  ${state.recBlobUrl ? `<audio controls src="${state.recBlobUrl}" class="w-full"></audio>` : ""}
 </div>
 <div class="${CARD} space-y-3">
  <span class="text-xs font-mono uppercase tracking-wider text-amber-600 dark:text-amber-400 font-bold">Ou envie um arquivo</span>
  <p class="text-sm text-[var(--text-muted)]">Prefere enviar um áudio ou vídeo já gravado? Envie com pelo menos <b>30 segundos</b> de fala real. Silêncio, ruído branco ou música não são aceitos.</p>
  <input type="file" id="rf" accept="audio/*,video/*" onchange="analyze(this.files[0])" class="text-sm max-w-full">
  <div id="out" class="text-sm"></div>
 </div>
 <div class="${CARD} text-xs text-[var(--text-muted)]">A gravação pelo microfone usa reconhecimento de fala do navegador (pode variar de precisão) para comparar com o vocabulário do dia. O envio de arquivo usa uma análise acústica local (duração, silêncio, ritmo) e não reconhece palavras.</div>
</div>`;
}

// Aba NOVA "Leitura": textos de compreensão de leitura por nível CEFR
// (RD[state.lvI]), cada um com perguntas de múltipla escolha. Conteúdo
// NOVO, escrito em espanhol (não existia no app original) — adicionado
// espelhando a aba "Leitura" criada na portagem do EnglishPath.
// Independente dos "dias": pertence ao nível inteiro, por isso usa
// state.lvI (não state.day).
export function reading() {
  const l = LV[state.lvI];
  const texts = RD[state.lvI] || [];
  if (!texts.length)
    return `<div class="${CARD}">Ningún texto de lectura disponible para este nivel.</div>`;
  const ti = Math.min(state.rdI, texts.length - 1);
  const txt = texts[ti];
  const prefix = state.lvI + ":" + ti + ":";

  return `<div class="space-y-6"><div class="flex flex-wrap items-center justify-between gap-3"><div><span class="text-xs font-mono uppercase tracking-wider text-red-600 dark:text-red-400 font-bold">Comprensión de lectura</span><h1 class="font-serif text-2xl font-bold">Lectura · ${
    l.c
  }</h1></div><div class="flex gap-2 flex-wrap">${texts
    .map(
      (tx, i) =>
        `<button onclick="selReading(${i})" class="px-3.5 py-2 rounded-xl text-xs font-bold border ${
          i == ti ? "bg-red-600 text-white border-red-600" : "saas-card"
        }">${esc(tx.t)}</button>`
    )
    .join("")}</div></div>
 <article class="${CARD} space-y-3"><h2 class="font-serif text-xl font-bold">${esc(
    txt.t
  )}</h2><p class="leading-relaxed">${esc(txt.x)}</p><button onclick='say(${JSON.stringify(txt.x)},0)' class="${BS} flex items-center gap-1.5 w-max"><i data-lucide="volume-2" class="w-4 h-4"></i>Escuchar el texto</button></article>
 <div class="space-y-3">${txt.q
   .map((q, qi) => {
     const [question, opts, correct] = q;
     const key = prefix + qi;
     const sel = state.RD && state.RD[key];
     const done = S.rd && S.rd[key];
     return `<div class="${CARD} space-y-3"><p class="font-serif text-lg font-bold">${qi + 1}. ${esc(
       question
     )}</p><div class="grid grid-cols-1 sm:grid-cols-2 gap-3">${opts
       .map((o, oi) => {
         let cls = "border-2 border-[var(--border-crisp)] bg-[var(--bg-card)] hover:border-red-500";
         if (sel != null) {
           if (oi == correct) cls = "border-2 border-emerald-500 bg-emerald-500/10";
           else if (oi == sel) cls = "border-2 border-rose-500 bg-rose-500/10";
           else cls = "border-2 border-[var(--border-crisp)] bg-[var(--bg-card)] opacity-60";
         }
         return `<button onclick="answerReading('${key}',${oi},${correct})" class="p-3 rounded-xl ${cls} font-semibold text-sm text-left">${esc(
           o
         )}</button>`;
       })
       .join("")}</div>${
       done ? '<div class="text-xs font-bold text-emerald-600">✔ Respondida correctamente (+5 XP)</div>' : ""
     }</div>`;
   })
   .join("")}</div></div>`;
}

export function profile() {
  const t = Object.values(S.secs).reduce((a, b) => a + b, 0);
  return `<div class="max-w-3xl mx-auto space-y-6"><div class="${CARD} text-center space-y-4">${
    S.av
      ? `<img src="${S.av}" alt="Avatar" class="w-24 h-24 rounded-full object-cover mx-auto shadow-lg">`
      : '<div class="w-24 h-24 rounded-full bg-gradient-to-tr from-red-600 to-amber-400 text-white font-bold text-3xl flex items-center justify-center mx-auto shadow-lg">' +
        esc((S.name || "ES")[0].toUpperCase()) +
        "</div>"
  }<div><label class="${BS} inline-block cursor-pointer">Inserir ou trocar foto<input type="file" accept="image/*" class="hidden" onchange="setAv(this.files[0])"></label></div>
 <div class="flex flex-wrap justify-center gap-2"><input id="nm" type="text" value="${esc(
   S.name
 )}" placeholder="Seu nome" class="px-3.5 py-2 rounded-xl bg-[var(--bg-subtle)] border border-[var(--border-crisp)] text-sm"><button class="${BP}" onclick="S.name=$('nm').value.trim();save();toast('Nome salvo');render()">Salvar</button></div>
 <p class="text-sm text-[var(--text-muted)]">Nível ativo: <strong>${LV[state.lvI].c} (${
    LV[state.lvI].n
  })</strong></p><p class="text-xs text-[var(--text-muted)]">Quizzes finais: ${
    Object.entries(S.exam || {})
      .map(([k, v]) => k + " " + v + "/20")
      .join(" · ") || "nenhum ainda"
  }</p>
 <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">${[
   [S.xp, "XP total", "text-red-600"],
   [S.streak + "d", "Ofensiva", "text-amber-600"],
   [S.comp.length + "/" + D.length, "Dias concluídos", "text-emerald-600"],
   [Math.floor(t / 60) + " min", "Tempo total", "text-sky-600"],
 ]
   .map(
     ([v, n, c]) =>
       `<div class="${ROW}"><span class="block font-mono text-xl font-bold ${c}">${v}</span><span class="text-xs text-[var(--text-muted)]">${n}</span></div>`
   )
   .join("")}</div>
 <button class="${BS}" onclick="if(confirm('Apagar todo o progresso?'))resetProgress()">Zerar progresso</button></div></div>`;
}
