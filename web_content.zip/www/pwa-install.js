/* Official app installer: APK download + browser-supported PWA install.
   Upload your signed APK to downloads/dhonnobad-foundation.apk. */
(() => {
  let deferredPrompt = null;
  const installButton = document.getElementById('installAppBtn');
  const modal = document.getElementById('dfInstallerModal');
  const closeButton = document.getElementById('dfInstallerClose');
  const pwaButton = document.getElementById('dfPwaInstall');
  const apkLink = document.getElementById('dfApkDownload');
  const status = document.getElementById('dfInstallerStatus');
  const isStandalone = () => window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
  const openModal = () => {
    if (!modal) return;
    modal.hidden = false;
    modal.setAttribute('aria-hidden', 'false');
    document.body.classList.add('df-installer-open');
    closeButton?.focus();
  };
  const closeModal = () => {
    if (!modal) return;
    modal.hidden = true;
    modal.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('df-installer-open');
    installButton?.focus();
  };
  installButton?.addEventListener('click', openModal);
  closeButton?.addEventListener('click', closeModal);
  modal?.addEventListener('click', e => { if (e.target === modal) closeModal(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && modal && !modal.hidden) closeModal(); });

  window.addEventListener('beforeinstallprompt', event => {
    event.preventDefault();
    deferredPrompt = event;
    if (pwaButton) pwaButton.hidden = false;
  });
  pwaButton?.addEventListener('click', async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const choice = await deferredPrompt.userChoice.catch(() => null);
      status.textContent = choice?.outcome === 'accepted'
        ? 'ওয়েব অ্যাপ ইনস্টল করার অনুরোধ গ্রহণ করা হয়েছে।'
        : 'ইনস্টল করা হয়নি। চাইলে APK ডাউনলোড অপশন ব্যবহার করতে পারেন।';
      deferredPrompt = null;
    } else {
      status.textContent = 'Chrome-এ মেনু (⋮) খুলে “Install app” বা “Add to Home screen” নির্বাচন করুন। এই সুবিধা ব্রাউজারভেদে আলাদা হতে পারে।';
    }
  });
  window.addEventListener('appinstalled', () => {
    if (status) status.textContent = 'ওয়েব অ্যাপ সফলভাবে ইনস্টল হয়েছে।';
    deferredPrompt = null;
  });
  // Never block the real download link based on a HEAD pre-check.
  // Some shared hosts/CDNs do not answer HEAD requests consistently even when GET works.
  // Keep the APK link usable and let the browser perform the actual same-origin download.
  apkLink?.addEventListener('click', () => {
    if (status) status.textContent = 'APK ডাউনলোড শুরু হওয়ার কথা। শুরু না হলে হোস্টিংয়ে downloads/dhonnobad-foundation.apk ফাইলটি আছে কি না যাচাই করুন।';
  });
  if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) {
    window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch(error => console.warn('Service worker registration failed:', error)));
  }
})();
