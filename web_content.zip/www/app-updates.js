(function () {
  'use strict';
  const cfg = window.DF_APP_UPDATE_CONFIG || { currentVersion: '1.3.0', manifestUrl: '' };
  const STORAGE_KEY = 'df_app_update_last_manifest_v1';
  const $ = (id) => document.getElementById(id);

  function versionParts(value) {
    return String(value || '0').replace(/^v/i, '').split(/[.+-]/).slice(0, 3).map(n => parseInt(n, 10) || 0);
  }
  function compareVersions(a, b) {
    const av = versionParts(a), bv = versionParts(b);
    for (let i = 0; i < 3; i++) { if (av[i] > bv[i]) return 1; if (av[i] < bv[i]) return -1; }
    return 0;
  }
  function getCachedManifest() {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null'); } catch (_) { return null; }
  }
  function saveManifest(data) {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); } catch (_) {}
  }
  function formatDate(value) {
    if (!value) return 'তারিখ উল্লেখ করা হয়নি';
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return String(value);
    return new Intl.DateTimeFormat('bn-BD', { day: 'numeric', month: 'long', year: 'numeric' }).format(d);
  }
  function safeText(value) { return String(value == null ? '' : value); }
  function safeDownloadUrl(value) {
    try { const u = new URL(String(value || ''), window.location.href); return u.protocol === 'https:' ? u.href : ''; } catch (_) { return ''; }
  }
  function isPublished(data) { return !!(data && data.published === true && data.version && data.apkUrl); }
  function isNewer(data) { return isPublished(data) && compareVersions(data.version, cfg.currentVersion) > 0; }

  function renderStatus(manifest, offline) {
    const status = $('update-status');
    const content = $('update-content');
    if (!status || !content) return;
    if (isNewer(manifest)) {
      status.className = 'update-status has-update';
      status.innerHTML = '<span class="status-dot"></span> নতুন আপডেট পাওয়া গেছে';
      const mandatory = manifest.mandatory === true;
      content.innerHTML = `
        <article class="update-release-card">
          <div class="release-top"><span class="release-icon">🚀</span><span class="release-badge ${mandatory ? 'required' : ''}">${mandatory ? 'বাধ্যতামূলক আপডেট' : 'নতুন সংস্করণ'}</span></div>
          <p class="release-kicker">DHANYABAD FOUNDATION APP</p>
          <h2>Version ${safeText(manifest.version)}</h2>
          <p class="release-date">প্রকাশের তারিখ: ${safeText(formatDate(manifest.releaseDate || manifest.publishedAt))}</p>
          <div class="release-notes">${safeText(manifest.notes || 'এই সংস্করণে উন্নতি ও সংশোধন আনা হয়েছে।').split(/\n+/).map(line => line.trim()).filter(Boolean).map(line => `<p>• ${line.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')}</p>`).join('')}</div>
          ${manifest.fileSize ? `<p class="release-size">ফাইলের আকার: ${safeText(manifest.fileSize)}</p>` : ''}
          <a class="update-primary" href="${safeDownloadUrl(manifest.apkUrl).replace(/&/g, '&amp;').replace(/"/g, '&quot;')}" target="_blank" rel="noopener">⬇ APK ডাউনলোড করুন</a>
          ${mandatory ? '<p class="mandatory-note">অ্যাডমিন এই আপডেটটি বাধ্যতামূলক করেছেন। নতুন সংস্করণ ইনস্টল না করা পর্যন্ত এই নোটিশ আবার দেখানো হবে।</p>' : '<p class="optional-note">আপডেটটি ঐচ্ছিক। চাইলে পরে ইনস্টল করতে পারবেন।</p>'}
        </article>`;
    } else {
      status.className = 'update-status';
      status.innerHTML = '<span class="status-dot"></span> বর্তমানে কোনো নতুন আপডেট নেই';
      content.innerHTML = `<article class="no-update-card"><div class="no-update-icon">✓</div><h2>আপনি আপ-টু-ডেট!</h2><p>বর্তমানে কোনো নতুন আপডেট নেই।</p><div class="version-chip">আপনার অ্যাপের ভার্সন <strong>${safeText(cfg.currentVersion)}</strong></div>${offline ? '<small>সর্বশেষ আপডেটের তথ্য দেখাতে ইন্টারনেট সংযোগ প্রয়োজন হতে পারে।</small>' : '<small>নতুন আপডেট প্রকাশিত হলে এখানে দেখা যাবে।</small>'}<button type="button" class="update-secondary" id="check-updates-again">↻ আবার পরীক্ষা করুন</button></article>`;
      const again = $('check-updates-again');
      if (again) again.addEventListener('click', () => checkUpdates(true));
    }
  }

  async function fetchManifest() {
    if (!cfg.manifestUrl) return null;
    const separator = cfg.manifestUrl.includes('?') ? '&' : '?';
    const response = await fetch(cfg.manifestUrl + separator + '_=' + Date.now(), { cache: 'no-store', headers: { 'Accept': 'application/json' } });
    if (!response.ok) throw new Error('Update service unavailable');
    return response.json();
  }

  async function checkUpdates(force) {
    const status = $('update-status');
    if (status && force) { status.className = 'update-status checking'; status.textContent = 'আপডেট পরীক্ষা করা হচ্ছে…'; }
    let manifest = null, offline = false;
    try {
      manifest = await fetchManifest();
      if (manifest) saveManifest(manifest);
      else manifest = getCachedManifest();
    } catch (_) {
      offline = true;
      manifest = getCachedManifest();
    }
    renderStatus(manifest, offline || !navigator.onLine);
    return manifest;
  }

  function showMandatoryOverlay(manifest) {
    if (!isNewer(manifest) || manifest.mandatory !== true) return;
    if (document.getElementById('mandatory-update-overlay')) return;
    const overlay = document.createElement('div');
    overlay.id = 'mandatory-update-overlay';
    overlay.className = 'mandatory-update-overlay';
    overlay.innerHTML = `<div class="mandatory-update-dialog" role="dialog" aria-modal="true" aria-labelledby="mandatory-update-title"><div class="mandatory-symbol">⬆</div><p class="release-kicker">DHANYABAD FOUNDATION</p><h2 id="mandatory-update-title">অ্যাপ আপডেট করা প্রয়োজন</h2><p>নতুন ভার্সন <strong>${safeText(manifest.version)}</strong> অ্যাডমিন বাধ্যতামূলক করেছেন। অ্যাপ ব্যবহার চালিয়ে যেতে নতুন APK ডাউনলোড করে ইনস্টল করুন।</p><a class="update-primary" href="${safeDownloadUrl(manifest.apkUrl).replace(/&/g, '&amp;').replace(/"/g, '&quot;')}" target="_blank" rel="noopener">⬇ আপডেট ডাউনলোড করুন</a><small>ডাউনলোডের পর Android-এর নির্দেশনা অনুসরণ করে ইনস্টল নিশ্চিত করুন।</small></div>`;
    document.body.appendChild(overlay);
  }

  async function checkOnLaunch() {
    if (!cfg.checkOnLaunch || !cfg.manifestUrl) return;
    const last = Number(localStorage.getItem('df_app_update_checked_at') || 0);
    const interval = (Number(cfg.checkIntervalHours) || 6) * 60 * 60 * 1000;
    if (Date.now() - last < interval && !navigator.onLine) return;
    try {
      const manifest = await fetchManifest();
      if (manifest) {
        saveManifest(manifest);
        localStorage.setItem('df_app_update_checked_at', String(Date.now()));
        showMandatoryOverlay(manifest);
      }
    } catch (_) { /* Don't interrupt app use when the update service is unreachable. */ }
  }

  document.addEventListener('DOMContentLoaded', function () {
    if ($('update-status')) checkUpdates(false);
    checkOnLaunch();
  });
  window.DFAppUpdates = { checkUpdates, compareVersions, showMandatoryOverlay };
})();
