"use strict";
const $ = s => document.querySelector(s);
const CK = "da_cfg", LK = "da_log", QK = "da_pq";
const STX = { off: "معطّلة", idle: "جاهزة", sus: "اشتباه", alarm: "إنذار", err: "خطأ" };
const TY = { flame: "لهب", smoke: "دخان" };
const RW = 640, RH = 360;
const esc = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const rnd = n => { const a = new Uint8Array(n); crypto.getRandomValues(a); return [...a].map(b => (b % 36).toString(36)).join(""); };
const ls = (k, d) => { try { const v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } };
const lsSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} };

/* ---------- الإعدادات المحفوظة ---------- */
const cfg = Object.assign({ server: "https://ntfy.sh", topic: "", confirm: 4, siren: true, hour: -1, lastRep: "", cams: [] }, ls(CK, {}));
const defCam = i => ({ name: "كاميرا " + (i + 1), src: i === 5 ? "device" : "off", facing: "environment", deviceId: "", url: "", sens: 3, flame: true, smoke: true, masks: [] });
for (let i = 0; i < 6; i++) cfg.cams[i] = Object.assign(defCam(i), cfg.cams[i] || {});
cfg.cams[5].src = "device";   // الكاميرا السادسة مخصصة لكاميرا الجوال دائماً
if (!cfg.topic) cfg.topic = "da-" + rnd(20);
const save = () => lsSet(CK, cfg);
save();

/* ---------- الحالة أثناء التشغيل ---------- */
const rt = cfg.cams.map(c => {
  const raw = document.createElement("canvas"); raw.width = RW; raw.height = RH;
  return { raw, rx: raw.getContext("2d", { willReadFrequently: true }), st: DET.newState(), acc: { flame: 0, smoke: 0 },
    state: c.src === "off" ? "off" : "idle", v: null, stream: null, bmp: null, err: "", mask: DET.buildMask(c.masks),
    test: null, cool: 0, sus: 0, live: false, polling: false };
});
const small = document.createElement("canvas"); small.width = DET.W; small.height = DET.H;
const sx = small.getContext("2d", { willReadFrequently: true });
let running = false, wl = null, ac, osc, sT, vT, tt, k = 0;
let fsI = -1, maskMode = false, maskDraft = null, editI = 0, pushOk = null;
let logs = ls(LK, []), pq = ls(QK, []);
const alarms = new Set();

function toast(m) { const t = $("#toast"); t.textContent = m; t.classList.remove("hide"); clearTimeout(tt); tt = setTimeout(() => t.classList.add("hide"), 4500); }

/* ---------- السجل والملخص ---------- */
function addLog(kind, text) { logs.unshift({ t: Date.now(), k: kind, text }); logs = logs.slice(0, 200); lsSet(LK, logs); renderLog(); }
function daySummary() {
  const d0 = new Date(); d0.setHours(0, 0, 0, 0);
  const td = logs.filter(l => l.t >= d0.getTime()), c = x => td.filter(l => l.k === x).length;
  return "ملخص اليوم: " + c("flame") + " حوادث لهب، " + c("smoke") + " حوادث دخان، " + c("transient") + " أحداث عابرة، " + c("test") + " أحداث اختبار.";
}
function renderLog() {
  $("#sum").textContent = daySummary();
  $("#log").innerHTML = logs.slice(0, 30).map(l => `<li class="${esc(l.k)}">${new Date(l.t).toLocaleTimeString("ar", { hour: "2-digit", minute: "2-digit" })} · ${esc(l.text)}</li>`).join("") || '<li>لا توجد أحداث بعد</li>';
}

/* ---------- الصافرة والاهتزاز ---------- */
function siren(on) {
  clearInterval(sT); clearInterval(vT); try { osc && osc.stop(); } catch (e) {} osc = null;
  if (!on) return;
  if (navigator.vibrate) { const v = () => navigator.vibrate([500, 200, 500]); v(); vT = setInterval(v, 2500); }
  if (!cfg.siren) return;
  try {
    ac = ac || new (window.AudioContext || window.webkitAudioContext)(); ac.resume();
    osc = ac.createOscillator(); const g = ac.createGain(); g.gain.value = .25; osc.type = "square"; osc.connect(g); g.connect(ac.destination); osc.start();
    let h = 0; sT = setInterval(() => { osc && (osc.frequency.value = h++ % 2 ? 720 : 1040); }, 380);
  } catch (e) {}
}

/* ---------- الإشعارات الحقيقية عبر ntfy (مع قائمة انتظار عند انقطاع الإنترنت) ---------- */
async function send(m) {
  const r = await fetch(cfg.server.replace(/\/$/, ""), { method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ topic: cfg.topic, title: m.title, message: m.message, priority: m.priority, tags: m.tags }) });
  if (!r.ok) throw new Error("HTTP " + r.status);
}
async function push(title, message, priority, tags, blob) {
  const m = { title, message, priority, tags };
  try {
    await send(m); pushOk = true;
    if (blob) fetch(cfg.server.replace(/\/$/, "") + "/" + cfg.topic, { method: "PUT", headers: { Filename: "snapshot.jpg" }, body: blob }).catch(() => {});
    renderChips(); return true;
  } catch (e) {
    pq.push(m); if (pq.length > 20) pq.shift(); lsSet(QK, pq); pushOk = false; renderChips(); return false;
  }
}
async function flush() {
  const q = pq; pq = [];
  for (const m of q) { try { await send(m); } catch (e) { pq.push(m); } }
  lsSet(QK, pq); pushOk = pq.length ? false : true; renderChips();
}
window.addEventListener("online", () => { renderChips(); flush(); });
window.addEventListener("offline", renderChips);
setInterval(() => { if (pq.length && navigator.onLine) flush(); }, 30000);
function renderChips() {
  $("#cNet").textContent = navigator.onLine ? "متصل بالإنترنت" : "بلا إنترنت: الإنذار المحلي يعمل";
  $("#cNet").className = "chip" + (navigator.onLine ? "" : " bad");
  $("#cPush").textContent = pq.length ? "إشعارات بانتظار الإرسال: " + pq.length : pushOk === false ? "فشل إرسال الإشعارات" : pushOk ? "الإشعارات تعمل" : "الإشعارات: لم تُختبر بعد";
  $("#cPush").className = "chip" + (pq.length || pushOk === false ? " bad" : "");
  $("#cRun").textContent = running ? "المراقبة تعمل" : "المراقبة متوقفة";
}

/* ---------- مصادر الصورة ---------- */
const camErr = e => {
  const n = e && e.name;
  if (n === "NoMediaDevices") return "هذا المتصفح أو الإطار لا يتيح الوصول للكاميرا. افتح التطبيق في نافذة مستقلة أو ثبّت ملف APK";
  if (n === "NotAllowedError" || n === "SecurityError") return "الكاميرا غير مسموحة: اسمح بالإذن من إعدادات المتصفح أو التطبيق";
  if (n === "NotFoundError" || n === "OverconstrainedError") return "لا توجد كاميرا بهذه المواصفات";
  if (n === "NotReadableError") return "الكاميرا مستخدمة من تطبيق آخر";
  return "تعذر فتح الكاميرا (" + (n || "خطأ") + ")";
};
function closeSource(i) {
  const r = rt[i]; r.polling = false;
  if (r.stream) { r.stream.getTracks().forEach(t => t.stop()); r.stream = null; }
  if (r.v) { r.v.remove(); r.v = null; }
  r.bmp = null;
}
async function openSource(i) {
  const c = cfg.cams[i], r = rt[i];
  closeSource(i); r.err = ""; r.state = c.src === "off" ? "off" : "idle";
  r.st = DET.newState(); r.acc = { flame: 0, smoke: 0 }; r.sus = 0;
  if (c.src === "device") {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) throw { name: "NoMediaDevices" };
      const vc = c.deviceId ? { deviceId: { exact: c.deviceId } } : { facingMode: { ideal: c.facing } };
      r.stream = await navigator.mediaDevices.getUserMedia({ video: vc, audio: false });
      const v = document.createElement("video"); v.muted = true; v.setAttribute("playsinline", "");
      v.style.cssText = "position:fixed;width:2px;height:2px;opacity:0;pointer-events:none";
      document.body.append(v); v.srcObject = r.stream; await v.play(); r.v = v;
    } catch (e) { closeSource(i); r.err = camErr(e); r.state = "err"; }
  } else if (c.src === "ip" && c.url) pollIp(i);
}
async function pollIp(i) {
  const r = rt[i]; if (r.polling) return; r.polling = true;
  while (r.polling && cfg.cams[i].src === "ip") {
    try {
      const u = cfg.cams[i].url, res = await fetch(u + (u.includes("?") ? "&" : "?") + "_=" + Date.now(), { cache: "no-store" });
      if (!res.ok) throw 0;
      r.bmp = await createImageBitmap(await res.blob()); r.err = ""; if (r.state === "err") r.state = "idle";
    } catch (e) { r.bmp = null; r.err = "تعذر جلب الصورة من الرابط. في المتصفح قد يمنعه CORS، والتطبيق المثبّت يتجاوز ذلك"; r.state = "err"; }
    await new Promise(s => setTimeout(s, 1000));
  }
}
function cover(x, s, sw, sh) { const f = Math.max(RW / sw, RH / sh); x.drawImage(s, (RW - sw * f) / 2, (RH - sh * f) / 2, sw * f, sh * f); }
function gen(x, t, kind) {            // فيديو اختبار: لهب أو دخان مرسوم يمرّ بمحرك الكشف الحقيقي
  x.save(); x.scale(2, 2);
  const g = x.createLinearGradient(0, 0, 0, 180); g.addColorStop(0, "#141a1f"); g.addColorStop(1, "#0b0f12"); x.fillStyle = g; x.fillRect(0, 0, 320, 180);
  x.fillStyle = "#1b242b"; x.fillRect(30, 100, 60, 60); x.fillRect(220, 90, 70, 70);
  if (t >= 2) {
    const e = t - 2;
    if (kind === "flame") for (let n = 0; n < 7; n++) { x.fillStyle = `rgb(255,${130 + Math.random() * 60 | 0},20)`; x.beginPath(); x.arc(160 + Math.random() * 10 - 5, 150 - n * 9, Math.max(3, 10 + Math.random() * 10 - n * .8), 0, 7); x.fill(); }
    else for (let n = 0; n < 8; n++) { x.fillStyle = "rgba(170,170,170,.75)"; x.beginPath(); x.arc(150 + Math.sin(e + n) * 8 + n * 4, 150 - Math.min(90, e * 8) - n * 6, Math.min(60, 8 + e * 5 + n * 3), 0, 7); x.fill(); }
  }
  x.restore();
}
function capture(i) {
  const r = rt[i], c = cfg.cams[i], x = r.rx;
  if (r.test) { gen(x, (Date.now() - r.test.t0) / 1000, r.test.kind); return true; }
  if (c.src === "device" && r.v && r.v.readyState >= 2 && r.v.videoWidth) { cover(x, r.v, r.v.videoWidth, r.v.videoHeight); return true; }
  if (c.src === "ip" && r.bmp) { cover(x, r.bmp, r.bmp.width, r.bmp.height); return true; }
  x.fillStyle = "#0b0f12"; x.fillRect(0, 0, RW, RH); return false;
}

/* ---------- الكشف والتأكيد والإنذار ---------- */
function step(i, type, hit, dt, res) {
  const r = rt[i]; if (r.state === "alarm" || Date.now() < r.cool) return;
  const a = r.acc; a[type] = hit ? a[type] + dt : Math.max(0, a[type] - dt * .5);
  const m = Math.max(a.flame, a.smoke);
  if (a[type] >= cfg.confirm) raise(i, type, res);
  else if (m > .5) { r.state = "sus"; r.sus = Math.max(r.sus, m); }
  else if (r.state === "sus") { r.state = "idle"; if (r.sus >= 1.5) addLog("transient", "حدث عابر: اشتباه " + TY[type] + " في " + cfg.cams[i].name + " ولم يستمر"); r.sus = 0; }
}
function snap(i) {
  return new Promise(res => {
    const t = document.createElement("canvas"); t.width = RW; t.height = RH; const x = t.getContext("2d");
    x.drawImage(rt[i].raw, 0, 0); x.fillStyle = "#000";
    cfg.cams[i].masks.forEach(m => x.fillRect(m.x * RW, m.y * RH, m.w * RW, m.h * RH));   // المناطق المحجوبة لا تخرج في اللقطة
    t.toBlob(b => res(b), "image/jpeg", .75);
  });
}
async function raise(i, type, res) {
  const r = rt[i], c = cfg.cams[i], test = !!r.test, pre = test ? "[اختبار] " : "";
  r.state = "alarm"; alarms.add(i); r.acc = { flame: 0, smoke: 0 };
  const sc = Math.min(99, Math.round(60 + (type === "flame" ? res.flameRatio * 2000 : res.smokeRatio * 400)));
  const txt = pre + TY[type] + " في " + c.name + " (قوة المؤشر " + sc + "%)";
  addLog(test ? "test" : type, txt);
  $("#alTxt").textContent = txt; $("#alarm").classList.remove("hide");
  siren(true);
  push(pre + "إنذار " + TY[type], txt, test ? 3 : 5, test ? ["test_tube"] : ["fire", "rotating_light"], await snap(i));
}
function stopAlarm(quiet) {
  alarms.forEach(i => { const r = rt[i]; r.state = cfg.cams[i].src === "off" && !r.test ? "off" : "idle"; r.cool = Date.now() + 30000; r.acc = { flame: 0, smoke: 0 }; r.sus = 0; });
  const had = alarms.size; alarms.clear(); siren(false); $("#alarm").classList.add("hide");
  if (had && !quiet) addLog("sys", "أُوقف الإنذار يدوياً");
}
function startTest(i, kind) {
  const r = rt[i]; r.test = { kind, t0: Date.now(), until: Date.now() + 18000 };
  r.st = DET.newState(); r.acc = { flame: 0, smoke: 0 }; r.state = "idle"; r.cool = 0; r.sus = 0;
  addLog("test", "بدء اختبار " + TY[kind] + " على " + cfg.cams[i].name);
}
function endTest(i) {
  const r = rt[i]; r.test = null; if (r.state !== "alarm") r.state = cfg.cams[i].src === "off" ? "off" : "idle";
  r.st = DET.newState(); addLog("test", "انتهى الاختبار على " + cfg.cams[i].name);
}
function analyzeAll() {
  for (let i = 0; i < 6; i++) {
    const r = rt[i], c = cfg.cams[i];
    if (r.test && Date.now() > r.test.until) endTest(i);
    if (!running || !r.live || r.state === "alarm" || r.state === "err") continue;
    sx.drawImage(r.raw, 0, 0, DET.W, DET.H);
    const res = DET.analyze(r.st, sx.getImageData(0, 0, DET.W, DET.H).data, r.mask, { sens: c.sens });
    step(i, "flame", c.flame && res.flame, .3, res);
    step(i, "smoke", c.smoke && res.smoke, .3, res);
  }
}

/* ---------- العرض ---------- */
function wrapText(x, t, cx, cy, maxW) {
  const lines = []; let line = "";
  t.split(" ").forEach(w => { const tt = line ? line + " " + w : w; if (x.measureText(tt).width > maxW && line) { lines.push(line); line = w; } else line = tt; });
  lines.push(line); const y0 = cy - lines.length * 8 + 6;
  lines.slice(0, 6).forEach((l, n) => x.fillText(l, cx, y0 + n * 16));
}
function paint(x, i, f) {
  const r = rt[i], c = cfg.cams[i];
  x.setTransform(f, 0, 0, f, 0, 0); x.drawImage(r.raw, 0, 0, 320, 180);
  c.masks.forEach(m => { x.fillStyle = "#070D11"; x.fillRect(m.x * 320, m.y * 180, m.w * 320, m.h * 180); x.fillStyle = "rgba(255,255,255,.7)"; x.font = "10px sans-serif"; x.textAlign = "center"; x.fillText("منطقة محجوبة", (m.x + m.w / 2) * 320, (m.y + m.h / 2) * 180 + 3); });
  if (maskDraft && maskDraft.i === i) { x.strokeStyle = "#F2A93B"; x.lineWidth = 2; x.setLineDash([5, 4]); x.strokeRect(maskDraft.x * 320, maskDraft.y * 180, maskDraft.w * 320, maskDraft.h * 180); x.setLineDash([]); }
  let msg = "";
  if (c.src === "off" && !r.test) msg = "اضغط ⚙ لإعداد الكاميرا"; else if (r.err) msg = r.err; else if (!running && !r.live) msg = "المراقبة متوقفة، اضغط «بدء المراقبة»";
  if (msg) { x.fillStyle = "rgba(6,14,18,.85)"; x.fillRect(0, 0, 320, 180); x.fillStyle = "#E6EEEC"; x.font = "bold 12px sans-serif"; x.textAlign = "center"; x.direction = "rtl"; wrapText(x, msg, 160, 90, 290); x.direction = "ltr"; }
  if (!running && r.live && !msg) { x.fillStyle = "rgba(212,42,37,.85)"; x.fillRect(0, 0, 320, 16); x.fillStyle = "#fff"; x.font = "bold 10px sans-serif"; x.textAlign = "center"; x.fillText("معاينة فقط: المراقبة متوقفة", 160, 11); }
  x.fillStyle = "rgba(255,255,255,.7)"; x.font = "10px monospace"; x.textAlign = "left"; x.fillText(new Date().toLocaleTimeString("en-GB"), 6, 174);
}
let page = "phone", phLast = "";
function phoneUi() {
  const r = rt[5];
  const st = r.err || (r.v ? "الكاميرا تعمل · " + (running ? STX[r.state] : "المراقبة متوقفة") : "جارٍ فتح الكاميرا…") + (r.test ? " · اختبار" : "");
  if (st !== phLast) {
    phLast = st; $("#phStat").textContent = st; $("#phStat").className = "chip" + (r.err ? " bad" : "");
    $("#phPerm").classList.toggle("hide", !(r.err && !r.v));
    $("#phC").className = "phc" + (r.state === "alarm" ? " alarm" : r.state === "sus" ? " sus" : "");
  }
}
function show(p) {
  page = p; phLast = "";
  $("#pgPhone").classList.toggle("hide", p !== "phone"); $("#pgMon").classList.toggle("hide", p !== "mon");
  $("#bPhone").setAttribute("aria-current", p === "phone" ? "page" : "false"); $("#bMon").setAttribute("aria-current", p === "mon" ? "page" : "false");
}
function loop() {
  k++;
  for (let i = 0; i < 6; i++) {
    const r = rt[i]; r.live = capture(i);
    if (i === 5 || page !== "mon") continue;
    const t = $("#t" + i); if (!t) continue;
    paint(t.querySelector("canvas").getContext("2d"), i, 2);
    t.className = "tile " + r.state; t.querySelector(".nm").textContent = cfg.cams[i].name;
    t.querySelector(".stt").textContent = STX[r.state] + (r.test ? " · اختبار" : "");
  }
  if (page === "phone") { paint($("#phC").getContext("2d"), 5, 2); phoneUi(); }
  if (fsI >= 0) paint($("#fsC").getContext("2d"), fsI, 4);
  if (k % 3 === 0) analyzeAll();
}
function build() {
  const g = $("#grid"); g.innerHTML = "";
  cfg.cams.slice(0, 5).forEach((c, i) => {
    const t = document.createElement("div"); t.className = "tile"; t.id = "t" + i;
    t.innerHTML = '<canvas width="640" height="360"></canvas><div class="cap"><span class="nm"></span><span class="stt"></span><button class="ib" aria-label="إعداد الكاميرا">⚙</button></div>';
    t.querySelector("canvas").onclick = () => openFs(i, false);
    t.querySelector(".ib").onclick = () => openCam(i);
    g.append(t);
  });
}

/* ---------- نافذة كاملة ورسم مناطق الخصوصية ---------- */
function openFs(i, mask) { fsI = i; maskMode = !!mask; $("#fs").classList.remove("hide"); $("#fsDone").classList.toggle("hide", !mask); $("#fsC").style.touchAction = mask ? "none" : ""; document.body.style.overflow = "hidden"; }
function closeFs() { fsI = -1; maskMode = false; maskDraft = null; $("#fs").classList.add("hide"); document.body.style.overflow = ""; }
const fc = $("#fsC");
const pos = e => { const b = fc.getBoundingClientRect(); return [Math.min(1, Math.max(0, (e.clientX - b.left) / b.width)), Math.min(1, Math.max(0, (e.clientY - b.top) / b.height))]; };
fc.addEventListener("pointerdown", e => { if (!maskMode) return; fc.setPointerCapture(e.pointerId); const p = pos(e); maskDraft = { i: fsI, x0: p[0], y0: p[1], x: p[0], y: p[1], w: 0, h: 0 }; e.preventDefault(); });
fc.addEventListener("pointermove", e => { if (!maskDraft) return; const p = pos(e), d = maskDraft; d.x = Math.min(d.x0, p[0]); d.y = Math.min(d.y0, p[1]); d.w = Math.abs(p[0] - d.x0); d.h = Math.abs(p[1] - d.y0); });
fc.addEventListener("pointerup", () => {
  const d = maskDraft; maskDraft = null; if (!d || d.w < .03 || d.h < .03) return;
  cfg.cams[d.i].masks.push({ x: d.x, y: d.y, w: d.w, h: d.h }); rt[d.i].mask = DET.buildMask(cfg.cams[d.i].masks); save();
  addLog("sys", "إضافة منطقة خصوصية في " + cfg.cams[d.i].name);
});
$("#fsX").onclick = closeFs; $("#fsDone").onclick = closeFs;
document.addEventListener("keydown", e => { if (e.key === "Escape" && fsI >= 0) closeFs(); });

/* ---------- نافذة إعداد الكاميرا ---------- */
async function devList() {
  const s = $("#fDev"); s.innerHTML = '<option value="">تلقائي (حسب الاختيار أعلاه)</option>';
  try { (await navigator.mediaDevices.enumerateDevices()).filter(x => x.kind === "videoinput").forEach((x, n) => { const o = document.createElement("option"); o.value = x.deviceId; o.textContent = x.label || "كاميرا " + (n + 1); s.append(o); }); } catch (e) {}
}
function srcUi() { const v = $("#fSrc").value; $("#gDev").classList.toggle("hide", v !== "device"); $("#gIp").classList.toggle("hide", v !== "ip"); }
function openCam(i) {
  editI = i; const c = cfg.cams[i];
  $("#dcT").textContent = "إعداد: " + c.name; $("#fName").value = c.name; $("#fSrc").value = c.src; $("#fFace").value = c.facing;
  $("#fSrc").disabled = i === 5; $("#fUrl").value = c.url; $("#fSens").value = c.sens; $("#fFlame").checked = c.flame; $("#fSmoke").checked = c.smoke; $("#fPre").value = "";
  devList().then(() => { $("#fDev").value = c.deviceId; }); srcUi(); $("#dCam").showModal();
}
async function applyCam() {
  const c = cfg.cams[editI];
  Object.assign(c, { name: $("#fName").value.trim() || c.name, src: $("#fSrc").value, facing: $("#fFace").value, deviceId: $("#fDev").value, url: $("#fUrl").value.trim(), sens: +$("#fSens").value, flame: $("#fFlame").checked, smoke: $("#fSmoke").checked });
  save(); rt[editI].mask = DET.buildMask(c.masks);
  if (running) await openSource(editI); else rt[editI].state = c.src === "off" ? "off" : "idle";
}
$("#fSrc").onchange = srcUi;
$("#fPre").onchange = () => { if ($("#fPre").value) $("#fUrl").value = $("#fPre").value; };
$("#fSave").onclick = async () => { await applyCam(); $("#dCam").close(); };
$("#fCancel").onclick = () => $("#dCam").close();
$("#fMask").onclick = async () => { await applyCam(); $("#dCam").close(); openFs(editI, true); toast("اسحب بإصبعك على الصورة لتحديد منطقة، ثم اضغط «تم»"); };
$("#fClear").onclick = () => { cfg.cams[editI].masks = []; rt[editI].mask = DET.buildMask([]); save(); toast("تم مسح المناطق"); };

/* ---------- نافذة الإعدادات (من الأيقونة السفلية) ---------- */
function applySet() {
  cfg.confirm = +$("#sConf").value; cfg.siren = $("#sSiren").checked; cfg.hour = +$("#sHour").value;
  cfg.server = $("#sServer").value.trim() || "https://ntfy.sh"; cfg.topic = $("#sTopic").value.trim() || cfg.topic; save();
}
$("#bSet").onclick = () => {
  $("#sConf").value = String(cfg.confirm); $("#sSiren").checked = cfg.siren; $("#sHour").value = String(cfg.hour);
  $("#sServer").value = cfg.server; $("#sTopic").value = cfg.topic;
  $("#tCam").innerHTML = cfg.cams.map((c, i) => `<option value="${i}">${esc(c.name)}</option>`).join("");
  $("#dSet").showModal();
};
$("#sClose").onclick = () => { applySet(); $("#dSet").close(); };
$("#sNew").onclick = () => { $("#sTopic").value = "da-" + rnd(20); toast("اشترك في الموضوع الجديد داخل تطبيق ntfy"); };
$("#sTest").onclick = async () => { applySet(); const ok = await push("اختبار درع الأمان", "هذا إشعار تجريبي من التطبيق", 3, ["white_check_mark"]); toast(ok ? "أُرسل الإشعار، تحقق من جوالك الآخر" : "تعذر الإرسال: تحقق من الإنترنت والخادم"); };
$("#sSum").onclick = async () => { applySet(); const ok = await push("ملخص درع الأمان", daySummary(), 3, ["bar_chart"]); toast(ok ? "أُرسل الملخص" : "تعذر الإرسال"); };
async function runTest(kind) { applySet(); $("#dSet").close(); if (!running) await start(); startTest(+$("#tCam").value, kind); }
$("#tFlame").onclick = () => runTest("flame");
$("#tSmoke").onclick = () => runTest("smoke");

/* ---------- التشغيل والإيقاف ---------- */
async function wake() { try { if (navigator.wakeLock && running) wl = await navigator.wakeLock.request("screen"); } catch (e) {} }
document.addEventListener("visibilitychange", () => { if (!document.hidden) wake(); });
async function start() {
  if (running) return; running = true; $("#bStart").textContent = "إيقاف المراقبة";
  try { ac = ac || new (window.AudioContext || window.webkitAudioContext)(); await ac.resume(); } catch (e) {}
  await wake();
  for (let i = 0; i < 6; i++) { if (i === 5 && rt[5].v) continue; await openSource(i); }
  addLog("sys", "بدأت المراقبة"); renderChips();
}
function stop() {
  running = false; stopAlarm(true);
  for (let i = 0; i < 6; i++) { closeSource(i); rt[i].test = null; rt[i].state = cfg.cams[i].src === "off" ? "off" : "idle"; }
  try { wl && wl.release(); } catch (e) {} wl = null;
  $("#bStart").textContent = "بدء المراقبة"; addLog("sys", "توقفت المراقبة"); renderChips(); openSource(5);
}
$("#bStart").onclick = () => (running ? stop() : start());
$("#alStop").onclick = () => stopAlarm(false);
setInterval(() => {                       // الملخص اليومي التلقائي (والتطبيق مفتوح)
  const n = new Date(), day = n.toDateString();
  if (running && cfg.hour >= 0 && n.getHours() >= cfg.hour && cfg.lastRep !== day) { cfg.lastRep = day; save(); push("ملخص درع الأمان اليومي", daySummary(), 3, ["bar_chart"]); }
}, 60000);

$("#bPhone").onclick = () => show("phone"); $("#bMon").onclick = () => show("mon");
$("#phFlip").onclick = async () => { const c = cfg.cams[5]; c.facing = c.facing === "user" ? "environment" : "user"; c.deviceId = ""; save(); await openSource(5); };
$("#phPerm").onclick = () => openSource(5);
$("#phCfg").onclick = () => openCam(5);
$("#phC").onclick = () => openFs(5, false);

build(); renderLog(); renderChips(); show("phone"); setInterval(loop, 100);
openSource(5);   // طلب إذن كاميرا الجوال فور فتح التطبيق
