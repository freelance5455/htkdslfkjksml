const games=[
 {name:"Pixel Quest",genre:"Adventure",version:"1.0",url:"https://example.com/game"},
 {name:"Space Runner",genre:"Arcade",version:"1.2",url:"https://example.com/game"},
 {name:"Block Battle",genre:"Action",version:"0.9",url:"https://example.com/game"}
];
function render(){const q=document.getElementById("search").value.toLowerCase();document.getElementById("games").innerHTML=games.filter(g=>(g.name+g.genre).toLowerCase().includes(q)).map(g=>`<article class="card"><span class="tag">${g.genre}</span><h3>${g.name}</h3><p>Version ${g.version}</p><a class="btn" href="${g.url}" target="_blank" rel="noopener">Download</a></article>`).join("")||"<p>No games found.</p>"}render();