// DK Tube India - starter JavaScript app
// This demo stores sample metadata locally. Online accounts/video sharing need a backend.
let videos = JSON.parse(localStorage.getItem("dktube_videos") || "[]");
let activePage = "home";
let signedIn = localStorage.getItem("dktube_user") || "";

function save(){ localStorage.setItem("dktube_videos", JSON.stringify(videos)); }
function showPage(page){ activePage=page; const app=document.getElementById("app");
  if(page==="upload"){ app.innerHTML=`<section class="panel"><h2>वीडियो अपलोड करें</h2><input id="title" class="field" placeholder="वीडियो का नाम"><textarea id="desc" class="field" placeholder="वीडियो के बारे में"></textarea><select id="category" class="field"><option>Video</option><option>Shorts</option><option>Comedy</option><option>Education</option><option>Music</option></select><input id="file" class="field" type="file" accept="video/*"><button class="primary" onclick="uploadVideo()">Upload</button><p class="muted">यह डेमो वीडियो इसी मोबाइल में रखता है। दूसरे लोगों तक पहुँचाने के लिए ऑनलाइन सर्वर चाहिए।</p></section>`; return; }
  if(page==="profile"){ app.innerHTML=`<section class="panel"><h2>Profile</h2><p>${signedIn||"आप Guest हैं"}</p><button onclick="showLogin()">Login / Sign Up</button></section>`; return; }
  if(page==="shorts"){ renderVideos(true); return; }
  renderVideos(false);
}
function renderVideos(shortsOnly=false){ const app=document.getElementById("app"); if(activePage==="upload"||activePage==="profile")return;
 const q=(document.getElementById("search")?.value||"").toLowerCase();
 const list=videos.filter(v=>(!q||v.title.toLowerCase().includes(q))&&(!shortsOnly||v.category==="Shorts"));
 app.innerHTML=list.length?'<div class="grid">'+list.map((v,i)=>`<article class="card" onclick="playVideo(${i})"><div class="thumb">▶</div><div class="info"><b>${escapeHtml(v.title)}</b><p class="muted">${escapeHtml(v.category)} • ${v.views||0} views</p></div></article>`).join("")+'</div>':'<p class="muted">अभी वीडियो नहीं हैं। Upload पर क्लिक करके अपना वीडियो जोड़ें।</p>';
}
function uploadVideo(){const title=document.getElementById("title").value.trim(),file=document.getElementById("file").files[0],category=document.getElementById("category").value;
 if(!title||!file){alert("वीडियो का नाम और फाइल चुनें।");return;} if(file.size>80*1024*1024){alert("डेमो में 80 MB तक की फाइल चुनें।");return;}
 const reader=new FileReader(); reader.onload=()=>{videos.unshift({title,description:document.getElementById("desc").value,category,data:reader.result,views:0});save();showPage(category==="Shorts"?"shorts":"home");alert("वीडियो इस मोबाइल में सेव हो गया।");}; reader.readAsDataURL(file);
}
function playVideo(i){const v=videos[i];const app=document.getElementById("app");v.views=(v.views||0)+1;save();app.innerHTML=`<section class="watch"><video controls autoplay playsinline src="${v.data}"></video><h2>${escapeHtml(v.title)}</h2><p>${escapeHtml(v.description||"")}</p><button onclick="likeVideo()">♡ Like</button><button onclick="shareVideo('${encodeURIComponent(v.title)}')">Share</button><button onclick="showPage('home')">Back</button><section class="panel"><h3>Comments</h3><input id="comment" class="field" placeholder="Comment लिखें"><button onclick="addComment()">Comment</button><div id="comments"></div></section></section>`;window.currentVideo=v;}
function likeVideo(){alert("Like demo में दिखाया गया। असली shared likes के लिए backend चाहिए।")}
function addComment(){const c=document.getElementById("comment").value.trim();if(c){const d=document.getElementById("comments");d.innerHTML+=`<p>${escapeHtml(c)}</p>`;document.getElementById("comment").value="";}}
function shareVideo(t){if(navigator.share)navigator.share({title:decodeURIComponent(t),text:"DK Tube India"});else alert("इस डिवाइस पर Share विकल्प उपलब्ध नहीं है।")}
function showLogin(){const name=prompt("अपना नाम लिखें (डेमो प्रोफाइल):");if(name){signedIn=name;localStorage.setItem("dktube_user",name);alert("डेमो प्रोफाइल बन गई। ऑनलाइन अकाउंट नहीं बना है।");showPage("profile");}}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
showPage("home");