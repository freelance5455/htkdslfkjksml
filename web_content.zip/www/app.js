const screen=document.getElementById('screen');
let page='home', historyStack=[], audioCtx=null, metroTimer=null, metroOn=false, beat=0, tunerStream=null, tunerFrame=null;
const $=s=>document.querySelector(s);
const chordData={
 C:{fa:'دو ماژور',notes:[261.63,329.63,392,523.25],fingers:['x','3','2','0','1','0'],tips:'انگشت اشاره: سیم دوم، فرت اول؛ انگشت میانی: سیم چهارم، فرت دوم؛ انگشت حلقه: سیم پنجم، فرت سوم.'},
 G:{fa:'سل ماژور',notes:[196,246.94,293.66,392,493.88],fingers:['3','2','0','0','0','3'],tips:'انگشت میانی روی سیم پنجم فرت دوم؛ اشاره روی سیم ششم فرت سوم؛ انگشت کوچک یا حلقه روی سیم اول فرت سوم.'},
 D:{fa:'ر ماژور',notes:[146.83,220,293.66,369.99],fingers:['x','x','0','2','3','2'],tips:'سه انگشت را نزدیک فرت‌ها قرار بده؛ سیم پنجم و ششم را در این شکل نزن.'},
 Em:{fa:'می مینور',notes:[82.41,123.47,164.81,196,246.94,329.63],fingers:['0','2','2','0','0','0'],tips:'دو انگشت روی سیم پنجم و چهارم، هر دو فرت دوم قرار می‌گیرند.'},
 Am:{fa:'لا مینور',notes:[110,164.81,220,261.63,329.63],fingers:['x','0','2','2','1','0'],tips:'اشاره روی سیم دوم فرت اول، میانی روی سیم چهارم فرت دوم و حلقه روی سیم سوم فرت دوم.'},
 Bm:{fa:'سی مینور',notes:[123.47,146.83,196,246.94,293.66],fingers:['x','2','4','4','3','2'],tips:'این آکورد باره دارد؛ فعلاً با فشار ملایم و بدون درد تمرین کن.'}
};
const scales={
 'C Major':{fa:'دو ماژور',notes:[261.63,293.66,329.63,349.23,392,440,493.88,523.25],names:['دو','ر','می','فا','سل','لا','سی','دو']},
 'A Minor':{fa:'لا مینور',notes:[220,246.94,261.63,293.66,329.63,349.23,392,440],names:['لا','سی','دو','ر','می','فا','سل','لا']},
 'G Major':{fa:'سل ماژور',notes:[196,220,246.94,261.63,293.66,329.63,369.99,392],names:['سل','لا','سی','دو','ر','می','فا دیز','سل']},
 'E Minor':{fa:'می مینور',notes:[164.81,185,196,220,246.94,261.63,293.66,329.63],names:['می','فا دیز','سل','لا','سی','دو','ر','می']},
 'D Major':{fa:'ر ماژور',notes:[293.66,329.63,369.99,392,440,493.88,554.37,587.33],names:['ر','می','فا دیز','سل','لا','سی','دو دیز','ر']},
 'D Minor':{fa:'ر مینور',notes:[293.66,329.63,349.23,392,440,466.16,523.25,587.33],names:['ر','می','فا','سل','لا','سی بمل','دو','ر']}
};
const lessons=[
['۱','آشنایی با گیتار و طرز نشستن','ساز را راحت روی پای راست یا چپ قرار بده و شانه‌ها را رها کن.','https://www.youtube.com/results?search_query=classical+guitar+posture+beginner'],
['۲','نام سیم‌های آزاد','از سیم ضخیم تا نازک: می، لا، ر، سل، سی، می (E A D G B E).','https://www.youtube.com/results?search_query=classical+guitar+open+strings+beginner'],
['۳','تمرین انگشت‌های دست راست','با p-i-m-a آرام و جداگانه سیم‌ها را بنواز.','https://www.youtube.com/results?search_query=classical+guitar+right+hand+pima+beginner'],
['۴','نت‌خوانی مقدماتی','نت‌های می، فا، سل و جای آن‌ها روی خطوط حامل را یاد بگیر.','https://www.youtube.com/results?search_query=classical+guitar+reading+music+lesson+1'],
['۵','اولین ملودی: سرود شادی','ملودی را آرام گوش کن و سپس با ساز تکرار کن.','https://www.youtube.com/results?search_query=Ode+to+Joy+classical+guitar+beginner+tutorial'],
['۶','تمرین ریتم و مترونوم','با سرعت ۶۰ ضرب در دقیقه، چهار ضرب یکنواخت بزن.','https://www.youtube.com/results?search_query=classical+guitar+metronome+beginner']
];
function layout(html){screen.innerHTML='<div class="content">'+html+'</div>';document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('active',b.dataset.page===page));}
function toast(s){const t=$('#toast');t.textContent=s;t.classList.add('show');clearTimeout(toast.t);toast.t=setTimeout(()=>t.classList.remove('show'),2600);}
function go(p){if(page!==p)historyStack.push(page);page=p;render();}
function back(){if(historyStack.length){page=historyStack.pop();render()}else{page='home';render()}}
function audio(){const AC=window.AudioContext||window.webkitAudioContext;if(!AC){toast('مرورگر این گوشی پخش صوت را پشتیبانی نمی‌کند.');return null}if(!audioCtx)audioCtx=new AC();if(audioCtx.state==='suspended')audioCtx.resume();return audioCtx}
const guitarSamples={
  E2:{hz:82.4069,url:'https://raw.githubusercontent.com/freepats/spanish-classical-guitar/main/samples/E2.flac'},
  A2:{hz:110,url:'https://raw.githubusercontent.com/freepats/spanish-classical-guitar/main/samples/A2.flac'},
  D3:{hz:146.832,url:'https://raw.githubusercontent.com/freepats/spanish-classical-guitar/main/samples/D3.flac'},
  G3:{hz:195.998,url:'https://raw.githubusercontent.com/freepats/spanish-classical-guitar/main/samples/G3.flac'},
  B3:{hz:246.942,url:'https://raw.githubusercontent.com/freepats/spanish-classical-guitar/main/samples/B3.flac'},
  E4:{hz:329.628,url:'https://raw.githubusercontent.com/freepats/spanish-classical-guitar/main/samples/E4.flac'}
};
const offlineVideos=[
  {id:'strum1',title:'تمرین ریتم و ضربه‌زدن به سیم‌ها',author:'Elenaf',license:'CC BY-SA 3.0',url:'https://commons.wikimedia.org/wiki/Special:Redirect/file/Chitarra_esercizio_preparatorio_strumming_1.webm',source:'https://commons.wikimedia.org/wiki/File:Chitarra_esercizio_preparatorio_strumming_1.webm'},
  {id:'finger9',title:'تمرین الگوی انگشت‌گذاری',author:'Elenaf',license:'CC BY-SA 3.0',url:'https://commons.wikimedia.org/wiki/Special:Redirect/file/Fingerpicking_Pattern_9_pimax_chitarra.webm',source:'https://commons.wikimedia.org/wiki/File:Fingerpicking_Pattern_9_pimax_chitarra.webm'},
  {id:'strum8',title:'تمرین ریتم شمارهٔ ۸',author:'Elenaf',license:'CC BY-SA 3.0',url:'https://commons.wikimedia.org/wiki/Special:Redirect/file/Chitarra_esercizio_preparatorio_strumming_8.webm',source:'https://commons.wikimedia.org/wiki/File:Chitarra_esercizio_preparatorio_strumming_8.webm'}
];
let sampleBuffers={};
function openAssetDB(){return new Promise((resolve,reject)=>{const r=indexedDB.open('guitarOfflineMedia',1);r.onupgradeneeded=()=>r.result.createObjectStore('assets');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
async function assetGet(key){try{const db=await openAssetDB();return await new Promise((resolve,reject)=>{const r=db.transaction('assets','readonly').objectStore('assets').get(key);r.onsuccess=()=>resolve(r.result||null);r.onerror=()=>reject(r.error)})}catch(e){return null}}
async function assetPut(key,value){const db=await openAssetDB();return new Promise((resolve,reject)=>{const tx=db.transaction('assets','readwrite');tx.objectStore('assets').put(value,key);tx.oncomplete=()=>resolve(true);tx.onerror=()=>reject(tx.error)})}
function nearestSample(freq){return Object.entries(guitarSamples).reduce((best,[name,v])=>Math.abs(Math.log(freq/v.hz))<Math.abs(Math.log(freq/guitarSamples[best].hz))?name:best,Object.keys(guitarSamples)[0])}
async function getSampleBuffer(name){if(sampleBuffers[name])return sampleBuffers[name];const c=audio();if(!c)return null;let bytes=await assetGet('sample:'+name);if(!bytes){const r=await fetch(guitarSamples[name].url);if(!r.ok)throw new Error('دانلود نمونهٔ صدای گیتار ناموفق بود');bytes=await r.arrayBuffer();await assetPut('sample:'+name,bytes)}const copy=bytes.slice(0);sampleBuffers[name]=await c.decodeAudioData(copy);return sampleBuffers[name]}
window.downloadOfflineAssets=async function(){
  const button=document.getElementById('downloadAssets');
  const status=document.getElementById('assetStatus');
  const setStatus=(msg)=>{if(status)status.textContent=msg;};
  try{
    if(!window.indexedDB) throw new Error('ذخیره‌سازی آفلاین مرورگر در این محیط در دسترس نیست.');
    if(button){button.disabled=true;button.textContent='در حال دریافت…';}
    setStatus('در حال آماده‌سازی دانلود… لطفاً اینترنت را قطع نکن.');
    let ok=0, failed=[];
    const total=Object.keys(guitarSamples).length+offlineVideos.length;
    for(const [name,sample] of Object.entries(guitarSamples)){
      try{
        let data=await assetGet('sample:'+name);
        if(!data){
          const r=await fetch(sample.url,{mode:'cors'});
          if(!r.ok) throw new Error('HTTP '+r.status);
          data=await r.arrayBuffer();
          await assetPut('sample:'+name,data);
        }
        const c=audio();
        if(c&&!sampleBuffers[name]) sampleBuffers[name]=await c.decodeAudioData(data.slice(0));
        ok++; setStatus(`دریافت رسانه‌ها: ${ok}/${total} — صدای ${name} آماده شد.`);
      }catch(e){failed.push('صدای '+name); setStatus(`دریافت رسانه‌ها: ${ok}/${total} — یک فایل رد شد؛ ادامه می‌دهم…`);}
    }
    for(const v of offlineVideos){
      try{
        let blob=await assetGet('video:'+v.id);
        if(!blob){
          const r=await fetch(v.url,{mode:'cors'});
          if(!r.ok) throw new Error('HTTP '+r.status);
          blob=await r.blob();
          if(blob.size<10000) throw new Error('فایل ویدئو معتبر نیست');
          await assetPut('video:'+v.id,blob);
        }
        ok++; setStatus(`دریافت رسانه‌ها: ${ok}/${total} — ویدئوی ${v.title} آماده شد.`);
      }catch(e){failed.push('ویدئوی '+v.title);}
    }
    if(failed.length){
      setStatus(`دانلود کامل نشد. ${ok}/${total} فایل ذخیره شد. فایل‌های ناموفق: ${failed.join('، ')}.`);
    }else{
      setStatus(`تمام شد! ${ok}/${total} رسانه روی همین دستگاه ذخیره شد و برای استفاده آفلاین آماده است.`);
    }
    if(button){button.disabled=false;button.textContent=failed.length?'تلاش دوباره برای دانلود آفلاین':'فایل‌های آفلاین آماده‌اند';}
  }catch(e){
    setStatus('دانلود شروع نشد: '+(e&&e.message?e.message:'خطای نامشخص')+' اگر فایل را با file:// باز کرده‌ای، آن را داخل یک WebView/مرورگر با پشتیبانی از IndexedDB اجرا کن.');
    if(button){button.disabled=false;button.textContent='تلاش دوباره برای دانلود آفلاین';}
  }
};
async function playOfflineVideo(id){const v=offlineVideos.find(x=>x.id===id);if(!v)return;let blob=await assetGet('video:'+id);const video=$('#offlineVideo');if(!video)return;if(blob){if(video.dataset.objectUrl)URL.revokeObjectURL(video.dataset.objectUrl);const u=URL.createObjectURL(blob);video.dataset.objectUrl=u;video.src=u;video.play().catch(()=>toast('برای پخش، روی دکمهٔ ▶ داخل فیلم بزن.'))}else{video.src=v.url;video.play().catch(()=>toast('برای پخش آنلاین، اینترنت لازم است.'))}}
function tone(freq,duration=.45,when=0,type='plucked',vol=.18){
  const c=audio();if(!c)return;
  const sampleName=nearestSample(freq), sample=sampleBuffers[sampleName];
  if(sample){const src=c.createBufferSource(),g=c.createGain(),lp=c.createBiquadFilter();src.buffer=sample;src.playbackRate.value=freq/guitarSamples[sampleName].hz;lp.type='lowpass';lp.frequency.value=Math.min(7000,Math.max(1800,freq*10));g.gain.setValueAtTime(.0001,c.currentTime+when);g.gain.linearRampToValueAtTime(vol,c.currentTime+when+.01);g.gain.setValueAtTime(vol,c.currentTime+when+Math.min(duration*.65,.5));g.gain.exponentialRampToValueAtTime(.0001,c.currentTime+when+duration);src.connect(lp);lp.connect(g);g.connect(c.destination);src.start(c.currentTime+when);src.stop(c.currentTime+when+duration+.02);return}
  // Fallback if no downloaded recording is available yet.
  const sampleRate=c.sampleRate,length=Math.max(256,Math.floor(sampleRate*Math.min(duration+.12,2.2))),buffer=c.createBuffer(1,length,sampleRate),data=buffer.getChannelData(0),period=Math.max(2,Math.round(sampleRate/freq)),ring=new Float32Array(period);
  for(let i=0;i<period;i++)ring[i]=Math.random()*2-1;let idx=0;for(let i=0;i<length;i++){const next=(idx+1)%period,v=(ring[idx]+ring[next])*.497;data[i]=v;ring[idx]=v;idx=next}for(let i=0;i<length;i++)data[i]*=Math.exp(-(i/sampleRate)*(2.2+freq/220));
  const src=c.createBufferSource(),g=c.createGain(),lp=c.createBiquadFilter();src.buffer=buffer;lp.type='lowpass';lp.frequency.value=Math.min(6500,Math.max(1300,freq*12));g.gain.setValueAtTime(.0001,c.currentTime+when);g.gain.linearRampToValueAtTime(vol,c.currentTime+when+.008);g.gain.setValueAtTime(vol,c.currentTime+when+Math.min(duration*.7,.45));g.gain.exponentialRampToValueAtTime(.0001,c.currentTime+when+duration);src.connect(lp);lp.connect(g);g.connect(c.destination);src.start(c.currentTime+when);src.stop(c.currentTime+when+duration+.03);
}
function playNotes(notes,step=.42){const names=[...new Set(notes.map(nearestSample))];Promise.all(names.map(n=>getSampleBuffer(n).catch(()=>null))).finally(()=>notes.forEach((n,i)=>tone(n,.42,i*step,'plucked',.17)))}
function saved(){try{return JSON.parse(localStorage.getItem('guitarProgress')||'{}')}catch(e){return {}}}
function saveLesson(id,checked){const s=saved();s[id]=checked;localStorage.setItem('guitarProgress',JSON.stringify(s));toast(checked?'پیشرفت ذخیره شد':'علامت درس برداشته شد')}
function home(){page='home';const s=saved(),done=lessons.filter(x=>s['lesson'+x[0]]).length;layout(`<div class="welcome"><div class="guitar"><img class="home-guitar-icon classical-guitar-icon" src="https://img.icons8.com/?size=100&id=VzDRYuJN6JLX&format=png&color=000000" alt="گیتار کلاسیک"></div><h1>به دنیای گیتار خوش آمدی</h1><p class="muted">آموزش گیتار کلاسیک، قدم‌به‌قدم</p></div>
<div class="panel"><b>پیشرفت آموزشی تو</b><p class="muted">${done} درس از ${lessons.length} درس نمونه انجام شده</p><div class="progress"><span style="width:${done/lessons.length*100}%"></span></div><button class="btn" onclick="go('lessons')">ادامه آموزش</button> <button class="btn secondary" onclick="go('plan90')">شروع برنامه ۹۰ روزه</button><p class="muted">هر روز ۲۰ تا ۳۰ دقیقه تمرین آرام و منظم؛ درد یا فشار زیاد نشانه توقف است.</p></div>
<div class="grid">
<button class="card green" onclick="go('chords')">🎓<b>۱۸ آکورد پرکاربرد</b><small>عکس واقعی و راهنمای انگشت‌گذاری</small></button>
<button class="card blue" onclick="go('strings')">🎼<b>سیم‌ها و نت‌ها</b><small>نام فارسی، حرف لاتین و فرت‌های ۰ تا ۱۲</small></button>
<button class="card purple" onclick="go('fingers')">🖐<b>انگشتان دو دست</b><small>نام‌گذاری دست چپ و راست</small></button>
<button class="card orange" onclick="go('technique')">🎯<b>تیراندو و آپویاندو</b><small>آموزش مرحله‌به‌مرحله و فیلم</small></button>
<button class="card blue" onclick="go('scales')">♫<b>نت‌ها و گام‌ها</b><small>شنیدن و تمرین نت‌ها</small></button>
<button class="card" onclick="go('practice')">♩<b>تمرین و مترونوم</b><small>تمرین روزانه و ضرب</small></button>
<button class="card orange" onclick="go('songs')">🎵<b>آهنگ‌های تمرینی</b><small>ملودی‌های ساده با صدا</small></button>
<button class="card" onclick="go('tuner')">🎛<b>تیونر</b><small>تشخیص نت و راهنمای مجوز میکروفون</small></button>
<button class="card wide" onclick="go('videos')">▶️ <b>فیلم‌های آموزشی</b><small>فیلم‌های تیراندو، آپویاندو و انگشت‌گذاری</small></button>
<button class="card wide blue" onclick="openGuitarTypes()">🎸 <b>شناخت انواع گیتار</b><small>تصویر، تفاوت صدا، سیم‌ها و کاربرد هر نوع</small></button>
<button class="card wide" onclick="go('settings')">⚙️ <b>تنظیمات و راهنما</b><small>نکات استفاده و پیشرفت</small></button></div>`)}
/* ===== بخش ۱۸ آکورد — بازنویسی کامل V25 =====
   این بخش عمداً مستقل از chordData/features.js است.
   هر کارت یک button واقعی است و listener مستقیماً روی همان کارت ثبت می‌شود.
*/
const chordBookV25 = {
  C:{fa:'دو ماژور',f:['x',3,2,0,1,0],img:'C.jpg',tips:'اشاره روی سیم ۲ فرت ۱، میانی روی سیم ۴ فرت ۲ و حلقه روی سیم ۵ فرت ۳. سیم ۶ نواخته نشود.'},
  G:{fa:'سل ماژور',f:[3,2,0,0,0,3],img:'G.jpg',tips:'اشاره روی سیم ۵ فرت ۲، میانی روی سیم ۶ فرت ۳ و حلقه یا کوچک روی سیم ۱ فرت ۳.'},
  D:{fa:'ر ماژور',f:['x','x',0,2,3,2],img:'D.jpg',tips:'سه انگشت را روی سیم‌های ۳، ۲ و ۱ قرار بده و فقط چهار سیم زیرین را بنواز.'},
  A:{fa:'لا ماژور',f:['x',0,2,2,2,0],img:'A.jpg',tips:'سه انگشت را کنار هم روی فرت دوم سیم‌های ۴، ۳ و ۲ قرار بده.'},
  E:{fa:'می ماژور',f:[0,2,2,1,0,0],img:'E.jpg',tips:'اشاره روی سیم ۳ فرت ۱، میانی روی سیم ۵ فرت ۲ و حلقه روی سیم ۴ فرت ۲.'},
  Am:{fa:'لا مینور',f:['x',0,2,2,1,0],img:'Am.jpg',tips:'اشاره روی سیم ۲ فرت ۱، میانی روی سیم ۴ فرت ۲ و حلقه روی سیم ۳ فرت ۲.'},
  Em:{fa:'می مینور',f:[0,2,2,0,0,0],img:'Em.jpg',tips:'میانی و حلقه را روی سیم‌های ۵ و ۴، فرت دوم قرار بده.'},
  Dm:{fa:'ر مینور',f:['x','x',0,2,3,1],img:'Dm.jpg',tips:'اشاره روی سیم ۱ فرت ۱، میانی روی سیم ۳ فرت ۲ و حلقه روی سیم ۲ فرت ۳.'},
  F:{fa:'فا ماژور',f:[1,3,3,2,1,1],img:'F.jpg',tips:'برای شکل باره‌ای، اشاره را روی فرت اول نگه دار و فشار دست را حداقل لازم قرار بده.'},
  Bm:{fa:'سی مینور',f:['x',2,4,4,3,2],img:'Bm.jpg',tips:'این آکورد باره دارد؛ مچ را صاف نگه دار و انگشت اشاره را روی فرت دوم نگه دار.'},
  B7:{fa:'سی هفت',f:['x',2,1,2,0,2],img:'B7.jpg',tips:'اشاره روی سیم ۵ فرت ۲، میانی روی سیم ۳ فرت ۲ و انگشتان دیگر را مطابق شکل قرار بده.'},
  A7:{fa:'لا هفت',f:['x',0,2,0,2,0],img:'A7.jpg',tips:'انگشتان روی سیم‌های ۴ و ۲ فرت دوم قرار می‌گیرند؛ سیم ۵ آزاد است.'},
  E7:{fa:'می هفت',f:[0,2,0,1,0,0],img:'E7.jpg',tips:'اشاره روی سیم ۳ فرت ۱ و میانی و حلقه روی سیم‌های ۵ و ۴ فرت دوم.'},
  D7:{fa:'ر هفت',f:['x','x',0,2,1,2],img:'D7.jpg',tips:'سه انگشت روی سیم‌های ۳، ۲ و ۱ قرار می‌گیرند؛ دو سیم بم نواخته نشوند.'},
  C7:{fa:'دو هفت',f:['x',3,2,3,1,0],img:'C7.jpg',tips:'شکل دو ماژور را با تغییر انگشت روی سیم ۴ فرت ۳ اجرا کن.'},
  G7:{fa:'سل هفت',f:[3,2,0,0,0,1],img:'G7.jpg',tips:'شکل سل را بگیر و انگشت کوچک را روی سیم ۱ فرت ۱ اضافه کن.'},
  Em7:{fa:'می مینور هفت',f:[0,2,0,0,0,0],img:'Em7.jpg',tips:'فقط انگشت میانی روی سیم ۵ فرت ۲؛ بقیه سیم‌ها آزاد هستند.'},
  Fmaj7:{fa:'فا ماژور هفت',f:['x','x',3,2,1,0],img:'Fmaj7.jpg',tips:'سه انگشت را روی سیم‌های ۴، ۳ و ۲ قرار بده؛ سیم ۱ آزاد است.'},
};

function chordPhotoV25(c,k){return 'media/chords/'+(c.img||'chords-real-reference.png');}
function chordNotesV25(f){
  const midi=[40,45,50,55,59,64];
  return f.map((v,i)=>v==='x'?null:440*Math.pow(2,((midi[i]+Number(v))-69)/12)).filter(Boolean);
}
function chords(){
  page='chords';
  const keys=Object.keys(chordBookV25);
  layout(`<h2>۱۸ آکورد پرکاربرد</h2>
    <p class="muted">هر کارت را لمس کن تا عکس واقعی، نحوهٔ انگشت‌گذاری و صدای همان آکورد باز شود.</p>
    <div id="chordBookV25" class="chord-grid" aria-label="۱۸ آکورد پرکاربرد">
      ${keys.map(k=>{const c=chordBookV25[k];return `<button type="button" class="chord-card" data-v25-chord="${k}">
        <img src="${chordPhotoV25(c,k)}" alt="تصویر واقعی آکورد ${k}" loading="eager">
        <div class="chord-card-info"><b>${k}</b><span>${c.fa}</span></div>
      </button>`}).join('')}
    </div>`);
  document.querySelectorAll('[data-v25-chord]').forEach(btn=>{
    btn.addEventListener('click',function(ev){
      ev.preventDefault(); ev.stopPropagation();
      const k=this.getAttribute('data-v25-chord');
      detail(k);
    });
  });
}
function detail(k){
  const c=chordBookV25[k];
  if(!c){toast('آکورد پیدا نشد.');return;}
  page='chordDetail'; window.currentChord=k; window.currentChordV25=k;
  const fingerLabels=c.f.map((v,i)=>v==='x'?'×':v==='0'?'○':v).join('  ');
  layout(`<h2>آکورد ${k} — ${c.fa}</h2>
    <div class="panel chord-photo real-chord-panel">
      <h3>تصویر واقعی دستهٔ گیتار و انگشت‌گذاری</h3>
      <img class="real-chord-photo" src="${chordPhotoV25(c,k)}" alt="تصویر واقعی نحوه انگشت گذاری آکورد ${k}">
      <div class="chord-legend"><span>سیم‌ها: ۶ ← ۱</span><span>فرت: ${fingerLabels}</span></div>
    </div>
    <div class="panel"><h3>نحوهٔ انگشت‌گذاری</h3><p>${c.tips}</p>
      <div class="panel"><b>شمارهٔ انگشت‌ها:</b><p class="muted">۱ اشاره، ۲ میانی، ۳ حلقه، ۴ کوچک. سیم‌های × نواخته نمی‌شوند و ○ آزاد هستند.</p></div>
      <button type="button" class="btn" id="v25PlayChord">▶ شنیدن آکورد</button>
      <button type="button" class="btn secondary" id="v25StopChord">■ توقف صدا</button>
    </div>
    <button type="button" class="btn secondary" id="v25BackChords">بازگشت به ۱۸ آکورد</button>`);
  document.getElementById('v25PlayChord').addEventListener('click',()=>playChord(k));
  document.getElementById('v25StopChord').addEventListener('click',stopSound);
  document.getElementById('v25BackChords').addEventListener('click',chords);
}
/* V25 navigation bridge: مسیر مستقیم و مستقل برای ورود به بخش آکوردها */
window.openChordsV25=function(){ chords(); };
window.openChordDetailV25=function(k){ detail(k); };
function playChord(k){
  const c=chordBookV25[k]; if(!c)return;
  chordNotesV25(c.f).forEach((n,i)=>tone(n,1.15,i*.035,'plucked',.12));
}
function stopSound(){if(audioCtx){audioCtx.close();audioCtx=null}toast('پخش صدا متوقف شد.')}
function scalesPage(){page='scales';layout(`<h2>گام‌ها و نت‌ها</h2><p class="muted">روی هر گام بزن و نت‌ها را به ترتیب بشنو.</p><div class="list">${Object.entries(scales).map(([k,v])=>`<div class="row" onclick="scaleDetail('${k}')"><div class="left"><div class="dot">${k[0]}</div><div><b>${k}</b><br><small>گام ${v.fa}</small></div></div><span>‹</span></div>`).join('')}</div>`)}
function scaleDetail(k){const s=scales[k];page='scaleDetail';layout(`<h2>${k} — ${s.fa}</h2><div class="panel"><h3>نت‌های گام</h3><div class="note-pills">${s.names.map((n,i)=>`<span class="pill">${n}</span>`).join('')}</div><button class="btn" onclick="playScale('${k}')">▶ پخش گام</button><button class="btn secondary" onclick="playScale('${k}',.65)">🐢 پخش آهسته</button></div><p class="muted">ابتدا به صدا گوش کن، سپس نت‌ها را روی گیتار پیدا کن. برای اجرای واقعی، از یک مدرس یا فیلم آموزشی کمک بگیر.</p><button class="btn secondary" onclick="go('scales')">بازگشت</button>`)}
function playScale(k,step=.32){playNotes(scales[k].notes,step)}
function practice(){page='practice';layout(`<h2>تمرین روزانه</h2><div class="panel"><h3>۱. مترونوم</h3><p class="muted">سرعت را انتخاب کن و شروع بزن. با هر ضرب صدای کوتاه می‌شنوی.</p><label for="bpm">سرعت: <b id="bpmLabel">60</b> BPM</label><input class="field" id="bpm" type="range" min="40" max="160" value="60" oninput="$('#bpmLabel').textContent=this.value"><div class="meter-number" id="beatNum">—</div><button class="btn" id="metroBtn" onclick="toggleMetro()">▶ شروع مترونوم</button></div><div class="panel"><h3>۲. برنامه ۲۰ دقیقه‌ای</h3><label class="check"><input type="checkbox" onchange="savePractice('warmup',this.checked)"> ۵ دقیقه: گرم‌کردن انگشت‌ها</label><label class="check"><input type="checkbox" onchange="savePractice('chords',this.checked)"> ۵ دقیقه: تعویض آکوردها</label><label class="check"><input type="checkbox" onchange="savePractice('notes',this.checked)"> ۵ دقیقه: نت‌خوانی و ملودی</label><label class="check"><input type="checkbox" onchange="savePractice('song',this.checked)"> ۵ دقیقه: آهنگ دلخواه</label></div><button class="btn secondary" onclick="go('tuner')">رفتن به تیونر</button>`);if(metroOn){stopMetro()}}
function savePractice(k,v){const s=saved();s['practice_'+k]=v;localStorage.setItem('guitarProgress',JSON.stringify(s));toast('تمرین ذخیره شد')}
function toggleMetro(){if(metroOn){stopMetro();return}const c=audio();if(!c)return;metroOn=true;beat=0;$('#metroBtn').textContent='■ توقف مترونوم';const tick=()=>{if(!metroOn)return;const bpm=Number($('#bpm')?.value||60);tone(beat%4===0?1000:750,.07,0,'square',.12);beat++;const el=$('#beatNum');if(el)el.textContent=String((beat-1)%4+1);metroTimer=setTimeout(tick,60000/bpm)};tick()}
function stopMetro(){metroOn=false;clearTimeout(metroTimer);metroTimer=null;const b=$('#metroBtn');if(b)b.textContent='▶ شروع مترونوم';const n=$('#beatNum');if(n)n.textContent='—'}
function songs(){page='songs';layout(`<h2>آهنگ‌های تمرینی</h2><p class="muted">ملودی‌های ساده برای گوش دادن و تمرین. صداها با مدل آفلاینِ سیم زخمه‌ای ساخته می‌شوند.</p><div class="panel"><h3>سرود شادی (Ode to Joy)</h3><p>می، می، فا، سل — سل، فا، می، ر — دو، دو، ر، می — می، ر، ر</p><button class="btn" onclick="playNotes([329.63,329.63,349.23,392,392,349.23,329.63,293.66,261.63,261.63,293.66,329.63,329.63,293.66,293.66],.42)">▶ پخش ملودی</button></div><div class="panel"><h3>تولدت مبارک</h3><p>ملودی نمونه برای آشنایی با تغییر نت‌ها.</p><button class="btn" onclick="playNotes([261.63,261.63,293.66,261.63,349.23,329.63,261.63,261.63,293.66,261.63,392,349.23],.36)">▶ پخش ملودی</button></div><div class="panel"><h3>تمرین نت‌های آزاد</h3><p>سیم‌های آزاد از بم به زیر: می، لا، ر، سل، سی، می.</p><button class="btn" onclick="playNotes([82.41,110,146.83,196,246.94,329.63],.55)">▶ پخش شش سیم</button></div>`)}
function videos(){page='videos';layout(`<h2>صداها و فیلم‌های آفلاین</h2>
<p class="muted">این بخش می‌تواند نمونه‌های ضبط‌شدهٔ گیتار کلاسیک و فیلم‌های دارای مجوز آزاد را با یک بار اتصال به اینترنت روی دستگاه ذخیره کند. حجم ویدئوها کم است؛ بعد از دانلود، از داخل همین برنامه پخش می‌شوند.</p>
<div class="panel"><h3>دانلود یک‌باره برای استفاده بدون اینترنت</h3><p>حدود ۶ نمونهٔ صوتی واقعی و ۳ کلیپ کوتاه آموزشی دریافت می‌شود. این کار فقط یک بار لازم است و فایل‌ها در حافظهٔ مرورگر همین دستگاه ذخیره می‌شوند.</p><button class="btn" id="downloadAssets" onclick="window.downloadOfflineAssets()">⬇ دانلود صداها و فیلم‌ها</button><p id="assetStatus" class="muted">وضعیت فایل‌ها را با زدن دکمه بررسی کن.</p></div>
<div class="panel"><h3>پخش فیلم آموزشی</h3><video id="offlineVideo" controls playsinline preload="none" style="width:100%;border-radius:12px;background:#000;min-height:150px"></video><p class="muted">یک فیلم را انتخاب کن. اگر دانلود آفلاین انجام شده باشد، از فایل ذخیره‌شده پخش می‌شود؛ در غیر این صورت اینترنت لازم است.</p></div>
${offlineVideos.map(v=>`<div class="panel video-card"><div class="play">▶️</div><div style="flex:1"><b>${v.title}</b><p class="muted">پدیدآورنده: ${v.author} · مجوز: ${v.license}</p><button class="btn secondary" onclick="playOfflineVideo('${v.id}')">▶ پخش فیلم</button><a href="${v.source}" target="_blank" rel="noopener">مشخصات و مجوز فایل ↗</a></div></div>`).join('')}
<div class="panel"><b>مجوزها و منبع‌ها</b><p class="muted">نمونه‌های صوتی گیتار کلاسیک از پروژهٔ FreePats و با مجوز CC0 ارائه شده‌اند. ویدئوهای تمرین ریتم و انگشت‌گذاری از Wikimedia Commons هستند و با مجوز CC BY-SA 3.0 استفاده می‌شوند؛ در صورت بازنشر، نام سازنده و مجوز باید حفظ شود.</p><a href="https://freepats.zenvoid.org/Guitar/acoustic-guitar.html" target="_blank" rel="noopener">منبع صداها ↗</a></div>`)}
function lessonsPage(){page='lessons';const s=saved();layout(`<h2>مسیر یادگیری از صفر</h2><p class="muted">هر درس را مطالعه کن، تمرین کن و پس از انجام تیک بزن.</p>${lessons.map(l=>`<div class="panel"><h3>درس ${l[0]}: ${l[1]}</h3><p>${l[2]}</p><label class="check"><input type="checkbox" ${s['lesson'+l[0]]?'checked':''} onchange="saveLesson('${l[0]}',this.checked)"> این درس را انجام دادم</label><a href="${l[3]}" target="_blank" rel="noopener">ویدئوهای کمکی این درس ↗</a></div>`).join('')}`)}
function settings(){page='settings';layout(`<h2>تنظیمات و راهنما</h2><div class="panel"><h3>درباره نسخه</h3><p>این نسخه از نمونه‌های ضبط‌شدهٔ گیتار کلاسیک با مجوز CC0 پشتیبانی می‌کند؛ آن‌ها را از بخش فیلم‌ها و صداها یک‌بار دانلود کن تا بعداً آفلاین پخش شوند. در صورت نبود نمونهٔ ذخیره‌شده، صدای شبیه‌سازی‌شده به‌عنوان پشتیبان استفاده می‌شود.</p><p class="muted">برای پخش صدا یک بار روی دکمه پخش بزن. صداها و ویدئوها در این بسته جاسازی نشده‌اند؛ برای رعایت حجم ZIP، از بخش فیلم‌ها و صداها آن‌ها را یک‌بار با اینترنت دریافت و روی دستگاه ذخیره کن. تیونر برای دسترسی به میکروفون به مرورگر و مجوز نیاز دارد و در فایل محلی ممکن است به دلیل محدودیت امنیتی کار نکند.</p></div><div class="panel"><h3>پاک کردن پیشرفت</h3><p class="muted">این کار تیک درس‌ها و تمرین‌های ذخیره‌شده را حذف می‌کند.</p><button class="btn danger" onclick="if(confirm('پیشرفت ذخیره‌شده پاک شود؟')){localStorage.removeItem('guitarProgress');toast('پیشرفت پاک شد');settings()}">پاک کردن پیشرفت</button></div>`)}
async function tuner(){page='tuner';stopMetro();layout(`<h2>تیونر گیتار</h2><div class="dial" id="pitch">—</div><div class="status" id="tunerStatus">برای تشخیص کوک، میکروفون را فعال کن.</div><p class="muted">سیم‌ها از ضخیم به نازک: E2، A2، D3، G3، B3، E4</p><button class="btn" id="micBtn" onclick="startTuner()">🎙 فعال کردن میکروفون</button><button class="btn secondary" onclick="stopTuner()">توقف تیونر</button><p class="muted">اگر اجازه میکروفون داده نشود یا برنامه از فایل محلی باز شده باشد، تشخیص صدا ممکن است در دسترس نباشد.</p>`)}
async function startTuner(){try{if(!navigator.mediaDevices?.getUserMedia)throw new Error('مرورگر اجازه دسترسی به میکروفون را در این حالت نمی‌دهد.');tunerStream=await navigator.mediaDevices.getUserMedia({audio:true});const c=audio();const src=c.createMediaStreamSource(tunerStream),an=c.createAnalyser();an.fftSize=4096;src.connect(an);const buf=new Float32Array(an.fftSize);const names=[['E2',82.41],['A2',110],['D3',146.83],['G3',196],['B3',246.94],['E4',329.63]];function detect(){if(!tunerStream)return;an.getFloatTimeDomainData(buf);let rms=0;for(const x of buf)rms+=x*x;rms=Math.sqrt(rms/buf.length);if(rms>.012){let bestLag=0,best=0;for(let lag=35;lag<buf.length/2;lag++){let corr=0;for(let i=0;i<buf.length/2;i++)corr+=buf[i]*buf[i+lag];if(corr>best){best=corr;bestLag=lag}}if(bestLag){const hz=c.sampleRate/bestLag;let nearest=names.reduce((a,b)=>Math.abs(b[1]-hz)<Math.abs(a[1]-hz)?b:a);const cents=1200*Math.log2(hz/nearest[1]);$('#pitch').textContent=nearest[0];$('#tunerStatus').textContent=`${hz.toFixed(1)} Hz — ${cents>0?'+':''}${cents.toFixed(0)} سنت ${Math.abs(cents)<10?'؛ نزدیک به کوک است':cents>0?'؛ کمی زیرتر کوک کن':'؛ کمی شل‌تر کوک کن'}`}}tunerFrame=requestAnimationFrame(detect)}detect();$('#micBtn').textContent='🎙 میکروفون فعال است'}catch(e){toast(e.message||'فعال‌سازی میکروفون ناموفق بود.');const st=$('#tunerStatus');if(st)st.textContent='میکروفون فعال نشد. از مرورگر دارای HTTPS استفاده کن و مجوز میکروفون بده.'}}
function stopTuner(){if(tunerFrame)cancelAnimationFrame(tunerFrame);tunerFrame=null;if(tunerStream){tunerStream.getTracks().forEach(t=>t.stop());tunerStream=null}if($('#pitch'))$('#pitch').textContent='—';if($('#tunerStatus'))$('#tunerStatus').textContent='تیونر متوقف شد.'}
function render(){if(page==='home')home();else if(page==='chords')chords();else if(page==='scales')scalesPage();else if(page==='practice')practice();else if(page==='songs')songs();else if(page==='videos')videos();else if(page==='lessons')lessonsPage();else if(page==='settings')settings();else if(page==='tuner')tuner();else if(page==='chordDetail')detail(window.currentChord||'C');else if(page==='scaleDetail')scaleDetail(window.currentScale||'C Major');}
const _detail=detail;detail=function(k){window.currentChord=k;_detail(k)};const _scaleDetail=scaleDetail;scaleDetail=function(k){window.currentScale=k;_scaleDetail(k)};
document.querySelectorAll('nav button').forEach(b=>b.onclick=()=>go(b.dataset.page));
$('#back').onclick=back;$('#settings').onclick=()=>go('settings');
window.addEventListener('beforeunload',()=>{stopMetro();stopTuner()});
home();