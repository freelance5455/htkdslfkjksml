const KEY = 'tavars_v8_data';
const SALE = 'tavars_v8_sales';
const EXPENSE = 'tavars_v8_expenses';
const TAVAR = 'tavars_v10_tavars';
const DEBT = 'tavars_v10_debts';
const REPAIR = 'tavars_v11_repairs';
const CASH = 'tavars_cash_balance';

function readStore(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    const parsed = raw ? JSON.parse(raw) : fallback;
    return Array.isArray(parsed) ? parsed : fallback;
  } catch (_) {
    return fallback;
  }
}

let data = readStore(KEY, []).map(normalizeProduct);
let sales = readStore(SALE, []);
let expenses = readStore(EXPENSE, []);
let tavars = readStore(TAVAR, []);
let debts = readStore(DEBT, []);
let repairs = readStore(REPAIR, []);
let cart = {};
let cashBalance = null;
let selectedTavars = new Set();
purgeZeroStockProducts();
cashBalance = calculateCashFromHistory();
localStorage.setItem(CASH, String(cashBalance));

function normalizeProduct(p) {
  return {
    id: String(p?.id || uid()),
    name: String(p?.name || '').trim(),
    qty: Math.max(0, Number.isInteger(Number(p?.qty)) ? Number(p.qty) : Math.floor(Number(p?.qty) || 0)),
    cost: Math.max(0, Number(p?.cost) || 0),
    avgCost: Math.max(0, Number(p?.avgCost ?? p?.cost) || 0),
    price: Math.max(0, Number(p?.price) || 0),
    created: Number(p?.created) || Date.now(),
    updated: Number(p?.updated) || Date.now()
  };
}

function purgeZeroStockProducts() {
  const before = data.length;
  data = data.filter(p => Number(p.qty) > 0);
  reconcileCart();
  return data.length !== before;
}

function reconcileCart() {
  const valid = {};
  for (const [id, rawQty] of Object.entries(cart)) {
    const p = data.find(x => x.id === id);
    const q = Math.min(Math.max(0, Number(rawQty) || 0), p ? Number(p.qty) : 0);
    if (p && q > 0) valid[id] = q;
  }
  cart = valid;
}

const $ = id => document.getElementById(id);
const money = n => Number(n || 0).toLocaleString('uz-UZ') + ' so‘m';
const dateText = ts => new Date(ts).toLocaleString('uz-UZ', { day:'2-digit', month:'2-digit', year:'numeric', hour:'2-digit', minute:'2-digit' });
const dayKey = ts => new Date(ts).toDateString();
const uid = () => (window.crypto && crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`);

function save() {
  data = data.map(normalizeProduct);
  data = data.filter(p => Number(p.qty) > 0);
  reconcileCart();
  localStorage.setItem(KEY, JSON.stringify(data));
  localStorage.setItem(SALE, JSON.stringify(sales));
  localStorage.setItem(EXPENSE, JSON.stringify(expenses));
  localStorage.setItem(TAVAR, JSON.stringify(tavars));
  localStorage.setItem(DEBT, JSON.stringify(debts));
  localStorage.setItem(REPAIR, JSON.stringify(repairs));
  localStorage.setItem(CASH, String(calculateCashFromHistory()));
  cashBalance = calculateCashFromHistory();
}

function esc(value) {
  return String(value ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
}

function toast(text) {
  const el = $('toast');
  el.textContent = text;
  el.classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => el.classList.remove('show'), 1900);
}

function go(id) {
  document.querySelectorAll('.page').forEach(page => page.classList.remove('active'));
  const target = $(id);
  if (!target) return;
  target.classList.add('active');
  render();
  window.scrollTo({ top:0, behavior:'smooth' });
}

document.querySelectorAll('[data-go]').forEach(btn => btn.addEventListener('click', () => go(btn.dataset.go)));

document.querySelectorAll('[data-close]').forEach(btn => btn.addEventListener('click', () => closeModal(btn.dataset.close)));

$('menuBtn').onclick = () => {
  $('spyPanel').hidden = true;
  $('resetPanel').hidden = true;
  $('spyPassword').value = '';
  $('verifySpy').textContent = 'Tekshirish';
  openModal('v13Overlay');
};
$('v13Ok').onclick = () => { closeModal('v13Overlay'); go('home'); };
$('v13Spy').onclick = () => { $('spyPanel').hidden = !$('spyPanel').hidden; if (!$('spyPanel').hidden) setTimeout(() => $('spyPassword').focus(), 50); };
$('verifySpy').onclick = () => {
  if ($('spyPassword').value === 'R23062011n') {
    $('resetPanel').hidden = false;
    $('verifySpy').textContent = 'Parol to‘g‘ri ✅';
    toast('RESET imkoniyati ochildi');
  } else {
    $('resetPanel').hidden = true;
    toast('Parol noto‘g‘ri');
  }
};
$('resetAll').onclick = () => {
  if (!confirm('Hamma ma’lumotlar o‘chiriladi. Rostdan RESET qilasizmi?')) return;
  [KEY, SALE, EXPENSE, TAVAR, DEBT, REPAIR, CASH].forEach(k => localStorage.removeItem(k));
  data = [];
  sales = [];
  expenses = [];
  tavars = [];
  debts = [];
  repairs = [];
  cart = {};
  selectedTavars = new Set();
  closeModal('v13Overlay');
  go('home');
  render();
  toast('Tizim boshidan boshlandi ✅');
};

function openModal(id) {
  const el = $(id);
  if (!el) return;
  el.classList.add('open');
  el.setAttribute('aria-hidden', 'false');
  document.body.classList.add('modalOpen');
}

function closeModal(id) {
  const el = $(id);
  if (!el) return;
  el.classList.remove('open');
  el.setAttribute('aria-hidden', 'true');
  if (![...document.querySelectorAll('.overlay')].some(x => x.classList.contains('open'))) {
    document.body.classList.remove('modalOpen');
  }
}

document.querySelectorAll('.overlay').forEach(overlay => {
  overlay.addEventListener('click', e => { if (e.target === overlay) closeModal(overlay.id); });
});

$('addForm').onsubmit = e => {
  e.preventDefault();
  const name = $('name').value.trim();
  const qty = Number($('qty').value);
  const cost = Number($('cost').value);
  const price = Number($('price').value);
  if (!name || !Number.isFinite(qty) || qty < 1 || !Number.isInteger(qty) || !Number.isFinite(cost) || cost < 0 || !Number.isFinite(price) || price < 0) {
    return toast('Ma’lumotlarni tekshiring');
  }

  const existing = data.find(p => p.name.trim().toLocaleLowerCase() === name.toLocaleLowerCase());
  if (existing) {
    const ok = confirm(`“${existing.name}” omborda bor. Yana ${qty} dona qo‘shilsinmi?\n\nEski qoldiq: ${existing.qty} dona\nYangi qoldiq: ${existing.qty + qty} dona`);
    if (!ok) return toast('Qo‘shish bekor qilindi');

    const oldQty = Number(existing.qty) || 0;
    const oldCost = Number(existing.avgCost ?? existing.cost) || 0;
    existing.avgCost = ((oldQty * oldCost) + (qty * cost)) / (oldQty + qty);
    existing.cost = Math.round(existing.avgCost);
    existing.qty = oldQty + qty;

    if (price !== Number(existing.price)) {
      const changePrice = confirm(`Sotish narxi ${money(existing.price)} edi.\n${money(price)} qilib o‘zgartiraymi?`);
      if (changePrice) existing.price = price;
    }

    existing.updated = Date.now();
    save();
    e.target.reset();
    toast('Mavjud mahsulotga qo‘shildi ✅');
    go('products');
    return;
  }

  data.push({ id:uid(), name, qty, cost, price, avgCost:cost, created:Date.now(), updated:Date.now() });
  save();
  e.target.reset();
  toast('Yangi mahsulot qo‘shildi ✅');
  go('products');
};

function renderProducts() {
  reconcileCart();
  const q = ($('search')?.value || '').trim().toLocaleLowerCase();
  const list = data.filter(p => Number(p.qty) > 0 && String(p.name || '').toLocaleLowerCase().includes(q));
  $('productList').innerHTML = list.length
    ? list.map(p => `<div class="card">
        <div class="cardTop"><div><div class="name">${esc(p.name)}</div></div><b>${Number(p.qty)||0} dona</b></div>
        <div class="price">${money(p.price)}</div>
        <div class="actions"><button class="primary" onclick="addCart('${p.id}')">Sotish</button><button onclick="removeProduct('${p.id}')" class="danger">O‘chirish</button></div>
      </div>`).join('')
    : '<div class="card empty">Hozircha mahsulot yo‘q.</div>';
}

function cartTotal() {
  return Object.entries(cart).reduce((sum, [id, q]) => {
    const p = data.find(item => item.id === id);
    return sum + (p ? Number(p.price) * Number(q) : 0);
  }, 0);
}

function cartCost() {
  return Object.entries(cart).reduce((sum, [id, q]) => {
    const p = data.find(item => item.id === id);
    const unitCost = p ? Number(p.avgCost ?? p.cost) : 0;
    return sum + unitCost * Number(q);
  }, 0);
}

function renderSell() {
  reconcileCart();
  const rows = data.filter(p => Number(p.qty) > 0).map(p => {
    const stock = Number(p.qty);
    const selected = Math.min(Math.max(0, Number(cart[p.id] || 0)), stock);
    const minusDisabled = selected <= 0;
    const plusDisabled = selected >= stock;
    const stockText = `Omborda: ${stock} dona · ${money(p.price)}`;

    return `<div class="saleRow">
      <div><b>${esc(p.name)}</b><div class="muted">${stockText}</div></div>
      <div class="salePick">
        <button aria-label="Kamaytirish" onclick="removeCart('${p.id}')" ${minusDisabled ? 'disabled' : ''}>−</button>
        <strong>${selected}</strong>
        <button aria-label="Qo‘shish" onclick="addCart('${p.id}')" ${plusDisabled ? 'disabled' : ''}>+</button>
      </div>
    </div>`;
  }).join('');

  $('sellList').innerHTML = rows || '<div class="card empty">Sotish uchun omborda mahsulot yo‘q.</div>';
  $('saleTotal').textContent = cartTotal().toLocaleString('uz-UZ');
}

function addCart(id) {
  reconcileCart();
  const p = data.find(x => x.id === id);
  if (!p) return;
  if (Number(cart[id] || 0) >= Number(p.qty)) return toast('Omborda buncha mahsulot yo‘q');
  cart[id] = Number(cart[id] || 0) + 1;
  renderSell();
}

function removeCart(id) {
  if (!cart[id]) return;
  cart[id] -= 1;
  if (cart[id] <= 0) delete cart[id];
  renderSell();
}

function prepareCheckout() {
  const total = cartTotal();
  if (!total) return toast('Avval mahsulot tanlang');

  $('checkoutTotal').textContent = money(total);
  $('clientPaid').value = total;
  updatePaymentPreview();

  $('checkoutItems').innerHTML = Object.entries(cart).map(([id, q]) => {
    const p = data.find(item => item.id === id);
    if (!p) return '';
    return `<div class="receiptRow"><span>${esc(p.name)} × ${q}</span><b>${money(Number(p.price) * Number(q))}</b></div>`;
  }).join('');

  openModal('checkoutOverlay');
  setTimeout(() => $('clientPaid').focus(), 50);
}

function updatePaymentPreview() {
  const total = cartTotal();
  const rawPaid = Number($('clientPaid').value || 0);
  const paid = Math.max(0, rawPaid);
  const debt = Math.max(0, total - paid);
  const change = Math.max(0, paid - total);
  const realizedBase = Math.min(paid, total);
  const cost = cartCost();
  const paidProfit = total > 0 ? (realizedBase / total) * (total - cost) : 0;

  $('changeAmount').textContent = money(Math.round(change));
  $('debtAmount').textContent = money(Math.round(debt));
  $('paidProfit').textContent = money(Math.round(paidProfit));
}

$('finishSale').onclick = prepareCheckout;
$('clientPaid').addEventListener('input', updatePaymentPreview);

$('completeSale').onclick = () => {
  const total = cartTotal();
  if (!total) return toast('Sotuv bo‘sh');
  const rawPaid = Number($('clientPaid').value || 0);
  if (!Number.isFinite(rawPaid) || rawPaid < 0) return toast('Klient pulini tekshiring');

  const customerPaid = Math.round(rawPaid);
  const debt = Math.max(0, total - customerPaid);
  const change = Math.max(0, customerPaid - total);
  const collected = Math.min(customerPaid, total);
  let cost = 0;
  const items = [];

  for (const [id, qRaw] of Object.entries(cart)) {
    const q = Number(qRaw);
    const p = data.find(item => item.id === id);
    if (!p || !Number.isInteger(q) || q < 1 || q > Number(p.qty)) {
      return toast('Ombordagi qoldiq o‘zgargan. Qayta tanlang.');
    }
    const unitCost = Number(p.avgCost ?? p.cost) || 0;
    const unitPrice = Number(p.price) || 0;
    const lineTotal = unitPrice * q;
    const lineCost = unitCost * q;
    cost += lineCost;
    items.push({ productId:p.id, name:p.name, qty:q, unitPrice, unitCost, total:lineTotal });
  }

  for (const item of items) {
    const p = data.find(x => x.id === item.productId);
    p.qty -= item.qty;
    p.updated = Date.now();
  }

  const grossProfit = total - cost;
  const realizedProfit = total > 0 ? (collected / total) * grossProfit : 0;
  const sale = {
    id:uid(), date:Date.now(), items, total, cost, customerPaid, collected, debt, change,
    grossProfit:Math.round(grossProfit), realizedProfit:Math.round(realizedProfit)
  };
  sales.push(sale);
  cart = {};
  purgeZeroStockProducts();
cashBalance = calculateCashFromHistory();
localStorage.setItem(CASH, String(cashBalance));
  save();
  closeModal('checkoutOverlay');
  showReceipt(sale);
  render();
};

function showReceipt(sale) {
  const items = sale.items.map(item => `<div class="receiptRow"><span>${esc(item.name)} × ${item.qty}</span><b>${money(item.total)}</b></div>`).join('');
  $('receiptContent').innerHTML = `
    <div class="receiptMeta"><span>Chek #${esc(sale.id.slice(-6).toUpperCase())}</span><span>${dateText(sale.date)}</span></div>
    <div class="receiptBlock">${items}</div>
    <div class="receiptGrand"><span>JAMI</span><strong>${money(sale.total)}</strong></div>
    <div class="receiptPair"><span>Klient berdi</span><b>${money(sale.customerPaid)}</b></div>
    <div class="receiptPair"><span>Qaytim</span><b>${money(sale.change)}</b></div>
    <div class="receiptPair"><span>Qarz</span><b>${money(sale.debt)}</b></div>
    <div class="receiptPair"><span>Foyda</span><b>${money(sale.realizedProfit)}</b></div>
    <div class="receiptThanks">Xaridingiz uchun rahmat! ✅</div>`;
  openModal('receiptOverlay');
}

function calculateCashFromHistory() {
  const salesCash = sales.reduce((sum, s) => sum + Number(s.collected ?? s.total ?? 0), 0);
  const repairCash = repairs.reduce((sum, r) => sum + Number(r.amount || 0), 0);
  const spent = expenses.reduce((sum, x) => sum + Number(x.amount || 0), 0);
  return Math.max(0, Math.round(salesCash + repairCash - spent));
}

function availableCash() {
  // Kassadagi pul vaqtga bog‘liq emas: RESET qilinmaguncha tarixdagi barcha
  // kirimlar (+) va xarajatlar (-) yig‘indisi sifatida doimiy saqlanadi.
  const stored = Number(localStorage.getItem(CASH));
  const calculated = calculateCashFromHistory();
  if (!Number.isFinite(stored) || stored < 0 || Math.round(stored) !== calculated) {
    cashBalance = calculated;
    localStorage.setItem(CASH, String(calculated));
    return calculated;
  }
  cashBalance = Math.round(stored);
  return cashBalance;
}

function dayStartOffset(days) {
  const d = new Date();
  d.setHours(0,0,0,0);
  d.setDate(d.getDate() + days);
  return d.getTime();
}

function dayIncome(offset) {
  const start = dayStartOffset(offset);
  const end = start + 86400000;
  const saleIncome = sales.reduce((sum, s) => {
    const ts = Number(s.date || 0);
    return ts >= start && ts < end ? sum + Number(s.collected ?? s.total ?? 0) : sum;
  }, 0);
  const repairIncome = repairs.reduce((sum, r) => {
    const ts = Number(r.date || 0);
    return ts >= start && ts < end ? sum + Number(r.amount || 0) : sum;
  }, 0);
  return Math.round(saleIncome + repairIncome);
}

function renderTavars() {
  const cash = availableCash();
  const total = tavars.reduce((sum, x) => sum + Number(x.qty || 0) * Number(x.unitPrice || 0), 0);
  $('availableCash').textContent = money(cash);
  $('tavarTotal').textContent = money(total);
  selectedTavars = new Set([...selectedTavars].filter(id => tavars.some(x => x.id === id)));
  $('tavarList').innerHTML = tavars.length ? tavars.map(x => {
    const line = Number(x.qty || 0) * Number(x.unitPrice || 0);
    const selected = selectedTavars.has(x.id);
    return `<div class="tavarCard ${selected ? 'selected' : ''}">
      <label class="tavarSelect"><input type="checkbox" ${selected ? 'checked' : ''} onchange="toggleTavar('${x.id}', this.checked)"><span>Tanlash</span></label>
      <div class="tavarInfo"><b>${esc(x.name)}</b><div class="muted">${x.qty} dona × ${money(x.unitPrice)}</div></div>
      <div class="tavarRight"><b>${money(line)}</b><button class="danger iconBtn" onclick="removeTavar('${x.id}')" aria-label="Tovarni o‘chirish">✕</button></div>
    </div>`;
  }).join('') : '<div class="card empty">Hozircha olinadigan tovar yo‘q.</div>';
}

function toggleTavar(id, checked) {
  if (checked) selectedTavars.add(id);
  else selectedTavars.delete(id);
  renderTavars();
}

$('tavarForm').onsubmit = e => {
  e.preventDefault();
  const name = $('tavarName').value.trim();
  const qty = Number($('tavarQty').value);
  const unitPrice = Number($('tavarPrice').value);
  if (!name || !Number.isInteger(qty) || qty < 1 || !Number.isFinite(unitPrice) || unitPrice <= 0) {
    return toast('Tovar ma’lumotlarini tekshiring');
  }
  const existing = tavars.find(x => x.name.toLocaleLowerCase() === name.toLocaleLowerCase() && Number(x.unitPrice) === unitPrice);
  if (existing) existing.qty += qty;
  else tavars.push({ id:uid(), name, qty, unitPrice:Math.round(unitPrice), date:Date.now() });
  save();
  e.target.reset();
  toast('Tovar ro‘yxatga qo‘shildi ✅');
  go('tavars');
};

function removeTavar(id) {
  if (!confirm('Bu tovarni ro‘yxatdan o‘chirasizmi?')) return;
  tavars = tavars.filter(x => x.id !== id);
  selectedTavars.delete(id);
  save();
  renderTavars();
  toast('Tovar ro‘yxatdan o‘chirildi');
}

function buyTavars() {
  let cash = availableCash();
  if (cash <= 0) return toast('Hozircha xarid qilish uchun pul yetarli emas');
  const chosen = tavars.filter(x => selectedTavars.has(x.id));
  if (!chosen.length) return toast('Avval olmoqchi bo‘lgan tovarlarni tanlang');

  const next = [];
  let boughtUnits = 0;
  let spent = 0;

  for (const item of tavars) {
    if (!selectedTavars.has(item.id)) {
      next.push(item);
      continue;
    }

    const unit = Math.max(0, Number(item.unitPrice) || 0);
    if (!unit) { next.push(item); continue; }
    const wanted = Math.max(0, Math.floor(Number(item.qty) || 0));
    const canBuy = Math.min(wanted, Math.floor(cash / unit));
    if (canBuy <= 0) { next.push(item); continue; }

    const amount = canBuy * unit;
    cash -= amount;
    spent += amount;
    boughtUnits += canBuy;

    let p = data.find(x => x.name.trim().toLocaleLowerCase() === item.name.trim().toLocaleLowerCase());
    if (p) {
      const oldQty = Number(p.qty) || 0;
      const oldCost = Number(p.avgCost ?? p.cost) || 0;
      p.avgCost = ((oldQty * oldCost) + amount) / (oldQty + canBuy);
      p.cost = Math.round(p.avgCost);
      p.qty = oldQty + canBuy;
      p.updated = Date.now();
    } else {
      const salePrice = Number(prompt(`“${item.name}” uchun sotish narxini kiriting:`) || 0);
      if (!Number.isFinite(salePrice) || salePrice <= 0) {
        cash += amount;
        spent -= amount;
        boughtUnits -= canBuy;
        next.push(item);
        continue;
      }
      data.push({ id:uid(), name:item.name, qty:canBuy, cost:Math.round(unit), avgCost:unit, price:Math.round(salePrice), created:Date.now(), updated:Date.now() });
    }

    if (canBuy < wanted) next.push({ ...item, qty:wanted - canBuy });
  }

  if (!boughtUnits) return toast('Tanlangan tovarlarga pul yetmadi');

  expenses.push({ id:uid(), amount:Math.round(spent), note:'TAVARs xaridi', date:Date.now(), type:'purchase' });
  tavars = next;
  selectedTavars.clear();
  save();
  renderTavars();
  renderProducts();
  render();
  toast(`${money(spent)} xarid qilindi ✅`);
}

$('buyTavars').onclick = buyTavars;

function renderDebts() {
  const total = debts.reduce((sum, x) => sum + Math.max(0, Number(x.amount || 0) - Number(x.paid || 0)), 0);
  $('myDebtTotal').textContent = money(total);
  $('debtList').innerHTML = debts.length ? debts.map(x => {
    const remaining = Math.max(0, Number(x.amount || 0) - Number(x.paid || 0));
    return `<div class="debtCard ${remaining === 0 ? 'paid' : ''}">
      <div><b>${esc(x.person)}</b><div class="muted">${esc(x.note || 'Qarz')} · ${dateText(x.date)}</div><div class="debtNums">Qarz: ${money(x.amount)} · Qoldi: ${money(remaining)}</div></div>
      <div class="debtActions">${remaining > 0 ? `<button class="primary small" onclick="payDebt('${x.id}')">To‘lash</button>` : ''}<button class="danger iconBtn" onclick="removeDebt('${x.id}')">✕</button></div>
    </div>`;
  }).join('') : '<div class="card empty">Hozircha qarz yo‘q.</div>';
}

$('debtForm').onsubmit = e => {
  e.preventDefault();
  const person = $('debtPerson').value.trim();
  const amount = Number($('debtAmountInput').value);
  const note = $('debtNote').value.trim();
  if (!person || !Number.isFinite(amount) || amount <= 0) return toast('Qarz ma’lumotlarini tekshiring');
  debts.push({ id:uid(), person, amount:Math.round(amount), paid:0, note, date:Date.now() });
  save();
  e.target.reset();
  renderDebts();
  toast('Qarz saqlandi 💳');
};

function payDebt(id) {
  const d = debts.find(x => x.id === id);
  if (!d) return;
  const remaining = Math.max(0, Number(d.amount || 0) - Number(d.paid || 0));
  const cash = availableCash();
  if (cash <= 0) return toast('Qarz to‘lash uchun mavjud pul yetarli emas');
  const raw = prompt(`Qancha to‘laysiz?\nQoldiq: ${money(remaining)}\nMavjud pul: ${money(cash)}`, String(Math.min(remaining, cash)));
  if (raw === null) return;
  const amount = Math.round(Number(raw));
  if (!Number.isFinite(amount) || amount <= 0 || amount > remaining || amount > cash) return toast('To‘lov summasini tekshiring');
  d.paid = Number(d.paid || 0) + amount;
  expenses.push({ id:uid(), amount, note:`Qarz to‘lovi: ${d.person}`, date:Date.now(), type:'debt' });
  save();
  renderDebts();
  render();
  toast(`${money(amount)} qarz to‘landi ✅`);
}

function removeDebt(id) {
  if (!confirm('Bu qarzni ro‘yxatdan o‘chirasizmi?')) return;
  debts = debts.filter(x => x.id !== id);
  save();
  renderDebts();
  toast('Qarz o‘chirildi');
}

function renderRepairs() {
  const total = repairs.reduce((sum, r) => sum + Number(r.amount || 0), 0);
  $('repairTotal').textContent = money(total);
  $('repairList').innerHTML = repairs.length ? [...repairs].sort((a,b) => b.date-a.date).map(r => `<div class="expenseCard">
    <div><b>${money(r.amount)}</b><div class="muted">${esc(r.note || 'Remont ishi')} · ${dateText(r.date)}</div><div class="repairProfit">100% sof foyda</div></div>
    <button class="danger iconBtn" onclick="removeRepair('${r.id}')" aria-label="Remont yozuvini o‘chirish">✕</button>
  </div>`).join('') : '<div class="card empty">Hali remont tushumi kiritilmagan.</div>';
}

$('repairForm').onsubmit = e => {
  e.preventDefault();
  const amount = Number($('repairAmount').value);
  const note = $('repairNote').value.trim();
  if (!Number.isFinite(amount) || amount <= 0) return toast('Remont summasini kiriting');
  repairs.push({ id:uid(), amount:Math.round(amount), note, date:Date.now() });
  save();
  e.target.reset();
  renderRepairs();
  render();
  toast(`${money(amount)} remont tushumi qo‘shildi ✅`);
};

function removeRepair(id) {
  if (!confirm('Bu remont yozuvini o‘chirasizmi?')) return;
  repairs = repairs.filter(r => r.id !== id);
  save();
  renderRepairs();
  render();
  toast('Remont yozuvi o‘chirildi');
}

function renderExpenses() {
  const total = expenses.reduce((sum, x) => sum + Number(x.amount || 0), 0);
  $('expenseTotal').textContent = money(total);
  const list = [...expenses].sort((a,b) => b.date - a.date);
  $('expenseList').innerHTML = list.length ? list.map(x => `<div class="expenseCard">
    <div><b>${money(x.amount)}</b><div class="muted">${esc(x.note || 'Xarajat')} · ${dateText(x.date)}</div></div>
    <button class="danger iconBtn" onclick="removeExpense('${x.id}')" aria-label="Xarajatni o‘chirish">✕</button>
  </div>`).join('') : '<div class="card empty">Hali xarajat kiritilmagan.</div>';
}

$('expenseForm').onsubmit = e => {
  e.preventDefault();
  const amount = Number($('expenseAmount').value);
  const note = $('expenseNote').value.trim();
  if (!Number.isFinite(amount) || amount <= 0) return toast('Xarajat summasini kiriting');
  expenses.push({ id:uid(), amount:Math.round(amount), note, date:Date.now() });
  save();
  e.target.reset();
  toast('Xarajat saqlandi ✅');
  renderExpenses();
  render();
};

function removeExpense(id) {
  if (!confirm('Bu xarajatni o‘chirasizmi?')) return;
  expenses = expenses.filter(x => x.id !== id);
  save();
  toast('Xarajat o‘chirildi');
  renderExpenses();
  render();
}

function removeProduct(id) {
  if (cart[id]) return toast('Avval sotuvdan olib tashlang');
  if (!confirm('Mahsulotni o‘chirasizmi? Tarixiy sotuvlar saqlanadi.')) return;
  data = data.filter(p => p.id !== id);
  save();
  render();
  toast('Mahsulot o‘chirildi');
}

function render() {
  const today = dayKey(Date.now());
  const todaySales = sales.filter(s => dayKey(s.date) === today);
  const todayRepairs = repairs.filter(r => dayKey(r.date) === today);
  const todayExpenses = expenses.filter(x => dayKey(x.date) === today);
  const revenue = todaySales.reduce((sum, s) => sum + Number(s.collected ?? s.total ?? 0), 0) + todayRepairs.reduce((sum, r) => sum + Number(r.amount || 0), 0);
  const salesProfit = todaySales.reduce((sum, s) => sum + Number(s.realizedProfit ?? s.profit ?? 0), 0);
  const repairProfit = todayRepairs.reduce((sum, r) => sum + Number(r.amount || 0), 0);
  const profit = salesProfit + repairProfit;
  const expense = todayExpenses.reduce((sum, x) => sum + Number(x.amount || 0), 0);
  const threeDayIncome = dayIncome(-1) + dayIncome(0) + dayIncome(1);

  $('stockCount').textContent = data.reduce((sum, p) => sum + Number(p.qty || 0), 0);
  $('lowCount').textContent = data.filter(p => Number(p.qty) <= 3).length;
  $('todaySales').textContent = money(revenue);
  $('rRevenue').textContent = money(revenue);
  $('rProfit').textContent = money(profit);
  $('rExpense').textContent = money(expense);
  $('rNetProfit').textContent = money(profit - expense);
  $('rProducts').textContent = data.reduce((sum, p) => sum + Number(p.qty || 0), 0).toLocaleString('uz-UZ') + ' dona';
  $('rCash').textContent = money(availableCash());
  $('rYesterday').textContent = money(dayIncome(-1));
  $('rToday').textContent = money(dayIncome(0));
  $('rTomorrow').textContent = money(dayIncome(1));

  if ($('productList')) renderProducts();
  if ($('sellList')) renderSell();
  if ($('expenseList')) renderExpenses();
  if ($('tavarList')) renderTavars();
  if ($('debtList')) renderDebts();
  if ($('repairList')) renderRepairs();
}

$('search').addEventListener('input', renderProducts);
$('printReceipt').onclick = () => window.print();

document.addEventListener('keydown', e => {
  if (e.key === 'Escape') document.querySelectorAll('.overlay.open').forEach(x => closeModal(x.id));
});

save();

setTimeout(() => {
  $('splash').style.display = 'none';
  render();
}, 800);
