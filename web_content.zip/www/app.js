(()=> {
const $=id=>document.getElementById(id), today=new Date();today.setHours(0,0,0,0);
const KEY='nen-period-tracker-v1';
let data={start:null,cycle:28,duration:5,records:[],logs:[]},month=new Date(today.getFullYear(),today.getMonth(),1),selected=new Date(today);
try{const saved=JSON.parse(localStorage.getItem(KEY)||'null');if(saved)data={...data,...saved}}catch(e){}
const fmt=d=>d.toLocaleDateString('en-GB',{day:'numeric',month:'short',year:'numeric'});
const add=(d,n)=>{let x=new Date(d);x.setDate(x.getDate()+n);return x};
const diff=(a,b)=>Math.round((a-b)/86400000);
const same=(a,b)=>a.getFullYear()===b.getFullYear()&&a.getMonth()===b.getMonth()&&a.getDate()===b.getDate();
const inputDate=d=>d?`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`:'';
const parse=s=>s?new Date(s+'T00:00:00'):null;
function save(){localStorage.setItem(KEY,JSON.stringify(data))}
function toast(s){$('toast').textContent=s;$('toast').classList.remove('hidden');setTimeout(()=>$('toast').classList.add('hidden'),2400)}
function allStarts(){return data.records.map(r=>r.start).concat(data.start?[data.start]:[]).sort((a,b)=>a-b)}
function nextPeriod(){let a=allStarts();return a.length?add(a[a.length-1],Number(data.cycle)):null}
function predicted(){let n=nextPeriod();return n?[n,add(n,data.cycle),add(n,data.cycle*2)]:[]}
function isPeriod(d){return data.records.some(r=>d>=new Date(r.start)&&d<=new Date(r.end))||(data.start&&d>=new Date(data.start)&&d<add(new Date(data.start),Number(data.duration)))}
function dayClass(d){let c='';if(isPeriod(d))c+=' period';else if(predicted().some(p=>d>=p&&d<add(p,Number(data.duration))))c+=' predicted';else if(nextPeriod()&&same(d,add(nextPeriod(),-14)))c+=' ovulation';if(same(d,today))c+=' today';if(same(d,selected))c+=' selected';return c}
function renderMini(){let first=new Date(today.getFullYear(),today.getMonth(),1),off=first.getDay(),count=new Date(today.getFullYear(),today.getMonth()+1,0).getDate(),h='<div class="week">'+['S','M','T','W','T','F','S'].map(x=>'<span>'+x+'</span>').join('')+'</div><div class="days">';for(let i=0;i<off;i++)h+='<span></span>';for(let n=1;n<=count;n++){let d=new Date(first.getFullYear(),first.getMonth(),n);h+=`<span class="day${dayClass(d)}">${n}</span>`}$('miniCalendar').innerHTML=h+'</div>'}
function renderCalendar(){let y=month.getFullYear(),m=month.getMonth(),off=new Date(y,m,1).getDay(),count=new Date(y,m+1,0).getDate();$('monthTitle').textContent=month.toLocaleDateString('en-GB',{month:'long',year:'numeric'});let h='';for(let i=0;i<off;i++)h+='<span></span>';for(let n=1;n<=count;n++){let d=new Date(y,m,n);h+=`<button class="day${dayClass(d)}" data-day="${n}">${n}</button>`}$('fullCalendar').innerHTML=h;$('fullCalendar').querySelectorAll('[data-day]').forEach(b=>b.addEventListener('click',()=>{selected=new Date(y,m,+b.dataset.day);$('selectedDate').textContent=fmt(selected)+(isPeriod(selected)?' · Period recorded':predicted().some(p=>selected>=p&&selected<add(p,Number(data.duration)))?' · Predicted period':'');renderCalendar()}));$('selectedDate').textContent=fmt(selected)+(isPeriod(selected)?' · Period recorded':'')}
function renderHome(){$('todayLabel').textContent=today.toLocaleDateString('en-GB',{weekday:'long',day:'numeric',month:'long'});$('setupPrompt').classList.toggle('hidden',!!data.start);$('summary').classList.toggle('hidden',!data.start);if(data.start){let next=nextPeriod(),left=diff(next,today),day=((diff(today,new Date(data.start))%data.cycle)+data.cycle)%data.cycle+1;$('daysLeft').textContent=Math.max(0,left);$('nextDate').textContent='Estimated date: '+fmt(next);$('cycleDay').textContent=day;$('cycleLengthLabel').textContent=data.cycle+' day cycle';$('progress').style.width=Math.min(100,day/data.cycle*100)+'%';$('durationMetric').textContent=data.duration;$('ovulationDate').textContent=fmt(add(next,-14))}renderMini()}
function renderInsights(){$('insCycle').textContent=data.cycle;$('insPeriod').textContent=data.duration;$('history').innerHTML=data.records.length?data.records.slice().sort((a,b)=>b.start.localeCompare(a.start)).map(r=>`<div style="padding:9px 0;border-bottom:1px solid #f5e3ed"><b>${fmt(new Date(r.start))}</b> – ${fmt(new Date(r.end))}</div>`).join(''):'No period records yet.'}
function show(id){document.querySelectorAll('main section').forEach(s=>s.classList.add('hidden'));$(id).classList.remove('hidden');document.querySelectorAll('.nav [data-tab]').forEach(b=>b.classList.toggle('active',b.dataset.tab===id));if(id==='calendar')renderCalendar();if(id==='home')renderHome();if(id==='insights')renderInsights();if(id==='settings'){$('lastDate').value=data.start||'';$('cycleInput').value=data.cycle;$('durationInput').value=data.duration}}
document.querySelectorAll('[data-go]').forEach(b=>b.addEventListener('click',()=>show(b.dataset.go)));
document.querySelectorAll('.nav [data-tab]').forEach(b=>b.addEventListener('click',()=>show(b.dataset.tab)));
$('settingsShortcut').onclick=()=>show('settings');
$('prevMonth').onclick=()=>{month=new Date(month.getFullYear(),month.getMonth()-1,1);renderCalendar()};
$('nextMonth').onclick=()=>{month=new Date(month.getFullYear(),month.getMonth()+1,1);renderCalendar()};
$('saveSettings').onclick=()=>{let d=parse($('lastDate').value),c=+$('cycleInput').value,p=+$('durationInput').value;if(!d||c<15||c>60||p<1||p>15||p>c){toast('Please enter valid cycle details.');return}data.start=inputDate(d);data.cycle=c;data.duration=p;save();renderHome();toast('Cycle settings saved 🌸');show('home')};
$('savePeriod').onclick=()=>{let s=parse($('periodStart').value),e=parse($('periodEnd').value);if(!s||e&&e<s){toast('Please check your period dates.');return}if(!e)e=add(s,Number(data.duration)-1);data.records.push({start:inputDate(s),end:inputDate(e)});data.records.sort((a,b)=>a.start.localeCompare(b.start));data.start=inputDate(s);save();renderHome();renderInsights();$('logMessage').textContent='Period record saved successfully 💗';toast('Period record saved!')};
document.querySelectorAll('.sym').forEach(b=>b.onclick=()=>b.classList.toggle('selected'));
$('saveLog').onclick=()=>{let symptoms=[...document.querySelectorAll('.sym.selected')].map(x=>x.innerText.replace(/\n/g,' '));data.logs.push({date:inputDate(today),symptoms,flow:$('flow').value,notes:$('notes').value});save();$('logMessage').textContent='Daily log saved successfully 💗';toast('Daily log saved!')};
$('reset').onclick=()=>{if(confirm('Reset all your cycle information and logs?')){data={start:null,cycle:28,duration:5,records:[],logs:[]};save();renderHome();renderInsights();toast('App data reset.')}};
if(data.start)$('lastDate').value=data.start;
renderHome();renderInsights();
})();