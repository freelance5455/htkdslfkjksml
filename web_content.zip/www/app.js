(() => {
  const $ = id => document.getElementById(id);
  const canvas = $('designCanvas'), ctx = canvas.getContext('2d');
  const state = {
    format:'square', bg1:'#111827', bg2:'#4338ca', gradient:true, transparent:false,
    layers:[], selected:0, history:[], dragging:false, dragOffset:{x:0,y:0}
  };
  const sizes = {square:[1080,1080],portrait:[1080,1350],story:[1080,1920],landscape:[1200,630]};
  const makeLayer = (text, y, size=76) => ({text,x:540,y,font:'Arial',size,color:'#ffffff',outline:'#111827',bold:true,italic:false,outlineOn:true,shadowOn:true,align:'center',lineSpacing:1.15});
  state.layers = [makeLayer('Your amazing idea\nstarts here',540,82)];
  state.history.push(JSON.stringify(state.layers));
  const selected = () => state.layers[state.selected];
  const setStatus = t => $('status').textContent = t;
  const esc = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  function saveHistory(){state.history.push(JSON.stringify(state.layers));if(state.history.length>40)state.history.shift();}
  function drawBackground(){
    if(state.transparent)return;
    if(state.gradient){const g=ctx.createLinearGradient(0,0,canvas.width,canvas.height);g.addColorStop(0,state.bg1);g.addColorStop(1,state.bg2);ctx.fillStyle=g;}
    else ctx.fillStyle=state.bg1;
    ctx.fillRect(0,0,canvas.width,canvas.height);
    // Subtle decorative glows
    if(!state.transparent){const g=ctx.createRadialGradient(canvas.width*.8,canvas.height*.12,0,canvas.width*.8,canvas.height*.12,canvas.width*.6);g.addColorStop(0,'#ffffff10');g.addColorStop(1,'#ffffff00');ctx.fillStyle=g;ctx.fillRect(0,0,canvas.width,canvas.height);}
  }
  function wrapLines(text, maxWidth, font){
    ctx.font=font; const out=[];
    text.split('\n').forEach(paragraph=>{
      if(paragraph===''){out.push('');return;}
      let line='';
      paragraph.split(/\s+/).forEach(word=>{
        const test=line?line+' '+word:word;
        if(line && ctx.measureText(test).width>maxWidth){out.push(line);line=word;}else line=test;
      });
      out.push(line);
    });
    return out;
  }
  function layerMetrics(layer){
    const weight=layer.bold?'700':'400', style=layer.italic?'italic ':'';
    const font=`${style}${weight} ${layer.size}px "${layer.font}"`;
    const lines=wrapLines(layer.text||' ',canvas.width*.84,font);
    return {font,lines,lineH:layer.size*layer.lineSpacing, totalH:layer.size*layer.lineSpacing*lines.length};
  }
  function drawLayer(layer,index){
    const m=layerMetrics(layer);ctx.save();ctx.font=m.font;ctx.textAlign=layer.align;ctx.textBaseline='middle';
    ctx.lineJoin='round';ctx.lineWidth=Math.max(3,layer.size*.075);
    ctx.shadowColor=layer.shadowOn?'#000b':'transparent';ctx.shadowBlur=layer.shadowOn?layer.size*.18:0;ctx.shadowOffsetX=layer.shadowOn?3:0;ctx.shadowOffsetY=layer.shadowOn?5:0;
    const startY=layer.y-m.totalH/2+m.lineH/2;
    m.lines.forEach((line,i)=>{const y=startY+i*m.lineH;if(layer.outlineOn){ctx.strokeStyle=layer.outline;ctx.strokeText(line,layer.x,y,canvas.width*.88);}ctx.fillStyle=layer.color;ctx.fillText(line,layer.x,y,canvas.width*.88);});
    if(index===state.selected){ctx.shadowColor='transparent';ctx.shadowBlur=0;ctx.shadowOffsetX=0;ctx.shadowOffsetY=0;ctx.strokeStyle='#a78bfa';ctx.lineWidth=3;ctx.setLineDash([12,9]);ctx.strokeRect(22,Math.max(22,startY-m.lineH*.65),canvas.width-44,Math.min(canvas.height-44,m.totalH+m.lineH*.3));}
    ctx.restore();
  }
  function render(){ctx.clearRect(0,0,canvas.width,canvas.height);drawBackground();state.layers.forEach(drawLayer);renderLayerList();syncControls();}
  function renderLayerList(){
    const root=$('layerList');root.innerHTML='';
    state.layers.forEach((l,i)=>{const b=document.createElement('button');b.className='layer-chip'+(i===state.selected?' active':'');b.textContent=(l.text||'Empty text').replace(/\n/g,' / ').slice(0,27);b.title=l.text;b.onclick=()=>{state.selected=i;render();};root.appendChild(b);});
  }
  function syncControls(){
    const l=selected();if(!l)return;
    $('textInput').value=l.text;$('fontSelect').value=l.font;$('fontSize').value=l.size;$('fontSizeVal').textContent=l.size;
    $('textColor').value=l.color;$('outlineColor').value=l.outline;$('boldBtn').classList.toggle('active',l.bold);$('italicBtn').classList.toggle('active',l.italic);
    $('outlineBtn').classList.toggle('active',l.outlineOn);$('shadowBtn').classList.toggle('active',l.shadowOn);
    document.querySelectorAll('.alignBtn').forEach(b=>b.classList.toggle('active',b.dataset.align===l.align));
    $('lineSpacing').value=l.lineSpacing;$('lineSpacingVal').textContent=Number(l.lineSpacing).toFixed(2)+'×';
    $('textX').value=Math.round(l.x/canvas.width*100);$('textXVal').textContent=$('textX').value+'%';
    $('textY').value=Math.round(l.y/canvas.height*100);$('textYVal').textContent=$('textY').value+'%';
  }
  function resizeCanvas(){const [w,h]=sizes[state.format];canvas.width=w;canvas.height=h;$('sizeLabel').textContent=`${w} × ${h}`;state.layers.forEach(l=>{l.x=Math.min(w-40,Math.max(40,l.x));l.y=Math.min(h-40,Math.max(40,l.y));});render();}
  function update(prop,value){const l=selected();if(!l)return;saveHistory();l[prop]=value;render();}
  $('formatSelect').addEventListener('change',e=>{state.format=e.target.value;resizeCanvas();});
  $('bgColor').addEventListener('input',e=>{state.bg1=e.target.value;render();});
  $('bgColor2').addEventListener('input',e=>{state.bg2=e.target.value;render();});
  $('gradientToggle').addEventListener('change',e=>{state.gradient=e.target.checked;render();});
  $('transparentToggle').addEventListener('change',e=>{state.transparent=e.target.checked;render();});
  document.querySelectorAll('.swatch').forEach(b=>{const a=b.dataset.a,c=b.dataset.b;b.style.setProperty('--a',a);b.style.setProperty('--b',c);b.onclick=()=>{state.bg1=a;state.bg2=c;$('bgColor').value=a;$('bgColor2').value=c;$('gradientToggle').checked=true;state.gradient=true;render();};});
  $('textInput').addEventListener('input',e=>{selected().text=e.target.value;renderLayerList();render();});
  $('textInput').addEventListener('change',saveHistory);
  $('fontSelect').addEventListener('change',e=>update('font',e.target.value));
  $('fontSize').addEventListener('input',e=>{selected().size=+e.target.value;$('fontSizeVal').textContent=e.target.value;render();});
  $('fontSize').addEventListener('change',saveHistory);
  $('textColor').addEventListener('input',e=>{selected().color=e.target.value;render();});
  $('outlineColor').addEventListener('input',e=>{selected().outline=e.target.value;render();});
  $('boldBtn').onclick=()=>update('bold',!selected().bold);
  $('italicBtn').onclick=()=>update('italic',!selected().italic);
  $('outlineBtn').onclick=()=>update('outlineOn',!selected().outlineOn);
  $('shadowBtn').onclick=()=>update('shadowOn',!selected().shadowOn);
  document.querySelectorAll('.alignBtn').forEach(b=>b.onclick=()=>update('align',b.dataset.align));
  $('lineSpacing').addEventListener('input',e=>{selected().lineSpacing=+e.target.value;$('lineSpacingVal').textContent=(+e.target.value).toFixed(2)+'×';render();});
  $('lineSpacing').addEventListener('change',saveHistory);
  $('textX').addEventListener('input',e=>{selected().x=canvas.width*(+e.target.value/100);$('textXVal').textContent=e.target.value+'%';render();});
  $('textY').addEventListener('input',e=>{selected().y=canvas.height*(+e.target.value/100);$('textYVal').textContent=e.target.value+'%';render();});
  ['textX','textY'].forEach(id=>$(id).addEventListener('change',saveHistory));
  $('addTextBtn').onclick=()=>{saveHistory();state.layers.push(makeLayer('New text',canvas.height/2,64));state.selected=state.layers.length-1;render();$('textInput').focus();$('textInput').select();setStatus('New text layer added.');};
  $('deleteBtn').onclick=()=>{if(!state.layers.length)return;saveHistory();state.layers.splice(state.selected,1);if(!state.layers.length)state.layers.push(makeLayer('',canvas.height/2,60));state.selected=Math.max(0,Math.min(state.selected,state.layers.length-1));render();setStatus('Selected layer deleted.');};
  $('undoBtn').onclick=()=>{if(state.history.length>1){state.history.pop();state.layers=JSON.parse(state.history[state.history.length-1]);state.selected=Math.min(state.selected,state.layers.length-1);render();setStatus('Last change undone.');}else setStatus('Nothing to undo yet.');};
  function downloadPNG(){render();canvas.toBlob(blob=>{if(!blob){setStatus('Could not export image. Please try again.');return;}const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`text-design-${state.format}.png`;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);setStatus('PNG saved. On Android, check Downloads or choose Save if prompted.');},'image/png');}
  $('saveBtn').onclick=downloadPNG;$('saveBtnBottom').onclick=downloadPNG;
  $('resetBtn').onclick=()=>{if(!confirm('Reset the current design?'))return;state.format='square';state.bg1='#111827';state.bg2='#4338ca';state.gradient=true;state.transparent=false;state.layers=[makeLayer('Your amazing idea\nstarts here',540,82)];state.selected=0;state.history=[JSON.stringify(state.layers)];$('formatSelect').value='square';$('bgColor').value=state.bg1;$('bgColor2').value=state.bg2;$('gradientToggle').checked=true;$('transparentToggle').checked=false;resizeCanvas();setStatus('Design reset.');};
  function pointerPos(e){const r=canvas.getBoundingClientRect();return{x:(e.clientX-r.left)*canvas.width/r.width,y:(e.clientY-r.top)*canvas.height/r.height};}
  canvas.addEventListener('pointerdown',e=>{const p=pointerPos(e);let best=-1,bestDist=Infinity;state.layers.forEach((l,i)=>{const m=layerMetrics(l);const d=Math.hypot(p.x-l.x,(p.y-l.y)/(canvas.height/canvas.width));if(d<bestDist){bestDist=d;best=i;}});if(best>=0){state.selected=best;const l=selected();state.dragging=true;state.dragOffset={x:p.x-l.x,y:p.y-l.y};canvas.setPointerCapture(e.pointerId);render();}});
  canvas.addEventListener('pointermove',e=>{if(!state.dragging)return;const p=pointerPos(e),l=selected();l.x=Math.max(20,Math.min(canvas.width-20,p.x-state.dragOffset.x));l.y=Math.max(20,Math.min(canvas.height-20,p.y-state.dragOffset.y));render();});
  canvas.addEventListener('pointerup',()=>{if(state.dragging){state.dragging=false;saveHistory();setStatus('Text position updated.');}});
  canvas.addEventListener('pointercancel',()=>state.dragging=false);
  // Prevent default form submission and render initial design.
  resizeCanvas();setStatus('Ready. Add, style, drag and save your post.');
})();