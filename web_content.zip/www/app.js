// The app uses bundled local HTML pages. No feature button redirects to the hosted website.
(function(){
 document.addEventListener('click',e=>{const a=e.target.closest('a');if(!a)return;const href=a.getAttribute('href');if(!href)return;if(/^https?:/i.test(href)&&/shafiislam834-maker\.github\.io|df\.gt\.tc/i.test(href)){e.preventDefault();location.href='index.html';}});
 const current=(location.pathname.split('/').pop()||'index.html').toLowerCase();
 document.querySelectorAll('.bottom a').forEach(a=>{const href=(a.getAttribute('href')||'').split('#')[0].toLowerCase();if(href===current){a.classList.add('active');a.setAttribute('aria-current','page')}else{a.classList.remove('active');a.removeAttribute('aria-current')}});
 // Restore normal document scrolling if an older style left the WebView in a locked state.
 document.documentElement.style.setProperty('overflow-y','auto','important');
 document.documentElement.style.setProperty('height','auto','important');
 document.body.style.setProperty('height','auto','important');
 document.body.style.setProperty('max-height','none','important');
 document.body.style.setProperty('overflow-y','visible','important');
 if(location.hash==='#membership'){requestAnimationFrame(()=>document.getElementById('membership')?.scrollIntoView({block:'start'}));}
})();
