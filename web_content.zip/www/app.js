const KEY="kz_tarefa_v1";
const TASKS=[
 {id:"t1",title:"Anúncio de demonstração",desc:"Veja a tarefa e confirme a conclusão.",reward:50},
 {id:"t2",title:"Pesquisa rápida",desc:"Responda a uma pergunta de teste.",reward:75},
 {id:"t3",title:"Visita promocional",desc:"Abra a tarefa e leia as informações.",reward:100},
 {id:"t4",title:"Tarefa especial",desc:"Confirme que leu os termos da tarefa.",reward:125}
];
let state=JSON.parse(localStorage.getItem(KEY)||"null");

const $=id=>document.getElementById(id);
function save(){localStorage.setItem(KEY,JSON.stringify(state))}
function money(n){return new Intl.NumberFormat("pt-AO").format(n)+" Kz"}
function render(){
 if(!state){$("auth").classList.remove("hidden");$("app").classList.add("hidden");$("logoutBtn").classList.add("hidden");return}
 $("auth").classList.add("hidden");$("app").classList.remove("hidden");$("logoutBtn").classList.remove("hidden");
 $("balance").textContent=money(state.balance);
 $("profileData").innerHTML=`<p><b>Nome:</b> ${esc(state.name)}</p><p><b>E-mail:</b> ${esc(state.email)}</p><p><b>Telefone:</b> ${esc(state.phone)}</p>`;
 renderTasks(); renderHistory();
}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function renderTasks(){
 $("taskList").innerHTML=TASKS.map(t=>{
  const done=state.completed.includes(t.id);
  return `<article class="task"><div><h3>${esc(t.title)}</h3><div class="small">${esc(t.desc)}</div></div><div><div class="reward">+${money(t.reward)}</div><button ${done?"disabled":""} onclick="completeTask('${t.id}')">${done?"Concluída":"Concluir"}</button></div></article>`
 }).join("");
}
window.completeTask=id=>{
 const t=TASKS.find(x=>x.id===id); if(!t||state.completed.includes(id))return;
 state.completed.push(id);state.balance+=t.reward;
 state.history.unshift({date:new Date().toLocaleString("pt-AO"),type:"Tarefa",value:t.reward,note:t.title});
 save();render();
}
function renderHistory(){
 $("historyList").innerHTML=state.history.length?state.history.map(x=>`<div class="card"><b>${esc(x.type)}</b><br>${esc(x.note||"")}<br><span class="small">${esc(x.date)}</span><br><b>${x.value>=0?"+":""}${money(x.value)}</b></div>`).join(""):"<p class='small'>Ainda não há movimentos.</p>";
}
$("registerBtn").onclick=()=>{
 const name=$("name").value.trim(),email=$("email").value.trim(),phone=$("phone").value.trim();
 if(!name||!email||!phone)return alert("Preencha nome, e-mail e telefone.");
 state={name,email,phone,balance:0,completed:[],history:[]};save();render();
};
$("logoutBtn").onclick=()=>{state=null;localStorage.removeItem(KEY);render()};
$("withdrawBtn").onclick=()=>{
 const amount=Number($("withdrawAmount").value),account=$("account").value.trim(),method=$("method").value;
 if(!amount||amount<=0||!account)return $("withdrawMsg").textContent="Preencha o valor e os dados de pagamento.";
 if(amount>state.balance)return $("withdrawMsg").textContent="Saldo insuficiente.";
 state.balance-=amount;state.history.unshift({date:new Date().toLocaleString("pt-AO"),type:"Levantamento",value:-amount,note:`${method} — ${account}`});
 save();$("withdrawMsg").textContent="Pedido registado localmente. Para pagamento real, conecte um backend/provedor de pagamentos.";render();
};
document.querySelectorAll("nav button").forEach(b=>b.onclick=()=>{
 document.querySelectorAll(".page").forEach(p=>p.classList.add("hidden"));
 $(b.dataset.page).classList.remove("hidden");
});
render();