const $=s=>document.querySelector(s),$$=s=>document.querySelectorAll(s);
const N=s=>String(s??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const fd=s=>s?s.split('-').reverse().join('/'):'—';
// Nomes amigáveis dos códigos. Se algum nome estiver diferente na sua empresa, é só editar aqui.
const AREA={PRD:'Produção',UTL:'Utilidades',EXT:'Extração',LOG:'Logística',MAN:'Manutenção',QUI:'Qualidade',QUA:'Qualidade',ADM:'Administração'};
const CENTRO={IM_ENCAN:'Caldeiraria',IM_MECAN:'Mecânica',IM_ELETR:'Elétrica',IM_INSTR:'Instrumentação',IA_CIVIL:'Civil',TERC_CIV:'Civil (terceiro)',IM_IMBIL:'Imbil',IM_REVOL:'Revoltis',IM_REFRI:'ETS',IM_TERCE:'Terceiros',IU_OPERA:'Operação Utilidades',IP_OPERA:'Operação Produção',IE_OPERA:'Operação Extração',IL_OPERA:'Operação Logística',IQ_ANALI:'Qualidade (análises)'};
const SEL={area:'fArea',centro:'fCentro'};
const FS=[['fArea','area'],['fCentro','centro'],['fCor','cor'],['fPrio','prio'],['fStatus','status'],['fSetor','setor'],['fQuando','quando']];
const LAB={nota:'Nota (controle)',ordem:'Ordem',cor:'Tipo',prio:'Prioridade',status:'Status',area:'Área',centro:'Centro de trabalho',setor:'Setor',equip:'Equipamento',local:'Local de instalação',desc:'Descrição',quando:'Quando executar',notif:'Notificado por',data:'Data de registro',prazo:'Prazo programado',resp:'Responsável',risco:'Risco de lesão',imed:'Providência imediata',def:'Providência definitiva',coment:'Comentários'};
let D=[],lim=60,cald=false,P=[];
try{P=JSON.parse(localStorage.getItem('prog'))||[]}catch(e){}
const savP=()=>{try{localStorage.setItem('prog',JSON.stringify(P))}catch(e){alert('Sem espaço para salvar a programação.')}};
const inP=n=>P.some(p=>p.nota===n),cntP=()=>$('#np').textContent=P.filter(p=>!p.done).length;

function fill(id,k,M={}){
  const lb=x=>x==='—'?'(vazio)':M[x]?M[x]+' ('+x+')':x;
  const v=[...new Set(D.map(o=>o[k]||'—'))].sort((a,b)=>lb(a).localeCompare(lb(b),'pt'));
  $('#'+id).innerHTML='<option value="">Todos</option>'+v.map(x=>`<option value="${esc(x)}">${esc(lb(x))}</option>`).join('');
}
function start(d){
  D=d.rows.map(r=>{
    const o={};d.cols.forEach((c,i)=>o[c]=r[i]);
    const n=(...k)=>N(k.map(x=>o[x]).join(' '));
    o._n={desc:n('desc'),equip:n('equip'),nota:n('nota','ordem'),notif:n('notif'),local:n('local')};
    o._n.all=n('nota','ordem','desc','equip','local','setor','notif','area','centro','resp','coment','quando','status')+' '+N((AREA[o.area]||'')+' '+(CENTRO[o.centro]||''));
    o._c=n('equip','desc','setor');
    return o;
  });
  fill('fArea','area',AREA);fill('fCentro','centro',CENTRO);fill('fPrio','prio');fill('fStatus','status');fill('fSetor','setor');fill('fQuando','quando');
  $('#info').textContent=(d.atualizado?'Atualizado até '+fd(d.atualizado)+' · ':'')+D.length+' etiquetas';
  lim=60;render();
}
function card(o){
  const det=Object.keys(LAB).map(k=>{
    let v=o[k];if(!v)return'';
    v=k==='area'?(AREA[v]||v)+' ('+v+')':k==='centro'?(CENTRO[v]||v)+' ('+v+')':(k==='data'||k==='prazo')?fd(v):k==='cor'?(v==='AZUL'?'Azul':'Vermelha'):v;
    return `<dt>${LAB[k]}</dt><dd>${esc(v)}</dd>`;
  }).join('');
  return `<details class="c ${o.cor==='AZUL'?'azul':''}"><summary><div class="r1"><b>${esc(o.nota)}</b><span>${o.cor==='AZUL'?'Azul':'Vermelha'}</span>${o.prio?`<span>${esc(o.prio)}</span>`:''}${o.status?`<span class="s">${esc(o.status)}</span>`:''}</div><div class="d">${esc(o.desc)}</div><div class="m">${esc(o.equip)}</div><div class="m">${esc(AREA[o.area]||o.area)} · ${esc(CENTRO[o.centro]||o.centro)} · ${fd(o.data)}${o.notif?' · '+esc(o.notif):''}</div><label class="ck"><input type="checkbox" class="sel" data-n="${esc(o.nota)}" ${inP(o.nota)?'checked':''}> Programar para resolver</label></summary><dl>${det}</dl></details>`;
}
function render(){
  const w=N($('#q').value).split(/\s+/).filter(Boolean),sc=$('#scope').value,d1=$('#d1').value,d2=$('#d2').value,rk=$('#fRisco').value;
  const fv=FS.map(([id,k])=>[k,$('#'+id).value]).filter(x=>x[1]);
  const L=D.filter(o=>fv.every(([k,v])=>(o[k]||'—')===v)&&(!rk||N(o.risco)===rk)&&(!d1||(o.data||'')>=d1)&&(!d2||(o.data&&o.data<=d2))&&(!cald||/caldeira|cald\./.test(o._c))&&w.every(x=>o._n[sc].includes(x)));
  const s=$('#ord').value;
  L.sort(s==='nota'?(a,b)=>a.nota-b.nota:s==='ant'?(a,b)=>(a.data||'').localeCompare(b.data||''):(a,b)=>(b.data||'').localeCompare(a.data||''));
  $('#cnt').textContent=L.length+' de '+D.length+' etiquetas';
  $('#list').innerHTML=L.slice(0,lim).map(card).join('')||'<p class="vz">Nenhuma etiqueta encontrada.</p>';
  $('#more').hidden=L.length<=lim;
  $$('.chips [data-k]').forEach(b=>{const k=b.dataset.k,[f,v]=k.split(':');b.classList.toggle('on',k==='cald'?cald:$('#'+SEL[f]).value===v)});
}
$$('header input:not([type=file]),header select').forEach(e=>e.addEventListener('input',()=>{lim=60;render()}));
$$('.chips [data-k]').forEach(b=>b.onclick=()=>{
  const k=b.dataset.k;
  if(k==='cald')cald=!cald;else{const[f,v]=k.split(':'),s=$('#'+SEL[f]);s.value=s.value===v?'':v}
  lim=60;render();
});
$('#clr').onclick=()=>{$$('header select').forEach(s=>s.selectedIndex=0);$('#q').value=$('#d1').value=$('#d2').value='';cald=false;lim=60;render()};
$('#more').onclick=()=>{lim+=60;render()};
$('#impb').onclick=()=>$('#imp').click();
$('#imp').onchange=async e=>{
  const f=e.target.files[0];if(!f)return;
  $('#info').textContent='Lendo planilha…';
  try{
    if(typeof DecompressionStream==='undefined')throw new Error('Este navegador é antigo demais para importar. Atualize o Chrome e o Android System WebView.');
    const buf=await new Promise((ok,no)=>{const r=new FileReader();r.onload=()=>ok(r.result);r.onerror=()=>no(new Error('Não consegui abrir o arquivo.'));r.readAsArrayBuffer(f)});
    const d=await lerExcel(buf);
    try{localStorage.setItem('anom',JSON.stringify(d))}catch(_){}
    start(d);
  }catch(er){start(cur);$('#info').textContent='Erro ao importar: '+er.message;alert(er.message)}
  e.target.value='';
};
let cur=window.DADOS||{cols:[],rows:[]};
try{const s=JSON.parse(localStorage.getItem('anom'));if(s&&s.rows&&(s.atualizado||'')>(cur.atualizado||''))cur=s}catch(e){}
start(cur);

// ---- Programação ----
$('#list').addEventListener('change',e=>{
  const c=e.target.closest('.sel');if(!c)return;const n=c.dataset.n;
  if(c.checked){const o=D.find(x=>x.nota===n);if(o&&!inP(n))P.push({nota:n,add:new Date().toISOString().slice(0,10),done:false,snap:{desc:o.desc,equip:o.equip,area:o.area,centro:o.centro,cor:o.cor,prio:o.prio,notif:o.notif,data:o.data}})}
  else P=P.filter(p=>p.nota!==n);
  savP();cntP();
});
function renderP(){
  const f=$('#pf').value,L=P.filter(p=>f==='todas'||(f==='conc')===p.done).reverse();
  $('#pcnt').textContent=L.length+' etiqueta(s) · '+P.filter(p=>!p.done).length+' pendente(s) · '+P.filter(p=>p.done).length+' concluída(s)';
  $('#plist').innerHTML=L.map(p=>{
    const o=Object.assign({nota:p.nota},p.snap,D.find(x=>x.nota===p.nota)||{}),n=esc(p.nota);
    return `<div class="c ${o.cor==='AZUL'?'azul':''} ${p.done?'ok':''}"><div class="r1"><b>${n}</b><span>${o.cor==='AZUL'?'Azul':'Vermelha'}</span>${o.prio?`<span>${esc(o.prio)}</span>`:''}<span class="${p.done?'g':''}">${p.done?'Concluída em '+fd(p.doneAt):'Programada em '+fd(p.add)}</span></div><div class="d">${esc(o.desc)}</div><div class="m">${esc(o.equip)}</div><div class="m">${esc(AREA[o.area]||o.area)} · ${esc(CENTRO[o.centro]||o.centro)} · ${fd(o.data)}${o.notif?' · '+esc(o.notif):''}</div><div class="acts"><button class="btn" data-a="done" data-n="${n}">${p.done?'Reabrir':'Marcar concluída'}</button><button class="btn" data-a="del" data-n="${n}">Remover</button></div></div>`}).join('')||'<p class="vz">Nenhuma etiqueta nesta lista. Marque "Programar para resolver" na aba Etiquetas.</p>';
}
$('#plist').addEventListener('click',e=>{
  const b=e.target.closest('[data-a]');if(!b)return;const p=P.find(x=>x.nota===b.dataset.n);if(!p)return;
  if(b.dataset.a==='del'){if(!confirm('Remover a etiqueta '+p.nota+' da programação?'))return;P=P.filter(x=>x!==p)}
  else{p.done=!p.done;p.doneAt=p.done?new Date().toISOString().slice(0,10):null}
  savP();cntP();renderP();
});
$('#pf').onchange=renderP;
$('#pclr').onclick=()=>{if(!P.some(p=>p.done)||!confirm('Remover todas as etiquetas concluídas da programação?'))return;P=P.filter(p=>!p.done);savP();cntP();renderP()};
function aba(n){
  $('#t1').classList.toggle('on',n===1);$('#t2').classList.toggle('on',n===2);
  $('#busca').hidden=n!==1;$('#vb').hidden=n!==1;$('#vp').hidden=n!==2;
  n===1?render():renderP();
}
$('#t1').onclick=()=>aba(1);$('#t2').onclick=()=>aba(2);cntP();
