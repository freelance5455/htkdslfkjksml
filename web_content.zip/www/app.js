const $ = id => document.getElementById(id);

const FIXED_ORG_NAME = "متوسطة محمد الصديق بن يحي";
const FIXED_DIRECTOR_NAME = "بن طاطا موسى";

let me = JSON.parse(localStorage.getItem("vr_standalone_user") || "null");
let orgName = FIXED_ORG_NAME;
let directorName = FIXED_DIRECTOR_NAME;
let offices = [];
let visits = [];
let users = [];
let dbx;

const DEFAULT_OFFICES = [
  "مكتب المدير",
  "الأمانة",
  "مكتب الناظر",
  "مكتب المستشار",
  "مكتب المقتصد",
  "مصلحة أخرى"
];

function sha256Hex(ascii) {
  function rightRotate(value, amount) {
    return (value >>> amount) | (value << (32 - amount));
  }
  const maxWord = Math.pow(2, 32);
  let result = "";
  const words = [];
  const utf8 = unescape(encodeURIComponent(ascii));
  const asciiBitLength = utf8.length * 8;
  const hash = [];
  const k = [];
  let primeCounter = 0;
  const isComposite = {};
  for (let candidate = 2; primeCounter < 64; candidate++) {
    if (!isComposite[candidate]) {
      for (let i = 0; i < 313; i += candidate) isComposite[i] = candidate;
      hash[primeCounter] = (Math.pow(candidate, 0.5) * maxWord) | 0;
      k[primeCounter++] = (Math.pow(candidate, 1 / 3) * maxWord) | 0;
    }
  }
  let padded = utf8 + "\x80";
  while ((padded.length % 64) - 56) padded += "\x00";
  for (let i = 0; i < padded.length; i++) {
    const j = padded.charCodeAt(i);
    words[i >> 2] |= j << (((3 - i) % 4) * 8);
  }
  words[words.length] = (asciiBitLength / maxWord) | 0;
  words[words.length] = asciiBitLength;

  for (let j = 0; j < words.length;) {
    const w = words.slice(j, (j += 16));
    const oldHash = hash.slice(0);
    for (let i = 0; i < 64; i++) {
      const w15 = w[i - 15], w2 = w[i - 2];
      const a = hash[0], e = hash[4];
      const temp1 = hash[7]
        + (rightRotate(e, 6) ^ rightRotate(e, 11) ^ rightRotate(e, 25))
        + ((e & hash[5]) ^ (~e & hash[6]))
        + k[i]
        + (w[i] = (i < 16) ? w[i] : (
          w[i - 16]
          + (rightRotate(w15, 7) ^ rightRotate(w15, 18) ^ (w15 >>> 3))
          + w[i - 7]
          + (rightRotate(w2, 17) ^ rightRotate(w2, 19) ^ (w2 >>> 10))
        ) | 0);
      const temp2 = (rightRotate(a, 2) ^ rightRotate(a, 13) ^ rightRotate(a, 22))
        + ((a & hash[1]) ^ (a & hash[2]) ^ (hash[1] & hash[2]));
      hash.unshift((temp1 + temp2) | 0);
      hash[4] = (hash[4] + temp1) | 0;
      hash.pop();
    }
    for (let i = 0; i < 8; i++) hash[i] = (hash[i] + oldHash[i]) | 0;
  }
  for (let i = 0; i < 8; i++) {
    for (let j = 3; j + 1; j--) {
      const b = (hash[i] >> (j * 8)) & 255;
      result += ((b < 16) ? "0" : "") + b.toString(16);
    }
  }
  return result;
}

function makeId(prefix = "id") {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return crypto.randomUUID();
  }
  return prefix + "-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 10);
}

function hashPassword(password, salt) {
  const s = salt || makeId("salt");
  return s + "$" + sha256Hex(s + ":" + password);
}

function verifyPassword(password, stored) {
  if (!stored || !stored.includes("$")) return false;
  const idx = stored.indexOf("$");
  const salt = stored.slice(0, idx);
  return hashPassword(password, salt) === stored;
}

function localNow() {
  const d = new Date();
  return {
    date: d.toLocaleDateString("en-CA"),
    time: d.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" }),
    iso: d.toISOString()
  };
}

function openDB() {
  return new Promise((resolve, reject) => {
    const r = indexedDB.open("VisitorRegisterStandalone", 1);
    r.onupgradeneeded = () => {
      const d = r.result;
      if (!d.objectStoreNames.contains("visits")) d.createObjectStore("visits", { keyPath: "id" });
      if (!d.objectStoreNames.contains("offices")) d.createObjectStore("offices", { keyPath: "id" });
      if (!d.objectStoreNames.contains("users")) d.createObjectStore("users", { keyPath: "id" });
      if (!d.objectStoreNames.contains("audit")) d.createObjectStore("audit", { keyPath: "id", autoIncrement: true });
      if (!d.objectStoreNames.contains("meta")) d.createObjectStore("meta", { keyPath: "key" });
    };
    r.onsuccess = () => { dbx = r.result; resolve(); };
    r.onerror = () => reject(r.error);
  });
}

function txStore(name, mode = "readonly") {
  return dbx.transaction(name, mode).objectStore(name);
}

function dbGetAll(storeName) {
  return new Promise(res => {
    const r = txStore(storeName).getAll();
    r.onsuccess = () => res(r.result || []);
    r.onerror = () => res([]);
  });
}

function dbPut(storeName, obj) {
  return new Promise(res => {
    const r = txStore(storeName, "readwrite").put(obj);
    r.onsuccess = () => res();
    r.onerror = () => res();
  });
}

function dbDelete(storeName, key) {
  return new Promise(res => {
    const r = txStore(storeName, "readwrite").delete(key);
    r.onsuccess = () => res();
    r.onerror = () => res();
  });
}

function getMeta(key) {
  return new Promise(res => {
    const r = txStore("meta").get(key);
    r.onsuccess = () => res(r.result ? r.result.value : null);
    r.onerror = () => res(null);
  });
}

function setMeta(key, value) {
  return dbPut("meta", { key, value });
}

async function seedIfFirstRun() {
  const initialized = await getMeta("initialized");
  if (!initialized) {
    await setMeta("org_name", FIXED_ORG_NAME);
    await setMeta("director_name", FIXED_DIRECTOR_NAME);

    for (let i = 0; i < DEFAULT_OFFICES.length; i++) {
      await dbPut("offices", {
        id: "off-" + (i + 1),
        name: DEFAULT_OFFICES[i],
        active: 1
      });
    }

    await dbPut("users", {
      id: "u-admin",
      name: FIXED_DIRECTOR_NAME,
      username: "admin",
      password: hashPassword("Admin@123"),
      role: "manager",
      active: 1
    });

    await dbPut("users", {
      id: "u-staff",
      name: "عون الاستقبال",
      username: "staff",
      password: hashPassword("Staff@123"),
      role: "employee",
      active: 1
    });

    await setMeta("initialized", true);
    return;
  }

  // Upgrade existing generic defaults if user previously ran the earlier prototype
  const savedOrg = await getMeta("org_name");
  if (!savedOrg || savedOrg === "المؤسسة التربوية") {
    await setMeta("org_name", FIXED_ORG_NAME);
  }
  const savedDirector = await getMeta("director_name");
  if (!savedDirector) {
    await setMeta("director_name", FIXED_DIRECTOR_NAME);
  }
  const allUsers = await dbGetAll("users");
  const adminUser = allUsers.find(u => u.id === "u-admin");
  if (adminUser && adminUser.name === "مدير المؤسسة") {
    adminUser.name = FIXED_DIRECTOR_NAME;
    await dbPut("users", adminUser);
    if (me && me.id === "u-admin") {
      me.name = FIXED_DIRECTOR_NAME;
      localStorage.setItem("vr_standalone_user", JSON.stringify(me));
    }
  }
}

function applyBrandingUI() {
  document.title = `سجل زوار ${orgName}`;
  if ($("loginOrgName")) $("loginOrgName").textContent = orgName;
  if ($("loginDirectorName")) $("loginDirectorName").textContent = `مدير المؤسسة: ${directorName}`;
  if ($("orgLabel")) $("orgLabel").textContent = orgName;
  if ($("sidebarDirector")) $("sidebarDirector").textContent = `المدير: ${directorName}`;
  if ($("welcomeOrg")) $("welcomeOrg").textContent = orgName;
  if ($("welcomeDirector")) $("welcomeDirector").textContent = `مدير المؤسسة: ${directorName}`;
  if ($("printOrgName")) $("printOrgName").textContent = orgName;
  if ($("printDirectorName")) $("printDirectorName").textContent = `مدير المؤسسة: ${directorName}`;
  if ($("printDate")) $("printDate").textContent = `تاريخ الطباعة: ${new Date().toLocaleDateString("ar-DZ")}`;
  if ($("appFooter")) $("appFooter").textContent = `${orgName} · مدير المؤسسة: ${directorName}`;
  if ($("orgNameInput")) $("orgNameInput").value = orgName;
  if ($("directorNameInput")) $("directorNameInput").value = directorName;
}

async function logAudit(action, recordId = "", details = "") {
  if (!me) return;
  await dbPut("audit", {
    user_id: me.id,
    user_name: me.name,
    action,
    record_id: recordId,
    details,
    at: new Date().toLocaleString("ar-DZ")
  });
}

function fillDemo(u, p) {
  $("username").value = u;
  $("password").value = p;
}

async function login() {
  await openDB();
  await seedIfFirstRun();

  const username = $("username").value.trim().toLowerCase();
  const password = $("password").value;
  $("loginError").textContent = "";

  const allUsers = await dbGetAll("users");
  const found = allUsers.find(u => u.username.toLowerCase() === username);

  if (!found || !verifyPassword(password, found.password)) {
    $("loginError").textContent = "اسم المستخدم أو كلمة المرور غير صحيحين";
    return;
  }
  if (!found.active) {
    $("loginError").textContent = "هذا الحساب معطّل من طرف المدير";
    return;
  }

  me = { id: found.id, name: found.name, username: found.username, role: found.role };
  localStorage.setItem("vr_standalone_user", JSON.stringify(me));
  await startApp();
}

function applyRoleUI() {
  const isEmployee = me.role === "employee";
  $("orgCard").classList.toggle("hidden", isEmployee);
  $("addOfficeForm").classList.toggle("hidden", isEmployee);
  $("officePermNote").classList.toggle("hidden", !isEmployee);
  $("usersCard").classList.toggle("hidden", isEmployee);
  $("auditCard").classList.toggle("hidden", isEmployee);
}

async function startApp() {
  await openDB();
  await seedIfFirstRun();

  users = await dbGetAll("users");
  const freshMe = users.find(u => u.id === me.id && u.active);
  if (!freshMe) {
    logout();
    return;
  }
  me.name = freshMe.name;

  $("login").classList.add("hidden");
  $("app").classList.remove("hidden");
  $("userName").textContent = me.name;
  $("userRole").textContent = me.role === "manager" ? "مدير المؤسسة" : "موظف الاستقبال";
  $("today").textContent = new Date().toLocaleDateString("ar-DZ");

  const n = localNow();
  $("visitDate").value = n.date;
  $("entryTime").value = n.time;
  $("reportDate").value = n.date;

  applyRoleUI();
  await loadLocalState();
  showPage("home");
}

async function loadLocalState() {
  orgName = (await getMeta("org_name")) || FIXED_ORG_NAME;
  directorName = (await getMeta("director_name")) || FIXED_DIRECTOR_NAME;
  applyBrandingUI();

  offices = (await dbGetAll("offices")).filter(o => o.active !== 0);
  visits = (await dbGetAll("visits")).filter(v => !v.deleted);
  users = await dbGetAll("users");

  renderAll();
}

function showPage(p) {
  document.querySelectorAll(".page").forEach(x => x.classList.add("hidden"));
  $(p).classList.remove("hidden");
  document.querySelectorAll(".nav").forEach(x => x.classList.toggle("active", x.dataset.page === p));
  $("pageTitle").textContent = ({
    home: "الرئيسية",
    new: "زيارة جديدة",
    visits: "سجل الزوار",
    reports: "التقارير",
    settings: "الإعدادات"
  })[p];
  document.querySelector(".sidebar").classList.remove("show");
  if (p === "reports") renderReport();
  if (p === "settings") renderSettings();
  if (p === "visits") renderVisits();
}

function renderAll() {
  fillOffices();
  renderHome();
  renderVisits();
  renderReport();
}

function fillOffices() {
  const html = offices.map(o => `<option value="${esc(o.id)}">${esc(o.name)}</option>`).join("");
  $("office").innerHTML = html;
  $("filterOffice").innerHTML = '<option value="">كل المكاتب</option>' + html;
}

function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, c => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  }[c]));
}

function isToday(v) {
  return v.visit_date === localNow().date;
}

function durationMinutes(v) {
  if (!v.exit_time || !v.entry_time || !v.visit_date) return null;
  const a = new Date(v.visit_date + "T" + v.entry_time);
  const b = new Date(v.visit_date + "T" + v.exit_time);
  if (isNaN(a.getTime()) || isNaN(b.getTime())) return null;
  const diff = Math.round((b - a) / 60000);
  return diff >= 0 ? diff : null;
}

function duration(v) {
  if (!v.exit_time) return "—";
  const mins = durationMinutes(v);
  return mins === null ? "غير صالح" : `${mins} د`;
}

function renderHome() {
  const activeVisits = visits.filter(v => !v.deleted);
  const today = activeVisits.filter(isToday);
  const month = localNow().date.slice(0, 7);

  $("sPresent").textContent = activeVisits.filter(v => !v.exit_time).length;
  $("sToday").textContent = today.length;
  $("sOffices").textContent = new Set(today.map(v => v.office_id)).size;
  $("sMonth").textContent = activeVisits.filter(v => (v.visit_date || "").startsWith(month)).length;

  drawBars("homeChart", today);

  const sortedToday = [...today].sort((a, b) => (b.entry_time || "").localeCompare(a.entry_time || ""));
  $("latest").innerHTML = sortedToday.slice(0, 5).map(v =>
    `<div class="office-row"><span>${esc(v.visitor_name)} <small>— ${esc(v.office_name)}</small></span><b>${esc(v.entry_time)}</b></div>`
  ).join("") || '<div class="empty">لا توجد زيارات اليوم</div>';
}

function drawBars(id, arr) {
  const counts = {};
  arr.forEach(v => {
    const label = v.office_name || "غير محدد";
    counts[label] = (counts[label] || 0) + 1;
  });
  const max = Math.max(1, ...Object.values(counts));
  $(id).innerHTML = Object.entries(counts).map(([n, c]) =>
    `<div class="bar-item"><b>${c}</b><div class="bar" style="height:${Math.max(4, c / max * 90)}px"></div><small>${esc(n)}</small></div>`
  ).join("") || '<div class="empty">لا توجد بيانات</div>';
}

function renderVisits() {
  const q = ($("search")?.value || "").trim().toLowerCase();
  const f = $("filterOffice")?.value || "";
  const st = $("filterStatus")?.value || "";

  const arr = [...visits]
    .filter(v => !v.deleted
      && (!q || (v.visitor_name || "").toLowerCase().includes(q) || (v.name_fr || "").toLowerCase().includes(q) || (v.national_id || "").includes(q))
      && (!f || v.office_id === f)
      && (!st || (st === "present" ? !v.exit_time : Boolean(v.exit_time))))
    .sort((a, b) => ((b.visit_date || "") + (b.entry_time || "")).localeCompare((a.visit_date || "") + (a.entry_time || "")));

  const isManager = me && me.role === "manager";

  $("visitRows").innerHTML = arr.map((v, i) => `
    <tr>
      <td>${i + 1}</td>
      <td><b>${esc(v.visitor_name)}</b>${v.name_fr ? `<br><small class="muted">${esc(v.name_fr)}</small>` : ""}</td>
      <td>${esc(v.visit_date)}</td>
      <td>${esc(v.entry_time)}</td>
      <td>${esc(v.exit_time || "—")}</td>
      <td>${esc(v.office_name)}</td>
      <td>${esc(v.reason || "—")}</td>
      <td>${duration(v)}</td>
      <td>
        <div class="btn-group">
          ${!v.exit_time ? `<button class="small-btn" onclick="checkout('${esc(v.id)}')">تسجيل خروج</button>` : ""}
          <button class="small-btn ghost" onclick="showDetails('${esc(v.id)}')">تفاصيل</button>
          ${isManager ? `<button class="small-btn danger" onclick="deleteVisit('${esc(v.id)}')">حذف</button>` : ""}
        </div>
      </td>
    </tr>
  `).join("") || '<tr><td colspan="9" class="empty">لا توجد نتائج</td></tr>';
}

function showDetails(id) {
  const v = visits.find(x => x.id === id);
  if (!v) return;
  const fields = [
    ["المؤسسة", orgName],
    ["مدير المؤسسة", directorName],
    ["الاسم واللقب", v.visitor_name],
    ["الاسم بالفرنسية", v.name_fr || "—"],
    ["المكتب المقصود", v.office_name],
    ["تاريخ الزيارة", v.visit_date],
    ["ساعة الدخول", v.entry_time],
    ["ساعة الخروج", v.exit_time || "حاضر حاليًا"],
    ["مدة الزيارة", duration(v)],
    ["سبب الزيارة", v.reason || "—"],
    ["تاريخ الميلاد", v.birth_date || "—"],
    ["رقم التعريف الوطني", v.national_id || "—"],
    ["سُجلت بواسطة", v.created_by_name || "—"],
  ];
  $("detailBody").innerHTML = fields.map(([k, val]) =>
    `<div class="detail-item"><small>${esc(k)}</small><b>${esc(val)}</b></div>`
  ).join("") + `<div class="detail-item span2"><small>ملاحظات</small><b>${esc(v.notes || "لا توجد ملاحظات")}</b></div>`;
  $("detailModal").classList.remove("hidden");
}

function closeDetails() {
  $("detailModal").classList.add("hidden");
}

async function saveVisit() {
  const name = $("visitorName").value.trim();
  const office = $("office").value;
  const officeName = $("office").selectedOptions[0]?.textContent || "";

  if (!name || !office) {
    $("newMsg").style.color = "#b42318";
    $("newMsg").textContent = "يرجى إدخال الاسم واختيار المكتب.";
    return;
  }

  const visitDate = $("visitDate").value || localNow().date;
  const entryTime = $("entryTime").value || localNow().time;

  const duplicate = visits.find(x =>
    !x.deleted
    && x.visitor_name.trim().toLowerCase() === name.toLowerCase()
    && x.visit_date === visitDate
    && !x.exit_time
  );
  if (duplicate && !confirm("توجد زيارة مفتوحة بالاسم نفسه اليوم على هذا الهاتف. هل تريد المتابعة؟")) return;

  const v = {
    id: makeId("vis"),
    visitor_name: name,
    name_fr: $("nameFr").value.trim(),
    office_id: office,
    office_name: officeName,
    visit_date: visitDate,
    entry_time: entryTime,
    exit_time: "",
    reason: $("reason").value.trim(),
    notes: $("notes").value.trim(),
    birth_date: $("birthDate").value,
    national_id: $("nationalId").value.trim(),
    created_by: me.id,
    created_by_name: me.name,
    updated_at: localNow().iso,
    deleted: 0
  };

  await dbPut("visits", v);
  await logAudit("تسجيل زيارة جديدة", v.id, v.visitor_name);
  visits.push(v);

  $("newMsg").style.color = "#1d8a58";
  $("newMsg").textContent = "تم حفظ الزيارة بنجاح في ذاكرة الهاتف.";
  resetVisit(false);
  renderAll();
}

function resetVisit(clearMsg = true) {
  ["visitorName", "nameFr", "reason", "notes", "birthDate", "nationalId"].forEach(id => $(id).value = "");
  const n = localNow();
  $("visitDate").value = n.date;
  $("entryTime").value = n.time;
  if (clearMsg) $("newMsg").textContent = "";
}

async function checkout(id) {
  const v = visits.find(x => x.id === id);
  if (!v || v.exit_time) return;

  const now = localNow();
  let exitTime = now.time;
  if (v.visit_date === now.date && exitTime < v.entry_time) {
    exitTime = v.entry_time;
  }

  v.exit_time = exitTime;
  v.updated_at = now.iso;
  await dbPut("visits", v);
  await logAudit("تسجيل خروج زائر", v.id, `${v.visitor_name} (${exitTime})`);
  renderAll();
}

async function deleteVisit(id) {
  if (me.role !== "manager") return;
  const v = visits.find(x => x.id === id);
  if (!v) return;
  if (!confirm(`هل تريد حذف سجل زيارة "${v.visitor_name}" نهائيًا؟`)) return;

  await dbDelete("visits", id);
  await logAudit("حذف سجل زيارة", id, v.visitor_name);
  visits = visits.filter(x => x.id !== id);
  renderAll();
}

function renderReport() {
  const date = $("reportDate").value || localNow().date;
  const activeVisits = visits.filter(v => !v.deleted);
  const arr = activeVisits.filter(v => v.visit_date === date);
  const present = activeVisits.filter(v => !v.exit_time).length;

  const validDurations = arr.map(durationMinutes).filter(m => m !== null);
  const avg = validDurations.length
    ? Math.round(validDurations.reduce((s, m) => s + m, 0) / validDurations.length)
    : 0;

  $("rPresent").textContent = present;
  $("rTotal").textContent = arr.length;
  $("rAverage").textContent = avg + " د";
  $("rOffices").textContent = new Set(arr.map(v => v.office_id)).size;

  drawBars("reportChart", arr);
  $("reportTable").innerHTML = arr.map(v =>
    `<div class="office-row"><span>${esc(v.visitor_name)} · ${esc(v.office_name)}</span><b>${esc(v.entry_time)} – ${esc(v.exit_time || "حاضر")}</b></div>`
  ).join("") || '<div class="empty">لا توجد زيارات في هذا التاريخ</div>';
}

async function renderSettings() {
  applyRoleUI();
  applyBrandingUI();

  const isManager = me.role === "manager";
  $("officeList").innerHTML = offices.map(o => `
    <div class="office-row">
      <span>${esc(o.name)}</span>
      ${isManager && offices.length > 1 ? `<button class="small-btn danger" onclick="removeOffice('${esc(o.id)}')">حذف</button>` : ""}
    </div>
  `).join("") || '<div class="empty">لا توجد مكاتب</div>';

  if (isManager) {
    users = await dbGetAll("users");
    $("userList").innerHTML = users.map(u => `
      <div class="office-row">
        <span><b>${esc(u.name)}</b> <small class="muted">(${esc(u.username)} · ${u.role === "manager" ? "مدير" : "موظف"})</small></span>
        ${u.id !== me.id ? `<button class="small-btn ${u.active ? "danger" : ""}" onclick="toggleUser('${esc(u.id)}')">${u.active ? "تعطيل" : "تفعيل"}</button>` : "<small class='muted'>الحساب الحالي</small>"}
      </div>
    `).join("");

    const logs = await dbGetAll("audit");
    $("auditLog").innerHTML = logs.slice(-15).reverse().map(x =>
      `<div class="office-row"><small>${esc(x.user_name)} · ${esc(x.action)}${x.details ? " (" + esc(x.details) + ")" : ""} · ${esc(x.at)}</small></div>`
    ).join("") || '<div class="empty">لا توجد عمليات مسجلة بعد</div>';
  }
}

async function saveOrgInfo() {
  if (me.role !== "manager") return;
  const newOrg = $("orgNameInput").value.trim();
  const newDir = $("directorNameInput").value.trim();
  if (!newOrg || !newDir) return;

  orgName = newOrg;
  directorName = newDir;
  await setMeta("org_name", orgName);
  await setMeta("director_name", directorName);

  const allUsers = await dbGetAll("users");
  const adminUser = allUsers.find(u => u.id === "u-admin");
  if (adminUser) {
    adminUser.name = directorName;
    await dbPut("users", adminUser);
  }
  if (me.id === "u-admin") {
    me.name = directorName;
    localStorage.setItem("vr_standalone_user", JSON.stringify(me));
    $("userName").textContent = me.name;
  }

  await logAudit("تحديث بيانات المؤسسة والمدير", "", `${orgName} — ${directorName}`);
  applyBrandingUI();
  renderSettings();
  $("orgMsg").textContent = "تم تثبيت وحفظ اسم المؤسسة والمدير بنجاح.";
  setTimeout(() => { $("orgMsg").textContent = ""; }, 3000);
}

async function addOffice() {
  if (me.role !== "manager") return;
  const name = $("newOffice").value.trim();
  if (!name) return;
  const office = { id: makeId("off"), name, active: 1 };
  await dbPut("offices", office);
  await logAudit("إضافة مكتب", office.id, name);
  offices.push(office);
  $("newOffice").value = "";
  renderAll();
  renderSettings();
}

async function removeOffice(id) {
  if (me.role !== "manager" || offices.length <= 1) return;
  const target = offices.find(o => o.id === id);
  if (!target || !confirm(`حذف "${target.name}" من قائمة المكاتب؟`)) return;
  await dbDelete("offices", id);
  await logAudit("حذف مكتب", id, target.name);
  offices = offices.filter(o => o.id !== id);
  renderAll();
  renderSettings();
}

async function addUser() {
  if (me.role !== "manager") return;
  const name = $("newUserName").value.trim();
  const username = $("newUsername").value.trim();
  const password = $("newPassword").value;
  const role = $("newRole").value;
  $("userMsg").textContent = "";

  if (!name || !username || !password) {
    $("userMsg").textContent = "يرجى ملء جميع الحقول.";
    return;
  }
  if (password.length < 6) {
    $("userMsg").textContent = "كلمة المرور يجب أن تتكون من 6 أحرف على الأقل.";
    return;
  }

  const allUsers = await dbGetAll("users");
  if (allUsers.some(u => u.username.toLowerCase() === username.toLowerCase())) {
    $("userMsg").textContent = "اسم المستخدم مستخدم مسبقًا.";
    return;
  }

  const user = {
    id: makeId("u"),
    name,
    username,
    password: hashPassword(password),
    role,
    active: 1
  };
  await dbPut("users", user);
  await logAudit("إنشاء حساب", user.id, `${name} (${username})`);
  $("newUserName").value = "";
  $("newUsername").value = "";
  $("newPassword").value = "";
  $("userMsg").textContent = "تم إنشاء الحساب بنجاح.";
  renderSettings();
}

async function toggleUser(id) {
  if (me.role !== "manager" || id === me.id) return;
  const allUsers = await dbGetAll("users");
  const u = allUsers.find(x => x.id === id);
  if (!u) return;
  u.active = u.active ? 0 : 1;
  await dbPut("users", u);
  await logAudit(u.active ? "تفعيل حساب" : "تعطيل حساب", u.id, u.username);
  renderSettings();
}

async function changeOwnPassword() {
  const cur = $("curPass").value;
  const nxt = $("nextPass").value;
  $("passMsg").textContent = "";

  if (!cur || nxt.length < 6) {
    $("passMsg").textContent = "أدخل كلمة المرور الحالية وكلمة جديدة من 6 أحرف على الأقل.";
    return;
  }
  const allUsers = await dbGetAll("users");
  const u = allUsers.find(x => x.id === me.id);
  if (!u || !verifyPassword(cur, u.password)) {
    $("passMsg").textContent = "كلمة المرور الحالية غير صحيحة.";
    return;
  }
  u.password = hashPassword(nxt);
  await dbPut("users", u);
  await logAudit("تغيير كلمة المرور", u.id, u.username);
  $("curPass").value = "";
  $("nextPass").value = "";
  $("passMsg").textContent = "تم تحديث كلمة المرور بنجاح.";
}

function exportCSV() {
  const rows = [
    [`المؤسسة: ${orgName}`, `مدير المؤسسة: ${directorName}`],
    ["رقم", "الاسم واللقب", "الاسم بالفرنسية", "تاريخ الميلاد", "رقم التعريف الوطني", "التاريخ", "الدخول", "الخروج", "المدة", "المكتب", "السبب", "ملاحظات"],
    ...visits.filter(v => !v.deleted).map((v, i) => [
      i + 1,
      v.visitor_name,
      v.name_fr,
      v.birth_date,
      v.national_id,
      v.visit_date,
      v.entry_time,
      v.exit_time,
      duration(v),
      v.office_name,
      v.reason,
      v.notes
    ])
  ];
  const csv = "\ufeff" + rows.map(r => r.map(x => '"' + String(x ?? "").replace(/"/g, '""') + '"').join(",")).join("\r\n");
  shareOrDownload(new Blob([csv], { type: "text/csv;charset=utf-8" }), "سجل-زوار-متوسطة-محمد-الصديق-بن-يحي.csv");
}

async function backup() {
  const payload = {
    version: 2,
    mode: "standalone",
    exported_at: new Date().toISOString(),
    org_name: orgName,
    director_name: directorName,
    offices: await dbGetAll("offices"),
    users: await dbGetAll("users"),
    visits: await dbGetAll("visits")
  };
  shareOrDownload(
    new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" }),
    "نسخة-سجل-زوار-متوسطة-محمد-الصديق-بن-يحي.json"
  );
}

function restoreBackup(e) {
  const f = e.target.files[0];
  if (!f) return;
  const r = new FileReader();
  r.onload = async () => {
    try {
      const d = JSON.parse(r.result);
      if (d.org_name) await setMeta("org_name", d.org_name);
      if (d.director_name) await setMeta("director_name", d.director_name);
      for (const o of d.offices || []) {
        if (o && o.id && o.name) await dbPut("offices", o);
      }
      for (const u of d.users || []) {
        if (u && u.id && u.username && u.password) await dbPut("users", u);
      }
      for (const v of d.visits || []) {
        if (v && v.id && v.visitor_name) await dbPut("visits", v);
      }
      await logAudit("استعادة نسخة احتياطية", "", `${(d.visits || []).length} زيارة`);
      await loadLocalState();
      renderSettings();
      alert("تمت استعادة النسخة الاحتياطية بنجاح.");
    } catch (_) {
      alert("ملف النسخة الاحتياطية غير صالح.");
    }
  };
  r.readAsText(f);
}

async function shareOrDownload(blob, filename) {
  try {
    const file = new File([blob], filename, { type: blob.type });
    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      await navigator.share({ files: [file], title: filename });
      return;
    }
  } catch (_) {}

  const a = document.createElement("a");
  const u = URL.createObjectURL(blob);
  a.href = u;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(u), 1500);
}

function logout() {
  localStorage.removeItem("vr_standalone_user");
  location.reload();
}

document.querySelectorAll(".nav").forEach(b => b.addEventListener("click", () => showPage(b.dataset.page)));
if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  navigator.serviceWorker.register("sw.js").catch(() => {});
}
openDB().then(async () => {
  await seedIfFirstRun();
  applyBrandingUI();
  if (me) await startApp();
}).catch(() => {});
