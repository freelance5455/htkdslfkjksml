const $ = (id) => document.getElementById(id);
const chat = $("chat"), welcome = $("welcome"), promptBox = $("prompt");
const SETTINGS_KEY = "red_settings_v1", HISTORY_KEY = "red_history_v1";
let busy = false;
let history = safeParse(localStorage.getItem(HISTORY_KEY), []);
let settings = safeParse(localStorage.getItem(SETTINGS_KEY), {apiKey:"", model:"gemini-2.5-flash"});
$("apiKey").value = settings.apiKey || ""; $("model").value = settings.model || "gemini-2.5-flash";
function safeParse(s, fallback){try{return s?JSON.parse(s):fallback}catch{return fallback}}
function setStatus(t){$("status").textContent=t}
function saveHistory(){localStorage.setItem(HISTORY_KEY, JSON.stringify(history.slice(-100)))}
function addMessage(role, text, save=true){
  welcome.classList.add("hide");
  const el=document.createElement("div"); el.className="msg "+(role==="user"?"user":"assistant");
  if(role!=="user"){const who=document.createElement("span");who.className="who";who.textContent="RED";el.appendChild(who)}
  const body=document.createElement("span");body.textContent=text;el.appendChild(body);chat.appendChild(el);chat.scrollTop=chat.scrollHeight;
  if(save){history.push({role,text,at:Date.now()});saveHistory()}
  return el;
}
function renderHistory(){
  [...chat.querySelectorAll(".msg")].forEach(n=>n.remove());
  if(!history.length){welcome.classList.remove("hide");return}
  welcome.classList.add("hide"); history.forEach(m=>addMessage(m.role,m.text,false));
}
function localReply(input){
  const s=input.toLowerCase().trim();
  if(/^(oi|olá|ola|e aí|eai|bom dia|boa tarde|boa noite)\b/.test(s))
    return "Fala! Eu sou o RED. 🔴 Ainda estou na minha versão inicial, então não vou fingir saber tudo. Quer conversar, aprender alguma coisa ou organizar uma ideia?";
  if(s.includes("quem é você")||s.includes("quem e voce")||s.includes("sua personalidade"))
    return "Sou o RED: direto, curioso, leal e um pouco teimoso com a verdade. Prefiro admitir quando não sei a inventar uma resposta. No modo local básico, minhas respostas são limitadas; conecte o Google Gemini para uma conversa generativa.";
  if(s.includes("offline")||s.includes("sem internet"))
    return "No modo offline eu consigo abrir o app e manter o histórico neste aparelho. Esta versão ainda não inclui um modelo de linguagem local completo, então minhas respostas offline são limitadas. Para conversar com uma IA generativa sem internet, precisamos instalar e integrar um modelo compatível com o celular.";
  if(s.includes("google")||s.includes("gemini")||s.includes("api"))
    return "Para ativar o Google Gemini, toque em “Configurar Google IA”, adicione sua chave da API e salve. A chave é pessoal: não compartilhe prints nem publique uma versão com ela salva. Os limites gratuitos dependem das condições atuais do Google.";
  if(s.includes("obrigado")||s.includes("obrigada")||s.includes("valeu"))
    return "Tamo junto. 🔴 E se alguma coisa não funcionar, me conta o que apareceu na tela que a gente resolve por etapas.";
  return "Estou em modo local básico, então ainda não consigo gerar uma resposta inteligente completa sem conexão. Posso manter seu histórico e as configurações. Para conversar de verdade, configure o Google Gemini em “Configurar Google IA”.";
}
async function askGemini(userText){
  const key=settings.apiKey?.trim(), model=settings.model?.trim() || "gemini-2.5-flash";
  if(!key) throw new Error("Configure sua chave do Google Gemini nas configurações.");
  const prior=history.filter(m=>m.role==="user"||m.role==="assistant").slice(-12).map(m=>({role:m.role==="assistant"?"model":"user",parts:[{text:m.text}]}));
  const body={
    system_instruction:{parts:[{text:"Você é RED, um assistente pessoal com personalidade própria. Fale em português brasileiro por padrão. Personalidade: direto sem ser grosseiro, curioso, caloroso sem bajular, espirituoso quando cabe, protetor da privacidade e honesto sobre incertezas. Prefira explicações claras e úteis. Nunca diga que executou ações no aparelho se não executou. Não invente pesquisas, fontes, capacidades offline ou resultados. Respeite a segurança do usuário."}]},
    contents:[...prior,{role:"user",parts:[{text:userText}]}],
    generationConfig:{temperature:0.8, maxOutputTokens:900}
  };
  const url=`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`;
  const res=await fetch(url,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
  const data=await res.json().catch(()=>({}));
  if(!res.ok) throw new Error(data?.error?.message || `Google Gemini retornou erro HTTP ${res.status}.`);
  const out=data?.candidates?.[0]?.content?.parts?.map(p=>p.text||"").join("").trim();
  if(!out) throw new Error("O Google Gemini não retornou texto. Tente novamente.");
  return out;
}
async function send(){
  const text=promptBox.value.trim(); if(!text||busy)return;
  promptBox.value="";promptBox.style.height="auto";busy=true;$("send").disabled=true;
  addMessage("user",text);
  const mode=$("mode").value; const loading=addMessage("assistant","Pensando…",false);
  try{
    let answer;
    if(mode==="offline"){answer=localReply(text);setStatus("Modo local")}
    else if(mode==="online"){answer=await askGemini(text);setStatus("Google online")}
    else if(navigator.onLine && settings.apiKey){answer=await askGemini(text);setStatus("Google online")}
    else {answer=localReply(text);setStatus("Modo local")}
    loading.querySelector("span:last-child").textContent=answer;
    history.push({role:"assistant",text:answer,at:Date.now()});saveHistory();
  }catch(e){
    loading.querySelector("span:last-child").textContent="Não consegui responder pela IA online: "+e.message+"\n\nVocê pode tentar novamente ou selecionar o modo local.";
    loading.querySelector("span:last-child").classList.add("error");
    history.push({role:"assistant",text:loading.querySelector("span:last-child").textContent,at:Date.now()});saveHistory();
    setStatus("Atenção");
  }finally{busy=false;$("send").disabled=false;promptBox.focus();chat.scrollTop=chat.scrollHeight}
}
$("send").addEventListener("click",send);
promptBox.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send()}});
promptBox.addEventListener("input",()=>{promptBox.style.height="auto";promptBox.style.height=Math.min(promptBox.scrollHeight,140)+"px"});
$("settingsBtn").addEventListener("click",()=>$("settings").showModal());
$("closeSettings").addEventListener("click",()=>$("settings").close());
$("saveSettings").addEventListener("click",()=>{
 settings={apiKey:$("apiKey").value.trim(),model:$("model").value.trim()||"gemini-2.5-flash"};
 localStorage.setItem(SETTINGS_KEY,JSON.stringify(settings));$("settings").close();
 setStatus(settings.apiKey?"Google configurado":"Modo local");
 addMessage("assistant",settings.apiKey?"Configuração salva neste aparelho. Quando estiver online, selecione “Automático” ou “Google online” para testar.":"Chave removida. O RED continuará disponível no modo local básico.");
});
$("newBtn").addEventListener("click",()=>{history=[];saveHistory();renderHistory();setStatus("Nova conversa")});
$("clearBtn").addEventListener("click",()=>{if(confirm("Apagar todo o histórico salvo neste aparelho?")){history=[];saveHistory();renderHistory()}});
document.querySelectorAll("[data-prompt]").forEach(b=>b.addEventListener("click",()=>{promptBox.value=b.dataset.prompt;send()}));
window.addEventListener("online",()=>setStatus(settings.apiKey?"Online · Google disponível":"Online · configure o Google"));
window.addEventListener("offline",()=>setStatus("Sem internet"));
renderHistory(); setStatus(navigator.onLine?(settings.apiKey?"Google configurado":"Modo local"):"Sem internet");
if("serviceWorker" in navigator) window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
