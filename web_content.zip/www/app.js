const $=id=>document.getElementById(id);
let map=L.map('map',{zoomControl:false}).setView([48.137,11.576],11);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap'}).addTo(map);
L.control.zoom({position:'bottomleft'}).addTo(map);
let current=null, currentMarker=null, routeLayer=null, stationLayer=L.layerGroup().addTo(map), lastRoute=null, routeChoices=[];
const defaults={name:'Saját jármű',fuel:'Benzin',fuelType:'e10',manualPrice:0,apiKey:'',tank:55,consumption:7.5,percent:100,reserve:15,connector:'type2',chargePower:11};
let vehicle={...defaults,...JSON.parse(localStorage.getItem('lindVehicle')||'{}')};
let tolls=JSON.parse(localStorage.getItem('lindTolls')||'[]');
let tollRecords=JSON.parse(localStorage.getItem('lindTollRecords')||'{}');
let tripCountries=JSON.parse(localStorage.getItem('lindTripCountries')||'[]');
let tollVehicleClass=localStorage.getItem('lindTollVehicleClass')||'car';
let nearbyPricedStations=[];
let priceFetchedAt=null;
let navSteps=[];let activeStep=-1;let routeCoords=[];let watchId=null;let voiceEnabled=false;let lastSpeedLookup=0;let lastSpeedLimit='—';let offRouteCount=0;let rerouting=false;let lastRerouteAt=0;
const tollCountryData=[['Németország','de'],['Ausztria','at'],['Magyarország','hu'],['Szlovákia','sk'],['Csehország','cz'],['Szlovénia','si'],['Svájc','ch'],['Horvátország','hr'],['Románia','ro'],['Bulgária','bg'],['Olaszország','it'],['Franciaország','fr'],['Spanyolország','es'],['Portugália','pt']];

function updateVehicle(){ $('vehicleName').textContent=vehicle.name; $('fuelMeta').textContent=`${vehicle.fuel} · ${vehicle.tank} ${vehicle.fuel==='Elektromos'?'kWh':'liter'} · ${vehicle.consumption} ${vehicle.fuel==='Elektromos'?'kWh':'l'}/100`;let usable=vehicle.tank*vehicle.percent/100;let range=vehicle.consumption>0?Math.floor(usable/vehicle.consumption*100):0;$('range').textContent=range.toLocaleString('hu-HU');$('fuelLevelText').textContent=`Becsült ${vehicle.fuel==='Elektromos'?'energia':'üzemanyag'}: ${usable.toFixed(1)} ${vehicle.fuel==='Elektromos'?'kWh':'liter'}`;$('fuelBar').style.width=vehicle.percent+'%';}
function bestKnownPrice(){
 if(vehicle.fuel==='Elektromos')return {value:vehicle.electricityPrice||0.35,label:'megadott áramár'};
 const cheapest=nearbyPricedStations.filter(s=>Number.isFinite(s.price)&&s.price>0).sort((a,b)=>a.price-b.price)[0];
 if(cheapest)return {value:cheapest.price,label:`legolcsóbb közeli ár (${cheapest.name})`};
 if(vehicle.manualPrice>0)return {value:vehicle.manualPrice,label:'kézzel megadott ár'};
 return null;
}
function updateTolls(){
 const entries=Object.entries(tollRecords).filter(([country,r])=>r&&r.validUntil);
 $('tollSummary').textContent=entries.length?'Nyilvántartott jogosultságok: '+entries.map(([c,r])=>c+' ('+r.validUntil+')').join(' · '):(tolls.length?'Korábbi matricalista: '+tolls.join(', '):'Nincs megadott matrica.');
}
function renderTollEditor(){
 $('tollVehicleClass').value=tollVehicleClass;
 $('tollEditor').innerHTML=tollCountryData.map(([country,code])=>{
  const r=tollRecords[country]||{};
  return `<div class="toll-edit-row"><div><b>${country}</b><small>${code.toUpperCase()}</small></div><label class="toll-input">Típus<select data-country="${country}" data-field="type"><option value="vignette" ${r.type==='vignette'?'selected':''}>Matrica</option><option value="toll" ${r.type==='toll'?'selected':''}>Útdíj / szakaszdíj</option><option value="free" ${r.type==='free'?'selected':''}>Díjmentes / nem szükséges</option></select></label><label class="toll-input">Érvényes eddig<input data-country="${country}" data-field="validUntil" type="date" value="${r.validUntil||''}"></label></div>`;
 }).join('');
 $('tripCountryChecks').innerHTML=tollCountryData.map(([country])=>`<label class="check"><input type="checkbox" value="${country}" ${tripCountries.includes(country)?'checked':''}>${country}</label>`).join('');
}
function checkTripTolls(){
 const missing=tripCountries.filter(c=>{const r=tollRecords[c];if(!r)return true;if(r.type==='free')return false;if(!r.validUntil)return true;return new Date(r.validUntil+'T23:59:59')<new Date();});
 const result=$('tollCheckResult');
 if(!tripCountries.length){result.textContent='Válaszd ki a tervezett útvonal országait az ellenőrzéshez.';return;}
 if(missing.length){result.innerHTML='<b class="warningtext">Ellenőrizendő jogosultságok:</b> '+missing.map(escapeHtml).join(', ')+'. Indulás előtt ellenőrizd az adott ország hivatalos útdíjfeltételeit.';}
 else{result.innerHTML='<b class="good">A saját nyilvántartásod szerint minden kiválasztott ország rendben van.</b> Az útdíj-szabályokat és az érvényességet indulás előtt hivatalos forrásból is ellenőrizd.';}
}
function setCurrent(lat,lon){current=[lat,lon];if(currentMarker)map.removeLayer(currentMarker);currentMarker=L.circleMarker(current,{radius:8,color:'#160f22',weight:3,fillColor:'#b58cff',fillOpacity:1}).addTo(map).bindPopup('Jelenlegi helyzet');map.setView(current,14);$('gpsStatus').textContent='GPS-helyzet elérhető';$('from').value='Jelenlegi helyzet';}
function locate(){if(!navigator.geolocation){$('gpsStatus').textContent='GPS nem támogatott';$('routeInfo').textContent='Ez a böngésző vagy előnézet nem biztosít helymeghatározást. Próbáld telepített alkalmazásban.';return} $('gpsStatus').textContent='Helymeghatározás…';navigator.geolocation.getCurrentPosition(p=>setCurrent(p.coords.latitude,p.coords.longitude),e=>{let msg=e.code===1?'A helyhozzáférést megtagadtad. Engedélyezd az alkalmazás helyhozzáférését.':e.code===2?'A készülék helyzete most nem határozható meg. Ellenőrizd a GPS-t.':'A helymeghatározás időtúllépés miatt nem sikerült.';$('gpsStatus').textContent='GPS nem elérhető';$('routeInfo').textContent=msg;},{enableHighAccuracy:true,timeout:20000,maximumAge:10000});}
$('gpsBtn').onclick=locate;$('locateBtn').onclick=()=>current?map.setView(current,15):locate();$('useCurrent').onclick=locate;
async function geocode(q){let u='https://nominatim.openstreetmap.org/search?format=json&limit=1&q='+encodeURIComponent(q);let r=await fetch(u);let a=await r.json();if(!a.length)throw Error('A megadott hely nem található: '+q);return [+a[0].lat,+a[0].lon,a[0].display_name];}
function routeSteps(r){
 return (r.legs||[]).flatMap(l=>l.steps||[]).map(s=>({
  name:s.name||'',type:s.maneuver?.type||'continue',modifier:s.maneuver?.modifier||'',
  instruction:formatManeuver(s),distance:s.distance||0,location:s.maneuver?.location||null,
  lanes:s.intersections?.[0]?.lanes||[],bearings:s.intersections?.[0]?.bearings||[]
 }));
}
function selectRoute(index){
 const r=routeChoices[index];if(!r)return;
 const d=lastRoute.destination;
 lastRoute={route:r,destination:d,index};
 routeCoords=r.geometry.coordinates;navSteps=routeSteps(r);activeStep=-1;offRouteCount=0;
 $('liveDrive').classList.remove('hidden');
 $('maneuverText').textContent=navSteps[0]?.instruction||'Kövesd az útvonalat';
 $('maneuverDistance').textContent=navSteps[0]?formatDistance(navSteps[0].distance):'—';
 $('maneuverIcon').textContent='↑';
 $('fuelPlan').classList.add('hidden');
 if(routeLayer)map.removeLayer(routeLayer);
 routeLayer=L.geoJSON(r.geometry,{style:{color:'#b58cff',weight:6,opacity:.92}}).addTo(map);
 map.fitBounds(routeLayer.getBounds(),{padding:[30,30]});
 const km=r.distance/1000,min=r.duration/60,usable=vehicle.tank*vehicle.percent/100;
 const need=km*vehicle.consumption/100,reserve=vehicle.tank*vehicle.reserve/100;
 $('distance').textContent=km.toFixed(0)+' km';
 $('duration').textContent=Math.round(min/60)+' ó '+Math.round(min%60)+' p';
 $('eta').textContent=new Date(Date.now()+r.duration*1000).toLocaleTimeString('hu-HU',{hour:'2-digit',minute:'2-digit'});
 const price=bestKnownPrice(),cost=price?need*price.value:null;
 $('routeInfo').textContent=`Cél: ${d[2]} · Becsült energiaigény: ${need.toFixed(1)} ${vehicle.fuel==='Elektromos'?'kWh':'liter'}`+
  (cost!==null?` · Becsült költség: ${cost.toFixed(2)} € (${price.label})`:vehicle.fuel!=='Elektromos'?' · Üzemanyagár megadásával költség is számolható.':' · Áramár megadásával becsült költség számolható.')+'.';
 $('fuelPlan').classList.remove('hidden');
 $('fuelPlan').innerHTML='<button id="planStopsBtn" class="secondary">TANKOLÁSI / TÖLTÉSI TERV KÉSZÍTÉSE</button><div id="planStopsResult" class="routeinfo">A rendszer megkeresi az útvonal közelében lévő megállókat, és megbecsüli, szükséges-e tankolás.</div>';
 $('planStopsBtn').onclick=planFuelStops;
 const w=$('routeWarning');
 if(need+reserve>usable){w.classList.remove('hidden');w.textContent=`A jelenlegi becsült készlet kevés lehet. Szükséges: ${need.toFixed(1)}, tartalékkal: ${(need+reserve).toFixed(1)}, rendelkezésre áll: ${usable.toFixed(1)}.`;}
 else{w.classList.add('hidden');w.textContent='';}
 renderRouteChoices(index);
}
function routeEstimate(r){
 const km=r.distance/1000;
 const energy=km*vehicle.consumption/100;
 const price=bestKnownPrice();
 const cost=price?energy*price.value:null;
 return {km,minutes:Math.round(r.duration/60),energy,cost,price};
}
function renderRouteChoices(selected){
 const panel=$('routeAlternatives');if(!panel)return;
 if(routeChoices.length<2){panel.classList.add('hidden');panel.innerHTML='';return;}
 const estimates=routeChoices.map(routeEstimate);
 const fastest=estimates.reduce((a,e,i)=>e.minutes<estimates[a].minutes?i:a,0);
 const shortest=estimates.reduce((a,e,i)=>e.km<estimates[a].km?i:a,0);
 const cheapest=estimates.some(e=>e.cost!==null)?estimates.reduce((a,e,i)=>e.cost!==null&&(estimates[a].cost===null||e.cost<estimates[a].cost)?i:a,0):-1;
 panel.classList.remove('hidden');
 panel.innerHTML='<div class="alternatives-title">ÚTVONALAK ÖSSZEHASONLÍTÁSA</div>'+routeChoices.map((r,i)=>{
  const e=estimates[i],tags=[];
  if(i===fastest)tags.push('Leggyorsabb');
  if(i===shortest)tags.push('Legrövidebb');
  if(i===cheapest)tags.push('Legolcsóbb becslés');
  const label=i===0?'Ajánlott':`Alternatíva ${i}`;
  const costText=e.cost!==null?`${e.cost.toFixed(2)} €`:'Ár nincs megadva';
  return `<button class="route-option ${i===selected?'selected':''}" data-route-index="${i}"><span><b>${label}</b><small>${e.km.toFixed(0)} km · ${Math.floor(e.minutes/60)} ó ${e.minutes%60} p · ${e.energy.toFixed(1)} ${vehicle.fuel==='Elektromos'?'kWh':'l'}</small><small>${costText} · ${tags.join(' · ')}</small></span><strong>${e.minutes}′</strong></button>`;
 }).join('')+(vehicle.fuel==='Elektromos'?'<small class="route-cost-note">Az elektromos energiaár nincs beállítva, ezért euróban számolt költséget nem mutatunk.</small>':'<small class="route-cost-note">A költségbecslés a megadott fogyasztással és az ismert üzemanyagárral számol; nem tartalmazza az útdíjakat.</small>');
 panel.querySelectorAll('[data-route-index]').forEach(btn=>btn.addEventListener('click',()=>selectRoute(Number(btn.dataset.routeIndex))));
}
$('routeBtn').onclick=async()=>{
 const dest=$('to').value.trim();if(!dest){$('routeInfo').textContent='Írd be az úti célt.';return;}
 try{
  $('routeBtn').textContent='KERESÉS…';
  if(!current)await new Promise((resolve,reject)=>navigator.geolocation.getCurrentPosition(p=>{setCurrent(p.coords.latitude,p.coords.longitude);resolve();},reject,{enableHighAccuracy:true,timeout:15000}));
  const d=await geocode(dest);
  const url=`https://router.project-osrm.org/route/v1/driving/${current[1]},${current[0]};${d[1]},${d[0]}?overview=full&geometries=geojson&steps=true&alternatives=true`;
  const res=await fetch(url),data=await res.json();
  if(data.code!=='Ok'||!data.routes?.length)throw Error('Nem sikerült útvonalat találni.');
  routeChoices=data.routes;lastRoute={route:routeChoices[0],destination:d,index:0};
  selectRoute(0);startLocationWatch();
 }catch(e){$('routeInfo').textContent=e.message||'Hiba történt az útvonaltervezés során.';}
 finally{$('routeBtn').textContent='TERVEZÉS';}
};
$('stationsBtn').onclick=async()=>{
 if(!current){locate();$('stationStatus').textContent='Előbb engedélyezd a GPS-t';return}
 $('stationStatus').textContent='Árak és állomások keresése…';
 try{
  let list=[];
  if(vehicle.fuel!=='Elektromos' && vehicle.apiKey.trim()){
   const type=vehicle.fuelType||'e10';
   const params=new URLSearchParams({lat:current[0],lng:current[1],rad:'10',sort:'price',type,apikey:vehicle.apiKey.trim()});
   const api=await fetch('https://creativecommons.tankerkoenig.de/json/list.php?'+params.toString());
   if(!api.ok)throw new Error('A Tankerkönig API nem érhető el.');
   const data=await api.json();
   if(!data.ok)throw new Error(data.message||'A Tankerkönig API hibát jelzett.');
   list=(data.stations||[]).map(s=>({id:s.id,name:s.name||s.brand||'Benzinkút',lat:+s.lat,lon:+s.lng,brand:s.brand||'',dist:+s.dist||null,price:Number(s[type]),isOpen:s.isOpen,source:'Tankerkönig'})).filter(s=>Number.isFinite(s.lat)&&Number.isFinite(s.lon));
   nearbyPricedStations=list.filter(s=>Number.isFinite(s.price)&&s.price>0);
   priceFetchedAt=new Date();
  }else{
   const [lat,lon]=current;
   const tag=vehicle.fuel==='Elektromos'?'[amenity=charging_station]':'[amenity=fuel]';
   const q=`[out:json][timeout:20];(node(around:5000,${lat},${lon})${tag};way(around:5000,${lat},${lon})${tag};);out center tags 30;`;
   const res=await fetch('https://overpass-api.de/api/interpreter',{method:'POST',body:q});
   const j=await res.json();
   list=(j.elements||[]).map(x=>({name:x.tags.name||x.tags.brand||'Benzinkút',lat:x.lat||x.center?.lat,lon:x.lon||x.center?.lon,brand:x.tags.brand||'',price:null,source:'OpenStreetMap'})).filter(x=>x.lat&&x.lon).slice(0,20);
   nearbyPricedStations=[];
  }
  stationLayer.clearLayers();$('stations').innerHTML='';
  list.forEach(s=>{
   L.marker([s.lat,s.lon]).addTo(stationLayer).bindPopup(s.name+(Number.isFinite(s.price)?`<br>${s.price.toFixed(3)} €/l`:'' ));
   const el=document.createElement('div');el.className='station';
   const title=document.createElement('b');title.textContent=s.name;el.appendChild(title);
   const sm=document.createElement('small');
   sm.textContent=Number.isFinite(s.price)?`${s.price.toFixed(3)} €/l · ${s.dist!==null?s.dist.toFixed(1)+' km · ':''}${s.isOpen===true?'Geöffnet':s.isOpen===false?'Geschlossen':'Nyitvatartás nem ismert'} · ${s.source}`:(s.brand|| (vehicle.fuel==='Elektromos'?'Töltőállomás':'Ár nem elérhető'))+' · '+s.source;
   el.appendChild(sm);$('stations').appendChild(el);
  });
  const cheapest=nearbyPricedStations.slice().sort((a,b)=>a.price-b.price)[0];
  $('stationStatus').textContent=list.length?`${list.length} találat`:'Nem találtunk állomást.';
  if(cheapest){$('stationStatus').textContent+=` · Legolcsóbb: ${cheapest.price.toFixed(3)} €/l`;}
  if(priceFetchedAt) $('stationStatus').textContent+=` · Frissítve ${priceFetchedAt.toLocaleTimeString('hu-HU',{hour:'2-digit',minute:'2-digit'})}`;
  if(lastRoute && vehicle.fuel!=='Elektromos'){
    const price=bestKnownPrice();
    if(price){const litres=(lastRoute.route.distance/1000)*vehicle.consumption/100;$('routeInfo').textContent+=` Útvonal üzemanyagköltsége kb. ${(litres*price.value).toFixed(2)} € (${price.label}).`;}
  }
 }catch(e){$('stationStatus').textContent=e.message||'Az ár-/állomáskeresés most nem elérhető.';}
};
$('editVehicle').onclick=()=>{$('vName').value=vehicle.name;$('vFuel').value=vehicle.fuel;$('vTank').value=vehicle.tank;$('vConsumption').value=vehicle.consumption;$('vPercent').value=vehicle.percent;$('vReserve').value=vehicle.reserve;$('vConnector').value=vehicle.connector||'type2';$('vChargePower').value=vehicle.chargePower||11;$('vFuelType').value=vehicle.fuelType||'e10';$('vManualPrice').value=vehicle.manualPrice||'';$('vFuelApiKey').value=vehicle.apiKey||'';$('evFields').classList.toggle('hidden', $('vFuel').value!=='Elektromos');$('fuelPriceFields').classList.toggle('hidden',$('vFuel').value==='Elektromos');$('vehicleModal').classList.remove('hidden')};
$('vFuel').onchange=()=>{$('evFields').classList.toggle('hidden',$('vFuel').value!=='Elektromos');$('fuelPriceFields').classList.toggle('hidden',$('vFuel').value==='Elektromos');};
$('saveVehicle').onclick=()=>{vehicle={name:$('vName').value||'Saját jármű',fuel:$('vFuel').value,tank:Math.max(1,+$('vTank').value||55),consumption:Math.max(.1,+$('vConsumption').value||7.5),percent:Math.min(100,Math.max(0,+$('vPercent').value||0)),reserve:Math.min(50,Math.max(0,+$('vReserve').value||0)),connector:$('vConnector').value,chargePower:Math.max(1,+$('vChargePower').value||11),fuelType:$('vFuelType').value,manualPrice:Math.max(0,+$('vManualPrice').value||0),apiKey:$('vFuelApiKey').value.trim()};localStorage.setItem('lindVehicle',JSON.stringify(vehicle));updateVehicle();if(lastRoute&&vehicle.fuel!=='Elektromos'){const price=bestKnownPrice();const litres=(lastRoute.route.distance/1000)*vehicle.consumption/100;if(price)$('routeInfo').textContent+=` Becsült költség: ${(litres*price.value).toFixed(2)} € (${price.label}).`;} $('vehicleModal').classList.add('hidden')};
$('editTolls').onclick=()=>{renderTollEditor();$('tollModal').classList.remove('hidden')};
$('saveTolls').onclick=()=>{
 tollVehicleClass=$('tollVehicleClass').value;
 document.querySelectorAll('#tollEditor [data-country]').forEach(el=>{const c=el.dataset.country,f=el.dataset.field;tollRecords[c]=tollRecords[c]||{};tollRecords[c][f]=el.value;});
 tripCountries=[...$('tripCountryChecks').querySelectorAll('input:checked')].map(x=>x.value);
 tolls=Object.keys(tollRecords).filter(c=>tollRecords[c].validUntil);
 localStorage.setItem('lindTolls',JSON.stringify(tolls));
 localStorage.setItem('lindTollRecords',JSON.stringify(tollRecords));
 localStorage.setItem('lindTripCountries',JSON.stringify(tripCountries));
 localStorage.setItem('lindTollVehicleClass',tollVehicleClass);
 updateTolls();checkTripTolls();$('tollModal').classList.add('hidden');
};
document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>$ (b.dataset.close).classList.add('hidden'));
updateVehicle();updateTolls();setTimeout(locate,700);
if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));




async function rerouteFrom(lat,lon){
 if(!lastRoute||rerouting||Date.now()-lastRerouteAt<20000)return;
 rerouting=true;lastRerouteAt=Date.now();$('driveStatus').textContent='Újratervezés…';
 try{
  const dest=lastRoute.destination;
  const url=`https://router.project-osrm.org/route/v1/driving/${lon},${lat};${dest[1]},${dest[0]}?overview=full&geometries=geojson&steps=true`;
  const response=await fetch(url);const data=await response.json();
  if(data.code!=='Ok'||!data.routes?.length)throw new Error('Nem található új útvonal.');
  const r=data.routes[0];routeChoices=[r];lastRoute={route:r,destination:dest,index:0};routeCoords=r.geometry.coordinates;renderRouteChoices(0);
  navSteps=(r.legs||[]).flatMap(l=>l.steps||[]).map(s=>({name:s.name||'',type:s.maneuver?.type||'continue',modifier:s.maneuver?.modifier||'',instruction:formatManeuver(s),distance:s.distance||0,location:s.maneuver?.location||null,lanes:s.intersections?.[0]?.lanes||[],bearings:s.intersections?.[0]?.bearings||[]}));
  activeStep=-1;offRouteCount=0;
  if(routeLayer)map.removeLayer(routeLayer);
  routeLayer=L.geoJSON(r.geometry,{style:{color:'#b58cff',weight:6,opacity:.95}}).addTo(map);
  $('driveStatus').textContent='Új útvonal elkészült.';
  $('maneuverText').textContent=navSteps[0]?.instruction||'Kövesd az útvonalat';
  $('maneuverDistance').textContent=navSteps[0]?formatDistance(navSteps[0].distance):'—';
  $('distance').textContent=(r.distance/1000).toFixed(0)+' km';
  $('duration').textContent=Math.round(r.duration/3600)+' ó '+Math.round((r.duration%3600)/60)+' p';
 }catch(e){$('driveStatus').textContent=e.message||'Az újratervezés nem sikerült.';}
 finally{rerouting=false;}
}
function renderLaneGuidance(step){
 const panel=$('lanePanel'),target=$('laneGuidance');
 const lanes=step?.lanes||[];
 if(!lanes.length){panel.classList.add('hidden');target.innerHTML='';return;}
 panel.classList.remove('hidden');target.innerHTML='';
 lanes.forEach(lane=>{
  const item=document.createElement('span');item.className='lane';
  const indications=lane.indications||[];
  item.textContent=indications.map(x=>({left:'↰',slight_left:'↖',straight:'↑',slight_right:'↗',right:'↱',uturn:'↶'}[x]||'↑')).join(' ');
  if(lane.valid)item.classList.add('lane-valid');
  target.appendChild(item);
 });
}

function formatDistance(m){return m>=1000?(m/1000).toFixed(1)+' km':Math.round(m)+' m';}
function formatManeuver(step){
 const map={turn:'Fordulj', 'new name':'Haladj tovább',depart:'Indulj el',arrive:'Megérkeztél',merge:'Csatlakozz','on ramp':'Hajts fel','off ramp':'Hajts le',fork:'Tarts',roundabout:'Hajts be a körforgalomba','exit roundabout':'Hagyd el a körforgalmat',continue:'Haladj tovább','end of road':'Az út végén fordulj'};
 const t=step.type||'continue',m=step.modifier||'';
 const phrase=map[t]||'Haladj tovább';
 const direction=m?({left:'balra',right:'jobbra',slight_left:'enyhén balra',slight_right:'enyhén jobbra',sharp_left:'élesen balra',sharp_right:'élesen jobbra',uturn:'fordulj vissza',straight:'egyenesen'}[m]||m):'';
 return [phrase,direction,step.name].filter(Boolean).join(' ');
}
function nearestRouteProgress(lat,lon){
 let best=Infinity,bestIndex=0;
 for(let i=0;i<routeCoords.length;i+=Math.max(1,Math.floor(routeCoords.length/1200))){
  const c=routeCoords[i],d=haversine(lat,lon,c[1],c[0]);if(d<best){best=d;bestIndex=i;}
 }
 let progress=0;
 for(let i=1;i<=bestIndex;i++)progress+=haversine(routeCoords[i-1][1],routeCoords[i-1][0],routeCoords[i][1],routeCoords[i][0])*1000;
 return {progress,offRoute:best};
}
function startLocationWatch(){
 if(!navigator.geolocation){$('driveStatus').textContent='A GPS nem érhető el ebben a környezetben.';return;}
 if(watchId!==null)navigator.geolocation.clearWatch(watchId);
 watchId=navigator.geolocation.watchPosition(async p=>{
  const lat=p.coords.latitude,lon=p.coords.longitude;
  setCurrent(lat,lon);
  const speed=p.coords.speed;
  $('liveSpeed').textContent=speed===null||!Number.isFinite(speed)?'—':Math.round(speed*3.6)+' km/h';
  const prog=nearestRouteProgress(lat,lon);
  let cumulative=0,idx=0;
  for(let i=0;i<navSteps.length;i++){cumulative+=navSteps[i].distance;if(cumulative>=prog.progress){idx=i;break;}idx=i;}
  const step=navSteps[idx];
  if(step){
   $('maneuverText').textContent=step.instruction;
   $('maneuverDistance').textContent=formatDistance(Math.max(0,cumulative-prog.progress));
   $('maneuverIcon').textContent=step.modifier.includes('left')?'↰':step.modifier.includes('right')?'↱':step.type==='arrive'?'◎':'↑';
   renderLaneGuidance(step);if(idx!==activeStep){activeStep=idx;if(voiceEnabled&&idx>=0)speakInstruction(step);}
  }
  if(prog.offRoute>0.12){offRouteCount++;$('driveStatus').textContent='Eltérés az útvonaltól – újratervezés előkészítése…';if(offRouteCount>=3)rerouteFrom(lat,lon);}else{offRouteCount=0;$('driveStatus').textContent='GPS-követés aktív';}
  if(Date.now()-lastSpeedLookup>60000){lastSpeedLookup=Date.now();lookupSpeedLimit(lat,lon);}
 },e=>{$('driveStatus').textContent=e.code===1?'Helyhozzáférés megtagadva. Engedélyezd a GPS-t.':'GPS-jel nem érhető el.';},{enableHighAccuracy:true,maximumAge:3000,timeout:20000});
}
function speakInstruction(step){
 if(!('speechSynthesis' in window))return;
 const utter=new SpeechSynthesisUtterance(step.instruction);
 utter.lang='hu-HU';utter.rate=1.0;window.speechSynthesis.cancel();window.speechSynthesis.speak(utter);
}
async function lookupSpeedLimit(lat,lon){
 try{
  const q=`[out:json][timeout:8];way(around:35,${lat},${lon})[highway][maxspeed];out tags 5;`;
  const r=await fetch('https://overpass-api.de/api/interpreter',{method:'POST',body:q});
  const j=await r.json();const found=(j.elements||[]).map(x=>x.tags?.maxspeed).find(Boolean);
  lastSpeedLimit=found||'—';$('speedLimit').textContent=lastSpeedLimit==='—'?'—':lastSpeedLimit;
 }catch(e){$('speedLimit').textContent='—';}
}
$('voiceToggle').onclick=()=>{
 voiceEnabled=!voiceEnabled;$('voiceToggle').textContent=voiceEnabled?'HANG: BE':'HANG: KI';
 if(!voiceEnabled&&'speechSynthesis'in window)window.speechSynthesis.cancel();
 if(voiceEnabled&&navSteps[activeStep])speakInstruction(navSteps[activeStep]);
};

async function planFuelStops(){
 const result=$('planStopsResult');
 if(!lastRoute){result.textContent='Először tervezz útvonalat.';return}
 result.textContent='Tankolási pontok keresése az útvonal mentén…';
 try{
  const coords=lastRoute.route.geometry.coordinates;
  const kmTotal=lastRoute.route.distance/1000;
  const usable=vehicle.tank*vehicle.percent/100;
  const reserve=vehicle.tank*vehicle.reserve/100;
  const required=kmTotal*vehicle.consumption/100;
  const range=vehicle.consumption>0?usable/vehicle.consumption*100:0;
  if(required+reserve<=usable){
    result.innerHTML=`<b class="good">Várhatóan megállás nélkül eléred a célt.</b><br>Tervezett fogyasztás: ${required.toFixed(1)} ${vehicle.fuel==='Elektromos'?'kWh':'liter'}. Becsült érkezési tartalék: ${(usable-required).toFixed(1)} ${vehicle.fuel==='Elektromos'?'kWh':'liter'}.`;
    return;
  }
  const sampleCount=Math.min(18,Math.max(4,Math.ceil(kmTotal/35)));
  const samples=[];
  for(let i=0;i<=sampleCount;i++){
    const idx=Math.min(coords.length-1,Math.floor(i*(coords.length-1)/sampleCount));
    const c=coords[idx];samples.push([c[1],c[0]]);
  }
  const stationTag=vehicle.fuel==='Elektromos'?'[amenity=charging_station]':'[amenity=fuel]';const clauses=samples.map(([lat,lon])=>`node(around:3500,${lat},${lon})${stationTag};way(around:3500,${lat},${lon})${stationTag};`).join('');
  const query=`[out:json][timeout:25];(${clauses});out center tags;`;
  const response=await fetch('https://overpass-api.de/api/interpreter',{method:'POST',body:query});
  if(!response.ok)throw new Error('A benzinkút-adatbázis most nem válaszol.');
  const data=await response.json();
  const seen=new Set(), candidates=[];
  for(const x of data.elements||[]){
    const lat=x.lat||x.center?.lat,lon=x.lon||x.center?.lon;
    if(!lat||!lon)continue;
    const key=`${lat.toFixed(4)},${lon.toFixed(4)}`;if(seen.has(key))continue;seen.add(key);
    let best={dist:Infinity,along:0};
    for(let i=0;i<coords.length;i+=Math.max(1,Math.floor(coords.length/300))){
      const c=coords[i],d=haversine(lat,lon,c[1],c[0]);
      if(d<best.dist)best={dist:d,along:kmTotal*(i/(coords.length-1))};
    }
    if(best.dist<3.5)candidates.push({lat,lon,name:x.tags.name||x.tags.brand||(vehicle.fuel==='Elektromos'?'Töltőállomás':'Benzinkút'),brand:x.tags.brand||'',along:best.along,detour:best.dist,connectors:Object.keys(x.tags||{}).filter(k=>k.startsWith('socket:')).map(k=>k.replace('socket:','').toUpperCase())});
  }
  candidates.sort((a,b)=>a.along-b.along);
  stationLayer.clearLayers();
  const safeCandidates=candidates.filter(s=>s.along<=Math.max(0,range-10));
  safeCandidates.slice(0,25).forEach(s=>L.marker([s.lat,s.lon]).addTo(stationLayer).bindPopup(`${s.name}<br>Útvonal menti pont: ${s.along.toFixed(0)} km${s.connectors?.length?'<br>Csatlakozók: '+s.connectors.join(', '):''}`));
  if(!safeCandidates.length){
    result.innerHTML=`<b class="warningtext">A megadott hatótávon belül nem találtunk megfelelő benzinkutat az útvonal közelében.</b><br>Indulás előtt töltsd fel a tankot, vagy ellenőrizd a fogyasztási és üzemanyagszint-adatokat.`;
    return;
  }
  const first=safeCandidates[0];
  result.innerHTML=`<b class="good">${vehicle.fuel==='Elektromos'?'Töltési megálló javasolt':'Tankolási megálló javasolt'}</b><br><strong>${escapeHtml(first.name)}</strong><br>Körülbelül ${first.along.toFixed(0)} km-re az indulástól · ${first.detour.toFixed(1)} km-re az útvonaltól.${first.connectors?.length?'<br>OSM szerint jelölt csatlakozók: '+first.connectors.join(', '):''}<br><small>${safeCandidates.length} útvonal közeli ${vehicle.fuel==='Elektromos'?'töltőállomás':'benzinkút'} található. A megálló javaslat becslés; az állomás működését, csatlakozó-kompatibilitását és elérhetőségét ellenőrizd.</small>`;
  map.setView([first.lat,first.lon],12);
 }catch(e){result.textContent=e.message||'Nem sikerült elkészíteni a tankolási tervet.';}
}
function haversine(lat1,lon1,lat2,lon2){const R=6371,toRad=v=>v*Math.PI/180;const dLat=toRad(lat2-lat1),dLon=toRad(lon2-lon1);const a=Math.sin(dLat/2)**2+Math.cos(toRad(lat1))*Math.cos(toRad(lat2))*Math.sin(dLon/2)**2;return 2*R*Math.asin(Math.sqrt(a));}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
