const app=document.querySelector('#app');

const defaultPosts=[
 {id:1,author:'NexaBot',circle:'Ideas',text:'Welcome to NexaCircle — share useful ideas, discover communities, and connect respectfully.',likes:24,comments:[]},
 {id:2,author:'Amina K.',circle:'Creators',text:'What is one skill you are learning this month?',likes:12,comments:[]},
 {id:3,author:'Brian M.',circle:'Local',text:'A simple community challenge: help one person with useful information today.',likes:8,comments:[]}
];
let posts=JSON.parse(localStorage.getItem('nc_posts')||'null')||defaultPosts;
let user=JSON.parse(localStorage.getItem('nc_user')||'null');
let page='feed';

function save(){localStorage.setItem('nc_posts',JSON.stringify(posts));localStorage.setItem('nc_user',JSON.stringify(user));}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));}

function layout(content){
 app.innerHTML=`<div class="shell">
 <header class="top"><div class="brand">◉ NexaCircle</div><div class="tag">Communities. Ideas. People.</div></header>
 <main class="main">${content}</main>
 <div class="footer">NexaCircle • Respect people • Protect privacy • Report abuse</div>
 </div>`;
}

function welcome(){
 layout(`<section class="hero"><span class="pill">COMMUNITY-FIRST</span><h1>NexaCircle</h1>
 <p class="muted">A fresh social network built around interest Circles and safer community interaction.</p>
 <div class="card"><button onclick="register()">Create account</button><br><br>
 <button class="secondary" onclick="login()">Sign in</button><br><br>
 <button class="secondary" onclick="guidelines()">Community Guidelines</button></div></section>`);
}

function register(){
 layout(`<div class="card"><h2>Create your account</h2>
 <input class="input" id="name" placeholder="Display name">
 <input class="input" id="email" type="email" placeholder="Email">
 <input class="input" id="pass" type="password" placeholder="Password (8+ characters)">
 <button onclick="createAccount()">Create account</button>
 <button class="secondary" onclick="welcome()">Back</button></div>`);
}
function createAccount(){
 const n=document.querySelector('#name').value.trim(),e=document.querySelector('#email').value.trim(),p=document.querySelector('#pass').value;
 if(!n||!e||p.length<8){alert('Enter a name, email and password of at least 8 characters.');return}
 user={name:n,email:e};save();feed();
}
function login(){register();}

function nav(){
 return `<div class="nav">
 <button class="${page==='feed'?'active':''}" onclick="feed()">Feed</button>
 <button class="${page==='circles'?'active':''}" onclick="circles()">Circles</button>
 <button class="${page==='create'?'active':''}" onclick="createPost()">Create</button>
 <button class="${page==='profile'?'active':''}" onclick="profile()">Profile</button>
 </div>`;
}
function feed(){
 if(!user){welcome();return}
 page='feed';
 let html=nav()+`<div class="card"><b>Hello, ${esc(user.name)} 👋</b><p class="muted">Discover conversations that match your interests.</p></div>`;
 posts.forEach(p=>html+=postCard(p));
 layout(html);
}
function postCard(p){
 return `<article class="card"><div><b>${esc(p.author)}</b> <span class="pill">${esc(p.circle)}</span></div>
 <p class="posttext">${esc(p.text)}</p>
 <div class="actions"><button onclick="like(${p.id})">♥ ${p.likes}</button>
 <button onclick="comment(${p.id})">Comment</button>
 <button onclick="report(${p.id})">Report</button>
 <button onclick="block('${esc(p.author)}')">Block</button></div>
 </article>`;
}
function like(id){const p=posts.find(x=>x.id===id);p.likes++;save();feed();}
function comment(id){const t=prompt('Write a respectful comment:');if(t){posts.find(x=>x.id===id).comments.push(t);save();alert('Comment added in this demo.');}}
function report(id){alert('Report submitted for moderation review. In production this will be sent to the moderation backend.');}
function block(name){alert(`Demo: ${name} would be added to your blocked-user list.`);}

function createPost(){
 if(!user){welcome();return}page='create';
 layout(nav()+`<div class="card"><h2>Create a post</h2>
 <input class="input" id="circle" placeholder="Circle (Ideas, Creators, Local...)">
 <textarea id="body" rows="6" placeholder="Share something useful or positive..."></textarea>
 <button onclick="publish()">Publish</button></div>`);
}
function publish(){
 const text=document.querySelector('#body').value.trim(),circle=document.querySelector('#circle').value.trim()||'General';
 if(!text){alert('Write something first.');return}
 posts.unshift({id:Date.now(),author:user.name,circle,text,likes:0,comments:[]});save();feed();
}
function circles(){
 if(!user){welcome();return}page='circles';
 const cs=[['Ideas','Practical knowledge and discussions'],['Creators','Art, writing, music and projects'],['Local','Community activities and useful updates'],['Learning','Study, careers and skills'],['Wellbeing','Supportive everyday conversations']];
 layout(nav()+`<div class="card"><h2>Discover Circles</h2>${cs.map(c=>`<div class="card circle"><div><b>${c[0]}</b><br><span class="muted">${c[1]}</span></div><button onclick="join('${c[0]}')">Join</button></div>`).join('')}</div>`);
}
function join(c){alert(`You joined the ${c} Circle in this demo.`);}
function profile(){
 if(!user){welcome();return}page='profile';
 layout(nav()+`<div class="card"><h2>${esc(user.name)}</h2><p>${esc(user.email)}</p>
 <p class="muted">Followers: 0 • Following: 0</p>
 <button class="secondary" onclick="guidelines()">Community Guidelines</button>
 <button class="danger" onclick="logout()">Sign out</button></div>`);
}
function logout(){user=null;localStorage.removeItem('nc_user');welcome();}
function guidelines(){
 layout(`<div class="card"><h2>Community Guidelines</h2><p>Respect people and local laws.</p>
 <ul><li>No threats, harassment or targeted abuse.</li><li>No sexual exploitation or sexual content involving minors.</li>
 <li>No scams, fraud, impersonation or deceptive schemes.</li><li>No doxxing or sharing private personal information without permission.</li>
 <li>No spam, coordinated manipulation or malicious automation.</li><li>Respect intellectual-property rights.</li></ul>
 <p>Use Report and Block when content violates the rules. Difficult cases should receive human review and an appeal path.</p>
 <button onclick="${user?'feed()':'welcome()'}">Back</button></div>`);
}
if(user) feed(); else welcome();
