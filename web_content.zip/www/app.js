const KEY='ahmed_private_manager_v1';
const defaults={
  profile:{name:'أحمد أبو الحجاج',service:'المهندس أحمد أبو الحجاج',photo:'assets/ahmed-profile.jpg'},
  settings:{examRate:10,consultRate:5},
  ratio:[], tickets:[], expenses:[], credentials:[], services:{research:[],computer:[],online:[],documents:[],other:[]}, wallets:[{id:'cash',name:'💵 كاش'},{id:'visa',name:'💳 فيزا'},{id:'pocket',name:'👝 محفظة الجيب'}], visaBanks:[{id:'aaib',name:'💳 البنك العربي الأفريقي الدولي'},{id:'arab',name:'💳 البنك العربي'},{id:'bdc',name:'💳 بنك القاهرة'},{id:'bm',name:'💳 بنك مصر'},{id:'boa',name:'💳 بنك الإسكندرية'},{id:'cib',name:'💳 CIB البنك التجاري الدولي'},{id:'egb',name:'💳 البنك المصري الخليجي'},{id:'nbe',name:'💳 البنك الأهلي المصري'},{id:'qnb',name:'💳 QNB الأهلي'},{id:'saib',name:'💳 بنك SAIB'},{id:'edbe',name:'💳 بنك تنمية الصادرات'},{id:'aib',name:'💳 البنك العربي الدولي'},{id:'faisal',name:'💳 بنك فيصل الإسلامي المصري'},{id:'albaraka',name:'💳 بنك البركة مصر'},{id:'attijari',name:'💳 بنك التجاري وفا بنك مصر'},{id:'adib',name:'💳 مصرف أبو ظبي الإسلامي مصر'},{id:'abk',name:'💳 بنك الأهلي الكويتي مصر'},{id:'hdb',name:'💳 بنك التعمير والإسكان'},{id:'nbk',name:'💳 بنك الكويت الوطني مصر'},{id:'ealbank',name:'💳 البنك العقاري المصري العربي'},{id:'scb',name:'💳 بنك قناة السويس'},{id:'aub',name:'💳 البنك الأهلي المتحد'},{id:'ub',name:'💳 المصرف المتحد'},{id:'hsbc',name:'💳 HSBC مصر'},{id:'adcb',name:'💳 بنك أبو ظبي التجاري مصر'},{id:'fab',name:'💳 بنك أبو ظبي الأول مصر'},{id:'citi',name:'💳 سيتي بنك مصر'},{id:'creditag',name:'💳 كريدي أجريكول مصر'},{id:'mashreq',name:'💳 بنك المشرق مصر'},{id:'enbd',name:'💳 بنك الإمارات دبي الوطني مصر'},{id:'banknxt',name:'💳 Bank NXT'},{id:'abc',name:'💳 بنك ABC'},{id:'midbank',name:'💳 MIDBANK'},{id:'idb',name:'💳 بنك التنمية الصناعية'},{id:'abe',name:'💳 البنك الزراعي المصري'}],cashWallets:[{id:'etisalat',name:'📱 اتصالات كاش'},{id:'orange',name:'🟠 أورانج كاش'},{id:'vodafone',name:'🔴 فودافون كاش'}]
};
let db=load();
let current='home';
let editing=null;
let credentialEditing=null;

function load(){try{const saved=JSON.parse(localStorage.getItem(KEY)||'{}');const out={...defaults,...saved};out.settings={...defaults.settings,...(saved.settings||{})};out.profile={...defaults.profile,...(saved.profile||{})};out.wallets=structuredClone(defaults.wallets);out.visaBanks=structuredClone(defaults.visaBanks);out.cashWallets=structuredClone(defaults.cashWallets);out.ratio.forEach(x=>{if(!x.entryTime)x.entryTime='';if(!x.exitTime)x.exitTime=''});out.tickets.forEach(x=>{if(!x.entryTime)x.entryTime='';if(!x.exitTime)x.exitTime=''});out.expenses.forEach(x=>{if(!x.entryTime)x.entryTime='';if(!x.exitTime)x.exitTime='';if(!x.visaBankId&&x.visaBank)x.visaBankId=x.visaBank});out.ratio=saved.ratio||[];out.tickets=saved.tickets||[];out.expenses=saved.expenses||[];out.credentials=saved.credentials||[];out.credentials.forEach(x=>{if(!x.entryTime)x.entryTime='';if(!x.exitTime)x.exitTime='' });out.services={research:[],computer:[],online:[],documents:[],other:[],...(saved.services||{})};Object.keys(out.services).forEach(k=>{if(!Array.isArray(out.services[k]))out.services[k]=[];out.services[k].forEach(x=>{if(!x.entryTime)x.entryTime='';if(!x.exitTime)x.exitTime=''})});out.expenses.forEach(x=>{if(!x.cashWalletId&&x.cashWallet)x.cashWalletId=x.cashWallet;if(!x.cashWalletId&&x.walletId==='cash')x.cashWalletId='vodafone';if(!x.walletId){x.walletId=x.wallet==='visa'?'visa':x.wallet==='pocket'?'pocket':'cash'}; if(x.walletId!=='cash'&&x.walletId!=='visa'&&x.walletId!=='pocket')x.walletId='cash'});return out}catch(e){return structuredClone(defaults)}}
function save(){localStorage.setItem(KEY,JSON.stringify(db))}
function money(n){return Number(n||0).toLocaleString('ar-EG',{minimumFractionDigits:0,maximumFractionDigits:2})+' جنيه'}
function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function uid(){return Date.now().toString(36)+Math.random().toString(36).slice(2,7)}
function toast(t){const el=document.getElementById('toast');el.textContent=t;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),1800)}
function today(){return new Date().toISOString().slice(0,10)}
function nowTime(){return new Date().toTimeString().slice(0,5)}
function dateAr(d){if(!d)return ''; return new Date(d+'T00:00:00').toLocaleDateString('ar-EG',{year:'numeric',month:'long',day:'numeric'})}
function sum(a,fn){return a.reduce((x,v)=>x+Number(fn(v)||0),0)}

function nav(){
 document.querySelectorAll('.bottom-nav button').forEach(b=>b.classList.toggle('active',b.dataset.page===current));
 const titles={home:['الرئيسية','إدارتي الخاصة'],services:['الخدمات','متابعة خدمات العملاء'],service_research:['الأبحاث والكتابة','طلبات العملاء ومواعيد التسليم'],service_computer:['خدمات الكمبيوتر والملفات','طلبات العملاء ومواعيد التسليم'],service_online:['الخدمات أونلاين','طلبات العملاء ومواعيد التسليم'],service_documents:['المستندات والنماذج','طلبات العملاء ومواعيد التسليم'],service_other:['الخدمات الأخرى','طلبات العملاء ومواعيد التسليم'],ratio:['حساب النسبة','الكشوفات والاستشارات'],tickets:['حجز التذاكر','متابعة حجوزات القطارات'],expenses:['المصاريف','الرصيد والمصروفات'],privacy:['خصوصيتي','البيانات السرية فقط'],settings:['الإعدادات','إعدادات التطبيق']};
 document.getElementById('topTitle').textContent=titles[current][0];
 document.getElementById('topSubtitle').textContent=titles[current][1];
 document.getElementById('backBtn').style.visibility=current==='home'?'hidden':'visible';
}
function render(){nav(); const page=document.getElementById('page'); page.innerHTML=pages[current](); bind()}
const serviceConfig={
  research:{title:'الأبحاث والكتابة',icon:'📚',key:'research',needsName:false},
  computer:{title:'خدمات الكمبيوتر والملفات',icon:'💻',key:'computer',needsName:true},
  online:{title:'الخدمات أونلاين',icon:'📱',key:'online',needsName:true},
  documents:{title:'المستندات والنماذج',icon:'📄',key:'documents',needsName:true},
  other:{title:'الخدمات الأخرى',icon:'⚙️',key:'other',needsName:true}
};
function servicePage(type){const c=serviceConfig[type], arr=db.services[c.key]||[]; const total=sum(arr,x=>x.amount); const e=editing&&editing.__serviceType===type?editing:null;
 return `<div class="card"><div class="section-title"><h2>${e?'تعديل طلب':'إضافة طلب'} ${c.icon}</h2></div><form id="serviceForm" class="form">
 <div class="row"><div><label>اليوم والتاريخ</label><input id="sdate" type="date" value="${e?esc(e.date):today()}"></div><div><label>اسم العميل</label><input id="sclient" value="${e?esc(e.client):''}"></div></div>
 <div class="row"><div><label>رقم الهاتف</label><input id="sphone" type="tel" value="${e?esc(e.phone):''}"></div><div><label>الموعد المحدد للتسليم</label><input id="sdeadline" type="date" value="${e?esc(e.deadline):today()}"></div></div>
 ${c.needsName?`<div><label>اسم الخدمة التي تم عملها</label><input id="sservice" placeholder="مثال: تنسيق Word / تحويل PDF / شحن رصيد" value="${e?esc(e.serviceName||''):''}"></div>`:''}
 <div class="row"><div><label>وقت التسجيل</label><input id="sentryTime" type="time" value="${e?esc(e.entryTime||nowTime()):nowTime()}"></div><div><label>وقت السحب / التسليم</label><input id="sexitTime" type="time" value="${e?esc(e.exitTime||''):''}"></div></div>
 <div><label>المبلغ المطلوب</label><input id="samount" type="number" min="0" step="0.01" value="${e?e.amount:0}"></div>
 <div><label>ملاحظات (اختياري)</label><input id="snote" value="${e?esc(e.note||''):''}"></div>
 <button class="btn" type="submit">${e?'حفظ التعديل':'حفظ الطلب'}</button>${e?'<button class="btn secondary" type="button" onclick="cancelEdit()">إلغاء التعديل</button>':''}</form></div>
 <div class="section-title"><h2>إجمالي ${c.title}</h2></div><div class="stat-grid"><div class="stat"><div class="muted">عدد الطلبات</div><div class="num">${arr.length}</div></div><div class="stat"><div class="muted">إجمالي المبالغ</div><div class="num">${money(total)}</div></div></div>
 <div class="section-title"><h2>الطلبات المحفوظة</h2></div><div class="list">${arr.length?arr.slice().sort((a,b)=>b.date.localeCompare(a.date)).map(x=>`<div class="item"><div class="item-head"><span>${dateAr(x.date)} — ${esc(x.client||'بدون اسم')}</span><span>${money(x.amount)}</span></div><div class="item-meta">📞 ${esc(x.phone||'—')}<br>📅 التسليم: ${dateAr(x.deadline)}${x.serviceName?`<br>🛠️ الخدمة: ${esc(x.serviceName)}`:''}${x.note?`<br>📝 ${esc(x.note)}`:''}<br>⏰ التسجيل: ${esc(x.entryTime||'—')} — التسليم/السحب: ${esc(x.exitTime||'—')}</div><div class="item-actions"><button class="mini" data-action="editService" data-key="${c.key}" data-id="${x.id}">تعديل</button><button class="mini danger" data-action="delService" data-key="${c.key}" data-id="${x.id}">حذف</button></div></div>`).join(''):'<div class="empty">لا توجد طلبات محفوظة في هذه الخدمة.</div>'}</div>`;
}
const pages={
home:()=>`<section class="hero home-only">
  <div class="home-logo">AA</div>
  <div class="welcome-title">أهلاً وسهلاً بك</div>
  <img class="profile-photo" src="${esc(db.profile.photo||'assets/profile-placeholder.svg')}" onerror="this.src='assets/profile-placeholder.svg'">
  <h1 class="home-name">${esc(db.profile.name)}</h1>
  <div class="home-service">${esc(db.profile.service)}</div>
  <div class="home-subtitle service-types">
    <span>📚 الأبحاث والكتابة</span>
    <span>💻 خدمات الكمبيوتر والملفات</span>
    <span>📱 خدمات أونلاين إضافية</span>
    <span>📄 المستندات والنماذج</span>
    <span>⚙️ خدمات أخرى</span>
    <span>🚆 حجز تذاكر القطارات أونلاين</span>
  </div>
</section>`,
ratio:()=>{const exRate=Number(db.settings.examRate||10), coRate=Number(db.settings.consultRate||5);
 const totalEx=sum(db.ratio,x=>x.examTotal), totalCo=sum(db.ratio,x=>x.consultTotal);
 return `<div class="card"><div class="section-title"><h2>${editing?'تعديل يوم':'إضافة يوم'}</h2></div>
 <form id="ratioForm" class="form">
 <div class="row"><div><label>اليوم</label><input id="rdate" type="date" value="${editing?esc(editing.date):today()}"></div><div><label>عدد الكشوفات</label><input id="rex" type="number" min="0" value="${editing?editing.exams:0}"></div></div>
 <div class="row"><div><label>سعر الكشف</label><input id="rerate" disabled value="${editing?editing.examRate:exRate}"></div><div><label>إجمالي الكشوفات</label><input id="retotal" disabled value="${money((editing?editing.exams:0)*(editing?editing.examRate:exRate))}"></div></div>
 <div class="row"><div><label>عدد الاستشارات</label><input id="rco" type="number" min="0" value="${editing?editing.consults:0}"></div><div><label>سعر الاستشارة</label><input id="rcorate" disabled value="${editing?editing.consultRate:coRate}"></div></div>
 <div class="row"><div><label>وقت التسجيل</label><input id="rentryTime" type="time" value="${editing?esc(editing.entryTime||nowTime()):nowTime()}"></div><div><label>وقت السحب / الانتهاء</label><input id="rexitTime" type="time" value="${editing?esc(editing.exitTime||''):''}"></div></div>
 <div class="row"><div><label>إجمالي الاستشارات</label><input id="rcototal" disabled value="${money((editing?editing.consults:0)*(editing?editing.consultRate:coRate))}"></div><div><label>إجمالي اليوم</label><input id="rdaytotal" disabled value="${money(0)}"></div></div>
 <button class="btn" type="submit">${editing?'حفظ التعديل':'حفظ اليوم'}</button>
 ${editing?'<button class="btn secondary" type="button" onclick="cancelEdit()">إلغاء التعديل</button>':''}
 </form></div>
 <div class="section-title"><h2>إجمالي كل الأيام</h2></div>
 <div class="stat-grid"><div class="stat"><div class="muted">الأيام</div><div class="num">${db.ratio.length}</div></div><div class="stat"><div class="muted">الكشوفات</div><div class="num">${sum(db.ratio,x=>x.exams)}</div></div><div class="stat"><div class="muted">الاستشارات</div><div class="num">${sum(db.ratio,x=>Number(x.consults||0))}</div></div><div class="stat"><div class="muted">مبلغ الكشف</div><div class="num">${money(totalEx)}</div></div><div class="stat"><div class="muted">مبلغ الاستشارة</div><div class="num">${money(totalCo)}</div></div></div>
 <div class="total-box"><div>الإجمالي الكلي</div><div class="big">${money(totalEx+totalCo)}</div></div>
 <div class="section-title"><h2>البيانات المحفوظة حسب اليوم</h2></div>
 <div class="list">${db.ratio.length?db.ratio.slice().sort((a,b)=>b.date.localeCompare(a.date)).map(x=>`<div class="item"><div class="item-head"><span>${dateAr(x.date)}</span><span>${money(x.examTotal+x.consultTotal)}</span></div><div class="item-meta">الكشوفات: ${x.exams} × ${money(x.examRate)} = ${money(x.examTotal)}<br>الاستشارات: ${x.consults} × ${money(x.consultRate)} = ${money(x.consultTotal)}<br>⏰ التسجيل: ${esc(x.entryTime||'—')} — الانتهاء/السحب: ${esc(x.exitTime||'—')}</div><div class="item-actions"><button class="mini" data-action="editRatio" data-id="${x.id}">تعديل</button><button class="mini danger" data-action="delRatio" data-id="${x.id}">حذف</button></div></div>`).join(''):'<div class="empty">لا توجد أيام محفوظة حتى الآن.</div>'}</div>`;
},
services:()=>`<div class="section-title"><h2>خدمات العملاء</h2></div><div class="service-menu">${Object.entries(serviceConfig).map(([k,c])=>`<button class="service-card" onclick="go('service_${k}')"><span>${c.icon}</span><strong>${c.title}</strong><small>${(db.services[c.key]||[]).length} طلبات محفوظة</small></button>`).join('')}</div>`,
service_research:()=>servicePage('research'),
service_computer:()=>servicePage('computer'),
service_online:()=>servicePage('online'),
service_documents:()=>servicePage('documents'),
service_other:()=>servicePage('other'),
tickets:()=>{const profit=sum(db.tickets,x=>x.myPrice);
 return `<div class="card"><div class="section-title"><h2>${editing?'تعديل حجز':'إضافة حجز'}</h2></div><form id="ticketForm" class="form">
 <div class="row"><div><label>تاريخ الحجز</label><input id="tbook" type="date" value="${editing?editing.bookDate:today()}"></div><div><label>تاريخ السفر</label><input id="ttravel" type="date" value="${editing?editing.travelDate:today()}"></div></div>
 <div class="row"><div><label>سعر التذكرة</label><input id="tprice" type="number" min="0" step="0.01" value="${editing?editing.ticketPrice:0}"></div><div><label>السعر الذي أخذته</label><input id="tmy" type="number" min="0" step="0.01" value="${editing?editing.myPrice:0}"></div></div>
 <div class="row"><div><label>وقت التسجيل</label><input id="tentryTime" type="time" value="${editing?esc(editing.entryTime||nowTime()):nowTime()}"></div><div><label>وقت السحب / التسليم</label><input id="texitTime" type="time" value="${editing?esc(editing.exitTime||''):''}"></div></div>
 <div class="row"><div><label>اسم الراكب (اختياري)</label><input id="tname" value="${editing?esc(editing.name):''}"></div><div><label>ملاحظة (اختياري)</label><input id="tnote" value="${editing?esc(editing.note):''}"></div></div>
 <button class="btn" type="submit">${editing?'حفظ التعديل':'حفظ الحجز'}</button>${editing?'<button class="btn secondary" type="button" onclick="cancelEdit()">إلغاء التعديل</button>':''}</form></div>
 <div class="section-title"><h2>الإجماليات</h2></div><div class="stat-grid"><div class="stat"><div class="muted">عدد الحجوزات</div><div class="num">${db.tickets.length}</div></div><div class="stat"><div class="muted">إجمالي التذاكر</div><div class="num">${money(sum(db.tickets,x=>x.ticketPrice))}</div></div><div class="stat"><div class="muted">إجمالي ما أخذته</div><div class="num">${money(profit)}</div></div><div class="stat"><div class="muted">الفرق</div><div class="num">${money(profit-sum(db.tickets,x=>x.ticketPrice))}</div></div></div>
 <div class="section-title"><h2>الحجوزات حسب تاريخ الحجز</h2></div><div class="list">${db.tickets.length?db.tickets.slice().sort((a,b)=>b.bookDate.localeCompare(a.bookDate)).map(x=>`<div class="item"><div class="item-head"><span>${dateAr(x.bookDate)}</span><span>${money(x.myPrice)}</span></div><div class="item-meta">السفر: ${dateAr(x.travelDate)}<br>سعر التذكرة: ${money(x.ticketPrice)} — أخذت: ${money(x.myPrice)}${x.name?'<br>الراكب: '+esc(x.name):''}${x.note?'<br>ملاحظة: '+esc(x.note):''}<br>⏰ التسجيل: ${esc(x.entryTime||'—')} — السحب/التسليم: ${esc(x.exitTime||'—')}</div><div class="item-actions"><button class="mini" data-action="editTicket" data-id="${x.id}">تعديل</button><button class="mini danger" data-action="delTicket" data-id="${x.id}">حذف</button></div></div>`).join(''):'<div class="empty">لا توجد حجوزات محفوظة.</div>'}</div>`;
},
expenses:()=>{const inc=sum(db.expenses,x=>x.type==='income'?x.amount:0), out=sum(db.expenses,x=>x.type==='expense'?x.amount:0);
 const wallets=db.wallets||[];
 const walletBalances=wallets.map(w=>({w,b:sum(db.expenses,x=>x.walletId===w.id?(x.type==='income'?x.amount:-x.amount):0)}));
 return `<div class="card"><div class="section-title"><h2>${editing?'تعديل حركة':'إضافة حركة مالية'}</h2></div><form id="expenseForm" class="form">
 <div class="row"><div><label>اليوم والتاريخ</label><input id="edate" type="date" value="${editing?editing.date:today()}"></div><div><label>الحركة</label><select id="etype"><option value="income" ${editing?.type==='income'?'selected':''}>مبلغ داخل</option><option value="expense" ${editing?.type==='expense'?'selected':''}>مصروف</option></select></div></div>
 <div class="row"><div><label>المحفظة / المكان</label><select id="ewallet">${wallets.map(w=>`<option value="${esc(w.id)}" ${editing?.walletId===w.id?'selected':''}>${esc(w.name)}</option>`).join('')}</select></div><div><label>القيمة</label><input id="eamount" type="number" min="0" step="0.01" value="${editing?editing.amount:0}"></div></div><div id="visaBankWrap" style="display:${editing?.walletId==='visa'?'block':'none'}"><label>اختيار الفيزا</label><select id="visaBank">${(db.visaBanks||[]).map(v=>`<option value="${esc(v.id)}" ${editing?.visaBankId===v.id?'selected':''}>${esc(v.name)}</option>`).join('')}</select></div><div id="cashWalletWrap" style="display:${editing?.walletId==='cash'?'block':'none'}"><label>نوع محفظة الكاش</label><select id="cashWallet">${(db.cashWallets||[]).map(v=>`<option value="${esc(v.id)}" ${editing?.cashWalletId===v.id?'selected':''}>${esc(v.name)}</option>`).join('')}</select></div>
 <div class="row"><div><label>وقت التسجيل</label><input id="eentryTime" type="time" value="${editing?esc(editing.entryTime||nowTime()):nowTime()}"></div><div><label>وقت السحب / الانتهاء</label><input id="eexitTime" type="time" value="${editing?esc(editing.exitTime||''):''}"></div></div>
 <div><label>نوع المصروف / وصف الحركة</label><input id="edesc" placeholder="مثال: مواصلات، طعام، دخل إضافي" value="${editing?esc(editing.desc):''}"></div>
 <button class="btn" type="submit">${editing?'حفظ التعديل':'حفظ الحركة'}</button>${editing?'<button class="btn secondary" type="button" onclick="cancelEdit()">إلغاء التعديل</button>':''}</form></div>
 <div class="section-title"><h2>المحافظ والأرصدة</h2></div><div class="stat-grid">${walletBalances.map(x=>`<div class="stat"><div class="muted">${esc(x.w.name)}</div><div class="num">${money(x.b)}</div></div>`).join('')}</div>
 <div class="stat-grid"><div class="stat"><div class="muted">إجمالي الداخل</div><div class="num positive">${money(inc)}</div></div><div class="stat"><div class="muted">إجمالي المصروف</div><div class="num negative">${money(out)}</div></div><div class="stat"><div class="muted">الرصيد الكلي</div><div class="num">${money(inc-out)}</div></div><div class="stat"><div class="muted">عدد الحركات</div><div class="num">${db.expenses.length}</div></div></div>
 <div class="stat-grid" style="margin-top:10px">
 <div class="stat"><div class="muted">رصيد الكاش</div><div class="num">${money(walletBalance('cash'))}</div></div>
 <div class="stat"><div class="muted">رصيد الفيزا</div><div class="num">${money(walletBalance('visa'))}</div></div>
 <div class="stat"><div class="muted">رصيد محفظة الجيب</div><div class="num">${money(walletBalance('pocket'))}</div></div>
 </div>
 <div class="total-box"><div>إجمالي المبلغ المتاح في كل الأماكن</div><div class="big">${money(walletBalances.reduce((t,x)=>t+x.b,0))}</div></div>
 <div class="section-title"><h2>الحركات حسب اليوم</h2></div><div class="list">${db.expenses.length?db.expenses.slice().sort((a,b)=>b.date.localeCompare(a.date)).map(x=>{const w=wallets.find(v=>v.id===x.walletId);const vb=(db.visaBanks||[]).find(v=>v.id===x.visaBankId);const cw=(db.cashWallets||[]).find(v=>v.id===x.cashWalletId);return `<div class="item"><div class="item-head"><span>${dateAr(x.date)}</span><span class="${x.type==='expense'?'negative':'positive'}">${x.type==='expense'?'-':'+'}${money(x.amount)}</span></div><div class="item-meta">المكان: ${esc(w?.name||'غير محدد')}${x.walletId==='visa'&&vb?`<br>البنك: ${esc(vb.name)}`:''}${x.walletId==='cash'&&cw?`<br>المحفظة: ${esc(cw.name)}`:''}<br>${esc(x.desc||'بدون وصف')}</div><div class="item-actions"><button class="mini" data-action="editExpense" data-id="${x.id}">تعديل</button><button class="mini danger" data-action="delExpense" data-id="${x.id}">حذف</button></div></div>`}).join(''):'<div class="empty">لا توجد حركات مالية محفوظة.</div>'}</div>`;
},
privacy:()=>{const e=credentialEditing; return `<div class="card"><div class="section-title"><h2>${e?'تعديل بيانات سرية':'خصوصيتي'}</h2>${!e?'<button class="mini" type="button" onclick="newCredential()">+ إضافة</button>':''}</div>
 <div class="note">هذه الصفحة للبيانات السرية التي تريد الاحتفاظ بها فقط، مثل حساباتك وأرقامك السرية. بيانات الاسم والأسعار وإعدادات التطبيق موجودة في الإعدادات.</div>
 ${e?`<form id="credentialForm" class="form"><div><label>اسم البيانات</label><input id="ctitle" value="${esc(e.title||'')}" required></div><div><label>اسم المستخدم / رقم الحساب</label><input id="cusername" value="${esc(e.username||'')}"></div><div><label>كلمة المرور / الرقم السري</label><input id="cpassword" type="text" value="${esc(e.password||'')}"></div><div class="row"><div><label>وقت التسجيل</label><input id="centryTime" type="time" value="${e?esc(e.entryTime||nowTime()):nowTime()}"></div><div><label>وقت السحب / الانتهاء</label><input id="cexitTime" type="time" value="${e?esc(e.exitTime||''):''}"></div></div><button class="btn" type="submit">حفظ البيانات</button><button class="btn secondary" type="button" onclick="cancelCredentialEdit()">إلغاء</button></form>`:''}
 <div id="credList" class="list" style="margin-top:10px">${credentialsHtml()}</div></div>`;},
settings:()=>`<div class="card"><div class="section-title"><h2>إعدادات التطبيق</h2></div><form id="profileForm" class="form">
 <div><label>اسمك</label><input id="pname" value="${esc(db.profile.name)}"></div><div><label>اسم الخدمة</label><input id="pservice" value="${esc(db.profile.service)}"></div><div><label>مسار الصورة</label><input id="pphoto" value="${esc(db.profile.photo)}"></div>
 <button class="btn" type="submit">حفظ بيانات الصفحة الرئيسية</button></form></div>
 <div class="card" style="margin-top:14px"><div class="section-title"><h2>أسعار حساب النسبة</h2></div><div class="note">سعر الكشف والاستشارة لا يمكن تغييره من صفحة النسبة. التغيير يتم من هنا فقط، ويطبق على الأيام الجديدة، بينما الأيام المحفوظة تحتفظ بسعرها القديم.</div><form id="ratesForm" class="row" style="margin-top:10px"><div><label>سعر الكشف</label><input id="setExam" type="number" min="0" step="0.01" value="${db.settings.examRate}"></div><div><label>سعر الاستشارة</label><input id="setConsult" type="number" min="0" step="0.01" value="${db.settings.consultRate}"></div><button class="btn" style="grid-column:1/-1">حفظ الأسعار</button></form></div>
 <div class="card" style="margin-top:14px"><div class="section-title"><h2>أماكن الأموال</h2></div><div class="note">المتاح في التطبيق: كاش، فيزا، ومحفظة الجيب. عند تسجيل أي مبلغ تختار مكانه من صفحة المصروفات.</div></div>
 <div class="actions"><button class="btn secondary" onclick="exportData()">نسخ احتياطي للبيانات</button><button class="btn danger" onclick="clearAll()">مسح كل البيانات</button></div>`,
};
function credentialsHtml(){return db.credentials.length?db.credentials.map(x=>`<div class="item"><div class="item-head"><span>${esc(x.title)}</span><span>${x.password?'••••••':'—'}</span></div><div class="item-meta">اسم المستخدم/الحساب: ${esc(x.username||'—')}<br>⏰ التسجيل: ${esc(x.entryTime||'—')} — الانتهاء/السحب: ${esc(x.exitTime||'—')}<br><span id="pw-${x.id}">كلمة المرور: ••••••</span></div><div class="item-actions"><button class="mini" data-action="togglePw" data-id="${x.id}">إظهار</button><button class="mini" data-action="editCredential" data-id="${x.id}">تعديل</button><button class="mini danger" data-action="delCredential" data-id="${x.id}">حذف</button></div></div>`).join(''):'<div class="empty">لم تضف أي بيانات بعد. اضغط + إضافة لإنشاء خانة جديدة.</div>'}
function bind(){
 document.onclick=(e)=>{const b=e.target.closest('[data-action]');if(!b)return;const a=b.dataset.action,id=b.dataset.id,key=b.dataset.key;if(a==='delRatio')return delRatio(id);if(a==='delTicket')return delTicket(id);if(a==='delExpense')return delExpense(id);if(a==='delService')return delService(key,id);if(a==='delCredential')return delCredential(id);if(a==='editRatio')return editRatio(id);if(a==='editTicket')return editTicket(id);if(a==='editExpense')return editExpense(id);if(a==='editService')return editService(key,id);if(a==='editCredential')return editCredential(id);if(a==='togglePw')return togglePw(id)};
 document.querySelectorAll('.bottom-nav button').forEach(b=>b.onclick=()=>go(b.dataset.page));
 const page=document.getElementById('page');
 if(page) page.onclick=(e)=>{
   const b=e.target.closest('[data-action]'); if(!b)return;
   const a=b.dataset.action,id=b.dataset.id,key=b.dataset.key;
   if(a==='editRatio') return editRatio(id);
   if(a==='delRatio') return delRatio(id);
   if(a==='editTicket') return editTicket(id);
   if(a==='delTicket') return delTicket(id);
   if(a==='editExpense') return editExpense(id);
   if(a==='delExpense') return delExpense(id);
   if(a==='editService') return editService(key,id);
   if(a==='delService') return delService(key,id);
   if(a==='togglePw') return togglePw(id);
   if(a==='editCredential') return editCredential(id);
   if(a==='delCredential') return delCredential(id);
 };

 const menu=document.getElementById('menuBtn'); if(menu)menu.onclick=()=>go('services');
 const back=document.getElementById('backBtn'); if(back)back.onclick=()=>go('home');
 const rf=document.getElementById('ratioForm');
 if(rf){
   const rdate=document.getElementById('rdate'), rex=document.getElementById('rex'), rerate=document.getElementById('rerate'), retotal=document.getElementById('retotal'), rco=document.getElementById('rco'), rcorate=document.getElementById('rcorate'), rcototal=document.getElementById('rcototal'), rdaytotal=document.getElementById('rdaytotal');
   const calc=()=>{const a=Number(rex.value)||0,b=Number(rerate.value)||0,c=Number(rco.value)||0,d=Number(rcorate.value)||0;retotal.value=money(a*b);rcototal.value=money(c*d);rdaytotal.value=money(a*b+c*d)};
   rf.querySelectorAll('input').forEach(i=>i.addEventListener('input',calc)); calc();
   rf.addEventListener('submit',e=>{e.preventDefault();const old=editing;const obj={id:old?.id||uid(),date:rdate.value,exams:Number(rex.value)||0,examRate:Number(rerate.value)||0,examTotal:(Number(rex.value)||0)*(Number(rerate.value)||0),consults:Number(rco.value)||0,consultRate:Number(rcorate.value)||0,consultTotal:(Number(rco.value)||0)*(Number(rcorate.value)||0),entryTime:document.getElementById('rentryTime').value,exitTime:document.getElementById('rexitTime').value};db.ratio=old?db.ratio.map(x=>x.id===obj.id?obj:x):[...db.ratio,obj];save();editing=null;toast('تم الحفظ بنجاح');render()});
 }
 const sfm=document.getElementById('serviceForm');
 if(sfm){
   const st=current.replace('service_',''), c=serviceConfig[st];
   sfm.addEventListener('submit',e=>{e.preventDefault();const old=editing;const obj={id:old?.id||uid(),date:document.getElementById('sdate').value,client:document.getElementById('sclient').value.trim(),phone:document.getElementById('sphone').value.trim(),deadline:document.getElementById('sdeadline').value,amount:Number(document.getElementById('samount').value)||0,note:document.getElementById('snote').value.trim(),entryTime:document.getElementById('sentryTime').value,exitTime:document.getElementById('sexitTime').value,serviceName:c.needsName?(document.getElementById('sservice')?.value.trim()||''):''};const arr=db.services[c.key]||[];db.services[c.key]=old?arr.map(x=>x.id===obj.id?obj:x):[...arr,obj];save();editing=null;toast('تم الحفظ بنجاح');render()});
 }
 const tf=document.getElementById('ticketForm');
 if(tf)tf.addEventListener('submit',e=>{e.preventDefault();const old=editing;const obj={id:old?.id||uid(),bookDate:document.getElementById('tbook').value,travelDate:document.getElementById('ttravel').value,ticketPrice:Number(document.getElementById('tprice').value)||0,myPrice:Number(document.getElementById('tmy').value)||0,name:document.getElementById('tname').value.trim(),note:document.getElementById('tnote').value.trim(),entryTime:document.getElementById('tentryTime').value,exitTime:document.getElementById('texitTime').value};db.tickets=old?db.tickets.map(x=>x.id===obj.id?obj:x):[...db.tickets,obj];save();editing=null;toast('تم الحفظ بنجاح');render()});
 const ef=document.getElementById('expenseForm'); const ew=document.getElementById('ewallet');
 if(ew){const sync=()=>{const box=document.getElementById('visaBankWrap'),cb=document.getElementById('cashWalletWrap');if(box)box.style.display=ew.value==='visa'?'block':'none';if(cb)cb.style.display=ew.value==='cash'?'block':'none'};ew.addEventListener('change',sync);sync()}
 if(ef)ef.addEventListener('submit',e=>{e.preventDefault();const old=editing, walletId=ew.value;const obj={id:old?.id||uid(),date:document.getElementById('edate').value,type:document.getElementById('etype').value,walletId,visaBankId:walletId==='visa'?(document.getElementById('visaBank')?.value||null):null,cashWalletId:walletId==='cash'?(document.getElementById('cashWallet')?.value||null):null,desc:document.getElementById('edesc').value.trim(),entryTime:document.getElementById('eentryTime').value,exitTime:document.getElementById('eexitTime').value,amount:Number(document.getElementById('eamount').value)||0};db.expenses=old?db.expenses.map(x=>x.id===obj.id?obj:x):[...db.expenses,obj];save();editing=null;toast('تم الحفظ بنجاح');render()});
 const pf=document.getElementById('profileForm');
 if(pf)pf.addEventListener('submit',e=>{e.preventDefault();db.profile={name:document.getElementById('pname').value.trim()||'اسمي',service:document.getElementById('pservice').value.trim()||'خدماتي الخاصة',photo:document.getElementById('pphoto').value.trim()||'assets/profile-placeholder.svg'};save();toast('تم الحفظ بنجاح');render()});
 const sf=document.getElementById('ratesForm');
 if(sf)sf.addEventListener('submit',e=>{e.preventDefault();db.settings.examRate=Number(document.getElementById('setExam').value)||0;db.settings.consultRate=Number(document.getElementById('setConsult').value)||0;save();toast('تم الحفظ بنجاح');render()});
 const cf=document.getElementById('credentialForm');
 if(cf)cf.addEventListener('submit',e=>{e.preventDefault();const obj={id:credentialEditing?.id||uid(),title:document.getElementById('ctitle').value.trim(),username:document.getElementById('cusername').value.trim(),password:document.getElementById('cpassword').value,entryTime:document.getElementById('centryTime').value,exitTime:document.getElementById('cexitTime').value};if(!obj.title){toast('اكتب اسم البيانات أولاً');return}db.credentials=credentialEditing?.id?db.credentials.map(x=>x.id===obj.id?obj:x):[...db.credentials,obj];save();credentialEditing=null;toast('تم حفظ البيانات');render()});
}
function go(p){editing=null;current=p;render();scrollTo(0,0)}
function cancelEdit(){editing=null;render()}
function editRatio(id){editing=db.ratio.find(x=>x.id===id);current='ratio';render()}
function delRatio(id){db.ratio=db.ratio.filter(x=>x.id!==id);save();toast('تم حذف اليوم');render()}
function editTicket(id){editing=db.tickets.find(x=>x.id===id);current='tickets';render()}
function delTicket(id){db.tickets=db.tickets.filter(x=>x.id!==id);save();toast('تم حذف الحجز');render()}
function editExpense(id){editing=db.expenses.find(x=>x.id===id);current='expenses';render()}
function delExpense(id){db.expenses=db.expenses.filter(x=>x.id!==id);save();toast('تم حذف الحركة');render()}
function editService(key,id){const arr=db.services[key]||[];editing=arr.find(x=>x.id===id);if(editing){editing={...editing,__serviceType:Object.keys(serviceConfig).find(k=>serviceConfig[k].key===key)};current='service_'+editing.__serviceType;render()}}
function delService(key,id){db.services[key]=(db.services[key]||[]).filter(x=>x.id!==id);save();toast('تم حذف الطلب');render()}
function newCredential(){credentialEditing={id:null,title:'',username:'',password:''};current='privacy';render()}
function editCredential(id){const x=db.credentials.find(v=>v.id===id);if(x){credentialEditing={...x};current='privacy';render()}}
function cancelCredentialEdit(){credentialEditing=null;render()}
function delCredential(id){db.credentials=db.credentials.filter(x=>x.id!==id);save();toast('تم حذف البيانات');render()}
function togglePw(id){const x=db.credentials.find(v=>v.id===id);if(x)alert('كلمة المرور: '+(x.password||'—'))}

function delWallet(id){if((db.wallets||[]).length<=1){toast('يجب الاحتفاظ بمحفظة واحدة على الأقل');return} if(db.expenses.some(x=>x.walletId===id)){toast('لا يمكن حذف محفظة عليها حركات محفوظة');return} if(confirm('حذف هذه المحفظة؟')){db.wallets=db.wallets.filter(x=>x.id!==id);save();render()}}
function togglePw(id){const x=db.credentials.find(v=>v.id===id); if(x)alert('كلمة المرور: '+(x.password||'—'))}
function walletName(w){return w==='visa'?'💳 فيزا':w==='pocket'?'👝 محفظة الجيب':'💵 كاش'}
function walletBalance(w){return sum(db.expenses,x=>x.walletId===w?(x.type==='income'?x.amount:-x.amount):0)}
function balance(){return sum(db.expenses,x=>x.type==='income'?x.amount:-x.amount)}
function exportData(){const blob=new Blob([JSON.stringify(db,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='ahmed-private-backup.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),500)}
function clearAll(){if(confirm('سيتم حذف كل البيانات من هذا الجهاز. هل أنت متأكد؟')){localStorage.removeItem(KEY);db=load();render();toast('تم مسح البيانات')}}
window.go=go; window.cancelEdit=cancelEdit; window.editRatio=editRatio; window.delRatio=delRatio; window.editTicket=editTicket; window.delTicket=delTicket; window.editExpense=editExpense; window.delExpense=delExpense; window.editService=editService; window.delService=delService; window.newCredential=newCredential; window.editCredential=editCredential; window.cancelCredentialEdit=cancelCredentialEdit; window.delCredential=delCredential; window.togglePw=togglePw; window.exportData=exportData; window.clearAll=clearAll;
render();
