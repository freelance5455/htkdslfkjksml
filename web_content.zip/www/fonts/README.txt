فایل فونت نازنین را با نام Nazanin.ttf در همین پوشه بگذارید.
Place your licensed B Nazanin font here as Nazanin.ttf
