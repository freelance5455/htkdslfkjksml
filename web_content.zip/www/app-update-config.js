/*
 * Dhanyabad Foundation App Update configuration.
 * The website admin panel publishes metadata at Firebase Realtime Database:
 * appUpdates/current. APK files themselves are hosted on the website (InfinityFree),
 * so Firebase Storage is not used.
 */
window.DF_APP_UPDATE_CONFIG = {
  currentVersion: '1.3.0',
  manifestUrl: 'https://myform-ddb68-default-rtdb.firebaseio.com/appUpdates/current.json',
  checkOnLaunch: true,
  checkIntervalHours: 6
};
