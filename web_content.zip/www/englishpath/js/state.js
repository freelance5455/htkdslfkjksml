// state.js
// Estado do app: progresso do usuário (persistido em localStorage), metas
// por dia, mapa de níveis (LV) derivado de data.js, e a UI state mutável
// (qual dia/seção/aba está ativa, flashcard atual, quiz em andamento etc.).
// Qualquer módulo que precise ler ou mudar progresso deve importar daqui —
// é a única fonte de verdade.
//
// Adaptado do EspañolPath: só a chave de localStorage mudou (de
// "espanhol_v1" para "english_v1") e os textos de "need()"/comentários
// foram revisados para o conteúdo de inglês. A lógica (done/secs/date/comp/
// xp/streak/exam) é idêntica. O sistema de migração de versões do app
// antigo (S.v / mg()) foi deliberadamente OMITIDO aqui — era específico do
// formato de save de versões anteriores do english.html monolítico e não
// há dados antigos compatíveis com este novo layout de localStorage para
// migrar (ver CHANGELOG no final da conversão).

import { D } from "./data.js";
import { today } from "./utils_time.js";
import { toast } from "./utils.js";

export const NEED = 3600; // segundos de estudo exigidos por dia (60 min)
export const N = { p: 10, w: 10, l: 8, f: 6 }; // metas por dia: pronúncia/vocabulário, escrita (lacunas), escuta, fala
const STORAGE_KEY = "english_v1";

function loadState() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY)) || {};
  } catch (e) {
    return {};
  }
}

export const S = loadState();
S.done = S.done || {}; // S.done[dayIndex] = { p0:1, w3:1, q:1, ... }
S.secs = S.secs || {}; // S.secs[dayIndex] = segundos estudados
S.date = S.date || {}; // S.date[dayIndex] = última data (string) em que o dia foi estudado
S.comp = S.comp || []; // dias concluídos (índices)
S.name = S.name || "";
S.av = S.av || ""; // avatar em data URL
S.xp = S.xp || 0;
S.streak = S.streak || 0;
S.last = S.last || ""; // última data (string) com atividade, para o cálculo da ofensiva
S.exam = S.exam || {}; // melhores notas do quiz final por nível, ex. { A1: 18 }
S.rd = S.rd || {}; // perguntas de leitura já respondidas corretamente: S.rd["lvI:textoI:perguntaI"] = 1

export function save() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(S));
  } catch (e) {
    /* localStorage pode estar indisponível (modo privado, quota) */
  }
}

// ===== progresso por dia =====
export const dn = (i) => (S.done[i] = S.done[i] || {});

export const cnt = (i, p) => Object.keys(dn(i)).filter((k) => k[0] == p && k !== "q").length;

export const full = (i) =>
  cnt(i, "p") >= N.p && cnt(i, "w") >= N.w && cnt(i, "l") >= N.l && cnt(i, "f") >= N.f && dn(i).q;

export const open = (i) => i == 0 || S.comp.includes(i - 1);

export const canFin = () => full(state.day) && (S.secs[state.day] || 0) >= NEED;

export function need() {
  const x = [];
  [
    ["p", "pronúncia/vocabulário"],
    ["w", "escrita"],
    ["l", "escuta"],
    ["f", "fala"],
  ].forEach(([k, n]) => {
    const f = N[k] - cnt(state.day, k);
    if (f > 0) x.push(f + " de " + n);
  });
  if (!dn(state.day).q) x.push("quiz");
  const m = Math.max(0, Math.ceil((NEED - (S.secs[state.day] || 0)) / 60));
  if (m) x.push(m + " min de estudo");
  return x.length ? "Falta: " + x.join(" · ") : "Tudo pronto!";
}

// Zera o contador de segundos de dias não concluídos quando a data muda
// (o cronômetro diário não acumula entre dias diferentes).
D.forEach((_, i) => {
  if (!S.comp.includes(i) && S.date[i] && S.date[i] !== today()) S.secs[i] = 0;
});

// ===== níveis (derivados do campo `lv` nos dias de data.js) =====
export const LV = [];
D.forEach((d, i) => {
  if (d.lv) {
    const m = d.lv.match(/Nível (\S+) · (.+)/);
    LV.push({ c: m[1], n: m[2], a: i, b: i });
  } else {
    LV[LV.length - 1].b = i;
  }
});
export const lvOf = (i) => LV.findIndex((l) => i >= l.a && i <= l.b);
export const levelDone = (l) => D.slice(l.a, l.b + 1).every((_, i) => S.comp.includes(l.a + i));

// ===== estado mutável de navegação/UI =====
// Agrupado em um único objeto para que outros módulos importem `state` e
// sempre leiam/gravem os valores atuais (evita cópias desatualizadas).
export const state = {
  sec: "lesson", // seção ativa: lesson | flashcards | roadmap | reading | rec | profile | exam
  pt: "g", // sub-aba da lição: g (gramática) | v (vocabulário/pronúncia) | w (escrita) | l (escuta) | f (fala) | q (quiz)
  day: Math.max(0, D.findIndex((_, i) => !S.comp.includes(i))),
  lvI: 0,
  rdI: 0, // índice do texto de leitura atual dentro do nível (aba "Leitura")
  RD: {}, // seleção de resposta por pergunta de leitura (transiente): RD["lvI:textoI:perguntaI"] = índice escolhido
  fc: 0, // índice do flashcard atual
  flip: false, // flashcard mostrando a face traseira?
  Q: null, // quiz diário em andamento
  X: null, // quiz final de nível em andamento
  mic: null, // índice da frase sendo gravada (reconhecimento de fala)
  SR: {}, // resultados de reconhecimento de fala por índice de frase
  col: false, // sidebar colapsada? (não usado na navegação por abas, mantido por compatibilidade)
  // ---- aba "Gravar": gravação pelo microfone + reconhecimento ----
  recording: false, // gravação pelo microfone em andamento?
  recTranscript: "", // transcrição acumulada da gravação atual
  recResult: null, // { ok, summary, matched, missed } após parar de gravar
  recBlobUrl: null, // URL local do áudio gravado, para o usuário reouvir
  _recStream: null, // MediaStream do microfone (interno, não serializar)
  _recognizer: null, // instância de SpeechRecognition ativa (interno)
  _mediaRecorder: null, // instância de MediaRecorder ativa (interno)
};
state.lvI = lvOf(state.day);

export function xp(n, message) {
  S.xp += n;
  save();
  if (message) toast(message + " (+" + n + " XP)");
}
