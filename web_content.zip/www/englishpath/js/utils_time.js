// utils_time.js
// Isolado em arquivo próprio para evitar import circular entre state.js
// (que precisa de `today()` ao inicializar) e um eventual utils.js maior.
// Idêntico ao do EspañolPath — não depende de idioma.
export const today = () => new Date().toDateString();
