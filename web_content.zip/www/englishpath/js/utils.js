// utils.js
// Pequenos utilitários puros, sem estado: acesso ao DOM, escaping,
// normalização de texto para correção de respostas, formatação de tempo,
// mapa de emojis por nível e as classes Tailwind-like reutilizadas nos
// templates (BP = botão primário, BS = botão secundário, etc.).
//
// Adaptado do EspañolPath: EM agora usa os códigos CEFR combinados do
// EnglishPath (A1, A2, B1–B2, C1–C2 — 4 módulos, não 6) com os mesmos
// emojis do app antigo (🌱🌿🌳🏔️). norm() não precisa mais preservar "ñ".

export const $ = (id) => document.getElementById(id);

export const mm = (s) => Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0");

export const esc = (s) =>
  String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

// Normaliza para comparar respostas digitadas: minúsculas, sem acentos, só [a-z0-9 ].
export const norm = (s) =>
  s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9 ]/g, "")
    .trim();

export const EM = { A1: "🌱", A2: "🌿", "B1–B2": "🌳", "C1–C2": "🏔️" };

// Classes utilitárias reaproveitadas em vários templates.
// Paleta: indigo é a cor "--pr" do EnglishPath (equivalente ao vermelho do
// EspañolPath), preservando a identidade visual original do english.html.
export const BP =
  "px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs sm:text-sm font-bold transition disabled:opacity-40 disabled:cursor-not-allowed";
export const BS =
  "px-3 py-1.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-crisp)] text-xs font-semibold hover:border-indigo-500/40 transition";
export const CARD = "saas-card rounded-3xl p-5 sm:p-6";
export const ROW = "p-4 rounded-2xl bg-[var(--bg-subtle)] border border-[var(--border-crisp)]";

export const icons = () => {
  try {
    lucide.createIcons();
  } catch (e) {
    /* biblioteca de ícones pode não estar disponível ainda */
  }
};

export function toast(m) {
  const t = $("toast");
  $("tt").textContent = m;
  t.classList.remove("opacity-0", "translate-y-3");
  clearTimeout(window._t);
  window._t = setTimeout(() => t.classList.add("opacity-0", "translate-y-3"), 2600);
}
