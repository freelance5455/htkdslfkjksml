// app.js
// Ponto de entrada do app: liga estado + templates + fala ao DOM. Mantém o
// mesmo padrão do app original (render manual via innerHTML, handlers
// chamados por onclick="..." inline), só que organizado em módulos. Todas
// as funções que o HTML chama via onclick precisam continuar expostas em
// `window` — é o único jeito de manter 100% do comportamento sem
// reescrever o HTML gerado para usar addEventListener.
//
// ADAPTAÇÕES EM RELAÇÃO AO EspañolPath (documentadas no changelog):
//  - Nav principal ganhou uma aba nova, "Leitura" (reading), entre
//    "Flashcards 3D" e "Trilha & Dias".
//  - quiz() (quiz diário) e startExam() (quiz final de nível) foram
//    reconstruídos para montar as perguntas a partir de d.b (lacunas) e,
//    no quiz final, também de d.w (pronúncia/IPA) — o EspañolPath usava
//    d.w como pares palavra→tradução, o que não existe no conteúdo de
//    inglês original (ver nota em templates.js).
//  - selReading()/answerReading() são handlers novos para a aba "Leitura".

import { D, RD } from "./data.js";
import {
  S,
  NEED,
  LV,
  state,
  save,
  dn,
  open,
  canFin,
  need,
  lvOf,
  levelDone,
  xp,
} from "./state.js";
import { $, mm, esc, norm, icons, toast } from "./utils.js";
import { say, sp, mark, speak, analyze, startMicRecording, stopMicRecording } from "./speech.js";
import { lesson, flashcards, roadmap, rec, profile, exam, reading } from "./templates.js";
import { today } from "./utils_time.js";

// ===== cronômetro de estudo (1x por segundo) =====
setInterval(() => {
  if (!["lesson", "flashcards"].includes(state.sec)) return;
  if (document.hidden || S.comp.includes(state.day) || !open(state.day)) return;

  const t = today();
  if (S.date[state.day] && S.date[state.day] !== t) S.secs[state.day] = 0;
  S.date[state.day] = t;

  if (S.last !== t) {
    const y = new Date(Date.now() - 864e5).toDateString();
    S.streak = S.last === y ? S.streak + 1 : 1;
    S.last = t;
  }

  S.secs[state.day] = (S.secs[state.day] || 0) + 1;
  if (S.secs[state.day] % 5 == 0) save();
  upd();
}, 1000);

// ===== navegação =====
// A sidebar foi removida (Opção 3: abas horizontais no topo, full-width).
// drawer()/collapse() não existem mais; a navegação agora é só `setSec`.

function theme() {
  const d = document.documentElement;
  const n = d.dataset.theme == "dark" ? "light" : "dark";
  d.dataset.theme = n;
  d.classList.toggle("dark", n == "dark");
  try {
    localStorage.setItem("english_theme", n);
  } catch (e) {
    /* ignore */
  }
  $("tic").setAttribute("data-lucide", n == "dark" ? "sun" : "moon");
  icons();
}

function setSec(s) {
  state.sec = s;
  state.Q = null;
  render();
  scrollTo({ top: 0, behavior: "smooth" });
}

function setPt(t) {
  state.pt = t;
  state.Q = null;
  render();
}

function selLevel(i) {
  state.lvI = i;
  state.rdI = 0;
  state.sec = "roadmap";
  render();
}

function selReading(i) {
  state.rdI = i;
  render();
}

function answerReading(key, oi, correct) {
  if (state.RD[key] != null) return; // já respondida, não deixa trocar
  state.RD[key] = oi;
  if (oi == correct && !S.rd[key]) {
    S.rd[key] = 1;
    xp(5, "📖 Leitura correta");
  }
  render();
}

function selDay(i) {
  if (!open(i)) {
    toast("🔒 Conclua o dia anterior para abrir este.");
    return;
  }
  state.day = i;
  state.lvI = lvOf(i);
  state.sec = "lesson";
  state.Q = null;
  render();
  scrollTo({ top: 0, behavior: "smooth" });
}

function finish() {
  if (S.comp.includes(state.day)) return;
  if (!canFin()) {
    toast(need());
    return;
  }
  S.comp.push(state.day);
  save();
  xp(50, "🎉 Dia concluído!");
  if (state.day + 1 < D.length) {
    state.day++;
    state.lvI = lvOf(state.day);
  }
  state.sec = "roadmap";
  render();
}

// ===== render =====
function upd() {
  $("xp").textContent = S.xp;
  $("st").textContent = S.streak;
  const s = S.secs[state.day] || 0;
  document.querySelectorAll(".tm").forEach((e) => (e.textContent = mm(s) + " / 60:00"));
  $("gb").style.width = Math.min(100, (s / NEED) * 100) + "%";
  document.querySelectorAll(".fin").forEach((b) => (b.disabled = S.comp.includes(state.day) || !canFin()));
}

function render() {
  upd();
  const d = D[state.day];
  const l = LV[state.lvI];
  const nd = D.slice(l.a, l.b + 1).filter((_, i) => S.comp.includes(l.a + i)).length;
  const tot = l.b - l.a + 1;
  const p = Math.round((nd / tot) * 100);

  // Resumo compacto do nível no header (detalhes completos ficam na aba Trilha).
  $("lb").textContent = "Nível " + l.c;
  $("lp").textContent = p + "%";
  $("lbar").style.width = p + "%";

  // Abas principais de navegação (substituem a sidebar — Opção 3).
  const NV = [
    ["lesson", "book-open", "Aula Atual"],
    ["flashcards", "layers", "Flashcards 3D"],
    ["reading", "newspaper", "Leitura"],
    ["roadmap", "map", "Trilha & Dias"],
    ["rec", "mic", "Gravar"],
    ["profile", "award", "Perfil"],
  ];
  $("nav").innerHTML = NV.map(
    ([k, i, t]) =>
      `<button onclick="setSec('${k}')" class="flex items-center gap-2 px-4 py-2 rounded-xl text-sm whitespace-nowrap transition-all ${
        k == state.sec
          ? "bg-indigo-600 text-white font-bold shadow-sm"
          : "font-semibold text-[var(--text-muted)] hover:text-[var(--text-main)] hover:bg-[var(--bg-subtle)]"
      }"><i data-lucide="${i}" class="w-4 h-4 shrink-0"></i><span>${t}</span></button>`
  ).join("");

  $("hav").innerHTML =
    (S.av
      ? `<img src="${S.av}" alt="" class="w-7 h-7 rounded-full object-cover">`
      : `<span class="w-7 h-7 rounded-full bg-gradient-to-tr from-indigo-600 to-sky-500 text-white font-bold text-xs flex items-center justify-center">${esc(
          (S.name || "EN")[0].toUpperCase()
        )}</span>`) +
    `<span class="hidden md:inline text-xs font-semibold">${esc(S.name || "Student")}</span>`;

  $("ws").innerHTML = { lesson, flashcards, reading, roadmap, rec, profile, exam }[state.sec]();
  icons();
}

// ===== prática: escrita (checagem de resposta) =====
function chk(k) {
  const d = D[state.day];
  const i = $("wi" + k);
  const f = $("wf" + k);
  if (!i || i.disabled) return;
  if (norm(i.value) == norm(d.b[k][1])) {
    mark("w" + k, render);
  } else {
    i.classList.add("border-rose-500");
    f.className = "text-xs font-bold text-rose-600";
    f.textContent = "✕ Tente de novo. Começa com «" + d.b[k][1][0] + "».";
    i.value = "";
  }
}

// ===== prática: quiz diário =====
// Montado a partir de d.b (frases de completar lacuna), já que o conteúdo
// de inglês não tem pares palavra→tradução como o d.w do EspañolPath (ver
// nota em templates.js). Cada dia tem exatamente 10 itens em b, então o
// quiz usa todos eles (sem amostragem), igual ao padrão de 10 perguntas.
function quiz() {
  const d = D[state.day];
  state.Q = {
    i: 0,
    s: 0,
    q: d.b
      .map((b) => {
        const o = [
          b[1],
          ...d.b
            .map((z) => z[1])
            .filter((z) => z !== b[1])
            .sort(() => Math.random() - 0.5)
            .slice(0, 3),
        ].sort(() => Math.random() - 0.5);
        return { t: "Complete: " + b[0], a: b[1], o };
      })
      .sort(() => Math.random() - 0.5),
  };
  render();
}

function ans(i) {
  const q = state.Q.q[state.Q.i];
  if (q.o[i] == q.a) state.Q.s++;
  state.Q.i++;
  if (state.Q.i >= 10 && state.Q.s >= 7) {
    dn(state.day).q = 1;
    save();
    xp(30, "🎯 Quiz aprovado");
    state.Q = null;
  }
  render();
}

// ===== flashcards =====
function toggleFlip() {
  state.flip = !state.flip;
  render();
}

function adv(p) {
  state.fc++;
  state.flip = false;
  if (p) xp(p);
  render();
}

// ===== quiz final de nível =====
// Montado a partir de d.b (lacunas) e d.w (pronúncia/IPA) do nível inteiro
// — ver nota acima sobre por que não usa "o que significa X" como no
// EspañolPath.
function startExam() {
  const l = LV[state.lvI];
  if (!levelDone(l)) {
    toast("Conclua todos os dias do nível para liberar o quiz final.");
    return;
  }
  const ds = D.slice(l.a, l.b + 1);
  const B = ds.flatMap((d) => d.b);
  const W = ds.flatMap((d) => d.w);
  const sh = (a) => a.slice().sort(() => Math.random() - 0.5);
  const pb = [...new Set(B.map((b) => b[1]))];
  const pw = [...new Set(W.map((w) => w[1]))];

  const qb = sh(B)
    .slice(0, 10)
    .map((b) => ({
      t: "Complete: " + b[0],
      a: b[1],
      o: sh([b[1], ...sh(pb.filter((x) => x !== b[1])).slice(0, 3)]),
    }));
  const qw = sh(W)
    .slice(0, 10)
    .map((w) => ({
      t: "Qual é a pronúncia/dica de “" + w[0] + "”?",
      a: w[1],
      o: sh([w[1], ...sh(pw.filter((x) => x !== w[1])).slice(0, 3)]),
    }));

  state.X = { i: 0, s: 0, q: sh([...qb, ...qw]), lv: l.c };
  state.sec = "exam";
  render();
  scrollTo({ top: 0, behavior: "smooth" });
}

function exAns(i) {
  const q = state.X.q[state.X.i];
  if (q.o[i] == q.a) state.X.s++;
  state.X.i++;
  if (state.X.i >= state.X.q.length) {
    S.exam = S.exam || {};
    if (state.X.s >= 14 && !(S.exam[state.X.lv] >= 14)) xp(100, "🏆 Quiz final aprovado");
    S.exam[state.X.lv] = Math.max(S.exam[state.X.lv] || 0, state.X.s);
    save();
  }
  render();
}

// ===== perfil =====
function setAv(f) {
  if (!f) return;
  const im = new Image();
  const fr = new FileReader();
  fr.onload = () => {
    im.onload = () => {
      const c = document.createElement("canvas");
      c.width = c.height = 160;
      const x = c.getContext("2d");
      const s = Math.min(im.width, im.height);
      x.drawImage(im, (im.width - s) / 2, (im.height - s) / 2, s, s, 0, 0, 160, 160);
      S.av = c.toDataURL("image/jpeg", 0.85);
      save();
      render();
    };
    im.src = fr.result;
  };
  fr.readAsDataURL(f);
}

function resetProgress() {
  Object.assign(S, {
    done: {},
    secs: {},
    date: {},
    comp: [],
    name: S.name,
    av: S.av,
    xp: 0,
    streak: 0,
    last: "",
    exam: {},
    rd: {},
  });
  save();
  state.day = 0;
  state.lvI = 0;
  state.rdI = 0;
  state.sec = "lesson";
  render();
}

// ===== expõe handlers para os onclick="..." inline do HTML gerado =====
Object.assign(window, {
  S,
  $,
  save,
  render,
  theme,
  setSec,
  setPt,
  selLevel,
  selReading,
  answerReading,
  selDay,
  finish,
  chk,
  quiz,
  ans,
  toggleFlip,
  adv,
  startExam,
  exAns,
  setAv,
  resetProgress,
  toast,
  say,
  sp: (k, i, slow) => sp(k, i, slow, render),
  mark: (k) => mark(k, render),
  speak: (k) => speak(k, render),
  analyze,
  startRec: () => startMicRecording(render),
  stopRec: () => stopMicRecording(render),
});

// ===== bootstrap =====
(function () {
  let t;
  try {
    t = localStorage.getItem("english_theme");
  } catch (e) {
    /* ignore */
  }
  t = t || (matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
  document.documentElement.dataset.theme = t;
  document.documentElement.classList.toggle("dark", t == "dark");
  $("tic").setAttribute("data-lucide", t == "dark" ? "sun" : "moon");
  render();
})();
