(function(root){'use strict';
const n=v=>{v=Number(v);return Number.isFinite(v)?v:0};
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,8);
const today=()=>{const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};
const empty=()=>({v:2,items:[],adds:[],sales:[],labours:[],lentries:[],wastage:[],expenses:[],finance:[],school:[],prime:[],loans:[],profitRates:[],ownPurchases:[],firstPrev:0});
const calculateSaleTotal=(q,r)=>n(q)*n(r);
const calculateWastageCost=(q,r)=>n(q)*n(r);
function findOrCreateItem(d,name,brand){name=String(name||'').trim();brand=String(brand||'').trim();
 let it=d.items.find(i=>i.name.toLowerCase()===name.toLowerCase()&&i.brand.toLowerCase()===brand.toLowerCase());
 if(!it){it={id:uid(),name,brand,opening:0};d.items.push(it)}return it}
// Stock: labour taken leaves the store; labour sold/wastage are part of "taken" so never subtracted twice.
function calculateStock(d,id){const f=(a,k)=>a.filter(x=>x.itemId===id).reduce((s,x)=>s+n(x[k]),0);
 const it=d.items.find(i=>i.id===id)||{opening:0};
 const L=d.lentries.flatMap(e=>e.lines.filter(l=>l.itemId===id));
 const sum=k=>L.reduce((s,l)=>s+n(l[k]),0);
 const added=f(d.adds,'qty'),sold=d.sales.filter(s=>s.itemId===id&&!s.legacy).reduce((s,x)=>s+n(x.qty),0),
 taken=sum('taken'),lsold=sum('sold'),ret=sum('returned'),lw=sum('wastage'),w=f(d.wastage,'qty');
 return{opening:n(it.opening),added,sold,taken,labourSold:lsold,returned:ret,labourWastage:lw,wastage:w+lw,
  available:n(it.opening)+added-sold-taken+ret}}
// V42 labour rule: soldValue = sum(sold x rate); net = soldValue + morning food/fuel - cash paid - online paid.
// net > 0 => Labour Receivable (labour owes us); net < 0 => Labour Credit (labour paid extra). Wastage = wastageQty x wastageRate (default 50), our loss, not charged to labour.
function calculateLabourDue(e){let sold=0,t=0,s=0,r=0;(e.lines||[]).forEach(l=>{sold+=calculateSaleTotal(l.sold,l.rate);t+=n(l.taken);s+=n(l.sold);r+=n(l.returned)});
 const rate=(e.wastageRate===undefined||e.wastageRate===null||e.wastageRate==='')?50:n(e.wastageRate),w=calculateWastageCost(e.wastageQty,rate),net=sold+n(e.morningCash)-n(e.cash)-n(e.online);
 return{soldValue:sold,wastageCost:w,due:sold,taken:t,sold:s,returned:r,wastage:n(e.wastageQty),online:n(e.online),cash:n(e.cash),morning:n(e.morningCash),outstanding:net,credit:Math.max(0,-net),receivable:Math.max(0,net)}}
function labourSummary(d,id){const z={taken:0,sold:0,returned:0,wastage:0,due:0,online:0,cash:0,morning:0,outstanding:0,soldValue:0,wastageCost:0,credit:0,receivable:0};
 d.lentries.filter(e=>e.labourId===id).forEach(e=>{const c=calculateLabourDue(e);['taken','sold','returned','wastage','online','cash','morning','outstanding','soldValue','wastageCost','credit','receivable'].forEach(k=>z[k]+=c[k]);z.due+=c.due});return z}
const sumF=(a,f)=>a.reduce((s,x)=>s+f(x),0);
function calculateDashboardTotals(d,date){date=date||today();
 const ls=d.lentries.map(e=>({e,c:calculateLabourDue(e)}));
 const dsale=a=>a.reduce((s,x)=>s+calculateSaleTotal(x.qty,x.rate),0);
 const normDate=x=>String(x||'').slice(0,10),directRows=d.sales.filter(x=>normDate(x.date)===normDate(date)),directT=dsale(directRows),directAll=dsale(d.sales);
 const labT=ls.filter(x=>normDate(x.e.date)===normDate(date)).reduce((s,x)=>s+x.c.soldValue,0),labAll=ls.reduce((s,x)=>s+x.c.soldValue,0);
 const sumL=k=>ls.reduce((s,x)=>s+x.c[k],0);
 const wCost=sumL('wastageCost');
 const exp=d.expenses.reduce((s,x)=>s+n(x.amount),0),fin=d.finance.reduce((s,x)=>s+n(x.amount),0);
 const stockQty=d.items.reduce((s,i)=>s+calculateStock(d,i.id).available,0);
 const t={todaySales:directT+labT,todayDirect:directT,todayLabour:labT,todaySaleCount:directRows.length,totalSales:directAll+labAll,
  wastageCost:wCost,wastageQty:sumL('wastage'),returned:sumL('returned'),stockQty,
  online:sumL('online'),cash:sumL('cash'),credit:sumL('credit'),receivable:sumL('receivable'),expenses:exp,finance:fin,labourPayments:sumL('morning'),
  labourOutstanding:sumL('outstanding')};
 t.school=sumF(d.school,x=>n(x.fees)+n(x.expense));t.primeCredit=sumF(d.prime.filter(x=>x.type==='credit'),x=>n(x.amount));t.primeDebit=sumF(d.prime.filter(x=>x.type==='debit'),x=>n(x.amount));t.loans=sumF(d.loans,x=>n(x.amount));t.purchasePaid=sumF(d.ownPurchases,x=>n(x.paid));t.profit=ownProfit(d).total;t.todayProfit=ownProfit(d,date).total;t.cashBalance=calculateCashBalance(d);return t}
// Money in: direct sales + labour online + labour cash + extra. Out: standalone wastage loss, expenses, finance, morning cash given.
// Labour-caused wastage is charged to labour (inside due) so it is not deducted twice.
function calculateCashBalance(d){const ls=d.lentries.map(calculateLabourDue);const s=k=>ls.reduce((a,c)=>a+c[k],0);
 const inn=d.sales.reduce((a,x)=>a+calculateSaleTotal(x.qty,x.rate),0)+s('online')+s('cash');
 const out=d.expenses.reduce((a,x)=>a+n(x.amount),0)+d.finance.reduce((a,x)=>a+n(x.amount),0)+s('morning')+s('wastageCost')+sumF(d.school,x=>n(x.fees)+n(x.expense))+sumF(d.prime.filter(x=>x.type==='debit'),x=>n(x.amount))+sumF(d.loans,x=>n(x.amount))+sumF(d.ownPurchases,x=>n(x.paid));
 return inn+n(d.firstPrev)+sumF(d.prime.filter(x=>x.type==='credit'),x=>n(x.amount))-out}
function validate(o){const e=[];(o.names||[]).forEach(([l,v])=>{if(!String(v||'').trim())e.push(l+' is required')});
 (o.nums||[]).forEach(([l,v,neg])=>{if(v===''||v===null||v===undefined||!Number.isFinite(Number(v)))e.push(l+' must be a number');else if(!neg&&Number(v)<0)e.push(l+' cannot be negative')});
 (o.pos||[]).forEach(([l,v])=>{if(!(Number(v)>0))e.push(l+' must be greater than 0')});return e}
function migrate(raw,old){let d=empty();if(raw&&raw.v===2){d=Object.assign(d,raw);return d}
 if(old){(old.stock||[]).forEach(s=>{const it=findOrCreateItem(d,s.item,s.brand);d.adds.push({id:uid(),date:s.date||today(),itemId:it.id,qty:n(s.qty),note:'migrated'})});
 (old.sales||[]).forEach(s=>{const it=findOrCreateItem(d,s.item,s.brand);d.sales.push({id:uid(),date:s.date||today(),itemId:it.id,qty:n(s.qty),rate:n(s.rate),legacy:true})})}
 return d}
function saleOn(d,date){return d.sales.filter(x=>x.date===date).reduce((s,x)=>s+n(x.qty)*n(x.rate),0)+d.lentries.filter(e=>e.date===date).reduce((s,e)=>s+calculateLabourDue(e).soldValue,0)}
function allDates(d){const s=new Set();['sales','lentries','wastage','expenses','finance','school','prime','loans','ownPurchases'].forEach(k=>d[k].forEach(x=>x.date&&s.add(x.date)));return [...s].sort()}
function previousSale(d,date){const ds=allDates(d).filter(x=>x<date&&saleOn(d,x)>0);return ds.length?saleOn(d,ds[ds.length-1]):(allDates(d).filter(x=>x<date).length?0:n(d.firstPrev))}
// Final Benefit (V42 rule): sale + previous + labour credit + bank net - wastage - labour receivable - loan - finance - home - school
function dailyHisaab(d,date){const L=d.lentries.filter(e=>e.date===date).map(calculateLabourDue),f=k=>L.reduce((s,c)=>s+c[k],0),on=(a,g)=>a.filter(x=>x.date===date).reduce((s,x)=>s+g(x),0);
 const h={date,sale:saleOn(d,date),prev:previousSale(d,date),credit:f('credit'),recv:f('receivable'),
 wastage:f('wastageCost'),loan:on(d.loans,x=>n(x.amount)),finance:on(d.finance,x=>n(x.amount)),home:on(d.expenses,x=>n(x.amount)),school:on(d.school,x=>n(x.fees)+n(x.expense)),purchase:on(d.ownPurchases,x=>n(x.paid)),
 bankCredit:on(d.prime.filter(x=>x.type==='credit'),x=>n(x.amount)),bankDebit:on(d.prime.filter(x=>x.type==='debit'),x=>n(x.amount))};
 h.benefit=h.sale+h.prev+h.credit+h.bankCredit-h.bankDebit-h.wastage-h.recv-h.loan-h.purchase-h.finance-h.home-h.school;return h}
// Own profit: qty sold (direct + labour) from item name; cost = qty x user's own rate; profit = sale value - cost. Own stock = purchased - sold.
function ownWastageForItem(d,item,date){return d.wastage.filter(x=>{if(date&&x.date!==date)return false;const it=d.items.find(i=>i.id===x.itemId);return it&&it.name.toLowerCase()===String(item||'').toLowerCase()}).reduce((s,x)=>s+calculateWastageCost(x.qty,x.rate),0)} function ownWastageQtyForItem(d,item,date){return d.wastage.filter(x=>{if(date&&x.date!==date)return false;const it=d.items.find(i=>i.id===x.itemId);return it&&it.name.toLowerCase()===String(item||'').toLowerCase()}).reduce((s,x)=>s+n(x.qty),0)} function ownPurchaseNet(d,p){const gross=n(p.qty)*n(p.rate)+n(p.freight);const adj=ownWastageForItem(d,p.item);return Math.max(0,gross-adj)} function ownProfit(d,date){const ok=x=>(!date||x.date===date);const rows=d.profitRates.map(p=>{const ids=d.items.filter(i=>i.name.toLowerCase()===p.item.toLowerCase()).map(i=>i.id);let qty=0,val=0;d.sales.filter(x=>ids.includes(x.itemId)&&ok(x)).forEach(x=>{qty+=n(x.qty);val+=n(x.qty)*n(x.rate)});d.lentries.filter(ok).forEach(e=>e.lines.filter(l=>ids.includes(l.itemId)).forEach(l=>{qty+=n(l.sold);val+=n(l.sold)*n(l.rate)}));const wastage=ownWastageForItem(d,p.item,date),bought=d.ownPurchases.filter(x=>x.item.toLowerCase()===p.item.toLowerCase()).reduce((s,x)=>s+n(x.qty),0),boughtGross=d.ownPurchases.filter(x=>x.item.toLowerCase()===p.item.toLowerCase()).reduce((s,x)=>s+n(x.qty)*n(x.rate)+n(x.freight),0),soldAll=date?null:qty;const netCost=Math.max(0,qty*n(p.rate)-wastage);return{item:p.item,rate:n(p.rate),qty,sale:val,cost:netCost,wastage,wastageCost:wastage,bought,remaining:Math.max(0,bought-(soldAll===null?0:soldAll)-ownWastageQtyForItem(d,p.item,date)),purchaseGross:boughtGross,purchaseWastageAdjustment:wastage,purchaseNet:Math.max(0,boughtGross-wastage),profit:val-netCost}});return{rows,total:rows.reduce((s,r)=>s+r.profit,0),sale:rows.reduce((s,r)=>s+r.sale,0),cost:rows.reduce((s,r)=>s+r.cost,0)}}
const api={dailyHisaab,ownProfit,saleOn,previousSale,allDates,n,uid,today,empty,calculateSaleTotal,calculateWastageCost,ownWastageForItem,ownWastageQtyForItem,ownPurchaseNet,findOrCreateItem,calculateStock,calculateLabourDue,labourSummary,calculateDashboardTotals,calculateCashBalance,validate,migrate};
if(typeof module!=='undefined')module.exports=api;else root.AS=api})(this);
