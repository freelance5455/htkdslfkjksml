(function(root){'use strict';
const n=v=>{v=Number(v);return Number.isFinite(v)?v:0};
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,8);
const today=()=>{const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};
const dateKey=v=>{v=String(v||'').trim();if(!v)return '';if(/^\d{4}-\d{2}-\d{2}/.test(v))return v.slice(0,10);let m=v.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})$/);if(m)return m[3]+'-'+String(m[2]).padStart(2,'0')+'-'+String(m[1]).padStart(2,'0');return v.slice(0,10)};
const empty=()=>({v:2,items:[],adds:[],sales:[],labours:[],lentries:[],wastage:[],expenses:[],finance:[],school:[],prime:[],loans:[],profitRates:[],ownPurchases:[],firstPrev:0});
const calculateSaleTotal=(q,r)=>n(q)*n(r);
const calculateWastageCost=(q,r)=>n(q)*n(r);
function findOrCreateItem(d,name,brand){name=String(name||'').trim();brand=String(brand||'').trim();
 let it=d.items.find(i=>i.name.toLowerCase()===name.toLowerCase()&&i.brand.toLowerCase()===brand.toLowerCase());
 if(!it){it={id:uid(),name,brand,opening:0};d.items.push(it)}return it}
// Stock: labour taken leaves the store; labour sold/wastage are part of "taken" so never subtracted twice.
function calculateStock(d,id){const f=(a,k)=>a.filter(x=>x.itemId===id).reduce((s,x)=>s+n(x[k]),0);
 const it=d.items.find(i=>i.id===id)||{opening:0};
 const L=d.lentries.flatMap(e=>e.lines.filter(l=>l.itemId===id));
 const sum=k=>L.reduce((s,l)=>s+n(l[k]),0);
 const added=f(d.adds,'qty'),sold=d.sales.filter(s=>s.itemId===id&&!s.legacy).reduce((s,x)=>s+n(x.qty),0),
 taken=sum('taken'),lsold=sum('sold'),lval=L.reduce((s,l)=>s+n(l.sold)*n(l.rate),0),dval=d.sales.filter(s=>s.itemId===id&&!s.legacy).reduce((s,x)=>s+n(x.qty)*n(x.rate),0),ret=sum('returned'),lw=sum('wastage'),w=f(d.wastage,'qty');
 return{opening:n(it.opening),added,sold,totalSold:sold+lsold,soldValue:dval+lval,taken,labourSold:lsold,returned:ret,labourWastage:lw,wastage:w+lw,
  available:n(it.opening)+added-sold-taken+ret}}
// Labour rule: soldValue = sum(sold x rate); labourTotal = soldValue - wastage; net = labourTotal + morning food/fuel - cash paid - online paid.
// net > 0 => Labour Receivable (labour owes us); net < 0 => Labour Credit (labour paid extra). Wastage = wastageQty x wastageRate (default 50), deducted from the labour's total.
function calculateLabourDue(e){let sold=0,t=0,s=0,r=0;(e.lines||[]).forEach(l=>{sold+=calculateSaleTotal(l.sold,l.rate);t+=n(l.taken);s+=n(l.sold);r+=n(l.returned)});
 const rate=(e.wastageRate===undefined||e.wastageRate===null||e.wastageRate==='')?50:n(e.wastageRate),w=calculateWastageCost(e.wastageQty,rate),total=sold-w,net=total+n(e.morningCash)-n(e.cash)-n(e.online);
 return{soldValue:sold,wastageCost:w,labourTotal:total,due:total,taken:t,sold:s,returned:r,wastage:n(e.wastageQty),online:n(e.online),cash:n(e.cash),morning:n(e.morningCash),outstanding:net,credit:Math.max(0,-net),receivable:Math.max(0,net)}}
function labourSummary(d,id){const z={taken:0,sold:0,returned:0,wastage:0,labourTotal:0,due:0,online:0,cash:0,morning:0,outstanding:0,soldValue:0,wastageCost:0,credit:0,receivable:0};
 d.lentries.filter(e=>e.labourId===id).forEach(e=>{const c=calculateLabourDue(e);['taken','sold','returned','wastage','online','cash','morning','outstanding','soldValue','wastageCost','labourTotal','credit','receivable'].forEach(k=>z[k]+=c[k]);z.due+=c.due});return z}
// Notebook-style sale summary: groups direct + labour sold by item and rate. date '' = all dates.
function soldSummary(d,date){const k=date?dateKey(date):'',m=new Map();let dv=0,lv=0;
 const add=(itemId,qty,rate,kind)=>{qty=n(qty);if(!(qty>0))return;rate=n(rate);const key=itemId+'|'+rate;let r=m.get(key);if(!r){r={itemId,rate,qty:0,amount:0};m.set(key,r)}r.qty+=qty;r.amount+=qty*rate;if(kind==='d')dv+=qty*rate;else lv+=qty*rate};
 d.sales.forEach(x=>{if(!k||dateKey(x.date)===k)add(x.itemId,x.qty,x.rate,'d')});
 d.lentries.forEach(e=>{if(!k||dateKey(e.date)===k)(e.lines||[]).forEach(l=>add(l.itemId,l.sold,l.rate,'l'))});
 const rows=[...m.values()];return{rows,qty:rows.reduce((s,r)=>s+r.qty,0),amount:dv+lv,direct:dv,labour:lv}}
// Permanent per-labour ledger. Debit = labour ka banta hai (sold - wastage + morning food/fuel). Credit = labour ne diya (cash + online).
// balance > 0 = Receivable (labour se lena baki), balance < 0 = Advance/Credit (labour ne zyada diya).
function labourLedger(d,id){let dr=0,cr=0;const rows=d.lentries.map((e,i)=>({e,i})).filter(x=>x.e.labourId===id).sort((a,b)=>dateKey(a.e.date).localeCompare(dateKey(b.e.date))||a.i-b.i).map(({e})=>{const c=calculateLabourDue(e),debit=c.labourTotal+c.morning,credit=c.cash+c.online;dr+=debit;cr+=credit;return{e,date:dateKey(e.date),debit,credit,balance:dr-cr,c}});
 const bal=dr-cr;return{rows,debit:dr,credit:cr,balance:bal,receivable:Math.max(0,bal),advance:Math.max(0,-bal)}}
// Display only: money labour deposited online in the account, date-wise. Not connected to sales/cash/benefit.
function labourOnline(d,nameOf){const m=new Map();d.lentries.forEach(e=>{const o=n(e.online);if(!(o>0))return;const k=dateKey(e.date);let r=m.get(k);if(!r){r={date:k,total:0,who:{}};m.set(k,r)}r.total+=o;const nm=nameOf?nameOf(e.labourId):e.labourId;r.who[nm]=(r.who[nm]||0)+o});
 const rows=[...m.values()].sort((a,b)=>b.date.localeCompare(a.date));return{rows,total:rows.reduce((s,r)=>s+r.total,0)}}
function labourIds(d){return [...new Set(d.labours.map(l=>l.id).concat(d.lentries.map(e=>e.labourId)))]}
const signed=x=>x&&x.dc==='credit'?-n(x.amount):n(x.amount); // finance/loan: Debit (default) = minus from total, Credit = plus
const sumF=(a,f)=>a.reduce((s,x)=>s+f(x),0);
function calculateDashboardTotals(d,date){date=date||today();
 const ls=d.lentries.map(e=>({e,c:calculateLabourDue(e)}));
 const dsale=a=>a.reduce((s,x)=>s+calculateSaleTotal(x.qty,x.rate),0);
 const normDate=x=>String(x||'').slice(0,10),directRows=d.sales.filter(x=>normDate(x.date)===normDate(date)),directT=dsale(directRows),directAll=dsale(d.sales);
 const labT=ls.filter(x=>normDate(x.e.date)===normDate(date)).reduce((s,x)=>s+x.c.soldValue,0),labAll=ls.reduce((s,x)=>s+x.c.soldValue,0);
 const sumL=k=>ls.reduce((s,x)=>s+x.c[k],0);
 const wCost=sumL('wastageCost');
 const exp=d.expenses.reduce((s,x)=>s+n(x.amount),0),fin=d.finance.reduce((s,x)=>s+signed(x),0);
 const stockQty=d.items.reduce((s,i)=>s+calculateStock(d,i.id).available,0);
 const t={todaySales:directT+labT,todayDirect:directT,todayLabour:labT,todaySaleCount:directRows.length,totalSales:directAll+labAll,
  wastageCost:wCost,wastageQty:sumL('wastage'),returned:sumL('returned'),stockQty,
  online:sumL('online'),cash:sumL('cash'),credit:sumF(labourIds(d),id=>labourLedger(d,id).advance),receivable:sumF(labourIds(d),id=>labourLedger(d,id).receivable),expenses:exp,finance:fin,labourPayments:sumL('morning'),
  labourOutstanding:sumL('outstanding')};
 t.school=sumF(d.school,x=>n(x.fees)+n(x.expense));t.primeCredit=sumF(d.prime.filter(x=>x.type==='credit'),x=>n(x.amount));t.primeDebit=sumF(d.prime.filter(x=>x.type==='debit'),x=>n(x.amount));t.loans=sumF(d.loans,signed);t.purchasePaid=sumF(d.ownPurchases,x=>n(x.paid));t.profit=ownProfit(d).total;t.todayProfit=ownProfit(d,date).total;t.cashBalance=calculateCashBalance(d,date);return t}
// Cash Balance (dashboard) = that day's Final Benefit: Sale + Previous + Labour Credit - Labour Receivable - Labour Wastage
// - Expenses - Finance - Loan - School - Own Purchase paid + Bank credit - Bank debit.
// Labour cash/online are NOT added separately (they already reduce Receivable / create Credit).
function calculateCashBalance(d,date){return dailyHisaab(d,date||today()).benefit}
function validate(o){const e=[];(o.names||[]).forEach(([l,v])=>{if(!String(v||'').trim())e.push(l+' is required')});
 (o.nums||[]).forEach(([l,v,neg])=>{if(v===''||v===null||v===undefined||!Number.isFinite(Number(v)))e.push(l+' must be a number');else if(!neg&&Number(v)<0)e.push(l+' cannot be negative')});
 (o.pos||[]).forEach(([l,v])=>{if(!(Number(v)>0))e.push(l+' must be greater than 0')});return e}
function migrate(raw,old){let d=empty();if(raw&&raw.v===2){d=Object.assign(d,raw);return d}
 if(old){(old.stock||[]).forEach(s=>{const it=findOrCreateItem(d,s.item,s.brand);d.adds.push({id:uid(),date:s.date||today(),itemId:it.id,qty:n(s.qty),note:'migrated'})});
 (old.sales||[]).forEach(s=>{const it=findOrCreateItem(d,s.item,s.brand);d.sales.push({id:uid(),date:s.date||today(),itemId:it.id,qty:n(s.qty),rate:n(s.rate),legacy:true})})}
 return d}
function saleOn(d,date){const k=dateKey(date);return d.sales.filter(x=>dateKey(x.date)===k).reduce((s,x)=>s+n(x.qty)*n(x.rate),0)+d.lentries.filter(e=>dateKey(e.date)===k).reduce((s,e)=>s+calculateLabourDue(e).soldValue,0)}
function allDates(d){const s=new Set();['sales','lentries','wastage','expenses','finance','school','prime','loans','ownPurchases'].forEach(k=>d[k].forEach(x=>{const dk=dateKey(x.date);if(dk)s.add(dk)}));return [...s].sort()}
// Previous: first day = firstPrev (typed by user); every later day = previous day's Final Benefit (carried forward).
function previousSale(d,date){date=dateKey(date);let carry=n(d.firstPrev);for(const dt of allDates(d)){if(dt>=date)break;carry=dayCalc(d,dt,carry).benefit}return carry}
function hisaabAll(d){const m=new Map();let carry=n(d.firstPrev);allDates(d).forEach(dt=>{const h=dayCalc(d,dt,carry);m.set(dt,h);carry=h.benefit});return m}
// Final Benefit (V42 rule): sale + previous + labour credit + bank net - wastage - labour receivable - loan - finance - home - school
function dailyHisaab(d,date){date=dateKey(date);return dayCalc(d,date,previousSale(d,date))}
function dayCalc(d,date,prev){const L=d.lentries.filter(e=>dateKey(e.date)===dateKey(date)).map(calculateLabourDue),f=k=>L.reduce((s,c)=>s+c[k],0),on=(a,g)=>a.filter(x=>dateKey(x.date)===dateKey(date)).reduce((s,x)=>s+g(x),0);
 const h={date:dateKey(date),sale:saleOn(d,date),prev:prev,credit:f('credit'),recv:f('receivable'),
 wastage:f('wastageCost'),loan:on(d.loans,signed),finance:on(d.finance,signed),home:on(d.expenses,x=>n(x.amount)),school:on(d.school,x=>n(x.fees)+n(x.expense)),purchase:on(d.ownPurchases,x=>n(x.paid)),
 bankCredit:on(d.prime.filter(x=>x.type==='credit'),x=>n(x.amount)),bankDebit:on(d.prime.filter(x=>x.type==='debit'),x=>n(x.amount))};
 h.benefit=h.sale+h.prev+h.credit+h.bankCredit-h.bankDebit-h.wastage-h.recv-h.loan-h.purchase-h.finance-h.home-h.school;return h}
// Own profit: qty sold (direct + labour) from item name; cost = qty x user's own rate; profit = sale value - cost. Own stock = purchased - sold.
function ownWastageForItem(d,item,date){return d.wastage.filter(x=>{if(date&&x.date!==date)return false;const it=d.items.find(i=>i.id===x.itemId);return it&&it.name.toLowerCase()===String(item||'').toLowerCase()}).reduce((s,x)=>s+calculateWastageCost(x.qty,x.rate),0)} function ownWastageQtyForItem(d,item,date){return d.wastage.filter(x=>{if(date&&x.date!==date)return false;const it=d.items.find(i=>i.id===x.itemId);return it&&it.name.toLowerCase()===String(item||'').toLowerCase()}).reduce((s,x)=>s+n(x.qty),0)} function ownPurchaseNet(d,p){const gross=n(p.qty)*n(p.rate)+n(p.freight);const adj=ownWastageForItem(d,p.item);return Math.max(0,gross-adj)} function ownProfit(d,date){const ok=x=>(!date||x.date===date);const rows=d.profitRates.map(p=>{const ids=d.items.filter(i=>i.name.toLowerCase()===p.item.toLowerCase()).map(i=>i.id);let qty=0,val=0;d.sales.filter(x=>ids.includes(x.itemId)&&ok(x)).forEach(x=>{qty+=n(x.qty);val+=n(x.qty)*n(x.rate)});d.lentries.filter(ok).forEach(e=>e.lines.filter(l=>ids.includes(l.itemId)).forEach(l=>{qty+=n(l.sold);val+=n(l.sold)*n(l.rate)}));const wastage=ownWastageForItem(d,p.item,date),bought=d.ownPurchases.filter(x=>x.item.toLowerCase()===p.item.toLowerCase()).reduce((s,x)=>s+n(x.qty),0),boughtGross=d.ownPurchases.filter(x=>x.item.toLowerCase()===p.item.toLowerCase()).reduce((s,x)=>s+n(x.qty)*n(x.rate)+n(x.freight),0),soldAll=date?null:qty;const netCost=Math.max(0,qty*n(p.rate)-wastage);return{item:p.item,rate:n(p.rate),qty,sale:val,cost:netCost,wastage,wastageCost:wastage,bought,remaining:Math.max(0,bought-(soldAll===null?0:soldAll)-ownWastageQtyForItem(d,p.item,date)),purchaseGross:boughtGross,purchaseWastageAdjustment:wastage,purchaseNet:Math.max(0,boughtGross-wastage),profit:val-netCost}});return{rows,total:rows.reduce((s,r)=>s+r.profit,0),sale:rows.reduce((s,r)=>s+r.sale,0),cost:rows.reduce((s,r)=>s+r.cost,0)}}
const api={hisaabAll,labourOnline,labourLedger,labourIds,soldSummary,dateKey,dailyHisaab,ownProfit,saleOn,previousSale,allDates,n,uid,today,empty,calculateSaleTotal,calculateWastageCost,ownWastageForItem,ownWastageQtyForItem,ownPurchaseNet,findOrCreateItem,calculateStock,calculateLabourDue,labourSummary,calculateDashboardTotals,calculateCashBalance,validate,migrate};
if(typeof module!=='undefined')module.exports=api;else root.AS=api})(this);
