(function(root){'use strict';
const n=v=>{v=Number(v);return Number.isFinite(v)?v:0};
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,8);
const today=()=>{const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};
const dateKey=v=>{v=String(v||'').trim();if(!v)return '';if(/^\d{4}-\d{2}-\d{2}/.test(v))return v.slice(0,10);let m=v.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})$/);if(m)return m[3]+'-'+String(m[2]).padStart(2,'0')+'-'+String(m[1]).padStart(2,'0');return v.slice(0,10)};
const empty=()=>({v:2,items:[],adds:[],sales:[],labours:[],lentries:[],wastage:[],expenses:[],finance:[],school:[],prime:[],loans:[],factory:[],profitRates:[],ownPurchases:[],purchasePayments:[],firstPrev:0});
const calculateSaleTotal=(q,r)=>n(q)*n(r);
const calculateWastageCost=(q,r)=>n(q)*n(r);
function findOrCreateItem(d,name,brand,cat){name=String(name||'').trim();brand=String(brand||'').trim();
 let it=d.items.find(i=>i.name.toLowerCase()===name.toLowerCase()&&i.brand.toLowerCase()===brand.toLowerCase());
 if(!it){it={id:uid(),name,brand,opening:0};if(cat)it.cat=cat;d.items.push(it)}return it}
const itemCat=(d,id)=>((d.items.find(i=>i.id===id)||{}).cat)||'';
// Stock: labour taken leaves the store; labour sold/wastage are part of "taken" so never subtracted twice.
function calculateStock(d,id){const f=(a,k)=>a.filter(x=>x.itemId===id).reduce((s,x)=>s+n(x[k]),0);
 const it=d.items.find(i=>i.id===id)||{opening:0};
 const L=d.lentries.flatMap(e=>e.lines.filter(l=>l.itemId===id));
 const sum=k=>L.reduce((s,l)=>s+n(l[k]),0);
 const added=f(d.adds,'qty'),sold=d.sales.filter(s=>s.itemId===id&&!s.legacy).reduce((s,x)=>s+n(x.qty),0),
 taken=sum('taken'),lsold=sum('sold'),lval=L.reduce((s,l)=>s+n(l.sold)*n(l.rate),0),dval=d.sales.filter(s=>s.itemId===id&&!s.legacy).reduce((s,x)=>s+n(x.qty)*n(x.rate),0),ret=sum('returned'),lw=sum('wastage'),w=f(d.wastage,'qty');
 return{opening:n(it.opening),added,sold,totalSold:sold+lsold,soldValue:dval+lval,taken,labourSold:lsold,returned:ret,labourWastage:lw,wastage:w+lw,
  available:n(it.opening)+added-sold-taken+ret}}
// Labour rule: soldValue = sum(sold x rate); labourTotal = soldValue - wastage; net = labourTotal + morning food/fuel - cash paid - online paid.
// net > 0 => Labour Receivable (labour owes us); net < 0 => Labour Credit (labour paid extra). Wastage = wastageQty x wastageRate (default 50), deducted from the labour's total.
function calculateLabourDue(e){let sold=0,t=0,s=0,r=0;(e.lines||[]).forEach(l=>{sold+=calculateSaleTotal(l.sold,l.rate);t+=n(l.taken);s+=n(l.sold);r+=n(l.returned)});
 const rate=(e.wastageRate===undefined||e.wastageRate===null||e.wastageRate==='')?50:n(e.wastageRate),w=calculateWastageCost(e.wastageQty,rate),total=sold-w,net=total+n(e.morningCash)-n(e.cash)-n(e.online);
 return{soldValue:sold,wastageCost:w,labourTotal:total,due:total,taken:t,sold:s,returned:r,wastage:n(e.wastageQty),online:n(e.online),cash:n(e.cash),morning:n(e.morningCash),outstanding:net,credit:Math.max(0,-net),receivable:Math.max(0,net)}}
function labourSummary(d,id){const z={taken:0,sold:0,returned:0,wastage:0,labourTotal:0,due:0,online:0,cash:0,morning:0,outstanding:0,soldValue:0,wastageCost:0,credit:0,receivable:0};
 d.lentries.filter(e=>e.labourId===id).forEach(e=>{const c=calculateLabourDue(e);['taken','sold','returned','wastage','online','cash','morning','outstanding','soldValue','wastageCost','labourTotal','credit','receivable'].forEach(k=>z[k]+=c[k]);z.due+=c.due});return z}
// Notebook-style sale summary: groups direct + labour sold by item and rate. date '' = all dates.
function soldSummary(d,date,cat){const k=date?dateKey(date):'',m=new Map();let dv=0,lv=0;
 const add=(itemId,qty,rate,kind)=>{qty=n(qty);if(!(qty>0))return;if(cat!==undefined&&itemCat(d,itemId)!==cat)return;rate=n(rate);const key=itemId+'|'+rate;let r=m.get(key);if(!r){r={itemId,rate,qty:0,amount:0};m.set(key,r)}r.qty+=qty;r.amount+=qty*rate;if(kind==='d')dv+=qty*rate;else lv+=qty*rate};
 d.sales.forEach(x=>{if(!k||dateKey(x.date)===k)add(x.itemId,x.qty,x.rate,'d')});
 d.lentries.forEach(e=>{if(!k||dateKey(e.date)===k)(e.lines||[]).forEach(l=>add(l.itemId,l.sold,l.rate,'l'))});
 const rows=[...m.values()];return{rows,qty:rows.reduce((s,r)=>s+r.qty,0),amount:dv+lv,direct:dv,labour:lv}}
// Permanent per-labour ledger. Debit = labour ka banta hai (sold - wastage + morning food/fuel). Credit = labour ne diya (cash + online).
// balance > 0 = Receivable (labour se lena baki), balance < 0 = Advance/Credit (labour ne zyada diya).
function labourLedger(d,id){let dr=0,cr=0;const rows=d.lentries.map((e,i)=>({e,i})).filter(x=>x.e.labourId===id).sort((a,b)=>dateKey(a.e.date).localeCompare(dateKey(b.e.date))||a.i-b.i).map(({e})=>{const c=calculateLabourDue(e),debit=c.labourTotal+c.morning,credit=c.cash+c.online;dr+=debit;cr+=credit;return{e,date:dateKey(e.date),debit,credit,balance:dr-cr,c}});
 const bal=dr-cr;return{rows,debit:dr,credit:cr,balance:bal,receivable:Math.max(0,bal),advance:Math.max(0,-bal)}}
// Display only: money labour deposited online in the account, date-wise. Not connected to sales/cash/benefit.
function labourOnline(d,nameOf){const m=new Map();d.lentries.forEach(e=>{const o=n(e.online);if(!(o>0))return;const k=dateKey(e.date);let r=m.get(k);if(!r){r={date:k,total:0,who:{}};m.set(k,r)}r.total+=o;const nm=nameOf?nameOf(e.labourId):e.labourId;r.who[nm]=(r.who[nm]||0)+o});
 const rows=[...m.values()].sort((a,b)=>b.date.localeCompare(a.date));return{rows,total:rows.reduce((s,r)=>s+r.total,0)}}
// Display only: cash AND online money labour handed over, date-wise. Not connected to sales/cash/benefit.
function labourReceived(d,nameOf){const m=new Map();d.lentries.forEach(e=>{const c=n(e.cash),o=n(e.online);if(!(c>0||o>0))return;const k=dateKey(e.date);let r=m.get(k);if(!r){r={date:k,cash:0,online:0,who:{}};m.set(k,r)}r.cash+=c;r.online+=o;const nm=nameOf?nameOf(e.labourId):e.labourId;const w=r.who[nm]||(r.who[nm]={cash:0,online:0});w.cash+=c;w.online+=o});
 const rows=[...m.values()].sort((a,b)=>b.date.localeCompare(a.date));return{rows,cash:rows.reduce((s,r)=>s+r.cash,0),online:rows.reduce((s,r)=>s+r.online,0)}}
function labourIds(d){return [...new Set(d.labours.map(l=>l.id).concat(d.lentries.map(e=>e.labourId)))]}
const signed=x=>x&&x.dc==='credit'?-n(x.amount):n(x.amount); // finance/loan: Debit (default) = minus from total, Credit = plus
const sumF=(a,f)=>a.reduce((s,x)=>s+f(x),0);
function calculateDashboardTotals(d,date){date=date||today();
 const ls=d.lentries.map(e=>({e,c:calculateLabourDue(e)}));
 const dsale=a=>a.reduce((s,x)=>s+calculateSaleTotal(x.qty,x.rate),0);
 const normDate=x=>String(x||'').slice(0,10),directRows=d.sales.filter(x=>normDate(x.date)===normDate(date)),directT=dsale(directRows),directAll=dsale(d.sales);
 const labT=ls.filter(x=>normDate(x.e.date)===normDate(date)).reduce((s,x)=>s+x.c.soldValue,0),labAll=ls.reduce((s,x)=>s+x.c.soldValue,0);
 const sumL=k=>ls.reduce((s,x)=>s+x.c[k],0);
 const wCost=sumL('wastageCost');
 const exp=d.expenses.reduce((s,x)=>s+n(x.amount),0),fin=d.finance.reduce((s,x)=>s+signed(x),0);
 const stockQty=d.items.filter(i=>i.cat!=='kadhai').reduce((s,i)=>s+calculateStock(d,i.id).available,0);
 const t={todaySales:directT+labT,todayDirect:directT,todayLabour:labT,todaySaleCount:directRows.length,totalSales:n(previousSale(d,date))+directT+labT,allTimeSales:directAll+labAll,kadhaiToday:soldSummary(d,date,'kadhai').amount,kadhaiStock:d.items.filter(i=>i.cat==='kadhai').reduce((s,i)=>s+calculateStock(d,i.id).available,0),
  wastageCost:wCost,wastageQty:sumL('wastage'),returned:sumL('returned'),stockQty,
  online:sumL('online'),cash:sumL('cash'),credit:sumF(labourIds(d),id=>labourLedger(d,id).advance),receivable:sumF(labourIds(d),id=>labourLedger(d,id).receivable),expenses:exp,finance:fin,labourPayments:sumL('morning'),
  labourOutstanding:sumL('outstanding')};
 t.school=sumF(d.school,x=>n(x.fees)+n(x.expense));t.primeCredit=sumF(d.prime.filter(x=>x.type==='credit'),x=>n(x.amount));t.primeDebit=sumF(d.prime.filter(x=>x.type==='debit'),x=>n(x.amount));t.loans=sumF(d.loans,signed);t.factory=sumF(d.factory||[],signed);t.purchasePaid=sumF(d.ownPurchases,x=>n(x.paid))+sumF(d.purchasePayments||[],x=>n(x.amount));t.profit=ownProfit(d).total;t.todayProfit=ownProfit(d,date).total;t.cashBalance=calculateCashBalance(d,date);return t}
// Cash Balance (dashboard) = that day's Final Benefit: Sale + Previous + Labour Credit - Labour Receivable - Labour Wastage
// - Expenses - Finance - Loan - School - Own Purchase paid + Bank credit - Bank debit.
// Labour cash/online are NOT added separately (they already reduce Receivable / create Credit).
function calculateCashBalance(d,date){return dailyHisaab(d,date||today()).benefit}
function validate(o){const e=[];(o.names||[]).forEach(([l,v])=>{if(!String(v||'').trim())e.push(l+' is required')});
 (o.nums||[]).forEach(([l,v,neg])=>{if(v===''||v===null||v===undefined||!Number.isFinite(Number(v)))e.push(l+' must be a number');else if(!neg&&Number(v)<0)e.push(l+' cannot be negative')});
 (o.pos||[]).forEach(([l,v])=>{if(!(Number(v)>0))e.push(l+' must be greater than 0')});return e}
function migrate(raw,old){let d=empty();if(raw&&raw.v===2){d=Object.assign(d,raw);return d}
 if(old){(old.stock||[]).forEach(s=>{const it=findOrCreateItem(d,s.item,s.brand);d.adds.push({id:uid(),date:s.date||today(),itemId:it.id,qty:n(s.qty),note:'migrated'})});
 (old.sales||[]).forEach(s=>{const it=findOrCreateItem(d,s.item,s.brand);d.sales.push({id:uid(),date:s.date||today(),itemId:it.id,qty:n(s.qty),rate:n(s.rate),legacy:true})})}
 return d}
function saleOn(d,date){const k=dateKey(date);return d.sales.filter(x=>dateKey(x.date)===k).reduce((s,x)=>s+n(x.qty)*n(x.rate),0)+d.lentries.filter(e=>dateKey(e.date)===k).reduce((s,e)=>s+calculateLabourDue(e).soldValue,0)}
function allDates(d){const s=new Set();['sales','lentries','wastage','expenses','finance','school','prime','loans','factory','ownPurchases'].forEach(k=>(d[k]||[]).forEach(x=>{const dk=dateKey(x.date);if(dk)s.add(dk)}));return [...s].sort()}
// Previous: first day = firstPrev (typed by user); every later day = previous day's Final Benefit (carried forward).
function previousSale(d,date){date=dateKey(date);let carry=n(d.firstPrev);for(const dt of allDates(d)){if(dt>=date)break;carry=dayCalc(d,dt,carry).benefit}return carry}
function hisaabAll(d){const m=new Map();let carry=n(d.firstPrev);allDates(d).forEach(dt=>{const h=dayCalc(d,dt,carry);m.set(dt,h);carry=h.benefit});return m}
// Final Benefit (V42 rule): sale + previous + labour credit + bank net - wastage - labour receivable - loan - finance - home - school
function dailyHisaab(d,date){date=dateKey(date);return dayCalc(d,date,previousSale(d,date))}
function dayCalc(d,date,prev){const L=d.lentries.filter(e=>dateKey(e.date)===dateKey(date)).map(calculateLabourDue),f=k=>L.reduce((s,c)=>s+c[k],0),on=(a,g)=>a.filter(x=>dateKey(x.date)===dateKey(date)).reduce((s,x)=>s+g(x),0);
 const h={date:dateKey(date),sale:saleOn(d,date),prev:prev,credit:f('credit'),recv:f('receivable'),
 wastage:f('wastageCost'),loan:on(d.loans,signed),factory:on(d.factory||[],signed),finance:on(d.finance,signed),home:on(d.expenses,x=>n(x.amount)),school:on(d.school,x=>n(x.fees)+n(x.expense)),purchase:purchaseLedger(d).filter(r=>dateKey(r.p.date)===date).reduce((t,r)=>t+r.paid-Math.min(r.wastageAdj,r.paid),0)+(d.purchasePayments||[]).filter(x=>dateKey(x.date)===date).reduce((t,x)=>t+n(x.amount),0),
 bankCredit:on(d.prime.filter(x=>x.type==='credit'),x=>n(x.amount)),bankDebit:on(d.prime.filter(x=>x.type==='debit'),x=>n(x.amount))};
 h.benefit=h.sale+h.prev+h.credit+h.bankCredit-h.bankDebit-h.wastage-h.recv-h.loan-h.factory-h.purchase-h.finance-h.home-h.school;return h}
// Own profit: qty sold (direct + labour) from item name; cost = qty x user's own rate; profit = sale value - cost. Own stock = purchased - sold.
// Own purchase ledger: standalone Wastage (scrap value) is minus from the purchase of the same item, oldest purchase first.
// net = qty x rate + freight - wastage adj ; remaining = net - paid.
function purchaseLedger(d){const left={};d.wastage.forEach(x=>{const it=d.items.find(i=>i.id===x.itemId);if(!it)return;const k=it.name.toLowerCase();left[k]=(left[k]||0)+calculateWastageCost(x.qty,x.rate)});
 const adj=new Map();d.ownPurchases.map((x,i)=>({x,i})).sort((a,b)=>dateKey(a.x.date).localeCompare(dateKey(b.x.date))||a.i-b.i).forEach(({x})=>{const k=String(x.item||'').toLowerCase(),goods=n(x.qty)*n(x.rate),a=Math.min(left[k]||0,goods);left[k]=(left[k]||0)-a;adj.set(x.id,a)});
 return d.ownPurchases.map(x=>{const a=adj.get(x.id)||0,net=n(x.qty)*n(x.rate)+n(x.freight)-a;return{p:x,wastageAdj:a,net,paid:n(x.paid),remaining:net-n(x.paid)}})}
function ownWastageForItem(d,item,date){return d.wastage.filter(x=>{if(date&&x.date!==date)return false;const it=d.items.find(i=>i.id===x.itemId);return it&&it.name.toLowerCase()===String(item||'').toLowerCase()}).reduce((s,x)=>s+calculateWastageCost(x.qty,x.rate),0)} function ownWastageQtyForItem(d,item,date){return d.wastage.filter(x=>{if(date&&x.date!==date)return false;const it=d.items.find(i=>i.id===x.itemId);return it&&it.name.toLowerCase()===String(item||'').toLowerCase()}).reduce((s,x)=>s+n(x.qty),0)} function ownPurchaseNet(d,p){const gross=n(p.qty)*n(p.rate)+n(p.freight);const adj=ownWastageForItem(d,p.item);return Math.max(0,gross-adj)} function normName(x){return String(x||'').toLowerCase().replace(/kadhai|kadahi|karahi|karai|kadai/g,'kadhai').replace(/[^a-z0-9\u0900-\u097f]/g,'')}
function assignRates(d){const m={},R=d.profitRates||[],al=['chair','kursi','stand','gadda','gadde','gaddi','kadhai','palta'];d.items.forEach(it=>{const ni=normName(it.name);let hit=R.find(p=>normName(p.item)===ni);if(!hit){const c=R.filter(p=>{const np=normName(p.item);return np.length>=3&&(ni.includes(np)||np.includes(ni))}).sort((a,b)=>normName(b.item).length-normName(a.item).length);hit=c[0]}if(!hit){const g=itemGroup(it);hit=R.find(p=>al.includes(normName(p.item))&&itemGroup({name:p.item})===g)}if(hit)m[it.id]=hit.id});return m}
function ownProfit(d,date){const ok=x=>(!date||x.date===date);const AM=assignRates(d);const rows=d.profitRates.map(p=>{const ids=d.items.filter(i=>AM[i.id]===p.id).map(i=>i.id);let qty=0,val=0;d.sales.filter(x=>ids.includes(x.itemId)&&ok(x)).forEach(x=>{qty+=n(x.qty);val+=n(x.qty)*n(x.rate)});d.lentries.filter(ok).forEach(e=>e.lines.filter(l=>ids.includes(l.itemId)).forEach(l=>{qty+=n(l.sold);val+=n(l.sold)*n(l.rate)}));const wastage=ownWastageForItem(d,p.item,date),bought=d.ownPurchases.filter(x=>x.item.toLowerCase()===p.item.toLowerCase()).reduce((s,x)=>s+n(x.qty),0),boughtGross=d.ownPurchases.filter(x=>x.item.toLowerCase()===p.item.toLowerCase()).reduce((s,x)=>s+n(x.qty)*n(x.rate)+n(x.freight),0),soldAll=date?null:qty;const pp=d.ownPurchases.filter(x=>String(x.item||'').toLowerCase()===p.item.toLowerCase()),pq=pp.reduce((t,x)=>t+n(x.qty),0),fpp=n(p.fqty)>0&&n(p.freight)>0?n(p.freight)/n(p.fqty):(pq>0?pp.reduce((t,x)=>t+n(x.freight),0)/pq:0);const netCost=Math.max(0,qty*(n(p.rate)+fpp)-wastage);return{item:p.item,grp:itemGroup(d.items.find(i=>ids.includes(i.id))||{name:p.item}),fpp,rate:n(p.rate),qty,sale:val,cost:netCost,wastage,wastageCost:wastage,bought,remaining:Math.max(0,bought-(soldAll===null?0:soldAll)-ownWastageQtyForItem(d,p.item,date)),purchaseGross:boughtGross,purchaseWastageAdjustment:wastage,purchaseNet:Math.max(0,boughtGross-wastage),profit:val-netCost}});return{rows,total:rows.reduce((s,r)=>s+r.profit,0),sale:rows.reduce((s,r)=>s+r.sale,0),cost:rows.reduce((s,r)=>s+r.cost,0)}}

// Groups: chair / stand / kadhai / palta / other. item.grp (set by user) wins, else guessed from name (palta & kadhai items are kept out of Total Stock).
const GROUPS=[['chair','Chair'],['stand','Stand'],['gadda','Gadda'],['other','Other'],['kadhai','Kadhai'],['palta','Palta']];
function itemGroup(it){if(!it)return 'other';if(it.grp&&GROUPS.some(g=>g[0]===it.grp))return it.grp;const s=String(it.name||'').toLowerCase();
 if(/palta|palt|\u092a\u0932\u091f\u093e/.test(s))return 'palta';if(it.cat==='kadhai'||/kadhai|kadai|karahi|karai|\u0915\u0922\u093c\u093e\u0908|\u0915\u0922\u093e\u0908|\u0915\u0921\u093c\u093e\u0939\u0940/.test(s))return 'kadhai';
 if(/gadd[ae]|gaddi|mattress|\bmat\b|\u0917\u0926\u094d\u0926\u093e|\u0917\u0926\u094d\u0926\u0947|\u092e\u0948\u091f/.test(s))return 'gadda';if(/chair|kursi|\u0915\u0941\u0930\u094d\u0938\u0940/.test(s))return 'chair';if(/stand|\u0938\u094d\u091f\u0948\u0902\u0921/.test(s))return 'stand';return 'chair'}
// groupSummary: per item + per group: taken (morning gaya), sold qty, sale value for the date (or all if no date) and all-time, current stock.
function fixCats(d){(d.items||[]).forEach(it=>{const g=itemGroup(it);if(g==='kadhai'||g==='palta')it.cat='kadhai';else if(it.cat==='kadhai')it.cat=''});return d}
function groupSummary(d,date){const k=date?dateKey(date):'',R=new Map(),mk=i=>({id:i.id,name:i.name,brand:i.brand||'',grp:itemGroup(i),taken:0,ret:0,allTaken:0,allRet:0,sold:0,sale:0,allSold:0,allSale:0,stock:calculateStock(d,i.id).available});
 d.items.forEach(i=>R.set(i.id,mk(i)));const add=(id,tk,q,rate,dt,rt)=>{const r=R.get(id);if(!r)return;q=n(q);const v=q*n(rate);r.allSold+=q;r.allSale+=v;r.allTaken+=n(tk);r.allRet+=n(rt);if(!k||dt===k){r.taken+=n(tk);r.ret+=n(rt);r.sold+=q;r.sale+=v}};
 d.sales.forEach(x=>add(x.itemId,0,x.qty,x.rate,dateKey(x.date)));d.lentries.forEach(e=>(e.lines||[]).forEach(l=>add(l.itemId,l.taken,l.sold,l.rate,dateKey(e.date),l.returned!==undefined&&l.returned!==''&&l.returned!==null?l.returned:Math.max(0,n(l.taken)-n(l.sold)))));
 const rows=[...R.values()],G={};GROUPS.forEach(([g,label])=>{const f=rows.filter(r=>r.grp===g),sm=c=>f.reduce((t,r)=>t+r[c],0);G[g]={key:g,label,rows:f,taken:sm('taken'),ret:sm('ret'),allTaken:sm('allTaken'),allRet:sm('allRet'),sold:sm('sold'),sale:sm('sale'),allSold:sm('allSold'),allSale:sm('allSale'),stock:sm('stock')}});
 const tot=c=>GROUPS.reduce((t,g)=>t+G[g[0]][c],0),goods=['chair','stand','other'];
 return{rows,G,totalSale:tot('sale'),totalAllSale:tot('allSale'),totalSold:tot('sold'),totalTaken:tot('taken'),totalRet:tot('ret'),totalAllTaken:tot('allTaken'),totalAllRet:tot('allRet'),totalAllSold:tot('allSold'),totalStock:goods.reduce((t,g)=>t+G[g].stock,0)}}
// Purchase summary: Net purchase (qty x rate + freight - wastage) minus paid on rows minus quick payments (no qty needed).
function purchaseSummary(d){const L=purchaseLedger(d),net=L.reduce((t,r)=>t+r.net,0),rowPaid=L.reduce((t,r)=>t+r.paid,0),pay=(d.purchasePayments||[]).reduce((t,x)=>t+n(x.amount),0);return{net,rowPaid,pay,paid:rowPaid+pay,remaining:net-rowPaid-pay}}
const api={assignRates,normName,fixCats,itemGroup,groupSummary,purchaseSummary,GROUPS,purchaseLedger,labourReceived,itemCat,hisaabAll,labourOnline,labourLedger,labourIds,soldSummary,dateKey,dailyHisaab,ownProfit,saleOn,previousSale,allDates,n,uid,today,empty,calculateSaleTotal,calculateWastageCost,ownWastageForItem,ownWastageQtyForItem,ownPurchaseNet,findOrCreateItem,calculateStock,calculateLabourDue,labourSummary,calculateDashboardTotals,calculateCashBalance,validate,migrate};
if(typeof module!=='undefined')module.exports=api;else root.AS=api})(this);
