TIME PASS LUDO V2

This version is a standalone playable HTML Ludo game.
Features:
- 4 local players
- Dice rolling
- Tokens leave home on 6
- Token movement and exact finish
- Token capture (except safe spaces)
- Extra turn on 6
- Win detection
- New Game button

Open index.html in a mobile browser to test.
