# v1.62.42 — Logos oficiais das competições em Ligas

- Substituídos os troféus antigos de Série A, Série B, Série C, Copa do Brasil, Premier League e LaLiga pelas logos fornecidas pelo usuário.
- Adicionada a logo da Serie A TIM na opção Itália.
- Sub-20 permanece separado, sem alteração nesta atualização.
- Nenhuma regra de campeonato, calendário, classificação, carreira ou elenco foi alterada.
- As logos desta entrega usam os endereços oficiais/fornecidos pelo usuário e precisam de conexão com os respectivos servidores para carregar.
