package ir.tradeyar.admin

import androidx.fragment.app.FragmentActivity
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import android.app.Activity
import android.os.Bundle
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.text.InputType
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.widget.*
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.nio.charset.StandardCharsets
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.Signature
import java.security.spec.ECGenParameterSpec
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import org.json.JSONObject
import java.util.UUID

/** Offline TradeYar license manager. Private signing key is generated in Android Keystore and is non-exportable. */
class MainActivity : FragmentActivity() {
    private lateinit var db: CustomerDb
    private val prefs by lazy { getSharedPreferences("admin_secure_prefs", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private var unlocked = false
    private var customerName = EditText(this)
    private var phone = EditText(this)
    private var deviceId = EditText(this)
    private var amount = EditText(this)
    private var paymentRef = EditText(this)
    private var plan = "30"
    private var resultBox: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = CustomerDb(this)
        showLogin()
    }

    private fun showLogin() {
        root = page("TRADEYAR ADMIN")
        val first = !prefs.contains("pass_hash")
        addText(if (first) "ساخت رمز مدیر" else "ورود مدیر", 22)
        val p = edit("رمز عبور اختصاصی", true)
        val p2 = if (first) edit("تکرار رمز عبور", true) else null
        addButton(if (first) "ثبت رمز و ورود" else "ورود به پنل") {
            val a = p.text.toString()
            if (a.length < 8) { toast("رمز باید حداقل ۸ نویسه باشد"); return@addButton }
            if (first) {
                if (a != p2?.text?.toString()) { toast("تکرار رمز یکسان نیست"); return@addButton }
                val salt = randomSalt()
                prefs.edit().putString("pass_salt", salt).putString("pass_hash", hashPassword(a, salt)).apply()
                ensureSigningKey()
                unlocked = true
                showDashboard()
            } else {
                val salt = prefs.getString("pass_salt", "") ?: ""
                val expected = prefs.getString("pass_hash", "") ?: ""
                if (hashPassword(a, salt) != expected) { toast("رمز نادرست است"); return@addButton }
                ensureSigningKey()
                unlocked = true
                showDashboard()
            }
        }
        if (!first) addButton("ورود با اثر انگشت") { biometricUnlock() }
        addText("این برنامه آفلاین است. رمز مدیر را در جای امن نگه دار؛ بازیابی رمز یا کلید امضا در این نسخه وجود ندارد.", 13)
    }

    private fun biometricUnlock() {
        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result)
                ensureSigningKey()
                unlocked = true
                showDashboard()
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { toast("ورود بیومتریک انجام نشد: $errString") }
            override fun onAuthenticationFailed() { toast("اثر انگشت تأیید نشد") }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("ورود مدیر تریدیار")
            .setSubtitle("با اثر انگشت یا روش امنیتی ثبت‌شده گوشی وارد شوید")
            .setAllowedAuthenticators(androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG or androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL)
            .build()
        prompt.authenticate(info)
    }

    private fun showDashboard() {
        if (!unlocked) return
        root = page("TRADEYAR ADMIN · مدیریت آفلاین")
        val stats = db.stats()
        addText("داشبورد", 22)
        addText("مشتریان: ${stats.first}     کدهای صادرشده: ${stats.second}", 16)
        addButton("صدور اشتراک جدید") { showIssue() }
        addButton("فهرست مشتریان و سوابق") { showCustomers() }
        addButton("نمایش کلید عمومی برای نصب در تریدیار") { showPublicKey() }
        addButton("قفل پنل و خروج") { unlocked = false; showLogin() }
        addText("نسخه ۱.۰ · صدور امضا بدون اینترنت", 12)
    }

    private fun showIssue() {
        root = page("صدور مجوز جدید")
        addText("اطلاعات مشتری", 21)
        customerName = edit("نام مشتری")
        phone = edit("شماره تماس (اختیاری)", false, InputType.TYPE_CLASS_PHONE)
        deviceId = edit("شناسه نصب تریدیار")
        addText("مدت اشتراک", 15)
        val rg = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        listOf("1" to "یک‌روزه (۲۴ ساعت)", "7" to "هفت‌روزه (۱۶۸ ساعت)", "30" to "ماهانه (۳۰ روز)").forEach { (v, label) ->
            val rb = RadioButton(this).apply { text = label; tag = v; isChecked = v == "30" }
            rb.setOnClickListener { plan = v }; rg.addView(rb)
        }
        root.addView(rg)
        amount = edit("مبلغ دریافتی به تومان", false, InputType.TYPE_CLASS_NUMBER)
        paymentRef = edit("شماره پیگیری پرداخت (اختیاری)")
        addButton("صدور کد امضاشده") { issueLicense() }
        addButton("بازگشت") { showDashboard() }
        resultBox = TextView(this).apply { textSize = 12f; textIsSelectable = true; setTextIsSelectable(true); setPadding(8,16,8,16) }
        root.addView(resultBox)
    }

    private fun issueLicense() {
        val name = customerName.text.toString().trim()
        val dv = deviceId.text.toString().trim().uppercase()
        if (name.isBlank() || dv.length < 6) { toast("نام و شناسه نصب معتبر لازم است"); return }
        try {
            val days = plan.toLong()
            val durationSeconds = days * 24L * 60L * 60L
            val customerId = "TY-${System.currentTimeMillis()}"
            val licenseId = UUID.randomUUID().toString()
            val payload = JSONObject().apply {
                put("v", 1)
                put("app", "TRADEYAR")
                put("bid", "TRADEYAR_V36")
                put("cid", customerId)
                put("jti", licenseId)
                put("nm", name)
                put("dv", dv)
                put("pl", when(plan) { "1" -> "یک‌روزه"; "7" -> "هفت‌روزه"; else -> "ماهانه" })
                put("dur", durationSeconds)
                put("iat", System.currentTimeMillis())
            }.toString()
            val encoded = b64url(payload.toByteArray(StandardCharsets.UTF_8))
            val sig = Signature.getInstance("SHA256withECDSA")
            sig.initSign(loadPrivateKey())
            sig.update(encoded.toByteArray(StandardCharsets.UTF_8))
            val der = sig.sign()
            val raw = derToP1363(der)
            val token = "$encoded.${b64url(raw)}"
            db.insert(name, phone.text.toString(), dv, plan, amount.text.toString(), paymentRef.text.toString(), customerId, licenseId, token)
            resultBox?.text = "کد فعال‌سازی مشتری:\n\n$token\n\nشناسه مشتری: $customerId\nمدت: ${days} روز\nشروع اشتراک: هنگام اولین فعال‌سازی موفق روی گوشی مشتری"
            toast("مجوز با موفقیت صادر شد")
        } catch (e: Exception) { toast("خطا در صدور مجوز: ${e.message ?: "نامشخص"}") }
    }

    private fun showCustomers() {
        root = page("مشتریان و سوابق")
        addText("فهرست مشتریان", 21)
        val rows = db.all()
        if (rows.isEmpty()) addText("هنوز مشتری ثبت نشده است.", 14)
        rows.forEach { r ->
            val box = TextView(this).apply {
                text = "${r[1]}\n${r[2]} · ${r[3]}\n${r[4]} · ${r[5]} تومان\nشناسه: ${r[6]}"
                textSize = 14f; setPadding(12,14,12,14); setBackgroundColor(0xFFF0F3F4.toInt())
            }
            root.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })
        }
        addButton("بازگشت") { showDashboard() }
    }

    private fun showPublicKey() {
        root = page("کلید عمومی تریدیار")
        addText("این کلید برای تأیید مجوز در نسخه مشتری است و محرمانه نیست.", 14)
        val jwk = publicJwk()
        val tv = TextView(this).apply { text = jwk; textIsSelectable = true; textSize = 12f; setPadding(8,12,8,12) }
        root.addView(tv)
        addButton("کپی کلید عمومی") {
            val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("TradeYar public key", jwk)); toast("کپی شد")
        }
        addButton("بازگشت") { showDashboard() }
    }

    private fun ensureSigningKey() {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (ks.containsAlias(KEY_ALIAS)) return
        val gen = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, "AndroidKeyStore")
        gen.initialize(KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY)
            .setAlgorithmParameterSpec(ECGenParameterSpec("secp256r1"))
            .setDigests(KeyProperties.DIGEST_SHA256)
            .setUserAuthenticationRequired(false)
            .build())
        gen.generateKeyPair()
    }

    private fun loadPrivateKey() = (KeyStore.getInstance("AndroidKeyStore").apply { load(null) }.getKey(KEY_ALIAS, null) as java.security.PrivateKey)

    private fun publicJwk(): String {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val cert = ks.getCertificate(KEY_ALIAS) ?: throw IllegalStateException("کلید ساخته نشده")
        val pub = cert.publicKey as java.security.interfaces.ECPublicKey
        val x = fixed32(pub.w.affineX.toByteArray()); val y = fixed32(pub.w.affineY.toByteArray())
        return JSONObject().put("kty", "EC").put("crv", "P-256").put("x", b64url(x)).put("y", b64url(y)).toString()
    }

    // Android Signature returns ASN.1 DER; WebCrypto ECDSA expects fixed-width P1363 r||s.
    private fun derToP1363(der: ByteArray): ByteArray {
        var i = 0
        require(der[i++].toInt() == 0x30)
        val seqLen = der[i++].toInt() and 0xff
        require(seqLen <= der.size - i)
        require(der[i++].toInt() == 0x02)
        val rLen = der[i++].toInt() and 0xff
        val r = der.copyOfRange(i, i + rLen); i += rLen
        require(der[i++].toInt() == 0x02)
        val sLen = der[i++].toInt() and 0xff
        val s = der.copyOfRange(i, i + sLen)
        return fixed32(r) + fixed32(s)
    }

    private fun fixed32(v: ByteArray): ByteArray {
        val clean = if (v.size > 32) v.copyOfRange(v.size - 32, v.size) else v
        return ByteArray(32 - clean.size) + clean
    }
    private fun b64url(b: ByteArray) = Base64.encodeToString(b, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    private fun randomSalt(): String { val b = ByteArray(16); SecureRandom().nextBytes(b); return b64url(b) }
    private fun hashPassword(password: String, salt: String): String {
        val spec = PBEKeySpec(password.toCharArray(), Base64.decode(salt, Base64.URL_SAFE or Base64.NO_WRAP), 180_000, 256)
        val out = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        spec.clearPassword(); return b64url(out)
    }

    private fun page(title: String): LinearLayout {
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 28, 20, 24); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        scroll.addView(root)
        setContentView(scroll)
        addText(title, 18)
        return root
    }
    private fun addText(s: String, size: Int) { root.addView(TextView(this).apply { text = s; textSize = size.toFloat(); setTextColor(0xff17212b.toInt()); setPadding(2, 10, 2, 10) }) }
    private fun edit(hint: String, password: Boolean = false, type: Int = InputType.TYPE_CLASS_TEXT): EditText {
        val e = EditText(this).apply { this.hint = hint; textSize = 15f; inputType = if (password) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD else type; setPadding(12,8,12,8) }
        root.addView(e, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 }); return e
    }
    private fun addButton(label: String, action: () -> Unit) { root.addView(Button(this).apply { text = label; setOnClickListener { action() } }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 6; bottomMargin = 6 }) }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    companion object { private const val KEY_ALIAS = "tradeyar_admin_signing_p256_v1" }
}

private class CustomerDb(ctx: android.content.Context) : SQLiteOpenHelper(ctx, "tradeyar_admin.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) { db.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,phone TEXT,device TEXT,plan TEXT,amount TEXT,payment_ref TEXT,customer_id TEXT,license_id TEXT,token TEXT,created_at INTEGER)") }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun insert(name:String, phone:String, device:String, plan:String, amount:String, ref:String, cid:String, lid:String, token:String) {
        writableDatabase.execSQL("INSERT INTO customers(name,phone,device,plan,amount,payment_ref,customer_id,license_id,token,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)", arrayOf(name,phone,device,plan,amount,ref,cid,lid,token,System.currentTimeMillis()))
    }
    fun stats(): Pair<Int,Int> { val c=readableDatabase.rawQuery("SELECT COUNT(*),COUNT(license_id) FROM customers",null); c.moveToFirst(); val p=c.getInt(0) to c.getInt(1); c.close(); return p }
    fun all(): List<Array<String>> { val out= mutableListOf<Array<String>>(); val c=readableDatabase.rawQuery("SELECT name,phone,device,plan,amount,customer_id,license_id FROM customers ORDER BY id DESC",null); while(c.moveToNext()) out.add(Array(c.columnCount){i->c.getString(i) ?: ""}); c.close(); return out }
}
