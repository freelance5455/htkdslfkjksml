/* ============================================================
   APPS: UI, Avito, Склад, Ремонт (4 мини-игры), Карта, Авто
   ============================================================ */
const UI = {
  currentApp: null,
  updateStatus(){
    $('#sbTime').textContent = Time.hhmm();
    $('#sbDay').textContent = 'Д'+Time.day;
    $('#sbMoney').textContent = fmtMoney(Player.money);
    $('#sbRep').textContent = Player.rep.toFixed(1);
    $('#sbSun').className = Time.isNight()? 'fas fa-moon':'fas fa-sun';
    const weatherIcons = {sunny:'fa-sun',cloudy:'fa-cloud',rain:'fa-cloud-rain',snow:'fa-snowflake'};
    $('#sbWeather').innerHTML = `<i class="fas ${weatherIcons[Time.weather]||'fa-sun'}"></i>`;
    const chatBadge = Player.messages.length;
    document.querySelectorAll('[data-app="chat"]').forEach(el=>{
      const old = el.querySelector('.badge-dot'); if(old) old.remove();
      if(chatBadge>0){
        const b = document.createElement('div'); b.className='badge-dot'; b.textContent=chatBadge;
        el.querySelector('.icon-box').appendChild(b);
      }
    });
  },
  notif(title,text,iconCls='ico-avito'){
    const n = document.createElement('div'); n.className='notif';
    n.innerHTML = `<div class="n-icon ${iconCls}"><i class="fas fa-bell"></i></div>
      <div><div class="n-title">${title}</div><div class="n-text">${text}</div></div>`;
    $('#notifLayer').appendChild(n);
    setTimeout(()=>{n.style.opacity='0'; n.style.transform='translateY(-30px)'; setTimeout(()=>n.remove(),300);}, 3500);
    AudioFX.notif();
  },
  toast(txt){ const t=document.createElement('div'); t.className='toast'; t.textContent=txt; document.body.appendChild(t); setTimeout(()=>t.remove(), 2000); },
  openApp(name){
    AudioFX.click();
    this.currentApp = name;
    const c = $('#appContainer'); c.innerHTML=''; c.classList.add('open');
    Three3D.destroyAll();
    const map = { avito:Apps.avito, repair:Apps.repair, sleep:Apps.sleep, map:Apps.map, chat:Apps.chat, car:Apps.car, warehouse:Apps.warehouse, stats:Apps.stats, quests:Apps.quests };
    (map[name]||Apps.avito)();
  },
  closeApp(){ $('#appContainer').classList.remove('open'); $('#appContainer').innerHTML=''; this.currentApp=null; Three3D.destroyAll(); this.updateStatus(); },
  header(title, sub=''){
    return `<div class="app-header">
      <button class="back-btn" onclick="UI.closeApp()"><i class="fas fa-chevron-left"></i></button>
      <div><div class="app-title">${title}</div>${sub?`<div class="app-sub">${sub}</div>`:''}</div>
    </div>`;
  },
  modal(html){
    const wrap = document.createElement('div');
    wrap.className='modal-back show';
    wrap.innerHTML = `<div class="modal">${html}</div>`;
    wrap.addEventListener('click', e=>{ if(e.target===wrap) wrap.remove(); });
    $('#screen').appendChild(wrap);
    return wrap;
  }
};

const Apps = {

  /* ---------- AVITO ---------- */
  avito(){
    const c = $('#appContainer');
    let activeTab = 'phones', sortBy = 'new', showFav = false;
    const render = ()=>{
      let items = Catalog.market.filter(p=>!Player.warehouse.find(w=>w.id===p.id));
      if(showFav) items = items.filter(p=>Player.favorites.includes(p.id));
      if(sortBy==='price_low') items.sort((a,b)=>a.price-b.price);
      if(sortBy==='price_high') items.sort((a,b)=>b.price-a.price);
      if(sortBy==='rep') items.sort((a,b)=>b.sellerRep-a.sellerRep);
      const listHTML = items.length ? items.slice(0,60).map(p=>`
        <div class="card ${p.isHot?'hot':''} ${p.oldPrice?'discount':''}" ${p.oldPrice?`data-disc="-${Math.round((1-p.price/p.oldPrice)*100)}%"`:''} onclick="Apps.avitoDetail(${p.id})">
          <div class="fav-btn ${Player.favorites.includes(p.id)?'active':''}" onclick="event.stopPropagation();Apps.toggleFav(${p.id})">
            <i class="fas fa-heart"></i>
          </div>
          <div class="row">
            <div class="thumb" style="background:linear-gradient(145deg,#${p.color.toString(16).padStart(6,'0')},#111);">
              <i class="fas fa-mobile-alt"></i>
            </div>
            <div class="info">
              <div class="title">${p.brand} ${p.model}</div>
              <div class="meta">${p.city} · ⭐${p.sellerRep.toFixed(1)} · ${p.daysOnAvito} дн.</div>
              <div class="price">${fmtFull(p.price)}${p.oldPrice?`<span class="old-price">${fmtFull(p.oldPrice)}</span>`:''}</div>
              <div class="tags">
                <span class="tag">${p.condition}</span>
                ${p.isNew?'<span class="tag" style="color:#4ade80;">NEW</span>':''}
              </div>
            </div>
          </div>
        </div>`).join('') : '<div class="spin" style="height:100px;">Нет объявлений</div>';
      c.innerHTML = UI.header('Avito', `${items.length} объявлений`) + `<div class="app-body">
        <div class="tabs">
          <div class="tab ${activeTab==='phones'?'active':''}" onclick="Apps._setTab('phones')">Телефоны</div>
          <div class="tab ${showFav?'active':''}" onclick="Apps._toggleFav()">❤ Избранное</div>
          <div class="tab" onclick="Apps._sort('price_low')">💸 Дешевле</div>
          <div class="tab" onclick="Apps._sort('rep')">⭐ Рейтинг</div>
        </div>
        ${listHTML}
      </div>`;
    };
    window._avitoRender = render;
    window._avitoState = { set:(k,v)=>{ if(k==='tab')activeTab=v; if(k==='sort')sortBy=v; if(k==='fav')showFav=v; render(); }, fav:showFav };
    render();
  },
  _setTab(t){ window._avitoState.set('tab',t); },
  _sort(s){ window._avitoState.set('sort',s); },
  _toggleFav(){ const st = window._avitoState; st.set('fav', !st.fav); st.fav = !st.fav; },
  toggleFav(id){
    const i = Player.favorites.indexOf(id);
    if(i>=0) Player.favorites.splice(i,1); else Player.favorites.push(id);
    Save.save(); window._avitoRender();
  },
  avitoDetail(id){
    const p = Catalog.market.find(x=>x.id===id);
    if(!p){ UI.toast('Лот не найден'); return; }
    const c = $('#appContainer');
    c.innerHTML = UI.header(p.brand+' '+p.model, `⭐${p.sellerRep.toFixed(1)} · ${p.sellerName} · ${p.city}`) + `
    <div class="app-body">
      <div class="three-wrap" id="threeBox"><div class="spin">Загрузка 3D...</div></div>
      <div class="card">
        <div style="display:flex;justify-content:space-between;align-items:baseline;">
          <div style="font-size:22px;font-weight:800;color:var(--accent);">${fmtFull(p.price)}</div>
          ${p.oldPrice?`<div class="old-price">${fmtFull(p.oldPrice)}</div>`:''}
        </div>
        <div class="tags" style="margin-top:8px;">
          <span class="badge">${p.condition}</span>
          ${p.isNew?'<span class="badge warn">Новое</span>':''}
          ${p.isHot?'<span class="badge danger">🔥 Горячее</span>':''}
        </div>
        <div class="stat-row"><span class="k">Продавец</span><span class="v">${p.sellerName} ⭐${p.sellerRep.toFixed(1)}</span></div>
        <div class="stat-row"><span class="k">Город</span><span class="v">${p.city}</span></div>
        <div class="stat-row"><span class="k">На Avito</span><span class="v">${p.daysOnAvito} дней</span></div>
        <div class="stat-row"><span class="k">Рыночная</span><span class="v">${fmtFull(p.basePrice)}</span></div>
      </div>
      <div class="card">
        <div style="font-size:12px;font-weight:700;margin-bottom:6px;">📝 Описание</div>
        <div style="font-size:12px;line-height:1.5;color:#ccc;">${p.description}</div>
      </div>
      <button class="btn btn-primary btn-full" onclick="Apps.avitoContact(${p.id})">
        <i class="fas fa-comment"></i> Написать продавцу
      </button>
      ${Player.imeiCheckUnlocked?`<button class="btn btn-secondary btn-full" style="margin-top:8px;" onclick="Apps.checkIMEI(${p.id})"><i class="fas fa-shield-alt"></i> Проверить IMEI (500₽)</button>`:''}
    </div>`;
    setTimeout(()=>{ const box=$('#threeBox'); if(box){ box.innerHTML=''; Three3D.createPhone(box, p.color, p.model); } }, 50);
  },
  checkIMEI(id){
    const p = Catalog.market.find(x=>x.id===id);
    if(!p) return;
    if(Player.money<500){ UI.toast('Нет денег'); return; }
    Player.addMoney(-500);
    if(Math.random()<0.85) UI.toast('✅ IMEI чист');
    else { p.price = Math.round(p.price*0.7); UI.toast('⚠️ IMEI в розыске!'); }
  },
  avitoContact(id){
    const p = Catalog.market.find(x=>x.id===id);
    if(!p) return;
    Chat.startWithSeller(p);
  },

  /* ---------- СКЛАД (исправлено: телефон не теряется) ---------- */
  warehouse(){
    const c = $('#appContainer');
    const list = Player.warehouse.length ? Player.warehouse.map((w,i)=>{
      const status = w.ready ? '✅ Готов' : (w.repairNeeded ? '🔧 Нужен ремонт' : '⏳ Осмотр');
      return `<div class="card">
        <div class="row">
          <div class="thumb" style="background:linear-gradient(145deg,#${w.color.toString(16).padStart(6,'0')},#111);">
            <i class="fas fa-mobile-alt"></i>
          </div>
          <div class="info">
            <div class="title">${w.brand} ${w.model}</div>
            <div class="meta">${w.condition} · ${status}</div>
            <div class="meta">Куплен: ${fmtFull(w.bought)}</div>
            ${w.forSale?`<div class="badge">На продаже за ${fmtFull(w.salePrice)}</div>`:
              (w.ready?`<button class="btn btn-secondary" style="margin-top:6px;padding:5px 10px;font-size:11px;" onclick="Apps.listForSale(${i})">Выставить</button>`:'')}
          </div>
        </div>
      </div>`; }).join('') : '<div class="spin" style="height:100px;">Склад пуст</div>';
    c.innerHTML = UI.header('Мой склад', `${Player.warehouse.length} телефонов`) + `<div class="app-body">${list}</div>`;
  },
  listForSale(idx){
    const w = Player.warehouse[idx];
    if(!w) return;
    UI.modal(`
      <h3>Выставить на продажу</h3>
      <p style="font-size:12px;color:#ccc;">Рыночная: ${fmtFull(w.basePrice)}</p>
      <input id="salePriceInput" type="number" value="${w.basePrice}" style="width:100%;padding:10px;border-radius:10px;border:1px solid rgba(255,255,255,.2);background:rgba(255,255,255,.08);color:#fff;font-size:14px;margin:8px 0;">
      <button class="btn btn-primary btn-full" onclick="Apps.confirmSale(${idx})">Выставить</button>
    `);
  },
  confirmSale(idx){
    const w = Player.warehouse[idx];
    if(!w) return;
    const val = parseInt($('#salePriceInput').value)||w.basePrice;
    w.forSale = true; w.salePrice = val;
    const m = $('.modal-back.show'); if(m) m.remove();
    UI.toast('📤 Выставлено');
    Buyers.queueBuyer(idx);
    Apps.warehouse();
  },

  /* ---------- РЕМОНТ ---------- */
  repair(){
    const c = $('#appContainer');
    // ВАЖНО: показываем ВСЕ телефоны, где нужен ремонт (не удаляем!)
    const repairable = Player.warehouse.filter(w=>w.repairNeeded && !w.ready);
    const list = repairable.length ? repairable.map((w)=>{
      const realIdx = Player.warehouse.indexOf(w);
      return `<div class="card" onclick="Apps.repairStart(${realIdx})">
        <div class="row">
          <div class="thumb" style="background:linear-gradient(145deg,#${w.color.toString(16).padStart(6,'0')},#111);">
            <i class="fas fa-tools" style="color:#f59e0b;"></i>
          </div>
          <div class="info">
            <div class="title">${w.brand} ${w.model}</div>
            <div class="meta">${w.condition}</div>
            <div class="meta" style="color:#f59e0b;">🔧 Нужен ремонт</div>
          </div>
        </div>
      </div>`; }).join('') : '<div class="spin" style="height:100px;">Нет телефонов для ремонта</div>';
    c.innerHTML = UI.header('Ремонт','Мастерская') + `<div class="app-body">${list}</div>`;
  },
  repairStart(idx){
    const w = Player.warehouse[idx];
    if(!w){ UI.toast('Телефон не найден'); return; }
    Time.paused = true;
    UI.modal(`
      <h3>🔧 ${w.brand} ${w.model}</h3>
      <p style="font-size:11px;color:#ccc;">${w.condition} · выберите работу:</p>
      <button class="btn btn-secondary btn-full" style="margin-bottom:6px;" onclick="Apps.repairScreen(${idx})">🖥 Экран (5000₽)</button>
      <button class="btn btn-secondary btn-full" style="margin-bottom:6px;" onclick="Apps.repairBattery(${idx})">🔋 Аккумулятор (3000₽)</button>
      <button class="btn btn-secondary btn-full" style="margin-bottom:6px;" onclick="Apps.repairCable(${idx})">🔌 Шлейф (2000₽)</button>
      <button class="btn btn-secondary btn-full" style="margin-bottom:6px;" onclick="Apps.repairFirmware(${idx})">💿 Прошивка (бесплатно)</button>
      <button class="btn btn-secondary btn-full" style="margin-bottom:6px;" onclick="Apps.repairClean(${idx})">🧹 Чистка (500₽)</button>
      <button class="btn btn-danger btn-full" onclick="Apps.closeModal()">Отмена</button>
    `);
  },
  closeModal(){ const m = document.querySelector('.modal-back.show'); if(m) m.remove(); Time.paused = false; },

  /* ============================================
     МИНИ-ИГРА 1: ФЕН (исправлено для touch)
     ============================================ */
  repairScreen(idx){
    const w = Player.warehouse[idx];
    if(!w){ UI.toast('Не найден'); return; }
    if(Player.money<5000){ UI.toast('Нет денег'); return; }
    Player.addMoney(-5000);
    $('.modal-back.show')?.remove();
    const m = UI.modal(`
      <h3>🖥 Замена экрана</h3>
      <p style="font-size:11px;color:#ccc;">Води пальцем/мышью по кругу, чтобы прогреть клей</p>
      <div class="fen-area" id="fenArea">
        <div class="target-zone"></div>
        <div class="heat" id="heat"></div>
        <div class="fen-progress"><div class="progress"><div class="bar" id="fenBar" style="width:0%"></div></div></div>
      </div>
    `);
    let prog = 0, heating = false, timer = null;
    const area = $('#fenArea'), heat = $('#heat');
    const getXY = e => {
      const t = e.touches ? e.touches[0] : e;
      const r = area.getBoundingClientRect();
      return { x: t.clientX - r.left, y: t.clientY - r.top };
    };
    const startHeat = e=>{
      e.preventDefault();
      heating = true;
      clearInterval(timer);
      timer = setInterval(doHeat, 50);
    };
    const stopHeat = ()=> heating = false;
    const moveHeat = e=>{
      if(!heating) return;
      e.preventDefault();
      const p = getXY(e);
      heat.style.left = p.x+'px';
      heat.style.top = p.y+'px';
      heat.style.opacity = 1;
      // проверка: попал ли в целевую зону
      const r = area.getBoundingClientRect();
      const cx = r.width/2, cy = r.height/2;
      const dist = Math.hypot(p.x-cx, p.y-cy);
      if(dist < 60) prog += 0.5;
      $('#fenBar').style.width = Math.min(100,prog)+'%';
      if(prog >= 100){
        clearInterval(timer);
        heating = false;
        finishRepair(idx, m, 'Экран заменён!');
      }
    };
    area.addEventListener('mousedown', startHeat);
    area.addEventListener('mouseup', stopHeat);
    area.addEventListener('mouseleave', ()=>{ stopHeat(); heat.style.opacity=0; });
    area.addEventListener('mousemove', moveHeat);
    area.addEventListener('touchstart', startHeat, {passive:false});
    area.addEventListener('touchend', stopHeat);
    area.addEventListener('touchcancel', stopHeat);
    area.addEventListener('touchmove', moveHeat, {passive:false});
    function doHeat(){
      if(!heating) return;
      prog += 0.3;
      $('#fenBar').style.width = Math.min(100,prog)+'%';
    }
    function finishRepair(idx, m, msg){
      const w = Player.warehouse[idx];
      if(!w) return;
      w.repairNeeded = false; w.ready = true;
      if(w.condition==='Битый экран' || w.condition==='Не включается') w.condition='Хорошее';
      Player.stats.repairs++; Player.addRep(0.1); Quests.progress('repairsToday');
      UI.toast('✅ '+msg); AudioFX.success(); Achievements.check();
      m.remove(); Time.paused = false;
      Apps.repair(); // покажет обновлённый список
    }
    window._finishRepair = finishRepair;
  },

  /* ============================================
     МИНИ-ИГРА 2: ОТВЁРТКА
     ============================================ */
  repairBattery(idx){
    const w = Player.warehouse[idx];
    if(!w) return;
    if(Player.money<3000){ UI.toast('Нет денег'); return; }
    Player.addMoney(-3000);
    $('.modal-back.show')?.remove();
    const m = UI.modal(`
      <h3>🔋 Аккумулятор</h3>
      <p style="font-size:11px;color:#ccc;">Крути отвёртку (зажми и двигай по кругу)</p>
      <div class="screw-box"><div class="screw" id="screw"></div></div>
      <div class="progress"><div class="bar" id="batBar" style="width:0%"></div></div>
      <p style="font-size:11px;color:#9ca3af;text-align:center;" id="angleTxt">0°</p>
    `);
    let totalAngle = 0, lastAngle = null, dragging = false;
    const screw = $('#screw');
    const getAngle = e=>{
      const r = screw.getBoundingClientRect();
      const t = e.touches ? e.touches[0] : e;
      const cx = r.left + r.width/2, cy = r.top + r.height/2;
      return Math.atan2(t.clientY-cy, t.clientX-cx)*180/Math.PI;
    };
    const onStart = e=>{ e.preventDefault(); dragging = true; lastAngle = getAngle(e); };
    const onMove = e=>{
      if(!dragging) return;
      e.preventDefault();
      const a = getAngle(e);
      let diff = a - lastAngle;
      if(diff > 180) diff -= 360;
      if(diff < -180) diff += 360;
      if(diff > 0) totalAngle += diff;
      lastAngle = a;
      const prog = clamp(totalAngle/720*100, 0, 100);
      $('#batBar').style.width = prog+'%';
      $('#angleTxt').textContent = Math.round(totalAngle)+'°';
      screw.style.transform = `rotate(${totalAngle}deg)`;
      if(Math.random()<0.1) AudioFX.screw();
      if(prog>=100){
        dragging = false;
        const w = Player.warehouse[idx];
        if(w){
          w.repairNeeded = false; w.ready = true;
          if(w.condition!=='Идеальное') w.condition='Хорошее';
          Player.stats.repairs++; Player.addRep(0.1); Quests.progress('repairsToday');
          UI.toast('✅ Аккумулятор заменён!'); AudioFX.success(); Achievements.check();
        }
        m.remove(); Time.paused = false; Apps.repair();
      }
    };
    const onEnd = ()=> dragging = false;
    screw.addEventListener('mousedown', onStart);
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onEnd);
    screw.addEventListener('touchstart', onStart, {passive:false});
    document.addEventListener('touchmove', onMove, {passive:false});
    document.addEventListener('touchend', onEnd);
  },

  /* ============================================
     МИНИ-ИГРА 3: ПАЗЛ ШЛЕЙФ (touch-friendly)
     ============================================ */
  repairCable(idx){
    const w = Player.warehouse[idx];
    if(!w) return;
    if(Player.money<2000){ UI.toast('Нет денег'); return; }
    Player.addMoney(-2000);
    $('.modal-back.show')?.remove();
    const slots = [
      {x:20, y:30, icon:'🔵'}, {x:120, y:30, icon:'🟢'},
      {x:20, y:130, icon:'🟡'}, {x:120, y:130, icon:'🔴'}
    ];
    const m = UI.modal(`
      <h3>🔌 Шлейф</h3>
      <p style="font-size:11px;color:#ccc;">Перетащи каждый шлейф в свой слот</p>
      <div class="puzzle-area" id="puzzleArea">
        ${slots.map((s,i)=>`<div class="puzzle-slot" data-i="${i}" style="left:${s.x}px;top:${s.y}px;">${s.icon}</div>`).join('')}
      </div>
      <div class="progress"><div class="bar" id="cableBar" style="width:0%"></div></div>
    `);
    const area = $('#puzzleArea');
    const shuffled = [...slots].sort(()=>Math.random()-0.5);
    let placed = 0;
    shuffled.forEach((s,i)=>{
      const piece = document.createElement('div');
      piece.className = 'puzzle-piece';
      piece.textContent = s.icon;
      piece.style.left = (200 + (i%2)*55)+'px';
      piece.style.top = (40 + Math.floor(i/2)*70)+'px';
      piece.dataset.target = slots.indexOf(s);
      area.appendChild(piece);
      let dragging = false, offX = 0, offY = 0;
      const getXY = e => {
        const t = e.touches ? e.touches[0] : e;
        const ar = area.getBoundingClientRect();
        return { x: t.clientX - ar.left, y: t.clientY - ar.top };
      };
      const down = e=>{
        e.preventDefault();
        dragging = true;
        const p = getXY(e);
        offX = p.x - parseFloat(piece.style.left);
        offY = p.y - parseFloat(piece.style.top);
        piece.style.zIndex = 10;
      };
      const move = e=>{
        if(!dragging) return;
        e.preventDefault();
        const p = getXY(e);
        piece.style.left = (p.x - offX)+'px';
        piece.style.top = (p.y - offY)+'px';
      };
      const up = e=>{
        if(!dragging) return;
        dragging = false;
        const p = getXY(e);
        const px = p.x - offX + 25, py = p.y - offY + 25;
        let matched = null;
        slots.forEach((s,si)=>{
          if(Math.hypot(px - (s.x+25), py - (s.y+25)) < 35) matched = si;
        });
        if(matched === parseInt(piece.dataset.target)){
          const s = slots[matched];
          piece.style.left = s.x+'px'; piece.style.top = s.y+'px';
          piece.style.background = 'linear-gradient(145deg,#4ade80,#16a34a)';
          piece.style.pointerEvents = 'none';
          placed++;
          $('#cableBar').style.width = (placed/4*100)+'%';
          AudioFX.screw();
          if(placed>=4){
            const w = Player.warehouse[idx];
            if(w){
              w.repairNeeded = false; w.ready = true;
              Player.stats.repairs++; Player.addRep(0.1); Quests.progress('repairsToday');
              UI.toast('✅ Шлейф заменён!'); AudioFX.success(); Achievements.check();
            }
            setTimeout(()=>{ m.remove(); Time.paused = false; Apps.repair(); }, 400);
          }
        } else {
          // возврат на место
          const s = slots[parseInt(piece.dataset.target)];
          if(s) { piece.style.left = (200 + Math.random()*40)+'px'; piece.style.top = (40 + Math.random()*180)+'px'; }
        }
      };
      piece.addEventListener('mousedown', down);
      piece.addEventListener('touchstart', down, {passive:false});
      piece.addEventListener('mousemove', move);
      piece.addEventListener('touchmove', move, {passive:false});
      piece.addEventListener('mouseup', up);
      piece.addEventListener('touchend', up);
    });
  },

  /* ============================================
     МИНИ-ИГРА 4: ПРОШИВКА (реалистичная)
     - 3D-модель
     - Recovery: Power + Vol+
     - Подключение USB
     - Выбор прошивки на ПК
     ============================================ */
  repairFirmware(idx){
    const w = Player.warehouse[idx];
    if(!w) return;
    $('.modal-back.show')?.remove();
    Time.paused = true;
    const isApple = w.brand === 'Apple';
    // Список прошивок
    let firmwareList = [];
    if(isApple){
      firmwareList = ['iOS 15','iOS 16','iOS 17','iOS 18','iOS 19','iOS 20','iOS 21','iOS 22','iOS 23','iOS 24','iOS 25','iOS 26','iOS 27'];
    } else if(w.brand === 'Xiaomi' || w.brand === 'Poco'){
      firmwareList = ['HyperOS 1.0','HyperOS 2.0','HyperOS 3.0','HyperOS 4.0','MIUI 14','MIUI 13'];
    } else if(w.brand === 'Huawei'){
      firmwareList = ['HarmonyOS 2.0','HarmonyOS 3.0','HarmonyOS 4.0','EMUI 12'];
    } else if(w.brand === 'Samsung'){
      firmwareList = ['One UI 3','One UI 4','One UI 5','One UI 6'];
    } else {
      firmwareList = ['Stock ROM v1','Stock ROM v2','LineageOS 19','LineageOS 20','AOSP 13'];
    }
    // Этап 1: Recovery
    const m = UI.modal(`
      <h3>💿 Прошивка ${w.brand}</h3>
      <p style="font-size:11px;color:#ccc;">Шаг 1: Войти в Recovery — зажми <b>Power + Vol+</b></p>
      <div class="fw-stage">
        <div class="fw-phone-view" id="fwPhone3d"></div>
        <div class="fw-buttons">
          <div class="fw-key" id="fwPower" data-key="power">⏻<br>Power</div>
          <div class="fw-key" id="fwVolUp" data-key="volup">+<br>Vol+</div>
          <div class="fw-key" id="fwVolDown" data-key="voldown">−<br>Vol−</div>
        </div>
        <div class="fw-hint" id="fwHint">Зажми обе кнопки одновременно</div>
      </div>
    `);
    // 3D-модель внутри модалки
    setTimeout(()=>{
      const box = $('#fwPhone3d');
      if(box){ box.innerHTML=''; Three3D.createPhone(box, w.color, w.model); }
    }, 30);
    // Логика Recovery: зажать Power + Vol+ одновременно 2 секунды
    let powerPressed = false, volUpPressed = false, recoveryTimer = null;
    const checkRecovery = ()=>{
      if(powerPressed && volUpPressed){
        if(!recoveryTimer){
          recoveryTimer = setTimeout(()=>{
            goToStep2();
          }, 1500);
        }
      } else {
        clearTimeout(recoveryTimer);
        recoveryTimer = null;
      }
    };
    const pressKey = (id)=>{
      const el = $('#'+id);
      if(!el) return;
      el.classList.add('pressed');
      if(id==='fwPower') powerPressed = true;
      if(id==='fwVolUp') volUpPressed = true;
      checkRecovery();
      AudioFX.click();
    };
    const releaseKey = (id)=>{
      const el = $('#'+id);
      if(el) el.classList.remove('pressed');
      if(id==='fwPower') powerPressed = false;
      if(id==='fwVolUp') volUpPressed = false;
      checkRecovery();
    };
    // события
    ['fwPower','fwVolUp','fwVolDown'].forEach(id=>{
      const el = $('#'+id);
      if(!el) return;
      el.addEventListener('mousedown', ()=>pressKey(id));
      el.addEventListener('mouseup', ()=>releaseKey(id));
      el.addEventListener('mouseleave', ()=>releaseKey(id));
      el.addEventListener('touchstart', e=>{ e.preventDefault(); pressKey(id); }, {passive:false});
      el.addEventListener('touchend', e=>{ e.preventDefault(); releaseKey(id); }, {passive:false});
    });
    const goToStep2 = ()=>{
      clearTimeout(recoveryTimer);
      m.remove();
      showRecoveryScreen();
    };
    // Этап 2: Recovery экран
    function showRecoveryScreen(){
      const m2 = UI.modal(`
        <h3>📱 Recovery Mode</h3>
        <div class="fw-recovery-screen">
          <div style="color:#4ade80;font-size:14px;">CWM-based Recovery v6.0.5</div>
          <div class="menu-item active">→ reboot system now</div>
          <div class="menu-item">→ apply update from ADB</div>
          <div class="menu-item">→ apply update from SD card</div>
          <div class="menu-item">→ wipe data / factory reset</div>
          <div class="menu-item">→ mount /system</div>
        </div>
        <p style="font-size:11px;color:#ccc;margin-top:8px;">Шаг 2: Подключи телефон к ПК по USB</p>
        <div style="display:flex;justify-content:space-around;align-items:center;margin:14px 0;">
          <div class="usb-cable" id="usbCable" style="touch-action:none;">🔌</div>
          <div style="font-size:11px;color:#9ca3af;">→ тяни →</div>
          <div class="usb-port" id="usbPort">ПК</div>
        </div>
      `);
      const cable = $('#usbCable'), port = $('#usbPort');
      let dragging = false, offX = 0, offY = 0;
      const getXY = e => {
        const t = e.touches ? e.touches[0] : e;
        return { x: t.clientX, y: t.clientY };
      };
      const down = e=>{
        e.preventDefault();
        dragging = true;
        const p = getXY(e);
        const r = cable.getBoundingClientRect();
        offX = p.x - r.left;
        offY = p.y - r.top;
        cable.style.position = 'fixed';
        cable.style.left = r.left+'px';
        cable.style.top = r.top+'px';
        cable.style.zIndex = 300;
      };
      const move = e=>{
        if(!dragging) return;
        e.preventDefault();
        const p = getXY(e);
        cable.style.left = (p.x - offX)+'px';
        cable.style.top = (p.y - offY)+'px';
      };
      const up = e=>{
        if(!dragging) return;
        dragging = false;
        const pr = port.getBoundingClientRect();
        const cr = cable.getBoundingClientRect();
        const overlap = !(cr.right < pr.left || cr.left > pr.right || cr.bottom < pr.top || cr.top > pr.bottom);
        if(overlap){
          port.classList.add('done');
          port.textContent = '✅ USB';
          cable.style.opacity = '0';
          AudioFX.success();
          setTimeout(()=>{ m2.remove(); showFirmwareSelect(); }, 500);
        } else {
          cable.style.position = 'relative';
          cable.style.left = '0'; cable.style.top = '0';
          cable.style.zIndex = '';
        }
      };
      cable.addEventListener('mousedown', down);
      document.addEventListener('mousemove', move);
      document.addEventListener('mouseup', up);
      cable.addEventListener('touchstart', down, {passive:false});
      document.addEventListener('touchmove', move, {passive:false});
      document.addEventListener('touchend', up);
    }
    // Этап 3: Выбор прошивки
    function showFirmwareSelect(){
      const m3 = UI.modal(`
        <h3>💿 ПК: Выбор прошивки</h3>
        <p style="font-size:11px;color:#ccc;">Выберите версию для ${w.brand} ${w.model}</p>
        <div class="fw-firmware-list" id="fwList">
          ${firmwareList.map((f,i)=>`<div class="fw-fw-item" data-fw="${f}" onclick="Apps._selectFw(this)">${f}</div>`).join('')}
        </div>
        <button class="btn btn-primary btn-full" style="margin-top:10px;" onclick="Apps._startFlash(${idx})">Начать прошивку</button>
      `);
      window._firmwareList = firmwareList;
    }

    window._finishFirmware = (idx, success, isBeta, baseBoost)=>{
      const w = Player.warehouse[idx];
      if(!w) return;
      if(success){
        w.repairNeeded = false; w.ready = true;
        if(w.condition==='Не включается') w.condition='Хорошее';
        Player.stats.repairs++; Player.addRep(0.1); Quests.progress('repairsToday');
        if(isBeta){ w.basePrice = Math.round(w.basePrice*1.1); UI.toast('✅ Beta прошита! +10%'); }
        else UI.toast('✅ Прошито!');
        AudioFX.success(); Achievements.check();
      } else {
        w.condition = 'Битый экран';
        UI.toast('❌ Кирпич! Нужен ремонт'); AudioFX.error();
      }
      const allModals = document.querySelectorAll('.modal-back.show');
      allModals.forEach(m=>m.remove());
      Time.paused = false;
      Apps.repair();
    };
  },

  // хелперы для прошивки (глобальные)
  _selectFw(el){
    document.querySelectorAll('.fw-fw-item').forEach(x=>x.classList.remove('selected'));
    el.classList.add('selected');
    window._selectedFw = el.dataset.fw;
  },
  _startFlash(idx){
    const fw = window._selectedFw || (window._firmwareList && window._firmwareList[0]);
    if(!fw){ UI.toast('Выберите прошивку'); return; }
    const allModals = document.querySelectorAll('.modal-back.show');
    allModals.forEach(m=>m.remove());
    const m = UI.modal(`
      <h3>💿 Прошивка: ${fw}</h3>
      <p style="font-size:11px;color:#ccc;">Не отключайте телефон!</p>
      <div class="progress"><div class="bar" id="flashBar" style="width:0%"></div></div>
      <p style="text-align:center;font-size:11px;color:#4ade80;margin-top:8px;" id="flashStatus">0%</p>
    `);
    let prog = 0;
    const isBeta = fw.includes('Beta') || fw.includes('beta') || fw.includes('HyperOS 3') || fw.includes('HyperOS 4');
    const success = isBeta ? Math.random() > 0.3 : Math.random() > 0.05;
    const int = setInterval(()=>{
      prog += 3;
      $('#flashBar').style.width = Math.min(100,prog)+'%';
      $('#flashStatus').textContent = prog+'%';
      AudioFX.fw();
      if(prog >= 100){
        clearInterval(int);
        m.remove();
        setTimeout(()=>{
          window._finishFirmware(idx, success, isBeta, 0);
        }, 200);
      }
    }, 100);
  },

  repairClean(idx){
    const w = Player.warehouse[idx];
    if(!w) return;
    if(Player.money<500){ UI.toast('Нет денег'); return; }
    Player.addMoney(-500);
    w.repairNeeded = false; w.ready = true;
    if(w.condition==='Есть царапины' || w.condition==='Битый экран') w.condition='Хорошее';
    Player.stats.repairs++; Quests.progress('repairsToday');
    $('.modal-back.show')?.remove();
    UI.toast('🧹 Почищено!'); AudioFX.success();
    Time.paused = false; Apps.repair();
  },

  /* ---------- СОН ---------- */
  sleep(){
    const c = $('#appContainer');
    const canSleep = Time.hour>=22 || Time.hour<6;
    c.innerHTML = UI.header('Сон') + `<div class="app-body" style="display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;">
      <div style="font-size:80px;margin:20px 0;">🌙</div>
      <div style="font-size:16px;font-weight:700;margin-bottom:8px;">${canSleep?'Пора спать':'Ещё рано'}</div>
      <div style="font-size:12px;color:#ccc;margin-bottom:20px;">${Time.hhmm()}, День ${Time.day}<br>Энергия: ${Math.round(Player.energy)}%</div>
      <button class="btn btn-primary btn-full" ${canSleep?'':'disabled'} onclick="Apps.sleepNow()">
        <i class="fas fa-bed"></i> Спать до утра
      </button>
    </div>`;
  },
  sleepNow(){
    const late = Time.hour>=1;
    const wakeHour = late ? 11 : 9;
    const restore = late ? 60 : 100;
    const overlay = document.createElement('div');
    overlay.className='sleep-overlay';
    overlay.innerHTML = `<div class="sleep-moon">🌙</div><div style="color:#fff;font-size:14px;">Спокойной ночи...</div>`;
    $('#screen').appendChild(overlay);
    setTimeout(()=>{
      Time.sleepTo(wakeHour, Time.day+1);
      Player.energy = restore;
      overlay.remove();
      UI.notif('☀️ Доброе утро!', `День ${Time.day}, ${Time.hhmm()}`, 'ico-sleep');
      UI.closeApp();
    }, 1800);
  },

  /* ---------- КАРТА ---------- */
  map(){
    const c = $('#appContainer');
    const cities = PlayerMap.cities;
    const listHTML = Object.keys(cities).map(name=>{
      const cur = Player.currentCity===name;
      return `<div class="city-item ${cur?'current':''}" onclick="Apps.mapCity('${name}')">
        <div class="dot"></div><div style="flex:1;">${name}</div>
        ${cur?'<span class="badge">Вы здесь</span>':`<span style="font-size:10px;color:#9ca3af;">~${PlayerMap.getHours(Player.currentCity,name)}ч</span>`}
      </div>`;
    }).join('');
    c.innerHTML = UI.header('Карта России', Player.currentCity) + `<div class="app-body">
      <svg class="map-svg" viewBox="0 0 400 250">
        <rect width="400" height="250" fill="rgba(30,41,59,.5)"/>
        <text x="200" y="125" font-size="60" fill="rgba(74,222,128,.1)" text-anchor="middle">🇷🇺</text>
        ${Object.entries(cities).map(([name,pos])=>`
          <g class="city" onclick="Apps.mapCity('${name}')">
            <circle cx="${pos.x*4}" cy="${pos.y*2.5}" r="4"/>
            <text x="${pos.x*4}" y="${pos.y*2.5-7}" text-anchor="middle">${name}</text>
          </g>
        `).join('')}
      </svg>
      ${listHTML}
    </div>`;
  },
  mapCity(name){
    if(Time.travel){ UI.toast('Вы уже в пути!'); return; }
    if(Player.currentCity===name){ UI.toast('Вы уже здесь'); return; }
    const hours = PlayerMap.getHours(Player.currentCity, name);
    const dist = PlayerMap.getDist(Player.currentCity, name);
    const hasCar = Player.activeCar !== null;
    const weatherMod = Time.weather==='rain'?1.15:Time.weather==='snow'?1.3:1;
    UI.modal(`
      <h3>🚆 В ${name}</h3>
      <p style="font-size:12px;color:#ccc;">~${dist} км · Погода: ${Time.weather}</p>
      <button class="btn btn-secondary btn-full" style="margin-top:6px;" onclick="Apps.travel('${name}','train',${Math.ceil(hours*weatherMod)},${dist})">🚆 Поезд (${Math.ceil(hours*weatherMod)}ч, ${fmtFull(dist*2)})</button>
      <button class="btn btn-secondary btn-full" style="margin-top:6px;" onclick="Apps.travel('${name}','plane',${Math.ceil(hours*0.4)},${dist})">✈️ Самолёт (${Math.ceil(hours*0.4)}ч, ${fmtFull(dist*8)})</button>
      ${hasCar?`<button class="btn btn-secondary btn-full" style="margin-top:6px;" onclick="Apps.travel('${name}','car',${Math.ceil(hours*0.75*weatherMod)},${dist})">🚗 Своя (${Math.ceil(hours*0.75*weatherMod)}ч, ${fmtFull(dist*5)})</button>`:''}
      ${Player.taxiUnlocked?`<button class="btn btn-warn btn-full" style="margin-top:6px;" onclick="Apps.travel('${name}','taxi',2,0)">🚕 Таксист (2ч, 5000₽)</button>`:''}
    `);
  },
  travel(to, mode, hours, dist){
    let cost = mode==='train'?dist*2:mode==='plane'?dist*8:mode==='car'?dist*5:5000;
    if(Player.money<cost){ UI.toast('Не хватает денег'); return; }
    Player.addMoney(-cost);
    Time.travel = { to, mode, hoursLeft: hours, total: hours };
    if(!Player.visitedCities) Player.visitedCities = [Player.currentCity];
    if(!Player.visitedCities.includes(to)) Player.visitedCities.push(to);
    $('.modal-back.show')?.remove();
    UI.closeApp();
    UI.notif('✈️ В путь!', `Едем в ${to}, ~${hours} ч`, 'ico-map');
  },

  /* ---------- АВТОСАЛОН ---------- */
  car(){
    const c = $('#appContainer');
    const listHTML = Cars.list.map((car,i)=>`
      <div class="card">
        <div class="row">
          <div class="thumb" style="background:linear-gradient(145deg,#${car.color.toString(16).padStart(6,'0')},#111);">
            <i class="fas fa-car" style="color:#fff;"></i>
          </div>
          <div class="info">
            <div class="title">${car.name}</div>
            <div class="meta">${car.desc}</div>
            <div class="price">${fmtFull(car.price)}</div>
            <button class="btn ${Player.cars.includes(i)?'btn-secondary':'btn-primary'}" style="margin-top:6px;padding:5px 10px;font-size:11px;"
              onclick="Apps.buyCar(${i})" ${Player.cars.includes(i)?'disabled':''}>
              ${Player.cars.includes(i)?'Куплено':'Купить'}
            </button>
            ${Player.cars.includes(i)&&Player.activeCar!==i?`<button class="btn btn-secondary" style="margin-top:4px;padding:5px 10px;font-size:11px;" onclick="Apps.useCar(${i})">Активировать</button>`:''}
          </div>
        </div>
      </div>`).join('');
    c.innerHTML = UI.header('Автосалон', Player.activeCar!==null?'🚗 '+Cars.list[Player.activeCar].name:'Машин нет') + `<div class="app-body">${listHTML}</div>`;
  },
  buyCar(i){
    const car = Cars.list[i];
    if(Player.money<car.price){ UI.toast('Не хватает денег'); return; }
    Player.addMoney(-car.price);
    Player.cars.push(i); Player.activeCar = i;
    UI.toast('🚗 Куплено!'); AudioFX.success(); Achievements.check();
    Apps.car();
  },
  useCar(i){ Player.activeCar = i; Apps.car(); },

  /* ---------- ЧАТЫ ---------- */
  chat(){
    const c = $('#appContainer');
    const chats = Player.messages;
    const listHTML = chats.length? chats.map((m,i)=>`
      <div class="card" onclick="Apps.openChat(${i})">
        <div class="row">
          <div class="thumb" style="background:linear-gradient(145deg,#ec4899,#be185d);width:44px;height:44px;border-radius:50%;font-size:18px;">
            <i class="fas fa-user"></i>
          </div>
          <div class="info">
            <div class="title">${m.name}</div>
            <div class="meta">${m.last||'...'}</div>
          </div>
        </div>
      </div>`).join('') : '<div class="spin" style="height:100px;">Нет чатов</div>';
    c.innerHTML = UI.header('Чаты') + `<div class="app-body">${listHTML}</div>`;
  },
  openChat(idx){
    const m = Player.messages[idx];
    if(!m) return;
    const c = $('#appContainer');
    c.innerHTML = UI.header(m.name) + `
    <div style="flex:1;display:flex;flex-direction:column;overflow:hidden;">
      <div class="chat-msgs" id="chatMsgs">
        ${m.msgs.map(msg=>`<div class="msg ${msg.me?'me':'them'}">${msg.text}</div>`).join('')}
      </div>
      ${m.type==='buyer'?`
        <div class="quick-btns">
          <button class="btn btn-primary" onclick="Chat.buyerAccept(${idx})">Согласиться</button>
          <button class="btn btn-secondary" onclick="Chat.buyerHaggle(${idx})">Поторговаться</button>
          <button class="btn btn-danger" onclick="Chat.buyerDecline(${idx})">Отшить</button>
        </div>`:`
        <div class="quick-btns">
          <button class="btn btn-secondary" onclick="Chat.haggle(${idx})">💰 Торг</button>
          <button class="btn btn-secondary" onclick="Chat.offerTrade(${idx})">🔄 Обмен</button>
          <button class="btn btn-secondary" onclick="Chat.arrange(${idx})">📍 Встреча</button>
          <button class="btn btn-danger" onclick="Chat.cancelDeal(${idx})">❌ Отмена</button>
        </div>`}
    </div>`;
    setTimeout(()=>{ const el=$('#chatMsgs'); if(el) el.scrollTop = el.scrollHeight;}, 50);
  },

  /* ---------- СТАТИСТИКА ---------- */
  stats(){
    const c = $('#appContainer');
    c.innerHTML = UI.header('Профиль') + `<div class="app-body">
      <div class="card" style="text-align:center;">
        <div style="font-size:32px;">${Player.rank()}</div>
        <div style="font-size:12px;color:#9ca3af;margin-top:4px;">Ранг</div>
      </div>
      <div class="card">
        <div class="stat-row"><span class="k">Баланс</span><span class="v">${fmtFull(Player.money)}</span></div>
        <div class="stat-row"><span class="k">Репутация</span><span class="v">⭐ ${Player.rep.toFixed(2)}</span></div>
        <div class="stat-row"><span class="k">Энергия</span><span class="v">${Math.round(Player.energy)}%</span></div>
        <div class="stat-row"><span class="k">Сделок</span><span class="v">${Player.stats.deals}</span></div>
        <div class="stat-row"><span class="k">Ремонтов</span><span class="v">${Player.stats.repairs}</span></div>
        <div class="stat-row"><span class="k">Города</span><span class="v">${(Player.visitedCities||[]).length}</span></div>
      </div>
      <div class="card">
        <div style="font-size:13px;font-weight:700;margin-bottom:8px;">🏆 Достижения</div>
        <div class="ach-grid">
          ${Achievements.list.map(a=>`<div class="ach ${Player.achievements.includes(a.id)?'unlocked':''}"><div class="a-icon">${a.icon}</div><div class="a-name">${a.name}</div><div class="a-desc">${a.desc}</div></div>`).join('')}
        </div>
      </div>
      <div class="card">
        <div class="stat-row"><span class="k">Скорость времени</span><span class="v">
          ${[1,2,5].map(s=>`<button class="btn ${Time.speed===s?'btn-primary':'btn-secondary'}" style="padding:4px 10px;font-size:11px;margin:0 2px;" onclick="Time.speed=${s};UI.toast('Скорость x${s}')">x${s}</button>`).join('')}
        </span></div>
      </div>
      <button class="btn btn-danger btn-full" style="margin-top:20px;" onclick="Save.reset()">🗑 Сбросить игру</button>
    </div>`;
  },

  quests(){
    const c = $('#appContainer');
    const q = Quests.current;
    const list = q.length? q.map((quest,i)=>`
      <div class="quest ${quest.done?'done':''}">
        <div class="q-icon"><i class="fas fa-bullseye"></i></div>
        <div class="q-info">
          <div class="q-title">${quest.title}</div>
          <div class="q-desc">${quest.desc} · ${fmtFull(quest.reward)}</div>
          <div class="q-progress"><div class="q-bar" style="width:${Math.min(100, (Player.today?.[quest.key]||0)/quest.target*100)}%"></div></div>
        </div>
        ${(Player.today?.[quest.key]||0) >= quest.target && !quest.done ? `<button class="btn btn-primary" onclick="Quests.claim(${i})">Забрать</button>` : ''}
      </div>`).join('') : '<div class="spin">Квесты обновятся завтра</div>';
    c.innerHTML = UI.header('Квесты', `День ${Time.day}`) + `<div class="app-body">${list}</div>`;
  }
};

/* ---------- КАРТА ---------- */
const PlayerMap = {
  cities: {
    'Москва':{x:30,y:40}, 'Санкт-Петербург':{x:25,y:25}, 'Казань':{x:48,y:45},
    'Екатеринбург':{x:65,y:42}, 'Новосибирск':{x:80,y:45}, 'Владивосток':{x:95,y:52},
    'Сочи':{x:35,y:70}, 'Калининград':{x:10,y:35}
  },
  getDist(a,b){
    const p1=this.cities[a], p2=this.cities[b];
    if(!p1||!p2) return 1000;
    const dx=(p1.x-p2.x)*40, dy=(p1.y-p2.y)*40;
    return Math.round(Math.sqrt(dx*dx+dy*dy)*20);
  },
  getHours(a,b){
    const pairs = {'Москва-Санкт-Петербург':3,'Москва-Казань':5,'Москва-Екатеринбург':9,
      'Москва-Новосибирск':16,'Москва-Владивосток':30,'Москва-Сочи':8,'Москва-Калининград':6};
    const key = a+'-'+b, key2 = b+'-'+a;
    if(pairs[key]) return pairs[key];
    if(pairs[key2]) return pairs[key2];
    return Math.max(2, Math.round(this.getDist(a,b)/80));
  }
};

/* ---------- АВТО ---------- */
const Cars = {
  list: [
    {name:'Лада Гранта', desc:'Надёжная, но медленная', price:300000, color:0x3b82f6},
    {name:'Toyota Camry', desc:'Комфорт и надёжность', price:1800000, color:0xd1d5db},
    {name:'BMW 5', desc:'Статусно', price:3500000, color:0x1e293b},
    {name:'Tesla Model 3', desc:'Электро', price:5000000, color:0xef4444},
    {name:'Kia Rio', desc:'Бюджетный', price:600000, color:0x10b981},
    {name:'Mercedes E', desc:'Роскошь', price:4200000, color:0x111827},
    {name:'Audi A6', desc:'Стиль', price:3800000, color:0x64748b},
    {name:'VW Polo', desc:'Немецкое качество', price:900000, color:0x8b5cf6}
  ]
};