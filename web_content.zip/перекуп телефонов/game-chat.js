/* ============================================================
   CHAT: продавцы, покупатели, обмен, события, сохранения
   ============================================================ */
const Chat = {
  startWithSeller(phone){
    const existing = Player.messages.findIndex(m=>m.phoneId===phone.id && m.type==='seller');
    if(existing>=0){ Apps.openChat(existing); return; }
    const msg = {
      type: 'seller', phoneId: phone.id, name: phone.sellerName,
      msgs: [{me:false, text:`Привет! Это по поводу ${phone.brand} ${phone.model}. Ещё актуально?`}],
      last: 'Ещё актуально?'
    };
    Player.messages.push(msg);
    Apps.chat();
    Apps.openChat(Player.messages.length-1);
  },
  addMsg(idx, me, text){
    const m = Player.messages[idx];
    if(!m) return;
    m.msgs.push({me, text});
    m.last = text;
    if(UI.currentApp==='chat') Apps.openChat(idx);
  },
  haggle(idx){
    const m = Player.messages[idx];
    if(!m || m.type!=='seller') return;
    const p = Catalog.market.find(x=>x.id===m.phoneId);
    if(!p) return;
    const discount = clamp(rand(5,20) + (Player.rep-3)*3, 0, 30);
    const success = Math.random() < (0.4 + Player.rep*0.08);
    if(success){
      const newP = Math.round(p.price * (1-discount/100));
      p.price = newP;
      this.addMsg(idx, false, `Ладно, ${Math.round(discount)}% скину — ${fmtFull(newP)}`);
      UI.toast(`💰 Торг: -${Math.round(discount)}%`);
    } else {
      this.addMsg(idx, false, 'Нет, цена уже минимальная');
      UI.toast('❌ Торг провален'); AudioFX.error();
    }
  },
  offerTrade(idx){
    const m = Player.messages[idx];
    if(!m || m.type!=='seller') return;
    const readyItems = Player.warehouse.filter(w=>w.ready && !w.forSale);
    if(readyItems.length === 0){ UI.toast('Нет готовых телефонов'); return; }
    UI.modal(`
      <h3>🔄 Обмен</h3>
      <p style="font-size:11px;color:#ccc;">Выберите телефон + доплата</p>
      ${readyItems.map((w,i)=>`
        <div class="card" style="cursor:pointer;" onclick="Chat.tradeConfirm(${idx},${i})">
          <div class="title">${w.brand} ${w.model}</div>
          <div class="meta">${w.condition} · ~${fmtFull(w.basePrice)}</div>
        </div>
      `).join('')}
    `);
  },
  tradeConfirm(idx, itemIdx){
    const m = Player.messages[idx];
    if(!m) return;
    const p = Catalog.market.find(x=>x.id===m.phoneId);
    const readyItems = Player.warehouse.filter(w=>w.ready && !w.forSale);
    const w = readyItems[itemIdx];
    if(!w || !p) return;
    $('.modal-back.show')?.remove();
    const myValue = Math.round(w.basePrice * 0.8);
    const needExtra = p.price - myValue;
    UI.modal(`
      <h3>🔄 Обмен</h3>
      <p style="font-size:12px;color:#ccc;">Ваш: ${fmtFull(myValue)}<br>Его: ${fmtFull(p.price)}<br>Доплата: ${needExtra>0?fmtFull(needExtra):'0₽'}</p>
      <button class="btn btn-primary btn-full" onclick="Chat.doExchange(${idx},${Player.warehouse.indexOf(w)},${Math.max(0,needExtra)})">Предложить</button>
    `);
  },
  doExchange(chatIdx, whIdx, extra){
    const m = Player.messages[chatIdx];
    if(!m) return;
    const p = Catalog.market.find(x=>x.id===m.phoneId);
    const w = Player.warehouse[whIdx];
    if(!w || !p) return;
    $('.modal-back.show')?.remove();
    if(extra > Player.money){ UI.toast('Не хватает на доплату'); return; }
    const chance = 0.5 + Player.rep*0.08;
    if(Math.random() > chance){
      this.addMsg(chatIdx, false, 'Нет, обмен не интересен');
      UI.toast('❌ Отказ'); return;
    }
    if(extra > 0) Player.addMoney(-extra);
    Player.warehouse = Player.warehouse.filter(x=>x!==w);
    const owned = {
      id: p.id, brand:p.brand, model:p.model, color:p.color, basePrice:p.basePrice,
      condition: p.condition, bought: extra, repairCost:0,
      repairNeeded: p.repairNeeded, defect: p.hiddenDefect,
      ready: !p.repairNeeded, forSale:false, salePrice:0
    };
    Player.warehouse.push(owned);
    Catalog.market = Catalog.market.filter(x=>x.id!==p);
    Player.messages = Player.messages.filter(x=>x!==m);
    UI.toast('🤝 Обмен!'); AudioFX.coin();
    UI.closeApp();
  },
  arrange(idx){
    const m = Player.messages[idx];
    if(!m) return;
    const p = Catalog.market.find(x=>x.id===m.phoneId);
    if(!p) return;
    UI.modal(`
      <h3>📍 Встреча</h3>
      <p style="font-size:12px;color:#ccc;">Продавец: ${p.city}<br>Вы: ${Player.currentCity}</p>
      ${p.city!==Player.currentCity?
        `<p style="font-size:12px;color:#f59e0b;">Сначала доедь до ${p.city}</p>
         <button class="btn btn-warn btn-full" onclick="UI.closeApp();UI.openApp('map')">Карта</button>`:
        `<button class="btn btn-primary btn-full" onclick="Chat.meetNow(${idx})">Встретиться</button>`}
    `);
  },
  meetNow(idx){
    $('.modal-back.show')?.remove();
    const chat = Player.messages[idx];
    if(!chat) return;
    const p = Catalog.market.find(x=>x.id===chat.phoneId);
    if(!p) return;
    UI.modal(`
      <h3>👀 Осмотр</h3>
      <button class="btn btn-secondary btn-full" style="margin:4px 0;" onclick="Chat.inspect(${idx},false)">Сам</button>
      <button class="btn btn-warn btn-full" style="margin:4px 0;" onclick="Chat.inspect(${idx},true)">Специалист (100к)</button>
      <button class="btn btn-primary btn-full" style="margin:4px 0;" onclick="Chat.buyNow(${idx})">Купить</button>
      <button class="btn btn-danger btn-full" style="margin:4px 0;" onclick="UI.closeModal()">Отмена</button>
    `);
  },
  inspect(idx, pro){
    Quests.progress('inspectsToday');
    const chat = Player.messages[idx];
    if(!chat) return;
    const p = Catalog.market.find(x=>x.id===chat.phoneId);
    if(!p) return;
    if(pro){
      if(Player.money<100000){ UI.toast('Нет денег'); return; }
      Player.addMoney(-100000);
    }
    const chance = pro ? 0.5 : 0.1 * (Player.energy/100);
    const found = p.hiddenDefect && Math.random() < chance;
    p.defectFound = found;
    $('.modal-back.show')?.remove();
    if(found){
      UI.modal(`
        <h3>🔍 Дефект!</h3>
        <p style="color:#f59e0b;font-size:13px;">${p.hiddenDefect}</p>
        <button class="btn btn-warn btn-full" style="margin:4px 0;" onclick="Chat.haggleDefect(${idx})">-20%</button>
        <button class="btn btn-primary btn-full" style="margin:4px 0;" onclick="Chat.buyNow(${idx})">Купить</button>
        <button class="btn btn-danger btn-full" style="margin:4px 0;" onclick="UI.closeModal()">Отмена</button>
      `);
    } else {
      UI.modal(`
        <h3>✅ Дефектов нет</h3>
        <button class="btn btn-primary btn-full" style="margin:4px 0;" onclick="Chat.buyNow(${idx})">Купить</button>
        <button class="btn btn-danger btn-full" style="margin:4px 0;" onclick="UI.closeModal()">Отмена</button>
      `);
    }
  },
  haggleDefect(idx){
    const chat = Player.messages[idx];
    if(!chat) return;
    const p = Catalog.market.find(x=>x.id===chat.phoneId);
    if(!p) return;
    p.price = Math.round(p.price*0.8);
    $('.modal-back.show')?.remove();
    UI.toast('💰 -20%');
    this.buyNow(idx);
  },
  buyNow(idx){
    $('.modal-back.show')?.remove();
    const chat = Player.messages[idx];
    if(!chat) return;
    const p = Catalog.market.find(x=>x.id===chat.phoneId);
    if(!p) return;
    if(Player.money<p.price){ UI.toast('Нет денег'); return; }
    Player.addMoney(-p.price);
    const owned = {
      id: p.id, brand:p.brand, model:p.model, color:p.color, basePrice:p.basePrice,
      condition: p.condition, bought: p.price, repairCost:0,
      repairNeeded: p.repairNeeded, defect: p.hiddenDefect,
      ready: !p.repairNeeded, forSale: false, salePrice: 0
    };
    Player.warehouse.push(owned);
    Catalog.market = Catalog.market.filter(x=>x.id!==p);
    Player.messages = Player.messages.filter(x=>x!==chat);
    Quests.progress('buysToday');
    UI.toast('✅ Куплено!'); AudioFX.success();
    UI.closeApp();
  },
  cancelDeal(idx){
    Player.messages.splice(idx,1);
    UI.toast('❌ Отменено');
    UI.closeApp();
  },
  buyerAccept(idx){
    const m = Player.messages[idx];
    if(!m) return;
    const w = Player.warehouse.find(x=>x.id===m.phoneId);
    if(!w) return;
    Player.addMoney(w.salePrice);
    Player.stats.deals++; Player.addRep(0.1);
    Quests.progress('dealsToday');
    Player.warehouse = Player.warehouse.filter(x=>x!==w);
    Player.messages.splice(idx,1);
    UI.toast(`💰 +${fmtFull(w.salePrice)}`);
    AudioFX.coin(); Achievements.check();
    UI.closeApp();
  },
  buyerHaggle(idx){
    const m = Player.messages[idx];
    if(!m) return;
    const w = Player.warehouse.find(x=>x.id===m.phoneId);
    if(!w) return;
    if(Math.random()<0.5){ w.salePrice = Math.round(w.salePrice*0.95); this.buyerAccept(idx); }
    else { UI.toast('❌ Ушёл'); Player.messages.splice(idx,1); UI.closeApp(); }
  },
  buyerDecline(idx){
    Player.messages.splice(idx,1);
    UI.toast('👋 Отшит');
    UI.closeApp();
  }
};

const Buyers = {
  queueBuyer(warehouseIdx){
    const w = Player.warehouse[warehouseIdx];
    if(!w) return;
    const delay = w.salePrice < w.basePrice ? randi(5000, 30000) : randi(60000, 180000);
    setTimeout(()=>{
      if(!w.forSale) return;
      const isAdequate = Math.random() > 0.2;
      const msg = {
        type: 'buyer', phoneId: w.id,
        name: isAdequate? pick(['Иван','Мария','Пётр','Анна','Сергей']) : '😡 НЕАДЕКВАТ',
        msgs: [{me:false, text: isAdequate
          ? `Здравствуйте! Интересует ${w.brand} ${w.model} за ${fmtFull(w.salePrice)}. Ещё актуально?`
          : `СЛУШАЙ БРАТ СКИДКУ ДАВАЙ ИЛИ ЖАЛОБУ НАПИШУ!!!`}],
        last: 'Новое сообщение'
      };
      Player.messages.push(msg);
      UI.notif('💬 Покупатель', `${msg.name} → ${w.model}`, 'ico-chat');
      UI.updateStatus();
    }, Math.min(delay, 60000));
  }
};

const Game = {
  randomEvent(){
    if(Math.random() > 0.3) return;
    const events = [
      ()=>{ Player.addEnergy(-10); UI.notif('😴 Усталость','Энергия -10', 'ico-sleep'); },
      ()=>{ Player.addMoney(1000); UI.notif('💵 Находка','+1000₽', 'ico-avito'); },
      ()=>{ if(Player.warehouse.length>0){ const w=pick(Player.warehouse); w.condition='Хорошее'; UI.notif('🔧 Бонус','Улучшение', 'ico-repair'); } },
      ()=>{ if(Math.random()<0.5){ const p = Catalog.generatePhone(); p.isHot = true; Catalog.market.push(p); UI.notif('🔥 Лот','Новое', 'ico-avito'); } }
    ];
    pick(events)();
  }
};

const Save = {
  KEY: 'perekup_save_v3',
  save(){
    try{
      localStorage.setItem(this.KEY, JSON.stringify({
        money: Player.money, rep: Player.rep, energy: Player.energy,
        city: Player.currentCity, warehouse: Player.warehouse, cars: Player.cars,
        activeCar: Player.activeCar, stats: Player.stats,
        imeiCheckUnlocked: Player.imeiCheckUnlocked, taxiUnlocked: Player.taxiUnlocked,
        hour: Time.hour, day: Time.day, market: Catalog.market, nextId: Catalog.nextId,
        favorites: Player.favorites, achievements: Player.achievements,
        visitedCities: Player.visitedCities, questsDay: Player.questsDays || 0,
        today: Player.today, messages: Player.messages
      }));
    }catch(e){}
  },
  load(){
    try{
      const raw = localStorage.getItem(this.KEY);
      if(!raw) return false;
      const d = JSON.parse(raw);
      Object.assign(Player, {
        money: d.money, rep: d.rep, energy: d.energy, currentCity: d.city,
        warehouse: d.warehouse||[], cars: d.cars||[], activeCar: d.activeCar,
        stats: d.stats||Player.stats, imeiCheckUnlocked: d.imeiCheckUnlocked,
        taxiUnlocked: d.taxiUnlocked, favorites: d.favorites||[],
        achievements: d.achievements||[], visitedCities: d.visitedCities||['Москва'],
        questsDay: d.questsDay||0, today: d.today||{}, messages: d.messages||[]
      });
      Time.hour = d.hour||9; Time.day = d.day||1;
      Catalog.market = d.market||[]; Catalog.nextId = d.nextId||1;
      return true;
    }catch(e){ return false; }
  },
  reset(){
    if(confirm('Сбросить?')){ localStorage.removeItem(this.KEY); location.reload(); }
  }
};

function initHome(){
  const grid = $('#appGrid');
  const apps = [
    {app:'avito', icon:'ico-avito', fa:'fa-shopping-bag', name:'Avito'},
    {app:'repair', icon:'ico-repair', fa:'fa-tools', name:'Ремонт'},
    {app:'sleep', icon:'ico-sleep', fa:'fa-moon', name:'Сон'},
    {app:'map', icon:'ico-map', fa:'fa-map-marked-alt', name:'Карта'},
    {app:'chat', icon:'ico-chat', fa:'fa-comments', name:'Чаты'},
    {app:'car', icon:'ico-car', fa:'fa-car', name:'Автосалон'},
    {app:'warehouse', icon:'ico-warehouse', fa:'fa-box', name:'Склад'},
    {app:'quests', icon:'ico-quest', fa:'fa-bullseye', name:'Квесты'},
    {app:'stats', icon:'ico-stats', fa:'fa-chart-line', name:'Профиль'}
  ];
  grid.innerHTML = apps.map(a=>`
    <div class="app-icon" data-app="${a.app}">
      <div class="icon-box ${a.icon}"><i class="fas ${a.fa}"></i></div>
      <span>${a.name}</span>
    </div>
  `).join('');
  grid.querySelectorAll('.app-icon').forEach(el=>{
    el.addEventListener('click', ()=> UI.openApp(el.dataset.app));
  });
  document.querySelectorAll('#dock .app-icon').forEach(el=>{
    el.addEventListener('click', ()=> UI.openApp(el.dataset.app));
  });
}

function init(){
  DeviceType.apply();
  if(!Save.load()){
    Catalog.init();
    Quests.generate();
  } else {
    if(Catalog.allPhones.length===0) Catalog.init();
    if(!Catalog.market.length) Catalog.refreshMarket();
    if(!Quests.current.length) Quests.generate();
  }
  initHome();
  UI.updateStatus();
  setInterval(()=>{ Time.tick(); UI.updateStatus(); }, 200);
  setInterval(()=>{ Save.save(); }, 10000);
  setTimeout(()=>{
    UI.notif('👋 Добро пожаловать!', 'Покупай, чини, продавай!', 'ico-avito');
  }, 800);
}

window.addEventListener('DOMContentLoaded', init);