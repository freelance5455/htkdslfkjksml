/* ============================================================
   BOOT: инициализация, иконки с fallback, защита от падений
   ============================================================ */

/* ---------- Проверка: загрузился ли Font Awesome ---------- */
function isFontAwesomeLoaded(){
  try{
    const test = document.createElement('i');
    test.className = 'fas fa-check';
    test.style.position = 'absolute';
    test.style.opacity = '0';
    test.style.left = '-9999px';
    document.body.appendChild(test);
    const font = getComputedStyle(test, ':before').fontFamily || '';
    document.body.removeChild(test);
    return /fontawesome|font awesome/i.test(font);
  }catch(e){ return false; }
}

/* ---------- Словарь эмодзи-фолбэков ---------- */
const ICON_FALLBACK = {
  'fa-shopping-bag':'🛒',
  'fa-tools':'🔧',
  'fa-moon':'🌙',
  'fa-map-marked-alt':'🗺',
  'fa-comments':'💬',
  'fa-car':'🚗',
  'fa-box':'📦',
  'fa-chart-line':'📊',
  'fa-bullseye':'🎯',
  'fa-bell':'🔔',
  'fa-coins':'💰',
  'fa-star':'⭐',
  'fa-battery-three-quarters':'🔋',
  'fa-sun':'☀',
  'fa-cloud-sun':'⛅',
  'fa-chevron-left':'‹',
  'fa-user':'👤',
  'fa-heart':'❤',
  'fa-shield-alt':'🛡',
  'fa-bed':'🛏',
  'fa-comment':'💬'
};

/* ---------- Применение эмодзи только если FA НЕ загрузился ---------- */
function applyIconFallback(root){
  if(isFontAwesomeLoaded()){
    console.log('[Icons] Font Awesome загружен ✅');
    // На всякий случай чистим текстовые эмодзи внутри <i>, если они остались
    (root || document).querySelectorAll('i[class*="fa-"]').forEach(el=>{
      if(el.textContent && el.textContent.trim().length > 0 && el.textContent.length < 6){
        el.textContent = '';
      }
    });
    return;
  }
  console.warn('[Icons] Font Awesome НЕ загрузился — использую эмодзи');
  (root || document).querySelectorAll('i[class*="fa-"]').forEach(el=>{
    // не дублируем, если эмодзи уже есть
    if(el.textContent && el.textContent.trim()) return;
    const cls = [...el.classList].find(c =>
      c.startsWith('fa-') && c !== 'fa-solid' && c !== 'fa-regular' && c !== 'fa-brands'
    );
    if(cls && ICON_FALLBACK[cls]){
      el.textContent = ICON_FALLBACK[cls];
      el.style.fontStyle = 'normal';
    } else {
      el.textContent = '•';
    }
  });
}

/* ---------- initHome: рисуем иконки БЕЗ вложенных эмодзи ---------- */
function initHome(){
  const grid = document.getElementById('appGrid');
  if(!grid){
    console.error('[initHome] #appGrid не найден!');
    return;
  }
  const apps = [
    {app:'avito',     icon:'ico-avito',     fa:'fa-shopping-bag',   name:'Avito'},
    {app:'repair',    icon:'ico-repair',    fa:'fa-tools',          name:'Ремонт'},
    {app:'sleep',     icon:'ico-sleep',     fa:'fa-moon',           name:'Сон'},
    {app:'map',       icon:'ico-map',       fa:'fa-map-marked-alt', name:'Карта'},
    {app:'chat',      icon:'ico-chat',      fa:'fa-comments',       name:'Чаты'},
    {app:'car',       icon:'ico-car',       fa:'fa-car',            name:'Автосалон'},
    {app:'warehouse', icon:'ico-warehouse', fa:'fa-box',            name:'Склад'},
    {app:'quests',    icon:'ico-quest',     fa:'fa-bullseye',       name:'Квесты'},
    {app:'stats',     icon:'ico-stats',     fa:'fa-chart-line',     name:'Профиль'}
  ];
  // ВАЖНО: внутри <i> НЕТ эмодзи — только класс FA
  grid.innerHTML = apps.map(a=>`
    <div class="app-icon" data-app="${a.app}">
      <div class="icon-box ${a.icon}"><i class="fas ${a.fa}"></i></div>
      <span>${a.name}</span>
    </div>
  `).join('');

  grid.querySelectorAll('.app-icon').forEach(el=>{
    el.addEventListener('click', ()=>{
      try{ UI.openApp(el.dataset.app); }
      catch(e){ console.error('openApp:', e); alert('Ошибка: '+e.message); }
    });
  });
  document.querySelectorAll('#dock .app-icon').forEach(el=>{
    el.addEventListener('click', ()=>{
      try{ UI.openApp(el.dataset.app); }
      catch(e){ console.error('openApp:', e); }
    });
  });

  console.log('[initHome] иконок отрисовано:', grid.children.length);
}

/* ---------- ГЛАВНАЯ ИНИЦИАЛИЗАЦИЯ ---------- */
function bootGame(){
  console.log('[Boot] старт');

  try{
    if(typeof DeviceType !== 'undefined') DeviceType.apply();
    else console.warn('DeviceType не найден');
  }catch(e){ console.error('DeviceType:', e); }

  try{
    if(typeof Save === 'undefined' || typeof Catalog === 'undefined'){
      throw new Error('Save или Catalog не загрузились (game-core.js?)');
    }
    if(!Save.load()){
      Catalog.init();
      if(typeof Quests !== 'undefined') Quests.generate();
    } else {
      if(!Catalog.allPhones || Catalog.allPhones.length===0) Catalog.init();
      if(!Catalog.market || Catalog.market.length===0) Catalog.refreshMarket();
      if(typeof Quests !== 'undefined' && (!Quests.current || Quests.current.length===0)) Quests.generate();
    }
    console.log('[Boot] сохранение загружено');
  }catch(e){
    console.error('[Boot] Ошибка загрузки:', e);
    try{
      if(typeof Catalog !== 'undefined') Catalog.init();
      if(typeof Quests !== 'undefined') Quests.generate();
    }catch(e2){ console.error('Катастрофа:', e2); }
  }

  try{ initHome(); }
  catch(e){ console.error('[Boot] initHome упал:', e); }

  try{ applyIconFallback(document); }
  catch(e){ console.warn('fallback:', e); }

  try{ if(typeof UI !== 'undefined') UI.updateStatus(); }
  catch(e){ console.error('updateStatus:', e); }

  setInterval(()=>{
    try{ Time.tick(); UI.updateStatus(); }catch(e){}
  }, 200);
  setInterval(()=>{
    try{ Save.save(); }catch(e){}
  }, 10000);

  setTimeout(()=>{
    try{ UI.notif('👋 Добро пожаловать!', 'Покупай, чини, продавай!', 'ico-avito'); }catch(e){}
  }, 800);

  console.log('[Boot] игра запущена ✅');
}

/* ---------- ЗАПУСК ---------- */
if(document.readyState === 'loading'){
  document.addEventListener('DOMContentLoaded', bootGame);
} else {
  bootGame();
}

/* ---------- Fallback ---------- */
setTimeout(()=>{
  const grid = document.getElementById('appGrid');
  if(grid && grid.children.length === 0){
    console.warn('[Boot] сетка пуста — повторная попытка');
    bootGame();
  }
}, 3000);