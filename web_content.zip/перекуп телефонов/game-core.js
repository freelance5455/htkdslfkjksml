/* ============================================================
   CORE: утилиты, звук, время, игрок, каталог (250+), 3D
   + авто-определение типа устройства
   ============================================================ */
const $ = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);
const rand = (a,b)=> Math.random()*(b-a)+a;
const randi = (a,b)=> Math.floor(rand(a,b+1));
const pick = arr => arr[Math.floor(Math.random()*arr.length)];
const clamp = (v,a,b)=> Math.max(a,Math.min(b,v));
const fmtMoney = n => {
  if(Math.abs(n)>=1000000) return (n/1000000).toFixed(2)+'M';
  if(Math.abs(n)>=1000) return (n/1000).toFixed(0)+'k';
  return Math.round(n).toString();
};
const fmtFull = n => Math.round(n).toLocaleString('ru-RU')+'₽';

/* ---------- ОПРЕДЕЛЕНИЕ УСТРОЙСТВА ---------- */
const DeviceType = {
  detect(){
    const w = window.innerWidth, h = window.innerHeight;
    const ua = navigator.userAgent.toLowerCase();
    const isMobile = /android|iphone|ipad|ipod|mobile/.test(ua);
    const isTablet = /ipad|tablet/.test(ua) || (isMobile && Math.min(w,h) > 600);
    let type = 'laptop';
    if(isTablet) type = 'tablet';
    else if(isMobile && w < 800) type = 'phone';
    else if(w < 900) type = 'phone';
    return type;
  },
  apply(){
    const type = this.detect();
    const device = $('#device');
    if(!device) return;
    device.dataset.type = type;
    // сохраним для отладки
    console.log('Device type:', type);
  }
};

/* ---------- ЗВУК ---------- */
const AudioFX = (()=>{
  let ctx=null;
  const ac = ()=> ctx || (ctx = new (window.AudioContext||window.webkitAudioContext)());
  function tone(f,d,type='sine',vol=0.08){
    try{
      const c=ac(), o=c.createOscillator(), g=c.createGain();
      o.type=type; o.frequency.value=f;
      g.gain.setValueAtTime(vol,c.currentTime);
      g.gain.exponentialRampToValueAtTime(0.001,c.currentTime+d);
      o.connect(g); g.connect(c.destination);
      o.start(); o.stop(c.currentTime+d);
    }catch(e){}
  }
  return {
    click(){ tone(800,0.05,'square',0.05); },
    coin(){ tone(1200,0.08,'sine',0.1); setTimeout(()=>tone(1600,0.12,'sine',0.1),80); },
    success(){ tone(600,0.1); setTimeout(()=>tone(900,0.15),100); },
    error(){ tone(200,0.2,'sawtooth',0.08); },
    notif(){ tone(1000,0.06); setTimeout(()=>tone(1300,0.06),70); },
    screw(){ tone(300,0.03,'square',0.03); },
    fw(){ tone(500,0.1,'sine',0.05); }
  };
})();

/* ---------- ВРЕМЯ ---------- */
const Time = {
  hour:9, day:1, speed:1, paused:false, travel:null, lastTick: Date.now(), listeners:[],
  weather:'sunny',
  tick(){
    if(this.paused) return;
    const now = Date.now();
    const realMin = (now - this.lastTick)/60000;
    this.lastTick = now;
    this.advance(realMin * this.speed);
  },
  advance(h){
    if(this.travel){
      this.travel.hoursLeft -= h;
      if(this.travel.hoursLeft <= 0){
        const dest = this.travel.to;
        this.travel = null;
        Player.currentCity = dest;
        UI.notif('🗺️ Прибытие', `Вы прибыли в ${dest}`, 'ico-map');
        AudioFX.success();
      }
    }
    this.hour += h;
    while(this.hour >= 24){ this.hour -= 24; this.day++; this.onNewDay(); }
    this.listeners.forEach(fn=>fn());
  },
  onNewDay(){
    const roll = Math.random();
    this.weather = roll<0.5?'sunny':roll<0.75?'cloudy':roll<0.92?'rain':'snow';
    Player.dailyEvents();
    Game.randomEvent();
    Quests.regenerate();
  },
  sleepTo(hour, day){
    this.day = day || (this.hour>=6? this.day+1 : this.day);
    this.hour = hour;
    this.listeners.forEach(fn=>fn());
  },
  isNight(){ return this.hour<6 || this.hour>=22; },
  hhmm(){ const h=Math.floor(this.hour), m=Math.floor((this.hour-h)*60); return String(h).padStart(2,'0')+':'+String(m).padStart(2,'0'); }
};

/* ---------- ИГРОК ---------- */
const Player = {
  money: 50000, rep: 3.0, energy: 100, currentCity: 'Москва',
  warehouse: [], cars: [], activeCar: null,
  stats: { deals:0, spent:0, earned:0, repairs:0, failed:0, inspected:0 },
  messages: [], imeiCheckUnlocked:false, taxiUnlocked:false,
  eventModifier: { price:1, expiresDay:0 },
  favorites: [], achievements: [], upgrades: {}, questsDay:0,
  visitedCities: ['Москва'],
  today: {},
  addMoney(v){ this.money+=v; if(v>0) this.stats.earned+=v; else this.stats.spent+=Math.abs(v); UI.updateStatus(); Save.save(); },
  addRep(v){ this.rep = clamp(this.rep+v, 0, 5); UI.updateStatus(); Save.save(); },
  addEnergy(v){ this.energy = clamp(this.energy+v,0,100); UI.updateStatus(); },
  rank(){
    if(this.stats.deals>=50) return '👑 Империя';
    if(this.stats.deals>=25) return '💼 Бизнесмен';
    if(this.stats.deals>=10) return '📱 Перекуп';
    return '🛒 Барыга';
  },
  dailyEvents(){
    if(Time.hour>=6 && Time.hour<10) this.addEnergy(30);
    Achievements.check();
  }
};

/* ---------- ДОСТИЖЕНИЯ ---------- */
const Achievements = {
  list: [
    {id:'first_deal', icon:'🎉', name:'Первая сделка', desc:'Продай 1 телефон', check:p=>p.stats.deals>=1},
    {id:'ten_deals', icon:'📱', name:'Перекуп', desc:'10 сделок', check:p=>p.stats.deals>=10},
    {id:'rich', icon:'💰', name:'Богач', desc:'100 000₽', check:p=>p.money>=100000},
    {id:'millionaire', icon:'💎', name:'Миллионер', desc:'1 000 000₽', check:p=>p.money>=1000000},
    {id:'rep5', icon:'⭐', name:'Идеал', desc:'Репутация 5.0', check:p=>p.rep>=5},
    {id:'collector', icon:'📦', name:'Коллекционер', desc:'5 телефонов', check:p=>p.warehouse.length>=5},
    {id:'traveler', icon:'✈️', name:'Путешественник', desc:'3 города', check:p=>(p.visitedCities||[]).length>=3},
    {id:'fixer', icon:'🔧', name:'Мастер', desc:'10 ремонтов', check:p=>p.stats.repairs>=10},
    {id:'car_owner', icon:'🚗', name:'Автовладелец', desc:'Купи машину', check:p=>p.cars.length>=1}
  ],
  check(){
    this.list.forEach(a=>{
      if(!Player.achievements.includes(a.id) && a.check(Player)){
        Player.achievements.push(a.id);
        UI.notif('🏆 Достижение!', `${a.icon} ${a.name}`, 'ico-stats');
        AudioFX.success();
      }
    });
  }
};

/* ---------- КВЕСТЫ ---------- */
const Quests = {
  current: [],
  generate(){
    const pool = [
      {id:'sell2', title:'Продай 2 телефона', desc:'Сегодня', target:2, reward:5000, key:'dealsToday'},
      {id:'fix1', title:'Почини 1 телефон', desc:'Сегодня', target:1, reward:3000, key:'repairsToday'},
      {id:'buy1', title:'Купи 1 телефон', desc:'Сегодня', target:1, reward:4000, key:'buysToday'},
      {id:'inspect1', title:'Осмотри 1 товар', desc:'Сегодня', target:1, reward:2000, key:'inspectsToday'}
    ];
    this.current = [pick(pool), pick(pool)];
    this.current.forEach(q=> q.done = false);
    Player.today = {dealsToday:0, repairsToday:0, buysToday:0, inspectsToday:0};
  },
  regenerate(){ if(Player.questsDay !== Time.day){ Player.questsDay = Time.day; this.generate(); } },
  progress(key){ if(Player.today && Player.today[key]!==undefined) Player.today[key]++; },
  claim(i){
    const q = this.current[i];
    if(!q) return;
    Player.addMoney(q.reward);
    q.done = true;
    UI.toast(`🎁 +${fmtFull(q.reward)}`);
    AudioFX.coin();
    UI.openApp('quests');
  }
};

/* ---------- КАТАЛОГ (250+ моделей) ---------- */
const Catalog = {
  brands: [
    {name:'Nokia', models:['3310','1100','N95','N8','Lumia 800','Lumia 1020','X20','G20','C30','X30'], color:0x1f2937},
    {name:'Motorola', models:['RAZR V3','RAZR V8','Moto G','Moto G7','Edge 20','Edge 40','Razr 5G','Defy'], color:0x4b5563},
    {name:'Sony Ericsson', models:['W800','K750','W810','T650','Xperia Z','Xperia Z3','Xperia XZ','Xperia 1'], color:0x111827},
    {name:'Apple', models:['iPhone 3G','iPhone 4','iPhone 4s','iPhone 5','iPhone 5s','iPhone 6','iPhone 6s','iPhone 7','iPhone 8','iPhone X','iPhone XR','iPhone 11','iPhone 12','iPhone 12 Pro','iPhone 13','iPhone 13 Pro','iPhone 14','iPhone 14 Pro Max','iPhone 15','iPhone 15 Pro Max','iPhone 16','iPhone 16 Pro','iPhone 17','iPhone 18 Pro Max'], color:0xe5e7eb},
    {name:'Samsung', models:['Galaxy S','S2','S3','S4','S5','S6','S7','S8','S9','S10','S20','S21','S22','S23','S24 Ultra','Note 3','Note 5','Note 8','Note 10','Note 20','A52','A72','M21','Z Fold 3','Z Flip 4'], color:0x2563eb},
    {name:'Xiaomi', models:['Redmi Note 4','Redmi Note 5','Redmi Note 7','Redmi Note 8','Redmi Note 10','Redmi Note 12','Redmi Note 13','Mi 8','Mi 9','Mi 10','Mi 11','Mi 12','Poco X3','Poco F3','Poco X5','13 Pro','14 Ultra'], color:0xf97316},
    {name:'Google', models:['Pixel','Pixel 2','Pixel 3','Pixel 4','Pixel 5','Pixel 6','Pixel 7','Pixel 8','Pixel 8 Pro','Pixel Fold'], color:0x10b981},
    {name:'OnePlus', models:['3','5','6','7','8','9','9 Pro','10 Pro','11','Nord 2','Nord 3'], color:0xef4444},
    {name:'Huawei', models:['P9','P10','P20','P30','P40 Pro','Mate 10','Mate 20','Mate 30','Mate 40'], color:0x8b5cf6},
    {name:'Realme', models:['3','5','6','7','8','9','GT','GT 2','GT Neo 3','C25','Narzo 50'], color:0xfacc15},
    {name:'Oppo', models:['R7','R11','R15','Reno 2','Reno 4','Reno 6','Reno 8','Find X3','Find X5'], color:0x22c55e},
    {name:'Vivo', models:['X20','X30','X50','X60','X70','X80','X90','Y33','Y55','V21','V23'], color:0x06b6d4},
    {name:'LG', models:['G2','G3','G4','G5','G6','G7','G8','V20','V30','V40','V50','Wing'], color:0xa3e635},
    {name:'HTC', models:['One M7','One M8','One M9','10','U11','U12','Desire 20'], color:0xf43f5e},
    {name:'Asus', models:['Zenfone 2','Zenfone 3','Zenfone 5','Zenfone 7','Zenfone 8','Zenfone 9','Zenfone 10','ROG Phone 2','ROG Phone 5'], color:0x6366f1},
    {name:'Lenovo', models:['K3 Note','P2','Z2','Z5','K10','Legion Duel'], color:0xd946ef},
    {name:'Meizu', models:['MX4','MX5','MX6','Pro 6','Pro 7','16th','17','18'], color:0x0891b2},
    {name:'ZTE', models:['Blade A1','Blade A3','Blade V8','Axon 7','Axon 10','Axon 30'], color:0x0ea5e9},
    {name:'Alcatel', models:['Idol 3','Idol 4','Pop 4','1S','3X','5V'], color:0x84cc16},
    {name:'BlackBerry', models:['Bold 9000','Curve 8520','Passport','Priv','KeyOne','Key2'], color:0x111827}
  ],
  conditions: ['Идеальное','Отличное','Хорошее','Есть царапины','Битый экран','Не включается','После ремонта'],
  defects: [
    'Звонит "барабан"','Выгорел угол экрана','Разряжается за час','Не работает вибро',
    'Хрипит динамик','Не заряжается','Тач глючит','Камера в пятнах',
    'Не работает Power','Пятно на экране','Не ловит сеть','Треснуто стекло камеры'
  ],
  sellers: ['Алексей','Мария','Дмитрий','Ольга','Сергей','Иван','Анна','Пётр','Наталья','Владимир','Елена','Максим'],
  cities: ['Москва','Санкт-Петербург','Казань','Екатеринбург','Новосибирск','Владивосток','Сочи','Калининград'],
  allPhones: [], market: [], nextId: 1,
  init(){
    this.allPhones = [];
    this.brands.forEach(b=>{
      b.models.forEach(m=>{
        this.allPhones.push({ brand:b.name, model:m, color:b.color, basePrice:this.estimatePrice(b.name, m) });
      });
    });
    this.refreshMarket();
  },
  estimatePrice(brand, model){
    const s = (brand+' '+model).toLowerCase();
    const flags = [
      {k:['3310','1100','bold','curve'], p:3000},
      {k:['razr v3','w800','k750','one m7'], p:8000},
      {k:['iphone 3g','iphone 4'], p:7000},
      {k:['iphone 4s','iphone 5'], p:9000},
      {k:['iphone 5s','iphone 6','iphone 6s'], p:14000},
      {k:['iphone 7','iphone 8'], p:18000},
      {k:['iphone x','iphone xr'], p:25000},
      {k:['iphone 11'], p:35000},
      {k:['iphone 12','iphone 13'], p:50000},
      {k:['iphone 14'], p:65000},
      {k:['iphone 15'], p:80000},
      {k:['iphone 16'], p:100000},
      {k:['iphone 17'], p:130000},
      {k:['iphone 18'], p:180000},
      {k:['s24'], p:70000},
      {k:['note'], p:40000},
      {k:['fold','flip'], p:90000},
      {k:['redmi'], p:12000},
      {k:['poco','mi 1'], p:25000},
      {k:['pixel'], p:30000},
      {k:['oneplus'], p:30000},
      {k:['p30','p40','mate 3','mate 4'], p:35000}
    ];
    for(const f of flags) for(const k of f.k) if(s.includes(k)) return f.p + randi(-2000, 2000);
    return randi(5000, 45000);
  },
  generatePhone(){
    const base = pick(this.allPhones);
    const cond = pick(this.conditions);
    const condMult = {'Идеальное':1.05,'Отличное':0.95,'Хорошее':0.82,'Есть царапины':0.7,'Битый экран':0.5,'Не включается':0.35,'После ремонта':0.88}[cond];
    const price = Math.round(base.basePrice * condMult * rand(0.8,1.2) * (Player.eventModifier.price||1));
    const hasHidden = Math.random() < 0.3;
    const sellerRep = hasHidden ? rand(3.0,4.2) : rand(4.3,5.0);
    return {
      id: this.nextId++,
      brand: base.brand, model: base.model, color: base.color,
      basePrice: base.basePrice, condition: cond, price,
      oldPrice: Math.random()<0.3 ? Math.round(price*1.15) : null,
      sellerRep, sellerName: pick(this.sellers), city: pick(this.cities),
      daysOnAvito: randi(1,30),
      hiddenDefect: hasHidden ? pick(this.defects) : null,
      defectFound: false, bought: null,
      repairNeeded: cond==='Битый экран' || cond==='Не включается' || hasHidden,
      repairCost: 0, ready: false, forSale: false, salePrice: 0,
      description: '', isHot: Math.random()<0.15, isNew: Math.random()<0.2,
      // для прошивки
      brandForFirmware: base.brand
    };
  },
  refreshMarket(){
    this.market = [];
    for(let i=0;i<150;i++){
      const p = this.generatePhone();
      p.description = this.makeDescription(p);
      this.market.push(p);
    }
  },
  makeDescription(p){
    let d = `${p.brand} ${p.model}, состояние: ${p.condition}. `;
    if(p.sellerRep<4.2) d += 'Торг возможен, срочно! Не звоните после 22:00. ';
    else d += 'Полный комплект, чехол в подарок. ';
    if(p.hiddenDefect) d += 'Всё работает, проверяйте при встрече.';
    return d;
  }
};

/* ---------- 3D ---------- */
const Three3D = {
  instances: [],
  createPhone(container, colorHex, model){
    if(!window.THREE){ container.innerHTML='<div class="spin">3D недоступно</div>'; return; }
    const w = container.clientWidth || 300, h = container.clientHeight || 200;
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, w/h, 0.1, 100);
    camera.position.set(2.2, 1.5, 3.2); camera.lookAt(0,0,0);
    const renderer = new THREE.WebGLRenderer({antialias:true, alpha:true});
    renderer.setSize(w,h); renderer.setPixelRatio(Math.min(window.devicePixelRatio,2));
    container.innerHTML=''; container.appendChild(renderer.domElement);
    scene.add(new THREE.AmbientLight(0xffffff, 0.7));
    const dl = new THREE.DirectionalLight(0xffffff, 1.2); dl.position.set(3,5,4); scene.add(dl);
    const dl2 = new THREE.DirectionalLight(0x22d3ee, 0.5); dl2.position.set(-3,-2,-3); scene.add(dl2);
    const group = new THREE.Group();
    const bodyMat = new THREE.MeshStandardMaterial({color:colorHex, metalness:0.6, roughness:0.35});
    group.add(new THREE.Mesh(new THREE.BoxGeometry(1.4, 2.6, 0.18), bodyMat));
    const screenMat = new THREE.MeshStandardMaterial({color:0x0f172a, metalness:0.2, roughness:0.1, emissive:0x1e40af, emissiveIntensity:0.3});
    const screen = new THREE.Mesh(new THREE.BoxGeometry(1.2, 2.2, 0.02), screenMat); screen.position.z = 0.1; group.add(screen);
    const camMat = new THREE.MeshStandardMaterial({color:0x000000, metalness:0.9, roughness:0.1});
    const cam = new THREE.Mesh(new THREE.CylinderGeometry(0.08,0.08,0.05,16), camMat);
    cam.rotation.x = Math.PI/2; cam.position.set(0.45, 1.15, 0.11); group.add(cam);
    const btnMat = new THREE.MeshStandardMaterial({color:0x333333, metalness:0.8});
    const btn = new THREE.Mesh(new THREE.BoxGeometry(0.05,0.3,0.08), btnMat); btn.position.set(0.72, 0.3, 0); group.add(btn);
    scene.add(group);
    let rotY=0, velY=0.01, dragging=false, lastX=0;
    const el = renderer.domElement;
    const onDown = e=>{dragging=true; lastX=(e.touches?e.touches[0].clientX:e.clientX);};
    const onMove = e=>{ if(!dragging) return; const x=(e.touches?e.touches[0].clientX:e.clientX); velY=(x-lastX)*0.01; lastX=x; };
    const onUp = ()=> dragging=false;
    el.addEventListener('mousedown',onDown); el.addEventListener('mousemove',onMove);
    el.addEventListener('mouseup',onUp); el.addEventListener('mouseleave',onUp);
    el.addEventListener('touchstart',onDown,{passive:true}); el.addEventListener('touchmove',onMove,{passive:true}); el.addEventListener('touchend',onUp);
    let alive = true;
    (function anim(){
      if(!alive) return;
      if(!dragging) velY += (0.012 - velY)*0.05;
      rotY += velY; group.rotation.y = rotY; group.rotation.x = Math.sin(rotY*0.5)*0.1;
      renderer.render(scene,camera); requestAnimationFrame(anim);
    })();
    const inst = {destroy(){alive=false; renderer.dispose(); if(el.parentNode) el.parentNode.removeChild(el);}};
    this.instances.push(inst); return inst;
  },
  destroyAll(){ this.instances.forEach(i=>i.destroy()); this.instances=[]; }
};

/* ---------- ИНИЦИАЛИЗАЦИЯ DEVICE ---------- */
window.addEventListener('resize', ()=> DeviceType.apply());