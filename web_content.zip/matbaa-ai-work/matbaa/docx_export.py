"""Builds a real, styled, RTL-aware DOCX from the designed booklet model."""
import copy, math, os, re, shutil, subprocess, tempfile
from lxml import etree
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import qn, nsdecls
from docx.shared import Pt, Cm, RGBColor, Emu
from .themes import resolve, FONTS, BOX_TYPES
from .analyzer import plain

ARABIC = re.compile(r"[؀-ۿ]")
LTR_LET = re.compile(r"[A-Za-z]")
BW_BORDER = {"definition": "double", "law": "single", "example": "dashed", "note": "dotted", "warning": "single",
             "important": "double", "question": "single", "answer": "dashed"}


def hex_rgb(h):
    h = h.lstrip("#")
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


def mix(h, t):
    r, g, b = hex_rgb(h)
    f = lambda c: int(c + (255 - c) * t)
    return "%02X%02X%02X" % (f(r), f(g), f(b))


def hx(h):
    return h.lstrip("#").upper()


def is_rtl(text):
    a, l = len(ARABIC.findall(text)), len(LTR_LET.findall(text))
    return a >= l


def el(tag, **attrs):
    e = OxmlElement(tag if ":" in tag else "w:" + tag)
    for k, v in attrs.items():
        e.set(qn("w:" + k), str(v))
    return e


class Builder:
    def __init__(self, proj, toc_pages=None):
        self.p = proj
        self.t = resolve(proj.get("theme"), proj.get("overrides"))
        self.c = self.t["colors"]
        self.fn = FONTS[self.t["font"]]["docx"]
        self.hfn = FONTS[self.t["headFont"]]["docx"]
        self.size = self.t["size"]
        self.meta = proj.get("meta", {})
        self.media = os.path.join(os.environ.get("MATBAA_MEDIA_ROOT", ""), "")
        self.media_dir = proj["_media_dir"]
        self.toc_pages = toc_pages  # list of ints or None
        self.doc = Document()
        self.headings = []
        self.chap = 0
        self.last_h1 = False

    # ------------------------------------------------------------ low level
    def font_run(self, run, size=None, bold=None, color=None, font=None, rtl=True, italic=None, underline=None):
        f = font or self.fn
        rpr = run._r.get_or_add_rPr()
        rf = rpr.find(qn("w:rFonts"))
        if rf is None:
            rf = el("rFonts")
            rpr.insert(0, rf)
        for a in ("ascii", "hAnsi", "cs", "eastAsia"):
            rf.set(qn("w:" + a), f)
        if rtl:
            rpr.append(el("rtl"))
        if size:
            run.font.size = Pt(size)
            szcs = el("szCs", val=int(size * 2))
            rpr.append(szcs)
        if bold is not None:
            run.font.bold = bold
            if bold:
                rpr.append(el("bCs"))
        if italic:
            run.font.italic = True
        if underline:
            run.font.underline = True
        if color:
            run.font.color.rgb = RGBColor(*hex_rgb(color))

    def para_fmt(self, par, rtl=True, align=None, before=0, after=0, line=None, keep_next=False):
        ppr = par._p.get_or_add_pPr()
        if rtl:
            ppr.append(el("bidi"))
        pf = par.paragraph_format
        pf.space_before = Pt(before)
        pf.space_after = Pt(after)
        if line:
            pf.line_spacing = line
        if keep_next:
            pf.keep_with_next = True
        if align == "center":
            par.alignment = WD_ALIGN_PARAGRAPH.CENTER
        elif align == "justify":
            par.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY

    def shade(self, par_or_cell, fill):
        if hasattr(par_or_cell, "_p"):
            pr = par_or_cell._p.get_or_add_pPr()
            pr.append(el("shd", val="clear", color="auto", fill=hx(fill)))
        else:
            tcpr = par_or_cell._tc.get_or_add_tcPr()
            for old in tcpr.findall(qn("w:shd")):
                tcpr.remove(old)
            tcpr.append(el("shd", val="clear", color="auto", fill=hx(fill)))

    def p_border(self, par, **sides):
        pr = par._p.get_or_add_pPr()
        b = el("pBdr")
        for side in ("top", "left", "bottom", "right"):
            if side in sides:
                v, sz, col, sp = sides[side]
                b.append(el(side, val=v, sz=sz, space=sp, color=hx(col)))
        pr.append(b)

    def cell_borders(self, cell, **sides):
        tcpr = cell._tc.get_or_add_tcPr()
        for old in tcpr.findall(qn("w:tcBorders")):
            tcpr.remove(old)
        b = el("tcBorders")
        for side in ("top", "start", "left", "bottom", "end", "right"):
            if side in sides:
                v, sz, col = sides[side]
                b.append(el(side, val=v, sz=sz, space=0, color=hx(col)))
        tcpr.append(b)

    def cell_margins(self, cell, top=60, bottom=60, start=120, end=120):
        tcpr = cell._tc.get_or_add_tcPr()
        m = el("tcMar")
        for side, v in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
            m.append(el(side, w=v, type="dxa"))
        tcpr.append(m)

    def table_setup(self, tbl, widths_pct=True):
        tblpr = tbl._tbl.tblPr
        tblpr.append(el("bidiVisual"))
        for old in tblpr.findall(qn("w:tblW")):
            tblpr.remove(old)
        tblpr.append(el("tblW", w=5000, type="pct"))
        tblpr.append(el("tblLayout", type="fixed"))
        for old in tblpr.findall(qn("w:tblStyle")):
            tblpr.remove(old)

    def add_runs(self, par, runs, size=None, color=None, rtl=True, bold=False):
        size = size or self.size
        for r in runs:
            if "m" in r:
                try:
                    par._p.append(etree.fromstring(r["m"]))
                except Exception:
                    pass
                continue
            parts = r["t"].split("\n")
            for i, part in enumerate(parts):
                run = par.add_run(part)
                col = color
                if r.get("k"):
                    col = self.c["kw"]
                elif r.get("b") and not bold:
                    col = self.c["bold"] if color is None or color == self.c["ink"] else color
                self.font_run(run, size=size * (0.7 if r.get("v") else 1), bold=bool(r.get("b")) or bold, color=col or self.c["ink"],
                              rtl=rtl, italic=r.get("i"), underline=r.get("u"))
                if r.get("v") == "sup":
                    run.font.superscript = True
                elif r.get("v") == "sub":
                    run.font.subscript = True
                if r.get("k"):
                    rpr = run._r.get_or_add_rPr()
                    rpr.append(el("shd", val="clear", color="auto", fill=hx(self.c["kwbg"])))
                if i < len(parts) - 1:
                    run.add_break()

    def spacer(self, pts=4):
        p = self.doc.add_paragraph()
        self.para_fmt(p, before=0, after=0)
        p.paragraph_format.line_spacing = Pt(pts)
        return p

    def field(self, par, instr, cached="1", size=10, color=None, rtl=False):
        def mk(kind):
            r = par.add_run()
            r._r.append(el("fldChar", fldCharType=kind))
            return r
        mk("begin")
        r = par.add_run()
        it = OxmlElement("w:instrText")
        it.set(qn("xml:space"), "preserve")
        it.text = " %s " % instr
        r._r.append(it)
        mk("separate")
        run = par.add_run(cached)
        self.font_run(run, size=size, color=color, rtl=rtl, bold=True)
        mk("end")

    # ------------------------------------------------------------ sections
    def setup_section(self, sec, cover=False):
        sec.page_width, sec.page_height = Cm(21), Cm(29.7)
        m = self.t["margins"]
        sec.top_margin, sec.bottom_margin = Cm(m["top"]), Cm(m["bottom"])
        sec.right_margin, sec.left_margin = Cm(m["inner"]), Cm(m["outer"])
        sec.header_distance, sec.footer_distance = Cm(1.0), Cm(0.9)
        sp = sec._sectPr
        frame = self.t["frame"]
        borders = None
        col = self.c["primary"]
        if cover and frame in ("ornate", "double"):
            borders = ("double", 18, col)
        elif cover and frame in ("round", "mono"):
            borders = ("single", 36 if frame == "mono" else 24, col)
        elif cover and frame == "simple":
            borders = ("single", 8, col)
        elif not cover and frame == "ornate":
            borders = ("single", 6, self.c["accent"])
        elif not cover and frame == "double":
            borders = ("single", 6, self.c["line"])
        if borders:
            for old in sp.findall(qn("w:pgBorders")):
                sp.remove(old)
            pb = el("pgBorders", offsetFrom="page")
            for side in ("top", "left", "bottom", "right"):
                pb.append(el(side, val=borders[0], sz=borders[1], space=24, color=hx(borders[2])))
            sp.find(qn("w:pgMar")).addnext(pb)
        for old in sp.findall(qn("w:bidi")):
            sp.remove(old)
        bidi = el("bidi")
        dg = sp.find(qn("w:docGrid"))
        if cover:
            va = el("vAlign", val="center")
            (dg.addprevious(va) if dg is not None else sp.append(va))
        (dg.addprevious(bidi) if dg is not None else sp.append(bidi))

    # ------------------------------------------------------------ cover
    def build_cover(self):
        doc, c, m = self.doc, self.c, self.meta
        self.setup_section(doc.sections[0], cover=True)
        title = m.get("title") or self.p.get("name") or "ملزمة"
        sub = m.get("subtitle", "")
        style = self.t["cover"]
        dark = style in ("iraqi", "ministerial", "modern", "bw", "compact")
        if m.get("institution"):
            p = doc.add_paragraph()
            self.para_fmt(p, align="center", after=18)
            r = p.add_run(m["institution"])
            self.font_run(r, size=16, bold=True, color=c["primary"], font=self.hfn)
        if style in ("iraqi", "ministerial"):
            p = doc.add_paragraph()
            self.para_fmt(p, align="center", after=6)
            r = p.add_run("◆  ❖  ◆" if style == "iraqi" else "━━━  ◆  ━━━")
            self.font_run(r, size=18, color=c["accent"], rtl=False)
        tbl = doc.add_table(rows=1, cols=1)
        self.table_setup(tbl)
        cell = tbl.cell(0, 0)
        self.cell_margins(cell, 500, 500, 300, 300)
        if dark:
            self.shade(cell, c["primary"])
            edge = ("single", 24, c["accent"])
            self.cell_borders(cell, top=edge, bottom=edge, start=("single", 4, c["accent"]), end=("single", 4, c["accent"]),
                              left=("single", 4, c["accent"]), right=("single", 4, c["accent"]))
            tcol = "FFFFFF"
        else:
            self.cell_borders(cell, top=("single", 18, c["primary"]), bottom=("single", 18, c["primary"]))
            tcol = c["primary"]
        p = cell.paragraphs[0]
        self.para_fmt(p, rtl=is_rtl(title), align="center", before=6, after=6)
        r = p.add_run(title)
        self.font_run(r, size=38 if len(title) < 30 else 28, bold=True, color=tcol, font=self.hfn, rtl=is_rtl(title))
        if sub:
            p2 = cell.add_paragraph()
            self.para_fmt(p2, align="center", before=4, after=4)
            r = p2.add_run(sub)
            self.font_run(r, size=18, color=c["accent"] if dark and style != "bw" else tcol, font=self.hfn)
        self.spacer(30)
        info = [("إعداد", m.get("teacher")), ("المرحلة / الصف", m.get("grade")), ("السنة الدراسية", m.get("year")), ("الطبعة", m.get("edition"))]
        for lab, val in info:
            if not val:
                continue
            p = doc.add_paragraph()
            self.para_fmt(p, align="center", after=6)
            r = p.add_run(lab + ": ")
            self.font_run(r, size=15, color=c["accent"], font=self.hfn)
            r = p.add_run(val)
            self.font_run(r, size=18 if lab == "إعداد" else 15, bold=True, color=c["ink"], font=self.hfn)
        sec = doc.add_section(WD_SECTION.NEW_PAGE)
        self.setup_section(sec)
        sec.header.is_linked_to_previous = False
        sec.footer.is_linked_to_previous = False
        self.build_header_footer(sec)

    def build_header_footer(self, sec):
        c, m = self.c, self.meta
        hp = sec.header.paragraphs[0]
        text = " | ".join(x for x in (m.get("title"), m.get("teacher")) if x)
        self.para_fmt(hp, align="center", after=0)
        r = hp.add_run(text)
        self.font_run(r, size=10, color=c["accent"] if self.t["id"] != "bw" else "444444", font=self.hfn)
        self.p_border(hp, bottom=("single", 8, c["accent"], 4))
        fp = sec.footer.paragraphs[0]
        self.para_fmt(fp, align="center", rtl=False)
        self.p_border(fp, top=("single", 6, c["line"], 4))
        r = fp.add_run("‹ ")
        self.font_run(r, size=11, color=c["primary"], rtl=False)
        self.field(fp, "PAGE", "2", size=11, color=c["primary"])
        r = fp.add_run(" ›")
        self.font_run(r, size=11, color=c["primary"], rtl=False)
        if m.get("footer"):
            fp2 = sec.footer.add_paragraph()
            self.para_fmt(fp2, align="center")
            r = fp2.add_run(m["footer"])
            self.font_run(r, size=9, color="666666", font=self.hfn)

    # ------------------------------------------------------------ toc
    def build_toc(self, entries):
        doc, c = self.doc, self.c
        p = doc.add_paragraph()
        self.para_fmt(p, align="center", before=0, after=14)
        r = p.add_run("فهرس المحتويات")
        self.font_run(r, size=26, bold=True, color=c["primary"], font=self.hfn)
        self.p_border(p, bottom=("single", 12, c["accent"], 6))
        width_tw = int((21 - self.t["margins"]["inner"] - self.t["margins"]["outer"]) * 567)
        first = True
        for i, (lvl, text, key) in enumerate(entries):
            par = doc.add_paragraph()
            self.para_fmt(par, rtl=True, before=2, after=2)
            pr = par._p.get_or_add_pPr()
            tabs = el("tabs")
            tabs.append(el("tab", val="left" if False else "right", leader="dot", pos=width_tw))
            pr.append(tabs)
            if lvl > 1:
                pr.append(el("ind", start=360 * (lvl - 1), left=360 * (lvl - 1)))
            if first:
                for kind in ("begin",):
                    rr = par.add_run()
                    rr._r.append(el("fldChar", fldCharType="begin"))
                rr = par.add_run()
                it = OxmlElement("w:instrText")
                it.set(qn("xml:space"), "preserve")
                it.text = ' TOC \\o "1-2" \\h \\z \\u '
                rr._r.append(it)
                rr = par.add_run()
                rr._r.append(el("fldChar", fldCharType="separate"))
                first = False
            num = ""
            if self.toc_pages is not None and i < len(self.toc_pages) and self.toc_pages[i]:
                num = str(self.toc_pages[i])
            txt = text if self.toc_pages is not None else "."
            r = par.add_run(txt)
            self.font_run(r, size=self.size - (0 if lvl == 1 else 1.5), bold=(lvl == 1), color=c["primary"] if lvl == 1 else c["ink"], rtl=is_rtl(text))
            r = par.add_run("\t" + num)
            self.font_run(r, size=self.size - 1, bold=True, color=c["primary"], rtl=False)
            if i == len(entries) - 1:
                rr = par.add_run()
                rr._r.append(el("fldChar", fldCharType="end"))
        pb = doc.add_paragraph()
        pb.add_run().add_break(__import__("docx.enum.text", fromlist=["WD_BREAK"]).WD_BREAK.PAGE)

    # ------------------------------------------------------------ blocks
    def chapter_color(self):
        rb = self.t.get("rainbow")
        if rb:
            return rb[(max(self.chap, 1) - 1) % len(rb)]
        return self.c["primary"]

    def heading(self, b):
        lvl = int(b["type"][1])
        text = plain(b["runs"]).strip()
        if lvl == 1:
            self.chap += 1
        col = self.chapter_color()
        rtl = is_rtl(text)
        par = self.doc.add_paragraph(style="Heading %d" % lvl)
        h1 = self.t["h1"]
        for r in list(par.runs):
            r._r.getparent().remove(r._r)
        if lvl == 1:
            page_break = self.t["chapterBreak"] and self.chap > 1 and not self.last_h1
            if page_break:
                par.paragraph_format.page_break_before = True
            self.para_fmt(par, rtl=rtl, align="center" if h1 in ("banner", "double", "invert", "pill") else None, before=10, after=12, keep_next=True)
            tcol, size = col, self.size + 9
            if h1 in ("banner", "pill", "invert"):
                self.shade(par, "000000" if h1 == "invert" else col)
                tcol = "FFFFFF"
                self.p_border(par, top=("single", 8, self.c["accent"], 4), bottom=("single", 8, self.c["accent"], 4)) if h1 == "banner" else None
            elif h1 == "double":
                self.p_border(par, bottom=("double", 6, col, 4), top=("double", 6, col, 4))
            elif h1 == "bar":
                self.p_border(par, right=("single", 36, self.c["accent"], 6), bottom=("single", 6, col, 2))
            elif h1 == "numbered":
                self.p_border(par, bottom=("single", 8, col, 4))
            self.add_runs(par, [dict(r, b=1) for r in b["runs"]], size=size, color=tcol, rtl=rtl)
        elif lvl == 2:
            self.para_fmt(par, rtl=rtl, before=12, after=6, keep_next=True)
            self.p_border(par, bottom=("single", 8, self.c["accent"], 2))
            self.add_runs(par, [dict(r, b=1) for r in b["runs"]], size=self.size + 4, color=col, rtl=rtl)
        else:
            self.para_fmt(par, rtl=rtl, before=8, after=4, keep_next=True)
            self.p_border(par, right=("single", 24, self.c["accent"], 6))
            self.add_runs(par, [dict(r, b=1) for r in b["runs"]], size=self.size + 1.5, color=self.c["ink"], rtl=rtl)
        for rr in par.runs:
            rpr = rr._r.get_or_add_rPr()
            f = rpr.find(qn("w:rFonts"))
            if f is not None:
                for a in ("ascii", "hAnsi", "cs"):
                    f.set(qn("w:" + a), self.hfn)
        if lvl <= 2:
            self.headings.append((lvl, text, b["id"]))

    def paragraph(self, b, align_justify=True):
        text = plain(b["runs"])
        rtl = is_rtl(text)
        par = self.doc.add_paragraph()
        self.para_fmt(par, rtl=rtl, align="justify" if (align_justify and rtl and len(text) > 90) else None, before=0, after=7, line=self.t["lh"] * 0.92)
        self.add_runs(par, b["runs"], color=self.c["ink"], rtl=rtl)
        return par

    def list_item(self, b):
        text = plain(b["runs"])
        rtl = is_rtl(text)
        par = self.doc.add_paragraph()
        lvl = b.get("list", {}).get("level", 0)
        self.para_fmt(par, rtl=rtl, before=0, after=3, line=self.t["lh"] * 0.9)
        pr = par._p.get_or_add_pPr()
        ind = 567 * (1 + lvl)
        tabs = el("tabs")
        tabs.append(el("tab", val="left", pos=ind))
        pr.append(tabs)
        if rtl:
            pr.append(el("ind", start=ind, left=ind, hanging=360))
        else:
            pr.append(el("ind", left=ind, hanging=360))
        mk = b.get("list", {}).get("marker", "•")
        r = par.add_run(mk + "\t")
        self.font_run(r, size=self.size, bold=True, color=self.c["accent"] if self.t["id"] != "bw" else "000000", rtl=rtl)
        self.add_runs(par, b["runs"], color=self.c["ink"], rtl=rtl)

    def box(self, b):
        typ = b["type"]
        label = b.get("label") or BOX_TYPES.get(typ, "")
        col = self.c["boxes"].get(typ, self.c["primary"])
        variant = b.get("variant", 0) % 3
        text = plain(b["runs"])
        rtl = is_rtl(text)
        bw = self.t["id"] == "bw"
        bst = BW_BORDER.get(typ, "single") if bw else "single"
        tint = mix(col, 0.9) if not bw else "F3F3F3"
        tbl = self.doc.add_table(rows=2 if variant == 0 else 1, cols=1)
        self.table_setup(tbl)
        if variant == 0:
            tc = tbl.cell(0, 0)
            self.shade(tc, col if not bw else "000000")
            self.cell_margins(tc, 40, 40, 160, 160)
            self.cell_borders(tc, top=("single", 8, col), start=("single", 8, col), end=("single", 8, col), left=("single", 8, col), right=("single", 8, col))
            p = tc.paragraphs[0]
            self.para_fmt(p, rtl=True, keep_next=True)
            r = p.add_run(label)
            self.font_run(r, size=self.size - 1, bold=True, color="FFFFFF", font=self.hfn)
            body = tbl.cell(1, 0)
            self.shade(body, tint)
            self.cell_margins(body, 90, 90, 180, 180)
            self.cell_borders(body, bottom=(bst, 12 if bw else 8, col), start=(bst, 8, col), end=(bst, 8, col), left=(bst, 8, col), right=(bst, 8, col))
            bp = body.paragraphs[0]
            self.para_fmt(bp, rtl=rtl, line=self.t["lh"] * 0.9)
            self.add_runs(bp, b["runs"], color=self.c["ink"], rtl=rtl)
        else:
            tc = tbl.cell(0, 0)
            self.cell_margins(tc, 100, 100, 200, 200)
            if variant == 1:
                self.shade(tc, tint)
                self.cell_borders(tc, start=(bst, 36, col), right=(bst, 36, col), top=(bst, 4, col), bottom=(bst, 4, col), end=("nil", 0, col), left=("nil", 0, col))
            else:
                self.cell_borders(tc, top=(bst, 12, col), bottom=(bst, 12, col), start=(bst, 12, col), end=(bst, 12, col), left=(bst, 12, col), right=(bst, 12, col))
            p = tc.paragraphs[0]
            self.para_fmt(p, rtl=rtl, line=self.t["lh"] * 0.9)
            r = p.add_run(label + (": " if rtl else ": "))
            self.font_run(r, size=self.size, bold=True, color=col, font=self.hfn)
            self.add_runs(p, b["runs"], color=self.c["ink"], rtl=rtl)
        self.spacer(6)

    def label_chip(self, b):
        typ = b.get("kind", "note")
        col = self.c["boxes"].get(typ, self.c["primary"])
        par = self.doc.add_paragraph()
        self.para_fmt(par, rtl=True, before=6, after=3, keep_next=True)
        self.shade(par, mix(col, 0.88))
        self.p_border(par, right=("single", 36, col, 6))
        r = par.add_run(b.get("label") or BOX_TYPES.get(typ, ""))
        self.font_run(r, size=self.size, bold=True, color=col, font=self.hfn)

    def equation(self, b):
        par = self.doc.add_paragraph()
        self.para_fmt(par, rtl=False, align="center", before=4, after=8)
        for r in b["runs"]:
            if "m" in r:
                try:
                    e = etree.fromstring(r["m"])
                    if e.tag.endswith("}oMath"):
                        wrap = OxmlElement("m:oMathPara")
                        wrap.append(e)
                        e = wrap
                    par._p.append(e)
                except Exception:
                    pass
        # a faint framed look
        self.p_border(par, top=("single", 4, self.c["line"], 4), bottom=("single", 4, self.c["line"], 4))

    def image(self, b):
        path = os.path.join(self.media_dir, os.path.basename(b["file"]))
        if not os.path.exists(path):
            return
        maxw = 21 - self.t["margins"]["inner"] - self.t["margins"]["outer"]
        w = min(b.get("w") or maxw, maxw)
        par = self.doc.add_paragraph()
        self.para_fmt(par, rtl=False, align="center", before=4, after=8)
        try:
            run = par.add_run()
            pic = run.add_picture(path, width=Cm(w))
            maxh = 29.7 - self.t["margins"]["top"] - self.t["margins"]["bottom"] - 2
            if pic.height > Cm(maxh):
                ratio = Cm(maxh) / pic.height
                pic.height = int(pic.height * ratio)
                pic.width = int(pic.width * ratio)
        except Exception:
            par._p.getparent().remove(par._p)

    def table(self, b):
        rows = b["rows"]
        occ, placed, ncols = {}, [], 1
        for ri, row in enumerate(rows):
            col = 0
            for cell in row:
                while (ri, col) in occ:
                    col += 1
                placed.append((ri, col, cell))
                for dr in range(cell.get("rs", 1)):
                    for dc in range(cell.get("cs", 1)):
                        occ[(ri + dr, col + dc)] = 1
                col += cell.get("cs", 1)
            ncols = max(ncols, col)
        nrows = len(rows)
        tbl = self.doc.add_table(rows=nrows, cols=ncols)
        self.table_setup(tbl)
        c = self.c
        col = self.chapter_color()
        edge = ("single", 6, c["line"] if self.t["id"] != "bw" else "000000")
        for ri, ci, cell in placed:
            a = tbl.cell(ri, ci)
            rs, cs = cell.get("rs", 1), cell.get("cs", 1)
            tgt = a
            if rs > 1 or cs > 1:
                try:
                    tgt = a.merge(tbl.cell(min(ri + rs - 1, nrows - 1), min(ci + cs - 1, ncols - 1)))
                except Exception:
                    tgt = a
            hdr = ri == 0
            self.cell_borders(tgt, top=edge, bottom=edge, start=edge, end=edge, left=edge, right=edge)
            self.cell_margins(tgt, 50, 50, 90, 90)
            if hdr:
                self.shade(tgt, col if self.t["id"] != "bw" else "222222")
            elif ri % 2 == 0:
                self.shade(tgt, c["tint"])
            for p in list(tgt.paragraphs)[1:]:
                p._p.getparent().remove(p._p)
            paras = cell.get("paras") or [[]]
            for pi, runs in enumerate(paras):
                par = tgt.paragraphs[0] if pi == 0 else tgt.add_paragraph()
                t = plain(runs)
                self.para_fmt(par, rtl=is_rtl(t), align="center" if hdr else None)
                self.add_runs(par, runs, size=self.size - 1.5, color="FFFFFF" if hdr else c["ink"], rtl=is_rtl(t), bold=hdr)
            for im in cell.get("imgs", []):
                pth = os.path.join(self.media_dir, os.path.basename(im["file"]))
                if os.path.exists(pth):
                    try:
                        tgt.add_paragraph().add_run().add_picture(pth, width=Cm(min(im.get("w") or 4, 5)))
                    except Exception:
                        pass
        self.spacer(8)

    # ------------------------------------------------------------ main
    def build(self, out):
        self.build_cover()
        blocks = self.p["blocks"]
        # first pass over headings to know the toc entries
        entries = []
        for b in blocks:
            if b["type"] in ("h1", "h2"):
                entries.append((int(b["type"][1]), plain(b["runs"]).strip(), b["id"]))
        if self.meta.get("toc", True) and entries:
            self.build_toc(entries)
        prev = None
        for b in blocks:
            t = b["type"]
            self.last_h1 = prev == "h1"
            prev = t
            if t in ("h1", "h2", "h3"):
                self.heading(b)

            elif t == "p":
                self.paragraph(b)
            elif t == "li":
                self.list_item(b)
            elif t in BOX_TYPES:
                self.box(b)
            elif t == "label":
                self.label_chip(b)
            elif t == "equation":
                self.equation(b)
            elif t == "image":
                self.image(b)
            elif t == "table":
                self.table(b)
        self.doc.core_properties.title = self.meta.get("title") or self.p.get("name") or ""
        self.doc.core_properties.author = self.meta.get("teacher") or ""
        self.doc.save(out)
        return self.headings


def _norm_words(s):
    s = re.sub(r"[ً-ٰٟـ]", "", s)
    return set(w for w in re.findall(r"\w+", s.lower()) if w)


def pdf_pages_text(pdf):
    try:
        out = subprocess.run(["pdftotext", "-enc", "UTF-8", pdf, "-"], capture_output=True, timeout=120).stdout.decode("utf-8", "ignore")
    except Exception:
        return []
    return out.split("\f")


def lo_to_pdf(docx_path, outdir):
    soffice = shutil.which("soffice") or shutil.which("libreoffice")
    if not soffice:
        return None
    prof = tempfile.mkdtemp(prefix="lo_")
    try:
        subprocess.run([soffice, "-env:UserInstallation=file://" + prof, "--headless", "--convert-to", "pdf", "--outdir", outdir, docx_path],
                       check=True, timeout=300, capture_output=True)
    except Exception:
        return None
    finally:
        shutil.rmtree(prof, ignore_errors=True)
    pdf = os.path.join(outdir, os.path.splitext(os.path.basename(docx_path))[0] + ".pdf")
    return pdf if os.path.exists(pdf) else None


def export_docx(proj, media_dir, out_path):
    proj = dict(proj)
    proj["_media_dir"] = media_dir
    # pass 1: layout without numbers, measure heading pages through LibreOffice
    b1 = Builder(proj, toc_pages=None)
    tmpd = tempfile.mkdtemp(prefix="mx_")
    try:
        p1 = os.path.join(tmpd, "pass1.docx")
        heads = b1.build(p1)
        pages = None
        if heads and proj.get("meta", {}).get("toc", True):
            pdf = lo_to_pdf(p1, tmpd)
            texts = pdf_pages_text(pdf) if pdf else []
            if texts:
                bags = [_norm_words(t) for t in texts]
                pages, start = [], 1
                for lvl, text, _ in heads:
                    w = _norm_words(text)
                    found = None
                    for i in range(start, len(bags)):
                        if w and len(w & bags[i]) / len(w) >= 0.75:
                            found = i
                            break
                    if found is not None:
                        start = found
                        pages.append(found + 1)
                    else:
                        pages.append(None)
        b2 = Builder(proj, toc_pages=pages if pages is not None else [])
        b2.build(out_path)
    finally:
        shutil.rmtree(tmpd, ignore_errors=True)
