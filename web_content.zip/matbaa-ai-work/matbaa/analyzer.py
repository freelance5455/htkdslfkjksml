"""Content analysis: classifies every block (heading / definition / law / example / ...).

The analyzer never rewrites or drops text. It only (a) assigns a semantic type, (b) lifts
leading labels such as "تعريف:" into a box title and (c) normalises list markers.
Optionally a Claude model can refine the labels when ANTHROPIC_API_KEY is set; the model only
returns labels, so the original wording can never be altered.
"""
import json, os, re, urllib.request
from collections import Counter

TYPES = ["h1", "h2", "h3", "p", "li", "definition", "law", "example", "note", "warning", "important",
         "question", "answer", "equation", "label"]

LABELS = [
    ("definition", r"(?:تعريف(?:ات)?|التعريف|المقصود\s+ب\w*|مفهوم|المفهوم|Definition|Def\.?)"),
    ("law", r"(?:قانون|القانون|القوانين|قاعدة|القاعدة|نظرية|النظرية|مبرهنة|المبرهنة|صيغة|الصيغة|مبدأ|المبدأ|Law|Rule|Theorem|Formula|Principle|Property|خاصية|الخاصية)"),
    ("example", r"(?:مثال|أمثلة|امثلة|الأمثلة|Example|Examples|e\.g\.)"),
    ("warning", r"(?:تنبيه|انتبه|تحذير|احذر|خطأ\s+شائع|Warning|Caution|Attention)"),
    ("note", r"(?:ملاحظة|ملاحظات|لاحظ|Note|N\.B\.?|NB)"),
    ("important", r"(?:مهم|مهمة|نقطة\s+مهمة|تذكر|تذكير|فائدة|خلاصة|الخلاصة|للحفظ|Important|Remember|Tip|Key\s+point|Summary)"),
    ("answer", r"(?:الجواب|جواب|الإجابة|الاجابة|إجابة|الحل|حل|Answer|Ans|Solution)"),
    ("question", r"(?:سؤال|السؤال|Question|Q)"),
]
_NUM = r"(?:\s*[\d٠-٩]{1,3}|\s*[أ-ي])?"
LABEL_RES = [(t, re.compile(r"^\W{0,3}(%s)(%s)\s*(?:[:：]|\s[-–—]\s|\)\s)\s*" % (p, _NUM), re.I)) for t, p in LABELS]
LABEL_ONLY = [(t, re.compile(r"^\W{0,3}(%s)(%s)\s*[:：]?\s*$" % (p, _NUM), re.I)) for t, p in LABELS]
SHORT_QA = [("question", re.compile(r"^\s*(س[\d٠-٩]*|Q[\d]*)\s*[:：\)\.\-]\s*")),
            ("answer", re.compile(r"^\s*(ج[\d٠-٩]*|A[\d]*|Ans)\s*[:：\)\.\-]\s*"))]
BULLET = re.compile(r"^[•▪●◦‣⁃·●■◆►✓✔\-–—\*]\s+")
NUMBERED = re.compile(r"^(\(?[\d٠-٩]{1,3}\s*[\.\)\-–]|\(?[أ-ي]\s*[\.\)\-–]|\(?[a-zA-Z][\.\)])\s+")
Q_WORDS = re.compile(r"^(?:ما|ماذا|لماذا|كيف|هل|أي|أيهما|متى|أين|كم|من|عرّ?ف|اذكر|علل|عدد|وضح|قارن|احسب|جد|أوجد|اشرح|بيّ?ن|ما\s+هو|ما\s+هي|what|why|how|which|when|where|define|explain|compare|calculate|find|state|list)\b", re.I)
HEAD_PAT1 = re.compile(r"^\s*(?:الفصل|الباب|الوحدة|المحاضرة|المحور|Chapter|Unit|Lecture|Module)\b", re.I)
HEAD_PAT2 = re.compile(r"^\s*(?:الموضوع|القسم|الجزء|Section|Part|Topic|مقدمة|المقدمة|الخاتمة|ملخص|أسئلة|اسئلة|تمارين|التمارين|مسائل|المسائل|مراجعة)\b", re.I)
ORD_PAT = re.compile(r"^\s*(?:أولاً|أولا|ثانياً|ثانيا|ثالثاً|ثالثا|رابعاً|رابعا|خامساً|خامسا|سادساً|سادسا|سابعاً|سابعا|ثامناً|تاسعاً|عاشراً)\b")
DEF_PAT = re.compile(r"^\S+(?:\s+\S+){0,4}?\s+(?:هو|هي|هم|هما|يعرّ?ف\s+ب\w*|تعرّ?ف\s+ب\w*|عبارة\s+عن|يُعرَّف|تُعرَّف)\s", re.U)
DEF_EN = re.compile(r"^[A-Z][\w\- ]{1,40}\s+(?:is|are|is defined as|refers to)\s", re.U)
END_PUNCT = re.compile(r"[\.،؛!\?؟]$")
ARABIC = re.compile(r"[؀-ۿ]")
LETTER = re.compile(r"[^\W\d_]", re.U)
MATHY = re.compile(r"[=≈≠≤≥∑∫√±×÷^²³]|\b(sin|cos|tan|log|ln)\b")


def plain(runs):
    return "".join(r.get("t", "") if "t" in r else " " for r in runs)


def strip_prefix(runs, n):
    """Remove the first n characters from runs (text runs only). Returns False if not possible."""
    left = n
    out = []
    for r in runs:
        if left > 0 and "t" in r:
            t = r["t"]
            if len(t) <= left:
                left -= len(t)
                continue
            r = dict(r)
            r["t"] = t[left:].lstrip()
            left = 0
        elif left > 0:
            return False
        out.append(r)
    if left > 0:
        return False
    runs[:] = out
    return True


class Stats:
    def __init__(self, blocks):
        sizes = Counter()
        for b in blocks:
            if b["type"] == "p" and b.get("size"):
                sizes[b["size"]] += len(plain(b["runs"]))
        self.base = sizes.most_common(1)[0][0] if sizes else None
        big = sorted({s for s in sizes if self.base and s >= self.base + 1.5}, reverse=True)
        self.big = big

    def level_for_size(self, s):
        if not self.base or s is None or s < self.base + 1.5:
            return None
        for i, v in enumerate(self.big):
            if s >= v - 0.01:
                return min(i + 1, 3)
        return 3


def heading_level(b, st, text):
    style = (b.get("style") or "")
    m = re.match(r"(?i)^(?:heading|عنوان)\s*(\d)", style)
    if m:
        return min(int(m.group(1)), 3)
    if style.lower() in ("title", "العنوان") or style.lower().startswith("title"):
        return 1
    if style.lower() in ("subtitle",):
        return 2
    n = len(text)
    if n == 0 or n > 100 or b.get("list"):
        return None
    if text.count(" ") > 14:
        return None
    if HEAD_PAT1.match(text):
        return 1
    ends_label = text.rstrip().endswith((":", "："))
    lvl_size = st.level_for_size(b.get("size"))
    strong = b.get("boldAll") or lvl_size
    if lvl_size and (not END_PUNCT.search(text) or ends_label):
        return lvl_size
    if HEAD_PAT2.match(text) and (strong or n < 40):
        return 2
    if ORD_PAT.match(text) and n < 70 and (strong or not END_PUNCT.search(text)):
        return 2
    if b.get("boldAll") and not END_PUNCT.search(text) and n < 70:
        return 3
    if b.get("align") == "center" and b.get("boldAll") and n < 70:
        return 2
    return None


def classify_block(b, st, ctx):
    """Mutates block b. ctx holds the previous block types."""
    if b["type"] in ("image", "table", "equation"):
        return
    runs = b["runs"]
    text = plain(runs).strip()
    if not text:
        return
    t_low = text
    lvl = heading_level(b, st, t_low)
    # explicit label first (e.g. "تعريف: ...")
    for typ, rx in LABEL_ONLY:
        if len(text) < 30 and rx.match(text) and not (lvl and lvl <= 2 and typ in ("question", "answer")):
            m = rx.match(text)
            b.update(type="label", kind=typ, label=text.rstrip(":： ").strip())
            return
    if lvl is None:
        for typ, rx in LABEL_RES:
            m = rx.match(text)
            if m:
                label = (m.group(1) + (m.group(2) or "")).strip()
                if strip_prefix(runs, m.end()) and plain(runs).strip():
                    b.update(type=typ, label=label)
                    return
        for typ, rx in SHORT_QA:
            m = rx.match(text)
            if m and strip_prefix(runs, m.end()) and plain(runs).strip():
                b.update(type=typ, label=m.group(1).rstrip(":：)-. ") if False else ("سؤال" if typ == "question" else "الجواب"))
                return
    if lvl:
        b["type"] = "h%d" % lvl
        return
    # list marker
    lst = b.get("list")
    marker = None
    if lst:
        marker = lst["marker"]
    else:
        m = BULLET.match(text)
        if m:
            marker = "•"
        else:
            m = NUMBERED.match(text)
            if m:
                marker = m.group(1).strip()
        if marker and m and strip_prefix(runs, m.end()):
            lst = {"marker": marker, "level": 0}
        else:
            marker = None
            lst = None
    body = plain(runs).strip()
    # questions
    if (body.endswith(("؟", "?")) and (Q_WORDS.match(body) or len(body) < 160)) or (lst and Q_WORDS.match(body) and "؟" in body):
        b.update(type="question", label="سؤال")
        if lst and re.match(r"^[\d٠-٩]", lst["marker"]):
            b["label"] = "س" + re.sub(r"\D", "", lst["marker"])
        return
    if lst:
        b.update(type="li", list=lst)
        return
    # implicit definition: starts with bold term followed by "هو/هي"
    first = next((r for r in runs if "t" in r and r["t"].strip()), None)
    if first and first.get("b") and (DEF_PAT.match(body) or DEF_EN.match(body)) and len(body) < 600:
        b["type"] = "definition"
        b["label"] = "تعريف"
        first["k"] = 1
        return
    # math-ish short line -> law
    letters = LETTER.findall(body)
    ar = len(ARABIC.findall(body))
    if len(body) < 90 and MATHY.search(body) and "=" in body and ar < 12 and not END_PUNCT.search(body):
        b.update(type="law", label="قانون")
        return
    if body[:1] in "⚠❗‼":
        b.update(type="warning", label="تنبيه")
        return
    if body[:1] in "★✦☆💡":
        b.update(type="important", label="مهم")
        return
    # fully bold sentences or heavily highlighted paragraphs -> important
    if len(body) < 260:
        txt = [r for r in runs if "t" in r and r["t"].strip()]
        tot = sum(len(r["t"]) for r in txt) or 1
        hl = sum(len(r["t"]) for r in txt if r.get("k") or r.get("b"))
        if b.get("boldAll") and END_PUNCT.search(body) and len(body) > 25:
            b.update(type="important", label="مهم")
            return
        if hl / tot > 0.75 and sum(1 for r in txt if r.get("k")) and len(body) > 25:
            b.update(type="important", label="مهم")
            return
    b["type"] = "p"


def _llm_labels(chunk):
    key = os.environ.get("ANTHROPIC_API_KEY")
    if not key:
        return {}
    model = os.environ.get("MATBAA_MODEL", "claude-sonnet-5-5")
    items = [{"i": i, "type": b["type"], "text": plain(b.get("runs", []))[:280]} for i, b in enumerate(chunk)
             if b["type"] not in ("image", "table", "equation")]
    prompt = (
        "أنت محلل محتوى تعليمي. صنّف كل عنصر من القائمة إلى أحد الأنواع: "
        "h1,h2,h3,p,li,definition,law,example,note,warning,important,question,answer. "
        "h1 عنوان فصل/وحدة، h2 عنوان فرعي، h3 عنوان صغير. لا تغيّر النص. "
        "أعد JSON فقط على شكل [{\"i\":0,\"type\":\"p\"}] ولا تضف أي شرح. هذه العناصر (type الحالي هو تقدير أولي):\n"
        + json.dumps(items, ensure_ascii=False))
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=json.dumps({"model": model, "max_tokens": 4000, "messages": [{"role": "user", "content": prompt}]}).encode(),
        headers={"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            data = json.load(r)
        txt = "".join(c.get("text", "") for c in data.get("content", []))
        m = re.search(r"\[.*\]", txt, re.S)
        arr = json.loads(m.group(0)) if m else []
        return {int(x["i"]): x["type"] for x in arr if x.get("type") in TYPES}
    except Exception:
        return {}


LABEL_AR = {"definition": "تعريف", "law": "قانون", "example": "مثال", "note": "ملاحظة", "warning": "تنبيه",
            "important": "مهم", "question": "سؤال", "answer": "الجواب"}


def analyze(blocks, progress=None, chunk=200, use_llm=True):
    st = Stats(blocks)
    ctx = []
    total = max(1, len(blocks))
    for s in range(0, len(blocks), chunk):
        part = blocks[s:s + chunk]
        for b in part:
            classify_block(b, st, ctx)
        if use_llm and os.environ.get("ANTHROPIC_API_KEY"):
            for i, typ in _llm_labels(part).items():
                b = part[i]
                if b["type"] in ("image", "table", "equation", "label") or typ == b["type"]:
                    continue
                if typ in LABEL_AR and not b.get("label"):
                    b["label"] = LABEL_AR[typ]
                b["type"] = typ
                b["ai"] = 1
        if progress:
            progress(min(1.0, (s + chunk) / total))
    # normalise heading levels: first heading becomes at most level considered h1 if doc has none
    hs = [b for b in blocks if b["type"] in ("h1", "h2", "h3")]
    if hs and not any(b["type"] == "h1" for b in hs):
        top = min(int(b["type"][1]) for b in hs)
        for b in hs:
            b["type"] = "h%d" % (int(b["type"][1]) - top + 1)
    # drop transient fields
    for b in blocks:
        for k in ("style", "align", "size", "boldAll"):
            b.pop(k, None)
    return blocks


def guess_meta(blocks):
    for b in blocks:
        if b["type"] in ("h1", "h2"):
            return {"title": plain(b["runs"]).strip()}
    return {}
