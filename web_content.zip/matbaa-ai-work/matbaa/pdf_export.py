"""PDF / cover-image export using headless Chromium (same renderer as the live preview)."""
from urllib.parse import urlencode


def _open(p, base, uid, pid, ik):
    browser = p.chromium.launch(args=["--no-sandbox", "--disable-dev-shm-usage"])
    ctx = browser.new_context(viewport={"width": 900, "height": 1200}, device_scale_factor=2)
    page = ctx.new_page()
    page.goto("%s/render.html?%s" % (base, urlencode({"pid": pid, "uid": uid, "ik": ik})), wait_until="load")
    page.wait_for_function("window.__ready === true", timeout=180000)
    return browser, page


def render_pdf(base, uid, pid, ik, out):
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        browser, page = _open(p, base, uid, pid, ik)
        try:
            page.emulate_media(media="print")
            page.pdf(path=out, width="210mm", height="297mm", print_background=True, prefer_css_page_size=True,
                     margin={"top": "0", "bottom": "0", "left": "0", "right": "0"})
        finally:
            browser.close()


def render_cover(base, uid, pid, ik, out):
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        browser, page = _open(p, base, uid, pid, ik)
        try:
            page.locator(".page.cover").first.screenshot(path=out)
        finally:
            browser.close()
