"""Staged processing job: parse -> analyse -> ready (runs in a background thread)."""
import json, os, time, traceback
from . import store
from .parser import parse_file, convert_doc_to_docx, ParseError
from .analyzer import analyze, guess_meta, plain

DEFAULT_META = {"title": "", "subtitle": "", "teacher": "", "institution": "", "grade": "", "year": "", "edition": "", "footer": "", "toc": True}


def _set(uid, pid, stage, progress, message, error=None):
    s = {"stage": stage, "progress": round(progress, 3), "message": message}
    if error:
        s["error"] = error
    store.STATUS[pid] = s


def create_project(uid, upload_ids, theme, meta, name):
    pid = store.new_id()
    pdir = store.project_dir(uid, pid)
    os.makedirs(os.path.join(pdir, "media"), exist_ok=True)
    m = dict(DEFAULT_META)
    m.update({k: v for k, v in (meta or {}).items() if k in DEFAULT_META})
    proj = {"id": pid, "name": name, "created": int(time.time()), "theme": theme, "overrides": {}, "meta": m,
            "blocks": [], "stats": {}, "status": {"stage": "queued", "progress": 0, "message": "في الانتظار"}}
    store.save_project(uid, proj)
    _set(uid, pid, "queued", 0, "في الانتظار")
    return pid


def run(uid, pid, upload_ids):
    try:
        proj = store.load_project(uid, pid)
        pdir = store.project_dir(uid, pid)
        media = os.path.join(pdir, "media")
        blocks, stats, nid = [], {"images": 0, "tables": 0, "equations": 0}, 1
        n = len(upload_ids)
        files = []
        for k, upid in enumerate(upload_ids):
            ud = store.upload_dir(uid, upid)
            with open(os.path.join(ud, "meta.json"), encoding="utf-8") as f:
                info = json.load(f)
            path = os.path.join(ud, info["stored"])
            files.append(info["name"])
            base = k / n
            span = 0.5 / n
            _set(uid, pid, "parsing", base * 0.5, "قراءة الملف: %s" % info["name"])
            if path.lower().endswith(".doc"):
                path = convert_doc_to_docx(path, ud)
            part, st, nid = parse_file(path, media, lambda f: _set(uid, pid, "parsing", (base + f / n) * 0.5, "قراءة الملف: %s" % info["name"]), nid)
            for key in stats:
                stats[key] += st[key]
            if n > 1 and part and part[0]["type"] != "h1":
                part.insert(0, {"id": "bf%d" % k, "type": "p", "runs": [{"t": os.path.splitext(info["name"])[0]}],
                                "style": "Heading 1", "size": None, "boldAll": False})
            blocks.extend(part)
        if not blocks:
            raise ParseError("لم يُعثر على أي محتوى نصي في الملف")
        _set(uid, pid, "analyzing", 0.5, "تحليل المحتوى وتصنيف العناصر")
        analyze(blocks, lambda f: _set(uid, pid, "analyzing", 0.5 + f * 0.45, "تحليل المحتوى وتصنيف العناصر"))
        g = guess_meta(blocks)
        if not proj["meta"].get("title") and g.get("title"):
            proj["meta"]["title"] = g["title"]
        proj["blocks"] = blocks
        proj["files"] = files
        stats["blocks"] = len(blocks)
        stats["words"] = sum(len(plain(b.get("runs", [])).split()) for b in blocks)
        proj["stats"] = stats
        proj["status"] = {"stage": "done", "progress": 1, "message": "اكتمل التصميم"}
        store.save_project(uid, proj)
        _set(uid, pid, "done", 1, "اكتمل التصميم")
    except ParseError as e:
        _fail(uid, pid, str(e))
    except Exception as e:  # pragma: no cover
        traceback.print_exc()
        _fail(uid, pid, "حدث خطأ أثناء المعالجة: %s" % e)


def _fail(uid, pid, msg):
    _set(uid, pid, "error", 1, msg, error=msg)
    try:
        proj = store.load_project(uid, pid)
        proj["status"] = store.STATUS[pid]
        store.save_project(uid, proj)
    except Exception:
        pass
