"""File-based project storage, scoped per anonymous browser token (privacy by design)."""
import hashlib, json, os, re, shutil, threading, time, uuid

DATA = os.environ.get("MATBAA_DATA", os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data"))
_lock = threading.Lock()
STATUS = {}  # in-memory job status: pid -> dict


def uid_dir(uid):
    h = hashlib.sha256(("matbaa:" + uid).encode()).hexdigest()[:32]
    p = os.path.join(DATA, h)
    os.makedirs(p, exist_ok=True)
    return p


def new_id():
    return uuid.uuid4().hex[:16]


def safe_id(x):
    return bool(re.fullmatch(r"[0-9a-f]{16}", x or ""))


def upload_dir(uid, upid):
    if not safe_id(upid):
        raise KeyError("bad id")
    return os.path.join(uid_dir(uid), "uploads", upid)


def project_dir(uid, pid):
    if not safe_id(pid):
        raise KeyError("bad id")
    return os.path.join(uid_dir(uid), "projects", pid)


def save_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp%s" % uuid.uuid4().hex[:6]
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False)
    os.replace(tmp, path)


def load_project(uid, pid):
    p = os.path.join(project_dir(uid, pid), "project.json")
    if not os.path.exists(p):
        raise KeyError(pid)
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def save_project(uid, proj):
    proj["updated"] = int(time.time())
    save_json(os.path.join(project_dir(uid, proj["id"]), "project.json"), proj)


def list_projects(uid):
    root = os.path.join(uid_dir(uid), "projects")
    out = []
    if os.path.isdir(root):
        for pid in os.listdir(root):
            try:
                pr = load_project(uid, pid)
            except Exception:
                continue
            st = STATUS.get(pid) or pr.get("status") or {}
            pages = pr.get("stats", {}).get("blocks", 0)
            out.append({"id": pid, "name": pr.get("name"), "theme": pr.get("theme"), "updated": pr.get("updated", 0),
                        "created": pr.get("created", 0), "status": st, "blocks": pages,
                        "title": pr.get("meta", {}).get("title", "")})
    out.sort(key=lambda x: -x["updated"])
    return out


def delete_project(uid, pid):
    shutil.rmtree(project_dir(uid, pid), ignore_errors=True)
    STATUS.pop(pid, None)


def purge_old(days):
    cutoff = time.time() - days * 86400
    if not os.path.isdir(DATA):
        return
    for h in os.listdir(DATA):
        for sub in ("uploads", "projects"):
            d = os.path.join(DATA, h, sub)
            if os.path.isdir(d):
                for x in os.listdir(d):
                    p = os.path.join(d, x)
                    if os.path.getmtime(p) < cutoff:
                        shutil.rmtree(p, ignore_errors=True)
