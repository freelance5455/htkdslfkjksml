"""Theme definitions shared by the web renderer and the DOCX exporter."""

BOX_TYPES = {
    "definition": "تعريف", "law": "قانون", "example": "مثال", "note": "ملاحظة",
    "warning": "تنبيه", "important": "مهم", "question": "سؤال", "answer": "الجواب",
}

FONTS = {
    "amiri": {"name": "أميري", "css": "'Amiri','Noto Naskh Arabic','FreeSerif',serif", "docx": "Traditional Arabic"},
    "cairo": {"name": "القاهرة", "css": "'Cairo','Tajawal','DejaVu Sans',sans-serif", "docx": "Segoe UI"},
    "tajawal": {"name": "تجوّل", "css": "'Tajawal','Cairo','DejaVu Sans',sans-serif", "docx": "Tahoma"},
    "naskh": {"name": "نسخ", "css": "'Noto Naskh Arabic','Amiri','FreeSerif',serif", "docx": "Simplified Arabic"},
    "kufi": {"name": "رقعة كوفي", "css": "'Reem Kufi','Cairo','DejaVu Sans',sans-serif", "docx": "Arial"},
    "plex": {"name": "بلكس", "css": "'IBM Plex Sans Arabic','Cairo','DejaVu Sans',sans-serif", "docx": "Arial"},
}


def _boxes(d, w, e, n, wa, i, q, a):
    return {"definition": d, "law": w, "example": e, "note": n, "warning": wa, "important": i, "question": q, "answer": a}


THEMES = {
    "iraqi": {
        "id": "iraqi", "name": "الملزمة العراقية الفخمة", "desc": "عنابي وذهبي بزخارف إسلامية وإطار مزدوج",
        "swatch": ["#6b1426", "#c9a24a", "#fffaf0"],
        "font": "amiri", "headFont": "kufi", "size": 14, "lh": 1.85,
        "margins": {"top": 2.3, "bottom": 2.1, "inner": 2.2, "outer": 1.8},
        "colors": {"primary": "#6b1426", "accent": "#c9a24a", "ink": "#1f1a17", "paper": "#fffdf7", "tint": "#fbf3dc",
                   "bold": "#6b1426", "kw": "#8a1c2f", "kwbg": "#fbeccb", "line": "#d9c28a",
                   "boxes": _boxes("#7a1a2c", "#0f3d5e", "#1f6b4a", "#a86a12", "#b42318", "#7a1a2c", "#0f3d5e", "#1f6b4a")},
        "cover": "iraqi", "frame": "ornate", "h1": "banner", "chapterBreak": True, "rainbow": None, "radius": 6,
    },
    "ministerial": {
        "id": "ministerial", "name": "الملزمة الوزارية", "desc": "رسمية بخطوط مزدوجة وألوان كحلية هادئة",
        "swatch": ["#0b2e59", "#1d6fb8", "#ffffff"],
        "font": "naskh", "headFont": "cairo", "size": 14, "lh": 1.8,
        "margins": {"top": 2.4, "bottom": 2.0, "inner": 2.2, "outer": 1.8},
        "colors": {"primary": "#0b2e59", "accent": "#1d6fb8", "ink": "#101418", "paper": "#ffffff", "tint": "#eef4fb",
                   "bold": "#0b2e59", "kw": "#0b2e59", "kwbg": "#e1ecf8", "line": "#9db7d5",
                   "boxes": _boxes("#0b2e59", "#7a1f1f", "#14683f", "#8a5a00", "#b42318", "#0b2e59", "#1d6fb8", "#14683f")},
        "cover": "ministerial", "frame": "double", "h1": "double", "chapterBreak": True, "rainbow": None, "radius": 2,
    },
    "university": {
        "id": "university", "name": "الملزمة الجامعية", "desc": "أكاديمية رصينة بخط مرقّم وهوامش واسعة",
        "swatch": ["#1f2d3d", "#8a6d3b", "#f7f5f0"],
        "font": "amiri", "headFont": "amiri", "size": 13, "lh": 1.8,
        "margins": {"top": 2.5, "bottom": 2.3, "inner": 2.8, "outer": 2.0},
        "colors": {"primary": "#1f2d3d", "accent": "#8a6d3b", "ink": "#1a1a1a", "paper": "#fffefc", "tint": "#f4f1ea",
                   "bold": "#1f2d3d", "kw": "#6b4f1d", "kwbg": "#f1e8d3", "line": "#c9c2b2",
                   "boxes": _boxes("#1f2d3d", "#5b2a6e", "#2f6b4f", "#8a6d3b", "#9a2a2a", "#1f2d3d", "#34495e", "#2f6b4f")},
        "cover": "university", "frame": "simple", "h1": "numbered", "chapterBreak": True, "rainbow": None, "radius": 0,
    },
    "compact": {
        "id": "compact", "name": "الملزمة المختصرة والمركزة", "desc": "كثافة عالية وهوامش ضيقة لتوفير الورق",
        "swatch": ["#0f766e", "#f59e0b", "#ffffff"],
        "font": "tajawal", "headFont": "tajawal", "size": 11.5, "lh": 1.6,
        "margins": {"top": 1.8, "bottom": 1.6, "inner": 1.6, "outer": 1.4},
        "colors": {"primary": "#0f766e", "accent": "#f59e0b", "ink": "#16201f", "paper": "#ffffff", "tint": "#ecf8f6",
                   "bold": "#0f766e", "kw": "#b45309", "kwbg": "#fef3c7", "line": "#a7d7d2",
                   "boxes": _boxes("#0f766e", "#7c3aed", "#2563eb", "#b45309", "#dc2626", "#0f766e", "#0369a1", "#15803d")},
        "cover": "compact", "frame": "none", "h1": "bar", "chapterBreak": False, "rainbow": None, "radius": 4,
    },
    "modern": {
        "id": "modern", "name": "الملزمة الملونة الحديثة", "desc": "ألوان زاهية لكل فصل وزوايا مدورة",
        "swatch": ["#6d28d9", "#0ea5e9", "#f97316"],
        "font": "cairo", "headFont": "cairo", "size": 12.5, "lh": 1.8,
        "margins": {"top": 2.2, "bottom": 2.0, "inner": 2.0, "outer": 1.8},
        "colors": {"primary": "#6d28d9", "accent": "#f97316", "ink": "#1b1b2f", "paper": "#ffffff", "tint": "#f5f3ff",
                   "bold": "#6d28d9", "kw": "#c2410c", "kwbg": "#ffedd5", "line": "#ddd6fe",
                   "boxes": _boxes("#6d28d9", "#0ea5e9", "#10b981", "#f59e0b", "#e11d48", "#f97316", "#0284c7", "#059669")},
        "cover": "modern", "frame": "round", "h1": "pill", "chapterBreak": True,
        "rainbow": ["#6d28d9", "#0ea5e9", "#f97316", "#10b981", "#e11d48", "#ca8a04"], "radius": 14,
    },
    "bw": {
        "id": "bw", "name": "الأبيض والأسود الاحترافي", "desc": "مثالية للطباعة الاقتصادية بتمييز عبر الإطارات",
        "swatch": ["#000000", "#6b6b6b", "#ffffff"],
        "font": "naskh", "headFont": "kufi", "size": 13.5, "lh": 1.8,
        "margins": {"top": 2.3, "bottom": 2.0, "inner": 2.2, "outer": 1.8},
        "colors": {"primary": "#000000", "accent": "#555555", "ink": "#000000", "paper": "#ffffff", "tint": "#f1f1f1",
                   "bold": "#000000", "kw": "#000000", "kwbg": "#e6e6e6", "line": "#999999",
                   "boxes": _boxes("#000000", "#000000", "#333333", "#444444", "#000000", "#000000", "#222222", "#333333")},
        "cover": "bw", "frame": "mono", "h1": "invert", "chapterBreak": True, "rainbow": None, "radius": 0,
    },
}


def public_themes():
    return {"themes": THEMES, "fonts": {k: {"name": v["name"], "css": v["css"]} for k, v in FONTS.items()},
            "boxTypes": BOX_TYPES}


def resolve(theme_id, overrides=None):
    """Theme with per-project overrides applied (used by the DOCX exporter)."""
    import copy
    t = copy.deepcopy(THEMES.get(theme_id) or THEMES["iraqi"])
    o = overrides or {}
    for k in ("primary", "accent"):
        if o.get(k):
            t["colors"][k] = o[k]
            if k == "primary":
                t["colors"]["bold"] = o[k]
    if o.get("font") in FONTS:
        t["font"] = o["font"]
    if o.get("headFont") in FONTS:
        t["headFont"] = o["headFont"]
    if o.get("size"):
        t["size"] = float(o["size"])
    return t
