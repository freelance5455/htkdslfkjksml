"""DOCX -> structured block model (text, runs, tables, images, equations)."""
import os, re, subprocess, shutil, tempfile, zipfile
from lxml import etree
from docx import Document
from docx.oxml.ns import qn
from docx.text.paragraph import Paragraph
from .omml import omml_to_mathml, M

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
A = "http://schemas.openxmlformats.org/drawingml/2006/main"
R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
WP = "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
MAX_UNZIPPED = 600 * 1024 * 1024


class ParseError(Exception):
    pass


def validate_docx(path):
    try:
        with zipfile.ZipFile(path) as z:
            names = z.namelist()
            if "word/document.xml" not in names:
                raise ParseError("الملف ليس مستند Word صالحاً")
            if sum(i.file_size for i in z.infolist()) > MAX_UNZIPPED:
                raise ParseError("حجم الملف بعد فك الضغط كبير جداً")
    except zipfile.BadZipFile:
        raise ParseError("الملف تالف أو ليس بصيغة DOCX")


def convert_doc_to_docx(src, outdir):
    soffice = shutil.which("soffice") or shutil.which("libreoffice")
    if not soffice:
        raise ParseError("تحويل ملفات DOC غير متاح على هذا الخادم (LibreOffice غير مثبت)")
    prof = tempfile.mkdtemp(prefix="lo_")
    try:
        subprocess.run([soffice, "-env:UserInstallation=file://" + prof, "--headless", "--convert-to", "docx",
                        "--outdir", outdir, src], check=True, timeout=180, capture_output=True)
    except Exception:
        raise ParseError("تعذّر تحويل ملف DOC إلى DOCX")
    finally:
        shutil.rmtree(prof, ignore_errors=True)
    out = os.path.join(outdir, os.path.splitext(os.path.basename(src))[0] + ".docx")
    if not os.path.exists(out):
        raise ParseError("تعذّر تحويل ملف DOC إلى DOCX")
    return out


def inspect_docx(path):
    """Quick stats for the upload card: pages, words."""
    validate_docx(path)
    pages = None
    try:
        with zipfile.ZipFile(path) as z:
            if "docProps/app.xml" in z.namelist():
                m = re.search(rb"<Pages>(\d+)</Pages>", z.read("docProps/app.xml"))
                if m:
                    pages = int(m.group(1))
    except Exception:
        pass
    doc = Document(path)
    words = sum(len(p.text.split()) for p in doc.paragraphs)
    for t in doc.tables:
        for row in t.rows:
            for c in row.cells:
                words += len(c.text.split())
    est = False
    if not pages:
        pages = max(1, round(words / 400))
        est = True
    return {"pages": pages, "pagesEstimated": est, "words": words}


# ---------------------------------------------------------------- numbering
class Numbering:
    def __init__(self, doc):
        self.fmt = {}
        self.counters = {}
        try:
            part = doc.part.numbering_part
            root = part.element
        except Exception:
            return
        absf = {}
        for an in root.findall(qn("w:abstractNum")):
            aid = an.get(qn("w:abstractNumId"))
            for lvl in an.findall(qn("w:lvl")):
                f = lvl.find(qn("w:numFmt"))
                s = lvl.find(qn("w:start"))
                absf[(aid, lvl.get(qn("w:ilvl")))] = (f.get(qn("w:val")) if f is not None else "decimal",
                                                       int(s.get(qn("w:val"))) if s is not None else 1)
        for num in root.findall(qn("w:num")):
            nid = num.get(qn("w:numId"))
            a = num.find(qn("w:abstractNumId"))
            if a is None:
                continue
            for (aid, il), v in absf.items():
                if aid == a.get(qn("w:val")):
                    self.fmt[(nid, il)] = v

    def marker(self, numid, ilvl):
        fmt, start = self.fmt.get((numid, str(ilvl)), ("decimal", 1))
        if fmt == "bullet" or fmt == "none":
            return "•"
        key = (numid, ilvl)
        self.counters[key] = self.counters.get(key, start - 1) + 1
        for k in list(self.counters):
            if k[0] == numid and k[1] > ilvl:
                del self.counters[k]
        n = self.counters[key]
        if fmt in ("lowerLetter", "upperLetter"):
            s = chr(ord("a") + (n - 1) % 26)
            return (s.upper() if fmt == "upperLetter" else s) + ")"
        if fmt in ("arabicAbjad", "arabicAlpha"):
            ab = "أبجدهوزحطيكلمنسعفصقرشتثخذضظغ"
            return ab[(n - 1) % len(ab)] + "-"
        return "%d." % n


# ---------------------------------------------------------------- helpers
def _on(rpr, tag):
    if rpr is None:
        return False
    e = rpr.find(qn("w:" + tag))
    if e is None:
        return False
    v = e.get(qn("w:val"))
    return v not in ("0", "false", "off", "none")


def run_format(r):
    rpr = r.find(qn("w:rPr"))
    f = {}
    if _on(rpr, "b") or _on(rpr, "bCs"):
        f["b"] = 1
    if _on(rpr, "i") or _on(rpr, "iCs"):
        f["i"] = 1
    if rpr is not None:
        u = rpr.find(qn("w:u"))
        if u is not None and u.get(qn("w:val")) not in ("none", "0"):
            f["u"] = 1
        c = rpr.find(qn("w:color"))
        if c is not None and c.get(qn("w:val")) not in (None, "auto", "000000", "FFFFFF", "ffffff"):
            f["k"] = 1
            f["oc"] = "#" + c.get(qn("w:val"))
        if rpr.find(qn("w:highlight")) is not None and rpr.find(qn("w:highlight")).get(qn("w:val")) != "none":
            f["k"] = 1
        shd = rpr.find(qn("w:shd"))
        if shd is not None and shd.get(qn("w:fill")) not in (None, "auto", "FFFFFF"):
            f["k"] = 1
        va = rpr.find(qn("w:vertAlign"))
        if va is not None and va.get(qn("w:val")) in ("superscript", "subscript"):
            f["v"] = "sup" if va.get(qn("w:val")) == "superscript" else "sub"
        if _on(rpr, "strike"):
            f["s"] = 1
        sz = rpr.find(qn("w:sz"))
        if sz is not None:
            try:
                f["sz"] = int(sz.get(qn("w:val"))) / 2
            except Exception:
                pass
    return f


def run_text(r):
    out = []
    for c in r:
        t = c.tag
        if t == qn("w:t"):
            out.append(c.text or "")
        elif t == qn("w:tab"):
            out.append(" ")
        elif t in (qn("w:br"), qn("w:cr")):
            if c.get(qn("w:type")) not in ("page", "column"):
                out.append("\n")
        elif t == qn("w:noBreakHyphen"):
            out.append("-")
        elif t == qn("w:sym"):
            ch = c.get(qn("w:char"))
            try:
                out.append(chr(int(ch, 16) - 0xF000 if int(ch, 16) >= 0xF000 else int(ch, 16)))
            except Exception:
                pass
    return "".join(out)


def iter_inline(el):
    for c in el:
        t = c.tag
        if t == qn("w:r"):
            yield "r", c
        elif t in (qn("w:hyperlink"), qn("w:ins"), qn("w:smartTag"), qn("w:fldSimple"), qn("w:sdt"), qn("w:sdtContent")):
            yield from iter_inline(c)
        elif t == "{%s}oMath" % M:
            yield "m", c
        elif t == "{%s}oMathPara" % M:
            yield "mp", c


def merge_runs(runs):
    out = []
    for r in runs:
        if "t" in r and out and "t" in out[-1] and {k: v for k, v in out[-1].items() if k != "t"} == {k: v for k, v in r.items() if k != "t"}:
            out[-1]["t"] += r["t"]
        else:
            out.append(r)
    return out


def runs_plain(runs):
    return "".join(r.get("t", "") if "t" in r else " " for r in runs)


class Parser:
    def __init__(self, path, media_dir, id_start=1):
        validate_docx(path)
        self.doc = Document(path)
        self.media_dir = media_dir
        os.makedirs(media_dir, exist_ok=True)
        self.num = Numbering(self.doc)
        self.n = id_start
        self.img_n = 0
        self.img_cache = {}
        self.stats = {"images": 0, "tables": 0, "equations": 0}

    def nid(self):
        self.n += 1
        return "b%d" % self.n

    # ---- images
    def save_image(self, rid):
        if rid in self.img_cache:
            return self.img_cache[rid]
        try:
            part = self.doc.part.related_parts[rid]
        except KeyError:
            return None
        ext = os.path.splitext(str(part.partname))[1].lower() or ".png"
        self.img_n += 1
        while os.path.exists(os.path.join(self.media_dir, "img%d%s" % (self.img_n, ext))) or \
                os.path.exists(os.path.join(self.media_dir, "img%d.png" % self.img_n)):
            self.img_n += 1
        name = "img%d%s" % (self.img_n, ext)
        p = os.path.join(self.media_dir, name)
        with open(p, "wb") as f:
            f.write(part.blob)
        if ext in (".emf", ".wmf", ".wdp", ".tif", ".tiff"):
            conv = self._convert_img(p)
            if conv:
                name = os.path.basename(conv)
        self.img_cache[rid] = name
        self.stats["images"] += 1
        return name

    def _convert_img(self, p):
        soffice = shutil.which("soffice")
        if not soffice:
            return None
        prof = tempfile.mkdtemp(prefix="lo_")
        try:
            subprocess.run([soffice, "-env:UserInstallation=file://" + prof, "--headless", "--convert-to", "png",
                            "--outdir", os.path.dirname(p), p], timeout=90, capture_output=True)
        except Exception:
            return None
        finally:
            shutil.rmtree(prof, ignore_errors=True)
        out = os.path.splitext(p)[0] + ".png"
        return out if os.path.exists(out) else None

    def drawings(self, r):
        """Images inside a w:r -> list of dicts."""
        res = []
        for blip in r.iter("{%s}blip" % A):
            rid = blip.get("{%s}embed" % R)
            if not rid:
                continue
            name = self.save_image(rid)
            if not name:
                continue
            w = h = None
            ext = None
            for e in r.iter("{%s}extent" % WP):
                ext = e
                break
            if ext is not None:
                try:
                    w, h = int(ext.get("cx")) / 360000.0, int(ext.get("cy")) / 360000.0
                except Exception:
                    pass
            res.append({"type": "image", "file": name, "w": w, "h": h})
        return res

    # ---- paragraph
    def para(self, p_el, imgs_out=None):
        runs, images = [], []
        for kind, el in iter_inline(p_el):
            if kind == "r":
                t = run_text(el)
                images.extend(self.drawings(el))
                if t:
                    f = run_format(el)
                    f["t"] = t
                    runs.append(f)
            else:
                ml = omml_to_mathml(el, display=(kind == "mp"))
                if ml:
                    self.stats["equations"] += 1
                    runs.append({"m": etree.tostring(el).decode(), "mm": ml, "disp": 1 if kind == "mp" else 0})
        runs = merge_runs(runs)
        # trim
        while runs and "t" in runs[0] and not runs[0]["t"].strip():
            runs.pop(0)
        while runs and "t" in runs[-1] and not runs[-1]["t"].strip():
            runs.pop()
        if runs and "t" in runs[0]:
            runs[0]["t"] = runs[0]["t"].lstrip()
        if runs and "t" in runs[-1]:
            runs[-1]["t"] = runs[-1]["t"].rstrip()
        for r in runs:
            if "t" in r:
                r["t"] = re.sub(r"[  ]{2,}", " ", r["t"])
        return runs, images

    def block_from_paragraph(self, p_el):
        par = Paragraph(p_el, self.doc._body)
        runs, images = self.para(p_el)
        out = []
        if runs:
            ppr = p_el.find(qn("w:pPr"))
            style = ""
            try:
                style = par.style.name or ""
            except Exception:
                pass
            align = None
            if ppr is not None and ppr.find(qn("w:jc")) is not None:
                align = ppr.find(qn("w:jc")).get(qn("w:val"))
            lst = None
            if ppr is not None and ppr.find(qn("w:numPr")) is not None:
                npr = ppr.find(qn("w:numPr"))
                nid = npr.find(qn("w:numId"))
                il = npr.find(qn("w:ilvl"))
                if nid is not None and nid.get(qn("w:val")) != "0":
                    lv = int(il.get(qn("w:val"))) if il is not None else 0
                    lst = {"marker": self.num.marker(nid.get(qn("w:val")), lv), "level": lv}
            sizes = [r["sz"] for r in runs if "sz" in r]
            size = max(sizes) if sizes else None
            if size is None:
                try:
                    size = par.style.font.size.pt if par.style.font.size else None
                except Exception:
                    size = None
            txt_runs = [r for r in runs if "t" in r and r["t"].strip()]
            bold_all = bool(txt_runs) and all(r.get("b") for r in txt_runs)
            b = {"id": self.nid(), "type": "p", "runs": runs, "style": style, "align": align,
                 "size": size, "boldAll": bold_all}
            if lst:
                b["list"] = lst
            out.append(b)
        for im in images:
            im["id"] = self.nid()
            out.append(im)
        return out

    # ---- table
    def table(self, tbl_el):
        rows = []
        colspans = []  # per row list of (col_start, cell)
        occupied = {}  # col -> cell with rowspan
        for tr in tbl_el.findall(qn("w:tr")):
            row = []
            col = 0
            for tc in tr.findall(qn("w:tc")):
                tcpr = tc.find(qn("w:tcPr"))
                gs, vm = 1, None
                if tcpr is not None:
                    g = tcpr.find(qn("w:gridSpan"))
                    if g is not None:
                        gs = int(g.get(qn("w:val")))
                    v = tcpr.find(qn("w:vMerge"))
                    if v is not None:
                        vm = v.get(qn("w:val")) or "continue"
                if vm == "continue" and col in occupied:
                    occupied[col]["rs"] += 1
                    col += gs
                    continue
                paras = []
                imgs = []
                for child in tc:
                    if child.tag == qn("w:p"):
                        runs, im = self.para(child)
                        if runs:
                            paras.append(runs)
                        imgs.extend(im)
                    elif child.tag == qn("w:tbl"):
                        for ntr in child.findall(qn("w:tr")):
                            cells = []
                            for ntc in ntr.findall(qn("w:tc")):
                                cells.append(" ".join(runs_plain(self.para(pp)[0]) for pp in ntc.findall(qn("w:p"))).strip())
                            if any(cells):
                                paras.append([{"t": " | ".join(cells)}])
                cell = {"paras": paras, "cs": gs, "rs": 1}
                if imgs:
                    cell["imgs"] = [{"file": i["file"], "w": i["w"], "h": i["h"]} for i in imgs]
                if vm == "restart":
                    occupied[col] = cell
                else:
                    for k in range(col, col + gs):
                        occupied.pop(k, None)
                row.append(cell)
                col += gs
            rows.append(row)
        rows = [r for r in rows if r]
        if not rows:
            return None
        self.stats["tables"] += 1
        return {"id": self.nid(), "type": "table", "rows": rows}

    def walk(self, container, blocks):
        for el in container:
            if el.tag == qn("w:p"):
                for b in self.block_from_paragraph(el):
                    blocks.append(b)
            elif el.tag == qn("w:tbl"):
                t = self.table(el)
                if t:
                    blocks.append(t)
            elif el.tag == qn("w:sdt"):
                c = el.find(qn("w:sdtContent"))
                if c is not None:
                    self.walk(c, blocks)

    def parse(self, progress=None):
        blocks = []
        body = self.doc.element.body
        total = max(1, len(body))
        for i, el in enumerate(list(body)):
            self.walk([el], blocks)
            if progress and i % 50 == 0:
                progress(i / total)
        for b in blocks:
            if b["type"] == "p" and len(b["runs"]) == 1 and "m" in b["runs"][0]:
                b["type"] = "equation"
            elif b["type"] == "p" and all(("m" in r) or not r.get("t", "").strip() for r in b["runs"]):
                b["type"] = "equation"
        return blocks, self.stats


def parse_file(path, media_dir, progress=None, id_start=1):
    p = Parser(path, media_dir, id_start)
    blocks, stats = p.parse(progress)
    return blocks, stats, p.n
