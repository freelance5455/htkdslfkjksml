"""Minimal OMML (Word equations) -> MathML converter for browser preview."""
import re
from xml.sax.saxutils import escape

M = "http://schemas.openxmlformats.org/officeDocument/2006/math"


def _q(n):
    return "{%s}%s" % (M, n)


def _val(el, tag, default=None):
    if el is None:
        return default
    p = el.find(_q(tag))
    if p is None:
        return default
    return p.get(_q("val"), default)


def _children(el):
    return [c for c in el if c.tag != _q("e") or True]


def _sub(el, tag):
    c = el.find(_q(tag))
    return _row(c) if c is not None else ""


def _row(el):
    if el is None:
        return "<mrow/>"
    return "<mrow>" + "".join(_node(c) for c in el) + "</mrow>"


def _text(t, plain=False):
    if plain:
        return "<mtext>%s</mtext>" % escape(t)
    out = []
    for tok in re.findall(r"\d+(?:\.\d+)?|[^\W\d_]+|\s+|.", t, re.U):
        if tok.isspace():
            continue
        if re.match(r"\d", tok):
            out.append("<mn>%s</mn>" % tok)
        elif re.match(r"[^\W\d_]", tok, re.U):
            out.append("<mi>%s</mi>" % escape(tok))
        else:
            out.append("<mo>%s</mo>" % escape(tok))
    return "".join(out)


def _node(el):
    tag = el.tag.split("}")[-1] if isinstance(el.tag, str) else ""
    if tag == "r":
        t = "".join(x.text or "" for x in el.findall(_q("t")))
        rpr = el.find(_q("rPr"))
        plain = rpr is not None and (_val(rpr, "nor") is not None or rpr.find(_q("nor")) is not None)
        return _text(t, plain)
    if tag == "f":
        return "<mfrac>%s%s</mfrac>" % (_sub(el, "num"), _sub(el, "den"))
    if tag == "sSup":
        return "<msup>%s%s</msup>" % (_sub(el, "e"), _sub(el, "sup"))
    if tag == "sSub":
        return "<msub>%s%s</msub>" % (_sub(el, "e"), _sub(el, "sub"))
    if tag == "sSubSup":
        return "<msubsup>%s%s%s</msubsup>" % (_sub(el, "e"), _sub(el, "sub"), _sub(el, "sup"))
    if tag == "sPre":
        return "<mmultiscripts>%s<mprescripts/>%s%s</mmultiscripts>" % (_sub(el, "e"), _sub(el, "sub"), _sub(el, "sup"))
    if tag == "rad":
        hide = _val(el.find(_q("radPr")), "degHide")
        if hide in ("1", "on", "true"):
            return "<msqrt>%s</msqrt>" % _sub(el, "e")
        return "<mroot>%s%s</mroot>" % (_sub(el, "e"), _sub(el, "deg"))
    if tag == "nary":
        pr = el.find(_q("naryPr"))
        chr_ = _val(pr, "chr", "∫")
        op = "<mo>%s</mo>" % escape(chr_)
        sub, sup = el.find(_q("sub")), el.find(_q("sup"))
        s, p = (_row(sub) if sub is not None else ""), (_row(sup) if sup is not None else "")
        if s and p:
            head = "<munderover>%s%s%s</munderover>" % (op, s, p)
        elif s:
            head = "<munder>%s%s</munder>" % (op, s)
        elif p:
            head = "<mover>%s%s</mover>" % (op, p)
        else:
            head = op
        return "<mrow>%s%s</mrow>" % (head, _sub(el, "e"))
    if tag == "d":
        pr = el.find(_q("dPr"))
        beg = _val(pr, "begChr", "(")
        end = _val(pr, "endChr", ")")
        sep = _val(pr, "sepChr", "|" if False else ",")
        es = [_row(e) for e in el.findall(_q("e"))]
        inner = ("<mo>%s</mo>" % escape(sep)).join(es)
        return "<mrow><mo>%s</mo>%s<mo>%s</mo></mrow>" % (escape(beg), inner, escape(end))
    if tag == "func":
        return "<mrow>%s%s</mrow>" % (_sub(el, "fName"), _sub(el, "e"))
    if tag == "limLow":
        return "<munder>%s%s</munder>" % (_sub(el, "e"), _sub(el, "lim"))
    if tag == "limUpp":
        return "<mover>%s%s</mover>" % (_sub(el, "e"), _sub(el, "lim"))
    if tag == "acc":
        c = _val(el.find(_q("accPr")), "chr", "^")
        return "<mover accent='true'>%s<mo>%s</mo></mover>" % (_sub(el, "e"), escape(c))
    if tag == "bar":
        pos = _val(el.find(_q("barPr")), "pos", "top")
        t = "mover" if pos == "top" else "munder"
        return "<%s>%s<mo>―</mo></%s>" % (t, _sub(el, "e"), t)
    if tag == "groupChr":
        c = _val(el.find(_q("groupChrPr")), "chr", "⏟")
        return "<munder>%s<mo>%s</mo></munder>" % (_sub(el, "e"), escape(c))
    if tag == "box" or tag == "phant":
        return _sub(el, "e")
    if tag == "eqArr":
        rows = "".join("<mtr><mtd>%s</mtd></mtr>" % _row(e) for e in el.findall(_q("e")))
        return "<mtable>%s</mtable>" % rows
    if tag == "m":
        rows = ""
        for mr in el.findall(_q("mr")):
            rows += "<mtr>" + "".join("<mtd>%s</mtd>" % _row(e) for e in mr.findall(_q("e"))) + "</mtr>"
        return "<mtable>%s</mtable>" % rows
    if tag in ("oMath", "e", "num", "den", "sup", "sub", "deg", "lim", "fName"):
        return _row(el)
    if tag.endswith("Pr"):
        return ""
    return "".join(_node(c) for c in el)


def omml_to_mathml(el, display=False):
    """el: lxml element m:oMath or m:oMathPara."""
    try:
        maths = [el] if el.tag == _q("oMath") else list(el.iter(_q("oMath")))
        body = "".join(_row(m) for m in maths)
        return '<math xmlns="http://www.w3.org/1998/Math/MathML"%s>%s</math>' % (' display="block"' if display else "", body)
    except Exception:
        return ""
