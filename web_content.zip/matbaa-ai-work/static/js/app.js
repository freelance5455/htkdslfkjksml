/* MATBAA AI — front-end application (home, upload, processing, preview editor, export). */
(() => {
  const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
  const esc = Booklet.esc;
  let TH = null, files = [], theme = 'iraqi', P = null, hist = [], hi = -1, sel = null, zoom = 1, curPage = 1, info = null;
  let saveT = null, renderT = null, rendering = false, again = false, dirty = false, polling = null;

  const toast = (m, err) => { const d = document.createElement('div'); d.textContent = m; if (err) d.className = 'err'; $('#toast').appendChild(d); setTimeout(() => d.remove(), err ? 6000 : 3200); };
  async function api(url, opts) {
    const r = await fetch(url, opts);
    if (!r.ok) { let m = 'حدث خطأ'; try { m = (await r.json()).error || m; } catch (e) { } throw new Error(m); }
    return r;
  }
  const fmtSize = n => n > 1048576 ? (n / 1048576).toFixed(1) + ' م.ب' : Math.max(1, Math.round(n / 1024)) + ' ك.ب';

  /* ================= HOME ================= */
  function buildThemeGrid() {
    const g = $('#themeGrid'); g.innerHTML = '';
    Object.values(TH.themes).forEach(t => {
      const b = document.createElement('button');
      b.className = 'tcard' + (t.id === theme ? ' on' : ''); b.dataset.id = t.id;
      b.innerHTML = '<div class="pv"></div><b>' + esc(t.name) + '</b><small>' + esc(t.desc) + '</small>';
      const pv = b.querySelector('.pv');
      const bk = document.createElement('div'); bk.className = 'bk';
      Booklet.applyVars(bk, t, TH);
      bk.innerHTML = '<div class="page cover cv-' + t.cover + '">' + Booklet.coverHtml({ title: 'عنوان المادة', subtitle: 'الفصل الأول', teacher: 'اسم المدرس', institution: 'اسم المؤسسة', grade: 'المرحلة', year: '2026' }, t) + '</div>';
      pv.appendChild(bk);
      b.onclick = () => { theme = t.id; $$('.tcard').forEach(x => x.classList.toggle('on', x.dataset.id === theme)); };
      g.appendChild(b);
      const pg = bk.firstChild; const sc = () => { pg.style.transform = 'scale(' + (pv.clientWidth / 794) + ')'; };
      sc(); new ResizeObserver(sc).observe(pv);
    });
  }

  function renderFiles() {
    const ul = $('#files'); ul.innerHTML = '';
    files.forEach((f, i) => {
      const li = document.createElement('li');
      li.innerHTML = '<div class="fi">DOC</div><div class="nm"><b>' + esc(f.name) + '</b><span>' +
        (f.error ? '<span class="err">' + esc(f.error) + '</span>' : (f.id ? fmtSize(f.size) + ' • ' + (f.pagesEstimated ? '≈ ' : '') + f.pages + ' صفحة • ' + f.words.toLocaleString('ar') + ' كلمة' : 'جارٍ الرفع…')) +
        '</span><div class="pr"><i style="width:' + (f.id ? 100 : f.pct || 0) + '%"></i></div></div>' +
        (files.length > 1 ? '<button class="ib" data-a="up">↑</button><button class="ib" data-a="dn">↓</button>' : '') + '<button class="ib" data-a="rm">✕</button>';
      li.querySelectorAll('button').forEach(b => b.onclick = () => {
        const a = b.dataset.a;
        if (a === 'rm') { if (f.id) fetch('/api/uploads/' + f.id, { method: 'DELETE' }); files.splice(i, 1); }
        if (a === 'up' && i > 0) [files[i - 1], files[i]] = [files[i], files[i - 1]];
        if (a === 'dn' && i < files.length - 1) [files[i + 1], files[i]] = [files[i], files[i + 1]];
        renderFiles();
      });
      ul.appendChild(li);
    });
    const ok = files.filter(f => f.id);
    $('#mergeRow').hidden = ok.length < 2;
    $('#start').disabled = !ok.length || files.some(f => !f.id && !f.error);
    $('#startHint').textContent = ok.length ? '' : 'ارفع ملفاً واحداً على الأقل للبدء';
  }

  function addFiles(list) {
    [...list].forEach(file => {
      if (!/\.docx?$/i.test(file.name)) { toast('«' + file.name + '» ليس ملف Word', true); return; }
      const f = { name: file.name, size: file.size, pct: 0 };
      files.push(f); renderFiles();
      const fd = new FormData(); fd.append('file', file);
      const x = new XMLHttpRequest(); x.open('POST', '/api/uploads');
      x.upload.onprogress = e => { f.pct = e.loaded / e.total * 100; renderFiles(); };
      x.onload = () => {
        let j = {}; try { j = JSON.parse(x.responseText); } catch (e) { }
        if (x.status === 200) Object.assign(f, j); else { f.error = j.error || 'فشل الرفع'; toast(f.error, true); }
        renderFiles();
      };
      x.onerror = () => { f.error = 'انقطع الاتصال'; renderFiles(); };
      x.send(fd);
    });
  }

  function setupHome() {
    const drop = $('#drop'), inp = $('#file');
    $('#pick').onclick = () => inp.click();
    inp.onchange = () => { addFiles(inp.files); inp.value = ''; };
    ['dragenter', 'dragover'].forEach(e => drop.addEventListener(e, ev => { ev.preventDefault(); drop.classList.add('over'); }));
    ['dragleave', 'drop'].forEach(e => drop.addEventListener(e, ev => { ev.preventDefault(); drop.classList.remove('over'); }));
    drop.addEventListener('drop', ev => addFiles(ev.dataTransfer.files));
    $('#start').onclick = startDesign;
  }

  async function startDesign() {
    const ok = files.filter(f => f.id);
    const meta = {};
    ['title', 'subtitle', 'teacher', 'institution', 'grade', 'year'].forEach(k => { const v = $('#m_' + k).value.trim(); if (v) meta[k] = v; });
    showProc(true);
    try {
      const r = await (await api('/api/projects', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ uploads: ok.map(f => f.id), theme, merge: $('#merge').checked, meta }) })).json();
      await pollAll(r.projects.map(p => p.id));
      files = []; renderFiles();
      if (r.projects.length === 1) location.hash = '#/p/' + r.projects[0].id;
      else { showProc(false); toast('تم إنشاء ' + r.projects.length + ' ملازم'); loadProjects(); location.hash = '#projects'; }
    } catch (e) { showProc(false); toast(e.message, true); }
  }
  function showProc(v) { $('#proc').hidden = !v; if (v) { $('#procBar').style.width = '2%'; $$('.stages li').forEach(l => l.className = ''); } }
  function pollAll(ids) {
    return new Promise((res, rej) => {
      const tick = async () => {
        try {
          const sts = await Promise.all(ids.map(id => api('/api/projects/' + id + '/status').then(r => r.json())));
          const bad = sts.find(s => s.stage === 'error');
          if (bad) return rej(new Error(bad.error || bad.message));
          const prog = sts.reduce((a, s) => a + s.progress, 0) / sts.length;
          $('#procBar').style.width = Math.max(3, prog * 100) + '%';
          const cur = sts.find(s => s.stage !== 'done') || sts[0];
          $('#procMsg').textContent = cur.message || '';
          const order = ['parsing', 'analyzing', 'done'];
          $$('.stages li').forEach(l => { const i = order.indexOf(l.dataset.s), c = order.indexOf(cur.stage); l.className = i < c || cur.stage === 'done' ? 'ok' : (i === c ? 'on' : ''); });
          if (sts.every(s => s.stage === 'done')) return res();
        } catch (e) { return rej(e); }
        setTimeout(tick, 600);
      };
      tick();
    });
  }

  async function loadProjects() {
    const g = $('#projGrid');
    try {
      const { projects } = await (await api('/api/projects')).json();
      g.innerHTML = projects.length ? '' : '<div class="empty">لا توجد مشاريع بعد. ارفع أول ملف Word وابدأ.</div>';
      projects.forEach(p => {
        const d = document.createElement('div'); d.className = 'card pcard';
        const st = p.status && p.status.stage;
        d.innerHTML = '<h4>' + esc(p.title || p.name || 'ملزمة') + '</h4><small>' + esc((TH.themes[p.theme] || {}).name || '') + ' • ' +
          new Date(p.updated * 1000).toLocaleDateString('ar-IQ') + (st && st !== 'done' ? ' • ' + (st === 'error' ? 'فشل' : 'قيد المعالجة') : '') + '</small>' +
          '<div class="acts"><button class="btn gold sm" data-a="open"' + (st === 'done' ? '' : ' disabled') + '>فتح</button><button class="btn ghost sm danger" data-a="del">حذف</button></div>';
        d.querySelector('[data-a=open]').onclick = () => location.hash = '#/p/' + p.id;
        d.querySelector('[data-a=del]').onclick = async () => { if (confirm('حذف هذا المشروع نهائياً مع ملفاته؟')) { await api('/api/projects/' + p.id, { method: 'DELETE' }); loadProjects(); } };
        g.appendChild(d);
      });
    } catch (e) { g.innerHTML = ''; }
  }

  /* ================= EDITOR ================= */
  const snap = () => JSON.stringify({ blocks: P.blocks, meta: P.meta, theme: P.theme, overrides: P.overrides });
  function pushHist() {
    const s = snap();
    if (hist[hi] === s) return;
    hist = hist.slice(0, hi + 1); hist.push(s); if (hist.length > 60) hist.shift(); hi = hist.length - 1; syncUndo();
  }
  function syncUndo() { $('#undo').disabled = hi <= 0; $('#redo').disabled = hi >= hist.length - 1; }
  function restore(i) {
    hi = i; const o = JSON.parse(hist[hi]); Object.assign(P, o); syncUndo(); syncInspector(); queueSave(); queueRender(0);
  }
  function queueSave() {
    dirty = true; $('#saved').textContent = 'جارٍ الحفظ…'; $('#saved').classList.add('dirty');
    clearTimeout(saveT); saveT = setTimeout(save, 700);
  }
  async function save() {
    clearTimeout(saveT);
    if (!P || !dirty) return;
    dirty = false;
    try {
      await api('/api/projects/' + P.id, { method: 'PUT', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ blocks: P.blocks, meta: P.meta, theme: P.theme, overrides: P.overrides, name: P.name }) });
      if (!dirty) { $('#saved').textContent = 'تم الحفظ ✓'; $('#saved').classList.remove('dirty'); }
    } catch (e) { dirty = true; $('#saved').textContent = 'تعذّر الحفظ'; toast(e.message, true); }
  }
  function change() { pushHist(); queueSave(); queueRender(250); }
  function queueRender(ms) { clearTimeout(renderT); renderT = setTimeout(doRender, ms); }

  async function doRender() {
    if (rendering) { again = true; return; }
    rendering = true; $('#rendering').hidden = false;
    const cv = $('#canvas'), keep = curPage, st = cv.scrollTop;
    $('#stage').style.zoom = 1;
    try {
      info = await Booklet.render($('#root'), P, TH, { editable: true });
    } catch (e) { console.error(e); toast('خطأ في إخراج الصفحات: ' + e.message, true); }
    $('#stage').style.zoom = zoom;
    $$('#root [data-frag]').forEach(e => { (e.matches('[data-ed]') ? [e] : [...e.querySelectorAll('[data-ed]')]).forEach(x => { x.removeAttribute('contenteditable'); x.title = 'عنصر ممتد على صفحتين — عدّله من تبويب «العنصر»'; }); });
    markSel(); buildPagesList();
    cv.scrollTop = st;
    $('#ptot').textContent = '/ ' + (info ? info.pages.length : 1);
    $('#pnum').max = info ? info.pages.length : 1;
    rendering = false; $('#rendering').hidden = true;
    if (again) { again = false; queueRender(0); }
  }

  function buildPagesList() {
    const l = $('#pagesList'); l.innerHTML = '';
    if (!info) return;
    let chap = '';
    info.pages.forEach((pg, i) => {
      let t = i === 0 ? 'الغلاف' : '';
      const h = pg.querySelector('.h1 .h-t, .h2 .h-t, .toc-title');
      if (h) t = h.textContent.trim();
      const b = document.createElement('button'); b.dataset.n = i + 1;
      b.innerHTML = '<b>' + (i + 1) + '</b>' + esc(t);
      b.onclick = () => goPage(i + 1);
      l.appendChild(b);
    });
    markPage();
  }
  function goPage(n) {
    if (!info) return; n = Math.max(1, Math.min(info.pages.length, n));
    const pg = info.pages[n - 1]; const cv = $('#canvas');
    cv.scrollTop = pg.offsetTop * zoom - 20 + 0; // offsetTop is unzoomed layout units
    curPage = n; markPage();
  }
  function markPage() {
    $('#pnum').value = curPage;
    $$('#pagesList button').forEach(b => b.classList.toggle('on', +b.dataset.n === curPage));
    const on = $('#pagesList button.on'); if (on) on.scrollIntoView({ block: 'nearest' });
  }
  function onScroll() {
    if (!info) return;
    const cv = $('#canvas'); const mid = cv.scrollTop + cv.clientHeight / 3;
    let best = 1;
    for (let i = 0; i < info.pages.length; i++) { if (info.pages[i].offsetTop * zoom <= mid) best = i + 1; else break; }
    if (best !== curPage) { curPage = best; markPage(); }
  }
  function setZoom(z) { zoom = Math.max(.3, Math.min(2.5, z)); $('#stage').style.zoom = zoom; $('#zlab').textContent = Math.round(zoom * 100) + '%'; goPage(curPage); }

  /* ---- DOM -> runs ---- */
  function domToRuns(el, origRuns) {
    const maths = (origRuns || []).filter(r => r.mm); let mi = 0;
    const out = [];
    (function walk(n, f) {
      n.childNodes.forEach(c => {
        if (c.nodeType === 3) { const t = c.nodeValue.replace(/ /g, ' '); if (t) out.push(Object.assign({}, f, { t })); }
        else if (c.nodeType === 1) {
          if (c.classList.contains('eq')) { if (maths[mi]) out.push(maths[mi++]); return; }
          if (c.tagName === 'BR') { out.push(Object.assign({}, f, { t: '\n' })); return; }
          const g = Object.assign({}, f), tg = c.tagName;
          if (tg === 'B' || tg === 'STRONG') g.b = 1; if (tg === 'I' || tg === 'EM') g.i = 1; if (tg === 'U') g.u = 1;
          ['b', 'i', 'u', 'k', 's'].forEach(k => { if (c.classList.contains(k)) g[k] = 1; });
          if (c.classList.contains('sup')) g.v = 'sup'; if (c.classList.contains('sub')) g.v = 'sub';
          if (c.style && c.style.fontWeight >= 600) g.b = 1;
          const blk = tg === 'DIV' || tg === 'P';
          if (blk && out.length && !(out[out.length - 1].t || '').endsWith('\n')) out.push(Object.assign({}, f, { t: '\n' }));
          walk(c, g);
        }
      });
    })(el, {});
    const m = [];
    out.forEach(r => { const l = m[m.length - 1]; if (l && l.t !== undefined && r.t !== undefined && JSON.stringify(Object.assign({}, l, { t: 0 })) === JSON.stringify(Object.assign({}, r, { t: 0 }))) l.t += r.t; else m.push(r); });
    while (m.length && m[m.length - 1].t === '\n') m.pop();
    return m;
  }
  const blockById = id => P.blocks.find(b => b.id === id);

  function onFocusOut(e) {
    const ed = e.target.closest && e.target.closest('[data-ed]'); if (!ed) return;
    const host = ed.closest('[data-id]'); if (!host) return;
    const b = blockById(host.dataset.id); if (!b || !b.runs) return;
    const runs = domToRuns(ed, b.runs);
    if (JSON.stringify(runs) !== JSON.stringify(b.runs)) { b.runs = runs; change(); }
  }
  function select(id) { sel = id; markSel(); syncBlockPanel(); if (id) switchTab('block'); }
  function markSel() {
    $$('#root .sel').forEach(e => e.classList.remove('sel'));
    if (sel) $$('#root [data-id="' + sel + '"]').forEach(e => e.classList.add('sel'));
  }

  /* ---- inspector ---- */
  const TYPES = [['h1', 'عنوان رئيسي'], ['h2', 'عنوان فرعي'], ['h3', 'عنوان صغير'], ['p', 'فقرة'], ['li', 'نقطة (قائمة)'], ['definition', 'تعريف'], ['law', 'قانون / قاعدة'], ['example', 'مثال'], ['note', 'ملاحظة'], ['warning', 'تنبيه'], ['important', 'نقطة مهمة'], ['question', 'سؤال'], ['answer', 'جواب']];
  const BOXT = ['definition', 'law', 'example', 'note', 'warning', 'important', 'question', 'answer'];
  function switchTab(t) { $$('.tabs button').forEach(b => b.classList.toggle('on', b.dataset.tab === t)); $$('.tab').forEach(x => x.hidden = x.id !== 'tab-' + t); }
  function syncInspector() {
    $$('#miniThemes button').forEach(b => b.classList.toggle('on', b.dataset.id === P.theme));
    const t = Booklet.themeOf(P, TH);
    $('#o_primary').value = t.colors.primary; $('#o_accent').value = t.colors.accent;
    $('#o_font').value = t.font; $('#o_headFont').value = t.headFont; $('#o_size').value = t.size; $('#o_sizeV').textContent = t.size + 'pt';
    $('#o_toc').checked = P.meta.toc !== false;
    $$('[data-meta]').forEach(i => i.value = P.meta[i.dataset.meta] || '');
    $('#pname').value = P.name || '';
  }
  function syncBlockPanel() {
    const b = sel && blockById(sel);
    $('#noSel').hidden = !!b; $('#blockPanel').hidden = !b;
    if (!b) return;
    const sl = $('#b_type'); sl.disabled = ['table', 'image', 'equation'].includes(b.type);
    if (sl.disabled) sl.innerHTML = '<option>' + ({ table: 'جدول', image: 'صورة', equation: 'معادلة' }[b.type]) + '</option>';
    else { sl.innerHTML = TYPES.map(t => '<option value="' + t[0] + '">' + t[1] + '</option>').join('') + '<option value="label">عنوان إطار منفصل</option>'; sl.value = b.type; }
    $('#b_label').value = b.label || ''; $('#b_label').disabled = !BOXT.includes(b.type) && b.type !== 'label';
    $$('#b_var button').forEach(x => x.classList.toggle('on', +x.dataset.v === (b.variant || 0)));
    $('#b_pb').checked = !!b.pb;
    const ta = $('#b_text'); const hasMath = (b.runs || []).some(r => r.mm);
    ta.disabled = !b.runs || hasMath; ta.value = b.runs ? b.runs.map(r => r.t || '').join('') : '';
  }
  function setupEditor() {
    const mt = $('#miniThemes');
    Object.values(TH.themes).forEach(t => {
      const b = document.createElement('button'); b.dataset.id = t.id; b.style.setProperty('--a', t.swatch[0]); b.style.setProperty('--b', t.swatch[1]); b.style.setProperty('--c', t.swatch[2]);
      b.innerHTML = '<i></i>' + esc(t.name.replace('الملزمة ', '')); b.onclick = () => { P.theme = t.id; P.overrides = {}; syncInspector(); change(); };
      mt.appendChild(b);
    });
    const fo = Object.entries(TH.fonts).map(([k, v]) => '<option value="' + k + '">' + v.name + '</option>').join('');
    $('#o_font').innerHTML = fo; $('#o_headFont').innerHTML = fo;
    $$('.tabs button').forEach(b => b.onclick = () => switchTab(b.dataset.tab));
    const ov = (k, v) => { P.overrides = Object.assign({}, P.overrides, { [k]: v }); change(); };
    $('#o_primary').onchange = e => ov('primary', e.target.value); $('#o_accent').onchange = e => ov('accent', e.target.value);
    $('#o_font').onchange = e => ov('font', e.target.value); $('#o_headFont').onchange = e => ov('headFont', e.target.value);
    $('#o_size').oninput = e => { $('#o_sizeV').textContent = e.target.value + 'pt'; }; $('#o_size').onchange = e => ov('size', e.target.value);
    $('#o_toc').onchange = e => { P.meta.toc = e.target.checked; change(); };
    $('#o_reset').onclick = () => { P.overrides = {}; syncInspector(); change(); };
    $$('[data-meta]').forEach(i => i.oninput = () => { P.meta[i.dataset.meta] = i.value; clearTimeout(i._t); i._t = setTimeout(change, 400); });
    $('#pname').onchange = e => { P.name = e.target.value; queueSave(); };
    $('#b_type').onchange = e => { const b = blockById(sel); if (!b) return; const t = e.target.value; b.type = t; if (t === 'label') b.kind = b.kind || 'note'; if (BOXT.includes(t) || t === 'label') b.label = b.label && BOXT.includes(b.type) ? b.label : (Booklet.BOX_AR[t] || b.label || ''); else delete b.label; if (t === 'li' && !b.list) b.list = { marker: '•', level: 0 }; change(); syncBlockPanel(); };
    $('#b_label').onchange = e => { const b = blockById(sel); if (b) { b.label = e.target.value; change(); } };
    $$('#b_var button').forEach(x => x.onclick = () => { const b = blockById(sel); if (b) { b.variant = +x.dataset.v; change(); syncBlockPanel(); } });
    $('#b_pb').onchange = e => { const b = blockById(sel); if (b) { if (e.target.checked) b.pb = 1; else delete b.pb; change(); } };
    $('#b_text').onchange = e => { const b = blockById(sel); if (b && b.runs) { const f = b.runs.find(r => r.t) || {}; b.runs = [Object.assign({}, f, { t: e.target.value })]; change(); } };
    $('#b_up').onclick = () => moveBlock(-1); $('#b_down').onclick = () => moveBlock(1);
    $('#b_del').onclick = () => { if (!sel || !confirm('حذف هذا العنصر؟')) return; P.blocks = P.blocks.filter(b => b.id !== sel); sel = null; syncBlockPanel(); change(); };
    $('#redesign').onclick = redesignPage;
    $('#undo').onclick = () => hi > 0 && restore(hi - 1); $('#redo').onclick = () => hi < hist.length - 1 && restore(hi + 1);
    $('#zin').onclick = () => setZoom(zoom + .1); $('#zout').onclick = () => setZoom(zoom - .1);
    $('#zfit').onclick = () => setZoom(($('#canvas').clientWidth - 40) / 794);
    $('#pprev').onclick = () => goPage(curPage - 1); $('#pnext').onclick = () => goPage(curPage + 1);
    $('#pnum').onchange = e => goPage(+e.target.value);
    $('#canvas').addEventListener('scroll', onScroll);
    $('#canvas').addEventListener('wheel', e => { if (e.ctrlKey) { e.preventDefault(); setZoom(zoom + (e.deltaY < 0 ? .08 : -.08)); } }, { passive: false });
    const root = $('#root');
    root.addEventListener('focusout', onFocusOut);
    root.addEventListener('click', e => { const h = e.target.closest('[data-id]'); select(h ? h.dataset.id : null); });
    root.addEventListener('keydown', e => { if (e.key === 'Escape') e.target.blur(); });
    document.addEventListener('keydown', e => {
      if ($('#editor').hidden || e.target.closest('[contenteditable],input,textarea,select')) return;
      if ((e.ctrlKey || e.metaKey) && e.key === 'z') { e.preventDefault(); hi > 0 && restore(hi - 1); }
      if ((e.ctrlKey || e.metaKey) && (e.key === 'y' || (e.shiftKey && e.key === 'Z'))) { e.preventDefault(); hi < hist.length - 1 && restore(hi + 1); }
    });
    $('#back').onclick = async () => { await save(); location.hash = ''; };
    $('#expBtn').onclick = e => { e.stopPropagation(); $('#expMenu').hidden = !$('#expMenu').hidden; };
    document.addEventListener('click', () => $('#expMenu').hidden = true);
    $$('#expMenu button').forEach(b => b.onclick = () => doExport(b.dataset.x));
    window.addEventListener('beforeprint', () => { if (!$('#editor').hidden) $('#stage').style.zoom = 1; });
    window.addEventListener('afterprint', () => { $('#stage').style.zoom = zoom; });
    window.addEventListener('beforeunload', e => { if (dirty) { e.preventDefault(); e.returnValue = ''; } });
  }
  function moveBlock(d) {
    const i = P.blocks.findIndex(b => b.id === sel), j = i + d; if (i < 0 || j < 0 || j >= P.blocks.length) return;
    [P.blocks[i], P.blocks[j]] = [P.blocks[j], P.blocks[i]]; change();
  }
  async function redesignPage() {
    const pg = info && info.pages[curPage - 1]; if (!pg) return;
    const ids = [...new Set([...pg.querySelectorAll('[data-id]')].map(e => e.dataset.id))];
    let n = 0;
    try {
      const r = await (await api('/api/projects/' + P.id + '/ai/relabel', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ ids }) })).json();
      Object.entries(r.types || {}).forEach(([id, t]) => { const b = blockById(id); if (b && b.type !== t) { b.type = t; if (BOXT.includes(t) && !b.label) b.label = Booklet.BOX_AR[t]; n++; } });
    } catch (e) { }
    ids.forEach(id => { const b = blockById(id); if (b && (BOXT.includes(b.type) || b.type === 'label')) { b.variant = ((b.variant || 0) + 1) % 3; n++; } });
    if (!n) { toast('لا توجد إطارات في هذه الصفحة لإعادة تصميمها'); return; }
    change(); toast('تمت إعادة تصميم الصفحة ' + curPage);
  }

  async function doExport(kind) {
    $('#expMenu').hidden = true;
    if (kind === 'print') { window.print(); return; }
    await save();
    showProc(true); $('#procTitle').textContent = 'جارٍ تجهيز الملف…'; $('#procMsg').textContent = kind === 'pdf' ? 'قد يستغرق PDF بضع ثوانٍ' : ''; $$('.stages').forEach(s => s.hidden = true);
    $('#procBar').style.width = '60%';
    try {
      const r = await api('/api/projects/' + P.id + '/export/' + kind);
      const blob = await r.blob();
      const cd = r.headers.get('content-disposition') || ''; let name = 'matbaa.' + (kind === 'cover' ? 'png' : kind);
      const m = /filename\*=UTF-8''([^;]+)/i.exec(cd); if (m) name = decodeURIComponent(m[1]);
      const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); a.remove();
      toast('تم التصدير بنجاح');
    } catch (e) { toast(e.message, true); }
    showProc(false); $('#procTitle').textContent = 'جارٍ التصميم...'; $$('.stages').forEach(s => s.hidden = false);
  }

  async function openProject(pid) {
    try {
      P = await (await api('/api/projects/' + pid)).json();
    } catch (e) { toast('المشروع غير موجود', true); location.hash = ''; return; }
    if (P.status && P.status.stage !== 'done') { showProc(true); try { await pollAll([pid]); P = await (await api('/api/projects/' + pid)).json(); } catch (e) { showProc(false); toast(e.message, true); location.hash = ''; return; } showProc(false); }
    showProc(false);
    $('#home').hidden = true; $('#editor').hidden = false;
    hist = []; hi = -1; sel = null; curPage = 1; zoom = Math.min(1, Math.max(.4, ($('#canvas').clientWidth - 40) / 794)); $('#zlab').textContent = Math.round(zoom * 100) + '%';
    pushHist(); syncInspector(); syncBlockPanel(); doRender();
  }

  /* ================= ROUTING ================= */
  function route() {
    const m = /^#\/p\/([0-9a-f]{16})$/.exec(location.hash);
    if (m) openProject(m[1]);
    else { $('#editor').hidden = true; $('#home').hidden = false; P = null; loadProjects(); }
  }
  (async function init() {
    TH = await (await fetch('/api/themes')).json();
    buildThemeGrid(); setupHome(); setupEditor(); renderFiles();
    window.addEventListener('hashchange', route); route();
  })();
})();
