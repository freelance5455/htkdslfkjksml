/* MATBAA AI — booklet renderer + paginator. Shared by the live preview, print and server PDF export. */
(function () {
  const PX_CM = 37.7953;
  const BOX_AR = { definition: 'تعريف', law: 'قانون', example: 'مثال', note: 'ملاحظة', warning: 'تنبيه', important: 'مهم', question: 'سؤال', answer: 'الجواب' };
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const tick = () => new Promise(r => requestAnimationFrame(() => r()));

  function themeOf(project, data) {
    const base = JSON.parse(JSON.stringify(data.themes[project.theme] || data.themes.iraqi));
    const o = project.overrides || {};
    if (o.primary) { base.colors.primary = o.primary; base.colors.bold = o.primary; }
    if (o.accent) base.colors.accent = o.accent;
    if (o.font && data.fonts[o.font]) base.font = o.font;
    if (o.headFont && data.fonts[o.headFont]) base.headFont = o.headFont;
    if (o.size) base.size = parseFloat(o.size);
    return base;
  }

  function applyVars(root, th, data) {
    const c = th.colors, s = root.style;
    ['primary', 'accent', 'ink', 'paper', 'tint', 'bold', 'kw', 'kwbg', 'line'].forEach(k => s.setProperty('--' + k, c[k]));
    Object.keys(c.boxes).forEach(k => s.setProperty('--c-' + k, c.boxes[k]));
    s.setProperty('--font', data.fonts[th.font].css);
    s.setProperty('--hfont', data.fonts[th.headFont].css);
    s.setProperty('--size', th.size + 'pt');
    s.setProperty('--lh', th.lh);
    s.setProperty('--radius', th.radius + 'px');
    root.className = root.className.replace(/\bth-\w+/g, '') + ' bk th-' + th.id;
  }

  /* ---------- inline runs ---------- */
  function runHtml(r) {
    if (r.mm) return '<span class="eq' + (r.disp ? ' disp' : '') + '">' + r.mm + '</span>';
    const cls = [];
    if (r.b) cls.push('b'); if (r.i) cls.push('i'); if (r.u) cls.push('u'); if (r.k) cls.push('k'); if (r.s) cls.push('s'); if (r.v) cls.push(r.v);
    const t = esc(r.t).replace(/\n/g, '<br>');
    return cls.length ? '<span class="' + cls.join(' ') + '">' + t + '</span>' : t;
  }
  function tokenize(runs) {
    const out = [];
    for (const r of runs || []) {
      if (r.mm) { out.push({ r, m: 1 }); continue; }
      for (const p of r.t.split(/(\s+)/)) if (p !== '') out.push({ r, t: p });
    }
    return out;
  }
  function tokensHtml(tokens) {
    let html = '', cur = null, buf = '';
    const flush = () => { if (cur && !cur.mm) html += runHtml(Object.assign({}, cur, { t: buf })); cur = null; buf = ''; };
    for (const tk of tokens) {
      if (tk.m) { flush(); html += runHtml(tk.r); continue; }
      if (tk.r !== cur) { flush(); cur = tk.r; }
      buf += tk.t;
    }
    flush();
    return html;
  }

  /* ---------- decorative svg ---------- */
  function star8(r, rot) {
    return '<rect x="' + (-r) + '" y="' + (-r) + '" width="' + 2 * r + '" height="' + 2 * r + '" transform="rotate(' + (rot || 0) + ')"/>' +
      '<rect x="' + (-r) + '" y="' + (-r) + '" width="' + 2 * r + '" height="' + 2 * r + '" transform="rotate(' + (45 + (rot || 0)) + ')"/>';
  }
  function medallion(col, size) {
    return '<svg class="medal" viewBox="-100 -100 200 200" width="' + size + '" height="' + size + '" fill="none" stroke="' + col + '" stroke-width="1.4">' +
      '<g>' + star8(62) + '</g><g opacity=".7">' + star8(48, 22.5) + '</g><g opacity=".5">' + star8(34) + '</g>' +
      '<circle r="86" stroke-width="2"/><circle r="92" stroke-width=".8"/><circle r="22" stroke-width="1.6"/><circle r="8" fill="' + col + '"/></svg>';
  }
  function tileUri(col, op) {
    const svg = '<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="-32 -32 64 64" fill="none" stroke="' + col + '" stroke-opacity="' + op + '" stroke-width="1">' +
      '<g>' + star8(14) + '</g><circle r="22"/><path d="M-32 0h10M22 0h10M0-32v10M0 22v10"/></svg>';
    return 'url("data:image/svg+xml;utf8,' + encodeURIComponent(svg) + '")';
  }
  function cornerSvg(col) {
    return '<svg viewBox="0 0 60 60" width="60" height="60" fill="none" stroke="' + col + '" stroke-width="1.5"><path d="M2 58V20Q2 2 20 2H58"/><path d="M10 58V26Q10 10 26 10H58" opacity=".6"/><circle cx="14" cy="14" r="3" fill="' + col + '"/></svg>';
  }

  /* ---------- cover ---------- */
  function coverHtml(meta, th) {
    const c = th.colors, st = th.cover;
    const title = esc(meta.title || 'عنوان الملزمة'), sub = meta.subtitle ? esc(meta.subtitle) : '';
    const rows = [['إعداد', meta.teacher], ['المرحلة / الصف', meta.grade], ['السنة الدراسية', meta.year], ['الطبعة', meta.edition]].filter(r => r[1]);
    const info = rows.map(r => '<div class="cv-row"><span>' + r[0] + '</span><b>' + esc(r[1]) + '</b></div>').join('');
    const inst = meta.institution ? '<div class="cv-inst">' + esc(meta.institution) + '</div>' : '';
    const teacher = meta.teacher ? '<div class="cv-teacher"><small>إعداد</small><b>' + esc(meta.teacher) + '</b></div>' : '';
    const meta2 = [meta.grade, meta.year, meta.edition ? 'الطبعة ' + meta.edition : ''].filter(Boolean).map(esc).join(' • ');
    if (st === 'iraqi') {
      return '<div class="cv cv-iraqi" style="background-image:' + tileUri(c.accent, .22) + '">' +
        '<div class="cv-frame"></div><div class="cv-corner tl">' + cornerSvg(c.accent) + '</div><div class="cv-corner tr">' + cornerSvg(c.accent) + '</div><div class="cv-corner bl">' + cornerSvg(c.accent) + '</div><div class="cv-corner br">' + cornerSvg(c.accent) + '</div>' +
        inst + '<div class="cv-medal">' + medallion(c.accent, 210) + '</div>' +
        '<h1 class="cv-title">' + title + '</h1>' + (sub ? '<div class="cv-sub">' + sub + '</div>' : '') +
        '<div class="cv-orn"><i></i><b>❖</b><i></i></div>' + teacher + '<div class="cv-meta">' + meta2 + '</div></div>';
    }
    if (st === 'ministerial') {
      return '<div class="cv cv-min"><div class="cv-frame"></div><div class="cv-frame f2"></div>' +
        '<div class="cv-band">' + (inst || '<div class="cv-inst">&nbsp;</div>') + '</div>' +
        '<div class="cv-box"><h1 class="cv-title">' + title + '</h1>' + (sub ? '<div class="cv-sub">' + sub + '</div>' : '') + '</div>' +
        '<div class="cv-info">' + info + '</div></div>';
    }
    if (st === 'university') {
      return '<div class="cv cv-uni"><div class="cv-side"><span>' + (meta.year ? esc(meta.year) : '') + '</span></div>' +
        '<div class="cv-main">' + inst + '<div class="cv-rule"></div><h1 class="cv-title">' + title + '</h1>' + (sub ? '<div class="cv-sub">' + sub + '</div>' : '') +
        '<div class="cv-rule short"></div><div class="cv-info">' + info + '</div></div></div>';
    }
    if (st === 'compact') {
      return '<div class="cv cv-compact"><div class="cv-top">' + inst + '<h1 class="cv-title">' + title + '</h1>' + (sub ? '<div class="cv-sub">' + sub + '</div>' : '') + '</div>' +
        '<div class="cv-bottom"><div class="cv-info">' + info + '</div></div></div>';
    }
    if (st === 'modern') {
      return '<div class="cv cv-modern"><i class="bl b1"></i><i class="bl b2"></i><i class="bl b3"></i>' +
        '<div class="cv-card">' + inst + '<h1 class="cv-title">' + title + '</h1>' + (sub ? '<div class="cv-sub">' + sub + '</div>' : '') +
        '<div class="cv-chips">' + rows.map(r => '<span><small>' + r[0] + '</small>' + esc(r[1]) + '</span>').join('') + '</div></div></div>';
    }
    return '<div class="cv cv-bw"><div class="cv-frame"></div>' + inst + '<div class="cv-box"><h1 class="cv-title">' + title + '</h1>' + (sub ? '<div class="cv-sub">' + sub + '</div>' : '') + '</div>' +
      '<div class="cv-lines"></div><div class="cv-info">' + info + '</div></div>';
  }

  /* ---------- item factories ---------- */
  function makeCtx(th, project, opts) {
    return { th, project, chap: 0, editable: !!opts.editable, mq: opts.mediaQuery || '', pid: project.id, rb: th.rainbow };
  }
  function chapColor(ctx) {
    return ctx.rb ? ctx.rb[(Math.max(ctx.chap, 1) - 1) % ctx.rb.length] : ctx.th.colors.primary;
  }
  function wrapEl(html, ctx, b) {
    const d = document.createElement('div');
    d.innerHTML = html;
    const el = d.firstElementChild;
    el.style.setProperty('--chap', chapColor(ctx));
    if (b) el.dataset.id = b.id;
    return el;
  }
  function editAttr(ctx, b, extra) {
    return ctx.editable ? ' data-t="1" data-ed="1" contenteditable="true" spellcheck="false"' + (extra || '') : ' data-t="1"';
  }

  const tgtOf = el => el.matches('[data-t]') ? el : el.querySelector('[data-t]');
  function textItem(ctx, b, tokens, cont) {
    const typ = b.type;
    const v = (b.variant || 0) % 3;
    let build;
    if (typ === 'p') {
      build = (t, c) => wrapEl('<p class="p' + (c ? ' cont' : '') + '" dir="auto"' + editAttr(ctx, b) + '></p>', ctx, b);
    } else if (typ === 'li') {
      const lv = (b.list && b.list.level) || 0, mk = esc((b.list && b.list.marker) || '•');
      build = (t, c) => wrapEl('<div class="li lv' + lv + (c ? ' cont' : '') + '" style="--lvl:' + lv + '"><span class="mk" dir="auto">' + (c ? '' : mk) + '</span><span class="li-t" dir="auto"' + editAttr(ctx, b) + '></span></div>', ctx, b);
    } else if (typ === 'h1' || typ === 'h2' || typ === 'h3') {
      build = (t, c) => {
        let no = '';
        if (typ === 'h1') no = ' data-no="' + ctx.chap + '"';
        return wrapEl('<div class="' + typ + ' kwn"' + no + '><span class="h-t" dir="auto"' + editAttr(ctx, b) + '></span></div>', ctx, b);
      };
    } else {
      const label = esc(b.label || BOX_AR[typ] || '');
      build = (t, c) => wrapEl('<div class="box v' + v + ' t-' + typ + (c ? ' cont' : '') + '"><div class="box-h">' + (c ? '' : label) + '</div><div class="box-b" dir="auto"' + editAttr(ctx, b) + '></div></div>', ctx, b);
    }
    const item = { id: b.id, tokens, cont: !!cont, type: typ };
    item.el = build(tokens, cont);
    tgtOf(item.el).innerHTML = tokensHtml(tokens);
    if (cont) { item.el.dataset.frag = '1'; }
    item.split = function (pg) {
      const body = pg.querySelector('.body');
      const tgt = tgtOf(item.el);
      const toks = item.tokens;
      const others = body.children.length > 1;
      const minT = others ? Math.min(6, Math.max(1, toks.length - 1)) : 1;
      let lo = 0, hi = toks.length - 1;
      while (lo < hi) {
        const mid = (lo + hi + 1) >> 1;
        tgt.innerHTML = tokensHtml(toks.slice(0, mid));
        if (body.scrollHeight > body.clientHeight + 1) hi = mid - 1; else lo = mid;
      }
      if (lo < minT || typ[0] === 'h') { tgt.innerHTML = tokensHtml(toks); return null; }
      // avoid leaving a single orphan word behind
      if (toks.length - lo < 3 && lo > minT + 2) lo -= 2;
      tgt.innerHTML = tokensHtml(toks.slice(0, lo));
      item.el.dataset.frag = '1'; item.el.classList.add('split-top');
      const rest = textItem(ctx, b, toks.slice(lo), true);
      item.tokens = toks.slice(0, lo);
      return rest;
    };
    return item;
  }

  function tableRowsHtml(rows, hdr) {
    return rows.map((row, ri) => '<tr>' + row.map(c => {
      const tag = (hdr && ri === 0) ? 'th' : 'td';
      const inner = (c.paras || []).map(p => '<div dir="auto">' + p.map(runHtml).join('') + '</div>').join('') +
        (c.imgs || []).map(i => '<img src="' + i.src + '">').join('');
      return '<' + tag + (c.cs > 1 ? ' colspan="' + c.cs + '"' : '') + (c.rs > 1 ? ' rowspan="' + c.rs + '"' : '') + '>' + inner + '</td>'.replace('td', tag);
    }).join('') + '</tr>').join('');
  }
  function tableItem(ctx, b, rows, cont) {
    rows = rows.map(r => r.map(c => Object.assign({}, c, { imgs: (c.imgs || []).map(i => ({ src: '/api/projects/' + ctx.pid + '/media/' + encodeURIComponent(i.file) + ctx.mq })) })));
    const header = rows[0];
    const build = (rs, c) => wrapEl('<div class="tbl-w' + (c ? ' cont' : '') + '"><table class="tbl"><tbody>' + tableRowsHtml(rs, true) + '</tbody></table></div>', ctx, b);
    const item = { id: b.id, rows, type: 'table' };
    item.el = build(rows, cont);
    item.split = function (pg) {
      const body = pg.querySelector('.body');
      const valid = rows.map((_, i) => i).filter(i => i > 0 && !rows.some((r, ri) => ri < i && r.some(c => ri + (c.rs || 1) > i)));
      let best = null;
      for (const k of valid) {
        const part = rows.slice(0, k);
        const holder = item.el;
        holder.querySelector('tbody').innerHTML = tableRowsHtml(part, true);
        if (body.scrollHeight > body.clientHeight + 1) break;
        best = k;
      }
      if (!best || (body.children.length > 1 && best < 2)) { item.el.querySelector('tbody').innerHTML = tableRowsHtml(rows, true); return null; }
      item.el.querySelector('tbody').innerHTML = tableRowsHtml(rows.slice(0, best), true);
      const restRows = [header.map(c => Object.assign({}, c, { rs: 1, cs: c.cs }))].concat(rows.slice(best));
      item.el.dataset.frag = '1';
      return tableItem(ctx, b, restRows, true);
    };
    return item;
  }

  function makeItem(ctx, b) {
    const t = b.type;
    if (t === 'h1') ctx.chap++;
    if (t === 'p' || t === 'li' || t === 'h1' || t === 'h2' || t === 'h3' || BOX_AR[t]) {
      const it = textItem(ctx, b, tokenize(b.runs || []), false);
      if (t === 'h1') { it.pageBreak = ctx.th.chapterBreak; it.el.dataset.no = ctx.chap; }
      if (b.pb) it.pageBreak = true;
      return it;
    }
    if (t === 'label') {
      const el = wrapEl('<div class="chip kwn t-' + (b.kind || 'note') + '"><span>' + esc(b.label || BOX_AR[b.kind] || '') + '</span></div>', ctx, b);
      return { id: b.id, el, type: t };
    }
    if (t === 'equation') {
      const el = wrapEl('<div class="eqblock" dir="ltr">' + (b.runs || []).map(runHtml).join('') + '</div>', ctx, b);
      return { id: b.id, el, type: t };
    }
    if (t === 'image') {
      const maxw = (21 - ctx.th.margins.inner - ctx.th.margins.outer);
      const w = Math.min(b.w || maxw, maxw);
      const el = wrapEl('<figure class="img"><img src="/api/projects/' + ctx.pid + '/media/' + encodeURIComponent(b.file) + ctx.mq + '" style="width:' + w + 'cm"></figure>', ctx, b);
      return { id: b.id, el, type: t };
    }
    if (t === 'table') return tableItem(ctx, b, b.rows || [], false);
    return null;
  }

  async function waitImages(root) {
    const imgs = [...root.querySelectorAll('img')];
    await Promise.all(imgs.map(im => im.complete ? 0 : new Promise(r => { im.onload = im.onerror = r; setTimeout(r, 8000); })));
  }
  async function fontsReady() {
    try { await Promise.race([document.fonts.ready, new Promise(r => setTimeout(r, 3500))]); } catch (e) { }
  }

  /* ---------- main ---------- */
  async function render(root, project, data, opts) {
    opts = opts || {};
    const th = themeOf(project, data);
    root.style.zoom = 1;
    root.innerHTML = '';
    applyVars(root, th, data);
    if (opts.editable) root.classList.add('editable');
    await fontsReady();
    const ctx = makeCtx(th, project, opts);
    const pages = [];
    const m = th.margins;
    const meta = project.meta || {};

    function newPage(kind) {
      const n = pages.length + 1;
      const pg = document.createElement('div');
      pg.className = 'page' + (kind ? ' ' + kind : '');
      pg.dataset.n = n;
      pg.style.setProperty('--chap', th.colors.primary);
      if (kind === 'cover') { root.appendChild(pg); pages.push(pg); return pg; }
      pg.innerHTML = '<div class="hdr"></div><div class="body"></div><div class="ftr"></div>';
      const odd = n % 2 === 1;
      const inner = m.inner * PX_CM, outer = m.outer * PX_CM;
      const b = pg.querySelector('.body');
      b.style.cssText = 'top:' + m.top * PX_CM + 'px;bottom:' + m.bottom * PX_CM + 'px;right:' + (odd ? inner : outer) + 'px;left:' + (odd ? outer : inner) + 'px';
      ['hdr', 'ftr'].forEach(k => { const e = pg.querySelector('.' + k); e.style.right = (odd ? inner : outer) + 'px'; e.style.left = (odd ? outer : inner) + 'px'; });
      root.appendChild(pg); pages.push(pg); return pg;
    }

    // cover
    const cv = newPage('cover');
    cv.innerHTML = coverHtml(meta, th);
    cv.classList.add('cv-' + th.cover);

    // items
    const blocks = project.blocks || [];
    const items = [];
    const heads = [];
    const tocItems = [];
    const body = [];
    for (const b of blocks) {
      const it = makeItem(ctx, b);
      if (it) body.push({ it, b });
      if (b.type === 'h1' || b.type === 'h2') heads.push({ id: b.id, level: +b.type[1], text: (b.runs || []).map(r => r.t || '').join('').trim() });
    }
    if (meta.toc !== false && heads.length) {
      const t = wrapEl('<div class="toc-title"><span>فهرس المحتويات</span></div>', ctx);
      t.classList.add('kwn');
      items.push({ el: t, type: 'toc' });
      for (const h of heads) {
        const el = wrapEl('<div class="toc-row l' + h.level + '" data-target="' + h.id + '"><span class="tt" dir="auto">' + esc(h.text) + '</span><i class="dots"></i><span class="pg">0</span></div>', ctx);
        items.push({ el, type: 'toc', row: 1 });
      }
      items[items.length - 1].endToc = true;
    }
    body.forEach(x => items.push(x.it));
    // preload images by attaching to a temp holder
    const holder = document.createElement('div');
    holder.style.cssText = 'position:absolute;left:-9999px;top:0;width:10px;height:10px;overflow:hidden';
    items.forEach(i => holder.appendChild(i.el));
    root.appendChild(holder);
    await waitImages(holder);
    holder.remove();

    // layout
    let pg = null;
    const over = p => { const b = p.querySelector('.body'); return b.scrollHeight > b.clientHeight + 1; };
    const startPage = () => { pg = newPage(); return pg; };
    let count = 0, tocEnded = false;
    const progress = opts.onProgress;
    for (let idx = 0; idx < items.length; idx++) {
      let item = items[idx];
      const firstBody = !tocEnded && idx > 0 && items[idx - 1].endToc;
      if (firstBody) { tocEnded = true; startPage(); }
      if (item.pageBreak && pg && pg.querySelector('.body').children.length) {
        const prevIsH1 = pg.querySelector('.body').lastElementChild && pg.querySelector('.body').lastElementChild.classList.contains('h1');
        if (!prevIsH1) startPage();
      }
      let guard = 0;
      while (item && guard++ < 400) {
        if (!pg) startPage();
        const bodyEl = pg.querySelector('.body');
        bodyEl.appendChild(item.el);
        if (!over(pg)) { item = null; break; }
        if (item.split) {
          const rest = item.split(pg);
          if (rest) { startPage(); item = rest; continue; }
        }
        bodyEl.removeChild(item.el);
        if (bodyEl.children.length === 0) { bodyEl.appendChild(item.el); item.el.classList.add('overflow'); item = null; break; }
        const carry = [];
        while (bodyEl.children.length > 1 && bodyEl.lastElementChild.classList.contains('kwn')) carry.unshift(bodyEl.removeChild(bodyEl.lastElementChild));
        startPage();
        carry.forEach(c => pg.querySelector('.body').appendChild(c));
        // loop again: item will be appended to the new page and re-checked (and split if needed)
      }
      if (++count % 120 === 0) { if (progress) progress(idx / items.length); await tick(); }
    }
    if (!pg) startPage();

    // headers, footers, toc numbers, chapter names
    const pageOfHeading = {};
    pages.forEach((p, i) => p.querySelectorAll('[data-id]').forEach(e => { if (/\bh[12]\b/.test(e.className) && !(e.dataset.frag) && !(pageOfHeading[e.dataset.id])) pageOfHeading[e.dataset.id] = i + 1; }));
    root.querySelectorAll('.toc-row').forEach(r => { r.querySelector('.pg').textContent = pageOfHeading[r.dataset.target] || ''; });
    let chapter = '';
    pages.forEach((p, i) => {
      if (p.classList.contains('cover')) return;
      const first = p.querySelector('.body > :first-child');
      const h1 = p.querySelector('.body .h1 .h-t');
      const opening = first && first.classList.contains('h1');
      if (h1) chapter = h1.textContent.trim();
      const hdr = p.querySelector('.hdr'), ftr = p.querySelector('.ftr');
      if (!p.querySelector('.toc-title') || true) {
        hdr.innerHTML = '<span class="h-book">' + esc(meta.title || '') + '</span><span class="h-chap">' + (opening ? '' : esc(chapter)) + '</span>';
        if (p.querySelector('.toc-title') && !p.querySelector('.toc-row')) hdr.innerHTML = '';
      }
      ftr.innerHTML = '<span class="f-txt">' + esc(meta.footer || '') + '</span><span class="f-no"><b>' + (i + 1) + '</b></span><span class="f-r">' + esc(meta.teacher || '') + '</span>';
      if (p.dataset.n % 2 === 0) ftr.classList.add('even');
    });
    // chapter number decorations
    root.querySelectorAll('.h1[data-no]').forEach(e => { e.style.setProperty('--no', '"' + e.dataset.no + '"'); });
    root.dataset.pages = pages.length;
    if (progress) progress(1);
    return { pages, headings: heads.map(h => Object.assign({ page: pageOfHeading[h.id] || 0 }, h)), theme: th };
  }

  window.Booklet = { render, coverHtml, themeOf, applyVars, BOX_AR, esc, runHtml };
})();
