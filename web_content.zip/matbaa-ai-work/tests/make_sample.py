"""Creates a realistic Arabic sample .docx (headings, definitions, laws, tables, image, equation, Q&A)."""
import sys, os
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.oxml import parse_xml
from docx.enum.text import WD_ALIGN_PARAGRAPH
from PIL import Image, ImageDraw

out = sys.argv[1] if len(sys.argv) > 1 else "sample.docx"
d = Document()

def rtl(p):
    from docx.oxml import OxmlElement
    p._p.get_or_add_pPr().append(OxmlElement("w:bidi"))
    return p

def P(text, bold=False, size=None, style=None, color=None):
    p = rtl(d.add_paragraph(style=style))
    r = p.add_run(text); r.bold = bold
    if size: r.font.size = Pt(size)
    if color: r.font.color.rgb = RGBColor.from_string(color)
    return p

P("الفيزياء – الحركة والقوى", True, 22, "Title")
P("الفصل الأول: الحركة في بعد واحد", style="Heading 1")
P("مقدمة", style="Heading 2")
P("تدرس الميكانيكا حركة الأجسام والأسباب التي تؤدي إلى تغيّر هذه الحركة، وتنقسم إلى علم الحركة وعلم الديناميك. وتعد دراسة الحركة في بعد واحد الأساس الذي تُبنى عليه بقية المفاهيم في الفيزياء الكلاسيكية، ولذلك يجب فهمها فهماً عميقاً قبل الانتقال إلى الحركة في بعدين.")
p = rtl(d.add_paragraph()); r = p.add_run("السرعة"); r.bold = True
p.add_run(" هي المسافة المقطوعة في وحدة الزمن، وتقاس بوحدة متر لكل ثانية في النظام الدولي للوحدات.")
P("تعريف: الإزاحة هي التغير في موقع الجسم وتكون كمية متجهة لها مقدار واتجاه.")
P("قانون:")
# block equation (OMML)
omml = ('<m:oMathPara xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"><m:oMath>'
        '<m:r><m:t>v=</m:t></m:r><m:f><m:num><m:r><m:t>Δx</m:t></m:r></m:num><m:den><m:r><m:t>Δt</m:t></m:r></m:den></m:f>'
        '</m:oMath></m:oMathPara>')
p = rtl(d.add_paragraph()); p._p.append(parse_xml(omml))
P("v = u + a × t")
P("ملاحظة: عند حل المسائل يجب تحويل جميع الوحدات إلى النظام الدولي قبل التعويض في القوانين.")
P("تنبيه: لا تخلط بين المسافة والإزاحة فهما كميتان مختلفتان.")
P("مثال 1: سيارة تتحرك بسرعة 20 م/ث لمدة 5 ثوان، احسب المسافة التي قطعتها.")
P("الحل: المسافة = السرعة × الزمن = 20 × 5 = 100 م.")
P("أنواع الحركة", style="Heading 2")
for t in ("حركة منتظمة: السرعة ثابتة", "حركة متسارعة: السرعة تتغير بانتظام", "حركة دائرية: المسار دائري"):
    P("• " + t)
P("خطوات حل المسألة", style="Heading 3")
for i, t in enumerate(("اقرأ المسألة جيداً", "حدد المعطيات والمطلوب", "اختر القانون المناسب", "عوّض وأوجد الناتج"), 1):
    P("%d- %s" % (i, t))
P("مقارنة بين الكميات", style="Heading 2")
tb = d.add_table(rows=3, cols=3); tb.style = "Table Grid"
data = [("الكمية", "الرمز", "الوحدة"), ("السرعة", "v", "م/ث"), ("التسارع", "a", "م/ث²")]
for i, row in enumerate(data):
    for j, v in enumerate(row):
        tb.cell(i, j).text = v
img = Image.new("RGB", (600, 260), "#eef3fb"); dr = ImageDraw.Draw(img)
dr.line([(30, 220), (570, 40)], fill="#6b1426", width=5); dr.rectangle([5, 5, 594, 254], outline="#333", width=3)
img.save("/tmp/_s.png"); d.add_picture("/tmp/_s.png", width=Cm(9))
P("الفصل الثاني: القوى وقوانين نيوتن", style="Heading 1")
P("Newton's second law relates force, mass and acceleration: F = ma.")
P("مهم: القوة المحصلة تساوي كتلة الجسم مضروبة في تسارعه.")
P("أسئلة الفصل", style="Heading 2")
P("س1: ما هو تعريف القصور الذاتي؟")
P("ج1: هو ممانعة الجسم لأي تغيير في حالته الحركية.")
P("2) اذكر نص القانون الثاني لنيوتن؟")
P("الجواب: تتناسب القوة المحصلة طردياً مع التسارع.")
for k in range(25):
    P("فقرة تفصيلية رقم %d: تؤكد التجارب العملية أن الأجسام الساكنة تبقى ساكنة والمتحركة تبقى متحركة بسرعة ثابتة ما لم تؤثر عليها قوة خارجية محصلة، وهذا ما يعرف بقانون القصور الذاتي الذي صاغه نيوتن." % (k + 1))
d.save(out)
print("saved", out)
