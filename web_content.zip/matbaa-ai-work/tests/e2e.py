"""End-to-end UI test: upload -> design -> edit -> undo -> export docx/pdf/cover."""
import sys, os, time
from playwright.sync_api import sync_playwright
URL = "http://127.0.0.1:5055/"
SAMPLE = sys.argv[1]; OUT = sys.argv[2]
with sync_playwright() as p:
    b = p.chromium.launch(args=["--no-sandbox"])
    ctx = b.new_context(viewport={"width": 1440, "height": 900}, accept_downloads=True)
    pg = ctx.new_page()
    errs = []
    pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.goto(URL, wait_until="load")
    pg.screenshot(path=OUT + "/1_home.png")
    pg.set_input_files("#file", SAMPLE)
    pg.wait_for_selector("#files .pr i[style*='100%']", timeout=20000)
    pg.fill("#m_title", "الفيزياء"); pg.fill("#m_teacher", "أ.د. محمد علي"); pg.fill("#m_institution", "جامعة بغداد")
    pg.click(".tcard[data-id=modern]")
    pg.screenshot(path=OUT + "/2_uploaded.png", full_page=True)
    pg.click("#start")
    pg.wait_for_selector("#editor:not([hidden])", timeout=60000)
    pg.wait_for_function("document.querySelectorAll('#root .page').length>3", timeout=30000)
    time.sleep(1)
    pg.screenshot(path=OUT + "/3_editor.png")
    n0 = pg.evaluate("document.querySelectorAll('#root .page').length")
    # edit a paragraph
    pg.click("#root .p >> nth=0")
    pg.keyboard.press("End"); pg.keyboard.type(" (تعديل تجريبي)")
    pg.click("#canvas", position={"x": 5, "y": 5})
    pg.wait_for_function("document.querySelector('#saved').textContent.includes('✓')", timeout=10000)
    ok_edit = pg.evaluate("document.body.innerText.includes('تعديل تجريبي')")
    pg.click("#undo"); time.sleep(1.2)
    ok_undo = not pg.evaluate("document.querySelector('#root').innerText.includes('تعديل تجريبي')")
    # redesign page 3
    pg.fill("#pnum", "3"); pg.press("#pnum", "Enter"); pg.click("[data-tab=design]"); pg.click("#redesign"); time.sleep(1.2)
    pg.screenshot(path=OUT + "/4_after_redesign.png")
    for kind in ("docx", "pdf", "cover"):
        pg.click("#expBtn")
        with pg.expect_download(timeout=120000) as d:
            pg.click(f"#expMenu [data-x={kind}]")
        path = os.path.join(OUT, "dl_" + d.value.suggested_filename.replace("/", "_"))
        d.value.save_as(path); print(kind, "->", path, os.path.getsize(path))
    print("pages", n0, "edit", ok_edit, "undo", ok_undo, "errors", errs)
    b.close()
