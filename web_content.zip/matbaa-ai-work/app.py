"""MATBAA AI — web server."""
import json, os, re, secrets, shutil, tempfile, threading, time
from flask import Flask, jsonify, request, send_from_directory, send_file, abort, make_response
from lxml import etree
from matbaa import store, pipeline, themes
from matbaa.parser import inspect_docx, convert_doc_to_docx, ParseError
from matbaa.omml import omml_to_mathml, M
from matbaa.analyzer import _llm_labels, LABEL_AR

BASE = os.path.dirname(os.path.abspath(__file__))
PORT = int(os.environ.get("PORT", 5000))
INTERNAL_KEY = os.environ.get("MATBAA_INTERNAL_KEY") or secrets.token_hex(16)
MAX_MB = int(os.environ.get("MATBAA_MAX_MB", 80))

app = Flask(__name__, static_folder=os.path.join(BASE, "static"), static_url_path="/static")
app.config["MAX_CONTENT_LENGTH"] = MAX_MB * 1024 * 1024
EXPORT_LOCK = threading.Semaphore(int(os.environ.get("MATBAA_EXPORT_WORKERS", 2)))


def get_uid():
    if request.args.get("ik") == INTERNAL_KEY and re.fullmatch(r"[0-9a-f]{32}", request.args.get("uid", "")):
        return request.args["uid"]
    mid = request.cookies.get("mid", "")
    if not re.fullmatch(r"[0-9a-f]{32}", mid):
        mid = secrets.token_hex(16)
        request.new_mid = mid
    return mid


@app.after_request
def after(resp):
    mid = getattr(request, "new_mid", None)
    if mid:
        resp.set_cookie("mid", mid, max_age=3600 * 24 * 365, httponly=True, samesite="Lax",
                        secure=bool(os.environ.get("MATBAA_SECURE_COOKIE")))
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["Referrer-Policy"] = "same-origin"
    if request.path.startswith("/api/"):
        resp.headers["Cache-Control"] = "no-store"
    return resp


@app.errorhandler(413)
def too_big(e):
    return jsonify(error="حجم الملف أكبر من الحد المسموح (%d ميغابايت)" % MAX_MB), 413


@app.route("/")
def index():
    r = make_response(send_from_directory(os.path.join(BASE, "static"), "index.html"))
    get_uid()
    return r


@app.route("/render.html")
def render_page():
    return send_from_directory(os.path.join(BASE, "static"), "render.html")


@app.route("/api/themes")
def api_themes():
    return jsonify(themes.public_themes())


# ------------------------------------------------------------------ uploads
@app.route("/api/uploads", methods=["POST"])
def upload():
    uid = get_uid()
    f = request.files.get("file")
    if not f or not f.filename:
        return jsonify(error="لم يتم اختيار ملف"), 400
    name = os.path.basename(f.filename)
    ext = os.path.splitext(name)[1].lower()
    if ext not in (".docx", ".doc"):
        return jsonify(error="الصيغة غير مدعومة. ارفع ملف Word بصيغة DOC أو DOCX"), 400
    upid = store.new_id()
    ud = store.upload_dir(uid, upid)
    os.makedirs(ud, exist_ok=True)
    stored = "orig" + ext
    path = os.path.join(ud, stored)
    f.save(path)
    size = os.path.getsize(path)
    try:
        if ext == ".doc":
            path = convert_doc_to_docx(path, ud)
            stored = os.path.basename(path)
        info = inspect_docx(path)
    except ParseError as e:
        shutil.rmtree(ud, ignore_errors=True)
        return jsonify(error=str(e)), 400
    except Exception:
        shutil.rmtree(ud, ignore_errors=True)
        return jsonify(error="تعذّر قراءة الملف، تأكد أنه مستند Word سليم"), 400
    meta = {"id": upid, "name": name, "size": size, "stored": stored, **info}
    store.save_json(os.path.join(ud, "meta.json"), meta)
    return jsonify(meta)


@app.route("/api/uploads/<upid>", methods=["DELETE"])
def del_upload(upid):
    uid = get_uid()
    try:
        shutil.rmtree(store.upload_dir(uid, upid), ignore_errors=True)
    except KeyError:
        abort(404)
    return jsonify(ok=True)


# ------------------------------------------------------------------ projects
@app.route("/api/projects", methods=["POST"])
def create_projects():
    uid = get_uid()
    d = request.get_json(force=True, silent=True) or {}
    ups = [u for u in d.get("uploads", []) if store.safe_id(u)]
    if not ups:
        return jsonify(error="لا توجد ملفات"), 400
    theme = d.get("theme") if d.get("theme") in themes.THEMES else "iraqi"
    meta = d.get("meta") or {}
    infos = {}
    for u in ups:
        try:
            with open(os.path.join(store.upload_dir(uid, u), "meta.json"), encoding="utf-8") as fh:
                infos[u] = json.load(fh)
        except Exception:
            return jsonify(error="ملف مرفوع غير موجود"), 404
    groups = [ups] if (d.get("merge") or len(ups) == 1) else [[u] for u in ups]
    out = []
    for g in groups:
        name = os.path.splitext(infos[g[0]]["name"])[0] if len(g) == 1 else "ملزمة مدمجة (%d ملفات)" % len(g)
        pid = pipeline.create_project(uid, g, theme, meta, name)
        threading.Thread(target=pipeline.run, args=(uid, pid, g), daemon=True).start()
        out.append({"id": pid, "name": name})
    return jsonify(projects=out)


@app.route("/api/projects")
def list_projects():
    return jsonify(projects=store.list_projects(get_uid()))


@app.route("/api/projects/<pid>/status")
def status(pid):
    uid = get_uid()
    try:
        st = store.STATUS.get(pid)
        if not st:
            st = store.load_project(uid, pid).get("status", {})
        else:
            store.load_project(uid, pid)  # ownership check
    except KeyError:
        abort(404)
    return jsonify(st)


def sanitize_runs(runs):
    out = []
    for r in runs if isinstance(runs, list) else []:
        if not isinstance(r, dict):
            continue
        if "m" in r:
            try:
                parser = etree.XMLParser(resolve_entities=False, no_network=True, huge_tree=False)
                e = etree.fromstring(str(r["m"]).encode(), parser)
                if e.tag not in ("{%s}oMath" % M, "{%s}oMathPara" % M):
                    continue
                out.append({"m": r["m"], "mm": omml_to_mathml(e, display=bool(r.get("disp"))), "disp": r.get("disp", 0)})
            except Exception:
                pass
            continue
        t = str(r.get("t", ""))
        c = {"t": t}
        for k in ("b", "i", "u", "k", "s"):
            if r.get(k):
                c[k] = 1
        if r.get("v") in ("sup", "sub"):
            c["v"] = r["v"]
        out.append(c)
    return out


def sanitize_block(b):
    if not isinstance(b, dict) or not re.fullmatch(r"[\w\-]{1,20}", str(b.get("id", ""))):
        return None
    t = b.get("type")
    allowed = {"h1", "h2", "h3", "p", "li", "definition", "law", "example", "note", "warning", "important", "question", "answer",
               "equation", "label", "table", "image"}
    if t not in allowed:
        return None
    nb = {"id": b["id"], "type": t}
    if t == "table":
        rows = []
        for row in b.get("rows", []):
            cells = []
            for c in row:
                cells.append({"paras": [sanitize_runs(p) for p in c.get("paras", [])], "cs": int(c.get("cs", 1)), "rs": int(c.get("rs", 1)),
                              **({"imgs": [{"file": os.path.basename(str(i.get("file", ""))), "w": i.get("w"), "h": i.get("h")} for i in c["imgs"]]} if c.get("imgs") else {})})
            rows.append(cells)
        nb["rows"] = rows
    elif t == "image":
        nb.update(file=os.path.basename(str(b.get("file", ""))), w=b.get("w"), h=b.get("h"))
    else:
        nb["runs"] = sanitize_runs(b.get("runs", []))
    for k in ("label", "kind"):
        if isinstance(b.get(k), str):
            nb[k] = b[k][:80]
    if isinstance(b.get("variant"), int):
        nb["variant"] = b["variant"] % 3
    if isinstance(b.get("list"), dict):
        nb["list"] = {"marker": str(b["list"].get("marker", "•"))[:6], "level": int(b["list"].get("level", 0)) % 5}
    if b.get("pb"):
        nb["pb"] = 1
    return nb


@app.route("/api/projects/<pid>", methods=["GET", "PUT", "DELETE"])
def project(pid):
    uid = get_uid()
    try:
        proj = store.load_project(uid, pid)
    except KeyError:
        abort(404)
    if request.method == "GET":
        proj["status"] = store.STATUS.get(pid) or proj.get("status")
        return jsonify(proj)
    if request.method == "DELETE":
        store.delete_project(uid, pid)
        return jsonify(ok=True)
    d = request.get_json(force=True, silent=True) or {}
    if "blocks" in d:
        blocks = [x for x in (sanitize_block(b) for b in d["blocks"]) if x]
        proj["blocks"] = blocks
        proj.setdefault("stats", {})["blocks"] = len(blocks)
    if isinstance(d.get("meta"), dict):
        for k in proj["meta"].keys() | {"title", "subtitle", "teacher", "institution", "grade", "year", "edition", "footer", "toc"}:
            if k in d["meta"]:
                v = d["meta"][k]
                proj["meta"][k] = bool(v) if k == "toc" else str(v)[:200]
    if d.get("theme") in themes.THEMES:
        proj["theme"] = d["theme"]
    if isinstance(d.get("overrides"), dict):
        o = {}
        for k in ("primary", "accent"):
            if re.fullmatch(r"#[0-9a-fA-F]{6}", str(d["overrides"].get(k, ""))):
                o[k] = d["overrides"][k]
        for k in ("font", "headFont"):
            if d["overrides"].get(k) in themes.FONTS:
                o[k] = d["overrides"][k]
        if d["overrides"].get("size"):
            try:
                o["size"] = max(9, min(20, float(d["overrides"]["size"])))
            except Exception:
                pass
        proj["overrides"] = o
    if isinstance(d.get("name"), str):
        proj["name"] = d["name"][:120]
    store.save_project(uid, proj)
    return jsonify(ok=True, updated=proj["updated"])


@app.route("/api/projects/<pid>/media/<path:name>")
def media(pid, name):
    uid = get_uid()
    try:
        d = os.path.join(store.project_dir(uid, pid), "media")
    except KeyError:
        abort(404)
    return send_from_directory(d, os.path.basename(name))


@app.route("/api/projects/<pid>/ai/relabel", methods=["POST"])
def relabel(pid):
    """Re-run the (optional) LLM classifier on selected blocks. Without an API key nothing changes."""
    uid = get_uid()
    try:
        proj = store.load_project(uid, pid)
    except KeyError:
        abort(404)
    ids = set((request.get_json(force=True, silent=True) or {}).get("ids", []))
    part = [b for b in proj["blocks"] if b["id"] in ids]
    res = {}
    if os.environ.get("ANTHROPIC_API_KEY"):
        for i, typ in _llm_labels(part).items():
            res[part[i]["id"]] = typ
    return jsonify(types=res, llm=bool(os.environ.get("ANTHROPIC_API_KEY")))


# ------------------------------------------------------------------ export
def _export_path(uid, pid, ext):
    d = os.path.join(store.project_dir(uid, pid), "exports")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "out.%s" % ext)


def _safe_name(proj, ext):
    n = re.sub(r'[\\/:*?"<>|]+', "_", (proj.get("meta", {}).get("title") or proj.get("name") or "matbaa")).strip()[:60] or "matbaa"
    return "%s.%s" % (n, ext)


@app.route("/api/projects/<pid>/export/<kind>")
def export(pid, kind):
    uid = get_uid()
    if kind not in ("docx", "pdf", "cover"):
        abort(404)
    try:
        proj = store.load_project(uid, pid)
    except KeyError:
        abort(404)
    if (store.STATUS.get(pid) or proj.get("status", {})).get("stage") != "done":
        return jsonify(error="المشروع لم يكتمل بعد"), 409
    ext = "png" if kind == "cover" else kind
    out = _export_path(uid, pid, ext)
    with EXPORT_LOCK:
        try:
            if kind == "docx":
                from matbaa.docx_export import export_docx
                export_docx(proj, os.path.join(store.project_dir(uid, pid), "media"), out)
            else:
                from matbaa import pdf_export
                base = "http://127.0.0.1:%d" % PORT
                (pdf_export.render_pdf if kind == "pdf" else pdf_export.render_cover)(base, uid, pid, INTERNAL_KEY, out)
        except Exception as e:
            app.logger.exception("export failed")
            return jsonify(error="فشل التصدير: %s" % str(e)[:200]), 500
    mt = {"docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "pdf": "application/pdf", "png": "image/png"}[ext]
    return send_file(out, mimetype=mt, as_attachment=True, download_name=_safe_name(proj, "png" if kind == "cover" else ext) if kind != "cover" else _safe_name(proj, "png").replace(".png", "-cover.png"))


if __name__ == "__main__":
    store.purge_old(int(os.environ.get("MATBAA_RETENTION_DAYS", 30)))
    app.run(host=os.environ.get("HOST", "0.0.0.0"), port=PORT, threaded=True)
