"""Download the Arabic fonts used by the designs into static/fonts (run once on the server, needs internet).
Without them the server-side PDF falls back to system Arabic fonts; the browser preview loads them from Google Fonts."""
import os, urllib.request
BASE = "https://github.com/google/fonts/raw/main/ofl/"
FILES = {
 "Amiri-Regular.ttf": "amiri/Amiri-Regular.ttf", "Amiri-Bold.ttf": "amiri/Amiri-Bold.ttf",
 "Cairo.ttf": "cairo/Cairo%5Bslnt%2Cwght%5D.ttf", "Tajawal-Regular.ttf": "tajawal/Tajawal-Regular.ttf",
 "Tajawal-Bold.ttf": "tajawal/Tajawal-Bold.ttf", "NotoNaskhArabic.ttf": "notonaskharabic/NotoNaskhArabic%5Bwght%5D.ttf",
 "ReemKufi.ttf": "reemkufi/ReemKufi%5Bwght%5D.ttf",
}
dst = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "static", "fonts")
os.makedirs(dst, exist_ok=True)
for name, path in FILES.items():
    try:
        urllib.request.urlretrieve(BASE + path, os.path.join(dst, name)); print("ok", name)
    except Exception as e:
        print("failed", name, e)
