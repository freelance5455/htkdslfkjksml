# MATBAA AI — من ملف عادي إلى ملزمة استثنائية

موقع حقيقي (Flask) يحوّل ملفات Word (DOC/DOCX) إلى ملازم تعليمية بستة تصاميم، ويصدّر DOCX وPDF وصورة الغلاف.

## التشغيل
```
pip install -r requirements.txt
python scripts/fetch_fonts.py      # خطوط عربية للـPDF (مرة واحدة، تحتاج إنترنت)
python app.py                      # http://localhost:5000
```
المتطلبات الاختيارية: LibreOffice (لملفات DOC وأرقام الفهرس في DOCX)، poppler-utils (pdftotext). أو استخدم `Dockerfile`.

## المعمارية
- `matbaa/parser.py` قراءة DOCX: نصوص بتنسيقها، جداول (دمج خلايا)، صور، معادلات OMML، قوائم.
- `matbaa/analyzer.py` الذكاء: تصنيف العناوين/التعاريف/القوانين/الأمثلة/الملاحظات/التنبيهات/الأسئلة/الأجوبة/النقاط المهمة دون تغيير أي نص. إن عُرّف `ANTHROPIC_API_KEY` يراجع Claude التصنيف (يعيد تصنيفات فقط، فلا يمكنه تعديل النص).
- `matbaa/pipeline.py` معالجة على مراحل في الخلفية (قراءة ← تحليل ← جاهز) مع شريط تقدم، وتقسيم التحليل إلى دفعات للملفات الكبيرة.
- `static/js/booklet.js` محرك الإخراج والترقيم (A4) المشترك بين المعاينة والطباعة وPDF.
- `matbaa/docx_export.py` DOCX حقيقي RTL: غلاف، فهرس بأرقام صفحات فعلية، رأس/تذييل، إطارات، جداول، صور، معادلات.
- `matbaa/pdf_export.py` PDF وصورة الغلاف عبر Chromium بنفس إخراج المعاينة.

## الخصوصية
كل متصفح يحصل على معرّف عشوائي (كوكي) وتُخزَّن ملفاته في مجلد معزول؛ لا مشاركة بين المستخدمين، حذف المشروع يمحو ملفاته، وتُمسح المشاريع الأقدم من `MATBAA_RETENTION_DAYS` (30). متغيرات: `MATBAA_DATA`, `MATBAA_MAX_MB`, `MATBAA_SECURE_COOKIE=1` خلف HTTPS.

## اختبار
`python tests/make_sample.py sample.docx && python tests/e2e.py sample.docx outdir` (الخادم يعمل على 5055).
