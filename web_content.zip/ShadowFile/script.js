// =====================================
// SHADOWFILE V1
// File Organizer + Quick Hide + Vault UI
// =====================================

const $ = id => document.getElementById(id);

let folders = JSON.parse(localStorage.getItem("sf_folders") || "null") || [
    { name: "Anime Clips", category: "Videos" },
    { name: "Finished Edits", category: "Videos" },
    { name: "Raw Footage", category: "Videos" },
    { name: "Music & SFX", category: "Audio" },
    { name: "Gold Motion XML", category: "Presets" },
    { name: "Thumbnails & PFPs", category: "Images" },
    { name: "Screenshots", category: "Images" }
];

let files = JSON.parse(localStorage.getItem("sf_files") || "[]");
let hiddenFiles = JSON.parse(localStorage.getItem("sf_hidden") || "[]");
let vaultFiles = JSON.parse(localStorage.getItem("sf_vault") || "[]");
let vaultPassword = localStorage.getItem("sf_vault_password") || "";
let currentPage = "home";
let currentCategory = "All";

// Save app data on this device.
function saveData() {
    localStorage.setItem("sf_folders", JSON.stringify(folders));
    localStorage.setItem("sf_files", JSON.stringify(files));
    localStorage.setItem("sf_hidden", JSON.stringify(hiddenFiles));
    localStorage.setItem("sf_vault", JSON.stringify(vaultFiles));

    if (vaultPassword) {
        localStorage.setItem("sf_vault_password", vaultPassword);
    }
}

// Show a message.
function message(text) {
    let old = $("sfMessage");
    if (old) old.remove();

    let box = document.createElement("div");
    box.id = "sfMessage";
    box.textContent = text;

    box.style.cssText = `
        position:fixed;
        bottom:100px;
        left:50%;
        transform:translateX(-50%);
        background:#173454;
        color:white;
        padding:13px 18px;
        border:1px solid #24baff;
        border-radius:12px;
        z-index:9999;
        width:max-content;
        max-width:90%;
        font-size:12px;
    `;

    document.body.appendChild(box);
    setTimeout(() => box.remove(), 2600);
}

// Escape text before displaying file names.
function safeText(value) {
    return String(value).replace(/[&<>"']/g, char => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[char]);
}

// Switch between app sections.
function showPage(page) {
    currentPage = page;

    document.querySelectorAll(".bottom-nav button").forEach(button => {
        button.classList.toggle("selected", button.dataset.page === page);
    });

    let main = $("dynamicContent");

    if (page === "home") {
        main.innerHTML = "";
        document.querySelector(".hero").style.display = "";
        document.querySelector(".search").style.display = "";
        document.querySelectorAll("main > h3, .grid, .tools").forEach(el => {
            el.style.display = "";
        });
        return;
    }

    document.querySelector(".hero").style.display = "none";
    document.querySelector(".search").style.display = "none";
    document.querySelectorAll("main > h3, .grid, .tools").forEach(el => {
        el.style.display = "none";
    });

    if (page === "files") renderFiles();
    if (page === "hide") renderHide();
    if (page === "vault") renderVault();
    if (page === "settings") renderSettings();

    window.scrollTo(0, 0);
}

// Connect navigation buttons.
document.querySelectorAll("[data-page]").forEach(button => {
    button.addEventListener("click", () => showPage(button.dataset.page));
});

$("settingsBtn").addEventListener("click", () => showPage("settings"));

// Identify common file types.
function getCategory(fileName) {
    let name = fileName.toLowerCase();

    if (/\.(mp4|mkv|mov|avi|webm)$/i.test(name)) return "Videos";
    if (/\.(jpg|jpeg|png|gif|webp|bmp)$/i.test(name)) return "Images";
    if (/\.(mp3|wav|m4a|ogg|flac|aac)$/i.test(name)) return "Audio";
    if (/\.(xml|am|preset)$/i.test(name)) return "Presets";
    if (/\.(pdf|txt|doc|docx|rtf|xls|xlsx)$/i.test(name)) return "Documents";
    if (/\.apk$/i.test(name)) return "APKs";

    return "Other";
}

// Pick files from the device.
// This lists chosen files; it does not move them.
function chooseFiles(callback) {
    let input = document.createElement("input");
    input.type = "file";
    input.multiple = true;
    input.accept = "*/*";

    input.onchange = () => {
        let selected = Array.from(input.files || []);

        if (!selected.length) return;

        selected.forEach(file => {
            callback({
                id: Date.now() + Math.random(),
                name: file.name,
                category: getCategory(file.name),
                size: file.size
            });
        });

        saveData();
        message("Added to your ShadowFile list.");
        if (currentPage === "files") renderFiles();
        if (currentPage === "hide") renderHide();
        if (currentPage === "vault") renderVault();
    };

    input.click();
}

// FILE ORGANIZER
function renderFiles() {
    let main = $("dynamicContent");

    main.innerHTML = `
        <h2>📁 File Organizer</h2>
        <p style="color:#899dbb;font-size:12px;margin:10px 0 18px">
            Organize your editing files in one place.
        </p>

        <button id="addFolder">＋ Create Folder</button>
        <button id="importFiles">＋ Import Files</button>

        <input id="folderSearch" placeholder="Search folders and files...">

        <h3>Your Folders (${folders.length})</h3>
        <div id="folderList"></div>

        <h3>Imported Files (${files.length})</h3>
        <div id="fileList"></div>
    `;

    $("addFolder").onclick = createFolder;
    $("importFiles").onclick = () => chooseFiles(file => files.push(file));
    $("folderSearch").oninput = displayItems;

    displayItems();
}

function displayItems() {
    let query = ($("folderSearch")?.value || "").toLowerCase();

    let folderList = $("folderList");
    let fileList = $("fileList");

    if (!folderList || !fileList) return;

    let matchingFolders = folders.filter(folder =>
        folder.name.toLowerCase().includes(query)
    );

    folderList.innerHTML = matchingFolders.map((folder, index) => `
        <div class="item">
            📁 <b>${safeText(folder.name)}</b>
            <small style="color:#899dbb"> · ${safeText(folder.category)}</small>
            <br>
            <button onclick="renameFolder(${folders.indexOf(folder)})">Rename</button>
            <button onclick="deleteFolder(${folders.indexOf(folder)})">Delete</button>
        </div>
    `).join("") || "<p class='item'>No matching folders.</p>";

    let matchingFiles = files.filter(file =>
        (currentCategory === "All" || file.category === currentCategory) &&
        file.name.toLowerCase().includes(query)
    );

    fileList.innerHTML = matchingFiles.map(file => `
        <div class="item">
            📄 ${safeText(file.name)}
            <br>
            <small style="color:#899dbb">${safeText(file.category)}</small>
            <br>
            <button onclick="addToHide(${file.id})">Quick Hide</button>
            <button onclick="addToVault(${file.id})">Vault List</button>
            <button onclick="deleteFile(${file.id})">Remove</button>
        </div>
    `).join("") || "<p class='item'>No matching files.</p>";
}

function createFolder() {
    let name = prompt("Enter a folder name:");

    if (!name || !name.trim()) return;

    let category = prompt(
        "Category: Videos, Images, Audio, Documents, Presets or Other",
        "Other"
    );

    let allowed = ["Videos", "Images", "Audio", "Documents", "Presets", "Other", "APKs"];

    if (!allowed.includes(category)) category = "Other";

    folders.push({
        name: name.trim(),
        category: category
    });

    saveData();
    renderFiles();
    message("Folder created!");
}

function renameFolder(index) {
    let folder = folders[index];
    if (!folder) return;

    let name = prompt("New folder name:", folder.name);

    if (!name || !name.trim()) return;

    folder.name = name.trim();
    saveData();
    renderFiles();
}

function deleteFolder(index) {
    if (!confirm("Delete this folder from ShadowFile?")) return;

    folders.splice(index, 1);
    saveData();
    renderFiles();
}

function deleteFile(id) {
    if (!confirm("Remove this file from ShadowFile's list?")) return;

    files = files.filter(file => file.id !== id);
    hiddenFiles = hiddenFiles.filter(file => file.id !== id);
    vaultFiles = vaultFiles.filter(file => file.id !== id);

    saveData();
    renderFiles();
}

// QUICK HIDE
function addToHide(id) {
    let file = files.find(item => item.id === id);

    if (!file) return;

    if (!hiddenFiles.some(item => item.id === id)) {
        hiddenFiles.push(file);
    }

    saveData();
    message("Added to Quick Hide list.");
}

function renderHide() {
    let main = $("dynamicContent");

    main.innerHTML = `
        <h2>🙈 Quick Hide</h2>
        <p style="color:#899dbb;font-size:12px;margin:12px 0">
            Keep a list of files you want to separate from your regular Gallery.
        </p>

        <button id="hideImport">＋ Select Files</button>

        <div class="item" style="margin-top:18px">
            ⚠️ This version does not actually hide files from Android Gallery.
            Native Android support is required for that.
        </div>

        <h3>Quick Hide List</h3>
        <div id="hideList"></div>
    `;

    $("hideImport").onclick = () => chooseFiles(file => hiddenFiles.push(file));

    $("hideList").innerHTML = hiddenFiles.map(file => `
        <div class="item">
            📄 ${safeText(file.name)}
            <br>
            <button onclick="removeFromHide(${file.id})">Remove from list</button>
        </div>
    `).join("") || "<p class='item'>No files in Quick Hide yet.</p>";
}

function removeFromHide(id) {
    hiddenFiles = hiddenFiles.filter(file => file.id !== id);
    saveData();
    renderHide();
}

// PRIVATE VAULT INTERFACE
function addToVault(id) {
    let file = files.find(item => item.id === id);

    if (!file) return;

    if (!vaultFiles.some(item => item.id === id)) {
        vaultFiles.push(file);
    }

    saveData();
    message("Added to Vault list. File not encrypted.");
}

function renderVault() {
    let main = $("dynamicContent");

    main.innerHTML = `
        <h2>🔐 Private Vault</h2>
        <p style="color:#899dbb;font-size:12px;margin:12px 0">
            A password-locked demo interface.
        </p>

        <div class="item">
            ⚠️ Important: this HTML prototype does not encrypt files.
            Do not store sensitive files here.
        </div>

        <div id="vaultLockArea"></div>
        <div id="vaultItems" style="display:none"></div>
    `;

    if (!vaultPassword) {
        $("vaultLockArea").innerHTML = `
            <input id="vaultPassInput" type="password" placeholder="Create password (4+ characters)">
            <button id="createVault">Create Vault</button>
        `;

        $("createVault").onclick = () => {
            let password = $("vaultPassInput").value;

            if (password.length < 4) {
                message("Use at least 4 characters.");
                return;
            }

            vaultPassword = password;
            saveData();
            message("Vault created. Remember, files are not encrypted.");
            renderVault();
        };
    } else {
        $("vaultLockArea").innerHTML = `
            <input id="vaultPassInput" type="password" placeholder="Enter vault password">
            <button id="unlockVault">Unlock</button>
        `;

        $("unlockVault").onclick = () => {
            if ($("vaultPassInput").value !== vaultPassword) {
                message("Incorrect password.");
                return;
            }

            $("vaultLockArea").innerHTML = "";
            $("vaultItems").style.display = "block";

            $("vaultItems").innerHTML = `
                <button id="vaultImport">＋ Select Files</button>
                <h3>Vault List</h3>
                <div id="vaultList"></div>
            `;

            $("vaultImport").onclick = () =>
                chooseFiles(file => vaultFiles.push(file));

            $("vaultList").innerHTML = vaultFiles.map(file => `
                <div class="item">
                    📄 ${safeText(file.name)}
                    <br>
                    <button onclick="removeFromVault(${file.id})">Remove</button>
                </div>
            `).join("") || "<p class='item'>Your vault list is empty.</p>";
        };
    }
}

function removeFromVault(id) {
    vaultFiles = vaultFiles.filter(file => file.id !== id);
    saveData();
    renderVault();
}

// SETTINGS
function renderSettings() {
    $("dynamicContent").innerHTML = `
        <h2>⚙ Settings</h2>

        <div class="item">
            <b>Appearance</b>
            <p style="color:#899dbb;margin:10px 0">
                Choose your accent color.
            </p>

            <button onclick="setTheme('bluepurple')">Blue + Purple</button>
            <button onclick="setTheme('blue')">Blue</button>
            <button onclick="setTheme('purple')">Purple</button>
        </div>

        <div class="item">
            <b>Export Lists</b>
            <p style="color:#899dbb;margin:10px 0">
                Save your folders and file lists as a JSON backup.
            </p>
            <button id="exportBackup">Export Backup</button>
        </div>

        <div class="item">
            <b>Reset App Lists</b>
            <p style="color:#899dbb;margin:10px 0">
                Restore the starter folders and clear saved lists.
            </p>
            <button id="resetApp">Reset Data</button>
        </div>

        <div class="item">
            <b>ShadowFile V1</b>
            <p style="color:#899dbb;margin-top:8px">
                Free · Offline-ready · No ads
            </p>
        </div>
    `;

    $("exportBackup").onclick = exportBackup;

    $("resetApp").onclick = () => {
        if (!confirm("Reset all ShadowFile lists?")) return;

        localStorage.removeItem("sf_folders");
        localStorage.removeItem("sf_files");
        localStorage.removeItem("sf_hidden");
        localStorage.removeItem("sf_vault");
        localStorage.removeItem("sf_vault_password");

        location.reload();
    };
}

function setTheme(theme) {
    let colors = {
        bluepurple: ["#24baff", "#925cff"],
        blue: ["#24baff", "#247aff"],
        purple: ["#925cff", "#d05cff"]
    };

    document.documentElement.style.setProperty("--blue", colors[theme][0]);
    document.documentElement.style.setProperty("--purple", colors[theme][1]);
    document.documentElement.style.setProperty(
        "--gradient",
        `linear-gradient(120deg, ${colors[theme][0]}, ${colors[theme][1]})`
    );

    localStorage.setItem("sf_theme", theme);
    message("Theme changed!");
}

function exportBackup() {
    let backup = {
        folders,
        files,
        hiddenFiles,
        vaultFiles
    };

    let blob = new Blob(
        [JSON.stringify(backup, null, 2)],
        { type: "application/json" }
    );

    let link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "ShadowFile-Backup.json";
    link.click();

    URL.revokeObjectURL(link.href);
    message("Backup downloaded.");
}

// Global search
$("searchInput").addEventListener("input", event => {
    let query = event.target.value.toLowerCase();

    if (!query) {
        if (currentPage === "home") {
            $("dynamicContent").innerHTML = "";
        }
        return;
    }

    showPage("files");

    $("folderSearch").value = query;
    displayItems();
});

// Quick category shortcuts
document.querySelectorAll(".category").forEach(button => {
    button.addEventListener("click", () => {
        currentCategory = button.dataset.category;
        showPage("files");
        displayItems();
    });
});

// Restore saved theme
(function restoreTheme() {
    let theme = localStorage.getItem("sf_theme");

    if (theme && theme !== "bluepurple") {
        setTheme(theme);
    }
})();

// Start app
showPage("home");