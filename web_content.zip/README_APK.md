# ROCKY RUMBLE — APK Converter Package

This ZIP is prepared specifically for HTML-to-APK/WebView converters.

## Upload
Upload this entire ZIP. The converter's website/root should point to `index.html`.

## Recommended settings
- App name: ROCKY RUMBLE
- Orientation: Portrait
- Fullscreen / immersive: ON
- Internet access: OFF for this offline demo
- Icon: `icon-512.png` or `icon-1024.png`
- Package/application ID: `com.rockyrumble.game`

## Included
- `index.html` — playable game
- `assets/rockycat.jpg` and `assets/rockycat.png`
- Android-friendly icons in multiple sizes
- `manifest.webmanifest`
- APK settings guide

This package does not contain a signed APK; the converter performs the APK packaging/signing step.
