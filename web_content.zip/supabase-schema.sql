create extension if not exists pgcrypto;

create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 email text not null,
 full_name text not null default '',
 role text not null default 'agent' check (role in ('agent','admin')),
 disabled boolean not null default false,
 created_at timestamptz not null default now()
);

create table if not exists public.items (
 id uuid primary key default gen_random_uuid(),
 owner_id uuid not null references public.profiles(id) on delete cascade,
 name text not null,
 number text,
 float_target numeric not null default 0,
 location text,
 personal_number text,
 details text,
 deleted boolean not null default false,
 daily_progress jsonb not null default '[]'::jsonb,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);

create or replace function public.is_admin() returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin' and p.disabled=false); $$;

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$ begin insert into public.profiles(id,email,full_name) values(new.id,new.email,coalesce(new.raw_user_meta_data->>'full_name','')); return new; end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.items enable row level security;

drop policy if exists profile_self on public.profiles;
drop policy if exists profile_admin_select on public.profiles;
create policy profile_self on public.profiles for select using (id=auth.uid());
create policy profile_admin_select on public.profiles for select using (public.is_admin());

drop policy if exists items_select on public.items;
drop policy if exists items_insert on public.items;
drop policy if exists items_update on public.items;
drop policy if exists items_delete on public.items;
create policy items_select on public.items for select using (owner_id=auth.uid() or public.is_admin());
create policy items_insert on public.items for insert with check (owner_id=auth.uid() or public.is_admin());
create policy items_update on public.items for update using (owner_id=auth.uid() or public.is_admin()) with check (owner_id=auth.uid() or public.is_admin());
create policy items_delete on public.items for delete using (public.is_admin());

-- After creating your first auth user, promote it: 
-- update public.profiles set role='admin' where email='admin@example.com';


-- Prevent agents from deleting or transferring their items by changing protected fields.
create or replace function public.protect_agent_item_changes() returns trigger language plpgsql security definer set search_path=public as $$
begin
  if not public.is_admin() then
    if new.owner_id <> old.owner_id then raise exception 'Agents cannot transfer items'; end if;
    if new.deleted <> old.deleted then raise exception 'Agents cannot delete or restore items'; end if;
  end if;
  return new;
end; $$;
drop trigger if exists protect_agent_item_changes on public.items;
create trigger protect_agent_item_changes before update on public.items for each row execute procedure public.protect_agent_item_changes();


-- Delete exactly one stored visit from an item
-- Run this entire script once in Supabase SQL Editor.

create or replace function public.delete_visit(
  p_item_id uuid,
  p_day date,
  p_visit_id text
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_item public.items%rowtype;
  v_entry jsonb;
  v_filtered jsonb;
  v_new_progress jsonb := '[]'::jsonb;
  v_day_found boolean := false;
  v_visit_found boolean := false;
  v_legacy_given numeric := 0;
  v_legacy_visits integer := 0;
  v_legacy_notes text := '';
  v_given numeric := 0;
  v_count integer := 0;
  v_notes text := '';
  v_visit_notes text := '';
  v_visit_given numeric := 0;
  v_item_id uuid := p_item_id;
begin
  if auth.uid() is null then
    raise exception 'Not authenticated';
  end if;

  select * into v_item
  from public.items
  where id = p_item_id;

  if not found then
    raise exception 'Item not found';
  end if;

  if v_item.owner_id <> auth.uid() and not public.is_admin() then
    raise exception 'You are not allowed to change this item';
  end if;

  for v_entry in
    select value
    from jsonb_array_elements(coalesce(v_item.daily_progress, '[]'::jsonb))
  loop
    if v_entry->>'date' = p_day::text then
      v_day_found := true;

      if jsonb_typeof(v_entry->'visits') <> 'array' then
        raise exception 'This daily record has no individual visit data';
      end if;

      select
        coalesce(jsonb_agg(v), '[]'::jsonb)
      into v_filtered
      from jsonb_array_elements(v_entry->'visits') as t(v)
      where coalesce(v->>'id','') <> p_visit_id;

      if jsonb_array_length(v_filtered) = jsonb_array_length(v_entry->'visits') then
        raise exception 'The selected visit was not found';
      end if;

      v_visit_found := true;
      v_legacy_given := coalesce(nullif(v_entry->>'legacy_given','')::numeric, 0);
      v_legacy_visits := coalesce(nullif(v_entry->>'legacy_visits','')::integer, 0);
      v_legacy_notes := coalesce(v_entry->>'legacy_notes','');

      select coalesce(sum(coalesce(nullif(v->>'given','')::numeric,0)),0)
      into v_given
      from jsonb_array_elements(v_filtered) as t(v);
      v_given := v_given + v_legacy_given;

      v_count := v_legacy_visits + jsonb_array_length(v_filtered);

      select coalesce(string_agg(note,' | '),'')
      into v_visit_notes
      from (
        select nullif(v->>'notes','') as note
        from jsonb_array_elements(v_filtered) as t(v)
        where nullif(v->>'notes','') is not null
      ) q;

      v_notes := concat_ws(' | ',
        nullif(v_legacy_notes,''),
        nullif(v_visit_notes,'')
      );

      if v_count > 0 or v_given <> 0 or v_notes <> '' then
        v_entry := jsonb_set(v_entry, '{visits}', v_filtered, true);
        v_entry := jsonb_set(v_entry, '{given}', to_jsonb(v_given), true);
        v_entry := jsonb_set(v_entry, '{visits_count}', to_jsonb(v_count), true);
        v_entry := jsonb_set(v_entry, '{visited}', to_jsonb(v_count > 0), true);
        v_entry := jsonb_set(v_entry, '{notes}', to_jsonb(v_notes), true);
        v_new_progress := v_new_progress || jsonb_build_array(v_entry);
      end if;
    else
      v_new_progress := v_new_progress || jsonb_build_array(v_entry);
    end if;
  end loop;

  if not v_day_found then
    raise exception 'The selected day was not found';
  end if;
  if not v_visit_found then
    raise exception 'The selected visit was not found';
  end if;

  update public.items
  set daily_progress = v_new_progress,
      updated_at = now()
  where id = p_item_id;

  return jsonb_build_object('ok', true, 'item_id', v_item_id, 'date', p_day, 'visit_id', p_visit_id);
end;
$$;

revoke all on function public.delete_visit(uuid, date, text) from public;
grant execute on function public.delete_visit(uuid, date, text) to authenticated;
