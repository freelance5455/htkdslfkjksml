-- الجولانيGZ: شغّل هذا الملف في Supabase > SQL Editor بعد تعديل OWNER_EMAIL_PLACEHOLDER
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null check (username ~ '^[A-Za-z0-9_]{3,24}$'),
  display_name text not null check (char_length(display_name) between 1 and 40),
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 80),
  caption text not null default '' check (char_length(caption) <= 400),
  video_path text not null,
  template_path text not null,
  template_file_name text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.follows (
  follower_id uuid not null references auth.users(id) on delete cascade,
  following_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (follower_id, following_id),
  check (follower_id <> following_id)
);

create table if not exists public.post_likes (
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (post_id, user_id)
);

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 300),
  created_at timestamptz not null default now()
);

create table if not exists public.templates (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text not null default '',
  category text not null default 'neon' check (category in ('neon','anime','circular')),
  kind text not null default 'free' check (kind in ('free','paid')),
  preview_path text,
  file_path text not null,
  file_name text not null,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.follows enable row level security;
alter table public.post_likes enable row level security;
alter table public.comments enable row level security;
alter table public.templates enable row level security;

drop policy if exists "profiles readable" on public.profiles;
create policy "profiles readable" on public.profiles for select using (true);
drop policy if exists "profile insert self" on public.profiles;
create policy "profile insert self" on public.profiles for insert to authenticated with check (auth.uid() = id);
drop policy if exists "profile update self" on public.profiles;
create policy "profile update self" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

drop policy if exists "posts readable" on public.posts;
create policy "posts readable" on public.posts for select using (true);
drop policy if exists "post insert self" on public.posts;
create policy "post insert self" on public.posts for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "post delete self or owner" on public.posts;
create policy "post delete self or owner" on public.posts for delete to authenticated using (auth.uid() = user_id or lower(coalesce(auth.jwt()->>'email','')) = lower('OWNER_EMAIL_PLACEHOLDER'));

drop policy if exists "follows readable" on public.follows;
create policy "follows readable" on public.follows for select using (true);
drop policy if exists "follow as self" on public.follows;
create policy "follow as self" on public.follows for insert to authenticated with check (auth.uid() = follower_id);
drop policy if exists "unfollow as self" on public.follows;
create policy "unfollow as self" on public.follows for delete to authenticated using (auth.uid() = follower_id);

drop policy if exists "likes readable" on public.post_likes;
create policy "likes readable" on public.post_likes for select using (true);
drop policy if exists "like as self" on public.post_likes;
create policy "like as self" on public.post_likes for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "unlike as self" on public.post_likes;
create policy "unlike as self" on public.post_likes for delete to authenticated using (auth.uid() = user_id);

drop policy if exists "comments readable" on public.comments;
create policy "comments readable" on public.comments for select using (true);
drop policy if exists "comment as self" on public.comments;
create policy "comment as self" on public.comments for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "comment delete self or owner" on public.comments;
create policy "comment delete self or owner" on public.comments for delete to authenticated using (auth.uid() = user_id or lower(coalesce(auth.jwt()->>'email','')) = lower('OWNER_EMAIL_PLACEHOLDER'));

drop policy if exists "templates readable" on public.templates;
create policy "templates readable" on public.templates for select using (true);
drop policy if exists "templates owner insert" on public.templates;
create policy "templates owner insert" on public.templates for insert to authenticated with check (lower(coalesce(auth.jwt()->>'email','')) = lower('OWNER_EMAIL_PLACEHOLDER'));
drop policy if exists "templates owner update" on public.templates;
create policy "templates owner update" on public.templates for update to authenticated using (lower(coalesce(auth.jwt()->>'email','')) = lower('OWNER_EMAIL_PLACEHOLDER')) with check (lower(coalesce(auth.jwt()->>'email','')) = lower('OWNER_EMAIL_PLACEHOLDER'));
drop policy if exists "templates owner delete" on public.templates;
create policy "templates owner delete" on public.templates for delete to authenticated using (lower(coalesce(auth.jwt()->>'email','')) = lower('OWNER_EMAIL_PLACEHOLDER'));

-- Buckets: الفيديوهات والمعاينات عامة للعرض؛ ملفات VIZ خاصة ويُنشأ لها رابط موقّع عند الحاجة.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('gz-public-media','gz-public-media',true,26214400,array['video/mp4','video/webm','image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;
insert into storage.buckets (id, name, public, file_size_limit)
values ('gz-template-files','gz-template-files',false,52428800)
on conflict (id) do nothing;

drop policy if exists "public media readable" on storage.objects;
create policy "public media readable" on storage.objects for select using (bucket_id = 'gz-public-media');
drop policy if exists "upload own media folder" on storage.objects;
create policy "upload own media folder" on storage.objects for insert to authenticated with check (bucket_id in ('gz-public-media','gz-template-files') and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "update own media folder" on storage.objects;
create policy "update own media folder" on storage.objects for update to authenticated using (bucket_id in ('gz-public-media','gz-template-files') and (storage.foldername(name))[1] = auth.uid()::text) with check (bucket_id in ('gz-public-media','gz-template-files') and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "delete own media folder" on storage.objects;
create policy "delete own media folder" on storage.objects for delete to authenticated using (bucket_id in ('gz-public-media','gz-template-files') and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "authenticated can read template files" on storage.objects;
create policy "authenticated can read eligible template files" on storage.objects for select to authenticated using (bucket_id = 'gz-template-files' and (lower(coalesce(auth.jwt()->>'email','')) = lower('OWNER_EMAIL_PLACEHOLDER') or exists (select 1 from public.templates t where t.file_path = storage.objects.name and t.kind = 'free') or exists (select 1 from public.posts p where p.template_path = storage.objects.name)));

create index if not exists posts_created_at_idx on public.posts(created_at desc);
create index if not exists comments_post_id_idx on public.comments(post_id, created_at);
create index if not exists likes_post_id_idx on public.post_likes(post_id);


-- Verification subscriptions, manual owner verification, payment requests, and public app settings.
-- Replace OWNER_EMAIL_PLACEHOLDER above and below with the same owner login email before running.
create table if not exists public.account_verifications (
  user_id uuid primary key references auth.users(id) on delete cascade,
  is_verified boolean not null default true,
  verification_type text not null default 'manual' check (verification_type in ('owner','manual','paid')),
  starts_at timestamptz not null default now(),
  expires_at timestamptz,
  note text not null default '',
  granted_by uuid references auth.users(id) on delete set null,
  updated_at timestamptz not null default now()
);

create table if not exists public.verification_payment_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  amount_usd numeric(8,2) not null default 20.00 check (amount_usd = 20.00),
  payment_method text not null default 'sham_cash' check (payment_method = 'sham_cash'),
  transaction_ref text not null check (char_length(transaction_ref) between 3 and 120),
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  submitted_at timestamptz not null default now(),
  reviewed_at timestamptz,
  reviewed_by uuid references auth.users(id) on delete set null,
  reviewer_note text not null default '',
  unique (payment_method, transaction_ref)
);

create table if not exists public.app_settings (
  setting_key text primary key check (setting_key ~ '^[a-z_]{2,60}$'),
  setting_value text not null default '',
  updated_at timestamptz not null default now(),
  updated_by uuid references auth.users(id) on delete set null
);

create table if not exists public.admin_audit_log (
  id bigint generated always as identity primary key,
  actor_id uuid references auth.users(id) on delete set null,
  action text not null,
  target_user_id uuid references auth.users(id) on delete set null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

alter table public.account_verifications enable row level security;
alter table public.verification_payment_requests enable row level security;
alter table public.app_settings enable row level security;
alter table public.admin_audit_log enable row level security;

-- Users can read their own verification status; owner can manage all statuses.
drop policy if exists "verification readable by user or owner" on public.account_verifications;
create policy "verification readable by user or owner" on public.account_verifications for select to authenticated
using ((is_verified = true and (expires_at is null or expires_at > now())) or auth.uid() = user_id or lower(coalesce(auth.jwt()->>'email','')) = lower('OWNER_EMAIL_PLACEHOLDER'));
drop policy if exists "verification owner insert" on public.account_verifications;
create policy "verification owner insert" on public.account_verifications for insert to authenticated
with check (lower(coalesce(auth.jwt()->>'email','')) = lower('OWNER_EMAIL_PLACEHOLDER'));
drop policy if exists "verification owner update" on public.account_verifications;
create policy "verification owner update" on public.account_verifications for update to authenticated
using (lower(coalesce(auth.jwt()->>'email','')) = lower('OWNER_EMAIL_PLACEHOLDER'))
with check (lower(coalesce(auth.jwt()->>'email','')) = lower('OWNER_EMAIL_PLACEHOLDER'));
drop policy if exists "verification owner delete" on public.account_verifications;
create policy "verification owner delete" on public.account_verifications for delete to authenticated
using (lower(coalesce(auth.jwt()->>'email','')) = lower('OWNER_EMAIL_PLACEHOLDER'));

-- Users submit payment references; only the owner can review/approve/reject.
drop policy if exists "payment request read own or owner" on public.verification_payment_requests;
create policy "payment request read own or owner" on public.verification_payment_requests for select to authenticated
using (auth.uid() = user_id or lower(coalesce(auth.jwt()->>'email','')) = lower('OWNER_EMAIL_PLACEHOLDER'));
drop policy if exists "payment request insert own" on public.verification_payment_requests;
create policy "payment request insert own" on public.verification_payment_requests for insert to authenticated
with check (auth.uid() = user_id and status = 'pending' and amount_usd = 20.00 and payment_method = 'sham_cash');
drop policy if exists "payment request owner update" on public.verification_payment_requests;
create policy "payment request owner update" on public.verification_payment_requests for update to authenticated
using (lower(coalesce(auth.jwt()->>'email','')) = lower('OWNER_EMAIL_PLACEHOLDER'))
with check (lower(coalesce(auth.jwt()->>'email','')) = lower('OWNER_EMAIL_PLACEHOLDER'));

-- App settings contain only public-facing values such as recipient instructions, support, and announcement.
drop policy if exists "public settings readable" on public.app_settings;
create policy "public settings readable" on public.app_settings for select using (true);
drop policy if exists "settings owner insert" on public.app_settings;
create policy "settings owner insert" on public.app_settings for insert to authenticated
with check (lower(coalesce(auth.jwt()->>'email','')) = lower('OWNER_EMAIL_PLACEHOLDER'));
drop policy if exists "settings owner update" on public.app_settings;
create policy "settings owner update" on public.app_settings for update to authenticated
using (lower(coalesce(auth.jwt()->>'email','')) = lower('OWNER_EMAIL_PLACEHOLDER'))
with check (lower(coalesce(auth.jwt()->>'email','')) = lower('OWNER_EMAIL_PLACEHOLDER'));
drop policy if exists "audit owner readable" on public.admin_audit_log;
create policy "audit owner readable" on public.admin_audit_log for select to authenticated
using (lower(coalesce(auth.jwt()->>'email','')) = lower('OWNER_EMAIL_PLACEHOLDER'));
drop policy if exists "audit owner insert" on public.admin_audit_log;
create policy "audit owner insert" on public.admin_audit_log for insert to authenticated
with check (lower(coalesce(auth.jwt()->>'email','')) = lower('OWNER_EMAIL_PLACEHOLDER'));

create index if not exists verification_requests_status_idx on public.verification_payment_requests(status, submitted_at desc);
create index if not exists verification_expiry_idx on public.account_verifications(expires_at);

-- Public defaults. Replace the payment recipient with the official details you are authorized to publish.
insert into public.app_settings(setting_key, setting_value) values
 ('app_name','AlJoulaniGZ'),
 ('verification_monthly_price_usd','20'),
 ('shamcash_recipient_name',''),
 ('shamcash_recipient_identifier',''),
 ('shamcash_payment_instructions',''),
 ('support_contact',''),
 ('owner_instagram',''),
 ('announcement',''),
 ('maintenance_mode','false')
on conflict (setting_key) do nothing;
