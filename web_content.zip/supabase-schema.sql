create extension if not exists pgcrypto;

create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 email text not null,
 full_name text not null default '',
 role text not null default 'agent' check (role in ('agent','admin')),
 disabled boolean not null default false,
 created_at timestamptz not null default now()
);

create table if not exists public.items (
 id uuid primary key default gen_random_uuid(),
 owner_id uuid not null references public.profiles(id) on delete cascade,
 name text not null,
 number text,
 float_target numeric not null default 0,
 location text,
 personal_number text,
 details text,
 deleted boolean not null default false,
 daily_progress jsonb not null default '[]'::jsonb,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);

create or replace function public.is_admin() returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin' and p.disabled=false); $$;

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$ begin insert into public.profiles(id,email,full_name) values(new.id,new.email,coalesce(new.raw_user_meta_data->>'full_name','')); return new; end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.items enable row level security;

drop policy if exists profile_self on public.profiles;
drop policy if exists profile_admin_select on public.profiles;
create policy profile_self on public.profiles for select using (id=auth.uid());
create policy profile_admin_select on public.profiles for select using (public.is_admin());

drop policy if exists items_select on public.items;
drop policy if exists items_insert on public.items;
drop policy if exists items_update on public.items;
drop policy if exists items_delete on public.items;
create policy items_select on public.items for select using (owner_id=auth.uid() or public.is_admin());
create policy items_insert on public.items for insert with check (owner_id=auth.uid() or public.is_admin());
create policy items_update on public.items for update using (owner_id=auth.uid() or public.is_admin()) with check (owner_id=auth.uid() or public.is_admin());
create policy items_delete on public.items for delete using (public.is_admin());

-- After creating your first auth user, promote it: 
-- update public.profiles set role='admin' where email='admin@example.com';


-- Prevent agents from deleting or transferring their items by changing protected fields.
create or replace function public.protect_agent_item_changes() returns trigger language plpgsql security definer set search_path=public as $$
begin
  if not public.is_admin() then
    if new.owner_id <> old.owner_id then raise exception 'Agents cannot transfer items'; end if;
    if new.deleted <> old.deleted then raise exception 'Agents cannot delete or restore items'; end if;
  end if;
  return new;
end; $$;
drop trigger if exists protect_agent_item_changes on public.items;
create trigger protect_agent_item_changes before update on public.items for each row execute procedure public.protect_agent_item_changes();
