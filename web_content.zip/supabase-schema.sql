-- MAHDI PLATFORM starter schema
-- Run this entire script in Supabase Dashboard -> SQL Editor -> New query.
-- This script uses RLS. Never expose a service_role key in frontend code.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default 'নতুন ব্যবহারকারী' check (char_length(full_name) between 1 and 80),
  avatar_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  content text not null default '' check (char_length(content) <= 2000),
  media_url text,
  created_at timestamptz not null default now(),
  constraint post_has_content_or_media check (char_length(trim(content)) > 0 or media_url is not null)
);

create table if not exists public.likes (
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (post_id, user_id)
);

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  content text not null check (char_length(trim(content)) between 1 and 1000),
  created_at timestamptz not null default now()
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  receiver_id uuid not null references public.profiles(id) on delete cascade,
  content text not null check (char_length(trim(content)) between 1 and 2000),
  created_at timestamptz not null default now(),
  read_at timestamptz,
  constraint no_self_message check (sender_id <> receiver_id)
);

create index if not exists posts_created_at_idx on public.posts(created_at desc);
create index if not exists comments_post_id_idx on public.comments(post_id, created_at);
create index if not exists messages_sender_created_idx on public.messages(sender_id, created_at desc);
create index if not exists messages_receiver_created_idx on public.messages(receiver_id, created_at desc);

alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.likes enable row level security;
alter table public.comments enable row level security;
alter table public.messages enable row level security;

-- Public profiles are visible to signed-in users; each user edits only their own.
drop policy if exists "Signed-in users can read profiles" on public.profiles;
create policy "Signed-in users can read profiles" on public.profiles
for select to authenticated using (true);
drop policy if exists "Users insert own profile" on public.profiles;
create policy "Users insert own profile" on public.profiles
for insert to authenticated with check (auth.uid() = id);
drop policy if exists "Users update own profile" on public.profiles;
create policy "Users update own profile" on public.profiles
for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

-- Posts are readable by signed-in users; authors control changes.
drop policy if exists "Signed-in users read posts" on public.posts;
create policy "Signed-in users read posts" on public.posts
for select to authenticated using (true);
drop policy if exists "Users create own posts" on public.posts;
create policy "Users create own posts" on public.posts
for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Authors update own posts" on public.posts;
create policy "Authors update own posts" on public.posts
for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "Authors delete own posts" on public.posts;
create policy "Authors delete own posts" on public.posts
for delete to authenticated using (auth.uid() = user_id);

-- Likes are visible to signed-in users; users can only add/remove their own likes.
drop policy if exists "Signed-in users read likes" on public.likes;
create policy "Signed-in users read likes" on public.likes
for select to authenticated using (true);
drop policy if exists "Users add own likes" on public.likes;
create policy "Users add own likes" on public.likes
for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Users remove own likes" on public.likes;
create policy "Users remove own likes" on public.likes
for delete to authenticated using (auth.uid() = user_id);

-- Comments are visible to signed-in users; only author can create/delete their own.
drop policy if exists "Signed-in users read comments" on public.comments;
create policy "Signed-in users read comments" on public.comments
for select to authenticated using (true);
drop policy if exists "Users create own comments" on public.comments;
create policy "Users create own comments" on public.comments
for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Users delete own comments" on public.comments;
create policy "Users delete own comments" on public.comments
for delete to authenticated using (auth.uid() = user_id);

-- Private direct messages: only sender or receiver can read.
drop policy if exists "Participants read own messages" on public.messages;
create policy "Participants read own messages" on public.messages
for select to authenticated using (auth.uid() = sender_id or auth.uid() = receiver_id);
drop policy if exists "Sender creates own message" on public.messages;
create policy "Sender creates own message" on public.messages
for insert to authenticated with check (auth.uid() = sender_id);
-- No message UPDATE policy in this starter. Add a narrowly scoped read-receipt policy later.

-- Create a profile row automatically when a new auth account is created.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, full_name)
  values (
    new.id,
    coalesce(nullif(trim(new.raw_user_meta_data ->> 'full_name'), ''), split_part(new.email, '@', 1), 'নতুন ব্যবহারকারী')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Optional: enable Realtime for posts/messages from Dashboard -> Database -> Replication.
-- Only enable tables you actually need. RLS still controls who may read rows.
