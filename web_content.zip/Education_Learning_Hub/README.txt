EDUCATION LEARNING HUB — CLASS 11 JKBOSE

This app follows the eight units and subtopics visible in the three syllabus photographs supplied by the student.

INCLUDED
- Eight units of chapter-wise study notes.
- 1,024 practice MCQs (128 per unit), with answer checking and short explanations.
- Unit-wise MCQ filter, random practice, progress tracking.
- Offline Study Tutor that searches and explains relevant sections from the stored notes.
- Local profile and progress saved in the browser on the same device.

IMPORTANT LIMITATIONS
- The Study Tutor is an offline notes-based helper, not a generative cloud AI model.
- There is no online account system or cloud synchronisation.
- This is a web app (HTML). It is not a signed Android APK. To make an installable APK, package it with an Android WebView/Capacitor project and build/sign it using Android tooling.
- Notes are study explanations based on the photographed syllabus topics, not a reproduction of the entire textbook. Verify exact definitions, prescribed wording, and current board instructions with the book/teacher.
