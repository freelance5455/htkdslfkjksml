import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { OBJLoader } from 'three/addons/loaders/OBJLoader.js';

const ASSETS = {
  icon: 'Assets/DoLex.png',
  dolex: 'Assets/DoLex.png',
  lexCoin: 'Assets/Lex.png',
  lex: 'Assets/Lex.png',
  jump: 'Assets/Jump.png',
  baseplateObj: 'Assets/Baseplate.obj',
  baseplateTex: 'Assets/Baseplate.png',
  boy: 'Assets/Boy.obj',
  girl: 'Assets/Girl.obj',
  friends: 'Assets/Friends.png',
  addFriend: 'Assets/AddFriend.png',
  gameSettings: 'Assets/GameSettings.png',
  fullScreen: 'Assets/FullScreen.png',
  home: 'Assets/Home.png',
  group: 'Assets/group.png',
  backpack: 'Assets/Backpack.png',
  voice: 'Assets/Voice.png',
};

const SAVE_KEY = 'dolex_save_v5';
const ACCOUNTS_KEY = 'dolex_accounts_v1';
const SESSION_KEY = 'dolex_session_v1';
const NAME_COLORS = ['#5b9dff', '#ff6b9d', '#50e3a2', '#ffc846', '#c77dff', '#ff8c5a', '#4ecdc4', '#f7a8ff'];

function colorForName(name) {
  let h = 0;
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) >>> 0;
  return NAME_COLORS[h % NAME_COLORS.length];
}

function defaultAccount() {
  return {
    user_id: '', username: '', password: '', email: '', gender: 'boy', birthDate: '',
    avatarColor: '#5b9dff',
    lex: 100, liked: false, likes: 0, rating: 0, rating_count: 0,
    transactions: [], inventory: [], owned: [],
    friends: [], groups_joined: [],
    about: '', game_visits: 0, joined: new Date().toLocaleString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
    settings: {
      sound: true, music: false, theme: 'dark', joystick: true, chat: true,
      graphics: 'medium', fov: 60, sensitivity: 1, showNames: true, volume: 0.7,
      musicVol: 0.5, qol: 100
    }
  };
}

function loadAccounts() {
  try { return JSON.parse(localStorage.getItem(ACCOUNTS_KEY) || '[]'); } catch { return []; }
}
function saveAccounts(list) {
  try { localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(list)); } catch {}
}

function loadSave() {
  const d = defaultAccount();
  try {
    const s = JSON.parse(localStorage.getItem(SAVE_KEY) || '{}');
    return { ...d, ...s, settings: { ...d.settings, ...(s.settings || {}) } };
  } catch { return d; }
}
function save(acc) {
  try { localStorage.setItem(SAVE_KEY, JSON.stringify(acc)); } catch {}
  // keep accounts list in sync
  const list = loadAccounts();
  const idx = list.findIndex(a => a.user_id === acc.user_id);
  const entry = {
    user_id: acc.user_id, username: acc.username, password: acc.password,
    email: acc.email, gender: acc.gender, birthDate: acc.birthDate, lex: acc.lex
  };
  if (idx >= 0) list[idx] = { ...list[idx], ...entry };
  else if (acc.user_id && acc.password) list.push(entry);
  saveAccounts(list);
}

let account = loadSave();
let isLoggedIn = false;
try { isLoggedIn = localStorage.getItem(SESSION_KEY) === '1' && !!account.username && !!account.password; } catch {}
account.chatColor = colorForName(account.username || 'Player');

const PACKS = [
  { lex: 100, usd: 0.99, label: 'Starter' },
  { lex: 550, usd: 4.99, label: 'Popular', bonus: true },
  { lex: 1200, usd: 9.99, label: 'Pro' },
  { lex: 3000, usd: 19.99, label: 'Mega' },
];
const GROUPS = [{ name: 'DoLexGroup', members: 1240, desc: 'Official DoLex community' }];

function addTx(desc, amount) {
  account.transactions = account.transactions || [];
  account.transactions.push({
    time: new Date().toISOString().slice(0, 16).replace('T', ' '),
    desc, amount
  });
  account.lex = (account.lex || 0) + amount;
  save(account);
  updateLexUI();
}
function updateLexUI() {
  document.querySelectorAll('.lex-val').forEach(el => { el.textContent = account.lex; });
}
function applyTheme(theme) {
  document.body.classList.toggle('theme-light', theme === 'light');
  if (account && account.settings) account.settings.theme = theme;
  if (account && account.user_id) save(account);
}

// ---------- AUTH ----------
let authMode = 'signin'; // signin | signup

function showAuthScreen(id) {
  ['auth-landing', 'auth-form', 'auth-accounts'].forEach(x => {
    document.getElementById(x)?.classList.add('hidden');
  });
  document.getElementById(id)?.classList.remove('hidden');
}

function hideAllAuth() {
  ['auth-landing', 'auth-form', 'auth-accounts'].forEach(x => {
    document.getElementById(x)?.classList.add('hidden');
  });
}

function enterLobby() {
  isLoggedIn = true;
  try { localStorage.setItem(SESSION_KEY, '1'); } catch {}
  hideAllAuth();
  document.getElementById('ui-root')?.classList.remove('hidden');
  document.getElementById('loading-screen')?.classList.add('hidden');
  applyTheme(account.settings?.theme || 'dark');
  updateLexUI();
  renderHome();
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.toggle('active', b.dataset.nav === 'home'));
  const title = document.getElementById('top-bar-title');
  if (title) title.textContent = 'Home';
  // Home screen → Portrait
  if (typeof lockOrientation === 'function') lockOrientation('portrait');
}

function signOut() {
  isLoggedIn = false;
  try { localStorage.removeItem(SESSION_KEY); } catch {}
  document.getElementById('ui-root')?.classList.add('hidden');
  closeDrawer();
  showAuthScreen('auth-landing');
}

function openAuthForm(mode) {
  authMode = mode;
  const title = document.getElementById('auth-form-title');
  const sub = document.getElementById('auth-form-sub');
  const submit = document.getElementById('auth-submit');
  const gender = document.getElementById('auth-gender-wrap');
  const birth = document.getElementById('auth-birth-wrap');
  const err = document.getElementById('auth-error');
  const forgot = document.getElementById('auth-forgot');
  err?.classList.add('hidden');
  forgot?.classList.add('hidden');
  if (mode === 'signup') {
    if (title) title.textContent = 'Sign Up';
    if (sub) sub.textContent = 'Create your DoLex account';
    if (submit) submit.textContent = 'Sign Up';
    gender?.classList.remove('hidden');
    birth?.classList.remove('hidden');
  } else {
    if (title) title.textContent = 'Sign In';
    if (sub) sub.textContent = 'Enter your details to continue';
    if (submit) submit.textContent = 'Sign In';
    gender?.classList.add('hidden');
    birth?.classList.add('hidden');
  }
  document.getElementById('auth-username').value = '';
  document.getElementById('auth-password').value = '';
  document.getElementById('auth-email').value = '';
  document.getElementById('auth-gender').value = '';
  document.getElementById('auth-birth').value = '';
  document.querySelectorAll('.gender-btn').forEach(b => b.classList.remove('selected'));
  showAuthScreen('auth-form');
}

function renderAccountsList() {
  const list = loadAccounts();
  const box = document.getElementById('accounts-list');
  if (!box) return;
  if (!list.length) {
    box.innerHTML = '<p class="muted">No saved accounts yet.</p>';
    return;
  }
  box.innerHTML = list.map(a => `
    <div class="account-row" data-uid="${escapeHtml(a.user_id)}">
      <img src="Assets/DoLex.png" alt="" onerror="this.style.display='none'" />
      <div>
        <div style="font-weight:800">${escapeHtml(a.username)}</div>
        <div class="muted" style="font-size:0.8rem">${escapeHtml(a.email || '')}</div>
      </div>
    </div>
  `).join('');
  box.querySelectorAll('.account-row').forEach(row => {
    row.onclick = () => {
      const uid = row.dataset.uid;
      const found = loadAccounts().find(a => a.user_id === uid);
      if (!found) return;
      // load full save if matches current, else hydrate from entry
      let full = loadSave();
      if (full.user_id !== found.user_id) {
        full = { ...defaultAccount(), ...found, settings: defaultAccount().settings };
      } else {
        full = { ...full, ...found };
      }
      account = full;
      account.chatColor = colorForName(account.username);
      if (account.gender === 'male' || account.gender === 'Male') account.gender = 'boy';
      if (account.gender === 'female' || account.gender === 'Female') account.gender = 'girl';
      if (!account.gender) account.gender = 'boy';
      save(account);
      loadCharacter().then(() => enterLobby());
    };
  });
}

function handleAuthSubmit(e) {
  e.preventDefault();
  const username = (document.getElementById('auth-username').value || '').trim().slice(0, 20);
  const password = (document.getElementById('auth-password').value || '').trim();
  const email = (document.getElementById('auth-email').value || '').trim().toLowerCase();
  const gender = document.getElementById('auth-gender').value || '';
  const birthDate = document.getElementById('auth-birth').value || '';
  const err = document.getElementById('auth-error');
  const forgot = document.getElementById('auth-forgot');
  err.classList.add('hidden');
  forgot.classList.add('hidden');

  if (!username || !password || !email) {
    err.textContent = 'Please fill in username, password, and email.';
    err.classList.remove('hidden');
    return;
  }

  const list = loadAccounts();

  if (authMode === 'signup') {
    if (!gender || (gender !== 'boy' && gender !== 'girl')) {
      err.textContent = 'Please choose Boy or Girl character.';
      err.classList.remove('hidden');
      return;
    }
    if (list.some(a => a.username.toLowerCase() === username.toLowerCase())) {
      err.textContent = 'Username already taken.';
      err.classList.remove('hidden');
      return;
    }
    if (list.some(a => a.email && a.email.toLowerCase() === email)) {
      err.textContent = 'Email already registered.';
      err.classList.remove('hidden');
      return;
    }
    account = defaultAccount();
    account.user_id = 'u' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
    account.username = username;
    account.password = password;
    account.email = email;
    account.gender = gender;
    account.birthDate = birthDate;
    account.chatColor = colorForName(username);
    save(account);
    // reload character for chosen gender
    loadCharacter().then(() => enterLobby());
    return;
  }

  // Sign in
  const found = list.find(a =>
    a.username.toLowerCase() === username.toLowerCase() &&
    a.password === password &&
    (!a.email || a.email.toLowerCase() === email)
  );
  if (!found) {
    // also try email match with password
    const byEmail = list.find(a => a.email && a.email.toLowerCase() === email && a.password === password && a.username.toLowerCase() === username.toLowerCase());
    if (!byEmail) {
      err.textContent = 'Incorrect username, password, or email.';
      err.classList.remove('hidden');
      forgot.classList.remove('hidden');
      return;
    }
  }
  const match = found || list.find(a => a.username.toLowerCase() === username.toLowerCase());
  let full = loadSave();
  if (full.user_id !== match.user_id) {
    full = { ...defaultAccount(), ...match, settings: (full.user_id === match.user_id ? full.settings : defaultAccount().settings) };
  } else {
    full = { ...full, username: match.username, password: match.password, email: match.email };
  }
  account = full;
  account.chatColor = colorForName(account.username);
  // normalize legacy gender values
  if (account.gender === 'male' || account.gender === 'Male') account.gender = 'boy';
  if (account.gender === 'female' || account.gender === 'Female') account.gender = 'girl';
  if (!account.gender) account.gender = 'boy';
  save(account);
  loadCharacter().then(() => enterLobby());
}

function initAuthUI() {
  document.getElementById('btn-goto-signin')?.addEventListener('click', () => openAuthForm('signin'));
  document.getElementById('btn-goto-signup')?.addEventListener('click', () => openAuthForm('signup'));
  document.getElementById('btn-goto-accounts')?.addEventListener('click', () => {
    renderAccountsList();
    showAuthScreen('auth-accounts');
  });
  document.getElementById('auth-back')?.addEventListener('click', () => showAuthScreen('auth-landing'));
  document.getElementById('accounts-back')?.addEventListener('click', () => showAuthScreen('auth-landing'));
  document.getElementById('accounts-new')?.addEventListener('click', () => openAuthForm('signup'));
  document.getElementById('auth-fields')?.addEventListener('submit', handleAuthSubmit);
  document.getElementById('auth-forgot')?.addEventListener('click', () => {
    alert('Password recovery is demo-only. Create a new account or check your saved Accounts list.');
  });
  document.getElementById('drawer-signout')?.addEventListener('click', signOut);
  // Gender / character pick (Boy or Girl)
  document.querySelectorAll('.gender-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.gender-btn').forEach(b => b.classList.remove('selected'));
      btn.classList.add('selected');
      const g = btn.dataset.gender || '';
      const inp = document.getElementById('auth-gender');
      if (inp) inp.value = g;
    });
  });
}

function openDrawer() {
  document.getElementById('side-drawer')?.classList.add('open');
}
function closeDrawer() {
  document.getElementById('side-drawer')?.classList.remove('open');
}
function initDrawer() {
  document.getElementById('hamburger')?.addEventListener('click', openDrawer);
  document.getElementById('drawer-close')?.addEventListener('click', closeDrawer);
  document.getElementById('drawer-backdrop')?.addEventListener('click', closeDrawer);
  document.querySelectorAll('.drawer-item[data-drawer]').forEach(btn => {
    btn.addEventListener('click', () => {
      const key = btn.dataset.drawer;
      closeDrawer();
      if (key === 'lex') {
        document.getElementById('buy-balance').textContent = account.lex;
        const packs = document.getElementById('packs');
        packs.innerHTML = '';
        PACKS.forEach(p => {
          const d = document.createElement('div');
          d.className = 'pack';
          d.innerHTML = `
            <div class="left"><img src="${ASSETS.lex}" class="theme-icon" onerror="this.style.display='none'"/><div>
              <div style="font-weight:800">${p.lex} Lex ${p.bonus ? '<span class="badge">BEST</span>' : ''}</div>
              <div class="muted">${p.label}</div></div></div>
            <div style="font-weight:800">$${p.usd.toFixed(2)}</div>`;
          d.onclick = () => { addTx('Bought ' + p.lex + ' Lex', p.lex); document.getElementById('buy-balance').textContent = account.lex; };
          packs.appendChild(d);
        });
        showScreen('buy-lex');
        return;
      }
      if (navRender[key]) {
        stopAvatarPreview();
        document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
        currentNav = key;
        showScreen('lobby');
        navRender[key]();
        const title = document.getElementById('top-bar-title');
        if (title) title.textContent = key.charAt(0).toUpperCase() + key.slice(1);
      }
    });
  });
}

// ---------- ONLINE / MULTIPLAYER (Gun.js) ----------
const GUN_PEERS = [
  'https://gun-manhattan.herokuapp.com/gun',
  'https://peer.wallie.io/gun'
];
let gun = null;
let isOnline = false;
let netConnected = false;
let globalOnlineCount = 0;
let inGameCount = 0;
const remotePlayers = new Map(); // id -> { root, nameTag, data, lastSeen }
const PLAYER_TIMEOUT = 8000;
let lastPresencePush = 0;
let heartbeatTimer = null;

const ERROR_CODES = {
  OFFLINE: 'E1001',
  GUN_FAIL: 'E1002',
  TIMEOUT: 'E1003',
  KICKED: 'E1004',
  UNKNOWN: 'E1999'
};

function setNetBadge(state, label) {
  const el = document.getElementById('net-status');
  if (!el) return;
  el.className = 'net-badge ' + state;
  el.textContent = '● ' + label;
}

function updateOnlineCounts() {
  const g = document.getElementById('home-online-count');
  if (g) g.textContent = String(globalOnlineCount);
  const d = document.getElementById('detail-online-count');
  if (d) d.textContent = String(Math.max(inGameCount, globalOnlineCount > 0 ? inGameCount : 0));
  const h = document.getElementById('hud-player-count');
  if (h) h.textContent = String(Math.max(1, inGameCount));
}

function showOfflineGate(detail) {
  const gate = document.getElementById('offline-gate');
  gate.classList.remove('hidden');
  document.getElementById('offline-detail').textContent = detail || 'Check your connection and try again.';
  setNetBadge('offline', 'Offline');
  isOnline = false;
  netConnected = false;
}

function hideOfflineGate() {
  document.getElementById('offline-gate').classList.add('hidden');
}

function showDisconnect(reason, errorNo) {
  document.getElementById('dc-reason').textContent = reason || 'Connection lost';
  document.getElementById('dc-error').textContent = errorNo || ERROR_CODES.UNKNOWN;
  document.getElementById('disconnect-overlay').classList.remove('hidden');
  if (gameRunning) {
    gameRunning = false;
  }
  setNetBadge('offline', 'Disconnected');
  netConnected = false;
}

function hideDisconnect() {
  document.getElementById('disconnect-overlay').classList.add('hidden');
}

function initGun() {
  if (typeof Gun === 'undefined') {
    showOfflineGate('Multiplayer library failed to load.');
    return false;
  }
  try {
    gun = Gun({ peers: GUN_PEERS, localStorage: false, radisk: false });
    return true;
  } catch (e) {
    console.warn(e);
    showOfflineGate('Could not start multiplayer.');
    return false;
  }
}

function checkBrowserOnline() {
  return navigator.onLine !== false;
}

function connectNetwork() {
  setNetBadge('connecting', 'Connecting…');
  document.getElementById('load-status').textContent = 'Connecting to network…';

  if (!checkBrowserOnline()) {
    showOfflineGate('No internet connection detected.');
    return;
  }

  if (!gun && !initGun()) return;

  // Presence: lobby + in-game
  const presence = gun.get('dolex').get('presence');
  const myId = account.user_id;

  presence.get(myId).put({
    id: myId,
    username: account.username,
    color: account.chatColor,
    inGame: false,
    t: Date.now()
  });

  presence.map().on((data, id) => {
    if (!data || !id) return;
    if (data === null) return;
    // recount
    recountPresence();
  });

  // Chat stream
  gun.get('dolex').get('chat').map().on((msg, id) => {
    if (!msg || !msg.text || !msg.user) return;
    if (msg.t && Date.now() - msg.t > 120000) return; // ignore old
    appendChat(msg.user, msg.text, msg.color || colorForName(msg.user), id);
    if (msg.uid && msg.uid !== account.user_id) {
      showChatBubble(msg.uid, msg.text, false);
    }
  });

  // Mark online after short delay if browser is online
  setTimeout(() => {
    if (!checkBrowserOnline()) {
      showOfflineGate('No internet connection detected.');
      return;
    }
    isOnline = true;
    netConnected = true;
    hideOfflineGate();
    setNetBadge('online', 'Online');
    document.getElementById('load-status').textContent = 'Connected';
    startHeartbeat();
    recountPresence();
  }, 1200);
}

function recountPresence() {
  if (!gun) return;
  const now = Date.now();
  let total = 0;
  let playing = 0;
  gun.get('dolex').get('presence').once(obj => {
    if (!obj) { globalOnlineCount = 0; inGameCount = gameRunning ? 1 : 0; updateOnlineCounts(); return; }
    Object.keys(obj).forEach(k => {
      if (k === '_' ) return;
      const p = obj[k];
      if (!p || typeof p !== 'object') return;
      if (p.t && now - p.t < PLAYER_TIMEOUT) {
        total++;
        if (p.inGame) playing++;
      }
    });
    // ensure at least self
    if (isOnline && total < 1) total = 1;
    if (gameRunning && playing < 1) playing = 1;
    globalOnlineCount = total;
    inGameCount = playing;
    updateOnlineCounts();
  });
}

function startHeartbeat() {
  if (heartbeatTimer) clearInterval(heartbeatTimer);
  heartbeatTimer = setInterval(() => {
    if (!checkBrowserOnline()) {
      if (gameRunning) {
        showDisconnect('Internet connection lost', ERROR_CODES.OFFLINE);
        leaveMultiplayerPresence();
      } else {
        showOfflineGate('Internet connection lost.');
      }
      stopHeartbeat();
      return;
    }
    if (!gun || !netConnected) return;
    gun.get('dolex').get('presence').get(account.user_id).put({
      id: account.user_id,
      username: account.username,
      color: account.chatColor,
      inGame: !!gameRunning,
      t: Date.now()
    });
    recountPresence();
    // prune remote players
    const now = Date.now();
    for (const [id, rp] of remotePlayers) {
      if (now - (rp.lastSeen || 0) > PLAYER_TIMEOUT) {
        removeRemotePlayer(id);
      }
    }
  }, 2500);
}

function stopHeartbeat() {
  if (heartbeatTimer) { clearInterval(heartbeatTimer); heartbeatTimer = null; }
}

function leaveMultiplayerPresence() {
  if (!gun) return;
  gun.get('dolex').get('presence').get(account.user_id).put(null);
  gun.get('dolex').get('players').get(account.user_id).put(null);
}

function pushPlayerState() {
  if (!gun || !gameRunning || !netConnected) return;
  const now = Date.now();
  if (now - lastPresencePush < 80) return;
  lastPresencePush = now;
  gun.get('dolex').get('players').get(account.user_id).put({
    id: account.user_id,
    username: account.username,
    color: account.chatColor,
    x: +player.x.toFixed(3),
    y: +player.y.toFixed(3),
    z: +player.z.toFixed(3),
    yaw: +player.yaw.toFixed(3),
    health: player.health,
    t: now
  });
}

function subscribePlayers() {
  if (!gun) return;
  gun.get('dolex').get('players').map().on((data, id) => {
    if (!id || id === account.user_id) return;
    if (!data || data === null) {
      removeRemotePlayer(id);
      return;
    }
    if (data.t && Date.now() - data.t > PLAYER_TIMEOUT) {
      removeRemotePlayer(id);
      return;
    }
    upsertRemotePlayer(id, data);
  });
}

function upsertRemotePlayer(id, data) {
  let rp = remotePlayers.get(id);
  if (!rp) {
    const root = new THREE.Group();
    // simple body clone-ish
    const body = createSimpleAvatar(data.color || '#5b9dff');
    root.add(body);
    const nt = createNameSprite(data.username || 'Player', data.color || '#5b9dff');
    nt.position.y = 2.55;
    root.add(nt);
    scene.add(root);
    rp = { root, body, nameTag: nt, data, lastSeen: Date.now() };
    remotePlayers.set(id, rp);
  }
  rp.data = data;
  rp.lastSeen = Date.now();
  rp.root.position.set(data.x || 0, data.y || 0, data.z || 0);
  rp.root.rotation.y = data.yaw || 0;
  if (rp.nameTag && data.username) {
    // name already set at create; skip redraw for perf
  }
}

function removeRemotePlayer(id) {
  const rp = remotePlayers.get(id);
  if (!rp) return;
  scene.remove(rp.root);
  remotePlayers.delete(id);
}

function clearRemotePlayers() {
  for (const id of [...remotePlayers.keys()]) removeRemotePlayer(id);
}

function createSimpleAvatar(color) {
  const g = new THREE.Group();
  const mat = new THREE.MeshStandardMaterial({ color: new THREE.Color(color) });
  const blue = new THREE.MeshStandardMaterial({ color: 0x2266cc });
  const green = new THREE.MeshStandardMaterial({ color: 0x33aa44 });
  const head = new THREE.Mesh(new THREE.BoxGeometry(0.65, 0.65, 0.65), mat);
  head.position.y = 1.5;
  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.85, 0.4), blue);
  torso.position.y = 0.9;
  const legL = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.65, 0.32), green);
  legL.position.set(-0.18, 0.32, 0);
  const legR = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.65, 0.32), green);
  legR.position.set(0.18, 0.32, 0);
  [head, torso, legL, legR].forEach(m => { m.castShadow = true; g.add(m); });
  return g;
}

function createNameSprite(name, color) {
  const c = document.createElement('canvas');
  c.width = 256; c.height = 64;
  const ctx = c.getContext('2d');
  ctx.fillStyle = 'rgba(0,0,0,0.55)';
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(8, 8, 240, 48, 10); else ctx.rect(8, 8, 240, 48);
  ctx.fill();
  ctx.fillStyle = color || '#fff';
  ctx.font = 'bold 26px system-ui, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(name, 128, 32);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  const mat = new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false });
  const spr = new THREE.Sprite(mat);
  spr.scale.set(2.2, 0.55, 1);
  return spr;
}

function createChatBubble(text) {
  const c = document.createElement('canvas');
  c.width = 320; c.height = 80;
  const ctx = c.getContext('2d');
  ctx.fillStyle = 'rgba(20,18,30,0.85)';
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(8, 8, 304, 56, 12); else ctx.rect(8, 8, 304, 56);
  ctx.fill();
  ctx.fillStyle = '#fff';
  ctx.font = '20px system-ui, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  const t = text.length > 36 ? text.slice(0, 34) + '…' : text;
  ctx.fillText(t, 160, 36);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  const mat = new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false });
  const spr = new THREE.Sprite(mat);
  spr.scale.set(2.6, 0.65, 1);
  return spr;
}

const chatBubbles = new Map(); // id -> { sprite, until }
let localChatBubble = null;
let localChatUntil = 0;

function showChatBubble(playerId, text, isLocal) {
  if (isLocal) {
    if (localChatBubble) {
      characterRoot.remove(localChatBubble);
      localChatBubble.material.map?.dispose();
      localChatBubble.material.dispose();
    }
    localChatBubble = createChatBubble(text);
    localChatBubble.position.y = 2.9;
    characterRoot.add(localChatBubble);
    localChatUntil = performance.now() + 5000;
  } else {
    const rp = remotePlayers.get(playerId);
    if (!rp) return;
    if (chatBubbles.has(playerId)) {
      const old = chatBubbles.get(playerId);
      rp.root.remove(old.sprite);
      old.sprite.material.map?.dispose();
      old.sprite.material.dispose();
    }
    const spr = createChatBubble(text);
    spr.position.y = 3.1;
    rp.root.add(spr);
    chatBubbles.set(playerId, { sprite: spr, until: performance.now() + 5000 });
  }
}

function updateChatBubbles(now) {
  if (localChatBubble && now > localChatUntil) {
    characterRoot.remove(localChatBubble);
    localChatBubble.material.map?.dispose();
    localChatBubble.material.dispose();
    localChatBubble = null;
  }
  for (const [id, b] of [...chatBubbles.entries()]) {
    if (now > b.until) {
      const rp = remotePlayers.get(id);
      if (rp) rp.root.remove(b.sprite);
      b.sprite.material.map?.dispose();
      b.sprite.material.dispose();
      chatBubbles.delete(id);
    }
  }
}

// Chat
const seenChat = new Set();
function appendChat(user, text, color, id) {
  const key = id || (user + '|' + text + '|' + (text.length));
  if (seenChat.has(key)) return;
  seenChat.add(key);
  if (seenChat.size > 200) {
    const first = seenChat.values().next().value;
    seenChat.delete(first);
  }
  const box = document.getElementById('chat-messages');
  if (!box) return;
  const line = document.createElement('div');
  line.className = 'chat-line';
  line.innerHTML = `<span class="chat-user" style="color:${color}">${escapeHtml(user)}</span><span class="chat-text">: ${escapeHtml(text)}</span>`;
  box.appendChild(line);
  box.scrollTop = box.scrollHeight;
  while (box.children.length > 40) box.removeChild(box.firstChild);
}
function escapeHtml(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function sendChat(text) {
  text = (text || '').trim();
  if (!text) return;
  if (gun && netConnected) {
    const id = account.user_id + '_' + Date.now();
    gun.get('dolex').get('chat').get(id).put({
      user: account.username,
      text,
      color: account.chatColor,
      uid: account.user_id,
      t: Date.now()
    });
  }
  // show locally immediately
  appendChat(account.username, text, account.chatColor);
  showChatBubble(account.user_id, text, true);
}

// ---------- Screens ----------
const content = document.getElementById('content');
let currentNav = 'home';

function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  const el = document.getElementById(id);
  if (el) el.classList.add('active');
}

function renderHome() {
  content.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:12px">
      <div>
        <div class="hello">Hello, ${escapeHtml(account.username)}!</div>
        <div class="muted">Friends ${account.friends.length}</div>
      </div>
      <div class="lex-chip"><img src="${ASSETS.lex}" alt="" onerror="this.style.display='none'"/><span class="lex-val">${account.lex}</span></div>
    </div>
    <div id="home-viewport-wrap"><canvas id="home-viewport"></canvas></div>
    <div class="online-banner" style="margin-top:14px">
      <span class="pulse-dot"></span>
      <span id="home-online-count">${globalOnlineCount}</span> players online on DoLex
    </div>
    <div class="section-title">Popular right now</div>
    <div class="game-card" id="game-card">
      <div class="thumb"><img src="${ASSETS.dolex}" alt="" onerror="this.style.display='none'"/></div>
      <div class="body">
        <h3>DoLex Obby's</h3>
        <div class="stats"><span class="live-ingame">${inGameCount}</span> in game &nbsp; Rating ${account.rating.toFixed(1)} &nbsp; Likes ${account.likes}</div>
      </div>
    </div>
    <p class="muted" style="margin-top:18px">Online multiplayer experience</p>
    <p class="muted">DoLex Obby's — play with others in any browser</p>
  `;
  document.getElementById('game-card').onclick = () => {
    document.getElementById('detail-stats').textContent =
      `${account.likes} likes · Rating ${account.rating.toFixed(1)}`;
    document.getElementById('detail-id').textContent = `ID ${account.user_id}`;
    document.getElementById('btn-like').textContent = account.liked ? 'Liked ✓' : 'Like';
    document.getElementById('detail-online-count').textContent = String(inGameCount || globalOnlineCount);
    showScreen('detail');
  };
  updateOnlineCounts();
  requestAnimationFrame(() => startAvatarPreview(document.getElementById('home-viewport')));
}

function renderProfile() {
  content.innerHTML = `
    <div class="hello">${escapeHtml(account.username)}</div>
    <div class="muted">User ID: ${account.user_id}</div>
    <div class="muted" style="margin-top:8px">${account.friends.length} Friends · 0 Followers · 0 Following</div>
    <div style="background:#201a32;border-radius:12px;padding:14px;margin-top:16px">
      <div style="font-weight:600;margin-bottom:6px">About</div>
      <div class="muted">${escapeHtml(account.about || 'Tell people about yourself.')}</div>
    </div>
    <div class="muted" style="margin-top:16px">Game visits: ${account.game_visits}</div>
    <div class="muted">Joined: ${account.joined}</div>
    <div class="muted" style="margin-top:8px">Chat color: <span style="color:${account.chatColor}">■ ${account.chatColor}</span></div>
  `;
}

function renderFriends() {
  const list = account.friends || [];
  content.innerHTML = `
    <div class="hello"><img src="${ASSETS.friends}" class="theme-icon" alt="" style="width:28px;height:28px;vertical-align:middle;margin-right:8px;border-radius:6px" onerror="this.style.display='none'"/> Friends</div>
    <button class="add-friend-btn" id="btn-add-friend">
      <img src="${ASSETS.addFriend}" alt="" onerror="this.style.display='none'"/> Add Friend
    </button>
    <div class="muted" style="margin:8px 0 12px">Friends · Followers · Following · Requests</div>
    <div id="friends-list">
      ${list.length ? list.map((f, i) => `
        <div class="friend-row" data-idx="${i}">
          <img class="friend-avatar" src="${ASSETS.dolex}" alt="" onerror="this.style.display='none'"/>
          <div>
            <div style="font-weight:600">${escapeHtml(f)}</div>
            <div class="muted" style="font-size:0.8rem">Online</div>
          </div>
          <div class="friend-actions">
            <button class="friend-dots" data-idx="${i}" aria-label="More">•••</button>
            <div class="friend-menu" id="fmenu-${i}">
              <button data-act="friend" data-idx="${i}">Friend</button>
              <button data-act="follow" data-idx="${i}">Follow</button>
              <button data-act="details" data-idx="${i}">Details</button>
            </div>
          </div>
        </div>
      `).join('') : '<p class="muted">No friends yet. Add some!</p>'}
    </div>
  `;
  document.getElementById('btn-add-friend').onclick = () => {
    const name = prompt('Enter friend username:');
    if (name && name.trim()) {
      account.friends = account.friends || [];
      if (!account.friends.includes(name.trim())) {
        account.friends.push(name.trim());
        save(account);
        renderFriends();
      }
    }
  };
  content.querySelectorAll('.friend-dots').forEach(btn => {
    btn.onclick = (e) => {
      e.stopPropagation();
      const idx = btn.dataset.idx;
      const menu = document.getElementById('fmenu-' + idx);
      document.querySelectorAll('.friend-menu').forEach(m => { if (m !== menu) m.classList.remove('open'); });
      menu.classList.toggle('open');
    };
  });
  content.querySelectorAll('.friend-menu button').forEach(btn => {
    btn.onclick = (e) => {
      e.stopPropagation();
      const act = btn.dataset.act;
      const idx = +btn.dataset.idx;
      const name = account.friends[idx];
      if (act === 'details') alert(`User: ${name}\nStatus: Online\nFriends since: recently`);
      else if (act === 'follow') alert(`Now following ${name}`);
      else if (act === 'friend') alert(`${name} is already your friend`);
      document.querySelectorAll('.friend-menu').forEach(m => m.classList.remove('open'));
    };
  });
  document.addEventListener('click', () => {
    document.querySelectorAll('.friend-menu').forEach(m => m.classList.remove('open'));
  }, { once: true });
}

function renderInventory() {
  const inv = account.inventory || [];
  content.innerHTML = `
    <div class="hello">Inventory</div>
    <div class="muted">${inv.length} item(s)</div>
    <div class="grid" style="margin-top:16px">${
      inv.length
        ? inv.map(n => `<div class="item-card"><div>${escapeHtml(n)}</div><div class="price free">Owned</div></div>`).join('')
        : '<p class="muted">No items yet.</p>'
    }</div>
  `;
}

let avatarPreviewRenderer = null, avatarPreviewScene = null, avatarPreviewCamera = null, avatarPreviewAnim = null, avatarPreviewModel = null;
let avatarDrag = { active: false, lastX: 0, rotY: 0, autoSpin: true };
function stopAvatarPreview() {
  if (avatarPreviewAnim) { cancelAnimationFrame(avatarPreviewAnim); avatarPreviewAnim = null; }
  if (avatarPreviewRenderer) { avatarPreviewRenderer.dispose(); avatarPreviewRenderer = null; }
  avatarPreviewScene = null; avatarPreviewCamera = null; avatarPreviewModel = null;
  avatarDrag = { active: false, lastX: 0, rotY: 0, autoSpin: true };
}
function startAvatarPreview(canvasEl) {
  stopAvatarPreview();
  if (!canvasEl || !character) return;
  const w = canvasEl.clientWidth || 280, h = canvasEl.clientHeight || 280;
  avatarPreviewRenderer = new THREE.WebGLRenderer({ canvas: canvasEl, antialias: true, alpha: true });
  avatarPreviewRenderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  avatarPreviewRenderer.setSize(w, h, false);
  avatarPreviewRenderer.outputColorSpace = THREE.SRGBColorSpace;
  avatarPreviewScene = new THREE.Scene();
  avatarPreviewScene.background = new THREE.Color(0x1a1628);
  avatarPreviewScene.add(new THREE.AmbientLight(0xffffff, 0.75));
  const light = new THREE.DirectionalLight(0xfff5e0, 1.1);
  light.position.set(3, 5, 4);
  avatarPreviewScene.add(light);
  const fill = new THREE.DirectionalLight(0x8899ff, 0.35);
  fill.position.set(-3, 2, -2);
  avatarPreviewScene.add(fill);
  avatarPreviewCamera = new THREE.PerspectiveCamera(40, w / h, 0.1, 50);
  avatarPreviewCamera.position.set(0, 1.2, 3.8);
  avatarPreviewCamera.lookAt(0, 0.9, 0);
  // Pivot at center of model
  avatarPreviewModel = character.clone(true);
  const box = new THREE.Box3().setFromObject(avatarPreviewModel);
  const center = new THREE.Vector3();
  box.getCenter(center);
  avatarPreviewModel.position.set(-center.x, -box.min.y, -center.z);
  const pivot = new THREE.Group();
  pivot.add(avatarPreviewModel);
  avatarPreviewScene.add(pivot);
  avatarPreviewModel = pivot; // rotate the pivot group
  const t0 = performance.now();
  function tick(now) {
    avatarPreviewAnim = requestAnimationFrame(tick);
    if (avatarPreviewModel && avatarDrag.autoSpin) {
      avatarDrag.rotY += 0.006;
    }
    if (avatarPreviewModel) avatarPreviewModel.rotation.y = avatarDrag.rotY;
    if (avatarPreviewRenderer) avatarPreviewRenderer.render(avatarPreviewScene, avatarPreviewCamera);
  }
  tick(t0);
  // Drag to rotate
  const onDown = (e) => {
    avatarDrag.active = true;
    avatarDrag.autoSpin = false;
    avatarDrag.lastX = e.clientX || (e.touches && e.touches[0].clientX) || 0;
    e.preventDefault();
  };
  const onMove = (e) => {
    if (!avatarDrag.active) return;
    const x = e.clientX || (e.touches && e.touches[0].clientX) || 0;
    const dx = x - avatarDrag.lastX;
    avatarDrag.rotY += dx * 0.01;
    avatarDrag.lastX = x;
    e.preventDefault();
  };
  const onUp = () => {
    avatarDrag.active = false;
    setTimeout(() => { avatarDrag.autoSpin = true; }, 2500);
  };
  canvasEl.addEventListener('pointerdown', onDown);
  canvasEl.addEventListener('pointermove', onMove);
  canvasEl.addEventListener('pointerup', onUp);
  canvasEl.addEventListener('pointerleave', onUp);
  canvasEl.addEventListener('touchstart', onDown, { passive: false });
  canvasEl.addEventListener('touchmove', onMove, { passive: false });
  canvasEl.addEventListener('touchend', onUp);
}
function renderAvatar() {
  stopAvatarPreview();
  const genderLabel = (account.gender === 'girl' || account.gender === 'female') ? 'Girl' : 'Boy';
  const col = account.avatarColor || account.chatColor || '#5b9dff';
  content.innerHTML = `
    <div class="hello">Avatar</div>
    <p class="muted" style="margin:8px 0">Character: <strong>${genderLabel}</strong> · Pivot centered (HumanoidRootPart style)</p>
    <div id="avatar-viewport-wrap"><canvas id="avatar-viewport"></canvas></div>
    <p class="muted" style="text-align:center;margin-top:8px">${escapeHtml(account.username)}</p>
    <div class="recolor-row">
      <label>Recolor model <input type="color" id="avatar-color" value="${col}" /></label>
      <button class="btn btn-dark" id="avatar-apply-color" style="padding:8px 14px">Apply</button>
      <button class="btn btn-outline" id="avatar-switch-gender" style="padding:8px 14px">Switch to ${genderLabel === 'Boy' ? 'Girl' : 'Boy'}</button>
    </div>
  `;
  requestAnimationFrame(() => startAvatarPreview(document.getElementById('avatar-viewport')));
  document.getElementById('avatar-apply-color')?.addEventListener('click', () => {
    const hex = document.getElementById('avatar-color')?.value || '#5b9dff';
    account.avatarColor = hex;
    applyAvatarColor(character, hex);
    save(account);
    stopAvatarPreview();
    requestAnimationFrame(() => startAvatarPreview(document.getElementById('avatar-viewport')));
  });
  document.getElementById('avatar-switch-gender')?.addEventListener('click', async () => {
    account.gender = (account.gender === 'girl' || account.gender === 'female') ? 'boy' : 'girl';
    save(account);
    await loadCharacter();
    renderAvatar();
  });
}

function renderGroups() {
  content.innerHTML = `<div class="hello">Groups</div><div id="glist" style="margin-top:12px"></div>`;
  const list = document.getElementById('glist');
  GROUPS.forEach(g => {
    const joined = (account.groups_joined || []).includes(g.name);
    const card = document.createElement('div');
    card.style.cssText = 'background:#201a32;border-radius:12px;padding:14px;margin-bottom:10px;display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap';
    card.innerHTML = `
      <div><div style="font-weight:600">${g.name}</div>
      <div class="muted">${g.members} members · ${g.desc}</div></div>
      <button class="btn ${joined ? 'btn-green' : 'btn-purple'}" style="padding:8px 16px">${joined ? 'Joined' : 'Join'}</button>`;
    card.querySelector('button').onclick = () => {
      account.groups_joined = account.groups_joined || [];
      if (joined) account.groups_joined = account.groups_joined.filter(x => x !== g.name);
      else account.groups_joined.push(g.name);
      save(account); renderGroups();
    };
    list.appendChild(card);
  });
}

function renderSettings() {
  const s = account.settings;
  content.innerHTML = `
    <div class="hello"><img src="${ASSETS.gameSettings}" class="theme-icon" alt="" style="width:24px;height:24px;vertical-align:middle;margin-right:8px;border-radius:6px" onerror="this.style.display='none'"/> Settings</div>
    <div class="settings-group">
      <h3>Account</h3>
      <div class="settings-row">Username <input type="text" id="set-username" value="${escapeHtml(account.username)}" maxlength="20" /></div>
      <div class="settings-row">User ID <span class="muted">${account.user_id}</span></div>
    </div>
    <div class="settings-group">
      <h3>Audio</h3>
      <div class="settings-row">Sound <input type="checkbox" id="hs-sound" ${s.sound ? 'checked' : ''} /></div>
      <div class="settings-row">Music <input type="checkbox" id="hs-music" ${s.music ? 'checked' : ''} /></div>
      <div class="settings-row">Volume <input type="range" id="hs-volume" min="0" max="1" step="0.05" value="${s.volume || 0.7}" /></div>
      <div class="settings-row">Music Vol <input type="range" id="hs-music-vol" min="0" max="1" step="0.05" value="${s.musicVol || 0.5}" /></div>
    </div>
    <div class="settings-group">
      <h3>Controls</h3>
      <div class="settings-row">Joystick Visible <input type="checkbox" id="hs-joystick" ${s.joystick ? 'checked' : ''} /></div>
      <div class="settings-row">Look Sensitivity <input type="range" id="hs-sens" min="0.3" max="2" step="0.1" value="${s.sensitivity}" /></div>
    </div>
    <div class="settings-group">
      <h3>Graphics & QOL</h3>
      <div class="settings-row">Quality
        <select id="hs-graphics">
          <option value="low" ${s.graphics==='low'?'selected':''}>Low</option>
          <option value="medium" ${s.graphics==='medium'?'selected':''}>Medium</option>
          <option value="high" ${s.graphics==='high'?'selected':''}>High</option>
        </select>
      </div>
      <div class="settings-row">QOL <input type="range" id="hs-qol" min="0" max="500" step="10" value="${s.qol || 100}" /> <span id="qol-val">${s.qol || 100}</span></div>
      <div class="settings-row">FOV <input type="range" id="hs-fov" min="50" max="90" step="1" value="${s.fov}" /></div>
      <div class="settings-row">Show Names <input type="checkbox" id="hs-names" ${s.showNames !== false ? 'checked' : ''} /></div>
      <div class="settings-row">Theme
        <select id="hs-theme">
          <option value="dark" ${s.theme==='dark'?'selected':''}>Dark</option>
          <option value="light" ${s.theme==='light'?'selected':''}>Light</option>
        </select>
      </div>
      <div class="settings-row">
        <button class="btn btn-dark" id="btn-fullscreen" style="display:flex;align-items:center;gap:8px;width:100%;justify-content:center">
          <img src="${ASSETS.fullScreen}" alt="" style="width:20px;height:20px" onerror="this.style.display='none'"/> Fullscreen
        </button>
      </div>
    </div>
    <div class="settings-group">
      <h3>Chat</h3>
      <div class="settings-row">Show Chat <input type="checkbox" id="hs-chat" ${s.chat !== false ? 'checked' : ''} /></div>
    </div>
    <div class="btn-row">
      <button class="btn btn-purple" id="go-buy">Buy Lex</button>
      <button class="btn btn-dark" id="go-tx">Transactions</button>
    </div>
    <p class="muted" style="margin-top:20px;color:#e84545">Danger Zone</p>
    <p class="muted">Local save only. Online play requires internet.</p>
  `;

  document.getElementById('set-username').onchange = (e) => {
    const v = e.target.value.trim().slice(0, 20) || account.username;
    account.username = v;
    account.chatColor = colorForName(v);
    save(account);
    drawNameTag(account.username);
    if (nameTagTex) nameTagTex.needsUpdate = true;
  };
  const bind = (id, key, parse = v => v) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.onchange = el.oninput = () => {
      const val = el.type === 'checkbox' ? el.checked : parse(el.value);
      account.settings[key] = val;
      save(account);
      if (key === 'theme') applyTheme(val);
      if (key === 'fov' && camera) { camera.fov = +val; camera.updateProjectionMatrix(); }
      if (key === 'graphics') applyGraphics(val);
      if (key === 'joystick') showJoystick = !!val;
      if (key === 'chat') {
        document.getElementById('chat-panel')?.classList.toggle('hidden', !val);
      }
    };
  };
  bind('hs-sound', 'sound');
  bind('hs-music', 'music');
  bind('hs-volume', 'volume', parseFloat);
  bind('hs-music-vol', 'musicVol', parseFloat);
  bind('hs-joystick', 'joystick');
  bind('hs-sens', 'sensitivity', parseFloat);
  bind('hs-graphics', 'graphics');
  bind('hs-fov', 'fov', parseFloat);
  bind('hs-names', 'showNames');
  bind('hs-theme', 'theme');
  bind('hs-chat', 'chat');
  const qolEl = document.getElementById('hs-qol');
  if (qolEl) {
    qolEl.oninput = () => {
      account.settings.qol = +qolEl.value;
      document.getElementById('qol-val').textContent = qolEl.value;
      save(account);
      applyQol(+qolEl.value);
    };
  }
  document.getElementById('btn-fullscreen')?.addEventListener('click', () => {
    const el = document.documentElement;
    if (!document.fullscreenElement) el.requestFullscreen?.() || el.webkitRequestFullscreen?.();
    else document.exitFullscreen?.() || document.webkitExitFullscreen?.();
  });

  document.getElementById('go-buy').onclick = () => {
    document.getElementById('buy-balance').textContent = account.lex;
    const packs = document.getElementById('packs');
    packs.innerHTML = '';
    PACKS.forEach(p => {
      const d = document.createElement('div');
      d.className = 'pack';
      d.innerHTML = `
        <div class="left"><img src="${ASSETS.lexCoin}" onerror="this.style.display='none'"/><div>
          <div style="font-weight:600">${p.lex} Lex ${p.bonus ? '<span class="badge">BEST</span>' : ''}</div>
          <div class="muted">${p.label}</div></div></div>
        <div style="font-weight:700">$${p.usd.toFixed(2)}</div>`;
      d.onclick = () => { addTx(`Bought ${p.lex} Lex`, p.lex); document.getElementById('buy-balance').textContent = account.lex; };
      packs.appendChild(d);
    });
    showScreen('buy-lex');
  };
  document.getElementById('go-tx').onclick = () => {
    const list = document.getElementById('tx-list');
    const txs = (account.transactions || []).slice().reverse().slice(0, 30);
    list.innerHTML = txs.length ? txs.map(t => `
      <div style="display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid #2a2438;gap:8px;flex-wrap:wrap">
        <span class="muted">${t.time}</span><span>${escapeHtml(t.desc)}</span>
        <span style="color:${t.amount >= 0 ? '#28c85a' : '#e84545'}">${t.amount >= 0 ? '+' : ''}${t.amount} Lex</span>
      </div>`).join('') : '<p class="muted">No transactions yet.</p>';
    showScreen('tx');
  };
}

function applyGraphics(level) {
  const pr = level === 'low' ? 1 : level === 'high' ? Math.min(window.devicePixelRatio, 2) : Math.min(window.devicePixelRatio, 1.5);
  renderer.setPixelRatio(pr);
  renderer.shadowMap.enabled = level !== 'low';
  sun.castShadow = level !== 'low';
}
function applyQol(val) {
  // QOL 0-500: higher = better shadows / quality without lag
  const q = Math.max(0, Math.min(500, val || 100));
  if (!renderer || !sun) return;
  const mapSize = q < 100 ? 512 : q < 250 ? 1024 : q < 400 ? 2048 : 2048;
  if (sun.shadow) {
    sun.shadow.mapSize.set(mapSize, mapSize);
    sun.shadow.map?.dispose?.();
    sun.shadow.map = null;
  }
  renderer.shadowMap.enabled = q > 20;
  sun.castShadow = q > 20;
  if (q >= 300) renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  else renderer.shadowMap.type = THREE.PCFShadowMap;
}

function renderMarketplace() {
  content.innerHTML = `
    <div class="hello">Marketplace</div>
    <p class="muted" style="margin-bottom:16px">Spend Lex on packs and items</p>
    <div class="lex-chip" style="margin-bottom:16px">
      <img src="${ASSETS.lex}" class="theme-icon" alt="" onerror="this.style.display='none'"/><span class="lex-val">${account.lex}</span>
    </div>
    <div class="section-title">Lex Packs</div>
    <div id="market-packs"></div>
  `;
  const packs = document.getElementById('market-packs');
  PACKS.forEach(p => {
    const d = document.createElement('div');
    d.className = 'pack';
    d.innerHTML = `
      <div class="left"><img src="${ASSETS.lex}" class="theme-icon" onerror="this.style.display='none'"/><div>
        <div style="font-weight:800">${p.lex} Lex ${p.bonus ? '<span class="badge">BEST</span>' : ''}</div>
        <div class="muted">${p.label}</div></div></div>
      <div style="font-weight:800">$${p.usd.toFixed(2)}</div>`;
    d.onclick = () => { addTx('Bought ' + p.lex + ' Lex', p.lex); updateLexUI(); renderMarketplace(); };
    packs.appendChild(d);
  });
}

const navRender = {
  home: renderHome, profile: renderProfile, friends: renderFriends,
  marketplace: renderMarketplace,
  inventory: renderInventory, avatar: renderAvatar,
  groups: renderGroups, settings: renderSettings
};

document.querySelectorAll('.nav-btn').forEach(btn => {
  btn.onclick = () => {
    stopAvatarPreview();
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentNav = btn.dataset.nav;
    showScreen('lobby');
    if (navRender[currentNav]) navRender[currentNav]();
    const title = document.getElementById('top-bar-title');
    if (title) title.textContent = (btn.querySelector('span')?.textContent || currentNav).trim();
  };
});

document.getElementById('detail-back').onclick = () => { showScreen('lobby'); renderHome(); };
document.getElementById('buy-back').onclick = () => { showScreen('lobby'); renderSettings(); };
document.getElementById('tx-back').onclick = () => { showScreen('lobby'); renderSettings(); };
document.getElementById('btn-like').onclick = () => {
  if (!account.liked) {
    account.liked = true;
    account.likes = (account.likes || 0) + 1;
    addTx('Like reward', 5);
    document.getElementById('btn-like').textContent = 'Liked ✓';
  }
};
document.getElementById('btn-rate').onclick = () => {
  const ns = 3 + Math.random() * 2;
  const c = (account.rating_count || 0) + 1;
  account.rating = ((account.rating || 0) * (c - 1) + ns) / c;
  account.rating_count = c;
  addTx('Rate reward', 2);
  document.getElementById('detail-stats').textContent =
    `${account.likes} likes · Rating ${account.rating.toFixed(1)}`;
};

document.getElementById('btn-retry-online').onclick = () => {
  hideOfflineGate();
  connectNetwork();
};
document.getElementById('dc-reconnect').onclick = () => {
  hideDisconnect();
  if (!checkBrowserOnline()) {
    showOfflineGate('Still offline.');
    return;
  }
  netConnected = true;
  isOnline = true;
  setNetBadge('online', 'Online');
  startHeartbeat();
  if (document.getElementById('hud').classList.contains('active')) {
    gameRunning = true;
    subscribePlayers();
  }
};
document.getElementById('dc-leave').onclick = () => {
  hideDisconnect();
  endGame();
};

// ---------- THREE.JS ----------
const canvas = document.getElementById('game-canvas');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.shadowMap.enabled = true;

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x87a0c0);
scene.fog = new THREE.Fog(0x87a0c0, 40, 90);

const camera = new THREE.PerspectiveCamera(account.settings.fov || 60, window.innerWidth / window.innerHeight, 0.1, 200);
const ambientLight = new THREE.AmbientLight(0xffffff, 0.55);
scene.add(ambientLight);
const sun = new THREE.DirectionalLight(0xfff5e0, 1.1);
sun.position.set(30, 50, 20);
sun.castShadow = true;
sun.shadow.mapSize.set(1024, 1024);
sun.shadow.camera.near = 1;
sun.shadow.camera.far = 120;
sun.shadow.camera.left = -40;
sun.shadow.camera.right = 40;
sun.shadow.camera.top = 40;
sun.shadow.camera.bottom = -40;
sun.shadow.bias = -0.0005;
sun.shadow.normalBias = 0.02;
scene.add(sun);
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

// Day / Night cycle (full cycle ~4 min)
let dayNightTime = 0.25; // 0=midnight, 0.25=sunrise, 0.5=noon, 0.75=sunset
const DAY_NIGHT_SPEED = 0.00004;
function updateDayNight(dt) {
  dayNightTime = (dayNightTime + DAY_NIGHT_SPEED * dt * 60) % 1;
  const t = dayNightTime;
  // Sun angle: rise in east, set in west
  const angle = t * Math.PI * 2;
  const sunH = Math.sin(angle);
  const sunX = Math.cos(angle) * 40;
  const sunY = Math.max(2, sunH * 55);
  const sunZ = Math.sin(angle * 0.5) * 15;
  sun.position.set(sunX, sunY, sunZ);
  sun.target.position.set(0, 0, 0);
  // Colors
  let skyR, skyG, skyB, ambI, sunI, sunC;
  if (t < 0.2 || t > 0.8) { // night
    skyR = 0.05; skyG = 0.06; skyB = 0.12;
    ambI = 0.18; sunI = 0.15; sunC = 0x6688cc;
  } else if (t < 0.3) { // sunrise
    const k = (t - 0.2) / 0.1;
    skyR = 0.05 + k * 0.7; skyG = 0.06 + k * 0.45; skyB = 0.12 + k * 0.35;
    ambI = 0.18 + k * 0.35; sunI = 0.15 + k * 0.9; sunC = 0xffaa66;
  } else if (t < 0.7) { // day
    skyR = 0.53; skyG = 0.63; skyB = 0.75;
    ambI = 0.55; sunI = 1.15; sunC = 0xfff5e0;
  } else { // sunset
    const k = (t - 0.7) / 0.1;
    skyR = 0.53 + k * 0.3; skyG = 0.63 - k * 0.35; skyB = 0.75 - k * 0.5;
    ambI = 0.55 - k * 0.3; sunI = 1.15 - k * 0.7; sunC = 0xff7744;
  }
  scene.background.setRGB(skyR, skyG, skyB);
  if (scene.fog) scene.fog.color.setRGB(skyR, skyG, skyB);
  ambientLight.intensity = ambI;
  sun.intensity = sunI;
  sun.color.setHex(sunC);
  sun.castShadow = sunY > 8;
}

const SPAWN = { x: 0, y: 1.2, z: 0 };
const player = {
  x: SPAWN.x, y: SPAWN.y, z: SPAWN.z, vy: 0, onGround: true,
  health: 100, maxHealth: 100, yaw: 0, dead: false, fallApartUntil: 0
};

let camDist = 8;
const CAM_MIN = 3.5, CAM_MAX = 16;
let camPitch = -0.35;
let character = null;
const characterRoot = new THREE.Group();
scene.add(characterRoot);

const nameTagCanvas = document.createElement('canvas');
nameTagCanvas.width = 256; nameTagCanvas.height = 64;
const nameTagCtx = nameTagCanvas.getContext('2d');
function drawNameTag(name) {
  nameTagCtx.clearRect(0, 0, 256, 64);
  nameTagCtx.fillStyle = 'rgba(0,0,0,0.55)';
  nameTagCtx.beginPath();
  if (nameTagCtx.roundRect) nameTagCtx.roundRect(8, 8, 240, 48, 10); else nameTagCtx.rect(8, 8, 240, 48);
  nameTagCtx.fill();
  nameTagCtx.fillStyle = account.chatColor || '#fff';
  nameTagCtx.font = 'bold 28px system-ui, sans-serif';
  nameTagCtx.textAlign = 'center';
  nameTagCtx.textBaseline = 'middle';
  nameTagCtx.fillText(name, 128, 32);
}
drawNameTag(account.username);
const nameTagTex = new THREE.CanvasTexture(nameTagCanvas);
nameTagTex.colorSpace = THREE.SRGBColorSpace;
const nameTag = new THREE.Sprite(new THREE.SpriteMaterial({ map: nameTagTex, transparent: true, depthTest: false }));
nameTag.scale.set(2.4, 0.6, 1);
nameTag.position.y = 2.6;
characterRoot.add(nameTag);

const keys = {};
let joyActive = false, joyDX = 0, joyDY = 0;
let pointerLook = false, lastPX = 0, lastPY = 0;
let pinchActive = false, pinchStartDist = 0, pinchStartCam = 8;

const healthWrap = document.getElementById('health-wrap');
const healthBar = document.getElementById('health-bar');
const damageFx = document.getElementById('damage-fx');
let healthVisibleUntil = 0, lastRegen = 0, damageFxUntil = 0, lastHazardHit = 0;

function setHealth(h) {
  const prev = player.health;
  player.health = Math.max(0, Math.min(player.maxHealth, h));
  healthBar.style.width = (player.health / player.maxHealth * 100) + '%';
  if (player.health < player.maxHealth) {
    healthWrap.classList.add('show');
    healthVisibleUntil = performance.now() + 3000;
    if (player.health < prev) {
      healthBar.classList.add('damaged');
      damageFx.classList.add('show');
      damageFxUntil = performance.now() + 1000;
      setTimeout(() => healthBar.classList.remove('damaged'), 400);
    }
  }
  if (player.health <= 0 && !player.dead) dieAndRespawn();
}
function takeDamage(amount) {
  if (player.dead) return;
  setHealth(player.health - amount);
}
function dieAndRespawn() {
  player.dead = true;
  player.health = 0;
  healthBar.style.width = '0%';
  if (character) {
    character.traverse(c => {
      if (c.isMesh) {
        c.userData._origPos = c.position.clone();
        c.userData._vel = new THREE.Vector3((Math.random() - 0.5) * 6, Math.random() * 4 + 2, (Math.random() - 0.5) * 6);
      }
    });
  }
  player.fallApartUntil = performance.now() + 1200;
  setTimeout(() => {
    if (character) {
      character.traverse(c => {
        if (c.isMesh && c.userData._origPos) {
          c.position.copy(c.userData._origPos);
          delete c.userData._vel; delete c.userData._origPos;
        }
      });
    }
    respawnPlayer();
  }, 1200);
}
function respawnPlayer() {
  player.x = SPAWN.x; player.y = SPAWN.y; player.z = SPAWN.z;
  player.vy = 0; player.health = player.maxHealth; player.dead = false; player.onGround = true;
  healthBar.style.width = '100%';
  healthBar.classList.remove('damaged');
  healthWrap.classList.remove('show');
  characterRoot.position.set(player.x, player.y, player.z);
  characterRoot.rotation.y = player.yaw;
}

const platforms = [];
function addBox(x, y, z, sx, sy, sz, color, receive = true) {
  const mesh = new THREE.Mesh(
    new THREE.BoxGeometry(sx, sy, sz),
    new THREE.MeshStandardMaterial({ color, roughness: 0.85 })
  );
  mesh.position.set(x, y, z);
  mesh.castShadow = true;
  mesh.receiveShadow = receive;
  scene.add(mesh);
  platforms.push({ x, y, z, sx, sy, sz, mesh, hazard: sx < 2 && sy > 1.5 });
  return mesh;
}

async function buildBaseplate() {
  const texLoader = new THREE.TextureLoader();
  let tex = null;
  try {
    tex = await new Promise((res, rej) => texLoader.load(ASSETS.baseplateTex, res, undefined, rej));
    tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(24, 24);
    tex.colorSpace = THREE.SRGBColorSpace;
  } catch { tex = null; }
  let loadedObj = false;
  try {
    const obj = await new Promise((res, rej) => new OBJLoader().load(ASSETS.baseplateObj, res, undefined, rej));
    const mat = new THREE.MeshStandardMaterial({ color: tex ? 0xffffff : 0x6a6a6a, map: tex, roughness: 0.92, metalness: 0.05 });
    obj.traverse(c => { if (c.isMesh) { c.material = mat; c.receiveShadow = true; } });
    const box = new THREE.Box3().setFromObject(obj);
    const size = new THREE.Vector3(); box.getSize(size);
    obj.scale.setScalar(80 / (Math.max(size.x, size.z) || 1));
    box.setFromObject(obj);
    obj.position.y -= box.min.y;
    scene.add(obj);
    platforms.push({ x: 0, y: -0.05, z: 0, sx: 80, sy: 0.2, sz: 80, mesh: obj, hazard: false });
    loadedObj = true;
  } catch (e) { console.warn(e); }
  if (!loadedObj) {
    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(80, 80),
      new THREE.MeshStandardMaterial({ color: tex ? 0xffffff : 0x4a7a4a, map: tex, roughness: 0.9 })
    );
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);
    platforms.push({ x: 0, y: -0.05, z: 0, sx: 80, sy: 0.1, sz: 80, mesh: ground, hazard: false });
  }
}

function buildObby() {
  [
    [0, 0.5, 10, 5, 1, 4, 0x5a8cc8],
    [0, 1.3, 16, 4, 1, 3.5, 0x5a96d0],
    [4, 2.2, 21, 3.5, 1, 3, 0x64a0c8],
    [7, 3.1, 26, 3, 1, 3, 0x6e96be],
    [3, 4.0, 31, 2.8, 1, 2.8, 0x78a0b4],
    [0, 4.9, 36, 3.2, 1, 3, 0x64aa96],
    [-4, 5.8, 41, 2.6, 1, 2.6, 0x5ab496],
    [-1, 6.7, 46, 2.4, 1, 2.4, 0x50be8c],
    [2, 7.6, 50, 2.8, 1, 2.8, 0x64b482],
    [0, 8.5, 55, 4.5, 1, 4.5, 0xffc850],
  ].forEach(p => addBox(...p));
  addBox(8, 1.8, 22, 1.4, 2.5, 1.4, 0xdc5050);
  addBox(-6, 3.5, 38, 1.4, 2.2, 1.4, 0xdc5050);
}

// Character parts for procedural animation (like Humanoid limbs)
let charParts = { torso: null, head: null, legL: null, legR: null, armL: null, armR: null };
let animState = 'idle'; // idle | walk | jump
let animTime = 0;

function applyAvatarColor(root, hex) {
  if (!root) return;
  const col = new THREE.Color(hex || account.avatarColor || '#5b9dff');
  root.traverse(c => {
    if (c.isMesh && c.material) {
      const mats = Array.isArray(c.material) ? c.material : [c.material];
      mats.forEach(m => {
        if (m.color) m.color.copy(col);
        m.needsUpdate = true;
      });
    }
  });
}

function centerCharacterPivot(model) {
  // Pivot like HumanoidRootPart: centered in XZ, feet on ground (Y=0)
  const box = new THREE.Box3().setFromObject(model);
  const size = new THREE.Vector3();
  box.getSize(size);
  const center = new THREE.Vector3();
  box.getCenter(center);
  // Target height ~2.0 units
  const targetH = 2.0;
  const s = targetH / (size.y || 1);
  model.scale.setScalar(s);
  box.setFromObject(model);
  box.getCenter(center);
  box.getSize(size);
  // Center XZ, put feet at y=0
  model.position.x -= center.x;
  model.position.z -= center.z;
  model.position.y -= box.min.y;
  return model;
}

function tagCharParts(root) {
  charParts = { torso: null, head: null, legL: null, legR: null, armL: null, armR: null };
  const names = [];
  root.traverse(c => {
    if (c.name) names.push(c.name.toLowerCase());
    const n = (c.name || '').toLowerCase();
    if (!charParts.torso && (n.includes('torso') || n.includes('body') || n.includes('chest'))) charParts.torso = c;
    if (!charParts.head && (n.includes('head') || n.includes('face'))) charParts.head = c;
    if (!charParts.legL && (n.includes('left leg') || n.includes('leg_l') || n.includes('leftleg') || n === 'left leg')) charParts.legL = c;
    if (!charParts.legR && (n.includes('right leg') || n.includes('leg_r') || n.includes('rightleg') || n === 'right leg')) charParts.legR = c;
    if (!charParts.armL && (n.includes('left arm') || n.includes('arm_l') || n.includes('leftarm'))) charParts.armL = c;
    if (!charParts.armR && (n.includes('right arm') || n.includes('arm_r') || n.includes('rightarm'))) charParts.armR = c;
  });
  // Fallback: use children groups by order if names missing
  if (!charParts.torso && root.children.length) {
    root.children.forEach((ch, i) => {
      const n = (ch.name || '').toLowerCase();
      if (n.includes('torso') || n.includes('body')) charParts.torso = ch;
      else if (n.includes('leg') && !charParts.legL) charParts.legL = ch;
      else if (n.includes('leg') && !charParts.legR) charParts.legR = ch;
    });
  }
  // Store base rotations for anim
  Object.keys(charParts).forEach(k => {
    const p = charParts[k];
    if (p) {
      p.userData.baseRot = p.rotation.clone();
      p.userData.basePos = p.position.clone();
    }
  });
}

function updateCharacterAnim(dt, moving, onGround) {
  if (!character) return;
  animTime += dt;
  if (!onGround) animState = 'jump';
  else if (moving) animState = 'walk';
  else animState = 'idle';

  const t = animTime;
  const legs = [charParts.legL, charParts.legR].filter(Boolean);
  const arms = [charParts.armL, charParts.armR].filter(Boolean);

  if (animState === 'idle') {
    // gentle bob
    const bob = Math.sin(t * 2.2) * 0.02;
    if (charParts.torso) {
      charParts.torso.rotation.x = (charParts.torso.userData.baseRot?.x || 0) + bob * 0.5;
      charParts.torso.position.y = (charParts.torso.userData.basePos?.y || 0) + Math.abs(bob) * 0.3;
    }
    legs.forEach((leg, i) => {
      if (!leg.userData.baseRot) return;
      leg.rotation.x = leg.userData.baseRot.x + Math.sin(t * 1.5 + i * Math.PI) * 0.04;
    });
    arms.forEach((arm, i) => {
      if (!arm.userData.baseRot) return;
      arm.rotation.x = arm.userData.baseRot.x + Math.sin(t * 1.2 + i) * 0.06;
    });
  } else if (animState === 'walk') {
    const swing = Math.sin(t * 10) * 0.55;
    legs.forEach((leg, i) => {
      if (!leg.userData.baseRot) return;
      const s = i === 0 ? swing : -swing;
      leg.rotation.x = leg.userData.baseRot.x + s;
    });
    arms.forEach((arm, i) => {
      if (!arm.userData.baseRot) return;
      const s = i === 0 ? -swing * 0.7 : swing * 0.7;
      arm.rotation.x = arm.userData.baseRot.x + s;
    });
    if (charParts.torso) {
      charParts.torso.rotation.y = (charParts.torso.userData.baseRot?.y || 0) + Math.sin(t * 10) * 0.04;
      charParts.torso.position.y = (charParts.torso.userData.basePos?.y || 0) + Math.abs(Math.sin(t * 10)) * 0.04;
    }
  } else if (animState === 'jump') {
    legs.forEach(leg => {
      if (!leg.userData.baseRot) return;
      leg.rotation.x = leg.userData.baseRot.x - 0.35;
    });
    arms.forEach(arm => {
      if (!arm.userData.baseRot) return;
      arm.rotation.x = arm.userData.baseRot.x - 0.5;
    });
    if (charParts.torso) {
      charParts.torso.rotation.x = (charParts.torso.userData.baseRot?.x || 0) - 0.08;
    }
  }
}

async function loadCharacter() {
  // clear previous
  if (character) {
    characterRoot.remove(character);
    character = null;
  }
  const gender = (account.gender === 'girl' || account.gender === 'female') ? 'girl' : 'boy';
  const url = gender === 'girl' ? ASSETS.girl : ASSETS.boy;
  try {
    const obj = await new Promise((res, rej) => {
      new OBJLoader().load(url, res, (xhr) => {
        if (xhr.total) document.getElementById('load-prog').style.width = Math.min(90, 55 + (xhr.loaded / xhr.total) * 35) + '%';
      }, rej);
    });
    // Ensure materials exist
    obj.traverse(c => {
      if (c.isMesh) {
        c.castShadow = true;
        c.receiveShadow = true;
        if (!c.material || !c.material.color) {
          c.material = new THREE.MeshStandardMaterial({ color: 0x5b9dff, roughness: 0.45, metalness: 0.1 });
        } else if (c.material) {
          c.material = c.material.clone ? c.material.clone() : c.material;
          if (!c.material.color) c.material.color = new THREE.Color(0x5b9dff);
        }
      }
    });
    character = centerCharacterPivot(obj);
    tagCharParts(character);
    applyAvatarColor(character, account.avatarColor || account.chatColor);
    characterRoot.add(character);
  } catch (e) {
    console.warn('OBJ load failed, using simple avatar', e);
    character = createSimpleAvatar(account.avatarColor || account.chatColor || '#5b9dff');
    centerCharacterPivot(character);
    tagCharParts(character);
    characterRoot.add(character);
  }
}

// Character collision capsule (CanCollide = true — cannot walk through parts)
const CHAR_RADIUS = 0.45;
const CHAR_HEIGHT = 1.85;
const CHAR_STEP = 0.55; // max step-up height

function platformTop(nx, ny, nz) {
  const r = CHAR_RADIUS;
  let best = null;
  for (const p of platforms) {
    if (p.hazard) continue;
    const top = p.y + p.sy / 2;
    if (Math.abs(nx - p.x) < p.sx / 2 + r && Math.abs(nz - p.z) < p.sz / 2 + r) {
      if (ny <= top + 0.5 && ny >= top - 1.0) {
        if (best === null || top > best) best = top;
      }
    }
  }
  return best;
}

/** True if character AABB at (nx,ny,nz) overlaps a solid non-hazard part */
function overlapsSolid(nx, ny, nz) {
  const feet = ny;
  const head = ny + CHAR_HEIGHT;
  const r = CHAR_RADIUS;
  for (const p of platforms) {
    if (p.hazard) continue;
    // thin ground planes: only stand on them, don't treat as side walls if very flat
    const isThinFloor = p.sy <= 0.35;
    const px0 = p.x - p.sx / 2, px1 = p.x + p.sx / 2;
    const pz0 = p.z - p.sz / 2, pz1 = p.z + p.sz / 2;
    const py0 = p.y - p.sy / 2, py1 = p.y + p.sy / 2;
    if (nx + r <= px0 || nx - r >= px1) continue;
    if (nz + r <= pz0 || nz - r >= pz1) continue;
    if (head <= py0 || feet >= py1) continue;
    if (isThinFloor) {
      // only block if trying to sink into the floor volume
      if (feet < py1 && feet > py0 - 0.05 && head > py1) continue; // standing on top ok
      if (feet >= py1 - 0.02) continue;
    }
    return true;
  }
  return false;
}

/** Resolve horizontal move so character cannot go through parts */
function resolveMove(fromX, fromZ, toX, toZ, y) {
  // try full move
  if (!overlapsSolid(toX, y, toZ)) return { x: toX, z: toZ };
  // try X only
  if (!overlapsSolid(toX, y, fromZ)) return { x: toX, z: fromZ };
  // try Z only
  if (!overlapsSolid(fromX, y, toZ)) return { x: fromX, z: toZ };
  // blocked
  return { x: fromX, z: fromZ };
}

function nearHazard(nx, nz) {
  for (const p of platforms) {
    if (!p.hazard) continue;
    if (Math.abs(nx - p.x) < p.sx / 2 + CHAR_RADIUS && Math.abs(nz - p.z) < p.sz / 2 + CHAR_RADIUS) {
      if (player.y < p.y + p.sy / 2 + 0.5 && player.y > p.y - p.sy / 2 - 0.3) return true;
    }
  }
  return false;
}

const MOVE_SPEED = 7, JUMP_SPEED = 10, GRAVITY = 24;
let showJoystick = account.settings.joystick !== false;

function updatePlayer(dt) {
  if (player.dead) {
    if (character && performance.now() < player.fallApartUntil) {
      character.traverse(c => {
        if (c.isMesh && c.userData._vel) {
          c.position.x += c.userData._vel.x * dt;
          c.position.y += c.userData._vel.y * dt;
          c.position.z += c.userData._vel.z * dt;
          c.userData._vel.y -= GRAVITY * dt * 0.5;
        }
      });
    }
    characterRoot.position.set(player.x, player.y, player.z);
    return;
  }

  let fx = 0, fz = 0;
  // Keyboard relative to camera
  if (keys['KeyW'] || keys['ArrowUp']) fz += 1;
  if (keys['KeyS'] || keys['ArrowDown']) fz -= 1;
  if (keys['KeyA'] || keys['ArrowLeft']) fx -= 1;
  if (keys['KeyD'] || keys['ArrowRight']) fx += 1;

  // Joystick NOT inverted:
  // Screen Up → forward (away from camera), Down → back, Left/Right → strafe
  if (joyActive) {
    fx += joyDX;        // right = +1
    fz += -joyDY;       // up (negative screen dy) → +forward
  }

  const mag = Math.hypot(fx, fz);
  if (mag > 1) { fx /= mag; fz /= mag; }
  const moving = mag > 0.08;

  const sy = Math.sin(player.yaw);
  const cy = Math.cos(player.yaw);
  // Camera sits behind player at +Z when yaw=0 and looks toward -Z.
  // Forward must move the player in -Z, not +Z (that was the invert bug).
  const mx = fx * cy + fz * sy;
  const mz = fx * sy - fz * cy;

  // Horizontal move with solid collision (CanCollide = true)
  const step = MOVE_SPEED * dt;
  const wantX = player.x + mx * step;
  const wantZ = player.z + mz * step;
  // Allow small step-up onto ledges while moving
  let moveY = player.y;
  const stepTop = platformTop(wantX, player.y + CHAR_STEP, wantZ);
  if (stepTop !== null && stepTop > player.y && stepTop - player.y <= CHAR_STEP && player.onGround) {
    moveY = stepTop;
  }
  const resolved = resolveMove(player.x, player.z, wantX, wantZ, moveY);
  player.x = resolved.x;
  player.z = resolved.z;
  if (moveY > player.y) player.y = moveY;

  // Vertical gravity + floor / ceiling collision
  player.vy -= GRAVITY * dt;
  const nextY = player.y + player.vy * dt;

  // Ceiling: hit underside of solid parts
  if (player.vy > 0) {
    const head = nextY + CHAR_HEIGHT;
    let hitCeil = null;
    for (const p of platforms) {
      if (p.hazard || p.sy <= 0.35) continue;
      const py0 = p.y - p.sy / 2;
      if (Math.abs(player.x - p.x) < p.sx / 2 + CHAR_RADIUS &&
          Math.abs(player.z - p.z) < p.sz / 2 + CHAR_RADIUS) {
        if (player.y + CHAR_HEIGHT <= py0 + 0.05 && head > py0) {
          if (hitCeil === null || py0 < hitCeil) hitCeil = py0;
        }
      }
    }
    if (hitCeil !== null) {
      player.y = hitCeil - CHAR_HEIGHT;
      player.vy = 0;
    } else {
      player.y = nextY;
    }
  } else {
    player.y = nextY;
  }

  const top = platformTop(player.x, player.y, player.z);
  if (top !== null && player.vy <= 0) {
    player.y = top;
    player.vy = 0;
    player.onGround = true;
  } else if (player.y < -5) {
    takeDamage(player.health + 1);
  } else {
    player.onGround = false;
  }

  // Push out if somehow embedded in a solid
  if (overlapsSolid(player.x, player.y, player.z)) {
    const dirs = [[0.2,0],[-0.2,0],[0,0.2],[0,-0.2],[0.3,0.3],[-0.3,0.3],[0.3,-0.3],[-0.3,-0.3]];
    for (const [dx, dz] of dirs) {
      if (!overlapsSolid(player.x + dx, player.y, player.z + dz)) {
        player.x += dx; player.z += dz; break;
      }
    }
  }

  if (nearHazard(player.x, player.z)) {
    const now = performance.now();
    if (now - lastHazardHit > 600) {
      lastHazardHit = now;
      takeDamage(15);
    }
  }

  // Face camera direction always
  characterRoot.rotation.y = player.yaw;
  characterRoot.position.set(player.x, player.y, player.z);
  nameTag.visible = account.settings.showNames !== false;

  // New procedural Idle / Walk / Jump animations
  updateCharacterAnim(dt, moving, player.onGround);

  pushPlayerState();
}

function updateCamera() {
  const pitch = camPitch, dist = camDist;
  const ox = Math.sin(player.yaw) * Math.cos(pitch) * dist;
  const oy = -Math.sin(pitch) * dist + 1.6;
  const oz = Math.cos(player.yaw) * Math.cos(pitch) * dist;
  camera.position.set(player.x + ox, player.y + oy, player.z + oz);
  camera.lookAt(player.x, player.y + 1.4, player.z);
}

function doJump() {
  if (player.onGround && !player.dead) {
    player.vy = JUMP_SPEED;
    player.onGround = false;
  }
}

// Input
window.addEventListener('keydown', e => {
  keys[e.code] = true;
  if (e.code === 'Space') { e.preventDefault(); doJump(); }
  if (e.code === 'Escape' && gameRunning) toggleMenu();
  if (e.code === 'Enter' && gameRunning) {
    const inp = document.getElementById('chat-input');
    if (document.activeElement !== inp) { inp.focus(); e.preventDefault(); }
  }
});
window.addEventListener('keyup', e => { keys[e.code] = false; });

const sens = () => (account.settings.sensitivity || 1) * 0.005;

canvas.addEventListener('pointerdown', e => {
  if (!gameRunning || menuOpen) return;
  if (e.pointerType === 'touch') return;
  pointerLook = true;
  lastPX = e.clientX; lastPY = e.clientY;
  canvas.setPointerCapture?.(e.pointerId);
});
canvas.addEventListener('pointermove', e => {
  if (!pointerLook || !gameRunning || menuOpen) return;
  const dx = e.clientX - lastPX, dy = e.clientY - lastPY;
  lastPX = e.clientX; lastPY = e.clientY;
  player.yaw -= dx * sens();
  camPitch = Math.max(-1.2, Math.min(0.4, camPitch - dy * sens() * 0.8));
});
canvas.addEventListener('pointerup', () => { pointerLook = false; });
canvas.addEventListener('pointercancel', () => { pointerLook = false; });
canvas.addEventListener('wheel', e => {
  if (!gameRunning) return;
  e.preventDefault();
  camDist = Math.max(CAM_MIN, Math.min(CAM_MAX, camDist + e.deltaY * 0.01));
}, { passive: false });

const activeTouches = new Map();
canvas.addEventListener('touchstart', e => {
  if (!gameRunning || menuOpen) return;
  for (const t of e.changedTouches) activeTouches.set(t.identifier, { x: t.clientX, y: t.clientY });
  if (activeTouches.size === 2) {
    pinchActive = true;
    const pts = [...activeTouches.values()];
    pinchStartDist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
    pinchStartCam = camDist;
    pointerLook = false;
  } else if (activeTouches.size === 1) {
    const t = e.changedTouches[0];
    pointerLook = true; lastPX = t.clientX; lastPY = t.clientY;
  }
}, { passive: true });
canvas.addEventListener('touchmove', e => {
  if (!gameRunning || menuOpen) return;
  e.preventDefault();
  for (const t of e.changedTouches) {
    if (activeTouches.has(t.identifier)) activeTouches.set(t.identifier, { x: t.clientX, y: t.clientY });
  }
  if (pinchActive && activeTouches.size >= 2) {
    const pts = [...activeTouches.values()];
    const dist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
    if (pinchStartDist > 0) camDist = Math.max(CAM_MIN, Math.min(CAM_MAX, pinchStartCam * (pinchStartDist / dist)));
  } else if (pointerLook && activeTouches.size === 1) {
    const t = e.changedTouches[0];
    const dx = t.clientX - lastPX, dy = t.clientY - lastPY;
    lastPX = t.clientX; lastPY = t.clientY;
    player.yaw -= dx * sens();
    camPitch = Math.max(-1.2, Math.min(0.4, camPitch - dy * sens() * 0.8));
  }
}, { passive: false });
canvas.addEventListener('touchend', e => {
  for (const t of e.changedTouches) activeTouches.delete(t.identifier);
  if (activeTouches.size < 2) pinchActive = false;
  if (activeTouches.size === 0) pointerLook = false;
  if (activeTouches.size === 1) {
    const r = [...activeTouches.values()][0];
    lastPX = r.x; lastPY = r.y; pointerLook = true;
  }
});
canvas.addEventListener('touchcancel', e => {
  for (const t of e.changedTouches) activeTouches.delete(t.identifier);
  pinchActive = false; pointerLook = false;
});

document.getElementById('jump-btn').addEventListener('pointerdown', e => {
  e.preventDefault(); e.stopPropagation(); doJump();
});
document.getElementById('jump-btn').addEventListener('touchstart', e => {
  e.preventDefault(); e.stopPropagation(); doJump();
}, { passive: false });
// Prevent swipe-through lag on HUD buttons
['menu-toggle', 'chat-toggle', 'jump-btn'].forEach(id => {
  const el = document.getElementById(id);
  if (!el) return;
  el.addEventListener('touchmove', e => { e.preventDefault(); e.stopPropagation(); }, { passive: false });
});

// ===== JOYSTICK (perfect mapping) =====
const joyZone = document.getElementById('joystick-zone');
const joyBase = document.getElementById('joystick-base');
const joyKnob = document.getElementById('joystick-knob');
let JOY_R = 45;

function updateJoyRadius() {
  const rect = joyBase.getBoundingClientRect();
  JOY_R = Math.min(rect.width, rect.height) * 0.38;
}

function setKnob(dx, dy) {
  // Use transform so it never "flips" or jumps due to %/px mix
  joyKnob.style.left = '50%';
  joyKnob.style.top = '50%';
  joyKnob.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
}

function updateJoy(cx, cy) {
  const rect = joyBase.getBoundingClientRect();
  const cx0 = rect.left + rect.width / 2;
  const cy0 = rect.top + rect.height / 2;
  let dx = cx - cx0;
  let dy = cy - cy0;
  const m = Math.hypot(dx, dy);
  if (m > JOY_R) {
    dx = (dx / m) * JOY_R;
    dy = (dy / m) * JOY_R;
  }
  setKnob(dx, dy);
  // Normalized: right = +1, down = +1
  // Up (negative dy on screen) → forward (positive fz)
  joyDX = dx / JOY_R;
  joyDY = dy / JOY_R;
}

function joyEnd() {
  joyActive = false;
  joyDX = 0;
  joyDY = 0;
  joyKnob.style.left = '50%';
  joyKnob.style.top = '50%';
  joyKnob.style.transform = 'translate(-50%, -50%)';
}

joyZone.addEventListener('pointerdown', e => {
  if (!gameRunning || menuOpen || !showJoystick) return;
  if (e.pointerType === 'mouse' && e.button !== 0) return;
  e.preventDefault();
  e.stopPropagation();
  joyActive = true;
  updateJoyRadius();
  updateJoy(e.clientX, e.clientY);
  joyZone.setPointerCapture?.(e.pointerId);
});
joyZone.addEventListener('pointermove', e => {
  if (!joyActive) return;
  e.preventDefault();
  updateJoy(e.clientX, e.clientY);
});
joyZone.addEventListener('pointerup', e => { joyEnd(); });
joyZone.addEventListener('pointercancel', e => { joyEnd(); });
joyZone.addEventListener('pointerleave', e => {
  if (joyActive && e.pointerType === 'mouse') joyEnd();
});

// Chat UI
document.getElementById('chat-send').onclick = () => {
  const inp = document.getElementById('chat-input');
  sendChat(inp.value);
  inp.value = '';
  inp.blur();
};
document.getElementById('chat-input').addEventListener('keydown', e => {
  if (e.code === 'Enter') {
    e.preventDefault();
    sendChat(e.target.value);
    e.target.value = '';
    e.target.blur();
  }
  e.stopPropagation();
});

// Voice to text
let recognition = null;
const micBtn = document.getElementById('chat-mic');
micBtn.onclick = () => {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) { alert('Voice input not supported in this browser'); return; }
  if (recognition) {
    recognition.stop();
    recognition = null;
    micBtn.classList.remove('listening');
    return;
  }
  recognition = new SR();
  recognition.lang = 'en-US';
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;
  recognition.onresult = (ev) => {
    const text = ev.results[0][0].transcript;
    document.getElementById('chat-input').value = text;
    sendChat(text);
    document.getElementById('chat-input').value = '';
  };
  recognition.onerror = () => { micBtn.classList.remove('listening'); recognition = null; };
  recognition.onend = () => { micBtn.classList.remove('listening'); recognition = null; };
  micBtn.classList.add('listening');
  recognition.start();
};

// Menu
let gameRunning = false;
let menuOpen = false;
function toggleMenu() {
  menuOpen = !menuOpen;
  document.getElementById('game-menu').classList.toggle('open', menuOpen);
}
document.getElementById('menu-toggle').onclick = toggleMenu;
document.getElementById('chat-toggle')?.addEventListener('click', () => {
  const panel = document.getElementById('chat-panel');
  panel.classList.toggle('hidden');
});
document.getElementById('menu-settings-btn')?.addEventListener('click', () => {
  const panel = document.getElementById('menu-settings-panel');
  if (panel) panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
});
document.getElementById('menu-resume').onclick = () => {
  menuOpen = false;
  document.getElementById('game-menu').classList.remove('open');
};
document.getElementById('menu-respawn').onclick = () => {
  menuOpen = false;
  document.getElementById('game-menu').classList.remove('open');
  respawnPlayer();
};
document.getElementById('menu-invite').onclick = () => {
  const url = location.href;
  if (navigator.share) navigator.share({ title: "DoLex Obby's", url }).catch(() => {});
  else if (navigator.clipboard) navigator.clipboard.writeText(url).then(() => alert('Link copied!')).catch(() => alert(url));
  else alert(url);
};
document.getElementById('menu-close').onclick = () => {
  menuOpen = false;
  document.getElementById('game-menu').classList.remove('open');
  endGame();
};

document.getElementById('set-joystick').onchange = (e) => {
  showJoystick = e.target.checked;
  account.settings.joystick = showJoystick;
  save(account);
  joyBase.style.display = showJoystick && gameRunning ? 'block' : 'none';
};
document.getElementById('set-sound').onchange = (e) => { account.settings.sound = e.target.checked; save(account); };
document.getElementById('set-music').onchange = (e) => { account.settings.music = e.target.checked; save(account); };
document.getElementById('set-chat').onchange = (e) => {
  account.settings.chat = e.target.checked;
  save(account);
  document.getElementById('chat-panel').classList.toggle('hidden', !e.target.checked);
};
document.getElementById('set-theme').onchange = (e) => applyTheme(e.target.value);
document.getElementById('set-volume')?.addEventListener('input', (e) => {
  account.settings.volume = parseFloat(e.target.value);
  save(account);
});
document.getElementById('set-music-vol')?.addEventListener('input', (e) => {
  account.settings.musicVol = parseFloat(e.target.value);
  save(account);
});
document.getElementById('set-qol')?.addEventListener('input', (e) => {
  account.settings.qol = parseInt(e.target.value, 10);
  save(account);
  applyQol(account.settings.qol);
});

/** Home / lobby = Portrait · 3D in-game = Landscape */
function lockOrientation(mode) {
  document.documentElement.classList.toggle('mode-portrait', mode === 'portrait');
  document.documentElement.classList.toggle('mode-landscape', mode === 'landscape');
  document.body.classList.toggle('mode-portrait', mode === 'portrait');
  document.body.classList.toggle('mode-landscape', mode === 'landscape');
  const hint = document.getElementById('orient-hint');
  if (hint) {
    hint.classList.toggle('hint-portrait', mode === 'portrait');
    hint.classList.toggle('hint-landscape', mode === 'landscape');
    const title = document.getElementById('orient-hint-title');
    const sub = document.getElementById('orient-hint-sub');
    if (mode === 'portrait') {
      if (title) title.textContent = 'Rotate to Portrait';
      if (sub) sub.textContent = 'Home screen works best in portrait mode.';
    } else {
      if (title) title.textContent = 'Rotate to Landscape';
      if (sub) sub.textContent = 'Play in landscape for the best 3D view.';
    }
  }
  const orient = screen.orientation;
  if (orient && typeof orient.lock === 'function') {
    const target = mode === 'landscape' ? 'landscape' : 'portrait';
    orient.lock(target).catch(() => {
      try { orient.lock(target + '-primary').catch(() => {}); } catch (_) {}
    });
  }
  resizeRenderer();
}

function resizeRenderer() {
  const w = window.innerWidth, h = window.innerHeight;
  if (typeof camera !== 'undefined' && camera) {
    camera.aspect = w / Math.max(h, 1);
    camera.updateProjectionMatrix();
  }
  if (typeof renderer !== 'undefined' && renderer) renderer.setSize(w, h);
}

function startGame() {
  if (!checkBrowserOnline() || !netConnected) {
    showOfflineGate('You must be online to play.');
    return;
  }
  stopAvatarPreview();
  account.game_visits = (account.game_visits || 0) + 1;
  save(account);
  document.getElementById('ui-root').style.display = 'none';
  document.getElementById('hud').classList.add('active');
  document.getElementById('loading-screen').classList.remove('hidden');
  document.getElementById('load-status').textContent = "Joining DoLex Obby's…";
  document.getElementById('load-prog').style.width = '100%';

  // In-game 3D → Landscape
  lockOrientation('landscape');

  respawnPlayer();
  player.yaw = 0;
  updateLexUI();
  drawNameTag(account.username);
  nameTagTex.needsUpdate = true;
  document.getElementById('chat-messages').innerHTML = '';
  document.getElementById('chat-panel').classList.toggle('hidden', account.settings.chat === false);

  subscribePlayers();

  setTimeout(() => {
    document.getElementById('loading-screen').classList.add('hidden');
    gameRunning = true;
    showJoystick = account.settings.joystick !== false;
    joyBase.style.display = showJoystick ? 'block' : 'none';
    document.getElementById('set-joystick').checked = showJoystick;
    document.getElementById('set-sound').checked = account.settings.sound !== false;
    document.getElementById('set-music').checked = !!account.settings.music;
    document.getElementById('set-chat').checked = account.settings.chat !== false;
    document.getElementById('set-theme').value = account.settings.theme || 'dark';
    if (gun) {
      gun.get('dolex').get('presence').get(account.user_id).put({
        id: account.user_id, username: account.username, color: account.chatColor, inGame: true, t: Date.now()
      });
    }
    recountPresence();
    resizeRenderer();
  }, 800);
}

function endGame() {
  gameRunning = false;
  menuOpen = false;
  leaveMultiplayerPresence();
  clearRemotePlayers();
  if (gun) {
    gun.get('dolex').get('presence').get(account.user_id).put({
      id: account.user_id, username: account.username, color: account.chatColor, inGame: false, t: Date.now()
    });
  }
  document.getElementById('hud').classList.remove('active');
  document.getElementById('game-menu').classList.remove('open');
  document.getElementById('ui-root').style.display = '';
  // Home screen → Portrait
  lockOrientation('portrait');
  showScreen('lobby');
  renderHome();
  recountPresence();
  resizeRenderer();
}

document.getElementById('btn-play').onclick = startGame;

window.addEventListener('online', () => {
  hideOfflineGate();
  connectNetwork();
});
window.addEventListener('offline', () => {
  if (gameRunning) showDisconnect('Internet connection lost', ERROR_CODES.OFFLINE);
  else showOfflineGate('Internet connection lost.');
  leaveMultiplayerPresence();
  stopHeartbeat();
});

window.addEventListener('resize', () => {
  resizeRenderer();
});

window.addEventListener('orientationchange', () => {
  setTimeout(resizeRenderer, 100);
});

window.addEventListener('beforeunload', () => {
  leaveMultiplayerPresence();
});

let last = performance.now();
function loop(now) {
  requestAnimationFrame(loop);
  const dt = Math.min(0.05, (now - last) / 1000);
  last = now;

  updateDayNight(dt);

  if (gameRunning && !menuOpen && netConnected) {
    updatePlayer(dt);
    updateCamera();
    updateChatBubbles(now);
    if (now - lastRegen > 1000) {
      lastRegen = now;
      if (player.health < player.maxHealth && player.health > 0 && !player.dead) setHealth(player.health + 2);
    }
    if (player.health >= player.maxHealth && now > healthVisibleUntil) healthWrap.classList.remove('show');
    if (now > damageFxUntil) damageFx.classList.remove('show');
  } else if (!gameRunning) {
    camera.position.set(8, 6, 12);
    camera.lookAt(0, 1, 0);
  }

  renderer.render(scene, camera);
}

async function boot() {
  // Start on Home → Portrait
  lockOrientation('portrait');
  applyTheme(account.settings?.theme || 'dark');
  applyGraphics(account.settings?.graphics || 'medium');
  applyQol(account.settings?.qol || 100);
  initAuthUI();
  initDrawer();
  document.getElementById('load-prog').style.width = '5%';
  document.getElementById('load-status').textContent = 'Connecting…';

  connectNetwork();

  document.getElementById('load-prog').style.width = '15%';
  await buildBaseplate();
  document.getElementById('load-prog').style.width = '40%';
  buildObby();
  document.getElementById('load-prog').style.width = '55%';
  await loadCharacter();
  document.getElementById('load-prog').style.width = '100%';
  characterRoot.position.set(SPAWN.x, SPAWN.y, SPAWN.z);
  updateCamera();
  setTimeout(() => {
    document.getElementById('loading-screen').classList.add('hidden');
    if (!checkBrowserOnline()) showOfflineGate('No internet connection.');
    // Auth gate: first play or not signed in
    if (isLoggedIn && account.username && account.password) {
      enterLobby();
    } else {
      document.getElementById('ui-root')?.classList.add('hidden');
      showAuthScreen('auth-landing');
    }
    updateLexUI();
  }, 500);
  requestAnimationFrame(loop);
}

boot();
