खर्च वही – Mobile App (PWA)

Features:
- नाश्ता / डिझेल / इतर खर्च
- तारीख, रक्कम, तपशील
- फोटोसहित नोंद सेव्ह
- एकूण, नाश्ता आणि डिझेलचा हिशोब
- WhatsApp वर formatted हिसाब पाठवा
- Offline वापरासाठी PWA cache

Mobile install:
1. हे files एका web hosting वर upload करा.
2. Chrome मध्ये site उघडा.
3. Menu > Add to Home screen / Install app.

टीप: फोटो व नोंदी browser च्या local storage मध्ये असतात.
