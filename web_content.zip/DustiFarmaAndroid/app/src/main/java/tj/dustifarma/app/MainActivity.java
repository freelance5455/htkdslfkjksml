package tj.dustifarma.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(248, 248, 243));
        getWindow().setNavigationBarColor(Color.rgb(248, 248, 243));
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        );

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(248, 248, 243));
        webView.setVerticalScrollBarEnabled(true);
        webView.setHorizontalScrollBarEnabled(false);
        webView.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new NativeScannerBridge(), "DustiFarmaScanner");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class NativeScannerBridge {
        @JavascriptInterface
        public void startScan() {
            runOnUiThread(() -> launchNativeScanner());
        }
    }

    private void launchNativeScanner() {
        try {
            IntentIntegrator integrator = new IntentIntegrator(this);
            integrator.setDesiredBarcodeFormats(IntentIntegrator.ONE_D_CODE_TYPES);
            integrator.setPrompt("Штрихкоди доруро ба чорчӯба нигоҳ доред");
            integrator.setBeepEnabled(false);
            integrator.setOrientationLocked(false);
            integrator.initiateScan();
        } catch (Exception e) {
            sendScanError("Сканер кушода нашуд. Камераро дар танзимоти телефон иҷозат диҳед.");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            if (result.getContents() != null) {
                final String code = result.getContents();
                final String safe = org.json.JSONObject.quote(code);
                webView.post(() -> webView.evaluateJavascript(
                    "window.dustiFarmaNativeBarcode && window.dustiFarmaNativeBarcode(" + safe + ");", null
                ));
            } else {
                sendScanError("Сканкунӣ бекор карда шуд. Боз кӯшиш кунед.");
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void sendScanError(String message) {
        final String safe = org.json.JSONObject.quote(message);
        if (webView != null) {
            webView.post(() -> webView.evaluateJavascript(
                "window.dustiFarmaNativeScanError && window.dustiFarmaNativeScanError(" + safe + ");", null
            ));
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
