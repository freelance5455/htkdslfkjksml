Дӯстӣ Фарма — Android Studio project

This is an Android WebView project containing the HTML interface in app/src/main/assets/index.html.

How to build an APK:
1. Install Android Studio on a computer.
2. Open the extracted DustiFarmaAndroid folder in Android Studio.
3. Allow Gradle sync and install the required Android SDK (API 35).
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The APK will be under app/build/outputs/apk/debug/app-debug.apk.

Package: tj.dustifarma.app
Version: 1.0
Internet permission is not requested; the HTML is bundled locally.
Note: This project has not been compiled or tested on a physical Android device in this environment.


APP ICON
The generated Dusti Farma teal-and-white logo is installed as the Android launcher icon in mipmap density folders. The source image is app/src/main/assets/dustifarma_app_icon.png.
