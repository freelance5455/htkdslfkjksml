# Sevgilim Offline (Android Studio kaynak projesi)

Bu, çevrimdışı çalışan bir Android başlangıç projesidir. Sohbet cevapları önceden tanımlı kurallarla üretilir; internet veya çevrimiçi yapay zekâ kullanmaz. Mesajlar cihazdaki WebView localStorage alanında tutulur. Uygulama her açıldığında günlük sabah bildirimi için alarm kurar; bildirim izni Android tarafından istenebilir.

## APK oluşturma
1. Bilgisayara Android Studio'nun güncel sürümünü kur.
2. Bu ZIP'i çıkar ve Android Studio'da `SevgilimOffline` klasörünü aç.
3. Gradle senkronizasyonunun bitmesini bekle. İlk derlemede Android Gradle Plugin ve bağımlılıkları indirmek için internet gerekebilir.
4. `Build > Build Bundle(s) / APK(s) > Build APK(s)` seç.
5. APK genellikle `app/build/outputs/apk/debug/app-debug.apk` konumunda oluşur.
6. APK'yı telefona kopyala ve kurulum izni ver. Bildirimler için uygulama izin istediğinde onayla.

## Notlar
- Bu ZIP hazır bir APK değil, APK üretmek için Android Studio kaynak projesidir.
- Günlük bildirim saati şu an 08:00 olarak ayarlı. Android pil optimizasyonu bazı cihazlarda bildirimi geciktirebilir.
- Sohbet, serbest biçimli bir dil modeli değil; internet olmadan çalışabilsin diye basit, kural tabanlı bir prototiptir.
- Görsel, konsept görselinden kırpılmış bir taslak portredir; gerçek bir kişiye ait olduğu iddia edilmez.
