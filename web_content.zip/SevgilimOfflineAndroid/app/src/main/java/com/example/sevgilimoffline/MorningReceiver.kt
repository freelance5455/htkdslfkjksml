package com.example.sevgilimoffline

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

class MorningReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("morning", "Günaydın mesajları", NotificationManager.IMPORTANCE_DEFAULT))
        val messages = listOf(
            "Günaydın ❤️ Yeni günün güzel geçsin. Kendine iyi bak!",
            "Uyandın mı? ☀️ Bugün kendine güzel bir şey yapmayı unutma.",
            "Günaydın! 💗 Kahveni al, güne küçük bir gülümsemeyle başla.",
            "Yeni bir gün başladı 🌷 Umarım bugün yüzünü güldüren şeyler olur."
        )
        val index = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_YEAR) % messages.size
        val open = PendingIntent.getActivity(context, 101, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(context, "morning")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Sevgilim 💗")
            .setContentText(messages[index])
            .setStyle(NotificationCompat.BigTextStyle().bigText(messages[index]))
            .setContentIntent(open).setAutoCancel(true).build()
        nm.notify(200, notification)
        MainActivity.scheduleMorning(context)
    }
}
