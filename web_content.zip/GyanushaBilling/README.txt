GYANUSHA TENSILE BILLING - Android project
==========================================

Ye project aapka billing app ek asli Android app me daalta hai.
Isme PDF seedha phone ke File Manager me save hota hai:

    Downloads / Gyanusha Bills / (bill number).pdf

Android 10 ya upar: koi permission nahi chahiye.
Android 9 ya purane: app pehli baar khulne par storage permission maangega, "Allow" dabayein.

APK kaise banayein (Rasta 1: computer par, sabse aasan)
-------------------------------------------------------
1. Android Studio install karein (developer.android.com/studio).
2. File > Open > is GyanushaBilling folder ko chunein. Neeche "Sync" poora hone dein
   (pehli baar kuch minute lagte hain, internet chahiye).
3. Menu: Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Ban jane par "locate" dabayein. File hogi:
   app/build/outputs/apk/debug/app-debug.apk
5. Is APK ko phone me bhej kar install karein.

APK kaise banayein (Rasta 2: GitHub se, Android Studio ke bina)
---------------------------------------------------------------
1. GitHub par free account banayein aur naya repository banayein.
2. Is poore folder ki saari files (".github" folder samet) us repository me upload karein.
3. Repository me "Actions" tab > "Build APK" > "Run workflow".
4. 5-10 minute baad run khulkar neeche "Artifacts" se gyanusha-billing-apk download karein.
   Usme app-debug.apk milegi.

Zaroori baatein
---------------
- Bill ka PDF banane wale tool aur fonts internet se aate hain. App chalate waqt
  phone me internet hona chahiye.
- Bill ka data phone me hi save rehta hai (app delete karne par ya data clear karne par hat jata hai).
  Isliye Bills page se CSV export karke time-time par rakh lein.
- App ka html app/src/main/assets/index.html me hai. Naya html aaye to bas us file ko badal dein.
- App ka naam badalna ho to app/src/main/AndroidManifest.xml me android:label badlein.
