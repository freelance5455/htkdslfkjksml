package com.gyanusha.billing;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {

    private static final int REQ_STORAGE = 101;
    private static final String FOLDER = "Gyanusha Bills";
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);   // bill data save hone ke liye
        s.setAllowFileAccess(true);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new Bridge(), "GyanushaAndroid");

        // Android 9 aur purane: storage permission pehle hi maang lo.
        if (!hasLegacyPermission()) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
        }

        webView.loadUrl("file:///android_asset/index.html");
    }

    private boolean hasLegacyPermission() {
        if (Build.VERSION.SDK_INT > 28) {
            return true; // Android 10+ me Downloads me likhne ke liye permission nahi chahiye
        }
        return checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void toast(final String msg) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    /** HTML se "GyanushaAndroid.saveFile(name, mime, base64)" ke naam se bulaya jata hai. */
    private class Bridge {
        @JavascriptInterface
        public boolean saveFile(String name, String mime, String base64) {
            try {
                byte[] data = Base64.decode(base64, Base64.DEFAULT);
                String safe = name.replaceAll("[\\\\/:*?\"<>|]", "-");

                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.Downloads.DISPLAY_NAME, safe);
                    v.put(MediaStore.Downloads.MIME_TYPE, mime);
                    v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + FOLDER);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    if (uri == null) {
                        toast("File banane me dikkat aayi.");
                        return false;
                    }
                    OutputStream out = getContentResolver().openOutputStream(uri);
                    if (out == null) {
                        toast("File likhne me dikkat aayi.");
                        return false;
                    }
                    try {
                        out.write(data);
                    } finally {
                        out.close();
                    }
                } else {
                    if (!hasLegacyPermission()) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
                            }
                        });
                        toast("Storage permission Allow karein, phir dobara save dabayein.");
                        return false;
                    }
                    File dir = new File(Environment.getExternalStoragePublicDirectory(
                            Environment.DIRECTORY_DOWNLOADS), FOLDER);
                    if (!dir.exists() && !dir.mkdirs()) {
                        toast("Folder nahi ban paya.");
                        return false;
                    }
                    File f = new File(dir, safe);
                    FileOutputStream out = new FileOutputStream(f);
                    try {
                        out.write(data);
                    } finally {
                        out.close();
                    }
                    MediaScannerConnection.scanFile(MainActivity.this,
                            new String[]{f.getAbsolutePath()}, new String[]{mime}, null);
                }

                toast("PDF save hua: Downloads/" + FOLDER + "/" + safe);
                return true;
            } catch (Exception e) {
                toast("Save nahi hua: " + e.getMessage());
                return false;
            }
        }
    }
}
