# V65 direct bridge in-app picker fix

Version 2.31 / versionCode 35.

The Choose File button now calls AndroidDPM.pickImportFile() directly when the native bridge is available, instead of relying first on a hidden HTML input and WebChromeClient callback. The HTML input remains as a fallback for browser builds. The in-app picker empty-state view is now attached to the same FrameLayout as the file list so it can display correctly when no files are found.

Limitation: this picker lists supported files from the phone's Downloads collection; it is not a full device-wide document browser.
