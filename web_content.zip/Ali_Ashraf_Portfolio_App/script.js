const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];

const roles = {
  ar: ["طالب حاسبات وذكاء اصطناعي", "مطور ويب", "مصمم جرافيك", "مهتم بتحليل البيانات"],
  en: ["CS & AI Student", "Web Developer", "Graphic Designer", "Data Analytics Enthusiast"]
};
let lang = "ar";
let roleIndex = 0;
let roleTimer;

function setLanguage(next) {
  lang = next;
  const isArabic = lang === "ar";
  document.documentElement.lang = lang;
  document.documentElement.dir = isArabic ? "rtl" : "ltr";
  document.body.dir = isArabic ? "rtl" : "ltr";
  document.body.lang = lang;
  $("#langToggle").textContent = isArabic ? "EN" : "ع";
  $$("[data-ar][data-en]").forEach(el => {
    const value = el.dataset[lang];
    if (value !== undefined) el.innerHTML = value;
  });
  document.title = isArabic ? "Ali Ashraf | مطور برمجيات" : "Ali Ashraf | Software Developer";
  roleIndex = 0;
  startRoleCycle();
}
function startRoleCycle() {
  clearInterval(roleTimer);
  const el = $("#rotatingRole");
  const list = roles[lang];
  el.style.opacity = "0";
  setTimeout(() => { el.textContent = list[roleIndex % list.length]; el.style.opacity = "1"; }, 220);
  roleTimer = setInterval(() => {
    el.style.opacity = "0";
    setTimeout(() => {
      roleIndex = (roleIndex + 1) % list.length;
      el.textContent = list[roleIndex];
      el.style.opacity = "1";
    }, 220);
  }, 2700);
}
$("#rotatingRole").style.transition = "opacity .22s ease";
$("#langToggle").addEventListener("click", () => setLanguage(lang === "ar" ? "en" : "ar"));
$("#year").textContent = new Date().getFullYear();

$("#menuToggle").addEventListener("click", () => $("#navLinks").classList.toggle("open"));
$$(".nav-links a").forEach(link => link.addEventListener("click", () => $("#navLinks").classList.remove("open")));

$$(".filter-btn").forEach(btn => btn.addEventListener("click", () => {
  $$(".filter-btn").forEach(b => b.classList.remove("active"));
  btn.classList.add("active");
  const filter = btn.dataset.filter;
  $$(".project-card").forEach(card => {
    const show = filter === "all" || card.dataset.category === filter;
    card.classList.toggle("hidden", !show);
    if (show) {
      card.classList.remove("in-view");
      requestAnimationFrame(() => card.classList.add("in-view"));
    }
  });
}));

const revealObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add("in-view");
      revealObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });
$$(".reveal").forEach(el => revealObserver.observe(el));

const sections = $$("main section[id]");
const navObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      $$(".nav-links a").forEach(a => a.classList.toggle("active", a.getAttribute("href") === `#${entry.target.id}`));
    }
  });
}, { rootMargin: "-35% 0px -55% 0px" });
sections.forEach(section => navObserver.observe(section));

const backTop = $("#backTop");
window.addEventListener("scroll", () => backTop.classList.toggle("show", window.scrollY > 500), { passive: true });
backTop.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));

// Subtle pointer parallax for larger screens only.
const visual = $(".hero-visual");
if (window.matchMedia("(pointer:fine)").matches) {
  visual.addEventListener("pointermove", e => {
    const rect = visual.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - .5;
    const y = (e.clientY - rect.top) / rect.height - .5;
    const frame = $(".portrait-frame");
    frame.style.transform = `rotate(${2 + x * 3}deg) translate(${x * 5}px, ${y * 5}px)`;
  });
  visual.addEventListener("pointerleave", () => $(".portrait-frame").style.transform = "");
}
setLanguage("ar");
