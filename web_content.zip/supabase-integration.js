/* AlJoulaniGZ cloud integration. Requires supabase-config.js and Supabase JS v2 CDN. */
(() => {
  const cfg = window.GZ_SUPABASE_CONFIG || {};
  const configured = cfg.url && cfg.anonKey && !String(cfg.url).includes('PASTE_YOUR') && !String(cfg.anonKey).includes('PASTE_YOUR');
  let client = null, currentSession = null, cloudTemplateIds = new Set(), originalRenderFeed = null, verifiedUserIds = new Set();
  const $ = id => document.getElementById(id);
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const msg = (ar, en) => (typeof lang !== 'undefined' && lang === 'ar') ? ar : en;
  const ownerEmail = String(cfg.ownerEmail || '').trim().toLowerCase();
  const isOwner = () => !!currentSession?.user?.email && ownerEmail && currentSession.user.email.toLowerCase() === ownerEmail;
  const filePath = (uid, file) => `${uid}/${Date.now()}_${String(file.name).replace(/[^\w.\-]+/g,'_')}`;
  const showCloudError = (error, fallback) => { console.error('AlJoulaniGZ cloud:', error); alert(error?.message || fallback || msg('تعذّر الاتصال بالخادم. تحقق من إعدادات Supabase والإنترنت.','Could not reach the server. Check Supabase settings and internet.')); };

  function connectionNotice() {
    const old = $('gzCloudNotice'); if (old) old.remove();
    const note = document.createElement('div'); note.id = 'gzCloudNotice'; note.className = 'notice';
    note.style.cssText = 'margin:12px auto;max-width:1100px;border:1px solid #31d17c';
    note.textContent = configured
      ? msg('☁️ الخادم مُعدّ. سجّل الدخول لمزامنة الحسابات والمنشورات.','☁️ Server configured. Sign in to sync accounts and posts.')
      : msg('⚙️ يلزم إعداد Supabase أولًا: عدّل supabase-config.js ثم شغّل supabase-schema.sql.','⚙️ Supabase setup required: edit supabase-config.js and run supabase-schema.sql.');
    const main = document.querySelector('main'); if (main) main.prepend(note);
  }

  async function refreshPublicSettings(){
    if(!client)return;
    const {data,error}=await client.from('app_settings').select('setting_key,setting_value');
    if(error){console.warn('App settings:',error.message);return;}
    const m={};(data||[]).forEach(x=>m[x.setting_key]=x.setting_value);
    const brand=$('brandName');if(brand&&m.app_name)brand.textContent=m.app_name;
    if(m.app_name)document.title=m.app_name;
    if(m.owner_instagram){localStorage.setItem('gz-owner-instagram',m.owner_instagram);}
    let banner=$('gzAnnouncement');
    if(m.announcement||m.maintenance_mode==='true'){
      if(!banner){banner=document.createElement('div');banner.id='gzAnnouncement';banner.className='notice';banner.style.cssText='margin:12px auto;max-width:1050px;border:1px solid #9dff65';const main=document.querySelector('main');if(main)main.prepend(banner);}
      banner.textContent=(m.maintenance_mode==='true'?msg('⚠️ التطبيق في وضع الصيانة.','⚠️ The app is in maintenance mode. '):'')+(m.announcement||'');
    }else if(banner)banner.remove();
  }

  function authModal() {
    const profile = typeof gzProfile !== 'undefined' ? gzProfile : null;
    if (currentSession) {
      showModal(`<h2>${msg('حساب الجولانيGZ','AlJoulaniGZ account')}</h2><div class="notice">${msg('تم تسجيل الدخول بالبريد:','Signed in as:')} <b>${esc(currentSession.user.email)}</b><br>${msg('الحساب متصل بالخادم.','Account connected to the server.')}</div><form id="gzCloudProfileForm"><div class="form-row"><label>${msg('الاسم الظاهر','Display name')}</label><input id="gzCloudDisplay" maxlength="40" required value="${esc(profile?.displayName || currentSession.user.user_metadata?.display_name || '')}"></div><div class="form-row"><label>${msg('اسم المستخدم (إنجليزي وأرقام و _)','Username (letters, numbers, _)')}</label><input id="gzCloudUsername" maxlength="24" minlength="3" pattern="[A-Za-z0-9_]{3,24}" required value="${esc(profile?.username || currentSession.user.user_metadata?.username || '')}"></div><button class="btn" type="submit">${msg('حفظ الملف الشخصي على الخادم','Save cloud profile')}</button></form><button class="btn" id="gzUserVerification" style="margin-top:10px">✓ ${msg('طلب التوثيق المدفوع','Request paid verification')}</button><button class="btn secondary" id="gzCloudLogout" style="margin-top:10px">${msg('تسجيل الخروج','Sign out')}</button>`);
      $('gzCloudProfileForm').onsubmit = async e => {
        e.preventDefault();
        const display_name = $('gzCloudDisplay').value.trim(), username = $('gzCloudUsername').value.trim();
        const { error } = await client.from('profiles').upsert({id: currentSession.user.id, display_name, username, updated_at: new Date().toISOString()});
        if (error) return showCloudError(error, msg('تعذّر حفظ الملف الشخصي.','Could not save profile.'));
        gzProfile = {displayName: display_name, username}; localStorage.setItem('gz-profile', JSON.stringify(gzProfile));
        if (typeof updateProfileUI === 'function') updateProfileUI(); closeModal(); alert(msg('تم حفظ ملفك الشخصي على الخادم.','Profile saved to the server.'));
      };
      $('gzUserVerification').onclick = userVerificationRequest;
      $('gzCloudLogout').onclick = async () => { const {error} = await client.auth.signOut(); if(error) return showCloudError(error); closeModal(); };
      return;
    }
    showModal(`<h2>${msg('حساب الجولانيGZ','AlJoulaniGZ account')}</h2><p class="sub">${msg('أنشئ حسابًا حقيقيًا لتظهر منشوراتك على أجهزة المستخدمين الآخرين.','Create a real account so your posts can appear on other users’ devices.')}</p><div class="form-row"><label>${msg('البريد الإلكتروني','Email')}</label><input id="gzAuthEmail" type="email" autocomplete="email" required placeholder="you@example.com"></div><div class="form-row"><label>${msg('كلمة المرور (8 أحرف على الأقل)','Password (at least 8 characters)')}</label><input id="gzAuthPassword" type="password" minlength="8" autocomplete="current-password" required></div><div class="form-row"><label>${msg('الاسم الظاهر عند إنشاء حساب','Display name for sign-up')}</label><input id="gzAuthDisplay" maxlength="40" placeholder="GZ Creator"></div><div class="form-row"><label>${msg('اسم المستخدم عند إنشاء حساب','Username for sign-up')}</label><input id="gzAuthUsername" maxlength="24" pattern="[A-Za-z0-9_]{3,24}" placeholder="gz_creator"></div><button class="btn" id="gzAuthSignup">${msg('إنشاء حساب','Create account')}</button><button class="btn secondary" id="gzAuthLogin" style="margin-top:8px">${msg('تسجيل الدخول','Sign in')}</button><p class="sub">${msg('استخدم بريدك الحقيقي. قد يطلب Supabase تأكيد البريد قبل تسجيل الدخول.','Use your real email. Supabase may require email confirmation before sign-in.')}</p>`);
    const credentials = () => ({email:$('gzAuthEmail').value.trim(), password:$('gzAuthPassword').value, display_name:$('gzAuthDisplay').value.trim(), username:$('gzAuthUsername').value.trim()});
    $('gzAuthSignup').onclick = async () => {
      const v = credentials(); if(!v.email || v.password.length < 8 || !v.display_name || !/^[A-Za-z0-9_]{3,24}$/.test(v.username)) return alert(msg('أدخل البريد وكلمة مرور من 8 أحرف على الأقل والاسم واسم مستخدم صالح.','Enter email, password (8+ characters), display name and a valid username.'));
      const {data,error} = await client.auth.signUp({email:v.email,password:v.password,options:{data:{display_name:v.display_name,username:v.username}}});
      if(error) return showCloudError(error, msg('تعذّر إنشاء الحساب.','Could not create account.'));
      if(data.session){ currentSession=data.session; const {error:pe}=await client.from('profiles').upsert({id:data.user.id,display_name:v.display_name,username:v.username}); if(pe) console.warn(pe); gzProfile={displayName:v.display_name,username:v.username}; localStorage.setItem('gz-profile',JSON.stringify(gzProfile)); await afterAuth(); closeModal(); alert(msg('تم إنشاء الحساب وربطه بالخادم.','Account created and connected to the server.')); }
      else alert(msg('تم إنشاء طلب الحساب. افتح بريدك وأكّد الحساب، ثم ارجع وسجّل الدخول.','Sign-up started. Confirm your email, then return and sign in.'));
    };
    $('gzAuthLogin').onclick = async () => {
      const v=credentials(); if(!v.email || !v.password) return alert(msg('أدخل البريد وكلمة المرور.','Enter email and password.'));
      const {data,error}=await client.auth.signInWithPassword({email:v.email,password:v.password}); if(error) return showCloudError(error,msg('فشل تسجيل الدخول.','Sign-in failed.'));
      currentSession=data.session; await afterAuth(); closeModal(); alert(msg('تم تسجيل الدخول إلى الخادم.','Signed in to the server.'));
    };
  }

  async function refreshCloudTemplates() {
    if(!client) return;
    const {data,error}=await client.from('templates').select('*').order('created_at',{ascending:false}).limit(100);
    if(error){ console.warn('Template sync:',error.message); return; }
    products = products.filter(p => !cloudTemplateIds.has(String(p.id))); cloudTemplateIds = new Set();
    for(const row of (data||[])) {
      let preview = null, file = null;
      if(row.preview_path){const {data:d}=client.storage.from('gz-public-media').getPublicUrl(row.preview_path);preview=d?.publicUrl||null;}
      if(currentSession && row.file_path){const {data:d}=await client.storage.from('gz-template-files').createSignedUrl(row.file_path,3600);file=d?.signedUrl||null;}
      const item={id:row.id,name:row.name,desc:{ar:row.description||row.name,en:row.description||row.name,de:row.description||row.name,ja:row.description||row.name,tr:row.description||row.name},cat:row.category,kind:row.kind,preview,file,fileName:row.file_name,cloud:true};
      products.unshift(item); cloudTemplateIds.add(String(item.id));
    }
    if(typeof render==='function') render();
  }

  async function refreshCloudFeed() {
    if(!client) return;
    const {data:rows,error}=await client.from('posts').select('*').order('created_at',{ascending:false}).limit(50);
    if(error) { console.warn('Feed sync:',error.message); return; }
    const ids=[...new Set((rows||[]).map(p=>p.user_id))];
    let profileMap={};
    if(ids.length){const {data:ps}=await client.from('profiles').select('id,username,display_name').in('id',ids);(ps||[]).forEach(p=>profileMap[p.id]=p);}
    const {data:likes}=await client.from('post_likes').select('post_id,user_id');
    const {data:verifiedRows}=await client.from('account_verifications').select('user_id,is_verified,verification_type,expires_at').eq('is_verified',true);
    const now=Date.now(); verifiedUserIds=new Set((verifiedRows||[]).filter(v=>!v.expires_at || new Date(v.expires_at).getTime()>now).map(v=>v.user_id));
    gzPosts=[];
    for(const row of (rows||[])){
      const prof=profileMap[row.user_id]||{}; const {data:vd}=client.storage.from('gz-public-media').getPublicUrl(row.video_path);
      let templateUrl=null; if(currentSession){const {data:td}=await client.storage.from('gz-template-files').createSignedUrl(row.template_path,3600);templateUrl=td?.signedUrl||null;}
      gzPosts.push({id:row.id,userId:row.user_id,creator:prof.display_name||'GZ Creator',username:prof.username||'creator',verified:verifiedUserIds.has(row.user_id),title:row.title,caption:row.caption,videoUrl:vd?.publicUrl||null,templateUrl,templateFileName:row.template_file_name,templateName:row.template_file_name,likes:(likes||[]).filter(l=>l.post_id===row.id).length,cloud:true});
    }
    if(typeof originalRenderFeed==='function') originalRenderFeed();
  }

  async function afterAuth(){
    const {data:{session}}=await client.auth.getSession(); currentSession=session;
    if(session){
      const {data:p}=await client.from('profiles').select('*').eq('id',session.user.id).maybeSingle();
      if(p){gzProfile={displayName:p.display_name,username:p.username};localStorage.setItem('gz-profile',JSON.stringify(gzProfile));}
      else if(session.user.user_metadata?.username && session.user.user_metadata?.display_name){const {error}=await client.from('profiles').insert({id:session.user.id,username:session.user.user_metadata.username,display_name:session.user.user_metadata.display_name});if(!error){gzProfile={displayName:session.user.user_metadata.display_name,username:session.user.user_metadata.username};localStorage.setItem('gz-profile',JSON.stringify(gzProfile));}}
      if(isOwner()){
        const {data:ownerBadge}=await client.from('account_verifications').select('user_id').eq('user_id',session.user.id).maybeSingle();
        if(!ownerBadge){const {error:ownerBadgeError}=await client.from('account_verifications').insert({user_id:session.user.id,is_verified:true,verification_type:'owner',starts_at:new Date().toISOString(),expires_at:null,note:'Permanent owner verification',granted_by:session.user.id});if(ownerBadgeError)console.warn('Owner badge setup:',ownerBadgeError.message);}
      }
    }
    if(typeof updateProfileUI==='function') updateProfileUI();
    await Promise.all([refreshCloudFeed(),refreshCloudTemplates(),refreshPublicSettings()]);
    connectionNotice();
  }

  async function cloudPostSubmit(form){
    if(!currentSession) return alert(msg('سجّل الدخول أولًا قبل نشر فيديو.','Sign in before publishing a video.'));
    const vf=$('postVideoInput')?.files?.[0], tf=$('postTemplateInput')?.files?.[0];
    if(!vf||!tf) return alert(msg('أرفق الفيديو وملف القالب.','Attach both a video and template file.'));
    if(vf.size>25*1024*1024 || tf.size>50*1024*1024) return alert(msg('الحد الأقصى للفيديو 25MB وملف القالب 50MB.','Maximum sizes: 25MB video and 50MB template.'));
    const uid=currentSession.user.id, vp=filePath(uid,vf), tp=filePath(uid,tf);
    const {error:ve}=await client.storage.from('gz-public-media').upload(vp,vf,{upsert:false,contentType:vf.type||'video/mp4'}); if(ve) return showCloudError(ve,msg('فشل رفع الفيديو.','Video upload failed.'));
    const {error:te}=await client.storage.from('gz-template-files').upload(tp,tf,{upsert:false}); if(te){await client.storage.from('gz-public-media').remove([vp]);return showCloudError(te,msg('فشل رفع ملف القالب.','Template upload failed.'));}
    const {error:pe}=await client.from('posts').insert({user_id:uid,title:$('postTitleInput').value.trim(),caption:$('postCaptionInput').value.trim(),video_path:vp,template_path:tp,template_file_name:tf.name});
    if(pe){await client.storage.from('gz-public-media').remove([vp]);await client.storage.from('gz-template-files').remove([tp]);return showCloudError(pe,msg('تعذّر حفظ المنشور.','Could not save post.'));}
    closeModal(); await refreshCloudFeed(); alert(msg('نُشر الفيديو على الخادم وسيظهر للمستخدمين الآخرين.','Video published to the server and can be seen by other users.'));
  }

  async function cloudTemplateSubmit(){
    if(!isOwner()) return alert(msg('إضافة القوالب متاحة لحساب المالك فقط. سجّل الدخول ببريد المالك المحدد في الإعدادات.','Template uploads are restricted to the configured owner account. Sign in with the owner email.'));
    const name=$('pname').value.trim(),description=$('pdesc').value.trim(),category=$('pcat').value,kind=$('pprice').value,img=$('pimage').files[0],file=$('pfile').files[0];
    if(kind==='paid') return alert(msg('لم نفعّل نشر القوالب المدفوعة بعد، لأن نظام الدفع والتحقق من الشراء غير مربوط. انشر القوالب المجانية فقط حتى نؤمّن الدفع.','Paid template publishing is disabled until payment verification and download permissions are implemented. Publish free templates only for now.'));
    if(!file) return alert(tr('needFile'));
    if(file.size>50*1024*1024) return alert(msg('حجم القالب يجب ألا يتجاوز 50MB.','Template file must be 50MB or less.'));
    const uid=currentSession.user.id, tp=filePath(uid,file); let previewPath=null;
    const {error:fe}=await client.storage.from('gz-template-files').upload(tp,file,{upsert:false});if(fe)return showCloudError(fe,msg('فشل رفع ملف القالب.','Template upload failed.'));
    if(img){const ip=filePath(uid,img);const {error:ie}=await client.storage.from('gz-public-media').upload(ip,img,{upsert:false,contentType:img.type||'image/jpeg'});if(ie){await client.storage.from('gz-template-files').remove([tp]);return showCloudError(ie,msg('فشل رفع صورة المعاينة.','Preview upload failed.'));}previewPath=ip;}
    const {error}=await client.from('templates').insert({name,description,category,kind,preview_path:previewPath,file_path:tp,file_name:file.name,created_by:uid});
    if(error){await client.storage.from('gz-template-files').remove([tp]);if(previewPath)await client.storage.from('gz-public-media').remove([previewPath]);return showCloudError(error,msg('تعذّر حفظ القالب على الخادم.','Could not save template to server.'));}
    closeModal(); await refreshCloudTemplates(); alert(msg('تم نشر القالب على الخادم. تنبيه: الدفع الآمن للقوالب المدفوعة غير مربوط بعد.','Template published to the server. Note: secure payment for paid templates is not connected yet.'));
  }

  async function ownerDashboard(){
    if(!currentSession){authModal();return;}
    if(!isOwner()) return alert(msg('هذه اللوحة خاصة بحساب المالك. سجّل الدخول ببريد المالك المحدد في الإعدادات.','Owner-only dashboard. Sign in with the configured owner email.'));
    const [u,p,t,v,pending]=await Promise.all([
      client.from('profiles').select('id',{count:'exact',head:true}),
      client.from('posts').select('id',{count:'exact',head:true}),
      client.from('templates').select('id',{count:'exact',head:true}),
      client.from('account_verifications').select('user_id,expires_at').eq('is_verified',true),
      client.from('verification_payment_requests').select('id',{count:'exact',head:true}).eq('status','pending')
    ]);
    const activeVerificationCount=(v.data||[]).filter(row=>!row.expires_at||new Date(row.expires_at).getTime()>Date.now()).length;
    const {data:settings}=await client.from('app_settings').select('setting_key,setting_value');
    const cfgMap={};(settings||[]).forEach(x=>cfgMap[x.setting_key]=x.setting_value);
    showModal(`<h2>🛠 ${msg('لوحة إدارة الجولانيGZ','AlJoulaniGZ Admin')}</h2>
      <div class="notice">${msg('الحسابات','Accounts')}: <b>${u.count??'—'}</b> · ${msg('المنشورات','Posts')}: <b>${p.count??'—'}</b> · ${msg('القوالب','Templates')}: <b>${t.count??'—'}</b><br>${msg('الحسابات الموثقة','Verified accounts')}: <b>${activeVerificationCount}</b> · ${msg('طلبات الدفع المعلقة','Pending payment requests')}: <b>${pending.count??'—'}</b></div>
      <div class="form-row"><button class="btn" id="gzManageVerify">✓ ${msg('توثيق/إلغاء توثيق حساب','Verify / unverify account')}</button></div>
      <div class="form-row"><button class="btn" id="gzManagePayments">💳 ${msg('طلبات توثيق مدفوعة','Paid verification requests')}</button></div>
      <details open><summary style="color:var(--accent);cursor:pointer;padding:10px">⚙️ ${msg('إعدادات التطبيق والدفع','App & payment settings')}</summary>
      <form id="gzSettingsForm">
      <div class="form-row"><label>${msg('اسم التطبيق','App name')}</label><input id="gzSetAppName" maxlength="60" value="${esc(cfgMap.app_name||'AlJoulaniGZ')}"></div>
      <div class="form-row"><label>${msg('سعر التوثيق الشهري بالدولار (ثابت 20 حالياً)','Monthly verification price in USD (fixed at $20)')}</label><input value="20" disabled></div>
      <div class="form-row"><label>${msg('اسم مستلم شام كاش','Sham Cash recipient name')}</label><input id="gzSetPayName" maxlength="100" value="${esc(cfgMap.shamcash_recipient_name||'')}"></div>
      <div class="form-row"><label>${msg('معرّف/رقم مستلم شام كاش','Sham Cash recipient ID/number')}</label><input id="gzSetPayId" maxlength="120" value="${esc(cfgMap.shamcash_recipient_identifier||'')}"></div>
      <div class="form-row"><label>${msg('تعليمات الدفع للمستخدمين','Payment instructions for users')}</label><textarea id="gzSetPayInfo" maxlength="1000" rows="3">${esc(cfgMap.shamcash_payment_instructions||'')}</textarea></div>
      <div class="form-row"><label>${msg('وسيلة التواصل للدعم','Support contact')}</label><input id="gzSetSupport" maxlength="160" value="${esc(cfgMap.support_contact||'')}"></div>
      <div class="form-row"><label>${msg('رابط إنستغرام المالك','Owner Instagram URL')}</label><input id="gzSetInstagram" type="url" maxlength="240" value="${esc(cfgMap.owner_instagram||'')}"></div>
      <div class="form-row"><label>${msg('إعلان أعلى التطبيق','App announcement')}</label><textarea id="gzSetAnnouncement" maxlength="500" rows="2">${esc(cfgMap.announcement||'')}</textarea></div>
      <div class="form-row"><label><input id="gzSetMaintenance" type="checkbox" ${cfgMap.maintenance_mode==='true'?'checked':''}> ${msg('وضع الصيانة (إعلان فقط؛ لا يقفل التطبيق بعد)','Maintenance mode (notice only; does not block the app yet)')}</label></div>
      <button class="btn" type="submit">${msg('حفظ الإعدادات على الخادم','Save settings to server')}</button></form></details>
      <button class="btn secondary" id="gzOwnerAddTemplate" style="margin-top:10px">＋ ${tr('addTemplate')}</button>
      <button class="btn secondary" id="gzOwnerClose" style="margin-top:8px">${tr('ok')}</button>`);
    $('gzOwnerAddTemplate').onclick=()=>openAddTemplate(); $('gzOwnerClose').onclick=closeModal;
    $('gzManageVerify').onclick=manageVerifications; $('gzManagePayments').onclick=managePayments;
    $('gzSettingsForm').onsubmit=async e=>{e.preventDefault();const vals={app_name:$('gzSetAppName').value.trim()||'AlJoulaniGZ',verification_monthly_price_usd:'20',shamcash_recipient_name:$('gzSetPayName').value.trim(),shamcash_recipient_identifier:$('gzSetPayId').value.trim(),shamcash_payment_instructions:$('gzSetPayInfo').value.trim(),support_contact:$('gzSetSupport').value.trim(),owner_instagram:$('gzSetInstagram').value.trim(),announcement:$('gzSetAnnouncement').value.trim(),maintenance_mode:$('gzSetMaintenance').checked?'true':'false'};if(vals.owner_instagram&&!/^https:\/\/www\.instagram\.com\//i.test(vals.owner_instagram))return alert(msg('رابط إنستغرام غير صالح.','Invalid Instagram URL.'));for(const [setting_key,setting_value] of Object.entries(vals)){const {error}=await client.from('app_settings').upsert({setting_key,setting_value,updated_at:new Date().toISOString(),updated_by:currentSession.user.id});if(error)return showCloudError(error,msg('تعذّر حفظ الإعدادات.','Could not save settings.'));}localStorage.setItem('gz-owner-instagram',vals.owner_instagram);alert(msg('حُفظت إعدادات التطبيق على الخادم.','App settings saved to server.'));};
  }

  async function manageVerifications(){
    const {data:profiles,error}=await client.from('profiles').select('id,username,display_name').order('created_at',{ascending:false}).limit(200);
    if(error)return showCloudError(error);
    const {data:verifs}=await client.from('account_verifications').select('*');const byId={};(verifs||[]).forEach(v=>byId[v.user_id]=v);
    const rows=(profiles||[]).map(p=>{const v=byId[p.id],active=v?.is_verified&&(!v.expires_at||new Date(v.expires_at).getTime()>Date.now());return `<div class="notice"><b>@${esc(p.username)}</b> — ${esc(p.display_name)}<br><small>${active?`✓ ${msg('موثّق','Verified')} (${esc(v.verification_type)})`:`${msg('غير موثّق','Not verified')}`}${v?.expires_at?` · ${esc(new Date(v.expires_at).toLocaleDateString())}`:''}</small><div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px"><button class="btn" data-verify="${p.id}" data-username="${esc(p.username)}">✓ ${msg('توثيق دائم','Permanent verify')}</button><button class="btn secondary" data-unverify="${p.id}" data-username="${esc(p.username)}">${msg('إلغاء التوثيق','Revoke')}</button></div></div>`}).join('');
    showModal(`<h2>${msg('إدارة توثيق الحسابات','Account verification')}</h2><p class="sub">${msg('اختر حساباً من القائمة أو ابحث باسم المستخدم. يمكنك توثيق حساب يدوياً مجاناً أو إلغاء التوثيق.','Choose an account or search by username. You can manually verify any account or revoke verification.')}</p><form id="gzVerifySearch"><div class="form-row"><label>@username</label><input id="gzVerifyUsername" required pattern="[A-Za-z0-9_]{3,24}" placeholder="creator_name"></div><button class="btn" type="submit">${msg('بحث','Search')}</button></form><div id="gzVerifyResults" style="max-height:42vh;overflow:auto">${rows||msg('لا توجد حسابات بعد.','No accounts yet.')}</div><button class="btn secondary" id="gzVerifyBack">${msg('رجوع','Back')}</button>`);
    const bind=()=>{document.querySelectorAll('[data-verify]').forEach(b=>b.onclick=()=>setVerification(b.dataset.verify,b.dataset.username,true));document.querySelectorAll('[data-unverify]').forEach(b=>b.onclick=()=>setVerification(b.dataset.unverify,b.dataset.username,false));};bind();
    $('gzVerifySearch').onsubmit=async e=>{e.preventDefault();const q=$('gzVerifyUsername').value.trim();const {data,error}=await client.from('profiles').select('id,username,display_name').ilike('username',q).limit(10);if(error)return showCloudError(error);const {data:vv}=await client.from('account_verifications').select('*').in('user_id',(data||[]).map(x=>x.id));const map={};(vv||[]).forEach(v=>map[v.user_id]=v);$('gzVerifyResults').innerHTML=(data||[]).map(p=>`<div class="notice"><b>@${esc(p.username)}</b> — ${esc(p.display_name)}<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px"><button class="btn" data-verify="${p.id}" data-username="${esc(p.username)}">✓ ${msg('توثيق دائم','Permanent verify')}</button><button class="btn secondary" data-unverify="${p.id}" data-username="${esc(p.username)}">${msg('إلغاء التوثيق','Revoke')}</button></div></div>`).join('')||msg('لم يتم العثور على الحساب.','Account not found.');bind();};
    $('gzVerifyBack').onclick=ownerDashboard;
  }

  async function setVerification(userId, username, verified){
    if(!isOwner())return alert(msg('غير مسموح.','Not allowed.'));
    if(verified){const {error}=await client.from('account_verifications').upsert({user_id:userId,is_verified:true,verification_type:'manual',starts_at:new Date().toISOString(),expires_at:null,note:'Manually granted by owner',granted_by:currentSession.user.id,updated_at:new Date().toISOString()});if(error)return showCloudError(error);await client.from('admin_audit_log').insert({actor_id:currentSession.user.id,action:'manual_verify',target_user_id:userId,details:{username}});alert(msg(`تم توثيق @${username} بشكل دائم.`,`@${username} is now permanently verified.`));}
    else{const {error}=await client.from('account_verifications').delete().eq('user_id',userId);if(error)return showCloudError(error);await client.from('admin_audit_log').insert({actor_id:currentSession.user.id,action:'revoke_verification',target_user_id:userId,details:{username}});alert(msg(`تم إلغاء توثيق @${username}.`,`Verification revoked for @${username}.`));}
    await manageVerifications();
  }

  async function managePayments(){
    const {data:requests,error}=await client.from('verification_payment_requests').select('*').eq('status','pending').order('submitted_at',{ascending:true}).limit(100);if(error)return showCloudError(error);
    const ids=[...new Set((requests||[]).map(r=>r.user_id))];let map={};if(ids.length){const {data:profiles}=await client.from('profiles').select('id,username,display_name').in('id',ids);(profiles||[]).forEach(p=>map[p.id]=p);}
    showModal(`<h2>💳 ${msg('طلبات الدفع المعلّقة','Pending payments')}</h2><p class="sub">${msg('تحقق من التحويل داخل حساب شام كاش نفسه قبل الموافقة. لا تعتمد على صورة إيصال وحدها.','Verify the incoming transfer in the Sham Cash account itself before approving. Do not rely on a receipt screenshot alone.')}</p>${(requests||[]).map(r=>{const p=map[r.user_id]||{};return `<div class="notice"><b>@${esc(p.username||'unknown')}</b> — ${esc(p.display_name||'')}<br>${msg('المبلغ','Amount')}: $20<br>${msg('مرجع التحويل','Transaction reference')}: <b>${esc(r.transaction_ref)}</b><br><small>${esc(new Date(r.submitted_at).toLocaleString())}</small><div class="form-row"><label>${msg('ملاحظة المراجع (اختياري)','Reviewer note (optional)')}</label><input id="gzNote_${r.id}" maxlength="200"></div><div style="display:flex;gap:8px"><button class="btn" data-pay-approve="${r.id}" data-user="${r.user_id}" data-username="${esc(p.username||'unknown')}">${msg('تأكيد الدفع + توثيق شهر','Approve + verify 1 month')}</button><button class="btn secondary" data-pay-reject="${r.id}">${msg('رفض','Reject')}</button></div></div>`}).join('')||`<div class="notice">${msg('لا توجد طلبات معلقة.','No pending requests.')}</div>`}<button class="btn secondary" id="gzPayBack">${msg('رجوع','Back')}</button>`);
    document.querySelectorAll('[data-pay-approve]').forEach(b=>b.onclick=async()=>{if(!confirm(msg('هل تحققت بنفسك من وصول مبلغ $20 إلى محفظة شام كاش؟','Have you personally confirmed the $20 transfer arrived in your Sham Cash wallet?')))return;const expiry=new Date();expiry.setDate(expiry.getDate()+30);const {error:ve}=await client.from('account_verifications').upsert({user_id:b.dataset.user,is_verified:true,verification_type:'paid',starts_at:new Date().toISOString(),expires_at:expiry.toISOString(),note:'Paid Sham Cash request '+b.dataset.payApprove,granted_by:currentSession.user.id,updated_at:new Date().toISOString()});if(ve)return showCloudError(ve);const {error:re}=await client.from('verification_payment_requests').update({status:'approved',reviewed_at:new Date().toISOString(),reviewed_by:currentSession.user.id,reviewer_note:$('gzNote_'+b.dataset.payApprove)?.value.trim()||''}).eq('id',b.dataset.payApprove);if(re)return showCloudError(re);await client.from('admin_audit_log').insert({actor_id:currentSession.user.id,action:'approve_paid_verification',target_user_id:b.dataset.user,details:{username:b.dataset.username,expires_at:expiry.toISOString()}});alert(msg('تم تأكيد الطلب وتوثيق الحساب لشهر واحد.','Payment approved; account verified for one month.'));await managePayments();});
    document.querySelectorAll('[data-pay-reject]').forEach(b=>b.onclick=async()=>{const {error}=await client.from('verification_payment_requests').update({status:'rejected',reviewed_at:new Date().toISOString(),reviewed_by:currentSession.user.id,reviewer_note:$('gzNote_'+b.dataset.payReject)?.value.trim()||'Rejected by owner'}).eq('id',b.dataset.payReject);if(error)return showCloudError(error);alert(msg('تم رفض الطلب.','Request rejected.'));await managePayments();});$('gzPayBack').onclick=ownerDashboard;
  }

  async function userVerificationRequest(){
    if(!currentSession){authModal();return;}
    const [{data:settings},{data:existing,error}] = await Promise.all([client.from('app_settings').select('setting_key,setting_value'),client.from('verification_payment_requests').select('id,status,transaction_ref,submitted_at').eq('user_id',currentSession.user.id).order('submitted_at',{ascending:false}).limit(5)]);
    if(error)return showCloudError(error);const m={};(settings||[]).forEach(s=>m[s.setting_key]=s.setting_value);
    const verified=await client.from('account_verifications').select('is_verified,verification_type,expires_at').eq('user_id',currentSession.user.id).maybeSingle();const v=verified.data,active=v?.is_verified&&(!v.expires_at||new Date(v.expires_at).getTime()>Date.now());
    showModal(`<h2>✓ ${msg('توثيق الحساب','Get verified')}</h2><div class="notice">${active?msg('حسابك موثّق حالياً.','Your account is currently verified.'):msg('التوثيق المدفوع: 20 دولاراً لمدة شهر بعد التحقق من وصول التحويل.','Paid verification: $20 for one month after the transfer is verified.')}</div><div class="notice"><b>${msg('مستلم شام كاش','Sham Cash recipient')}</b><br>${esc(m.shamcash_recipient_name||msg('لم يحدد المالك اسم المستلم بعد.','Owner has not configured recipient name yet.'))}<br>${esc(m.shamcash_recipient_identifier||'')}<p>${esc(m.shamcash_payment_instructions||msg('انتظر حتى يضيف المالك بيانات الدفع الرسمية. لا تحول أي مبلغ إذا لم تظهر بيانات واضحة.','Wait until the owner adds official payment details. Do not transfer money if clear details are missing.'))}</p><small>${msg('السعر: $20 / شهر','Price: $20 / month')}</small></div><form id="gzPaymentRequestForm"><div class="form-row"><label>${msg('رقم/مرجع العملية الظاهر في شام كاش','Transaction reference shown in Sham Cash')}</label><input id="gzTransactionRef" required maxlength="120" minlength="3" placeholder="Transaction reference"></div><button class="btn" type="submit">${msg('إرسال الطلب للمراجعة','Submit for review')}</button></form><h3>${msg('طلباتي السابقة','My recent requests')}</h3>${(existing||[]).map(r=>`<div class="notice">${esc(r.transaction_ref)} — ${esc(r.status)} — ${esc(new Date(r.submitted_at).toLocaleDateString())}</div>`).join('')||`<p class="sub">${msg('لا توجد طلبات.','No requests yet.')}</p>`}<button class="btn secondary" id="gzVerifyUserClose">${tr('ok')}</button>`);
    $('gzVerifyUserClose').onclick=closeModal;$('gzPaymentRequestForm').onsubmit=async e=>{e.preventDefault();if(!m.shamcash_recipient_identifier||!m.shamcash_payment_instructions)return alert(msg('لم يضبط المالك بيانات الدفع بعد. لا تحوّل المال الآن.','Payment details are not configured. Do not transfer money yet.'));const transaction_ref=$('gzTransactionRef').value.trim();const {error}=await client.from('verification_payment_requests').insert({user_id:currentSession.user.id,amount_usd:20,payment_method:'sham_cash',transaction_ref,status:'pending'});if(error)return showCloudError(error,msg('تعذّر إرسال الطلب. ربما استُخدم المرجع من قبل.','Could not submit request; the reference may already have been used.'));alert(msg('أُرسل طلبك. سيُفعّل التوثيق بعد أن يتحقق المالك من التحويل.','Request submitted. Verification activates after the owner confirms the transfer.'));await userVerificationRequest();};
  }

  async function boot(){
    connectionNotice();
    if(!configured || !window.supabase?.createClient){console.warn('Supabase not configured or CDN unavailable.');return;}
    client=window.supabase.createClient(cfg.url,cfg.anonKey,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
    originalRenderFeed=renderFeed;
    const {data:{session}}=await client.auth.getSession(); currentSession=session;
    client.auth.onAuthStateChange((_event,session)=>{currentSession=session;setTimeout(()=>afterAuth().catch(console.error),0);});
    // Replace prototype-only profile and owner flows with real cloud flows.
    if($('navProfile')) $('navProfile').onclick=authModal;
    if($('accountButton')) $('accountButton').onclick=authModal;
    if($('navOwner')) $('navOwner').onclick=ownerDashboard;
    if($('adminOpen')) $('adminOpen').onclick=ownerDashboard;
    // Intercept form submissions before local-only handlers.
    $('modalContent').addEventListener('submit',e=>{
      if(e.target.id==='profileForm') {e.preventDefault();e.stopImmediatePropagation();authModal();return;}
      if(e.target.id==='postForm') {e.preventDefault();e.stopImmediatePropagation();cloudPostSubmit(e.target).catch(err=>showCloudError(err));return;}
      if(e.target.id==='adminForm') {e.preventDefault();e.stopImmediatePropagation();cloudTemplateSubmit().catch(err=>showCloudError(err));return;}
    },true);
    // Cloud-backed likes and follows; prevent the demo's local-only click handlers.
    $('feed')?.addEventListener('click',async e=>{
      const like=e.target.closest('.like-btn'), follow=e.target.closest('.follow-btn'), comment=e.target.closest('.comment-btn'); if(!like&&!follow&&!comment)return;
      e.preventDefault();e.stopPropagation();
      if(!currentSession){authModal();return;}
      const card=e.target.closest('.post-card'); const title=card?.querySelector('.post-caption strong')?.textContent;
      const post=gzPosts.find(p=>String(p.id)===String(card?.dataset.postId) && p.cloud); if(!post)return;
      if(comment){const {data:rows,error}=await client.from('comments').select('id,body,created_at,user_id').eq('post_id',post.id).order('created_at',{ascending:true}).limit(100);if(error)return showCloudError(error);const userIds=[...new Set((rows||[]).map(r=>r.user_id))];let names={};if(userIds.length){const {data:ps}=await client.from('profiles').select('id,display_name').in('id',userIds);(ps||[]).forEach(p=>names[p.id]=p.display_name);}showModal(`<h2>${tr('comments')}</h2><div>${(rows||[]).map(r=>`<p class="notice"><b>${esc(names[r.user_id]||'GZ Creator')}</b><br>${esc(r.body)}</p>`).join('')||`<p>${msg('لا توجد تعليقات بعد.','No comments yet.')}</p>`}</div><form id="gzCloudCommentForm"><div class="form-row"><label>${tr('addComment')}</label><input id="gzCloudCommentInput" required maxlength="300" placeholder="${tr('commentPlaceholder')}"></div><button class="btn" type="submit">${tr('addComment')}</button></form>`);$('gzCloudCommentForm').onsubmit=async ev=>{ev.preventDefault();const body=$('gzCloudCommentInput').value.trim();if(!body)return;const {error:ce}=await client.from('comments').insert({post_id:post.id,user_id:currentSession.user.id,body});if(ce)return showCloudError(ce);await refreshCloudFeed();const b=document.querySelector(`[data-post-id="${post.id}"] .comment-btn`);if(b)b.click();};return;}
      if(like){const {data:existing,error:qe}=await client.from('post_likes').select('post_id').eq('post_id',post.id).eq('user_id',currentSession.user.id).maybeSingle();if(qe)return showCloudError(qe);const result=existing?await client.from('post_likes').delete().eq('post_id',post.id).eq('user_id',currentSession.user.id):await client.from('post_likes').insert({post_id:post.id,user_id:currentSession.user.id});if(result.error)return showCloudError(result.error);await refreshCloudFeed();}
      if(follow){const target=post.userId;if(!target||target===currentSession.user.id)return;const {data:existing,error:qe}=await client.from('follows').select('following_id').eq('follower_id',currentSession.user.id).eq('following_id',target).maybeSingle();if(qe)return showCloudError(qe);const result=existing?await client.from('follows').delete().eq('follower_id',currentSession.user.id).eq('following_id',target):await client.from('follows').insert({follower_id:currentSession.user.id,following_id:target});if(result.error)return showCloudError(result.error);await refreshCloudFeed();}
    },true);
    if(currentSession) await afterAuth();
    else {await Promise.all([refreshCloudTemplates(),refreshCloudFeed(),refreshPublicSettings()]);}
  }
  window.GZCloud={boot,signIn:authModal,refreshFeed:refreshCloudFeed,requestVerification:userVerificationRequest};
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>boot().catch(showCloudError));else boot().catch(showCloudError);
})();
