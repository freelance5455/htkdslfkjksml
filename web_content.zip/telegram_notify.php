<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$botToken = '8990709020:AAEB7MUXvgPN2lgqPJ9oMiOdx6yMVh9V4hU';
$chatId = '8591379261';

$input = json_decode(file_get_contents('php://input'), true);
$text = isset($input['text']) ? $input['text'] : '';

if (empty($text)) {
    echo json_encode(['ok' => false, 'error' => 'No text']);
    exit;
}

$url = "https://api.telegram.org/bot{$botToken}/sendMessage";
$data = [
    'chat_id' => $chatId,
    'text' => $text,
    'parse_mode' => 'HTML',
    'disable_web_page_preview' => true
];

$options = [
    'http' => [
        'header'  => "Content-type: application/json\r\n",
        'method'  => 'POST',
        'content' => json_encode($data),
        'timeout' => 10,
        'ignore_errors' => true
    ],
    'ssl' => [
        'verify_peer' => false,
        'verify_peer_name' => false
    ]
];

$context = stream_context_create($options);
$result = @file_get_contents($url, false, $context);

if ($result === false) {
    echo json_encode(['ok' => false, 'error' => 'Request failed']);
} else {
    echo $result;
}
