# Universe Simulator — Android project

This is a self-contained, offline-friendly Android WebView game prototype. The game itself is in `app/src/main/assets/index.html`; the Android wrapper loads it locally, with no network permission and no generative AI dependency.

## What is implemented
- Seeded, repeatable universe generation
- Cosmic era progression and time advancement
- Generated galaxies, stars, and planets
- Planet traits and rule-based potential habitability
- Conditional biosphere, complex-life, and civilization milestones
- Stellar lifetime transitions
- Tap-to-inspect objects and catalogue filters
- Simulation speed, run/pause, reset via seed, local save/load, JSON export

## Build an APK
This workspace did not have the Android SDK or Gradle installed, so a compiled APK could not be produced here. To build:
1. Open this folder in Android Studio with Android SDK Platform 35 installed.
2. Allow Gradle sync to complete.
3. Choose **Build > Build APK(s)**.
4. Android Studio will place the APK under `app/build/outputs/apk/debug/`.

The project needs Android Gradle Plugin 8.7.3 and Gradle 8.9 or a compatible Gradle version. Internet may be required by Android Studio to download the build tools on first setup.

## Model caveats
This is a deterministic toy model, not a scientifically validated cosmology. Galaxies and stars are procedural abstractions; planets use simplified environmental traits; life and civilization emergence use seeded probabilities. It does not integrate real N-body gravity or simulate chemistry at molecular resolution.
