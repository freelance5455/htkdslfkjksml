# Milk Hisab Pro - Android Project & Google Play Store Publishing Guide

यह फोल्डर **Milk Hisab Pro** का पूर्ण Android Studio प्रोजेक्ट है। इसमें आपकी पूरी वर्किंग ऐप (`assets/index.html`) और नेटिव Android WebView कोड शामिल है।

---

## 1. इस प्रोजेक्ट से APK और AAB कैसे बनाएं (2 मिनट में)

1. इस ज़िप फ़ाइल को अपने कंप्यूटर में अनज़िप (Extract) करें।
2. **Android Studio** खोलें।
3. **Open Project** पर क्लिक करके इस `MilkHisabPro_Android` फ़ोल्डर को चुनें।
4. Android Studio प्रोजेक्ट की फ़ाइलें और Gradle लोड कर लेगा।
5. **सीधे अपने फ़ोन में टेस्ट करने के लिए APK बनाना:**
   - मेनू में जाएं: `Build` -> `Build Bundle(s) / APK(s)` -> `Build APK(s)`
   - 1 मिनट में `app-debug.apk` तैयार हो जाएगा, जिसे आप अपने फ़ोन में सीधे इंस्टॉल कर सकते हैं।
6. **Play Store पर अपलोड करने के लिए AAB बनाना:**
   - मेनू में जाएं: `Build` -> `Generate Signed Bundle / APK`
   - `Android App Bundle (.aab)` चुनें।
   - अपनी नई Keystore फ़ाइल बनाएं (Create New Keystore) और पासवर्ड सेट करें।
   - `Release` मोड चुनें और Finish करें।
   - आपको `app-release.aab` फ़ाइल मिल जाएगी।

---

## 2. Google Play Store पर लाइव करने के चरण (Play Console)

Google Play Store पर कोई भी ऐप लाइव करने के लिए Google की आधिकारिक प्रक्रिया निम्न है:

### चरण 1: Google Play Console डेवलपर खाता
- वेबसाइट पर जाएं: https://play.google.com/console/signup
- अपनी Gmail ID से लॉगिन करें।
- Google $25 (लगभग ₹2,100) की वन-टाइम रजिस्ट्रेशन फ़ीस लेता है।
- अपना नाम, पता और सरकारी पहचान पत्र (Aadhaar/PAN/Passport) से पहचान सत्यापित (Verify) करें।

### चरण 2: नया ऐप बनाएं (Create App)
- Play Console में **"Create App"** पर क्लिक करें।
- **App Name**: `Milk Hisab Pro - डेयरी दूध हिसाब`
- **Default Language**: Hindi (हिंदी)
- **App or Game**: App
- **Free or Paid**: Free
- Declaration स्वीकार करके Create App दबाएं।

### चरण 3: स्टोर लिस्टिंग (Store Listing) विवरण
- **Short Description**: गाय और भैंस के दूध का 10-दिन, महीना और पूरा हिसाब रखने वाला ऐप।
- **Full Description**: अपनी गाय और भैंस का डेयरी में दूध देने का पूरा हिसाब, Fat, SNF, अलग-अलग रेट, 10 दिन का हिसाब, डेयरी से प्राप्त भुगतान, बकाया रकम और PDF/Excel रिपोर्ट।
- **App Icon**: 512 x 512 px PNG (डेयरी/दूध का लोगो)
- **Feature Graphic**: 1024 x 500 px बैनर इमेज
- **Screenshots**: फ़ोन से ऐप के 3-4 स्क्रीनशॉट अपलोड करें (Dashboard, New Entry, 10-Day Report)।

### चरण 4: प्राइवेसी पॉलिसी व डेटा सेफ्टी (Privacy Policy & Data Safety)
- Milk Hisab Pro का सारा डेटा 100% यूजर के फ़ोन के लोकल स्टोरेज में रहता है, कोई भी डेटा सर्वर पर नहीं जाता।
- Data Safety फ़ॉर्म में भरें: "No user data is collected or shared with third parties."
- Privacy Policy URL दर्ज करें।

### चरण 5: App Bundle (.aab) अपलोड करें
- Play Console में **Production** या **Closed Testing** सेक्शन में जाएं।
- Android Studio से बनी `app-release.aab` फ़ाइल को ड्रैग करके अपलोड करें।
- Release Name दें (उदा: `1.0.0 (First Release)`).

### चरण 6: 20 Testers (Google की 14 दिन की टेस्टिंग नीति)
- नवंबर 2023 के बाद बने सभी नए पर्सनल Google Play खातों के लिए Google की नीति है कि ऐप को 20 दोस्तों/परीक्षकों (Testers) के साथ 14 दिन Closed Testing में रखना होता है।
- 14 दिन पूरे होने के बाद **"Apply for Production"** का बटन दबाइए।

### चरण 7: Google Review और Live
- Google की टीम ऐप की समीक्षा (Review) करती है (आमतौर पर 2 से 4 दिन)।
- अप्रूव होते ही आपका **Milk Hisab Pro** ऐप पूरी दुनिया में Google Play Store पर लाइव हो जाएगा!
