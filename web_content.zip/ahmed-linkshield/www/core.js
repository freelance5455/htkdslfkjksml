/* AHMED HAMDY — Link Shield core
 * محرك الفحص: منطق بحت + طبقة http قابلة للاستبدال (native في الأندرويد، fetch في المتصفح)
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.Core = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const UA = 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36';
  const VT = 'https://www.virustotal.com/api/v3';
  const MAX_HOPS = 8;
  const MAX_BODY = 1500000;

  const STAGES = {
    structure: 'تحليل شكل الرابط',
    dns: 'DNS (مشفّر DoH)',
    rdap: 'عمر الدومين (RDAP)',
    fetch: 'تتبع التحويلات وجلب الصفحة',
    content: 'تحليل محتوى الصفحة',
    phish: 'قوائم التصيّد (OpenPhish)',
    vt: 'VirusTotal (70+ محرك)',
    gsb: 'Google Safe Browsing',
  };

  const SUSP_TLDS = new Set('zip mov xyz top click link work support country gq cf tk ml ga rest fit cam icu monster buzz surf men loan download review stream bid sbs cyou cfd'.split(' '));
  const SHORTENERS = new Set('bit.ly tinyurl.com t.co goo.gl ow.ly is.gd buff.ly rebrand.ly cutt.ly shorturl.at tiny.cc rb.gy s.id lnkd.in t.ly v.gd'.split(' '));
  const PHISH_WORDS = 'login signin verify account update secure banking confirm password wallet paypal apple microsoft google facebook instagram netflix amazon support suspend unlock recover billing invoice gift prize bonus'.split(' ');
  const TWO_LVL = new Set('co.uk com.eg com.au co.jp com.br co.in org.uk gov.uk com.sa com.tr co.za com.ng com.pk'.split(' '));
  const BRANDS = {
    paypal: ['paypal.com'], google: ['google.com', 'google.com.eg', 'goo.gl'], facebook: ['facebook.com', 'fb.com'],
    instagram: ['instagram.com'], apple: ['apple.com', 'icloud.com'], microsoft: ['microsoft.com', 'live.com', 'office.com', 'microsoftonline.com'],
    amazon: ['amazon.com', 'amazon.eg', 'amazon.ae', 'amazon.sa'], netflix: ['netflix.com'], whatsapp: ['whatsapp.com', 'whatsapp.net'],
    telegram: ['telegram.org', 't.me'], binance: ['binance.com'], vodafone: ['vodafone.com', 'vodafone.com.eg'],
    etisalat: ['etisalat.com', 'etisalat.eg'], instapay: ['instapay.eg'], fawry: ['fawry.com'], tiktok: ['tiktok.com'],
    youtube: ['youtube.com', 'youtu.be'], linkedin: ['linkedin.com'], twitter: ['twitter.com', 'x.com'], github: ['github.com'],
    dropbox: ['dropbox.com'], outlook: ['outlook.com'], steam: ['steampowered.com', 'steamcommunity.com'], discord: ['discord.com', 'discord.gg'],
    paymob: ['paymob.com'], cib: ['cibeg.com'], nbe: ['nbe.com.eg'], banquemisr: ['banquemisr.com'], aramex: ['aramex.com'], dhl: ['dhl.com'],
  };

  const LEVELS = [
    { max: 14, key: 'safe', label: 'آمن', color: '#22c55e' },
    { max: 34, key: 'caution', label: 'حذر', color: '#eab308' },
    { max: 59, key: 'suspicious', label: 'مشبوه', color: '#f97316' },
    { max: 101, key: 'danger', label: 'خطير', color: '#ef4444' },
  ];

  // ---------- أدوات ----------
  const add = (F, sev, pts, msg, src) => F.push({ severity: sev, points: pts, message: msg, source: src || 'local' });
  const skip = (m) => Object.assign(new Error(m), { skip: true });
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  function normalizeUrl(raw) {
    raw = String(raw || '').trim();
    return /^[a-z][a-z0-9+.-]*:\/\//i.test(raw) ? raw : 'http://' + raw;
  }
  function regDomain(h) {
    const p = String(h).toLowerCase().split('.');
    if (p.length <= 2) return p.join('.');
    const l2 = p.slice(-2).join('.');
    return TWO_LVL.has(l2) && p.length >= 3 ? p.slice(-3).join('.') : l2;
  }
  function isIpv4(h) { return /^\d{1,3}(\.\d{1,3}){3}$/.test(h); }
  function isPrivateIp(ip) {
    if (isIpv4(ip)) {
      const [a, b] = ip.split('.').map(Number);
      return a === 10 || a === 127 || a === 0 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) ||
        (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127) || a >= 224;
    }
    const l = ip.toLowerCase();
    return l === '::1' || l === '::' || l.startsWith('fc') || l.startsWith('fd') || l.startsWith('fe80');
  }
  function lev(a, b) {
    const m = a.length, n = b.length;
    const d = Array.from({ length: m + 1 }, (_, i) => [i].concat(Array(n).fill(0)));
    for (let j = 1; j <= n; j++) d[0][j] = j;
    for (let i = 1; i <= m; i++) for (let j = 1; j <= n; j++)
      d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    return d[m][n];
  }
  function entropy(s) {
    const c = {};
    for (const ch of s) c[ch] = (c[ch] || 0) + 1;
    return -Object.values(c).reduce((a, v) => a + (v / s.length) * Math.log2(v / s.length), 0);
  }
  function b64url(s) {
    const bytes = new TextEncoder().encode(s);
    let bin = '';
    bytes.forEach((b) => (bin += String.fromCharCode(b)));
    return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }
  function netErr(e) {
    const m = String((e && e.message) || e).toLowerCase();
    if (/ssl|certificate|handshake|trust anchor|cert/.test(m)) return 'ssl';
    if (/unable to resolve|unknownhost|nodename|enotfound|resolve/.test(m)) return 'dns';
    if (/timeout|timed out|abort/.test(m)) return 'timeout';
    if (/cors/.test(m)) return 'cors';
    return 'other';
  }
  const json = (r) => { try { return JSON.parse(r.data); } catch (e) { return null; } };

  // ---------- 1) شكل الرابط ----------
  function structureChecks(url, u, F) {
    const host = u.hostname.toLowerCase(), full = url.toLowerCase();
    const rawHost = ((url.match(/^[a-z][a-z0-9+.-]*:\/\/(?:[^@\/?#]*@)?([^:\/?#]+)/i) || [])[1] || '').toLowerCase();

    if (!/^https?:$/.test(u.protocol)) add(F, 'high', 25, 'بروتوكول غير معتاد: ' + u.protocol);
    if (u.protocol === 'http:') add(F, 'medium', 10, 'الرابط بدون تشفير (HTTP)');
    if (u.username || u.password) add(F, 'high', 25, 'الرابط فيه بيانات قبل علامة @ (حيلة لإخفاء الوجهة الحقيقية)');
    if (isIpv4(host)) {
      add(F, 'high', 25, 'الرابط يستخدم عنوان IP بدل اسم دومين');
      if (isPrivateIp(host)) add(F, 'high', 20, 'عنوان IP داخلي/خاص: ' + host);
    }
    if (/^(0x[0-9a-f]+|\d{8,10})$/.test(rawHost)) add(F, 'high', 25, 'عنوان IP مُخفى بصيغة رقمية/سداسية عشرية');
    if (host.includes('xn--')) add(F, 'high', 25, 'دومين Punycode (احتمال تقليد حروف / Homograph)');
    const labels = host.split('.');
    if (labels.length > 4) add(F, 'medium', 12, 'عدد كبير من النطاقات الفرعية (' + labels.length + ')');
    const tld = labels[labels.length - 1];
    if (SUSP_TLDS.has(tld)) add(F, 'medium', 12, 'امتداد دومين شائع في الاحتيال (.' + tld + ')');
    if (SHORTENERS.has(host) || SHORTENERS.has(regDomain(host))) add(F, 'medium', 12, 'رابط مختصر - الوجهة الحقيقية مخفية');
    if (url.length > 120) add(F, 'low', 6, 'الرابط طويل جدا (' + url.length + ' حرف)');
    if ((host.match(/-/g) || []).length >= 3) add(F, 'low', 6, 'الدومين فيه شرطات كتير');
    if (u.port && !['80', '443'].includes(u.port)) add(F, 'medium', 10, 'بورت غير قياسي: ' + u.port);
    const hits = PHISH_WORDS.filter((w) => full.includes(w));
    if (hits.length >= 3) add(F, 'medium', 12, 'كلمات تصيّد كتير في الرابط: ' + hits.slice(0, 6).join(', '));
    else if (hits.length) add(F, 'low', 4, 'كلمات حساسة في الرابط: ' + hits.join(', '));
    if (/%[0-9a-f]{2}.*%[0-9a-f]{2}.*%[0-9a-f]{2}/.test(full)) add(F, 'low', 6, 'ترميز مفرط (%) في الرابط');
    if (/\.(exe|scr|bat|cmd|msi|apk|jar|js|vbs|ps1)$/.test(u.pathname.toLowerCase())) add(F, 'high', 20, 'الرابط يشير لملف تنفيذي/سكريبت');
    if (/[?&][^=]*=(https?%3a|https?:)\/\//i.test(u.search)) add(F, 'low', 8, 'الرابط بيحمل رابط تاني جواه (احتمال Open Redirect)');
  }

  function brandChecks(host, reg, F) {
    if (isIpv4(host)) return null;
    const sld = reg.split('.')[0];
    const norm = sld.replace(/0/g, 'o').replace(/1/g, 'l').replace(/3/g, 'e').replace(/5/g, 's').replace(/\$/g, 's').replace(/vv/g, 'w').replace(/rn/g, 'm');
    const leet = (s) => s.replace(/0/g, 'o').replace(/1/g, 'l').replace(/3/g, 'e').replace(/5/g, 's').replace(/\$/g, 's');
    const sub = leet(host.split('.').slice(0, -2).join('.'));
    for (const [brand, legit] of Object.entries(BRANDS)) {
      if (legit.includes(reg) || legit.some((d) => host === d || host.endsWith('.' + d))) continue;
      if (norm === brand && sld !== brand) { add(F, 'critical', 40, 'تقليد حروف لاسم ' + brand + ' (' + sld + ') - احتمال انتحال'); return brand; }
      if (sld.length >= 5 && brand.length >= 5 && lev(sld, brand) <= 1) { add(F, 'high', 30, 'اسم قريب جدا من ' + brand + ' (Typosquatting)'); return brand; }
      if (sld.includes(brand)) { add(F, 'high', 25, 'الدومين فيه اسم ' + brand + ' لكنه مش الدومين الرسمي'); return brand; }
      if (sub.includes(brand)) { add(F, 'high', 25, 'اسم ' + brand + ' ظاهر كنطاق فرعي في دومين غريب (' + reg + ')'); return brand; }
    }
    if (sld.length >= 10 && entropy(sld) > 3.4 && /\d/.test(sld)) add(F, 'low', 8, 'اسم الدومين عشوائي الشكل (احتمال دومين مولّد آليا)');
    return null;
  }

  // ---------- 2) DNS عبر DoH ----------
  async function dohQ(http, name, type) {
    const eps = [
      'https://cloudflare-dns.com/dns-query?name=' + encodeURIComponent(name) + '&type=' + type,
      'https://dns.google/resolve?name=' + encodeURIComponent(name) + '&type=' + type,
    ];
    let last;
    for (const url of eps) {
      try {
        const r = await http.request({ url, headers: { accept: 'application/dns-json' }, timeout: 8000 });
        const j = json(r);
        if (j && typeof j.Status === 'number') return j;
      } catch (e) { last = e; }
    }
    throw last || new Error('DoH غير متاح');
  }

  async function dnsTask(host, http, F, meta) {
    const [A, AAAA, NS] = await Promise.all([dohQ(http, host, 'A'), dohQ(http, host, 'AAAA').catch(() => null), dohQ(http, regDomain(host), 'NS').catch(() => null)]);
    const ans = (j) => (j && j.Answer) || [];
    const ips = ans(A).filter((x) => x.type === 1).map((x) => x.data).concat(ans(AAAA).filter((x) => x.type === 28).map((x) => x.data));
    if (A.Status === 3) { add(F, 'high', 25, 'الدومين مش موجود (NXDOMAIN)', 'dns'); return 'غير موجود'; }
    if (!ips.length && !ans(A).some((x) => x.type === 5)) { add(F, 'medium', 12, 'الدومين مالوش عنوان IP', 'dns'); return 'بدون IP'; }
    meta.ips = ips;
    const priv = ips.filter(isPrivateIp);
    if (priv.length) add(F, 'high', 30, 'الدومين بيشاور على عنوان داخلي/خاص: ' + priv.join(', '), 'dns');
    const ttls = ans(A).filter((x) => x.type === 1).map((x) => x.TTL);
    if (ips.length > 6 || (ttls.length && Math.max(...ttls) <= 30 && ips.length > 2)) add(F, 'low', 8, 'نمط DNS متقلّب (احتمال Fast-Flux)', 'dns');
    const cname = ans(A).find((x) => x.type === 5);
    if (cname) meta.cname = cname.data.replace(/\.$/, '');
    const nsList = ans(NS).filter((x) => x.type === 2).map((x) => x.data.replace(/\.$/, ''));
    if (nsList.length) meta.ns = nsList.slice(0, 3);
    add(F, 'info', 0, 'عناوين IP: ' + ips.slice(0, 4).join(', '), 'dns');
    return ips.length + ' IP';
  }

  // ---------- 3) RDAP ----------
  async function rdapTask(reg, http, F, meta) {
    const r = await http.request({ url: 'https://rdap.org/domain/' + encodeURIComponent(reg), headers: { accept: 'application/rdap+json' }, timeout: 12000 });
    if (r.status === 404) { add(F, 'medium', 10, 'مفيش سجل تسجيل للدومين في RDAP', 'rdap'); return 'مفيش سجل'; }
    const j = json(r);
    if (!j || !j.events) throw new Error('رد RDAP غير مفهوم');
    const reg_ev = j.events.find((e) => e.eventAction === 'registration');
    const ent = (j.entities || []).find((e) => (e.roles || []).includes('registrar'));
    try {
      const fn = ent && ent.vcardArray && ent.vcardArray[1].find((x) => x[0] === 'fn');
      if (fn) meta.registrar = fn[3];
    } catch (e) { /* تجاهل */ }
    if (!reg_ev) { add(F, 'medium', 8, 'مفيش تاريخ تسجيل للدومين', 'rdap'); return 'بدون تاريخ'; }
    const age = Math.floor((Date.now() - new Date(reg_ev.eventDate).getTime()) / 864e5);
    meta.ageDays = age;
    if (age < 30) add(F, 'high', 25, 'الدومين جديد جدا (عمره ' + age + ' يوم)', 'rdap');
    else if (age < 180) add(F, 'medium', 12, 'الدومين حديث (عمره ' + age + ' يوم)', 'rdap');
    else add(F, 'info', 0, 'عمر الدومين: ' + Math.floor(age / 365) + ' سنة و' + (age % 365) + ' يوم', 'rdap');
    return age + ' يوم';
  }

  // ---------- 4) جلب الصفحة + التحويلات ----------
  async function fetchChain(url, http, F) {
    const chain = [url];
    let cur = url;
    for (let i = 0; i <= MAX_HOPS; i++) {
      let r;
      try {
        r = await http.request({ url: cur, headers: { 'user-agent': UA, accept: 'text/html,*/*' }, timeout: 12000, noRedirect: true });
      } catch (e) {
        const k = netErr(e);
        if (k === 'ssl') add(F, 'high', 30, 'شهادة SSL غير صالحة أو غير موثوقة', 'fetch');
        else if (k === 'dns') add(F, 'medium', 10, 'تعذّر الوصول للموقع (الدومين مش بيتحل)', 'fetch');
        else if (k === 'timeout') add(F, 'low', 5, 'الموقع بطيء جدا أو مش بيرد', 'fetch');
        else if (k === 'cors') throw skip('فحص المحتوى متاح داخل تطبيق الأندرويد فقط');
        else add(F, 'medium', 8, 'تعذّر فتح الصفحة', 'fetch');
        return { resp: null, chain, err: k };
      }
      const loc = r.headers && r.headers.location;
      if (r.status >= 300 && r.status < 400 && loc) {
        let nxt;
        try { nxt = new URL(loc, cur).href; } catch (e) { nxt = loc; }
        if (!/^https?:/i.test(nxt)) { add(F, 'high', 20, 'تحويل لبروتوكول غير ويب: ' + nxt.slice(0, 40), 'fetch'); chain.push(nxt); return { resp: null, chain }; }
        chain.push(nxt); cur = nxt; continue;
      }
      return { resp: r, chain };
    }
    add(F, 'medium', 12, 'تحويلات كتير جدا (أكتر من ' + MAX_HOPS + ')', 'fetch');
    return { resp: null, chain };
  }

  function chainFindings(chain, F) {
    if (chain.length < 2) return;
    add(F, 'info', 0, 'سلسلة التحويلات: ' + chain.slice(0, 5).map((x) => { try { return new URL(x).host; } catch (e) { return x; } }).join(' ← '), 'fetch');
    if (chain.length > 3) add(F, 'medium', 10, 'عدد تحويلات كبير (' + (chain.length - 1) + ')', 'fetch');
    try {
      const a = regDomain(new URL(chain[0]).hostname), b = regDomain(new URL(chain[chain.length - 1]).hostname);
      if (a !== b) add(F, 'medium', 10, 'الوجهة النهائية دومين مختلف: ' + b, 'fetch');
    } catch (e) { /* تجاهل */ }
  }

  function headerFindings(r, F) {
    const h = r.headers || {};
    const ctype = h['content-type'] || '', disp = h['content-disposition'] || '';
    if (/attachment/i.test(disp)) add(F, 'high', 20, 'الرابط بينزّل ملف تلقائيا', 'fetch');
    if (/octet-stream|x-msdownload|vnd\.android\.package-archive|x-apk|x-dosexec/i.test(ctype)) add(F, 'high', 20, 'نوع المحتوى ملف تنفيذي/ثنائي: ' + ctype, 'fetch');
    const miss = ['content-security-policy', 'x-frame-options', 'strict-transport-security', 'x-content-type-options'].filter((n) => !(n in h));
    if (miss.length >= 4 && /text\/html/i.test(ctype)) add(F, 'low', 4, 'الموقع من غير هيدرز أمان أساسية', 'fetch');
    return ctype;
  }

  // ---------- 5) تحليل المحتوى ----------
  function analyzeHtml(html, finalUrl, F, meta) {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const fu = new URL(finalUrl), pageReg = regDomain(fu.hostname);
    const title = (doc.title || '').trim();
    if (title) { meta.title = title.slice(0, 120); add(F, 'info', 0, 'عنوان الصفحة: ' + meta.title, 'content'); }

    const t = title.toLowerCase();
    for (const [brand, legit] of Object.entries(BRANDS)) {
      if (t.includes(brand) && !legit.includes(pageReg) && !legit.some((d) => fu.hostname.endsWith('.' + d))) {
        add(F, 'high', 25, 'الصفحة بتستخدم اسم ' + brand + ' في العنوان لكنها على دومين تاني (' + pageReg + ')', 'content');
        break;
      }
    }

    const pw = doc.querySelectorAll('input[type=password]');
    if (pw.length) {
      add(F, 'medium', 12, 'الصفحة فيها حقل كلمة سر', 'content');
      doc.querySelectorAll('form').forEach((form) => {
        if (!form.querySelector('input[type=password]')) return;
        const action = form.getAttribute('action');
        if (action) {
          try {
            const tr = regDomain(new URL(action, finalUrl).hostname);
            if (tr && tr !== pageReg) add(F, 'critical', 40, 'فورم كلمة السر بيبعت لدومين تاني: ' + tr, 'content');
          } catch (e) { /* تجاهل */ }
        }
        if (fu.protocol === 'http:') add(F, 'high', 20, 'فورم كلمة سر على HTTP بدون تشفير', 'content');
      });
    }
    const sens = [...doc.querySelectorAll('input')].some((i) =>
      /(card|cvv|cvc|cc-number|otp|iban|ssn)/i.test((i.name || '') + ' ' + (i.id || '') + ' ' + (i.getAttribute('autocomplete') || '')) ||
      /(بطاقة|الرقم السري|رمز التحقق|كارت)/.test(i.getAttribute('placeholder') || ''));
    if (sens) add(F, 'medium', 10, 'الصفحة بتطلب بيانات دفع أو رمز تحقق', 'content');

    for (const ifr of doc.querySelectorAll('iframe')) {
      const st = (ifr.getAttribute('style') || '').replace(/\s/g, '').toLowerCase();
      if (['0', '1'].includes(ifr.getAttribute('width')) || ['0', '1'].includes(ifr.getAttribute('height')) || /display:none|visibility:hidden/.test(st)) {
        add(F, 'high', 20, 'iframe مخفي في الصفحة', 'content'); break;
      }
    }
    if (doc.querySelector('meta[http-equiv="refresh" i]')) add(F, 'medium', 10, 'الصفحة بتعمل تحويل تلقائي عبر meta refresh', 'content');

    // روابط بتكذب: النص دومين والرابط الفعلي دومين تاني
    let liars = 0;
    doc.querySelectorAll('a[href]').forEach((a) => {
      const txt = (a.textContent || '').trim();
      const m = txt.match(/^(?:https?:\/\/)?((?:[a-z0-9-]+\.)+[a-z]{2,})(?:[\/?#]|$)/i);
      if (!m) return;
      try {
        const hr = regDomain(new URL(a.getAttribute('href'), finalUrl).hostname);
        if (hr && hr !== regDomain(m[1])) liars++;
      } catch (e) { /* تجاهل */ }
    });
    if (liars) add(F, 'high', 20, 'فيه ' + liars + ' رابط نصه بيوري دومين والوجهة الفعلية دومين تاني', 'content');

    const scripts = [...doc.querySelectorAll('script:not([src])')].map((s) => s.textContent).join('\n');
    const pats = {
      'eval\\s*\\(': 'eval', 'atob\\s*\\(': 'فك base64', 'unescape\\s*\\(': 'unescape', 'document\\.write\\s*\\(': 'document.write',
      'fromCharCode': 'fromCharCode', 'window\\.location(\\.href)?\\s*=': 'تحويل بالجافاسكربت',
    };
    const obf = Object.entries(pats).filter(([p]) => new RegExp(p).test(scripts)).map(([, m]) => m);
    if (obf.length >= 3) add(F, 'high', 20, 'جافاسكربت مموّه/مشبوه: ' + obf.join(' | '), 'content');
    else if (obf.length) add(F, 'low', 5, 'أنماط جافاسكربت تستحق الحذر: ' + obf.join(' | '), 'content');
    if (/addEventListener\(\s*['"]key(down|press|up)/.test(scripts) && /(XMLHttpRequest|fetch\(|sendBeacon)/.test(scripts))
      add(F, 'medium', 12, 'سكربت بيراقب الكتابة وبيبعت بيانات (احتمال Keylogger)', 'content');
    if (/oncontextmenu\s*=\s*["']?return false/i.test(html)) add(F, 'low', 4, 'الصفحة بتمنع الضغط المطوّل/كليك يمين', 'content');

    const ext = new Set();
    doc.querySelectorAll('script[src]').forEach((s) => {
      try { ext.add(regDomain(new URL(s.getAttribute('src'), finalUrl).hostname)); } catch (e) { /* تجاهل */ }
    });
    ext.delete(pageReg);
    if (ext.size > 8) add(F, 'low', 6, 'سكربتات من ' + ext.size + ' دومين خارجي', 'content');

    const low = html.toLowerCase();
    if (/(your (account|device) (has been|is) (suspended|locked|infected)|verify your identity|urgent action required|you have won|تم إيقاف حسابك|تم تعليق حسابك|لقد ربحت)/i.test(low))
      add(F, 'high', 18, 'نص ضغط/تخويف نموذجي للتصيّد', 'content');
    if (/(coinhive|cryptonight|miner\.start)/.test(low)) add(F, 'high', 25, 'مؤشرات تعدين عملات داخل المتصفح', 'content');
  }

  // ---------- 6) القوائم والـ APIs الخارجية ----------
  async function phishTask(url, host, ctx, F) {
    const KEY = 'ls_openphish';
    let list = null;
    try { const c = JSON.parse(ctx.storage.get(KEY) || 'null'); if (c && Date.now() - c.t < 36e5) list = c.list; } catch (e) { /* تجاهل */ }
    if (!list) {
      const r = await ctx.http.request({ url: 'https://openphish.com/feed.txt', timeout: 15000 });
      if (r.status !== 200) throw new Error('تعذّر تحميل القائمة (' + r.status + ')');
      list = String(r.data).split(/\r?\n/).map((x) => x.trim()).filter(Boolean);
      try { ctx.storage.set(KEY, JSON.stringify({ t: Date.now(), list })); } catch (e) { /* تجاهل */ }
    }
    const strip = (s) => s.replace(/^https?:\/\//i, '').replace(/\/+$/, '').toLowerCase();
    const me = strip(url);
    const exact = list.some((x) => strip(x) === me);
    let hostHit = false;
    if (!exact) hostHit = list.some((x) => { try { return new URL(x).hostname.toLowerCase() === host; } catch (e) { return false; } });
    if (exact) add(F, 'critical', 60, 'الرابط موجود في قائمة OpenPhish للتصيّد', 'phish');
    else if (hostHit) add(F, 'high', 35, 'الدومين ظهر في قائمة OpenPhish للتصيّد', 'phish');
    return exact ? 'مُبلّغ عنه' : hostHit ? 'الدومين مُبلّغ' : 'نظيف (' + list.length + ' رابط)';
  }

  async function vtTask(url, key, http, F, out) {
    if (!key) throw skip('مفيش مفتاح VirusTotal (حطه من الإعدادات)');
    const H = { 'x-apikey': key, accept: 'application/json' };
    const guard = (r) => {
      if (r.status === 401 || r.status === 403) throw new Error('مفتاح VirusTotal غير صحيح');
      if (r.status === 429) throw new Error('تجاوزت حد VirusTotal (4 فحوصات/دقيقة)');
    };
    let stats, results;
    let r = await http.request({ url: VT + '/urls/' + b64url(url), headers: H, timeout: 15000 });
    guard(r);
    if (r.status === 404) {
      const s = await http.request({ url: VT + '/urls', method: 'POST', headers: Object.assign({ 'content-type': 'application/x-www-form-urlencoded' }, H), data: { url }, timeout: 15000 });
      guard(s);
      const aid = (json(s) || {}).data && json(s).data.id;
      if (!aid) throw new Error('VirusTotal رفض الطلب');
      for (let i = 0; i < 10 && !stats; i++) {
        await sleep(3000);
        const a = await http.request({ url: VT + '/analyses/' + aid, headers: H, timeout: 15000 });
        guard(a);
        const j = json(a);
        if (j && j.data && j.data.attributes.status === 'completed') { stats = j.data.attributes.stats; results = j.data.attributes.results; }
      }
      if (!stats) throw new Error('VirusTotal لسه بيفحص - جرّب بعد شوية');
    } else if (r.status === 200) {
      const at = (json(r) || {}).data.attributes;
      stats = at.last_analysis_stats; results = at.last_analysis_results;
    } else throw new Error('VirusTotal رجّع خطأ ' + r.status);

    const mal = stats.malicious || 0, sus = stats.suspicious || 0, total = Object.values(stats).reduce((a, b) => a + b, 0) || 1;
    const engines = Object.values(results || {}).filter((x) => x.category === 'malicious' || x.category === 'suspicious')
      .map((x) => x.engine_name + (x.result ? ': ' + x.result : '')).slice(0, 12);
    out.vt = { mal, sus, total, engines };
    const msg = 'VirusTotal: ' + mal + ' خبيث / ' + sus + ' مشبوه من ' + total + ' محرك';
    if (mal >= 5) add(F, 'critical', 60, msg, 'vt');
    else if (mal >= 2) add(F, 'high', Math.min(55, 30 + 5 * mal), msg, 'vt');
    else if (mal === 1) add(F, 'medium', 18, msg + ' (محرك واحد - ممكن يكون إنذار كاذب)', 'vt');
    else if (sus >= 1) add(F, 'low', 10, msg, 'vt');
    else add(F, 'info', 0, msg + ' ✓', 'vt');
    return mal + '/' + total;
  }

  async function gsbTask(url, key, http, F) {
    if (!key) throw skip('مفيش مفتاح Safe Browsing (اختياري)');
    const body = {
      client: { clientId: 'ahmed-hamdy-linkshield', clientVersion: '2.0' },
      threatInfo: {
        threatTypes: ['MALWARE', 'SOCIAL_ENGINEERING', 'UNWANTED_SOFTWARE', 'POTENTIALLY_HARMFUL_APPLICATION'],
        platformTypes: ['ANY_PLATFORM'], threatEntryTypes: ['URL'], threatEntries: [{ url }],
      },
    };
    const r = await http.request({ url: 'https://safebrowsing.googleapis.com/v4/threatMatches:find?key=' + encodeURIComponent(key), method: 'POST', headers: { 'content-type': 'application/json' }, data: body, timeout: 12000 });
    if (r.status !== 200) throw new Error('Safe Browsing خطأ ' + r.status);
    const m = (json(r) || {}).matches || [];
    if (m.length) { add(F, 'critical', 60, 'Google Safe Browsing: الرابط مُبلّغ عنه (' + [...new Set(m.map((x) => x.threatType))].join(', ') + ')', 'gsb'); return 'مُبلّغ عنه'; }
    add(F, 'info', 0, 'Google Safe Browsing: لا توجد تهديدات ✓', 'gsb');
    return 'نظيف';
  }

  // ---------- التجميع ----------
  function levelOf(score) { return LEVELS.find((l) => score <= l.max); }

  async function scan(raw, ctx) {
    const t0 = Date.now();
    const F = [], checks = {}, meta = {}, out = {};
    const opt = Object.assign({ content: true, phish: true }, ctx.options || {});
    const set = (id, st, detail) => {
      checks[id] = { id, label: STAGES[id], st, detail: detail || '' };
      if (ctx.onStage) ctx.onStage(checks[id]);
    };
    const url = normalizeUrl(raw);
    let u;
    try { u = new URL(url); } catch (e) { return { error: 'رابط غير صالح' }; }
    if (!u.hostname) return { error: 'رابط غير صالح' };
    const host = u.hostname.toLowerCase(), reg = regDomain(host), ip = isIpv4(host);
    const web = /^https?:$/.test(u.protocol);

    set('structure', 'run');
    structureChecks(url, u, F);
    meta.brand = brandChecks(host, reg, F);
    set('structure', 'ok');

    const tasks = [];
    const task = (id, enabled, why, fn) => {
      if (!enabled) { set(id, 'skip', why); return; }
      set(id, 'run');
      tasks.push(fn().then((d) => set(id, 'ok', d), (e) => set(id, e && e.skip ? 'skip' : 'fail', (e && e.message) || 'فشل')));
    };

    let finalUrl = url;
    task('dns', web && !ip, ip ? 'الرابط IP مباشر' : 'غير ويب', () => dnsTask(host, ctx.http, F, meta));
    task('rdap', web && !ip, ip ? 'الرابط IP مباشر' : 'غير ويب', () => rdapTask(reg, ctx.http, F, meta));
    task('phish', web && opt.phish, 'متوقف من الإعدادات', () => phishTask(url, host, ctx, F));
    task('vt', web, 'غير ويب', () => vtTask(url, ctx.keys && ctx.keys.vt, ctx.http, F, out));
    task('gsb', web, 'غير ويب', () => gsbTask(url, ctx.keys && ctx.keys.gsb, ctx.http, F));
    if (web && opt.content) {
      set('content', 'wait');
      task('fetch', true, '', async () => {
        const { resp, chain } = await fetchChain(url, ctx.http, F);
        chainFindings(chain, F);
        finalUrl = chain[chain.length - 1];
        if (!resp) { set('content', 'skip', 'الصفحة ماتفتحتش'); return 'تعذّر الجلب'; }
        const ctype = headerFindings(resp, F);
        meta.status = resp.status;
        if (resp.status >= 400) add(F, 'low', 4, 'الصفحة رجّعت كود ' + resp.status, 'fetch');
        if (/html|xml|^$/.test(ctype) || /^\s*</.test(String(resp.data).slice(0, 200))) {
          set('content', 'run');
          try { analyzeHtml(String(resp.data).slice(0, MAX_BODY), finalUrl, F, meta); set('content', 'ok'); }
          catch (e) { set('content', 'fail', 'تعذّر تحليل الصفحة'); }
        } else set('content', 'skip', 'المحتوى مش صفحة ويب');
        return chain.length - 1 + ' تحويل';
      });
    } else { set('fetch', 'skip', web ? 'متوقف من الإعدادات' : 'غير ويب'); set('content', 'skip', 'متوقف'); }

    await Promise.all(tasks);

    let score = Math.min(100, F.reduce((a, x) => a + x.points, 0));
    if (F.some((x) => x.severity === 'critical')) score = Math.max(score, 85);
    const lvl = levelOf(score);
    const order = { critical: 0, high: 1, medium: 2, low: 3, info: 4 };
    F.sort((a, b) => order[a.severity] - order[b.severity]);
    const list = Object.values(checks);
    const done = list.filter((c) => c.st === 'ok').length;
    return {
      url, final: finalUrl, host, score, level: lvl.key, verdict: lvl.label, color: lvl.color,
      findings: F, checks: list, coverage: { done, total: list.length },
      vt: out.vt || null, meta, ms: Date.now() - t0, at: Date.now(),
    };
  }

  return { scan, STAGES, LEVELS, structureChecks, brandChecks, analyzeHtml, regDomain, normalizeUrl, isPrivateIp, b64url, levelOf, netErr };
});
