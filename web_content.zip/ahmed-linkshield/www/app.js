/* AHMED HAMDY — Link Shield (واجهة التطبيق) */
(function () {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const SEV = { critical: 'حرج', high: 'عالي', medium: 'متوسط', low: 'منخفض', info: 'معلومة' };
  const SEV_ORDER = ['critical', 'high', 'medium', 'low', 'info'];
  const SRC = { local: 'LOCAL', dns: 'DNS', rdap: 'RDAP', fetch: 'HTTP', content: 'PAGE', phish: 'OPENPHISH', vt: 'VT', gsb: 'GSB' };

  // ---------- تخزين آمن ----------
  const store = {
    get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* تجاهل */ } },
  };
  const cfg = window.APP_CONFIG || {};
  function loadSettings() {
    let s = {};
    try { s = JSON.parse(store.get('ls_settings') || '{}'); } catch (e) { /* تجاهل */ }
    return Object.assign({ vt: cfg.VT_API_KEY || '', gsb: cfg.GSB_API_KEY || '', content: true, phish: true, clip: false }, s);
  }
  let S = loadSettings();
  const saveSettings = () => store.set('ls_settings', JSON.stringify(S));

  // ---------- طبقة HTTP: native في الأندرويد، fetch في المتصفح ----------
  function makeHttp() {
    const cap = window.Capacitor;
    const nat = cap && cap.isNativePlatform && cap.isNativePlatform() && cap.Plugins && cap.Plugins.CapacitorHttp;
    if (nat) {
      return {
        native: true,
        async request(o) {
          const r = await nat.request({
            url: o.url, method: o.method || 'GET', headers: o.headers || {}, data: o.data,
            connectTimeout: o.timeout || 10000, readTimeout: o.timeout || 10000,
            disableRedirects: !!o.noRedirect, responseType: 'text',
          });
          const h = {};
          for (const k in r.headers || {}) h[k.toLowerCase()] = r.headers[k];
          return { status: r.status, headers: h, data: typeof r.data === 'string' ? r.data : JSON.stringify(r.data), url: r.url || o.url };
        },
      };
    }
    return {
      native: false,
      async request(o) {
        const ctl = new AbortController();
        const t = setTimeout(() => ctl.abort(), o.timeout || 10000);
        try {
          let body;
          const ct = (o.headers && (o.headers['content-type'] || o.headers['Content-Type'])) || '';
          if (o.data != null) body = /json/.test(ct) ? JSON.stringify(o.data) : new URLSearchParams(o.data).toString();
          const r = await fetch(o.url, { method: o.method || 'GET', headers: o.headers, body, signal: ctl.signal });
          const h = {};
          r.headers.forEach((v, k) => (h[k] = v));
          return { status: r.status, headers: h, data: await r.text(), url: r.url };
        } catch (e) {
          if (e.name === 'AbortError') throw new Error('timeout');
          throw new Error('CORS/network: ' + e.message);
        } finally { clearTimeout(t); }
      },
    };
  }
  const http = makeHttp();

  // ---------- واجهة ----------
  let toastT;
  function toast(m) {
    const t = $('toast'); t.textContent = m; t.classList.add('show');
    clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), 1800);
  }
  function view(id) {
    document.querySelectorAll('.view').forEach((v) => v.classList.toggle('active', v.id === id));
    document.querySelectorAll('.tabs button').forEach((b) => b.classList.toggle('on', b.dataset.v === id));
    $('v-scan').parentElement.scrollTop = 0;
    if (id === 'v-hist') renderHistory();
  }
  document.querySelectorAll('.tabs button').forEach((b) => (b.onclick = () => view(b.dataset.v)));

  function pingNet() {
    const on = navigator.onLine !== false;
    $('net').className = 'net ' + (on ? 'on' : 'off');
  }
  window.addEventListener('online', pingNet); window.addEventListener('offline', pingNet); pingNet();

  // ---------- مراحل الفحص ----------
  const ICON = { wait: '○', run: '◌', ok: '✓', fail: '!', skip: '–' };
  function onStage(s) {
    let li = $('st-' + s.id);
    if (!li) { li = document.createElement('li'); li.id = 'st-' + s.id; $('stages').appendChild(li); }
    li.className = s.st;
    li.innerHTML = '<span class="ic">' + ICON[s.st] + '</span><span>' + esc(s.label) + '</span>' + (s.detail ? '<small>' + esc(s.detail) + '</small>' : '');
  }

  // ---------- العرض ----------
  function gauge(score, color) {
    const L = Math.PI * 50;
    return '<div class="gauge"><svg viewBox="0 0 120 66"><path d="M10 60 A50 50 0 0 1 110 60" fill="none" stroke="#1a2542" stroke-width="10" stroke-linecap="round"/>' +
      '<path d="M10 60 A50 50 0 0 1 110 60" fill="none" stroke="' + color + '" stroke-width="10" stroke-linecap="round" stroke-dasharray="' + L + '" stroke-dashoffset="' + (L * (1 - score / 100)) + '"/></svg>' +
      '<div class="num" style="color:' + color + '">' + score + '<small>/100</small></div></div>';
  }
  function resultHtml(r) {
    if (r.error) return '<div class="err">' + esc(r.error) + '</div>';
    const groups = SEV_ORDER.map((k) => {
      const items = r.findings.filter((f) => f.severity === k);
      if (!items.length) return '';
      return '<div class="fgroup"><h4>' + SEV[k] + ' (' + items.length + ')</h4>' +
        items.map((f) => '<div class="f ' + k + '"><span>' + esc(f.message) + '</span><span class="src">' + (SRC[f.source] || f.source) + '</span></div>').join('') + '</div>';
    }).join('');
    const chips = r.checks.map((c) => '<span class="chip ' + c.st + '" title="' + esc(c.detail || '') + '">' + ({ ok: '✓ ', fail: '! ', skip: '– ' }[c.st] || '') + esc(c.label) + '</span>').join('');
    const m = r.meta || {};
    const tags = [];
    if (m.ageDays != null) tags.push('عمر الدومين: ' + (m.ageDays >= 365 ? Math.floor(m.ageDays / 365) + ' سنة' : m.ageDays + ' يوم'));
    if (m.registrar) tags.push(m.registrar);
    if (m.ips && m.ips[0]) tags.push(m.ips[0]);
    tags.push((r.ms / 1000).toFixed(1) + ' ث');
    const eng = r.vt && r.vt.engines.length ? '<div class="eng"><b>المحركات اللي بلّغت:</b><br>' + r.vt.engines.map(esc).join('<br>') + '</div>' : '';
    return '<div class="res" style="--c:' + r.color + '">' +
      '<div class="res-top">' + gauge(r.score, r.color) + '<div class="rinfo"><div class="verdict">' + r.verdict + '</div>' +
      '<div class="u">' + esc(r.url) + '</div>' + (r.final && r.final !== r.url ? '<div class="u f">↳ ' + esc(r.final) + '</div>' : '') +
      '<div class="meta">' + tags.map((t) => '<span class="tag">' + esc(t) + '</span>').join('') + '</div></div></div>' +
      '<div class="cov"><h4>تغطية الفحص: ' + r.coverage.done + ' من ' + r.coverage.total + ' طبقة اشتغلت</h4><div class="chips">' + chips + '</div></div>' +
      eng + groups +
      '<div class="acts"><button class="btn" data-act="copy">نسخ التقرير</button><button class="btn" data-act="share">مشاركة</button></div>' +
      '<div class="disc">النتيجة تقدير آلي ومش ضمان. لو الرابط جاي من حد مجهول وبيطلب بيانات، ماتفتحوش.</div></div>';
  }
  function reportText(r) {
    return 'AHMED HAMDY — Link Shield\n' + r.url + '\nالنتيجة: ' + r.verdict + ' (' + r.score + '/100)\n' +
      r.findings.filter((f) => f.severity !== 'info').map((f) => '- [' + SEV[f.severity] + '] ' + f.message).join('\n');
  }

  let last = [];
  $('out').addEventListener('click', async (e) => {
    const b = e.target.closest('[data-act]'); if (!b) return;
    const idx = [...$('out').querySelectorAll('.res')].indexOf(b.closest('.res'));
    const r = last[idx]; if (!r) return;
    const txt = reportText(r);
    if (b.dataset.act === 'share' && navigator.share) { try { await navigator.share({ text: txt }); return; } catch (er) { /* يكمل للنسخ */ } }
    try { await navigator.clipboard.writeText(txt); toast('تم نسخ التقرير'); } catch (er) { toast('تعذّر النسخ'); }
  });

  // ---------- التشغيل ----------
  let busy = false;
  async function run() {
    if (busy) return;
    const lines = $('in').value.split(/\s*\n\s*/).map((s) => s.trim()).filter(Boolean).slice(0, 5);
    if (!lines.length) { toast('الصق رابط الأول'); return; }
    busy = true; $('go').disabled = true; $('go-t').textContent = 'جاري الفحص...';
    $('out').innerHTML = ''; last = [];
    const ctx = {
      http, storage: store, keys: { vt: S.vt.trim(), gsb: S.gsb.trim() },
      options: { content: S.content, phish: S.phish }, onStage,
    };
    try {
      for (let i = 0; i < lines.length; i++) {
        $('stages').innerHTML = ''; $('scanning').hidden = false;
        if (lines.length > 1) $('go-t').textContent = 'فحص ' + (i + 1) + ' من ' + lines.length;
        let r;
        try { r = await Core.scan(lines[i], ctx); } catch (e) { r = { error: 'حصل خطأ غير متوقع أثناء الفحص' }; }
        $('scanning').hidden = true;
        last.push(r);
        $('out').insertAdjacentHTML('beforeend', resultHtml(r));
        if (!r.error) saveHistory(r);
        if (i === 0) $('out').scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    } finally { busy = false; $('go').disabled = false; $('go-t').textContent = 'ابدأ الفحص'; $('scanning').hidden = true; }
  }
  $('go').onclick = run;
  $('in').addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey && !$('in').value.includes('\n')) { e.preventDefault(); run(); } });
  $('clear').onclick = () => { $('in').value = ''; $('out').innerHTML = ''; $('in').focus(); };
  $('paste').onclick = async () => {
    try { const t = await navigator.clipboard.readText(); if (t) { $('in').value = t.trim(); toast('تم اللصق'); } else toast('الحافظة فاضية'); }
    catch (e) { toast('اضغط مطوّلا في الخانة للصق'); $('in').focus(); }
  };

  // ---------- السجل ----------
  const hist = () => { try { return JSON.parse(store.get('ls_hist') || '[]'); } catch (e) { return []; } };
  function saveHistory(r) {
    const h = hist().filter((x) => x.url !== r.url);
    h.unshift({ url: r.url, score: r.score, color: r.color, verdict: r.verdict, at: r.at });
    store.set('ls_hist', JSON.stringify(h.slice(0, 50)));
  }
  function renderHistory() {
    const h = hist();
    $('hist').innerHTML = h.length ? h.map((x, i) =>
      '<div class="h" data-i="' + i + '" style="--c:' + x.color + '"><div class="sc">' + x.score + '</div><div class="t"><b>' + esc(x.url) + '</b><small>' +
      x.verdict + ' • ' + new Date(x.at).toLocaleString('ar-EG') + '</small></div></div>').join('') : '<div class="empty">لسه مفيش فحوصات</div>';
  }
  $('hist').addEventListener('click', (e) => {
    const el = e.target.closest('.h'); if (!el) return;
    $('in').value = hist()[el.dataset.i].url; view('v-scan'); run();
  });
  $('hclear').onclick = () => { store.set('ls_hist', '[]'); renderHistory(); toast('تم مسح السجل'); };

  // ---------- الإعدادات ----------
  $('k-vt').value = S.vt; $('k-gsb').value = S.gsb;
  $('o-content').checked = S.content; $('o-phish').checked = S.phish; $('o-clip').checked = S.clip;
  $('k-vt').oninput = () => { S.vt = $('k-vt').value; saveSettings(); };
  $('k-gsb').oninput = () => { S.gsb = $('k-gsb').value; saveSettings(); };
  $('o-content').onchange = () => { S.content = $('o-content').checked; saveSettings(); };
  $('o-phish').onchange = () => { S.phish = $('o-phish').checked; saveSettings(); };
  $('o-clip').onchange = () => { S.clip = $('o-clip').checked; saveSettings(); };
  $('vt-eye').onclick = () => { const i = $('k-vt'); i.type = i.type === 'password' ? 'text' : 'password'; };
  $('vt-test').onclick = async () => {
    const k = $('k-vt').value.trim(), out = $('vt-res');
    if (!k) { out.textContent = 'ادخل المفتاح الأول'; return; }
    out.textContent = 'جاري الاختبار...';
    try {
      const r = await http.request({ url: 'https://www.virustotal.com/api/v3/users/' + encodeURIComponent(k), headers: { 'x-apikey': k, accept: 'application/json' }, timeout: 12000 });
      out.textContent = r.status === 200 ? '✓ المفتاح شغال' : r.status === 401 || r.status === 403 ? '✕ المفتاح غير صحيح' : 'رد غير متوقع (' + r.status + ')';
    } catch (e) { out.textContent = http.native ? 'تعذّر الاتصال، اتأكد من النت' : 'الاختبار بيشتغل داخل التطبيق بس'; }
  };

  // ---------- بدء التشغيل ----------
  (async function init() {
    if (S.clip) {
      try {
        const t = (await navigator.clipboard.readText() || '').trim();
        if (/^(https?:\/\/)?([\w-]+\.)+[a-z]{2,}(\/|$|\?)/i.test(t)) $('in').value = t;
      } catch (e) { /* تجاهل */ }
    }
  })();
})();
