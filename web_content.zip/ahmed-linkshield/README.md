# AHMED HAMDY — Link Shield

تطبيق فحص روابط بيشتغل **جوه الموبايل مباشرة** (من غير سيرفر)، ومشروعه جاهز يتحوّل APK.

## الفحوصات
- شكل الرابط: IP مخفي، Punycode، @، امتدادات مشبوهة، روابط مختصرة، تقليد أسماء البراندات (Typosquatting)
- DNS مشفّر (DoH) وعمر الدومين (RDAP)
- تتبع التحويلات (حتى 8) وجلب الصفحة فعليا وتحليل محتواها: فورم كلمة سر بيبعت لدومين تاني، iframe مخفي، روابط بتكذب، جافاسكربت مموّه، Keylogger، بيانات دفع
- OpenPhish (مجاني) + VirusTotal (70+ محرك) + Google Safe Browsing (اختياري)

## الطريقة 1 — الأسهل: GitHub Actions (من غير ما تثبّت حاجة)
1. اعمل حساب على github.com وأنشئ Repository جديد (Private).
2. ارفع كل محتويات الفولدر ده (ملفات المشروع كلها، **بما فيها فولدر `.github`**).
3. من تبويب **Actions** اختار **Build APK** ثم **Run workflow**.
4. استنى 5–8 دقايق، افتح الـ run وانزّل **AhmedHamdy-LinkShield-apk** من Artifacts. فك الضغط هتلاقي `app-debug.apk`.
5. انقله للموبايل وثبّته (فعّل "التثبيت من مصادر غير معروفة").

## الطريقة 2 — على الكمبيوتر (Android Studio)
```
npm install
npx cap add android
npm run icons
npx cap sync android
npx cap open android      # من Android Studio: Build > Build APK(s)
```
المتطلبات: Node 20+ و JDK 21 و Android Studio.

## المفاتيح
افتح التطبيق ← **الإعدادات** ← الصق مفتاح VirusTotal (واختياري Safe Browsing) ← **اختبار المفتاح**.
المفاتيح بتتخزن على الموبايل بس. لو كتبتها في `www/config.js` هتبقى جوه الـ APK ويقدر أي حد يستخرجها، فسيبها فاضية لو هتشارك التطبيق.

## تغيير الاسم أو الأيقونة
- اسم التطبيق على الشاشة الرئيسية: `capacitor.config.json` ← `appName` (يتغير قبل `cap add android`).
- الأيقونة: بدّل ملفات `assets/` وشغّل `npm run icons`.
- اسم الحزمة: `appId` في نفس الملف.

## ملاحظة
الـ APK الناتج نسخة Debug بتتثبّت عادي للاستخدام الشخصي. للنشر على Google Play محتاج نسخة Release موقّعة.
