AD MONEY EARN - HTML source

1. ZIP ফাইলটি Extract করুন।
2. index.html ফাইলটি HTML editor বা HTML-to-APK builder-এ ব্যবহার করুন।
3. এটি একটি front-end demo। Rewarded Ads, secure admin, database বা real payment এখনো যুক্ত নেই।
4. বাস্তব অর্থ বা পেমেন্টের জন্য নিরাপদ backend, যাচাইকৃত ad integration এবং আইন/প্ল্যাটফর্ম নীতিমালা মেনে আলাদা কাজ করতে হবে।
