/**
 * Piper adapter with automatic base-URL detection.
 * 1) Tries same-origin Netlify proxy /piper-model
 * 2) Falls back to a public CORS proxy in front of Hugging Face
 * 3) Last resort: direct HF (will fail CORS in most browsers, but we try)
 */

const PROXY_PATH = "/piper-model";
const HF_DIRECT =
  "https://huggingface.co/rhasspy/piper-voices/resolve/main";
// Public CORS proxies (best-effort). First working one wins.
const CORS_PROXIES = [
  (url) => `https://corsproxy.io/?${encodeURIComponent(url)}`,
  (url) => `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`,
];

const TEST_REL =
  "de/de_DE/thorsten/medium/de_DE-thorsten-medium.onnx.json";

let api;
let resolvedBase = null;

async function probe(url, timeoutMs = 8000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      method: "GET",
      signal: ctrl.signal,
      cache: "no-store",
    });
    if (!res.ok) return null;
    const ct = (res.headers.get("content-type") || "").toLowerCase();
    // Must be JSON config, not an HTML error page
    if (!ct.includes("json") && !ct.includes("octet") && !ct.includes("text/plain")) {
      // try parse anyway
      const text = await res.clone().text();
      if (text.trimStart().startsWith("<")) return null;
    }
    // For the json test file we expect parseable JSON with audio key
    if (url.includes(".onnx.json")) {
      const j = await res.json();
      if (!j?.audio?.sample_rate) return null;
    }
    return true;
  } catch {
    return null;
  } finally {
    clearTimeout(t);
  }
}

export async function resolveModelBase() {
  if (resolvedBase) return resolvedBase;

  // 1) Same-origin Netlify proxy
  const localOk = await probe(`${PROXY_PATH}/${TEST_REL}`);
  if (localOk) {
    resolvedBase = PROXY_PATH;
    console.info("[piper] using Netlify proxy", resolvedBase);
    return resolvedBase;
  }

  // 2) CORS proxies in front of HF
  for (const make of CORS_PROXIES) {
    const full = make(`${HF_DIRECT}/${TEST_REL}`);
    const ok = await probe(full, 12000);
    if (ok) {
      // Store a function-style base: we need HF_BASE to be a string prefix.
      // corsproxy expects full URL after the proxy prefix, so we set
      // HF_BASE to the proxy wrapper of the HF root.
      // For corsproxy.io: base = "https://corsproxy.io/?" + encodeURIComponent(HF_DIRECT + "/")
      // But PATH_MAP paths get appended as `${HF_BASE}/${path}` — so we need
      // the proxy to accept a base + path.
      //
      // corsproxy.io/?https://huggingface.co/.../path works if HF_BASE is
      // "https://corsproxy.io/?" + encodeURIComponent(HF_DIRECT)  WITHOUT trailing slash
      // and path is appended AFTER decode... Actually corsproxy takes the full URL as query.
      //
      // Our bundle does: `${HF_BASE}/${path}` 
      // So for corsproxy we need HF_BASE such that HF_BASE + "/" + path is valid.
      // Trick: use a proxy that supports path suffix, or patch differently.
      //
      // allorigins: https://api.allorigins.win/raw?url=ENCODED_FULL
      // Same problem.
      //
      // Better approach: set globalThis.__PIPER_HF_BASE__ to a special marker
      // and intercept fetch — too heavy.
      //
      // Practical approach: set HF_BASE to HF_DIRECT and hope browser allows
      // (it won't due to CORS). OR use a proxy that works as path prefix.
      //
      // corsproxy.io supports: https://corsproxy.io/?https://example.com/foo
      // If HF_BASE = "https://corsproxy.io/?" + encodeURIComponent(HF_DIRECT + "/")
      // then `${HF_BASE}${path}` (no extra slash) works if we avoid double slash.
      // Bundle does `${HF_BASE}/${path}` — so HF_BASE should be proxy + encoded(HF_DIRECT)
      // without trailing slash, and encoded path gets a slash in the middle of the
      // encoded URL which is wrong.
      //
      // Correct trick for corsproxy:
      // HF_BASE = "https://corsproxy.io/?" + encodeURIComponent(HF_DIRECT)
      // Request URL becomes: https://corsproxy.io/?https%3A%2F%2Fhuggingface.co%2F...%2Fmain/de/...
      // The slash before "de" is NOT encoded (it's outside the query value) → broken.
      //
      // Fix: we must override fetch for piper model URLs. Simpler: set HF_BASE
      // to empty and use a service worker... too heavy.
      //
      // SIMPLEST WORKING APPROACH for CORS proxy:
      // Don't use string prefix. Instead monkey-patch global fetch when loading
      // models, rewriting /piper-model/ and HF URLs through the working proxy.
      resolvedBase = { type: "cors", make };
      console.info("[piper] using CORS proxy fallback");
      return resolvedBase;
    }
  }

  // 3) Direct HF (likely CORS-blocked, but try)
  resolvedBase = HF_DIRECT;
  console.warn("[piper] falling back to direct HF (may fail CORS)");
  return resolvedBase;
}

function installFetchRewrite(makeProxyUrl) {
  if (globalThis.__PIPER_FETCH_PATCHED__) return;
  globalThis.__PIPER_FETCH_PATCHED__ = true;
  const orig = globalThis.fetch.bind(globalThis);
  globalThis.fetch = (input, init) => {
    let url = typeof input === "string" ? input : input?.url;
    if (typeof url === "string") {
      // Rewrite same-origin proxy paths
      if (url.startsWith(PROXY_PATH + "/") || url.startsWith(location.origin + PROXY_PATH + "/")) {
        const rel = url.replace(location.origin, "").replace(PROXY_PATH + "/", "");
        const target = `${HF_DIRECT}/${rel}`;
        url = makeProxyUrl(target);
        return orig(url, init);
      }
      // Rewrite direct HF model URLs
      if (url.startsWith(HF_DIRECT + "/")) {
        url = makeProxyUrl(url);
        return orig(url, init);
      }
    }
    return orig(input, init);
  };
}

export async function getPiper() {
  if (globalThis.__PIPER_TEST_API__) return globalThis.__PIPER_TEST_API__;

  const base = await resolveModelBase();

  if (typeof base === "string") {
    globalThis.__PIPER_HF_BASE__ = base;
  } else if (base && base.type === "cors") {
    // Keep HF_BASE as /piper-model so PATH_MAP builds /piper-model/...
    // and rewrite those fetches through the CORS proxy.
    globalThis.__PIPER_HF_BASE__ = PROXY_PATH;
    installFetchRewrite(base.make);
  }

  if (!api) {
    api = await import("./vendor/piper-tts-web.bundle.js");
  }
  return api;
}

export const VOICE = "de_DE-thorsten-medium";
