/**
 * Piper adapter – Netlify proxy → CORS proxy → HF
 * + speakerId support for emotional voices (via global, vendor is patched)
 * + Cache-friendly
 */

const PROXY_PATH = "/piper-model";
const HF_DIRECT = "https://huggingface.co/rhasspy/piper-voices/resolve/main";
const CORS_PROXIES = [
  (url) => `https://corsproxy.io/?${encodeURIComponent(url)}`,
  (url) => `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`,
];

const TEST_REL = "de/de_DE/thorsten/medium/de_DE-thorsten-medium.onnx.json";

let api;
let resolvedBase = null;

async function probe(url, timeoutMs = 8000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, { method: "GET", signal: ctrl.signal, cache: "no-store" });
    if (!res.ok) return null;
    const ct = (res.headers.get("content-type") || "").toLowerCase();
    if (!ct.includes("json") && !ct.includes("octet") && !ct.includes("text/plain")) {
      const text = await res.clone().text();
      if (text.trimStart().startsWith("<")) return null;
    }
    if (url.includes(".onnx.json")) {
      const j = await res.json();
      if (!j?.audio?.sample_rate) return null;
    }
    return true;
  } catch {
    return null;
  } finally {
    clearTimeout(t);
  }
}

export async function resolveModelBase() {
  if (resolvedBase) return resolvedBase;

  const localOk = await probe(`${PROXY_PATH}/${TEST_REL}`);
  if (localOk) {
    resolvedBase = PROXY_PATH;
    console.info("[piper] using Netlify proxy", resolvedBase);
    return resolvedBase;
  }

  for (const make of CORS_PROXIES) {
    const full = make(`${HF_DIRECT}/${TEST_REL}`);
    const ok = await probe(full, 12000);
    if (ok) {
      resolvedBase = { type: "cors", make };
      console.info("[piper] using CORS proxy fallback");
      return resolvedBase;
    }
  }

  resolvedBase = HF_DIRECT;
  console.warn("[piper] falling back to direct HF (may fail CORS)");
  return resolvedBase;
}

function installFetchRewrite(makeProxyUrl) {
  if (globalThis.__PIPER_FETCH_PATCHED__) return;
  globalThis.__PIPER_FETCH_PATCHED__ = true;
  const orig = globalThis.fetch.bind(globalThis);
  globalThis.fetch = (input, init) => {
    let url = typeof input === "string" ? input : input?.url;
    if (typeof url === "string") {
      if (url.startsWith(PROXY_PATH + "/") || url.startsWith(location.origin + PROXY_PATH + "/")) {
        const rel = url.replace(location.origin, "").replace(PROXY_PATH + "/", "");
        const target = `${HF_DIRECT}/${rel}`;
        url = makeProxyUrl(target);
        return orig(url, init);
      }
      if (url.startsWith(HF_DIRECT + "/")) {
        url = makeProxyUrl(url);
        return orig(url, init);
      }
    }
    return orig(input, init);
  };
}

export async function getPiper() {
  if (globalThis.__PIPER_TEST_API__) return globalThis.__PIPER_TEST_API__;

  const base = await resolveModelBase();

  if (typeof base === "string") {
    globalThis.__PIPER_HF_BASE__ = base;
  } else if (base && base.type === "cors") {
    globalThis.__PIPER_HF_BASE__ = PROXY_PATH;
    installFetchRewrite(base.make);
  }

  if (!api) {
    api = await import("./vendor/piper-tts-web.bundle.js");
  }

  // Return a thin wrapper that sets speakerId via global (vendor is already patched)
  // without mutating the frozen ES module.
  return {
    predict: async (config, callback) => {
      globalThis.__PIPER_SPEAKER_ID__ =
        typeof config.speakerId === "number" ? config.speakerId : 0;
      return api.predict(
        { text: config.text, voiceId: config.voiceId },
        callback
      );
    },
    // pass through anything else if needed
    download: api.download?.bind(api),
    remove: api.remove?.bind(api),
  };
}

export const VOICE = "de_DE-thorsten-medium";
