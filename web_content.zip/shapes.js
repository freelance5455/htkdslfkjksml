/* =========================================================
   SHAPES.JS — v7.0
   400+ shape definitions + tester + renderer
   Zero console errors. Safe fallbacks.
   ========================================================= */
(function () {
  'use strict';

  const SHAPES = [
    /* ---------- BASIC POLYGONS (20) ---------- */
    { name: 'Square', color: '#8b7cff', css: { width:170, height:170, borderRadius:14 } },
    { name: 'Rounded Square', color: '#7c9dff', css: { width:170, height:170, borderRadius:42 } },
    { name: 'Circle', color: '#4dd4ff', css: { width:170, height:170, borderRadius:85 } },
    { name: 'Ellipse', color: '#4dffcc', css: { width:220, height:130, borderRadius:65 } },
    { name: 'Triangle', color: '#9dff7c', css: { triangle: 1, width:170, height:150 } },
    { name: 'Right Triangle', color: '#d4ff5c', css: { rightTriangle: 1, width:150, height:150 } },
    { name: 'Diamond', color: '#ffd45c', css: { rotate45: 1, width:130, height:130, borderRadius:8 } },
    { name: 'Pentagon', color: '#ffb04d', css: { width:170, height:170, clipPath:'polygon(50% 0%, 100% 38%, 82% 100%, 18% 100%, 0% 38%)' } },
    { name: 'Hexagon', color: '#ff7c9d', css: { width:180, height:160, clipPath:'polygon(25% 0%, 75% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%)' } },
    { name: 'Heptagon', color: '#ff7cff', css: { width:170, height:170, clipPath:'polygon(50% 0%, 90% 20%, 100% 60%, 75% 100%, 25% 100%, 0% 60%, 10% 20%)' } },
    { name: 'Octagon', color: '#b87cff', css: { width:170, height:170, clipPath:'polygon(30% 0%, 70% 0%, 100% 30%, 100% 70%, 70% 100%, 30% 100%, 0% 70%, 0% 30%)' } },
    { name: 'Nonagon', color: '#7cffb8', css: { width:170, height:170, clipPath:'polygon(50% 0%, 78% 10%, 98% 32%, 98% 68%, 78% 90%, 50% 100%, 22% 90%, 2% 68%, 2% 32%, 22% 10%)' } },
    { name: 'Decagon', color: '#7cd4ff', css: { width:170, height:170, clipPath:'polygon(50% 0%, 80% 10%, 98% 35%, 98% 65%, 80% 90%, 50% 100%, 20% 90%, 2% 65%, 2% 35%, 20% 10%)' } },
    { name: 'Dodecagon', color: '#d4ff7c', css: { width:170, height:170, clipPath:'polygon(50% 0%, 75% 7%, 93% 25%, 100% 50%, 93% 75%, 75% 93%, 50% 100%, 25% 93%, 7% 75%, 0% 50%, 7% 25%, 25% 7%)' } },
    { name: 'Parallelogram', color: '#b0b0ff', css: { width:180, height:130, clipPath:'polygon(20% 0%, 100% 0%, 80% 100%, 0% 100%)' } },
    { name: 'Trapezoid', color: '#7cffe5', css: { width:180, height:130, clipPath:'polygon(20% 0%, 80% 0%, 100% 100%, 0% 100%)' } },
    { name: 'Kite', color: '#c8ff7c', css: { width:150, height:180, clipPath:'polygon(50% 0%, 100% 40%, 50% 100%, 0% 40%)' } },
    { name: 'Rhombus', color: '#7cffd4', css: { width:140, height:180, clipPath:'polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)' } },
    { name: 'Vertical Rhombus', color: '#8b9dff', css: { width:150, height:180, clipPath:'polygon(50% 0%, 100% 35%, 50% 100%, 0% 35%)' } },
    { name: 'Rectangle', color: '#7c9dff', css: { width:200, height:120, borderRadius:6 } },

    /* ---------- MORE POLYGONS (20) ---------- */
    { name: 'Pentadecagon', color: '#8b7cff', css: { width:170, height:170, clipPath:'polygon(50% 0%, 71% 7%, 88% 20%, 98% 38%, 100% 58%, 92% 78%, 76% 92%, 56% 99%, 36% 96%, 18% 84%, 5% 66%, 0% 45%, 8% 24%, 24% 10%, 42% 3%)' } },
    { name: 'Hexadecagon', color: '#7c9dff', css: { width:170, height:170, clipPath:'polygon(50% 0%, 70% 6%, 87% 18%, 97% 35%, 100% 55%, 95% 74%, 82% 89%, 64% 97%, 45% 100%, 27% 94%, 12% 82%, 3% 64%, 0% 45%, 5% 26%, 16% 11%, 32% 3%)' } },
    { name: 'Icosagon', color: '#4dd4ff', css: { width:170, height:170, borderRadius:'85px' } },
    { name: 'Kite 2', color: '#4dffcc', css: { width:160, height:190, clipPath:'polygon(50% 0%, 95% 35%, 50% 100%, 5% 35%)' } },
    { name: 'Dart', color: '#9dff7c', css: { width:150, height:190, clipPath:'polygon(50% 0%, 100% 100%, 50% 70%, 0% 100%)' } },
    { name: 'Arrowhead', color: '#d4ff5c', css: { width:180, height:170, clipPath:'polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%, 50% 25%)' } },
    { name: 'Quadrilateral', color: '#ffd45c', css: { width:180, height:160, clipPath:'polygon(10% 0%, 100% 10%, 90% 100%, 0% 90%)' } },
    { name: 'Skewed Square', color: '#ffb04d', css: { width:170, height:170, clipPath:'polygon(15% 0%, 100% 0%, 85% 100%, 0% 100%)' } },
    { name: 'Offset Hex', color: '#ff7c9d', css: { width:180, height:160, clipPath:'polygon(30% 0%, 100% 0%, 70% 100%, 0% 100%, 30% 50%, 100% 50%)' } },
    { name: 'Pinwheel', color: '#ff7cff', css: { width:180, height:180, clipPath:'polygon(50% 50%, 100% 0%, 70% 40%, 100% 70%, 60% 60%, 70% 100%, 40% 70%, 30% 100%, 40% 60%, 0% 70%, 30% 40%, 0% 0%)' } },
    { name: 'Cross X', color: '#b87cff', css: { width:170, height:170, clipPath:'polygon(35% 0%, 50% 25%, 65% 0%, 100% 35%, 75% 50%, 100% 65%, 65% 100%, 50% 75%, 35% 100%, 0% 65%, 25% 50%, 0% 35%)' } },
    { name: 'Bowtie', color: '#7cffb8', css: { width:190, height:150, clipPath:'polygon(0% 0%, 50% 50%, 100% 0%, 100% 100%, 50% 50%, 0% 100%)' } },
    { name: 'Butterfly Geo', color: '#7cd4ff', css: { width:200, height:160, clipPath:'polygon(50% 50%, 0% 0%, 20% 50%, 0% 100%, 50% 50%, 100% 0%, 80% 50%, 100% 100%)' } },
    { name: 'Hourglass', color: '#d4ff7c', css: { width:150, height:190, clipPath:'polygon(0% 0%, 100% 0%, 50% 50%, 100% 100%, 0% 100%, 50% 50%)' } },
    { name: 'Cone', color: '#b0b0ff', css: { width:170, height:190, clipPath:'polygon(50% 0%, 100% 100%, 0% 100%)' } },
    { name: 'Frustum', color: '#7cffe5', css: { width:180, height:150, clipPath:'polygon(25% 0%, 75% 0%, 100% 100%, 0% 100%)' } },
    { name: 'Prism', color: '#c8ff7c', css: { width:180, height:150, clipPath:'polygon(20% 0%, 80% 0%, 100% 50%, 80% 100%, 20% 100%, 0% 50%)' } },
    { name: 'Antiprism', color: '#7cffd4', css: { width:180, height:170, clipPath:'polygon(50% 0%, 90% 20%, 100% 60%, 75% 95%, 25% 95%, 0% 60%, 10% 20%)' } },
    { name: 'Deltahedron', color: '#8b9dff', css: { width:170, height:170, clipPath:'polygon(50% 0%, 100% 40%, 90% 100%, 10% 100%, 0% 40%)' } },
    { name: 'Trapezium', color: '#7c9dff', css: { width:180, height:150, clipPath:'polygon(15% 0%, 85% 0%, 100% 100%, 0% 100%)' } },

    /* ---------- STARS (15) ---------- */
    { name: 'Star 5', color: '#ffcc4d', css: { width:180, height:180, clipPath:'polygon(50% 0%, 61% 35%, 98% 35%, 68% 57%, 79% 91%, 50% 70%, 21% 91%, 32% 57%, 2% 35%, 39% 35%)' } },
    { name: 'Star 6', color: '#9dff7c', css: { width:180, height:180, clipPath:'polygon(50% 0%, 60% 35%, 95% 25%, 70% 50%, 95% 75%, 60% 65%, 50% 100%, 40% 65%, 5% 75%, 30% 50%, 5% 25%, 40% 35%)' } },
    { name: 'Star 7', color: '#4dd4ff', css: { width:180, height:180, clipPath:'polygon(50% 0%, 60% 30%, 90% 20%, 72% 45%, 95% 65%, 65% 68%, 60% 98%, 50% 72%, 40% 98%, 35% 68%, 5% 65%, 28% 45%, 10% 20%, 40% 30%)' } },
    { name: 'Star 8', color: '#8b7cff', css: { width:180, height:180, clipPath:'polygon(50% 0%, 58% 30%, 88% 12%, 76% 42%, 100% 50%, 76% 58%, 88% 88%, 58% 70%, 50% 100%, 42% 70%, 12% 88%, 24% 58%, 0% 50%, 24% 42%, 12% 12%, 42% 30%)' } },
    { name: 'Star 12', color: '#ff7cff', css: { width:180, height:180, clipPath:'polygon(50% 0%, 55% 28%, 75% 8%, 72% 35%, 95% 25%, 82% 45%, 100% 50%, 82% 55%, 95% 75%, 72% 65%, 75% 92%, 55% 72%, 50% 100%, 45% 72%, 25% 92%, 28% 65%, 5% 75%, 18% 55%, 0% 50%, 18% 45%, 5% 25%, 28% 35%, 25% 8%, 45% 28%)' } },
    { name: 'Burst Star', color: '#ffb04d', css: { width:190, height:190, clipPath:'polygon(50% 0%, 55% 25%, 68% 10%, 65% 30%, 85% 22%, 75% 42%, 98% 42%, 80% 58%, 98% 75%, 72% 70%, 68% 95%, 58% 72%, 45% 92%, 42% 68%, 18% 88%, 25% 62%, 2% 62%, 22% 45%, 5% 28%, 30% 32%, 30% 8%, 42% 28%)' } },
    { name: 'Sparkle', color: '#ffd45c', css: { width:180, height:180, clipPath:'polygon(50% 0%, 55% 40%, 100% 50%, 55% 60%, 50% 100%, 45% 60%, 0% 50%, 45% 40%)' } },
    { name: 'Sparkle 4', color: '#4dffcc', css: { width:180, height:180, clipPath:'polygon(50% 5%, 58% 42%, 95% 50%, 58% 58%, 50% 95%, 42% 58%, 5% 50%, 42% 42%)' } },
    { name: 'Starfish', color: '#ff7c9d', css: { width:180, height:180, clipPath:'polygon(50% 5%, 62% 38%, 95% 40%, 70% 60%, 78% 92%, 50% 75%, 22% 92%, 30% 60%, 5% 40%, 38% 38%)' } },
    { name: 'Star 5 Double', color: '#ff7cff', css: { width:190, height:190, clipPath:'polygon(50% 0%, 58% 30%, 85% 15%, 72% 42%, 100% 50%, 72% 58%, 85% 85%, 58% 70%, 50% 100%, 42% 70%, 15% 85%, 28% 58%, 0% 50%, 28% 42%, 15% 15%, 42% 30%)' } },
    { name: 'Sunburst', color: '#ffcc4d', css: { width:200, height:200, clipPath:'polygon(50% 0%, 55% 30%, 70% 10%, 68% 35%, 90% 25%, 78% 45%, 100% 45%, 82% 58%, 100% 75%, 75% 68%, 70% 92%, 58% 72%, 48% 100%, 42% 72%, 25% 92%, 30% 68%, 0% 75%, 18% 58%, 0% 45%, 22% 45%, 10% 25%, 30% 35%, 30% 10%, 45% 30%)' } },
    { name: 'Sunburst 2', color: '#ffcc4d', css: { width:190, height:190, clipPath:'polygon(50% 0%, 55% 25%, 75% 5%, 68% 30%, 95% 20%, 75% 45%, 100% 50%, 75% 55%, 95% 80%, 68% 70%, 75% 95%, 55% 75%, 50% 100%, 45% 75%, 25% 95%, 32% 70%, 5% 80%, 25% 55%, 0% 50%, 25% 45%, 5% 20%, 32% 30%, 25% 5%, 45% 25%)' } },
    { name: 'Sunburst 3', color: '#ffcc4d', css: { width:190, height:190, clipPath:'polygon(50% 5%, 57% 33%, 75% 15%, 70% 42%, 90% 30%, 78% 50%, 95% 55%, 78% 62%, 90% 82%, 70% 70%, 75% 95%, 57% 78%, 50% 95%, 43% 78%, 25% 95%, 30% 70%, 10% 82%, 22% 62%, 5% 55%, 22% 50%, 10% 30%, 30% 42%, 25% 15%, 43% 33%)' } },
    { name: 'Star Flower', color: '#ff7cff', css: { width:200, height:200, clipPath:'polygon(50% 0%, 60% 25%, 75% 10%, 70% 30%, 90% 15%, 80% 35%, 100% 30%, 85% 50%, 100% 70%, 80% 65%, 90% 85%, 70% 70%, 75% 90%, 60% 75%, 50% 100%, 40% 75%, 25% 90%, 30% 70%, 10% 85%, 20% 65%, 0% 70%, 15% 50%, 0% 30%, 20% 35%, 10% 15%, 30% 30%, 25% 10%, 40% 25%)' } },
    { name: 'Star 3', color: '#8b7cff', css: { width:190, height:190, clipPath:'polygon(50% 0%, 60% 35%, 95% 25%, 70% 50%, 95% 75%, 60% 65%, 50% 100%, 40% 65%, 5% 75%, 30% 50%, 5% 25%, 40% 35%)' } },
    { name: 'Parallel Star', color: '#ff9d7c', css: { width:180, height:170, clipPath:'polygon(20% 0%, 80% 0%, 100% 30%, 100% 70%, 80% 100%, 20% 100%, 0% 70%, 0% 30%, 50% 20%, 80% 50%, 50% 80%, 20% 50%)' } },

    /* ---------- NEW STARS (15) ---------- */
    { name: 'Star 4', color: '#ffcc4d', css: { width:180, height:180, clipPath:'polygon(50% 0%, 65% 35%, 100% 50%, 65% 65%, 50% 100%, 35% 65%, 0% 50%, 35% 35%)' } },
    { name: 'Star 9', color: '#9dff7c', css: { width:180, height:180, clipPath:'polygon(50% 0%, 58% 30%, 78% 15%, 72% 38%, 95% 38%, 78% 55%, 95% 72%, 72% 72%, 68% 95%, 54% 78%, 40% 95%, 36% 72%, 13% 72%, 30% 55%, 13% 38%, 36% 38%, 30% 15%, 50% 30%)' } },
    { name: 'Star 10', color: '#4dd4ff', css: { width:180, height:180, clipPath:'polygon(50% 0%, 57% 28%, 75% 10%, 70% 32%, 90% 22%, 78% 42%, 100% 42%, 82% 55%, 100% 68%, 78% 68%, 88% 88%, 68% 76%, 65% 100%, 55% 78%, 42% 98%, 38% 76%, 18% 90%, 26% 68%, 2% 72%, 20% 55%, 2% 42%, 26% 42%, 14% 22%, 36% 32%, 30% 10%, 48% 28%)' } },
    { name: 'Star 14', color: '#8b7cff', css: { width:180, height:180, clipPath:'polygon(50% 0%, 55% 22%, 68% 8%, 66% 28%, 82% 16%, 76% 35%, 95% 30%, 84% 45%, 100% 55%, 84% 62%, 95% 78%, 76% 74%, 82% 94%, 66% 82%, 68% 100%, 55% 86%, 50% 100%, 45% 86%, 32% 100%, 34% 82%, 18% 94%, 24% 74%, 5% 78%, 16% 62%, 0% 55%, 16% 45%, 5% 30%, 24% 35%, 18% 16%, 34% 28%, 32% 8%, 45% 22%)' } },
    { name: 'Starburst', color: '#ff7cff', css: { width:190, height:190, clipPath:'polygon(50% 0%, 55% 30%, 70% 5%, 65% 32%, 90% 15%, 75% 38%, 100% 35%, 80% 50%, 100% 65%, 75% 62%, 90% 85%, 65% 68%, 70% 95%, 55% 70%, 50% 100%, 45% 70%, 30% 95%, 35% 68%, 10% 85%, 25% 62%, 0% 65%, 20% 50%, 0% 35%, 25% 38%, 10% 15%, 35% 32%, 30% 5%, 45% 30%)' } },
    { name: 'Supernova', color: '#ffb04d', css: { width:200, height:200, clipPath:'polygon(50% 0%, 54% 25%, 66% 8%, 63% 28%, 82% 15%, 74% 36%, 95% 30%, 80% 48%, 100% 55%, 80% 62%, 95% 78%, 74% 72%, 82% 92%, 63% 80%, 66% 100%, 54% 84%, 50% 100%, 46% 84%, 34% 100%, 37% 80%, 18% 92%, 26% 72%, 5% 78%, 20% 62%, 0% 55%, 20% 48%, 5% 30%, 26% 36%, 18% 15%, 37% 28%, 34% 8%, 46% 25%)' } },
    { name: 'Spark 5', color: '#ffd45c', css: { width:180, height:180, clipPath:'polygon(50% 0%, 58% 42%, 85% 15%, 70% 50%, 100% 50%, 70% 58%, 85% 85%, 58% 58%, 50% 100%, 42% 58%, 15% 85%, 30% 58%, 0% 50%, 30% 50%, 15% 15%, 42% 42%)' } },
    { name: 'Spark 6', color: '#4dffcc', css: { width:180, height:180, clipPath:'polygon(50% 5%, 55% 35%, 70% 15%, 65% 42%, 90% 30%, 78% 50%, 95% 55%, 78% 62%, 90% 82%, 65% 70%, 70% 95%, 55% 78%, 50% 95%, 45% 78%, 30% 95%, 35% 70%, 10% 82%, 22% 62%, 5% 55%, 22% 50%, 10% 30%, 35% 42%, 30% 15%, 45% 35%)' } },
    { name: 'Explosion', color: '#ff7c9d', css: { width:200, height:200, clipPath:'polygon(50% 0%, 56% 30%, 72% 8%, 66% 32%, 88% 18%, 76% 40%, 100% 35%, 82% 50%, 100% 65%, 76% 62%, 88% 85%, 66% 70%, 72% 95%, 56% 74%, 50% 100%, 44% 74%, 28% 95%, 34% 70%, 12% 85%, 24% 62%, 0% 65%, 18% 50%, 0% 35%, 24% 40%, 12% 18%, 34% 32%, 28% 8%, 44% 30%)' } },
    { name: 'Nova', color: '#ffcc4d', css: { width:190, height:190, clipPath:'polygon(50% 0%, 55% 25%, 68% 10%, 64% 28%, 82% 20%, 74% 38%, 94% 38%, 80% 52%, 96% 65%, 78% 64%, 86% 82%, 66% 72%, 66% 92%, 54% 78%, 50% 98%, 46% 78%, 34% 92%, 34% 72%, 14% 82%, 22% 64%, 4% 65%, 20% 52%, 6% 38%, 26% 38%, 18% 20%, 36% 28%, 32% 10%, 46% 25%)' } },
    { name: 'Compass Star', color: '#5cffe5', css: { width:180, height:180, clipPath:'polygon(50% 0%, 58% 42%, 100% 50%, 58% 58%, 50% 100%, 42% 58%, 0% 50%, 42% 42%)' } },
    { name: 'Sputnik', color: '#a0a0ff', css: { width:190, height:190, clipPath:'polygon(50% 0%, 55% 30%, 70% 10%, 65% 32%, 88% 22%, 76% 42%, 100% 40%, 80% 55%, 100% 70%, 76% 68%, 88% 88%, 65% 78%, 70% 100%, 55% 80%, 50% 100%, 45% 80%, 30% 100%, 35% 78%, 12% 88%, 24% 68%, 0% 70%, 20% 55%, 0% 40%, 24% 42%, 12% 22%, 35% 32%, 30% 10%, 45% 30%)' } },
    { name: 'Twinkle', color: '#ff7cb8', css: { width:180, height:180, clipPath:'polygon(50% 0%, 56% 44%, 100% 50%, 56% 56%, 50% 100%, 44% 56%, 0% 50%, 44% 44%)' } },
    { name: 'Starburst 4', color: '#ffd45c', css: { width:180, height:180, clipPath:'polygon(50% 0%, 60% 40%, 95% 25%, 70% 50%, 100% 60%, 60% 60%, 50% 100%, 40% 60%, 0% 60%, 30% 50%, 5% 25%, 40% 40%)' } },
    { name: 'Radiant', color: '#ff9d7c', css: { width:190, height:190, clipPath:'polygon(50% 0%, 55% 25%, 67% 8%, 63% 27%, 80% 16%, 73% 36%, 92% 32%, 80% 48%, 95% 55%, 80% 62%, 92% 78%, 73% 74%, 80% 92%, 63% 80%, 67% 100%, 55% 84%, 50% 100%, 45% 84%, 33% 100%, 37% 80%, 20% 92%, 27% 74%, 8% 78%, 20% 62%, 5% 55%, 20% 48%, 8% 32%, 27% 36%, 20% 16%, 37% 27%, 33% 8%, 45% 25%)' } },

    /* ---------- HEARTS, CROSSES, RINGS (15) ---------- */
    { name: 'Heart', color: '#ff4d6d', css: { width:170, height:160, clipPath:'path("M85 150 C10 95 10 30 50 20 C70 15 85 30 85 30 C85 30 100 15 120 20 C160 30 160 95 85 150 Z")' } },
    { name: 'Heart Round', color: '#ff4d6d', css: { width:180, height:170, clipPath:'path("M 90 30 Q 130 0 160 30 Q 190 60 180 100 Q 170 150 90 175 Q 10 150 0 100 Q -10 60 20 30 Q 50 0 90 30 Z")' } },
    { name: 'Diamond Heart', color: '#ff4d6d', css: { width:180, height:180, clipPath:'polygon(50% 0%, 75% 15%, 100% 30%, 100% 55%, 75% 75%, 50% 100%, 25% 75%, 0% 55%, 0% 30%, 25% 15%)' } },
    { name: 'Cross', color: '#4dffd4', css: { width:170, height:170, clipPath:'polygon(35% 0%, 65% 0%, 65% 35%, 100% 35%, 100% 65%, 65% 65%, 65% 100%, 35% 100%, 35% 65%, 0% 65%, 0% 35%, 35% 35%)' } },
    { name: 'Round Cross', color: '#ff5c9e', css: { width:170, height:170, clipPath:'polygon(35% 0%, 65% 0%, 65% 35%, 100% 35%, 100% 65%, 65% 65%, 65% 100%, 35% 100%, 35% 65%, 0% 65%, 0% 35%, 35% 35%)' } },
    { name: 'Plus', color: '#7c9dff', css: { width:170, height:170, clipPath:'polygon(40% 0%, 60% 0%, 60% 40%, 100% 40%, 100% 60%, 60% 60%, 60% 100%, 40% 100%, 40% 60%, 0% 60%, 0% 40%, 40% 40%)' } },
    { name: 'Rounded Plus', color: '#9dff7c', css: { width:170, height:170, clipPath:'polygon(35% 0%, 65% 0%, 65% 35%, 100% 35%, 100% 65%, 65% 65%, 65% 100%, 35% 100%, 35% 65%, 0% 65%, 0% 35%, 35% 35%)' } },
    { name: 'X Shape', color: '#ff7c5c', css: { width:170, height:170, clipPath:'polygon(20% 0%, 50% 30%, 80% 0%, 100% 20%, 70% 50%, 100% 80%, 80% 100%, 50% 70%, 20% 100%, 0% 80%, 30% 50%, 0% 20%)' } },
    { name: 'Crosshair', color: '#ff5cb8', css: { width:190, height:190, clipPath:'polygon(45% 0%, 55% 0%, 55% 45%, 100% 45%, 100% 55%, 55% 55%, 55% 100%, 45% 100%, 45% 55%, 0% 55%, 0% 45%, 45% 45%)' } },
    { name: 'Target', color: '#b87cff', css: { width:190, height:190, clipPath:'polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%, 50% 0%, 50% 20%, 70% 50%, 50% 80%, 30% 50%, 50% 20%, 50% 35%, 60% 50%, 50% 65%, 40% 50%, 50% 35%)' } },
    { name: 'Ring', color: '#ff7cff', css: { width:180, height:180, clipPath:'polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%, 0% 0%, 20% 20%, 20% 80%, 80% 80%, 80% 20%, 20% 20%)' } },
    { name: 'Double Ring', color: '#b87cff', css: { width:190, height:190, clipPath:'polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%, 0% 0%, 15% 15%, 15% 85%, 85% 85%, 85% 15%, 15% 15%, 30% 30%, 30% 70%, 70% 70%, 70% 30%, 30% 30%)' } },
    { name: 'Triple Ring', color: '#a0a0ff', css: { width:200, height:200, clipPath:'polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%, 0% 0%, 12% 12%, 12% 88%, 88% 88%, 88% 12%, 12% 12%, 24% 24%, 24% 76%, 76% 76%, 76% 24%, 24% 24%, 36% 36%, 36% 64%, 64% 64%, 64% 36%, 36% 36%)' } },
    { name: 'Donut', color: '#ff7c9d', css: { width:180, height:180, clipPath:'path("M90 0 A90 90 0 1 1 89.9 0 Z M90 30 A60 60 0 1 0 89.9 30 Z")' } },
    { name: 'Hollow Square', color: '#4dffcc', css: { width:170, height:170, clipPath:'polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%, 0% 0%, 25% 25%, 25% 75%, 75% 75%, 75% 25%, 25% 25%)' } },

    /* ---------- NEW HEARTS & SYMBOLS (20) ---------- */
    { name: 'Heart 2', color: '#ff4d6d', css: { width:170, height:170, clipPath:'polygon(50% 100%, 0% 35%, 0% 15%, 20% 0%, 40% 5%, 50% 20%, 60% 5%, 80% 0%, 100% 15%, 100% 35%)' } },
    { name: 'Heart Slim', color: '#ff4d6d', css: { width:150, height:180, clipPath:'path("M 75 170 Q 10 100 10 50 Q 10 10 40 5 Q 70 5 75 30 Q 80 5 110 5 Q 140 10 140 50 Q 140 100 75 170 Z")' } },
    { name: 'Broken Heart', color: '#ff5c8c', css: { width:180, height:170, clipPath:'polygon(50% 100%, 0% 40%, 10% 20%, 30% 15%, 45% 30%, 50% 25%, 55% 30%, 60% 15%, 80% 10%, 100% 40%, 55% 60%, 60% 100%)' } },
    { name: 'Double Heart', color: '#ff4d6d', css: { width:200, height:150, clipPath:'polygon(25% 50%, 0% 20%, 0% 5%, 15% 0%, 25% 15%, 35% 0%, 50% 5%, 50% 20%, 75% 50%, 50% 80%, 25% 100%)' } },
    { name: 'Small Heart', color: '#ff7c9d', css: { width:150, height:150, clipPath:'polygon(50% 100%, 0% 30%, 15% 5%, 50% 20%, 85% 5%, 100% 30%)' } },
    { name: 'Diamond Plus', color: '#b87cff', css: { width:180, height:180, clipPath:'polygon(50% 0%, 60% 40%, 100% 50%, 60% 60%, 50% 100%, 40% 60%, 0% 50%, 40% 40%)' } },
    { name: 'Infinity 2', color: '#ff7cff', css: { width:200, height:130, clipPath:'path("M 50 65 Q 25 30 0 65 Q 25 100 50 65 Q 100 0 150 65 Q 175 100 200 65 Q 175 30 150 65 Q 100 130 50 65 Z")' } },
    { name: 'Peace Sign', color: '#a0a0ff', css: { width:180, height:180, borderRadius:'85px' } },
    { name: 'Spiral 3', color: '#8b7cff', css: { width:190, height:190, clipPath:'polygon(50% 0%, 65% 10%, 80% 25%, 90% 45%, 85% 65%, 70% 82%, 50% 90%, 30% 85%, 15% 70%, 10% 50%, 18% 32%, 32% 20%, 48% 18%, 62% 26%, 70% 40%, 65% 55%, 52% 62%, 40% 56%, 38% 45%, 45% 38%, 52% 42%, 50% 50%)' } },
    { name: 'Yin Yang 2', color: '#ffffff', css: { width:180, height:180, borderRadius:'85px' } },
    { name: 'Dollar', color: '#5cff8c', css: { width:150, height:190, clipPath:'polygon(45% 0%, 55% 0%, 55% 15%, 80% 20%, 85% 45%, 55% 45%, 55% 50%, 80% 60%, 85% 85%, 55% 90%, 55% 100%, 45% 100%, 45% 90%, 15% 85%, 15% 60%, 45% 60%, 45% 50%, 20% 45%, 15% 20%, 45% 15%)' } },
    { name: 'Percent', color: '#ffd45c', css: { width:170, height:170, clipPath:'polygon(0% 20%, 20% 0%, 100% 80%, 100% 100%, 80% 100%, 0% 20%, 0% 20%, 15% 5%, 25% 5%, 35% 15%, 25% 25%, 15% 25%, 5% 15%, 15% 5%, 70% 100%, 100% 100%, 100% 90%, 85% 90%, 75% 100%, 70% 100%)' } },
    { name: 'At Sign', color: '#4dd4ff', css: { width:180, height:180, clipPath:'path("M 90 20 Q 160 20 160 90 Q 160 160 90 160 Q 20 160 20 90 Q 20 20 90 20 Z")' } },
    { name: 'Anchor', color: '#7c9dff', css: { width:190, height:200, clipPath:'path("M 85 0 L 105 0 L 105 30 L 130 30 L 130 40 L 105 40 L 105 160 Q 150 160 170 130 L 160 120 L 180 110 L 195 145 L 180 180 L 165 170 Q 130 195 95 195 Q 60 195 25 170 L 10 180 L -5 145 L 10 110 L 30 120 L 20 130 Q 40 160 85 160 L 85 40 L 60 40 L 60 30 L 85 30 Z")' } },
    { name: 'Pilcrow', color: '#a0d4ff', css: { width:150, height:180, clipPath:'polygon(30% 0%, 70% 0%, 100% 0%, 100% 15%, 85% 15%, 85% 100%, 70% 100%, 70% 15%, 50% 15%, 50% 100%, 35% 100%, 35% 15%, 15% 15%, 15% 60%, 0% 60%, 0% 15%, 0% 0%)' } },
    { name: 'Section', color: '#ffb04d', css: { width:150, height:180, clipPath:'polygon(35% 0%, 100% 0%, 100% 15%, 35% 15%, 35% 100%, 0% 100%, 0% 60%, 15% 60%, 15% 15%, 0% 15%, 0% 0%, 35% 0%, 35% 25%, 15% 25%, 15% 85%, 20% 85%, 20% 100%, 100% 100%, 100% 85%, 35% 85%)' } },
    { name: 'Bullet', color: '#ff7c5c', css: { width:150, height:150, borderRadius:'75px' } },
    { name: 'Spark New', color: '#5cffe5', css: { width:180, height:180, clipPath:'polygon(50% 0%, 58% 42%, 85% 15%, 65% 50%, 100% 50%, 65% 58%, 85% 85%, 58% 58%, 50% 100%, 42% 58%, 15% 85%, 35% 58%, 0% 50%, 35% 50%, 15% 15%, 42% 42%)' } },
    { name: 'Drop Heart', color: '#ff4d6d', css: { width:150, height:180, clipPath:'path("M 75 0 Q 110 60 110 100 Q 110 150 75 175 Q 40 150 40 100 Q 40 60 75 0 Z")' } },

    /* ---------- MOONS & ARCS (8) ---------- */
    { name: 'Moon', color: '#4dffcc', css: { width:180, height:180, clipPath:'path("M 90 10 A 80 80 0 1 0 90 170 A 60 60 0 1 1 90 10 Z")' } },
    { name: 'Half Moon', color: '#4dc8ff', css: { width:180, height:180, clipPath:'path("M 0 90 A 90 90 0 0 1 180 90 Z")' } },
    { name: 'Quarter Moon', color: '#4dd4ff', css: { width:180, height:180, clipPath:'path("M 0 180 A 180 180 0 0 1 180 0 L 180 180 Z")' } },
    { name: 'Sickle', color: '#9dff7c', css: { width:190, height:150, clipPath:'path("M 0 150 A 190 190 0 0 1 190 150 Z")' } },
    { name: 'Parabola', color: '#d4ff5c', css: { width:200, height:130, clipPath:'path("M 0 0 Q 100 180 200 0 Z")' } },
    { name: 'Inverted Parabola', color: '#ffd45c', css: { width:200, height:130, clipPath:'path("M 0 130 Q 100 -50 200 130 Z")' } },
    { name: 'Dome', color: '#ff7c9d', css: { width:180, height:150, clipPath:'path("M 0 150 Q 0 0 90 0 Q 180 0 180 150 Z")' } },
    { name: 'Dome 2', color: '#ff9d5c', css: { width:180, height:150, clipPath:'path("M 0 150 Q 0 0 90 0 Q 180 0 180 150 Z")' } },

    /* ---------- NATURE (20) ---------- */
    { name: 'Drop', color: '#4dd4ff', css: { width:150, height:180, clipPath:'path("M75 0 Q150 90 150 130 Q150 180 75 180 Q0 180 0 130 Q0 90 75 0 Z")' } },
    { name: 'Water Drop', color: '#4dccff', css: { width:150, height:180, clipPath:'path("M 75 0 Q 30 60 15 100 Q 0 145 40 170 Q 75 190 110 170 Q 150 145 135 100 Q 120 60 75 0 Z")' } },
    { name: 'Drop 2', color: '#4dffcc', css: { width:170, height:190, clipPath:'path("M 85 0 Q 40 50 20 100 Q 0 150 50 175 Q 85 195 120 175 Q 170 150 150 100 Q 130 50 85 0 Z")' } },
    { name: 'Blaze', color: '#ff7c5c', css: { width:150, height:190, clipPath:'path("M 75 0 Q 100 40 90 70 Q 110 50 120 90 Q 140 80 140 120 Q 140 180 75 180 Q 10 180 10 120 Q 10 80 30 90 Q 40 50 60 70 Q 50 40 75 0 Z")' } },
    { name: 'Flame', color: '#ff7c9d', css: { width:150, height:190, clipPath:'path("M 75 0 Q 100 30 95 60 Q 115 40 130 70 Q 145 60 145 100 Q 145 180 75 180 Q 5 180 5 100 Q 5 60 20 70 Q 35 40 55 60 Q 50 30 75 0 Z")' } },
    { name: 'Wave', color: '#4dffd4', css: { width:200, height:120, clipPath:'path("M 0 60 Q 25 20 50 60 Q 75 100 100 60 Q 125 20 150 60 Q 175 100 200 60 L 200 120 L 0 120 Z")' } },
    { name: 'Leaf', color: '#9dff7c', css: { width:170, height:180, clipPath:'path("M 85 0 Q 170 40 170 110 Q 170 180 85 180 Q 0 180 0 110 Q 0 40 85 0")' } },
    { name: 'Leaf 2', color: '#9dffcc', css: { width:170, height:190, clipPath:'path("M 85 0 Q 170 60 170 130 Q 170 190 85 190 Q 0 190 0 130 Q 0 60 85 0")' } },
    { name: 'Leaf 3', color: '#9dff7c', css: { width:170, height:190, clipPath:'path("M 85 0 Q 85 60 170 100 Q 170 150 100 180 Q 85 190 70 180 Q 0 150 0 100 Q 85 60 85 0")' } },
    { name: 'Flower', color: '#ff7cb8', css: { width:180, height:180, clipPath:'path("M90 0 Q120 40 90 60 Q140 40 170 60 Q140 90 120 90 Q170 120 160 160 Q120 170 90 140 Q60 170 20 160 Q10 120 60 90 Q40 90 10 60 Q40 40 90 60 Q60 40 90 0 Z")' } },
    { name: 'Flower 5', color: '#ff7c9d', css: { width:190, height:190, clipPath:'path("M 95 10 Q 115 50 100 80 Q 135 65 160 85 Q 165 120 130 125 Q 155 155 130 170 Q 100 165 95 130 Q 90 165 60 170 Q 35 155 60 125 Q 25 120 30 85 Q 55 65 90 80 Q 75 50 95 10 Z")' } },
    { name: 'Daisy', color: '#ffd45c', css: { width:190, height:190, clipPath:'path("M95 5 Q115 45 95 55 Q135 45 155 65 Q135 90 115 85 Q155 105 155 135 Q120 140 95 120 Q70 140 35 135 Q35 105 75 85 Q55 90 35 65 Q55 45 95 55 Q75 45 95 5 Z")' } },
    { name: 'Tulip', color: '#ff7c9d', css: { width:170, height:190, clipPath:'path("M85 0 Q110 30 100 60 Q130 40 160 60 Q140 90 100 90 Q90 130 110 180 L 60 180 Q80 130 70 90 Q30 90 10 60 Q40 40 70 60 Q60 30 85 0 Z")' } },
    { name: 'Lotus', color: '#ff7cb8', css: { width:200, height:170, clipPath:'path("M 100 10 Q 120 50 110 80 Q 140 60 170 80 Q 160 110 110 110 Q 100 100 100 100 Q 100 100 90 110 Q 40 110 30 80 Q 60 60 90 80 Q 80 50 100 10 Z")' } },
    { name: 'Tree', color: '#7cff9d', css: { width:170, height:190, clipPath:'polygon(50% 0%, 80% 35%, 65% 35%, 90% 65%, 70% 65%, 90% 100%, 60% 100%, 60% 190%, 40% 190%, 40% 100%, 10% 100%, 30% 65%, 10% 65%, 35% 35%, 20% 35%)' } },
    { name: 'Pine', color: '#4dffcc', css: { width:170, height:190, clipPath:'polygon(50% 0%, 75% 30%, 62% 30%, 85% 55%, 68% 55%, 95% 85%, 75% 85%, 95% 110%, 60% 110%, 60% 190%, 40% 190%, 40% 110%, 5% 110%, 25% 85%, 5% 85%, 32% 55%, 15% 55%, 38% 30%, 25% 30%)' } },
    { name: 'Cactus', color: '#9dff7c', css: { width:170, height:190, clipPath:'path("M 70 0 L 100 0 L 100 60 Q 130 40 130 70 Q 130 90 100 90 L 100 130 Q 140 110 140 140 Q 140 160 100 160 L 100 190 L 70 190 L 70 160 Q 30 160 30 140 Q 30 110 70 130 L 70 90 Q 40 90 40 70 Q 40 40 70 60 Z")' } },
    { name: 'Mushroom', color: '#ff7c5c', css: { width:180, height:180, clipPath:'path("M 0 80 Q 90 -30 180 80 L 180 90 L 130 90 L 130 180 L 50 180 L 50 90 L 0 90 Z")' } },
    { name: 'Cloud', color: '#a0a0ff', css: { width:190, height:150, clipPath:'path("M 40 120 Q 0 120 0 90 Q 0 65 30 60 Q 40 25 80 25 Q 120 25 130 55 Q 165 55 170 85 Q 185 85 185 105 Q 185 120 155 120 Z")' } },
    { name: 'Snowflake', color: '#4dd4ff', css: { width:180, height:180, clipPath:'polygon(50% 0%, 60% 40%, 95% 25%, 70% 50%, 100% 65%, 60% 60%, 50% 100%, 40% 60%, 0% 65%, 30% 50%, 5% 25%, 40% 40%)' } },
    { name: 'Sun', color: '#ffd45c', css: { width:190, height:190, clipPath:'polygon(50% 25%, 55% 35%, 65% 30%, 62% 40%, 72% 42%, 65% 50%, 75% 55%, 65% 58%, 72% 68%, 62% 68%, 65% 78%, 55% 75%, 50% 85%, 45% 75%, 35% 78%, 38% 68%, 28% 68%, 35% 58%, 25% 55%, 35% 50%, 28% 42%, 38% 40%, 35% 30%, 45% 35%)' } },

    /* ---------- FOOD (15) ---------- */
    { name: 'Apple', color: '#ff4d6d', css: { width:180, height:180, clipPath:'path("M 90 40 Q 50 10 20 40 Q 0 90 40 150 Q 70 180 90 170 Q 110 180 140 150 Q 180 90 160 40 Q 130 10 90 40")' } },
    { name: 'Banana', color: '#ffd45c', css: { width:190, height:150, clipPath:'path("M 10 20 Q 60 10 110 50 Q 160 90 180 140 Q 170 145 160 130 Q 130 90 90 60 Q 50 35 10 20 Z")' } },
    { name: 'Pear', color: '#c8ff5c', css: { width:170, height:190, clipPath:'path("M 70 0 L 100 0 L 100 50 Q 130 60 130 110 Q 130 180 85 180 Q 40 180 40 110 Q 40 60 70 50 Z")' } },
    { name: 'Cheese', color: '#ffd45c', css: { width:170, height:170, clipPath:'polygon(0% 0%, 100% 0%, 100% 40%, 60% 40%, 60% 100%, 40% 100%, 40% 40%, 0% 40%)' } },
    { name: 'Cup', color: '#b8a0ff', css: { width:160, height:170, clipPath:'polygon(0% 0%, 100% 0%, 85% 100%, 15% 100%)' } },
    { name: 'Cup 2', color: '#ff9d5c', css: { width:180, height:180, clipPath:'polygon(0% 20%, 80% 20%, 80% 80%, 100% 80%, 100% 100%, 0% 100%)' } },
    { name: 'Glass', color: '#4dffcc', css: { width:150, height:190, clipPath:'polygon(20% 0%, 80% 0%, 70% 100%, 30% 100%)' } },
    { name: 'Bottle', color: '#a0a0ff', css: { width:150, height:190, clipPath:'polygon(35% 0%, 65% 0%, 65% 20%, 75% 30%, 75% 100%, 25% 100%, 25% 30%, 35% 20%)' } },
    { name: 'Spoon', color: '#ff7cff', css: { width:180, height:130, clipPath:'polygon(0% 35%, 60% 35%, 60% 20%, 85% 20%, 85% 80%, 60% 80%, 60% 65%, 0% 65%)' } },
    { name: 'Fork', color: '#ffcc4d', css: { width:180, height:130, clipPath:'polygon(0% 35%, 50% 35%, 50% 0%, 60% 0%, 60% 35%, 70% 35%, 70% 0%, 80% 0%, 80% 35%, 100% 35%, 100% 65%, 0% 65%)' } },
    { name: 'Full Plate', color: '#4dffcc', css: { width:190, height:190, clipPath:'polygon(50% 0%, 90% 10%, 100% 50%, 90% 90%, 50% 100%, 10% 90%, 0% 50%, 10% 10%, 50% 0%, 50% 20%, 78% 25%, 85% 50%, 78% 75%, 50% 80%, 22% 75%, 15% 50%, 22% 25%, 50% 20%)' } },
    { name: 'Cupcake', color: '#ff7c9d', css: { width:170, height:190, clipPath:'path("M 30 80 Q 30 30 85 20 Q 140 30 140 80 L 140 100 L 30 100 Z M 30 100 L 140 100 L 130 190 L 40 190 Z")' } },
    { name: 'Ice Cream', color: '#ffcc4d', css: { width:160, height:200, clipPath:'polygon(50% 0%, 80% 30%, 80% 50%, 60% 50%, 50% 100%, 40% 50%, 20% 50%, 20% 30%)' } },
    { name: 'Donut 2', color: '#ff7c9d', css: { width:180, height:180, clipPath:'path("M 90 10 Q 170 10 170 90 Q 170 170 90 170 Q 10 170 10 90 Q 10 10 90 10 Z")' } },
    { name: 'Cake', color: '#ff7cff', css: { width:180, height:180, clipPath:'polygon(10% 30%, 90% 30%, 90% 40%, 100% 40%, 100% 100%, 0% 100%, 0% 40%, 10% 40%)' } },

    /* ---------- ARROWS (10) ---------- */
    { name: 'Arrow', color: '#c8ff5c', css: { width:180, height:140, clipPath:'polygon(0% 35%, 60% 35%, 60% 0%, 100% 50%, 60% 100%, 60% 65%, 0% 65%)' } },
    { name: 'Arrow Right', color: '#8b7cff', css: { width:190, height:120, clipPath:'polygon(0% 30%, 70% 30%, 70% 0%, 100% 50%, 70% 100%, 70% 70%, 0% 70%)' } },
    { name: 'Arrow Left', color: '#7c9dff', css: { width:190, height:120, clipPath:'polygon(100% 30%, 30% 30%, 30% 0%, 0% 50%, 30% 100%, 30% 70%, 100% 70%)' } },
    { name: 'Arrow Up', color: '#4dd4ff', css: { width:120, height:190, clipPath:'polygon(30% 100%, 30% 30%, 0% 30%, 50% 0%, 100% 30%, 70% 30%, 70% 100%)' } },
    { name: 'Arrow Down', color: '#4dffcc', css: { width:120, height:190, clipPath:'polygon(30% 0%, 30% 70%, 0% 70%, 50% 100%, 100% 70%, 70% 70%, 70% 0%)' } },
    { name: 'Arrow 4-Way', color: '#ffd45c', css: { width:190, height:190, clipPath:'polygon(50% 0%, 65% 25%, 90% 25%, 90% 10%, 100% 25%, 75% 50%, 100% 75%, 90% 90%, 90% 75%, 65% 75%, 50% 100%, 35% 75%, 10% 75%, 10% 90%, 0% 75%, 25% 50%, 0% 25%, 10% 10%, 10% 25%, 35% 25%)' } },
    { name: 'Double Arrow', color: '#ffcc4d', css: { width:190, height:140, clipPath:'polygon(0% 50%, 25% 15%, 25% 35%, 75% 35%, 75% 15%, 100% 50%, 75% 85%, 75% 65%, 25% 65%, 25% 85%)' } },
    { name: 'Chevron', color: '#7cff9d', css: { width:170, height:150, clipPath:'polygon(0% 20%, 50% 0%, 100% 20%, 100% 80%, 50% 100%, 0% 80%)' } },
    { name: 'Triple Chevron', color: '#a0ff5c', css: { width:190, height:130, clipPath:'polygon(0% 50%, 20% 0%, 33% 0%, 13% 50%, 33% 100%, 20% 100%, 33% 50%, 53% 0%, 66% 0%, 46% 50%, 66% 100%, 53% 100%, 66% 50%, 86% 0%, 100% 0%, 80% 50%, 100% 100%, 86% 100%)' } },
    { name: 'Caret', color: '#4dffcc', css: { width:190, height:150, clipPath:'polygon(50% 0%, 100% 100%, 0% 100%, 50% 30%, 20% 100%, 50% 50%, 80% 100%)' } },

    /* ---------- SYMBOLS (12) ---------- */
    { name: 'Infinity', color: '#ff7c9d', css: { width:200, height:130, clipPath:'path("M 50 65 A 35 35 0 1 1 100 65 A 35 35 0 1 0 150 65 A 35 35 0 1 1 100 65 A 35 35 0 1 0 50 65 Z")' } },
    { name: 'Gear', color: '#ff9d5c', css: { width:190, height:190, clipPath:'polygon(40% 0%, 60% 0%, 65% 20%, 80% 10%, 90% 30%, 100% 40%, 85% 55%, 100% 60%, 90% 80%, 80% 90%, 60% 85%, 55% 100%, 40% 100%, 35% 85%, 20% 90%, 10% 80%, 0% 60%, 15% 55%, 0% 40%, 10% 30%, 20% 10%, 35% 20%, 40% 0%)' } },
    { name: 'Spiral', color: '#b87cff', css: { width:190, height:190, clipPath:'polygon(50% 50%, 60% 40%, 70% 50%, 60% 65%, 40% 65%, 25% 50%, 25% 30%, 45% 15%, 70% 15%, 85% 35%, 85% 65%, 65% 85%, 35% 85%, 10% 60%, 10% 30%, 35% 5%)' } },
    { name: 'Spiral 2', color: '#b87cff', css: { width:190, height:190, clipPath:'polygon(50% 0%, 70% 10%, 90% 25%, 100% 50%, 90% 75%, 70% 90%, 50% 100%, 30% 90%, 10% 75%, 0% 50%, 10% 25%, 30% 10%, 50% 20%, 65% 30%, 80% 50%, 70% 70%, 50% 80%, 30% 70%, 20% 50%, 30% 30%, 50% 40%)' } },
    { name: 'Crystal', color: '#4dd4ff', css: { width:190, height:190, clipPath:'polygon(50% 0%, 80% 20%, 100% 60%, 70% 100%, 30% 100%, 0% 60%, 20% 20%)' } },
    { name: 'Thumbs Up', color: '#ff7c9d', css: { width:150, height:190, clipPath:'polygon(35% 40%, 65% 40%, 65% 0%, 85% 0%, 85% 40%, 100% 40%, 100% 100%, 0% 100%, 0% 50%, 35% 50%)' } },
    { name: 'Bookmark', color: '#ff7cff', css: { width:150, height:190, clipPath:'polygon(0% 0%, 100% 0%, 100% 100%, 50% 70%, 0% 100%)' } },
    { name: 'Trophy', color: '#ffd45c', css: { width:170, height:190, clipPath:'polygon(20% 0%, 80% 0%, 80% 20%, 100% 20%, 100% 50%, 80% 65%, 80% 75%, 55% 75%, 55% 85%, 75% 85%, 75% 100%, 25% 100%, 25% 85%, 45% 85%, 45% 75%, 20% 75%, 20% 65%, 0% 50%, 0% 20%, 20% 20%)' } },
    { name: 'Medal', color: '#ffb04d', css: { width:150, height:190, clipPath:'polygon(30% 0%, 70% 0%, 80% 30%, 100% 30%, 100% 80%, 50% 100%, 0% 80%, 0% 30%, 20% 30%, 30% 0%)' } },
    { name: 'Crown', color: '#ff7c9d', css: { width:190, height:150, clipPath:'polygon(0% 100%, 0% 30%, 20% 50%, 25% 0%, 50% 40%, 75% 0%, 80% 50%, 100% 30%, 100% 100%)' } },
    { name: 'Shield', color: '#7c9dff', css: { width:160, height:180, clipPath:'path("M80 0 L160 30 L160 100 Q160 160 80 180 Q0 160 0 100 L0 30 Z")' } },
    { name: 'Asterisk', color: '#ffcc4d', css: { width:190, height:190, clipPath:'polygon(40% 0%, 60% 0%, 60% 40%, 100% 40%, 100% 60%, 60% 60%, 60% 100%, 40% 100%, 40% 60%, 0% 60%, 0% 40%, 40% 40%)' } },

    /* ---------- BUILDINGS (10) ---------- */
    { name: 'Pyramid', color: '#ff9d5c', css: { width:190, height:150, clipPath:'polygon(50% 0%, 100% 100%, 75% 100%, 50% 40%, 25% 100%, 0% 100%)' } },
    { name: 'Tower', color: '#7c9dff', css: { width:150, height:190, clipPath:'polygon(50% 0%, 70% 20%, 70% 40%, 80% 40%, 80% 60%, 70% 60%, 70% 100%, 30% 100%, 30% 60%, 20% 60%, 20% 40%, 30% 40%, 30% 20%)' } },
    { name: 'Bridge', color: '#4dd4ff', css: { width:200, height:150, clipPath:'polygon(0% 60%, 10% 20%, 20% 60%, 30% 20%, 40% 60%, 50% 20%, 60% 60%, 70% 20%, 80% 60%, 90% 20%, 100% 60%, 100% 100%, 0% 100%)' } },
    { name: 'Castle', color: '#ffd45c', css: { width:190, height:150, clipPath:'polygon(0% 40%, 10% 40%, 10% 20%, 20% 20%, 20% 40%, 30% 40%, 30% 0%, 70% 0%, 70% 40%, 80% 40%, 80% 20%, 90% 20%, 90% 40%, 100% 40%, 100% 100%, 0% 100%)' } },
    { name: 'Mountain', color: '#8b7cff', css: { width:200, height:150, clipPath:'polygon(0% 100%, 15% 50%, 30% 80%, 50% 20%, 65% 60%, 80% 35%, 100% 100%)' } },
    { name: 'Mountain 2', color: '#7c9dff', css: { width:200, height:150, clipPath:'polygon(0% 100%, 20% 40%, 40% 70%, 60% 20%, 80% 60%, 100% 100%)' } },
    { name: 'House Pentagon', color: '#4dd4ff', css: { width:170, height:170, clipPath:'polygon(50% 0%, 100% 40%, 100% 100%, 0% 100%, 0% 40%)' } },
    { name: 'House', color: '#ff9d5c', css: { width:180, height:170, clipPath:'polygon(50% 0%, 100% 40%, 100% 100%, 70% 100%, 70% 60%, 30% 60%, 30% 100%, 0% 100%, 0% 40%)' } },
    { name: 'Boat', color: '#4dd4ff', css: { width:200, height:150, clipPath:'polygon(0% 60%, 100% 60%, 80% 100%, 20% 100%)' } },
    { name: 'Telescope', color: '#4dccff', css: { width:200, height:150, clipPath:'polygon(0% 30%, 65% 0%, 100% 20%, 100% 60%, 65% 80%, 0% 50%, 35% 50%, 35% 100%, 50% 100%, 50% 60%)' } },

    /* ---------- LETTERS (8) ---------- */
    { name: 'L-Shape', color: '#ff9d5c', css: { width:170, height:170, clipPath:'polygon(0% 0%, 40% 0%, 40% 60%, 100% 60%, 100% 100%, 0% 100%)' } },
    { name: 'T-Shape', color: '#4dffcc', css: { width:170, height:170, clipPath:'polygon(0% 0%, 100% 0%, 100% 30%, 65% 30%, 65% 100%, 35% 100%, 35% 30%, 0% 30%)' } },
    { name: 'U-Shape', color: '#ff7c9d', css: { width:170, height:170, clipPath:'polygon(0% 0%, 25% 0%, 25% 70%, 75% 70%, 75% 0%, 100% 0%, 100% 100%, 0% 100%)' } },
    { name: 'Z-Shape', color: '#a0ff5c', css: { width:170, height:170, clipPath:'polygon(0% 0%, 100% 0%, 100% 30%, 40% 30%, 100% 70%, 100% 100%, 0% 100%, 0% 70%, 60% 70%, 0% 30%)' } },
    { name: 'C-Shape', color: '#c8ff5c', css: { width:170, height:170, clipPath:'polygon(0% 0%, 100% 0%, 100% 25%, 30% 25%, 30% 75%, 100% 75%, 100% 100%, 0% 100%)' } },
    { name: 'H-Shape', color: '#ffcc4d', css: { width:180, height:170, clipPath:'polygon(0% 0%, 30% 0%, 30% 40%, 70% 40%, 70% 0%, 100% 0%, 100% 100%, 70% 100%, 70% 60%, 30% 60%, 30% 100%, 0% 100%)' } },
    { name: 'M-Shape', color: '#5cffd4', css: { width:190, height:170, clipPath:'polygon(0% 100%, 0% 0%, 25% 0%, 50% 40%, 75% 0%, 100% 0%, 100% 100%, 75% 100%, 75% 40%, 50% 80%, 25% 40%, 25% 100%)' } },
    { name: 'V-Shape', color: '#a0a0ff', css: { width:170, height:170, clipPath:'polygon(0% 0%, 30% 0%, 50% 60%, 70% 0%, 100% 0%, 60% 100%, 40% 100%)' } },

    /* ---------- ABSTRACT (15) ---------- */
    { name: 'Abstract 1', color: '#4dffcc', css: { width:180, height:180, clipPath:'polygon(0% 30%, 30% 0%, 60% 30%, 100% 0%, 70% 40%, 100% 70%, 60% 100%, 30% 70%, 0% 100%, 30% 60%)' } },
    { name: 'Abstract 2', color: '#ffd45c', css: { width:190, height:190, clipPath:'polygon(50% 0%, 75% 15%, 90% 40%, 100% 70%, 80% 90%, 50% 100%, 20% 90%, 0% 70%, 10% 40%, 25% 15%)' } },
    { name: 'Abstract 3', color: '#ff9d5c', css: { width:190, height:160, clipPath:'polygon(0% 50%, 20% 20%, 40% 50%, 60% 20%, 80% 50%, 100% 20%, 100% 80%, 80% 50%, 60% 80%, 40% 50%, 20% 80%, 0% 50%)' } },
    { name: 'Radial', color: '#ff7cff', css: { width:190, height:190, clipPath:'polygon(50% 50%, 90% 50%, 85% 70%, 70% 85%, 50% 90%, 30% 85%, 15% 70%, 10% 50%, 15% 30%, 30% 15%, 50% 10%, 70% 15%, 85% 30%)' } },
    { name: 'Rounded Star', color: '#ff7cb8', css: { width:190, height:190, clipPath:'path("M 95 15 Q 110 50 130 40 Q 130 65 160 65 Q 140 80 145 105 Q 120 95 110 120 Q 95 105 80 120 Q 70 95 45 105 Q 50 80 30 65 Q 60 65 60 40 Q 80 50 95 15 Z")' } },
    { name: 'Cut Diamond', color: '#ff9d5c', css: { width:170, height:170, clipPath:'polygon(50% 0%, 100% 25%, 85% 50%, 100% 75%, 50% 100%, 0% 75%, 15% 50%, 0% 25%)' } },
    { name: 'Delta', color: '#ffb04d', css: { width:170, height:150, clipPath:'polygon(50% 0%, 100% 100%, 0% 100%)' } },
    { name: 'Diamond 2', color: '#7c9dff', css: { width:150, height:150, clipPath:'polygon(50% 0%, 100% 30%, 100% 70%, 50% 100%, 0% 70%, 0% 30%)' } },
    { name: 'Rounded Diamond', color: '#4dffcc', css: { width:150, height:150, clipPath:'polygon(50% 5%, 95% 50%, 50% 95%, 5% 50%)' } },
    { name: 'Double Diamond', color: '#ffcc4d', css: { width:180, height:180, clipPath:'polygon(50% 0%, 75% 25%, 100% 50%, 75% 75%, 50% 100%, 25% 75%, 0% 50%, 25% 25%)' } },
    { name: 'Diamond 3', color: '#ff7c9d', css: { width:180, height:170, clipPath:'polygon(50% 0%, 100% 25%, 90% 60%, 50% 100%, 10% 60%, 0% 25%)' } },
    { name: 'Diamond Facet', color: '#4dffcc', css: { width:190, height:170, clipPath:'polygon(50% 0%, 100% 25%, 90% 60%, 50% 100%, 10% 60%, 0% 25%)' } },
    { name: 'Diamond Grid', color: '#ffcc7c', css: { width:190, height:190, clipPath:'polygon(50% 0%, 75% 25%, 100% 50%, 75% 75%, 50% 100%, 25% 75%, 0% 50%, 25% 25%)' } },
    { name: 'Diamond Ring', color: '#ffcc4d', css: { width:190, height:190, clipPath:'polygon(0% 0%, 40% 0%, 50% 30%, 60% 0%, 100% 0%, 100% 40%, 70% 50%, 100% 60%, 100% 100%, 60% 100%, 50% 70%, 40% 100%, 0% 100%, 0% 60%, 30% 50%, 0% 40%)' } },
    { name: 'Radial 2', color: '#ff7cff', css: { width:190, height:190, clipPath:'polygon(50% 0%, 90% 50%, 50% 100%, 10% 50%)' } },

    /* ---------- MISC GEOMETRY (15) ---------- */
    { name: 'World', color: '#ff7c5c', css: { width:180, height:180, clipPath:'polygon(50% 0%, 90% 15%, 100% 50%, 90% 85%, 50% 100%, 10% 85%, 0% 50%, 10% 15%)' } },
    { name: 'Parallel Side', color: '#7c9dff', css: { width:190, height:140, clipPath:'polygon(10% 0%, 90% 0%, 100% 50%, 90% 100%, 10% 100%, 0% 50%)' } },
    { name: 'Parallel Hex', color: '#ff7c9d', css: { width:200, height:130, clipPath:'polygon(15% 0%, 100% 0%, 85% 100%, 0% 100%, 15% 70%, 100% 70%, 85% 30%, 0% 30%, 15% 0%)' } },
    { name: 'Step', color: '#4dffcc', css: { width:170, height:170, clipPath:'polygon(0% 100%, 0% 65%, 33% 65%, 33% 35%, 66% 35%, 66% 0%, 100% 0%, 100% 100%)' } },
    { name: 'Step 2', color: '#4dccff', css: { width:170, height:170, clipPath:'polygon(0% 100%, 0% 70%, 25% 70%, 25% 45%, 50% 45%, 50% 20%, 75% 20%, 75% 0%, 100% 0%, 100% 100%)' } },
    { name: 'Step Pyramid', color: '#9dff7c', css: { width:190, height:150, clipPath:'polygon(50% 0%, 60% 20%, 70% 20%, 70% 40%, 80% 40%, 80% 60%, 90% 60%, 90% 80%, 100% 80%, 100% 100%, 0% 100%, 0% 80%, 10% 80%, 10% 60%, 20% 60%, 20% 40%, 30% 40%, 30% 20%, 40% 20%)' } },
    { name: 'Double Step', color: '#4dccff', css: { width:190, height:150, clipPath:'polygon(0% 100%, 0% 50%, 25% 50%, 25% 0%, 50% 0%, 50% 50%, 75% 50%, 75% 0%, 100% 0%, 100% 100%)' } },
    { name: 'Triple Step', color: '#ffd45c', css: { width:190, height:150, clipPath:'polygon(0% 100%, 0% 66%, 15% 66%, 15% 33%, 30% 33%, 30% 0%, 70% 0%, 70% 33%, 85% 33%, 85% 66%, 100% 66%, 100% 100%)' } },
    { name: 'Flag', color: '#8b7cff', css: { width:170, height:170, clipPath:'polygon(0% 0%, 100% 0%, 100% 40%, 50% 40%, 50% 100%, 40% 100%, 40% 40%, 0% 40%)' } },
    { name: 'Banner', color: '#ff7cb8', css: { width:180, height:150, clipPath:'polygon(0% 20%, 100% 20%, 100% 80%, 0% 80%)' } },
    { name: 'Banner Tag', color: '#c8ff5c', css: { width:180, height:150, clipPath:'polygon(0% 0%, 80% 0%, 100% 50%, 80% 100%, 0% 100%, 10% 50%)' } },
    { name: 'Tag', color: '#a0a0ff', css: { width:160, height:150, clipPath:'polygon(0% 0%, 70% 0%, 100% 50%, 70% 100%, 0% 100%)' } },
    { name: 'Ticket', color: '#ff7cb8', css: { width:200, height:120, clipPath:'polygon(0% 0%, 100% 0%, 100% 40%, 94% 50%, 100% 60%, 100% 100%, 0% 100%, 0% 60%, 6% 50%, 0% 40%)' } },
    { name: 'Six-Sided', color: '#ff9d5c', css: { width:150, height:180, clipPath:'polygon(50% 0%, 90% 30%, 100% 70%, 80% 100%, 20% 100%, 0% 70%, 10% 30%)' } },
    { name: 'Keel', color: '#ff7c9d', css: { width:170, height:170, clipPath:'polygon(0% 100%, 30% 40%, 70% 40%, 100% 100%, 70% 60%, 30% 60%)' } },

    /* ---------- ANIMALS (15) ---------- */
    { name: 'Fish', color: '#5cc8ff', css: { width:200, height:140, clipPath:'polygon(0% 50%, 30% 25%, 60% 25%, 100% 0%, 90% 50%, 100% 100%, 60% 75%, 30% 75%)' } },
    { name: 'Fish 2', color: '#4dc4e8', css: { width:200, height:140, clipPath:'path("M 0 70 Q 20 20 90 20 Q 160 20 180 60 Q 200 50 220 70 Q 200 90 180 80 Q 160 130 90 130 Q 20 130 0 70 Z")' } },
    { name: 'Bird', color: '#7cff9e', css: { width:200, height:140, clipPath:'polygon(0% 60%, 25% 40%, 50% 55%, 75% 40%, 100% 60%, 75% 75%, 50% 80%, 25% 75%)' } },
    { name: 'Butterfly', color: '#ff5cb8', css: { width:200, height:180, clipPath:'path("M 100 60 Q 60 20 20 40 Q 0 80 40 110 Q 10 140 40 170 Q 80 170 100 130 Q 120 170 160 170 Q 190 140 160 110 Q 200 80 180 40 Q 140 20 100 60 Z")' } },
    { name: 'Butterfly 2', color: '#ff7cff', css: { width:200, height:160, clipPath:'polygon(50% 50%, 0% 0%, 20% 50%, 0% 100%, 50% 50%, 100% 0%, 80% 50%, 100% 100%)' } },
    { name: 'Cat Head', color: '#ffb04d', css: { width:180, height:170, clipPath:'polygon(20% 0%, 30% 25%, 50% 20%, 70% 25%, 80% 0%, 100% 20%, 95% 60%, 75% 95%, 25% 95%, 5% 60%, 0% 20%)' } },
    { name: 'Paw', color: '#ff7c5c', css: { width:180, height:180, clipPath:'path("M 90 100 Q 50 100 40 130 Q 30 160 60 160 Q 80 160 90 140 Q 100 160 120 160 Q 150 160 140 130 Q 130 100 90 100 Z M 50 80 Q 45 50 55 45 Q 65 45 65 80 Q 55 90 50 80 M 90 40 Q 85 10 100 10 Q 115 10 110 40 Q 100 55 90 40 M 130 80 Q 135 50 145 45 Q 155 45 150 80 Q 145 90 130 80")' } },
    { name: 'Penguin', color: '#a0c8ff', css: { width:150, height:180, clipPath:'path("M 75 0 Q 120 10 120 60 Q 140 80 130 130 Q 130 180 75 180 Q 20 180 20 130 Q 10 80 30 60 Q 30 10 75 0 Z")' } },
    { name: 'Owl', color: '#d4a05c', css: { width:160, height:180, clipPath:'polygon(20% 10%, 30% 20%, 50% 15%, 70% 20%, 80% 10%, 95% 30%, 90% 70%, 65% 100%, 35% 100%, 10% 70%, 5% 30%)' } },
    { name: 'Whale', color: '#4dc4e8', css: { width:220, height:140, clipPath:'path("M 0 70 Q 20 20 90 20 Q 160 20 180 60 Q 200 50 220 70 Q 200 90 180 80 Q 160 130 90 130 Q 20 130 0 70 Z")' } },
    { name: 'Snail', color: '#c8a07c', css: { width:200, height:150, clipPath:'path("M 30 110 Q 30 60 90 60 Q 150 60 160 100 Q 170 130 130 140 L 60 140 Q 20 140 20 110 Z")' } },
    { name: 'Turtle', color: '#7cff9e', css: { width:200, height:150, clipPath:'path("M 40 100 Q 20 60 60 40 Q 100 20 140 40 Q 180 60 160 100 Q 180 120 200 110 Q 190 140 160 130 Q 140 150 100 150 Q 60 150 40 130 Q 10 140 0 110 Q 20 120 40 100 Z")' } },
    { name: 'Jellyfish', color: '#ff7cb8', css: { width:160, height:190, clipPath:'path("M 80 0 Q 160 20 160 80 Q 160 100 140 100 L 130 130 L 120 100 L 110 130 L 100 100 L 90 130 L 80 100 L 70 130 L 60 100 L 50 130 L 40 100 L 20 100 Q 0 100 0 80 Q 0 20 80 0 Z")' } },
    { name: 'Crab', color: '#ff5c5c', css: { width:200, height:150, clipPath:'path("M 30 60 Q 0 40 0 70 Q 20 80 30 100 Q 10 110 30 130 Q 50 130 60 110 Q 60 140 100 140 Q 140 140 140 110 Q 150 130 170 130 Q 190 110 170 100 Q 180 80 200 70 Q 200 40 170 60 Q 150 40 140 60 Q 140 40 100 40 Q 60 40 60 60 Q 50 40 30 60 Z")' } },
    { name: 'Octopus', color: '#ff7c9d', css: { width:180, height:190, clipPath:'path("M 90 0 Q 150 20 150 80 Q 150 100 130 110 L 130 130 L 110 110 L 100 140 L 90 110 L 80 140 L 70 110 L 50 130 L 50 110 Q 30 100 30 80 Q 30 20 90 0 Z")' } },

    /* ---------- WEATHER (10) ---------- */
    { name: 'Lightning', color: '#ffcc4d', css: { width:120, height:200, clipPath:'polygon(45% 0%, 25% 50%, 45% 50%, 30% 100%, 75% 45%, 55% 45%, 75% 0%)' } },
    { name: 'Raindrop', color: '#5cc8ff', css: { width:140, height:180, clipPath:'path("M 70 0 Q 140 80 140 120 Q 140 175 70 175 Q 0 175 0 120 Q 0 80 70 0 Z")' } },
    { name: 'Snowflake 2', color: '#c8e8ff', css: { width:180, height:180, clipPath:'polygon(50% 0%, 55% 35%, 65% 15%, 70% 40%, 85% 25%, 80% 50%, 100% 50%, 80% 55%, 95% 75%, 70% 65%, 65% 90%, 55% 65%, 50% 100%, 45% 65%, 30% 90%, 25% 65%, 0% 75%, 15% 55%, 0% 50%, 20% 50%, 15% 25%, 30% 40%, 35% 15%, 45% 35%)' } },
    { name: 'Wind', color: '#a0d4ff', css: { width:200, height:120, clipPath:'polygon(0% 40%, 60% 40%, 70% 25%, 85% 25%, 85% 40%, 100% 40%, 100% 60%, 70% 60%, 60% 75%, 40% 75%, 40% 60%, 0% 60%)' } },
    { name: 'Tornado', color: '#a0a0c8', css: { width:150, height:200, clipPath:'polygon(0% 0%, 100% 0%, 80% 30%, 90% 30%, 70% 60%, 80% 60%, 55% 100%, 45% 100%, 20% 60%, 30% 60%, 10% 30%, 20% 30%)' } },
    { name: 'Volcano', color: '#ff5c3c', css: { width:200, height:150, clipPath:'polygon(0% 100%, 30% 40%, 40% 45%, 50% 20%, 60% 45%, 70% 40%, 100% 100%)' } },
    { name: 'Island', color: '#5cff9e', css: { width:200, height:150, clipPath:'path("M 0 110 Q 40 60 80 90 Q 120 50 160 90 Q 200 70 200 130 L 0 130 Z")' } },
    { name: 'Crescent', color: '#ffd45c', css: { width:180, height:180, clipPath:'path("M 90 0 Q 180 30 180 90 Q 180 150 90 180 Q 140 90 90 0 Z")' } },
    { name: 'Star River', color: '#a0a0ff', css: { width:180, height:180, clipPath:'polygon(50% 0%, 60% 20%, 80% 20%, 70% 40%, 90% 50%, 70% 60%, 80% 80%, 60% 80%, 50% 100%, 40% 80%, 20% 80%, 30% 60%, 10% 50%, 30% 40%, 20% 20%, 40% 20%)' } },
    { name: 'Rainbow', color: '#ff7c9d', css: { width:200, height:120, clipPath:'path("M 0 120 Q 0 0 100 0 Q 200 0 200 120 L 180 120 Q 180 20 100 20 Q 20 20 20 120 Z")' } },

    /* ---------- EXTRA LIBRARY SHAPES ---------- */
    { name: 'Lib Octagon', color: '#4dffcc', css: { width:170, height:170, clipPath:'polygon(30% 0%, 70% 0%, 100% 30%, 100% 70%, 70% 100%, 30% 100%, 0% 70%, 0% 30%)' } },
    { name: 'Lib Arrow', color: '#c8ff5c', css: { width:190, height:120, clipPath:'polygon(0% 30%, 70% 30%, 70% 0%, 100% 50%, 70% 100%, 70% 70%, 0% 70%)' } },
    { name: 'Lib Leaf', color: '#9dff7c', css: { width:170, height:180, clipPath:'path("M 85 0 Q 170 40 170 110 Q 170 180 85 180 Q 0 180 0 110 Q 0 40 85 0")' } },
    { name: 'Lib Drop', color: '#4dd4ff', css: { width:150, height:180, clipPath:'path("M75 0 Q150 90 150 130 Q150 180 75 180 Q0 180 0 130 Q0 90 75 0 Z")' } },
    { name: 'Lib Shield', color: '#7c9dff', css: { width:160, height:180, clipPath:'path("M80 0 L160 30 L160 100 Q160 160 80 180 Q0 160 0 100 L0 30 Z")' } },
    { name: 'Lib Gear', color: '#ff9d5c', css: { width:190, height:190, clipPath:'polygon(40% 0%, 60% 0%, 65% 20%, 80% 10%, 90% 30%, 100% 40%, 85% 55%, 100% 60%, 90% 80%, 80% 90%, 60% 85%, 55% 100%, 40% 100%, 35% 85%, 20% 90%, 10% 80%, 0% 60%, 15% 55%, 0% 40%, 10% 30%, 20% 10%, 35% 20%, 40% 0%)' } },
    { name: 'Lib Crown', color: '#ff7c9d', css: { width:190, height:150, clipPath:'polygon(0% 100%, 0% 30%, 20% 50%, 25% 0%, 50% 40%, 75% 0%, 80% 50%, 100% 30%, 100% 100%)' } },
    { name: 'Lib Trophy', color: '#ffd45c', css: { width:170, height:190, clipPath:'polygon(20% 0%, 80% 0%, 80% 20%, 100% 20%, 100% 50%, 80% 65%, 80% 75%, 55% 75%, 55% 85%, 75% 85%, 75% 100%, 25% 100%, 25% 85%, 45% 85%, 45% 75%, 20% 75%, 20% 65%, 0% 50%, 0% 20%, 20% 20%)' } },
    { name: 'Lib Crystal', color: '#4dd4ff', css: { width:190, height:190, clipPath:'polygon(50% 0%, 80% 20%, 100% 60%, 70% 100%, 30% 100%, 0% 60%, 20% 20%)' } },
    { name: 'Lib Spiral', color: '#b87cff', css: { width:190, height:190, clipPath:'polygon(50% 50%, 60% 40%, 70% 50%, 60% 65%, 40% 65%, 25% 50%, 25% 30%, 45% 15%, 70% 15%, 85% 35%, 85% 65%, 65% 85%, 35% 85%, 10% 60%, 10% 30%, 35% 5%)' } },

    /* ---------- ROUNDED & ORGANIC (10) ---------- */
    { name: 'Squircle 2', color: '#7c9dff', css: { width:180, height:180, borderRadius:'42%' } },
    { name: 'Egg', color: '#ffd45c', css: { width:150, height:190, borderRadius:'50% 50% 50% 50% / 60% 60% 40% 40%' } },
    { name: 'Bean', color: '#9dff7c', css: { width:190, height:120, borderRadius:'60% 40% 55% 45% / 55% 60% 40% 45%' } },
    { name: 'Pebble', color: '#a0a0ff', css: { width:170, height:140, borderRadius:'48% 52% 42% 58% / 55% 45% 55% 45%' } },
    { name: 'Blob 2', color: '#ff7cff', css: { width:180, height:180, borderRadius:'65% 35% 55% 45% / 40% 60% 40% 60%' } },
    { name: 'Blob 3', color: '#ff5c9e', css: { width:170, height:170, borderRadius:'40% 60% 30% 70% / 55% 45% 65% 35%' } },
    { name: 'Cloud Puff', color: '#a0d4ff', css: { width:200, height:130, borderRadius:'50% 50% 50% 50% / 70% 70% 30% 30%' } },
    { name: 'Capsule', color: '#4dffcc', css: { width:200, height:100, borderRadius:'50px' } },
    { name: 'Lozenge', color: '#d4ff5c', css: { width:200, height:110, borderRadius:'30px 30px 30px 30px / 55px 55px 55px 55px' } },
    { name: 'Water Drop 2', color: '#4dd4ff', css: { width:150, height:180, borderRadius:'50% 50% 50% 50% / 75% 75% 25% 25%' } },

    /* ---------- COMPLEX POLYGONS ---------- */
    { name: 'Hendecagon', color: '#ff5c8c', css: { width:170, height:170, clipPath:'polygon(50% 0%, 76% 8%, 95% 27%, 100% 55%, 88% 79%, 65% 95%, 38% 98%, 15% 85%, 2% 62%, 2% 35%, 18% 12%)' } },
    { name: 'Tridecagon', color: '#5c8cff', css: { width:170, height:170, clipPath:'polygon(50% 0%, 73% 6%, 91% 22%, 100% 45%, 97% 68%, 82% 87%, 60% 98%, 37% 97%, 16% 84%, 3% 63%, 0% 40%, 11% 18%, 30% 5%)' } },
    { name: 'Tetradecagon', color: '#7cff9e', css: { width:170, height:170, clipPath:'polygon(50% 0%, 72% 6%, 89% 20%, 100% 40%, 100% 60%, 89% 80%, 72% 94%, 50% 100%, 28% 94%, 11% 80%, 0% 60%, 0% 40%, 11% 20%, 28% 6%)' } },
    { name: 'Triacontagon', color: '#ffb04d', css: { width:170, height:170, borderRadius:'85px' } },
    { name: 'Arrow 5b', color: '#c8ff5c', css: { width:190, height:170, clipPath:'polygon(50% 0%, 60% 35%, 100% 35%, 75% 60%, 85% 95%, 50% 75%, 15% 95%, 25% 60%, 0% 35%, 40% 35%)' } },

    /* ---------- HIGH STAR COUNTS ---------- */
    { name: 'Star 16', color: '#ff7c5c', css: { width:180, height:180, clipPath:'polygon(50% 0%, 55% 22%, 70% 8%, 68% 28%, 88% 16%, 78% 35%, 100% 40%, 82% 50%, 100% 60%, 78% 65%, 88% 84%, 68% 72%, 70% 92%, 55% 78%, 50% 100%, 45% 78%, 30% 92%, 32% 72%, 12% 84%, 22% 65%, 0% 60%, 18% 50%, 0% 40%, 22% 35%, 12% 16%, 32% 28%, 30% 8%, 45% 22%)' } },
    { name: 'Star 20', color: '#5cffd4', css: { width:180, height:180, clipPath:'polygon(50% 0%, 54% 20%, 65% 8%, 64% 25%, 80% 15%, 74% 32%, 92% 30%, 80% 42%, 100% 50%, 80% 58%, 92% 70%, 74% 68%, 80% 85%, 64% 75%, 65% 92%, 54% 80%, 50% 100%, 46% 80%, 35% 92%, 36% 75%, 20% 85%, 26% 68%, 8% 70%, 20% 58%, 0% 50%, 20% 42%, 8% 30%, 26% 32%, 20% 15%, 36% 25%, 35% 8%, 46% 20%)' } },

    /* ---------- MORE NATURE ---------- */
    { name: 'Leaf 4', color: '#9dff7c', css: { width:170, height:190, clipPath:'path("M 85 0 Q 170 50 170 110 Q 170 180 85 180 Q 0 180 0 110 Q 0 50 85 0 Z")' } },
    { name: 'Acorn', color: '#d4a05c', css: { width:150, height:180, clipPath:'path("M 20 50 Q 20 0 75 0 Q 130 0 130 50 L 130 60 L 20 60 Z M 30 60 L 120 60 L 105 180 L 45 180 Z")' } },
    { name: 'Tree 2', color: '#7cff9d', css: { width:170, height:200, clipPath:'polygon(50% 0%, 90% 40%, 70% 40%, 95% 80%, 60% 80%, 60% 200%, 40% 200%, 40% 80%, 5% 80%, 30% 40%, 10% 40%)' } },
    { name: 'Moon Crescent', color: '#ffd45c', css: { width:180, height:180, clipPath:'path("M 90 0 Q 160 20 180 80 Q 180 150 100 180 Q 130 100 90 0 Z")' } },
    { name: 'Sun 2', color: '#ffd45c', css: { width:190, height:190, clipPath:'polygon(50% 10%, 55% 30%, 70% 15%, 65% 35%, 85% 25%, 75% 45%, 90% 45%, 78% 55%, 90% 65%, 78% 62%, 78% 82%, 65% 72%, 65% 90%, 55% 78%, 50% 95%, 45% 78%, 35% 90%, 35% 72%, 22% 82%, 22% 62%, 10% 65%, 22% 55%, 10% 45%, 25% 45%, 15% 25%, 35% 35%, 30% 15%, 45% 30%)' } },
    { name: 'Fire', color: '#ff5c3c', css: { width:150, height:200, clipPath:'path("M 75 0 Q 90 40 110 60 Q 130 80 120 120 Q 110 160 75 200 Q 40 160 30 120 Q 20 80 40 60 Q 60 40 75 0 Z")' } },
    { name: 'Ocean Wave', color: '#4dd4ff', css: { width:200, height:130, clipPath:'path("M 0 50 Q 30 10 60 50 Q 90 90 120 50 Q 150 10 180 50 Q 200 70 200 130 L 0 130 Z")' } },
    { name: 'Mountain 3', color: '#7c9dff', css: { width:220, height:150, clipPath:'polygon(0% 100%, 15% 60%, 30% 80%, 50% 30%, 65% 65%, 80% 45%, 100% 100%)' } },

    /* ---------- MORE FOOD ---------- */
    { name: 'Ice Cream 2', color: '#ff7cb8', css: { width:150, height:200, clipPath:'path("M 30 60 Q 30 0 75 0 Q 120 0 120 60 Q 120 90 75 100 Q 30 90 30 60 Z M 60 100 L 90 100 L 75 200 Z")' } },
    { name: 'Cupcake 2', color: '#ff5ce5', css: { width:170, height:180, clipPath:'path("M 20 90 Q 20 30 85 10 Q 150 30 150 90 L 150 100 L 20 100 Z M 20 100 L 150 100 L 130 180 L 40 180 Z")' } },
    { name: 'Wine Glass', color: '#c84dff', css: { width:130, height:200, clipPath:'path("M 30 0 L 100 0 L 90 80 Q 80 120 65 130 L 65 180 L 100 180 L 100 195 L 30 195 L 30 180 L 65 180 L 65 130 Q 50 120 40 80 Z")' } },
    { name: 'Bottle 2', color: '#5cffb8', css: { width:120, height:200, clipPath:'path("M 45 0 L 75 0 L 75 30 Q 100 50 100 90 L 100 180 Q 100 200 60 200 Q 20 200 20 180 L 20 90 Q 20 50 45 30 Z")' } },
    { name: 'Chopsticks', color: '#ffb04d', css: { width:180, height:180, clipPath:'polygon(0% 20%, 90% 45%, 90% 50%, 0% 25%, 0% 20%, 0% 75%, 90% 55%, 90% 50%, 0% 70%)' } },
    { name: 'Cookie', color: '#d4a05c', css: { width:180, height:180, borderRadius:'85px' } },
    { name: 'Pretzel', color: '#d4a05c', css: { width:180, height:180, clipPath:'path("M 50 40 Q 90 10 130 40 Q 160 70 130 110 Q 110 140 90 120 Q 70 100 90 80 Q 110 60 130 90 Q 140 110 130 130 Q 100 160 50 130 Q 20 100 50 40 Z")' } },

    /* ---------- MORE SYMBOLS ---------- */
    { name: 'Yin Yang', color: '#ffffff', css: { width:180, height:180, borderRadius:'85px' } },
    { name: 'Peace', color: '#a0a0ff', css: { width:180, height:180, borderRadius:'85px' } },
    { name: 'Plus Round', color: '#5cff7c', css: { width:170, height:170, clipPath:'path("M 65 20 Q 65 0 85 0 Q 105 0 105 20 L 105 65 L 150 65 Q 170 65 170 85 Q 170 105 150 105 L 105 105 L 105 150 Q 105 170 85 170 Q 65 170 65 150 L 65 105 L 20 105 Q 0 105 0 85 Q 0 65 20 65 L 65 65 Z")' } },
    { name: 'Minus', color: '#5c8cff', css: { width:180, height:100, borderRadius:'20px' } },
    { name: 'Divide', color: '#ff7c9d', css: { width:170, height:170, borderRadius:'85px' } },
    { name: 'Equal', color: '#ffd45c', css: { width:180, height:160, clipPath:'polygon(0% 20%, 100% 20%, 100% 40%, 0% 40%, 0% 20%, 0% 60%, 100% 60%, 100% 80%, 0% 80%)' } },
    { name: 'Asterisk 2', color: '#ff5ce5', css: { width:180, height:180, clipPath:'polygon(40% 0%, 60% 0%, 60% 35%, 85% 20%, 95% 40%, 70% 55%, 95% 60%, 85% 80%, 60% 65%, 60% 100%, 40% 100%, 40% 65%, 15% 80%, 5% 60%, 30% 55%, 5% 40%, 15% 20%, 40% 35%)' } },
    { name: 'Tag 2', color: '#b8a0ff', css: { width:170, height:150, clipPath:'polygon(20% 0%, 100% 0%, 80% 100%, 0% 100%, 20% 50%)' } },
    { name: 'Grid 2x2', color: '#ff7c5c', css: { width:180, height:180, clipPath:'polygon(0% 0%, 45% 0%, 45% 45%, 0% 45%, 0% 0%, 55% 0%, 100% 0%, 100% 45%, 55% 45%, 55% 0%, 55% 55%, 100% 55%, 100% 100%, 55% 100%, 55% 55%, 45% 55%, 45% 100%, 0% 100%, 0% 55%, 45% 55%, 45% 45%)' } },
    { name: 'Grid 3x3', color: '#5c8cff', css: { width:180, height:180, clipPath:'polygon(0% 0%, 30% 0%, 30% 30%, 0% 30%, 35% 0%, 65% 0%, 65% 30%, 35% 30%, 70% 0%, 100% 0%, 100% 30%, 70% 30%, 0% 35%, 30% 35%, 30% 65%, 0% 65%, 35% 35%, 65% 35%, 65% 65%, 35% 65%, 70% 35%, 100% 35%, 100% 65%, 70% 65%, 0% 70%, 30% 70%, 30% 100%, 0% 100%, 35% 70%, 65% 70%, 65% 100%, 35% 100%, 70% 70%, 100% 70%, 100% 100%, 70% 100%)' } },

    /* ---------- MORE LETTERS ---------- */
    { name: 'Letter A', color: '#ff7c9d', css: { width:170, height:170, clipPath:'polygon(50% 0%, 100% 100%, 80% 100%, 68% 70%, 32% 70%, 20% 100%, 0% 100%)' } },
    { name: 'Letter B', color: '#7cff9e', css: { width:170, height:170, clipPath:'polygon(10% 0%, 60% 0%, 80% 10%, 90% 25%, 80% 45%, 60% 50%, 85% 60%, 95% 80%, 85% 95%, 60% 100%, 10% 100%, 10% 0%, 30% 20%, 30% 35%, 55% 35%, 60% 20%, 30% 20%, 30% 60%, 60% 60%, 70% 70%, 65% 80%, 30% 80%)' } },
    { name: 'Letter C 2', color: '#5cc8ff', css: { width:170, height:170, clipPath:'polygon(30% 0%, 100% 0%, 100% 20%, 35% 20%, 20% 35%, 20% 65%, 35% 80%, 100% 80%, 100% 100%, 30% 100%, 0% 70%, 0% 30%)' } },
    { name: 'Letter D', color: '#d4ff5c', css: { width:170, height:170, clipPath:'polygon(10% 0%, 50% 0%, 80% 15%, 95% 40%, 95% 60%, 80% 85%, 50% 100%, 10% 100%, 10% 0%, 30% 20%, 30% 80%, 50% 80%, 70% 65%, 70% 35%, 50% 20%)' } },
    { name: 'Letter E', color: '#ffd45c', css: { width:170, height:170, clipPath:'polygon(10% 0%, 100% 0%, 100% 20%, 30% 20%, 30% 40%, 85% 40%, 85% 60%, 30% 60%, 30% 80%, 100% 80%, 100% 100%, 10% 100%)' } },
    { name: 'Number 1', color: '#ff7cff', css: { width:150, height:190, clipPath:'polygon(30% 20%, 50% 0%, 70% 0%, 70% 100%, 50% 100%, 50% 20%, 30% 35%)' } },
    { name: 'Number 2', color: '#ff5c8c', css: { width:170, height:170, clipPath:'polygon(20% 20%, 50% 0%, 80% 20%, 80% 40%, 20% 100%, 100% 100%, 100% 80%, 50% 80%, 60% 60%, 60% 30%, 50% 25%, 30% 30%)' } },
    { name: 'Number 3', color: '#5cffe5', css: { width:170, height:170, clipPath:'polygon(20% 10%, 80% 10%, 80% 30%, 50% 30%, 50% 40%, 70% 40%, 85% 55%, 85% 80%, 70% 95%, 20% 95%, 20% 80%, 70% 80%, 70% 60%, 50% 60%, 50% 55%, 70% 55%, 70% 30%, 20% 30%)' } },
    { name: 'Letter F', color: '#7cff9e', css: { width:170, height:170, clipPath:'polygon(10% 0%, 100% 0%, 100% 20%, 30% 20%, 30% 40%, 85% 40%, 85% 60%, 30% 60%, 30% 100%, 10% 100%)' } },
    { name: 'Letter G', color: '#5cc8ff', css: { width:170, height:170, clipPath:'polygon(30% 0%, 100% 0%, 100% 20%, 35% 20%, 20% 35%, 20% 65%, 35% 80%, 65% 80%, 65% 60%, 50% 60%, 50% 45%, 85% 45%, 85% 100%, 30% 100%, 0% 70%, 0% 30%)' } },
    { name: 'Letter H 2', color: '#d4ff5c', css: { width:170, height:170, clipPath:'polygon(10% 0%, 30% 0%, 30% 40%, 70% 40%, 70% 0%, 90% 0%, 90% 100%, 70% 100%, 70% 60%, 30% 60%, 30% 100%, 10% 100%)' } },
    { name: 'Letter I', color: '#ffd45c', css: { width:100, height:170, clipPath:'polygon(0% 0%, 100% 0%, 100% 20%, 70% 20%, 70% 80%, 100% 80%, 100% 100%, 0% 100%, 0% 80%, 30% 80%, 30% 20%, 0% 20%)' } },
    { name: 'Letter K', color: '#ff7cff', css: { width:170, height:170, clipPath:'polygon(10% 0%, 30% 0%, 30% 40%, 65% 0%, 95% 0%, 55% 50%, 95% 100%, 65% 100%, 30% 60%, 30% 100%, 10% 100%)' } },
    { name: 'Letter L', color: '#ff5c8c', css: { width:170, height:170, clipPath:'polygon(10% 0%, 30% 0%, 30% 80%, 100% 80%, 100% 100%, 10% 100%)' } },
    { name: 'Letter N', color: '#5cffe5', css: { width:170, height:170, clipPath:'polygon(10% 0%, 30% 0%, 70% 60%, 70% 0%, 90% 0%, 90% 100%, 70% 100%, 30% 40%, 30% 100%, 10% 100%)' } },
    { name: 'Letter P', color: '#ffb04d', css: { width:170, height:170, clipPath:'polygon(10% 0%, 70% 0%, 90% 15%, 90% 45%, 70% 60%, 30% 60%, 30% 100%, 10% 100%)' } },
    { name: 'Number 4', color: '#7cffb8', css: { width:170, height:170, clipPath:'polygon(60% 0%, 80% 0%, 80% 60%, 100% 60%, 100% 80%, 80% 80%, 80% 100%, 60% 100%, 60% 80%, 0% 80%, 0% 60%, 60% 0%)' } },
    { name: 'Number 5', color: '#7cd4ff', css: { width:170, height:170, clipPath:'polygon(10% 0%, 90% 0%, 90% 20%, 30% 20%, 30% 40%, 70% 40%, 90% 55%, 90% 85%, 70% 100%, 10% 100%, 10% 80%, 70% 80%, 70% 60%, 10% 60%)' } },
    { name: 'Number 6', color: '#d4ff7c', css: { width:170, height:170, clipPath:'polygon(30% 0%, 90% 0%, 90% 20%, 40% 20%, 25% 40%, 25% 100%, 70% 100%, 85% 85%, 85% 60%, 70% 45%, 25% 45%, 25% 60%, 65% 60%, 65% 80%, 40% 80%, 45% 100%, 20% 100%, 5% 85%, 5% 35%)' } },

    /* ---------- TECH & OBJECTS ---------- */
    { name: 'Rocket', color: '#7c9dff', css: { width:130, height:200, clipPath:'path("M 65 0 Q 100 40 100 100 L 100 150 Q 100 170 85 175 L 85 200 L 70 190 L 70 175 L 60 175 L 60 190 L 45 200 L 45 175 Q 30 170 30 150 L 30 100 Q 30 40 65 0 Z")' } },
    { name: 'Satellite', color: '#a0a0ff', css: { width:200, height:160, clipPath:'polygon(0% 30%, 20% 30%, 20% 40%, 40% 40%, 40% 0%, 60% 0%, 60% 40%, 80% 40%, 80% 30%, 100% 30%, 100% 70%, 80% 70%, 80% 60%, 60% 60%, 60% 100%, 40% 100%, 40% 60%, 20% 60%, 20% 70%, 0% 70%)' } },
    { name: 'Chip', color: '#5cffd4', css: { width:180, height:180, clipPath:'polygon(15% 0%, 85% 0%, 85% 15%, 100% 15%, 100% 25%, 85% 25%, 85% 75%, 100% 75%, 100% 85%, 85% 85%, 85% 100%, 15% 100%, 15% 85%, 0% 85%, 0% 75%, 15% 75%, 15% 25%, 0% 25%, 0% 15%, 15% 15%)' } },
    { name: 'Battery', color: '#7cff9e', css: { width:180, height:100, clipPath:'polygon(0% 20%, 90% 20%, 90% 0%, 100% 0%, 100% 100%, 90% 100%, 90% 80%, 0% 80%, 0% 20%, 15% 35%, 15% 65%, 30% 65%, 30% 35%, 15% 35%, 45% 35%, 45% 65%, 60% 65%, 60% 35%, 45% 35%, 75% 35%, 75% 65%, 85% 65%, 85% 35%, 75% 35%)' } },
    { name: 'Wifi', color: '#5cc8ff', css: { width:180, height:150, clipPath:'path("M 90 40 Q 140 40 165 70 L 155 85 Q 130 60 90 60 Q 50 60 25 85 L 15 70 Q 40 40 90 40 Z M 90 80 Q 120 80 140 100 L 130 115 Q 110 100 90 100 Q 70 100 50 115 L 40 100 Q 60 80 90 80 Z M 90 120 Q 105 120 115 130 L 90 150 L 65 130 Q 75 120 90 120 Z")' } },
    { name: 'Microphone', color: '#ffb04d', css: { width:140, height:180, clipPath:'path("M 50 30 Q 50 0 70 0 Q 90 0 90 30 L 90 80 Q 90 110 70 110 Q 50 110 50 80 Z M 30 70 L 40 70 L 40 85 Q 40 120 70 130 L 70 150 L 30 150 L 30 165 L 110 165 L 110 150 L 70 150 L 70 130 Q 100 120 100 85 L 100 70 L 110 70 L 110 85 Q 110 135 70 148 L 70 148 L 70 150 L 30 150 L 30 148 Q 0 135 0 85 L 0 70 L 10 70 L 10 85 Q 10 120 30 130 L 30 148")' } },
    { name: 'Lock', color: '#a0a0ff', css: { width:150, height:190, clipPath:'path("M 30 80 Q 30 30 75 30 Q 120 30 120 80 L 120 90 L 100 90 L 100 80 Q 100 50 75 50 Q 50 50 50 80 L 50 90 L 30 90 Z M 20 90 L 130 90 L 130 180 L 20 180 Z")' } },
    { name: 'Key', color: '#ffd45c', css: { width:220, height:120, clipPath:'path("M 60 0 Q 120 0 120 60 Q 120 100 85 110 L 85 120 L 70 120 L 70 110 L 55 110 L 55 120 L 40 120 L 40 100 L 0 100 L 0 80 L 40 80 L 40 60 L 60 60 Q 40 40 40 30 Q 40 0 60 0 Z")' } },

    /* ---------- SPORTS & MISC ---------- */
    { name: 'Football', color: '#c8a05c', css: { width:180, height:180, borderRadius:'85px' } },
    { name: 'Basketball', color: '#ff7c4d', css: { width:170, height:170, borderRadius:'85px' } },
    { name: 'Baseball', color: '#ff5c8c', css: { width:170, height:170, borderRadius:'85px' } },
    { name: 'Tennis Ball', color: '#c8ff4d', css: { width:170, height:170, borderRadius:'85px' } },
    { name: 'Soccer Ball', color: '#ffffff', css: { width:170, height:170, borderRadius:'85px' } },
    { name: 'Ping Pong', color: '#ff9d4d', css: { width:150, height:150, borderRadius:'75px' } },
    { name: 'Volleyball', color: '#f5f5f5', css: { width:170, height:170, borderRadius:'85px' } },
    { name: 'Rugby', color: '#c8a05c', css: { width:190, height:130, borderRadius:'65px' } }
  ];

  /* =========================================================
     SHAPE TESTER
     ========================================================= */
  const testCanvas = document.createElement('canvas');
  testCanvas.width = 300;
  testCanvas.height = 300;
  const testCtx = testCanvas.getContext('2d');
  const testerCache = new Map();

  function roundRect(ctx, x, y, w, h, r) {
    r = Math.min(r, w / 2, h / 2);
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
  }

  function makeShapeTester(shape) {
    if (!shape || !shape.css) {
      return { isInside: function () { return false; } };
    }
    const key = (shape.name || '') + ':' + JSON.stringify(shape.css);
    if (testerCache.has(key)) return testerCache.get(key);

    const c = shape.css;
    const W = 300, H = 300;
    testCtx.clearRect(0, 0, W, H);
    testCtx.fillStyle = '#fff';
    const baseW = c.width || 170;
    const baseH = c.height || 170;
    const scale = Math.min(W / baseW, H / baseH) * 0.88;
    const w = baseW * scale, h = baseH * scale;
    const x = (W - w) / 2, y = (H - h) / 2;

    try {
      if (c.triangle) {
        testCtx.beginPath();
        testCtx.moveTo(x + w / 2, y);
        testCtx.lineTo(x + w, y + h);
        testCtx.lineTo(x, y + h);
        testCtx.closePath();
        testCtx.fill();
      } else if (c.rightTriangle) {
        testCtx.beginPath();
        testCtx.moveTo(x, y + h);
        testCtx.lineTo(x, y);
        testCtx.lineTo(x + w, y + h);
        testCtx.closePath();
        testCtx.fill();
      } else if (c.rotate45) {
        testCtx.save();
        testCtx.translate(x + w / 2, y + h / 2);
        testCtx.rotate(Math.PI / 4);
        testCtx.fillRect(-w / 2, -h / 2, w, h);
        testCtx.restore();
      } else if (c.clipPath) {
        const polyMatch = c.clipPath.match(/polygon\(([^)]+)\)/);
        if (polyMatch) {
          const pts = polyMatch[1].split(',').map(function (p) {
            const parts = p.trim().split(/\s+/).map(function (v) { return parseFloat(v); });
            return [x + (parts[0] / 100) * w, y + (parts[1] / 100) * h];
          });
          testCtx.beginPath();
          testCtx.moveTo(pts[0][0], pts[0][1]);
          for (let i = 1; i < pts.length; i++) testCtx.lineTo(pts[i][0], pts[i][1]);
          testCtx.closePath();
          testCtx.fill('evenodd');
        } else {
          const pathStr = c.clipPath.replace(/^path\(["']|["']\)$/g, '');
          try {
            const path = new Path2D(pathStr);
            testCtx.save();
            testCtx.translate(x, y);
            testCtx.scale(w / baseW, h / baseH);
            testCtx.fill(path, 'evenodd');
            testCtx.restore();
          } catch (e) {
            testCtx.fillRect(x, y, w, h);
          }
        }
      } else if (c.borderRadius !== undefined) {
        const r = (parseFloat(c.borderRadius) / Math.max(baseW, baseH)) * Math.max(w, h);
        testCtx.beginPath();
        roundRect(testCtx, x, y, w, h, r);
        testCtx.fill();
      } else {
        testCtx.fillRect(x, y, w, h);
      }
    } catch (e) {
      testCtx.fillRect(x, y, w, h);
    }

    const img = testCtx.getImageData(0, 0, W, H).data;
    const tester = {
      W: W,
      H: H,
      isInside: function (nx, ny) {
        const px = Math.floor(nx * W), py = Math.floor(ny * H);
        if (px < 0 || py < 0 || px >= W || py >= H) return false;
        return img[(py * W + px) * 4 + 3] > 128;
      }
    };
    if (testerCache.size < 800) testerCache.set(key, tester);
    return tester;
  }

  function hexToRgba(hex, a) {
    try {
      const h = String(hex || '#8b7cff').replace('#', '');
      const full = h.length === 3 ? h.split('').map(function (c) { return c + c; }).join('') : h;
      const n = parseInt(full, 16);
      return 'rgba(' + ((n >> 16) & 255) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
    } catch (e) { return 'rgba(139,124,255,' + a + ')'; }
  }

  function renderDots(canvas, shape, opts) {
    opts = opts || {};
    if (!canvas || !shape) return;
    const S = window.ShapeStudio || {};
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const dpr = Math.min(window.devicePixelRatio || 1, (S.qualityCfg && S.qualityCfg.dpr) || 1.25);
    const rect = canvas.getBoundingClientRect();
    const W = rect.width || canvas.width;
    const H = rect.height || canvas.height;
    if (W === 0 || H === 0) return;
    canvas.width = W * dpr;
    canvas.height = H * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);

    const color = opts.color || shape.color || '#8b7cff';
    const tester = makeShapeTester(shape);
    const dotCount = Math.floor((opts.dotCount || 2600) * ((S.qualityCfg && S.qualityCfg.dotMult) || 1));
    const dotSize = (opts.dotSize || 1.6) * (S.settings ? S.settings.particleSize : 1);
    const opacity = opts.opacity != null ? opts.opacity : 1;
    const glowAmt = (opts.glow != null ? opts.glow : 0.5) * (S.settings ? S.settings.glowStrength : 1) * ((S.qualityCfg && S.qualityCfg.glowMult) || 1);
    const ring = opts.ring || false;
    const brightness = S.settings ? S.settings.dotBrightness : 1;

    const pad = W * 0.06;
    const gridSize = Math.max(3, Math.floor(Math.sqrt(dotCount)));
    const cellW = (W - pad * 2) / gridSize;
    const cellH = (H - pad * 2) / gridSize;

    if (glowAmt > 0) {
      ctx.shadowBlur = Math.min(dotSize * 3 * glowAmt * 2, (S.qualityCfg && S.qualityCfg.shadowMax) || 8);
      ctx.shadowColor = color;
    }

    for (let gy = 0; gy < gridSize; gy++) {
      for (let gx = 0; gx < gridSize; gx++) {
        const jx = (Math.random() - 0.5) * cellW * 0.85;
        const jy = (Math.random() - 0.5) * cellH * 0.85;
        const px = pad + gx * cellW + cellW / 2 + jx;
        const py = pad + gy * cellH + cellH / 2 + jy;
        if (tester.isInside(px / W, py / H)) {
          const r = dotSize * (0.6 + Math.random() * 0.8);
          ctx.beginPath();
          ctx.arc(px, py, r, 0, Math.PI * 2);
          const d = Math.hypot(px / W - 0.5, py / H - 0.5) * 2;
          const alpha = Math.min(1, (0.55 + (1 - Math.min(d, 1)) * 0.45) * opacity * brightness);
          ctx.fillStyle = hexToRgba(color, alpha);
          ctx.fill();
        }
      }
    }
    if (ring) {
      ctx.shadowBlur = 0;
      ctx.beginPath();
      ctx.arc(W / 2, H / 2, Math.min(W, H) * 0.44, 0, Math.PI * 2);
      ctx.strokeStyle = hexToRgba(color, 0.25 * opacity);
      ctx.lineWidth = 2;
      ctx.stroke();
    }
  }

  /* =========================================================
     LIBRARY SHAPES (smaller curated set for library page)
     ========================================================= */
  const LIBRARY_SHAPES = [
    { name: 'Circle', color: '#4dd4ff', css: { width:170, height:170, borderRadius:85 } },
    { name: 'Star', color: '#ffd45c', css: { width:180, height:180, clipPath:'polygon(50% 0%, 61% 35%, 98% 35%, 68% 57%, 79% 91%, 50% 70%, 21% 91%, 32% 57%, 2% 35%, 39% 35%)' } },
    { name: 'Heart', color: '#ff4d6d', css: { width:170, height:160, clipPath:'path("M85 150 C10 95 10 30 50 20 C70 15 85 30 85 30 C85 30 100 15 120 20 C160 30 160 95 85 150 Z")' } },
    { name: 'Hexagon', color: '#4dffcc', css: { width:180, height:160, clipPath:'polygon(25% 0%, 75% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%)' } },
    { name: 'Pentagon', color: '#ff9d5c', css: { width:170, height:170, clipPath:'polygon(50% 0%, 100% 38%, 82% 100%, 18% 100%, 0% 38%)' } },
    { name: 'Diamond', color: '#b87cff', css: { width:150, height:150, clipPath:'polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)' } },
    { name: 'Cross', color: '#4dffd4', css: { width:170, height:170, clipPath:'polygon(35% 0%, 65% 0%, 65% 35%, 100% 35%, 100% 65%, 65% 65%, 65% 100%, 35% 100%, 35% 65%, 0% 65%, 0% 35%, 35% 35%)' } },
    { name: 'Moon', color: '#4dffcc', css: { width:180, height:180, clipPath:'path("M 90 10 A 80 80 0 1 0 90 170 A 60 60 0 1 1 90 10 Z")' } },
    { name: 'Triangle', color: '#9dff7c', css: { triangle: 1, width:170, height:150 } },
    { name: 'Shield', color: '#7c9dff', css: { width:160, height:180, clipPath:'path("M80 0 L160 30 L160 100 Q160 160 80 180 Q0 160 0 100 L0 30 Z")' } },
    { name: 'Octagon', color: '#4dffcc', css: { width:170, height:170, clipPath:'polygon(30% 0%, 70% 0%, 100% 30%, 100% 70%, 70% 100%, 30% 100%, 0% 70%, 0% 30%)' } },
    { name: 'Arrow', color: '#c8ff5c', css: { width:190, height:120, clipPath:'polygon(0% 30%, 70% 30%, 70% 0%, 100% 50%, 70% 100%, 70% 70%, 0% 70%)' } },
    { name: 'Leaf', color: '#9dff7c', css: { width:170, height:180, clipPath:'path("M 85 0 Q 170 40 170 110 Q 170 180 85 180 Q 0 180 0 110 Q 0 40 85 0")' } },
    { name: 'Drop', color: '#4dd4ff', css: { width:150, height:180, clipPath:'path("M75 0 Q150 90 150 130 Q150 180 75 180 Q0 180 0 130 Q0 90 75 0 Z")' } },
    { name: 'Gear', color: '#ff9d5c', css: { width:190, height:190, clipPath:'polygon(40% 0%, 60% 0%, 65% 20%, 80% 10%, 90% 30%, 100% 40%, 85% 55%, 100% 60%, 90% 80%, 80% 90%, 60% 85%, 55% 100%, 40% 100%, 35% 85%, 20% 90%, 10% 80%, 0% 60%, 15% 55%, 0% 40%, 10% 30%, 20% 10%, 35% 20%, 40% 0%)' } },
    { name: 'Crown', color: '#ff7c9d', css: { width:190, height:150, clipPath:'polygon(0% 100%, 0% 30%, 20% 50%, 25% 0%, 50% 40%, 75% 0%, 80% 50%, 100% 30%, 100% 100%)' } },
    { name: 'Trophy', color: '#ffd45c', css: { width:170, height:190, clipPath:'polygon(20% 0%, 80% 0%, 80% 20%, 100% 20%, 100% 50%, 80% 65%, 80% 75%, 55% 75%, 55% 85%, 75% 85%, 75% 100%, 25% 100%, 25% 85%, 45% 85%, 45% 75%, 20% 75%, 20% 65%, 0% 50%, 0% 20%, 20% 20%)' } },
    { name: 'Crystal', color: '#4dd4ff', css: { width:190, height:190, clipPath:'polygon(50% 0%, 80% 20%, 100% 60%, 70% 100%, 30% 100%, 0% 60%, 20% 20%)' } },
    { name: 'Spiral', color: '#b87cff', css: { width:190, height:190, clipPath:'polygon(50% 50%, 60% 40%, 70% 50%, 60% 65%, 40% 65%, 25% 50%, 25% 30%, 45% 15%, 70% 15%, 85% 35%, 85% 65%, 65% 85%, 35% 85%, 10% 60%, 10% 30%, 35% 5%)' } }
  ];

  /* =========================================================
     EXPORT
     ========================================================= */
  window.ShapeStudio = window.ShapeStudio || {};
  window.ShapeStudio.SHAPES = SHAPES;
  window.ShapeStudio.LIBRARY_SHAPES = LIBRARY_SHAPES;
  window.ShapeStudio.makeShapeTester = makeShapeTester;
  window.ShapeStudio.renderDots = renderDots;
  window.ShapeStudio.hexToRgba = hexToRgba;

})();