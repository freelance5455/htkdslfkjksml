/*
 * Report data bridge.
 *
 * The Report module does not change the main shell.
 * Input data can be supplied later through:
 *
 *   window.setReportData({
 *     name: "<name>",
 *     gender: "<gender>",
 *     year: <year>,
 *     month: <month>,
 *     day: <day>
 *   });
 *
 * The same data can also be supplied by URL parameters:
 * ?name=<name>&gender=<gender>&year=<year>&month=<month>&day=<day>
 */

(function () {
  "use strict";

  const nameEl = document.getElementById("report-name");
  const genderEl = document.getElementById("report-gender");
  const dobEl = document.getElementById("report-dob");
  const locationEl = document.getElementById("report-location");

  function formatDate(data) {
    const year = Number(data.year);
    const month = Number(data.month);
    const day = Number(data.day);

    if (!year || !month || !day) return null;

    const date = new Date(year, month - 1, day);
    if (
      date.getFullYear() !== year ||
      date.getMonth() !== month - 1 ||
      date.getDate() !== day
    ) {
      return null;
    }

    return new Intl.DateTimeFormat("en-GB", {
      day: "2-digit",
      month: "long",
      year: "numeric"
    }).format(date).toUpperCase();
  }

  function setReportData(data) {
    if (!data || typeof data !== "object") return;

    if (data.name) {
      nameEl.textContent = String(data.name).trim();
    }

    if (data.gender) {
      genderEl.textContent = String(data.gender).trim().toUpperCase();
    }

    const dob = formatDate(data);
    if (dob) {
      dobEl.textContent = dob;
    }

    if (data.location && locationEl) {
      const location = Array.isArray(data.location)
        ? data.location.filter(Boolean).join(" · ")
        : String(data.location).trim();
      if (location) locationEl.textContent = location;
    }
  }

  window.setReportData = setReportData;

  const params = new URLSearchParams(window.location.search);
  const urlData = {
    name: params.get("name"),
    gender: params.get("gender"),
    year: params.get("year"),
    month: params.get("month"),
    day: params.get("day")
  };

  if (urlData.name || urlData.gender || urlData.year) {
    setReportData(urlData);
  }
  window.addEventListener("message", function (event) {
    const data = event.data || {};
    if (data.type !== "BAZI_MASTER_RESULT" || !data.payload) return;

    const a2 = data.payload.A2 || {};
    const civilDate = a2.civilDate ? String(a2.civilDate) : "";
    setReportData({
      name: a2.name,
      gender: a2.sex,
      year: civilDate.slice(0, 4),
      month: civilDate.slice(5, 7),
      day: civilDate.slice(8, 10),
      location: a2.location
    });
  });

  window.parent.postMessage({ type: "REQUEST_BAZI_MASTER_RESULT" }, "*");

})();


(function setupJSONDownload() {
  "use strict";

  let latestMasterResult = null;
  let aiTemplatePromise = null;
  const button = document.getElementById("download-json-button");

  function loadAITemplate() {
    if (!aiTemplatePromise) {
      if (window.PenggilasAITemplate && typeof window.PenggilasAITemplate === "object") {
        aiTemplatePromise = Promise.resolve(window.PenggilasAITemplate);
      } else {
        const templateURL = new URL(
          "../../template/ai-result-template.json?v=20261008-v126",
          document.baseURI
        ).href;

        aiTemplatePromise = fetch(templateURL, {
          cache: "no-store"
        }).then(function (response) {
          if (!response.ok) {
            throw new Error(
              "AI result template could not be loaded: HTTP " + response.status
            );
          }
          return response.json();
        });
      }
    }

    return aiTemplatePromise;
  }

  async function downloadJSON() {
    if (!latestMasterResult) {
      window.alert("BaZi result belum tersedia. Jalankan perhitungan terlebih dahulu.");
      return;
    }

    if (!window.PenggilasJSONMapper ||
        typeof window.PenggilasJSONMapper.buildAIPresentationJSON !== "function") {
      window.alert("AI JSON mapper belum tersedia.");
      return;
    }

    let payload;

    try {
      const aiTemplate = await loadAITemplate();

      payload = window.PenggilasJSONMapper.buildAIPresentationJSON(
        latestMasterResult,
        aiTemplate
      );
    } catch (error) {
      console.error("[report] JSON export failed:", error);
      window.alert(
        "JSON tidak dapat dibuat: " +
        (error && error.message ? error.message : "unknown error")
      );
      return;
    }

    if (!payload || typeof payload !== "object") {
      window.alert("JSON tidak dapat dibuat: mapper tidak menghasilkan object.");
      return;
    }

    // Production boundary guard: never allow template/binding/source identifiers
    // to cross into the AI-facing download. The mapper remains responsible for
    // cleaning, while the report download path enforces the contract.
    if (typeof window.PenggilasJSONMapper.validateMachineReadableJSON === "function") {
      const validation = window.PenggilasJSONMapper.validateMachineReadableJSON(payload);
      if (!validation.pass) {
        console.error("[report] AI JSON contract violation:", validation.violations);
        window.alert(
          "JSON tidak dapat diunduh: ditemukan identifier internal pada output AI (" +
          validation.violations.join("; ") +
          ")."
        );
        return;
      }
    }

    const subjectName = payload.subject && payload.subject.name
      ? String(payload.subject.name).trim()
      : "";

    const chartId = payload.subject && payload.subject.chart_id
      ? String(payload.subject.chart_id).trim()
      : "BaZi_PENGGILAS";

    const safeName = (subjectName || chartId)
      .replace(/[^a-z0-9_-]+/gi, "_")
      .replace(/^_+|_+$/g, "");

    const filename =
      "BAZI_PENGGILAS_" +
      (safeName || "RESULT") +
      ".json";

    const blob = new Blob([
      JSON.stringify(payload, null, 2)
    ], { type: "application/json;charset=utf-8" });

    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();

    setTimeout(function () {
      URL.revokeObjectURL(url);
    }, 1000);
  }

  window.addEventListener("message", function (event) {
    const data = event.data || {};

    if (data.type === "BAZI_MASTER_RESULT" && data.payload) {
      latestMasterResult = data.payload;
    }
  });

  if (button) {
    button.addEventListener("click", function (event) {
      event.preventDefault();
      void downloadJSON();
    });
  }

  // Ask the application shell for the current result when the report iframe loads.
  window.parent.postMessage({ type: "REQUEST_BAZI_MASTER_RESULT" }, "*");
})();
