(function () {

    "use strict";


    /* =====================================================
       CHART MODULE
       MASTER RESULT → DISPLAY ONLY

       Profile      → BAZI_USER_DATA
       6 Chart Block → BAZI_MASTER_RESULT

       Tidak melakukan kalkulasi BaZi.
       Tidak mengubah jalur Input / Calculate.
    ===================================================== */


    /* =====================================================
       PROFILE
       SOURCE: BAZI_USER_DATA
    ===================================================== */

    function updateProfile(payload) {

        if (!payload) return;


        var nameEl =
            document.getElementById(
                "profile-name"
            );

        var datetimeEl =
            document.getElementById(
                "profile-datetime"
            );

        var placeEl =
            document.getElementById(
                "profile-place"
            );


        if (nameEl) {

            nameEl.textContent =
                payload.name || "—";

        }


        if (datetimeEl) {

            var dateText =
                payload.birthDate || "—";


            if (payload.birthDate) {

                var parts =
                    payload.birthDate.split("-");


                if (parts.length === 3) {

                    var date =
                        new Date(
                            Number(parts[0]),
                            Number(parts[1]) - 1,
                            Number(parts[2])
                        );


                    dateText =
                        date.toLocaleDateString(
                            "en-GB",
                            {
                                day: "numeric",
                                month: "long",
                                year: "numeric"
                            }
                        );

                }

            }


            if (payload.birthTime) {

                dateText +=
                    ", " + payload.birthTime;

            }


            datetimeEl.textContent =
                dateText;

        }


        if (placeEl) {

            var place = "—";


            if (
                payload.birthPlace &&
                payload.birthPlace.query
            ) {

                place =
                    payload.birthPlace.query;

            }


            placeEl.textContent =
                place;

        }

    }


    /* =====================================================
       HELPER
       "Gui | 癸" → "癸"
    ===================================================== */

    function extractHanzi(value) {

        if (!value) return "—";


        var text =
            String(value);


        var parts =
            text.split("|");


        if (parts.length > 1) {

            return parts[
                parts.length - 1
            ].trim();

        }


        return text.trim();

    }


    /* =====================================================
       HELPER
       "Gui Mao | 癸卯" → "Gui Mao"
    ===================================================== */

    function extractPinyin(value) {

        if (!value) return "—";


        var text =
            String(value);


        var parts =
            text.split("|");


        if (parts.length > 0) {

            return parts[0].trim();

        }


        return text.trim();

    }


    /* =====================================================
       FIVE ELEMENT COLOR SIGNAL
       UI ONLY — never calculates an element.

       Accepted incoming value example:
       "Fire | Huo | 火"
       or "Fire"
    ===================================================== */

    var ELEMENT_KEYS = [
        "wood",
        "fire",
        "earth",
        "metal",
        "water"
    ];

    function resolveElementKey(value) {

        if (!value) return "";

        var text = String(value).toLowerCase();

        for (var i = 0; i < ELEMENT_KEYS.length; i++) {
            if (text.indexOf(ELEMENT_KEYS[i]) !== -1) {
                return ELEMENT_KEYS[i];
            }
        }

        return "";
    }

    function applyElementClass(elementNode, elementValue) {

        if (!elementNode) return;

        ELEMENT_KEYS.forEach(function (key) {
            elementNode.classList.remove("element-" + key);
        });

        var key = resolveElementKey(elementValue);

        if (key) {
            elementNode.classList.add("element-" + key);
        }
    }

    function setElementTextColor(elementNode, elementValue) {
        applyElementClass(elementNode, elementValue);
    }


    /* =====================================================
       CHART ADDITION 01
       DAY MASTER
    ===================================================== */

    function updateDayMaster(
        dayMaster
    ) {

        if (!dayMaster) return;


        var hanziEl =
            document.getElementById(
                "day-master-hanzi"
            );

        var pinyinEl =
            document.getElementById(
                "day-master-pinyin"
            );

        var englishEl =
            document.getElementById(
                "day-master-english"
            );

        var card =
            document.querySelector(".day-master-card");

        applyElementClass(
            card,
            dayMaster.element
        );

        setElementTextColor(
            hanziEl,
            dayMaster.element
        );

        setElementTextColor(
            pinyinEl,
            dayMaster.element
        );

        setElementTextColor(
            englishEl,
            dayMaster.element
        );


        if (hanziEl) {

            hanziEl.textContent =
                dayMaster.hanzi || "—";

        }


        if (pinyinEl) {

            pinyinEl.textContent =
                dayMaster.pinyin || "—";

        }


        if (englishEl) {

            englishEl.textContent =
                dayMaster.english || "—";

        }

    }


    /* =====================================================
       CHART ADDITION 02
       FOUR PILLARS
    ===================================================== */

    function updateFourPillars(
        fourPillars
    ) {

        if (!fourPillars) return;


        var order = [
            "year",
            "month",
            "day",
            "hour"
        ];


        order.forEach(function (key) {

            var data =
                fourPillars[key];


            if (!data) return;


            var card =
                document.querySelector(
                    '.pillar-card[data-pillar="' +
                    key +
                    '"]'
                );


            if (!card) return;

            /* Element is supplied by Master Result/Core.
               This UI never derives it from the stem/branch. */
            applyElementClass(
                card,
                data.element
            );

            var stemEl = card.querySelector('[data-field="stem"]');
            var branchEl = card.querySelector('[data-field="branch"]');
            var stemMetaEl = card.querySelector('[data-field="stem-meta"]');
            var branchMetaEl = card.querySelector('[data-field="branch-meta"]');
            var pillarEl = card.querySelector('[data-field="pillar"]');
            var hiddenWrap = card.querySelector('[data-field="hidden-stems"]');
            var hiddenList = card.querySelector('[data-field="hidden-stems-list"]');

            var stemElement =
                data.stemElement || data.element;

            var branchElement =
                data.branchElement || data.element;

            var pillarElement = data.pillarElement || data.element;

            setElementTextColor(stemEl, stemElement);
            setElementTextColor(branchEl, branchElement);
            setElementTextColor(pillarEl, pillarElement);

            if (stemMetaEl) {
                stemMetaEl.textContent = data.stemLabel || extractPinyin(data.stem);
                setElementTextColor(stemMetaEl, stemElement);
            }

            if (branchMetaEl) {
                branchMetaEl.textContent = data.branchLabel || extractPinyin(data.branch);
                setElementTextColor(branchMetaEl, branchElement);
            }


            if (stemEl) {

                stemEl.textContent =
                    extractHanzi(
                        data.stem
                    );

            }


            if (branchEl) {

                branchEl.textContent =
                    extractHanzi(
                        data.branch
                    );

            }


            if (pillarEl) {
                pillarEl.textContent = data.elementLabel || "";
            }

            if (hiddenWrap && hiddenList) {
                var hidden = Array.isArray(data.hiddenStems) ? data.hiddenStems : [];
                hiddenList.innerHTML = "";

                if (hidden.length) {
                    hidden.forEach(function (item) {
                        var row = document.createElement("div");
                        row.className = "hidden-stem-item";

                        var hanzi = document.createElement("span");
                        hanzi.className = "hidden-stem-hanzi";
                        hanzi.textContent = item.hanzi || extractHanzi(item.stem);
                        setElementTextColor(hanzi, item.element);

                        var label = document.createElement("span");
                        label.className = "hidden-stem-label";
                        label.textContent = item.label || item.english || extractPinyin(item.stem);
                        setElementTextColor(label, item.element);

                        row.appendChild(hanzi);
                        row.appendChild(label);
                        hiddenList.appendChild(row);
                    });
                    hiddenWrap.hidden = false;
                } else {
                    hiddenWrap.hidden = true;
                }
            }

        });

    }


    /* =====================================================
       CHART ADDITION 03
       FIVE ELEMENTS
    ===================================================== */

    function updateFiveElements(
        fiveElements
    ) {

        if (!fiveElements) return;


        var elements = [
            "wood",
            "fire",
            "earth",
            "metal",
            "water"
        ];


        var values = [];


        elements.forEach(function (key) {

            var value =
                Number(
                    fiveElements[key]
                );


            if (
                !Number.isFinite(value)
            ) {

                value = 0;

            }


            values.push(value);


            var valueEl =
                document.querySelector(
                    '[data-element-value="' +
                    key +
                    '"]'
                );


            var fillEl =
                document.querySelector(
                    '[data-element-fill="' +
                    key +
                    '"]'
                );


            if (valueEl) {

                valueEl.textContent =
                    value + "%";

            }


            if (fillEl) {

                fillEl.style.width =
                    Math.max(
                        0,
                        Math.min(
                            100,
                            value
                        )
                    ) + "%";

            }

        });


        updateFiveElementsDonut(
            values
        );

    }


    /* =====================================================
       FIVE ELEMENTS DONUT
    ===================================================== */

    function updateFiveElementsDonut(
        values
    ) {

        var donut =
            document.getElementById(
                "five-elements-donut"
            );


        if (!donut) return;


        var total =
            values.reduce(
                function (sum, value) {
                    return sum + value;
                },
                0
            );


        if (total <= 0) return;


        var wood =
            values[0] / total * 360;

        var fire =
            values[1] / total * 360;

        var earth =
            values[2] / total * 360;

        var metal =
            values[3] / total * 360;

        var water =
            values[4] / total * 360;


        var start = 0;


        var woodEnd =
            start + wood;

        var fireEnd =
            woodEnd + fire;

        var earthEnd =
            fireEnd + earth;

        var metalEnd =
            earthEnd + metal;

        var waterEnd =
            metalEnd + water;


        donut.style.background =
            "conic-gradient(" +

            "#657a57 " +
            start + "deg " +
            woodEnd + "deg," +

            "#a65e49 " +
            woodEnd + "deg " +
            fireEnd + "deg," +

            "#96724d " +
            fireEnd + "deg " +
            earthEnd + "deg," +

            "#77766e " +
            earthEnd + "deg " +
            metalEnd + "deg," +

            "#587786 " +
            metalEnd + "deg " +
            waterEnd + "deg" +

            ")";

    }


    /* =====================================================
       CHART ADDITION 04
       YIN-YANG
    ===================================================== */

    function updateYinYang(
        yinYang
    ) {

        if (!yinYang) return;


        var yangEl =
            document.getElementById(
                "yang-value"
            );

        var yinEl =
            document.getElementById(
                "yin-value"
            );

        var card =
            document.querySelector(".yin-yang-card");

        applyElementClass(
            card,
            yinYang.element
        );


        if (yangEl) {

            yangEl.textContent =
                typeof yinYang.yang === "number"
                    ? yinYang.yang + "%"
                    : "—";

        }


        if (yinEl) {

            yinEl.textContent =
                typeof yinYang.yin === "number"
                    ? yinYang.yin + "%"
                    : "—";

        }

    }


    /* =====================================================
       CHART ADDITION 05
       TEN GODS
    ===================================================== */

    function updateTenGods(
        tenGods
    ) {

        if (!Array.isArray(tenGods)) {
            return;
        }


        var cards =
            document.querySelectorAll(
                ".ten-god-card"
            );


        tenGods.forEach(
            function (god, index) {

                var card =
                    cards[index];


                if (!card) return;


                var symbolEl =
                    card.querySelector(
                        ".ten-god-symbol"
                    );

                var englishEl =
                    card.querySelector(
                        "strong"
                    );

                var pinyinEl =
                    card.querySelector(
                        "small"
                    );

                applyElementClass(
                    card,
                    god.element
                );

                setElementTextColor(
                    symbolEl,
                    god.element
                );

                setElementTextColor(
                    englishEl,
                    god.element
                );

                setElementTextColor(
                    pinyinEl,
                    god.element
                );


                if (symbolEl) {

                    symbolEl.textContent =
                        god.hanzi || "—";

                }


                if (englishEl) {

                    englishEl.textContent =
                        god.english || "—";

                }


                if (pinyinEl) {

                    pinyinEl.textContent =
                        god.pinyin || "—";

                }

            }
        );

    }


    /* =====================================================
       CHART ADDITION 06
       DA YUN
    ===================================================== */

    function updateDaYun(
        daYun
    ) {

        if (!Array.isArray(daYun)) {
            return;
        }


        var cards =
            document.querySelectorAll(
                ".dayun-period"
            );


        daYun.forEach(
            function (period, index) {

                var card =
                    cards[index];


                if (!card) return;


                var ageEl =
                    card.querySelector(
                        "span"
                    );

                var pillarEl =
                    card.querySelector(
                        "strong"
                    );

                applyElementClass(
                    card,
                    period.element
                );

                setElementTextColor(
                    pillarEl,
                    period.element
                );


                if (ageEl) {

                    ageEl.textContent =
                        period.age || "—";

                }


                if (pillarEl) {

                    pillarEl.textContent =
                        extractHanzi(
                            period.pillar
                        );

                }

            }
        );

    }




    /* =====================================================
       CHART VIEW MODEL
       -----------------------------------------------------
       Source of truth: authoritative MasterResult.
       This projection exists only inside the Chart UI.
       It MUST NOT mutate MasterResult.
    ===================================================== */
    function splitLabel(str) {
        // "Geng (庚)" -> {pinyin:"Geng", hanzi:"庚"}
        if (!str) return { pinyin: "-", hanzi: "-" };
        const m = String(str).match(/^(.*?)\s*\(([^)]+)\)/);
        return m ? { pinyin: m[1].trim(), hanzi: m[2].trim() } : { pinyin: str, hanzi: str };
    }

    function pipe(pinyin, hanzi) {
        // Format "Pinyin | Hanzi" — cocok dengan extractHanzi/extractPinyin di chart.js (split "|")
        return pinyin + " | " + hanzi;
    }

    function buildDayMaster(A6) {
        const s = splitLabel(A6.dayStem);
        return {
            hanzi: s.hanzi,
            pinyin: s.pinyin,
            english: A6.polarity + " " + A6.element,
            element: A6.element
        };
    }

    function buildFourPillars(A4, A5) {
        const result = {};
        ["year", "month", "day", "hour"].forEach(function (key) {
            const p = A4[key];
            const stemS = splitLabel(p.stem);
            const branchS = splitLabel(p.branch);
            const hidden = A5[key];
            const hiddenStems = [];
            ["main", "mid", "res"].forEach(function (slot) {
                if (hidden[slot + "Stem"]) {
                    const hs = splitLabel(hidden[slot + "Stem"]);
                    hiddenStems.push({
                        hanzi: hs.hanzi,
                        stem: hs.pinyin,
                        label: hs.pinyin,
                        english: hidden[slot + "Elem"],
                        element: hidden[slot + "Elem"]
                    });
                }
            });
            result[key] = {
                stem: pipe(stemS.pinyin, stemS.hanzi),
                branch: pipe(branchS.pinyin, branchS.hanzi),
                stemLabel: stemS.pinyin,
                branchLabel: branchS.pinyin,
                element: p.stemElem,
                stemElement: p.stemElem,
                branchElement: p.branchElem,
                pillarElement: p.stemElem,
                elementLabel: p.stemElem,
                hiddenStems: hiddenStems
            };
        });
        return result;
    }

    function buildFiveElements(A8) {
        const keys = ["wood", "fire", "earth", "metal", "water"];
        const total = keys.reduce(function (sum, k) { return sum + A8[k].weight; }, 0);
        const result = {};
        keys.forEach(function (k) {
            result[k] = total > 0 ? Math.round((A8[k].weight / total) * 100) : 0;
        });
        return result;
    }

    function buildYinYang(A9, dmElement) {
        const total = A9.totalYang + A9.totalYin;
        return {
            yang: total > 0 ? Math.round((A9.totalYang / total) * 100) : 0,
            yin: total > 0 ? Math.round((A9.totalYin / total) * 100) : 0,
            element: dmElement
        };
    }

    function buildTenGods(A10_1) {
        // Urutan tetap 10 Batang (stemOrder) supaya konsisten dengan 10 kartu di chart.html
        const STEM_ORDER = [
            "jia", "yi", "bing", "ding", "wu",
            "ji", "geng", "xin", "ren", "gui"
        ];
        return STEM_ORDER.map(function (pinyinKey) {
            const info = A10_1[pinyinKey.toLowerCase()];
            const g = splitLabel(info.god);
            return {
                hanzi: g.hanzi,
                pinyin: g.pinyin,
                english: g.pinyin,
                element: info.elem
            };
        });
    }

    function buildDaYun(A14_2) {
        const keys = Object.keys(A14_2).sort(function (a, b) { return Number(a) - Number(b); });
        return keys.map(function (k) {
            const p = A14_2[k];
            const s = splitLabel(p.stem);
            const b = splitLabel(p.branch);
            return {
                age: p.startAge + "\u2013" + p.endAge,
                pillar: pipe(s.pinyin + " " + b.pinyin, s.hanzi + b.hanzi),
                element: p.stemElem
            };
        });
    }



    function buildChartViewModel(masterResult) {
        if (!masterResult || !masterResult.A4 || !masterResult.A5 || !masterResult.A6 ||
            !masterResult.A8 || !masterResult.A9 || !masterResult.A10_1 || !masterResult.A14_2) {
            return null;
        }

        return {
            dayMaster: buildDayMaster(masterResult.A6),
            fourPillars: buildFourPillars(masterResult.A4, masterResult.A5),
            fiveElements: buildFiveElements(masterResult.A8),
            yinYang: buildYinYang(masterResult.A9, masterResult.A6.element),
            tenGods: buildTenGods(masterResult.A10_1),
            daYun: buildDaYun(masterResult.A14_2)
        };
    }


    /* =====================================================
       MASTER RESULT → CHART
       
       MASTER_RESULT hanya mengisi 6 blok.
       PROFILE TIDAK DISENTUH.
    ===================================================== */

    function updateChartFromMasterResult(
        masterResult
    ) {

        if (!masterResult) return;


        const chartViewModel = buildChartViewModel(masterResult);
        if (!chartViewModel) return;

        /* 01 — DAY MASTER */
        updateDayMaster(chartViewModel.dayMaster);

        /* 02 — FOUR PILLARS */
        updateFourPillars(chartViewModel.fourPillars);

        /* 03 — FIVE ELEMENTS */
        updateFiveElements(chartViewModel.fiveElements);

        /* 04 — YIN-YANG */
        updateYinYang(chartViewModel.yinYang);

        /* 05 — TEN GODS */
        updateTenGods(chartViewModel.tenGods);

        /* 06 — DA YUN */
        updateDaYun(chartViewModel.daYun);

    }


    /* =====================================================
       RECEIVE MESSAGE FROM APP.JS
    ===================================================== */

    window.addEventListener(
        "message",
        function (event) {

            var message =
                event.data;


            if (!message) return;


            /* =============================================
               PROFILE
               SOURCE = BAZI_USER_DATA
            ============================================= */

            if (
                message.type ===
                "BAZI_USER_DATA"
            ) {

                updateProfile(
                    message.payload
                );

                return;

            }


            /* =============================================
               6 CHART BLOCKS
               SOURCE = BAZI_MASTER_RESULT
            ============================================= */

            if (
                message.type ===
                "BAZI_MASTER_RESULT"
            ) {

                updateChartFromMasterResult(
                    message.payload
                );

                return;

            }

        }
    );


    /* =====================================================
       INITIALIZATION
    ===================================================== */

    document.addEventListener(
        "DOMContentLoaded",
        function () {


            /* =============================================
               REQUEST USER INPUT
               
               → Profile
            ============================================= */

            if (
                window.parent &&
                window.parent !== window
            ) {

                window.parent.postMessage(
                    {
                        type:
                            "REQUEST_BAZI_USER_DATA"
                    },
                    "*"
                );


                /* =========================================
                   REQUEST MASTER RESULT
                   
                   → 6 Chart Blocks
                ========================================= */

                window.parent.postMessage(
                    {
                        type:
                            "REQUEST_BAZI_MASTER_RESULT"
                    },
                    "*"
                );

            }


            /* =============================================
               QUICK ACCESS
            ============================================= */

            document
                .querySelectorAll(
                    ".quick-card"
                )
                .forEach(
                    function (button) {

                        button.addEventListener(
                            "click",
                            function () {

                                var target =
                                    button.dataset
                                        .target;


                                var targetEl =
                                    document.getElementById(
                                        target
                                    );


                                if (targetEl) {

                                    targetEl.scrollIntoView(
                                        {
                                            behavior:
                                                "smooth",
                                            block:
                                                "start"
                                        }
                                    );

                                }

                            }
                        );

                    }
                );


            /* =============================================
               EDIT
            ============================================= */

            var editButton =
                document.querySelector(
                    ".edit-button"
                );


            if (editButton) {

                editButton.addEventListener(
                    "click",
                    function () {

                        window.parent.postMessage(
                            {
                                type:
                                    "BAZI_NAVIGATE",

                                screenId:
                                    "screen-input"
                            },
                            "*"
                        );

                    }
                );

            }

        }
    );

})();