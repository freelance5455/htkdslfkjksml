(function () {
    "use strict";

    var MONTHS = [
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    ];

    function pad2(value) {
        return String(value).padStart(2, "0");
    }

    function isValidDateParts(day, monthIndex, year) {
        if (day === "" || monthIndex === "" || year === "" ||
            day == null || monthIndex == null || year == null) {
            return false;
        }

        var numericDay = Number(day);
        var numericMonth = Number(monthIndex);
        var numericYear = Number(year);

        if (!numericDay || numericMonth < 0 || !numericYear) return false;
        if (numericYear < 1900) return false;
        if (numericMonth > 11) return false;

        var daysInMonth = new Date(numericYear, numericMonth + 1, 0).getDate();
        return numericDay >= 1 && numericDay <= daysInMonth;
    }

    function formatDate(day, monthIndex, year) {
        if (!isValidDateParts(day, monthIndex, year)) return "";

        // HTML <select> values are strings. Convert before arithmetic;
        // otherwise monthIndex + 1 becomes string concatenation
        // (e.g. "5" + 1 => "51"), producing an invalid YYYY-MM-DD.
        var numericDay = Number(day);
        var numericMonth = Number(monthIndex);
        var numericYear = Number(year);

        return String(numericYear) + "-" + pad2(numericMonth + 1) + "-" + pad2(numericDay);
    }

    function formatTime(hour, minute) {
        if (hour === "" || minute === "") return "";
        return pad2(hour) + ":" + pad2(minute);
    }

    function populateDateSelectors(daySelect, monthSelect, yearSelect) {
        var now = new Date();
        var currentYear = now.getFullYear();

        daySelect.innerHTML = '<option value="">Day</option>';
        for (var day = 1; day <= 31; day += 1) {
            daySelect.add(new Option(pad2(day), String(day)));
        }

        monthSelect.innerHTML = '<option value="">Month</option>';
        MONTHS.forEach(function (month, index) {
            monthSelect.add(new Option(month, String(index)));
        });

        yearSelect.innerHTML = '<option value="">Year</option>';
        for (var year = currentYear; year >= 1900; year -= 1) {
            yearSelect.add(new Option(String(year), String(year)));
        }
    }

    function populateTimeSelectors(hourSelect, minuteSelect) {
        hourSelect.innerHTML = '<option value="">Hour</option>';
        for (var hour = 0; hour <= 23; hour += 1) {
            hourSelect.add(new Option(pad2(hour), String(hour)));
        }

        minuteSelect.innerHTML = '<option value="">Minutes</option>';
        for (var minute = 0; minute <= 59; minute += 1) {
            minuteSelect.add(new Option(pad2(minute), String(minute)));
        }
    }

    function openNativePicker(input) {
        if (!input) return;
        try {
            if (typeof input.showPicker === "function") {
                input.showPicker();
                return;
            }
        } catch (error) {
            // Some browsers reject showPicker outside a direct user gesture.
        }
        input.focus();
        input.click();
    }

    function syncDateFromNativePicker(nativeDate, daySelect, monthSelect, yearSelect) {
        if (!nativeDate.value) return;
        var parts = nativeDate.value.split("-");
        if (parts.length !== 3) return;
        yearSelect.value = parts[0];
        monthSelect.value = String(Number(parts[1]) - 1);
        daySelect.value = String(Number(parts[2]));
    }

    function syncTimeFromNativePicker(nativeTime, hourSelect, minuteSelect) {
        if (!nativeTime.value) return;
        var parts = nativeTime.value.split(":");
        if (parts.length < 2) return;
        hourSelect.value = String(Number(parts[0]));
        minuteSelect.value = String(Number(parts[1]));
    }

    document.addEventListener("DOMContentLoaded", function () {
        var gender = "Male";

        var nameInput = document.getElementById("name-input");
        var birthDay = document.getElementById("birth-day");
        var birthMonth = document.getElementById("birth-month");
        var birthYear = document.getElementById("birth-year");
        var birthDatePicker = document.getElementById("birth-date-picker");
        var birthHour = document.getElementById("birth-hour");
        var birthMinute = document.getElementById("birth-minute");
        var birthTimePicker = document.getElementById("birth-time-picker");
        var placeInput = document.getElementById("place-input");
        var locationSuggestions = document.getElementById("location-suggestions");
        var locationStatus = document.getElementById("location-status");
        var calculateButton = document.getElementById("calculate-button");

        populateDateSelectors(birthDay, birthMonth, birthYear);
        populateTimeSelectors(birthHour, birthMinute);

        document.querySelectorAll(".gender-btn").forEach(function (button) {
            button.addEventListener("click", function () {
                gender = button.dataset.gender;
                document.querySelectorAll(".gender-btn").forEach(function (item) {
                    item.classList.toggle("active", item === button);
                });
            });
        });

        function updateNativeDate() {
            var value = formatDate(
                birthDay.value,
                birthMonth.value,
                birthYear.value
            );
            birthDatePicker.value = value;
        }

        function updateNativeTime() {
            birthTimePicker.value = formatTime(
                birthHour.value,
                birthMinute.value
            );
        }

        [birthDay, birthMonth, birthYear].forEach(function (select) {
            select.addEventListener("change", updateNativeDate);
        });

        [birthHour, birthMinute].forEach(function (select) {
            select.addEventListener("change", updateNativeTime);
        });

        birthDatePicker.addEventListener("change", function () {
            syncDateFromNativePicker(birthDatePicker, birthDay, birthMonth, birthYear);
        });

        birthTimePicker.addEventListener("change", function () {
            syncTimeFromNativePicker(birthTimePicker, birthHour, birthMinute);
        });

        document.getElementById("open-date-picker").addEventListener("click", function () {
            updateNativeDate();
            openNativePicker(birthDatePicker);
        });

        document.getElementById("open-time-picker").addEventListener("click", function () {
            updateNativeTime();
            openNativePicker(birthTimePicker);
        });

        /* =====================================================
           ONLINE BIRTH-PLACE CANDIDATES
           Open-Meteo Geocoding is used for the picker only.
           The selected candidate is converted to a qualified
           query so the engine receives city + admin + country.
        ===================================================== */
        var locationTimer = null;
        var locationRequestId = 0;
        var selectedLocation = null;

        function notifyParentResize() {
            if (window.parent && window.parent !== window) {
                window.parent.postMessage({ type: "BAZI_INPUT_RESIZE" }, "*");
            }
        }

        function clearLocationSuggestions() {
            locationSuggestions.innerHTML = "";
            locationSuggestions.hidden = true;
            notifyParentResize();
        }

        function renderLocationState(message) {
            locationSuggestions.innerHTML =
                '<div class="location-search-state">' +
                escapeHtml(message) +
                '</div>';
            locationSuggestions.hidden = false;
            notifyParentResize();
        }

        function formatLocationQuery(item) {
            return [item.name, item.admin1, item.country]
                .filter(Boolean)
                .join(", ");
        }

        function normalizeLocationResults(results) {
            var seen = Object.create(null);
            var normalized = [];

            results.forEach(function (item) {
                if (!item || !item.name) return;

                var key = [
                    item.name,
                    item.admin1,
                    item.country,
                    item.latitude,
                    item.longitude
                ].map(function (value) {
                    return String(value == null ? "" : value).trim().toLowerCase();
                }).join("|");

                if (seen[key]) return;
                seen[key] = true;
                normalized.push(item);
            });

            return normalized;
        }

        function renderLocationSuggestions(results) {
            locationSuggestions.innerHTML = "";

            normalizeLocationResults(results).slice(0, 10).forEach(function (item) {
                var button = document.createElement("button");
                button.type = "button";
                button.className = "location-suggestion";
                button.setAttribute("role", "option");
                button.innerHTML =
                    "<strong>" + escapeHtml(item.name || "") + "</strong>" +
                    "<span>" + escapeHtml([
                        item.admin1,
                        item.country
                    ].filter(Boolean).join(", ")) + "</span>";

                button.addEventListener("click", function () {
                    selectedLocation = item;
                    placeInput.value = formatLocationQuery(item);
                    placeInput.dataset.locationSelected = "true";
                    locationStatus.textContent = "Selected location: " + placeInput.value;
                    clearLocationSuggestions();
                });

                locationSuggestions.appendChild(button);
            });

            locationSuggestions.hidden = locationSuggestions.children.length === 0;
            notifyParentResize();
        }

        function escapeHtml(value) {
            return String(value)
                .replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;")
                .replace(/"/g, "&quot;")
                .replace(/'/g, "&#039;");
        }

        function searchLocations(query) {
            var trimmed = query.trim();
            if (trimmed.length < 2) {
                clearLocationSuggestions();
                locationStatus.textContent = "Type at least 2 characters to search.";
                return;
            }

            var requestId = ++locationRequestId;
            locationStatus.textContent = "Searching locations…";
            renderLocationState("Searching locations…");

            fetch(
                "https://geocoding-api.open-meteo.com/v1/search?name=" +
                encodeURIComponent(trimmed) +
                "&count=10&language=en&format=json",
                { headers: { "Accept": "application/json" } }
            )
                .then(function (response) {
                    if (!response.ok) throw new Error("Location search failed");
                    return response.json();
                })
                .then(function (payload) {
                    if (requestId !== locationRequestId) return;
                    var results = Array.isArray(payload.results) ? payload.results : [];
                    renderLocationSuggestions(results);
                    locationStatus.textContent = results.length
                        ? "Choose the exact city / province / country."
                        : "No location candidates found.";
                })
                .catch(function () {
                    if (requestId !== locationRequestId) return;
                    renderLocationState("Online location search is unavailable. Check your connection and try again.");
                    locationStatus.textContent = "Location search unavailable — a candidate must be selected before calculation.";
                });
        }

        placeInput.addEventListener("input", function () {
            selectedLocation = null;
            placeInput.dataset.locationSelected = "false";
            clearTimeout(locationTimer);
            clearLocationSuggestions();

            locationTimer = setTimeout(function () {
                searchLocations(placeInput.value);
            }, 350);
        });

        placeInput.addEventListener("focus", function () {
            if (placeInput.value.trim().length >= 2 && !selectedLocation) {
                searchLocations(placeInput.value);
            }
        });

        document.addEventListener("click", function (event) {
            if (!event.target.closest(".location-search-wrap")) {
                clearLocationSuggestions();
            }
        });

        window.addEventListener("message", function (event) {
            if (!event.data || event.data.type !== "BAZI_CALCULATION_ERROR") return;
            var message = event.data.payload && event.data.payload.message
                ? event.data.payload.message
                : "BaZi calculation failed.";
            locationStatus.textContent = "Calculation could not be completed: " + message;
        });

        if (!calculateButton) {
            console.error("calculate-button tidak ditemukan.");
            return;
        }

        calculateButton.addEventListener("click", function () {
            var name = nameInput.value.trim();
            var date = formatDate(
                birthDay.value,
                birthMonth.value,
                birthYear.value
            );
            var time = formatTime(birthHour.value, birthMinute.value);
            var place = placeInput.value.trim();

            if (!name) {
                nameInput.focus();
                return;
            }

            if (!date) {
                locationStatus.textContent = "";
                birthDay.focus();
                return;
            }

            if (!time) {
                birthHour.focus();
                return;
            }

            if (!place) {
                placeInput.focus();
                return;
            }

            if (!selectedLocation) {
                placeInput.focus();
                locationStatus.textContent = "Choose a location candidate before calculating.";
                searchLocations(placeInput.value);
                return;
            }

            var data = {
                name: name,
                gender: gender,
                birthDate: date,
                birthTime: time,
                birthPlace: {
                    query: place,
                    selected: selectedLocation ? {
                        name: selectedLocation.name || "",
                        admin1: selectedLocation.admin1 || "",
                        country: selectedLocation.country || "",
                        latitude: selectedLocation.latitude,
                        longitude: selectedLocation.longitude,
                        timezone: selectedLocation.timezone || ""
                    } : null
                }
            };

            window.parent.postMessage(
                {
                    type: "BAZI_NAVIGATE",
                    screenId: "screen-chart",
                    payload: data
                },
                "*"
            );
        });
    });

})();
