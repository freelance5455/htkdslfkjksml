// Analysis UI module logic
