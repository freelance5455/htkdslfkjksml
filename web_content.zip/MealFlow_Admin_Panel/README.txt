MEALFLOW ADMIN PANEL

Firebase project: mealflow-56118

IMPORTANT:
This panel is intentionally separate from the main MealFlow app.
It only allows users whose Firebase Auth UID exists under /admins/<uid>.

To authorize an admin:
1. Create/sign in the admin account in Firebase Authentication.
2. Copy that account's UID.
3. In Realtime Database create:
   admins
     UID_HERE: true

Example:
admins
  abc123UID: true

Do NOT put a normal user's UID here.

Suggested Realtime Database rules are in firebase-rules.json.
