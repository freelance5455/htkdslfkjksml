IQ Test: Can You Pass It? — Ajit

HOW TO PLAY
1. Open index.html in Chrome or another modern browser.
2. Tap START GAME and play as usual.
3. When you clear a level, the next level unlocks and progress is saved automatically.
4. Close and reopen the game in the same browser on the same device; it resumes at your highest unlocked level.

IMPORTANT
- Progress uses browser localStorage on this device/browser.
- Do not clear browser site data or use private/incognito mode if you want to keep progress.
- The game is an HTML web game, not an APK. You can import index.html into a compatible web-game wrapper.
