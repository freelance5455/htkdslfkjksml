# OLDX AI: APK banane ke steps

## Step 1: Server (AI ke liye)
1. Free host lo (Render.com ya Railway.app). `server` folder upload karo.
2. Environment variables daalo: `ANTHROPIC_API_KEY` (apni key), `APP_TOKEN` (koi lamba random text), baaki `.env.example` jaise.
3. Start command: `npm start`. Deploy hone par aapko ek link milega, jaise https://oldx.onrender.com
4. Browser me wo link kholo. "OLDX AI server is running" dikhna chahiye.

## Step 2: App me server ka link daalo
`www/index.html` kholo, shuru me ye 2 cheez badlo:
- `SERVER_URL` = aapka server link (Step 1 wala)
- `APP_TOKEN` = wahi text jo server me daala

## Step 3: APK banao (PC par, Node 18+ aur Android Studio chahiye)
```
npm install
npx cap add android
npx cap sync
npx cap open android
```
Android Studio me: Build > Build APK(s). APK phone me install karo.

## Dhyan rakho
- API key kabhi `www` folder me mat daalo. Sirf server me rahe.
- Login aur database abhi nahi hai: Premium sirf usi phone me yaad rehta hai.
- Payment check abhi bhi screenshot se hota hai (nakli ho sakta hai). Ek UTR sirf ek baar chalta hai (server rokta hai).
- Chart image "Save" button Android me kaam na kare to batao, plugin lagana padega.
