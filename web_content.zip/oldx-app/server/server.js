// OLDX AI server: keeps your API key secret and talks to Claude for the app.
const express = require("express"), cors = require("cors"), fs = require("fs");
const app = express();
app.use(cors());
app.use(express.json({ limit: "12mb" }));

const KEY = process.env.ANTHROPIC_API_KEY, TOKEN = process.env.APP_TOKEN || "";
const MODELS = { complex: process.env.MODEL_COMPLEX || "claude-sonnet-5-5", default: process.env.MODEL_COMPLEX || "claude-sonnet-5-5", quick: process.env.MODEL_QUICK || "claude-haiku-5-5" };

// simple rate limit: 30 requests per 10 minutes per IP
const hits = new Map();
function limited(ip) { const now = Date.now(), a = (hits.get(ip) || []).filter(t => now - t < 600000); a.push(now); hits.set(ip, a); return a.length > 30; }

app.get("/", (_, res) => res.send("OLDX AI server is running"));

app.post("/ai", async (req, res) => {
  if (TOKEN && req.get("x-app-token") !== TOKEN) return res.status(401).json({ error: "unauthorized" });
  if (limited(req.ip)) return res.status(429).json({ error: "too many requests" });
  if (!KEY) return res.status(500).json({ error: "server key missing" });
  try {
    const { input, images = [], tier = "default" } = req.body;
    let messages = typeof input === "string" ? [{ role: "user", content: input }] : (input || []);
    if (images.length && messages.length) {
      const last = messages[messages.length - 1];
      const blocks = images.slice(0, 3).map(d => { const m = /^data:(.+?);base64,(.+)$/.exec(d); return { type: "image", source: { type: "base64", media_type: m ? m[1] : "image/jpeg", data: m ? m[2] : d } }; });
      last.content = [...blocks, { type: "text", text: String(last.content) }];
    }
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: MODELS[tier] || MODELS.default, max_tokens: 2000, messages })
    });
    const j = await r.json();
    if (!r.ok) return res.status(502).json({ error: (j.error && j.error.message) || "AI error" });
    res.json({ text: (j.content || []).filter(c => c.type === "text").map(c => c.text).join("\n") });
  } catch (e) { res.status(500).json({ error: String(e.message || e) }); }
});

// one payment (UTR) can unlock Premium only once
const FILE = "./used-utr.json";
const used = fs.existsSync(FILE) ? JSON.parse(fs.readFileSync(FILE, "utf8")) : {};
app.post("/claim", (req, res) => {
  if (TOKEN && req.get("x-app-token") !== TOKEN) return res.status(401).json({ error: "unauthorized" });
  const { utr, device } = req.body || {};
  if (!utr || String(utr).length < 8) return res.status(400).json({ error: "bad utr" });
  if (used[utr] && used[utr] !== device) return res.status(409).json({ error: "already used" });
  used[utr] = device || "x"; fs.writeFileSync(FILE, JSON.stringify(used)); res.json({ ok: true });
});

app.listen(process.env.PORT || 3000, () => console.log("OLDX AI server on port " + (process.env.PORT || 3000)));
