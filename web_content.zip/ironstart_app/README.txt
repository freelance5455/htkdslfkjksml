IRONSTART - REVISED PACKAGE FOR ZIP-TO-APK CONVERTERS

FIX:
The converter error showed it was trying to load:
https://appassets.androidplatform.net/web/index.html
The previous ZIP did not include a web/ directory, so this package now includes:
web/index.html
web/manifest.json
web/sw.js

HOW TO USE WITH A ZIP-TO-APK CONVERTER:
1. Import this revised ZIP into the same converter.
2. If the converter asks for a start page / entry file, select web/index.html.
3. If it asks for a web root folder, select web/ (not android/ or www/).
4. Build a NEW APK and install that new APK. Updating the ZIP alone does not change the APK already installed.

ANDROID STUDIO PROJECT:
The android/ folder is a separate native Android Studio project. Open the android/ folder in Android Studio and build it there if you want to build the native project instead of using a ZIP-to-APK converter.

The converter's exact configuration may vary. This ZIP adds the exact web/index.html path shown in the error, but if the converter still fails, send its name or a screenshot of its import/settings screen.
