IRONSTART — BEGINNER HOME WORKOUT APP

This package includes:
1) www/index.html — working mobile web app. It includes the workout plan, session checklist, progress history, 8-week plan, and export feature. Workout records are stored locally in the browser/device.
2) android/ — Android Studio project source for a native Android APK wrapper around the same app.

IMPORTANT APK NOTE
This environment does not have the Android SDK or Gradle installed, so I could not compile or verify a signed .apk here. The Android project source is ready to open in Android Studio on a computer with Android SDK 35 and a compatible Gradle/JDK setup. In Android Studio choose Build > Build APK(s). The debug APK is normally written to app/build/outputs/apk/debug/app-debug.apk.

QUICK PREVIEW
Open www/index.html in a modern browser to try the app. Some browsers restrict local storage for file:// pages; for reliable save/history behavior, serve the www folder from a local web server or build the Android project. Data is local to the app/browser and is not synced.

SAFETY
The plan is for a beginner. Use controlled reps, secure the backpack, and stop if you feel sharp pain, dizziness, or unusual symptoms.
