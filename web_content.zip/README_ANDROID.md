# FlowSpace — Android offline/WebView

## Carregamento local do aplicativo

A tela inicial está empacotada em `app/src/main/assets/web/index.html`. O `MainActivity` usa `WebViewAssetLoader` para mapear os assets do APK para a origem virtual local:

`https://appassets.androidplatform.net/assets/web/index.html`

Essa URL não é carregada da internet: o `WebViewAssetLoader` responde diretamente com os arquivos dentro de `app/src/main/assets/`. O caminho `/assets/web/index.html` é intencional; `/web/index.html` não é o caminho correto para esse mapeamento. CSS, JavaScript embutido, `manifest.json`, `sw.js` e ícones estão dentro de `app/src/main/assets/web/`.

A tela de login e a navegação abrem offline. Conteúdos externos (por exemplo, YouTube, links do Zoom e áudios hospedados fora do APK) precisam de internet para serem reproduzidos, mas não são necessários para abrir o aplicativo.

## Áudio e permissões

A gravação de Speaking usa `MediaRecorder` do navegador. O app declara `RECORD_AUDIO` e solicita a permissão Android quando o aluno inicia uma gravação.

## Funcionalidades e limites do protótipo

- Dados, perfis, cobranças demonstrativas e entregas ficam no `localStorage` deste dispositivo/WebView; não são sincronizados automaticamente entre aparelhos.
- O código Pix é demonstrativo e não processa pagamentos reais.
- O convite por e-mail prepara uma mensagem padrão no aplicativo de e-mail do dispositivo com o código da turma. Por ser um app offline sem servidor de e-mail, o usuário precisa confirmar o envio no aplicativo de e-mail; não existe envio automático em segundo plano.
- Para envio automático de e-mails e sincronização de dados entre aparelhos, seria necessário um backend/serviço de e-mail autenticado.

## Gerar APK

1. Abra a pasta do projeto no Android Studio.
2. Aguarde o Gradle sincronizar.
3. Execute em um emulador/dispositivo ou use `Build > Build APK(s)`.

O projeto usa Android Gradle Plugin 8.7.3, compileSdk 35 e AndroidX WebKit.
