# MasterFlow Trading Android v4 — IDX + US

Versi ini hanya menyediakan dua pasar: Indonesia (IDX/BEI) dan Amerika Serikat (US). Hong Kong, Jepang, Singapura, dan Global dihapus dari UI dan daftar saham.

US menggunakan Twelve Data. IDX tetap menggunakan konfigurasi provider IDX yang tersedia di project. API key tidak dibundel ke APK.
