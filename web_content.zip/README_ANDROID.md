# VIBA Artes — Proyecto Android

Este proyecto convierte el prototipo funcional VIBA Artes V1 en una aplicación Android instalable.

## Qué incluye
- Diseño VIBA Artes azul/navy.
- Administrador principal.
- Profesor/administrador.
- Padre/estudiante.
- Alumnos, profesores, planes y clases.
- Descuento manual Sí/No.
- Historial y notificaciones internas.
- Datos locales mediante localStorage.

## Abrir y generar APK
1. Instala Android Studio en un computador.
2. Abre esta carpeta como proyecto.
3. Espera a que Gradle sincronice y descargue las herramientas necesarias.
4. Ve a Build > Build APK(s).
5. El APK de prueba quedará en:
   app/build/outputs/apk/debug/app-debug.apk

## Importante
Esta APK es la versión de prueba local. Los datos todavía quedan guardados en el teléfono.
La versión real multiusuario necesita backend (Firebase o Supabase), autenticación, base de datos compartida y notificaciones push FCM/APNs.

## Versión
1.0 — VIBA Artes
