# MasterFlow Trading — Android Ready

Project ini membungkus versi **NO_BACKEND** MasterFlow Trading ke Android WebView.

## Cara build APK
1. Install Android Studio.
2. Open folder `MasterFlowTrading_ANDROID_READY`.
3. Tunggu Gradle sync selesai.
4. Pilih **Build > Build APK(s)**.
5. APK debug biasanya ada di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan
- Tidak ada backend.
- API key Twelve Data dimasukkan dari aplikasi dan disimpan lokal di perangkat.
- Aplikasi membutuhkan internet untuk mengambil data Twelve Data.
- Tidak ada auto-trading.
