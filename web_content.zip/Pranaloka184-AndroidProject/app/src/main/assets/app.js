let KNOWLEDGE_DB = { topics: [], quizzes: [] };
let currentTopic = null;
let currentQuizIndex = 0;
let userState = {
    learnedTopics: JSON.parse(localStorage.getItem('prana_learned') || '[]'),
    quizScore: parseInt(localStorage.getItem('prana_score') || '0', 10),
    chatHistory: JSON.parse(localStorage.getItem('prana_history') || '[]'),
    theme: localStorage.getItem('prana_theme') || 'light'
};

document.addEventListener('DOMContentLoaded', async () => {
    applyTheme(userState.theme);
    updateStatsUI();

    try {
        const res = await fetch('database.json');
        KNOWLEDGE_DB = await res.json();
    } catch (e) {
        console.error("Gagal memuat database lokal:", e);
    }

    setTimeout(() => {
        document.getElementById('splash-screen').classList.add('fade-out');
    }, 1500);

    if (userState.chatHistory.length > 0) {
        userState.chatHistory.forEach(item => renderMessage(item.sender, item.html, item.rawText, false));
    } else {
        const welcomeHtml = `Halo! Saya <b>Mentor Pranaloka 184</b> ✦<br><br>Saya siap menemani Anda mempelajari arsitektur etika AI lintas peradaban <b>100% tanpa kuota internet</b>. Mau mulai dari pilar mana hari ini?`;
        addBotMessage(welcomeHtml, "Halo! Saya Mentor Pranaloka 184. Saya siap menemani Anda belajar etika AI lintas peradaban secara offline.");
    }

    setQuickChips(["Apa itu Pranaloka 184?", "Mulai Pilar 1", "Mode Kuis 🎯"]);

    const inputEl = document.getElementById('user-input');
    inputEl.addEventListener('keypress', (e) => { if (e.key === 'Enter') handleSend(); });
    window.addEventListener('resize', scrollToBottom);
});

function levenshtein(a, b) {
    const matrix = Array.from({ length: b.length + 1 }, (_, i) => [i]);
    for (let j = 0; j <= a.length; j++) matrix[0][j] = j;
    for (let i = 1; i <= b.length; i++) {
        for (let j = 1; j <= a.length; j++) {
            matrix[i][j] = b[i - 1] === a[j - 1]
                ? matrix[i - 1][j - 1]
                : Math.min(matrix[i - 1][j - 1] + 1, matrix[i][j - 1] + 1, matrix[i - 1][j] + 1);
        }
    }
    return matrix[b.length][a.length];
}

function findBestTopic(query) {
    const cleanWords = query.toLowerCase().replace(/[^a-z0-9\s]/g, '').split(/\s+/);
    let bestMatch = null;
    let highestScore = 0;

    KNOWLEDGE_DB.topics.forEach(topic => {
        let score = 0;
        topic.keywords.forEach(kw => {
            if (query.toLowerCase().includes(kw)) score += 3;
            cleanWords.forEach(w => {
                if (w.length > 3 && levenshtein(w, kw) <= 1) score += 2;
            });
        });
        if (score > highestScore) {
            highestScore = score;
            bestMatch = topic;
        }
    });
    return highestScore >= 2 ? bestMatch : null;
}

function handleSend(customText = null) {
    const inputEl = document.getElementById('user-input');
    const text = (customText || inputEl.value).trim();
    if (!text) return;

    haptic(25);
    addUserMessage(text);
    if (!customText) inputEl.value = '';

    showTyping(true);
    setTimeout(() => {
        showTyping(false);
        processUserIntent(text);
    }, 650);
}

function processUserIntent(text) {
    const q = text.toLowerCase();

    if (q.includes('kuis') || q.includes('tes') || q.includes('soal')) {
        startQuiz();
        return;
    }

    if ((q.includes('analogi') || q.includes('contoh')) && currentTopic) {
        const html = `💡 <b>Analogi ${currentTopic.title}:</b><br><div class="ml-block">${currentTopic.analogy}</div>`;
        addBotMessage(html, `Analogi ${currentTopic.title}. ${currentTopic.analogy}`);
        setQuickChips(["Lanjut materi berikutnya", "Tes pemahaman saya 🎯"]);
        return;
    }

    if (q.includes('lanjut') && currentTopic) {
        selectTopic(currentTopic.next_topic);
        return;
    }

    if (q.includes('pranaloka') || q.includes('apa itu')) {
        const html = `<b>Pranaloka 184</b> (5 Peradaban dalam 1 Nafas) adalah sistem etika AI yang menyatukan <b>99 Asmaul Husna</b>, <b>29 Hijaiyah</b>, <b>20 Hanacaraka</b>, <b>26 Abjad Latin</b>, dan <b>10 Angka (0-9)</b>.<br><div class="ml-block"><div class="ml-title">Tujuan Utama</div>Memastikan kecerdasan buatan bekerja dengan moral luhur, logika teliti, dan adab yang santun.</div>`;
        addBotMessage(html, "Pranaloka 184 adalah sistem etika AI yang menyatukan lima peradaban dalam satu nafas komputasi.");
        setQuickChips(["Mulai Pilar 1", "Mulai Pilar 3", "Mode Kuis 🎯"]);
        return;
    }

    const matched = findBestTopic(q);
    if (matched) {
        presentMicroLearning(matched);
    } else {
        const fallback = `Pertanyaan menarik! Saat ini saya bisa menjelaskan secara mendalam tentang <b>5 Pilar Pranaloka 184</b> (Asmaul Husna, Hijaiyah, Hanacaraka, Abjad Latin, dan Angka 0-9).<br><br>Silakan pilih topik di bawah atau ketik <b>"kuis"</b> untuk menguji pemahaman Anda.`;
        addBotMessage(fallback, "Silakan pilih salah satu dari lima pilar Pranaloka 184 atau ketik kuis.");
        setQuickChips(["Pilar 1: Moral", "Pilar 2: Hijaiyah", "Pilar 3: Hanacaraka", "Mode Kuis 🎯"]);
    }
}

function selectTopic(topicId) {
    toggleDrawer(false);
    const topic = KNOWLEDGE_DB.topics.find(t => t.id === topicId);
    if (topic) presentMicroLearning(topic);
}

function presentMicroLearning(topic) {
    currentTopic = topic;
    markTopicLearned(topic.id);

    const pointsHtml = topic.key_points.map(p => `• ${p}`).join('<br>');
    const html = `
        <b>${topic.title}</b>
        <div class="ml-block">
            <div class="ml-title">1. Pengertian Sederhana</div>
            ${topic.simple}
        </div>
        <div class="ml-block">
            <div class="ml-title">2. Analogi Sehari-hari</div>
            ${topic.analogy}
        </div>
        <div class="ml-block">
            <div class="ml-title">3. Poin Penting</div>
            ${pointsHtml}
        </div>
    `;
    const speechText = `${topic.title}. ${topic.simple}. Analoginya: ${topic.analogy}`;
    addBotMessage(html, speechText, topic.title);

    setQuickChips(["Kasih analogi lagi 💡", "Lanjut materi berikutnya ➡️", "Tes pemahaman saya 🎯"]);
}

function startQuiz() {
    toggleDrawer(false);
    if (!KNOWLEDGE_DB.quizzes.length) return;

    const quiz = KNOWLEDGE_DB.quizzes[currentQuizIndex % KNOWLEDGE_DB.quizzes.length];
    const qId = `quiz-${Date.now()}`;
    const optionsHtml = quiz.options.map((opt, idx) =>
        `<button class="quiz-opt-btn" onclick="checkQuizAnswer('${qId}', ${idx}, ${quiz.answer_index}, this)">${opt}</button>`
    ).join('');

    const html = `
        <b>🎯 Kuis Pemahaman Pranaloka 184</b><br><br>${quiz.question}
        <div class="quiz-options" id="${qId}">${optionsHtml}</div>
    `;
    addBotMessage(html, `Kuis Pemahaman. ${quiz.question}`);
    currentQuizIndex++;
}

function checkQuizAnswer(containerId, selectedIdx, correctIdx, btnEl) {
    const container = document.getElementById(containerId);
    const buttons = container.querySelectorAll('button');
    buttons.forEach(b => b.disabled = true);

    const quiz = KNOWLEDGE_DB.quizzes[(currentQuizIndex - 1) % KNOWLEDGE_DB.quizzes.length];
    if (selectedIdx === correctIdx) {
        btnEl.classList.add('correct');
        haptic(40);
        userState.quizScore += 10;
        localStorage.setItem('prana_score', userState.quizScore);
        updateStatsUI();
        addBotMessage(`✅ <b>Jawaban Benar! (+10 Poin)</b><br>${quiz.explanation}`, `Jawaban benar! ${quiz.explanation}`);
    } else {
        btnEl.classList.add('wrong');
        buttons[correctIdx].classList.add('correct');
        haptic(80);
        addBotMessage(`❌ <b>Kurang Tepat.</b><br>${quiz.explanation}`, `Kurang tepat. ${quiz.explanation}`);
    }
    setQuickChips(["Soal Kuis Berikutnya 🎯", "Kembali ke Materi 📚"]);
}

function addUserMessage(text) {
    renderMessage('user', escapeHtml(text), text, true);
}

function addBotMessage(html, rawText, shareTitle = "Ringkasan Pranaloka 184") {
    renderMessage('bot', html, rawText, true, shareTitle);
}

function renderMessage(sender, html, rawText, save = true, shareTitle = "Pranaloka 184") {
    const chatBox = document.getElementById('chat-box');
    const row = document.createElement('div');
    row.className = `msg-row ${sender}`;

    const safeSpeech = rawText.replace(/'/g, "\\'").replace(/\n/g, " ");
    const safeTitle = shareTitle.replace(/'/g, "\\'");

    const actionsHtml = sender === 'bot' ? `
        <div class="bubble-actions">
            <button class="action-pill" onclick="speakNative('${safeSpeech}')">🔊 Dengarkan</button>
            <button class="action-pill" onclick="shareNative('${safeTitle}', '${safeSpeech}')">📤 Bagikan</button>
        </div>` : '';

    row.innerHTML = `
        ${sender === 'bot' ? '<div class="avatar small">✦</div>' : ''}
        <div class="bubble">${html}${actionsHtml}</div>
    `;
    chatBox.appendChild(row);
    scrollToBottom();

    if (save) {
        userState.chatHistory.push({ sender, html, rawText });
        if (userState.chatHistory.length > 50) userState.chatHistory.shift();
        localStorage.setItem('prana_history', JSON.stringify(userState.chatHistory));
    }
}

function setQuickChips(labels) {
    const container = document.getElementById('quick-chips');
    container.innerHTML = labels.map(lbl =>
        `<button class="chip" onclick="handleSend('${lbl}')">${lbl}</button>`
    ).join('');
}

function speakNative(text) {
    haptic(20);
    if (window.AndroidBridge) window.AndroidBridge.speakText(text);
}

function shareNative(title, body) {
    haptic(20);
    if (window.AndroidBridge) window.AndroidBridge.shareContent(title, body);
}

function haptic(ms) {
    if (window.AndroidBridge) window.AndroidBridge.triggerHaptic(ms);
}

function toggleDrawer(open) {
    haptic(15);
    document.getElementById('side-drawer').classList.toggle('open', open);
    document.getElementById('drawer-overlay').classList.toggle('active', open);
}

function toggleTheme() {
    haptic(20);
    const next = userState.theme === 'light' ? 'dark' : 'light';
    applyTheme(next);
}

function applyTheme(theme) {
    userState.theme = theme;
    localStorage.setItem('prana_theme', theme);
    document.documentElement.setAttribute('data-theme', theme);
    document.getElementById('theme-toggle').textContent = theme === 'dark' ? '☀️' : '🌙';
    if (window.AndroidBridge) window.AndroidBridge.setSystemBarTheme(theme === 'dark');
}

function markTopicLearned(id) {
    if (!userState.learnedTopics.includes(id)) {
        userState.learnedTopics.push(id);
        localStorage.setItem('prana_learned', JSON.stringify(userState.learnedTopics));
        updateStatsUI();
    }
}

function updateStatsUI() {
    document.getElementById('stat-topics').textContent = `${userState.learnedTopics.length}/5`;
    document.getElementById('stat-score').textContent = userState.quizScore;
}

function clearChatHistory() {
    haptic(40);
    userState.chatHistory = [];
    localStorage.removeItem('prana_history');
    document.getElementById('chat-box').innerHTML = '';
    toggleDrawer(false);
    addBotMessage("Riwayat obrolan telah dibersihkan. Silakan pilih pilar pembelajaran yang ingin Anda ulang!", "Riwayat obrolan telah dibersihkan.");
}

function showTyping(show) {
    document.getElementById('typing-indicator').classList.toggle('hidden', !show);
    scrollToBottom();
}

function scrollToBottom() {
    const chatBox = document.getElementById('chat-box');
    chatBox.scrollTop = chatBox.scrollHeight;
}

function escapeHtml(str) {
    return str.replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
}

window.handleAndroidBack = function () {
    const drawer = document.getElementById('side-drawer');
    if (drawer.classList.contains('open')) {
        toggleDrawer(false);
        return "true";
    }
    return "false";
};
