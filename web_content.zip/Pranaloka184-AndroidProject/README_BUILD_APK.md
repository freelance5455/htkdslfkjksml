# Panduan Build APK Pranaloka 184 (Android Studio)

1. Ekstrak file `Pranaloka184-AndroidProject.zip`.
2. Buka **Android Studio**, pilih **Open**, lalu arahkan ke folder `Pranaloka184-AndroidProject`.
3. Tunggu proses *Gradle Sync* selesai secara otomatis.
4. Klik menu **Build > Build Bundle(s) / APK(s) > Build APK(s)** untuk menghasilkan file `.apk` siap pasang di HP Android Anda.
