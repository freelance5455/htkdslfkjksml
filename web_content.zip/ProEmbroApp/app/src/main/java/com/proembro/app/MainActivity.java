package com.proembro.app;
import android.app.*; import android.os.*; import android.webkit.*; import android.net.*; import android.content.*; import android.view.*; import java.util.*;
public class MainActivity extends Activity {
 WebView w; ValueCallback<Uri[]> cb;
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main); w=findViewById(R.id.webview);
  WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setDatabaseEnabled(true);s.setAllowFileAccess(true);s.setAllowContentAccess(true);s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
  w.setWebChromeClient(new WebChromeClient(){ public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> c,FileChooserParams p){cb=c;try{startActivityForResult(p.createIntent(),9);}catch(Exception e){cb=null;return false;}return true;}});
  w.setWebViewClient(new WebViewClient(){ public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){v.loadUrl(r.getUrl().toString());return true;}});
  w.loadUrl("file:///android_asset/proembro_app.html");
 }
 protected void onActivityResult(int q,int r,Intent d){super.onActivityResult(q,r,d);if(q==9&&cb!=null){cb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r,d));cb=null;}}
 public void onBackPressed(){if(w.canGoBack())w.goBack();else super.onBackPressed();}
}