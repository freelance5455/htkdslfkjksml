package com.jrclub.gym;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

/**
 * صفحه‌ی اصلی برنامه: فایل index.html (همان برنامه‌ی باشگاه) را داخل WebView نشان می‌دهد.
 * برنامه از آدرس امن داخلی باز می‌شود تا IndexedDB و رمزنگاری مرورگر در آن کار کنند.
 * هیچ اینترنتی لازم نیست و لینک‌های بیرونی (تماس، پیامک، وب) باز نمی‌شوند.
 */
public class MainActivity extends Activity {

    static final int REQ_SMS = 101;
    static final int REQ_FILE = 102;
    static final String HOST = "appassets.androidplatform.net";

    private static final String BACK_JS =
            "(function(){"
          + "var m=document.querySelector('#md');"
          + "if(m&&m.classList.contains('o')){closeM();return '1'}"
          + "var d=document.querySelector('#dg');"
          + "if(d&&d.style.display=='flex'){document.querySelector('#an').click();return '1'}"
          + "if(document.querySelector('#app').style.display=='block'&&page!='dash'){go('dash');return '1'}"
          + "return '0'})()";

    private WebView web;
    private SmsBridge bridge;
    private WebViewAssetLoader loader;
    private ValueCallback<Uri[]> fileCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web = new WebView(this);
        setContentView(web);

        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);

        bridge = new SmsBridge(this, web);
        web.addJavascriptInterface(bridge, "JRNative");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // فقط داخل خود برنامه بمان؛ لینک‌های بیرونی و tel: و sms: باز نمی‌شوند
                return !HOST.equals(request.getUrl().getHost());
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             WebChromeClient.FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });

        web.loadUrl("https://" + HOST + "/assets/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE && fileCallback != null) {
            Uri[] result = (resultCode == RESULT_OK && data != null)
                    ? WebChromeClient.FileChooserParams.parseResult(resultCode, data)
                    : null;
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_SMS) {
            boolean ok = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            bridge.onPermission(ok);
        }
    }

    @Override
    public void onBackPressed() {
        // دکمه‌ی برگشت: اول پنجره‌ی باز را می‌بندد، بعد به داشبورد برمی‌گردد، و در آخر از برنامه خارج می‌شود
        web.evaluateJavascript(BACK_JS, value -> {
            if (!"\"1\"".equals(value) && !"1".equals(value)) finish();
        });
    }

    @Override
    protected void onDestroy() {
        if (bridge != null) bridge.close();
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
