package com.jrclub.gym;

import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.telephony.SmsManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * پل بین صفحه‌ی برنامه (JavaScript) و امکانات اندروید:
 * ارسال پیامک از سیم‌کارت همین گوشی، ذخیره‌ی فایل در Download، و چاپ.
 */
public class SmsBridge {

    private static final String ACTION_SENT = "com.jrclub.gym.SMS_SENT";
    private static final long GAP_MS = 1500;

    private final Activity act;
    private final WebView web;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final AtomicBoolean stop = new AtomicBoolean(false);
    /** کلید پیام -> [تعداد بخش‌های هنوز بی‌جواب، آیا خطا داشته؟ (0 یا 1)] */
    private final ConcurrentHashMap<String, int[]> pending = new ConcurrentHashMap<>();
    private final BroadcastReceiver receiver;

    SmsBridge(Activity act, WebView web) {
        this.act = act;
        this.web = web;
        this.receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String key = intent.getStringExtra("key");
                if (key != null) partDone(key, getResultCode() == Activity.RESULT_OK);
            }
        };
        IntentFilter filter = new IntentFilter(ACTION_SENT);
        if (Build.VERSION.SDK_INT >= 33) {
            act.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            act.registerReceiver(receiver, filter);
        }
    }

    void close() {
        try {
            act.unregisterReceiver(receiver);
        } catch (Exception ignored) {
            // قبلاً ثبت نشده بود
        }
        worker.shutdownNow();
    }

    /** نتیجه‌ی پنجره‌ی اجازه را به صفحه می‌دهد. */
    void onPermission(final boolean ok) {
        js("if(window.annPermResult)annPermResult(" + ok + ")");
    }

    // ------------------------------------------------------------------
    // فراخوانی‌های قابل استفاده از JavaScript
    // ------------------------------------------------------------------

    @JavascriptInterface
    public boolean hasPermission() {
        return act.checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    @JavascriptInterface
    public void requestPermission() {
        ui.post(() -> act.requestPermissions(new String[]{Manifest.permission.SEND_SMS}, MainActivity.REQ_SMS));
    }

    @JavascriptInterface
    public void cancel() {
        stop.set(true);
    }

    /**
     * فهرستی به شکل JSON از {id, phone, text} می‌گیرد و پیام‌ها را یکی‌یکی می‌فرستد.
     * وضعیت هر پیام با annSmsResult(id, ok) و پایان کار با annSmsBatchEnd(stopped) به صفحه برمی‌گردد.
     */
    @JavascriptInterface
    public void sendBatch(final String json) {
        stop.set(false);
        worker.execute(() -> {
            try {
                JSONArray list = new JSONArray(json);
                SmsManager sm = manager();
                for (int i = 0; i < list.length() && !stop.get(); i++) {
                    JSONObject o = list.getJSONObject(i);
                    sendOne(sm, safeKey(o.getString("id")), o.getString("phone"), o.getString("text"));
                    if (i < list.length() - 1 && !stop.get()) {
                        Thread.sleep(GAP_MS);
                    }
                }
            } catch (Exception e) {
                toast("ارسال متوقف شد: " + e.getMessage());
            } finally {
                js("if(window.annSmsBatchEnd)annSmsBatchEnd(" + stop.get() + ")");
            }
        });
    }

    @JavascriptInterface
    public void printPage() {
        ui.post(() -> {
            PrintManager pm = (PrintManager) act.getSystemService(Context.PRINT_SERVICE);
            if (pm != null) {
                pm.print("باشگاه بزرگ JR",
                        web.createPrintDocumentAdapter("باشگاه بزرگ JR"),
                        new PrintAttributes.Builder().build());
            }
        });
    }

    /** فایل متنی را در پوشه‌ی Download ذخیره می‌کند (پشتیبان و خروجی CSV). */
    @JavascriptInterface
    public void saveFile(final String name, final String mime, final String text) {
        worker.execute(() -> {
            try {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                v.put(MediaStore.Downloads.MIME_TYPE, mime);
                v.put(MediaStore.Downloads.IS_PENDING, 1);
                Uri uri = act.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) throw new Exception("uri");
                try (OutputStream os = act.getContentResolver().openOutputStream(uri)) {
                    if (os == null) throw new Exception("stream");
                    os.write(text.getBytes(StandardCharsets.UTF_8));
                }
                ContentValues done = new ContentValues();
                done.put(MediaStore.Downloads.IS_PENDING, 0);
                act.getContentResolver().update(uri, done, null, null);
                toast("فایل در پوشه‌ی Download ذخیره شد: " + name);
            } catch (Exception e) {
                toast("ذخیره‌ی فایل انجام نشد");
            }
        });
    }

    // ------------------------------------------------------------------
    // ارسال پیامک
    // ------------------------------------------------------------------

    private SmsManager manager() {
        if (Build.VERSION.SDK_INT >= 31) {
            return act.getSystemService(SmsManager.class);
        }
        return SmsManager.getDefault();
    }

    private void sendOne(SmsManager sm, String key, String phone, String text) {
        if (!phone.matches("0\\d{9,10}") || text.trim().isEmpty()) {
            report(key, false);
            return;
        }
        try {
            ArrayList<String> parts = sm.divideMessage(text);
            int n = parts.size();
            pending.put(key, new int[]{n, 0});
            ArrayList<PendingIntent> sents = new ArrayList<>();
            for (int p = 0; p < n; p++) {
                Intent in = new Intent(ACTION_SENT).setPackage(act.getPackageName());
                in.putExtra("key", key);
                sents.add(PendingIntent.getBroadcast(act, (key + "#" + p).hashCode(), in,
                        PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
            }
            if (n == 1) {
                sm.sendTextMessage(phone, null, parts.get(0), sents.get(0), null);
            } else {
                sm.sendMultipartTextMessage(phone, null, parts, sents, null);
            }
        } catch (Exception e) {
            pending.remove(key);
            report(key, false);
        }
    }

    /** هر بخش پیام که جواب بدهد، شمارش را کم می‌کند؛ وقتی همه‌ی بخش‌ها جواب داد، نتیجه را می‌فرستد. */
    private void partDone(String key, boolean ok) {
        int[] st = pending.get(key);
        if (st == null) return;
        boolean finished;
        synchronized (st) {
            if (!ok) st[1] = 1;
            st[0]--;
            finished = st[0] <= 0;
        }
        if (finished) {
            pending.remove(key);
            report(key, st[1] == 0);
        }
    }

    private void report(String key, boolean ok) {
        js("if(window.annSmsResult)annSmsResult('" + key + "'," + ok + ")");
    }

    // ------------------------------------------------------------------
    // کمک‌ها
    // ------------------------------------------------------------------

    private void js(final String code) {
        ui.post(() -> web.evaluateJavascript(code, null));
    }

    private void toast(final String msg) {
        ui.post(() -> Toast.makeText(act, msg, Toast.LENGTH_LONG).show());
    }

    private static String safeKey(String s) {
        return s.replaceAll("[^A-Za-z0-9:_-]", "");
    }
}
