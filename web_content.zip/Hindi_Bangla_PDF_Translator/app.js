/* Hindi ⇄ Bangla PDF Translator
 * PDF.js extracts selectable text. Translation uses third-party public APIs.
 */
(() => {
  "use strict";
  const $ = id => document.getElementById(id);
  const fileInput = $("pdfFile"), source = $("sourceText"), result = $("translatedText");
  const extractBtn = $("extractBtn"), translateBtn = $("translateBtn");
  const status = $("status"), progress = $("progressBar");
  if (window.pdfjsLib) {
    pdfjsLib.GlobalWorkerOptions.workerSrc =
      "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";
  }
  let selectedFile = null;
  const setStatus = (msg, pct = null) => {
    status.textContent = msg;
    if (pct !== null) progress.style.width = `${Math.max(0, Math.min(100, pct))}%`;
  };
  const updateButtons = () => {
    translateBtn.disabled = !source.value.trim();
    $("copySource").disabled = !source.value;
    $("copyResult").disabled = !result.value;
    $("downloadTxt").disabled = !result.value;
    $("printPdf").disabled = !result.value;
  };
  source.addEventListener("input", updateButtons);
  result.addEventListener("input", updateButtons);
  fileInput.addEventListener("change", () => {
    selectedFile = fileInput.files && fileInput.files[0] || null;
    $("fileInfo").textContent = selectedFile
      ? `${selectedFile.name} · ${(selectedFile.size / 1024 / 1024).toFixed(2)} MB`
      : "अभी कोई फ़ाइल नहीं चुनी गई।";
    extractBtn.disabled = !selectedFile;
    if (selectedFile && selectedFile.type !== "application/pdf" && !selectedFile.name.toLowerCase().endsWith(".pdf")) {
      setStatus("कृपया PDF फ़ाइल चुनें।");
      extractBtn.disabled = true;
    } else setStatus("PDF चुना गया।");
  });

  const dropZone = $("dropZone");
  ["dragenter", "dragover"].forEach(evt => dropZone.addEventListener(evt, e => {
    e.preventDefault(); dropZone.style.borderColor = "#123c35";
  }));
  ["dragleave", "drop"].forEach(evt => dropZone.addEventListener(evt, e => {
    e.preventDefault(); dropZone.style.borderColor = "";
  }));
  dropZone.addEventListener("drop", e => {
    const f = e.dataTransfer.files && e.dataTransfer.files[0];
    if (f && (f.type === "application/pdf" || f.name.toLowerCase().endsWith(".pdf"))) {
      try { const dt = new DataTransfer(); dt.items.add(f); fileInput.files = dt.files; fileInput.dispatchEvent(new Event("change")); }
      catch (_) { setStatus("ड्रॉप समर्थित नहीं हुआ; फ़ाइल चुनने के बटन का उपयोग करें।"); }
    } else setStatus("कृपया PDF फ़ाइल छोड़ें।");
  });

  extractBtn.addEventListener("click", async () => {
    if (!selectedFile) return;
    if (!window.pdfjsLib) { setStatus("PDF पढ़ने की लाइब्रेरी लोड नहीं हुई। इंटरनेट कनेक्शन जाँचें।"); return; }
    extractBtn.disabled = true;
    try {
      setStatus("PDF पढ़ी जा रही है…", 5);
      const bytes = await selectedFile.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({data: bytes}).promise;
      let pages = [];
      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const content = await page.getTextContent();
        const text = content.items.map(item => item.str).join(" ").replace(/[ \t]+/g, " ").trim();
        pages.push(`— पृष्ठ ${i} —\n${text}`);
        setStatus(`पृष्ठ ${i}/${pdf.numPages} पढ़ा जा रहा है…`, Math.round(i / pdf.numPages * 100));
      }
      const extracted = pages.join("\n\n").trim();
      if (!extracted.replace(/— पृष्ठ \d+ —/g, "").trim()) {
        setStatus("इस PDF में चुनने योग्य टेक्स्ट नहीं मिला। यह स्कैन की हुई PDF हो सकती है; OCR करें या टेक्स्ट पेस्ट करें।", 0);
      } else {
        source.value = extracted;
        result.value = "";
        updateButtons();
        setStatus(`टेक्स्ट निकाल लिया गया (${pdf.numPages} पृष्ठ)। अब “अनुवाद करें” दबाएँ।`, 100);
      }
    } catch (err) {
      console.error(err);
      setStatus("PDF पढ़ने में समस्या हुई। फ़ाइल खराब/पासवर्ड-सुरक्षित हो सकती है।");
    } finally { extractBtn.disabled = !selectedFile; }
  });

  function splitText(text, limit = 450) {
    const chunks = [];
    let rest = text;
    while (rest.length > limit) {
      let cut = rest.lastIndexOf("\n", limit);
      if (cut < limit * 0.55) cut = rest.lastIndexOf("।", limit);
      if (cut < limit * 0.55) cut = rest.lastIndexOf(". ", limit);
      if (cut < limit * 0.55) cut = rest.lastIndexOf(" ", limit);
      if (cut < 1) cut = limit;
      chunks.push(rest.slice(0, cut));
      rest = rest.slice(cut).trimStart();
    }
    if (rest) chunks.push(rest);
    return chunks;
  }
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  async function translateChunk(text, direction, service) {
    if (service === "mymemory") {
      const [from, to] = direction === "hi-bn" ? ["hi", "bn"] : ["bn", "hi"];
      const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${from}|${to}`;
      const response = await fetch(url);
      if (!response.ok) throw new Error(`अनुवाद सेवा ने HTTP ${response.status} लौटाया`);
      const data = await response.json();
      if (data.responseStatus && Number(data.responseStatus) !== 200) {
        throw new Error(data.responseDetails || "MyMemory ने अनुरोध स्वीकार नहीं किया।");
      }
      return data.responseData && data.responseData.translatedText || "";
    }
    // Public LibreTranslate instances may change, rate-limit, or reject browser requests.
    const response = await fetch("https://libretranslate.com/translate", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({q: text, source: direction === "hi-bn" ? "hi" : "bn",
        target: direction === "hi-bn" ? "bn" : "hi", format: "text"})
    });
    if (!response.ok) throw new Error(`LibreTranslate ने HTTP ${response.status} लौटाया। यह सर्वर/API key माँग सकता है।`);
    const data = await response.json();
    if (!data.translatedText) throw new Error("अनुवाद सेवा से टेक्स्ट नहीं मिला।");
    return data.translatedText;
  }

  translateBtn.addEventListener("click", async () => {
    const input = source.value.trim();
    if (!input) { setStatus("पहले PDF का टेक्स्ट निकालें या मूल टेक्स्ट बॉक्स में पेस्ट करें।"); return; }
    translateBtn.disabled = true;
    result.value = "";
    const chunks = splitText(input);
    const direction = $("direction").value, service = $("service").value;
    let done = [];
    try {
      for (let i = 0; i < chunks.length; i++) {
        setStatus(`अनुवाद जारी है… ${i + 1}/${chunks.length} भाग`, Math.round(i / chunks.length * 100));
        const translated = await translateChunk(chunks[i], direction, service);
        done.push(translated);
        result.value = done.join("\n");
        updateButtons();
        // Reduce the chance of hitting public service rate limits.
        if (i < chunks.length - 1) await sleep(service === "mymemory" ? 900 : 350);
      }
      setStatus("अनुवाद पूरा हुआ। परिणाम जाँचें; फिर TXT डाउनलोड या PDF सेव / प्रिंट करें।", 100);
    } catch (err) {
      console.error(err);
      setStatus(`अनुवाद बीच में रुक गया: ${err.message} पहले से हुआ अनुवाद बॉक्स में सुरक्षित है। कुछ देर बाद पुनः प्रयास करें।`, 0);
    } finally { translateBtn.disabled = !source.value.trim(); updateButtons(); }
  });

  async function copyText(text, label) {
    try {
      await navigator.clipboard.writeText(text);
      setStatus(`${label} कॉपी हो गया।`);
    } catch (_) {
      const temp = document.createElement("textarea"); temp.value = text; document.body.appendChild(temp);
      temp.select(); const ok = document.execCommand("copy"); temp.remove();
      setStatus(ok ? `${label} कॉपी हो गया।` : "कॉपी नहीं हुआ; टेक्स्ट चुनकर कॉपी करें।");
    }
  }
  $("copySource").addEventListener("click", () => copyText(source.value, "मूल टेक्स्ट"));
  $("copyResult").addEventListener("click", () => copyText(result.value, "अनुवाद"));
  $("downloadTxt").addEventListener("click", () => {
    const blob = new Blob(["\ufeff", result.value], {type:"text/plain;charset=utf-8"});
    const url = URL.createObjectURL(blob), a = document.createElement("a");
    a.href = url; a.download = "translated-text.txt"; document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url); setStatus("TXT फ़ाइल डाउनलोड शुरू हुई।");
  });
  $("printPdf").addEventListener("click", () => {
    // CSS print mode hides the source and prints the translated text only.
    window.print();
  });
  updateButtons();
})();