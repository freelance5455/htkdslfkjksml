SELHER V4.5 - proyecto Android basado en tu HTML.

Incluye:
- Carga XLSX/XLS
- Voz es-MX con 0.8x / 1.1x / 1.6x
- Lectura secuencial de ubicaciones
- Escaneo QR con cámara
- Validación exacta de cantidades
- Registro persistente del historial en el dispositivo
- Exportación de resultados a SELHER_RESULTADOS.xlsx

Para compilar APK con Capacitor:
1) Instala Node.js y Android Studio.
2) En esta carpeta ejecuta: npm install
3) Ejecuta: npx cap add android
4) Ejecuta: npx cap sync android
5) Abre: npx cap open android
6) En Android Studio genera el APK.

La documentación oficial de Capacitor: https://capacitorjs.com/docs
