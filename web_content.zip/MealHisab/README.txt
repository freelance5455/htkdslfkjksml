MealHisab — Sabbir Shikdar

নতুন ফিচার: পরের দিনের মিল রিকোয়েস্ট। সদস্য তারিখ, সকাল/দুপুর/রাতের মিল, অতিথি মিল সংখ্যা এবং মন্তব্য দিয়ে সেভ করতে পারবে। রিকোয়েস্টগুলো এই ডিভাইসের লোকাল স্টোরেজে থাকে।

Android HTML-to-APK Builder-এ index.html ব্যবহার করুন এবং JavaScript ও DOM Storage/Local Storage চালু রাখুন। নিয়মিত JSON backup রাখুন।