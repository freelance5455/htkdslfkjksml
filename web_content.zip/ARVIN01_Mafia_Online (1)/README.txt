ARVIN01 Mafia Online
نسخه آماده HTML

اجرا:
1) فایل index.html را با Chrome باز کنید.
2) برای اجرای محلی با Termux:
   python -m http.server 8080
   سپس http://localhost:8080 را باز کنید.

این نسخه دمو/آفلاین است؛ برای بازی آنلاین واقعی به سرور و WebSocket نیاز دارد.
