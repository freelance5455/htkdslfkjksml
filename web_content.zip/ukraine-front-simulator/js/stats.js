// ===== STATISTICS =====
function updateStats() {
  let liberated = 0;
  let occupied = 0;
  let fighting = 0;

  STATE.shapes.forEach(s => {
    if (s.category === 'liberated') liberated += s.area;
    else if (s.category === 'occupied') occupied += s.area;
    else if (s.category === 'fighting') fighting += s.area;
  });

  const flags = STATE.markers.filter(m => m.type.startsWith('flag')).length;
  const brigUa = STATE.markers.filter(m => m.type === 'brigade-ua').length;
  const brigRu = STATE.markers.filter(m => m.type === 'brigade-ru').length;

  document.getElementById('stat-liberated').textContent = formatArea(liberated);
  document.getElementById('stat-occupied').textContent = formatArea(occupied);
  document.getElementById('stat-fighting').textContent = formatArea(fighting);
  document.getElementById('stat-flags').textContent = flags;
  document.getElementById('stat-brigade-ua').textContent = brigUa;
  document.getElementById('stat-brigade-ru').textContent = brigRu;
}

function formatArea(km2) {
  if (km2 >= 1000) return km2.toFixed(0);
  if (km2 >= 10) return km2.toFixed(1);
  return km2.toFixed(2);
}
