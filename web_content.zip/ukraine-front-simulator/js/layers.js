// ===== LAYERS PANEL =====
function initLayersPanel() {
  const baseContainer = document.getElementById('base-layers');
  const overlayContainer = document.getElementById('overlay-layers');

  // Базові шари (radio)
  CONFIG.baseLayers.forEach((cfg, idx) => {
    const div = document.createElement('label');
    div.className = 'layer-item' + (idx === 0 ? ' active' : '');
    div.innerHTML = `
      <input type="radio" name="base-layer" value="${cfg.id}" ${idx === 0 ? 'checked' : ''} />
      <span>${cfg.name}</span>
    `;
    div.querySelector('input').addEventListener('change', () => {
      setBaseLayer(cfg.id);
      document.querySelectorAll('#base-layers .layer-item').forEach(el => el.classList.remove('active'));
      div.classList.add('active');
    });
    baseContainer.appendChild(div);
  });

  // Оверлеї (checkbox)
  CONFIG.overlays.forEach(cfg => {
    const div = document.createElement('label');
    div.className = 'layer-item';
    div.innerHTML = `
      <input type="checkbox" value="${cfg.id}" />
      <span>${cfg.name}</span>
    `;
    div.querySelector('input').addEventListener('change', (e) => {
      toggleOverlay(cfg.id, e.target.checked);
    });
    overlayContainer.appendChild(div);
  });

  // Кнопка відкриття панелі
  document.getElementById('layers-btn').addEventListener('click', () => {
    document.getElementById('layers-panel').classList.toggle('hidden');
  });

  // Закриття
  document.querySelectorAll('.close-panel').forEach(btn => {
    btn.addEventListener('click', () => {
      document.getElementById(btn.dataset.panel).classList.add('hidden');
    });
  });
}
