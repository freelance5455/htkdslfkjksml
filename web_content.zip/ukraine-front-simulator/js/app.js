/* FOREFRONT 0.5.3 — Delux/uxedition mechanics */
(function () {
  'use strict';

  const COL = {
    blue:   { fill: '#2563eb', op: 0.45 },
    red:    { fill: '#dc2626', op: 0.50 },
    gray:   { fill: '#64748b', op: 0.40 },
    yellow: { fill: '#eab308', op: 0.40 }
  };
  const LABEL = { blue: 'Синяя сторона', red: 'Красная сторона', gray: 'Серая зона', yellow: 'Нейтрал' };
  const TILES = {
    sat:    { url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', a: 'Esri' },
    google: { url: 'https://mt{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}', s: '0123', a: 'Google' },
    topo:   { url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}', a: 'Esri' },
    esri:   { url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}', a: 'Esri' }
  };

  const S = {
    tool: 'contour', side: 'blue',
    brushPx: 14, smooth: 1, grayW: 2, autoGray: false,
    anim: true, lowEnd: false,
    shapes: [], hist: [], hIdx: -1,
    drawing: false, pts: [],
    temp: null, tile: null, scenario: 'deepstate',
    xp: 0, candy: 0
  };

  let map, drawn;

  function $(id) { return document.getElementById(id); }
  function loadMeta() {
    try { const j = JSON.parse(localStorage.getItem('ff-meta') || '{}'); S.xp = j.xp || 0; S.candy = j.candy || 0; } catch (e) {}
  }
  function saveMeta() {
    localStorage.setItem('ff-meta', JSON.stringify({ xp: S.xp, candy: S.candy }));
    updXP();
  }
  function updXP() {
    const lvl = Math.min(10, Math.floor(S.xp / 100));
    const into = S.xp % 100;
    if ($('lvl')) $('lvl').textContent = lvl;
    if ($('xpcur')) $('xpcur').textContent = into;
    if ($('xpfill')) $('xpfill').style.width = (lvl >= 10 ? 100 : into) + '%';
    if ($('candy')) $('candy').textContent = S.candy;
    if ($('shop-candy')) $('shop-candy').textContent = S.candy;
  }
  function toast(t, ms) {
    const el = $('toast');
    el.textContent = t;
    el.classList.remove('hidden');
    clearTimeout(toast._t);
    toast._t = setTimeout(() => el.classList.add('hidden'), ms || 1400);
  }

  function initMap() {
    map = L.map('map', { center: [47.75, 35.9], zoom: 11, zoomControl: false, preferCanvas: true });
    setLayer('sat');
    drawn = L.featureGroup().addTo(map);
    map.on('zoomend', () => { if ($('zlabel')) $('zlabel').textContent = map.getZoom().toFixed(1); });
    bindInput();
  }

  function setLayer(k) {
    if (S.tile) map.removeLayer(S.tile);
    const T = TILES[k] || TILES.sat;
    S.tile = L.tileLayer(T.url, { attribution: T.a, maxZoom: 18, subdomains: T.s || '', crossOrigin: true }).addTo(map);
    document.querySelectorAll('.layer-btn').forEach(b => b.classList.toggle('active', b.dataset.layer === k));
  }

  function ll(e) {
    const t = (e.touches && e.touches[0]) || (e.changedTouches && e.changedTouches[0]) || e;
    return map.mouseEventToLatLng(t);
  }

  function bindInput() {
    const el = map.getContainer();
    el.addEventListener('touchstart', onStart, { passive: false });
    el.addEventListener('touchmove', onMove, { passive: false });
    el.addEventListener('touchend', onEnd, { passive: false });
    el.addEventListener('mousedown', onStart);
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onEnd);
  }

  function onStart(e) {
    if (S.tool === 'pan') return;
    if (e.touches && e.touches.length > 1) return;
    if (e.button !== undefined && e.button !== 0) return;
    e.preventDefault && e.preventDefault();
    map.dragging.disable();
    S.drawing = true;
    S.pts = [];
    const p = ll(e);
    S.pts.push([p.lat, p.lng]);
    redrawTemp();
  }

  function onMove(e) {
    if (!S.drawing) return;
    if (e.touches && e.touches.length > 1) return;
    e.preventDefault && e.preventDefault();
    const p = ll(e);
    const last = S.pts[S.pts.length - 1];
    if (!last) return;
    const d = map.latLngToContainerPoint(p).distanceTo(map.latLngToContainerPoint(L.latLng(last[0], last[1])));
    if (d < (S.lowEnd ? 8 : 4)) return;
    S.pts.push([p.lat, p.lng]);
    redrawTemp();
  }

  function onEnd() {
    if (!S.drawing) return;
    S.drawing = false;
    map.dragging.enable();
    if (S.tool === 'eraser') { doErase(); clearTemp(); return; }
    finish();
  }

  /* LIVE PREVIEW like Delux */
  function redrawTemp() {
    clearTemp();
    if (S.pts.length < 2) return;
    const c = COL[S.side].fill;

    if (S.tool === 'brush') {
      // translucent stroke following finger (as in video)
      const km = brushKm();
      try {
        const line = turf.lineString(S.pts.map(p => [p[1], p[0]]));
        const buf = turf.buffer(line, km, { units: 'kilometers' });
        if (buf) {
          const rings = buf.geometry.type === 'Polygon'
            ? [buf.geometry.coordinates[0]]
            : (buf.geometry.coordinates || []).map(c => c[0]);
          const latlngs = rings.map(r => r.map(c => [c[1], c[0]]));
          S.temp = L.polygon(latlngs, {
            color: c, fillColor: c, fillOpacity: 0.35, weight: 1, opacity: 0.5
          }).addTo(map);
        }
      } catch (e) {
        S.temp = L.polyline(S.pts, { color: c, weight: Math.max(4, S.brushPx), opacity: 0.5, lineCap: 'round' }).addTo(map);
      }
    } else {
      // white dashed contour like Delux video
      const closed = S.pts.concat([S.pts[0]]);
      S.temp = L.polyline(closed, {
        color: '#ffffff', weight: 2, opacity: 0.95, dashArray: '7 5'
      }).addTo(map);
    }
  }

  function clearTemp() {
    if (S.temp) { map.removeLayer(S.temp); S.temp = null; }
  }

  function brushKm() {
    // size slider ~ screen pixels → km at current zoom (Delux-like)
    const z = map.getZoom();
    const mPerPx = 40075016.686 * Math.abs(Math.cos(map.getCenter().lat * Math.PI / 180)) / Math.pow(2, z + 8);
    return Math.max(0.03, (S.brushPx * mPerPx) / 1000);
  }

  function finish() {
    clearTemp();
    toast('Считаю…', 800);
    let geo = null;

    if (S.tool === 'brush') {
      if (S.pts.length < 2) return;
      try {
        let pts = S.pts;
        if (S.smooth > 0 && pts.length > 4) pts = smoothPts(pts, S.smooth);
        const line = turf.lineString(pts.map(p => [p[1], p[0]]));
        geo = turf.buffer(line, brushKm(), { units: 'kilometers' });
      } catch (e) { return; }
    } else {
      if (S.pts.length < 3) return;
      let pts = S.pts;
      if (S.smooth > 0 && pts.length > 4) pts = smoothPts(pts, S.smooth);
      const ring = pts.map(p => [p[1], p[0]]);
      const a = ring[0], b = ring[ring.length - 1];
      if (a[0] !== b[0] || a[1] !== b[1]) ring.push([a[0], a[1]]);
      try { geo = turf.polygon([ring]); } catch (e) { return; }
    }
    if (!geo) return;

    // same color: merge (union) later via cut+add; subtract overlap first for clean
    geo = subtractSame(geo, S.side);
    if (!geo) return;

    // opposite colors: cut out
    cutOthers(geo, S.side);

    let area = 0;
    try { area = turf.area(geo) / 1e6; } catch (e) {}
    if (area < 0.01) return;

    // progress animation like Delux
    progressToast(S.side, area);

    addShape(geo, S.side, area);
    reward(area, S.side);
    pushHist();
    updateStats();
  }

  function progressToast(side, area) {
    const label = LABEL[side] || side;
    let pct = 0;
    toast('Продвижение: ' + label + ' · 0%', 2000);
    const iv = setInterval(() => {
      pct += 8 + Math.random() * 12;
      if (pct >= 100) {
        pct = 100;
        clearInterval(iv);
        toast('Продвижение: ' + label + ' · ' + area.toFixed(1) + ' км²', 1200);
      } else {
        toast('Продвижение: ' + label + ' · ' + Math.min(99, Math.floor(pct)) + '%', 2000);
      }
    }, 60);
  }

  function smoothPts(pts, n) {
    let out = pts.slice();
    for (let k = 0; k < n; k++) {
      const next = [out[0]];
      for (let i = 1; i < out.length - 1; i++) {
        next.push([
          (out[i - 1][0] + out[i][0] * 2 + out[i + 1][0]) / 4,
          (out[i - 1][1] + out[i][1] * 2 + out[i + 1][1]) / 4
        ]);
      }
      next.push(out[out.length - 1]);
      out = next;
    }
    return out;
  }

  function subtractSame(geo, side) {
    let r = geo;
    for (const s of S.shapes) {
      if (s.side !== side || !s.geo) continue;
      try {
        if (!turf.booleanIntersects(r, s.geo)) continue;
        const d = turf.difference(r, s.geo);
        if (!d) return null;
        r = d;
      } catch (e) {}
    }
    return r;
  }

  function cutOthers(geo, side) {
    const remove = [], add = [];
    for (const s of S.shapes) {
      if (s.side === side || !s.geo) continue;
      try {
        if (!turf.booleanIntersects(s.geo, geo)) continue;
        const d = turf.difference(s.geo, geo);
        remove.push(s);
        if (d) {
          const parts = d.geometry.type === 'MultiPolygon'
            ? d.geometry.coordinates.map(c => turf.polygon(c))
            : [d];
          for (const p of parts) {
            let a = 0;
            try { a = turf.area(p) / 1e6; } catch (e) {}
            if (a >= 0.01) add.push({ side: s.side, geo: p, area: a });
          }
        }
      } catch (e) {}
    }
    for (const s of remove) {
      if (s.layer) drawn.removeLayer(s.layer);
      S.shapes = S.shapes.filter(x => x !== s);
    }
    for (const a of add) addShape(a.geo, a.side, a.area, true);
  }

  function addShape(geo, side, area, silent) {
    const parts = geo.geometry.type === 'MultiPolygon'
      ? geo.geometry.coordinates.map(c => turf.polygon(c))
      : [geo];
    for (const g of parts) {
      let a = area;
      try { a = turf.area(g) / 1e6; } catch (e) {}
      if (a < 0.01) continue;
      const latlngs = g.geometry.coordinates[0].map(c => [c[1], c[0]]);
      const c = COL[side] || COL.blue;
      const layer = L.polygon(latlngs, {
        color: c.fill, fillColor: c.fill,
        fillOpacity: (!silent && S.anim) ? 0.12 : c.op,
        weight: 0, opacity: 0, stroke: false
      }).addTo(drawn);
      if (!silent && S.anim) animateFill(layer, c.op);
      S.shapes.push({ side, geo: g, layer, area: a });
    }
  }

  function animateFill(layer, target) {
    let i = 0;
    const steps = 14;
    const tick = () => {
      i++;
      layer.setStyle({ fillOpacity: 0.12 + (target - 0.12) * (i / steps) });
      if (i < steps) setTimeout(tick, 30);
    };
    setTimeout(tick, 20);
  }

  function doErase() {
    if (!S.pts.length) return;
    const p = S.pts[S.pts.length - 1];
    const pt = turf.point([p[1], p[0]]);
    const hit = S.shapes.filter(s => {
      try { return turf.booleanPointInPolygon(pt, s.geo); } catch (e) { return false; }
    });
    for (const s of hit) {
      if (s.layer) drawn.removeLayer(s.layer);
      S.shapes = S.shapes.filter(x => x !== s);
    }
    if (hit.length) { pushHist(); updateStats(); }
  }

  function reward(areaKm2, side) {
    if (side === 'gray' || side === 'yellow') return;
    const area = Math.floor(areaKm2);
    if (areaKm2 >= 100) {
      const pen = Math.min(100, S.candy);
      S.candy -= pen;
      toast('Жульнічество! −' + pen + ' 🍬', 1800);
    } else if (area > 0) {
      S.candy += area;
      S.xp += area;
    }
    saveMeta();
  }

  function updateStats() {
    const A = { blue: 0, red: 0, gray: 0, yellow: 0 };
    for (const s of S.shapes) A[s.side] = (A[s.side] || 0) + (s.area || 0);
    const tot = A.blue + A.red + A.gray + A.yellow || 1;
    const pct = v => (Math.round((v / tot) * 1000) / 10).toFixed(1).replace('.', ',') + '%';
    if ($('pct-blue')) $('pct-blue').textContent = pct(A.blue);
    if ($('pct-red')) $('pct-red').textContent = pct(A.red);
    if ($('pct-gray')) $('pct-gray').textContent = pct(A.gray);
    if ($('pct-yellow')) $('pct-yellow').textContent = pct(A.yellow);
  }

  function snap() { return S.shapes.map(s => ({ side: s.side, geo: s.geo, area: s.area })); }
  function restore(list) {
    drawn.clearLayers(); S.shapes = [];
    for (const s of list) addShape(s.geo, s.side, s.area, true);
    updateStats();
  }
  function pushHist() {
    S.hist = S.hist.slice(0, S.hIdx + 1);
    S.hist.push(snap());
    if (S.hist.length > 40) S.hist.shift();
    S.hIdx = S.hist.length - 1;
  }

  async function loadDeepState() {
    toast('Завантаження фронту…', 3000);
    const urls = [
      'https://raw.githubusercontent.com/cyterat/deepstate-map-data/main/data/deepstatemap_data_20261008.geojson',
      'https://raw.githubusercontent.com/cyterat/deepstate-map-data/main/data/deepstatemap_data_20251001.geojson'
    ];
    for (const u of urls) {
      try {
        const r = await fetch(u);
        if (!r.ok) continue;
        ingest(await r.json());
        toast('Фронт завантажено', 1200);
        return;
      } catch (e) {}
    }
    // fallback demo zones near Tokmak
    seedDemo();
    toast('Демо-зони (фронт недоступний)', 2000);
  }

  function ingest(data) {
    if (!data || !data.features) return;
    drawn.clearLayers(); S.shapes = [];
    for (const f of data.features) {
      if (!f.geometry) continue;
      const name = ((f.properties && (f.properties.name || f.properties.status || '')) || '').toLowerCase();
      let side = 'red';
      if (/ukr|liber|free|звіль|blue|синь/.test(name)) side = 'blue';
      else if (/gray|grey|сір|fight|бої/.test(name)) side = 'gray';
      try {
        let area = 0;
        try { area = turf.area(f) / 1e6; } catch (e) {}
        addShape(f, side, area, true);
      } catch (e) {}
    }
    pushHist(); updateStats();
    map.setView([47.75, 35.9], 10);
  }

  function seedDemo() {
    // blue north, red south around Orikhiv/Tokmak like the video
    const blue = turf.polygon([[
      [35.4, 47.9], [36.3, 47.9], [36.4, 47.6], [35.9, 47.55], [35.4, 47.6], [35.4, 47.9]
    ]]);
    const red = turf.polygon([[
      [35.4, 47.6], [36.4, 47.6], [36.5, 47.3], [35.3, 47.3], [35.4, 47.6]
    ]]);
    addShape(blue, 'blue', 0, true);
    addShape(red, 'red', 0, true);
    pushHist(); updateStats();
    map.setView([47.65, 35.85], 11);
  }

  function saveFile() {
    const data = { v: '0.5.3', shapes: snap(), xp: S.xp, candy: S.candy };
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([JSON.stringify(data)], { type: 'application/json' }));
    a.download = 'forefront-save.json';
    a.click();
  }

  function startGame() {
    $('menu').classList.add('hidden');
    $('game').classList.remove('hidden');
    if (!map) initMap();
    setTimeout(() => map.invalidateSize(), 120);
    drawn && drawn.clearLayers();
    S.shapes = []; S.hist = []; S.hIdx = -1;
    updateStats(); updXP();
    if (S.scenario === 'deepstate') loadDeepState();
    else { seedDemo(); }
  }

  function wire() {
    document.querySelectorAll('.sc-btn').forEach(b => b.onclick = () => {
      document.querySelectorAll('.sc-btn').forEach(x => x.classList.remove('active'));
      b.classList.add('active');
      S.scenario = b.dataset.scenario;
    });
    $('btn-start').onclick = startGame;
    $('btn-menu').onclick = () => { $('game').classList.add('hidden'); $('menu').classList.remove('hidden'); };
    $('btn-settings-menu').onclick = () => $('modal-settings').classList.remove('hidden');
    $('btn-credits-menu').onclick = () => $('modal-credits').classList.remove('hidden');
    $('btn-settings-game').onclick = () => $('modal-settings').classList.remove('hidden');
    $('btn-shop').onclick = () => { updXP(); $('modal-shop').classList.remove('hidden'); };
    document.querySelectorAll('[data-close]').forEach(b => b.onclick = () => $(b.dataset.close).classList.add('hidden'));
    document.querySelectorAll('[data-buy]').forEach(b => b.onclick = () => {
      const c = +b.dataset.buy;
      if (S.candy < c) { toast('Недостатньо 🍬'); return; }
      S.candy -= c; S.xp += c; saveMeta(); toast('+' + c + ' XP');
    });
    $('ptoggle').onclick = () => {
      $('panel').classList.toggle('collapsed');
      $('ptoggle').textContent = $('panel').classList.contains('collapsed') ? '▲' : '▼';
    };
    document.querySelectorAll('.tool').forEach(b => {
      if (b.id === 'undo' || b.id === 'redo') return;
      b.onclick = () => {
        document.querySelectorAll('.tool').forEach(x => { if (x.id !== 'undo' && x.id !== 'redo') x.classList.remove('active'); });
        b.classList.add('active');
        S.tool = b.dataset.tool;
        if (S.tool === 'pan') map.dragging.enable(); else map.dragging.disable();
      };
    });
    document.querySelectorAll('.side').forEach(b => b.onclick = () => {
      document.querySelectorAll('.side').forEach(x => x.classList.remove('active'));
      b.classList.add('active');
      S.side = b.dataset.side;
    });
    document.querySelectorAll('.layer-btn').forEach(b => b.onclick = () => setLayer(b.dataset.layer));
    $('brush-size').oninput = e => { S.brushPx = +e.target.value; $('brush-val').textContent = S.brushPx; };
    $('smooth').oninput = e => { S.smooth = +e.target.value; $('smooth-val').textContent = S.smooth; };
    $('gray-w').oninput = e => { S.grayW = +e.target.value; $('gray-val').textContent = S.grayW; };
    $('auto-gray').onchange = e => { S.autoGray = e.target.checked; };
    $('anim-on').onchange = e => { S.anim = e.target.checked; };
    $('low-end').onchange = e => { S.lowEnd = e.target.checked; };
    $('undo').onclick = () => { if (S.hIdx > 0) { S.hIdx--; restore(S.hist[S.hIdx]); } };
    $('redo').onclick = () => { if (S.hIdx < S.hist.length - 1) { S.hIdx++; restore(S.hist[S.hIdx]); } };
    $('clear-all').onclick = () => {
      if (!confirm('Очистить все зоны?')) return;
      drawn.clearLayers(); S.shapes = []; pushHist(); updateStats();
    };
    $('btn-save-top').onclick = saveFile;
    $('btn-load').onclick = () => $('file-in').click();
    $('file-in').onchange = e => {
      if (!e.target.files[0]) return;
      const r = new FileReader();
      r.onload = () => {
        try {
          const d = JSON.parse(r.result);
          if ($('game').classList.contains('hidden')) startGame();
          if (d.shapes) restore(d.shapes);
          if (typeof d.xp === 'number') S.xp = d.xp;
          if (typeof d.candy === 'number') S.candy = d.candy;
          saveMeta(); pushHist(); updateStats();
          toast('Завантажено');
        } catch (err) { toast('Помилка файлу'); }
      };
      r.readAsText(e.target.files[0]);
    };
  }

  loadMeta(); updXP(); wire();
})();
