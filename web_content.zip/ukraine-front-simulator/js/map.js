// ===== MAP INIT =====
let map;
let baseLayerGroup = {};
let overlayLayerGroup = {};
let drawnItems;          // FeatureGroup для всіх полігонів
let markerGroup;         // FeatureGroup для маркерів
let tempGroup;           // тимчасові лінії під час малювання

function initMap() {
  map = L.map('map', {
    center: CONFIG.map.center,
    zoom: CONFIG.map.zoom,
    minZoom: CONFIG.map.minZoom,
    maxZoom: CONFIG.map.maxZoom,
    zoomControl: true,
    attributionControl: true,
    preferCanvas: true   // краща продуктивність при багатьох полігонах
  });

  // Групи шарів
  drawnItems = new L.FeatureGroup().addTo(map);
  markerGroup = new L.FeatureGroup().addTo(map);
  tempGroup = new L.FeatureGroup().addTo(map);

  // Ініціалізація базових шарів
  CONFIG.baseLayers.forEach((layerCfg, idx) => {
    const layer = L.tileLayer(layerCfg.url, {
      attribution: layerCfg.attribution,
      maxZoom: layerCfg.maxZoom || 18,
      subdomains: layerCfg.url.includes('{s}') ? 'abc' : ''
    });
    baseLayerGroup[layerCfg.id] = layer;
    if (idx === 0) layer.addTo(map); // перший шар за замовчуванням
  });

  // Оверлеї
  CONFIG.overlays.forEach(ov => {
    const layer = L.tileLayer(ov.url, {
      attribution: ov.attribution,
      maxZoom: ov.maxZoom || 18,
      opacity: ov.opacity || 0.8,
      subdomains: 'abc'
    });
    overlayLayerGroup[ov.id] = layer;
  });

  // Обробники кліків карти
  map.on('click', onMapClick);
  map.on('mousemove', onMapMouseMove);

  // Мобільна підтримка малювання пальцем
  map.on('touchstart', onTouchStart, { passive: false });
  map.on('touchmove', onTouchMove, { passive: false });
  map.on('touchend', onTouchEnd);
  map.on('touchcancel', onTouchEnd);

  updateMapCursor();
}

function setBaseLayer(id) {
  Object.values(baseLayerGroup).forEach(l => {
    if (map.hasLayer(l)) map.removeLayer(l);
  });
  if (baseLayerGroup[id]) {
    baseLayerGroup[id].addTo(map);
  }
}

function toggleOverlay(id, enabled) {
  const layer = overlayLayerGroup[id];
  if (!layer) return;
  if (enabled) {
    if (!map.hasLayer(layer)) layer.addTo(map);
  } else {
    if (map.hasLayer(layer)) map.removeLayer(layer);
  }
}

function updateMapCursor() {
  const container = map.getContainer();
  container.classList.remove('mode-draw', 'mode-paint', 'mode-eraser');

  if (STATE.mode === 'draw' || STATE.mode === 'paint') {
    container.classList.add('mode-draw');
    // Під час малювання карта не рухається (один палець = тільки малювання)
    map.dragging.disable();
    map.doubleClickZoom.disable();
  } else if (STATE.mode === 'eraser') {
    container.classList.add('mode-eraser');
    map.dragging.disable();
    map.doubleClickZoom.disable();
  } else {
    // Режим «Рух карти» — все увімкнено
    map.dragging.enable();
    map.doubleClickZoom.enable();
  }
}

function onMapClick(e) {
  if (STATE.mode === 'pan') return;

  if (STATE.mode === 'draw' || STATE.mode === 'paint') {
    // На миші: кожен клік додає точку в ПОТОЧНУ фігуру.
    // Нова фігура починається тільки після «Завершити» або якщо точок ще немає.
    addPointToCurrentShape(e.latlng);
  } else if (STATE.mode === 'eraser') {
    eraseAt(e.latlng);
  } else if (STATE.mode === 'ruler') {
    handleRulerClick(e.latlng);
  }
}

function onMapMouseMove(e) {
  if ((STATE.mode === 'draw' || STATE.mode === 'paint') && STATE.currentPoints.length > 0) {
    updateTempLine(e.latlng);
  }
}

// ===== TOUCH SUPPORT (мобільне малювання) v0.3 =====
// Оптимізовано під Android 10–16: менше точок, throttle, плавне заповнення
let touchDrawing = false;
let lastTouchLatLng = null;
let lastRedrawTime = 0;
const MIN_POINT_DIST_PX = 18;   // мінімальна відстань між точками (пікселі)
const REDRAW_THROTTLE_MS = 32;  // ~30 fps для прев’ю

function onTouchStart(e) {
  if (STATE.mode === 'pan') return;
  if (e.originalEvent.touches.length !== 1) return;

  e.originalEvent.preventDefault();
  const touch = e.originalEvent.touches[0];
  const latlng = map.mouseEventToLatLng(touch);
  touchDrawing = true;
  window._touchDrawingActive = true;
  lastTouchLatLng = latlng;
  lastRedrawTime = 0;

  if (STATE.mode === 'draw' || STATE.mode === 'paint') {
    // Якщо попередня фігура ще не завершена — спочатку ЗБЕРІГАЄМО її
    if (STATE.currentPoints.length >= 3) {
      finishCurrentShape(); // перша залишається на карті
    } else if (STATE.currentPoints.length > 0) {
      clearTemp(); // занадто мало точок — просто скидаємо
    }
    // Тепер починаємо абсолютно нову фігуру
    addPointToCurrentShape(latlng);
    redrawTempShape();
  } else if (STATE.mode === 'eraser') {
    eraseAt(latlng);
  }
}

function onTouchMove(e) {
  if (!touchDrawing || e.originalEvent.touches.length !== 1) return;
  e.originalEvent.preventDefault();

  const touch = e.originalEvent.touches[0];
  const latlng = map.mouseEventToLatLng(touch);

  if (STATE.mode === 'draw' || STATE.mode === 'paint') {
    // Додаємо точку за піксельною відстанню (стабільніше на Android)
    let shouldAdd = false;
    if (lastTouchLatLng) {
      const p1 = map.latLngToContainerPoint(lastTouchLatLng);
      const p2 = map.latLngToContainerPoint(latlng);
      const distPx = Math.hypot(p2.x - p1.x, p2.y - p1.y);
      if (distPx >= MIN_POINT_DIST_PX) shouldAdd = true;
    } else {
      shouldAdd = true;
    }

    if (shouldAdd) {
      addPointToCurrentShape(latlng);
      lastTouchLatLng = latlng;
    } else {
      // Тільки оновлюємо прев’ю (throttle)
      const now = performance.now();
      if (now - lastRedrawTime > REDRAW_THROTTLE_MS) {
        updateTempLine(latlng);
        lastRedrawTime = now;
      }
    }
  } else if (STATE.mode === 'eraser') {
    eraseAt(latlng);
  }
}

function onTouchEnd(e) {
  if (!touchDrawing) return;
  touchDrawing = false;
  window._touchDrawingActive = false;
  lastTouchLatLng = null;

  // При відпусканні пальця — автоматично завершуємо фігуру
  if ((STATE.mode === 'draw' || STATE.mode === 'paint') && STATE.currentPoints.length >= 3) {
    finishCurrentShape();
  } else if (STATE.currentPoints.length > 0 && STATE.currentPoints.length < 3) {
    cancelCurrentShape();
  }
}
