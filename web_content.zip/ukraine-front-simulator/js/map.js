// ===== MAP INIT =====
let map;
let baseLayerGroup = {};
let overlayLayerGroup = {};
let drawnItems;          // FeatureGroup для всіх полігонів
let markerGroup;         // FeatureGroup для маркерів
let tempGroup;           // тимчасові лінії під час малювання

function initMap() {
  map = L.map('map', {
    center: CONFIG.map.center,
    zoom: CONFIG.map.zoom,
    minZoom: CONFIG.map.minZoom,
    maxZoom: CONFIG.map.maxZoom,
    zoomControl: true,
    attributionControl: true,
    preferCanvas: true   // краща продуктивність при багатьох полігонах
  });

  // Групи шарів
  drawnItems = new L.FeatureGroup().addTo(map);
  markerGroup = new L.FeatureGroup().addTo(map);
  tempGroup = new L.FeatureGroup().addTo(map);

  // Ініціалізація базових шарів
  CONFIG.baseLayers.forEach((layerCfg, idx) => {
    const layer = L.tileLayer(layerCfg.url, {
      attribution: layerCfg.attribution,
      maxZoom: layerCfg.maxZoom || 18,
      subdomains: layerCfg.url.includes('{s}') ? 'abc' : ''
    });
    baseLayerGroup[layerCfg.id] = layer;
    if (idx === 0) layer.addTo(map); // перший шар за замовчуванням
  });

  // Оверлеї
  CONFIG.overlays.forEach(ov => {
    const layer = L.tileLayer(ov.url, {
      attribution: ov.attribution,
      maxZoom: ov.maxZoom || 18,
      opacity: ov.opacity || 0.8,
      subdomains: 'abc'
    });
    overlayLayerGroup[ov.id] = layer;
  });

  // Обробники кліків карти
  map.on('click', onMapClick);
  map.on('mousemove', onMapMouseMove);

  // Мобільна підтримка малювання пальцем
  map.on('touchstart', onTouchStart, { passive: false });
  map.on('touchmove', onTouchMove, { passive: false });
  map.on('touchend', onTouchEnd);

  updateMapCursor();
}

function setBaseLayer(id) {
  Object.values(baseLayerGroup).forEach(l => {
    if (map.hasLayer(l)) map.removeLayer(l);
  });
  if (baseLayerGroup[id]) {
    baseLayerGroup[id].addTo(map);
  }
}

function toggleOverlay(id, enabled) {
  const layer = overlayLayerGroup[id];
  if (!layer) return;
  if (enabled) {
    if (!map.hasLayer(layer)) layer.addTo(map);
  } else {
    if (map.hasLayer(layer)) map.removeLayer(layer);
  }
}

function updateMapCursor() {
  const container = map.getContainer();
  container.classList.remove('mode-draw', 'mode-paint', 'mode-eraser');
  if (STATE.mode === 'draw' || STATE.mode === 'paint') {
    container.classList.add('mode-draw');
  } else if (STATE.mode === 'eraser') {
    container.classList.add('mode-eraser');
  }
}

function onMapClick(e) {
  if (STATE.mode === 'pan') return;

  if (STATE.mode === 'draw' || STATE.mode === 'paint') {
    addPointToCurrentShape(e.latlng);
  } else if (STATE.mode === 'eraser') {
    eraseAt(e.latlng);
  } else if (STATE.mode === 'ruler') {
    handleRulerClick(e.latlng);
  }
}

function onMapMouseMove(e) {
  if ((STATE.mode === 'draw' || STATE.mode === 'paint') && STATE.currentPoints.length > 0) {
    updateTempLine(e.latlng);
  }
}

// ===== TOUCH SUPPORT (мобільне малювання) =====
let touchDrawing = false;
let lastTouchLatLng = null;

function onTouchStart(e) {
  if (STATE.mode === 'pan') return;
  if (e.originalEvent.touches.length !== 1) return; // тільки один палець

  e.originalEvent.preventDefault();
  const touch = e.originalEvent.touches[0];
  const latlng = map.mouseEventToLatLng(touch);
  touchDrawing = true;
  lastTouchLatLng = latlng;

  if (STATE.mode === 'draw' || STATE.mode === 'paint') {
    addPointToCurrentShape(latlng);
  } else if (STATE.mode === 'eraser') {
    eraseAt(latlng);
  }
}

function onTouchMove(e) {
  if (!touchDrawing || e.originalEvent.touches.length !== 1) return;
  e.originalEvent.preventDefault();

  const touch = e.originalEvent.touches[0];
  const latlng = map.mouseEventToLatLng(touch);

  if (STATE.mode === 'draw' || STATE.mode === 'paint') {
    // Додаємо точку тільки якщо відстань достатня (щоб не було занадто багато точок)
    if (lastTouchLatLng && map.distance(lastTouchLatLng, latlng) > 25) {
      addPointToCurrentShape(latlng);
      lastTouchLatLng = latlng;
    } else {
      updateTempLine(latlng);
    }
  } else if (STATE.mode === 'eraser') {
    eraseAt(latlng);
  }
}

function onTouchEnd(e) {
  if (!touchDrawing) return;
  touchDrawing = false;
  lastTouchLatLng = null;

  // При відпусканні пальця в режимі малювання — завершуємо фігуру
  if ((STATE.mode === 'draw' || STATE.mode === 'paint') && STATE.currentPoints.length >= 3) {
    finishCurrentShape();
  }
}
