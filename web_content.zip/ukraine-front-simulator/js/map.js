// ===== MAP INIT =====
let map;
let baseLayerGroup = {};
let overlayLayerGroup = {};
let drawnItems;          // FeatureGroup для всіх полігонів
let markerGroup;         // FeatureGroup для маркерів
let tempGroup;           // тимчасові лінії під час малювання

function detectLowEnd() {
  // Samsung A6 / Android 10 та подібні слабкі пристрої
  try {
    const mem = navigator.deviceMemory || 4; // GB, якщо підтримується
    const cores = navigator.hardwareConcurrency || 4;
    const ua = (navigator.userAgent || '').toLowerCase();
    const isOldAndroid = /android [5-9]|android 10/.test(ua);
    const isWeak = mem <= 2 || cores <= 4 || isOldAndroid;
    return isWeak;
  } catch (e) {
    return true; // на сумнів — вважаємо слабким
  }
}

function initMap() {
  STATE.lowEnd = detectLowEnd();

  const maxZ = STATE.lowEnd ? 14 : CONFIG.map.maxZoom;
  const wheelPx = STATE.lowEnd ? 120 : 60;

  map = L.map('map', {
    center: CONFIG.map.center,
    zoom: CONFIG.map.zoom,
    minZoom: CONFIG.map.minZoom,
    maxZoom: maxZ,
    zoomControl: !STATE.lowEnd, // на слабких — менше DOM
    attributionControl: false,
    preferCanvas: true,
    fadeAnimation: !STATE.lowEnd,
    zoomAnimation: !STATE.lowEnd,
    markerZoomAnimation: !STATE.lowEnd,
    inertia: !STATE.lowEnd,
    easeLinearity: 0.4,
    wheelPxPerZoomLevel: wheelPx
  });

  // Групи шарів (canvas для полігонів на слабких)
  drawnItems = new L.FeatureGroup().addTo(map);
  markerGroup = new L.FeatureGroup().addTo(map);
  tempGroup = new L.FeatureGroup().addTo(map);

  // Тайли: на слабких — тільки OSM, без оверлеїв за замовчуванням
  const layersToInit = STATE.lowEnd
    ? CONFIG.baseLayers.filter(function (l) { return l.id === 'osm'; })
    : CONFIG.baseLayers;

  if (!layersToInit.length) layersToInit.push(CONFIG.baseLayers[0]);

  layersToInit.forEach(function (layerCfg, idx) {
    const layer = L.tileLayer(layerCfg.url, {
      attribution: layerCfg.attribution || '',
      maxZoom: STATE.lowEnd ? 14 : (layerCfg.maxZoom || 18),
      minZoom: 4,
      subdomains: layerCfg.url.indexOf('{s}') >= 0 ? 'abc' : '',
      updateWhenIdle: true,          // не оновлювати під час жесту
      updateWhenZooming: false,      // критично для слабких CPU
      keepBuffer: STATE.lowEnd ? 1 : 2,
      crossOrigin: true
    });
    baseLayerGroup[layerCfg.id] = layer;
    if (idx === 0) layer.addTo(map);
  });

  // Оверлеї — тільки на нормальних пристроях
  if (!STATE.lowEnd) {
    CONFIG.overlays.forEach(function (ov) {
      const layer = L.tileLayer(ov.url, {
        attribution: ov.attribution || '',
        maxZoom: ov.maxZoom || 18,
        opacity: ov.opacity || 0.8,
        subdomains: 'abc',
        updateWhenIdle: true,
        updateWhenZooming: false
      });
      overlayLayerGroup[ov.id] = layer;
    });
  }

  map.on('click', onMapClick);
  if (!STATE.lowEnd) {
    map.on('mousemove', onMapMouseMove);
  }

  map.on('touchstart', onTouchStart, { passive: false });
  map.on('touchmove', onTouchMove, { passive: false });
  map.on('touchend', onTouchEnd);
  map.on('touchcancel', onTouchEnd);

  // На слабких — вимикаємо анімації за замовчуванням
  if (STATE.lowEnd) {
    STATE.animEnabled = false;
    const animCb = document.getElementById('anim-enabled');
    if (animCb) animCb.checked = false;
  }

  updateMapCursor();
}

function setBaseLayer(id) {
  Object.values(baseLayerGroup).forEach(l => {
    if (map.hasLayer(l)) map.removeLayer(l);
  });
  if (baseLayerGroup[id]) {
    baseLayerGroup[id].addTo(map);
  }
}

function toggleOverlay(id, enabled) {
  const layer = overlayLayerGroup[id];
  if (!layer) return;
  if (enabled) {
    if (!map.hasLayer(layer)) layer.addTo(map);
  } else {
    if (map.hasLayer(layer)) map.removeLayer(layer);
  }
}

function updateMapCursor() {
  const container = map.getContainer();
  container.classList.remove('mode-draw', 'mode-paint', 'mode-eraser');

  if (STATE.mode === 'draw' || STATE.mode === 'paint') {
    container.classList.add('mode-draw');
    // Під час малювання карта не рухається (один палець = тільки малювання)
    map.dragging.disable();
    map.doubleClickZoom.disable();
  } else if (STATE.mode === 'eraser') {
    container.classList.add('mode-eraser');
    map.dragging.disable();
    map.doubleClickZoom.disable();
  } else {
    // Режим «Рух карти» — все увімкнено
    map.dragging.enable();
    map.doubleClickZoom.enable();
  }
}

function onMapClick(e) {
  if (STATE.mode === 'pan') return;

  if (STATE.mode === 'draw' || STATE.mode === 'paint') {
    // На миші: кожен клік додає точку в ПОТОЧНУ фігуру.
    // Нова фігура починається тільки після «Завершити» або якщо точок ще немає.
    addPointToCurrentShape(e.latlng);
  } else if (STATE.mode === 'eraser') {
    eraseAt(e.latlng);
  } else if (STATE.mode === 'ruler') {
    handleRulerClick(e.latlng);
  }
}

function onMapMouseMove(e) {
  if ((STATE.mode === 'draw' || STATE.mode === 'paint') && STATE.currentPoints.length > 0) {
    updateTempLine(e.latlng);
  }
}

// ===== TOUCH SUPPORT v0.4 — оптимізація під слабкі Android =====
let touchDrawing = false;
let lastTouchLatLng = null;
let lastRedrawTime = 0;
// На слабких (A6 тощо) — менше точок і рідше прев’ю
function minPointDist() { return (STATE.lowEnd ? 28 : 16); }
function redrawThrottle() { return (STATE.lowEnd ? 64 : 32); }

function onTouchStart(e) {
  if (STATE.mode === 'pan') return;
  if (e.originalEvent.touches.length !== 1) return;

  e.originalEvent.preventDefault();
  const touch = e.originalEvent.touches[0];
  const latlng = map.mouseEventToLatLng(touch);
  touchDrawing = true;
  window._touchDrawingActive = true;
  lastTouchLatLng = latlng;
  lastRedrawTime = 0;

  if (STATE.mode === 'draw' || STATE.mode === 'paint') {
    // Якщо попередня фігура ще не завершена — спочатку ЗБЕРІГАЄМО її
    if (STATE.currentPoints.length >= 3) {
      finishCurrentShape(); // перша залишається на карті
    } else if (STATE.currentPoints.length > 0) {
      clearTemp(); // занадто мало точок — просто скидаємо
    }
    // Тепер починаємо абсолютно нову фігуру
    addPointToCurrentShape(latlng);
    redrawTempShape();
  } else if (STATE.mode === 'eraser') {
    eraseAt(latlng);
  }
}

function onTouchMove(e) {
  if (!touchDrawing || e.originalEvent.touches.length !== 1) return;
  e.originalEvent.preventDefault();

  const touch = e.originalEvent.touches[0];
  const latlng = map.mouseEventToLatLng(touch);

  if (STATE.mode === 'draw' || STATE.mode === 'paint') {
    // Додаємо точку за піксельною відстанню (стабільніше на Android)
    let shouldAdd = false;
    if (lastTouchLatLng) {
      const p1 = map.latLngToContainerPoint(lastTouchLatLng);
      const p2 = map.latLngToContainerPoint(latlng);
      const distPx = Math.hypot(p2.x - p1.x, p2.y - p1.y);
      if (distPx >= minPointDist()) shouldAdd = true;
    } else {
      shouldAdd = true;
    }

    if (shouldAdd) {
      addPointToCurrentShape(latlng);
      lastTouchLatLng = latlng;
    } else {
      // Тільки оновлюємо прев’ю (throttle)
      const now = performance.now();
      if (now - lastRedrawTime > redrawThrottle()) {
        updateTempLine(latlng);
        lastRedrawTime = now;
      }
    }
  } else if (STATE.mode === 'eraser') {
    eraseAt(latlng);
  }
}

function onTouchEnd(e) {
  if (!touchDrawing) return;
  touchDrawing = false;
  window._touchDrawingActive = false;
  lastTouchLatLng = null;

  // При відпусканні пальця — автоматично завершуємо фігуру
  if ((STATE.mode === 'draw' || STATE.mode === 'paint') && STATE.currentPoints.length >= 3) {
    finishCurrentShape();
  } else if (STATE.currentPoints.length > 0 && STATE.currentPoints.length < 3) {
    cancelCurrentShape();
  }
}
