// ===== MAP INIT =====
let map;
let baseLayerGroup = {};
let overlayLayerGroup = {};
let drawnItems;          // FeatureGroup для всіх полігонів
let markerGroup;         // FeatureGroup для маркерів
let tempGroup;           // тимчасові лінії під час малювання

function detectLowEnd() {
  // Samsung A6 / Android 10 та подібні слабкі пристрої
  try {
    const mem = navigator.deviceMemory || 4; // GB, якщо підтримується
    const cores = navigator.hardwareConcurrency || 4;
    const ua = (navigator.userAgent || '').toLowerCase();
    const isOldAndroid = /android [5-9]|android 10/.test(ua);
    const isWeak = mem <= 2 || cores <= 4 || isOldAndroid;
    return isWeak;
  } catch (e) {
    return true; // на сумнів — вважаємо слабким
  }
}

function initMap() {
  STATE.lowEnd = detectLowEnd();

  const maxZ = STATE.lowEnd ? 14 : CONFIG.map.maxZoom;
  const wheelPx = STATE.lowEnd ? 120 : 60;

  map = L.map('map', {
    center: CONFIG.map.center,
    zoom: CONFIG.map.zoom,
    minZoom: CONFIG.map.minZoom,
    maxZoom: maxZ,
    zoomControl: !STATE.lowEnd, // на слабких — менше DOM
    attributionControl: false,
    preferCanvas: true,
    fadeAnimation: !STATE.lowEnd,
    zoomAnimation: !STATE.lowEnd,
    markerZoomAnimation: !STATE.lowEnd,
    inertia: !STATE.lowEnd,
    easeLinearity: 0.4,
    wheelPxPerZoomLevel: wheelPx
  });

  // Групи шарів (canvas для полігонів на слабких)
  drawnItems = new L.FeatureGroup().addTo(map);
  markerGroup = new L.FeatureGroup().addTo(map);
  tempGroup = new L.FeatureGroup().addTo(map);

  // Тайли: на слабких — тільки OSM, без оверлеїв за замовчуванням
  const layersToInit = STATE.lowEnd
    ? CONFIG.baseLayers.filter(function (l) { return l.id === 'osm'; })
    : CONFIG.baseLayers;

  if (!layersToInit.length) layersToInit.push(CONFIG.baseLayers[0]);

  layersToInit.forEach(function (layerCfg, idx) {
    const layer = L.tileLayer(layerCfg.url, {
      attribution: layerCfg.attribution || '',
      maxZoom: STATE.lowEnd ? 14 : (layerCfg.maxZoom || 18),
      minZoom: 4,
      subdomains: layerCfg.url.indexOf('{s}') >= 0 ? 'abc' : '',
      updateWhenIdle: true,          // не оновлювати під час жесту
      updateWhenZooming: false,      // критично для слабких CPU
      keepBuffer: STATE.lowEnd ? 1 : 2,
      crossOrigin: true
    });
    baseLayerGroup[layerCfg.id] = layer;
    if (idx === 0) layer.addTo(map);
  });

  // Оверлеї — тільки на нормальних пристроях
  if (!STATE.lowEnd) {
    CONFIG.overlays.forEach(function (ov) {
      const layer = L.tileLayer(ov.url, {
        attribution: ov.attribution || '',
        maxZoom: ov.maxZoom || 18,
        opacity: ov.opacity || 0.8,
        subdomains: 'abc',
        updateWhenIdle: true,
        updateWhenZooming: false
      });
      overlayLayerGroup[ov.id] = layer;
    });
  }

  map.on('click', onMapClick);
  if (!STATE.lowEnd) {
    map.on('mousemove', onMapMouseMove);
  }

  // ТІЛЬКИ нативні touch-слухачі (Leaflet touchend в WebView/APK ненадійний)
  // На слабких — вимикаємо анімації за замовчуванням
  if (STATE.lowEnd) {
    STATE.animEnabled = false;
    const animCb = document.getElementById('anim-enabled');
    if (animCb) animCb.checked = false;
  }

  updateMapCursor();
  bindNativeTouch(); // ОБОВ'ЯЗКОВО — інакше відпускання пальця не ловиться
}

function setBaseLayer(id) {
  Object.values(baseLayerGroup).forEach(l => {
    if (map.hasLayer(l)) map.removeLayer(l);
  });
  if (baseLayerGroup[id]) {
    baseLayerGroup[id].addTo(map);
  }
}

function toggleOverlay(id, enabled) {
  const layer = overlayLayerGroup[id];
  if (!layer) return;
  if (enabled) {
    if (!map.hasLayer(layer)) layer.addTo(map);
  } else {
    if (map.hasLayer(layer)) map.removeLayer(layer);
  }
}

function updateMapCursor() {
  const container = map.getContainer();
  container.classList.remove('mode-draw', 'mode-paint', 'mode-eraser');

  if (STATE.mode === 'draw' || STATE.mode === 'paint') {
    container.classList.add('mode-draw');
    // Під час малювання карта не рухається (один палець = тільки малювання)
    map.dragging.disable();
    map.doubleClickZoom.disable();
  } else if (STATE.mode === 'eraser') {
    container.classList.add('mode-eraser');
    map.dragging.disable();
    map.doubleClickZoom.disable();
  } else {
    // Режим «Рух карти» — все увімкнено
    map.dragging.enable();
    map.doubleClickZoom.enable();
  }
}

function onMapClick(e) {
  if (STATE.mode === 'pan') return;

  if (STATE.mode === 'draw' || STATE.mode === 'paint') {
    // На миші: кожен клік додає точку в ПОТОЧНУ фігуру.
    // Нова фігура починається тільки після «Завершити» або якщо точок ще немає.
    addPointToCurrentShape(e.latlng);
  } else if (STATE.mode === 'eraser') {
    eraseAt(e.latlng);
  } else if (STATE.mode === 'ruler') {
    handleRulerClick(e.latlng);
  }
}

function onMapMouseMove(e) {
  if ((STATE.mode === 'draw' || STATE.mode === 'paint') && STATE.currentPoints.length > 0) {
    updateTempLine(e.latlng);
  }
}

// ===== TOUCH SUPPORT v0.4.6 — надійне відпускання на Android WebView =====
let touchDrawing = false;
let lastTouchLatLng = null;
let lastRedrawTime = 0;
let finishLock = false;

function minPointDist() { return (STATE.lowEnd ? 12 : 8); }
function redrawThrottle() { return (STATE.lowEnd ? 50 : 30); }

function getLatLngFromTouch(touch) {
  return map.mouseEventToLatLng(touch);
}

function beginDrawAt(latlng) {
  if (STATE.mode !== 'draw' && STATE.mode !== 'paint') return;
  // Якщо залишились точки після збою endDraw — завершити їх ЗАРАЗ
  if (STATE.currentPoints.length >= 3) {
    finishCurrentShape();
  } else if (STATE.currentPoints.length > 0) {
    clearTemp();
  }
  touchDrawing = true;
  window._touchDrawingActive = true;
  lastTouchLatLng = latlng;
  lastRedrawTime = 0;
  finishLock = false;
  addPointToCurrentShape(latlng);
  redrawTempShape();
}

function moveDrawTo(latlng) {
  if (!touchDrawing) return;
  if (STATE.mode !== 'draw' && STATE.mode !== 'paint') return;

  let shouldAdd = false;
  if (lastTouchLatLng) {
    const p1 = map.latLngToContainerPoint(lastTouchLatLng);
    const p2 = map.latLngToContainerPoint(latlng);
    if (Math.hypot(p2.x - p1.x, p2.y - p1.y) >= minPointDist()) shouldAdd = true;
  } else {
    shouldAdd = true;
  }

  if (shouldAdd) {
    addPointToCurrentShape(latlng);
    lastTouchLatLng = latlng;
    const now = performance.now();
    if (now - lastRedrawTime > redrawThrottle()) {
      redrawTempShape();
      lastRedrawTime = now;
    }
  } else {
    const now = performance.now();
    if (now - lastRedrawTime > redrawThrottle()) {
      updateTempLine(latlng);
      lastRedrawTime = now;
    }
  }
}

function endDraw() {
  // Навіть якщо прапорці збиті — якщо є точки, завершуємо
  const pts = STATE.currentPoints ? STATE.currentPoints.length : 0;
  const was = touchDrawing || window._touchDrawingActive || pts > 0;
  if (!was) return;
  if (finishLock) return;
  finishLock = true;

  touchDrawing = false;
  window._touchDrawingActive = false;
  lastTouchLatLng = null;

  try {
    if (STATE.mode === 'draw' || STATE.mode === 'paint' || pts >= 3) {
      if (pts >= 3) {
        finishCurrentShape(); // відпустив = заливка ОДРАЗУ
      } else if (pts > 0) {
        cancelCurrentShape();
      }
    }
  } catch (err) {
    console.warn('endDraw', err);
    try { cancelCurrentShape(); } catch (e2) {}
  } finally {
    setTimeout(function () { finishLock = false; }, 80);
  }
}

// Leaflet-події (fallback)
function onTouchStart(e) {
  if (STATE.mode === 'pan') return;
  if (!e.originalEvent || !e.originalEvent.touches || e.originalEvent.touches.length !== 1) return;
  e.originalEvent.preventDefault();
  beginDrawAt(getLatLngFromTouch(e.originalEvent.touches[0]));
}

function onTouchMove(e) {
  if (!touchDrawing) return;
  if (!e.originalEvent || !e.originalEvent.touches || e.originalEvent.touches.length !== 1) return;
  e.originalEvent.preventDefault();
  moveDrawTo(getLatLngFromTouch(e.originalEvent.touches[0]));
}

function onTouchEnd(e) {
  endDraw();
}

/** Нативні touch — єдине джерело жестів (працює в APK WebView) */
function bindNativeTouch() {
  const el = map.getContainer();
  if (!el || el._ffTouchBound) return;
  el._ffTouchBound = true;

  el.addEventListener('touchstart', function (ev) {
    if (STATE.mode === 'pan') return;
    if (ev.touches.length !== 1) return;
    if (STATE.mode !== 'draw' && STATE.mode !== 'paint' && STATE.mode !== 'eraser') return;
    ev.preventDefault();
    ev.stopPropagation();
    try { map.dragging.disable(); } catch (e) {}
    const latlng = getLatLngFromTouch(ev.touches[0]);
    if (STATE.mode === 'eraser') {
      touchDrawing = true;
      window._touchDrawingActive = true;
      eraseAt(latlng);
      return;
    }
    beginDrawAt(latlng);
  }, { passive: false, capture: true });

  el.addEventListener('touchmove', function (ev) {
    if (!touchDrawing && !window._touchDrawingActive) return;
    if (ev.touches.length !== 1) {
      // Другий палець — не завершуємо малювання, просто ігноруємо
      return;
    }
    ev.preventDefault();
    ev.stopPropagation();
    const latlng = getLatLngFromTouch(ev.touches[0]);
    if (STATE.mode === 'eraser') {
      eraseAt(latlng);
      return;
    }
    moveDrawTo(latlng);
  }, { passive: false, capture: true });

  function onFingerUp(ev) {
    // Якщо ще є інші пальці — не завершуємо
    if (ev.touches && ev.touches.length > 0) return;
    endDraw();
  }

  // І на карті, і на document, capture — щоб нічого не з’їло подію
  el.addEventListener('touchend', onFingerUp, { passive: false, capture: true });
  el.addEventListener('touchcancel', onFingerUp, { passive: false, capture: true });
  document.addEventListener('touchend', onFingerUp, { passive: false, capture: true });
  document.addEventListener('touchcancel', onFingerUp, { passive: false, capture: true });
  window.addEventListener('touchend', onFingerUp, { passive: false, capture: true });
}

