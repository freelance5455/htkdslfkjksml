// ===== CONFIG =====
const CONFIG = {
  version: '0.4.2',
  appName: 'FOREFRONT',

  // DeepStateMap data (GitHub mirror)
  deepState: {
    baseUrl: 'https://raw.githubusercontent.com/cyterat/deepstate-map-data/main/data/',
    latestKnown: 'deepstatemap_data_20261008.geojson',
    // формат файлу: deepstatemap_data_YYYYMMDD.geojson
  },

  // Початковий вид карти
  map: {
    center: [48.5, 31.5],   // центр України
    zoom: 6,
    minZoom: 4,
    maxZoom: 18
  },

  // Кольори категорій
  colors: {
    liberated: {
      fill: '#3b82f6',
      stroke: '#1d4ed8',
      fillOpacity: 0.55,
      weight: 2
    },
    occupied: {
      fill: '#ef4444',
      stroke: '#b91c1c',
      fillOpacity: 0.55,
      weight: 2
    },
    fighting: {
      fill: '#94a3b8',
      stroke: '#64748b',
      fillOpacity: 0.45,
      weight: 2,
      dashArray: '6 4'
    }
  },

  // Базові тайлові шари
  baseLayers: [
    {
      id: 'osm',
      name: 'OSM · Стандарт',
      url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
      attribution: '© OpenStreetMap',
      maxZoom: 19
    },
    {
      id: 'osm-fr',
      name: 'OSM · Французький стиль',
      url: 'https://{s}.tile.openstreetmap.fr/osmfr/{z}/{x}/{y}.png',
      attribution: '© OpenStreetMap France',
      maxZoom: 20
    },
    {
      id: 'osm-de',
      name: 'OSM · Німецький стиль',
      url: 'https://{s}.tile.openstreetmap.de/{z}/{x}/{y}.png',
      attribution: '© OpenStreetMap Deutschland',
      maxZoom: 18
    },
    {
      id: 'carto-light',
      name: 'Carto · Світла',
      url: 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png',
      attribution: '© CARTO',
      maxZoom: 20
    },
    {
      id: 'carto-dark',
      name: 'Carto · Темна',
      url: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
      attribution: '© CARTO',
      maxZoom: 20
    },
    {
      id: 'topo',
      name: 'OpenTopoMap · Рельєф',
      url: 'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png',
      attribution: '© OpenTopoMap',
      maxZoom: 17
    },
    {
      id: 'esri-street',
      name: 'Esri · Вулиці',
      url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}',
      attribution: '© Esri',
      maxZoom: 19
    },
    {
      id: 'esri-topo',
      name: 'Esri · Топографічна',
      url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}',
      attribution: '© Esri',
      maxZoom: 19
    },
    {
      id: 'esri-natgeo',
      name: 'Esri · National Geographic',
      url: 'https://server.arcgisonline.com/ArcGIS/rest/services/NatGeo_World_Map/MapServer/tile/{z}/{y}/{x}',
      attribution: '© Esri / NatGeo',
      maxZoom: 16
    },
    {
      id: 'esri-imagery',
      name: 'Esri · Супутник',
      url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
      attribution: '© Esri',
      maxZoom: 19
    },
    {
      id: 'esri-relief',
      name: 'Esri · Рельєф місцевості',
      url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Shaded_Relief/MapServer/tile/{z}/{y}/{x}',
      attribution: '© Esri',
      maxZoom: 13
    },
    {
      id: 'esri-physical',
      name: 'Esri · Фізична карта',
      url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Physical_Map/MapServer/tile/{z}/{y}/{x}',
      attribution: '© Esri',
      maxZoom: 8
    }
  ],

  // Накладання (оверлеї)
  overlays: [
    {
      id: 'labels',
      name: 'Підписи (Carto)',
      url: 'https://{s}.basemaps.cartocdn.com/light_only_labels/{z}/{x}/{y}{r}.png',
      attribution: '© CARTO',
      maxZoom: 20,
      opacity: 0.9
    },
    {
      id: 'rail',
      name: 'Залізниці (OpenRailwayMap)',
      url: 'https://{s}.tiles.openrailwaymap.org/standard/{z}/{x}/{y}.png',
      attribution: '© OpenRailwayMap',
      maxZoom: 19,
      opacity: 0.8
    }
  ],

  // Значення за замовчуванням
  defaults: {
    stripWidthKm: 2.0,
    animDuration: 1.5,
    polyOpacity: 0.55
  }
};

// Глобальний стан додатку
const STATE = {
  mode: 'pan',           // pan | draw | paint | eraser
  category: 'liberated', // liberated | occupied | fighting
  currentPoints: [],     // точки поточної фігури
  currentPolyline: null,
  currentPolygon: null,
  shapes: [],            // усі завершені полігони {id, category, layer, geojson, area}
  markers: [],           // маркери {id, type, layer, latlng}
  history: [],           // історія для undo
  historyIndex: -1,
  stripWidth: CONFIG.defaults.stripWidthKm,
  animEnabled: true,
  animDuration: CONFIG.defaults.animDuration,
  polyOpacity: CONFIG.defaults.polyOpacity,
  autoStrip: false,
  lowEnd: false,
  rulerPoints: [],
  rulerLine: null,
  rulerMarkers: []
};


/** Leaflet-сумісний стиль для категорії */
function styleForCategory(cat, opacity) {
  const c = CONFIG.colors[cat] || CONFIG.colors.occupied;
  return {
    color: c.stroke,
    fillColor: c.fill,
    fillOpacity: opacity != null ? opacity : (STATE.polyOpacity || 0.55),
    weight: c.weight || 2,
    opacity: 1,
    dashArray: c.dashArray || null
  };
}
