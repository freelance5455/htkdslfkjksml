// ===== DAILY QUESTS & COINS (v0.2) =====

const QUESTS_POOL = [
  { id: 'cap_kharkiv', title: 'Звільнити Харків', city: 'Харків', side: 'liberated', reward: 40, desc: 'Захопіть місто Харків під контроль УА' },
  { id: 'cap_donetsk', title: 'Захопити Донецьк', city: 'Донецьк', side: 'occupied', reward: 50, desc: 'Взяти Донецьк під контроль РФ' },
  { id: 'cap_kherson', title: 'Звільнити Херсон', city: 'Херсон', side: 'liberated', reward: 35, desc: 'Повернути Херсон під контроль УА' },
  { id: 'cap_zaporizhzhia', title: 'Захистити Запоріжжя', city: 'Запоріжжя', side: 'liberated', reward: 30, desc: 'Утримати Запоріжжя' },
  { id: 'cap_mariupol', title: 'Звільнити Маріуполь', city: 'Маріуполь', side: 'liberated', reward: 45, desc: 'Повернути Маріуполь' },
  { id: 'cap_luhansk', title: 'Захопити Луганськ', city: 'Луганськ', side: 'occupied', reward: 40, desc: 'Взяти Луганськ' },
  { id: 'cap_melitopol', title: 'Звільнити Мелітополь', city: 'Мелітополь', side: 'liberated', reward: 30, desc: 'Звільнити Мелітополь' },
  { id: 'cap_bakhmut', title: 'Повернути Бахмут', city: 'Бахмут', side: 'liberated', reward: 35, desc: 'Звільнити Бахмут' },
  { id: 'cap_avdiivka', title: 'Утримати Авдіївку', city: 'Авдіївка', side: 'liberated', reward: 25, desc: 'Захистити Авдіївку' },
  { id: 'cap_kryvyi_rih', title: 'Захистити Кривий Ріг', city: 'Кривий Ріг', side: 'liberated', reward: 25, desc: 'Утримати Кривий Ріг' },
  { id: 'area_liberated', title: 'Звільнити 500 км²', type: 'area', category: 'liberated', target: 500, reward: 30, desc: 'Звільнити сумарно 500 км²' },
  { id: 'area_occupied', title: 'Захопити 300 км²', type: 'area', category: 'occupied', target: 300, reward: 25, desc: 'Захопити 300 км² під окупацію' },
  { id: 'place_flags', title: 'Поставити 5 прапорів', type: 'flags', target: 5, reward: 20, desc: 'Розмістити 5 прапорів на карті' }
];

let activeQuests = [];
let coins = 0;
let completedQuestIds = new Set();

function loadCoinsAndQuests() {
  try {
    const saved = JSON.parse(localStorage.getItem('forefront-quests') || '{}');
    coins = saved.coins || 0;
    completedQuestIds = new Set(saved.completed || []);
    const today = new Date().toDateString();
    if (saved.date === today && saved.quests) {
      activeQuests = saved.quests;
    } else {
      generateDailyQuests();
    }
  } catch (e) {
    generateDailyQuests();
  }
  updateCoinsUI();
  renderQuests();
}

function saveQuestsState() {
  localStorage.setItem('forefront-quests', JSON.stringify({
    coins,
    completed: [...completedQuestIds],
    quests: activeQuests,
    date: new Date().toDateString()
  }));
}

function generateDailyQuests() {
  // Вибираємо 3 випадкові завдання
  const shuffled = [...QUESTS_POOL].sort(() => Math.random() - 0.5);
  activeQuests = shuffled.slice(0, 3).map(q => ({
    ...q,
    progress: 0,
    completed: false
  }));
  saveQuestsState();
  renderQuests();
}

function updateCoinsUI() {
  const el = document.getElementById('coins-value');
  if (el) el.textContent = coins;
}

function addCoins(amount) {
  coins += amount;
  updateCoinsUI();
  saveQuestsState();
  if (typeof hwUpdateUI === 'function') hwUpdateUI();
  addChronoEvent({ type: 'system', text: `+${amount} 🍬 цукерок` });
}

function renderQuests() {
  const list = document.getElementById('quests-list');
  if (!list) return;
  list.innerHTML = '';

  activeQuests.forEach(q => {
    const div = document.createElement('div');
    div.className = 'quest-item' + (q.completed ? ' completed' : '');
    let progressText = '';
    if (q.type === 'area') {
      progressText = `${Math.min(q.progress, q.target).toFixed(0)} / ${q.target} км²`;
    } else if (q.type === 'flags') {
      progressText = `${q.progress} / ${q.target}`;
    } else {
      progressText = q.completed ? 'Виконано ✓' : 'Не виконано';
    }
    div.innerHTML = `
      <div class="quest-title">${q.title}</div>
      <div class="quest-reward">Нагорода: ${q.reward} 🍬</div>
      <div class="quest-progress">${progressText}</div>
    `;
    list.appendChild(div);
  });
}

function checkQuestProgress() {
  let changed = false;

  activeQuests.forEach(q => {
    if (q.completed) return;

    if (q.type === 'area') {
      const total = STATE.shapes
        .filter(s => s.category === q.category)
        .reduce((sum, s) => sum + s.area, 0);
      q.progress = total;
      if (total >= q.target) {
        completeQuest(q);
        changed = true;
      }
    } else if (q.type === 'flags') {
      q.progress = STATE.markers.filter(m => m.type.startsWith('flag')).length;
      if (q.progress >= q.target) {
        completeQuest(q);
        changed = true;
      }
    } else if (q.city) {
      // Перевірка захоплення міста
      const city = CITIES.find(c => c.name === q.city);
      if (city && city.control === q.side) {
        completeQuest(q);
        changed = true;
      }
    }
  });

  if (changed) {
    renderQuests();
    saveQuestsState();
  }
}

function completeQuest(q) {
  if (q.completed) return;
  q.completed = true;
  completedQuestIds.add(q.id);
  addCoins(q.reward);
  addChronoEvent({
    type: 'system',
    text: `Завдання виконано: ${q.title} (+${q.reward} 🍬)`
  });
}

function initQuestsUI() {
  document.getElementById('menu-dots-btn').addEventListener('click', () => {
    document.getElementById('quests-panel').classList.toggle('hidden');
  });
}
