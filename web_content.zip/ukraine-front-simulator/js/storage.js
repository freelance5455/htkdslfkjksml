// ===== SAVE / LOAD =====

function saveToFile() {
  const data = {
    version: 1,
    savedAt: new Date().toISOString(),
    shapes: STATE.shapes.map(s => ({
      id: s.id,
      category: s.category,
      geojson: s.geojson,
      area: s.area,
      timestamp: s.timestamp
    })),
    markers: STATE.markers.map(m => ({
      id: m.id,
      type: m.type,
      latlng: m.latlng
    })),
    settings: {
      stripWidth: STATE.stripWidth,
      animEnabled: STATE.animEnabled,
      animDuration: STATE.animDuration,
      polyOpacity: STATE.polyOpacity
    }
  };

  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `front-map-${new Date().toISOString().slice(0, 10)}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);

  addChronoEvent({ type: 'system', text: 'Карту збережено у файл' });
}

function loadFromFile(file) {
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const data = JSON.parse(e.target.result);
      // Якщо ще на стартовому екрані — запускаємо гру
      if (!document.body.classList.contains('game-started')) {
        document.body.classList.add('game-started');
        document.getElementById('start-screen').classList.add('hidden');
        if (typeof initCities === 'function') initCities();
      }
      applyLoadedData(data);
      if (typeof updateCityControl === 'function') updateCityControl();
      addChronoEvent({ type: 'system', text: 'Карту завантажено з файлу' });
      if (typeof map !== 'undefined') map.invalidateSize();
    } catch (err) {
      alert('Помилка читання файлу: ' + err.message);
    }
  };
  reader.readAsText(file);
}

function applyLoadedData(data) {
  // Очищаємо
  drawnItems.clearLayers();
  markerGroup.clearLayers();
  STATE.shapes = [];
  STATE.markers = [];
  clearTemp();

  // Полігони
  (data.shapes || []).forEach(s => {
    try {
      const coords = s.geojson.geometry.coordinates[0].map(c => [c[1], c[0]]);
      const style = {
        ...CONFIG.colors[s.category],
        fillOpacity: (data.settings && data.settings.polyOpacity) || STATE.polyOpacity
      };
      const poly = L.polygon(coords, style).addTo(drawnItems);
      STATE.shapes.push({
        id: s.id,
        category: s.category,
        layer: poly,
        geojson: s.geojson,
        area: s.area,
        timestamp: s.timestamp || Date.now()
      });
    } catch (e) {
      console.warn('Skip shape', e);
    }
  });

  // Маркери
  (data.markers || []).forEach(m => {
    placeMarkerSilent(m.type, m.latlng, m.id);
  });

  // Налаштування
  if (data.settings) {
    if (data.settings.stripWidth != null) {
      STATE.stripWidth = data.settings.stripWidth;
      document.getElementById('strip-width').value = STATE.stripWidth;
      document.getElementById('strip-value').textContent = STATE.stripWidth.toFixed(1) + ' км';
    }
    if (data.settings.animDuration != null) {
      STATE.animDuration = data.settings.animDuration;
      document.getElementById('anim-speed').value = STATE.animDuration;
      document.getElementById('anim-value').textContent = STATE.animDuration.toFixed(1) + ' с';
    }
    if (data.settings.polyOpacity != null) {
      STATE.polyOpacity = data.settings.polyOpacity;
    }
  }

  pushHistory();
  updateStats();
}

function clearAll() {
  if (!confirm('Очистити всі фігури, маркери та хронологію?')) return;

  drawnItems.clearLayers();
  markerGroup.clearLayers();
  clearTemp();
  clearRuler();
  STATE.shapes = [];
  STATE.markers = [];
  STATE.history = [];
  STATE.historyIndex = -1;
  clearChronology();
  updateStats();
  addChronoEvent({ type: 'system', text: 'Все очищено' });
}

// Автозбереження в localStorage
function autoSave() {
  try {
    const data = {
      shapes: STATE.shapes.map(s => ({
        id: s.id,
        category: s.category,
        geojson: s.geojson,
        area: s.area
      })),
      markers: STATE.markers.map(m => ({
        id: m.id,
        type: m.type,
        latlng: m.latlng
      }))
    };
    localStorage.setItem('front-sim-autosave', JSON.stringify(data));
  } catch (e) {}
}

function tryAutoLoad() {
  try {
    const raw = localStorage.getItem('front-sim-autosave');
    if (raw) {
      const data = JSON.parse(raw);
      if (data.shapes && data.shapes.length) {
        // Не завантажуємо автоматично — лише пропонуємо
        // applyLoadedData(data);
      }
    }
  } catch (e) {}
}
