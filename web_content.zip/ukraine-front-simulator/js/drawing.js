// ===== DRAWING LOGIC =====
// v0.3 — плавне захоплення пальцем + оптимізація Android

function addPointToCurrentShape(latlng) {
  STATE.currentPoints.push([latlng.lat, latlng.lng]);
  // Не перемальовуємо на кожну точку під час touch — тільки через throttle в map.js
  // Але для миші малюємо одразу
  if (!window._touchDrawingActive) {
    redrawTempShape();
  }
}

function updateTempLine(latlng) {
  if (STATE.currentPoints.length === 0) return;
  redrawTempShape(latlng);
}

/** Прев’ю як у оригіналі: пунктир + напівпрозора заливка */
function redrawTempShape(hoverLatLng) {
  tempGroup.clearLayers();

  const pts = hoverLatLng
    ? [...STATE.currentPoints, [hoverLatLng.lat, hoverLatLng.lng]]
    : [...STATE.currentPoints];

  if (pts.length < 2) {
    STATE.currentPoints.forEach(pt => {
      L.circleMarker(pt, {
        radius: 4,
        color: CONFIG.colors[STATE.category].stroke,
        fillColor: '#fff',
        fillOpacity: 1,
        weight: 2
      }).addTo(tempGroup);
    });
    return;
  }

  // Пунктирна лінія (як на відео)
  STATE.currentPolyline = L.polyline(pts, {
    color: CONFIG.colors[STATE.category].stroke,
    weight: 3,
    dashArray: '8 6',
    opacity: 0.95,
    lineJoin: 'round',
    lineCap: 'round'
  }).addTo(tempGroup);

  // Напівпрозора заливка
  if (pts.length >= 3) {
    const closed = [...pts];
    if (closed[0][0] !== closed[closed.length - 1][0] ||
        closed[0][1] !== closed[closed.length - 1][1]) {
      closed.push(closed[0]);
    }
    L.polygon(closed, {
      color: CONFIG.colors[STATE.category].stroke,
      weight: 2,
      dashArray: '6 4',
      fillColor: CONFIG.colors[STATE.category].fill,
      fillOpacity: 0.35,
      opacity: 0.9,
      lineJoin: 'round'
    }).addTo(tempGroup);
  }
}

function finishCurrentShape() {
  if (STATE.currentPoints.length < 3) {
    cancelCurrentShape();
    return;
  }

  // Замикаємо
  let coords = STATE.currentPoints.slice();
  const a0 = coords[0], a1 = coords[coords.length - 1];
  if (a0[0] !== a1[0] || a0[1] !== a1[1]) {
    coords.push([a0[0], a0[1]]);
  }

  const cat = STATE.category;
  let newGeo = {
    type: 'Feature',
    properties: {},
    geometry: {
      type: 'Polygon',
      coordinates: [coords.map(function (c) { return [c[1], c[0]]; })]
    }
  };

  // 1) Тільки територія України
  try {
    const clipped = clipToUkraine(newGeo);
    if (clipped) newGeo = clipped;
    else { cancelCurrentShape(); return; }
  } catch (e) {}

  // 2) НЕ перетинати жодну існуючу фігуру (навіть випадково)
  //    Нова = нова мінус усі старі. Старі НЕ змінюються.
  try {
    newGeo = subtractFromAllExisting(newGeo);
    if (!newGeo) { cancelCurrentShape(); return; }
  } catch (e) {}

  // Перевірка площі
  let areaKm2 = 0;
  try { areaKm2 = turf.area(newGeo) / 1000000; } catch (e) {}
  if (areaKm2 < 0.05) {
    cancelCurrentShape();
    return;
  }

  const style = {
    color: CONFIG.colors[cat].stroke,
    fillColor: CONFIG.colors[cat].fill,
    fillOpacity: STATE.polyOpacity,
    weight: 3,
    opacity: 1
  };

  // Розбити MultiPolygon якщо треба
  const parts = expandToPolygons(newGeo);
  let totalArea = 0;

  parts.forEach(function (g) {
    let a = 0;
    try { a = turf.area(g) / 1000000; } catch (e) {}
    if (a < 0.05) return;
    totalArea += a;

    const latlngs = g.geometry.coordinates[0].map(function (c) { return [c[1], c[0]]; });
    const layer = L.polygon(latlngs, style).addTo(drawnItems);
    layer.bringToFront();

    if (STATE.animEnabled && !STATE.lowEnd) {
      layer.setStyle({ fillOpacity: 0, opacity: 0 });
      animatePolygon(layer, style);
    }

    STATE.shapes.push({
      id: 'shape_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7),
      category: cat,
      layer: layer,
      geojson: g,
      area: a,
      timestamp: Date.now()
    });
  });

  // Авто сіра зона (якщо увімкнено і це occupied/liberated)
  if (STATE.autoStrip && (cat === 'occupied' || cat === 'liberated') && !STATE.lowEnd) {
    try { autoGrayAroundLast(cat); } catch (e) {}
  }

  pushHistory();

  const catNames = { liberated: 'Звільнено', occupied: 'Окупація', fighting: 'Йдуть бої' };
  addChronoEvent({
    type: cat,
    text: (catNames[cat] || cat) + ': +' + totalArea.toFixed(1) + ' км²',
    area: totalArea
  });

  clearTemp();
  updateStats();
  if (typeof updateCityControl === 'function') updateCityControl();
  if (typeof checkQuestProgress === 'function') checkQuestProgress();
}

/** Спрощений контур України (включно з Кримом) — для кліпу малювання */
var UKRAINE_BOUNDS_GEO = null;
function getUkraineGeo() {
  if (UKRAINE_BOUNDS_GEO) return UKRAINE_BOUNDS_GEO;
  // Спрощений зовнішній контур України [lng, lat]
  const ring = [
    [22.15, 48.40], [22.70, 49.00], [23.50, 49.80], [24.00, 50.40],
    [24.50, 51.20], [25.50, 51.60], [26.50, 51.70], [28.00, 51.70],
    [30.00, 52.00], [32.00, 52.10], [33.50, 52.00], [34.50, 51.50],
    [35.50, 50.80], [37.00, 50.40], [38.20, 49.80], [39.00, 49.50],
    [40.10, 49.30], [40.20, 48.80], [39.80, 48.20], [39.50, 47.80],
    [39.00, 47.20], [38.50, 47.00], [38.20, 46.50], [37.50, 46.40],
    [36.50, 46.30], [35.50, 46.20], [35.00, 45.80], [34.50, 45.30],
    [33.80, 44.80], [33.50, 44.40], [33.60, 44.20], [34.00, 44.40],
    [34.50, 44.80], [35.20, 45.10], [35.80, 45.30], [36.20, 45.20],
    [36.50, 45.00], [36.60, 44.60], [36.40, 44.40], [35.80, 44.50],
    [35.00, 44.60], [34.00, 44.50], [33.20, 44.60], [32.50, 45.20],
    [32.00, 45.80], [31.50, 46.20], [31.00, 46.50], [30.20, 46.40],
    [29.60, 46.20], [29.00, 46.30], [28.50, 46.80], [28.20, 47.50],
    [28.00, 48.00], [27.50, 48.30], [26.80, 48.20], [25.50, 47.90],
    [24.50, 47.80], [23.50, 47.90], [22.90, 48.00], [22.15, 48.40]
  ];
  UKRAINE_BOUNDS_GEO = {
    type: 'Feature',
    properties: {},
    geometry: { type: 'Polygon', coordinates: [ring] }
  };
  return UKRAINE_BOUNDS_GEO;
}


/** Нова фігура мінус УСІ існуючі — без перетинів, старі не чіпаємо */
function subtractFromAllExisting(newGeo) {
  let result = newGeo;
  for (let i = 0; i < STATE.shapes.length; i++) {
    const s = STATE.shapes[i];
    if (!s.geojson) continue;
    try {
      if (!turf.booleanIntersects(result, s.geojson)) continue;
      const diff = turf.difference(result, s.geojson);
      if (!diff || !diff.geometry) {
        return null; // повністю всередині старої — нічого не додаємо
      }
      result = diff;
    } catch (e) {
      // якщо turf не зміг — пропускаємо цю фігуру
    }
  }
  return result;
}

function clipToUkraine(geo) {
  try {
    const ua = getUkraineGeo();
    const inter = turf.intersect(geo, ua);
    return inter || null;
  } catch (e) {
    return geo; // якщо turf не зміг — лишаємо як є
  }
}

/** Авто-сіра смуга навколо щойно намальованої фігури */
function autoGrayAroundLast(cat) {
  const last = STATE.shapes[STATE.shapes.length - 1];
  if (!last || last.category !== cat) return;
  const w = STATE.stripWidth || 2;
  if (w <= 0) return;

  try {
    const buffered = turf.buffer(last.geojson, w, { units: 'kilometers' });
    if (!buffered) return;
    let ring = turf.difference(buffered, last.geojson);
    if (!ring) return;

    // Не заходити на протилежний колір
    const opposite = cat === 'occupied' ? 'liberated' : 'occupied';
    STATE.shapes.filter(function (s) { return s.category === opposite; }).forEach(function (s) {
      try {
        const d = turf.difference(ring, s.geojson);
        if (d) ring = d;
      } catch (e) {}
    });

    expandToPolygons(ring).forEach(function (g) {
      let a = 0;
      try { a = turf.area(g) / 1000000; } catch (e) {}
      if (a < 0.1) return;
      const latlngs = g.geometry.coordinates[0].map(function (c) { return [c[1], c[0]]; });
      const layer = L.polygon(latlngs, {
        color: CONFIG.colors.fighting.stroke,
        fillColor: CONFIG.colors.fighting.fill,
        fillOpacity: (STATE.polyOpacity || 0.5) * 0.7,
        weight: 1,
        dashArray: '4 4',
        opacity: 0.8
      }).addTo(drawnItems);

      STATE.shapes.push({
        id: 'strip_' + Date.now() + '_' + Math.random().toString(36).slice(2, 5),
        category: 'fighting',
        layer: layer,
        geojson: g,
        area: a,
        timestamp: Date.now()
      });
    });
  } catch (e) {}
}

// Залишено для сумісності
function mergeWithSameCategory(newGeo, category) {
  const same = STATE.shapes.filter(s => s.category === category);
  if (!same.length) return newGeo;

  let result = newGeo;
  const toRemove = [];

  same.forEach(shape => {
    try {
      // Не чіпаємо, якщо не перетинаються
      if (!turf.booleanIntersects(result, shape.geojson)) return;

      const u = turf.union(result, shape.geojson);
      if (u && u.geometry) {
        result = u;
        toRemove.push(shape);
      }
    } catch (e) {
      // ігноруємо помилки union
    }
  });

  toRemove.forEach(s => {
    try { drawnItems.removeLayer(s.layer); } catch (e) {}
    STATE.shapes = STATE.shapes.filter(x => x.id !== s.id);
  });

  return result;
}

/** Розбиває Feature на масив Polygon Feature */
function expandToPolygons(geo) {
  if (!geo || !geo.geometry) return [];
  if (geo.geometry.type === 'Polygon') return [geo];
  if (geo.geometry.type === 'MultiPolygon') {
    return geo.geometry.coordinates.map(coords => ({
      type: 'Feature',
      properties: {},
      geometry: { type: 'Polygon', coordinates: coords }
    }));
  }
  return [];
}

function subtractFromOtherCategories(newGeo, newCategory) {
  const toRemove = [];
  const toAdd = [];

  STATE.shapes.forEach(shape => {
    // Свій колір НІКОЛИ не чіпаємо
    if (shape.category === newCategory) return;
    // Чужий колір без перетину — теж не чіпаємо
    try {
      if (!turf.booleanIntersects(shape.geojson, newGeo)) return;
    } catch (e) { return; }

    try {
      const a = turf.buffer(shape.geojson, 0) || shape.geojson;
      const b = turf.buffer(newGeo, 0) || newGeo;
      const diff = turf.difference(a, b);

      if (!diff || !diff.geometry) {
        // Повністю поглинутий — видаляємо
        toRemove.push(shape);
        return;
      }

      const geoms = expandToPolygons(diff);
      toRemove.push(shape);

      geoms.forEach(g => {
        try {
          const area = turf.area(g) / 1_000_000;
          if (area < 0.01) return;

          const latlngs = g.geometry.coordinates[0].map(c => [c[1], c[0]]);
          // КОЛІР ЗАЛИШАЄТЬСЯ ВІД СТАРОЇ ФІГУРИ
          const layer = L.polygon(latlngs, styleForCategory(shape.category)).addTo(drawnItems);

          toAdd.push({
            id: 'shape_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7),
            category: shape.category, // колір НЕ змінюється
            layer,
            geojson: g,
            area,
            timestamp: Date.now()
          });
        } catch (e) {}
      });
    } catch (e) {
      // Якщо turf не зміг — залишаємо стару фігуру як є
      console.warn('difference failed', e);
    }
  });

  toRemove.forEach(s => {
    try { drawnItems.removeLayer(s.layer); } catch (e) {}
    STATE.shapes = STATE.shapes.filter(x => x.id !== s.id);
  });
  toAdd.forEach(s => STATE.shapes.push(s));
}

function cancelCurrentShape() {
  clearTemp();
}

function clearTemp() {
  tempGroup.clearLayers();
  STATE.currentPoints = [];
  STATE.currentPolyline = null;
  STATE.currentPolygon = null;
}

function undoLastPoint() {
  if (STATE.currentPoints.length === 0) return;
  STATE.currentPoints.pop();
  redrawTempShape();
}

function animatePolygon(polygon, finalStyle) {
  const duration = STATE.animDuration * 1000;
  const start = performance.now();

  function step(now) {
    const t = Math.min(1, (now - start) / duration);
    const eased = t * (2 - t); // ease-out
    polygon.setStyle({
      fillOpacity: finalStyle.fillOpacity * eased,
      opacity: eased
    });
    if (t < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

// ===== ERASER =====
function eraseAt(latlng) {
  // Видаляємо полігони, що містять точку
  const toRemove = [];
  STATE.shapes.forEach(shape => {
    try {
      const pt = turf.point([latlng.lng, latlng.lat]);
      if (turf.booleanPointInPolygon(pt, shape.geojson)) {
        toRemove.push(shape);
      }
    } catch (e) {}
  });

  toRemove.forEach(shape => {
    drawnItems.removeLayer(shape.layer);
    STATE.shapes = STATE.shapes.filter(s => s.id !== shape.id);
    addChronoEvent({
      type: 'system',
      text: `Видалено полігон (${shape.category})`
    });
  });

  // Видаляємо маркери поруч
  const toRemoveMarkers = [];
  STATE.markers.forEach(m => {
    if (map.distance(latlng, m.latlng) < 15000) { // ~15 км
      toRemoveMarkers.push(m);
    }
  });
  toRemoveMarkers.forEach(m => {
    markerGroup.removeLayer(m.layer);
    STATE.markers = STATE.markers.filter(x => x.id !== m.id);
  });

  if (toRemove.length || toRemoveMarkers.length) {
    pushHistory();
    updateStats();
  }
}

// ===== MARKERS =====
function placeMarker(type, latlng) {
  let iconHtml = '';
  let title = '';

  switch (type) {
    case 'flag-ua':
      iconHtml = '🇺🇦';
      title = 'Прапор України';
      break;
    case 'flag-ru':
      iconHtml = '🇷🇺';
      title = 'Прапор РФ';
      break;
    case 'brigade-ua':
      iconHtml = '🇺🇦⚔️';
      title = 'Бригада ЗСУ';
      break;
    case 'brigade-ru':
      iconHtml = '🇷🇺⚔️';
      title = 'Бригада РФ';
      break;
    default:
      return;
  }

  const icon = L.divIcon({
    className: 'custom-marker',
    html: `<div class="marker-icon" title="${title}">${iconHtml}</div>`,
    iconSize: [28, 28],
    iconAnchor: [14, 14]
  });

  const marker = L.marker(latlng, { icon, draggable: true }).addTo(markerGroup);

  const id = 'marker_' + Date.now();
  const data = {
    id,
    type,
    layer: marker,
    latlng: { lat: latlng.lat, lng: latlng.lng }
  };
  STATE.markers.push(data);

  marker.on('dragend', () => {
    data.latlng = marker.getLatLng();
    pushHistory();
  });

  pushHistory();
  updateStats();

  addChronoEvent({
    type: 'marker',
    text: `Додано: ${title}`
  });
}

// ===== RULER =====
function handleRulerClick(latlng) {
  STATE.rulerPoints.push(latlng);

  const m = L.circleMarker(latlng, {
    radius: 5,
    color: '#f59e0b',
    fillColor: '#fbbf24',
    fillOpacity: 1,
    weight: 2
  }).addTo(tempGroup);
  STATE.rulerMarkers.push(m);

  if (STATE.rulerPoints.length >= 2) {
    if (STATE.rulerLine) tempGroup.removeLayer(STATE.rulerLine);
    STATE.rulerLine = L.polyline(STATE.rulerPoints, {
      color: '#f59e0b',
      weight: 3,
      dashArray: '10 6'
    }).addTo(tempGroup);

    // Відстань
    let total = 0;
    for (let i = 1; i < STATE.rulerPoints.length; i++) {
      total += map.distance(STATE.rulerPoints[i - 1], STATE.rulerPoints[i]);
    }
    const km = (total / 1000).toFixed(2);

    // Показуємо підказку
    const mid = STATE.rulerPoints[STATE.rulerPoints.length - 1];
    L.popup({ closeButton: false, autoClose: true, closeOnClick: true })
      .setLatLng(mid)
      .setContent(`<b>${km} км</b>`)
      .openOn(map);
  }
}

function clearRuler() {
  STATE.rulerPoints = [];
  STATE.rulerMarkers.forEach(m => tempGroup.removeLayer(m));
  STATE.rulerMarkers = [];
  if (STATE.rulerLine) {
    tempGroup.removeLayer(STATE.rulerLine);
    STATE.rulerLine = null;
  }
}

// ===== GRAY STRIP (сіра зона між фронтами) =====
function buildGrayStrip() {
  // v0.4 — сіра зона між occupied і liberated
  const occupied = STATE.shapes.filter(function (s) { return s.category === 'occupied'; });
  const liberated = STATE.shapes.filter(function (s) { return s.category === 'liberated'; });

  if (!occupied.length && !liberated.length) {
    alert('Спочатку намалюйте території окупації або звільнення');
    return;
  }

  const w = STATE.stripWidth || 2;
  let added = 0;

  // Буфер навколо окупації
  occupied.forEach(function (shape) {
    try {
      const buffered = turf.buffer(shape.geojson, w, { units: 'kilometers' });
      if (!buffered) return;
      let ring = turf.difference(buffered, shape.geojson);
      if (!ring) return;

      // Не накладати на liberated
      liberated.forEach(function (lib) {
        try {
          const d = turf.difference(ring, lib.geojson);
          if (d) ring = d;
        } catch (e) {}
      });

      expandToPolygons(ring).forEach(function (g) {
        let a = 0;
        try { a = turf.area(g) / 1000000; } catch (e) {}
        if (a < 0.1) return;
        const latlngs = g.geometry.coordinates[0].map(function (c) { return [c[1], c[0]]; });
        const poly = L.polygon(latlngs, {
          color: CONFIG.colors.fighting.stroke,
          fillColor: CONFIG.colors.fighting.fill,
          fillOpacity: (STATE.polyOpacity || 0.5) * 0.7,
          weight: 1,
          dashArray: '4 4',
          opacity: 0.8
        }).addTo(drawnItems);

        STATE.shapes.push({
          id: 'strip_' + Date.now() + '_' + Math.random().toString(36).slice(2, 5),
          category: 'fighting',
          layer: poly,
          geojson: g,
          area: a,
          timestamp: Date.now()
        });
        added++;
      });
    } catch (e) {
      console.warn('Strip error', e);
    }
  });

  pushHistory();
  updateStats();
  addChronoEvent({
    type: 'fighting',
    text: 'Побудовано сіру зону (' + w + ' км), ділянок: ' + added
  });
}

// ===== HISTORY (Undo/Redo) =====
function pushHistory() {
  // Спрощена історія: зберігаємо знімок кількості
  const snapshot = {
    shapesCount: STATE.shapes.length,
    markersCount: STATE.markers.length,
    shapes: STATE.shapes.map(s => ({
      id: s.id,
      category: s.category,
      geojson: s.geojson,
      area: s.area
    })),
    markers: STATE.markers.map(m => ({
      id: m.id,
      type: m.type,
      latlng: m.latlng
    }))
  };

  // Обрізаємо майбутнє якщо були undo
  STATE.history = STATE.history.slice(0, STATE.historyIndex + 1);
  STATE.history.push(snapshot);
  STATE.historyIndex = STATE.history.length - 1;

  // Обмежуємо історію
  if (STATE.history.length > 40) {
    STATE.history.shift();
    STATE.historyIndex--;
  }
}

function undo() {
  if (STATE.historyIndex <= 0) return;
  STATE.historyIndex--;
  restoreSnapshot(STATE.history[STATE.historyIndex]);
}

function redo() {
  if (STATE.historyIndex >= STATE.history.length - 1) return;
  STATE.historyIndex++;
  restoreSnapshot(STATE.history[STATE.historyIndex]);
}

function restoreSnapshot(snap) {
  // Очищаємо все
  drawnItems.clearLayers();
  markerGroup.clearLayers();
  STATE.shapes = [];
  STATE.markers = [];

  // Відновлюємо полігони
  snap.shapes.forEach(s => {
    const coords = s.geojson.geometry.coordinates[0].map(c => [c[1], c[0]]);
    const poly = L.polygon(coords, styleForCategory(s.category)).addTo(drawnItems);
    STATE.shapes.push({
      id: s.id,
      category: s.category,
      layer: poly,
      geojson: s.geojson,
      area: s.area,
      timestamp: Date.now()
    });
  });

  // Відновлюємо маркери
  snap.markers.forEach(m => {
    placeMarkerSilent(m.type, m.latlng, m.id);
  });

  updateStats();
}

function placeMarkerSilent(type, latlng, id) {
  let iconHtml = type.startsWith('flag-ua') || type === 'flag-ua' ? '🇺🇦' :
                 type.startsWith('flag-ru') || type === 'flag-ru' ? '🇷🇺' :
                 type.includes('brigade-ua') ? '🇺🇦⚔️' : '🇷🇺⚔️';

  const icon = L.divIcon({
    className: 'custom-marker',
    html: `<div class="marker-icon">${iconHtml}</div>`,
    iconSize: [28, 28],
    iconAnchor: [14, 14]
  });

  const marker = L.marker(latlng, { icon, draggable: true }).addTo(markerGroup);
  STATE.markers.push({ id: id || 'm_' + Date.now(), type, layer: marker, latlng });
}
