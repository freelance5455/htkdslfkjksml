// ===== DRAWING LOGIC =====
// v0.2.1 — правильне захоплення/звільнення (вирізання з чужих полігонів)

function addPointToCurrentShape(latlng) {
  STATE.currentPoints.push([latlng.lat, latlng.lng]);
  redrawTempShape();
}

function updateTempLine(latlng) {
  if (STATE.currentPoints.length === 0) return;
  redrawTempShape(latlng);
}

/** Перемальовує тимчасову фігуру (лінія + напівпрозора заливка як на відео) */
function redrawTempShape(hoverLatLng) {
  tempGroup.clearLayers();

  const pts = hoverLatLng
    ? [...STATE.currentPoints, [hoverLatLng.lat, hoverLatLng.lng]]
    : [...STATE.currentPoints];

  if (pts.length < 2) {
    // Тільки точки
    STATE.currentPoints.forEach(pt => {
      L.circleMarker(pt, {
        radius: 4,
        color: CONFIG.colors[STATE.category].stroke,
        fillColor: '#fff',
        fillOpacity: 1,
        weight: 2
      }).addTo(tempGroup);
    });
    return;
  }

  // Пунктирна лінія
  STATE.currentPolyline = L.polyline(pts, {
    color: CONFIG.colors[STATE.category].stroke,
    weight: 3,
    dashArray: '8 6',
    opacity: 0.95
  }).addTo(tempGroup);

  // Напівпрозора заливка (як на відео) — якщо вже є мінімум 3 точки
  if (pts.length >= 3) {
    const closed = [...pts];
    if (closed[0][0] !== closed[closed.length - 1][0] ||
        closed[0][1] !== closed[closed.length - 1][1]) {
      closed.push(closed[0]);
    }
    L.polygon(closed, {
      color: CONFIG.colors[STATE.category].stroke,
      weight: 2,
      dashArray: '6 4',
      fillColor: CONFIG.colors[STATE.category].fill,
      fillOpacity: 0.35,
      opacity: 0.9
    }).addTo(tempGroup);
  }

  // Точки
  STATE.currentPoints.forEach(pt => {
    L.circleMarker(pt, {
      radius: 4,
      color: CONFIG.colors[STATE.category].stroke,
      fillColor: '#fff',
      fillOpacity: 1,
      weight: 2
    }).addTo(tempGroup);
  });
}

function finishCurrentShape() {
  if (STATE.currentPoints.length < 3) {
    cancelCurrentShape();
    return;
  }

  // Замикаємо полігон
  const coords = [...STATE.currentPoints];
  if (coords[0][0] !== coords[coords.length - 1][0] ||
      coords[0][1] !== coords[coords.length - 1][1]) {
    coords.push(coords[0]);
  }

  const style = {
    ...CONFIG.colors[STATE.category],
    fillOpacity: STATE.polyOpacity
  };

  // Створюємо GeoJSON нового полігону
  const newPoly = L.polygon(coords, style);
  const newGeo = newPoly.toGeoJSON();

  // === ГОЛОВНИЙ ФІКС v0.2.1 ===
  // Вирізаємо нову фігуру з усіх існуючих полігонів ІНШОГО кольору
  subtractFromOtherCategories(newGeo, STATE.category);

  // Додаємо новий полігон
  if (STATE.animEnabled) {
    newPoly.setStyle({ fillOpacity: 0, opacity: 0 });
    newPoly.addTo(drawnItems);
    animatePolygon(newPoly, style);
  } else {
    newPoly.addTo(drawnItems);
  }

  let areaKm2 = 0;
  try {
    areaKm2 = turf.area(newGeo) / 1_000_000;
  } catch (e) {
    areaKm2 = 0;
  }

  const id = 'shape_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
  STATE.shapes.push({
    id,
    category: STATE.category,
    layer: newPoly,
    geojson: newGeo,
    area: areaKm2,
    timestamp: Date.now()
  });

  pushHistory();

  const catNames = {
    liberated: 'Звільнено',
    occupied: 'Окупація',
    fighting: 'Йдуть бої'
  };
  addChronoEvent({
    type: STATE.category,
    text: `${catNames[STATE.category]}: +${areaKm2.toFixed(1)} км²`,
    area: areaKm2
  });

  clearTemp();
  updateStats();

  if (typeof updateCityControl === 'function') updateCityControl();
  if (typeof checkQuestProgress === 'function') checkQuestProgress();
}

/**
 * Вирізає newGeo з усіх полігонів, які мають іншу категорію.
 * Якщо після різниці полігон зникає — видаляємо його.
 * Якщо розпадається на кілька — створюємо кілька нових.
 */
function subtractFromOtherCategories(newGeo, newCategory) {
  const toRemove = [];
  const toAdd = [];

  STATE.shapes.forEach(shape => {
    if (shape.category === newCategory) return; // свій колір не чіпаємо

    try {
      const diff = turf.difference(shape.geojson, newGeo);
      if (!diff) {
        // Повністю поглинутий — видаляємо
        toRemove.push(shape);
        return;
      }

      // Може бути Polygon або MultiPolygon
      const geoms = diff.geometry.type === 'MultiPolygon'
        ? diff.geometry.coordinates.map(coords => ({
            type: 'Feature',
            properties: {},
            geometry: { type: 'Polygon', coordinates: coords }
          }))
        : [diff];

      // Видаляємо старий
      toRemove.push(shape);

      // Додаємо залишки
      geoms.forEach(g => {
        try {
          const area = turf.area(g) / 1_000_000;
          if (area < 0.01) return; // занадто маленький — ігноруємо

          const latlngs = g.geometry.coordinates[0].map(c => [c[1], c[0]]);
          const style = {
            ...CONFIG.colors[shape.category],
            fillOpacity: STATE.polyOpacity
          };
          const layer = L.polygon(latlngs, style).addTo(drawnItems);

          toAdd.push({
            id: 'shape_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7),
            category: shape.category,
            layer,
            geojson: g,
            area,
            timestamp: Date.now()
          });
        } catch (e) {}
      });
    } catch (e) {
      // Якщо turf не зміг — залишаємо як є
      console.warn('difference failed', e);
    }
  });

  // Застосовуємо зміни
  toRemove.forEach(s => {
    drawnItems.removeLayer(s.layer);
    STATE.shapes = STATE.shapes.filter(x => x.id !== s.id);
  });
  toAdd.forEach(s => STATE.shapes.push(s));
}

function cancelCurrentShape() {
  clearTemp();
}

function clearTemp() {
  tempGroup.clearLayers();
  STATE.currentPoints = [];
  STATE.currentPolyline = null;
  STATE.currentPolygon = null;
}

function undoLastPoint() {
  if (STATE.currentPoints.length === 0) return;
  STATE.currentPoints.pop();
  redrawTempShape();
}

function animatePolygon(polygon, finalStyle) {
  const duration = STATE.animDuration * 1000;
  const start = performance.now();

  function step(now) {
    const t = Math.min(1, (now - start) / duration);
    const eased = t * (2 - t); // ease-out
    polygon.setStyle({
      fillOpacity: finalStyle.fillOpacity * eased,
      opacity: eased
    });
    if (t < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

// ===== ERASER =====
function eraseAt(latlng) {
  // Видаляємо полігони, що містять точку
  const toRemove = [];
  STATE.shapes.forEach(shape => {
    try {
      const pt = turf.point([latlng.lng, latlng.lat]);
      if (turf.booleanPointInPolygon(pt, shape.geojson)) {
        toRemove.push(shape);
      }
    } catch (e) {}
  });

  toRemove.forEach(shape => {
    drawnItems.removeLayer(shape.layer);
    STATE.shapes = STATE.shapes.filter(s => s.id !== shape.id);
    addChronoEvent({
      type: 'system',
      text: `Видалено полігон (${shape.category})`
    });
  });

  // Видаляємо маркери поруч
  const toRemoveMarkers = [];
  STATE.markers.forEach(m => {
    if (map.distance(latlng, m.latlng) < 15000) { // ~15 км
      toRemoveMarkers.push(m);
    }
  });
  toRemoveMarkers.forEach(m => {
    markerGroup.removeLayer(m.layer);
    STATE.markers = STATE.markers.filter(x => x.id !== m.id);
  });

  if (toRemove.length || toRemoveMarkers.length) {
    pushHistory();
    updateStats();
  }
}

// ===== MARKERS =====
function placeMarker(type, latlng) {
  let iconHtml = '';
  let title = '';

  switch (type) {
    case 'flag-ua':
      iconHtml = '🇺🇦';
      title = 'Прапор України';
      break;
    case 'flag-ru':
      iconHtml = '🇷🇺';
      title = 'Прапор РФ';
      break;
    case 'brigade-ua':
      iconHtml = '🇺🇦⚔️';
      title = 'Бригада ЗСУ';
      break;
    case 'brigade-ru':
      iconHtml = '🇷🇺⚔️';
      title = 'Бригада РФ';
      break;
    default:
      return;
  }

  const icon = L.divIcon({
    className: 'custom-marker',
    html: `<div class="marker-icon" title="${title}">${iconHtml}</div>`,
    iconSize: [28, 28],
    iconAnchor: [14, 14]
  });

  const marker = L.marker(latlng, { icon, draggable: true }).addTo(markerGroup);

  const id = 'marker_' + Date.now();
  const data = {
    id,
    type,
    layer: marker,
    latlng: { lat: latlng.lat, lng: latlng.lng }
  };
  STATE.markers.push(data);

  marker.on('dragend', () => {
    data.latlng = marker.getLatLng();
    pushHistory();
  });

  pushHistory();
  updateStats();

  addChronoEvent({
    type: 'marker',
    text: `Додано: ${title}`
  });
}

// ===== RULER =====
function handleRulerClick(latlng) {
  STATE.rulerPoints.push(latlng);

  const m = L.circleMarker(latlng, {
    radius: 5,
    color: '#f59e0b',
    fillColor: '#fbbf24',
    fillOpacity: 1,
    weight: 2
  }).addTo(tempGroup);
  STATE.rulerMarkers.push(m);

  if (STATE.rulerPoints.length >= 2) {
    if (STATE.rulerLine) tempGroup.removeLayer(STATE.rulerLine);
    STATE.rulerLine = L.polyline(STATE.rulerPoints, {
      color: '#f59e0b',
      weight: 3,
      dashArray: '10 6'
    }).addTo(tempGroup);

    // Відстань
    let total = 0;
    for (let i = 1; i < STATE.rulerPoints.length; i++) {
      total += map.distance(STATE.rulerPoints[i - 1], STATE.rulerPoints[i]);
    }
    const km = (total / 1000).toFixed(2);

    // Показуємо підказку
    const mid = STATE.rulerPoints[STATE.rulerPoints.length - 1];
    L.popup({ closeButton: false, autoClose: true, closeOnClick: true })
      .setLatLng(mid)
      .setContent(`<b>${km} км</b>`)
      .openOn(map);
  }
}

function clearRuler() {
  STATE.rulerPoints = [];
  STATE.rulerMarkers.forEach(m => tempGroup.removeLayer(m));
  STATE.rulerMarkers = [];
  if (STATE.rulerLine) {
    tempGroup.removeLayer(STATE.rulerLine);
    STATE.rulerLine = null;
  }
}

// ===== GRAY STRIP (сіра зона між фронтами) =====
function buildGrayStrip() {
  // Проста реалізація: буферизуємо всі полігони "окупація" і "звільнено"
  // і створюємо зону боїв між ними (спрощено)

  const occupied = STATE.shapes.filter(s => s.category === 'occupied');
  const liberated = STATE.shapes.filter(s => s.category === 'liberated');

  if (occupied.length === 0 && liberated.length === 0) {
    alert('Спочатку намалюйте території окупації або звільнення');
    return;
  }

  // Для демонстрації: створюємо буфер навколо окупованих територій
  occupied.forEach(shape => {
    try {
      const buffered = turf.buffer(shape.geojson, STATE.stripWidth, { units: 'kilometers' });
      const diff = turf.difference(buffered, shape.geojson);
      if (diff) {
        const coords = diff.geometry.coordinates;
        // Leaflet очікує [lat, lng]
        const latlngs = coords[0].map(c => [c[1], c[0]]);
        const poly = L.polygon(latlngs, {
          ...CONFIG.colors.fighting,
          fillOpacity: STATE.polyOpacity * 0.8
        }).addTo(drawnItems);

        const id = 'strip_' + Date.now();
        const areaKm2 = turf.area(diff) / 1_000_000;
        STATE.shapes.push({
          id,
          category: 'fighting',
          layer: poly,
          geojson: diff,
          area: areaKm2,
          timestamp: Date.now()
        });
      }
    } catch (e) {
      console.warn('Strip error', e);
    }
  });

  pushHistory();
  updateStats();
  addChronoEvent({
    type: 'fighting',
    text: `Побудовано сіру зону (${STATE.stripWidth} км)`
  });
}

// ===== HISTORY (Undo/Redo) =====
function pushHistory() {
  // Спрощена історія: зберігаємо знімок кількості
  const snapshot = {
    shapesCount: STATE.shapes.length,
    markersCount: STATE.markers.length,
    shapes: STATE.shapes.map(s => ({
      id: s.id,
      category: s.category,
      geojson: s.geojson,
      area: s.area
    })),
    markers: STATE.markers.map(m => ({
      id: m.id,
      type: m.type,
      latlng: m.latlng
    }))
  };

  // Обрізаємо майбутнє якщо були undo
  STATE.history = STATE.history.slice(0, STATE.historyIndex + 1);
  STATE.history.push(snapshot);
  STATE.historyIndex = STATE.history.length - 1;

  // Обмежуємо історію
  if (STATE.history.length > 40) {
    STATE.history.shift();
    STATE.historyIndex--;
  }
}

function undo() {
  if (STATE.historyIndex <= 0) return;
  STATE.historyIndex--;
  restoreSnapshot(STATE.history[STATE.historyIndex]);
}

function redo() {
  if (STATE.historyIndex >= STATE.history.length - 1) return;
  STATE.historyIndex++;
  restoreSnapshot(STATE.history[STATE.historyIndex]);
}

function restoreSnapshot(snap) {
  // Очищаємо все
  drawnItems.clearLayers();
  markerGroup.clearLayers();
  STATE.shapes = [];
  STATE.markers = [];

  // Відновлюємо полігони
  snap.shapes.forEach(s => {
    const coords = s.geojson.geometry.coordinates[0].map(c => [c[1], c[0]]);
    const style = { ...CONFIG.colors[s.category], fillOpacity: STATE.polyOpacity };
    const poly = L.polygon(coords, style).addTo(drawnItems);
    STATE.shapes.push({
      id: s.id,
      category: s.category,
      layer: poly,
      geojson: s.geojson,
      area: s.area,
      timestamp: Date.now()
    });
  });

  // Відновлюємо маркери
  snap.markers.forEach(m => {
    placeMarkerSilent(m.type, m.latlng, m.id);
  });

  updateStats();
}

function placeMarkerSilent(type, latlng, id) {
  let iconHtml = type.startsWith('flag-ua') || type === 'flag-ua' ? '🇺🇦' :
                 type.startsWith('flag-ru') || type === 'flag-ru' ? '🇷🇺' :
                 type.includes('brigade-ua') ? '🇺🇦⚔️' : '🇷🇺⚔️';

  const icon = L.divIcon({
    className: 'custom-marker',
    html: `<div class="marker-icon">${iconHtml}</div>`,
    iconSize: [28, 28],
    iconAnchor: [14, 14]
  });

  const marker = L.marker(latlng, { icon, draggable: true }).addTo(markerGroup);
  STATE.markers.push({ id: id || 'm_' + Date.now(), type, layer: marker, latlng });
}
