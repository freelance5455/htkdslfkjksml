// ===== HALLOWEEN EVENT 0.5.0 =====
// Тимчасове івент-оновлення. Механіку малювання не змінює.

const HW = {
  maxLevel: 10,
  xpPerLevel: 100,
  candyPerKm2: 1,
  cheatThresholdKm2: 80,   // більше за один жест = жульнічество
  cheatPenalty: 2,
  shop: [
    { id: 'xp25',  label: '+25 XP',   cost: 8,  xp: 25 },
    { id: 'xp100', label: '+100 XP',  cost: 25, xp: 100 },
    { id: 'xp300', label: '+300 XP',  cost: 60, xp: 300 }
  ]
};

let hwXp = 0;
let hwCandies = 0; // синхронізується з coins квестів

function hwLevel() {
  return Math.min(Math.floor(hwXp / HW.xpPerLevel), HW.maxLevel);
}

function hwXpIntoLevel() {
  if (hwLevel() >= HW.maxLevel) return hwXp - HW.maxLevel * HW.xpPerLevel;
  return hwXp % HW.xpPerLevel;
}

function hwLoad() {
  try {
    const s = JSON.parse(localStorage.getItem('forefront-halloween') || '{}');
    hwXp = s.xp || 0;
    // Конфети = монети з квестів (єдина валюта івенту)
    if (typeof coins === 'number') hwCandies = coins;
    else hwCandies = s.candies || 0;
  } catch (e) {
    hwXp = 0;
  }
  hwUpdateUI();
}

function hwSave() {
  try {
    localStorage.setItem('forefront-halloween', JSON.stringify({
      xp: hwXp,
      candies: (typeof coins === 'number' ? coins : hwCandies)
    }));
  } catch (e) {}
}

function hwUpdateUI() {
  const candyEl = document.getElementById('coins-value');
  if (candyEl) candyEl.textContent = (typeof coins === 'number' ? coins : hwCandies);

  const icon = document.querySelector('#coins-display .coin-icon');
  if (icon) icon.textContent = '🍬';

  const lvlEl = document.getElementById('hw-level-value');
  const xpEl = document.getElementById('hw-xp-value');
  const bar = document.getElementById('hw-xp-bar');
  if (lvlEl) lvlEl.textContent = hwLevel();
  if (xpEl) {
    if (hwLevel() >= HW.maxLevel) {
      xpEl.textContent = hwXp + ' XP (макс. рівень)';
    } else {
      xpEl.textContent = hwXpIntoLevel() + ' / ' + HW.xpPerLevel + ' XP';
    }
  }
  if (bar) {
    const pct = hwLevel() >= HW.maxLevel
      ? 100
      : Math.min(100, (hwXpIntoLevel() / HW.xpPerLevel) * 100);
    bar.style.width = pct + '%';
  }

  const shopCandy = document.getElementById('shop-candy-count');
  if (shopCandy) shopCandy.textContent = (typeof coins === 'number' ? coins : hwCandies);
}

/** Виклик після захоплення/звільнення території (не чіпає механіку малювання) */
function hwOnTerritoryCapture(areaKm2, category) {
  if (!areaKm2 || areaKm2 < 0.05) return;
  if (category !== 'occupied' && category !== 'liberated') return;

  const area = Math.floor(areaKm2);

  if (areaKm2 >= HW.cheatThresholdKm2) {
    // Жульнічество
    if (typeof addCoins === 'function') {
      // addCoins може піти в мінус — обмежуємо
      const cur = typeof coins === 'number' ? coins : 0;
      const pen = Math.min(HW.cheatPenalty, cur);
      if (pen > 0) {
        coins = cur - pen;
        updateCoinsUI();
        saveQuestsState();
      }
    }
    if (typeof addChronoEvent === 'function') {
      addChronoEvent({
        type: 'system',
        text: '🎃 Жульнічество! Занадто велике захоплення (−' + HW.cheatPenalty + ' 🍬)'
      });
    }
    hwShowToast('Жульнічество! −' + HW.cheatPenalty + ' 🍬');
  } else if (area > 0) {
    if (typeof addCoins === 'function') {
      // addCoins вже пише в хронологію з монетами — тимчасово без подвійного chrono
      coins = (typeof coins === 'number' ? coins : 0) + area;
      updateCoinsUI();
      saveQuestsState();
    }
    if (typeof addChronoEvent === 'function') {
      addChronoEvent({
        type: 'system',
        text: '+'+ area + ' 🍬 за ' + area + ' км²'
      });
    }
  }

  hwSave();
  hwUpdateUI();
}

function hwBuy(itemId) {
  const item = HW.shop.find(function (x) { return x.id === itemId; });
  if (!item) return;

  const bal = typeof coins === 'number' ? coins : hwCandies;
  if (bal < item.cost) {
    hwShowToast('Недостатньо цукерок 🍬');
    return;
  }

  if (typeof coins === 'number') {
    coins -= item.cost;
    updateCoinsUI();
    saveQuestsState();
  } else {
    hwCandies -= item.cost;
  }

  hwXp += item.xp;
  hwSave();
  hwUpdateUI();
  hwRenderShop();

  if (typeof addChronoEvent === 'function') {
    addChronoEvent({
      type: 'system',
      text: '🛒 Куплено ' + item.label + ' (−' + item.cost + ' 🍬)'
    });
  }
  hwShowToast(item.label + ' отримано!');
}

function hwRenderShop() {
  const list = document.getElementById('shop-list');
  if (!list) return;
  const bal = typeof coins === 'number' ? coins : hwCandies;
  list.innerHTML = HW.shop.map(function (item) {
    const can = bal >= item.cost;
    return (
      '<div class="shop-item' + (can ? '' : ' disabled') + '">' +
        '<div class="shop-item-info">' +
          '<div class="shop-item-title">' + item.label + '</div>' +
          '<div class="shop-item-cost">🍬 ' + item.cost + '</div>' +
        '</div>' +
        '<button class="shop-buy-btn" data-shop="' + item.id + '"' +
          (can ? '' : ' disabled') + '>Купити</button>' +
      '</div>'
    );
  }).join('');

  list.querySelectorAll('[data-shop]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      hwBuy(btn.getAttribute('data-shop'));
    });
  });
}

function hwShowToast(text) {
  let t = document.getElementById('hw-toast');
  if (!t) {
    t = document.createElement('div');
    t.id = 'hw-toast';
    document.body.appendChild(t);
  }
  t.textContent = text;
  t.classList.add('show');
  clearTimeout(t._timer);
  t._timer = setTimeout(function () { t.classList.remove('show'); }, 2200);
}

function hwOpenShop() {
  const panel = document.getElementById('shop-panel');
  if (!panel) return;
  document.getElementById('quests-panel')?.classList.add('hidden');
  document.getElementById('layers-panel')?.classList.add('hidden');
  hwRenderShop();
  hwUpdateUI();
  panel.classList.remove('hidden');
}

function hwCloseShop() {
  document.getElementById('shop-panel')?.classList.add('hidden');
}

function initHalloween() {
  hwLoad();

  // Декор кутів
  if (!document.getElementById('hw-decor')) {
    const decor = document.createElement('div');
    decor.id = 'hw-decor';
    decor.innerHTML =
      '<span class="hw-corner tl">🕸️</span>' +
      '<span class="hw-corner tr">🎃</span>' +
      '<span class="hw-corner bl">🎃</span>' +
      '<span class="hw-corner br">🕸️</span>';
    document.body.appendChild(decor);
  }

  // Кнопка магазину
  const shopBtn = document.getElementById('shop-btn');
  if (shopBtn) {
    shopBtn.addEventListener('click', function () {
      const panel = document.getElementById('shop-panel');
      if (panel && !panel.classList.contains('hidden')) hwCloseShop();
      else hwOpenShop();
    });
  }

  document.querySelectorAll('[data-panel="shop-panel"]').forEach(function (btn) {
    btn.addEventListener('click', hwCloseShop);
  });

  // Іконка цукерок замість монет
  const icon = document.querySelector('#coins-display .coin-icon');
  if (icon) icon.textContent = '🍬';

  hwUpdateUI();
}

// Після завантаження DOM (main викличе initHalloween)
window.HW_EVENT = { init: initHalloween, onCapture: hwOnTerritoryCapture, update: hwUpdateUI };
