// ===== CITIES & VILLAGES (v0.2) =====

const CITIES = [
  // Великі міста
  { name: 'Київ', lat: 50.4501, lng: 30.5234, type: 'city', control: null },
  { name: 'Харків', lat: 49.9935, lng: 36.2304, type: 'city', control: null },
  { name: 'Одеса', lat: 46.4825, lng: 30.7233, type: 'city', control: null },
  { name: 'Дніпро', lat: 48.4647, lng: 35.0462, type: 'city', control: null },
  { name: 'Донецьк', lat: 48.0159, lng: 37.8028, type: 'city', control: null },
  { name: 'Запоріжжя', lat: 47.8388, lng: 35.1396, type: 'city', control: null },
  { name: 'Львів', lat: 49.8397, lng: 24.0297, type: 'city', control: null },
  { name: 'Кривий Ріг', lat: 47.9105, lng: 33.3918, type: 'city', control: null },
  { name: 'Миколаїв', lat: 46.9750, lng: 31.9946, type: 'city', control: null },
  { name: 'Маріуполь', lat: 47.0971, lng: 37.5434, type: 'city', control: null },
  { name: 'Луганськ', lat: 48.5740, lng: 39.3078, type: 'city', control: null },
  { name: 'Вінниця', lat: 49.2331, lng: 28.4682, type: 'city', control: null },
  { name: 'Херсон', lat: 46.6354, lng: 32.6169, type: 'city', control: null },
  { name: 'Полтава', lat: 49.5883, lng: 34.5514, type: 'city', control: null },
  { name: 'Чернігів', lat: 51.4982, lng: 31.2893, type: 'city', control: null },
  { name: 'Черкаси', lat: 49.4444, lng: 32.0598, type: 'city', control: null },
  { name: 'Суми', lat: 50.9077, lng: 34.7981, type: 'city', control: null },
  { name: 'Житомир', lat: 50.2547, lng: 28.6587, type: 'city', control: null },
  { name: 'Хмельницький', lat: 49.4229, lng: 26.9871, type: 'city', control: null },
  { name: 'Рівне', lat: 50.6199, lng: 26.2516, type: 'city', control: null },
  { name: 'Кропивницький', lat: 48.5079, lng: 32.2623, type: 'city', control: null },
  { name: 'Івано-Франківськ', lat: 48.9226, lng: 24.7111, type: 'city', control: null },
  { name: 'Тернопіль', lat: 49.5535, lng: 25.5948, type: 'city', control: null },
  { name: 'Луцьк', lat: 50.7472, lng: 25.3254, type: 'city', control: null },
  { name: 'Ужгород', lat: 48.6208, lng: 22.2879, type: 'city', control: null },
  { name: 'Чернівці', lat: 48.2917, lng: 25.9352, type: 'city', control: null },
  { name: 'Сімферополь', lat: 44.9521, lng: 34.1024, type: 'city', control: null },
  { name: 'Севастополь', lat: 44.6167, lng: 33.5254, type: 'city', control: null },

  // Важливі населені пункти фронту
  { name: 'Бахмут', lat: 48.5950, lng: 38.0000, type: 'town', control: null },
  { name: 'Авдіївка', lat: 48.1390, lng: 37.7470, type: 'town', control: null },
  { name: 'Покровськ', lat: 48.2820, lng: 37.1760, type: 'town', control: null },
  { name: 'Краматорськ', lat: 48.7380, lng: 37.5840, type: 'town', control: null },
  { name: 'Слов\'янськ', lat: 48.8530, lng: 37.6060, type: 'town', control: null },
  { name: 'Лисичанськ', lat: 48.9050, lng: 38.4300, type: 'town', control: null },
  { name: 'Сєвєродонецьк', lat: 48.9480, lng: 38.4910, type: 'town', control: null },
  { name: 'Мелітополь', lat: 46.8480, lng: 35.3650, type: 'town', control: null },
  { name: 'Бердянськ', lat: 46.7550, lng: 36.7840, type: 'town', control: null },
  { name: 'Токмак', lat: 47.2510, lng: 35.7060, type: 'town', control: null },
  { name: 'Оріхів', lat: 47.5670, lng: 35.7850, type: 'town', control: null },
  { name: 'Гуляйполе', lat: 47.6630, lng: 36.2630, type: 'town', control: null },
  { name: 'Вугледар', lat: 47.7790, lng: 37.2480, type: 'town', control: null },
  { name: 'Мар\'їнка', lat: 47.9420, lng: 37.5080, type: 'town', control: null },
  { name: 'Часів Яр', lat: 48.5950, lng: 37.8350, type: 'town', control: null },
  { name: 'Торецьк', lat: 48.3920, lng: 37.8610, type: 'town', control: null },
  { name: 'Нью-Йорк', lat: 48.3330, lng: 37.8400, type: 'town', control: null },
  { name: 'Куп\'янськ', lat: 49.7100, lng: 37.6170, type: 'town', control: null },
  { name: 'Ізюм', lat: 49.2120, lng: 37.2570, type: 'town', control: null },
  { name: 'Лиман', lat: 48.9870, lng: 37.8110, type: 'town', control: null },
  { name: 'Сватове', lat: 49.4100, lng: 38.1520, type: 'town', control: null },
  { name: 'Кремінна', lat: 49.0500, lng: 38.2200, type: 'town', control: null },
  { name: 'Нова Каховка', lat: 46.7550, lng: 33.3700, type: 'town', control: null },
  { name: 'Енергодар', lat: 47.4980, lng: 34.6560, type: 'town', control: null },
  { name: 'Васильківка', lat: 48.2050, lng: 36.0300, type: 'village', control: null },
  { name: 'Велика Новосілка', lat: 47.8400, lng: 36.8350, type: 'town', control: null },
  { name: 'Роботyne', lat: 47.4500, lng: 35.8500, type: 'village', control: null },
  { name: 'Вербове', lat: 47.4800, lng: 35.9200, type: 'village', control: null }
];

let cityMarkers = [];
let citiesLayer = null;

function initCities() {
  citiesLayer = L.layerGroup().addTo(map);
  renderCities();
}

function renderCities() {
  if (!citiesLayer) return;
  citiesLayer.clearLayers();
  cityMarkers = [];

  const show = document.getElementById('show-cities')?.checked !== false;

  CITIES.forEach(city => {
    if (!show && city.type === 'village') return; // села можна ховати

    let cls = 'city-label';
    if (city.control === 'liberated') cls += ' captured-ua';
    if (city.control === 'occupied') cls += ' captured-ru';

    const icon = L.divIcon({
      className: '',
      html: `<div class="${cls}">${city.name}</div>`,
      iconSize: [0, 0],
      iconAnchor: [0, 0]
    });

    const marker = L.marker([city.lat, city.lng], {
      icon,
      interactive: true,
      keyboard: false
    }).addTo(citiesLayer);

    marker.on('click', () => {
      // Клік по місту — показати статус
      const status = city.control === 'liberated' ? '🇺🇦 Під контролем УА' :
                    city.control === 'occupied' ? '🇷🇺 Під контролем РФ' :
                    '⚪ Невизначено';
      L.popup()
        .setLatLng([city.lat, city.lng])
        .setContent(`<b>${city.name}</b><br>${status}`)
        .openOn(map);
    });

    cityMarkers.push({ city, marker });
  });
}

function updateCityControl() {
  // Перевіряємо, в якому полігоні знаходиться кожне місто
  CITIES.forEach(city => {
    let found = null;
    for (const shape of STATE.shapes) {
      try {
        const pt = turf.point([city.lng, city.lat]);
        if (turf.booleanPointInPolygon(pt, shape.geojson)) {
          found = shape.category;
          break;
        }
      } catch (e) {}
    }
    city.control = found; // liberated | occupied | fighting | null
  });
  renderCities();
  if (typeof checkQuestProgress === 'function') checkQuestProgress();
}

// Викликати після завершення фігури
function onShapeFinished() {
  updateCityControl();
}
