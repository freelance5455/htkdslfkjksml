// ===== MAIN APP =====
// FOREFRONT v0.2

document.addEventListener('DOMContentLoaded', () => {
  initMap();
  initLayersPanel();
  initChronology();
  initUI();
  initQuestsUI();
  loadCoinsAndQuests();
  updateStats();

  // Перевірка чи є збереження для кнопки "Продовжити"
  updateContinueButton();

  // Автозбереження кожні 30 сек
  setInterval(autoSave, 30000);

  console.log('%cFOREFRONT v0.2 · MAXI CORPORATION', 'color:#3b82f6;font-size:14px;font-weight:bold');
});

function startGame(mode) {
  document.body.classList.add('game-started');
  document.getElementById('start-screen').classList.add('hidden');

  if (mode === 'empty') {
    // Порожня карта
    pushHistory();
    if (typeof initCities === 'function') initCities();
  } else if (mode === 'real') {
    // Реальна лінія фронту
    loadRealFrontLine().then(() => {
      pushHistory();
      if (typeof initCities === 'function') initCities();
      if (typeof updateCityControl === 'function') updateCityControl();
    }).catch(err => {
      console.error(err);
      alert('Не вдалося завантажити реальну лінію фронту. Перевірте інтернет.');
      pushHistory();
      if (typeof initCities === 'function') initCities();
    });
  } else if (mode === 'continue') {
    tryAutoLoadFull();
    if (typeof initCities === 'function') initCities();
    if (typeof updateCityControl === 'function') updateCityControl();
  }

  map.invalidateSize();
}

async function loadRealFrontLine() {
  // Спробуємо кілька дат назад від сьогодні
  const today = new Date();
  let loaded = false;

  for (let i = 0; i < 10; i++) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const dateStr = d.toISOString().slice(0, 10); // YYYY-MM-DD
    const url = `${CONFIG.deepState.baseUrl}deepstatemap_data_${dateStr}.geojson`;

    try {
      const resp = await fetch(url);
      if (!resp.ok) continue;
      const geojson = await resp.json();
      applyDeepStateGeoJSON(geojson);
      addChronoEvent({ type: 'system', text: `Завантажено реальну лінію фронту (${dateStr})` });
      loaded = true;
      break;
    } catch (e) {
      // спробуємо наступну дату
    }
  }

  if (!loaded) {
    // Fallback на відомий файл
    try {
      const url = CONFIG.deepState.baseUrl + CONFIG.deepState.latestKnown;
      const resp = await fetch(url);
      if (resp.ok) {
        const geojson = await resp.json();
        applyDeepStateGeoJSON(geojson);
        addChronoEvent({ type: 'system', text: 'Завантажено реальну лінію фронту (fallback)' });
        loaded = true;
      }
    } catch (e) {}
  }

  if (!loaded) throw new Error('Немає доступних даних DeepState');
}

function applyDeepStateGeoJSON(geojson) {
  // Очищаємо попередні
  drawnItems.clearLayers();
  STATE.shapes = [];

  const features = geojson.type === 'FeatureCollection' ? geojson.features :
                   geojson.type === 'Feature' ? [geojson] :
                   geojson.geometry ? [geojson] : [];

  features.forEach((f, idx) => {
    try {
      let coords;
      if (f.geometry.type === 'Polygon') {
        coords = f.geometry.coordinates[0].map(c => [c[1], c[0]]);
      } else if (f.geometry.type === 'MultiPolygon') {
        // Беремо найбільший полігон або всі
        f.geometry.coordinates.forEach(poly => {
          const latlngs = poly[0].map(c => [c[1], c[0]]);
          addOccupiedPolygon(latlngs, f);
        });
        return;
      } else return;

      addOccupiedPolygon(coords, f);
    } catch (e) {
      console.warn('Skip feature', e);
    }
  });

  updateStats();
}

function addOccupiedPolygon(latlngs, feature) {
  const style = {
    ...CONFIG.colors.occupied,
    fillOpacity: STATE.polyOpacity
  };
  const polygon = L.polygon(latlngs, style).addTo(drawnItems);
  const geojson = polygon.toGeoJSON();
  let areaKm2 = 0;
  try {
    areaKm2 = turf.area(geojson) / 1_000_000;
  } catch (e) {}

  STATE.shapes.push({
    id: 'ds_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
    category: 'occupied',
    layer: polygon,
    geojson,
    area: areaKm2,
    timestamp: Date.now()
  });
}

function updateContinueButton() {
  const btn = document.getElementById('btn-continue');
  const dateEl = document.getElementById('continue-date');
  try {
    const raw = localStorage.getItem('front-sim-autosave');
    if (raw) {
      const data = JSON.parse(raw);
      if (data.shapes && data.shapes.length) {
        const d = new Date();
        dateEl.textContent = `(${d.toLocaleDateString('uk-UA')}, ${d.toLocaleTimeString('uk-UA', {hour:'2-digit', minute:'2-digit'})})`;
        btn.style.display = 'flex';
        return;
      }
    }
  } catch (e) {}
  btn.style.display = 'none';
}

function tryAutoLoadFull() {
  try {
    const raw = localStorage.getItem('front-sim-autosave');
    if (raw) {
      const data = JSON.parse(raw);
      applyLoadedData(data);
    }
  } catch (e) {}
}

function initUI() {
  // ===== MODE BUTTONS =====
  document.querySelectorAll('.mode-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.mode-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      STATE.mode = btn.dataset.mode;

      // Якщо вибрали маркер — перемикаємо режим
      clearRuler();
      updateMapCursor();

      // Показуємо/ховаємо секцію поточної фігури
      const figSection = document.getElementById('current-figure-section');
      if (STATE.mode === 'draw' || STATE.mode === 'paint') {
        figSection.style.display = 'block';
      } else {
        figSection.style.display = 'none';
        cancelCurrentShape();
      }
    });
  });

  // ===== CATEGORY BUTTONS =====
  document.querySelectorAll('.cat-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      STATE.category = btn.dataset.cat;
    });
  });

  // ===== MARKER BUTTONS =====
  document.querySelectorAll('.marker-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const type = btn.dataset.marker;

      if (type === 'delete') {
        STATE.mode = 'eraser';
        document.querySelectorAll('.mode-btn').forEach(b => b.classList.remove('active'));
        document.querySelector('.mode-btn[data-mode="eraser"]').classList.add('active');
        updateMapCursor();
        return;
      }

      if (type === 'ruler') {
        STATE.mode = 'ruler';
        document.querySelectorAll('.mode-btn').forEach(b => b.classList.remove('active'));
        clearRuler();
        updateMapCursor();
        return;
      }

      // Для прапорів і бригад — ставимо режим "один клік = маркер"
      STATE.mode = 'marker-' + type;
      map.once('click', (e) => {
        placeMarker(type, e.latlng);
        // Повертаємося в pan
        STATE.mode = 'pan';
        document.querySelectorAll('.mode-btn').forEach(b => b.classList.remove('active'));
        document.querySelector('.mode-btn[data-mode="pan"]').classList.add('active');
        updateMapCursor();
      });
    });
  });

  // ===== CURRENT FIGURE CONTROLS =====
  document.getElementById('finish-shape').addEventListener('click', finishCurrentShape);
  document.getElementById('undo-point').addEventListener('click', undoLastPoint);
  document.getElementById('cancel-shape').addEventListener('click', cancelCurrentShape);

  // ===== UNDO / REDO =====
  document.getElementById('undo-btn').addEventListener('click', undo);
  document.getElementById('redo-btn').addEventListener('click', redo);

  // ===== STRIP =====
  const stripSlider = document.getElementById('strip-width');
  const stripValue = document.getElementById('strip-value');
  stripSlider.addEventListener('input', () => {
    STATE.stripWidth = parseFloat(stripSlider.value);
    stripValue.textContent = STATE.stripWidth.toFixed(1) + ' км';
  });
  document.getElementById('auto-strip').addEventListener('change', (e) => {
    STATE.autoStrip = e.target.checked;
  });
  document.getElementById('build-strip-btn').addEventListener('click', buildGrayStrip);

  // ===== ANIMATION =====
  const animSlider = document.getElementById('anim-speed');
  const animValue = document.getElementById('anim-value');
  animSlider.addEventListener('input', () => {
    STATE.animDuration = parseFloat(animSlider.value);
    animValue.textContent = STATE.animDuration.toFixed(1) + ' с';
  });
  document.getElementById('anim-enabled').addEventListener('change', (e) => {
    STATE.animEnabled = e.target.checked;
  });

  // ===== SAVE / LOAD / CLEAR =====
  document.getElementById('save-btn').addEventListener('click', saveToFile);
  document.getElementById('load-btn').addEventListener('click', () => {
    document.getElementById('file-input').click();
  });
  document.getElementById('file-input').addEventListener('change', (e) => {
    if (e.target.files[0]) loadFromFile(e.target.files[0]);
    e.target.value = '';
  });
  document.getElementById('clear-all-btn').addEventListener('click', clearAll);

  // ===== PANEL TOGGLE =====
  const panel = document.getElementById('control-panel');
  const toggleBtn = document.getElementById('toggle-panel');
  toggleBtn.addEventListener('click', () => {
    panel.classList.toggle('collapsed');
    toggleBtn.textContent = panel.classList.contains('collapsed') ? '▲' : '▼';
  });

  // ===== SETTINGS & CREDITS MODALS =====
  document.getElementById('settings-btn').addEventListener('click', () => {
    document.getElementById('settings-modal').classList.remove('hidden');
  });

  document.querySelectorAll('.close-modal').forEach(btn => {
    btn.addEventListener('click', () => {
      const modalId = btn.dataset.modal || 'settings-modal';
      document.getElementById(modalId).classList.add('hidden');
    });
  });

  document.querySelectorAll('.modal').forEach(modal => {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) modal.classList.add('hidden');
    });
  });

  // Settings options
  document.getElementById('show-hint').addEventListener('change', (e) => {
    document.getElementById('hint-bar').style.display = e.target.checked ? 'block' : 'none';
  });
  document.getElementById('show-chrono').addEventListener('change', (e) => {
    const chrono = document.getElementById('chronology');
    if (e.target.checked) {
      if (chronoEvents.length) chrono.classList.add('visible');
    } else {
      chrono.classList.remove('visible');
    }
  });
  document.getElementById('show-cities')?.addEventListener('change', () => {
    if (typeof renderCities === 'function') renderCities();
  });

  const opacitySlider = document.getElementById('poly-opacity');
  const opacityValue = document.getElementById('opacity-value');
  opacitySlider.addEventListener('input', () => {
    STATE.polyOpacity = parseFloat(opacitySlider.value);
    opacityValue.textContent = STATE.polyOpacity.toFixed(2);
    STATE.shapes.forEach(s => {
      s.layer.setStyle({ fillOpacity: STATE.polyOpacity });
    });
  });

  // ===== START SCREEN BUTTONS =====
  document.getElementById('btn-empty-map').addEventListener('click', () => startGame('empty'));
  document.getElementById('btn-real-front').addEventListener('click', () => startGame('real'));
  document.getElementById('btn-continue').addEventListener('click', () => startGame('continue'));
  document.getElementById('btn-new-game').addEventListener('click', () => {
    if (confirm('Почати нову гру? Поточний прогрес на карті буде скинуто.')) {
      drawnItems.clearLayers();
      markerGroup.clearLayers();
      STATE.shapes = [];
      STATE.markers = [];
      clearTemp();
      startGame('empty');
    }
  });
  document.getElementById('btn-load-save').addEventListener('click', () => {
    document.getElementById('file-input').click();
  });
  document.getElementById('btn-settings-start').addEventListener('click', () => {
    document.getElementById('settings-modal').classList.remove('hidden');
  });
  document.getElementById('btn-credits').addEventListener('click', () => {
    document.getElementById('credits-modal').classList.remove('hidden');
  });

  // ===== KEYBOARD SHORTCUTS =====
  document.addEventListener('keydown', (e) => {
    if (e.target.tagName === 'INPUT') return;

    if (e.ctrlKey || e.metaKey) {
      if (e.key === 'z') { e.preventDefault(); undo(); }
      if (e.key === 'y') { e.preventDefault(); redo(); }
      if (e.key === 's') { e.preventDefault(); saveToFile(); }
    }
    if (e.key === 'Escape') {
      cancelCurrentShape();
      clearRuler();
      STATE.mode = 'pan';
      document.querySelectorAll('.mode-btn').forEach(b => b.classList.remove('active'));
      document.querySelector('.mode-btn[data-mode="pan"]')?.classList.add('active');
      updateMapCursor();
      // Закриваємо панелі
      document.getElementById('quests-panel')?.classList.add('hidden');
      document.getElementById('layers-panel')?.classList.add('hidden');
    }
    if (e.key === 'Enter' && (STATE.mode === 'draw' || STATE.mode === 'paint')) {
      finishCurrentShape();
    }
  });
}
