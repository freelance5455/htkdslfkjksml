// ===== MAIN APP =====

document.addEventListener('DOMContentLoaded', () => {
  initMap();
  initLayersPanel();
  initChronology();
  initUI();
  updateStats();

  // Перший запис в історію
  pushHistory();

  // Автозбереження кожні 30 сек
  setInterval(autoSave, 30000);

  console.log('%cФронт • Симулятор територій готовий', 'color:#3b82f6;font-size:14px;font-weight:bold');
});

function initUI() {
  // ===== MODE BUTTONS =====
  document.querySelectorAll('.mode-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.mode-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      STATE.mode = btn.dataset.mode;

      // Якщо вибрали маркер — перемикаємо режим
      clearRuler();
      updateMapCursor();

      // Показуємо/ховаємо секцію поточної фігури
      const figSection = document.getElementById('current-figure-section');
      if (STATE.mode === 'draw' || STATE.mode === 'paint') {
        figSection.style.display = 'block';
      } else {
        figSection.style.display = 'none';
        cancelCurrentShape();
      }
    });
  });

  // ===== CATEGORY BUTTONS =====
  document.querySelectorAll('.cat-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      STATE.category = btn.dataset.cat;
    });
  });

  // ===== MARKER BUTTONS =====
  document.querySelectorAll('.marker-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const type = btn.dataset.marker;

      if (type === 'delete') {
        STATE.mode = 'eraser';
        document.querySelectorAll('.mode-btn').forEach(b => b.classList.remove('active'));
        document.querySelector('.mode-btn[data-mode="eraser"]').classList.add('active');
        updateMapCursor();
        return;
      }

      if (type === 'ruler') {
        STATE.mode = 'ruler';
        document.querySelectorAll('.mode-btn').forEach(b => b.classList.remove('active'));
        clearRuler();
        updateMapCursor();
        return;
      }

      // Для прапорів і бригад — ставимо режим "один клік = маркер"
      STATE.mode = 'marker-' + type;
      map.once('click', (e) => {
        placeMarker(type, e.latlng);
        // Повертаємося в pan
        STATE.mode = 'pan';
        document.querySelectorAll('.mode-btn').forEach(b => b.classList.remove('active'));
        document.querySelector('.mode-btn[data-mode="pan"]').classList.add('active');
        updateMapCursor();
      });
    });
  });

  // ===== CURRENT FIGURE CONTROLS =====
  document.getElementById('finish-shape').addEventListener('click', finishCurrentShape);
  document.getElementById('undo-point').addEventListener('click', undoLastPoint);
  document.getElementById('cancel-shape').addEventListener('click', cancelCurrentShape);

  // ===== UNDO / REDO =====
  document.getElementById('undo-btn').addEventListener('click', undo);
  document.getElementById('redo-btn').addEventListener('click', redo);

  // ===== STRIP =====
  const stripSlider = document.getElementById('strip-width');
  const stripValue = document.getElementById('strip-value');
  stripSlider.addEventListener('input', () => {
    STATE.stripWidth = parseFloat(stripSlider.value);
    stripValue.textContent = STATE.stripWidth.toFixed(1) + ' км';
  });
  document.getElementById('auto-strip').addEventListener('change', (e) => {
    STATE.autoStrip = e.target.checked;
  });
  document.getElementById('build-strip-btn').addEventListener('click', buildGrayStrip);

  // ===== ANIMATION =====
  const animSlider = document.getElementById('anim-speed');
  const animValue = document.getElementById('anim-value');
  animSlider.addEventListener('input', () => {
    STATE.animDuration = parseFloat(animSlider.value);
    animValue.textContent = STATE.animDuration.toFixed(1) + ' с';
  });
  document.getElementById('anim-enabled').addEventListener('change', (e) => {
    STATE.animEnabled = e.target.checked;
  });

  // ===== SAVE / LOAD / CLEAR =====
  document.getElementById('save-btn').addEventListener('click', saveToFile);
  document.getElementById('load-btn').addEventListener('click', () => {
    document.getElementById('file-input').click();
  });
  document.getElementById('file-input').addEventListener('change', (e) => {
    if (e.target.files[0]) loadFromFile(e.target.files[0]);
    e.target.value = '';
  });
  document.getElementById('clear-all-btn').addEventListener('click', clearAll);

  // ===== PANEL TOGGLE =====
  const panel = document.getElementById('control-panel');
  const toggleBtn = document.getElementById('toggle-panel');
  toggleBtn.addEventListener('click', () => {
    panel.classList.toggle('collapsed');
    toggleBtn.textContent = panel.classList.contains('collapsed') ? '▲' : '▼';
  });

  // ===== SETTINGS MODAL =====
  document.getElementById('settings-btn').addEventListener('click', () => {
    document.getElementById('settings-modal').classList.remove('hidden');
  });
  document.querySelector('.close-modal').addEventListener('click', () => {
    document.getElementById('settings-modal').classList.add('hidden');
  });
  document.getElementById('settings-modal').addEventListener('click', (e) => {
    if (e.target.id === 'settings-modal') {
      document.getElementById('settings-modal').classList.add('hidden');
    }
  });

  // Settings options
  document.getElementById('show-hint').addEventListener('change', (e) => {
    document.getElementById('hint-bar').style.display = e.target.checked ? 'block' : 'none';
  });
  document.getElementById('show-chrono').addEventListener('change', (e) => {
    const chrono = document.getElementById('chronology');
    if (e.target.checked) {
      if (chronoEvents.length) chrono.classList.add('visible');
    } else {
      chrono.classList.remove('visible');
    }
  });
  const opacitySlider = document.getElementById('poly-opacity');
  const opacityValue = document.getElementById('opacity-value');
  opacitySlider.addEventListener('input', () => {
    STATE.polyOpacity = parseFloat(opacitySlider.value);
    opacityValue.textContent = STATE.polyOpacity.toFixed(2);
    // Оновлюємо існуючі полігони
    STATE.shapes.forEach(s => {
      s.layer.setStyle({ fillOpacity: STATE.polyOpacity });
    });
  });

  // ===== KEYBOARD SHORTCUTS =====
  document.addEventListener('keydown', (e) => {
    if (e.target.tagName === 'INPUT') return;

    if (e.ctrlKey || e.metaKey) {
      if (e.key === 'z') { e.preventDefault(); undo(); }
      if (e.key === 'y') { e.preventDefault(); redo(); }
      if (e.key === 's') { e.preventDefault(); saveToFile(); }
    }
    if (e.key === 'Escape') {
      cancelCurrentShape();
      clearRuler();
      STATE.mode = 'pan';
      document.querySelectorAll('.mode-btn').forEach(b => b.classList.remove('active'));
      document.querySelector('.mode-btn[data-mode="pan"]').classList.add('active');
      updateMapCursor();
    }
    if (e.key === 'Enter' && (STATE.mode === 'draw' || STATE.mode === 'paint')) {
      finishCurrentShape();
    }
  });
}
