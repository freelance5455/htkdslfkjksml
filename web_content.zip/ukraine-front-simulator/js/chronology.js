// ===== CHRONOLOGY =====
const chronoEvents = [];

function addChronoEvent({ type, text, area }) {
  const now = new Date();
  const timeStr = now.toLocaleTimeString('uk-UA', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

  const event = {
    id: Date.now(),
    type: type || 'system',
    text,
    area: area || 0,
    time: timeStr,
    timestamp: now.getTime()
  };

  chronoEvents.unshift(event); // нові зверху
  if (chronoEvents.length > 50) chronoEvents.pop();

  renderChronology();
}

function renderChronology() {
  const list = document.getElementById('chrono-list');
  list.innerHTML = '';

  chronoEvents.forEach(ev => {
    const div = document.createElement('div');
    div.className = 'chrono-item ' + (ev.type || '');
    div.innerHTML = `
      <div class="time">${ev.time}</div>
      <div class="desc">${ev.text}</div>
    `;
    list.appendChild(div);
  });

  // Показуємо панель хронології якщо є події
  const chronoPanel = document.getElementById('chronology');
  if (chronoEvents.length > 0) {
    chronoPanel.classList.add('visible');
  }
}

function clearChronology() {
  chronoEvents.length = 0;
  document.getElementById('chrono-list').innerHTML = '';
  document.getElementById('chronology').classList.remove('visible');
}

function initChronology() {
  document.getElementById('clear-chrono').addEventListener('click', clearChronology);
}
