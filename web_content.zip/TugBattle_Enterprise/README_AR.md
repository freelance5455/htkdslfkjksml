# TugBattle Enterprise — أساس برمجي قابل للبناء

يشمل خادم Node.js، WebSocket، PostgreSQL، واجهة عربية، اختبارات منطق، Docker، وتوثيقًا لما يلزم قبل الإنتاج.

## تشغيل سريع
1. انسخ `.env.example` إلى `.env` وغيّر `ADMIN_API_KEY` إلى سر عشوائي طويل.
2. ثبّت Docker وDocker Compose.
3. من مجلد المشروع شغّل: `docker compose up --build`
4. افتح `http://localhost:8080` أو `http://localhost:8080/health`.

هذه حزمة أساس هندسي وليست منتجًا إنتاجيًا معتمدًا. لا تتضمن تكاملًا حقيقيًا مع TikTok أو YouTube؛ أحداث التقبيس تجريبية. لا يمكن ضمان قيمة تجارية أو جاهزية بمليون دولار من ملفات وحدها. قبل البيع يلزم موصل منصة مسموح ومختبر، نشر حقيقي، مصادقة لكل عميل، عزل مستأجرين، اختبارات أمان/ضغط، مراقبة ونسخ احتياطية. راجع `docs/PRODUCTION_GO_LIVE_AR.md`.

## API
- `GET /health`
- `GET /api/v1/matches/current`
- `POST /api/v1/admin/matches/reset` (يتطلب `x-admin-api-key`)
- `POST /api/v1/admin/matches/push` (يتطلب المفتاح)
- `POST /api/v1/demo/tap` (تجريبي فقط، عطّله في الإنتاج)
- WebSocket `/ws`
