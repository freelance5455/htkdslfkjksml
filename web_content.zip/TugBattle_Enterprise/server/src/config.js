import 'dotenv/config';
const int=(n,d)=>{const x=Number.parseInt(process.env[n]||'',10);return Number.isInteger(x)&&x>0?x:d};
export const config={
 env:process.env.NODE_ENV||'development',port:int('PORT',8080),
 db:process.env.DATABASE_URL||'postgres://tugbattle:tugbattle_dev_password@localhost:5432/tugbattle',
 adminKey:process.env.ADMIN_API_KEY||'',demo:(process.env.ENABLE_DEMO_ENDPOINTS||'false')==='true',
 origins:(process.env.ALLOWED_ORIGINS||'http://localhost:8080').split(',').map(x=>x.trim()),
 winScore:int('WIN_SCORE',100),rateWindow:int('RATE_LIMIT_WINDOW_MS',10000),rateMax:int('RATE_LIMIT_MAX',40)
};
if(config.env==='production'&&config.adminKey.length<32)throw Error('ADMIN_API_KEY must be at least 32 chars in production');
