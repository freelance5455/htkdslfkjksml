import pg from 'pg'; import {config} from './config.js';
const {Pool}=pg; export const pool=new Pool({connectionString:config.db,max:15,idleTimeoutMillis:30000,connectionTimeoutMillis:5000});
export async function schema(){await pool.query(`
CREATE TABLE IF NOT EXISTS matches(id UUID PRIMARY KEY, tenant_slug TEXT NOT NULL DEFAULT 'demo',
status TEXT NOT NULL CHECK(status IN ('waiting','running','finished')), red_score INTEGER NOT NULL DEFAULT 0,
blue_score INTEGER NOT NULL DEFAULT 0,winner TEXT CHECK(winner IN ('red','blue') OR winner IS NULL),
total_events BIGINT NOT NULL DEFAULT 0,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
CREATE INDEX IF NOT EXISTS matches_tenant_created_idx ON matches(tenant_slug,created_at DESC);
CREATE TABLE IF NOT EXISTS game_events(id BIGSERIAL PRIMARY KEY,match_id UUID NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
platform TEXT NOT NULL,platform_event_id TEXT NOT NULL,team TEXT NOT NULL CHECK(team IN ('red','blue')),
username TEXT NOT NULL,power INTEGER NOT NULL CHECK(power BETWEEN 1 AND 5),received_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
UNIQUE(platform,platform_event_id));`)}
