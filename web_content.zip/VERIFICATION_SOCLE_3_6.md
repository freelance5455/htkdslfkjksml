# Vérification — Socle 3.6

- 213 tests automatisés réussis sur 213 (`npm test -- --test-concurrency=8`).
- Syntaxe JavaScript vérifiée pour tous les fichiers de `src/` et `tests/` avec `node --check`.
- 24 modules de moteur comparés à la Socle 3.5 : dames, arènes, simulation, calendrier, championnat, huit compétitions, statistiques individuelles, contrats, transferts, relations, match et scène 3D ; aucun changement.
- Archive ZIP contrôlée avec `unzip -t` après génération.
- Test visuel réel dans un navigateur mobile non effectué dans cet environnement ; l'interface reste à valider sur appareil.
