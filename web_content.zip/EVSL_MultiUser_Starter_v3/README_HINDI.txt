EVSL AUTO MAINTENANCE MANAGEMENT - VERSION 3 STARTER PACKAGE

इस ZIP में:
1. EVSL_Auto_Maintenance_Advanced_v3_Offline.html
   - Hindi + English interface
   - Vehicle Master, Breakdown Entry, PM, Inventory, Daily Work Report
   - Vehicle Parts Master, Analytics, CSV export
   - JSON Backup / Restore और local auto-backup
   - Offline उपयोग: डेटा इसी मोबाइल/ब्राउज़र में सेव होता है।

महत्वपूर्ण - Multi-user Online Sync की स्थिति:
यह HTML अभी 4 मोबाइल के बीच Cloud Sync चालू नहीं करता। 4 सदस्यों का साझा डेटा, Username/Password Login और Offline-to-Online Sync चालू करने के लिए Firebase (या अन्य Cloud Server) का प्रोजेक्ट, सुरक्षा नियम और ऐप में उसके कॉन्फ़िगरेशन की जरूरत है। इस ZIP को अभी Multi-user Online App या APK न समझें।

अगले चरण में Cloud setup के लिए चाहिए:
- Admin और 3 Members के लिए अलग-अलग login credentials (पासवर्ड यहाँ चैट में न भेजें)
- Cloud project की configuration
- सभी सदस्यों के मोबाइल में एक ही app version
- पुराने डेटा का JSON Backup, ताकि उसे Cloud में migrate किया जा सके

पुराना डेटा सुरक्षित रखने के लिए:
1. पुरानी ऐप खोलें और Backup Now दबाकर JSON फाइल डाउनलोड करें।
2. इस ZIP की HTML फाइल चलाकर Backup / Restore में JSON Restore करें।
3. सभी रिकॉर्ड जांचे बिना पुरानी ऐप uninstall न करें।

सुरक्षा नोट:
किसी भी रिकॉर्ड को स्थायी रूप से मिटाने के बजाय Recycle Bin / soft-delete और audit history Cloud version में लागू की जानी चाहिए।
