"use strict";

const $ = s => document.querySelector(s);
const main = $("#main");
const modal = $("#modal");
const modalContent = $("#modalContent");

const COLORS = [
  {name:"Rosa",hex:"#d96e97"},
  {name:"Azul noche",hex:"#263d71"},
  {name:"Lavanda",hex:"#a58ad0"},
  {name:"Verde salvia",hex:"#8aa995"},
  {name:"Rojo cereza",hex:"#a93451"},
  {name:"Crema",hex:"#f1ddbc"},
  {name:"Negro",hex:"#33313c"},
  {name:"Celeste",hex:"#8bc9df"}
];

const FABRICS = [
  {id:"cotton",name:"Algodón",price:22,quality:75,pattern:"plain"},
  {id:"satin",name:"Satén",price:38,quality:90,pattern:"shine"},
  {id:"linen",name:"Lino",price:29,quality:82,pattern:"linen"},
  {id:"velvet",name:"Terciopelo",price:48,quality:96,pattern:"velvet"},
  {id:"denim",name:"Denim",price:34,quality:84,pattern:"denim"},
  {id:"lace",name:"Encaje",price:43,quality:88,pattern:"lace"}
];

const GARMENTS = [
  {id:"dress",name:"Vestido",icon:"👗",unlock:1,base:110,material:2},
  {id:"shirt",name:"Remera",icon:"👕",unlock:1,base:65,material:1},
  {id:"skirt",name:"Falda",icon:"🩰",unlock:1,base:75,material:1},
  {id:"pants",name:"Pantalón",icon:"👖",unlock:2,base:90,material:2},
  {id:"shirtFormal",name:"Camisa",icon:"👔",unlock:2,base:100,material:2},
  {id:"jacket",name:"Campera",icon:"🧥",unlock:3,base:155,material:3},
  {id:"suit",name:"Traje",icon:"🤵",unlock:4,base:240,material:4},
  {id:"uniform",name:"Uniforme",icon:"🥼",unlock:2,base:125,material:2}
];

const UPGRADES = [
  {id:"machine",name:"Máquina profesional",icon:"🪡",cost:350,desc:"+12 calidad de costura",effect:"sew"},
  {id:"scissors",name:"Tijeras de precisión",icon:"✂️",cost:220,desc:"+12 calidad de corte",effect:"cut"},
  {id:"table",name:"Mesa de corte grande",icon:"🧵",cost:280,desc:"Reduce el desperdicio de tela",effect:"waste"},
  {id:"mannequin",name:"Maniquí de diseño",icon:"👗",cost:300,desc:"Desbloquea una galería de presentación",effect:"show"},
  {id:"fitting",name:"Probador",icon:"🪞",cost:450,desc:"Permite probar prendas antes de entregar",effect:"fit"},
  {id:"embroidery",name:"Kit de bordado",icon:"🪡",cost:400,desc:"+10 calidad de decoración",effect:"embroidery"},
  {id:"helper",name:"Ayudante de atelier",icon:"🧑‍🎨",cost:600,desc:"+5 calidad de costura en cada encargo",effect:"helper"}
];

const CLIENTS = [
  {name:"Valentina",face:"👩🏻‍🦰",personality:"Amable",lines:["¡Hola! Tengo un evento especial y me encantaría algo hecho a medida.","Confío en tu creatividad. Quiero una prenda que tenga personalidad."]},
  {name:"Camila",face:"👩🏽",personality:"Exigente",lines:["Busco algo muy concreto. Para mí los detalles son importantes.","Me gustaría revisar el diseño antes de que lo termines."]},
  {name:"Martina",face:"👩🏼‍🦱",personality:"Indecisa",lines:["Tengo varias ideas, pero todavía no sé cómo combinarlas.","¡Ay, me gustan tantas opciones! Ayudame a elegir."]},
  {name:"Lucía",face:"👩🏻",personality:"Paciente",lines:["No tengo apuro, prefiero que el trabajo quede bien hecho.","Me gustan los diseños delicados y los materiales de calidad."]},
  {name:"Sofía",face:"👩🏾‍🦱",personality:"Entusiasta",lines:["¡Estoy preparando algo increíble y necesito un look especial!","¡Qué emoción! Me encanta usar ropa original."]},
  {name:"Abril",face:"👩🏼‍🦰",personality:"Recurrente",lines:["¡Volví! Me encantó cómo quedó mi último encargo.","Ya conozco tu atelier y tengo una nueva idea."]}
];

const FIRST_STATE = {
  boutique:"Mi Atelier",
  money:500,xp:0,rep:10,level:1,
  inventory:{cotton:5,satin:1,linen:1,velvet:0,denim:0,lace:0,
    thread:8,buttons:5,zipper:2,ribbon:3,embroidery:1},
  upgrades:[],page:"boutique",orders:[],catalog:[],history:[],
  daily:{day:"",done:0},tutorial:true,freeMode:false,
  sound:true,clientsSeen:[],nextId:1,
  design:{type:"dress",color:"#d96e97",secondary:"#f1ddbc",
    fabric:"cotton",length:"long",sleeves:"short",neck:"round",
    print:"plain",pockets:false,buttons:false,decoration:"none"}
};

let game = loadGame();
let activeOrder = null;
let design = {...game.design};
let craft = {stage:0,cutQuality:0,sewQuality:0,decorQuality:80,cutTarget:0,sewTarget:0,cutDone:false,sewDone:false};
let modalCallback = null;
let toastTimer;
let sewFrame = null;
let lastClick = 0;

function loadGame(){
  try {
    const saved = JSON.parse(localStorage.getItem("fashionStudioSave"));
    if(saved) return {...structuredClone(FIRST_STATE),...saved,
      inventory:{...FIRST_STATE.inventory,...saved.inventory},
      design:{...FIRST_STATE.design,...saved.design}};
  } catch(e){}
  return structuredClone(FIRST_STATE);
}

function save(){
  try{
    game.design = {...design};
    game.page = game.page || "boutique";
    localStorage.setItem("fashionStudioSave",JSON.stringify(game));
    toast("Partida guardada 💾");
  }catch(e){toast("No se pudo guardar en este navegador.");}
}

function toast(text){
  const el=$("#toast");
  el.textContent=text;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer=setTimeout(()=>el.classList.remove("show"),2400);
}

function money(n){return Math.floor(n).toLocaleString("es-AR");}
function garment(id){return GARMENTS.find(g=>g.id===id)||GARMENTS[0];}
function fabric(id){return FABRICS.find(f=>f.id===id)||FABRICS[0];}
function upgrade(id){return game.upgrades.includes(id);}
function random(arr){return arr[Math.floor(Math.random()*arr.length)];}
function choiceLabel(list,value){return list.find(x=>x[0]===value)?.[1]||value;}
function level(){return 1+Math.floor(game.xp/100);}
function rankName(){
  const n=level();
  if(n>=9)return "Alta costura";
  if(n>=6)return "Diseñador reconocido";
  if(n>=4)return "Boutique reconocida";
  if(n>=2)return "Modista principiante";
  return "Aprendiz";
}
function notifySound(freq=500){
  if(!game.sound)return;
  try{
    const C=window.AudioContext||window.webkitAudioContext;
    const a=new C(),o=a.createOscillator(),g=a.createGain();
    o.frequency.value=freq;
    g.gain.value=.04;
    g.gain.exponentialRampToValueAtTime(.001,a.currentTime+.14);
    o.connect(g);g.connect(a.destination);o.start();o.stop(a.currentTime+.14);
    o.onended=()=>a.close();
  }catch(e){}
}

function updateHeader(){
  $("#brandName").textContent=game.boutique.toUpperCase();
  $("#money").textContent=money(game.money);
  $("#rank").textContent=`${level()} · ${rankName()}`;
  $("#rep").textContent=game.rep;
  $("#xpbar").style.width=(game.xp%100)+"%";
  $("#xptext").textContent=`${game.xp%100} / 100 XP`;
  $("#orderCount").textContent=game.orders.filter(o=>o.status!=="done"&&o.status!=="rejected").length;
  $("#sound").textContent=game.sound?"♫":"🔇";
  document.querySelectorAll(".nav button").forEach(b=>b.classList.toggle("active",b.dataset.page===game.page));
}

function changePage(page){
  game.page=page;
  render();
  saveQuiet();
}

function saveQuiet(){
  try{
    game.design={...design};
    localStorage.setItem("fashionStudioSave",JSON.stringify(game));
  }catch(e){}
}

function showModal(html,callback=null){
  modalContent.innerHTML=html;
  modal.classList.remove("hidden");
  modalCallback=callback;
}
function closeModal(){
  modal.classList.add("hidden");
  modalCallback=null;
  if(sewFrame)cancelAnimationFrame(sewFrame);
  sewFrame=null;
}
$("#closeModal").onclick=closeModal;
modal.addEventListener("click",e=>{if(e.target===modal)closeModal();});
$("#sound").onclick=()=>{
  game.sound=!game.sound;
  updateHeader();saveQuiet();
  if(game.sound)notifySound();
};
$("#saveBtn").onclick=save;

document.querySelectorAll(".nav button").forEach(b=>{
  b.onclick=()=>changePage(b.dataset.page);
});

function garmentSVG(d=design,preview=false){
  const c=d.color||"#d96e97",s=d.secondary||"#f1ddbc";
  const type=d.type||"dress";
  const isDress=type==="dress";
  const isSkirt=type==="skirt";
  const isPants=type==="pants";
  const isJacket=type==="jacket";
  const isSuit=type==="suit";
  const isFormal=type==="shirtFormal";
  const isUniform=type==="uniform";
  const isTop=!(isDress||isSkirt||isPants);
  let body="",sleeves="",extra="";
  if(isDress){
    body=d.length==="short"
      ?`<path d="M78 100 Q100 88 122 100 L143 183 Q100 200 57 183Z" fill="${c}" stroke="#fff" stroke-opacity=".35" stroke-width="2"/>`
      :`<path d="M78 100 Q100 88 122 100 L156 223 Q100 241 44 223Z" fill="${c}" stroke="#fff" stroke-opacity=".35" stroke-width="2"/>`;
    body+=`<path d="M82 102 Q100 120 118 102" fill="none" stroke="${s}" stroke-width="3"/>`;
    if(d.sleeves!=="none") sleeves=`<path d="M79 98 L57 112 L64 132 L82 119Z M121 98 L143 112 L136 132 L118 119Z" fill="${c}" stroke="${s}" stroke-width="1.5"/>`;
  }else if(isSkirt){
    body=`<path d="M79 100 L121 100 L148 219 Q100 235 52 219Z" fill="${c}" stroke="${s}" stroke-width="2"/>`;
    if(d.length==="short")body=`<path d="M79 100 L121 100 L137 166 Q100 177 63 166Z" fill="${c}" stroke="${s}" stroke-width="2"/>`;
  }else if(isPants){
    body=`<path d="M78 91 L122 91 L130 139 L124 227 L103 227 L98 149 L94 227 L73 227 L70 139Z" fill="${c}" stroke="${s}" stroke-width="2"/>`;
  }else{
    body=`<path d="M81 86 L119 86 L133 103 L127 174 L73 174 L67 103Z" fill="${c}" stroke="${s}" stroke-width="2"/>`;
    if(d.sleeves==="long")sleeves=`<path d="M80 89 L61 101 L48 155 L64 160 L84 115Z M120 89 L139 101 L152 155 L136 160 L116 115Z" fill="${c}" stroke="${s}" stroke-width="2"/>`;
    else if(d.sleeves!=="none")sleeves=`<path d="M80 89 L62 100 L73 121 L87 108Z M120 89 L138 100 L127 121 L113 108Z" fill="${c}" stroke="${s}" stroke-width="2"/>`;
    if(isJacket||isSuit||isFormal||isUniform)extra+=`<path d="M99 92 L89 111 L100 123 L111 111 L101 92Z" fill="${s}" stroke="${s}" stroke-width="1"/>`;
  }
  let print="";
  if(d.print==="dots"){
    print=`<g fill="${s}" opacity=".9">${Array.from({length:12},(_,i)=>`<circle cx="${65+(i%4)*22}" cy="${112+Math.floor(i/4)*28}" r="2.8"/>`).join("")}</g>`;
  }else if(d.print==="stripes"){
    print=`<path d="M75 108 L85 168 M92 107 L98 168 M109 107 L116 168" stroke="${s}" stroke-width="4" opacity=".8"/>`;
  }else if(d.print==="floral"){
    print=`<g fill="${s}">${[0,1,2,3,4].map((n)=>`<g transform="translate(${75+(n%2)*35} ${115+n*12})"><circle r="4"/><circle cx="5" r="3"/><circle cy="5" r="3"/><circle cx="-5" r="3"/></g>`).join("")}</g>`;
  }else if(d.print==="plaid"){
    print=`<path d="M74 100V173 M92 100V173 M110 100V173 M70 120H130 M70 145H130" stroke="${s}" stroke-width="3" opacity=".65"/>`;
  }
  const buttons=d.buttons?`<g fill="${s}" stroke="#fff" stroke-width=".7">${[0,1,2,3].map(n=>`<circle cx="100" cy="${112+n*13}" r="2.5"/>`).join("")}</g>`:"";
  const pockets=d.pockets?`<path d="M77 128h13v14H77z M110 128h13v14H110z" fill="none" stroke="${s}" stroke-width="2"/>`:"";
  let neck="";
  if(d.neck==="v")neck=`<path d="M82 89 L100 113 L118 89" fill="none" stroke="${s}" stroke-width="3"/>`;
  else if(d.neck==="square")neck=`<path d="M84 88 V102 H116 V88" fill="none" stroke="${s}" stroke-width="3"/>`;
  else neck=`<path d="M87 88 Q100 109 113 88" fill="none" stroke="${s}" stroke-width="3"/>`;
  if(isSkirt||isPants)neck="";
  let decoration="";
  if(d.decoration==="bow")decoration=`<path d="M91 127 Q76 112 79 131 L98 135 L102 135 L121 131 Q124 112 109 127 L100 135Z" fill="${s}" stroke="#fff" stroke-width="1"/>`;
  if(d.decoration==="lace")decoration=`<path d="M51 214 Q100 229 149 214" fill="none" stroke="${s}" stroke-width="5" stroke-dasharray="3 3"/>`;
  if(d.decoration==="sparkle")decoration=`<g fill="${s}">${[0,1,2,3].map(n=>`<path d="M${78+n*13} ${132+n%2*20} l3 -7 3 7 7 3 -7 3 -3 7 -3 -7 -7 -3Z"/>`).join("")}</g>`;
  return `<svg class="garment" viewBox="0 0 200 250" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="cloth" x1="0" x2="1"><stop stop-color="#fff" stop-opacity=".2"/><stop offset=".45" stop-color="#fff" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".12"/></linearGradient></defs>
    <ellipse cx="100" cy="232" rx="55" ry="7" fill="#9b667c" opacity=".12"/>
    <path d="M87 34 Q100 25 113 34 L116 52 Q112 68 100 69 Q88 68 84 52Z" fill="#e8bda9"/>
    <path d="M82 40 Q79 20 99 20 Q120 20 117 43 L111 34 L91 34 L84 47Z" fill="#765047"/>
    <path d="M88 65 L112 65 L120 89 L80 89Z" fill="#e8bda9"/>
    ${sleeves}${body}
    <path d="${isDress||isSkirt||isPants?"M60 180 L140 180":"M74 160 L126 160"}" fill="none" stroke="#fff" stroke-opacity=".2" stroke-width="2"/>
    ${print}${neck}${buttons}${pockets}${decoration}
    <path d="${isDress?"M48 220 Q100 236 152 220":isSkirt?"M55 218 Q100 232 145 218":isPants?"M75 218 L94 218 M105 218 L125 218":"M72 170 H128"}" fill="none" stroke="${s}" stroke-width="2" opacity=".8"/>
    <path d="${isDress?"M58 120 L72 180 M142 120 L128 180":isSkirt?"M73 120 L62 200 M127 120 L138 200":"M78 102 L83 158 M122 102 L117 158"}" stroke="#fff" stroke-opacity=".13" stroke-width="2" fill="none"/>
    <path d="${isDress?"M44 223 Q100 241 156 223":isSkirt?"M52 219 Q100 235 148 219":isPants?"M73 227 H94 M103 227 H124":"M73 174 H127"}" fill="none" stroke="#fff" stroke-width="1.5" opacity=".55"/>
    <path d="${isDress?"M57 183 Q100 200 143 183":isSkirt?"M57 166 Q100 178 143 166":"M68 103 L132 103"}" fill="none" stroke="${s}" stroke-width="1.5" opacity=".7"/>
    <path d="${isDress?"M78 100 Q100 88 122 100":isSkirt?"M79 100 H121":"M81 86 L119 86"}" fill="none" stroke="#fff" stroke-opacity=".7" stroke-width="2"/>
    <path d="${isDress?"M44 223 Q100 241 156 223":isSkirt?"M52 219 Q100 235 148 219":"M73 174 H127"}" fill="none" stroke="url(#cloth)" stroke-width="9"/>
  </svg>`;
}

function previewHTML(d=design){
  return `<div class="scene"><span class="decor">✦</span><div class="manDisplay">${garmentSVG(d,true)}</div></div>`;
}

function makeOrder(){
  const c=random(CLIENTS);
  const types=GARMENTS.filter(g=>g.unlock<=level()).map(g=>g.id);
  const type=random(types);
  const color=random(COLORS);
  const second=random(COLORS.filter(x=>x.hex!==color.hex));
  const fab=game.inventory[random(["cotton","cotton","satin","linen","denim"])]>0
    ?random(["cotton","cotton","satin","linen","denim"]):"cotton";
  const req={
    type,color:color.hex,
    length:random(["short","long"]),
    sleeves:random(["short","long","none"]),
    decoration:random(["bow","lace","sparkle","none"]),
    print:random(["plain","dots","floral","stripes"])
  };
  const g=garment(type);
  const budget=g.base+Math.floor(Math.random()*65);
  const order={
    id:game.nextId++,client:c.name,face:c.face,personality:c.personality,
    dialogue:c.lines,req,budget,price:budget+Math.floor(Math.random()*30),
    minQuality:62+Math.floor(Math.random()*15),deadline:random(["Normal","Normal","Urgente"]),
    status:"new",fabric:fab,created:Date.now()
  };
  game.orders.unshift(order);
  return order;
}

function ensureOrders(){
  if(!game.orders.some(o=>o.status!=="done"&&o.status!=="rejected")){
    makeOrder();
  }
  if(game.orders.filter(o=>o.status!=="done"&&o.status!=="rejected").length<2 && Math.random()<.65){
    makeOrder();
  }
}

function requirementsHTML(o){
  const r=o.req;
  return `<div class="orderline"><span>Prenda</span><b>${garment(r.type).icon} ${garment(r.type).name}</b></div>
  <div class="orderline"><span>Color</span><b><i class="swatch" style="background:${r.color}"></i>${COLORS.find(c=>c.hex===r.color)?.name||"Personalizado"}</b></div>
  <div class="orderline"><span>Largo</span><b>${r.length==="long"?"Largo":"Corto"}</b></div>
  <div class="orderline"><span>Mangas</span><b>${choiceLabel([["short","Cortas"],["long","Largas"],["none","Sin mangas"]],r.sleeves)}</b></div>
  <div class="orderline"><span>Estampado</span><b>${choiceLabel([["plain","Liso"],["dots","Lunares"],["floral","Flores"],["stripes","Rayas"]],r.print)}</b></div>
  <div class="orderline"><span>Detalle</span><b>${choiceLabel([["none","Minimalista"],["bow","Lazo"],["lace","Encaje"],["sparkle","Brillos"]],r.decoration)}</b></div>
  <div class="orderline"><span>Presupuesto</span><b>🪙 ${money(o.budget)}</b></div>
  <div class="orderline"><span>Calidad mínima</span><b>${o.minQuality}/100</b></div>`;
}

function dialogue(o){
  const c=CLIENTS.find(x=>x.name===o.client)||CLIENTS[0];
  showModal(`<div class="eyebrow">NUEVA CLIENTA</div>
    <div class="clientrow" style="margin-top:20px"><div class="avatar">${o.face}</div><div><h2>${o.client}</h2><span class="tag">${o.personality}</span></div></div>
    <p>«${random(o.dialogue)}»</p>
    <p>«Necesito un/a <b>${garment(o.req.type).name.toLowerCase()}</b>. Mi presupuesto es de <b>${money(o.budget)} monedas</b>. ¿Podemos diseñarlo juntas?»</p>
    <div class="btnrow"><button class="btn primary" id="acceptDialogue">¡Sí, vamos a diseñar!</button><button class="btn" id="declineDialogue">Ahora no</button></div>`);
  $("#acceptDialogue").onclick=()=>{
    o.status="accepted";
    activeOrder=o;
    design={...design,...o.req,fabric:o.fabric,secondary:"#f1ddbc",neck:"round",pockets:false,buttons:false};
    craft={stage:0,cutQuality:0,sewQuality:0,decorQuality:80,cutTarget:0,sewTarget:0,cutDone:false,sewDone:false};
    closeModal();changePage("workshop");notifySound(620);
  };
  $("#declineDialogue").onclick=()=>{closeModal();toast("El pedido sigue disponible.");};
}

function renderBoutique(){
  const open=game.orders.find(o=>o.status==="new");
  return `<div class="hero"><div><div class="eyebrow">BIENVENIDA A TU MUNDO CREATIVO</div>
    <h1>Tu atelier,<br>tu obra de arte.</h1>
    <p>Diseñá prendas únicas, escuchá a tus clientes y convertí tu pequeño atelier en una marca inolvidable.</p>
    <div class="btnrow"><button class="btn primary" data-action="newOrder">📋 Atender cliente</button><button class="btn" data-page="workshop">🧵 Ir al taller</button></div>
    </div><div class="heroart">🪡👗✂️</div></div>
    <div class="grid">
      <div class="card"><div class="eyebrow">TU ESPACIO</div><div class="room" style="margin-top:12px"><div class="shelf"></div><div class="tablecloth"></div><div class="machine">🧵</div><div class="roomtitle">TALLER DE COSTURA</div></div><p>Tu espacio de creación está listo para trabajar.</p></div>
      <div class="card"><div class="eyebrow">CLIENTES Y ENCARGOS</div><div style="font-size:43px;margin:20px 0">🛍️💬</div><h3>${open?"¡Tenés una nueva clienta!":"¡Busquemos nuevos encargos!"}</h3><p>${open?"Escuchá su idea y prepará una prenda a medida.":"Generá un nuevo pedido para seguir creciendo."}</p><button class="btn primary" data-action="newOrder">${open?"Conocer clienta":"Buscar cliente"}</button></div>
      <div class="card"><div class="eyebrow">TU NEGOCIO</div><div class="miniStats" style="margin-top:15px"><div><b>${game.catalog.length}</b><small>Diseños</small></div><div><b>${game.history.length}</b><small>Entregas</small></div><div><b>${game.rep}</b><small>Reputación</small></div></div><p style="margin-top:15px">Cada encargo terminado te acerca a la alta costura.</p><button class="btn" data-page="collection">Ver mi colección →</button></div>
    </div>
    <div class="pagehead" style="margin-top:25px"><div><h2>Pedidos recientes</h2><p class="sub">Tus encargos pendientes y terminados.</p></div><button class="btn" data-page="orders">Ver todos</button></div>
    ${renderOrderCards(game.orders.slice(0,3))}`;
}

function renderOrderCards(list){
  if(!list.length)return `<div class="card empty">Todavía no hay pedidos. ¡Atendé a tu primera clienta!</div>`;
  return `<div class="grid">${list.map(o=>`<div class="card">
    <div class="clientrow"><div class="avatar">${o.face}</div><div><h3>${o.client}</h3><span class="tag">${o.status==="new"?"Nuevo":o.status==="accepted"?"Aceptado":o.status==="done"?"Entregado":o.status==="rejected"?"Rechazado":"En proceso"}</span></div></div>
    <p>${garment(o.req.type).name} · Presupuesto ${money(o.budget)} monedas</p>
    <div class="btnrow">${o.status==="new"?`<button class="btn primary" data-action="dialogue" data-id="${o.id}">Hablar</button><button class="btn" data-action="reject" data-id="${o.id}">Rechazar</button>`:""}${o.status==="accepted"||o.status==="working"?`<button class="btn primary" data-action="resume" data-id="${o.id}">Continuar</button>`:""}${o.status==="done"?`<span class="tag">✓ Entregado</span>`:""}</div>
    </div>`).join("")}</div>`;
}

function renderOrders(){
  return `<div class="pagehead"><div><h1>Pedidos y clientes</h1><p class="sub">Cada encargo es una nueva oportunidad para demostrar tu talento.</p></div><button class="btn primary" data-action="newOrder">＋ Buscar cliente</button></div>
  <div class="grid two"><div class="card"><h3>📋 Encargos activos</h3>${renderOrderCards(game.orders.filter(o=>!["done","rejected"].includes(o.status)))}</div><div class="card"><h3>📚 Historial de clientes</h3>${game.history.length?game.history.slice(-8).reverse().map(h=>`<div class="orderline"><span>${h.face} ${h.client}<br><small>${garment(h.type).name}</small></span><b>🪙 ${money(h.paid)}</b></div>`).join(""):`<p>Aún no hay entregas. Tus clientes aparecerán aquí después del primer trabajo.</p>`}</div></div>
  <div style="margin-top:22px"><h2>Pedidos terminados</h2>${renderOrderCards(game.orders.filter(o=>["done","rejected"].includes(o.status)).slice(0,6))}</div>`;
}

function garmentOptions(){
  return GARMENTS.filter(g=>g.unlock<=level()).map(g=>`<option value="${g.id}">${g.icon} ${g.name}</option>`).join("");
}

function renderDesigner(){
  const d=design;
  const g=garment(d.type);
  return `<div class="grid two">
    <div><div class="pagehead"><div><div class="eyebrow">VISTA PREVIA EN MANIQUÍ</div><h2>Tu diseño</h2></div><span class="tag">${g.icon} ${g.name}</span></div>
      ${previewHTML(d)}
      <div class="card" style="margin-top:12px"><div class="materialrow"><span>Material</span><b>${fabric(d.fabric).name}</b></div><div class="materialrow"><span>Calidad del tejido</span><b>${fabric(d.fabric).quality}/100</b></div><div class="materialrow"><span>Estilo</span><b>${d.print==="plain"?"Liso":d.print==="floral"?"Floral":d.print==="dots"?"Lunares":"Rayas"}</b></div></div>
    </div>
    <div class="card">
      <div class="eyebrow">ESTUDIO DE DISEÑO</div><h2>Diseñá cada detalle</h2>
      <label class="label">Tipo de prenda</label><select id="dType">${garmentOptions()}</select>
      <div class="optiongrid"><div><label class="label">Color principal</label><input id="dColor" type="color" value="${d.color}"></div><div><label class="label">Color de detalles</label><input id="dSecondary" type="color" value="${d.secondary}"></div></div>
      <label class="label">Tipo de tela</label><select id="dFabric">${FABRICS.map(f=>`<option value="${f.id}">${f.name} · ${f.quality} calidad · ${f.price} monedas</option>`).join("")}</select>
      <label class="label">Estampado</label><select id="dPrint"><option value="plain">Liso</option><option value="dots">Lunares</option><option value="stripes">Rayas</option><option value="floral">Floral</option><option value="plaid">Cuadros</option></select>
      <div class="optiongrid"><div><label class="label">Largo</label><select id="dLength"><option value="short">Corto</option><option value="long">Largo</option></select></div><div><label class="label">Mangas</label><select id="dSleeves"><option value="short">Cortas</option><option value="long">Largas</option><option value="none">Sin mangas</option></select></div></div>
      <label class="label">Cuello</label><select id="dNeck"><option value="round">Redondo</option><option value="v">En V</option><option value="square">Cuadrado</option></select>
      <label class="label">Decoración</label><select id="dDecoration"><option value="none">Sin decoración</option><option value="bow">Lazo</option><option value="lace">Encaje</option><option value="sparkle">Brillos</option></select>
      <label class="checkline"><input id="dPockets" type="checkbox" ${d.pockets?"checked":""}> Agregar bolsillos</label>
      <label class="checkline"><input id="dButtons" type="checkbox" ${d.buttons?"checked":""}> Agregar botones</label>
      <div class="btnrow"><button class="btn" data-action="randomDesign">🎲 Inspirarme</button><button class="btn primary" data-action="saveDesign">Guardar diseño</button></div>
    </div>
  </div>`;
}

function bindDesigner(){
  const map={dType:"type",dColor:"color",dSecondary:"secondary",dFabric:"fabric",dPrint:"print",dLength:"length",dSleeves:"sleeves",dNeck:"neck",dDecoration:"decoration",dPockets:"pockets",dButtons:"buttons"};
  Object.entries(map).forEach(([id,key])=>{
    const el=$("#"+id);
    if(!el)return;
    el.value=design[key]??el.value;
    el.addEventListener("input",()=>{
      design[key]=el.type==="checkbox"?el.checked:el.value;
      if(key==="type" && garment(design.type).unlock>level()){
        design.type="dress";el.value="dress";toast("Todavía no desbloqueaste esa prenda.");return;
      }
      const old=main.innerHTML;
      const scene=main.querySelector(".scene");
      if(scene)scene.outerHTML=previewHTML(design);
      if(key==="type"||key==="fabric")render();
      saveQuiet();
    });
  });
}

function renderWorkshop(){
  const o=activeOrder||game.orders.find(x=>x.status==="accepted"||x.status==="working");
  if(o)activeOrder=o;
  const stage=craft.stage;
  const stages=["Diseñar","Patrón","Cortar","Coser","Decorar","Entregar"];
  return `<div class="pagehead"><div><h1>El taller de costura</h1><p class="sub">Cada puntada y cada elección cuentan.</p></div><span class="tag">${o?"Encargo #"+o.id:"Modo creativo"}</span></div>
    <div class="stepper">${stages.map((s,i)=>`<span class="step ${i===stage?"current":i<stage?"":" "}">${i+1}. ${s}</span>`).join("")}</div>
    ${o?`<div class="card" style="margin-bottom:14px"><div class="clientrow"><div class="avatar">${o.face}</div><div><h3>Encargo de ${o.client}</h3><p>${garment(o.req.type).name} · Presupuesto ${money(o.budget)} monedas · Calidad mínima ${o.minQuality}/100</p></div><button class="btn" data-action="showRequirements">Ver pedido</button></div></div>`:`<div class="card" style="margin-bottom:14px"><h3>Modo libre</h3><p>Diseñá sin presión, sin gastar materiales y sin penalizaciones.</p></div>`}
    <div class="grid two"><div class="card" id="workStage">${renderStage(o)}</div><div><div class="card"><div class="eyebrow">VISTA DEL DISEÑO</div>${previewHTML(design)}<div class="materialrow"><span>Calidad de corte</span><b>${craft.cutQuality||"—"}</b></div><div class="materialrow"><span>Calidad de costura</span><b>${craft.sewQuality||"—"}</b></div><div class="materialrow"><span>Decoración</span><b>${craft.decorQuality}</b></div></div><div class="card" style="margin-top:12px"><h3>🧺 Materiales disponibles</h3>${inventoryLine("Tela",design.fabric)}${inventoryLine("Hilo","thread")}${inventoryLine("Botones","buttons")}</div></div></div>`;
}

function inventoryLine(name,id){
  const f=FABRICS.find(x=>x.id===id);
  const qty=game.inventory[id]||0;
  return `<div class="materialrow"><span>${name}</span><b>${f?f.name+" · ":""}${qty} unidades</b></div>`;
}

function renderStage(o){
  if(craft.stage===0)return `<div class="eyebrow">ETAPA 1</div><h2>Diseño y patrón</h2><p>Elegí la silueta, la tela, el color y los detalles. La vista previa se actualizará automáticamente.</p><div class="btnrow"><button class="btn primary" data-action="nextStage">Confirmar diseño →</button><button class="btn" data-action="randomDesign">Inspirarme</button></div>`;
  if(craft.stage===1){
    const g=garment(design.type);
    return `<div class="eyebrow">ETAPA 2</div><h2>Preparar el patrón</h2><p>Antes de cortar, revisá las piezas necesarias para ${g.name.toLowerCase()}.</p><div class="orderline"><span>Piezas de tela</span><b>${g.material} unidades</b></div><div class="orderline"><span>Hilo necesario</span><b>${g.material*2} unidades</b></div><div class="orderline"><span>Botones</span><b>${design.buttons?4:0}</b></div><div class="orderline"><span>Tela disponible</span><b>${game.inventory[design.fabric]||0} unidades</b></div><div class="btnrow"><button class="btn primary" data-action="cutStart">✂️ Preparar tela y cortar</button><button class="btn" data-action="prevStage">← Volver</button></div>`;
  }
  if(craft.stage===2){
    return `<div class="eyebrow">ETAPA 3 · PRECISIÓN</div><h2>Corte de tela</h2><p>Cuando la aguja de corte pase por la zona dorada, tocá el botón. ¡Intentá acertar en el centro!</p><div class="cutarea"><div class="cutpattern"></div><div class="cutline"></div></div><div class="sewtrack"><i id="cutMarker"></i></div><div class="btnrow"><button class="btn primary" data-action="cutTap">✂️ Cortar ahora</button></div><p id="cutFeedback" class="sub">El momento de tu toque determina la precisión.</p>`;
  }
  if(craft.stage===3){
    return `<div class="eyebrow">ETAPA 4 · MÁQUINA DE COSER</div><h2>Uní las piezas</h2><p>Presioná el botón cuando el indicador esté en la zona verde. Vas a tener tres intentos para lograr una costura prolija.</p><div class="sewtrack"><i id="sewMarker"></i></div><div class="btnrow"><button class="btn primary" data-action="sewTap">🧵 Coser puntada</button></div><p id="sewFeedback" class="sub">Intentos: <b id="sewAttempts">0 / 3</b></p>`;
  }
  if(craft.stage===4){
    return `<div class="eyebrow">ETAPA 5 · TOQUES FINALES</div><h2>Decorá tu creación</h2><p>Podés añadir botones, lazos, encaje o brillos. La decoración influye en la satisfacción y en el valor final.</p><label class="label">Detalle final</label><select id="finishDecoration"><option value="none">Minimalista</option><option value="bow">Lazo</option><option value="lace">Encaje</option><option value="sparkle">Brillos</option></select><label class="checkline"><input type="checkbox" id="finishButtons"> Añadir botones (cuesta 1 unidad)</label><label class="checkline"><input type="checkbox" id="finishPocket"> Añadir bolsillos</label><div class="btnrow"><button class="btn primary" data-action="finishGarment">✨ Terminar prenda</button><button class="btn" data-action="prevStage">← Volver</button></div>`;
  }
  return `<div class="eyebrow">ETAPA 6</div><h2>Revisá tu creación</h2><p>La prenda está lista para una última inspección. Podés reparar defectos antes de entregarla.</p><div class="result" id="qualityResult">${qualityBreakdown(o)}</div><div class="btnrow"><button class="btn" data-action="repair">🪡 Reparar costuras</button><button class="btn" data-action="fitting">🪞 Probar en maniquí</button><button class="btn primary" data-action="deliver">Entregar y cobrar 🪙</button></div>`;
}

function qualityBreakdown(o){
  const q=finalQuality();
  return `Calidad total: <b>${q}/100</b><br>Corte: ${craft.cutQuality}/100<br>Costura: ${craft.sewQuality}/100<br>Material: ${fabric(design.fabric).quality}/100<br>Decoración: ${craft.decorQuality}/100<br>${o?`Objetivo de cliente: ${o.minQuality}/100`:"Modo libre: sin calificación comercial"}`;
}

function finalQuality(){
  const fabricQuality=fabric(design.fabric).quality;
  return Math.max(0,Math.min(100,Math.round(
    (craft.cutQuality*.28)+(craft.sewQuality*.36)+(fabricQuality*.2)+(craft.decorQuality*.16)
  )));
}

function enterStage(n){
  craft.stage=n;
  render();
}

function nextStage(){
  if(craft.stage===0){enterStage(1);return;}
  if(craft.stage===1){cutStart();return;}
}

function cutStart(){
  const g=garment(design.type);
  if(!game.freeMode && (game.inventory[design.fabric]||0)<g.material){
    toast("No tenés suficiente tela. Comprá más en la tienda.");changePage("shop");return;
  }
  if(!game.freeMode && (game.inventory.thread||0)<g.material*2){
    toast("Te falta hilo para confeccionar la prenda.");changePage("shop");return;
  }
  if(!game.freeMode){
    game.inventory[design.fabric]-=g.material;
    game.inventory.thread-=g.material*2;
    if(design.buttons){
      if(game.inventory.buttons<4){toast("Necesitás 4 botones. Compralos en la tienda.");game.inventory[design.fabric]+=g.material;game.inventory.thread+=g.material*2;changePage("shop");return;}
      game.inventory.buttons-=4;
    }
  }
  craft.cutTarget=35+Math.random()*30;
  craft.cutDone=false;
  craft.cutQuality=0;
  craft.sewQuality=0;
  craft.stage=2;
  render();
  runCutMeter();
}

function runCutMeter(){
  const marker=$("#cutMarker");
  if(!marker)return;
  const start=performance.now();
  const animate=now=>{
    if(craft.stage!==2||!$("#cutMarker"))return;
    const x=(Math.sin((now-start)/450)+1)*50;
    $("#cutMarker").style.width=x+"%";
    requestAnimationFrame(animate);
  };
  requestAnimationFrame(animate);
}

function cutTap(){
  if(craft.stage!==2||craft.cutDone)return;
  const marker=$("#cutMarker");
  const x=parseFloat(marker?.style.width)||50;
  const accuracy=Math.max(0,100-Math.abs(x-craft.cutTarget)*2.4);
  craft.cutQuality=Math.round(Math.min(100,accuracy+(upgrade("scissors")?12:0)));
  craft.cutQuality=Math.min(100,craft.cutQuality);
  if(craft.cutQuality<45&&!upgrade("table")){
    toast("El corte salió mal. Podés reparar el patrón.");
    if(!game.freeMode)game.inventory[design.fabric]=Math.max(0,game.inventory[design.fabric]-1);
  }
  craft.cutDone=true;
  $("#cutFeedback").innerHTML=`Precisión del corte: <b>${craft.cutQuality}/100</b>. ${craft.cutQuality>75?"¡Excelente!":craft.cutQuality>50?"Buen trabajo.":"Se desperdició algo de tela."}`;
  $("#cutFeedback").insertAdjacentHTML("afterend",`<div class="btnrow"><button class="btn primary" id="cutContinue">Continuar a costura →</button><button class="btn" id="cutRetry">Reintentar</button></div>`);
  $("#cutContinue").onclick=()=>enterStage(3);
  $("#cutRetry").onclick=()=>{
    craft.cutDone=false;craft.cutQuality=0;
    $("#cutFeedback").textContent="Volvé a intentarlo.";
    document.querySelector("#workStage .btnrow")?.remove();
  };
  notifySound(craft.cutQuality>70?750:280);
}

let sewAttempts=0;
function beginSew(){
  sewAttempts=0;
  craft.sewTarget=70;
  craft.sewDone=false;
  enterStage(3);
  runSewMeter();
}
function runSewMeter(){
  const start=performance.now();
  const animate=now=>{
    const el=$("#sewMarker");
    if(!el||craft.stage!==3||craft.sewDone)return;
    const x=(Math.sin((now-start)/300)+1)*50;
    el.style.width=x+"%";
    sewFrame=requestAnimationFrame(animate);
  };
  sewFrame=requestAnimationFrame(animate);
}
function sewTap(){
  if(craft.stage!==3||craft.sewDone)return;
  sewAttempts++;
  const x=parseFloat($("#sewMarker")?.style.width)||50;
  const acc=Math.max(0,100-Math.abs(x-72)*2.2);
  craft.sewQuality=Math.max(craft.sewQuality,Math.round(Math.min(100,acc+(upgrade("machine")?12:0)+(upgrade("helper")?5:0))));
  $("#sewAttempts").textContent=`${sewAttempts} / 3`;
  if(acc>=70||sewAttempts>=3){
    craft.sewDone=true;
    if(craft.sewQuality<50)toast("La costura tiene defectos. Podrás repararla.");
    $("#sewFeedback").innerHTML=`Calidad de costura: <b>${craft.sewQuality}/100</b>`;
    $("#sewFeedback").insertAdjacentHTML("afterend",`<div class="btnrow"><button class="btn primary" id="sewContinue">Continuar a decoración →</button><button class="btn" id="sewRetry">Repetir costura</button></div>`);
    $("#sewContinue").onclick=()=>enterStage(4);
    $("#sewRetry").onclick=()=>beginSew();
    notifySound(craft.sewQuality>70?700:250);
  }else{
    $("#sewFeedback").textContent=`Puntada ${sewAttempts}/3. Precisión ${Math.round(acc)}. ¡Intentá otra vez!`;
    notifySound(400);
  }
}

function finishGarment(){
  const deco=$("#finishDecoration")?.value||design.decoration;
  const buttons=$("#finishButtons")?.checked;
  const pockets=$("#finishPocket")?.checked;
  if(buttons&&!game.freeMode&&game.inventory.buttons<1){toast("No tenés botones suficientes.");return;}
  if(buttons&&!game.freeMode)game.inventory.buttons--;
  design.decoration=deco;
  design.buttons=design.buttons||buttons;
  design.pockets=design.pockets||pockets;
  craft.decorQuality=deco==="none"?72:deco==="bow"?86:deco==="lace"?90:94;
  if(upgrade("embroidery"))craft.decorQuality=Math.min(100,craft.decorQuality+10);
  craft.stage=5;
  render();
}

function repair(){
  const cost=30;
  if(!game.freeMode&&game.money<cost){toast("Necesitás 30 monedas para reparar.");return;}
  if(!game.freeMode)game.money-=cost;
  craft.cutQuality=Math.max(craft.cutQuality,65);
  craft.sewQuality=Math.max(craft.sewQuality,70);
  toast("Reparación terminada. ¡Mejor calidad!");
  render();updateHeader();saveQuiet();
}

function fitting(){
  showModal(`<div class="eyebrow">PRUEBA FINAL</div><h2>Así queda tu creación</h2>${previewHTML(design)}<p>La silueta, los colores y los detalles están listos para la revisión.</p><div class="btnrow"><button class="btn primary" id="fitOk">¡Perfecto!</button><button class="btn" id="fitEdit">Volver al diseño</button></div>`);
  $("#fitOk").onclick=()=>{closeModal();toast("¡Prueba completada!");};
  $("#fitEdit").onclick=()=>{closeModal();enterStage(0);};
}

function deliver(){
  if(craft.stage!==5)return;
  const o=activeOrder;
  if(!o||game.freeMode){
    const item={id:Date.now(),type:design.type,design:{...design},quality:finalQuality(),date:Date.now(),free:true};
    game.catalog.push(item);
    toast("¡Diseño guardado en tu colección!");
    craft.stage=0;activeOrder=null;
    changePage("collection");return;
  }
  const q=finalQuality();
  const r=o.req;
  let matches=0,total=6;
  if(design.type===r.type)matches++;
  if(design.color===r.color)matches++;
  if(design.length===r.length)matches++;
  if(design.sleeves===r.sleeves)matches++;
  if(design.print===r.print)matches++;
  if(design.decoration===r.decoration)matches++;
  const matchPercent=Math.round(matches/total*100);
  const cost=fabric(design.fabric).price*garment(design.type).material+
    garment(design.type).material*2*3+
    (design.buttons?12:0)+(design.decoration!=="none"?15:0);
  let paid=Math.round(o.price*(.45+matchPercent/200+q/500));
  if(q<o.minQuality)paid=Math.round(paid*.7);
  if(matchPercent<50)paid=Math.round(paid*.65);
  if(o.deadline==="Urgente")paid=Math.round(paid*1.12);
  paid=Math.min(paid,Math.max(o.price*1.5,paid));
  const profit=paid-cost;
  game.money+=paid;
  game.xp+=Math.max(20,Math.round(q*.5+matchPercent*.3));
  game.rep=Math.max(0,Math.min(100,game.rep+(q>=o.minQuality&&matchPercent>=65?2:-1)));
  game.history.push({client:o.client,face:o.face,type:design.type,paid,quality:q,matchPercent,profit,date:Date.now()});
  game.catalog.push({id:Date.now(),type:design.type,design:{...design},quality:q,client:o.client,paid});
  o.status="done";o.paid=paid;o.quality=q;o.matchPercent=matchPercent;
  closeModal();
  showModal(`<div class="eyebrow">ENCARGO FINALIZADO</div><h2>${q>=o.minQuality&&matchPercent>=65?"¡Tu clienta está encantada!":"¡Prenda entregada!"}</h2>
    <div class="clientrow"><div class="avatar">${o.face}</div><div><h3>${o.client}</h3><p>${q>=o.minQuality&&matchPercent>=65?"«¡Es exactamente lo que necesitaba!»":"«Gracias por el trabajo. Hay detalles que podemos mejorar para la próxima.»"}</p></div></div>
    ${previewHTML(design)}
    <div class="result" style="margin-top:12px">Coincidencia con el pedido: <b>${matchPercent}%</b><br>Calidad final: <b>${q}/100</b><br>Ingresos: <b>+${money(paid)} monedas</b><br>Costo estimado de materiales: <b>${money(cost)}</b><br>Resultado del encargo: <b>${profit>=0?"+":""}${money(profit)} monedas</b><br>Experiencia: <b>+${Math.max(20,Math.round(q*.5+matchPercent*.3))} XP</b></div>
    <div class="btnrow"><button class="btn primary" id="deliveryDone">¡Seguir creciendo!</button></div>`);
  $("#deliveryDone").onclick=()=>{
    closeModal();activeOrder=null;craft.stage=0;design={...game.design};ensureOrders();changePage("boutique");
  };
  updateHeader();saveQuiet();notifySound(850);
}
function renderShop(){
  const goods=[
    {id:"cotton",name:"Algodón",icon:"🧵",price:22,desc:"Tela versátil para prendas diarias."},
    {id:"satin",name:"Satén",icon:"✨",price:38,desc:"Acabado brillante y elegante."},
    {id:"linen",name:"Lino",icon:"🌿",price:29,desc:"Textura natural y ligera."},
    {id:"velvet",name:"Terciopelo",icon:"💜",price:48,desc:"Tela premium para diseños especiales."},
    {id:"denim",name:"Denim",icon:"👖",price:34,desc:"Resistente para prendas casuales."},
    {id:"lace",name:"Encaje",icon:"🌸",price:43,desc:"Ideal para detalles delicados."},
    {id:"thread",name:"Hilo",icon:"🧶",price:3,desc:"Necesario para unir las piezas."},
    {id:"buttons",name:"Botones",icon:"🔘",price:3,desc:"Pequeños detalles que hacen la diferencia."},
    {id:"zipper",name:"Cierres",icon:"🤍",price:8,desc:"Para camperas y pantalones."},
    {id:"ribbon",name:"Cintas",icon:"🎀",price:7,desc:"Un toque de color y elegancia."},
    {id:"embroidery",name:"Bordados",icon:"🪡",price:15,desc:"Detalles especiales para tus creaciones."}
  ];
  return `<div class="pagehead"><div><h1>Tienda de materiales</h1><p class="sub">Comprá con cuidado: el presupuesto de tu atelier importa.</p></div><div class="wallet">🪙 ${money(game.money)}</div></div>
    <div class="grid">${goods.map(g=>`<div class="card">
      <div style="font-size:38px;margin:6px 0 12px">${g.icon}</div><h3>${g.name}</h3><p>${g.desc}</p>
      <div class="orderline"><span>Inventario</span><b>${game.inventory[g.id]||0}</b></div>
      <div class="orderline"><span>Precio por unidad</span><b>🪙 ${g.price}</b></div>
      <div class="btnrow"><button class="btn primary" data-action="buy" data-id="${g.id}" data-price="${g.price}">Comprar 1</button><button class="btn" data-action="buy3" data-id="${g.id}" data-price="${g.price}">Comprar 3</button></div>
    </div>`).join("")}</div>`;
}

function renderUpgrades(){
  return `<div class="pagehead"><div><h1>Mejoras del atelier</h1><p class="sub">Invertí tus ganancias para trabajar con más precisión.</p></div><div class="wallet">🪙 ${money(game.money)}</div></div>
  <div class="grid">${UPGRADES.map(u=>`<div class="card">
    <div style="font-size:40px;margin-bottom:12px">${u.icon}</div><h3>${u.name}</h3><p>${u.desc}</p>
    <div class="orderline"><span>Inversión</span><b>🪙 ${money(u.cost)}</b></div>
    <div class="btnrow">${upgrade(u.id)?`<span class="tag">✓ Comprada</span>`:`<button class="btn primary" data-action="upgrade" data-id="${u.id}">Comprar mejora</button>`}</div>
  </div>`).join("")}</div>`;
}

function renderCollection(){
  const catalog=game.catalog.slice().reverse();
  return `<div class="pagehead"><div><h1>Mi colección</h1><p class="sub">Tus diseños guardados, listos para inspirar futuras creaciones.</p></div><button class="btn primary" data-action="freeDesign">＋ Nuevo diseño</button></div>
  ${catalog.length?`<div class="grid">${catalog.map(item=>`<div class="card">
    ${previewHTML(item.design)}
    <div class="materialrow" style="margin-top:14px"><b>${garment(item.type).name}</b><span class="tag">Calidad ${item.quality}</span></div>
    <p>${item.client?"Encargo de "+item.client:"Diseño libre"}${item.paid?" · "+money(item.paid)+" monedas":""}</p>
    <div class="btnrow"><button class="btn" data-action="reuse" data-id="${item.id}">Editar diseño</button><button class="btn" data-action="showDesign" data-id="${item.id}">Ver detalles</button></div>
  </div>`).join("")}</div>`:`<div class="card empty"><div style="font-size:48px">👗</div><h2>Tu colección empieza acá</h2><p>Creá tu primera prenda y guardala para verla en esta galería.</p><button class="btn primary" data-action="freeDesign">Crear mi primer diseño</button></div>`}
  <div class="card" style="margin-top:18px"><h3>📖 Libro de clientes</h3>${game.history.length?game.history.slice().reverse().slice(0,10).map(h=>`<div class="orderline"><span>${h.face} ${h.client}<br><small>${garment(h.type).name} · Coincidencia ${h.matchPercent}%</small></span><b>🪙 ${money(h.paid)}</b></div>`).join(""):`<p>Acá aparecerán los clientes a los que les hayas entregado prendas.</p>`}</div>`;
}

function render(){
  updateHeader();
  const pages={
    boutique:renderBoutique,
    orders:renderOrders,
    workshop:renderWorkshop,
    shop:renderShop,
    upgrades:renderUpgrades,
    collection:renderCollection
  };
  main.innerHTML=(pages[game.page]||renderBoutique)();
  if(game.page==="workshop")bindDesigner();
  if(game.page==="workshop"&&craft.stage===3&&!craft.sewDone)runSewMeter();
  if(game.tutorial&&!game.history.length&&!game.freeMode&&game.page==="boutique"){
    setTimeout(showTutorial,250);
  }
}

function showTutorial(){
  if(!game.tutorial||game.history.length||game.freeMode)return;
  showModal(`<div class="eyebrow">TU PRIMER DÍA</div><h2>¡Bienvenida a tu atelier!</h2><div style="font-size:45px">🧵✂️👗</div>
    <p>Tu aventura empieza con 500 monedas, algunas telas y una máquina de coser básica.</p>
    <p><b>Tu misión:</b> escuchar a una clienta, diseñar su prenda, cortar la tela, coserla y entregarla con la mejor calidad posible.</p>
    <div class="result">Consejo: leé los requisitos del pedido antes de diseñar. Cumplirlos mejora la satisfacción, la reputación y tus ganancias.</div>
    <div class="btnrow"><button class="btn primary" id="tutorialStart">¡Abrir mi atelier!</button><button class="btn" id="tutorialSkip">Ya sé cómo jugar</button></div>`);
  $("#tutorialStart").onclick=()=>{
    game.tutorial=false;closeModal();saveQuiet();
    const o=game.orders.find(x=>x.status==="new")||makeOrder();
    dialogue(o);
  };
  $("#tutorialSkip").onclick=()=>{
    game.tutorial=false;closeModal();saveQuiet();
  };
}

function rejectOrder(id){
  const o=game.orders.find(x=>x.id===Number(id));
  if(!o)return;
  showModal(`<h2>¿Rechazar este pedido?</h2><p>${o.client} tendrá que buscar otro atelier. Tu reputación podría verse afectada.</p><div class="btnrow"><button class="btn danger" id="confirmReject">Rechazar encargo</button><button class="btn" id="cancelReject">Volver</button></div>`);
  $("#confirmReject").onclick=()=>{
    o.status="rejected";
    game.rep=Math.max(0,game.rep-1);
    closeModal();render();saveQuiet();toast("Pedido rechazado.");
  };
  $("#cancelReject").onclick=closeModal;
}

function buy(id,price,quantity=1){
  price=Number(price);quantity=Number(quantity);
  if(!Number.isFinite(price)||!Number.isFinite(quantity)||quantity<1)return;
  const total=price*quantity;
  if(game.money<total){toast("No te alcanza. Hacé un encargo para ganar monedas.");return;}
  game.money-=total;
  game.inventory[id]=(game.inventory[id]||0)+quantity;
  notifySound(650);
  toast(`Compraste ${quantity} unidad${quantity>1?"es":""}.`);
  render();saveQuiet();
}

function buyUpgrade(id){
  const u=UPGRADES.find(x=>x.id===id);
  if(!u||upgrade(id))return;
  if(game.money<u.cost){toast("Necesitás más monedas para esta mejora.");return;}
  game.money-=u.cost;
  game.upgrades.push(id);
  notifySound(720);
  toast(`¡Mejora adquirida: ${u.name}!`);
  render();saveQuiet();
}

function randomizeDesign(){
  design={
    ...design,
    type:random(GARMENTS.filter(g=>g.unlock<=level())).id,
    color:random(COLORS).hex,
    secondary:random(COLORS).hex,
    fabric:random(FABRICS.filter(f=>(game.inventory[f.id]||0)>0)).id,
    print:random(["plain","dots","stripes","floral","plaid"]),
    length:random(["short","long"]),
    sleeves:random(["short","long","none"]),
    neck:random(["round","v","square"]),
    decoration:random(["none","bow","lace","sparkle"]),
    pockets:Math.random()>.5,
    buttons:Math.random()>.5
  };
  render();saveQuiet();toast("¡Nueva inspiración creada!");
}

function newOrder(){
  const active=game.orders.filter(o=>!["done","rejected"].includes(o.status));
  if(active.length>=4){toast("Tenés cuatro encargos activos. Terminá alguno primero.");return;}
  const o=makeOrder();
  render();
  dialogue(o);
}

function enterFreeMode(){
  game.freeMode=true;
  activeOrder=null;
  design={...game.design};
  craft={stage:0,cutQuality:0,sewQuality:0,decorQuality:80,cutTarget:0,sewTarget:0,cutDone:false,sewDone:false};
  changePage("workshop");
  toast("Modo libre activado. No gastás materiales ni perdés monedas.");
}

$("#freeMode").onclick=()=>{
  showModal(`<div class="eyebrow">ESTUDIO CREATIVO</div><h2>Diseño libre</h2><p>Probá combinaciones, colores, telas y decoraciones sin la presión de un pedido. Los diseños terminados se guardarán en tu colección, sin consumir inventario.</p><div class="btnrow"><button class="btn primary" id="freeStart">Empezar a diseñar</button><button class="btn" id="freeCancel">Cancelar</button></div>`);
  $("#freeStart").onclick=()=>{closeModal();enterFreeMode();};
  $("#freeCancel").onclick=closeModal;
};

main.addEventListener("click",e=>{
  const btn=e.target.closest("[data-action]");
  const pageBtn=e.target.closest("[data-page]");
  if(pageBtn){changePage(pageBtn.dataset.page);return;}
  if(!btn)return;
  const a=btn.dataset.action,id=btn.dataset.id;
  if(a==="newOrder")newOrder();
  if(a==="dialogue"){
    const o=game.orders.find(x=>x.id===Number(id));
    if(o)dialogue(o);
  }
  if(a==="reject")rejectOrder(id);
  if(a==="resume"){
    const o=game.orders.find(x=>x.id===Number(id));
    if(o){activeOrder=o;game.freeMode=false;changePage("workshop");}
  }
  if(a==="showRequirements"){
    const o=activeOrder;
    if(o)showModal(`<div class="eyebrow">REQUISITOS DEL PEDIDO</div><h2>${o.client}</h2>${requirementsHTML(o)}<button class="btn primary" id="reqClose">Volver al taller</button>`);
    $("#reqClose").onclick=closeModal;
  }
  if(a==="nextStage")nextStage();
  if(a==="prevStage")enterStage(Math.max(0,craft.stage-1));
  if(a==="cutStart")cutStart();
  if(a==="cutTap")cutTap();
  if(a==="sewTap")sewTap();
  if(a==="finishGarment")finishGarment();
  if(a==="deliver")deliver();
  if(a==="repair")repair();
  if(a==="fitting")fitting();
  if(a==="randomDesign")randomizeDesign();
  if(a==="saveDesign"){game.design={...design};saveQuiet();toast("Diseño guardado.");}
  if(a==="buy")buy(id,btn.dataset.price,1);
  if(a==="buy3")buy(id,btn.dataset.price,3);
  if(a==="upgrade")buyUpgrade(id);
  if(a==="freeDesign")enterFreeMode();
  if(a==="reuse"){
    const item=game.catalog.find(x=>x.id===Number(id));
    if(item){design={...item.design};game.freeMode=true;activeOrder=null;craft.stage=0;changePage("workshop");}
  }
  if(a==="showDesign"){
    const item=game.catalog.find(x=>x.id===Number(id));
    if(item)showModal(`<h2>${garment(item.type).name}</h2>${previewHTML(item.design)}<div class="result">Calidad: ${item.quality}/100<br>Material: ${fabric(item.design.fabric).name}<br>Color principal: ${item.design.color}<br>Estampado: ${item.design.print}</div><button class="btn primary" id="showDesignClose">Cerrar</button>`);
    $("#showDesignClose").onclick=closeModal;
  }
});

function setupNewGame(){
  if(game.orders.length===0){
    const o=makeOrder();
    o.status="new";
  }
  if(!game.daily||typeof game.daily!=="object")game.daily={day:"",done:0};
  const today=new Date().toLocaleDateString("en-CA");
  if(game.daily.day!==today){
    game.daily={day:today,done:0};
  }
  updateHeader();
  render();
}

setupNewGame();
// Integración del diseñador en la primera etapa del taller.
const originalRenderStage = renderStage;

renderStage = function(o) {
  if (craft.stage === 0) {
    return `<div class="eyebrow">ETAPA 1 · TU ESTUDIO</div>
      ${renderDesigner()}
      <div class="btnrow">
        <button class="btn primary" data-action="nextStage">Confirmar diseño y preparar patrón →</button>
      </div>`;
  }
  return originalRenderStage(o);
};

// Evita que un nuevo encargo conserve el modo libre.
const originalNewOrder = newOrder;
newOrder = function() {
  game.freeMode = false;
  originalNewOrder();
};

// Objetivos diarios locales.
function dailyHTML() {
  const objectives = [
    {title:"Creatividad diaria",desc:"Guardá un diseño en tu colección.",done:game.catalog.length>0},
    {title:"Atelier activo",desc:"Completá tu primer encargo.",done:game.history.length>0},
    {title:"Administradora",desc:"Comprá materiales en la tienda.",done:game.daily.bought===true}
  ];

  return `<div class="pagehead" style="margin-top:24px">
    <div><h2>🌷 Objetivos del día</h2>
    <p class="sub">Pequeños logros para hacer crecer tu marca.</p></div>
  </div>
  <div class="grid">${objectives.map(o=>`<div class="card">
    <div class="materialrow"><b>${o.title}</b><span class="tag">${o.done?"✓ COMPLETADO":"PENDIENTE"}</span></div>
    <p>${o.desc}</p>
    ${o.done?`<span class="tag">¡Buen trabajo!</span>`:""}
  </div>`).join("")}</div>`;
}

const originalBoutique = renderBoutique;
renderBoutique = function() {
  return originalBoutique() + dailyHTML();
};

// Acciones extra para administrar el negocio.
$("#brandName").closest("button").addEventListener("contextmenu", e => {
  e.preventDefault();
  renameBoutique();
});

function renameBoutique() {
  showModal(`<div class="eyebrow">IDENTIDAD DE MARCA</div>
    <h2>El nombre de tu atelier</h2>
    <label class="label">Nombre de la boutique</label>
    <input id="newBrandName" type="text" maxlength="28" value="${game.boutique.replace(/"/g,"&quot;")}">
    <div class="btnrow"><button class="btn primary" id="saveBrand">Guardar nombre</button></div>`);
  $("#saveBrand").onclick=()=>{
    const value=$("#newBrandName").value.trim();
    if(!value){toast("Elegí un nombre para tu boutique.");return;}
    game.boutique=value;
    closeModal();
    render();
    saveQuiet();
    toast("¡Nueva identidad de marca!");
  };
}

// Botón de administración de la boutique.
const brandTools = document.createElement("button");
brandTools.className = "btn";
brandTools.textContent = "⚙️ Mi marca";
brandTools.onclick=()=>{
  showModal(`<div class="eyebrow">ADMINISTRACIÓN</div>
    <h2>Mi atelier</h2>
    <p>Personalizá el nombre de tu marca o reiniciá tu partida.</p>
    <div class="btnrow"><button class="btn primary" id="renameBtn">✏️ Cambiar nombre</button>
    <button class="btn danger" id="resetBtn">Reiniciar partida</button></div>`);
  $("#renameBtn").onclick=renameBoutique;
  $("#resetBtn").onclick=()=>{
    showModal(`<h2>¿Empezar de nuevo?</h2>
      <p>Se borrarán el dinero, los pedidos, las mejoras y la colección guardada en este navegador.</p>
      <div class="btnrow"><button class="btn danger" id="confirmReset">Sí, reiniciar</button>
      <button class="btn" id="cancelReset">Cancelar</button></div>`);
    $("#confirmReset").onclick=()=>{
      try{localStorage.removeItem("fashionStudioSave");}catch(e){}
      location.reload();
    };
    $("#cancelReset").onclick=closeModal;
  };
};
document.querySelector("footer").appendChild(brandTools);

// Registra compras para los objetivos diarios.
const originalBuy = buy;
buy = function(id,price,quantity=1) {
  const before=game.money;
  originalBuy(id,price,quantity);
  if(game.money<before) {
    game.daily.bought=true;
    saveQuiet();
  }
};

// Actualiza el taller con el diseñador integrado.
render();