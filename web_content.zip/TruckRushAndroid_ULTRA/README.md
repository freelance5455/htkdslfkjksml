# Truck Rush: Alpine Highway Racer — Ultra Edition

A mobile-friendly Canvas arcade truck racer set on Swiss Alpine roads, with European-style AI freight trucks, cars, coaches, coins, touch controls, keyboard controls, score, and saved best distance.

## Build an Android APK
1. Open this folder in Android Studio on a computer.
2. Let Gradle sync.
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

This source project has not been compiled or device-tested in this environment. It is an arcade 2D Canvas game with simulated perspective, not a true 3D Unity/Unreal racing simulator.
