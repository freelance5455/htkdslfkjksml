require("dotenv").config();

const express = require("express");
const helmet = require("helmet");
const crypto = require("crypto");
const path = require("path");
const { Pool } = require("pg");

const app = express();

// Configure Helmet while allowing local scripts/styles/fonts for Web Dashboard
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
        fontSrc: ["'self'", "https://fonts.gstatic.com"],
        imgSrc: ["'self'", "data:"],
        connectSrc: ["'self'"]
      }
    }
  })
);

app.use(express.json({ limit: "256kb" }));
app.use(express.static(path.join(__dirname, "..", "public")));

const PORT = Number(process.env.PORT || 10000);
const DATABASE_URL = process.env.DATABASE_URL;
const ADMIN_TOKEN = process.env.ADMIN_TOKEN;

if (!DATABASE_URL) {
  console.error("DATABASE_URL is required. Configure a persistent PostgreSQL database.");
  process.exit(1);
}
if (!ADMIN_TOKEN || ADMIN_TOKEN.length < 32) {
  console.error("ADMIN_TOKEN is required and must be at least 32 characters.");
  process.exit(1);
}

const pool = new Pool({
  connectionString: DATABASE_URL,
  ssl: process.env.PGSSL === "true" ? { rejectUnauthorized: true } : undefined
});

function adminOnly(req, res, next) {
  const supplied = req.get("x-admin-token") || "";
  const a = Buffer.from(supplied);
  const b = Buffer.from(ADMIN_TOKEN);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return res.status(401).json({ error: "unauthorized" });
  }
  next();
}

function makeUid(length = 16) {
  const validLen = Math.min(16, Math.max(13, Number(length) || 16));
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";
  let out = "";
  while (out.length < validLen) {
    const bytes = crypto.randomBytes(validLen);
    for (const byte of bytes) {
      if (byte < 248) out += alphabet[byte % alphabet.length];
      if (out.length === validLen) break;
    }
  }
  return out;
}

function sha256(value) {
  return crypto.createHash("sha256").update(value).digest("hex");
}

async function addLog(action, target, detail, status = "SUCCESS") {
  try {
    await pool.query(
      "INSERT INTO server_logs (action, target, detail, status) VALUES ($1, $2, $3, $4)",
      [action, target, detail, status]
    );
  } catch (err) {
    console.error("Log write failed:", err.message);
  }
}

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS projects (
      id BIGSERIAL PRIMARY KEY,
      uid VARCHAR(16) NOT NULL UNIQUE,
      uuid UUID NOT NULL UNIQUE,
      name VARCHAR(120) NOT NULL,
      category VARCHAR(40) NOT NULL,
      version VARCHAR(40) NOT NULL,
      status VARCHAR(20) NOT NULL DEFAULT 'Active',
      api_key_hash CHAR(64) NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  // Ensure status column exists if upgrading from older starter schema
  await pool.query(`
    ALTER TABLE projects ADD COLUMN IF NOT EXISTS status VARCHAR(20) NOT NULL DEFAULT 'Active'
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS server_logs (
      id BIGSERIAL PRIMARY KEY,
      action VARCHAR(60) NOT NULL,
      target VARCHAR(120),
      detail TEXT,
      status VARCHAR(20) NOT NULL DEFAULT 'SUCCESS',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
}

// Health check endpoint
app.get("/api/health", async (_req, res) => {
  try {
    await pool.query("SELECT 1");
    res.json({
      status: "ok",
      service: "UNIT SERVER",
      system: "WO9N SYSTEM",
      database: "connected",
      timestamp: new Date().toISOString()
    });
  } catch {
    res.status(503).json({ status: "error", database: "unavailable" });
  }
});

// Verify admin token session from Dashboard
app.post("/api/admin/auth", adminOnly, async (_req, res) => {
  await addLog("ADMIN_LOGIN", "Dashboard", "Admin authenticated via web console", "SUCCESS");
  res.json({ authenticated: true });
});

// Dashboard overview stats & project list
app.get("/api/projects", adminOnly, async (_req, res) => {
  try {
    const result = await pool.query(
      `SELECT id, uid, uuid, name, category, version, status, created_at
       FROM projects ORDER BY created_at DESC`
    );
    res.json({ projects: result.rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "server_error" });
  }
});

// Server Logs
app.get("/api/logs", adminOnly, async (_req, res) => {
  try {
    const result = await pool.query(
      `SELECT id, action, target, detail, status, created_at
       FROM server_logs ORDER BY created_at DESC LIMIT 100`
    );
    res.json({ logs: result.rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "server_error" });
  }
});

// Generate globally unique UID & UUID preview (checks DB collision before returning)
app.post("/api/identifiers/generate", adminOnly, async (req, res) => {
  const length = Number(req.body?.uid_length || 16);
  for (let attempt = 0; attempt < 8; attempt++) {
    const uid = makeUid(length);
    const uuid = crypto.randomUUID();
    const exists = await pool.query(
      "SELECT 1 FROM projects WHERE uid = $1 OR uuid = $2",
      [uid, uuid]
    );
    if (!exists.rowCount) {
      await addLog("GENERATE_ID", uid, `Generated unique UID (${uid.length} chars) & UUID`, "SUCCESS");
      return res.json({ uid, uuid, status: "Available" });
    }
  }
  return res.status(503).json({ error: "collision_retry_exceeded" });
});

// Check UID / UUID collision in database
app.get("/api/identifiers/check", adminOnly, async (req, res) => {
  const { uid, uuid } = req.query;
  const result = await pool.query(
    "SELECT uid, uuid, name, status FROM projects WHERE uid = $1 OR uuid::text = $2",
    [uid || "", uuid || ""]
  );
  res.json({
    exists: result.rowCount > 0,
    record: result.rows[0] || null
  });
});

// Register a new project (with optional pre-generated UID/UUID or auto-generated)
app.post("/api/projects", adminOnly, async (req, res) => {
  const { name, category, version, custom_uid, custom_uuid, uid_length } = req.body || {};
  if (typeof name !== "string" || !name.trim() || name.trim().length > 120) {
    return res.status(400).json({ error: "name must be 1-120 characters" });
  }
  const allowed = ["FOLDER_STORE", "APPLICATION_STORE", "MOD_APPLICATION_STORE", "WO9N_APP", "WO9N_WEB"];
  if (!allowed.includes(category)) {
    return res.status(400).json({ error: "invalid category" });
  }
  if (typeof version !== "string" || !version.trim() || version.trim().length > 40) {
    return res.status(400).json({ error: "version must be 1-40 characters" });
  }

  for (let attempt = 0; attempt < 8; attempt++) {
    const uid = attempt === 0 && custom_uid && /^[A-Za-z0-9]{13,16}$/.test(custom_uid)
      ? custom_uid
      : makeUid(uid_length || 16);
    const uuid = attempt === 0 && custom_uuid && /^[0-9a-fA-F-]{36}$/.test(custom_uuid)
      ? custom_uuid
      : crypto.randomUUID();
    const apiKey = "unit_" + crypto.randomBytes(32).toString("base64url");

    try {
      const result = await pool.query(
        `INSERT INTO projects (uid, uuid, name, category, version, status, api_key_hash)
         VALUES ($1, $2, $3, $4, $5, 'Active', $6)
         RETURNING id, uid, uuid, name, category, version, status, created_at`,
        [uid, uuid, name.trim(), category, version.trim(), sha256(apiKey)]
      );
      await addLog("PROJECT_REGISTER", uid, `Registered project "${name.trim()}" (${category})`, "SUCCESS");
      return res.status(201).json({
        project: result.rows[0],
        api_key: apiKey,
        warning: "Copy the API key now. It is not stored in readable form and cannot be shown again."
      });
    } catch (err) {
      if (err.code === "23505") continue;
      console.error("Project creation failed:", err.message);
      return res.status(500).json({ error: "server_error" });
    }
  }
  return res.status(503).json({ error: "could_not_allocate_unique_identifiers" });
});

// Toggle project status (Active / Inactive / Registered) or rotate API Key
app.patch("/api/projects/:uid/status", adminOnly, async (req, res) => {
  const { uid } = req.params;
  const { status } = req.body || {};
  if (!["Active", "Inactive", "Registered"].includes(status)) {
    return res.status(400).json({ error: "invalid status" });
  }
  const result = await pool.query(
    "UPDATE projects SET status = $1 WHERE uid = $2 RETURNING uid, name, status",
    [status, uid]
  );
  if (!result.rowCount) return res.status(404).json({ error: "not_found" });
  await addLog("STATUS_UPDATE", uid, `Updated status to ${status}`, "SUCCESS");
  res.json({ project: result.rows[0] });
});

app.post("/api/projects/:uid/rotate-key", adminOnly, async (req, res) => {
  const { uid } = req.params;
  const newKey = "unit_" + crypto.randomBytes(32).toString("base64url");
  const result = await pool.query(
    "UPDATE projects SET api_key_hash = $1 WHERE uid = $2 RETURNING uid, uuid, name, version, status",
    [sha256(newKey), uid]
  );
  if (!result.rowCount) return res.status(404).json({ error: "not_found" });
  await addLog("API_KEY_ROTATE", uid, `Rotated API key for ${result.rows[0].name}`, "WARNING");
  res.json({ project: result.rows[0], api_key: newKey });
});

app.delete("/api/projects/:uid", adminOnly, async (req, res) => {
  const { uid } = req.params;
  const result = await pool.query("DELETE FROM projects WHERE uid = $1 RETURNING uid, name", [uid]);
  if (!result.rowCount) return res.status(404).json({ error: "not_found" });
  await addLog("PROJECT_DELETE", uid, `Deleted project ${result.rows[0].name}`, "WARNING");
  res.json({ deleted: true });
});

// Public / Client verification endpoint for Wo9n_app and Wo9n_web
app.post("/api/projects/verify", async (req, res) => {
  const { uid, api_key } = req.body || {};
  if (typeof uid !== "string" || typeof api_key !== "string") {
    return res.status(400).json({ error: "uid and api_key are required" });
  }
  const result = await pool.query(
    "SELECT uid, uuid, name, category, version, status, api_key_hash FROM projects WHERE uid = $1",
    [uid]
  );
  if (!result.rowCount || sha256(api_key) !== result.rows[0].api_key_hash) {
    await addLog("VERIFY_FAIL", uid, "Invalid UID or API key verification attempt", "ERROR");
    return res.status(401).json({ valid: false, error: "invalid_credentials" });
  }
  const proj = result.rows[0];
  if (proj.status === "Inactive") {
    await addLog("VERIFY_BLOCKED", uid, "Inactive project attempted verification", "WARNING");
    return res.status(403).json({ valid: false, status: proj.status, error: "project_inactive" });
  }
  await addLog("VERIFY_OK", uid, `Verified ${proj.name} (${proj.version})`, "SUCCESS");
  return res.json({
    valid: true,
    project: {
      uid: proj.uid,
      uuid: proj.uuid,
      name: proj.name,
      category: proj.category,
      version: proj.version,
      status: proj.status
    }
  });
});

// SPA fallback to index.html
app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "..", "public", "index.html"));
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: "internal_server_error" });
});

initDb()
  .then(() => {
    app.listen(PORT, "0.0.0.0", () => {
      console.log(`UNIT SERVER listening on port ${PORT}`);
    });
  })
  .catch((err) => {
    console.error("Database initialization failed:", err);
    process.exit(1);
  });
