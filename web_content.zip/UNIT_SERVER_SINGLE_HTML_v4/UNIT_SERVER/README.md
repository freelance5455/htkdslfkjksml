# UNIT SERVER — Full Stack (Backend + Web Console UI)

โปรเจกต์ **UNIT SERVER** สำหรับระบบ **WO9N SYSTEM** พร้อมหน้าจอจัดการเว็บแอปพลิเคชัน (`HTML`, `CSS`, `JavaScript`) ที่เชื่อมต่อกับ `Node.js + Express` และ `PostgreSQL` บน Render

## โครงสร้างไฟล์ในโปรเจกต์
```text
UNIT_SERVER/
├── public/
│   ├── index.html       # หน้าหลักของระบบ (Dashboard, UID/UUID, API, Connection Manager, Logs)
│   ├── css/
│   │   └── style.css    # สไตล์ Dark Theme รองรับทั้งหน้าจอ Desktop และ Mobile (WebView / APK)
│   └── js/
│       └── app.js       # ระบบจัดการ State, เรียก API Render, สร้างโค้ด 8 ภาษา และ Demo Mode
├── src/
│   └── server.js        # Backend API + Static Web Server สำหรับ Render
├── .env.example
├── package.json
└── render.yaml
```

## วิธีรันและ Deploy บน Render
1. อัปโหลดไฟล์ทั้งหมดขึ้น GitHub Repository ของคุณ
2. สร้าง Web Service บน **Render** และตั้งค่า Environment Variables:
   - `DATABASE_URL`: ลิงก์ PostgreSQL Database
   - `ADMIN_TOKEN`: รหัสลับผู้ดูแลระบบ (ความยาวอย่างน้อย 32 ตัวอักษร)
   - `PGSSL`: `true`
3. เมื่อ Deploy เสร็จ สามารถเปิด URL ของ Render เพื่อใช้งานหน้า **UNIT SERVER Web Console** ได้ทันที
