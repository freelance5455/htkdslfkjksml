ИИ ДОГОНЯЛКИ — Android-проект

Важно: это исходный проект Android Studio, а не готовый APK.
В текущей среде нет Android SDK/Gradle, поэтому APK здесь не удалось собрать.

Как получить APK:
1. Откройте Android Studio на компьютере.
2. Выберите Open и укажите папку II_Dogonyalki_Android.
3. Дождитесь загрузки Gradle и установки нужных компонентов SDK.
4. Выберите Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK обычно появится в app/build/outputs/apk/debug/app-debug.apk.

Название приложения: ИИ Догонялки
Package ID: com.ii.dogonyalki
Игра уже вложена в app/src/main/assets/index.html.
