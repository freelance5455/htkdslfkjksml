/* ==================================================
   STUDENTS PAGE
   إدارة الصفوف
================================================== */

"use strict";


/* ==================================================
   STORAGE
================================================== */

const CLASSES_STORAGE_KEY = "mueen_classes";


/* ==================================================
   ELEMENTS
================================================== */

const classesList =
    document.getElementById("classesList");

const emptyState =
    document.getElementById("emptyState");

const classesCount =
    document.getElementById("classesCount");

const addClassButton =
    document.getElementById("addClassButton");

const emptyAddClassButton =
    document.getElementById("emptyAddClassButton");

const classModal =
    document.getElementById("classModal");

const closeModalButton =
    document.getElementById("closeModalButton");

const cancelModalButton =
    document.getElementById("cancelModalButton");

const saveClassButton =
    document.getElementById("saveClassButton");

const stageSelect =
    document.getElementById("stageSelect");

const gradeSelect =
    document.getElementById("gradeSelect");

const classNumberInput =
    document.getElementById("classNumber");

const previewNumber =
    document.getElementById("previewNumber");

const previewName =
    document.getElementById("previewName");

const backButton =
    document.getElementById("backButton");


/* ==================================================
   GRADES
================================================== */

const grades = {

    "رياض الأطفال": [
        "المستوى الأول",
        "المستوى الثاني",
        "المستوى الثالث"
    ],

    "المرحلة الابتدائية": [
        "الصف الأول الابتدائي",
        "الصف الثاني الابتدائي",
        "الصف الثالث الابتدائي",
        "الصف الرابع الابتدائي",
        "الصف الخامس الابتدائي",
        "الصف السادس الابتدائي"
    ],

    "المرحلة الإعدادية": [
        "الصف الأول الإعدادي",
        "الصف الثاني الإعدادي",
        "الصف الثالث الإعدادي"
    ],

    "المرحلة الثانوية": [
        "الصف الأول الثانوي",
        "الصف الثاني الثانوي",
        "الصف الثالث الثانوي"
    ]

};


/* ==================================================
   LOAD CLASSES
================================================== */

function getClasses() {

    try {

        const saved =
            localStorage.getItem(CLASSES_STORAGE_KEY);

        if (!saved) {
            return [];
        }

        const parsed =
            JSON.parse(saved);

        if (!Array.isArray(parsed)) {
            return [];
        }

        /*
           تحديث studentsCount تلقائيًا من
           قائمة الطلاب الفعلية عند القراءة.
        */

        let changed = false;

        parsed.forEach(function(item) {

            if (!item || typeof item !== "object") {
                return;
            }

            const realCount =
                Array.isArray(item.students)
                    ? item.students.length
                    : Number(item.studentsCount) || 0;

            if (
                Number(item.studentsCount) !==
                realCount
            ) {

                item.studentsCount =
                    realCount;

                changed = true;
            }

        });


        if (changed) {

            localStorage.setItem(
                CLASSES_STORAGE_KEY,
                JSON.stringify(parsed)
            );

        }


        return parsed;

    } catch (error) {

        console.error(
            "خطأ في قراءة الصفوف:",
            error
        );

        return [];
    }
}


/* ==================================================
   SAVE CLASSES
================================================== */

function saveClasses(classes) {

    localStorage.setItem(
        CLASSES_STORAGE_KEY,
        JSON.stringify(classes)
    );

}


/* ==================================================
   GET STUDENT COUNT
================================================== */

function getStudentCount(classData) {

    /*
       المصدر الأساسي هو students نفسها.
       هذا يضمن ظهور العدد الحقيقي حتى لو
       كانت studentsCount القديمة = 0.
    */

    if (
        classData &&
        Array.isArray(classData.students)
    ) {

        return classData.students.length;

    }


    return Number(
        classData?.studentsCount
    ) || 0;

}


/* ==================================================
   RENDER
================================================== */

function renderClasses() {

    const classes = getClasses();

    classesList.innerHTML = "";

    classesCount.textContent =
        classes.length;


    if (classes.length === 0) {

        emptyState.style.display =
            "flex";

        return;
    }


    emptyState.style.display =
        "none";


    classes.forEach(function(classData) {

        const card =
            createClassCard(classData);

        classesList.appendChild(card);

    });

}


/* ==================================================
   CREATE CARD
================================================== */

function createClassCard(classData) {

    const card =
        document.createElement("article");

    card.className =
        "class-card";

    card.dataset.id =
        classData.id;


    const studentCount =
        getStudentCount(classData);


    card.innerHTML = `

        <div class="class-visual">

            <span>
                ${escapeHTML(classData.code)}
            </span>

        </div>


        <div class="class-info">

            <span class="class-stage">
                ${escapeHTML(classData.stage)}
            </span>

            <h2 class="class-name">
                ${escapeHTML(classData.grade)}
            </h2>

            <span class="class-section">
                الفصل ${escapeHTML(classData.section)}
            </span>

            <span class="class-student-count">

                <svg viewBox="0 0 24 24">

                    <circle
                        cx="9"
                        cy="8"
                        r="3"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="1.7">
                    </circle>

                    <path
                        d="M3.8 19c.5-3.2 2.2-5 5.2-5s4.7 1.8 5.2 5"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="1.7"
                        stroke-linecap="round">
                    </path>

                </svg>

                ${studentCount} طالب

            </span>

        </div>


        <div class="class-actions">

            <button
                class="class-open-arrow"
                type="button"
                aria-label="فتح الصف">

                ‹

            </button>

            <button
                class="class-edit-button"
                type="button"
                aria-label="تعديل الصف">

                <svg viewBox="0 0 24 24">

                    <path
                        d="M4 20h4L19 9a2.1 2.1 0 0 0-3-3L5 17v3Z"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="1.7"
                        stroke-linejoin="round">
                    </path>

                </svg>

            </button>

            <button
                class="class-delete-button"
                type="button"
                aria-label="حذف الصف">

                <svg viewBox="0 0 24 24">

                    <path
                        d="M5 7h14M10 11v6M14 11v6M9 7l1-2h4l1 2M7 7l1 14h8l1-14"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="1.6"
                        stroke-linecap="round"
                        stroke-linejoin="round">
                    </path>

                </svg>

            </button>

        </div>
    `;


    /* فتح الصف */

    card.addEventListener(
        "click",
        function(event) {

            if (
                event.target.closest(
                    ".class-delete-button"
                )
            ) {
                return;
            }

            if (
                event.target.closest(
                    ".class-edit-button"
                )
            ) {
                return;
            }

            openClass(classData);

        }
    );


    /* تعديل */

    const editButton =
        card.querySelector(
            ".class-edit-button"
        );

    editButton.addEventListener(
        "click",
        function(event) {

            event.stopPropagation();

            editClass(classData);

        }
    );


    /* حذف */

    const deleteButton =
        card.querySelector(
            ".class-delete-button"
        );

    deleteButton.addEventListener(
        "click",
        function(event) {

            event.stopPropagation();

            deleteClass(classData.id);

        }
    );


    return card;
}


/* ==================================================
   OPEN CLASS
================================================== */

function openClass(classData) {

    /*
       نحصل على أحدث نسخة من الصف قبل فتحه،
       حتى لا نرسل بيانات قديمة للصف.
    */

    const classes =
        getClasses();

    const latestClass =
        classes.find(function(item) {

            return String(item.id) ===
                String(classData.id);

        }) || classData;


    /*
       مزامنة عدد الطلاب مع القائمة الفعلية.
    */

    latestClass.studentsCount =
        getStudentCount(latestClass);


    localStorage.setItem(
        "mueen_selected_class",
        JSON.stringify(latestClass)
    );


    /*
       حفظ الصف الحالي حتى تستطيع الصفحات
       الأخرى مثل الحضور استخدامه.
    */

    localStorage.setItem(
        "mueen_current_class",
        String(
            latestClass.code ??
            latestClass.id
        )
    );


    const params =
        new URLSearchParams({

            classId:
                String(latestClass.id)

        });


    /*
       الانتقال إلى صفحة الطلاب الفرعية
       باستخدام href حتى يكون الرجوع منها
       إلى صفحة إدارة الصفوف طبيعيًا.
    */

    window.location.href =
        "class-students.html?" +
        params.toString();

}


/* ==================================================
   STAGE CHANGE
================================================== */

stageSelect.addEventListener(
    "change",
    function() {

        const stage =
            stageSelect.value;

        gradeSelect.innerHTML = `
            <option value="">
                اختر الصف
            </option>
        `;


        if (!stage) {

            gradeSelect.disabled =
                true;

            updatePreview();

            return;
        }


        grades[stage].forEach(
            function(grade) {

                const option =
                    document.createElement("option");

                option.value =
                    grade;

                option.textContent =
                    grade;

                gradeSelect.appendChild(
                    option
                );

            }
        );


        gradeSelect.disabled =
            false;

        updatePreview();

    }
);


/* ==================================================
   PREVIEW
================================================== */

gradeSelect.addEventListener(
    "change",
    updatePreview
);


classNumberInput.addEventListener(
    "input",
    function() {

        let value =
            classNumberInput.value;

        value =
            value.replace(/\D/g, "");

        if (value) {

            let number =
                Number(value);

            if (number < 1) {
                number = 1;
            }

            if (number > 10) {
                number = 10;
            }

            classNumberInput.value =
                number;
        }

        updatePreview();

    }
);


function updatePreview() {

    const grade =
        gradeSelect.value;

    const section =
        classNumberInput.value;


    let gradeNumber = "";


    if (grade) {

        const match =
            grade.match(
                /(الأول|الثاني|الثالث|الرابع|الخامس|السادس)/
            );

        if (match) {

            const map = {

                "الأول": "1",
                "الثاني": "2",
                "الثالث": "3",
                "الرابع": "4",
                "الخامس": "5",
                "السادس": "6"

            };

            gradeNumber =
                map[match[1]] || "";

        }

    }


    if (
        gradeNumber &&
        section
    ) {

        previewNumber.textContent =
            `${gradeNumber}/${section}`;

    } else {

        previewNumber.textContent =
            "—/—";
    }


    if (
        grade &&
        section
    ) {

        previewName.textContent =
            `${grade} — الفصل ${section}`;

    } else if (grade) {

        previewName.textContent =
            `${grade} — اختر الفصل`;

    } else {

        previewName.textContent =
            "اختر الصف والفصل";
    }

}


/* ==================================================
   OPEN MODAL
================================================== */

function openModal() {

    /*
       مهم:
       عند إضافة صف جديد لا نريد بقاء
       معرف الصف الذي كان يتم تعديله.
    */

    delete saveClassButton.dataset.editingId;


    classModal.hidden =
        false;

    document.body.style.overflow =
        "hidden";

    resetModal();

}


/* ==================================================
   CLOSE MODAL
================================================== */

function closeModal() {

    classModal.hidden =
        true;

    document.body.style.overflow =
        "";

    delete saveClassButton.dataset.editingId;

    resetModal();

}


/* ==================================================
   RESET MODAL
================================================== */

function resetModal() {

    stageSelect.value =
        "";

    gradeSelect.innerHTML = `
        <option value="">
            اختر الصف
        </option>
    `;

    gradeSelect.disabled =
        true;

    classNumberInput.value =
        "";

    updatePreview();

}


/* ==================================================
   ADD BUTTONS
================================================== */

addClassButton.addEventListener(
    "click",
    openModal
);


emptyAddClassButton.addEventListener(
    "click",
    openModal
);


closeModalButton.addEventListener(
    "click",
    closeModal
);


cancelModalButton.addEventListener(
    "click",
    closeModal
);


/* الضغط خارج النافذة */

classModal.addEventListener(
    "click",
    function(event) {

        if (
            event.target ===
            classModal
        ) {

            closeModal();

        }

    }
);


/* ==================================================
   SAVE NEW CLASS
================================================== */

saveClassButton.addEventListener(
    "click",
    function() {

        /*
           إذا كان هناك صف يتم تعديله،
           لا ننفذ منطق إضافة صف جديد.
        */

        if (
            saveClassButton.dataset.editingId
        ) {

            return;

        }


        const stage =
            stageSelect.value;

        const grade =
            gradeSelect.value;

        const section =
            classNumberInput.value.trim();


        if (!stage) {

            alert(
                "يرجى اختيار المرحلة التعليمية."
            );

            return;
        }


        if (!grade) {

            alert(
                "يرجى اختيار الصف."
            );

            return;
        }


        if (!section) {

            alert(
                "يرجى إدخال رقم الفصل."
            );

            return;
        }


        const sectionNumber =
            Number(section);


        if (
            sectionNumber < 1 ||
            sectionNumber > 10
        ) {

            alert(
                "رقم الفصل يجب أن يكون من 1 إلى 10."
            );

            return;
        }


        const gradeNumber =
            getGradeNumber(grade);


        const code =
            gradeNumber
                ? `${gradeNumber}/${sectionNumber}`
                : `${grade}/${sectionNumber}`;


        const classes =
            getClasses();


        /*
           منع تسجيل نفس الصف والمرحلة والفصل
           أكثر من مرة.
        */

        const exists =
            classes.some(
                function(item) {

                    return (
                        item.stage === stage &&
                        item.grade === grade &&
                        String(item.section) ===
                            String(sectionNumber)
                    );

                }
            );


        if (exists) {

            alert(
                "هذا الصف مسجل بالفعل."
            );

            return;
        }


        const newClass = {

            id:
                Date.now().toString(),

            stage:
                stage,

            grade:
                grade,

            section:
                sectionNumber,

            code:
                code,

            studentsCount:
                0,

            students:
                [],

            createdAt:
                new Date().toISOString()

        };


        classes.push(
            newClass
        );


        saveClasses(
            classes
        );


        renderClasses();

        closeModal();

    }
);


/* ==================================================
   GRADE NUMBER
================================================== */

function getGradeNumber(grade) {

    const map = {

        "الصف الأول الابتدائي": "1",
        "الصف الثاني الابتدائي": "2",
        "الصف الثالث الابتدائي": "3",
        "الصف الرابع الابتدائي": "4",
        "الصف الخامس الابتدائي": "5",
        "الصف السادس الابتدائي": "6",

        "الصف الأول الإعدادي": "1",
        "الصف الثاني الإعدادي": "2",
        "الصف الثالث الإعدادي": "3",

        "الصف الأول الثانوي": "1",
        "الصف الثاني الثانوي": "2",
        "الصف الثالث الثانوي": "3"

    };


    return map[grade] || "";
}


/* ==================================================
   DELETE
================================================== */

function deleteClass(id) {

    const classes =
        getClasses();


    const target =
        classes.find(
            function(item) {

                return String(item.id) ===
                    String(id);

            }
        );


    if (!target) {
        return;
    }


    const confirmed =
        confirm(
            `هل تريد حذف ${target.grade} — الفصل ${target.section}؟`
        );


    if (!confirmed) {
        return;
    }


    const updated =
        classes.filter(
            function(item) {

                return String(item.id) !==
                    String(id);

            }
        );


    saveClasses(
        updated
    );


    renderClasses();

}


/* ==================================================
   EDIT
================================================== */

function editClass(classData) {

    /*
       نحفظ معرف الصف الذي يتم تعديله
       قبل فتح النافذة.
    */

    saveClassButton.dataset.editingId =
        classData.id;


    classModal.hidden =
        false;

    document.body.style.overflow =
        "hidden";


    stageSelect.value =
        classData.stage;


    stageSelect.dispatchEvent(
        new Event("change")
    );


    gradeSelect.value =
        classData.grade;


    classNumberInput.value =
        classData.section;


    updatePreview();

}


/* ==================================================
   SAVE EDIT
================================================== */

saveClassButton.addEventListener(
    "click",
    function(event) {

        const editingId =
            saveClassButton.dataset.editingId;

        if (!editingId) {
            return;
        }


        event.stopImmediatePropagation();


        const stage =
            stageSelect.value;

        const grade =
            gradeSelect.value;

        const section =
            Number(
                classNumberInput.value
            );


        if (
            !stage ||
            !grade ||
            !section ||
            section < 1 ||
            section > 10
        ) {

            alert(
                "يرجى إدخال بيانات الصف بشكل صحيح."
            );

            return;
        }


        const classes =
            getClasses();


        const index =
            classes.findIndex(
                function(item) {

                    return String(item.id) ===
                        String(editingId);

                }
            );


        if (index === -1) {

            delete saveClassButton.dataset.editingId;

            return;
        }


        /*
           منع تعديل الصف إلى صف آخر
           موجود بالفعل.

           نستثني نفس الصف الذي نقوم بتعديله
           باستخدام id.
        */

        const duplicate =
            classes.some(
                function(item) {

                    if (
                        String(item.id) ===
                        String(editingId)
                    ) {
                        return false;
                    }


                    return (
                        item.stage === stage &&
                        item.grade === grade &&
                        String(item.section) ===
                            String(section)
                    );

                }
            );


        if (duplicate) {

            alert(
                "هذا الصف مسجل بالفعل."
            );

            return;
        }


        const gradeNumber =
            getGradeNumber(grade);


        classes[index] = {

            ...classes[index],

            stage:
                stage,

            grade:
                grade,

            section:
                section,

            code:
                gradeNumber
                    ? `${gradeNumber}/${section}`
                    : `${grade}/${section}`,

            studentsCount:
                getStudentCount(
                    classes[index]
                )

        };


        saveClasses(
            classes
        );


        delete saveClassButton.dataset.editingId;


        renderClasses();

        closeModal();

    },
    true
);


/* ==================================================
   BACK
   الصفحة الرئيسية للطلاب
================================================== */

backButton.addEventListener(
    "click",
    function() {

        /*
           صفحة إدارة الصفوف هي صفحة رئيسية.
           لذلك زر الرجوع منها يجب أن يعيد
           المستخدم إلى الرئيسية مباشرة،
           وليس إلى كل خطوة سابقة.
        */

        renderClasses();

        window.location.replace(
            "home.html"
        );

    }
);


/* ==================================================
   ESCAPE HTML
================================================== */

function escapeHTML(value) {

    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");

}


/* ==================================================
   PAGE VISIBILITY
   تحديث البطاقة عند الرجوع للصفحة
================================================== */

document.addEventListener(
    "visibilitychange",
    function() {

        if (
            document.visibilityState ===
            "visible"
        ) {

            renderClasses();

        }

    }
);


/* ==================================================
   WINDOW FOCUS
   تحديث البيانات عند العودة من صفحة الطلاب
================================================== */

window.addEventListener(
    "focus",
    function() {

        renderClasses();

    }
);


/* ==================================================
   MAIN NAVIGATION
   Canonical 6-item navigation
================================================== */

/*
   التنقل بين الصفحات الرئيسية لا يضيف
   خطوات جديدة إلى سجل الرجوع.

   أما الصفحات الفرعية مثل
   class-students.html فتستخدم href
   طبيعي حتى يعود زر الهاتف منها
   إلى صفحة إدارة الصفوف.
*/

function goMain(page) {

    const currentPage =
        window.location.pathname
            .split("/")
            .pop()
            .toLowerCase();


    if (
        currentPage === "home.html" ||
        currentPage === ""
    ) {

        window.location.href =
            page;

        return;
    }


    window.location.replace(
        page
    );

}


const homeNavigation =
    document.getElementById("homeNavigation");

const attendanceNavigation =
    document.getElementById("attendanceNavigation");

const studentsNavigation =
    document.getElementById("studentsNavigation");

const scheduleNavigation =
    document.getElementById("scheduleNavigation");

const gradesNavigation =
    document.getElementById("gradesNavigation");

const reportsNavigation =
    document.getElementById("reportsNavigation");


/* الرئيسية */

if (homeNavigation) {

    homeNavigation.addEventListener(
        "click",
        function() {

            goMain(
                "home.html"
            );

        }
    );

}


/* الحضور */

if (attendanceNavigation) {

    attendanceNavigation.addEventListener(
        "click",
        function() {

            const currentClass =
                localStorage.getItem(
                    "mueen_current_class"
                );


            if (currentClass) {

                goMain(
                    "attendance.html?class=" +
                    encodeURIComponent(
                        currentClass
                    )
                );

            } else {

                goMain(
                    "attendance.html"
                );

            }

        }
    );

}


/* الطلاب */

if (studentsNavigation) {

    studentsNavigation.addEventListener(
        "click",
        function() {

            goMain(
                "students.html"
            );

        }
    );

}


/* حصصي */

if (scheduleNavigation) {

    scheduleNavigation.addEventListener(
        "click",
        function() {

            goMain(
                "schedule.html"
            );

        }
    );

}


/* دفتري */

if (gradesNavigation) {

    gradesNavigation.addEventListener(
        "click",
        function() {

            goMain(
                "grades.html"
            );

        }
    );

}


/* التقارير */

if (reportsNavigation) {

    reportsNavigation.addEventListener(
        "click",
        function() {

            goMain(
                "reports.html"
            );

        }
    );

}


/* ==================================================
   INIT
================================================== */

document.addEventListener(
    "DOMContentLoaded",
    function() {

        renderClasses();

    }
);