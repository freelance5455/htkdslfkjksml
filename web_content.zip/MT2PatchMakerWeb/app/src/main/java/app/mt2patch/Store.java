package app.mt2patch;
import org.json.JSONArray;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

public class Store {
  File root;
  Store(File r) { root = r; }
  File d(String n) { File f = new File(root, n); f.mkdirs(); return f; }
  String ts() { return new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()); }
  static void copy(File a, File b) throws IOException {
    try (InputStream i = new FileInputStream(a); OutputStream o = new FileOutputStream(b)) {
      byte[] buf = new byte[8192]; int n; while ((n = i.read(buf)) > 0) o.write(buf, 0, n); } }
  static void write(File f, byte[] b) throws IOException { try (OutputStream o = new FileOutputStream(f)) { o.write(b); } }
  static String read(File f) throws IOException {
    ByteArrayOutputStream bo = new ByteArrayOutputStream();
    try (InputStream i = new FileInputStream(f)) { byte[] buf = new byte[8192]; int n; while ((n = i.read(buf)) > 0) bo.write(buf, 0, n); }
    return bo.toString("UTF-8"); }
  /** Original is copied once and never overwritten (a different file with the same name gets a new name). */
  File backup(File src) throws IOException {
    File b = new File(d("backup"), src.getName());
    if (b.exists() && b.length() != src.length()) b = new File(d("backup"), ts() + "_" + src.getName());
    if (!b.exists()) copy(src, b);
    return b; }
  File saveOutput(File tmp, String name) throws IOException {
    File o = new File(d("out"), "modified_" + ts() + "_" + name);
    if (o.exists()) throw new IOException("Output exists, wait a second and retry");
    copy(tmp, o); return o; }
  File savePatches(JSONArray a) throws IOException {
    File f = new File(d("patches"), "patch_" + ts() + ".json"); write(f, a.toString().getBytes(StandardCharsets.UTF_8)); return f; }
  void log(String kind, String msg) {
    try (FileWriter w = new FileWriter(new File(d("logs"), kind + ".log"), true)) { w.write("[" + ts() + "] " + msg + "\n"); } catch (IOException ignored) { } }
  String readLog(String kind) {
    File f = new File(d("logs"), kind + ".log");
    try { if (!f.exists()) return "(empty)"; String s = read(f); return s.length() > 3000 ? s.substring(s.length() - 3000) : s; }
    catch (IOException e) { return "(unreadable)"; } }
}
