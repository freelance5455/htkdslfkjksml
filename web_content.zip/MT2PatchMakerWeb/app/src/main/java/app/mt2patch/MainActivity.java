package app.mt2patch;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.webkit.*;
import org.json.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
  WebView web; Store st; Engine eng; File tmp, backupFile; String dex = "classes.dex", pendingId;
  JSONObject cur; boolean staged, valid; JSONArray applied = new JSONArray();
  final ExecutorService ex = Executors.newSingleThreadExecutor();

  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    if (Build.VERSION.SDK_INT >= 30) { if (!Environment.isExternalStorageManager())
      startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + getPackageName()))); }
    else requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE, android.Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
    st = new Store(new File(Environment.getExternalStorageDirectory(), "MT2"));
    eng = new Engine(new File(getFilesDir(), "work")); tmp = new File(getCacheDir(), "validate.dex");
    web = new WebView(this); setContentView(web);
    web.getSettings().setJavaScriptEnabled(true);
    web.addJavascriptInterface(new Bridge(), "Android");
    web.loadUrl("file:///android_asset/index.html"); }

  public class Bridge {
    @JavascriptInterface public String root() { return st.root.getPath(); }
    @JavascriptInterface public void call(String id, String op, String args) { dispatch(id, op, args); } }

  static String err(String m) { return "{\"error\":" + JSONObject.quote(m) + "}"; }
  void reply(String id, String json) { runOnUiThread(() -> web.evaluateJavascript("window.__cb('" + id + "'," + json + ")", null)); }

  void dispatch(String id, String op, String args) {
    if (op.equals("pick")) {
      try { JSONObject a = new JSONObject(args); st.root = new File(a.getString("root"));
        final int code = a.getString("kind").equals("dex") ? 1 : 2; pendingId = id;
        runOnUiThread(() -> { Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*"); startActivityForResult(i, code); });
      } catch (Exception e) { reply(id, err(String.valueOf(e.getMessage()))); }
      return; }
    ex.submit(() -> { try { reply(id, handle(op, new JSONObject(args))); }
      catch (Throwable e) { st.log("errors", Log.get(e)); reply(id, err(String.valueOf(e.getMessage()))); } }); }

  static class Log { static String get(Throwable e) { StringWriter w = new StringWriter(); e.printStackTrace(new PrintWriter(w)); String s = w.toString(); return s.substring(0, Math.min(800, s.length())); } }

  String handle(String op, JSONObject a) throws Exception {
    switch (op) {
      case "root": st.root = new File(a.getString("path")); return "{}";
      case "search": { String q = a.getString("term").trim(); List<String> f = q.isEmpty() ? new ArrayList<String>() : eng.find(q);
        return new JSONObject().put("classes", new JSONArray(f)).put("patches", eng.suggest(f, q)).toString(); }
      case "preview": { if (staged) { eng.rollback(); staged = false; } valid = false; cur = a.getJSONObject("patch");
        return new JSONObject().put("hits", eng.preview(cur, a.getJSONArray("sel"))).toString(); }
      case "validate": { if (eng.pending.isEmpty()) return err("Nothing to change");
        if (!staged) { eng.stage(); staged = true; }
        String e = eng.assemble(tmp); valid = e == null;
        if (e != null) { st.log("errors", cur.optString("name") + ": " + e); eng.rollback(); staged = false; }
        return new JSONObject().put("ok", valid).put("err", e == null ? "" : e).toString(); }
      case "apply": { if (!valid) return err("Validate first");
        File o = st.saveOutput(tmp, dex); applied.put(cur); File pf = st.savePatches(applied);
        st.log("history", "Applied " + cur.optString("name") + " -> " + o.getName()); staged = false; valid = false;
        return new JSONObject().put("out", o.getPath()).put("pf", pf.getPath()).toString(); }
      case "discard": { if (staged) { eng.rollback(); staged = false; } valid = false; return "{}"; }
      case "undo": { valid = false; return new JSONObject().put("ok", eng.rollback()).toString(); }
      case "restore": { if (backupFile == null) return err("Import a DEX first");
        eng.disassemble(backupFile); applied = new JSONArray(); staged = false; valid = false; st.log("history", "Restored original"); return "{}"; }
      case "log": return new JSONObject().put("text", st.readLog(a.getString("kind"))).toString();
      default: return err("Unknown op"); } }

  @Override protected void onActivityResult(int rc, int rs, Intent d) {
    final String id = pendingId;
    if (rs != RESULT_OK || d == null || d.getData() == null) { reply(id, err("Cancelled")); return; }
    final Uri u = d.getData();
    ex.submit(() -> { try {
      ByteArrayOutputStream bo = new ByteArrayOutputStream(); InputStream in = getContentResolver().openInputStream(u);
      byte[] buf = new byte[8192]; int n; while ((n = in.read(buf)) > 0) bo.write(buf, 0, n); in.close();
      if (rc == 1) {
        String seg = u.getLastPathSegment(); String name = seg == null ? "classes.dex" : seg.substring(seg.lastIndexOf('/') + 1);
        if (!name.endsWith(".dex")) name = "classes.dex"; dex = name;
        File src = new File(getCacheDir(), name); Store.write(src, bo.toByteArray());
        backupFile = st.backup(src); eng.disassemble(backupFile); applied = new JSONArray(); staged = false; valid = false;
        st.log("history", "Imported " + name + ", backup " + backupFile.getPath());
        reply(id, "{\"name\":" + JSONObject.quote(name) + ",\"backup\":" + JSONObject.quote(backupFile.getPath()) + "}");
      } else reply(id, "{\"patches\":" + new JSONArray(bo.toString("UTF-8")) + "}");
    } catch (Throwable e) { st.log("errors", Log.get(e)); reply(id, err(String.valueOf(e.getMessage()))); } }); }
}
