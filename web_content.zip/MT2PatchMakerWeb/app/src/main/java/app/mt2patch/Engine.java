package app.mt2patch;
import com.android.tools.smali.baksmali.Baksmali;
import com.android.tools.smali.baksmali.BaksmaliOptions;
import com.android.tools.smali.dexlib2.DexFileFactory;
import com.android.tools.smali.dexlib2.Opcodes;
import com.android.tools.smali.smali.Smali;
import com.android.tools.smali.smali.SmaliOptions;
import org.json.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;
import java.util.stream.Stream;

/** Smali workflow: DEX -> smali tree -> regex patches -> reassemble (= rebuild validation). */
public class Engine {
  static class Hit { File f; String before, after; Hit(File f, String b, String a) { this.f = f; before = b; after = a; } }
  final File work;
  final Deque<Map<File, String>> undo = new ArrayDeque<>();
  List<Hit> pending = new ArrayList<>();
  Engine(File w) { work = w; }

  static void rm(File f) { File[] c = f.listFiles(); if (c != null) for (File x : c) rm(x); f.delete(); }
  static String rd(File f) throws IOException { return new String(Files.readAllBytes(f.toPath()), "UTF-8"); }
  static void wr(File f, String s) throws IOException { Files.write(f.toPath(), s.getBytes("UTF-8")); }

  void disassemble(File dex) throws Exception {
    rm(work); work.mkdirs(); undo.clear(); pending.clear();
    Baksmali.disassembleDexFile(DexFileFactory.loadDexFile(dex, Opcodes.getDefault()), work, 4, new BaksmaliOptions()); }

  List<String> find(String q) throws IOException {
    List<String> r = new ArrayList<>(); String lq = q.toLowerCase();
    try (Stream<Path> s = Files.walk(work.toPath())) {
      for (Path p : (Iterable<Path>) s::iterator)
        if (p.toString().endsWith(".smali") && rd(p.toFile()).toLowerCase().contains(lq)) r.add(work.toPath().relativize(p).toString()); }
    return r; }

  static String[][] stubs(String t) {
    String z = "    .locals 1\n    const/4 v0, 0x0\n    return v0", o = "    .locals 1\n    const/4 v0, 0x1\n    return v0";
    switch (t) {
      case "V": return new String[][]{{"return-void", "    .locals 0\n    return-void"}};
      case "Z": return new String[][]{{"true", o}, {"false", z}};
      case "F": return new String[][]{{"0", z}};
      case "B": case "S": case "C": case "I": return new String[][]{{"0", z}, {"1", o}};
      case "J": case "D": return new String[][]{{"0", "    .locals 2\n    const-wide/16 v0, 0x0\n    return-wide v0"}};
      default: return new String[][]{{"null", "    .locals 1\n    const/4 v0, 0x0\n    return-object v0"}}; } }

  /** Suggest return-stub patches for ANY method (any return type) whose name or class matches the term. */
  JSONArray suggest(List<String> rels, String q) throws Exception {
    JSONArray out = new JSONArray(); String lq = q.toLowerCase();
    Pattern cp = Pattern.compile("\\.class .*?L([^;]+);");
    Pattern mp = Pattern.compile("^\\.method (?![^\\n]*(abstract|native))[^\\n]* (\\S+)\\(([^)]*)\\)(\\S+)$", Pattern.MULTILINE);
    for (String rel : rels) {
      String t = rd(new File(work, rel)); Matcher c = cp.matcher(t); if (!c.find()) continue;
      String cls = c.group(1); boolean cm = cls.toLowerCase().contains(lq); Matcher m = mp.matcher(t);
      while (m.find()) {
        String n = m.group(2), ps = m.group(3), ret = m.group(4);
        if (n.startsWith("<") || !(cm || n.toLowerCase().contains(lq))) continue;
        for (String[] s : stubs(ret)) {
          out.put(new JSONObject().put("name", cls.substring(cls.lastIndexOf('/') + 1) + "." + n + " -> " + s[0])
            .put("find", "(^\\.method [^\\n]* " + Pattern.quote(n) + "\\(" + Pattern.quote(ps) + "\\)" + Pattern.quote(ret) + "\\n)[\\s\\S]*?(^\\.end method)")
            .put("replace", "$1" + s[1] + "\n$2"));
          if (out.length() >= 400) return out; } } }
    return out; }

  JSONArray preview(JSONObject p, JSONArray sel) throws Exception {
    Pattern re = Pattern.compile(p.getString("find"), Pattern.MULTILINE);
    pending = new ArrayList<>(); JSONArray out = new JSONArray();
    for (int i = 0; i < sel.length(); i++) {
      File f = new File(work, sel.getString(i)); String t = rd(f);
      String r = re.matcher(t).replaceAll(p.getString("replace"));
      if (!r.equals(t)) { Hit h = new Hit(f, t, r); pending.add(h); out.put(new JSONObject().put("file", f.getName()).put("diff", diff(h))); } }
    return out; }

  static String diff(Hit h) {
    String[] a = h.before.split("\n", -1), b = h.after.split("\n", -1);
    int s = 0; while (s < a.length && s < b.length && a[s].equals(b[s])) s++;
    int e = 0; while (e < a.length - s && e < b.length - s && a[a.length - 1 - e].equals(b[b.length - 1 - e])) e++;
    StringBuilder sb = new StringBuilder(); int n = 0;
    for (int i = s; i < a.length - e && n++ < 40; i++) sb.append("- ").append(a[i]).append('\n');
    for (int i = s; i < b.length - e && n++ < 80; i++) sb.append("+ ").append(b[i]).append('\n');
    return sb.toString(); }

  void stage() throws IOException {
    Map<File, String> m = new HashMap<>();
    for (Hit h : pending) { m.put(h.f, h.before); wr(h.f, h.after); }
    undo.push(m); }
  boolean rollback() throws IOException {
    if (undo.isEmpty()) return false;
    for (Map.Entry<File, String> e : undo.pop().entrySet()) wr(e.getKey(), e.getValue());
    return true; }

  /** Reassemble. null = success, else errors. Proves it rebuilds, NOT runtime behaviour. */
  String assemble(File out) {
    SmaliOptions o = new SmaliOptions(); o.outputDexFile = out.getPath(); o.apiLevel = 30;
    PrintStream old = System.err; ByteArrayOutputStream b = new ByteArrayOutputStream(); System.setErr(new PrintStream(b)); boolean ok;
    String ex = "";
    try { ok = Smali.assemble(o, Collections.singletonList(work.getPath())); } catch (Exception e) { ok = false; ex = e.toString(); } finally { System.setErr(old); }
    if (ok) return null;
    String s = (b.toString() + ex).trim(); return s.isEmpty() ? "Assembler failed" : s.substring(0, Math.min(2000, s.length())); }
}
