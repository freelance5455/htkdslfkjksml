// UI layer: talks to Java through the Android bridge (WebView needs a little JS for that).
const cbs = {}; let n = 0;
window.__cb = (id, r) => { const f = cbs[id]; delete cbs[id]; f && f(r); };
const call = (op, args = {}) => new Promise(res => { const id = 'c' + (++n); cbs[id] = res; Android.call(id, op, JSON.stringify(args)); });
const $ = s => document.querySelector(s);
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
let classes = [], sel = new Set(), patches = [], cur = null, restoreAsk = false;
function status(t, k) { const e = $('#st'); e.textContent = t; e.className = k || ''; }
function chk(r) { if (r.error) { status('Error: ' + r.error, 'bad'); return false; } return true; }
async function go(msg, fn) { status(msg); $('#bar').hidden = false; try { await fn(); } catch (e) { status('Error: ' + e, 'bad'); } $('#bar').hidden = true; }
$('#root').value = Android.root();
$('#root').onchange = () => call('root', { path: $('#root').value });

function renderClasses() {
  $('#classes').innerHTML = classes.slice(0, 200).map((c, i) =>
    `<label class="cls"><input type="checkbox" data-i="${i}" ${sel.has(c) ? 'checked' : ''}><span>${esc(c.replace(/\.smali$/, ''))}</span></label>`).join('')
    + (classes.length > 200 ? `<p class="mut">+${classes.length - 200} more (all selected)</p>` : '');
  $('#cnt').textContent = sel.size + ' selected'; }
function renderPatches() {
  $('#sg').hidden = !patches.length;
  $('#patches').innerHTML = patches.slice(0, 150).map((p, i) => `<button class="p ${p === cur ? 'on' : ''}" data-i="${i}">${esc(p.name)}</button>`).join(''); }
$('#classes').onchange = e => { const c = classes[e.target.dataset.i]; e.target.checked ? sel.add(c) : sel.delete(c); $('#cnt').textContent = sel.size + ' selected'; };
$('#all').onclick = () => { sel = new Set(classes); renderClasses(); };
$('#none').onclick = () => { sel = new Set(); renderClasses(); };

$('#bDex').onclick = () => go('Importing…', async () => {
  const r = await call('pick', { kind: 'dex', root: $('#root').value }); if (!chk(r)) return;
  classes = []; patches = []; sel = new Set(); cur = null; $('#pv').hidden = true; renderClasses(); renderPatches();
  status('Imported ' + r.name + ' ✔\nBackup: ' + r.backup, 'ok'); });
$('#bPat').onclick = () => go('Loading patches…', async () => {
  const r = await call('pick', { kind: 'patch', root: $('#root').value }); if (!chk(r)) return;
  patches = r.patches; renderPatches(); status('Loaded ' + patches.length + ' patch(es)', 'ok'); });
$('#bSearch').onclick = () => go('Searching…', async () => {
  const r = await call('search', { term: $('#q').value }); if (!chk(r)) return;
  classes = r.classes; sel = new Set(classes); patches = r.patches; cur = null; $('#pv').hidden = true; renderClasses(); renderPatches();
  status(classes.length + ' class(es) · ' + patches.length + ' suggested patch(es)'); });
$('#patches').onclick = e => { const i = e.target.dataset.i; if (i === undefined) return; go('Building preview…', async () => {
  cur = patches[i]; $('#bApply').disabled = true;
  const r = await call('preview', { patch: cur, sel: [...sel] }); if (!chk(r)) return;
  $('#pv').hidden = false; $('#pn').textContent = cur.name; renderPatches();
  $('#hits').innerHTML = r.hits.map(h => `<div class="hit"><b>${esc(h.file)}</b>` + h.diff.split('\n').filter(Boolean)
    .map(l => `<div class="${l[0] === '+' ? 'add' : 'del'}">${esc(l)}</div>`).join('') + '</div>').join('');
  status(r.hits.length + ' file(s) will change. Review, then Validate.'); }); };
$('#bVal').onclick = () => go('Validating (reassembling)…', async () => {
  const r = await call('validate'); if (!chk(r)) return;
  $('#bApply').disabled = !r.ok;
  r.ok ? status('Rebuild OK ✔ (assembles; runtime NOT tested). Safe to apply.', 'ok') : status('Validation FAILED, rolled back:\n' + r.err, 'bad'); });
$('#bApply').onclick = () => go('Saving…', async () => {
  const r = await call('apply'); if (!chk(r)) return;
  $('#bApply').disabled = true; $('#pv').hidden = true; cur = null; renderPatches();
  status('Saved ✔ ' + r.out + '\nPatch file: ' + r.pf, 'ok'); });
$('#bDis').onclick = () => go('…', async () => { await call('discard'); cur = null; $('#pv').hidden = true; renderPatches(); status('Discarded'); });
$('#bUndo').onclick = () => go('Undoing…', async () => { const r = await call('undo'); status(r.ok ? 'Undid last change. Re-validate to export.' : 'Nothing to undo'); });
$('#bRes').onclick = () => {
  if (!restoreAsk) { restoreAsk = true; $('#bRes').textContent = 'Confirm restore'; status('Tap again to restore the original DEX (discards working changes)'); setTimeout(() => { restoreAsk = false; $('#bRes').textContent = '♻ Restore'; }, 5000); return; }
  restoreAsk = false; $('#bRes').textContent = '♻ Restore';
  go('Restoring…', async () => { const r = await call('restore'); if (chk(r)) status('Restored from original backup ✔', 'ok'); }); };
for (const [id, k] of [['#bHis', 'history'], ['#bErr', 'errors']]) $(id).onclick = async () => {
  const l = $('#log'); if (!l.hidden && l.dataset.k === k) { l.hidden = true; return; }
  const r = await call('log', { kind: k }); l.dataset.k = k; l.textContent = r.text; l.hidden = false; };
renderClasses();
