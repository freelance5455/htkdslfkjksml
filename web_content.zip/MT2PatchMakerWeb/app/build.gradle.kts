plugins { id("com.android.application") }
android {
  namespace = "app.mt2patch"; compileSdk = 35
  defaultConfig { applicationId = "app.mt2patch"; minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "0.2" }
  compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
  packaging { resources.excludes += setOf("META-INF/*") }
}
dependencies {
  val s = "3.0.9" // verify latest com.android.tools.smali release
  implementation("com.android.tools.smali:smali:$s")
  implementation("com.android.tools.smali:smali-baksmali:$s")
  implementation("com.android.tools.smali:smali-dexlib2:$s")
}
