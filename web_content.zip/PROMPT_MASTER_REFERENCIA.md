# PROMPT MASTER DEFINITIVO — MÁQUINA MILITAR
## VERSÃO 3.2 — RECONSTRUÇÃO INTEGRAL E CONSISTENTE

## 0. OBJETIVO
Criar **MÁQUINA MILITAR** como um sistema Android real, funcional, persistente e operacional. A interface é apenas a representação; o núcleo é: **dados → estado → categoria efetiva → ciclo operacional → conflitos → agendamentos nativos → execução → cumprimento/violação → persistência → reconstrução**.

### REGRA ABSOLUTA DE CONTINUIDADE
Depois de o utilizador **ativar qualquer uma das 7 categorias**, a máquina deve entrar no estado **EM_EXECUÇÃO** e permanecer em andamento continuamente até o utilizador utilizar explicitamente o comando global **DESLIGAR/OFF**. **Trocar de categoria nunca desliga a máquina.** Expirar uma temporária às 03:00 nunca desliga a máquina. Fechar a aplicação, bloquear o ecrã, terminar o processo, perder rede, ou reiniciar o telefone não deve apagar o estado lógico; após o retorno do Android, o sistema deve reconstruir os futuros válidos.

A máquina é um único motor contínuo. A categoria selecionada apenas determina os dados operacionais que alimentam esse motor.

## 1. IDENTIDADE
Nome: **MÁQUINA MILITAR**
Código: **07770**
Frase: **“Obsessed to progress.”**

## 2. CATEGORIAS — EXATAMENTE 7
- 1_NAO — **NÃO** — PERMANENTE
- 2_SIM_24H — **SIM — 24 HORAS** — TEMPORÁRIA
- 3_FERIAS — **ESTOU DE FÉRIAS** — PERMANENTE
- 4_EXPLICACAO — **AGORA VOU À EXPLICAÇÃO** — PERMANENTE
- 5_NAO_ESCOLA_EXPLICACAO — **NÃO FUI À ESCOLA, MAS VOU À EXPLICAÇÃO — 24 HORAS** — TEMPORÁRIA
- 6_NAO_EXPLICACAO — **NÃO FUI À EXPLICAÇÃO — 24 HORAS** — TEMPORÁRIA
- 7_NAO_PE_EXPLICACAO — **NÃO FUI À EDUCAÇÃO FÍSICA, MAS VOU À EXPLICAÇÃO — 24 HORAS** — TEMPORÁRIA


## 2.1 MODELO DE SELEÇÃO E CONTINUIDADE
A aplicação mantém separadamente três conceitos: **CATEGORIA PERMANENTE**, **CATEGORIA TEMPORÁRIA** e **CATEGORIA EFETIVA**.

- A categoria permanente é a base de fallback.
- Pode existir no máximo **uma categoria temporária ativa**.
- A categoria efetiva é a temporária quando existe e é válida; caso contrário, é a permanente.
- Selecionar uma categoria permanente altera a base permanente, mas **não cancela uma temporária já ativa**; a temporária continua até à próxima 03:00.
- Selecionar uma categoria temporária substitui a temporária anterior pela nova temporária e mantém intacta a permanente.
- Ao terminar a temporária às 03:00, o sistema faz automaticamente a passagem para a permanente e continua **EM_EXECUÇÃO**.

### ATIVAÇÃO
Ao tocar numa das 7 categorias, o sistema deve: guardar a seleção localmente, resolver a categoria efetiva, resolver o dia operacional, cancelar apenas os futuros que ficaram inválidos, reconstruir os futuros válidos sem duplicação, atualizar a interface e colocar **MÁQUINA_EM_EXECUÇÃO = true**.

A seleção de categoria **não é um comando de desligar**. O único comando que pode colocar a máquina em OFF é a ação global explícita **DESLIGAR/OFF**.

## 2.2 INTERFACE PRINCIPAL
A interface deve usar **laranja + preto**, alto contraste e elementos grandes. O laranja é a cor ativa; **amarelo não deve ser usado como cor primária de estado ativo**. O estado OFF deve usar aparência neutra.

### ECRÃ DE ACESSO
- Exigir o código local **07770** antes de entrar na aplicação.
- Depois do código correto, mostrar literalmente **“Obsessed to progress.”**.
- O código não é enviado para a internet.

### ECRÃ PRINCIPAL
Mostrar simultaneamente:
- título **MÁQUINA MILITAR**;
- data completa do dispositivo;
- dia da semana;
- hora atual do dispositivo;
- estado global **ON/OFF**;
- categoria permanente;
- categoria temporária, quando existir;
- categoria efetiva;
- ciclo operacional **03:00 → 03:00**;
- próxima mudança relevante;
- botão **ESCOLHER CATEGORIA**;
- botão/ícone de olho **VER DADOS**.

Quando a máquina estiver ON, o ecrã deve refletir **EM_EXECUÇÃO**. O utilizador não precisa manter este ecrã aberto para os agendamentos funcionarem.

### ECRÃ ESCOLHER CATEGORIA
Mostrar **exatamente 7** opções e nenhuma oitava opção:
1. NÃO
2. SIM — 24 HORAS
3. ESTOU DE FÉRIAS
4. AGORA VOU À EXPLICAÇÃO
5. NÃO FUI À ESCOLA, MAS VOU À EXPLICAÇÃO — 24 HORAS
6. NÃO FUI À EXPLICAÇÃO — 24 HORAS
7. NÃO FUI À EDUCAÇÃO FÍSICA, MAS VOU À EXPLICAÇÃO — 24 HORAS

Não criar opções como “trabalho”, “não estou a trabalhar”, “dia livre”, “sem escola” ou qualquer outra categoria inventada.

## 5.1 REGRAS DA MÁQUINA SEMPRE EM ANDAMENTO
**INVARIANTE:** se `MÁQUINA_EM_EXECUÇÃO = true`, existe sempre uma categoria efetiva válida para o ciclo atual e existe sempre um processo de reconciliação responsável por garantir os próximos eventos futuros.

A máquina deve permanecer funcional com a aplicação fechada e com o ecrã bloqueado. Ao abrir novamente, a interface apenas lê o estado persistido; não é ela que mantém a rotina viva.

Se o processo da interface morrer, o núcleo lógico persistido deve sobreviver e o mecanismo nativo deve continuar responsável pelos agendamentos já programados. Após reboot ou recuperação do sistema, executar uma **RECONCILIAÇÃO AUTOMÁTICA** antes de aceitar novos agendamentos.

Se `MÁQUINA_EM_EXECUÇÃO = false`, nenhum novo alarme/notificação futuro da máquina deve permanecer programado, mas os dados e estados históricos devem ser preservados. Ao selecionar qualquer categoria novamente, voltar imediatamente para `true` e reconstruir a rotina.

## 3. PERMANENTES
NÃO; ESTOU DE FÉRIAS; AGORA VOU À EXPLICAÇÃO. A Categoria 4 é permanente e não expira.

## 4. TEMPORÁRIAS
SIM — 24 HORAS; NÃO FUI À ESCOLA, MAS VOU À EXPLICAÇÃO — 24 HORAS; NÃO FUI À EXPLICAÇÃO — 24 HORAS; NÃO FUI À EDUCAÇÃO FÍSICA, MAS VOU À EXPLICAÇÃO — 24 HORAS. Todas terminam na próxima 03:00.

## 5. CICLO OPERACIONAL
03:00 → 03:00. 00:00–02:59 pertence ao ciclo operacional do dia anterior. 20:25–03:00 pertence ao mesmo ciclo iniciado às 03:00.

## 6. MOTOR DE ESTADOS — FUNDAMENTAL
Persistir estados localmente. Item: AGUARDANDO, NOTIFICADO, EM_ANDAMENTO, CONCLUÍDO, NÃO_CONFIRMADO, VIOLAÇÃO_CONFIRMED, CANCELADO. Evento: AGUARDANDO, PENDENTE, CONFIRMADO, EXECUTADO, CANCELADO. Explicação: EM ANDAMENTO / TERMINADA.

### Cumprimento
O telefone não consegue observar fisicamente todas as ações. Portanto, fim de janela sem confirmação = **ROTINA NÃO CONFIRMADA**, não uma alegação falsa. O utilizador pode marcar **CUMPRI** ou **NÃO CUMPRI**. Somente **NÃO CUMPRI** produz **VIOLAÇÃO CONFIRMADA** e a mensagem específica de violação.

## 7. ÁUDIOS — 49/49
**ÁUDIOS = SIM em todos os 49 registos.** Mensagem: **“Aproveite este momento para escutar os áudios, áudios por ti feitos.”**. Prioridade baixa. Nunca interromper obrigação superior.
- Não escolar: **08:45** no início da janela livre 08:45–09:55.
- Sábado escolar: **09:50** como horário de áudio.
- Segunda a sexta escolar: **primeiro momento livre real não reservado** a T.P.C., Educação Física, explicação ou outra obrigação.
- Domingo com igreja: **retorno real da igreja + momento livre real**.

## 8.1. ALARMES E NOTIFICAÇÕES — CONTRATO VISÍVEL E VIBRATÓRIO

**TODO ALARME E TODA NOTIFICAÇÃO desta matriz são reais e devem chegar ao telemóvel como alerta do sistema Android.**

Para cada alarme e para cada notificação válida:
1. criar a ocorrência no agendador nativo;
2. apresentar uma notificação Android visível com a mensagem correspondente;
3. usar som quando definido para o tipo de alerta;
4. activar vibração real;
5. pedir/usar uma vibração de referência de **20 segundos** para cada alerta;
6. quando suportado pelo sistema, permitir apresentação heads-up e no ecrã bloqueado;
7. abrir a MÁQUINA MILITAR ao tocar quando o evento exigir confirmação;
8. marcar o alerta como entregue somente depois de a API nativa confirmar o disparo;
9. se a plataforma impedir som/vibração/notificação por permissão ou configuração do sistema, o diagnóstico deve mostrar o bloqueio e nunca fingir sucesso.

A vibração de 20 segundos é um requisito da aplicação. O código deve configurá-la explicitamente, em vez de depender da vibração padrão de um canal.

**CONTINUIDADE:** a aplicação não pode depender de ficar aberta no ecrã. Os próximos eventos devem continuar agendados em segundo plano e ser reconstruídos depois de fechar, bloquear o ecrã, terminar o processo ou reiniciar o telefone.

## 8. ALARMES E NOTIFICAÇÕES
Alarmes críticos: `window.WebToApk.scheduleNotificationEx()` + `alarm:true` + `ringSeconds:20` + som local + vibração real + `openApp:true` quando aplicável. Disparo = início oficial − 10 min. Notificações normais mantêm a própria hora e não recebem −10 min.

## 9. EXPLICAÇÃO
17:50 e 18:10 são condicionais. Não interrompem explicação. Se a explicação terminar depois do horário, a pendência é entregue após a confirmação do término. Não inventar término.

## 10. CONFLITOS
ESCOLA=NÃO remove preparação/ida/TPC escolar. EXPLICAÇÃO=NÃO remove preparação/ida/notificações/eventos da explicação. PE=NÃO remove preparação/PE/retorno PE. Categoria 4/quarta: PE SIM e retorno PE suspenso. Categoria 7/quarta: PE NÃO e retorno PE não executado. Sono nunca interrompe explicação em andamento.

## 11. DADOS COMPLETOS — 7 CATEGORIAS × 7 DIAS

# CATEGORIA: NÃO — PERMANENTE

## DOMINGO
Escola=NÃO | Explicação=NÃO | Educação Física=NÃO APLICÁVEL | Lavagem=NÃO | T.P.C.=NÃO | **ÁUDIOS=SIM** | Igreja=SIM | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "EVENTO", "trigger": "RETORNO_REAL_DA_IGREJA_E_MOMENTO_LIVRE"}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:00 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05 às 05:00, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME PREPARACAO_IGREJA** — 04:55 → 05:05–05:45 — Tomar banho, escovar os dentes, limpar os sapatos e vestir-se. — **São 04:55. Das 05:05 às 05:45, prepara-te: toma banho, escova os dentes, limpa os sapatos e veste-te.** — cumprimento monitorizado: SIM
- **ALARME ACORDAR_NOITE** — 19:50 → 20:00–20:25 — Acordar, tomar banho e vestir-se. — **São 19:50. Das 20:00 às 20:25, acorda, toma banho e veste-te.** — cumprimento monitorizado: SIM
- **ALARME ESTUDO** — 20:15 → 20:25–03:00 — Estudar MAT e PORT. Faz VID, Ex e GRAV. — **São 20:15. Das 20:25 às 03:00, estuda MAT e PORT. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **EVENTO IGREJA_IDA** — gatilho `PREPARAÇÃO TERMINADA` — Ir à igreja no momento certo. — **Termina de te preparar e vai à igreja no momento certo.** — estado `AGUARDANDO`
- **EVENTO IGREJA_RETORNO** — gatilho `RETORNO REAL DA IGREJA` — Dormir. — **Volta da igreja e dorme.** — estado `AGUARDANDO`
- **EVENTO AUDIOS** — gatilho `RETORNO REAL DA IGREJA + SURGIU MOMENTO LIVRE ANTES DO PRÓXIMO BLOCO FIXO` — Escutar os áudios. — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — estado `AGUARDANDO`
- **TAREFA:** Organizar o quarto.
- **ESTUDO:** MATEMÁTICA — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** PORTUGUÊS — 14 páginas — VID, Ex, GRAV

## SEGUNDA-FEIRA
Escola=SIM | Explicação=NÃO | Educação Física=NÃO | Lavagem=NÃO | T.P.C.=SIM | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "EVENTO", "trigger": "PRIMEIRO_MOMENTO_LIVRE_DISPONIVEL"}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:40 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05–05:40, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME PREPARACAO_ESCOLA** — 05:35 → 05:45–06:00 — Tomar banho, escovar os dentes, limpar os sapatos e vestir o uniforme. — **São 05:35. Das 05:45 às 06:00, prepara-te: toma banho, escova os dentes, limpa os sapatos e veste o uniforme.** — cumprimento monitorizado: SIM
- **ALARME ESCOLA** — 05:50 → 06:00 — Ir à escola. — **São 05:50. Às 06:00, vai à escola.** — cumprimento monitorizado: SIM
- **ALARME BANHO** — 16:35 → 16:45–17:00 — Tomar banho. — **São 16:35. Das 16:45 às 17:00, toma banho.** — cumprimento monitorizado: SIM
- **ALARME SONO** — 16:50 → 17:00–23:00 — Dormir. — **São 16:50. Das 17:00 às 23:00, dorme.** — cumprimento monitorizado: NÃO
- **ALARME ESTUDO** — 22:50 → 23:00–03:00 — Estudar FIS e QUI. Faz VID, Ex e GRAV. — **São 22:50. Das 23:00 às 03:00, estuda FIS e QUI. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO TPC_0520** — 05:20 — **Faz o T.P.C.** — condição `VALID`
- **EVENTO AUDIOS** — gatilho `SURGIU MOMENTO LIVRE NÃO DESTINADO AO T.P.C., À EXPLICAÇÃO, À EDUCAÇÃO FÍSICA OU AO SONO` — Escutar os áudios. — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — estado `AGUARDANDO`
- **ESTUDO:** FÍSICA — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** QUÍMICA — 14 páginas — VID, Ex, GRAV

## TERÇA-FEIRA
Escola=SIM | Explicação=NÃO | Educação Física=NÃO | Lavagem=NÃO | T.P.C.=SIM | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "EVENTO", "trigger": "PRIMEIRO_MOMENTO_LIVRE_DISPONIVEL"}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:40 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05–05:40, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME PREPARACAO_ESCOLA** — 05:35 → 05:45–06:00 — Tomar banho, escovar os dentes, limpar os sapatos e vestir o uniforme. — **São 05:35. Das 05:45 às 06:00, prepara-te: toma banho, escova os dentes, limpa os sapatos e veste o uniforme.** — cumprimento monitorizado: SIM
- **ALARME ESCOLA** — 05:50 → 06:00 — Ir à escola. — **São 05:50. Às 06:00, vai à escola.** — cumprimento monitorizado: SIM
- **ALARME BANHO** — 16:35 → 16:45–17:00 — Tomar banho. — **São 16:35. Das 16:45 às 17:00, toma banho.** — cumprimento monitorizado: SIM
- **ALARME SONO** — 16:50 → 17:00–23:00 — Dormir. — **São 16:50. Das 17:00 às 23:00, dorme.** — cumprimento monitorizado: NÃO
- **ALARME ESTUDO** — 22:50 → 23:00–03:00 — Estudar HIST e GEO. Faz VID, Ex e GRAV. — **São 22:50. Das 23:00 às 03:00, estuda HIST e GEO. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO TPC_0520** — 05:20 — **Faz o T.P.C.** — condição `VALID`
- **EVENTO AUDIOS** — gatilho `SURGIU MOMENTO LIVRE NÃO DESTINADO AO T.P.C., À EXPLICAÇÃO, À EDUCAÇÃO FÍSICA OU AO SONO` — Escutar os áudios. — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — estado `AGUARDANDO`
- **ESTUDO:** HISTÓRIA — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** GEOGRAFIA — 14 páginas — VID, Ex, GRAV

## QUARTA-FEIRA
Escola=SIM | Explicação=NÃO | Educação Física=SIM | Lavagem=SIM | T.P.C.=SIM | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "EVENTO", "trigger": "PRIMEIRO_MOMENTO_LIVRE_DISPONIVEL"}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:40 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05–05:40, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME PREPARACAO_ESCOLA_E_PE** — 05:35 → 05:45–06:00 — Tomar banho, escovar os dentes, limpar os sapatos, vestir o uniforme e preparar o uniforme de Educação Física. — **São 05:35. Das 05:45 às 06:00, prepara-te: toma banho, escova os dentes, limpa os sapatos, veste o uniforme e prepara o uniforme de Educação Física.** — cumprimento monitorizado: SIM
- **ALARME ESCOLA** — 05:50 → 06:00 — Ir à escola. — **São 05:50. Às 06:00, vai à escola.** — cumprimento monitorizado: SIM
- **ALARME BANHO** — 16:35 → 16:45–17:00 — Tomar banho. — **São 16:35. Das 16:45 às 17:00, toma banho.** — cumprimento monitorizado: SIM
- **ALARME SONO** — 16:50 → 17:00–23:00 — Dormir. — **São 16:50. Das 17:00 às 23:00, dorme.** — cumprimento monitorizado: NÃO
- **ALARME ESTUDO** — 22:50 → 23:00–03:00 — Estudar INGL e BÍBLIA. Faz VID, Ex e GRAV em INGL e VID + GRAV em BÍBLIA. — **São 22:50. Das 23:00 às 03:00, estuda INGL e BÍBLIA. Faz VID, Ex e GRAV em INGL e VID + GRAV em BÍBLIA.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO TPC_0520** — 05:20 — **Faz o T.P.C.** — condição `VALID`
- **NOTIFICAÇÃO LAVAGEM** — 13:20 — **Lava o uniforme.** — condição `VALID`
- **EVENTO PE_RETORNO** — gatilho `RETORNO REAL DEPOIS DA EDUCAÇÃO FÍSICA` — Executar a rotina pós-Educação Física. — **Depois da Educação Física, volta para casa, busca o Guift, come se for necessário, trabalha, varre dentro de casa, garante o almoço da Melissa e do Guift quando estiverem presentes, garante as bacias de água e termina tudo até às 16:40.** — estado `AGUARDANDO`
- **EVENTO AUDIOS** — gatilho `SURGIU MOMENTO LIVRE NÃO DESTINADO AO T.P.C., À EXPLICAÇÃO, À EDUCAÇÃO FÍSICA OU AO SONO` — Escutar os áudios. — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — estado `AGUARDANDO`
- **ESTUDO:** INGLÊS — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** BÍBLIA — 17 páginas — VID + GRAV

## QUINTA-FEIRA
Escola=SIM | Explicação=NÃO | Educação Física=NÃO | Lavagem=NÃO | T.P.C.=SIM | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "EVENTO", "trigger": "PRIMEIRO_MOMENTO_LIVRE_DISPONIVEL"}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:40 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05–05:40, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME PREPARACAO_ESCOLA** — 05:35 → 05:45–06:00 — Tomar banho, escovar os dentes, limpar os sapatos e vestir o uniforme. — **São 05:35. Das 05:45 às 06:00, prepara-te: toma banho, escova os dentes, limpa os sapatos e veste o uniforme.** — cumprimento monitorizado: SIM
- **ALARME ESCOLA** — 05:50 → 06:00 — Ir à escola. — **São 05:50. Às 06:00, vai à escola.** — cumprimento monitorizado: SIM
- **ALARME BANHO** — 16:35 → 16:45–17:00 — Tomar banho. — **São 16:35. Das 16:45 às 17:00, toma banho.** — cumprimento monitorizado: SIM
- **ALARME SONO** — 16:50 → 17:00–23:00 — Dormir. — **São 16:50. Das 17:00 às 23:00, dorme.** — cumprimento monitorizado: NÃO
- **ALARME ESTUDO** — 22:50 → 23:00–03:00 — Estudar BIOL e EDV. Faz VID, Ex e GRAV. — **São 22:50. Das 23:00 às 03:00, estuda BIOL e EDV. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO TPC_0520** — 05:20 — **Faz o T.P.C.** — condição `VALID`
- **EVENTO AUDIOS** — gatilho `SURGIU MOMENTO LIVRE NÃO DESTINADO AO T.P.C., À EXPLICAÇÃO, À EDUCAÇÃO FÍSICA OU AO SONO` — Escutar os áudios. — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — estado `AGUARDANDO`
- **ESTUDO:** BIOLOGIA — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** EDV — 14 páginas — VID, Ex, GRAV

## SEXTA-FEIRA
Escola=SIM | Explicação=NÃO | Educação Física=NÃO | Lavagem=SIM | T.P.C.=SIM | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "EVENTO", "trigger": "PRIMEIRO_MOMENTO_LIVRE_DISPONIVEL"}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:40 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05–05:40, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME PREPARACAO_ESCOLA** — 05:35 → 05:45–06:00 — Tomar banho, escovar os dentes, limpar os sapatos e vestir o uniforme. — **São 05:35. Das 05:45 às 06:00, prepara-te: toma banho, escova os dentes, limpa os sapatos e veste o uniforme.** — cumprimento monitorizado: SIM
- **ALARME ESCOLA** — 05:50 → 06:00 — Ir à escola. — **São 05:50. Às 06:00, vai à escola.** — cumprimento monitorizado: SIM
- **ALARME BANHO** — 16:35 → 16:45–17:00 — Tomar banho. — **São 16:35. Das 16:45 às 17:00, toma banho.** — cumprimento monitorizado: SIM
- **ALARME SONO** — 16:50 → 17:00–23:00 — Dormir. — **São 16:50. Das 17:00 às 23:00, dorme.** — cumprimento monitorizado: NÃO
- **ALARME ESTUDO** — 22:50 → 23:00–03:00 — Estudar FRANCÊS e DÍCIO. Faz VID, Ex e GRAV. — **São 22:50. Das 23:00 às 03:00, estuda FRANCÊS e DÍCIO. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO TPC_0520** — 05:20 — **Faz o T.P.C.** — condição `VALID`
- **NOTIFICAÇÃO LAVAGEM** — 13:20 — **Lava o uniforme.** — condição `VALID`
- **EVENTO TPC_LIVRE** — gatilho `COMEÇOU O PERÍODO LIVRE` — Fazer o T.P.C. — **Faz o T.P.C.** — estado `AGUARDANDO`
- **EVENTO AUDIOS** — gatilho `SURGIU MOMENTO LIVRE NÃO DESTINADO AO T.P.C., À EXPLICAÇÃO, À EDUCAÇÃO FÍSICA OU AO SONO` — Escutar os áudios. — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — estado `AGUARDANDO`
- **ESTUDO:** FRANCÊS — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** DÍCIO — 15 páginas — VID, Ex, GRAV

## SÁBADO
Escola=SIM | Explicação=NÃO | Educação Física=NÃO | Lavagem=NÃO | T.P.C.=NÃO | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "FIXED_WINDOW_START", "time": "09:50", "window": ["09:50", "13:45"]}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:00 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05–05:00, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME PREPARACAO_ESCOLA** — 05:35 → 05:45–06:00 — Tomar banho, escovar os dentes, limpar os sapatos e vestir o uniforme. — **São 05:35. Das 05:45 às 06:00, prepara-te: toma banho, escova os dentes, limpa os sapatos e veste o uniforme.** — cumprimento monitorizado: SIM
- **ALARME ESCOLA** — 05:50 → 06:00 — Ir à escola. — **São 05:50. Às 06:00, vai à escola.** — cumprimento monitorizado: SIM
- **ALARME BANHO** — 16:35 → 16:45–17:00 — Tomar banho. — **São 16:35. Das 16:45 às 17:00, toma banho.** — cumprimento monitorizado: SIM
- **ALARME SONO** — 16:50 → 17:00–23:00 — Dormir. — **São 16:50. Das 17:00 às 23:00, dorme.** — cumprimento monitorizado: NÃO
- **ALARME ESTUDO** — 22:50 → 23:00–03:00 — Estudar AGRO e HOTWAV HYPER 7 PRO. Faz VID, Ex e GRAV em AGRO e realiza o material correspondente do ciclo em HOTWAV HYPER 7 PRO. — **São 22:50. Das 23:00 às 03:00, estuda AGRO e HOTWAV HYPER 7 PRO. Faz VID, Ex e GRAV em AGRO e realiza o material correspondente do ciclo em HOTWAV HYPER 7 PRO.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO AUDIOS** — 09:50 — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — condição `VALID`
- **TAREFA:** Organizar o quarto.
- **ESTUDO:** AGRO — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** HOTWAV HYPER 7 PRO — 0 páginas — material correspondente do ciclo

# CATEGORIA: SIM — 24 HORAS — TEMPORÁRIA

## DOMINGO
Escola=NÃO | Explicação=NÃO | Educação Física=NÃO APLICÁVEL | Lavagem=NÃO | T.P.C.=NÃO | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "FIXED_WINDOW_START", "time": "08:45", "window": ["08:45", "09:55"]}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:00 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05 às 05:00, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME LIVRE_MANHA** — 04:55 → 05:05–07:05 — Ficar livre. — **São 04:55. Das 05:05 às 07:05, fica livre.** — cumprimento monitorizado: NÃO
- **ALARME ORGANIZACAO** — 06:55 → 07:05–08:45 — Organizar o quarto e o interior, garantir o Matabixo + almoço para Guift e Melissa e colocar água nas bacias. — **São 06:55. Das 07:05 às 08:45, organiza o quarto e o interior, garante o Matabixo + almoço para Guift e Melissa e coloca água nas bacias.** — cumprimento monitorizado: SIM
- **ALARME SONO_NAO_ESCOLAR** — 09:45 → 09:55–17:45 — Dormir. — **São 09:45. Das 09:55 às 17:45, dorme.** — cumprimento monitorizado: NÃO
- **ALARME ACORDAR_NAO_ESCOLAR** — 17:35 → 17:45–18:45 — Acordar, tomar banho, escovar os dentes e garantir o uniforme engomado. — **São 17:35. Das 17:45 às 18:45, acorda, toma banho, escova os dentes e garante o uniforme engomado.** — cumprimento monitorizado: SIM
- **ALARME ESTUDO** — 18:35 → 18:45–03:00 — Estudar MAT e PORT. Faz VID, Ex e GRAV. — **São 18:35. Das 18:45 às 03:00, estuda MAT e PORT. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO AUDIOS** — 08:45 — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — condição `VALID`
- **TAREFA:** Organizar o quarto.
- **ESTUDO:** MATEMÁTICA — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** PORTUGUÊS — 14 páginas — VID, Ex, GRAV

## SEGUNDA-FEIRA
Escola=NÃO | Explicação=NÃO | Educação Física=NÃO APLICÁVEL | Lavagem=NÃO | T.P.C.=NÃO | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "FIXED_WINDOW_START", "time": "08:45", "window": ["08:45", "09:55"]}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:00 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05 às 05:00, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME LIVRE_MANHA** — 04:55 → 05:05–07:05 — Ficar livre. — **São 04:55. Das 05:05 às 07:05, fica livre.** — cumprimento monitorizado: NÃO
- **ALARME ORGANIZACAO** — 06:55 → 07:05–08:45 — Organizar o quarto e o interior, garantir o Matabixo + almoço para Guift e Melissa e colocar água nas bacias. — **São 06:55. Das 07:05 às 08:45, organiza o quarto e o interior, garante o Matabixo + almoço para Guift e Melissa e coloca água nas bacias.** — cumprimento monitorizado: SIM
- **ALARME SONO_NAO_ESCOLAR** — 09:45 → 09:55–17:45 — Dormir. — **São 09:45. Das 09:55 às 17:45, dorme.** — cumprimento monitorizado: NÃO
- **ALARME ACORDAR_NAO_ESCOLAR** — 17:35 → 17:45–18:45 — Acordar, tomar banho, escovar os dentes e garantir o uniforme engomado. — **São 17:35. Das 17:45 às 18:45, acorda, toma banho, escova os dentes e garante o uniforme engomado.** — cumprimento monitorizado: SIM
- **ALARME ESTUDO** — 18:35 → 18:45–03:00 — Estudar FIS e QUI. Faz VID, Ex e GRAV. — **São 18:35. Das 18:45 às 03:00, estuda FIS e QUI. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO AUDIOS** — 08:45 — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — condição `VALID`
- **ESTUDO:** FÍSICA — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** QUÍMICA — 14 páginas — VID, Ex, GRAV

## TERÇA-FEIRA
Escola=NÃO | Explicação=NÃO | Educação Física=NÃO APLICÁVEL | Lavagem=NÃO | T.P.C.=NÃO | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "FIXED_WINDOW_START", "time": "08:45", "window": ["08:45", "09:55"]}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:00 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05 às 05:00, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME LIVRE_MANHA** — 04:55 → 05:05–07:05 — Ficar livre. — **São 04:55. Das 05:05 às 07:05, fica livre.** — cumprimento monitorizado: NÃO
- **ALARME ORGANIZACAO** — 06:55 → 07:05–08:45 — Organizar o quarto e o interior, garantir o Matabixo + almoço para Guift e Melissa e colocar água nas bacias. — **São 06:55. Das 07:05 às 08:45, organiza o quarto e o interior, garante o Matabixo + almoço para Guift e Melissa e coloca água nas bacias.** — cumprimento monitorizado: SIM
- **ALARME SONO_NAO_ESCOLAR** — 09:45 → 09:55–17:45 — Dormir. — **São 09:45. Das 09:55 às 17:45, dorme.** — cumprimento monitorizado: NÃO
- **ALARME ACORDAR_NAO_ESCOLAR** — 17:35 → 17:45–18:45 — Acordar, tomar banho, escovar os dentes e garantir o uniforme engomado. — **São 17:35. Das 17:45 às 18:45, acorda, toma banho, escova os dentes e garante o uniforme engomado.** — cumprimento monitorizado: SIM
- **ALARME ESTUDO** — 18:35 → 18:45–03:00 — Estudar HIST e GEO. Faz VID, Ex e GRAV. — **São 18:35. Das 18:45 às 03:00, estuda HIST e GEO. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO AUDIOS** — 08:45 — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — condição `VALID`
- **ESTUDO:** HISTÓRIA — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** GEOGRAFIA — 14 páginas — VID, Ex, GRAV

## QUARTA-FEIRA
Escola=NÃO | Explicação=NÃO | Educação Física=NÃO APLICÁVEL | Lavagem=SIM | T.P.C.=NÃO | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "FIXED_WINDOW_START", "time": "08:45", "window": ["08:45", "09:55"]}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:00 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05 às 05:00, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME LIVRE_MANHA** — 04:55 → 05:05–07:05 — Ficar livre. — **São 04:55. Das 05:05 às 07:05, fica livre.** — cumprimento monitorizado: NÃO
- **ALARME ORGANIZACAO** — 06:55 → 07:05–08:45 — Organizar o quarto e o interior, garantir o Matabixo + almoço para Guift e Melissa e colocar água nas bacias. — **São 06:55. Das 07:05 às 08:45, organiza o quarto e o interior, garante o Matabixo + almoço para Guift e Melissa e coloca água nas bacias.** — cumprimento monitorizado: SIM
- **ALARME SONO_NAO_ESCOLAR** — 09:45 → 09:55–17:45 — Dormir. — **São 09:45. Das 09:55 às 17:45, dorme.** — cumprimento monitorizado: NÃO
- **ALARME ACORDAR_NAO_ESCOLAR** — 17:35 → 17:45–18:45 — Acordar, tomar banho, escovar os dentes e garantir o uniforme engomado. — **São 17:35. Das 17:45 às 18:45, acorda, toma banho, escova os dentes e garante o uniforme engomado.** — cumprimento monitorizado: SIM
- **ALARME ESTUDO** — 18:35 → 18:45–03:00 — Estudar INGL e BÍBLIA. Faz VID, Ex e GRAV em INGL e VID + GRAV em BÍBLIA. — **São 18:35. Das 18:45 às 03:00, estuda INGL e BÍBLIA. Faz VID, Ex e GRAV em INGL e VID + GRAV em BÍBLIA.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO LAVAGEM** — 09:00 — **Lava o uniforme.** — condição `VALID`
- **NOTIFICAÇÃO AUDIOS** — 08:45 — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — condição `VALID`
- **ESTUDO:** INGLÊS — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** BÍBLIA — 17 páginas — VID + GRAV

## QUINTA-FEIRA
Escola=NÃO | Explicação=NÃO | Educação Física=NÃO APLICÁVEL | Lavagem=NÃO | T.P.C.=NÃO | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "FIXED_WINDOW_START", "time": "08:45", "window": ["08:45", "09:55"]}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:00 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05 às 05:00, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME LIVRE_MANHA** — 04:55 → 05:05–07:05 — Ficar livre. — **São 04:55. Das 05:05 às 07:05, fica livre.** — cumprimento monitorizado: NÃO
- **ALARME ORGANIZACAO** — 06:55 → 07:05–08:45 — Organizar o quarto e o interior, garantir o Matabixo + almoço para Guift e Melissa e colocar água nas bacias. — **São 06:55. Das 07:05 às 08:45, organiza o quarto e o interior, garante o Matabixo + almoço para Guift e Melissa e coloca água nas bacias.** — cumprimento monitorizado: SIM
- **ALARME SONO_NAO_ESCOLAR** — 09:45 → 09:55–17:45 — Dormir. — **São 09:45. Das 09:55 às 17:45, dorme.** — cumprimento monitorizado: NÃO
- **ALARME ACORDAR_NAO_ESCOLAR** — 17:35 → 17:45–18:45 — Acordar, tomar banho, escovar os dentes e garantir o uniforme engomado. — **São 17:35. Das 17:45 às 18:45, acorda, toma banho, escova os dentes e garante o uniforme engomado.** — cumprimento monitorizado: SIM
- **ALARME ESTUDO** — 18:35 → 18:45–03:00 — Estudar BIOL e EDV. Faz VID, Ex e GRAV. — **São 18:35. Das 18:45 às 03:00, estuda BIOL e EDV. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO AUDIOS** — 08:45 — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — condição `VALID`
- **ESTUDO:** BIOLOGIA — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** EDV — 14 páginas — VID, Ex, GRAV

## SEXTA-FEIRA
Escola=NÃO | Explicação=NÃO | Educação Física=NÃO APLICÁVEL | Lavagem=SIM | T.P.C.=NÃO | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "FIXED_WINDOW_START", "time": "08:45", "window": ["08:45", "09:55"]}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:00 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05 às 05:00, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME LIVRE_MANHA** — 04:55 → 05:05–07:05 — Ficar livre. — **São 04:55. Das 05:05 às 07:05, fica livre.** — cumprimento monitorizado: NÃO
- **ALARME ORGANIZACAO** — 06:55 → 07:05–08:45 — Organizar o quarto e o interior, garantir o Matabixo + almoço para Guift e Melissa e colocar água nas bacias. — **São 06:55. Das 07:05 às 08:45, organiza o quarto e o interior, garante o Matabixo + almoço para Guift e Melissa e coloca água nas bacias.** — cumprimento monitorizado: SIM
- **ALARME SONO_NAO_ESCOLAR** — 09:45 → 09:55–17:45 — Dormir. — **São 09:45. Das 09:55 às 17:45, dorme.** — cumprimento monitorizado: NÃO
- **ALARME ACORDAR_NAO_ESCOLAR** — 17:35 → 17:45–18:45 — Acordar, tomar banho, escovar os dentes e garantir o uniforme engomado. — **São 17:35. Das 17:45 às 18:45, acorda, toma banho, escova os dentes e garante o uniforme engomado.** — cumprimento monitorizado: SIM
- **ALARME ESTUDO** — 18:35 → 18:45–03:00 — Estudar FRANCÊS e DÍCIO. Faz VID, Ex e GRAV. — **São 18:35. Das 18:45 às 03:00, estuda FRANCÊS e DÍCIO. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO LAVAGEM** — 09:00 — **Lava o uniforme.** — condição `VALID`
- **NOTIFICAÇÃO AUDIOS** — 08:45 — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — condição `VALID`
- **ESTUDO:** FRANCÊS — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** DÍCIO — 15 páginas — VID, Ex, GRAV

## SÁBADO
Escola=NÃO | Explicação=NÃO | Educação Física=NÃO APLICÁVEL | Lavagem=NÃO | T.P.C.=NÃO | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "FIXED_WINDOW_START", "time": "08:45", "window": ["08:45", "09:55"]}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:00 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05 às 05:00, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME LIVRE_MANHA** — 04:55 → 05:05–07:05 — Ficar livre. — **São 04:55. Das 05:05 às 07:05, fica livre.** — cumprimento monitorizado: NÃO
- **ALARME ORGANIZACAO** — 06:55 → 07:05–08:45 — Organizar o quarto e o interior, garantir o Matabixo + almoço para Guift e Melissa e colocar água nas bacias. — **São 06:55. Das 07:05 às 08:45, organiza o quarto e o interior, garante o Matabixo + almoço para Guift e Melissa e coloca água nas bacias.** — cumprimento monitorizado: SIM
- **ALARME SONO_NAO_ESCOLAR** — 09:45 → 09:55–17:45 — Dormir. — **São 09:45. Das 09:55 às 17:45, dorme.** — cumprimento monitorizado: NÃO
- **ALARME ACORDAR_NAO_ESCOLAR** — 17:35 → 17:45–18:45 — Acordar, tomar banho, escovar os dentes e garantir o uniforme engomado. — **São 17:35. Das 17:45 às 18:45, acorda, toma banho, escova os dentes e garante o uniforme engomado.** — cumprimento monitorizado: SIM
- **ALARME ESTUDO** — 18:35 → 18:45–03:00 — Estudar AGRO e HOTWAV HYPER 7 PRO. Faz VID, Ex e GRAV em AGRO e realiza o material correspondente do ciclo em HOTWAV HYPER 7 PRO. — **São 18:35. Das 18:45 às 03:00, estuda AGRO e HOTWAV HYPER 7 PRO. Faz VID, Ex e GRAV em AGRO e realiza o material correspondente do ciclo em HOTWAV HYPER 7 PRO.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO AUDIOS** — 08:45 — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — condição `VALID`
- **TAREFA:** Organizar o quarto.
- **ESTUDO:** AGRO — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** HOTWAV HYPER 7 PRO — 0 páginas — material correspondente do ciclo

# CATEGORIA: ESTOU DE FÉRIAS — PERMANENTE

## DOMINGO
Escola=NÃO | Explicação=NÃO | Educação Física=NÃO APLICÁVEL | Lavagem=NÃO | T.P.C.=NÃO | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "FIXED_WINDOW_START", "time": "08:45", "window": ["08:45", "09:55"]}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:00 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05 às 05:00, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME LIVRE_MANHA** — 04:55 → 05:05–07:05 — Ficar livre. — **São 04:55. Das 05:05 às 07:05, fica livre.** — cumprimento monitorizado: NÃO
- **ALARME ORGANIZACAO** — 06:55 → 07:05–08:45 — Organizar o quarto e o interior, garantir o Matabixo + almoço para Guift e Melissa e colocar água nas bacias. — **São 06:55. Das 07:05 às 08:45, organiza o quarto e o interior, garante o Matabixo + almoço para Guift e Melissa e coloca água nas bacias.** — cumprimento monitorizado: SIM
- **ALARME SONO_NAO_ESCOLAR** — 09:45 → 09:55–17:45 — Dormir. — **São 09:45. Das 09:55 às 17:45, dorme.** — cumprimento monitorizado: NÃO
- **ALARME ACORDAR_NAO_ESCOLAR** — 17:35 → 17:45–18:45 — Acordar, tomar banho, escovar os dentes e garantir o uniforme engomado. — **São 17:35. Das 17:45 às 18:45, acorda, toma banho, escova os dentes e garante o uniforme engomado.** — cumprimento monitorizado: SIM
- **ALARME ESTUDO** — 18:35 → 18:45–03:00 — Estudar MAT e PORT. Faz VID, Ex e GRAV. — **São 18:35. Das 18:45 às 03:00, estuda MAT e PORT. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO AUDIOS** — 08:45 — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — condição `VALID`
- **TAREFA:** Organizar o quarto.
- **ESTUDO:** MATEMÁTICA — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** PORTUGUÊS — 14 páginas — VID, Ex, GRAV

## SEGUNDA-FEIRA
Escola=NÃO | Explicação=NÃO | Educação Física=NÃO APLICÁVEL | Lavagem=NÃO | T.P.C.=NÃO | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "FIXED_WINDOW_START", "time": "08:45", "window": ["08:45", "09:55"]}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:00 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05 às 05:00, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME LIVRE_MANHA** — 04:55 → 05:05–07:05 — Ficar livre. — **São 04:55. Das 05:05 às 07:05, fica livre.** — cumprimento monitorizado: NÃO
- **ALARME ORGANIZACAO** — 06:55 → 07:05–08:45 — Organizar o quarto e o interior, garantir o Matabixo + almoço para Guift e Melissa e colocar água nas bacias. — **São 06:55. Das 07:05 às 08:45, organiza o quarto e o interior, garante o Matabixo + almoço para Guift e Melissa e coloca água nas bacias.** — cumprimento monitorizado: SIM
- **ALARME SONO_NAO_ESCOLAR** — 09:45 → 09:55–17:45 — Dormir. — **São 09:45. Das 09:55 às 17:45, dorme.** — cumprimento monitorizado: NÃO
- **ALARME ACORDAR_NAO_ESCOLAR** — 17:35 → 17:45–18:45 — Acordar, tomar banho, escovar os dentes e garantir o uniforme engomado. — **São 17:35. Das 17:45 às 18:45, acorda, toma banho, escova os dentes e garante o uniforme engomado.** — cumprimento monitorizado: SIM
- **ALARME ESTUDO** — 18:35 → 18:45–03:00 — Estudar FIS e QUI. Faz VID, Ex e GRAV. — **São 18:35. Das 18:45 às 03:00, estuda FIS e QUI. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO AUDIOS** — 08:45 — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — condição `VALID`
- **ESTUDO:** FÍSICA — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** QUÍMICA — 14 páginas — VID, Ex, GRAV

## TERÇA-FEIRA
Escola=NÃO | Explicação=NÃO | Educação Física=NÃO APLICÁVEL | Lavagem=NÃO | T.P.C.=NÃO | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "FIXED_WINDOW_START", "time": "08:45", "window": ["08:45", "09:55"]}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:00 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05 às 05:00, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME LIVRE_MANHA** — 04:55 → 05:05–07:05 — Ficar livre. — **São 04:55. Das 05:05 às 07:05, fica livre.** — cumprimento monitorizado: NÃO
- **ALARME ORGANIZACAO** — 06:55 → 07:05–08:45 — Organizar o quarto e o interior, garantir o Matabixo + almoço para Guift e Melissa e colocar água nas bacias. — **São 06:55. Das 07:05 às 08:45, organiza o quarto e o interior, garante o Matabixo + almoço para Guift e Melissa e coloca água nas bacias.** — cumprimento monitorizado: SIM
- **ALARME SONO_NAO_ESCOLAR** — 09:45 → 09:55–17:45 — Dormir. — **São 09:45. Das 09:55 às 17:45, dorme.** — cumprimento monitorizado: NÃO
- **ALARME ACORDAR_NAO_ESCOLAR** — 17:35 → 17:45–18:45 — Acordar, tomar banho, escovar os dentes e garantir o uniforme engomado. — **São 17:35. Das 17:45 às 18:45, acorda, toma banho, escova os dentes e garante o uniforme engomado.** — cumprimento monitorizado: SIM
- **ALARME ESTUDO** — 18:35 → 18:45–03:00 — Estudar HIST e GEO. Faz VID, Ex e GRAV. — **São 18:35. Das 18:45 às 03:00, estuda HIST e GEO. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO AUDIOS** — 08:45 — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — condição `VALID`
- **ESTUDO:** HISTÓRIA — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** GEOGRAFIA — 14 páginas — VID, Ex, GRAV

## QUARTA-FEIRA
Escola=NÃO | Explicação=NÃO | Educação Física=NÃO APLICÁVEL | Lavagem=SIM | T.P.C.=NÃO | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "FIXED_WINDOW_START", "time": "08:45", "window": ["08:45", "09:55"]}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:00 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05 às 05:00, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME LIVRE_MANHA** — 04:55 → 05:05–07:05 — Ficar livre. — **São 04:55. Das 05:05 às 07:05, fica livre.** — cumprimento monitorizado: NÃO
- **ALARME ORGANIZACAO** — 06:55 → 07:05–08:45 — Organizar o quarto e o interior, garantir o Matabixo + almoço para Guift e Melissa e colocar água nas bacias. — **São 06:55. Das 07:05 às 08:45, organiza o quarto e o interior, garante o Matabixo + almoço para Guift e Melissa e coloca água nas bacias.** — cumprimento monitorizado: SIM
- **ALARME SONO_NAO_ESCOLAR** — 09:45 → 09:55–17:45 — Dormir. — **São 09:45. Das 09:55 às 17:45, dorme.** — cumprimento monitorizado: NÃO
- **ALARME ACORDAR_NAO_ESCOLAR** — 17:35 → 17:45–18:45 — Acordar, tomar banho, escovar os dentes e garantir o uniforme engomado. — **São 17:35. Das 17:45 às 18:45, acorda, toma banho, escova os dentes e garante o uniforme engomado.** — cumprimento monitorizado: SIM
- **ALARME ESTUDO** — 18:35 → 18:45–03:00 — Estudar INGL e BÍBLIA. Faz VID, Ex e GRAV em INGL e VID + GRAV em BÍBLIA. — **São 18:35. Das 18:45 às 03:00, estuda INGL e BÍBLIA. Faz VID, Ex e GRAV em INGL e VID + GRAV em BÍBLIA.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO LAVAGEM** — 09:00 — **Lava o uniforme.** — condição `VALID`
- **NOTIFICAÇÃO AUDIOS** — 08:45 — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — condição `VALID`
- **ESTUDO:** INGLÊS — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** BÍBLIA — 17 páginas — VID + GRAV

## QUINTA-FEIRA
Escola=NÃO | Explicação=NÃO | Educação Física=NÃO APLICÁVEL | Lavagem=NÃO | T.P.C.=NÃO | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "FIXED_WINDOW_START", "time": "08:45", "window": ["08:45", "09:55"]}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:00 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05 às 05:00, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME LIVRE_MANHA** — 04:55 → 05:05–07:05 — Ficar livre. — **São 04:55. Das 05:05 às 07:05, fica livre.** — cumprimento monitorizado: NÃO
- **ALARME ORGANIZACAO** — 06:55 → 07:05–08:45 — Organizar o quarto e o interior, garantir o Matabixo + almoço para Guift e Melissa e colocar água nas bacias. — **São 06:55. Das 07:05 às 08:45, organiza o quarto e o interior, garante o Matabixo + almoço para Guift e Melissa e coloca água nas bacias.** — cumprimento monitorizado: SIM
- **ALARME SONO_NAO_ESCOLAR** — 09:45 → 09:55–17:45 — Dormir. — **São 09:45. Das 09:55 às 17:45, dorme.** — cumprimento monitorizado: NÃO
- **ALARME ACORDAR_NAO_ESCOLAR** — 17:35 → 17:45–18:45 — Acordar, tomar banho, escovar os dentes e garantir o uniforme engomado. — **São 17:35. Das 17:45 às 18:45, acorda, toma banho, escova os dentes e garante o uniforme engomado.** — cumprimento monitorizado: SIM
- **ALARME ESTUDO** — 18:35 → 18:45–03:00 — Estudar BIOL e EDV. Faz VID, Ex e GRAV. — **São 18:35. Das 18:45 às 03:00, estuda BIOL e EDV. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO AUDIOS** — 08:45 — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — condição `VALID`
- **ESTUDO:** BIOLOGIA — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** EDV — 14 páginas — VID, Ex, GRAV

## SEXTA-FEIRA
Escola=NÃO | Explicação=NÃO | Educação Física=NÃO APLICÁVEL | Lavagem=SIM | T.P.C.=NÃO | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "FIXED_WINDOW_START", "time": "08:45", "window": ["08:45", "09:55"]}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:00 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05 às 05:00, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME LIVRE_MANHA** — 04:55 → 05:05–07:05 — Ficar livre. — **São 04:55. Das 05:05 às 07:05, fica livre.** — cumprimento monitorizado: NÃO
- **ALARME ORGANIZACAO** — 06:55 → 07:05–08:45 — Organizar o quarto e o interior, garantir o Matabixo + almoço para Guift e Melissa e colocar água nas bacias. — **São 06:55. Das 07:05 às 08:45, organiza o quarto e o interior, garante o Matabixo + almoço para Guift e Melissa e coloca água nas bacias.** — cumprimento monitorizado: SIM
- **ALARME SONO_NAO_ESCOLAR** — 09:45 → 09:55–17:45 — Dormir. — **São 09:45. Das 09:55 às 17:45, dorme.** — cumprimento monitorizado: NÃO
- **ALARME ACORDAR_NAO_ESCOLAR** — 17:35 → 17:45–18:45 — Acordar, tomar banho, escovar os dentes e garantir o uniforme engomado. — **São 17:35. Das 17:45 às 18:45, acorda, toma banho, escova os dentes e garante o uniforme engomado.** — cumprimento monitorizado: SIM
- **ALARME ESTUDO** — 18:35 → 18:45–03:00 — Estudar FRANCÊS e DÍCIO. Faz VID, Ex e GRAV. — **São 18:35. Das 18:45 às 03:00, estuda FRANCÊS e DÍCIO. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO LAVAGEM** — 09:00 — **Lava o uniforme.** — condição `VALID`
- **NOTIFICAÇÃO AUDIOS** — 08:45 — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — condição `VALID`
- **ESTUDO:** FRANCÊS — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** DÍCIO — 15 páginas — VID, Ex, GRAV

## SÁBADO
Escola=NÃO | Explicação=NÃO | Educação Física=NÃO APLICÁVEL | Lavagem=NÃO | T.P.C.=NÃO | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "FIXED_WINDOW_START", "time": "08:45", "window": ["08:45", "09:55"]}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:00 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05 às 05:00, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME LIVRE_MANHA** — 04:55 → 05:05–07:05 — Ficar livre. — **São 04:55. Das 05:05 às 07:05, fica livre.** — cumprimento monitorizado: NÃO
- **ALARME ORGANIZACAO** — 06:55 → 07:05–08:45 — Organizar o quarto e o interior, garantir o Matabixo + almoço para Guift e Melissa e colocar água nas bacias. — **São 06:55. Das 07:05 às 08:45, organiza o quarto e o interior, garante o Matabixo + almoço para Guift e Melissa e coloca água nas bacias.** — cumprimento monitorizado: SIM
- **ALARME SONO_NAO_ESCOLAR** — 09:45 → 09:55–17:45 — Dormir. — **São 09:45. Das 09:55 às 17:45, dorme.** — cumprimento monitorizado: NÃO
- **ALARME ACORDAR_NAO_ESCOLAR** — 17:35 → 17:45–18:45 — Acordar, tomar banho, escovar os dentes e garantir o uniforme engomado. — **São 17:35. Das 17:45 às 18:45, acorda, toma banho, escova os dentes e garante o uniforme engomado.** — cumprimento monitorizado: SIM
- **ALARME ESTUDO** — 18:35 → 18:45–03:00 — Estudar AGRO e HOTWAV HYPER 7 PRO. Faz VID, Ex e GRAV em AGRO e realiza o material correspondente do ciclo em HOTWAV HYPER 7 PRO. — **São 18:35. Das 18:45 às 03:00, estuda AGRO e HOTWAV HYPER 7 PRO. Faz VID, Ex e GRAV em AGRO e realiza o material correspondente do ciclo em HOTWAV HYPER 7 PRO.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO AUDIOS** — 08:45 — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — condição `VALID`
- **TAREFA:** Organizar o quarto.
- **ESTUDO:** AGRO — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** HOTWAV HYPER 7 PRO — 0 páginas — material correspondente do ciclo

# CATEGORIA: AGORA VOU À EXPLICAÇÃO — PERMANENTE

## DOMINGO
Escola=NÃO | Explicação=NÃO | Educação Física=NÃO APLICÁVEL | Lavagem=NÃO | T.P.C.=NÃO | **ÁUDIOS=SIM** | Igreja=SIM | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "EVENTO", "trigger": "RETORNO_REAL_DA_IGREJA_E_MOMENTO_LIVRE"}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:00 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05 às 05:00, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME PREPARACAO_IGREJA** — 04:55 → 05:05–05:45 — Tomar banho, escovar os dentes, limpar os sapatos e vestir-se. — **São 04:55. Das 05:05 às 05:45, prepara-te: toma banho, escova os dentes, limpa os sapatos e veste-te.** — cumprimento monitorizado: SIM
- **ALARME ACORDAR_NOITE** — 19:50 → 20:00–20:25 — Acordar, tomar banho e vestir-se. — **São 19:50. Das 20:00 às 20:25, acorda, toma banho e veste-te.** — cumprimento monitorizado: SIM
- **ALARME ESTUDO** — 20:15 → 20:25–03:00 — Estudar MAT e PORT. Faz VID, Ex e GRAV. — **São 20:15. Das 20:25 às 03:00, estuda MAT e PORT. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **EVENTO IGREJA_IDA** — gatilho `PREPARAÇÃO TERMINADA` — Ir à igreja no momento certo. — **Termina de te preparar e vai à igreja no momento certo.** — estado `AGUARDANDO`
- **EVENTO IGREJA_RETORNO** — gatilho `RETORNO REAL DA IGREJA` — Dormir. — **Volta da igreja e dorme.** — estado `AGUARDANDO`
- **EVENTO AUDIOS** — gatilho `RETORNO REAL DA IGREJA + SURGIU MOMENTO LIVRE ANTES DO PRÓXIMO BLOCO FIXO` — Escutar os áudios. — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — estado `AGUARDANDO`
- **TAREFA:** Organizar o quarto.
- **ESTUDO:** MATEMÁTICA — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** PORTUGUÊS — 14 páginas — VID, Ex, GRAV

## SEGUNDA-FEIRA
Escola=SIM | Explicação=SIM | Educação Física=NÃO | Lavagem=NÃO | T.P.C.=SIM | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "EVENTO", "trigger": "PRIMEIRO_MOMENTO_LIVRE_DISPONIVEL"}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:40 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05–05:40, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME PREPARACAO_ESCOLA** — 05:35 → 05:45–06:00 — Tomar banho, escovar os dentes, limpar os sapatos e vestir o uniforme. — **São 05:35. Das 05:45 às 06:00, prepara-te: toma banho, escova os dentes, limpa os sapatos e veste o uniforme.** — cumprimento monitorizado: SIM
- **ALARME ESCOLA** — 05:50 → 06:00 — Ir à escola. — **São 05:50. Às 06:00, vai à escola.** — cumprimento monitorizado: SIM
- **ALARME SONO** — 13:35 → 13:45–15:40 — Dormir. — **São 13:35. Das 13:45 às 15:40, dorme.** — cumprimento monitorizado: NÃO
- **ALARME PREP_EXPLICACAO** — 15:40 → 15:50–16:00 — Preparar-te para a explicação. — **São 15:40. Das 15:50 às 16:00, prepara-te para a explicação.** — cumprimento monitorizado: SIM
- **ALARME EXPLICACAO** — 15:50 → 16:00–fim — Ir à explicação e participar até ao seu término. — **São 15:50. Às 16:00, vai à explicação e participa até ao seu término.** — cumprimento monitorizado: NÃO
- **ALARME ESTUDO** — 22:15 → 22:25–03:00 — Estudar FIS e QUI. Faz VID, Ex e GRAV. — **São 22:15. Das 22:25 às 03:00, estuda FIS e QUI. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO TPC_0520** — 05:20 — **Faz o T.P.C.** — condição `VALID`
- **NOTIFICAÇÃO EXPLICACAO_1750** — 17:50 — **Não te esqueças: dorme depois da explicação.** — condição `EXPLICACAO_TERMINADA`
- **NOTIFICAÇÃO EXPLICACAO_1810** — 18:10 — **Dorme imediatamente.** — condição `EXPLICACAO_TERMINADA`
- **EVENTO EXPLICACAO_FIM** — gatilho `EXPLICAÇÃO TERMINOU` — Marcar explicação terminada e liberar pendências. — **Quando a explicação terminar, marca EXPLICAÇÃO TERMINADA e executa as pendências válidas.** — estado `AGUARDANDO`
- **EVENTO AUDIOS** — gatilho `SURGIU MOMENTO LIVRE NA ESCOLA NÃO DESTINADO AO T.P.C., À EDUCAÇÃO FÍSICA OU À EXPLICAÇÃO` — Escutar os áudios. — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — estado `AGUARDANDO`
- **ESTUDO:** FÍSICA — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** QUÍMICA — 14 páginas — VID, Ex, GRAV

## TERÇA-FEIRA
Escola=SIM | Explicação=SIM | Educação Física=NÃO | Lavagem=NÃO | T.P.C.=SIM | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "EVENTO", "trigger": "PRIMEIRO_MOMENTO_LIVRE_DISPONIVEL"}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:40 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05–05:40, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME PREPARACAO_ESCOLA** — 05:35 → 05:45–06:00 — Tomar banho, escovar os dentes, limpar os sapatos e vestir o uniforme. — **São 05:35. Das 05:45 às 06:00, prepara-te: toma banho, escova os dentes, limpa os sapatos e veste o uniforme.** — cumprimento monitorizado: SIM
- **ALARME ESCOLA** — 05:50 → 06:00 — Ir à escola. — **São 05:50. Às 06:00, vai à escola.** — cumprimento monitorizado: SIM
- **ALARME SONO** — 13:35 → 13:45–15:40 — Dormir. — **São 13:35. Das 13:45 às 15:40, dorme.** — cumprimento monitorizado: NÃO
- **ALARME PREP_EXPLICACAO** — 15:40 → 15:50–16:00 — Preparar-te para a explicação. — **São 15:40. Das 15:50 às 16:00, prepara-te para a explicação.** — cumprimento monitorizado: SIM
- **ALARME EXPLICACAO** — 15:50 → 16:00–fim — Ir à explicação e participar até ao seu término. — **São 15:50. Às 16:00, vai à explicação e participa até ao seu término.** — cumprimento monitorizado: NÃO
- **ALARME ESTUDO** — 22:15 → 22:25–03:00 — Estudar HIST e GEO. Faz VID, Ex e GRAV. — **São 22:15. Das 22:25 às 03:00, estuda HIST e GEO. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO TPC_0520** — 05:20 — **Faz o T.P.C.** — condição `VALID`
- **NOTIFICAÇÃO EXPLICACAO_1750** — 17:50 — **Não te esqueças: dorme depois da explicação.** — condição `EXPLICACAO_TERMINADA`
- **NOTIFICAÇÃO EXPLICACAO_1810** — 18:10 — **Dorme imediatamente.** — condição `EXPLICACAO_TERMINADA`
- **EVENTO EXPLICACAO_FIM** — gatilho `EXPLICAÇÃO TERMINOU` — Marcar explicação terminada e liberar pendências. — **Quando a explicação terminar, marca EXPLICAÇÃO TERMINADA e executa as pendências válidas.** — estado `AGUARDANDO`
- **EVENTO AUDIOS** — gatilho `SURGIU MOMENTO LIVRE NA ESCOLA NÃO DESTINADO AO T.P.C., À EDUCAÇÃO FÍSICA OU À EXPLICAÇÃO` — Escutar os áudios. — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — estado `AGUARDANDO`
- **ESTUDO:** HISTÓRIA — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** GEOGRAFIA — 14 páginas — VID, Ex, GRAV

## QUARTA-FEIRA
Escola=SIM | Explicação=SIM | Educação Física=SIM | Lavagem=SIM | T.P.C.=SIM | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "EVENTO", "trigger": "PRIMEIRO_MOMENTO_LIVRE_DISPONIVEL"}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:40 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05–05:40, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME PREPARACAO_ESCOLA_E_PE** — 05:35 → 05:45–06:00 — Tomar banho, escovar os dentes, limpar os sapatos, vestir o uniforme e preparar o uniforme de Educação Física. — **São 05:35. Das 05:45 às 06:00, prepara-te: toma banho, escova os dentes, limpa os sapatos, veste o uniforme e prepara o uniforme de Educação Física.** — cumprimento monitorizado: SIM
- **ALARME ESCOLA** — 05:50 → 06:00 — Ir à escola. — **São 05:50. Às 06:00, vai à escola.** — cumprimento monitorizado: SIM
- **ALARME SONO** — 13:35 → 13:45–15:40 — Dormir. — **São 13:35. Das 13:45 às 15:40, dorme.** — cumprimento monitorizado: NÃO
- **ALARME PREP_EXPLICACAO** — 15:40 → 15:50–16:00 — Preparar-te para a explicação. — **São 15:40. Das 15:50 às 16:00, prepara-te para a explicação.** — cumprimento monitorizado: SIM
- **ALARME EXPLICACAO** — 15:50 → 16:00–fim — Ir à explicação e participar até ao seu término. — **São 15:50. Às 16:00, vai à explicação e participa até ao seu término.** — cumprimento monitorizado: NÃO
- **ALARME ESTUDO** — 22:15 → 22:25–03:00 — Estudar INGL e BÍBLIA. Faz VID, Ex e GRAV em INGL e VID + GRAV em BÍBLIA. — **São 22:15. Das 22:25 às 03:00, estuda INGL e BÍBLIA. Faz VID, Ex e GRAV em INGL e VID + GRAV em BÍBLIA.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO TPC_0520** — 05:20 — **Faz o T.P.C.** — condição `VALID`
- **NOTIFICAÇÃO LAVAGEM** — 13:20 — **Lava o uniforme.** — condição `VALID`
- **NOTIFICAÇÃO EXPLICACAO_1750** — 17:50 — **Não te esqueças: dorme depois da explicação.** — condição `EXPLICACAO_TERMINADA`
- **NOTIFICAÇÃO EXPLICACAO_1810** — 18:10 — **Dorme imediatamente.** — condição `EXPLICACAO_TERMINADA`
- **EVENTO EXPLICACAO_FIM** — gatilho `EXPLICAÇÃO TERMINOU` — Marcar explicação terminada e liberar pendências. — **Quando a explicação terminar, marca EXPLICAÇÃO TERMINADA e executa as pendências válidas.** — estado `AGUARDANDO`
- **EVENTO PE_RETORNO** — gatilho `RETORNO REAL DEPOIS DA EDUCAÇÃO FÍSICA` — Rotina pós-Educação Física. — **Depois da Educação Física, volta para casa, busca o Guift, come se for necessário, trabalha, varre dentro de casa, garante o almoço da Melissa e do Guift quando estiverem presentes, garante as bacias de água e termina tudo até às 16:40.** — estado `SUSPENSO`
- **EVENTO AUDIOS** — gatilho `SURGIU MOMENTO LIVRE NA ESCOLA NÃO DESTINADO AO T.P.C., À EDUCAÇÃO FÍSICA OU À EXPLICAÇÃO` — Escutar os áudios. — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — estado `AGUARDANDO`
- **ESTUDO:** INGLÊS — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** BÍBLIA — 17 páginas — VID + GRAV

## QUINTA-FEIRA
Escola=SIM | Explicação=SIM | Educação Física=NÃO | Lavagem=NÃO | T.P.C.=SIM | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "EVENTO", "trigger": "PRIMEIRO_MOMENTO_LIVRE_DISPONIVEL"}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:40 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05–05:40, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME PREPARACAO_ESCOLA** — 05:35 → 05:45–06:00 — Tomar banho, escovar os dentes, limpar os sapatos e vestir o uniforme. — **São 05:35. Das 05:45 às 06:00, prepara-te: toma banho, escova os dentes, limpa os sapatos e veste o uniforme.** — cumprimento monitorizado: SIM
- **ALARME ESCOLA** — 05:50 → 06:00 — Ir à escola. — **São 05:50. Às 06:00, vai à escola.** — cumprimento monitorizado: SIM
- **ALARME SONO** — 13:35 → 13:45–15:40 — Dormir. — **São 13:35. Das 13:45 às 15:40, dorme.** — cumprimento monitorizado: NÃO
- **ALARME PREP_EXPLICACAO** — 15:40 → 15:50–16:00 — Preparar-te para a explicação. — **São 15:40. Das 15:50 às 16:00, prepara-te para a explicação.** — cumprimento monitorizado: SIM
- **ALARME EXPLICACAO** — 15:50 → 16:00–fim — Ir à explicação e participar até ao seu término. — **São 15:50. Às 16:00, vai à explicação e participa até ao seu término.** — cumprimento monitorizado: NÃO
- **ALARME ESTUDO** — 22:50 → 23:00–03:00 — Estudar BIOL e EDV. Faz VID, Ex e GRAV. — **São 22:50. Das 23:00 às 03:00, estuda BIOL e EDV. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO TPC_0520** — 05:20 — **Faz o T.P.C.** — condição `VALID`
- **NOTIFICAÇÃO EXPLICACAO_1750** — 17:50 — **Não te esqueças: dorme depois da explicação.** — condição `EXPLICACAO_TERMINADA`
- **NOTIFICAÇÃO EXPLICACAO_1810** — 18:10 — **Dorme imediatamente.** — condição `EXPLICACAO_TERMINADA`
- **EVENTO EXPLICACAO_FIM** — gatilho `EXPLICAÇÃO TERMINOU` — Marcar explicação terminada e liberar pendências. — **Quando a explicação terminar, marca EXPLICAÇÃO TERMINADA e executa as pendências válidas.** — estado `AGUARDANDO`
- **EVENTO AUDIOS** — gatilho `SURGIU MOMENTO LIVRE NA ESCOLA NÃO DESTINADO AO T.P.C., À EDUCAÇÃO FÍSICA OU À EXPLICAÇÃO` — Escutar os áudios. — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — estado `AGUARDANDO`
- **ESTUDO:** BIOLOGIA — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** EDV — 14 páginas — VID, Ex, GRAV

## SEXTA-FEIRA
Escola=SIM | Explicação=SIM | Educação Física=NÃO | Lavagem=SIM | T.P.C.=SIM | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "EVENTO", "trigger": "PRIMEIRO_MOMENTO_LIVRE_DISPONIVEL"}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:40 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05–05:40, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME PREPARACAO_ESCOLA** — 05:35 → 05:45–06:00 — Tomar banho, escovar os dentes, limpar os sapatos e vestir o uniforme. — **São 05:35. Das 05:45 às 06:00, prepara-te: toma banho, escova os dentes, limpa os sapatos e veste o uniforme.** — cumprimento monitorizado: SIM
- **ALARME ESCOLA** — 05:50 → 06:00 — Ir à escola. — **São 05:50. Às 06:00, vai à escola.** — cumprimento monitorizado: SIM
- **ALARME SONO** — 13:35 → 13:45–15:40 — Dormir. — **São 13:35. Das 13:45 às 15:40, dorme.** — cumprimento monitorizado: NÃO
- **ALARME PREP_EXPLICACAO** — 15:40 → 15:50–16:00 — Preparar-te para a explicação. — **São 15:40. Das 15:50 às 16:00, prepara-te para a explicação.** — cumprimento monitorizado: SIM
- **ALARME EXPLICACAO** — 15:50 → 16:00–fim — Ir à explicação e participar até ao seu término. — **São 15:50. Às 16:00, vai à explicação e participa até ao seu término.** — cumprimento monitorizado: NÃO
- **ALARME ESTUDO** — 22:15 → 22:25–03:00 — Estudar FRANCÊS e DÍCIO. Faz VID, Ex e GRAV. — **São 22:15. Das 22:25 às 03:00, estuda FRANCÊS e DÍCIO. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO TPC_0520** — 05:20 — **Faz o T.P.C.** — condição `VALID`
- **NOTIFICAÇÃO LAVAGEM** — 13:20 — **Lava o uniforme.** — condição `VALID`
- **NOTIFICAÇÃO EXPLICACAO_1750** — 17:50 — **Não te esqueças: dorme depois da explicação.** — condição `EXPLICACAO_TERMINADA`
- **NOTIFICAÇÃO EXPLICACAO_1810** — 18:10 — **Dorme imediatamente.** — condição `EXPLICACAO_TERMINADA`
- **EVENTO EXPLICACAO_FIM** — gatilho `EXPLICAÇÃO TERMINOU` — Marcar explicação terminada e liberar pendências. — **Quando a explicação terminar, marca EXPLICAÇÃO TERMINADA e executa as pendências válidas.** — estado `AGUARDANDO`
- **EVENTO AUDIOS** — gatilho `SURGIU MOMENTO LIVRE NA ESCOLA NÃO DESTINADO AO T.P.C., À EDUCAÇÃO FÍSICA OU À EXPLICAÇÃO` — Escutar os áudios. — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — estado `AGUARDANDO`
- **EVENTO TPC_LIVRE** — gatilho `COMEÇOU O PERÍODO LIVRE` — Fazer o T.P.C. — **Faz o T.P.C.** — estado `AGUARDANDO`
- **ESTUDO:** FRANCÊS — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** DÍCIO — 15 páginas — VID, Ex, GRAV

## SÁBADO
Escola=SIM | Explicação=NÃO | Educação Física=NÃO | Lavagem=NÃO | T.P.C.=NÃO | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "FIXED_WINDOW_START", "time": "09:50", "window": ["09:50", "13:45"]}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:00 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05–05:00, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME PREPARACAO_ESCOLA** — 05:35 → 05:45–06:00 — Tomar banho, escovar os dentes, limpar os sapatos e vestir-se. — **São 05:35. Das 05:45 às 06:00, prepara-te: toma banho, escova os dentes, limpa os sapatos e veste-te.** — cumprimento monitorizado: SIM
- **ALARME ESCOLA** — 05:50 → 06:00 — Ir à escola. — **São 05:50. Às 06:00, vai à escola.** — cumprimento monitorizado: SIM
- **ALARME SONO_ESCOLAR** — 13:35 → 13:45–20:00 — Dormir. — **São 13:35. Das 13:45 às 20:00, dorme.** — cumprimento monitorizado: NÃO
- **ALARME ACORDAR** — 19:50 → 20:00–20:25 — Acordar, tomar banho e vestir-se. — **São 19:50. Das 20:00 às 20:25, acorda, toma banho e veste-te.** — cumprimento monitorizado: SIM
- **ALARME ESTUDO** — 20:15 → 20:25–03:00 — Estudar AGRO e HOTWAV HYPER 7 PRO. Faz VID, Ex e GRAV em AGRO e realiza o material correspondente do ciclo em HOTWAV HYPER 7 PRO. — **São 20:15. Das 20:25 às 03:00, estuda AGRO e HOTWAV HYPER 7 PRO. Faz VID, Ex e GRAV em AGRO e realiza o material correspondente do ciclo em HOTWAV HYPER 7 PRO.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO AUDIOS** — 09:50 — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — condição `VALID`
- **TAREFA:** Organizar o quarto.
- **ESTUDO:** AGRO — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** HOTWAV HYPER 7 PRO — 0 páginas — material correspondente do ciclo

# CATEGORIA: NÃO FUI À ESCOLA, MAS VOU À EXPLICAÇÃO — 24 HORAS — TEMPORÁRIA

## DOMINGO
Escola=NÃO | Explicação=NÃO | Educação Física=NÃO APLICÁVEL | Lavagem=NÃO | T.P.C.=NÃO | **ÁUDIOS=SIM** | Igreja=SIM | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "EVENTO", "trigger": "RETORNO_REAL_DA_IGREJA_E_MOMENTO_LIVRE"}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:00 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05 às 05:00, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME PREPARACAO_IGREJA** — 04:55 → 05:05–05:45 — Tomar banho, escovar os dentes, limpar os sapatos e vestir-se. — **São 04:55. Das 05:05 às 05:45, prepara-te: toma banho, escova os dentes, limpa os sapatos e veste-te.** — cumprimento monitorizado: SIM
- **ALARME ACORDAR_NOITE** — 19:50 → 20:00–20:25 — Acordar, tomar banho e vestir-se. — **São 19:50. Das 20:00 às 20:25, acorda, toma banho e veste-te.** — cumprimento monitorizado: SIM
- **ALARME ESTUDO** — 20:15 → 20:25–03:00 — Estudar MAT e PORT. Faz VID, Ex e GRAV. — **São 20:15. Das 20:25 às 03:00, estuda MAT e PORT. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **EVENTO IGREJA_IDA** — gatilho `PREPARAÇÃO TERMINADA` — Ir à igreja no momento certo. — **Termina de te preparar e vai à igreja no momento certo.** — estado `AGUARDANDO`
- **EVENTO IGREJA_RETORNO** — gatilho `RETORNO REAL DA IGREJA` — Dormir. — **Volta da igreja e dorme.** — estado `AGUARDANDO`
- **EVENTO AUDIOS** — gatilho `RETORNO REAL DA IGREJA + SURGIU MOMENTO LIVRE ANTES DO PRÓXIMO BLOCO FIXO` — Escutar os áudios. — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — estado `AGUARDANDO`
- **TAREFA:** Organizar o quarto.
- **ESTUDO:** MATEMÁTICA — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** PORTUGUÊS — 14 páginas — VID, Ex, GRAV

## SEGUNDA-FEIRA
Escola=NÃO | Explicação=SIM | Educação Física=NÃO | Lavagem=NÃO | T.P.C.=NÃO | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "FIXED_WINDOW_START", "time": "08:45", "window": ["08:45", "09:55"]}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:00 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05 às 05:00, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME LIVRE_MANHA** — 04:55 → 05:05–07:05 — Ficar livre. — **São 04:55. Das 05:05 às 07:05, fica livre.** — cumprimento monitorizado: SIM
- **ALARME ORGANIZACAO** — 06:55 → 07:05–08:45 — Organizar o quarto e o interior, garantir o Matabixo + almoço para Guift e Melissa e colocar água nas bacias. — **São 06:55. Das 07:05 às 08:45, organiza o quarto e o interior, garante o Matabixo + almoço para Guift e Melissa e coloca água nas bacias.** — cumprimento monitorizado: SIM
- **ALARME SONO** — 09:45 → 09:55–15:40 — Dormir. — **São 09:45. Das 09:55 às 15:40, dorme.** — cumprimento monitorizado: SIM
- **ALARME PREP_EXPLICACAO** — 15:40 → 15:50–16:00 — Preparar-te para a explicação. — **São 15:40. Das 15:50 às 16:00, prepara-te para a explicação.** — cumprimento monitorizado: SIM
- **ALARME EXPLICACAO** — 15:50 → 16:00–fim — Ir à explicação e participar até ao seu término. — **São 15:50. Às 16:00, vai à explicação e participa até ao seu término.** — cumprimento monitorizado: NÃO
- **ALARME ESTUDO** — 22:15 → 22:25–03:00 — Estudar FIS e QUI. Faz VID, Ex e GRAV. — **São 22:15. Das 22:25 às 03:00, estuda FIS e QUI. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO EXPLICACAO_1750** — 17:50 — **Não te esqueças: dorme depois da explicação.** — condição `EXPLICACAO_TERMINADA`
- **NOTIFICAÇÃO EXPLICACAO_1810** — 18:10 — **Dorme imediatamente.** — condição `EXPLICACAO_TERMINADA`
- **NOTIFICAÇÃO AUDIOS** — 08:45 — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — condição `VALID`
- **EVENTO EXPLICACAO_FIM** — gatilho `EXPLICAÇÃO TERMINOU` — Marcar explicação terminada e liberar pendências. — **Quando a explicação terminar, marca EXPLICAÇÃO TERMINADA e executa as pendências válidas.** — estado `AGUARDANDO`
- **ESTUDO:** FÍSICA — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** QUÍMICA — 14 páginas — VID, Ex, GRAV

## TERÇA-FEIRA
Escola=NÃO | Explicação=SIM | Educação Física=NÃO | Lavagem=NÃO | T.P.C.=NÃO | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "FIXED_WINDOW_START", "time": "08:45", "window": ["08:45", "09:55"]}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:00 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05 às 05:00, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME LIVRE_MANHA** — 04:55 → 05:05–07:05 — Ficar livre. — **São 04:55. Das 05:05 às 07:05, fica livre.** — cumprimento monitorizado: SIM
- **ALARME ORGANIZACAO** — 06:55 → 07:05–08:45 — Organizar o quarto e o interior, garantir o Matabixo + almoço para Guift e Melissa e colocar água nas bacias. — **São 06:55. Das 07:05 às 08:45, organiza o quarto e o interior, garante o Matabixo + almoço para Guift e Melissa e coloca água nas bacias.** — cumprimento monitorizado: SIM
- **ALARME SONO** — 09:45 → 09:55–15:40 — Dormir. — **São 09:45. Das 09:55 às 15:40, dorme.** — cumprimento monitorizado: SIM
- **ALARME PREP_EXPLICACAO** — 15:40 → 15:50–16:00 — Preparar-te para a explicação. — **São 15:40. Das 15:50 às 16:00, prepara-te para a explicação.** — cumprimento monitorizado: SIM
- **ALARME EXPLICACAO** — 15:50 → 16:00–fim — Ir à explicação e participar até ao seu término. — **São 15:50. Às 16:00, vai à explicação e participa até ao seu término.** — cumprimento monitorizado: NÃO
- **ALARME ESTUDO** — 22:15 → 22:25–03:00 — Estudar HIST e GEO. Faz VID, Ex e GRAV. — **São 22:15. Das 22:25 às 03:00, estuda HIST e GEO. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO EXPLICACAO_1750** — 17:50 — **Não te esqueças: dorme depois da explicação.** — condição `EXPLICACAO_TERMINADA`
- **NOTIFICAÇÃO EXPLICACAO_1810** — 18:10 — **Dorme imediatamente.** — condição `EXPLICACAO_TERMINADA`
- **NOTIFICAÇÃO AUDIOS** — 08:45 — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — condição `VALID`
- **EVENTO EXPLICACAO_FIM** — gatilho `EXPLICAÇÃO TERMINOU` — Marcar explicação terminada e liberar pendências. — **Quando a explicação terminar, marca EXPLICAÇÃO TERMINADA e executa as pendências válidas.** — estado `AGUARDANDO`
- **ESTUDO:** HISTÓRIA — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** GEOGRAFIA — 14 páginas — VID, Ex, GRAV

## QUARTA-FEIRA
Escola=NÃO | Explicação=SIM | Educação Física=NÃO | Lavagem=SIM | T.P.C.=NÃO | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "FIXED_WINDOW_START", "time": "08:45", "window": ["08:45", "09:55"]}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:00 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05 às 05:00, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME LIVRE_MANHA** — 04:55 → 05:05–07:05 — Ficar livre. — **São 04:55. Das 05:05 às 07:05, fica livre.** — cumprimento monitorizado: SIM
- **ALARME ORGANIZACAO** — 06:55 → 07:05–08:45 — Organizar o quarto e o interior, garantir o Matabixo + almoço para Guift e Melissa e colocar água nas bacias. — **São 06:55. Das 07:05 às 08:45, organiza o quarto e o interior, garante o Matabixo + almoço para Guift e Melissa e coloca água nas bacias.** — cumprimento monitorizado: SIM
- **ALARME SONO** — 09:45 → 09:55–15:40 — Dormir. — **São 09:45. Das 09:55 às 15:40, dorme.** — cumprimento monitorizado: SIM
- **ALARME PREP_EXPLICACAO** — 15:40 → 15:50–16:00 — Preparar-te para a explicação. — **São 15:40. Das 15:50 às 16:00, prepara-te para a explicação.** — cumprimento monitorizado: SIM
- **ALARME EXPLICACAO** — 15:50 → 16:00–fim — Ir à explicação e participar até ao seu término. — **São 15:50. Às 16:00, vai à explicação e participa até ao seu término.** — cumprimento monitorizado: NÃO
- **ALARME ESTUDO** — 22:15 → 22:25–03:00 — Estudar INGL e BÍBLIA. Faz VID, Ex e GRAV em INGL e VID + GRAV em BÍBLIA. — **São 22:15. Das 22:25 às 03:00, estuda INGL e BÍBLIA. Faz VID, Ex e GRAV em INGL e VID + GRAV em BÍBLIA.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO LAVAGEM** — 09:00 — **Lava o uniforme.** — condição `VALID`
- **NOTIFICAÇÃO EXPLICACAO_1750** — 17:50 — **Não te esqueças: dorme depois da explicação.** — condição `EXPLICACAO_TERMINADA`
- **NOTIFICAÇÃO EXPLICACAO_1810** — 18:10 — **Dorme imediatamente.** — condição `EXPLICACAO_TERMINADA`
- **NOTIFICAÇÃO AUDIOS** — 08:45 — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — condição `VALID`
- **EVENTO EXPLICACAO_FIM** — gatilho `EXPLICAÇÃO TERMINOU` — Marcar explicação terminada e liberar pendências. — **Quando a explicação terminar, marca EXPLICAÇÃO TERMINADA e executa as pendências válidas.** — estado `AGUARDANDO`
- **ESTUDO:** INGLÊS — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** BÍBLIA — 17 páginas — VID + GRAV

## QUINTA-FEIRA
Escola=NÃO | Explicação=SIM | Educação Física=NÃO | Lavagem=NÃO | T.P.C.=NÃO | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "FIXED_WINDOW_START", "time": "08:45", "window": ["08:45", "09:55"]}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:00 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05 às 05:00, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME LIVRE_MANHA** — 04:55 → 05:05–07:05 — Ficar livre. — **São 04:55. Das 05:05 às 07:05, fica livre.** — cumprimento monitorizado: SIM
- **ALARME ORGANIZACAO** — 06:55 → 07:05–08:45 — Organizar o quarto e o interior, garantir o Matabixo + almoço para Guift e Melissa e colocar água nas bacias. — **São 06:55. Das 07:05 às 08:45, organiza o quarto e o interior, garante o Matabixo + almoço para Guift e Melissa e coloca água nas bacias.** — cumprimento monitorizado: SIM
- **ALARME SONO** — 09:45 → 09:55–15:40 — Dormir. — **São 09:45. Das 09:55 às 15:40, dorme.** — cumprimento monitorizado: SIM
- **ALARME PREP_EXPLICACAO** — 15:40 → 15:50–16:00 — Preparar-te para a explicação. — **São 15:40. Das 15:50 às 16:00, prepara-te para a explicação.** — cumprimento monitorizado: SIM
- **ALARME EXPLICACAO** — 15:50 → 16:00–fim — Ir à explicação e participar até ao seu término. — **São 15:50. Às 16:00, vai à explicação e participa até ao seu término.** — cumprimento monitorizado: NÃO
- **ALARME ESTUDO** — 22:50 → 23:00–03:00 — Estudar BIOL e EDV. Faz VID, Ex e GRAV. — **São 22:50. Das 23:00 às 03:00, estuda BIOL e EDV. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO EXPLICACAO_1750** — 17:50 — **Não te esqueças: dorme depois da explicação.** — condição `EXPLICACAO_TERMINADA`
- **NOTIFICAÇÃO EXPLICACAO_1810** — 18:10 — **Dorme imediatamente.** — condição `EXPLICACAO_TERMINADA`
- **NOTIFICAÇÃO AUDIOS** — 08:45 — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — condição `VALID`
- **EVENTO EXPLICACAO_FIM** — gatilho `EXPLICAÇÃO TERMINOU` — Marcar explicação terminada e liberar pendências. — **Quando a explicação terminar, marca EXPLICAÇÃO TERMINADA e executa as pendências válidas.** — estado `AGUARDANDO`
- **ESTUDO:** BIOLOGIA — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** EDV — 14 páginas — VID, Ex, GRAV

## SEXTA-FEIRA
Escola=NÃO | Explicação=SIM | Educação Física=NÃO | Lavagem=SIM | T.P.C.=NÃO | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "FIXED_WINDOW_START", "time": "08:45", "window": ["08:45", "09:55"]}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:00 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05 às 05:00, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME LIVRE_MANHA** — 04:55 → 05:05–07:05 — Ficar livre. — **São 04:55. Das 05:05 às 07:05, fica livre.** — cumprimento monitorizado: SIM
- **ALARME ORGANIZACAO** — 06:55 → 07:05–08:45 — Organizar o quarto e o interior, garantir o Matabixo + almoço para Guift e Melissa e colocar água nas bacias. — **São 06:55. Das 07:05 às 08:45, organiza o quarto e o interior, garante o Matabixo + almoço para Guift e Melissa e coloca água nas bacias.** — cumprimento monitorizado: SIM
- **ALARME SONO** — 09:45 → 09:55–15:40 — Dormir. — **São 09:45. Das 09:55 às 15:40, dorme.** — cumprimento monitorizado: SIM
- **ALARME PREP_EXPLICACAO** — 15:40 → 15:50–16:00 — Preparar-te para a explicação. — **São 15:40. Das 15:50 às 16:00, prepara-te para a explicação.** — cumprimento monitorizado: SIM
- **ALARME EXPLICACAO** — 15:50 → 16:00–fim — Ir à explicação e participar até ao seu término. — **São 15:50. Às 16:00, vai à explicação e participa até ao seu término.** — cumprimento monitorizado: NÃO
- **ALARME ESTUDO** — 22:15 → 22:25–03:00 — Estudar FRANCÊS e DÍCIO. Faz VID, Ex e GRAV. — **São 22:15. Das 22:25 às 03:00, estuda FRANCÊS e DÍCIO. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO LAVAGEM** — 09:00 — **Lava o uniforme.** — condição `VALID`
- **NOTIFICAÇÃO EXPLICACAO_1750** — 17:50 — **Não te esqueças: dorme depois da explicação.** — condição `EXPLICACAO_TERMINADA`
- **NOTIFICAÇÃO EXPLICACAO_1810** — 18:10 — **Dorme imediatamente.** — condição `EXPLICACAO_TERMINADA`
- **NOTIFICAÇÃO AUDIOS** — 08:45 — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — condição `VALID`
- **EVENTO EXPLICACAO_FIM** — gatilho `EXPLICAÇÃO TERMINOU` — Marcar explicação terminada e liberar pendências. — **Quando a explicação terminar, marca EXPLICAÇÃO TERMINADA e executa as pendências válidas.** — estado `AGUARDANDO`
- **ESTUDO:** FRANCÊS — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** DÍCIO — 15 páginas — VID, Ex, GRAV

## SÁBADO
Escola=NÃO | Explicação=NÃO | Educação Física=NÃO APLICÁVEL | Lavagem=NÃO | T.P.C.=NÃO | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "FIXED_WINDOW_START", "time": "08:45", "window": ["08:45", "09:55"]}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:00 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05 às 05:00, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME LIVRE_MANHA** — 04:55 → 05:05–07:05 — Ficar livre. — **São 04:55. Das 05:05 às 07:05, fica livre.** — cumprimento monitorizado: NÃO
- **ALARME ORGANIZACAO** — 06:55 → 07:05–08:45 — Organizar o quarto e o interior, garantir o Matabixo + almoço para Guift e Melissa e colocar água nas bacias. — **São 06:55. Das 07:05 às 08:45, organiza o quarto e o interior, garante o Matabixo + almoço para Guift e Melissa e coloca água nas bacias.** — cumprimento monitorizado: SIM
- **ALARME SONO_NAO_ESCOLAR** — 09:45 → 09:55–17:45 — Dormir. — **São 09:45. Das 09:55 às 17:45, dorme.** — cumprimento monitorizado: NÃO
- **ALARME ACORDAR_NAO_ESCOLAR** — 17:35 → 17:45–18:45 — Acordar, tomar banho, escovar os dentes e garantir o uniforme engomado. — **São 17:35. Das 17:45 às 18:45, acorda, toma banho, escova os dentes e garante o uniforme engomado.** — cumprimento monitorizado: SIM
- **ALARME ESTUDO** — 18:35 → 18:45–03:00 — Estudar AGRO e HOTWAV HYPER 7 PRO. Faz VID, Ex e GRAV em AGRO e realiza o material correspondente do ciclo em HOTWAV HYPER 7 PRO. — **São 18:35. Das 18:45 às 03:00, estuda AGRO e HOTWAV HYPER 7 PRO. Faz VID, Ex e GRAV em AGRO e realiza o material correspondente do ciclo em HOTWAV HYPER 7 PRO.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO AUDIOS** — 08:45 — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — condição `VALID`
- **TAREFA:** Organizar o quarto.
- **ESTUDO:** AGRO — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** HOTWAV HYPER 7 PRO — 0 páginas — material correspondente do ciclo

# CATEGORIA: NÃO FUI À EXPLICAÇÃO — 24 HORAS — TEMPORÁRIA

## DOMINGO
Escola=NÃO | Explicação=NÃO | Educação Física=NÃO APLICÁVEL | Lavagem=NÃO | T.P.C.=NÃO | **ÁUDIOS=SIM** | Igreja=SIM | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "EVENTO", "trigger": "RETORNO_REAL_DA_IGREJA_E_MOMENTO_LIVRE"}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:00 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05 às 05:00, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME PREPARACAO_IGREJA** — 04:55 → 05:05–05:45 — Tomar banho, escovar os dentes, limpar os sapatos e vestir-se. — **São 04:55. Das 05:05 às 05:45, prepara-te: toma banho, escova os dentes, limpa os sapatos e veste-te.** — cumprimento monitorizado: SIM
- **ALARME ACORDAR_NOITE** — 19:50 → 20:00–20:25 — Acordar, tomar banho e vestir-se. — **São 19:50. Das 20:00 às 20:25, acorda, toma banho e veste-te.** — cumprimento monitorizado: SIM
- **ALARME ESTUDO** — 20:15 → 20:25–03:00 — Estudar MAT e PORT. Faz VID, Ex e GRAV. — **São 20:15. Das 20:25 às 03:00, estuda MAT e PORT. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **EVENTO IGREJA_IDA** — gatilho `PREPARAÇÃO TERMINADA` — Ir à igreja no momento certo. — **Termina de te preparar e vai à igreja no momento certo.** — estado `AGUARDANDO`
- **EVENTO IGREJA_RETORNO** — gatilho `RETORNO REAL DA IGREJA` — Dormir. — **Volta da igreja e dorme.** — estado `AGUARDANDO`
- **EVENTO AUDIOS** — gatilho `RETORNO REAL DA IGREJA + SURGIU MOMENTO LIVRE ANTES DO PRÓXIMO BLOCO FIXO` — Escutar os áudios. — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — estado `AGUARDANDO`
- **TAREFA:** Organizar o quarto.
- **ESTUDO:** MATEMÁTICA — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** PORTUGUÊS — 14 páginas — VID, Ex, GRAV

## SEGUNDA-FEIRA
Escola=SIM | Explicação=NÃO | Educação Física=NÃO | Lavagem=NÃO | T.P.C.=SIM | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "EVENTO", "trigger": "PRIMEIRO_MOMENTO_LIVRE_DISPONIVEL"}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:40 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05–05:40, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME PREPARACAO_ESCOLA** — 05:35 → 05:45–06:00 — Tomar banho, escovar os dentes, limpar os sapatos e vestir o uniforme. — **São 05:35. Das 05:45 às 06:00, prepara-te: toma banho, escova os dentes, limpa os sapatos e veste o uniforme.** — cumprimento monitorizado: SIM
- **ALARME ESCOLA** — 05:50 → 06:00 — Ir à escola. — **São 05:50. Às 06:00, vai à escola.** — cumprimento monitorizado: SIM
- **ALARME BANHO** — 16:35 → 16:45–17:00 — Tomar banho. — **São 16:35. Das 16:45 às 17:00, toma banho.** — cumprimento monitorizado: SIM
- **ALARME SONO** — 16:50 → 17:00–23:00 — Dormir. — **São 16:50. Das 17:00 às 23:00, dorme.** — cumprimento monitorizado: NÃO
- **ALARME ESTUDO** — 22:50 → 23:00–03:00 — Estudar FIS e QUI. Faz VID, Ex e GRAV. — **São 22:50. Das 23:00 às 03:00, estuda FIS e QUI. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO TPC_0520** — 05:20 — **Faz o T.P.C.** — condição `VALID`
- **EVENTO AUDIOS** — gatilho `SURGIU MOMENTO LIVRE NÃO DESTINADO AO T.P.C., À EXPLICAÇÃO, À EDUCAÇÃO FÍSICA OU AO SONO` — Escutar os áudios. — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — estado `AGUARDANDO`
- **ESTUDO:** FÍSICA — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** QUÍMICA — 14 páginas — VID, Ex, GRAV

## TERÇA-FEIRA
Escola=SIM | Explicação=NÃO | Educação Física=NÃO | Lavagem=NÃO | T.P.C.=SIM | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "EVENTO", "trigger": "PRIMEIRO_MOMENTO_LIVRE_DISPONIVEL"}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:40 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05–05:40, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME PREPARACAO_ESCOLA** — 05:35 → 05:45–06:00 — Tomar banho, escovar os dentes, limpar os sapatos e vestir o uniforme. — **São 05:35. Das 05:45 às 06:00, prepara-te: toma banho, escova os dentes, limpa os sapatos e veste o uniforme.** — cumprimento monitorizado: SIM
- **ALARME ESCOLA** — 05:50 → 06:00 — Ir à escola. — **São 05:50. Às 06:00, vai à escola.** — cumprimento monitorizado: SIM
- **ALARME BANHO** — 16:35 → 16:45–17:00 — Tomar banho. — **São 16:35. Das 16:45 às 17:00, toma banho.** — cumprimento monitorizado: SIM
- **ALARME SONO** — 16:50 → 17:00–23:00 — Dormir. — **São 16:50. Das 17:00 às 23:00, dorme.** — cumprimento monitorizado: NÃO
- **ALARME ESTUDO** — 22:50 → 23:00–03:00 — Estudar HIST e GEO. Faz VID, Ex e GRAV. — **São 22:50. Das 23:00 às 03:00, estuda HIST e GEO. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO TPC_0520** — 05:20 — **Faz o T.P.C.** — condição `VALID`
- **EVENTO AUDIOS** — gatilho `SURGIU MOMENTO LIVRE NÃO DESTINADO AO T.P.C., À EXPLICAÇÃO, À EDUCAÇÃO FÍSICA OU AO SONO` — Escutar os áudios. — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — estado `AGUARDANDO`
- **ESTUDO:** HISTÓRIA — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** GEOGRAFIA — 14 páginas — VID, Ex, GRAV

## QUARTA-FEIRA
Escola=SIM | Explicação=NÃO | Educação Física=SIM | Lavagem=SIM | T.P.C.=SIM | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "EVENTO", "trigger": "PRIMEIRO_MOMENTO_LIVRE_DISPONIVEL"}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:40 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05–05:40, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME PREPARACAO_ESCOLA_E_PE** — 05:35 → 05:45–06:00 — Tomar banho, escovar os dentes, limpar os sapatos, vestir o uniforme e preparar o uniforme de Educação Física. — **São 05:35. Das 05:45 às 06:00, prepara-te: toma banho, escova os dentes, limpa os sapatos, veste o uniforme e prepara o uniforme de Educação Física.** — cumprimento monitorizado: SIM
- **ALARME ESCOLA** — 05:50 → 06:00 — Ir à escola. — **São 05:50. Às 06:00, vai à escola.** — cumprimento monitorizado: SIM
- **ALARME BANHO** — 16:35 → 16:45–17:00 — Tomar banho. — **São 16:35. Das 16:45 às 17:00, toma banho.** — cumprimento monitorizado: SIM
- **ALARME SONO** — 16:50 → 17:00–23:00 — Dormir. — **São 16:50. Das 17:00 às 23:00, dorme.** — cumprimento monitorizado: NÃO
- **ALARME ESTUDO** — 22:50 → 23:00–03:00 — Estudar INGL e BÍBLIA. Faz VID, Ex e GRAV em INGL e VID + GRAV em BÍBLIA. — **São 22:50. Das 23:00 às 03:00, estuda INGL e BÍBLIA. Faz VID, Ex e GRAV em INGL e VID + GRAV em BÍBLIA.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO TPC_0520** — 05:20 — **Faz o T.P.C.** — condição `VALID`
- **NOTIFICAÇÃO LAVAGEM** — 13:20 — **Lava o uniforme.** — condição `VALID`
- **EVENTO PE_RETORNO** — gatilho `RETORNO REAL DEPOIS DA EDUCAÇÃO FÍSICA` — Executar a rotina pós-Educação Física. — **Depois da Educação Física, volta para casa, busca o Guift, come se for necessário, trabalha, varre dentro de casa, garante o almoço da Melissa e do Guift quando estiverem presentes, garante as bacias de água e termina tudo até às 16:40.** — estado `AGUARDANDO`
- **EVENTO AUDIOS** — gatilho `SURGIU MOMENTO LIVRE NÃO DESTINADO AO T.P.C., À EXPLICAÇÃO, À EDUCAÇÃO FÍSICA OU AO SONO` — Escutar os áudios. — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — estado `AGUARDANDO`
- **ESTUDO:** INGLÊS — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** BÍBLIA — 17 páginas — VID + GRAV

## QUINTA-FEIRA
Escola=SIM | Explicação=NÃO | Educação Física=NÃO | Lavagem=NÃO | T.P.C.=SIM | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "EVENTO", "trigger": "PRIMEIRO_MOMENTO_LIVRE_DISPONIVEL"}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:40 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05–05:40, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME PREPARACAO_ESCOLA** — 05:35 → 05:45–06:00 — Tomar banho, escovar os dentes, limpar os sapatos e vestir o uniforme. — **São 05:35. Das 05:45 às 06:00, prepara-te: toma banho, escova os dentes, limpa os sapatos e veste o uniforme.** — cumprimento monitorizado: SIM
- **ALARME ESCOLA** — 05:50 → 06:00 — Ir à escola. — **São 05:50. Às 06:00, vai à escola.** — cumprimento monitorizado: SIM
- **ALARME BANHO** — 16:35 → 16:45–17:00 — Tomar banho. — **São 16:35. Das 16:45 às 17:00, toma banho.** — cumprimento monitorizado: SIM
- **ALARME SONO** — 16:50 → 17:00–23:00 — Dormir. — **São 16:50. Das 17:00 às 23:00, dorme.** — cumprimento monitorizado: NÃO
- **ALARME ESTUDO** — 22:50 → 23:00–03:00 — Estudar BIOL e EDV. Faz VID, Ex e GRAV. — **São 22:50. Das 23:00 às 03:00, estuda BIOL e EDV. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO TPC_0520** — 05:20 — **Faz o T.P.C.** — condição `VALID`
- **EVENTO AUDIOS** — gatilho `SURGIU MOMENTO LIVRE NÃO DESTINADO AO T.P.C., À EXPLICAÇÃO, À EDUCAÇÃO FÍSICA OU AO SONO` — Escutar os áudios. — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — estado `AGUARDANDO`
- **ESTUDO:** BIOLOGIA — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** EDV — 14 páginas — VID, Ex, GRAV

## SEXTA-FEIRA
Escola=SIM | Explicação=NÃO | Educação Física=NÃO | Lavagem=SIM | T.P.C.=SIM | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "EVENTO", "trigger": "PRIMEIRO_MOMENTO_LIVRE_DISPONIVEL"}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:40 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05–05:40, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME PREPARACAO_ESCOLA** — 05:35 → 05:45–06:00 — Tomar banho, escovar os dentes, limpar os sapatos e vestir o uniforme. — **São 05:35. Das 05:45 às 06:00, prepara-te: toma banho, escova os dentes, limpa os sapatos e veste o uniforme.** — cumprimento monitorizado: SIM
- **ALARME ESCOLA** — 05:50 → 06:00 — Ir à escola. — **São 05:50. Às 06:00, vai à escola.** — cumprimento monitorizado: SIM
- **ALARME BANHO** — 16:35 → 16:45–17:00 — Tomar banho. — **São 16:35. Das 16:45 às 17:00, toma banho.** — cumprimento monitorizado: SIM
- **ALARME SONO** — 16:50 → 17:00–23:00 — Dormir. — **São 16:50. Das 17:00 às 23:00, dorme.** — cumprimento monitorizado: NÃO
- **ALARME ESTUDO** — 22:50 → 23:00–03:00 — Estudar FRANCÊS e DÍCIO. Faz VID, Ex e GRAV. — **São 22:50. Das 23:00 às 03:00, estuda FRANCÊS e DÍCIO. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO TPC_0520** — 05:20 — **Faz o T.P.C.** — condição `VALID`
- **NOTIFICAÇÃO LAVAGEM** — 13:20 — **Lava o uniforme.** — condição `VALID`
- **EVENTO TPC_LIVRE** — gatilho `COMEÇOU O PERÍODO LIVRE` — Fazer o T.P.C. — **Faz o T.P.C.** — estado `AGUARDANDO`
- **EVENTO AUDIOS** — gatilho `SURGIU MOMENTO LIVRE NÃO DESTINADO AO T.P.C., À EXPLICAÇÃO, À EDUCAÇÃO FÍSICA OU AO SONO` — Escutar os áudios. — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — estado `AGUARDANDO`
- **ESTUDO:** FRANCÊS — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** DÍCIO — 15 páginas — VID, Ex, GRAV

## SÁBADO
Escola=SIM | Explicação=NÃO | Educação Física=NÃO | Lavagem=NÃO | T.P.C.=NÃO | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "FIXED_WINDOW_START", "time": "09:50", "window": ["09:50", "13:45"]}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:00 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05–05:00, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME PREPARACAO_ESCOLA** — 05:35 → 05:45–06:00 — Tomar banho, escovar os dentes, limpar os sapatos e vestir o uniforme. — **São 05:35. Das 05:45 às 06:00, prepara-te: toma banho, escova os dentes, limpa os sapatos e veste o uniforme.** — cumprimento monitorizado: SIM
- **ALARME ESCOLA** — 05:50 → 06:00 — Ir à escola. — **São 05:50. Às 06:00, vai à escola.** — cumprimento monitorizado: SIM
- **ALARME BANHO** — 16:35 → 16:45–17:00 — Tomar banho. — **São 16:35. Das 16:45 às 17:00, toma banho.** — cumprimento monitorizado: SIM
- **ALARME SONO** — 16:50 → 17:00–23:00 — Dormir. — **São 16:50. Das 17:00 às 23:00, dorme.** — cumprimento monitorizado: NÃO
- **ALARME ESTUDO** — 22:50 → 23:00–03:00 — Estudar AGRO e HOTWAV HYPER 7 PRO. Faz VID, Ex e GRAV em AGRO e realiza o material correspondente do ciclo em HOTWAV HYPER 7 PRO. — **São 22:50. Das 23:00 às 03:00, estuda AGRO e HOTWAV HYPER 7 PRO. Faz VID, Ex e GRAV em AGRO e realiza o material correspondente do ciclo em HOTWAV HYPER 7 PRO.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO AUDIOS** — 09:50 — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — condição `VALID`
- **TAREFA:** Organizar o quarto.
- **ESTUDO:** AGRO — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** HOTWAV HYPER 7 PRO — 0 páginas — material correspondente do ciclo

# CATEGORIA: NÃO FUI À EDUCAÇÃO FÍSICA, MAS VOU À EXPLICAÇÃO — 24 HORAS — TEMPORÁRIA

## DOMINGO
Escola=NÃO | Explicação=NÃO | Educação Física=NÃO APLICÁVEL | Lavagem=NÃO | T.P.C.=NÃO | **ÁUDIOS=SIM** | Igreja=SIM | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "EVENTO", "trigger": "RETORNO_REAL_DA_IGREJA_E_MOMENTO_LIVRE"}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:00 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05 às 05:00, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME PREPARACAO_IGREJA** — 04:55 → 05:05–05:45 — Tomar banho, escovar os dentes, limpar os sapatos e vestir-se. — **São 04:55. Das 05:05 às 05:45, prepara-te: toma banho, escova os dentes, limpa os sapatos e veste-te.** — cumprimento monitorizado: SIM
- **ALARME ACORDAR_NOITE** — 19:50 → 20:00–20:25 — Acordar, tomar banho e vestir-se. — **São 19:50. Das 20:00 às 20:25, acorda, toma banho e veste-te.** — cumprimento monitorizado: SIM
- **ALARME ESTUDO** — 20:15 → 20:25–03:00 — Estudar MAT e PORT. Faz VID, Ex e GRAV. — **São 20:15. Das 20:25 às 03:00, estuda MAT e PORT. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **EVENTO IGREJA_IDA** — gatilho `PREPARAÇÃO TERMINADA` — Ir à igreja no momento certo. — **Termina de te preparar e vai à igreja no momento certo.** — estado `AGUARDANDO`
- **EVENTO IGREJA_RETORNO** — gatilho `RETORNO REAL DA IGREJA` — Dormir. — **Volta da igreja e dorme.** — estado `AGUARDANDO`
- **EVENTO AUDIOS** — gatilho `RETORNO REAL DA IGREJA + SURGIU MOMENTO LIVRE ANTES DO PRÓXIMO BLOCO FIXO` — Escutar os áudios. — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — estado `AGUARDANDO`
- **TAREFA:** Organizar o quarto.
- **ESTUDO:** MATEMÁTICA — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** PORTUGUÊS — 14 páginas — VID, Ex, GRAV

## SEGUNDA-FEIRA
Escola=SIM | Explicação=SIM | Educação Física=NÃO | Lavagem=NÃO | T.P.C.=SIM | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "EVENTO", "trigger": "PRIMEIRO_MOMENTO_LIVRE_DISPONIVEL"}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:40 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05–05:40, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME PREPARACAO_ESCOLA** — 05:35 → 05:45–06:00 — Tomar banho, escovar os dentes, limpar os sapatos e vestir o uniforme. — **São 05:35. Das 05:45 às 06:00, prepara-te: toma banho, escova os dentes, limpa os sapatos e veste o uniforme.** — cumprimento monitorizado: SIM
- **ALARME ESCOLA** — 05:50 → 06:00 — Ir à escola. — **São 05:50. Às 06:00, vai à escola.** — cumprimento monitorizado: SIM
- **ALARME SONO** — 13:35 → 13:45–15:40 — Dormir. — **São 13:35. Das 13:45 às 15:40, dorme.** — cumprimento monitorizado: NÃO
- **ALARME PREP_EXPLICACAO** — 15:40 → 15:50–16:00 — Preparar-te para a explicação. — **São 15:40. Das 15:50 às 16:00, prepara-te para a explicação.** — cumprimento monitorizado: SIM
- **ALARME EXPLICACAO** — 15:50 → 16:00–fim — Ir à explicação e participar até ao seu término. — **São 15:50. Às 16:00, vai à explicação e participa até ao seu término.** — cumprimento monitorizado: NÃO
- **ALARME ESTUDO** — 22:15 → 22:25–03:00 — Estudar FIS e QUI. Faz VID, Ex e GRAV. — **São 22:15. Das 22:25 às 03:00, estuda FIS e QUI. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO TPC_0520** — 05:20 — **Faz o T.P.C.** — condição `VALID`
- **NOTIFICAÇÃO EXPLICACAO_1750** — 17:50 — **Não te esqueças: dorme depois da explicação.** — condição `EXPLICACAO_TERMINADA`
- **NOTIFICAÇÃO EXPLICACAO_1810** — 18:10 — **Dorme imediatamente.** — condição `EXPLICACAO_TERMINADA`
- **EVENTO EXPLICACAO_FIM** — gatilho `EXPLICAÇÃO TERMINOU` — Marcar explicação terminada e liberar pendências. — **Quando a explicação terminar, marca EXPLICAÇÃO TERMINADA e executa as pendências válidas.** — estado `AGUARDANDO`
- **EVENTO AUDIOS** — gatilho `SURGIU MOMENTO LIVRE NA ESCOLA NÃO DESTINADO AO T.P.C., À EDUCAÇÃO FÍSICA OU À EXPLICAÇÃO` — Escutar os áudios. — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — estado `AGUARDANDO`
- **ESTUDO:** FÍSICA — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** QUÍMICA — 14 páginas — VID, Ex, GRAV

## TERÇA-FEIRA
Escola=SIM | Explicação=SIM | Educação Física=NÃO | Lavagem=NÃO | T.P.C.=SIM | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "EVENTO", "trigger": "PRIMEIRO_MOMENTO_LIVRE_DISPONIVEL"}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:40 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05–05:40, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME PREPARACAO_ESCOLA** — 05:35 → 05:45–06:00 — Tomar banho, escovar os dentes, limpar os sapatos e vestir o uniforme. — **São 05:35. Das 05:45 às 06:00, prepara-te: toma banho, escova os dentes, limpa os sapatos e veste o uniforme.** — cumprimento monitorizado: SIM
- **ALARME ESCOLA** — 05:50 → 06:00 — Ir à escola. — **São 05:50. Às 06:00, vai à escola.** — cumprimento monitorizado: SIM
- **ALARME SONO** — 13:35 → 13:45–15:40 — Dormir. — **São 13:35. Das 13:45 às 15:40, dorme.** — cumprimento monitorizado: NÃO
- **ALARME PREP_EXPLICACAO** — 15:40 → 15:50–16:00 — Preparar-te para a explicação. — **São 15:40. Das 15:50 às 16:00, prepara-te para a explicação.** — cumprimento monitorizado: SIM
- **ALARME EXPLICACAO** — 15:50 → 16:00–fim — Ir à explicação e participar até ao seu término. — **São 15:50. Às 16:00, vai à explicação e participa até ao seu término.** — cumprimento monitorizado: NÃO
- **ALARME ESTUDO** — 22:15 → 22:25–03:00 — Estudar HIST e GEO. Faz VID, Ex e GRAV. — **São 22:15. Das 22:25 às 03:00, estuda HIST e GEO. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO TPC_0520** — 05:20 — **Faz o T.P.C.** — condição `VALID`
- **NOTIFICAÇÃO EXPLICACAO_1750** — 17:50 — **Não te esqueças: dorme depois da explicação.** — condição `EXPLICACAO_TERMINADA`
- **NOTIFICAÇÃO EXPLICACAO_1810** — 18:10 — **Dorme imediatamente.** — condição `EXPLICACAO_TERMINADA`
- **EVENTO EXPLICACAO_FIM** — gatilho `EXPLICAÇÃO TERMINOU` — Marcar explicação terminada e liberar pendências. — **Quando a explicação terminar, marca EXPLICAÇÃO TERMINADA e executa as pendências válidas.** — estado `AGUARDANDO`
- **EVENTO AUDIOS** — gatilho `SURGIU MOMENTO LIVRE NA ESCOLA NÃO DESTINADO AO T.P.C., À EDUCAÇÃO FÍSICA OU À EXPLICAÇÃO` — Escutar os áudios. — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — estado `AGUARDANDO`
- **ESTUDO:** HISTÓRIA — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** GEOGRAFIA — 14 páginas — VID, Ex, GRAV

## QUARTA-FEIRA
Escola=SIM | Explicação=SIM | Educação Física=NÃO | Lavagem=SIM | T.P.C.=SIM | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "EVENTO", "trigger": "PRIMEIRO_MOMENTO_LIVRE_DISPONIVEL"}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:40 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05 às 05:40, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME PREPARACAO_ESCOLA** — 05:35 → 05:45–06:00 — Tomar banho, escovar os dentes, limpar os sapatos e vestir o uniforme. Não preparar o uniforme de Educação Física. — **São 05:35. Das 05:45 às 06:00, prepara-te: toma banho, escova os dentes, limpa os sapatos e veste o uniforme. Não prepares nem uses o uniforme de Educação Física.** — cumprimento monitorizado: SIM
- **ALARME ESCOLA** — 05:50 → 06:00 — Ir à escola. — **São 05:50. Às 06:00, vai à escola.** — cumprimento monitorizado: SIM
- **ALARME SONO** — 13:35 → 13:45–15:40 — Dormir. — **São 13:35. Das 13:45 às 15:40, dorme.** — cumprimento monitorizado: SIM
- **ALARME PREP_EXPLICACAO** — 15:40 → 15:50–16:00 — Preparar-te para a explicação. — **São 15:40. Das 15:50 às 16:00, prepara-te para a explicação.** — cumprimento monitorizado: SIM
- **ALARME EXPLICACAO** — 15:50 → 16:00–fim — Ir à explicação e participar até ao seu término. — **São 15:50. Às 16:00, vai à explicação e participa até ao seu término.** — cumprimento monitorizado: NÃO
- **ALARME ESTUDO** — 22:15 → 22:25–03:00 — Estudar INGL e BÍBLIA. Faz VID, Ex e GRAV em INGL e VID + GRAV em BÍBLIA. — **São 22:15. Das 22:25 às 03:00, estuda INGL e BÍBLIA. Faz VID, Ex e GRAV em INGL e VID + GRAV em BÍBLIA.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO TPC_0520** — 05:20 — **Faz o T.P.C.** — condição `VALID`
- **NOTIFICAÇÃO LAVAGEM** — 13:20 — **Lava o uniforme.** — condição `VALID`
- **NOTIFICAÇÃO EXPLICACAO_1750** — 17:50 — **Não te esqueças: dorme depois da explicação.** — condição `EXPLICACAO_TERMINADA`
- **NOTIFICAÇÃO EXPLICACAO_1810** — 18:10 — **Dorme imediatamente.** — condição `EXPLICACAO_TERMINADA`
- **EVENTO EXPLICACAO_FIM** — gatilho `EXPLICAÇÃO TERMINOU` — Marcar explicação terminada e liberar pendências. — **Quando a explicação terminar, marca EXPLICAÇÃO TERMINADA e executa as pendências válidas.** — estado `AGUARDANDO`
- **EVENTO AUDIOS** — gatilho `SURGIU MOMENTO LIVRE NA ESCOLA NÃO DESTINADO AO T.P.C. OU À EXPLICAÇÃO` — Escutar os áudios. — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — estado `AGUARDANDO`
- **ESTUDO:** INGLÊS — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** BÍBLIA — 17 páginas — VID + GRAV

## QUINTA-FEIRA
Escola=SIM | Explicação=SIM | Educação Física=NÃO | Lavagem=NÃO | T.P.C.=SIM | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "EVENTO", "trigger": "PRIMEIRO_MOMENTO_LIVRE_DISPONIVEL"}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:40 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05–05:40, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME PREPARACAO_ESCOLA** — 05:35 → 05:45–06:00 — Tomar banho, escovar os dentes, limpar os sapatos e vestir o uniforme. — **São 05:35. Das 05:45 às 06:00, prepara-te: toma banho, escova os dentes, limpa os sapatos e veste o uniforme.** — cumprimento monitorizado: SIM
- **ALARME ESCOLA** — 05:50 → 06:00 — Ir à escola. — **São 05:50. Às 06:00, vai à escola.** — cumprimento monitorizado: SIM
- **ALARME SONO** — 13:35 → 13:45–15:40 — Dormir. — **São 13:35. Das 13:45 às 15:40, dorme.** — cumprimento monitorizado: NÃO
- **ALARME PREP_EXPLICACAO** — 15:40 → 15:50–16:00 — Preparar-te para a explicação. — **São 15:40. Das 15:50 às 16:00, prepara-te para a explicação.** — cumprimento monitorizado: SIM
- **ALARME EXPLICACAO** — 15:50 → 16:00–fim — Ir à explicação e participar até ao seu término. — **São 15:50. Às 16:00, vai à explicação e participa até ao seu término.** — cumprimento monitorizado: NÃO
- **ALARME ESTUDO** — 22:50 → 23:00–03:00 — Estudar BIOL e EDV. Faz VID, Ex e GRAV. — **São 22:50. Das 23:00 às 03:00, estuda BIOL e EDV. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO TPC_0520** — 05:20 — **Faz o T.P.C.** — condição `VALID`
- **NOTIFICAÇÃO EXPLICACAO_1750** — 17:50 — **Não te esqueças: dorme depois da explicação.** — condição `EXPLICACAO_TERMINADA`
- **NOTIFICAÇÃO EXPLICACAO_1810** — 18:10 — **Dorme imediatamente.** — condição `EXPLICACAO_TERMINADA`
- **EVENTO EXPLICACAO_FIM** — gatilho `EXPLICAÇÃO TERMINOU` — Marcar explicação terminada e liberar pendências. — **Quando a explicação terminar, marca EXPLICAÇÃO TERMINADA e executa as pendências válidas.** — estado `AGUARDANDO`
- **EVENTO AUDIOS** — gatilho `SURGIU MOMENTO LIVRE NA ESCOLA NÃO DESTINADO AO T.P.C., À EDUCAÇÃO FÍSICA OU À EXPLICAÇÃO` — Escutar os áudios. — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — estado `AGUARDANDO`
- **ESTUDO:** BIOLOGIA — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** EDV — 14 páginas — VID, Ex, GRAV

## SEXTA-FEIRA
Escola=SIM | Explicação=SIM | Educação Física=NÃO | Lavagem=SIM | T.P.C.=SIM | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "EVENTO", "trigger": "PRIMEIRO_MOMENTO_LIVRE_DISPONIVEL"}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:40 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05–05:40, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME PREPARACAO_ESCOLA** — 05:35 → 05:45–06:00 — Tomar banho, escovar os dentes, limpar os sapatos e vestir o uniforme. — **São 05:35. Das 05:45 às 06:00, prepara-te: toma banho, escova os dentes, limpa os sapatos e veste o uniforme.** — cumprimento monitorizado: SIM
- **ALARME ESCOLA** — 05:50 → 06:00 — Ir à escola. — **São 05:50. Às 06:00, vai à escola.** — cumprimento monitorizado: SIM
- **ALARME SONO** — 13:35 → 13:45–15:40 — Dormir. — **São 13:35. Das 13:45 às 15:40, dorme.** — cumprimento monitorizado: NÃO
- **ALARME PREP_EXPLICACAO** — 15:40 → 15:50–16:00 — Preparar-te para a explicação. — **São 15:40. Das 15:50 às 16:00, prepara-te para a explicação.** — cumprimento monitorizado: SIM
- **ALARME EXPLICACAO** — 15:50 → 16:00–fim — Ir à explicação e participar até ao seu término. — **São 15:50. Às 16:00, vai à explicação e participa até ao seu término.** — cumprimento monitorizado: NÃO
- **ALARME ESTUDO** — 22:15 → 22:25–03:00 — Estudar FRANCÊS e DÍCIO. Faz VID, Ex e GRAV. — **São 22:15. Das 22:25 às 03:00, estuda FRANCÊS e DÍCIO. Faz VID, Ex e GRAV.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO TPC_0520** — 05:20 — **Faz o T.P.C.** — condição `VALID`
- **NOTIFICAÇÃO LAVAGEM** — 13:20 — **Lava o uniforme.** — condição `VALID`
- **NOTIFICAÇÃO EXPLICACAO_1750** — 17:50 — **Não te esqueças: dorme depois da explicação.** — condição `EXPLICACAO_TERMINADA`
- **NOTIFICAÇÃO EXPLICACAO_1810** — 18:10 — **Dorme imediatamente.** — condição `EXPLICACAO_TERMINADA`
- **EVENTO EXPLICACAO_FIM** — gatilho `EXPLICAÇÃO TERMINOU` — Marcar explicação terminada e liberar pendências. — **Quando a explicação terminar, marca EXPLICAÇÃO TERMINADA e executa as pendências válidas.** — estado `AGUARDANDO`
- **EVENTO AUDIOS** — gatilho `SURGIU MOMENTO LIVRE NA ESCOLA NÃO DESTINADO AO T.P.C., À EDUCAÇÃO FÍSICA OU À EXPLICAÇÃO` — Escutar os áudios. — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — estado `AGUARDANDO`
- **EVENTO TPC_LIVRE** — gatilho `COMEÇOU O PERÍODO LIVRE` — Fazer o T.P.C. — **Faz o T.P.C.** — estado `AGUARDANDO`
- **ESTUDO:** FRANCÊS — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** DÍCIO — 15 páginas — VID, Ex, GRAV

## SÁBADO
Escola=SIM | Explicação=NÃO | Educação Física=NÃO | Lavagem=NÃO | T.P.C.=NÃO | **ÁUDIOS=SIM** | Igreja=NÃO | Poupança=10 MT + 20 MT
ÁUDIO: `{"enabled": true, "message": "Aproveite este momento para escutar os áudios, áudios por ti feitos.", "priority": "BAIXA", "interruptHigherPriority": false, "deliveryMode": "FIXED_WINDOW_START", "time": "09:50", "window": ["09:50", "13:45"]}`
- **ALARME ORACAO** — 01:50 → 02:00 — Orar. — **São 01:50. Às 02:00, ora.** — cumprimento monitorizado: SIM
- **ALARME TRABALHO** — 02:55 → 03:05–05:00 — Lavar a louça, varrer o quintal e limpar a casa de banho. — **São 02:55. Das 03:05–05:00, trabalha: lava a louça, varre o quintal e limpa a casa de banho.** — cumprimento monitorizado: SIM
- **ALARME PREPARACAO_ESCOLA** — 05:35 → 05:45–06:00 — Tomar banho, escovar os dentes, limpar os sapatos e vestir o uniforme. — **São 05:35. Das 05:45 às 06:00, prepara-te: toma banho, escova os dentes, limpa os sapatos e veste o uniforme.** — cumprimento monitorizado: SIM
- **ALARME ESCOLA** — 05:50 → 06:00 — Ir à escola. — **São 05:50. Às 06:00, vai à escola.** — cumprimento monitorizado: SIM
- **ALARME BANHO** — 16:35 → 16:45–17:00 — Tomar banho. — **São 16:35. Das 16:45 às 17:00, toma banho.** — cumprimento monitorizado: SIM
- **ALARME SONO** — 16:50 → 17:00–23:00 — Dormir. — **São 16:50. Das 17:00 às 23:00, dorme.** — cumprimento monitorizado: NÃO
- **ALARME ESTUDO** — 22:50 → 23:00–03:00 — Estudar AGRO e HOTWAV HYPER 7 PRO. Faz VID, Ex e GRAV em AGRO e realiza o material correspondente do ciclo em HOTWAV HYPER 7 PRO. — **São 22:50. Das 23:00 às 03:00, estuda AGRO e HOTWAV HYPER 7 PRO. Faz VID, Ex e GRAV em AGRO e realiza o material correspondente do ciclo em HOTWAV HYPER 7 PRO.** — cumprimento monitorizado: SIM
- **NOTIFICAÇÃO AUDIOS** — 09:50 — **Aproveite este momento para escutar os áudios, áudios por ti feitos.** — condição `VALID`
- **TAREFA:** Organizar o quarto.
- **ESTUDO:** AGRO — 14 páginas — VID, Ex, GRAV
- **ESTUDO:** HOTWAV HYPER 7 PRO — 0 páginas — material correspondente do ciclo

## 12. IDS E DUPLICAÇÃO
IDs determinísticos por categoria + dia operacional + ciclo + tipo + item. Nenhuma ocorrência lógica pode existir duas vezes.

## 13. REBOOT E MUDANÇAS DO RELÓGIO
Reconciliar após reboot e alterações de hora/data/fuso; reconstruir apenas futuros válidos; não executar retroativamente.

## 14. RECURSOS LOCAIS
`index.html` na raiz. CSS, JS, dados, áudio e assets no pacote. Não depender de CDN, servidor, Firebase, push ou API remota para a rotina.

## 15. PROIBIÇÕES
Não criar 8.ª categoria. Não usar “igual ao anterior”, “idem”, “rotina normal” ou “etc.”. Não inventar horários. Não criar PE em PE=NÃO. Não criar explicação em explicação=NÃO. Não criar Ex para BÍBLIA. Não falsificar suporte nativo.

## 16. CRITÉRIO FINAL
O sistema deve respeitar integralmente o fluxo: **dados → estados → categoria efetiva → 03:00 → conflitos → execução → cumprimento → não confirmação/violação → persistência → reconstrução**.
## 16.1 INVARIANTES OBRIGATÓRIAS — ANTIBUG
Antes de considerar o build válido, executar validações automáticas sobre os 49 registos:
1. Existem exatamente 7 categorias e exatamente 7 dias por categoria = 49 registos.
2. Cada registo possui todos os campos obrigatórios: escola, explicação, educação física, lavagem, T.P.C., áudios, igreja, poupança, alarmes, notificações/eventos válidos, estudos e tarefa quando aplicável.
3. Nenhum alarme de Educação Física existe quando Educação Física=NÃO.
4. Nenhum item de explicação existe quando Explicação=NÃO, exceto dados explicitamente marcados como inativos e nunca agendados.
5. Nenhum T.P.C. escolar é agendado quando Escola=NÃO.
6. Cada alarme tem hora de disparo anterior ou igual à hora oficial, com antecedência de 10 minutos quando a regra exigir.
7. O texto do alarme corresponde exatamente à ação e ao horário oficial do mesmo registo.
8. O estudo do alarme corresponde aos dois estudos declarados no mesmo registo.
9. BÍBLIA nunca recebe Ex.
10. Temporárias expiram na próxima 03:00 e são substituídas pelo permanente sem desligar o motor.
11. Nenhum mesmo ID pode ter duas ocorrências físicas futuras.
12. Reboot, alteração de relógio, alteração de fuso ou troca de categoria não podem gerar duplicações.
13. Um alerta só pode ser marcado como entregue depois de confirmação do mecanismo nativo.
14. Falha de permissão ou suporte nativo nunca pode ser apresentada como sucesso.
15. O sistema deve ter um teste de arranque/reconciliação que verifique se a máquina continua **EM_EXECUÇÃO** e se o próximo evento futuro está realmente programado.

### TESTE DE CENÁRIOS CRÍTICOS
O gerador deve testar, antes de produzir o artefacto final: ativar cada uma das 7 categorias; trocar entre categorias permanente/temporária; atravessar 03:00; fechar a aplicação; bloquear o ecrã; terminar o processo; reiniciar o telefone; alterar hora/data/fuso; remover/restaurar permissões; tentar programar o mesmo item duas vezes; e verificar que cada situação preserva o estado correto e deixa apenas os futuros válidos programados.

### CRITÉRIO DE FALHA
Se qualquer teste falhar, **não declarar a aplicação concluída nem fingir que a função está operacional**. Corrigir o problema e repetir os testes.

# FIM DO PROMPT MASTER 3.2
