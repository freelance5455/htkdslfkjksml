-- Silver One - النسخة الجديدة
create table if not exists products (
 id uuid primary key default gen_random_uuid(), code text not null unique,
 category text not null, name text not null, type text, weight numeric(12,2),
 price numeric(12,2) not null default 0, total integer not null default 0,
 qty integer not null default 0, active boolean not null default true, created_at timestamptz not null default now()
);
alter table products add column if not exists active boolean not null default true;
-- السماح بفئة عامة عند الحاجة دون حذف البيانات القديمة
alter table products drop constraint if exists products_category_check;
alter table products add constraint products_category_check check (category in ('silver','watches','perfumes','general'));
create table if not exists invoices (
 id uuid primary key default gen_random_uuid(), invoice_no text not null unique,
 total numeric(12,2) not null default 0, discount numeric(12,2) not null default 0,
 created_at timestamptz not null default now(), created_by uuid references auth.users(id)
);
alter table invoices add column if not exists discount numeric(12,2) not null default 0;
create table if not exists invoice_items (
 id uuid primary key default gen_random_uuid(), invoice_id uuid not null references invoices(id) on delete cascade,
 product_id uuid references products(id), code text not null, name text not null, type text, qty integer not null, price numeric(12,2) not null
);
alter table invoice_items add column if not exists type text;
create table if not exists app_settings(key text primary key,value jsonb not null default '{}'::jsonb);
create table if not exists activity_logs(id uuid primary key default gen_random_uuid(),action text not null,details text,created_by uuid references auth.users(id),created_at timestamptz not null default now());
create table if not exists expenses(id uuid primary key default gen_random_uuid(),title text not null,category text not null default 'أخرى',amount numeric(12,2) not null check(amount>=0),notes text,created_by uuid references auth.users(id),created_at timestamptz not null default now());

alter table products enable row level security; alter table invoices enable row level security; alter table invoice_items enable row level security; alter table app_settings enable row level security; alter table activity_logs enable row level security; alter table expenses enable row level security;
drop policy if exists products_all_authenticated on products; create policy products_all_authenticated on products for all to authenticated using(true) with check(true);
drop policy if exists invoices_all_authenticated on invoices; create policy invoices_all_authenticated on invoices for all to authenticated using(true) with check(true);
drop policy if exists invoice_items_all_authenticated on invoice_items; create policy invoice_items_all_authenticated on invoice_items for all to authenticated using(true) with check(true);
drop policy if exists settings_all_authenticated on app_settings; create policy settings_all_authenticated on app_settings for all to authenticated using(true) with check(true);
drop policy if exists activity_all_authenticated on activity_logs; create policy activity_all_authenticated on activity_logs for all to authenticated using(true) with check(true);
drop policy if exists expenses_all_authenticated on expenses; create policy expenses_all_authenticated on expenses for all to authenticated using(true) with check(true);

create sequence if not exists invoice_no_seq start 1;
create sequence if not exists silver_code_seq start 1;
create sequence if not exists watch_code_seq start 1;
create sequence if not exists perfume_code_seq start 1;

create or replace function next_product_code(p_category text) returns text language plpgsql security definer set search_path=public as $$
declare n bigint; p text; begin
 if p_category='silver' then p:='S'; n:=nextval('silver_code_seq');
 elsif p_category='watches' then p:='W'; n:=nextval('watch_code_seq');
 elsif p_category='perfumes' then p:='P'; n:=nextval('perfume_code_seq');
 else p:='G'; n:=nextval('invoice_no_seq'); end if;
 return p||'-'||lpad(n::text,4,'0'); end; $$;
grant execute on function next_product_code(text) to authenticated;

create or replace function create_sale(p_items jsonb,p_total numeric,p_discount numeric default 0) returns jsonb
language plpgsql security definer set search_path=public as $$
declare item jsonb; pid uuid; q integer; p numeric; v_id uuid; v_no text; r record; calc numeric:=0; d numeric:=greatest(coalesce(p_discount,0),0); begin
 if jsonb_array_length(coalesce(p_items,'[]'::jsonb))=0 then raise exception 'EMPTY_CART'; end if;
 for item in select * from jsonb_array_elements(p_items) loop
   q:=coalesce((item->>'qty')::integer,0); if q<=0 then raise exception 'INVALID_QTY'; end if;
   p:=greatest(coalesce((item->>'price')::numeric,0),0); calc:=calc+(p*q);
   if nullif(item->>'product_id','') is not null then
     pid:=(item->>'product_id')::uuid; select * into r from products where id=pid and active=true for update;
     if not found then raise exception 'PRODUCT_NOT_FOUND'; end if;
     if r.qty<q then raise exception 'INSUFFICIENT_STOCK:%',r.code; end if;
   end if;
 end loop;
 d:=least(d,calc); v_no:='INV-'||lpad(nextval('invoice_no_seq')::text,4,'0');
 insert into invoices(invoice_no,total,discount,created_by) values(v_no,calc-d,d,auth.uid()) returning id into v_id;
 for item in select * from jsonb_array_elements(p_items) loop
   q:=(item->>'qty')::integer; p:=coalesce((item->>'price')::numeric,0); pid:=nullif(item->>'product_id','')::uuid;
   if pid is not null then select code,name,type into r from products where id=pid; else r.code:=coalesce(item->>'code','عام'); r.name:=coalesce(item->>'name','عام'); r.type:=coalesce(item->>'type',''); end if;
   insert into invoice_items(invoice_id,product_id,code,name,type,qty,price) values(v_id,pid,r.code,r.name,r.type,q,p);
   if pid is not null then update products set qty=qty-q where id=pid; end if;
 end loop;
 insert into activity_logs(action,details,created_by) values('sale','تم تسجيل الفاتورة '||v_no||' بقيمة '||round(calc-d,2),auth.uid());
 return jsonb_build_object('id',v_id,'invoice_no',v_no,'total',calc-d); end; $$;
grant execute on function create_sale(jsonb,numeric,numeric) to authenticated;

-- مزامنة العدادات مع الأكواد الموجودة إذا كانت قاعدة البيانات تحتوي بيانات قديمة
select setval('invoice_no_seq',coalesce((select max(nullif(regexp_replace(invoice_no,'[^0-9]','','g'),'')::bigint) from invoices where invoice_no ~ '[0-9]'),0),true);
select setval('silver_code_seq',coalesce((select max(nullif(regexp_replace(code,'[^0-9]','','g'),'')::bigint) from products where category='silver' and code ~ '[0-9]'),0),true);
select setval('watch_code_seq',coalesce((select max(nullif(regexp_replace(code,'[^0-9]','','g'),'')::bigint) from products where category='watches' and code ~ '[0-9]'),0),true);
select setval('perfume_code_seq',coalesce((select max(nullif(regexp_replace(code,'[^0-9]','','g'),'')::bigint) from products where category='perfumes' and code ~ '[0-9]'),0),true);
