-- Silver One - Supabase schema + upgrades
create table if not exists products (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  category text not null check (category in ('silver','watches','perfumes')),
  name text not null,
  type text,
  weight numeric(12,2),
  price numeric(12,2) not null default 0,
  total integer not null default 0,
  qty integer not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

alter table products add column if not exists active boolean not null default true;

create table if not exists invoices (
  id uuid primary key default gen_random_uuid(),
  invoice_no text not null unique,
  total numeric(12,2) not null default 0,
  created_at timestamptz not null default now(),
  created_by uuid references auth.users(id)
);

create table if not exists invoice_items (
  id uuid primary key default gen_random_uuid(),
  invoice_id uuid not null references invoices(id) on delete cascade,
  product_id uuid references products(id),
  code text not null,
  name text not null,
  qty integer not null,
  price numeric(12,2) not null
);

create table if not exists app_settings (
  key text primary key,
  value jsonb not null default '{}'::jsonb
);

create table if not exists activity_logs (
  id uuid primary key default gen_random_uuid(),
  action text not null,
  details text,
  reference_id text,
  amount numeric(12,2),
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists expenses (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  category text not null default 'أخرى',
  amount numeric(12,2) not null check (amount >= 0),
  notes text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create sequence if not exists invoice_no_seq start 1;
create sequence if not exists silver_code_seq start 1;
create sequence if not exists watch_code_seq start 1;
create sequence if not exists perfume_code_seq start 1;

-- Sync sequences with existing data before using them.
select setval('invoice_no_seq', coalesce((select max(nullif(regexp_replace(invoice_no,'[^0-9]','','g'),'')::bigint) from invoices where invoice_no ~ '[0-9]'),0), true);
select setval('silver_code_seq', coalesce((select max(nullif(regexp_replace(code,'[^0-9]','','g'),'')::bigint) from products where category='silver' and code ~ '[0-9]'),0), true);
select setval('watch_code_seq', coalesce((select max(nullif(regexp_replace(code,'[^0-9]','','g'),'')::bigint) from products where category='watches' and code ~ '[0-9]'),0), true);
select setval('perfume_code_seq', coalesce((select max(nullif(regexp_replace(code,'[^0-9]','','g'),'')::bigint) from products where category='perfumes' and code ~ '[0-9]'),0), true);

alter table products enable row level security;
alter table invoices enable row level security;
alter table invoice_items enable row level security;
alter table app_settings enable row level security;
alter table activity_logs enable row level security;
alter table expenses enable row level security;

drop policy if exists products_all_authenticated on products;
create policy products_all_authenticated on products for all to authenticated using (true) with check (true);
drop policy if exists invoices_all_authenticated on invoices;
create policy invoices_all_authenticated on invoices for all to authenticated using (true) with check (true);
drop policy if exists invoice_items_all_authenticated on invoice_items;
create policy invoice_items_all_authenticated on invoice_items for all to authenticated using (true) with check (true);
drop policy if exists settings_all_authenticated on app_settings;
create policy settings_all_authenticated on app_settings for all to authenticated using (true) with check (true);
drop policy if exists activity_logs_all_authenticated on activity_logs;
create policy activity_logs_all_authenticated on activity_logs for all to authenticated using (true) with check (true);
drop policy if exists expenses_all_authenticated on expenses;
create policy expenses_all_authenticated on expenses for all to authenticated using (true) with check (true);

create or replace function next_product_code(p_category text)
returns text
language plpgsql
security definer
set search_path = public
as $$
declare n bigint; prefix text;
begin
  if p_category='silver' then n:=nextval('silver_code_seq'); prefix:='S';
  elsif p_category='watches' then n:=nextval('watch_code_seq'); prefix:='W';
  elsif p_category='perfumes' then n:=nextval('perfume_code_seq'); prefix:='P';
  else raise exception 'INVALID_CATEGORY'; end if;
  return prefix||'-'||lpad(n::text,4,'0');
end; $$;
grant execute on function next_product_code(text) to authenticated;

create or replace function create_sale(p_items jsonb, p_total numeric)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  item jsonb; pid uuid; q integer; p numeric; v_invoice_id uuid; v_no text; r record; calc_total numeric:=0;
begin
  if p_items is null or jsonb_array_length(p_items)=0 then raise exception 'EMPTY_CART'; end if;
  for item in select * from jsonb_array_elements(p_items) loop
    pid := (item->>'product_id')::uuid; q := (item->>'qty')::integer; p := (item->>'price')::numeric;
    if q is null or q <= 0 then raise exception 'INVALID_QTY'; end if;
    select * into r from products where id=pid and active=true for update;
    if not found then raise exception 'PRODUCT_NOT_FOUND'; end if;
    if r.qty < q then raise exception 'INSUFFICIENT_STOCK:%',r.code; end if;
    calc_total := calc_total + (p*q);
  end loop;

  v_no := 'INV-'||lpad(nextval('invoice_no_seq')::text,4,'0');
  insert into invoices(invoice_no,total,created_by) values(v_no,round(calc_total,2),auth.uid()) returning id into v_invoice_id;

  for item in select * from jsonb_array_elements(p_items) loop
    pid := (item->>'product_id')::uuid; q := (item->>'qty')::integer; p := (item->>'price')::numeric;
    select code,name into r from products where id=pid;
    insert into invoice_items(invoice_id,product_id,code,name,qty,price) values(v_invoice_id,pid,r.code,r.name,q,p);
    update products set qty=qty-q where id=pid;
  end loop;

  insert into activity_logs(action,details,reference_id,amount,created_by)
  values('بيع','إصدار فاتورة '||v_no,v_no,round(calc_total,2),auth.uid());
  return jsonb_build_object('id',v_invoice_id,'invoice_no',v_no,'total',round(calc_total,2));
end; $$;
grant execute on function create_sale(jsonb,numeric) to authenticated;

create or replace function add_activity(p_action text,p_details text,p_reference_id text default null,p_amount numeric default null)
returns void language plpgsql security definer set search_path=public as $$
begin insert into activity_logs(action,details,reference_id,amount,created_by) values(p_action,p_details,p_reference_id,p_amount,auth.uid()); end; $$;
grant execute on function add_activity(text,text,text,numeric) to authenticated;
