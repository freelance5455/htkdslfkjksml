-- Supabase SQL для реального Топ 100
-- 1) Открой Supabase -> SQL Editor -> New query
-- 2) Вставь всё содержимое этого файла и нажми Run.

create table if not exists public.players (
  id text primary key,
  name text not null check (char_length(name) between 3 and 10),
  score bigint not null default 0 check (score >= 0),
  updated_at timestamptz not null default now()
);

alter table public.players enable row level security;

-- Для игры: любой посетитель может читать рейтинг.
create policy "public read leaderboard"
on public.players for select
to anon, authenticated
using (true);

-- Игрок может создать/изменить запись.
-- ВАЖНО: для полностью защищённой от читеров версии лучше вынести изменение score
-- в Edge Function/RPC и добавить авторизацию. Для простого MVP это работает.

-- ID = никнейм. Два игрока не могут одновременно использовать одинаковый ник.
create policy "public insert players"
on public.players for insert
to anon, authenticated
with check (true);

create policy "public update players"
on public.players for update
to anon, authenticated
using (true)
with check (score >= 0 and char_length(name) between 3 and 10);

-- Включаем Realtime для таблицы.
alter publication supabase_realtime add table public.players;
