-- À coller dans Supabase > SQL Editor > Run
create table profiles(
  id uuid primary key references auth.users(id) on delete cascade,
  phone text unique not null, name text not null,
  role text default 'TL ACQUISITION', zone text default '',
  is_admin boolean not null default false, active boolean not null default true,
  created_at timestamptz default now());
create table remontees(
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id),
  type text not null, fields jsonb not null default '[]', phone text,
  status int not null default 0, at bigint not null, by_phone text,
  created_at timestamptz default now());
alter table profiles enable row level security;
alter table remontees enable row level security;
create or replace function is_admin() returns boolean language sql security definer set search_path=public stable as
$$ select coalesce((select is_admin and active from profiles where id=auth.uid()),false) $$;
create policy p_sel on profiles for select using (id=auth.uid() or is_admin());
create policy p_ins on profiles for insert with check (is_admin());
create policy p_upd on profiles for update using (is_admin()) with check (is_admin());
create policy r_sel on remontees for select using (user_id=auth.uid() or is_admin());
create policy r_ins on remontees for insert with check (user_id=auth.uid());
create policy r_upd on remontees for update using (is_admin());

-- ÉTAPE ADMIN : après avoir créé l'utilisateur 800800100@estla.app dans Authentication > Users
insert into profiles(id,phone,name,role,zone,is_admin)
select id,'800800100','Admin','ADMIN','ORDC-POL-GK-084',true from auth.users where email='800800100@estla.app';
