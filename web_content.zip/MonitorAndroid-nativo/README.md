# Monitor — projeto Android nativo

## Como funciona

Ao abrir, o app explica as ações e pede consentimento. Em seguida solicita a permissão de notificações (Android 13+) e a permissão especial de sobreposição nas telas do Android. Depois que as permissões forem concedidas, o app automaticamente adiciona 30 imagens à pasta `Pictures/Monitor`, define `monstro2.png` como papel de parede, inicia as janelas flutuantes e o áudio de interferência em um serviço Android em primeiro plano e fecha sua própria tela.

A simulação dura até cinco minutos. A notificação persistente tem a ação **Parar**. Ao terminar ou parar, as janelas e o áudio são encerrados; as imagens e o papel de parede permanecem. As alterações na galeria e no papel de parede são informadas na tela de consentimento antes de começar.

O arquivo `app/src/main/assets/index.html` e as imagens estão incluídos como assets do APK. Os efeitos executados depois que a tela fecha são nativos no Android (serviço, sobreposições e áudio), não dependem de manter o WebView aberto.

## Compilar

1. Extraia o ZIP.
2. Abra a pasta `MonitorAndroid-nativo` no Android Studio.
3. Aguarde a sincronização do Gradle (JDK 17 e Android SDK 35).
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

Este projeto foi atualizado, mas não foi compilado nem testado em um aparelho nesta sessão. O comportamento pode variar conforme a versão do Android e as regras do fabricante.


## Important: test as an installed Android APK
Opening `index.html` in a browser will NOT request Android permissions or create system overlay windows. Build and install the APK, then tap START. The app requests notification and overlay permissions, then starts the five-minute simulation. Use the persistent notification Stop action to end it early. The gallery images and wallpaper remain after the simulation. The prank message is in English and explicitly says it is a simulation.
