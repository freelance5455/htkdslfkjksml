package com.monitor.simulador;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import java.io.*;
import java.util.*;

public class OverlayService extends Service {
  private static final long DURATION_MS = 5 * 60 * 1000L;
  private WindowManager windowManager;
  private Handler handler;
  private final ArrayList<View> windows = new ArrayList<>();
  private final Random random = new Random();
  private long endAt;
  private boolean running = false;
  private Thread soundThread;
  private volatile boolean soundRunning = false;
  private final Runnable spawner = new Runnable() {
    @Override public void run() {
      if (!running) return;
      if (System.currentTimeMillis() >= endAt) { stopSelf(); return; }
      if (Settings.canDrawOverlays(OverlayService.this) && windows.size() < 4) addWindow();
      handler.postDelayed(this, 6500);
    }
  };

  @Override public void onCreate() {
    super.onCreate();
    windowManager = (WindowManager)getSystemService(WINDOW_SERVICE);
    handler = new Handler(Looper.getMainLooper());
  }

  @Override public int onStartCommand(Intent intent, int flags, int startId) {
    startForeground(42, buildNotification());
    if (!running) {
      running = true;
      endAt = System.currentTimeMillis() + DURATION_MS;
      startStaticSound();
      handler.post(spawner);
      handler.postDelayed(() -> stopSelf(), DURATION_MS);
    }
    return START_NOT_STICKY;
  }

  private Notification buildNotification() {
    String channel = "monitor_effects";
    if (Build.VERSION.SDK_INT >= 26) {
      NotificationChannel c = new NotificationChannel(channel, "Monitor — simulação ativa", NotificationManager.IMPORTANCE_LOW);
      ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
    }
    Intent stop = new Intent(this, StopReceiver.class);
    PendingIntent pi = PendingIntent.getBroadcast(this, 1, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, channel) : new Notification.Builder(this);
    return b.setSmallIcon(android.R.drawable.ic_dialog_info)
      .setContentTitle("Monitor — simulation active")
      .setContentText("Ends automatically in 5 minutes. Tap Stop to end it now.")
      .addAction(android.R.drawable.ic_media_pause, "Stop", pi)
      .setOngoing(true).build();
  }

  private void startStaticSound() {
    soundRunning = true;
    soundThread = new Thread(() -> {
      final int sampleRate = 22050;
      int min = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
      if (min <= 0) return;
      AudioTrack track = null;
      try {
        AudioAttributes attrs = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
        AudioFormat format = new AudioFormat.Builder().setSampleRate(sampleRate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build();
        track = new AudioTrack(attrs, format, Math.max(min, 4096), AudioTrack.MODE_STREAM, AudioTrack.AUDIO_SESSION_ID_GENERATE);
        track.play();
        short[] buffer = new short[2048];
        Random noise = new Random();
        while (soundRunning) {
          for (int i=0; i<buffer.length; i++) {
            double hiss = (noise.nextDouble()*2.0-1.0) * 0.20;
            double hum = Math.sin((System.nanoTime()/1.0e9 + i/(double)sampleRate) * 2*Math.PI*47) * 0.055;
            double burst = noise.nextDouble() > 0.992 ? (noise.nextDouble()*2-1)*0.45 : 0;
            buffer[i] = (short)(Math.max(-1, Math.min(1, hiss + hum + burst)) * 32767);
          }
          track.write(buffer, 0, buffer.length);
        }
      } catch (Exception ignored) {
      } finally {
        if (track != null) { try { track.pause(); track.flush(); track.release(); } catch (Exception ignored) {} }
      }
    }, "MonitorStaticAudio");
    soundThread.start();
  }

  private void addWindow() {
    try {
      FrameLayout frame = new FrameLayout(this);
      ImageView image = new ImageView(this);
      String asset = random.nextBoolean() ? "monstro.png" : "caveira.png";
      try (InputStream in = getAssets().open(asset)) { image.setImageBitmap(BitmapFactory.decodeStream(in)); }
      image.setScaleType(ImageView.ScaleType.FIT_CENTER);
      frame.addView(image, new FrameLayout.LayoutParams(-1, -1));
      TextView prank = new TextView(this);
      prank.setText("YOU'VE BEEN HACKED!\nHAHAHA! JUST KIDDING — IT'S A SIMULATION.");
      prank.setTextColor(Color.WHITE);
      prank.setTextSize(11);
      prank.setGravity(Gravity.CENTER);
      prank.setPadding(5, 5, 5, 5);
      prank.setBackgroundColor(0xdd990018);
      FrameLayout.LayoutParams prankParams = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
      frame.addView(prank, prankParams);
      TextView close = new TextView(this);
      close.setText("×"); close.setTextColor(Color.WHITE); close.setTextSize(25); close.setGravity(Gravity.CENTER); close.setBackgroundColor(0xcc990000);
      FrameLayout.LayoutParams closeParams = new FrameLayout.LayoutParams(58,58,Gravity.RIGHT|Gravity.TOP);
      frame.addView(close, closeParams); close.setOnClickListener(v -> removeWindow(frame));
      int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
      WindowManager.LayoutParams params = new WindowManager.LayoutParams(220+random.nextInt(80),220+random.nextInt(80),type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
      params.gravity = Gravity.TOP|Gravity.LEFT;
      params.x = random.nextInt(Math.max(1,getResources().getDisplayMetrics().widthPixels-240));
      params.y = 100+random.nextInt(Math.max(1,getResources().getDisplayMetrics().heightPixels-350));
      windowManager.addView(frame, params); windows.add(frame);
      frame.setOnTouchListener(new View.OnTouchListener() {
        float startX,startY; int originalX,originalY;
        public boolean onTouch(View v, MotionEvent event) {
          if (event.getAction()==MotionEvent.ACTION_DOWN) { startX=event.getRawX(); startY=event.getRawY(); originalX=params.x; originalY=params.y; return true; }
          if (event.getAction()==MotionEvent.ACTION_MOVE) { params.x=originalX+(int)(event.getRawX()-startX); params.y=originalY+(int)(event.getRawY()-startY); try { windowManager.updateViewLayout(frame,params); } catch(Exception ignored) {} return true; }
          return false;
        }
      });
      handler.postDelayed(() -> removeWindow(frame), 18000);
    } catch (Exception ignored) {}
  }

  private void removeWindow(View view) {
    try { windowManager.removeView(view); } catch (Exception ignored) {}
    windows.remove(view);
  }

  @Override public void onDestroy() {
    running = false;
    soundRunning = false;
    if (handler != null) handler.removeCallbacksAndMessages(null);
    for (View view : new ArrayList<>(windows)) removeWindow(view);
    stopForeground(true);
    super.onDestroy();
  }

  @Override public IBinder onBind(Intent intent) { return null; }
}
