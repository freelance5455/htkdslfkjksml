package com.monitor.simulador;
import android.content.*;
public class StopReceiver extends BroadcastReceiver { @Override public void onReceive(Context c,Intent i){ c.stopService(new Intent(c,OverlayService.class)); } }
