package com.monitor.simulador;

import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import android.graphics.Color;
import android.view.Gravity;
import java.io.*;

public class MainActivity extends Activity {
  private static final int REQ_NOTIFICATIONS = 78;
  private static final int REQ_OVERLAY = 77;
  private boolean started = false;

  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    getWindow().setFlags(1024, 1024);
    showStartScreen();
  }

  // Single-action launcher screen. The Game Jolt listing describes the simulation;
  // the START button is the user's deliberate action to begin it.
  private void showStartScreen() {
    LinearLayout root = new LinearLayout(this);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setGravity(Gravity.CENTER);
    root.setPadding(28, 28, 28, 28);
    root.setBackgroundColor(Color.rgb(8, 0, 5));

    TextView title = new TextView(this);
    title.setText("MONITOR");
    title.setTextColor(Color.rgb(255, 35, 70));
    title.setTextSize(32);
    title.setGravity(Gravity.CENTER);
    title.setLetterSpacing(0.18f);
    root.addView(title, new LinearLayout.LayoutParams(-1, -2));

    TextView subtitle = new TextView(this);
    subtitle.setText("HORROR SIMULATION\n5 MINUTES");
    subtitle.setTextColor(Color.LTGRAY);
    subtitle.setTextSize(14);
    subtitle.setGravity(Gravity.CENTER);
    LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
    sp.setMargins(0, 18, 0, 34);
    root.addView(subtitle, sp);

    Button start = new Button(this);
    start.setText("START");
    start.setTextSize(18);
    start.setOnClickListener(v -> requestNextPermission());
    LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
    root.addView(start, bp);

    TextView note = new TextView(this);
    note.setText("A simulated prank. Android will ask for the required permissions.\nYou can stop it from its notification.");
    note.setTextColor(Color.GRAY);
    note.setTextSize(11);
    note.setGravity(Gravity.CENTER);
    LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
    np.setMargins(0, 24, 0, 0);
    root.addView(note, np);

    setContentView(root);
  }

  private void requestNextPermission() {
    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
      requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
      return;
    }
    requestOverlayIfNeeded();
  }

  private void requestOverlayIfNeeded() {
    if (!Settings.canDrawOverlays(this)) {
      new AlertDialog.Builder(this)
        .setTitle("Permitir janelas sobre outros apps")
        .setMessage("Ative a permissão de sobreposição para as abas flutuantes da simulação.")
        .setCancelable(false)
        .setNegativeButton("Cancelar", (d,w) -> finish())
        .setPositiveButton("Abrir configurações", (d,w) -> startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())), REQ_OVERLAY))
        .show();
      return;
    }
    startSimulation();
  }

  @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
    super.onRequestPermissionsResult(requestCode, permissions, results);
    if (requestCode == REQ_NOTIFICATIONS) {
      if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) requestOverlayIfNeeded();
      else new AlertDialog.Builder(this).setTitle("Permissão necessária").setMessage("Sem notificações, não é possível mostrar o controle para parar a simulação. Nada foi iniciado.").setPositiveButton("OK", (d,w) -> finish()).show();
    }
  }

  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (requestCode == REQ_OVERLAY) {
      if (Settings.canDrawOverlays(this)) startSimulation();
      else new AlertDialog.Builder(this).setMessage("A permissão de sobreposição não foi concedida. A simulação não foi iniciada.").setPositiveButton("OK", (d,w) -> finish()).show();
    }
  }

  private void startSimulation() {
    if (started) return;
    started = true;
    try {
      saveThirtyImages();
      setMonsterWallpaper();
      Intent service = new Intent(this, OverlayService.class);
      if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
      Toast.makeText(this, "Simulação iniciada. Ela termina automaticamente em 5 minutos.", Toast.LENGTH_LONG).show();
      finish();
    } catch (Exception e) {
      started = false;
      new AlertDialog.Builder(this).setTitle("Não foi possível iniciar").setMessage("Erro: " + e.getMessage() + "\nA simulação não foi iniciada.").setPositiveButton("OK", (d,w) -> finish()).show();
    }
  }

  private void saveThirtyImages() throws IOException {
    for (int n=1; n<=30; n++) {
      ContentValues values = new ContentValues();
      values.put(MediaStore.Images.Media.DISPLAY_NAME, String.format(java.util.Locale.US, "galeria_%02d.png", n));
      values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
      if (Build.VERSION.SDK_INT >= 29) values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Monitor");
      Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
      if (uri == null) throw new IOException("O Android não permitiu criar as imagens na galeria.");
      try (InputStream in = getAssets().open("galeria.png"); OutputStream out = getContentResolver().openOutputStream(uri)) {
        if (out == null) throw new IOException("Não foi possível gravar uma imagem.");
        byte[] buffer = new byte[8192]; int count;
        while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
      }
    }
  }

  private void setMonsterWallpaper() throws IOException {
    try (InputStream in = getAssets().open("monstro2.png")) {
      android.app.WallpaperManager.getInstance(this).setStream(in);
    }
  }
}
