const $=id=>document.getElementById(id),J=JSON,LS=localStorage;
const ld=(k,d)=>{try{return J.parse(LS.getItem(k))||d}catch(e){return d}};
const put=(k,v)=>{try{LS.setItem(k,J.stringify(v))}catch(e){}};
let C=Object.assign({disc:60,def:30,tm:1,calm:0},ld('kh_c',{})),S=ld('kh_s',null),U={v:'menu',n:5,nm:[],g:0,w:[],t:0},iv;
if(S&&!Array.isArray(S.P))S=null;
const RL={
sab:{n:'خرابکار',i:'🕶️',d:'هر شب یک خرابکاری: تبعید شبانه (۲ اعتبار مشترک تیم)، خرابکاری رفتاری یا شهری.'},
dec:{n:'فریبکار',i:'🎭',d:'یک بار رأی یک نفر را بی‌اثر کن و حداکثر دو بار خبر جعلی بفرست.'},
det:{n:'کارآگاه',i:'🔍',d:'از شب دوم یک نفر را استعلام کن و خبر را به دیگری بده. خرابکار نیاز به دو استعلام دارد.'},
rep:{n:'تعمیرکار',i:'🛠️',d:'هر شب یک نفر را از تبعید شبانه نجات بده.'},
trk:{n:'ردیاب',i:'📡',d:'دو اعتبار برای خنثی‌سازی خرابکاری شهری.'},
grd:{n:'نگهبان',i:'💂',d:'هر شب یک نفر را بررسی کن؛ اگر خرابکار یا فریبکار بود، آن شب عملیاتش متوقف می‌شود.'},
cit:{n:'شهروند',i:'🏠',d:'تحلیل کن، بحث کن، رأی بده و خرابکاران را پیدا کن.'}};
const BEH=[{n:'زبان بیرون',m:'امروز باید با زبان بیرون از دهان صحبت کند. (دستی)'},{n:'زبان برعکس',m:'امروز باید منظور مخالف را بگوید. (دستی)'},{n:'مأموریت الکی',m:'به مأموریت رفته و امروز در بحث و رأی نیست.'}];
const CITY=[{n:'قطع برق',m:'🔌 برق شهر قطع شد! زمان بحث امروز نصف می‌شود.'},{n:'شایعه‌پراکنی',m:'🗣️ شایعه‌ای در شهر پیچید! (دستی: امروز هر نفر فقط یک اتهام می‌تواند بزند)'}];
const BASE=['sab','dec','rep','det','trk','grd'];
const mf=r=>r==='sab'||r==='dec';
const combo=n=>{const l=n<5?['sab','rep','det'].slice(0,n-1):BASE.slice(0,Math.min(n-1,6));while(l.length<n)l.push('cit');return l};
const valid=n=>{const m=combo(n).filter(mf).length;return n>=3&&n<=10&&m>=1&&m<n-m};
const sh=a=>{a=[...a];for(let i=a.length;i>1;){const j=Math.random()*i--|0;[a[i],a[j]]=[a[j],a[i]]}return a};
const newsTxt=(n,v)=>`«${n}» ${v==='mf'?'عضو تیم خرابکاری است.':'بی‌گناه به نظر می‌رسد.'}`;
function newGame(nm){const R=sh(combo(nm.length)),ci=R.map((r,i)=>r==='cit'?i:-1).filter(i=>i>=0),my=ci[Math.random()*ci.length|0];
return{ph:'deal',n:0,P:nm.map((x,i)=>({i,nm:x,r:R[i],my:i===my,al:1,df:0,away:0})),ex:2,nul:1,fk:2,tc:2,insp:{},Q:nm.map((_,i)=>i),H:[],mq:[],N:{act:[]},V1:{},V2:{},nt:null,dim:0,st:{ex:0,neut:0,sab:0}}}
// ===== موتور قوانین =====
function inquire(s,t){const c=s.insp[t]=(s.insp[t]||0)+1,r=s.P[t].r;return r==='dec'||(r==='sab'&&c>=2)?'mf':'clean'}
function resolve(s){
const P=s.P,L=s.N.act,r={ex:null,pub:[],mail:[],beh:[],cut:0,saved:0};
const K=k=>L.filter(a=>a.k===k);
const bl=new Set(K('grd').filter(a=>P[a.p].al&&P[a.t].al&&mf(P[a.t].r)).map(a=>a.t));
const ok=a=>P[a.p].al&&!bl.has(a.p)&&(a.t==null||P[a.t].al);
const sv=new Set(K('rep').filter(ok).map(a=>a.t)),tu=K('trk').some(a=>a.use&&ok(a)&&s.tc>0);
for(const a of K('sab').filter(ok)){
 if(a.m==='atk'&&s.ex>0){if(sv.has(a.t))r.saved++;else{r.ex=a.t;s.ex--}}
 else if(a.m==='beh'){r.beh.push({t:a.t,v:a.v});if(a.v===2)P[a.t].away=1}
 else if(a.m==='city'){if(tu){r.cut++;s.tc--}else{r.pub.push(CITY[a.v].m);if(a.v===0)s.dim=1}}}
for(const a of K('dec').filter(ok)){
 if(a.m==='nul'&&s.nul>0){s.nul--;s.nt=a.t}
 if(a.m==='fk'&&s.fk>0){s.fk--;if(!mf(P[a.t].r))r.mail.push({to:a.t,txt:newsTxt(P[a.x].nm,a.v),fake:1})}}
for(const a of K('det').filter(ok))if(a.to!=null&&P[a.to].al&&!mf(P[a.to].r))r.mail.push({to:a.to,txt:a.news,fake:0});
if(r.ex!=null)P[r.ex].al=0;
return r}
function win(s){const a=s.P.filter(p=>p.al),m=a.filter(p=>mf(p.r)).length;return m===0?'c':m>=a.length-m?'m':null}
function tally(s){const t={};for(const p in s.V1){if(p==s.nt)continue;const x=s.V1[p];t[x]=(t[x]||0)+1}
const mx=Math.max(0,...Object.values(t)),top=Object.keys(t).filter(k=>t[k]===mx).map(Number);
let d=null;if(top.length===1)d=top[0];else{const f=top.filter(i=>s.P[i].df);if(f.length===1)d=f[0]}
return{t,d}}
// ===== جریان =====
const F=[],E=s=>String(s).replace(/[&<>"']/g,c=>'&#'+c.charCodeAt(0)+';');
const b=(l,fn,c='',d=0)=>(F.push(fn),`<button class="${c}" ${d?'disabled':''} onclick="run(${F.length-1})">${l}</button>`);
const run=i=>{if(U.lk)return;U.lk=1;setTimeout(()=>U.lk=0,300);F[i]()};
const fm=t=>(t/60|0)+':'+String(t%60).padStart(2,'0');
const al=()=>S.P.filter(p=>p.al),vt=()=>al().filter(p=>!p.away).map(p=>p.i);
const T=(t,x)=>`<div class=card><h2>${t}</h2>${x}</div>`;
const timer=s=>{clearInterval(iv);U.t=s;U.run=0};
const tg=()=>{U.run=!U.run;clearInterval(iv);if(U.run)iv=setInterval(()=>{U.t>0&&U.t--;const e=$('tm');e&&(e.textContent=fm(U.t));if(!U.t){clearInterval(iv);U.run=0;navigator.vibrate&&navigator.vibrate(300)}},1000);render()};
const go=ph=>{S.ph=ph;U.g=0;U.w=[];if(ph==='disc')timer(Math.round(C.disc*(S.dim?.5:1)));if(ph==='def')timer(C.def)};
const go2=v=>{U.v=v;U.g=0;render()};
const to=ph=>{go(ph);render()};
const adv=cb=>{S.Q.shift();U.g=0;U.w=[];if(!S.Q.length)cb();render()};
function startNight(){S.n++;S.P.forEach(p=>p.away=0);S.dim=0;S.nt=null;S.N={act:[]};S.Q=al().map(p=>p.i);S.ph='dusk';U.g=0}
function endNight(){const r=resolve(S),n=S.n;S.R=r;S.st.neut+=r.saved+r.cut;S.st.sab+=(r.ex!=null?1:0)+r.pub.length+r.beh.length;
if(r.ex!=null){S.st.ex++;S.H.push(`شب ${n}: «${S.P[r.ex].nm}» تبعید شد.`)}else S.H.push(`شب ${n}: کسی تبعید نشد.`);
r.pub.forEach(m=>S.H.push(`شب ${n}: ${m}`));
if(S.W=win(S)){S.ph='end';return}
S.Q=[...new Set(r.mail.filter(m=>S.P[m.to].al).map(m=>m.to))];S.mq=r.mail;S.ph='morning'}
const gate=(p,body,btn)=>U.g?`<div class=card>${body}</div>${btn}`:`<div class=card style="text-align:center"><div class=sub>گوشی را بدهید به</div><h1>${E(p.nm)}</h1><div class=sub>فقط خودش نگاه کند</div>${b('من '+E(p.nm)+' هستم؛ نمایش',()=>{U.g=1;render()},'p')}</div>`;
const start=()=>{const nm=[...Array(U.n)].map((_,i)=>U.nm[i]||'بازیکن '+(i+1));if(new Set(nm).size<nm.length)return alert('نام‌ها باید متفاوت باشند.');S=newGame(nm);U.v='game';U.g=0;render()};
const G=[['هدف','شهروندان باید همه خرابکاران را تبعید کنند؛ خرابکاران باید تعدادشان را به برابر یا بیشتر از شهروندان زنده برسانند.'],
['شب','گوشی به نوبت بین همه بازیکنان زنده می‌چرخد تا کسی نفهمد چه کسی چه نقشی دارد. هر نفر فقط صفحهٔ خودش را می‌بیند و آن را پنهان می‌کند. نتیجه صبح اعلام می‌شود و همهٔ عملیات‌ها با یک تابع ثابت حل می‌شوند.'],
['روز','بحث، رأی مخفی به مظنون، دفاعیه و رأی «تبعید شود / نشود». اگر آرا مساوی باشد فقط وقتی یکی از برابرها قبلاً دفاعیه رفته باشد او دفاع می‌کند؛ وگرنه دادگاه بدون تبعید تمام می‌شود.'],
['خرابکاری‌ها','تبعید شبانه (خودکار، ۲ اعتبار مشترک)، مأموریت الکی و قطع برق (خودکار)، زبان بیرون، زبان برعکس و شایعه (اجرای دستی توسط بازیکنان).'],
['خبر','فریبکار خبر جعلی هم‌قالب با خبر واقعی می‌فرستد. خبری که به خرابکار برسد بی‌اثر است و کارآگاه فاش نمی‌شود. استعلام اول روی خرابکار «بی‌گناه» نشان می‌دهد و استعلام دوم تأیید می‌کند.'],
['گوشی مشترک','هر بار فقط نفرِ نوبت نگاه کند و بعد از «مخفی کن» گوشی را به نفر بعد بدهد. داده‌ها روی همین دستگاه ذخیره می‌شوند و بدون اینترنت کار می‌کنند.']];
// ===== صفحه‌ها =====
const V={
menu:()=>`<h1 style="font-size:52px;margin-top:20px">خرابکار</h1><p class=sub>به هیچ‌کس اعتماد نکن!</p><p class=sub>● آفلاین؛ بدون نیاز به اینترنت</p>`+(S?b('ادامه بازی ('+(S.ph==='end'?'نتیجه':S.ph==='deal'?'توزیع نقش':'شب '+S.n)+')',()=>go2('game'),'p'):'')+b('شروع بازی جدید',()=>{if(!S||confirm('بازی جاری حذف می‌شود. ادامه؟'))go2('setup')},S?'':'p')+b('راهنما',()=>go2('guide'))+b('تنظیمات',()=>go2('set'))+(S?b('پاک کردن بازی و اطلاعات محرمانه',()=>{if(confirm('بازی جاری و نقش‌ها پاک شوند؟')){S=null;render()}},'d'):''),
setup(){const n=U.n,cnt={};combo(n).forEach(r=>cnt[r]=(cnt[r]||0)+1);
return T('بازیکنان',`<div class=g>${b('−',()=>{U.n=Math.max(3,n-1);render()})}${b('+',()=>{U.n=Math.min(10,n+1);render()})}</div><div class=sub>تعداد: ${n}</div>`+[...Array(n)].map((_,i)=>`<input placeholder="بازیکن ${i+1}" value="${E(U.nm[i]||'')}" maxlength=14 onchange="U.nm[${i}]=this.value.trim()">`).join(''))+T('ترکیب نقش‌ها',Object.entries(cnt).map(([r,c])=>`<div>${RL[r].i} ${RL[r].n} × ${c}${r==='cit'?' (یکی شهردار)':''}</div>`).join('')+(valid(n)?'':'<p class=err>ترکیب نامعتبر است؛ تعداد بازیکنان را اصلاح کنید.</p>'))+b('شروع بازی',start,'p',!valid(n))+b('بازگشت',()=>go2('menu'))},
set(){const st=(k,l,mn,mx,sp)=>`<div class=card><div>${l}: <b>${C[k]} ثانیه</b></div><div class=g>${b('−',()=>{C[k]=Math.max(mn,C[k]-sp);put('kh_c',C);render()})}${b('+',()=>{C[k]=Math.min(mx,C[k]+sp);put('kh_c',C);render()})}</div></div>`;
const tg2=(k,l)=>b(l+': '+(C[k]?'روشن':'خاموش'),()=>{C[k]=C[k]?0:1;put('kh_c',C);render()});
return '<h2>تنظیمات</h2>'+st('disc','زمان بحث',15,300,15)+st('def','زمان دفاع',10,120,10)+tg2('tm','تایمرها')+tg2('calm','کاهش حرکت')+b('بازگشت به پیش‌فرض',()=>{C={disc:60,def:30,tm:1,calm:0};put('kh_c',C);render()})+b('بازگشت',()=>go2('menu'),'p')},
guide:()=>'<h2>راهنما</h2>'+G.map(([t,x])=>`<details class=card><summary>${t}</summary><p>${x}</p></details>`).join('')+`<details class=card><summary>نقش‌ها</summary>${Object.values(RL).map(r=>`<p>${r.i} <b>${r.n}</b>: ${r.d}</p>`).join('')}<p>🏛️ <b>شهردار</b>: فقط یک عنوان؛ بدون قدرت ویژه.</p></details>`+b('بازگشت',()=>go2('menu'),'p'),
deal(){const p=S.P[S.Q[0]],r=RL[p.r],tm=S.P.filter(x=>mf(x.r)&&x!==p).map(x=>E(x.nm)).join('، ');
return gate(p,`<div style="text-align:center;display:flex;flex-direction:column;gap:8px"><div style="font-size:64px">${r.i}</div><h2>${r.n}${p.my?' (شهردار)':''}</h2><span class=tag>${mf(p.r)?'تیم خرابکاری':'تیم شهروندی'}</span><p>${r.d}</p>${mf(p.r)?`<p>هم‌تیمی: ${tm||'ندارد'}</p>`:''}</div>`,b('متوجه شدم؛ مخفی کن',()=>adv(startNight),'p'))},
dusk:()=>`<div class="card dusk" style="text-align:center"><div style="font-size:56px">🌃</div><h2>شب ${S.n}</h2><p>شهر به خواب می‌رود... همه چشم‌ها بسته.</p><p class=sub>گوشی به ترتیب بین بازیکنان زنده می‌چرخد.</p></div>`+b('شروع نوبت‌ها',()=>to('night'),'p'),
night(){const p=S.P[S.Q[0]],i=p.i,r=p.r,w=U.w,ex=S.N.act.find(a=>a.p===i);
const cm=a=>{S.N.act=S.N.act.filter(x=>x.p!==i);S.N.act.push({p:i,...a});adv(endNight)};
const pick=(f,s=1)=>al().filter(x=>s||x.i!==i).map(x=>b(E(x.nm),()=>f(x.i))).join('');
const st=a=>{U.w=a;render()};
let h='<p>امشب کاری نداری؛ چشم‌هایت را ببند.</p>',bt=b('تمام؛ مخفی کن',()=>adv(endNight),'p');
if(r==='grd'){h='<h2>چه کسی را بررسی می‌کنی؟</h2>'+pick(t=>cm({k:'grd',t}),0);bt=''}
else if(r==='rep'){h='<h2>چه کسی را نجات می‌دهی؟</h2>'+pick(t=>cm({k:'rep',t}));bt=''}
else if(r==='trk'&&S.tc>0){h=`<h2>اعتبار ردیاب: ${S.tc}</h2><p>خرابکاری شهری امشب خنثی شود؟</p>`+b('بله، مصرف اعتبار',()=>cm({k:'trk',use:1}),'p')+b('نه',()=>cm({k:'trk',use:0}));bt=''}
else if(r==='det'&&S.n>1){bt='';
 if(ex&&ex.res){const q=S.P[ex.t];h=`<h2>نتیجه استعلام</h2><p>${E(newsTxt(q.nm,ex.res))}</p><p>خبر را به چه کسی منتقل می‌کنی؟</p>`+pick(rc=>cm({k:'det',t:ex.t,res:ex.res,to:rc,news:newsTxt(q.nm,ex.res)}),0)+b('نزد خودم می‌ماند',()=>cm({k:'det',t:ex.t,res:ex.res}))}
 else h='<h2>چه کسی را استعلام می‌کنی؟</h2>'+pick(t=>{S.N.act.push({p:i,k:'det',t,res:inquire(S,t)});render()},0)}
else if(r==='dec'){bt='';
 if(!w.length)h='<h2>اقدام امشب؟</h2>'+(S.nul>0?b('بی‌اثر کردن رأی یک نفر',()=>st(['nul'])):'')+(S.fk>0?b('خبر جعلی ('+S.fk+' باقی)',()=>st(['fk'])):'')+b('کاری نمی‌کنم',()=>cm({k:'dec',m:'none'}));
 else if(w[0]==='nul')h='<h2>رأی چه کسی بی‌اثر شود؟</h2>'+pick(t=>cm({k:'dec',m:'nul',t}),0);
 else if(w.length===1)h='<h2>خبر برای چه کسی ارسال شود؟</h2>'+pick(t=>st(['fk',t]),0);
 else if(w.length===2)h='<h2>خبر درباره چه کسی است؟</h2>'+pick(x=>st(['fk',w[1],x]));
 else{const q=E(S.P[w[2]].nm);h='<h2>محتوای خبر؟</h2>'+b('«'+q+'» خرابکار است',()=>cm({k:'dec',m:'fk',t:w[1],x:w[2],v:'mf'}))+b('«'+q+'» بی‌گناه است',()=>cm({k:'dec',m:'fk',t:w[1],x:w[2],v:'clean'}))}
 if(w.length)h+=b('بازگشت',()=>st([]))}
else if(r==='sab'){bt='';
 if(!w.length)h='<h2>خرابکاری امشب؟</h2>'+(S.ex>0?b('تبعید شبانه ('+S.ex+' اعتبار)',()=>st(['atk'])):'')+b('خرابکاری رفتاری',()=>st(['beh']))+b('خرابکاری شهری',()=>st(['city']))+b('کاری نمی‌کنم',()=>cm({k:'sab',m:'none'}));
 else if(w[0]==='atk')h='<h2>هدف تبعید؟</h2>'+pick(t=>cm({k:'sab',m:'atk',t}),0);
 else if(w[0]==='city')h='<h2>کدام خرابکاری؟</h2>'+CITY.map((x,v)=>b(x.n,()=>cm({k:'sab',m:'city',v}))).join('');
 else if(w.length===1)h='<h2>نوع خرابکاری؟</h2>'+BEH.map((x,v)=>b(x.n,()=>st(['beh',v]))).join('');
 else h='<h2>هدف؟</h2>'+pick(t=>cm({k:'sab',m:'beh',v:w[1],t}),0);
 if(w.length)h+=b('بازگشت',()=>st([]))}
return gate(p,h,bt)},
morning(){const r=S.R;return `<div class=card style="text-align:center"><div style="font-size:48px">🌅</div><h2>صبح روز ${S.n}</h2></div>`+T('گزارش شهر',`<p>${r.ex!=null?'«'+E(S.P[r.ex].nm)+'» شب‌هنگام تبعید شد.':'امشب کسی تبعید نشد.'}</p>`+r.pub.map(m=>`<p>${m}</p>`).join('')+r.beh.map(x=>`<p>⚠️ «${E(S.P[x.t].nm)}» ${BEH[x.v].m}</p>`).join(''))+b(S.Q.length?'نمایش پیام‌های خصوصی':'شروع بحث',()=>to(S.Q.length?'mail':'disc'),'p')},
mail(){const p=S.P[S.Q[0]],m=S.mq.filter(x=>x.to===p.i);return gate(p,'<h2>گزارش‌های محرمانه</h2>'+m.map(x=>`<div class=card>📨 ${E(x.txt)}</div>`).join(''),b('خواندم؛ مخفی کن',()=>adv(()=>go('disc')),'p'))},
disc(){const pr=al().filter(p=>!p.away),aw=al().filter(p=>p.away);
return T('بحث روزانه — روز '+S.n,(S.R?S.R.beh.map(x=>`<p>⚠️ «${E(S.P[x.t].nm)}» ${BEH[x.v].m}</p>`).join(''):'')+(S.dim?'<p>🔌 زمان بحث نصف شده است.</p>':'')+'<div class=sub>ترتیب صحبت:</div>'+pr.map((p,k)=>`<div>${k+1}. ${E(p.nm)}</div>`).join('')+aw.map(p=>`<div class=dead>${E(p.nm)} (غایب)</div>`).join('')+(C.tm?`<div class=tm id=tm>${fm(U.t)}</div>`+b(U.run?'توقف':'شروع / ادامه تایمر',tg):''))+b('شروع رأی‌گیری',()=>{S.V1={};S.Q=vt();to('v1')},'p')},
v1(){const p=S.P[S.Q[0]];return gate(p,'<h2>مظنون شما کیست؟</h2>'+al().filter(x=>x.i!==p.i).map(x=>b(E(x.nm),()=>{S.V1[p.i]=x.i;adv(()=>{S.T=tally(S);go('t1')})})).join(''),'')},
t1(){const t=S.T.t,d=S.T.d;return T('نتیجه رأی‌گیری',Object.keys(t).map(k=>`<div>${E(S.P[k].nm)}: ${t[k]} رأی</div>`).join('')||'رأیی ثبت نشد.')+(d==null?T('بدون دفاعیه','تساوی یا نبود اکثریت؛ امروز کسی به دفاعیه نمی‌رود.')+b('رفتن به شب',()=>{startNight();render()},'p'):T('دفاعیه','«'+E(S.P[d].nm)+'» بیشترین رأی را دارد.')+b('شروع دفاعیه',()=>{S.P[d].df=1;to('def')},'p'))},
def(){const q=S.P[S.T.d];return T('دفاعیه',`<h1>${E(q.nm)}</h1><p class=sub>برای دفاع از خود صحبت کن.</p>`+(C.tm?`<div class=tm id=tm>${fm(U.t)}</div>`+b(U.run?'توقف':'شروع / ادامه تایمر',tg):''))+b('رأی‌گیری نهایی',()=>{S.V2={};S.Q=vt();to('v2')},'p')},
v2(){const p=S.P[S.Q[0]],fin=()=>{const e=Object.entries(S.V2).filter(([k])=>k!=S.nt),y=e.filter(x=>x[1]).length,n=e.length-y,d=S.T.d,q=S.P[d].nm;S.Y=[y,n];
 if(y>n){S.P[d].al=0;S.st.ex++;S.H.push(`روز ${S.n}: «${q}» تبعید شد.`)}else S.H.push(`روز ${S.n}: «${q}» تبرئه شد.`);S.W=win(S);go('r2')};
return gate(p,`<h2>درباره «${E(S.P[S.T.d].nm)}» تصمیم نهایی؟</h2>`+b('تبعید شود',()=>{S.V2[p.i]=1;adv(fin)},'d')+b('تبعید نشود',()=>{S.V2[p.i]=0;adv(fin)}),'')},
r2(){const d=S.P[S.T.d],o=!d.al;return T(o?'تبعید شد':'تبرئه شد',`<p>«${E(d.nm)}» ${o?'تبعید شد و از بازی خارج است. نقش او فاش نمی‌شود.':'تبرئه شد.'}</p><p class=sub>تبعید شود: ${S.Y[0]} · تبعید نشود: ${S.Y[1]}</p>`)+b('ادامه',()=>{if(S.W)S.ph='end';else startNight();render()},'p')},
end(){const w=S.W==='c',st=S.st,c=w?'var(--ok)':'var(--d)';
return `<div class=card style="text-align:center;border-color:${c}"><div style="font-size:64px">${w?'🌆':'🌑'}</div><h1 style="color:${c}">${w?'شهر نجات پیدا کرد!':'شهر سقوط کرد!'}</h1></div>`+T('نقش‌ها',S.P.map(p=>`<div class="${p.al?'':'dead'}">${RL[p.r].i} ${E(p.nm)} — ${RL[p.r].n}${p.my?' (شهردار)':''}${p.al?'':' · تبعیدشده'}</div>`).join(''))+T('آمار',`<div>شب‌ها: ${S.n}</div><div>تبعیدشده‌ها: ${st.ex}</div><div>عملیات خنثی‌شده: ${st.neut}</div><div>خرابکاری موفق: ${st.sab}</div>`)+T('رویدادها',S.H.map(h=>`<div class=sub>${E(h)}</div>`).join(''))+b('بازی دوباره',()=>{U.nm=S.P.map(p=>p.nm);S=null;go2('setup')},'p')+b('بازگشت به منو',()=>{S=null;go2('menu')})}
};
function render(){F.length=0;document.body.classList.toggle('calm',!!C.calm);if(U.v==='game'&&!S)U.v='menu';let h;
try{h=U.v==='game'?V[S.ph]():V[U.v]()}catch(e){h=T('خطا','داده بازی ناسازگار است.')+b('پاک کردن بازی',()=>{S=null;U.v='menu';render()},'d')}
if(U.v==='game'&&S&&S.ph!=='end')h+=b('منو',()=>go2('menu'));
$('a').innerHTML=h;S?put('kh_s',S):LS.removeItem('kh_s')}
if(S&&(S.ph==='disc'||S.ph==='def'))timer(S.ph==='disc'?C.disc:C.def);
render();
if(location.hash==='#test'){const mk=r=>({n:2,ex:2,nul:1,fk:2,tc:2,insp:{},P:r.map((x,i)=>({i,nm:'p'+i,r:x,al:1})),N:{act:[]}});
const t1=mk(['sab','rep','grd','cit']);t1.N.act.push({p:0,k:'sab',m:'atk',t:3},{p:2,k:'grd',t:0});resolve(t1);
const t2=mk(['sab','rep','cit','cit']);t2.N.act.push({p:0,k:'sab',m:'atk',t:3},{p:1,k:'rep',t:3});resolve(t2);
const t3=mk(['sab','cit','cit','cit']);t3.N.act.push({p:0,k:'sab',m:'atk',t:3});resolve(t3);
const ok=[t1.ex==2&&t1.P[3].al,t2.ex==2&&t2.P[3].al,t3.ex==1&&!t3.P[3].al,[3,4,5,6,7,8,9,10].every(n=>combo(n).length==n&&valid(n))];
console.log('tests',ok);alert('آزمون‌ها: '+ok.join(' '))}
