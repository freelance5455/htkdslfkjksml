KEUANGANKU — MODERN EDITION
Developed by Andi XTJKT3

CARA MENJALANKAN
1. Ekstrak ZIP sampai seluruh folder terlihat.
2. Buka folder Keuanganku_Opening.
3. Jalankan index.html menggunakan Chrome, Edge, atau browser modern lainnya.
4. Jangan pisahkan folder assets dari index.html.

DATA DAN CADANGAN
- Data disimpan secara lokal di browser/perangkat yang digunakan.
- Versi revisi tetap menggunakan penyimpanan KeuanganKu sebelumnya agar data lama di browser yang sama tetap terbaca.
- Gunakan menu Laporan > Ekspor data untuk membuat cadangan JSON secara berkala.
- Impor cadangan akan mengganti data yang sedang tersimpan dan meminta konfirmasi terlebih dahulu.
- Data yang tidak valid pada file impor akan dilewati. File impor yang seluruh isinya tidak valid akan ditolak.
- Menghapus data browser atau berpindah perangkat dapat membuat catatan lokal tidak tersedia. Simpan cadangan JSON.

PERBAIKAN UTAMA
- Setoran tabungan kini dicatat sebagai transaksi pengeluaran kategori Tabungan.
- Cicilan dan pelunasan utang/piutang kini masuk ke riwayat transaksi sesuai arus uangnya.
- Cicilan yang melebihi sisa utang ditolak.
- Nilai investasi dapat diperbarui, termasuk menjadi Rp0, dan nilai sebelumnya ditampilkan saat formulir dibuka.
- Jadwal transaksi dan tagihan berulang mempertahankan tanggal acuannya ketika melewati bulan yang lebih pendek.
- Transaksi berulang yang tertinggal diproses saat aplikasi dibuka atau saat perubahan disimpan; pengulangan tidak dibuat dua kali.
- Impor data divalidasi per jenis catatan, ID dibersihkan, dan data rusak dilewati agar tidak merusak aplikasi.
- Kegagalan penyimpanan lokal menampilkan peringatan.
- Navigasi bawah diperkuat agar tetap dapat ditekan dan tata letak ponsel dipadatkan.

CATATAN
Setoran tabungan dan pembayaran/cicilan yang dilakukan setelah pembaruan akan tercatat ke riwayat transaksi. Riwayat lama yang sebelumnya tidak pernah dicatat tidak dapat dibuat kembali secara otomatis.

Lihat CHANGELOG.txt dan QA_TEST_RESULTS.txt untuk rincian revisi dan hasil pengujian.
