# Keuanganku — Personal Opening Edition

## Isi folder
- `index.html` — aplikasi Keuanganku yang sudah ditambahkan loading screen dan opening personal.
- `assets/keuanganku-logo.png` — logo Keuanganku.
- `assets/developer-andi.png` — foto developer.

## Cara menggunakan
Buka `index.html` di browser. Untuk menjaga gambar tetap tampil, jangan pisahkan atau pindahkan folder `assets` dari `index.html`.

Opening menampilkan loading 0–100%, logo, foto developer, kredit **Developed by Andi XTJKT3**, pesan kebebasan finansial, dan tombol untuk masuk ke aplikasi.

Fitur pencatatan dan penyimpanan aplikasi asli tetap dipertahankan.
