package com.contek.tradejournal;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String FILE = "Contek-Trade-Journal-backup.json";
    private WebView web;
    private ValueCallback<Uri[]> chooser;
    private String pendText;
    private SharedPreferences prefs;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("contek", MODE_PRIVATE);
        web = new WebView(this);
        web.setBackgroundColor(android.graphics.Color.BLACK);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = cb;
                try { startActivityForResult(p.createIntent(), 1); }
                catch (Exception e) { chooser = null; return false; }
                return true;
            }
        });
        web.loadUrl("file:///android_asset/index.html");
    }

    class Bridge {
        @JavascriptInterface public void save(final String name, final String mime, final String text) {
            pendText = text;
            runOnUiThread(new Runnable() { public void run() {
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType(mime);
                i.putExtra(Intent.EXTRA_TITLE, name);
                startActivityForResult(i, 2);
            }});
        }
        @JavascriptInterface public boolean hasFolder() { return prefs.getString("tree", null) != null; }
        @JavascriptInterface public void pickFolder() {
            runOnUiThread(new Runnable() { public void run() {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(i, 3);
            }});
        }
        @JavascriptInterface public void autoBackup(final String json) {
            new Thread(new Runnable() { public void run() {
                boolean ok = false;
                try { ok = writeBackup(json); } catch (Exception e) { }
                final String js = "onBk(" + ok + ",'" + new SimpleDateFormat("d MMM yyyy, HH:mm", Locale.getDefault()).format(new Date()) + "')";
                runOnUiThread(new Runnable() { public void run() { web.evaluateJavascript(js, null); }});
            }}).start();
        }
    }

    private boolean writeBackup(String json) throws Exception {
        String t = prefs.getString("tree", null);
        if (t == null) return false;
        Uri tree = Uri.parse(t);
        ContentResolver cr = getContentResolver();
        String id = DocumentsContract.getTreeDocumentId(tree);
        Uri parent = DocumentsContract.buildDocumentUriUsingTree(tree, id);
        Uri kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree, id);
        Uri existing = null;
        Cursor c = cr.query(kids, new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null);
        if (c != null) {
            try { while (c.moveToNext()) if (FILE.equals(c.getString(1))) { existing = DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(0)); break; } }
            finally { c.close(); }
        }
        byte[] data = json.getBytes("UTF-8");
        if (existing != null) {
            try { OutputStream o = cr.openOutputStream(existing, "wt"); o.write(data); o.close(); return true; }
            catch (Exception e) { try { DocumentsContract.deleteDocument(cr, existing); } catch (Exception x) { } }
        }
        Uri n = DocumentsContract.createDocument(cr, parent, "application/json", FILE);
        if (n == null) return false;
        OutputStream o = cr.openOutputStream(n);
        o.write(data);
        o.close();
        return true;
    }

    @Override protected void onActivityResult(int r, int c, Intent d) {
        if (r == 1) {
            if (chooser != null) { chooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(c, d)); chooser = null; }
        } else if (r == 2 && c == RESULT_OK && d != null && pendText != null) {
            try {
                OutputStream o = getContentResolver().openOutputStream(d.getData());
                o.write(pendText.getBytes("UTF-8"));
                o.close();
                Toast.makeText(this, "File saved", Toast.LENGTH_SHORT).show();
            } catch (Exception e) { Toast.makeText(this, "Could not save file", Toast.LENGTH_LONG).show(); }
            pendText = null;
        } else if (r == 3 && c == RESULT_OK && d != null) {
            Uri u = d.getData();
            getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            prefs.edit().putString("tree", u.toString()).apply();
            web.evaluateJavascript("onFolder()", null);
        }
    }
}
