// lang: Java  file: CheatCore.java  runtime: Android 8+ root
package com.ffcheat.panel;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

public class CheatCore {

    // ── Config ────────────────────────────────────────────────────────
    public static final AtomicBoolean espOn    = new AtomicBoolean(false);
    public static final AtomicBoolean aimOn    = new AtomicBoolean(false);
    public static final AtomicBoolean onShoot  = new AtomicBoolean(true);
    public static final AtomicInteger bone     = new AtomicInteger(0); // 0=head,1=chest,2=hip
    public static volatile float fov           = 253.6f;

    // ── State ─────────────────────────────────────────────────────────
    public static volatile float[] espBoxes    = new float[0]; // [x,y,w,h,hp,...]
    private static int   pid  = 0;
    private static long  base = 0;
    private static ScheduledExecutorService exec;

    // ── W2S matrix read from camera ───────────────────────────────────
    private static float[] readMatrix(long camBase) {
        long follow = Mem.readLong(camBase + Offsets.Camera_Follow);
        long intPtr = Mem.readLong(follow  + Offsets.Camera_IntPtr);
        long matAddr= intPtr + Offsets.Camera_Matrix;
        float[] m = new float[16];
        for (int i = 0; i < 16; i++)
            m[i] = Mem.readFloat(matAddr + i * 4L);
        return m;
    }

    private static float[] w2s(float[] m, float wx, float wy, float wz, int sw, int sh) {
        float cx = m[0]*wx + m[1]*wy + m[2]*wz  + m[3];
        float cy = m[4]*wx + m[5]*wy + m[6]*wz  + m[7];
        float cw = m[12]*wx+ m[13]*wy+ m[14]*wz + m[15];
        if (cw < 0.001f) return null;
        float sx = (cx/cw + 1f) * 0.5f * sw;
        float sy = (1f - cy/cw) * 0.5f * sh;
        return new float[]{sx, sy};
    }

    // ── Unity transform → world position ─────────────────────────────
    private static float[] getBonePos(long tf) {
        long obj    = Mem.readLong(tf  + Offsets.TF_Obj);
        long idx    = Mem.readLong(obj + Offsets.TF_ObjIdx);
        long mats   = Mem.readLong(obj + Offsets.TF_MatList);
        long idxArr = Mem.readLong(mats + Offsets.MatList_IdxArr);
        long matArr = Mem.readLong(mats + Offsets.MatList_MatArr);
        int  i      = Mem.readInt(idxArr + idx * 4L);
        long matBase= matArr + (long)i * Offsets.Mat_Stride;
        float x = Mem.readFloat(matBase + 0x0C * 4L);
        float y = Mem.readFloat(matBase + 0x0D * 4L);
        float z = Mem.readFloat(matBase + 0x0E * 4L);
        return new float[]{x, y, z};
    }

    // ── Main tick ─────────────────────────────────────────────────────
    private static void tick(int sw, int sh) {
        if (pid == 0) {
            pid = Mem.findPid("com.dts.freefireth");
            if (pid == 0) return;
            try { Mem.open(pid); } catch (Exception e) { pid = 0; return; }
        }
        if (base == 0) {
            base = Mem.getBase(pid, "libil2cpp.so");
            if (base == 0) { pid = 0; return; }
        }

        try {
            long gf    = Mem.readLong(base + Offsets.GameFacade);
            long gf2   = Mem.readLong(gf   + Offsets.GameFacade_P2);
            long match = Mem.readLong(gf2  + Offsets.BaseGame_Match);
            if (match == 0) return;

            long lp    = Mem.readLong(match + Offsets.Match_LocalPlayer);
            long camBase = Mem.readLong(lp  + Offsets.Player_Camera);
            float[] vp = readMatrix(camBase);

            long dict    = Mem.readLong(match + Offsets.Match_PlayerDict);
            long entries = Mem.readLong(dict  + Offsets.Dict_Entries);
            int  count   = Mem.readInt(dict   + Offsets.Dict_Count);
            if (count <= 0 || count > 128) return;

            List<float[]> boxes = new ArrayList<>(); // [x,y,w,h,hp]
            long   bestTarget   = 0;
            float  bestDist     = fov * fov;
            float  bestBx = 0, bestBy = 0, bestBz = 0;

            for (int i = 0; i < count; i++) {
                long entry = entries + (long)i * Offsets.Dict_Stride;
                long pbase = Mem.readLong(entry + Offsets.Dict_Value);
                if (pbase == 0 || pbase == lp) continue;
                if (Mem.readBool(pbase + Offsets.Player_IsDead)) continue;
                if (Mem.readBool(pbase + Offsets.Player_IsBot))  continue;

                // HP
                long hpList  = Mem.readLong(pbase + Offsets.Player_HP);
                long hpEntry = Mem.readLong(hpList + Offsets.HP_List);
                float hp     = Mem.readFloat(hpEntry + Offsets.HP_Value);
                if (hp <= 0) continue;

                // bone positions
                long headTF = Mem.readLong(pbase + Offsets.Bone_Head);
                long feetTF = Mem.readLong(pbase + Offsets.Bone_Feet);
                float[] head = getBonePos(headTF);
                float[] feet = getBonePos(feetTF);

                float[] scrH = w2s(vp, head[0], head[1], head[2], sw, sh);
                float[] scrF = w2s(vp, feet[0], feet[1], feet[2], sw, sh);
                if (scrH == null || scrF == null) continue;
                if (scrH[0] < 0 || scrH[0] > sw || scrH[1] < 0 || scrH[1] > sh) continue;

                // ESP box
                if (espOn.get()) {
                    float bh = Math.abs(scrF[1] - scrH[1]);
                    float bw = bh * 0.5f;
                    if (bw < 10) bw = 40;
                    boxes.add(new float[]{scrH[0] - bw/2f, scrH[1], bw, bh, hp});
                }

                // aimbot candidate
                if (aimOn.get()) {
                    long boneOff = bone.get() == 0 ? Offsets.Bone_Head
                                 : bone.get() == 1 ? Offsets.Bone_Chest
                                 : Offsets.Bone_Hip;
                    long boneTF = Mem.readLong(pbase + boneOff);
                    float[] bpos = getBonePos(boneTF);
                    float[] scr  = w2s(vp, bpos[0], bpos[1], bpos[2], sw, sh);
                    if (scr != null) {
                        float dx = scr[0] - sw/2f, dy = scr[1] - sh/2f;
                        float d  = dx*dx + dy*dy;
                        if (d < bestDist) {
                            bestDist = d; bestTarget = pbase;
                            bestBx = bpos[0]; bestBy = bpos[1]; bestBz = bpos[2];
                        }
                    }
                }
            }

            // commit ESP
            float[] flat = new float[boxes.size() * 5];
            for (int i = 0; i < boxes.size(); i++)
                System.arraycopy(boxes.get(i), 0, flat, i*5, 5);
            espBoxes = flat;

            // commit aimbot
            if (aimOn.get() && bestTarget != 0) {
                boolean fire = onShoot.get() ? Mem.readBool(lp + Offsets.Player_IsFiring) : true;
                if (fire) {
                    long lpBullet = Mem.readLong(lp + Offsets.Player_BulletInfo);
                    if (lpBullet != 0) {
                        // camera world pos from matrix
                        float ox = vp[3], oy = vp[7], oz = vp[11];
                        float dx = bestBx - ox, dy = bestBy - oy, dz = bestBz - oz;
                        float len = (float)Math.sqrt(dx*dx + dy*dy + dz*dz);
                        if (len > 0.001f) {
                            // write spawn pos
                            Mem.writeFloat(lpBullet + Offsets.Bullet_SpawnPos,      ox);
                            Mem.writeFloat(lpBullet + Offsets.Bullet_SpawnPos + 4L, oy);
                            Mem.writeFloat(lpBullet + Offsets.Bullet_SpawnPos + 8L, oz);
                            // write direction
                            Mem.writeFloat(lpBullet + Offsets.Bullet_DirWrite,      dx/len);
                            Mem.writeFloat(lpBullet + Offsets.Bullet_DirWrite + 4L, dy/len);
                            Mem.writeFloat(lpBullet + Offsets.Bullet_DirWrite + 8L, dz/len);
                        }
                    }
                }
            }

        } catch (Exception e) {
            pid = 0; base = 0; Mem.close();
        }
    }

    // ── Start / Stop ──────────────────────────────────────────────────
    public static void start(int sw, int sh) {
        if (exec != null) return;
        exec = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "gl_worker"); // masked name — anti-ban
            t.setDaemon(true);
            return t;
        });
        exec.scheduleAtFixedRate(() -> tick(sw, sh), 0, 16, TimeUnit.MILLISECONDS);
    }

    public static void stop() {
        if (exec != null) { exec.shutdownNow(); exec = null; }
        pid = 0; base = 0; Mem.close();
        espBoxes = new float[0];
    }
}
