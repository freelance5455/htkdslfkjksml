// lang: Java  file: Mem.java  runtime: Android 8+ root
package com.ffcheat.panel;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class Mem {
    private static RandomAccessFile memFile;
    private static final ByteBuffer buf4  = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN);
    private static final ByteBuffer buf8  = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN);

    public static void open(int pid) throws Exception {
        if (memFile != null) try { memFile.close(); } catch (Exception ignored) {}
        memFile = new RandomAccessFile("/proc/" + pid + "/mem", "rw");
    }

    public static void close() {
        try { if (memFile != null) memFile.close(); } catch (Exception ignored) {}
        memFile = null;
    }

    public static long readLong(long addr) {
        try {
            memFile.seek(addr);
            byte[] b = new byte[8];
            memFile.readFully(b);
            buf8.clear(); buf8.put(b); buf8.flip();
            return buf8.getLong();
        } catch (Exception e) { return 0; }
    }

    public static int readInt(long addr) {
        try {
            memFile.seek(addr);
            byte[] b = new byte[4];
            memFile.readFully(b);
            buf4.clear(); buf4.put(b); buf4.flip();
            return buf4.getInt();
        } catch (Exception e) { return 0; }
    }

    public static float readFloat(long addr) {
        return Float.intBitsToFloat(readInt(addr));
    }

    public static boolean readBool(long addr) {
        try {
            memFile.seek(addr);
            return memFile.readByte() != 0;
        } catch (Exception e) { return false; }
    }

    public static void writeFloat(long addr, float val) {
        try {
            buf4.clear(); buf4.putFloat(val); buf4.flip();
            byte[] b = new byte[4]; buf4.get(b);
            memFile.seek(addr); memFile.write(b);
        } catch (Exception ignored) {}
    }

    public static void writeLong(long addr, long val) {
        try {
            buf8.clear(); buf8.putLong(val); buf8.flip();
            byte[] b = new byte[8]; buf8.get(b);
            memFile.seek(addr); memFile.write(b);
        } catch (Exception ignored) {}
    }

    public static long chain(long base, long... offsets) {
        long cur = base;
        for (long off : offsets) {
            if (cur == 0) return 0;
            cur = readLong(cur + off);
        }
        return cur;
    }

    // find pid by package name via /proc
    public static int findPid(String pkg) {
        File proc = new File("/proc");
        File[] dirs = proc.listFiles();
        if (dirs == null) return 0;
        for (File d : dirs) {
            String name = d.getName();
            if (!name.matches("\\d+")) continue;
            File cmd = new File(d, "cmdline");
            try (BufferedReader r = new BufferedReader(new FileReader(cmd))) {
                String line = r.readLine();
                if (line != null && line.contains(pkg)) return Integer.parseInt(name);
            } catch (Exception ignored) {}
        }
        return 0;
    }

    // get base address of lib in pid maps
    public static long getBase(int pid, String lib) {
        try (BufferedReader r = new BufferedReader(
                new FileReader("/proc/" + pid + "/maps"))) {
            String line;
            while ((line = r.readLine()) != null) {
                if (line.contains(lib)) {
                    return Long.parseLong(line.split("-")[0], 16);
                }
            }
        } catch (Exception ignored) {}
        return 0;
    }
}
