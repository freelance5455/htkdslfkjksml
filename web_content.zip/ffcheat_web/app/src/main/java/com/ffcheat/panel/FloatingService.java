// lang: Java  file: FloatingService.java  runtime: Android 8+
package com.ffcheat.panel;

import android.app.Service;
import android.content.*;
import android.graphics.PixelFormat;
import android.os.*;
import android.util.DisplayMetrics;
import android.view.*;
import android.view.WindowManager.LayoutParams;
import android.webkit.*;

public class FloatingService extends Service {
    private WindowManager wm;
    private WebView       webView;
    private JsBridge      bridge;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        int sw = dm.widthPixels, sh = dm.heightPixels;

        // WebView setup
        webView = new WebView(this);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccessFromFileURLs(true);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        // transparent bg
        webView.setBackgroundColor(0x00000000);
        webView.setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null);

        bridge = new JsBridge(webView);
        webView.addJavascriptInterface(bridge, "Android");
        webView.loadUrl("file:///android_asset/index.html");

        // floating window params
        LayoutParams lp = new LayoutParams(
            (int)(sw * 0.72f), LayoutParams.WRAP_CONTENT,
            Build.VERSION.SDK_INT >= 26
                ? LayoutParams.TYPE_APPLICATION_OVERLAY
                : LayoutParams.TYPE_PHONE,
            LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.END;
        lp.x = 0; lp.y = 80;
        wm.addView(webView, lp);
        makeDraggable(webView, lp);

        CheatCore.start(sw, sh);
    }

    @Override public void onDestroy() {
        CheatCore.stop();
        try { wm.removeView(webView); } catch (Exception ignored) {}
        super.onDestroy();
    }

    private void makeDraggable(android.view.View v, LayoutParams lp) {
        v.setOnTouchListener(new android.view.View.OnTouchListener() {
            int lx, ly;
            public boolean onTouch(android.view.View view, android.view.MotionEvent e) {
                switch (e.getAction()) {
                    case android.view.MotionEvent.ACTION_DOWN:
                        lx = (int)e.getRawX(); ly = (int)e.getRawY(); break;
                    case android.view.MotionEvent.ACTION_MOVE:
                        lp.x -= ((int)e.getRawX() - lx);
                        lp.y += ((int)e.getRawY() - ly);
                        lx = (int)e.getRawX(); ly = (int)e.getRawY();
                        wm.updateViewLayout(v, lp); break;
                }
                return false;
            }
        });
    }
}
