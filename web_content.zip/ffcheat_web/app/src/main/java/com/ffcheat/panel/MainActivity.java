// lang: Java  file: MainActivity.java
package com.ffcheat.panel;

import android.app.Activity;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ = 1001;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (!hasRoot()) {
            Toast.makeText(this, "Root obrigatório!", Toast.LENGTH_LONG).show();
            finish(); return;
        }
        grantOverlay();
        if (Settings.canDrawOverlays(this)) { go(); return; }
        startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:" + getPackageName())), REQ);
    }

    @Override protected void onActivityResult(int req, int res, Intent d) {
        if (req == REQ && Settings.canDrawOverlays(this)) go();
    }

    private boolean hasRoot() {
        try {
            Process p = Runtime.getRuntime().exec("su -c id");
            byte[] buf = new byte[64];
            int n = p.getInputStream().read(buf);
            return new String(buf, 0, n).contains("uid=0");
        } catch (Exception e) { return false; }
    }

    private void grantOverlay() {
        try {
            int uid = getApplicationInfo().uid;
            String cmd = "appops set --uid " + uid + " " + getPackageName() + " SYSTEM_ALERT_WINDOW allow";
            Runtime.getRuntime().exec(new String[]{"su", "-c", cmd}).waitFor();
        } catch (Exception ignored) {}
    }

    private void go() {
        startService(new Intent(this, FloatingService.class));
        finish();
    }
}
