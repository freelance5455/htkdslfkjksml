// lang: Java  file: JsBridge.java  runtime: Android 8+
// @JavascriptInterface — called by index.html JS → CheatCore
package com.ffcheat.panel;

import android.webkit.JavascriptInterface;
import com.google.gson.Gson;
import java.util.*;

public class JsBridge {
    private final android.webkit.WebView wv;
    private final Gson gson = new Gson();

    public JsBridge(android.webkit.WebView wv) { this.wv = wv; }

    @JavascriptInterface public void setAimbot(boolean v)   { CheatCore.aimOn.set(v); }
    @JavascriptInterface public void setEsp(boolean v)      { CheatCore.espOn.set(v); }
    @JavascriptInterface public void setAimOnShoot(boolean v){ CheatCore.onShoot.set(v); }
    @JavascriptInterface public void setFov(float v)        { CheatCore.fov = v; }
    @JavascriptInterface public void setBone(int v)         { CheatCore.bone.set(v); }

    // called by JS every 33ms — push ESP boxes back as JSON
    @JavascriptInterface public void requestEspBoxes() {
        float[] raw = CheatCore.espBoxes;
        if (raw == null || raw.length == 0) {
            runJs("window.receiveEspBoxes('[]')");
            return;
        }
        List<Map<String,Float>> list = new ArrayList<>();
        for (int i = 0; i + 4 < raw.length; i += 5) {
            Map<String,Float> m = new LinkedHashMap<>();
            m.put("x",  raw[i]);   m.put("y", raw[i+1]);
            m.put("w",  raw[i+2]); m.put("h", raw[i+3]);
            m.put("hp", raw[i+4]);
            list.add(m);
        }
        String json = gson.toJson(list).replace("'", "\\'");
        runJs("window.receiveEspBoxes('" + json + "')");
    }

    // push pid to status bar
    public void pushPid(int pid) {
        runJs("window.receivePid(" + pid + ")");
    }

    private void runJs(String js) {
        wv.post(() -> wv.evaluateJavascript(js, null));
    }
}
