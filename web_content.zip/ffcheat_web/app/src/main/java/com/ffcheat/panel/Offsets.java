// lang: Java  file: Offsets.java
package com.ffcheat.panel;

public final class Offsets {
    public static final long GameFacade        = 0xAD68E18L;
    public static final long GameFacade_P2     = 0xB8L;
    public static final long BaseGame_Match    = 0x90L;
    public static final long Match_PlayerDict  = 0xC0L;
    public static final long Match_LocalPlayer = 0xD8L;
    public static final long Dict_Entries      = 0x18L;
    public static final long Dict_Count        = 0x20L;
    public static final long Dict_Stride       = 0x18L;
    public static final long Dict_Value        = 0x10L;

    public static final long Player_IsDead     = 0x7CL;
    public static final long Player_IsBot      = 0x4A8L;
    public static final long Player_HP         = 0x70L;
    public static final long Player_IsFiring   = 0x850L;
    public static final long Player_Camera     = 0x698L;
    public static final long Player_BulletInfo = 0xE58L;
    public static final long Bullet_SpawnPos   = 0x4CL;
    public static final long Bullet_DirWrite   = 0x40L;
    public static final long HP_List           = 0x10L;
    public static final long HP_Entry          = 0x20L;
    public static final long HP_Value          = 0x18L;

    public static final long Camera_Follow     = 0x30L;
    public static final long Camera_IntPtr     = 0x10L;
    public static final long Camera_Matrix     = 0x100L;

    // Bones (transform offsets from player base)
    public static final long Bone_Head         = 0x6A8L;
    public static final long Bone_Chest        = 0x6B8L;
    public static final long Bone_Hip          = 0x6B0L;
    public static final long Bone_Feet         = 0x6D0L;

    // Transform → position (Unity internal)
    public static final long TF_Obj            = 0x10L;
    public static final long TF_ObjIdx         = 0x40L;
    public static final long TF_MatList        = 0x38L;
    public static final long MatList_IdxArr    = 0x18L;
    public static final long MatList_MatArr    = 0x20L;
    public static final long Mat_Stride        = 0x30L;
}
