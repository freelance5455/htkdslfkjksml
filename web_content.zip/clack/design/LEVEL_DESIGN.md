# Clack! levels 1 to 1000: design

Every number here comes from `plan(level)` in `www/index.html` (the same code the game runs). `levels_1_1000.csv` lists all 1,000 levels. Levels past 1,000 reuse the same rules.

## Principles
1. **One new idea at a time.** Each mechanic is introduced alone, on a gentle level, with a notification, then recurs on a fixed beat so it never feels random.
2. **Teach by doing.** Tutorials lock the controls to the one correct action. You cannot finish them without doing the thing. A **Skip tutorial** link appears after 14 idle seconds so nobody gets stuck.
3. **Rhythm.** Every 10 levels follow the same wave: build, build, build, *time*, **breather**, *spin*, *limit*, build, **peak**, finale. Breathers use fewer colours and easy layouts (columns or bands) for a fast, satisfying clear.
4. **Bosses** every 100 levels: two blobs, two armed cores, a timer, a title card with letterbox bars.
5. **Never punish learning.** Mistakes are free in tutorials. After 2 fails on one level you get 12% fewer balls and 20% more time per fail; after 3, more help still.

## Chapters
| Levels | Chapter | Avg balls | Avg colours | Multi-blob levels | Timed | Limited pulls | Spinning | Core levels | Tool gifts |
|---|---|---|---|---|---|---|---|---|---|
| 1-10 | First Pulls | 23 | 3.3 | 0 | 0 | 0 | 0 | 0 | 0 |
| 11-30 | Two Hands | 48 | 4.7 | 6 | 1 | 0 | 1 | 1 | 0 |
| 31-60 | Pressure | 78 | 5.7 | 10 | 3 | 3 | 3 | 2 | 1 |
| 61-100 | Toolbox | 93 | 5.9 | 17 | 5 | 4 | 5 | 2 | 2 |
| 101-200 | Deep Water | 117 | 5.9 | 44 | 16 | 10 | 11 | 5 | 3 |
| 201-350 | Whirlpool | 130 | 5.9 | 65 | 36 | 30 | 26 | 7 | 5 |
| 351-500 | Stormfront | 130 | 5.9 | 65 | 47 | 30 | 32 | 8 | 5 |
| 501-700 | Iron Nerves | 130 | 5.9 | 87 | 62 | 50 | 42 | 10 | 7 |
| 701-900 | Edge of the Map | 130 | 5.9 | 86 | 62 | 60 | 42 | 10 | 6 |
| 901-1000 | The Last Hundred | 130 | 5.9 | 44 | 31 | 30 | 21 | 5 | 4 |

## Introduction timeline (what is new, and how it is taught)
| Level | New | Teaching method |
|---|---|---|
| 1 | Pulling a colour | **Forced tutorial.** 2 colours in two bands (red below blue). Only RED works, then only BLUE. |
| 2 | Blocked balls | **Forced.** You must tap the buried colour first and see it fail (free), then pull the one underneath. |
| 3 | Layers | **Forced.** 3 bands. You must go bottom-up: yellow, blue, red. |
| 4 | Lives | Card explaining the red dots. |
| 6, 14, 36 | 4th, 5th, 6th colour | Toast: "A new colour joins the blob." |
| 8 | Speed stars | Toast about bonus stars for fast clears. |
| 11 | Chapter 2, pulled-apart blobs | Title card, then a card: two attractors, same rules. |
| 15 | **Slice** | **Forced, 3 steps.** Tap Slice, drag between the red top layer and the rest (a dashed guide shows where; a bad cut is refused), then pull the freed red. |
| 18 | Flawless streaks | Toast: 5 clean levels in a row earns a Slice. |
| 20 | **Armed cores** (then every 20 levels) | **Forced.** A pulsing ball with a countdown. You must dig to it and secure it. A long fuse and a hint on the right button. If it blows, the tutorial restarts. |
| 24 | **Time limits** | Card. First timed level, about 2.7x par time. |
| 26 | **Spinning blob** | Card. First spin, very slow. |
| 37 | **Press limits** | Card. Numbers on the buttons, generous slack. |
| 45 | **Grapple Gun** | **Forced.** Tap the tool, then tap the glowing keystone ball. |
| 65 | **Plunger** | **Forced.** Tap the tool, then tap the glowing spot. |
| 100, 200... | Bosses | Title card and letterbox bars. |

## Where the balls go (layouts)
Balls are placed on a hex lattice, then relaxed by the physics, so each level's structure is designed instead of random.
- **bands**: horizontal layers. Forces a bottom-up order. Used for tutorials and breathers.
- **cols**: vertical stripes. Nearly everything is free. Breather palate-cleanser.
- **mix**: random colours on the lattice. The baseline.
- **diag**: diagonal layers. Order matters, but less obviously.
- **rings**: concentric colour rings, outer to inner.
- **cap**: one colour caps the top of a mixed body.
- **halves**: left and right halves use different colour sets, so it is two puzzles in one.
- **checker**: interleaved colours, the hardest. Only from level 120, only on peak levels.
Blob shapes (round, wide, tall, lumpy) start at level 11. 1 to 3 blobs per level. Ball counts: 10, 12, 16, 20, 24 for levels 1 to 5, then about 1.6 more per level to 80 at level 40, then slowly to the cap of 132 (140 on bosses).

## Where the cores go
One core every 20 levels (two on bosses), always a distinct colour. Placement rotates: **mid** (about the 30th to 60th percentile by burial depth, level 20), **edge** (furthest to the side) and **top** (most buried). The fuse is about 3.8 to 4.8 seconds per estimated press plus 8, with 1.7x on the tutorial.

## Mechanic schedule (cycle position = (level-1) mod 10)
- **Timed**: position 3 from level 24; position 7 from level 150; peaks from 300. Tightness 2.7x par falling to 1.5x.
- **Limited pulls**: position 6 from level 37; position 2 from 200; peaks from 600. Slack 0.93 falling to 0.52.
- **Spinning**: position 5 from level 26; position 1 from 250. Strength rises about 4x.
- Boss levels add a timer and a spin.
- The mechanics sit on different beats, so they never stack until level 300.

## Tools
Slice (unlocks 15), Core (20), Grapple Gun (45), Plunger (65). Earned by: Slice every 5 flawless levels; Core by securing cores; a rotating supply gift every 30 levels from level 31; or bought with stars. Max 9 of each. A tool's toolbar slot only appears once it is introduced.

## Notifications (what shows when)
- **Title card**: chapter start or boss. About 2.3 seconds, controls briefly held so timers do not run.
- **Tutorial bar**: a pill under the HUD with the step and progress dots. The highlighted control pulses.
- **Intro card**: blocking, once per mechanic.
- **Toast**: non-blocking tip, once.
- **Fly-to-toolbar orb**: when you earn a tool.
- **Assist toast**: after repeated fails.

## Tuning dials (all in `plan()`)
`balls` formula, `colors` thresholds, the `pos` sets for time/limit/spin, `time`/`limit`/`spin` curves (`2.8-1.3*d`, `.95-.45*d`), `core` cadence, `TUT` scripts, `TUTLAY` tutorial layouts. Fuse length is in `pickCores()`.

## Not verified
The curve was checked by simulation only (a bot played the tutorials and sample levels, and every level's parameters were range-checked: 0 out of range). It has not been playtested by humans, so expect to retune the timed and limited levels first.
