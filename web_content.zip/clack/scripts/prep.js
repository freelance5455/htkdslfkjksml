// Copies the two (optional) fonts into www/ so the app works fully offline.
const fs = require('fs'), path = require('path');
const copy = (from, to) => {
  try {
    fs.mkdirSync(path.dirname(to), { recursive: true });
    fs.copyFileSync(from, to);
    console.log('copied', to);
  } catch (e) { console.warn('skipped', to, '(game falls back to system fonts)'); }
};
copy('node_modules/@fontsource/bowlby-one/files/bowlby-one-latin-400-normal.woff2', 'www/fonts/display.woff2');
copy('node_modules/@fontsource-variable/bricolage-grotesque/files/bricolage-grotesque-latin-wght-normal.woff2', 'www/fonts/body.woff2');
