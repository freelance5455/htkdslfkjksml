# Clack! Magnetic Jam: Android project

## Build the APK / AAB
1. Install Node 18+, Android Studio and a JDK (Android Studio bundles one).
2. In this folder: `npm install` (also copies the optional fonts into `www/`).
3. `npx cap add android` (first time only), then `npm run sync`.
4. Change `appId` in `capacitor.config.json` to your own reverse-domain id before you add Android.
5. `npm run open`, then in Android Studio: Build > Generate Signed Bundle / APK.
   Google Play needs the **AAB**; the APK is for sideloading and testing.
6. Icons are already in `assets/` (adaptive foreground + background). After `npx cap add android`, run `npm run icons` to write the launcher icons. Upload `store/play-store-icon-512.png` as the Play Store listing icon.

## Level packs (what's in the game)
| Levels | Price | Play Console product id |
|---|---|---|
| 1 - 1,000 | Free | none |
| 1,001 - 10,000 | £3.99 | `clack_pack_9k` |
| 10,001 - 100,000 | £3.99 | `clack_pack_90k` |
| 100,001 - 1,000,000 | £3.99 | `clack_pack_900k` |
| 1,000,001 - 11,000,000 | £3.99 | `clack_pack_10m` |

Levels are generated from the level number (seeded), so the same level is identical every time and nothing is stored.

## Turn on real payments
1. Play Console > your app > Monetize > In-app products: create the four ids above as **one-time products**, price £3.99, status Active.
2. Upload a build to Internal testing, add yourself under License testers, and install from the testing link. Billing does not work on a sideloaded APK.
3. Opening `www/index.html` as a local file (or adding `#dev` to its URL) turns on a **test mode** that unlocks packs for free. Inside the APK it never does, so a failed store connection can't hand out free levels.
4. Purchases are not receipt-verified. For serious revenue add server-side validation (RevenueCat or your own backend) before launch.

## Before you publish
- Fill in the Play Console data safety form and add a privacy policy URL (required even for a game that collects nothing).
- Progress is saved on the device only (localStorage). Uninstalling clears it; owned packs come back via "Restore purchases".
- Levels are procedurally generated. Difficulty and solvability across all 11M have not been brute-force tested, so play a few hundred at various depths and tune `generateLevel()` in `www/index.html`.

## Quick builds (Build Center and other online HTML-to-APK tools)
- Use `www/index.html` on its own. It is fully self-contained (audio is synthesised, no Tone.js).
- Those tools need internet to reach their build server. "Unable to resolve host" means the phone is offline or in airplane mode.
- They can't take Google Play payments, so the pack button says purchases need the Google Play version. Use the Capacitor route above for the paid release.
- Without the font files the game uses Android's heavy system font; the Capacitor build bundles the real fonts.

## v4 notes
- Mechanics: tutorial on level 1, time limits from level 12, press limits (count shown on each button) from level 24, spinning blob from level 36, combos of these from level 100. Tune `mech()` in `www/index.html`.
- The blob is pre-simulated when a level starts, so it is formed and playable straight away.
- 20 music tracks (5 chord progressions x 4 patterns); a new one is picked after every fail, and the classic tune opens a fresh install.
- Saves (progress, stars, shop items, settings) live on the device. There is no account or cloud save yet.

## v5: armed cores
- From level 3 on, most levels have pulsing armed cores with a countdown. Dig to them and pull their colour before zero: defusing wipes that whole colour, in slow motion. Letting one reach zero fails the level.
- Tuning: `coreCount()` sets how many per level; the fuse length is in `pickCores()` (`3.6` for the first levels, then `2.4 + level/700` seconds per estimated press, plus 6). Lower the numbers for a harder game.
- Time limits now start at level 10, press limits at 18, spinning blob at 28.

## v6: toolbar
- Armed cores now appear every 20 levels (`coreCount()`), with a generous fuse (`pickCores()`). Secure one to keep a Core in the toolbar; let it blow and you lose a life.
- Toolbar (above the colour buttons): Core (tap, then a colour: pulls that whole colour) and Slice (tap, drag across the blob: it splits in two for 3 pulls and balls only block others on their own side).
- Earning: Slice is gifted at level 8, then +1 every 5 flawless levels in a row (`reward()`). Core comes from core levels. Both can be bought with stars in the Shop (prices in `renderShop()`). Max 9 of each; saved on the device.

## v7
- `design/LEVEL_DESIGN.md` and `design/levels_1_1000.csv`: the full 1,000-level design, generated from `plan()` in `www/index.html`.
- Scripted tutorials (levels 1, 2, 3, 15, 20, 45, 65) lock the controls to the required action.
- New tools: Grapple Gun (introduced at 45) and Plunger (65). Shop rebuilt: tabs, rarity, buy confirmation, stars only.
- Screen shake reduced by about 45%.

## v8
- **Biscuit the quokka and his ball pit.** Every ball you collect goes into the pit. It is built up in 12 stages (signpost, fence, lights, slide... legendary pit). Cutscenes play every 5 levels, at build milestones, at level 100s, and as an opening before level 1. Skippable, and can be switched off in Settings.
- **Shop rebuilt:** 116 items in 8 categories (magnets, effects, sparks, worlds, buttons, balls, sounds, tools). Rarities Common to Mythic. Mythic items need achievements as well as stars.
- **Test mode:** Settings > Test mode restarts the app on a separate save with infinite stars, every item unlocked, spawnable tools, a level jumper that explains each level, and a cutscene player. **Set `DEV_TOGGLE=false` in `www/index.html` before publishing**, otherwise players can skip the level-pack paywall.
