# Clack! Magnetic Jam: Android project

## Build the APK / AAB
1. Install Node 18+, Android Studio and a JDK (Android Studio bundles one).
2. In this folder: `npm install` (also copies Tone.js and fonts into `www/`).
3. `npx cap add android` (first time only), then `npm run sync`.
4. Change `appId` in `capacitor.config.json` to your own reverse-domain id before you add Android.
5. `npm run open`, then in Android Studio: Build > Generate Signed Bundle / APK.
   Google Play needs the **AAB**; the APK is for sideloading and testing.
6. App icon and splash: put `icon.png` (1024x1024) in `assets/`, then `npx @capacitor/assets generate --android`.

## Level packs (what's in the game)
| Levels | Price | Play Console product id |
|---|---|---|
| 1 - 1,000 | Free | none |
| 1,001 - 10,000 | £3.99 | `clack_pack_9k` |
| 10,001 - 100,000 | £3.99 | `clack_pack_90k` |
| 100,001 - 1,000,000 | £3.99 | `clack_pack_900k` |
| 1,000,001 - 11,000,000 | £3.99 | `clack_pack_10m` |

Levels are generated from the level number (seeded), so the same level is identical every time and nothing is stored.

## Turn on real payments
1. Play Console > your app > Monetize > In-app products: create the four ids above as **one-time products**, price £3.99, status Active.
2. Upload a build to Internal testing, add yourself under License testers, and install from the testing link. Billing does not work on a sideloaded APK.
3. In a normal browser the game uses a **test mode** that unlocks packs for free. Inside the APK it never does, so a failed store connection can't hand out free levels.
4. Purchases are not receipt-verified. For serious revenue add server-side validation (RevenueCat or your own backend) before launch.

## Before you publish
- Fill in the Play Console data safety form and add a privacy policy URL (required even for a game that collects nothing).
- Progress is saved on the device only (localStorage). Uninstalling clears it; owned packs come back via "Restore purchases".
- Levels are procedurally generated. Difficulty and solvability across all 11M have not been brute-force tested, so play a few hundred at various depths and tune `generateLevel()` in `www/index.html`.
