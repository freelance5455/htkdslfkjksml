Flappy Bird Android project
===========================

El HTML original se incluye como app/src/main/assets/index.html y se carga
dentro de un WebView de Android. La app está configurada en vertical y pantalla
completa.

Cómo generar la APK:
1. Instala Android Studio en un ordenador.
2. Descomprime este ZIP.
3. En Android Studio, elige Open y selecciona la carpeta FlappyBirdAndroid.
4. Espera a que termine la sincronización de Gradle.
5. Ve a Build > Build Bundle(s) / APK(s) > Build APK(s).
6. La APK de depuración aparecerá normalmente en:
   app/build/outputs/apk/debug/app-debug.apk

Nota: este entorno no tiene instalado Android SDK/Gradle, así que aquí no se ha
compilado una APK binaria. Este archivo es el proyecto preparado para compilarla.
