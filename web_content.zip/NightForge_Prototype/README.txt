NIGHTFORGE STUDIO — Prototype 0.1
==================================

A tiny dark-minimalist 3D game editor concept for Windows.

HOW TO RUN
1. Extract the ZIP file.
2. Open index.html in a modern browser (Microsoft Edge or Google Chrome).
3. Internet access is required because the prototype loads Three.js from jsDelivr CDN.
4. Click the object buttons to add objects, select them from Scene Objects, and edit transforms in Inspector.
5. Click Play to test the preview mode.
6. Click Export scene to download a JSON description of the scene.

WHAT WORKS
- Dark minimalist editor UI
- Interactive 3D viewport (orbit by dragging, zoom with mouse wheel)
- Add Cube, Sphere, Point Light, Monster, and Ground Plane
- Select objects and edit position, scale, and name
- Basic atmosphere/fog controls
- Play/stop preview toggle
- Export scene as JSON

CURRENT LIMITATIONS
- This is a first UI/3D prototype, not a full game engine.
- Script panel is currently a mock editor; arbitrary code is not executed.
- Play mode is a preview placeholder with basic camera movement, not a full gameplay runtime.
- Scene JSON export is a starting format; re-import, asset management, physics, and executable builds are future milestones.

NEXT ARCHITECTURE STEPS
1. Desktop shell (Tauri or Electron) around this editor.
2. Scene graph and project file format.
3. Script runtime / supported scripting API.
4. Physics, collision, character controller, and AI components.
5. Asset import and Windows game export.
