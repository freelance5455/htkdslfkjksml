# Micro Panel Only — Android project

This project wraps the offline Micro Panel Only app in an Android WebView. It has no GPS permission and does not connect to or modify Free Fire.

## Build an installable APK
1. Install Android Studio on a computer.
2. Open this folder (`android`) as a project.
3. Wait for Gradle sync.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the output path, typically `app/build/outputs/apk/debug/app-debug.apk`.

This environment does not have the Android SDK/Gradle build setup available, so this ZIP includes source and the working offline web app, not a compiled APK binary.
