package com.example.lockapp

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.webkit.JavascriptInterface
import androidx.core.app.ActivityCompat

/** WebView bridge. Torch alternates ON/OFF for 49 seconds total. */
class AndroidAudioBridge(private val activity: Activity) {
    private val appContext: Context = activity.applicationContext
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var flashRunning = false
    private var flashCameraId: String? = null
    private var flashOn = false
    private var flashStartedAt = 0L
    private var permissionRequestPending = false
    private var pulseRunnable: Runnable? = null

    @JavascriptInterface
    fun ensureVolume97(): Boolean = try {
        val audio = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        if (max > 0) audio.setStreamVolume(
            AudioManager.STREAM_MUSIC,
            kotlin.math.ceil(max * 0.97).toInt().coerceAtMost(max), 0
        )
        true
    } catch (_: Exception) { false }

    @JavascriptInterface
    fun openGoogle(): Boolean = try {
        val url = Uri.parse("https://www.google.com/search?q=${Uri.encode("xxx")}")
        val google = Intent(Intent.ACTION_VIEW, url)
            .setPackage("com.google.android.googlequicksearchbox")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { appContext.startActivity(google) }
        catch (_: Exception) {
            appContext.startActivity(Intent(Intent.ACTION_VIEW, url)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        true
    } catch (_: Exception) { false }

    @JavascriptInterface
    fun startFlashPulsing49(): Boolean {
        if (flashRunning) return true
        if (ActivityCompat.checkSelfPermission(
                activity, android.Manifest.permission.CAMERA
            ) != PackageManager.PERMISSION_GRANTED) {
            if (!permissionRequestPending) {
                permissionRequestPending = true
                activity.runOnUiThread {
                    ActivityCompat.requestPermissions(
                        activity, arrayOf(android.Manifest.permission.CAMERA),
                        CAMERA_PERMISSION_REQUEST
                    )
                }
            }
            return false
        }
        return beginPulseSequence()
    }

    /** Forward Activity.onRequestPermissionsResult here. */
    fun onCameraPermissionResult(requestCode: Int, grantResults: IntArray) {
        if (requestCode != CAMERA_PERMISSION_REQUEST) return
        permissionRequestPending = false
        if (grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            beginPulseSequence()
        }
    }

    private fun beginPulseSequence(): Boolean = try {
        val manager = appContext.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = manager.cameraIdList.firstOrNull { cameraId ->
            val c = manager.getCameraCharacteristics(cameraId)
            c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                c.get(CameraCharacteristics.LENS_FACING) ==
                CameraCharacteristics.LENS_FACING_BACK
        } ?: return false

        stopFlashInternal()
        flashCameraId = id
        flashRunning = true
        flashStartedAt = SystemClock.elapsedRealtime()
        flashOn = false
        schedulePulse(0L)
        true
    } catch (_: Exception) {
        stopFlashInternal()
        false
    }

    private fun schedulePulse(delayMs: Long) {
        pulseRunnable?.let { handler.removeCallbacks(it) }
        val task = object : Runnable {
            override fun run() {
                if (!flashRunning) return
                val elapsed = SystemClock.elapsedRealtime() - flashStartedAt
                if (elapsed >= FLASH_DURATION_MS) {
                    stopFlashInternal()
                    return
                }
                val id = flashCameraId ?: run { stopFlashInternal(); return }
                try {
                    val next = !flashOn
                    (appContext.getSystemService(Context.CAMERA_SERVICE) as CameraManager)
                        .setTorchMode(id, next)
                    flashOn = next
                } catch (_: Exception) {
                    // Retry on the next tick if Android temporarily rejects torch access.
                }
                val remaining = FLASH_DURATION_MS -
                    (SystemClock.elapsedRealtime() - flashStartedAt)
                if (remaining <= 0L) stopFlashInternal()
                else schedulePulse(PULSE_INTERVAL_MS.coerceAtMost(remaining))
            }
        }
        pulseRunnable = task
        handler.postDelayed(task, delayMs)
    }

    @JavascriptInterface
    fun stopFlash(): Boolean {
        stopFlashInternal()
        return true
    }

    private fun stopFlashInternal() {
        flashRunning = false
        pulseRunnable?.let { handler.removeCallbacks(it) }
        pulseRunnable = null
        val id = flashCameraId
        if (id != null && flashOn) try {
            (appContext.getSystemService(Context.CAMERA_SERVICE) as CameraManager)
                .setTorchMode(id, false)
        } catch (_: Exception) { }
        flashOn = false
        flashCameraId = null
    }

    companion object {
        const val CAMERA_PERMISSION_REQUEST = 7301
        private const val FLASH_DURATION_MS = 49_000L
        private const val PULSE_INTERVAL_MS = 500L
    }
}
