@echo off
setlocal
cd /d "%~dp0"
if "%ANDROID_HOME%"=="" set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
set "BT=%ANDROID_HOME%\build-tools\35.0.0"
set "JAR=%ANDROID_HOME%\platforms\android-35\android.jar"
if not exist "%BT%\aapt2.exe" (
  echo Install Android SDK platform 35 and build-tools 35, then set ANDROID_HOME.
  exit /b 1
)
if not exist "build" mkdir build\compiled build\classes build\dex
set "APP=app\src\main"
"%BT%\aapt2.exe" compile -o build\compiled\strings.flat "%APP%\res\values\strings.xml"
"%BT%\aapt2.exe" compile -o build\compiled\net.flat "%APP%\res\xml\network_security_config.xml"
"%BT%\aapt2.exe" compile -o build\compiled\icon.flat "%APP%\res\drawable\ic_launcher.png"
"%BT%\aapt2.exe" link -o build\base.apk -I "%JAR%" --manifest "%APP%\AndroidManifest.xml" --min-sdk-version 26 --target-sdk-version 35 --version-code 1 --version-name 1.0.0 -A "%APP%\assets" build\compiled\strings.flat build\compiled\net.flat build\compiled\icon.flat
javac --release 17 -classpath "%JAR%" -d build\classes "%APP%\java\app\yooyyaa\*.java"
call "%BT%\d8.bat" --min-api 26 --lib "%JAR%" --output build\dex build\classes\app\yooyyaa\*.class
copy /y build\base.apk build\with-dex.apk >nul
powershell -NoProfile -Command "Compress-Archive -Path build\dex\classes.dex -DestinationPath build\dex.zip -Force; Copy-Item build\with-dex.apk build\tmp.zip; Expand-Archive build\dex.zip -DestinationPath build\dexun -Force"
cd build\dex
jar uf ..\with-dex.apk classes.dex
cd ..\..
"%BT%\zipalign.exe" -p -f 4 build\with-dex.apk build\aligned.apk
if not exist yooyyaa.jks (
  keytool -genkeypair -keystore yooyyaa.jks -storepass yooyyaa-build -keypass yooyyaa-build -alias yooyyaa -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=YOOYYAA, O=YOOYYAA, C=ET"
)
call "%BT%\apksigner.bat" sign --ks yooyyaa.jks --ks-key-alias yooyyaa --ks-pass pass:yooyyaa-build --key-pass pass:yooyyaa-build --out YOOYYAA.apk build\aligned.apk
echo Built YOOYYAA.apk
exit /b 0
