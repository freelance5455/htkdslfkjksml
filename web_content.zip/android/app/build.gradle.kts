plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.rewardedssvmessenger"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.rewardedssvmessenger"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        // Android emulator -> host machine.
        // Change this for a physical device or production backend.
        buildConfigField(
            "String",
            "API_BASE_URL",
            "\"http://10.0.2.2:3000\""
        )
    }

    buildFeatures {
        buildConfig = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.gms:play-services-ads:23.0.0")
}
