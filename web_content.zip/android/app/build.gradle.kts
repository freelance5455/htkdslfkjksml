plugins { id("com.android.application") }
android { namespace="com.shesha.delivery"; compileSdk=35
    defaultConfig { applicationId="com.shesha.delivery"; minSdk=24; targetSdk=35; versionCode=1; versionName="1.0" }
}
