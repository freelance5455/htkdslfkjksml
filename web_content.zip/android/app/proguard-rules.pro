# Keep SDK APIs that may be accessed through reflection if release minification is enabled later.
-keep class ir.myket.billingclient.** { *; }
-keep interface ir.myket.billingclient.** { *; }
-keep class com.android.vending.billing.** { *; }
-keepclassmembers class ir.myket.billingclient.util.** {
    public <fields>;
    public <methods>;
}
-keep class ir.tapsell.plus.** { *; }
-keep interface ir.tapsell.plus.** { *; }
