# Proguard rules for JARVIS
-keepattributes JavascriptInterface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.jarvis.ai.** { *; }
-dontwarn android.webkit.**
