# Caliber ships without minification by default.
