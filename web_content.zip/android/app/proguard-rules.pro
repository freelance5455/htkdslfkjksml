# Vishal Tools — release shrinking is off by default (see app/build.gradle.kts).
# Add keep rules here only if you later set isMinifyEnabled = true.
