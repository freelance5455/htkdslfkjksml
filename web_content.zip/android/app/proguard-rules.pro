# Keep WebView JavaScript bridge and Billing classes used by reflection/callbacks.
-keepclassmembers class com.mdcatnums.prep.MainActivity {
    public *;
}
