# CINEMA GOLD release rules
