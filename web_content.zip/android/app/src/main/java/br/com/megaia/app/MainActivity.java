package br.com.megaia.app;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ServiceWorkerClient;
import android.webkit.ServiceWorkerController;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.credentials.ClearCredentialStateRequest;
import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.ClearCredentialException;
import androidx.credentials.exceptions.GetCredentialCancellationException;
import androidx.credentials.exceptions.GetCredentialException;
import androidx.credentials.exceptions.NoCredentialException;
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;
import androidx.webkit.WebViewAssetLoader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_FILE = 1001, REQ_WEB_PERM = 1002, REQ_CAMERA = 1003, REQ_MIC = 1004;
    private static final String HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + HOST + "/assets/index.html";
    private int mainErrors = 0;
    private long lastMainErrorAt = 0;
    private WebView web;
    private ValueCallback<Uri[]> filePathCallback;
    private PermissionRequest pendingPermission;
    private Uri cameraUri;

    // Leitura em voz alta (TextToSpeech nativo, funciona offline se a voz estiver instalada)
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private String pendingSpeech = null;
    private int ttsGen = 0;
    private String currentLast = "";

    public class TtsBridge {
        @JavascriptInterface public void speak(final String text) { runOnUiThread(() -> doSpeak(text)); }
        @JavascriptInterface public void stop() { runOnUiThread(() -> { if (tts != null) tts.stop(); }); }
    }

    // Reconhecimento de voz nativo (o WebView não tem SpeechRecognition)
    private SpeechRecognizer stt;
    private String pendingSttLang = null;

    public class SttBridge {
        @JavascriptInterface public boolean available() { return SpeechRecognizer.isRecognitionAvailable(MainActivity.this); }
        @JavascriptInterface public void start(final String lang) { runOnUiThread(() -> startStt(lang)); }
        @JavascriptInterface public void stop() { runOnUiThread(() -> { if (stt != null) stt.stopListening(); }); }
        @JavascriptInterface public void cancel() { runOnUiThread(() -> { if (stt != null) stt.cancel(); }); }
    }

    private void sttJs(String fn, String arg) {
        if (web == null) return;
        web.evaluateJavascript("window." + fn + "&&window." + fn + "(" + (arg == null ? "" : org.json.JSONObject.quote(arg)) + ")", null);
    }

    private String firstResult(Bundle b) {
        ArrayList<String> l = b == null ? null : b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        return (l == null || l.isEmpty()) ? "" : l.get(0);
    }

    private void startStt(String lang) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingSttLang = lang;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { sttJs("onSttError", "unavailable"); return; }
        if (tts != null) tts.stop();
        if (stt == null) {
            stt = SpeechRecognizer.createSpeechRecognizer(this);
            stt.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle p) { sttJs("onSttReady", null); }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float v) { }
                @Override public void onBufferReceived(byte[] b) { }
                @Override public void onEndOfSpeech() { }
                @Override public void onPartialResults(Bundle b) { sttJs("onSttPartial", firstResult(b)); }
                @Override public void onResults(Bundle b) { sttJs("onSttFinal", firstResult(b)); }
                @Override public void onEvent(int t, Bundle p) { }
                @Override public void onError(int code) { sttJs("onSttError", String.valueOf(code)); }
            });
        }
        stt.cancel();
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, (lang == null || lang.isEmpty()) ? "pt-BR" : lang);
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        stt.startListening(i);
    }


    // ---------- Login com Google (Credential Manager, nativo) ----------
    // O Google bloqueia login OAuth dentro de WebView; por isso o login é feito pelo Android
    // e só o token (ID token) é entregue à página.
    public class GoogleBridge {
        @JavascriptInterface public boolean configured() {
            String id = getString(R.string.google_web_client_id);
            return id != null && id.endsWith(".apps.googleusercontent.com") && !id.startsWith("COLE_AQUI");
        }
        @JavascriptInterface public void signIn() { runOnUiThread(() -> googleSignIn()); }
        @JavascriptInterface public void signOut() { runOnUiThread(() -> googleSignOut()); }
    }

    private void googleJs(String fn, String arg) {
        if (web == null) return;
        web.evaluateJavascript("window." + fn + "&&window." + fn + "(" + org.json.JSONObject.quote(arg == null ? "" : arg) + ")", null);
    }

    private void googleSignIn() {
        final String cid = getString(R.string.google_web_client_id);
        if (cid == null || cid.startsWith("COLE_AQUI") || !cid.endsWith(".apps.googleusercontent.com")) {
            googleJs("onGoogleError", "not_configured");
            return;
        }
        try {
            CredentialManager cm = CredentialManager.Companion.create(this);
            GetCredentialRequest req = new GetCredentialRequest.Builder()
                    .addCredentialOption(new GetSignInWithGoogleOption.Builder(cid).build())
                    .build();
            cm.getCredentialAsync(this, req, new android.os.CancellationSignal(), ContextCompat.getMainExecutor(this),
                    new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                        @Override public void onResult(GetCredentialResponse result) {
                            try {
                                Credential c = result.getCredential();
                                if (c instanceof CustomCredential
                                        && GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(c.getType())) {
                                    GoogleIdTokenCredential g = GoogleIdTokenCredential.createFrom(((CustomCredential) c).getData());
                                    org.json.JSONObject o = new org.json.JSONObject();
                                    o.put("idToken", g.getIdToken());
                                    o.put("email", g.getId());
                                    o.put("name", g.getDisplayName() == null ? "" : g.getDisplayName());
                                    o.put("picture", g.getProfilePictureUri() == null ? "" : g.getProfilePictureUri().toString());
                                    googleJs("onGoogleLogin", o.toString());
                                } else {
                                    googleJs("onGoogleError", "unexpected_credential");
                                }
                            } catch (Exception e) {
                                googleJs("onGoogleError", "parse:" + e.getMessage());
                            }
                        }
                        @Override public void onError(GetCredentialException e) {
                            if (e instanceof GetCredentialCancellationException) googleJs("onGoogleError", "cancelled");
                            else if (e instanceof NoCredentialException) googleJs("onGoogleError", "no_account");
                            else googleJs("onGoogleError", "error:" + e.getType() + ":" + e.getMessage());
                        }
                    });
        } catch (Exception e) {
            googleJs("onGoogleError", "error:" + e.getMessage());
        }
    }

    private void googleSignOut() {
        try {
            CredentialManager cm = CredentialManager.Companion.create(this);
            cm.clearCredentialStateAsync(new ClearCredentialStateRequest(), new android.os.CancellationSignal(),
                    ContextCompat.getMainExecutor(this),
                    new CredentialManagerCallback<Void, ClearCredentialException>() {
                        @Override public void onResult(Void r) { }
                        @Override public void onError(ClearCredentialException e) { }
                    });
        } catch (Exception ignored) { }
    }

    public class ShareBridge {
        @JavascriptInterface public void shareFile(final String name, final String text) { runOnUiThread(() -> doShare(name, text)); }
    }

    private void doShare(String name, String text) {
        try {
            File dir = new File(getCacheDir(), "export");
            dir.mkdirs();
            File[] old = dir.listFiles();
            if (old != null) for (File o : old) o.delete();
            String safe = name == null ? "conversa.md" : name.replaceAll("[^A-Za-z0-9._-]", "_");
            if (safe.isEmpty()) safe = "conversa.md";
            File f = new File(dir, safe);
            try (FileOutputStream o = new FileOutputStream(f)) { o.write(text.getBytes("UTF-8")); }
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_STREAM, uri);
            i.putExtra(Intent.EXTRA_SUBJECT, safe);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, "Exportar conversa"));
        } catch (Exception e) {
            try {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, text);
                startActivity(Intent.createChooser(i, "Exportar conversa"));
            } catch (Exception ignored) { }
        }
    }

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);

        // Serve os arquivos do app em https://appassets.androidplatform.net (origem segura:
        // permite cache do modelo offline, service worker, microfone e câmera).
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        if (Build.VERSION.SDK_INT >= 24) {
            ServiceWorkerController.getInstance().setServiceWorkerClient(new ServiceWorkerClient() {
                @Override
                public WebResourceResponse shouldInterceptRequest(WebResourceRequest request) {
                    WebResourceResponse cr = cdnCache(request);
                    if (cr != null) return cr;
                    return loader.shouldInterceptRequest(request.getUrl());
                }
            });
        }

        web.addJavascriptInterface(new TtsBridge(), "MegaTTS");
        web.addJavascriptInterface(new ShareBridge(), "MegaShare");
        web.addJavascriptInterface(new SttBridge(), "MegaSTT");
        web.addJavascriptInterface(new GoogleBridge(), "MegaGoogle");

        web.setOnApplyWindowInsetsListener((v, insets) -> {
            int l, t, r, bt;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets i = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.ime());
                l = i.left; t = i.top; r = i.right; bt = i.bottom;
            } else {
                l = insets.getSystemWindowInsetLeft(); t = insets.getSystemWindowInsetTop();
                r = insets.getSystemWindowInsetRight(); bt = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(l, t, r, bt);
            return insets;
        });

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                WebResourceResponse cr = cdnCache(request);
                if (cr != null) return cr;
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (url != null && url.startsWith("https://" + HOST + "/")) mainErrors = 0;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request != null && request.isForMainFrame())
                    mainFrameFailed(error.getErrorCode(), String.valueOf(error.getDescription()), String.valueOf(request.getUrl()));
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse resp) {
                if (request != null && request.isForMainFrame() && resp.getStatusCode() >= 400)
                    mainFrameFailed(resp.getStatusCode(), "HTTP " + resp.getStatusCode() + " " + resp.getReasonPhrase(), String.valueOf(request.getUrl()));
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> handleWebPermission(request));
            }

            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = cb;
                if (params.isCaptureEnabled()) {
                    if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        launchCamera();
                    } else {
                        requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
                    }
                    return true;
                }
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (ActivityNotFoundException e) {
                    finishChooser(null);
                    return false;
                }
                return true;
            }
        });

        setContentView(web);
        web.loadUrl(START_URL);
    }

    // ---------- Falha ao abrir a tela do app ("Página da Web não disponível") ----------
    // Em vez da página de erro genérica do WebView, tenta de novo uma vez e, se falhar,
    // mostra o código real do erro com um botão para tentar de novo.
    private void mainFrameFailed(int code, String desc, String url) {
        long now = System.currentTimeMillis();
        if (now - lastMainErrorAt < 1500) return; // o WebView pode avisar o mesmo erro duas vezes
        lastMainErrorAt = now;
        mainErrors++;
        if (web == null) return;
        if (mainErrors == 1) {
            web.postDelayed(() -> { if (web != null) web.loadUrl(START_URL); }, 600);
            return;
        }
        showErrorPage(code, desc, url);
    }

    private static String esc(String t) {
        return t == null ? "" : t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    private void showErrorPage(int code, String desc, String url) {
        if (web == null) return;
        String html = "<!doctype html><html lang='pt-BR'><head><meta charset='utf-8'>"
                + "<meta name='viewport' content='width=device-width,initial-scale=1'>"
                + "<style>body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;"
                + "background:#10111B;color:#EDEBFF;font-family:sans-serif;padding:24px;box-sizing:border-box}"
                + ".c{max-width:420px}h1{font-size:22px;margin:0 0 12px}p{line-height:1.5;color:#B9B6D6}"
                + "code{display:block;margin:14px 0;padding:10px;background:#1B1C2B;border-radius:8px;"
                + "color:#C9B8FF;font-size:12px;word-break:break-all}"
                + "a{display:block;text-align:center;margin-top:18px;padding:14px;border-radius:12px;"
                + "background:#9A7CFF;color:#10111B;font-weight:bold;text-decoration:none}</style></head>"
                + "<body><div class='c'><h1>Não consegui abrir a MegaIA</h1>"
                + "<p>O app não conseguiu carregar a própria tela. Toque em tentar de novo. "
                + "Se continuar, me mande o código abaixo.</p>"
                + "<code>Erro " + code + ": " + esc(desc) + "<br>" + esc(url) + "</code>"
                + "<a href='" + START_URL + "'>Tentar de novo</a></div></body></html>";
        web.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
    }

    // ---------- Motor do modelo offline: guarda em disco o que vem do jsDelivr ----------
    private static final Object CDN_LOCK = new Object();

    private static String sha1(String s) throws Exception {
        byte[] d = MessageDigest.getInstance("SHA-1").digest(s.getBytes("UTF-8"));
        StringBuilder sb = new StringBuilder();
        for (byte b : d) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    private WebResourceResponse cdnCache(WebResourceRequest request) {
        try {
            Uri u = request.getUrl();
            if (!"GET".equalsIgnoreCase(request.getMethod()) || !"cdn.jsdelivr.net".equals(u.getHost())) return null;
            File dir = new File(getFilesDir(), "cdn");
            dir.mkdirs();
            String key = sha1(u.toString());
            File data = new File(dir, key), type = new File(dir, key + ".type");
            synchronized (CDN_LOCK) {
                if (!data.exists() || !type.exists()) {
                    HttpURLConnection c = (HttpURLConnection) new URL(u.toString()).openConnection();
                    c.setConnectTimeout(15000);
                    c.setReadTimeout(60000);
                    if (c.getResponseCode() != 200) { c.disconnect(); return null; }
                    String ct = c.getContentType();
                    if (ct == null) ct = "application/octet-stream";
                    File tmp = new File(dir, key + ".tmp");
                    try (InputStream in = c.getInputStream(); FileOutputStream out = new FileOutputStream(tmp)) {
                        byte[] buf = new byte[32768];
                        int n;
                        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    }
                    c.disconnect();
                    data.delete();
                    if (!tmp.renameTo(data)) return null;
                    try (FileOutputStream o = new FileOutputStream(type)) { o.write(ct.getBytes("UTF-8")); }
                }
            }
            byte[] tb = new byte[(int) type.length()];
            try (FileInputStream ti = new FileInputStream(type)) { ti.read(tb); }
            String mime = new String(tb, "UTF-8").split(";")[0].trim();
            Map<String, String> h = new HashMap<>();
            h.put("Access-Control-Allow-Origin", "*");
            h.put("Cross-Origin-Resource-Policy", "cross-origin");
            String enc = (mime.startsWith("text/") || mime.contains("javascript") || mime.contains("json")) ? "utf-8" : null;
            return new WebResourceResponse(mime, enc, 200, "OK", h, new FileInputStream(data));
        } catch (Exception e) {
            return null;
        }
    }

    // ---------- Voz ----------
    private void doSpeak(final String text) {
        if (tts == null) {
            pendingSpeech = text;
            tts = new TextToSpeech(this, status -> {
                if (status == TextToSpeech.SUCCESS) {
                    int r = tts.setLanguage(new Locale("pt", "BR"));
                    if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) tts.setLanguage(Locale.getDefault());
                    tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                        @Override public void onStart(String id) { }
                        @Override public void onDone(String id) { if (id != null && id.equals(currentLast)) notifyTtsDone(); }
                        @Override public void onError(String id) { if (id != null && id.equals(currentLast)) notifyTtsDone(); }
                    });
                    ttsReady = true;
                    if (pendingSpeech != null) { String t = pendingSpeech; pendingSpeech = null; speakNow(t); }
                } else {
                    tts = null;
                    notifyTtsDone();
                }
            });
            return;
        }
        if (!ttsReady) { pendingSpeech = text; return; }
        speakNow(text);
    }

    private void speakNow(String text) {
        tts.stop();
        List<String> parts = new ArrayList<>();
        String rest = text.trim();
        while (rest.length() > 3000) {
            int cut = rest.lastIndexOf(". ", 3000);
            if (cut < 1500) cut = rest.lastIndexOf(' ', 3000);
            if (cut < 1) cut = 3000;
            parts.add(rest.substring(0, cut + 1));
            rest = rest.substring(cut + 1).trim();
        }
        if (!rest.isEmpty()) parts.add(rest);
        ttsGen++;
        currentLast = "last" + ttsGen;
        for (int i = 0; i < parts.size(); i++) {
            String id = (i == parts.size() - 1) ? currentLast : "c" + ttsGen + "_" + i;
            if (Build.VERSION.SDK_INT >= 21) tts.speak(parts.get(i), TextToSpeech.QUEUE_ADD, null, id);
        }
    }

    private void notifyTtsDone() {
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript("window.onTtsDone&&window.onTtsDone()", null); });
    }

    // ---------- Permissões e arquivos ----------
    private void handleWebPermission(PermissionRequest request) {
        Uri o = request.getOrigin();
        if (!"https".equals(o.getScheme()) || !HOST.equals(o.getHost())) { request.deny(); return; }
        List<String> needed = new ArrayList<>();
        for (String r : request.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r) && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                needed.add(Manifest.permission.RECORD_AUDIO);
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r) && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
                needed.add(Manifest.permission.CAMERA);
        }
        if (needed.isEmpty()) {
            request.grant(request.getResources());
        } else {
            if (pendingPermission != null) pendingPermission.deny();
            pendingPermission = request;
            requestPermissions(needed.toArray(new String[0]), REQ_WEB_PERM);
        }
    }

    private void launchCamera() {
        try {
            File dir = new File(getCacheDir(), "camera");
            dir.mkdirs();
            File f = File.createTempFile("foto_", ".jpg", dir);
            cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE).putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(i, REQ_FILE);
        } catch (Exception e) {
            cameraUri = null;
            finishChooser(null);
        }
    }

    private void finishChooser(Uri[] result) {
        if (filePathCallback != null) filePathCallback.onReceiveValue(result);
        filePathCallback = null;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_FILE) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK) {
            if (data != null && (data.getData() != null || data.getClipData() != null)) {
                result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            } else if (cameraUri != null) {
                result = new Uri[]{cameraUri};
            }
        }
        cameraUri = null;
        finishChooser(result);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean ok = grantResults.length > 0;
        for (int g : grantResults) if (g != PackageManager.PERMISSION_GRANTED) ok = false;
        if (requestCode == REQ_WEB_PERM && pendingPermission != null) {
            if (ok) pendingPermission.grant(pendingPermission.getResources()); else pendingPermission.deny();
            pendingPermission = null;
        } else if (requestCode == REQ_CAMERA) {
            if (ok && filePathCallback != null) launchCamera(); else finishChooser(null);
        } else if (requestCode == REQ_MIC) {
            String l = pendingSttLang; pendingSttLang = null;
            if (ok) startStt(l); else sttJs("onSttError", "denied");
        }
    }

    @Override
    public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript("(function(){var sb=document.getElementById('sidebar'),h=false;"
                + "var g=document.querySelector('.fullgame');if(g){g.remove();h=true}"
                + "['gamesModal','settings','attachMenu','accountModal'].forEach(function(i){var e=document.getElementById(i);if(e&&!e.classList.contains('hidden')){e.classList.add('hidden');h=true}});"
                + "if(sb.classList.contains('open')){sb.classList.remove('open');h=true}"
                + "return h})()", v -> { if (!"true".equals(v)) finish(); });
    }

    @Override
    protected void onDestroy() {
        if (stt != null) { stt.destroy(); stt = null; }
        if (tts != null) { tts.stop(); tts.shutdown(); tts = null; }
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }
}
