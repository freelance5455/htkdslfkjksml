package br.com.caminhodopoder;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * O Caminho do Poder - As 48 Leis do Poder
 *
 * Activity nativa minima que hospeda o jogo (HTML5 + Canvas) dentro de um WebView.
 * Nao usa nenhuma dependencia externa (sem AndroidX), o que torna o APK minimo e rapido
 * de inicializar em aparelhos de baixo desempenho.
 *
 * Os arquivos do jogo sao servidos em https://appassets.androidplatform.net/ para que o
 * WebView trate o jogo como uma origem https real - assim o localStorage (save do jogo)
 * funciona de forma confiavel em qualquer versao do Android.
 */
public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String GAME_URL = "https://" + HOST + "/index.html";
    private static final String ASSET_ROOT = "www";

    private WebView web;
    private boolean loadedFallback = false;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.parseColor("#0B0812"));
        getWindow().setNavigationBarColor(Color.parseColor("#0B0812"));

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#0B0812"));

        web = new WebView(this);
        web.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        web.setBackgroundColor(Color.parseColor("#0B0812"));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);
        web.setLongClickable(false);
        web.setHapticFeedbackEnabled(false);
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);       // localStorage: salva o progresso do jogador
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setUseWideViewPort(false);
        s.setLoadWithOverviewMode(false);
        s.setTextZoom(100);                  // ignora a fonte do sistema (legibilidade do jogo)
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        s.setMediaPlaybackRequiresUserGesture(false); // libera o audio ambientado
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        }

        web.setWebViewClient(new AssetWebViewClient());
        root.addView(web);
        setContentView(root);

        hideSystemUI();
        web.loadUrl(GAME_URL);
    }

    /** Serve o build web do jogo a partir de uma origem https local. */
    private class AssetWebViewClient extends WebViewClient {

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            Uri url = request.getUrl();
            if (url == null || !HOST.equals(url.getHost())) return null;
            String path = url.getPath();
            if (path == null || path.length() <= 1) path = "/index.html";
            try {
                InputStream in = getAssets().open(ASSET_ROOT + path);
                Map<String, String> headers = new HashMap<String, String>();
                headers.put("Cache-Control", "no-cache");
                WebResourceResponse res = new WebResourceResponse(mimeOf(path), "utf-8", in);
                res.setResponseHeaders(headers);
                return res;
            } catch (IOException e) {
                return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found",
                        new HashMap<String, String>(), null);
            }
        }

        /** existe em todas as versoes do Android (API 1+) */
        @SuppressWarnings("deprecation")
        @Override
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            if (!loadedFallback && failingUrl != null && failingUrl.contains(HOST)) {
                loadedFallback = true;
                // assets indisponiveis: usa o caminho file:// classico
                view.loadUrl("file:///android_asset/" + ASSET_ROOT + "/index.html");
            }
        }
    }

    private static String mimeOf(String path) {
        if (path.endsWith(".html")) return "text/html";
        if (path.endsWith(".js")) return "application/javascript";
        if (path.endsWith(".css")) return "text/css";
        if (path.endsWith(".json")) return "application/json";
        if (path.endsWith(".png")) return "image/png";
        if (path.endsWith(".svg")) return "image/svg+xml";
        if (path.endsWith(".ico")) return "image/x-icon";
        return "application/octet-stream";
    }

    /** Tela cheia imersiva (sem barra de status/navegacao). */
    private void hideSystemUI() {
        View decor = getWindow().getDecorView();
        decor.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUI();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) {
            web.onResume();
            web.evaluateJavascript("window.__gameResume && window.__gameResume();", null);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (web != null) {
            // salva o progresso antes de o app ir para segundo plano
            web.evaluateJavascript("window.__gamePause && window.__gamePause();", null);
            web.onPause();
        }
    }

    @Override
    public void onBackPressed() {
        if (web != null) {
            // deixa o jogo fechar paineis/dialogos antes de sair do app
            web.evaluateJavascript("window.__gameBack ? window.__gameBack() : false;",
                    new ValueCallback<String>() {
                        @Override
                        public void onReceiveValue(String value) {
                            if (!"true".equals(value)) {
                                finishAfterTransition();
                            }
                        }
                    });
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
