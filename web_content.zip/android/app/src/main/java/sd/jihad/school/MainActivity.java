package sd.jihad.school;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
