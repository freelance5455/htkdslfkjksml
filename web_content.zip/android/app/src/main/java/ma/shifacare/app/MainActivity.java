package ma.shifacare.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
