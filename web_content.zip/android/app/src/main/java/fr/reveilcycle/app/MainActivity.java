package fr.reveilcycle.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
