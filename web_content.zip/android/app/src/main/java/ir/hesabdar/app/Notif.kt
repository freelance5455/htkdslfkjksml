package ir.hesabdar.app

import android.app.*
import android.content.*
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject

object Store {
    fun dupe(c: Context, body: String): Boolean {
        val k = body.filter { it.isDigit() }
        val p = c.getSharedPreferences("sms", 0)
        val now = System.currentTimeMillis()
        if (k == p.getString("dk", "") && now - p.getLong("dt", 0) < 30000) return true
        p.edit().putString("dk", k).putLong("dt", now).apply()
        return false
    }
    fun push(c: Context, k: String, o: JSONObject) {
        val p = c.getSharedPreferences("sms", 0)
        val a = JSONArray(p.getString(k, "[]"))
        a.put(o)
        p.edit().putString(k, a.toString()).apply()
    }
    fun drain(c: Context, k: String): String {
        val p = c.getSharedPreferences("sms", 0)
        val q = p.getString(k, "[]") ?: "[]"
        if (q != "[]") p.edit().putString(k, "[]").apply()
        return q
    }
}

object Notif {
    fun summary(body: String): String {
        val s = body.map { ch -> when (ch) { in '۰'..'۹' -> '0' + (ch - '۰'); in '٠'..'٩' -> '0' + (ch - '٠'); else -> ch } }.joinToString("")
        val m = Regex("\\d{1,3}(?:[,٬]\\d{3})+|\\d{5,}").find(s.replace(Regex("(?:موجودی|مانده)[:\\s]*[\\d,٬]+"), "")) ?: return "تراکنش جدید"
        var n = m.value.replace(",", "").replace("٬", "").toLongOrNull() ?: return "تراکنش جدید"
        if (!s.contains("تومان")) n /= 10
        val inc = Regex("واریز|دریافت|برگشت|سپرده|نشست|اضافه شد").containsMatchIn(s) && !Regex("برداشت|خرید|پرید").containsMatchIn(s)
        return (if (inc) "واریز " else "برداشت ") + String.format(java.util.Locale("fa"), "%,d", n) + " تومان"
    }

    fun schedule(c: Context) {
        val cal = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 9); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0)
            if (timeInMillis < System.currentTimeMillis()) add(java.util.Calendar.DAY_OF_YEAR, 1)
        }
        val pi = PendingIntent.getBroadcast(c, 7, Intent(c, ReminderReceiver::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        c.getSystemService(AlarmManager::class.java).setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY, pi)
    }

    const val CH = "tx"
    private fun builder(c: Context): Notification.Builder {
        if (Build.VERSION.SDK_INT >= 26) {
            c.getSystemService(NotificationManager::class.java)
                .createNotificationChannel(NotificationChannel(CH, "تراکنش‌ها و یادآوری", NotificationManager.IMPORTANCE_HIGH))
            return Notification.Builder(c, CH)
        }
        return Notification.Builder(c)
    }
    private fun open(c: Context) = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)

    fun ask(c: Context, id: Long, body: String) {
        val nid = (id % 100000).toInt()
        val b = builder(c).setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle(summary(body) + "؛ برای چی بود؟").setContentText(body.take(80))
            .setStyle(Notification.BigTextStyle().bigText(body)).setAutoCancel(true).setContentIntent(open(c))
        listOf("غذا", "حمل‌ونقل", "خرید", "سایر").forEachIndexed { k, cat ->
            val i = Intent(c, CatReceiver::class.java).putExtra("id", id).putExtra("cat", cat)
            b.addAction(0, cat, PendingIntent.getBroadcast(c, nid * 10 + k, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        }
        c.getSystemService(NotificationManager::class.java).notify(nid, b.build())
    }

    fun remind(c: Context, text: String, title: String = "یادآوری حسابدار من") {
        val b = builder(c).setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle(title).setContentText(text).setAutoCancel(true).setContentIntent(open(c))
        c.getSystemService(NotificationManager::class.java).notify(1, b.build())
    }
}

class CatReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getLongExtra("id", 0)
        Store.push(c, "cats", JSONObject().put("id", id).put("cat", i.getStringExtra("cat")))
        c.getSystemService(NotificationManager::class.java).cancel((id % 100000).toInt())
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val t = c.getSharedPreferences("sms", 0).getString("rem", "") ?: ""
        if (t.isNotEmpty()) Notif.remind(c, t)
    }
}

class QuickReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Store.push(c, "quick", JSONObject().put("n", i.getStringExtra("n")).put("a", i.getLongExtra("a", 0)).put("c", i.getStringExtra("c")))
        android.widget.Toast.makeText(c, "ثبت شد: " + i.getStringExtra("n"), android.widget.Toast.LENGTH_SHORT).show()
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) Notif.schedule(c)
    }
}
