package ir.hesabdar.app

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.KeyguardManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.PowerManager
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar

class MainActivity : Activity() {
    lateinit var web: WebView
    private var authed = false
    private var pausedAt = 0L

    private fun lockOn() = getSharedPreferences("sms", 0).getBoolean("lock", false)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.parseColor("#1e1b4b")
        if (lockOn()) window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(this), "Android")
        web.loadUrl("file:///android_asset/index.html")
        val need = mutableListOf(Manifest.permission.RECEIVE_SMS)
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        val miss = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (miss.isNotEmpty()) requestPermissions(miss.toTypedArray(), 1)
        scheduleReminder()
    }

    private fun scheduleReminder() {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0)
            if (timeInMillis < System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        val pi = PendingIntent.getBroadcast(this, 7, Intent(this, ReminderReceiver::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        getSystemService(AlarmManager::class.java).setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY, pi)
    }

    override fun onPause() { super.onPause(); pausedAt = System.currentTimeMillis() }

    override fun onResume() {
        super.onResume()
        if (lockOn() && (!authed || System.currentTimeMillis() - pausedAt > 20000)) {
            authed = false
            val km = getSystemService(KeyguardManager::class.java)
            if (km.isDeviceSecure) {
                val i = km.createConfirmDeviceCredentialIntent("قفل حسابدار من", "برای ورود هویتت رو تأیید کن")
                if (i != null) { web.visibility = View.INVISIBLE; startActivityForResult(i, 77) }
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, d: Intent?) {
        if (req == 77) { if (res == RESULT_OK) { authed = true; web.visibility = View.VISIBLE } else finish() }
        else super.onActivityResult(req, res, d)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }

    class Bridge(private val a: Activity) {
        private val p get() = a.getSharedPreferences("sms", 0)
        @JavascriptInterface fun drain(): String = Store.drain(a, "q")
        @JavascriptInterface fun drainCats(): String = Store.drain(a, "cats")
        @JavascriptInterface fun setWidget(t: String) { p.edit().putString("w", t).apply(); BalanceWidget.update(a) }
        @JavascriptInterface fun setLock(b: Boolean) { p.edit().putBoolean("lock", b).apply() }
        @JavascriptInterface fun setReminder(t: String) { p.edit().putString("rem", t).apply() }
        @JavascriptInterface fun hasAI(): Boolean = !p.getString("ak", "").isNullOrEmpty()
        @JavascriptInterface fun clearAI() { p.edit().remove("ak").apply() }
        @JavascriptInterface fun setAI(key: String, model: String, base: String) {
            val e = p.edit()
            if (key.isNotBlank()) e.putString("ak", key.trim())
            e.putString("am", model.trim()).putString("ab", base.trim()).apply()
        }
        @JavascriptInterface fun askAI(id: String, messages: String) {
            Thread {
                var out = ""
                var ok = false
                try {
                    val base = (p.getString("ab", "") ?: "").ifBlank { "https://api.openai.com/v1" }.trimEnd('/')
                    val model = (p.getString("am", "") ?: "").ifBlank { "gpt-4o-mini" }
                    val body = JSONObject().put("model", model).put("messages", JSONArray(messages)).toString()
                    val c = URL("$base/chat/completions").openConnection() as HttpURLConnection
                    c.requestMethod = "POST"; c.connectTimeout = 20000; c.readTimeout = 60000; c.doOutput = true
                    c.setRequestProperty("Content-Type", "application/json")
                    c.setRequestProperty("Authorization", "Bearer " + (p.getString("ak", "") ?: ""))
                    c.outputStream.use { it.write(body.toByteArray()) }
                    val code = c.responseCode
                    val txt = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
                    if (code in 200..299) {
                        out = JSONObject(txt).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content"); ok = true
                    } else {
                        val m = try { JSONObject(txt).getJSONObject("error").getString("message") } catch (e: Exception) { txt.take(120) }
                        out = "خطا ($code): $m"
                    }
                } catch (e: Exception) { out = "اتصال برقرار نشد: " + (e.message ?: "") }
                val js = "window.onAI('" + id + "'," + ok + "," + JSONObject.quote(out) + ")"
                a.runOnUiThread { (a as MainActivity).web.evaluateJavascript(js, null) }
            }.start()
        }
        @JavascriptInterface fun alert(title: String, text: String) { Notif.remind(a, text, title) }
        @JavascriptInterface fun clearAll() { p.edit().clear().apply(); BalanceWidget.update(a) }
        @JavascriptInterface fun drainQuick(): String = Store.drain(a, "quick")
        @JavascriptInterface fun setQuick(t: String) { p.edit().putString("wq", t).apply(); BalanceWidget.update(a) }
        @JavascriptInterface fun hasNotifAccess(): Boolean = (Settings.Secure.getString(a.contentResolver, "enabled_notification_listeners") ?: "").contains(a.packageName)
        @JavascriptInterface fun openNotifAccess() { a.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        @JavascriptInterface fun status(): String {
            val nm = a.getSystemService(NotificationManager::class.java)
            val sms = a.checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED
            val ok = if (Build.VERSION.SDK_INT >= 33) a.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED else nm.areNotificationsEnabled()
            val acc = (Settings.Secure.getString(a.contentResolver, "enabled_notification_listeners") ?: "").contains(a.packageName)
            val bat = a.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(a.packageName)
            return JSONObject().put("sms", sms).put("notif", ok).put("access", acc).put("battery", bat).toString()
        }
        @JavascriptInterface fun askPerms() {
            a.runOnUiThread {
                val l = mutableListOf(Manifest.permission.RECEIVE_SMS)
                if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
                a.requestPermissions(l.toTypedArray(), 1)
            }
        }
        @JavascriptInterface fun appSettings() { a.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(android.net.Uri.parse("package:" + a.packageName))) }
        @JavascriptInterface fun batterySettings() { a.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        @JavascriptInterface fun testNotif() {
            Notif.remind(a, "اعلان‌ها درست کار می‌کنن", "تست اعلان")
            Notif.ask(a, System.currentTimeMillis(), "برداشت پول\n450,000ریال از حساب شما پرید.\nموجودی: 1,124,074 ریال")
        }
        @JavascriptInterface fun share(t: String) {
            val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t)
            a.startActivity(Intent.createChooser(i, "اشتراک گزارش"))
        }
    }
}
