package ir.hesabdar.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews
import org.json.JSONArray

class BalanceWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) = refresh(c, m, ids)

    companion object {
        fun refresh(c: Context, m: AppWidgetManager, ids: IntArray) {
            val p = c.getSharedPreferences("sms", 0)
            val v = RemoteViews(c.packageName, R.layout.widget)
            v.setTextViewText(R.id.wb, p.getString("w", "—"))
            v.setOnClickPendingIntent(R.id.wroot, PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
            val q = try { JSONArray(p.getString("wq", "[]")) } catch (e: Exception) { JSONArray() }
            val vs = intArrayOf(R.id.q1, R.id.q2, R.id.q3)
            for (i in 0 until 3) {
                if (i < q.length()) {
                    val o = q.getJSONObject(i)
                    v.setTextViewText(vs[i], o.getString("n") + " " + (o.getLong("a") / 1000) + "ک")
                    v.setViewVisibility(vs[i], View.VISIBLE)
                    val it = Intent(c, QuickReceiver::class.java).putExtra("n", o.getString("n")).putExtra("a", o.getLong("a")).putExtra("c", o.getString("c"))
                    v.setOnClickPendingIntent(vs[i], PendingIntent.getBroadcast(c, 500 + i, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
                } else v.setViewVisibility(vs[i], View.GONE)
            }
            ids.forEach { m.updateAppWidget(it, v) }
        }
        fun update(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            refresh(c, m, m.getAppWidgetIds(ComponentName(c, BalanceWidget::class.java)))
        }
    }
}
