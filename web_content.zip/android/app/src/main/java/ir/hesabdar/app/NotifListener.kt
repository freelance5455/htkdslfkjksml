package ir.hesabdar.app

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONObject

// فقط اعلان‌هایی که شبیه تراکنش بانکی‌اند خونده و ذخیره می‌شن؛ بقیه اعلان‌ها نادیده گرفته می‌شن.
class NotifListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val e = sbn.notification.extras
        val body = listOfNotNull(e.getCharSequence("android.title"), e.getCharSequence("android.bigText") ?: e.getCharSequence("android.text")).joinToString("\n")
        if (!Regex("موجودی|ریال|برداشت|واریز|تومان").containsMatchIn(body)) return
        if (Store.dupe(this, body)) return
        val id = System.currentTimeMillis()
        Store.push(this, "q", JSONObject().put("id", id).put("t", body))
        Notif.ask(this, id, body)
    }
}
