package ir.hesabdar.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import org.json.JSONObject

// فقط پیامک‌هایی که شبیه پیامک بانکی‌اند ذخیره می‌شن؛ بقیه نادیده گرفته می‌شن.
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val body = Telephony.Sms.Intents.getMessagesFromIntent(i).joinToString("") { it.messageBody ?: "" }
        if (!Regex("موجودی|ریال|برداشت|واریز|تومان").containsMatchIn(body)) return
        if (Store.dupe(c, body)) return
        val id = System.currentTimeMillis()
        Store.push(c, "q", JSONObject().put("id", id).put("t", body))
        Notif.ask(c, id, body)
    }
}
