package ir.egames.davandefazayi;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

import ir.myket.billingclient.IabHelper;
import ir.myket.billingclient.util.IabResult;
import ir.myket.billingclient.util.Inventory;
import ir.myket.billingclient.util.Purchase;

import ir.tapsell.plus.AdRequestCallback;
import ir.tapsell.plus.AdShowListener;
import ir.tapsell.plus.TapsellPlus;
import ir.tapsell.plus.TapsellPlusInitListener;
import ir.tapsell.plus.model.AdNetworkError;
import ir.tapsell.plus.model.AdNetworks;
import ir.tapsell.plus.model.TapsellPlusAdModel;
import ir.tapsell.plus.model.TapsellPlusErrorModel;

/**
 * Native Android host for the offline Space Runner HTML5 game.
 *
 * Security boundaries:
 * - JavaScript may request operations, but may never assert a purchase/ad success.
 * - Billing success is accepted only from Myket's SDK result after SDK receipt/signature
 *   verification with the developer public key, plus exact SKU and developerPayload checks.
 * - Rewarded-ad success is emitted only from Tapsell Plus onRewarded callback.
 * - Pending grants are persisted before consume/acknowledgement so a process death does not
 *   silently lose a paid reward.
 */
public final class MainActivity extends Activity {
    private static final String TAG = "SpaceRunnerNative";
    private static final String GAME_ASSET_URL = "file:///android_asset/index.html";
    private static final String PREFS_NAME = "space_runner_native_v1";
    private static final String KEY_PENDING_GRANTS = "pending_grants_json";
    private static final String KEY_DELIVERED_GRANTS = "delivered_grants_json";
    private static final long AD_TIMEOUT_MS = 120_000L;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Map<String, String> productTypes = new HashMap<>();
    private final Set<String> knownProducts = new HashSet<>();

    private WebView webView;
    private boolean pageLoaded = false;
    private IabHelper billing;
    private boolean billingReady = false;
    private boolean billingSetupAttempted = false;
    private boolean purchaseInProgress = false;
    private String activePurchaseRequestId = null;
    private String activePurchaseSku = null;
    private String activePurchasePayload = null;

    private boolean tapsellReady = false;
    private boolean adInProgress = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(2, 5, 17));
        getWindow().setNavigationBarColor(Color.rgb(2, 5, 17));
        getWindow().getDecorView().setSystemUiVisibility(0);

        loadProductCatalog();
        createWebView();
        initializeBilling();
        initializeTapsell();
    }

    private void createWebView() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(2, 5, 17));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(2, 5, 17));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        webView.setWebChromeClient(new WebChromeClient());

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(false);
        webView.getSettings().setAllowFileAccessFromFileURLs(false);
        webView.getSettings().setAllowUniversalAccessFromFileURLs(false);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(true);
        webView.getSettings().setSupportZoom(false);
        webView.getSettings().setBuiltInZoomControls(false);
        webView.addJavascriptInterface(new SpaceRunnerBridge(), "SpaceRunnerNative");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (uri.toString().startsWith("file:///android_asset/")) {
                    return false;
                }
                openExternalUri(uri);
                return true;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                Uri uri = Uri.parse(url);
                if (uri.toString().startsWith("file:///android_asset/")) {
                    return false;
                }
                openExternalUri(uri);
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // The game reads this only when it needs the store listing fallback.
                String config = "window.SPACE_RUNNER_CONFIG={packageName:" +
                        JSONObject.quote(BuildConfig.APPLICATION_ID) + "};";
                view.evaluateJavascript(config, null);
                pageLoaded = true;
                if (billingReady) notifyBillingReadyToGame();
            }
        });

        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        webView.loadUrl(GAME_ASSET_URL);
    }

    private void openExternalUri(Uri uri) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(intent);
        } catch (ActivityNotFoundException | SecurityException e) {
            Toast.makeText(this, "برنامه‌ای برای باز کردن این پیوند پیدا نشد.", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadProductCatalog() {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                getAssets().open("MYKET-PRODUCT-CATALOG-fa.csv"), StandardCharsets.UTF_8))) {
            String line;
            boolean header = true;
            while ((line = reader.readLine()) != null) {
                if (header) { header = false; continue; }
                String[] fields = line.replace("\uFEFF", "").split(",", -1);
                if (fields.length < 2) continue;
                String sku = fields[0].trim();
                String type = fields[1].trim();
                if (!sku.matches("sr_[a-z0-9_]+")) continue;
                if (!("consumable".equals(type) || "non_consumable".equals(type))) continue;
                productTypes.put(sku, type);
                knownProducts.add(sku);
            }
        } catch (Exception e) {
            Log.e(TAG, "Unable to read product catalog", e);
        }
    }

    private void initializeBilling() {
        if (BuildConfig.IAB_PUBLIC_KEY == null || BuildConfig.IAB_PUBLIC_KEY.trim().isEmpty()) {
            Log.w(TAG, "Myket billing disabled: MYKET_RSA_PUBLIC_KEY is not configured.");
            return;
        }
        if (billingSetupAttempted) return;
        billingSetupAttempted = true;
        try {
            billing = new IabHelper(this, BuildConfig.IAB_PUBLIC_KEY.trim());
            billing.enableDebugLogging(BuildConfig.DEBUG);
            billing.startSetup(new IabHelper.OnIabSetupFinishedListener() {
                @Override
                public void onIabSetupFinished(IabResult result) {
                    if (result != null && result.isSuccess()) {
                        billingReady = true;
                        Log.i(TAG, "Myket billing is ready.");
                        if (pageLoaded) notifyBillingReadyToGame();
                    } else {
                        billingReady = false;
                        Log.e(TAG, "Myket billing setup failed: " + (result == null ? "unknown" : result.getMessage()));
                    }
                }
            });
        } catch (Exception e) {
            billingReady = false;
            Log.e(TAG, "Myket billing initialization failed", e);
        }
    }


    private void notifyBillingReadyToGame() {
        if (webView == null || !pageLoaded) return;
        String js = "(function(){window.__SPACE_RUNNER_BILLING_READY=true;" +
                "if(typeof window.onSpaceRunnerBillingReady==='function'){window.onSpaceRunnerBillingReady();}})();";
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(js, null);
        });
    }

    private void initializeTapsell() {
        String appKey = BuildConfig.TAPSELL_APP_KEY == null ? "" : BuildConfig.TAPSELL_APP_KEY.trim();
        if (appKey.isEmpty()) {
            Log.w(TAG, "Rewarded ads disabled: TAPSELL_APP_KEY is not configured.");
            return;
        }
        try {
            TapsellPlus.initialize(this, appKey, new TapsellPlusInitListener() {
                @Override
                public void onInitializeSuccess(AdNetworks adNetworks) {
                    tapsellReady = true;
                    Log.i(TAG, "Tapsell Plus initialized: " + adNetworks);
                }

                @Override
                public void onInitializeFailed(AdNetworks adNetworks, AdNetworkError error) {
                    tapsellReady = false;
                    Log.e(TAG, "Tapsell Plus initialization failed: " +
                            (error == null ? "unknown" : error.getErrorMessage()));
                }
            });
        } catch (Exception e) {
            tapsellReady = false;
            Log.e(TAG, "Tapsell Plus initialization error", e);
        }
    }

    private final class SpaceRunnerBridge {
        @JavascriptInterface
        public void postMessage(String rawMessage) {
            final JSONObject message;
            try {
                message = new JSONObject(rawMessage == null ? "{}" : rawMessage);
            } catch (JSONException e) {
                Log.w(TAG, "Invalid bridge JSON", e);
                return;
            }
            final String requestId = message.optString("requestId", "");
            if (requestId.isEmpty() || requestId.length() > 128 || message.optInt("protocol", 0) != 1) {
                return;
            }
            final String action = message.optString("action", "");
            final JSONObject payload = message.optJSONObject("payload") == null
                    ? new JSONObject() : message.optJSONObject("payload");
            mainHandler.post(() -> handleBridgeAction(requestId, action, payload));
        }
    }

    private void handleBridgeAction(String requestId, String action, JSONObject payload) {
        switch (action) {
            case "purchase":
                handlePurchase(requestId, payload);
                break;
            case "syncEntitlements":
                handleSyncEntitlements(requestId);
                break;
            case "acknowledgePurchaseGrant":
                handleAcknowledgeGrant(requestId, payload);
                break;
            case "showRewardedAd":
                handleRewardedAd(requestId, payload);
                break;
            case "openMyketListing":
                handleOpenMyketListing(requestId);
                break;
            default:
                replyError(requestId, "UNSUPPORTED_ACTION", "عملیات پشتیبانی نمی‌شود.");
        }
    }

    private void handlePurchase(String requestId, JSONObject payload) {
        String sku = payload.optString("productId", "");
        String type = payload.optString("productType", "");
        String developerPayload = payload.optString("developerPayload", "");
        String registeredType = productTypes.get(sku);

        if (!knownProducts.contains(sku) || registeredType == null || !registeredType.equals(type)) {
            replyError(requestId, "UNKNOWN_PRODUCT", "شناسه یا نوع محصول در کاتالوگ بازی ثبت نشده است.");
            return;
        }
        if (!isValidDeveloperPayload(sku, developerPayload)) {
            replyError(requestId, "INVALID_PAYLOAD", "شناسه درخواست خرید معتبر نیست.");
            return;
        }
        if (!billingReady || billing == null) {
            replyError(requestId, "BILLING_NOT_READY", "اتصال پرداخت مایکت آماده نیست.");
            return;
        }
        if (purchaseInProgress) {
            replyError(requestId, "PURCHASE_BUSY", "یک خرید دیگر در حال انجام است.");
            return;
        }

        purchaseInProgress = true;
        activePurchaseRequestId = requestId;
        activePurchaseSku = sku;
        activePurchasePayload = developerPayload;
        try {
            billing.launchPurchaseFlow(this, sku, new IabHelper.OnIabPurchaseFinishedListener() {
                @Override
                public void onIabPurchaseFinished(IabResult result, Purchase purchase) {
                    String responseId = activePurchaseRequestId;
                    String expectedSku = activePurchaseSku;
                    String expectedPayload = activePurchasePayload;
                    clearActivePurchase();
                    if (responseId == null) return;

                    if (result == null || !result.isSuccess() || purchase == null) {
                        String message = result == null ? "unknown" : result.getMessage();
                        boolean cancelled = message != null && message.toLowerCase().contains("cancel");
                        JSONObject out = baseResult(false, cancelled ? "cancelled" : "failed");
                        put(out, "errorCode", cancelled ? "USER_CANCELLED" : "MYKET_PURCHASE_FAILED");
                        put(out, "message", safeMessage(message));
                        reply(responseId, out);
                        return;
                    }

                    if (!expectedSku.equals(purchase.getSku()) ||
                            !expectedPayload.equals(purchase.getDeveloperPayload()) ||
                            !isValidDeveloperPayload(expectedSku, purchase.getDeveloperPayload()) ||
                            purchase.getToken() == null || purchase.getToken().trim().isEmpty()) {
                        replyError(responseId, "PURCHASE_MISMATCH", "رسید خرید با درخواست اصلی مطابقت ندارد.");
                        return;
                    }

                    String grantId = stableGrantId(purchase.getToken());
                    boolean needsGrant = "consumable".equals(type) ||
                            expectedSku.startsWith("sr_pack_") || expectedSku.startsWith("sr_offer_");

                    if ("consumable".equals(type)) {
                        if (!savePendingGrant(grantId, expectedSku, type, "consume_pending")) {
                            replyError(responseId, "GRANT_JOURNAL_FAILED", "ثبت امن پاداش خرید ناموفق بود.");
                            return;
                        }
                        consumePurchasedItem(purchase, grantId, responseId, expectedSku, type);
                    } else {
                        if (needsGrant && !savePendingGrant(grantId, expectedSku, type, "ready")) {
                            replyError(responseId, "GRANT_JOURNAL_FAILED", "ثبت امن پاداش خرید ناموفق بود.");
                            return;
                        }
                        JSONObject out = baseResult(true, "purchased");
                        put(out, "verified", true);
                        put(out, "productId", expectedSku);
                        put(out, "productType", type);
                        put(out, "developerPayload", expectedPayload);
                        if (needsGrant) put(out, "grantId", grantId);
                        reply(responseId, out);
                    }
                }
            }, developerPayload);
        } catch (Exception e) {
            clearActivePurchase();
            Log.e(TAG, "Unable to launch Myket purchase", e);
            replyError(requestId, "MYKET_LAUNCH_FAILED", "باز کردن پنجره خرید مایکت ممکن نشد.");
        }
    }

    private void clearActivePurchase() {
        purchaseInProgress = false;
        activePurchaseRequestId = null;
        activePurchaseSku = null;
        activePurchasePayload = null;
    }

    private boolean isValidDeveloperPayload(String sku, String value) {
        if (value == null || value.length() < 24 || value.length() > 220) return false;
        String prefix = "srp1_" + sku + "_";
        if (!value.startsWith(prefix)) return false;
        String nonce = value.substring(prefix.length());
        return nonce.length() >= 10 && nonce.matches("[a-z0-9_]+") && !nonce.contains("__");
    }

    private void consumePurchasedItem(Purchase purchase, String grantId, String requestId,
                                      String sku, String type) {
        try {
            billing.consumeAsync(purchase, new IabHelper.OnConsumeFinishedListener() {
                @Override
                public void onConsumeFinished(Purchase consumedPurchase, IabResult result) {
                    if (result != null && result.isSuccess() && consumedPurchase != null &&
                            sku.equals(consumedPurchase.getSku()) &&
                            purchase.getToken() != null && purchase.getToken().equals(consumedPurchase.getToken()) &&
                            purchase.getDeveloperPayload() != null &&
                            purchase.getDeveloperPayload().equals(consumedPurchase.getDeveloperPayload())) {
                        boolean saved = updateGrantStatus(grantId, "ready");
                        if (!saved) {
                            replyError(requestId, "GRANT_JOURNAL_FAILED", "خرید ثبت شد اما صف تحویل قابل ذخیره نیست؛ بازی را نبند و دوباره همگام‌سازی کن.");
                            return;
                        }
                        JSONObject out = baseResult(true, "purchased");
                        put(out, "verified", true);
                        put(out, "productId", sku);
                        put(out, "productType", type);
                        put(out, "developerPayload", consumedPurchase.getDeveloperPayload());
                        put(out, "consumed", true);
                        put(out, "grantId", grantId);
                        reply(requestId, out);
                    } else {
                        // Keep the durable consume_pending record; syncEntitlements retries it later.
                        JSONObject out = baseResult(false, "pending");
                        put(out, "errorCode", "CONSUME_PENDING");
                        put(out, "message", result == null ? "consume result missing" : safeMessage(result.getMessage()));
                        reply(requestId, out);
                    }
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Myket consume failed; grant remains pending", e);
            JSONObject out = baseResult(false, "pending");
            put(out, "errorCode", "CONSUME_PENDING");
            reply(requestId, out);
        }
    }

    private void handleSyncEntitlements(String requestId) {
        if (!billingReady || billing == null) {
            replyError(requestId, "BILLING_NOT_READY", "اتصال پرداخت مایکت آماده نیست.");
            return;
        }
        List<String> skus = new ArrayList<>(knownProducts);
        Collections.sort(skus);
        try {
            billing.queryInventoryAsync(true, skus, new IabHelper.QueryInventoryFinishedListener() {
                @Override
                public void onQueryInventoryFinished(IabResult result, Inventory inventory) {
                    if (result == null || !result.isSuccess() || inventory == null) {
                        replyError(requestId, "INVENTORY_QUERY_FAILED", result == null ? "unknown" : safeMessage(result.getMessage()));
                        return;
                    }
                    JSONArray owned = new JSONArray();
                    List<Purchase> consumablesToConsume = new ArrayList<>();

                    for (String sku : skus) {
                        Purchase purchase = inventory.getPurchase(sku);
                        if (purchase == null) continue;
                        String type = productTypes.get(sku);
                        if ("non_consumable".equals(type)) {
                            // Match the Myket sample's restore rule: a signed inventory row is
                            // not enough by itself; its original developerPayload must also
                            // match this app's SKU-specific purchase format.
                            String purchaseToken = purchase.getToken();
                            boolean validOwnedPurchase = purchaseToken != null &&
                                    !purchaseToken.trim().isEmpty() &&
                                    isValidDeveloperPayload(sku, purchase.getDeveloperPayload());
                            if (!validOwnedPurchase) {
                                Log.w(TAG, "Ignoring inventory item with invalid payload/token: " + sku);
                                continue;
                            }
                            owned.put(sku);
                            if (sku.startsWith("sr_pack_") || sku.startsWith("sr_offer_")) {
                                String grantId = stableGrantId(purchaseToken);
                                if (!isDelivered(grantId) && !hasPendingGrant(grantId)) {
                                    savePendingGrant(grantId, sku, type, "ready");
                                }
                            }
                        } else if ("consumable".equals(type) &&
                                isValidDeveloperPayload(sku, purchase.getDeveloperPayload()) &&
                                purchase.getToken() != null && !purchase.getToken().trim().isEmpty()) {
                            String grantId = stableGrantId(purchase.getToken());
                            if (!isDelivered(grantId)) {
                                JSONObject existingGrant = getPendingGrant(grantId);
                                if (existingGrant == null) {
                                    savePendingGrant(grantId, sku, type, "consume_pending");
                                    existingGrant = getPendingGrant(grantId);
                                }
                                // A grant already marked ready was consumed successfully; never
                                // downgrade it or consume the same transaction a second time.
                                if (existingGrant != null &&
                                        "consume_pending".equals(existingGrant.optString("status", ""))) {
                                    consumablesToConsume.add(purchase);
                                }
                            }
                        }
                    }

                    // A crash can occur after Myket confirms consume but before the local status
                    // write. The durable consume_pending record plus absence from Myket inventory
                    // is enough to resume delivery without issuing another consume call.
                    JSONObject pendingSnapshot = readPendingGrants();
                    java.util.Iterator<String> pendingKeys = pendingSnapshot.keys();
                    while (pendingKeys.hasNext()) {
                        String grantId = pendingKeys.next();
                        JSONObject record = pendingSnapshot.optJSONObject(grantId);
                        if (record == null || !"consumable".equals(record.optString("productType", "")) ||
                                !"consume_pending".equals(record.optString("status", ""))) continue;
                        String pendingSku = record.optString("productId", "");
                        if (!pendingSku.isEmpty() && inventory.getPurchase(pendingSku) == null) {
                            updateGrantStatus(grantId, "ready");
                        }
                    }

                    consumeInventoryPurchases(consumablesToConsume, 0, () -> {
                        JSONObject out = baseResult(true, "synced");
                        put(out, "ownedNonConsumableProductIds", owned);
                        put(out, "pendingConsumableGrants", pendingGrantArray("consumable"));
                        put(out, "pendingPurchaseGrants", pendingGrantArray("non_consumable"));
                        reply(requestId, out);
                    });
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Inventory query exception", e);
            replyError(requestId, "INVENTORY_QUERY_FAILED", "بازیابی خریدهای مایکت ناموفق بود.");
        }
    }

    private void consumeInventoryPurchases(List<Purchase> purchases, int index, Runnable onComplete) {
        if (index >= purchases.size()) {
            onComplete.run();
            return;
        }
        Purchase purchase = purchases.get(index);
        String grantId = stableGrantId(purchase.getToken());
        String sku = purchase.getSku();
        try {
            billing.consumeAsync(purchase, new IabHelper.OnConsumeFinishedListener() {
                @Override
                public void onConsumeFinished(Purchase consumedPurchase, IabResult result) {
                    if (result != null && result.isSuccess() && consumedPurchase != null &&
                            sku.equals(consumedPurchase.getSku()) &&
                            purchase.getToken() != null && purchase.getToken().equals(consumedPurchase.getToken()) &&
                            purchase.getDeveloperPayload() != null &&
                            purchase.getDeveloperPayload().equals(consumedPurchase.getDeveloperPayload())) {
                        updateGrantStatus(grantId, "ready");
                    }
                    consumeInventoryPurchases(purchases, index + 1, onComplete);
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Retry consume failed for " + sku, e);
            consumeInventoryPurchases(purchases, index + 1, onComplete);
        }
    }

    private void handleAcknowledgeGrant(String requestId, JSONObject payload) {
        String grantId = payload.optString("grantId", "");
        String sku = payload.optString("productId", "");
        if (grantId.isEmpty() || sku.isEmpty()) {
            replyError(requestId, "INVALID_GRANT", "شناسه تحویل معتبر نیست.");
            return;
        }
        if (isDelivered(grantId)) {
            JSONObject out = baseResult(true, "acknowledged");
            reply(requestId, out);
            return;
        }
        JSONObject record = getPendingGrant(grantId);
        if (record == null || !sku.equals(record.optString("productId", "")) ||
                !"ready".equals(record.optString("status", ""))) {
            replyError(requestId, "GRANT_NOT_READY", "پاداش خرید هنوز آماده تحویل نیست.");
            return;
        }
        if (!markGrantDelivered(grantId)) {
            replyError(requestId, "GRANT_ACK_FAILED", "ثبت تأیید تحویل روی دستگاه ناموفق بود.");
            return;
        }
        JSONObject out = baseResult(true, "acknowledged");
        reply(requestId, out);
    }

    private void handleRewardedAd(String requestId, JSONObject payload) {
        String placementId = payload.optString("placementId", "generic-reward");
        if (!placementId.matches("[a-zA-Z0-9_-]{1,40}")) {
            replyError(requestId, "INVALID_PLACEMENT", "جایگاه تبلیغ معتبر نیست.");
            return;
        }
        String zoneId = BuildConfig.TAPSELL_REWARDED_ZONE_ID == null
                ? "" : BuildConfig.TAPSELL_REWARDED_ZONE_ID.trim();
        String appKey = BuildConfig.TAPSELL_APP_KEY == null ? "" : BuildConfig.TAPSELL_APP_KEY.trim();
        if (!tapsellReady || appKey.isEmpty() || zoneId.isEmpty()) {
            JSONObject out = baseResult(false, "unavailable");
            put(out, "errorCode", "NO_FILL");
            put(out, "message", "Tapsell app key / rewarded zone is not configured or not ready.");
            reply(requestId, out);
            return;
        }
        if (adInProgress) {
            replyError(requestId, "AD_BUSY", "تبلیغ دیگری در حال اجراست.");
            return;
        }
        adInProgress = true;
        AtomicBoolean completed = new AtomicBoolean(false);
        Runnable timeout = () -> {
            if (completed.compareAndSet(false, true)) {
                adInProgress = false;
                JSONObject out = baseResult(false, "unavailable");
                put(out, "errorCode", "AD_TIMEOUT");
                reply(requestId, out);
            }
        };
        mainHandler.postDelayed(timeout, AD_TIMEOUT_MS);

        try {
            TapsellPlus.requestRewardedVideoAd(this, zoneId, new AdRequestCallback() {
                @Override
                public void response(TapsellPlusAdModel adModel) {
                    if (completed.get()) return;
                    if (adModel == null || adModel.getResponseId() == null || adModel.getResponseId().trim().isEmpty()) {
                        finishAdFailure(requestId, completed, timeout, "NO_FILL", "unavailable");
                        return;
                    }
                    String responseId = adModel.getResponseId();
                    try {
                        TapsellPlus.showRewardedVideoAd(MainActivity.this, responseId, new AdShowListener() {
                        @Override
                        public void onOpened(TapsellPlusAdModel model) {
                            Log.i(TAG, "Rewarded ad opened for placement " + placementId);
                        }

                        @Override
                        public void onClosed(TapsellPlusAdModel model) {
                            if (completed.compareAndSet(false, true)) {
                                mainHandler.removeCallbacks(timeout);
                                adInProgress = false;
                                JSONObject out = baseResult(false, "cancelled");
                                put(out, "errorCode", "NOT_REWARDED");
                                reply(requestId, out);
                            }
                        }

                        @Override
                        public void onRewarded(TapsellPlusAdModel model) {
                            if (completed.compareAndSet(false, true)) {
                                mainHandler.removeCallbacks(timeout);
                                adInProgress = false;
                                JSONObject out = baseResult(true, "completed");
                                put(out, "rewardEarned", true);
                                reply(requestId, out);
                            }
                        }

                        @Override
                        public void onError(TapsellPlusErrorModel errorModel) {
                            finishAdFailure(requestId, completed, timeout, "AD_SHOW_FAILED", "unavailable");
                            Log.e(TAG, "Rewarded ad show error: " + (errorModel == null ? "unknown" : errorModel.toString()));
                        }
                        });
                    } catch (Exception showError) {
                        Log.e(TAG, "Rewarded ad display exception", showError);
                        finishAdFailure(requestId, completed, timeout, "AD_SHOW_FAILED", "unavailable");
                    }
                }

                @Override
                public void error(String message) {
                    Log.w(TAG, "Rewarded ad request failed: " + safeMessage(message));
                    finishAdFailure(requestId, completed, timeout, "NO_FILL", "unavailable");
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Rewarded ad request exception", e);
            finishAdFailure(requestId, completed, timeout, "AD_SDK_ERROR", "unavailable");
        }
    }

    private void finishAdFailure(String requestId, AtomicBoolean completed, Runnable timeout,
                                 String errorCode, String status) {
        if (!completed.compareAndSet(false, true)) return;
        mainHandler.removeCallbacks(timeout);
        adInProgress = false;
        JSONObject out = baseResult(false, status);
        put(out, "errorCode", errorCode);
        reply(requestId, out);
    }

    private void handleOpenMyketListing(String requestId) {
        String packageName = getPackageName();
        Uri appUri = Uri.parse("myket://details?id=" + Uri.encode(packageName));
        try {
            Intent market = new Intent(Intent.ACTION_VIEW, appUri);
            market.setPackage("ir.mservices.market");
            market.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(market);
            JSONObject out = baseResult(true, "opened");
            put(out, "opened", true);
            reply(requestId, out);
            return;
        } catch (Exception ignored) {
            // Fall through to the HTTPS listing page.
        }
        try {
            Intent web = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://myket.ir/app/" + Uri.encode(packageName)));
            startActivity(web);
            JSONObject out = baseResult(true, "opened");
            put(out, "opened", true);
            reply(requestId, out);
        } catch (Exception e) {
            replyError(requestId, "MYKET_LISTING_UNAVAILABLE", "صفحه بازی در مایکت باز نشد.");
        }
    }

    private JSONObject baseResult(boolean ok, String status) {
        JSONObject out = new JSONObject();
        put(out, "ok", ok);
        put(out, "status", status);
        return out;
    }

    private void replyError(String requestId, String code, String message) {
        JSONObject out = baseResult(false, "failed");
        put(out, "errorCode", code);
        put(out, "message", message);
        reply(requestId, out);
    }

    private void reply(String requestId, JSONObject result) {
        if (requestId == null || requestId.isEmpty() || webView == null) return;
        String js = "window.onSpaceRunnerNativeResult && window.onSpaceRunnerNativeResult(" +
                JSONObject.quote(requestId) + "," + JSONObject.quote(result.toString()) + ");";
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(js, null);
        });
    }

    private void put(JSONObject object, String key, Object value) {
        try { object.put(key, value); }
        catch (JSONException e) { Log.e(TAG, "JSON write failed: " + key, e); }
    }

    private String safeMessage(String value) {
        if (value == null || value.trim().isEmpty()) return "unknown";
        return value.length() > 240 ? value.substring(0, 240) : value;
    }

    private String stableGrantId(String purchaseToken) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(purchaseToken.getBytes(StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder("srgrant_");
            for (int i = 0; i < 12 && i < bytes.length; i++) out.append(String.format("%02x", bytes[i]));
            return out.toString();
        } catch (Exception e) {
            // This is only a stable local id; the signature and token still come from Myket.
            return "srgrant_" + Integer.toHexString(purchaseToken.hashCode()) + Integer.toHexString(purchaseToken.length());
        }
    }

    private android.content.SharedPreferences prefs() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
    }

    private JSONObject readPendingGrants() {
        try { return new JSONObject(prefs().getString(KEY_PENDING_GRANTS, "{}")); }
        catch (Exception e) { return new JSONObject(); }
    }

    private JSONArray readDeliveredGrants() {
        try { return new JSONArray(prefs().getString(KEY_DELIVERED_GRANTS, "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    private boolean isDelivered(String grantId) {
        JSONArray delivered = readDeliveredGrants();
        for (int i = 0; i < delivered.length(); i++) {
            if (grantId.equals(delivered.optString(i))) return true;
        }
        return false;
    }

    private JSONObject getPendingGrant(String grantId) {
        return readPendingGrants().optJSONObject(grantId);
    }

    private boolean hasPendingGrant(String grantId) {
        return getPendingGrant(grantId) != null;
    }

    private boolean savePendingGrant(String grantId, String sku, String type, String status) {
        try {
            JSONObject all = readPendingGrants();
            JSONObject record = all.optJSONObject(grantId);
            if (record != null) {
                if (!sku.equals(record.optString("productId", "")) ||
                        !type.equals(record.optString("productType", ""))) {
                    Log.e(TAG, "Grant id collision or product mismatch: " + grantId);
                    return false;
                }
                // Monotonic state: a ready grant must never be downgraded to consume_pending.
                if ("ready".equals(record.optString("status", ""))) return true;
            } else {
                record = new JSONObject();
            }
            record.put("grantId", grantId);
            record.put("productId", sku);
            record.put("productType", type);
            record.put("status", status);
            all.put(grantId, record);
            return prefs().edit().putString(KEY_PENDING_GRANTS, all.toString()).commit();
        } catch (Exception e) {
            Log.e(TAG, "Could not persist pending grant", e);
            return false;
        }
    }

    private boolean updateGrantStatus(String grantId, String status) {
        try {
            JSONObject all = readPendingGrants();
            JSONObject record = all.optJSONObject(grantId);
            if (record == null) return false;
            record.put("status", status);
            all.put(grantId, record);
            return prefs().edit().putString(KEY_PENDING_GRANTS, all.toString()).commit();
        } catch (Exception e) {
            Log.e(TAG, "Could not update grant status", e);
            return false;
        }
    }

    private JSONArray pendingGrantArray(String type) {
        JSONArray out = new JSONArray();
        JSONObject all = readPendingGrants();
        java.util.Iterator<String> keys = all.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            JSONObject record = all.optJSONObject(key);
            if (record == null || !"ready".equals(record.optString("status", ""))) continue;
            if (!type.equals(record.optString("productType", ""))) continue;
            JSONObject item = new JSONObject();
            put(item, "grantId", record.optString("grantId", key));
            put(item, "productId", record.optString("productId", ""));
            out.put(item);
        }
        return out;
    }

    private boolean markGrantDelivered(String grantId) {
        try {
            JSONObject pending = readPendingGrants();
            if (pending.optJSONObject(grantId) == null) return isDelivered(grantId);
            pending.remove(grantId);
            JSONArray delivered = readDeliveredGrants();
            boolean exists = false;
            for (int i = 0; i < delivered.length(); i++) {
                if (grantId.equals(delivered.optString(i))) { exists = true; break; }
            }
            if (!exists) delivered.put(grantId);
            // A bounded local ledger keeps the preferences compact.
            JSONArray bounded = new JSONArray();
            int start = Math.max(0, delivered.length() - 1000);
            for (int i = start; i < delivered.length(); i++) bounded.put(delivered.optString(i));
            return prefs().edit()
                    .putString(KEY_PENDING_GRANTS, pending.toString())
                    .putString(KEY_DELIVERED_GRANTS, bounded.toString())
                    .commit();
        } catch (Exception e) {
            Log.e(TAG, "Could not acknowledge grant", e);
            return false;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("SpaceRunnerNative");
            webView.stopLoading();
            webView.loadUrl("about:blank");
            webView.destroy();
            webView = null;
        }
        if (billing != null) {
            try { billing.dispose(); }
            catch (Exception e) { Log.w(TAG, "Billing dispose failed", e); }
            billing = null;
        }
        mainHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
