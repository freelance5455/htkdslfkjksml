package online.digitaldostcenter.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import online.digitaldostcenter.app.ui.navigation.AdminScreen
import online.digitaldostcenter.app.ui.screens.AdminDashboardScreen
import online.digitaldostcenter.app.ui.screens.AdminLoginScreen
import online.digitaldostcenter.app.ui.theme.DigitalDostCentreTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            DigitalDostCentreTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()

                    NavHost(
                        navController = navController,
                        startDestination = AdminScreen.Login.route
                    ) {
                        // 1. Professional Admin Login Screen
                        composable(AdminScreen.Login.route) {
                            AdminLoginScreen(
                                onLoginSuccess = { _ ->
                                    navController.navigate(AdminScreen.Dashboard.route) {
                                        popUpTo(AdminScreen.Login.route) { inclusive = true }
                                    }
                                }
                            )
                        }

                        // 2. Authenticated Admin Dashboard (digitaldostcenter.online/admin-login -> admin.html)
                        composable(AdminScreen.Dashboard.route) {
                            AdminDashboardScreen(
                                onLogout = {
                                    navController.navigate(AdminScreen.Login.route) {
                                        popUpTo(AdminScreen.Dashboard.route) { inclusive = true }
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
