package online.digitaldostcenter.app.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Blue Palette
val DdcBluePrimary = Color(0xFF1565C0)
val DdcBlueDark = Color(0xFF0D47A1)
val DdcBlueLight = Color(0xFF1E88E5)
val DdcCyanAccent = Color(0xFF0284C7)

// Neutral Light
val DdcSurfaceLight = Color(0xFFF8FAFC)
val DdcCardLight = Color(0xFFFFFFFF)
val DdcBorderLight = Color(0xFFE2E8F0)
val DdcTextPrimaryLight = Color(0xFF0F172A)
val DdcTextSecondaryLight = Color(0xFF475569)

// Neutral Dark
val DdcSurfaceDark = Color(0xFF0F172A)
val DdcCardDark = Color(0xFF1E293B)
val DdcBorderDark = Color(0xFF334155)
val DdcTextPrimaryDark = Color(0xFFF8FAFC)
val DdcTextSecondaryDark = Color(0xFF94A3B8)

// Status colors
val DdcVerifiedGreen = Color(0xFF059669)
val DdcAlertOrange = Color(0xFFEA580C)
