package app.yooyyaa;

import android.content.Context;
import java.io.ByteArrayOutputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/** Serves bundled pages on 127.0.0.1 so camera and mic stay in a secure context. */
public class LocalServer {
    private final Context context;
    private ServerSocket socket;
    private volatile boolean running;

    LocalServer(Context context) {
        this.context = context.getApplicationContext();
    }

    int start() {
        try {
            socket = new ServerSocket(0, 8, InetAddress.getByName("127.0.0.1"));
            running = true;
            Thread thread = new Thread(this::loop, "yooyyaa-http");
            thread.setDaemon(true);
            thread.start();
            return socket.getLocalPort();
        } catch (Exception err) {
            throw new RuntimeException(err);
        }
    }

    void stop() {
        running = false;
        try {
            if (socket != null) socket.close();
        } catch (Exception ignored) {
        }
    }

    private void loop() {
        while (running) {
            try {
                Socket client = socket.accept();
                Thread worker = new Thread(() -> handle(client), "yooyyaa-conn");
                worker.setDaemon(true);
                worker.start();
            } catch (Exception err) {
                if (running) continue;
                return;
            }
        }
    }

    private void handle(Socket client) {
        try {
            client.setSoTimeout(4000);
            BufferedReader reader = new BufferedReader(new InputStreamReader(client.getInputStream(), StandardCharsets.UTF_8));
            String line = reader.readLine();
            if (line == null || !line.startsWith("GET ")) {
                writeStatus(client, 405, "text/plain", "no");
                return;
            }
            String path = line.split(" ")[1];
            int q = path.indexOf('?');
            if (q >= 0) path = path.substring(0, q);
            if (path.contains("..") || path.contains("\\") || !path.startsWith("/")) {
                writeStatus(client, 403, "text/plain", "no");
                return;
            }
            String asset = "/".equals(path) ? "www/index.html" : "www" + path;
            InputStream in;
            try {
                in = context.getAssets().open(asset);
            } catch (Exception missing) {
                writeStatus(client, 404, "text/plain", "missing");
                return;
            }
            byte[] body = readAll(in);
            in.close();
            String type = typeFor(asset);
            OutputStream out = client.getOutputStream();
            String head = "HTTP/1.1 200 OK\r\nContent-Type: " + type
                    + "\r\nContent-Length: " + body.length
                    + "\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n";
            out.write(head.getBytes(StandardCharsets.US_ASCII));
            out.write(body);
            out.flush();
        } catch (Exception ignored) {
        } finally {
            try {
                client.close();
            } catch (Exception ignored) {
            }
        }
    }

    private static byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        byte[] chunk = new byte[8192];
        int n;
        while ((n = in.read(chunk)) >= 0) buf.write(chunk, 0, n);
        return buf.toByteArray();
    }

    private static void writeStatus(Socket client, int code, String type, String body) throws Exception {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        String head = "HTTP/1.1 " + code + " X\r\nContent-Type: " + type
                + "\r\nContent-Length: " + bytes.length + "\r\nConnection: close\r\n\r\n";
        OutputStream out = client.getOutputStream();
        out.write(head.getBytes(StandardCharsets.US_ASCII));
        out.write(bytes);
        out.flush();
    }

    private static String typeFor(String path) {
        Map<String, String> types = new HashMap<>();
        types.put(".html", "text/html; charset=utf-8");
        types.put(".js", "text/javascript; charset=utf-8");
        types.put(".css", "text/css; charset=utf-8");
        types.put(".svg", "image/svg+xml");
        types.put(".png", "image/png");
        types.put(".json", "application/json");
        int dot = path.lastIndexOf('.');
        if (dot < 0) return "application/octet-stream";
        return types.getOrDefault(path.substring(dot), "application/octet-stream");
    }
}
