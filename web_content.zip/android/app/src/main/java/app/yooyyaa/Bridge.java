package app.yooyyaa;

import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.json.JSONObject;

/** Operator password is checked here, not in the page. Five misses lock for ten minutes. */
public class Bridge {
    private static final String EXPECTED = "5a0fa0761f8a636d285c7c517054f098427da9ef031a72158bfb102583208905";
    private static final int MAX_FAILS = 5;
    private static final long LOCK_MS = 10 * 60 * 1000L;
    private static final long SESSION_MS = 60 * 60 * 1000L;

    private final MainActivity activity;
    private final Map<String, Long> sessions = new ConcurrentHashMap<>();
    private int fails;
    private long lockedUntil;

    Bridge(MainActivity activity) {
        this.activity = activity;
    }

    @JavascriptInterface
    public synchronized String adminLogin(String password) {
        try {
            long now = System.currentTimeMillis();
            JSONObject out = new JSONObject();
            if (now < lockedUntil) {
                out.put("ok", false);
                out.put("lockedForMs", lockedUntil - now);
                out.put("attemptsLeft", 0);
                return out.toString();
            }
            if (password == null || !EXPECTED.equals(sha(password))) {
                fails += 1;
                if (fails >= MAX_FAILS) {
                    lockedUntil = now + LOCK_MS;
                    fails = 0;
                    out.put("ok", false);
                    out.put("lockedForMs", LOCK_MS);
                    out.put("attemptsLeft", 0);
                    return out.toString();
                }
                out.put("ok", false);
                out.put("lockedForMs", 0);
                out.put("attemptsLeft", MAX_FAILS - fails);
                return out.toString();
            }
            fails = 0;
            lockedUntil = 0;
            byte[] rnd = new byte[32];
            new java.security.SecureRandom().nextBytes(rnd);
            String token = hex(rnd);
            long exp = now + SESSION_MS;
            sessions.put(token, exp);
            out.put("ok", true);
            out.put("token", token);
            out.put("expiresAt", exp);
            return out.toString();
        } catch (Exception err) {
            return "{\"ok\":false,\"lockedForMs\":0,\"attemptsLeft\":0}";
        }
    }

    @JavascriptInterface
    public synchronized String adminCheck(String token) {
        try {
            Long exp = token == null ? null : sessions.get(token);
            JSONObject out = new JSONObject();
            if (exp == null || exp < System.currentTimeMillis()) {
                if (token != null) sessions.remove(token);
                out.put("ok", false);
                return out.toString();
            }
            out.put("ok", true);
            out.put("expiresAt", exp);
            return out.toString();
        } catch (Exception err) {
            return "{\"ok\":false}";
        }
    }

    @JavascriptInterface
    public void shareApp() {
        activity.runOnUiThread(() -> {
            Uri uri = Uri.parse("content://app.yooyyaa.apk/YOOYYAA.apk");
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("application/vnd.android.package-archive");
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.setClipData(ClipData.newRawUri("YOOYYAA.apk", uri));
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent chooser = Intent.createChooser(send, "YOOYYAA");
            chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            activity.startActivity(chooser);
        });
    }

    @JavascriptInterface
    public void shareText(String text) {
        activity.runOnUiThread(() -> {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_TEXT, text == null ? "YOOYYAA" : text);
            activity.startActivity(Intent.createChooser(send, "YOOYYAA"));
        });
    }

    private static String sha(String password) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        digest.update("yooyyaa-admin-v1|".getBytes(StandardCharsets.UTF_8));
        digest.update(password.getBytes(StandardCharsets.UTF_8));
        return hex(digest.digest());
    }

    private static String hex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) sb.append(String.format("%02x", b));
        return sb.toString();
    }
}
