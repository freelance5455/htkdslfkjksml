package app.tradyar.utils;

/**
 * Exception thrown when an async operation is already in progress.
 */
public class IabAsyncInProgressException extends Exception {
    public IabAsyncInProgressException() {
        super("Another async operation is in progress.");
    }

    public IabAsyncInProgressException(String message) {
        super(message);
    }
}
