package app.tradyar;

import android.app.Activity;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import app.tradyar.utils.IabHelper;
import app.tradyar.utils.IabResult;
import app.tradyar.utils.Inventory;
import app.tradyar.utils.Purchase;

/**
 * MyketBridge.java - JavaScript Bridge for Myket in-app billing.
 *
 * CRITICAL FIX: JavaScript functions passed as callbacks are NOT converted to Strings
 * automatically by WebView. We use a callback ID system instead:
 *   JS side generates a unique ID, registers a function in window.__myketCallbacks[id]
 *   Then calls bridge.launchPurchaseFlow(sku, type, payload, callbackId)
 *   Java side calls back via webView.evaluateJavascript("window.__myketCallbacks['id'](...)")
 */
public class MyketBridge {
    private static final String TAG = "MyketBridge";

    private static final String BASE_64_PUBLIC_KEY =
        "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCVUpho/fKrXcukvRis33DNoUbSxHL7qlM9uWm70BSAcZYIV9xHT2mdI60xWo7KsN7qWbDlcyAwdHT4pOF4sqsaYfNLsCS5thsVHLI/JGMBdhah8drN+M586pPF8CsStpH9EKwvb4ZIVRvl9ViEXOpSU9y5lsHv67SxuO2W9h2EHwIDAQAB";

    private final Activity activity;
    private final WebView webView;

    private IabHelper mHelper;
    private boolean isSetup = false;
    private final Object setupLock = new Object();
    private boolean setupFailed = false;

    private final Map<String, Purchase> pendingPurchases = new HashMap<>();
    private final Map<String, String> activePurchases = new HashMap<>(); // callbackId -> sku

    public static final int RC_REQUEST = 10001;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public MyketBridge(Activity activity, WebView webView) {
        this.activity = activity;
        this.webView = webView;
    }

    /**
     * Step 1: startSetup - Connect to Myket billing service
     */
    @JavascriptInterface
    public void startSetup(final String publicKey) {
        Log.d(TAG, "startSetup() called");

        String key = BASE_64_PUBLIC_KEY;
        if (publicKey != null && publicKey.length() > 100) {
            key = publicKey;
        }

        try {
            mHelper = new IabHelper(activity, key);
            mHelper.enableDebugLogging(true);

            mHelper.startSetup(new IabHelper.OnIabSetupFinishedListener() {
                @Override
                public void onIabSetupFinished(IabResult result) {
                    Log.d(TAG, "Setup finished: " + result);

                    if (result == null || !result.isSuccess()) {
                        Log.e(TAG, "Problem setting up billing: " + result);
                        setupFailed = true;
                        synchronized (setupLock) { setupLock.notifyAll(); }
                        callJavaScript("myketOnSetupFinished",
                            "{\"success\":false,\"message\":\"" + escapeJson(result != null ? result.getMessage() : "unknown") + "\"}");
                        return;
                    }

                    isSetup = true;
                    setupFailed = false;
                    synchronized (setupLock) { setupLock.notifyAll(); }
                    Log.d(TAG, "Setup successful. Querying inventory.");
                    callJavaScript("myketOnSetupFinished", "{\"success\":true}");
                    queryInventoryOnStartup();
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Error in startSetup", e);
            setupFailed = true;
            synchronized (setupLock) { setupLock.notifyAll(); }
            callJavaScript("myketOnSetupFinished",
                "{\"success\":false,\"message\":\"" + escapeJson(e.getMessage()) + "\"}");
        }
    }

    @JavascriptInterface
    public boolean isSetup() {
        return isSetup && mHelper != null;
    }

    /**
     * Wait for setup synchronously (called from a background thread)
     */
    private boolean waitForSetup(long timeoutMs) {
        long start = System.currentTimeMillis();
        while (!isSetup && !setupFailed && mHelper != null) {
            long elapsed = System.currentTimeMillis() - start;
            if (elapsed >= timeoutMs) return false;
            try {
                synchronized (setupLock) {
                    setupLock.wait(Math.max(50, timeoutMs - elapsed));
                }
            } catch (InterruptedException e) { return false; }
        }
        return isSetup;
    }

    /**
     * Step 2: queryInventoryOnStartup - Check for unconsumed purchases
     */
    private void queryInventoryOnStartup() {
        if (mHelper == null || !isSetup) return;

        List<String> itemSkus = new ArrayList<>();
        itemSkus.add("tradyar_coins_p1");
        itemSkus.add("tradyar_coins_p2");
        itemSkus.add("tradyar_coins_p3");
        itemSkus.add("tradyar_sub_sh1");
        itemSkus.add("tradyar_sub_sh2");
        itemSkus.add("tradyar_sub_sh3");
        itemSkus.add("tradyar_sub_sh4");
        itemSkus.add("tradyar_sub_sh5");
        itemSkus.add("tradyar_sub_s1");
        itemSkus.add("tradyar_sub_s2");
        itemSkus.add("tradyar_sub_s3");

        List<String> subSkus = new ArrayList<>();

        try {
            mHelper.queryInventoryAsync(true, itemSkus, subSkus, mGotInventoryListener);
        } catch (Exception e) {
            Log.e(TAG, "Error querying inventory", e);
        }
    }

    /**
     * Query inventory - JS side passes callbackId (String), not a function
     */
    @JavascriptInterface
    public void queryInventoryAsync(boolean querySkuDetails, String itemSkusJson, String subSkusJson, final String callbackId) {
        Log.d(TAG, "queryInventoryAsync called, callbackId=" + callbackId);

        if (mHelper == null || !isSetup) {
            invokeCallback(callbackId, "null");
            return;
        }

        try {
            final List<String> itemSkus = parseSkus(itemSkusJson);
            final List<String> subSkus = parseSkus(subSkusJson);

            mHelper.queryInventoryAsync(querySkuDetails, itemSkus, subSkus,
                new IabHelper.QueryInventoryFinishedListener() {
                    @Override
                    public void onQueryInventoryFinished(IabResult result, Inventory inventory) {
                        if (mHelper == null) {
                            invokeCallback(callbackId, "{\"success\":false,\"error\":\"disposed\"}");
                            return;
                        }

                        if (result == null || result.isFailure()) {
                            invokeCallback(callbackId,
                                "{\"success\":false,\"message\":\"" + escapeJson(result != null ? result.getMessage() : "unknown") + "\"}");
                            return;
                        }

                        try {
                            JSONObject json = new JSONObject();
                            json.put("success", true);

                            JSONArray purchasesArray = new JSONArray();
                            if (inventory != null) {
                                List<Purchase> purchases = inventory.getAllPurchases();
                                if (purchases != null) {
                                    for (Purchase purchase : purchases) {
                                        JSONObject p = new JSONObject();
                                        p.put("sku", purchase.getSku());
                                        p.put("token", purchase.getToken());
                                        p.put("orderId", purchase.getOrderId());
                                        p.put("purchaseTime", purchase.getPurchaseTime());
                                        p.put("purchaseState", purchase.getPurchaseState());
                                        p.put("developerPayload", purchase.getDeveloperPayload());
                                        p.put("originalJson", purchase.getOriginalJson());
                                        p.put("signature", purchase.getSignature());
                                        purchasesArray.put(p);
                                    }
                                }
                            }
                            json.put("purchases", purchasesArray);
                            json.put("purchase", purchasesArray); // backward-compat alias

                            invokeCallback(callbackId, json.toString());
                        } catch (Exception e) {
                            Log.e(TAG, "Error building inventory JSON", e);
                            invokeCallback(callbackId,
                                "{\"success\":false,\"message\":\"" + escapeJson(e.getMessage()) + "\"}");
                        }
                    }
                });
        } catch (Exception e) {
            Log.e(TAG, "Error in queryInventoryAsync", e);
            invokeCallback(callbackId,
                "{\"success\":false,\"message\":\"" + escapeJson(e.getMessage()) + "\"}");
        }
    }

    /**
     * Step 3: launchPurchaseFlow - Open the Myket payment dialog
     * JS passes: sku, itemType, developerPayload, callbackId (String, not function)
     */
    @JavascriptInterface
    public void launchPurchaseFlow(final String sku, String itemType, final String developerPayload, final String callbackId) {
        Log.d(TAG, "launchPurchaseFlow: sku=" + sku + " callbackId=" + callbackId);

        if (mHelper == null || !isSetup) {
            // Try to setup on-the-fly if not ready yet
            Log.w(TAG, "Not setup yet, attempting to start setup...");
            if (mHelper == null) {
                startSetup(BASE_64_PUBLIC_KEY);
            }
            // Wait up to 3 seconds for setup
            new Thread(new Runnable() {
                @Override
                public void run() {
                    boolean ready = waitForSetup(3000);
                    if (ready) {
                        doLaunchPurchaseFlow(sku, developerPayload, callbackId);
                    } else {
                        Log.e(TAG, "Setup timed out, cannot launch purchase flow");
                        invokeCallback(callbackId,
                            "{\"success\":false,\"error\":\"setup_timeout\",\"message\":\"Myket billing setup timed out\"}");
                    }
                }
            }).start();
            return;
        }

        doLaunchPurchaseFlow(sku, developerPayload, callbackId);
    }

    private void doLaunchPurchaseFlow(final String sku, final String developerPayload, final String callbackId) {
        if (mHelper == null || !isSetup) {
            invokeCallback(callbackId, "{\"success\":false,\"error\":\"not_setup\"}");
            return;
        }

        // Detect subs vs inapp based on SKU prefix
        String type = IabHelper.ITEM_TYPE_INAPP;
        if (sku != null && sku.startsWith("tradyar_sub_")) {
            type = IabHelper.ITEM_TYPE_SUBS;
        }

        try {
            mHelper.setRequestCode(RC_REQUEST);

            // Track this active purchase
            activePurchases.put(callbackId, sku);

            mHelper.launchPurchaseFlow(activity, sku, type, RC_REQUEST,
                    new IabHelper.OnIabPurchaseFinishedListener() {
                        @Override
                        public void onIabPurchaseFinished(IabResult result, Purchase purchase) {
                            Log.d(TAG, "Purchase finished: " + result + " for " + sku);
                            activePurchases.remove(callbackId);

                            if (mHelper == null) {
                                invokeCallback(callbackId, "{\"success\":false,\"error\":\"disposed\"}");
                                return;
                            }

                            if (result == null || result.isFailure()) {
                                boolean cancelled = (result != null && result.getResponse() == IabHelper.BILLING_RESPONSE_RESULT_USER_CANCELED);
                                String errorKey = cancelled ? "cancelled" : "purchase_failed";
                                String json = "{\"success\":false,\"error\":\"" + errorKey +
                                    "\",\"cancelled\":" + cancelled +
                                    ",\"message\":\"" + escapeJson(result != null ? result.getMessage() : "unknown") + "\"}";
                                invokeCallback(callbackId, json);
                                return;
                            }

                            // Store purchase for later consume
                            if (purchase != null) {
                                String token = purchase.getToken();
                                if (token != null) {
                                    pendingPurchases.put(token, purchase);
                                    Log.d(TAG, "Purchase stored for consume. Token: " + token);
                                }
                            }

                            try {
                                JSONObject json = new JSONObject();
                                json.put("success", true);
                                json.put("isSuccess", true);

                                if (purchase != null) {
                                    JSONObject purchaseJson = new JSONObject();
                                    purchaseJson.put("sku", purchase.getSku());
                                    purchaseJson.put("token", purchase.getToken());
                                    purchaseJson.put("orderId", purchase.getOrderId());
                                    purchaseJson.put("itemType", purchase.getItemType());
                                    purchaseJson.put("purchaseTime", purchase.getPurchaseTime());
                                    purchaseJson.put("purchaseState", purchase.getPurchaseState());
                                    purchaseJson.put("developerPayload", purchase.getDeveloperPayload());
                                    purchaseJson.put("originalJson", purchase.getOriginalJson());
                                    purchaseJson.put("signature", purchase.getSignature());
                                    json.put("purchase", purchaseJson);

                                    // Also flat-copy common keys for backward compat
                                    json.put("token", purchase.getToken());
                                    json.put("purchaseToken", purchase.getToken());
                                    json.put("mToken", purchase.getToken());
                                    json.put("orderId", purchase.getOrderId());
                                    json.put("mOrderId", purchase.getOrderId());
                                    json.put("mSku", purchase.getSku());
                                }

                                invokeCallback(callbackId, json.toString());
                            } catch (Exception e) {
                                Log.e(TAG, "Error building purchase JSON", e);
                                invokeCallback(callbackId, "{\"success\":true,\"purchase\":{\"token\":\"\"}}");
                            }
                        }
                    }, developerPayload);
        } catch (Exception e) {
            Log.e(TAG, "Error in launchPurchaseFlow", e);
            activePurchases.remove(callbackId);
            invokeCallback(callbackId,
                "{\"success\":false,\"error\":\"" + escapeJson(e.getMessage()) + "\"}");
        }
    }

    /**
     * Step 4: consumeAsync - Consume a consumable purchase
     * JS passes: token (or JSON string), callbackId (String)
     */
    @JavascriptInterface
    public void consumeAsync(String tokenOrPurchase, final String callbackId) {
        Log.d(TAG, "consumeAsync: " + tokenOrPurchase + " callbackId=" + callbackId);

        if (mHelper == null || !isSetup) {
            invokeCallback(callbackId, "{\"success\":false,\"error\":\"not_setup\"}");
            return;
        }

        // tokenOrPurchase can be just a token string OR a JSON-stringified purchase object
        String token = tokenOrPurchase;
        if (tokenOrPurchase != null && tokenOrPurchase.trim().startsWith("{")) {
            try {
                JSONObject obj = new JSONObject(tokenOrPurchase);
                token = obj.optString("token", "");
                if (token.isEmpty()) token = obj.optString("purchaseToken", "");
                if (token.isEmpty()) token = obj.optString("mToken", "");
            } catch (Exception e) {
                Log.e(TAG, "Error parsing purchase JSON", e);
            }
        }

        if (token == null || token.isEmpty()) {
            invokeCallback(callbackId, "{\"success\":false,\"error\":\"invalid_token\"}");
            return;
        }

        Purchase purchase = pendingPurchases.get(token);
        if (purchase == null) {
            Log.w(TAG, "Purchase not found in pending map for token: " + token);
            // Create a synthetic purchase object — sometimes Myket returns the purchase
            // but we lost track of it. Try to consume by token only.
            try {
                purchase = new Purchase(IabHelper.ITEM_TYPE_INAPP, "{\"productId\":\"\",\"purchaseToken\":\"" + token + "\"}", "");
            } catch (Exception e) {
                Log.e(TAG, "Could not create synthetic purchase", e);
                invokeCallback(callbackId, "{\"success\":false,\"error\":\"purchase_not_found\"}");
                return;
            }
        }

        try {
            mHelper.consumeAsync(purchase, new IabHelper.OnConsumeFinishedListener() {
                @Override
                public void onConsumeFinished(Purchase purchase, IabResult result) {
                    Log.d(TAG, "Consumption finished: " + result);

                    if (mHelper == null) {
                        invokeCallback(callbackId, "{\"success\":false,\"error\":\"disposed\"}");
                        return;
                    }

                    if (result != null && result.isSuccess()) {
                        invokeCallback(callbackId, "{\"success\":true,\"isSuccess\":true}");
                        if (purchase != null && purchase.getToken() != null) {
                            pendingPurchases.remove(purchase.getToken());
                        }
                    } else {
                        invokeCallback(callbackId,
                            "{\"success\":false,\"message\":\"" + escapeJson(result != null ? result.getMessage() : "unknown") + "\"}");
                    }
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Error in consumeAsync", e);
            invokeCallback(callbackId,
                "{\"success\":false,\"error\":\"" + escapeJson(e.getMessage()) + "\"}");
        }
    }

    /**
     * Generate a unique callback ID (used by JS side via a different pattern)
     */
    @JavascriptInterface
    public String generateCallbackId() {
        return "cb_" + System.currentTimeMillis() + "_" + UUID.randomUUID().toString().substring(0, 8);
    }

    private IabHelper.QueryInventoryFinishedListener mGotInventoryListener =
        new IabHelper.QueryInventoryFinishedListener() {
            @Override
            public void onQueryInventoryFinished(IabResult result, Inventory inventory) {
                if (mHelper == null) return;

                if (result == null || result.isFailure()) {
                    callJavaScript("myketOnQueryInventoryFinished", "{\"success\":false}");
                    return;
                }

                Log.d(TAG, "Initial inventory query successful");

                try {
                    JSONObject json = new JSONObject();
                    json.put("success", true);

                    JSONArray purchasesArray = new JSONArray();
                    if (inventory != null) {
                        List<Purchase> purchases = inventory.getAllPurchases();
                        if (purchases != null) {
                            for (Purchase purchase : purchases) {
                                JSONObject p = new JSONObject();
                                p.put("sku", purchase.getSku());
                                p.put("token", purchase.getToken());
                                p.put("orderId", purchase.getOrderId());
                                p.put("purchaseTime", purchase.getPurchaseTime());
                                p.put("purchaseState", purchase.getPurchaseState());
                                p.put("developerPayload", purchase.getDeveloperPayload());
                                p.put("originalJson", purchase.getOriginalJson());
                                p.put("signature", purchase.getSignature());
                                purchasesArray.put(p);
                            }
                        }
                    }
                    json.put("purchases", purchasesArray);

                    callJavaScript("myketOnQueryInventoryFinished", json.toString());
                } catch (Exception e) {
                    Log.e(TAG, "Error building inventory JSON", e);
                }
            }
        };

    private List<String> parseSkus(String json) {
        List<String> skus = new ArrayList<>();
        if (json == null || json.isEmpty()) return skus;
        try {
            if (json.trim().startsWith("[")) {
                JSONArray array = new JSONArray(json);
                for (int i = 0; i < array.length(); i++) {
                    skus.add(array.getString(i));
                }
            } else {
                String[] parts = json.split(",");
                for (String part : parts) {
                    String trimmed = part.trim().replace("\"", "");
                    if (!trimmed.isEmpty()) {
                        skus.add(trimmed);
                    }
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error parsing skus: " + json, e);
        }
        return skus;
    }

    private String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
               .replace("\"", "\\\"")
               .replace("\n", "\\n")
               .replace("\r", "\\r")
               .replace("\t", "\\t");
    }

    /**
     * Invoke a JS callback by ID.
     * Calls window.__invokeMyketCallback(callbackId, data)
     */
    private void invokeCallback(final String callbackId, final String data) {
        if (callbackId == null || callbackId.isEmpty()) {
            Log.w(TAG, "invokeCallback called with empty callbackId");
            return;
        }
        // Build a safe JS call: window.__invokeMyketCallback("callbackId", <data>)
        // data is already a JSON string (object/null/array)
        String safeData = (data == null || data.equals("null")) ? "null" : data;
        final String js = "javascript:if(window.__invokeMyketCallback){window.__invokeMyketCallback(\"" +
                          escapeJson(callbackId) + "\"," + safeData + ");}";
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    Log.d(TAG, "invokeCallback: " + js.substring(0, Math.min(js.length(), 200)));
                    webView.evaluateJavascript(js, null);
                } catch (Exception e) {
                    Log.e(TAG, "Error in invokeCallback", e);
                }
            }
        });
    }

    private void callJavaScript(final String functionName, final String data) {
        if (activity == null || webView == null) return;

        final String safeData = (data == null || data.equals("null")) ? "null" : data;
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    String js = "javascript:if(window." + functionName + "){window." +
                               functionName + "(" + safeData + ");}";
                    Log.d(TAG, "Calling JS: " + js.substring(0, Math.min(js.length(), 200)));
                    webView.evaluateJavascript(js, null);
                } catch (Exception e) {
                    Log.e(TAG, "Error calling JavaScript", e);
                }
            }
        });
    }

    public boolean handleActivityResult(int requestCode, int resultCode, Intent data) {
        if (mHelper == null) return false;
        return mHelper.handleActivityResult(requestCode, resultCode, data);
    }

    public void onDestroy() {
        Log.d(TAG, "Destroying helper.");
        if (mHelper != null) {
            try {
                mHelper.disposeWhenFinished();
            } catch (Exception e) {
                Log.e(TAG, "Error disposing helper", e);
            }
            mHelper = null;
        }
        isSetup = false;
        pendingPurchases.clear();
        activePurchases.clear();
    }
}
