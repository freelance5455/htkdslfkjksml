package app.pacex.tracker;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.IBinder;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONObject;

/** Long-lived native listener for Android TYPE_STEP_COUNTER. No JavaScript pedometer is used. */
public class PaceXStepService extends Service implements SensorEventListener {
    static final String ACTION_START = "app.pacex.tracker.steps.START";
    static final String ACTION_STOP = "app.pacex.tracker.steps.STOP";
    static final String ACTION_STEP = "app.pacex.tracker.STEP";
    private static final String CHANNEL = "pace_x_steps";
    private static final int NOTIFICATION_ID = 4102;
    private SensorManager sensors;
    private Sensor sensor;
    private StepDataStore store;

    static boolean available(Context context) {
        SensorManager manager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        return manager != null && manager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) != null;
    }
    static void start(Context context) { ContextCompat.startForegroundService(context, new Intent(context, PaceXStepService.class).setAction(ACTION_START)); }
    static void stop(Context context) { context.startService(new Intent(context, PaceXStepService.class).setAction(ACTION_STOP)); }

    @Override public void onCreate() {
        super.onCreate(); store = new StepDataStore(this); sensors = (SensorManager) getSystemService(SENSOR_SERVICE); sensor = sensors.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
    }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) { store.setEnabled(false); unregister(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY; }
        if (sensor == null) { stopSelf(); return START_NOT_STICKY; }
        store.setEnabled(true); enterForeground(); sensors.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL); broadcast(store.current());
        return START_STICKY;
    }
    @Override public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() != Sensor.TYPE_STEP_COUNTER || event.values.length == 0) return;
        broadcast(store.acceptSensorValue(event.values[0]));
    }
    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }
    private void unregister() { try { sensors.unregisterListener(this); } catch (Exception ignored) { } }
    private void broadcast(JSONObject state) { Intent i = new Intent(ACTION_STEP).setPackage(getPackageName()); i.putExtra("json", state.toString()); sendBroadcast(i); }
    private void enterForeground() {
        NotificationManager manager=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O)manager.createNotificationChannel(new NotificationChannel(CHANNEL,"Daily step counting",NotificationManager.IMPORTANCE_MIN));
        Intent open=new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pending=PendingIntent.getActivity(this,101,open,PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));
        Notification n=new NotificationCompat.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_menu_compass).setContentTitle("PACE X is counting steps").setContentText("Native step counter is active").setContentIntent(pending).setOngoing(true).setOnlyAlertOnce(true).setCategory(NotificationCompat.CATEGORY_SERVICE).build();
        // The health foreground-service type is enforced on Android 14+. Older Android releases use a normal foreground service.
        if(Build.VERSION.SDK_INT>=34)startForeground(NOTIFICATION_ID,n,android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_HEALTH);else startForeground(NOTIFICATION_ID,n);
    }
    @Nullable @Override public IBinder onBind(Intent intent) { return null; }
    @Override public void onDestroy() { unregister(); super.onDestroy(); }
}
