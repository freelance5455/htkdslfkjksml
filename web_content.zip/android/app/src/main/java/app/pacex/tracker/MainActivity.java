package app.pacex.tracker;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

/** Entry activity. The native plugin supplies background-safe GPS and step sensor functions. */
public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        registerPlugin(PaceXNativePlugin.class);
    }
}
