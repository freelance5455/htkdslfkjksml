package app.pacex.tracker;

import android.content.Context;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

/**
 * Converts TYPE_STEP_COUNTER's reboot-relative cumulative number into private daily totals.
 * A lower counter value is a reboot/new sensor baseline, not a source of fabricated steps.
 */
final class StepDataStore {
    private static final String DIR = "pace-x-data";
    private static final String FILE = "daily-steps.json";
    private static final String ENABLED_FILE = "step-service-enabled.json";
    private final Context context;

    StepDataStore(Context context) { this.context = context.getApplicationContext(); }

    synchronized JSONObject current() {
        JSONObject state = read();
        try {
            if (!state.has("version")) state.put("version", 1);
            if (!state.has("totalSteps")) state.put("totalSteps", 0);
            if (!state.has("days")) state.put("days", new JSONObject());
        } catch (Exception ignored) { }
        return state;
    }

    synchronized JSONObject acceptSensorValue(float sensorValue) {
        JSONObject state = current();
        String today = TimeUtil.dayKey();
        try {
            double previous = state.optDouble("sensorLastValue", -1);
            // First ever reading / a device reboot: set a baseline, deliberately add nothing.
            if (previous < 0 || sensorValue < previous) {
                state.put("sensorLastValue", sensorValue);
                state.put("sensorDate", today);
                write(state); return state;
            }
            long delta = Math.max(0L, Math.round(sensorValue - previous));
            state.put("sensorLastValue", sensorValue);
            state.put("sensorDate", today);
            if (delta > 0) {
                JSONObject days = state.getJSONObject("days");
                JSONObject day = days.optJSONObject(today);
                if (day == null) { day = new JSONObject(); day.put("steps", 0); days.put(today, day); }
                day.put("steps", day.optLong("steps", 0) + delta);
                state.put("totalSteps", state.optLong("totalSteps", 0) + delta);
            }
        } catch (Exception ignored) { }
        write(state); return state;
    }

    synchronized void setEnabled(boolean enabled) {
        File f = new File(directory(), ENABLED_FILE);
        if (!enabled) { if (f.exists()) f.delete(); return; }
        try (FileOutputStream out = new FileOutputStream(f, false)) { out.write("true".getBytes(StandardCharsets.UTF_8)); } catch (Exception ignored) { }
    }
    synchronized boolean enabled() { return new File(directory(), ENABLED_FILE).exists(); }

    private JSONObject read() {
        File f = new File(directory(), FILE);
        if (!f.exists()) return new JSONObject();
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] b = new byte[(int) f.length()];
            if (in.read(b) > 0) return new JSONObject(new String(b, StandardCharsets.UTF_8));
        } catch (Exception ignored) { }
        return new JSONObject(); // corrupted file is contained; UI will still be usable.
    }
    private void write(JSONObject state) {
        File target = new File(directory(), FILE); File tmp = new File(directory(), FILE + ".tmp");
        try (FileOutputStream out = new FileOutputStream(tmp, false)) {
            out.write(state.toString().getBytes(StandardCharsets.UTF_8)); out.getFD().sync();
            if (target.exists() && !target.delete()) return;
            if (!tmp.renameTo(target)) { try (FileOutputStream fallback = new FileOutputStream(target, false)) { fallback.write(state.toString().getBytes(StandardCharsets.UTF_8)); } tmp.delete(); }
        } catch (Exception ignored) { }
    }
    private File directory() { File d = new File(context.getFilesDir(), DIR); if (!d.exists()) d.mkdirs(); return d; }
}
