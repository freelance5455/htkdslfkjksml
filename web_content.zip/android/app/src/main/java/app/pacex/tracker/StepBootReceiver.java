package app.pacex.tracker;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Restarts only the opt-in native step service after an Android reboot. */
public class StepBootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction()) && !Intent.ACTION_MY_PACKAGE_REPLACED.equals(intent.getAction())) return;
        StepDataStore store = new StepDataStore(context);
        if (store.enabled() && PaceXStepService.available(context)) PaceXStepService.start(context);
    }
}
