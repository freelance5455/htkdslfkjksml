package app.pacex.tracker;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Build;
import android.os.IBinder;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;

/** A location-type foreground service that owns GPS updates while an activity is active. */
public class PaceXLocationService extends Service {
    static final String ACTION_START = "app.pacex.tracker.location.START";
    static final String ACTION_PAUSE = "app.pacex.tracker.location.PAUSE";
    static final String ACTION_RESUME = "app.pacex.tracker.location.RESUME";
    static final String ACTION_STOP = "app.pacex.tracker.location.STOP";
    static final String ACTION_CANCEL = "app.pacex.tracker.location.CANCEL";
    static final String ACTION_LOCATION = "app.pacex.tracker.LOCATION";
    static final String ACTION_STATUS = "app.pacex.tracker.TRACKING_STATUS";
    static final String EXTRA_MODE = "mode";
    private static final String CHANNEL = "pace_x_tracking";
    private static final int NOTIFICATION_ID = 4101;

    private FusedLocationProviderClient fused;
    private LocationCallback callback;
    private WorkoutSessionStore store;

    static void command(Context context, String action, @Nullable String mode) {
        Intent intent = new Intent(context, PaceXLocationService.class).setAction(action);
        if (mode != null) intent.putExtra(EXTRA_MODE, mode);
        ContextCompat.startForegroundService(context, intent);
    }

    @Override public void onCreate() {
        super.onCreate();
        store = new WorkoutSessionStore(this);
        fused = LocationServices.getFusedLocationProviderClient(this);
        callback = new LocationCallback() {
            @Override public void onLocationResult(LocationResult result) {
                for (Location location : result.getLocations()) {
                    if (store.addLocation(location)) broadcastLocation(location);
                    else if (location.hasAccuracy() && location.getAccuracy() > 25f) broadcastStatus("gps_lost");
                }
            }
        };
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_RESUME : intent.getAction();
        if (ACTION_START.equals(action)) {
            store.start(intent.getStringExtra(EXTRA_MODE) == null ? "running" : intent.getStringExtra(EXTRA_MODE));
            enterForeground("Tracking activity"); requestLocations(); broadcastStatus("started");
        } else if (ACTION_PAUSE.equals(action)) {
            store.pause(); removeLocations(); updateNotification("Workout paused"); broadcastStatus("paused");
        } else if (ACTION_RESUME.equals(action)) {
            if (store.hasActive()) { store.resume(); enterForeground("Tracking activity"); requestLocations(); broadcastStatus("resumed"); }
        } else if (ACTION_STOP.equals(action)) {
            store.pause(); removeLocations(); broadcastStatus("stopped"); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf();
        } else if (ACTION_CANCEL.equals(action)) {
            removeLocations(); store.clear(); broadcastStatus("cancelled"); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf();
        } else if (store.hasActive() && !store.isPaused()) {
            // START_STICKY recovery after the service process is reclaimed.
            enterForeground("Resuming activity tracking"); requestLocations(); broadcastStatus("recovered");
        }
        return START_STICKY;
    }

    private void requestLocations() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            broadcastStatus("permission_missing"); return;
        }
        try {
            // High-accuracy fused provider automatically uses the handset's GPS when it is
            // enabled. Two-second / two-metre sampling gives a more faithful route while the
            // quality filters in WorkoutSessionStore protect distance from GPS wander.
            LocationRequest request = new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 2000L)
                .setMinUpdateIntervalMillis(1000L).setMinUpdateDistanceMeters(2f)
                .setWaitForAccurateLocation(true).setMaxUpdateDelayMillis(4000L).build();
            fused.requestLocationUpdates(request, callback, getMainLooper());
        } catch (SecurityException ignored) { broadcastStatus("permission_missing"); }
    }
    private void removeLocations() { try { fused.removeLocationUpdates(callback); } catch (Exception ignored) { } }

    private void enterForeground(String detail) {
        Notification notification = notification(detail);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
        else startForeground(NOTIFICATION_ID, notification);
    }
    private void updateNotification(String detail) { ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(NOTIFICATION_ID, notification(detail)); }
    private Notification notification(String detail) {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) manager.createNotificationChannel(new NotificationChannel(CHANNEL, "Active workout tracking", NotificationManager.IMPORTANCE_LOW));
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pending = PendingIntent.getActivity(this, 100, open, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        return new NotificationCompat.Builder(this, CHANNEL).setSmallIcon(android.R.drawable.ic_menu_mylocation).setContentTitle("PACE X is tracking your workout").setContentText(detail).setContentIntent(pending).setOngoing(true).setOnlyAlertOnce(true).setCategory(NotificationCompat.CATEGORY_SERVICE).build();
    }
    private void broadcastLocation(Location l) {
        Intent event = new Intent(ACTION_LOCATION).setPackage(getPackageName());
        event.putExtra("latitude", l.getLatitude()); event.putExtra("longitude", l.getLongitude()); event.putExtra("accuracy", l.getAccuracy());
        event.putExtra("speedMps", l.hasSpeed() ? l.getSpeed() : -1f); event.putExtra("timestamp", l.getTime() > 0 ? l.getTime() : System.currentTimeMillis());
        sendBroadcast(event);
    }
    private void broadcastStatus(String status) { sendBroadcast(new Intent(ACTION_STATUS).setPackage(getPackageName()).putExtra("status", status)); }
    @Nullable @Override public IBinder onBind(Intent intent) { return null; }
    @Override public void onTaskRemoved(Intent rootIntent) { /* Foreground service intentionally persists; session is atomically stored. */ super.onTaskRemoved(rootIntent); }
    @Override public void onDestroy() { removeLocations(); super.onDestroy(); }
}
