package app.pacex.tracker;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import androidx.activity.result.ActivityResult;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import com.google.android.gms.location.CancellationTokenSource;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;

import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** Capacitor bridge for the parts that cannot reliably be implemented in browser JavaScript. */
@CapacitorPlugin(
    name = "PaceXNative",
    permissions = {
        @Permission(alias = "location", strings = { Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION }),
        @Permission(alias = "activity", strings = { Manifest.permission.ACTIVITY_RECOGNITION }),
        @Permission(alias = "notifications", strings = { Manifest.permission.POST_NOTIFICATIONS }),
        @Permission(alias = "backgroundLocation", strings = { Manifest.permission.ACCESS_BACKGROUND_LOCATION })
    }
)
public class PaceXNativePlugin extends Plugin {
    private FusedLocationProviderClient fused;
    private BroadcastReceiver receiver;

    @Override public void load() {
        fused = LocationServices.getFusedLocationProviderClient(getContext());
        receiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (PaceXLocationService.ACTION_LOCATION.equals(action)) {
                    JSObject point = new JSObject();
                    point.put("latitude", intent.getDoubleExtra("latitude", 0)); point.put("longitude", intent.getDoubleExtra("longitude", 0));
                    point.put("accuracy", intent.getFloatExtra("accuracy", 999));
                    float speed = intent.getFloatExtra("speedMps", -1); if (speed >= 0) point.put("speedMps", speed);
                    point.put("timestamp", TimeUtil.iso(intent.getLongExtra("timestamp", System.currentTimeMillis())));
                    notifyListeners("locationUpdate", point, true);
                } else if (PaceXLocationService.ACTION_STATUS.equals(action)) {
                    JSObject status = new JSObject(); status.put("status", intent.getStringExtra("status")); notifyListeners("trackingStatus", status, true);
                } else if (PaceXStepService.ACTION_STEP.equals(action)) {
                    try { notifyListeners("stepUpdate", JSObject.fromJSONObject(new JSONObject(intent.getStringExtra("json"))), true); } catch (Exception ignored) { }
                }
            }
        };
        IntentFilter filter = new IntentFilter(); filter.addAction(PaceXLocationService.ACTION_LOCATION); filter.addAction(PaceXLocationService.ACTION_STATUS); filter.addAction(PaceXStepService.ACTION_STEP);
        if (Build.VERSION.SDK_INT >= 33) getContext().registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else getContext().registerReceiver(receiver, filter);
    }

    @PluginMethod public void requestFeature(PluginCall call) {
        String feature = call.getString("feature", "");
        if ("location".equals(feature)) { requestAliasIfNeeded("location", call); return; }
        if ("activity".equals(feature)) { if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) { call.resolve(permissionResult()); } else requestAliasIfNeeded("activity", call); return; }
        if ("notifications".equals(feature)) { if (Build.VERSION.SDK_INT < 33) call.resolve(permissionResult()); else requestAliasIfNeeded("notifications", call); return; }
        if ("backgroundLocation".equals(feature)) {
            // Android 11+ requires background access to be changed from the app settings screen.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Intent settings = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", getContext().getPackageName(), null));
                getActivity().startActivity(settings); JSObject out = permissionResult(); out.put("settingsOpened", true); call.resolve(out);
            } else requestAliasIfNeeded("backgroundLocation", call);
            return;
        }
        call.reject("Unknown permission feature.");
    }
    private void requestAliasIfNeeded(String alias, PluginCall call) {
        if (getPermissionState(alias) == PermissionState.GRANTED) call.resolve(permissionResult());
        else requestPermissionForAlias(alias, call, "permissionCallback");
    }
    @PermissionCallback private void permissionCallback(PluginCall call) { call.resolve(permissionResult()); }
    private JSObject permissionResult() {
        JSObject out = new JSObject();
        out.put("location", getPermissionState("location").toString()); out.put("activity", getPermissionState("activity").toString());
        out.put("notifications", getPermissionState("notifications").toString()); out.put("backgroundLocation", getPermissionState("backgroundLocation").toString()); return out;
    }

    @PluginMethod public void getCurrentLocation(PluginCall call) {
        if (!hasFineOrCoarse()) { call.reject("Location permission is not granted."); return; }
        LocationManager manager = (LocationManager) getContext().getSystemService(Context.LOCATION_SERVICE);
        if (manager != null && !manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            call.reject("Phone GPS is switched off. Turn on Location and choose Precise location for PACE X."); return;
        }
        try {
            CancellationTokenSource token = new CancellationTokenSource();
            fused.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, token.getToken()).addOnSuccessListener(location -> {
                if (location == null) { call.reject("No GPS location is available yet."); return; }
                JSObject result = locationObject(location); call.resolve(result);
            }).addOnFailureListener(error -> call.reject("Could not get GPS location.", error));
        } catch (SecurityException error) { call.reject("Location permission is not granted.", error); }
    }

    @PluginMethod public void startTracking(PluginCall call) {
        if (!hasFineOrCoarse()) { call.reject("Location permission is required to start a workout."); return; }
        try { PaceXLocationService.command(getContext(), PaceXLocationService.ACTION_START, call.getString("mode", "running")); call.resolve(new JSObject().put("started", true)); }
        catch (Exception e) { call.reject("Android prevented the foreground tracking service from starting.", e); }
    }
    @PluginMethod public void pauseTracking(PluginCall call) { PaceXLocationService.command(getContext(), PaceXLocationService.ACTION_PAUSE, null); call.resolve(); }
    @PluginMethod public void resumeTracking(PluginCall call) { PaceXLocationService.command(getContext(), PaceXLocationService.ACTION_RESUME, null); call.resolve(); }
    @PluginMethod public void stopTracking(PluginCall call) {
        JSONObject session = new WorkoutSessionStore(getContext()).snapshot(); PaceXLocationService.command(getContext(), PaceXLocationService.ACTION_STOP, null);
        try { if (session == null) call.resolve(new JSObject().put("active", false)); else call.resolve(JSObject.fromJSONObject(session)); } catch (Exception e) { call.reject("Could not read active workout.", e); }
    }
    @PluginMethod public void cancelTracking(PluginCall call) { PaceXLocationService.command(getContext(), PaceXLocationService.ACTION_CANCEL, null); call.resolve(); }
    @PluginMethod public void getActiveSession(PluginCall call) {
        try { JSONObject session = new WorkoutSessionStore(getContext()).snapshot(); if (session == null) call.resolve(new JSObject().put("active", false)); else call.resolve(JSObject.fromJSONObject(session)); }
        catch (Exception e) { call.reject("Could not restore active session.", e); }
    }
    @PluginMethod public void clearActiveSession(PluginCall call) { new WorkoutSessionStore(getContext()).clear(); call.resolve(); }

    @PluginMethod public void enableStepCounter(PluginCall call) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && getPermissionState("activity") != PermissionState.GRANTED) { call.reject("Physical activity permission is required for the native step counter."); return; }
        if (!PaceXStepService.available(getContext())) { call.reject("This device does not provide Android's TYPE_STEP_COUNTER sensor."); return; }
        try { PaceXStepService.start(getContext()); JSONObject data = new StepDataStore(getContext()).current(); call.resolve(JSObject.fromJSONObject(data)); }
        catch (Exception e) { call.reject("Could not start native step counting.", e); }
    }
    @PluginMethod public void disableStepCounter(PluginCall call) { PaceXStepService.stop(getContext()); call.resolve(); }
    @PluginMethod public void getStepState(PluginCall call) { try { call.resolve(JSObject.fromJSONObject(new StepDataStore(getContext()).current())); } catch (Exception e) { call.reject("Could not read step history.", e); } }
    @PluginMethod public void getPermissionState(PluginCall call) { call.resolve(permissionResult()); }
    @PluginMethod public void openAppSettings(PluginCall call) { getActivity().startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", getContext().getPackageName(), null))); call.resolve(); }

    @PluginMethod public void exportJson(PluginCall call) {
        String filename = call.getString("filename", "pace-x-export.json").replaceAll("[^A-Za-z0-9._-]", "_");
        Intent save = new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json").putExtra(Intent.EXTRA_TITLE, filename);
        startActivityForResult(call, save, "exportResult");
    }
    @ActivityCallback private void exportResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != android.app.Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) { call.reject("Export cancelled."); return; }
        try (OutputStream stream = getContext().getContentResolver().openOutputStream(result.getData().getData(), "w")) {
            if (stream == null) throw new IllegalStateException("No output stream.");
            stream.write(call.getString("json", "{}").getBytes(StandardCharsets.UTF_8)); stream.flush(); call.resolve(new JSObject().put("saved", true));
        } catch (Exception e) { call.reject("Could not write export file.", e); }
    }

    private boolean hasFineOrCoarse() { return ContextCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED; }
    @NonNull private JSObject locationObject(Location location) {
        JSObject r = new JSObject(); r.put("latitude", location.getLatitude()); r.put("longitude", location.getLongitude()); r.put("accuracy", location.hasAccuracy() ? location.getAccuracy() : 999); if (location.hasSpeed()) r.put("speedMps", location.getSpeed()); r.put("timestamp", TimeUtil.iso(location.getTime() > 0 ? location.getTime() : System.currentTimeMillis())); return r;
    }
    @Override protected void handleOnDestroy() { if (receiver != null) { try { getContext().unregisterReceiver(receiver); } catch (Exception ignored) { } } super.handleOnDestroy(); }
}
