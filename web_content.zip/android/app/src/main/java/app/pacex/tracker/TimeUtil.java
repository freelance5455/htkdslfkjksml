package app.pacex.tracker;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** ISO-8601 helpers compatible with Android API 22; avoids requiring java.time on older phones. */
final class TimeUtil {
    private static final String ISO = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
    static String iso(long millis) {
        SimpleDateFormat f = new SimpleDateFormat(ISO, Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return f.format(new Date(millis));
    }
    static long parse(String value, long fallback) {
        try { SimpleDateFormat f = new SimpleDateFormat(ISO, Locale.US); f.setTimeZone(TimeZone.getTimeZone("UTC")); return f.parse(value).getTime(); }
        catch (ParseException | NullPointerException ignored) { return fallback; }
    }
    static String dayKey() {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        return f.format(new Date());
    }
}
