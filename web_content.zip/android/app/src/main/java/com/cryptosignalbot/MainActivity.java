package com.cryptosignalbot;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.webkit.*;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    WebView web;
    static final String CHANNEL_ID="signals";
    @Override public void onCreate(Bundle b){super.onCreate(b); createChannel();
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},101);
        web=new WebView(this); WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW); web.setWebViewClient(new WebViewClient()); web.addJavascriptInterface(new NativeApi(web),"NativeApi"); setContentView(web); web.loadUrl("file:///android_asset/public/index.html");
        SignalAlarmReceiver.schedule(this);
    }
    void createChannel(){ if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL_ID,"AI Trading Signals",NotificationManager.IMPORTANCE_HIGH); c.setDescription("Crypto Money Agent alerts"); ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}}
    public static class NativeApi {
        final WebView web; final ExecutorService pool=Executors.newCachedThreadPool();
        NativeApi(WebView w){web=w;}
        @JavascriptInterface public void get(String url,String id){ pool.execute(()->{String result; try{result=http(url);}catch(Exception e){result="__ERROR__"+e.getClass().getSimpleName()+":"+e.getMessage();} final String out=result; web.post(()->web.evaluateJavascript("window.__nativeDone && window.__nativeDone("+JSONObject.quote(id)+","+JSONObject.quote(out)+")",null));}); }
        static String http(String u)throws Exception{ if(!u.startsWith("https://www.bitstamp.net/api/v2/"))throw new SecurityException("URL not allowed"); HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection(); c.setConnectTimeout(12000); c.setReadTimeout(15000); c.setRequestProperty("Accept","application/json"); c.setRequestProperty("User-Agent","CryptoMoneyAgent/2.0 Android"); int code=c.getResponseCode(); InputStream in=code>=400?c.getErrorStream():c.getInputStream(); if(in==null)throw new IOException("empty response HTTP "+code); BufferedReader r=new BufferedReader(new InputStreamReader(in)); StringBuilder sb=new StringBuilder(); String line; while((line=r.readLine())!=null)sb.append(line); r.close(); if(code<200||code>=300)throw new IOException("HTTP "+code); return sb.toString(); }
    }
}
