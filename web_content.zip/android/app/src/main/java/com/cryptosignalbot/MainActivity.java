package com.cryptosignalbot;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
 @Override public void onCreate(Bundle savedInstanceState) {
  super.onCreate(savedInstanceState);
  WebView web = new WebView(this);
  web.setWebViewClient(new ApiProxyWebViewClient());
  WebSettings s = web.getSettings();
  s.setJavaScriptEnabled(true);
  s.setDomStorageEnabled(true);
  s.setAllowFileAccess(true);
  s.setAllowContentAccess(true);
  s.setJavaScriptCanOpenWindowsAutomatically(false);
  s.setBuiltInZoomControls(false);
  web.loadUrl("file:///android_asset/public/index.html");
  setContentView(web);
 }

 private static class ApiProxyWebViewClient extends WebViewClient {
  @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
   return proxy(request.getUrl().toString());
  }
  @Override public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
   return proxy(url);
  }
  private WebResourceResponse proxy(String url) {
   if (!url.startsWith("https://www.bitstamp.net/api/v2/")) return null;
   HttpURLConnection c = null;
   try {
    c = (HttpURLConnection)new URL(url).openConnection();
    c.setConnectTimeout(12000);
    c.setReadTimeout(15000);
    c.setRequestMethod("GET");
    c.setRequestProperty("Accept", "application/json");
    c.setRequestProperty("User-Agent", "CryptoMoneyAgent/1.0 Android");
    c.setUseCaches(false);
    int code = c.getResponseCode();
    InputStream stream = code >= 400 ? c.getErrorStream() : c.getInputStream();
    if (stream == null) return null;
    Map<String,String> headers = new HashMap<>();
    headers.put("Access-Control-Allow-Origin", "*");
    headers.put("Cache-Control", "no-store");
    headers.put("Content-Type", c.getContentType() != null ? c.getContentType() : "application/json");
    return new WebResourceResponse("application", "UTF-8", code, c.getResponseMessage(), headers, stream);
   } catch (Exception e) {
    return null;
   }
  }
 }
}
