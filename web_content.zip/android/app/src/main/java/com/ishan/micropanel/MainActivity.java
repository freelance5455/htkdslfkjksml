package com.ishan.micropanel;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.graphics.Color;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle state) {
  super.onCreate(state);
  getWindow().setStatusBarColor(Color.rgb(16,8,11));
  getWindow().setNavigationBarColor(Color.rgb(16,8,11));
  WebView web = new WebView(this);
  web.setBackgroundColor(Color.rgb(16,8,11));
  WebSettings settings = web.getSettings();
  settings.setJavaScriptEnabled(true);
  settings.setDomStorageEnabled(true);
  settings.setAllowFileAccess(true);
  settings.setAllowContentAccess(false);
  web.loadUrl("file:///android_asset/index.html");
  setContentView(web);
 }
}
