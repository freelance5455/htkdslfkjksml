package com.rms.movieplace
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity: ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App()}}}
@Composable fun App(){
 var screen by remember{mutableStateOf(0)};var time by remember{mutableStateOf("")};var selected by remember{mutableStateOf(setOf<String>())}
 val seats=(0 until 60).map{"${('A'.code+it/10).toChar()}${it%10+1}"}
 MaterialTheme{Surface(Modifier.fillMaxSize(),color=Color(12,12,16)){Column(Modifier.padding(20.dp)){
 when(screen){
  0->{Text("RMS MOVIE PLACE",color=Color.White,fontSize=28.sp);Spacer(Modifier.height(20.dp));Box(Modifier.fillMaxWidth().height(400.dp).background(Color.DarkGray),contentAlignment=Alignment.Center){Text("MOVIE POSTER",color=Color.White,fontSize=28.sp)};Spacer(Modifier.height(20.dp));Button({screen=1},Modifier.fillMaxWidth()){Text("BOOK NOW • ₹50")}}
  1->{Text("SELECT SHOWTIME",color=Color.White,fontSize=24.sp);listOf("10:00 AM","1:00 PM","4:00 PM","7:00 PM").forEach{t->Button({time=t;screen=2},Modifier.fillMaxWidth().padding(5.dp)){Text(t)}}}
  2->{Text("SELECT YOUR SEATS",color=Color.White,fontSize=24.sp);Spacer(Modifier.height(10.dp));LazyVerticalGrid(GridCells.Fixed(10),Modifier.weight(1f)){items(seats){s->Box(Modifier.padding(3.dp).size(32.dp).background(if(s in selected)Color(0xFFFF9800)else Color(0xFF33343A)).clickable{selected=if(s in selected)selected-s else selected+s},contentAlignment=Alignment.Center){Text(s,color=Color.White,fontSize=9.sp)}}};Text("Selected: ${selected.size}  Total: ₹${selected.size*50}",color=Color.White,fontSize=20.sp);Button({screen=3},enabled=selected.isNotEmpty(),Modifier.fillMaxWidth()){Text("BOOK TICKETS")}}
  3->{Column(Modifier.fillMaxSize(),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Text("✓ BOOKING CONFIRMED",color=Color.White,fontSize=25.sp);Text("RMS MOVIE PLACE",color=Color.White);Text("Show: $time",color=Color.White);Text("Seats: ${selected.sorted().joinToString(", ")}",color=Color.White);Text("TOTAL ₹${selected.size*50}",color=Color.White,fontSize=24.sp);Spacer(Modifier.height(20.dp));Button({screen=0;selected=emptySet()}){Text("BACK TO HOME")}}}
 }}}}
}