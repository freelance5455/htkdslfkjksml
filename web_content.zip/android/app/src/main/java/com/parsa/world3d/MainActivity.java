package com.parsa.world3d;
import android.app.*;import android.os.*;import android.webkit.*;import android.view.*;
public class MainActivity extends Activity{
 public void onCreate(Bundle b){super.onCreate(b);
  WebView w=new WebView(this); WebSettings s=w.getSettings();
  s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
  s.setAllowFileAccess(true); s.setAllowContentAccess(true);
  s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
  w.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
  w.setBackgroundColor(0xFF07111F);
  w.loadUrl("file:///android_asset/index.html");
  setContentView(w);
 }
}
