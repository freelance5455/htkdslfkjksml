package com.papercraft.studio;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
