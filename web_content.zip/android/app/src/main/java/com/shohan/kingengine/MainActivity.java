package com.shohan.kingengine;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
