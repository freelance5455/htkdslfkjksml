package com.jagiroad.school

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.print.PrintManager
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import java.io.OutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private val prefs by lazy { getSharedPreferences("perm", MODE_PRIVATE) }

    /** System photo/file picker. No storage permission is needed. */
    private val chooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        fileCb = null
    }

    /** Real Android runtime permission dialog for notifications (Android 13+). */
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
        prefs.edit().putBoolean("notifAsked", true).apply()
        js("window.__nfResult&&window.__nfResult('${notifState()}')")
    }

    private fun js(code: String) = runOnUiThread { if (::web.isInitialized) web.evaluateJavascript(code, null) }

    /** Web Notification API values: granted / default (can still ask) / denied (blocked: only Settings can change it). */
    private fun notifState(): String {
        val enabled = NotificationManagerCompat.from(this).areNotificationsEnabled()
        if (Build.VERSION.SDK_INT < 33) return if (enabled) "granted" else "denied"
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        if (granted) return if (enabled) "granted" else "denied"
        if (!prefs.getBoolean("notifAsked", false)) return "default"
        return if (shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) "default" else "denied"
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor("#F3F6FB"))
        web = WebView(this)
        root.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        WindowCompat.getInsetsController(window, root).isAppearanceLightStatusBars = true
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val s = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(s.left, s.top, s.right, s.bottom)
            insets
        }

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            setSupportMultipleWindows(false)
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.host == "appassets.androidplatform.net") return false
                try { startActivity(Intent(Intent.ACTION_VIEW, u)) }
                catch (e: Exception) { Toast.makeText(this@MainActivity, "No app found to open this link", Toast.LENGTH_SHORT).show() }
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try { chooser.launch(p.createIntent()); true }
                catch (e: Exception) { fileCb = null; false }
            }
        }
        web.addJavascriptInterface(Bridge(), "AndroidApp")

        // Android Back: the web app owns the screen stack. It returns true when it handled Back
        // (closed a dialog/menu or went to the previous screen). On the root screen it returns false,
        // and we minimise the app, which is the normal Android behaviour for a root screen.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(function(){try{return window.__appBack?window.__appBack():false}catch(e){return false}})()") { r ->
                    if (r != "true") moveTaskToBack(true)
                }
            }
        })

        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    override fun onResume() {
        super.onResume()
        // The user may have changed the permission in Android Settings.
        js("window.__permChanged&&window.__permChanged()")
    }

    override fun onDestroy() {
        if (::web.isInitialized) { (web.parent as? ViewGroup)?.removeView(web); web.destroy() }
        super.onDestroy()
    }

    private var outStream: OutputStream? = null
    private var outUri: Uri? = null

    inner class Bridge {
        @JavascriptInterface fun notifPermission(): String = notifState()
        @JavascriptInterface fun notifAsked(): Boolean = prefs.getBoolean("notifAsked", false)

        @JavascriptInterface fun requestNotifPermission() {
            runOnUiThread {
                val s = notifState()
                if (s == "default") notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
                else js("window.__nfResult&&window.__nfResult('$s')")
            }
        }

        @JavascriptInterface fun openSettings() {
            runOnUiThread {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null)))
            }
        }

        @JavascriptInterface fun notify(title: String, body: String, tag: String) = showNotification(title, body, tag)

        @JavascriptInterface fun print() {
            runOnUiThread {
                val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
                pm.print("Jagiroad document", web.createPrintDocumentAdapter("Jagiroad document"), null)
            }
        }

        // Saves to the public Downloads folder through MediaStore (no storage permission needed).
        @JavascriptInterface fun fileBegin(name: String, mime: String): Boolean = try {
            val v = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name.replace(Regex("[\\\\/:*?\"<>|]"), "_"))
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val u = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
            outUri = u
            outStream = u?.let { contentResolver.openOutputStream(it) }
            outStream != null
        } catch (e: Exception) { false }

        @JavascriptInterface fun fileChunk(b64: String): Boolean = try {
            outStream!!.write(Base64.decode(b64, Base64.DEFAULT)); true
        } catch (e: Exception) { false }

        @JavascriptInterface fun fileEnd(ok: Boolean): Boolean = try {
            outStream?.close(); outStream = null
            val u = outUri; outUri = null
            if (u != null) {
                if (ok) contentResolver.update(u, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
                else contentResolver.delete(u, null, null)
            }
            ok && u != null
        } catch (e: Exception) { false }
    }

    private fun showNotification(title: String, body: String, tag: String) {
        if (notifState() != "granted") return
        val ch = "school_alerts"
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(ch) == null) {
            nm.createNotificationChannel(
                NotificationChannel(ch, "School alerts", NotificationManager.IMPORTANCE_HIGH)
                    .apply { description = "Notices, homework, results and leave updates" })
        }
        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(this, ch)
            .setSmallIcon(R.drawable.ic_stat_notify)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()
        try { nm.notify((tag.ifEmpty { title }).hashCode(), n) } catch (e: SecurityException) { }
    }
}
