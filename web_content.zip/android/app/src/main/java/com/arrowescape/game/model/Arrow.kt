package com.arrowescape.game.model

data class Point(val x: Int, val y: Int)

data class Arrow(
    val id: String,
    val points: List<Point>,
    val row: Int,
    val col: Int,
    val direction: Direction,
    val isEscaping: Boolean = false,
    val isHinted: Boolean = false,
    val isInvalid: Boolean = false
)
