package com.arrowescape.game.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.arrowescape.game.ui.theme.DarkCard
import com.arrowescape.game.ui.theme.TextMuted
import com.arrowescape.game.ui.theme.TextWhite

@Composable
fun GameHud(
    levelId: Int,
    lives: Int,
    moves: Int,
    elapsedSeconds: Int,
    remainingArrows: Int,
    totalArrows: Int,
    onPause: () -> Unit,
    onRestart: () -> Unit,
    onHint: () -> Unit,
    modifier: Modifier = Modifier
) {
    val progress = if (totalArrows > 0) {
        ((totalArrows - remainingArrows).toFloat() / totalArrows.toFloat()).coerceIn(0f, 1f)
    } else 0f

    val minutes = elapsedSeconds / 60
    val seconds = elapsedSeconds % 60
    val timeFormatted = String.format("%02d:%02d", minutes, seconds)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "LEVEL $levelId",
                    color = TextWhite,
                    fontSize = 16.sp,
                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                )
                Text(
                    text = "$remainingArrows Remaining · $timeFormatted",
                    color = TextMuted,
                    fontSize = 11.sp
                )
            }

            // Lives indicators
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                for (i in 1..3) {
                    Icon(
                        imageVector = if (i <= lives) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Life $i",
                        tint = TextWhite,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Action controls
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                IconButton(onClick = onHint, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Default.Lightbulb, contentDescription = "Hint", tint = TextWhite)
                }
                IconButton(onClick = onRestart, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Default.Refresh, contentDescription = "Restart", tint = TextWhite)
                }
                IconButton(onClick = onPause, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Default.Pause, contentDescription = "Pause", tint = TextWhite)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Progress bar
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp),
            color = TextWhite,
            trackColor = DarkCard
        )
    }
}
