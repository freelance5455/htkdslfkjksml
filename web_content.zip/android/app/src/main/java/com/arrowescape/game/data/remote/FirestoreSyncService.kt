package com.arrowescape.game.data.remote

import com.arrowescape.game.model.LevelProgress
import com.arrowescape.game.model.UserProgress
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await

class FirestoreSyncService(
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) {

    suspend fun fetchCloudProgress(uid: String): UserProgress? {
        return try {
            val doc = firestore.collection("users")
                .document(uid)
                .collection("progress")
                .document("main")
                .get()
                .await()

            if (!doc.exists()) return null

            val currentLevel = (doc.getLong("currentLevel") ?: 1L).toInt()
            val totalStars = (doc.getLong("totalStars") ?: 0L).toInt()
            val totalScore = (doc.getLong("totalScore") ?: 0L).toInt()
            val lastUpdated = doc.getString("updatedAt") ?: ""

            val rawMap = doc.get("completedLevels") as? Map<*, *> ?: emptyMap<Any, Any>()
            val completedMap = mutableMapOf<Int, LevelProgress>()

            for ((k, v) in rawMap) {
                val lvlId = k.toString().toIntOrNull() ?: continue
                val entry = v as? Map<*, *> ?: continue
                completedMap[lvlId] = LevelProgress(
                    stars = (entry["stars"] as? Long)?.toInt() ?: 0,
                    bestTimeSec = (entry["bestTimeSec"] as? Long)?.toInt() ?: 0,
                    bestMoves = (entry["bestMoves"] as? Long)?.toInt() ?: 0,
                    completedAt = entry["completedAt"] as? String ?: ""
                )
            }

            UserProgress(
                currentLevel = currentLevel,
                completedLevels = completedMap,
                totalStars = totalStars,
                totalScore = totalScore,
                lastUpdated = lastUpdated,
                pendingSync = false
            )
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    suspend fun saveCloudProgress(uid: String, progress: UserProgress): Boolean {
        return try {
            val serializableCompleted = progress.completedLevels.mapKeys { it.key.toString() }.mapValues {
                mapOf(
                    "stars" to it.value.stars,
                    "bestTimeSec" to it.value.bestTimeSec,
                    "bestMoves" to it.value.bestMoves,
                    "completedAt" to it.value.completedAt
                )
            }

            val data = hashMapOf(
                "currentLevel" to progress.currentLevel,
                "completedLevels" to serializableCompleted,
                "totalStars" to progress.totalStars,
                "totalScore" to progress.totalScore,
                "settings" to mapOf(
                    "soundEnabled" to progress.settings.soundEnabled,
                    "hapticsEnabled" to progress.settings.hapticsEnabled,
                    "animationSpeed" to progress.settings.animationSpeed,
                    "contrastTheme" to progress.settings.contrastTheme
                ),
                "updatedAt" to java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US).apply {
                    timeZone = java.util.TimeZone.getTimeZone("UTC")
                }.format(java.util.Date())
            )

            firestore.collection("users")
                .document(uid)
                .collection("progress")
                .document("main")
                .set(data, SetOptions.merge())
                .await()

            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
