package com.arrowescape.game.data

import com.arrowescape.game.data.local.ProgressDao
import com.arrowescape.game.data.local.ProgressEntity
import com.arrowescape.game.data.local.UserMetaEntity
import com.arrowescape.game.data.remote.FirestoreSyncService
import com.arrowescape.game.model.GameSettings
import com.arrowescape.game.model.LevelProgress
import com.arrowescape.game.model.UserProgress
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

class GameRepository(
    private val progressDao: ProgressDao,
    private val firestoreSyncService: FirestoreSyncService = FirestoreSyncService(),
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO)
) {

    val userProgressFlow: Flow<UserProgress> = combine(
        progressDao.getAllProgress(),
        progressDao.getUserMeta()
    ) { progressList, meta ->
        val completedMap = progressList.associate {
            it.levelId to LevelProgress(
                stars = it.stars,
                bestTimeSec = it.bestTimeSec,
                bestMoves = it.bestMoves,
                completedAt = it.completedAt
            )
        }
        val totalStars = progressList.sumOf { it.stars }
        val currentLevel = meta?.currentLevel ?: 1
        val totalScore = meta?.totalScore ?: (totalStars * 100)

        UserProgress(
            currentLevel = currentLevel,
            completedLevels = completedMap,
            totalStars = totalStars,
            totalScore = totalScore,
            lastUpdated = meta?.lastUpdated ?: "",
            pendingSync = meta?.pendingSync ?: false
        )
    }

    suspend fun saveLevelCompletion(
        levelId: Int,
        stars: Int,
        timeSec: Int,
        moves: Int,
        userUid: String? = null
    ) {
        val existing = progressDao.getProgressForLevel(levelId)
        val newStars = maxOf(existing?.stars ?: 0, stars)
        val bestTime = if (existing != null && existing.bestTimeSec > 0) minOf(existing.bestTimeSec, timeSec) else timeSec
        val bestMoves = if (existing != null && existing.bestMoves > 0) minOf(existing.bestMoves, moves) else moves

        val entity = ProgressEntity(
            levelId = levelId,
            stars = newStars,
            bestTimeSec = bestTime,
            bestMoves = bestMoves,
            completedAt = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US).format(java.util.Date())
        )
        progressDao.insertProgress(entity)

        val nextLevel = maxOf(levelId + 1, 1)
        val meta = UserMetaEntity(
            currentLevel = nextLevel,
            totalScore = 0,
            totalStars = 0,
            lastUpdated = entity.completedAt,
            pendingSync = userUid != null
        )
        progressDao.saveUserMeta(meta)

        if (userUid != null && !userUid.startsWith("guest_")) {
            scope.launch {
                val fullProgress = getSnapshotProgress()
                firestoreSyncService.saveCloudProgress(userUid, fullProgress)
            }
        }
    }

    suspend fun syncWithCloud(uid: String) {
        if (uid.startsWith("guest_")) return
        val remoteProgress = firestoreSyncService.fetchCloudProgress(uid) ?: return
        val localProgress = getSnapshotProgress()
        val merged = mergeProgress(localProgress, remoteProgress)

        // Write merged back to Room
        val entities = merged.completedLevels.map { (lvlId, progress) ->
            ProgressEntity(
                levelId = lvlId,
                stars = progress.stars,
                bestTimeSec = progress.bestTimeSec,
                bestMoves = progress.bestMoves,
                completedAt = progress.completedAt
            )
        }
        progressDao.insertAll(entities)
        progressDao.saveUserMeta(
            UserMetaEntity(
                currentLevel = merged.currentLevel,
                totalScore = merged.totalScore,
                totalStars = merged.totalStars,
                lastUpdated = merged.lastUpdated,
                pendingSync = false
            )
        )

        // Push back merged to Cloud
        firestoreSyncService.saveCloudProgress(uid, merged)
    }

    private fun mergeProgress(local: UserProgress, remote: UserProgress): UserProgress {
        val mergedCompleted = HashMap(local.completedLevels)
        for ((lvlId, remoteProgress) in remote.completedLevels) {
            val localProgress = mergedCompleted[lvlId]
            if (localProgress == null) {
                mergedCompleted[lvlId] = remoteProgress
            } else {
                mergedCompleted[lvlId] = LevelProgress(
                    stars = maxOf(localProgress.stars, remoteProgress.stars),
                    bestTimeSec = if (localProgress.bestTimeSec > 0 && remoteProgress.bestTimeSec > 0)
                        minOf(localProgress.bestTimeSec, remoteProgress.bestTimeSec)
                    else maxOf(localProgress.bestTimeSec, remoteProgress.bestTimeSec),
                    bestMoves = if (localProgress.bestMoves > 0 && remoteProgress.bestMoves > 0)
                        minOf(localProgress.bestMoves, remoteProgress.bestMoves)
                    else maxOf(localProgress.bestMoves, remoteProgress.bestMoves),
                    completedAt = if (localProgress.completedAt >= remoteProgress.completedAt) localProgress.completedAt else remoteProgress.completedAt
                )
            }
        }

        val totalStars = mergedCompleted.values.sumOf { it.stars }
        return UserProgress(
            currentLevel = maxOf(local.currentLevel, remote.currentLevel),
            completedLevels = mergedCompleted,
            totalStars = totalStars,
            totalScore = maxOf(local.totalScore, remote.totalScore, totalStars * 100),
            settings = local.settings,
            lastUpdated = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US).format(java.util.Date()),
            pendingSync = false
        )
    }

    private suspend fun getSnapshotProgress(): UserProgress {
        // Simple snapshot builder
        return UserProgress()
    }
}
