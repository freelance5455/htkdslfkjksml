package com.arrowescape.game.ui.theme

import androidx.compose.ui.graphics.Color

val PureBlack = Color(0xFF000000)
val DarkCard = Color(0xFF0D0D0D)
val DarkGray = Color(0xFF171717)
val BorderSubtle = Color(0xFF262626)
val BorderStrong = Color(0xFF404040)
val TextMuted = Color(0xFFA3A3A3)
val TextWhite = Color(0xFFFFFFFF)
val AccentWhite = Color(0xFFEEEEEE)
