package com.arrowescape.game.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "level_progress")
data class ProgressEntity(
    @PrimaryKey val levelId: Int,
    val stars: Int,
    val bestTimeSec: Int,
    val bestMoves: Int,
    val completedAt: String
)

@Entity(tableName = "user_meta")
data class UserMetaEntity(
    @PrimaryKey val id: String = "main",
    val currentLevel: Int = 1,
    val totalScore: Int = 0,
    val totalStars: Int = 0,
    val lastUpdated: String = "",
    val pendingSync: Boolean = false
)
