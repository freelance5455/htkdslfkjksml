package com.arrowescape.game.model

data class LevelProgress(
    val stars: Int = 0,
    val bestTimeSec: Int = 0,
    val bestMoves: Int = 0,
    val completedAt: String = ""
)

data class GameSettings(
    val soundEnabled: Boolean = true,
    val hapticsEnabled: Boolean = true,
    val animationSpeed: String = "normal",
    val contrastTheme: String = "pure_black"
)

data class UserProgress(
    val currentLevel: Int = 1,
    val completedLevels: Map<Int, LevelProgress> = emptyMap(),
    val totalStars: Int = 0,
    val totalScore: Int = 0,
    val settings: GameSettings = GameSettings(),
    val lastUpdated: String = "",
    val pendingSync: Boolean = false
)

data class AuthUser(
    val uid: String,
    val displayName: String?,
    val email: String?,
    val photoUrl: String?,
    val isGuest: Boolean
)
