package com.arrowescape.game.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.arrowescape.game.model.Arrow
import com.arrowescape.game.model.Direction
import com.arrowescape.game.ui.theme.BorderSubtle
import com.arrowescape.game.ui.theme.DarkCard
import com.arrowescape.game.ui.theme.TextWhite
import kotlin.math.hypot

@Composable
fun ArrowBoard(
    rows: Int,
    cols: Int,
    arrows: List<Arrow>,
    onArrowClick: (Arrow) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(cols.toFloat() / rows.toFloat())
            .background(DarkCard, RoundedCornerShape(16.dp))
            .border(1.dp, BorderSubtle, RoundedCornerShape(16.dp))
            .padding(12.dp)
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(arrows) {
                    detectTapGestures { tapOffset ->
                        val cellSizeX = size.width / cols
                        val cellSizeY = size.height / rows

                        // Find closest arrow to tap
                        var closestArrow: Arrow? = null
                        var minDist = Float.MAX_VALUE

                        for (arrow in arrows) {
                            if (arrow.isEscaping) continue
                            for (p in arrow.points) {
                                val px = p.x * cellSizeX + cellSizeX / 2
                                val py = p.y * cellSizeY + cellSizeY / 2
                                val dist = hypot(tapOffset.x - px, tapOffset.y - py)
                                if (dist < minDist && dist < cellSizeX * 0.9f) {
                                    minDist = dist
                                    closestArrow = arrow
                                }
                            }
                        }

                        closestArrow?.let { onArrowClick(it) }
                    }
                }
        ) {
            val cellSizeX = size.width / cols
            val cellSizeY = size.height / rows

            // Draw each winding arrow
            for (arrow in arrows) {
                if (arrow.isEscaping) continue

                val strokeColor = when {
                    arrow.isInvalid -> Color(0xFFEF4444)
                    arrow.isHinted -> Color(0xFFF59E0B)
                    else -> TextWhite
                }

                val path = Path()
                val pts = arrow.points
                if (pts.isNotEmpty()) {
                    val startX = pts[0].x * cellSizeX + cellSizeX / 2
                    val startY = pts[0].y * cellSizeY + cellSizeY / 2
                    path.moveTo(startX, startY)

                    for (i in 1 until pts.size) {
                        val px = pts[i].x * cellSizeX + cellSizeX / 2
                        val py = pts[i].y * cellSizeY + cellSizeY / 2
                        path.lineTo(px, py)
                    }

                    // Draw thick path line
                    drawPath(
                        path = path,
                        color = strokeColor,
                        style = Stroke(
                            width = 12f,
                            cap = StrokeCap.Square,
                            join = StrokeJoin.Miter
                        )
                    )

                    // Draw crisp arrowhead triangle at the head
                    val head = pts.last()
                    val hx = head.x * cellSizeX + cellSizeX / 2
                    val hy = head.y * cellSizeY + cellSizeY / 2
                    val arrowHeadPath = Path()

                    val arrowSize = 16f
                    val arrowLen = 22f

                    when (arrow.direction) {
                        Direction.UP -> {
                            arrowHeadPath.moveTo(hx, hy - arrowLen)
                            arrowHeadPath.lineTo(hx - arrowSize, hy + 4f)
                            arrowHeadPath.lineTo(hx + arrowSize, hy + 4f)
                            arrowHeadPath.close()
                        }
                        Direction.DOWN -> {
                            arrowHeadPath.moveTo(hx, hy + arrowLen)
                            arrowHeadPath.lineTo(hx - arrowSize, hy - 4f)
                            arrowHeadPath.lineTo(hx + arrowSize, hy - 4f)
                            arrowHeadPath.close()
                        }
                        Direction.LEFT -> {
                            arrowHeadPath.moveTo(hx - arrowLen, hy)
                            arrowHeadPath.lineTo(hx + 4f, hy - arrowSize)
                            arrowHeadPath.lineTo(hx + 4f, hy + arrowSize)
                            arrowHeadPath.close()
                        }
                        Direction.RIGHT -> {
                            arrowHeadPath.moveTo(hx + arrowLen, hy)
                            arrowHeadPath.lineTo(hx - 4f, hy - arrowSize)
                            arrowHeadPath.lineTo(hx - 4f, hy + arrowSize)
                            arrowHeadPath.close()
                        }
                    }

                    drawPath(
                        path = arrowHeadPath,
                        color = strokeColor
                    )
                }
            }
        }
    }
}
