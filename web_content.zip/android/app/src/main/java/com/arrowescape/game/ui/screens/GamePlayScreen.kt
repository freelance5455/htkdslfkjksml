package com.arrowescape.game.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.arrowescape.game.generator.DeterministicLevelGenerator
import com.arrowescape.game.model.Arrow
import com.arrowescape.game.model.Level
import com.arrowescape.game.solver.ArrowSolver
import com.arrowescape.game.ui.components.ArrowBoard
import com.arrowescape.game.ui.components.GameHud
import com.arrowescape.game.ui.theme.DarkCard
import com.arrowescape.game.ui.theme.PureBlack
import com.arrowescape.game.ui.theme.TextMuted
import com.arrowescape.game.ui.theme.TextWhite
import kotlinx.coroutines.delay

@Composable
fun GamePlayScreen(
    levelId: Int,
    onBackToTitle: () -> Unit,
    onNextLevel: (Int) -> Unit,
    onLevelCompleted: (levelId: Int, stars: Int, timeSec: Int, moves: Int) -> Unit
) {
    val level = remember(levelId) { DeterministicLevelGenerator.generateLevel(levelId) }
    var currentArrows by remember(levelId) { mutableStateOf(level.arrows) }
    var lives by remember(levelId) { mutableIntStateOf(3) }
    var moves by remember(levelId) { mutableIntStateOf(0) }
    var elapsedSeconds by remember(levelId) { mutableIntStateOf(0) }
    var isWon by remember(levelId) { mutableStateOf(false) }
    var isGameOver by remember(levelId) { mutableStateOf(false) }
    var isPaused by remember(levelId) { mutableStateOf(false) }

    // Timer loop
    LaunchedEffect(isWon, isGameOver, isPaused) {
        while (!isWon && !isGameOver && !isPaused) {
            delay(1000L)
            elapsedSeconds++
        }
    }

    fun handleArrowClick(arrow: Arrow) {
        if (isWon || isGameOver || isPaused) return

        val canEscape = ArrowSolver.isArrowPathClear(
            arrow = arrow,
            allArrows = currentArrows,
            gridRows = level.gridRows,
            gridCols = level.gridCols
        )

        moves++

        if (canEscape) {
            // Remove arrow immediately and update remaining counter
            val updated = currentArrows.filter { it.id != arrow.id }
            currentArrows = updated

            if (updated.isEmpty()) {
                isWon = true
                val stars = if (lives == 3) 3 else if (lives == 2) 2 else 1
                onLevelCompleted(levelId, stars, elapsedSeconds, moves)
            }
        } else {
            // Invalid move feedback: shake and reduce life
            currentArrows = currentArrows.map {
                if (it.id == arrow.id) it.copy(isInvalid = true) else it
            }
            lives--
            if (lives <= 0) {
                isGameOver = true
            }
        }
    }

    fun restartLevel() {
        currentArrows = level.arrows
        lives = 3
        moves = 0
        elapsedSeconds = 0
        isWon = false
        isGameOver = false
    }

    fun showHint() {
        val hint = ArrowSolver.getHintArrow(currentArrows, level.gridRows, level.gridCols)
        if (hint != null) {
            currentArrows = currentArrows.map {
                it.copy(isHinted = it.id == hint.id)
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(PureBlack)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            GameHud(
                levelId = levelId,
                lives = lives,
                moves = moves,
                elapsedSeconds = elapsedSeconds,
                remainingArrows = currentArrows.size,
                totalArrows = level.arrows.size,
                onPause = { isPaused = true },
                onRestart = { restartLevel() },
                onHint = { showHint() }
            )

            Box(
                modifier = Modifier
                    .weight(1f)
                    .padding(12.dp),
                contentAlignment = Alignment.Center
            ) {
                ArrowBoard(
                    rows = level.gridRows,
                    cols = level.gridCols,
                    arrows = currentArrows,
                    onArrowClick = { handleArrowClick(it) }
                )
            }

            Text(
                text = "${level.difficulty.name} · ${currentArrows.size} of ${level.arrows.size} Arrows Remaining",
                fontSize = 12.sp,
                color = TextMuted,
                modifier = Modifier.padding(bottom = 20.dp)
            )
        }

        // Victory Dialog with Continue button
        if (isWon) {
            AlertDialog(
                onDismissRequest = {},
                containerColor = DarkCard,
                title = { Text("LEVEL $levelId CLEARED!", color = TextWhite) },
                text = { Text("All ${level.arrows.size} arrows escaped in $moves moves ($elapsedSeconds seconds).", color = TextMuted) },
                confirmButton = {
                    Button(
                        onClick = { onNextLevel(levelId + 1) },
                        colors = ButtonDefaults.buttonColors(containerColor = TextWhite, contentColor = PureBlack)
                    ) {
                        Text("CONTINUE (LEVEL ${levelId + 1})")
                    }
                }
            )
        }

        // Game Over Dialog
        if (isGameOver) {
            AlertDialog(
                onDismissRequest = {},
                containerColor = DarkCard,
                title = { Text("OUT OF LIVES", color = TextWhite) },
                text = { Text("Hit blocked paths 3 times. Observe arrow directions carefully!", color = TextMuted) },
                confirmButton = {
                    Button(
                        onClick = { restartLevel() },
                        colors = ButtonDefaults.buttonColors(containerColor = TextWhite, contentColor = PureBlack)
                    ) {
                        Text("RETRY")
                    }
                }
            )
        }
    }
}
