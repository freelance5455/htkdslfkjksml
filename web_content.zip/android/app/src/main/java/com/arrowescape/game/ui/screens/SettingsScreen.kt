package com.arrowescape.game.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.arrowescape.game.model.AuthUser
import com.arrowescape.game.model.GameSettings
import com.arrowescape.game.ui.theme.BorderSubtle
import com.arrowescape.game.ui.theme.DarkCard
import com.arrowescape.game.ui.theme.PureBlack
import com.arrowescape.game.ui.theme.TextMuted
import com.arrowescape.game.ui.theme.TextWhite

@Composable
fun SettingsScreen(
    settings: GameSettings,
    authUser: AuthUser?,
    onToggleSound: (Boolean) -> Unit,
    onToggleHaptics: (Boolean) -> Unit,
    onGoogleSignIn: () -> Unit,
    onSignOut: () -> Unit,
    onBack: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(PureBlack)
            .padding(16.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextWhite
                    )
                }
                Text(
                    text = "SETTINGS & SYNC",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextWhite,
                    letterSpacing = 1.sp
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Sound Toggle
            SettingRow(
                title = "Sound Effects",
                subtitle = "Synthesized audio feedback",
                checked = settings.soundEnabled,
                onCheckedChange = onToggleSound
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Haptics Toggle
            SettingRow(
                title = "Haptic Feedback",
                subtitle = "Tactile impulse on collisions",
                checked = settings.hapticsEnabled,
                onCheckedChange = onToggleHaptics
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Firebase Cloud Synchronization Card
            Text(
                text = "FIREBASE CLOUD SYNC",
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                color = TextMuted,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkCard, RoundedCornerShape(8.dp))
                    .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp))
                    .padding(16.dp)
            ) {
                Column {
                    Text(
                        text = if (authUser?.isGuest == false) "Connected with Google" else "Playing in Guest Mode",
                        fontWeight = FontWeight.Bold,
                        color = TextWhite
                    )
                    Text(
                        text = if (authUser?.isGuest == false)
                            (authUser.email ?: authUser.displayName ?: "")
                        else
                            "Sync across Web & Android by signing in.",
                        fontSize = 13.sp,
                        color = TextMuted
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    if (authUser?.isGuest == false) {
                        Button(
                            onClick = onSignOut,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = DarkCard,
                                contentColor = TextWhite
                            ),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.border(1.dp, BorderSubtle, RoundedCornerShape(6.dp))
                        ) {
                            Text("SIGN OUT")
                        }
                    } else {
                        Button(
                            onClick = onGoogleSignIn,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = TextWhite,
                                contentColor = PureBlack
                            ),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text("CONTINUE WITH GOOGLE")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkCard, RoundedCornerShape(8.dp))
            .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp))
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(text = title, color = TextWhite, fontWeight = FontWeight.SemiBold)
            Text(text = subtitle, color = TextMuted, fontSize = 12.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = PureBlack,
                checkedTrackColor = TextWhite,
                uncheckedThumbColor = TextMuted,
                uncheckedTrackColor = DarkCard
            )
        )
    }
}
