package com.arrowescape.game.data.remote

import android.content.Context
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetCredentialResponse
import com.arrowescape.game.model.AuthUser
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await

class AuthManager(
    private val context: Context,
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    private val credentialManager = CredentialManager.create(context)

    private val _currentUser = MutableStateFlow<AuthUser?>(null)
    val currentUser: StateFlow<AuthUser?> = _currentUser.asStateFlow()

    init {
        val currentFirebaseUser = auth.currentUser
        if (currentFirebaseUser != null) {
            _currentUser.value = AuthUser(
                uid = currentFirebaseUser.uid,
                displayName = currentFirebaseUser.displayName,
                email = currentFirebaseUser.email,
                photoUrl = currentFirebaseUser.photoUrl?.toString(),
                isGuest = false
            )
        } else {
            setGuestUser()
        }
    }

    fun setGuestUser() {
        _currentUser.value = AuthUser(
            uid = "guest_android",
            displayName = "Guest Player",
            email = null,
            photoUrl = null,
            isGuest = true
        )
    }

    suspend fun signInWithGoogle(webClientId: String): Result<AuthUser> {
        return try {
            val googleIdOption = GetGoogleIdOption.Builder()
                .setFilterByAuthorizedAccounts(false)
                .setServerClientId(webClientId)
                .setAutoSelectEnabled(false)
                .build()

            val request = GetCredentialRequest.Builder()
                .addCredentialOption(googleIdOption)
                .build()

            val result: GetCredentialResponse = credentialManager.getCredential(
                request = request,
                context = context
            )

            val credential = result.credential
            if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
                val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
                val authResult = auth.signInWithCredential(authCredential).await()
                val firebaseUser = authResult.user

                if (firebaseUser != null) {
                    val user = AuthUser(
                        uid = firebaseUser.uid,
                        displayName = firebaseUser.displayName,
                        email = firebaseUser.email,
                        photoUrl = firebaseUser.photoUrl?.toString(),
                        isGuest = false
                    )
                    _currentUser.value = user
                    Result.success(user)
                } else {
                    Result.failure(Exception("Authentication returned null user"))
                }
            } else {
                Result.failure(Exception("Unrecognized credential type"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun signOut() {
        auth.signOut()
        setGuestUser()
    }
}
