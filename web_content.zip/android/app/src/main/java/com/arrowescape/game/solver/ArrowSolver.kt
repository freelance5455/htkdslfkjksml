package com.arrowescape.game.solver

import com.arrowescape.game.model.Arrow
import com.arrowescape.game.model.Direction
import com.arrowescape.game.model.Point
import kotlin.math.sign

object ArrowSolver {

    fun getArrowOccupiedPoints(arrow: Arrow): Set<String> {
        val occupied = mutableSetOf<String>()
        val pts = arrow.points
        if (pts.isEmpty()) {
            occupied.add("${arrow.col},${arrow.row}")
            return occupied
        }

        for (i in pts.indices) {
            occupied.add("${pts[i].x},${pts[i].y}")
            if (i < pts.size - 1) {
                val p1 = pts[i]
                val p2 = pts[i + 1]
                val dx = (p2.x - p1.x).sign
                val dy = (p2.y - p1.y).sign
                var currX = p1.x + dx
                var currY = p1.y + dy
                while ((dx != 0 && currX != p2.x) || (dy != 0 && currY != p2.y)) {
                    occupied.add("$currX,$currY")
                    currX += dx
                    currY += dy
                }
            }
        }
        return occupied
    }

    fun isArrowPathClear(
        arrow: Arrow,
        allArrows: List<Arrow>,
        gridRows: Int,
        gridCols: Int
    ): Boolean {
        val occupied = mutableSetOf<String>()
        for (other in allArrows) {
            if (other.id != arrow.id && !other.isEscaping) {
                occupied.addAll(getArrowOccupiedPoints(other))
            }
        }

        val head = if (arrow.points.isNotEmpty()) arrow.points.last() else Point(arrow.col, arrow.row)
        var x = head.x
        var y = head.y

        return when (arrow.direction) {
            Direction.UP -> {
                while (y > 0) {
                    y -= 1
                    if (occupied.contains("$x,$y")) return false
                }
                true
            }
            Direction.DOWN -> {
                while (y < gridRows - 1) {
                    y += 1
                    if (occupied.contains("$x,$y")) return false
                }
                true
            }
            Direction.LEFT -> {
                while (x > 0) {
                    x -= 1
                    if (occupied.contains("$x,$y")) return false
                }
                true
            }
            Direction.RIGHT -> {
                while (x < gridCols - 1) {
                    x += 1
                    if (occupied.contains("$x,$y")) return false
                }
                true
            }
        }
    }

    fun getEscapableArrows(
        arrows: List<Arrow>,
        gridRows: Int,
        gridCols: Int
    ): List<Arrow> {
        val active = arrows.filter { !it.isEscaping }
        return active.filter { isArrowPathClear(it, active, gridRows, gridCols) }
    }

    fun solveLevel(
        initialArrows: List<Arrow>,
        gridRows: Int,
        gridCols: Int
    ): List<String>? {
        var current = initialArrows.toList()
        val solution = mutableListOf<String>()

        while (current.isNotEmpty()) {
            val escapable = getEscapableArrows(current, gridRows, gridCols)
            if (escapable.isEmpty()) {
                return null // Deadlock
            }
            val chosen = escapable.first()
            solution.add(chosen.id)
            current = current.filter { it.id != chosen.id }
        }

        return solution
    }

    fun getHintArrow(
        arrows: List<Arrow>,
        gridRows: Int,
        gridCols: Int
    ): Arrow? {
        val escapable = getEscapableArrows(arrows, gridRows, gridCols)
        if (escapable.isEmpty()) return null

        for (candidate in escapable) {
            val remaining = arrows.filter { !it.isEscaping && it.id != candidate.id }
            if (solveLevel(remaining, gridRows, gridCols) != null) {
                return candidate
            }
        }
        return escapable.firstOrNull()
    }
}
