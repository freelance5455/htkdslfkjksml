package com.arrowescape.game

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.arrowescape.game.data.GameRepository
import com.arrowescape.game.data.local.GameDatabase
import com.arrowescape.game.data.local.UserPreferencesRepository
import com.arrowescape.game.data.remote.AuthManager
import com.arrowescape.game.ui.screens.GamePlayScreen
import com.arrowescape.game.ui.screens.LevelSelectScreen
import com.arrowescape.game.ui.screens.SettingsScreen
import com.arrowescape.game.ui.screens.TitleScreen
import com.arrowescape.game.ui.theme.ArrowEscapeTheme
import com.arrowescape.game.ui.theme.PureBlack
import kotlinx.coroutines.launch

enum class Screen {
    TITLE,
    GAME,
    LEVEL_SELECT,
    SETTINGS
}

class MainActivity : ComponentActivity() {

    private lateinit var repository: GameRepository
    private lateinit var authManager: AuthManager
    private lateinit var preferencesRepo: UserPreferencesRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val db = GameDatabase.getDatabase(this)
        repository = GameRepository(db.progressDao())
        authManager = AuthManager(this)
        preferencesRepo = UserPreferencesRepository(this)

        setContent {
            ArrowEscapeTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = PureBlack
                ) {
                    AppNavigation(
                        repository = repository,
                        authManager = authManager,
                        preferencesRepo = preferencesRepo
                    )
                }
            }
        }
    }
}

@Composable
fun AppNavigation(
    repository: GameRepository,
    authManager: AuthManager,
    preferencesRepo: UserPreferencesRepository
) {
    var currentScreen by remember { mutableStateOf(Screen.TITLE) }
    var selectedLevelId by remember { mutableIntStateOf(1) }

    val userProgress by repository.userProgressFlow.collectAsState(initial = com.arrowescape.game.model.UserProgress())
    val authUser by authManager.currentUser.collectAsState()
    val settings by preferencesRepo.settingsFlow.collectAsState(initial = com.arrowescape.game.model.GameSettings())
    val scope = rememberCoroutineScope()

    when (currentScreen) {
        Screen.TITLE -> {
            TitleScreen(
                currentLevel = userProgress.currentLevel,
                totalStars = userProgress.totalStars,
                authUser = authUser,
                onPlay = {
                    selectedLevelId = userProgress.currentLevel
                    currentScreen = Screen.GAME
                },
                onLevelSelect = { currentScreen = Screen.LEVEL_SELECT },
                onSettings = { currentScreen = Screen.SETTINGS },
                onGoogleSignIn = {
                    scope.launch {
                        authManager.signInWithGoogle("WEB_CLIENT_ID")
                    }
                },
                onSignOut = { authManager.signOut() }
            )
        }
        Screen.GAME -> {
            GamePlayScreen(
                levelId = selectedLevelId,
                onBackToTitle = { currentScreen = Screen.TITLE },
                onNextLevel = { nextId ->
                    selectedLevelId = nextId
                },
                onLevelCompleted = { lvlId, stars, time, moves ->
                    scope.launch {
                        repository.saveLevelCompletion(lvlId, stars, time, moves, authUser?.uid)
                    }
                }
            )
        }
        Screen.LEVEL_SELECT -> {
            LevelSelectScreen(
                currentUnlockedLevel = userProgress.currentLevel,
                completedLevels = userProgress.completedLevels,
                onSelectLevel = { lvlId ->
                    selectedLevelId = lvlId
                    currentScreen = Screen.GAME
                },
                onBack = { currentScreen = Screen.TITLE }
            )
        }
        Screen.SETTINGS -> {
            SettingsScreen(
                settings = settings,
                authUser = authUser,
                onToggleSound = { scope.launch { preferencesRepo.updateSound(it) } },
                onToggleHaptics = { scope.launch { preferencesRepo.updateHaptics(it) } },
                onGoogleSignIn = {
                    scope.launch {
                        authManager.signInWithGoogle("WEB_CLIENT_ID")
                    }
                },
                onSignOut = { authManager.signOut() },
                onBack = { currentScreen = Screen.TITLE }
            )
        }
    }
}
