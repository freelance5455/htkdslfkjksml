package com.arrowescape.game.model

enum class Difficulty {
    BEGINNER,
    INTERMEDIATE,
    ADVANCED,
    MASTER,
    ULTIMATE
}

data class Level(
    val id: Int,
    val gridRows: Int,
    val gridCols: Int,
    val arrows: List<Arrow>,
    val difficulty: Difficulty,
    val optimalMoves: Int,
    val parTimeSec: Int
)
