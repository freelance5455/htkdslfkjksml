package com.arrowescape.game.generator

import com.arrowescape.game.model.Arrow
import com.arrowescape.game.model.Difficulty
import com.arrowescape.game.model.Direction
import com.arrowescape.game.model.Level
import com.arrowescape.game.model.Point
import com.arrowescape.game.solver.ArrowSolver

class Mulberry32Rng(seed: Long) {
    private var state: Long = seed and 0xFFFFFFFFL

    fun next(): Float {
        state = (state + 0x6D2B79F5L) and 0xFFFFFFFFL
        var t = state xor (state ushr 15)
        t = (t * (1L or state)) and 0xFFFFFFFFL
        t = (t xor (t + ((t xor (t ushr 7)) * 61L))) and 0xFFFFFFFFL
        val res = (t xor (t ushr 14)) and 0xFFFFFFFFL
        return (res.toDouble() / 4294967296.0).toFloat()
    }
}

object DeterministicLevelGenerator {

    fun getDifficultyForLevel(levelId: Int): Difficulty = when {
        levelId <= 150 -> Difficulty.BEGINNER
        levelId <= 400 -> Difficulty.INTERMEDIATE
        levelId <= 700 -> Difficulty.ADVANCED
        levelId <= 900 -> Difficulty.MASTER
        else -> Difficulty.ULTIMATE
    }

    private val DIRECTIONS = listOf(Direction.UP, Direction.DOWN, Direction.LEFT, Direction.RIGHT)

    private fun getDirVector(dir: Direction): Pair<Int, Int> = when (dir) {
        Direction.UP -> Pair(0, -1)
        Direction.DOWN -> Pair(0, 1)
        Direction.LEFT -> Pair(-1, 0)
        Direction.RIGHT -> Pair(1, 0)
    }

    private fun getOppositeDir(dir: Direction): Direction = when (dir) {
        Direction.UP -> Direction.DOWN
        Direction.DOWN -> Direction.UP
        Direction.LEFT -> Direction.RIGHT
        Direction.RIGHT -> Direction.LEFT
    }

    private fun getPerpendicularDirs(dir: Direction): List<Direction> = when (dir) {
        Direction.UP, Direction.DOWN -> listOf(Direction.LEFT, Direction.RIGHT)
        Direction.LEFT, Direction.RIGHT -> listOf(Direction.UP, Direction.DOWN)
    }

    private fun isRayClear(
        hx: Int,
        hy: Int,
        dir: Direction,
        occupied: Array<BooleanArray>,
        rows: Int,
        cols: Int
    ): Boolean {
        val (dx, dy) = getDirVector(dir)
        var x = hx + dx
        var y = hy + dy
        while (x in 0 until cols && y in 0 until rows) {
            if (occupied[y][x]) return false
            x += dx
            y += dy
        }
        return true
    }

    fun generateLevel(levelId: Int): Level {
        val clampedId = levelId.coerceIn(1, 1000)
        val difficulty = getDifficultyForLevel(clampedId)

        var gridCols = 10
        var gridRows = 12
        var targetArrows = 16
        var parTimeSec = 120

        if (clampedId == 1) {
            targetArrows = 16
            gridCols = 10
            gridRows = 12
            parTimeSec = 120
        } else if (clampedId <= 10) {
            val ratio = (clampedId - 2) / 8.0
            targetArrows = (20 + ratio * 20).toInt()
            gridCols = (11 + ratio * 3).toInt()
            gridRows = (13 + ratio * 3).toInt()
            parTimeSec = 150
        } else if (clampedId <= 50) {
            val ratio = (clampedId - 11) / 39.0
            targetArrows = (30 + ratio * 30).toInt()
            gridCols = (14 + ratio * 4).toInt()
            gridRows = (16 + ratio * 5).toInt()
            parTimeSec = 180
        } else if (clampedId <= 100) {
            val ratio = (clampedId - 51) / 49.0
            targetArrows = (50 + ratio * 30).toInt()
            gridCols = (18 + ratio * 4).toInt()
            gridRows = (21 + ratio * 5).toInt()
            parTimeSec = 210
        } else if (clampedId <= 500) {
            val ratio = (clampedId - 101) / 399.0
            targetArrows = (70 + ratio * 50).toInt()
            gridCols = (22 + ratio * 5).toInt()
            gridRows = (26 + ratio * 6).toInt()
            parTimeSec = 260
        } else {
            val ratio = (clampedId - 501) / 499.0
            targetArrows = (100 + ratio * 100).toInt()
            gridCols = (27 + ratio * 6).toInt()
            gridRows = (32 + ratio * 8).toInt()
            parTimeSec = 300
        }

        var attempt = 0
        var finalArrows: List<Arrow> = emptyList()
        var solution: List<String>? = null

        while (attempt < 12) {
            val seed = ((clampedId.toLong() * 10007L + attempt.toLong() * 7919L + 42L) and 0xFFFFFFFFL)
            val rng = Mulberry32Rng(seed)
            val generated = buildReverseWindingMaze(gridRows, gridCols, targetArrows, rng)

            if (generated.isNotEmpty()) {
                solution = ArrowSolver.solveLevel(generated, gridRows, gridCols)
                if (solution != null && solution.size == generated.size) {
                    finalArrows = generated
                    break
                }
            }
            attempt++
        }

        if (finalArrows.isEmpty()) {
            finalArrows = buildFallbackSolvableLevel(gridRows, gridCols)
            solution = ArrowSolver.solveLevel(finalArrows, gridRows, gridCols)
        }

        val optimalMoves = solution?.size ?: finalArrows.size

        return Level(
            id = clampedId,
            gridRows = gridRows,
            gridCols = gridCols,
            arrows = finalArrows,
            difficulty = difficulty,
            optimalMoves = optimalMoves,
            parTimeSec = parTimeSec
        )
    }

    private fun buildReverseWindingMaze(
        rows: Int,
        cols: Int,
        targetCount: Int,
        rng: Mulberry32Rng
    ): List<Arrow> {
        val arrows = mutableListOf<Arrow>()
        val occupied = Array(rows) { BooleanArray(cols) { false } }
        var arrowId = 1
        var failures = 0

        while (arrows.size < targetCount && failures < 120) {
            val emptyCells = mutableListOf<Pair<Int, Int>>()
            for (y in 0 until rows) {
                for (x in 0 until cols) {
                    if (!occupied[y][x]) emptyCells.add(Pair(x, y))
                }
            }

            if (emptyCells.isEmpty()) break

            val idx = (rng.next() * emptyCells.size).toInt().coerceIn(0, emptyCells.size - 1)
            val (hx, hy) = emptyCells[idx]

            val validDirs = mutableListOf<Direction>()
            for (d in DIRECTIONS) {
                if (isRayClear(hx, hy, d, occupied, rows, cols)) {
                    validDirs.add(d)
                }
            }

            if (validDirs.isEmpty()) {
                failures++
                continue
            }

            val chosenDir = validDirs[(rng.next() * validDirs.size).toInt().coerceIn(0, validDirs.size - 1)]
            val body = mutableListOf(Point(hx, hy))
            var currX = hx
            var currY = hy
            var currentBackDir = getOppositeDir(chosenDir)

            val maxBends = if (rng.next() < 0.3f) 1 else if (rng.next() < 0.7f) 2 else 3
            var bends = 0

            while (bends < maxBends) {
                val segLength = 1 + (rng.next() * 3).toInt()
                val (dx, dy) = getDirVector(currentBackDir)
                var stepsTaken = 0

                for (s in 0 until segLength) {
                    val nextX = currX + dx
                    val nextY = currY + dy
                    if (nextX in 0 until cols && nextY in 0 until rows &&
                        !occupied[nextY][nextX] && body.none { it.x == nextX && it.y == nextY }
                    ) {
                        currX = nextX
                        currY = nextY
                        body.add(Point(currX, currY))
                        stepsTaken++
                    } else {
                        break
                    }
                }

                if (stepsTaken == 0) break

                val turns = getPerpendicularDirs(currentBackDir)
                currentBackDir = turns[(rng.next() * turns.size).toInt().coerceIn(0, turns.size - 1)]
                bends++
            }

            if (body.size >= 2) {
                val points = body.reversed()
                val head = points.last()

                for (p in points) {
                    occupied[p.y][p.x] = true
                }

                arrows.add(
                    Arrow(
                        id = "arrow_${arrowId++}",
                        points = points,
                        row = head.y,
                        col = head.x,
                        direction = chosenDir
                    )
                )
                failures = 0
            } else {
                failures++
            }
        }

        return arrows
    }

    private fun buildFallbackSolvableLevel(rows: Int, cols: Int): List<Arrow> {
        val arrows = mutableListOf<Arrow>()
        var id = 1

        for (x in 0 until cols step 2) {
            arrows.add(
                Arrow(
                    id = "fb_${id++}",
                    points = listOf(Point(x, 1), Point(x, 0)),
                    row = 0,
                    col = x,
                    direction = Direction.UP
                )
            )
        }
        for (x in 1 until cols step 2) {
            arrows.add(
                Arrow(
                    id = "fb_${id++}",
                    points = listOf(Point(x, rows - 2), Point(x, rows - 1)),
                    row = rows - 1,
                    col = x,
                    direction = Direction.DOWN
                )
            )
        }
        for (y in 1 until rows - 1 step 2) {
            arrows.add(
                Arrow(
                    id = "fb_${id++}",
                    points = listOf(Point(1, y), Point(0, y)),
                    row = y,
                    col = 0,
                    direction = Direction.LEFT
                )
            )
        }

        return arrows
    }
}
