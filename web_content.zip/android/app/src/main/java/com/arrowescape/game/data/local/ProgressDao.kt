package com.arrowescape.game.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ProgressDao {

    @Query("SELECT * FROM level_progress")
    fun getAllProgress(): Flow<List<ProgressEntity>>

    @Query("SELECT * FROM level_progress WHERE levelId = :levelId")
    suspend fun getProgressForLevel(levelId: Int): ProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProgress(progress: ProgressEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(progressList: List<ProgressEntity>)

    @Query("SELECT * FROM user_meta WHERE id = 'main'")
    fun getUserMeta(): Flow<UserMetaEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveUserMeta(meta: UserMetaEntity)

    @Query("DELETE FROM level_progress")
    suspend fun clearAll()
}
