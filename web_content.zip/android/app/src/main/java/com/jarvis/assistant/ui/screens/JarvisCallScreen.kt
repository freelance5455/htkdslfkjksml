package com.jarvis.assistant.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.jarvis.assistant.ui.components.ArcReactorMicButton
import com.jarvis.assistant.ui.components.WaveformVisualizer
import com.jarvis.assistant.ui.theme.JarvisAccentRed
import com.jarvis.assistant.ui.theme.JarvisBackground
import com.jarvis.assistant.ui.theme.JarvisCyan
import com.jarvis.assistant.ui.theme.JarvisGreen
import com.jarvis.assistant.ui.theme.JarvisTextDim
import com.jarvis.assistant.ui.theme.JarvisTextPrimary
import kotlinx.coroutines.delay
import java.util.Locale

enum class CallState {
    INCOMING,
    ACTIVE,
    ENDED
}

enum class VoiceLoopState {
    GREETING,
    LISTENING,
    PROCESSING,
    SPEAKING
}

/**
 * Native Android Jetpack Compose in-app voice call experience for JARVIS.
 * 
 * Features:
 * - Two-way hands-free voice loop using Android TextToSpeech & SpeechRecognizer
 * - Automatic loop resumption after JARVIS speaks
 * - Zero paid APIs or external keys (100% on-device architecture)
 * - Mute/Unmute, Speaker/Earpiece, and End Call controls
 * - Runtime RECORD_AUDIO permission handling and graceful fallbacks
 */
@Composable
fun JarvisCallScreen(
    onEndCall: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val mainHandler = remember { Handler(Looper.getMainLooper()) }

    var callState by remember { mutableStateOf(CallState.INCOMING) }
    var voiceLoopState by remember { mutableStateOf(VoiceLoopState.GREETING) }
    var isMuted by remember { mutableStateOf(false) }
    var isSpeakerOn by remember { mutableStateOf(true) }
    var durationSeconds by remember { mutableIntStateOf(0) }

    // Speech & Text State
    var recognizedUserSpeech by remember { mutableStateOf("") }
    var jarvisSpokenResponse by remember {
        mutableStateOf("Voice connection initializing...")
    }
    var speechRecognizerAvailable by remember { mutableStateOf(true) }
    var permissionGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }
    var statusFeedbackMessage by remember { mutableStateOf<String?>(null) }

    // Native Android Engines
    var ttsInstance by remember { mutableStateOf<TextToSpeech?>(null) }
    var speechRecognizerInstance by remember { mutableStateOf<SpeechRecognizer?>(null) }
    var isTtsReady by remember { mutableStateOf(false) }

    // Permission Launcher for RECORD_AUDIO
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        permissionGranted = isGranted
        if (!isGranted) {
            statusFeedbackMessage = "Microphone permission required for hands-free speech recognition."
        }
    }

    // Helper: Speak response via native Android TTS and automatically listen again
    fun speakAndResumeListening(text: String, isExit: Boolean = false) {
        jarvisSpokenResponse = text
        voiceLoopState = VoiceLoopState.SPEAKING

        if (isTtsReady && ttsInstance != null) {
            val params = Bundle()
            params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, if (isExit) "EXIT_UTTERANCE" else "JARVIS_LOOP")
            ttsInstance?.speak(text, TextToSpeech.QUEUE_FLUSH, params, if (isExit) "EXIT_UTTERANCE" else "JARVIS_LOOP")
        } else {
            // Fallback timer if TTS engine is slow initializing
            mainHandler.postDelayed({
                if (callState == CallState.ACTIVE && !isMuted) {
                    voiceLoopState = VoiceLoopState.LISTENING
                }
            }, 3000)
        }
    }

    // Helper: Start Android SpeechRecognizer hands-free
    fun triggerListening() {
        if (callState != CallState.ACTIVE || isMuted) return

        if (!permissionGranted) {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            return
        }

        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            speechRecognizerAvailable = false
            statusFeedbackMessage = "On-device SpeechRecognizer is not available on this Android device."
            return
        }

        mainHandler.post {
            try {
                speechRecognizerInstance?.cancel()
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                }
                voiceLoopState = VoiceLoopState.LISTENING
                speechRecognizerInstance?.startListening(intent)
            } catch (e: Exception) {
                statusFeedbackMessage = "Failed to launch voice recognizer: ${e.localizedMessage}"
            }
        }
    }

    // On-Device Natural Conversation Brain (Zero Paid APIs)
    fun processUserSpeech(userSpeech: String) {
        val query = userSpeech.lowercase().trim()
        recognizedUserSpeech = userSpeech
        voiceLoopState = VoiceLoopState.PROCESSING

        val (replyText, isExit) = when {
            query.contains("bye") || query.contains("hang up") || query.contains("disconnect") || query.contains("end call") -> {
                Pair("Understood, Sir. Terminating secure voice session. Good day.", true)
            }
            query.contains("briefing") || query.contains("morning") || query.contains("agenda") || query.contains("schedule") -> {
                Pair("Morning briefing report: You have three schedule milestones starting with Core Systems Review at 9:00 AM. Weather is sunny at 72 degrees Fahrenheit. All VIP communication filters are active.", false)
            }
            query.contains("status") || query.contains("system") || query.contains("diagnostic") || query.contains("health") -> {
                Pair("All fourteen subsystems are operating with optimal precision. Latency is twelve milliseconds, internal memory footprint is nominal, and encrypted audio pipeline is established.", false)
            }
            query.contains("weather") || query.contains("forecast") || query.contains("temperature") -> {
                Pair("Atmospheric sensors record 72 degrees Fahrenheit with clear skies, humidity at 48 percent, and calm northwest winds. Ideal conditions.", false)
            }
            query.contains("notification") || query.contains("message") || query.contains("alert") -> {
                Pair("Notification triage active: zero unread VIP alerts pending. Seven non-critical alerts have been quietly categorized.", false)
            }
            query.contains("who are you") || query.contains("jarvis") || query.contains("what can you do") -> {
                Pair("I am JARVIS, your on-device personal artificial intelligence assistant. I manage your briefings, monitor critical communications, and assist your daily workflow entirely on device.", false)
            }
            query.contains("thank") || query.contains("good job") -> {
                Pair("Always at your service, Sir. Is there anything further I may coordinate for you?", false)
            }
            else -> {
                Pair("Directive received regarding '$userSpeech', Sir. Local parameters are calibrated. How shall we proceed?", false)
            }
        }

        speakAndResumeListening(replyText, isExit)
    }

    // Initialize Android TextToSpeech and SpeechRecognizer
    DisposableEffect(Unit) {
        val tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsInstance?.language = Locale.US
                isTtsReady = true

                ttsInstance?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        voiceLoopState = VoiceLoopState.SPEAKING
                    }

                    override fun onDone(utteranceId: String?) {
                        mainHandler.post {
                            if (utteranceId == "EXIT_UTTERANCE") {
                                onEndCall()
                            } else if (callState == CallState.ACTIVE && !isMuted) {
                                // CRITICAL: Automatically listen again so conversation continues hands-free
                                triggerListening()
                            }
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        mainHandler.post {
                            if (callState == CallState.ACTIVE && !isMuted) {
                                triggerListening()
                            }
                        }
                    }
                })
            }
        }
        ttsInstance = tts

        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    voiceLoopState = VoiceLoopState.LISTENING
                }

                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {
                    voiceLoopState = VoiceLoopState.PROCESSING
                }

                override fun onError(error: Int) {
                    mainHandler.post {
                        if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                            if (callState == CallState.ACTIVE && !isMuted) {
                                triggerListening()
                            }
                        } else if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    }
                }

                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = matches?.firstOrNull()
                    if (!text.isNullOrBlank()) {
                        processUserSpeech(text)
                    } else if (callState == CallState.ACTIVE && !isMuted) {
                        triggerListening()
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!partial.isNullOrBlank()) {
                        recognizedUserSpeech = partial
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            speechRecognizerInstance = recognizer
        } else {
            speechRecognizerAvailable = false
        }

        onDispose {
            tts.stop()
            tts.shutdown()
            speechRecognizerInstance?.destroy()
        }
    }

    // Android AudioManager & Audio Routing
    DisposableEffect(callState) {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        if (callState == CallState.ACTIVE) {
            audioManager?.mode = AudioManager.MODE_IN_COMMUNICATION
            audioManager?.isSpeakerphoneOn = isSpeakerOn
        }
        onDispose {
            audioManager?.mode = AudioManager.MODE_NORMAL
        }
    }

    // Active session duration timer
    LaunchedEffect(callState) {
        if (callState == CallState.ACTIVE) {
            while (true) {
                delay(1000)
                durationSeconds++
            }
        }
    }

    // Incoming Call Vibrator Alert
    DisposableEffect(callState) {
        var vibrator: Vibrator? = null
        if (callState == CallState.INCOMING) {
            vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }

            val pattern = longArrayOf(0, 400, 800, 400, 800)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(pattern, 0)
            }
        }
        onDispose {
            vibrator?.cancel()
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "ring_anim")
    val ringScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ring_scale"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF03060B), JarvisBackground, Color(0xFF03060B))
                )
            )
            .padding(horizontal = 24.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top Header Information
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(top = 10.dp)
        ) {
            // Anti-Cellular Disclaimer Badge
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF131B2E))
                    .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(16.dp))
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Shield, contentDescription = null, tint = JarvisCyan, modifier = Modifier.size(12.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "IN-APP AI VOICE SESSION • NOT A CELLULAR CALL",
                    color = Color(0xFF94A3B8),
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "JARVIS",
                color = JarvisTextPrimary,
                fontSize = 40.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 5.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            if (callState == CallState.INCOMING) {
                Text(
                    text = "INCOMING VOICE CONNECTION",
                    color = JarvisCyan,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 2.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Hands-Free Assistant Trigger • Direct Audio",
                    color = JarvisTextDim,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            } else {
                Text(
                    text = "ACTIVE VOICE CONVERSATION",
                    color = JarvisCyan,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 2.sp
                )
                val timerString = String.format("%02d:%02d", durationSeconds / 60, durationSeconds % 60)
                val loopLabel = when {
                    isMuted -> "MIC MUTED"
                    voiceLoopState == VoiceLoopState.LISTENING -> "LISTENING TO YOU..."
                    voiceLoopState == VoiceLoopState.SPEAKING -> "JARVIS SPEAKING"
                    voiceLoopState == VoiceLoopState.PROCESSING -> "PROCESSING..."
                    else -> "INITIALIZING..."
                }
                Text(
                    text = "$timerString • $loopLabel",
                    color = if (isMuted) JarvisAccentRed else JarvisGreen,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Center Arc Reactor & Conversation Card
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.Center
        ) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(200.dp)) {
                if (callState == CallState.INCOMING) {
                    Box(
                        modifier = Modifier
                            .size(180.dp)
                            .scale(ringScale)
                            .clip(CircleShape)
                            .border(2.dp, JarvisCyan.copy(alpha = 0.4f), CircleShape)
                    )
                }

                ArcReactorMicButton(
                    isListening = callState == CallState.ACTIVE && !isMuted && voiceLoopState == VoiceLoopState.LISTENING,
                    onClick = {},
                    size = 160.dp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (callState == CallState.ACTIVE) {
                WaveformVisualizer(
                    isActive = !isMuted && (voiceLoopState == VoiceLoopState.SPEAKING || voiceLoopState == VoiceLoopState.LISTENING),
                    modifier = Modifier.padding(horizontal = 20.dp),
                    height = 32.dp
                )

                Spacer(modifier = Modifier.height(12.dp))

                // JARVIS Voice Transcript Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.95f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF131B2E))
                        .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "JARVIS SPEECH",
                                color = JarvisCyan,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = jarvisSpokenResponse,
                            color = JarvisTextPrimary,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )

                        if (recognizedUserSpeech.isNotBlank()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "You said: \"$recognizedUserSpeech\"",
                                color = JarvisGreen,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                // Fallback / Permission Notice Banner if SpeechRecognizer unavailable
                if (!speechRecognizerAvailable || statusFeedbackMessage != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth(0.95f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF261C14))
                            .border(1.dp, Color(0xFFF59E0B).copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = statusFeedbackMessage ?: "Speech recognition unavailable. Using TTS fallback mode.",
                            color = Color(0xFFFDE68A),
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            } else {
                Text(
                    text = "Scheduled morning briefing ready for hands-free delivery.",
                    color = JarvisTextDim,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Bottom Controls
        if (callState == CallState.INCOMING) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    FloatingActionButton(
                        onClick = onEndCall,
                        containerColor = JarvisAccentRed,
                        contentColor = Color.White,
                        shape = CircleShape,
                        modifier = Modifier.size(68.dp),
                        elevation = FloatingActionButtonDefaults.elevation(8.dp)
                    ) {
                        Icon(Icons.Default.CallEnd, contentDescription = "Decline", modifier = Modifier.size(28.dp))
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("DECLINE", color = JarvisAccentRed, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    FloatingActionButton(
                        onClick = {
                            callState = CallState.ACTIVE
                            speakAndResumeListening("Voice link established. Good day, Sir. JARVIS on-device voice assistant is online and subsystems are nominal. What can I do for you?")
                        },
                        containerColor = JarvisGreen,
                        contentColor = Color(0xFF0A0E17),
                        shape = CircleShape,
                        modifier = Modifier.size(68.dp),
                        elevation = FloatingActionButtonDefaults.elevation(8.dp)
                    ) {
                        Icon(Icons.Default.Phone, contentDescription = "Answer", modifier = Modifier.size(28.dp))
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("ANSWER", color = JarvisGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }
        } else {
            // Active Voice Controls
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Mute
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    FloatingActionButton(
                        onClick = {
                            isMuted = !isMuted
                            if (isMuted) {
                                speechRecognizerInstance?.cancel()
                            } else {
                                triggerListening()
                            }
                        },
                        containerColor = Color(0xFF1E293B),
                        contentColor = if (isMuted) JarvisAccentRed else JarvisTextPrimary,
                        shape = CircleShape,
                        modifier = Modifier.size(54.dp)
                    ) {
                        Icon(if (isMuted) Icons.Default.MicOff else Icons.Default.Mic, contentDescription = "Mute")
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(if (isMuted) "MUTED" else "MUTE", color = JarvisTextDim, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }

                // End Call
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    FloatingActionButton(
                        onClick = {
                            ttsInstance?.stop()
                            speechRecognizerInstance?.cancel()
                            onEndCall()
                        },
                        containerColor = JarvisAccentRed,
                        contentColor = Color.White,
                        shape = CircleShape,
                        modifier = Modifier.size(68.dp),
                        elevation = FloatingActionButtonDefaults.elevation(8.dp)
                    ) {
                        Icon(Icons.Default.CallEnd, contentDescription = "End Call", modifier = Modifier.size(28.dp))
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("END CALL", color = JarvisAccentRed, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }

                // Speaker
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    FloatingActionButton(
                        onClick = {
                            isSpeakerOn = !isSpeakerOn
                            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                            audioManager?.isSpeakerphoneOn = isSpeakerOn
                        },
                        containerColor = Color(0xFF1E293B),
                        contentColor = if (isSpeakerOn) JarvisCyan else JarvisTextDim,
                        shape = CircleShape,
                        modifier = Modifier.size(54.dp)
                    ) {
                        Icon(if (isSpeakerOn) Icons.Default.VolumeUp else Icons.Default.VolumeOff, contentDescription = "Speaker")
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(if (isSpeakerOn) "SPEAKER" else "EARPIECE", color = JarvisTextDim, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}
