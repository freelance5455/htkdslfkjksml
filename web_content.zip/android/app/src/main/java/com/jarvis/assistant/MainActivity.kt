package com.jarvis.assistant

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.jarvis.assistant.data.model.JarvisSettings
import com.jarvis.assistant.receiver.MorningBriefingScheduler
import com.jarvis.assistant.ui.screens.JarvisCallScreen
import com.jarvis.assistant.ui.screens.MainScreen
import com.jarvis.assistant.ui.screens.SettingsScreen
import com.jarvis.assistant.ui.theme.JarvisBackground
import com.jarvis.assistant.ui.theme.JarvisTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as JarvisApplication
        val preferencesManager = app.preferencesManager

        setContent {
            JarvisTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = JarvisBackground
                ) {
                    val navController = rememberNavController()
                    val currentSettings by preferencesManager.settingsFlow.collectAsState(
                        initial = JarvisSettings()
                    )

                    // Ensure AlarmManager schedule is maintained on launch
                    LaunchedEffect(currentSettings.morningBriefingTime, currentSettings.isDailyBriefingEnabled) {
                        MorningBriefingScheduler.scheduleMorningBriefing(
                            this@MainActivity,
                            currentSettings.morningBriefingTime,
                            currentSettings.isDailyBriefingEnabled
                        )
                    }

                    // Check if launched by incoming morning briefing or alarm intent
                    LaunchedEffect(intent) {
                        val navigateTo = intent?.getStringExtra("EXTRA_NAVIGATE_TO")
                        if (navigateTo == "call") {
                            navController.navigate("call") {
                                launchSingleTop = true
                            }
                        }
                    }

                    NavHost(
                        navController = navController,
                        startDestination = "main"
                    ) {
                        composable("main") {
                            MainScreen(
                                onNavigateToSettings = {
                                    navController.navigate("settings")
                                },
                                onTestCallTrigger = {
                                    navController.navigate("call")
                                }
                            )
                        }

                        composable("settings") {
                            SettingsScreen(
                                currentSettings = currentSettings,
                                preferencesManager = preferencesManager,
                                onNavigateBack = {
                                    navController.popBackStack()
                                },
                                onTestCallClick = {
                                    navController.navigate("call")
                                },
                                onTestMorningTriggerClick = {
                                    MorningBriefingScheduler.triggerImmediateTest(this@MainActivity)
                                },
                                onTestNotificationAccessClick = {
                                    try {
                                        val notifIntent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                                        startActivity(notifIntent)
                                    } catch (e: Exception) {
                                        Toast.makeText(
                                            this@MainActivity,
                                            "Notification listener settings opened",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                }
                            )
                        }

                        composable("call") {
                            JarvisCallScreen(
                                onEndCall = {
                                    navController.popBackStack()
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
    }
}
