package com.jarvis.assistant.receiver

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.jarvis.assistant.JarvisApplication
import com.jarvis.assistant.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch

/**
 * BroadcastReceiver triggered by AlarmManager at the user's configured
 * morning briefing time (e.g. 07:00 AM) or upon device reboot.
 */
class MorningBriefingReceiver : BroadcastReceiver() {

    companion object {
        const val CHANNEL_MORNING_CALL = "jarvis_morning_call_channel"
        const val NOTIFICATION_ID_MORNING = 1001
        private const val TAG = "MorningReceiver"
    }

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action
        Log.d(TAG, "Received broadcast action: $action")

        val app = context.applicationContext as? JarvisApplication
        val preferencesManager = app?.preferencesManager

        when (action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED -> {
                // Restore scheduled AlarmManager trigger after device reboot or time change
                CoroutineScope(Dispatchers.IO).launch {
                    val settings = preferencesManager?.settingsFlow?.firstOrNull()
                    val time = settings?.morningBriefingTime ?: "07:00"
                    val isEnabled = settings?.isDailyBriefingEnabled ?: true
                    Log.d(TAG, "Device restarted/time changed. Restoring alarm schedule: $time (enabled=$isEnabled)")
                    MorningBriefingScheduler.scheduleMorningBriefing(context, time, isEnabled)
                }
            }

            MorningBriefingScheduler.ACTION_MORNING_BRIEFING,
            MorningBriefingScheduler.ACTION_TEST_MORNING_TRIGGER -> {
                val isTest = action == MorningBriefingScheduler.ACTION_TEST_MORNING_TRIGGER

                CoroutineScope(Dispatchers.IO).launch {
                    val settings = preferencesManager?.settingsFlow?.firstOrNull()
                    val isEnabled = settings?.isDailyBriefingEnabled ?: true
                    val time = settings?.morningBriefingTime ?: "07:00"

                    // If it is the scheduled daily briefing and user disabled it, do not trigger!
                    if (!isTest && !isEnabled) {
                        Log.d(TAG, "Daily Briefing is disabled in user settings. Suppressing scheduled trigger.")
                        return@launch
                    }

                    // Schedule next day's alarm
                    if (!isTest && isEnabled) {
                        MorningBriefingScheduler.scheduleMorningBriefing(context, time, true)
                    }

                    // Launch the in-app incoming-call-style experience
                    launchMorningCallExperience(context)
                }
            }
        }
    }

    private fun launchMorningCallExperience(context: Context) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // Create high-importance incoming call channel with alarm ringtone
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ringtoneUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            val audioAttributes = AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_ALARM)
                .build()

            val channel = NotificationChannel(
                CHANNEL_MORNING_CALL,
                "JARVIS Morning Call",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Incoming voice session trigger for scheduled JARVIS morning briefings"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 250, 500, 250, 500)
                setSound(ringtoneUri, audioAttributes)
                lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
            }
            notificationManager.createNotificationChannel(channel)
        }

        // Full-screen incoming call intent to display JarvisCallScreen in MainActivity
        val fullScreenIntent = Intent(context, MainActivity::class.java).apply {
            action = Intent.ACTION_MAIN
            addCategory(Intent.CATEGORY_LAUNCHER)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("EXTRA_NAVIGATE_TO", "call")
            putExtra("EXTRA_IS_MORNING_BRIEFING", true)
        }

        val fullScreenPendingIntent = PendingIntent.getActivity(
            context,
            2001,
            fullScreenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Action: Answer directly into voice conversation
        val answerIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("EXTRA_NAVIGATE_TO", "call")
            putExtra("EXTRA_AUTO_ANSWER", true)
            putExtra("EXTRA_IS_MORNING_BRIEFING", true)
        }
        val answerPendingIntent = PendingIntent.getActivity(
            context,
            2002,
            answerIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Build heads-up notification with Answer / Decline buttons and full-screen intent
        val notification = NotificationCompat.Builder(context, CHANNEL_MORNING_CALL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("JARVIS • IN-APP VOICE SESSION")
            .setContentText("Good morning, Sir. Scheduled morning briefing ready (Not a cellular call).")
            .setSubText("MORNING BRIEFING")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .setContentIntent(fullScreenPendingIntent)
            .setAutoCancel(true)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "DECLINE", fullScreenPendingIntent)
            .addAction(android.R.drawable.ic_btn_speak_now, "ANSWER", answerPendingIntent)
            .build()

        notificationManager.notify(NOTIFICATION_ID_MORNING, notification)

        // Launch activity directly to display in-app incoming screen
        try {
            context.startActivity(fullScreenIntent)
        } catch (e: Exception) {
            Log.d(TAG, "Activity launch delegated to fullScreenIntent: ${e.message}")
        }
    }
}

