package com.jarvis.assistant.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.assistant.data.local.PreferencesManager
import com.jarvis.assistant.data.model.JarvisSettings
import com.jarvis.assistant.ui.theme.JarvisBackground
import com.jarvis.assistant.ui.theme.JarvisCyan
import com.jarvis.assistant.ui.theme.JarvisSurface
import com.jarvis.assistant.ui.theme.JarvisTextDim
import com.jarvis.assistant.ui.theme.JarvisTextPrimary
import com.jarvis.assistant.ui.theme.JarvisTextSecondary
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    currentSettings: JarvisSettings,
    preferencesManager: PreferencesManager?,
    onNavigateBack: () -> Unit,
    onTestCallClick: () -> Unit,
    onTestMorningTriggerClick: () -> Unit = onTestCallClick,
    onTestNotificationAccessClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // 1. Morning briefing time state
    var briefingTime by remember { mutableStateOf(currentSettings.morningBriefingTime) }

    // 2. Enable/disable daily briefing state
    var isBriefingEnabled by remember { mutableStateOf(currentSettings.isDailyBriefingEnabled) }

    // 3. Voice/speech settings state
    var voicePitch by remember { mutableFloatStateOf(currentSettings.voicePitch) }
    var voiceSpeed by remember { mutableFloatStateOf(currentSettings.voiceSpeed) }
    var voicePersonality by remember { mutableStateOf(currentSettings.voicePersonality) }

    // 4. Notification briefing settings state
    var readOnArrival by remember { mutableStateOf(currentSettings.readNotificationsOnArrival) }
    var filterImportant by remember { mutableStateOf(currentSettings.filterImportantOnly) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(JarvisBackground)
    ) {
        TopAppBar(
            title = {
                Text(
                    text = "SETTINGS",
                    fontSize = 18.sp,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 2.sp,
                    color = JarvisTextPrimary
                )
            },
            navigationIcon = {
                IconButton(onClick = onNavigateBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = JarvisCyan
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = JarvisBackground
            )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // SECTION 1 & 2: MORNING BRIEFING
            SettingsCard(title = "MORNING BRIEFING", icon = Icons.Default.Alarm) {
                // 2. Enable/disable daily briefing
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Enable Daily Briefing",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            color = JarvisTextPrimary
                        )
                        Text(
                            text = "Wake to schedule, weather, and overnight highlights",
                            fontSize = 12.sp,
                            color = JarvisTextDim
                        )
                    }
                    Switch(
                        checked = isBriefingEnabled,
                        onCheckedChange = { checked ->
                            isBriefingEnabled = checked
                            coroutineScope.launch {
                                preferencesManager?.setDailyBriefingEnabled(checked)
                            }
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = JarvisCyan,
                            checkedTrackColor = Color(0xFF005566)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // 1. Morning briefing time
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Briefing Time",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            color = JarvisTextPrimary
                        )
                        Text(
                            text = "Scheduled morning trigger",
                            fontSize = 12.sp,
                            color = JarvisTextDim
                        )
                    }

                    // Quick time selection chips
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("06:30", "07:00", "07:30", "08:00").forEach { time ->
                            val isSelected = briefingTime == time
                            Box(
                                modifier = Modifier
                                    .border(
                                        1.dp,
                                        if (isSelected) JarvisCyan else Color(0xFF263238),
                                        RoundedCornerShape(6.dp)
                                    )
                                    .background(
                                        if (isSelected) Color(0xFF003840) else Color.Transparent,
                                        RoundedCornerShape(6.dp)
                                    )
                                    .clickable {
                                        briefingTime = time
                                        coroutineScope.launch {
                                            preferencesManager?.updateMorningBriefingTime(time)
                                        }
                                    }
                                    .padding(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = time,
                                    color = if (isSelected) JarvisCyan else JarvisTextSecondary,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Schedule info & Test Trigger
                Text(
                    text = if (isBriefingEnabled) {
                        "Scheduled via AlarmManager for $briefingTime. Trigger persists across device reboot."
                    } else {
                        "Daily Briefing is disabled. AlarmManager trigger is cancelled."
                    },
                    fontSize = 12.sp,
                    color = if (isBriefingEnabled) JarvisCyan else JarvisTextDim,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedButton(
                    onClick = onTestMorningTriggerClick,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = JarvisCyan
                    )
                ) {
                    Icon(Icons.Default.Alarm, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("TEST MORNING TRIGGER", fontWeight = FontWeight.Bold)
                }
            }

            // SECTION 3: VOICE & SPEECH SETTINGS
            SettingsCard(title = "VOICE & SPEECH", icon = Icons.Default.RecordVoiceOver) {
                Text(
                    text = "Personality: $voicePersonality",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = JarvisCyan
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Pitch (${String.format("%.1f", voicePitch)}x)",
                    fontSize = 13.sp,
                    color = JarvisTextSecondary
                )
                Slider(
                    value = voicePitch,
                    onValueChange = {
                        voicePitch = it
                        coroutineScope.launch {
                            preferencesManager?.updateVoiceSettings(voicePitch, voiceSpeed, voicePersonality)
                        }
                    },
                    valueRange = 0.5f..1.5f,
                    colors = SliderDefaults.colors(
                        thumbColor = JarvisCyan,
                        activeTrackColor = JarvisCyan
                    )
                )

                Text(
                    text = "Speech Rate (${String.format("%.1f", voiceSpeed)}x)",
                    fontSize = 13.sp,
                    color = JarvisTextSecondary
                )
                Slider(
                    value = voiceSpeed,
                    onValueChange = {
                        voiceSpeed = it
                        coroutineScope.launch {
                            preferencesManager?.updateVoiceSettings(voicePitch, voiceSpeed, voicePersonality)
                        }
                    },
                    valueRange = 0.5f..1.5f,
                    colors = SliderDefaults.colors(
                        thumbColor = JarvisCyan,
                        activeTrackColor = JarvisCyan
                    )
                )
            }

            // SECTION 4: NOTIFICATION BRIEFING SETTINGS
            SettingsCard(title = "NOTIFICATION BRIEFING", icon = Icons.Default.Notifications) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Read on Arrival",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            color = JarvisTextPrimary
                        )
                        Text(
                            text = "Vocalize urgent notifications in hands-free mode",
                            fontSize = 12.sp,
                            color = JarvisTextDim
                        )
                    }
                    Switch(
                        checked = readOnArrival,
                        onCheckedChange = { checked ->
                            readOnArrival = checked
                            coroutineScope.launch {
                                preferencesManager?.updateNotificationSettings(checked, filterImportant)
                            }
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = JarvisCyan,
                            checkedTrackColor = Color(0xFF005566)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Filter VIP Only",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            color = JarvisTextPrimary
                        )
                        Text(
                            text = "Exclude marketing, social media, and spam",
                            fontSize = 12.sp,
                            color = JarvisTextDim
                        )
                    }
                    Switch(
                        checked = filterImportant,
                        onCheckedChange = { checked ->
                            filterImportant = checked
                            coroutineScope.launch {
                                preferencesManager?.updateNotificationSettings(readOnArrival, checked)
                            }
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = JarvisCyan,
                            checkedTrackColor = Color(0xFF005566)
                        )
                    )
                }
            }

            // SECTION 5: TEST NOTIFICATION ACCESS
            SettingsCard(title = "DIAGNOSTICS & HARDWARE ACCESS", icon = Icons.Default.Security) {
                Text(
                    text = "Notification Listener Service requires system permission to read incoming briefs.",
                    fontSize = 13.sp,
                    color = JarvisTextSecondary
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedButton(
                    onClick = onTestNotificationAccessClick,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("TEST NOTIFICATION ACCESS")
                }
            }

            // SECTION 6: TEST JARVIS CALL
            SettingsCard(title = "CONVERSATIONAL TRIGGER", icon = Icons.Default.PhoneInTalk) {
                Text(
                    text = "Simulate full-screen incoming call trigger from JARVIS for hands-free dialogue.",
                    fontSize = 13.sp,
                    color = JarvisTextSecondary
                )
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = onTestCallClick,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = JarvisCyan,
                        contentColor = Color(0xFF0A0E17)
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.PhoneInTalk, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("TEST JARVIS CALL (FULL SCREEN)", fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SettingsCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    content: @Composable () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = JarvisSurface),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = JarvisCyan, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    color = JarvisCyan,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.2.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
            Spacer(modifier = Modifier.height(14.dp))
            content()
        }
    }
}
