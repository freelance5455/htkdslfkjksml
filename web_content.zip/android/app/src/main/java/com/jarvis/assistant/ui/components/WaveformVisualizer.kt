package com.jarvis.assistant.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.ui.theme.JarvisCyan

/**
 * Animated audio frequency waveform visualizer for JARVIS voice feedback.
 */
@Composable
fun WaveformVisualizer(
    isActive: Boolean,
    modifier: Modifier = Modifier,
    height: Dp = 48.dp,
    barCount: Int = 24
) {
    val infiniteTransition = rememberInfiniteTransition(label = "waveform_anim")

    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
    ) {
        val totalWidth = size.width
        val barWidth = (totalWidth / (barCount * 1.6f)).coerceIn(4f, 14f)
        val spacing = (totalWidth - (barWidth * barCount)) / (barCount + 1)
        val midY = size.height / 2f

        for (i in 0 until barCount) {
            val normalizedX = i.toFloat() / barCount
            val amp = if (isActive) {
                val wave1 = Math.sin(phase + (i * 0.4)).toFloat()
                val wave2 = Math.cos((phase * 1.5) + (i * 0.25)).toFloat()
                ((wave1 + wave2 + 2f) / 4f) * 0.85f + 0.15f
            } else {
                0.12f
            }

            val barH = size.height * amp
            val x = spacing + i * (barWidth + spacing)
            val y = midY - (barH / 2f)

            drawRoundRect(
                color = if (isActive) JarvisCyan.copy(alpha = 0.85f) else JarvisCyan.copy(alpha = 0.25f),
                topLeft = Offset(x, y),
                size = Size(barWidth, barH),
                cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f)
            )
        }
    }
}
