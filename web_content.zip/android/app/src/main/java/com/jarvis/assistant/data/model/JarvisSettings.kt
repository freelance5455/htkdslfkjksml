package com.jarvis.assistant.data.model

/**
 * Data model for JARVIS local device preferences and configuration.
 */
data class JarvisSettings(
    // 1. Morning briefing time (in 24-hour format "HH:mm")
    val morningBriefingTime: String = "07:00",

    // 2. Enable/disable daily briefing
    val isDailyBriefingEnabled: Boolean = true,

    // 3. Voice/speech settings
    val voicePitch: Float = 1.0f,
    val voiceSpeed: Float = 1.0f,
    val voiceLanguage: String = "en-US",
    val voicePersonality: String = "British Butler", // Classic JARVIS tone
    val wakeWordEnabled: Boolean = true,

    // 4. Notification briefing settings
    val readNotificationsOnArrival: Boolean = false,
    val filterImportantOnly: Boolean = true,
    val allowedApps: Set<String> = setOf("com.google.android.gm", "com.whatsapp", "com.google.android.calendar"),

    // User greeting preference
    val userName: String = "Sir"
)
