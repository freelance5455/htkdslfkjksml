package com.jarvis.assistant.service

import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import java.util.Locale

/**
 * Service managing on-device Speech-to-Text (SpeechRecognizer) and
 * Text-to-Speech (TTS) for hands-free two-way conversational voice flow.
 * 
 * Supports continuous hands-free dialogue, on-device NLP response routing,
 * and zero external paid API overhead.
 */
class JarvisVoiceInteractionService : Service(), TextToSpeech.OnInitListener {

    companion object {
        private const val TAG = "JarvisVoiceService"
        const val ACTION_START_VOICE_SESSION = "com.jarvis.assistant.START_VOICE_SESSION"
        const val ACTION_STOP_VOICE_SESSION = "com.jarvis.assistant.STOP_VOICE_SESSION"
    }

    private val binder = LocalBinder()
    private var textToSpeech: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var isTtsReady = false
    private var isListening = false

    interface VoiceInteractionCallback {
        fun onUserSpoken(text: String)
        fun onJarvisSpeaking(text: String)
        fun onSpeechRecognitionError(errorCode: Int, message: String)
        fun onVoiceSessionEnded()
    }

    private var interactionCallback: VoiceInteractionCallback? = null

    inner class LocalBinder : Binder() {
        fun getService(): JarvisVoiceInteractionService = this@JarvisVoiceInteractionService
    }

    override fun onCreate() {
        super.onCreate()
        textToSpeech = TextToSpeech(this, this)
        initializeSpeechRecognizer()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = textToSpeech?.setLanguage(Locale.US)
            if (result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED) {
                isTtsReady = true
                Log.d(TAG, "On-device TTS engine initialized successfully.")
            }

            textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}

                override fun onDone(utteranceId: String?) {
                    // Continuous hands-free loop: resume listening once JARVIS finishes speaking
                    if (utteranceId == "JARVIS_LOOP_UTTERANCE") {
                        startListening()
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    startListening()
                }
            })
        }
    }

    private fun initializeSpeechRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        isListening = true
                    }

                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {
                        isListening = false
                    }

                    override fun onError(error: Int) {
                        isListening = false
                        // On timeout or no speech, automatically continue hands-free listening
                        if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                            startListening()
                        } else {
                            interactionCallback?.onSpeechRecognitionError(error, "Speech recognition code: $error")
                        }
                    }

                    override fun onResults(results: Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val text = matches?.firstOrNull()
                        if (!text.isNullOrBlank()) {
                            interactionCallback?.onUserSpoken(text)
                        } else {
                            startListening()
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
        }
    }

    fun setCallback(callback: VoiceInteractionCallback?) {
        this.interactionCallback = callback
    }

    fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }

        try {
            speechRecognizer?.cancel()
            speechRecognizer?.startListening(intent)
            isListening = true
        } catch (e: Exception) {
            Log.e(TAG, "Error launching recognizer: ${e.message}")
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.cancel()
            isListening = false
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping recognizer: ${e.message}")
        }
    }

    fun speak(text: String, pitch: Float = 1.0f, speed: Float = 1.0f, continuousLoop: Boolean = true) {
        if (isTtsReady) {
            stopListening()
            textToSpeech?.setPitch(pitch)
            textToSpeech?.setSpeechRate(speed)
            val utteranceId = if (continuousLoop) "JARVIS_LOOP_UTTERANCE" else "JARVIS_SINGLE_UTTERANCE"
            val params = Bundle().apply {
                putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
            }
            interactionCallback?.onJarvisSpeaking(text)
            textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
        }
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onDestroy() {
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        speechRecognizer?.destroy()
        super.onDestroy()
    }
}
