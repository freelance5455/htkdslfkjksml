package com.jarvis.ai;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String label = intent.getStringExtra("label");
        if (label == null) label = "JARVIS Wakeup";

        Toast.makeText(context, "JARVIS ALARM: " + label, Toast.LENGTH_LONG).show();

        // Launch MainActivity to start wake sequence
        Intent launchIntent = new Intent(context, MainActivity.class);
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        launchIntent.putExtra("TRIGGER_ALARM", label);
        context.startActivity(launchIntent);
    }
}
