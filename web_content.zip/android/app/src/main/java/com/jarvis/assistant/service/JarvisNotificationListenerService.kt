package com.jarvis.assistant.service

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

/**
 * Data model for locally stored notification metadata.
 * Only the minimum details needed for the morning briefing are saved.
 * Zero data is transmitted to external servers.
 */
data class StoredNotification(
    val id: String,
    val appName: String,
    val packageName: String,
    val title: String,
    val text: String,
    val timestamp: Long,
    val isOngoing: Boolean,
    val priority: Int
)

/**
 * Android NotificationListenerService to intercept, filter, and locally store incoming notifications
 * for the JARVIS morning briefing system.
 *
 * Privacy & Security Guarantees:
 * 1. Notifications are NEVER read or accessed until the user explicitly grants Notification Access in Settings.
 * 2. Only minimum required fields (app name, title, text, timestamp) are kept.
 * 3. All storage is strictly local on the device (zero cloud telemetry).
 * 4. Low-priority noise, media players, and ongoing background services are filtered out.
 */
class JarvisNotificationListenerService : NotificationListenerService() {

    companion object {
        private const val TAG = "JarvisNotification"
        private const val MAX_STORED_NOTIFICATIONS = 30

        // In-memory / local on-device cache of captured notifications since last briefing
        private val localNotificationCache = mutableListOf<StoredNotification>()

        /**
         * Checks if the user has explicitly granted Notification Access in Android Settings.
         * Must be called before reading any notifications.
         */
        fun isNotificationAccessGranted(context: Context): Boolean {
            val enabledListeners = Settings.Secure.getString(
                context.contentResolver,
                "enabled_notification_listeners"
            ) ?: return false

            val expectedComponentName = ComponentName(context, JarvisNotificationListenerService::class.java).flattenToString()
            return enabledListeners.contains(expectedComponentName)
        }

        /**
         * Intent to launch Android Notification Listener Settings for user authorization.
         */
        fun createNotificationAccessSettingsIntent(): Intent {
            return Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        }

        /**
         * Retrieves all captured notifications filtered by user importance preferences.
         */
        @Synchronized
        fun getCapturedNotifications(allowedPackages: Set<String>? = null, filterNoise: Boolean = true): List<StoredNotification> {
            return localNotificationCache.filter { item ->
                if (filterNoise && item.isOngoing) return@filter false
                if (filterNoise && item.priority < Notification.PRIORITY_DEFAULT) return@filter false
                if (allowedPackages != null && !allowedPackages.contains(item.packageName)) return@filter false
                true
            }.sortedByDescending { it.timestamp }
        }

        /**
         * Clears notifications after a successful morning briefing has been delivered.
         */
        @Synchronized
        fun clearOldNotifications() {
            localNotificationCache.clear()
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return

        try {
            val notification = sbn.notification ?: return
            val packageName = sbn.packageName ?: return

            // 1. Ignore ongoing foreground tasks (e.g. download progress, media player)
            val isOngoing = (notification.flags and Notification.FLAG_ONGOING_EVENT) != 0

            // 2. Extract user-readable title and text
            val extras = notification.extras ?: return
            val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim() ?: ""
            val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
                ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString()?.trim() ?: ""

            // Skip empty or purely decorative notifications
            if (title.isEmpty() && text.isEmpty()) return

            // 3. Resolve human-readable App Name
            val pm = applicationContext.packageManager
            val appName = try {
                val appInfo = pm.getApplicationInfo(packageName, 0)
                pm.getApplicationLabel(appInfo).toString()
            } catch (e: Exception) {
                packageName
            }

            val stored = StoredNotification(
                id = "${sbn.key}_${System.currentTimeMillis()}",
                appName = appName,
                packageName = packageName,
                title = title,
                text = text,
                timestamp = sbn.postTime,
                isOngoing = isOngoing,
                priority = notification.priority
            )

            synchronized(localNotificationCache) {
                // Deduplicate: avoid storing identical text from same package within 2 minutes
                val isDuplicate = localNotificationCache.any {
                    it.packageName == packageName &&
                    it.title == title &&
                    it.text == text &&
                    (System.currentTimeMillis() - it.timestamp) < 120_000
                }

                if (!isDuplicate) {
                    localNotificationCache.add(0, stored)
                    if (localNotificationCache.size > MAX_STORED_NOTIFICATIONS) {
                        localNotificationCache.removeAt(localNotificationCache.lastIndex)
                    }
                    Log.d(TAG, "Locally captured notification for briefing: [$appName] $title")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error processing notification", e)
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        super.onNotificationRemoved(sbn)
        // Kept in local buffer for morning summary until briefing is spoken
    }
}
