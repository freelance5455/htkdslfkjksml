package com.jarvis.assistant.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.jarvis.assistant.data.model.JarvisSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "jarvis_settings")

/**
 * Local DataStore manager to store and retrieve all JARVIS settings on the device.
 */
class PreferencesManager(private val context: Context) {

    companion object {
        val KEY_MORNING_BRIEFING_TIME = stringPreferencesKey("morning_briefing_time")
        val KEY_DAILY_BRIEFING_ENABLED = booleanPreferencesKey("daily_briefing_enabled")
        val KEY_VOICE_PITCH = floatPreferencesKey("voice_pitch")
        val KEY_VOICE_SPEED = floatPreferencesKey("voice_speed")
        val KEY_VOICE_LANGUAGE = stringPreferencesKey("voice_language")
        val KEY_VOICE_PERSONALITY = stringPreferencesKey("voice_personality")
        val KEY_WAKE_WORD_ENABLED = booleanPreferencesKey("wake_word_enabled")
        val KEY_READ_NOTIFICATIONS = booleanPreferencesKey("read_notifications")
        val KEY_FILTER_IMPORTANT = booleanPreferencesKey("filter_important")
        val KEY_ALLOWED_APPS = stringSetPreferencesKey("allowed_apps")
        val KEY_USER_NAME = stringPreferencesKey("user_name")
    }

    /**
     * Flow representing continuous stream of local settings
     */
    val settingsFlow: Flow<JarvisSettings> = context.dataStore.data.map { preferences ->
        JarvisSettings(
            morningBriefingTime = preferences[KEY_MORNING_BRIEFING_TIME] ?: "07:00",
            isDailyBriefingEnabled = preferences[KEY_DAILY_BRIEFING_ENABLED] ?: true,
            voicePitch = preferences[KEY_VOICE_PITCH] ?: 1.0f,
            voiceSpeed = preferences[KEY_VOICE_SPEED] ?: 1.0f,
            voiceLanguage = preferences[KEY_VOICE_LANGUAGE] ?: "en-US",
            voicePersonality = preferences[KEY_VOICE_PERSONALITY] ?: "British Butler",
            wakeWordEnabled = preferences[KEY_WAKE_WORD_ENABLED] ?: true,
            readNotificationsOnArrival = preferences[KEY_READ_NOTIFICATIONS] ?: false,
            filterImportantOnly = preferences[KEY_FILTER_IMPORTANT] ?: true,
            allowedApps = preferences[KEY_ALLOWED_APPS] ?: setOf("com.google.android.gm", "com.whatsapp", "com.google.android.calendar"),
            userName = preferences[KEY_USER_NAME] ?: "Sir"
        )
    }

    suspend fun updateMorningBriefingTime(time: String) {
        context.dataStore.edit { prefs ->
            prefs[KEY_MORNING_BRIEFING_TIME] = time
            val isEnabled = prefs[KEY_DAILY_BRIEFING_ENABLED] ?: true
            com.jarvis.assistant.receiver.MorningBriefingScheduler.scheduleMorningBriefing(context, time, isEnabled)
        }
    }

    suspend fun setDailyBriefingEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_DAILY_BRIEFING_ENABLED] = enabled
            val time = prefs[KEY_MORNING_BRIEFING_TIME] ?: "07:00"
            com.jarvis.assistant.receiver.MorningBriefingScheduler.scheduleMorningBriefing(context, time, enabled)
        }
    }

    suspend fun updateVoiceSettings(pitch: Float, speed: Float, personality: String) {
        context.dataStore.edit { prefs ->
            prefs[KEY_VOICE_PITCH] = pitch
            prefs[KEY_VOICE_SPEED] = speed
            prefs[KEY_VOICE_PERSONALITY] = personality
        }
    }

    suspend fun updateNotificationSettings(readOnArrival: Boolean, filterImportant: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_READ_NOTIFICATIONS] = readOnArrival
            prefs[KEY_FILTER_IMPORTANT] = filterImportant
        }
    }
}
