package com.jarvis.assistant.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.ui.theme.JarvisCyan
import com.jarvis.assistant.ui.theme.JarvisCyanGlow

/**
 * Futuristic arc-reactor pulsing microphone button for voice interaction.
 */
@Composable
fun ArcReactorMicButton(
    isListening: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 160.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_animation")

    // Pulsing outer glow radius animation
    val pulseGlow by infiniteTransition.animateFloat(
        initialValue = if (isListening) 0.85f else 0.95f,
        targetValue = if (isListening) 1.25f else 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isListening) 800 else 2400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_glow"
    )

    // Rotating reactor ticks animation
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isListening) 4000 else 16000),
            repeatMode = RepeatMode.Restart
        ),
        label = "reactor_rotation"
    )

    Box(
        modifier = modifier
            .size(size)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        // Futuristic Ring canvas
        Canvas(modifier = Modifier.matchParentSize()) {
            val center = this.center
            val radius = (this.size.minDimension / 2f) * 0.85f

            // Outer pulse wave ring
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(JarvisCyanGlow, Color.Transparent),
                    center = center,
                    radius = radius * pulseGlow
                ),
                radius = radius * pulseGlow
            )

            // Outer tech ring border
            drawCircle(
                color = JarvisCyan.copy(alpha = if (isListening) 0.8f else 0.35f),
                radius = radius,
                style = Stroke(width = 2.5f)
            )

            // Arc segments
            val segmentAngle = 360f / 12f
            for (i in 0 until 12) {
                val start = rotationAngle + (i * segmentAngle)
                drawArc(
                    color = if (i % 2 == 0) JarvisCyan else JarvisCyan.copy(alpha = 0.4f),
                    startAngle = start,
                    sweepAngle = segmentAngle * 0.6f,
                    useCenter = false,
                    style = Stroke(width = if (isListening) 4.5f else 3f)
                )
            }
        }

        // Center glass button
        Box(
            modifier = Modifier
                .size(size * 0.58f)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            if (isListening) JarvisCyan.copy(alpha = 0.3f) else Color(0xFF162438),
                            Color(0xFF0F172A)
                        )
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Mic,
                contentDescription = "Activate Voice Assistant",
                tint = if (isListening) JarvisCyan else Color.White,
                modifier = Modifier.size(size * 0.3f)
            )
        }
    }
}
