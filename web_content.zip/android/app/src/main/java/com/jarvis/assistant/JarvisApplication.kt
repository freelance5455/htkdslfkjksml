package com.jarvis.assistant

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.jarvis.assistant.data.local.PreferencesManager

class JarvisApplication : Application() {

    lateinit var preferencesManager: PreferencesManager
        private set

    companion object {
        const val CHANNEL_BRIEFING = "jarvis_briefing_channel"
        const val CHANNEL_CALL = "jarvis_call_channel"
    }

    override fun onCreate() {
        super.onCreate()
        preferencesManager = PreferencesManager(applicationContext)
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val briefingChannel = NotificationChannel(
                CHANNEL_BRIEFING,
                "JARVIS Morning Briefings",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Daily morning briefing summaries and alarms"
            }

            val callChannel = NotificationChannel(
                CHANNEL_CALL,
                "JARVIS Calls",
                NotificationManager.IMPORTANCE_MAX
            ).apply {
                description = "Incoming conversational assistant calls"
            }

            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(briefingChannel)
            notificationManager.createNotificationChannel(callChannel)
        }
    }
}
