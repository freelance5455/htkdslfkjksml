package com.jarvis.assistant.ui.theme

import androidx.compose.ui.graphics.Color

val JarvisCyan = Color(0xFF00E5FF)
val JarvisCyanDark = Color(0xFF00838F)
val JarvisCyanGlow = Color(0x3300E5FF)
val JarvisBackground = Color(0xFF0A0E17)
val JarvisSurface = Color(0xFF111827)
val JarvisSurfaceVariant = Color(0xFF1F2937)
val JarvisBorder = Color(0xFF1E293B)
val JarvisAccentAmber = Color(0xFFFFB300)
val JarvisAccentRed = Color(0xFFFF3B30)
val JarvisGreen = Color(0xFF00E676)
val JarvisTextPrimary = Color(0xFFF1F5F9)
val JarvisTextSecondary = Color(0xFF94A3B8)
val JarvisTextDim = Color(0xFF64748B)
