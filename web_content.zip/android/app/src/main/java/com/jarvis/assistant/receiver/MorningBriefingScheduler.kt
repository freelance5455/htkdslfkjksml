package com.jarvis.assistant.receiver

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.jarvis.assistant.MainActivity
import java.util.Calendar

/**
 * Helper object managing exact AlarmManager scheduling for the daily JARVIS morning briefing.
 * Works even when the application is killed/closed, restores across phone reboots,
 * and adheres to Android battery/Doze restrictions via setAlarmClock or setExactAndAllowWhileIdle.
 */
object MorningBriefingScheduler {

    const val ACTION_MORNING_BRIEFING = "com.jarvis.assistant.ACTION_MORNING_BRIEFING"
    const val ACTION_TEST_MORNING_TRIGGER = "com.jarvis.assistant.ACTION_TEST_MORNING_TRIGGER"
    const val REQUEST_CODE_BRIEFING = 7001
    private const val TAG = "MorningScheduler"

    /**
     * Schedules or cancels the daily morning briefing alarm.
     *
     * @param context Context
     * @param timeString String in "HH:mm" format (e.g. "07:00")
     * @param isEnabled Boolean whether the user has enabled daily briefing
     */
    fun scheduleMorningBriefing(context: Context, timeString: String, isEnabled: Boolean) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: run {
            Log.e(TAG, "AlarmManager system service not available.")
            return
        }

        val intent = Intent(context, MorningBriefingReceiver::class.java).apply {
            action = ACTION_MORNING_BRIEFING
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE_BRIEFING,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        if (!isEnabled) {
            alarmManager.cancel(pendingIntent)
            Log.d(TAG, "Daily Morning Briefing alarm cancelled (disabled in settings).")
            return
        }

        val (hour, minute) = parseTimeString(timeString)
        val now = Calendar.getInstance()
        val target = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            // If the time has already passed today, advance to tomorrow
            if (before(now) || timeInMillis <= now.timeInMillis) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        val triggerTimeMs = target.timeInMillis

        // Show Intent for AlarmClockInfo allows user to tap system clock / status bar icon to open JARVIS
        val showIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val showPendingIntent = PendingIntent.getActivity(
            context,
            REQUEST_CODE_BRIEFING,
            showIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                // AlarmClockInfo is the gold-standard Android API for user-scheduled wakeups:
                // It is exempt from Doze mode and App Standby buckets, guaranteeing exact on-time trigger.
                val alarmClockInfo = AlarmManager.AlarmClockInfo(triggerTimeMs, showPendingIntent)
                alarmManager.setAlarmClock(alarmClockInfo, pendingIntent)
                Log.d(TAG, "Scheduled morning briefing via setAlarmClock for ${target.time}")
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerTimeMs, pendingIntent)
                Log.d(TAG, "Scheduled morning briefing via setExactAndAllowWhileIdle for ${target.time}")
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerTimeMs, pendingIntent)
            }
        } catch (se: SecurityException) {
            Log.w(TAG, "Exact alarm permission restricted; falling back to setAndAllowWhileIdle", se)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerTimeMs, pendingIntent)
            } else {
                alarmManager.set(AlarmManager.RTC_WAKEUP, triggerTimeMs, pendingIntent)
            }
        }
    }

    /**
     * Broadcasts an immediate test trigger to test the incoming-call-style in-app experience
     * without needing to wait for the scheduled time.
     */
    fun triggerImmediateTest(context: Context) {
        Log.d(TAG, "Triggering immediate morning briefing test...")
        val intent = Intent(context, MorningBriefingReceiver::class.java).apply {
            action = ACTION_TEST_MORNING_TRIGGER
        }
        context.sendBroadcast(intent)
    }

    /**
     * Cancels any active morning briefing alarm.
     */
    fun cancelBriefing(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, MorningBriefingReceiver::class.java).apply {
            action = ACTION_MORNING_BRIEFING
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE_BRIEFING,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
        Log.d(TAG, "Cancelled morning briefing alarm.")
    }

    fun parseTimeString(timeString: String): Pair<Int, Int> {
        return try {
            val parts = timeString.split(":")
            val h = parts[0].trim().toInt()
            val m = parts[1].trim().toInt()
            Pair(h, m)
        } catch (e: Exception) {
            Pair(7, 0) // Default: 7:00 AM
        }
    }
}
