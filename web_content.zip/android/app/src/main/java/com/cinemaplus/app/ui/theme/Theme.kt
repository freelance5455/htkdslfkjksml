package com.cinemaplus.app.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFFD5AD61),
    secondary = Color(0xFFB88D42),
    background = Color(0xFF101827),
    surface = Color(0xFF1B2940)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFFD5AD61),
    secondary = Color(0xFFB88D42)
)

@Composable
fun CinemaGoldTheme(darkTheme: Boolean = true, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content
    )
}
