package com.cinemaplus.app.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.cinemaplus.app.data.api.CinemaApi
import com.cinemaplus.app.data.model.MovieDto
import com.cinemaplus.app.data.model.SeriesDto
import com.cinemaplus.app.data.model.SubscriptionStatus
import com.cinemaplus.app.data.model.WatchProgressDto
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun HomeContent(
    api: CinemaApi,
    modifier: Modifier = Modifier,
    onOpenMovie: (Int) -> Unit,
    onOpenSeries: (Int) -> Unit,
    onSeeAllMovies: () -> Unit,
    onSeeAllSeries: () -> Unit,
    onOpenSubscription: () -> Unit = {},
    onOpenContinue: (WatchProgressDto) -> Unit = {}
) {
    var popularMovies by remember { mutableStateOf<List<MovieDto>>(emptyList()) }
    var popularSeries by remember { mutableStateOf<List<SeriesDto>>(emptyList()) }
    var subStatus by remember { mutableStateOf<SubscriptionStatus?>(null) }
    var continueItems by remember { mutableStateOf<List<WatchProgressDto>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var showClearHistoryDialog by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun reload() {
        scope.launch {
            loading = true
            error = null
            try {
                popularMovies = api.popularMovies()
                popularSeries = api.popularSeries()
                subStatus = runCatching { api.mySubscription() }.getOrNull()
                continueItems = runCatching { api.watchProgress() }.getOrDefault(emptyList())
            } catch (e: Exception) {
                error = e.message
            } finally {
                loading = false
            }
        }
    }

    LaunchedEffect(Unit) { reload() }

    if (showClearHistoryDialog) {
        AlertDialog(
            onDismissRequest = { showClearHistoryDialog = false },
            title = { Text("پاک‌کردن تاریخچه تماشا؟") },
            text = { Text("همه موارد بخش ادامه تماشا از حساب شما حذف می‌شوند.") },
            confirmButton = {
                TextButton(onClick = {
                    showClearHistoryDialog = false
                    scope.launch {
                        runCatching { api.saveWatchProgress(mapOf("action" to "clear")) }
                            .onSuccess { continueItems = emptyList() }
                    }
                }) { Text("پاک‌کردن") }
            },
            dismissButton = { TextButton(onClick = { showClearHistoryDialog = false }) { Text("انصراف") } }
        )
    }

    when {
        loading -> Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        error != null -> Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(error ?: "خطا")
                Spacer(Modifier.height(8.dp))
                Button(onClick = { reload() }) { Text("تلاش مجدد") }
            }
        }
        else -> LazyColumn(modifier.fillMaxSize()) {
            item { SubscriptionBanner(subStatus, onOpenSubscription) }
            if (continueItems.isNotEmpty()) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("ادامه تماشا", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        TextButton(onClick = { showClearHistoryDialog = true }) {
                            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("پاک‌کردن همه")
                        }
                    }
                }
                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(continueItems, key = { "${it.type}-${it.id}" }) { item ->
                            ContinueWatchingCard(
                                item = item,
                                onClick = { onOpenContinue(item) },
                                onRemove = {
                                    scope.launch {
                                        runCatching {
                                            api.saveWatchProgress(mapOf("action" to "remove", "type" to item.type, "id" to item.id))
                                        }.onSuccess { continueItems = continueItems.filterNot { it.type == item.type && it.id == item.id } }
                                    }
                                }
                            )
                        }
                    }
                }
            }
            item {
                SectionHeader("سریال‌های پربازدید", "همه سریال‌ها", onSeeAllSeries)
            }
            item {
                if (popularSeries.isEmpty()) {
                    EmptyHint("سریالی نیست — از پنل ادمین اضافه کنید")
                } else {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(popularSeries) { s ->
                            SeriesCard(s) { onOpenSeries(s.id) }
                        }
                    }
                }
            }
            item {
                SectionHeader("فیلم‌های پربازدید", "همه فیلم‌ها", onSeeAllMovies)
            }
            item {
                if (popularMovies.isEmpty()) {
                    EmptyHint("فیلمی موجود نیست")
                } else {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(popularMovies) { m ->
                            MovieCard(m) { onOpenMovie(m.id) }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(28.dp)) }
        }
    }
}

@Composable
private fun ContinueWatchingCard(item: WatchProgressDto, onClick: () -> Unit, onRemove: () -> Unit) {
    val duration = (item.duration ?: 0).coerceAtLeast(0)
    val position = item.position_seconds.coerceAtLeast(0)
    val progress = if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f
    Card(
        modifier = Modifier.width(148.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column {
            Box {
                AsyncImage(
                    model = item.poster_url,
                    contentDescription = item.title,
                    modifier = Modifier.fillMaxWidth().height(190.dp),
                    contentScale = ContentScale.Crop
                )
                IconButton(
                    onClick = onRemove,
                    modifier = Modifier.align(Alignment.TopEnd).padding(4.dp)
                        .size(34.dp).clip(RoundedCornerShape(50)).background(Color.Black.copy(alpha = 0.58f))
                ) {
                    Icon(Icons.Default.Clear, contentDescription = "حذف از ادامه تماشا", tint = Color.White)
                }
            }
            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(item.series_title ?: item.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                if (item.type == "episode") Text(item.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                LinearProgressIndicator(progress = progress, modifier = Modifier.fillMaxWidth())
                Text("ادامه از ${position / 60} دقیقه", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun SubscriptionBanner(status: SubscriptionStatus?, onClick: () -> Unit) {
    val (title, subtitle, color) = when {
        status == null -> Triple("وضعیت اشتراک", "برای مشاهده جزئیات لمس کنید", MaterialTheme.colorScheme.surfaceVariant)
        status.hasAccess && status.type == "admin" -> Triple("دسترسی مدیر", "نامحدود", Color(0xFF1B5E20))
        status.hasAccess && status.type == "free_trial" -> Triple(
            "دوره رایگان فعال",
            "تا ${status.endsAt?.take(10) ?: "—"}",
            Color(0xFF0D47A1)
        )
        status.hasAccess -> Triple(
            "اشتراک فعال",
            "${status.type} تا ${status.endsAt?.take(10) ?: "—"}",
            Color(0xFF1B5E20)
        )
        else -> Triple("اشتراک ندارید", "برای تماشا و دانلود اشتراک تهیه کنید", Color(0xFFB71C1C))
    }
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.25f))
    ) {
        Row(
            Modifier.padding(16.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(title, fontWeight = FontWeight.Bold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall)
            }
            TextButton(onClick = onClick) { Text("مدیریت") }
        }
    }
}

@Composable
private fun SectionHeader(title: String, action: String, onAction: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        TextButton(onClick = onAction) { Text(action) }
    }
}

@Composable
private fun EmptyHint(text: String) {
    Text(
        text,
        Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        style = MaterialTheme.typography.bodyMedium
    )
}

@Composable
fun MoviesTabContent(
    api: CinemaApi,
    modifier: Modifier = Modifier,
    onOpenMovie: (Int) -> Unit
) {
    CatalogTab(
        modifier = modifier,
        load = { q, genre -> api.movies(q = q.ifBlank { null }, genre = genre) },
        loadGenres = { api.genres() },
        onOpen = onOpenMovie,
        isSeries = false
    )
}

@Composable
fun SeriesTabContent(
    api: CinemaApi,
    modifier: Modifier = Modifier,
    onOpenSeries: (Int) -> Unit
) {
    CatalogTab(
        modifier = modifier,
        load = { q, genre ->
            api.series(q = q.ifBlank { null }, genre = genre).map {
                CatalogItem(it.id, it.title, it.poster_url, it.rating_avg, it.view_count, it.year, it.genre, true)
            }
        },
        loadGenres = { api.genres() },
        onOpen = onOpenSeries,
        isSeries = true,
        loadSeriesRaw = { q, genre -> api.series(q = q.ifBlank { null }, genre = genre) }
    )
}

private data class CatalogItem(
    val id: Int,
    val title: String,
    val posterUrl: String?,
    val rating: Double,
    val views: Int,
    val year: Int?,
    val genre: String?,
    val isSeries: Boolean
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CatalogTab(
    modifier: Modifier,
    load: suspend (String, String?) -> List<*>,
    loadGenres: suspend () -> List<String>,
    onOpen: (Int) -> Unit,
    isSeries: Boolean,
    loadSeriesRaw: (suspend (String, String?) -> List<SeriesDto>)? = null
) {
    var query by remember { mutableStateOf("") }
    var selectedGenre by remember { mutableStateOf<String?>(null) }
    var genres by remember { mutableStateOf<List<String>>(emptyList()) }
    var movies by remember { mutableStateOf<List<MovieDto>>(emptyList()) }
    var series by remember { mutableStateOf<List<SeriesDto>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var showClearHistoryDialog by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun refresh() {
        scope.launch {
            loading = true
            error = null
            try {
                if (genres.isEmpty()) genres = runCatching { loadGenres() }.getOrDefault(emptyList())
                if (isSeries) {
                    series = loadSeriesRaw!!(query, selectedGenre)
                } else {
                    @Suppress("UNCHECKED_CAST")
                    movies = load(query, selectedGenre) as List<MovieDto>
                }
            } catch (e: Exception) {
                error = e.message
            } finally {
                loading = false
            }
        }
    }

    LaunchedEffect(Unit) { refresh() }
    LaunchedEffect(query, selectedGenre) {
        delay(350)
        refresh()
    }

    Column(modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            placeholder = { Text(if (isSeries) "جستجوی سریال..." else "جستجوی فیلم...") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { query = "" }) {
                        Icon(Icons.Default.Clear, null)
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(12.dp)
        )
        if (genres.isNotEmpty()) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = selectedGenre == null,
                        onClick = { selectedGenre = null },
                        label = { Text("همه") }
                    )
                }
                items(genres) { g ->
                    FilterChip(
                        selected = selectedGenre == g,
                        onClick = { selectedGenre = if (selectedGenre == g) null else g },
                        label = { Text(g) }
                    )
                }
            }
        }
        when {
            loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            error != null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(error ?: "خطا")
            }
            isSeries && series.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("موردی یافت نشد")
            }
            !isSeries && movies.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("موردی یافت نشد")
            }
            isSeries -> LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(series) { s ->
                    SeriesCard(s, fullWidth = true) { onOpen(s.id) }
                }
            }
            else -> LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(movies) { m ->
                    MovieCard(m, fullWidth = true) { onOpen(m.id) }
                }
            }
        }
    }
}

@Composable
fun MovieCard(movie: MovieDto, fullWidth: Boolean = false, onClick: () -> Unit) {
    ContentCard(
        title = movie.title,
        posterUrl = movie.poster_url,
        rating = movie.rating_avg,
        views = movie.view_count,
        badge = movie.genre,
        fullWidth = fullWidth,
        onClick = onClick
    )
}

@Composable
fun SeriesCard(series: SeriesDto, fullWidth: Boolean = false, onClick: () -> Unit) {
    ContentCard(
        title = series.title,
        posterUrl = series.poster_url,
        rating = series.rating_avg,
        views = series.view_count,
        badge = "سریال",
        fullWidth = fullWidth,
        onClick = onClick
    )
}

@Composable
private fun ContentCard(
    title: String,
    posterUrl: String?,
    rating: Double,
    views: Int,
    badge: String?,
    fullWidth: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = (if (fullWidth) Modifier.fillMaxWidth() else Modifier.width(148.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(if (fullWidth) 210.dp else 200.dp)
                    .background(Color(0xFF2A2A2A))
            ) {
                if (!posterUrl.isNullOrBlank()) {
                    AsyncImage(
                        model = posterUrl,
                        contentDescription = title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Text(
                        title.take(1),
                        modifier = Modifier.align(Alignment.Center),
                        style = MaterialTheme.typography.headlineLarge,
                        color = Color.White.copy(alpha = 0.5f)
                    )
                }
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .align(Alignment.BottomCenter)
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, Color.Black.copy(alpha = 0.75f))
                            )
                        )
                )
                if (!badge.isNullOrBlank()) {
                    Surface(
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.9f),
                        shape = RoundedCornerShape(bottomStart = 8.dp),
                        modifier = Modifier.align(Alignment.TopEnd)
                    ) {
                        Text(
                            badge,
                            Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White
                        )
                    }
                }
            }
            Column(Modifier.padding(10.dp)) {
                Text(
                    title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Star,
                        null,
                        tint = Color(0xFFFFC107),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        "$rating  •  ${formatViews(views)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

private fun formatViews(v: Int): String = when {
    v >= 1_000_000 -> "%.1fM بازدید".format(v / 1_000_000.0)
    v >= 1_000 -> "%.1fK بازدید".format(v / 1_000.0)
    else -> "$v بازدید"
}
