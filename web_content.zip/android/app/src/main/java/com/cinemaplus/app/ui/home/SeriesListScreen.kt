package com.cinemaplus.app.ui.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.cinemaplus.app.data.api.CinemaApi
import com.cinemaplus.app.data.model.SeriesDto
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SeriesListScreen(
    api: CinemaApi,
    onBack: () -> Unit,
    onOpenSeries: (Int) -> Unit,
    onOpenHome: () -> Unit = onBack,
    onOpenMovies: () -> Unit = {}
) {
    var series by remember { mutableStateOf<List<SeriesDto>>(emptyList()) }
    var popular by remember { mutableStateOf<List<SeriesDto>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        scope.launch {
            try {
                popular = api.popularSeries()
                series = api.series()
            } catch (e: Exception) {
                error = e.message
            } finally {
                loading = false
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("سریال‌ها") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = false,
                    onClick = onOpenHome,
                    icon = { Icon(Icons.Default.Home, null) },
                    label = { Text("خانه") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = onOpenMovies,
                    icon = { Icon(Icons.Default.Movie, null) },
                    label = { Text("فیلم‌ها") }
                )
                NavigationBarItem(
                    selected = true,
                    onClick = { },
                    icon = { Icon(Icons.Default.Tv, null) },
                    label = { Text("سریال‌ها") }
                )
            }
        }
    ) { padding ->
        when {
            loading -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            error != null -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text(error ?: "خطا")
            }
            series.isEmpty() -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("هنوز سریالی اضافه نشده است")
            }
            else -> {
                Column(Modifier.fillMaxSize().padding(padding)) {
                    if (popular.isNotEmpty()) {
                        Text(
                            "پربازدیدترین‌ها",
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                        )
                    }
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        contentPadding = PaddingValues(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(series) { s ->
                            SeriesCard(s, fullWidth = true) { onOpenSeries(s.id) }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MoviesListScreen(
    api: CinemaApi,
    onBack: () -> Unit,
    onOpenMovie: (Int) -> Unit,
    onOpenHome: () -> Unit = onBack,
    onOpenSeries: () -> Unit = {}
) {
    var movies by remember { mutableStateOf<List<com.cinemaplus.app.data.model.MovieDto>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        scope.launch {
            try {
                movies = api.movies()
            } catch (e: Exception) {
                error = e.message
            } finally {
                loading = false
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("فیلم‌ها") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = false,
                    onClick = onOpenHome,
                    icon = { Icon(Icons.Default.Home, null) },
                    label = { Text("خانه") }
                )
                NavigationBarItem(
                    selected = true,
                    onClick = { },
                    icon = { Icon(Icons.Default.Movie, null) },
                    label = { Text("فیلم‌ها") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = onOpenSeries,
                    icon = { Icon(Icons.Default.Tv, null) },
                    label = { Text("سریال‌ها") }
                )
            }
        }
    ) { padding ->
        when {
            loading -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            error != null -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text(error ?: "خطا")
            }
            else -> {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize().padding(padding)
                ) {
                    items(movies) { m ->
                        MovieCard(m, fullWidth = true) { onOpenMovie(m.id) }
                    }
                }
            }
        }
    }
}
