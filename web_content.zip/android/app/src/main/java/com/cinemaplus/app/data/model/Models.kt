package com.cinemaplus.app.data.model

data class AuthResponse(
    val token: String,
    val user: UserDto,
    val message: String? = null
)

data class UserDto(
    val id: Int,
    val username: String,
    val role: String,
    val free_trial_ends_at: String? = null
)

data class MovieDto(
    val id: Int,
    val title: String,
    val poster_url: String? = null,
    val rating_avg: Double = 0.0,
    val rating_count: Int = 0,
    val view_count: Int = 0,
    val year: Int? = null,
    val genre: String? = null,
    val description: String? = null,
    val video_url: String? = null,
    val subtitle_url: String? = null,
    val duration: Int? = null,
    val can_watch: Boolean? = null,
    val allow_download: Boolean? = true
)

data class SeriesDto(
    val id: Int,
    val title: String,
    val poster_url: String? = null,
    val rating_avg: Double = 0.0,
    val rating_count: Int = 0,
    val view_count: Int = 0,
    val year: Int? = null,
    val genre: String? = null,
    val description: String? = null,
    val can_watch: Boolean? = null,
    val seasons: List<SeasonDto>? = null
)

data class SeasonDto(
    val id: Int,
    val season_number: Int,
    val title: String?,
    val episodes: List<EpisodeDto>? = null
)

data class EpisodeDto(
    val id: Int,
    val episode_number: Int,
    val title: String?,
    val duration: Int? = null,
    val video_url: String? = null,
    val subtitle_url: String? = null,
    val allow_download: Boolean? = true
)

data class CommentDto(
    val id: Int,
    val body: String,
    val username: String,
    val created_at: String
)

data class PlanDto(
    val id: Int,
    val name: String,
    val name_en: String,
    val duration_days: Int,
    val price: Int
)

data class SubscriptionStatus(
    val hasAccess: Boolean,
    val type: String?,
    val endsAt: String?
)

data class PlayInfoDto(
    val id: Int,
    val title: String,
    val video_url: String,
    val subtitle_url: String? = null,
    val duration: Int? = null,
    val allow_download: Boolean = true,
    val video_mime_type: String? = null,
    val resume_position: Int? = null,
    val quality_options: List<PlaybackTrackDto> = emptyList(),
    val audio_tracks: List<PlaybackTrackDto> = emptyList(),
    val subtitle_tracks: List<PlaybackTrackDto> = emptyList()
)

data class PlaybackTrackDto(
    val label: String? = null,
    val name: String? = null,
    val quality: String? = null,
    val language: String? = null,
    val url: String? = null,
    val mime_type: String? = null,
    val default: Boolean = false
)

data class DownloadRequest(
    val type: String, // movie | episode
    val id: Int
)

data class ApiError(val error: String)


data class WatchProgressDto(
    val type: String,
    val id: Int,
    val title: String,
    val series_title: String? = null,
    val series_id: Int? = null,
    val poster_url: String? = null,
    val duration: Int? = null,
    val position_seconds: Int = 0,
    val updated_at: String? = null
)
