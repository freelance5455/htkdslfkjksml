package com.cinemaplus.app.data.api

import com.cinemaplus.app.data.model.*
import retrofit2.http.*

interface CinemaApi {

    @POST("api/auth/register")
    suspend fun register(@Body body: Map<String, String>): AuthResponse

    @POST("api/auth/login")
    suspend fun login(@Body body: Map<String, String>): AuthResponse

    @POST("api/auth/logout")
    suspend fun logout(): Map<String, String>

    @GET("api/movies/popular")
    suspend fun popularMovies(): List<MovieDto>

    @GET("api/movies")
    suspend fun movies(
        @Query("q") q: String? = null,
        @Query("genre") genre: String? = null
    ): List<MovieDto>

    @GET("api/movies/{id}")
    suspend fun movieDetail(@Path("id") id: Int): MovieDto

    @GET("api/movies/{id}/play")
    suspend fun playMovie(@Path("id") id: Int): PlayInfoDto

    @GET("api/series/popular")
    suspend fun popularSeries(): List<SeriesDto>

    @GET("api/series")
    suspend fun series(
        @Query("q") q: String? = null,
        @Query("genre") genre: String? = null
    ): List<SeriesDto>

    @GET("api/genres")
    suspend fun genres(): List<String>

    @GET("api/series/{id}")
    suspend fun seriesDetail(@Path("id") id: Int): SeriesDto

    @GET("api/series/episodes/{id}/play")
    suspend fun playEpisode(@Path("id") id: Int): PlayInfoDto

    @GET("api/comments/{type}/{id}")
    suspend fun comments(@Path("type") type: String, @Path("id") id: Int): List<CommentDto>

    @POST("api/comments/{type}/{id}")
    suspend fun postComment(
        @Path("type") type: String,
        @Path("id") id: Int,
        @Body body: Map<String, String>
    ): CommentDto

    @POST("api/ratings/{type}/{id}")
    suspend fun rate(
        @Path("type") type: String,
        @Path("id") id: Int,
        @Body body: Map<String, Int>
    ): Map<String, Any>

    @GET("api/subscription/plans")
    suspend fun plans(): List<PlanDto>

    @GET("api/subscription/me")
    suspend fun mySubscription(): SubscriptionStatus

    @POST("api/subscription/pay")
    suspend fun pay(@Body body: Map<String, Int>): Map<String, Any>

    @GET("api/subscription/verify-mock")
    suspend fun verifyMock(@Query("authority") authority: String): Map<String, Any>

    @GET("api/me/watch-progress")
    suspend fun watchProgress(): List<WatchProgressDto>

    @POST("api/me/watch-progress")
    suspend fun saveWatchProgress(@Body body: Map<String, @JvmSuppressWildcards Any>): Map<String, String>

    @POST("api/downloads/request")
    suspend fun requestDownload(@Body body: DownloadRequest): Map<String, Any>
}
