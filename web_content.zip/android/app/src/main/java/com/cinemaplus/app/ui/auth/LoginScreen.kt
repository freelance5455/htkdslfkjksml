package com.cinemaplus.app.ui.auth

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.cinemaplus.app.data.api.CinemaApi
import com.cinemaplus.app.data.api.TokenManager
import kotlinx.coroutines.launch

@Composable
fun LoginScreen(
    api: CinemaApi,
    tokenManager: TokenManager,
    onSuccess: () -> Unit
) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isRegister by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "CINEMA GOLD",
            style = MaterialTheme.typography.headlineLarge
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = if (isRegister) "ثبت‌نام رایگان" else "ورود به حساب",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(32.dp))

        OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            label = { Text("نام کاربری") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("رمز عبور") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth()
        )

        error?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }

        Spacer(Modifier.height(24.dp))
        Button(
            onClick = {
                if (username.isBlank() || password.length < 10) {
                    error = "نام کاربری و رمز (حداقل ۱۰ کاراکتر) الزامی است"
                    return@Button
                }
                loading = true
                error = null
                scope.launch {
                    try {
                        val body = mapOf("username" to username.trim(), "password" to password)
                        val res = if (isRegister) api.register(body) else api.login(body)
                        tokenManager.saveAuth(res.token, res.user.username)
                        onSuccess()
                    } catch (e: Exception) {
                        error = e.message ?: "خطا در ارتباط با سرور"
                    } finally {
                        loading = false
                    }
                }
            },
            enabled = !loading,
            modifier = Modifier.fillMaxWidth().height(48.dp)
        ) {
            if (loading) CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
            else Text(if (isRegister) "ثبت‌نام" else "ورود")
        }

        TextButton(onClick = { isRegister = !isRegister; error = null }) {
            Text(if (isRegister) "حساب دارید؟ ورود" else "حساب ندارید؟ ثبت‌نام")
        }
    }
}
