package com.cinemaplus.app.util

/**
 * مدیریت دانلود فیلم و زیرنویس با DownloadManager سیستم
 */
import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.widget.Toast

object DownloadHelper {

    fun downloadVideo(
        context: Context,
        title: String,
        videoUrl: String,
        subtitleUrl: String? = null
    ) {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

        val videoRequest = DownloadManager.Request(Uri.parse(videoUrl)).apply {
            setTitle(title)
            setDescription("در حال دانلود فیلم...")
            setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            setDestinationInExternalPublicDir(
                Environment.DIRECTORY_MOVIES,
                "CinemaPlus/${title}.mp4"
            )
            setAllowedOverMetered(true)
            setAllowedOverRoaming(false)
        }
        dm.enqueue(videoRequest)

        if (!subtitleUrl.isNullOrBlank()) {
            val ext = if (subtitleUrl.endsWith(".vtt", true)) "vtt" else "srt"
            val subRequest = DownloadManager.Request(Uri.parse(subtitleUrl)).apply {
                setTitle("$title - زیرنویس")
                setDescription("دانلود زیرنویس")
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_MOVIES,
                    "CinemaPlus/${title}.$ext"
                )
            }
            dm.enqueue(subRequest)
        }

        Toast.makeText(context, "دانلود شروع شد", Toast.LENGTH_SHORT).show()
    }
}
