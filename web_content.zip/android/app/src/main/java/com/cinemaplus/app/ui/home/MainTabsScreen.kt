package com.cinemaplus.app.ui.home

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Subscriptions
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.cinemaplus.app.data.api.CinemaApi
import com.cinemaplus.app.data.model.WatchProgressDto

enum class MainTab { Home, Movies, Series }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainTabsScreen(
    api: CinemaApi,
    onLogout: () -> Unit,
    onOpenMovie: (Int) -> Unit,
    onOpenSeries: (Int) -> Unit,
    onOpenSubscription: () -> Unit,
    onOpenContinue: (WatchProgressDto) -> Unit = {}
) {
    var tab by remember { mutableStateOf(MainTab.Home) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        when (tab) {
                            MainTab.Home -> "CINEMA GOLD"
                            MainTab.Movies -> "فیلم‌ها"
                            MainTab.Series -> "سریال‌ها"
                        }
                    )
                },
                actions = {
                    IconButton(onClick = onOpenSubscription) {
                        Icon(Icons.Default.Subscriptions, contentDescription = "اشتراک")
                    }
                    IconButton(onClick = onLogout) {
                        Icon(Icons.Default.ExitToApp, contentDescription = "خروج")
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == MainTab.Home,
                    onClick = { tab = MainTab.Home },
                    icon = { Icon(Icons.Default.Home, contentDescription = null) },
                    label = { Text("خانه") }
                )
                NavigationBarItem(
                    selected = tab == MainTab.Movies,
                    onClick = { tab = MainTab.Movies },
                    icon = { Icon(Icons.Default.Movie, contentDescription = null) },
                    label = { Text("فیلم‌ها") }
                )
                NavigationBarItem(
                    selected = tab == MainTab.Series,
                    onClick = { tab = MainTab.Series },
                    icon = { Icon(Icons.Default.Tv, contentDescription = null) },
                    label = { Text("سریال‌ها") }
                )
            }
        }
    ) { padding ->
        when (tab) {
            MainTab.Home -> HomeContent(
                api = api,
                modifier = Modifier.padding(padding),
                onOpenMovie = onOpenMovie,
                onOpenSeries = onOpenSeries,
                onSeeAllMovies = { tab = MainTab.Movies },
                onSeeAllSeries = { tab = MainTab.Series },
                onOpenSubscription = onOpenSubscription,
                onOpenContinue = onOpenContinue
            )
            MainTab.Movies -> MoviesTabContent(
                api = api,
                modifier = Modifier.padding(padding),
                onOpenMovie = onOpenMovie
            )
            MainTab.Series -> SeriesTabContent(
                api = api,
                modifier = Modifier.padding(padding),
                onOpenSeries = onOpenSeries
            )
        }
    }
}
