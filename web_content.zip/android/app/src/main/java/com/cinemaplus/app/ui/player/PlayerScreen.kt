package com.cinemaplus.app.ui.player

/**
 * صفحه پخش آنلاین با Media3 ExoPlayer + زیرنویس + دکمه دانلود
 */

import android.net.Uri
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.text.style.TextAlign
import androidx.media3.common.Tracks
import androidx.media3.common.TrackSelectionOverride
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.ui.PlayerView

data class PlayInfo(
    val id: Int,
    val title: String,
    val videoUrl: String,
    val subtitleUrl: String? = null,
    val allowDownload: Boolean = true,
    val videoMimeType: String? = null,
    val resumePosition: Long = 0L,
    val qualityOptions: List<PlaybackChoice> = emptyList(),
    val audioTracks: List<PlaybackChoice> = emptyList(),
    val subtitleTracks: List<PlaybackChoice> = emptyList(),
    val contentType: String = "movie"
)

data class PlaybackChoice(
    val label: String,
    val url: String? = null,
    val language: String? = null,
    val mimeType: String? = null,
    val isDefault: Boolean = false
) {
    fun qualityKey(): String? = label.lowercase().replace(" ", "").takeIf { it.isNotBlank() }
}

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    playInfo: PlayInfo,
    onBack: () -> Unit,
    onDownload: (PlayInfo) -> Unit = {},
    onRefreshPlayInfo: suspend () -> PlayInfo,
    onSaveProgress: suspend (PlayInfo, Long) -> Unit = { _, _ -> }
) {
    val context = LocalContext.current
    val lifecycleOwner = context as? LifecycleOwner
    val initialSubtitle = playInfo.subtitleUrl
        ?: playInfo.subtitleTracks.firstOrNull { it.isDefault }?.url
        ?: playInfo.subtitleTracks.firstOrNull()?.url
    var activeSubtitleUrl by remember(playInfo.id, playInfo.videoUrl) { mutableStateOf(initialSubtitle) }
    var showSubtitle by remember(playInfo.id, playInfo.videoUrl) { mutableStateOf(!initialSubtitle.isNullOrBlank()) }
    var selectedVideoUrl by remember(playInfo.id, playInfo.videoUrl) { mutableStateOf(playInfo.videoUrl) }
    var selectedVideoMime by remember(playInfo.id, playInfo.videoUrl) { mutableStateOf(playInfo.videoMimeType) }
    var activeAudioChoice by remember(playInfo.id, playInfo.videoUrl) { mutableStateOf<PlaybackChoice?>(null) }
    var qualityChoices by remember(playInfo.id, playInfo.videoUrl) { mutableStateOf(playInfo.qualityOptions) }
    var audioChoices by remember(playInfo.id, playInfo.videoUrl) { mutableStateOf(playInfo.audioTracks) }
    var subtitleChoices by remember(playInfo.id, playInfo.videoUrl) { mutableStateOf(playInfo.subtitleTracks) }
    var showTrackDialog by remember(playInfo.id, playInfo.videoUrl) { mutableStateOf(false) }
    var tracksSnapshot by remember(playInfo.id, playInfo.videoUrl) { mutableStateOf(Tracks.EMPTY) }
    var playbackError by remember(playInfo.id, playInfo.videoUrl) { mutableStateOf<String?>(null) }
    var refreshInProgress by remember(playInfo.id, playInfo.videoUrl) { mutableStateOf(false) }
    var refreshAttempted by remember(playInfo.id, playInfo.videoUrl) { mutableStateOf(false) }
    var refreshRequested by remember(playInfo.id, playInfo.videoUrl) { mutableStateOf(false) }
    val scope = rememberCoroutineScope()


    fun createMediaItem(sourceUrl: String, subtitleUrl: String?, sourceMimeType: String? = playInfo.videoMimeType, subtitleLanguage: String? = null): MediaItem {
        val builder = MediaItem.Builder().setUri(sourceUrl)
        // Signed URLs hide extensions, so keep the server-provided MIME type.
        sourceMimeType?.takeIf { it.isNotBlank() }?.let { builder.setMimeType(it) }
        if (!subtitleUrl.isNullOrBlank()) {
            val mime = if (subtitleUrl.substringBefore('?').endsWith(".vtt", true)) MimeTypes.TEXT_VTT else MimeTypes.APPLICATION_SUBRIP
            val config = MediaItem.SubtitleConfiguration.Builder(Uri.parse(subtitleUrl))
                .setMimeType(mime).setLanguage(subtitleLanguage?.takeIf { it.isNotBlank() } ?: "fa").setLabel("زیرنویس")
                .setSelectionFlags(C.SELECTION_FLAG_DEFAULT).build()
            builder.setSubtitleConfigurations(listOf(config))
        }
        return builder.build()
    }

    fun createCurrentMediaSource(videoUrl: String, subtitleUrl: String?, videoMime: String?, audioChoice: PlaybackChoice?): MediaSource {
        val factory = DefaultMediaSourceFactory(context)
        val videoSource = factory.createMediaSource(createMediaItem(videoUrl, subtitleUrl, videoMime))
        val audioUrl = audioChoice?.url
        if (audioUrl.isNullOrBlank()) return videoSource
        val audioMime = audioChoice?.mimeType ?: when {
            audioUrl.substringBefore('?').endsWith(".m3u8", true) -> "application/vnd.apple.mpegurl"
            audioUrl.substringBefore('?').endsWith(".m4a", true) -> "audio/mp4"
            audioUrl.substringBefore('?').endsWith(".aac", true) -> "audio/aac"
            else -> null
        }
        val audioItem = MediaItem.Builder().setUri(audioUrl).apply { audioMime?.let { setMimeType(it) } }.build()
        return MergingMediaSource(videoSource, factory.createMediaSource(audioItem))
    }

    val exoPlayer = remember(playInfo.id, playInfo.videoUrl) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(createMediaItem(playInfo.videoUrl, activeSubtitleUrl), playInfo.resumePosition.coerceAtLeast(0L))
            trackSelectionParameters = trackSelectionParameters.buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !showSubtitle)
                .build()
            addListener(object : Player.Listener {
                override fun onTracksChanged(tracks: Tracks) { tracksSnapshot = tracks }
                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    val responseCode = generateSequence<Throwable>(error) { it.cause }
                        .mapNotNull { it as? androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException }
                        .firstOrNull()?.responseCode
                    if (responseCode == 401 || responseCode == 403) {
                        playbackError = "اعتبار لینک پخش پایان یافته؛ در حال دریافت لینک تازه..."
                        refreshRequested = true
                    } else {
                        playbackError = error.message ?: "خطا در دریافت ویدئو؛ اتصال اینترنت یا منبع پخش را بررسی کنید."
                    }
                }
                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (playbackState == Player.STATE_READY) {
                        playbackError = null
                        refreshAttempted = false
                    }
                }
            })
            prepare()
            playWhenReady = true
        }
    }

    fun saveCurrentProgress() {
        val positionSeconds = (exoPlayer.currentPosition / 1000L).coerceAtLeast(0L)
        if (positionSeconds > 0L) {
            scope.launch {
                try { onSaveProgress(playInfo, positionSeconds) } catch (_: Exception) { /* Retry on next checkpoint. */ }
            }
        }
    }

    LaunchedEffect(playInfo.id, playInfo.contentType) {
        while (true) {
            delay(15_000)
            if (exoPlayer.isPlaying) {
                val positionSeconds = (exoPlayer.currentPosition / 1000L).coerceAtLeast(0L)
                if (positionSeconds > 0L) {
                    try { onSaveProgress(playInfo, positionSeconds) } catch (_: Exception) { /* Next checkpoint retries. */ }
                }
            }
        }
    }

    DisposableEffect(lifecycleOwner, exoPlayer) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_PAUSE) saveCurrentProgress()
        }
        lifecycleOwner?.lifecycle?.addObserver(observer)
        onDispose { lifecycleOwner?.lifecycle?.removeObserver(observer) }
    }

    fun refreshSignedPlayback() {
        if (refreshInProgress || refreshAttempted) return
        refreshInProgress = true
        refreshAttempted = true
        val resumeAt = exoPlayer.currentPosition.coerceAtLeast(0L)
        scope.launch {
            try {
                val fresh = onRefreshPlayInfo()
                val oldQuality = qualityChoices.firstOrNull { it.url == selectedVideoUrl }
                val nextQuality = oldQuality?.let { old -> fresh.qualityOptions.firstOrNull { it.label == old.label || (!old.qualityKey().isNullOrBlank() && it.qualityKey() == old.qualityKey()) } }
                    ?: fresh.qualityOptions.firstOrNull { it.isDefault }
                val nextVideo = nextQuality?.url ?: fresh.videoUrl
                val nextAudio = activeAudioChoice?.let { old -> fresh.audioTracks.firstOrNull { it.label == old.label || (!old.language.isNullOrBlank() && it.language == old.language) } }
                val oldSubtitle = activeSubtitleUrl?.let { old -> subtitleChoices.firstOrNull { it.url == old } }
                val nextSubtitle = oldSubtitle?.let { old -> fresh.subtitleTracks.firstOrNull { it.label == old.label || (!old.language.isNullOrBlank() && it.language == old.language) }?.url }
                    ?: fresh.subtitleUrl
                qualityChoices = fresh.qualityOptions
                audioChoices = fresh.audioTracks
                subtitleChoices = fresh.subtitleTracks
                selectedVideoUrl = nextVideo
                selectedVideoMime = nextQuality?.mimeType ?: fresh.videoMimeType
                activeAudioChoice = nextAudio
                activeSubtitleUrl = nextSubtitle
                showSubtitle = showSubtitle && !nextSubtitle.isNullOrBlank()
                playbackError = null
                exoPlayer.setMediaSource(createCurrentMediaSource(nextVideo, if (showSubtitle) nextSubtitle else null, selectedVideoMime, nextAudio), resumeAt)
                exoPlayer.prepare()
                exoPlayer.playWhenReady = true
            } catch (e: Exception) {
                playbackError = e.message ?: "دریافت لینک تازه ناموفق بود. وضعیت اشتراک و اتصال اینترنت را بررسی کنید."
            } finally {
                refreshInProgress = false
            }
        }
    }


    LaunchedEffect(refreshRequested) {
        if (refreshRequested) {
            refreshRequested = false
            refreshSignedPlayback()
        }
    }

    DisposableEffect(exoPlayer) {
        onDispose { exoPlayer.release() }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = true
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            update = { view ->
                // AndroidView may survive a content change; always attach the current player.
                if (view.player !== exoPlayer) view.player = exoPlayer
            },
            modifier = Modifier.fillMaxSize()
        )
        if (playbackError != null) {
            Column(
                modifier = Modifier.align(Alignment.Center).padding(24.dp)
                    .background(Color(0xDD171717), shape = MaterialTheme.shapes.large)
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("پخش متوقف شد", color = Color.White, style = MaterialTheme.typography.titleMedium)
                Text(playbackError ?: "خطای نامشخص", color = Color.White, textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodySmall)
                Button(onClick = {
                    refreshAttempted = false
                    refreshSignedPlayback()
                }, enabled = !refreshInProgress) { Text(if (refreshInProgress) "در حال دریافت لینک..." else "دریافت لینک تازه و تلاش دوباره") }
            }
        }
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = {
                scope.launch {
                    val positionSeconds = (exoPlayer.currentPosition / 1000L).coerceAtLeast(0L)
                    if (positionSeconds > 0L) {
                        try { onSaveProgress(playInfo, positionSeconds) } catch (_: Exception) { }
                    }
                    onBack()
                }
            }) {
                Icon(Icons.Default.ArrowBack, null, tint = Color.White)
            }
            Text(playInfo.title, color = Color.White, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            IconButton(onClick = { showTrackDialog = true }) {
                Icon(Icons.Default.Settings, contentDescription = "کیفیت و صدا", tint = Color.White)
            }
            if (!playInfo.subtitleUrl.isNullOrBlank() || subtitleChoices.isNotEmpty()) {
                IconButton(onClick = {
                    showSubtitle = !showSubtitle
                    if (showSubtitle && activeSubtitleUrl == null && !initialSubtitle.isNullOrBlank()) {
                        activeSubtitleUrl = initialSubtitle
                        val pos = exoPlayer.currentPosition
                        exoPlayer.setMediaSource(createCurrentMediaSource(selectedVideoUrl, initialSubtitle, selectedVideoMime, activeAudioChoice), pos)
                        exoPlayer.prepare(); exoPlayer.playWhenReady = true
                    } else {
                        exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters.buildUpon()
                            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !showSubtitle)
                            .build()
                    }
                }) {
                    Icon(Icons.Default.Subtitles, null, tint = if (showSubtitle) Color.Yellow else Color.White)
                }
            }
            if (playInfo.allowDownload) {
                IconButton(onClick = { onDownload(playInfo) }) {
                    Icon(Icons.Default.Download, null, tint = Color.White)
                }
            }
        }
        if (showTrackDialog) {
            AlertDialog(
                onDismissRequest = { showTrackDialog = false },
                title = { Text("تنظیمات پخش", textAlign = TextAlign.Center) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("کیفیت تصویر", style = MaterialTheme.typography.titleSmall)
                        Text("کیفیت تطبیقی (خودکار) از طریق HLS در دسترس است. برای انتخاب دستی، از کنترل کیفیت خود پخش‌کننده استفاده کنید.", style = MaterialTheme.typography.bodySmall)
                        if (qualityChoices.isNotEmpty()) {
                            qualityChoices.forEach { choice ->
                                TextButton(onClick = {
                                    val position = exoPlayer.currentPosition
                                    val next = choice.url
                                    if (!next.isNullOrBlank()) {
                                        val detectedMime = choice.mimeType ?: if (next.substringBefore('?').endsWith(".m3u8", true)) "application/vnd.apple.mpegurl" else null
                                        selectedVideoUrl = next
                                        selectedVideoMime = detectedMime
                                        exoPlayer.setMediaSource(createCurrentMediaSource(next, activeSubtitleUrl, detectedMime, activeAudioChoice), position)
                                        exoPlayer.prepare(); exoPlayer.playWhenReady = true
                                    }
                                    showTrackDialog = false
                                }) { Text(choice.label) }
                            }
                        }
                        Text("صدای جایگزین", style = MaterialTheme.typography.titleSmall)
                        if (audioChoices.isEmpty()) {
                            Text("انتخاب صدای جداگانه‌ای برای این محتوا ثبت نشده است.", style = MaterialTheme.typography.bodySmall)
                        } else audioChoices.forEach { choice ->
                            TextButton(onClick = {
                                val next = choice.url
                                if (!next.isNullOrBlank()) {
                                    val position = exoPlayer.currentPosition
                                    activeAudioChoice = choice
                                    exoPlayer.setMediaSource(createCurrentMediaSource(selectedVideoUrl, activeSubtitleUrl, selectedVideoMime, choice), position)
                                    exoPlayer.prepare(); exoPlayer.playWhenReady = true
                                }
                                showTrackDialog = false
                            }) { Text(choice.label) }
                        }
                        Text("زیرنویس", style = MaterialTheme.typography.titleSmall)
                        TextButton(onClick = {
                            showSubtitle = false
                            activeSubtitleUrl = null
                            val pos = exoPlayer.currentPosition
                            exoPlayer.setMediaSource(createCurrentMediaSource(selectedVideoUrl, null, selectedVideoMime, activeAudioChoice), pos)
                            exoPlayer.prepare(); exoPlayer.playWhenReady = true
                        }) { Text("بدون زیرنویس") }
                        subtitleChoices.forEach { choice ->
                            TextButton(onClick = {
                                val url = choice.url
                                if (!url.isNullOrBlank()) {
                                    activeSubtitleUrl = url
                                    val pos = exoPlayer.currentPosition
                                    exoPlayer.setMediaSource(createCurrentMediaSource(selectedVideoUrl, url, selectedVideoMime, activeAudioChoice), pos)
                                    exoPlayer.prepare(); exoPlayer.playWhenReady = true
                                    showSubtitle = true
                                }
                                showTrackDialog = false
                            }) { Text(choice.label) }
                        }
                        if (tracksSnapshot.groups.isNotEmpty()) {
                            Text("ترک‌های داخلی HLS", style = MaterialTheme.typography.titleSmall)
                            tracksSnapshot.groups.forEach { group ->
                                if (group.type == C.TRACK_TYPE_VIDEO || group.type == C.TRACK_TYPE_AUDIO || group.type == C.TRACK_TYPE_TEXT) {
                                    for (trackIndex in 0 until group.length) {
                                        val format = group.getTrackFormat(trackIndex)
                                        val label = format.label ?: format.language ?: if (group.type == C.TRACK_TYPE_VIDEO && format.height > 0) "${format.height}p" else "ترک ${trackIndex + 1}"
                                        TextButton(onClick = {
                                            val builder = exoPlayer.trackSelectionParameters.buildUpon()
                                                .clearOverridesOfType(group.type)
                                                .setTrackTypeDisabled(group.type, false)
                                                .addOverride(TrackSelectionOverride(group.mediaTrackGroup, listOf(trackIndex)))
                                            exoPlayer.trackSelectionParameters = builder.build()
                                            showTrackDialog = false
                                        }) { Text(label) }
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { showTrackDialog = false }) { Text("بستن") } }
            )
        }
    }
}
