package com.cinemaplus.app.ui.subscription

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.cinemaplus.app.data.api.CinemaApi
import com.cinemaplus.app.data.model.PlanDto
import com.cinemaplus.app.data.model.SubscriptionStatus
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubscriptionScreen(
    api: CinemaApi,
    onBack: () -> Unit
) {
    var plans by remember { mutableStateOf<List<PlanDto>>(emptyList()) }
    var status by remember { mutableStateOf<SubscriptionStatus?>(null) }
    var loading by remember { mutableStateOf(true) }
    var message by remember { mutableStateOf<String?>(null) }
    var paying by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun reload() {
        scope.launch {
            loading = true
            try {
                plans = api.plans()
                status = api.mySubscription()
            } catch (e: Exception) {
                message = e.message
            } finally {
                loading = false
            }
        }
    }

    LaunchedEffect(Unit) { reload() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("اشتراک") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, null)
                    }
                }
            )
        }
    ) { padding ->
        if (loading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            LazyColumn(
                Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("وضعیت اشتراک", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(8.dp))
                            when {
                                status?.hasAccess == true && status?.type == "admin" ->
                                    Text("دسترسی مدیر — نامحدود", color = MaterialTheme.colorScheme.primary)
                                status?.hasAccess == true && status?.type == "free_trial" ->
                                    Text("دوره رایگان تا ${status?.endsAt?.take(10) ?: ""}")
                                status?.hasAccess == true ->
                                    Text("فعال (${status?.type}) تا ${status?.endsAt?.take(10) ?: ""}")
                                else ->
                                    Text("اشتراک غیرفعال — برای تماشا و دانلود اشتراک تهیه کنید", color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
                item {
                    Text("پلن‌ها", style = MaterialTheme.typography.titleMedium)
                }
                items(plans) { plan ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text(plan.name, style = MaterialTheme.typography.titleMedium)
                            Text("${plan.duration_days} روز")
                            Text("%,d تومان".format(plan.price), style = MaterialTheme.typography.titleLarge)
                            Spacer(Modifier.height(8.dp))
                            Button(
                                onClick = {
                                    paying = true
                                    scope.launch {
                                        try {
                                            val payRes = api.pay(mapOf("plan_id" to plan.id))
                                            val authority = payRes["authority"] as? String
                                            if (authority != null) {
                                                // پرداخت آزمایشی: مستقیم تأیید
                                                val verify = api.verifyMock(authority)
                                                message = verify["message"] as? String ?: "اشتراک فعال شد"
                                                reload()
                                            }
                                        } catch (e: Exception) {
                                            message = e.message
                                        } finally {
                                            paying = false
                                        }
                                    }
                                },
                                enabled = !paying,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(if (paying) "در حال پرداخت..." else "خرید (آزمایشی)")
                            }
                        }
                    }
                }
                message?.let {
                    item {
                        Text(it, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}
