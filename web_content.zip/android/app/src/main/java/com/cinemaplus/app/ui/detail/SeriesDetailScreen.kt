package com.cinemaplus.app.ui.detail

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.cinemaplus.app.data.api.CinemaApi
import com.cinemaplus.app.data.model.*
import com.cinemaplus.app.ui.player.PlayInfo
import com.cinemaplus.app.util.DownloadHelper
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SeriesDetailScreen(
    seriesId: Int,
    api: CinemaApi,
    onBack: () -> Unit,
    onPlay: (PlayInfo) -> Unit,
    onNeedSubscription: () -> Unit
) {
    var series by remember { mutableStateOf<SeriesDto?>(null) }
    var comments by remember { mutableStateOf<List<CommentDto>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var commentText by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    fun reload() {
        scope.launch {
            loading = true
            try {
                series = api.seriesDetail(seriesId)
                comments = api.comments("series", seriesId)
            } catch (e: Exception) {
                error = e.message
            } finally {
                loading = false
            }
        }
    }

    LaunchedEffect(seriesId) { reload() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(series?.title ?: "سریال", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, null)
                    }
                }
            )
        }
    ) { padding ->
        if (loading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else if (series != null) {
            val s = series!!
            LazyColumn(
                Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        AsyncImage(
                            model = s.poster_url,
                            contentDescription = s.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.width(120.dp).height(180.dp).clip(RoundedCornerShape(8.dp))
                        )
                        Column {
                            Text(s.title, style = MaterialTheme.typography.titleLarge)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Star, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                Text(" ${s.rating_avg}  •  ${s.view_count} بازدید")
                            }
                            Text("${s.year ?: ""} • ${s.genre ?: ""}")
                        }
                    }
                }
                item { Text(s.description ?: "") }

                s.seasons?.forEach { season ->
                    item {
                        Text(season.title ?: "فصل ${season.season_number}", style = MaterialTheme.typography.titleMedium)
                    }
                    items(season.episodes ?: emptyList()) { ep ->
                        Card(Modifier.fillMaxWidth()) {
                            Row(
                                Modifier.padding(12.dp).fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text("قسمت ${ep.episode_number}: ${ep.title ?: ""}")
                                    Text("${ep.duration ?: 0} ثانیه", style = MaterialTheme.typography.labelSmall)
                                }
                                IconButton(onClick = {
                                    scope.launch {
                                        try {
                                            val play = api.playEpisode(ep.id)
                                            onPlay(PlayInfo(play.id, play.title, play.video_url, play.subtitle_url, play.allow_download, play.video_mime_type, (play.resume_position ?: 0).toLong(), play.quality_options.map { com.cinemaplus.app.ui.player.PlaybackChoice(it.label ?: it.name ?: it.quality ?: "کیفیت", it.url, it.language, it.mime_type, it.default) }, play.audio_tracks.map { com.cinemaplus.app.ui.player.PlaybackChoice(it.label ?: it.name ?: it.language ?: "صدا", it.url, it.language, it.mime_type, it.default) }, play.subtitle_tracks.map { com.cinemaplus.app.ui.player.PlaybackChoice(it.label ?: it.name ?: it.language ?: "زیرنویس", it.url, it.language, it.mime_type, it.default) }, "episode")
                                        } catch (e: Exception) {
                                            onNeedSubscription()
                                        }
                                    }
                                }) {
                                    Icon(Icons.Default.PlayArrow, "پخش")
                                }
                                IconButton(onClick = {
                                    scope.launch {
                                        try {
                                            val res = api.requestDownload(DownloadRequest("episode", ep.id))
                                            val url = res["video_url"] as? String
                                            val sub = res["subtitle_url"] as? String
                                            if (url != null) {
                                                DownloadHelper.downloadVideo(context, ep.title ?: "episode", url, sub)
                                            }
                                        } catch (_: Exception) {
                                            onNeedSubscription()
                                        }
                                    }
                                }) {
                                    Icon(Icons.Default.Download, "دانلود")
                                }
                            }
                        }
                    }
                }

                item { Text("نظرات (${comments.size})", style = MaterialTheme.typography.titleMedium) }
                items(comments) { c ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text(c.username, style = MaterialTheme.typography.labelLarge)
                            Text(c.body)
                        }
                    }
                }
                item {
                    OutlinedTextField(
                        value = commentText,
                        onValueChange = { commentText = it },
                        label = { Text("نظر شما") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            scope.launch {
                                try {
                                    api.postComment("series", seriesId, mapOf("body" to commentText))
                                    commentText = ""
                                    comments = api.comments("series", seriesId)
                                } catch (_: Exception) {}
                            }
                        },
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                    ) { Text("ارسال نظر") }
                }
            }
        } else {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text(error ?: "یافت نشد")
            }
        }
    }
}
