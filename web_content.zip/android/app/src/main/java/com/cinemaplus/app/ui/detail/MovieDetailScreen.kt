package com.cinemaplus.app.ui.detail

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.cinemaplus.app.data.api.CinemaApi
import com.cinemaplus.app.data.model.*
import com.cinemaplus.app.ui.player.PlayInfo
import com.cinemaplus.app.util.DownloadHelper
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MovieDetailScreen(
    movieId: Int,
    api: CinemaApi,
    onBack: () -> Unit,
    onPlay: (PlayInfo) -> Unit,
    onNeedSubscription: () -> Unit
) {
    var movie by remember { mutableStateOf<MovieDto?>(null) }
    var comments by remember { mutableStateOf<List<CommentDto>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var commentText by remember { mutableStateOf("") }
    var ratingScore by remember { mutableStateOf(8) }
    var message by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    fun reload() {
        scope.launch {
            loading = true
            error = null
            try {
                movie = api.movieDetail(movieId)
                comments = api.comments("movie", movieId)
            } catch (e: Exception) {
                error = e.message
            } finally {
                loading = false
            }
        }
    }

    LaunchedEffect(movieId) { reload() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(movie?.title ?: "جزئیات فیلم", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                }
            )
        }
    ) { padding ->
        when {
            loading -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            error != null -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(error ?: "خطا")
                    Button(onClick = { reload() }) { Text("تلاش مجدد") }
                }
            }
            movie != null -> {
                val m = movie!!
                LazyColumn(
                    Modifier.fillMaxSize().padding(padding),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            AsyncImage(
                                model = m.poster_url,
                                contentDescription = m.title,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .width(120.dp)
                                    .height(180.dp)
                                    .clip(RoundedCornerShape(8.dp))
                            )
                            Column(Modifier.weight(1f)) {
                                Text(m.title, style = MaterialTheme.typography.titleLarge)
                                Spacer(Modifier.height(8.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Star, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("${m.rating_avg} (${m.rating_count} رأی)")
                                }
                                Text("${m.view_count} بازدید", style = MaterialTheme.typography.bodySmall)
                                Text("${m.year ?: ""} • ${m.genre ?: ""}", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    item {
                        Text(m.description ?: "", style = MaterialTheme.typography.bodyMedium)
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    scope.launch {
                                        try {
                                            val play = api.playMovie(movieId)
                                            onPlay(
                                                PlayInfo(
                                                    id = play.id,
                                                    title = play.title,
                                                    videoUrl = play.video_url,
                                                    subtitleUrl = play.subtitle_url,
                                                    allowDownload = play.allow_download,
                                                    videoMimeType = play.video_mime_type,
                                                    resumePosition = (play.resume_position ?: 0).toLong(),
                                                    qualityOptions = play.quality_options.map { com.cinemaplus.app.ui.player.PlaybackChoice(it.label ?: it.name ?: it.quality ?: "کیفیت", it.url, it.language, it.mime_type, it.default) },
                                                    audioTracks = play.audio_tracks.map { com.cinemaplus.app.ui.player.PlaybackChoice(it.label ?: it.name ?: it.language ?: "صدا", it.url, it.language, it.mime_type, it.default) },
                                                    subtitleTracks = play.subtitle_tracks.map { com.cinemaplus.app.ui.player.PlaybackChoice(it.label ?: it.name ?: it.language ?: "زیرنویس", it.url, it.language, it.mime_type, it.default) },
                                                    contentType = "movie"
                                                )
                                            )
                                        } catch (e: Exception) {
                                            if (e.message?.contains("403") == true || e.message?.contains("اشتراک") == true) {
                                                onNeedSubscription()
                                            } else {
                                                message = e.message
                                            }
                                        }
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.PlayArrow, null)
                                Spacer(Modifier.width(4.dp))
                                Text("پخش")
                            }
                            OutlinedButton(
                                onClick = {
                                    scope.launch {
                                        try {
                                            val res = api.requestDownload(DownloadRequest("movie", movieId))
                                            val videoUrl = res["video_url"] as? String
                                            val subUrl = res["subtitle_url"] as? String
                                            if (videoUrl != null) {
                                                DownloadHelper.downloadVideo(context, m.title, videoUrl, subUrl)
                                                message = "دانلود شروع شد"
                                            }
                                        } catch (e: Exception) {
                                            if (e.message?.contains("403") == true) onNeedSubscription()
                                            else message = e.message
                                        }
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Download, null)
                                Spacer(Modifier.width(4.dp))
                                Text("دانلود")
                            }
                        }
                    }
                    item {
                        Text("امتیاز شما", style = MaterialTheme.typography.titleSmall)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Slider(
                                value = ratingScore.toFloat(),
                                onValueChange = { ratingScore = it.toInt() },
                                valueRange = 1f..10f,
                                steps = 8,
                                modifier = Modifier.weight(1f)
                            )
                            Text("$ratingScore")
                            Spacer(Modifier.width(8.dp))
                            TextButton(onClick = {
                                scope.launch {
                                    try {
                                        api.rate("movie", movieId, mapOf("score" to ratingScore))
                                        message = "امتیاز ثبت شد"
                                        reload()
                                    } catch (e: Exception) {
                                        message = e.message
                                    }
                                }
                            }) { Text("ثبت") }
                        }
                    }
                    item {
                        Text("نظرات (${comments.size})", style = MaterialTheme.typography.titleMedium)
                    }
                    items(comments) { c ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp)) {
                                Text(c.username, style = MaterialTheme.typography.labelLarge)
                                Text(c.body, style = MaterialTheme.typography.bodyMedium)
                                Text(c.created_at.take(16), style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                    item {
                        OutlinedTextField(
                            value = commentText,
                            onValueChange = { commentText = it },
                            label = { Text("نظر شما") },
                            modifier = Modifier.fillMaxWidth(),
                            maxLines = 3
                        )
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = {
                                if (commentText.isBlank()) return@Button
                                scope.launch {
                                    try {
                                        api.postComment("movie", movieId, mapOf("body" to commentText))
                                        commentText = ""
                                        comments = api.comments("movie", movieId)
                                        message = "نظر ثبت شد"
                                    } catch (e: Exception) {
                                        message = e.message
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("ارسال نظر") }
                    }
                    item { Spacer(Modifier.height(24.dp)) }
                }
                message?.let {
                    LaunchedEffect(it) {
                        kotlinx.coroutines.delay(2500)
                        message = null
                    }
                    // simple snack via text at bottom could be added
                }
            }
        }
    }
}
