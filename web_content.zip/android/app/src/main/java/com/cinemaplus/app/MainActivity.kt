package com.cinemaplus.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.cinemaplus.app.data.api.ApiClient
import com.cinemaplus.app.data.api.TokenManager
import com.cinemaplus.app.ui.auth.LoginScreen
import com.cinemaplus.app.ui.detail.MovieDetailScreen
import com.cinemaplus.app.ui.detail.SeriesDetailScreen
import com.cinemaplus.app.ui.home.MainTabsScreen
import com.cinemaplus.app.ui.player.PlayInfo
import com.cinemaplus.app.ui.player.PlayerScreen
import com.cinemaplus.app.ui.subscription.SubscriptionScreen
import com.cinemaplus.app.ui.theme.CinemaGoldTheme
import com.cinemaplus.app.util.DownloadHelper
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val tokenManager = TokenManager(this)
        val api = ApiClient.create(this)

        setContent {
            CinemaGoldTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    val navController = rememberNavController()
                    val appScope = rememberCoroutineScope()
                    var startDest by remember { mutableStateOf<String?>(null) }
                    var currentPlay by remember { mutableStateOf<PlayInfo?>(null) }

                    LaunchedEffect(Unit) {
                        val token = tokenManager.tokenFlow.first()
                        startDest = if (!token.isNullOrBlank()) "main" else "login"
                    }

                    if (startDest == null) return@Surface

                    NavHost(navController = navController, startDestination = startDest!!) {
                        composable("login") {
                            LoginScreen(
                                api = api,
                                tokenManager = tokenManager,
                                onSuccess = {
                                    navController.navigate("main") {
                                        popUpTo("login") { inclusive = true }
                                    }
                                }
                            )
                        }
                        composable("main") {
                            MainTabsScreen(
                                api = api,
                                onLogout = {
                                    runBlocking {
                                        try { api.logout() } catch (_: Exception) { }
                                        tokenManager.clear()
                                    }
                                    navController.navigate("login") {
                                        popUpTo(0) { inclusive = true }
                                    }
                                },
                                onOpenMovie = { id -> navController.navigate("movie/$id") },
                                onOpenSeries = { id -> navController.navigate("series/$id") },
                                onOpenSubscription = { navController.navigate("subscription") },
                                onOpenContinue = { item ->
                                    appScope.launch {
                                        try {
                                            val fresh = if (item.type == "episode") api.playEpisode(item.id) else api.playMovie(item.id)
                                            currentPlay = PlayInfo(
                                                id = fresh.id, title = fresh.title, videoUrl = fresh.video_url,
                                                subtitleUrl = fresh.subtitle_url, allowDownload = fresh.allow_download,
                                                videoMimeType = fresh.video_mime_type,
                                                resumePosition = (fresh.resume_position ?: item.position_seconds).toLong(),
                                                qualityOptions = fresh.quality_options.map { com.cinemaplus.app.ui.player.PlaybackChoice(it.label ?: it.name ?: it.quality ?: "کیفیت", it.url, it.language, it.mime_type, it.default) },
                                                audioTracks = fresh.audio_tracks.map { com.cinemaplus.app.ui.player.PlaybackChoice(it.label ?: it.name ?: it.language ?: "صدا", it.url, it.language, it.mime_type, it.default) },
                                                subtitleTracks = fresh.subtitle_tracks.map { com.cinemaplus.app.ui.player.PlaybackChoice(it.label ?: it.name ?: it.language ?: "زیرنویس", it.url, it.language, it.mime_type, it.default) },
                                                contentType = item.type
                                            )
                                            navController.navigate("player")
                                        } catch (_: Exception) { /* Home shelf remains available for retry. */ }
                                    }
                                }
                            )
                        }
                        composable(
                            "movie/{id}",
                            arguments = listOf(navArgument("id") { type = NavType.IntType })
                        ) { entry ->
                            val id = entry.arguments?.getInt("id") ?: return@composable
                            MovieDetailScreen(
                                movieId = id,
                                api = api,
                                onBack = { navController.popBackStack() },
                                onPlay = { info ->
                                    currentPlay = info
                                    navController.navigate("player")
                                },
                                onNeedSubscription = { navController.navigate("subscription") }
                            )
                        }
                        composable(
                            "series/{id}",
                            arguments = listOf(navArgument("id") { type = NavType.IntType })
                        ) { entry ->
                            val id = entry.arguments?.getInt("id") ?: return@composable
                            SeriesDetailScreen(
                                seriesId = id,
                                api = api,
                                onBack = { navController.popBackStack() },
                                onPlay = { info ->
                                    currentPlay = info
                                    navController.navigate("player")
                                },
                                onNeedSubscription = { navController.navigate("subscription") }
                            )
                        }
                        composable("subscription") {
                            SubscriptionScreen(
                                api = api,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("player") {
                            val play = currentPlay
                            if (play != null) {
                                PlayerScreen(
                                    playInfo = play,
                                    onBack = { navController.popBackStack() },
                                    onDownload = { info ->
                                        DownloadHelper.downloadVideo(
                                            this@MainActivity,
                                            info.title,
                                            info.videoUrl,
                                            info.subtitleUrl
                                        )
                                    },
                                    onRefreshPlayInfo = {
                                        val fresh = if (play.contentType == "episode") api.playEpisode(play.id) else api.playMovie(play.id)
                                        PlayInfo(
                                            id = fresh.id, title = fresh.title, videoUrl = fresh.video_url,
                                            subtitleUrl = fresh.subtitle_url, allowDownload = fresh.allow_download,
                                            videoMimeType = fresh.video_mime_type,
                                            resumePosition = (fresh.resume_position ?: 0).toLong(),
                                            qualityOptions = fresh.quality_options.map { com.cinemaplus.app.ui.player.PlaybackChoice(it.label ?: it.name ?: it.quality ?: "کیفیت", it.url, it.language, it.mime_type, it.default) },
                                            audioTracks = fresh.audio_tracks.map { com.cinemaplus.app.ui.player.PlaybackChoice(it.label ?: it.name ?: it.language ?: "صدا", it.url, it.language, it.mime_type, it.default) },
                                            subtitleTracks = fresh.subtitle_tracks.map { com.cinemaplus.app.ui.player.PlaybackChoice(it.label ?: it.name ?: it.language ?: "زیرنویس", it.url, it.language, it.mime_type, it.default) },
                                            contentType = play.contentType
                                        )
                                    },
                                    onSaveProgress = { info, positionSeconds ->
                                        api.saveWatchProgress(mapOf(
                                            "type" to info.contentType,
                                            "id" to info.id,
                                            "position_seconds" to positionSeconds
                                        ))
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

class CinemaPlusApp : android.app.Application()
