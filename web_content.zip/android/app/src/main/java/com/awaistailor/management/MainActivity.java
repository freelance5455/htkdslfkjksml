package com.awaistailor.management;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
