package com.iphonelauncher.app;

import android.app.role.RoleManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Build;
import android.provider.Settings;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.PluginMethod;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

@CapacitorPlugin(name = "LauncherNative")
public class LauncherNativePlugin extends Plugin {
    @PluginMethod
    public void launchPackage(PluginCall call) {
        String packageName = call.getString("packageName");
        if (packageName == null || packageName.trim().isEmpty()) {
            call.reject("Missing packageName");
            return;
        }

        PackageManager pm = getContext().getPackageManager();
        Intent launchIntent = pm.getLaunchIntentForPackage(packageName);
        if (launchIntent == null) {
            call.resolve(result(false));
            return;
        }

        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            getContext().startActivity(launchIntent);
            call.resolve(result(true));
        } catch (Exception ex) {
            call.reject("Unable to launch application", ex);
        }
    }

    @PluginMethod
    public void openHomeSettings(PluginCall call) {
        try {
            Intent intent = new Intent(Settings.ACTION_HOME_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
            call.resolve(result(true));
        } catch (Exception ex) {
            try {
                Intent fallback = new Intent(Settings.ACTION_SETTINGS);
                fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(fallback);
                call.resolve(result(true));
            } catch (Exception inner) {
                call.reject("Unable to open Android Home settings", inner);
            }
        }
    }

    @PluginMethod
    public void isDefaultHome(PluginCall call) {
        boolean isDefault = false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            RoleManager roleManager = (RoleManager) getContext().getSystemService(Context.ROLE_SERVICE);
            if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_HOME)) {
                isDefault = roleManager.isRoleHeld(RoleManager.ROLE_HOME);
            }
        } else {
            Intent homeIntent = new Intent(Intent.ACTION_MAIN);
            homeIntent.addCategory(Intent.CATEGORY_HOME);
            ResolveInfo resolved = getContext().getPackageManager().resolveActivity(homeIntent, PackageManager.MATCH_DEFAULT_ONLY);
            isDefault = resolved != null && getContext().getPackageName().equals(resolved.activityInfo.packageName);
        }
        JSObject ret = new JSObject();
        ret.put("value", isDefault);
        call.resolve(ret);
    }

    @PluginMethod
    public void getInstalledApps(PluginCall call) {
        PackageManager pm = getContext().getPackageManager();
        Intent intent = new Intent(Intent.ACTION_MAIN, null);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> activities = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL);
        Collections.sort(activities, new Comparator<ResolveInfo>() {
            @Override public int compare(ResolveInfo a, ResolveInfo b) {
                String an = String.valueOf(a.loadLabel(pm));
                String bn = String.valueOf(b.loadLabel(pm));
                return an.compareToIgnoreCase(bn);
            }
        });

        JSArray apps = new JSArray();
        String self = getContext().getPackageName();
        for (ResolveInfo info : activities) {
            if (info.activityInfo == null) continue;
            String pkg = info.activityInfo.packageName;
            if (self.equals(pkg)) continue;
            ApplicationInfo ai;
            try { ai = pm.getApplicationInfo(pkg, 0); } catch (Exception ignored) { continue; }
            JSObject app = new JSObject();
            app.put("packageName", pkg);
            app.put("name", String.valueOf(pm.getApplicationLabel(ai)));
            apps.put(app);
        }
        JSObject ret = new JSObject();
        ret.put("apps", apps);
        call.resolve(ret);
    }

    private JSObject result(boolean value) {
        JSObject ret = new JSObject();
        ret.put("completed", value);
        return ret;
    }
}
