package com.caliber.ff.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caliber.ff.CaliberViewModel
import com.caliber.ff.engine.CaliberEngine
import com.caliber.ff.ui.theme.Accent
import com.caliber.ff.ui.theme.Bg
import com.caliber.ff.ui.theme.Fg
import com.caliber.ff.ui.theme.Muted
import com.caliber.ff.ui.theme.Primary
import com.caliber.ff.ui.theme.Surface

@Composable
fun CaliberRoot(vm: CaliberViewModel) {
    val state by vm.state.collectAsState()
    val dir = if (state.lang == "ar") LayoutDirection.Rtl else LayoutDirection.Ltr
    CompositionLocalProvider(LocalLayoutDirection provides dir) {
        Box(Modifier.fillMaxSize().background(Bg)) {
            when (state.phase) {
                "scanning" -> ScanScreen(state.lang)
                "results" -> ResultsScreen(vm)
                else -> HomeScreen(state.lang, vm)
            }
        }
    }
}

@Composable
private fun HomeScreen(lang: String, vm: CaliberViewModel) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("CALIBER", color = Primary, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
        Spacer(Modifier.height(12.dp))
        Text(
            if (lang == "ar") "إعدادات فري فاير حسب عتاد جهازك" else "Hardware-tuned Free Fire settings",
            color = Fg,
            fontSize = 28.sp,
            fontWeight = FontWeight.SemiBold,
            lineHeight = 32.sp,
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = { vm.scan() }, modifier = Modifier.fillMaxWidth()) {
            Text(if (lang == "ar") "افحص هذا الجهاز" else "Scan this device")
        }
        TextButton(onClick = { vm.toggleLang() }) {
            Text(if (lang == "ar") "English" else "العربية", color = Muted)
        }
    }
}

@Composable
private fun ScanScreen(lang: String) {
    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            if (lang == "ar") "جاري فحص العتاد" else "Probing hardware",
            color = Primary,
            fontSize = 22.sp,
            fontWeight = FontWeight.SemiBold,
        )
        Spacer(Modifier.height(16.dp))
        LinearProgressIndicator(color = Primary)
    }
}

@Composable
private fun ResultsScreen(vm: CaliberViewModel) {
    val state by vm.state.collectAsState()
    val hw = state.hardware ?: return
    val settings = state.settings ?: return
    val ctx = LocalContext.current
    val ar = state.lang == "ar"
    val blob = CaliberEngine.format(hw, settings)

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column {
                Text("CALIBER", color = Primary, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                Text("${hw.manufacturer} ${hw.model}", color = Muted, fontSize = 12.sp)
            }
            Row {
                TextButton(onClick = { vm.toggleLang() }) { Text(if (ar) "EN" else "ع", color = Fg) }
                TextButton(onClick = { vm.reset() }) { Text(if (ar) "إعادة" else "Re-scan", color = Fg) }
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("specs", "settings", "touch").forEach { id ->
                val label = when (id) {
                    "specs" -> if (ar) "المواصفات" else "Specs"
                    "settings" -> if (ar) "إعدادات" else "Settings"
                    else -> if (ar) "لمس" else "Touch"
                }
                if (state.tab == id) Button(onClick = { vm.setTab(id) }, modifier = Modifier.weight(1f)) { Text(label) }
                else OutlinedButton(onClick = { vm.setTab(id) }, modifier = Modifier.weight(1f)) { Text(label) }
            }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp)) {
            when (state.tab) {
                "specs" -> {
                    SpecRow(if (ar) "المعالج" else "CPU", hw.socName, "${hw.cpuCores} cores")
                    SpecRow(if (ar) "رسوميات" else "GPU", hw.gpuName, hw.abi)
                    SpecRow("RAM", "${hw.ramGb} GB ${hw.ramType}", if (hw.ramTypeEstimated) "estimated" else hw.ramType)
                    SpecRow(if (ar) "تخزين" else "Storage", hw.storageType, hw.storageGb?.let { "$it GB" } ?: "Unavailable")
                    SpecRow(
                        if (ar) "شاشة" else "Display",
                        "${hw.displayWidth}×${hw.displayHeight}  ${hw.displayInches}\"",
                        "${hw.refreshRate.toInt()} Hz · ${hw.densityDpi} dpi · touch ${hw.touchSamplingHz} Hz",
                    )
                    SpecRow(
                        if (ar) "بطارية" else "Battery",
                        hw.batteryLevel?.let { "$it%" } ?: "Unavailable",
                        hw.batteryTempC?.let { "$it °C" } ?: "temp Unavailable",
                    )
                    SpecRow("Thermal", hw.thermalStatus.name.lowercase(), "Android ${hw.androidVersion}")
                    SpecRow("System", hw.model, "patch ${hw.securityPatch}")
                    hw.notes.forEach { Text(it, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp)) }
                }
                "settings" -> {
                    Text("${settings.performanceScore}/100", color = Accent, fontSize = 40.sp, fontWeight = FontWeight.Bold)
                    Sense("General", settings.sensitivity.general)
                    Sense("Red Dot", settings.sensitivity.redDot)
                    Sense("2x", settings.sensitivity.scope2x)
                    Sense("4x", settings.sensitivity.scope4x)
                    Sense("AWM", settings.sensitivity.awm)
                    Sense("Free Look", settings.sensitivity.freeLook)
                    Spacer(Modifier.height(12.dp))
                    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Surface).padding(16.dp)) {
                        Column {
                            Text(if (ar) "DPI الموصى به" else "Recommended DPI", color = Muted, fontSize = 12.sp)
                            Text("${settings.dpi.recommended}", color = Primary, fontSize = 36.sp, fontWeight = FontWeight.Bold)
                            Text("Original ${settings.dpi.originalDpi} — write this down before applying.", color = Muted, fontSize = 12.sp)
                            Text(settings.dpi.adbSet, color = Accent, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                            Text(settings.dpi.adbReset, color = Muted, fontSize = 12.sp)
                            Text("Developer options → Smallest width → ${settings.dpi.smallestWidth}", color = Muted, fontSize = 12.sp)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Surface).padding(16.dp)) {
                        Column {
                            Text(if (ar) "حجم زر الإطلاق" else "Fire button size", color = Muted, fontSize = 12.sp)
                            Text("${settings.fireButtonPercent}%", color = Accent, fontSize = 36.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Graphics ${settings.graphics.preset} · FPS ${settings.graphics.fpsOption} · High FPS ${if (settings.graphics.highFps) "ON" else "OFF"}", color = Fg)
                    settings.graphics.extras.forEach { Text("· $it", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp)) }
                }
                else -> TouchPad(ar) { vm.applyTouch(it) }
            }
        }
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { copy(ctx, blob) }, modifier = Modifier.weight(1f)) {
                Text(if (ar) "نسخ" else "Copy all")
            }
            OutlinedButton(onClick = { share(ctx, blob) }, modifier = Modifier.weight(1f)) {
                Text(if (ar) "مشاركة" else "Share")
            }
        }
    }
}

@Composable
private fun SpecRow(title: String, body: String, meta: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp).clip(RoundedCornerShape(12.dp)).background(Surface).padding(12.dp)) {
        Text(title.uppercase(), color = Muted, fontSize = 11.sp, letterSpacing = 1.sp)
        Text(body, color = Fg, fontSize = 15.sp)
        Text(meta, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun Sense(label: String, value: Int) {
    val anim by animateFloatAsState(value / 200f, label = label)
    Column(Modifier.padding(vertical = 6.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Muted)
            Text("$value / 200", color = Fg, fontWeight = FontWeight.SemiBold)
        }
        LinearProgressIndicator(progress = { anim }, modifier = Modifier.fillMaxWidth().height(8.dp), color = Primary)
    }
}

@Composable
private fun TouchPad(ar: Boolean, onResult: (Int) -> Unit) {
    var stamps by remember { mutableStateOf(listOf<Long>()) }
    var result by remember { mutableStateOf<Int?>(null) }
    Column {
        Text(
            if (ar) "اسحب إصبعك لمدة 4 ثوان" else "Drag a finger across this pad for 4 seconds.",
            color = Muted,
        )
        Spacer(Modifier.height(8.dp))
        Box(
            Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(16.dp)).background(Surface)
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { stamps = listOf(System.nanoTime()) },
                        onDrag = { _, _ -> stamps = stamps + System.nanoTime() },
                        onDragEnd = {
                            val deltas = stamps.zipWithNext { a, b -> (b - a) / 1_000_000.0 }
                            if (deltas.size >= 8) {
                                val median = deltas.sorted()[deltas.size / 2]
                                val raw = 1000.0 / maxOf(median, 2.0)
                                val common = listOf(60, 90, 120, 180, 240, 360)
                                result = common.minBy { kotlin.math.abs(it - raw) }
                            }
                        },
                    )
                },
            contentAlignment = Alignment.Center,
        ) {
            Text(if (ar) "اضغط واسحب هنا" else "Hold and drag here", color = Fg)
        }
        result?.let { hz ->
            Spacer(Modifier.height(12.dp))
            Text("$hz Hz", color = Accent, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Button(onClick = { onResult(hz) }) { Text(if (ar) "استخدم هذا المعدل" else "Use this rate") }
        }
    }
}

private fun copy(ctx: Context, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("caliber", text))
}

private fun share(ctx: Context, text: String) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    ctx.startActivity(Intent.createChooser(intent, "Caliber"))
}
