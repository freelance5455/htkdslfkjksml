package com.caliber.ff.detection

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.opengl.EGL14
import android.opengl.GLES20
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.os.StatFs
import android.util.DisplayMetrics
import android.view.WindowManager
import com.caliber.ff.model.HardwareProfile
import com.caliber.ff.model.ThermalStatus
import java.io.File
import kotlin.math.hypot
import kotlin.math.roundToInt

/**
 * Reads every userspace hardware surface the brief asked for, and degrades to
 * "Unavailable" / an estimate instead of crashing when SELinux or the OEM
 * blocks a node.
 */
object HardwareScanner {

    fun scan(context: Context, touchHz: Int?, touchEstimated: Boolean): HardwareProfile {
        val notes = mutableListOf<String>()

        val socName = readSocName()
        val soc = SocClassifier.classify(socName)
        val cores = Runtime.getRuntime().availableProcessors()
        val freqs = readCoreFreqs()
        if (freqs.isEmpty()) notes += "Per-core max clocks were not readable on this firmware."

        val gpu = readGpuRenderer()
        val gpuClass = SocClassifier.classify(gpu)

        val ram = readRam(context)
        val ramGb = (ram.totalMb / 1024.0).roundToInt().coerceAtLeast(1)
        val ramAvail = ram.availMb / 1024.0

        val storage = readStorage()
        val display = readDisplay(context)
        val battery = readBattery(context)
        val thermal = readThermal(context)

        val touch = touchHz ?: estimateTouch(display.refreshRate.roundToInt())

        return HardwareProfile(
            manufacturer = Build.MANUFACTURER.replaceFirstChar { it.uppercase() },
            model = Build.MODEL,
            androidVersion = Build.VERSION.RELEASE ?: "Unavailable",
            securityPatch = Build.VERSION.SECURITY_PATCH ?: "Unavailable",
            socName = socName,
            socFamily = soc.family,
            cpuTier = soc.tier,
            cpuCores = cores,
            cpuMaxFreqKhz = freqs,
            abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "Unavailable",
            gpuName = gpu,
            gpuTier = gpuClass.tier,
            ramGb = ramGb,
            ramAvailableGb = ramAvail,
            ramType = soc.ramType,
            ramTypeEstimated = true,
            storageGb = storage.sizeGb,
            storageType = storage.type,
            storageTypeEstimated = storage.estimated,
            displayWidth = display.width,
            displayHeight = display.height,
            displayInches = display.inches,
            displayInchesEstimated = false,
            refreshRate = display.refreshRate,
            supportedRefreshRates = display.supported,
            densityDpi = display.dpi,
            defaultDpi = display.dpi,
            touchSamplingHz = touch,
            touchSamplingEstimated = touchEstimated || touchHz == null,
            batteryLevel = battery.level,
            batteryTempC = battery.tempC,
            thermalStatus = thermal,
            notes = notes,
        )
    }

    private fun readSocName(): String {
        val parts = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            Build.SOC_MODEL.takeIf { it.isNotBlank() && it != Build.UNKNOWN }?.let { parts += it }
            Build.SOC_MANUFACTURER.takeIf { it.isNotBlank() && it != Build.UNKNOWN }?.let { parts += it }
        }
        Build.HARDWARE.takeIf { it.isNotBlank() && it != Build.UNKNOWN }?.let { parts += it }
        Build.BOARD.takeIf { it.isNotBlank() && it != Build.UNKNOWN }?.let { parts += it }
        readProcCpuinfo()?.let { parts += it }
        return parts.firstOrNull { it.isNotBlank() } ?: "Unavailable"
    }

    private fun readProcCpuinfo(): String? = runCatching {
        val text = File("/proc/cpuinfo").takeIf { it.canRead() }?.readText() ?: return null
        val keys = listOf("Hardware", "model name", "Processor", "CPU part")
        keys.firstNotNullOfOrNull { key ->
            text.lineSequence().firstOrNull { it.startsWith(key, ignoreCase = true) }
                ?.substringAfter(":")?.trim()
                ?.takeIf { it.isNotBlank() }
        }
    }.getOrNull()

    private fun readCoreFreqs(): List<Long> = runCatching {
        val dir = File("/sys/devices/system/cpu")
        dir.listFiles { f -> f.name.matches(Regex("cpu\\d+")) }
            ?.sortedBy { it.name.removePrefix("cpu").toIntOrNull() ?: 0 }
            ?.mapNotNull { cpu ->
                File(cpu, "cpufreq/cpuinfo_max_freq").takeIf { it.canRead() }
                    ?.readText()?.trim()?.toLongOrNull()
            } ?: emptyList()
    }.getOrDefault(emptyList())

    private fun readGpuRenderer(): String = runCatching {
        val display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val version = IntArray(2)
        if (!EGL14.eglInitialize(display, version, 0, version, 1)) return "Unavailable"
        val attrib = intArrayOf(
            EGL14.EGL_RED_SIZE, 8,
            EGL14.EGL_GREEN_SIZE, 8,
            EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL14.EGL_NONE,
        )
        val configs = arrayOfNulls<android.opengl.EGLConfig>(1)
        val num = IntArray(1)
        EGL14.eglChooseConfig(display, attrib, 0, configs, 0, 1, num, 0)
        val config = configs[0] ?: return "Unavailable"
        val ctxAttrib = intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE)
        val ctx = EGL14.eglCreateContext(display, config, EGL14.EGL_NO_CONTEXT, ctxAttrib, 0)
        val surfAttrib = intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE)
        val surf = EGL14.eglCreatePbufferSurface(display, config, surfAttrib, 0)
        EGL14.eglMakeCurrent(display, surf, surf, ctx)
        val renderer = GLES20.glGetString(GLES20.GL_RENDERER) ?: "Unavailable"
        EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
        EGL14.eglDestroySurface(display, surf)
        EGL14.eglDestroyContext(display, ctx)
        EGL14.eglTerminate(display)
        renderer
    }.getOrDefault("Unavailable")

    private data class Ram(val totalMb: Long, val availMb: Long)

    private fun readRam(context: Context): Ram {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        return Ram(totalMb = info.totalMem / (1024 * 1024), availMb = info.availMem / (1024 * 1024))
    }

    private data class Storage(val sizeGb: Long?, val type: String, val estimated: Boolean)

    private fun readStorage(): Storage {
        val size = runCatching {
            val stat = StatFs(android.os.Environment.getDataDirectory().absolutePath)
            stat.blockCountLong * stat.blockSizeLong / (1024 * 1024 * 1024)
        }.getOrNull()
        val type = detectStorageType()
        return Storage(size, type.first, type.second)
    }

    private fun detectStorageType(): Pair<String, Boolean> = runCatching {
        val ufs = File("/sys/class/scsi_host").listFiles()?.any { it.name.contains("ufs", true) } == true ||
            File("/sys/bus/platform/drivers/ufshcd").exists() ||
            File("/dev/block/by-name").exists() && File("/sys/class/block").listFiles()
                ?.any { it.name.startsWith("sd") } == true
        val emmc = File("/sys/block/mmcblk0").exists() || File("/sys/class/mmc_host").exists()
        when {
            ufs -> "UFS" to false
            emmc -> "eMMC" to false
            else -> "UFS 2.2" to true
        }
    }.getOrDefault("Unavailable" to true)

    private data class DisplayInfo(
        val width: Int,
        val height: Int,
        val inches: Double,
        val refreshRate: Float,
        val supported: List<Float>,
        val dpi: Int,
    )

    private fun readDisplay(context: Context): DisplayInfo {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)
        val inches = hypot(metrics.widthPixels / metrics.xdpi.toDouble(), metrics.heightPixels / metrics.ydpi.toDouble())
        val modes = if (Build.VERSION.SDK_INT >= 23) {
            wm.defaultDisplay.supportedModes.map { it.refreshRate }
        } else {
            listOf(wm.defaultDisplay.refreshRate)
        }
        val current = if (Build.VERSION.SDK_INT >= 23) {
            wm.defaultDisplay.mode.refreshRate
        } else {
            @Suppress("DEPRECATION")
            wm.defaultDisplay.refreshRate
        }
        return DisplayInfo(
            width = metrics.widthPixels,
            height = metrics.heightPixels,
            inches = (inches * 10).roundToInt() / 10.0,
            refreshRate = current,
            supported = modes.distinct().sorted(),
            dpi = metrics.densityDpi,
        )
    }

    private data class Battery(val level: Int?, val tempC: Float?)

    private fun readBattery(context: Context): Battery {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level != null && level >= 0) (level * 100 / scale) else null
        val temp = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        val tempC = if (temp != null && temp != Int.MIN_VALUE) temp / 10f else null
        return Battery(pct, tempC)
    }

    private fun readThermal(context: Context): ThermalStatus {
        if (Build.VERSION.SDK_INT < 29) return ThermalStatus.UNAVAILABLE
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return when (pm.currentThermalStatus) {
            PowerManager.THERMAL_STATUS_NONE -> ThermalStatus.NONE
            PowerManager.THERMAL_STATUS_LIGHT -> ThermalStatus.LIGHT
            PowerManager.THERMAL_STATUS_MODERATE -> ThermalStatus.MODERATE
            PowerManager.THERMAL_STATUS_SEVERE -> ThermalStatus.SEVERE
            PowerManager.THERMAL_STATUS_CRITICAL -> ThermalStatus.CRITICAL
            PowerManager.THERMAL_STATUS_EMERGENCY -> ThermalStatus.EMERGENCY
            PowerManager.THERMAL_STATUS_SHUTDOWN -> ThermalStatus.SHUTDOWN
            else -> ThermalStatus.UNAVAILABLE
        }
    }

    private fun estimateTouch(refresh: Int): Int = when {
        refresh >= 144 -> 360
        refresh >= 120 -> 240
        refresh >= 90 -> 180
        else -> 120
    }
}
