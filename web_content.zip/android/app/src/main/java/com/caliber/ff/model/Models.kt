package com.caliber.ff.model

enum class CpuTier { FLAGSHIP, UPPER_MID, MID, LOW_END }

enum class SocFamily { SNAPDRAGON, DIMENSITY, EXYNOS, HELIO, UNISOC, TENSOR, APPLE, UNKNOWN }

enum class ThermalStatus {
    NONE, LIGHT, MODERATE, SEVERE, CRITICAL, EMERGENCY, SHUTDOWN, UNAVAILABLE
}

data class HardwareProfile(
    val manufacturer: String,
    val model: String,
    val androidVersion: String,
    val securityPatch: String,
    val socName: String,
    val socFamily: SocFamily,
    val cpuTier: CpuTier,
    val cpuCores: Int,
    val cpuMaxFreqKhz: List<Long>,
    val abi: String,
    val gpuName: String,
    val gpuTier: CpuTier,
    val ramGb: Int,
    val ramAvailableGb: Double,
    val ramType: String,
    val ramTypeEstimated: Boolean,
    val storageGb: Long?,
    val storageType: String,
    val storageTypeEstimated: Boolean,
    val displayWidth: Int,
    val displayHeight: Int,
    val displayInches: Double,
    val displayInchesEstimated: Boolean,
    val refreshRate: Float,
    val supportedRefreshRates: List<Float>,
    val densityDpi: Int,
    val defaultDpi: Int,
    val touchSamplingHz: Int,
    val touchSamplingEstimated: Boolean,
    val batteryLevel: Int?,
    val batteryTempC: Float?,
    val thermalStatus: ThermalStatus,
    val notes: List<String>,
)

data class ScoreBreakdown(
    val cpu: Int,
    val ram: Int,
    val ramType: Int,
    val gpu: Int,
    val refresh: Int,
    val touch: Int,
    val thermal: Int,
)

data class Sensitivity(
    val general: Int,
    val redDot: Int,
    val scope2x: Int,
    val scope4x: Int,
    val awm: Int,
    val freeLook: Int,
)

data class DpiPlan(
    val recommended: Int,
    val smallestWidth: Int,
    val originalDpi: Int,
    val adbSet: String,
    val adbReset: String,
)

data class GraphicsPlan(
    val preset: String,
    val fpsOption: String,
    val highFps: Boolean,
    val extras: List<String>,
)

data class FfSettings(
    val performanceScore: Int,
    val scoreBreakdown: ScoreBreakdown,
    val sensitivity: Sensitivity,
    val dpi: DpiPlan,
    val fireButtonPercent: Int,
    val graphics: GraphicsPlan,
)

data class SocClassification(
    val family: SocFamily,
    val tier: CpuTier,
    val ramType: String,
    val storageType: String,
    val label: String,
)
