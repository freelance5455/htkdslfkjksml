package com.caliber.ff.engine

import com.caliber.ff.model.CpuTier
import com.caliber.ff.model.DpiPlan
import com.caliber.ff.model.FfSettings
import com.caliber.ff.model.GraphicsPlan
import com.caliber.ff.model.HardwareProfile
import com.caliber.ff.model.ScoreBreakdown
import com.caliber.ff.model.Sensitivity
import com.caliber.ff.model.ThermalStatus
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Same formulas as the web engine. Every weight and ratio is documented next
 * to the function that owns it.
 */
object CaliberEngine {

    fun generate(hw: HardwareProfile): FfSettings {
        val (total, breakdown) = score(hw)
        return FfSettings(
            performanceScore = total,
            scoreBreakdown = breakdown,
            sensitivity = sensitivity(hw),
            dpi = dpi(hw),
            fireButtonPercent = fireButton(hw),
            graphics = graphics(hw, total),
        )
    }

    /* Score weights: CPU 28, RAM 18, RAM type 6, GPU 18, refresh 14, touch 10, thermal 6. */
    private fun score(hw: HardwareProfile): Pair<Int, ScoreBreakdown> {
        val b = ScoreBreakdown(
            cpu = when (hw.cpuTier) {
                CpuTier.FLAGSHIP -> 28
                CpuTier.UPPER_MID -> 21
                CpuTier.MID -> 14
                CpuTier.LOW_END -> 6
            },
            ram = when {
                hw.ramGb >= 12 -> 18
                hw.ramGb >= 8 -> 16
                hw.ramGb >= 6 -> 13
                hw.ramGb >= 4 -> 9
                hw.ramGb >= 3 -> 5
                else -> 3
            },
            ramType = when {
                hw.ramType.contains("LPDDR5", true) -> 6
                hw.ramType.contains("LPDDR4X", true) -> 4
                hw.ramType.contains("LPDDR4", true) -> 3
                else -> 4
            },
            gpu = when (hw.gpuTier) {
                CpuTier.FLAGSHIP -> 18
                CpuTier.UPPER_MID -> 13
                CpuTier.MID -> 9
                CpuTier.LOW_END -> 4
            },
            refresh = when {
                hw.refreshRate >= 144 -> 14
                hw.refreshRate >= 120 -> 12
                hw.refreshRate >= 90 -> 9
                else -> 5
            },
            touch = when {
                hw.touchSamplingHz >= 240 -> 10
                hw.touchSamplingHz >= 180 -> 8
                hw.touchSamplingHz >= 120 -> 6
                hw.touchSamplingHz >= 90 -> 4
                else -> 2
            },
            thermal = when (hw.thermalStatus) {
                ThermalStatus.NONE, ThermalStatus.UNAVAILABLE -> 6
                ThermalStatus.LIGHT -> 5
                ThermalStatus.MODERATE -> 4
                ThermalStatus.SEVERE -> 2
                ThermalStatus.CRITICAL, ThermalStatus.EMERGENCY, ThermalStatus.SHUTDOWN -> 0
            },
        )
        val total = (b.cpu + b.ram + b.ramType + b.gpu + b.refresh + b.touch + b.thermal).coerceIn(0, 100)
        return total to b
    }

    /**
     * High Hz + strong chip → lower General (168–175) to stop over-flicking.
     * 60 Hz / ≤4 GB / weak chip → higher General (188–195) to cover delay.
     * Scopes scale from General: 0.95 / 0.88 / 0.78 / 0.62 / 0.72.
     */
    private fun sensitivity(hw: HardwareProfile): Sensitivity {
        val strong = hw.cpuTier == CpuTier.FLAGSHIP || hw.cpuTier == CpuTier.UPPER_MID
        val highHz = hw.refreshRate >= 90
        var general = when {
            highHz && strong && hw.cpuTier == CpuTier.FLAGSHIP && hw.refreshRate >= 120 -> 168
            highHz && strong && hw.cpuTier == CpuTier.FLAGSHIP -> 171
            highHz && strong && hw.refreshRate >= 120 -> 173
            highHz && strong -> 175
            hw.ramGb <= 3 || hw.cpuTier == CpuTier.LOW_END -> 195
            hw.ramGb <= 4 || hw.refreshRate <= 60 -> 190
            else -> 188
        }
        val screenAdj = ((6.4 - hw.displayInches) * 2).roundToInt().coerceIn(-4, 4)
        val touchAdj = when {
            hw.touchSamplingHz >= 240 -> -3
            hw.touchSamplingHz >= 180 -> -2
            hw.touchSamplingHz >= 120 -> -1
            hw.touchSamplingHz < 90 -> 3
            else -> 0
        }
        general = (general + screenAdj + touchAdj).coerceIn(140, 200)
        fun scale(ratio: Double) = (general * ratio).roundToInt().coerceIn(0, 200)
        return Sensitivity(general, scale(0.95), scale(0.88), scale(0.78), scale(0.62), scale(0.72))
    }

    /** RAM baseline, then ±40 from CPU/GPU tier. Hard clamp 360–640. */
    private fun dpi(hw: HardwareProfile): DpiPlan {
        val base = when {
            hw.ramGb <= 3 -> 420
            hw.ramGb <= 4 -> 480
            hw.ramGb <= 6 -> 520
            hw.refreshRate >= 90 -> 560
            else -> 600
        }
        val cpuAdj = when (hw.cpuTier) {
            CpuTier.FLAGSHIP -> 16
            CpuTier.UPPER_MID -> 8
            CpuTier.MID -> 0
            CpuTier.LOW_END -> -16
        }
        val gpuAdj = when (hw.gpuTier) {
            CpuTier.FLAGSHIP -> 12
            CpuTier.UPPER_MID -> 4
            CpuTier.MID -> 0
            CpuTier.LOW_END -> -12
        }
        val recommended = (base + cpuAdj + gpuAdj).coerceIn(360, 640)
        val shortest = min(hw.displayWidth, hw.displayHeight).coerceAtLeast(1)
        val sw = (shortest * 160.0 / recommended).roundToInt()
        return DpiPlan(
            recommended = recommended,
            smallestWidth = sw,
            originalDpi = hw.defaultDpi,
            adbSet = "adb shell wm density $recommended",
            adbReset = "adb shell wm density reset",
        )
    }

    private fun fireButton(hw: HardwareProfile): Int {
        var size = when {
            hw.ramGb <= 3 -> 52
            hw.ramGb <= 4 -> 50
            hw.ramGb <= 6 -> 48
            else -> 46
        }
        if (hw.displayInches >= 6.8) size += 2
        else if (hw.displayInches <= 5.8) size -= 1
        return size.coerceIn(40, 60)
    }

    private fun graphics(hw: HardwareProfile, score: Int): GraphicsPlan {
        val extras = mutableListOf<String>()
        val hot = hw.thermalStatus in setOf(
            ThermalStatus.SEVERE, ThermalStatus.CRITICAL, ThermalStatus.EMERGENCY, ThermalStatus.SHUTDOWN,
        )
        var preset = "Smooth"
        var fps = "60"
        var high = false
        when {
            hw.cpuTier == CpuTier.FLAGSHIP && hw.ramGb >= 8 && hw.refreshRate >= 90 && score >= 78 && !hot -> {
                fps = if (hw.refreshRate >= 120) "Ultra" else "High"
                high = true
                extras += "Keep Shadows off — they hide enemies in smoke and cost GPU time."
            }
            (hw.cpuTier == CpuTier.FLAGSHIP || hw.cpuTier == CpuTier.UPPER_MID) && hw.refreshRate >= 90 && !hot -> {
                fps = "High"
                high = true
                extras += "If the phone heats past ~42°C, drop to 60 FPS for the rest of the session."
            }
            hw.cpuTier == CpuTier.MID && hw.ramGb >= 6 -> {
                fps = if (hw.refreshRate >= 90) "High" else "60"
                high = hw.refreshRate >= 90 && score >= 55 && !hot
                extras += "Disable Effects and Shadows. Leave Auto-adjust off."
            }
            else -> {
                fps = if (hw.ramGb <= 3 || hw.cpuTier == CpuTier.LOW_END) "30" else "60"
                high = false
                extras += "High FPS stays off — this silicon cannot hold it in late-game fights."
            }
        }
        if (hot) {
            high = false
            fps = "30"
            extras.add(0, "Device is thermally throttled. Cool it down before ranked.")
        }
        extras += "Lock HUD scale to default after applying DPI, then set the fire button percent."
        return GraphicsPlan(preset, fps, high, extras)
    }

    fun format(hw: HardwareProfile, s: FfSettings): String = buildString {
        appendLine("CALIBER — Free Fire settings")
        appendLine("Device: ${hw.manufacturer} ${hw.model}")
        appendLine("SoC: ${hw.socName}")
        appendLine("Performance score: ${s.performanceScore}/100")
        appendLine()
        appendLine("Sensitivity (0–200)")
        appendLine("General: ${s.sensitivity.general}")
        appendLine("Red Dot: ${s.sensitivity.redDot}")
        appendLine("2x Scope: ${s.sensitivity.scope2x}")
        appendLine("4x Scope: ${s.sensitivity.scope4x}")
        appendLine("AWM Scope: ${s.sensitivity.awm}")
        appendLine("Free Look: ${s.sensitivity.freeLook}")
        appendLine()
        appendLine("Recommended DPI: ${s.dpi.recommended}")
        appendLine("Smallest width: ${s.dpi.smallestWidth}")
        appendLine("Original DPI: ${s.dpi.originalDpi}")
        appendLine(s.dpi.adbSet)
        appendLine("Restore: ${s.dpi.adbReset}")
        appendLine("Path: Settings → Developer options → Smallest width → ${s.dpi.smallestWidth}")
        appendLine()
        appendLine("Fire button size: ${s.fireButtonPercent}%")
        appendLine("Graphics: ${s.graphics.preset}")
        appendLine("FPS: ${s.graphics.fpsOption}")
        appendLine("High FPS: ${if (s.graphics.highFps) "ON" else "OFF"}")
        s.graphics.extras.forEach { appendLine(it) }
    }
}
