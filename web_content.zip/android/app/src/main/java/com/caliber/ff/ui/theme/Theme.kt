package com.caliber.ff.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF0F172A)
val Surface = Color(0xFF1E293B)
val Fg = Color(0xFFF8FAFC)
val Muted = Color(0xFF94A3B8)
val Primary = Color(0xFFF97316)
val Accent = Color(0xFFEAB308)

private val scheme = darkColorScheme(
    primary = Primary,
    onPrimary = Bg,
    secondary = Accent,
    onSecondary = Bg,
    background = Bg,
    onBackground = Fg,
    surface = Surface,
    onSurface = Fg,
)

@Composable
fun CaliberTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}
