package com.caliber.ff

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.caliber.ff.detection.HardwareScanner
import com.caliber.ff.engine.CaliberEngine
import com.caliber.ff.model.FfSettings
import com.caliber.ff.model.HardwareProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class UiState(
    val phase: String = "home",
    val tab: String = "specs",
    val lang: String = "en",
    val hardware: HardwareProfile? = null,
    val settings: FfSettings? = null,
    val measuredTouchHz: Int? = null,
)

class CaliberViewModel(app: Application) : AndroidViewModel(app) {
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state

    fun toggleLang() {
        _state.update { it.copy(lang = if (it.lang == "en") "ar" else "en") }
    }

    fun setTab(tab: String) {
        _state.update { it.copy(tab = tab) }
    }

    fun scan() {
        _state.update { it.copy(phase = "scanning") }
        viewModelScope.launch {
            delay(900)
            val hw = withContext(Dispatchers.Default) {
                HardwareScanner.scan(
                    getApplication(),
                    touchHz = _state.value.measuredTouchHz,
                    touchEstimated = _state.value.measuredTouchHz == null,
                )
            }
            _state.update {
                it.copy(phase = "results", tab = "specs", hardware = hw, settings = CaliberEngine.generate(hw))
            }
        }
    }

    fun applyTouch(hz: Int) {
        val current = _state.value.hardware ?: return
        val hw = current.copy(touchSamplingHz = hz, touchSamplingEstimated = false)
        _state.update {
            it.copy(hardware = hw, settings = CaliberEngine.generate(hw), measuredTouchHz = hz, tab = "settings")
        }
    }

    fun reset() {
        _state.update { UiState(lang = it.lang, measuredTouchHz = it.measuredTouchHz) }
    }
}
