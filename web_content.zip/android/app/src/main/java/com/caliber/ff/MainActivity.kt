package com.caliber.ff

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.core.view.WindowCompat
import com.caliber.ff.ui.CaliberRoot
import com.caliber.ff.ui.theme.CaliberTheme

class MainActivity : ComponentActivity() {
    private val vm: CaliberViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent {
            CaliberTheme {
                CaliberRoot(vm)
            }
        }
    }
}
