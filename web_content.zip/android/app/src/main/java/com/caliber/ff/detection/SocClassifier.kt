package com.caliber.ff.detection

import com.caliber.ff.model.CpuTier
import com.caliber.ff.model.SocClassification
import com.caliber.ff.model.SocFamily

/**
 * Pattern-match Snapdragon / Dimensity / Exynos / Helio / Unisoc / Tensor names
 * (and Adreno/Mali/Xclipse renderer strings) into a performance tier.
 */
object SocClassifier {

    fun classify(raw: String): SocClassification {
        val name = raw.replace(Regex("\\s+"), " ").trim()
        val n = name.lowercase()
        if (n.isBlank() || n == "unavailable" || n == "unknown") {
            return SocClassification(SocFamily.UNKNOWN, CpuTier.MID, "LPDDR4X", "UFS 2.2", "Unknown")
        }

        if (n.contains("tensor")) {
            val tier = when {
                Regex("g[345]").containsMatchIn(n) -> CpuTier.FLAGSHIP
                n.contains("g2") -> CpuTier.UPPER_MID
                else -> CpuTier.MID
            }
            return wrap(SocFamily.TENSOR, tier, name)
        }

        if (n.contains("snapdragon") || n.contains("qualcomm") || n.contains("adreno") ||
            Regex("sm\\d{4}").containsMatchIn(n) || n.contains("8 gen") || n.contains("8 elite")
        ) {
            val tier = when {
                Regex("8 elite|8 gen [3-9]|8\\+|sm8[56]|adreno[^0-9]*(8[23]\\d|75\\d|740)").containsMatchIn(n) ->
                    CpuTier.FLAGSHIP
                Regex("8 gen [12]|888|865|870|sm84|adreno[^0-9]*(730|660|650)").containsMatchIn(n) ->
                    CpuTier.FLAGSHIP
                Regex("8s gen|7\\+ gen|7 gen|7s gen|778g|780g|782g|855|adreno[^0-9]*(735|725|720|710|644|642)")
                    .containsMatchIn(n) -> CpuTier.UPPER_MID
                Regex("6 gen|6s|695|4 gen|732g|730|720g|680|685|adreno[^0-9]*(619|616|613|610)").containsMatchIn(n) ->
                    CpuTier.MID
                else -> CpuTier.LOW_END
            }
            return wrap(SocFamily.SNAPDRAGON, tier, name)
        }

        if (n.contains("dimensity") || n.contains("immortalis") || n.contains("mediatek mt6")) {
            val tier = when {
                Regex("9[2-9]\\d{2}|9400|9300|9200|9000|immortalis").containsMatchIn(n) -> CpuTier.FLAGSHIP
                Regex("8[2-4]\\d{2}|8100|8000|7350|7200").containsMatchIn(n) -> CpuTier.UPPER_MID
                Regex("7[0-1]\\d{2}|7050|6100|6300|1080|1200|1300").containsMatchIn(n) -> CpuTier.MID
                else -> CpuTier.LOW_END
            }
            return wrap(SocFamily.DIMENSITY, tier, name)
        }

        if (n.contains("helio")) {
            val tier = if (Regex("g9[0-9]|g99|g96|g95").containsMatchIn(n)) CpuTier.MID else CpuTier.LOW_END
            return wrap(SocFamily.HELIO, tier, name)
        }

        if (n.contains("exynos") || n.contains("xclipse")) {
            val tier = when {
                Regex("2[2-5]00|2100|990|xclipse 9").containsMatchIn(n) -> CpuTier.FLAGSHIP
                Regex("1[45]80|1580|xclipse").containsMatchIn(n) -> CpuTier.UPPER_MID
                Regex("1380|1280|1080|1330|980").containsMatchIn(n) -> CpuTier.MID
                else -> CpuTier.LOW_END
            }
            return wrap(SocFamily.EXYNOS, tier, name)
        }

        if (n.contains("unisoc") || n.contains("spreadtrum") || Regex("t[6-8]\\d{2}").containsMatchIn(n)) {
            val tier = if (Regex("t820|t760").containsMatchIn(n)) CpuTier.MID else CpuTier.LOW_END
            return wrap(SocFamily.UNISOC, tier, name)
        }

        classifyGpu(n, name)?.let { return it }
        return wrap(SocFamily.UNKNOWN, CpuTier.MID, name)
    }

    fun classifyGpu(n: String, label: String): SocClassification? {
        if (n.contains("adreno")) {
            val tier = when {
                Regex("8[2-3]\\d|75\\d|740|730|660|650").containsMatchIn(n) -> CpuTier.FLAGSHIP
                Regex("735|725|720|710|644|642").containsMatchIn(n) -> CpuTier.UPPER_MID
                Regex("619|616|613|610").containsMatchIn(n) -> CpuTier.MID
                else -> CpuTier.LOW_END
            }
            return wrap(SocFamily.SNAPDRAGON, tier, label)
        }
        if (n.contains("immortalis") || n.contains("mali-g715") || n.contains("mali-g720")) {
            return wrap(SocFamily.DIMENSITY, CpuTier.FLAGSHIP, label)
        }
        if (n.contains("mali-g615")) return wrap(SocFamily.DIMENSITY, CpuTier.UPPER_MID, label)
        if (n.contains("mali-g610") || n.contains("mali-g68")) return wrap(SocFamily.DIMENSITY, CpuTier.MID, label)
        if (n.contains("mali-g57")) return wrap(SocFamily.HELIO, CpuTier.MID, label)
        if (n.contains("mali-g52") || n.contains("mali-g31")) return wrap(SocFamily.HELIO, CpuTier.LOW_END, label)
        if (n.contains("xclipse 9")) return wrap(SocFamily.EXYNOS, CpuTier.FLAGSHIP, label)
        if (n.contains("xclipse")) return wrap(SocFamily.EXYNOS, CpuTier.UPPER_MID, label)
        if (n.contains("powervr")) return wrap(SocFamily.UNKNOWN, CpuTier.LOW_END, label)
        return null
    }

    private fun wrap(family: SocFamily, tier: CpuTier, label: String): SocClassification {
        val ram = when (tier) {
            CpuTier.FLAGSHIP, CpuTier.UPPER_MID -> "LPDDR5"
            else -> "LPDDR4X"
        }
        val storage = when (tier) {
            CpuTier.FLAGSHIP -> "UFS 4.0"
            CpuTier.UPPER_MID -> "UFS 3.1"
            CpuTier.MID -> "UFS 2.2"
            CpuTier.LOW_END -> "eMMC 5.1"
        }
        return SocClassification(family, tier, ram, storage, label)
    }
}
