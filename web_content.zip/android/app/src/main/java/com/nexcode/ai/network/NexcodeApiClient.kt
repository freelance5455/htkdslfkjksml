package com.nexcode.ai.network

import com.nexcode.ai.BuildConfig
import com.nexcode.ai.model.ChatMessage
import com.nexcode.ai.model.MediaAttachment
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject

data class ChatApiResult(
    val reply: String,
    val snippetTitle: String?,
    val snippetLanguage: String?,
    val snippetCode: String?
)

interface LiveSocketCallbacks {
    fun onReady()
    fun onAudio(base64Pcm24k: String)
    fun onInputTranscript(text: String)
    fun onOutputTranscript(text: String)
    fun onLanguageChanged(language: String)
    fun onVisionAck(frameCount: Int, receivedAt: Long)
    fun onClipboardItem(title: String, language: String, code: String)
    fun onInterrupted()
    fun onTurnComplete()
    fun onError(error: String)
    fun onClosed()
}

class NexcodeApiClient {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .pingInterval(15, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private val baseHttpUrl: String
        get() = BuildConfig.API_BASE_URL.trimEnd('/')

    private val baseWsUrl: String
        get() = when {
            baseHttpUrl.startsWith("https://") -> "wss://${baseHttpUrl.removePrefix("https://")}"
            baseHttpUrl.startsWith("http://") -> "ws://${baseHttpUrl.removePrefix("http://")}"
            else -> "wss://$baseHttpUrl"
        }

    fun buildChatCall(
        conversationHistory: List<ChatMessage>,
        language: String,
        attachment: MediaAttachment?,
        screenFrameBase64: String?
    ): Call {
        val msgsArr = JSONArray()
        conversationHistory.forEach { msg ->
            msgsArr.put(
                JSONObject().apply {
                    put("role", msg.role)
                    put("text", msg.text)
                }
            )
        }

        val bodyJson = JSONObject().apply {
            put("messages", msgsArr)
            put("language", language)
            put("thinkingDepth", "HIGH")
            put("autoAnalyzeMedia", attachment != null)
            if (attachment != null) {
                put(
                    "attachment",
                    JSONObject().apply {
                        put("mimeType", attachment.mimeType)
                        put("data", attachment.data)
                        put("name", attachment.name)
                        put("kind", attachment.kind.wireName)
                    }
                )
            } else {
                put("attachment", JSONObject.NULL)
            }
            if (!screenFrameBase64.isNullOrBlank()) {
                put("screenFrame", screenFrameBase64)
            } else {
                put("screenFrame", JSONObject.NULL)
            }
        }

        val request = Request.Builder()
            .url("$baseHttpUrl/api/chat")
            .post(bodyJson.toString().toRequestBody(jsonMediaType))
            .build()

        return httpClient.newCall(request)
    }

    fun executeChatCall(call: Call): ChatApiResult {
        call.execute().use { response ->
            val rawBody = response.body?.string().orEmpty()
            val json = runCatching { JSONObject(rawBody) }.getOrNull()
            if (!response.isSuccessful) {
                val errMsg = json?.optString("error")?.takeIf { it.isNotBlank() }
                    ?: "Server error (${response.code})"
                throw IOException(errMsg)
            }
            if (json == null) {
                throw IOException("Invalid response from NEXCODE AI.")
            }
            val err = json.optString("error", "")
            if (err.isNotBlank()) {
                throw IOException(err)
            }
            val reply = json.optString("reply", "Here is what I found.")
            val clipObj = json.optJSONObject("clipboardItem")
            return ChatApiResult(
                reply = reply,
                snippetTitle = clipObj?.optString("title")?.takeIf { it.isNotBlank() },
                snippetLanguage = clipObj?.optString("language")?.takeIf { it.isNotBlank() },
                snippetCode = clipObj?.optString("code")?.takeIf { it.isNotBlank() }
            )
        }
    }

    fun connectLiveSocket(language: String, callbacks: LiveSocketCallbacks): WebSocket {
        val encodedLang = URLEncoder.encode(language, "UTF-8")
        val request = Request.Builder()
            .url("$baseWsUrl/api/live?lang=$encodedLang")
            .build()

        return httpClient.newWebSocket(
            request,
            object : WebSocketListener() {
                override fun onMessage(webSocket: WebSocket, text: String) {
                    val msg = runCatching { JSONObject(text) }.getOrNull() ?: return
                    when (msg.optString("type")) {
                        "ready" -> callbacks.onReady()
                        "audio" -> {
                            val data = msg.optString("data")
                            if (data.isNotBlank()) callbacks.onAudio(data)
                        }
                        "inputTranscript" -> {
                            val chunk = msg.optString("text")
                            if (chunk.isNotEmpty()) callbacks.onInputTranscript(chunk)
                        }
                        "outputTranscript" -> {
                            val chunk = msg.optString("text")
                            if (chunk.isNotEmpty()) callbacks.onOutputTranscript(chunk)
                        }
                        "languageChanged" -> {
                            val nextLang = msg.optString("language")
                            if (nextLang.isNotBlank()) callbacks.onLanguageChanged(nextLang)
                        }
                        "visionAck" -> {
                            val count = msg.optInt("frameCount", -1)
                            val receivedAt = msg.optLong("receivedAt", System.currentTimeMillis())
                            if (count >= 0) callbacks.onVisionAck(count, receivedAt)
                        }
                        "clipboardItem" -> {
                            val item = msg.optJSONObject("item")
                            if (item != null) {
                                callbacks.onClipboardItem(
                                    title = item.optString("title", "Code Snippet"),
                                    language = item.optString("language", "text"),
                                    code = item.optString("code", "")
                                )
                            }
                        }
                        "interrupted" -> callbacks.onInterrupted()
                        "turnComplete" -> callbacks.onTurnComplete()
                        "error" -> callbacks.onError(
                            msg.optString("error", "Voice connection interrupted.")
                        )
                        "closed" -> callbacks.onClosed()
                    }
                }

                override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                    webSocket.close(1000, null)
                }

                override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                    callbacks.onClosed()
                }

                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                    callbacks.onError(t.message ?: "Live WebSocket connection error")
                    callbacks.onClosed()
                }
            }
        )
    }
}
