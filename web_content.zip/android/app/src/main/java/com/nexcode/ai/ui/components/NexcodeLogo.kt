package com.nexcode.ai.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun NexcodeLogo(
    size: Dp = 32.dp,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.size(size)) {
        val scale = this.size.minDimension / 48f
        val grad = Brush.linearGradient(
            colors = listOf(
                Color(0xFF3B82F6),
                Color(0xFF06B6D4),
                Color(0xFF8B5CF6)
            ),
            start = Offset(6f * scale, 6f * scale),
            end = Offset(42f * scale, 42f * scale)
        )

        drawRoundRect(
            color = Color(0xFF070A12),
            topLeft = Offset(3f * scale, 3f * scale),
            size = Size(42f * scale, 42f * scale),
            cornerRadius = CornerRadius(12f * scale, 12f * scale)
        )
        drawRoundRect(
            brush = grad,
            topLeft = Offset(3f * scale, 3f * scale),
            size = Size(42f * scale, 42f * scale),
            cornerRadius = CornerRadius(12f * scale, 12f * scale),
            style = Stroke(width = 2f * scale)
        )

        val nPath = Path().apply {
            moveTo(15f * scale, 32f * scale)
            lineTo(15f * scale, 16f * scale)
            lineTo(24f * scale, 26f * scale)
            lineTo(33f * scale, 16f * scale)
            lineTo(33f * scale, 32f * scale)
        }
        drawPath(
            path = nPath,
            brush = grad,
            style = Stroke(
                width = 3.2f * scale,
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )

        val leftBracket = Path().apply {
            moveTo(11f * scale, 21f * scale)
            lineTo(8.5f * scale, 24f * scale)
            lineTo(11f * scale, 27f * scale)
        }
        drawPath(
            path = leftBracket,
            color = Color(0xFF22D3EE),
            style = Stroke(
                width = 2f * scale,
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )

        val rightBracket = Path().apply {
            moveTo(37f * scale, 21f * scale)
            lineTo(39.5f * scale, 24f * scale)
            lineTo(37f * scale, 27f * scale)
        }
        drawPath(
            path = rightBracket,
            color = Color(0xFFA78BFA),
            style = Stroke(
                width = 2f * scale,
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )
    }
}
