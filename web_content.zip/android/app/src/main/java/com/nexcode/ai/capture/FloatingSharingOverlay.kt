package com.nexcode.ai.capture

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Real system-wide floating sharing indicator pill displayed over any Android app
 * (e.g., WhatsApp, Roblox, Chrome, Settings) when SYSTEM_ALERT_WINDOW is granted.
 */
class FloatingSharingOverlay(
    private val context: Context,
    private val onTogglePause: () -> Unit,
    private val onStopSharing: () -> Unit
) {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private var rootView: LinearLayout? = null
    private var statusText: TextView? = null
    private var pauseButton: TextView? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    fun show(paused: Boolean) {
        mainHandler.post {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
                return@post
            }
            if (rootView == null) {
                createOverlayView(paused)
            } else {
                updateStatusInternal(paused)
            }
        }
    }

    fun updateStatus(paused: Boolean) {
        mainHandler.post {
            updateStatusInternal(paused)
        }
    }

    fun hide() {
        mainHandler.post {
            rootView?.let { view ->
                runCatching { windowManager.removeView(view) }
            }
            rootView = null
            statusText = null
            pauseButton = null
            layoutParams = null
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createOverlayView(paused: Boolean) {
        val density = context.resources.displayMetrics.density
        fun dp(value: Int): Int = (value * density).toInt()

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(10), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#E609090B"))
                cornerRadius = dp(20).toFloat()
                setStroke(dp(1), Color.parseColor("#3B82F6"))
            }
            elevation = dp(8).toFloat()
        }

        val label = TextView(context).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setPadding(0, 0, dp(10), 0)
        }

        val pauseBtn = TextView(context).apply {
            setTextColor(Color.parseColor("#93C5FD"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setPadding(dp(8), dp(4), dp(8), dp(4))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1E293B"))
                cornerRadius = dp(10).toFloat()
            }
            setOnClickListener { onTogglePause() }
        }

        val stopBtn = TextView(context).apply {
            text = "Stop"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setPadding(dp(10), dp(4), dp(10), dp(4))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#DC2626"))
                cornerRadius = dp(10).toFloat()
            }
            setOnClickListener { onStopSharing() }
        }

        val spacer = View(context).apply {
            layoutParams = LinearLayout.LayoutParams(dp(6), 1)
        }

        container.addView(label)
        container.addView(pauseBtn)
        container.addView(spacer)
        container.addView(stopBtn)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(12)
            y = dp(96)
        }

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        container.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX - (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    runCatching { windowManager.updateViewLayout(container, params) }
                    true
                }
                else -> false
            }
        }

        rootView = container
        statusText = label
        pauseButton = pauseBtn
        layoutParams = params
        updateStatusInternal(paused)

        runCatching {
            windowManager.addView(container, params)
        }
    }

    private fun updateStatusInternal(paused: Boolean) {
        statusText?.text = if (paused) "Paused" else "Sharing Live"
        pauseButton?.text = if (paused) "Resume" else "Pause"
    }
}
