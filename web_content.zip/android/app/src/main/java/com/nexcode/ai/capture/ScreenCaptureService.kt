package com.nexcode.ai.capture

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.util.Base64
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.nexcode.ai.MainActivity
import com.nexcode.ai.R
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import kotlin.math.max
import kotlin.math.min

class ScreenCaptureService : Service() {

    companion object {
        const val ACTION_START = "com.nexcode.ai.action.START_CAPTURE"
        const val ACTION_PAUSE = "com.nexcode.ai.action.PAUSE_CAPTURE"
        const val ACTION_RESUME = "com.nexcode.ai.action.RESUME_CAPTURE"
        const val ACTION_STOP = "com.nexcode.ai.action.STOP_CAPTURE"
        const val ACTION_REQUEST_FRAME = "com.nexcode.ai.action.REQUEST_FRAME"
        const val ACTION_REFRESH_OVERLAY = "com.nexcode.ai.action.REFRESH_OVERLAY"

        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
        const val EXTRA_INTERVAL_MS = "extra_interval_ms"

        private const val CHANNEL_ID = "screen_share_channel"
        private const val NOTIFICATION_ID = 4001
        private const val MAX_OUTPUT_DIMENSION = 960
        private const val JPEG_QUALITY = 72
        private const val STALE_HEARTBEAT_MS = 3500L
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var captureThread: HandlerThread? = null
    private var captureHandler: Handler? = null

    private var mediaProjectionManager: MediaProjectionManager? = null
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var floatingOverlay: FloatingSharingOverlay? = null
    private var wakeLock: PowerManager.WakeLock? = null

    @Volatile
    private var isPaused = false

    @Volatile
    private var forceNextFrame = true

    @Volatile
    private var frameIntervalMs = 950L

    private var lastDispatchedAtMs = 0L
    private var lastHeartbeatAtMs = 0L
    private var lastFrameChecksum = 0L
    private var consecutiveBlankFrames = 0
    private var currentWidth = 720
    private var currentHeight = 1280
    private var currentDensityDpi = DisplayMetrics.DENSITY_HIGH

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            mainHandler.post {
                ScreenShareState.publishState(
                    NativeShareStatus.STOPPED,
                    "Screen sharing stopped"
                )
                stopCaptureAndSelf()
            }
        }

        override fun onCapturedContentResize(width: Int, height: Int) {
            if (width > 0 && height > 0) {
                captureHandler?.post {
                    rebuildVirtualDisplay(width, height)
                }
            }
        }

        override fun onCapturedContentVisibilityChanged(isVisible: Boolean) {
            if (!isVisible && !isPaused) {
                ScreenShareState.publishState(
                    NativeShareStatus.ACTIVE,
                    "Screen content temporarily hidden",
                    currentWidth,
                    currentHeight
                )
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        mediaProjectionManager =
            getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        createNotificationChannel()
        floatingOverlay = FloatingSharingOverlay(
            context = this,
            onTogglePause = {
                if (isPaused) resumeCapture() else pauseCapture()
            },
            onStopSharing = {
                ScreenShareState.publishState(
                    NativeShareStatus.STOPPED,
                    "Screen sharing stopped"
                )
                stopCaptureAndSelf()
            }
        )
        registerDisplayListener()
    }

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) {
            if (mediaProjection == null || isPaused) return
            val metrics = resolveScreenMetrics()
            if (metrics.widthPixels > 0 && metrics.heightPixels > 0) {
                captureHandler?.post {
                    rebuildVirtualDisplay(metrics.widthPixels, metrics.heightPixels)
                }
            }
        }
    }

    private fun registerDisplayListener() {
        val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        dm.registerDisplayListener(displayListener, mainHandler)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val resultData: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_RESULT_DATA)
                }
                frameIntervalMs = intent.getLongExtra(EXTRA_INTERVAL_MS, 950L).coerceIn(500L, 4000L)

                if (resultCode != Activity.RESULT_OK || resultData == null) {
                    ScreenShareState.publishError("Screen capture permission was not granted.")
                    stopSelf()
                    return START_NOT_STICKY
                }

                startForegroundWithProjectionType(paused = false)
                startMediaProjection(resultCode, resultData)
            }
            ACTION_PAUSE -> pauseCapture()
            ACTION_RESUME -> resumeCapture()
            ACTION_REQUEST_FRAME -> {
                forceNextFrame = true
            }
            ACTION_REFRESH_OVERLAY -> {
                if (mediaProjection != null) {
                    floatingOverlay?.show(isPaused)
                }
            }
            ACTION_STOP -> {
                ScreenShareState.publishState(NativeShareStatus.STOPPED, "Screen sharing stopped")
                stopCaptureAndSelf()
            }
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        runCatching {
            val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            dm.unregisterDisplayListener(displayListener)
        }
        cleanupProjectionResources()
        floatingOverlay?.hide()
        super.onDestroy()
    }

    private fun startForegroundWithProjectionType(paused: Boolean) {
        val notification = buildNotification(paused)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun startMediaProjection(resultCode: Int, resultData: Intent) {
        cleanupProjectionResources()

        try {
            val projection = mediaProjectionManager?.getMediaProjection(resultCode, resultData)
            if (projection == null) {
                ScreenShareState.publishError("Could not initialize Android MediaProjection.")
                stopCaptureAndSelf()
                return
            }

            isPaused = false
            forceNextFrame = true
            consecutiveBlankFrames = 0
            lastFrameChecksum = 0L

            captureThread = HandlerThread("NexcodeScreenCapture").apply { start() }
            captureHandler = Handler(captureThread!!.looper)

            projection.registerCallback(projectionCallback, captureHandler)
            mediaProjection = projection

            val metrics = resolveScreenMetrics()
            currentDensityDpi = metrics.densityDpi
            val scaled = scaleDimensions(
                metrics.widthPixels.coerceAtLeast(360),
                metrics.heightPixels.coerceAtLeast(360)
            )
            currentWidth = scaled.first
            currentHeight = scaled.second

            acquireCaptureWakeLock()
            createVirtualDisplayAndReader(currentWidth, currentHeight)
            floatingOverlay?.show(paused = false)

            ScreenShareState.publishState(
                NativeShareStatus.ACTIVE,
                "Live Android screen sharing active",
                currentWidth,
                currentHeight
            )
        } catch (sec: SecurityException) {
            ScreenShareState.publishError(
                "Android blocked screen projection (${sec.message ?: "SecurityException"}). Please retry permission."
            )
            stopCaptureAndSelf()
        } catch (t: Throwable) {
            ScreenShareState.publishError(
                "Failed to start screen capture: ${t.message ?: "Unexpected error"}"
            )
            stopCaptureAndSelf()
        }
    }

    private fun createVirtualDisplayAndReader(width: Int, height: Int) {
        val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        reader.setOnImageAvailableListener({ imgReader ->
            handleImageAvailable(imgReader)
        }, captureHandler)
        imageReader = reader

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "NexcodeScreenShare",
            width,
            height,
            currentDensityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface,
            null,
            captureHandler
        )
    }

    private fun rebuildVirtualDisplay(rawWidth: Int, rawHeight: Int) {
        val scaled = scaleDimensions(
            rawWidth.coerceAtLeast(360),
            rawHeight.coerceAtLeast(360)
        )
        if (scaled.first == currentWidth && scaled.second == currentHeight && virtualDisplay != null) {
            return
        }
        currentWidth = scaled.first
        currentHeight = scaled.second

        if (mediaProjection == null) return

        val existingDisplay = virtualDisplay
        if (existingDisplay != null) {
            val newReader = ImageReader.newInstance(currentWidth, currentHeight, PixelFormat.RGBA_8888, 2)
            newReader.setOnImageAvailableListener({ imgReader ->
                handleImageAvailable(imgReader)
            }, captureHandler)

            val prevReader = imageReader
            imageReader = newReader
            existingDisplay.resize(currentWidth, currentHeight, currentDensityDpi)
            existingDisplay.setSurface(newReader.surface)

            runCatching {
                prevReader?.setOnImageAvailableListener(null, null)
                prevReader?.close()
            }
            forceNextFrame = true
        } else {
            createVirtualDisplayAndReader(currentWidth, currentHeight)
            forceNextFrame = true
        }
    }

    private fun handleImageAvailable(reader: ImageReader) {
        var image: Image? = null
        try {
            image = reader.acquireLatestImage() ?: return
            if (isPaused) return

            val now = System.currentTimeMillis()
            val elapsed = now - lastDispatchedAtMs
            val minActiveInterval = max(550L, frameIntervalMs / 2)
            if (!forceNextFrame && elapsed < minActiveInterval) {
                return
            }

            val planes = image.planes
            if (planes.isEmpty()) return

            val buffer: ByteBuffer = planes[0].buffer
            val pixelStride = planes[0].pixelStride.coerceAtLeast(1)
            val rowStride = planes[0].rowStride
            val rowPadding = max(0, rowStride - pixelStride * image.width)

            val paddedWidth = image.width + rowPadding / pixelStride
            val rawBitmap = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
            rawBitmap.copyPixelsFromBuffer(buffer)

            val croppedBitmap = if (paddedWidth != image.width) {
                Bitmap.createBitmap(rawBitmap, 0, 0, image.width, image.height)
                    .also { rawBitmap.recycle() }
            } else {
                rawBitmap
            }

            val checksum = computeSparseChecksum(croppedBitmap)
            if (checksum == 0L) {
                consecutiveBlankFrames++
                if (consecutiveBlankFrames == 4) {
                    ScreenShareState.publishState(
                        NativeShareStatus.ACTIVE,
                        "Protected app screen detected (FLAG_SECURE)",
                        croppedBitmap.width,
                        croppedBitmap.height
                    )
                }
                croppedBitmap.recycle()
                return
            }
            consecutiveBlankFrames = 0

            val changed = checksum != lastFrameChecksum
            val heartbeatDue = (now - lastHeartbeatAtMs) >= STALE_HEARTBEAT_MS
            val requiredInterval = if (changed) minActiveInterval else frameIntervalMs
            if (!forceNextFrame && !heartbeatDue && (!changed || elapsed < requiredInterval)) {
                croppedBitmap.recycle()
                return
            }

            val outputStream = ByteArrayOutputStream()
            croppedBitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, outputStream)
            val widthOut = croppedBitmap.width
            val heightOut = croppedBitmap.height
            croppedBitmap.recycle()

            val base64Jpeg = Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
            lastDispatchedAtMs = now
            lastHeartbeatAtMs = now
            lastFrameChecksum = checksum
            forceNextFrame = false

            ScreenShareState.publishFrame(base64Jpeg, widthOut, heightOut, now)
        } catch (_: IllegalStateException) {
            // ImageReader closed during teardown or rotation
        } catch (t: Throwable) {
            ScreenShareState.publishError("Screen frame capture error: ${t.message ?: "unknown"}")
        } finally {
            runCatching { image?.close() }
        }
    }

    private fun computeSparseChecksum(bitmap: Bitmap): Long {
        val w = bitmap.width
        val h = bitmap.height
        if (w <= 0 || h <= 0) return 0L
        var hash = 0L
        var nonBlackPixels = 0
        val stepX = max(1, w / 16)
        val stepY = max(1, h / 16)
        var y = stepY / 2
        while (y < h) {
            var x = stepX / 2
            while (x < w) {
                val px = bitmap.getPixel(x, y)
                val r = (px shr 16) and 0xFF
                val g = (px shr 8) and 0xFF
                val b = px and 0xFF
                if (r > 3 || g > 3 || b > 3) {
                    nonBlackPixels++
                }
                hash = hash * 31L + px.toLong()
                x += stepX
            }
            y += stepY
        }
        return if (nonBlackPixels == 0) 0L else hash
    }

    private fun pauseCapture() {
        if (isPaused || mediaProjection == null) return
        isPaused = true
        updateNotification(paused = true)
        floatingOverlay?.updateStatus(paused = true)
        ScreenShareState.publishState(
            NativeShareStatus.PAUSED,
            "Screen sharing paused",
            currentWidth,
            currentHeight
        )
    }

    private fun resumeCapture() {
        if (!isPaused || mediaProjection == null) return
        isPaused = false
        forceNextFrame = true
        updateNotification(paused = false)
        floatingOverlay?.updateStatus(paused = false)
        ScreenShareState.publishState(
            NativeShareStatus.ACTIVE,
            "Screen sharing resumed",
            currentWidth,
            currentHeight
        )
    }

    private fun stopCaptureAndSelf() {
        cleanupProjectionResources()
        floatingOverlay?.hide()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun acquireCaptureWakeLock() {
        runCatching {
            if (wakeLock == null) {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                wakeLock = pm.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK,
                    "NexcodeAI::ScreenShareWakeLock"
                ).apply { setReferenceCounted(false) }
            }
            if (wakeLock?.isHeld == false) {
                wakeLock?.acquire(60 * 60 * 1000L)
            }
        }
    }

    private fun releaseCaptureWakeLock() {
        runCatching {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        }
        wakeLock = null
    }

    private fun cleanupProjectionResources() {
        releaseCaptureWakeLock()

        runCatching { virtualDisplay?.release() }
        virtualDisplay = null

        runCatching {
            imageReader?.setOnImageAvailableListener(null, null)
            imageReader?.close()
        }
        imageReader = null

        runCatching {
            mediaProjection?.unregisterCallback(projectionCallback)
            mediaProjection?.stop()
        }
        mediaProjection = null

        captureThread?.quitSafely()
        captureThread = null
        captureHandler = null
    }

    private fun scaleDimensions(rawWidth: Int, rawHeight: Int): Pair<Int, Int> {
        val maxRaw = max(rawWidth, rawHeight).coerceAtLeast(1)
        val scale = min(1f, MAX_OUTPUT_DIMENSION.toFloat() / maxRaw.toFloat())
        val w = (rawWidth * scale).toInt().coerceAtLeast(2) and 1.inv()
        val h = (rawHeight * scale).toInt().coerceAtLeast(2) and 1.inv()
        return Pair(w, h)
    }

    private fun resolveScreenMetrics(): DisplayMetrics {
        val metrics = DisplayMetrics()
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = wm.currentWindowMetrics.bounds
            metrics.widthPixels = bounds.width()
            metrics.heightPixels = bounds.height()
            metrics.densityDpi = resources.configuration.densityDpi
        } else {
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(metrics)
        }
        return metrics
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.screen_share_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.screen_share_channel_desc)
                setShowBadge(false)
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun updateNotification(paused: Boolean) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, buildNotification(paused))
    }

    private fun buildNotification(paused: Boolean): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPending = PendingIntent.getActivity(
            this,
            10,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val toggleIntent = Intent(this, ScreenCaptureService::class.java).apply {
            action = if (paused) ACTION_RESUME else ACTION_PAUSE
        }
        val togglePending = PendingIntent.getService(
            this,
            11,
            toggleIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, ScreenCaptureService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPending = PendingIntent.getService(
            this,
            12,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = if (paused) {
            getString(R.string.screen_share_notif_paused)
        } else {
            getString(R.string.screen_share_notif_title)
        }
        val toggleLabel = if (paused) {
            getString(R.string.screen_share_action_resume)
        } else {
            getString(R.string.screen_share_action_pause)
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_screen_share)
            .setContentTitle(title)
            .setContentText(getString(R.string.screen_share_notif_text))
            .setOngoing(true)
            .setSilent(true)
            .setContentIntent(openPending)
            .addAction(0, toggleLabel, togglePending)
            .addAction(0, getString(R.string.screen_share_action_stop), stopPending)
            .build()
    }
}
