package com.nexcode.ai.audio

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.util.Base64
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread
import kotlin.math.sqrt

class LiveAudioEngine(
    private val onPcm16Base64: (String) -> Unit,
    private val onMicLevel: (Float) -> Unit,
    private val onSpeakingChanged: (Boolean) -> Unit,
    private val onAudioError: (String) -> Unit
) {
    companion object {
        private const val INPUT_SAMPLE_RATE = 16000
        private const val OUTPUT_SAMPLE_RATE = 24000
        private const val CHUNK_SAMPLES = 2048 // ~128ms per chunk at 16kHz
    }

    @Volatile
    private var running = false

    @Volatile
    private var muted = false

    private var audioRecord: AudioRecord? = null
    private var aec: AcousticEchoCanceler? = null
    private var noiseSuppressor: NoiseSuppressor? = null
    private var recordThread: Thread? = null

    private var audioTrack: AudioTrack? = null
    private var playbackThread: Thread? = null
    private val playbackQueue = LinkedBlockingQueue<ByteArray>()

    @Volatile
    private var lastAudioEnqueuedAt = 0L

    fun setMuted(isMuted: Boolean) {
        muted = isMuted
        if (isMuted) {
            onMicLevel(0f)
        }
    }

    @SuppressLint("MissingPermission")
    fun start() {
        if (running) return
        running = true
        playbackQueue.clear()

        if (!startPlayback() || !startCapture()) {
            stop()
        }
    }

    fun enqueuePcm24kBase64(base64Pcm: String) {
        if (!running) return
        val bytes = runCatching { Base64.decode(base64Pcm, Base64.DEFAULT) }.getOrNull() ?: return
        if (bytes.isEmpty()) return
        lastAudioEnqueuedAt = System.currentTimeMillis()
        onSpeakingChanged(true)
        playbackQueue.offer(bytes)
    }

    fun clearPlayback() {
        playbackQueue.clear()
        runCatching {
            audioTrack?.pause()
            audioTrack?.flush()
            if (running) audioTrack?.play()
        }
        onSpeakingChanged(false)
    }

    fun stop() {
        running = false
        playbackQueue.clear()
        onSpeakingChanged(false)
        onMicLevel(0f)

        runCatching { recordThread?.interrupt() }
        recordThread = null

        runCatching { playbackThread?.interrupt() }
        playbackThread = null

        runCatching { aec?.release() }
        aec = null

        runCatching { noiseSuppressor?.release() }
        noiseSuppressor = null

        runCatching {
            audioRecord?.stop()
            audioRecord?.release()
        }
        audioRecord = null

        runCatching {
            audioTrack?.pause()
            audioTrack?.flush()
            audioTrack?.stop()
            audioTrack?.release()
        }
        audioTrack = null
    }

    @SuppressLint("MissingPermission")
    private fun startCapture(): Boolean {
        val minBuf = AudioRecord.getMinBufferSize(
            INPUT_SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(CHUNK_SAMPLES * 2)

        val bufSize = (minBuf * 2).coerceAtLeast(CHUNK_SAMPLES * 4)

        val record = createAudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, bufSize)
            ?: createAudioRecord(MediaRecorder.AudioSource.MIC, bufSize)

        if (record == null || record.state != AudioRecord.STATE_INITIALIZED) {
            onAudioError("Microphone initialization failed on Android.")
            return false
        }

        audioRecord = record
        val sessionId = record.audioSessionId
        if (AcousticEchoCanceler.isAvailable()) {
            runCatching {
                aec = AcousticEchoCanceler.create(sessionId)?.apply { enabled = true }
            }
        }
        if (NoiseSuppressor.isAvailable()) {
            runCatching {
                noiseSuppressor = NoiseSuppressor.create(sessionId)?.apply { enabled = true }
            }
        }

        record.startRecording()

        recordThread = thread(name = "NexcodeMicCapture", isDaemon = true) {
            val shortBuf = ShortArray(CHUNK_SAMPLES)
            val byteBuf = ByteArray(CHUNK_SAMPLES * 2)
            while (running) {
                val readSamples = runCatching {
                    record.read(shortBuf, 0, shortBuf.size)
                }.getOrDefault(-1)

                if (readSamples <= 0) {
                    if (!running) break
                    continue
                }

                if (muted) {
                    onMicLevel(0f)
                    continue
                }

                var sumSq = 0.0
                for (i in 0 until readSamples) {
                    val sample = shortBuf[i]
                    val norm = sample / 32768.0
                    sumSq += norm * norm
                    byteBuf[i * 2] = (sample.toInt() and 0xFF).toByte()
                    byteBuf[i * 2 + 1] = ((sample.toInt() shr 8) and 0xFF).toByte()
                }
                val rms = sqrt(sumSq / readSamples).toFloat().coerceIn(0f, 1f)
                onMicLevel((rms * 3.5f).coerceIn(0f, 1f))

                val encoded = Base64.encodeToString(byteBuf, 0, readSamples * 2, Base64.NO_WRAP)
                onPcm16Base64(encoded)
            }
        }
        return true
    }

    @SuppressLint("MissingPermission")
    private fun createAudioRecord(source: Int, bufferSize: Int): AudioRecord? = runCatching {
        AudioRecord(
            source,
            INPUT_SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            bufferSize
        ).takeIf { it.state == AudioRecord.STATE_INITIALIZED }
    }.getOrNull()

    private fun startPlayback(): Boolean {
        val minOutBuf = AudioTrack.getMinBufferSize(
            OUTPUT_SAMPLE_RATE,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(4096)

        val track = runCatching {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(OUTPUT_SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(minOutBuf * 3)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
        }.getOrNull()

        if (track == null || track.state != AudioTrack.STATE_INITIALIZED) {
            onAudioError("Audio output initialization failed on Android.")
            return false
        }

        audioTrack = track
        track.play()

        playbackThread = thread(name = "NexcodeAudioPlayback", isDaemon = true) {
            while (running) {
                val chunk = runCatching {
                    playbackQueue.poll(180, TimeUnit.MILLISECONDS)
                }.getOrNull()

                if (chunk != null) {
                    runCatching {
                        track.write(chunk, 0, chunk.size, AudioTrack.WRITE_BLOCKING)
                    }
                } else if (playbackQueue.isEmpty() &&
                    System.currentTimeMillis() - lastAudioEnqueuedAt > 360L
                ) {
                    onSpeakingChanged(false)
                }
            }
        }
        return true
    }
}
