package com.nexcode.ai.data

import android.content.Context
import com.nexcode.ai.model.AttachmentKind
import com.nexcode.ai.model.ChatMessage
import com.nexcode.ai.model.ClipboardSnippet
import com.nexcode.ai.model.HistorySession
import java.io.File
import org.json.JSONArray
import org.json.JSONObject

class SessionStorage(context: Context) {

    private val prefs = context.getSharedPreferences("nexcode_prefs_v1", Context.MODE_PRIVATE)
    private val sessionsFile = File(context.filesDir, "nexcode_history_sessions.json")

    fun isOnboarded(): Boolean = prefs.getBoolean("onboarded", false)

    fun setOnboarded(value: Boolean) {
        prefs.edit().putBoolean("onboarded", value).apply()
    }

    fun getPreferredLanguage(): String =
        prefs.getString("preferred_language", "English") ?: "English"

    fun setPreferredLanguage(lang: String) {
        prefs.edit().putString("preferred_language", lang).apply()
    }

    @Synchronized
    fun loadSessions(): List<HistorySession> {
        if (!sessionsFile.exists()) return emptyList()
        return runCatching {
            val raw = sessionsFile.readText()
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val msgsArr = obj.optJSONArray("messages") ?: JSONArray()
                    val msgs = buildList {
                        for (j in 0 until msgsArr.length()) {
                            val m = msgsArr.getJSONObject(j)
                            val snippetObj = m.optJSONObject("clipboardSnippet")
                            val snippet = snippetObj?.let { s ->
                                ClipboardSnippet(
                                    id = s.optString("id"),
                                    title = s.optString("title"),
                                    language = s.optString("language"),
                                    code = s.optString("code"),
                                    createdAt = s.optLong("createdAt"),
                                    autoCopied = s.optBoolean("autoCopied", false)
                                )
                            }
                            val kindStr = m.optString("attachmentKind", "")
                            val kind = AttachmentKind.entries.firstOrNull { it.wireName == kindStr }
                            add(
                                ChatMessage(
                                    id = m.optString("id"),
                                    role = m.optString("role"),
                                    text = m.optString("text"),
                                    timestamp = m.optLong("timestamp"),
                                    attachmentName = m.optString("attachmentName", "").ifEmpty { null },
                                    attachmentKind = kind,
                                    usedScreenShare = m.optBoolean("usedScreenShare", false),
                                    clipboardSnippet = snippet
                                )
                            )
                        }
                    }
                    add(
                        HistorySession(
                            id = obj.optString("id"),
                            type = obj.optString("type", "chat"),
                            title = obj.optString("title", "Session"),
                            language = obj.optString("language", "English"),
                            updatedAt = obj.optLong("updatedAt"),
                            messages = msgs,
                            durationSeconds = if (obj.has("durationSeconds") && !obj.isNull("durationSeconds")) {
                                obj.optInt("durationSeconds")
                            } else {
                                null
                            }
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    @Synchronized
    fun saveSessions(sessions: List<HistorySession>) {
        runCatching {
            val arr = JSONArray()
            sessions.take(40).forEach { s ->
                val obj = JSONObject().apply {
                    put("id", s.id)
                    put("type", s.type)
                    put("title", s.title)
                    put("language", s.language)
                    put("updatedAt", s.updatedAt)
                    if (s.durationSeconds != null) put("durationSeconds", s.durationSeconds)
                    val msgsArr = JSONArray()
                    s.messages.forEach { m ->
                        val mObj = JSONObject().apply {
                            put("id", m.id)
                            put("role", m.role)
                            put("text", m.text)
                            put("timestamp", m.timestamp)
                            m.attachmentName?.let { put("attachmentName", it) }
                            m.attachmentKind?.let { put("attachmentKind", it.wireName) }
                            put("usedScreenShare", m.usedScreenShare)
                            m.clipboardSnippet?.let { snip ->
                                put(
                                    "clipboardSnippet",
                                    JSONObject().apply {
                                        put("id", snip.id)
                                        put("title", snip.title)
                                        put("language", snip.language)
                                        put("code", snip.code)
                                        put("createdAt", snip.createdAt)
                                        put("autoCopied", snip.autoCopied)
                                    }
                                )
                            }
                        }
                        msgsArr.put(mObj)
                    }
                    put("messages", msgsArr)
                }
                arr.put(obj)
            }
            sessionsFile.writeText(arr.toString())
        }
    }
}
