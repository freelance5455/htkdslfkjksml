package com.nexcode.ai.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexcode.ai.ui.theme.NexcodeColors
import kotlinx.coroutines.delay

private sealed class MarkdownSegment {
    data class TextBlock(val text: String) : MarkdownSegment()
    data class CodeBlock(val language: String, val code: String) : MarkdownSegment()
}

private fun parseMarkdownSegments(markdown: String): List<MarkdownSegment> {
    val result = mutableListOf<MarkdownSegment>()
    val regex = Regex("""```([a-zA-Z0-9_+-]*)\n?([\s\S]*?)```""")
    var cursor = 0
    for (match in regex.findAll(markdown)) {
        if (match.range.first > cursor) {
            val plain = markdown.substring(cursor, match.range.first)
            if (plain.isNotBlank()) result.add(MarkdownSegment.TextBlock(plain))
        }
        val lang = match.groupValues[1].trim()
        val code = match.groupValues[2].trimEnd()
        result.add(MarkdownSegment.CodeBlock(lang, code))
        cursor = match.range.last + 1
    }
    if (cursor < markdown.length) {
        val tail = markdown.substring(cursor)
        if (tail.isNotBlank()) result.add(MarkdownSegment.TextBlock(tail))
    }
    return if (result.isEmpty()) listOf(MarkdownSegment.TextBlock(markdown)) else result
}

@Composable
fun MarkdownCodeView(
    text: String,
    onCopyCode: (code: String, label: String) -> Unit
) {
    val segments = remember(text) { parseMarkdownSegments(text) }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        segments.forEachIndexed { idx, segment ->
            when (segment) {
                is MarkdownSegment.CodeBlock -> {
                    CodeBlockCard(
                        language = segment.language,
                        code = segment.code,
                        onCopy = {
                            onCopyCode(
                                segment.code,
                                if (segment.language.isNotEmpty()) "${segment.language} snippet" else "Code snippet"
                            )
                        }
                    )
                }
                is MarkdownSegment.TextBlock -> {
                    FormattedMarkdownParagraphs(segment.text)
                }
            }
        }
    }
}

@Composable
private fun CodeBlockCard(
    language: String,
    code: String,
    onCopy: () -> Unit
) {
    var copied by remember { mutableStateOf(false) }

    LaunchedEffect(copied) {
        if (copied) {
            delay(1800)
            copied = false
        }
    }

    val lineCount = remember(code) { code.lines().size }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(NexcodeColors.Black)
            .border(1.dp, NexcodeColors.Border, RoundedCornerShape(12.dp))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xE618181B))
                .padding(horizontal = 12.dp, vertical = 7.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = language.ifEmpty { "code" },
                color = Color(0xFF67E8F9),
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )
            CopyActionChip(
                label = if (copied) "Copied" else "Copy",
                copied = copied,
                onClick = {
                    onCopy()
                    copied = true
                }
            )
        }

        HorizontalDivider(color = NexcodeColors.Border)

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(12.dp)
        ) {
            Text(
                text = code,
                color = NexcodeColors.TextPrimary,
                fontSize = 12.sp,
                lineHeight = 18.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        HorizontalDivider(color = NexcodeColors.Border)

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xE618181B))
                .padding(horizontal = 12.dp, vertical = 7.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "$lineCount lines",
                color = NexcodeColors.TextMuted,
                fontSize = 11.sp
            )
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(NexcodeColors.Border)
                    .clickable {
                        onCopy()
                        copied = true
                    }
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Icon(
                        imageVector = if (copied) Icons.Outlined.Check else Icons.Outlined.ContentCopy,
                        contentDescription = null,
                        tint = if (copied) NexcodeColors.Emerald else NexcodeColors.TextPrimary,
                        modifier = Modifier.size(13.dp)
                    )
                    Text(
                        text = if (copied) "Copied" else "Copy Code",
                        color = NexcodeColors.TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

@Composable
private fun CopyActionChip(
    label: String,
    copied: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Icon(
            imageVector = if (copied) Icons.Outlined.Check else Icons.Outlined.ContentCopy,
            contentDescription = null,
            tint = if (copied) NexcodeColors.Emerald else NexcodeColors.TextPrimary,
            modifier = Modifier.size(13.dp)
        )
        Text(
            text = label,
            color = NexcodeColors.TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun FormattedMarkdownParagraphs(text: String) {
    val lines = remember(text) { text.trim().lines() }
    val inlineRegex = remember { Regex("""(`[^`]+`|\*\*[^*]+\*\*)""") }

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        lines.forEach { line ->
            if (line.isBlank()) {
                Spacer(modifier = Modifier.height(2.dp))
            } else {
                val annotated = buildAnnotatedString {
                    var pos = 0
                    for (match in inlineRegex.findAll(line)) {
                        if (match.range.first > pos) {
                            append(line.substring(pos, match.range.first))
                        }
                        val token = match.value
                        if (token.startsWith("`") && token.endsWith("`")) {
                            withStyle(
                                SpanStyle(
                                    color = Color(0xFFA5F3FC),
                                    background = NexcodeColors.Border,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 13.sp
                                )
                            ) {
                                append(" ${token.substring(1, token.length - 1)} ")
                            }
                        } else if (token.startsWith("**") && token.endsWith("**")) {
                            withStyle(
                                SpanStyle(
                                    color = Color.White,
                                    fontWeight = FontWeight.SemiBold
                                )
                            ) {
                                append(token.substring(2, token.length - 2))
                            }
                        }
                        pos = match.range.last + 1
                    }
                    if (pos < line.length) {
                        append(line.substring(pos))
                    }
                }
                Text(
                    text = annotated,
                    color = NexcodeColors.TextPrimary,
                    fontSize = 14.sp,
                    lineHeight = 21.sp
                )
            }
        }
    }
}
