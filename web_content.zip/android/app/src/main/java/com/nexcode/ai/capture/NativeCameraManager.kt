package com.nexcode.ai.capture

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.util.Base64
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.io.ByteArrayOutputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Fast, low-latency Jetpack CameraX frame pipeline using STRATEGY_KEEP_ONLY_LATEST.
 */
class NativeCameraManager(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner,
    private val onFrameReady: (
        base64Jpeg: String,
        width: Int,
        height: Int,
        timestampMs: Long,
        forAiVision: Boolean
    ) -> Unit,
    private val onStateChanged: (status: String, facing: String, message: String?, w: Int, h: Int) -> Unit,
    private val onError: (String) -> Unit
) {
    private var cameraProvider: ProcessCameraProvider? = null
    private val analysisExecutor: ExecutorService = Executors.newSingleThreadExecutor()

    @Volatile
    private var isActive = false

    @Volatile
    private var useBackCamera = true

    @Volatile
    private var forceAiFrame = true

    private var lastPreviewSentAtMs = 0L
    private var lastAiVisionSentAtMs = 0L

    companion object {
        private const val PREVIEW_INTERVAL_MS = 100L
        private const val AI_VISION_INTERVAL_MS = 700L
        private const val JPEG_QUALITY = 74
    }

    fun start(facingBack: Boolean = true) {
        useBackCamera = facingBack
        forceAiFrame = true
        onStateChanged("starting", facingLabel(), "Starting fast CameraX vision...", 0, 0)

        val providerFuture = ProcessCameraProvider.getInstance(context)
        providerFuture.addListener({
            try {
                val provider = providerFuture.get()
                cameraProvider = provider
                bindAnalysis(provider)
            } catch (err: Throwable) {
                isActive = false
                onError("CameraX initialization failed: ${err.message ?: "unknown error"}")
            }
        }, ContextCompat.getMainExecutor(context))
    }

    fun switchLens() {
        useBackCamera = !useBackCamera
        forceAiFrame = true
        val provider = cameraProvider
        if (provider != null && isActive) {
            ContextCompat.getMainExecutor(context).execute {
                bindAnalysis(provider)
            }
        } else {
            start(useBackCamera)
        }
    }

    fun requestImmediateAiFrame() {
        forceAiFrame = true
    }

    fun stop() {
        isActive = false
        ContextCompat.getMainExecutor(context).execute {
            runCatching { cameraProvider?.unbindAll() }
            onStateChanged("stopped", facingLabel(), "Camera stopped", 0, 0)
        }
    }

    fun release() {
        stop()
        runCatching { analysisExecutor.shutdownNow() }
    }

    private fun bindAnalysis(provider: ProcessCameraProvider) {
        try {
            provider.unbindAll()

            val selector = if (useBackCamera) {
                CameraSelector.DEFAULT_BACK_CAMERA
            } else {
                CameraSelector.DEFAULT_FRONT_CAMERA
            }

            val resolutionSelector = ResolutionSelector.Builder()
                .setResolutionStrategy(
                    ResolutionStrategy(
                        Size(720, 480),
                        ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER
                    )
                )
                .build()

            val analysis = ImageAnalysis.Builder()
                .setResolutionSelector(resolutionSelector)
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()

            analysis.setAnalyzer(analysisExecutor) { imageProxy ->
                processImageProxy(imageProxy)
            }

            provider.bindToLifecycle(lifecycleOwner, selector, analysis)
            isActive = true
            onStateChanged("active", facingLabel(), "Fast CameraX live", 720, 480)
        } catch (err: Throwable) {
            isActive = false
            onError("Could not bind camera: ${err.message ?: "unavailable"}")
        }
    }

    private fun processImageProxy(imageProxy: ImageProxy) {
        try {
            if (!isActive) return
            val now = System.currentTimeMillis()
            val previewDue = (now - lastPreviewSentAtMs) >= PREVIEW_INTERVAL_MS
            val aiDue = forceAiFrame || (now - lastAiVisionSentAtMs) >= AI_VISION_INTERVAL_MS

            if (!previewDue && !aiDue) {
                return
            }

            val bitmap = imageProxy.toBitmap()
            val rotation = imageProxy.imageInfo.rotationDegrees
            val uprightBitmap = if (rotation != 0) {
                val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
                Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
                    .also { bitmap.recycle() }
            } else {
                bitmap
            }

            val out = ByteArrayOutputStream()
            uprightBitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)
            val w = uprightBitmap.width
            val h = uprightBitmap.height
            uprightBitmap.recycle()

            val base64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
            lastPreviewSentAtMs = now
            if (aiDue) {
                lastAiVisionSentAtMs = now
                forceAiFrame = false
            }

            onFrameReady(base64, w, h, now, aiDue)
        } catch (_: Throwable) {
            // Skip corrupted frame without breaking the live stream
        } finally {
            imageProxy.close()
        }
    }

    private fun facingLabel(): String = if (useBackCamera) "back" else "front"
}
