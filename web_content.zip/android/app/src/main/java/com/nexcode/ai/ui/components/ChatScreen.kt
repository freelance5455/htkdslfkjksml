package com.nexcode.ai.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.outlined.AttachFile
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material.icons.outlined.Videocam
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexcode.ai.model.AttachmentKind
import com.nexcode.ai.model.ChatMessage
import com.nexcode.ai.model.MediaAttachment
import com.nexcode.ai.ui.theme.NexcodeColors

@Composable
fun ChatScreen(
    messages: List<ChatMessage>,
    chatInput: String,
    chatLoading: Boolean,
    pendingAttachment: MediaAttachment?,
    onChatInputChanged: (String) -> Unit,
    onAttachClick: () -> Unit,
    onClearAttachment: () -> Unit,
    onSendMessage: () -> Unit,
    onStopGeneration: () -> Unit,
    onRegenerateLast: () -> Unit,
    onCopyCode: (code: String, label: String) -> Unit
) {
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size, chatLoading) {
        val target = messages.size + (if (chatLoading) 1 else 0) - 1
        if (target >= 0) {
            listState.animateScrollToItem(target)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NexcodeColors.Black)
            .imePadding()
    ) {
        // Message list / Empty State
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            if (messages.isEmpty() && !chatLoading) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    NexcodeLogo(size = 44.dp)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "NEXCODE AI Chat",
                        color = NexcodeColors.TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Ask any question, generate or debug code, attach photos, videos, or source files, or switch to Call for live voice and screen sharing.",
                        color = NexcodeColors.TextDim,
                        fontSize = 12.sp,
                        lineHeight = 18.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.widthIn(max = 360.dp)
                    )
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item { Spacer(modifier = Modifier.height(6.dp)) }

                    itemsIndexed(messages, key = { _, m -> m.id }) { idx, msg ->
                        val isUser = msg.role == "user"
                        val isLastAssistant = !isUser && idx == messages.lastIndex && !chatLoading

                        Box(
                            modifier = Modifier.fillMaxWidth(),
                            contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
                        ) {
                            Column(
                                modifier = Modifier
                                    .widthIn(max = 340.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .then(
                                        if (isUser) {
                                            Modifier.background(NexcodeColors.BlueCyanGradient)
                                        } else {
                                            Modifier
                                                .background(NexcodeColors.CardBg)
                                                .border(
                                                    1.dp,
                                                    NexcodeColors.Border,
                                                    RoundedCornerShape(16.dp)
                                                )
                                        }
                                    )
                                    .padding(horizontal = 14.dp, vertical = 12.dp)
                            ) {
                                // Attached image preview
                                msg.previewBitmap?.let { bmp ->
                                    val imgBmp = remember(bmp) { bmp.asImageBitmap() }
                                    Image(
                                        bitmap = imgBmp,
                                        contentDescription = msg.attachmentName ?: "Attached image",
                                        contentScale = ContentScale.Fit,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .heightIn(max = 220.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .padding(bottom = 8.dp)
                                    )
                                }

                                // Non-image attachment badge (video / code / persisted image name)
                                if (msg.previewBitmap == null && !msg.attachmentName.isNullOrBlank()) {
                                    Row(
                                        modifier = Modifier.padding(bottom = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (msg.attachmentKind == AttachmentKind.VIDEO) {
                                                Icons.Outlined.Videocam
                                            } else {
                                                Icons.Outlined.Description
                                            },
                                            contentDescription = null,
                                            tint = Color(0xFFCFFAFE),
                                            modifier = Modifier.size(15.dp)
                                        )
                                        Text(
                                            text = msg.attachmentName,
                                            color = Color(0xFFCFFAFE),
                                            fontSize = 12.sp,
                                            fontFamily = FontFamily.Monospace,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }

                                if (isUser) {
                                    Text(
                                        text = msg.text,
                                        color = Color.White,
                                        fontSize = 14.sp,
                                        lineHeight = 20.sp
                                    )
                                } else {
                                    MarkdownCodeView(
                                        text = msg.text,
                                        onCopyCode = onCopyCode
                                    )

                                    msg.clipboardSnippet?.let { snippet ->
                                        Spacer(modifier = Modifier.height(10.dp))
                                        HorizontalDivider(color = NexcodeColors.Border)
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Outlined.Check,
                                                    contentDescription = null,
                                                    tint = NexcodeColors.Emerald,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                                Text(
                                                    text = "${snippet.title} ready",
                                                    color = NexcodeColors.TextMuted,
                                                    fontSize = 12.sp,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .background(NexcodeColors.SurfaceDark)
                                                    .border(
                                                        1.dp,
                                                        Color(0xFF3F3F46),
                                                        RoundedCornerShape(6.dp)
                                                    )
                                                    .clickable {
                                                        onCopyCode(snippet.code, snippet.title)
                                                    }
                                                    .padding(horizontal = 12.dp, vertical = 5.dp)
                                            ) {
                                                Text(
                                                    text = "Copy",
                                                    color = NexcodeColors.CyanLight,
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Medium
                                                )
                                            }
                                        }
                                    }

                                    if (isLastAssistant) {
                                        Spacer(modifier = Modifier.height(10.dp))
                                        HorizontalDivider(color = NexcodeColors.BorderSubtle)
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.End
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .clickable(onClick = onRegenerateLast)
                                                    .padding(horizontal = 6.dp, vertical = 3.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Outlined.Refresh,
                                                    contentDescription = null,
                                                    tint = NexcodeColors.TextMuted,
                                                    modifier = Modifier.size(13.dp)
                                                )
                                                Text(
                                                    text = "Regenerate",
                                                    color = NexcodeColors.TextMuted,
                                                    fontSize = 12.sp
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (chatLoading) {
                        item {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(NexcodeColors.CardBg)
                                    .border(1.dp, NexcodeColors.Border, RoundedCornerShape(16.dp))
                                    .padding(horizontal = 16.dp, vertical = 12.dp)
                            ) {
                                Text(
                                    text = "Thinking...",
                                    color = NexcodeColors.TextMuted,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }

                    item { Spacer(modifier = Modifier.height(6.dp)) }
                }
            }
        }

        // Pending Attachment Strip
        if (pendingAttachment != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(NexcodeColors.CardBg)
                    .border(1.dp, NexcodeColors.Border, RoundedCornerShape(12.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (pendingAttachment.previewBitmap != null) {
                        val thumb = remember(pendingAttachment.previewBitmap) {
                            pendingAttachment.previewBitmap.asImageBitmap()
                        }
                        Image(
                            bitmap = thumb,
                            contentDescription = pendingAttachment.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .border(1.dp, NexcodeColors.Border, RoundedCornerShape(6.dp))
                        )
                    } else {
                        Icon(
                            imageVector = if (pendingAttachment.kind == AttachmentKind.VIDEO) {
                                Icons.Outlined.Videocam
                            } else {
                                Icons.Outlined.Description
                            },
                            contentDescription = null,
                            tint = NexcodeColors.CyanLight,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Text(
                        text = pendingAttachment.name,
                        color = NexcodeColors.TextPrimary,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(
                    onClick = onClearAttachment,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Close,
                        contentDescription = "Remove attachment",
                        tint = NexcodeColors.TextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        // Bottom Composer
        HorizontalDivider(color = NexcodeColors.BorderSubtle)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(NexcodeColors.Black)
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(NexcodeColors.CardBg)
                    .border(1.dp, NexcodeColors.Border, RoundedCornerShape(12.dp))
                    .clickable(onClick = onAttachClick),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Outlined.AttachFile,
                    contentDescription = "Attach photo, video, or source code file",
                    tint = Color(0xFFD4D4D8),
                    modifier = Modifier.size(18.dp)
                )
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 44.dp, max = 120.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(NexcodeColors.CardBg)
                    .border(1.dp, NexcodeColors.Border, RoundedCornerShape(12.dp))
                    .padding(horizontal = 14.dp, vertical = 11.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                BasicTextField(
                    value = chatInput,
                    onValueChange = onChatInputChanged,
                    maxLines = 5,
                    textStyle = TextStyle(
                        color = NexcodeColors.TextPrimary,
                        fontSize = 14.sp,
                        lineHeight = 20.sp
                    ),
                    cursorBrush = SolidColor(NexcodeColors.CyanLight),
                    modifier = Modifier.fillMaxWidth(),
                    decorationBox = { inner ->
                        if (chatInput.isEmpty()) {
                            Text(
                                text = "Ask NEXCODE AI anything or attach a screenshot...",
                                color = NexcodeColors.TextDim,
                                fontSize = 13.5.sp
                            )
                        }
                        inner()
                    }
                )
            }

            if (chatLoading) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(NexcodeColors.Red)
                        .clickable(onClick = onStopGeneration),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Stop,
                        contentDescription = "Stop response",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            } else {
                val canSend = chatInput.isNotBlank() || pendingAttachment != null
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .then(
                            if (canSend) Modifier.background(NexcodeColors.BlueCyanGradient)
                            else Modifier.background(Color(0x662563EB))
                        )
                        .clickable(enabled = canSend, onClick = onSendMessage),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Outlined.Send,
                        contentDescription = "Send message",
                        tint = if (canSend) Color.White else Color(0x88FFFFFF),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}
