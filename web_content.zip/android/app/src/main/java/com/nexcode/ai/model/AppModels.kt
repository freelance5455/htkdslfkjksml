package com.nexcode.ai.model

import android.graphics.Bitmap

enum class WorkspaceTab {
    CHAT,
    CALL
}

enum class VisualMode {
    NONE,
    SCREEN,
    CAMERA
}

enum class ScreenShareSource(val wireName: String) {
    NONE("none"),
    ANDROID_MEDIAPROJECTION("android_mediaprojection"),
    ANDROID_CAMERAX("android_camerax")
}

enum class ScreenShareStatus {
    IDLE,
    REQUESTING,
    ACTIVE,
    PAUSED,
    ERROR
}

enum class AttachmentKind(val wireName: String) {
    IMAGE("image"),
    VIDEO("video"),
    CODE("code")
}

data class MediaAttachment(
    val name: String,
    val mimeType: String,
    val data: String,
    val kind: AttachmentKind,
    val previewBitmap: Bitmap? = null
)

data class ClipboardSnippet(
    val id: String,
    val title: String,
    val language: String,
    val code: String,
    val createdAt: Long,
    val autoCopied: Boolean = false
)

data class ChatMessage(
    val id: String,
    val role: String, // "user" or "assistant"
    val text: String,
    val timestamp: Long,
    val attachmentName: String? = null,
    val attachmentKind: AttachmentKind? = null,
    val usedScreenShare: Boolean = false,
    val clipboardSnippet: ClipboardSnippet? = null,
    val previewBitmap: Bitmap? = null
)

data class HistorySession(
    val id: String,
    val type: String, // "chat", "call", "media"
    val title: String,
    val language: String,
    val updatedAt: Long,
    val messages: List<ChatMessage>,
    val durationSeconds: Int? = null
)

enum class PermissionStateLabel {
    GRANTED,
    PROMPT,
    DENIED,
    ACTIVE,
    IDLE
}

data class PermissionStatusMap(
    val microphone: PermissionStateLabel = PermissionStateLabel.PROMPT,
    val screenShare: PermissionStateLabel = PermissionStateLabel.IDLE,
    val clipboard: PermissionStateLabel = PermissionStateLabel.PROMPT
)

val ONBOARDING_LANGUAGES = listOf(
    "English",
    "Roman Urdu",
    "Urdu",
    "Hindi",
    "Arabic",
    "Spanish",
    "French",
    "German",
    "Japanese"
)

val CALL_LANGUAGES = listOf(
    "English",
    "Urdu",
    "Roman Urdu",
    "Hindi",
    "Punjabi",
    "Pashto",
    "Arabic",
    "Turkish",
    "Spanish",
    "French",
    "German",
    "Japanese",
    "Chinese",
    "Korean",
    "Bengali"
)

private val LANGUAGE_SWITCH_INTENT = Regex(
    """\b(speak|talk|reply|answer|switch|change|use|baat|bat|bolo|bol|kaho|kah|zaban|zubaan|zabaan|language|mein|main|me|in|to)\b""",
    RegexOption.IGNORE_CASE
)
private val NON_LATIN_SCRIPT = Regex("""[\u0600-\u06FF\u0900-\u097F]""")

private val LANGUAGE_PATTERNS: List<Pair<String, Regex>> = listOf(
    "Roman Urdu" to Regex("""\broman\s*urdu\b""", RegexOption.IGNORE_CASE),
    "Urdu" to Regex("""\b(urdu|اُردو|اردو)\b""", RegexOption.IGNORE_CASE),
    "Hindi" to Regex("""\b(hindi|हिन्दी|हिंदी)\b""", RegexOption.IGNORE_CASE),
    "Punjabi" to Regex("""\b(punjabi|پنجابی|ਪੰਜਾਬੀ)\b""", RegexOption.IGNORE_CASE),
    "Pashto" to Regex("""\b(pashto|pushto|پښتو)\b""", RegexOption.IGNORE_CASE),
    "Arabic" to Regex("""\b(arabic|arabi|العربية|عربي)\b""", RegexOption.IGNORE_CASE),
    "Turkish" to Regex("""\bturkish\b""", RegexOption.IGNORE_CASE),
    "Spanish" to Regex("""\b(spanish|español|espanol)\b""", RegexOption.IGNORE_CASE),
    "French" to Regex("""\b(french|français|francais)\b""", RegexOption.IGNORE_CASE),
    "German" to Regex("""\b(german|deutsch)\b""", RegexOption.IGNORE_CASE),
    "Japanese" to Regex("""\b(japanese|nihongo)\b""", RegexOption.IGNORE_CASE),
    "Chinese" to Regex("""\b(chinese|mandarin)\b""", RegexOption.IGNORE_CASE),
    "Korean" to Regex("""\bkorean\b""", RegexOption.IGNORE_CASE),
    "Bengali" to Regex("""\b(bengali|bangla)\b""", RegexOption.IGNORE_CASE),
    "English" to Regex("""\b(english|angrezi|angrazi)\b""", RegexOption.IGNORE_CASE)
)

fun detectRequestedLanguage(text: String): String? {
    val clean = text.trim()
    if (clean.isEmpty()) return null
    val hasIntent = LANGUAGE_SWITCH_INTENT.containsMatchIn(clean) || NON_LATIN_SCRIPT.containsMatchIn(clean)
    if (!hasIntent) return null
    for ((name, regex) in LANGUAGE_PATTERNS) {
        if (regex.containsMatchIn(clean)) return name
    }
    return null
}
