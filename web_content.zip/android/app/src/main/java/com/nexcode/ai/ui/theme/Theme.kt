package com.nexcode.ai.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

object NexcodeColors {
    val Black = Color(0xFF000000)
    val CardBg = Color(0xFF09090B)       // zinc-950
    val SurfaceDark = Color(0xFF18181B)  // zinc-900
    val Border = Color(0xFF27272A)       // zinc-800
    val BorderSubtle = Color(0xFF18181B) // zinc-900
    val TextPrimary = Color(0xFFF4F4F5)  // zinc-100
    val TextMuted = Color(0xFFA1A1AA)    // zinc-400
    val TextDim = Color(0xFF71717A)      // zinc-500

    val Blue = Color(0xFF2563EB)
    val BlueLight = Color(0xFF60A5FA)
    val Cyan = Color(0xFF0891B2)
    val CyanLight = Color(0xFF22D3EE)
    val Purple = Color(0xFF9333EA)
    val Emerald = Color(0xFF34D399)
    val EmeraldBorder = Color(0xFF047857)
    val EmeraldBg = Color(0x4D022C22)
    val Amber = Color(0xFFFBBF24)
    val AmberBorder = Color(0xB3D97706)
    val AmberBg = Color(0x99451A03)
    val Red = Color(0xFFDC2626)
    val RedLight = Color(0xFFF87171)
    val RedBorder = Color(0xB37F1D1D)
    val RedBg = Color(0x80450A0A)

    val BrandGradient = Brush.horizontalGradient(
        colors = listOf(Blue, Cyan, Purple)
    )

    val BlueCyanGradient = Brush.horizontalGradient(
        colors = listOf(Blue, Cyan)
    )

    val TitleGradient = Brush.horizontalGradient(
        colors = listOf(Color(0xFF60A5FA), Color(0xFF67E8F9), Color(0xFFC084FC))
    )
}

private val DarkScheme = darkColorScheme(
    primary = NexcodeColors.Blue,
    secondary = NexcodeColors.Cyan,
    tertiary = NexcodeColors.Purple,
    background = NexcodeColors.Black,
    surface = NexcodeColors.CardBg,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = NexcodeColors.TextPrimary,
    onSurface = NexcodeColors.TextPrimary
)

@Composable
fun NexcodeTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkScheme,
        content = content
    )
}
