package com.nexcode.ai.capture

import java.util.concurrent.CopyOnWriteArraySet

enum class NativeShareStatus(val wireName: String) {
    IDLE("idle"),
    REQUESTING("requesting"),
    ACTIVE("active"),
    PAUSED("paused"),
    STOPPED("stopped"),
    ERROR("error")
}

interface NativeScreenShareListener {
    fun onFrame(base64Jpeg: String, width: Int, height: Int, timestampMs: Long)
    fun onStateChanged(status: NativeShareStatus, message: String?, width: Int, height: Int)
    fun onError(errorMessage: String)
}

object ScreenShareState {
    @Volatile
    var currentStatus: NativeShareStatus = NativeShareStatus.IDLE
        private set

    @Volatile
    var lastWidth: Int = 0
        private set

    @Volatile
    var lastHeight: Int = 0
        private set

    @Volatile
    var lastFrameBase64: String? = null
        private set

    private val listeners = CopyOnWriteArraySet<NativeScreenShareListener>()

    fun addListener(listener: NativeScreenShareListener) {
        listeners.add(listener)
    }

    fun removeListener(listener: NativeScreenShareListener) {
        listeners.remove(listener)
    }

    fun publishFrame(base64Jpeg: String, width: Int, height: Int, timestampMs: Long) {
        lastFrameBase64 = base64Jpeg
        lastWidth = width
        lastHeight = height
        for (listener in listeners) {
            listener.onFrame(base64Jpeg, width, height, timestampMs)
        }
    }

    fun publishState(
        status: NativeShareStatus,
        message: String? = null,
        width: Int = lastWidth,
        height: Int = lastHeight
    ) {
        currentStatus = status
        lastWidth = width
        lastHeight = height
        if (status == NativeShareStatus.IDLE || status == NativeShareStatus.STOPPED) {
            lastFrameBase64 = null
        }
        for (listener in listeners) {
            listener.onStateChanged(status, message, width, height)
        }
    }

    fun publishError(errorMessage: String) {
        currentStatus = NativeShareStatus.ERROR
        for (listener in listeners) {
            listener.onError(errorMessage)
        }
    }
}
