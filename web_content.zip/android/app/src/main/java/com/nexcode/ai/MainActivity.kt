package com.nexcode.ai

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color as AndroidColor
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material.icons.outlined.Phone
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexcode.ai.capture.NativeCameraManager
import com.nexcode.ai.capture.NativeShareStatus
import com.nexcode.ai.capture.ScreenCaptureService
import com.nexcode.ai.capture.ScreenShareState
import com.nexcode.ai.model.VisualMode
import com.nexcode.ai.model.WorkspaceTab
import com.nexcode.ai.ui.NexcodeViewModel
import com.nexcode.ai.ui.components.ChatScreen
import com.nexcode.ai.ui.components.HistoryDrawerContent
import com.nexcode.ai.ui.components.NexcodeLogo
import com.nexcode.ai.ui.components.OnboardingSetupScreen
import com.nexcode.ai.ui.components.VoiceCallScreen
import com.nexcode.ai.ui.theme.NexcodeColors
import com.nexcode.ai.ui.theme.NexcodeTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: NexcodeViewModel by viewModels()
    private lateinit var cameraManager: NativeCameraManager

    @Volatile
    private var isRequestingProjection = false
    private var pendingMicAction: (() -> Unit)? = null
    private var pendingCameraAction: (() -> Unit)? = null
    private var pendingOnboardingContinue = false

    private val permissionsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
            viewModel.refreshCapabilitiesAndPermissions()

            if (results.containsKey(Manifest.permission.RECORD_AUDIO)) {
                if (results[Manifest.permission.RECORD_AUDIO] == true) {
                    val action = pendingMicAction
                    pendingMicAction = null
                    action?.invoke()
                } else {
                    pendingMicAction = null
                    viewModel.markMicDenied()
                    viewModel.showToast("Microphone permission is required for voice calls.")
                }
            }

            if (results.containsKey(Manifest.permission.CAMERA)) {
                if (results[Manifest.permission.CAMERA] == true) {
                    val action = pendingCameraAction
                    pendingCameraAction = null
                    action?.invoke()
                } else {
                    pendingCameraAction = null
                    viewModel.markCameraDenied()
                    viewModel.showToast("Camera permission denied on Android.")
                }
            }

            if (pendingOnboardingContinue) {
                pendingOnboardingContinue = false
                viewModel.completeOnboarding()
            }
        }

    private val mediaProjectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            isRequestingProjection = false
            if (result.resultCode == RESULT_OK && result.data != null) {
                val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                    action = ScreenCaptureService.ACTION_START
                    putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, result.data)
                    putExtra(ScreenCaptureService.EXTRA_INTERVAL_MS, 950L)
                }
                ContextCompat.startForegroundService(this, serviceIntent)
            } else {
                ScreenShareState.publishState(
                    NativeShareStatus.STOPPED,
                    "Screen sharing permission canceled"
                )
            }
        }

    private val overlayPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            val intent = Intent(this, ScreenCaptureService::class.java).apply {
                action = ScreenCaptureService.ACTION_REFRESH_OVERLAY
            }
            runCatching { startService(intent) }
            viewModel.refreshCapabilitiesAndPermissions()
        }

    private val chatFilePickerLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            uri?.let { viewModel.attachChatFile(it) }
        }

    private val callMediaPickerLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            uri?.let { viewModel.attachCallMedia(it) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.BLACK),
            navigationBarStyle = SystemBarStyle.dark(AndroidColor.BLACK)
        )

        cameraManager = NativeCameraManager(
            context = this,
            lifecycleOwner = this,
            onFrameReady = { base64Jpeg, _, _, ts, forAiVision ->
                viewModel.onCameraFrame(base64Jpeg, ts, forAiVision)
            },
            onStateChanged = { status, _, message, _, _ ->
                viewModel.onCameraStateChanged(status, message)
            },
            onError = { errMsg ->
                viewModel.onCameraError(errMsg)
            }
        )
        viewModel.attachCameraManager(cameraManager)
        viewModel.refreshCapabilitiesAndPermissions()

        setContent {
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()

            NexcodeTheme {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(NexcodeColors.Black)
                ) {
                    if (!uiState.onboarded) {
                        OnboardingSetupScreen(
                            language = uiState.language,
                            permissions = uiState.permissions,
                            onChangeLanguage = viewModel::setLanguage,
                            onRequestMicrophone = {
                                ensureMicPermission {
                                    viewModel.refreshCapabilitiesAndPermissions()
                                    viewModel.showToast("Microphone enabled")
                                }
                            },
                            onRequestClipboard = viewModel::markClipboardAllowed,
                            onRequestScreenOrCamera = {
                                ensureCameraPermission {
                                    viewModel.refreshCapabilitiesAndPermissions()
                                    viewModel.showToast("Camera permission allowed")
                                }
                            },
                            onContinueToChat = ::handleOnboardingContinue
                        )
                    } else {
                        NexcodeMainScaffold(
                            uiState = uiState,
                            onSelectTab = viewModel::setTab,
                            onNewChat = viewModel::startNewChat,
                            onSelectSession = viewModel::loadSession,
                            onRenameSession = viewModel::renameSession,
                            onDeleteSession = viewModel::deleteSession,
                            onClearAllHistory = viewModel::clearAllHistory,
                            onChatInputChanged = viewModel::updateChatInput,
                            onAttachChatFile = {
                                chatFilePickerLauncher.launch(arrayOf("image/*", "video/*", "text/*", "*/*"))
                            },
                            onClearAttachment = viewModel::clearPendingAttachment,
                            onSendChat = viewModel::sendChatMessage,
                            onStopChat = viewModel::stopChatGeneration,
                            onRegenerateLast = viewModel::regenerateLastResponse,
                            onCopyCode = { code, label ->
                                viewModel.copyToClipboard(code, label, showFeedback = true)
                            },
                            onStartCall = {
                                ensureMicPermission {
                                    viewModel.startVoiceCallAfterMicGranted()
                                }
                            },
                            onEndCall = viewModel::endVoiceCall,
                            onToggleMute = viewModel::toggleMute,
                            onChangeCallLanguage = viewModel::changeCallLanguage,
                            onToggleScreenShare = {
                                if (uiState.visualMode == VisualMode.SCREEN) {
                                    viewModel.stopVisualShare()
                                } else {
                                    if (uiState.visualMode == VisualMode.CAMERA) {
                                        viewModel.stopVisualShare()
                                    }
                                    launchSystemScreenCaptureDialog()
                                }
                            },
                            onTogglePauseScreenShare = viewModel::togglePauseScreenShare,
                            onRequestOverlayIndicator = ::requestOverlayPermissionScreen,
                            onDismissScreenShareError = viewModel::dismissScreenShareError,
                            onToggleCamera = {
                                if (uiState.visualMode == VisualMode.CAMERA) {
                                    viewModel.stopVisualShare()
                                } else {
                                    ensureCameraPermission {
                                        viewModel.startCameraXAfterPermissionGranted()
                                    }
                                }
                            },
                            onSwitchCameraLens = viewModel::switchCameraLens,
                            onAttachCallMedia = {
                                callMediaPickerLauncher.launch(arrayOf("image/*", "video/*"))
                            },
                            onSendCallText = viewModel::sendCallText
                        )
                    }

                    // Toast banner matching web UI
                    uiState.toastMessage?.let { msg ->
                        Row(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(16.dp)
                                .widthIn(max = 320.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(NexcodeColors.SurfaceDark)
                                .border(1.dp, Color(0xFF3F3F46), RoundedCornerShape(10.dp))
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = msg,
                                color = NexcodeColors.TextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.weight(1f, fill = false)
                            )
                            Icon(
                                imageVector = Icons.Outlined.Close,
                                contentDescription = "Dismiss notification",
                                tint = NexcodeColors.TextMuted,
                                modifier = Modifier
                                    .size(15.dp)
                                    .clickable { viewModel.dismissToast() }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshCapabilitiesAndPermissions()
    }

    private fun ensureMicPermission(onGranted: () -> Unit) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            onGranted()
        } else {
            pendingMicAction = onGranted
            val toRequest = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
                PackageManager.PERMISSION_GRANTED
            ) {
                toRequest.add(Manifest.permission.POST_NOTIFICATIONS)
            }
            permissionsLauncher.launch(toRequest.toTypedArray())
        }
    }

    private fun ensureCameraPermission(onGranted: () -> Unit) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            onGranted()
        } else {
            pendingCameraAction = onGranted
            permissionsLauncher.launch(arrayOf(Manifest.permission.CAMERA))
        }
    }

    private fun handleOnboardingContinue() {
        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            needed.add(Manifest.permission.RECORD_AUDIO)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            needed.add(Manifest.permission.CAMERA)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        if (needed.isEmpty()) {
            viewModel.completeOnboarding()
        } else {
            pendingOnboardingContinue = true
            permissionsLauncher.launch(needed.toTypedArray())
        }
    }

    private fun launchSystemScreenCaptureDialog() {
        if (isRequestingProjection) return
        isRequestingProjection = true

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            permissionsLauncher.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
        }

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        ScreenShareState.publishState(
            NativeShareStatus.REQUESTING,
            "Waiting for Android screen capture approval"
        )
        runCatching {
            mediaProjectionLauncher.launch(mpm.createScreenCaptureIntent())
        }.onFailure { err ->
            isRequestingProjection = false
            ScreenShareState.publishError(
                "Could not open Android screen-sharing dialog: ${err.message ?: "unknown error"}"
            )
        }
    }

    private fun requestOverlayPermissionScreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlayPermissionLauncher.launch(intent)
        } else {
            viewModel.showToast("Floating Indicator already active while screen sharing.")
        }
    }
}

@Composable
private fun NexcodeMainScaffold(
    uiState: com.nexcode.ai.ui.NexcodeUiState,
    onSelectTab: (WorkspaceTab) -> Unit,
    onNewChat: () -> Unit,
    onSelectSession: (com.nexcode.ai.model.HistorySession) -> Unit,
    onRenameSession: (String, String) -> Unit,
    onDeleteSession: (String) -> Unit,
    onClearAllHistory: () -> Unit,
    onChatInputChanged: (String) -> Unit,
    onAttachChatFile: () -> Unit,
    onClearAttachment: () -> Unit,
    onSendChat: () -> Unit,
    onStopChat: () -> Unit,
    onRegenerateLast: () -> Unit,
    onCopyCode: (String, String) -> Unit,
    onStartCall: () -> Unit,
    onEndCall: () -> Unit,
    onToggleMute: () -> Unit,
    onChangeCallLanguage: (String) -> Unit,
    onToggleScreenShare: () -> Unit,
    onTogglePauseScreenShare: () -> Unit,
    onRequestOverlayIndicator: () -> Unit,
    onDismissScreenShareError: () -> Unit,
    onToggleCamera: () -> Unit,
    onSwitchCameraLens: () -> Unit,
    onAttachCallMedia: () -> Unit,
    onSendCallText: (String) -> Unit
) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            HistoryDrawerContent(
                activeSessionId = uiState.sessionId,
                sessions = uiState.sessions,
                onClose = { scope.launch { drawerState.close() } },
                onNewChat = onNewChat,
                onSelectSession = onSelectSession,
                onRenameSession = onRenameSession,
                onDeleteSession = onDeleteSession,
                onClearAll = onClearAllHistory
            )
        }
    ) {
        Scaffold(
            containerColor = NexcodeColors.Black,
            topBar = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(NexcodeColors.Black)
                        .statusBarsPadding()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .padding(horizontal = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            IconButton(
                                onClick = { scope.launch { drawerState.open() } },
                                modifier = Modifier.size(38.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.Menu,
                                    contentDescription = "Open History",
                                    tint = Color(0xFFD4D4D8)
                                )
                            }

                            Row(
                                modifier = Modifier.clickable { onSelectTab(WorkspaceTab.CHAT) },
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                NexcodeLogo(size = 26.dp)
                                Text(
                                    text = "NEXCODE AI",
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TopNavPill(
                                icon = Icons.Outlined.ChatBubbleOutline,
                                label = "Chat",
                                selected = uiState.activeTab == WorkspaceTab.CHAT,
                                onClick = { onSelectTab(WorkspaceTab.CHAT) }
                            )
                            TopNavPill(
                                icon = Icons.Outlined.Phone,
                                label = "Call",
                                selected = uiState.activeTab == WorkspaceTab.CALL,
                                onClick = { onSelectTab(WorkspaceTab.CALL) }
                            )
                        }
                    }
                    HorizontalDivider(color = NexcodeColors.BorderSubtle)
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (uiState.activeTab) {
                    WorkspaceTab.CHAT -> ChatScreen(
                        messages = uiState.messages,
                        chatInput = uiState.chatInput,
                        chatLoading = uiState.chatLoading,
                        pendingAttachment = uiState.pendingAttachment,
                        onChatInputChanged = onChatInputChanged,
                        onAttachClick = onAttachChatFile,
                        onClearAttachment = onClearAttachment,
                        onSendMessage = onSendChat,
                        onStopGeneration = onStopChat,
                        onRegenerateLast = onRegenerateLast,
                        onCopyCode = onCopyCode
                    )

                    WorkspaceTab.CALL -> VoiceCallScreen(
                        callActive = uiState.callActive,
                        callConnecting = uiState.callConnecting,
                        reconnectAttempt = uiState.reconnectAttempt,
                        muted = uiState.muted,
                        micLevel = uiState.micLevel,
                        durationSeconds = uiState.callDurationSeconds,
                        assistantSpeaking = uiState.assistantSpeaking,
                        callLanguage = uiState.callLanguage,
                        visualMode = uiState.visualMode,
                        screenShareSource = uiState.screenShareSource,
                        screenShareStatus = uiState.screenShareStatus,
                        screenShareError = uiState.screenShareError,
                        visionFrameCount = uiState.visionFrameCount,
                        lastVisionTimestamp = uiState.lastVisionTimestamp,
                        nativeOverlayGranted = uiState.nativeOverlayGranted,
                        previewBitmap = uiState.previewBitmap,
                        callTranscript = uiState.callTranscript,
                        onStartCall = onStartCall,
                        onEndCall = onEndCall,
                        onToggleMute = onToggleMute,
                        onChangeCallLanguage = onChangeCallLanguage,
                        onToggleScreenShare = onToggleScreenShare,
                        onTogglePauseScreenShare = onTogglePauseScreenShare,
                        onRequestOverlayIndicator = onRequestOverlayIndicator,
                        onDismissScreenShareError = onDismissScreenShareError,
                        onToggleCamera = onToggleCamera,
                        onSwitchCameraLens = onSwitchCameraLens,
                        onAttachCallMedia = onAttachCallMedia,
                        onSendCallText = onSendCallText
                    )
                }
            }
        }
    }
}

@Composable
private fun TopNavPill(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .height(38.dp)
            .clip(RoundedCornerShape(8.dp))
            .then(
                if (selected) {
                    Modifier.background(NexcodeColors.BlueCyanGradient)
                } else {
                    Modifier
                        .background(NexcodeColors.CardBg)
                        .border(1.dp, NexcodeColors.Border, RoundedCornerShape(8.dp))
                }
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (selected) Color.White else Color(0xFFD4D4D8),
            modifier = Modifier.size(15.dp)
        )
        Text(
            text = label,
            color = if (selected) Color.White else Color(0xFFD4D4D8),
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
