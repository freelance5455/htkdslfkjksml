package com.nexcode.ai.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CameraAlt
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.ContentPaste
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexcode.ai.model.ONBOARDING_LANGUAGES
import com.nexcode.ai.model.PermissionStateLabel
import com.nexcode.ai.model.PermissionStatusMap
import com.nexcode.ai.ui.theme.NexcodeColors

@Composable
fun OnboardingSetupScreen(
    language: String,
    permissions: PermissionStatusMap,
    onChangeLanguage: (String) -> Unit,
    onRequestMicrophone: () -> Unit,
    onRequestClipboard: () -> Unit,
    onRequestScreenOrCamera: () -> Unit,
    onContinueToChat: () -> Unit
) {
    var langExpanded by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NexcodeColors.Black)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 440.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(NexcodeColors.CardBg)
                .border(1.dp, NexcodeColors.Border, RoundedCornerShape(16.dp))
                .padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                NexcodeLogo(size = 42.dp)
                Column {
                    Text(
                        text = "NEXCODE AI",
                        style = TextStyle(
                            brush = NexcodeColors.TitleGradient,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = "Allow permissions below to open Chat & Voice Call.",
                        color = NexcodeColors.TextMuted,
                        fontSize = 12.sp
                    )
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Permissions",
                    color = Color(0xFFD4D4D8),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )

                PermissionCardRow(
                    icon = Icons.Outlined.Mic,
                    title = "Microphone",
                    subtitle = "For voice calls",
                    granted = permissions.microphone == PermissionStateLabel.GRANTED,
                    onAllow = onRequestMicrophone
                )

                PermissionCardRow(
                    icon = Icons.Outlined.CameraAlt,
                    title = "Cam & Screen Sharing",
                    subtitle = "For live camera & screen vision in calls",
                    granted = permissions.screenShare == PermissionStateLabel.GRANTED ||
                        permissions.screenShare == PermissionStateLabel.ACTIVE,
                    onAllow = onRequestScreenOrCamera
                )

                PermissionCardRow(
                    icon = Icons.Outlined.ContentPaste,
                    title = "Clipboard",
                    subtitle = "Copy generated code snippets",
                    granted = permissions.clipboard == PermissionStateLabel.GRANTED,
                    onAllow = onRequestClipboard
                )
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Language,
                        contentDescription = null,
                        tint = NexcodeColors.CyanLight,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "Chat Language",
                        color = Color(0xFFD4D4D8),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Box {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(NexcodeColors.Black)
                            .border(1.dp, NexcodeColors.Border, RoundedCornerShape(10.dp))
                            .clickable { langExpanded = true }
                            .padding(horizontal = 12.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = language,
                            color = NexcodeColors.TextPrimary,
                            fontSize = 14.sp
                        )
                        Icon(
                            imageVector = Icons.Outlined.KeyboardArrowDown,
                            contentDescription = "Select language",
                            tint = NexcodeColors.TextMuted,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = langExpanded,
                        onDismissRequest = { langExpanded = false },
                        modifier = Modifier.background(NexcodeColors.CardBg)
                    ) {
                        ONBOARDING_LANGUAGES.forEach { lang ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = lang,
                                        color = NexcodeColors.TextPrimary,
                                        fontSize = 14.sp
                                    )
                                },
                                onClick = {
                                    onChangeLanguage(lang)
                                    langExpanded = false
                                }
                            )
                        }
                    }
                }
            }

            Button(
                onClick = onContinueToChat,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(NexcodeColors.BrandGradient),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.Transparent,
                    contentColor = Color.White
                ),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text(
                    text = "Continue to Chat",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
private fun PermissionCardRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    granted: Boolean,
    onAllow: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(NexcodeColors.Black)
            .border(1.dp, NexcodeColors.Border, RoundedCornerShape(12.dp))
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color(0xFFD4D4D8),
                modifier = Modifier.size(18.dp)
            )
            Column {
                Text(
                    text = title,
                    color = NexcodeColors.TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = subtitle,
                    color = NexcodeColors.TextDim,
                    fontSize = 11.sp
                )
            }
        }

        Spacer(modifier = Modifier.size(8.dp))

        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(NexcodeColors.SurfaceDark)
                .border(1.dp, Color(0xFF3F3F46), RoundedCornerShape(8.dp))
                .clickable(onClick = onAllow)
                .padding(horizontal = 12.dp, vertical = 7.dp)
        ) {
            if (granted) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.CheckCircle,
                        contentDescription = null,
                        tint = NexcodeColors.Emerald,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "Allowed",
                        color = NexcodeColors.Emerald,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            } else {
                Text(
                    text = "Allow",
                    color = NexcodeColors.TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
