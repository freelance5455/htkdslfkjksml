package com.nexcode.ai.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import com.nexcode.ai.model.AttachmentKind
import com.nexcode.ai.model.MediaAttachment
import java.io.ByteArrayOutputStream
import kotlin.math.max
import kotlin.math.min

object MediaAttachmentHelper {

    private val CODE_EXTENSIONS = setOf(
        "html", "htm", "css", "js", "jsx", "ts", "tsx", "py", "java", "kt", "kts",
        "c", "h", "cpp", "hpp", "cs", "php", "sql", "dart", "xml", "json", "lua",
        "swift", "md", "txt", "gradle", "yaml", "yml", "sh"
    )

    private const val MAX_VIDEO_BYTES = 20L * 1024L * 1024L
    private const val MAX_IMAGE_DIMENSION = 1280

    fun prepareFromUri(context: Context, uri: Uri): MediaAttachment {
        val cr = context.contentResolver
        val fileName = resolveFileName(context, uri)
        val ext = fileName.substringAfterLast('.', "").lowercase()
        val mimeType = cr.getType(uri) ?: inferMimeType(ext)

        if (mimeType.startsWith("image/")) {
            val bytes = cr.openInputStream(uri)?.use { it.readBytes() }
                ?: error("Could not read selected image.")
            val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                ?: error("Unsupported or corrupted image file.")

            val maxSide = max(decoded.width, decoded.height).coerceAtLeast(1)
            val scale = min(1f, MAX_IMAGE_DIMENSION.toFloat() / maxSide.toFloat())
            val resized = if (scale < 1f) {
                Bitmap.createScaledBitmap(
                    decoded,
                    (decoded.width * scale).toInt().coerceAtLeast(1),
                    (decoded.height * scale).toInt().coerceAtLeast(1),
                    true
                ).also {
                    if (it !== decoded) decoded.recycle()
                }
            } else {
                decoded
            }

            val out = ByteArrayOutputStream()
            resized.compress(Bitmap.CompressFormat.JPEG, 82, out)
            val base64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)

            return MediaAttachment(
                name = fileName,
                mimeType = "image/jpeg",
                data = base64,
                kind = AttachmentKind.IMAGE,
                previewBitmap = resized
            )
        }

        if (mimeType.startsWith("video/")) {
            val bytes = cr.openInputStream(uri)?.use { it.readBytes() }
                ?: error("Could not read selected video.")
            if (bytes.size > MAX_VIDEO_BYTES) {
                error("Video is too large. Please keep videos under 20 MB.")
            }
            val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
            return MediaAttachment(
                name = fileName,
                mimeType = mimeType,
                data = base64,
                kind = AttachmentKind.VIDEO,
                previewBitmap = null
            )
        }

        if (ext in CODE_EXTENSIONS || mimeType.startsWith("text/") || mimeType == "application/json") {
            val text = cr.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                ?: error("Could not read source file.")
            return MediaAttachment(
                name = fileName,
                mimeType = if (mimeType.isBlank()) "text/plain" else mimeType,
                data = text.take(48000),
                kind = AttachmentKind.CODE,
                previewBitmap = null
            )
        }

        error("Unsupported file format: $fileName")
    }

    private fun resolveFileName(context: Context, uri: Uri): String {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) {
                        val name = cursor.getString(idx)
                        if (!name.isNullOrBlank()) return name
                    }
                }
            }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "attachment"
    }

    private fun inferMimeType(ext: String): String = when (ext) {
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "webp" -> "image/webp"
        "mp4" -> "video/mp4"
        "webm" -> "video/webm"
        "json" -> "application/json"
        else -> "text/plain"
    }
}
