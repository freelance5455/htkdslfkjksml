package com.nexcode.ai.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.outlined.AttachFile
import androidx.compose.material.icons.outlined.CallEnd
import androidx.compose.material.icons.outlined.CameraAlt
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.MicOff
import androidx.compose.material.icons.outlined.Pause
import androidx.compose.material.icons.outlined.Phone
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.ScreenShare
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexcode.ai.model.CALL_LANGUAGES
import com.nexcode.ai.model.ChatMessage
import com.nexcode.ai.model.ScreenShareSource
import com.nexcode.ai.model.ScreenShareStatus
import com.nexcode.ai.model.VisualMode
import com.nexcode.ai.ui.theme.NexcodeColors
import java.text.DateFormat
import java.util.Date

private fun formatDuration(sec: Int): String {
    val m = (sec / 60).toString().padStart(2, '0')
    val s = (sec % 60).toString().padStart(2, '0')
    return "$m:$s"
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VoiceCallScreen(
    callActive: Boolean,
    callConnecting: Boolean,
    reconnectAttempt: Int,
    muted: Boolean,
    micLevel: Float,
    durationSeconds: Int,
    assistantSpeaking: Boolean,
    callLanguage: String,
    visualMode: VisualMode,
    screenShareSource: ScreenShareSource,
    screenShareStatus: ScreenShareStatus,
    screenShareError: String?,
    visionFrameCount: Int,
    lastVisionTimestamp: Long?,
    nativeOverlayGranted: Boolean,
    previewBitmap: Bitmap?,
    callTranscript: List<ChatMessage>,
    onStartCall: () -> Unit,
    onEndCall: () -> Unit,
    onToggleMute: () -> Unit,
    onChangeCallLanguage: (String) -> Unit,
    onToggleScreenShare: () -> Unit,
    onTogglePauseScreenShare: () -> Unit,
    onRequestOverlayIndicator: () -> Unit,
    onDismissScreenShareError: () -> Unit,
    onToggleCamera: () -> Unit,
    onSwitchCameraLens: () -> Unit,
    onAttachCallMedia: () -> Unit,
    onSendCallText: (String) -> Unit
) {
    var chatDrawerOpen by remember { mutableStateOf(false) }
    var privacyOpen by remember { mutableStateOf(false) }
    var langExpanded by remember { mutableStateOf(false) }
    var draft by remember { mutableStateOf("") }

    if (!callActive && !callConnecting) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(NexcodeColors.Black)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(NexcodeColors.CardBg)
                    .border(1.dp, NexcodeColors.Border, RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Outlined.Phone,
                    contentDescription = null,
                    tint = NexcodeColors.CyanLight,
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "Voice Call & Live Vision",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Starts in English and switches to Urdu, Hindi, Arabic, or any language on request. Share your full Android screen or use live Cam vision during the call.",
                color = NexcodeColors.TextMuted,
                fontSize = 13.5.sp,
                lineHeight = 20.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.widthIn(max = 360.dp)
            )

            Spacer(modifier = Modifier.height(22.dp))

            Button(
                onClick = onStartCall,
                modifier = Modifier
                    .height(46.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(NexcodeColors.BrandGradient),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.Transparent,
                    contentColor = Color.White
                ),
                contentPadding = PaddingValues(horizontal = 26.dp, vertical = 0.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.Phone,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Start Call",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.Security,
                    contentDescription = null,
                    tint = NexcodeColors.CyanLight,
                    modifier = Modifier.size(14.dp)
                )
                Text(
                    text = "Native Android MediaProjection & CameraX bridges active",
                    color = NexcodeColors.TextDim,
                    fontSize = 12.sp
                )
            }
        }
        return
    }

    val isVisualActive = visualMode != VisualMode.NONE
    val isScreenSharing = visualMode == VisualMode.SCREEN
    val isCameraActive = visualMode == VisualMode.CAMERA
    val isPaused = screenShareStatus == ScreenShareStatus.PAUSED

    val connectionLabel = when {
        callConnecting && reconnectAttempt > 0 -> "Reconnecting ($reconnectAttempt/3)"
        callConnecting -> "Connecting"
        callActive -> "Connected"
        else -> "Disconnected"
    }

    val sharingLabel = when {
        isCameraActive -> if (screenShareSource == ScreenShareSource.ANDROID_CAMERAX) "CameraX Live" else "Cam Active"
        isScreenSharing -> if (isPaused) "Sharing Paused" else "Sharing Live"
        screenShareStatus == ScreenShareStatus.REQUESTING -> "Requesting Permission"
        else -> "Screen Idle"
    }

    val visionLabel = when {
        isScreenSharing && isPaused -> "AI Vision Paused"
        isVisualActive && visionFrameCount > 0 -> "AI Vision Active ($visionFrameCount)"
        isVisualActive -> "AI Vision Active"
        else -> "AI Vision Standby"
    }

    val languageOptions = remember(callLanguage) {
        if (CALL_LANGUAGES.contains(callLanguage)) CALL_LANGUAGES
        else listOf(callLanguage) + CALL_LANGUAGES
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NexcodeColors.Black)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top Status Section (Clean Icon Badge — No Orb)
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            val badgeBorder = when {
                callConnecting -> Color(0x80D97706)
                assistantSpeaking -> Color(0xB306B6D4)
                muted -> NexcodeColors.Border
                else -> Color(0x80059669)
            }
            val badgeBg = when {
                callConnecting -> Color(0x4D451A03)
                assistantSpeaking -> Color(0x66083344)
                muted -> NexcodeColors.CardBg
                else -> Color(0x4D022C22)
            }
            val badgeTint = when {
                callConnecting -> NexcodeColors.Amber
                assistantSpeaking -> NexcodeColors.CyanLight
                muted -> NexcodeColors.TextDim
                else -> NexcodeColors.Emerald
            }

            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(badgeBg)
                    .border(1.dp, badgeBorder, RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when {
                        assistantSpeaking -> Icons.Outlined.VolumeUp
                        muted -> Icons.Outlined.MicOff
                        else -> Icons.Outlined.Mic
                    },
                    contentDescription = null,
                    tint = badgeTint,
                    modifier = Modifier.size(24.dp)
                )
            }

            Text(
                text = when {
                    callConnecting && reconnectAttempt > 0 -> "Reconnecting ($reconnectAttempt/3)..."
                    callConnecting -> "Connecting..."
                    assistantSpeaking -> "Speaking..."
                    muted -> "Muted"
                    else -> "Listening..."
                },
                color = Color(0xFFE4E4E7),
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )

            // Duration + Language selector
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = formatDuration(durationSeconds),
                    color = NexcodeColors.TextMuted,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(text = "|", color = Color(0xFF3F3F46), fontSize = 12.sp)

                Box {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(NexcodeColors.CardBg)
                            .border(1.dp, NexcodeColors.Border, RoundedCornerShape(8.dp))
                            .clickable { langExpanded = true }
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Language,
                            contentDescription = null,
                            tint = NexcodeColors.CyanLight,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = callLanguage,
                            color = NexcodeColors.TextPrimary,
                            fontSize = 12.sp
                        )
                        Icon(
                            imageVector = Icons.Outlined.KeyboardArrowDown,
                            contentDescription = null,
                            tint = NexcodeColors.TextMuted,
                            modifier = Modifier.size(14.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = langExpanded,
                        onDismissRequest = { langExpanded = false },
                        modifier = Modifier.background(NexcodeColors.CardBg)
                    ) {
                        languageOptions.forEach { lang ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = lang,
                                        color = NexcodeColors.TextPrimary,
                                        fontSize = 13.sp
                                    )
                                },
                                onClick = {
                                    onChangeCallLanguage(lang)
                                    langExpanded = false
                                }
                            )
                        }
                    }
                }
            }

            // Connection | Sharing | Vision Status Strip
            FlowRow(
                horizontalArrangement = Arrangement.Center,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = connectionLabel,
                    color = if (callActive) NexcodeColors.Emerald else NexcodeColors.Amber,
                    fontSize = 12.sp
                )
                Text(
                    text = "  |  ",
                    color = Color(0xFF3F3F46),
                    fontSize = 12.sp
                )
                Text(
                    text = sharingLabel,
                    color = when {
                        (isScreenSharing || isCameraActive) && !isPaused -> NexcodeColors.CyanLight
                        isPaused -> NexcodeColors.Amber
                        else -> NexcodeColors.TextMuted
                    },
                    fontSize = 12.sp,
                    fontWeight = if (isScreenSharing || isCameraActive || isPaused) FontWeight.Medium else FontWeight.Normal
                )
                Text(
                    text = "  |  ",
                    color = Color(0xFF3F3F46),
                    fontSize = 12.sp
                )
                Text(
                    text = visionLabel,
                    color = if (isVisualActive && !isPaused) NexcodeColors.Emerald else NexcodeColors.TextMuted,
                    fontSize = 12.sp,
                    fontWeight = if (isVisualActive && !isPaused) FontWeight.Medium else FontWeight.Normal
                )
            }

            if (isVisualActive && lastVisionTimestamp != null) {
                val timeStr = remember(lastVisionTimestamp) {
                    DateFormat.getTimeInstance(DateFormat.MEDIUM).format(Date(lastVisionTimestamp))
                }
                Text(
                    text = "Latest frame synced $timeStr",
                    color = NexcodeColors.TextDim,
                    fontSize = 11.sp
                )
            }

            // Mic level bar
            if (!callConnecting) {
                val fillFraction = if (muted) 0f else micLevel.coerceIn(0.06f, 1f)
                Box(
                    modifier = Modifier
                        .width(144.dp)
                        .height(6.dp)
                        .clip(RoundedCornerShape(50))
                        .background(NexcodeColors.SurfaceDark)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(fillFraction)
                            .height(6.dp)
                            .background(NexcodeColors.BrandGradient)
                    )
                }
            }
        }

        // Diagnostic Error Card
        if (screenShareError != null) {
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier
                    .widthIn(max = 420.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(NexcodeColors.RedBg)
                    .border(1.dp, NexcodeColors.RedBorder, RoundedCornerShape(12.dp))
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.ErrorOutline,
                        contentDescription = null,
                        tint = NexcodeColors.RedLight,
                        modifier = Modifier.size(16.dp)
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = screenShareError,
                            color = Color(0xFFFECACA),
                            fontSize = 12.sp,
                            lineHeight = 17.sp
                        )
                        Text(
                            text = "Retry Screen Sharing",
                            color = NexcodeColors.CyanLight,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            textDecoration = TextDecoration.Underline,
                            modifier = Modifier.clickable {
                                onDismissScreenShareError()
                                onToggleScreenShare()
                            }
                        )
                    }
                }
                Icon(
                    imageVector = Icons.Outlined.Close,
                    contentDescription = "Dismiss error",
                    tint = NexcodeColors.TextMuted,
                    modifier = Modifier
                        .size(16.dp)
                        .clickable(onClick = onDismissScreenShareError)
                )
            }
        }

        // Live Screen / CameraX Preview Card
        if (isVisualActive) {
            Spacer(modifier = Modifier.height(10.dp))
            Column(
                modifier = Modifier
                    .widthIn(max = 360.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(NexcodeColors.CardBg)
                    .border(1.dp, NexcodeColors.Border, RoundedCornerShape(12.dp))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(176.dp)
                        .background(NexcodeColors.Black),
                    contentAlignment = Alignment.Center
                ) {
                    if (previewBitmap != null) {
                        val imgBmp = remember(previewBitmap) { previewBitmap.asImageBitmap() }
                        Image(
                            bitmap = imgBmp,
                            contentDescription = if (isCameraActive) "Live CameraX preview" else "Live shared Android screen",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxSize()
                                .alpha(if (isPaused) 0.4f else 1f)
                        )
                    } else {
                        Text(
                            text = if (isCameraActive) "Starting CameraX..." else "Capturing screen...",
                            color = NexcodeColors.TextDim,
                            fontSize = 12.sp
                        )
                    }
                }

                HorizontalDivider(color = NexcodeColors.Border)

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(NexcodeColors.SurfaceDark)
                        .padding(horizontal = 12.dp, vertical = 9.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = when {
                            isCameraActive -> "Fast CameraX Vision"
                            isPaused -> "Sharing Paused"
                            else -> "Sharing Entire Android Screen"
                        },
                        color = Color(0xFFD4D4D8),
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isCameraActive) {
                            Row(
                                modifier = Modifier.clickable(onClick = onSwitchCameraLens),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.Refresh,
                                    contentDescription = null,
                                    tint = NexcodeColors.CyanLight,
                                    modifier = Modifier.size(13.dp)
                                )
                                Text(
                                    text = "Flip Lens",
                                    color = NexcodeColors.CyanLight,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        if (isScreenSharing) {
                            Text(
                                text = if (isPaused) "Resume" else "Pause",
                                color = NexcodeColors.BlueLight,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.clickable(onClick = onTogglePauseScreenShare)
                            )
                        }

                        Text(
                            text = if (isCameraActive) "Stop Cam" else "Stop Sharing",
                            color = NexcodeColors.RedLight,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.clickable(
                                onClick = if (isCameraActive) onToggleCamera else onToggleScreenShare
                            )
                        )
                    }
                }
            }
        }

        // Slide-in Call Chat Drawer
        if (chatDrawerOpen) {
            Spacer(modifier = Modifier.height(10.dp))
            Column(
                modifier = Modifier
                    .widthIn(max = 420.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(NexcodeColors.CardBg)
                    .border(1.dp, NexcodeColors.Border, RoundedCornerShape(12.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(NexcodeColors.Black)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Call Chat",
                        color = Color(0xFFD4D4D8),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Icon(
                        imageVector = Icons.Outlined.Close,
                        contentDescription = "Close call chat",
                        tint = NexcodeColors.TextMuted,
                        modifier = Modifier
                            .size(15.dp)
                            .clickable { chatDrawerOpen = false }
                    )
                }

                HorizontalDivider(color = NexcodeColors.Border)

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 76.dp, max = 160.dp)
                        .padding(10.dp)
                ) {
                    if (callTranscript.isEmpty()) {
                        Text(
                            text = "Ask \"What is showing on my screen?\" or \"What am I showing you?\"",
                            color = NexcodeColors.TextDim,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.Center)
                        )
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(callTranscript, key = { it.id }) { m ->
                                val isUser = m.role == "user"
                                Box(
                                    modifier = Modifier.fillMaxWidth(),
                                    contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .widthIn(max = 300.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .then(
                                                if (isUser) Modifier.background(NexcodeColors.Blue)
                                                else Modifier
                                                    .background(NexcodeColors.SurfaceDark)
                                                    .border(
                                                        1.dp,
                                                        NexcodeColors.Border,
                                                        RoundedCornerShape(8.dp)
                                                    )
                                            )
                                            .padding(horizontal = 10.dp, vertical = 7.dp)
                                    ) {
                                        Text(
                                            text = m.text,
                                            color = if (isUser) Color.White else NexcodeColors.TextPrimary,
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                HorizontalDivider(color = NexcodeColors.Border)

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    BasicTextField(
                        value = draft,
                        onValueChange = { draft = it },
                        singleLine = true,
                        textStyle = TextStyle(color = NexcodeColors.TextPrimary, fontSize = 12.sp),
                        cursorBrush = SolidColor(NexcodeColors.CyanLight),
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(NexcodeColors.Black)
                            .border(1.dp, NexcodeColors.Border, RoundedCornerShape(8.dp))
                            .padding(horizontal = 10.dp, vertical = 9.dp),
                        decorationBox = { inner ->
                            if (draft.isEmpty()) {
                                Text(
                                    text = "Ask about your screen/camera or switch language...",
                                    color = NexcodeColors.TextDim,
                                    fontSize = 11.5.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            inner()
                        }
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(NexcodeColors.Blue)
                            .clickable {
                                val trimmed = draft.trim()
                                if (trimmed.isNotEmpty()) {
                                    onSendCallText(trimmed)
                                    draft = ""
                                }
                            }
                            .padding(9.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Outlined.Send,
                            contentDescription = "Send call message",
                            tint = Color.White,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }
            }
        }

        // Privacy Notice Panel
        if (privacyOpen) {
            Spacer(modifier = Modifier.height(10.dp))
            Column(
                modifier = Modifier
                    .widthIn(max = 420.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(NexcodeColors.CardBg)
                    .border(1.dp, NexcodeColors.Border, RoundedCornerShape(12.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Security,
                            contentDescription = null,
                            tint = NexcodeColors.Emerald,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "Vision & Call Privacy",
                            color = NexcodeColors.TextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                    Icon(
                        imageVector = Icons.Outlined.Close,
                        contentDescription = "Close privacy info",
                        tint = NexcodeColors.TextMuted,
                        modifier = Modifier
                            .size(14.dp)
                            .clickable { privacyOpen = false }
                    )
                }
                Text(
                    text = "Android requests explicit permission before screen or camera capture starts, keeps a visible notification running while active, respects protected windows (FLAG_SECURE), and stops immediately when you press Stop.",
                    color = NexcodeColors.TextMuted,
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Direct Call Controls (Row 1 + Row 2)
        Column(
            modifier = Modifier
                .widthIn(max = 440.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Screen Sharing / Stop Sharing
                Box(
                    modifier = Modifier
                        .height(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .then(
                            if (isScreenSharing) {
                                Modifier
                                    .background(NexcodeColors.RedBg)
                                    .border(1.dp, Color(0xB3DC2626), RoundedCornerShape(12.dp))
                            } else {
                                Modifier
                                    .background(NexcodeColors.BlueCyanGradient)
                                    .border(1.dp, Color(0xB33B82F6), RoundedCornerShape(12.dp))
                            }
                        )
                        .clickable(onClick = onToggleScreenShare)
                        .padding(horizontal = 14.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.ScreenShare,
                            contentDescription = null,
                            tint = if (isScreenSharing) Color(0xFFFECACA) else Color.White,
                            modifier = Modifier.size(15.dp)
                        )
                        Text(
                            text = if (isScreenSharing) "Stop Sharing" else "Screen Sharing",
                            color = if (isScreenSharing) Color(0xFFFECACA) else Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                // Pause / Resume (when Screen Sharing active)
                if (isScreenSharing) {
                    SecondaryActionChip(
                        icon = if (isPaused) Icons.Outlined.PlayArrow else Icons.Outlined.Pause,
                        label = if (isPaused) "Resume" else "Pause",
                        active = isPaused,
                        activeBg = Color(0x99172554),
                        activeBorder = Color(0xFF3B82F6),
                        activeTint = Color(0xFFBFDBFE),
                        onClick = onTogglePauseScreenShare
                    )
                }

                // Floating Indicator
                SecondaryActionChip(
                    icon = Icons.Outlined.Layers,
                    label = if (nativeOverlayGranted) "Floating Indicator On" else "Floating Indicator",
                    active = nativeOverlayGranted,
                    activeBg = NexcodeColors.EmeraldBg,
                    activeBorder = NexcodeColors.EmeraldBorder,
                    activeTint = NexcodeColors.Emerald,
                    onClick = onRequestOverlayIndicator
                )

                // Cam / Stop Cam
                SecondaryActionChip(
                    icon = Icons.Outlined.CameraAlt,
                    label = if (isCameraActive) "Stop Cam" else "Cam",
                    active = isCameraActive,
                    activeBg = Color(0x80083344),
                    activeBorder = NexcodeColors.CyanLight,
                    activeTint = Color(0xFFA5F3FC),
                    onClick = onToggleCamera
                )

                // Attach Pic / Video
                SecondaryActionChip(
                    icon = Icons.Outlined.AttachFile,
                    label = "Attach Pic / Video",
                    active = false,
                    onClick = onAttachCallMedia
                )
            }

            // Row 2: Mute | Chat | Privacy | End Call
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CallBottomTile(
                    icon = if (muted) Icons.Outlined.MicOff else Icons.Outlined.Mic,
                    label = if (muted) "Unmute" else "Mute",
                    bg = if (muted) NexcodeColors.AmberBg else NexcodeColors.CardBg,
                    border = if (muted) NexcodeColors.AmberBorder else NexcodeColors.Border,
                    tint = if (muted) Color(0xFFFCD34D) else NexcodeColors.TextPrimary,
                    onClick = onToggleMute
                )

                CallBottomTile(
                    icon = Icons.Outlined.ChatBubbleOutline,
                    label = "Chat",
                    bg = if (chatDrawerOpen) Color(0x99172554) else NexcodeColors.CardBg,
                    border = if (chatDrawerOpen) Color(0xFF3B82F6) else NexcodeColors.Border,
                    tint = if (chatDrawerOpen) Color(0xFF93C5FD) else NexcodeColors.TextPrimary,
                    onClick = { chatDrawerOpen = !chatDrawerOpen }
                )

                CallBottomTile(
                    icon = Icons.Outlined.Security,
                    label = "Privacy",
                    bg = if (privacyOpen) NexcodeColors.EmeraldBg else NexcodeColors.CardBg,
                    border = if (privacyOpen) NexcodeColors.EmeraldBorder else NexcodeColors.Border,
                    tint = if (privacyOpen) NexcodeColors.Emerald else NexcodeColors.TextPrimary,
                    onClick = { privacyOpen = !privacyOpen }
                )

                Box(
                    modifier = Modifier
                        .height(50.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(NexcodeColors.Red)
                        .clickable(onClick = onEndCall)
                        .padding(horizontal = 18.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.CallEnd,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "End Call",
                            color = Color.White,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SecondaryActionChip(
    icon: ImageVector,
    label: String,
    active: Boolean,
    activeBg: Color = NexcodeColors.SurfaceDark,
    activeBorder: Color = NexcodeColors.Border,
    activeTint: Color = NexcodeColors.TextPrimary,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .height(44.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (active) activeBg else NexcodeColors.CardBg)
            .border(1.dp, if (active) activeBorder else NexcodeColors.Border, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (active) activeTint else NexcodeColors.TextPrimary,
            modifier = Modifier.size(15.dp)
        )
        Text(
            text = label,
            color = if (active) activeTint else NexcodeColors.TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun CallBottomTile(
    icon: ImageVector,
    label: String,
    bg: Color,
    border: Color,
    tint: Color,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .height(50.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(bg)
            .border(1.dp, border, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = tint,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            color = tint,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
