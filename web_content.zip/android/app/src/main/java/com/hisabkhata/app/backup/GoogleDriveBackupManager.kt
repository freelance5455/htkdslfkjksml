package com.hisabkhata.app.backup

import android.content.Context
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.HttpURLConnection
import java.net.URL

/**
 * Handles Google Sign-In via Credential Manager API and Google Drive API v3 `appDataFolder`
 * using only the minimum required scope: https://www.googleapis.com/auth/drive.appdata
 */
class GoogleDriveBackupManager(private val context: Context) {

    companion object {
        const val DRIVE_APPDATA_SCOPE = "https://www.googleapis.com/auth/drive.appdata"
        const val BACKUP_FILE_NAME = "hisab_khata_backup_v2.enc.json"
    }

    private val credentialManager = CredentialManager.create(context)

    /**
     * Step 1: Authenticate the user with Google's modern Credential Manager API.
     * Returns the signed-in Google email address.
     */
    suspend fun signInWithGoogle(webClientId: String): String {
        val googleIdOption = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(false)
            .setServerClientId(webClientId)
            .setAutoSelectEnabled(false)
            .build()

        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleIdOption)
            .build()

        val result = credentialManager.getCredential(context, request)
        val credential = result.credential
        if (credential is CustomCredential &&
            credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
        ) {
            val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
            return googleIdTokenCredential.id // User's Google email
        }
        throw IllegalStateException("Unexpected credential type")
    }

    /**
     * Step 2: Request OAuth 2.0 access token strictly for `drive.appdata` via Google Identity Services.
     * No client secret or password is ever stored in the app.
     */
    suspend fun requestDriveAppDataAccessToken(): String {
        val authRequest = AuthorizationRequest.builder()
            .setRequestedScopes(listOf(Scope(DRIVE_APPDATA_SCOPE)))
            .build()

        val authResult = Identity.getAuthorizationClient(context)
            .authorize(authRequest)
            .await()

        check(!authResult.hasResolution()) {
            "User consent resolution required via PendingIntent"
        }

        return requireNotNull(authResult.accessToken) {
            "Failed to obtain Drive appDataFolder access token"
        }
    }

    suspend fun disconnectAccount() {
        credentialManager.clearCredentialState(ClearCredentialStateRequest())
    }

    /**
     * Uploads an AES-256-GCM encrypted backup into Google Drive `appDataFolder`.
     */
    suspend fun uploadEncryptedBackup(accessToken: String, encryptedEnvelopeJson: String): Int =
        withContext(Dispatchers.IO) {
            val boundary = "hisab_khata_boundary_${System.currentTimeMillis()}"
            val metadataJson = """
                {
                  "name": "$BACKUP_FILE_NAME",
                  "parents": ["appDataFolder"],
                  "mimeType": "application/json"
                }
            """.trimIndent()

            val body = buildString {
                append("--$boundary\r\n")
                append("Content-Type: application/json; charset=UTF-8\r\n\r\n")
                append(metadataJson).append("\r\n")
                append("--$boundary\r\n")
                append("Content-Type: application/json; charset=UTF-8\r\n\r\n")
                append(encryptedEnvelopeJson).append("\r\n")
                append("--$boundary--")
            }

            val url = URL("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,size,modifiedTime")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                setRequestProperty("Authorization", "Bearer $accessToken")
                setRequestProperty("Content-Type", "multipart/related; boundary=$boundary")
            }

            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            conn.responseCode
        }
}
