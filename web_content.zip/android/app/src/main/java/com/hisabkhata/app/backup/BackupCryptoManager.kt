package com.hisabkhata.app.backup

import android.util.Base64
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

@Serializable
data class EncryptedBackupEnvelope(
    val app: String = "HisabKhata",
    val backupFormatVersion: Int = 2,
    val encryptedAt: String,
    val algorithm: String = "AES-256-GCM",
    val kdf: String = "PBKDF2WithHmacSHA256",
    val iterations: Int = 150000,
    val saltBase64: String,
    val ivBase64: String,
    val ciphertextBase64: String,
    val plaintextSha256Hex: String
)

/**
 * Encrypts and decrypts backup payloads using AES-256-GCM and PBKDF2-HMAC-SHA256.
 * Never uploads plaintext financial data to Google Drive.
 */
object BackupCryptoManager {
    private const val PBKDF2_ITERATIONS = 150_000
    private const val KEY_LENGTH_BITS = 256
    private const val GCM_TAG_LENGTH_BITS = 128
    private const val SALT_BYTES = 16
    private const val IV_BYTES = 12

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    fun encryptJsonPayload(plaintextJson: String, passphrase: String, timestampIso: String): String {
        require(passphrase.trim().length >= 6) { "Passphrase must be at least 6 characters" }

        val plaintextBytes = plaintextJson.toByteArray(Charsets.UTF_8)
        val sha256Hex = sha256Hex(plaintextBytes)

        val random = SecureRandom()
        val salt = ByteArray(SALT_BYTES).also { random.nextBytes(it) }
        val iv = ByteArray(IV_BYTES).also { random.nextBytes(it) }

        val secretKey = deriveAesKey(passphrase, salt, PBKDF2_ITERATIONS)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv))
        val ciphertext = cipher.doFinal(plaintextBytes)

        val envelope = EncryptedBackupEnvelope(
            encryptedAt = timestampIso,
            iterations = PBKDF2_ITERATIONS,
            saltBase64 = Base64.encodeToString(salt, Base64.NO_WRAP),
            ivBase64 = Base64.encodeToString(iv, Base64.NO_WRAP),
            ciphertextBase64 = Base64.encodeToString(ciphertext, Base64.NO_WRAP),
            plaintextSha256Hex = sha256Hex
        )

        return json.encodeToString(envelope)
    }

    fun decryptAndVerifyPayload(envelopeJson: String, passphrase: String): String {
        val envelope = json.decodeFromString<EncryptedBackupEnvelope>(envelopeJson)
        require(envelope.app == "HisabKhata" && envelope.algorithm == "AES-256-GCM") {
            "Invalid or unsupported backup envelope"
        }

        val salt = Base64.decode(envelope.saltBase64, Base64.NO_WRAP)
        val iv = Base64.decode(envelope.ivBase64, Base64.NO_WRAP)
        val ciphertext = Base64.decode(envelope.ciphertextBase64, Base64.NO_WRAP)

        val secretKey = deriveAesKey(passphrase, salt, envelope.iterations)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, secretKey, GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv))

        val decryptedBytes = cipher.doFinal(ciphertext)
        val actualHash = sha256Hex(decryptedBytes)
        check(actualHash == envelope.plaintextSha256Hex) {
            "SHA-256 integrity check failed: backup is corrupted"
        }

        return String(decryptedBytes, Charsets.UTF_8)
    }

    private fun deriveAesKey(passphrase: String, salt: ByteArray, iterations: Int): SecretKeySpec {
        val spec = PBEKeySpec(passphrase.toCharArray(), salt, iterations, KEY_LENGTH_BITS)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val keyBytes = factory.generateSecret(spec).encoded
        spec.clearPassword()
        return SecretKeySpec(keyBytes, "AES")
    }

    private fun sha256Hex(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
        return digest.joinToString("") { "%02x".format(it) }
    }
}
