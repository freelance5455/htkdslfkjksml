package com.hisabkhata.app.backup

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/**
 * Background CoroutineWorker that performs daily automatic encrypted backups to Google Drive `appDataFolder`.
 * Automatically retries with exponential backoff when internet connectivity becomes available
 * without interrupting the user while recording transactions.
 */
class DriveBackupWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        return try {
            val driveManager = GoogleDriveBackupManager(applicationContext)
            val accessToken = driveManager.requestDriveAppDataAccessToken()

            // Retrieve serialized Room snapshot & encrypt with user's Keystore-wrapped passphrase
            val payloadJson = inputData.getString("SNAPSHOT_JSON") ?: return Result.success()
            val passphrase = inputData.getString("PASSPHRASE") ?: return Result.failure()

            val encryptedJson = BackupCryptoManager.encryptJsonPayload(
                plaintextJson = payloadJson,
                passphrase = passphrase,
                timestampIso = java.time.Instant.now().toString()
            )

            val status = driveManager.uploadEncryptedBackup(accessToken, encryptedJson)
            if (status in 200..299) {
                Result.success()
            } else if (status in 500..599 || status == 429) {
                Result.retry()
            } else {
                Result.failure()
            }
        } catch (e: Exception) {
            // Network error or transient failure -> retry automatically when internet returns
            Result.retry()
        }
    }

    companion object {
        private const val UNIQUE_WORK_NAME = "HisabKhataDailyDriveBackup"

        fun scheduleDailyAutoBackup(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .setRequiresBatteryNotLow(true)
                .build()

            val dailyRequest = PeriodicWorkRequestBuilder<DriveBackupWorker>(24, TimeUnit.HOURS)
                .setConstraints(constraints)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.MINUTES)
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                UNIQUE_WORK_NAME,
                ExistingPeriodicWorkPolicy.UPDATE,
                dailyRequest
            )
        }

        fun cancelDailyAutoBackup(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(UNIQUE_WORK_NAME)
        }
    }
}
