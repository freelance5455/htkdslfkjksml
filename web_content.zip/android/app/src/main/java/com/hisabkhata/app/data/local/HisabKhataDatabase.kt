package com.hisabkhata.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        AccountEntity::class,
        TransactionEntity::class,
        DebtEntity::class,
        RepaymentEntity::class,
        SubscriptionEntity::class,
        SubscriptionPaymentEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class HisabKhataDatabase : RoomDatabase() {
    abstract fun dao(): HisabKhataDao

    companion object {
        @Volatile
        private var INSTANCE: HisabKhataDatabase? = null

        fun getInstance(context: Context): HisabKhataDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    HisabKhataDatabase::class.java,
                    "hisab_khata_offline.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
