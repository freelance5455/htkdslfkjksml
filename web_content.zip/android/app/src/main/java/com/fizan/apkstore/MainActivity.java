package com.fizan.apkstore;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
  private WebView web;
  private ValueCallback<Uri[]> chooserCb;
  private static final int PICK = 77;

  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    web = new WebView(this);
    web.setBackgroundColor(Color.parseColor("#050405"));
    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true);
    web.addJavascriptInterface(new Bridge(), "FizanBridge");
    web.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView v, android.webkit.WebResourceRequest r) {
        Uri u = r.getUrl();
        if ("http".equals(u.getScheme()) || "https".equals(u.getScheme()) || "mailto".equals(u.getScheme())) {
          try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception e) {}
          return true;
        }
        return false;
      }
    });
    web.setWebChromeClient(new WebChromeClient() {
      @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
        if (chooserCb != null) chooserCb.onReceiveValue(null);
        chooserCb = cb;
        try { startActivityForResult(p.createIntent(), PICK); }
        catch (Exception e) { chooserCb = null; cb.onReceiveValue(null); return false; }
        return true;
      }
    });
    web.setOnApplyWindowInsetsListener((v, i) -> {
      v.setPadding(i.getSystemWindowInsetLeft(), i.getSystemWindowInsetTop(), i.getSystemWindowInsetRight(), i.getSystemWindowInsetBottom());
      return i;
    });
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }

  @Override protected void onActivityResult(int req, int res, Intent data) {
    if (req == PICK && chooserCb != null) {
      chooserCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
      chooserCb = null;
    } else super.onActivityResult(req, res, data);
  }

  @Override public void onBackPressed() {
    web.evaluateJavascript("(window.fzBack?window.fzBack():false)", v -> {
      if (!"true".equals(v)) finish();
    });
  }

  public class Bridge {
    @JavascriptInterface public String saveFile(String name, String mime, String b64) {
      try {
        byte[] data = Base64.decode(b64, Base64.DEFAULT);
        String where;
        if (Build.VERSION.SDK_INT >= 29) {
          ContentValues cv = new ContentValues();
          cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
          cv.put(MediaStore.Downloads.MIME_TYPE, mime);
          cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
          Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
          OutputStream os = getContentResolver().openOutputStream(uri);
          os.write(data); os.close();
          where = "Downloads/" + name;
        } else {
          File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
          File f = new File(dir, name);
          FileOutputStream os = new FileOutputStream(f);
          os.write(data); os.close();
          where = f.getAbsolutePath();
        }
        return "OK:" + where;
      } catch (Exception e) { return "ERR:" + e.getMessage(); }
    }
  }
}
