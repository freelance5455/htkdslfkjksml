package com.krissoundboard;

import android.content.Context;
import android.net.Uri;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public final class BoardWeb {
    public static final String HOST = "kris.soundboard.local";
    public static final String URL = "https://kris.soundboard.local/index.html";

    private BoardWeb() {}

    public static void configure(WebView web) {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        web.setBackgroundColor(0xFF090B12);
    }

    public static WebResourceResponse intercept(Context ctx, WebResourceRequest request) {
        if (request == null || request.getUrl() == null) return null;
        Uri uri = request.getUrl();
        if (!HOST.equalsIgnoreCase(uri.getHost())) return null;
        String path = uri.getPath();
        if (path == null || path.equals("/") || path.equals("/index.html")) path = "index.html";
        else if (path.startsWith("/")) path = path.substring(1);
        if (path.contains("..") || path.isEmpty()) return missing();
        try {
            InputStream in = ctx.getAssets().open(path);
            String mime = path.endsWith(".js") ? "text/javascript"
                    : path.endsWith(".css") ? "text/css"
                    : path.endsWith(".html") ? "text/html"
                    : "application/octet-stream";
            return new WebResourceResponse(mime, "UTF-8", 200, "OK", headers(), in);
        } catch (IOException e) {
            return missing();
        }
    }

    private static Map<String, String> headers() {
        Map<String, String> h = new HashMap<>();
        h.put("Cache-Control", "no-cache");
        return h;
    }

    private static WebResourceResponse missing() {
        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", headers(),
                new ByteArrayInputStream(new byte[0]));
    }
}
