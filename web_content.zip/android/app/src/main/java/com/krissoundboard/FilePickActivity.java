package com.krissoundboard;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.ValueCallback;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;

public class FilePickActivity extends Activity {
    public static ValueCallback<Uri[]> pending;
    private boolean delivered;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null) return;
        Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.setType("audio/*");
        pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        try {
            startActivityForResult(Intent.createChooser(pick, "Pilih audio"), 41);
        } catch (Exception e) {
            deliver(null);
            finish();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Uri[] result = null;
        if (requestCode == 41 && resultCode == RESULT_OK && data != null) {
            ArrayList<Uri> list = new ArrayList<>();
            if (data.getClipData() != null) {
                int n = data.getClipData().getItemCount();
                for (int i = 0; i < n; i++) {
                    Uri copied = copy(data.getClipData().getItemAt(i).getUri(), i);
                    if (copied != null) list.add(copied);
                }
            } else if (data.getData() != null) {
                Uri copied = copy(data.getData(), 0);
                if (copied != null) list.add(copied);
            }
            if (!list.isEmpty()) result = list.toArray(new Uri[0]);
        }
        deliver(result);
        finish();
    }

    private void deliver(Uri[] result) {
        if (delivered) return;
        delivered = true;
        if (pending != null) {
            pending.onReceiveValue(result);
            pending = null;
        }
    }

    private Uri copy(Uri src, int index) {
        if (src == null) return null;
        try (InputStream in = getContentResolver().openInputStream(src)) {
            if (in == null) return null;
            File out = new File(getCacheDir(), "pick-" + System.currentTimeMillis() + "-" + index + ".audio");
            try (FileOutputStream os = new FileOutputStream(out)) {
                byte[] buf = new byte[16384];
                int read;
                while ((read = in.read(buf)) != -1) os.write(buf, 0, read);
            }
            return Uri.fromFile(out);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    protected void onDestroy() {
        deliver(null);
        super.onDestroy();
    }
}
