package com.krissoundboard;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.Toast;

public class KrisChrome extends WebChromeClient {
    private final Context app;

    public KrisChrome(Context ctx) {
        this.app = ctx.getApplicationContext();
    }

    @Override
    public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
        if (FilePickActivity.pending != null) {
            FilePickActivity.pending.onReceiveValue(null);
            FilePickActivity.pending = null;
        }
        FilePickActivity.pending = callback;
        Intent i = new Intent(app, FilePickActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            app.startActivity(i);
        } catch (Exception e) {
            FilePickActivity.pending = null;
            callback.onReceiveValue(null);
            Toast.makeText(app, "Tidak bisa membuka pemilih file.", Toast.LENGTH_LONG).show();
        }
        return true;
    }

    @Override
    public void onPermissionRequest(PermissionRequest request) {
        if (app.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            request.grant(request.getResources());
        } else {
            request.deny();
        }
    }
}
