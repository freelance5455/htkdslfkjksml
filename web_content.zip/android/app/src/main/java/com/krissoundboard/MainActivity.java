package com.krissoundboard;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_PERMS = 77;
    private WebView webView;
    private TextView status;
    private boolean waitingOverlay;
    private boolean askedPerms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(9, 11, 18));

        TextView title = new TextView(this);
        title.setText("KRIS SOUNDBOARD");
        title.setTextColor(Color.WHITE);
        title.setTextSize(18);
        title.setPadding(dp(16), dp(14), dp(16), dp(4));
        root.addView(title);

        status = new TextView(this);
        status.setTextColor(Color.rgb(176, 188, 220));
        status.setTextSize(13);
        status.setPadding(dp(16), 0, dp(16), dp(8));
        root.addView(status);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(12), 0, dp(12), dp(10));
        row.setGravity(Gravity.CENTER_VERTICAL);

        Button bubble = new Button(this);
        stylePrimary(bubble);
        bubble.setText("Aktifkan bubble");
        bubble.setOnClickListener(v -> enableBubble());
        row.addView(bubble, new LinearLayout.LayoutParams(0, dp(48), 1));

        Button battery = new Button(this);
        styleGhost(battery);
        battery.setText("Baterai");
        battery.setOnClickListener(v -> askBattery());
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(48));
        bp.leftMargin = dp(8);
        row.addView(battery, bp);
        root.addView(row);

        webView = new WebView(this);
        BoardWeb.configure(webView);
        webView.setWebChromeClient(new KrisChrome(this));
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, android.webkit.WebResourceRequest request) {
                android.webkit.WebResourceResponse hit = BoardWeb.intercept(view.getContext(), request);
                return hit != null ? hit : super.shouldInterceptRequest(view, request);
            }
        });
        webView.addJavascriptInterface(new ActivityBridge(), "KrisAndroid");
        webView.loadUrl(BoardWeb.URL);
        root.addView(webView, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(root);
        updateStatus();
    }

    private void stylePrimary(Button b) {
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(15);
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.rgb(52, 123, 231), Color.rgb(124, 92, 255)});
        d.setCornerRadius(dp(14));
        b.setBackground(d);
    }

    private void styleGhost(Button b) {
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(15);
        GradientDrawable d = new GradientDrawable();
        d.setColor(Color.rgb(28, 34, 54));
        d.setCornerRadius(dp(14));
        d.setStroke(dp(1), Color.rgb(58, 70, 104));
        b.setBackground(d);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void updateStatus() {
        boolean overlay = Settings.canDrawOverlays(this);
        status.setText(overlay
                ? "Izin layar belakang sudah aktif. Tekan Aktifkan bubble, lalu buka game. Bubble KS tetap di atas."
                : "freewebtoapk tidak bisa menaruh bubble di atas aplikasi lain. Tekan tombol, lalu izinkan Tampil di atas aplikasi lain.");
    }

    private void enableBubble() {
        if (!askedPerms && Build.VERSION.SDK_INT >= 33) {
            boolean notif = checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
            boolean mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
            if (!notif || !mic) {
                askedPerms = true;
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.RECORD_AUDIO}, REQ_PERMS);
                return;
            }
        }
        if (!Settings.canDrawOverlays(this)) {
            waitingOverlay = true;
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            try {
                startActivity(intent);
                Toast.makeText(this, "Aktifkan izinkan tampil di atas aplikasi lain, lalu kembali.", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, "Buka Setelan > Aplikasi > Kris Soundboard > Tampil di atas aplikasi lain.", Toast.LENGTH_LONG).show();
            }
            return;
        }
        launchService();
    }

    private void launchService() {
        Intent service = new Intent(this, BubbleService.class);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service);
            else startService(service);
        } catch (Exception e) {
            Toast.makeText(this, "Gagal menyalakan bubble: " + e.getMessage(), Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this, "Bubble aktif. Ketuk lingkaran KS untuk membuka soundboard.", Toast.LENGTH_LONG).show();
        moveTaskToBack(true);
    }

    private void askBattery() {
        try {
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (Exception ignored) {
                Toast.makeText(this, "Buka setelan baterai dan jangan optimalkan Kris Soundboard.", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatus();
        if (waitingOverlay && Settings.canDrawOverlays(this)) {
            waitingOverlay = false;
            launchService();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_PERMS) enableBubble();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private final class ActivityBridge {
        @android.webkit.JavascriptInterface
        public boolean isNative() { return true; }

        @android.webkit.JavascriptInterface
        public void stopBubble() {
            runOnUiThread(() -> {
                stopService(new Intent(MainActivity.this, BubbleService.class));
                Toast.makeText(MainActivity.this, "Bubble dimatikan.", Toast.LENGTH_SHORT).show();
            });
        }
    }
}
