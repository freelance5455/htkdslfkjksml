package com.krissoundboard;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class BubbleService extends Service {
    public static final String ACTION_STOP = "com.krissoundboard.STOP";
    private static final String PREFS = "kris_bubble";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private View bubble;
    private View panel;
    private WebView board;
    private WindowManager.LayoutParams bubbleParams;
    private WindowManager.LayoutParams panelParams;
    private PowerManager.WakeLock wakeLock;
    private boolean panelOpen;

    @Override
    public void onCreate() {
        super.onCreate();
        startInForeground();
        keepAwake();
        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }
        showBubble();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            shutdown();
            return START_NOT_STICKY;
        }
        if (bubble == null && Settings.canDrawOverlays(this)) showBubble();
        return START_STICKY;
    }

    private void startInForeground() {
        String channelId = "kris_bubble";
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(channelId, "Bubble Kris Soundboard", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Bubble tetap tampil di atas aplikasi lain");
            nm.createNotificationChannel(channel);
        }
        Intent stop = new Intent(this, BubbleService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 2, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, channelId)
                : new Notification.Builder(this);
        builder.setContentTitle("Kris Soundboard")
                .setContentText("Bubble aktif di atas aplikasi lain")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true)
                .setContentIntent(openPi)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Matikan", stopPi);
        Notification notification = builder.build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(7, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(7, notification);
        }
    }

    private void keepAwake() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "kris:bubble");
            wakeLock.setReferenceCounted(false);
            wakeLock.acquire();
        } catch (Exception ignored) {}
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private int overlayType() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private void showBubble() {
        if (bubble != null) return;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        View view = new BubbleView(this);
        int size = dp(72);
        bubbleParams = new WindowManager.LayoutParams(
                size, size, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        int defX = getResources().getDisplayMetrics().widthPixels - dp(88);
        int defY = getResources().getDisplayMetrics().heightPixels / 3;
        bubbleParams.x = prefs.getInt("x", defX);
        bubbleParams.y = prefs.getInt("y", defY);
        view.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            boolean dragged;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX();
                        downY = e.getRawY();
                        startX = bubbleParams.x;
                        startY = bubbleParams.y;
                        dragged = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (e.getRawX() - downX);
                        int dy = (int) (e.getRawY() - downY);
                        if (Math.abs(dx) > 8 || Math.abs(dy) > 8) dragged = true;
                        bubbleParams.x = startX + dx;
                        bubbleParams.y = startY + dy;
                        try { wm.updateViewLayout(bubble, bubbleParams); } catch (Exception ignored) {}
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!dragged) togglePanel();
                        else getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                                .putInt("x", bubbleParams.x).putInt("y", bubbleParams.y).apply();
                        return true;
                    default:
                        return false;
                }
            }
        });
        try {
            wm.addView(view, bubbleParams);
            bubble = view;
        } catch (Exception e) {
            Toast.makeText(this, "Bubble gagal muncul. Izinkan Tampil di atas aplikasi lain, lalu aktifkan lagi.", Toast.LENGTH_LONG).show();
            stopSelf();
        }
    }

    private void togglePanel() {
        if (panelOpen) closePanel();
        else showPanel();
    }

    private void ensureBoard() {
        if (board != null) return;
        Context themed = new ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault);
        board = new WebView(themed);
        BoardWeb.configure(board);
        board.setWebChromeClient(new KrisChrome(this));
        board.setWebViewClient(new WebViewClient() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, android.webkit.WebResourceRequest request) {
                android.webkit.WebResourceResponse hit = BoardWeb.intercept(BubbleService.this, request);
                return hit != null ? hit : super.shouldInterceptRequest(view, request);
            }
        });
        board.addJavascriptInterface(new ServiceBridge(), "KrisAndroid");
        board.loadUrl(BoardWeb.URL);
    }

    private void showPanel() {
        if (wm == null) wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        ensureBoard();
        if (board.getParent() instanceof ViewGroup) {
            ((ViewGroup) board.getParent()).removeView(board);
        }
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(12, 14, 24));
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(1), Color.rgb(70, 86, 130));
        container.setBackground(bg);
        container.setClipToOutline(true);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(12), dp(8), dp(8), dp(8));
        top.setBackgroundColor(Color.rgb(22, 27, 46));

        TextView title = new TextView(this);
        title.setText("KRIS SOUNDBOARD");
        title.setTextColor(Color.WHITE);
        title.setTextSize(14);
        top.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        Button minimize = headerButton("—");
        Button close = headerButton("✕");
        top.addView(minimize);
        top.addView(close);
        container.addView(top, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        container.addView(board, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        int screenW = getResources().getDisplayMetrics().widthPixels;
        int screenH = getResources().getDisplayMetrics().heightPixels;
        panelParams = new WindowManager.LayoutParams(
                Math.min(screenW - dp(12), dp(520)),
                (int) (screenH * 0.78f),
                overlayType(),
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.CENTER;
        panelParams.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN;

        minimize.setOnClickListener(v -> closePanel());
        close.setOnClickListener(v -> closePanel());
        top.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (panelParams == null || panel == null) return false;
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX();
                        downY = e.getRawY();
                        startX = panelParams.x;
                        startY = panelParams.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        panelParams.x = startX + (int) (e.getRawX() - downX);
                        panelParams.y = startY + (int) (e.getRawY() - downY);
                        try { wm.updateViewLayout(panel, panelParams); } catch (Exception ignored) {}
                        return true;
                    default:
                        return false;
                }
            }
        });

        try {
            if (panel != null) wm.removeView(panel);
        } catch (Exception ignored) {}
        try {
            wm.addView(container, panelParams);
            panel = container;
            panelOpen = true;
            board.onResume();
            board.resumeTimers();
            raiseBubble();
        } catch (Exception e) {
            panel = null;
            panelOpen = false;
            Toast.makeText(this, "Panel gagal dibuka. Cek izin Tampil di atas aplikasi lain.", Toast.LENGTH_LONG).show();
        }
    }

    private Button headerButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(16);
        b.setMinWidth(0);
        b.setMinHeight(0);
        b.setMinimumWidth(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(14), dp(4), dp(14), dp(4));
        GradientDrawable d = new GradientDrawable();
        d.setColor(Color.rgb(40, 48, 78));
        d.setCornerRadius(dp(10));
        b.setBackground(d);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(40));
        lp.leftMargin = dp(6);
        b.setLayoutParams(lp);
        return b;
    }

    private void raiseBubble() {
        if (wm == null || bubble == null || bubbleParams == null) return;
        try {
            wm.removeView(bubble);
            wm.addView(bubble, bubbleParams);
        } catch (Exception ignored) {}
    }

    private void closePanel() {
        panelOpen = false;
        if (board != null) {
            try { board.onPause(); } catch (Exception ignored) {}
        }
        try {
            if (wm != null && panel != null) wm.removeView(panel);
        } catch (Exception ignored) {}
        if (board != null && board.getParent() instanceof ViewGroup) {
            ((ViewGroup) board.getParent()).removeView(board);
        }
        panel = null;
    }

    private void shutdown() {
        closePanel();
        try {
            if (wm != null && bubble != null) wm.removeView(bubble);
        } catch (Exception ignored) {}
        bubble = null;
        if (board != null) {
            board.destroy();
            board = null;
        }
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        closePanel();
        try {
            if (wm != null && bubble != null) wm.removeView(bubble);
        } catch (Exception ignored) {}
        bubble = null;
        if (board != null) {
            board.destroy();
            board = null;
        }
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    private final class ServiceBridge {
        @android.webkit.JavascriptInterface
        public boolean isNative() { return true; }

        @android.webkit.JavascriptInterface
        public void stopBubble() {
            handler.post(BubbleService.this::shutdown);
        }
    }

    private final class BubbleView extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);

        BubbleView(Context ctx) {
            super(ctx);
            fill.setColor(Color.rgb(61, 110, 235));
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(dp(3));
            ring.setColor(Color.rgb(176, 205, 255));
            text.setColor(Color.WHITE);
            text.setTextAlign(Paint.Align.CENTER);
            text.setFakeBoldText(true);
            text.setTextSize(dp(18));
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float cx = getWidth() / 2f;
            float cy = getHeight() / 2f;
            float r = Math.min(cx, cy) - dp(2);
            canvas.drawCircle(cx, cy, r, fill);
            canvas.drawCircle(cx, cy, r - dp(1), ring);
            float y = cy - (text.descent() + text.ascent()) / 2f;
            canvas.drawText("KS", cx, y, text);
        }
    }
}
