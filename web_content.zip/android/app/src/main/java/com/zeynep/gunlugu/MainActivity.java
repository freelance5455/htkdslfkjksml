package com.zeynep.gunlugu;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
