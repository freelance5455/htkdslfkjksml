package com.kingsaroj.routine;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
public class MainActivity extends Activity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WebView v = new WebView(this);
        v.getSettings().setJavaScriptEnabled(true);
        v.getSettings().setDomStorageEnabled(true);
        v.loadUrl("file:///android_asset/KingSaroj-Routine-Offline.html");
        setContentView(v);
    }
}