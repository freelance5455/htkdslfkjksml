package com.example.rewardedssvmessenger

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.MobileAds

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var adBridge: AdMobBridge

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        MobileAds.initialize(this) {}

        webView = findViewById(R.id.webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
        }

        webView.webViewClient = WebViewClient()

        adBridge = AdMobBridge(
            activity = this,
            webView = webView
        )

        webView.addJavascriptInterface(adBridge, "AndroidAPI")

        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onDestroy() {
        webView.removeJavascriptInterface("AndroidAPI")
        webView.destroy()
        super.onDestroy()
    }
}
