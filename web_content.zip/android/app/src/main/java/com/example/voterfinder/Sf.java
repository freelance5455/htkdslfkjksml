package com.example.voterfinder;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Salesforce sync: OAuth (PKCE), offline queue, upsert to Voter__c, pull of newer tags. */
class Sf {
    interface Js { void run(String script); }
    static final String API = "v60.0", REDIR = "com.example.voterfinder://oauth";
    final Activity act; final Js js; final SharedPreferences p;
    final ExecutorService ex = Executors.newSingleThreadExecutor();
    final File qf;

    Sf(Activity a, Js js) {
        act = a; this.js = js;
        p = a.getSharedPreferences("sf", Context.MODE_PRIVATE);
        qf = new File(a.getFilesDir(), "queue.json");
        if (get("dev").isEmpty()) p.edit().putString("dev", UUID.randomUUID().toString().substring(0, 8)).apply();
    }
    String get(String k) { return p.getString(k, ""); }
    void config(String d, String c) { p.edit().putString("d", d.trim().replaceAll("/+$", "")).putString("c", c.trim()).apply(); }
    static String b64(byte[] b) { return Base64.encodeToString(b, Base64.URL_SAFE | Base64.NO_PADDING | Base64.NO_WRAP); }
    static String enc(String s) throws Exception { return URLEncoder.encode(s, "UTF-8"); }
    static String iso(long t, boolean ms) {
        SimpleDateFormat f = new SimpleDateFormat(ms ? "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'" : "yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC")); return f.format(new Date(t));
    }
    void status(String s) { js.run("window.onSfStatus&&onSfStatus(" + JSONObject.quote(s) + ")"); }

    void login() throws Exception {
        byte[] r = new byte[32]; new SecureRandom().nextBytes(r);
        String v = b64(r), ch = b64(MessageDigest.getInstance("SHA-256").digest(v.getBytes(StandardCharsets.US_ASCII)));
        p.edit().putString("v", v).apply();
        Uri u = Uri.parse(get("d") + "/services/oauth2/authorize").buildUpon()
            .appendQueryParameter("response_type", "code").appendQueryParameter("client_id", get("c"))
            .appendQueryParameter("redirect_uri", REDIR).appendQueryParameter("code_challenge", ch)
            .appendQueryParameter("code_challenge_method", "S256").appendQueryParameter("scope", "api refresh_token").build();
        act.startActivity(new Intent(Intent.ACTION_VIEW, u));
    }

    void redirect(Uri u) {
        final String code = u.getQueryParameter("code");
        if (code == null) { status("Login failed: " + u.getQueryParameter("error_description")); return; }
        ex.submit(new Runnable() { public void run() { try {
            token("grant_type=authorization_code&code=" + enc(code) + "&client_id=" + enc(get("c"))
                + "&redirect_uri=" + enc(REDIR) + "&code_verifier=" + enc(get("v")));
            status("Connected to Salesforce"); cycle();
        } catch (Exception e) { status("Login failed: " + e.getMessage()); } } });
    }

    void token(String form) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(get("d") + "/services/oauth2/token").openConnection();
        c.setRequestMethod("POST"); c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        c.getOutputStream().write(form.getBytes(StandardCharsets.UTF_8));
        int code = c.getResponseCode(); String b = read(code >= 400 ? c.getErrorStream() : c.getInputStream());
        if (code >= 400) throw new Exception("token " + code + " " + b);
        JSONObject j = new JSONObject(b);
        SharedPreferences.Editor e = p.edit().putString("at", j.getString("access_token")).putString("i", j.getString("instance_url")).putString("uid", j.optString("id", "").replaceAll(".*/", ""));
        if (j.has("refresh_token")) e.putString("rt", j.getString("refresh_token"));
        e.apply();
    }

    static String read(InputStream in) throws IOException {
        if (in == null) return "";
        ByteArrayOutputStream o = new ByteArrayOutputStream(); byte[] b = new byte[4096]; int n;
        while ((n = in.read(b)) > 0) o.write(b, 0, n);
        return o.toString("UTF-8");
    }

    String[] call(String m, String path, String body) throws Exception {
        for (int a = 0; a < 2; a++) {
            String url = get("i") + path;
            if (m.equals("PATCH")) url += (path.contains("?") ? "&" : "?") + "_HttpMethod=PATCH";
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setRequestMethod(m.equals("GET") ? "GET" : "POST");
            c.setRequestProperty("Authorization", "Bearer " + get("at"));
            c.setRequestProperty("Content-Type", "application/json");
            if (body != null) { c.setDoOutput(true); c.getOutputStream().write(body.getBytes(StandardCharsets.UTF_8)); }
            int code = c.getResponseCode(); String b = read(code >= 400 ? c.getErrorStream() : c.getInputStream());
            if (code == 401 && a == 0 && !get("rt").isEmpty()) {
                token("grant_type=refresh_token&refresh_token=" + enc(get("rt")) + "&client_id=" + enc(get("c")));
                continue;
            }
            return new String[]{String.valueOf(code), b};
        }
        throw new Exception("auth failed");
    }

    // ---- offline queue (file) ----
    synchronized JSONArray readQ() {
        try { return new JSONArray(read(new FileInputStream(qf))); } catch (Exception e) { return new JSONArray(); }
    }
    synchronized void writeQ(JSONArray a) {
        try (FileOutputStream o = new FileOutputStream(qf)) { o.write(a.toString().getBytes(StandardCharsets.UTF_8)); } catch (Exception e) { }
    }
    synchronized void enqueue(int s, String np, String op, long t) throws Exception {
        JSONArray q = readQ(); q.put(new JSONObject().put("s", s).put("p", np).put("o", op).put("t", t)); writeQ(q);
    }
    synchronized void removeDone(Set<String> ids) throws Exception {
        JSONArray q = readQ(), keep = new JSONArray();
        for (int k = 0; k < q.length(); k++) {
            JSONObject o = q.getJSONObject(k);
            if (!ids.contains(o.getInt("s") + ":" + o.getLong("t"))) keep.put(o);
        }
        writeQ(keep);
    }

    void cycle() {
        ex.submit(new Runnable() { public void run() {
            try { flush(); pull(); int n = readQ().length(); status(n == 0 ? "Synced" : n + " pending"); }
            catch (Exception e) { status(readQ().length() + " pending \u00b7 " + (e.getMessage() == null ? "offline" : e.getMessage())); }
        } });
    }

    void flush() throws Exception {
        if (get("i").isEmpty()) return;
        JSONArray q = readQ(); if (q.length() == 0) return;
        int n = Math.min(q.length(), 200);
        JSONArray vr = new JSONArray(); List<String> ids = new ArrayList<String>();
        for (int k = 0; k < n; k++) {
            JSONObject o = q.getJSONObject(k);
            String key = String.format(Locale.US, "236-%04d", o.getInt("s")), ts = iso(o.getLong("t"), true);
            ids.add(o.getInt("s") + ":" + o.getLong("t"));
            vr.put(new JSONObject().put("attributes", new JSONObject().put("type", "Voter__c")).put("Voter_Key__c", key)
                .put("Party__c", o.getString("p")).put("Party_Updated_At__c", ts).put("Updated_By__c", get("uid") + "/" + get("dev")));
        }
        String base = "/services/data/" + API + "/composite/sobjects/";
        String[] r = call("PATCH", base + "Voter__c/Voter_Key__c", new JSONObject().put("allOrNone", false).put("records", vr).toString());
        if (!r[0].startsWith("2")) throw new Exception("upsert " + r[0] + " " + r[1]);
        JSONArray res = new JSONArray(r[1]); Set<String> done = new HashSet<String>();
        for (int k = 0; k < n; k++) if (res.getJSONObject(k).optBoolean("success")) done.add(ids.get(k));
        removeDone(done);
        if (done.size() < n) throw new Exception((n - done.size()) + " records rejected");
    }

    static final String FIELDS = "Voter_Key__c,Name,Serial_No__c,Section__c,Surname__c,Surname_Group__c,Relation_Type__c,Relative_Name__c,Door_No__c,Age__c,Gender__c,Party__c,Party_Updated_At__c,EPIC_No__c,Full_Address__c,SystemModstamp";
    static final String[][] MAP = {{"n","Name"},{"s","Serial_No__c"},{"sec","Section__c"},{"sr","Surname__c"},{"sg","Surname_Group__c"},{"rt","Relation_Type__c"},{"rel","Relative_Name__c"},{"h","Door_No__c"},{"age","Age__c"},{"g","Gender__c"},{"p","Party__c"},{"e","EPIC_No__c"},{"ad","Full_Address__c"}};

    /** Downloads every Voter__c changed since the last sync (all of them on the first run). */
    void pull() throws Exception {
        if (get("i").isEmpty()) return;
        String last = get("last"); if (last.isEmpty()) last = "1970-01-01T00:00:00Z";
        String path = "/services/data/" + API + "/query?q=" + enc("SELECT " + FIELDS + " FROM Voter__c WHERE SystemModstamp > " + last + " ORDER BY SystemModstamp");
        JSONArray out = new JSONArray(); long max = 0;
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.US);
        while (path != null) {
            String[] r = call("GET", path, null);
            if (!r[0].startsWith("2")) throw new Exception("query " + r[0] + " " + r[1]);
            JSONObject j = new JSONObject(r[1]); JSONArray rs = j.getJSONArray("records");
            for (int k = 0; k < rs.length(); k++) {
                JSONObject o = rs.getJSONObject(k);
                max = Math.max(max, f.parse(o.getString("SystemModstamp")).getTime());
                String pu = o.isNull("Party_Updated_At__c") ? "" : o.getString("Party_Updated_At__c");
                JSONObject x = new JSONObject().put("k", o.getString("Voter_Key__c")).put("t", pu.isEmpty() ? 0L : f.parse(pu).getTime());
                for (String[] m : MAP) if (!o.isNull(m[1])) x.put(m[0], o.get(m[1]));
                out.put(x);
            }
            path = j.optBoolean("done", true) ? null : j.getString("nextRecordsUrl");
        }
        if (max > 0) p.edit().putString("last", iso(max, false)).apply();
        js.run("window.onSfPull&&onSfPull(" + out.toString() + ")");
    }
}
