package com.example.dailyprogress;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    ArrayList<Item> items = new ArrayList<>();
    SharedPreferences db;
    LinearLayout list;
    EditText search;
    String today(){ return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()); }
    int dp(int n){ return (int)(n*getResources().getDisplayMetrics().density+.5f); }
    TextView text(String s,int sp){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setPadding(dp(10),dp(8),dp(10),dp(8)); return t; }

    @Override public void onCreate(Bundle b){ super.onCreate(b); db=getSharedPreferences("dpm_v2",0); load(); build(); }

    void build(){
        LinearLayout main=new LinearLayout(this); main.setOrientation(LinearLayout.VERTICAL); main.setPadding(dp(10),dp(10),dp(10),dp(10));
        TextView title=text("Daily Progress Manager",24); main.addView(title);
        search=new EditText(this); search.setHint("Search name, number or location"); main.addView(search);
        LinearLayout buttons=new LinearLayout(this);
        Button add=btn("+ Add Item"), trash=btn("Recycle Bin"), report=btn("Today Summary");
        buttons.addView(add,new LinearLayout.LayoutParams(0,-2,1)); buttons.addView(trash,new LinearLayout.LayoutParams(0,-2,1)); buttons.addView(report,new LinearLayout.LayoutParams(0,-2,1));
        main.addView(buttons);
        add.setOnClickListener(v->edit(null,-1)); trash.setOnClickListener(v->recycleBin()); report.setOnClickListener(v->summary());
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int d){} public void onTextChanged(CharSequence s,int a,int b,int c){refresh();} public void afterTextChanged(android.text.Editable e){}});
        list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); ScrollView sv=new ScrollView(this); sv.addView(list);
        main.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); setContentView(main); refresh();
    }
    Button btn(String s){ Button b=new Button(this); b.setText(s); return b; }

    void refresh(){
        list.removeAllViews(); String q=search==null?"":search.getText().toString().toLowerCase(Locale.US);
        int active=0;
        for(int i=0;i<items.size();i++){
            Item x=items.get(i); if(x.deleted) continue;
            if(!q.isEmpty() && !(x.name+" "+x.number+" "+x.location+" "+x.personal).toLowerCase(Locale.US).contains(q)) continue;
            active++; addCard(x,i);
        }
        if(active==0) list.addView(text("No active items found.",17));
    }

    void addCard(Item x,int index){
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
        String st=x.visited.getOrDefault(today(),false)?"VISITED":"NOT VISITED";
        TextView head=text(x.name+"  •  "+st,19); head.setTextColor(st.equals("VISITED")?Color.rgb(0,120,0):Color.DKGRAY); card.addView(head);
        double cumulative=cumulativeGiven(x,today());
        double remaining=x.target-cumulative;
        card.addView(text("Number: "+x.number+"\nFloat target: "+x.target+"\nGiven MTD: "+x.mtd+"\nRemaining: "+remaining+
                "\nLocation: "+x.location+"\nPersonal number: "+x.personal,15));
        LinearLayout r=new LinearLayout(this);
        Button v=btn(st.equals("VISITED")?"Mark Not Visited":"Mark Visited");
        Button p=btn("Daily Progress"), e=btn("Edit"), d=btn("Delete");
        r.addView(v);r.addView(p);r.addView(e);r.addView(d);card.addView(r);
        v.setOnClickListener(z->{x.visited.put(today(),!x.visited.getOrDefault(today(),false));save();refresh();});
        p.setOnClickListener(z->dailyHistory(x));
        e.setOnClickListener(z->edit(x,index));
        d.setOnClickListener(z->{new AlertDialog.Builder(this).setTitle("Delete item?").setMessage("It will go to Recycle Bin and can be restored.")
                .setPositiveButton("Delete",(a,w)->{x.deleted=true;save();refresh();}).setNegativeButton("Cancel",null).show();});
        list.addView(card); View line=new View(this); line.setBackgroundColor(Color.LTGRAY); list.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
    }

    void edit(Item x,int idx){
        LinearLayout f=new LinearLayout(this); f.setOrientation(LinearLayout.VERTICAL); f.setPadding(dp(18),0,dp(18),0);
        EditText name=field("Name",x==null?"":x.name), number=field("Number",x==null?"":x.number), target=field("Float target",x==null?"":""+x.target),
        mtd=field("Given MTD",x==null?"":""+x.mtd), loc=field("Location",x==null?"":x.location), personal=field("Personal number",x==null?"":x.personal);
        f.addView(name);f.addView(number);f.addView(target);f.addView(mtd);f.addView(loc);f.addView(personal);
        new AlertDialog.Builder(this).setTitle(x==null?"Add Item":"Edit Item").setView(f).setPositiveButton("Save",(d,w)->{
            Item a=x==null?new Item():x; a.name=name.getText().toString().trim();a.number=number.getText().toString().trim();a.target=num(target);a.mtd=num(mtd);
            a.location=loc.getText().toString().trim();a.personal=personal.getText().toString().trim(); if(x==null)items.add(a); save(); refresh();
        }).setNegativeButton("Cancel",null).show();
    }
    EditText field(String h,String v){EditText e=new EditText(this);e.setHint(h);e.setText(v);return e;}
    double num(EditText e){try{return Double.parseDouble(e.getText().toString());}catch(Exception z){return 0;}}

    void dailyHistory(Item x){
        LinearLayout f=new LinearLayout(this); f.setOrientation(LinearLayout.VERTICAL);
        EditText date=field("Date (YYYY-MM-DD)",today()), amount=field("Given today / progress amount",""+x.dailyAmount.getOrDefault(today(),0.0));
        CheckBox visited=new CheckBox(this); visited.setText("Visited on this date"); visited.setChecked(x.visited.getOrDefault(today(),false));
        f.addView(date);f.addView(amount);f.addView(visited);
        new AlertDialog.Builder(this).setTitle("Save Daily Progress").setView(f).setPositiveButton("Save",(d,w)->{
            String day=date.getText().toString().trim(); x.dailyAmount.put(day,num(amount)); x.visited.put(day,visited.isChecked()); save();
        }).setNegativeButton("Cancel",null).show();
    }

    double cumulativeGiven(Item x,String upTo){ double total=0; boolean hasDaily=false; for(Map.Entry<String,Double> e:x.dailyAmount.entrySet()){ if(e.getKey().compareTo(upTo)<=0){ total+=e.getValue(); hasDaily=true; } } return hasDaily?total:x.mtd; }

    void summary(){
        int total=0,vis=0; double target=0,mtd=0;
        for(Item x:items) if(!x.deleted){total++;target+=x.target;mtd+=cumulativeGiven(x,today());if(x.visited.getOrDefault(today(),false))vis++;}
        new AlertDialog.Builder(this).setTitle("Today • "+today()).setMessage("Active items: "+total+"\nVisited: "+vis+"\nNot visited: "+(total-vis)+
                "\nFloat target total: "+target+"\nGiven MTD total: "+mtd+"\nRemaining total: "+(target-mtd)).setPositiveButton("OK",null).show();
    }

    void recycleBin(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
        boolean any=false;
        for(int i=0;i<items.size();i++){Item x=items.get(i);if(!x.deleted)continue;any=true;CheckBox c=new CheckBox(this);c.setText(x.name+" • "+x.number);c.setTag(i);box.addView(c);}
        if(!any){new AlertDialog.Builder(this).setTitle("Recycle Bin").setMessage("No deleted items.").setPositiveButton("OK",null).show();return;}
        new AlertDialog.Builder(this).setTitle("Recycle Bin").setMessage("Select deleted items to restore.").setView(box).setPositiveButton("Restore Selected",(d,w)->{
            for(int j=0;j<box.getChildCount();j++){View v=box.getChildAt(j);if(v instanceof CheckBox && ((CheckBox)v).isChecked()){int i=(Integer)v.getTag();items.get(i).deleted=false;}}
            save();refresh();
        }).setNeutralButton("Restore All",(d,w)->{for(Item x:items)x.deleted=false;save();refresh();}).setNegativeButton("Close",null).show();
    }

    void save(){
        JSONArray a=new JSONArray();
        try{for(Item x:items)a.put(x.toJson());}catch(Exception e){}
        db.edit().putString("items",a.toString()).apply();
    }
    void load(){
        try{JSONArray a=new JSONArray(db.getString("items","[]"));for(int i=0;i<a.length();i++)items.add(Item.fromJson(a.getJSONObject(i)));}catch(Exception e){}
    }

    static class Item{
        String name="",number="",location="",personal=""; double target=0,mtd=0; boolean deleted=false;
        HashMap<String,Boolean> visited=new HashMap<>(); HashMap<String,Double> dailyAmount=new HashMap<>();
        JSONObject toJson() throws JSONException{
            JSONObject o=new JSONObject();o.put("name",name);o.put("number",number);o.put("location",location);o.put("personal",personal);
            o.put("target",target);o.put("mtd",mtd);o.put("deleted",deleted);o.put("visited",new JSONObject(visited));o.put("daily",new JSONObject(dailyAmount));return o;
        }
        static Item fromJson(JSONObject o)throws JSONException{
            Item x=new Item();x.name=o.optString("name");x.number=o.optString("number");x.location=o.optString("location");x.personal=o.optString("personal");
            x.target=o.optDouble("target");x.mtd=o.optDouble("mtd");x.deleted=o.optBoolean("deleted");
            JSONObject v=o.optJSONObject("visited");if(v!=null)for(String k:v.keySet())x.visited.put(k,v.optBoolean(k));
            JSONObject d=o.optJSONObject("daily");if(d!=null)for(String k:d.keySet())x.dailyAmount.put(k,d.optDouble(k));return x;
        }
    }
}