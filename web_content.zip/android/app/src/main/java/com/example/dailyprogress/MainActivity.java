package com.example.dailyprogress;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.net.Uri;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.JavascriptInterface;
import android.util.Base64;
import android.content.ContentResolver;
import android.content.res.AssetManager;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.content.pm.PackageManager;
import android.widget.Toast;
import android.app.AlertDialog;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.view.ViewGroup;
import android.view.Gravity;
import android.text.TextUtils;
import org.json.JSONObject;
import org.json.JSONArray;
import org.xmlpull.v1.XmlPullParser;
import android.util.Xml;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.io.File;
import java.io.FileOutputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private static final String APP_URL = "file:///android_asset/index.html";
    private static final int TEMPLATE_SAVE_REQUEST = 2102;
    private static final int IMPORT_PICKER_REQUEST = 3101;
    private static final int WEB_FILE_PICKER_REQUEST = 3102;
    private static final int READ_STORAGE_REQUEST = 4101;
    private boolean nativeImportRequest = false;
    private ValueCallback<Uri[]> webFileCallback;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request == null ? null : request.getUrl();
                if (u != null && "dpm-template".equalsIgnoreCase(u.getScheme())) {
                    launchTemplateSaveDocument();
                    return true;
                }
                if (u != null && "dpm.local".equalsIgnoreCase(u.getHost())) {
                    launchNativeImportPicker();
                    return true;
                }
                return false;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && url.startsWith("dpm-template://")) {
                    launchTemplateSaveDocument();
                    return true;
                }
                if (url != null && url.startsWith("https://dpm.local/") || url.startsWith("http://dpm.local/")) {
                    launchNativeImportPicker();
                    return true;
                }
                return false;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (webFileCallback != null) {
                    try { webFileCallback.onReceiveValue(null); } catch (Exception ignored) {}
                }
                nativeImportRequest = false;
                notifyJs("window.handleExcelDiagnostic && window.handleExcelDiagnostic('WEBVIEW_FILE_CHOOSER','Android WebView requested the file chooser.');");
                webFileCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        "text/csv", "text/plain", "application/octet-stream"
                });
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    startActivityForResult(intent, WEB_FILE_PICKER_REQUEST);
                    return true;
                } catch (Exception e) {
                    try { callback.onReceiveValue(null); } catch (Exception ignored) {}
                    webFileCallback = null;
                    Toast.makeText(MainActivity.this, "Android file picker could not be opened. Please use the Files app to select the Excel file.", Toast.LENGTH_LONG).show();
                    return true;
                }
            }
        });
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setAllowFileAccessFromFileURLs(true);
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidDPM");
        webView.loadUrl(buildUrl(getIntent()));
        setContentView(webView);
    }

    public class AndroidBridge {
        @JavascriptInterface public void saveBundledTemplate() {
            MainActivity.this.runOnUiThread(() -> saveBundledTemplateToDownloadsDirect());
        }

        @JavascriptInterface public void pickImportFile() {
            MainActivity.this.runOnUiThread(() -> launchNativeImportPicker());
        }
    }

    private void launchNativeImportPicker() {
        nativeImportRequest = true;
        notifyJs("window.handleExcelDiagnostic && window.handleExcelDiagnostic('NATIVE_PICKER_REQUESTED','Android is starting the native file picker.');");
        cancelWebFileCallback();
        Toast.makeText(this, "Opening Android file picker…", Toast.LENGTH_SHORT).show();

        // IMPORTANT: use the simplest Android GET_CONTENT contract here.
        // Several vendor WebViews/file providers fail when ACTION_OPEN_DOCUMENT
        // is combined with EXTRA_MIME_TYPES/persistable permissions. The app
        // validates the extension after selection, so */* is intentional.
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivityForResult(intent, IMPORT_PICKER_REQUEST);
            notifyJs("window.handleExcelDiagnostic && window.handleExcelDiagnostic('PICKER_OPENED','Android file picker opened successfully.');");
            notifyJs("window.handleAndroidImportPickerOpened && window.handleAndroidImportPickerOpened();");
        } catch (ActivityNotFoundException e) {
            nativeImportRequest = false;
            notifyJs("window.handleExcelDiagnostic && window.handleExcelDiagnostic('PICKER_OPEN_FAILED','Android could not start the file picker.');");
            notifyJs("window.handleAndroidImportError && window.handleAndroidImportError('Android has no file picker available.');");
            showDownloadsPickerAsync();
        } catch (Exception e) {
            nativeImportRequest = false;
            notifyJs("window.handleAndroidImportError && window.handleAndroidImportError(" + JSONObject.quote("Could not open Android file picker: " + e.getMessage()) + ");");
            showDownloadsPickerAsync();
        }
    }

    /**
     * Primary import path:
     * Android's native document picker is launched directly (no chooser wrapper),
     * and the returned content:// URI is consumed by this Activity.
     *
     * If the device has no usable document picker Activity, the app falls back to
     * its own Downloads list.
     */
    private void startImportPicker(ValueCallback<Uri[]> callback) {
        if (webFileCallback != null) {
            try { webFileCallback.onReceiveValue(null); } catch (Exception ignored) {}
            webFileCallback = null;
        }
        webFileCallback = callback;

        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "text/csv",
                "text/plain",
                "application/octet-stream"
        });
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        try {
            startActivityForResult(intent, WEB_FILE_PICKER_REQUEST);
            notifyJs("window.handleAndroidImportPickerOpened && window.handleAndroidImportPickerOpened();");
        } catch (ActivityNotFoundException e) {
            webFileCallback = callback;
            showDownloadsPickerAsync();
        } catch (Exception e) {
            webFileCallback = callback;
            showDownloadsPickerAsync();
        }
    }

    /**
     * App-owned fallback. The MediaStore query runs off the UI thread so a
     * slow/vendor-specific Downloads provider cannot freeze the WebView after
     * the user taps Choose File.
     */
    private void showDownloadsPickerAsync() {
        // Do NOT query MediaStore here. Some TECNO/Android builds can block
        // indefinitely while querying the Downloads provider. Instead scan the
        // public Downloads directory directly after READ_EXTERNAL_STORAGE is granted.
        new Thread(() -> {
            final ArrayList<Uri> uris = new ArrayList<>();
            final ArrayList<String> names = new ArrayList<>();
            String loadError = null;
            try {
                ArrayList<File> roots = new ArrayList<>();
                File primary = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                roots.add(primary);
                File alt = new File(Environment.getExternalStorageDirectory(), "Downloads");
                if (!alt.getAbsolutePath().equals(primary.getAbsolutePath())) roots.add(alt);

                for (File root : roots) {
                    if (root == null || !root.exists() || !root.isDirectory()) continue;
                    File[] files = root.listFiles();
                    if (files == null) continue;
                    java.util.Arrays.sort(files, (a,b) -> Long.compare(b.lastModified(), a.lastModified()));
                    for (File f : files) {
                        if (f == null || !f.isFile()) continue;
                        if (!isSupportedImportFile(f.getName(), "")) continue;
                        uris.add(Uri.fromFile(f));
                        names.add(f.getName());
                        if (names.size() >= 200) break;
                    }
                    if (names.size() >= 200) break;
                }
            } catch (Exception e) {
                loadError = e.getClass().getSimpleName()
                        + (TextUtils.isEmpty(e.getMessage()) ? "" : ": " + e.getMessage());
            }

            final String finalLoadError = loadError;
            runOnUiThread(() -> showDownloadsPickerDialog(uris, names, finalLoadError));
        }).start();
    }

    private boolean isSupportedImportFile(String name, String mime) {
        String lower = String.valueOf(name == null ? "" : name).toLowerCase();
        return lower.endsWith(".xlsx")
                || lower.endsWith(".csv")
                || lower.endsWith(".txt")
                || "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet".equalsIgnoreCase(mime)
                || "text/csv".equalsIgnoreCase(mime)
                || "text/plain".equalsIgnoreCase(mime);
    }

    private void showDownloadsPickerDialog(ArrayList<Uri> uris, ArrayList<String> names, String loadError) {
        final ListView list = new ListView(this);
        list.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        list.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, names));

        TextView header = new TextView(this);
        if (loadError == null) {
            header.setText("Select an .xlsx, .csv or .txt file from Downloads");
        } else {
            header.setText("Could not read Downloads.\n" + loadError
                    + "\n\nUse the Android file picker again or check that the file is in Downloads.");
        }
        header.setTextSize(15);
        header.setPadding(24, 20, 24, 20);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Choose Excel file")
                .setCustomTitle(header)
                .setView(list)
                .setNegativeButton("Cancel", (d, w) -> cancelWebFileCallback())
                .create();

        list.setOnItemClickListener((parent, view, position, id) -> {
            if (position >= 0 && position < uris.size()) {
                Uri uri = uris.get(position);
                dialog.dismiss();
                handleNativeSelectedUri(uri);
            }
        });

        TextView empty = makePickerEmptyView();
        android.widget.FrameLayout pickerFrame = new android.widget.FrameLayout(this);
        pickerFrame.addView(list, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        pickerFrame.addView(empty, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        list.setEmptyView(empty);

        dialog.setView(pickerFrame);
        dialog.setOnCancelListener(d -> cancelWebFileCallback());
        dialog.show();

        if (loadError == null) {
            notifyJs("window.handleAndroidImportPickerOpened && window.handleAndroidImportPickerOpened();");
        }
    }

    private TextView makePickerEmptyView() {
        TextView empty = new TextView(this);
        empty.setText("No Excel/CSV files were found in Downloads.\n\nSave your .xlsx or .csv file to the phone's Downloads folder, then tap Choose File again.");
        empty.setTextSize(16);
        empty.setGravity(Gravity.CENTER);
        empty.setPadding(30, 30, 30, 30);
        return empty;
    }

    private void cancelWebFileCallback() {
        if (webFileCallback != null) {
            ValueCallback<Uri[]> cb = webFileCallback;
            webFileCallback = null;
            cb.onReceiveValue(null);
        }
    }

    private void handleNativeSelectedUri(Uri uri) {
        if (uri == null) {
            notifyJs("window.handleExcelDiagnostic && window.handleExcelDiagnostic('NO_URI','Android returned no file URI.');");
            if (webFileCallback != null) {
                ValueCallback<Uri[]> cb = webFileCallback;
                webFileCallback = null;
                runOnUiThread(() -> cb.onReceiveValue(null));
            } else {
                notifyJs("window.handleAndroidImportError && window.handleAndroidImportError('No file was selected.');");
            }
            return;
        }

        notifyJs("window.handleExcelDiagnostic && window.handleExcelDiagnostic('URI_RECEIVED','Android returned a file URI: "+JSONObject.quote(String.valueOf(uri))+"');");

        // If the request came from the HTML <input type=file>, return the URI to
        // WebView and let the existing JavaScript parser process the File object.
        if (webFileCallback != null) {
            ValueCallback<Uri[]> cb = webFileCallback;
            webFileCallback = null;
            runOnUiThread(() -> cb.onReceiveValue(new Uri[]{uri}));
            return;
        }

        // The explicit AndroidDPM bridge still gets native parsing as a fallback.
        new Thread(() -> {
            try {
                notifyJs("window.handleExcelDiagnostic && window.handleExcelDiagnostic('FILE_READ_STARTED','Android is reading the selected file.');");
                String name = displayName(uri);
                String mime = getContentResolver().getType(uri);
                String matrixJson = parseImportUriToMatrixJson(uri, name, mime);
                notifyJs("window.handleExcelDiagnostic && window.handleExcelDiagnostic('FILE_READ_SUCCESS','Android read the file and parsed its rows.');");
                final String safeName = JSONObject.quote(name);
                final String safeJson = JSONObject.quote(matrixJson);
                if (webView != null) webView.post(() -> webView.evaluateJavascript(
                        "window.handleAndroidImportRows && window.handleAndroidImportRows(" + safeName + "," + safeJson + " );", null));
            } catch (Exception e) {
                final String msg = e.getMessage() == null ? "Could not read the selected file." : e.getMessage();
                notifyJs("window.handleExcelDiagnostic && window.handleExcelDiagnostic('FILE_READ_ERROR'," + JSONObject.quote(msg) + ");");
                notifyJs("window.handleAndroidImportError && window.handleAndroidImportError(" + JSONObject.quote(msg) + " );");
                runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private void notifyJs(String script) {
        if (webView != null) webView.post(() -> webView.evaluateJavascript(script, null));
    }

    private void launchTemplateSaveDocument() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        intent.putExtra(Intent.EXTRA_TITLE, "DailyProgressManager_Item_Import_Template.xlsx");
        try {
            startActivityForResult(intent, TEMPLATE_SAVE_REQUEST);
            notifyJs("window.handleExcelDiagnostic && window.handleExcelDiagnostic('SAVE_DIALOG_OPENED','Android save dialog opened successfully.');");
            notifyJs("window.handleAndroidTemplateSaveFallback && window.handleAndroidTemplateSaveFallback();");
        } catch (Exception e) {
            String msg = e.getMessage() == null ? "Could not open Android's save dialog." : e.getMessage();
            notifyJs("window.handleAndroidTemplateSaveError && window.handleAndroidTemplateSaveError(" + JSONObject.quote(msg) + ");");
            Toast.makeText(this, "Could not open the save dialog. " + msg, Toast.LENGTH_LONG).show();
        }
    }

    private void saveBundledTemplateToDownloadsDirect() {
        // Use Android's standard Save As document UI as the primary path. This
        // avoids MediaStore/Downloads-provider differences across TECNO and
        // other vendor ROMs. The actual bytes are copied in onActivityResult.
        launchTemplateSaveDocument();
    }

    private void saveBundledTemplateToDownloadsDirectLegacy() {
        final String fileName = "DailyProgressManager_Item_Import_Template.xlsx";
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                values.put(MediaStore.Downloads.MIME_TYPE, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                values.put(MediaStore.Downloads.IS_PENDING, 1);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new Exception("Android could not create the Downloads file.");
                try (InputStream in = getAssets().open("DPM_Item_Import_Template.xlsx"); OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new Exception("Could not open the Downloads file for writing.");
                    byte[] buf = new byte[8192]; int n;
                    while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                }
                ContentValues published = new ContentValues();
                published.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(uri, published, null, null);
            } else {
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists() && !dir.mkdirs()) throw new Exception("Could not create the Downloads folder.");
                File target = new File(dir, fileName);
                if (target.exists()) {
                    int suffix = 2;
                    while (new File(dir, "DailyProgressManager_Item_Import_Template ("+suffix+").xlsx").exists()) suffix++;
                    target = new File(dir, "DailyProgressManager_Item_Import_Template ("+suffix+").xlsx");
                }
                try (InputStream in = getAssets().open("DPM_Item_Import_Template.xlsx"); OutputStream out = new FileOutputStream(target)) {
                    byte[] buf = new byte[8192]; int n;
                    while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                }
            }
            Toast.makeText(this, "Excel template saved to Downloads.", Toast.LENGTH_LONG).show();
            if (webView != null) webView.post(() -> webView.evaluateJavascript("window.handleAndroidTemplateSaved && window.handleAndroidTemplateSaved(" + JSONObject.quote(fileName) + ");", null));
        } catch (Exception e) {
            // Some vendor ROMs reject MediaStore Downloads writes. Fall back to
            // Android's standard Save As document UI so the button always has a
            // visible, user-controlled path.
            launchTemplateSaveDocument();
        }
    }

    private void saveBundledTemplateTo(Uri uri) throws Exception {
        AssetManager am = getAssets();
        InputStream in = am.open("DPM_Item_Import_Template.xlsx");
        OutputStream out = getContentResolver().openOutputStream(uri);
        if (out == null) throw new Exception("Could not open the selected destination.");
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        out.flush(); out.close(); in.close();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == IMPORT_PICKER_REQUEST) {
            notifyJs("window.handleExcelDiagnostic && window.handleExcelDiagnostic('PICKER_RETURNED', resultCode == RESULT_OK ? 'Android returned OK.' : 'Android picker was cancelled.');");
            boolean wasNative = nativeImportRequest;
            nativeImportRequest = false;
            if (resultCode == RESULT_OK && data != null) {
                Uri uri = data.getData();
                if (uri == null && data.getClipData() != null && data.getClipData().getItemCount() > 0) {
                    uri = data.getClipData().getItemAt(0).getUri();
                }
                if (uri != null) {
                    final Uri selectedUri = uri;
                    if (wasNative) {
                        try { getContentResolver().takePersistableUriPermission(selectedUri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
                        handleNativeSelectedUri(selectedUri);
                    } else if (webFileCallback != null) {
                        ValueCallback<Uri[]> cb = webFileCallback;
                        webFileCallback = null;
                        runOnUiThread(() -> cb.onReceiveValue(new Uri[]{selectedUri}));
                    } else {
                        handleNativeSelectedUri(selectedUri);
                    }
                } else {
                    cancelWebFileCallback();
                    notifyJs("window.handleAndroidImportError && window.handleAndroidImportError('Android returned no file. Please choose the Excel file again.');");
                }
            } else {
                cancelWebFileCallback();
                notifyJs("window.handleAndroidImportCancelled && window.handleAndroidImportCancelled();");
            }
            return;
        }

        if (requestCode == WEB_FILE_PICKER_REQUEST) {
            if (resultCode == RESULT_OK && data != null) {
                Uri uri = data.getData();
                if (uri == null && data.getClipData() != null && data.getClipData().getItemCount() > 0) {
                    uri = data.getClipData().getItemAt(0).getUri();
                }
                if (uri != null && webFileCallback != null) {
                    final Uri selectedUri = uri;
                    ValueCallback<Uri[]> cb = webFileCallback;
                    webFileCallback = null;
                    runOnUiThread(() -> cb.onReceiveValue(new Uri[]{selectedUri}));
                } else {
                    cancelWebFileCallback();
                    notifyJs("window.handleAndroidImportError && window.handleAndroidImportError('Android returned no file. Please choose the Excel file again.');");
                }
            } else {
                cancelWebFileCallback();
                notifyJs("window.handleAndroidImportCancelled && window.handleAndroidImportCancelled();");
            }
            return;
        }

        if (requestCode == TEMPLATE_SAVE_REQUEST) {
            notifyJs("window.handleExcelDiagnostic && window.handleExcelDiagnostic('SAVE_DIALOG_RETURNED', resultCode == RESULT_OK ? 'Save location selected.' : 'Save dialog cancelled.');");
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try {
                    saveBundledTemplateTo(data.getData());
                    Toast.makeText(this, "Excel template saved successfully.", Toast.LENGTH_LONG).show();
                    notifyJs("window.handleAndroidTemplateSaved && window.handleAndroidTemplateSaved('DailyProgressManager_Item_Import_Template.xlsx');");
                } catch (Exception e) {
                    String msg = e.getMessage() == null ? "Could not save the Excel template." : e.getMessage();
                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
                    notifyJs("window.handleAndroidTemplateSaveError && window.handleAndroidTemplateSaveError(" + JSONObject.quote(msg) + ");");
                }
            } else {
                notifyJs("window.handleAndroidTemplateSaveError && window.handleAndroidTemplateSaveError('Template save was cancelled.');");
            }
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == READ_STORAGE_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                showDownloadsPickerAsync();
            } else {
                Toast.makeText(this, "Storage permission is needed to read Excel files from Downloads.", Toast.LENGTH_LONG).show();
                notifyJs("window.handleAndroidImportError && window.handleAndroidImportError('Storage permission was denied. Allow storage access, then try Choose File again.');");
            }
        }
    }

    private String displayName(Uri uri) {
        if (uri == null) return "Selected file";
        if ("file".equalsIgnoreCase(uri.getScheme()) && uri.getPath() != null) {
            File f = new File(uri.getPath());
            return f.getName();
        }
        String n = uri.getLastPathSegment();
        return TextUtils.isEmpty(n) ? "Selected file" : n;
    }

    private String parseImportUriToMatrixJson(Uri uri, String name, String mime) throws Exception {
        String lower = String.valueOf(name).toLowerCase();
        boolean zipLike = "application/zip".equalsIgnoreCase(mime) || "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet".equalsIgnoreCase(mime);
        if (lower.endsWith(".csv") || lower.endsWith(".txt") || "text/csv".equalsIgnoreCase(mime) || "text/plain".equalsIgnoreCase(mime)) {
            InputStream in = getContentResolver().openInputStream(uri);
            if (in == null) throw new Exception("Could not read the selected file.");
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192]; int n; long total = 0;
            while ((n = in.read(buf)) != -1) { total += n; if (total > 10L*1024L*1024L) throw new Exception("Please use a file smaller than 10 MB."); out.write(buf,0,n); }
            in.close();
            return csvToJson(new String(out.toByteArray(), StandardCharsets.UTF_8));
        }
        if (!lower.endsWith(".xlsx") && !zipLike) throw new Exception("Please choose an .xlsx, .csv or .txt file. Older .xls files are not supported by the Android importer.");
        InputStream in = getContentResolver().openInputStream(uri);
        if (in == null) throw new Exception("Could not read the selected file.");
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192]; int n; long total=0;
        while ((n=in.read(buf))!=-1) { total+=n; if(total>10L*1024L*1024L) throw new Exception("Please use a file smaller than 10 MB."); out.write(buf,0,n); }
        in.close();
        return xlsxToJson(out.toByteArray());
    }

    private String csvToJson(String text) throws Exception {
        List<List<String>> rows = new ArrayList<>();
        List<String> row = new ArrayList<>(); StringBuilder cell = new StringBuilder(); boolean quoted = false;
        for (int i=0;i<text.length();i++) {
            char ch=text.charAt(i), next=i+1<text.length()?text.charAt(i+1):0;
            if (ch=='"') { if (quoted && next=='"') { cell.append('"'); i++; } else quoted=!quoted; }
            else if (ch==',' && !quoted) { row.add(cell.toString()); cell.setLength(0); }
            else if ((ch=='\n'||ch=='\r') && !quoted) { if(ch=='\r'&&next=='\n')i++; row.add(cell.toString()); cell.setLength(0); rows.add(row); row=new ArrayList<>(); }
            else cell.append(ch);
        }
        if (cell.length()>0 || !row.isEmpty()) { row.add(cell.toString()); rows.add(row); }
        return rowsToJson(rows);
    }

    private String xlsxToJson(byte[] bytes) throws Exception {
        Map<String, byte[]> entries = new HashMap<>();
        ZipInputStream zin = new ZipInputStream(new ByteArrayInputStream(bytes));
        ZipEntry e; byte[] buf = new byte[8192];
        while ((e=zin.getNextEntry())!=null) {
            if (!e.isDirectory()) { ByteArrayOutputStream out=new ByteArrayOutputStream(); int n; while((n=zin.read(buf))!=-1) out.write(buf,0,n); entries.put(e.getName(),out.toByteArray()); }
            zin.closeEntry();
        }
        zin.close();
        if (!entries.containsKey("xl/workbook.xml")) throw new Exception("Invalid Excel workbook: workbook.xml is missing.");
        String sheetTarget = "xl/worksheets/sheet1.xml";
        try {
            XmlPullParser wp=Xml.newPullParser(); wp.setInput(new ByteArrayInputStream(entries.get("xl/workbook.xml")), "UTF-8");
            String firstRid=null; int ev;
            while((ev=wp.next())!=XmlPullParser.END_DOCUMENT){ if(ev==XmlPullParser.START_TAG && "sheet".equals(wp.getName())) { firstRid=wp.getAttributeValue("http://schemas.openxmlformats.org/officeDocument/2006/relationships","id"); if(firstRid==null) firstRid=wp.getAttributeValue(null,"r:id"); break; } }
            if(firstRid!=null && entries.containsKey("xl/_rels/workbook.xml.rels")) {
                XmlPullParser rp=Xml.newPullParser(); rp.setInput(new ByteArrayInputStream(entries.get("xl/_rels/workbook.xml.rels")),"UTF-8");
                while((ev=rp.next())!=XmlPullParser.END_DOCUMENT){ if(ev==XmlPullParser.START_TAG && "Relationship".equals(rp.getName()) && firstRid.equals(rp.getAttributeValue(null,"Id"))) { String target=rp.getAttributeValue(null,"Target"); if(target!=null){ target=target.replaceFirst("^/",""); if(target.startsWith("../")) target=target.substring(3); if(!target.startsWith("xl/")) target="xl/"+target; sheetTarget=target; } break; } }
            }
        } catch(Exception ignored) {}
        if(!entries.containsKey(sheetTarget)) throw new Exception("The first worksheet could not be read.");
        List<String> shared = new ArrayList<>();
        if(entries.containsKey("xl/sharedStrings.xml")) {
            XmlPullParser sp=Xml.newPullParser(); sp.setInput(new ByteArrayInputStream(entries.get("xl/sharedStrings.xml")),"UTF-8");
            StringBuilder t=null; int ev;
            while((ev=sp.next())!=XmlPullParser.END_DOCUMENT){
                if(ev==XmlPullParser.START_TAG && "si".equals(sp.getName())) t=new StringBuilder();
                else if(ev==XmlPullParser.TEXT && t!=null) t.append(sp.getText());
                else if(ev==XmlPullParser.END_TAG && "si".equals(sp.getName()) && t!=null){ shared.add(t.toString()); t=null; }
            }
        }
        List<List<String>> rows = new ArrayList<>();
        XmlPullParser xp=Xml.newPullParser(); xp.setInput(new ByteArrayInputStream(entries.get(sheetTarget)),"UTF-8");
        List<String> current=null; int maxCol=-1; int currentRowNum=-1; int ev; String cellRef=null, cellType=null, cellValue=null, inlineText=null;
        while((ev=xp.next())!=XmlPullParser.END_DOCUMENT){
            if(ev==XmlPullParser.START_TAG && "row".equals(xp.getName())) { current=new ArrayList<>(); currentRowNum=parseRowNum(xp.getAttributeValue(null,"r")); }
            else if(ev==XmlPullParser.START_TAG && "c".equals(xp.getName()) && current!=null) { cellRef=xp.getAttributeValue(null,"r"); cellType=xp.getAttributeValue(null,"t"); cellValue=null; inlineText=null; }
            else if(ev==XmlPullParser.START_TAG && "v".equals(xp.getName()) && cellRef!=null) { cellValue=xp.nextText(); }
            else if(ev==XmlPullParser.START_TAG && "t".equals(xp.getName()) && cellRef!=null) { inlineText=(inlineText==null?"":inlineText)+xp.nextText(); }
            else if(ev==XmlPullParser.END_TAG && "c".equals(xp.getName()) && cellRef!=null && current!=null) {
                int col=columnIndex(cellRef); while(current.size()<=col) current.add(""); String val=inlineText!=null?inlineText:(cellValue==null?"":cellValue);
                if("s".equals(cellType)) { try { int si=Integer.parseInt(val); val=si>=0&&si<shared.size()?shared.get(si):""; } catch(Exception ignored){} }
                current.set(col,val); if(col>maxCol)maxCol=col; cellRef=null;
            }
            else if(ev==XmlPullParser.END_TAG && "row".equals(xp.getName()) && current!=null) { while(current.size()<=maxCol) current.add(""); rows.add(current); current=null; }
        }
        return rowsToJson(rows);
    }

    private int parseRowNum(String s){ try{return Integer.parseInt(s);}catch(Exception e){return -1;} }
    private int columnIndex(String ref){ if(ref==null)return 0; int n=0; for(int i=0;i<ref.length();i++){ char c=ref.charAt(i); if(c<'A'||c>'Z')break; n=n*26+(c-'A'+1);} return Math.max(0,n-1); }
    private String rowsToJson(List<List<String>> rows) throws Exception {
        JSONArray outer=new JSONArray();
        for(List<String> row:rows){ JSONArray inner=new JSONArray(); for(String v:row) inner.put(v==null?"":v); outer.put(inner); }
        return outer.toString();
    }

    private String buildUrl(Intent intent) {
        Uri data = intent == null ? null : intent.getData();
        if (data != null && "dpm".equalsIgnoreCase(data.getScheme())) {
            StringBuilder url = new StringBuilder(APP_URL);
            String query = data.getEncodedQuery();
            String fragment = data.getEncodedFragment();
            if (query != null && !query.isEmpty()) url.append("?").append(query);
            if (fragment != null && !fragment.isEmpty()) url.append("#").append(fragment);
            if ((query != null && !query.isEmpty()) || (fragment != null && !fragment.isEmpty())) return url.toString();
        }
        return APP_URL;
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String url = buildUrl(intent);
        if (webView != null) webView.loadUrl(url);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
