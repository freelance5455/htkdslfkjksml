package com.example.dailyprogress;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;

public class MainActivity extends Activity {
    private WebView webView;
    private static final String APP_URL = "file:///android_asset/index.html";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.loadUrl(buildUrl(getIntent()));
        setContentView(webView);
    }

    private String buildUrl(Intent intent) {
        Uri data = intent == null ? null : intent.getData();
        if (data != null && "dpm".equalsIgnoreCase(data.getScheme())) {
            StringBuilder url = new StringBuilder(APP_URL);
            String query = data.getEncodedQuery();
            String fragment = data.getEncodedFragment();
            if (query != null && !query.isEmpty()) url.append("?").append(query);
            if (fragment != null && !fragment.isEmpty()) url.append("#").append(fragment);
            if (query != null && !query.isEmpty() || fragment != null && !fragment.isEmpty()) return url.toString();
        }
        return APP_URL;
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String url = buildUrl(intent);
        if (webView != null) webView.loadUrl(url);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
