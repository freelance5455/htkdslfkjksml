package com.example.dailyprogress;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.JavascriptInterface;
import android.util.Base64;
import android.content.ContentResolver;
import android.content.res.AssetManager;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.os.Build;
import android.widget.Toast;
import android.text.TextUtils;
import org.json.JSONObject;
import org.json.JSONArray;
import org.xmlpull.v1.XmlPullParser;
import android.util.Xml;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.io.File;
import java.io.FileOutputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private static final String APP_URL = "file:///android_asset/index.html";
    private static final int FILE_PICK_REQUEST = 2101;
    private static final int TEMPLATE_SAVE_REQUEST = 2102;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.setWebViewClient(new WebViewClient());
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setAllowFileAccessFromFileURLs(true);
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidDPM");
        webView.loadUrl(buildUrl(getIntent()));
        setContentView(webView);
    }

    public class AndroidBridge {
        @JavascriptInterface public void saveBundledTemplate() {
            MainActivity.this.runOnUiThread(() -> saveBundledTemplateToDownloadsDirect());
        }

        @JavascriptInterface public void pickImportFile() {
            MainActivity.this.runOnUiThread(() -> openImportFilePicker());
        }
    }

    private void saveBundledTemplateToDownloadsDirect() {
        final String fileName = "DailyProgressManager_Item_Import_Template.xlsx";
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                values.put(MediaStore.Downloads.MIME_TYPE, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new Exception("Android could not create the Downloads file.");
                try (InputStream in = getAssets().open("DPM_Item_Import_Template.xlsx"); OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new Exception("Could not open the Downloads file for writing.");
                    byte[] buf = new byte[8192]; int n;
                    while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                }
            } else {
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists() && !dir.mkdirs()) throw new Exception("Could not create the Downloads folder.");
                File target = new File(dir, fileName);
                if (target.exists()) {
                    int suffix = 2;
                    while (new File(dir, "DailyProgressManager_Item_Import_Template ("+suffix+").xlsx").exists()) suffix++;
                    target = new File(dir, "DailyProgressManager_Item_Import_Template ("+suffix+").xlsx");
                }
                try (InputStream in = getAssets().open("DPM_Item_Import_Template.xlsx"); OutputStream out = new FileOutputStream(target)) {
                    byte[] buf = new byte[8192]; int n;
                    while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                }
            }
            Toast.makeText(this, "Excel template saved to Downloads.", Toast.LENGTH_LONG).show();
            if (webView != null) webView.post(() -> webView.evaluateJavascript("window.handleAndroidTemplateSaved && window.handleAndroidTemplateSaved(" + JSONObject.quote(fileName) + ");", null));
        } catch (Exception e) {
            final String msg = e.getMessage() == null ? "Could not save the Excel template." : e.getMessage();
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
            if (webView != null) webView.post(() -> webView.evaluateJavascript("window.handleAndroidTemplateSaveError && window.handleAndroidTemplateSaveError(" + JSONObject.quote(msg) + ");", null));
        }
    }

    private void openImportFilePicker() {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("*/*");
            intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "application/vnd.ms-excel",
                "text/csv",
                "text/plain",
                "application/octet-stream"
            });
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(intent, FILE_PICK_REQUEST);
        } catch (Exception e) {
            try {
                Intent fallback = new Intent(Intent.ACTION_GET_CONTENT);
                fallback.addCategory(Intent.CATEGORY_OPENABLE);
                fallback.setType("*/*");
                fallback.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    "application/vnd.ms-excel",
                    "text/csv",
                    "text/plain",
                    "application/octet-stream"
                });
                fallback.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivityForResult(fallback, FILE_PICK_REQUEST);
            } catch (Exception e2) {
                Toast.makeText(this, "Could not open the file picker: " + e2.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }

    private void saveBundledTemplateTo(Uri uri) throws Exception {
        AssetManager am = getAssets();
        InputStream in = am.open("DPM_Item_Import_Template.xlsx");
        OutputStream out = getContentResolver().openOutputStream(uri);
        if (out == null) throw new Exception("Could not open the selected destination.");
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        out.flush(); out.close(); in.close();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_PICK_REQUEST) {
            Uri uri = (resultCode == RESULT_OK && data != null) ? data.getData() : null;
            if (uri == null) {
                if (webView != null) webView.post(() -> webView.evaluateJavascript("window.handleAndroidImportError && window.handleAndroidImportError('No file was selected.');", null));
                return;
            }
            new Thread(() -> {
                try {
                    try {
                        getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } catch (Exception ignored) {}
                    String name = displayName(uri);
                    String mime = getContentResolver().getType(uri);
                    String matrixJson = parseImportUriToMatrixJson(uri, name, mime);
                    final String safeName = JSONObject.quote(name);
                    final String safeJson = JSONObject.quote(matrixJson);
                    if (webView != null) webView.post(() -> webView.evaluateJavascript(
                        "window.handleAndroidImportRows && window.handleAndroidImportRows(" + safeName + "," + safeJson + ");", null));
                } catch (Exception e) {
                    final String msg = e.getMessage() == null ? "Unknown file-read error." : e.getMessage();
                    if (webView != null) webView.post(() -> webView.evaluateJavascript(
                        "window.handleAndroidImportError && window.handleAndroidImportError(" + JSONObject.quote(msg) + ");", null));
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "Could not read the selected file: " + msg, Toast.LENGTH_LONG).show());
                }
            }).start();
        } else if (requestCode == TEMPLATE_SAVE_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try {
                    saveBundledTemplateTo(data.getData());
                    Toast.makeText(this, "Excel template saved successfully.", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Could not save the Excel template: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        }
    }

    private String displayName(Uri uri) {
        String name = null;
        android.database.Cursor c = getContentResolver().query(uri, null, null, null, null);
        if (c != null) {
            try {
                int idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (c.moveToFirst() && idx >= 0) name = c.getString(idx);
            } finally { c.close(); }
        }
        if (TextUtils.isEmpty(name)) name = "import.xlsx";
        return name;
    }

    private String parseImportUriToMatrixJson(Uri uri, String name, String mime) throws Exception {
        String lower = String.valueOf(name).toLowerCase();
        boolean zipLike = "application/zip".equalsIgnoreCase(mime) || "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet".equalsIgnoreCase(mime);
        if (lower.endsWith(".csv") || lower.endsWith(".txt") || "text/csv".equalsIgnoreCase(mime) || "text/plain".equalsIgnoreCase(mime)) {
            InputStream in = getContentResolver().openInputStream(uri);
            if (in == null) throw new Exception("Could not read the selected file.");
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192]; int n; long total = 0;
            while ((n = in.read(buf)) != -1) { total += n; if (total > 10L*1024L*1024L) throw new Exception("Please use a file smaller than 10 MB."); out.write(buf,0,n); }
            in.close();
            return csvToJson(new String(out.toByteArray(), StandardCharsets.UTF_8));
        }
        if (!lower.endsWith(".xlsx") && !zipLike) throw new Exception("Please choose an .xlsx, .csv or .txt file. Older .xls files are not supported by the Android importer.");
        InputStream in = getContentResolver().openInputStream(uri);
        if (in == null) throw new Exception("Could not read the selected file.");
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192]; int n; long total=0;
        while ((n=in.read(buf))!=-1) { total+=n; if(total>10L*1024L*1024L) throw new Exception("Please use a file smaller than 10 MB."); out.write(buf,0,n); }
        in.close();
        return xlsxToJson(out.toByteArray());
    }

    private String csvToJson(String text) throws Exception {
        List<List<String>> rows = new ArrayList<>();
        List<String> row = new ArrayList<>(); StringBuilder cell = new StringBuilder(); boolean quoted = false;
        for (int i=0;i<text.length();i++) {
            char ch=text.charAt(i), next=i+1<text.length()?text.charAt(i+1):0;
            if (ch=='"') { if (quoted && next=='"') { cell.append('"'); i++; } else quoted=!quoted; }
            else if (ch==',' && !quoted) { row.add(cell.toString()); cell.setLength(0); }
            else if ((ch=='\n'||ch=='\r') && !quoted) { if(ch=='\r'&&next=='\n')i++; row.add(cell.toString()); cell.setLength(0); rows.add(row); row=new ArrayList<>(); }
            else cell.append(ch);
        }
        if (cell.length()>0 || !row.isEmpty()) { row.add(cell.toString()); rows.add(row); }
        return rowsToJson(rows);
    }

    private String xlsxToJson(byte[] bytes) throws Exception {
        Map<String, byte[]> entries = new HashMap<>();
        ZipInputStream zin = new ZipInputStream(new ByteArrayInputStream(bytes));
        ZipEntry e; byte[] buf = new byte[8192];
        while ((e=zin.getNextEntry())!=null) {
            if (!e.isDirectory()) { ByteArrayOutputStream out=new ByteArrayOutputStream(); int n; while((n=zin.read(buf))!=-1) out.write(buf,0,n); entries.put(e.getName(),out.toByteArray()); }
            zin.closeEntry();
        }
        zin.close();
        if (!entries.containsKey("xl/workbook.xml")) throw new Exception("Invalid Excel workbook: workbook.xml is missing.");
        String sheetTarget = "xl/worksheets/sheet1.xml";
        try {
            XmlPullParser wp=Xml.newPullParser(); wp.setInput(new ByteArrayInputStream(entries.get("xl/workbook.xml")), "UTF-8");
            String firstRid=null; int ev;
            while((ev=wp.next())!=XmlPullParser.END_DOCUMENT){ if(ev==XmlPullParser.START_TAG && "sheet".equals(wp.getName())) { firstRid=wp.getAttributeValue("http://schemas.openxmlformats.org/officeDocument/2006/relationships","id"); if(firstRid==null) firstRid=wp.getAttributeValue(null,"r:id"); break; } }
            if(firstRid!=null && entries.containsKey("xl/_rels/workbook.xml.rels")) {
                XmlPullParser rp=Xml.newPullParser(); rp.setInput(new ByteArrayInputStream(entries.get("xl/_rels/workbook.xml.rels")),"UTF-8");
                while((ev=rp.next())!=XmlPullParser.END_DOCUMENT){ if(ev==XmlPullParser.START_TAG && "Relationship".equals(rp.getName()) && firstRid.equals(rp.getAttributeValue(null,"Id"))) { String target=rp.getAttributeValue(null,"Target"); if(target!=null){ target=target.replaceFirst("^/",""); if(target.startsWith("../")) target=target.substring(3); if(!target.startsWith("xl/")) target="xl/"+target; sheetTarget=target; } break; } }
            }
        } catch(Exception ignored) {}
        if(!entries.containsKey(sheetTarget)) throw new Exception("The first worksheet could not be read.");
        List<String> shared = new ArrayList<>();
        if(entries.containsKey("xl/sharedStrings.xml")) {
            XmlPullParser sp=Xml.newPullParser(); sp.setInput(new ByteArrayInputStream(entries.get("xl/sharedStrings.xml")),"UTF-8");
            StringBuilder t=null; int ev;
            while((ev=sp.next())!=XmlPullParser.END_DOCUMENT){
                if(ev==XmlPullParser.START_TAG && "si".equals(sp.getName())) t=new StringBuilder();
                else if(ev==XmlPullParser.TEXT && t!=null) t.append(sp.getText());
                else if(ev==XmlPullParser.END_TAG && "si".equals(sp.getName()) && t!=null){ shared.add(t.toString()); t=null; }
            }
        }
        List<List<String>> rows = new ArrayList<>();
        XmlPullParser xp=Xml.newPullParser(); xp.setInput(new ByteArrayInputStream(entries.get(sheetTarget)),"UTF-8");
        List<String> current=null; int maxCol=-1; int currentRowNum=-1; int ev; String cellRef=null, cellType=null, cellValue=null, inlineText=null;
        while((ev=xp.next())!=XmlPullParser.END_DOCUMENT){
            if(ev==XmlPullParser.START_TAG && "row".equals(xp.getName())) { current=new ArrayList<>(); currentRowNum=parseRowNum(xp.getAttributeValue(null,"r")); }
            else if(ev==XmlPullParser.START_TAG && "c".equals(xp.getName()) && current!=null) { cellRef=xp.getAttributeValue(null,"r"); cellType=xp.getAttributeValue(null,"t"); cellValue=null; inlineText=null; }
            else if(ev==XmlPullParser.START_TAG && "v".equals(xp.getName()) && cellRef!=null) { cellValue=xp.nextText(); }
            else if(ev==XmlPullParser.START_TAG && "t".equals(xp.getName()) && cellRef!=null) { inlineText=(inlineText==null?"":inlineText)+xp.nextText(); }
            else if(ev==XmlPullParser.END_TAG && "c".equals(xp.getName()) && cellRef!=null && current!=null) {
                int col=columnIndex(cellRef); while(current.size()<=col) current.add(""); String val=inlineText!=null?inlineText:(cellValue==null?"":cellValue);
                if("s".equals(cellType)) { try { int si=Integer.parseInt(val); val=si>=0&&si<shared.size()?shared.get(si):""; } catch(Exception ignored){} }
                current.set(col,val); if(col>maxCol)maxCol=col; cellRef=null;
            }
            else if(ev==XmlPullParser.END_TAG && "row".equals(xp.getName()) && current!=null) { while(current.size()<=maxCol) current.add(""); rows.add(current); current=null; }
        }
        return rowsToJson(rows);
    }

    private int parseRowNum(String s){ try{return Integer.parseInt(s);}catch(Exception e){return -1;} }
    private int columnIndex(String ref){ if(ref==null)return 0; int n=0; for(int i=0;i<ref.length();i++){ char c=ref.charAt(i); if(c<'A'||c>'Z')break; n=n*26+(c-'A'+1);} return Math.max(0,n-1); }
    private String rowsToJson(List<List<String>> rows) throws Exception {
        JSONArray outer=new JSONArray();
        for(List<String> row:rows){ JSONArray inner=new JSONArray(); for(String v:row) inner.put(v==null?"":v); outer.put(inner); }
        return outer.toString();
    }

    private String buildUrl(Intent intent) {
        Uri data = intent == null ? null : intent.getData();
        if (data != null && "dpm".equalsIgnoreCase(data.getScheme())) {
            StringBuilder url = new StringBuilder(APP_URL);
            String query = data.getEncodedQuery();
            String fragment = data.getEncodedFragment();
            if (query != null && !query.isEmpty()) url.append("?").append(query);
            if (fragment != null && !fragment.isEmpty()) url.append("#").append(fragment);
            if ((query != null && !query.isEmpty()) || (fragment != null && !fragment.isEmpty())) return url.toString();
        }
        return APP_URL;
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String url = buildUrl(intent);
        if (webView != null) webView.loadUrl(url);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
