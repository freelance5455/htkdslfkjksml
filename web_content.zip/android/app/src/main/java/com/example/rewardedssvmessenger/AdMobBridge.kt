package com.example.rewardedssvmessenger

import android.app.Activity
import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.gms.ads.rewarded.ServerSideVerificationOptions
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import kotlin.concurrent.thread

class AdMobBridge(
    private val activity: Activity,
    private val webView: WebView
) {
    private var rewardedAd: RewardedAd? = null
    private var isLoading = false
    private var currentNonce: String? = null

    private val adUnitId =
        "ca-app-pub-3940256099942544/5224354917"

    private val apiBaseUrl =
        BuildConfig.API_BASE_URL

    private val prefs =
        activity.getSharedPreferences("reward_demo", Activity.MODE_PRIVATE)

    private var userId: String? = prefs.getString("user_id", null)

    init {
        ensureUserId()
        loadAd()
    }

    private fun ensureUserId() {
        if (userId == null) {
            userId = UUID.randomUUID().toString()
            prefs.edit().putString("user_id", userId).apply()
        }
    }

    fun loadAd() {
        activity.runOnUiThread {
            if (rewardedAd != null || isLoading) return@runOnUiThread

            isLoading = true

            RewardedAd.load(
                activity,
                adUnitId,
                AdRequest.Builder().build(),
                object : RewardedAdLoadCallback() {

                    override fun onAdLoaded(ad: RewardedAd) {
                        rewardedAd = ad
                        isLoading = false

                        ad.fullScreenContentCallback =
                            object : FullScreenContentCallback() {

                                override fun onAdShowedFullScreenContent() {
                                    rewardedAd = null
                                }

                                override fun onAdDismissedFullScreenContent() {
                                    sendAndroidEvent("adDismissed", "{}")
                                    loadAd()
                                }

                                override fun onAdFailedToShowFullScreenContent(
                                    adError: com.google.android.gms.ads.AdError
                                ) {
                                    rewardedAd = null
                                    sendAndroidEvent(
                                        "adFailedToShow",
                                        """{"code":${adError.code}}"""
                                    )
                                    loadAd()
                                }
                            }

                        sendAndroidEvent(
                            "adLoaded",
                            """{"status":"ready"}"""
                        )
                    }

                    override fun onAdFailedToLoad(error: LoadAdError) {
                        rewardedAd = null
                        isLoading = false

                        sendAndroidEvent(
                            "adFailedToLoad",
                            """{"code":${error.code}}"""
                        )
                    }
                }
            )
        }
    }

    @JavascriptInterface
    fun isRewardedAdLoaded(): Boolean {
        return rewardedAd != null
    }

    /*
     * Creates a backend reward session first, then attaches its one-time
     * nonce to the RewardedAd SSV custom_data field.
     */
    @JavascriptInterface
    fun showRewardedAd() {
        activity.runOnUiThread {
            val ad = rewardedAd

            if (ad == null) {
                sendAndroidEvent(
                    "adFailedToShow",
                    """{"message":"Ad is not loaded yet."}"""
                )
                loadAd()
                return@runOnUiThread
            }

            createRewardSessionAndShow(ad)
        }
    }

    private fun createRewardSessionAndShow(ad: RewardedAd) {
        val uid = userId ?: return

        thread {
            try {
                val url = URL("$apiBaseUrl/api/reward/session")
                val connection =
                    url.openConnection() as HttpURLConnection

                connection.requestMethod = "POST"
                connection.connectTimeout = 10000
                connection.readTimeout = 10000
                connection.setRequestProperty(
                    "X-User-Id",
                    uid
                )
                connection.setRequestProperty(
                    "Content-Type",
                    "application/json"
                )

                val status = connection.responseCode

                if (status !in 200..299) {
                    sendAndroidEvent(
                        "rewardSessionFailed",
                        """{"code":$status}"""
                    )
                    return@thread
                }

                val response =
                    connection.inputStream.bufferedReader()
                        .use { it.readText() }

                val nonce =
                    Regex(""""nonce"\s*:\s*"([^"]+)"""")
                        .find(response)
                        ?.groupValues
                        ?.get(1)

                if (nonce == null) {
                    sendAndroidEvent(
                        "rewardSessionFailed",
                        """{"message":"Backend returned no nonce"}"""
                    )
                    return@thread
                }

                currentNonce = nonce

                activity.runOnUiThread {
                    val options =
                        ServerSideVerificationOptions.Builder()
                            .setUserId(uid)
                            .setCustomData(nonce)
                            .build()

                    ad.setServerSideVerificationOptions(options)

                    /*
                     * Client callback is deliberately UI-only.
                     * The backend remains the authoritative reward source.
                     */
                    ad.show(activity) {
                        sendAndroidEvent(
                            "rewardPending",
                            """{"message":"Google reported the ad reward. Waiting for SSV."}"""
                        )
                    }
                }
            } catch (e: Exception) {
                sendAndroidEvent(
                    "rewardSessionFailed",
                    """{"message":"${escapeJson(e.message ?: "network error")}"}"""
                )
            }
        }
    }

    @JavascriptInterface
    fun getUserId(): String {
        return userId ?: ""
    }

    @JavascriptInterface
    fun refreshBalance() {
        val uid = userId ?: return

        thread {
            try {
                val url = URL("$apiBaseUrl/api/reward/balance")
                val connection =
                    url.openConnection() as HttpURLConnection

                connection.requestMethod = "GET"
                connection.connectTimeout = 10000
                connection.readTimeout = 10000
                connection.setRequestProperty(
                    "X-User-Id",
                    uid
                )

                val status = connection.responseCode

                if (status !in 200..299) {
                    sendAndroidEvent(
                        "balanceFailed",
                        """{"code":$status}"""
                    )
                    return@thread
                }

                val response =
                    connection.inputStream.bufferedReader()
                        .use { it.readText() }

                val balance =
                    Regex(""""balance"\s*:\s*(-?\d+)""")
                        .find(response)
                        ?.groupValues
                        ?.get(1)

                if (balance != null) {
                    sendAndroidEvent(
                        "balanceUpdated",
                        """{"balance":$balance}"""
                    )
                }
            } catch (e: Exception) {
                sendAndroidEvent(
                    "balanceFailed",
                    """{"message":"${escapeJson(e.message ?: "network error")}"}"""
                )
            }
        }
    }

    private fun sendAndroidEvent(
        eventName: String,
        jsonPayload: String
    ) {
        webView.post {
            val safeName =
                eventName.replace("'", "\\'")

            val script =
                "if(window.onAndroidEvent)" +
                " window.onAndroidEvent('$safeName',$jsonPayload);"

            webView.evaluateJavascript(script, null)
        }
    }

    private fun escapeJson(value: String): String =
        value
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r")
}
