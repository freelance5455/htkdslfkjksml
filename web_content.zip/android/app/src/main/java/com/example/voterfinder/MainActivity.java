package com.example.voterfinder;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.*;
import androidx.webkit.WebViewAssetLoader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    WebView w; String pendData; ValueCallback<Uri[]> fcb; Sf sf;
    final Handler h = new Handler(Looper.getMainLooper());
    final Runnable tick = new Runnable() { public void run() { sf.cycle(); h.postDelayed(this, 30000); } };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        w = new WebView(this);
        setContentView(w);
        sf = new Sf(this, new Sf.Js() { public void run(final String s) {
            w.post(new Runnable() { public void run() { w.evaluateJavascript(s, null); } });
        } });
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(false);
        w.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }
        });
        w.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                fcb = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
                startActivityForResult(i, 2);
                return true;
            }
        });
        w.addJavascriptInterface(new Object() {
            @JavascriptInterface public void save(final String name, String data) {
                pendData = data;
                runOnUiThread(new Runnable() { public void run() {
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*"); i.putExtra(Intent.EXTRA_TITLE, name);
                    startActivityForResult(i, 1);
                } });
            }
            @JavascriptInterface public String sfGet(String k) { return sf.get(k); }
            @JavascriptInterface public void sfConfig(String d, String c) { sf.config(d, c); }
            @JavascriptInterface public void sfLogin() { try { sf.login(); } catch (Exception e) { sf.status("Login error: " + e.getMessage()); } }
            @JavascriptInterface public void sfSync() { sf.cycle(); }
            @JavascriptInterface public void queueTag(int s, String np, String op, double t) {
                try { sf.enqueue(s, np, op, (long) t); sf.cycle(); } catch (Exception e) { }
            }
        }, "Android");
        w.loadUrl("https://appassets.androidplatform.net/assets/index.html");
        handle(getIntent());
    }

    void handle(Intent i) {
        Uri u = i == null ? null : i.getData();
        if (u != null && "oauth".equals(u.getHost())) sf.redirect(u);
    }
    @Override protected void onNewIntent(Intent i) { super.onNewIntent(i); handle(i); }
    @Override protected void onResume() { super.onResume(); h.postDelayed(tick, 1500); }
    @Override protected void onPause() { super.onPause(); h.removeCallbacks(tick); }

    @Override protected void onActivityResult(int rq, int rs, Intent d) {
        if (rq == 1 && rs == RESULT_OK && d != null && pendData != null) {
            try (OutputStream o = getContentResolver().openOutputStream(d.getData())) {
                o.write(pendData.getBytes(StandardCharsets.UTF_8));
            } catch (Exception e) { }
        }
        if (rq == 2 && fcb != null) {
            fcb.onReceiveValue(rs == RESULT_OK && d != null && d.getData() != null ? new Uri[]{d.getData()} : null);
            fcb = null;
        }
    }
}
