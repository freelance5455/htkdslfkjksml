package com.ggtouch.freefire;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
