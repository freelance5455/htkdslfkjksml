package com.vishal.tools.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp
import com.vishal.tools.tools.rememberBatteryInfo
import com.vishal.tools.ui.components.AppCard
import com.vishal.tools.ui.components.IconBadge
import com.vishal.tools.ui.components.InfoRow
import com.vishal.tools.ui.components.ScreenHeader
import com.vishal.tools.ui.theme.VtMuted
import com.vishal.tools.ui.theme.VtOnBackground
import com.vishal.tools.ui.theme.VtPrimary
import com.vishal.tools.ui.theme.VtWarning

@Composable
fun BatteryScreen(onBack: () -> Unit) {
    val battery = rememberBatteryInfo()
    val percentLabel = if (battery.percent >= 0) "${battery.percent}%" else "—"
    val progress = (battery.percent.coerceIn(0, 100)) / 100f

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(bottom = 28.dp)
    ) {
        ScreenHeader(
            title = "Battery Info",
            subtitle = "Live reading from this phone. Nothing is stored or sent.",
            onBack = onBack
        )
        Spacer(Modifier.height(22.dp))

        AppCard {
            IconBadge(color = if (battery.isCharging) VtWarning else VtPrimary) {
                Icon(
                    imageVector = Icons.Filled.BatteryChargingFull,
                    contentDescription = null,
                    tint = if (battery.isCharging) VtWarning else VtPrimary
                )
            }
            Spacer(Modifier.height(16.dp))
            Text(text = percentLabel, color = VtOnBackground, style = MaterialTheme.typography.displaySmall)
            Text(
                text = if (battery.isCharging) "Charging" else "Not charging",
                color = if (battery.isCharging) VtWarning else VtMuted
            )
            Spacer(Modifier.height(16.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(RoundedCornerShape(20.dp)),
                color = if (battery.isCharging) VtWarning else VtPrimary,
                trackColor = VtPrimary.copy(alpha = 0.16f),
                strokeCap = StrokeCap.Round
            )
        }

        Spacer(Modifier.height(14.dp))
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            InfoRow("Status", battery.statusLabel)
            InfoRow("Power source", battery.pluggedLabel)
            InfoRow("Health", battery.healthLabel)
            battery.temperatureC?.let {
                InfoRow("Temperature", String.format("%.1f °C", it))
            }
            battery.voltageMv?.let {
                InfoRow("Voltage", "$it mV")
            }
        }
    }
}
