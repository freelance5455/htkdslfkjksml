package com.vishal.tools.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.vishal.tools.tools.readDeviceInfo
import com.vishal.tools.ui.components.AppCard
import com.vishal.tools.ui.components.IconBadge
import com.vishal.tools.ui.components.InfoRow
import com.vishal.tools.ui.components.ScreenHeader
import com.vishal.tools.ui.theme.VtMuted
import com.vishal.tools.ui.theme.VtOnBackground

@Composable
fun DeviceScreen(onBack: () -> Unit) {
    val device = remember { readDeviceInfo() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(bottom = 28.dp)
    ) {
        ScreenHeader(
            title = "Device Info",
            subtitle = "Hardware and Android version reported by the system.",
            onBack = onBack
        )
        Spacer(Modifier.height(22.dp))

        AppCard {
            IconBadge(color = Color(0xFFC4B5FD)) {
                Icon(Icons.Filled.Smartphone, contentDescription = null, tint = Color(0xFFC4B5FD))
            }
            Spacer(Modifier.height(16.dp))
            Text(text = device.model, color = VtOnBackground, style = MaterialTheme.typography.headlineMedium)
            Text(text = device.manufacturer, color = VtMuted)
        }

        Spacer(Modifier.height(14.dp))
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            InfoRow("Device model", device.model)
            InfoRow("Manufacturer", device.manufacturer)
            InfoRow("Brand", device.brand)
            InfoRow("Android version", device.androidVersion)
            InfoRow("SDK version", device.sdk.toString())
            InfoRow("Device", device.device)
            InfoRow("Product", device.product)
            InfoRow("Hardware", device.hardware)
        }
    }
}
