package com.vishal.tools.tools

import android.content.Context
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager

/**
 * Turns the camera torch on/off. Safe on phones that have no flash:
 * [hasFlashlight] is false and [setEnabled] becomes a no-op.
 */
class FlashlightController(context: Context) {
    private val appContext = context.applicationContext
    private val cameraManager =
        appContext.getSystemService(Context.CAMERA_SERVICE) as CameraManager

    val hasFlashlight: Boolean =
        appContext.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH)

    private val torchCameraId: String? = findTorchCameraId()

    var isOn: Boolean = false
        private set

    fun setEnabled(on: Boolean): FlashResult {
        if (!hasFlashlight || torchCameraId == null) {
            isOn = false
            return FlashResult.Unavailable
        }
        return try {
            cameraManager.setTorchMode(torchCameraId, on)
            isOn = on
            if (on) FlashResult.On else FlashResult.Off
        } catch (se: SecurityException) {
            isOn = false
            FlashResult.NeedsPermission
        } catch (ex: Exception) {
            isOn = false
            FlashResult.Error(ex.message ?: "Could not control the flashlight")
        }
    }

    fun release() {
        if (isOn) {
            setEnabled(false)
        }
    }

    private fun findTorchCameraId(): String? {
        if (!hasFlashlight) return null
        return try {
            cameraManager.cameraIdList.firstOrNull { id ->
                val chars = cameraManager.getCameraCharacteristics(id)
                val hasFlash = chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                val facing = chars.get(CameraCharacteristics.LENS_FACING)
                hasFlash && facing == CameraCharacteristics.LENS_FACING_BACK
            } ?: cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
        } catch (_: Exception) {
            null
        }
    }
}

sealed class FlashResult {
    data object On : FlashResult()
    data object Off : FlashResult()
    data object Unavailable : FlashResult()
    data object NeedsPermission : FlashResult()
    data class Error(val message: String) : FlashResult()
}
