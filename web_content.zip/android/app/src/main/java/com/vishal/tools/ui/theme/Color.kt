package com.vishal.tools.ui.theme

import androidx.compose.ui.graphics.Color

val VtBackground = Color(0xFF07090C)
val VtSurface = Color(0xFF12161C)
val VtElevated = Color(0xFF1A212B)
val VtOnBackground = Color(0xFFF1F5F9)
val VtMuted = Color(0xFF8B98A8)
val VtPrimary = Color(0xFF2EE6A6)
val VtPrimaryDim = Color(0xFF1A9E72)
val VtBorder = Color(0xFF2A323C)
val VtDanger = Color(0xFFFF6B6B)
val VtWarning = Color(0xFFF5C14A)
