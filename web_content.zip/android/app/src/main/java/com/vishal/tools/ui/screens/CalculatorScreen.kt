package com.vishal.tools.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vishal.tools.ui.components.ScreenHeader
import com.vishal.tools.ui.theme.VtDanger
import com.vishal.tools.ui.theme.VtElevated
import com.vishal.tools.ui.theme.VtMuted
import com.vishal.tools.ui.theme.VtOnBackground
import com.vishal.tools.ui.theme.VtPrimary
import com.vishal.tools.ui.theme.VtSurface
import java.math.BigDecimal
import java.math.RoundingMode

private enum class Op { Add, Sub, Mul, Div }

private data class CalcState(
    val display: String = "0",
    val acc: BigDecimal? = null,
    val op: Op? = null,
    val fresh: Boolean = true,
    val error: String? = null
)

@Composable
fun CalculatorScreen(onBack: () -> Unit) {
    var state by remember { mutableStateOf(CalcState()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(bottom = 28.dp)
    ) {
        ScreenHeader(
            title = "Calculator",
            subtitle = "Basic arithmetic. Works fully offline.",
            onBack = onBack
        )
        Spacer(Modifier.height(22.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(VtSurface)
                .padding(horizontal = 18.dp, vertical = 22.dp),
            contentAlignment = Alignment.CenterEnd
        ) {
            Column(horizontalAlignment = Alignment.End, modifier = Modifier.fillMaxWidth()) {
                if (state.error != null) {
                    Text(text = state.error!!, color = VtDanger, style = MaterialTheme.typography.bodyMedium)
                }
                Text(
                    text = state.display,
                    color = VtOnBackground,
                    style = MaterialTheme.typography.displaySmall.copy(fontSize = 40.sp),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.End,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            CalcRow(listOf("C", "÷", "×", "⌫"), state) { state = it }
            CalcRow(listOf("7", "8", "9", "−"), state) { state = it }
            CalcRow(listOf("4", "5", "6", "+"), state) { state = it }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                listOf("1", "2", "3").forEach { key ->
                    CalcKey(key, Modifier.weight(1f), state) { state = it }
                }
                CalcKey("=", Modifier.weight(1f), state, accent = true) { state = it }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                CalcKey("0", Modifier.weight(2f).height(64.dp), state) { state = it }
                CalcKey(".", Modifier.weight(1f), state) { state = it }
            }
        }
    }
}

@Composable
private fun CalcRow(
    keys: List<String>,
    state: CalcState,
    onChange: (CalcState) -> Unit
) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        keys.forEach { key ->
            CalcKey(
                label = key,
                modifier = Modifier.weight(1f),
                state = state,
                accent = key == "=",
                onChange = onChange
            )
        }
    }
}

@Composable
private fun CalcKey(
    label: String,
    modifier: Modifier,
    state: CalcState,
    accent: Boolean = false,
    onChange: (CalcState) -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by androidx.compose.animation.core.animateFloatAsState(
        if (pressed) 0.96f else 1f,
        label = "key"
    )
    val background = when {
        accent -> VtPrimary
        label in listOf("÷", "×", "−", "+", "C", "⌫") -> VtElevated
        else -> VtSurface
    }
    val foreground = when {
        accent -> Color(0xFF07090C)
        label == "C" -> VtDanger
        label in listOf("÷", "×", "−", "+", "⌫") -> VtPrimary
        else -> VtOnBackground
    }

    Box(
        modifier = modifier
            .then(if (label != "0") Modifier.aspectRatio(1.15f) else Modifier)
            .scale(scale)
            .clip(RoundedCornerShape(18.dp))
            .background(background)
            .clickable(interactionSource = interaction, indication = null) {
                onChange(reduce(state, label))
            },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = foreground,
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(vertical = 8.dp)
        )
    }
}

private fun reduce(state: CalcState, key: String): CalcState {
    if (state.error != null && key != "C") {
        return reduce(CalcState(), key)
    }
    return when (key) {
        "C" -> CalcState()
        "⌫" -> backspace(state)
        "." -> decimal(state)
        "+", "−", "×", "÷" -> setOp(state, opFrom(key))
        "=" -> equals(state)
        else -> digit(state, key)
    }
}

private fun opFrom(key: String): Op = when (key) {
    "+" -> Op.Add
    "−" -> Op.Sub
    "×" -> Op.Mul
    else -> Op.Div
}

private fun digit(state: CalcState, d: String): CalcState {
    val next = if (state.fresh || state.display == "0") d else state.display + d
    if (next.replace(".", "").length > 12) return state
    return state.copy(display = next, fresh = false, error = null)
}

private fun decimal(state: CalcState): CalcState {
    if (state.fresh) return state.copy(display = "0.", fresh = false)
    if (state.display.contains(".")) return state
    return state.copy(display = state.display + ".", fresh = false)
}

private fun backspace(state: CalcState): CalcState {
    if (state.fresh) return state.copy(display = "0", fresh = true)
    val next = state.display.dropLast(1)
    return if (next.isEmpty() || next == "-") state.copy(display = "0", fresh = true)
    else state.copy(display = next)
}

private fun setOp(state: CalcState, op: Op): CalcState {
    val current = parse(state.display) ?: return state.copy(error = "Invalid number")
    val acc = if (state.acc != null && state.op != null && !state.fresh) {
        compute(state.acc, current, state.op) ?: return state.copy(error = "Cannot divide by zero")
    } else current
    return state.copy(acc = acc, op = op, display = format(acc), fresh = true)
}

private fun equals(state: CalcState): CalcState {
    val op = state.op ?: return state
    val acc = state.acc ?: return state
    val current = parse(state.display) ?: return state.copy(error = "Invalid number")
    val result = compute(acc, current, op) ?: return state.copy(error = "Cannot divide by zero")
    return CalcState(display = format(result), acc = result, op = null, fresh = true)
}

private fun compute(a: BigDecimal, b: BigDecimal, op: Op): BigDecimal? = when (op) {
    Op.Add -> a.add(b)
    Op.Sub -> a.subtract(b)
    Op.Mul -> a.multiply(b)
    Op.Div -> if (b.compareTo(BigDecimal.ZERO) == 0) null else a.divide(b, 10, RoundingMode.HALF_UP)
}

private fun parse(text: String): BigDecimal? = runCatching { BigDecimal(text) }.getOrNull()

private fun format(value: BigDecimal): String {
    val stripped = value.stripTrailingZeros()
    val plain = stripped.toPlainString()
    return if (plain.length > 14) stripped.setScale(8, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()
    else plain
}
