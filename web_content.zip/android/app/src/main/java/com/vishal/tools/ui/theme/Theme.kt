package com.vishal.tools.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val VtDarkColors = darkColorScheme(
    primary = VtPrimary,
    onPrimary = VtBackground,
    secondary = VtPrimaryDim,
    background = VtBackground,
    onBackground = VtOnBackground,
    surface = VtSurface,
    onSurface = VtOnBackground,
    surfaceVariant = VtElevated,
    onSurfaceVariant = VtMuted,
    outline = VtBorder,
    error = VtDanger,
    onError = VtOnBackground
)

@Composable
fun VishalToolsTheme(content: @Composable () -> Unit) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? android.app.Activity)?.window ?: return@SideEffect
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
        }
    }

    MaterialTheme(
        colorScheme = VtDarkColors,
        typography = VtTypography,
        content = content
    )
}
