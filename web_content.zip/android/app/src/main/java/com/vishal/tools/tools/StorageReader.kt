package com.vishal.tools.tools

import android.os.Environment
import android.os.StatFs

data class StorageInfo(
    val totalBytes: Long,
    val freeBytes: Long,
    val usedBytes: Long
) {
    val usedFraction: Float
        get() = if (totalBytes <= 0L) 0f else (usedBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f)
}

fun readInternalStorage(): StorageInfo {
    val stat = StatFs(Environment.getDataDirectory().absolutePath)
    val total = stat.totalBytes
    val free = stat.availableBytes
    return StorageInfo(
        totalBytes = total,
        freeBytes = free,
        usedBytes = (total - free).coerceAtLeast(0L)
    )
}

fun formatBytes(bytes: Long): String {
    if (bytes < 0) return "—"
    val kb = 1024.0
    val mb = kb * 1024
    val gb = mb * 1024
    return when {
        bytes >= gb -> String.format("%.2f GB", bytes / gb)
        bytes >= mb -> String.format("%.2f MB", bytes / mb)
        bytes >= kb -> String.format("%.1f KB", bytes / kb)
        else -> "$bytes B"
    }
}
