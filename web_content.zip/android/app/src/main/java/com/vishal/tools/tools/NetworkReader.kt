package com.vishal.tools.tools

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext

data class NetworkInfo(
    val isOnline: Boolean,
    val typeLabel: String,
    val typeDetail: String,
    val isValidated: Boolean,
    val isMetered: Boolean
)

fun readNetwork(context: Context): NetworkInfo {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val network = cm.activeNetwork
    val caps = network?.let { cm.getNetworkCapabilities(it) }
    if (network == null || caps == null) {
        return NetworkInfo(
            isOnline = false,
            typeLabel = "Offline",
            typeDetail = "No active network connection",
            isValidated = false,
            isMetered = false
        )
    }

    val type = when {
        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile data"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_BLUETOOTH) -> "Bluetooth"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN"
        else -> "Connected"
    }

    val validated = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    val internet = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    val metered = !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
    val detail = buildString {
        append(if (internet) "Internet capable" else "No internet capability")
        if (validated) append(" · Validated")
        if (metered) append(" · Metered")
    }

    return NetworkInfo(
        isOnline = internet,
        typeLabel = type,
        typeDetail = detail,
        isValidated = validated,
        isMetered = metered
    )
}

@Composable
fun rememberNetworkInfo(): NetworkInfo {
    val context = LocalContext.current
    var info by remember { mutableStateOf(readNetwork(context)) }

    DisposableEffect(context) {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                info = readNetwork(context)
            }

            override fun onLost(network: Network) {
                info = readNetwork(context)
            }

            override fun onCapabilitiesChanged(
                network: Network,
                networkCapabilities: NetworkCapabilities
            ) {
                info = readNetwork(context)
            }
        }
        cm.registerDefaultNetworkCallback(callback)
        onDispose {
            runCatching { cm.unregisterNetworkCallback(callback) }
        }
    }
    return info
}
