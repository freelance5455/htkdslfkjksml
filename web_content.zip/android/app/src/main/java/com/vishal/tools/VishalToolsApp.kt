package com.vishal.tools

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.vishal.tools.ui.screens.BatteryScreen
import com.vishal.tools.ui.screens.CalculatorScreen
import com.vishal.tools.ui.screens.DashboardScreen
import com.vishal.tools.ui.screens.DeviceScreen
import com.vishal.tools.ui.screens.FlashlightScreen
import com.vishal.tools.ui.screens.NetworkScreen
import com.vishal.tools.ui.screens.StorageScreen
import com.vishal.tools.ui.theme.VtBackground

@Composable
fun VishalToolsApp() {
    val navController = rememberNavController()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(VtBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(top = 12.dp)
    ) {
        NavHost(
            navController = navController,
            startDestination = "dashboard",
            modifier = Modifier.fillMaxSize()
        ) {
            composable("dashboard") {
                DashboardScreen(onOpen = { route -> navController.navigate(route) })
            }
            composable("battery") {
                BatteryScreen(onBack = { navController.popBackStack() })
            }
            composable("storage") {
                StorageScreen(onBack = { navController.popBackStack() })
            }
            composable("device") {
                DeviceScreen(onBack = { navController.popBackStack() })
            }
            composable("calculator") {
                CalculatorScreen(onBack = { navController.popBackStack() })
            }
            composable("flashlight") {
                FlashlightScreen(onBack = { navController.popBackStack() })
            }
            composable("network") {
                NetworkScreen(onBack = { navController.popBackStack() })
            }
        }
    }
}
