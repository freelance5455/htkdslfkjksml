package com.vishal.tools.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.vishal.tools.tools.rememberNetworkInfo
import com.vishal.tools.ui.components.AppCard
import com.vishal.tools.ui.components.IconBadge
import com.vishal.tools.ui.components.InfoRow
import com.vishal.tools.ui.components.ScreenHeader
import com.vishal.tools.ui.theme.VtDanger
import com.vishal.tools.ui.theme.VtMuted
import com.vishal.tools.ui.theme.VtOnBackground
import com.vishal.tools.ui.theme.VtPrimary

@Composable
fun NetworkScreen(onBack: () -> Unit) {
    val network = rememberNetworkInfo()
    val tint = if (network.isOnline) Color(0xFF5EEAD4) else VtDanger

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(bottom = 28.dp)
    ) {
        ScreenHeader(
            title = "Network Info",
            subtitle = "Connection type only. No personal data is collected.",
            onBack = onBack
        )
        Spacer(Modifier.height(22.dp))

        AppCard {
            IconBadge(color = tint) {
                Icon(
                    imageVector = if (network.isOnline) Icons.Filled.Wifi else Icons.Filled.WifiOff,
                    contentDescription = null,
                    tint = tint
                )
            }
            Spacer(Modifier.height(16.dp))
            Text(
                text = if (network.isOnline) "Connected" else "Offline",
                color = VtOnBackground,
                style = MaterialTheme.typography.displaySmall
            )
            Text(text = network.typeLabel, color = if (network.isOnline) VtPrimary else VtMuted)
        }

        Spacer(Modifier.height(14.dp))
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            InfoRow("Status", if (network.isOnline) "Online" else "Offline")
            InfoRow("Connection type", network.typeLabel)
            InfoRow("Details", network.typeDetail)
            InfoRow("Validated", if (network.isValidated) "Yes" else "No")
            InfoRow("Metered", if (network.isMetered) "Yes" else "No")
        }
    }
}
