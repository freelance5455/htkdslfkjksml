package com.vishal.tools.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.vishal.tools.ui.components.AppCard
import com.vishal.tools.ui.components.IconBadge
import com.vishal.tools.ui.theme.VtMuted
import com.vishal.tools.ui.theme.VtOnBackground
import com.vishal.tools.ui.theme.VtPrimary

data class ToolItem(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val tint: Color,
    val route: String
)

private val tools = listOf(
    ToolItem("Battery Info", "Level, charging, health", Icons.Filled.BatteryChargingFull, Color(0xFF2EE6A6), "battery"),
    ToolItem("Storage Info", "Used, free, and total", Icons.Filled.Storage, Color(0xFF7AD3FF), "storage"),
    ToolItem("Device Info", "Model, Android, SDK", Icons.Filled.Smartphone, Color(0xFFC4B5FD), "device"),
    ToolItem("Calculator", "Add, subtract, multiply, divide", Icons.Filled.Calculate, Color(0xFFF5C14A), "calculator"),
    ToolItem("Flashlight", "Turn the torch on or off", Icons.Filled.FlashlightOn, Color(0xFFFFE08A), "flashlight"),
    ToolItem("Network Info", "Wi-Fi or mobile status", Icons.Filled.Wifi, Color(0xFF5EEAD4), "network")
)

@Composable
fun DashboardScreen(onOpen: (String) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(bottom = 28.dp)
    ) {
        Text(
            text = "Vishal Tools",
            color = VtOnBackground,
            style = MaterialTheme.typography.displaySmall
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = "Offline utilities for your phone. Nothing is uploaded.",
            color = VtMuted,
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(Modifier.height(22.dp))

        tools.chunked(2).forEach { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                row.forEach { tool ->
                    ToolCard(
                        tool = tool,
                        modifier = Modifier.weight(1f),
                        onClick = { onOpen(tool.route) }
                    )
                }
                if (row.size == 1) {
                    Spacer(Modifier.weight(1f))
                }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun ToolCard(
    tool: ToolItem,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    AppCard(modifier = modifier.height(168.dp), onClick = onClick) {
        IconBadge(color = tool.tint) {
            Icon(tool.icon, contentDescription = tool.title, tint = tool.tint)
        }
        Spacer(Modifier.height(16.dp))
        Text(text = tool.title, color = VtOnBackground, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(4.dp))
        Text(text = tool.subtitle, color = VtMuted, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.weight(1f))
        Text(
            text = "Open",
            color = VtPrimary,
            style = MaterialTheme.typography.labelLarge,
            modifier = Modifier.align(Alignment.Start)
        )
    }
}
