package com.vishal.tools.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.dp
import com.vishal.tools.tools.formatBytes
import com.vishal.tools.tools.readInternalStorage
import com.vishal.tools.ui.components.AppCard
import com.vishal.tools.ui.components.IconBadge
import com.vishal.tools.ui.components.InfoRow
import com.vishal.tools.ui.components.ScreenHeader
import com.vishal.tools.ui.theme.VtMuted
import com.vishal.tools.ui.theme.VtOnBackground
import com.vishal.tools.ui.theme.VtPrimary

@Composable
fun StorageScreen(onBack: () -> Unit) {
    val storage = remember { readInternalStorage() }
    val usedPct = (storage.usedFraction * 100).toInt()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(bottom = 28.dp)
    ) {
        ScreenHeader(
            title = "Storage Info",
            subtitle = "Internal storage on this device. No files are read.",
            onBack = onBack
        )
        Spacer(Modifier.height(22.dp))

        AppCard {
            IconBadge(color = Color(0xFF7AD3FF)) {
                Icon(Icons.Filled.Storage, contentDescription = null, tint = Color(0xFF7AD3FF))
            }
            Spacer(Modifier.height(16.dp))
            Text(
                text = "$usedPct% used",
                color = VtOnBackground,
                style = MaterialTheme.typography.displaySmall
            )
            Text(text = "${formatBytes(storage.freeBytes)} free", color = VtMuted)
            Spacer(Modifier.height(16.dp))
            LinearProgressIndicator(
                progress = { storage.usedFraction },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(RoundedCornerShape(20.dp)),
                color = VtPrimary,
                trackColor = VtPrimary.copy(alpha = 0.16f),
                strokeCap = StrokeCap.Round
            )
        }

        Spacer(Modifier.height(14.dp))
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            InfoRow("Total storage", formatBytes(storage.totalBytes))
            InfoRow("Used storage", formatBytes(storage.usedBytes))
            InfoRow("Free storage", formatBytes(storage.freeBytes))
        }
    }
}
