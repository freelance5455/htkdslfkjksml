package com.vishal.tools.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlashlightOff
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.vishal.tools.tools.FlashResult
import com.vishal.tools.tools.FlashlightController
import com.vishal.tools.ui.components.AppCard
import com.vishal.tools.ui.components.ScreenHeader
import com.vishal.tools.ui.theme.VtDanger
import com.vishal.tools.ui.theme.VtElevated
import com.vishal.tools.ui.theme.VtMuted
import com.vishal.tools.ui.theme.VtOnBackground
import com.vishal.tools.ui.theme.VtPrimary
import com.vishal.tools.ui.theme.VtWarning

@Composable
fun FlashlightScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val controller = remember { FlashlightController(context) }
    var isOn by remember { mutableStateOf(controller.isOn) }
    var message by remember { mutableStateOf<String?>(null) }

    DisposableEffect(controller) {
        onDispose { controller.release() }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            applyTorch(controller, true) { on, msg ->
                isOn = on
                message = msg
            }
        } else {
            message = "Camera permission is needed to use the flashlight."
        }
    }

    val hasPermission = ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.CAMERA
    ) == PackageManager.PERMISSION_GRANTED

    fun toggle() {
        if (!controller.hasFlashlight) {
            isOn = false
            message = "This phone does not have a flashlight."
            return
        }
        val wantOn = !isOn
        if (wantOn && !hasPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
            return
        }
        applyTorch(controller, wantOn) { on, msg ->
            isOn = on
            message = msg
        }
    }

    val glow by animateColorAsState(
        if (isOn) VtWarning.copy(alpha = 0.22f) else VtElevated,
        label = "glow"
    )
    val iconTint by animateColorAsState(if (isOn) VtWarning else VtMuted, label = "icon")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(bottom = 28.dp)
    ) {
        ScreenHeader(
            title = "Flashlight",
            subtitle = "Uses the camera LED. Safe if this phone has no flash.",
            onBack = onBack
        )
        Spacer(Modifier.height(28.dp))

        AppCard(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(168.dp)
                        .clip(CircleShape)
                        .background(glow)
                        .clickable { toggle() },
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(124.dp)
                            .clip(CircleShape)
                            .background(if (isOn) VtWarning else VtElevated),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isOn) Icons.Filled.FlashlightOn else Icons.Filled.FlashlightOff,
                            contentDescription = if (isOn) "Turn flashlight off" else "Turn flashlight on",
                            tint = if (isOn) VtOnBackground else iconTint,
                            modifier = Modifier.size(56.dp)
                        )
                    }
                }
                Spacer(Modifier.height(20.dp))
                Text(
                    text = when {
                        !controller.hasFlashlight -> "No flashlight"
                        isOn -> "Flashlight is ON"
                        else -> "Flashlight is OFF"
                    },
                    color = VtOnBackground,
                    style = MaterialTheme.typography.titleLarge
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = if (controller.hasFlashlight) "Tap the button to toggle" else "This device has no camera flash",
                    color = VtMuted
                )
                if (message != null) {
                    Spacer(Modifier.height(12.dp))
                    Text(text = message!!, color = if (isOn) VtPrimary else VtDanger)
                }
            }
        }
    }
}

private fun applyTorch(
    controller: FlashlightController,
    on: Boolean,
    done: (Boolean, String?) -> Unit
) {
    when (val result = controller.setEnabled(on)) {
        FlashResult.On -> done(true, null)
        FlashResult.Off -> done(false, null)
        FlashResult.Unavailable -> done(false, "This phone does not have a flashlight.")
        FlashResult.NeedsPermission -> done(false, "Camera permission is needed to use the flashlight.")
        is FlashResult.Error -> done(false, result.message)
    }
}
