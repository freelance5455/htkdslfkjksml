package com.vishal.tools.tools

import android.os.Build

data class DeviceInfo(
    val model: String,
    val manufacturer: String,
    val brand: String,
    val androidVersion: String,
    val sdk: Int,
    val device: String,
    val product: String,
    val hardware: String
)

fun readDeviceInfo(): DeviceInfo = DeviceInfo(
    model = Build.MODEL.ifBlank { "Unknown" },
    manufacturer = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }.ifBlank { "Unknown" },
    brand = Build.BRAND.replaceFirstChar { it.uppercase() }.ifBlank { "Unknown" },
    androidVersion = Build.VERSION.RELEASE.ifBlank { "Unknown" },
    sdk = Build.VERSION.SDK_INT,
    device = Build.DEVICE.ifBlank { "Unknown" },
    product = Build.PRODUCT.ifBlank { "Unknown" },
    hardware = Build.HARDWARE.ifBlank { "Unknown" }
)
