package com.unai.tim;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import androidx.documentfile.provider.DocumentFile;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;

/** SAF bridge for the bundled TiM SAFE test page. */
public final class TiMSafeStorageBridge {
    public static final int REQUEST_TREE = 7412;
    private static final String PREFS = "tim_safe_storage";
    private static final String TREE_URI = "tree_uri";
    private static final String SAFE_DIR = "UNAI_SAFE";
    private static final String FINAL_NAME = "UNAI_TIM_SAFE.timsafe";
    private static final String TEMP_NAME = ".UNAI_TIM_SAFE.tmp";
    private final MainActivity activity;

    TiMSafeStorageBridge(MainActivity activity) { this.activity = activity; }

    @JavascriptInterface public void selectSafeFolder() {
        activity.runOnUiThread(() -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            activity.startActivityForResult(intent, REQUEST_TREE);
        });
    }

    boolean onFolderResult(int resultCode, Intent data) {
        if (resultCode != Activity.RESULT_OK || data == null || data.getData() == null) return false;
        Uri uri = data.getData();
        int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try {
            activity.getContentResolver().takePersistableUriPermission(uri, flags);
            if (!isRemovableCardTree(uri)) return false;
            activity.getSharedPreferences(PREFS, 0).edit().putString(TREE_URI, uri.toString()).apply();
            return true;
        } catch (Exception e) { return false; }
    }

    @JavascriptInterface public String saveSafeFile(String fileName, String base64Data) {
        if (!FINAL_NAME.equals(fileName) || base64Data == null) return "ERROR_BAD_ARGUMENT";
        DocumentFile temp = null;
        try {
            Uri tree = getSavedTree();
            if (tree == null || !isRemovableCardTree(tree)) return "ERROR_NO_TFCARD_PERMISSION";
            byte[] bytes = Base64.decode(base64Data, Base64.DEFAULT);
            if (bytes.length == 0 || bytes.length > 2 * 1024 * 1024) return "ERROR_SIZE";

            DocumentFile root = DocumentFile.fromTreeUri(activity, tree);
            if (root == null || !root.isDirectory() || !root.canWrite()) return "ERROR_NO_WRITE_ACCESS";
            DocumentFile dir = root.findFile(SAFE_DIR);
            if (dir == null) dir = root.createDirectory(SAFE_DIR);
            if (dir == null || !dir.isDirectory() || !dir.canWrite()) return "ERROR_CREATE_SAFE_FOLDER";

            DocumentFile existing = dir.findFile(FINAL_NAME);
            temp = dir.findFile(TEMP_NAME);
            if (temp != null && !temp.delete()) return "ERROR_TEMP_CLEANUP";
            temp = dir.createFile("application/octet-stream", TEMP_NAME);
            if (temp == null) return "ERROR_TEMP_CREATE";
            try (OutputStream out = activity.getContentResolver().openOutputStream(temp.getUri(), "w")) {
                if (out == null) { temp.delete(); return "ERROR_WRITE"; }
                out.write(bytes); out.flush();
            }
            if (!java.util.Arrays.equals(bytes, readAll(temp.getUri()))) { temp.delete(); return "ERROR_VERIFY_TEMP"; }
            if (existing != null && !existing.delete()) { temp.delete(); return "ERROR_REPLACE"; }
            if (!temp.renameTo(FINAL_NAME)) return "ERROR_RENAME";
            DocumentFile saved = dir.findFile(FINAL_NAME);
            if (saved == null || !java.util.Arrays.equals(bytes, readAll(saved.getUri()))) return "ERROR_VERIFY_FINAL";
            return "OK";
        } catch (Exception e) {
            if (temp != null && temp.exists()) temp.delete();
            return "ERROR_IO";
        }
    }

    private Uri getSavedTree() {
        String value = activity.getSharedPreferences(PREFS, 0).getString(TREE_URI, null);
        return value == null ? null : Uri.parse(value);
    }

    private boolean isRemovableCardTree(Uri tree) {
        try {
            String docId = DocumentsContract.getTreeDocumentId(tree);
            int colon = docId.indexOf(':');
            if (colon <= 0) return false;
            String volume = docId.substring(0, colon);
            if ("primary".equalsIgnoreCase(volume)) return false;
            File[] dirs = activity.getExternalFilesDirs(null);
            for (File f : dirs) {
                if (f == null) continue;
                String path = f.getAbsolutePath();
                if (path.contains("/" + volume + "/Android/") && Environment.isExternalStorageRemovable(f)) return true;
            }
        } catch (Exception ignored) { }
        return false;
    }

    private byte[] readAll(Uri uri) throws Exception {
        try (InputStream in = activity.getContentResolver().openInputStream(uri);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            if (in == null) throw new Exception("read failed");
            byte[] buffer = new byte[8192]; int count;
            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            return out.toByteArray();
        }
    }
}
