package com.bao.looksmaxos;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
