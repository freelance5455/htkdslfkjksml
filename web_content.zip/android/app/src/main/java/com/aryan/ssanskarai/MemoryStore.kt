package com.aryan.ssanskarai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class MemoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("sanskar_memory", Context.MODE_PRIVATE)

    fun saveMessages(messages: List<ChatMessage>) {
        val array = JSONArray()
        messages.takeLast(80).forEach {
            array.put(JSONObject().apply {
                put("role", it.role)
                put("text", it.text)
                put("timestamp", it.timestamp)
            })
        }
        prefs.edit().putString("messages", array.toString()).apply()
    }

    fun loadMessages(): List<ChatMessage> {
        val raw = prefs.getString("messages", "[]") ?: "[]"
        val array = JSONArray(raw)
        return buildList {
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                add(ChatMessage(
                    role = o.optString("role"),
                    text = o.optString("text"),
                    timestamp = o.optLong("timestamp")
                ))
            }
        }
    }

    fun clear() {
        prefs.edit().clear().apply()
    }
}
