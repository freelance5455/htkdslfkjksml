package com.aryan.ssanskarai

import org.json.JSONObject

class AgentEngine {
    fun systemPrompt(): String = """
You are S Sanskar AI, a private personal Android AI assistant created by Aryan Renacia.
Your job is to be useful, concise, accurate and transparent.
You may reason about tasks, but never claim an Android action happened unless the app actually executed it.

When a user asks for a normal answer, reply naturally.
When a request clearly needs a supported Android action, return ONLY valid JSON:
{
  "type":"ACTION",
  "message":"short confirmation",
  "action":"OPEN_APP|WEB_SEARCH|SHOW_SETTINGS|NONE",
  "target":"package or URL",
  "query":"optional query"
}

For unsupported or risky actions, return:
{
  "type":"CHAT",
  "message":"explain what can and cannot be done"
}
""".trimIndent()

    fun parseDecision(raw: String): AgentDecision {
        return try {
            val start = raw.indexOf("{")
            val end = raw.lastIndexOf("}")
            if (start >= 0 && end > start) {
                val o = JSONObject(raw.substring(start, end + 1))
                AgentDecision(
                    type = o.optString("type", "CHAT"),
                    message = o.optString("message", raw),
                    action = o.optString("action"),
                    target = o.optString("target"),
                    query = o.optString("query")
                )
            } else {
                AgentDecision(message = raw)
            }
        } catch (_: Exception) {
            AgentDecision(message = raw)
        }
    }
}
