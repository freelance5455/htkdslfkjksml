package com.aryan.ssanskarai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {

    private lateinit var memory: MemoryStore
    private lateinit var voice: VoiceManager

    private val messages = mutableStateListOf<ChatMessage>()
    private var modelName by mutableStateOf("gemini-3.1-pro")
    private var showSettings by mutableStateOf(false)

    private val speechLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val text = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull().orEmpty()
            if (text.isNotBlank()) sendMessage(text)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        memory = MemoryStore(this)
        messages.addAll(memory.loadMessages())
        voice = VoiceManager(this) { sendMessage(it) }

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
        }

        setContent {
            SanskarTheme {
                if (showSettings) {
                    SettingsScreen(
                        model = modelName,
                        onModelChange = { modelName = it },
                        onBack = { showSettings = false },
                        onClearMemory = {
                            memory.clear()
                            messages.clear()
                        }
                    )
                } else {
                    ChatScreen(
                        messages = messages,
                        onSend = ::sendMessage,
                        onMic = { voice.startListening() },
                        onSettings = { showSettings = true }
                    )
                }
            }
        }
    }

    private fun sendMessage(text: String) {
        if (text.isBlank()) return

        messages.add(ChatMessage(role = "user", text = text))
        memory.saveMessages(messages)

        val apiKey = BuildConfig.GEMINI_API_KEY
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                try {
                    val client = GeminiClient(apiKey, modelName)
                    val raw = client.generate(
                        userText = text,
                        history = messages.dropLast(1),
                        systemInstruction = AgentEngine().systemPrompt()
                    )
                    AgentEngine().parseDecision(raw)
                } catch (e: Exception) {
                    AgentDecision(message = "Error: ${e.message ?: "Unknown error"}")
                }
            }

            messages.add(ChatMessage(role = "model", text = result.message))
            memory.saveMessages(messages)
            if (result.message.isNotBlank()) voice.speak(result.message)
        }
    }

    override fun onDestroy() {
        voice.release()
        super.onDestroy()
    }
}

@Composable
fun ChatScreen(
    messages: List<ChatMessage>,
    onSend: (String) -> Unit,
    onMic: () -> Unit,
    onSettings: () -> Unit
) {
    var input by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("S Sanskar AI", fontWeight = FontWeight.Bold)
                        Text("Created by Aryan Renacia", style = MaterialTheme.typography.labelSmall)
                    }
                },
                actions = {
                    IconButton(onClick = onSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(horizontal = 12.dp)
        ) {
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth(),
                reverseLayout = false,
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                items(messages, key = { it.id }) { message ->
                    MessageBubble(message)
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Ask S Sanskar AI...") },
                    shape = RoundedCornerShape(24.dp),
                    singleLine = true
                )
                IconButton(onClick = onMic) {
                    Icon(Icons.Default.Mic, contentDescription = "Voice")
                }
                IconButton(
                    onClick = {
                        val value = input.trim()
                        if (value.isNotEmpty()) {
                            input = ""
                            onSend(value)
                        }
                    }
                ) {
                    Icon(Icons.Default.Send, contentDescription = "Send")
                }
            }
        }
    }
}

@Composable
fun MessageBubble(message: ChatMessage) {
    val isUser = message.role == "user"
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = if (isUser) MaterialTheme.colorScheme.primaryContainer
                    else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.widthIn(max = 320.dp)
        ) {
            Text(
                text = message.text,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
            )
        }
    }
}

@Composable
fun SettingsScreen(
    model: String,
    onModelChange: (String) -> Unit,
    onBack: () -> Unit,
    onClearMemory: () -> Unit
) {
    var selected by remember(model) { mutableStateOf(model) }
    Column(
        Modifier.fillMaxSize().padding(20.dp)
    ) {
        Text("S Sanskar AI Settings", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(18.dp))
        Text("Gemini model")
        Spacer(Modifier.height(6.dp))

        listOf("gemini-3.1-pro", "gemini-3.6-flash", "gemini-3.5-flash-lite").forEach {
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(
                    selected = selected == it,
                    onClick = {
                        selected = it
                        onModelChange(it)
                    }
                )
                Text(it)
            }
        }

        Spacer(Modifier.height(20.dp))
        Text("API key is loaded from local.properties and is not displayed in the app source UI.")

        Spacer(Modifier.height(20.dp))
        Button(onClick = onClearMemory) {
            Text("Clear local memory")
        }

        Spacer(Modifier.weight(1f))
        OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) {
            Text("Back")
        }
    }
}

@Composable
fun SanskarTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Color(0xFF090A0F),
            surface = Color(0xFF11131A),
            surfaceVariant = Color(0xFF1A1D26)
        ),
        content = content
    )
}
