package com.aryan.ssanskarai

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

class GeminiClient(
    private val apiKey: String,
    private val model: String
) {
    private val http = OkHttpClient()
    private val jsonType = "application/json".toMediaType()

    fun generate(
        userText: String,
        history: List<ChatMessage>,
        systemInstruction: String
    ): String {
        require(apiKey.isNotBlank()) { "Gemini API key is missing. Add GEMINI_API_KEY to local.properties." }

        val contents = JSONArray()

        history.takeLast(20).forEach { message ->
            contents.put(JSONObject().apply {
                put("role", if (message.role == "user") "user" else "model")
                put("parts", JSONArray().put(JSONObject().put("text", message.text)))
            })
        }

        contents.put(JSONObject().apply {
            put("role", "user")
            put("parts", JSONArray().put(JSONObject().put("text", userText)))
        })

        val body = JSONObject().apply {
            put("systemInstruction", JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text", systemInstruction)))
            })
            put("contents", contents)
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.7)
                put("maxOutputTokens", 2048)
            })
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
        val request = Request.Builder()
            .url(url)
            .addHeader("x-goog-api-key", apiKey)
            .post(body.toString().toRequestBody(jsonType))
            .build()

        http.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw IllegalStateException("Gemini HTTP ${response.code}: $text")
            }

            val root = JSONObject(text)
            return root.optJSONArray("candidates")
                ?.optJSONObject(0)
                ?.optJSONObject("content")
                ?.optJSONArray("parts")
                ?.optJSONObject(0)
                ?.optString("text")
                ?: "I couldn't generate a response."
        }
    }
}
