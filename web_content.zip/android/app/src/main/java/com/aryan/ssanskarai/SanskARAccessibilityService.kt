package com.aryan.ssanskarai

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class SanskARAccessibilityService : AccessibilityService() {

    companion object {
        var instance: SanskARAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Reserved for the advanced agent layer.
        // The service is intentionally passive until an explicit supported action is requested.
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }
}
