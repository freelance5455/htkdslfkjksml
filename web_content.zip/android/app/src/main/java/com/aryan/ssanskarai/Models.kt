package com.aryan.ssanskarai

data class ChatMessage(
    val id: Long = System.nanoTime(),
    val role: String,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class AgentDecision(
    val type: String = "CHAT",
    val message: String = "",
    val action: String = "",
    val target: String = "",
    val query: String = ""
)
