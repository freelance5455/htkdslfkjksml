package com.arabic.crossword;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
