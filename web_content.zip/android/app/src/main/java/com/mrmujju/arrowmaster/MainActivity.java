package com.mrmujju.arrowmaster;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;
import com.mrmujju.arrowmaster.ads.ArrowMasterAdsPlugin;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(ArrowMasterAdsPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
