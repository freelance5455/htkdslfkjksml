package com.mrmujju.arrowmaster.ads;

import android.app.Activity;
import com.google.android.ump.ConsentInformation;
import com.google.android.ump.ConsentRequestParameters;
import com.google.android.ump.UserMessagingPlatform;

/**
 * Manages Google User Messaging Platform (UMP) consent gathering and privacy options.
 */
public final class ConsentManager {

    public interface ConsentCallback {
        void onComplete(boolean canRequestAds, boolean privacyOptionsRequired);
    }

    private ConsentInformation consentInformation;

    public boolean canRequestAds() {
        return consentInformation != null && consentInformation.canRequestAds();
    }

    public boolean isPrivacyOptionsRequired() {
        return consentInformation != null
                && consentInformation.getPrivacyOptionsRequirementStatus()
                        == ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED;
    }

    public void gatherConsent(Activity activity, ConsentCallback callback) {
        if (activity == null) {
            callback.onComplete(false, false);
            return;
        }

        ConsentRequestParameters params = new ConsentRequestParameters.Builder()
                .setTagForUnderAgeOfConsent(false)
                .build();

        consentInformation = UserMessagingPlatform.getConsentInformation(activity);
        consentInformation.requestConsentInfoUpdate(
                activity,
                params,
                () -> UserMessagingPlatform.loadAndShowConsentFormIfRequired(
                        activity,
                        loadAndShowError -> callback.onComplete(canRequestAds(), isPrivacyOptionsRequired())
                ),
                requestConsentError -> callback.onComplete(canRequestAds(), isPrivacyOptionsRequired())
        );
    }

    public void showPrivacyOptionsForm(Activity activity, ConsentCallback callback) {
        if (activity == null) {
            callback.onComplete(canRequestAds(), isPrivacyOptionsRequired());
            return;
        }
        UserMessagingPlatform.showPrivacyOptionsForm(
                activity,
                formError -> callback.onComplete(canRequestAds(), isPrivacyOptionsRequired())
        );
    }
}
