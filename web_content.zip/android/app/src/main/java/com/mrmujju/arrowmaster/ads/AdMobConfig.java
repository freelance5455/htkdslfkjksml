package com.mrmujju.arrowmaster.ads;

/**
 * Centralized Google AdMob unit configuration for Android.
 * Test IDs and Production IDs are strictly separated.
 */
public final class AdMobConfig {
    private AdMobConfig() {}

    // Official Google AdMob Android Test Ad Unit IDs
    public static final String TEST_APP_OPEN_AD_UNIT_ID = "ca-app-pub-3940256099942544/9257395921";
    public static final String TEST_REWARDED_AD_UNIT_ID = "ca-app-pub-3940256099942544/5224354917";

    // Production AdMob Ad Unit IDs placeholder — replace before Google Play release
    public static final String PROD_APP_OPEN_AD_UNIT_ID = "ca-app-pub-XXXXXXXXXXXXXXXX/AAAAAAAAAA";
    public static final String PROD_REWARDED_AD_UNIT_ID = "ca-app-pub-XXXXXXXXXXXXXXXX/BBBBBBBBBB";

    private volatile boolean useProduction = false;
    private volatile String appOpenAdUnitId = TEST_APP_OPEN_AD_UNIT_ID;
    private volatile String rewardedAdUnitId = TEST_REWARDED_AD_UNIT_ID;

    public void configure(String environment, String customAppOpenId, String customRewardedId) {
        this.useProduction = "production".equalsIgnoreCase(environment);
        if (this.useProduction) {
            this.appOpenAdUnitId = (customAppOpenId != null && !customAppOpenId.isEmpty())
                    ? customAppOpenId
                    : PROD_APP_OPEN_AD_UNIT_ID;
            this.rewardedAdUnitId = (customRewardedId != null && !customRewardedId.isEmpty())
                    ? customRewardedId
                    : PROD_REWARDED_AD_UNIT_ID;
        } else {
            this.appOpenAdUnitId = TEST_APP_OPEN_AD_UNIT_ID;
            this.rewardedAdUnitId = TEST_REWARDED_AD_UNIT_ID;
        }
    }

    public boolean isUseProduction() {
        return useProduction;
    }

    public String getAppOpenAdUnitId() {
        return appOpenAdUnitId;
    }

    public String getRewardedAdUnitId() {
        return rewardedAdUnitId;
    }
}
