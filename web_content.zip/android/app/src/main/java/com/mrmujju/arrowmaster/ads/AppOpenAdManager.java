package com.mrmujju.arrowmaster.ads;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import androidx.annotation.NonNull;
import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.ProcessLifecycleOwner;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.appopen.AppOpenAd;
import java.util.Date;

/**
 * Manages AdMob App Open Ads: preloading, 4-hour expiry validation, cooldown & session gating,
 * gameplay interruption protection, and optional foreground-resume presentation.
 */
public final class AppOpenAdManager implements DefaultLifecycleObserver {

    public interface ShowCallback {
        void onComplete(boolean shown, String reason);
    }

    private static final long FOUR_HOURS_MS = 4L * 3600L * 1000L;
    private static final String PREFS_NAME = "arrow_master_native_ads";
    private static final String KEY_LAST_APP_OPEN_MS = "last_app_open_ms";

    private final Context appContext;
    private final AdMobConfig config;
    private final ConsentManager consentManager;

    private AppOpenAd appOpenAd = null;
    private boolean isLoadingAd = false;
    private boolean isShowingAd = false;
    private long loadTimeMs = 0L;

    private volatile boolean isGameplayActive = false;
    private volatile Activity currentActivity = null;
    private volatile int cachedLaunchCount = 0;
    private volatile int minSessionsBeforeAppOpen = 3;
    private volatile long cooldownMs = 4L * 60L * 1000L;
    private boolean lifecycleRegistered = false;

    public AppOpenAdManager(Context appContext, AdMobConfig config, ConsentManager consentManager) {
        this.appContext = appContext.getApplicationContext();
        this.config = config;
        this.consentManager = consentManager;
    }

    public void attachLifecycleObserver() {
        if (!lifecycleRegistered) {
            lifecycleRegistered = true;
            ProcessLifecycleOwner.get().getLifecycle().addObserver(this);
        }
    }

    public void setCurrentActivity(Activity activity) {
        this.currentActivity = activity;
    }

    public void setGameplayActive(boolean active) {
        this.isGameplayActive = active;
    }

    public void updatePolicy(int launchCount, int minSessions, long cooldownMs) {
        this.cachedLaunchCount = launchCount;
        this.minSessionsBeforeAppOpen = minSessions;
        this.cooldownMs = cooldownMs;
    }

    private long getLastShownMs() {
        SharedPreferences prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getLong(KEY_LAST_APP_OPEN_MS, 0L);
    }

    private void saveLastShownMs(long nowMs) {
        SharedPreferences prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putLong(KEY_LAST_APP_OPEN_MS, nowMs).apply();
    }

    private boolean wasLoadTimeLessThanNHoursAgo() {
        long dateDifference = (new Date()).getTime() - this.loadTimeMs;
        return dateDifference < FOUR_HOURS_MS;
    }

    public boolean isAdAvailable() {
        return appOpenAd != null && wasLoadTimeLessThanNHoursAgo();
    }

    public void preloadAd() {
        if (!consentManager.canRequestAds() || isLoadingAd || isAdAvailable()) {
            return;
        }
        isLoadingAd = true;
        AdRequest request = new AdRequest.Builder().build();
        AppOpenAd.load(
                appContext,
                config.getAppOpenAdUnitId(),
                request,
                new AppOpenAd.AppOpenAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull AppOpenAd ad) {
                        appOpenAd = ad;
                        isLoadingAd = false;
                        loadTimeMs = (new Date()).getTime();
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        isLoadingAd = false;
                        appOpenAd = null;
                    }
                }
        );
    }

    public void showIfAvailable(
            Activity activity,
            int launchCount,
            long jsLastShownAt,
            int minSessions,
            long policyCooldownMs,
            ShowCallback callback
    ) {
        updatePolicy(launchCount, minSessions, policyCooldownMs);

        if (activity == null || activity.isFinishing()) {
            callback.onComplete(false, "no_activity");
            return;
        }
        if (isShowingAd) {
            callback.onComplete(false, "already_showing");
            return;
        }
        if (isGameplayActive) {
            callback.onComplete(false, "gameplay_active");
            return;
        }
        if (!consentManager.canRequestAds()) {
            callback.onComplete(false, "consent_not_ready");
            return;
        }
        if (launchCount < minSessions) {
            callback.onComplete(false, "below_min_sessions");
            return;
        }

        long now = System.currentTimeMillis();
        long effectiveLastShown = Math.max(getLastShownMs(), jsLastShownAt);
        if (effectiveLastShown > 0 && (now - effectiveLastShown) < policyCooldownMs) {
            callback.onComplete(false, "cooldown_active");
            return;
        }

        if (!isAdAvailable()) {
            preloadAd();
            callback.onComplete(false, "not_ready");
            return;
        }

        final AppOpenAd adToShow = appOpenAd;
        appOpenAd = null;
        isShowingAd = true;

        adToShow.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override
            public void onAdDismissedFullScreenContent() {
                isShowingAd = false;
                saveLastShownMs(System.currentTimeMillis());
                preloadAd();
                callback.onComplete(true, "dismissed");
            }

            @Override
            public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                isShowingAd = false;
                preloadAd();
                callback.onComplete(false, "show_failed");
            }

            @Override
            public void onAdShowedFullScreenContent() {
                saveLastShownMs(System.currentTimeMillis());
            }
        });

        adToShow.show(activity);
    }

    @Override
    public void onStart(@NonNull LifecycleOwner owner) {
        // Warm resume from background: never interrupt active gameplay
        if (isGameplayActive || currentActivity == null || isShowingAd) {
            return;
        }
        if (!isAdAvailable()) {
            preloadAd();
            return;
        }
        showIfAvailable(
                currentActivity,
                cachedLaunchCount,
                getLastShownMs(),
                minSessionsBeforeAppOpen,
                cooldownMs,
                (shown, reason) -> {}
        );
    }
}
