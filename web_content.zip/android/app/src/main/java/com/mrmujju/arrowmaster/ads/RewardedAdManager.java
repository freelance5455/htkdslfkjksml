package com.mrmujju.arrowmaster.ads;

import android.app.Activity;
import android.content.Context;
import androidx.annotation.NonNull;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

/**
 * Manages AdMob Rewarded Video Ads for Extra Hearts.
 * Strictly awards 1 heart ONLY when Google Mobile Ads OnUserEarnedRewardListener fires.
 */
public final class RewardedAdManager {

    public interface RewardCallback {
        void onResult(String status, int rewardAmount, String message);
    }

    private final Context appContext;
    private final AdMobConfig config;
    private final ConsentManager consentManager;

    private RewardedAd rewardedAd = null;
    private boolean isLoading = false;
    private boolean isShowing = false;

    public RewardedAdManager(Context appContext, AdMobConfig config, ConsentManager consentManager) {
        this.appContext = appContext.getApplicationContext();
        this.config = config;
        this.consentManager = consentManager;
    }

    public boolean isAdLoaded() {
        return rewardedAd != null;
    }

    public void preloadAd() {
        if (!consentManager.canRequestAds() || isLoading || rewardedAd != null) {
            return;
        }
        isLoading = true;
        AdRequest request = new AdRequest.Builder().build();
        RewardedAd.load(
                appContext,
                config.getRewardedAdUnitId(),
                request,
                new RewardedAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull RewardedAd ad) {
                        rewardedAd = ad;
                        isLoading = false;
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        rewardedAd = null;
                        isLoading = false;
                    }
                }
        );
    }

    public void showRewardedAd(Activity activity, RewardCallback callback) {
        if (activity == null || activity.isFinishing()) {
            callback.onResult("unavailable", 0, "Activity is unavailable.");
            return;
        }
        if (isShowing) {
            callback.onResult("failed", 0, "An ad is already open.");
            return;
        }
        if (!consentManager.canRequestAds()) {
            callback.onResult("unavailable", 0, "Consent is required to load video ads.");
            return;
        }

        if (rewardedAd != null) {
            final RewardedAd readyAd = rewardedAd;
            rewardedAd = null;
            presentLoadedAd(activity, readyAd, callback);
            return;
        }

        if (isLoading) {
            // Avoid parallel duplicate load calls; tell UI cleanly to retry if still buffering
            callback.onResult("unavailable", 0, "Video ad is still loading. Please tap WATCH AD again in a moment.");
            return;
        }

        isLoading = true;
        AdRequest request = new AdRequest.Builder().build();
        RewardedAd.load(
                appContext,
                config.getRewardedAdUnitId(),
                request,
                new RewardedAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull RewardedAd ad) {
                        isLoading = false;
                        presentLoadedAd(activity, ad, callback);
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        isLoading = false;
                        rewardedAd = null;
                        callback.onResult("failed", 0, "Video ad failed to load. Please check your connection and try again.");
                    }
                }
        );
    }

    private void presentLoadedAd(Activity activity, RewardedAd adToShow, RewardCallback callback) {
        if (activity == null || activity.isFinishing()) {
            callback.onResult("unavailable", 0, "Activity is unavailable.");
            return;
        }

        isShowing = true;
        final boolean[] rewardEarned = { false };
        final boolean[] callbackDelivered = { false };

        adToShow.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override
            public void onAdDismissedFullScreenContent() {
                isShowing = false;
                preloadAd();
                if (!callbackDelivered[0]) {
                    callbackDelivered[0] = true;
                    if (rewardEarned[0]) {
                        callback.onResult("rewarded", 1, null);
                    } else {
                        callback.onResult(
                                "dismissed_without_reward",
                                0,
                                "Watch the full video ad to receive 1 extra heart."
                        );
                    }
                }
            }

            @Override
            public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                isShowing = false;
                preloadAd();
                if (!callbackDelivered[0]) {
                    callbackDelivered[0] = true;
                    callback.onResult("failed", 0, "Could not display video ad. Please try again.");
                }
            }
        });

        adToShow.show(activity, rewardItem -> {
            // Official Google AdMob reward callback — ONLY place rewardEarned becomes true.
            rewardEarned[0] = true;
        });
    }
}
