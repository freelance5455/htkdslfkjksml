package com.mrmujju.arrowmaster.ads;

import android.app.Activity;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.google.android.gms.ads.MobileAds;

@CapacitorPlugin(name = "ArrowMasterAds")
public class ArrowMasterAdsPlugin extends Plugin {

    private AdMobConfig config;
    private ConsentManager consentManager;
    private AppOpenAdManager appOpenAdManager;
    private RewardedAdManager rewardedAdManager;
    private volatile boolean mobileAdsInitialized = false;

    @Override
    public void load() {
        super.load();
        config = new AdMobConfig();
        consentManager = new ConsentManager();
        appOpenAdManager = new AppOpenAdManager(getContext(), config, consentManager);
        rewardedAdManager = new RewardedAdManager(getContext(), config, consentManager);

        getActivity().runOnUiThread(() -> {
            appOpenAdManager.setCurrentActivity(getActivity());
            appOpenAdManager.attachLifecycleObserver();
        });
    }

    @Override
    protected void handleOnResume() {
        super.handleOnResume();
        if (appOpenAdManager != null) {
            appOpenAdManager.setCurrentActivity(getActivity());
        }
    }

    private void ensureMobileAdsInitialized() {
        if (mobileAdsInitialized || !consentManager.canRequestAds()) {
            return;
        }
        mobileAdsInitialized = true;
        MobileAds.initialize(getContext(), initializationStatus -> {
            appOpenAdManager.preloadAd();
            rewardedAdManager.preloadAd();
        });
    }

    @PluginMethod
    public void initialize(PluginCall call) {
        String environment = call.getString("environment", "test");
        String appOpenId = call.getString("appOpenAdUnitId", AdMobConfig.TEST_APP_OPEN_AD_UNIT_ID);
        String rewardedId = call.getString("rewardedAdUnitId", AdMobConfig.TEST_REWARDED_AD_UNIT_ID);
        int minSessions = call.getInt("minSessionsBeforeAppOpen", 3);
        long cooldownMs = call.getLong("appOpenCooldownMs", 240000L);

        config.configure(environment, appOpenId, rewardedId);
        appOpenAdManager.updatePolicy(0, minSessions, cooldownMs);

        Activity activity = getActivity();
        if (activity == null) {
            JSObject ret = new JSObject();
            ret.put("canRequestAds", false);
            ret.put("privacyOptionsRequired", false);
            call.resolve(ret);
            return;
        }

        activity.runOnUiThread(() -> {
            appOpenAdManager.setCurrentActivity(activity);
            consentManager.gatherConsent(activity, (canRequestAds, privacyRequired) -> {
                if (canRequestAds) {
                    ensureMobileAdsInitialized();
                }
                JSObject ret = new JSObject();
                ret.put("canRequestAds", canRequestAds);
                ret.put("privacyOptionsRequired", privacyRequired);
                call.resolve(ret);
            });
        });
    }

    @PluginMethod
    public void setGameplayActive(PluginCall call) {
        boolean active = Boolean.TRUE.equals(call.getBoolean("active", false));
        if (appOpenAdManager != null) {
            appOpenAdManager.setGameplayActive(active);
        }
        call.resolve();
    }

    @PluginMethod
    public void isAppOpenAdReady(PluginCall call) {
        Activity activity = getActivity();
        if (activity == null) {
            JSObject ret = new JSObject();
            ret.put("ready", false);
            call.resolve(ret);
            return;
        }
        activity.runOnUiThread(() -> {
            JSObject ret = new JSObject();
            ret.put("ready", appOpenAdManager != null && appOpenAdManager.isAdAvailable());
            call.resolve(ret);
        });
    }

    @PluginMethod
    public void showAppOpenIfReady(PluginCall call) {
        int launchCount = call.getInt("launchCount", 0);
        long lastShownAt = call.getLong("lastShownAt", 0L);
        int minSessions = call.getInt("minSessions", 3);
        long cooldownMs = call.getLong("cooldownMs", 240000L);

        Activity activity = getActivity();
        if (activity == null) {
            JSObject ret = new JSObject();
            ret.put("shown", false);
            ret.put("reason", "no_activity");
            call.resolve(ret);
            return;
        }

        activity.runOnUiThread(() -> appOpenAdManager.showIfAvailable(
                activity,
                launchCount,
                lastShownAt,
                minSessions,
                cooldownMs,
                (shown, reason) -> {
                    JSObject ret = new JSObject();
                    ret.put("shown", shown);
                    ret.put("reason", reason);
                    call.resolve(ret);
                }
        ));
    }

    @PluginMethod
    public void preloadRewardedAd(PluginCall call) {
        Activity activity = getActivity();
        if (activity == null) {
            JSObject ret = new JSObject();
            ret.put("loaded", false);
            call.resolve(ret);
            return;
        }
        activity.runOnUiThread(() -> {
            ensureMobileAdsInitialized();
            rewardedAdManager.preloadAd();
            JSObject ret = new JSObject();
            ret.put("loaded", rewardedAdManager.isAdLoaded());
            call.resolve(ret);
        });
    }

    @PluginMethod
    public void showRewardedAd(PluginCall call) {
        Activity activity = getActivity();
        if (activity == null) {
            JSObject ret = new JSObject();
            ret.put("status", "unavailable");
            ret.put("rewardAmount", 0);
            ret.put("message", "Activity unavailable.");
            call.resolve(ret);
            return;
        }

        activity.runOnUiThread(() -> {
            ensureMobileAdsInitialized();
            rewardedAdManager.showRewardedAd(activity, (status, rewardAmount, message) -> {
                JSObject ret = new JSObject();
                ret.put("status", status);
                ret.put("rewardAmount", rewardAmount);
                if (message != null) {
                    ret.put("message", message);
                }
                call.resolve(ret);
            });
        });
    }

    @PluginMethod
    public void getConsentStatus(PluginCall call) {
        JSObject ret = new JSObject();
        ret.put("canRequestAds", consentManager != null && consentManager.canRequestAds());
        ret.put("privacyOptionsRequired", consentManager != null && consentManager.isPrivacyOptionsRequired());
        call.resolve(ret);
    }

    @PluginMethod
    public void openPrivacyOptions(PluginCall call) {
        Activity activity = getActivity();
        if (activity == null) {
            JSObject ret = new JSObject();
            ret.put("canRequestAds", consentManager != null && consentManager.canRequestAds());
            ret.put("privacyOptionsRequired", false);
            call.resolve(ret);
            return;
        }

        activity.runOnUiThread(() -> consentManager.showPrivacyOptionsForm(
                activity,
                (canRequestAds, privacyRequired) -> {
                    if (canRequestAds) {
                        ensureMobileAdsInitialized();
                    }
                    JSObject ret = new JSObject();
                    ret.put("canRequestAds", canRequestAds);
                    ret.put("privacyOptionsRequired", privacyRequired);
                    call.resolve(ret);
                }
        ));
    }
}
