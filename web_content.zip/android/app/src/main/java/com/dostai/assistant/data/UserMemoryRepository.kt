package com.dostai.assistant.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

data class AndroidUserMemory(
    val id: String = System.currentTimeMillis().toString(),
    val category: String, // Routine, Preference, Goal, Work, Personal
    val fact: String,
    val learnedAt: Long = System.currentTimeMillis()
)

class UserMemoryRepository(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("dost_user_mind_prefs", Context.MODE_PRIVATE)

    fun getAllMemories(): List<AndroidUserMemory> {
        val raw = prefs.getString("memories_json", "[]") ?: "[]"
        val list = mutableListOf<AndroidUserMemory>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    AndroidUserMemory(
                        id = obj.getString("id"),
                        category = obj.getString("category"),
                        fact = obj.getString("fact"),
                        learnedAt = obj.getLong("learnedAt")
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    fun saveMemory(category: String, fact: String) {
        val current = getAllMemories().toMutableList()
        current.add(0, AndroidUserMemory(category = category, fact = fact))
        persist(current)
    }

    fun deleteMemory(id: String) {
        val current = getAllMemories().filter { it.id != id }
        persist(current)
    }

    private fun persist(list: List<AndroidUserMemory>) {
        val arr = JSONArray()
        list.forEach { mem ->
            val obj = JSONObject().apply {
                put("id", mem.id)
                put("category", mem.category)
                put("fact", mem.fact)
                put("learnedAt", mem.learnedAt)
            }
            arr.put(obj)
        }
        prefs.edit().putString("memories_json", arr.toString()).apply()
    }
}
