package com.dostai.assistant.services

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent

/**
 * DostAccessibilityService
 *
 * CRITICAL SECURITY ARCHITECTURE:
 * 1. This service ONLY acts with explicit user permission in Android Accessibility Settings.
 * 2. It NEVER reads passwords, sensitive PINs, lockscreen states, or biometric prompts.
 * 3. It assists only with authorized accessibility notifications and assistive spoken prompts.
 */
class DostAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "DostAccessibility"
        var isServiceRunning = false
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        isServiceRunning = true
        Log.i(TAG, "DOST Accessibility Service connected with user authorization.")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        // Security boundary: ignore any password fields or secure inputs
        if (event.isPassword) {
            return
        }

        when (event.eventType) {
            AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED -> {
                val notificationText = event.text.joinToString(" ")
                Log.d(TAG, "Authorized notification event observed: $notificationText")
            }
            else -> {
                // No arbitrary interaction
            }
        }
    }

    override fun onInterrupt() {
        Log.w(TAG, "Accessibility Service interrupted by Android system.")
    }

    override fun onDestroy() {
        super.onDestroy()
        isServiceRunning = false
    }
}
