package com.dostai.assistant.ai

import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import com.google.ai.client.generativeai.type.generationConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

data class ActionProposal(
    val type: String,
    val target: String = "",
    val recipient: String = "",
    val message: String = "",
    val label: String = "",
    val isSensitive: Boolean = false
)

data class BrainResponse(
    val replyText: String,
    val actionProposal: ActionProposal? = null,
    val isError: Boolean = false
)

class GeminiBrain(
    private val apiKey: String
) {
    private val model: GenerativeModel by lazy {
        GenerativeModel(
            modelName = "gemini-1.5-flash", // Compatible model mapping for Android SDK
            apiKey = apiKey,
            generationConfig = generationConfig {
                temperature = 0.7f
                topK = 40
                topP = 0.95f
            },
            systemInstruction = content {
                text(
                    """
                    You are DOST AI, an advanced, highly loyal, and practical personal Android AI agent.
                    Languages supported: Roman Urdu, Urdu (اردو), and English.
                    
                    When user asks for an action (e.g. open camera, play youtube, send SMS, set alarm, analyze crypto):
                    Provide your conversational answer first, and if an action can be performed on the phone, append:
                    [ACTION_PROPOSAL]
                    {
                      "type": "open_app | send_sms | set_alarm | analyze_crypto",
                      "target": "camera | youtube | chrome | settings | messages",
                      "recipient": "+123456789",
                      "message": "...",
                      "label": "Open YouTube",
                      "isSensitive": false
                    }
                    [/ACTION_PROPOSAL]
                    
                    Always treat sending SMS and phone calls as sensitive actions requiring confirmation.
                    Never claim you can bypass lockscreens or security passwords.
                    """.trimIndent()
                )
            }
        )
    }

    suspend fun sendMessage(
        history: List<Pair<String, String>>,
        userMessage: String
    ): BrainResponse = withContext(Dispatchers.IO) {
        try {
            // Build conversation history contents
            val chat = model.startChat(
                history = history.map { (role, text) ->
                    content(role = if (role == "user") "user" else "model") {
                        text(text)
                    }
                }
            )

            val response = chat.sendMessage(userMessage)
            val fullText = response.text ?: "Dost tayyar hai. Main aap ki kya madad karoon?"

            var cleanReply = fullText
            var actionProposal: ActionProposal? = null

            val pattern = "\\[ACTION_PROPOSAL\\]([\\s\\S]*?)\\[/ACTION_PROPOSAL\\]".toRegex()
            val match = pattern.find(fullText)
            if (match != null) {
                val jsonStr = match.groupValues[1].trim()
                cleanReply = fullText.replace(match.value, "").trim()
                try {
                    val json = JSONObject(jsonStr)
                    actionProposal = ActionProposal(
                        type = json.optString("type"),
                        target = json.optString("target"),
                        recipient = json.optString("recipient"),
                        message = json.optString("message"),
                        label = json.optString("label", "Execute Action"),
                        isSensitive = json.optBoolean("isSensitive", false)
                    )
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            BrainResponse(replyText = cleanReply, actionProposal = actionProposal)
        } catch (e: Exception) {
            e.printStackTrace()
            BrainResponse(
                replyText = "Dost AI error: " + (e.localizedMessage ?: "Internet connection ya API quota check karein."),
                isError = true
            )
        }
    }
}
