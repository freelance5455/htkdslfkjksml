package com.dostai.assistant.crypto

import kotlin.math.abs
import kotlin.math.max

data class TechnicalIndicators(
    val latestClose: Double,
    val ema9: Double,
    val ema20: Double,
    val ema200: Double,
    val atr14: Double,
    val support: Double,
    val resistance: Double,
    val liquidityHigh: Double,
    val liquidityLow: Double,
    val trend: String
)

data class PaperTrade(
    val id: String = System.currentTimeMillis().toString(),
    val symbol: String,
    val type: String, // "BUY" / "SELL"
    val entryPrice: Double,
    val amountUsdt: Double,
    val stopLoss: Double,
    val takeProfit: Double,
    val openTime: Long = System.currentTimeMillis(),
    var status: String = "OPEN", // "OPEN", "CLOSED"
    var exitPrice: Double? = null,
    var pnlUsdt: Double? = null
)

class TechnicalAnalysisEngine {

    fun calculateIndicators(candles: List<List<Any>>): TechnicalIndicators? {
        if (candles.isEmpty()) return null

        val closes = candles.map { (it[4] as String).toDouble() }
        val highs = candles.map { (it[2] as String).toDouble() }
        val lows = candles.map { (it[3] as String).toDouble() }

        val latestClose = closes.last()
        val ema9 = calcEMA(closes, 9).last() ?: latestClose
        val ema20 = calcEMA(closes, 20).last() ?: latestClose
        val ema200 = calcEMA(closes, minOf(closes.size, 50)).last() ?: latestClose

        val atr14 = calcATR(highs, lows, closes, 14)

        val recentHighs = highs.takeLast(30)
        val recentLows = lows.takeLast(30)
        val resistance = recentHighs.maxOrNull() ?: latestClose
        val support = recentLows.minOrNull() ?: latestClose

        val liquidityHigh = resistance * 1.002
        val liquidityLow = support * 0.998

        val trend = when {
            latestClose > ema9 && ema9 > ema20 -> "Bullish Momentum"
            latestClose < ema9 && ema9 < ema20 -> "Bearish Pressure"
            else -> "Consolidation / Range"
        }

        return TechnicalIndicators(
            latestClose = latestClose,
            ema9 = ema9,
            ema20 = ema20,
            ema200 = ema200,
            atr14 = atr14,
            support = support,
            resistance = resistance,
            liquidityHigh = liquidityHigh,
            liquidityLow = liquidityLow,
            trend = trend
        )
    }

    private fun calcEMA(data: List<Double>, period: Int): List<Double?> {
        val result = mutableListOf<Double?>()
        if (data.size < period) {
            return data.map { null }
        }
        val k = 2.0 / (period + 1)
        val initialSma = data.take(period).sum() / period
        for (i in 0 until period - 1) result.add(null)
        result.add(initialSma)

        var currentEma = initialSma
        for (i in period until data.size) {
            currentEma = data[i] * k + currentEma * (1 - k)
            result.add(currentEma)
        }
        return result
    }

    private fun calcATR(highs: List<Double>, lows: List<Double>, closes: List<Double>, period: Int = 14): Double {
        if (highs.size < period + 1) return 0.0
        val trs = mutableListOf<Double>()
        for (i in 1 until highs.size) {
            val tr = max(
                highs[i] - lows[i],
                max(
                    abs(highs[i] - closes[i - 1]),
                    abs(lows[i] - closes[i - 1])
                )
            )
            trs.add(tr)
        }
        val recent = trs.takeLast(period)
        return recent.sum() / period
    }
}
