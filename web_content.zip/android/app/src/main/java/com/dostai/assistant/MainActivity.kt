package com.dostai.assistant

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.dostai.assistant.ai.GeminiBrain
import com.dostai.assistant.crypto.BinanceClient
import com.dostai.assistant.crypto.TechnicalAnalysisEngine
import com.dostai.assistant.intents.AndroidActionEngine
import com.dostai.assistant.services.DostForegroundService
import com.dostai.assistant.ui.theme.DarkBackground
import com.dostai.assistant.ui.theme.DostAITheme
import com.dostai.assistant.ui.theme.PrimaryCyan
import com.dostai.assistant.voice.DostSpeechManager
import com.dostai.assistant.voice.VoiceState

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    object Home : Screen("home", "Home", Icons.Default.Home)
    object Chat : Screen("chat", "Chat", Icons.Default.Chat)
    object Voice : Screen("voice", "Voice", Icons.Default.Mic)
    object PhoneTools : Screen("tools", "Tools", Icons.Default.PhoneAndroid)
    object Crypto : Screen("crypto", "Crypto", Icons.Default.TrendingUp)
    object Settings : Screen("settings", "Settings", Icons.Default.Settings)
}

class MainActivity : ComponentActivity() {

    private lateinit var actionEngine: AndroidActionEngine
    private lateinit var speechManager: DostSpeechManager
    private lateinit var geminiBrain: GeminiBrain
    private val cryptoEngine = TechnicalAnalysisEngine()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val recordAudioGranted = permissions[Manifest.permission.RECORD_AUDIO] ?: false
        if (recordAudioGranted) {
            Toast.makeText(this, "Microphone permission granted", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        actionEngine = AndroidActionEngine(this)
        geminiBrain = GeminiBrain(BuildConfig.GEMINI_API_KEY)

        // Request runtime permissions on Android 13+
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        permissionLauncher.launch(perms.toTypedArray())

        setContent {
            DostAITheme {
                MainAppScaffold(
                    actionEngine = actionEngine,
                    geminiBrain = geminiBrain,
                    cryptoEngine = cryptoEngine,
                    onToggleForegroundService = { start ->
                        val serviceIntent = Intent(this, DostForegroundService::class.java).apply {
                            action = if (start) DostForegroundService.ACTION_START else DostForegroundService.ACTION_STOP
                        }
                        if (start) {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                startForegroundService(serviceIntent)
                            } else {
                                startService(serviceIntent)
                            }
                        } else {
                            startService(serviceIntent)
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun MainAppScaffold(
    actionEngine: AndroidActionEngine,
    geminiBrain: GeminiBrain,
    cryptoEngine: TechnicalAnalysisEngine,
    onToggleForegroundService: (Boolean) -> Unit
) {
    var selectedScreen by remember { mutableStateOf<Screen>(Screen.Home) }
    var isForegroundActive by remember { mutableStateOf(false) }

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                val screens = listOf(
                    Screen.Home,
                    Screen.Chat,
                    Screen.Voice,
                    Screen.PhoneTools,
                    Screen.Crypto,
                    Screen.Settings
                )
                screens.forEach { screen ->
                    NavigationBarItem(
                        icon = { Icon(screen.icon, contentDescription = screen.title) },
                        label = { Text(screen.title) },
                        selected = selectedScreen == screen,
                        onClick = { selectedScreen = screen },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = PrimaryCyan,
                            selectedTextColor = PrimaryCyan,
                            indicatorColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(DarkBackground)
                .padding(innerPadding)
        ) {
            when (selectedScreen) {
                Screen.Home -> HomeScreen(
                    onNavigate = { selectedScreen = it },
                    isForegroundActive = isForegroundActive,
                    onToggleService = {
                        isForegroundActive = !isForegroundActive
                        onToggleForegroundService(isForegroundActive)
                    }
                )
                Screen.Chat -> NativeChatScreen(geminiBrain = geminiBrain, actionEngine = actionEngine)
                Screen.Voice -> NativeVoiceScreen(geminiBrain = geminiBrain, actionEngine = actionEngine)
                Screen.PhoneTools -> NativePhoneToolsScreen(actionEngine = actionEngine)
                Screen.Crypto -> NativeCryptoScreen(cryptoEngine = cryptoEngine)
                Screen.Settings -> NativeSettingsScreen(
                    isForegroundActive = isForegroundActive,
                    onToggleService = {
                        isForegroundActive = !isForegroundActive
                        onToggleForegroundService(isForegroundActive)
                    }
                )
            }
        }
    }
}

@Composable
fun HomeScreen(
    onNavigate: (Screen) -> Unit,
    isForegroundActive: Boolean,
    onToggleService: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "DOST AI",
            style = MaterialTheme.typography.headlineLarge,
            color = PrimaryCyan
        )
        Text(
            text = "Aap ka personal Android assistant",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Quick status card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Background Service", style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (isForegroundActive) "Active (Persistent Notification)" else "Inactive (Tap to keep Dost ready)",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (isForegroundActive) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
                Switch(checked = isForegroundActive, onCheckedChange = { onToggleService() })
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Quick action tiles
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { onNavigate(Screen.Voice) },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryCyan)
            ) {
                Icon(Icons.Default.Mic, contentDescription = null)
                Spacer(modifier = Modifier.width(4.dp))
                Text("Bolo")
            }
            Button(
                onClick = { onNavigate(Screen.Chat) },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Icon(Icons.Default.Chat, contentDescription = null)
                Spacer(modifier = Modifier.width(4.dp))
                Text("Chat")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = { onNavigate(Screen.Crypto) },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Icon(Icons.Default.TrendingUp, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Binance Crypto Analysis & Demo Trades")
        }
    }
}

// Basic Compose Screen placeholders for Android Native Studio project
@Composable
fun NativeChatScreen(geminiBrain: GeminiBrain, actionEngine: AndroidActionEngine) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("DOST AI Chat", style = MaterialTheme.typography.titleLarge, color = PrimaryCyan)
        Text("Multi-turn conversation with Roman Urdu, Urdu, and English capability.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun NativeVoiceScreen(geminiBrain: GeminiBrain, actionEngine: AndroidActionEngine) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Push-To-Talk Voice Assistant", style = MaterialTheme.typography.titleLarge, color = PrimaryCyan)
        Text("Speech recognition and text-to-speech engine with Android microphone permissions.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun NativePhoneToolsScreen(actionEngine: AndroidActionEngine) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Phone Tools & Intent Dispatcher", style = MaterialTheme.typography.titleLarge, color = PrimaryCyan)
        Text("Safe Android Intent launchers with strict allowlist and user confirmation for SMS/Calls.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun NativeCryptoScreen(cryptoEngine: TechnicalAnalysisEngine) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Crypto Trading Assistant", style = MaterialTheme.typography.titleLarge, color = PrimaryCyan)
        Text("Binance public market feed, EMA 9/20/200, ATR, and Paper trading demo simulator.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun NativeSettingsScreen(isForegroundActive: Boolean, onToggleService: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("DOST AI Settings & Security", style = MaterialTheme.typography.titleLarge, color = PrimaryCyan)
        Text("Configure API keys, permissions, privacy, and background availability.", style = MaterialTheme.typography.bodySmall)
    }
}
