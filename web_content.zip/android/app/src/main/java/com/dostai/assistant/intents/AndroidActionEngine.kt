package com.dostai.assistant.intents

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast

sealed class ActionResult {
    data class Success(val message: String) : ActionResult()
    data class Failure(val reason: String) : ActionResult()
    data class RequiresConfirmation(val title: String, val message: String, val execute: () -> ActionResult) : ActionResult()
}

class AndroidActionEngine(private val context: Context) {

    // Strict allowlist of safe system apps & approved intents
    private val appAllowlist = mapOf(
        "camera" to "android.media.action.IMAGE_CAPTURE",
        "youtube" to "com.google.android.youtube",
        "chrome" to "com.android.chrome",
        "settings" to Settings.ACTION_SETTINGS,
        "messages" to "android.intent.action.MAIN",
        "whatsapp" to "com.whatsapp",
        "maps" to "com.google.android.apps.maps"
    )

    fun openApp(target: String): ActionResult {
        val normalized = target.lowercase().trim()
        
        return try {
            when (normalized) {
                "camera" -> {
                    val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                    ActionResult.Success("Camera opened successfully")
                }
                "settings" -> {
                    val intent = Intent(Settings.ACTION_SETTINGS).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                    ActionResult.Success("Phone Settings opened")
                }
                "youtube" -> {
                    launchPackageOrWeb("com.google.android.youtube", "https://youtube.com")
                }
                "chrome" -> {
                    launchPackageOrWeb("com.android.chrome", "https://google.com")
                }
                "whatsapp" -> {
                    launchPackageOrWeb("com.whatsapp", "https://whatsapp.com")
                }
                else -> {
                    // Try package manager with strict sanity check
                    val pm = context.packageManager
                    val launchIntent = pm.getLaunchIntentForPackage(normalized)
                    if (launchIntent != null) {
                        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(launchIntent)
                        ActionResult.Success("Opened $normalized")
                    } else {
                        ActionResult.Failure("App '$target' is not in allowlist or not installed on this device.")
                    }
                }
            }
        } catch (e: Exception) {
            ActionResult.Failure("Failed to open $target: ${e.localizedMessage}")
        }
    }

    private fun launchPackageOrWeb(packageName: String, fallbackUrl: String): ActionResult {
        val pm = context.packageManager
        val intent = pm.getLaunchIntentForPackage(packageName)
        return if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            ActionResult.Success("App opened: $packageName")
        } else {
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(fallbackUrl)).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(webIntent)
            ActionResult.Success("Opened in browser: $fallbackUrl")
        }
    }

    fun prepareSms(recipient: String, message: String): ActionResult {
        // Sensitive action: Prompt confirmation first before sending
        return ActionResult.RequiresConfirmation(
            title = "Confirm SMS",
            message = "Send SMS to '$recipient' with content:\n\"$message\"?",
            execute = {
                try {
                    val intent = Intent(Intent.ACTION_SENDTO).apply {
                        data = Uri.parse("smsto:$recipient")
                        putExtra("sms_body", message)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                    ActionResult.Success("SMS composer opened for $recipient")
                } catch (e: Exception) {
                    ActionResult.Failure("SMS failed: ${e.localizedMessage}")
                }
            }
        )
    }

    fun setAlarm(hour: Int, minute: Int, message: String = "DOST AI Alarm"): ActionResult {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
                putExtra(AlarmClock.EXTRA_MESSAGE, message)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            ActionResult.Success("Alarm set for %02d:%02d".format(hour, minute))
        } catch (e: Exception) {
            ActionResult.Failure("Could not set alarm: ${e.localizedMessage}")
        }
    }

    fun dialNumber(phoneNumber: String): ActionResult {
        return ActionResult.RequiresConfirmation(
            title = "Confirm Phone Call",
            message = "Prepare phone dialer for '$phoneNumber'?",
            execute = {
                try {
                    val intent = Intent(Intent.ACTION_DIAL).apply {
                        data = Uri.parse("tel:$phoneNumber")
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                    ActionResult.Success("Dialer opened with $phoneNumber")
                } catch (e: Exception) {
                    ActionResult.Failure("Could not dial: ${e.localizedMessage}")
                }
            }
        )
    }
}
