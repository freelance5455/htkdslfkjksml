package com.dostai.assistant.crypto

import com.google.gson.annotations.SerializedName
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

data class BinanceTicker24hr(
    val symbol: String,
    val lastPrice: String,
    val priceChangePercent: String,
    val highPrice: String,
    val lowPrice: String,
    val quoteVolume: String
)

interface BinanceApiService {
    @GET("api/v3/ticker/24hr")
    suspend fun get24hrTickers(): List<BinanceTicker24hr>

    @GET("api/v3/klines")
    suspend fun getKlines(
        @Query("symbol") symbol: String,
        @Query("interval") interval: String, // 5m, 15m, 1h, 4h
        @Query("limit") limit: Int = 100
    ): List<List<Any>>
}

object BinanceClient {
    private const val BASE_URL = "https://api.binance.com/"

    val api: BinanceApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(BinanceApiService::class.java)
    }
}
