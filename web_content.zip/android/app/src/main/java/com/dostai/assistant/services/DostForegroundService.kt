package com.dostai.assistant.services

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.dostai.assistant.DostApplication
import com.dostai.assistant.MainActivity

class DostForegroundService : Service() {

    companion object {
        const val ACTION_START = "ACTION_START_DOST_SERVICE"
        const val ACTION_STOP = "ACTION_STOP_DOST_SERVICE"
        const val ACTION_TALK = "ACTION_QUICK_TALK"
        const val ACTION_CRYPTO = "ACTION_QUICK_CRYPTO"
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                startDostNotification()
            }
            else -> {
                startDostNotification()
            }
        }
        // START_STICKY asks Android to recreate service if killed by low memory pressure
        return START_STICKY
    }

    private fun startDostNotification() {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Quick action: Voice talk
        val talkIntent = Intent(this, MainActivity::class.java).apply {
            putExtra("EXTRA_START_TAB", "voice")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val talkPendingIntent = PendingIntent.getActivity(
            this, 1, talkIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Quick action: Crypto scan
        val cryptoIntent = Intent(this, MainActivity::class.java).apply {
            putExtra("EXTRA_START_TAB", "crypto")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val cryptoPendingIntent = PendingIntent.getActivity(
            this, 2, cryptoIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Stop Service action
        val stopIntent = Intent(this, DostForegroundService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 3, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, DostApplication.CHANNEL_ID)
            .setContentTitle("DOST AI is Active")
            .setContentText("Aap ka personal agent background mein tayyar hai")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(openPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(android.R.drawable.ic_btn_speak_now, "Talk", talkPendingIntent)
            .addAction(android.R.drawable.ic_menu_agenda, "Crypto", cryptoPendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPendingIntent)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Android 14 requires specifying foregroundServiceType
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    DostApplication.NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(DostApplication.NOTIFICATION_ID, notification)
            }
        } else {
            startForeground(DostApplication.NOTIFICATION_ID, notification)
        }
    }
}
