package com.getmoneymachine

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.datastore.preferences.core.edit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import java.time.Instant
import java.time.Duration
import kotlinx.coroutines.flow.first

private val API_URL = BuildConfig.API_URL.trimEnd('/')
private val ComponentActivity.tokenStore get() = applicationContext.dataStore
private val android.content.Context.dataStore by preferencesDataStore(name = "gmm_session")
private val TOKEN_KEY = stringPreferencesKey("access_token")
private val API_KEY = stringPreferencesKey("api_url")
@Volatile private var liveApiUrl: String = API_URL

private fun normalizeApi(raw: String): String {
    val trimmed = raw.trim().trimEnd('/')
    return if (trimmed.endsWith("/api/gmm")) trimmed else "$trimmed/api/gmm"
}

private suspend fun api(path: String, token: String? = null, method: String = "GET", body: String? = null): JsonElement = withContext(Dispatchers.IO) {
    val root = normalizeApi(liveApiUrl)
    val c = (URL(root + path).openConnection() as HttpURLConnection).apply {
        requestMethod = method
        connectTimeout = 20_000
        readTimeout = 20_000
        setRequestProperty("Accept", "application/json")
        setRequestProperty("Content-Type", "application/json")
        token?.let { setRequestProperty("Authorization", "Bearer $it") }
        if (body != null) doOutput = true
    }
    if (body != null) c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
    val response = c.responseCode
    val stream = if (response in 200..299) c.inputStream else c.errorStream
    val text = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
    if (response !in 200..299) {
        val detail = runCatching { Json.parseToJsonElement(text).jsonObject["detail"]?.jsonPrimitive?.content }.getOrNull()
        error(detail ?: "HTTP $response")
    }
    Json.parseToJsonElement(text)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        setContent { MaterialTheme { App(this@MainActivity) } }
    }
}

@Composable
private fun App(activity: MainActivity) {
    var token by remember { mutableStateOf<String?>(null) }
    var apiUrl by remember { mutableStateOf("") }
    var loaded by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        val store = activity.applicationContext.dataStore.data.first()
        token = store[TOKEN_KEY]
        apiUrl = store[API_KEY] ?: API_URL
        liveApiUrl = apiUrl
        loaded = true
    }
    if (!loaded) return
    if (apiUrl.isBlank()) {
        ApiSetup { value ->
            apiUrl = value
            liveApiUrl = value
            activity.applicationContext.dataStore.edit { it[API_KEY] = value }
        }
    } else if (token == null) Login { value -> token = value; activity.applicationContext.dataStore.edit { it[TOKEN_KEY] = value } }
    else MainShell(token!!) {
        activity.applicationContext.dataStore.edit { it.remove(TOKEN_KEY) }
        token = null
    }
}

@Composable
private fun ApiSetup(onSave: (String) -> Unit) {
    var url by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("GET MONEY MACHINE", style = MaterialTheme.typography.headlineMedium)
        Text("Production API URL")
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(url, { url = it }, label = { Text("https://your-app.example/api/gmm") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(12.dp))
        Button(onClick = { onSave(url.trim()) }, enabled = url.startsWith("https://"), modifier = Modifier.fillMaxWidth()) { Text("SAVE API URL") }
    }
}

@Composable
private fun Login(onToken: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("GET MONEY MACHINE", style = MaterialTheme.typography.headlineMedium)
        Text("Secure owner access")
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(email, { email = it }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(password, { password = it }, label = { Text("Password") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(12.dp))
        Button(onClick = {
            error = ""
            scope.launch {
                try {
                    val result = api("/auth/login", method = "POST", body = buildJsonObject {
                        put("email", email.trim())
                        put("password", password)
                    }.toString()).jsonObject
                    onToken(result["access_token"]!!.jsonPrimitive.content)
                } catch (e: Exception) { error = e.message ?: "Login failed" }
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("LOG IN") }
        if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 10.dp))
    }
}

private val tabs = listOf("Dashboard", "Stations", "Move Money", "Transactions", "Security", "Notifications")

@Composable
private fun MainShell(token: String, onLogout: () -> Unit) {
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf("Dashboard") }
    var stations by remember { mutableStateOf<JsonArray>(buildJsonArray { }) }
    var balance by remember { mutableStateOf<JsonObject?>(null) }
    var destinations by remember { mutableStateOf<JsonArray>(buildJsonArray { }) }
    var withdrawals by remember { mutableStateOf<JsonArray>(buildJsonArray { }) }
    var transactions by remember { mutableStateOf<JsonArray>(buildJsonArray { }) }
    var audit by remember { mutableStateOf<JsonArray>(buildJsonArray { }) }
    var notifications by remember { mutableStateOf<JsonArray>(buildJsonArray { }) }
    var paypal by remember { mutableStateOf<JsonObject?>(null) }
    var error by remember { mutableStateOf("") }

    fun load() {
        scope.launch {
            try {
                val results = listOf(
                    api("/stations", token).jsonArray,
                    api("/balance", token).jsonObject,
                    api("/destinations", token).jsonArray,
                    api("/withdrawals", token).jsonArray,
                    api("/transactions", token).jsonArray,
                    api("/audit", token).jsonArray,
                    api("/notifications", token).jsonArray,
                    api("/paypal/status", token).jsonObject
                )
                stations = results[0].jsonArray; balance = results[1].jsonObject; destinations = results[2].jsonArray
                withdrawals = results[3].jsonArray; transactions = results[4].jsonArray; audit = results[5].jsonArray
                notifications = results[6].jsonArray; paypal = results[7].jsonObject; error = ""
            } catch (e: Exception) { error = e.message ?: "Backend unavailable" }
        }
    }
    LaunchedEffect(Unit) { load() }

    fun post(path: String) {
        scope.launch { try { api(path, token, "POST"); load() } catch (e: Exception) { error = e.message ?: "Request failed" } }
    }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column { Text("GET MONEY MACHINE", style = MaterialTheme.typography.titleLarge); Text("Connected backend") }
            TextButton(onClick = { scope.launch { runCatching { api("/auth/logout", token, "POST") }; onLogout() } }) { Text("LOG OUT") }
        }
        ScrollableTabRow(selectedTabIndex = tabs.indexOf(tab).coerceAtLeast(0)) {
            tabs.forEach { label -> Tab(selected = tab == label, onClick = { tab = label }, text = { Text(label) }) }
        }
        if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(8.dp))
        when (tab) {
            "Dashboard" -> Dashboard(stations, balance, paypal, ::post)
            "Stations" -> Stations(stations, token, ::post, load)
            "Move Money" -> MoveMoney(balance, destinations, withdrawals, token, load, { error = it })
            "Transactions" -> JsonList("Ledger Transactions", transactions)
            "Security" -> JsonList("Audit & Security", audit)
            "Notifications" -> JsonList("Notifications", notifications)
        }
    }
}

@Composable
private fun Dashboard(stations: JsonArray, balance: JsonObject?, paypal: JsonObject?, post: (String) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Spacer(Modifier.height(8.dp))
        Text("Spendable Available Balance: $${balance?.number("spendable").ifBlank { balance?.number("display_available") }}", style = MaterialTheme.typography.titleMedium)
        Text("Spendable ledger: $${balance?.number("available")}")
        Text("Pending: $${balance?.number("pending")}")
        Text("Opening balance: $0.00")
        Text("PayPal: ${if (paypal?.bool("configured") == true) "LIVE CONFIGURED" else "PRODUCTION SETUP REQUIRED"}")
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button({ post("/stations/control/start") }) { Text("START ALL") }
            Button({ post("/stations/control/stop") }) { Text("STOP ALL") }
            Button({ post("/stations/control/pause") }) { Text("PAUSE ALL") }
            Button({ post("/stations/control/emergency") }) { Text("EMERGENCY") }
        }
        Text("15 stations", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp))
        Text("Running stations discover only through configured real connectors; they never create money automatically.")
    }
}

@Composable
private fun Stations(stations: JsonArray, token: String, post: (String) -> Unit, reload: () -> Unit) {
    val scope = rememberCoroutineScope()
    var selected by remember { mutableStateOf<JsonObject?>(null) }
    LazyColumn(Modifier.fillMaxSize()) {
        items(stations) { station ->
            val id = station.int("id")
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Column(Modifier.padding(10.dp)) {
                    Text(station.string("name"), style = MaterialTheme.typography.titleMedium)
                    val nextCycle = station.string("next_cycle_at")
                    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
                    LaunchedEffect(station.int("id"), station.bool("active"), station.bool("paused"), nextCycle) { while (true) { now = System.currentTimeMillis(); kotlinx.coroutines.delay(1000) } }
                    val remaining = if (station.bool("paused")) station.int("paused_remaining_seconds").toLong() else if (station.bool("active") && nextCycle.isNotBlank()) runCatching { maxOf(0, Duration.between(Instant.ofEpochMilli(now), Instant.parse(nextCycle)).seconds) }.getOrDefault(0) else 0
                    Text(if (station.bool("active")) "RUNNING • ${remaining/3600}:${(remaining%3600)/60}:${remaining%60}" else if (station.bool("paused")) "PAUSED • ${remaining/3600}:${(remaining%3600)/60}:${remaining%60}" else "STOPPED")
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("start", "pause", "stop", "enable", "disable", "emergency").forEach { action ->
                            TextButton({ post("/stations/$id/$action") }) { Text(action.uppercase()) }
                        }
                    }
                    TextButton({ selected = station }) { Text("DETAILS / SCAN / OPPORTUNITIES") }
                }
            }
        }
    }
    selected?.let { StationDetail(it, token, { selected = null }, reload) }
}

@Composable
private fun StationDetail(station: JsonObject, token: String, close: () -> Unit, reload: () -> Unit) {
    val scope = rememberCoroutineScope()
    val id = station.int("id")
    var opportunities by remember { mutableStateOf<JsonArray>(buildJsonArray { }) }
    var title by remember { mutableStateOf("") }
    var evidence by remember { mutableStateOf("") }
    var value by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    fun load() { scope.launch { runCatching { opportunities = api("/opportunities?station_id=$id", token).jsonArray }.onFailure { message = it.message ?: "Load failed" } } }
    LaunchedEffect(Unit) { load() }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(station.string("name"), style = MaterialTheme.typography.titleLarge); TextButton(close) { Text("CLOSE") } }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button({ scope.launch { runCatching { api("/stations/$id/scan", token, "POST"); load(); reload() }.onFailure { message = it.message ?: "Scan failed" } } }) { Text("SCAN") }
        }
        OutlinedTextField(title, { title = it }, label = { Text("Opportunity title") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value, { value = it }, label = { Text("Estimated value (optional)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(evidence, { evidence = it }, label = { Text("Evidence / source details") }, modifier = Modifier.fillMaxWidth())
        Button({
            scope.launch {
                try {
                    api("/opportunities/manual", token, "POST", buildJsonObject {
                        put("station_id", id); put("title", title); put("estimated_value", value.toDoubleOrNull()); put("evidence", evidence)
                    }.toString())
                    title = ""; value = ""; evidence = ""; message = "Opportunity recorded as DETECTED"; load(); reload()
                } catch (e: Exception) { message = e.message ?: "Save failed" }
            }
        }) { Text("SAVE DETECTED OPPORTUNITY") }
        if (message.isNotEmpty()) Text(message, modifier = Modifier.padding(6.dp))
        LazyColumn { items(opportunities) { o -> Text("#${o.int("id")} ${o.string("title")} • ${o.string("state")} • estimated $${o.number("estimated_value")}", modifier = Modifier.padding(vertical = 4.dp)) } }
    }
}

@Composable
private fun MoveMoney(balance: JsonObject?, destinations: JsonArray, withdrawals: JsonArray, token: String, reload: () -> Unit, onError: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var type by remember { mutableStateOf("PAYPAL") }
    var label by remember { mutableStateOf("") }
    var providerData by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    val types = listOf("PAYPAL", "ACH", "ONEPAY", "CASH_APP", "DEBIT_CARD")
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Spendable: $${balance?.number("spendable").ifBlank { balance?.number("available") }}", style = MaterialTheme.typography.titleMedium)
        Text("Only spendable internal-ledger funds can be transferred.")
        Spacer(Modifier.height(8.dp))
        Text("Add transfer destination", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(label, { label = it }, label = { Text("Destination label") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            types.forEach { t -> FilterChip(selected = type == t, onClick = { type = t }, label = { Text(t) }) }
        }
        OutlinedTextField(
            providerData,
            { providerData = it },
            label = { Text(if (type == "PAYPAL") "PayPal recipient email" else "Provider data JSON") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 2
        )
        Button(enabled = label.isNotBlank() && providerData.isNotBlank(), onClick = {
            scope.launch {
                try {
                    val external = if (type == "PAYPAL") providerData.trim() else providerData.trim()
                    val d = api("/destinations", token, "POST", buildJsonObject {
                        put("type", type); put("label", label.trim()); put("external_id", external)
                    }.toString()).jsonObject
                    selected = d["id"]!!.jsonPrimitive.content
                    label = ""; providerData = ""; message = "$type destination saved"; reload()
                } catch (e: Exception) { onError(e.message ?: "Destination failed") }
            }
        }) { Text("SAVE DESTINATION") }
        Spacer(Modifier.height(10.dp))
        Text("Transfer", style = MaterialTheme.typography.titleMedium)
        val enabledDestinations = destinations.filter { it.jsonObject["enabled"]?.jsonPrimitive?.booleanOrNull == true }
        if (enabledDestinations.isNotEmpty()) {
            enabledDestinations.forEach { d ->
                val id = d.jsonObject["id"]!!.jsonPrimitive.content
                FilterChip(selected = selected == id, onClick = { selected = id }, label = { Text(d.jsonObject["label"]!!.jsonPrimitive.content) })
            }
        } else Text("No enabled destination is configured yet.")
        OutlinedTextField(amount, { amount = it }, label = { Text("Amount") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Button(enabled = amount.toDoubleOrNull()?.let { it > 0 } == true && selected.isNotBlank(), onClick = {
            scope.launch {
                try {
                    val w = api("/withdrawals", token, "POST", buildJsonObject {
                        put("amount", amount.toDouble()); put("destination_id", selected.toInt()); put("idempotency_key", UUID.randomUUID().toString())
                    }.toString()).jsonObject
                    message = "Transfer status: ${w.string("status")}"; amount = ""; reload()
                } catch (e: Exception) { onError(e.message ?: "Transfer failed") }
            }
        }) { Text("TRANSFER") }
        if (message.isNotEmpty()) Text(message, modifier = Modifier.padding(6.dp))
        Text("Transfer History", style = MaterialTheme.typography.titleMedium)
        JsonRows(withdrawals)
    }
}

@Composable
private fun JsonList(title: String, rows: JsonArray) { Column(Modifier.fillMaxSize()) { Text(title, style = MaterialTheme.typography.titleLarge); JsonRows(rows) } }

@Composable
private fun JsonRows(rows: JsonArray) {
    LazyColumn { items(rows) { row -> Text(row.toString(), modifier = Modifier.padding(vertical = 4.dp)) } }
}

private fun JsonObject.string(key: String): String = this[key]?.jsonPrimitive?.contentOrNull ?: ""
private fun JsonObject.bool(key: String): Boolean = this[key]?.jsonPrimitive?.booleanOrNull ?: false
private fun JsonObject.int(key: String): Int = this[key]?.jsonPrimitive?.intOrNull ?: 0
private fun JsonObject.number(key: String): String = this[key]?.jsonPrimitive?.contentOrNull ?: "0.00"
