package com.mdcatnums.prep

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.android.billingclient.api.*

class MainActivity : AppCompatActivity(), PurchasesUpdatedListener {

    private lateinit var webView: WebView
    private lateinit var billingClient: BillingClient

    private val productIds = setOf(
        "premium_monthly",
        "premium_3months",
        "premium_yearly"
    )

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            webViewClient = WebViewClient()
            addJavascriptInterface(BillingBridge(), "AndroidBilling")
        }
        setContentView(webView)

        webView.loadUrl("file:///android_asset/index.html")
        setupBilling()
    }

    private fun setupBilling() {
        billingClient = BillingClient.newBuilder(this)
            .setListener(this)
            .enablePendingPurchases(
                PendingPurchasesParams.newBuilder()
                    .enableOneTimeProducts()
                    .enablePrepaidPlans()
                    .build()
            )
            .build()

        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                    restorePurchases()
                }
            }

            override fun onBillingServiceDisconnected() {
                // Billing reconnects when the user tries again.
            }
        })
    }

    private fun restorePurchases() {
        if (!billingClient.isReady) return
        val params = QueryPurchasesParams.newBuilder()
            .setProductType(BillingClient.ProductType.SUBS)
            .build()

        billingClient.queryPurchasesAsync(params) { result, purchases ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                purchases.forEach { handlePurchase(it) }
            }
        }
    }

    private fun buy(productId: String) {
        if (!billingClient.isReady) {
            showMessage("Google Play Billing is not ready yet.")
            return
        }

        val product = QueryProductDetailsParams.Product.newBuilder()
            .setProductId(productId)
            .setProductType(BillingClient.ProductType.SUBS)
            .build()

        val params = QueryProductDetailsParams.newBuilder()
            .setProductList(listOf(product))
            .build()

        billingClient.queryProductDetailsAsync(params) { result, detailsResult ->
            if (result.responseCode != BillingClient.BillingResponseCode.OK) {
                showMessage("Could not load the Premium product.")
                return@queryProductDetailsAsync
            }

            val details = detailsResult.productDetailsList.firstOrNull()
            val offer = details?.subscriptionOfferDetails?.firstOrNull()

            if (details == null || offer == null) {
                showMessage("Premium product is not configured in Play Console yet.")
                return@queryProductDetailsAsync
            }

            val productParams = BillingFlowParams.ProductDetailsParams.newBuilder()
                .setProductDetails(details)
                .setOfferToken(offer.offerToken)
                .build()

            val flowParams = BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(listOf(productParams))
                .build()

            billingClient.launchBillingFlow(this, flowParams)
        }
    }

    override fun onPurchasesUpdated(
        result: BillingResult,
        purchases: MutableList<Purchase>?
    ) {
        if (result.responseCode == BillingClient.BillingResponseCode.OK) {
            purchases.orEmpty().forEach { handlePurchase(it) }
        } else if (result.responseCode != BillingClient.BillingResponseCode.USER_CANCELED) {
            showMessage("Purchase could not be completed.")
        }
    }

    private fun handlePurchase(purchase: Purchase) {
        if (purchase.purchaseState != Purchase.PurchaseState.PURCHASED) return

        if (!purchase.isAcknowledged) {
            val acknowledgeParams = AcknowledgePurchaseParams.newBuilder()
                .setPurchaseToken(purchase.purchaseToken)
                .build()

            billingClient.acknowledgePurchase(acknowledgeParams) {
                if (it.responseCode == BillingClient.BillingResponseCode.OK) {
                    unlockPremium()
                }
            }
        } else {
            unlockPremium()
        }

        // Production note: verify purchase tokens on your own secure backend
        // before granting durable server-side entitlement.
    }

    private fun unlockPremium() {
        // The UI cache is updated immediately. In production, the web app should
        // send the purchase token to /api/play/verify-subscription with the
        // signed-in account, then unlock based on the server response.
        webView.post {
            webView.evaluateJavascript(
                "localStorage.setItem('premium','1'); window.setPremiumState && window.setPremiumState(true);",
                null
            )
        }
    }

    private fun showMessage(message: String) {
        webView.post {
            val js = "window.toast && window.toast(${org.json.JSONObject.quote(message)});"
            webView.evaluateJavascript(js, null)
        }
    }

    inner class BillingBridge {
        @JavascriptInterface
        fun buySubscription(productId: String) {
            runOnUiThread { buy(if (productId in productIds) productId else "premium_monthly") }
        }
    }

    override fun onDestroy() {
        if (::billingClient.isInitialized) billingClient.endConnection()
        webView.destroy()
        super.onDestroy()
    }
}
