package com.hebrew.calendar;

import android.os.Bundle;
import android.util.Log;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebResourceError;
import android.webkit.WebView;
import com.getcapacitor.Bridge;
import com.getcapacitor.BridgeActivity;
import com.getcapacitor.BridgeWebViewClient;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends BridgeActivity {
    private static final String TAG = "HebrewCalendar";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            Bridge bridge = getBridge();
            if (bridge != null && bridge.getWebView() != null) {
                WebView webView = bridge.getWebView();
                webView.clearCache(true);
                webView.getSettings().setJavaScriptEnabled(true);
                webView.getSettings().setDomStorageEnabled(true);
                webView.getSettings().setDatabaseEnabled(true);
                webView.getSettings().setAllowFileAccess(true);
                webView.getSettings().setAllowContentAccess(true);

                BridgeWebViewClient customClient = new BridgeWebViewClient(bridge) {
                    @Override
                    public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                        String url = request.getUrl().toString();
                        Log.i(TAG, "shouldInterceptRequest: " + url);

                        Map<String, String> headers = new HashMap<>();
                        headers.put("Access-Control-Allow-Origin", "*");
                        headers.put("Access-Control-Allow-Methods", "GET, POST, OPTIONS, HEAD");
                        headers.put("Access-Control-Allow-Headers", "*");
                        headers.put("Cache-Control", "no-cache");

                        // 1. Intercept main.tsx / main.js / app-bundle.js
                        if (url.contains("main.tsx") || url.contains("main.js") || url.contains("app-bundle.js")) {
                            Log.i(TAG, "Serving app-bundle.js with CORS headers for: " + url);
                            InputStream is = openAsset(
                                "preview/assets/app-bundle.js",
                                "public/assets/app-bundle.js",
                                "assets/app-bundle.js",
                                "app-bundle.js"
                            );
                            if (is != null) {
                                return new WebResourceResponse("application/javascript", "UTF-8", 200, "OK", headers, is);
                            }
                        }

                        // 2. Intercept index.css
                        if (url.contains("index.css")) {
                            Log.i(TAG, "Serving index.css for: " + url);
                            InputStream is = openAsset(
                                "preview/assets/index.css",
                                "public/assets/index.css",
                                "assets/index.css",
                                "index.css"
                            );
                            if (is != null) {
                                return new WebResourceResponse("text/css", "UTF-8", 200, "OK", headers, is);
                            }
                        }

                        // 3. Intercept index.html
                        if (url.contains("index.html") || url.endsWith("/")) {
                            Log.i(TAG, "Serving index.html for: " + url);
                            InputStream is = openAsset(
                                "preview/index.html",
                                "public/index.html",
                                "index.html"
                            );
                            if (is != null) {
                                return new WebResourceResponse("text/html", "UTF-8", 200, "OK", headers, is);
                            }
                        }

                        // 4. Any other appassets.androidplatform.net request
                        if (url.contains("androidplatform.net")) {
                            String path = request.getUrl().getPath();
                            if (path != null) {
                                if (path.startsWith("/")) path = path.substring(1);
                                InputStream is = openAsset(
                                    path,
                                    "preview/" + path,
                                    "public/" + path,
                                    "assets/" + path
                                );
                                if (is != null) {
                                    String mime = getMimeType(path);
                                    return new WebResourceResponse(mime, "UTF-8", 200, "OK", headers, is);
                                }
                            }
                        }

                        return super.shouldInterceptRequest(view, request);
                    }

                    private InputStream openAsset(String... paths) {
                        for (String p : paths) {
                            try {
                                return getAssets().open(p);
                            } catch (Exception ignored) {}
                        }
                        return null;
                    }

                    private String getMimeType(String path) {
                        if (path.endsWith(".js") || path.endsWith(".mjs")) return "application/javascript";
                        if (path.endsWith(".css")) return "text/css";
                        if (path.endsWith(".html")) return "text/html";
                        if (path.endsWith(".json")) return "application/json";
                        if (path.endsWith(".png")) return "image/png";
                        if (path.endsWith(".jpg") || path.endsWith(".jpeg")) return "image/jpeg";
                        if (path.endsWith(".svg")) return "image/svg+xml";
                        return "application/octet-stream";
                    }

                    @Override
                    public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                        Log.e(TAG, "WebView error: " + error.getDescription() + " code: " + error.getErrorCode() + " url: " + request.getUrl());
                        super.onReceivedError(view, request, error);
                    }
                };

                bridge.setWebViewClient(customClient);
                webView.setWebViewClient(customClient);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error configuring WebView in MainActivity", e);
        }
    }
}
