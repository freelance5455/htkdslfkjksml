package com.habivio.app

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import org.json.JSONObject

@CapacitorPlugin(name = "HabivioAlarm")
class HabivioAlarmPlugin : Plugin() {

    companion object {
        private const val PREFS_NAME = "habivio_native_alarms_v1"
        private var activePluginInstance: HabivioAlarmPlugin? = null

        fun notifyAlarmTriggered(taskId: String, title: String, dueTime: String, ringtone: String) {
            val data = JSObject().apply {
                put("taskId", taskId)
                put("title", title)
                put("dueTime", dueTime)
                put("ringtone", ringtone)
            }
            activePluginInstance?.notifyListeners("alarmTriggered", data, true)
        }

        fun notifyAlarmCompleted(taskId: String) {
            val data = JSObject().apply {
                put("taskId", taskId)
            }
            activePluginInstance?.notifyListeners("alarmCompleted", data, true)
        }

        fun notifyAlarmDismissed(taskId: String) {
            val data = JSObject().apply {
                put("taskId", taskId)
            }
            activePluginInstance?.notifyListeners("alarmDismissed", data, true)
        }

        fun notifyAlarmSnoozed(taskId: String, snoozeTime: String) {
            val data = JSObject().apply {
                put("taskId", taskId)
                put("snoozeTime", snoozeTime)
            }
            activePluginInstance?.notifyListeners("alarmSnoozed", data, true)
        }

        fun scheduleNativeAlarmInternal(
            context: Context,
            taskId: String,
            title: String,
            triggerMillis: Long,
            dueTime: String,
            notes: String,
            ringtone: String,
            minutesBefore: Int
        ) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

            val intent = Intent(context, AlarmReceiver::class.java).apply {
                action = AlarmReceiver.ACTION_TRIGGER_ALARM
                putExtra(AlarmReceiver.EXTRA_TASK_ID, taskId)
                putExtra(AlarmReceiver.EXTRA_TITLE, title)
                putExtra(AlarmReceiver.EXTRA_DUE_TIME, dueTime)
                putExtra(AlarmReceiver.EXTRA_NOTES, notes)
                putExtra(AlarmReceiver.EXTRA_RINGTONE, ringtone)
                putExtra(AlarmReceiver.EXTRA_MINUTES_BEFORE, minutesBefore)
            }

            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            } else {
                PendingIntent.FLAG_UPDATE_CURRENT
            }

            val pendingIntent = PendingIntent.getBroadcast(
                context,
                taskId.hashCode(),
                intent,
                flags
            )

            // Requirement 1 & 2: Use setExactAndAllowWhileIdle for reliable lock-screen execution
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    triggerMillis,
                    pendingIntent
                )
            }

            // Persist to SharedPreferences for reboot restoration
            saveAlarmToPrefs(context, taskId, title, triggerMillis, dueTime, notes, ringtone, minutesBefore)
        }

        fun restoreAllSavedAlarms(context: Context) {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val allEntries = prefs.all
            val now = System.currentTimeMillis()

            for ((taskId, jsonStr) in allEntries) {
                try {
                    val obj = JSONObject(jsonStr as String)
                    val triggerMillis = obj.getLong("triggerMillis")
                    // Only restore future alarms
                    if (triggerMillis > now) {
                        scheduleNativeAlarmInternal(
                            context = context,
                            taskId = taskId,
                            title = obj.optString("title", "Task"),
                            triggerMillis = triggerMillis,
                            dueTime = obj.optString("dueTime", ""),
                            notes = obj.optString("notes", ""),
                            ringtone = obj.optString("ringtone", "morning_birds"),
                            minutesBefore = obj.optInt("minutesBefore", 0)
                        )
                    } else {
                        prefs.edit().remove(taskId).apply()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }

        private fun saveAlarmToPrefs(
            context: Context,
            taskId: String,
            title: String,
            triggerMillis: Long,
            dueTime: String,
            notes: String,
            ringtone: String,
            minutesBefore: Int
        ) {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val obj = JSONObject().apply {
                put("taskId", taskId)
                put("title", title)
                put("triggerMillis", triggerMillis)
                put("dueTime", dueTime)
                put("notes", notes)
                put("ringtone", ringtone)
                put("minutesBefore", minutesBefore)
            }
            prefs.edit().putString(taskId, obj.toString()).apply()
        }

        fun removeAlarmFromPrefs(context: Context, taskId: String) {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit().remove(taskId).apply()
        }
    }

    override fun load() {
        super.load()
        activePluginInstance = this
    }

    @PluginMethod
    fun scheduleAlarm(call: PluginCall) {
        val taskId = call.getString("taskId") ?: run {
            call.reject("taskId is required")
            return
        }
        val title = call.getString("title", "Task Reminder")
        val triggerMillis = call.getDouble("triggerMillis")?.toLong() ?: run {
            call.reject("triggerMillis is required")
            return
        }
        val dueTime = call.getString("dueTime", "")
        val notes = call.getString("notes", "")
        val ringtone = call.getString("ringtone", "morning_birds")
        val minutesBefore = call.getInt("minutesBefore", 0)

        try {
            scheduleNativeAlarmInternal(
                context = context,
                taskId = taskId,
                title = title,
                triggerMillis = triggerMillis,
                dueTime = dueTime,
                notes = notes,
                ringtone = ringtone,
                minutesBefore = minutesBefore
            )

            val ret = JSObject().apply {
                put("success", true)
                put("taskId", taskId)
                put("triggerMillis", triggerMillis)
            }
            call.resolve(ret)
        } catch (e: Exception) {
            call.reject("Failed to schedule alarm: ${e.message}", e)
        }
    }

    @PluginMethod
    fun cancelAlarm(call: PluginCall) {
        val taskId = call.getString("taskId") ?: run {
            call.reject("taskId is required")
            return
        }

        try {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent = Intent(context, AlarmReceiver::class.java).apply {
                action = AlarmReceiver.ACTION_TRIGGER_ALARM
            }
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            } else {
                PendingIntent.FLAG_UPDATE_CURRENT
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                taskId.hashCode(),
                intent,
                flags
            )
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()

            // Cancel notification if active
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.cancel(taskId.hashCode())

            removeAlarmFromPrefs(context, taskId)

            val ret = JSObject().apply {
                put("success", true)
                put("taskId", taskId)
            }
            call.resolve(ret)
        } catch (e: Exception) {
            call.reject("Failed to cancel alarm: ${e.message}", e)
        }
    }

    @PluginMethod
    fun cancelAllAlarms(call: PluginCall) {
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            } else {
                PendingIntent.FLAG_UPDATE_CURRENT
            }

            for ((taskId, _) in prefs.all) {
                val intent = Intent(context, AlarmReceiver::class.java).apply {
                    action = AlarmReceiver.ACTION_TRIGGER_ALARM
                }
                val pi = PendingIntent.getBroadcast(context, taskId.hashCode(), intent, flags)
                alarmManager.cancel(pi)
                pi.cancel()
                nm.cancel(taskId.hashCode())
            }

            prefs.edit().clear().apply()

            val ret = JSObject().apply {
                put("success", true)
            }
            call.resolve(ret)
        } catch (e: Exception) {
            call.reject("Failed to cancel all alarms: ${e.message}", e)
        }
    }

    @PluginMethod
    fun getPermissionsStatus(call: PluginCall) {
        val exactAlarmAllowed = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarmManager.canScheduleExactAlarms()
        } else {
            true
        }

        val notificationsAllowed = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.areNotificationsEnabled()
        } else {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.areNotificationsEnabled()
        }

        val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        val batteryOptimizationIgnored = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            powerManager.isIgnoringBatteryOptimizations(context.packageName)
        } else {
            true
        }

        val manufacturer = Build.MANUFACTURER.lowercase()
        val isXiaomiOrRedmi = manufacturer.contains("xiaomi") || manufacturer.contains("redmi") || manufacturer.contains("poco")

        val ret = JSObject().apply {
            put("exactAlarmAllowed", exactAlarmAllowed)
            put("notificationsAllowed", notificationsAllowed)
            put("batteryOptimizationIgnored", batteryOptimizationIgnored)
            put("isXiaomiOrRedmi", isXiaomiOrRedmi)
            put("manufacturer", Build.MANUFACTURER)
            put("model", Build.MODEL)
            put("sdkInt", Build.VERSION.SDK_INT)
        }
        call.resolve(ret)
    }

    @PluginMethod
    fun requestExactAlarmPermission(call: PluginCall) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                    data = Uri.parse("package:${context.packageName}")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                call.resolve(JSObject().put("success", true))
            } catch (e: Exception) {
                call.reject("Failed to open exact alarm settings: ${e.message}", e)
            }
        } else {
            call.resolve(JSObject().put("success", true).put("message", "Not required below Android 12"))
        }
    }

    @PluginMethod
    fun requestIgnoreBatteryOptimizations(call: PluginCall) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:${context.packageName}")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                call.resolve(JSObject().put("success", true))
            } catch (e: Exception) {
                // Fallback to battery saver settings
                try {
                    val fallbackIntent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(fallbackIntent)
                    call.resolve(JSObject().put("success", true))
                } catch (err: Exception) {
                    call.reject("Failed to request battery optimization exemption: ${err.message}", err)
                }
            }
        } else {
            call.resolve(JSObject().put("success", true))
        }
    }

    @PluginMethod
    fun openAutostartSettings(call: PluginCall) {
        // Redmi / Xiaomi / POCO Autostart intent handling
        val intents = listOf(
            Intent().setComponent(ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")),
            Intent("miui.intent.action.OP_AUTO_START").addCategory(Intent.CATEGORY_DEFAULT),
            Intent().setComponent(ComponentName("com.miui.securitycenter", "com.miui.powercenter.PowerSettings")),
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(Uri.parse("package:${context.packageName}"))
        )

        var launched = false
        for (intent in intents) {
            try {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                launched = true
                break
            } catch (e: Exception) {
                // try next
            }
        }

        call.resolve(JSObject().put("success", launched))
    }

    @PluginMethod
    fun silenceAlarm(call: PluginCall) {
        AlarmService.silence()
        call.resolve(JSObject().put("success", true))
    }

    @PluginMethod
    fun dismissAlarm(call: PluginCall) {
        AlarmService.silence()
        val stopIntent = Intent(context, AlarmService::class.java).apply {
            action = AlarmService.ACTION_STOP
        }
        context.stopService(stopIntent)

        val taskId = call.getString("taskId")
        if (taskId != null) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.cancel(taskId.hashCode())
        }

        call.resolve(JSObject().put("success", true))
    }

    @PluginMethod
    fun snoozeAlarm(call: PluginCall) {
        val taskId = call.getString("taskId") ?: run {
            call.reject("taskId is required")
            return
        }
        val minutes = call.getInt("minutes", 5)

        AlarmService.silence()
        val stopIntent = Intent(context, AlarmService::class.java).apply {
            action = AlarmService.ACTION_STOP
        }
        context.stopService(stopIntent)

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(taskId.hashCode())

        val cal = java.util.Calendar.getInstance().apply {
            add(java.util.Calendar.MINUTE, minutes)
        }
        val snoozeTimeStr = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(cal.time)

        scheduleNativeAlarmInternal(
            context = context,
            taskId = taskId,
            title = call.getString("title", "Snoozed Task"),
            triggerMillis = cal.timeInMillis,
            dueTime = snoozeTimeStr,
            notes = "",
            ringtone = call.getString("ringtone", "morning_birds"),
            minutesBefore = 0
        )

        call.resolve(JSObject().apply {
            put("success", true)
            put("snoozeTime", snoozeTimeStr)
        })
    }

    @PluginMethod
    fun testLockScreenAlarm(call: PluginCall) {
        val delaySec = call.getInt("delaySeconds", 5)
        val title = call.getString("title", "লক স্ক্রিন অ্যালার্ম টেস্ট — Habivio")

        val triggerMillis = System.currentTimeMillis() + (delaySec * 1000L)
        val testTaskId = "test_alarm_${System.currentTimeMillis()}"

        try {
            scheduleNativeAlarmInternal(
                context = context,
                taskId = testTaskId,
                title = title,
                triggerMillis = triggerMillis,
                dueTime = "এখনই",
                notes = "স্ক্রিন অফ ও লক থাকা অবস্থায় Native Android AlarmManager ও WakeLock নিখুঁতভাবে কাজ করছে!",
                ringtone = "morning_birds",
                minutesBefore = 0
            )

            call.resolve(JSObject().apply {
                put("success", true)
                put("taskId", testTaskId)
                put("delaySeconds", delaySec)
            })
        } catch (e: Exception) {
            call.reject("Failed to schedule test alarm: ${e.message}", e)
        }
    }
}
