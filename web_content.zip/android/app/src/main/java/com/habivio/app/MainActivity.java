package com.habivio.app;

import android.os.Bundle;
import android.view.KeyEvent;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(HabivioAlarmPlugin.class);
        super.onCreate(savedInstanceState);
    }

    /**
     * Requirement 4: Pressing Volume Up or Volume Down should silence the ringing alarm.
     */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            if (AlarmService.Companion.isRinging()) {
                AlarmService.Companion.silence();
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }
}
