package com.habivio.app

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class AlarmActionReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_COMPLETE = "com.habivio.app.ACTION_COMPLETE"
        const val ACTION_DISMISS = "com.habivio.app.ACTION_DISMISS"
        const val ACTION_SNOOZE = "com.habivio.app.ACTION_SNOOZE"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val taskId = intent.getStringExtra(AlarmReceiver.EXTRA_TASK_ID) ?: return

        // 1. Stop audio service
        val stopServiceIntent = Intent(context, AlarmService::class.java).apply {
            action = AlarmService.ACTION_STOP
        }
        context.stopService(stopServiceIntent)

        // 2. Clear notification
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(taskId.hashCode())

        // 3. Perform specific action
        when (intent.action) {
            ACTION_COMPLETE -> {
                HabivioAlarmPlugin.notifyAlarmCompleted(taskId)
                Toast.makeText(context, "✓ Task Completed (কাজটি সম্পন্ন হয়েছে)", Toast.LENGTH_SHORT).show()
            }
            ACTION_DISMISS -> {
                HabivioAlarmPlugin.notifyAlarmDismissed(taskId)
            }
            ACTION_SNOOZE -> {
                val cal = Calendar.getInstance().apply {
                    add(Calendar.MINUTE, 5)
                }
                val snoozeTimeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(cal.time)

                HabivioAlarmPlugin.scheduleNativeAlarmInternal(
                    context = context,
                    taskId = taskId,
                    title = "Snoozed Task",
                    triggerMillis = cal.timeInMillis,
                    dueTime = snoozeTimeStr,
                    notes = "",
                    ringtone = "morning_birds",
                    minutesBefore = 0
                )

                HabivioAlarmPlugin.notifyAlarmSnoozed(taskId, snoozeTimeStr)
                Toast.makeText(context, "⏰ Snoozed for 5 minutes ($snoozeTimeStr এ আবার বাজবে)", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
