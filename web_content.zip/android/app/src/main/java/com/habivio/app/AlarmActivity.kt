package com.habivio.app

import android.app.KeyguardManager
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class AlarmActivity : AppCompatActivity() {

    private var taskId: String = ""
    private var titleText: String = ""
    private var dueTimeText: String = ""
    private var notesText: String = ""
    private var ringtoneKey: String = ""

    private var screenOffReceiver: BroadcastReceiver? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Configure window flags to display over lock screen and wake display
        setupLockScreenFlags()

        setContentView(R.layout.activity_alarm)

        taskId = intent.getStringExtra(AlarmReceiver.EXTRA_TASK_ID) ?: ""
        titleText = intent.getStringExtra(AlarmReceiver.EXTRA_TITLE) ?: "Task Reminder"
        dueTimeText = intent.getStringExtra(AlarmReceiver.EXTRA_DUE_TIME) ?: ""
        notesText = intent.getStringExtra(AlarmReceiver.EXTRA_NOTES) ?: ""
        ringtoneKey = intent.getStringExtra(AlarmReceiver.EXTRA_RINGTONE) ?: "morning_birds"

        val tvAlarmTitle = findViewById<TextView>(R.id.tvAlarmTitle)
        val tvAlarmTime = findViewById<TextView>(R.id.tvAlarmTime)
        val tvAlarmNotes = findViewById<TextView>(R.id.tvAlarmNotes)
        val btnComplete = findViewById<Button>(R.id.btnComplete)
        val btnDismiss = findViewById<Button>(R.id.btnDismiss)
        val btnSnooze = findViewById<Button>(R.id.btnSnooze)

        tvAlarmTitle.text = titleText
        tvAlarmTime.text = if (dueTimeText.isNotEmpty()) dueTimeText else SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Calendar.getInstance().time)
        tvAlarmNotes.text = if (notesText.isNotEmpty()) "\"$notesText\"" else "Habivio Personal Routine Alert"

        // Button 1: Mark Complete
        btnComplete.setOnClickListener {
            handleMarkComplete()
        }

        // Button 2: Dismiss
        btnDismiss.setOnClickListener {
            handleDismiss()
        }

        // Button 3: Snooze 5 mins
        btnSnooze.setOnClickListener {
            handleSnooze()
        }

        // Register hardware screen-off receiver for power button silencing
        registerScreenOffReceiver()
    }

    private fun setupLockScreenFlags() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            keyguardManager.requestDismissKeyguard(this, null)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
    }

    /**
     * Requirement 4: Pressing Volume Up or Volume Down silences the ringing alarm.
     */
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            silenceAlarm()
            Toast.makeText(this, "Alarm Silenced (সাউন্ড মিউট করা হয়েছে)", Toast.LENGTH_SHORT).show()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    /**
     * Register dynamic receiver for Intent.ACTION_SCREEN_OFF.
     * When user presses physical Power button turning off the screen, safely silence alarm.
     */
    private fun registerScreenOffReceiver() {
        screenOffReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent?.action == Intent.ACTION_SCREEN_OFF) {
                    silenceAlarm()
                }
            }
        }
        val filter = IntentFilter(Intent.ACTION_SCREEN_OFF)
        registerReceiver(screenOffReceiver, filter)
    }

    private fun silenceAlarm() {
        AlarmService.silence()
    }

    private fun handleMarkComplete() {
        silenceAlarm()
        stopAlarmService()
        cancelNotification()

        HabivioAlarmPlugin.notifyAlarmCompleted(taskId)
        Toast.makeText(this, "✓ Task Completed (কাজ সম্পন্ন হয়েছে)", Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun handleDismiss() {
        silenceAlarm()
        stopAlarmService()
        cancelNotification()

        HabivioAlarmPlugin.notifyAlarmDismissed(taskId)
        finish()
    }

    private fun handleSnooze() {
        silenceAlarm()
        stopAlarmService()
        cancelNotification()

        // Calculate 5 minutes from now
        val cal = Calendar.getInstance().apply {
            add(Calendar.MINUTE, 5)
        }
        val snoozeTimeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(cal.time)

        // Reschedule in native AlarmManager
        HabivioAlarmPlugin.scheduleNativeAlarmInternal(
            context = this,
            taskId = taskId,
            title = titleText,
            triggerMillis = cal.timeInMillis,
            dueTime = snoozeTimeStr,
            notes = notesText,
            ringtone = ringtoneKey,
            minutesBefore = 0
        )

        HabivioAlarmPlugin.notifyAlarmSnoozed(taskId, snoozeTimeStr)
        Toast.makeText(this, "⏰ Snoozed for 5 minutes ($snoozeTimeStr এ আবার বাজবে)", Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun stopAlarmService() {
        val stopIntent = Intent(this, AlarmService::class.java).apply {
            action = AlarmService.ACTION_STOP
        }
        stopService(stopIntent)
    }

    private fun cancelNotification() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(taskId.hashCode())
    }

    override fun onDestroy() {
        try {
            screenOffReceiver?.let { unregisterReceiver(it) }
        } catch (e: Exception) {
            // ignore
        }
        super.onDestroy()
    }
}
