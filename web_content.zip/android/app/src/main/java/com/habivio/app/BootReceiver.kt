package com.habivio.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        Log.d("HabivioBootReceiver", "Received broadcast action: $action")

        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == "android.intent.action.QUICKBOOT_POWERON" ||
            action == "com.htc.intent.action.QUICKBOOT_POWERON" ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED ||
            action == Intent.ACTION_TIME_CHANGED ||
            action == Intent.ACTION_TIMEZONE_CHANGED) {

            // Reschedule all persistent alarms after reboot or clock adjustments
            try {
                HabivioAlarmPlugin.restoreAllSavedAlarms(context)
            } catch (e: Exception) {
                Log.e("HabivioBootReceiver", "Error restoring alarms on boot", e)
            }
        }
    }
}
