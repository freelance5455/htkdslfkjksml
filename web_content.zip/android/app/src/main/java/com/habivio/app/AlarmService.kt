package com.habivio.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat

class AlarmService : Service() {

    companion object {
        const val ACTION_SILENCE = "com.habivio.app.ACTION_SILENCE"
        const val ACTION_STOP = "com.habivio.app.ACTION_STOP"
        private const val NOTIFICATION_ID = 9001

        var isRinging = false
            private set

        var activeTaskId: String? = null
            private set

        private var instance: AlarmService? = null

        fun silence() {
            instance?.silenceAudioAndVibration()
        }

        fun stop() {
            instance?.stopSelf()
        }
    }

    private var mediaPlayer: MediaPlayer? = null
    private var vibrator: Vibrator? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        initVibrator()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) return START_NOT_STICKY

        if (intent.action == ACTION_SILENCE) {
            silenceAudioAndVibration()
            return START_NOT_STICKY
        } else if (intent.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        val taskId = intent.getStringExtra(AlarmReceiver.EXTRA_TASK_ID) ?: ""
        val title = intent.getStringExtra(AlarmReceiver.EXTRA_TITLE) ?: "Task Reminder"
        val ringtone = intent.getStringExtra(AlarmReceiver.EXTRA_RINGTONE) ?: "morning_birds"

        activeTaskId = taskId
        isRinging = true

        startForegroundNotification(title)
        playAlarmAudio(ringtone)
        startAlarmVibration()

        return START_STICKY
    }

    private fun startForegroundNotification(title: String) {
        val channelId = AlarmReceiver.CHANNEL_ID
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                channelId,
                AlarmReceiver.CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            )
            nm.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("🔔 Ringing: $title")
            .setContentText("Habivio Smart Alarm is sounding")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setOngoing(true)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    private fun playAlarmAudio(ringtoneKey: String) {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null

            val rawResId = getRawResIdForTone(ringtoneKey)
            if (rawResId != 0) {
                mediaPlayer = MediaPlayer.create(this, rawResId)
            }

            if (mediaPlayer == null) {
                // Fallback to system default alarm URI
                val alertUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                mediaPlayer = MediaPlayer().apply {
                    setDataSource(applicationContext, alertUri)
                }
            }

            mediaPlayer?.let { player ->
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    player.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                } else {
                    @Suppress("DEPRECATION")
                    player.setAudioStreamType(AudioManager.STREAM_ALARM)
                }

                player.isLooping = true
                player.start()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun getRawResIdForTone(key: String): Int {
        return when (key) {
            "morning_birds" -> R.raw.morning_birds
            "flowing_water" -> R.raw.flowing_water
            "zen_bell" -> R.raw.zen_bell
            "soft_rain" -> R.raw.soft_rain
            "emergency_siren" -> R.raw.emergency_siren
            else -> R.raw.morning_birds
        }
    }

    private fun initVibrator() {
        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vibratorManager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
    }

    private fun startAlarmVibration() {
        val pattern = longArrayOf(0, 1000, 400, 1000, 400, 1500)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val effect = VibrationEffect.createWaveform(pattern, 0)
                vibrator?.vibrate(effect)
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(pattern, 0)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun silenceAudioAndVibration() {
        try {
            mediaPlayer?.let {
                if (it.isPlaying) {
                    it.stop()
                }
                it.release()
            }
            mediaPlayer = null
            vibrator?.cancel()
            isRinging = false
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onDestroy() {
        silenceAudioAndVibration()
        instance = null
        activeTaskId = null
        isRinging = false
        super.onDestroy()
    }
}
