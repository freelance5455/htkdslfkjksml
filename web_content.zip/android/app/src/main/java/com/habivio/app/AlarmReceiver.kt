package com.habivio.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import androidx.core.app.NotificationCompat

class AlarmReceiver : BroadcastReceiver() {

    companion object {
        const val CHANNEL_ID = "habivio_alarm_high_priority_v1"
        const val CHANNEL_NAME = "Habivio Smart Alarms"
        const val ACTION_TRIGGER_ALARM = "com.habivio.app.ACTION_TRIGGER_ALARM"

        const val EXTRA_TASK_ID = "extra_task_id"
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_DUE_TIME = "extra_due_time"
        const val EXTRA_NOTES = "extra_notes"
        const val EXTRA_RINGTONE = "extra_ringtone"
        const val EXTRA_MINUTES_BEFORE = "extra_minutes_before"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val taskId = intent.getStringExtra(EXTRA_TASK_ID) ?: return
        val title = intent.getStringExtra(EXTRA_TITLE) ?: "Task Reminder"
        val dueTime = intent.getStringExtra(EXTRA_DUE_TIME) ?: ""
        val notes = intent.getStringExtra(EXTRA_NOTES) ?: ""
        val ringtone = intent.getStringExtra(EXTRA_RINGTONE) ?: "morning_birds"
        val minutesBefore = intent.getIntExtra(EXTRA_MINUTES_BEFORE, 0)

        // 1. Acquire Partial WakeLock to guarantee execution while device is asleep
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        val wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
            "habivio:alarm_wakelock_${taskId}"
        )
        wakeLock.acquire(90 * 1000L) // 90 seconds max

        // 2. Start Foreground Alarm Audio & Vibration Service
        val serviceIntent = Intent(context, AlarmService::class.java).apply {
            putExtra(EXTRA_TASK_ID, taskId)
            putExtra(EXTRA_TITLE, title)
            putExtra(EXTRA_DUE_TIME, dueTime)
            putExtra(EXTRA_NOTES, notes)
            putExtra(EXTRA_RINGTONE, ringtone)
            putExtra(EXTRA_MINUTES_BEFORE, minutesBefore)
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // 3. Create Notification Channel if Android 8.0+
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Critical lock-screen alarm ringtones and full-screen alerts for Habivio tasks"
                enableVibration(true)
                vibrationPattern = longArrayOf(1000, 400, 1000, 400, 1500)
                setBypassDnd(true)
                lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
            }
            notificationManager.createNotificationChannel(channel)
        }

        // 4. Build Full-Screen Intent for Lock Screen
        val fullScreenIntent = Intent(context, AlarmActivity::class.java).apply {
            putExtra(EXTRA_TASK_ID, taskId)
            putExtra(EXTRA_TITLE, title)
            putExtra(EXTRA_DUE_TIME, dueTime)
            putExtra(EXTRA_NOTES, notes)
            putExtra(EXTRA_RINGTONE, ringtone)
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_CLEAR_TOP or
                Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
            )
        }

        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }

        val fullScreenPendingIntent = PendingIntent.getActivity(
            context,
            taskId.hashCode(),
            fullScreenIntent,
            flags
        )

        // Action: Complete
        val completeIntent = Intent(context, AlarmActionReceiver::class.java).apply {
            action = AlarmActionReceiver.ACTION_COMPLETE
            putExtra(EXTRA_TASK_ID, taskId)
        }
        val completePendingIntent = PendingIntent.getBroadcast(
            context,
            (taskId + "_complete").hashCode(),
            completeIntent,
            flags
        )

        // Action: Dismiss
        val dismissIntent = Intent(context, AlarmActionReceiver::class.java).apply {
            action = AlarmActionReceiver.ACTION_DISMISS
            putExtra(EXTRA_TASK_ID, taskId)
        }
        val dismissPendingIntent = PendingIntent.getBroadcast(
            context,
            (taskId + "_dismiss").hashCode(),
            dismissIntent,
            flags
        )

        // Action: Snooze
        val snoozeIntent = Intent(context, AlarmActionReceiver::class.java).apply {
            action = AlarmActionReceiver.ACTION_SNOOZE
            putExtra(EXTRA_TASK_ID, taskId)
        }
        val snoozePendingIntent = PendingIntent.getBroadcast(
            context,
            (taskId + "_snooze").hashCode(),
            snoozeIntent,
            flags
        )

        val leadStr = if (minutesBefore > 0) " (${minutesBefore} মিনিট আগে)" else ""
        val notificationTitle = "🔔 ${title}${leadStr}"
        val notificationBody = if (notes.isNotEmpty()) notes else "সময়: ${dueTime}। কাজটি সম্পন্ন করুন!"

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(notificationTitle)
            .setContentText(notificationBody)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .setContentIntent(fullScreenPendingIntent)
            .setAutoCancel(true)
            .setOngoing(true)
            .addAction(android.R.drawable.checkbox_on_background, "✓ Complete", completePendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "✕ Dismiss", dismissPendingIntent)
            .addAction(android.R.drawable.ic_lock_idle_alarm, "⏰ Snooze (5m)", snoozePendingIntent)
            .build()

        notificationManager.notify(taskId.hashCode(), notification)

        // 5. Notify web app if foregrounded
        HabivioAlarmPlugin.notifyAlarmTriggered(taskId, title, dueTime, ringtone)
    }
}
