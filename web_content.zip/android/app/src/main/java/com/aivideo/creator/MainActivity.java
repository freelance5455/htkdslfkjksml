package com.aivideo.creator;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
