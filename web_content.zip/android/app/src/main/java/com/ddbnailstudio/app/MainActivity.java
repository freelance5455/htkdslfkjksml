package com.ddbnailstudio.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
