package com.campus.secretgossip;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
