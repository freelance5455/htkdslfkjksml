package com.chaudharidairy.farm;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
