package com.kormi.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kormi.app.theme.*
import com.kormi.app.ui.components.AppDrawerContent
import com.kormi.app.ui.components.KormiLogo
import com.kormi.app.ui.screens.ChatScreen
import com.kormi.app.ui.screens.ScriptWriterScreen
import com.kormi.app.ui.screens.VideoSeoScreen
import com.kormi.app.viewmodel.AppTab
import com.kormi.app.viewmodel.KormiViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: KormiViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            KormiTheme {
                val activeTab by viewModel.activeTab.collectAsState()
                val messages by viewModel.messages.collectAsState()
                val chatSessions by viewModel.chatSessions.collectAsState()
                val activeSessionId by viewModel.activeSessionId.collectAsState()
                val isSending by viewModel.isSending.collectAsState()
                val webResearchEnabled by viewModel.webResearchEnabled.collectAsState()
                val currentUser by viewModel.currentUser.collectAsState()
                val snackBarMessage by viewModel.snackBarMessage.collectAsState()
                val scriptLoading by viewModel.scriptLoading.collectAsState()
                val scriptText by viewModel.generatedScriptText.collectAsState()
                val seoLoading by viewModel.seoLoading.collectAsState()
                val seoData by viewModel.seoData.collectAsState()

                val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
                val scope = rememberCoroutineScope()
                val snackBarHostState = remember { SnackbarHostState() }

                var showSignOutDialog by remember { mutableStateOf(false) }

                LaunchedEffect(snackBarMessage) {
                    snackBarMessage?.let {
                        snackBarHostState.showSnackbar(it)
                        viewModel.clearSnackBar()
                    }
                }

                // Sign Out Confirmation Dialog ("Back" and "Yes, Sign Out")
                if (showSignOutDialog) {
                    AlertDialog(
                        onDismissRequest = { showSignOutDialog = false },
                        shape = RoundedCornerShape(24.dp),
                        containerColor = SurfaceWhite,
                        title = {
                            Text(
                                text = "Sign out of Kormi?",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = Slate900
                            )
                        },
                        text = {
                            Text(
                                text = "Are you sure you want to sign out from your Google account (${currentUser?.email ?: ""})?",
                                fontSize = 13.sp,
                                color = Slate700
                            )
                        },
                        confirmButton = {
                            Button(
                                onClick = {
                                    viewModel.signOut()
                                    showSignOutDialog = false
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Yes, Sign Out", fontWeight = FontWeight.Bold)
                            }
                        },
                        dismissButton = {
                            OutlinedButton(
                                onClick = { showSignOutDialog = false },
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Back", fontWeight = FontWeight.SemiBold, color = Slate700)
                            }
                        }
                    )
                }

                ModalNavigationDrawer(
                    drawerState = drawerState,
                    drawerContent = {
                        AppDrawerContent(
                            activeTab = activeTab,
                            chatSessions = chatSessions,
                            activeSessionId = activeSessionId,
                            currentUser = currentUser,
                            onSelectTab = { viewModel.setTab(it) },
                            onStartNewChat = { viewModel.startNewChat() },
                            onSelectSession = { viewModel.selectSession(it) },
                            onDeleteSession = { viewModel.deleteSession(it) },
                            onSignOutRequest = {
                                showSignOutDialog = true
                                scope.launch { drawerState.close() }
                            },
                            onSignInRequest = {
                                viewModel.signIn()
                                scope.launch { drawerState.close() }
                            },
                            onCloseDrawer = { scope.launch { drawerState.close() } }
                        )
                    }
                ) {
                    Scaffold(
                        snackbarHost = { SnackbarHost(snackBarHostState) },
                        topBar = {
                            TopAppBar(
                                title = {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        KormiLogo(size = 32.dp)
                                        Text(
                                            text = "Kormi",
                                            fontWeight = FontWeight.Black,
                                            fontSize = 18.sp,
                                            color = Emerald950
                                        )
                                    }
                                },
                                navigationIcon = {
                                    IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                        Icon(
                                            imageVector = Icons.Default.Menu,
                                            contentDescription = "Menu",
                                            tint = Emerald950
                                        )
                                    }
                                },
                                actions = {
                                    Button(
                                        onClick = { viewModel.startNewChat() },
                                        shape = RoundedCornerShape(20.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = Emerald700,
                                            contentColor = SurfaceWhite
                                        ),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                        modifier = Modifier.height(34.dp)
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("+ New chat", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }

                                    Spacer(modifier = Modifier.width(6.dp))

                                    if (currentUser != null) {
                                        IconButton(
                                            onClick = { showSignOutDialog = true },
                                            modifier = Modifier.size(34.dp)
                                        ) {
                                            Surface(
                                                modifier = Modifier.size(32.dp),
                                                shape = CircleShape,
                                                color = Emerald600
                                            ) {
                                                Box(contentAlignment = Alignment.Center) {
                                                    Text(
                                                        text = currentUser?.displayName?.firstOrNull()?.toString() ?: "U",
                                                        color = SurfaceWhite,
                                                        fontSize = 12.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            }
                                        }
                                    }
                                },
                                colors = TopAppBarDefaults.topAppBarColors(
                                    containerColor = SurfaceWhite,
                                    titleContentColor = Emerald950
                                )
                            )
                        }
                    ) { paddingValues ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(paddingValues)
                        ) {
                            when (activeTab) {
                                AppTab.CHAT, AppTab.HISTORY -> {
                                    ChatScreen(
                                        messages = messages,
                                        isSending = isSending,
                                        webResearchEnabled = webResearchEnabled,
                                        onToggleWebResearch = { viewModel.toggleWebResearch() },
                                        onSendMessage = { viewModel.sendChatMessage(it) }
                                    )
                                }
                                AppTab.WRITER -> {
                                    ScriptWriterScreen(
                                        isLoading = scriptLoading,
                                        generatedScript = scriptText,
                                        onGenerate = { topic, platform, duration, tone, audience ->
                                            viewModel.generateScript(topic, platform, duration, tone, audience)
                                        }
                                    )
                                }
                                AppTab.SEO -> {
                                    VideoSeoScreen(
                                        isLoading = seoLoading,
                                        seoData = seoData,
                                        onGenerate = { topic, keyword, category ->
                                            viewModel.generateSeo(topic, keyword, category)
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
