package com.kormi.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kormi.app.model.ChatApiRequest
import com.kormi.app.model.ChatMessage
import com.kormi.app.model.ChatSession
import com.kormi.app.model.ImagePayload
import com.kormi.app.model.MessagePayload
import com.kormi.app.model.ScriptApiRequest
import com.kormi.app.model.ScriptApiResponse
import com.kormi.app.model.SeoApiRequest
import com.kormi.app.model.SeoDataPayload
import com.kormi.app.model.UserAccount
import com.kormi.app.network.RetrofitClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class AppTab {
    CHAT, WRITER, SEO, HISTORY
}

class KormiViewModel : ViewModel() {

    private val _activeTab = MutableStateFlow(AppTab.CHAT)
    val activeTab: StateFlow<AppTab> = _activeTab.asStateFlow()

    private val _currentUser = MutableStateFlow<UserAccount?>(UserAccount())
    val currentUser: StateFlow<UserAccount?> = _currentUser.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _chatSessions = MutableStateFlow<List<ChatSession>>(emptyList())
    val chatSessions: StateFlow<List<ChatSession>> = _chatSessions.asStateFlow()

    private val _activeSessionId = MutableStateFlow<String?>(null)
    val activeSessionId: StateFlow<String?> = _activeSessionId.asStateFlow()

    private val _isSending = MutableStateFlow(false)
    val isSending: StateFlow<Boolean> = _isSending.asStateFlow()

    private val _webResearchEnabled = MutableStateFlow(true)
    val webResearchEnabled: StateFlow<Boolean> = _webResearchEnabled.asStateFlow()

    private val _attachedImageBase64 = MutableStateFlow<String?>(null)
    val attachedImageBase64: StateFlow<String?> = _attachedImageBase64.asStateFlow()

    private val _snackBarMessage = MutableStateFlow<String?>(null)
    val snackBarMessage: StateFlow<String?> = _snackBarMessage.asStateFlow()

    // Writer State
    private val _scriptLoading = MutableStateFlow(false)
    val scriptLoading: StateFlow<Boolean> = _scriptLoading.asStateFlow()

    private val _generatedScript = MutableStateFlow<String?>(null)
    val generatedScript: StateFlow<Boolean?> = MutableStateFlow(null) // or string
    val generatedScriptText = MutableStateFlow<String?>(null)

    // SEO State
    private val _seoLoading = MutableStateFlow(false)
    val seoLoading: StateFlow<Boolean> = _seoLoading.asStateFlow()

    private val _seoData = MutableStateFlow<SeoDataPayload?>(null)
    val seoData: StateFlow<SeoDataPayload?> = _seoData.asStateFlow()

    fun setTab(tab: AppTab) {
        _activeTab.value = tab
    }

    fun toggleWebResearch() {
        _webResearchEnabled.value = !_webResearchEnabled.value
    }

    fun attachImage(base64: String?) {
        _attachedImageBase64.value = base64
    }

    fun clearSnackBar() {
        _snackBarMessage.value = null
    }

    fun showToast(msg: String) {
        _snackBarMessage.value = msg
    }

    fun startNewChat() {
        _messages.value = emptyList()
        _activeSessionId.value = null
        _activeTab.value = AppTab.CHAT
        showToast("New chat started")
    }

    fun deleteSession(sessionId: String) {
        _chatSessions.value = _chatSessions.value.filter { it.id != sessionId }
        if (_activeSessionId.value == sessionId) {
            startNewChat()
        }
        showToast("Conversation deleted")
    }

    fun selectSession(session: ChatSession) {
        _activeSessionId.value = session.id
        _activeTab.value = AppTab.CHAT
    }

    fun sendChatMessage(prompt: String) {
        val trimmed = prompt.trim()
        val image = _attachedImageBase64.value
        if (trimmed.isEmpty() && image == null) return

        val userText = if (trimmed.isNotEmpty()) trimmed else "Please analyze this attached image."
        val userMsg = ChatMessage(
            role = "user",
            content = userText,
            imageBase64 = image
        )
        _messages.value = _messages.value + userMsg
        _attachedImageBase64.value = null
        _isSending.value = true

        // Create session title if first message
        if (_activeSessionId.value == null) {
            val title = if (userText.length > 32) userText.substring(0, 32) + "..." else userText
            val session = ChatSession(title = title)
            _activeSessionId.value = session.id
            _chatSessions.value = listOf(session) + _chatSessions.value
        }

        viewModelScope.launch {
            try {
                val history = _messages.value.map { m ->
                    MessagePayload(
                        role = m.role,
                        content = m.content,
                        image = m.imageBase64?.let { ImagePayload(data = it) }
                    )
                }

                val req = ChatApiRequest(
                    messages = history,
                    image = image?.let { ImagePayload(data = it) },
                    webResearch = _webResearchEnabled.value
                )

                val response = RetrofitClient.apiService.sendChatMessage(req)
                val reply = response.reply ?: response.error ?: "No response generated."
                val modelMsg = ChatMessage(
                    role = "model",
                    content = reply,
                    sources = response.sources ?: emptyList()
                )
                _messages.value = _messages.value + modelMsg
            } catch (e: Exception) {
                val errorMsg = ChatMessage(
                    role = "model",
                    content = "Connection error: ${e.localizedMessage ?: "Failed to reach server. Please check internet connection."}"
                )
                _messages.value = _messages.value + errorMsg
            } finally {
                _isSending.value = false
            }
        }
    }

    fun generateScript(
        topic: String,
        platform: String,
        duration: String,
        tone: String,
        audience: String
    ) {
        if (topic.isBlank()) {
            showToast("Please enter a video topic")
            return
        }
        _scriptLoading.value = true
        viewModelScope.launch {
            try {
                val req = ScriptApiRequest(
                    topic = topic,
                    platform = platform,
                    duration = duration,
                    tone = tone,
                    audience = audience,
                    webResearch = _webResearchEnabled.value
                )
                val res = RetrofitClient.apiService.generateScript(req)
                generatedScriptText.value = res.script ?: res.error ?: "Script generation completed."
                showToast("Script generated successfully!")
            } catch (e: Exception) {
                showToast("Failed to generate script: ${e.localizedMessage}")
            } finally {
                _scriptLoading.value = false
            }
        }
    }

    fun generateSeo(topic: String, keyword: String, category: String) {
        if (topic.isBlank()) {
            showToast("Please enter a video topic")
            return
        }
        _seoLoading.value = true
        viewModelScope.launch {
            try {
                val req = SeoApiRequest(
                    topic = topic,
                    keyword = keyword,
                    category = category
                )
                val res = RetrofitClient.apiService.generateSeo(req)
                _seoData.value = res.seoData
                showToast("SEO Kit generated successfully!")
            } catch (e: Exception) {
                showToast("Failed to generate SEO: ${e.localizedMessage}")
            } finally {
                _seoLoading.value = false
            }
        }
    }

    fun signOut() {
        _currentUser.value = null
        startNewChat()
        showToast("Signed out successfully")
    }

    fun signIn() {
        _currentUser.value = UserAccount()
        showToast("Welcome back to Kormi!")
    }
}
