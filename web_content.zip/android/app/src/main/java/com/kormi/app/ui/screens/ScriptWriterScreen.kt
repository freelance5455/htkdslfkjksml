package com.kormi.app.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kormi.app.theme.*

@Composable
fun ScriptWriterScreen(
    isLoading: Boolean,
    generatedScript: String?,
    onGenerate: (topic: String, platform: String, duration: String, tone: String, audience: String) -> Unit
) {
    var topic by remember { mutableStateOf("") }
    var platform by remember { mutableStateOf("YouTube (16:9)") }
    var duration by remember { mutableStateOf("3-5 Minutes") }
    var tone by remember { mutableStateOf("Engaging & Educational") }
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Emerald50)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            color = SurfaceWhite,
            shadowElevation = 1.dp
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.SmartDisplay, contentDescription = null, tint = Emerald700)
                    Text("AI Video Script Writer", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Emerald950)
                }

                OutlinedTextField(
                    value = topic,
                    onValueChange = { topic = it },
                    label = { Text("Video Topic or Idea") },
                    placeholder = { Text("e.g. 5 AI tools that will replace apps in 2026") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp)
                )

                // Platform Selector
                Text("Platform:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Slate700)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("YouTube (16:9)", "Shorts / Reels").forEach { p ->
                        FilterChip(
                            selected = platform == p,
                            onClick = { platform = p },
                            label = { Text(p, fontSize = 11.sp) }
                        )
                    }
                }

                // Duration Selector
                Text("Target Duration:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Slate700)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("1-2 Minutes", "3-5 Minutes", "8-10 Minutes").forEach { d ->
                        FilterChip(
                            selected = duration == d,
                            onClick = { duration = d },
                            label = { Text(d, fontSize = 11.sp) }
                        )
                    }
                }

                Button(
                    onClick = {
                        onGenerate(topic, platform, duration, tone, "General")
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Emerald700),
                    enabled = !isLoading && topic.isNotBlank()
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = SurfaceWhite, strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Writing Video Script...")
                    } else {
                        Text("Generate Video Script", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Generated Script Result Card
        if (generatedScript != null) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                color = SurfaceWhite,
                shadowElevation = 2.dp
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Generated Script", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Emerald950)
                        IconButton(onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("Script", generatedScript)
                            clipboard.setPrimaryClip(clip)
                        }) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = Emerald700)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = generatedScript,
                        fontSize = 12.sp,
                        color = Slate900,
                        lineHeight = 18.sp
                    )
                }
            }
        }
    }
}
