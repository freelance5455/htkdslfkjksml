package com.kormi.app.model

import com.google.gson.annotations.SerializedName
import java.util.UUID

data class GroundingSource(
    @SerializedName("title") val title: String,
    @SerializedName("url") val url: String
)

data class ImagePayload(
    @SerializedName("data") val data: String, // base64 data URI
    @SerializedName("mimeType") val mimeType: String = "image/jpeg"
)

data class MessagePayload(
    @SerializedName("role") val role: String,
    @SerializedName("content") val content: String,
    @SerializedName("image") val image: ImagePayload? = null
)

data class ChatApiRequest(
    @SerializedName("messages") val messages: List<MessagePayload>,
    @SerializedName("image") val image: ImagePayload? = null,
    @SerializedName("webResearch") val webResearch: Boolean = true
)

data class ChatApiResponse(
    @SerializedName("reply") val reply: String?,
    @SerializedName("sources") val sources: List<GroundingSource>?,
    @SerializedName("webResearchActive") val webResearchActive: Boolean?,
    @SerializedName("modelUsed") val modelUsed: String?,
    @SerializedName("error") val error: String?
)

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val role: String, // "user" or "model"
    val content: String,
    val imageBase64: String? = null,
    val sources: List<GroundingSource> = emptyList(),
    val timestamp: Long = System.currentTimeMillis()
)

data class ChatSession(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class ScriptApiRequest(
    @SerializedName("topic") val topic: String,
    @SerializedName("platform") val platform: String,
    @SerializedName("duration") val duration: String,
    @SerializedName("tone") val tone: String,
    @SerializedName("audience") val audience: String,
    @SerializedName("webResearch") val webResearch: Boolean = true
)

data class ScriptApiResponse(
    @SerializedName("script") val script: String?,
    @SerializedName("sources") val sources: List<GroundingSource>?,
    @SerializedName("error") val error: String?
)

data class SeoApiRequest(
    @SerializedName("topic") val topic: String,
    @SerializedName("keyword") val keyword: String,
    @SerializedName("category") val category: String
)

data class SeoTitleItem(
    @SerializedName("title") val title: String,
    @SerializedName("ctrScore") val ctrScore: Int,
    @SerializedName("rationale") val rationale: String
)

data class SeoMetrics(
    @SerializedName("primaryKeyword") val primaryKeyword: String,
    @SerializedName("searchVolume") val searchVolume: String,
    @SerializedName("competition") val competition: String,
    @SerializedName("trendScore") val trendScore: Int,
    @SerializedName("difficultyScore") val difficultyScore: Int,
    @SerializedName("opportunityRating") val opportunityRating: String
)

data class SeoApiResponse(
    @SerializedName("seoData") val seoData: SeoDataPayload?,
    @SerializedName("error") val error: String?
)

data class SeoDataPayload(
    @SerializedName("titles") val titles: List<SeoTitleItem>,
    @SerializedName("description") val description: String,
    @SerializedName("tags") val tags: List<String>,
    @SerializedName("metrics") val metrics: SeoMetrics
)

data class UserAccount(
    val uid: String = "user_default",
    val displayName: String = "Google User",
    val email: String = "mrmamunahmedbd@gmail.com",
    val photoUrl: String? = null,
    val dateOfBirth: String = "2000-01-01"
)
