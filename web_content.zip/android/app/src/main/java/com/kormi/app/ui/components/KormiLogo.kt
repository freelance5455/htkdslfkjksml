package com.kormi.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun KormiLogo(
    size: Dp = 36.dp,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height

        // 1. Deep Obsidian-Emerald Body Gradient
        val bodyBrush = Brush.radialGradient(
            colors = listOf(
                Color(0xFF065F46),
                Color(0xFF064E3B),
                Color(0xFF022C22),
                Color(0xFF011B15)
            ),
            center = Offset(w * 0.35f, h * 0.25f),
            radius = w * 0.85f
        )

        // Metallic Rim Gradient
        val rimBrush = Brush.linearGradient(
            colors = listOf(
                Color(0xFFA7F3D0),
                Color(0xFF34D399),
                Color(0xFF059669),
                Color(0xFF022C22)
            ),
            start = Offset(0f, 0f),
            end = Offset(w, h)
        )

        // Draw Base Squircle Shield
        val strokeW = w * 0.035f
        val radius = w * 0.26f
        drawRoundRect(
            brush = bodyBrush,
            size = Size(w, h),
            cornerRadius = CornerRadius(radius, radius)
        )
        drawRoundRect(
            brush = rimBrush,
            size = Size(w, h),
            cornerRadius = CornerRadius(radius, radius),
            style = Stroke(width = strokeW)
        )

        // 2. Gloss Highlight Arc
        val glossPath = Path().apply {
            moveTo(w * 0.06f, h * 0.28f)
            cubicTo(w * 0.06f, h * 0.15f, w * 0.15f, h * 0.06f, w * 0.28f, h * 0.06f)
            lineTo(w * 0.72f, h * 0.06f)
            cubicTo(w * 0.85f, h * 0.06f, w * 0.94f, h * 0.15f, w * 0.94f, h * 0.28f)
            cubicTo(w * 0.94f, h * 0.38f, w * 0.78f, h * 0.5f, w * 0.5f, h * 0.5f)
            cubicTo(w * 0.22f, h * 0.5f, w * 0.06f, h * 0.38f, w * 0.06f, h * 0.28f)
            close()
        }
        val glossBrush = Brush.verticalGradient(
            colors = listOf(
                Color(0x73FFFFFF),
                Color(0x26FFFFFF),
                Color(0x00FFFFFF)
            )
        )
        drawPath(path = glossPath, brush = glossBrush)

        // 3. Sculpted 3D 'K' Monogram
        // Vertical Spine
        val stemBrush = Brush.horizontalGradient(
            colors = listOf(
                Color(0xFFA7F3D0),
                Color(0xFF34D399),
                Color(0xFF059669),
                Color(0xFF047857)
            )
        )
        val spineX = w * 0.22f
        val spineY = h * 0.21f
        val spineW = w * 0.13f
        val spineH = h * 0.58f
        drawRoundRect(
            brush = stemBrush,
            topLeft = Offset(spineX, spineY),
            size = Size(spineW, spineH),
            cornerRadius = CornerRadius(spineW * 0.5f, spineW * 0.5f)
        )
        drawLine(
            color = Color(0xB3FFFFFF),
            start = Offset(spineX + spineW * 0.3f, spineY + spineH * 0.05f),
            end = Offset(spineX + spineW * 0.3f, spineY + spineH * 0.95f),
            strokeWidth = spineW * 0.15f,
            cap = StrokeCap.Round
        )

        // Diagonal Upper Arm
        val upperArmPath = Path().apply {
            moveTo(w * 0.30f, h * 0.53f)
            lineTo(w * 0.67f, h * 0.23f)
            cubicTo(w * 0.70f, h * 0.20f, w * 0.74f, h * 0.22f, w * 0.74f, h * 0.26f)
            cubicTo(w * 0.74f, h * 0.28f, w * 0.73f, h * 0.30f, w * 0.71f, h * 0.32f)
            lineTo(w * 0.41f, h * 0.58f)
            close()
        }
        val upperArmBrush = Brush.linearGradient(
            colors = listOf(Color(0xFF10B981), Color(0xFF34D399), Color(0xFFA7F3D0), Color(0xFFFFFFFF)),
            start = Offset(w * 0.3f, h * 0.53f),
            end = Offset(w * 0.74f, h * 0.23f)
        )
        drawPath(path = upperArmPath, brush = upperArmBrush)

        // Diagonal Lower Arm
        val lowerArmPath = Path().apply {
            moveTo(w * 0.31f, h * 0.50f)
            lineTo(w * 0.70f, h * 0.75f)
            cubicTo(w * 0.72f, h * 0.77f, w * 0.73f, h * 0.79f, w * 0.72f, h * 0.82f)
            cubicTo(w * 0.71f, h * 0.84f, w * 0.68f, h * 0.85f, w * 0.66f, h * 0.83f)
            lineTo(w * 0.27f, h * 0.57f)
            close()
        }
        val lowerArmBrush = Brush.linearGradient(
            colors = listOf(Color(0xFF059669), Color(0xFF10B981), Color(0xFF14B8A6)),
            start = Offset(w * 0.31f, h * 0.50f),
            end = Offset(w * 0.72f, h * 0.84f)
        )
        drawPath(path = lowerArmPath, brush = lowerArmBrush)

        // Center Nexus Dot
        drawCircle(
            color = Color(0xFF10B981),
            radius = w * 0.055f,
            center = Offset(w * 0.35f, h * 0.54f)
        )
        drawCircle(
            color = Color(0xFFA7F3D0),
            radius = w * 0.03f,
            center = Offset(w * 0.35f, h * 0.54f)
        )

        // Apex Lens Flare Spark
        val sparkCenter = Offset(w * 0.73f, h * 0.25f)
        drawCircle(
            color = Color(0xCCFFFFFF),
            radius = w * 0.035f,
            center = sparkCenter
        )
        drawLine(
            color = Color(0xFFFFFFFF),
            start = Offset(sparkCenter.x - w * 0.07f, sparkCenter.y),
            end = Offset(sparkCenter.x + w * 0.07f, sparkCenter.y),
            strokeWidth = 2f
        )
        drawLine(
            color = Color(0xFFFFFFFF),
            start = Offset(sparkCenter.x, sparkCenter.y - h * 0.07f),
            end = Offset(sparkCenter.x, sparkCenter.y + h * 0.07f),
            strokeWidth = 2f
        )
    }
}
