package com.kormi.app.network

import com.kormi.app.model.ChatApiRequest
import com.kormi.app.model.ChatApiResponse
import com.kormi.app.model.ScriptApiRequest
import com.kormi.app.model.ScriptApiResponse
import com.kormi.app.model.SeoApiRequest
import com.kormi.app.model.SeoApiResponse
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import java.util.concurrent.TimeUnit

interface KormiApiService {
    @POST("api/chat/message")
    suspend fun sendChatMessage(@Body request: ChatApiRequest): ChatApiResponse

    @POST("api/writer/generate")
    suspend fun generateScript(@Body request: ScriptApiRequest): ScriptApiResponse

    @POST("api/seo/generate")
    suspend fun generateSeo(@Body request: SeoApiRequest): SeoApiResponse
}

object RetrofitClient {
    // Connects directly to the existing Kormi server backend
    private const val BASE_URL = "https://ais-pre-4g34cathbtosdspxorbhqt-271702768652.asia-east1.run.app/"

    private val logging = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }

    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(logging)
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    val apiService: KormiApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(KormiApiService::class.java)
    }
}
