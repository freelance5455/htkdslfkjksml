package com.kormi.app.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kormi.app.model.SeoDataPayload
import com.kormi.app.theme.*

@Composable
fun VideoSeoScreen(
    isLoading: Boolean,
    seoData: SeoDataPayload?,
    onGenerate: (topic: String, keyword: String, category: String) -> Unit
) {
    var topic by remember { mutableStateOf("") }
    var keyword by remember { mutableStateOf("") }
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Emerald50)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            color = SurfaceWhite,
            shadowElevation = 1.dp
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.TrendingUp, contentDescription = null, tint = Emerald700)
                    Text("Video SEO & Keyword Generator", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Emerald950)
                }

                OutlinedTextField(
                    value = topic,
                    onValueChange = { topic = it },
                    label = { Text("Video Topic") },
                    placeholder = { Text("e.g. Best Coding Laptops 2026") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp)
                )

                OutlinedTextField(
                    value = keyword,
                    onValueChange = { keyword = it },
                    label = { Text("Primary Keyword (Optional)") },
                    placeholder = { Text("e.g. budget laptops 2026") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp)
                )

                Button(
                    onClick = {
                        onGenerate(topic, keyword, "Technology")
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Emerald700),
                    enabled = !isLoading && topic.isNotBlank()
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = SurfaceWhite, strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Analyzing Keywords & Rankings...")
                    } else {
                        Text("Generate Video SEO Kit", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (seoData != null) {
            // Metrics Cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    color = Emerald100
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("OPPORTUNITY", fontSize = 9.sp, fontWeight = FontWeight.Black, color = Emerald900)
                        Text(seoData.metrics.opportunityRating, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Emerald950)
                    }
                }
                Surface(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    color = SurfaceWhite
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("SEARCH VOLUME", fontSize = 9.sp, fontWeight = FontWeight.Black, color = Slate500)
                        Text(seoData.metrics.searchVolume, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Slate900)
                    }
                }
            }

            // High CTR Titles
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                color = SurfaceWhite,
                shadowElevation = 1.dp
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Top High-CTR Titles", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Emerald950)
                    seoData.titles.forEach { titleItem ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFFF7FAF8), RoundedCornerShape(10.dp))
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = titleItem.title,
                                modifier = Modifier.weight(1f),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Slate900
                            )
                            IconButton(onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("Title", titleItem.title)
                                clipboard.setPrimaryClip(clip)
                            }) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = Emerald700, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}
