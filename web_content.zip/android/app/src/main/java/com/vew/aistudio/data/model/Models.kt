package com.vew.aistudio.data.model

data class VoiceItem(
    val id: String,
    val name: String,
    val language: String,
    val languageCode: String,
    val gender: String,
    val style: String,
    val accent: String
)

data class VoicesResponse(
    val voices: List<VoiceItem>
)

data class HealthResponse(
    val status: String,
    val connected: Boolean,
    val version: String?
)

data class TTSRequest(
    val text: String,
    val voice: String,
    val language: String,
    val speed: Float = 1.0f,
    val pitch: Float = 1.0f
)

data class TTSResponse(
    val fileId: String,
    val url: String,
    val duration: Float,
    val text: String
)

data class ImageRequest(
    val prompt: String,
    val aspectRatio: String = "1:1",
    val imageStyle: String = "Realistic"
)

data class ImageResponse(
    val fileId: String,
    val imageUrl: String,
    val prompt: String
)

data class MusicRequest(
    val lyrics: String? = null,
    val style: String,
    val mood: String,
    val language: String
)

data class MusicResponse(
    val fileId: String,
    val audioUrl: String,
    val coverUrl: String?,
    val title: String,
    val duration: Int
)

data class ProjectItem(
    val id: String,
    val title: String,
    val type: String,
    val mediaUrl: String,
    val createdAt: Long = System.currentTimeMillis()
)
