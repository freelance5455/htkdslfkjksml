package com.vew.aistudio.ui.screens

import android.media.AudioAttributes
import android.media.MediaPlayer
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vew.aistudio.data.api.NetworkClient
import com.vew.aistudio.data.model.TTSRequest
import com.vew.aistudio.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun VoiceStudioScreen(
    onBack: () -> Unit
) {
    var textInput by remember { mutableStateOf("Welcome to VEW AI Studio on Android. Professional speech synthesis is ready.") }
    var selectedLanguage by remember { mutableStateOf("English") }
    var selectedVoice by remember { mutableStateOf("en-kore") }
    var speechSpeed by remember { mutableStateOf(1.0f) }

    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var audioUrlResult by remember { mutableStateOf<String?>(null) }
    var isPlaying by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()
    var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }

    DisposableEffect(Unit) {
        onDispose {
            mediaPlayer?.release()
            mediaPlayer = null
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Slate950)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Top Back Row
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text("AI Voice Studio", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Enter Text to Synthesize", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Slate300)
        Spacer(modifier = Modifier.height(6.dp))

        OutlinedTextField(
            value = textInput,
            onValueChange = { textInput = it },
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
                .clip(RoundedCornerShape(16.dp)),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Slate900,
                unfocusedContainerColor = Slate900,
                focusedBorderColor = Blue500,
                unfocusedBorderColor = Slate800,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Speed Slider
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Speaking Rate", fontSize = 12.sp, color = Slate400)
            Text("${String.format("%.1f", speechSpeed)}x", fontSize = 12.sp, color = Blue400, fontWeight = FontWeight.Bold)
        }
        Slider(
            value = speechSpeed,
            onValueChange = { speechSpeed = it },
            valueRange = 0.5f..2.0f,
            steps = 6,
            colors = SliderDefaults.colors(
                thumbColor = Blue500,
                activeTrackColor = Blue600,
                inactiveTrackColor = Slate800
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Generate Button
        Button(
            onClick = {
                if (textInput.isBlank()) return@Button
                isLoading = true
                errorMessage = null
                scope.launch {
                    try {
                        val response = NetworkClient.api.generateTTS(
                            TTSRequest(
                                text = textInput,
                                voice = selectedVoice,
                                language = selectedLanguage,
                                speed = speechSpeed
                            )
                        )
                        audioUrlResult = response.url
                    } catch (e: Exception) {
                        errorMessage = e.localizedMessage ?: "Failed to synthesize speech"
                    } finally {
                        isLoading = false
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Blue600),
            enabled = !isLoading
        ) {
            if (isLoading) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                Spacer(modifier = Modifier.width(10.dp))
                Text("Synthesizing Voice...")
            } else {
                Icon(Icons.Default.VolumeUp, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Generate AI Voice", fontWeight = FontWeight.Bold)
            }
        }

        errorMessage?.let { msg ->
            Spacer(modifier = Modifier.height(12.dp))
            Surface(
                color = Rose500.copy(alpha = 0.15f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = msg,
                    color = Rose500,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }

        // Result Audio Player
        audioUrlResult?.let { url ->
            Spacer(modifier = Modifier.height(20.dp))
            Surface(
                color = Slate900,
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Synthesized Voice Output", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        IconButton(
                            onClick = {
                                if (isPlaying) {
                                    mediaPlayer?.pause()
                                    isPlaying = false
                                } else {
                                    if (mediaPlayer == null) {
                                        mediaPlayer = MediaPlayer().apply {
                                            setAudioAttributes(
                                                AudioAttributes.Builder()
                                                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                                                    .setUsage(AudioAttributes.USAGE_MEDIA)
                                                    .build()
                                            )
                                            setDataSource(url)
                                            prepareAsync()
                                            setOnPreparedListener {
                                                start()
                                                isPlaying = true
                                            }
                                            setOnCompletionListener {
                                                isPlaying = false
                                            }
                                        }
                                    } else {
                                        mediaPlayer?.start()
                                        isPlaying = true
                                    }
                                }
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .background(Blue600, RoundedCornerShape(24.dp))
                        ) {
                            Icon(
                                if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = Color.White
                            )
                        }

                        Column {
                            Text("Audio Playback Ready", fontSize = 13.sp, color = Color.White, fontWeight = FontWeight.Medium)
                            Text("Tap to play on phone speakers", fontSize = 11.sp, color = Slate400)
                        }
                    }
                }
            }
        }
    }
}
