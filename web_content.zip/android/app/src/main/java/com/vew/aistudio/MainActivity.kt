package com.vew.aistudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.vew.aistudio.ui.components.BottomNavigationBar
import com.vew.aistudio.ui.components.Screen
import com.vew.aistudio.ui.screens.*
import com.vew.aistudio.ui.theme.Slate950
import com.vew.aistudio.ui.theme.VEWAiStudioTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VEWAiStudioTheme {
                MainAppContainer()
            }
        }
    }
}

@Composable
fun MainAppContainer() {
    var currentScreen by remember { mutableStateOf(Screen.Home) }
    var activeTool by remember { mutableStateOf<String?>(null) }

    Scaffold(
        containerColor = Slate950,
        bottomBar = {
            if (activeTool == null) {
                BottomNavigationBar(
                    currentScreen = currentScreen,
                    onScreenSelected = {
                        currentScreen = it
                        activeTool = null
                    }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (activeTool != null) {
                when (activeTool) {
                    "tts" -> VoiceStudioScreen(onBack = { activeTool = null })
                    else -> {
                        VoiceStudioScreen(onBack = { activeTool = null })
                    }
                }
            } else {
                when (currentScreen) {
                    Screen.Home -> HomeScreen(
                        onNavigateToCreate = { currentScreen = Screen.Create },
                        onSelectTool = { toolId -> activeTool = toolId }
                    )
                    Screen.Create -> CreateScreen(
                        onSelectTool = { toolId -> activeTool = toolId }
                    )
                    Screen.Projects -> ProjectsScreen(
                        onNavigateToCreate = { currentScreen = Screen.Create }
                    )
                    Screen.History -> HistoryScreen()
                    Screen.Settings -> SettingsScreen()
                }
            }
        }
    }
}
