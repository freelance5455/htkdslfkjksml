package com.vew.aistudio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vew.aistudio.ui.theme.*

data class ToolDefinition(
    val id: String,
    val title: String,
    val description: String,
    val category: String,
    val icon: ImageVector,
    val accentColor: Color
)

@Composable
fun CreateScreen(
    onSelectTool: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }

    val categories = listOf("All", "Audio & Voice", "Music", "Video & Image", "Writing")

    val tools = listOf(
        ToolDefinition("tts", "AI Voice (TTS)", "Convert text to natural human speech in 16+ languages", "Audio & Voice", Icons.Default.RecordVoiceOver, Blue500),
        ToolDefinition("translator", "Audio Translator & Dubbing", "Translate audio files and dub with natural voice", "Audio & Voice", Icons.Default.Translate, Cyan500),
        ToolDefinition("music", "AI Music Studio", "Compose complete songs with custom lyrics and genres", "Music", Icons.Default.MusicNote, Violet500),
        ToolDefinition("ghazal", "Ghazal & Nasheed", "Dedicated acoustic, devotional, and traditional poetry", "Music", Icons.Default.Favorite, Rose500),
        ToolDefinition("image", "AI Image Generator", "Create photorealistic visuals in various aspect ratios", "Video & Image", Icons.Default.Image, Emerald500),
        ToolDefinition("image-to-video", "Image to Video", "Bring still images to life with cinematic camera motion", "Video & Image", Icons.Default.MovieFilter, Amber500),
        ToolDefinition("text-to-video", "Text to Video", "Synthesize full video scenes from prompt descriptions", "Video & Image", Icons.Default.Videocam, Violet400),
        ToolDefinition("enhance-audio", "Audio Enhancer", "Reduce noise and isolate vocals with studio DSP", "Audio & Voice", Icons.Default.Tune, Blue400),
        ToolDefinition("subtitles", "Subtitle Generator", "Auto transcribe and sync SRT, VTT, and TXT captions", "Video & Image", Icons.Default.Subtitles, Cyan500),
        ToolDefinition("script", "Script & Lyrics Assistant", "Generate viral scripts and poetic verses for production", "Writing", Icons.Default.Edit, Emerald500)
    )

    val filteredTools = tools.filter { tool ->
        (selectedCategory == "All" || tool.category == selectedCategory) &&
        (tool.title.contains(searchQuery, ignoreCase = true) || tool.description.contains(searchQuery, ignoreCase = true))
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Slate950)
            .padding(16.dp)
    ) {
        Text(
            text = "AI Creation Tools",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Text(
            text = "Select a studio tool to start producing media",
            fontSize = 12.sp,
            color = Slate400
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search AI tools...", color = Slate400, fontSize = 13.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Slate400) },
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp)),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Slate900,
                unfocusedContainerColor = Slate900,
                focusedBorderColor = Blue500,
                unfocusedBorderColor = Slate800,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            ),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Category Filter Chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            categories.take(3).forEach { cat ->
                FilterChip(
                    selected = selectedCategory == cat,
                    onClick = { selectedCategory = cat },
                    label = { Text(cat, fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Blue600,
                        selectedLabelColor = Color.White,
                        containerColor = Slate900,
                        labelColor = Slate400
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Tools List
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filteredTools) { tool ->
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { onSelectTool(tool.id) },
                    color = Slate900,
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(tool.accentColor.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(tool.icon, contentDescription = null, tint = tool.accentColor)
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = tool.title,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = tool.description,
                                fontSize = 11.sp,
                                color = Slate400,
                                maxLines = 2
                            )
                        }

                        Icon(
                            Icons.Default.ChevronRight,
                            contentDescription = null,
                            tint = Slate700
                        )
                    }
                }
            }
        }
    }
}
