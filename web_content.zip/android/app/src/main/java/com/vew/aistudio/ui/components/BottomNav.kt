package com.vew.aistudio.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.vector.ImageVector
import com.vew.aistudio.ui.theme.Slate800
import com.vew.aistudio.ui.theme.Slate900
import com.vew.aistudio.ui.theme.Slate400
import com.vew.aistudio.ui.theme.Blue500

enum class Screen(val title: String, val icon: ImageVector) {
    Home("Home", Icons.Default.Home),
    Create("Create", Icons.Default.AddCircleOutline),
    Projects("Projects", Icons.Default.Folder),
    History("History", Icons.Default.History),
    Settings("Settings", Icons.Default.Settings)
}

@Composable
fun BottomNavigationBar(
    currentScreen: Screen,
    onScreenSelected: (Screen) -> Unit
) {
    NavigationBar(
        containerColor = Slate900,
        contentColor = Slate400
    ) {
        Screen.values().forEach { screen ->
            NavigationBarItem(
                selected = currentScreen == screen,
                onClick = { onScreenSelected(screen) },
                icon = { Icon(screen.icon, contentDescription = screen.title) },
                label = { Text(screen.title) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Blue500,
                    selectedTextColor = Blue500,
                    unselectedIconColor = Slate400,
                    unselectedTextColor = Slate400,
                    indicatorColor = Slate800
                )
            )
        }
    }
}
