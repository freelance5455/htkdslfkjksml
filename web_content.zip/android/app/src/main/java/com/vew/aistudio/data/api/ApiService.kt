package com.vew.aistudio.data.api

import com.vew.aistudio.data.model.*
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import java.util.concurrent.TimeUnit

interface ApiService {
    @GET("/api/health")
    suspend fun getHealth(): HealthResponse

    @GET("/api/voices")
    suspend fun getVoices(): VoicesResponse

    @POST("/api/tts")
    suspend fun generateTTS(@Body request: TTSRequest): TTSResponse

    @POST("/api/image")
    suspend fun generateImage(@Body request: ImageRequest): ImageResponse

    @POST("/api/music")
    suspend fun generateMusic(@Body request: MusicRequest): MusicResponse
}

object NetworkClient {
    // Default URL pointing to the deployed VEW AI Studio Cloud backend
    private var currentBaseUrl = "https://ais-pre-xgypb6cwr5boupmfhqrd26-890206935679.asia-southeast1.run.app/"

    fun setBaseUrl(newUrl: String) {
        currentBaseUrl = if (newUrl.endsWith("/")) newUrl else "$newUrl/"
        retrofitInstance = null
    }

    fun getBaseUrl(): String = currentBaseUrl

    private var retrofitInstance: Retrofit? = null

    private fun getRetrofit(): Retrofit {
        if (retrofitInstance == null) {
            val logging = HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BODY
            }
            val client = OkHttpClient.Builder()
                .addInterceptor(logging)
                .connectTimeout(60, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .build()

            retrofitInstance = Retrofit.Builder()
                .baseUrl(currentBaseUrl)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
        }
        return retrofitInstance!!
    }

    val api: ApiService
        get() = getRetrofit().create(ApiService::class.java)
}
