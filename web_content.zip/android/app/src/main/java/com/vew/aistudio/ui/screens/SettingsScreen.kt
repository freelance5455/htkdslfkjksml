package com.vew.aistudio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vew.aistudio.data.api.NetworkClient
import com.vew.aistudio.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen() {
    var backendUrlInput by remember { mutableStateOf(NetworkClient.getBaseUrl()) }
    var connectionStatus by remember { mutableStateOf("Testing...") }
    var isChecking by remember { mutableStateOf(false) }
    var autoSaveEnabled by remember { mutableStateOf(true) }

    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        isChecking = true
        try {
            val res = NetworkClient.api.getHealth()
            connectionStatus = if (res.connected) "Connected to Studio Server" else "Error: Not connected"
        } catch (e: Exception) {
            connectionStatus = "Offline (Local mode)"
        } finally {
            isChecking = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Slate950)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("Studio Settings", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("App configurations & Cloud backend connection", fontSize = 12.sp, color = Slate400)

        Spacer(modifier = Modifier.height(20.dp))

        // Connection Card
        Surface(
            color = Slate900,
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Backend Server Status", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Surface(
                        color = if (connectionStatus.contains("Connected")) Emerald500.copy(alpha = 0.2f) else Rose500.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = if (connectionStatus.contains("Connected")) "Online" else "Check Server",
                            color = if (connectionStatus.contains("Connected")) Emerald500 else Rose500,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(connectionStatus, fontSize = 12.sp, color = Slate400)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Backend URL Input (Proxy API safety - no hardcoded API keys in app)
        Surface(
            color = Slate900,
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Backend Server URL", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text("AI Keys are securely proxied through this backend", fontSize = 11.sp, color = Slate400)

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = backendUrlInput,
                    onValueChange = { backendUrlInput = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp)),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Slate800,
                        unfocusedContainerColor = Slate800,
                        focusedBorderColor = Blue500,
                        unfocusedBorderColor = Slate700,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        NetworkClient.setBaseUrl(backendUrlInput)
                        scope.launch {
                            isChecking = true
                            try {
                                val res = NetworkClient.api.getHealth()
                                connectionStatus = if (res.connected) "Connected to Studio Server" else "Error"
                            } catch (e: Exception) {
                                connectionStatus = "Disconnected (${e.localizedMessage})"
                            } finally {
                                isChecking = false
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Blue600),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Save & Reconnect", fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Preferences
        Surface(
            color = Slate900,
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("General Preferences", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Auto-Save Generated Media", fontSize = 13.sp, color = Color.White)
                        Text("Automatically store files to Projects tab", fontSize = 11.sp, color = Slate400)
                    }
                    Switch(
                        checked = autoSaveEnabled,
                        onCheckedChange = { autoSaveEnabled = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Blue600
                        )
                    )
                }
            }
        }
    }
}
