package com.colorrush.game;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
