package bg.horaryai.app

import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class HoraryApi {
    // Emulator only. Set a production HTTPS URL before release.
    private val baseUrl = BuildConfig.HORARY_API_BASE_URL.trimEnd('/')
    private val client = OkHttpClient()
    private val json = Json { ignoreUnknownKeys = true }
    private val mediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun ask(payload: HoraryRequest): HoraryResponse = withContext(Dispatchers.IO) {
        val body = json.encodeToString(HoraryRequest.serializer(), payload).toRequestBody(mediaType)
        val request = Request.Builder().url("$baseUrl/horary").post(body).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Сървърна грешка: ${response.code}")
            json.decodeFromString(HoraryResponse.serializer(), response.body?.string() ?: error("Празен отговор"))
        }
    }
}
