package bg.horaryai.app

import kotlinx.serialization.Serializable

@Serializable
data class HoraryRequest(
    val question: String,
    val askedAtLocal: String,
    val place: String,
    val latitude: Double,
    val longitude: Double,
    val timezone: String = "Europe/Sofia"
)

@Serializable
data class HoraryResponse(
    val verdict: String,
    val confidencePercent: Int,
    val confidenceMeaning: String,
    val summary: String,
    val detailedExplanation: String,
    val supportingFactors: List<String>,
    val challengingFactors: List<String>,
    val timing: String,
    val chartFacts: List<String>,
    val warnings: List<String>,
    val disclaimer: String
)
