package bg.horaryai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HoraryApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HoraryApp() {
    val api = remember { HoraryApi() }
    val scope = rememberCoroutineScope()
    var question by remember { mutableStateOf("") }
    var place by remember { mutableStateOf("Бургас, България") }
    var latitude by remember { mutableStateOf("42.5065") }
    var longitude by remember { mutableStateOf("27.4689") }
    var timezone by remember { mutableStateOf("Europe/Sofia") }
    var askedAt by remember { mutableStateOf(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"))) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var result by remember { mutableStateOf<HoraryResponse?>(null) }

    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("Хорар AI") }) }) { padding ->
            Column(
                Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Задай хорарен въпрос", style = MaterialTheme.typography.headlineSmall)
                Text("Използвай един конкретен въпрос. Датата, часът и мястото са за момента, в който задаваш въпроса.", style = MaterialTheme.typography.bodyMedium)
                OutlinedTextField(question, { question = it }, label = { Text("Какво искаш да попиташ?") },
                    placeholder = { Text("Напр. Ще излезем ли на среща?") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(askedAt, { askedAt = it }, label = { Text("Местна дата и час (YYYY-MM-DD HH:MM)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(place, { place = it }, label = { Text("Град и държава") }, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(latitude, { latitude = it }, label = { Text("Ширина") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(longitude, { longitude = it }, label = { Text("Дължина") }, modifier = Modifier.weight(1f))
                }
                OutlinedTextField(timezone, { timezone = it }, label = { Text("Часова зона (напр. Europe/Sofia)") }, modifier = Modifier.fillMaxWidth())
                Button(
                    enabled = !loading && question.isNotBlank() && place.isNotBlank(),
                    onClick = {
                        val lat = latitude.toDoubleOrNull()
                        val lon = longitude.toDoubleOrNull()
                        if (lat == null || lon == null) { error = "Въведи валидни координати."; return@Button }
                        loading = true; error = null; result = null
                        scope.launch {
                            try { result = api.ask(HoraryRequest(question.trim(), askedAt.trim(), place.trim(), lat, lon, timezone.trim())) }
                            catch (e: Exception) { error = e.message ?: "Неуспешна заявка." }
                            finally { loading = false }
                        }
                    }, modifier = Modifier.fillMaxWidth()
                ) { Text(if (loading) "Изчисляване..." else "Анализирай въпроса") }

                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                result?.let { r ->
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(r.verdict, style = MaterialTheme.typography.headlineSmall)
                            Text("Съгласуваност на показателите: ${r.confidencePercent}%")
                            Text(r.confidenceMeaning, style = MaterialTheme.typography.bodySmall)
                            HorizontalDivider()
                            Text("Кратък отговор", style = MaterialTheme.typography.titleMedium)
                            Text(r.summary)
                            Text("Подробно обяснение", style = MaterialTheme.typography.titleMedium)
                            Text(r.detailedExplanation)
                            Text("Какво подкрепя извода", style = MaterialTheme.typography.titleMedium)
                            r.supportingFactors.forEach { Text("• $it") }
                            Text("Какво затруднява извода", style = MaterialTheme.typography.titleMedium)
                            r.challengingFactors.forEach { Text("• $it") }
                            Text("Времеви ориентир", style = MaterialTheme.typography.titleMedium)
                            Text(r.timing)
                            Text("Факти от картата", style = MaterialTheme.typography.titleMedium)
                            r.chartFacts.forEach { Text("• $it") }
                            if (r.warnings.isNotEmpty()) {
                                Text("Предупреждения", style = MaterialTheme.typography.titleMedium)
                                r.warnings.forEach { Text("• $it") }
                            }
                            Text(r.disclaimer, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                Text("Астрологията е символична практика, а не научно потвърден метод за предсказване. Процентът показва съгласуваността на тълкуването, а не реална вероятност за събитие.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
