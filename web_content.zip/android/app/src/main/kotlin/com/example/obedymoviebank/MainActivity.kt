package com.example.obedymoviebank

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
