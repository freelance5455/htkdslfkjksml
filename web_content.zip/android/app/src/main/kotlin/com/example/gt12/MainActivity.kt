package com.example.gt12

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
