package com.laden.console

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
