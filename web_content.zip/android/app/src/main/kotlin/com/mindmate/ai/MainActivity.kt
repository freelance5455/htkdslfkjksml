package com.mindmate.ai

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
