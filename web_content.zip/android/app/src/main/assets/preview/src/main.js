// Hebrew Calendar Fallback Loader
(function() {
  var w = window as any;
  if (w.__bundleFallbackAttempted) return;
  w.__bundleFallbackAttempted = true;
  var s = document.createElement('script');
  s.src = './assets/app-bundle.js';
  s.onerror = function() {
    var s2 = document.createElement('script');
    s2.src = '/preview/assets/app-bundle.js';
    document.body.appendChild(s2);
  };
  document.body.appendChild(s);
})();
export {};
