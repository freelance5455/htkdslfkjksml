var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_vite = require("vite");
var syncStore = /* @__PURE__ */ new Map();
async function startServer() {
  const app = (0, import_express.default)();
  const PORT = 3e3;
  app.use(import_express.default.json({ limit: "10mb" }));
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", time: (/* @__PURE__ */ new Date()).toISOString() });
  });
  app.get("/api/download-ipk", (req, res) => {
    const ipkPath = import_path.default.join(process.cwd(), "hebrew-calendar_1.0.0_all.ipk");
    res.download(ipkPath, "hebrew-calendar_1.0.0_all.ipk", (err) => {
      if (err) {
        res.status(404).send("IPK installer package is currently being generated or not found.");
      }
    });
  });
  app.get(["/api/download-zip", "/api/download-project-zip"], async (req, res) => {
    const prebuiltPath = import_path.default.join(process.cwd(), "project.zip");
    if (import_fs.default.existsSync(prebuiltPath)) {
      res.setHeader("Content-Type", "application/zip");
      res.setHeader("Content-Disposition", 'attachment; filename="hebrew-calendar-source.zip"');
      return res.sendFile(prebuiltPath);
    }
    try {
      let addDirectoryRecursively = function(currentPath, zipPath = "") {
        const items = import_fs.default.readdirSync(currentPath);
        for (const item of items) {
          if (excludeList.has(item)) continue;
          const fullPath = import_path.default.join(currentPath, item);
          const entryZipPath = zipPath ? `${zipPath}/${item}` : item;
          const stat = import_fs.default.statSync(fullPath);
          if (stat.isDirectory()) {
            addDirectoryRecursively(fullPath, entryZipPath);
          } else {
            zip.addLocalFile(fullPath, zipPath);
          }
        }
      };
      const AdmZip = (await import("adm-zip")).default;
      const rootDir = process.cwd();
      const zip = new AdmZip();
      const excludeList = /* @__PURE__ */ new Set([
        "node_modules",
        ".git",
        "dist.zip",
        "project.zip",
        "hebrew-calendar_1.0.0_all.ipk",
        "app-export.tar.gz"
      ]);
      addDirectoryRecursively(rootDir);
      const zipBuffer = zip.toBuffer();
      res.set({
        "Content-Type": "application/zip",
        "Content-Disposition": 'attachment; filename="hebrew-calendar-source.zip"',
        "Content-Length": zipBuffer.length
      });
      res.send(zipBuffer);
    } catch (err) {
      console.error("Error generating project zip:", err);
      const fallbackPath = import_path.default.join(process.cwd(), "project.zip");
      if (import_fs.default.existsSync(fallbackPath)) {
        res.download(fallbackPath, "hebrew-calendar-source.zip");
      } else {
        res.status(500).send("Could not generate project ZIP file.");
      }
    }
  });
  app.get("/api/sync/room/:roomId", (req, res) => {
    const { roomId } = req.params;
    const pin = req.query.pin || "";
    const cleanRoomId = roomId.toUpperCase().trim();
    const room = syncStore.get(cleanRoomId);
    if (!room) {
      return res.status(404).json({ error: "Sync room not found. You can create a new room with this ID." });
    }
    if (room.pin && room.pin !== pin) {
      return res.status(401).json({ error: "Incorrect room PIN / Passphrase." });
    }
    return res.json({
      success: true,
      roomId: cleanRoomId,
      updatedAt: room.updatedAt,
      devices: room.devices,
      data: room.data
    });
  });
  app.post("/api/sync/room/:roomId", (req, res) => {
    const { roomId } = req.params;
    const { pin, data } = req.body;
    const cleanRoomId = roomId.toUpperCase().trim();
    const existing = syncStore.get(cleanRoomId);
    if (existing && existing.pin && existing.pin !== (pin || "")) {
      return res.status(401).json({ error: "Incorrect room PIN." });
    }
    const deviceName = data?.deviceName || "Unknown Device";
    const devices = existing?.devices || [];
    if (!devices.includes(deviceName)) {
      devices.push(deviceName);
    }
    const updatedRoom = {
      roomId: cleanRoomId,
      pin: pin || "",
      data: data || {},
      updatedAt: Date.now(),
      devices
    };
    syncStore.set(cleanRoomId, updatedRoom);
    return res.json({
      success: true,
      roomId: cleanRoomId,
      timestamp: updatedRoom.updatedAt,
      devicesCount: devices.length
    });
  });
  app.get("/web/index.html", (req, res) => {
    res.redirect("/");
  });
  app.get(["/sw.js", "/manifest.json"], (req, res, next) => {
    res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
    res.setHeader("Pragma", "no-cache");
    res.setHeader("Expires", "0");
    next();
  });
  const distAssetsPath = import_path.default.join(process.cwd(), "dist", "assets");
  const backupAssetsPath = import_path.default.join(process.cwd(), "android", "app", "src", "main", "assets", "public", "assets");
  app.use("/assets", import_express.default.static(distAssetsPath));
  if (import_fs.default.existsSync(backupAssetsPath)) {
    app.use("/assets", import_express.default.static(backupAssetsPath));
  }
  app.get("/assets/:file", (req, res, next) => {
    const fileName = req.params.file;
    const pathsToCheck = [distAssetsPath, backupAssetsPath].filter((p) => import_fs.default.existsSync(p));
    if (fileName.endsWith(".js")) {
      for (const dir of pathsToCheck) {
        const allAssets = import_fs.default.readdirSync(dir);
        const targetJs = allAssets.find((f) => f.startsWith("index-") && f.endsWith(".js")) || allAssets.find((f) => f.endsWith(".js"));
        if (targetJs) {
          res.setHeader("Content-Type", "text/javascript");
          return res.sendFile(import_path.default.join(dir, targetJs));
        }
      }
      res.setHeader("Content-Type", "text/javascript");
      return res.send('console.warn("Requested asset not found, refreshing..."); if (window.location.search.indexOf("refreshed") === -1) { window.location.href = window.location.origin + "/?refreshed=" + Date.now(); }');
    }
    if (fileName.endsWith(".css")) {
      for (const dir of pathsToCheck) {
        const allAssets = import_fs.default.readdirSync(dir);
        const targetCss = allAssets.find((f) => f.startsWith("index-") && f.endsWith(".css")) || allAssets.find((f) => f.endsWith(".css"));
        if (targetCss) {
          res.setHeader("Content-Type", "text/css");
          return res.sendFile(import_path.default.join(dir, targetCss));
        }
      }
      res.setHeader("Content-Type", "text/css");
      return res.send("/* CSS fallback */");
    }
    next();
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Hebrew Calendar App server listening on port ${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
