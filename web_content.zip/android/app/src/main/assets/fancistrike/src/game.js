(() => {
"use strict";
const $=id=>document.getElementById(id);
const loading=$("loading"), lobby=$("lobby"), bar=$("loadBar"), loadText=$("loadText");
let progress=0;
const loadingTimer=setInterval(()=>{
  progress=Math.min(100,progress+Math.floor(Math.random()*13)+7);
  bar.style.width=progress+"%";
  loadText.textContent=progress<35?"LOADING ASSETS...":progress<70?"PREPARING OPERATOR...":progress<95?"CONNECTING TO LOBBY...":"READY";
  if(progress>=100){clearInterval(loadingTimer);setTimeout(()=>{loading.classList.add("hidden");lobby.classList.remove("hidden")},300)}
},180);

const panel=$("panel"), content=$("panelContent"), toast=$("toast");
let timer;
function showToast(t){toast.textContent=t;toast.classList.add("show");clearTimeout(timer);timer=setTimeout(()=>toast.classList.remove("show"),1400)}
function showPage(page){
 const data={
  profile:["PROFILE","FANCI","Level 01 • Rookie","Matches: 0","K/D: —","Wins: 0"],
  weapons:["WEAPONS","PRIMARY • Assault Rifle","SECONDARY • Pistol","MELEE • Tactical Knife","Weapon inventory is ready for future 3D assets."],
  vault:["VAULT","Weapon Skins","Operator Skins","Charms","Emotes","Vault inventory is ready for future assets."],
  operator:["CHARACTER","Operator: FANCI","Class: Assault","Status: Available","Character customization will be added next."],
  events:["EVENTS","Daily Login","Weekly Missions","Season Rewards"],
  shop:["SHOP","Weapon Skins","Operator Bundles","Crates","Shop system will be added later."],
  settings:["SETTINGS","Graphics: Balanced","FPS Target: 60","Audio: ON","Controls: Touch"]
 };
 const d=data[page]||data.profile;
 content.innerHTML=`<h2>${d[0]}</h2><p>${d[1]}</p><div class="cards">${d.slice(2).map(x=>`<div class="card"><b>${x.split(" • ")[0]}</b><small>${x.includes(" • ")?x.split(" • ")[1]:"Available"}</small></div>`).join("")}</div>`;
 panel.classList.remove("hidden");
}
document.querySelectorAll("[data-page]").forEach(b=>b.addEventListener("click",()=>showPage(b.dataset.page)));
$("close").addEventListener("click",()=>panel.classList.add("hidden"));
panel.addEventListener("click",e=>{if(e.target===panel)panel.classList.add("hidden")});
$("play").addEventListener("click",()=>showToast("MATCHMAKING — GAMEPLAY V3 NEXT"));
$("settings").addEventListener("click",()=>showPage("settings"));
})();