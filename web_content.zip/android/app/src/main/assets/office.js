/* MegaIA — leitura de Word (.docx), Excel (.xlsx) e PowerPoint (.pptx) direto no aparelho.
   Extrai só o texto (sem enviar o arquivo inteiro ao Gemini). Usa o JSZip embutido, então funciona offline. */
(function(){
 'use strict';
 var MAX=150000;
 function decode(s){return s.replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&apos;/g,"'").replace(/&#(\d+);/g,function(m,n){return String.fromCharCode(+n)}).replace(/&#x([0-9a-f]+);/gi,function(m,n){return String.fromCharCode(parseInt(n,16))}).replace(/&amp;/g,'&')}
 function ext(name){var m=/\.([a-z0-9]+)$/i.exec(name||'');return m?m[1].toLowerCase():''}
 function isOffice(f){return ['docx','xlsx','pptx'].indexOf(ext(f.name))>=0}
 function isLegacy(f){return ['doc','xls','ppt'].indexOf(ext(f.name))>=0}
 function runs(xml,tag){var out=[],re=new RegExp('<'+tag+'(?:\\s[^>]*)?>([\\s\\S]*?)</'+tag+'>','g'),m;while((m=re.exec(xml)))out.push(decode(m[1]));return out}
 /* Parágrafo: junta <w:t>/<a:t>, trata tabulação e quebra de linha. */
 function paraText(p,t){
  p=p.replace(/<w:tab\/>|<a:tab\/>/g,'<'+t+'>\t</'+t+'>').replace(/<w:br\/>|<a:br\/>/g,'<'+t+'>\n</'+t+'>');
  return runs(p,t).join('')}
 function esc(t){return t.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
 function docxTable(tbl){
  var rows=tbl.match(/<w:tr\b[\s\S]*?<\/w:tr>/g)||[],out='';
  rows.forEach(function(r){var cells=(r.match(/<w:tc\b[\s\S]*?<\/w:tc>/g)||[]).map(function(c){
    return c.split(/<\/w:p>/).map(function(p){return paraText(p,'w:t')}).join(' ').replace(/\s+/g,' ').trim()});
   out+='<w:p><w:r><w:t>'+esc(cells.join(' | '))+'</w:t></w:r></w:p>'});
  return '<w:p><w:r><w:t>[tabela]</w:t></w:r></w:p>'+out}
 function docxText(xml){
  var body=xml.replace(/<w:tbl>[\s\S]*?<\/w:tbl>/g,docxTable);
  var paras=body.split(/<\/w:p>/),out=[];
  for(var i=0;i<paras.length;i++){var t=paraText(paras[i],'w:t');var st=/<w:pStyle w:val="(?:Heading|Titulo|Ttulo)(\d)"/i.exec(paras[i]);
   if(st&&t.trim())t='#'.repeat(Math.min(6,+st[1]))+' '+t.trim();out.push(t)}
  return out.join('\n').replace(/\n{3,}/g,'\n\n').trim()}
 function pptxSlide(xml){
  var paras=xml.split(/<\/a:p>/),out=[];
  for(var i=0;i<paras.length;i++){var t=paraText(paras[i],'a:t');if(t.trim())out.push(t)}
  return out.join('\n')}
 function colIndex(ref){var m=/^([A-Z]+)/.exec(ref||'');if(!m)return 0;var n=0;for(var i=0;i<m[1].length;i++)n=n*26+(m[1].charCodeAt(i)-64);return n-1}
 function sheetRows(xml,shared){
  var rows=[],rr=/<row\b[^>]*>([\s\S]*?)<\/row>/g,m;
  while((m=rr.exec(xml))){
   var cells=[],cr=/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g,c;
   while((c=cr.exec(m[1]))){
    var at=c[1],inner=c[2]||'',ref=(/\br="([A-Z]+\d+)"/.exec(at)||[])[1],ty=(/\bt="(\w+)"/.exec(at)||[])[1],val='';
    var v=/<v>([\s\S]*?)<\/v>/.exec(inner);
    if(ty==='s'&&v)val=shared[+v[1]]||'';
    else if(ty==='inlineStr')val=runs(inner,'t').join('');
    else if(v)val=decode(v[1]);
    cells[colIndex(ref)]=val}
   var line=[];for(var i=0;i<cells.length;i++)line.push(cells[i]===undefined?'':String(cells[i]).replace(/[\t\r\n]+/g,' '));
   while(line.length&&line[line.length-1]==='')line.pop();
   if(line.length)rows.push(line.join('\t'))}
  return rows}
 async function load(file){
  if(!window.JSZip)throw new Error('Leitor de Office não carregou. Reinicie o app.');
  try{return await JSZip.loadAsync(file)}catch(_){throw new Error('Não consegui abrir "'+file.name+'". O arquivo pode estar corrompido ou protegido por senha.')}}
 function num(a,b){return (+(/(\d+)\.xml$/.exec(a)||[0,0])[1])-(+(/(\d+)\.xml$/.exec(b)||[0,0])[1])}
 async function extract(file){
  var e=ext(file.name),zip=await load(file),out='';
  if(e==='docx'){
   var d=zip.file('word/document.xml');if(!d)throw new Error('"'+file.name+'" não parece um Word válido.');
   out=docxText(await d.async('string'));
   var names=Object.keys(zip.files).filter(function(n){return /^word\/(footnotes|endnotes)\.xml$/.test(n)});
   for(var i=0;i<names.length;i++){var x=docxText(await zip.file(names[i]).async('string'));if(x)out+='\n\n['+(/foot/.test(names[i])?'Notas de rodapé':'Notas de fim')+']\n'+x}}
  else if(e==='pptx'){
   var sl=Object.keys(zip.files).filter(function(n){return /^ppt\/slides\/slide\d+\.xml$/.test(n)}).sort(num),parts=[];
   if(!sl.length)throw new Error('"'+file.name+'" não parece um PowerPoint válido.');
   for(var s=0;s<sl.length;s++){var t=pptxSlide(await zip.file(sl[s]).async('string'));
    var nf=zip.file(sl[s].replace('slides/slide','notesSlides/notesSlide'));var nt=nf?pptxSlide(await nf.async('string')).replace(/^\d+\s*$/gm,'').trim():'';
    parts.push('## Slide '+(s+1)+'\n'+(t||'(sem texto)')+(nt?'\n[Notas do apresentador]\n'+nt:''))}
   out=parts.join('\n\n')}
  else if(e==='xlsx'){
   var shared=[],ss=zip.file('xl/sharedStrings.xml');
   if(ss){var sx=await ss.async('string'),sr=/<si\b[^>]*>([\s\S]*?)<\/si>/g,mm;while((mm=sr.exec(sx)))shared.push(runs(mm[1],'t').join(''))}
   var wb=zip.file('xl/workbook.xml'),rel=zip.file('xl/_rels/workbook.xml.rels'),sheets=[];
   if(wb&&rel){var wx=await wb.async('string'),rx=await rel.async('string'),map={},rm,rre=/<Relationship\b[^>]*>/g;
    while((rm=rre.exec(rx))){var id=(/\bId="([^"]+)"/.exec(rm[0])||[])[1],tg=(/\bTarget="([^"]+)"/.exec(rm[0])||[])[1];if(id&&tg)map[id]=tg.replace(/^\/?(xl\/)?/,'xl/')}
    var sre=/<sheet\b[^>]*>/g,sm;while((sm=sre.exec(wx))){var nm=(/\bname="([^"]*)"/.exec(sm[0])||[])[1],rid=(/\br:id="([^"]+)"/.exec(sm[0])||[])[1];if(map[rid])sheets.push({name:decode(nm||'Planilha'),path:map[rid]})}}
   if(!sheets.length)sheets=Object.keys(zip.files).filter(function(n){return /^xl\/worksheets\/sheet\d+\.xml$/.test(n)}).sort(num).map(function(p,i){return {name:'Planilha '+(i+1),path:p}});
   if(!sheets.length)throw new Error('"'+file.name+'" não parece um Excel válido.');
   var chunks=[];
   for(var k=0;k<sheets.length;k++){var f=zip.file(sheets[k].path);if(!f)continue;var rows=sheetRows(await f.async('string'),shared);
    chunks.push('## Planilha: '+sheets[k].name+' ('+rows.length+' linhas)\n'+rows.join('\n'))}
   out=chunks.join('\n\n')}
  out=out.trim();
  if(!out)throw new Error('Não encontrei texto em "'+file.name+'".');
  var cut=out.length>MAX;
  return {text:'[Conteúdo do arquivo '+file.name+']\n'+out.slice(0,MAX)+(cut?'\n[... arquivo cortado: só os primeiros '+MAX.toLocaleString('pt-BR')+' caracteres foram enviados]':''),cut:cut}}
 window.MegaOffice={isOffice:isOffice,isLegacy:isLegacy,extract:extract,_docxText:docxText,_pptxSlide:pptxSlide,_sheetRows:sheetRows};
})();
