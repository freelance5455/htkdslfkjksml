const base=[
{id:1,title:'تويوتا كامري 2020',price:12500000,cat:'سيارات',loc:'تعز',emoji:'🚗',desc:'سيارة نظيفة بحالة ممتازة، جاهزة للاستخدام.'},
{id:2,title:'آيفون 15 برو',price:380000,cat:'جوالات',loc:'تعز',emoji:'📱',desc:'جهاز نظيف مع ملحقاته.'},
{id:3,title:'شقة للبيع',price:18000000,cat:'عقارات',loc:'تعز',emoji:'🏠',desc:'شقة مناسبة للسكن في موقع ممتاز.'},
{id:4,title:'لابتوب احترافي',price:650000,cat:'أجهزة',loc:'تعز',emoji:'💻',desc:'لابتوب مناسب للعمل والدراسة.'}
];
let ads=JSON.parse(localStorage.getItem('taiz_ads')||'null')||base;
let activeCat='الكل';
function money(n){return Number(n).toLocaleString('ar-YE')+' ريال'}
function render(){
 const q=(document.getElementById('search')?.value||'').toLowerCase();
 let list=ads.filter(a=>(activeCat==='الكل'||a.cat===activeCat)&&(!q||a.title.toLowerCase().includes(q)||a.cat.includes(q)));
 document.getElementById('ads').innerHTML=list.map(a=>`<article class="card" onclick="detail(${a.id})"><div class="photo">${a.emoji}</div><div class="info"><b>${a.title}</b><div class="price">${money(a.price)}</div><div class="loc">📍 ${a.loc} • ${a.cat}</div></div></article>`).join('')||'<p>لا توجد إعلانات.</p>';
}
function show(id){document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));document.getElementById(id).classList.add('active');if(id==='home')render();window.scrollTo(0,0)}
function filterCat(c){activeCat=c;show('home')}
function detail(id){let a=ads.find(x=>x.id===id);document.getElementById('detailBody').innerHTML=`<div class="photo">${a.emoji}</div><h2>${a.title}</h2><h2 class="price">${money(a.price)}</h2><p>📍 ${a.loc}</p><p>${a.desc}</p><button class="primary" onclick="alert('يمكن ربط هذا الزر لاحقًا بالمراسلة أو الاتصال داخل التطبيق')">تواصل مع المعلن</button>`;document.getElementById('detail').style.display='block'}
function closeDetail(){document.getElementById('detail').style.display='none'}
function addAd(e){e.preventDefault();let a={id:Date.now(),title:title.value,price:Number(price.value),cat:cat.value,loc:loc.value||'تعز',emoji:{سيارات:'🚗',جوالات:'📱',عقارات:'🏠',أجهزة:'💻'}[cat.value],desc:desc.value};ads.unshift(a);localStorage.setItem('taiz_ads',JSON.stringify(ads));e.target.reset();alert('تم نشر الإعلان على هذا الجهاز بنجاح');show('home')}
render();
