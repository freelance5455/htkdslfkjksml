import { h, icon, toast, fmtDate, fmtMoney, openSheet, confirmDialog, todayISO, debounce, norm } from './util.js';
import { t, optLabel, ifieldLabel } from './i18n.js';
import { state, putInterv, delInterv, putDevice } from './store.js';
import { IFIELDS, CODES } from './schema.js';
import { deviceById } from './logic.js';
import { buildInput, badge } from './form.js';
import { nav } from './nav.js';
import { scheduleSoon } from './notify.js';

const toneOfType = (x) => (x === 'corrective' ? 'danger' : x === 'preventive' ? 'ok' : 'info');
const toneOfIS = (x) => (x === 'closed' ? 'ok' : x === 'ongoing' ? 'warn' : x === 'parts' ? 'danger' : 'muted');

export function intervRow(r, showDevice = true) {
  const d = deviceById(r.devId);
  return h('button', { class: 'row', onclick: () => nav.push('interv-edit', { uid: r.uid }) },
    h('div', { class: 'row-main' },
      h('div', { class: 'row-t' }, fmtDate(r.date), ' · ', optLabel('itype', r.type) || '—'),
      h('div', { class: 'row-s' }, showDevice ? `${d ? (d.desig || '') + ' — ' : ''}${r.devId}${d && d.hop ? ' · ' + d.hop : ''}` : ''),
      r.desc ? h('div', { class: 'row-s clamp' }, r.desc) : null),
    h('div', { class: 'row-end col' }, badge(toneOfIS(r.status), optLabel('istatus', r.status) || '—'), r.cost ? h('small', { class: 'muted' }, fmtMoney(r.cost)) : null));
}

let mf = { q: '', type: '' };
export function maintView() {
  const el = h('div', { class: 'page' }), list = h('div', { class: 'list flat' }), count = h('div', { class: 'muted count' });
  const q = h('input', { class: 'input search', type: 'search', placeholder: t('maint.search'), value: mf.q });
  const chips = h('div', { class: 'chips' });
  const defs = [['', t('inv.all')], ['open', t('maint.open')], ['corrective', t('c.itype.corrective')], ['preventive', t('c.itype.preventive')], ['calibration', t('c.itype.calibration')]];
  const render = () => {
    const rows = state.intervs.filter((r) => {
      if (mf.type === 'open') { if (!(r.status === 'ongoing' || r.status === 'parts')) return false; }
      else if (mf.type && r.type !== mf.type) return false;
      if (mf.q) { const d = deviceById(r.devId) || {}; const hay = norm([r.devId, d.desig, d.hop, r.desc, r.cause, r.parts, r.notes].join(' ')); if (!mf.q.split(' ').every((w) => hay.includes(norm(w)))) return false; }
      return true;
    }).sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0));
    count.textContent = t('maint.count', { n: rows.length });
    list.replaceChildren(...(rows.length ? rows.slice(0, 200).map((r) => intervRow(r)) : [h('div', { class: 'empty small' }, h('p', null, state.intervs.length ? t('inv.noMatch') : t('maint.empty')))]));
    chips.replaceChildren(...defs.map(([k, l]) => h('button', { class: 'chip' + (mf.type === k ? ' on' : ''), onclick: () => { mf.type = k; render(); } }, l)));
  };
  q.addEventListener('input', debounce(() => { mf.q = q.value; render(); }, 150));
  render();
  el.append(h('div', { class: 'toolbar' }, h('div', { class: 'searchbox' }, icon('search', 20), q)), chips, count, list);
  return { title: t('nav.maintenance'), el, tab: 'maint', fab: { label: t('maint.add'), onClick: () => nav.push('interv-edit', {}) } };
}

// ---------- formulaire d'intervention ----------
export function intervEditView({ uid, devId }) {
  const src = state.intervs.find((r) => r.uid === uid);
  const base = src ? { ...src } : { date: todayISO(), devId: devId || '', type: 'preventive', status: 'closed', by: 'internal' };
  const inputs = {}, el = h('form', { class: 'page form card pad', novalidate: true });
  for (const f of IFIELDS) {
    const lbl = f.k === 'cost' ? ifieldLabel(f.k) + (state.settings.currency ? ` (${state.settings.currency})` : '') : ifieldLabel(f.k);
    const b = buildInput(f.k === 'devId' ? { ...f, type: 'text' } : f, base[f.k], lbl); inputs[f.k] = b;
    if (f.k === 'devId') {
      const dl = h('datalist', { id: 'devlist' }, state.devices.map((d) => h('option', { value: d.id }, `${d.desig || ''} — ${d.hop || ''}`)));
      b.ctl.setAttribute('list', 'devlist'); b.ctl.setAttribute('autocapitalize', 'characters'); b.node.append(dl);
      const info = h('div', { class: 'hint' }); b.node.append(info);
      const upd = () => { const d = deviceById(b.get()); info.textContent = d ? `${d.desig || ''} · ${d.hop || '—'} · ${d.service || ''}` : (b.get() ? t('maint.unknownDev') : ''); };
      b.ctl.addEventListener('input', upd); upd();
    }
    el.append(b.node);
  }
  // options de synchronisation avec l'appareil
  const syncBox = h('input', { type: 'checkbox', id: 'syncdev', checked: true });
  const syncRow = h('label', { class: 'check', for: 'syncdev' }, syncBox, h('span', { id: 'synctxt' }));
  const refresh = () => {
    const ty = inputs.type.get(), st = inputs.status.get(), d = deviceById(inputs.devId.get());
    let txt = '';
    if (st === 'closed' && d) {
      if (ty === 'preventive') txt = t('maint.syncMp');
      else if (['calibration', 'safety', 'qc'].includes(ty)) txt = t('maint.syncCal');
      else if (ty === 'corrective' && d.statut === 'repair') txt = t('maint.syncBack');
    }
    syncRow.hidden = !txt; syncRow.querySelector('span').textContent = txt;
  };
  ['type', 'status', 'devId'].forEach((k) => inputs[k].ctl.addEventListener('input', refresh)); refresh();
  el.append(syncRow);
  const err = h('div', { class: 'form-err', role: 'alert' }); el.append(err);
  el.addEventListener('submit', async (e) => {
    e.preventDefault();
    const r = { ...base }; for (const f of IFIELDS) r[f.k] = inputs[f.k].get();
    if (!r.date) { err.textContent = t('maint.errDate'); return; }
    if (!r.devId) { err.textContent = t('maint.errDev'); return; }
    await putInterv(r);
    const d = deviceById(r.devId);
    if (d && !syncRow.hidden && syncBox.checked) {
      const nd = { ...d };
      if (r.type === 'preventive') { if (!nd.lmp || r.date > nd.lmp) nd.lmp = r.date; }
      else if (['calibration', 'safety', 'qc'].includes(r.type)) { if (!nd.lcal || r.date > nd.lcal) nd.lcal = r.date; }
      else if (r.type === 'corrective' && nd.statut === 'repair') nd.statut = 'in_service';
      await putDevice(nd);
    }
    scheduleSoon(); toast(t('common.saved')); nav.back();
  });
  const actions = [h('button', { type: 'button', class: 'btn text', onclick: () => nav.back() }, t('common.cancel')), h('button', { type: 'submit', class: 'btn primary' }, icon('check', 18), t('common.save'))];
  el.append(h('div', { class: 'sticky-actions' }, actions));
  const bar = src ? [h('button', { class: 'icon-btn', 'aria-label': t('common.delete'), onclick: async () => { if (await confirmDialog({ title: t('maint.deleteTitle'), message: t('maint.deleteMsg'), okLabel: t('common.delete'), danger: true })) { await delInterv(src.uid); scheduleSoon(); toast(t('common.deleted')); nav.back(); } } }, icon('delete'))] : [];
  return { title: src ? t('maint.edit') : t('maint.add'), el, tab: 'maint', actions: bar };
}

// ---------- actions rapides depuis la fiche appareil ----------
export function quickDone(d, type) {
  const date = h('input', { type: 'date', class: 'input', value: todayISO() });
  const by = h('select', { class: 'input' }, CODES.iby.map((c) => h('option', { value: c }, optLabel('iby', c))));
  const note = h('textarea', { class: 'input', rows: 2, placeholder: t('if.desc') });
  openSheet({
    title: t(type === 'preventive' ? 'dev.doneMaint' : 'dev.doneCal'),
    body: h('div', null, h('p', { class: 'muted' }, `${d.desig || ''} · ${d.id}`), h('div', { class: 'field' }, h('label', null, t('if.date')), date), h('div', { class: 'field' }, h('label', null, t('if.by')), by), h('div', { class: 'field' }, h('label', null, t('if.desc')), note)),
    actions: [{ label: t('common.cancel'), cls: 'text' }, { label: t('common.save'), cls: 'primary', onClick: async () => {
      if (!date.value) return false;
      await putInterv({ date: date.value, devId: d.id, type, by: by.value, desc: note.value.trim(), status: 'closed', downtime: '', cost: '' });
      const nd = { ...d }; if (type === 'preventive') { if (!nd.lmp || date.value > nd.lmp) nd.lmp = date.value; } else if (!nd.lcal || date.value > nd.lcal) nd.lcal = date.value;
      await putDevice(nd); scheduleSoon(); toast(t('common.saved')); nav.refresh();
    } }],
  });
}
export function declareFailure(d) {
  const date = h('input', { type: 'date', class: 'input', value: todayISO() });
  const desc = h('textarea', { class: 'input', rows: 3, placeholder: t('dev.failurePh') });
  const down = h('input', { type: 'checkbox', id: 'dwn', checked: true });
  openSheet({
    title: t('dev.failure'),
    body: h('div', null, h('p', { class: 'muted' }, `${d.desig || ''} · ${d.id}`), h('div', { class: 'field' }, h('label', null, t('if.date')), date), h('div', { class: 'field' }, h('label', null, t('if.desc')), desc),
      h('label', { class: 'check', for: 'dwn' }, down, h('span', null, t('dev.failureSet')))),
    actions: [{ label: t('common.cancel'), cls: 'text' }, { label: t('common.save'), cls: 'primary', onClick: async () => {
      if (!date.value) return false;
      await putInterv({ date: date.value, devId: d.id, type: 'corrective', by: 'internal', desc: desc.value.trim(), status: 'ongoing', downtime: '', cost: '' });
      if (down.checked) await putDevice({ ...d, statut: 'repair' });
      scheduleSoon(); toast(t('common.saved')); nav.refresh();
    } }],
  });
}
