// Verrouillage par code PIN (stocké sous forme de hash salé, jamais en clair)
import { h, icon, toast } from './util.js';
import { t } from './i18n.js';
import { state, saveSettings } from './store.js';

async function sha(text) {
  if (crypto.subtle) { const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text)); return [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, '0')).join(''); }
  let x = 5381; for (const c of text) x = ((x << 5) + x + c.charCodeAt(0)) | 0; return String(x);
}
const salt = () => Math.random().toString(36).slice(2) + Date.now().toString(36);
export async function setPin(pin) { const s = salt(); state.settings.pin = { ...state.settings.pin, enabled: true, salt: s, hash: await sha(s + pin) }; await saveSettings(); }
export async function checkPin(pin) { const p = state.settings.pin; return (await sha(p.salt + pin)) === p.hash; }

let locked = false;
export const isLocked = () => locked;

// pad : saisie d'un code à 4 chiffres. mode 'unlock' ou 'new'
export function pinPad({ title, sub, onDone, cancel }) {
  let val = '';
  const dots = h('div', { class: 'dots' }, [0, 1, 2, 3].map(() => h('i')));
  const msg = h('div', { class: 'pin-msg' }, sub || '');
  const upd = () => [...dots.children].forEach((d, i) => d.classList.toggle('on', i < val.length));
  const press = async (k) => {
    if (k === 'del') val = val.slice(0, -1); else if (val.length < 4) val += k;
    upd();
    if (val.length === 4) { const v = val; val = ''; const ok = await onDone(v, msg); setTimeout(upd, 120); if (ok === false) { dots.classList.add('shake'); setTimeout(() => dots.classList.remove('shake'), 400); } }
  };
  const keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', cancel ? 'cancel' : '', '0', 'del'];
  return h('div', { class: 'pinpad' }, h('div', { class: 'pin-icon' }, icon('lock', 36)), h('h2', null, title), dots, msg,
    h('div', { class: 'keys' }, keys.map((k) => k === '' ? h('span') : h('button', { type: 'button', class: 'key', onclick: () => (k === 'cancel' ? cancel() : press(k)) }, k === 'del' ? '⌫' : k === 'cancel' ? t('common.cancel') : k))));
}

export function showLock() {
  if (!state.settings.pin.enabled || locked) return;
  locked = true;
  const el = document.getElementById('lock'); el.hidden = false;
  const render = () => el.replaceChildren(pinPad({
    title: t('lock.title'), sub: t('lock.enter'),
    onDone: async (v, msg) => { if (await checkPin(v)) { locked = false; el.hidden = true; el.replaceChildren(); return true; } msg.textContent = t('lock.wrong'); return false; },
  }));
  render();
}
let hiddenAt = 0;
export function trackLock() {
  const away = () => { hiddenAt = Date.now(); };
  const back = () => { if (hiddenAt && state.settings.pin.enabled && Date.now() - hiddenAt >= (+state.settings.pin.lockAfterMin || 0) * 60000) showLock(); hiddenAt = 0; };
  document.addEventListener('visibilitychange', () => (document.hidden ? away() : back()));
  const App = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App;
  if (App && App.addListener) App.addListener('appStateChange', (s) => (s.isActive ? back() : away()));
}
