import { h, icon, fmtNum, fmtMoney, fmtDate } from './util.js';
import { t, optLabel } from './i18n.js';
import { state } from './store.js';
import { kpis, dueItems, byHospital, byStatus, C } from './logic.js';
import { badge, toneOfM, toneOfStatut, dueText } from './form.js';
import { nav } from './nav.js';
import { setFilter } from './view-inventory.js';

const pct = (x) => (x * 100).toFixed(0) + ' %';

function tile(label, value, tone, onClick, sub) {
  return h('button', { class: 'tile ' + (tone || ''), onclick: onClick }, h('div', { class: 'tile-v' }, value), h('div', { class: 'tile-l' }, label), sub ? h('div', { class: 'tile-s' }, sub) : null);
}
const go = (f) => () => { setFilter(f); nav.go('inv'); };

export function dashView() {
  const K = kpis(), el = h('div', { class: 'page' });
  if (!state.devices.length) {
    el.append(h('div', { class: 'empty' }, icon('list', 48), h('h3', null, t('dash.emptyTitle')), h('p', null, t('dash.emptyText')),
      h('div', { class: 'row-gap' }, h('button', { class: 'btn primary', onclick: () => nav.push('device-edit', {}) }, t('inv.add')), h('button', { class: 'btn outline', onclick: () => nav.go('settings') }, t('dash.importDemo')))));
    return { title: t('app.name'), el, tab: 'dash' };
  }
  // Bannière de sauvegarde
  const lb = state.settings.lastBackup;
  const daysSince = lb ? Math.floor((Date.now() - new Date(lb)) / 86400000) : null;
  if (lb === '' || daysSince > 30) {
    el.append(h('button', { class: 'banner warn', onclick: () => nav.go('settings') }, icon('cloud', 20), h('span', null, lb === '' ? t('dash.backupNever') : t('dash.backupOld', { n: daysSince }))));
  }
  el.append(h('div', { class: 'tiles' },
    tile(t('kpi.total'), fmtNum(K.tot), '', go({})),
    tile(t('kpi.avail'), pct(K.avail), K.avail < 0.85 ? 'warn' : 'ok', go({ statut: 'in_service' }), t('kpi.availSub', { a: K.serv, b: K.tot - K.scrapped })),
    tile(t('kpi.mpOver'), K.mpOver, K.mpOver ? 'danger' : 'ok', go({ smp: 'overdue' })),
    tile(t('kpi.calOver'), K.calOver, K.calOver ? 'danger' : 'ok', go({ scal: 'overdue' })),
    tile(t('kpi.critOver'), K.critOver, K.critOver ? 'danger' : 'ok', go({ crit: 'critical', quick: 'overdue' })),
    tile(t('kpi.down'), K.down, K.down ? 'warn' : 'ok', go({ quick: 'down' })),
    tile(t('kpi.soon'), K.mpSoon + K.calSoon, K.mpSoon + K.calSoon ? 'warn' : '', go({ quick: 'soon' }), t('kpi.soonSub', { n: state.settings.alertDays })),
    tile(t('kpi.eol'), K.eol, K.eol ? 'warn' : '', go({ obs: 'eol' }), K.eolSoon ? t('kpi.eolSub', { n: K.eolSoon }) : ''),
  ));

  // À traiter
  const due = dueItems();
  const sec = h('section', { class: 'card' }, h('div', { class: 'card-h' }, h('h3', null, t('dash.todo')), due.length > 8 ? h('button', { class: 'link', onclick: go({ quick: 'attention' }) }, t('dash.seeAll', { n: due.length })) : null));
  if (!due.length) sec.append(h('p', { class: 'muted pad' }, t('dash.allGood')));
  due.slice(0, 8).forEach((x) => sec.append(h('button', { class: 'row', onclick: () => nav.push('device', { uid: x.d.uid }) },
    h('div', { class: 'row-main' }, h('div', { class: 'row-t' }, x.d.desig || x.d.id, x.d.crit === 'critical' ? badge('danger', t('c.crit.critical'), 'sm') : null),
      h('div', { class: 'row-s' }, `${x.d.id} · ${x.d.hop || '—'} · ${t(x.kind === 'maint' ? 'dash.maint' : 'dash.cal')}`)),
    h('div', { class: 'row-end' }, badge(toneOfM(x.st), dueText(x.date, x.st))))));
  el.append(sec);

  // Par hôpital
  const H = byHospital(), max = Math.max(1, ...H.map((x) => x.n));
  const hs = h('section', { class: 'card' }, h('div', { class: 'card-h' }, h('h3', null, t('dash.byHospital'))));
  H.forEach((x) => hs.append(h('button', { class: 'hrow', onclick: go({ hop: x.name }) },
    h('div', { class: 'hrow-top' }, h('b', null, x.name || t('common.unassigned')), h('span', null, fmtNum(x.n))),
    h('div', { class: 'bar' }, h('i', { class: 'seg ok', style: { width: (x.serv / max) * 100 + '%' } }), h('i', { class: 'seg warn', style: { width: (x.down / max) * 100 + '%' } }), h('i', { class: 'seg rest', style: { width: ((x.n - x.serv - x.down) / max) * 100 + '%' } })),
    h('div', { class: 'hrow-sub' }, t('dash.hospSub', { s: x.serv, d: x.down, m: x.mpOver, c: x.calOver })))));
  hs.append(h('div', { class: 'legend' }, h('span', null, h('i', { class: 'dot ok' }), t('c.statut.in_service')), h('span', null, h('i', { class: 'dot warn' }), t('dash.downLegend')), h('span', null, h('i', { class: 'dot rest' }), t('dash.otherLegend'))));
  el.append(hs);

  // Par statut
  const S = byStatus(), tot = state.devices.length;
  const ss = h('section', { class: 'card' }, h('div', { class: 'card-h' }, h('h3', null, t('dash.byStatus'))));
  const stack = h('div', { class: 'stack' });
  Object.entries(S).forEach(([k, n]) => stack.append(h('i', { class: 'seg ' + toneOfStatut(k), style: { width: (n / tot) * 100 + '%' }, title: optLabel('statut', k) })));
  ss.append(stack);
  Object.entries(S).sort((a, b) => b[1] - a[1]).forEach(([k, n]) => ss.append(h('button', { class: 'lrow', onclick: go({ statut: k }) }, h('span', null, h('i', { class: 'dot ' + toneOfStatut(k) }), k ? optLabel('statut', k) : '—'), h('span', null, `${n} · ${pct(n / tot)}`))));
  el.append(ss);

  // Chiffres clés
  const kc = h('section', { class: 'card' }, h('div', { class: 'card-h' }, h('h3', null, t('dash.figures'))));
  const line = (a, b) => kc.append(h('div', { class: 'lrow static' }, h('span', null, a), h('b', null, b)));
  line(t('kpi.mpRate'), pct(K.mpRate));
  line(t('kpi.critical'), K.critical);
  line(t('kpi.noCover'), K.noCover);
  line(t('kpi.vigi'), K.vigi);
  line(t('kpi.openInterv'), K.openInterv);
  line(t('kpi.corrN'), K.corrN);
  line(t('kpi.corrCost'), fmtMoney(K.corrCost) || '0');
  line(t('kpi.corrDown'), K.corrDown.toFixed(1));
  line(t('kpi.value'), fmtMoney(K.value) || '0');
  el.append(kc);
  return { title: t('app.name'), el, tab: 'dash' };
}
