// Données de démonstration (fictives) pour essayer l'application
import { state, bulkPut, saveSettings, DEFAULT_SETTINGS } from './store.js';
import { SEEDS } from './schema.js';
import { addDays, addMonths, todayISO, isoOf } from './util.js';

export async function loadDemo() {
  const S = state.settings, L = SEEDS[S.lang] || SEEDS.fr, fr = S.lang !== 'en';
  const hosp = S.hospitals.length ? S.hospitals.slice(0, 3) : L.hospitals;
  for (const h of hosp) if (!S.hospitals.includes(h)) S.hospitals.push(h);
  if (!S.services.length) S.services = [...L.services]; if (!S.types.length) S.types = [...L.types];
  const T = S.types, V = S.services, today = todayISO();
  const catalog = [
    [0, 'Mindray', 'BeneVision N17', 'critical', 1, 'IIb', 6, 12, 10, 8500],
    [1, 'Dräger', 'Evita V500', 'critical', 1, 'IIb', 6, 12, 12, 24000],
    [2, 'B. Braun', 'Infusomat Space', 'important', 0, 'IIb', 12, 12, 8, 2200],
    [3, 'B. Braun', 'Perfusor Space', 'important', 0, 'IIb', 12, 12, 8, 1800],
    [4, 'Philips', 'HeartStart XL+', 'critical', 4, 'IIb', 6, 12, 10, 7500],
    [5, 'GE', 'MAC 2000', 'standard', 8, 'IIa', 12, 12, 10, 3100],
    [6, 'Samsung', 'HS40', 'important', 3, 'IIa', 12, 12, 10, 18000],
    [9, 'Getinge', 'GSS 67', 'important', 10, 'IIb', 6, 12, 15, 35000],
    [12, 'Atom', 'Dual Incu i', 'critical', 5, 'IIb', 6, 12, 10, 9500],
    [13, 'GE', 'Giraffe Warmer', 'critical', 5, 'IIb', 6, 12, 10, 8800],
    [14, 'Philips', 'EverFlo', 'important', 1, 'IIa', 12, 12, 8, 1500],
    [10, 'Maquet', 'Alphamaxx', 'important', 2, 'I', 12, 24, 15, 20000],
  ];
  const stat = ['in_service', 'in_service', 'in_service', 'in_service', 'in_service', 'repair', 'in_service', 'out_of_service', 'in_service', 'stock', 'to_scrap', 'in_service'];
  const devices = [], intervs = []; let n = 0;
  hosp.forEach((hop, hi) => {
    catalog.forEach((c, ci) => {
      if ((hi + ci) % 3 === 2 && ci > 8) return;
      n++;
      const age = ((ci * 3 + hi * 2) % 11) + 1, annee = new Date().getFullYear() - age;
      const mpOffset = [-70, -20, 10, 45, 120, 200, -5, 90, 20, 150, -200, 60][(ci + hi * 5) % 12];
      const calOffset = [30, -15, 100, 220, 15, -90, 60, 300, 140, 20, 80, -3][(ci * 2 + hi) % 12];
      const lmp = addMonths(addDays(today, Math.min(mpOffset, c[6] * 30 - 10)), -c[6]), lcal = addMonths(addDays(today, Math.min(calOffset, c[7] * 30 - 10)), -c[7]);
      const status = stat[(ci + hi) % stat.length];
      const id = `H${hi + 1}-${String(ci + 1).padStart(3, '0')}`;
      const d = {
        id, desig: T[c[0]] || '', fab: c[1], model: c[2], serie: `SN-DEMO-${1000 + n}`, annee, classe: c[5], crit: c[3],
        hop, service: V[[1, 1, 2, 2, 0, 3, 3, 11, 5, 5, 6, 10][ci]] || V[0], salle: `S${(ci % 5) + 1}`, statut: status, etat: age > 9 ? 'poor' : age > 6 ? 'fair' : 'good',
        dacq: `${annee}-03-15`, mode: ci % 5 === 0 ? 'gift' : 'purchase', fourn: fr ? 'Fournisseur démo' : 'Demo supplier', prix: c[9], bc: `BC-${annee}-${100 + n}`, gfin: `${annee + 3}-03-15`,
        duree: c[8], pieces: age > 9 ? 'no' : 'yes', contrat: ci % 2 === 0 ? 'yes' : 'no', presta: ci % 2 === 0 ? (fr ? 'Prestataire démo' : 'Demo provider') : '', freq: c[6], lmp, lcal, pcal: c[7],
        alim: '100-240 V', fw: `v${1 + (ci % 3)}.${ci % 7}`, acc: '', doc: '', ce: 'yes', alerte: n % 17 === 0 ? 'yes' : 'no', form: 'yes', obsv: fr ? 'Donnée de démonstration' : 'Demo data', custom: {},
      };
      devices.push(d);
      if (ci % 2 === 0) intervs.push({ date: lmp, devId: id, type: 'preventive', by: 'internal', desc: fr ? 'Maintenance préventive : contrôles, nettoyage, test des alarmes' : 'Preventive maintenance: checks, cleaning, alarm test', cause: '', parts: '', downtime: 0, cost: 0, status: 'closed', notes: '' });
      if (status === 'repair') intervs.push({ date: addDays(today, -6), devId: id, type: 'corrective', by: 'internal', desc: fr ? 'Appareil ne démarre plus' : 'Device does not power on', cause: fr ? 'Alimentation défectueuse (à confirmer)' : 'Faulty power supply (tbc)', parts: fr ? 'Alimentation' : 'Power supply', downtime: 6, cost: 180, status: 'parts', notes: '' });
      if (status === 'out_of_service') intervs.push({ date: addDays(today, -40), devId: id, type: 'corrective', by: 'external', desc: fr ? 'Panne majeure carte mère' : 'Major motherboard failure', cause: fr ? 'Carte mère' : 'Motherboard', parts: '', downtime: 40, cost: 950, status: 'ongoing', notes: '' });
      if (ci % 4 === 1) intervs.push({ date: addDays(today, -90 - ci * 3), devId: id, type: 'corrective', by: 'external', desc: fr ? 'Remplacement capteur' : 'Sensor replacement', cause: fr ? 'Usure' : 'Wear', parts: fr ? 'Capteur' : 'Sensor', downtime: 4, cost: 240, status: 'closed', notes: '' });
    });
  });
  await bulkPut(devices, intervs); await saveSettings();
  return devices.length;
}
