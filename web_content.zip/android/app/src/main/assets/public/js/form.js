// Générateur de champs de formulaire (appareils, interventions, champs personnalisés)
import { h } from './util.js';
import { t, optLabel } from './i18n.js';
import { CODES } from './schema.js';
import { state } from './store.js';

let seq = 0;
// f : { k, type, list, src, req, min, max, label, options }
export function buildInput(f, val, label) {
  const id = 'fld' + (++seq);
  let ctl, get;
  const v = val == null ? '' : val;
  if (f.type === 'select' || f.type === 'hospital' || f.type === 'clist') {
    let opts = [];
    if (f.type === 'select') opts = CODES[f.list].map((c) => [c, optLabel(f.list, c)]);
    else if (f.type === 'hospital') { const names = [...state.settings.hospitals]; if (v && !names.includes(v)) names.push(v); opts = names.map((n) => [n, n]); }
    else { const names = [...(f.options || [])]; if (v && !names.includes(v)) names.push(v); opts = names.map((n) => [n, n]); }
    ctl = h('select', { id, class: 'input' }, h('option', { value: '' }, '—'), opts.map(([c, l]) => h('option', { value: c }, l)));
    ctl.value = v; get = () => ctl.value;
  } else if (f.type === 'yn') {
    ctl = h('select', { id, class: 'input' }, h('option', { value: '' }, '—'), CODES.yn.map((c) => h('option', { value: c }, optLabel('yn', c))));
    ctl.value = v; get = () => ctl.value;
  } else if (f.type === 'textarea') {
    ctl = h('textarea', { id, class: 'input', rows: 3 }); ctl.value = v; get = () => ctl.value.trim();
  } else if (f.type === 'number') {
    ctl = h('input', { id, class: 'input', type: 'number', inputmode: 'decimal', step: 'any', min: f.min, max: f.max }); ctl.value = v;
    get = () => (ctl.value === '' ? '' : Number(ctl.value));
  } else if (f.type === 'date') {
    ctl = h('input', { id, class: 'input', type: 'date' }); ctl.value = v; get = () => ctl.value;
  } else if (f.type === 'suggest') {
    const dl = h('datalist', { id: id + 'l' }, (state.settings[f.src] || []).map((s) => h('option', { value: s })));
    ctl = h('input', { id, class: 'input', type: 'text', list: id + 'l', autocomplete: 'off' }); ctl.value = v; get = () => ctl.value.trim();
    return { node: h('div', { class: 'field' }, h('label', { for: id }, label, f.req ? ' *' : ''), ctl, dl), get, ctl };
  } else {
    ctl = h('input', { id, class: 'input', type: 'text', autocomplete: 'off', autocapitalize: f.k === 'id' ? 'characters' : 'sentences' }); ctl.value = v; get = () => ctl.value.trim();
  }
  return { node: h('div', { class: 'field' }, h('label', { for: id }, label, f.req ? ' *' : ''), ctl), get, ctl };
}

export const badge = (tone, text, extra) => h('span', { class: 'badge ' + tone + (extra ? ' ' + extra : '') }, text);
export function toneOfM(st) { return st === 'overdue' ? 'danger' : st === 'soon' ? 'warn' : st === 'ok' ? 'ok' : 'muted'; }
export function toneOfStatut(s) { return { in_service: 'ok', repair: 'warn', out_of_service: 'danger', to_scrap: 'warn', scrapped: 'muted', stock: 'info', loan: 'info' }[s] || 'muted'; }
export const toneOfCrit = (c) => (c === 'critical' ? 'danger' : c === 'important' ? 'warn' : 'muted');
export function toneOfObs(o) { return o === 'eol' ? 'danger' : o === 'eolsoon' ? 'warn' : o === 'ok' ? 'ok' : 'muted'; }
export { t };

import { daysUntil, fmtDate } from './util.js';
export function dueText(date, st) {
  if (!date) return t('due.none');
  const n = daysUntil(date);
  if (st === 'overdue') return t('due.overdueBy', { n: Math.abs(n) }) + ' · ' + fmtDate(date);
  if (st === 'soon') return (n === 0 ? t('due.today') : t('due.in', { n })) + ' · ' + fmtDate(date);
  return fmtDate(date);
}
