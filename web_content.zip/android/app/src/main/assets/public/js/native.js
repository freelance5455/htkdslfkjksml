const Cap = window.Capacitor;
const plugin = Cap?.registerPlugin ? Cap.registerPlugin('PaceXNative') : null;
const native = Boolean(Cap?.isNativePlatform?.() && plugin);

async function call(name, options = {}) {
  if (!native) throw new Error('This device feature is available in the Android app only.');
  return plugin[name](options);
}
export const Native = {
  native,
  async request(feature) { return call('requestFeature', { feature }); },
  async location() { return call('getCurrentLocation'); },
  async startTracking(mode) { return call('startTracking', { mode }); },
  async pauseTracking() { return call('pauseTracking'); },
  async resumeTracking() { return call('resumeTracking'); },
  async stopTracking() { return call('stopTracking'); },
  async cancelTracking() { return call('cancelTracking'); },
  async activeSession() { return native ? call('getActiveSession') : { active: false }; },
  async enableSteps() { return call('enableStepCounter'); },
  async disableSteps() { return call('disableStepCounter'); },
  async steps() { return native ? call('getStepState') : null; },
  async permissionState() { return native ? call('getPermissionState') : { native: false }; },
  async openSettings() { return call('openAppSettings'); },
  async exportJson(json, filename) { return call('exportJson', { json, filename }); },
  async clearNativeActive() { return native ? call('clearActiveSession') : null; },
  async addListener(event, callback) {
    if (!native) return { remove: async () => {} };
    return plugin.addListener(event, callback);
  }
};

export function browserLocation(onPoint, onError) {
  if (!navigator.geolocation) { onError?.(new Error('Location is not available in this browser.')); return null; }
  return navigator.geolocation.watchPosition(
    position => onPoint({ latitude:position.coords.latitude, longitude:position.coords.longitude, accuracy:position.coords.accuracy, speedMps:position.coords.speed, timestamp:new Date(position.timestamp).toISOString() }),
    err => onError?.(err),
    { enableHighAccuracy:true, maximumAge:1000, timeout:12000 }
  );
}
