import { uid, dateKey } from './utils.js';

const ROOT = 'pace-x-data';
const FILES = {
  profile: 'profile.json',
  steps: 'daily-steps.json',
  workouts: 'workouts.json',
  achievements: 'achievements.json',
  challenges: 'challenges.json',
  settings: 'settings.json',
  active: 'active-workout.json',
  pending: 'pending-workout.json'
};

const defaults = {
  profile: { version: 1, name: '', age: '', weightKg: 70, heightCm: '', createdAt: new Date().toISOString() },
  steps: { version: 1, totalSteps: 0, days: {} },
  workouts: { version: 1, items: [] },
  achievements: { version: 1, xp: 0, unlocked: {}, seenCelebrations: [] },
  challenges: { version: 1, items: [] },
  settings: { version: 1, onboardingComplete: false, dailyGoal: 8000, distanceUnit: 'km', weightUnit: 'kg', darkTheme: true, stepServiceEnabled: false },
  active: null,
  pending: null
};

function clone(v) { return JSON.parse(JSON.stringify(v)); }
function mergeDefault(kind, value) {
  const base = clone(defaults[kind]);
  if (value === null && base === null) return null;
  if (!value || typeof value !== 'object') return base;
  return { ...base, ...value };
}

class PaceStore {
  constructor() { this.fs = null; this.Directory = null; this.Encoding = null; this.web = !(window.Capacitor?.isNativePlatform?.()); }
  async init() {
    if (!this.web) {
      try {
        const mod = await import('@capacitor/filesystem');
        this.fs = mod.Filesystem; this.Directory = mod.Directory; this.Encoding = mod.Encoding;
        await this.fs.mkdir({ path: ROOT, directory: this.Directory.Data, recursive: true });
      } catch (e) { console.warn('Filesystem unavailable; using browser fallback', e); this.web = true; }
    }
    for (const key of ['profile','steps','workouts','achievements','challenges','settings']) {
      const val = await this.read(key);
      if (val === null) await this.write(key, defaults[key]);
    }
  }
  path(kind) { return `${ROOT}/${FILES[kind]}`; }
  key(kind) { return `pace-x:${FILES[kind]}`; }
  async read(kind) {
    try {
      let raw;
      if (this.web) raw = localStorage.getItem(this.key(kind));
      else raw = (await this.fs.readFile({ path: this.path(kind), directory: this.Directory.Data, encoding: this.Encoding.UTF8 })).data;
      if (!raw) return null;
      return mergeDefault(kind, JSON.parse(raw));
    } catch (error) {
      // A damaged JSON file must not take down the tracker. Preserve it for manual recovery, then return safe defaults.
      console.warn(`Could not read ${kind}; using safe default`, error);
      return clone(defaults[kind]);
    }
  }
  async write(kind, value) {
    const json = JSON.stringify(value);
    if (this.web) { localStorage.setItem(this.key(kind), json); return; }
    const path = this.path(kind); const temp = `${path}.tmp`;
    try {
      // Filesystem write + replacement keeps a complete temp copy until the final replacement.
      await this.fs.writeFile({ path: temp, data: json, directory: this.Directory.Data, encoding: this.Encoding.UTF8, recursive: true });
      try { await this.fs.deleteFile({ path, directory: this.Directory.Data }); } catch (_) { /* first write */ }
      await this.fs.rename({ from: temp, to: path, directory: this.Directory.Data });
    } catch (error) {
      console.error(`Could not write ${kind}`, error);
      try { await this.fs.writeFile({ path, data: json, directory: this.Directory.Data, encoding: this.Encoding.UTF8, recursive: true }); } catch (lastError) { throw lastError; }
    }
  }
  async update(kind, updater) { const current = await this.read(kind); const next = await updater(current); await this.write(kind, next); return next; }
  async all() {
    const result = {};
    for (const kind of Object.keys(FILES)) result[kind] = await this.read(kind);
    return { schema: 'pace-x-export-v1', exportedAt: new Date().toISOString(), files: result };
  }
  async deleteAll() {
    if (this.web) { Object.keys(FILES).forEach(k => localStorage.removeItem(this.key(k))); }
    else {
      await Promise.all(Object.keys(FILES).map(async kind => { try { await this.fs.deleteFile({ path:this.path(kind), directory:this.Directory.Data }); } catch (_) {} }));
    }
    await this.init();
  }
  async saveWorkout(workout) {
    const normalized = { ...workout, id: workout.id || uid('workout'), date: workout.date || dateKey(workout.startTime), savedAt: new Date().toISOString() };
    await this.update('workouts', data => ({ ...data, items: [normalized, ...(data.items || [])] }));
    return normalized;
  }
  async deleteWorkout(id) { await this.update('workouts', data => ({ ...data, items: (data.items || []).filter(w => w.id !== id) })); }
}
export const store = new PaceStore();
export { defaults };
