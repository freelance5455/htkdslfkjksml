// Règles de calcul (identiques au classeur Excel) : échéances, statuts, fin de vie, indicateurs.
import { state } from './store.js';
import { addMonths, todayISO, addDays, parseISO } from './util.js';

// Calculs d'un appareil, mis en cache tant que les données/paramètres n'ont pas changé.
export function C(d) {
  if (d.__v === state.ver && d.__c) return d.__c;
  const S = state.settings, today = todayISO(), Y = new Date().getFullYear(), limit = addDays(today, +S.alertDays || 0);
  const scrapped = d.statut === 'scrapped';
  const annee = d.annee === '' || d.annee == null ? null : +d.annee, duree = d.duree === '' || d.duree == null ? null : +d.duree;
  const c = {};
  c.gstat = d.gfin ? (d.gfin < today ? 'expired' : 'under') : '';
  c.age = annee ? Y - annee : '';
  c.fdv = annee && duree ? annee + duree : '';
  c.obs = c.fdv === '' ? '' : c.fdv <= Y ? 'eol' : c.fdv <= Y + (+S.eolYears || 0) ? 'eolsoon' : 'ok';
  const st = (due) => scrapped ? 'na' : !due ? 'unplanned' : due < today ? 'overdue' : due <= limit ? 'soon' : 'ok';
  c.nmp = d.lmp && d.freq !== '' && d.freq != null ? addMonths(d.lmp, d.freq) : '';
  c.smp = st(c.nmp);
  c.ncal = d.lcal && d.pcal !== '' && d.pcal != null ? addMonths(d.lcal, d.pcal) : '';
  c.scal = st(c.ncal);
  d.__c = c; d.__v = state.ver;
  return c;
}

export const live = () => state.devices.filter((d) => d.statut !== 'scrapped');
const cnt = (arr, fn) => arr.reduce((n, x) => n + (fn(x) ? 1 : 0), 0);

export function kpis() {
  const D = state.devices, tot = D.length, scrapped = cnt(D, (d) => d.statut === 'scrapped'), serv = cnt(D, (d) => d.statut === 'in_service');
  const preds = (k, v) => cnt(D, (d) => C(d)[k] === v);
  const mOk = preds('smp', 'ok') + preds('smp', 'soon'), mAll = mOk + preds('smp', 'overdue');
  const corr = state.intervs.filter((r) => r.type === 'corrective');
  const dt = corr.filter((r) => r.downtime !== '' && r.downtime != null);
  return {
    tot, serv, scrapped,
    down: cnt(D, (d) => d.statut === 'repair' || d.statut === 'out_of_service'),
    avail: tot - scrapped > 0 ? serv / (tot - scrapped) : 0,
    critical: cnt(D, (d) => d.crit === 'critical' && d.statut !== 'scrapped'),
    mpOver: preds('smp', 'overdue'), mpSoon: preds('smp', 'soon'), mpRate: mAll ? mOk / mAll : 0,
    calOver: preds('scal', 'overdue'), calSoon: preds('scal', 'soon'),
    critOver: cnt(D, (d) => d.crit === 'critical' && (C(d).smp === 'overdue' || C(d).scal === 'overdue')),
    noCover: cnt(D, (d) => C(d).gstat === 'expired' && d.contrat === 'no' && d.statut !== 'scrapped'),
    eol: preds('obs', 'eol'), eolSoon: preds('obs', 'eolsoon'),
    vigi: cnt(D, (d) => d.alerte === 'yes'),
    value: D.reduce((s, d) => s + (+d.prix || 0), 0),
    corrN: corr.length, corrCost: corr.reduce((s, r) => s + (+r.cost || 0), 0),
    corrDown: dt.length ? dt.reduce((s, r) => s + (+r.downtime || 0), 0) / dt.length : 0,
    openInterv: cnt(state.intervs, (r) => r.status === 'ongoing' || r.status === 'parts'),
  };
}

// Éléments à traiter : maintenance/calibration en retard ou à planifier (critiques d'abord)
export function dueItems() {
  const out = [];
  for (const d of live()) {
    const c = C(d);
    for (const [kind, st, date] of [['maint', c.smp, c.nmp], ['cal', c.scal, c.ncal]]) {
      if (st === 'overdue' || st === 'soon') out.push({ d, kind, st, date });
    }
  }
  const w = (x) => (x.d.crit === 'critical' ? 0 : x.d.crit === 'important' ? 1 : 2);
  out.sort((a, b) => (a.st === b.st ? 0 : a.st === 'overdue' ? -1 : 1) || w(a) - w(b) || (a.date < b.date ? -1 : 1));
  return out;
}

export function byHospital() {
  const names = [...state.settings.hospitals];
  for (const d of state.devices) if (d.hop && !names.includes(d.hop)) names.push(d.hop);
  if (state.devices.some((d) => !d.hop)) names.push('');
  return names.map((name) => {
    const D = state.devices.filter((d) => (d.hop || '') === name);
    return {
      name, n: D.length, serv: cnt(D, (d) => d.statut === 'in_service'), down: cnt(D, (d) => d.statut === 'repair' || d.statut === 'out_of_service'),
      mpOver: cnt(D, (d) => C(d).smp === 'overdue'), calOver: cnt(D, (d) => C(d).scal === 'overdue'), value: D.reduce((s, d) => s + (+d.prix || 0), 0),
    };
  }).filter((x) => x.n > 0 || x.name);
}
export function byStatus() {
  const m = {}; for (const d of state.devices) m[d.statut || ''] = (m[d.statut || ''] || 0) + 1; return m;
}
export const deviceById = (id) => state.devices.find((d) => d.id === id);
export const intervsOf = (id) => state.intervs.filter((r) => r.devId === id).sort((a, b) => (a.date < b.date ? 1 : -1));
export { parseISO };
