import { h, icon, toast, fmtDate, fmtMoney, fmtNum, openSheet, confirmDialog, debounce, norm, todayISO } from './util.js';
import { t, optLabel, fieldLabel } from './i18n.js';
import { state, putDevice, delDevice, putInterv, saveSettings, newUid } from './store.js';
import { FIELDS, GROUPS, CODES } from './schema.js';
import { C, intervsOf, deviceById } from './logic.js';
import { buildInput, badge, toneOfM, toneOfStatut, toneOfCrit, toneOfObs, dueText } from './form.js';
import { nav } from './nav.js';
import { quickDone, declareFailure, intervRow } from './view-maintenance.js';
import { scheduleSoon } from './notify.js';
import { openScanner } from './scanner.js';

// ---------- filtres ----------
const EMPTY = { q: '', hop: '', service: '', statut: '', crit: '', smp: '', scal: '', obs: '', alerte: '', quick: '', sort: 'id' };
export const filter = { ...EMPTY };
export function setFilter(f) { Object.assign(filter, EMPTY, f || {}); }

function matches(d, f) {
  const c = C(d);
  if (f.hop !== '' && (d.hop || '') !== f.hop) return false;
  if (f.service && d.service !== f.service) return false;
  if (f.statut && d.statut !== f.statut) return false;
  if (f.crit && d.crit !== f.crit) return false;
  if (f.smp && c.smp !== f.smp) return false;
  if (f.scal && c.scal !== f.scal) return false;
  if (f.obs && c.obs !== f.obs) return false;
  if (f.alerte && d.alerte !== f.alerte) return false;
  if (f.quick === 'overdue' && !(c.smp === 'overdue' || c.scal === 'overdue')) return false;
  if (f.quick === 'soon' && !(c.smp === 'soon' || c.scal === 'soon')) return false;
  if (f.quick === 'attention' && !(['overdue', 'soon'].includes(c.smp) || ['overdue', 'soon'].includes(c.scal))) return false;
  if (f.quick === 'down' && !(d.statut === 'repair' || d.statut === 'out_of_service')) return false;
  if (f.q) {
    const hay = norm([d.id, d.desig, d.fab, d.model, d.serie, d.hop, d.service, d.salle, d.fourn].join(' '));
    if (!f.q.split(' ').every((w) => hay.includes(norm(w)))) return false;
  }
  return true;
}
const nextDue = (d) => { const c = C(d); const a = [c.nmp, c.ncal].filter(Boolean).sort(); return a[0] || '9999'; };
const SORTS = {
  id: (a, b) => String(a.id).localeCompare(String(b.id), undefined, { numeric: true }),
  desig: (a, b) => String(a.desig).localeCompare(String(b.desig)),
  hop: (a, b) => String(a.hop).localeCompare(String(b.hop)) || SORTS.id(a, b),
  due: (a, b) => (nextDue(a) < nextDue(b) ? -1 : nextDue(a) > nextDue(b) ? 1 : 0),
};
const activeCount = () => ['hop', 'service', 'statut', 'crit', 'smp', 'scal', 'obs', 'alerte'].filter((k) => filter[k] !== '').length + (filter.quick ? 1 : 0);

let shown = 60;

export function invView() {
  const el = h('div', { class: 'page' });
  const list = h('div', { class: 'list' });
  const count = h('div', { class: 'muted count' });
  const q = h('input', { class: 'input search', type: 'search', placeholder: t('inv.search'), value: filter.q, 'aria-label': t('inv.search') });
  const chips = h('div', { class: 'chips' });
  const quick = [['', t('inv.all')], ['overdue', t('inv.qOverdue')], ['soon', t('inv.qSoon')], ['down', t('inv.qDown')]];

  const renderList = () => {
    const rows = state.devices.filter((d) => matches(d, filter)).sort(SORTS[filter.sort] || SORTS.id);
    count.textContent = t('inv.count', { n: rows.length, total: state.devices.length });
    list.replaceChildren();
    if (!rows.length) list.append(h('div', { class: 'empty small' }, h('p', null, state.devices.length ? t('inv.noMatch') : t('inv.empty'))));
    rows.slice(0, shown).forEach((d) => list.append(card(d)));
    if (rows.length > shown) list.append(h('button', { class: 'btn outline block', onclick: () => { shown += 60; renderList(); } }, t('inv.more', { n: rows.length - shown })));
  };
  const renderChips = () => {
    chips.replaceChildren(...quick.map(([k, l]) => h('button', { class: 'chip' + (filter.quick === k && !activeOther() ? ' on' : ''), onclick: () => { Object.assign(filter, { quick: k }); shown = 60; renderChips(); renderList(); } }, l)));
  };
  const activeOther = () => false;
  q.addEventListener('input', debounce(() => { filter.q = q.value; shown = 60; renderList(); }, 150));
  renderChips(); renderList();
  const fbtn = h('button', { class: 'icon-btn' + (activeCount() ? ' badged' : ''), 'aria-label': t('inv.filters'), onclick: () => openFilters(() => { renderChips(); renderList(); fbtn.classList.toggle('badged', !!activeCount()); }) }, icon('filter'));
  const sbtn = h('button', { class: 'icon-btn', 'aria-label': t('inv.scan'), onclick: () => openScanner((code) => { q.value = code; filter.q = code; renderList(); }) }, icon('scan'));
  el.append(h('div', { class: 'toolbar' }, h('div', { class: 'searchbox' }, icon('search', 20), q), sbtn, fbtn), chips, count, list);
  return { title: t('nav.inventory'), el, tab: 'inv', fab: { label: t('inv.add'), onClick: () => nav.push('device-edit', {}) } };
}

function openFilters(onApply) {
  const mk = (k, label, opts) => {
    const s = h('select', { class: 'input' }, h('option', { value: '' }, t('inv.any')), opts.map(([v, l]) => h('option', { value: v }, l)));
    s.value = filter[k]; return { node: h('div', { class: 'field' }, h('label', null, label), s), s };
  };
  const hops = [...new Set([...state.settings.hospitals, ...state.devices.map((d) => d.hop).filter(Boolean)])].map((x) => [x, x]);
  const svcs = [...new Set([...state.settings.services, ...state.devices.map((d) => d.service).filter(Boolean)])].map((x) => [x, x]);
  const F = {
    hop: mk('hop', fieldLabel('hop'), hops), service: mk('service', fieldLabel('service'), svcs),
    statut: mk('statut', fieldLabel('statut'), CODES.statut.map((c) => [c, optLabel('statut', c)])),
    crit: mk('crit', fieldLabel('crit'), CODES.crit.map((c) => [c, optLabel('crit', c)])),
    smp: mk('smp', t('inv.fMaint'), ['overdue', 'soon', 'ok', 'unplanned'].map((c) => [c, t('m.' + c)])),
    scal: mk('scal', t('inv.fCal'), ['overdue', 'soon', 'ok', 'unplanned'].map((c) => [c, t('m.' + c)])),
    obs: mk('obs', fieldLabel('obs'), [['eol', t('obs.eol')], ['eolsoon', t('obs.eolsoon')], ['ok', t('obs.ok')]]),
    alerte: mk('alerte', fieldLabel('alerte'), [['yes', t('c.yn.yes')]]),
  };
  const sort = h('select', { class: 'input' }, ['id', 'desig', 'hop', 'due'].map((k) => h('option', { value: k }, t('inv.sort.' + k)))); sort.value = filter.sort;
  openSheet({
    title: t('inv.filters'), full: true,
    body: h('div', null, Object.values(F).map((x) => x.node), h('div', { class: 'field' }, h('label', null, t('inv.sortBy')), sort)),
    actions: [
      { label: t('inv.reset'), cls: 'text', onClick: () => { setFilter({ q: filter.q }); onApply(); } },
      { label: t('inv.apply'), cls: 'primary', onClick: () => { for (const k of Object.keys(F)) filter[k] = F[k].s.value; filter.sort = sort.value; filter.quick = ''; shown = 60; onApply(); } },
    ],
  });
}

function card(d) {
  const c = C(d);
  return h('button', { class: 'item', onclick: () => nav.push('device', { uid: d.uid }) },
    h('div', { class: 'item-top' }, h('div', { class: 'item-t' }, d.desig || t('common.noName')), badge(toneOfStatut(d.statut), optLabel('statut', d.statut) || '—')),
    h('div', { class: 'item-s' }, [d.id, [d.fab, d.model].filter(Boolean).join(' ')].filter(Boolean).join(' · ')),
    h('div', { class: 'item-s' }, [d.hop, d.service, d.salle].filter(Boolean).join(' · ')),
    h('div', { class: 'badges' },
      c.smp !== 'na' && c.smp !== 'unplanned' ? badge(toneOfM(c.smp), t('dash.maintShort') + ' ' + dueText(c.nmp, c.smp)) : null,
      c.scal !== 'na' && c.scal !== 'unplanned' ? badge(toneOfM(c.scal), t('dash.calShort') + ' ' + dueText(c.ncal, c.scal)) : null,
      d.crit === 'critical' ? badge('danger', optLabel('crit', 'critical')) : null,
      d.alerte === 'yes' ? badge('danger', t('inv.vigilance')) : null,
      c.obs === 'eol' ? badge('warn', t('obs.eol')) : null));
}

// ---------- fiche appareil ----------
const dd = (label, value) => (value === '' || value == null ? null : h('div', { class: 'kv' }, h('span', null, label), h('b', null, value)));

export function deviceView({ uid }) {
  const d = state.devices.find((x) => x.uid === uid);
  if (!d) { setTimeout(() => nav.back(), 0); return { title: '', el: h('div') }; }
  const c = C(d), el = h('div', { class: 'page' });
  el.append(h('section', { class: 'card hero' },
    h('div', { class: 'hero-t' }, d.desig || t('common.noName')),
    h('div', { class: 'hero-s' }, [d.id, [d.fab, d.model].filter(Boolean).join(' ')].filter(Boolean).join(' · ')),
    h('div', { class: 'badges' }, badge(toneOfStatut(d.statut), optLabel('statut', d.statut) || '—'), d.crit ? badge(toneOfCrit(d.crit), optLabel('crit', d.crit)) : null,
      d.etat ? badge(d.etat === 'poor' ? 'danger' : d.etat === 'fair' ? 'warn' : 'ok', optLabel('etat', d.etat)) : null, d.alerte === 'yes' ? badge('danger', t('inv.vigilance')) : null),
    h('div', { class: 'actions' },
      h('button', { class: 'btn primary', onclick: () => quickDone(d, 'preventive') }, icon('check', 18), t('dev.doneMaint')),
      h('button', { class: 'btn outline', onclick: () => quickDone(d, 'calibration') }, icon('check', 18), t('dev.doneCal')),
      h('button', { class: 'btn outline danger-o', onclick: () => declareFailure(d) }, icon('warning', 18), t('dev.failure')))));

  const dueRow = (label, date, st, extra) => h('div', { class: 'kv' }, h('span', null, label), h('b', null, badge(toneOfM(st), date ? dueText(date, st) : t('m.' + st)), extra || null));
  el.append(h('section', { class: 'card' }, h('div', { class: 'card-h' }, h('h3', null, t('dev.deadlines'))),
    dueRow(t('dev.nextMaint'), c.nmp, c.smp), dueRow(t('dev.nextCal'), c.ncal, c.scal),
    c.gstat ? h('div', { class: 'kv' }, h('span', null, t('f.gfin')), h('b', null, badge(c.gstat === 'expired' ? 'warn' : 'ok', t('g.' + c.gstat)), ' ', fmtDate(d.gfin))) : null,
    c.obs ? h('div', { class: 'kv' }, h('span', null, t('f.fdv')), h('b', null, badge(toneOfObs(c.obs), t('obs.' + c.obs)), ' ', c.fdv)) : null,
    c.age !== '' ? dd(t('f.age'), t('dev.years', { n: c.age })) : null));

  for (const g of GROUPS) {
    const rows = FIELDS.filter((f) => f.g === g && f.k !== 'desig' && f.k !== 'id').map((f) => {
      let v = d[f.k];
      if (v === '' || v == null) return null;
      if (f.type === 'select') v = optLabel(f.list, v); else if (f.type === 'date') v = fmtDate(v); else if (f.k === 'prix') v = fmtMoney(v);
      if (f.k === 'doc' && /^https?:\/\//i.test(v)) return h('div', { class: 'kv' }, h('span', null, fieldLabel(f.k)), h('a', { href: v, target: '_blank', rel: 'noopener' }, v));
      return dd(fieldLabel(f.k), String(v));
    }).filter(Boolean);
    if (rows.length) el.append(h('section', { class: 'card' }, h('div', { class: 'card-h' }, h('h3', null, t('g.' + g))), rows));
  }
  const cf = state.settings.customFields.map((f) => dd(f.label, customDisplay(f, (d.custom || {})[f.id]))).filter(Boolean);
  if (cf.length) el.append(h('section', { class: 'card' }, h('div', { class: 'card-h' }, h('h3', null, t('g.custom'))), cf));

  const hist = intervsOf(d.id);
  el.append(h('section', { class: 'card' }, h('div', { class: 'card-h' }, h('h3', null, t('dev.history', { n: hist.length })), h('button', { class: 'link', onclick: () => nav.push('interv-edit', { devId: d.id }) }, '+ ' + t('maint.add'))),
    hist.length ? hist.slice(0, 15).map((r) => intervRow(r, false)) : h('p', { class: 'muted pad' }, t('dev.noHistory'))));

  el.append(h('div', { class: 'row-gap pad-b' },
    h('button', { class: 'btn outline', onclick: () => nav.push('device-edit', { dupOf: d.uid }) }, icon('copy', 18), t('dev.duplicate')),
    h('button', { class: 'btn outline danger-o', onclick: async () => {
      if (await confirmDialog({ title: t('dev.deleteTitle'), message: t('dev.deleteMsg', { name: d.desig || d.id }), okLabel: t('common.delete'), danger: true })) {
        await delDevice(d.uid); scheduleSoon(); toast(t('dev.deleted')); nav.back();
      }
    } }, icon('delete', 18), t('common.delete'))));
  return { title: d.id || t('nav.inventory'), el, tab: 'inv', actions: [h('button', { class: 'icon-btn', 'aria-label': t('common.edit'), onclick: () => nav.push('device-edit', { uid: d.uid }) }, icon('edit'))] };
}
export function customDisplay(f, v) {
  if (v === '' || v == null) return '';
  if (f.type === 'date') return fmtDate(v);
  if (f.type === 'yn') return optLabel('yn', v);
  return String(v);
}

// ---------- formulaire appareil ----------
export function deviceEditView({ uid, dupOf }) {
  const src = state.devices.find((x) => x.uid === (uid || dupOf));
  const isNew = !uid;
  const base = src ? { ...src } : { statut: 'in_service', hop: state.settings.hospitals[0] || '', crit: 'standard' };
  if (dupOf) { base.id = ''; base.serie = ''; base.uid = undefined; base.lmp = ''; base.lcal = ''; }
  const inputs = {}, el = h('form', { class: 'page form', novalidate: true });
  for (const g of GROUPS) {
    const sec = h('details', { class: 'card fold', open: g === 'ident' || g === 'loc' || (isNew && false) }, h('summary', null, t('g.' + g)));
    for (const f of FIELDS.filter((x) => x.g === g)) { const b = buildInput(f, base[f.k], fieldLabel(f.k)); inputs[f.k] = b; sec.append(b.node); }
    el.append(sec);
  }
  const cin = {};
  if (state.settings.customFields.length) {
    const sec = h('details', { class: 'card fold', open: true }, h('summary', null, t('g.custom')));
    for (const f of state.settings.customFields) { const b = buildInput({ k: f.id, type: f.type === 'list' ? 'clist' : f.type, options: f.options }, (base.custom || {})[f.id], f.label); cin[f.id] = b; sec.append(b.node); }
    el.append(sec);
  }
  const err = h('div', { class: 'form-err', role: 'alert' });
  const save = async (e) => {
    e && e.preventDefault();
    const d = { ...base };
    for (const f of FIELDS) d[f.k] = inputs[f.k].get();
    if (!d.id) { err.textContent = t('dev.errId'); inputs.id.ctl.focus(); return; }
    if (state.devices.some((x) => x.id === d.id && x.uid !== d.uid)) { err.textContent = t('dev.errDup', { id: d.id }); inputs.id.ctl.focus(); return; }
    if (d.annee !== '' && (d.annee < 1950 || d.annee > 2100)) { err.textContent = t('dev.errYear'); inputs.annee.ctl.focus(); return; }
    d.custom = { ...(base.custom || {}) }; for (const id of Object.keys(cin)) d.custom[id] = cin[id].get();
    // apprentissage des listes (services / types)
    let lists = false;
    for (const [k, key] of [['service', 'services'], ['desig', 'types']]) if (d[k] && !state.settings[key].includes(d[k])) { state.settings[key].push(d[k]); lists = true; }
    if (d.hop && !state.settings.hospitals.includes(d.hop)) { state.settings.hospitals.push(d.hop); lists = true; }
    const oldId = src && !dupOf ? src.id : null;
    await putDevice(d);
    if (oldId && oldId !== d.id) for (const r of state.intervs.filter((r) => r.devId === oldId)) await putInterv({ ...r, devId: d.id });
    if (lists) await saveSettings();
    scheduleSoon(); toast(t('common.saved')); nav.back();
  };
  el.addEventListener('submit', save);
  el.append(err, h('div', { class: 'sticky-actions' }, h('button', { type: 'button', class: 'btn text', onclick: () => nav.back() }, t('common.cancel')), h('button', { type: 'submit', class: 'btn primary' }, icon('check', 18), t('common.save'))));
  return { title: isNew ? t('inv.add') : t('common.edit'), el, tab: 'inv' };
}
