// Import / export : Excel (.xlsx, compatible avec le classeur d'inventaire), sauvegarde JSON, partage de fichiers
import { h, toast, openSheet, confirmDialog, norm, todayISO, isoOf, pad } from './util.js';
import { t, fieldLabel, ifieldLabel, optLabel, codeFromLabel, allDicts } from './i18n.js';
import { state, saveSettings, bulkPut, clearData, newUid } from './store.js';
import { FIELDS, IFIELDS, CALC, CODES } from './schema.js';
import { C, deviceById } from './logic.js';

const X = () => { if (!window.XLSX) throw new Error('XLSX non chargé'); return window.XLSX; };
const native = () => !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());

// ---------- fichiers ----------
export async function saveFile(name, mime, base64) {
  if (native()) {
    const { Filesystem, Share } = window.Capacitor.Plugins;
    const r = await Filesystem.writeFile({ path: name, data: base64, directory: 'CACHE' });
    await Share.share({ title: name, url: r.uri, dialogTitle: name });
    return;
  }
  const bin = atob(base64), u8 = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  const url = URL.createObjectURL(new Blob([u8], { type: mime }));
  const a = h('a', { href: url, download: name }); document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 4000);
}
const textToB64 = (s) => btoa(unescape(encodeURIComponent(s)));
export function pickFile(accept) {
  return new Promise((res) => {
    const inp = h('input', { type: 'file', accept, style: { display: 'none' } });
    inp.addEventListener('change', () => { res(inp.files[0] || null); inp.remove(); });
    inp.addEventListener('cancel', () => res(null));
    document.body.appendChild(inp); inp.click();
  });
}
const stamp = () => todayISO();

// ---------- dates Excel ----------
const serialOf = (iso) => { const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso || ''); return m ? Math.round((Date.UTC(+m[1], +m[2] - 1, +m[3]) - Date.UTC(1899, 11, 30)) / 86400000) : ''; };
const isoOfSerial = (n) => { const d = new Date(Date.UTC(1899, 11, 30) + Math.floor(n) * 86400000); return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`; };
function toISO(v) {
  if (v === '' || v == null) return '';
  if (v instanceof Date) return isoOf(v);
  if (typeof v === 'number') return v > 20000 && v < 80000 ? isoOfSerial(v) : '';
  const s = String(v).trim();
  let m = /^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})/.exec(s); if (m) return `${m[1]}-${pad(+m[2])}-${pad(+m[3])}`;
  m = /^(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})$/.exec(s);
  if (m) { let y = +m[3]; if (y < 100) y += 2000; const us = state.settings.dateFormat === 'mm/dd/yyyy'; return `${y}-${pad(us ? +m[1] : +m[2])}-${pad(us ? +m[2] : +m[1])}`; }
  return null;
}

// ---------- export Excel ----------
const calcLabel = (k) => t('f.' + k);
function calcValue(d, k) {
  const c = C(d), v = c[k];
  if (v === '' || v == null) return '';
  if (k === 'gstat') return t('g.' + v); if (k === 'obs') return t('obs.' + v);
  if (k === 'smp' || k === 'scal') return t('m.' + v);
  if (k === 'nmp' || k === 'ncal') return serialOf(v);
  return v;
}
export async function exportXlsx() {
  const XL = X(), wb = XL.utils.book_new(), cf = state.settings.customFields;
  const cols = [...FIELDS.map((f) => ({ label: fieldLabel(f.k), type: f.type, get: (d) => d[f.k], f })), ...CALC.map((k) => ({ label: calcLabel(k), calc: k, type: ['nmp', 'ncal'].includes(k) ? 'date' : 'text' })), ...cf.map((f) => ({ label: f.label, type: f.type, get: (d) => (d.custom || {})[f.id], custom: f }))];
  const val = (col, d) => {
    if (col.calc) return calcValue(d, col.calc);
    const v = col.get(d); if (v === '' || v == null) return '';
    if (col.type === 'select') return optLabel(col.f.list, v);
    if (col.type === 'date') return serialOf(v);
    if (col.type === 'yn') return optLabel('yn', v);
    return v;
  };
  const rows = [cols.map((c) => c.label), ...[...state.devices].sort((a, b) => String(a.id).localeCompare(String(b.id), undefined, { numeric: true })).map((d) => cols.map((c) => val(c, d)))];
  const ws = XL.utils.aoa_to_sheet(rows);
  cols.forEach((c, i) => { if (c.type === 'date') for (let r = 1; r < rows.length; r++) { const a = XL.utils.encode_cell({ r, c: i }); if (ws[a] && ws[a].t === 'n') ws[a].z = 'dd/mm/yyyy'; } });
  ws['!cols'] = cols.map((c) => ({ wch: Math.min(34, Math.max(11, String(c.label).length + 2)) }));
  ws['!autofilter'] = { ref: XL.utils.encode_range({ s: { r: 0, c: 0 }, e: { r: Math.max(0, rows.length - 1), c: cols.length - 1 } }) };
  XL.utils.book_append_sheet(wb, ws, t('xl.inv'));

  const mh = [ifieldLabel('date'), ifieldLabel('devId'), t('xl.device'), t('xl.hospital'), ...['type', 'desc', 'cause', 'parts', 'by', 'downtime', 'cost', 'status', 'notes'].map(ifieldLabel)];
  const mrows = [mh, ...[...state.intervs].sort((a, b) => (a.date < b.date ? 1 : -1)).map((r) => { const d = deviceById(r.devId) || {}; return [serialOf(r.date), r.devId, d.desig || '', d.hop || '', optLabel('itype', r.type), r.desc || '', r.cause || '', r.parts || '', optLabel('iby', r.by), r.downtime ?? '', r.cost ?? '', optLabel('istatus', r.status), r.notes || '']; })];
  const wm = XL.utils.aoa_to_sheet(mrows);
  for (let r = 1; r < mrows.length; r++) { const a = XL.utils.encode_cell({ r, c: 0 }); if (wm[a] && wm[a].t === 'n') wm[a].z = 'dd/mm/yyyy'; }
  wm['!cols'] = mh.map((x, i) => ({ wch: i === 4 ? 36 : 16 }));
  XL.utils.book_append_sheet(wb, wm, t('xl.maint'));
  const b64 = XL.write(wb, { bookType: 'xlsx', type: 'base64' });
  await saveFile(`${t('xl.file')}_${stamp()}.xlsx`, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', b64);
  state.settings.lastBackup = new Date().toISOString(); await saveSettings();
}

// ---------- import Excel ----------
function labelMap(prefix, keys, extra = []) {
  const m = new Map();
  for (const k of keys) {
    m.set(norm(k), k);
    for (const dict of Object.values(allDicts())) { const l = dict[prefix + k]; if (l) m.set(norm(l), k); }
  }
  for (const [lbl, k] of extra) m.set(norm(lbl), k);
  return m;
}
function convert(f, raw, warn) {
  if (raw === '' || raw == null) return '';
  const s = String(raw).trim();
  if (f.type === 'date') { const v = toISO(raw); if (v === null) { warn.bad++; return ''; } return v; }
  if (f.type === 'number') { const n = Number(String(raw).replace(/\s/g, '').replace(',', '.')); if (isNaN(n)) { warn.bad++; return ''; } return n; }
  if (f.type === 'select') { const c = codeFromLabel(f.list, s, norm); if (c === null) { warn.bad++; return ''; } return c; }
  return s;
}
export async function importXlsx(file) {
  const XL = X(), wb = XL.read(await file.arrayBuffer(), { type: 'array' });
  const invMap = labelMap('f.', FIELDS.map((f) => f.k), [["Prix d'achat (devise locale)", 'prix'], ['Classe de risque (I, IIa, IIb, III)', 'classe'], ["Désignation (type d'appareil)", 'desig'], ['Périodicité (mois)', 'pcal']]);
  for (const c of state.settings.customFields) invMap.set(norm(c.label), 'custom:' + c.id);
  const intMap = labelMap('if.', IFIELDS.map((f) => f.k), [['Coût (devise locale)', 'cost']]);
  const warn = { bad: 0, skipped: 0, ignoredCols: new Set() };
  const devices = [], intervs = [];
  const dateHead = new Set([...Object.values(allDicts()).map((d) => norm(d['if.date']))]);
  for (const name of wb.SheetNames) {
    const aoa = XL.utils.sheet_to_json(wb.Sheets[name], { header: 1, raw: true, defval: '' });
    // ligne d'en-tête = première ligne (parmi les 15 premières) qui contient « N° d'inventaire »
    const idLabels = new Set(Object.values(allDicts()).map((d) => norm(d['f.id'])));
    let hr = -1; for (let i = 0; i < Math.min(15, aoa.length); i++) if (aoa[i].some((c) => idLabels.has(norm(c)))) { hr = i; break; }
    if (hr < 0) continue;
    const head = aoa[hr], isInt = head.some((c) => dateHead.has(norm(c)));
    const map = isInt ? intMap : invMap;
    const cols = head.map((c) => map.get(norm(c)));
    head.forEach((c, i) => { if (c !== '' && !cols[i] && !(CALC.some((k) => Object.values(allDicts()).some((d) => norm(d['f.' + k]) === norm(c))) || ['appareil auto', 'hopital auto', 'device auto', 'hospital auto', 'device', 'hospital'].includes(norm(c)))) warn.ignoredCols.add(String(c)); });
    for (let r = hr + 1; r < aoa.length; r++) {
      const row = aoa[r]; const o = {};
      const idCol = cols.indexOf(isInt ? 'devId' : 'id'); const idv = String(row[idCol] ?? '').trim();
      if (!idv) { if (row.some((x) => x !== '')) warn.skipped++; continue; }
      const obsCol = cols.indexOf(isInt ? 'notes' : 'obsv'); if (obsCol >= 0 && /^(exemple|example)/i.test(String(row[obsCol]))) { warn.skipped++; continue; }
      if (isInt) {
        for (const f of IFIELDS) { const i = cols.indexOf(f.k); if (i >= 0) o[f.k] = convert(f, row[i], warn); }
        o.devId = idv; if (!o.date) { warn.skipped++; continue; }
        intervs.push(o);
      } else {
        o.custom = {};
        cols.forEach((k, i) => {
          if (!k) return;
          if (k.startsWith('custom:')) { const cf = state.settings.customFields.find((x) => x.id === k.slice(7)); if (cf) o.custom[cf.id] = convert({ type: cf.type === 'list' ? 'text' : cf.type === 'yn' ? 'select' : cf.type, list: 'yn' }, row[i], warn); return; }
          const f = FIELDS.find((x) => x.k === k); if (f) o[k] = convert(f, row[i], warn);
        });
        o.id = idv; devices.push(o);
      }
    }
  }
  return { devices, intervs, warn };
}
export async function runImportXlsx() {
  const file = await pickFile('.xlsx,.xls,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel');
  if (!file) return;
  let res; try { res = await importXlsx(file); } catch (e) { console.error(e); toast(t('io.readError')); return; }
  const { devices, intervs, warn } = res;
  if (!devices.length && !intervs.length) { toast(t('io.nothing')); return; }
  const byId = new Map(state.devices.map((d) => [d.id, d]));
  const upd = devices.filter((d) => byId.has(d.id)).length, add = devices.length - upd;
  const exist = new Set(state.intervs.map((r) => [r.date, r.devId, r.type, r.desc].join('|')));
  const newInt = intervs.filter((r) => !exist.has([r.date, r.devId, r.type, r.desc].join('|')));
  const ok = await confirmDialog({
    title: t('io.confirmTitle'), okLabel: t('io.import'),
    message: t('io.confirmMsg', { add, upd, ints: newInt.length }) + (warn.skipped ? '\n' + t('io.skipped', { n: warn.skipped }) : '') + (warn.bad ? '\n' + t('io.bad', { n: warn.bad }) : '') + (warn.ignoredCols.size ? '\n' + t('io.ignored', { cols: [...warn.ignoredCols].slice(0, 6).join(', ') }) : ''),
  });
  if (!ok) return;
  const S = state.settings, learn = (arr, v) => { if (v && !arr.includes(v)) arr.push(v); };
  const toPut = devices.map((n) => { const old = byId.get(n.id); const d = old ? { ...old, ...n, custom: { ...(old.custom || {}), ...(n.custom || {}) } } : { statut: 'in_service', ...n }; learn(S.hospitals, d.hop); learn(S.services, d.service); learn(S.types, d.desig); return d; });
  await bulkPut(toPut, newInt.map((r) => ({ ...r, uid: newUid() })));
  await saveSettings(); toast(t('io.done', { n: devices.length }));
}

// ---------- sauvegarde JSON ----------
export async function exportJson() {
  const strip = (o) => { const c = {}; for (const k of Object.keys(o)) if (!k.startsWith('__')) c[k] = o[k]; return c; };
  const data = { app: 'inventaire-biomedicale', v: 1, at: new Date().toISOString(), settings: state.settings, devices: state.devices.map(strip), intervs: state.intervs.map(strip) };
  await saveFile(`${t('xl.backup')}_${stamp()}.json`, 'application/json', textToB64(JSON.stringify(data)));
  state.settings.lastBackup = new Date().toISOString(); await saveSettings();
}
export async function runRestoreJson(afterRestore) {
  const file = await pickFile('.json,application/json'); if (!file) return;
  let data; try { data = JSON.parse(await file.text()); } catch (e) { toast(t('io.readError')); return; }
  if (!data || data.app !== 'inventaire-biomedicale' || !Array.isArray(data.devices)) { toast(t('io.notBackup')); return; }
  const ok = await confirmDialog({ title: t('io.restoreTitle'), message: t('io.restoreMsg', { d: data.devices.length, i: (data.intervs || []).length, date: (data.at || '').slice(0, 10) }), okLabel: t('io.restore'), danger: true });
  if (!ok) return;
  await clearData();
  await bulkPut(data.devices, data.intervs || []);
  if (data.settings) { const keepPin = state.settings.pin; Object.assign(state.settings, data.settings); if (!data.settings.pin || !data.settings.pin.enabled) state.settings.pin = keepPin; }
  await saveSettings(); toast(t('io.restored')); if (afterRestore) afterRestore();
}
