import { h, icon, openSheet, modalStack, toast } from './util.js';
import { t, registerLang, LANGS, missing } from './i18n.js';
import { fr } from './lang-fr.js';
import { en } from './lang-en.js';
import { init, state, saveSettings } from './store.js';
import { SEEDS } from './schema.js';
import { nav } from './nav.js';
import { applySettings } from './app-core.js';
import { dashView } from './view-dashboard.js';
import { invView, deviceView, deviceEditView } from './view-inventory.js';
import { maintView, intervEditView } from './view-maintenance.js';
import { settingsView, listEditView, customFieldsView } from './view-settings.js';
import { reschedule } from './notify.js';
import { showLock, trackLock } from './lock.js';
import { loadDemo } from './demo.js';

registerLang('fr', fr); registerLang('en', en);
window.__ib = { missing, state }; // outil de diagnostic
const VIEWS = { dash: dashView, inv: invView, maint: maintView, settings: settingsView, device: deviceView, 'device-edit': deviceEditView, 'interv-edit': intervEditView, 'list-edit': listEditView, 'custom-fields': customFieldsView };
const TABS = [['dash', 'dashboard', 'nav.dashboard'], ['inv', 'list', 'nav.inventory'], ['maint', 'wrench', 'nav.maintenance'], ['settings', 'settings', 'nav.settings']];
let stack = [{ view: 'dash', params: {} }];
const $ = (id) => document.getElementById(id);

function render(keepScroll) {
  const top = stack[stack.length - 1], main = $('main'), sc = keepScroll ? main.scrollTop : 0;
  let res;
  try { res = VIEWS[top.view](top.params || {}); } catch (e) { console.error(e); res = { title: t('common.error'), el: h('pre', { class: 'page pad' }, String(e && e.stack || e)), tab: 'dash' }; }
  const bar = $('appbar'), detail = stack.length > 1;
  bar.replaceChildren(
    detail ? h('button', { class: 'icon-btn', 'aria-label': t('common.back'), onclick: () => nav.back() }, icon('back')) : h('img', { class: 'logo', src: 'icons/icon-192.png', alt: '' }),
    h('h1', null, res.title), h('div', { class: 'bar-actions' }, res.actions || []));
  main.replaceChildren(res.el); main.scrollTop = sc;
  const fab = $('fab'); fab.hidden = !res.fab;
  if (res.fab) { fab.replaceChildren(icon('add', 24), h('span', null, res.fab.label)); fab.onclick = res.fab.onClick; }
  $('tabbar').replaceChildren(...TABS.map(([k, ic, lbl]) => h('button', { class: 'tab' + (res.tab === k ? ' on' : ''), 'aria-current': res.tab === k ? 'page' : null, onclick: () => nav.go(k) }, icon(ic, 24), h('span', null, t(lbl)))));
  document.title = t('app.name');
}
nav.go = (view, params) => { stack = [{ view, params: params || {} }]; render(); };
nav.push = (view, params) => { stack.push({ view, params: params || {} }); render(); };
nav.replace = (view, params) => { stack[stack.length - 1] = { view, params: params || {} }; render(); };
nav.back = () => { if (stack.length > 1) stack.pop(); render(); };
nav.refresh = () => render(true);

// Bouton retour Android
function setupBack() {
  const App = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App;
  if (!App || !App.addListener) return;
  App.addListener('backButton', () => {
    if (modalStack.length) { modalStack[modalStack.length - 1].close(); return; }
    if (stack.length > 1) { nav.back(); return; }
    if (stack[0].view !== 'dash') { nav.go('dash'); return; }
    App.exitApp();
  });
}

function onboarding() {
  return new Promise((resolve) => {
    let finished = false, hosp = SEEDS[state.settings.lang].hospitals.join('\n'), demo = false;
    const show = () => {
      const ta = h('textarea', { class: 'input', rows: 4 }); ta.value = hosp;
      const dm = h('input', { type: 'checkbox', id: 'ob-demo', checked: demo });
      const finish = async () => {
        if (finished) return; finished = true;
        const s = state.settings, L = SEEDS[s.lang];
        s.hospitals = ta.value.split('\n').map((x) => x.trim()).filter(Boolean); if (!s.hospitals.length) s.hospitals = [...L.hospitals];
        s.services = [...L.services]; s.types = [...L.types]; s.onboarded = true; await saveSettings();
        if (dm.checked) await loadDemo();
        resolve();
      };
      const langs = h('div', { class: 'seg-ctl' }, Object.entries(LANGS).map(([k, l]) => h('button', { type: 'button', class: state.settings.lang === k ? 'on' : '', onclick: async () => { hosp = ta.value; demo = dm.checked; state.settings.lang = k; if (hosp === SEEDS[k === 'fr' ? 'en' : 'fr'].hospitals.join('\n')) hosp = SEEDS[k].hospitals.join('\n'); applySettings(); api.close('lang'); } }, l)));
      const api = openSheet({
        title: t('ob.title'),
        body: h('div', null, h('p', null, t('ob.intro')), h('div', { class: 'field' }, h('label', null, t('set.langLabel')), langs), h('div', { class: 'field' }, h('label', null, t('ob.hospitals')), ta), h('label', { class: 'check', for: 'ob-demo' }, dm, h('span', null, t('ob.demo')))),
        actions: [{ label: t('ob.start'), cls: 'primary', onClick: finish }],
        onClose: (r) => { if (r === 'lang') show(); else finish(); },
      });
    };
    show();
  });
}

async function main() {
  await init();
  applySettings();
  document.getElementById('splash')?.remove();
  if (window.matchMedia) matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => applySettings());
  if (!state.settings.onboarded) await onboarding();
  applySettings(); render();
  setupBack(); trackLock();
  if (state.settings.pin.enabled) showLock();
  reschedule().catch((e) => console.warn(e));
  if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol) && !(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform())) navigator.serviceWorker.register('sw.js').catch(() => {});
}
main().catch((e) => { console.error(e); document.body.append(h('pre', { style: { padding: '16px', whiteSpace: 'pre-wrap' } }, 'Erreur de démarrage : ' + (e && e.stack || e))); });
