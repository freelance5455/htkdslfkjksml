// Notifications locales (Android natif via Capacitor ; navigateur en secours)
import { state } from './store.js';
import { C, live } from './logic.js';
import { t } from './i18n.js';
import { addDays, parseISO, debounce, todayISO } from './util.js';

const cap = () => window.Capacitor;
export const isNative = () => !!(cap() && cap().isNativePlatform && cap().isNativePlatform());
const LN = () => cap().Plugins.LocalNotifications;

export async function permission(request = false) {
  try {
    if (isNative()) { const r = request ? await LN().requestPermissions() : await LN().checkPermissions(); return r.display; }
    if (!('Notification' in window)) return 'unsupported';
    if (request) return (await Notification.requestPermission()) === 'granted' ? 'granted' : 'denied';
    return Notification.permission === 'granted' ? 'granted' : Notification.permission === 'denied' ? 'denied' : 'prompt';
  } catch (e) { return 'unsupported'; }
}

// Construit la liste des rappels à programmer (regroupés par jour)
export function buildPlan(now = new Date()) {
  const N = state.settings.notif, [hh, mm] = (N.time || '09:00').split(':').map(Number);
  const horizon = new Date(now.getTime() + 365 * 86400000), groups = new Map();
  const add = (kind, d, due) => {
    if (!due) return;
    const at = parseISO(addDays(due, -(+N.daysBefore || 0))); if (!at) return; at.setHours(hh, mm, 0, 0);
    if (at <= now || at > horizon) return;
    const key = at.getTime(); if (!groups.has(key)) groups.set(key, { at, maint: [], cal: [], gar: [] });
    groups.get(key)[kind].push(d);
  };
  for (const d of live()) {
    const c = C(d);
    if (N.maint) add('maint', d, c.nmp);
    if (N.cal) add('cal', d, c.ncal);
    if (N.warranty) add('gar', d, d.gfin);
  }
  const plan = [...groups.values()].sort((a, b) => a.at - b.at).slice(0, 50).map((g) => {
    const parts = [];
    if (g.maint.length) parts.push(t('notif.maint', { n: g.maint.length }));
    if (g.cal.length) parts.push(t('notif.cal', { n: g.cal.length }));
    if (g.gar.length) parts.push(t('notif.gar', { n: g.gar.length }));
    const names = [...new Set([...g.maint, ...g.cal, ...g.gar].map((d) => d.desig || d.id))].slice(0, 3).join(', ');
    return { at: g.at, title: t('notif.title', { n: new Set([...g.maint, ...g.cal, ...g.gar]).size, d: N.daysBefore }), body: parts.join(' · ') + (names ? ' — ' + names : '') };
  });
  if (N.overdue) {
    const n = live().filter((d) => C(d).smp === 'overdue' || C(d).scal === 'overdue').length;
    if (n) for (let i = 1; i <= 7; i++) { const at = new Date(now); at.setDate(at.getDate() + i); at.setHours(hh, mm, 0, 0); plan.push({ at, title: t('notif.overdueTitle'), body: t('notif.overdueBody', { n }) }); }
  }
  return plan;
}

export async function reschedule() {
  const N = state.settings.notif;
  if (isNative()) {
    const ln = LN();
    const pend = await ln.getPending();
    if (pend.notifications && pend.notifications.length) await ln.cancel({ notifications: pend.notifications });
    if (!N.enabled || (await permission()) !== 'granted') return 0;
    try { await ln.createChannel({ id: 'echeances', name: t('notif.channel'), description: t('notif.channelDesc'), importance: 4, visibility: 1 }); } catch (e) { /* déjà créé */ }
    const plan = buildPlan();
    if (plan.length) await ln.schedule({ notifications: plan.map((p, i) => ({ id: 1000 + i, title: p.title, body: p.body, channelId: 'echeances', smallIcon: 'ic_stat_notify', schedule: { at: p.at, allowWhileIdle: true } })) });
    return plan.length;
  }
  // Navigateur : rappel du jour, une fois par jour, à l'ouverture
  if (!N.enabled || (await permission()) !== 'granted') return 0;
  const key = 'ib-last-web-notif', today = todayISO();
  try { if (localStorage.getItem(key) === today) return 0; } catch (e) { /* ignore */ }
  const n = live().filter((d) => ['overdue', 'soon'].includes(C(d).smp) || ['overdue', 'soon'].includes(C(d).scal)).length;
  if (n) { new Notification(t('notif.overdueTitle'), { body: t('notif.webBody', { n }) }); try { localStorage.setItem(key, today); } catch (e) { /* ignore */ } }
  return n;
}
export const scheduleSoon = debounce(() => { reschedule().catch((e) => console.warn('notif', e)); }, 1500);

export async function pendingCount() {
  try { if (isNative()) return (await LN().getPending()).notifications.length; } catch (e) { /* ignore */ }
  return null;
}
export async function sendTest() {
  const title = t('notif.testTitle'), body = t('notif.testBody');
  if (isNative()) {
    const ln = LN();
    try { await ln.createChannel({ id: 'echeances', name: t('notif.channel'), description: t('notif.channelDesc'), importance: 4, visibility: 1 }); } catch (e) { /* ignore */ }
    await ln.schedule({ notifications: [{ id: 999, title, body, channelId: 'echeances', smallIcon: 'ic_stat_notify', schedule: { at: new Date(Date.now() + 3000), allowWhileIdle: true } }] });
  } else if ('Notification' in window && Notification.permission === 'granted') new Notification(title, { body });
}
