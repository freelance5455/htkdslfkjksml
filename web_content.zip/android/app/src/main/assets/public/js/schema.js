// Structure des données : champs de l'appareil, listes codées, groupes.
// >>> Pour ajouter un champ standard : ajoutez une ligne dans FIELDS et ses libellés (f.<clé>) dans i18n.js.
//     (Pour un simple champ en plus, utilisez plutôt Paramètres > Champs personnalisés : aucun code nécessaire.)

export const GROUPS = ['ident', 'loc', 'acq', 'life', 'mp', 'cal', 'tech'];

// type : text | number | date | select (liste codée) | suggest (texte avec suggestions) | hospital | textarea
export const FIELDS = [
  { k: 'id', g: 'ident', type: 'text', req: true },
  { k: 'desig', g: 'ident', type: 'suggest', src: 'types' },
  { k: 'fab', g: 'ident', type: 'text' },
  { k: 'model', g: 'ident', type: 'text' },
  { k: 'serie', g: 'ident', type: 'text' },
  { k: 'annee', g: 'ident', type: 'number', min: 1950, max: 2100 },
  { k: 'classe', g: 'ident', type: 'select', list: 'classe' },
  { k: 'crit', g: 'ident', type: 'select', list: 'crit' },
  { k: 'hop', g: 'loc', type: 'hospital' },
  { k: 'service', g: 'loc', type: 'suggest', src: 'services' },
  { k: 'salle', g: 'loc', type: 'text' },
  { k: 'statut', g: 'loc', type: 'select', list: 'statut' },
  { k: 'etat', g: 'loc', type: 'select', list: 'etat' },
  { k: 'dacq', g: 'acq', type: 'date' },
  { k: 'mode', g: 'acq', type: 'select', list: 'mode' },
  { k: 'fourn', g: 'acq', type: 'text' },
  { k: 'prix', g: 'acq', type: 'number', min: 0 },
  { k: 'bc', g: 'acq', type: 'text' },
  { k: 'gfin', g: 'acq', type: 'date' },
  { k: 'duree', g: 'life', type: 'number', min: 0, max: 60 },
  { k: 'pieces', g: 'life', type: 'select', list: 'yn' },
  { k: 'contrat', g: 'mp', type: 'select', list: 'yn' },
  { k: 'presta', g: 'mp', type: 'text' },
  { k: 'freq', g: 'mp', type: 'number', min: 0, max: 120 },
  { k: 'lmp', g: 'mp', type: 'date' },
  { k: 'lcal', g: 'cal', type: 'date' },
  { k: 'pcal', g: 'cal', type: 'number', min: 0, max: 120 },
  { k: 'alim', g: 'tech', type: 'text' },
  { k: 'fw', g: 'tech', type: 'text' },
  { k: 'acc', g: 'tech', type: 'text' },
  { k: 'doc', g: 'tech', type: 'text' },
  { k: 'ce', g: 'tech', type: 'select', list: 'yn' },
  { k: 'alerte', g: 'tech', type: 'select', list: 'yn' },
  { k: 'form', g: 'tech', type: 'select', list: 'yn' },
  { k: 'obsv', g: 'tech', type: 'textarea' },
];
export const FIELD = Object.fromEntries(FIELDS.map((f) => [f.k, f]));

// Colonnes calculées automatiquement (lecture seule)
export const CALC = ['gstat', 'age', 'fdv', 'obs', 'nmp', 'smp', 'ncal', 'scal'];

// Listes codées (les libellés sont traduits : c.<liste>.<code>)
export const CODES = {
  statut: ['in_service', 'stock', 'loan', 'repair', 'to_scrap', 'out_of_service', 'scrapped'],
  etat: ['good', 'fair', 'poor'],
  crit: ['critical', 'important', 'standard'],
  mode: ['purchase', 'gift', 'leasing', 'rental', 'loan', 'transfer'],
  yn: ['yes', 'no'],
  classe: ['I', 'IIa', 'IIb', 'III'],
  itype: ['preventive', 'corrective', 'calibration', 'safety', 'software', 'qc', 'install', 'other'],
  istatus: ['closed', 'ongoing', 'parts', 'cancelled'],
  iby: ['internal', 'external', 'manufacturer'],
  mstat: ['overdue', 'soon', 'ok', 'unplanned', 'na'],
};

// Champs d'une intervention (journal de maintenance)
export const IFIELDS = [
  { k: 'date', type: 'date', req: true },
  { k: 'devId', type: 'text', req: true },
  { k: 'type', type: 'select', list: 'itype' },
  { k: 'desc', type: 'textarea' },
  { k: 'cause', type: 'text' },
  { k: 'parts', type: 'text' },
  { k: 'by', type: 'select', list: 'iby' },
  { k: 'downtime', type: 'number', min: 0 },
  { k: 'cost', type: 'number', min: 0 },
  { k: 'status', type: 'select', list: 'istatus' },
  { k: 'notes', type: 'textarea' },
];

// Listes modifiables proposées au premier lancement
export const SEEDS = {
  fr: {
    services: ['Urgences', 'Réanimation / soins intensifs', 'Bloc opératoire', 'Imagerie / radiologie', 'Maternité / salle d\'accouchement', 'Néonatologie', 'Pédiatrie', 'Laboratoire', 'Dialyse', 'Médecine interne', 'Chirurgie', 'Stérilisation', 'Consultations', 'Autre'],
    types: ['Moniteur multiparamétrique', 'Respirateur / ventilateur', 'Pompe à perfusion', 'Pousse-seringue', 'Défibrillateur', 'Électrocardiographe (ECG)', 'Échographe', 'Appareil de radiologie', 'Scanner', 'Autoclave / stérilisateur', 'Table d\'opération', 'Scialytique', 'Incubateur néonatal', 'Table chauffante néonatale', 'Concentrateur d\'oxygène', 'Aspirateur chirurgical', 'Bistouri électrique', 'Analyseur de laboratoire', 'Générateur d\'hémodialyse', 'Autre'],
    hospitals: ['Hôpital 1', 'Hôpital 2', 'Hôpital 3'],
  },
  en: {
    services: ['Emergency', 'Intensive care', 'Operating theatre', 'Imaging / radiology', 'Maternity / delivery', 'Neonatology', 'Paediatrics', 'Laboratory', 'Dialysis', 'Internal medicine', 'Surgery', 'Sterilisation', 'Outpatient', 'Other'],
    types: ['Patient monitor', 'Ventilator', 'Infusion pump', 'Syringe pump', 'Defibrillator', 'ECG machine', 'Ultrasound', 'X-ray unit', 'CT scanner', 'Autoclave / steriliser', 'Operating table', 'Surgical light', 'Neonatal incubator', 'Infant warmer', 'Oxygen concentrator', 'Surgical suction', 'Electrosurgical unit', 'Laboratory analyser', 'Haemodialysis machine', 'Other'],
    hospitals: ['Hospital 1', 'Hospital 2', 'Hospital 3'],
  },
};

export const ACCENTS = { green: '#1E7145', blue: '#1565C0', teal: '#00796B', purple: '#6A1B9A', orange: '#D84315', slate: '#37474F' };
