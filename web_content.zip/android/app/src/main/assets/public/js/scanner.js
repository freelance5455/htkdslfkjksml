// Lecture de code-barres / QR code avec la caméra (si supportée), sinon saisie manuelle.
import { h, openSheet } from './util.js';
import { t } from './i18n.js';

export function openScanner(onCode) {
  const supported = 'BarcodeDetector' in window && navigator.mediaDevices && navigator.mediaDevices.getUserMedia;
  let stream = null, timer = null, closed = false;
  const video = h('video', { class: 'scan-video', playsinline: true, muted: true, autoplay: true });
  const msg = h('p', { class: 'muted' }, supported ? t('scan.hint') : t('scan.unsupported'));
  const manual = h('input', { class: 'input', type: 'text', placeholder: t('scan.manual'), autocapitalize: 'characters' });
  const api = openSheet({
    title: t('inv.scan'),
    body: h('div', null, supported ? video : null, msg, h('div', { class: 'field' }, manual)),
    actions: [{ label: t('common.cancel'), cls: 'text' }, { label: t('scan.search'), cls: 'primary', onClick: () => { if (manual.value.trim()) onCode(manual.value.trim()); } }],
    onClose: () => { closed = true; clearInterval(timer); if (stream) stream.getTracks().forEach((x) => x.stop()); },
  });
  if (!supported) return;
  (async () => {
    try {
      stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
      if (closed) { stream.getTracks().forEach((x) => x.stop()); return; }
      video.srcObject = stream; await video.play().catch(() => {});
      const det = new window.BarcodeDetector({ formats: ['qr_code', 'code_128', 'code_39', 'ean_13', 'ean_8', 'data_matrix', 'upc_a'] });
      timer = setInterval(async () => {
        try { const r = await det.detect(video); if (r.length && !closed) { const v = r[0].rawValue; api.close(); onCode(v); } } catch (e) { /* image pas prête */ }
      }, 350);
    } catch (e) { msg.textContent = t('scan.denied'); }
  })();
}
