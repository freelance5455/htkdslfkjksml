// Traduction : t('clé', {variables}). Les dictionnaires sont dans lang-fr.js et lang-en.js.
// >>> Pour ajouter une langue : copiez lang-en.js en lang-xx.js, traduisez, puis ajoutez-la dans app.js (registerLang) et LANGS.
import { state } from './store.js';
import { CODES } from './schema.js';
const dicts = {};
export const LANGS = { fr: 'Français', en: 'English' };
export const missing = new Set();
export function registerLang(code, dict) { dicts[code] = dict; }
export const lang = () => state.settings.lang || 'fr';
export function t(key, vars) {
  const d = dicts[lang()] || dicts.fr || {};
  let s = d[key];
  if (s === undefined) { s = (dicts.fr || {})[key]; if (s === undefined) { missing.add(key); s = key; } }
  if (vars) for (const [k, v] of Object.entries(vars)) s = s.split(`{${k}}`).join(v);
  return s;
}
export const fieldLabel = (k) => t('f.' + k);
export const ifieldLabel = (k) => t('if.' + k);
export function optLabel(list, code) {
  if (code === '' || code == null) return '';
  return list === 'classe' ? String(code) : t(`c.${list}.${code}`);
}
// Retrouve le code d'une liste à partir d'un libellé FR/EN ou du code (import Excel)
export function codeFromLabel(list, text, norm) {
  const n = norm(text); if (!n) return '';
  for (const code of CODES[list]) {
    if (norm(code) === n) return code;
    for (const L of Object.keys(dicts)) if (norm(dicts[L][`c.${list}.${code}`]) === n) return code;
  }
  return null;
}
export const allDicts = () => dicts;
