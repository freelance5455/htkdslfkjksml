// Stockage local (IndexedDB) + état de l'application. Tout reste sur l'appareil, hors-ligne.
const DB_NAME = 'inventaire-biomedicale', DB_VER = 1;
let db = null;
const memUid = () => (crypto.randomUUID ? crypto.randomUUID() : 'u' + Date.now().toString(36) + Math.random().toString(36).slice(2, 10));

export const DEFAULT_SETTINGS = () => ({
  lang: 'fr', theme: 'auto', accent: 'green', fontScale: 1,
  hospitals: [], services: [], types: [],
  alertDays: 30, eolYears: 2, currency: '', dateFormat: 'dd/mm/yyyy',
  notif: { enabled: false, daysBefore: 7, time: '09:00', maint: true, cal: true, warranty: true, overdue: true },
  pin: { enabled: false, hash: '', salt: '', lockAfterMin: 1 },
  customFields: [], updateUrl: '', lastBackup: '', onboarded: false,
});

export const state = { devices: [], intervs: [], settings: DEFAULT_SETTINGS(), ready: false, ver: 0 };

function open() {
  return new Promise((res, rej) => {
    const rq = indexedDB.open(DB_NAME, DB_VER);
    rq.onupgradeneeded = () => {
      const d = rq.result;
      if (!d.objectStoreNames.contains('devices')) d.createObjectStore('devices', { keyPath: 'uid' });
      if (!d.objectStoreNames.contains('intervs')) d.createObjectStore('intervs', { keyPath: 'uid' });
      if (!d.objectStoreNames.contains('kv')) d.createObjectStore('kv', { keyPath: 'key' });
    };
    rq.onsuccess = () => res(rq.result);
    rq.onerror = () => rej(rq.error);
  });
}
const tx = (stores, mode = 'readonly') => db.transaction(stores, mode);
const reqP = (r) => new Promise((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
const done = (t) => new Promise((res, rej) => { t.oncomplete = () => res(); t.onerror = () => rej(t.error); t.onabort = () => rej(t.error); });
const clean = (o) => { const c = {}; for (const k of Object.keys(o)) if (!k.startsWith('__')) c[k] = o[k]; return c; };

export async function init() {
  db = await open();
  const t = tx(['devices', 'intervs', 'kv']);
  const [devs, ints, kv] = await Promise.all([reqP(t.objectStore('devices').getAll()), reqP(t.objectStore('intervs').getAll()), reqP(t.objectStore('kv').get('settings'))]);
  state.devices = devs; state.intervs = ints;
  state.settings = mergeSettings(DEFAULT_SETTINGS(), kv ? kv.value : {});
  state.ready = true;
}
function mergeSettings(base, over) {
  for (const k of Object.keys(over || {})) {
    if (over[k] && typeof over[k] === 'object' && !Array.isArray(over[k]) && base[k] && typeof base[k] === 'object') base[k] = { ...base[k], ...over[k] };
    else base[k] = over[k];
  }
  return base;
}
export const bump = () => { state.ver++; };

export async function saveSettings() { bump(); const t = tx(['kv'], 'readwrite'); t.objectStore('kv').put({ key: 'settings', value: state.settings }); await done(t); }

export async function putDevice(d) {
  if (!d.uid) d.uid = memUid();
  const i = state.devices.findIndex((x) => x.uid === d.uid);
  if (i >= 0) state.devices[i] = d; else state.devices.push(d);
  bump(); const t = tx(['devices'], 'readwrite'); t.objectStore('devices').put(clean(d)); await done(t); return d;
}
export async function delDevice(uid) {
  state.devices = state.devices.filter((x) => x.uid !== uid);
  bump(); const t = tx(['devices'], 'readwrite'); t.objectStore('devices').delete(uid); await done(t);
}
export async function putInterv(r) {
  if (!r.uid) r.uid = memUid();
  const i = state.intervs.findIndex((x) => x.uid === r.uid);
  if (i >= 0) state.intervs[i] = r; else state.intervs.push(r);
  bump(); const t = tx(['intervs'], 'readwrite'); t.objectStore('intervs').put(clean(r)); await done(t); return r;
}
export async function delInterv(uid) {
  state.intervs = state.intervs.filter((x) => x.uid !== uid);
  bump(); const t = tx(['intervs'], 'readwrite'); t.objectStore('intervs').delete(uid); await done(t);
}
// Écrit en une seule transaction (import, restauration, démo)
export async function bulkPut(devices, intervs) {
  const t = tx(['devices', 'intervs'], 'readwrite');
  for (const d of devices) { if (!d.uid) d.uid = memUid(); t.objectStore('devices').put(clean(d)); const i = state.devices.findIndex((x) => x.uid === d.uid); if (i >= 0) state.devices[i] = d; else state.devices.push(d); }
  for (const r of intervs) { if (!r.uid) r.uid = memUid(); t.objectStore('intervs').put(clean(r)); const i = state.intervs.findIndex((x) => x.uid === r.uid); if (i >= 0) state.intervs[i] = r; else state.intervs.push(r); }
  bump(); await done(t);
}
export async function clearData() {
  const t = tx(['devices', 'intervs'], 'readwrite');
  t.objectStore('devices').clear(); t.objectStore('intervs').clear(); await done(t);
  state.devices = []; state.intervs = []; bump();
}
export async function resetAll() {
  await clearData(); const t = tx(['kv'], 'readwrite'); t.objectStore('kv').clear(); await done(t);
  state.settings = DEFAULT_SETTINGS(); bump();
}
export const newUid = memUid;
