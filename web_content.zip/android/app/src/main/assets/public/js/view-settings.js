import { h, icon, toast, openSheet, confirmDialog, promptDialog, uid } from './util.js';
import { t, LANGS } from './i18n.js';
import { state, saveSettings, putDevice, resetAll, clearData } from './store.js';
import { ACCENTS, SEEDS } from './schema.js';
import { nav } from './nav.js';
import { applySettings, appInfo } from './app-core.js';
import { permission, reschedule, pendingCount, sendTest, scheduleSoon } from './notify.js';
import { exportXlsx, runImportXlsx, exportJson, runRestoreJson } from './io.js';
import { pinPad, setPin, checkPin } from './lock.js';
import { loadDemo } from './demo.js';

const S = () => state.settings;
const save = async (fn) => { fn(); await saveSettings(); };

function seg(options, value, onChange) {
  const box = h('div', { class: 'seg-ctl', role: 'radiogroup' });
  options.forEach(([v, l]) => box.append(h('button', { type: 'button', role: 'radio', 'aria-checked': String(v === value), class: v === value ? 'on' : '', onclick: () => onChange(v) }, l)));
  return box;
}
function toggle(value, onChange, label) {
  const b = h('button', { type: 'button', role: 'switch', 'aria-checked': String(!!value), 'aria-label': label, class: 'switch' + (value ? ' on' : '') }, h('i'));
  b.addEventListener('click', () => { const v = b.getAttribute('aria-checked') !== 'true'; b.setAttribute('aria-checked', String(v)); b.classList.toggle('on', v); onChange(v); });
  return b;
}
const row = (label, control, sub, onClick) => h(onClick ? 'button' : 'div', { class: 'srow' + (onClick ? ' tap' : ''), onclick: onClick }, h('div', { class: 'srow-main' }, h('div', { class: 'srow-t' }, label), sub ? h('div', { class: 'srow-s' }, sub) : null), control || (onClick ? icon('chevron', 20) : null));
const stack = (label, control, sub) => h('div', { class: 'srow col' }, h('div', { class: 'srow-t' }, label), sub ? h('div', { class: 'srow-s' }, sub) : null, control);
const section = (title, ic, ...kids) => h('section', { class: 'card' }, h('div', { class: 'card-h' }, h('h3', null, icon(ic, 20), title)), kids);

export function settingsView() {
  const el = h('div', { class: 'page' }), s = S();
  // Apparence
  const sw = h('div', { class: 'swatches' }, Object.entries(ACCENTS).map(([k, c]) => h('button', { type: 'button', class: 'swatch' + (s.accent === k ? ' on' : ''), style: { background: c }, 'aria-label': k, onclick: async () => { await save(() => { s.accent = k; }); applySettings(); nav.refresh(); } }, s.accent === k ? icon('check', 18) : null)));
  el.append(section(t('set.appearance'), 'palette',
    stack(t('set.theme'), seg([['auto', t('set.themeAuto')], ['light', t('set.themeLight')], ['dark', t('set.themeDark')]], s.theme, async (v) => { await save(() => { s.theme = v; }); applySettings(); nav.refresh(); })),
    stack(t('set.accent'), sw),
    stack(t('set.fontSize'), seg([[0.9, t('set.small')], [1, t('set.medium')], [1.12, t('set.large')], [1.25, t('set.xlarge')]], s.fontScale, async (v) => { await save(() => { s.fontScale = v; }); applySettings(); nav.refresh(); }))));
  // Langue
  el.append(section(t('set.language'), 'globe', stack(t('set.langLabel'), seg(Object.entries(LANGS), s.lang, async (v) => { await save(() => { s.lang = v; }); applySettings(); nav.refresh(); }))));
  // Notifications
  const nstat = h('div', { class: 'srow-s' });
  const N = s.notif;
  const refreshStat = async () => { const p = await permission(); const c = await pendingCount(); nstat.textContent = N.enabled ? (p === 'granted' ? t('set.notifOn') + (c != null ? ' · ' + t('set.notifPending', { n: c }) : '') : t('set.notifDenied')) : t('set.notifOff'); };
  refreshStat();
  const nsub = (k, label) => row(label, toggle(N[k], async (v) => { await save(() => { N[k] = v; }); scheduleSoon(); }, label));
  el.append(section(t('set.notifications'), 'bell',
    h('div', { class: 'srow' }, h('div', { class: 'srow-main' }, h('div', { class: 'srow-t' }, t('set.notifEnable')), nstat), toggle(N.enabled, async (v) => {
      if (v) { const p = await permission(true); if (p !== 'granted') { toast(t('set.notifDenied')); await save(() => { N.enabled = false; }); nav.refresh(); return; } }
      await save(() => { N.enabled = v; }); await reschedule(); refreshStat();
    }, t('set.notifEnable'))),
    row(t('set.notifDays'), (() => { const sel = h('select', { class: 'input small' }, [1, 3, 7, 14, 30].map((n) => h('option', { value: n }, t('set.nDays', { n })))); sel.value = N.daysBefore; sel.addEventListener('change', async () => { await save(() => { N.daysBefore = +sel.value; }); scheduleSoon(); }); return sel; })()),
    row(t('set.notifTime'), (() => { const i = h('input', { class: 'input small', type: 'time', value: N.time }); i.addEventListener('change', async () => { if (!i.value) return; await save(() => { N.time = i.value; }); scheduleSoon(); }); return i; })()),
    nsub('maint', t('set.notifMaint')), nsub('cal', t('set.notifCal')), nsub('warranty', t('set.notifWarranty')), nsub('overdue', t('set.notifOverdue')),
    row(t('set.notifTest'), null, t('set.notifTestSub'), async () => { if ((await permission(true)) !== 'granted') { toast(t('set.notifDenied')); return; } await sendTest(); toast(t('set.notifTestSent')); }),
    h('p', { class: 'note' }, t('set.notifNote'))));
  // Données
  el.append(section(t('set.data'), 'tune',
    row(t('set.hospitals'), h('span', { class: 'pill' }, s.hospitals.length), null, () => nav.push('list-edit', { kind: 'hospitals' })),
    row(t('set.services'), h('span', { class: 'pill' }, s.services.length), null, () => nav.push('list-edit', { kind: 'services' })),
    row(t('set.types'), h('span', { class: 'pill' }, s.types.length), null, () => nav.push('list-edit', { kind: 'types' })),
    row(t('set.custom'), h('span', { class: 'pill' }, s.customFields.length), t('set.customSub'), () => nav.push('custom-fields')),
    row(t('set.alertDays'), numInput(s.alertDays, 0, 365, async (v) => { await save(() => { s.alertDays = v; }); scheduleSoon(); }), t('set.alertDaysSub')),
    row(t('set.eolYears'), numInput(s.eolYears, 0, 20, async (v) => { await save(() => { s.eolYears = v; }); }), t('set.eolYearsSub')),
    row(t('set.currency'), (() => { const i = h('input', { class: 'input small', type: 'text', value: s.currency, maxlength: 8, placeholder: '€, $, FCFA…' }); i.addEventListener('change', async () => { await save(() => { s.currency = i.value.trim(); }); }); return i; })()),
    row(t('set.dateFormat'), (() => { const sel = h('select', { class: 'input small' }, ['dd/mm/yyyy', 'mm/dd/yyyy', 'yyyy-mm-dd'].map((f) => h('option', { value: f }, f))); sel.value = s.dateFormat; sel.addEventListener('change', async () => { await save(() => { s.dateFormat = sel.value; }); }); return sel; })())));
  // Sauvegarde
  const lb = s.lastBackup ? new Date(s.lastBackup).toLocaleString(s.lang === 'en' ? 'en-GB' : 'fr-FR') : t('set.never');
  el.append(section(t('set.backup'), 'cloud',
    row(t('set.exportXlsx'), icon('download', 20), t('set.exportXlsxSub'), () => run(exportXlsx)),
    row(t('set.importXlsx'), icon('upload', 20), t('set.importXlsxSub'), () => run(runImportXlsx)),
    row(t('set.exportJson'), icon('download', 20), t('set.exportJsonSub'), () => run(exportJson)),
    row(t('set.restoreJson'), icon('upload', 20), t('set.restoreJsonSub'), () => run(() => runRestoreJson(() => { applySettings(); nav.refresh(); }))),
    h('p', { class: 'note' }, t('set.lastBackup', { d: lb }))));
  // Sécurité
  const P = s.pin;
  el.append(section(t('set.security'), 'lock',
    h('div', { class: 'srow' }, h('div', { class: 'srow-main' }, h('div', { class: 'srow-t' }, t('set.pin')), h('div', { class: 'srow-s' }, t('set.pinSub'))), toggle(P.enabled, async (v) => { if (v) { askNewPin(() => nav.refresh()); setTimeout(() => nav.refresh(), 0); } else { askDisablePin(() => nav.refresh()); setTimeout(() => nav.refresh(), 0); } }, t('set.pin'))),
    P.enabled ? row(t('set.pinChange'), null, null, () => askNewPin(() => nav.refresh())) : null,
    P.enabled ? row(t('set.lockAfter'), (() => { const sel = h('select', { class: 'input small' }, [[0, t('set.lockNow')], [1, t('set.nMin', { n: 1 })], [5, t('set.nMin', { n: 5 })], [15, t('set.nMin', { n: 15 })]].map(([v, l]) => h('option', { value: v }, l))); sel.value = P.lockAfterMin; sel.addEventListener('change', async () => { await save(() => { P.lockAfterMin = +sel.value; }); }); return sel; })()) : null));
  // Mises à jour & à propos
  const info = h('span', { class: 'pill' }, '…'); appInfo().then((i) => { info.textContent = i; });
  el.append(section(t('set.about'), 'info',
    row(t('set.version'), info),
    stack(t('set.updateUrl'), (() => { const i = h('input', { class: 'input', type: 'url', value: s.updateUrl, placeholder: 'https://github.com/…/releases/latest' }); i.addEventListener('change', async () => { await save(() => { s.updateUrl = i.value.trim(); }); }); return i; })(), t('set.updateUrlSub')),
    row(t('set.checkUpdate'), icon('sync', 20), null, () => { if (!s.updateUrl) { toast(t('set.noUpdateUrl')); return; } window.open(s.updateUrl, '_system'); }),
    h('p', { class: 'note' }, t('set.updateHow'))));
  // Avancé
  el.append(section(t('set.advanced'), 'warning',
    row(t('set.demo'), null, t('set.demoSub'), async () => { if (state.devices.length && !(await confirmDialog({ title: t('set.demo'), message: t('set.demoWarn') }))) return; const n = await loadDemo(); toast(t('set.demoDone', { n })); nav.go('dash'); }),
    row(t('set.deleteData'), null, t('set.deleteDataSub'), async () => { if (await confirmDialog({ title: t('set.deleteData'), message: t('set.deleteDataMsg'), okLabel: t('common.delete'), danger: true })) { await clearData(); toast(t('common.deleted')); nav.go('dash'); } }),
    row(t('set.reset'), null, t('set.resetSub'), async () => { if (await confirmDialog({ title: t('set.reset'), message: t('set.resetMsg'), okLabel: t('set.reset'), danger: true })) { await resetAll(); location.reload(); } })));
  return { title: t('nav.settings'), el, tab: 'settings' };
}
async function run(fn) { try { await fn(); } catch (e) { console.error(e); toast(t('common.error') + ' : ' + (e && e.message ? e.message : e)); } }
function numInput(v, min, max, onChange) {
  const i = h('input', { class: 'input small', type: 'number', inputmode: 'numeric', min, max, value: v });
  i.addEventListener('change', () => { let n = Math.round(+i.value); if (isNaN(n)) n = v; n = Math.min(max, Math.max(min, n)); i.value = n; onChange(n); });
  return i;
}
function askNewPin(done) {
  let first = null; const host = h('div'); let api;
  const render = () => { host.replaceChildren(pinPad({ title: first ? t('lock.confirm') : t('lock.new'), sub: t('lock.hint'), onDone: async (v, msg) => {
    if (!first) { first = v; render(); return true; }
    if (first !== v) { first = null; render(); host.querySelector('.pin-msg').textContent = t('lock.mismatch'); return false; }
    await setPin(v); api.close(); toast(t('lock.set')); done(); return true;
  } })); };
  api = openSheet({ title: t('set.pin'), body: host }); render();
}
function askDisablePin(done) {
  const host = h('div'); let api;
  host.append(pinPad({ title: t('lock.disable'), sub: t('lock.enter'), onDone: async (v, msg) => { if (await checkPin(v)) { state.settings.pin = { ...state.settings.pin, enabled: false, hash: '', salt: '' }; await saveSettings(); api.close(); toast(t('lock.off')); done(); return true; } msg.textContent = t('lock.wrong'); return false; } }));
  api = openSheet({ title: t('set.pin'), body: host });
}

// ---------- éditeur de listes (hôpitaux, services, types) ----------
export function listEditView({ kind }) {
  const s = S(), key = kind, field = { hospitals: 'hop', services: 'service', types: 'desig' }[kind];
  const el = h('div', { class: 'page' }), box = h('section', { class: 'card' });
  const render = () => {
    box.replaceChildren(h('div', { class: 'card-h' }, h('h3', null, t('set.' + kind)), h('span', { class: 'pill' }, s[key].length)));
    s[key].forEach((name, i) => {
      const used = state.devices.filter((d) => d[field] === name).length;
      box.append(h('div', { class: 'srow' }, h('div', { class: 'srow-main' }, h('div', { class: 'srow-t' }, name), used ? h('div', { class: 'srow-s' }, t('set.usedBy', { n: used })) : null),
        h('button', { class: 'icon-btn', 'aria-label': t('common.edit'), onclick: async () => {
          const nv = await promptDialog({ title: t('common.edit'), value: name }); if (!nv || nv === name) return;
          if (s[key].includes(nv)) { toast(t('set.exists')); return; }
          s[key][i] = nv; for (const d of state.devices.filter((d) => d[field] === name)) await putDevice({ ...d, [field]: nv });
          await saveSettings(); render();
        } }, icon('edit')),
        h('button', { class: 'icon-btn', 'aria-label': t('common.delete'), onclick: async () => {
          if (await confirmDialog({ title: t('common.delete'), message: used ? t('set.deleteUsed', { name, n: used }) : t('set.deleteItem', { name }), okLabel: t('common.delete'), danger: true })) { s[key].splice(i, 1); await saveSettings(); render(); }
        } }, icon('delete'))));
    });
    box.append(h('div', { class: 'pad' }, h('button', { class: 'btn primary block', onclick: async () => {
      const v = await promptDialog({ title: t('set.addItem'), label: t('set.name') }); if (!v) return;
      if (s[key].includes(v)) { toast(t('set.exists')); return; }
      s[key].push(v); await saveSettings(); render();
    } }, icon('add', 18), t('set.addItem'))));
  };
  render(); el.append(box, h('p', { class: 'note pad' }, t('set.listNote')));
  return { title: t('set.' + kind), el, tab: 'settings' };
}

// ---------- champs personnalisés ----------
export function customFieldsView() {
  const s = S(), el = h('div', { class: 'page' }), box = h('section', { class: 'card' });
  const edit = (f) => {
    const isNew = !f; const cur = f ? { ...f } : { id: 'c_' + uid().slice(0, 6), label: '', type: 'text', options: [] };
    const label = h('input', { class: 'input', type: 'text', value: cur.label }), type = h('select', { class: 'input' }, ['text', 'number', 'date', 'yn', 'list'].map((x) => h('option', { value: x }, t('set.ctype.' + x)))); type.value = cur.type;
    const opts = h('textarea', { class: 'input', rows: 3, placeholder: t('set.optionsPh') }); opts.value = (cur.options || []).join('\n');
    const optField = h('div', { class: 'field' }, h('label', null, t('set.options')), opts); optField.hidden = cur.type !== 'list';
    type.addEventListener('change', () => { optField.hidden = type.value !== 'list'; });
    openSheet({ title: isNew ? t('set.addField') : t('common.edit'), body: h('div', null, h('div', { class: 'field' }, h('label', null, t('set.fieldName')), label), h('div', { class: 'field' }, h('label', null, t('set.fieldType')), type), optField),
      actions: [{ label: t('common.cancel'), cls: 'text' }, { label: t('common.save'), cls: 'primary', onClick: async () => {
        if (!label.value.trim()) return false;
        cur.label = label.value.trim(); cur.type = type.value; cur.options = cur.type === 'list' ? opts.value.split('\n').map((x) => x.trim()).filter(Boolean) : [];
        if (isNew) s.customFields.push(cur); else Object.assign(f, cur);
        await saveSettings(); render();
      } }] });
  };
  const render = () => {
    box.replaceChildren(h('div', { class: 'card-h' }, h('h3', null, t('set.custom')), h('span', { class: 'pill' }, s.customFields.length)));
    if (!s.customFields.length) box.append(h('p', { class: 'muted pad' }, t('set.noCustom')));
    s.customFields.forEach((f, i) => box.append(h('div', { class: 'srow' }, h('div', { class: 'srow-main' }, h('div', { class: 'srow-t' }, f.label), h('div', { class: 'srow-s' }, t('set.ctype.' + f.type))),
      h('button', { class: 'icon-btn', 'aria-label': t('common.edit'), onclick: () => edit(f) }, icon('edit')),
      h('button', { class: 'icon-btn', 'aria-label': t('common.delete'), onclick: async () => { if (await confirmDialog({ title: t('common.delete'), message: t('set.deleteField', { name: f.label }), okLabel: t('common.delete'), danger: true })) { s.customFields.splice(i, 1); await saveSettings(); render(); } } }, icon('delete')))));
    box.append(h('div', { class: 'pad' }, h('button', { class: 'btn primary block', onclick: () => edit(null) }, icon('add', 18), t('set.addField'))));
  };
  render(); el.append(box, h('p', { class: 'note pad' }, t('set.customNote')));
  return { title: t('set.custom'), el, tab: 'settings' };
}
