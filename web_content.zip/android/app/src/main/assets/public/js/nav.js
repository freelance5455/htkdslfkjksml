// Objet de navigation partagé (rempli par app.js)
export const nav = { go() {}, push() {}, back() {}, refresh() {}, replace() {} };
