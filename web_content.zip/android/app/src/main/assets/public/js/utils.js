export const DAY_MS = 86_400_000;

export function uid(prefix = 'px') {
  const bytes = crypto?.getRandomValues ? crypto.getRandomValues(new Uint32Array(2)) : [Date.now(), Math.random() * 1e9];
  return `${prefix}-${Date.now().toString(36)}-${Number(bytes[0]).toString(36)}${Number(bytes[1]).toString(36)}`;
}
export function dateKey(value = new Date()) {
  const d = new Date(value);
  const offset = d.getTimezoneOffset() * 60_000;
  return new Date(d.getTime() - offset).toISOString().slice(0, 10);
}
export function dateLabel(value, style = 'medium') {
  return new Intl.DateTimeFormat(undefined, { weekday: style === 'long' ? 'long' : undefined, month: 'short', day: 'numeric', year: style === 'long' ? 'numeric' : undefined }).format(new Date(value));
}
export function timeLabel(value) {
  return new Intl.DateTimeFormat(undefined, { hour: 'numeric', minute: '2-digit' }).format(new Date(value));
}
export function greeting() {
  const h = new Date().getHours();
  return h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
}
export function haversineKm(a, b) {
  const rad = Math.PI / 180; const R = 6371;
  const dLat = (b.latitude - a.latitude) * rad;
  const dLng = (b.longitude - a.longitude) * rad;
  const q = Math.sin(dLat / 2) ** 2 + Math.cos(a.latitude * rad) * Math.cos(b.latitude * rad) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.atan2(Math.sqrt(q), Math.sqrt(1 - q));
}
export function secondsToClock(total = 0) {
  total = Math.max(0, Math.floor(total));
  const h = Math.floor(total / 3600); const m = Math.floor((total % 3600) / 60); const s = total % 60;
  return h ? `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}` : `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}
export function durationLong(total = 0) {
  total = Math.round(total); const h = Math.floor(total / 3600); const m = Math.floor((total % 3600) / 60); const s = total % 60;
  return h ? `${h}h ${m}m` : m ? `${m}m ${s}s` : `${s}s`;
}
export function paceFrom(distanceKm, seconds) { return distanceKm > 0.025 && seconds > 0 ? seconds / 60 / distanceKm : null; }
export function formatPace(pace, unit = 'km') {
  if (!Number.isFinite(pace) || pace <= 0 || pace > 99) return '—';
  const shown = unit === 'mi' ? pace * 1.609344 : pace;
  const m = Math.floor(shown); const s = Math.round((shown - m) * 60);
  return `${m}:${String(s === 60 ? 0 : s).padStart(2, '0')}/${unit}`;
}
export function formatDistance(km = 0, unit = 'km', precise = false) {
  const n = unit === 'mi' ? km * 0.621371 : km;
  const digits = precise ? 2 : n < 10 ? 2 : 1;
  return `${n.toFixed(digits)} ${unit}`;
}
export function rawDistance(km = 0, unit = 'km', digits = 2) { return (unit === 'mi' ? km * .621371 : km).toFixed(digits); }
export function formatSpeed(kmh, unit = 'km') { return Number.isFinite(kmh) && kmh >= 0 ? `${(unit === 'mi' ? kmh * .621371 : kmh).toFixed(1)} ${unit}/h` : '—'; }
export function modeLabel(mode = 'running') { return mode.charAt(0).toUpperCase() + mode.slice(1); }
export function maxSpeed(mode) { return { walking: 12, running: 30, cycling: 75 }[mode] || 30; }
export function caloriesFor(mode, seconds, distanceKm, weightKg = 70) {
  // Conservative MET estimate. Displayed explicitly as an estimate, not a medical value.
  const met = { walking: 3.8, running: 9.8, cycling: 7.5 }[mode] || 5;
  const durationH = seconds / 3600;
  const metCalories = met * Math.max(35, Number(weightKg) || 70) * durationH;
  const distanceFloor = { walking: 45, running: 60, cycling: 26 }[mode] * Math.max(0, distanceKm);
  return Math.round(Math.max(metCalories, distanceFloor * .45));
}
export function escapeHtml(value = '') {
  return String(value).replace(/[&<>'"]/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;' }[c]));
}
export function lastNDays(n) { return Array.from({ length:n }, (_, i) => dateKey(Date.now() - (n - 1 - i) * DAY_MS)); }
export function sum(values) { return values.reduce((total, v) => total + (Number(v) || 0), 0); }
export function safeNumber(v, fallback = 0) { const n = Number(v); return Number.isFinite(n) ? n : fallback; }
