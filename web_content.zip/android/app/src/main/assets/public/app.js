const LC=LightweightCharts;
const chart=LC.createChart(document.getElementById('chart'),{autoSize:true,layout:{background:{type:'solid',color:'#0b1220'},textColor:'#9cafc9'},grid:{vertLines:{color:'#17243a'},horzLines:{color:'#17243a'}},rightPriceScale:{borderColor:'#26344c'},timeScale:{borderColor:'#26344c',timeVisible:true}});
const series=chart.addSeries(LC.CandlestickSeries,{upColor:'#27c281',downColor:'#f05b6e',borderVisible:false,wickUpColor:'#27c281',wickDownColor:'#f05b6e'});
let data=[];let p=760;for(let i=0;i<650;i++){let d=new Date('2016-01-01');d.setDate(d.getDate()+Math.floor(i*1.45));let o=p,n=(Math.random()-.48)*18+.55+Math.sin(i/35)*.35,c=Math.max(300,o+n),h=Math.max(o,c)+Math.random()*14,l=Math.min(o,c)-Math.random()*14;p=c;data.push({time:d.toISOString().slice(0,10),open:+o.toFixed(2),high:+h.toFixed(2),low:+l.toFixed(2),close:+c.toFixed(2)})}
let cursor=data.length,replay=false;
for(let y=2016;y<=2026;y++){let o=document.createElement('option');o.value=y;o.textContent=y;year.appendChild(o)}
function render(){let v=data.slice(0,cursor);series.setData(v);if(v.length){date.textContent=v.at(-1).time;price.textContent=v.at(-1).close.toFixed(2)}progress.textContent=cursor+'/'+data.length;mode.textContent=replay?'REPLAY MODE':'LIVE VIEW'}
render();chart.timeScale().fitContent();
next.onclick=()=>{if(!replay){replay=true;cursor=Math.min(60,data.length)}cursor=Math.min(data.length,cursor+1);render()};
replay.onclick=()=>{replay=!replay;if(replay&&cursor>=data.length)cursor=60;render()};
reset.onclick=()=>{replay=false;cursor=data.length;render();chart.timeScale().fitContent()};
clear.onclick=()=>alert('Drawing layer reset. V2 will add persistent interactive drawings.');
document.querySelectorAll('.tool').forEach(x=>x.onclick=()=>{document.querySelectorAll('.tool').forEach(y=>y.classList.remove('active'));x.classList.add('active')});
record.onclick=()=>{let e=+entry.value,s=+sl.value,t=+target.value;if(!e||!s||!t)return alert('Enter Entry, SL and Target');let v=data[Math.max(0,cursor-1)],sideEl=document.getElementById('side');let result='OPEN';if(v){if(sideEl.value==='BUY CE'){if(v.low<=s)result='SL';else if(v.high>=t)result='TARGET'}else{if(v.high>=s)result='SL';else if(v.low<=t)result='TARGET'}}let tr=document.createElement('tr');tr.innerHTML='<td>'+v.time+'</td><td>'+sideEl.value+'</td><td>'+e+'</td><td>'+s+'</td><td>'+t+'</td><td>'+result+'</td>';body.prepend(tr);stats()};
function stats(){let rs=[...body.rows],w=rs.filter(r=>r.cells[5].textContent==='TARGET').length,l=rs.filter(r=>r.cells[5].textContent==='SL').length;trades.textContent=rs.length;wins.textContent=w;losses.textContent=l;rate.textContent=(rs.length?Math.round(w/rs.length*100):0)+'%'};
export.onclick=()=>{let rs=[['Date','Side','Entry','SL','Target','Result'],...([...body.rows].map(r=>[...r.cells].map(c=>c.textContent)))];let csv=rs.map(r=>r.map(x=>'"'+x.replaceAll('"','""')+'"').join(',')).join('\n');let a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv'}));a.download='nifty-journal.csv';a.click()};
