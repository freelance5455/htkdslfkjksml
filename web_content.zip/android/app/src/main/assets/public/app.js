const crafts=[
{id:1,name:"Paper Butterfly",cat:"Origami",art:"🦋",level:"Easy",time:"10 min",steps:[["Prepare paper","Take one square sheet of colourful paper."],["Fold diagonally","Fold the paper diagonally to form a triangle."],["Shape corners","Bring the lower corners toward the top point."],["Create wings","Fold the outer edges slightly."],["Finish","Open the wings gently and decorate."]]},
{id:2,name:"Paper Flower",cat:"Flowers",art:"🌸",level:"Easy",time:"15 min",steps:[["Prepare","Take colourful paper and scissors."],["Make petals","Cut several similar petal shapes."],["Centre","Roll a small piece of yellow paper."],["Arrange","Glue the petals around the centre."],["Finish","Attach a paper stem and leaves."]]},
{id:3,name:"Origami Boat",cat:"Origami",art:"⛵",level:"Easy",time:"5 min",steps:[["Prepare","Take one rectangular sheet of paper."],["Fold","Fold it in half from top to bottom."],["Shape","Fold the top corners toward the middle."],["Open edges","Fold the bottom edges upward."],["Finish","Open the bottom and shape into a boat."]]},
{id:4,name:"Greeting Card",cat:"Cards",art:"💌",level:"Easy",time:"15 min",steps:[["Prepare","Take a rectangular sheet of coloured paper."],["Fold","Fold it in half."],["Decorate","Cut small paper shapes."],["Attach","Glue the decorations onto the front."],["Finish","Write your greeting inside."]]},
{id:5,name:"Paper House",cat:"Models",art:"🏠",level:"Medium",time:"25 min",steps:[["Prepare","Take thick paper, ruler and glue."],["Draw","Draw a house template."],["Cut","Carefully cut the template."],["Fold","Fold walls along their edges."],["Assemble","Glue walls together and attach the roof."]]},
{id:6,name:"Paper Heart",cat:"Origami",art:"💜",level:"Easy",time:"8 min",steps:[["Prepare","Take a square sheet of paper."],["Fold","Fold it in half and unfold."],["Shape","Fold the top corners inward."],["Make heart","Fold edges to create a heart shape."],["Finish","Turn it over and adjust the corners."]]}
];
let selected=null,step=0,filter="All";
let favorites=JSON.parse(localStorage.getItem("pcFav")||"[]");
let completed=JSON.parse(localStorage.getItem("pcDone")||"[]");
const $=id=>document.getElementById(id);
function page(p){
 ["home","tutorial","favorites","progress"].forEach(x=>$(x).classList.toggle("hide",x!==p));
 if(p==="favorites")favRender();
 if(p==="progress")progressRender();
 window.scrollTo(0,0);
}
function renderFilters(){
 $("filters").innerHTML=["All","Origami","Flowers","Cards","Models"].map(c=>`<button class="${filter===c?'active':''}" onclick="setFilter('${c}')">${c}</button>`).join("");
}
function setFilter(c){filter=c;render()}
function render(){
 renderFilters();
 let q=$("search").value.toLowerCase();
 let list=crafts.filter(c=>(filter==="All"||c.cat===filter)&&c.name.toLowerCase().includes(q));
 $("grid").innerHTML=list.map(c=>card(c)).join("")||"<p>No crafts found.</p>";
}
function card(c){return `<div class="craft"><div class="art">${c.art}</div><div class="info"><h4>${c.name}</h4><p>${c.level} · ${c.time}</p><button class="primary" onclick="openCraft(${c.id})">Start making →</button></div></div>`}
function openCraft(id){selected=crafts.find(c=>c.id===id);step=0;page("tutorial");renderStep()}
function renderStep(){
 let c=selected,s=c.steps[step];
 $("tutorialBody").innerHTML=`<small style="color:#b99aff;letter-spacing:2px">${c.cat.toUpperCase()} · ${c.level.toUpperCase()}</small><h2>${c.name}</h2><div class="tutorialArt">${c.art}</div><div class="bar"><div style="width:${(step+1)/c.steps.length*100}%"></div></div><small>STEP ${step+1} OF ${c.steps.length}</small><div class="step"><h3>${s[0]}</h3><p>${s[1]}</p></div><button class="round" onclick="toggleFavorite(${c.id})">${favorites.includes(c.id)?"♥":"♡"} Favorite</button><div class="actions"><button onclick="changeStep(-1)" ${step===0?"disabled":""}>Previous</button><button onclick="changeStep(1)">${step===c.steps.length-1?"Complete ✓":"Next →"}</button></div>`;
}
function changeStep(n){
 if(n===1&&step===selected.steps.length-1){
 if(!completed.includes(selected.id))completed.push(selected.id);
 localStorage.setItem("pcDone",JSON.stringify(completed));page("progress");return;
 }
 step=Math.max(0,Math.min(selected.steps.length-1,step+n));renderStep();
}
function toggleFavorite(id){
 favorites=favorites.includes(id)?favorites.filter(x=>x!==id):[...favorites,id];
 localStorage.setItem("pcFav",JSON.stringify(favorites));renderStep();
}
function favRender(){$("favGrid").innerHTML=crafts.filter(c=>favorites.includes(c.id)).map(card).join("")||"<p>No favorites saved yet.</p>"}
function progressRender(){
 $("count").textContent=completed.length;
 $("doneList").innerHTML=crafts.filter(c=>completed.includes(c.id)).map(c=>`<p>✓ ${c.name}</p>`).join("")||"<p>Start your first craft!</p>";
}
render();
