var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_http = require("http");
var import_ws = require("ws");
var import_path = __toESM(require("path"), 1);
var import_url = require("url");
var import_dotenv = __toESM(require("dotenv"), 1);
var import_genai = require("@google/genai");
var import_vite = require("vite");
var import_meta = {};
import_dotenv.default.config();
var __filename = (0, import_url.fileURLToPath)(import_meta.url);
var __dirname = import_path.default.dirname(__filename);
async function startServer() {
  const app = (0, import_express.default)();
  const server = (0, import_http.createServer)(app);
  const wss = new import_ws.WebSocketServer({ noServer: true });
  const PORT = 3e3;
  app.use(import_express.default.json({ limit: "10mb" }));
  function getGeminiClient() {
    const key = process.env.GEMINI_API_KEY;
    if (!key) return null;
    return new import_genai.GoogleGenAI({ apiKey: key });
  }
  app.get("/api/health", (_req, res) => {
    res.json({
      status: "ok",
      service: "Hinata AI Assistant Backend",
      hasApiKey: Boolean(process.env.GEMINI_API_KEY)
    });
  });
  app.post("/api/chat", async (req, res) => {
    try {
      const { message, audio } = req.body;
      const aiClient = getGeminiClient();
      if (!aiClient) {
        res.json({
          reply: "Hinata: GEMINI_API_KEY is not configured on the backend server. Please set GEMINI_API_KEY in environment settings."
        });
        return;
      }
      if (audio) {
        const response2 = await aiClient.models.generateContent({
          model: "gemini-2.5-flash",
          contents: [
            {
              role: "user",
              parts: [
                {
                  inlineData: {
                    mimeType: "audio/webm",
                    data: audio
                  }
                },
                { text: "Listen to this voice message. Respond concisely as Hinata, a warm and helpful AI Assistant." }
              ]
            }
          ]
        });
        res.json({ reply: response2.text || "I heard your voice message!" });
        return;
      }
      const response = await aiClient.models.generateContent({
        model: "gemini-2.5-flash",
        contents: [
          {
            role: "user",
            parts: [{ text: `You are Hinata, a helpful, warm, and highly capable AI Assistant. Respond concisely to: ${message || ""}` }]
          }
        ]
      });
      res.json({ reply: response.text || "I am listening!" });
    } catch (error) {
      console.error("[Hinata API] Chat error:", error);
      res.status(500).json({ error: error.message || "Failed to process chat message" });
    }
  });
  server.on("upgrade", (request, socket, head) => {
    try {
      const pathname = new URL(request.url || "", "http://localhost").pathname;
      if (pathname === "/ws/live") {
        wss.handleUpgrade(request, socket, head, (ws) => {
          wss.emit("connection", ws, request);
        });
      }
    } catch (e) {
      console.error("[Hinata Backend] Upgrade parse error:", e);
    }
  });
  wss.on("connection", (ws) => {
    console.log("[Hinata Backend] Client connected to /ws/live");
    ws.on("message", async (data) => {
      try {
        const payload = JSON.parse(data.toString());
        const aiClient = getGeminiClient();
        if (payload.type === "text") {
          if (!aiClient) {
            ws.send(JSON.stringify({
              type: "text",
              content: "Hinata: GEMINI_API_KEY is not set on the backend. Please add GEMINI_API_KEY in environment settings.",
              isUser: false
            }));
            return;
          }
          const response = await aiClient.models.generateContent({
            model: "gemini-2.5-flash",
            contents: [
              {
                role: "user",
                parts: [{ text: `You are Hinata, a helpful, warm, and highly capable AI Assistant. Respond concisely to: ${payload.content}` }]
              }
            ]
          });
          const textOutput = response.text || "I am listening!";
          ws.send(JSON.stringify({ type: "text", content: textOutput, isUser: false }));
        } else if (payload.type === "audio") {
          if (!aiClient) {
            ws.send(JSON.stringify({
              type: "text",
              content: "Hinata: GEMINI_API_KEY is not set on the backend.",
              isUser: false
            }));
            return;
          }
          const response = await aiClient.models.generateContent({
            model: "gemini-2.5-flash",
            contents: [
              {
                role: "user",
                parts: [
                  {
                    inlineData: {
                      mimeType: "audio/webm",
                      data: payload.data
                    }
                  },
                  { text: "Respond concisely as Hinata, a warm and helpful AI Assistant." }
                ]
              }
            ]
          });
          ws.send(JSON.stringify({ type: "text", content: response.text || "I heard your audio stream!", isUser: false }));
        }
      } catch (err) {
        console.error("[Hinata Backend] Error handling WS message:", err);
        ws.send(JSON.stringify({ type: "error", message: "Error processing request." }));
      }
    });
    ws.on("close", () => {
      console.log("[Hinata Backend] Client disconnected from /ws/live");
    });
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  server.listen(PORT, "0.0.0.0", () => {
    console.log(`[Hinata Backend] Server listening on http://0.0.0.0:${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
