/* Crypto Day Trading & AI Hub — Service Worker
 * Background OS push notifications + deep-link handling. */

self.addEventListener("install", (event) => {
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(self.clients.claim());
});

// Web Push payloads (when wired to a push provider / Capacitor bridge)
self.addEventListener("push", (event) => {
  let data = { title: "Crypto AI Hub", body: "עדכון מסחר חדש", tab: "active" };
  try {
    if (event.data) data = { ...data, ...event.data.json() };
  } catch (e) {
    /* non-JSON payload */
  }
  event.waitUntil(
    self.registration.showNotification(data.title, {
      body: data.body,
      icon: "/icon.svg",
      badge: "/icon.svg",
      vibrate: [120, 60, 120],
      data: { openTab: data.tab },
    })
  );
});

// Deep-link: clicking a lock-screen notification opens the relevant tab
self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const tab = (event.notification.data && event.notification.data.openTab) || "active";
  event.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((list) => {
      for (const client of list) {
        if ("focus" in client) {
          client.postMessage({ openTab: tab });
          return client.focus();
        }
      }
      if (self.clients.openWindow) return self.clients.openWindow("/#" + tab);
    })
  );
});
