// Task Earn Pro Service Worker - Version 2.4.0
const CACHE_VERSION = 'taskearn-v2.4.0';
const STATIC_CACHE = `${CACHE_VERSION}-static`;
const DYNAMIC_CACHE = `${CACHE_VERSION}-dynamic`;

// Core App Shell assets to precache
const APP_SHELL_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/favicon.ico',
  '/icon.svg',
  '/apple-touch-icon.png',
  '/pwa-192x192.png',
  '/pwa-512x512.png',
  '/pwa-maskable-512x512.png'
];

// Sensitive or dynamic paths that MUST NEVER be cached
const EXCLUDED_PATHS = [
  '/api/',
  '/oauth/',
  'token',
  'wallet',
  'withdraw',
  'payment',
  'auth',
  'login',
  'session'
];

// Install Event - Precache App Shell
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(STATIC_CACHE).then((cache) => {
      // Use catch so any non-critical resource failure doesn't block worker install
      return cache.addAll(APP_SHELL_ASSETS).catch((err) => {
        console.warn('[SW] Non-critical asset precache warning:', err);
      });
    }).then(() => self.skipWaiting())
  );
});

// Activate Event - Clean up stale caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== STATIC_CACHE && key !== DYNAMIC_CACHE) {
            return caches.delete(key);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

// Fetch Event - Safe routing & offline support
self.addEventListener('fetch', (event) => {
  const request = event.request;
  const url = new URL(request.url);

  // 1. Only process GET requests (Never touch POST, PUT, DELETE, PATCH)
  if (request.method !== 'GET') {
    return;
  }

  // 2. Strictly bypass chrome-extension, internal protocols, or cross-origin trackers
  if (!url.protocol.startsWith('http')) {
    return;
  }

  // 3. Strictly bypass API endpoints, payment requests, auth, and sensitive user data
  const isExcluded = EXCLUDED_PATHS.some((path) => 
    url.pathname.includes(path) || url.search.includes(path)
  );

  if (isExcluded) {
    // Pure network request, zero caching of private or financial data
    return;
  }

  // 4. For Navigation (HTML page loading): Network First, fallback to cached index.html
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((response) => {
          if (response && response.status === 200) {
            const responseClone = response.clone();
            caches.open(STATIC_CACHE).then((cache) => {
              cache.put(request, responseClone);
            });
          }
          return response;
        })
        .catch(async () => {
          const cachedResponse = await caches.match(request);
          if (cachedResponse) return cachedResponse;
          const fallbackShell = await caches.match('/index.html');
          if (fallbackShell) return fallbackShell;
          return new Response('Offline - Task Earn Pro is currently offline.', {
            status: 503,
            statusText: 'Service Unavailable',
            headers: new Headers({ 'Content-Type': 'text/plain' })
          });
        })
    );
    return;
  }

  // 5. For Static Assets (JS, CSS, Images, Fonts, Icons): Stale-While-Revalidate
  const isStaticAsset = 
    url.origin === self.location.origin ||
    url.hostname.includes('fonts.googleapis.com') ||
    url.hostname.includes('fonts.gstatic.com') ||
    url.hostname.includes('images.unsplash.com');

  if (isStaticAsset) {
    event.respondWith(
      caches.match(request).then((cachedResponse) => {
        const fetchPromise = fetch(request)
          .then((networkResponse) => {
            if (networkResponse && networkResponse.status === 200 && networkResponse.type === 'basic') {
              const responseClone = networkResponse.clone();
              caches.open(DYNAMIC_CACHE).then((cache) => {
                cache.put(request, responseClone);
              });
            }
            return networkResponse;
          })
          .catch(() => cachedResponse);

        return cachedResponse || fetchPromise;
      })
    );
    return;
  }

  // 6. Default: Network fallback to cache
  event.respondWith(
    fetch(request).catch(() => caches.match(request))
  );
});
