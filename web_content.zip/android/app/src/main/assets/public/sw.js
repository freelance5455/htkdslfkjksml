// Service worker (version navigateur/PWA uniquement) : fonctionnement hors-ligne.
// Changez CACHE à chaque mise à jour des fichiers pour forcer le rafraîchissement.
const CACHE = 'inventaire-biomedicale-v1';
const FILES = ['./', 'index.html', 'css/app.css', 'xlsx.mini.min.js', 'manifest.webmanifest', 'icons/icon-192.png', 'icons/icon-512.png',
  'js/app.js', 'js/app-core.js', 'js/util.js', 'js/i18n.js', 'js/lang-fr.js', 'js/lang-en.js', 'js/store.js', 'js/schema.js', 'js/logic.js', 'js/form.js', 'js/nav.js',
  'js/view-dashboard.js', 'js/view-inventory.js', 'js/view-maintenance.js', 'js/view-settings.js', 'js/io.js', 'js/notify.js', 'js/scanner.js', 'js/lock.js', 'js/demo.js'];
self.addEventListener('install', (e) => { e.waitUntil(caches.open(CACHE).then((c) => c.addAll(FILES)).then(() => self.skipWaiting())); });
self.addEventListener('activate', (e) => { e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', (e) => { if (e.request.method !== 'GET') return; e.respondWith(caches.match(e.request).then((r) => r || fetch(e.request))); });
