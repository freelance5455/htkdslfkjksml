// Guarda em cache o runtime do modelo offline (jsDelivr) para funcionar sem internet depois do 1º download.
const RT='megaia-runtime-v1';
self.addEventListener('install',()=>self.skipWaiting());
self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));
self.addEventListener('fetch',e=>{
 const u=new URL(e.request.url);
 if(e.request.method!=='GET'||u.hostname!=='cdn.jsdelivr.net')return;
 e.respondWith(caches.open(RT).then(async c=>{const hit=await c.match(e.request);if(hit)return hit;const r=await fetch(e.request);if(r.ok)c.put(e.request,r.clone());return r}));
});
