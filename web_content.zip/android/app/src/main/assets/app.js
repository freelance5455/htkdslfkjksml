
const $=id=>document.getElementById(id);
let mode='chat', network='online', attachments=[], recorder=null, chunks=[], localPipe=null, localBusy=false;
let firebaseApp=null, firebaseAuth=null, firestore=null, currentUser=null, firebaseFns=null;
const titles={chat:['MegaIA','Sua assistente inteligente'],image:['Criar e editar imagens','Crie do zero ou altere uma foto sua'],video:['Analisar vídeos','Envie vídeos para análise'],files:['Arquivos e documentos','Trabalhe com seus arquivos'],audio:['Áudio e voz','Grave ou envie áudio'],camera:['Câmera','Capture uma foto'],game:['Criar jogos','Descreva o jogo e jogue na hora'],makevideo:['Criar vídeos','Gere vídeos de 8 segundos']};
const MAX_WORDS=10000, MAX_IMAGES=50, MAX_VIDEOS=50, MAX_OTHER=20;
function toast(t){$('toast').textContent=t;$('toast').classList.add('show');setTimeout(()=>$('toast').classList.remove('show'),3200)}
function status(t){$('status').textContent='● '+t}
function normalizeApi(u){u=String(u||'').trim();if(!u)return '';if(!/^https?:\/\//i.test(u))u='https://'+u;u=u.replace(/[?#].*$/,'').replace(/\/+$/,'').replace(/\/api(\/(chat|health|generate-image))?$/i,'');return u}
function apiBase(){return normalizeApi(localStorage.getItem('megaia_api'))}
async function testServer(base){const ctl=new AbortController();const t=setTimeout(()=>ctl.abort(),4000);try{const r=await fetch(base+'/api/health',{cache:'no-store',signal:ctl.signal});if(r.status===404)return {ok:false,msg:'Esse endereço não tem o backend MegaIA (404). Use só o endereço base, sem /api.'};if(r.status>=500)return {ok:false,msg:'O servidor está com erro ('+r.status+'). Pode estar reiniciando ou dormindo; tente em instantes.'};if(!r.ok)return {ok:false,msg:'O servidor respondeu '+r.status+'.'};const d=await r.json().catch(()=>null);if(!d||d.service!=='MegaIA')return {ok:false,msg:'Esse endereço responde, mas não é o backend MegaIA.'};return {ok:true,msg:d.onlineAIConfigured?'Servidor conectado.':'Servidor conectado, sem chave Gemini própria: cole a chave em Configurações.'}}catch(e){return {ok:false,msg:ctl.signal.aborted?'O servidor não respondeu em 4 s: desligado, dormindo ou sem internet.':'Servidor inacessível: desligado, endereço errado, sem internet ou CORS bloqueando o app.'}}finally{clearTimeout(t)}}
function geminiKey(){return (localStorage.getItem('megaia_gemini_key')||sessionStorage.getItem('megaia_gemini_key')||'').trim()}
function openGeminiStudio(){if(window.MegaAds&&typeof window.MegaAds.openGeminiStudio==='function'){window.MegaAds.openGeminiStudio()}else{window.open('https://aistudio.google.com/app/apikey','_blank','noopener')}}
function setMode(m){mode=m;document.querySelectorAll('.nav[data-mode]').forEach(b=>b.classList.toggle('active',b.dataset.mode===m));$('headTitle').textContent=titles[m][0];$('headSub').textContent=titles[m][1];$('prompt').placeholder=m==='game'?'Descreva o jogo (ex.: corrida infinita com obstáculos e placar)...':m==='makevideo'?'Descreva o vídeo de 8 segundos que quer criar...':m==='image'?'Descreva a imagem a criar — ou anexe uma foto e diga o que mudar...':m==='video'?'Faça uma pergunta sobre os vídeos anexados...':'Pergunte qualquer coisa à MegaIA... (até 10.000 palavras)';if(m==='camera')$('cameraInput').click();if(m==='files')$('fileInput').click();if(m==='audio')startAudio();$('sidebar').classList.remove('open')}
document.querySelectorAll('.nav[data-mode]').forEach(b=>b.onclick=()=>setMode(b.dataset.mode));
document.querySelectorAll('.mode').forEach(b=>b.onclick=()=>{network=b.dataset.network;document.querySelectorAll('.mode').forEach(x=>x.classList.toggle('selected',x===b));$('modeInfo').textContent=network==='online'?'Usa o Gemini (sua chave) ou o servidor configurado.':'Usa o modelo local neste dispositivo.';refreshStatus()});
$('hamb').onclick=()=>{$('sidebar').classList.toggle('open')};
// Fechar o menu lateral ao tocar na área principal em celulares.
$('content').addEventListener('click',()=>{$('sidebar').classList.remove('open')});
document.addEventListener('keydown',e=>{if(e.key==='Escape'){ $('settings').classList.add('hidden'); $('attachMenu').classList.add('hidden'); $('sidebar').classList.remove('open'); }});
$('settings').addEventListener('click',e=>{if(e.target===$('settings'))$('settings').classList.add('hidden')});
$('attachMenu').addEventListener('click',e=>{if(e.target===$('attachMenu'))$('attachMenu').classList.add('hidden')});
$('settingsBtn').onclick=()=>{$('apiUrl').value=apiBase();$('geminiKey').value=geminiKey();$('fastModel').value=cfg('megaia_fast_model','gemini-3.5-flash-lite');$('geminiModel').value=cfg('megaia_gemini_model','gemini-3.8-flash');$('imageModel').value=cfg('megaia_image_model','gemini-3.1-flash-image');$('offlineModel').value=cfg('megaia_model','onnx-community/SmolLM2-135M-Instruct-ONNX');$('firebaseConfig').value=localStorage.getItem('megaia_firebase')||'';showQuota();$('autoRead').checked=localStorage.getItem('megaia_autoread')==='1';$('offlineInfo').textContent=localStorage.getItem('megaia_offline_ready2')?'Modelo offline já baixado.':'Modelo offline ainda não baixado.';$('settings').classList.remove('hidden')};
$('openGeminiStudio').onclick=openGeminiStudio;
$('dlOffline').onclick=async()=>{if(!navigator.onLine){toast('Conecte à internet para baixar o modelo.');return}toast('Baixando o modelo offline... mantenha o app aberto.');try{await ensureOffline();$('offlineInfo').textContent='Modelo offline pronto. Agora funciona sem internet.';toast('Modelo offline pronto!')}catch(e){$('offlineInfo').textContent=e.message;toast(e.message)}};
$('closeSettings').onclick=()=>$('settings').classList.add('hidden');
$('saveSettings').onclick=async()=>{const api=normalizeApi($('apiUrl').value);const key=$('geminiKey').value.trim();localStorage.setItem('megaia_api',api);$('apiUrl').value=api;if(key)localStorage.setItem('megaia_gemini_key',key);else localStorage.removeItem('megaia_gemini_key');sessionStorage.removeItem('megaia_gemini_key');localStorage.setItem('megaia_fast_model',$('fastModel').value.trim()||'gemini-3.5-flash-lite');localStorage.setItem('megaia_gemini_model',$('geminiModel').value.trim()||'gemini-3.8-flash');localStorage.setItem('megaia_image_model',$('imageModel').value.trim()||'gemini-3.1-flash-image');localStorage.setItem('megaia_model',$('offlineModel').value.trim());localStorage.setItem('megaia_firebase',$('firebaseConfig').value.trim());localStorage.setItem('megaia_autoread',$('autoRead').checked?'1':'0');srvState={ok:null,msg:'',at:0};$('settings').classList.add('hidden');toast('Configurações salvas.');if(api&&window.MegaAuth&&!MegaAuth.session())MegaAuth.exchange(api);await refreshStatus()};
$('attachBtn').onclick=()=>$('attachMenu').classList.remove('hidden');
$('closeAttach').onclick=()=>$('attachMenu').classList.add('hidden');
$('chooseFiles').onclick=()=>{$('attachMenu').classList.add('hidden');$('fileInput').click()};
$('takePhoto').onclick=()=>{$('attachMenu').classList.add('hidden');$('cameraInput').click()};
$('recordAudio').onclick=()=>{$('attachMenu').classList.add('hidden');startAudio()};
$('fileInput').onchange=e=>addFiles([...e.target.files]);
$('cameraInput').onchange=e=>addFiles([...e.target.files]);
function addFiles(fs){let imgs=attachments.filter(f=>f.type.startsWith('image/')).length, vids=attachments.filter(f=>f.type.startsWith('video/')).length, other=attachments.filter(f=>!f.type.startsWith('image/')&&!f.type.startsWith('video/')).length;
 for(const f of fs){if(f.type.startsWith('image/')&&imgs>=MAX_IMAGES){toast('Limite de 50 fotos por envio atingido');continue}if(f.type.startsWith('video/')&&vids>=MAX_VIDEOS){toast('Limite de 50 vídeos por envio atingido');continue}if(!f.type.startsWith('image/')&&!f.type.startsWith('video/')&&other>=MAX_OTHER){toast('Limite de 20 outros arquivos por envio');continue}attachments.push(f);if(f.type.startsWith('image/'))imgs++;else if(f.type.startsWith('video/'))vids++;else other++}
 renderAttachments();$('fileInput').value='';$('cameraInput').value=''}
function renderAttachments(){$('attachmentBar').innerHTML='';attachments.forEach((f,i)=>{let c=document.createElement('span');c.className='chip';c.textContent=(f.type.startsWith('image/')?'📷 ':f.type.startsWith('video/')?'🎬 ':f.type.startsWith('audio/')?'🎙 ':'📄 ')+f.name+' ×';c.onclick=()=>{attachments.splice(i,1);renderAttachments()};$('attachmentBar').append(c)})}
function wordCount(s){return s.trim()?s.trim().split(/\s+/).length:0}
$('prompt').oninput=()=>{$('wordCount').textContent=wordCount($('prompt').value).toLocaleString('pt-BR')+' / 10.000 palavras';$('prompt').style.height='auto';$('prompt').style.height=Math.min($('prompt').scrollHeight,170)+'px'};
document.querySelectorAll('.quick button').forEach(b=>b.onclick=()=>{if(b.dataset.setmode)setMode(b.dataset.setmode);$('prompt').value=b.dataset.prompt;$('prompt').dispatchEvent(new Event('input'));$('prompt').focus()});
$('newChat').onclick=()=>{if(busy){toast('Aguarde a resposta ou toque em ■ para parar.');return}resetChatUI();$('sidebar').classList.remove('open');renderConvList()};
function addMessage(text,who,files=[],pending=false){
 $('content').querySelector('.welcome').style.display='none';
 const m=document.createElement('div');m.className='msg '+who;
 const col=document.createElement('div');col.className='col';
 const b=document.createElement('div');b.className='bubble';b._raw=text;
 if(who==='assistant')b.innerHTML=md(text);else b.textContent=text;
 if(files.length){const f=document.createElement('div');f.className='files';f.textContent='Anexos: '+files.map(x=>x.name).join(', ');b.append(f)}
 const bar=document.createElement('div');bar.className='msgbar';bar.hidden=pending;
 const mk=(label,fn)=>{const x=document.createElement('button');x.type='button';x.textContent=label;x.onclick=fn;bar.append(x);return x};
 mk('⧉ Copiar',()=>copyText(b._raw));
 if(who==='assistant'){const rb=mk('🔊 Ler',()=>{if(speakBtn===rb)stopSpeak();else speak(b._raw,rb)});b._readBtn=rb;const eb=mk('✎ Editar',()=>toggleEdit(b,eb))}
 else mk('✎ Editar',()=>{$('prompt').value=b._raw;$('prompt').dispatchEvent(new Event('input'));$('prompt').focus();toast('Edite o texto e envie de novo')});
 b._bar=bar;col.append(b,bar);m.append(col);$('messages').append(m);$('content').scrollTop=$('content').scrollHeight;return b}

/* ===== Texto formatado (markdown simples + fórmulas) ===== */
function escHtml(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
function texToText(x){const sup={'0':'⁰','1':'¹','2':'²','3':'³','4':'⁴','5':'⁵','6':'⁶','7':'⁷','8':'⁸','9':'⁹'};
 for(let i=0;i<3;i++)x=x.replace(/\\sqrt\{([^{}]*)\}/g,'√($1)').replace(/\\frac\{([^{}]*)\}\{([^{}]*)\}/g,'($1)/($2)').replace(/\\text\{([^{}]*)\}/g,'$1');
 x=x.replace(/\\approx/g,'≈').replace(/\\times/g,'×').replace(/\\cdot/g,'·').replace(/\\div/g,'÷').replace(/\\pm/g,'±').replace(/\\leq?/g,'≤').replace(/\\geq?/g,'≥').replace(/\\neq/g,'≠').replace(/\\pi/g,'π').replace(/\\infty/g,'∞').replace(/\\(left|right)/g,'').replace(/\\[,;! ]/g,' ');
 x=x.replace(/\^\{?(\d)\}?/g,(m,d)=>sup[d]).replace(/\^\{([^{}]*)\}/g,'^($1)');
 return x.replace(/\\([a-zA-Z]+)/g,'$1').trim()}
function md(src){
 const blocks=[];let s=String(src).replace(/```[a-zA-Z]*\n?([\s\S]*?)(```|$)/g,(m,c)=>{blocks.push(c.replace(/\n$/,''));return '\u0000B'+(blocks.length-1)+'\u0000'});
 s=s.replace(/\$\$?([^$\n]*\\[^$\n]*)\$\$?/g,(m,x)=>texToText(x));
 s=escHtml(s);
 s=s.replace(/^\s{0,3}#{1,6}\s+(.+)$/gm,'<b>$1</b>').replace(/^(\s*)[*-]\s+/gm,'$1• ');
 s=s.replace(/`([^`\n]+)`/g,'<code>$1</code>').replace(/\*\*([^*\n]+)\*\*/g,'<b>$1</b>').replace(/(^|[^*\w])\*([^*\n]+)\*(?![*\w])/g,'$1<i>$2</i>');
 return s.replace(/\u0000B(\d+)\u0000/g,(m,i)=>'<pre><code>'+escHtml(blocks[i])+'</code></pre>')}
function setReply(el,t){el.innerHTML=md(t)}
function detectIntent(t){const x=String(t||'').toLowerCase().trim();
 const verb='(?:fa[çc]a|faz|fazer|fa[çc]o|me d[áa]|d[êe]-me|crie|criar|cria|gere|gerar|gera|desenh\\w+|monte|montar|quero|preciso de|pode (?:fazer|criar|gerar)|consegue (?:fazer|criar|gerar)|me (?:mostr[ae]|manda)|mostre|produz\\w*|elabor\\w+)';
 const nouns={makevideo:'(?:v[ií]deos?|anima[çc][ãa]o|animac[õo]es|clipes?)',game:'(?:jogos?|games?)',image:'(?:imagem|imagens|fotos?|desenhos?|ilustra[çc][õo]es|ilustra[çc][ãa]o|wallpapers?|logos?|logotipos?|artes?|figuras?|pinturas?|retratos?)'};
 let best=null,bestEnd=1e9;
 for(const k of ['makevideo','game','image']){const m=new RegExp(verb+'[^.!?\\n]{0,40}?'+nouns[k]+'\\b').exec(x);if(m&&m.index+m[0].length<bestEnd){best=k;bestEnd=m.index+m[0].length}}
 if(best)return best;
 if(x.split(/\s+/).length<=12)for(const k of ['makevideo','game','image']){if(new RegExp('^(?:(?:um|uma|o|a|outro|outra)\\s+)?'+nouns[k]+'\\b').test(x))return k}
 return null}
function confirmIntent(t){const x=String(t||'').toLowerCase().trim();return x.split(/\s+/).length<=5&&/^(faz|faça|fa[çc]a|fazer|pode|manda|vai|cria|crie|gera|gere|isso|sim|ok|bora|agora|continua|tenta|de novo|outra vez|novamente)\b/.test(x)}
let lastCreate=null,lastImagePrompt='';
function detectEdit(t){return /\b(edit|alter|mud|tro[cq]|remov|tir|apag|adicion|colo[cq]|color|pint|deix|transform|melhor|reto[cq]|recort|aument|diminu|clare|escure|substitu|apliqu|ponh|inclu|ajust|corrij)\w*/i.test(t||'')}
function attachGenerated(b){
 const imgs=[...b.querySelectorAll('img.result-image')].filter(i=>/^data:image\//.test(i.src));
 if(!imgs.length||!b._bar||b._bar.querySelector('[data-edit]'))return;
 const x=document.createElement('button');x.type='button';x.textContent='🖌 Editar imagem';x.dataset.edit='1';
 x.onclick=async()=>{try{const src=imgs[imgs.length-1].src,bl=await (await fetch(src)).blob();const ext=(bl.type.split('/')[1]||'png').replace('jpeg','jpg');
  attachments.push(new File([bl],'imagem-para-editar.'+ext,{type:bl.type||'image/png'}));renderAttachments();setMode('image');$('prompt').placeholder='Diga o que mudar na imagem (ex.: troque o fundo por uma praia)...';$('prompt').focus();toast('Imagem anexada. Descreva a mudança e envie.')}catch(_){toast('Não consegui anexar a imagem.')}};
 b._bar.append(x)}
let curMode='chat';

/* ===== Histórico local, voz, copiar, editar, modo offline ===== */
function legacyLog(){try{const a=JSON.parse(localStorage.getItem('megaia_log')||'[]');return Array.isArray(a)?a:[]}catch(_){return []}}
let speakBtn=null;
function cleanForSpeech(t){return String(t).replace(/```[\s\S]*?(```|$)/g,' trecho de código omitido. ').replace(/\[([^\]]+)\]\([^)]+\)/g,'$1').replace(/https?:\/\/\S+/g,' link ').replace(/[*_#>`~|]/g,'').replace(/[ \t]+\n/g,'\n').trim()}
function stopSpeak(){ttsThen=null;try{if(window.MegaTTS)MegaTTS.stop();else if(window.speechSynthesis)speechSynthesis.cancel()}catch(_){}if(speakBtn){speakBtn.textContent='🔊 Ler';speakBtn=null}}
window.onTtsDone=()=>{if(speakBtn){speakBtn.textContent='🔊 Ler';speakBtn=null}if(ttsThen){const f=ttsThen;ttsThen=null;setTimeout(f,350)}};
function speak(text,btn){stopSpeak();const t=cleanForSpeech(text);if(!t){toast('Nada para ler');return}
 speakBtn=btn||null;if(btn)btn.textContent='⏹ Parar';
 try{if(window.MegaTTS)MegaTTS.speak(t);else if(window.speechSynthesis){const u=new SpeechSynthesisUtterance(t);u.lang='pt-BR';u.onend=u.onerror=()=>window.onTtsDone();speechSynthesis.speak(u)}else{toast('Este aparelho não tem leitura em voz alta.');window.onTtsDone()}}
 catch(e){toast('Não consegui ler em voz alta.');window.onTtsDone()}}
async function copyText(t){try{await navigator.clipboard.writeText(t);toast('Copiado');return}catch(_){}
 try{const a=document.createElement('textarea');a.value=t;a.style.cssText='position:fixed;opacity:0';document.body.append(a);a.select();document.execCommand('copy');a.remove();toast('Copiado')}catch(_){toast('Não consegui copiar')}}
function toggleEdit(b,btn){
 if(!b._editing){if(b.querySelector('img,iframe,video')){toast('Só dá para editar respostas de texto.');return}
  b._editing=true;b.textContent=b._raw;b.contentEditable='true';b.classList.add('editing');b.focus();btn.textContent='✔ Salvar';return}
 const v=b.innerText.trim();b._editing=false;b.contentEditable='false';b.classList.remove('editing');b._raw=v;b.innerHTML=md(v);btn.textContent='✎ Editar';
 if(b._msg){b._msg.text=v;saveMsg(b._msg)}toast('Resposta editada')}
function finishMsg(b,raw){b._raw=raw;if(b._bar)b._bar.hidden=false}
function offlineBasic(t){
 const x=t.trim().toLowerCase().replace(/[?!.]+$/,'');
 if(/(que horas|hora atual|horas s[ãa]o)/.test(x))return 'Agora são '+new Date().toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})+'.';
 if(/(que dia|data de hoje|dia [ée] hoje|qual a data)/.test(x))return 'Hoje é '+new Date().toLocaleDateString('pt-BR',{weekday:'long',day:'numeric',month:'long',year:'numeric'})+'.';
 const e=x.replace(/^(quanto [ée]|calcule|calcula|resultado de|qual [ée] o resultado de|qual [ée])\s+/,'');
 let m=e.match(/^(?:a )?raiz quadrada d[eo] ([\d.,]+)$/);
 if(m){const n=parseFloat(m[1].replace(',','.'));if(n>=0)return 'A raiz quadrada de '+m[1]+' é **'+Number(Math.sqrt(n).toFixed(6)).toLocaleString('pt-BR')+'**.'}
 if(/^[\d\s+\-*/().,^%x×÷]+$/.test(e)&&/\d/.test(e)&&/[+\-*/^%x×÷]/.test(e)){
  const ex=e.replace(/[x×]/g,'*').replace(/÷/g,'/').replace(/\^/g,'**').replace(/(\d),(\d)/g,'$1.$2').replace(/(\d+(?:\.\d+)?)%/g,'($1/100)');
  try{const v=Function('"use strict";return ('+ex+')')();if(typeof v==='number'&&Number.isFinite(v))return 'O resultado é **'+Number(v.toFixed(10)).toLocaleString('pt-BR',{maximumFractionDigits:10})+'**.'}catch(_){}}
 return null}
/* ===== Utilidades, limite por hora e erros ===== */
const LIMITS={image:50,video:50}; // por hora (mude aqui)
const QUOTA_WINDOW=60*60*1000; // a contagem reinicia 1 hora depois do primeiro uso
const GURL='https://generativelanguage.googleapis.com/v1beta/';
const cfg=(k,d)=>localStorage.getItem(k)||d;
const sleep=(ms,signal)=>new Promise((res,rej)=>{const t=setTimeout(res,ms);if(signal)signal.addEventListener('abort',()=>{clearTimeout(t);rej(mkErr('Cancelado.',{fatal:true,cancelled:signal.reason==='user'}))},{once:true})});
function mkErr(msg,flags){return Object.assign(new Error(msg),flags||{})}
function dayKey(){const d=new Date();return d.getFullYear()+'-'+(d.getMonth()+1)+'-'+d.getDate()}
function getQuota(){let q={};try{q=JSON.parse(localStorage.getItem('megaia_quota')||'{}')}catch(_){}const now=Date.now();if(!q||typeof q.start!=='number'||q.start>now||now-q.start>=QUOTA_WINDOW)q={start:0,image:0,video:0};return q}
function minsLeft(q){return q.start?Math.max(1,Math.ceil((q.start+QUOTA_WINDOW-Date.now())/60000)):60}
function checkQuota(k){const q=getQuota();if((q[k]||0)>=LIMITS[k])throw mkErr('Você atingiu o limite de '+LIMITS[k]+' '+(k==='image'?'imagens':'vídeos')+' por hora. O contador reinicia em cerca de '+minsLeft(q)+' min.',{fatal:true})}
function useQuota(k,n){const q=getQuota();if(!q.start)q.start=Date.now();q[k]=(q[k]||0)+n;try{localStorage.setItem('megaia_quota',JSON.stringify(q))}catch(_){}showQuota()}
function showQuota(){const q=getQuota(),el=$('quotaInfo');if(el)el.textContent='Nesta hora: '+(q.image||0)+'/'+LIMITS.image+' imagens e '+(q.video||0)+'/'+LIMITS.video+' vídeos criados.'+(q.start?' Reinicia em '+minsLeft(q)+' min.':'')}
setInterval(showQuota,60000);
function linkSignal(ctl,outer){if(!outer)return;if(outer.aborted)ctl.abort(outer.reason);else outer.addEventListener('abort',()=>ctl.abort(outer.reason),{once:true})}
function netError(e,ctl,ms,who){who=who||'Gemini';if(ctl.signal.aborted){if(ctl.signal.reason==='user')return mkErr('Cancelado.',{fatal:true,cancelled:true});return mkErr(who==='servidor'?'O servidor não respondeu a tempo ('+Math.round(ms/1000)+' s).':'O Gemini não respondeu a tempo ('+Math.round(ms/1000)+' s).',{retry:true,timeout:true})}
 if(!navigator.onLine)return mkErr('Sem internet. Conecte-se ao Wi-Fi ou 4G.',{fatal:true});
 return mkErr(who==='servidor'?'Falha na comunicação com o servidor. Pode estar desligado, ou o CORS_ORIGIN dele bloqueia o app.':'Não consegui falar com o Google. Verifique a internet.',{retry:true})}
function retrySecs(d){try{const det=(d.error.details||[]).find(x=>/RetryInfo/.test(x['@type']||''));if(det&&det.retryDelay)return Math.ceil(parseFloat(det.retryDelay))}catch(_){}return 0}
function httpError(status,d,model){const m=(d&&d.error&&d.error.message)||'';
 if(status===429){const raw=JSON.stringify(d||{}),sec=retrySecs(d);
  if(/limit: 0/.test(m)||/"limit":\s*0\b/.test(raw))return mkErr('Sua chave gratuita não tem cota para o modelo "'+model+'" (limite 0). Imagens e vídeos normalmente exigem ativar o faturamento no Google AI Studio. Para texto, troque o modelo em Configurações.',{retry:true,status:429,noQuota:true});
  if(/PerDay/i.test(raw))return mkErr('Você usou toda a cota diária grátis do modelo "'+model+'". Ela renova em cerca de 1 dia, ou ative o faturamento no Google AI Studio.',{retry:true,status:429,daily:true});
  return mkErr('Limite por minuto da chave atingido'+(sec?'. Tente de novo em '+sec+' s.':'. Aguarde alguns segundos.'),{retry:true,status:429})}
 if(status===400&&/thinking/i.test(m))return mkErr(m,{thinking:true,retry:true});
 if(status===400&&/google_search|grounding|search|tool/i.test(m)&&!/API key/i.test(m))return mkErr(m,{tool:true,retry:true});
 if(status===400&&/API key|API_KEY/i.test(m))return mkErr('Chave Gemini inválida. Confira a chave em Configurações.',{fatal:true});
 if(status===401||status===403)return mkErr('A chave Gemini não tem permissão: '+m,{fatal:true});
 if(status===404)return mkErr('Modelo "'+model+'" não encontrado para sua chave. Troque o nome em Configurações.',{retry:true});
 if(status===429)return mkErr('Limite de uso da chave atingido (429). Aguarde um pouco.',{retry:true});
 if(status>=500)return mkErr('O Gemini está com alta demanda ou instável ('+status+'). Tente de novo em instantes.',{retry:true,status});
 return mkErr(m||('Erro do Gemini ('+status+').'),{fatal:true})}
function webMode(){return localStorage.getItem('megaia_web')||'auto'}
function needsWeb(t){return /\b(not[ií]cias?|hoje|atual(mente)?|[uú]ltim[oa]s?|recente(s|mente)?|esta semana|este m[eê]s|ontem|amanh[ãa]|cota[çc][ãa]o|d[óo]lar|euro|bitcoin|pre[çc]o d[eoa]s?|placar|resultado d[eoa]s?|tabela d[eoa]|clima|previs[ãa]o do tempo|temperatura|quem [ée] o (atual|presidente|prefeito|governador)|lan[çc]amento|2025|2026|pesquis[ae]|busque|procure na (web|internet))\b/i.test(t||'')}
function gHeaders(){return {'Content-Type':'application/json','x-goog-api-key':geminiKey()}}
function fileToB64(f){return new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(String(r.result).split(',')[1]);r.onerror=()=>rej(new Error('Não consegui ler '+f.name));r.readAsDataURL(f)})}

/* ===== Prompts ===== */
const CHAT_PROMPT='Você é a MegaIA, uma assistente inteligente. Responda em português do Brasil, de forma clara, direta e útil. Seja objetiva: vá direto ao ponto. Você roda dentro de um app que também cria imagens, jogos e vídeos de 8 segundos (menu ☰ > Criar vídeos): nunca diga que não consegue criar vídeos; se pedirem um vídeo, peça que descrevam a cena e informe que o app a cria.';
function chatPrompt(){return CHAT_PROMPT+' Hoje é '+new Date().toLocaleDateString('pt-BR',{weekday:'long',day:'numeric',month:'long',year:'numeric'})+'.'+(voiceMode?' A resposta será lida em voz alta: responda em no máximo 3 frases curtas, em texto corrido, sem listas, sem símbolos e sem formatação.':'')}
const GAME_PROMPT='Você é o MegaIA Game Studio. Crie UM jogo completo e jogável em um único arquivo HTML, com HTML, CSS e JavaScript inline, sem bibliotecas, sem imagens ou fontes externas e sem acesso à rede. Use canvas ou DOM com visual caprichado e cores vibrantes. O jogo precisa funcionar no celular (controles de toque na tela, arrastar ou botões grandes) e também com teclado, ocupar toda a área do iframe de forma responsiva, ter placar, game over e botão de reiniciar. Não use localStorage, sessionStorage, cookies, alert, confirm, prompt nem window.open (o jogo roda isolado dentro de um iframe): guarde o recorde só em variáveis. Se o pedido for para alterar um jogo anterior, devolva o arquivo completo já alterado. Responda com no máximo duas frases em português e em seguida o código completo dentro de UM único bloco ```html.';

/* ===== Gemini direto (streaming) ===== */
const gHistory=[];
const HIST_MAX=40;
function trimHistory(){while(gHistory.length>HIST_MAX)gHistory.splice(0,2);
 for(let i=0;i<gHistory.length-6;i++){const p=gHistory[i].parts[0];if(p&&p.text&&p.text.length>6000&&!/```/.test(p.text))p.text=p.text.slice(0,6000)+' [...]'}let seen=false;for(let i=gHistory.length-1;i>=0;i--){const g=gHistory[i];if(g.role==='model'&&/```/.test(g.parts[0].text)){if(seen)g.parts[0].text='[jogo anterior omitido]';seen=true}}}
async function buildParts(text,files){
 const parts=[];let total=0;
 for(const f0 of files){
  if(window.MegaOffice&&MegaOffice.isOffice(f0)){status('Lendo '+f0.name+'...');const r=await MegaOffice.extract(f0);parts.push({text:r.text});if(r.cut)toast('Arquivo grande: só o começo foi enviado.');continue}
  if(window.MegaOffice&&MegaOffice.isLegacy(f0))throw mkErr('"'+f0.name+'" está num formato antigo. Abra no Word, Excel ou PowerPoint e salve como .docx, .xlsx ou .pptx.',{fatal:true});
  const f=await shrinkImage(f0);const t=mt(f).split(';')[0];
  if(t.startsWith('text/')||/\.(txt|csv|json|md|xml)$/i.test(f.name)){parts.push({text:'[Conteúdo do arquivo '+f.name+']\n'+(await f.text()).slice(0,150000)});continue}
  if(!(t.startsWith('image/')||t.startsWith('video/')||t.startsWith('audio/')||t==='application/pdf'))throw mkErr('Formato não suportado: '+f.name+'. Envie imagem, vídeo, áudio, PDF, Word, Excel, PowerPoint ou TXT/CSV/JSON/MD.',{fatal:true});
  total+=f.size;if(total>14*1024*1024)throw mkErr('Anexos grandes demais para envio direto (máx. cerca de 14 MB no total). Use arquivos menores ou um servidor MegaIA.',{fatal:true});
  parts.push({inlineData:{mimeType:t,data:await fileToB64(f)}});
 }
 parts.push({text:text||'Analise os anexos enviados e explique os principais pontos.'});
 return parts}
async function geminiStream(model,body,o){
 const ctl=new AbortController();linkSignal(ctl,o.signal);let cur=o.firstMs;
 let timer=setTimeout(()=>ctl.abort('timeout'),cur);
 const bump=ms=>{cur=ms;clearTimeout(timer);timer=setTimeout(()=>ctl.abort('timeout'),ms)};
 try{
  let r;try{r=await fetch(GURL+'models/'+encodeURIComponent(model)+':streamGenerateContent?alt=sse',{method:'POST',signal:ctl.signal,headers:gHeaders(),body:JSON.stringify(body)})}catch(e){throw netError(e,ctl,cur)}
  if(!r.ok){const d=await r.json().catch(()=>({}));throw httpError(r.status,d,model)}
  const reader=r.body.getReader(),dec=new TextDecoder();let buf='',text='',images=[],block=null;const sources=[];
  bump(o.idleMs||20000);
  while(true){
   let ch;try{ch=await reader.read()}catch(e){throw netError(e,ctl,cur)}
   if(ch.done)break;bump(o.idleMs||20000);
   buf+=dec.decode(ch.value,{stream:true});
   let i;while((i=buf.search(/\r?\n\r?\n/))>=0){
    const ev=buf.slice(0,i);buf=buf.slice(i).replace(/^\r?\n\r?\n/,'');
    const line=ev.split(/\r?\n/).filter(l=>l.startsWith('data:')).map(l=>l.slice(5).trim()).join('');if(!line)continue;
    let j;try{j=JSON.parse(line)}catch(_){continue}
    if(j.error)throw httpError(j.error.code||500,j,model);
    if(j.promptFeedback&&j.promptFeedback.blockReason)block=j.promptFeedback.blockReason;
    const gm=j.candidates&&j.candidates[0]&&j.candidates[0].groundingMetadata;
    if(gm&&gm.groundingChunks)gm.groundingChunks.forEach(c=>{if(c.web&&c.web.uri&&!sources.some(x=>x.uri===c.web.uri))sources.push({uri:c.web.uri,title:c.web.title||c.web.uri})});
    const ps=(j.candidates&&j.candidates[0]&&j.candidates[0].content&&j.candidates[0].content.parts)||[];
    for(const p of ps){if(p.text&&!p.thought){text+=p.text;if(o.onText)o.onText(text)}if(p.inlineData)images.push({mimeType:p.inlineData.mimeType,data:p.inlineData.data})}
   }
  }
  if(!text&&!images.length)throw mkErr(block?'Pedido bloqueado pelo Gemini ('+block+').':'O Gemini não retornou resposta.',{fatal:!!block,retry:!block});
  return {text:text.trim(),images,sources}
 }finally{clearTimeout(timer)}
}
async function geminiChat(text,files,signal,onText){
 const parts=await buildParts(text,files);const game=curMode==='game';
 const body={contents:[...gHistory,{role:'user',parts}],systemInstruction:{parts:[{text:game?GAME_PROMPT:chatPrompt()}]},generationConfig:{thinkingConfig:{thinkingLevel:'low'}}};
 const fast=cfg('megaia_fast_model','gemini-3.5-flash-lite'),smart=cfg('megaia_gemini_model','gemini-3.8-flash');
 const wm=webMode(),useWeb=!game&&wm!=='never'&&(wm==='always'||(!files.length&&needsWeb(text)));
 if(useWeb)body.tools=[{google_search:{}}];
 const heavy=game||files.length>0;const mb=parts.reduce((n,p)=>n+(p.inlineData?p.inlineData.data.length:0),0)/1e6;
 const order=[...new Set(heavy?[smart,fast]:[fast,smart])];
 let last;
 for(let i=0;i<order.length;i++){
  for(let a=0;a<3;a++){
   try{status(body.tools?'Pesquisando na web...':'Respondendo...');return await geminiStream(order[i],body,{signal,onText,firstMs:game?40000:heavy?Math.round(30000+mb*9000):body.tools?30000:(i?15000:9000),idleMs:game?45000:30000})}
   catch(e){last=e;if(e.thinking&&body.generationConfig){delete body.generationConfig;continue}if(e.tool&&body.tools){delete body.tools;toast('Pesquisa na web indisponível neste modelo; respondendo sem ela.');continue}if(e.fatal||signal.aborted)throw e;if(e.status>=500&&a===0){await sleep(2500,signal);continue}break}
  }
 }
 throw last}
async function refineImagePrompt(text,signal,english){
 const key=geminiKey();if(!key)return text;
 const ctl=new AbortController();linkSignal(ctl,signal);const t=setTimeout(()=>ctl.abort('timeout'),9000);
 try{
  const sys='Você escreve prompts para geradores de imagem. Receba o pedido do usuário e, se houver, o prompt da imagem anterior (o pedido pode ser só um ajuste, como "mais escuro", "com fundo azul" ou "troque o gato por um cachorro": nesse caso aplique o ajuste ao prompt anterior). Devolva UM prompt final'+(english?' em inglês':' em português')+', detalhado e fiel ao pedido: sujeito, quantidade de itens, cores, estilo, enquadramento, iluminação e fundo. Preserve todos os detalhes, nomes e textos pedidos e não contradiga o pedido. Responda só com o prompt, sem aspas nem explicações.';
  const u=(lastImagePrompt?'Prompt anterior: '+lastImagePrompt+'\n':'')+'Pedido: '+text;
  const r=await fetch(GURL+'models/'+encodeURIComponent(cfg('megaia_fast_model','gemini-3.5-flash-lite'))+':generateContent',{method:'POST',signal:ctl.signal,headers:gHeaders(),body:JSON.stringify({contents:[{role:'user',parts:[{text:u}]}],systemInstruction:{parts:[{text:sys}]}})});
  if(!r.ok)return text;const d=await r.json();
  const o=((d.candidates&&d.candidates[0]&&d.candidates[0].content&&d.candidates[0].content.parts)||[]).filter(p=>p.text&&!p.thought).map(p=>p.text).join(' ').trim().replace(/^["']|["']$/g,'');
  return o&&o.length>=text.length*0.5&&o.length<1500?o:text
 }catch(e){if(signal&&signal.aborted&&signal.reason==='user')throw e;return text}finally{clearTimeout(t)}}
async function geminiImage(prompt,signal,files){
 files=files||[];checkQuota('image');const model=cfg('megaia_image_model','gemini-3.1-flash-image');
 const iparts=[];for(const f0 of files.slice(0,4)){const f=await shrinkImage(f0);iparts.push({inlineData:{mimeType:mt(f).split(';')[0]||'image/jpeg',data:await fileToB64(f)}})}
 if(!iparts.length&&lastImagePrompt&&prompt.split(/\s+/).length<=12)prompt=await refineImagePrompt(prompt,signal,false);
 const ptext=iparts.length?'Edite a imagem enviada conforme o pedido, mantendo o que não for mencionado o mais parecido possível com o original. Pedido: '+prompt:'Crie a imagem exatamente como descrito, respeitando a quantidade de itens, as cores, as posições e qualquer texto pedido. Pedido: '+prompt;
 for(let a=0;a<2;a++){
  const ctl=new AbortController();linkSignal(ctl,signal);const t=setTimeout(()=>ctl.abort('timeout'),60000);
  try{
   let r;try{r=await fetch(GURL+'models/'+encodeURIComponent(model)+':generateContent',{method:'POST',signal:ctl.signal,headers:gHeaders(),body:JSON.stringify({contents:[{role:'user',parts:[...iparts,{text:ptext}]}],generationConfig:{responseModalities:['TEXT','IMAGE']}})})}catch(e){throw netError(e,ctl,60000)}
   const d=await r.json().catch(()=>({}));if(!r.ok)throw httpError(r.status,d,model);
   const cp=(d.candidates&&d.candidates[0]&&d.candidates[0].content&&d.candidates[0].content.parts)||[];
   const images=cp.filter(p=>p.inlineData).map(p=>({mimeType:p.inlineData.mimeType,data:p.inlineData.data}));
   const text=cp.filter(p=>p.text).map(p=>p.text).join('\n').trim();
   if(!images.length)throw mkErr(text||(d.promptFeedback&&d.promptFeedback.blockReason?'Pedido bloqueado pelo Gemini ('+d.promptFeedback.blockReason+').':'O modelo não retornou imagem. Confira o nome do modelo de imagem em Configurações.'),{fatal:true});
   useQuota('image',images.length);if(!iparts.length)lastImagePrompt=prompt;return {text:text||(iparts.length?'Imagem editada:':'Imagem gerada:'),images}
  }catch(e){if(e.fatal||e.status===429||signal.aborted||a===1)throw e;await sleep(1500,signal)}
  finally{clearTimeout(t)}
 }}
function loadImg(url,signal,ms){return new Promise((res,rej)=>{const im=new Image();let done=false;const fin=(f,v)=>{if(done)return;done=true;clearTimeout(t);signal.removeEventListener('abort',ab);f(v)};const t=setTimeout(()=>{im.src='';fin(rej,mkErr('O gerador gratuito demorou demais. Tente de novo.',{fatal:true}))},ms);const ab=()=>{im.src='';fin(rej,mkErr('Cancelado.',{fatal:true,cancelled:signal.reason==='user'}))};signal.addEventListener('abort',ab,{once:true});im.onload=()=>fin(res,im);im.onerror=()=>fin(rej,mkErr('O gerador gratuito não respondeu. Tente de novo em alguns segundos (ele aceita cerca de 1 imagem a cada 15 s).',{fatal:true}));im.alt='Imagem criada pela MegaIA';im.src=url})}
async function freeImage(prompt,signal,note){
 checkQuota('image');
 prompt=await refineImagePrompt(prompt,signal,true);lastImagePrompt=prompt;
 const url='https://image.pollinations.ai/prompt/'+encodeURIComponent(prompt.slice(0,900))+'?width=1024&height=1024&model=flux&nologo=true&seed='+Math.floor(Math.random()*1e6);
 const im=await loadImg(url,signal,70000);useQuota('image',1);
 return {text:(note?note+'\n':'')+'Imagem criada com o gerador gratuito (Pollinations), que segue bem menos os detalhes do pedido que o Gemini. O texto do pedido é enviado a esse serviço.',images:[],els:[im]}}
async function veoModels(signal,skip){
 veoModels.listed=false;
 try{const lr=await fetch(GURL+'models?pageSize=200',{signal,headers:{'x-goog-api-key':geminiKey()}});
  if(lr.ok){const d=await lr.json();veoModels.listed=true;return (d.models||[]).filter(m=>/veo/i.test(m.name)&&(!m.supportedGenerationMethods||m.supportedGenerationMethods.indexOf('predictLongRunning')>=0)).map(m=>m.name.replace(/^models\//,'')).filter(n=>n!==skip)}}
 catch(e){if(signal.aborted)throw e}
 return ['veo-3.1-fast-generate-preview','veo-3.0-generate-001','veo-3.0-fast-generate-001','veo-2.0-generate-001'].filter(n=>n!==skip)}
async function geminiVideo(prompt,signal,progress){
 checkQuota('video');const model=cfg('megaia_video_model','veo-3.1-generate-preview'),key=geminiKey();
 const ab=e=>{if(signal.aborted)return mkErr(signal.reason==='user'?'Cancelado.':'A criação do vídeo demorou demais e foi interrompida.',{fatal:true,cancelled:signal.reason==='user'});return navigator.onLine?mkErr('Falha de comunicação com o Google ao criar o vídeo.',{fatal:true}):mkErr('Sem internet.',{fatal:true})};
 const startVideo=async m=>{let rr;try{rr=await fetch(GURL+'models/'+encodeURIComponent(m)+':predictLongRunning',{method:'POST',signal,headers:gHeaders(),body:JSON.stringify({instances:[{prompt}]})})}catch(e){throw ab(e)}const oo=await rr.json().catch(()=>({}));return {r:rr,op:oo}};
 let r,op,mdl=model;
 ({r,op}=await startVideo(mdl));
 for(let k=0;k<2&&r.status>=500;k++){await sleep(3000,signal);({r,op}=await startVideo(mdl))}
 if(!r.ok&&r.status===404){
  for(const m of await veoModels(signal,mdl)){status('Tentando o modelo '+m+'...');({r,op}=await startVideo(m));if(r.ok){mdl=m;try{localStorage.setItem('megaia_video_model',m)}catch(_){}break}if(r.status!==404)break}
  if(!r.ok&&r.status===404){const gm=(op&&op.error&&op.error.message)||'';
   throw mkErr((veoModels.listed?'A lista de modelos da sua chave não inclui nenhum modelo de vídeo (Veo).':'O Google respondeu 404 para todos os modelos Veo testados.')+' O Veo exige uma chave de um projeto com faturamento ativo no Google AI Studio; chaves gratuitas não liberam.'+(gm?' Resposta do Google: '+gm.slice(0,200):''),{fatal:true,noVeo:true})}}
 if(!r.ok){const e=httpError(r.status,op,mdl);e.fatal=true;const gm=(op&&op.error&&op.error.message)||'';
  if(r.status===403||e.noQuota||(r.status===400&&/billing|paid|not (available|supported|enabled)|allowlist|permission|region|country/i.test(gm)))e.noVeo=true;
  if(r.status===400&&gm&&!e.noVeo)e.message='O Google recusou o pedido de vídeo: '+gm.slice(0,240);
  throw e}
 if(!op.name)throw mkErr('O Gemini não iniciou a criação do vídeo.',{fatal:true});
 const t0=Date.now();let fails=0;
 while(true){
  await sleep(8000,signal);progress(Math.round((Date.now()-t0)/1000));
  let pd;try{const pr=await fetch(GURL+op.name,{signal,headers:{'x-goog-api-key':key}});pd=await pr.json().catch(()=>({}));if(!pr.ok){const e=httpError(pr.status,pd,model);if(pr.status>=500){fails++;if(fails<4)continue}e.fatal=true;throw e}fails=0}catch(e){if(e.fatal)throw e;fails++;if(signal.aborted||fails>=4)throw ab(e);continue}
  if(!pd.done)continue;
  if(pd.error)throw mkErr('Falha ao criar o vídeo: '+(pd.error.message||'erro desconhecido'),{fatal:true});
  const gv=pd.response&&pd.response.generateVideoResponse;const uri=gv&&gv.generatedSamples&&gv.generatedSamples[0]&&gv.generatedSamples[0].video&&gv.generatedSamples[0].video.uri;
  if(!uri)throw mkErr(gv&&gv.raiMediaFilteredReasons&&gv.raiMediaFilteredReasons[0]?'Vídeo bloqueado pelo filtro de segurança: '+gv.raiMediaFilteredReasons[0]:'O Gemini não retornou o vídeo.',{fatal:true});
  let blob=null;try{const vr=await fetch(uri,{signal,headers:{'x-goog-api-key':key}});if(vr.ok)blob=await vr.blob()}catch(e){if(signal.aborted)throw ab(e)}
  useQuota('video',1);
  if(blob)return {url:URL.createObjectURL(blob),blob};
  return {url:uri+(uri.indexOf('?')<0?'?':'&')+'key='+encodeURIComponent(key),blob:null}
 }}

/* ===== Vídeo gratuito de reserva: animação 2D feita pelo modelo de TEXTO e gravada no aparelho ===== */
const MOTION_PROMPT='Você é o MegaIA Motion Studio. Escreva UMA função JavaScript chamada draw(ctx,t,W,H) que desenha UM quadro de uma animação 2D de 8 segundos num canvas 2D de 640x360 (W e H), onde t é o tempo em segundos (0 a 8). Regras: desenhe o quadro inteiro a cada chamada (fundo incluso); tudo deve ser função de t (animação suave e determinística, sem estado externo, sem Math.random sem semente); use só ctx e Math, formas, gradientes, linhas, arcos e texto (fonte sans-serif); sem imagens, sem rede, sem DOM, sem window, sem document. Capriche: cenário com profundidade, cores vibrantes, personagens e objetos feitos de formas, movimento de câmera, uma ação clara do pedido ao longo dos 8 s e, no máximo, um título curto. Responda com UM único bloco ```js contendo só a função draw (e funções auxiliares dentro dela).';
const DEFAULT_DRAW='function draw(ctx,t,W,H){var g=ctx.createLinearGradient(0,0,W,H);g.addColorStop(0,"hsl("+(220+t*12)+",70%,18%)");g.addColorStop(1,"hsl("+(280+t*12)+",70%,35%)");ctx.fillStyle=g;ctx.fillRect(0,0,W,H);for(var i=0;i<40;i++){var a=i*2.399+t*0.4,r=40+((i*37)%260);var x=W/2+Math.cos(a)*r*1.6,y=H/2+Math.sin(a*1.3)*r*0.7;ctx.fillStyle="rgba(255,255,255,"+(0.15+0.5*((i%5)/5))+")";ctx.beginPath();ctx.arc(x,y,2+(i%4),0,6.283);ctx.fill()}}';
function motionDoc(code,id){return '<!doctype html><html><body style="margin:0;background:#000"><canvas id="c" width="640" height="360" style="width:100%;height:auto;display:block"></canvas><script>(function(){var ID='+JSON.stringify(id)+',W=640,H=360,D=8,cv=document.getElementById("c"),ctx=cv.getContext("2d"),CODE='+JSON.stringify(code).replace(/</g,'\\u003c')+';'
+'function send(o){o.mv=ID;parent.postMessage(o,"*")}'
+'var draw;try{draw=new Function(CODE+"\\n;return draw;")()}catch(e){send({err:"código da animação inválido: "+e.message});return}'
+'if(typeof draw!=="function"){send({err:"a animação não definiu draw()"});return}'
+'try{ctx.save();draw(ctx,0,W,H);ctx.restore()}catch(e){send({err:"erro na animação: "+e.message});return}'
+'if(!window.MediaRecorder||!cv.captureStream){send({err:"este aparelho não grava vídeo a partir do canvas"});return}'
+'var mt=["video/webm;codecs=vp9","video/webm;codecs=vp8","video/webm","video/mp4"].filter(function(x){return MediaRecorder.isTypeSupported(x)})[0];'
+'var rec;try{rec=new MediaRecorder(cv.captureStream(30),mt?{mimeType:mt,videoBitsPerSecond:4000000}:{})}catch(e){send({err:"MediaRecorder falhou: "+e.message});return}'
+'var ch=[];rec.ondataavailable=function(e){if(e.data&&e.data.size)ch.push(e.data)};'
+'rec.onstop=function(){send({blob:new Blob(ch,{type:(mt||"video/webm").split(";")[0]})})};'
+'var t0=performance.now(),bad=0;function frame(){var t=(performance.now()-t0)/1000;try{ctx.save();draw(ctx,Math.min(t,D),W,H);ctx.restore()}catch(e){if(++bad>5){try{rec.stop()}catch(_){}send({err:"erro na animação: "+e.message});return}}'
+'send({p:Math.min(t,D)});if(t<D)requestAnimationFrame(frame);else setTimeout(function(){rec.stop()},250)}'
+'rec.start(250);frame()})()<\/script></body></html>'}
async function motionCode(prompt,signal){
 const ctl=new AbortController();linkSignal(ctl,signal);const tm=setTimeout(()=>ctl.abort('timeout'),60000);
 try{const r=await fetch(GURL+'models/'+encodeURIComponent(cfg('megaia_gemini_model','gemini-3.8-flash'))+':generateContent',{method:'POST',signal:ctl.signal,headers:gHeaders(),body:JSON.stringify({contents:[{role:'user',parts:[{text:'Pedido de vídeo: '+prompt}]}],systemInstruction:{parts:[{text:MOTION_PROMPT}]},generationConfig:{thinkingConfig:{thinkingLevel:'low'}}})});
  if(!r.ok)return null;const d=await r.json();
  const tx=((d.candidates&&d.candidates[0]&&d.candidates[0].content&&d.candidates[0].content.parts)||[]).filter(p=>p.text&&!p.thought).map(p=>p.text).join('\n');
  const m=tx.match(/```(?:js|javascript)?[ \t]*\r?\n([\s\S]*?)```/i);const code=(m?m[1]:tx).trim();
  return /function\s+draw\s*\(/.test(code)?code:null
 }catch(e){if(signal&&signal.aborted&&signal.reason==='user')throw e;return null}finally{clearTimeout(tm)}}
function recordMotion(code,signal,host,progress){return new Promise((resolve,reject)=>{
 const id='mv'+Date.now(),fr=document.createElement('iframe');fr.setAttribute('sandbox','allow-scripts');fr.style.cssText='width:100%;aspect-ratio:16/9;border:0;border-radius:12px;background:#000;display:block;margin-top:8px';
 let fin=false;const end=(fn,v)=>{if(fin)return;fin=true;window.removeEventListener('message',on);clearTimeout(to);signal.removeEventListener('abort',ab);fr.remove();fn(v)};
 const on=ev=>{if(ev.source!==fr.contentWindow||!ev.data||ev.data.mv!==id)return;const d=ev.data;if(d.err)end(reject,mkErr(d.err,{motionFail:true}));else if(d.blob)end(resolve,d.blob);else if(typeof d.p==='number')progress(d.p)};
 const ab=()=>end(reject,mkErr('Cancelado.',{fatal:true,cancelled:true}));
 const to=setTimeout(()=>end(reject,mkErr('A gravação da animação demorou demais.',{motionFail:true})),40000);
 window.addEventListener('message',on);signal.addEventListener('abort',ab);
 host.append(fr);fr.srcdoc=motionDoc(code,id)})}
async function localVideo(prompt,signal,host,progress){
 progress('Pensando na animação...');
 let code=await motionCode(prompt,signal),used=code;
 const rec=c=>recordMotion(c,signal,host,s=>progress('Gravando a animação... '+Math.floor(s)+'/8 s'));
 let blob;
 try{blob=await rec(code||DEFAULT_DRAW)}catch(e){if(e.cancelled||!code)throw e;blob=await rec(DEFAULT_DRAW);used=null}
 return {url:URL.createObjectURL(blob),blob,generic:!used}}

/* ===== Servidor MegaIA (opcional) ===== */
let srvState={ok:null,msg:'',at:0};
async function checkServer(force){const base=apiBase();if(!force&&srvState.at&&Date.now()-srvState.at<20000)return srvState;const t=await testServer(base);srvState={ok:t.ok,msg:t.msg,at:Date.now()};return srvState}
async function serverChat(text,files,signal){
 const base=apiBase(),st=await checkServer();if(!st.ok)throw mkErr(st.msg,{fatal:true,serverDown:true});
 const isImg=curMode==='image'&&!files.length;if(isImg)checkQuota('image');
 const fd=new FormData();fd.append('message',text);fd.append('mode',curMode);files.forEach(f=>fd.append('files',f));
 const ctl=new AbortController();linkSignal(ctl,signal);const lim=files.length?180000:(isImg?90000:30000);const t=setTimeout(()=>ctl.abort('timeout'),lim);
 try{
  let r;try{r=await fetch(base+(isImg?'/api/generate-image':'/api/chat'),{method:'POST',body:fd,signal:ctl.signal,headers:Object.assign(geminiKey()?{'X-Gemini-API-Key':geminiKey()}:{},window.MegaAuth?window.MegaAuth.authHeaders():{})})}catch(e){srvState.at=0;throw netError(e,ctl,lim,'servidor')}
  const data=await r.json().catch(()=>null);
  if(r.status===401)throw mkErr('O servidor pediu login e a sessão não é válida. Toque no seu nome (topo) > Sair da conta e entre de novo com o Google.',{fatal:true});
  if(!r.ok)throw mkErr((data&&data.error)||(r.status===404?'Endereço do servidor incorreto (404). Use só o endereço base, sem /api.':'O servidor respondeu com erro ('+r.status+').'),{fatal:true});
  if(!data)throw mkErr('Resposta inválida do servidor.',{fatal:true});
  const images=data.images||[];if(isImg&&images.length)useQuota('image',images.length);
  return {text:data.reply||data.text||(images.length?'Imagem gerada:':'A MegaIA respondeu.'),images}
 }finally{clearTimeout(t)}}

/* ===== Jogos ===== */
function extractHtml(t){let m=t.match(/```(?:html)?[ \t]*\r?\n([\s\S]*?)```/i);if(m)return {html:m[1].trim(),rest:t.replace(m[0],'').trim()};
 m=t.match(/```(?:html)?[ \t]*\r?\n([\s\S]*)$/i);if(m&&/<(html|canvas|script|body)/i.test(m[1]))return {html:m[1].trim(),rest:t.slice(0,m.index).trim()};
 const i=t.search(/<!doctype html|<html/i);if(i>=0)return {html:t.slice(i).trim(),rest:t.slice(0,i).trim()};return null}
function openFullGame(html){const o=document.createElement('div');o.className='fullgame';const fr=document.createElement('iframe');fr.setAttribute('sandbox','allow-scripts');fr.srcdoc=html;const x=document.createElement('button');x.type='button';x.className='fullclose';x.textContent='✕ Fechar';x.onclick=()=>o.remove();o.append(fr,x);document.body.append(o)}
function gameCard(html){const w=document.createElement('div');w.className='gamecard';const fr=document.createElement('iframe');fr.className='gameframe';fr.setAttribute('sandbox','allow-scripts');fr.srcdoc=html;const bar=document.createElement('div');bar.className='gamebar';
 const mk=(t,f)=>{const b=document.createElement('button');b.type='button';b.textContent=t;b.onclick=f;bar.append(b)};
 mk('⛶ Tela cheia',()=>openFullGame(html));mk('↻ Reiniciar',()=>{fr.srcdoc=html});
 mk('⧉ Copiar código',async()=>{try{await navigator.clipboard.writeText(html);toast('Código copiado')}catch(_){toast('Não consegui copiar o código')}});
 w.append(fr,bar);return w}
function loadGames(){try{return JSON.parse(localStorage.getItem('megaia_games')||'[]')}catch(_){return []}}
function saveGame(title,html){try{const g=loadGames();g.unshift({id:Date.now(),title:(title||'Jogo').slice(0,50),html});localStorage.setItem('megaia_games',JSON.stringify(g.slice(0,15)))}catch(_){toast('Jogo criado, mas não coube na memória para salvar.')}}
function renderGames(){const box=$('gamesList');box.innerHTML='';const g=loadGames();if(!g.length){box.innerHTML='<p class="hint">Nenhum jogo salvo ainda. Use ☰ &gt; Criar jogos.</p>';return}
 g.forEach(x=>{const row=document.createElement('div');row.className='gamerow';const n=document.createElement('span');n.textContent='🎮 '+x.title;const p=document.createElement('button');p.type='button';p.textContent='▶ Jogar';p.onclick=()=>{$('gamesModal').classList.add('hidden');openFullGame(x.html)};const d=document.createElement('button');d.type='button';d.textContent='🗑';d.onclick=()=>{localStorage.setItem('megaia_games',JSON.stringify(loadGames().filter(y=>y.id!==x.id)));renderGames()};row.append(n,p,d);box.append(row)})}
$('gamesBtn').onclick=()=>{renderGames();$('sidebar').classList.remove('open');$('gamesModal').classList.remove('hidden')};
$('closeGames').onclick=()=>$('gamesModal').classList.add('hidden');
$('gamesModal').addEventListener('click',e=>{if(e.target===$('gamesModal'))$('gamesModal').classList.add('hidden')});

/* ===== Offline ===== */
async function ensureOffline(){if(localPipe)return localPipe;if(localBusy)throw new Error('O modelo offline já está carregando. Aguarde.');localBusy=true;status('Carregando modelo offline...');
 try{
  try{if(navigator.storage&&navigator.storage.persist)navigator.storage.persist()}catch(_){}
  const {pipeline,env}=await import('https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.8.1');env.allowLocalModels=false;env.useBrowserCache=true;
  localPipe=await pipeline('text-generation',cfg('megaia_model','onnx-community/SmolLM2-135M-Instruct-ONNX'),{progress_callback:p=>{if(p&&p.status==='progress'&&typeof p.progress==='number'){const t='Baixando modelo offline: '+Math.round(p.progress)+'%';status(t);const el=$('offlineInfo');if(el)el.textContent=t}}});
  localStorage.setItem('megaia_offline_ready2','1');status('Modelo offline pronto');return localPipe
 }catch(e){throw new Error(localStorage.getItem('megaia_offline_ready2')?'Não consegui carregar o modelo offline. Conecte à internet uma vez e toque em ⚙ > Baixar modelo offline para guardar tudo no aparelho. ('+e.message+')':'O modelo offline ainda não foi baixado. Conecte ao Wi-Fi e use ☰ > ⚙ > "Baixar modelo offline". Depois disso funciona sem internet. (Cálculos, data e hora já funcionam sem ele.)')}
 finally{localBusy=false}}

/* ===== Conversas salvas (ficam no aparelho: texto, fotos, jogos e vídeos) ===== */
const tmo=(p,ms)=>Promise.race([p,new Promise((_,rej)=>setTimeout(()=>rej(new Error('tempo esgotado')),ms))]);
const MIME={jpg:'image/jpeg',jpeg:'image/jpeg',png:'image/png',webp:'image/webp',gif:'image/gif',heic:'image/heic',heif:'image/heif',mp4:'video/mp4',mov:'video/quicktime',webm:'video/webm','3gp':'video/3gpp',mkv:'video/x-matroska',mp3:'audio/mpeg',wav:'audio/wav',m4a:'audio/mp4',aac:'audio/aac',ogg:'audio/ogg',flac:'audio/flac',pdf:'application/pdf',txt:'text/plain',csv:'text/csv',json:'application/json',md:'text/markdown'};
function mt(f){if(f.type)return f.type;const m=/\.([a-z0-9]+)$/i.exec(f.name||'');return (m&&MIME[m[1].toLowerCase()])||''}
async function drawScaled(f,max){
 if(!window.createImageBitmap)return null;
 let bmp;try{bmp=await createImageBitmap(f)}catch(_){return null}
 const sc=Math.min(1,max/Math.max(bmp.width,bmp.height)),w=Math.max(1,Math.round(bmp.width*sc)),h=Math.max(1,Math.round(bmp.height*sc));
 const c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,w,h);x.drawImage(bmp,0,0,w,h);if(bmp.close)bmp.close();return c}
async function shrinkImage(f){
 try{if(!/^image\/(jpeg|png|webp)$/.test(f.type)||f.size<500*1024)return f;
  const c=await drawScaled(f,1600);if(!c)return f;
  const blob=await new Promise(r=>c.toBlob(r,'image/jpeg',.85));
  if(!blob||blob.size>=f.size)return f;
  return new File([blob],(f.name||'foto').replace(/\.\w+$/,'')+'.jpg',{type:'image/jpeg'})}catch(_){return f}}
async function makeThumbs(files){const out=[];
 for(const f of files){if(out.length>=6)break;if(!mt(f).startsWith('image/'))continue;
  try{const c=await drawScaled(f,240);if(c)out.push(c.toDataURL('image/jpeg',.7))}catch(_){}}
 return out}
function addThumbs(b,list){if(!list||!list.length)return;const w=document.createElement('div');w.className='thumbs';list.forEach(u=>{const i=document.createElement('img');i.className='thumb';i.src=u;i.alt='Foto enviada';w.append(i)});b.append(w)}
function videoEl(url){const v=document.createElement('video');v.className='result-video';v.src=url;v.controls=true;v.playsInline=true;v.loop=true;v.preload='metadata';
 v.onerror=()=>{if(v.dataset.err)return;v.dataset.err='1';const p=document.createElement('p');p.className='hint';p.textContent='Não consegui reproduzir este vídeo (o link pode ter expirado). Crie outro.';v.after(p)};return v}
let conv=null,saveWarned=false;
function warnSave(e){if(!saveWarned){saveWarned=true;toast('Não consegui salvar esta conversa no aparelho (memória cheia?).')}try{console.warn(e)}catch(_){}}
function ensureConv(firstText){if(!conv){conv={id:'c'+Date.now().toString(36)+Math.random().toString(36).slice(2,6),title:String(firstText||'').replace(/\s+/g,' ').trim().slice(0,40)||'Nova conversa',updated:Date.now(),hist:[]}}return conv}
async function touchConv(){if(!conv)return;conv.updated=Date.now();conv.hist=gHistory.map(h=>({role:h.role,parts:h.parts.map(p=>({text:p.text}))}));
 try{await tmo(MegaStore.putConv(conv),5000)}catch(e){warnSave(e)}renderConvList()}
async function saveMsg(m){const c=ensureConv();try{await tmo(MegaStore.addMsg(c.id,m),8000);return true}catch(e){warnSave(e);return false}}
function resetChatUI(){lastCreate=null;lastImagePrompt='';conv=null;gHistory.length=0;stopSpeak();$('messages').innerHTML='';$('prompt').value='';$('prompt').dispatchEvent(new Event('input'));attachments=[];renderAttachments();$('content').querySelector('.welcome').style.display='block'}
function renderMsg(m){
 const names=(m.fnames||[]).map(n=>({name:n}));
 const b=addMessage(m.who==='assistant'?(m.text||(m.game?'Jogo pronto! 🎮':'')):(m.text||''),m.who,names);
 addThumbs(b,m.thumbs);
 (m.images||[]).forEach(it=>{const i=document.createElement('img');i.className='result-image';i.alt='Imagem criada pela MegaIA';i.src='data:'+it.mimeType+';base64,'+it.data;b.append(i)});
 (m.urls||[]).forEach(u=>{const i=document.createElement('img');i.className='result-image';i.alt='Imagem criada pela MegaIA';i.src=u;b.append(i)});
 if(m.game)b.append(gameCard(m.game));
 addSources(b,m.sources);
 if(m.video||m.videoUrl)b.append(videoEl(m.video?URL.createObjectURL(m.video):m.videoUrl));
 b._msg=m;finishMsg(b,m.text||'');attachGenerated(b);return b}
let convQuery='',convTimer=null;
function slug(t){return String(t||'conversa').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-zA-Z0-9]+/g,'-').replace(/^-+|-+$/g,'').slice(0,40)||'conversa'}
async function convMarkdown(id){
 const r=await tmo(MegaStore.load(id),10000);if(!r)return null;
 const L=['# '+(r.conv.title||'Conversa'),'','_Exportado da MegaIA em '+new Date().toLocaleString('pt-BR')+'_',''];
 for(const m of r.msgs){
  L.push('**'+(m.who==='user'?'Você':'MegaIA')+':**');
  if(m.text)L.push(m.text);
  if(m.fnames&&m.fnames.length)L.push('_Anexos: '+m.fnames.join(', ')+'_');
  if((m.images&&m.images.length)||(m.urls&&m.urls.length))L.push('_[imagem criada]_');
  if(m.video||m.videoUrl)L.push('_[vídeo criado]_');
  if(m.sources&&m.sources.length)L.push('Fontes: '+m.sources.map(x=>'['+(x.title||x.uri)+']('+x.uri+')').join(', '));
  if(m.game)L.push('```html\n'+m.game+'\n```');
  L.push('')}
 return {name:slug(r.conv.title)+'.md',text:L.join('\n')}}
async function exportConv(id){
 let ex=null;try{ex=await convMarkdown(id)}catch(e){toast('Não consegui ler a conversa.');return}
 if(!ex){toast('Conversa não encontrada');return}
 try{if(window.MegaShare){MegaShare.shareFile(ex.name,ex.text);return}}catch(_){}
 try{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([ex.text],{type:'text/markdown'}));a.download=ex.name;document.body.append(a);a.click();a.remove();toast('Conversa exportada');return}catch(_){}
 copyText(ex.text)}
async function renameConv(id,title){
 title=String(title||'').replace(/\s+/g,' ').trim().slice(0,60);if(!title)return;
 try{const r=await tmo(MegaStore.load(id),8000);if(!r)return;r.conv.title=title;await tmo(MegaStore.putConv(r.conv),5000);if(conv&&conv.id===id)conv.title=title}catch(e){warnSave(e)}}
async function renderConvList(){
 const box=$('convList');if(!box)return;let list=[];
 try{list=await tmo(MegaStore.list(),4000)}catch(_){}
 const q=convQuery.trim().toLowerCase();
 if(q){let ids=[];try{ids=await tmo(MegaStore.search(q),8000)}catch(_){}
  list=list.filter(c=>String(c.title||'').toLowerCase().indexOf(q)>=0||ids.indexOf(c.id)>=0)}
 box.innerHTML='';
 if(!list.length){const p=document.createElement('p');p.className='hint';p.textContent=q?'Nenhuma conversa encontrada.':'Suas conversas ficam salvas aqui.';box.append(p);return}
 list.slice(0,80).forEach(c=>{
  const row=document.createElement('div');row.className='convrow'+(conv&&conv.id===c.id?' active':'');
  const t=document.createElement('button');t.type='button';t.className='convtitle';t.textContent=c.title||'Conversa';t.onclick=()=>openConv(c.id);
  const mkb=(txt,title,fn)=>{const b=document.createElement('button');b.type='button';b.className='convdel';b.textContent=txt;b.title=title;b.onclick=e=>{e.stopPropagation();fn(b)};return b};
  const rn=mkb('✎','Renomear',()=>{
   const inp=document.createElement('input');inp.className='convedit';inp.value=c.title||'';inp.maxLength=60;let fin=false;
   const done=async save=>{if(fin)return;fin=true;if(save)await renameConv(c.id,inp.value);renderConvList()};
   inp.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();done(true)}else if(e.key==='Escape')done(false)};inp.onblur=()=>done(true);
   t.replaceWith(inp);inp.focus();inp.select()});
  const ex=mkb('⤴','Exportar',()=>exportConv(c.id));
  let armed=false;
  const d=mkb('🗑','Apagar conversa',async b=>{
   if(!armed){armed=true;b.textContent='Apagar?';setTimeout(()=>{armed=false;b.textContent='🗑'},3000);return}
   try{await tmo(MegaStore.del(c.id),5000)}catch(_){}
   if(conv&&conv.id===c.id)resetChatUI();renderConvList()});
  row.append(t,rn,ex,d);box.append(row)})}
if($('convSearch'))$('convSearch').oninput=e=>{convQuery=e.target.value;clearTimeout(convTimer);convTimer=setTimeout(renderConvList,250)};
async function openConv(id){
 if(busy){toast('Aguarde a resposta terminar.');return}
 let r=null;try{r=await tmo(MegaStore.load(id),8000)}catch(e){warnSave(e)}
 if(!r)return;
 stopSpeak();conv=r.conv;gHistory.length=0;(conv.hist||[]).forEach(h=>gHistory.push(h));
 $('messages').innerHTML='';
 if(r.msgs.length)r.msgs.forEach(m=>{try{renderMsg(m)}catch(_){}});else $('content').querySelector('.welcome').style.display='block';
 $('sidebar').classList.remove('open');renderConvList();scrollEnd()}
async function migrateLegacy(){
 const old=legacyLog();if(!old.length)return;
 const first=old.find(e=>e.who==='user');
 const hist=old.slice(-8).map(e=>({role:e.who==='user'?'user':'model',parts:[{text:String(e.text||'')}]}));while(hist.length&&hist[0].role!=='user')hist.shift();
 const c={id:'c'+Date.now().toString(36),title:String((first&&first.text)||'Conversa anterior').replace(/\s+/g,' ').trim().slice(0,40),updated:Date.now(),hist};
 await MegaStore.putConv(c);for(const e of old)await MegaStore.addMsg(c.id,{who:e.who,text:String(e.text||'')});
 localStorage.removeItem('megaia_log')}
async function initConversations(){
 try{if(navigator.storage&&navigator.storage.persist)navigator.storage.persist()}catch(_){}
 try{await tmo(MegaStore.open(),4000)}catch(_){}
 try{await tmo(migrateLegacy(),10000)}catch(e){try{console.warn(e)}catch(_){}}
 let list=[];try{list=await tmo(MegaStore.list(),4000)}catch(_){}
 await renderConvList();
 if(list.length&&!busy&&!conv)await openConv(list[0].id)}

/* ===== Envio (nunca trava o chat) ===== */
let busy=false,currentCtl=null;
function setBusy(b){busy=b;$('sendBtn').textContent=b?'■':'➤';$('sendBtn').title=b?'Parar':'Enviar';$('sendBtn').classList.toggle('stop',b)}
function scrollEnd(){$('content').scrollTop=$('content').scrollHeight}
function addSources(b,list){if(!list||!list.length||b.querySelector('.sources'))return;
 const w=document.createElement('div');w.className='sources';const h=document.createElement('span');h.textContent='🌐 Fontes: ';w.append(h);
 list.slice(0,6).forEach((x,i)=>{const a=document.createElement('a');a.href=x.uri;a.rel='noopener';a.textContent=(x.title||x.uri).slice(0,40);w.append(a)});b.append(w)}
function showImages(reply,images,els){(els||[]).forEach(e=>{e.className='result-image';reply.append(e)});for(const it of images){const img=document.createElement('img');img.className='result-image';img.src='data:'+it.mimeType+';base64,'+it.data;img.alt='Imagem criada pela MegaIA';reply.append(img)}}
async function send(){
 if(busy)return;
 let text=$('prompt').value.trim(),files=[...attachments];
 if(!text&&!files.length){toast('Escreva uma mensagem ou anexe algo');return}
 if(wordCount(text)>MAX_WORDS){toast('O limite é 10.000 palavras por mensagem');return}
 const origText=text;
 let sendMode=mode;if(mode==='chat'&&!files.length){const di=detectIntent(text);if(di){sendMode=di;lastCreate={mode:di,text}}
  else if(lastCreate&&confirmIntent(text)){sendMode=lastCreate.mode;text=lastCreate.text}}
 const onlyImgs=files.length>0&&files.every(f=>mt(f).startsWith('image/'));
 if(mode==='chat'&&onlyImgs&&text&&detectEdit(text)&&!/\?\s*$/.test(text)&&!/\b(descreva|o que|qual|quais|quem|explique|analise|leia|traduza|transcreva)\b/i.test(text))sendMode='image';
 curMode=sendMode;
 $('prompt').value='';$('prompt').dispatchEvent(new Event('input'));attachments=[];renderAttachments();
 const userText=origText||(mode==='image'?'Crie uma imagem com base nos anexos.':'Analise os anexos, por favor.');const ub=addMessage(userText,'user',files);
 const um={who:'user',text:userText.slice(0,20000),fnames:files.map(f=>f.name)};ensureConv(userText);
 const userSaved=(async()=>{try{um.thumbs=await tmo(makeThumbs(files),5000);addThumbs(ub,um.thumbs)}catch(_){}await saveMsg(um);await touchConv()})();
 const reply=addMessage('Processando...','assistant',[],true);
 setBusy(true);const ctl=new AbortController();currentCtl=ctl;
 const wd=setTimeout(()=>ctl.abort('timeout'),sendMode==='makevideo'?480000:150000);
 let partial='';
 try{
  let out=null;
  if(network==='offline'||!navigator.onLine){
   if(files.length||sendMode!=='chat')throw mkErr('Sem internet (ou modo Offline): anexos, imagens, vídeos e jogos precisam de internet.',{fatal:true});
   if(network!=='offline')status('Sem internet: usando modo offline');
   const basic=offlineBasic(text);
   if(basic)out={text:basic,images:[]};
   else{const p=await ensureOffline();const o=await p([{role:'system',content:'Você é a MegaIA. Responda em português do Brasil, de forma curta e clara.'},{role:'user',content:text}],{max_new_tokens:500,temperature:.7,do_sample:true});const g=o[0].generated_text;out={text:(Array.isArray(g)?g[g.length-1].content:String(g).slice(text.length)).trim()||'Não consegui gerar uma resposta offline.',images:[]}}
   status('Respondido offline');
  }else{
   const key=geminiKey(),hasServer=!!apiBase();
   const imgOnly=files.every(f=>mt(f).startsWith('image/'));const isEdit=sendMode==='image'&&files.length>0&&imgOnly;
   if(isEdit&&!key)throw mkErr('Editar imagem precisa da chave Gemini salva nas Configurações.',{fatal:true});
   if(isEdit&&!text)throw mkErr('Descreva o que quer mudar na imagem (ex.: troque o fundo por uma praia).',{fatal:true});
   const wantImg=sendMode==='image'&&(!files.length||isEdit);
   if(!key&&!hasServer&&!wantImg)throw mkErr('Abra Configurações (☰ > ⚙) e cole sua chave Gemini para começar.',{fatal:true});
   if(sendMode==='makevideo'){
    if(!key)throw mkErr('Criar vídeos precisa da chave Gemini salva nas Configurações.',{fatal:true});
    if(!text)throw mkErr('Descreva o vídeo que quer criar.',{fatal:true});
    reply.textContent='🎬 Criando vídeo de 8 s... isso leva de 1 a 3 minutos. Toque em ■ para cancelar.';
    let vid,vtxt='Seu vídeo está pronto:';
    try{vid=await geminiVideo(text,ctl.signal,s=>{reply.textContent='🎬 Criando vídeo... '+s+' s (leva de 1 a 3 min). Toque em ■ para cancelar.'})}
    catch(e){
     if(!(e.noVeo||e.noQuota||e.daily)||ctl.signal.aborted)throw e;
     const why=String(e.message||'').slice(0,300);status('Sem Veo: criando animação gratuita...');
     reply.textContent='⚠️ '+why+'\n\n🎞 Vou criar uma animação 2D gratuita (feita pelo modelo de texto, sem o Veo). Leva cerca de 30 s.';
     const host=document.createElement('div');reply.append(host);
     vid=await localVideo(text,ctl.signal,host,s=>{reply.firstChild&&(reply.firstChild.nodeValue='⚠️ '+why+'\n\n🎞 '+s)});
     vtxt='Seu vídeo (animação gratuita'+(vid.generic?', simples: o modelo não conseguiu montar a cena':'')+') está pronto. Para vídeo realista com IA (Veo), ative o faturamento no Google AI Studio:';
    }
    reply.textContent=vtxt;reply.append(videoEl(vid.url));finishMsg(reply,vtxt);status('Vídeo criado');
    const vm={who:'assistant',text:vtxt};if(vid.blob)vm.video=vid.blob;else vm.videoUrl=vid.url;reply._msg=vm;await userSaved;await saveMsg(vm);await touchConv();await saveConversation(text,'[vídeo criado]');return}
   const isImg=sendMode==='image'&&(!files.length||isEdit);
   const onText=t=>{partial=t;if(sendMode==='game')reply.textContent='🎮 Criando seu jogo... '+Math.max(1,Math.round(t.length/1000))+' mil caracteres';else setReply(reply,t);scrollEnd()};
   if(key){
    try{out=isImg?await geminiImage(text,ctl.signal,files):await geminiChat(text,files,ctl.signal,onText)}
    catch(e){if(isImg&&!isEdit&&!e.fatal&&!ctl.signal.aborted){status('Gemini sem imagem; usando gerador gratuito...');out=await freeImage(text,ctl.signal,'⚠️ O Gemini não gerou a imagem: '+String(e.message||'').slice(0,220))}else if(!e.fatal&&hasServer&&!ctl.signal.aborted&&(await checkServer()).ok){status('Tentando pelo servidor...');out=await serverChat(text,files,ctl.signal)}else throw e}
   }else out=isImg?await freeImage(text,ctl.signal):await serverChat(text,files,ctl.signal);
   if(key&&!isImg){gHistory.push({role:'user',parts:[{text:(text||'(anexos enviados)')+(files.length?'\n[Anexos: '+files.map(f=>f.name).join(', ')+']':'')}]},{role:'model',parts:[{text:out.text}]});trimHistory()}
   status(key?'Gemini conectado':'Servidor conectado');
  }
  let shown=out.text,gameHtml=null;
  if(sendMode==='game'){const g=extractHtml(out.text);if(g&&g.html.length>200){setReply(reply,g.rest||'Jogo pronto! 🎮 Toque em Tela cheia para jogar.');reply.append(gameCard(g.html));saveGame(text,g.html);gameHtml=g.html;shown=g.rest}else{setReply(reply,out.text)}}
  else{setReply(reply,out.text);showImages(reply,out.images||[],out.els);attachGenerated(reply);addSources(reply,out.sources)}
  const ea={who:'assistant',text:gameHtml?(shown||'Jogo pronto! 🎮'):String(shown||out.text||'').slice(0,20000)};if(gameHtml)ea.game=gameHtml;if(out.images&&out.images.length)ea.images=out.images;if(out.sources&&out.sources.length)ea.sources=out.sources;if(out.els&&out.els.length)ea.urls=out.els.map(e=>e.src);reply._msg=ea;finishMsg(reply,shown||out.text);await userSaved;await saveMsg(ea);await touchConv();
  if(voiceMode){const vt=shown||out.text;if(sendMode==='chat'&&vt){speak(vt,reply._readBtn);ttsThen=voiceListen}else setTimeout(voiceListen,400)}
  else if(localStorage.getItem('megaia_autoread')==='1'&&sendMode!=='game')speak(shown||out.text,reply._readBtn);
  scrollEnd();await saveConversation(text,shown);
 }catch(e){
  if(voiceMode)setVoice(false,true);
  const msg=e&&e.message?e.message:'erro desconhecido';
  if(e&&e.cancelled)reply.textContent=(partial?partial+'\n\n':'')+'⏹ Cancelado.';
  else{reply.textContent=(partial&&sendMode!=='game'?partial+'\n\n⚠️ Resposta interrompida: ':'Não consegui concluir: ')+msg;
   if(!(e&&e.cancelled)){const b=document.createElement('button');b.type='button';b.className='retry';b.textContent='↻ Tentar de novo';b.onclick=()=>{if(busy)return;$('prompt').value=text;$('prompt').dispatchEvent(new Event('input'));send()};reply.append(document.createElement('br'),b)}}
  status(e&&e.serverDown?'Servidor indisponível':'Falhou — tente de novo');
 }finally{clearTimeout(wd);currentCtl=null;setBusy(false);scrollEnd()}
}
$('sendBtn').onclick=()=>{if(busy){if(currentCtl)currentCtl.abort('user')}else send()};
$('prompt').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send()}});
async function refreshStatus(){
 if(network==='offline'||!navigator.onLine){status((network==='offline'?'Offline':'Sem internet')+(localStorage.getItem('megaia_offline_ready2')?': modelo pronto':': só cálculos básicos'));return}
 const key=geminiKey();
 if(key){status('Verificando chave...');const ctl=new AbortController();const t=setTimeout(()=>ctl.abort(),6000);
  try{const r=await fetch(GURL+'models/'+encodeURIComponent(cfg('megaia_fast_model','gemini-3.5-flash-lite')),{headers:{'x-goog-api-key':key},signal:ctl.signal});status(r.ok?'Gemini conectado':(r.status===400||r.status===403)?'Chave inválida':r.status===404?'Modelo rápido não encontrado':'Gemini instável ('+r.status+')')}
  catch(_){status(ctl.signal.aborted?'Conexão lenta com o Google':'Sem conexão com o Google')}finally{clearTimeout(t)}return}
 if(apiBase()){status('Testando servidor...');const s=await checkServer(true);status(s.ok?'Servidor conectado':'Servidor indisponível');return}
 status('Aguardando chave Gemini')}
window.addEventListener('online',()=>{toast('Internet voltou');refreshStatus()});
window.addEventListener('offline',()=>{status('Sem internet');toast('Você está sem internet')});

async function startAudio(){try{if(recorder&&recorder.state==='recording'){recorder.stop();return}if(!navigator.mediaDevices?.getUserMedia||!window.MediaRecorder)throw new Error('Gravação de áudio não é compatível neste navegador.');let stream=await navigator.mediaDevices.getUserMedia({audio:true});recorder=new MediaRecorder(stream);chunks=[];recorder.ondataavailable=e=>chunks.push(e.data);recorder.onstop=()=>{let blob=new Blob(chunks,{type:recorder.mimeType||'audio/webm'});let f=new File([blob],'gravacao.webm',{type:blob.type});attachments.push(f);renderAttachments();stream.getTracks().forEach(t=>t.stop());toast('Áudio anexado. Envie para transcrever/analisar online.')};recorder.start();toast('Gravando áudio — toque no microfone novamente para parar.');$('micBtn').onclick=()=>{if(recorder&&recorder.state==='recording'){recorder.stop();$('micBtn').onclick=micTap}}}catch(e){toast(e.message)}}
$('micBtn').onclick=micTap;

/* ===== Voz em tempo real: ditado e conversa por voz ===== */
let voiceMode=false,dictating=false,dictBase='',sttRetries=0,ttsThen=null,webRec=null;
const WebSR=window.SpeechRecognition||window.webkitSpeechRecognition;
function nativeStt(){try{return !!(window.MegaSTT&&MegaSTT.available())}catch(_){return false}}
function micUI(on){dictating=on;$('micBtn').textContent=on?'⏹':'🎙';$('micBtn').classList.toggle('rec',on)}
function setPrompt(t){$('prompt').value=t;$('prompt').dispatchEvent(new Event('input'))}
function startDictation(){
 if(busy)return false;dictBase=$('prompt').value.trim();
 if(nativeStt()){micUI(true);status('Ouvindo... fale agora');MegaSTT.start('pt-BR');return true}
 if(WebSR){try{webRec=new WebSR();webRec.lang='pt-BR';webRec.interimResults=true;webRec.continuous=false;let got=false;
   webRec.onresult=e=>{let tx='',fin=false;for(let i=0;i<e.results.length;i++){tx+=e.results[i][0].transcript;if(e.results[i].isFinal)fin=true}if(fin){got=true;window.onSttFinal(tx)}else window.onSttPartial(tx)};
   webRec.onerror=e=>{got=true;window.onSttError(e.error==='not-allowed'?'denied':e.error==='no-speech'?'7':'x')};
   webRec.onend=()=>{if(!got&&dictating)window.onSttError('7')};
   webRec.start();micUI(true);status('Ouvindo... fale agora');return true}catch(_){}}
 return false}
function stopDictation(cancel){try{if(window.MegaSTT)cancel?MegaSTT.cancel():MegaSTT.stop();if(webRec)cancel?webRec.abort():webRec.stop()}catch(_){}if(cancel)micUI(false)}
window.onSttReady=()=>status('Ouvindo... fale agora');
window.onSttPartial=t=>{if(t)setPrompt((dictBase?dictBase+' ':'')+t)};
window.onSttFinal=t=>{micUI(false);sttRetries=0;t=String(t||'').trim();
 if(t)setPrompt((dictBase?dictBase+' ':'')+t);
 if(voiceMode){if(t)send();else setTimeout(voiceListen,300)}else{status('Texto reconhecido');$('prompt').focus()}};
window.onSttError=c=>{c=String(c);if(c==='5')return;micUI(false);
 const silent=(c==='7'||c==='6');
 if(voiceMode&&silent&&sttRetries<2){sttRetries++;setTimeout(voiceListen,400);return}
 const msg={denied:'Permita o microfone para o MegaIA nas configurações do Android.',9:'Permita o microfone para o MegaIA nas configurações do Android.',unavailable:'Este aparelho não tem reconhecimento de voz. Instale ou atualize o app Google.',2:'Sem internet para reconhecer a voz.',3:'Erro no microfone.',8:'O reconhecedor de voz está ocupado. Tente de novo.',7:'Não entendi. Tente de novo.',6:'Não ouvi nada. Tente de novo.'}[c]||'Não consegui usar a voz ('+c+').';
 if(voiceMode){setVoice(false,true);toast(silent?'Não ouvi nada. Conversa por voz encerrada.':msg)}else toast(msg);refreshStatus()};
function voiceListen(){if(!voiceMode||busy||dictating)return;if(!startDictation()){setVoice(false);toast('Voz em tempo real não funciona neste aparelho.')}}
function setVoice(on,quiet){voiceMode=on;$('voiceBtn').classList.toggle('on',on);
 if(on){sttRetries=0;toast('Conversa por voz ligada. Fale agora; toque em 🗣 para encerrar.');voiceListen()}
 else{ttsThen=null;stopSpeak();stopDictation(true);if(!quiet)refreshStatus()}}
function micTap(){
 if(dictating){stopDictation(false);return}
 if(busy){toast('Aguarde a resposta terminar.');return}
 if(voiceMode)setVoice(false);
 if(!startDictation())startAudio()}
$('micBtn').onclick=micTap;
$('voiceBtn').onclick=()=>{if(busy&&!voiceMode){toast('Aguarde a resposta terminar.');return}setVoice(!voiceMode)};
$('webBtn').onclick=()=>{const w=webMode()==='always'?'auto':'always';localStorage.setItem('megaia_web',w);$('webBtn').classList.toggle('on',w==='always');if($('webMode'))$('webMode').value=w;toast(w==='always'?'🌐 Pesquisa na web: sempre ligada':'🌐 Pesquisa na web: automática')};
$('webBtn').classList.toggle('on',webMode()==='always');
$('webMode').onchange=e=>{localStorage.setItem('megaia_web',e.target.value);$('webBtn').classList.toggle('on',e.target.value==='always')};
$('settingsBtn').addEventListener('click',()=>{$('webMode').value=webMode()});

/* Firebase (opcional): só sincroniza o histórico. O login em si é nativo (auth.js); aqui o ID token do Google é reaproveitado. */
async function initFirebase(){
 const raw=localStorage.getItem('megaia_firebase');if(!raw||firebaseAuth)return !!firebaseAuth||null;
 const u=window.MegaAuth&&MegaAuth.user();if(!u||!u.idToken)return null;
 try{
  const cfg=JSON.parse(raw);
  const appMod=await import('https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js');
  const authMod=await import('https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js');
  const fsMod=await import('https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js');
  firebaseApp=appMod.initializeApp(cfg,'megaia-'+(cfg.projectId||'project'));
  firebaseAuth=authMod.getAuth(firebaseApp);firestore=fsMod.getFirestore(firebaseApp);
  firebaseFns={...authMod,...fsMod};
  const cred=authMod.GoogleAuthProvider.credential(u.idToken);
  const res=await authMod.signInWithCredential(firebaseAuth,cred);currentUser=res.user;
  return true;
 }catch(e){firebaseAuth=null;toast('Firebase: '+e.message+' (o ID token do Google dura 1 h; saia e entre de novo se expirou).');return null}
}
async function saveConversation(userText,assistantText){if(!currentUser||!firestore)return;try{const {collection,addDoc,serverTimestamp}=firebaseFns;await addDoc(collection(firestore,'users',currentUser.uid,'messages'),{userText,assistantText,createdAt:serverTimestamp()})}catch(e){toast('Não foi possível sincronizar o histórico: '+e.message)}}
async function loadConversation(){if(!currentUser||!firestore)return;try{const {collection,getDocs,query,orderBy,limit}=firebaseFns;const q=query(collection(firestore,'users',currentUser.uid,'messages'),orderBy('createdAt','desc'),limit(30));const snap=await getDocs(q);if(snap.empty)return;$('messages').innerHTML='';for(const d of snap.docs.reverse()){const v=d.data();addMessage(v.userText||'', 'user');addMessage(v.assistantText||'', 'assistant')}toast('Histórico sincronizado')}catch(e){toast('Histórico não carregado. Confira as regras do Firestore: '+e.message)}}
if('serviceWorker'in navigator)window.addEventListener('load',()=>navigator.serviceWorker.getRegistrations().then(rs=>rs.forEach(r=>r.unregister())).catch(()=>{}));
showQuota();initConversations();refreshStatus();
if(localStorage.getItem('megaia_firebase'))initFirebase();
