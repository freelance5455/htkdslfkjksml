export const DHIKRS = [
  {
    id: "subhanallah",
    ar: "سُبْحَانَ اللَّهِ",
    tr: "Allah'ı tenzih ederim",
    label: "Subhanallah",
  },
  {
    id: "alhamdulillah",
    ar: "الْحَمْدُ لِلَّهِ",
    tr: "Hamd Allah'a mahsustur",
    label: "Alhamdulillah",
  },
  {
    id: "allahuakbar",
    ar: "اللَّهُ أَكْبَرُ",
    tr: "Allah en büyüktür",
    label: "Allahu Akbar",
  },
  {
    id: "lailaha",
    ar: "لَا إِلَٰهَ إِلَّا اللَّهُ",
    tr: "Allah'tan başka ilah yoktur",
    label: "La ilahe illallah",
  },
  {
    id: "astaghfirullah",
    ar: "أَسْتَغْفِرُ اللَّهَ",
    tr: "Allah'tan bağışlanma dilerim",
    label: "Astaghfirullah",
  },
  {
    id: "salawat",
    ar: "صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ",
    tr: "Allah ona salat ve selam etsin",
    label: "Salawat",
  },
  {
    id: "subhanallahi",
    ar: "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ",
    tr: "Allah'ı hamd ile tenzih ederim",
    label: "Subhanallahi ve bihamdihi",
  },
  {
    id: "hasbunallah",
    ar: "حَسْبُنَا اللَّهُ وَنِعْمَ الْوَكِيلُ",
    tr: "Allah bize yeter, O ne güzel vekildir",
    label: "Hasbunallah",
  },
  {
    id: "lahavle",
    ar: "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ",
    tr: "Güç ve kuvvet ancak Allah'tandır",
    label: "La havle",
  },
  {
    id: "rabbighfirli",
    ar: "رَبِّ اغْفِرْ لِي",
    tr: "Rabbim beni bağışla",
    label: "Rabbiğfirli",
  },
] as const;

export type DhikrId = (typeof DHIKRS)[number]["id"];

export const GOAL_PRESETS = [33, 99, 100, 333, 500, 1000] as const;

export const THEMES = [
  { id: "emerald", accent: "#10b981", dark: "#059669", label: "Zümrüt" },
  { id: "teal", accent: "#14b8a6", dark: "#0d9488", label: "Teal" },
  { id: "sky", accent: "#0ea5e9", dark: "#0284c7", label: "Gökyüzü" },
  { id: "blue", accent: "#2563eb", dark: "#1d4ed8", label: "Mavi" },
  { id: "rose", accent: "#f43f5e", dark: "#e11d48", label: "Gül" },
  { id: "gold", accent: "#d4af37", dark: "#b8860b", label: "Altın" },
] as const;

export type ThemeId = (typeof THEMES)[number]["id"];

export const RING_RADIUS = 80;
export const RING_CIRC = 2 * Math.PI * RING_RADIUS;

export function todayKey(): string {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function emptyCounts(): Record<string, number> {
  return Object.fromEntries(DHIKRS.map((d) => [d.id, 0]));
}

export function applyTheme(id: ThemeId) {
  if (typeof document === "undefined") return;
  const theme = THEMES.find((t) => t.id === id) ?? THEMES[0];
  const root = document.documentElement;
  root.style.setProperty("--accent", theme.accent);
  root.style.setProperty("--accent-dark", theme.dark);
}

export function clampGoal(n: number): number {
  if (!Number.isFinite(n)) return 33;
  return Math.max(1, Math.min(99999, Math.floor(n)));
}
