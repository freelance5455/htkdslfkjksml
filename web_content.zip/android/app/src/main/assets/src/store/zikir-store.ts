import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import {
  applyTheme,
  clampGoal,
  emptyCounts,
  todayKey,
  type DhikrId,
  type ThemeId,
} from "@/lib/zikir";
import { haptic, hapticGoal, playComplete, playTick } from "@/lib/sounds";

export type TapResult = { incremented: boolean; reached: boolean };

type Persisted = {
  activeId: DhikrId;
  counts: Record<string, number>;
  totals: Record<string, number>;
  goal: number;
  todayDate: string;
  todayCount: number;
  lifetime: number;
  rounds: number;
  sound: boolean;
  vibrate: boolean;
  theme: ThemeId;
  stopAtGoal: boolean;
};

type Actions = {
  tap: () => TapResult;
  setActive: (id: DhikrId) => void;
  setGoal: (n: number) => void;
  resetCurrent: () => void;
  resetAll: () => void;
  setSound: (v: boolean) => void;
  setVibrate: (v: boolean) => void;
  setTheme: (id: ThemeId) => void;
  setStopAtGoal: (v: boolean) => void;
  rollToday: () => void;
};

const memoryStorage: Storage = {
  getItem: () => null,
  setItem: () => undefined,
  removeItem: () => undefined,
  clear: () => undefined,
  key: () => null,
  length: 0,
};

export const useZikirStore = create<Persisted & Actions>()(
  persist(
    (set, get) => ({
      activeId: "subhanallah",
      counts: emptyCounts(),
      totals: emptyCounts(),
      goal: 33,
      todayDate: todayKey(),
      todayCount: 0,
      lifetime: 0,
      rounds: 0,
      sound: true,
      vibrate: true,
      theme: "emerald",
      stopAtGoal: true,

      rollToday: () => {
        const today = todayKey();
        if (get().todayDate !== today) {
          set({ todayDate: today, todayCount: 0 });
        }
      },

      tap: () => {
        const s = get();
        const current = s.counts[s.activeId] ?? 0;
        if (s.stopAtGoal && current >= s.goal) {
          return { incremented: false, reached: true };
        }

        if (s.sound) playTick();
        if (s.vibrate) haptic();

        const next = current + 1;
        const reached = next >= s.goal && current < s.goal;
        const today = todayKey();

        set({
          counts: { ...s.counts, [s.activeId]: next },
          totals: {
            ...s.totals,
            [s.activeId]: (s.totals[s.activeId] ?? 0) + 1,
          },
          lifetime: s.lifetime + 1,
          todayDate: today,
          todayCount: s.todayDate === today ? s.todayCount + 1 : 1,
          rounds: reached ? s.rounds + 1 : s.rounds,
        });

        if (reached) {
          if (s.sound) playComplete();
          if (s.vibrate) hapticGoal();
        }

        return { incremented: true, reached };
      },

      setActive: (id) => set({ activeId: id }),
      setGoal: (n) => set({ goal: clampGoal(n) }),
      resetCurrent: () => {
        const s = get();
        set({ counts: { ...s.counts, [s.activeId]: 0 } });
      },
      resetAll: () =>
        set({
          counts: emptyCounts(),
          totals: emptyCounts(),
          todayCount: 0,
          todayDate: todayKey(),
          lifetime: 0,
          rounds: 0,
          goal: 33,
          activeId: "subhanallah",
        }),
      setSound: (v) => set({ sound: v }),
      setVibrate: (v) => set({ vibrate: v }),
      setTheme: (id) => {
        applyTheme(id);
        set({ theme: id });
      },
      setStopAtGoal: (v) => set({ stopAtGoal: v }),
    }),
    {
      name: "zikirmatik-said-ucar-v1",
      storage: createJSONStorage(() =>
        typeof window === "undefined" ? memoryStorage : localStorage,
      ),
      skipHydration: true,
      partialize: (s) => ({
        activeId: s.activeId,
        counts: s.counts,
        totals: s.totals,
        goal: s.goal,
        todayDate: s.todayDate,
        todayCount: s.todayCount,
        lifetime: s.lifetime,
        rounds: s.rounds,
        sound: s.sound,
        vibrate: s.vibrate,
        theme: s.theme,
        stopAtGoal: s.stopAtGoal,
      }),
    },
  ),
);
