import { useCallback, useEffect, useRef, useState } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import { Check, ChevronRight, BookOpen, Plus, RotateCcw, Settings, Target, X } from "lucide-react";
import {
  DHIKRS,
  GOAL_PRESETS,
  RING_CIRC,
  THEMES,
  applyTheme,
  clampGoal,
  type DhikrId,
} from "@/lib/zikir";
import { useZikirStore } from "@/store/zikir-store";

type ConfirmKind = "current" | "all" | null;

export function ZikirApp() {
  const activeId = useZikirStore((s) => s.activeId);
  const counts = useZikirStore((s) => s.counts);
  const totals = useZikirStore((s) => s.totals);
  const goal = useZikirStore((s) => s.goal);
  const todayCount = useZikirStore((s) => s.todayCount);
  const lifetime = useZikirStore((s) => s.lifetime);
  const rounds = useZikirStore((s) => s.rounds);
  const sound = useZikirStore((s) => s.sound);
  const vibrate = useZikirStore((s) => s.vibrate);
  const theme = useZikirStore((s) => s.theme);
  const stopAtGoal = useZikirStore((s) => s.stopAtGoal);

  const tap = useZikirStore((s) => s.tap);
  const setActive = useZikirStore((s) => s.setActive);
  const setGoal = useZikirStore((s) => s.setGoal);
  const resetCurrent = useZikirStore((s) => s.resetCurrent);
  const resetAll = useZikirStore((s) => s.resetAll);
  const setSound = useZikirStore((s) => s.setSound);
  const setVibrate = useZikirStore((s) => s.setVibrate);
  const setTheme = useZikirStore((s) => s.setTheme);
  const setStopAtGoal = useZikirStore((s) => s.setStopAtGoal);
  const rollToday = useZikirStore((s) => s.rollToday);

  const [goalOpen, setGoalOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [dualarOpen, setDualarOpen] = useState(false);
  const [confirm, setConfirm] = useState<ConfirmKind>(null);
  const [draftGoal, setDraftGoal] = useState(String(goal));
  const [pulse, setPulse] = useState(false);
  const [toast, setToast] = useState("");
  const toastTimer = useRef(0);

  const dhikr = DHIKRS.find((d) => d.id === activeId) ?? DHIKRS[0];
  const count = counts[activeId] ?? 0;
  const locked = stopAtGoal && count >= goal;
  const left = Math.max(0, goal - count);
  const offset = RING_CIRC * (1 - Math.min(count / Math.max(goal, 1), 1));
  const modalOpen = goalOpen || settingsOpen || dualarOpen || confirm !== null;

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(""), 1800);
  }, []);

  useEffect(() => {
    const apply = () => {
      rollToday();
      applyTheme(useZikirStore.getState().theme);
    };
    const unsub = useZikirStore.persist.onFinishHydration(apply);
    void useZikirStore.persist.rehydrate();
    if (useZikirStore.persist.hasHydrated()) apply();
    return unsub;
  }, [rollToday]);

  useEffect(() => {
    applyTheme(theme);
  }, [theme]);

  const handleTap = useCallback(() => {
    const result = tap();
    if (!result.incremented) return;
    setPulse(true);
    window.setTimeout(() => setPulse(false), 120);
    if (result.reached) showToast("Hedefe ulaşıldı");
  }, [tap, showToast]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code !== "Space") return;
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "BUTTON") return;
      if (modalOpen) return;
      e.preventDefault();
      handleTap();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [handleTap, modalOpen]);

  useEffect(() => {
    setDraftGoal(String(goal));
  }, [goal, goalOpen]);

  const saveGoal = () => {
    const n = clampGoal(Number.parseInt(draftGoal, 10));
    setGoal(n);
    setGoalOpen(false);
    showToast("Hedef güncellendi");
  };

  return (
    <>
      <div className="device">
        <div className="bismillah" dir="rtl" lang="ar">
          بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
        </div>
        <div className="title">Zikirmatik</div>

        <div className="dhikr-bar" id="dhikrBar" role="tablist" aria-label="Zikir seçimi">
          {DHIKRS.map((item) => (
            <button
              key={item.id}
              type="button"
              role="tab"
              aria-selected={item.id === activeId}
              className={item.id === activeId ? "dhikr-chip active" : "dhikr-chip"}
              onClick={() => setActive(item.id as DhikrId)}
            >
              {item.label}
            </button>
          ))}
        </div>

        <div className="screen">
          <div className="arabic" id="arabic" dir="rtl" lang="ar">
            {dhikr.ar}
          </div>
          <div className="meaning" id="meaning">
            {dhikr.tr}
          </div>

          <div className="count-wrap">
            <svg className="ring" width="180" height="180" viewBox="0 0 180 180" aria-hidden="true">
              <circle className="ring-bg" cx="90" cy="90" r="80" />
              <circle
                className="ring-fill"
                id="ring"
                cx="90"
                cy="90"
                r="80"
                style={{ strokeDashoffset: offset }}
              />
            </svg>
            <div className="count-num">
              <span id="count" className={pulse ? "pulse" : undefined} aria-live="polite">
                {count}
              </span>
              <small>ZİKİR</small>
            </div>
          </div>

          <div className="goal-text">
            Hedef: <b id="goalText">{goal}</b>
            {" "}&nbsp;•&nbsp; Kalan: <b id="leftText">{left}</b>
          </div>
          <div className={locked ? "goal-reached show" : "goal-reached"} id="goalReached">
            <Check size={16} strokeWidth={2.5} aria-hidden="true" />
            Hedefe ulaşıldı • Sıfırla ile devam et
          </div>
        </div>

        <button
          type="button"
          className="main-btn"
          id="tap"
          disabled={locked}
          onPointerDown={(e) => {
            if (e.button !== 0) return;
            e.preventDefault();
            handleTap();
          }}
        >
          <Plus size={22} strokeWidth={2.5} aria-hidden="true" />
          Zikir Çek
        </button>

        <div className="controls">
          <button type="button" className="ctrl" id="goalBtn" onClick={() => setGoalOpen(true)}>
            <Target strokeWidth={2} />
            Hedef
          </button>
          <button
            type="button"
            className="ctrl"
            id="dualarBtn"
            onClick={() => setDualarOpen(true)}
          >
            <BookOpen strokeWidth={2} />
            Dualar
          </button>
          <button
            type="button"
            className="ctrl"
            id="resetBtn"
            onClick={() => setConfirm("current")}
          >
            <RotateCcw strokeWidth={2} />
            Sıfırla
          </button>
          <button
            type="button"
            className="ctrl"
            id="settingsBtn"
            onClick={() => setSettingsOpen(true)}
          >
            <Settings strokeWidth={2} />
            Ayarlar
          </button>
        </div>

        <div className="stats">
          <div className="stat">
            <strong>{todayCount}</strong>
            <span>Bugün</span>
          </div>
          <div className="stat">
            <strong>{lifetime}</strong>
            <span>Toplam</span>
          </div>
          <div className="stat">
            <strong>{rounds}</strong>
            <span>Tur</span>
          </div>
        </div>
      </div>

      <footer className="app-footer">Said Uçar</footer>

      <Dialog.Root open={goalOpen} onOpenChange={setGoalOpen}>
        <Dialog.Portal>
          <Dialog.Overlay className="overlay" />
          <Dialog.Content className="modal" aria-describedby={undefined}>
            <Dialog.Title className="modal-title">Hedef Belirle</Dialog.Title>
            <div className="goal-grid">
              {GOAL_PRESETS.map((n) => (
                <button
                  key={n}
                  type="button"
                  className={Number(draftGoal) === n ? "goal-opt selected" : "goal-opt"}
                  onClick={() => setDraftGoal(String(n))}
                >
                  {n}
                </button>
              ))}
            </div>
            <input
              className="custom-input"
              type="number"
              min={1}
              max={99999}
              inputMode="numeric"
              placeholder="Özel hedef"
              value={draftGoal}
              onChange={(e) => setDraftGoal(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") saveGoal();
              }}
            />
            <div className="modal-btns">
              <button type="button" className="btn-cancel" onClick={() => setGoalOpen(false)}>
                Vazgeç
              </button>
              <button type="button" className="btn-save" onClick={saveGoal}>
                Kaydet
              </button>
            </div>
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>

      <Dialog.Root open={settingsOpen} onOpenChange={setSettingsOpen}>
        <Dialog.Portal>
          <Dialog.Overlay className="overlay" />
          <Dialog.Content className="modal" aria-describedby={undefined}>
            <div className="modal-head">
              <Dialog.Title className="modal-title">Ayarlar</Dialog.Title>
              <Dialog.Close className="modal-close" aria-label="Kapat">
                <X strokeWidth={2} />
              </Dialog.Close>
            </div>

            <button
              type="button"
              className="menu-link"
              onClick={() => {
                setSettingsOpen(false);
                setDualarOpen(true);
              }}
            >
              <div>
                <div className="setting-label">Dualar</div>
                <div className="setting-desc">Arapça, anlam ve zikir toplamları</div>
              </div>
              <ChevronRight className="chev" size={18} strokeWidth={2} />
            </button>

            <div className="setting-row">
              <div>
                <div className="setting-label">Ses efekti</div>
                <div className="setting-desc">Zikir çekerken kısa bir ses</div>
              </div>
              <button
                type="button"
                className={sound ? "toggle on" : "toggle"}
                role="switch"
                aria-checked={sound}
                aria-label="Ses efekti"
                onClick={() => setSound(!sound)}
              />
            </div>

            <div className="setting-row">
              <div>
                <div className="setting-label">Titreşim</div>
                <div className="setting-desc">Destekleyen cihazlarda titreşim</div>
              </div>
              <button
                type="button"
                className={vibrate ? "toggle on" : "toggle"}
                role="switch"
                aria-checked={vibrate}
                aria-label="Titreşim"
                onClick={() => setVibrate(!vibrate)}
              />
            </div>

            <div className="setting-row">
              <div>
                <div className="setting-label">Hedefte dur</div>
                <div className="setting-desc">Hedefe ulaşınca sayaç kilitlenir</div>
              </div>
              <button
                type="button"
                className={stopAtGoal ? "toggle on" : "toggle"}
                role="switch"
                aria-checked={stopAtGoal}
                aria-label="Hedefte dur"
                onClick={() => setStopAtGoal(!stopAtGoal)}
              />
            </div>

            <div className="section-title">Renk teması</div>
            <div className="color-row">
              {THEMES.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  className={theme === t.id ? "color-dot active" : "color-dot"}
                  style={{ background: t.accent }}
                  aria-label={t.label}
                  title={t.label}
                  onClick={() => setTheme(t.id)}
                />
              ))}
            </div>

            <div className="dev-card">
              <div className="label">Geliştirici</div>
              <div className="name">Said Uçar</div>
              <div className="note">Profesyonel Zikirmatik</div>
            </div>

            <button
              type="button"
              className="danger-btn"
              onClick={() => {
                setSettingsOpen(false);
                setConfirm("all");
              }}
            >
              Tüm verileri sil
            </button>
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>

      <Dialog.Root open={dualarOpen} onOpenChange={setDualarOpen}>
        <Dialog.Portal>
          <Dialog.Overlay className="overlay" />
          <Dialog.Content className="modal" aria-describedby={undefined}>
            <div className="modal-head">
              <Dialog.Title className="modal-title">Dualar</Dialog.Title>
              <Dialog.Close className="modal-close" aria-label="Kapat">
                <X strokeWidth={2} />
              </Dialog.Close>
            </div>

            {DHIKRS.map((item) => {
              const current = counts[item.id] ?? 0;
              const total = totals[item.id] ?? 0;
              const selected = item.id === activeId;
              return (
                <article
                  key={item.id}
                  className={selected ? "dua-card active" : "dua-card"}
                >
                  <div className="dua-ar" dir="rtl" lang="ar">
                    {item.ar}
                  </div>
                  <div className="dua-label">{item.label}</div>
                  <div className="dua-tr">{item.tr}</div>
                  <div className="dua-meta">
                    <span>
                      Bu tur
                      <b>{current}</b>
                    </span>
                    <span>
                      Toplam
                      <b>{total}</b>
                    </span>
                    <span>
                      Kalan
                      <b>{Math.max(0, goal - current)}</b>
                    </span>
                  </div>
                  <button
                    type="button"
                    className="dua-pick"
                    onClick={() => {
                      setActive(item.id as DhikrId);
                      setDualarOpen(false);
                      if (!selected) showToast(`${item.label} seçildi`);
                    }}
                  >
                    {selected ? "Şu an seçili" : "Bu zikri seç"}
                  </button>
                </article>
              );
            })}
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>

      <Dialog.Root
        open={confirm !== null}
        onOpenChange={(open) => {
          if (!open) setConfirm(null);
        }}
      >
        <Dialog.Portal>
          <Dialog.Overlay className="overlay" />
          <Dialog.Content className="modal" aria-describedby={undefined}>
            <Dialog.Title className="modal-title">
              {confirm === "all" ? "Tüm veriler silinsin mi?" : "Sayaç sıfırlansın mı?"}
            </Dialog.Title>
            <p className="confirm-text">
              {confirm === "all"
                ? "Bugünkü, toplam ve tur sayıları da sıfırlanır."
                : "Bu turdaki zikirler silinir, toplamlar korunur."}
            </p>
            <p className="confirm-sub">Bu işlem geri alınamaz.</p>
            <div className="modal-btns">
              <button type="button" className="btn-cancel" onClick={() => setConfirm(null)}>
                Vazgeç
              </button>
              <button
                type="button"
                className={confirm === "all" ? "btn-danger" : "btn-save"}
                onClick={() => {
                  if (confirm === "all") {
                    resetAll();
                    showToast("Tüm veriler silindi");
                  } else {
                    resetCurrent();
                    showToast("Sayaç sıfırlandı");
                  }
                  setConfirm(null);
                }}
              >
                {confirm === "all" ? "Sil" : "Sıfırla"}
              </button>
            </div>
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>

      <div className={toast ? "toast show" : "toast"} role="status">
        {toast}
      </div>
    </>
  );
}
