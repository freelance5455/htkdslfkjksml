import { createFileRoute } from "@tanstack/react-router";
import { ZikirApp } from "@/components/zikir-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <ZikirApp />;
}
