// Copy this to config.js and replace with your HTTPS backend.
// Never put secrets in this file.
window.APP_CONFIG = {
  API_BASE: "https://YOUR-BACKEND-DOMAIN.example.com"
};
