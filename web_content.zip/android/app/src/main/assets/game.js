import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.164.1/build/three.module.js';

// ============================================================
// الداية مريم — سر الداية
// Mobile/PC survival-horror gameplay inspired by the hide/seek
// loop of classic escape-horror games, with original characters.
// ============================================================

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x050608);
scene.fog = new THREE.Fog(0x080b0e, 5, 34);

const camera = new THREE.PerspectiveCamera(72, innerWidth / innerHeight, 0.05, 80);
camera.position.set(0, 1.65, 10);
camera.rotation.order = 'YXZ';

const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
renderer.setSize(innerWidth, innerHeight);
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.05;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
document.getElementById('game').appendChild(renderer.domElement);

const clock = new THREE.Clock();
const Y = new THREE.Vector3(0, 1, 0);


// ---------- Procedural materials for a more grounded, aged-house look ----------
function canvasTexture(base, speck, scale=96, alpha=1) {
  const c = document.createElement('canvas'); c.width = c.height = scale;
  const ctx = c.getContext('2d');
  ctx.fillStyle = base; ctx.fillRect(0,0,scale,scale);
  for(let i=0;i<scale*1.6;i++){
    const x=Math.random()*scale, y=Math.random()*scale;
    const r=Math.random()*2.2+0.3;
    ctx.globalAlpha=(Math.random()*.16+.035)*alpha;
    ctx.fillStyle=speck; ctx.fillRect(x,y,r,r);
  }
  ctx.globalAlpha=1;
  const tex=new THREE.CanvasTexture(c); tex.colorSpace=THREE.SRGBColorSpace; tex.wrapS=tex.wrapT=THREE.RepeatWrapping; tex.anisotropy=4;
  return tex;
}
function woodTexture() {
  const c=document.createElement('canvas'); c.width=c.height=256; const ctx=c.getContext('2d');
  ctx.fillStyle='#2a1c17'; ctx.fillRect(0,0,256,256);
  for(let i=0;i<90;i++){ ctx.strokeStyle=`rgba(125,78,47,${.06+Math.random()*.16})`; ctx.lineWidth=1+Math.random()*2; ctx.beginPath(); const y=Math.random()*256; ctx.moveTo(0,y); for(let x=0;x<=256;x+=16) ctx.lineTo(x,y+Math.sin(x*.04+i)*3); ctx.stroke(); }
  const t=new THREE.CanvasTexture(c); t.colorSpace=THREE.SRGBColorSpace; t.wrapS=t.wrapT=THREE.RepeatWrapping; t.repeat.set(2,2); t.anisotropy=4; return t;
}
const wallTex=canvasTexture('#34312f','#d2c5ad'); wallTex.repeat.set(5,4);
const floorTex=canvasTexture('#111214','#6b6257'); floorTex.repeat.set(8,8);
const woodTex=woodTexture();

const mat = {
  wall: new THREE.MeshStandardMaterial({ map: wallTex, color: 0xffffff, roughness: 1, metalness: 0 }),
  wallDark: new THREE.MeshStandardMaterial({ map: wallTex, color: 0x777777, roughness: 1 }),
  floor: new THREE.MeshStandardMaterial({ map: floorTex, color: 0x8a857e, roughness: .98 }),
  wood: new THREE.MeshStandardMaterial({ map: woodTex, color: 0xffffff, roughness: .96 }),
  wood2: new THREE.MeshStandardMaterial({ map: woodTex, color: 0x8b6049, roughness: .9 }),
  metal: new THREE.MeshStandardMaterial({ color: 0x454747, roughness: .75, metalness: .15 }),
  cloth: new THREE.MeshStandardMaterial({ color: 0x101012, roughness: 1 }),
  skin: new THREE.MeshStandardMaterial({ color: 0x69645e, roughness: 1 }),
  red: new THREE.MeshStandardMaterial({ color: 0x70151b, roughness: .8, emissive: 0x180000 }),
  brass: new THREE.MeshStandardMaterial({ color: 0x9d7737, roughness: .55, metalness: .45 }),
  white: new THREE.MeshStandardMaterial({ color: 0xd9d4c8, roughness: .8 }),
};

const colliders = [];
const interactables = [];
const hideSpots = [];
const doors = [];
const keys = new Set();
const inventory = [];

let objective = 'اعثر على أختك';
let sisterFound = false;
let generatorOn = false;
let exitOpen = false;
let gameOver = false;
let crouch = false;
let running = false;
let hiding = false;
let flashlightOn = true;
let stamina = 100;
let battery = 100;
let noise = 0;
let noiseTimer = 0;
let maryState = 'patrol';
let maryTarget = new THREE.Vector3(-10, 0, -7);
let lastSeenAt = 0;
let lastNoiseAt = 0;
let patrolIndex = 0;
let yaw = 0;
let pitch = 0;
let touchLook = null;
let touchMove = { x: 0, y: 0 };

function box(name, x, y, z, sx, sy, sz, material, solid = true) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(sx, sy, sz), material);
  m.name = name;
  m.position.set(x, y, z);
  m.castShadow = true;
  m.receiveShadow = true;
  scene.add(m);
  if (solid) colliders.push({ min: new THREE.Vector3(x - sx / 2, y - sy / 2, z - sz / 2), max: new THREE.Vector3(x + sx / 2, y + sy / 2, z + sz / 2), obj: m });
  return m;
}
function wall(x, z, sx, sz) { return box('wall', x, 1.5, z, sx, 3, sz, mat.wall, true); }
function prop(name, x, y, z, sx, sy, sz, material = mat.wood) { return box(name, x, y, z, sx, sy, sz, material, false); }
function distXZ(a, b) { return Math.hypot(a.x - b.x, a.z - b.z); }

// ---------- House ----------
box('floor', 0, -0.08, 0, 30, .15, 26, mat.floor, false);
wall(0, -13, 30, .4); wall(-15, 0, .4, 26); wall(15, 0, .4, 26);
// Internal walls deliberately leave doorways.
wall(-8, -5, .35, 16); wall(8, -5, .35, 16);
wall(0, 3, 16, .35); wall(-11, 7, 8, .35); wall(11, 7, 8, .35);
wall(-8, 13, 14, .4); wall(8, 13, 14, .4);

// Ceiling, aged beams and a worn central rug add scale and depth.
box('ceiling', 0, 3.12, 0, 30, .12, 26, mat.wallDark, false);
for (let x of [-12,-6,0,6,12]) box('beam', x, 2.92, 0, .22, .35, 25.5, mat.wood2, false);
const rugMat = new THREE.MeshStandardMaterial({color:0x24191a, roughness:1});
const rug = new THREE.Mesh(new THREE.PlaneGeometry(5.2,10), rugMat); rug.rotation.x=-Math.PI/2; rug.position.set(0,.012,-1); rug.receiveShadow=true; scene.add(rug);

// Rooms/furniture.
prop('diningTable', -3, .55, -8, 3.2, .9, 1.6);
prop('desk', -11, .55, 10, 2.2, .9, 1);
prop('cabinetA', 11.2, 1.5, -3.2, 1.2, 3, 1.2);
prop('cabinetB', -11.2, 1.5, 1.5, 1.2, 3, 1.2);
prop('shelf', 4.8, 1.3, 9.5, 2.4, 2.6, .55, mat.wood2);
prop('bed', 10.7, .45, 9.5, 2.5, .65, 4, mat.wood2);
prop('bedBlanket', 10.7, .8, 9.5, 2.25, .18, 3.4, mat.cloth);
prop('crate', -4.8, .45, 5.8, 1.2, .9, 1.2);
prop('crate2', 5.2, .45, -4.6, 1.1, .9, 1.1);

// Doors: physical blockers with simple open/close state.
function makeDoor(name, x, z, w, d, color = mat.wood) {
  const door = box(name, x, 1.5, z, w, 3, d, color, true);
  const data = { type: 'door', object: door, open: false, radius: 1.7, locked: false, key: null, home: door.position.clone(), axis: w > d ? 'x' : 'z' };
  doors.push(data); interactables.push(data); return data;
}
const doorKitchen = makeDoor('kitchenDoor', -8, -1, .3, 2.2); doorKitchen.locked = true; doorKitchen.key = 'مفتاح المطبخ';
const doorSister = makeDoor('sisterDoor', 8, 9.5, 2.2, .3); doorSister.locked = true; doorSister.key = 'مفتاح غرفة أختك';
const doorBasement = makeDoor('basementDoor', -11, 7, 2.2, .3); doorBasement.locked = true; doorBasement.key = 'مفتاح القبو';
const exitDoor = makeDoor('exitDoor', 0, -12.75, 3, .35); exitDoor.locked = true; exitDoor.key = 'مفتاح الخروج';

function setDoorOpen(d, open = true) {
  d.open = open;
  if (open) {
    d.object.visible = false;
    const c = colliders.find(c => c.obj === d.object); if (c) c.disabled = true;
  } else {
    d.object.visible = true;
    const c = colliders.find(c => c.obj === d.object); if (c) c.disabled = false;
  }
}

// ---------- Lighting ----------
scene.add(new THREE.HemisphereLight(0x435465, 0x050505, .38));
const moon = new THREE.DirectionalLight(0x9fb7d1, .62); moon.position.set(-8, 12, 4); moon.castShadow = true; scene.add(moon);
function lamp(x, y, z, intensity = 1.1) {
  const l = new THREE.PointLight(0xd7a15b, intensity, 7); l.position.set(x, y, z); l.castShadow = true; scene.add(l);
  const b = new THREE.Mesh(new THREE.SphereGeometry(.09, 10, 8), new THREE.MeshStandardMaterial({ color: 0xffc76b, emissive: 0x6b3e12, emissiveIntensity: 1.4 })); b.position.copy(l.position); scene.add(b);
}
lamp(-12, 2.1, -9); lamp(11, 2.1, -9); lamp(-4, 2.1, 9); lamp(12, 2.1, 10); lamp(0, 2.1, 5); lamp(0, 2.1, -11);

const flashlight = new THREE.SpotLight(0xfff1d0, 3.6, 17, Math.PI / 7, .45, 1.2);
flashlight.castShadow = true; scene.add(flashlight); scene.add(flashlight.target);

// ---------- Items ----------
function item(name, label, x, z, color = 0xcaa34a, size = .32) {
  const g = new THREE.Group();
  const m = new THREE.Mesh(new THREE.BoxGeometry(size, .18, .18), new THREE.MeshStandardMaterial({ color, roughness: .5, metalness: .35 }));
  g.add(m); g.position.set(x, .35, z); scene.add(g);
  const it = { type: 'item', name, label, object: g, radius: 1.15 };
  interactables.push(it); return it;
}
item('kitchenKey', 'مفتاح المطبخ', -12, -5, 0xa88642);
item('sisterKey', 'مفتاح غرفة أختك', 10.8, -3, 0xb18d43);
item('fuse', 'فيوز المولد', -11, 10.5, 0xd8d8c5);
item('basementKey', 'مفتاح القبو', 4.5, 10.2, 0xb18d43);
item('pliers', 'كماشة', -3, 9, 0x7c858b);
item('exitKey', 'مفتاح الخروج', 0, -8.5, 0xcaa34a);
item('battery', 'بطارية', 12, 5.3, 0x657f50);

const generator = box('generator', 5, .8, -10, 1.5, 1.6, 1.05, mat.metal, true);
interactables.push({ type: 'generator', object: generator, radius: 1.7 });

// ---------- Sister ----------
const sister = new THREE.Group();
const sbody = new THREE.Mesh(new THREE.CapsuleGeometry(.25, .7, 6, 10), new THREE.MeshStandardMaterial({ color: 0x39424c, roughness: 1 }));
sbody.position.y = .65; sister.add(sbody);
const sh = new THREE.Mesh(new THREE.SphereGeometry(.27, 16, 12), mat.skin); sh.position.y = 1.3; sister.add(sh);
sister.position.set(10.5, 0, 10); scene.add(sister);
sister.visible = false;

// ---------- Hide spots ----------
function hideSpot(name, x, z, w = 1.6, d = .9) {
  prop(name, x, 1.15, z, w, 2.3, d, mat.wood2);
  hideSpots.push({ name, position: new THREE.Vector3(x, 0, z), radius: 1.8 });
}
hideSpot('خزانة الاختباء', -12.2, 4.8, 1.4, 1.0);
hideSpot('خزانة الصالة', 4.8, 1.8, 1.4, 1.0);

// ---------- Mary ----------
const mary = new THREE.Group();
const robe = new THREE.Mesh(new THREE.ConeGeometry(.76, 2.2, 18), mat.cloth); robe.position.y = 1.05; robe.castShadow = true; mary.add(robe);
const shawl = new THREE.Mesh(new THREE.SphereGeometry(.68,18,12), new THREE.MeshStandardMaterial({color:0x171719,roughness:1})); shawl.scale.set(1,.75,.72); shawl.position.set(0,1.65,-.05); shawl.castShadow=true; mary.add(shawl);
const head = new THREE.Mesh(new THREE.SphereGeometry(.46, 18, 14), mat.skin); head.position.y = 2.38; head.castShadow = true; mary.add(head);
const hair = new THREE.Mesh(new THREE.SphereGeometry(.56, 18, 14), new THREE.MeshStandardMaterial({ color: 0x77736c, roughness: 1 })); hair.scale.set(1, 1.4, .8); hair.position.set(0, 2.43, -.08); mary.add(hair);
for (const sx of [-.18, .18]) { const eye = new THREE.Mesh(new THREE.SphereGeometry(.055, 10, 8), new THREE.MeshStandardMaterial({color:0x7b0000,emissive:0xff1010,emissiveIntensity:2.8,roughness:.3})); eye.position.set(sx, 2.4, .43); mary.add(eye); }
for (const sx of [-.48,.48]) { const hand=new THREE.Mesh(new THREE.SphereGeometry(.13,10,8),mat.skin); hand.position.set(sx,1.05,.05); hand.scale.set(.8,1.25,.7); hand.castShadow=true; mary.add(hand); }
const cane = box('cane', .55, .8, 0, .08, 1.8, .08, mat.wood2, false); cane.rotation.z = -.12; mary.add(cane);
mary.position.set(-10, 0, -7); scene.add(mary);

const patrol = [
  new THREE.Vector3(-10, 0, -7), new THREE.Vector3(-10, 0, -11), new THREE.Vector3(5, 0, -11),
  new THREE.Vector3(12, 0, -5), new THREE.Vector3(12, 0, 5), new THREE.Vector3(5, 0, 10),
  new THREE.Vector3(-4, 0, 10), new THREE.Vector3(-12, 0, 9), new THREE.Vector3(-12, 0, 1)
];

// ---------- HUD ----------
const objectiveEl = document.getElementById('objective');
const itemsEl = document.getElementById('items');
const statusEl = document.getElementById('status');
const messageEl = document.getElementById('message');
const fadeEl = document.getElementById('fade');
const staminaEl = document.getElementById('staminaFill');
const batteryEl = document.getElementById('batteryFill');
const hideEl = document.getElementById('hideHint');

function say(text, ms = 2200) { messageEl.textContent = text; messageEl.style.opacity = '1'; clearTimeout(say.timer); say.timer = setTimeout(() => messageEl.style.opacity = '0', ms); }
function setObjective(text) { objective = text; objectiveEl.textContent = 'الهدف: ' + text; }
function updateInventory() { itemsEl.textContent = 'الأدوات: ' + (inventory.length ? inventory.join('، ') : 'لا شيء'); }
function addItem(label) { if (!inventory.includes(label)) { inventory.push(label); updateInventory(); } }
function has(label) { return inventory.includes(label); }

function collides(pos) {
  if (hiding) return false;
  const r = crouch ? .28 : .34;
  for (const c of colliders) {
    if (c.disabled) continue;
    if (pos.x + r > c.min.x && pos.x - r < c.max.x && pos.z + r > c.min.z && pos.z - r < c.max.z) return true;
  }
  return false;
}
function movePlayer(dx, dz) {
  const p = camera.position.clone(); p.x += dx;
  if (!collides(p)) camera.position.x = p.x;
  p.z = camera.position.z + dz;
  if (!collides(p)) camera.position.z = p.z;
}

function look(dx, dy) {
  yaw -= dx * .0024; pitch -= dy * .0022;
  pitch = Math.max(-1.35, Math.min(1.35, pitch));
  camera.rotation.y = yaw; camera.rotation.x = pitch;
}

// ---------- Interaction ----------
function nearestInteract() {
  let best = null, bestD = 999;
  for (const it of interactables) {
    if (!it.object || !it.object.parent || !it.object.visible) continue;
    const p = it.object.getWorldPosition(new THREE.Vector3());
    const d = distXZ(camera.position, p);
    if (d < it.radius && d < bestD) { bestD = d; best = it; }
  }
  return best;
}

function nearestHide() {
  let best = null, bestD = 999;
  for (const h of hideSpots) { const d = distXZ(camera.position, h.position); if (d < h.radius && d < bestD) { bestD = d; best = h; } }
  return best;
}

function interact() {
  if (gameOver) return;
  if (hiding) { exitHide(); return; }
  const h = nearestHide();
  if (h && !nearestInteract()) { enterHide(h); return; }
  const it = nearestInteract();
  if (!it) { say('لا يوجد شيء يمكن التفاعل معه هنا'); return; }

  if (it.type === 'item') {
    addItem(it.label); say('حصلت على: ' + it.label);
    scene.remove(it.object); it.object.visible = false;
    const i = interactables.indexOf(it); if (i >= 0) interactables.splice(i, 1);
    if (it.name === 'sisterKey') setObjective('افتح غرفة أختك');
    if (it.name === 'fuse') setObjective('شغّل المولد');
    if (it.name === 'basementKey') setObjective('ادخل القبو وابحث عن سر الداية');
    if (it.name === 'exitKey') setObjective('جهز طريق الهروب');
    return;
  }
  if (it.type === 'door') {
    if (it === exitDoor) {
      if (sisterFound && generatorOn && has('مفتاح الخروج')) { setDoorOpen(it, true); exitOpen = true; setObjective('اخرج من البيت'); say('الباب انفتح... اهرب!', 3000); }
      else say(!sisterFound ? 'لن أخرج قبل أن أجد أختي.' : !generatorOn ? 'الباب يحتاج إلى الكهرباء.' : 'أحتاج مفتاح الخروج.');
      return;
    }
    if (it.locked) {
      if (has(it.key)) { it.locked = false; setDoorOpen(it, true); say('فتحت الباب.'); if (it === doorSister) { sister.visible = true; sisterFound = true; setObjective('أوصل أختك إلى باب الخروج'); say('وجدت أختك... لا تتركها وحدها.'); } }
      else say('الباب مقفل. ابحث عن المفتاح.');
    } else setDoorOpen(it, !it.open);
    return;
  }
  if (it.type === 'generator') {
    if (generatorOn) { say('المولد يعمل.'); return; }
    if (has('فيوز المولد')) { generatorOn = true; setObjective(sisterFound ? 'أوصل أختك إلى باب الخروج' : 'اعثر على أختك'); say('عاد التيار... والآن بدأت الداية تتحرك أسرع.'); }
    else say('المولد يحتاج إلى فيوز.');
  }
}

function enterHide(h) {
  hiding = true; crouch = true; running = false; camera.position.x = h.position.x; camera.position.z = h.position.z + .25; camera.position.y = 1.05; hideEl.textContent = 'تفاعل للخروج من الاختباء'; hideEl.style.opacity = '1'; say('اختبأت... لا تتحرك.');
}
function exitHide() { hiding = false; camera.position.y = 1.1; hideEl.style.opacity = '0'; say('خرجت من مخبئك.'); }

// ---------- Mary AI ----------
function maryCanSee() {
  if (hiding) return false;
  const target = camera.position.clone(); target.y = 1.25;
  const origin = mary.position.clone(); origin.y = 1.55;
  const to = target.clone().sub(origin); const d = to.length();
  if (d > 13) return false;
  const dir = to.normalize();
  const fwd = new THREE.Vector3(0, 0, 1).applyQuaternion(mary.quaternion);
  if (fwd.angleTo(dir) > 1.05) return false;
  const ray = new THREE.Raycaster(origin, dir, 0, d);
  const hits = ray.intersectObjects(scene.children, true);
  return !hits.some(h => h.object !== mary && h.object !== camera && h.object.visible && h.object.name === 'wall' && h.distance < d - .3);
}
function emitNoise(amount) { noise = Math.max(noise, amount); lastNoiseAt = performance.now(); }
function updateMary(dt) {
  if (gameOver) return;
  const d = distXZ(mary.position, camera.position);
  if (maryCanSee()) { maryState = 'chase'; maryTarget.copy(camera.position); lastSeenAt = performance.now(); }
  else if (!hiding && noise > .55 && d < 14 && performance.now() - lastNoiseAt < 1200) { maryState = 'investigate'; maryTarget.copy(camera.position); }
  else if (maryState === 'chase' && performance.now() - lastSeenAt > 2500) { maryState = 'investigate'; maryTarget.copy(camera.position); }

  if (maryState === 'patrol' && distXZ(mary.position, patrol[patrolIndex]) < .75) { patrolIndex = (patrolIndex + 1) % patrol.length; maryTarget.copy(patrol[patrolIndex]); }
  if (maryState === 'investigate' && distXZ(mary.position, maryTarget) < .8) { maryState = 'search'; lastSeenAt = performance.now(); }
  if (maryState === 'search' && performance.now() - lastSeenAt > 2500) { maryState = 'patrol'; maryTarget.copy(patrol[patrolIndex]); }
  if (maryState === 'chase' && d < 1.05 && !hiding) { lose(); return; }

  let speed = 1.15;
  if (maryState === 'investigate') speed = 1.8;
  if (maryState === 'chase') speed = generatorOn ? 3.2 : 2.8;
  const dir = new THREE.Vector3(maryTarget.x - mary.position.x, 0, maryTarget.z - mary.position.z);
  if (dir.lengthSq() > .01) {
    dir.normalize(); mary.position.x += dir.x * speed * dt; mary.position.z += dir.z * speed * dt;
    mary.lookAt(mary.position.x + dir.x, mary.position.y, mary.position.z + dir.z);
  }
  statusEl.textContent = maryState === 'chase' ? 'الداية مريم تطاردك!' : maryState === 'investigate' ? 'الداية تحقق في الصوت...' : d < 5 ? 'هناك شيء قريب...' : '';
}

function lose() { gameOver = true; fadeEl.style.opacity = '.92'; say('أمسكت بك الداية مريم — اضغط إعادة اللعب', 999999); document.getElementById('restartBtn').classList.remove('hidden'); }
function win() { gameOver = true; fadeEl.style.opacity = '.8'; say('هربت مع أختك... لكن سر الداية لم ينتهِ.', 999999); document.getElementById('restartBtn').classList.remove('hidden'); }

// ---------- Controls ----------
window.addEventListener('keydown', e => {
  keys.add(e.code);
  if (e.code === 'KeyF') { flashlightOn = !flashlightOn; say(flashlightOn ? 'تم تشغيل الكشاف' : 'تم إطفاء الكشاف'); }
  if (e.code === 'KeyC') crouch = true;
  if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') running = true;
  if (e.code === 'KeyE') interact();
  if (e.code === 'KeyR' && gameOver) location.reload();
});
window.addEventListener('keyup', e => { keys.delete(e.code); if (e.code === 'KeyC') crouch = false; if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') running = false; });
renderer.domElement.addEventListener('click', () => { if (innerWidth > 800 && !gameOver) renderer.domElement.requestPointerLock?.(); });
document.addEventListener('mousemove', e => { if (document.pointerLockElement === renderer.domElement) look(e.movementX, e.movementY); });

// Mobile controls.
const touchLayer = document.getElementById('touch');
const joy = document.getElementById('joy');
const knob = document.getElementById('knob');
const isTouchDevice = ('ontouchstart' in window) || navigator.maxTouchPoints > 0;
if (isTouchDevice) {
  touchLayer.classList.remove('hidden');
  joy.addEventListener('pointerdown', e => { joy.setPointerCapture(e.pointerId); joy.dataset.active = '1'; });
  joy.addEventListener('pointermove', e => {
    if (joy.dataset.active !== '1') return;
    const r = joy.getBoundingClientRect(); const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    let x = e.clientX - cx, y = e.clientY - cy; const max = 42, len = Math.hypot(x, y); if (len > max) { x *= max / len; y *= max / len; }
    knob.style.transform = `translate(${x}px,${y}px)`; touchMove.x = x / max; touchMove.y = y / max;
  });
  const resetJoy = () => { joy.dataset.active = '0'; touchMove.x = 0; touchMove.y = 0; knob.style.transform = 'translate(0,0)'; };
  joy.addEventListener('pointerup', resetJoy); joy.addEventListener('pointercancel', resetJoy);
  document.getElementById('runBtn').addEventListener('pointerdown', () => running = true); document.getElementById('runBtn').addEventListener('pointerup', () => running = false);
  document.getElementById('crouchBtn').addEventListener('click', () => crouch = !crouch);
  document.getElementById('interactBtn').addEventListener('click', interact);
  renderer.domElement.addEventListener('touchstart', e => { if (e.touches.length === 1 && e.touches[0].clientX > innerWidth * .35) touchLook = { x: e.touches[0].clientX, y: e.touches[0].clientY, id: e.touches[0].identifier }; }, { passive: true });
  renderer.domElement.addEventListener('touchmove', e => { if (!touchLook) return; const t = [...e.touches].find(t => t.identifier === touchLook.id); if (!t) return; look(t.clientX - touchLook.x, t.clientY - touchLook.y); touchLook.x = t.clientX; touchLook.y = t.clientY; }, { passive: true });
  renderer.domElement.addEventListener('touchend', () => touchLook = null, { passive: true });
}

async function lockLandscape() {
  try {
    if (screen.orientation?.lock) await screen.orientation.lock('landscape');
    if (document.documentElement.requestFullscreen && !document.fullscreenElement) { await document.documentElement.requestFullscreen().catch(()=>{}); }
    if (screen.orientation?.lock) await screen.orientation.lock('landscape');
  } catch (e) {}
}

function start() {
  lockLandscape();
  document.documentElement.style.setProperty('--game-orientation', 'landscape'); document.body.classList.add('game-landscape');
  document.getElementById('menu').classList.add('hidden'); document.getElementById('game').classList.remove('hidden');
  setObjective('اعثر على أختك'); updateInventory(); say('البيت هادئ... أكثر مما ينبغي.', 3200);
  if (innerWidth > 800) renderer.domElement.requestPointerLock?.();
}
document.getElementById('newGame').onclick = start;
document.getElementById('continueGame').onclick = start;
document.getElementById('howTo').onclick = () => document.getElementById('howto').classList.remove('hidden');
document.getElementById('back').onclick = () => document.getElementById('howto').classList.add('hidden');
document.getElementById('restartBtn').onclick = () => location.reload();

function animate() {
  requestAnimationFrame(animate);
  const dt = Math.min(clock.getDelta(), .05);
  if (!gameOver) {
    let sx = 0, sz = 0;
    if (keys.has('KeyW')) sz -= 1; if (keys.has('KeyS')) sz += 1; if (keys.has('KeyA')) sx -= 1; if (keys.has('KeyD')) sx += 1;
    sx += touchMove.x; sz += touchMove.y;
    // Forward is negative Z in the camera's local space.
    // The old code applied `sz` directly to the forward vector, which inverted W/S.
    // Convert input so W / joystick-up moves forward and S / joystick-down moves backward.
    const forwardInput = -sz;
    const moving = Math.abs(sx) + Math.abs(sz) > .05;
    if (moving && !hiding) {
      const len = Math.hypot(sx, sz); sx /= len; sz /= len;
      if (running && stamina > 1 && !crouch) { stamina = Math.max(0, stamina - dt * 24); emitNoise(1); }
      else { stamina = Math.min(100, stamina + dt * 13); emitNoise(crouch ? .15 : .35); }
      const speed = (running && stamina > 0 && !crouch ? 3.55 : 1.8) * (crouch ? .48 : 1);
      const f = new THREE.Vector3(0, 0, -1).applyAxisAngle(Y, yaw); const r = new THREE.Vector3(1, 0, 0).applyAxisAngle(Y, yaw);
      movePlayer((r.x * sx + f.x * forwardInput) * speed * dt, (r.z * sx + f.z * forwardInput) * speed * dt);
      noiseTimer = .25;
    } else { stamina = Math.min(100, stamina + dt * 18); }
    noise = Math.max(0, noise - dt * 1.8);
    if (noiseTimer > 0) noiseTimer -= dt;
    camera.position.y += ((hiding ? 1.05 : crouch ? 1.12 : 1.65) - camera.position.y) * Math.min(1, dt * 12);
    if (flashlightOn) battery = Math.max(0, battery - dt * .45); else battery = Math.min(100, battery + dt * .05);
    if (battery <= 0) flashlightOn = false;
    flashlight.visible = flashlightOn && battery > 0;
    flashlight.position.copy(camera.position); flashlight.target.position.copy(camera.position).add(new THREE.Vector3(0, 0, -1).applyQuaternion(camera.quaternion).multiplyScalar(8));
    updateMary(dt);
    if (exitOpen && distXZ(camera.position, new THREE.Vector3(0, 0, -13)) < 2.2) win();
    staminaEl.style.width = stamina + '%'; batteryEl.style.width = battery + '%';
  }
  renderer.render(scene, camera);
}
animate();

addEventListener('resize', () => { camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); renderer.setSize(innerWidth, innerHeight); });
addEventListener('orientationchange', () => setTimeout(() => { camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); renderer.setSize(innerWidth, innerHeight); }, 120));
