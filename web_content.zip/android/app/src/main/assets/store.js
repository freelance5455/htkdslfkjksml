/* MegaIA — armazenamento das conversas no aparelho.
   Usa IndexedDB (aguenta fotos, vídeos e jogos). Se ele não existir, usa localStorage só com texto. */
(function(){
 'use strict';
 var db=null,SC=(window.MegaAuth?window.MegaAuth.scope():''),LS='megaia_convs_v2'+SC;
 function lsAll(){try{return JSON.parse(localStorage.getItem(LS)||'[]')}catch(_){return []}}
 function lsSave(a){localStorage.setItem(LS,JSON.stringify(a))}
 function rq(r){return new Promise(function(res,rej){r.onsuccess=function(){res(r.result)};r.onerror=function(){rej(r.error)}})}
 function done(t){return new Promise(function(res,rej){t.oncomplete=function(){res()};t.onerror=function(){rej(t.error)};t.onabort=function(){rej(t.error||new Error('abortado'))}})}
 function meta(c){return {id:c.id,title:c.title,updated:c.updated}}
 function byNewest(a,b){return b.updated-a.updated}
 function open(){return new Promise(function(res){
  if(db){res(true);return}
  if(!window.indexedDB){res(false);return}
  var r;try{r=indexedDB.open('megaia'+SC,1)}catch(_){res(false);return}
  r.onupgradeneeded=function(){var d=r.result;
   if(!d.objectStoreNames.contains('convs'))d.createObjectStore('convs',{keyPath:'id'});
   if(!d.objectStoreNames.contains('msgs')){var s=d.createObjectStore('msgs',{keyPath:'id',autoIncrement:true});s.createIndex('cid','cid',{unique:false})}};
  r.onsuccess=function(){db=r.result;db.onversionchange=function(){db.close();db=null};db.onclose=function(){db=null};res(true)};
  r.onerror=function(){res(false)};r.onblocked=function(){res(false)}})}
 async function list(){
  if(!db)return lsAll().map(meta).sort(byNewest);
  var t=db.transaction('convs','readonly');var all=await rq(t.objectStore('convs').getAll());
  return all.map(meta).sort(byNewest)}
 async function putConv(c){
  if(!db){var a=lsAll(),i=a.findIndex(function(x){return x.id===c.id});
   var rec={id:c.id,title:c.title,updated:c.updated,hist:c.hist,msgs:i>=0?a[i].msgs:[]};
   if(i>=0)a[i]=rec;else a.push(rec);lsSave(a);return}
  var t=db.transaction('convs','readwrite');var d=done(t);t.objectStore('convs').put(c);await d}
 async function addMsg(cid,m){
  if(!db){var a=lsAll(),c=a.find(function(x){return x.id===cid});
   if(!c){c={id:cid,title:'Conversa',updated:Date.now(),hist:[],msgs:[]};a.push(c)}
   if(m.id===undefined)m.id=Date.now()*1000+Math.floor(Math.random()*1000);
   var slim={id:m.id,who:m.who,text:m.text,fnames:m.fnames,game:m.game};
   var k=c.msgs.findIndex(function(x){return x.id===m.id});if(k>=0)c.msgs[k]=slim;else c.msgs.push(slim);
   try{lsSave(a)}catch(_){delete slim.game;lsSave(a)}
   return m.id}
  m.cid=cid;var t=db.transaction('msgs','readwrite'),os=t.objectStore('msgs');var d=done(t);
  var req=(m.id===undefined)?os.add(m):os.put(m);var key=await rq(req);await d;m.id=key;return key}
 async function load(id){
  if(!db){var c=lsAll().find(function(x){return x.id===id});if(!c)return null;
   return {conv:{id:c.id,title:c.title,updated:c.updated,hist:c.hist||[]},msgs:(c.msgs||[]).slice()}}
  var t=db.transaction(['convs','msgs'],'readonly');var d=done(t);
  var r1=rq(t.objectStore('convs').get(id)),r2=rq(t.objectStore('msgs').index('cid').getAll(IDBKeyRange.only(id)));
  var cv=await r1,ms=await r2;await d;if(!cv)return null;
  ms.sort(function(a,b){return a.id-b.id});return {conv:cv,msgs:ms}}
 async function del(id){
  if(!db){lsSave(lsAll().filter(function(x){return x.id!==id}));return}
  var t=db.transaction(['convs','msgs'],'readwrite');var d=done(t);
  t.objectStore('convs').delete(id);var ms=t.objectStore('msgs');
  var cur=ms.index('cid').openKeyCursor(IDBKeyRange.only(id));
  cur.onsuccess=function(){var c=cur.result;if(c){ms.delete(c.primaryKey);c.continue()}};
  await d}
 async function search(q){
  q=String(q||'').toLowerCase().trim();if(!q)return [];
  function hit(m){return ((m.text||'')+' '+(m.fnames||[]).join(' ')).toLowerCase().indexOf(q)>=0}
  if(!db){var out=[];lsAll().forEach(function(c){if((c.msgs||[]).some(hit))out.push(c.id)});return out}
  return new Promise(function(res,rej){var t=db.transaction('msgs','readonly'),seen={},cur=t.objectStore('msgs').openCursor();
   cur.onsuccess=function(){var c=cur.result;if(!c){res(Object.keys(seen));return}var m=c.value;if(m.cid&&!seen[m.cid]&&hit(m))seen[m.cid]=1;c.continue()};
   cur.onerror=function(){rej(cur.error)}})}
 window.MegaStore={open:open,list:list,putConv:putConv,addMsg:addMsg,load:load,del:del,search:search,mode:function(){return db?'idb':'ls'}};
})();
