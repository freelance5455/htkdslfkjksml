/* MegaIA — login com Google de verdade.
   O login é feito pelo Android (Credential Manager) e entrega um ID token assinado pelo Google.
   O WebView nunca abre a tela de login do Google (o Google bloqueia isso). */
(function(){
 'use strict';
 var KEY='megaia_user',SKEY='megaia_session',LEG='megaia_legacy_owner';
 function $(i){return document.getElementById(i)}
 function jwt(t){try{var p=String(t).split('.')[1].replace(/-/g,'+').replace(/_/g,'/');while(p.length%4)p+='=';
  return JSON.parse(decodeURIComponent(escape(atob(p))))}catch(_){return null}}
 function rd(k){try{return JSON.parse(localStorage.getItem(k)||'null')}catch(_){return null}}
 var user=rd(KEY);
 function scope(){ // conversas de cada conta ficam separadas; a 1ª conta herda as conversas antigas do aparelho
  if(!user)return '';var l=localStorage.getItem(LEG);
  if(!l){try{localStorage.setItem(LEG,user.sub)}catch(_){}return ''}
  return l===user.sub?'':'_'+String(user.sub).replace(/[^A-Za-z0-9]/g,'')}
 function session(){var s=rd(SKEY);return s&&s.token&&s.exp>Date.now()?s.token:''}
 function authHeaders(){var t=session();return t?{Authorization:'Bearer '+t}:{}}
 async function exchange(base){ // troca o ID token do Google por uma sessão do servidor MegaIA (se houver servidor)
  if(!base||!user||!user.idToken)return {ok:false,why:'sem servidor ou token'};
  var p=jwt(user.idToken);if(p&&p.exp*1000<Date.now()-60000)return {ok:false,why:'expired'};
  try{var r=await fetch(base+'/api/auth/google',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({idToken:user.idToken})});
   if(r.status===404||r.status===501)return {ok:false,why:'no-auth-on-server'};
   var d=await r.json().catch(function(){return null});
   if(!r.ok||!d||!d.session)return {ok:false,why:(d&&d.error)||('HTTP '+r.status)};
   localStorage.setItem(SKEY,JSON.stringify({token:d.session,exp:Date.now()+(d.expiresIn||2592000)*1000}));
   return {ok:true}}catch(e){return {ok:false,why:'rede'}}}
 var msgs={cancelled:'Login cancelado.',
  no_account:'Nenhuma conta Google neste aparelho. Adicione uma em Configurações do Android > Contas e tente de novo.',
  not_configured:'Falta configurar o Web Client ID em res/values/google.xml (veja LOGIN-GOOGLE-LEIA-ME.txt).',
  unexpected_credential:'O Google devolveu um tipo de credencial inesperado.'};
 function showErr(code){var m=msgs[code]||('Não foi possível entrar: '+String(code).replace(/^error:/,''));
  var e=$('loginMsg');if(e)e.textContent=m;var b=$('googleBtn');if(b){b.disabled=false;b.textContent='Entrar com Google'}}
 window.onGoogleLogin=function(json){
  try{var g=JSON.parse(json),p=jwt(g.idToken);if(!p||!p.sub)throw new Error('token inválido');
   user={sub:p.sub,email:g.email||p.email||'',name:g.name||p.name||'',picture:g.picture||p.picture||'',idToken:g.idToken,at:Date.now()};
   localStorage.setItem(KEY,JSON.stringify(user));localStorage.removeItem(SKEY);
   location.reload()}catch(e){showErr('error:'+e.message)}};
 window.onGoogleError=showErr;
 function signIn(){var e=$('loginMsg');if(e)e.textContent='';
  if(!window.MegaGoogle){showErr('O login com Google funciona no app Android da MegaIA.');return}
  if(!window.MegaGoogle.configured()){showErr('not_configured');return}
  var b=$('googleBtn');if(b){b.disabled=true;b.textContent='Abrindo o Google...'}
  window.MegaGoogle.signIn();
  setTimeout(function(){var b2=$('googleBtn');if(b2&&b2.disabled){b2.disabled=false;b2.textContent='Entrar com Google'}},60000)}
 function signOut(){try{if(window.MegaGoogle)window.MegaGoogle.signOut()}catch(_){}
  localStorage.removeItem(KEY);localStorage.removeItem(SKEY);location.reload()}
 window.MegaAuth={user:function(){return user},uid:function(){return user?user.sub:''},scope:scope,session:session,authHeaders:authHeaders,exchange:exchange,signOut:signOut,signIn:signIn};
 function init(){
  var gate=$('loginGate'),btn=$('accountBtn');
  if(!user){if(gate)gate.classList.remove('hidden');if($('googleBtn'))$('googleBtn').onclick=signIn;if(btn)btn.textContent='Entrar com Google';if(btn)btn.onclick=function(){if(gate)gate.classList.remove('hidden')};return}
  if(gate)gate.classList.add('hidden');
  if(btn){btn.textContent=user.name||user.email||'Minha conta';
   btn.onclick=function(){var m=$('accountModal');if(!m)return;
    $('accName').textContent=user.name||'Conta Google';$('accEmail').textContent=user.email;
    var im=$('accPic');if(user.picture){im.src=user.picture;im.classList.remove('hidden')}else im.classList.add('hidden');
    $('accServer').textContent=session()?'Servidor MegaIA: conectado à sua conta.':'Servidor MegaIA: sem sessão (só é necessária se você usa servidor).';
    m.classList.remove('hidden')}}
  if($('closeAccount'))$('closeAccount').onclick=function(){$('accountModal').classList.add('hidden')};
  if($('logoutBtn'))$('logoutBtn').onclick=signOut;
  var base='';try{base=(localStorage.getItem('megaia_api')||'').trim()}catch(_){}
  if(base&&!session())exchange(base.replace(/\/+$/,''));
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
