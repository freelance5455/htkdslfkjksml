
const SUPABASE_URL='https://iflqwjnyfgxkhfmsrqlq.supabase.co';const SUPABASE_ANON_KEY='sb_publishable_vQ8ToX3le-8zHi38EOdgUg_KjTMMnIL';
let sb=null,user=null,profile=null,items=[],trash=false,query='',viewOwnerId=null,viewOwnerName='';
const esc=s=>String(s??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');const today=()=>new Date().toISOString().slice(0,10);const monthKey=()=>today().slice(0,7);const money=n=>Number(n||0).toLocaleString(undefined,{maximumFractionDigits:2});
function configured(){return SUPABASE_URL.startsWith('http')&&SUPABASE_ANON_KEY.length>20}
function configure(){let u=prompt('Supabase Project URL',SUPABASE_URL.startsWith('http')?SUPABASE_URL:'');if(!u)return;let k=prompt('Supabase anon/publishable key',SUPABASE_ANON_KEY.startsWith('YOUR_')?'':SUPABASE_ANON_KEY);if(!k)return;localStorage.setItem('DPM_SUPABASE_URL',u.trim());localStorage.setItem('DPM_SUPABASE_ANON_KEY',k.trim());location.reload()}
function resetRedirectUrl(){return (SUPABASE_URL||'').replace(/\/$/,'')+'/functions/v1/password-reset'}
function showLogin(msg=''){document.getElementById('root').innerHTML=`<div class="login"><div class="card"><h1>Daily Progress Manager</h1><div class="muted" style="margin-bottom:18px">Secure account login</div>${msg?`<div class="error">${esc(msg)}</div>`:''}<form id="login"><div class="field"><label>Email</label><input name="email" type="email" required autocomplete="username"></div><div class="field"><label>Password</label><input name="password" type="password" required autocomplete="current-password"></div><button class="primary" style="width:100%">Login</button></form><div style="margin-top:12px;text-align:center"><button type="button" onclick="forgotPassword()">Forgot password?</button></div><div style="margin-top:14px;text-align:center"><button type="button" onclick="configure()">Configure connection</button></div>${!configured()?'<p class="muted" style="font-size:12px;margin-top:14px">Connect this app to your Supabase project before logging in.</p>':''}</div></div>`;document.getElementById('login').onsubmit=login}
async function login(e){e.preventDefault();if(!configured())return showLogin('The app is not connected to Supabase yet. Follow SETUP.md.');let f=new FormData(e.target);let {error}=await sb.auth.signInWithPassword({email:f.get('email'),password:f.get('password')});if(error)return showLogin(error.message);await boot()}
async function forgotPassword(){
  if(!configured())return showLogin('Configure Supabase first.');
  document.querySelectorAll('.modal-bg').forEach(x=>x.remove());
  const d=overlay(`<form class="modal" id="forgotForm" onsubmit="return false" style="max-width:460px"><h2>Forgot Password</h2><p class="muted">Enter the email address for the account. We will send a password-reset link.</p><div id="forgotError" class="error" style="display:none"></div><div id="forgotSuccess" style="display:none;color:#166534;background:#dcfce7;padding:9px;border-radius:8px;margin-bottom:10px"></div><div class="field"><label>Email</label><input name="email" type="email" required autocomplete="email"></div><div class="actions"><button type="button" id="cancelForgot">Cancel</button><button type="button" class="primary" id="sendForgot">Send reset link</button></div></form>`);
  d.querySelector('#cancelForgot').onclick=()=>d.remove();
  d.querySelector('#sendForgot').onclick=async()=>{
    const btn=d.querySelector('#sendForgot'),err=d.querySelector('#forgotError'),ok=d.querySelector('#forgotSuccess');
    const email=String(d.querySelector('[name="email"]').value||'').trim();
    err.style.display='none';ok.style.display='none';
    if(!email){err.textContent='Enter the account email address.';err.style.display='block';return;}
    btn.disabled=true;btn.textContent='Sending...';
    const {error}=await sb.auth.resetPasswordForEmail(email,{redirectTo:resetRedirectUrl()});
    if(error){err.textContent=error.message;err.style.display='block';btn.disabled=false;btn.textContent='Send reset link';return;}
    ok.textContent='Reset email sent. Check your inbox (and spam/junk folder) and open the reset link on this device.';ok.style.display='block';btn.textContent='Sent';
  };
}

function showPasswordRecovery(){document.getElementById('root').innerHTML=`<div class="login"><div class="card"><h1>Reset Password</h1><div class="muted" style="margin-bottom:18px">Choose a new password for your account.</div><form id="recoveryForm"><div id="recoveryError" class="error" style="display:none"></div><div class="field"><label>New password</label><input name="password" type="password" minlength="8" required autocomplete="new-password"></div><div class="field"><label>Confirm new password</label><input name="confirm" type="password" minlength="8" required autocomplete="new-password"></div><button class="primary" style="width:100%" id="recoveryBtn">Set new password</button></form></div></div>`;document.getElementById('recoveryForm').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);const password=String(f.get('password')||'');const confirm=String(f.get('confirm')||'');const err=document.getElementById('recoveryError');const btn=document.getElementById('recoveryBtn');err.style.display='none';if(password.length<8){err.textContent='Password must be at least 8 characters.';err.style.display='block';return}if(password!==confirm){err.textContent='The passwords do not match.';err.style.display='block';return}btn.disabled=true;btn.textContent='Saving...';const {error}=await sb.auth.updateUser({password});if(error){err.textContent=error.message;err.style.display='block';btn.disabled=false;btn.textContent='Set new password';return}await sb.auth.signOut();showLogin('Password reset successfully. Please log in with your new password.')}}
async function handleRecovery(){
  const hashRaw=location.hash.replace(/^#/,'');
  const queryRaw=location.search.replace(/^\?/,'');
  const raw=hashRaw||queryRaw;
  if(!raw)return false;
  const p=new URLSearchParams(raw);
  const access=p.get('access_token');
  const refreshToken=p.get('refresh_token');
  const tokenHash=p.get('token_hash');
  const type=p.get('type');
  if(p.get('error_code')||p.get('error_description')){
    const msg=p.get('error_description')||'Password recovery link is invalid or expired.';
    history.replaceState(null,'',location.pathname);
    showLogin(msg);
    return true;
  }
  if(tokenHash&&(type==='recovery'||type==='')){
    const verified=await sb.auth.verifyOtp({token_hash:tokenHash,type:'recovery'});
    if(verified.error||!verified.data){
      history.replaceState(null,'',location.pathname);
      showLogin((verified.error&&verified.error.message)||'The password reset link could not be verified. It may have expired or already been used.');
      return true;
    }
    const session=verified.data.session||verified.data;
    const accessToken=session&&session.access_token;
    const refreshToken2=session&&session.refresh_token;
    if(!accessToken){
      history.replaceState(null,'',location.pathname);
      showLogin('The password reset link was verified, but no recovery session was returned.');
      return true;
    }
    await sb.auth.importSession(accessToken,refreshToken2||null);
    history.replaceState(null,'',location.pathname);
    showPasswordRecovery();
    return true;
  }
  if(access&&refreshToken&&(type==='recovery'||type==='signup'||type==='')){
    const imported=await sb.auth.importSession(access,refreshToken);
    if(imported.error){
      history.replaceState(null,'',location.pathname);
      showLogin(imported.error.message||'The password reset link could not be opened.');
      return true;
    }
    history.replaceState(null,'',location.pathname);
    showPasswordRecovery();
    return true;
  }
  return false;
}

function showOwnPasswordModal(){document.querySelectorAll('.modal-bg').forEach(x=>x.remove());const d=overlay(`<form class="modal" id="ownPasswordForm" onsubmit="return false"><h2>Change My Password</h2><p class="muted">Change your own account password.</p><div id="ownPasswordError" class="error" style="display:none"></div><div class="grid"><label>Current password<input name="current" type="password" required autocomplete="current-password"></label><label>New password<input name="password" type="password" minlength="8" required autocomplete="new-password"></label><label style="grid-column:1/-1">Confirm new password<input name="confirm" type="password" minlength="8" required autocomplete="new-password"></label></div><div class="actions"><button type="button" id="cancelOwnPassword">Cancel</button><button type="button" class="primary" id="saveOwnPassword">Change Password</button></div></form>`);d.querySelector('#cancelOwnPassword').onclick=()=>d.remove();d.querySelector('#saveOwnPassword').onclick=async()=>{const b=d.querySelector('#saveOwnPassword'),e=d.querySelector('#ownPasswordError');const current=String(d.querySelector('[name="current"]').value||'');const password=String(d.querySelector('[name="password"]').value||'');const confirm=String(d.querySelector('[name="confirm"]').value||'');e.style.display='none';if(password.length<8){e.textContent='New password must be at least 8 characters.';e.style.display='block';return}if(password!==confirm){e.textContent='The new passwords do not match.';e.style.display='block';return}if(current===password){e.textContent='New password must be different from current password.';e.style.display='block';return}b.disabled=true;b.textContent='Changing...';const {error}=await sb.auth.updateUser({password,current_password:current});if(error){e.textContent=error.message;e.style.display='block';b.disabled=false;b.textContent='Change Password';return}d.remove();alert('Your password was changed successfully.')}}
async function boot(){let r=await sb.auth.getUser();user=r.data.user;if(!user)return showLogin();let p=await sb.from('profiles').select('*').eq('id',user.id).single();if(p.error){await sb.auth.signOut();return showLogin('Your account profile has not been created by an administrator.')}profile=p.data;await loadItems();render()}
async function loadItems(){let q=sb.from('items').select('*').order('created_at',{ascending:false});const ownerToLoad=(profile.role==='admin'&&viewOwnerId)?viewOwnerId:user.id;q=q.eq('owner_id',ownerToLoad);if(!trash)q=q.eq('deleted',false);else q=q.eq('deleted',true);let r=await q;if(r.error)return alert(r.error.message);items=r.data||[]}
function mtdFor(x,ym=monthKey()){return (x.daily_progress||[]).filter(p=>p.date.startsWith(ym)).reduce((s,p)=>s+(+p.given||0),0)}
function statusFor(x){
  let ym=monthKey();
  let monthlyVisits=(x.daily_progress||[]).filter(d=>String(d.date||'').startsWith(ym)).reduce((n,d)=>n+(+d.visits_count||(d.visited?1:0)),0);
  return monthlyVisits>=5?'Serviced':'Unserviced';
}
function searchTextFor(x){return [x.name,x.number,x.location,x.personal_number,statusFor(x)].filter(Boolean).join(' ').toLowerCase()}
function openBalance(){try{document.querySelectorAll('.modal-bg').forEach(x=>x.remove());window.balanceTab='entries';window.balanceItemId='';history.replaceState(null,'',location.pathname+location.search+'#balance');renderBalance()}catch(e){console.error(e);document.getElementById('root').innerHTML='<div class="app"><div class="card"><h2>Balance</h2><div class="error">Unable to open Balance: '+esc(e&&e.message?e.message:String(e))+'</div><button onclick="openDashboard()">← Dashboard</button></div></div>'}}
function openDashboard(){if(location.hash)history.replaceState(null,'',location.pathname+location.search);render()}
function row(x){let p=(x.daily_progress||[]).find(p=>p.date===today())||{};let ym=monthKey(),monthlyVisits=(x.daily_progress||[]).filter(d=>String(d.date||'').startsWith(ym)).reduce((n,d)=>n+(+d.visits_count||(d.visited?1:0)),0),status=statusFor(x);let canEdit=profile.role==='admin'||x.owner_id===user.id;return `<tr><td><b>${esc(x.name)}</b><br><small>${esc(x.personal_number||'')}</small></td><td>${esc(x.number)||'—'}</td><td>${money(x.float_target)}</td><td>${p.given==null?'—':money(p.given)}</td><td>${money(mtdFor(x))}</td><td>${money((+x.float_target||0)-mtdFor(x))}</td><td>${money((x.daily_progress||[]).reduce((s,p)=>s+(+p.cash_pulls||0),0))}</td><td><span class="badge ${monthlyVisits>=5?'yes':''}">${status}</span></td><td><span class="badge ${(+(p.visits_count||0)>0||p.visited)?'yes':''}">${+p.visits_count||(p.visited?1:0)}</span></td><td>${esc(x.location)||'—'}</td><td>${esc(x.owner_name||'')}</td><td><div class="row-actions">${trash?`<button onclick="restore('${x.id}')">Restore</button><button class="danger" onclick="permanentDelete('${x.id}')">Delete</button>`:`<button onclick="progressModal('${x.id}')">Daily</button><button onclick="historyModal('${x.id}')">History</button>${canEdit?`<button onclick="formModal('${x.id}')">Edit</button>`:''}${profile.role==='admin'?'':' '}${profile.role==='admin'?`<button class="danger" onclick="del('${x.id}')">Delete</button>`:''}`}</div></td></tr>`}
// Explicit global handlers for browser/WebView inline buttons.
window.deleteBankedEntry = deleteBankedEntry;
window.deleteMtnSentEntry = deleteMtnSentEntry;

async function refresh(){await loadItems();render()}
async function viewUserItems(id,name){if(profile.role!=='admin')return;viewOwnerId=id;viewOwnerName=name||'User';trash=false;query='';document.querySelectorAll('.modal-bg').forEach(x=>x.remove());await refresh()}
async function clearOwnerView(){viewOwnerId=null;viewOwnerName='';trash=false;query='';await refresh()}
function render(){
  if(location.hash==='#balance'){renderBalance();return;}
  let active=items.filter(x=>searchTextFor(x).includes(query.toLowerCase()));
  let activeAll=items.filter(x=>!x.deleted);
  let total=activeAll.length,
      givenToday=activeAll.reduce((s,x)=>s+(+((x.daily_progress||[]).find(p=>p.date===today())||{}).given||0),0),
      cashPullsToday=activeAll.reduce((s,x)=>s+(+((x.daily_progress||[]).find(p=>p.date===today())||{}).cash_pulls||0),0),
      givenMTD=activeAll.reduce((s,x)=>s+mtdFor(x),0),
      visited=activeAll.filter(x=>(x.daily_progress||[]).some(p=>p.date===today()&&((+p.visits_count||0)>0||p.visited))).length,
      ym=monthKey(),
      monthVisited=activeAll.reduce((s,x)=>s+(x.daily_progress||[]).filter(p=>p.date.startsWith(ym)&&((+p.visits_count||0)>0||p.visited)).length,0),
      visited5=activeAll.filter(x=>(x.daily_progress||[]).filter(p=>p.date.startsWith(ym)).reduce((n,p)=>n+(+p.visits_count||(p.visited?1:0)),0)>=5).length,
      remaining=activeAll.reduce((s,x)=>s+(+x.float_target||0)-mtdFor(x),0),
      totalFloat=activeAll.reduce((s,x)=>s+(+x.float_target||0),0);
  let scopeLabel=viewOwnerId?`Viewing: ${esc(viewOwnerName)}`:'My items';
  document.getElementById('root').innerHTML=`<div class="app"><header><div><h1>Daily Progress Manager</h1><div class="muted">${scopeLabel} · ${esc(profile.full_name||user.email)} <span class="role">${esc(profile.role)}</span></div></div><div class="top-actions">${profile.role==='admin'?'<button onclick="usersModal()">Users</button>':''}${viewOwnerId?'<button onclick="clearOwnerView()">My Items</button>':''}<button onclick="showOwnPasswordModal()">My Password</button><button onclick="logout()">Logout</button><span class="current-date" aria-label="Current date">${esc(new Intl.DateTimeFormat('en-UG',{weekday:'short',day:'2-digit',month:'short',year:'numeric'}).format(new Date()) )}</span></div></header><div class="stats"><div class="stat"><span>Agent Base</span><b>${total}</b></div><div class="stat"><span>Float Base</span><b>${money(totalFloat)}</b></div><div class="stat"><span>Today Float Given</span><b>${money(givenToday)}</b></div><div class="stat"><span>Today Cash Pulls</span><b>${money(cashPullsToday)}</b></div><div class="stat"><span>Total Float Given MTD</span><b>${money(givenMTD)}</b></div><div class="stat"><span>Visited today</span><b>${visited}</b></div><div class="stat"><span>Productive Days</span><b>${monthVisited}</b></div><div class="stat"><span>Visited 5+ times</span><b>${visited5}</b></div><div class="stat"><span>Float variency</span><b>${money(remaining)}</b></div><button type="button" id="openBalanceBtn" class="stat stat-button" onclick="openBalance();return false;"><span>Tap To BALANCE</span><b>Open</b></button></div><div class="toolbar"><div class="search"><input id="q" placeholder="Search name, number, location or status" value="${esc(query)}"><button onclick="query=document.getElementById('q').value;render()">Search</button></div><div class="actions tabs"><button class="${!trash?'active':''}" onclick="trash=false;refresh()">Active</button>${profile.role==='admin'?`<button class="${trash?'active':''}" onclick="trash=true;refresh()">Recycle Bin</button>`:''}${!trash&&!viewOwnerId?'<button class="primary" onclick="formModal()">+ Add Item</button>':''}</div></div><div class="table-wrap card"><table><thead><tr><th>Name</th><th>Number</th><th>Target</th><th>Given today</th><th>MTD</th><th>Remaining</th><th>Cash Pulls</th><th>STATUS</th><th>Visits Made</th><th>Location</th><th>Owner</th><th>Actions</th></tr></thead><tbody>${active.map(row).join('')||`<tr><td colspan="12" class="empty">${trash?'Recycle Bin is empty.':'No items found.'}</td></tr>`}</tbody></table></div></div>`;
  const balanceBtn=document.getElementById('openBalanceBtn');
  if(balanceBtn) balanceBtn.addEventListener('click',openBalance);
}
window.addEventListener('hashchange',()=>{if(location.hash==='#balance' && user) renderBalance();});
function todayTotalsGeneral(){
  let day=today(), activeAll=items.filter(x=>!x.deleted);
  return {
    given:activeAll.reduce((s,x)=>s+(+((x.daily_progress||[]).find(p=>p.date===day)||{}).given||0),0),
    cash:activeAll.reduce((s,x)=>s+(+((x.daily_progress||[]).find(p=>p.date===day)||{}).cash_pulls||0),0)
  };
}
function balanceCarolItem(){return items.find(i=>!i.deleted&&String(i.name||'').trim().toLowerCase()==='carol bank katwe')||null;}
function selectedBalanceItem(){
  let id=window.balanceItemId||'';
  let x=items.find(i=>!i.deleted&&String(i.id)===String(id));
  if(x)return x;
  let carol=balanceCarolItem();
  if(carol){window.balanceItemId=carol.id;return carol;}
  return null;
}
function selectBalanceItem(id){window.balanceItemId=id;window.balanceTab='entries';renderBalance();}
function canEditBalance(x){return !!x&&(profile.role==='admin'||x.owner_id===user.id)}
function makeEntryId(prefix){return prefix+'-'+Date.now()+'-'+Math.random().toString(36).slice(2,10)}
function todayEntryFor(x){
  const day=today(),all=Array.isArray(x.daily_progress)?x.daily_progress:[],found=all.find(p=>p&&p.date===day);
  return found||{date:day,given:0,cash_pulls:0,visited:false,visits_count:0,notes:''};
}
function todayBankedEntriesFor(x){
  let p=todayEntryFor(x),entries=Array.isArray(p.banked_entries)?p.banked_entries.slice():[];
  if(!entries.length&&(+p.banked||0)>0)entries=[{id:'legacy-'+p.date,amount:+p.banked||0,entered_at:p.date+'T12:00:00',legacy:true}];
  return entries.sort((a,b)=>String(b.entered_at||'').localeCompare(String(a.entered_at||'')));
}
function todayMtnSentEntriesFor(x){
  let p=todayEntryFor(x),entries=Array.isArray(p.mtn_sent_entries)?p.mtn_sent_entries.slice():[];
  return entries.sort((a,b)=>String(b.entered_at||'').localeCompare(String(a.entered_at||'')));
}
function todayBankedFor(x){return todayBankedEntriesFor(x).reduce((s,e)=>s+(+e.amount||0),0)}
function todayMtnSentFor(x){return todayMtnSentEntriesFor(x).reduce((s,e)=>s+(+e.amount||0),0)}
function formatBalanceEntryTime(e){let d=new Date(e.entered_at||'');if(Number.isNaN(d.getTime()))return esc(e.entered_at||'');return esc(new Intl.DateTimeFormat('en-UG',{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'}).format(d))+(e.legacy?' <small class="muted">(legacy)</small>':'')}
function renderBalance(){
  let selected=selectedBalanceItem(),totals=todayTotalsGeneral(),tab=window.balanceTab||'entries';
  let scopeLabel=viewOwnerId?`Viewing: ${esc(viewOwnerName)}`:'My items';
  if(!selected){
    document.getElementById('root').innerHTML=`<div class="app balance-page"><header><div><h1>BALANCE</h1><div class="muted">${scopeLabel} · ${esc(profile.full_name||user.email)} <span class="role">${esc(profile.role)}</span></div></div><div class="top-actions"><button onclick="openDashboard()">← Dashboard</button><button onclick="logout()">Logout</button></div></header><div class="card"><h2 style="margin-top:0">Balance</h2><div class="muted">Balance Item: <b>Carol Bank Katwe</b></div><div class="error" style="margin-top:12px">Carol Bank Katwe is required for Banked and MTN SENT entries. Add it to the Agent Base first.</div></div></div>`;
    return;
  }
  let carol=balanceCarolItem(),isCarol=carol&&selected.id===carol.id,totalGiven=totals.given,totalCash=totals.cash;
  let totalBanked=isCarol?todayBankedFor(carol):0,totalMtnSent=isCarol?todayMtnSentFor(carol):0;
  let net=0;
  net=net+Number(totalCash||0);
  net=net+Number(totalBanked||0);
  net=net+Number(totalMtnSent||0);
  net=net-Number(totalGiven||0);
  let tabs=`<div class="actions tabs"><button class="${tab==='entries'?'active':''}" onclick="window.balanceTab='entries';renderBalance()">BALANCE ENTRY</button><button class="${tab==='check'?'active':''}" onclick="window.balanceTab='check';renderBalance()">CHECK BALANCE</button></div>`;
  let summary=`<div class="card"><div class="toolbar" style="margin-bottom:12px"><div><h2 style="margin:0">${esc(selected.name||'Unnamed item')}</h2><div class="muted">Given Today and Cash Pulls Today are general totals.</div></div><div style="min-width:260px;font-size:13px"><span class="muted">Balance Item</span><br><b>Carol Bank Katwe</b></div></div><div class="stats" style="grid-template-columns:repeat(4,1fr);margin-bottom:0"><div class="stat"><span>Given Today</span><b>${money(totalGiven)}</b></div><div class="stat"><span>Cash Pulls Today</span><b>${money(totalCash)}</b></div><div class="stat"><span>Total Banked</span><b>${money(totalBanked)}</b></div><div class="stat"><span>MTN SENT</span><b>${money(totalMtnSent)}</b></div></div></div>`;
  let body='';
  if(tab==='entries'){
    let banked=isCarol?todayBankedEntriesFor(carol):[],mtn=isCarol?todayMtnSentEntriesFor(carol):[];
    let bankedRows=banked.map(e=>`<tr><td>${formatBalanceEntryTime(e)}</td><td>${money(e.amount||0)}</td><td>${canEditBalance(carol)?`<button type="button" class="danger balance-delete-btn" data-balance-delete="banked" data-item-id="${esc(String(carol.id))}" data-entry-id="${esc(String(e.id))}" onpointerup="return window.balanceDeletePointer(this,event);" onclick="return false;" style="position:relative;z-index:1000;pointer-events:auto;">Delete</button>`:'—'}</td></tr>`).join('');
    let mtnRows=mtn.map(e=>`<tr><td>${formatBalanceEntryTime(e)}</td><td>${money(e.amount||0)}</td><td>${canEditBalance(carol)?`<button type="button" class="danger balance-delete-btn" data-balance-delete="mtn" data-item-id="${esc(String(carol.id))}" data-entry-id="${esc(String(e.id))}" onpointerup="return window.balanceDeletePointer(this,event);" onclick="return false;" style="position:relative;z-index:1000;pointer-events:auto;">Delete</button>`:'—'}</td></tr>`).join('');
    body=`<div class="card"><div class="toolbar" style="margin-bottom:8px"><div><h3 style="margin:0 0 4px">Banked Entries Today</h3><div class="muted">${isCarol?'Only Carol Bank Katwe can receive Banked figures. Add each amount separately as it is entered.':'Banked entries are available only for Carol Bank Katwe.'}</div></div>${isCarol?`<button type="button" class="primary" onclick="addBankedEntry('${esc(String(carol.id))}')">+ Add Carol Banked</button>`:''}</div><div class="table-wrap"><table><thead><tr><th>Time</th><th>Banked Amount</th><th>Action</th></tr></thead><tbody>${bankedRows||'<tr><td colspan="3" class="empty">No banked entries recorded today.</td></tr>'}</tbody></table></div></div>`;
    body+=`<div class="card"><div class="toolbar" style="margin-bottom:8px"><div><h3 style="margin:0 0 4px">MTN SENT Today</h3><div class="muted">Add each MTN SENT amount separately, just like Banked Entries.</div></div>${isCarol?`<button type="button" class="primary" onclick="addMtnSentEntry('${esc(String(carol.id))}')">+ Add MTN</button>`:''}</div><div class="table-wrap"><table><thead><tr><th>Time</th><th>MTN SENT Amount</th><th>Action</th></tr></thead><tbody>${mtnRows||'<tr><td colspan="3" class="empty">No MTN SENT entries recorded today.</td></tr>'}</tbody></table></div></div>`;
  }else if(tab==='check'){
    body=`<div class="card"><div class="muted" style="margin-bottom:6px">Today Reconciliation — ${new Intl.DateTimeFormat('en-UG',{day:'2-digit',month:'short',year:'numeric'}).format(new Date())}</div><div style="font-size:22px;font-weight:700">${net===0?'<span class="badge yes">BALANCING</span>':net>0?`<span style="color:#15803d">${money(net)}</span><span style="color:#15803d;margin-left:8px">EXCESS</span>`:`<span class="negative">-${money(Math.abs(net)).replace('-','')}</span><span class="negative" style="margin-left:8px">SHORTAGE</span>`}</div><div class="muted" style="margin-top:8px"></div><div style="margin-top:12px"><table style="min-width:0"><tbody><tr><td>Given Today</td><td>${money(totalGiven)}</td></tr><tr><td>Cash Pulls Today</td><td>${money(totalCash)}</td></tr><tr><td>Total Banked (Carol Bank Katwe)</td><td>${money(totalBanked)}</td></tr><tr><td>MTN SENT</td><td>${money(totalMtnSent)}</td></tr><tr><td><b>Reconciliation</b></td><td><b>${net===0?'BALANCING':money(net)}</b></td></tr></tbody></table></div></div>`;
  }
  document.getElementById('root').innerHTML=`<div class="app balance-page"><header><div><h1>BALANCE</h1><div class="muted">${scopeLabel} · ${esc(profile.full_name||user.email)} <span class="role">${esc(profile.role)}</span></div></div><div class="top-actions"><button onclick="openDashboard()">← Dashboard</button><button onclick="logout()">Logout</button></div></header>${summary}<div class="toolbar"><div></div>${tabs}</div>${body}</div>`;
}
function balanceDeletePointer(btn,ev){
  try{
    if(ev){ev.preventDefault();ev.stopPropagation();}
    const action=btn&&btn.getAttribute?btn.getAttribute('data-balance-delete'):'';
    const itemId=btn&&btn.getAttribute?btn.getAttribute('data-item-id'):'';
    const entryId=btn&&btn.getAttribute?btn.getAttribute('data-entry-id'):'';
    if(!action||!itemId||!entryId){alert('Delete entry information is missing.');return false;}
    showBalanceDeleteDialog(action,itemId,entryId);
  }catch(e){alert('Delete button error: '+(e&&e.message?e.message:String(e)));}
  return false;
}
window.balanceDeletePointer=balanceDeletePointer;
function showBalanceDeleteDialog(action,itemId,entryId){
  document.querySelectorAll('.modal-bg.balance-delete-confirm').forEach(x=>x.remove());
  const label=action==='mtn'?'MTN SENT':'Carol Banked';
  const d=overlay(`<div class="modal balance-delete-confirm" style="max-width:430px"><h2>Delete ${label}</h2><p>Are you sure you want to delete this ${label} entry?</p><div id="balanceDeleteDialogError" class="error" style="display:none"></div><div class="actions"><button type="button" id="cancelBalanceDelete">Cancel</button><button type="button" class="danger" id="confirmBalanceDelete">Delete</button></div></div>`);
  d.classList.add('balance-delete-confirm');
  d.querySelector('#cancelBalanceDelete').onclick=()=>d.remove();
  d.querySelector('#confirmBalanceDelete').onclick=async()=>{
    const b=d.querySelector('#confirmBalanceDelete'),err=d.querySelector('#balanceDeleteDialogError');
    b.disabled=true;b.textContent='Deleting...';err.style.display='none';
    try{
      if(action==='banked') await deleteBankedEntry(itemId,entryId,true);
      else await deleteMtnSentEntry(itemId,entryId,true);
      d.remove();
    }catch(e){err.textContent=e&&e.message?e.message:String(e);err.style.display='block';b.disabled=false;b.textContent='Delete';}
  };
}
function balanceHistoryHtml(x){
  let days=[...(x.daily_progress||[])].sort((a,b)=>String(b.date||'').localeCompare(String(a.date||'')));
  let rows=days.map(p=>{let banked=(Array.isArray(p.banked_entries)?p.banked_entries.reduce((s,e)=>s+(+e.amount||0),0):(+p.banked||0)),mtn=Array.isArray(p.mtn_sent_entries)?p.mtn_sent_entries.reduce((s,e)=>s+(+e.amount||0),0):0,given=+p.given||0,cash=+p.cash_pulls||0,net=0;net+=cash;net+=banked;net+=mtn;net-=given;let status=net===0?'<span class="badge yes">BALANCING</span>':net>0?`<b style="color:#15803d">${money(net)} EXCESS</b>`:`<b class="negative">-${money(Math.abs(net)).replace('-','')}</b>`;return `<tr><td>${esc(p.date||'')}</td><td>${money(given)}</td><td>${money(cash)}</td><td>${money(banked)}</td><td>${money(mtn)}</td><td>${status}</td></tr>`;}).join('');
  return `<div class="card"><h3 style="margin-top:0">Daily History</h3><div class="table-wrap"><table><thead><tr><th>Date</th><th>Given Today</th><th>Cash Pulls Today</th><th>Banked</th><th>MTN SENT</th><th>Check</th></tr></thead><tbody>${rows||'<tr><td colspan="6" class="empty">No daily balance history yet.</td></tr>'}</tbody></table></div></div>`;
}
async function addBankedEntry(id){
  let x=items.find(i=>i.id===id);if(!x||!canEditBalance(x))return alert('You are not allowed to edit this balance.');
  let d=overlay(`<form class="modal" id="bankedEntryForm"><h2>Add Carol Banked</h2><p class="muted">Carol Bank Katwe · enter each banked figure separately.</p><div id="bankedEntryError" class="error" style="display:none"></div><div class="grid"><label>Banked amount<input name="amount" type="number" min="0" step="0.01" required autofocus></label><label>Time entered<input type="text" value="${esc(new Intl.DateTimeFormat('en-UG',{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'}).format(new Date()))}" readonly><small class="muted">Automatic</small></label></div><div class="actions"><button type="button" onclick="this.closest('.modal-bg').remove()">Cancel</button><button class="primary" type="submit">Add Carol Banked</button></div></form>`);
  d.querySelector('#bankedEntryForm').onsubmit=async e=>{e.preventDefault();let f=new FormData(e.target),amount=Number(f.get('amount')),enteredAt=new Date();if(!Number.isFinite(amount)||amount<0)return alert('Enter a valid non-negative Banked amount.');let all=Array.isArray(x.daily_progress)?x.daily_progress.slice():[],day=today(),idx=all.findIndex(p=>p.date===day),entry=idx>=0?{...all[idx]}:{date:day,given:0,cash_pulls:0,visited:false,visits_count:0,notes:''};let existing=Array.isArray(entry.banked_entries)?entry.banked_entries.slice():((+entry.banked||0)>0?[{id:'legacy-'+day,amount:+entry.banked||0,entered_at:day+'T12:00:00',legacy:true}]:[]);existing.push({id:makeEntryId('banked'),amount,entered_at:enteredAt.toISOString(),created_at:new Date().toISOString()});entry.banked_entries=existing;entry.banked=existing.reduce((s,e)=>s+(+e.amount||0),0);let updated=idx>=0?all.map((p,i)=>i===idx?entry:p):[...all,entry];let r=await sb.from('items').update({daily_progress:updated}).eq('id',id);if(r.error){d.querySelector('#bankedEntryError').textContent=r.error.message;d.querySelector('#bankedEntryError').style.display='block';}else{items=items.map(i=>i.id===id?{...i,daily_progress:updated}:i);d.remove();renderBalance();}};
}
async function addMtnSentEntry(id){
  let x=items.find(i=>i.id===id);if(!x||!canEditBalance(x))return alert('You are not allowed to edit this balance.');
  let d=overlay(`<form class="modal" id="mtnSentEntryForm"><h2>Add MTN SENT</h2><p class="muted">Enter each MTN SENT figure separately.</p><div id="mtnSentEntryError" class="error" style="display:none"></div><div class="grid"><label>MTN SENT amount<input name="amount" type="number" min="0" step="0.01" required autofocus></label><label>Time entered<input type="text" value="${esc(new Intl.DateTimeFormat('en-UG',{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'}).format(new Date()))}" readonly><small class="muted">Automatic</small></label></div><div class="actions"><button type="button" onclick="this.closest('.modal-bg').remove()">Cancel</button><button class="primary" type="submit">Add MTN</button></div></form>`);
  d.querySelector('#mtnSentEntryForm').onsubmit=async e=>{e.preventDefault();let f=new FormData(e.target),amount=Number(f.get('amount')),enteredAt=new Date();if(!Number.isFinite(amount)||amount<0)return alert('Enter a valid non-negative MTN SENT amount.');let all=Array.isArray(x.daily_progress)?x.daily_progress.slice():[],day=today(),idx=all.findIndex(p=>p.date===day),entry=idx>=0?{...all[idx]}:{date:day,given:0,cash_pulls:0,visited:false,visits_count:0,notes:''};let existing=Array.isArray(entry.mtn_sent_entries)?entry.mtn_sent_entries.slice():[];existing.push({id:makeEntryId('mtn'),amount,entered_at:enteredAt.toISOString(),created_at:new Date().toISOString()});entry.mtn_sent_entries=existing;let updated=idx>=0?all.map((p,i)=>i===idx?entry:p):[...all,entry];let r=await sb.from('items').update({daily_progress:updated}).eq('id',id);if(r.error){d.querySelector('#mtnSentEntryError').textContent=r.error.message;d.querySelector('#mtnSentEntryError').style.display='block';}else{items=items.map(i=>i.id===id?{...i,daily_progress:updated}:i);d.remove();renderBalance();}};
}
async function saveDailyProgressForBalance(id,updated){
  const session=await sb.auth.getSession();
  const token=session&&session.data&&session.data.session&&session.data.session.access_token;
  if(!token)throw new Error('Your login session has expired. Please log in again.');
  const res=await fetch(SUPABASE_URL+'/rest/v1/items?id=eq.'+encodeURIComponent(id),{method:'PATCH',headers:{'Content-Type':'application/json','apikey':SUPABASE_ANON_KEY,'Authorization':'Bearer '+token,'Prefer':'return=representation'},body:JSON.stringify({daily_progress:updated})});
  let body=null;try{body=await res.json()}catch(_){ }
  if(!res.ok)throw new Error((body&&(body.message||body.msg||body.error||body.details))||('Supabase update failed (HTTP '+res.status+').'));
  if(!Array.isArray(body)||body.length===0)throw new Error('Supabase updated 0 items. Your items UPDATE policy may be blocking this action.');
  return true;
}
async function deleteBankedEntry(id,entryId){
  try{
    const x=items.find(i=>String(i.id)===String(id));
    if(!x)throw new Error('Carol Bank Katwe could not be found. Refresh the page and try again.');
    if(!canEditBalance(x))throw new Error('You are not allowed to edit this balance.');
    const all=Array.isArray(x.daily_progress)?x.daily_progress.slice():[],day=today(),idx=all.findIndex(p=>p&&p.date===day);
    if(idx<0)throw new Error('No entry exists for today.');
    const entry={...all[idx]},existing=Array.isArray(entry.banked_entries)?entry.banked_entries.slice():[];
    if(String(entryId).startsWith('legacy-')){
      entry.banked_entries=[];
      entry.banked=0;
    }else{
      const next=existing.filter(e=>String(e.id)!==String(entryId));
      if(next.length===existing.length)throw new Error('Carol Banked entry was not found.');
      entry.banked_entries=next;
      entry.banked=next.reduce((sum,e)=>sum+(Number(e.amount)||0),0);
    }
    const updated=all.map((p,i)=>i===idx?entry:p);
    await saveDailyProgressForBalance(id,updated);
    items=items.map(i=>String(i.id)===String(id)?{...i,daily_progress:updated}:i);
    renderBalance();
  }catch(err){alert('Delete Carol Banked entry failed: '+(err&&err.message?err.message:String(err)));}
}
async function deleteMtnSentEntry(id,entryId){
  try{
    const x=items.find(i=>String(i.id)===String(id));
    if(!x)throw new Error('Carol Bank Katwe could not be found. Refresh the page and try again.');
    if(!canEditBalance(x))throw new Error('You are not allowed to edit this balance.');
    const all=Array.isArray(x.daily_progress)?x.daily_progress.slice():[],day=today(),idx=all.findIndex(p=>p&&p.date===day);
    if(idx<0)throw new Error('No entry exists for today.');
    const entry={...all[idx]},existing=Array.isArray(entry.mtn_sent_entries)?entry.mtn_sent_entries.slice():[];
    const next=existing.filter(e=>String(e.id)!==String(entryId));
    if(next.length===existing.length)throw new Error('MTN SENT entry was not found.');
    entry.mtn_sent_entries=next;
    const updated=all.map((p,i)=>i===idx?entry:p);
    await saveDailyProgressForBalance(id,updated);
    items=items.map(i=>String(i.id)===String(id)?{...i,daily_progress:updated}:i);
    renderBalance();
  }catch(err){alert('Delete MTN SENT entry failed: '+(err&&err.message?err.message:String(err)));}
}

async function refresh(){await loadItems();render()}
async function viewUserItems(id,name){if(profile.role!=='admin')return;viewOwnerId=id;viewOwnerName=name||'User';trash=false;query='';document.querySelectorAll('.modal-bg').forEach(x=>x.remove());await refresh()}
async function clearOwnerView(){viewOwnerId=null;viewOwnerName='';trash=false;query='';await refresh()}
function overlay(html){let d=document.createElement('div');d.className='modal-bg';d.innerHTML=html;document.body.appendChild(d);return d}
function formModal(id){let x=items.find(i=>i.id===id)||{};let d=overlay(`<form class="modal" id="f"><h2>${id?'Edit':'Add'} item</h2><div class="grid"><label>Name *<input name="name" required value="${esc(x.name)}"></label><label>Number<input name="number" value="${esc(x.number)}"></label><label>Float target<input name="target" type="number" step="0.01" value="${x.float_target||0}"></label><label>Location<input name="location" value="${esc(x.location)}"></label><label>Personal number<input name="personal" value="${esc(x.personal_number)}"></label><label>Details<input name="details" value="${esc(x.details)}"></label></div><div class="actions"><button type="button" onclick="this.closest('.modal-bg').remove()">Cancel</button><button class="primary">Save</button></div></form>`);d.querySelector('#f').onsubmit=async e=>{e.preventDefault();let f=new FormData(e.target);let payload={name:f.get('name').trim(),number:f.get('number').trim(),float_target:+f.get('target')||0,location:f.get('location').trim(),personal_number:f.get('personal').trim(),details:f.get('details').trim()};let r=id?await sb.from('items').update(payload).eq('id',id):await sb.from('items').insert({...payload,owner_id:user.id,deleted:false});if(r.error)alert(r.error.message);else{d.remove();refresh()}}}
function progressModal(id){let x=items.find(i=>i.id===id);let d=overlay(`<form class="modal" id="p"><h2>Record a visit — ${esc(x.name)}</h2><div class="muted" style="margin-bottom:12px">Choose whether this visit records an amount given or a cash pull.</div><div class="grid"><label>Date<input name="date" type="date" value="${today()}"></label><label>Visit type<select name="type"><option value="given">Amount given this visit</option><option value="cash_pull">Cash Pull</option></select></label><label id="amountLabel">Amount given this visit<input name="amount" type="number" min="0" step="0.01" value="0" required></label></div><label style="display:block;margin-top:10px">Notes<textarea name="notes" placeholder="Optional visit notes"></textarea></label><div class="actions"><button type="button" onclick="this.closest('.modal-bg').remove()">Cancel</button><button class="primary">Add Visit</button></div></form>`);let form=d.querySelector('#p'),type=form.elements.type,label=d.querySelector('#amountLabel');type.onchange=()=>{label.innerHTML=(type.value==='cash_pull'?'Cash Pull amount':'Amount given this visit')+'<input name="amount" type="number" min="0" step="0.01" value="0" required>'};form.onsubmit=async e=>{e.preventDefault();let f=new FormData(e.target),day=f.get('date'),amount=Number(f.get('amount')),kind=String(f.get('type'));if(!Number.isFinite(amount)||amount<0)return alert('Enter a valid non-negative amount.');let all=x.daily_progress||[],idx=all.findIndex(p=>p.date===day),entry=idx>=0?{...all[idx]}:{date:day,given:0,cash_pulls:0,visited:false,visits_count:0,notes:''};if(!Array.isArray(entry.visits)){entry.legacy_given=+entry.given||0;entry.legacy_cash_pulls=+entry.cash_pulls||0;entry.legacy_visits=+(entry.visits_count||0)||(entry.visited?1:0);entry.legacy_notes=entry.notes||'';entry.visits=[];}let note=String(f.get('notes')||'').trim(),visit={id:(crypto.randomUUID?crypto.randomUUID():String(Date.now())+'-'+Math.random()),type:kind,given:kind==='given'?amount:0,cash_pull:kind==='cash_pull'?amount:0,notes:note,created_at:new Date().toISOString()};entry.visits.push(visit);entry.given=(+entry.legacy_given||0)+entry.visits.reduce((sum,v)=>sum+(+v.given||0),0);entry.cash_pulls=(+entry.legacy_cash_pulls||0)+entry.visits.reduce((sum,v)=>sum+(+v.cash_pull||0),0);entry.visits_count=(+entry.legacy_visits||0)+entry.visits.length;entry.visited=entry.visits_count>0;entry.notes=[...(entry.legacy_notes?[entry.legacy_notes]:[]),...entry.visits.map(v=>v.notes).filter(Boolean)].join(' | ');let updated=all.filter(p=>p.date!==day);updated.push(entry);let r=await sb.from('items').update({daily_progress:updated}).eq('id',id);if(r.error)alert(r.error.message);else{d.remove();refresh()}}}
function historyModal(id){
  let x=items.find(i=>i.id===id),rows=[...(x.daily_progress||[])].sort((a,b)=>b.date.localeCompare(a.date));
  let canEdit=profile.role==='admin'||x.owner_id===user.id;
  let d=overlay(`<div class="modal"><h2>Progress history — ${esc(x.name)}</h2><div id="historyError" class="error" style="display:none"></div><div class="table-wrap"><table><tr><th>Date</th><th>Given</th><th>Remaining</th><th>Cash Pulls</th><th>STATUS</th><th>Visits Made</th><th>Notes / Visit actions</th></tr>${rows.map(p=>`<tr><td>${p.date}</td><td>${money(p.given)}</td><td>${money((+x.float_target||0)-(x.daily_progress||[]).filter(q=>q.date.startsWith(p.date.slice(0,7))&&q.date<=p.date).reduce((s,q)=>s+(+q.given||0),0))}</td><td>${money(p.cash_pulls||0)}</td><td>${+p.visits_count||(p.visited?1:0)}</td><td>${Array.isArray(p.visits)&&p.visits.length?p.visits.map((v,i)=>`<div style="padding:5px 0;border-bottom:1px solid var(--border)"><b>Visit ${i+1} (${v.type==='cash_pull'?'Cash Pull':'Given'}):</b> ${money(v.type==='cash_pull'?v.cash_pull:v.given)} ${esc(v.notes||'')}${canEdit?` <button type="button" class="danger" data-delete-visit="1" data-item-id="${esc(x.id)}" data-day="${esc(p.date)}" data-visit-id="${esc(String(v.id))}">Delete visit</button>`:''}</div>`).join(''):`${esc(p.notes||'')}${Array.isArray(p.visits)?'':' <small class="muted">(Older combined record; individual visit amounts were not stored.)'}`}</td></tr>`).join('')||'<tr><td colspan="6" class="empty">No daily records yet.</td></tr>'}</table></div><div class="actions"><button type="button" id="closeHistory">Close</button></div></div>`);
  d.querySelector('#closeHistory').onclick=()=>d.remove();
  d.querySelectorAll('[data-delete-visit]').forEach(btn=>btn.addEventListener('click',()=>confirmDeleteVisit(btn.dataset.itemId,btn.dataset.day,btn.dataset.visitId)));
}
function showHistoryError(message){
  let el=document.getElementById('historyError');
  if(el){el.textContent=message;el.style.display='block';}
}
function confirmDeleteVisit(id,day,visitId){
  let c=overlay(`<div class="modal" style="max-width:420px"><h2>Delete visit?</h2><p>This will remove this visit and its recorded amount from the daily history.</p><div class="actions"><button type="button" id="cancelDelete">Cancel</button><button type="button" class="danger" id="confirmDelete">Delete visit</button></div></div>`);
  c.querySelector('#cancelDelete').onclick=()=>c.remove();
  c.querySelector('#confirmDelete').onclick=async()=>{c.remove();await deleteVisit(id,day,visitId);};
}
async function deleteVisit(id,day,visitId){
  try{
    const x=items.find(i=>i.id===id);
    if(!x)throw new Error('The item could not be found in the current app data. Close History and reopen it.');
    const all=Array.isArray(x.daily_progress)?x.daily_progress:[];
    const original=all.find(p=>p.date===day);
    if(!original)throw new Error('The selected day could not be found. Close History and reopen it.');
    if(!Array.isArray(original.visits))throw new Error('This record does not contain individual visits, so there is no visit ID to delete.');
    const before=original.visits.length;
    const remainingVisits=original.visits.filter(v=>String(v.id)!==String(visitId));
    if(remainingVisits.length===before)throw new Error('The selected visit was not found. Close History and reopen it.');
    const next={...original,visits:remainingVisits};
    const legacyGiven=Number(original.legacy_given||0);
    const legacyCashPulls=Number(original.legacy_cash_pulls||0);
    next.cash_pulls=legacyCashPulls+remainingVisits.reduce((sum,v)=>sum+(Number(v.cash_pull)||0),0);
    const legacyVisits=Number(original.legacy_visits||0)||(original.visited && !Array.isArray(original.visits)?1:0);
    const legacyNotes=String(original.legacy_notes||'');
    next.given=legacyGiven+remainingVisits.reduce((sum,v)=>sum+(Number(v.given)||0),0);
    next.visits_count=legacyVisits+remainingVisits.length;
    next.visited=next.visits_count>0;
    next.notes=[...(legacyNotes?[legacyNotes]:[]),...remainingVisits.map(v=>String(v.notes||'').trim()).filter(Boolean)].join(' | ');
    const updated=all.map(p=>p.date===day?next:p).filter(p=>p.date!==day || next.visits_count>0 || next.given!==0 || next.notes);
    const access=await sb.auth.getSession();
    const token=access&&access.data&&access.data.session&&access.data.session.access_token;
    if(!token)throw new Error('Your login session has expired. Log in again and retry.');
    const res=await fetch(SUPABASE_URL+'/rest/v1/items?id=eq.'+encodeURIComponent(id),{method:'PATCH',headers:{'Content-Type':'application/json','apikey':SUPABASE_ANON_KEY,'Authorization':'Bearer '+token,'Prefer':'return=representation'},body:JSON.stringify({daily_progress:updated})});
    let body=null;try{body=await res.json()}catch(_){}
    if(!res.ok)throw new Error((body&&(body.message||body.msg||body.error||body.details))||('Supabase update failed (HTTP '+res.status+').'));
    if(!Array.isArray(body)||body.length===0)throw new Error('Supabase accepted the request but updated 0 items. Check your items UPDATE policy.');
    document.querySelectorAll('.modal-bg').forEach(m=>m.remove());
    await refresh();
    historyModal(id);
  }catch(err){
    let msg=err&&err.message?err.message:String(err);
    let historyOpen=[...document.querySelectorAll('.modal-bg')].some(m=>m.querySelector('#historyError'));
    if(historyOpen)showHistoryError(msg);else alert('Delete visit failed: '+msg);
  }
}

function confirmItemAction(id, permanent){
  const x=items.find(i=>i.id===id);
  if(!x)return alert('Item not found. Refresh the list and try again.');
  const title=permanent?'Permanently delete item?':'Delete item?';
  const message=permanent?`Permanently delete <b>${esc(x.name)}</b> and all of its saved history? This cannot be undone.`:`Move <b>${esc(x.name)}</b> to the Recycle Bin? You can restore it later.`;
  const actionText=permanent?'Delete permanently':'Move to Recycle Bin';
  const c=overlay(`<div class="modal" style="max-width:460px"><h2>${title}</h2><p>${message}</p><div class="actions"><button type="button" id="cancelItemAction">Cancel</button><button type="button" class="danger" id="confirmItemAction">${actionText}</button></div><div id="itemActionError" class="error" style="display:none;margin-top:10px"></div></div>`);
  c.querySelector('#cancelItemAction').onclick=()=>c.remove();
  c.querySelector('#confirmItemAction').onclick=async()=>{
    const b=c.querySelector('#confirmItemAction');
    const e=c.querySelector('#itemActionError');
    b.disabled=true;b.textContent=permanent?'Deleting...':'Moving...';
    try{
      const r=permanent?await sb.from('items').delete().eq('id',id):await sb.from('items').update({deleted:true}).eq('id',id);
      if(r.error)throw new Error(r.error.message||'Database request failed');
      c.remove();
      await refresh();
    }catch(err){
      b.disabled=false;b.textContent=actionText;
      e.textContent=err&&err.message?err.message:String(err);
      e.style.display='block';
    }
  };
}

async function del(id){confirmItemAction(id,false)}

async function restore(id){
  try{
    const r=await sb.from('items').update({deleted:false}).eq('id',id);
    if(r.error)throw new Error(r.error.message||'Could not restore item');
    await refresh();
  }catch(err){alert('Restore failed: '+(err&&err.message?err.message:String(err)));}
}

async function permanentDelete(id){confirmItemAction(id,true)}
async function usersModal(){
  if(profile.role!=='admin')return;
  let r=await sb.from('profiles').select('*').order('created_at');
  if(r.error)return alert(r.error.message);
  let d=overlay(`<div class="modal" id="usersModal"><h2>User Management</h2><p class="muted">Tap <b>View Items</b> to see only that user's items. Your own items remain separate.</p><div id="userDeleteError" class="error" style="display:none"></div><div class="table-wrap"><table><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Actions</th></tr>${r.data.map(p=>{
    const targetName=String(p.full_name||p.email||'User');
    return `<tr><td><b>${esc(p.full_name||'')}</b></td><td>${esc(p.email||'')}</td><td>${esc(p.role)}</td><td>${p.disabled?'Disabled':'Active'}</td><td class="row-actions">${p.id===user.id?'<span class="muted">Current user</span>':`<button type="button" data-view-user="${esc(p.id)}" data-view-name="${esc(targetName)}">View Items</button><button type="button" data-change-password="${esc(p.id)}" data-change-name="${esc(targetName)}">Change Password</button><button type="button" class="danger" data-delete-user="${esc(p.id)}" data-delete-name="${esc(targetName)}">Delete</button>`}</td></tr>`;
  }).join('')}</table></div><div class="actions"><button type="button" id="createUserOpen">+ Create User</button><button type="button" id="closeUsers">Close</button></div></div>`);
  d.querySelector('#createUserOpen').onclick=()=>{d.remove();createUserModal();};
  d.querySelector('#closeUsers').onclick=()=>d.remove();
  d.querySelectorAll('[data-view-user]').forEach(btn=>btn.addEventListener('click',()=>viewUserItems(btn.dataset.viewUser,btn.dataset.viewName)));
  d.querySelectorAll('[data-delete-user]').forEach(btn=>btn.addEventListener('click',()=>confirmDeleteUser(btn.dataset.deleteUser,btn.dataset.deleteName)));
  d.querySelectorAll('[data-change-password]').forEach(btn=>btn.addEventListener('click',()=>changeUserPasswordModal(btn.dataset.changePassword,btn.dataset.changeName)));
}

function showUserDeleteError(message){
  let el=document.getElementById('userDeleteError');
  if(el){el.textContent=message;el.style.display='block';}
}

function confirmDeleteUser(id,name){
  if(id===user.id)return alert('You cannot delete your own administrator account here.');
  let c=overlay(`<div class="modal" style="max-width:460px"><h2>Delete user?</h2><p>Permanently delete <b>${esc(name)}</b>? This removes the user's login account, profile, items, and item history.</p><div class="actions"><button type="button" id="cancelUserDelete">Cancel</button><button type="button" class="danger" id="confirmUserDelete">Delete user</button></div></div>`);
  c.querySelector('#cancelUserDelete').onclick=()=>c.remove();
  c.querySelector('#confirmUserDelete').onclick=async()=>{const b=c.querySelector('#confirmUserDelete');b.disabled=true;b.textContent='Deleting...';await deleteUser(id,name);if(document.body.contains(c))c.remove();};
}

async function deleteUser(id,name){
  if(id===user.id)return alert('You cannot delete your own administrator account here.');
  try{
    const session=await sb.auth.getSession();
    const accessToken=session&&session.data&&session.data.session&&session.data.session.access_token;
    if(!accessToken)throw new Error('Your admin session has expired. Please log in again.');
    const res=await fetch(SUPABASE_URL+'/functions/v1/admin-delete-user',{
      method:'POST',
      headers:{'Content-Type':'application/json','apikey':SUPABASE_ANON_KEY,'Authorization':'Bearer '+accessToken},
      body:JSON.stringify({user_id:id})
    });
    let j={};try{j=await res.json()}catch(_){ }
    if(!res.ok)throw new Error(j.error||j.message||('Could not delete user (HTTP '+res.status+')'));
    document.querySelectorAll('.modal-bg').forEach(x=>x.remove());
    await refresh();
    await usersModal();
  }catch(err){
    const msg=err&&err.message?err.message:String(err);
    const open=document.getElementById('usersModal');
    if(open){
      open.querySelectorAll('[data-delete-user]').forEach(btn=>{btn.disabled=false;btn.textContent='Delete';});
      showUserDeleteError(msg);
    }else alert('Delete user failed: '+msg);
  }
}


function changeUserPasswordModal(id,name){
  if(id===user.id)return alert('Use your own account settings to change the administrator password.');
  document.querySelectorAll('.modal-bg').forEach(x=>x.remove());
  const d=overlay(`<form class="modal" id="changePasswordForm" onsubmit="return false"><h2>Change Password</h2><p class="muted">Set a new password for <b>${esc(name)}</b>.</p><div id="changePasswordError" class="error" style="display:none"></div><div class="grid"><label>New password<input name="password" type="password" minlength="8" required autocomplete="new-password"></label><label>Confirm password<input name="confirm" type="password" minlength="8" required autocomplete="new-password"></label></div><div class="actions"><button type="button" id="cancelPassword">Cancel</button><button type="button" class="primary" id="savePassword">Change Password</button></div></form>`);
  d.querySelector('#cancelPassword').onclick=()=>d.remove();
  d.querySelector('#savePassword').onclick=async()=>{
    const button=d.querySelector('#savePassword');
    const errorBox=d.querySelector('#changePasswordError');
    const password=String(d.querySelector('[name="password"]').value||'');
    const confirm=String(d.querySelector('[name="confirm"]').value||'');
    errorBox.style.display='none';errorBox.textContent='';
    if(password.length<8){errorBox.textContent='Password must be at least 8 characters.';errorBox.style.display='block';return;}
    if(password!==confirm){errorBox.textContent='The two passwords do not match.';errorBox.style.display='block';return;}
    button.disabled=true;button.textContent='Changing...';
    try{
      const session=await sb.auth.getSession();
      const accessToken=session&&session.data&&session.data.session&&session.data.session.access_token;
      if(!accessToken)throw new Error('Your admin session has expired. Please log in again.');
      const res=await fetch(SUPABASE_URL+'/functions/v1/admin-change-password',{
        method:'POST',
        headers:{'Content-Type':'application/json','apikey':SUPABASE_ANON_KEY,'Authorization':'Bearer '+accessToken},
        body:JSON.stringify({user_id:id,password})
      });
      let j={};try{j=await res.json()}catch(_){ }
      if(!res.ok)throw new Error(j.error||j.message||('Could not change password (HTTP '+res.status+')'));
      d.remove();
      alert('Password changed successfully for '+name+'.');
    }catch(err){
      errorBox.textContent=err&&err.message?err.message:String(err);
      errorBox.style.display='block';
      button.disabled=false;button.textContent='Change Password';
    }
  };
  d.querySelectorAll('input').forEach(el=>el.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();d.querySelector('#savePassword').click();}}));
  return d;
}

async function createUserSubmit(d,button){
  const form=d.querySelector('#u');
  const f=new FormData(form);
  const name=String(f.get('name')||'').trim();
  const email=String(f.get('email')||'').trim();
  const password=String(f.get('password')||'');
  const role=String(f.get('role')||'agent');
  const errorBox=d.querySelector('#createError');
  const setError=(msg)=>{errorBox.textContent=msg||'';errorBox.style.display=msg?'block':'none'};
  setError('');
  if(!name||!email||password.length<8){setError('Enter a full name, valid email, and a password of at least 8 characters.');return;}
  button.disabled=true;button.textContent='Creating...';
  try{
    const session=await sb.auth.getSession();
    const accessToken=session&&session.data&&session.data.session&&session.data.session.access_token;
    if(!accessToken)throw new Error('Your admin session has expired. Please log in again.');
    const res=await fetch(SUPABASE_URL+'/functions/v1/admin-create-user',{method:'POST',headers:{'Content-Type':'application/json','apikey':SUPABASE_ANON_KEY,Authorization:'Bearer '+accessToken},body:JSON.stringify({email,password,full_name:name,role})});
    let j={};try{j=await res.json()}catch(_){ }
    if(!res.ok)throw new Error(j.error||j.message||('Could not create user (HTTP '+res.status+')'));
    d.remove();
    await usersModal();
  }catch(err){setError(err&&err.message?err.message:String(err));button.disabled=false;button.textContent='Create';}
}
function createUserModal(){
  document.querySelectorAll('.modal-bg').forEach(x=>x.remove());
  const d=overlay(`<form class="modal" id="u" onsubmit="return false"><h2>Create User</h2><div id="createError" class="error" style="display:none"></div><div class="grid"><label>Full name<input name="name" required autocomplete="name"></label><label>Email<input name="email" type="email" required autocomplete="email"></label><label>Temporary password<input name="password" type="password" minlength="8" required autocomplete="new-password"></label><label>Role<select name="role"><option value="agent">Agent</option><option value="admin">Administrator</option></select></label></div><div class="actions"><button type="button" onclick="this.closest('.modal-bg').remove()">Cancel</button><button type="button" class="primary" id="createUserBtn">Create</button></div></form>`);
  const button=d.querySelector('#createUserBtn');
  button.addEventListener('click',()=>createUserSubmit(d,button));
  d.querySelectorAll('input,select').forEach(el=>el.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();button.click();}}));
  return d;
}
async function logout(){await sb.auth.signOut();showLogin()}
window.addEventListener('hashchange',()=>{if(profile)render()});
if(configured()){
  try{sb=window.supabase.createClient(SUPABASE_URL,SUPABASE_ANON_KEY);(async()=>{if(await handleRecovery())return;await boot();})().catch(e=>showLogin('App startup error: '+(e.message||e)));}
  catch(e){showLogin('Could not start the app: '+(e.message||e));}
}else showLogin();
