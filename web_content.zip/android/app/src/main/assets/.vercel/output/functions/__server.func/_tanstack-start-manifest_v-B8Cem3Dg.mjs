//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B8Cem3Dg.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-IEA_ay9J.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-IEA_ay9J.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Ddlzt2dl.js"]
	}
} });
//#endregion
export { tsrStartManifest };
