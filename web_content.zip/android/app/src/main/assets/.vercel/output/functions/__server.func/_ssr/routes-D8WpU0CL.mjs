import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as RotateCcw, c as Check, i as Settings, l as BookOpen, o as Plus, r as Target, s as ChevronRight, t as X } from "../_libs/lucide-react.mjs";
import { a as DialogPortal, i as DialogOverlay, n as DialogClose, o as DialogTitle, r as DialogContent, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D8WpU0CL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DHIKRS = [
	{
		id: "subhanallah",
		ar: "سُبْحَانَ اللَّهِ",
		tr: "Allah'ı tenzih ederim",
		label: "Subhanallah"
	},
	{
		id: "alhamdulillah",
		ar: "الْحَمْدُ لِلَّهِ",
		tr: "Hamd Allah'a mahsustur",
		label: "Alhamdulillah"
	},
	{
		id: "allahuakbar",
		ar: "اللَّهُ أَكْبَرُ",
		tr: "Allah en büyüktür",
		label: "Allahu Akbar"
	},
	{
		id: "lailaha",
		ar: "لَا إِلَٰهَ إِلَّا اللَّهُ",
		tr: "Allah'tan başka ilah yoktur",
		label: "La ilahe illallah"
	},
	{
		id: "astaghfirullah",
		ar: "أَسْتَغْفِرُ اللَّهَ",
		tr: "Allah'tan bağışlanma dilerim",
		label: "Astaghfirullah"
	},
	{
		id: "salawat",
		ar: "صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ",
		tr: "Allah ona salat ve selam etsin",
		label: "Salawat"
	},
	{
		id: "subhanallahi",
		ar: "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ",
		tr: "Allah'ı hamd ile tenzih ederim",
		label: "Subhanallahi ve bihamdihi"
	},
	{
		id: "hasbunallah",
		ar: "حَسْبُنَا اللَّهُ وَنِعْمَ الْوَكِيلُ",
		tr: "Allah bize yeter, O ne güzel vekildir",
		label: "Hasbunallah"
	},
	{
		id: "lahavle",
		ar: "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ",
		tr: "Güç ve kuvvet ancak Allah'tandır",
		label: "La havle"
	},
	{
		id: "rabbighfirli",
		ar: "رَبِّ اغْفِرْ لِي",
		tr: "Rabbim beni bağışla",
		label: "Rabbiğfirli"
	}
];
var GOAL_PRESETS = [
	33,
	99,
	100,
	333,
	500,
	1e3
];
var THEMES = [
	{
		id: "emerald",
		accent: "#10b981",
		dark: "#059669",
		label: "Zümrüt"
	},
	{
		id: "teal",
		accent: "#14b8a6",
		dark: "#0d9488",
		label: "Teal"
	},
	{
		id: "sky",
		accent: "#0ea5e9",
		dark: "#0284c7",
		label: "Gökyüzü"
	},
	{
		id: "blue",
		accent: "#2563eb",
		dark: "#1d4ed8",
		label: "Mavi"
	},
	{
		id: "rose",
		accent: "#f43f5e",
		dark: "#e11d48",
		label: "Gül"
	},
	{
		id: "gold",
		accent: "#d4af37",
		dark: "#b8860b",
		label: "Altın"
	}
];
var RING_CIRC = 2 * Math.PI * 80;
function todayKey() {
	const d = /* @__PURE__ */ new Date();
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function emptyCounts() {
	return Object.fromEntries(DHIKRS.map((d) => [d.id, 0]));
}
function applyTheme(id) {
	if (typeof document === "undefined") return;
	const theme = THEMES.find((t) => t.id === id) ?? THEMES[0];
	const root = document.documentElement;
	root.style.setProperty("--accent", theme.accent);
	root.style.setProperty("--accent-dark", theme.dark);
}
function clampGoal(n) {
	if (!Number.isFinite(n)) return 33;
	return Math.max(1, Math.min(99999, Math.floor(n)));
}
var ctx = null;
function getCtx() {
	if (typeof window === "undefined") return null;
	try {
		const AC = window.AudioContext || window.webkitAudioContext;
		if (!AC) return null;
		ctx ??= new AC();
		if (ctx.state === "suspended") ctx.resume();
		return ctx;
	} catch {
		return null;
	}
}
function playTick() {
	const ac = getCtx();
	if (!ac) return;
	const t = ac.currentTime;
	const osc = ac.createOscillator();
	const gain = ac.createGain();
	osc.type = "sine";
	osc.frequency.setValueAtTime(760, t);
	osc.frequency.exponentialRampToValueAtTime(480, t + .055);
	gain.gain.setValueAtTime(.06, t);
	gain.gain.exponentialRampToValueAtTime(.001, t + .07);
	osc.connect(gain);
	gain.connect(ac.destination);
	osc.start(t);
	osc.stop(t + .08);
}
function playComplete() {
	const ac = getCtx();
	if (!ac) return;
	const t = ac.currentTime;
	[
		523.25,
		659.25,
		783.99
	].forEach((freq, i) => {
		const osc = ac.createOscillator();
		const gain = ac.createGain();
		osc.type = "sine";
		osc.frequency.value = freq;
		const start = t + i * .09;
		gain.gain.setValueAtTime(1e-4, start);
		gain.gain.exponentialRampToValueAtTime(.07, start + .02);
		gain.gain.exponentialRampToValueAtTime(.001, start + .28);
		osc.connect(gain);
		gain.connect(ac.destination);
		osc.start(start);
		osc.stop(start + .3);
	});
}
function haptic(ms = 14) {
	try {
		navigator.vibrate?.(ms);
	} catch {}
}
function hapticGoal() {
	try {
		navigator.vibrate?.([
			18,
			36,
			18,
			36,
			42
		]);
	} catch {}
}
var memoryStorage = {
	getItem: () => null,
	setItem: () => void 0,
	removeItem: () => void 0,
	clear: () => void 0,
	key: () => null,
	length: 0
};
var useZikirStore = create()(persist((set, get) => ({
	activeId: "subhanallah",
	counts: emptyCounts(),
	totals: emptyCounts(),
	goal: 33,
	todayDate: todayKey(),
	todayCount: 0,
	lifetime: 0,
	rounds: 0,
	sound: true,
	vibrate: true,
	theme: "emerald",
	stopAtGoal: true,
	rollToday: () => {
		const today = todayKey();
		if (get().todayDate !== today) set({
			todayDate: today,
			todayCount: 0
		});
	},
	tap: () => {
		const s = get();
		const current = s.counts[s.activeId] ?? 0;
		if (s.stopAtGoal && current >= s.goal) return {
			incremented: false,
			reached: true
		};
		if (s.sound) playTick();
		if (s.vibrate) haptic();
		const next = current + 1;
		const reached = next >= s.goal && current < s.goal;
		const today = todayKey();
		set({
			counts: {
				...s.counts,
				[s.activeId]: next
			},
			totals: {
				...s.totals,
				[s.activeId]: (s.totals[s.activeId] ?? 0) + 1
			},
			lifetime: s.lifetime + 1,
			todayDate: today,
			todayCount: s.todayDate === today ? s.todayCount + 1 : 1,
			rounds: reached ? s.rounds + 1 : s.rounds
		});
		if (reached) {
			if (s.sound) playComplete();
			if (s.vibrate) hapticGoal();
		}
		return {
			incremented: true,
			reached
		};
	},
	setActive: (id) => set({ activeId: id }),
	setGoal: (n) => set({ goal: clampGoal(n) }),
	resetCurrent: () => {
		const s = get();
		set({ counts: {
			...s.counts,
			[s.activeId]: 0
		} });
	},
	resetAll: () => set({
		counts: emptyCounts(),
		totals: emptyCounts(),
		todayCount: 0,
		todayDate: todayKey(),
		lifetime: 0,
		rounds: 0,
		goal: 33,
		activeId: "subhanallah"
	}),
	setSound: (v) => set({ sound: v }),
	setVibrate: (v) => set({ vibrate: v }),
	setTheme: (id) => {
		applyTheme(id);
		set({ theme: id });
	},
	setStopAtGoal: (v) => set({ stopAtGoal: v })
}), {
	name: "zikirmatik-said-ucar-v1",
	storage: createJSONStorage(() => typeof window === "undefined" ? memoryStorage : localStorage),
	skipHydration: true,
	partialize: (s) => ({
		activeId: s.activeId,
		counts: s.counts,
		totals: s.totals,
		goal: s.goal,
		todayDate: s.todayDate,
		todayCount: s.todayCount,
		lifetime: s.lifetime,
		rounds: s.rounds,
		sound: s.sound,
		vibrate: s.vibrate,
		theme: s.theme,
		stopAtGoal: s.stopAtGoal
	})
}));
function ZikirApp() {
	const activeId = useZikirStore((s) => s.activeId);
	const counts = useZikirStore((s) => s.counts);
	const totals = useZikirStore((s) => s.totals);
	const goal = useZikirStore((s) => s.goal);
	const todayCount = useZikirStore((s) => s.todayCount);
	const lifetime = useZikirStore((s) => s.lifetime);
	const rounds = useZikirStore((s) => s.rounds);
	const sound = useZikirStore((s) => s.sound);
	const vibrate = useZikirStore((s) => s.vibrate);
	const theme = useZikirStore((s) => s.theme);
	const stopAtGoal = useZikirStore((s) => s.stopAtGoal);
	const tap = useZikirStore((s) => s.tap);
	const setActive = useZikirStore((s) => s.setActive);
	const setGoal = useZikirStore((s) => s.setGoal);
	const resetCurrent = useZikirStore((s) => s.resetCurrent);
	const resetAll = useZikirStore((s) => s.resetAll);
	const setSound = useZikirStore((s) => s.setSound);
	const setVibrate = useZikirStore((s) => s.setVibrate);
	const setTheme = useZikirStore((s) => s.setTheme);
	const setStopAtGoal = useZikirStore((s) => s.setStopAtGoal);
	const rollToday = useZikirStore((s) => s.rollToday);
	const [goalOpen, setGoalOpen] = (0, import_react.useState)(false);
	const [settingsOpen, setSettingsOpen] = (0, import_react.useState)(false);
	const [dualarOpen, setDualarOpen] = (0, import_react.useState)(false);
	const [confirm, setConfirm] = (0, import_react.useState)(null);
	const [draftGoal, setDraftGoal] = (0, import_react.useState)(String(goal));
	const [pulse, setPulse] = (0, import_react.useState)(false);
	const [toast, setToast] = (0, import_react.useState)("");
	const toastTimer = (0, import_react.useRef)(0);
	const dhikr = DHIKRS.find((d) => d.id === activeId) ?? DHIKRS[0];
	const count = counts[activeId] ?? 0;
	const locked = stopAtGoal && count >= goal;
	const left = Math.max(0, goal - count);
	const offset = RING_CIRC * (1 - Math.min(count / Math.max(goal, 1), 1));
	const modalOpen = goalOpen || settingsOpen || dualarOpen || confirm !== null;
	const showToast = (0, import_react.useCallback)((msg) => {
		setToast(msg);
		if (toastTimer.current) window.clearTimeout(toastTimer.current);
		toastTimer.current = window.setTimeout(() => setToast(""), 1800);
	}, []);
	(0, import_react.useEffect)(() => {
		const apply = () => {
			rollToday();
			applyTheme(useZikirStore.getState().theme);
		};
		const unsub = useZikirStore.persist.onFinishHydration(apply);
		useZikirStore.persist.rehydrate();
		if (useZikirStore.persist.hasHydrated()) apply();
		return unsub;
	}, [rollToday]);
	(0, import_react.useEffect)(() => {
		applyTheme(theme);
	}, [theme]);
	const handleTap = (0, import_react.useCallback)(() => {
		const result = tap();
		if (!result.incremented) return;
		setPulse(true);
		window.setTimeout(() => setPulse(false), 120);
		if (result.reached) showToast("Hedefe ulaşıldı");
	}, [tap, showToast]);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			if (e.code !== "Space") return;
			const tag = e.target?.tagName;
			if (tag === "INPUT" || tag === "TEXTAREA" || tag === "BUTTON") return;
			if (modalOpen) return;
			e.preventDefault();
			handleTap();
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [handleTap, modalOpen]);
	(0, import_react.useEffect)(() => {
		setDraftGoal(String(goal));
	}, [goal, goalOpen]);
	const saveGoal = () => {
		const n = clampGoal(Number.parseInt(draftGoal, 10));
		setGoal(n);
		setGoalOpen(false);
		showToast("Hedef güncellendi");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "device",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "bismillah",
					dir: "rtl",
					lang: "ar",
					children: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "title",
					children: "Zikirmatik"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "dhikr-bar",
					id: "dhikrBar",
					role: "tablist",
					"aria-label": "Zikir seçimi",
					children: DHIKRS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						role: "tab",
						"aria-selected": item.id === activeId,
						className: item.id === activeId ? "dhikr-chip active" : "dhikr-chip",
						onClick: () => setActive(item.id),
						children: item.label
					}, item.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "screen",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "arabic",
							id: "arabic",
							dir: "rtl",
							lang: "ar",
							children: dhikr.ar
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "meaning",
							id: "meaning",
							children: dhikr.tr
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "count-wrap",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
								className: "ring",
								width: "180",
								height: "180",
								viewBox: "0 0 180 180",
								"aria-hidden": "true",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
									className: "ring-bg",
									cx: "90",
									cy: "90",
									r: "80"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
									className: "ring-fill",
									id: "ring",
									cx: "90",
									cy: "90",
									r: "80",
									style: { strokeDashoffset: offset }
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "count-num",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									id: "count",
									className: pulse ? "pulse" : void 0,
									"aria-live": "polite",
									children: count
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "ZİKİR" })]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "goal-text",
							children: [
								"Hedef: ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
									id: "goalText",
									children: goal
								}),
								" ",
								"\xA0•\xA0 Kalan: ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
									id: "leftText",
									children: left
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: locked ? "goal-reached show" : "goal-reached",
							id: "goalReached",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
								size: 16,
								strokeWidth: 2.5,
								"aria-hidden": "true"
							}), "Hedefe ulaşıldı • Sıfırla ile devam et"]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "main-btn",
					id: "tap",
					disabled: locked,
					onPointerDown: (e) => {
						if (e.button !== 0) return;
						e.preventDefault();
						handleTap();
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
						size: 22,
						strokeWidth: 2.5,
						"aria-hidden": "true"
					}), "Zikir Çek"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "controls",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "ctrl",
							id: "goalBtn",
							onClick: () => setGoalOpen(true),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Target, { strokeWidth: 2 }), "Hedef"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "ctrl",
							id: "dualarBtn",
							onClick: () => setDualarOpen(true),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { strokeWidth: 2 }), "Dualar"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "ctrl",
							id: "resetBtn",
							onClick: () => setConfirm("current"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { strokeWidth: 2 }), "Sıfırla"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "ctrl",
							id: "settingsBtn",
							onClick: () => setSettingsOpen(true),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { strokeWidth: 2 }), "Ayarlar"]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "stats",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "stat",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: todayCount }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Bugün" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "stat",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: lifetime }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Toplam" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "stat",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: rounds }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Tur" })]
						})
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
			className: "app-footer",
			children: "Said Uçar"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: goalOpen,
			onOpenChange: setGoalOpen,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "overlay" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				className: "modal",
				"aria-describedby": void 0,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "modal-title",
						children: "Hedef Belirle"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "goal-grid",
						children: GOAL_PRESETS.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: Number(draftGoal) === n ? "goal-opt selected" : "goal-opt",
							onClick: () => setDraftGoal(String(n)),
							children: n
						}, n))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "custom-input",
						type: "number",
						min: 1,
						max: 99999,
						inputMode: "numeric",
						placeholder: "Özel hedef",
						value: draftGoal,
						onChange: (e) => setDraftGoal(e.target.value),
						onKeyDown: (e) => {
							if (e.key === "Enter") saveGoal();
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "modal-btns",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn-cancel",
							onClick: () => setGoalOpen(false),
							children: "Vazgeç"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn-save",
							onClick: saveGoal,
							children: "Kaydet"
						})]
					})
				]
			})] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: settingsOpen,
			onOpenChange: setSettingsOpen,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "overlay" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				className: "modal",
				"aria-describedby": void 0,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "modal-head",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
							className: "modal-title",
							children: "Ayarlar"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
							className: "modal-close",
							"aria-label": "Kapat",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { strokeWidth: 2 })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "menu-link",
						onClick: () => {
							setSettingsOpen(false);
							setDualarOpen(true);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "setting-label",
							children: "Dualar"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "setting-desc",
							children: "Arapça, anlam ve zikir toplamları"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
							className: "chev",
							size: 18,
							strokeWidth: 2
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "setting-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "setting-label",
							children: "Ses efekti"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "setting-desc",
							children: "Zikir çekerken kısa bir ses"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: sound ? "toggle on" : "toggle",
							role: "switch",
							"aria-checked": sound,
							"aria-label": "Ses efekti",
							onClick: () => setSound(!sound)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "setting-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "setting-label",
							children: "Titreşim"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "setting-desc",
							children: "Destekleyen cihazlarda titreşim"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: vibrate ? "toggle on" : "toggle",
							role: "switch",
							"aria-checked": vibrate,
							"aria-label": "Titreşim",
							onClick: () => setVibrate(!vibrate)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "setting-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "setting-label",
							children: "Hedefte dur"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "setting-desc",
							children: "Hedefe ulaşınca sayaç kilitlenir"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: stopAtGoal ? "toggle on" : "toggle",
							role: "switch",
							"aria-checked": stopAtGoal,
							"aria-label": "Hedefte dur",
							onClick: () => setStopAtGoal(!stopAtGoal)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "section-title",
						children: "Renk teması"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "color-row",
						children: THEMES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: theme === t.id ? "color-dot active" : "color-dot",
							style: { background: t.accent },
							"aria-label": t.label,
							title: t.label,
							onClick: () => setTheme(t.id)
						}, t.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "dev-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "label",
								children: "Geliştirici"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "name",
								children: "Said Uçar"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "note",
								children: "Profesyonel Zikirmatik"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "danger-btn",
						onClick: () => {
							setSettingsOpen(false);
							setConfirm("all");
						},
						children: "Tüm verileri sil"
					})
				]
			})] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: dualarOpen,
			onOpenChange: setDualarOpen,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "overlay" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				className: "modal",
				"aria-describedby": void 0,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "modal-head",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "modal-title",
						children: "Dualar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
						className: "modal-close",
						"aria-label": "Kapat",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { strokeWidth: 2 })
					})]
				}), DHIKRS.map((item) => {
					const current = counts[item.id] ?? 0;
					const total = totals[item.id] ?? 0;
					const selected = item.id === activeId;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: selected ? "dua-card active" : "dua-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "dua-ar",
								dir: "rtl",
								lang: "ar",
								children: item.ar
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "dua-label",
								children: item.label
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "dua-tr",
								children: item.tr
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "dua-meta",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Bu tur", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: current })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Toplam", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: total })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Kalan", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: Math.max(0, goal - current) })] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "dua-pick",
								onClick: () => {
									setActive(item.id);
									setDualarOpen(false);
									if (!selected) showToast(`${item.label} seçildi`);
								},
								children: selected ? "Şu an seçili" : "Bu zikri seç"
							})
						]
					}, item.id);
				})]
			})] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: confirm !== null,
			onOpenChange: (open) => {
				if (!open) setConfirm(null);
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "overlay" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				className: "modal",
				"aria-describedby": void 0,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "modal-title",
						children: confirm === "all" ? "Tüm veriler silinsin mi?" : "Sayaç sıfırlansın mı?"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "confirm-text",
						children: confirm === "all" ? "Bugünkü, toplam ve tur sayıları da sıfırlanır." : "Bu turdaki zikirler silinir, toplamlar korunur."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "confirm-sub",
						children: "Bu işlem geri alınamaz."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "modal-btns",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn-cancel",
							onClick: () => setConfirm(null),
							children: "Vazgeç"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: confirm === "all" ? "btn-danger" : "btn-save",
							onClick: () => {
								if (confirm === "all") {
									resetAll();
									showToast("Tüm veriler silindi");
								} else {
									resetCurrent();
									showToast("Sayaç sıfırlandı");
								}
								setConfirm(null);
							},
							children: confirm === "all" ? "Sil" : "Sıfırla"
						})]
					})
				]
			})] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: toast ? "toast show" : "toast",
			role: "status",
			children: toast
		})
	] });
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZikirApp, {});
}
//#endregion
export { Home as component };
