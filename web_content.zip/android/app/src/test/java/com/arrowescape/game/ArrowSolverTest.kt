package com.arrowescape.game

import com.arrowescape.game.generator.DeterministicLevelGenerator
import com.arrowescape.game.model.Arrow
import com.arrowescape.game.model.Direction
import com.arrowescape.game.model.Point
import com.arrowescape.game.solver.ArrowSolver
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ArrowSolverTest {

    @Test
    fun testWindingArrowUnobstructedEscape() {
        val arrow = Arrow(
            id = "1",
            points = listOf(Point(0, 2), Point(0, 1), Point(0, 0)),
            row = 0,
            col = 0,
            direction = Direction.UP
        )
        val allArrows = listOf(arrow)
        val canEscape = ArrowSolver.isArrowPathClear(arrow, allArrows, 5, 5)
        assertTrue("Winding arrow pointing UP at row 0 should escape freely", canEscape)
    }

    @Test
    fun testWindingArrowCollision() {
        val arrow1 = Arrow(
            id = "1",
            points = listOf(Point(2, 4), Point(2, 3)),
            row = 3,
            col = 2,
            direction = Direction.UP
        )
        val blocker = Arrow(
            id = "2",
            points = listOf(Point(1, 1), Point(2, 1), Point(3, 1)),
            row = 1,
            col = 3,
            direction = Direction.RIGHT
        )

        val allArrows = listOf(arrow1, blocker)
        val canEscape = ArrowSolver.isArrowPathClear(arrow1, allArrows, 5, 5)
        assertFalse("Arrow path blocked by crossing body segment should be blocked", canEscape)
    }

    @Test
    fun testArrowDensityScaling() {
        val lvl1 = DeterministicLevelGenerator.generateLevel(1)
        assertTrue("Level 1 should have ~10-20 arrows", lvl1.arrows.size in 10..22)

        val lvl5 = DeterministicLevelGenerator.generateLevel(5)
        assertTrue("Level 5 should have 20-40 arrows", lvl5.arrows.size in 20..42)

        val lvl25 = DeterministicLevelGenerator.generateLevel(25)
        assertTrue("Level 25 should have 30-60 arrows", lvl25.arrows.size in 30..62)

        val lvl75 = DeterministicLevelGenerator.generateLevel(75)
        assertTrue("Level 75 should have 50-80 arrows", lvl75.arrows.size in 50..82)

        val lvl250 = DeterministicLevelGenerator.generateLevel(250)
        assertTrue("Level 250 should have 70-120 arrows", lvl250.arrows.size in 68..122)

        val lvl750 = DeterministicLevelGenerator.generateLevel(750)
        assertTrue("Level 750 should have 100-200 arrows", lvl750.arrows.size in 95..205)
    }

    @Test
    fun test1000LevelSolvabilityAcrossTiers() {
        val testLevels = listOf(1, 5, 15, 35, 75, 150, 350, 600, 950)

        for (lvlId in testLevels) {
            val level = DeterministicLevelGenerator.generateLevel(lvlId)
            assertNotNull("Level $lvlId must generate successfully", level)
            assertTrue("Level $lvlId must have arrows", level.arrows.isNotEmpty())

            val solution = ArrowSolver.solveLevel(level.arrows, level.gridRows, level.gridCols)
            assertNotNull("Level $lvlId must be 100% solvable without deadlock", solution)
            assertEquals("Solution size must equal arrows count", level.arrows.size, solution?.size)
        }
    }
}
