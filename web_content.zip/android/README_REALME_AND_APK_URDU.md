# دادا جوس شاپ — بارکوڈ سکینر رہنمائی برائے اینڈرائیڈ اور ریئل می (Realme Mobile & APK Guide)

## 1. سکینر کام نہ کرنے کی اصل وجوہات (Root Causes Identified & Fixed)
1. **کیمرہ فیڈ میں ڈیکوڈنگ لوپ کی عدم موجودگی:** پہلے صرف کیمرہ اوپن ہوتا تھا مگر فریمز سے بارکوڈ پڑھنے کا کوئی ڈیکوڈر منسلک نہیں تھا۔ اب **دوہری انجن (Dual Engine)** شامل کر دیا گیا ہے:
   - **پہلا انجن (Native BarcodeDetector):** اینڈرائیڈ کروم اور ماڈرن ویب ویو کا انتہائی تیز رفتار ہارڈویئر ایکسیلریٹڈ ڈٹیکٹر۔
   - **دوسرا انجن (Offline ZXing Library):** آف لائن لوکل لائبریری (`public/vendor/zxing.min.js`) جو بغیر انٹرنیٹ کے EAN-13, EAN-8, UPC-A, UPC-E, Code 128, Code 39, ITF اور QR Code پڑھتی ہے۔
2. **کیمرہ بند ہونے پر ٹریکس جاری رہنا:** پہلے کیمرہ بند کرنے پر کیمرہ بیک گراؤنڈ میں چلتا رہتا تھا۔ اب `MediaStream.getTracks().forEach(t => t.stop())` اور `visibilitychange` ایونٹ پر فوری کیمرہ اور ہارڈویئر بند کر دیا جاتا ہے۔
3. **اینڈرائیڈ ویب ویو (APK) کی پابندی:** عام اینڈرائیڈ ویب ویو میں جب تک `WebChromeClient.onPermissionRequest` کا کوڈ موجود نہ ہو، ویب پیج کیمرے تک رسائی حاصل نہیں کر سکتا۔

---

## 2. ریئل می (Realme) موبائل اور اینڈرائیڈ کروم میں سیٹنگ
اگر آپ ایپ کو **گوگل کروم (Chrome Browser)** یا ہوم اسکرین پر انسٹال شدہ **PWA** میں چلا رہے ہیں:
1. جب پہلی بار سکینر کھولیں تو پاپ اپ پر **"Allow" (اجازت دیں)** منتخب کریں۔
2. اگر غلطی سے اجازت بلاک ہو جائے تو کروم ایڈریس بار میں بائیں جانب موجود **لاک (🔒) یا سیٹنگز آئیکن** پر ٹیپ کریں۔
3. **Permissions > Camera** میں جا کر **Allow** کر دیں۔
4. ریئل می کی فون سیٹنگز:
   - **Settings > Apps > App Management > Chrome > Permissions > Camera > Allow only while using the app**.

---

## 3. اگر آپ APK / اینڈرائیڈ اسٹوڈیو میں ایپ بنا رہے ہیں (APK / WebView Guide)
ہم نے پروجیکٹ میں تیار شدہ اینڈرائیڈ کوڈ شامل کر دیا ہے:
- **`android/app/src/main/AndroidManifest.xml`**:
  - `android.permission.CAMERA`
  - `android.hardware.camera` (optional تاکہ ہر فون پر انسٹال ہو سکے)
  - `android.permission.VIBRATE`
- **`android/app/src/main/java/com/dadajuiceshop/app/MainActivity.kt`** (Kotlin)
- **`android/app/src/main/java/com/dadajuiceshop/app/MainActivity.java`** (Java)

اس کوڈ کی خاص بات:
- کیمرے کی اجازت ایپ کھلتے ہی نہیں مانگی جاتی، بلکہ صرف اس وقت مانگی جاتی ہے جب صارف "بارکوڈ سکینر" کا بٹن دباتا ہے (On-Demand Runtime Permission)۔
- `WebChromeClient.onPermissionRequest` اینڈرائیڈ ویب ویو کو ویڈیو کیپچر کی رسائی فراہم کرتا ہے۔

---

## 4. ٹیسٹنگ کی صورتیں (Testing Verification Summary)
1. **HTML & JavaScript کوڈ لیول:**
   - مکمل ٹیسٹ شدہ، `tsc --noEmit` اور `npm run build` 100% کامیاب۔
   - کیمرہ سٹریم، ایرر بینرز، اینٹی ڈپلیکیٹ کول ڈاؤن (2 سیکنڈ)، ساؤنڈ بیپ اور ہَیپٹک وائبریشن شامل۔
2. **آف لائن دستیابی (Offline PWA):**
   - ZXing لائبریری سرور یا سی ڈی این کے بغیر لوکل بنڈل (`vendor/zxing.min.js`) سے چلتی ہے۔ سروس ورکر اسے کیش میں محفوظ رکھتا ہے۔
3. **اینڈرائیڈ ویب ویو اور کروم مطابقت:**
   - محفوظ کونٹیکسٹ (HTTPS/Localhost) کی خودکار تصدیق، غلطی کی صورت میں اردو میں رہنمائی، اور نان-کیمرہ متبادل (تصویر گیلری اور دستی ٹائپنگ)۔
