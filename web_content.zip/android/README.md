# Zikirmatik Android Projesi

Bu proje, web uygulamasını Android WebView içinde çalıştırmak üzere hazırlanmıştır.

## APK oluşturma
1. Android Studio'yu açın.
2. Bu klasördeki `android` klasörünü **Open** ile açın.
3. Gradle senkronizasyonunun tamamlanmasını bekleyin.
4. Menüden **Build > Generate App Bundles or APKs > Generate APKs** seçin.
5. APK genellikle `android/app/build/outputs/apk/debug/app-debug.apk` altında oluşur.

Not: Web uygulamasının kullandığı harici CDN/API kaynakları internet bağlantısı gerektirebilir.
