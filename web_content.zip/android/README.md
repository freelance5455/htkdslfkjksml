# YOOYYAA

Private messenger for a thin signal. Afaan Oromoo, Amharic, and English.

The APK in this folder is already signed and ready to install on Android 8 or newer. Copy `YOOYYAA.apk` to the phone and open it. If Android asks, allow installs from that source.

## What the phone build does

- Language choice, then an ID read. The name is locked. The ID number is hashed on the device and discarded — it is not kept.
- Live selfie from the front camera (one face, one blink). Gallery is not used.
- Chats, people, and calls. Messages are AES-256-GCM on the phone.
- Weak or offline path: messages wait, then send when a path returns. Weak signal and data saver keep calls on audio.
- Share the APK file itself (Bluetooth, Nearby Share, Xender, WhatsApp, Telegram) from Settings, Share the app.
- Operator desk: tap the version line seven times. The password is checked in the app process, not written into the page. Five wrong tries lock it for 10 minutes. A session ends after one hour.

There is no native code, so one APK covers every phone type and stays well under 10 MB. A worldwide relay needs a server you control; until then messages stay on the phone that created them.

## Rebuild

Windows, from this folder, with Android SDK platform 35 and build-tools 35 installed:

```
BUILD.bat
```

Set `ANDROID_HOME` if the SDK is not in `%LOCALAPPDATA%\Android\Sdk`.

The demo signing key is `yooyyaa.jks` (alias `yooyyaa`). Replace it before any real store listing.
