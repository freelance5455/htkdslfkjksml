# DOST AI — NATIVE ANDROID PERSONAL ASSISTANT
**Kotlin & Jetpack Compose Native Android Project**

Welcome to **DOST AI**, a personal, practical Android AI agent designed to assist with everyday tasks, phone operations, voice interactions, productivity, and cryptocurrency market analysis.

---

## 📱 Project Architecture

```
android/
├── build.gradle.kts                   # Root Gradle build script
├── settings.gradle.kts                # Project modules configuration
├── gradle.properties                  # JVM memory & AndroidX flags
└── app/
    ├── build.gradle.kts               # App dependencies (Compose, Material3, Gemini SDK, Retrofit)
    └── src/main/
        ├── AndroidManifest.xml        # Permissions, queries allowlist, Services, Activity
        ├── res/
        │   ├── values/strings.xml     # App strings & accessibility description
        │   ├── values/themes.xml      # Dark mode Material Theme
        │   └── xml/accessibility_service_config.xml # Security-hardened accessibility config
        └── java/com/dostai/assistant/
            ├── DostApplication.kt     # Application init & notification channel creation
            ├── MainActivity.kt        # Jetpack Compose UI scaffold & Bottom navigation
            ├── ai/
            │   └── GeminiBrain.kt     # Gemini Generative AI SDK, Roman Urdu/Urdu/English prompts
            ├── intents/
            │   └── AndroidActionEngine.kt # Safe Android Intent launcher, strict allowlist & confirmation
            ├── voice/
            │   └── DostSpeechManager.kt # SpeechRecognizer & TextToSpeech engine
            ├── services/
            │   ├── DostForegroundService.kt # Persistent notification, quick action buttons, wake lock
            │   └── DostAccessibilityService.kt # Authorized accessibility helper (no password access)
            ├── crypto/
            │   ├── BinanceRepository.kt # Retrofit client for live Binance 24h ticker & Klines
            │   └── TechnicalAnalysisEngine.kt # EMA 9/20/200, ATR, Support/Resistance & Paper Trading
            └── ui/theme/
                └── Theme.kt           # Modern dark color palette
```

---

## 🚀 Setup & Build Instructions in Android Studio

1. **Prerequisites**:
   - Android Studio Hedgehog (2023.1.1) or newer (Iguana, Jellyfish, Koala, Ladybug).
   - JDK 17 (configured in Android Studio under *Settings > Build, Execution, Deployment > Build Tools > Gradle > Gradle JDK*).
   - Android SDK API 35 (Android 15) with Build Tools 35.0.0.

2. **Open the Project**:
   - In Android Studio, select **Open** and select the `/android` folder.
   - Wait for Gradle Sync to complete.

3. **Configure your Gemini API Key**:
   - Add your Gemini API key in `local.properties`:
     ```properties
     GEMINI_API_KEY=AIzaSy...your_key_here
     ```
   - Or configure it via Firebase AI Logic / App Check if building with Firebase backend.

4. **Run on Device / Emulator**:
   - Connect an Android device with Developer Options & USB Debugging enabled (or start an emulator with Google Play Services).
   - Press **Run 'app'** (`Shift + F10`).

---

## 🔒 Permissions & Security Model

1. **Strict Local Allowlist**:
   - AI cannot trigger arbitrary system actions or execute arbitrary code.
   - App intents are restricted to known safe packages: Camera, YouTube, Chrome, Settings, Messages, Phone dialer, Google Maps, and WhatsApp.
2. **Mandatory Confirmation for Sensitive Actions**:
   - Sending SMS or dialing telephone numbers always prompts an explicit confirmation dialog before executing.
3. **Accessibility Security Boundary**:
   - The optional `DostAccessibilityService` strictly ignores any `isPassword` fields or biometric credential dialogs. It cannot and will not bypass lockscreens.
4. **No Financial Keys or Passwords**:
   - Crypto analysis uses 100% public read-only Binance market data. DOST AI does not request or store private exchange API keys.

---

## ⚠️ Known Android OS Limitations & Real Environment Realities

1. **Continuous Background Microphone Listening**:
   - Android 12, 13, 14, and 15 strictly restrict background microphone access (`FOREGROUND_SERVICE_MICROPHONE`). Android system stops microphone access if an app attempts continuous silent audio recording without active user presence.
   - **DOST AI's Solution**: Provides a persistent foreground notification with quick "Talk" action button, lockscreen widget action, and instant Push-To-Talk within the app.
2. **Doze Mode & Battery Restrictions**:
   - Android vendors (Xiaomi, Samsung, OnePlus) aggressively kill background services unless battery optimization is disabled. DOST AI provides a direct shortcut to `ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`.
3. **SMS Carrier Fees**:
   - Sending SMS uses standard device telephony intents, subject to cellular carrier charges and user confirmation.

---

## 🧪 Test Cases

- **Test 1: Roman Urdu Comprehension**
  - Prompt: `"Bhai aaj ka mausam kaisa hai aur BTC ka rate kya hai?"`
  - Expected: DOST AI responds in natural Roman Urdu and provides current crypto market context.
- **Test 2: Phone Action Proposal**
  - Prompt: `"Camera kholo"`
  - Expected: DOST AI emits an `open_app` action card for Camera. Tapping it triggers `android.media.action.IMAGE_CAPTURE`.
- **Test 3: Sensitive SMS Confirmation**
  - Spoken: `"Ali ko message bhejo ke main 5 minute mein phonch raha hoon"`
  - Expected: Shows confirmation dialog asking the user to confirm recipient and body before launching SMS composer.
- **Test 4: Crypto Indicator Accuracy**
  - Symbol: `BTCUSDT`, Timeframe: `1h`
  - Expected: Real calculated EMA 9, EMA 20, EMA 200, ATR 14, Support & Resistance levels with clear badge separating verified data from AI tactical interpretation.
