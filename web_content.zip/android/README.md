# NEXCODE AI — Native Android App (Kotlin + Jetpack Compose)

**Tagline:** *Build Anything. Code Everything.*

Genuine native Android application (`package com.nexcode.ai`) built with **Kotlin** and **Jetpack Compose**, preserving the exact design, black/blue/cyan/purple theme, and features of NEXCODE AI without any WebView or browser wrapper.

## Architecture & Screens

1. **Permissions Onboarding (`OnboardingSetupScreen.kt`)**
   - Opens on first launch (`!onboarded`), prompts for **Microphone**, **Cam & Screen Sharing**, and **Clipboard** + **Chat Language**, then launches directly into **Chat**.

2. **AI Coding Chat (`ChatScreen.kt` + `MarkdownCodeView.kt`)**
   - Multi-turn AI chat over `POST /api/chat` (`NexcodeApiClient.kt` via OkHttp) with **Stop** cancellation and **Regenerate**.
   - Native Android attachment picker (`ActivityResultContracts.OpenDocument`) for **photos**, **videos**, and **source code files**.
   - Fenced Markdown code blocks rendered inside `#000000` syntax cards with monospace horizontal scroll, line counts, and **Copy** / **Copy Code** buttons backed by Android `ClipboardManager`.

3. **Persistent History Drawer (`HistoryDrawerContent.kt` + `SessionStorage.kt`)**
   - Stores chat, media, and voice call sessions locally in internal JSON (`nexcode_history_sessions.json`).
   - Supports **+ New**, **Search**, **Rename**, **Delete**, and **Clear All History**.

4. **Real-Time Voice Call & Live Vision (`VoiceCallScreen.kt`)**
   - **Native Audio (`LiveAudioEngine.kt` + `VoiceCallService.kt`)**: Hardware-accelerated 16kHz `AudioRecord` (with `AcousticEchoCanceler` & `NoiseSuppressor`) and 24kHz `AudioTrack` PCM streaming over `/api/live` WebSocket, running inside a `FOREGROUND_SERVICE_TYPE_MICROPHONE` service so calls stay connected while switching apps.
   - **Dynamic Language Switching**: Starts every call in **English** and switches instantaneously (Urdu, Roman Urdu, Hindi, Arabic, Punjabi, etc.) via spoken/typed detection or the language selector.
   - **System-Wide Screen Sharing (`ScreenCaptureService.kt` + `FloatingSharingOverlay.kt`)**: Genuine Android `MediaProjection` capture across WhatsApp, Roblox, Chrome, Settings, and Gallery, with `FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION`, `PARTIAL_WAKE_LOCK`, adaptive intervals, `VirtualDisplay` resize reuse, `FLAG_SECURE` detection, Pause/Resume/Stop notification controls, and draggable overlay indicator (`SYSTEM_ALERT_WINDOW`).
   - **Fast Camera Vision (`NativeCameraManager.kt`)**: Jetpack CameraX `STRATEGY_KEEP_ONLY_LATEST` analyzer with live preview and **Flip Lens** (Back ↔ Front).
   - **Call Controls**: `Screen Sharing` / `Stop Sharing`, `Pause` / `Resume`, `Floating Indicator`, `Cam` / `Stop Cam`, `Attach Pic / Video`, `Mute`, `Chat` drawer, `Privacy` notice, and `End Call`.

## Permissions (`AndroidManifest.xml`)
- `INTERNET`, `ACCESS_NETWORK_STATE`
- `RECORD_AUDIO`, `MODIFY_AUDIO_SETTINGS`, `CAMERA`
- `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MEDIA_PROJECTION`, `FOREGROUND_SERVICE_MICROPHONE`
- `POST_NOTIFICATIONS`, `WAKE_LOCK`, `SYSTEM_ALERT_WINDOW`

## Building & Installing the APK in Android Studio

1. Open `/android` in **Android Studio** (Ladybug / JDK 17, `compileSdk = 35`, `minSdk = 26`).
2. Sync Gradle (`File > Sync Project with Gradle Files`).
3. Optional: Override the backend URL if testing locally against an emulator:
   ```bash
   ./gradlew assembleDebug -PNEXCODE_API_URL=http://10.0.2.2:3000
   ```
   Or build with the default production backend URL:
   ```bash
   ./gradlew assembleDebug
   ```
4. Build a Release APK:
   ```bash
   ./gradlew assembleRelease
   ```
5. Install on a connected Android phone via USB debugging:
   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```
