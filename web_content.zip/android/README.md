# Vishal Tools

A beginner-friendly Android app (Kotlin + Jetpack Compose) with offline utilities:

- Battery Info
- Storage Info
- Device Info
- Calculator
- Flashlight
- Network Info

Package name: `com.vishal.tools`

No Firebase, no login, no ads, no internet required for core features.

## Open in Android Studio

1. Install [Android Studio](https://developer.android.com/studio) (Ladybug / Meerkat or newer is fine).
2. Open Android Studio.
3. Choose **File → Open…** (or **Open** on the welcome screen).
4. Select this folder (`VishalTools`) — the one that contains `settings.gradle.kts`.
5. Wait for Gradle Sync to finish. If Android Studio offers to use a JDK, pick **jbr-17** (the bundled JetBrains Runtime).
6. Plug in a phone with USB debugging, or start an emulator (**Device Manager → Create Device**).
7. Press the green **Run** button.

If Gradle asks to upgrade the Android Gradle Plugin, you can accept the suggested version.

## Build a debug APK (for installing on your phone)

In Android Studio:

1. **Build → Build Bundle(s) / APK(s) → Build APK(s)**
2. When it finishes, click **locate** in the notification.

The file is:

```
app/build/outputs/apk/debug/app-debug.apk
```

Copy that APK to your phone and open it to install (enable **Install unknown apps** for Files / Chrome if Android asks).

## Build a release APK (unsigned)

**Build → Generate Signed App Bundle / APK** is the Play Store path.

For a local release APK without Play signing:

1. Open the **Terminal** tab in Android Studio.
2. Run:

```
./gradlew assembleRelease
```

On Windows:

```
gradlew.bat assembleRelease
```

The APK will be at:

```
app/build/outputs/apk/release/app-release-unsigned.apk
```

(or `app-release.apk` if you configured a signing key).

## Permissions

| Permission | Why |
|---|---|
| `CAMERA` / `FLASHLIGHT` | Turning the LED torch on and off |
| `ACCESS_NETWORK_STATE` | Showing Wi-Fi vs mobile vs offline |

Camera is **not required** to install the app (`required="false"`). Phones without a flash show a clear “no flashlight” state.

Battery, storage, and device info do not need extra permissions.

## Project map

```
VishalTools/
  settings.gradle.kts          // project name + module list
  build.gradle.kts             // plugin versions
  app/build.gradle.kts         // SDK versions + Compose libraries
  app/src/main/AndroidManifest.xml
  app/src/main/java/com/vishal/tools/
    MainActivity.kt            // app entry
    VishalToolsApp.kt          // navigation
    tools/                     // battery, storage, flashlight, network
    ui/screens/                // one file per screen
    ui/theme/                  // dark mint theme
```
