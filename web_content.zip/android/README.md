# Jagiroad Higher Secondary School: Android app

Native Android (Kotlin) wrapper around the school web app (`app/src/main/assets/index.html`).

## Build
1. Open this folder in **Android Studio** (Ladybug or newer). Let it sync. It creates the Gradle wrapper.
2. Run on a phone or emulator (Android 10+), or Build > Build APK(s).

## Navigation
- The Android Back button and the top-left ‹ button use the same stack.
- Back order: close dialog or image viewer, then close the side menu, then go to the previous screen, then (on the Home screen) minimise the app.
- Same-tab taps do not stack duplicates. Scroll position is restored when going back.

## Permissions (real Android permissions only)
| Permission | Why | When requested |
|---|---|---|
| `POST_NOTIFICATIONS` (Android 13+) | School alerts | Right after login (system dialog opens directly). If dismissed, the Allow banner on Home or the Notifications page asks again |
| `INTERNET` | Supabase cloud database | Normal permission, auto-granted, not shown in Settings |

Not requested, because the feature does not exist or needs no permission: camera, location, microphone, storage. Photos/PDF are picked with the system picker, and files are saved to Downloads through MediaStore.

States handled: not asked (shows explanation first), granted, denied once (asks again later from the banner), permanently denied (dialog + **Open Settings** button that opens the app's Android Settings page).
Settings > Apps > Jagiroad Higher Secondary School > Permissions shows only Notifications, and shows "No permissions allowed" until it is granted.

## Test checklist
- Back from: login screen, every bottom/side menu page, sub-pages (student details, edit homework, form builder, forms response), image viewer, side menu, notification dialog. On Home, Back minimises.
- Notifications: Allow, Deny (once), Deny twice (then Open Settings appears), re-enable in Settings and return to the app (banner disappears).
- Pick a profile photo / PDF; Download admit card (saves to Downloads); Print admit card.

## Known limits
- Alerts appear while the app is open or recently in the background. Alerts when the app is fully closed need Firebase Cloud Messaging + a server.
- minSdk is 29 (Android 10) so no storage permission is needed.
