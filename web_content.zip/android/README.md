# JARVIS - Native Android AI Voice Assistant

A native Android application built with **Kotlin** and **Jetpack Compose**, designed with a futuristic cyber HUD interface, on-device local storage, and extensible voice architecture.

---

## 📱 Project Highlights & Architecture

- **100% Native Android**: Built using modern Kotlin and Jetpack Compose Material 3.
- **Local Storage**: Uses Jetpack DataStore Preferences for storing all configuration on the device without third-party cloud lock-in.
- **Navigation Compose**: Type-safe navigation between the Main HUD, Settings, and Incoming Call Screen.
- **Audio & Voice Ready**:
  - `ArcReactorMicButton`: Custom Jetpack Compose Canvas rendering pulsating futuristic reactor rings.
  - `WaveformVisualizer`: Animated audio frequency bars responding to voice activity.
  - `JarvisVoiceInteractionService`: On-device Android `SpeechRecognizer` and `TextToSpeech` integration.
- **Automation & Background Support**:
  - `JarvisNotificationListenerService`: Intercepts system notifications for vocal briefings.
  - `MorningBriefingReceiver`: Handles exact alarms and WorkManager scheduled triggers.

---

## 🛠️ How to Open and Run in Android Studio

1. **Prerequisites**:
   - Android Studio Ladybug (2024.2+) or newer
   - JDK 17 or higher
   - Android SDK 35 (API 35)

2. **Open in Android Studio**:
   - Launch Android Studio
   - Click **File > Open**
   - Select the `android` directory
   - Allow Gradle to sync dependencies (`libs.versions.toml`)

3. **Build & Run**:
   - Connect an Android device or start an emulator running API 26+
   - Press **Shift + F10** or the green **Run** button to install and launch `com.jarvis.assistant`

---

## 📂 Project Structure

```
android/
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/jarvis/assistant/
│       │   ├── JarvisApplication.kt
│       │   ├── MainActivity.kt
│       │   ├── data/
│       │   │   ├── local/PreferencesManager.kt
│       │   │   └── model/JarvisSettings.kt
│       │   ├── receiver/
│       │   │   └── MorningBriefingReceiver.kt
│       │   ├── service/
│       │   │   ├── JarvisNotificationListenerService.kt
│       │   │   └── JarvisVoiceInteractionService.kt
│       │   └── ui/
│       │       ├── components/
│       │       │   ├── ArcReactorMicButton.kt
│       │       │   └── WaveformVisualizer.kt
│       │       ├── screens/
│       │       │   ├── JarvisCallScreen.kt
│       │       │   ├── MainScreen.kt
│       │       │   └── SettingsScreen.kt
│       │       └── theme/
│       │           ├── Color.kt
│       │           ├── Theme.kt
│       │           └── Type.kt
│       └── res/values/
│           ├── colors.xml
│           ├── strings.xml
│           └── themes.xml
├── gradle/
│   └── libs.versions.toml
├── build.gradle.kts
├── gradle.properties
└── settings.gradle.kts
```
