# Arrow Escape — Native Android Game & Firebase Setup Guide

## 1. Project Specifications
- **Package Name**: `com.arrowescape.game`
- **Language**: Kotlin 2.0.21
- **UI Toolkit**: Jetpack Compose (BOM 2024.10.01)
- **Min SDK**: 26 (Android 8.0) | **Target SDK**: 35 (Android 15)
- **Local Persistence**: Room Database 2.6.1 + Jetpack Preferences DataStore 1.1.1
- **Cloud Backend**: Firebase Authentication + Cloud Firestore

---

## 2. Firebase & Google Sign-In Setup

### Step A: Create Firebase Project
1. Go to the [Firebase Console](https://console.firebase.google.com/).
2. Create a new Firebase project named **Arrow Escape**.
3. Under **Build > Authentication**, enable **Google** sign-in provider.
4. Under **Build > Firestore Database**, create a database in your preferred region.

### Step B: Register Android App
1. In Project Overview, click the **Android** icon to add an Android app.
2. Enter the Package Name: `com.arrowescape.game`.
3. Enter an App Nickname: `Arrow Escape Android`.
4. Provide the **SHA-1** and **SHA-256** certificate fingerprints (see Step C below).
5. Download `google-services.json` and move it to `android/app/google-services.json`.

### Step C: Retrieve SHA-1 and SHA-256 Fingerprints
In terminal or Android Studio terminal:
```bash
cd android
./gradlew signingReport
```
Look for `Variant: debug` and copy the `SHA1` and `SHA-256` hashes into the Firebase Console.

### Step D: Credential Manager Web Client ID
1. In the Firebase Console under **Authentication > Sign-in method > Google**, copy the **Web client ID**.
2. Paste this value into `android/app/src/main/res/values/strings.xml`:
```xml
<string name="default_web_client_id">YOUR_ACTUAL_CLIENT_ID.apps.googleusercontent.com</string>
```

---

## 3. Deploying Firestore Security Rules
To ensure secure synchronization across both Web and Android:
```bash
firebase deploy --only firestore:rules
```
The rules in `firestore.rules` protect user data at `users/{userId}/progress/*`, only allowing access if `request.auth.uid == userId`.

---

## 4. Running Automated Tests
Run the deterministic solver and solvability verification test suite:
```bash
./gradlew test
```
This runs `ArrowSolverTest`, which validates:
- Arrow directional clear-path escape mechanics
- Collision and blocked-state detection
- Guaranteed solvability across Beginner, Intermediate, Advanced, Master, and Ultimate tiers
- Hint system accuracy

---

## 5. Building Signed Release APK & Android App Bundle (AAB)

### Generate Release Keystore
```bash
keytool -genkey -v -keystore arrow-escape-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias arrowkey
```

### Build APK:
```bash
./gradlew assembleRelease
```
Output: `android/app/build/outputs/apk/release/app-release-unsigned.apk`

### Build AAB (Google Play):
```bash
./gradlew bundleRelease
```
Output: `android/app/build/outputs/bundle/release/app-release.aab`
