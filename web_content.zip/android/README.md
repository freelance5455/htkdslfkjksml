# S Sanskar AI

Created by Aryan Renacia

Private personal Android AI assistant foundation.

## Current capabilities
- Gemini API chat
- Local conversation memory
- Voice input
- Text-to-speech
- Model selector
- Agent decision JSON foundation
- Android AccessibilityService foundation
- Clean Compose UI

## API key
The project intentionally does NOT contain the API key.

1. Create `local.properties` in the project root.
2. Add:
   GEMINI_API_KEY=YOUR_NEW_KEY
3. Keep `local.properties` private.

## Build
Open the project in Android Studio and let Gradle sync.
Then build the debug APK.

## Important
AccessibilityService and screen-capture capabilities require explicit Android permissions/consent. They are not silently enabled by the app.

The current agent engine has only a small safe action vocabulary. Expand the action executor before adding additional phone controls.
