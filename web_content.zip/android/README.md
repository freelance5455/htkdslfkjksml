# 002 AI - Android APK Packaging Guide

## Why the original APK showed a blank white screen
1. **ES Module CORS Restriction on `file://`**: Chromium WebViews block `<script type="module" crossorigin>` when loaded from local `file://` paths.
2. **Missing DOM Storage in WebSettings**: Android's default `WebView` disables `domStorageEnabled`, which crashes `localStorage` calls synchronously.
3. **`nomodule` suppression**: Chromium suppresses `<script nomodule>` because it supports modern JS, so neither module nor nomodule ran.

## What is fixed in this build
- **Universal Hybrid Bootloader**: `dist/index.html` boots directly via SystemJS if modern ES modules are blocked by `file://` CORS.
- **Safe Storage Fallback**: `safeStorage.ts` provides in-memory fallback if `domStorageEnabled` is off.
- **Removed `crossorigin`**: Prevents CORS null-origin blocks on styles and scripts.
- **Visual Pre-mount Indicator**: Shows 002 branded splash while WebGL and React initialize.
- **React ErrorBoundary**: Catches any rendering failure and displays a diagnostic recovery screen instead of a white page.

## How to assemble the APK in Android Studio
1. In your Android Studio project, copy the **contents of the `dist` folder** directly into:
   `app/src/main/assets/`
   (You should have `app/src/main/assets/index.html` and `app/src/main/assets/assets/...`).
2. Replace `MainActivity.kt` with the included `android/MainActivity.kt`.
3. Ensure `AndroidManifest.xml` has `INTERNET` and `RECORD_AUDIO` permissions.
4. Build APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Gemini Backend Note
The Gemini API key must NEVER be stored in the APK.
Your APK will connect to the backend server via HTTPS (configured in **Settings > Android APK Packaging** or default cloud URL).
