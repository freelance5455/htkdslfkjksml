# Caliber — native Android (Kotlin + Compose)

Offline Free Fire optimizer. **No INTERNET permission.** minSdk 24.

## Build the APK in Android Studio

1. Install [Android Studio](https://developer.android.com/studio) (Koala or newer) and the Android SDK 35 + a JDK 17.
2. **File → Open** and select this `android/` folder.
3. Let Gradle sync. If the wrapper JAR is missing, Android Studio offers to generate it — accept.
4. Plug in a phone with **USB debugging** (Settings → About phone → tap Build number 7 times → Developer options → USB debugging), or start an emulator (API 24+).
5. Click **Run**. To export an APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**. The file lands in `app/build/outputs/apk/debug/app-debug.apk`.
6. Install: drag the APK onto the device, or `adb install -r app/build/outputs/apk/debug/app-debug.apk`.

## What the APK reads

- CPU: `Build.SOC_MODEL` (API 31+), `Build.HARDWARE`, `/proc/cpuinfo`, core count, `/sys/.../cpuinfo_max_freq`
- GPU: EGL + `glGetString(GL_RENDERER)`
- RAM: `ActivityManager.MemoryInfo`
- Storage: `StatFs` + UFS/eMMC sysfs hints
- Display: real pixels, inches, `Display.getSupportedModes`, current mode, densityDpi
- Touch: motion-event interval test on the Touch tab (otherwise estimated from refresh)
- Battery + thermal: `ACTION_BATTERY_CHANGED`, `PowerManager.getCurrentThermalStatus` (API 29+)
- Blocked nodes show **Unavailable** or an estimate — the app does not crash

## Apply the DPI

Write down the original density first.

- ADB: `adb shell wm density <recommended>` and restore with `adb shell wm density reset`
- Manual: Settings → Developer options → **Smallest width** → the number Caliber prints
