# Pocket Toolkit - Native Android Application

**Developer:** Syed Salman Mehdi  
**Application ID:** `com.salmanmehdi.pockettoolkit`  
**Compatibility:** Android 7.0+ (Min SDK 24, Target SDK 34)  
**Architecture:** Single Activity, Jetpack Compose, Material 3, Room SQLite, StateFlow  

---

## 1. How to Preview the App in Android Studio

1. Open **Android Studio** (Ladybug or Koala edition with JDK 17).
2. Select **Open** and choose this project directory.
3. Allow Gradle to synchronize dependencies.
4. Under **Device Manager**, launch any virtual device (e.g. Pixel 8 running Android 14).
5. Click **Run 'app'** (or press Shift + F10) to preview.

---

## 2. How to Build a Debug APK (Free Tools)

Run the Gradle wrapper from this directory:

```bash
# On Linux / macOS:
./gradlew assembleDebug

# On Windows:
gradlew.bat assembleDebug
```

The debug APK file is generated at:
`app/build/outputs/apk/debug/app-debug.apk`

---

## 3. How to Install on a Physical Android Phone

1. **Enable Developer Options & USB Debugging:**
   - Go to **Settings > About Phone** on your device.
   - Tap **Build Number** 7 times.
   - Go to **Settings > System > Developer Options** and enable **USB Debugging**.
2. **Connect Phone via USB:**
   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```
3. **Alternatively, Sideload directly:**
   - Send `app-debug.apk` to your phone via Google Drive, Telegram, or USB cable.
   - Tap the APK file in the Files app.
   - Tap "Allow from this source" when prompted by Android, then tap **Install**.

---

## 4. How to Build a Signed Release APK for Sharing

1. In Android Studio, select **Build > Generate Signed Bundle / APK...**
2. Choose **APK** and click **Next**.
3. Create or specify your Key store path and password.
4. Select build variant **release**.
5. Check V1 (Jar Signature) and V2 (Full APK Signature).
6. Click **Finish**. The output signed APK will be in `app/release/app-release.apk`.

---

## 5. Offline Operation & System Permissions

- **Offline Utilities:** The scientific calculator, financial/everyday math, unit converters, password generator, offline notes, to-do items, shopping lists, and expense splitter are 100% offline.
- **Privacy Hardening:** No advertising, no analytics, no remote tracking, and no external cloud database requirements.
- **Camera Permission:** Only requested when you open the QR code scanner.
