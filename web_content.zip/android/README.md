# MDCAT/NUMS Prep — Android project

This is an Android Studio project wrapping the supplied single-file mobile UI in a native Android app.

## Included
- Mobile-first MDCAT/NUMS UI
- MCQ practice, explanations, mock-test flow, progress, mistakes, settings, notifications
- Google Play Billing integration for subscription products
- Premium bridge from the HTML UI to native Google Play Billing

## Before production
1. Open the project in Android Studio.
2. Create these subscription products in Play Console:
   - `premium_monthly`
   - `premium_3months`
   - `premium_yearly`
3. Configure the base plans/offers and prices in Play Console.
4. Test billing with Play Console test accounts.
5. Replace demo/local question data with your real question database/backend.
6. Add secure server-side purchase verification before granting durable premium entitlement.
7. Add a privacy policy and complete Play Console Data safety/store listing requirements.
8. Build a signed Android App Bundle (AAB) for Play Console.

The package name is `com.mdcatnums.prep`.


## Production starter added
A sibling `backend/` folder is included in the complete starter ZIP. It provides:
- Google Play subscription token verification
- A remote question-bank endpoint
- Environment-variable based Google credentials
- A structure for moving Premium entitlement off localStorage

The backend is intentionally not deployed because it requires your own Google Play/Cloud account and credentials.


### Logo
The supplied MDCAT & NUMS Presentation logo is configured as the launcher icon.

### Build APK
Open this `android` folder in Android Studio, allow Gradle sync, then use:
Build > Build App Bundle(s) / APK(s) > Build APK(s).
