AETHERA - Android project (WebView wrapper around the game)

Build the APK:
1. Install Android Studio (free): https://developer.android.com/studio
2. File > Open > select this "android" folder. Let Gradle sync (it downloads what it needs).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
   The file appears in app/build/outputs/apk/debug/app-debug.apk
4. Copy it to your phone and install (allow "install unknown apps").

The game itself is app/src/main/assets/index.html. Edit it and rebuild to change the game.
Saves use the in-game menu (gear icon) and live inside the app's storage.
This project has not been compiled in this environment.
