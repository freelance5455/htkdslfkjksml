package com.zero_two.ai

import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.PermissionRequest
import androidx.appcompat.app.AppCompatActivity

/**
 * 002 AI Companion - Production Android WebView Activity
 *
 * Configured specifically to prevent blank white screens:
 * 1. Enables JavaScript and DOM Storage (prevents localStorage crashes).
 * 2. Allows file access from file URLs.
 * 3. Handles audio recording / microphone permission requests.
 * 4. Enables WebContentsDebugging in debug builds for chrome://inspect.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        // Enable Chrome DevTools inspection on your PC via chrome://inspect/#devices
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            WebView.setWebContentsDebuggingEnabled(true)
        }

        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true // CRITICAL: Required for chat history & preferences
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true

        // Allow local file access for file:/// scheme loading
        settings.allowFileAccessFromFileURLs = true
        settings.allowUniversalAccessFromFileURLs = true

        settings.mediaPlaybackRequiresUserGesture = false
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true

        webView.webViewClient = object : WebViewClient() {}

        webView.webChromeClient = object : WebChromeClient() {
            // Automatically grant web microphone permissions if Android app has RECORD_AUDIO
            override fun onPermissionRequest(request: PermissionRequest?) {
                request?.let {
                    for (resource in it.resources) {
                        if (resource == PermissionRequest.RESOURCE_AUDIO_CAPTURE) {
                            it.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                            return
                        }
                    }
                    it.grant(it.resources)
                }
            }
        }

        // LOAD APP:
        // Place the contents of the 'dist' folder into: app/src/main/assets/
        // So that index.html is located at: app/src/main/assets/index.html
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
