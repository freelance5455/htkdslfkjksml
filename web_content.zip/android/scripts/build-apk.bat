@echo off
where java >nul 2>nul
if errorlevel 1 (
  echo Java 17 or later is not installed.
  exit /b 1
)
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle 8.13 was not found in PATH. Open this project in Android Studio.
  exit /b 1
)
gradle --no-daemon assembleDebug
if errorlevel 1 exit /b 1
echo.
echo APK: app\build\outputs\apk\debug\app-debug.apk
