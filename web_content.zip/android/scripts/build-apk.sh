#!/usr/bin/env sh
set -eu

if ! command -v java >/dev/null 2>&1; then
  echo 'Java 17 یا بالاتر نصب نیست.' >&2
  exit 1
fi
if ! command -v gradle >/dev/null 2>&1; then
  echo 'Gradle 8.13 در PATH پیدا نشد. پروژه را با Android Studio باز کنید یا Gradle 8.13 را نصب کنید.' >&2
  exit 1
fi

gradle --no-daemon assembleDebug
printf '\nفایل APK: app/build/outputs/apk/debug/app-debug.apk\n'
