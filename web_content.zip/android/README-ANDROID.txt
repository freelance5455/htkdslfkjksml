ANDROID APK BUILD
1) Install Node.js LTS and Android Studio.
2) From this android folder: npm install
3) Create the web folder: mkdir www (or copy the contents of ../web into www).
4) Run: npx cap add android
5) Run: npx cap sync android
6) Run: npx cap open android
7) In Android Studio, build > Build Bundle(s) / APK(s) > Build APK(s).

IMPORTANT:
- Set the Bridge URL in the app to the Windows PC LAN address, e.g. http://192.168.1.25:5000.
- Allow TCP port 5000 through Windows Firewall only on a trusted private network.
- Android cleartext HTTP is enabled for local LAN development. For public internet use HTTPS and authentication.
- The APK project is a source wrapper; this ZIP does not contain a precompiled APK.
