#!/bin/sh
set -e
ROOT="$(CDPATH= cd -- "$(dirname "$0")" && pwd)"
SDK="${ANDROID_HOME:-/tmp/android-sdk}"
BT="$SDK/build-tools/35.0.0"
JAR="$SDK/platforms/android-35/android.jar"
OUT="$ROOT/build"
APP="$ROOT/app/src/main"
rm -rf "$OUT"
mkdir -p "$OUT/compiled" "$OUT/classes" "$OUT/dex" "$APP/res/drawable" /workspace/public/downloads

python3 - <<'PY'
from PIL import Image, ImageDraw
im = Image.new("RGBA", (192, 192), (16, 33, 27, 255))
d = ImageDraw.Draw(im)
d.rounded_rectangle((8, 8, 184, 184), radius=36, outline=(226, 182, 87, 255), width=6)
d.arc((28, 36, 100, 156), 200, 340, fill=(226, 182, 87, 255), width=10)
d.arc((92, 36, 164, 156), 200, 340, fill=(226, 182, 87, 255), width=10)
im.save("/workspace/android/app/src/main/res/drawable/ic_launcher.png")
PY

"$BT/aapt2" compile -o "$OUT/compiled" \
  "$APP/res/values/strings.xml" \
  "$APP/res/xml/network_security_config.xml" \
  "$APP/res/drawable/ic_launcher.png"
"$BT/aapt2" link -o "$OUT/base.apk" \
  -I "$JAR" \
  --manifest "$APP/AndroidManifest.xml" \
  --min-sdk-version 26 \
  --target-sdk-version 35 \
  --version-code 1 \
  --version-name 1.0.0 \
  --auto-add-overlay \
  -A "$APP/assets" \
  "$OUT/compiled"/*.flat

javac --release 17 -classpath "$JAR" -d "$OUT/classes" \
  "$APP/java/app/yooyyaa/"*.java
"$BT/d8" --min-api 26 --lib "$JAR" --output "$OUT/dex" "$OUT/classes/app/yooyyaa/"*.class
cp "$OUT/base.apk" "$OUT/with-dex.apk"
(cd "$OUT/dex" && jar uf "$OUT/with-dex.apk" classes.dex)
"$BT/zipalign" -p -f 4 "$OUT/with-dex.apk" "$OUT/aligned.apk"

KS="$ROOT/yooyyaa.jks"
if [ ! -f "$KS" ]; then
  keytool -genkeypair -keystore "$KS" -storepass yooyyaa-build -keypass yooyyaa-build \
    -alias yooyyaa -keyalg RSA -keysize 2048 -validity 10000 \
    -dname "CN=YOOYYAA, O=YOOYYAA, C=ET"
fi
"$BT/apksigner" sign --ks "$KS" --ks-key-alias yooyyaa \
  --ks-pass pass:yooyyaa-build --key-pass pass:yooyyaa-build \
  --out "$ROOT/YOOYYAA.apk" "$OUT/aligned.apk"
"$BT/apksigner" verify "$ROOT/YOOYYAA.apk"
cp "$ROOT/YOOYYAA.apk" /workspace/public/downloads/YOOYYAA.apk
ls -lh "$ROOT/YOOYYAA.apk"
