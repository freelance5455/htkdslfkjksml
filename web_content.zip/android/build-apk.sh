#!/usr/bin/env bash
# =============================================================================
#  O CAMINHO DO PODER — build do APK Android (sem Gradle, sem internet)
#
#  Usa apenas as ferramentas oficiais do Android SDK (aapt2, d8, zipalign,
#  apksigner) + um JDK. Gera um APK assinado e pronto para instalar.
#
#  Uso:  ./build-apk.sh
#  Requisitos:
#     - JDK 17 (javac, keytool)
#     - Android SDK com build-tools 34.0.0 e platforms;android-34
#       ANDROID_HOME=$HOME/android-sdk
# =============================================================================
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$HOME/android-sdk}}"
BT_VER="${BUILD_TOOLS_VERSION:-34.0.0}"
BT="$SDK/build-tools/$BT_VER"
PLATFORM="$SDK/platforms/android-34/android.jar"
OUT="$HERE/build"
APK_NAME="O-Caminho-do-Poder-1.0.0.apk"

say() { printf "\033[1;33m==> %s\033[0m\n" "$*"; }
die() { printf "\033[1;31mERRO: %s\033[0m\n" "$*" >&2; exit 1; }

# --- checagens ---
command -v javac >/dev/null || die "javac nao encontrado (instale o JDK 17)"
command -v keytool >/dev/null || die "keytool nao encontrado (instale o JDK 17)"
[ -x "$BT/aapt2" ] || die "aapt2 nao encontrado em $BT (instale build-tools $BT_VER)"
[ -f "$PLATFORM" ] || die "android.jar nao encontrado em $PLATFORM (instale platforms;android-34)"

say "Limpando build anterior"
rm -rf "$OUT"
mkdir -p "$OUT/res" "$OUT/gen" "$OUT/classes" "$OUT/dex" "$OUT/assets"

# --- 1. build web ---
if [ ! -f "$ROOT/dist/index.html" ]; then
  say "Gerando build web (vite)"
  (cd "$ROOT" && npm run build)
fi
say "Copiando o jogo para os assets (assets/www)"
mkdir -p "$OUT/assets/www"
cp -r "$ROOT/dist/." "$OUT/assets/www/"
rm -f "$OUT/assets/www"/*.map 2>/dev/null || true

# --- 2. recursos ---
say "Compilando recursos (aapt2 compile)"
"$BT/aapt2" compile --dir "$HERE/app/src/main/res" -o "$OUT/res/resources.zip"

# o aapt2 exige o atributo 'package'; injeta numa copia temporaria
# (o manifest original fica compativel com o AGP 8 / Android Studio)
MANIFEST="$OUT/AndroidManifest.xml"
sed 's|<manifest xmlns:android="http://schemas.android.com/apk/res/android">|<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="br.com.caminhodopoder">|' \
  "$HERE/app/src/main/AndroidManifest.xml" > "$MANIFEST"

say "Ligando recursos (aapt2 link)"
"$BT/aapt2" link \
  -o "$OUT/base.apk" \
  -I "$PLATFORM" \
  --manifest "$MANIFEST" \
  --rename-manifest-package br.com.caminhodopoder \
  --java "$OUT/gen" \
  -A "$OUT/assets" \
  --min-sdk-version 21 \
  --target-sdk-version 34 \
  --version-code 1 \
  --version-name "1.0.0" \
  --no-version-vectors \
  "$OUT/res/resources.zip"

# --- 3. java ---
say "Compilando Java (javac)"
find "$OUT/gen" "$HERE/app/src/main/java" -name '*.java' > "$OUT/sources.txt"
javac -nowarn -encoding UTF-8 -source 8 -target 8 \
  -bootclasspath "$PLATFORM" -classpath "$PLATFORM" \
  -d "$OUT/classes" @"$OUT/sources.txt" 2> "$OUT/javac.log" || {
    cat "$OUT/javac.log" >&2
    die "falha na compilacao do Java"
  }
grep -v "bootstrap class path" "$OUT/javac.log" >&2 || true

# --- 4. dex ---
say "Gerando classes.dex (d8)"
(cd "$OUT/classes" && jar cf "$OUT/app.jar" .)
"$BT/d8" --lib "$PLATFORM" --min-api 21 --release --output "$OUT/dex" "$OUT/app.jar"

# --- 5. empacotar ---
say "Empacotando o APK"
cp "$OUT/base.apk" "$OUT/unsigned.apk"
(cd "$OUT/dex" && zip -q -X "$OUT/unsigned.apk" classes.dex)

# --- 6. alinhar ---
say "Alinhando (zipalign)"
"$BT/zipalign" -f -p 4 "$OUT/unsigned.apk" "$OUT/aligned.apk"

# --- 7. assinar ---
KS="$HERE/release.keystore"
if [ ! -f "$KS" ]; then
  say "Gerando chave de assinatura"
  keytool -genkeypair -v -keystore "$KS" \
    -storepass caminho -keypass caminho \
    -alias caminho -keyalg RSA -keysize 2048 -validity 10950 \
    -dname "CN=O Caminho do Poder, OU=Jogo, O=Valdemar, L=Valdemar, C=BR" >/dev/null 2>&1
fi
say "Assinando (apksigner)"
"$BT/apksigner" sign \
  --ks "$KS" --ks-pass pass:caminho --key-pass pass:caminho --ks-key-alias caminho \
  --min-sdk-version 21 \
  --out "$OUT/$APK_NAME" "$OUT/aligned.apk"

"$BT/apksigner" verify --print-certs "$OUT/$APK_NAME" | head -3

mkdir -p "$ROOT/apk"
cp "$OUT/$APK_NAME" "$ROOT/apk/$APK_NAME"
say "APK pronto: apk/$APK_NAME  ($(du -h "$ROOT/apk/$APK_NAME" | cut -f1))"
