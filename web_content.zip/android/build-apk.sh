#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SDK="${ANDROID_HOME:-/tmp/android-sdk}"
PLATFORM="$SDK/platforms/android-35/android.jar"
TOOLS="$SDK/build-tools/35.0.0"
WORK="$ROOT/android/build"
OUTPUT="$ROOT/public/downloads/auria-ai.apk"
KEYSTORE="${AURIA_KEYSTORE_PATH:-/tmp/auria-signing.jks}"
PASSWORD_FILE="${AURIA_PASSWORD_FILE:-/tmp/auria-signing.pass}"

if [[ ! -f "$PLATFORM" || ! -x "$TOOLS/aapt" ]]; then
  echo 'Android SDK platform 35 and build-tools 35.0.0 are required.' >&2
  exit 1
fi

mkdir -p "$WORK/generated" "$WORK/classes" "$WORK/dex" "$ROOT/public/downloads"
rm -rf "$WORK/package" "$WORK/res"
cp -r "$ROOT/android/res" "$WORK/res"
mkdir -p "$WORK/res/drawable-nodpi"
cp "$ROOT/public/icon-192.png" "$WORK/res/drawable-nodpi/ic_launcher.png"

"$TOOLS/aapt" package -f -m \
  -J "$WORK/generated" \
  -M "$ROOT/android/AndroidManifest.xml" \
  -S "$WORK/res" \
  -I "$PLATFORM" \
  -F "$WORK/resources.apk"

javac -encoding UTF-8 -source 8 -target 8 \
  -classpath "$PLATFORM" \
  -d "$WORK/classes" \
  "$ROOT/android/src/com/auria/ai/MainActivity.java" \
  "$WORK/generated/com/auria/ai/R.java"

jar cf "$WORK/classes.jar" -C "$WORK/classes" .
"$TOOLS/d8" --min-api 26 --lib "$PLATFORM" --output "$WORK/dex" "$WORK/classes.jar"

mkdir -p "$WORK/package"
unzip -q "$WORK/resources.apk" -d "$WORK/package"
cp "$WORK/dex/classes.dex" "$WORK/package/classes.dex"
mkdir -p "$WORK/package/assets/images" "$WORK/package/assets/vendor" "$WORK/package/assets/fonts"
cp "$ROOT/public/fonts/"*.woff2 "$WORK/package/assets/fonts/"
cp "$ROOT/public/studio.html" "$ROOT/public/studio.css" "$ROOT/public/studio.js" \
   "$ROOT/public/icon.svg" "$ROOT/public/icon-192.png" "$ROOT/public/icon-512.png" \
   "$ROOT/public/manifest.webmanifest" "$WORK/package/assets/"
cp "$ROOT/public/images/hero-orb.png" "$WORK/package/assets/images/"
cp "$ROOT/public/vendor/pdf.min.mjs" "$ROOT/public/vendor/pdf.worker.min.mjs" "$WORK/package/assets/vendor/"
(cd "$WORK/package" && zip -q -r "$WORK/unsigned.apk" .)
"$TOOLS/zipalign" -f 4 "$WORK/unsigned.apk" "$WORK/aligned.apk"

if [[ ! -f "$KEYSTORE" ]]; then
  mkdir -p "$(dirname "$KEYSTORE")"
  AURIA_SIGN_PASS="$(openssl rand -hex 24)"
  printf '%s' "$AURIA_SIGN_PASS" > "$PASSWORD_FILE"
  chmod 600 "$PASSWORD_FILE"
  keytool -genkeypair -noprompt -keystore "$KEYSTORE" -alias auria \
    -keyalg RSA -keysize 3072 -validity 3650 \
    -storepass "$AURIA_SIGN_PASS" -keypass "$AURIA_SIGN_PASS" \
    -dname 'CN=Auria AI, OU=Mobile, O=Auria, C=ES' >/dev/null 2>&1
else
  AURIA_SIGN_PASS="${AURIA_SIGN_PASS:-$(cat "$PASSWORD_FILE")}" 
fi
export AURIA_SIGN_PASS
"$TOOLS/apksigner" sign --ks "$KEYSTORE" --ks-key-alias auria \
  --ks-pass env:AURIA_SIGN_PASS --key-pass env:AURIA_SIGN_PASS \
  --v4-signing-enabled false --out "$OUTPUT" "$WORK/aligned.apk"
"$TOOLS/apksigner" verify --verbose "$OUTPUT"
"$TOOLS/aapt" dump badging "$OUTPUT" | grep -E "^(package:|sdkVersion:|targetSdkVersion:|application-label:)"
echo "APK ready: $OUTPUT ($(du -h "$OUTPUT" | cut -f1))"
