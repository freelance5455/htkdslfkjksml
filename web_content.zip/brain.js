// GabxAI Brain: orquestração online, contexto, memória e ferramentas locais.
import * as M from './memory.js';
import { chat } from './model-manager.js';

export const PERSONA = `Você é a GabxAI, uma assistente inteligente e útil.
Responda em português brasileiro, com clareza, naturalidade e objetividade.
Entenda a intenção antes de responder. Se a tarefa for complexa, organize-a em etapas internamente.
Use o contexto da conversa e as memórias fornecidas quando forem relevantes.
Não invente fatos, resultados de ferramentas, pesquisas ou ações concluídas.
Se faltar informação essencial, faça uma pergunta curta.
Não diga que está pensando; entregue diretamente a resposta.`;

const normalize = s => (s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
const tokens = s => new Set(normalize(s).match(/[a-z0-9]{3,}/g) || []);

function calculate(expr) {
  if (!/^[\d\s+\-*/().,%^]+$/.test(expr)) return null;
  try {
    const source = expr.replace(/,/g,'.').replace(/\^/g,'**').replace(/(\d+(?:\.\d+)?)%/g,'($1/100)');
    if (!/^[\d\s+\-*/().]+$/.test(source)) return null;
    const value = Function('"use strict";return (' + source + ')')();
    return Number.isFinite(value) ? String(value) : null;
  } catch { return null; }
}

function detectIntent(text) {
  let m;
  if ((m = text.match(/^\s*(?:lembre(?:-se)?|memorize|guarde)\s+(?:que\s+)?(.+)/i))) return {type:'remember', value:m[1]};
  if ((m = text.match(/^\s*(?:esque[cç]a|apague da mem[oó]ria)\s+(.+)/i))) return {type:'forget', value:m[1]};
  if ((m = text.match(/^\s*(?:calcule|quanto [eé])\s+([\d\s+\-*/().,%^]+?)\s*\??\s*$/i))) {
    const result = calculate(m[1]);
    if (result !== null) return {type:'calc', expression:m[1], result};
  }
  return {type:'chat'};
}

async function relevantMemories(query, limit=5) {
  const q = tokens(query);
  const all = await M.all('mems');
  return all.map(m => {
    const words = tokens(m.text);
    let score = 0;
    for (const w of words) if (q.has(w)) score++;
    return {memory:m, score};
  }).filter(x => x.score > 0).sort((a,b) => b.score-a.score || (b.memory.ts||0)-(a.memory.ts||0))
    .slice(0,limit).map(x => x.memory);
}

function buildSystem(cfg, memories, note) {
  const now = new Date().toLocaleString('pt-BR');
  const memoryText = memories.length
    ? 'MEMÓRIAS RELEVANTES (informações fornecidas anteriormente pelo usuário):\n' + memories.map(m => '- ' + m.text).join('\n')
    : '';
  return [
    cfg.persona?.trim() || PERSONA,
    'Data e hora local do dispositivo: ' + now + '.',
    'REGRAS DE EXECUÇÃO:\n- Responda ao pedido atual, não apenas repita instruções.\n- Para tarefas com várias partes, apresente uma solução organizada.\n- Aproveite o histórico recente sem contradizer fatos já informados.\n- Diferencie fatos confirmados de estimativas.\n- Não afirme que acessou a internet, arquivos ou aplicativos se isso não aconteceu.',
    memoryText, note
  ].filter(Boolean).join('\n\n');
}

export async function reply(cfg, history, text, onText, signal) {
  const intent = detectIntent(text);
  let note = '';
  if (intent.type === 'remember') {
    await M.remember(intent.value);
    note = 'A memória foi salva localmente por solicitação explícita do usuário. Confirme brevemente.';
  } else if (intent.type === 'forget') {
    const matches = await relevantMemories(intent.value, 1);
    if (matches[0]) {
      await M.del('mems', matches[0].id);
      note = 'A memória correspondente foi apagada localmente. Confirme brevemente.';
    } else note = 'Não foi encontrada uma memória correspondente. Informe isso.';
  } else if (intent.type === 'calc') {
    note = `Ferramenta calculadora local: ${intent.expression} = ${intent.result}. Use esse resultado.`;
  }

  // A memória permanece no dispositivo. Quando enviada, ela também será recebida pelo provedor online.
  const memories = cfg.sendMem ? await relevantMemories(text, 5) : [];
  const recent = (history || []).slice(-8).map(m => ({role:m.role, content:m.content}));
  const messages = [
    {role:'system', content:buildSystem(cfg, memories, note)},
    ...recent,
    {role:'user', content:text}
  ];
  return chat(cfg, messages, onText, signal);
}
