خطوات تحويل المشروع إلى APK
============================

المتطلبات (مرة واحدة):
  1) Node.js  (نسخة LTS)      https://nodejs.org
  2) Android Studio           https://developer.android.com/studio

الخطوات (افتح Terminal / CMD داخل فولدر المشروع):

  npm install @capacitor/core @capacitor/cli @capacitor/android
  npx cap add android
  npx cap sync android
  npx cap open android

بعد ما يفتح Android Studio واستنى يخلّص Gradle sync:

  APK للتجربة:
    Build > Build Bundle(s) / APK(s) > Build APK(s)
    الملف بيبقى في:
    android/app/build/outputs/apk/debug/app-debug.apk

  APK للنشر (موقّع):
    Build > Generate Signed Bundle / APK > APK
    (اعمل keystore جديد واحفظه كويس)

لتعديل أي حاجة في الصفحة: عدّل www/index.html وبعدين
  npx cap sync android
ثم ابنِ الـ APK تاني.

الأيقونة: بعد npx cap add android،
  في Android Studio: كليك يمين على app/res > New > Image Asset
  واختار صورتك.

ملاحظة: الخط (IBM Plex Sans Arabic) بيتحمّل من الإنترنت، ومن غير نت
هيظهر بخط Tahoma/النظام. الباقي شغال أوفلاين.
