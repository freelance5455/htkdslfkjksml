خطوات تحويل المشروع إلى APK
============================

المتطلبات (مرة واحدة):
  1) Node.js  (نسخة LTS)      https://nodejs.org
  2) Android Studio           https://developer.android.com/studio

الخطوات (افتح Terminal / CMD داخل فولدر المشروع):

  npm install
  npx cap add android
  npx cap sync android
  npx cap open android

(npm install بينزّل كل الإضافات المطلوبة، ومنها إضافات حفظ ومشاركة PDF)

بعد ما يفتح Android Studio واستنى يخلّص Gradle sync:

  APK للتجربة:
    Build > Build Bundle(s) / APK(s) > Build APK(s)
    الملف بيبقى في:
    android/app/build/outputs/apk/debug/app-debug.apk

  APK للنشر (موقّع):
    Build > Generate Signed Bundle / APK > APK

طباعة التقرير PDF (متعدّلة جوه التطبيق):
  زرار "حفظ PDF" بيجهّز التقرير وبيحفظ نسخة في مجلد Documents
  على الموبايل، وبيفتح قايمة المشاركة (فتح / Drive / واتساب...).
  في المتصفح العادي بينزّل الملف مباشرة.

لو عدّلت في www/index.html:
  npx cap sync android
  ثم ابنِ الـ APK تاني.

الأيقونة: في Android Studio كليك يمين على app/res >
  New > Image Asset.

ملاحظة: خط IBM Plex Sans Arabic بيتحمّل من الإنترنت، ومن غير نت
بيتعرض بخط النظام. الباقي شغال أوفلاين.
