package com.masterflow.trading;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView web;
    private volatile String idxApiKey = "";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        web.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        web.setWebViewClient(new WebViewClient());
        web.loadUrl("file:///android_asset/web/index.html");
        setContentView(web);
    }

    public class AndroidBridge {
        @JavascriptInterface public void setIdxApiKey(String key) { idxApiKey = key == null ? "" : key.trim(); }

        @JavascriptInterface public String fetchIdxHistory(String code) {
            if (idxApiKey.isEmpty()) return "{\"error\":\"API key IDX Edge PRO belum diisi\"}";
            HttpURLConnection c = null;
            try {
                String u = "https://stock.arjum.com/api/history/" + URLEncoder.encode(code, "UTF-8");
                URL url = new URL(u);
                c = (HttpURLConnection) url.openConnection();
                c.setRequestMethod("GET");
                c.setConnectTimeout(15000);
                c.setReadTimeout(20000);
                c.setRequestProperty("X-API-Key", idxApiKey);
                c.setRequestProperty("Accept", "application/json");
                int status = c.getResponseCode();
                InputStream is = status >= 200 && status < 400 ? c.getInputStream() : c.getErrorStream();
                String body = readAll(is);
                if (status < 200 || status >= 300) {
                    return "{\"error\":" + jsonQuote("IDX Edge HTTP " + status + ": " + body) + "}";
                }
                return body;
            } catch (Exception e) {
                return "{\"error\":" + jsonQuote("IDX Edge gagal: " + e.getMessage()) + "}";
            } finally { if (c != null) c.disconnect(); }
        }

        private String readAll(InputStream is) throws Exception {
            if (is == null) return "";
            BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
            StringBuilder b = new StringBuilder(); String line;
            while ((line = br.readLine()) != null) b.append(line);
            br.close(); return b.toString();
        }
        private String jsonQuote(String x) { return "\"" + x.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r") + "\""; }
    }
}
