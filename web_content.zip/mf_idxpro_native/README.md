# MasterFlow Trading — IDX Edge PRO Native v11

- IDX: IDX Edge PRO via native Android bridge (adds X-API-Key, bypasses WebView CORS)
- US: Twelve Data via WebView fetch
- API keys stay local on device; do not share them.

Import this project into Android Studio and build the APK.
