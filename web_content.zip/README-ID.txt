NELAYAN GPS GO — PAKET WEB SIAP DIKONVERSI KE APK
=================================================

ISI FITUR
- Menampilkan koordinat GPS, akurasi, dan kompas jika sensor didukung.
- Menyimpan titik pancing/rumpon secara lokal di perangkat.
- Menghitung jarak garis lurus dan azimut ke titik pilihan.
- Mencatat jenis serta berat hasil tangkapan.
- Merekam titik perjalanan GPS selama fitur rekam aktif.
- Ekspor cadangan JSON dan daftar titik CSV, serta impor cadangan.
- Tampilan aplikasi berbahasa Indonesia dan dapat di-cache untuk offline.

CARA KONVERSI MENJADI APK
1. Ekstrak ZIP ini. Pastikan index.html berada di folder utama (root).
2. Buka layanan Web-to-APK yang dipilih, misalnya Web to App Creator.
3. Pilih opsi unggah HTML/ZIP (bukan hanya URL), lalu unggah ZIP ini.
4. Isi nama aplikasi: Nelayan GPS Go. Atur ikon menggunakan icon.svg jika diminta.
5. Aktifkan izin lokasi/geolocation pada pengaturan aplikasi hasil konversi jika tersedia.
6. Buat dan unduh APK. Instal hanya jika Anda mempercayai layanan pembuat APK tersebut.

CATATAN PENTING GPS / OFFLINE
- Aplikasi menyimpan data titik, hasil, dan rekaman di penyimpanan lokal browser/WebView.
- Agar GPS bekerja, Android harus mengizinkan akses lokasi untuk aplikasi hasil konversi.
  Tidak semua layanan Web-to-APK meneruskan izin lokasi dan sensor kompas dengan benar.
  Uji GPS dan kompas di HP sebelum dipakai melaut.
- Browser biasa umumnya mensyaratkan konteks aman (HTTPS) untuk Geolocation. Pada APK,
  dukungan bergantung pada cara layanan pembungkus membuat WebView dan memberi izin.
- Service worker untuk mode PWA biasanya perlu dijalankan melalui HTTPS/localhost.
  Paket APK yang memuat file HTML lokal mungkin memakai mekanisme offline tersendiri.
- Data lokal bisa hilang jika data aplikasi/browser dihapus atau aplikasi di-uninstall.
  Ekspor cadangan secara berkala.

BATASAN KESELAMATAN
Aplikasi ini TIDAK menyertakan peta laut, kontur kedalaman, rambu pelayaran, cuaca,
pasang surut, atau lokasi ikan/rumpon bawaan. Jarak adalah garis lurus, bukan rute kapal.
Jangan jadikan aplikasi ini satu-satunya alat navigasi. Gunakan peta laut resmi dan
perangkat keselamatan yang sesuai, cek cuaca, bawa alat komunikasi, dan gunakan pelampung.
