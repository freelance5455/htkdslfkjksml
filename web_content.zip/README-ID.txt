NutriScan AI - Paket HTML/ZIP untuk Web to App Creator

IDENTITAS APLIKASI
Nama aplikasi: NutriScan AI
Package name: com.nutriscan.ai
Mode build: HTML/ZIP dimasukkan ke APK (bukan URL website)

PENYIMPANAN
- IndexedDB digunakan sebagai salinan database lokal otomatis.
- Aplikasi lama tetap memakai localStorage sebagai lapisan kompatibilitas utama.
- Setiap perubahan localStorage dijadwalkan untuk disalin ke IndexedDB; ada penyimpanan berkala.
- Tidak memerlukan WebToApkFS, SAF, atau pemilihan folder.
- Ekspor dan impor JSON tersedia di Pengaturan > Cadangkan & pulihkan data.
- Unduh cadangan JSON secara berkala. Data lokal dapat hilang jika data aplikasi dihapus atau aplikasi di-uninstall.
- Status tersimpan di aplikasi hanya menunjukkan penulisan ke database lokal berhasil; tetap lakukan uji tutup paksa dan buka kembali pada APK.

PANDUAN PENGUJIAN SEBELUM PEMAKAIAN
1. Build APK percobaan dan instal.
2. Buat akun uji.
3. Isi profil dan target nutrisi.
4. Tambahkan makanan ke jurnal, konsumsi air, dan kebiasaan.
5. Tekan Simpan sekarang.
6. Tutup paksa aplikasi, buka kembali, lalu pastikan semua data tetap ada.
7. Unduh cadangan JSON.
8. Uji pemulihan dengan file JSON tersebut.
9. Uji kamera, PDF, dan fitur Groq AI dengan koneksi internet aktif.

CATATAN
- Fitur AI membutuhkan internet.
- Kamera harus diuji dan izin kamera perlu diberikan jika diminta Android.
- IndexedDB/localStorage dapat dihapus oleh Android jika pengguna menghapus data aplikasi atau meng-uninstall aplikasi.
- Simpan file cadangan JSON di tempat aman.
- API key Groq dipertahankan di HTML sesuai permintaan pemilik aplikasi. API key yang ditanam di HTML/APK dapat diekstrak oleh pihak lain; pertimbangkan proxy server sebelum distribusi luas.

Perbaikan logo: logo sekarang menggunakan SVG inline di dalam index.html sehingga tidak bergantung pada file gambar atau URL eksternal.
