RHYTHM MUSIC — YOUTUBE SEARCH + PLAYER + CAPTION SUPPORT

Sumber musik:
1. YouTube Data API v3 digunakan untuk mencari video musik publik (termasuk musik Indonesia) berdasarkan judul/artis.
2. Hasil YouTube diputar memakai YouTube IFrame Player resmi. Website tidak mengekstrak audio, tidak mengunduh video, dan tidak memisahkan audio dari YouTube.
3. Jika API key belum dimasukkan, pencarian memakai Audius sebagai katalog alternatif. Audius berisi unggahan kreator, sehingga cakupannya berbeda dari YouTube.
4. YouTube Music sendiri tidak menyediakan API publik resmi yang membuka seluruh katalog dan audio streaming terpisah untuk aplikasi pihak ketiga.

Cara mengaktifkan pencarian YouTube:
- Buat project di Google Cloud Console.
- Aktifkan YouTube Data API v3.
- Buat API key.
- Batasi API key dengan HTTP referrer/domain website dan batasi API hanya ke YouTube Data API v3.
- Buka Rhythm > Search > Atur YouTube API, lalu tempel API key dan Simpan.
- API key disimpan di localStorage browser perangkat tersebut. Jangan bagikan key kepada orang lain.
- Search API memiliki kuota; hindari pencarian berulang yang tidak diperlukan.

Pemutaran:
- Pilih hasil YouTube untuk memutar video lewat pemutar resmi YouTube.
- Tombol Video membuka/menutup pemutar.
- Tombol CC/Lirik menampilkan petunjuk subtitle YouTube. Jika pemilik video menyediakan subtitle/lirik, gunakan tombol CC pada pemutar. Tidak semua video menyediakan lirik.
- Lagu Audius diputar lewat stream resmi Audius bila tersedia.

UI:
- Mini-player dan tombol bawah diperbesar.
- Bottom navigation diperbesar agar lebih nyaman disentuh.
- Panel video dan panel CC dibuat responsif untuk HP.

Catatan:
YouTube Data API hanya mencari metadata video. Playback dilakukan melalui YouTube IFrame Player API. Tidak ada jaminan semua video bisa di-embed; beberapa pemilik video membatasi pemutaran di situs lain.
Dokumentasi:
https://developers.google.com/youtube/v3/docs/search/list
https://developers.google.com/youtube/iframe_api_reference

Tema visual diperbarui menjadi Midnight Emerald: dasar charcoal-hijau, aksen mint, kartu gradasi, dan Liquid Glass yang lebih lembut. Area navigasi dan mini-player bawah diperbesar.


TEMA BLUE GLASS LARGE (2026-10-27)
- Seluruh palet UI diperbarui menjadi deep navy, electric blue, dan cyan.
- Kartu, navigasi, mini-player, search, library, lyrics menggunakan frosted glass biru.
- UI mobile diperbesar: judul, kartu, bar pencarian, tombol, mini-player dan navigasi bawah.
- Integrasi sumber tetap: Audius untuk streaming track yang tersedia; YouTube Data API untuk hasil video dan YouTube official player; LRCLIB untuk lirik jika tersedia.
