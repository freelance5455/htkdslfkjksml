MY LIVE PROJECTS - DEPLOYMENT

This folder contains a homepage (index.html) and all three project pages.

To publish for free using Netlify Drop:
1. Open https://app.netlify.com/drop in a browser.
2. Sign in or create a free Netlify account.
3. Drag and drop this entire 'live-website' folder (or a ZIP of it) onto the page.
4. Netlify will publish the site and show you a public URL.
5. Open that URL to see the homepage and launch each project.

Notes:
- SkyPulse requests current weather data from Open-Meteo, so it needs an internet connection.
- FreshBite's ordering links still open the original Claude Artifact URL; the uploaded HTML does not contain a separate local checkout backend.
- Student Result Management is a front-end HTML page; this package does not add a server/database.
\n\nAdded project: World Currency Converter (world-currency-converter.html). It is linked from the main index page.\n

DEVELOPER ATTRIBUTION
The portfolio and project pages display: “Developed by NIKHIL SINGH · Software Developer”.

IMPORTANT LEGAL NOTE
Adding a name or copyright notice does not itself create a patent, prove ownership, or grant exclusive rights over every component. Patent protection (where available) requires a qualifying novel invention and a formal application; ordinary website code and visual content are more commonly protected through copyright, subject to who created or owns each part. Third-party APIs, fonts, libraries, templates, and linked services remain subject to their own terms and licenses. Keep evidence of your original work and get advice from an Indian IP professional before making a legal filing.
