# My Phone Control — HTML ZIP Demo

## চালানোর নিয়ম
1. ZIP Extract করুন।
2. `index.html` ব্রাউজারে খুলুন। PWA/Camera/Microphone/Location/Screen Share-এর জন্য HTTPS বা localhost প্রয়োজন হতে পারে।
3. PWA ইনস্টল করতে HTTPS-এ হোস্ট করে Chrome-এর Install app ব্যবহার করুন।
4. Admin Panel ও Child Panel আলাদাভাবে খুলে ডেমো পরীক্ষা করুন। Demo Pairing Code: `482915`।

## কী কাজ করে
- Responsive Admin ও Child UI
- Browser Online/Offline ইভেন্ট থেকে নেটওয়ার্ক অবস্থা
- Demo Pairing এবং UI status
- Child-এর সরাসরি অনুমতিতে Camera preview, Microphone permission test, Location, user-selected file এবং WhatsApp `.txt` export preview
- সমর্থিত ব্রাউজারে user-approved Screen Share preview
- PWA manifest ও service worker (offline app shell)

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এটি **সম্পূর্ণ HTML demo**, বাস্তব দূরবর্তী ফোন-নিয়ন্ত্রণ ব্যবস্থা নয়। Admin/Child ফোনের মধ্যে কোনো প্রকৃত নেটওয়ার্ক সেশন, ডেটা ট্রান্সফার, Push notification বা সার্ভারভিত্তিক presence চালু নেই। Demo Pairing Code স্থির এবং নিরাপত্তার জন্য ব্যবহারযোগ্য নয়।

- প্রকৃত cross-network connection-এর জন্য HTTPS backend, authenticated device pairing, WebSocket/WebRTC signaling এবং অনুমোদিত data channels/relay দরকার।
- Browser online/offline ইভেন্ট শুধু এই ব্রাউজারের নেটওয়ার্ক অবস্থা জানায়; অন্য ফোন চালু/বন্ধ হয়েছে কি না নির্ভরযোগ্যভাবে জানায় না।
- Browser বন্ধ/ফোন রিস্টার্টের পর auto-start বা background reconnect HTML দিয়ে সম্ভব নয়। Android Native app, user-visible foreground service, Android lifecycle ও notification permission দরকার।
- Camera/Microphone/Location/Screen Capture-এর অনুমতি Child ডিভাইসেই নিতে হবে। এই demo কোনো stream অন্য ডিভাইসে পাঠায় না এবং ভিডিও/অডিও রেকর্ড করে না।
- Android Chrome-এ Screen Capture API সমর্থন সীমিত হতে পারে।
- WhatsApp chat শুধু ব্যবহারকারীর নিজের export করা `.txt` ফাইল থেকে স্থানীয় preview-তে দেখানো হয়; WhatsApp account বা chat database-এ সরাসরি প্রবেশ করে না।

## পরবর্তী Android APK পরিকল্পনা
প্রস্তাবিত কাঠামো:
- `web/` — এই HTML/CSS/JS UI (বর্তমান ZIP-এর root)
- Android wrapper — Kotlin + WebView অথবা Capacitor
- Native permissions — Camera, Record Audio, Location, document picker
- Auto reconnect — অনুমোদিত foreground service + WorkManager; OS নীতিমালা মেনে
- Backend — HTTPS API, WebSocket presence, WebRTC signaling; শক্তিশালী authentication, pairing expiry, revocation ও audit log

## নিরাপত্তা নীতি
- কোনো hidden camera/microphone access নয়।
- কোনো video capture/recording নয়।
- কোনো screen-time monitoring নয়।
- Child নিজে প্রতিটি permission অনুমোদন/বন্ধ করবে।
- Demo-তে Admin-এর ব্যক্তিগত তথ্য Child Panel-এ প্রকাশ করা হয় না।
