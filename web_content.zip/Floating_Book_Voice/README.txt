Floating Book Voice — HTML ZIP Demo

ব্যবহার:
1. ZIP extract করুন।
2. index.html ফাইলটি Android Chrome বা অন্য আধুনিক ব্রাউজারে খুলুন।
3. TXT বই নির্বাচন করুন অথবা লেখার ঘরে পেস্ট করুন।
4. Voice List থেকে ফোনে থাকা TTS voice বেছে Play চাপুন।
5. ডান পাশের ♫ বাটনে চাপলে ছোট Mini Player খুলবে। প্যানেলের শিরোনাম ধরে টেনে সরানো যাবে।

নিজের ভয়েস:
- Add Voice অংশে ভয়েসের নাম সংরক্ষণ করা যায়।
- নাম যোগ করলেই নতুন কণ্ঠ তৈরি হয় না। কণ্ঠটি Android-এর Text-to-Speech engine-এ ইনস্টল/সক্রিয় থাকতে হবে।

সীমাবদ্ধতা:
এটি HTML ডেমো, নেটিভ Android অ্যাপ নয়। অন্য অ্যাপ/গেমের ওপর সিস্টেম-ওয়াইড floating overlay, স্থায়ী background playback, screen-off playback ও Android shortcut-এর জন্য native APK-তে Overlay permission এবং foreground media service তৈরি করতে হবে।
