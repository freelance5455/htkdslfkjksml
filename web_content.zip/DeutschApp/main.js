const content = document.getElementById("content");
const searchInput = document.getElementById("searchInput");

let favorites =
JSON.parse(localStorage.getItem("favorites")) || [];

let viewed =
Number(localStorage.getItem("viewed")) || 0;

let quizScore =
Number(localStorage.getItem("quizScore")) || 0;

const allWords = [
    ...wordsA1,
    ...wordsA2
];

function updateStats() {

    document.getElementById(
        "totalWords"
    ).textContent = allWords.length;

    document.getElementById(
        "totalFavorites"
    ).textContent = favorites.length;

    document.getElementById(
        "totalViewed"
    ).textContent = viewed;
}

function saveData() {

    localStorage.setItem(
        "favorites",
        JSON.stringify(favorites)
    );

    localStorage.setItem(
        "viewed",
        viewed
    );

    localStorage.setItem(
        "quizScore",
        quizScore
    );

    updateStats();
}

function speak(text) {

    if (!window.speechSynthesis) return;

    const utterance =
    new SpeechSynthesisUtterance(text);

    utterance.lang = "de-DE";

    speechSynthesis.speak(utterance);
}

function createWordCard(word) {

    const isFavorite =
    favorites.includes(word.german);

    return `
    <div class="word-card">

        <h2>${word.german}</h2>

        <p>
            <strong>Перевод:</strong>
            ${word.russian}
        </p>

        <p class="pronunciation">
            <strong>Читается:</strong>
            ${word.pronunciation}
        </p>

        <div class="action-row">

            <button
            class="fav-btn"
            onclick="toggleFavorite('${word.german}')">

                ${isFavorite ? "⭐" : "☆"}

            </button>

            <button
            class="speak-btn"
            onclick="speak('${word.german}')">

                🔊

            </button>

        </div>

    </div>
    `;
}

window.speak = speak;

function displayWords(list) {

    viewed += list.length;

    saveData();

    content.innerHTML =
    list.map(createWordCard).join("");
}

function displayPhrases(list) {

    content.innerHTML = "";

    list.forEach(item => {

        content.innerHTML += `
        <div class="word-card">

            <h2>${item.german}</h2>

            <p>
                ${item.russian}
            </p>

            <p class="pronunciation">

                ${item.pronunciation}

            </p>

            <div class="action-row">

                <button
                class="speak-btn"
                onclick="speak('${item.german}')">

                    🔊 Озвучить

                </button>

            </div>

        </div>
        `;
    });
}

window.toggleFavorite = function(word) {

    if (favorites.includes(word)) {

        favorites =
        favorites.filter(
            item => item !== word
        );

    } else {

        favorites.push(word);

    }

    saveData();

    const current =
    allWords.filter(item =>
        item.german
    );

    displayWords(current);
};

function showFavorites() {

    const result =
    allWords.filter(word =>
        favorites.includes(
            word.german
        )
    );

    displayWords(result);
}

function startQuiz() {

    const question =
    allWords[
        Math.floor(
            Math.random() *
            allWords.length
        )
    ];

    let answers =
    [question.russian];

    while (
        answers.length < 4
    ) {

        const answer =
        allWords[
            Math.floor(
                Math.random() *
                allWords.length
            )
        ].russian;

        if (
            !answers.includes(answer)
        ) {
            answers.push(answer);
        }
    }

    answers.sort(
        () => Math.random() - 0.5
    );

    content.innerHTML = `
    <div class="quiz-box">

        <div class="quiz-question">

            ${question.german}

        </div>

        <div id="answers"></div>

        <div class="score">

            Очки:
            ${quizScore}

        </div>

    </div>
    `;

    const answersBox =
    document.getElementById(
        "answers"
    );

    answers.forEach(answer => {

        const btn =
        document.createElement(
            "button"
        );

        btn.className =
        "answer-btn";

        btn.textContent =
        answer;

        btn.onclick = () => {

            if (
                answer ===
                question.russian
            ) {

                quizScore++;

                saveData();

                alert(
                    "✅ Правильно"
                );

            } else {

                alert(
                    "❌ Неверно\n\nПравильно:\n" +
                    question.russian
                );

            }

            startQuiz();
        };

        answersBox.appendChild(btn);
    });
}

searchInput.addEventListener(
    "input",
    () => {

        const value =
        searchInput.value
        .toLowerCase();

        const result =
        allWords.filter(word =>

            word.german
            .toLowerCase()
            .includes(value)

            ||

            word.russian
            .toLowerCase()
            .includes(value)

            ||

            word.pronunciation
            .toLowerCase()
            .includes(value)

        );

        displayWords(result);
    }
);

document
.getElementById("btnWordsA1")
.onclick = () =>
displayWords(wordsA1);

document
.getElementById("btnWordsA2")
.onclick = () =>
displayWords(wordsA2);

document
.getElementById("btnLife")
.onclick = () =>
displayPhrases(lifePhrases);

document
.getElementById("btnWork")
.onclick = () =>
displayPhrases(workPhrases);

document
.getElementById("btnShop")
.onclick = () =>
displayPhrases(shopPhrases);

document
.getElementById("btnDoctor")
.onclick = () =>
displayPhrases(doctorPhrases);

document
.getElementById("btnFavorites")
.onclick = () =>
showFavorites();

document
.getElementById("btnQuiz")
.onclick = () =>
startQuiz();

updateStats();

displayWords(wordsA1);