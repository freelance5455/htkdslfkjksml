function startQuiz() {

    const allWords = [...wordsA1];

    const randomWord =
        allWords[Math.floor(Math.random() * allWords.length)];

    const answers = [randomWord.russian];

    while (answers.length < 4) {

        const wrong =
            allWords[Math.floor(Math.random() * allWords.length)].russian;

        if (!answers.includes(wrong)) {
            answers.push(wrong);
        }

    }

    answers.sort(() => Math.random() - 0.5);

    let html = `
        <div class="quiz-box">
            <h2>🎯 Тест</h2>

            <h3>${randomWord.german}</h3>

            <p>Выберите перевод:</p>
    `;

    answers.forEach(answer => {

        html += `
            <button class="quiz-btn"
            onclick="checkAnswer('${answer}','${randomWord.russian}')">
                ${answer}
            </button>
        `;

    });

    html += `</div>`;

    document.getElementById("content").innerHTML = html;

}

function checkAnswer(selected, correct) {

    if (selected === correct) {

        alert("✅ Правильно!");

    } else {

        alert("❌ Неправильно!\n\nПравильный ответ:\n" + correct);

    }

    startQuiz();

}

document
.getElementById("btnQuiz")
.addEventListener("click", startQuiz);