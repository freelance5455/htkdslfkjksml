const lifePhrases = [

{
    german: "Ich verstehe nicht",
    russian: "Я не понимаю",
    pronunciation: "Ихь ферштее нихьт"
},
{
    german: "Ich spreche schlecht Deutsch",
    russian: "Я плохо говорю по-немецки",
    pronunciation: "Ихь шпрехе шлехт дойч"
},
{
    german: "Guten Morgen",
    russian: "Доброе утро",
    pronunciation: "Гутен морген"
},
{
    german: "Guten Tag",
    russian: "Добрый день",
    pronunciation: "Гутен таг"
},
{
    german: "Guten Abend",
    russian: "Добрый вечер",
    pronunciation: "Гутен абенд"
},
{
    german: "Wie geht es Ihnen?",
    russian: "Как у Вас дела?",
    pronunciation: "Ви гейт эс инен"
},
{
    german: "Mir geht es gut.",
    russian: "У меня всё хорошо.",
    pronunciation: "Мир гейт эс гут"
},
{
    german: "Und Ihnen?",
    russian: "А у Вас?",
    pronunciation: "Унд инен"
},
{
    german: "Ich heiße Denis.",
    russian: "Меня зовут Денис.",
    pronunciation: "Ихь хайсе Денис"
},
{
    german: "Ich komme aus der Ukraine.",
    russian: "Я из Украины.",
    pronunciation: "Ихь комме аус дер Украйне"
},
{
    german: "Ich wohne in Deutschland.",
    russian: "Я живу в Германии.",
    pronunciation: "Ихь воне ин Дойчланд"
},
{
    german: "Ich verstehe nicht.",
    russian: "Я не понимаю.",
    pronunciation: "Ихь ферштее нихт"
},
{
    german: "Bitte wiederholen Sie.",
    russian: "Повторите, пожалуйста.",
    pronunciation: "Битте видерхолен зи"
},
{
    german: "Sprechen Sie bitte langsamer.",
    russian: "Говорите, пожалуйста, медленнее.",
    pronunciation: "Шпрехен зи битте лангзамер"
},
{
    german: "Ich spreche schlecht Deutsch.",
    russian: "Я плохо говорю по-немецки.",
    pronunciation: "Ихь шпрехе шлехт дойч"
},
{
    german: "Können Sie mir helfen?",
    russian: "Вы можете мне помочь?",
    pronunciation: "Кённен зи мир хельфен"
},
{
    german: "Vielen Dank.",
    russian: "Большое спасибо.",
    pronunciation: "Филен данк"
},
{
    german: "Kein Problem.",
    russian: "Без проблем.",
    pronunciation: "Кайн проблем"
},
{
    german: "Entschuldigung.",
    russian: "Извините.",
    pronunciation: "Энтшульдигунг"
},
{
    german: "Wo ist die Toilette?",
    russian: "Где туалет?",
    pronunciation: "Во ист ди туалетте"
},
{
    german: "Wo ist der Bahnhof?",
    russian: "Где вокзал?",
    pronunciation: "Во ист дер банхоф"
},
{
    german: "Wie viel kostet das?",
    russian: "Сколько это стоит?",
    pronunciation: "Ви филь костет дас"
},
{
    german: "Wie heißen Sie?",
    russian: "Как Вас зовут?",
    pronunciation: "Ви хайсен зи"
},
{
    german: "Woher kommen Sie?",
    russian: "Откуда Вы?",
    pronunciation: "Вохер коммен зи"
},
{
    german: "Wie alt sind Sie?",
    russian: "Сколько Вам лет?",
    pronunciation: "Ви альт зинт зи"
},
{
    german: "Ich bin 25 Jahre alt.",
    russian: "Мне 25 лет.",
    pronunciation: "Ихь бин фюнфундцванцих яре альт"
},
{
    german: "Wo wohnen Sie?",
    russian: "Где Вы живёте?",
    pronunciation: "Во вонен зи"
},
{
    german: "Ich arbeite hier.",
    russian: "Я работаю здесь.",
    pronunciation: "Ихь арбайте хир"
},
{
    german: "Ich lerne Deutsch.",
    russian: "Я учу немецкий.",
    pronunciation: "Ихь лерне дойч"
},
{
    german: "Können Sie das erklären?",
    russian: "Можете это объяснить?",
    pronunciation: "Кённен зи дас эрклерен"
},
{
    german: "Was bedeutet das?",
    russian: "Что это значит?",
    pronunciation: "Вас бэдойтет дас"
},
{
    german: "Wie schreibt man das?",
    russian: "Как это пишется?",
    pronunciation: "Ви шрайбт ман дас"
},
{
    german: "Können Sie das aufschreiben?",
    russian: "Можете это записать?",
    pronunciation: "Кённен зи дас ауфшрайбен"
},
{
    german: "Einen Moment bitte.",
    russian: "Одну минуту, пожалуйста.",
    pronunciation: "Айнен момент битте"
},
{
    german: "Ich habe eine Frage.",
    russian: "У меня есть вопрос.",
    pronunciation: "Ихь хабе айне фраге"
},
{
    german: "Ich weiß nicht.",
    russian: "Я не знаю.",
    pronunciation: "Ихь вайс нихт"
},
{
    german: "Natürlich.",
    russian: "Конечно.",
    pronunciation: "Натюрлих"
},
{
    german: "Vielleicht.",
    russian: "Возможно.",
    pronunciation: "Филяйхт"
},
{
    german: "Genau.",
    russian: "Точно.",
    pronunciation: "Генау"
},
{
    german: "Kein Problem.",
    russian: "Без проблем.",
    pronunciation: "Кайн проблем"
},
{
    german: "Das ist gut.",
    russian: "Это хорошо.",
    pronunciation: "Дас ист гут"
},
{
    german: "Das ist schlecht.",
    russian: "Это плохо.",
    pronunciation: "Дас ист шлехт"
},
{
    german: "Ich bin müde.",
    russian: "Я устал.",
    pronunciation: "Ихь бин мюде"
},
{
    german: "Ich habe Hunger.",
    russian: "Я голоден.",
    pronunciation: "Ихь хабе хунгер"
},
{
    german: "Ich habe Durst.",
    russian: "Я хочу пить.",
    pronunciation: "Ихь хабе дурст"
},
{
    german: "Ich habe Zeit.",
    russian: "У меня есть время.",
    pronunciation: "Ихь хабе цайт"
},
{
    german: "Ich habe keine Zeit.",
    russian: "У меня нет времени.",
    pronunciation: "Ихь хабе кайне цайт"
},
{
    german: "Bis morgen.",
    russian: "До завтра.",
    pronunciation: "Бис морген"
},
{
    german: "Bis später.",
    russian: "До позже.",
    pronunciation: "Бис шпетер"
},
{
    german: "Bis bald.",
    russian: "До скорого.",
    pronunciation: "Бис бальд"
},
{
    german: "Schönen Tag noch.",
    russian: "Хорошего дня.",
    pronunciation: "Шёнен таг нох"
},
{
    german: "Gute Nacht.",
    russian: "Спокойной ночи.",
    pronunciation: "Гуте нахт"
},
{
    german: "Wo sind Sie?",
    russian: "Где Вы?",
    pronunciation: "Во зинт зи"
},
{
    german: "Ich bin zu Hause.",
    russian: "Я дома.",
    pronunciation: "Ихь бин цу хаузе"
},
{
    german: "Ich bin unterwegs.",
    russian: "Я в пути.",
    pronunciation: "Ихь бин унтервегс"
},
{
    german: "Ich komme gleich.",
    russian: "Я скоро приду.",
    pronunciation: "Ихь комме гляйх"
},
{
    german: "Warten Sie bitte.",
    russian: "Подождите, пожалуйста.",
    pronunciation: "Вартен зи битте"
},
{
    german: "Alles klar.",
    russian: "Всё понятно.",
    pronunciation: "Аллес клар"
},
{
    german: "Keine Ahnung.",
    russian: "Без понятия.",
    pronunciation: "Кайне анунг"
},
{
    german: "Das stimmt.",
    russian: "Это верно.",
    pronunciation: "Дас штимт"
},
{
    german: "Das stimmt nicht.",
    russian: "Это неверно.",
    pronunciation: "Дас штимт нихт"
},
{
    german: "Ich bin fertig.",
    russian: "Я закончил.",
    pronunciation: "Ихь бин фертих"
},
{
    german: "Wie spät ist es?",
    russian: "Сколько сейчас времени?",
    pronunciation: "Ви шпэт ист эс"
},
{
    german: "Es ist zwölf Uhr.",
    russian: "Сейчас двенадцать часов.",
    pronunciation: "Эс ист цвёльф ур"
},
{
    german: "Welcher Tag ist heute?",
    russian: "Какой сегодня день?",
    pronunciation: "Вельхер таг ист хойте"
},
{
    german: "Heute ist Montag.",
    russian: "Сегодня понедельник.",
    pronunciation: "Хойте ист монтаг"
},
{
    german: "Wo arbeiten Sie?",
    russian: "Где Вы работаете?",
    pronunciation: "Во арбайтен зи"
},
{
    german: "Ich suche Arbeit.",
    russian: "Я ищу работу.",
    pronunciation: "Ихь зухе арбайт"
},
{
    german: "Ich habe frei.",
    russian: "У меня выходной.",
    pronunciation: "Ихь хабе фрай"
},
{
    german: "Ich komme zu spät.",
    russian: "Я опаздываю.",
    pronunciation: "Ихь комме цу шпэт"
},
{
    german: "Ich bin pünktlich.",
    russian: "Я вовремя.",
    pronunciation: "Ихь бин пунктлих"
},
{
    german: "Können Sie mir zeigen?",
    russian: "Можете мне показать?",
    pronunciation: "Кённен зи мир цайген"
},
{
    german: "Wo kann ich das finden?",
    russian: "Где я могу это найти?",
    pronunciation: "Во кан ихь дас финден"
},
{
    german: "Ich suche diese Adresse.",
    russian: "Я ищу этот адрес.",
    pronunciation: "Ихь зухе дизе адрессе"
},
{
    german: "Ist das weit?",
    russian: "Это далеко?",
    pronunciation: "Ист дас вайт"
},
{
    german: "Ist das nah?",
    russian: "Это близко?",
    pronunciation: "Ист дас на"
},
{
    german: "Links oder rechts?",
    russian: "Налево или направо?",
    pronunciation: "Линкс одер рехтс"
},
{
    german: "Gehen Sie geradeaus.",
    russian: "Идите прямо.",
    pronunciation: "Геен зи герадеаус"
},
{
    german: "Ich habe mich verlaufen.",
    russian: "Я заблудился.",
    pronunciation: "Ихь хабе михь ферлауфен"
},
{
    german: "Können Sie mir helfen?",
    russian: "Можете мне помочь?",
    pronunciation: "Кённен зи мир хельфен"
},
{
    german: "Ich brauche Hilfe.",
    russian: "Мне нужна помощь.",
    pronunciation: "Ихь браухе хильфе"
},
{
    german: "Alles ist in Ordnung.",
    russian: "Всё в порядке.",
    pronunciation: "Аллес ист ин орднунг"
},
{
    german: "Ich habe kein Geld dabei.",
    russian: "У меня нет с собой денег.",
    pronunciation: "Ихь хабе кайн гельд дабай"
},
{
    german: "Kann ich mit Karte bezahlen?",
    russian: "Можно оплатить картой?",
    pronunciation: "Кан ихь мит карте бецален"
},
{
    german: "Ich möchte bar bezahlen.",
    russian: "Я хочу оплатить наличными.",
    pronunciation: "Ихь мёхте бар бецален"
},
{
    german: "Brauche ich die Rechnung?",
    russian: "Мне нужен чек?",
    pronunciation: "Браухе ихь ди рехнунг"
},
{
    german: "Das ist zu teuer.",
    russian: "Это слишком дорого.",
    pronunciation: "Дас ист цу тойер"
},
{
    german: "Das ist günstig.",
    russian: "Это недорого.",
    pronunciation: "Дас ист гюнстих"
},
{
    german: "Ich nehme das.",
    russian: "Я возьму это.",
    pronunciation: "Ихь неме дас"
},
{
    german: "Ich brauche nur das.",
    russian: "Мне нужно только это.",
    pronunciation: "Ихь браухе нур дас"
},
{
    german: "Haben Sie etwas Kleineres?",
    russian: "У Вас есть что-нибудь поменьше?",
    pronunciation: "Хабен зи этвас кляйнерес"
},
{
    german: "Ich verstehe die Frage.",
    russian: "Я понимаю вопрос.",
    pronunciation: "Ихь ферштее ди фраге"
},
{
    german: "Ich verstehe die Antwort nicht.",
    russian: "Я не понимаю ответ.",
    pronunciation: "Ихь ферштее ди антворт нихт"
},
{
    german: "Bitte sprechen Sie einfacher.",
    russian: "Говорите, пожалуйста, проще.",
    pronunciation: "Битте шпрехен зи айнфахер"
},
{
    german: "Können Sie langsamer sprechen?",
    russian: "Можете говорить медленнее?",
    pronunciation: "Кённен зи лангзамер шпрехен"
},
{
    german: "Wie schreibt man dieses Wort?",
    russian: "Как пишется это слово?",
    pronunciation: "Ви шрайбт ман дизес ворт"
},
{
    german: "Was haben Sie gesagt?",
    russian: "Что Вы сказали?",
    pronunciation: "Вас хабен зи гезагт"
},
{
    german: "Noch einmal bitte.",
    russian: "Ещё раз, пожалуйста.",
    pronunciation: "Нох айнмаль битте"
},
{
    german: "Kein Stress.",
    russian: "Без проблем, не переживайте.",
    pronunciation: "Кайн штресс"
},
{
    german: "Alles gut.",
    russian: "Всё хорошо.",
    pronunciation: "Аллес гут"
},
{
    german: "Ich freue mich.",
    russian: "Я рад.",
    pronunciation: "Ихь фройе михь"
},
{
    german: "Schön, Sie kennenzulernen.",
    russian: "Приятно познакомиться.",
    pronunciation: "Шён зи кенненцулернен"
},
{
    german: "Wie war Ihr Tag?",
    russian: "Как прошёл Ваш день?",
    pronunciation: "Ви вар ир таг"
},
{
    german: "Mein Tag war gut.",
    russian: "Мой день прошёл хорошо.",
    pronunciation: "Майн таг вар гут"
},
{
    german: "Ich bin zu Hause.",
    russian: "Я дома.",
    pronunciation: "Ихь бин цу хаузе"
},
{
    german: "Ich komme später.",
    russian: "Я приду позже.",
    pronunciation: "Ихь комме шпетер"
},
{
    german: "Ich bin schon da.",
    russian: "Я уже здесь.",
    pronunciation: "Ихь бин шон да"
},
{
    german: "Warten Sie auf mich.",
    russian: "Подождите меня.",
    pronunciation: "Вартен зи ауф михь"
},
{
    german: "Ich habe verstanden.",
    russian: "Я понял.",
    pronunciation: "Ихь хабе ферштанден"
},
{
    german: "Jetzt verstehe ich.",
    russian: "Теперь я понимаю.",
    pronunciation: "Йетцт ферштее ихь"
},
{
    german: "Das weiß ich nicht.",
    russian: "Этого я не знаю.",
    pronunciation: "Дас вайс ихь нихт"
},
{
    german: "Ich erinnere mich nicht.",
    russian: "Я не помню.",
    pronunciation: "Ихь эриннере михь нихт"
},
{
    german: "Ich habe vergessen.",
    russian: "Я забыл.",
    pronunciation: "Ихь хабе фергессен"
},
{
    german: "Kein Interesse.",
    russian: "Неинтересно.",
    pronunciation: "Кайн интерессе"
},
{
    german: "Das gefällt mir.",
    russian: "Мне это нравится.",
    pronunciation: "Дас гефельт мир"
},
{
    german: "Das gefällt mir nicht.",
    russian: "Мне это не нравится.",
    pronunciation: "Дас гефельт мир нихт"
},
{
    german: "Ich denke schon.",
    russian: "Я думаю, что да.",
    pronunciation: "Ихь денке шон"
},
{
    german: "Ich denke nicht.",
    russian: "Я так не думаю.",
    pronunciation: "Ихь денке нихт"
},
{
    german: "Vielleicht später.",
    russian: "Может быть позже.",
    pronunciation: "Филяйхт шпетер"
},
{
    german: "Warum nicht?",
    russian: "Почему нет?",
    pronunciation: "Варум нихт"
},
{
    german: "Natürlich nicht.",
    russian: "Конечно нет.",
    pronunciation: "Натюрлих нихт"
},
{
    german: "Natürlich ja.",
    russian: "Конечно да.",
    pronunciation: "Натюрлих я"
},
{
    german: "Ich habe keine Ahnung.",
    russian: "Я понятия не имею.",
    pronunciation: "Ихь хабе кайне анунг"
},
{
    german: "Das ist interessant.",
    russian: "Это интересно.",
    pronunciation: "Дас ист интерессант"
},
{
    german: "Das ist wichtig.",
    russian: "Это важно.",
    pronunciation: "Дас ист вихтих"
},
{
    german: "Das ist möglich.",
    russian: "Это возможно.",
    pronunciation: "Дас ист меглих"
},
{
    german: "Das ist unmöglich.",
    russian: "Это невозможно.",
    pronunciation: "Дас ист унмеглих"
},
{
    german: "Ich bin beschäftigt.",
    russian: "Я занят.",
    pronunciation: "Ихь бин бешефтихт"
},
{
    german: "Ich habe Freizeit.",
    russian: "У меня есть свободное время.",
    pronunciation: "Ихь хабе фрайцайт"
},
{
    german: "Ich habe Urlaub.",
    russian: "У меня отпуск.",
    pronunciation: "Ихь хабе урлауб"
},
{
    german: "Ich bin krank.",
    russian: "Я болен.",
    pronunciation: "Ихь бин кранк"
},
{
    german: "Mir geht es besser.",
    russian: "Мне лучше.",
    pronunciation: "Мир гейт эс бесер"
},
{
    german: "Mir geht es schlecht.",
    russian: "Мне плохо.",
    pronunciation: "Мир гейт эс шлехт"
},
{
    german: "Ich brauche Ruhe.",
    russian: "Мне нужен отдых.",
    pronunciation: "Ихь браухе руэ"
},
{
    german: "Was machen Sie heute?",
    russian: "Что Вы делаете сегодня?",
    pronunciation: "Вас махен зи хойте"
},
{
    german: "Ich habe keine Pläne.",
    russian: "У меня нет планов.",
    pronunciation: "Ихь хабе кайне плене"
},
{
    german: "Ich bin bereit.",
    russian: "Я готов.",
    pronunciation: "Ихь бин берайт"
},
{
    german: "Noch nicht.",
    russian: "Ещё нет.",
    pronunciation: "Нох нихт"
},
{
    german: "Schon fertig?",
    russian: "Уже закончил?",
    pronunciation: "Шон фертих"
},
{
    german: "Fast fertig.",
    russian: "Почти закончил.",
    pronunciation: "Фаст фертих"
},
{
    german: "Kein Grund zur Sorge.",
    russian: "Нет причин для беспокойства.",
    pronunciation: "Кайн грунд цур зорге"
},
{
    german: "Alles wird gut.",
    russian: "Всё будет хорошо.",
    pronunciation: "Аллес вирд гут"
}

];