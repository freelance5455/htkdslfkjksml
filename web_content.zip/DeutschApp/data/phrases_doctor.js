const doctorPhrases = [

{
    german: "Ich habe Schmerzen",
    russian: "У меня болит",
    pronunciation: "Ихь хабе шмерцен"
},
{
    german: "Ich brauche einen Termin",
    russian: "Мне нужна запись на приём",
    pronunciation: "Ихь браухе айнен термин"
}

];