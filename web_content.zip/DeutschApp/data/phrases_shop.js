const phrasesShop = [
{
    german: "Guten Tag.",
    russian: "Добрый день.",
    pronunciation: "Гутен таг"
},
{
    german: "Kann ich Ihnen helfen?",
    russian: "Могу я Вам помочь?",
    pronunciation: "Кан ихь инен хельфен"
},
{
    german: "Ich schaue nur.",
    russian: "Я просто смотрю.",
    pronunciation: "Ихь шауэ нур"
},
{
    german: "Wie viel kostet das?",
    russian: "Сколько это стоит?",
    pronunciation: "Ви филь костет дас"
},
{
    german: "Das ist zu teuer.",
    russian: "Это слишком дорого.",
    pronunciation: "Дас ист цу тойер"
},
{
    german: "Das ist günstig.",
    russian: "Это недорого.",
    pronunciation: "Дас ист гюнстих"
},
{
    german: "Ich nehme das.",
    russian: "Я возьму это.",
    pronunciation: "Ихь неме дас"
},
{
    german: "Ich brauche das.",
    russian: "Мне это нужно.",
    pronunciation: "Ихь браухе дас"
},
{
    german: "Haben Sie das?",
    russian: "У Вас это есть?",
    pronunciation: "Хабен зи дас"
},
{
    german: "Wo finde ich das?",
    russian: "Где я могу это найти?",
    pronunciation: "Во финде ихь дас"
},
{
    german: "Haben Sie etwas Kleineres?",
    russian: "У Вас есть что-нибудь поменьше?",
    pronunciation: "Хабен зи этвас кляйнерес"
},
{
    german: "Haben Sie etwas Größeres?",
    russian: "У Вас есть что-нибудь побольше?",
    pronunciation: "Хабен зи этвас грёссерес"
},
{
    german: "Welche Größe ist das?",
    russian: "Какой это размер?",
    pronunciation: "Вельхе грёсе ист дас"
},
{
    german: "Ich suche Größe M.",
    russian: "Я ищу размер M.",
    pronunciation: "Ихь зухе грёсе эм"
},
{
    german: "Kann ich das anprobieren?",
    russian: "Можно примерить?",
    pronunciation: "Кан ихь дас анпробирен"
},
{
    german: "Wo ist die Umkleidekabine?",
    russian: "Где примерочная?",
    pronunciation: "Во ист ди умкляйдекабине"
},
{
    german: "Ich kaufe das.",
    russian: "Я покупаю это.",
    pronunciation: "Ихь кауфе дас"
},
{
    german: "Kann ich mit Karte bezahlen?",
    russian: "Можно оплатить картой?",
    pronunciation: "Кан ихь мит карте бецален"
},
{
    german: "Ich möchte bar bezahlen.",
    russian: "Я хочу оплатить наличными.",
    pronunciation: "Ихь мёхте бар бецален"
},
{
    german: "Brauche ich die Rechnung?",
    russian: "Мне нужен чек?",
    pronunciation: "Браухе ихь ди рехнунг"
},
{
    german: "Wo ist die Kasse?",
    russian: "Где касса?",
    pronunciation: "Во ист ди кассе"
},
{
    german: "Wie viel kostet ein Kilogramm?",
    russian: "Сколько стоит килограмм?",
    pronunciation: "Ви филь костет айн килограм"
},
{
    german: "Haben Sie frisches Brot?",
    russian: "У вас есть свежий хлеб?",
    pronunciation: "Хабен зи фришес брот"
},
{
    german: "Ich möchte ein Brot.",
    russian: "Я хочу один хлеб.",
    pronunciation: "Ихь мёхте айн брот"
},
{
    german: "Ich möchte zwei Brötchen.",
    russian: "Я хочу две булочки.",
    pronunciation: "Ихь мёхте цвай брётхен"
},
{
    german: "Wo ist die Milch?",
    russian: "Где молоко?",
    pronunciation: "Во ист ди мильх"
},
{
    german: "Wo finde ich Kaffee?",
    russian: "Где найти кофе?",
    pronunciation: "Во финде ихь кафе"
},
{
    german: "Haben Sie Eier?",
    russian: "У вас есть яйца?",
    pronunciation: "Хабен зи айер"
},
{
    german: "Ich brauche Wasser.",
    russian: "Мне нужна вода.",
    pronunciation: "Ихь браухе вассер"
},
{
    german: "Welche Marke empfehlen Sie?",
    russian: "Какую марку Вы рекомендуете?",
    pronunciation: "Вельхе марке эмпфелен зи"
},
{
    german: "Ist das im Angebot?",
    russian: "Это по акции?",
    pronunciation: "Ист дас им ангебот"
},
{
    german: "Gibt es Rabatt?",
    russian: "Есть скидка?",
    pronunciation: "Гибт эс рабат"
},
{
    german: "Kann ich das umtauschen?",
    russian: "Можно обменять это?",
    pronunciation: "Кан ихь дас умтаушен"
},
{
    german: "Kann ich das zurückgeben?",
    russian: "Можно вернуть это?",
    pronunciation: "Кан ихь дас цурюкгебен"
},
{
    german: "Das ist beschädigt.",
    russian: "Это повреждено.",
    pronunciation: "Дас ист бешедигт"
},
{
    german: "Haben Sie eine andere Farbe?",
    russian: "Есть другой цвет?",
    pronunciation: "Хабен зи айне андере фарбе"
},
{
    german: "Haben Sie eine andere Größe?",
    russian: "Есть другой размер?",
    pronunciation: "Хабен зи айне андере грёсе"
},
{
    german: "Ich suche etwas Günstiges.",
    russian: "Я ищу что-то недорогое.",
    pronunciation: "Ихь зухе этвас гюнстигес"
},
{
    german: "Nur diese?",
    russian: "Только эти?",
    pronunciation: "Нур дизе"
},
{
    german: "Diese hier.",
    russian: "Вот эти.",
    pronunciation: "Дизе хир"
},
{
    german: "Diese kleineren.",
    russian: "Вот эти поменьше.",
    pronunciation: "Дизе кляйнерен"
},
{
    german: "Zwei von diesen.",
    russian: "Два вот этих.",
    pronunciation: "Цвай фон дизен"
},
{
    german: "Mehr brauche ich nicht.",
    russian: "Больше мне не нужно.",
    pronunciation: "Мер браухе ихь нихт"
},
{
    german: "Das ist alles.",
    russian: "Это всё.",
    pronunciation: "Дас ист аллес"
},
{
    german: "Vielen Dank, auf Wiedersehen.",
    russian: "Большое спасибо, до свидания.",
    pronunciation: "Филен данк, ауф видерзеен"
}
];