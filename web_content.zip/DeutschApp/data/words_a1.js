const wordsA1 = [

{
    german: "Hallo",
    russian: "Привет",
    pronunciation: "Халло"
},
{
    german: "Guten Morgen",
    russian: "Доброе утро",
    pronunciation: "Гутен морген"
},
{
    german: "Guten Tag",
    russian: "Добрый день",
    pronunciation: "Гутен таг"
},
{
    german: "Guten Abend",
    russian: "Добрый вечер",
    pronunciation: "Гутен абент"
},
{
    german: "Auf Wiedersehen",
    russian: "До свидания",
    pronunciation: "Ауф видерзеен"
},
{
    german: "Danke",
    russian: "Спасибо",
    pronunciation: "Данке"
},
{
    german: "Bitte",
    russian: "Пожалуйста",
    pronunciation: "Битте"
},
{
    german: "Ja",
    russian: "Да",
    pronunciation: "Я"
},
{
    german: "Nein",
    russian: "Нет",
    pronunciation: "Найн"
},
{
    german: "Entschuldigung",
    russian: "Извините",
    pronunciation: "Энтшульдигунг"
},
{
    german: "Wasser",
    russian: "Вода",
    pronunciation: "Вассер"
},
{
    german: "Brot",
    russian: "Хлеб",
    pronunciation: "Брот"
},
{
    german: "Milch",
    russian: "Молоко",
    pronunciation: "Мильх"
},
{
    german: "Kaffee",
    russian: "Кофе",
    pronunciation: "Кафе"
},
{
    german: "Tee",
    russian: "Чай",
    pronunciation: "Тее"
},
{
    german: "Haus",
    russian: "Дом",
    pronunciation: "Хаус"
},
{
    german: "Wohnung",
    russian: "Квартира",
    pronunciation: "Вонунг"
},
{
    german: "Zimmer",
    russian: "Комната",
    pronunciation: "Циммер"
},
{
    german: "Tür",
    russian: "Дверь",
    pronunciation: "Тюр"
},
{
    german: "Fenster",
    russian: "Окно",
    pronunciation: "Фенстер"
},
{
    german: "Auto",
    russian: "Машина",
    pronunciation: "Ауто"
},
{
    german: "Bahnhof",
    russian: "Вокзал",
    pronunciation: "Банхоф"
},
{
    german: "Straße",
    russian: "Улица",
    pronunciation: "Штрассе"
},
{
    german: "Arbeit",
    russian: "Работа",
    pronunciation: "Арбайт"
},
{
    german: "Chef",
    russian: "Начальник",
    pronunciation: "Шеф"
},
{
    german: "Kollege",
    russian: "Коллега",
    pronunciation: "Колеге"
},
{
    german: "Freund",
    russian: "Друг",
    pronunciation: "Фройнд"
},
{
    german: "Familie",
    russian: "Семья",
    pronunciation: "Фамилие"
},
{
    german: "Mutter",
    russian: "Мама",
    pronunciation: "Муттер"
},
{
    german: "Vater",
    russian: "Папа",
    pronunciation: "Фатер"
},
{
    german: "Bruder",
    russian: "Брат",
    pronunciation: "Брудер"
},
{
    german: "Schwester",
    russian: "Сестра",
    pronunciation: "Швестер"
},
{
    german: "Kind",
    russian: "Ребёнок",
    pronunciation: "Кинд"
},
{
    german: "Mann",
    russian: "Мужчина",
    pronunciation: "Ман"
},
{
    german: "Frau",
    russian: "Женщина",
    pronunciation: "Фрау"
},
{
    german: "Name",
    russian: "Имя",
    pronunciation: "Наме"
},
{
    german: "Alter",
    russian: "Возраст",
    pronunciation: "Альтер"
},
{
    german: "Stadt",
    russian: "Город",
    pronunciation: "Штат"
},
{
    german: "Dorf",
    russian: "Деревня",
    pronunciation: "Дорф"
},
{
    german: "Land",
    russian: "Страна",
    pronunciation: "Ланд"
},
{
    german: "Deutsch",
    russian: "Немецкий язык",
    pronunciation: "Дойч"
},
{
    german: "Sprache",
    russian: "Язык",
    pronunciation: "Шпрахе"
},
{
    german: "Schule",
    russian: "Школа",
    pronunciation: "Шуле"
},
{
    german: "Lehrer",
    russian: "Учитель",
    pronunciation: "Лерер"
},
{
    german: "Schüler",
    russian: "Ученик",
    pronunciation: "Шюлер"
},
{
    german: "Buch",
    russian: "Книга",
    pronunciation: "Бух"
},
{
    german: "Heft",
    russian: "Тетрадь",
    pronunciation: "Хефт"
},
{
    german: "Stift",
    russian: "Ручка",
    pronunciation: "Штифт"
},
{
    german: "Tisch",
    russian: "Стол",
    pronunciation: "Тиш"
},
{
    german: "Stuhl",
    russian: "Стул",
    pronunciation: "Штуль"
},
{
    german: "Hand",
    russian: "Рука",
    pronunciation: "Ханд"
},
{
    german: "Kopf",
    russian: "Голова",
    pronunciation: "Копф"
},
{
    german: "Auge",
    russian: "Глаз",
    pronunciation: "Ауге"
},
{
    german: "Nase",
    russian: "Нос",
    pronunciation: "Назе"
},
{
    german: "Mund",
    russian: "Рот",
    pronunciation: "Мунд"
},
{
    german: "Ohr",
    russian: "Ухо",
    pronunciation: "Ор"
},
{
    german: "Bein",
    russian: "Нога",
    pronunciation: "Байн"
},
{
    german: "Fuß",
    russian: "Ступня",
    pronunciation: "Фус"
},
{
    german: "Finger",
    russian: "Палец",
    pronunciation: "Фингер"
},
{
    german: "Tag",
    russian: "День",
    pronunciation: "Таг"
},
{
    german: "Apfel",
    russian: "Яблоко",
    pronunciation: "Апфель"
},
{
    german: "Banane",
    russian: "Банан",
    pronunciation: "Банане"
},
{
    german: "Orange",
    russian: "Апельсин",
    pronunciation: "Оранже"
},
{
    german: "Kartoffel",
    russian: "Картошка",
    pronunciation: "Картофель"
},
{
    german: "Tomate",
    russian: "Помидор",
    pronunciation: "Томате"
},
{
    german: "Gurke",
    russian: "Огурец",
    pronunciation: "Гурке"
},
{
    german: "Zwiebel",
    russian: "Лук",
    pronunciation: "Цвибель"
},
{
    german: "Kohl",
    russian: "Капуста",
    pronunciation: "Коль"
},
{
    german: "Salat",
    russian: "Салат",
    pronunciation: "Залат"
},
{
    german: "Gemüse",
    russian: "Овощи",
    pronunciation: "Гемюзе"
},
{
    german: "Obst",
    russian: "Фрукты",
    pronunciation: "Обст"
},
{
    german: "Fleisch",
    russian: "Мясо",
    pronunciation: "Фляйш"
},
{
    german: "Fisch",
    russian: "Рыба",
    pronunciation: "Фиш"
},
{
    german: "Ei",
    russian: "Яйцо",
    pronunciation: "Ай"
},
{
    german: "Käse",
    russian: "Сыр",
    pronunciation: "Кезе"
},
{
    german: "Butter",
    russian: "Масло",
    pronunciation: "Буттер"
},
{
    german: "Zucker",
    russian: "Сахар",
    pronunciation: "Цукер"
},
{
    german: "Salz",
    russian: "Соль",
    pronunciation: "Зальц"
},
{
    german: "Pfeffer",
    russian: "Перец",
    pronunciation: "Пфеффер"
},
{
    german: "Suppe",
    russian: "Суп",
    pronunciation: "Зуппе"
},
{
    german: "Wurst",
    russian: "Колбаса",
    pronunciation: "Вурст"
},
{
    german: "Hähnchen",
    russian: "Курица",
    pronunciation: "Хенхен"
},
{
    german: "Pizza",
    russian: "Пицца",
    pronunciation: "Пицца"
},
{
    german: "Restaurant",
    russian: "Ресторан",
    pronunciation: "Ресторан"
},
{
    german: "Supermarkt",
    russian: "Супермаркет",
    pronunciation: "Зупермаркт"
},
{
    german: "Kasse",
    russian: "Касса",
    pronunciation: "Кассе"
},
{
    german: "Preis",
    russian: "Цена",
    pronunciation: "Прайс"
},
{
    german: "Geld",
    russian: "Деньги",
    pronunciation: "Гельд"
},
{
    german: "Euro",
    russian: "Евро",
    pronunciation: "Ойро"
},
{
    german: "Rechnung",
    russian: "Чек",
    pronunciation: "Рехнунг"
},
{
    german: "Bus",
    russian: "Автобус",
    pronunciation: "Бус"
},
{
    german: "Zug",
    russian: "Поезд",
    pronunciation: "Цуг"
},
{
    german: "Straßenbahn",
    russian: "Трамвай",
    pronunciation: "Штрассенбан"
},
{
    german: "U-Bahn",
    russian: "Метро",
    pronunciation: "У-бан"
},
{
    german: "Haltestelle",
    russian: "Остановка",
    pronunciation: "Хальтештелле"
},
{
    german: "Fahrkarte",
    russian: "Билет",
    pronunciation: "Фаркарте"
},
{
    german: "Flughafen",
    russian: "Аэропорт",
    pronunciation: "Флюгхафен"
},
{
    german: "Reise",
    russian: "Путешествие",
    pronunciation: "Райзе"
},
{
    german: "Weg",
    russian: "Путь",
    pronunciation: "Вег"
},
{
    german: "Adresse",
    russian: "Адрес",
    pronunciation: "Адрессе"
},
{
    german: "Miete",
    russian: "Аренда",
    pronunciation: "Мите"
},
{
    german: "Schlüssel",
    russian: "Ключ",
    pronunciation: "Шлюссель"
},
{
    german: "Küche",
    russian: "Кухня",
    pronunciation: "Кюхе"
},
{
    german: "Bad",
    russian: "Ванная",
    pronunciation: "Бад"
},
{
    german: "Dusche",
    russian: "Душ",
    pronunciation: "Душе"
},
{
    german: "Bett",
    russian: "Кровать",
    pronunciation: "Бетт"
},
{
    german: "Lampe",
    russian: "Лампа",
    pronunciation: "Лампе"
},
{
    german: "Möbel",
    russian: "Мебель",
    pronunciation: "Мёбель"
},
{
    german: "Nachbar",
    russian: "Сосед",
    pronunciation: "Нахбар"
},
{
    german: "Stock",
    russian: "Этаж",
    pronunciation: "Шток"
},
{
    german: "Strom",
    russian: "Электричество",
    pronunciation: "Штром"
},
{
    german: "Heizung",
    russian: "Отопление",
    pronunciation: "Хайцунг"
},
{
    german: "Wand",
    russian: "Стена",
    pronunciation: "Ванд"
},
{
    german: "Boden",
    russian: "Пол",
    pronunciation: "Боден"
},
{
    german: "Decke",
    russian: "Потолок",
    pronunciation: "Декке"
},
{
    german: "der",
    russian: "артикль мужского рода",
    pronunciation: "дер"
},
{
    german: "die",
    russian: "артикль женского рода",
    pronunciation: "ди"
},
{
    german: "das",
    russian: "артикль среднего рода",
    pronunciation: "дас"
},
{
    german: "ein",
    russian: "неопределённый артикль (м.р.)",
    pronunciation: "айн"
},
{
    german: "eine",
    russian: "неопределённый артикль (ж.р.)",
    pronunciation: "айне"
},
{
    german: "ich",
    russian: "я",
    pronunciation: "ихь"
},
{
    german: "du",
    russian: "ты",
    pronunciation: "ду"
},
{
    german: "er",
    russian: "он",
    pronunciation: "эр"
},
{
    german: "sie",
    russian: "она / они / Вы",
    pronunciation: "зи"
},
{
    german: "es",
    russian: "оно",
    pronunciation: "эс"
},
{
    german: "wir",
    russian: "мы",
    pronunciation: "вир"
},
{
    german: "ihr",
    russian: "вы",
    pronunciation: "ир"
},
{
    german: "sein",
    russian: "быть",
    pronunciation: "зайн"
},
{
    german: "haben",
    russian: "иметь",
    pronunciation: "хабен"
},
{
    german: "werden",
    russian: "становиться",
    pronunciation: "вердэн"
},
{
    german: "wohnen",
    russian: "жить, проживать",
    pronunciation: "вонен"
},
{
    german: "arbeiten",
    russian: "работать",
    pronunciation: "арбайтен"
},
{
    german: "lernen",
    russian: "учить",
    pronunciation: "лернен"
},
{
    german: "sprechen",
    russian: "говорить",
    pronunciation: "шпрехен"
},
{
    german: "verstehen",
    russian: "понимать",
    pronunciation: "ферштеен"
},
{
    german: "gehen",
    russian: "идти",
    pronunciation: "геен"
},
{
    german: "kommen",
    russian: "приходить",
    pronunciation: "коммен"
},
{
    german: "fahren",
    russian: "ехать",
    pronunciation: "фарен"
},
{
    german: "kaufen",
    russian: "покупать",
    pronunciation: "кауфен"
},
{
    german: "bezahlen",
    russian: "платить",
    pronunciation: "бецален"
},
{
    german: "essen",
    russian: "есть",
    pronunciation: "эссен"
},
{
    german: "trinken",
    russian: "пить",
    pronunciation: "тринкен"
},
{
    german: "schlafen",
    russian: "спать",
    pronunciation: "шлафен"
},
{
    german: "kochen",
    russian: "готовить",
    pronunciation: "кохен"
},
{
    german: "duschen",
    russian: "принимать душ",
    pronunciation: "душен"
},
{
    german: "waschen",
    russian: "мыть",
    pronunciation: "вашен"
},
{
    german: "spielen",
    russian: "играть",
    pronunciation: "шпилен"
},
{
    german: "Wer?",
    russian: "Кто?",
    pronunciation: "вер"
},
{
    german: "Was?",
    russian: "Что?",
    pronunciation: "вас"
},
{
    german: "Wo?",
    russian: "Где?",
    pronunciation: "во"
},
{
    german: "Wann?",
    russian: "Когда?",
    pronunciation: "ван"
},
{
    german: "Warum?",
    russian: "Почему?",
    pronunciation: "варум"
},
{
    german: "Wie?",
    russian: "Как?",
    pronunciation: "ви"
},
{
    german: "heute",
    russian: "сегодня",
    pronunciation: "хойте"
},
{
    german: "morgen",
    russian: "завтра",
    pronunciation: "морген"
},
{
    german: "gestern",
    russian: "вчера",
    pronunciation: "гестерн"
},
{
    german: "jetzt",
    russian: "сейчас",
    pronunciation: "йетцт"
},
{
    german: "immer",
    russian: "всегда",
    pronunciation: "иммер"
},
{
    german: "nie",
    russian: "никогда",
    pronunciation: "ни"
},
{
    german: "oft",
    russian: "часто",
    pronunciation: "офт"
},
{
    german: "mit",
    russian: "с",
    pronunciation: "мит"
},
{
    german: "für",
    russian: "для",
    pronunciation: "фюр"
},
{
    german: "von",
    russian: "от",
    pronunciation: "фон"
},
{
    german: "nach",
    russian: "в, после",
    pronunciation: "нах"
},
{
    german: "bei",
    russian: "у, при",
    pronunciation: "бай"
},
{
    german: "in",
    russian: "в",
    pronunciation: "ин"
},
{
    german: "auf",
    russian: "на",
    pronunciation: "ауф"
},
{
    german: "und",
    russian: "и",
    pronunciation: "унд"
},
{
    german: "oder",
    russian: "или",
    pronunciation: "одер"
},
{
    german: "aber",
    russian: "но",
    pronunciation: "абер"
},
{
    german: "null",
    russian: "ноль",
    pronunciation: "нуль"
},
{
    german: "eins",
    russian: "один",
    pronunciation: "айнс"
},
{
    german: "zwei",
    russian: "два",
    pronunciation: "цвай"
},
{
    german: "drei",
    russian: "три",
    pronunciation: "драй"
},
{
    german: "vier",
    russian: "четыре",
    pronunciation: "фир"
},
{
    german: "fünf",
    russian: "пять",
    pronunciation: "фюнф"
},
{
    german: "sechs",
    russian: "шесть",
    pronunciation: "зекс"
},
{
    german: "sieben",
    russian: "семь",
    pronunciation: "зибен"
},
{
    german: "acht",
    russian: "восемь",
    pronunciation: "ахт"
},
{
    german: "neun",
    russian: "девять",
    pronunciation: "нойн"
},
{
    german: "zehn",
    russian: "десять",
    pronunciation: "цеен"
},
{
    german: "elf",
    russian: "одиннадцать",
    pronunciation: "эльф"
},
{
    german: "zwölf",
    russian: "двенадцать",
    pronunciation: "цвёльф"
},
{
    german: "dreizehn",
    russian: "тринадцать",
    pronunciation: "драйцеен"
},
{
    german: "vierzehn",
    russian: "четырнадцать",
    pronunciation: "фирцеен"
},
{
    german: "fünfzehn",
    russian: "пятнадцать",
    pronunciation: "фюнфцеен"
},
{
    german: "zwanzig",
    russian: "двадцать",
    pronunciation: "цванцих"
},
{
    german: "dreißig",
    russian: "тридцать",
    pronunciation: "драйсих"
},
{
    german: "vierzig",
    russian: "сорок",
    pronunciation: "фирцих"
},
{
    german: "fünfzig",
    russian: "пятьдесят",
    pronunciation: "фюнфцих"
},
{
    german: "hundert",
    russian: "сто",
    pronunciation: "хундерт"
},
{
    german: "tausend",
    russian: "тысяча",
    pronunciation: "таузенд"
},
{
    german: "Montag",
    russian: "понедельник",
    pronunciation: "монтаг"
},
{
    german: "Dienstag",
    russian: "вторник",
    pronunciation: "динстаг"
},
{
    german: "Mittwoch",
    russian: "среда",
    pronunciation: "митвох"
},
{
    german: "Donnerstag",
    russian: "четверг",
    pronunciation: "доннерстаг"
},
{
    german: "Freitag",
    russian: "пятница",
    pronunciation: "фрайтаг"
},
{
    german: "Samstag",
    russian: "суббота",
    pronunciation: "замстаг"
},
{
    german: "Sonntag",
    russian: "воскресенье",
    pronunciation: "зоннтаг"
},
{
    german: "Januar",
    russian: "январь",
    pronunciation: "януар"
},
{
    german: "Februar",
    russian: "февраль",
    pronunciation: "фебруар"
},
{
    german: "März",
    russian: "март",
    pronunciation: "мерц"
},
{
    german: "April",
    russian: "апрель",
    pronunciation: "априль"
},
{
    german: "Mai",
    russian: "май",
    pronunciation: "май"
},
{
    german: "Juni",
    russian: "июнь",
    pronunciation: "юни"
},
{
    german: "Juli",
    russian: "июль",
    pronunciation: "юли"
},
{
    german: "August",
    russian: "август",
    pronunciation: "аугуст"
},
{
    german: "September",
    russian: "сентябрь",
    pronunciation: "зептембер"
},
{
    german: "Oktober",
    russian: "октябрь",
    pronunciation: "октобер"
},
{
    german: "November",
    russian: "ноябрь",
    pronunciation: "новембер"
},
{
    german: "Dezember",
    russian: "декабрь",
    pronunciation: "децембер"
},
{
    german: "Uhr",
    russian: "час",
    pronunciation: "ур"
},
{
    german: "Minute",
    russian: "минута",
    pronunciation: "минуте"
},
{
    german: "Sekunde",
    russian: "секунда",
    pronunciation: "зекунде"
},
{
    german: "Tag",
    russian: "день",
    pronunciation: "таг"
},
{
    german: "Woche",
    russian: "неделя",
    pronunciation: "вохе"
},
{
    german: "Monat",
    russian: "месяц",
    pronunciation: "монат"
},
{
    german: "Jahr",
    russian: "год",
    pronunciation: "яр"
},
{
    german: "früh",
    russian: "рано",
    pronunciation: "фрю"
},
{
    german: "spät",
    russian: "поздно",
    pronunciation: "шпэт"
},
{
    german: "Beruf",
    russian: "профессия",
    pronunciation: "беруф"
},
{
    german: "Arbeiter",
    russian: "рабочий",
    pronunciation: "арбайтер"
},
{
    german: "Mitarbeiter",
    russian: "сотрудник",
    pronunciation: "митарбайтер"
},
{
    german: "Firma",
    russian: "фирма",
    pronunciation: "фирма"
},
{
    german: "Büro",
    russian: "офис",
    pronunciation: "бюро"
},
{
    german: "Chef",
    russian: "начальник",
    pronunciation: "шеф"
},
{
    german: "Kollege",
    russian: "коллега",
    pronunciation: "колеге"
},
{
    german: "Pause",
    russian: "перерыв",
    pronunciation: "паузе"
},
{
    german: "Arbeitszeit",
    russian: "рабочее время",
    pronunciation: "арбайтсцайт"
},
{
    german: "Lohn",
    russian: "зарплата",
    pronunciation: "лон"
},
{
    german: "Gehalt",
    russian: "оклад",
    pronunciation: "гехальт"
},
{
    german: "Vertrag",
    russian: "договор",
    pronunciation: "фертраг"
},
{
    german: "Urlaub",
    russian: "отпуск",
    pronunciation: "урлауб"
},
{
    german: "Schicht",
    russian: "смена",
    pronunciation: "шихт"
},
{
    german: "Überstunden",
    russian: "сверхурочные",
    pronunciation: "юберштунден"
},
{
    german: "Bewerbung",
    russian: "заявление на работу",
    pronunciation: "бевербунг"
},
{
    german: "Lebenslauf",
    russian: "резюме",
    pronunciation: "лебенслауф"
},
{
    german: "Ausbildung",
    russian: "обучение, профессия",
    pronunciation: "аусбильдунг"
},
{
    german: "Praktikum",
    russian: "практика",
    pronunciation: "практикум"
},
{
    german: "Feierabend",
    russian: "конец рабочего дня",
    pronunciation: "файерабенд"
},
{
    german: "arbeiten",
    russian: "работать",
    pronunciation: "арбайтен"
},
{
    german: "verdienen",
    russian: "зарабатывать",
    pronunciation: "фердинен"
},
{
    german: "unterschreiben",
    russian: "подписывать",
    pronunciation: "унтершрайбен"
},
{
    german: "helfen",
    russian: "помогать",
    pronunciation: "хельфен"
},
{
    german: "fragen",
    russian: "спрашивать",
    pronunciation: "фраген"
},
{
    german: "Arzt",
    russian: "врач",
    pronunciation: "арцт"
},
{
    german: "Ärztin",
    russian: "женщина-врач",
    pronunciation: "эрцтин"
},
{
    german: "Krankenhaus",
    russian: "больница",
    pronunciation: "кранкенхаус"
},
{
    german: "Apotheke",
    russian: "аптека",
    pronunciation: "апотеке"
},
{
    german: "Medikament",
    russian: "лекарство",
    pronunciation: "медикамент"
},
{
    german: "Tablette",
    russian: "таблетка",
    pronunciation: "таблетте"
},
{
    german: "Rezept",
    russian: "рецепт",
    pronunciation: "рецепт"
},
{
    german: "Termin",
    russian: "запись на приём",
    pronunciation: "термин"
},
{
    german: "Patient",
    russian: "пациент",
    pronunciation: "пациент"
},
{
    german: "Krankheit",
    russian: "болезнь",
    pronunciation: "кранкхайт"
},
{
    german: "Gesundheit",
    russian: "здоровье",
    pronunciation: "гезундхайт"
},
{
    german: "Schmerz",
    russian: "боль",
    pronunciation: "шмерц"
},
{
    german: "Fieber",
    russian: "температура",
    pronunciation: "фибер"
},
{
    german: "Husten",
    russian: "кашель",
    pronunciation: "хустен"
},
{
    german: "Schnupfen",
    russian: "насморк",
    pronunciation: "шнупфен"
},
{
    german: "Kopfweh",
    russian: "головная боль",
    pronunciation: "копфве"
},
{
    german: "Bauch",
    russian: "живот",
    pronunciation: "баух"
},
{
    german: "Rücken",
    russian: "спина",
    pronunciation: "рюккен"
},
{
    german: "Zahn",
    russian: "зуб",
    pronunciation: "цан"
},
{
    german: "Blut",
    russian: "кровь",
    pronunciation: "блут"
},
{
    german: "Unfall",
    russian: "несчастный случай",
    pronunciation: "унфаль"
},
{
    german: "Notfall",
    russian: "экстренный случай",
    pronunciation: "нотфаль"
},
{
    german: "krank",
    russian: "больной",
    pronunciation: "кранк"
},
{
    german: "gesund",
    russian: "здоровый",
    pronunciation: "гезунд"
},
{
    german: "helfen",
    russian: "помогать",
    pronunciation: "хельфен"
},
{
    german: "untersuchen",
    russian: "обследовать",
    pronunciation: "унтерзухен"
},
{
    german: "warten",
    russian: "ждать",
    pronunciation: "вартен"
},
{
    german: "heilen",
    russian: "лечить",
    pronunciation: "хайлен"
},
{
    german: "Pass",
    russian: "паспорт",
    pronunciation: "пас"
},
{
    german: "Ausweis",
    russian: "удостоверение личности",
    pronunciation: "аусвайс"
},
{
    german: "Dokument",
    russian: "документ",
    pronunciation: "документ"
},
{
    german: "Formular",
    russian: "анкета, бланк",
    pronunciation: "формуляр"
},
{
    german: "Unterschrift",
    russian: "подпись",
    pronunciation: "унтершрифт"
},
{
    german: "Adresse",
    russian: "адрес",
    pronunciation: "адрессе"
},
{
    german: "Postleitzahl",
    russian: "почтовый индекс",
    pronunciation: "постляйцаль"
},
{
    german: "Brief",
    russian: "письмо",
    pronunciation: "бриф"
},
{
    german: "Post",
    russian: "почта",
    pronunciation: "пост"
},
{
    german: "Paket",
    russian: "посылка",
    pronunciation: "пакет"
},
{
    german: "Bank",
    russian: "банк",
    pronunciation: "банк"
},
{
    german: "Konto",
    russian: "счёт",
    pronunciation: "конто"
},
{
    german: "Bankkarte",
    russian: "банковская карта",
    pronunciation: "банккарте"
},
{
    german: "Geldautomat",
    russian: "банкомат",
    pronunciation: "гельдаутомат"
},
{
    german: "Versicherung",
    russian: "страховка",
    pronunciation: "ферзихерунг"
},
{
    german: "Krankenversicherung",
    russian: "медицинская страховка",
    pronunciation: "кранкенферзихерунг"
},
{
    german: "Amt",
    russian: "учреждение, ведомство",
    pronunciation: "амт"
},
{
    german: "Rathaus",
    russian: "ратуша, мэрия",
    pronunciation: "ратхаус"
},
{
    german: "Bürgeramt",
    russian: "центр обслуживания граждан",
    pronunciation: "бюргерамт"
},
{
    german: "Anmeldung",
    russian: "регистрация",
    pronunciation: "анмельдунг"
},
{
    german: "Bescheinigung",
    russian: "справка",
    pronunciation: "бешайнигунг"
},
{
    german: "Termin",
    russian: "запись, встреча",
    pronunciation: "термин"
},
{
    german: "Nummer",
    russian: "номер",
    pronunciation: "нуммер"
},
{
    german: "Telefon",
    russian: "телефон",
    pronunciation: "телефон"
},
{
    german: "Handy",
    russian: "мобильный телефон",
    pronunciation: "хэнди"
},
{
    german: "E-Mail",
    russian: "электронная почта",
    pronunciation: "и-мейль"
},
{
    german: "Internet",
    russian: "интернет",
    pronunciation: "интернет"
},
{
    german: "Kennwort",
    russian: "пароль",
    pronunciation: "кенворт"
},
{
    german: "Benutzername",
    russian: "имя пользователя",
    pronunciation: "бенутцернаме"
},
{
    german: "Unterschreiben",
    russian: "подписывать",
    pronunciation: "унтершрайбен"
},
{
    german: "Kleidung",
    russian: "одежда",
    pronunciation: "кляйдунг"
},
{
    german: "Hemd",
    russian: "рубашка",
    pronunciation: "хемд"
},
{
    german: "T-Shirt",
    russian: "футболка",
    pronunciation: "ти-ширт"
},
{
    german: "Jacke",
    russian: "куртка",
    pronunciation: "яке"
},
{
    german: "Mantel",
    russian: "пальто",
    pronunciation: "мантель"
},
{
    german: "Hose",
    russian: "штаны",
    pronunciation: "хозе"
},
{
    german: "Jeans",
    russian: "джинсы",
    pronunciation: "джинс"
},
{
    german: "Schuhe",
    russian: "обувь",
    pronunciation: "шуэ"
},
{
    german: "Socke",
    russian: "носок",
    pronunciation: "зокке"
},
{
    german: "Mütze",
    russian: "шапка",
    pronunciation: "мютце"
},
{
    german: "Handschuh",
    russian: "перчатка",
    pronunciation: "хандшу"
},
{
    german: "Regen",
    russian: "дождь",
    pronunciation: "реген"
},
{
    german: "Schnee",
    russian: "снег",
    pronunciation: "шнее"
},
{
    german: "Wind",
    russian: "ветер",
    pronunciation: "винд"
},
{
    german: "Sonne",
    russian: "солнце",
    pronunciation: "зонне"
},
{
    german: "Wetter",
    russian: "погода",
    pronunciation: "веттер"
},
{
    german: "warm",
    russian: "тёплый",
    pronunciation: "варм"
},
{
    german: "heiß",
    russian: "жаркий",
    pronunciation: "хайс"
},
{
    german: "kalt",
    russian: "холодный",
    pronunciation: "кальт"
},
{
    german: "bewölkt",
    russian: "облачно",
    pronunciation: "бевёлькт"
},
{
    german: "sonnig",
    russian: "солнечно",
    pronunciation: "зонних"
},
{
    german: "regnerisch",
    russian: "дождливо",
    pronunciation: "регнериш"
},
{
    german: "trocken",
    russian: "сухо",
    pronunciation: "троккен"
},
{
    german: "nass",
    russian: "мокрый",
    pronunciation: "нас"
},
{
    german: "Frühling",
    russian: "весна",
    pronunciation: "фрюлинг"
},
{
    german: "Sommer",
    russian: "лето",
    pronunciation: "зоммер"
},
{
    german: "Herbst",
    russian: "осень",
    pronunciation: "хербст"
},
{
    german: "Winter",
    russian: "зима",
    pronunciation: "винтер"
},
{
    german: "Stadtzentrum",
    russian: "центр города",
    pronunciation: "штадтцентрум"
},
{
    german: "Platz",
    russian: "площадь",
    pronunciation: "плац"
},
{
    german: "Park",
    russian: "парк",
    pronunciation: "парк"
},
{
    german: "Bahnhof",
    russian: "вокзал",
    pronunciation: "банхоф"
},
{
    german: "Bushaltestelle",
    russian: "автобусная остановка",
    pronunciation: "бусхальтештелле"
},
{
    german: "Ampel",
    russian: "светофор",
    pronunciation: "ампель"
},
{
    german: "Kreuzung",
    russian: "перекрёсток",
    pronunciation: "кройцунг"
},
{
    german: "links",
    russian: "налево",
    pronunciation: "линкс"
},
{
    german: "rechts",
    russian: "направо",
    pronunciation: "рехтс"
},
{
    german: "geradeaus",
    russian: "прямо",
    pronunciation: "герадеаус"
},
{
    german: "nah",
    russian: "близко",
    pronunciation: "на"
},
{
    german: "weit",
    russian: "далеко",
    pronunciation: "вайт"
},
{
    german: "Polizei",
    russian: "полиция",
    pronunciation: "полицай"
},
{
    german: "Feuerwehr",
    russian: "пожарная служба",
    pronunciation: "фойервер"
},
{
    german: "Krankenwagen",
    russian: "скорая помощь",
    pronunciation: "кранкенваген"
},
{
    german: "Notruf",
    russian: "экстренный вызов",
    pronunciation: "нотруф"
},
{
    german: "Hilfe",
    russian: "помощь",
    pronunciation: "хильфе"
},
{
    german: "Gefahr",
    russian: "опасность",
    pronunciation: "гефар"
},
{
    german: "verloren",
    russian: "потерянный",
    pronunciation: "ферлорен"
},
{
    german: "gefunden",
    russian: "найденный",
    pronunciation: "гефунден"
},
{
    german: "Problem",
    russian: "проблема",
    pronunciation: "проблем"
},
{
    german: "wichtig",
    russian: "важный",
    pronunciation: "вихтих"
},
{
    german: "richtig",
    russian: "правильный",
    pronunciation: "рихтих"
},
{
    german: "falsch",
    russian: "неправильный",
    pronunciation: "фальш"
},
{
    german: "sicher",
    russian: "безопасно",
    pronunciation: "зихер"
},
{
    german: "offen",
    russian: "открыто",
    pronunciation: "офен"
},
{
    german: "geschlossen",
    russian: "закрыто",
    pronunciation: "гешлоссен"
},
{
    german: "Eingang",
    russian: "вход",
    pronunciation: "айнганг"
},
{
    german: "Ausgang",
    russian: "выход",
    pronunciation: "аусганг"
},
{
    german: "Toilette",
    russian: "туалет",
    pronunciation: "туалетте"
},
{
    german: "groß",
    russian: "большой",
    pronunciation: "грос"
},
{
    german: "klein",
    russian: "маленький",
    pronunciation: "клайн"
},
{
    german: "lang",
    russian: "длинный",
    pronunciation: "ланг"
},
{
    german: "kurz",
    russian: "короткий",
    pronunciation: "курц"
},
{
    german: "neu",
    russian: "новый",
    pronunciation: "ной"
},
{
    german: "alt",
    russian: "старый",
    pronunciation: "альт"
},
{
    german: "jung",
    russian: "молодой",
    pronunciation: "юнг"
},
{
    german: "gut",
    russian: "хороший",
    pronunciation: "гут"
},
{
    german: "schlecht",
    russian: "плохой",
    pronunciation: "шлехт"
},
{
    german: "schön",
    russian: "красивый",
    pronunciation: "шён"
},
{
    german: "hässlich",
    russian: "некрасивый",
    pronunciation: "хесслих"
},
{
    german: "schnell",
    russian: "быстрый",
    pronunciation: "шнель"
},
{
    german: "langsam",
    russian: "медленный",
    pronunciation: "лангзам"
},
{
    german: "stark",
    russian: "сильный",
    pronunciation: "штарк"
},
{
    german: "schwach",
    russian: "слабый",
    pronunciation: "швах"
},
{
    german: "leicht",
    russian: "лёгкий",
    pronunciation: "лайхт"
},
{
    german: "schwer",
    russian: "тяжёлый",
    pronunciation: "швер"
},
{
    german: "billig",
    russian: "дешёвый",
    pronunciation: "биллих"
},
{
    german: "teuer",
    russian: "дорогой",
    pronunciation: "тойер"
},
{
    german: "voll",
    russian: "полный",
    pronunciation: "фоль"
},
{
    german: "leer",
    russian: "пустой",
    pronunciation: "леер"
},
{
    german: "viel",
    russian: "много",
    pronunciation: "филь"
},
{
    german: "wenig",
    russian: "мало",
    pronunciation: "вених"
},
{
    german: "alle",
    russian: "все",
    pronunciation: "алле"
},
{
    german: "niemand",
    russian: "никто",
    pronunciation: "ниманд"
},
{
    german: "jemand",
    russian: "кто-то",
    pronunciation: "йеманд"
},
{
    german: "etwas",
    russian: "что-то",
    pronunciation: "этвас"
},
{
    german: "nichts",
    russian: "ничего",
    pronunciation: "нихтс"
},
{
    german: "genau",
    russian: "точно, именно",
    pronunciation: "генау"
},
{
    german: "vielleicht",
    russian: "возможно",
    pronunciation: "филяйхт"
},
{
    german: "natürlich",
    russian: "конечно",
    pronunciation: "натюрлих"
},
{
    german: "wirklich",
    russian: "действительно",
    pronunciation: "вирклих"
},
{
    german: "zusammen",
    russian: "вместе",
    pronunciation: "цузаммен"
},
{
    german: "allein",
    russian: "один, в одиночку",
    pronunciation: "аллайн"
},
{
    german: "hier",
    russian: "здесь",
    pronunciation: "хир"
},
{
    german: "dort",
    russian: "там",
    pronunciation: "дорт"
},
{
    german: "oben",
    russian: "наверху",
    pronunciation: "обен"
},
{
    german: "unten",
    russian: "внизу",
    pronunciation: "унтен"
},
{
    german: "immer",
    russian: "всегда",
    pronunciation: "иммер"
},
{
    german: "oft",
    russian: "часто",
    pronunciation: "офт"
}
  

];