const wordsA2 = [

{
    german: "Erfahrung",
    russian: "Опыт",
    pronunciation: "Эрфарунг"
},
{
    german: "Möglichkeit",
    russian: "Возможность",
    pronunciation: "Мёглихкайт"
}

];