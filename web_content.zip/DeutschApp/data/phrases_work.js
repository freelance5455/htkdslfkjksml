const phrasesWork = [
{
    german: "Guten Morgen.",
    russian: "Доброе утро.",
    pronunciation: "Гутен морген"
},
{
    german: "Ich bin neu hier.",
    russian: "Я здесь новенький.",
    pronunciation: "Ихь бин ной хир"
},
{
    german: "Wo soll ich arbeiten?",
    russian: "Где мне работать?",
    pronunciation: "Во золь ихь арбайтен"
},
{
    german: "Was soll ich machen?",
    russian: "Что мне делать?",
    pronunciation: "Вас золь ихь махен"
},
{
    german: "Können Sie mir das zeigen?",
    russian: "Можете мне это показать?",
    pronunciation: "Кённен зи мир дас цайген"
},
{
    german: "Ich habe eine Frage.",
    russian: "У меня есть вопрос.",
    pronunciation: "Ихь хабе айне фраге"
},
{
    german: "Ich verstehe nicht.",
    russian: "Я не понимаю.",
    pronunciation: "Ихь ферштее нихт"
},
{
    german: "Bitte erklären Sie das.",
    russian: "Пожалуйста, объясните это.",
    pronunciation: "Битте эрклерен зи дас"
},
{
    german: "Können Sie langsamer sprechen?",
    russian: "Можете говорить медленнее?",
    pronunciation: "Кённен зи лангзамер шпрехен"
},
{
    german: "Wo ist mein Arbeitsplatz?",
    russian: "Где моё рабочее место?",
    pronunciation: "Во ист майн арбайтсплац"
},
{
    german: "Wann beginnt die Schicht?",
    russian: "Когда начинается смена?",
    pronunciation: "Ван бегинт ди шихт"
},
{
    german: "Wann endet die Schicht?",
    russian: "Когда заканчивается смена?",
    pronunciation: "Ван эндет ди шихт"
},
{
    german: "Ich bin fertig.",
    russian: "Я закончил.",
    pronunciation: "Ихь бин фертих"
},
{
    german: "Brauchen Sie noch Hilfe?",
    russian: "Вам ещё нужна помощь?",
    pronunciation: "Браухен зи нох хильфе"
},
{
    german: "Ich brauche Hilfe.",
    russian: "Мне нужна помощь.",
    pronunciation: "Ихь браухе хильфе"
},
{
    german: "Wo ist der Chef?",
    russian: "Где начальник?",
    pronunciation: "Во ист дер шеф"
},
{
    german: "Ich komme gleich.",
    russian: "Я сейчас приду.",
    pronunciation: "Ихь комме гляйх"
},
{
    german: "Ich mache Pause.",
    russian: "Я на перерыве.",
    pronunciation: "Ихь махе паузе"
},
{
    german: "Wann ist Pause?",
    russian: "Когда перерыв?",
    pronunciation: "Ван ист паузе"
},
{
    german: "Ich bin müde.",
    russian: "Я устал.",
    pronunciation: "Ихь бин мюде"
},
{
    german: "Ich bin bereit zu arbeiten.",
    russian: "Я готов работать.",
    pronunciation: "Ихь бин берайт цу арбайтен"
},
{
    german: "Was ist meine Aufgabe?",
    russian: "Какая моя задача?",
    pronunciation: "Вас ист майне ауфгабе"
},
{
    german: "Kann ich anfangen?",
    russian: "Могу я начать?",
    pronunciation: "Кан ихь анфанген"
},
{
    german: "Ich habe die Aufgabe erledigt.",
    russian: "Я выполнил задачу.",
    pronunciation: "Ихь хабе ди ауфгабе эрледигт"
},
{
    german: "Was soll ich als Nächstes machen?",
    russian: "Что мне делать дальше?",
    pronunciation: "Вас золь ихь альс некстес махен"
},
{
    german: "Können Sie das wiederholen?",
    russian: "Можете повторить?",
    pronunciation: "Кённен зи дас видерхолен"
},
{
    german: "Ich habe verstanden.",
    russian: "Я понял.",
    pronunciation: "Ихь хабе ферштанден"
},
{
    german: "Ich habe ein Problem.",
    russian: "У меня проблема.",
    pronunciation: "Ихь хабе айн проблем"
},
{
    german: "Die Maschine funktioniert nicht.",
    russian: "Машина не работает.",
    pronunciation: "Ди машина функциунирт нихт"
},
{
    german: "Das Werkzeug fehlt.",
    russian: "Не хватает инструмента.",
    pronunciation: "Дас веркцойг фельт"
},
{
    german: "Wo finde ich das?",
    russian: "Где я могу это найти?",
    pronunciation: "Во финде ихь дас"
},
{
    german: "Ich brauche mehr Zeit.",
    russian: "Мне нужно больше времени.",
    pronunciation: "Ихь браухе мер цайт"
},
{
    german: "Das ist schwer.",
    russian: "Это тяжело.",
    pronunciation: "Дас ист швер"
},
{
    german: "Das ist einfach.",
    russian: "Это легко.",
    pronunciation: "Дас ист айнфах"
},
{
    german: "Bitte helfen Sie mir.",
    russian: "Пожалуйста, помогите мне.",
    pronunciation: "Битте хельфен зи мир"
},
{
    german: "Ich arbeite daran.",
    russian: "Я работаю над этим.",
    pronunciation: "Ихь арбайте даран"
},
{
    german: "Ich bin gleich fertig.",
    russian: "Я скоро закончу.",
    pronunciation: "Ихь бин гляйх фертих"
},
{
    german: "Ist alles in Ordnung?",
    russian: "Всё в порядке?",
    pronunciation: "Ист аллес ин орднунг"
},
{
    german: "Ja, alles ist in Ordnung.",
    russian: "Да, всё в порядке.",
    pronunciation: "Я аллес ист ин орднунг"
},
{
    german: "Nein, ich brauche Hilfe.",
    russian: "Нет, мне нужна помощь.",
    pronunciation: "Найн ихь браухе хильфе"
},
{
    german: "Wann bekomme ich meinen Lohn?",
    russian: "Когда я получу зарплату?",
    pronunciation: "Ван бекомме ихь майнен лон"
},
{
    german: "Ich habe heute Frühschicht.",
    russian: "У меня сегодня утренняя смена.",
    pronunciation: "Ихь хабе хойте фрюшихт"
},
{
    german: "Ich habe heute Spätschicht.",
    russian: "У меня сегодня вечерняя смена.",
    pronunciation: "Ихь хабе хойте шпэтшихт"
},
{
    german: "Ich bin krank und kann nicht kommen.",
    russian: "Я болен и не могу прийти.",
    pronunciation: "Ихь бин кранк унд кан нихт коммен"
},
{
    german: "Mein Auto startet nicht.",
    russian: "Моя машина не заводится.",
    pronunciation: "Майн ауто штартет нихт"
},
{
    german: "Ich komme etwas später.",
    russian: "Я немного опоздаю.",
    pronunciation: "Ихь комме этвас шпетер"
},
{
    german: "Danke für Ihre Hilfe.",
    russian: "Спасибо за помощь.",
    pronunciation: "Данке фюр ире хильфе"
},
{
    german: "Bis morgen auf der Arbeit.",
    russian: "До завтра на работе.",
    pronunciation: "Бис морген ауф дер арбайт"
},
{
    german: "Schönen Feierabend.",
    russian: "Хорошего вечера после работы.",
    pronunciation: "Шёнен файерабенд"
},
{
    german: "Bis nächste Woche.",
    russian: "До следующей недели.",
    pronunciation: "Бис нексте вохе"
}
];