# Features

- Professional navy, blue and gold police visual system
- Collapsible topic navigation with separate pages
- Case-insensitive full-content search using `Ctrl+K`
- Structured tables, legal quotations, decision trees, procedure steps and roleplay action text
- Directory of all 45 UK territorial forces and three national special police forces
- A4 printable frontline reference
- Responsive desktop and mobile navigation
- Print styles for individual guidance pages