# Implemented features (Phase 1-9)
- [x] Political map, 7 nations, 61 land provinces, borders, capitals
- [x] Country + province selection, info panels
- [x] Zoom / pan / pinch, responsive portrait + landscape
- [x] Top bar (date, treasury, manpower, 4 resources), time controls (pause + 5 speeds)
- [x] Save / load foundation (autosave + 3 slots)
- [x] Starting scenario: 1 Jan 1936, choose any of 7 nations
- [x] Phase 2: 6 unit types, recruitment queue, equipment, armies, movement, generals, map icons, Army Command UI
- [x] Phase 3: war declarations, battles, casualties, retreat, occupation, capital capture, forts, reinforcements, dynamic borders, basic enemy responses
- [x] Phase 4: factories, production lines, resources incl. rubber, budget and tax policy, construction queue, trade, shortages, equipment tied to recruitment
- [x] Phase 5: relations, non-aggression pacts, alliances (call to arms), military access, trade agreements, guarantees, offers inbox, peace talks with terms, AI diplomacy
- [x] Phase 6: agency and agents, spy networks, 9 covert operations (incl. province agitation and revolutions that annex provinces without war), counter-intelligence, fog of war, masked foreign stats, AI espionage
- [x] Phase 7: research (30 technologies in 8 branches, slots, allied speed-up), 4 army doctrines with levels, tech effects on combat/economy/movement/spies, fortification gating, steal-technology operation, AI research
- [x] Food: Farm Estates (3 levels), Agricultural Methods / Mechanized Farming techs, food deficit warning
- [x] Phase 8: AI personalities, war decisions, staged offensives, standing armies, AI economy/taxes/forts, strategic diplomacy, coalitions, difficulty levels
- [x] Phase 9: second scenario (Old World 1936 on real Natural Earth coastlines, 44 nations), sea zones, ports, straits, 5 ship types, fleets, shipbuilding, naval combat, blockades, amphibious landings, naval tech, naval AI, 5 map modes, Navy UI
## Not yet (later phases)
 Phase 10: campaigns/events, balance pass, final release.
Province ownership is already stored in a mutable array (state.owners) ready for conquest in Phase 3.
