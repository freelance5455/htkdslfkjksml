#!/usr/bin/env bash
set -euo pipefail

if [[ $EUID -eq 0 ]]; then SUDO=""; else SUDO="sudo"; fi
command -v docker >/dev/null 2>&1 || { echo "Docker is required. Install Docker first."; exit 1; }

mkdir -p data
if [[ ! -f .env ]]; then cp .env.example .env; fi

read -r -p "Domain (example: chat.example.com): " DOMAIN
if [[ -z "$DOMAIN" ]]; then echo "Domain is required for HTTPS setup."; exit 1; fi
cat > Caddyfile <<CFG
$DOMAIN {
    reverse_proxy alichat:3000
}
CFG

# Behind Caddy, the app should trust X-Forwarded-Proto and issue Secure cookies.
sed -i 's/^TRUST_PROXY=.*/TRUST_PROXY=true/' .env
sed -i 's/^COOKIE_SECURE=.*/COOKIE_SECURE=auto/' .env

docker compose -f docker-compose.production.yml up -d --build

echo
 echo "AliChat is starting. HTTPS: https://$DOMAIN"
echo "Check: docker compose -f docker-compose.production.yml ps"
echo "Logs:  docker compose -f docker-compose.production.yml logs -f alichat"
