package com.infocast24.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.content.*;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(new NewsView(this));
    }

    static class News {
        String cat, title, time, body;
        News(String c, String t, String tm, String b){cat=c;title=t;time=tm;body=b;}
    }

    static class NewsView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Bitmap logo, cover;
        int page=0;
        int W,H;
        final int NAV=92;
        final int BLUE=Color.rgb(5,24,52), CARD=Color.rgb(10,39,70), RED=Color.rgb(245,32,48);
        final int WHITE=Color.WHITE, MUTED=Color.rgb(180,196,215);
        String[] cats={"বাংলাদেশ","চট্টগ্রাম","রাজনীতি","আন্তর্জাতিক","অর্থনীতি","খেলাধুলা","বিনোদন","প্রযুক্তি"};
        ArrayList<News> news=new ArrayList<>();

        NewsView(Context c){
            super(c);
            logo=BitmapFactory.decodeResource(getResources(),R.drawable.infocast24_logo);
            cover=BitmapFactory.decodeResource(getResources(),R.drawable.infocast24_cover);
            seed();
        }
        void seed(){
            news.add(new News("বাংলাদেশ","জাতীয় সংসদে আগামী বাজেট নিয়ে আলোচনা শুরু আজ","২ ঘণ্টা আগে",
                "আগামী অর্থবছরের বাজেট নিয়ে জাতীয় সংসদে আলোচনা শুরু হয়েছে। সংশ্লিষ্টরা বিভিন্ন বিষয় নিয়ে মতামত দিচ্ছেন।"));
            news.add(new News("চট্টগ্রাম","চট্টগ্রামে ফের বৃষ্টির সম্ভাবনা, সতর্কতা জারি","৩ ঘণ্টা আগে",
                "আবহাওয়ার পরিবর্তনের কারণে চট্টগ্রামসহ বিভিন্ন এলাকায় বৃষ্টির সম্ভাবনা রয়েছে।"));
            news.add(new News("খেলাধুলা","বাংলাদেশের নতুন কোচ হিসেবে আসছেন কে?","৪ ঘণ্টা আগে",
                "দলের পরবর্তী পরিকল্পনা নিয়ে আলোচনা চলছে। বিস্তারিত তথ্য পাওয়া গেলে আপডেট করা হবে।"));
            news.add(new News("আন্তর্জাতিক","গুরুত্বপূর্ণ আন্তর্জাতিক বৈঠক শুরু","৬ ঘণ্টা আগে",
                "আন্তর্জাতিক অঙ্গনে গুরুত্বপূর্ণ বৈঠক নিয়ে আলোচনা চলছে।"));
            news.add(new News("চট্টগ্রাম","পটিয়ায় স্থানীয় বিভিন্ন উদ্যোগ নিয়ে আলোচনা","৮ ঘণ্টা আগে",
                "স্থানীয় উন্নয়ন ও নাগরিক বিষয় নিয়ে মানুষের মধ্যে আলোচনা চলছে।"));
        }

        void bg(Canvas c){c.drawColor(BLUE);}
        void text(Canvas c,String s,float x,float y,float size,int color,boolean bold){
            p.setColor(color);p.setTextSize(size);p.setTypeface(Typeface.create("sans",bold?1:0));c.drawText(s,x,y,p);
        }
        void rect(Canvas c,float l,float t,float r,float b,float rad,int color){
            p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRoundRect(l,t,r,b,rad,rad,p);
        }
        void header(Canvas c,String title){
            rect(c,0,0,W,84,0,Color.rgb(3,16,35));
            if(logo!=null)c.drawBitmap(logo,null,new RectF(14,10,72,68),p);
            text(c,title,84,49,23,WHITE,true);
        }
        @Override protected void onDraw(Canvas c){
            W=getWidth();H=getHeight();bg(c);
            if(page==0)home(c);
            else if(page==1)categories(c);
            else if(page==2)search(c);
            else if(page==3)notifications(c);
            else if(page==4)profile(c);
            else article(c,page-5);
            if(page<5)nav(c);
        }
        void home(Canvas c){
            header(c,"ইনফোকাস্ট 24");
            text(c,"সত্যের সন্ধানে, সবসময়",84,70,11,MUTED,false);
            rect(c,14,98,W-14,136,18,RED);
            text(c,"⚡ ব্রেকিং নিউজ",28,123,14,WHITE,true);
            text(c,"নতুন গুরুত্বপূর্ণ আপডেট",164,123,13,WHITE,false);
            rect(c,14,151,W-14,382,18,CARD);
            if(cover!=null)c.drawBitmap(cover,null,new RectF(14,151,W-14,274),p);
            text(c,news.get(0).title,28,313,18,WHITE,true);
            text(c,news.get(0).time+"   •   InfoCast24",28,342,11,MUTED,false);
            float y=405;
            for(int i=1;i<news.size();i++){
                rect(c,14,y,W-14,y+76,14,CARD);
                rect(c,25,y+11,104,y+65,10,Color.rgb(19,65,100));
                text(c,"NEWS",38,y+43,13,WHITE,true);
                text(c,news.get(i).title,118,y+30,13,WHITE,true);
                text(c,news.get(i).time,118,y+53,11,MUTED,false);
                y+=88;
            }
        }
        void categories(Canvas c){
            header(c,"ক্যাটাগরি");
            float top=103,g=12,bw=(W-36-g)/2,bh=100;
            for(int i=0;i<cats.length;i++){
                int col=i%2,row=i/2;
                float x=14+col*(bw+g),y=top+row*(bh+g);
                int[] cs={0xff006b67,0xff164c9a,0xff8c1f32,0xff174e78,0xff236e48,0xff254f9c,0xff63308c,0xff5b651d};
                rect(c,x,y,x+bw,y+bh,17,cs[i]);
                text(c,cats[i],x+20,y+57,18,WHITE,true);
            }
        }
        void search(Canvas c){
            header(c,"সার্চ");
            rect(c,14,101,W-14,155,22,Color.rgb(15,44,74));
            text(c,"⌕  খবর, বিষয় বা কীওয়ার্ড লিখুন...",28,136,14,MUTED,false);
            text(c,"জনপ্রিয় অনুসন্ধান",18,190,17,WHITE,true);
            float x=18,y=210;
            for(String s:cats){
                float tw=86;
                if(x+tw>W-18){x=18;y+=46;}
                rect(c,x,y,x+tw,y+34,17,Color.rgb(17,60,96));
                text(c,s,x+10,y+23,12,WHITE,false);x+=tw+7;
            }
            text(c,"সর্বশেষ খবর",18,y+68,17,WHITE,true);
            float yy=y+84;
            for(News n:news){
                rect(c,14,yy,W-14,yy+66,13,CARD);
                text(c,n.title,28,yy+29,13,WHITE,true);
                text(c,n.cat+" • "+n.time,28,yy+50,11,MUTED,false);
                yy+=78;
            }
        }
        void notifications(Canvas c){
            header(c,"নোটিফিকেশন");
            float y=103;
            for(int i=0;i<news.size();i++){
                rect(c,14,y,W-14,y+82,15,CARD);
                rect(c,27,y+18,67,y+62,22,RED);
                text(c,"!",43,y+49,20,WHITE,true);
                text(c,news.get(i).cat,83,y+31,15,WHITE,true);
                text(c,news.get(i).title,83,y+55,11,MUTED,false);
                y+=96;
            }
        }
        void profile(Canvas c){
            header(c,"প্রোফাইল");
            if(logo!=null)c.drawBitmap(logo,null,new RectF(W/2-58,105,W/2+58,221),p);
            text(c,"InfoCast24",W/2-51,251,21,WHITE,true);
            text(c,"সত্যের সন্ধানে, সবসময়",W/2-78,276,12,MUTED,false);
            String[] items={"আমাদের সম্পর্কে","যোগাযোগ করুন","গোপনীয়তা নীতি","ব্যবহারের শর্তাবলী","সেটিংস","অ্যাপ সম্পর্কে"};
            float y=310;
            for(String s:items){
                rect(c,14,y,W-14,y+56,13,CARD);
                text(c,s,30,y+35,14,WHITE,false);text(c,"›",W-42,y+35,21,MUTED,true);y+=68;
            }
        }
        void article(Canvas c,int idx){
            header(c,"সংবাদ বিস্তারিত");
            if(idx<0||idx>=news.size())idx=0;
            News n=news.get(idx);
            if(cover!=null)c.drawBitmap(cover,null,new RectF(14,100,W-14,240),p);
            text(c,n.cat,18,273,12,RED,true);
            text(c,n.title,18,306,21,WHITE,true);
            text(c,n.time+"  •  InfoCast24",18,334,11,MUTED,false);
            float y=375;
            for(String line:wrap(n.body,38)){
                text(c,line,18,y,15,WHITE,false);y+=27;
            }
            rect(c,18,y+15,W-18,y+65,14,Color.rgb(15,55,90));
            text(c,"শেয়ার করুন",34,y+47,14,WHITE,true);
        }
        ArrayList<String> wrap(String s,int max){
            ArrayList<String> a=new ArrayList<>();String cur="";
            for(String w:s.split(" ")){if((cur+" "+w).length()>max){a.add(cur.trim());cur=w;}else cur+=" "+w;}
            if(!cur.trim().isEmpty())a.add(cur.trim());return a;
        }
        void nav(Canvas c){
            float y=H-NAV;rect(c,0,y,W,H,0,Color.rgb(3,15,32));
            String[] n={"হোম","ক্যাটাগরি","সার্চ","নোটিফিকেশন","প্রোফাইল"};
            float bw=W/5f;
            for(int i=0;i<5;i++){int co=i==page?RED:MUTED;text(c,n[i],i*bw+10,y+57,11,co,i==page);text(c,i==page?"●":"○",i*bw+bw/2-4,y+28,13,co,true);}
        }
        @Override public boolean onTouchEvent(MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_UP)return true;
            float x=e.getX(),y=e.getY();
            if(page<5 && y>H-NAV){page=Math.min(4,(int)(x/(W/5f)));invalidate();return true;}
            if(page==0 && y>145 && y<385){page=5;invalidate();return true;}
            if(page>=5){page=0;invalidate();return true;}
            return true;
        }
    }
}
