package com.infocast24.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class WebFallbackActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        w.loadUrl("file:///android_asset/web/index.html");
        setContentView(w);
    }
}
