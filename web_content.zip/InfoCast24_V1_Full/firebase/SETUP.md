# Firebase setup checklist

এই প্যাকেজে Firebase integration-এর জায়গা প্রস্তুত রাখা হয়েছে, কিন্তু আপনার Firebase account/project তৈরি করা হয়নি—তাই কোনো ব্যক্তিগত API key/credential ZIP-এ রাখা হয়নি।

## 1. Firebase project
Firebase Console-এ নতুন project তৈরি করুন: `InfoCast24`

## 2. Android app
Package/Application ID: `com.infocast24.app`

Firebase থেকে Android configuration (`google-services.json`) নিন এবং Android project-এ রাখুন:
`android/app/google-services.json`

## 3. Recommended services
- Firestore Database — news, categories, users
- Storage — news images/videos
- Cloud Messaging (FCM) — breaking-news notifications
- Authentication — admin login
- App Check — abuse protection

## 4. Suggested Firestore collections
`news`, `categories`, `users`, `notifications`

## 5. Security
Admin-only write permissions দিন। Public users-এর জন্য read-only access রাখুন।
কখনো API keys/password/service-account JSON এই ZIP বা public Git repository-তে commit করবেন না.
