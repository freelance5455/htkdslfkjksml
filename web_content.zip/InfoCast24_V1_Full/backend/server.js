const express=require('express');
const cors=require('cors');
const app=express();
app.use(cors()); app.use(express.json());

let news=[
 {id:1,category:"বাংলাদেশ",title:"জাতীয় সংসদে আগামী বাজেট নিয়ে আলোচনা শুরু আজ",time:"২ ঘণ্টা আগে",body:"ডেমো খবর—Firebase বা অন্য ডাটাবেস সংযুক্ত হলে এখানে লাইভ কনটেন্ট আসবে।"},
 {id:2,category:"চট্টগ্রাম",title:"চট্টগ্রামে ফের বৃষ্টির সম্ভাবনা, সতর্কতা জারি",time:"৩ ঘণ্টা আগে",body:"ডেমো খবর।"}
];

app.get('/api/news',(req,res)=>res.json(news));
app.get('/api/news/:id',(req,res)=>{
 const item=news.find(x=>x.id==req.params.id);
 if(!item) return res.status(404).json({error:"Not found"});
 res.json(item);
});
app.post('/api/news',(req,res)=>{
 const item={id:Date.now(),time:"এখন",...req.body};
 news.unshift(item); res.status(201).json(item);
});
app.put('/api/news/:id',(req,res)=>{
 const i=news.findIndex(x=>x.id==req.params.id);
 if(i<0) return res.status(404).json({error:"Not found"});
 news[i]={...news[i],...req.body,id:news[i].id};
 res.json(news[i]);
});
app.delete('/api/news/:id',(req,res)=>{
 news=news.filter(x=>x.id!=req.params.id); res.json({ok:true});
});
app.listen(process.env.PORT||3000,()=>console.log('InfoCast24 API running'));
