# InfoCast24 V1 — Full starter package

আপনার দেওয়া InfoCast24 logo ও cover দিয়ে Android app starter + Admin UI + REST backend template।

## Included
### Android
- Branded Home
- Breaking news strip
- Categories
- Search UI
- Notifications UI
- Profile
- Article details
- Offline demo news
- Internet permission for future API/Firebase use

### Admin
- Dashboard
- New news publishing form
- Category management UI placeholders
- Push notification UI placeholder

### Backend
- Node/Express demo API
- GET /api/news
- GET /api/news/:id
- POST /api/news
- DELETE /api/news/:id

### Firebase
- Setup guide
- Firestore/Storage/FCM/Auth architecture notes

## APK
Android Studio-তে `android` folder open করুন।
Gradle sync হওয়ার পরে Build > Build APK(s)।

## What is not yet live
লাইভ Firebase project, admin credentials, real news provider/API, FCM credentials এবং hosting account এই প্যাকেজে নেই। এগুলো নির্দিষ্ট account/credential ছাড়া নিরাপদভাবে তৈরি করা যায় না। SETUP.md অনুসরণ করে এগুলো যুক্ত করতে হবে।

## Branding
Logo: supplied InfoCast24 logo
Cover: supplied InfoCast24 cover
Slogan: সত্যের সন্ধানে, সবসময়


## Admin Edit
Admin panel V2-তে এখন:
- নতুন খবর Publish
- প্রকাশিত খবরের তালিকা
- ✏️ Edit
- 🗑 Delete
- Breaking News UI

Browser-এ `admin/index.html` খুললে demo CRUD দেখা যাবে। Production-এ Firebase/REST API যুক্ত করলে Edit/Delete বাস্তব ডাটাবেসে হবে।


## V3 WebView error fix
যদি কোনো builder `https://appassets.androidplatform.net/web/index.html` লোড করতে চায়, V3-তে সেই exact local asset:
`android/app/src/main/assets/web/index.html`
যোগ করা হয়েছে। Branding images-ও assets-এ রাখা হয়েছে। ফলে `web/index.html` missing থাকার কারণে হওয়া error আর হবে না।

Main app-এর native UI আগের মতোই আছে।
