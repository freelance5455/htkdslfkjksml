# Rumy's Care — Pregnancy Education & Deals App

A responsive English-language app prototype with a warm, accessible teal/mint/peach palette and an original vector logo. It is built as a web app and can be packaged as an Android APK using Capacitor.

## Features
- Home dashboard and Rumy's Care logo
- Pregnancy education topics and general safety guidance
- Demo deals/offer cards (replace with verified real offers before publishing)
- Personal checklist with custom reminders and local-device storage
- Mobile-responsive layout
- Android packaging setup through Capacitor

## Requirements
- Node.js LTS (includes npm)
- Android Studio with Android SDK for Android APK builds
- Internet connection for first-time dependency installation

## Run the app on your computer
1. Extract this ZIP.
2. Open a terminal in the extracted `rumys-care` folder.
3. Run:
   ```bash
   npm install
   npm run dev
   ```
   If `npm run dev` is unavailable, use `npm start` (the package start script uses Vite).
4. Open the local URL shown in the terminal.

## Build the Android APK
Run these commands from the project folder:

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

Android Studio opens the Android project. Wait for Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The debug APK is typically created under:

`android/app/build/outputs/apk/debug/app-debug.apk`

To create a signed release APK for distribution, use **Build > Generate Signed Bundle / APK** in Android Studio and follow the signing wizard. Keep your signing key private and backed up.

If you edit the website after creating the Android folder, run:

```bash
npm run build
npx cap sync android
```

Then rebuild in Android Studio.

## Notes before publishing
- This ZIP contains source code, not a prebuilt APK. Android Studio/Gradle must build the APK on a computer.
- The deal cards are demonstration content, not live or verified discounts. Add real partner details, terms, expiry dates and contact links before launch.
- Educational content is general information and is not a replacement for antenatal care. Have qualified local maternity professionals review the medical content before public release.
- Add a privacy policy and clear consent before collecting personal or pregnancy data. This prototype keeps checklist items in browser/app local storage only.
- For production, test on several Android screen sizes and add a clear way to report incorrect offers/content.
