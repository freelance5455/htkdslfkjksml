const lessons = [
 {id:1, category:"wellness", icon:"☼", color:"mint", title:"Everyday pregnancy wellness", time:"4 MIN READ", intro:"Small, steady habits can support your wellbeing.", body:"Aim for a varied diet, fluids throughout the day, and rest when you can. Ask your maternity provider what activity is suitable for you, especially if you have symptoms or a higher-risk pregnancy. Do not start or stop medicines or supplements without professional advice."},
 {id:2, category:"wellness", icon:"♡", color:"peach", title:"Food, hydration and supplements", time:"5 MIN READ", intro:"Learn what to discuss about nutrition and vitamins.", body:"Food safety and nutrition needs can change during pregnancy. Ask your healthcare provider about folic acid, iron and any other supplements appropriate for you. Avoid alcohol, and ask a qualified provider about foods or medicines you are unsure about. Local guidance may differ."},
 {id:3, category:"appointments", icon:"＋", color:"blue", title:"Making the most of antenatal visits", time:"3 MIN READ", intro:"A few notes can make appointments more useful.", body:"Keep your appointment dates and bring questions, a list of medicines and any test results you have. Ask which warning signs should prompt urgent care, what tests are recommended, and how to contact your maternity team between visits."},
 {id:4, category:"appointments", icon:"☏", color:"lilac", title:"Know when to seek urgent help", time:"3 MIN READ", intro:"Some symptoms need prompt medical attention.", body:"Seek urgent medical advice for heavy bleeding, severe or persistent abdominal pain, severe headache or vision changes, trouble breathing, fainting, fever, fluid leaking, or reduced baby movement once you normally feel movement. This is not a complete list. If you feel something is seriously wrong, contact your local maternity unit or emergency service immediately."},
 {id:5, category:"preparation", icon:"✧", color:"yellow", title:"Preparing for birth", time:"4 MIN READ", intro:"A simple plan can help you feel more prepared.", body:"Talk with your maternity team about where to go when labour starts, transport, who can support you, pain-relief options, and what to pack. Plans can change, so follow professional advice and the guidance of your local health service."},
 {id:6, category:"preparation", icon:"♧", color:"pink", title:"Getting ready for your newborn", time:"4 MIN READ", intro:"Focus on safe basics rather than buying everything.", body:"Prepare a safe sleep space, clean clothes, nappies and a way to get to healthcare. Ask your provider about feeding support, newborn check-ups, vaccinations and signs your baby needs urgent care. You do not need every advertised product to care for your baby."}
];
const defaultTasks = [
 "Book or confirm my next antenatal visit",
 "Write down questions for my healthcare provider",
 "Ask about recommended supplements and tests",
 "Prepare important clinic contacts",
 "Plan transport for birth",
 "Gather essential items for baby"
];
const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
function showPage(name) {
 $$(".page").forEach(p => p.classList.toggle("active", p.id === `page-${name}`));
 $$(".nav-item").forEach(b => b.classList.toggle("active", b.dataset.page === name));
 window.scrollTo({top:0,behavior:"smooth"});
}
$$("[data-page]").forEach(b => b.addEventListener("click", () => showPage(b.dataset.page)));
function renderLessons(filter="all") {
 const filtered = lessons.filter(l => filter==="all" || l.category===filter);
 $("#lesson-grid").innerHTML = filtered.map(l => `<article class="lesson-card"><div class="lesson-icon ${l.color}">${l.icon}</div><span class="card-kicker">${l.time}</span><h3>${l.title}</h3><p>${l.intro}</p><button class="text-btn" data-lesson="${l.id}">Read topic <b>→</b></button></article>`).join("");
 $$("[data-lesson]").forEach(b => b.addEventListener("click", () => {
  const l=lessons.find(x=>x.id===Number(b.dataset.lesson));
  openModal(l.title, `<p>${l.body}</p><p class="modal-caution">This is general education, not personal medical advice. Please consult a qualified healthcare professional for advice about your pregnancy.</p>`);
 }));
}
$$(".filter").forEach(b=>b.addEventListener("click",()=>{$$(".filter").forEach(x=>x.classList.remove("active"));b.classList.add("active");renderLessons(b.dataset.filter)}));
function openModal(title, body) {
 $("#modal-title").textContent=title; $("#modal-body").innerHTML=body; $("#modal").classList.add("open"); $("#modal").setAttribute("aria-hidden","false");
}
function closeModal(){ $("#modal").classList.remove("open"); $("#modal").setAttribute("aria-hidden","true"); }
$("#modal-close").addEventListener("click",closeModal); $("#modal-ok").addEventListener("click",closeModal);
$("#modal").addEventListener("click",e=>{if(e.target.id==="modal")closeModal()});
$$("[data-deal]").forEach(b=>b.addEventListener("click",()=>openModal(b.dataset.deal,`<p>This is a sample section for the ${b.dataset.deal.toLowerCase()} category.</p><p>Before publishing, add a verified partner, real offer details, current price, expiry date, terms and a safe contact or destination link. Do not present demo offers as active discounts.</p>`)));

let tasks;
try { tasks=JSON.parse(localStorage.getItem("rumys-care-tasks")||"null"); } catch { tasks=null; }
if(!Array.isArray(tasks)) tasks=defaultTasks.map((label,i)=>({id:i+1,label,done:false}));
function saveTasks(){try{localStorage.setItem("rumys-care-tasks",JSON.stringify(tasks));}catch{}}
function renderTasks(){
 $("#checklist").innerHTML=tasks.map(t=>`<label class="task ${t.done?"done":""}"><input type="checkbox" data-task="${t.id}" ${t.done?"checked":""}/><span class="custom-check">✓</span><span class="task-label">${escapeHtml(t.label)}</span><button type="button" class="delete-task" data-delete="${t.id}" aria-label="Delete ${escapeHtml(t.label)}">×</button></label>`).join("");
 const done=tasks.filter(t=>t.done).length; $("#progress-count").textContent=`${done} / ${tasks.length}`; $("#progress-fill").style.width=`${tasks.length?done/tasks.length*100:0}%`;
 $$("[data-task]").forEach(c=>c.addEventListener("change",()=>{const t=tasks.find(x=>x.id===Number(c.dataset.task));if(t)t.done=c.checked;saveTasks();renderTasks()}));
 $$("[data-delete]").forEach(b=>b.addEventListener("click",()=>{tasks=tasks.filter(t=>t.id!==Number(b.dataset.delete));saveTasks();renderTasks()}));
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
$("#task-form").addEventListener("submit",e=>{e.preventDefault();const input=$("#task-input");const label=input.value.trim();if(!label)return;tasks.push({id:Date.now(),label,done:false});saveTasks();renderTasks();input.value=""});
renderLessons();renderTasks();