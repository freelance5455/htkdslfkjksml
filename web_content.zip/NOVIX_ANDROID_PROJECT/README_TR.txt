NOVIX TECHNOLOGIES - ANDROID PROJESI (APK DERLEMEYE HAZIR)

Bu ZIP, NOVIX HTML arayuzunu Android WebView uygulamasi icinde calistiran kaynak projedir.
Uygulama adi: NOVIX TECHNOLOGIES
Paket adi: com.novix.technologies
Surum: 1.1 (versionCode 2)
Minimum Android: 6.0 (API 23)
Hedef SDK: 35

EKLENENLER:
- NOVIX uygulama baslatma simgesi (launcher icon)
- NOVIX koyu tema acilis arka plani (splash/window background)
- Uygulama etiketi ve ikon tanimlari
- Surum 1.1 / versionCode 2
- Mevcut HTML, JavaScript ve localStorage yapisi korunmustur.

APK OLUSTURMA:
1. ZIP'i AndroidIDE ile ac veya cikartip projeyi AndroidIDE'ye aktar.
2. Internet acikken Gradle senkronizasyonunu bekle.
3. AndroidIDE'de :app:assembleDebug gorevini calistir.
4. APK normalde app/build/outputs/apk/debug/app-debug.apk konumunda olusur.
5. APK'yi telefona yukleyebilirsin.

NOT:
Bu paket kaynak projedir, derlenmis APK dosyasi degildir.
APK olusturmak icin Android SDK ve Gradle ile derleme gerekir.
Play Store icin ayrica imzali release APK/AAB ve magaza gereksinimleri gerekir.

BULUTTAN APK DERLEME (BILGISAYAR / ANDROIDIDE GEREKMEZ):
1. GitHub.com'a tarayicidan giris yap veya hesap olustur.
2. New repository ile yeni bir depo olustur. Private secenegini kullanabilirsin.
3. Bu ZIP'i cikart; NOVIX_ANDROID_PROJECT klasorunun ICINDEKILERINI depoya yukle.
   .github klasoru dahil tum dosyalar yuklenmeli.
4. Depoda Actions sekmesine gir. "Build NOVIX APK" is akisini secip Run workflow'a bas.
5. Islem tamamlaninca calismanin sayfasinda Artifacts bolumunden
   NOVIX-TECHNOLOGIES-APK dosyasini indir.
6. ZIP'i telefonda cikart ve icindeki app-debug.apk dosyasini kur.

Not: GitHub hesabiyla giris gerekir. Bu workflow, APK'yi GitHub'in bulut sunucusunda derler.
