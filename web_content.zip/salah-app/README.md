# Salah Glass (Capacitor Android project)

1. Install Node.js (LTS) and Android Studio.
2. In this folder:  npm install
3.                  npm run add-android
4.                  npm run open      (opens Android Studio)
5. In Android Studio: Build > Generate App Bundles or APKs > Generate APKs

After any change in www/index.html:  npm run sync

Azan sound: replace resources/azan.wav with your own WAV (keep the same name),
run `npm run sync`, uninstall the old app from the phone, install again.
(Android keeps a notification channel's sound until the app is uninstalled.)
