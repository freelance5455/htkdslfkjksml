// Run after "npx cap add android". Safe to run again.
const fs = require('fs'), path = require('path');
const root = __dirname, android = path.join(root, 'android');
if (!fs.existsSync(android)) { console.error('android folder not found. Run: npx cap add android'); process.exit(1); }

// 1. azan sound -> res/raw
const raw = path.join(android, 'app/src/main/res/raw');
fs.mkdirSync(raw, { recursive: true });
fs.copyFileSync(path.join(root, 'resources/azan.wav'), path.join(raw, 'azan.wav'));
console.log('Copied azan.wav');

// 2. permissions
const mf = path.join(android, 'app/src/main/AndroidManifest.xml');
let x = fs.readFileSync(mf, 'utf8');
const perms = [
  'android.permission.POST_NOTIFICATIONS',
  'android.permission.SCHEDULE_EXACT_ALARM',
  'android.permission.RECEIVE_BOOT_COMPLETED',
  'android.permission.VIBRATE',
  'android.permission.ACCESS_COARSE_LOCATION',
  'android.permission.ACCESS_FINE_LOCATION'
];
let add = '';
perms.forEach(p => { if (!x.includes(p)) add += '    <uses-permission android:name="' + p + '" />\n'; });
if (add) { x = x.replace('</manifest>', add + '</manifest>'); fs.writeFileSync(mf, x); console.log('Added permissions'); }
else console.log('Permissions already present');
