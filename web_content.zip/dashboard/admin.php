<?php
declare(strict_types=1);
// Compatibility entry point for installations that expose the dashboard alias.
// All application assets and admin actions are rooted at the site document root.
$platformBaseHref = rtrim(dirname(dirname(str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? '/')))), '/') . '/';
require dirname(__DIR__) . '/admin.php';
