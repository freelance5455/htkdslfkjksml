package fr.forcerun.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<android.net.Uri>>? = null
    private var backupToWrite: String? = null
    private val openFileCode = 101
    private val saveFileCode = 102

    inner class Bridge {
        @JavascriptInterface fun saveBackup(json: String) {
            runOnUiThread {
                backupToWrite = json
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, "force-run-sauvegarde.json")
                }
                startActivityForResult(intent, saveFileCode)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        web.addJavascriptInterface(Bridge(), "ForceRunAndroid")
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(webView: WebView?, callback: ValueCallback<Array<android.net.Uri>>?, params: FileChooserParams?): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                }
                startActivityForResult(intent, openFileCode)
                return true
            }
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when(requestCode) {
            openFileCode -> {
                fileCallback?.onReceiveValue(if(resultCode == RESULT_OK && data?.data != null) arrayOf(data.data!!) else null)
                fileCallback = null
            }
            saveFileCode -> {
                if(resultCode == RESULT_OK && data?.data != null) {
                    contentResolver.openOutputStream(data.data!!)?.use { stream ->
                        stream.write((backupToWrite ?: "{}").toByteArray(Charsets.UTF_8))
                    }
                }
                backupToWrite = null
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if(web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
