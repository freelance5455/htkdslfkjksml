# Force × Run — application Android

Application Android hors ligne reprenant le programme hybride 16 semaines : musculation (1RM estimé, charges, exercices), course (vitesses km/h, séances), suivi et sauvegardes JSON.

## Générer l'APK
1. Installer Android Studio (version récente) et son SDK Android 35.
2. Ouvrir le dossier `ForceRunAndroid` dans Android Studio.
3. Laisser Gradle synchroniser et télécharger les dépendances nécessaires (connexion Internet requise pour la première compilation).
4. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Récupérer `app/build/outputs/apk/debug/app-debug.apk` et le transférer sur le téléphone Android.
6. Installer le fichier APK après autorisation Android d'installation depuis cette source.

Les données restent stockées dans l'application sur le téléphone. **Exporter une sauvegarde** régulièrement via le bouton prévu ; désinstaller l'application peut supprimer les données. L'import JSON utilise le sélecteur de fichiers Android.

Ce projet n'a pas été compilé ni testé sur un appareil dans cet environnement (Android SDK absent). La version produite par Android Studio sera un APK de développement non destiné à une distribution publique. Pour une distribution officielle, prévoir une signature de publication et des tests de sécurité/compatibilité.
