# IT SOLUTIONS Android WebView App

## Included
- Business dashboard and service catalogue
- Service booking records and status tracking
- Customer directory
- Invoice creation with line items, billing types, tax/GST calculation and payment status
- Print-ready invoice view (use Android print/save as PDF if available)
- Local JSON backup and restore
- Android WebView wrapper with local HTML assets

## Build APK in Android Studio
1. Extract this ZIP.
2. Open Android Studio and choose **Open**, then select the `IT_SOLUTIONS_Android_Project` folder.
3. Allow Gradle sync; use JDK 17 and install Android SDK 35 if prompted.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio shows the APK location when the build completes (usually `app/build/outputs/apk/debug/app-debug.apk`).

## Important
- This is an offline-first starter application. Records are stored locally on the device; export backups regularly.
- No cloud synchronization, authentication, automated WhatsApp/SMS, payment gateway or server database is configured.
- Confirm applicable GST settings with your accountant before issuing tax invoices.
- Test invoice printing on your target Android device before production use.
