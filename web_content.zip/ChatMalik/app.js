const conversation=document.getElementById('conversation');
const welcome=document.getElementById('welcome');
const input=document.getElementById('prompt');
const form=document.getElementById('form');
const history=document.getElementById('history');
function addMessage(text,who){
  if(welcome) welcome.remove();
  const row=document.createElement('div'); row.className='message '+who;
  const bubble=document.createElement('div'); bubble.className='bubble'; bubble.textContent=text;
  row.appendChild(bubble); conversation.appendChild(row); conversation.scrollTop=conversation.scrollHeight;
}
function demoReply(text){
 const t=text.toLocaleLowerCase('az');
 if(t.includes('salam')) return 'Salam! Mən ChatMalikəm. Sənə kömək etməyə hazıram. 😊';
 if(t.includes('riyaziyyat')||t.includes('misal')) return 'Əlbəttə! Riyaziyyat tapşırığını göndər, onu addım-addım izah edim.';
 if(t.includes('hekayə')) return 'Bir gün balaca bir ulduz gecə səmasında öz işığını axtarırdı. O anladı ki, başqalarına yol göstərdikcə özü də daha parlaq görünür. ✨';
 if(t.includes('plan')) return 'Günün üçün sadə plan: 1. Əsas işlərini yaz. 2. Əvvəl vacib olanı et. 3. Fasilə ver. 4. Günün sonunda nəticəni yoxla.';
 return 'Mesajını aldım! Bu ZIP ChatMalik-in işlək görünüşlü demo versiyasıdır. Həqiqi ChatGPT səviyyəsində cavablar üçün təhlükəsiz serverdə AI modelinə qoşulmalıdır.';
}
function send(text){
 const value=text.trim(); if(!value)return;
 addMessage(value,'user'); input.value='';
 setTimeout(()=>addMessage(demoReply(value),'bot'),350);
}
form.addEventListener('submit',e=>{e.preventDefault();send(input.value)});
document.querySelectorAll('[data-prompt]').forEach(b=>b.addEventListener('click',()=>send(b.dataset.prompt)));
document.getElementById('newChat').addEventListener('click',()=>location.reload());
document.getElementById('menu').addEventListener('click',()=>document.querySelector('.sidebar').classList.toggle('open'));
input.addEventListener('input',()=>{input.style.height='auto';input.style.height=Math.min(input.scrollHeight,130)+'px'});
