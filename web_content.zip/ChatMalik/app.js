const conversation=document.getElementById('conversation');
const welcome=document.getElementById('welcome');
const input=document.getElementById('prompt');
const form=document.getElementById('form');
const history=document.getElementById('history');
const messages=[];
function addMessage(text,who){
  if(welcome) welcome.remove();
  const row=document.createElement('div'); row.className='message '+who;
  const bubble=document.createElement('div'); bubble.className='bubble'; bubble.textContent=text;
  row.appendChild(bubble); conversation.appendChild(row); conversation.scrollTop=conversation.scrollHeight;
}
async function send(text){
 const value=text.trim(); if(!value)return;
 addMessage(value,'user'); messages.push({role:'user',content:value}); input.value=''; input.style.height='auto';
 const pending=document.createElement('div'); pending.className='message bot'; pending.innerHTML='<div class="bubble">Cavab hazırlanır...</div>'; conversation.appendChild(pending); conversation.scrollTop=conversation.scrollHeight;
 try{
   const response=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({messages})});
   const data=await response.json();
   if(!response.ok) throw new Error(data.error||'Server xətası');
   const answer=data.reply||'Cavab alınmadı.'; messages.push({role:'assistant',content:answer});
   pending.querySelector('.bubble').textContent=answer;
 }catch(err){
   pending.querySelector('.bubble').textContent='Serverə qoşulmaq mümkün olmadı. Serverin işlədiyini və API sazlamalarını yoxla. ('+err.message+')';
 }
}
form.addEventListener('submit',e=>{e.preventDefault();send(input.value)});
document.querySelectorAll('[data-prompt]').forEach(b=>b.addEventListener('click',()=>send(b.dataset.prompt)));
document.getElementById('newChat').addEventListener('click',()=>{messages.length=0;location.reload()});
document.getElementById('menu').addEventListener('click',()=>document.querySelector('.sidebar').classList.toggle('open'));
input.addEventListener('input',()=>{input.style.height='auto';input.style.height=Math.min(input.scrollHeight,130)+'px'});
