const express = require('express');
const path = require('path');
require('dotenv').config();
const app = express();
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, '..')));

app.post('/api/chat', async (req, res) => {
  try {
    const { messages } = req.body || {};
    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'Mesaj tapılmadı.' });
    }
    if (!process.env.AI_API_KEY || !process.env.AI_BASE_URL || !process.env.AI_MODEL) {
      return res.status(503).json({ error: 'Serverdə AI_API_KEY, AI_BASE_URL və AI_MODEL sazlanmalıdır.' });
    }
    const safeMessages = messages.slice(-20).filter(m =>
      m && ['user', 'assistant'].includes(m.role) && typeof m.content === 'string'
    );
    const upstream = await fetch(process.env.AI_BASE_URL.replace(/\/$/, '') + '/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.AI_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: process.env.AI_MODEL,
        messages: [
          { role: 'system', content: 'Sənin adın ChatMalikdir. Azərbaycan dilində aydın, mehriban və faydalı cavab ver.' },
          ...safeMessages
        ]
      })
    });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      console.error('AI provider error:', upstream.status, data);
      return res.status(502).json({ error: 'AI xidmətindən cavab alınmadı. Server sazlamalarını yoxla.' });
    }
    const reply = data.choices?.[0]?.message?.content;
    if (!reply) return res.status(502).json({ error: 'AI boş cavab qaytardı.' });
    res.json({ reply });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Daxili server xətası.' });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`ChatMalik server ${port} portunda işləyir.`));
