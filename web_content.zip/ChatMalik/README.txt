CHATMALIK — Android və kompüter üçün veb tətbiq demo

İşə salmaq:
1. ZIP-i telefonda çıxart (Extract).
2. ChatMalik qovluğunda index.html faylını Chrome ilə aç.
3. Mesaj yaz və göndər.

Nə var:
- ChatGPT-dən ilhamlanan, lakin öz dizaynı olan söhbət interfeysi
- Yeni söhbət düyməsi
- Hazır nümunə sual düymələri
- Mobil ekrana uyğun görünüş
- Azərbaycan dilində demo cavablar

Vacib:
Bu, hələ real AI modeli deyil. Cavablar JavaScript-dəki nümunə məntiqdən gəlir.
Həqiqi AI üçün server tərəfdə API bağlantısı qurulmalıdır. API açarını heç vaxt
index.html və ya app.js daxilində paylaşma. Bu layihə APK deyil; veb tətbiqdir.
