CHATMALIK — AI SERVER-Ə QOŞULMAĞA HAZIR VERSİYA

Bu ZIP veb tətbiq və Node.js server kodunu ehtiva edir. Hələ canlı serverdə yerləşdirilməyib və API açarı daxil edilməyib.

YERLİ İŞƏ SALMA
1. Node.js 18 və ya daha yenisini quraşdır.
2. Bu qovluqda terminal aç və: npm install
3. .env.example faylının surətini .env adlandır.
4. .env daxilində AI_API_KEY, AI_BASE_URL və AI_MODEL dəyərlərini öz AI provayderinin verdiyi məlumatlarla doldur.
5. npm start
6. Brauzerdə http://localhost:3000 aç.

HOSTİNQƏ YERLƏŞDİRMƏ
- Bütün ChatMalik qovluğunu Node.js dəstəkləyən hostinqə yüklə.
- Build/install əmri: npm install
- Start əmri: npm start
- Hostinqin Environment Variables / Secrets bölməsində AI_API_KEY, AI_BASE_URL və AI_MODEL əlavə et.
- API açarını heç vaxt app.js, index.html, ZIP-in açıq faylları və ya GitHub-a yazma.

AI_BASE_URL /chat/completions endpoint-i olan OpenAI-compatible provayder ünvanı olmalıdır.
AI_MODEL provayderin dəstəklədiyi model adı olmalıdır.

QEYD
Bu ZIP APK deyil. APKForge-un ZIP importu bu Node.js serverini özü host etməyə bilər. Əvvəl server ayrıca hostinqdə yayımlanmalı, sonra tətbiq həmin server ünvanına uyğunlaşdırılmalıdır. API açarı və canlı server ünvanı verilmədiyi üçün bu paket hələ canlı AI-yə qoşulmayıb.
