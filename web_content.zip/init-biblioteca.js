buildPlaceholderView('biblioteca', 'Biblioteca Especializada', 'Referências bibliográficas e materiais de apoio ao estudo. Conteúdo em desenvolvimento.', null, 'Biblioteca.png');

setTimeout(()=>{
  const bibView = document.getElementById('view-biblioteca');
  if(bibView){
    const placeholder = bibView.querySelector('.placeholder');
    if(placeholder){
      placeholder.innerHTML = `
        <img src="Biblioteca.png" style="width:100%;max-width:200px;border-radius:12px;margin-bottom:16px;" alt="Biblioteca">
        <h3>Biblioteca Especializada</h3>
        <p style="margin-bottom:20px;">Referências bibliográficas e materiais de apoio ao estudo.</p>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;text-align:left;">
          <div style="background:#faf3df;padding:14px;border-radius:12px;border-left:4px solid #9c7d20;">
            <b style="color:#9c7d20;display:block;margin-bottom:6px;font-size:12px;">📚 Fundamentos</b>
            <span style="font-size:11px;color:#9c7d20;line-height:1.5;">Princípios de Enfermagem · Anatomia · Fisiologia · Farmacologia</span>
          </div>
          <div style="background:#e5eefc;padding:14px;border-radius:12px;border-left:4px solid #00205B;">
            <b style="color:#00205B;display:block;margin-bottom:6px;font-size:12px;">🏥 Clínica</b>
            <span style="font-size:11px;color:#00205B;line-height:1.5;">Procedimentos · Protocolos · Estudos de Caso · Evidência</span>
          </div>
          <div style="background:#fbe4e8;padding:14px;border-radius:12px;border-left:4px solid var(--vermelho);">
            <b style="color:var(--vermelho);display:block;margin-bottom:6px;font-size:12px;">🔬 Pesquisa</b>
            <span style="font-size:11px;color:var(--vermelho);line-height:1.5;">Artigos Científicos · Dissertações · Teses · Publicações</span>
          </div>
          <div style="background:#faf3df;padding:14px;border-radius:12px;border-left:4px solid #9c7d20;">
            <b style="color:#9c7d20;display:block;margin-bottom:6px;font-size:12px;">💼 Profissional</b>
            <span style="font-size:11px;color:#9c7d20;line-height:1.5;">Regulamentações · Competências · Desenvolvimento · Carreira</span>
          </div>
        </div>
      `;
    }
  }
}, 100);
