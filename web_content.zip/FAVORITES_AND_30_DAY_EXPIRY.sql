-- GH MARKETPLACE favorites + 30-day listing expiration
-- Run in Supabase SQL Editor. Keep RLS enabled.
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS bio text;
DO $$
DECLARE listing_id_type text;
BEGIN
 SELECT format_type(a.atttypid,a.atttypmod) INTO listing_id_type
 FROM pg_attribute a WHERE a.attrelid='public.listings'::regclass AND a.attname='id' AND NOT a.attisdropped;
 IF listing_id_type IS NULL THEN RAISE EXCEPTION 'Could not find public.listings.id'; END IF;
 EXECUTE format('CREATE TABLE IF NOT EXISTS public.favorites (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE, listing_id %s NOT NULL REFERENCES public.listings(id) ON DELETE CASCADE, created_at timestamptz NOT NULL DEFAULT now(), CONSTRAINT favorites_user_listing_unique UNIQUE(user_id,listing_id))', listing_id_type);
END $$;
ALTER TABLE public.favorites ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Users can view own favorites" ON public.favorites;
CREATE POLICY "Users can view own favorites" ON public.favorites FOR SELECT TO authenticated USING ((SELECT auth.uid())=user_id);
DROP POLICY IF EXISTS "Users can add own favorites" ON public.favorites;
CREATE POLICY "Users can add own favorites" ON public.favorites FOR INSERT TO authenticated WITH CHECK ((SELECT auth.uid())=user_id);
DROP POLICY IF EXISTS "Users can remove own favorites" ON public.favorites;
CREATE POLICY "Users can remove own favorites" ON public.favorites FOR DELETE TO authenticated USING ((SELECT auth.uid())=user_id);
-- Expire listing rows at/after 30 days from created_at. Cron checks every minute.
CREATE EXTENSION IF NOT EXISTS pg_cron;
CREATE OR REPLACE FUNCTION public.gh_delete_expired_marketplace_listings()
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $fn$
DECLARE deleted_count integer;
BEGIN
 DELETE FROM public.listings WHERE created_at <= now() - interval '30 days';
 GET DIAGNOSTICS deleted_count = ROW_COUNT;
 RETURN deleted_count;
END $fn$;
DO $$ BEGIN
 IF EXISTS (SELECT 1 FROM cron.job WHERE jobname='gh-marketplace-expire-listings') THEN PERFORM cron.unschedule('gh-marketplace-expire-listings'); END IF;
END $$;
SELECT cron.schedule('gh-marketplace-expire-listings','* * * * *',$job$SELECT public.gh_delete_expired_marketplace_listings();$job$);
NOTIFY pgrst, 'reload schema';
