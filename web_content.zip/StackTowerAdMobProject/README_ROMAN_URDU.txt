STACK TOWER + ADMOB ANDROID PROJECT

Is ZIP ko Android Studio mein open karein.

IMPORTANT:
- Android Studio/Gradle internet se Android SDK aur dependencies download karega.
- Manifest mein aapka AdMob App ID add hai.
- App abhi Google ka official TEST banner ad unit use karti hai.
- Testing ke dauran TEST ad hi rehne dein. Test ads par click karna safe hai.
- Apna live Banner Ad Unit ID sirf tab lagayein jab app release ke liye tayyar ho aur testing/test-device setup sahi ho.
- Live ads ko khud click na karein; apne ads par clicks ya artificial impressions invalid traffic hain.

BUILD:
1. Android Studio > Open > extracted StackTowerAdMobProject folder.
2. Gradle Sync complete hone dein.
3. Run button se phone/emulator par test karein.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).

PACKAGE NAME:
com.earnmaxpk.stacktower

CURRENT AD CONFIG:
App ID: ca-app-pub-8069642017943154~1302691885
Test Banner ID: ca-app-pub-3940256099942544/9214589741

Aapka live Banner Ad Unit ID abhi code mein jaan-boojh kar enable nahi kiya gaya. Pehle TEST ad se integration verify karein.
