MoneyBook Pro – Myanmar Offline Edition

ပါဝင်သောအရာများ
- မြန်မာဘာသာ Offline ငွေစာရင်း WebView Android project
- နေ့စဉ်/အပတ်စဉ်/လစဉ်/နှစ်စဉ် ကာလ filter
- ဝင်ငွေ/ထွက်ငွေ၊ အမျိုးအစား၊ ပြင်/ဖျက်/ရှာ
- Cash / Bank / Mobile Wallet, MMK / USD
- Quantity / Unit / Rate / Amount
- Budget, Savings Goals, Receivable/Payable, Installment/Loan
- ဂရပ်၊ အမျိုးအစားအလိုက်သုံးစွဲမှု၊ ယခင်ကာလနှိုင်းယှဉ်
- JSON Backup/Restore, CSV, Print-to-PDF
- PIN lock (local WebView storage)

APK တည်ဆောက်ရန်
1. Android Studio တွင် ဤ Project folder ကို Open လုပ်ပါ။
2. Android SDK Platform 35 နှင့် JDK 17 ရှိကြောင်း စစ်ပါ။
3. Gradle Sync ပြီး Build > Build APK(s) ကိုရွေးပါ။
4. APK သည် app/build/outputs/apk/debug/app-debug.apk တွင် ထွက်လာမည်။

သတိပြုရန်
ဤ environment တွင် Android SDK/Gradle build toolchain မရှိသဖြင့် APK binary ကို မတည်ဆောက်နိုင်သေးပါ။ ဤဖိုင်သည် APK ထုတ်လုပ်ရန် Android Studio source project ဖြစ်သည်။
PIN သည် WebView local storage အခြေခံ basic lock ဖြစ်ပြီး encrypted vault မဟုတ်ပါ။ Browser Notification ကို Android background notification အဖြစ် မချိတ်ဆက်ရသေးပါ။ PDF သည် Print dialog မှတစ်ဆင့် သိမ်းနိုင်ပြီး CSV ကို Excel ဖြင့်ဖွင့်နိုင်သည်။ True .xlsx export မပါသေးပါ။
