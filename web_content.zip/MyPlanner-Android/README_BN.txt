My Planner — Android APK build project
=====================================

মূল MyPlanner-PWA.zip থেকে Android WebView অ্যাপের প্রজেক্ট তৈরি করা হয়েছে।

যা রাখা হয়েছে
- মূল ওয়েব অ্যাপের লেআউট, রুটিন, স্টাডি, গেম, হিসাব ও সেটিংস
- LocalStorage: অ্যাপের তথ্য ফোনে স্থানীয়ভাবে সংরক্ষণ
- নেট ছাড়াই চলবে (HTML, CSS, JS ও ছবি অ্যাপের ভেতর আছে)
- Android file picker: .json ব্যাকআপ পুনরুদ্ধার
- Android Save As: .json ব্যাকআপ এবং .ics ক্যালেন্ডার ফাইল সংরক্ষণ
- Android system notification: অ্যাপ সামনে চালু থাকা অবস্থায় ওয়েব অ্যাপের রিমাইন্ডার থেকে নোটিফিকেশন

সতর্কতা
- অ্যাপ বন্ধ থাকলে/ব্যাকগ্রাউন্ডে থাকলে অ্যালার্ম বা রিমাইন্ডার সবসময় বাজবে না।
  ২৪ ঘণ্টা নির্ভরযোগ্য রিমাইন্ডারের জন্য Native AlarmManager ভিত্তিক অতিরিক্ত কাজ দরকার।
- .ics ফাইল Save করে ক্যালেন্ডার অ্যাপে আমদানি করলে ক্যালেন্ডারের আলাদা অ্যালার্ম ব্যবহার করা যাবে।
- Chrome/PWA-তে আগের ডেটা থাকলে সেখানে JSON ব্যাকআপ নিয়ে নতুন APK-তে Restore করুন।
- এটি সোর্স প্রজেক্ট, সরাসরি ইনস্টল করার APK নয়।

Android Studio দিয়ে APK তৈরির নিয়ম
1. Android Studio (কম্পিউটার) ইনস্টল করুন।
2. এই ZIP Extract করে MyPlanner-Android ফোল্ডার Android Studio-তে Open করুন।
3. Gradle Sync শেষ করুন (প্রথমবার ইন্টারনেট লাগে)।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) চাপুন।
5. APK পাবেন: app/build/outputs/apk/debug/app-debug.apk
6. ফোনে কপি করে ইনস্টল করুন।

GitHub Actions দিয়ে (কম্পিউটারে Android Studio ছাড়াই)
1. একটি GitHub repository তৈরি করে এই প্রজেক্টের ফাইল ও ফোল্ডারগুলো তাদের আসল পাথে আপলোড করুন।
2. Repository Actions > Build My Planner APK > Run workflow নির্বাচন করুন।
3. Workflow সফল হলে Artifacts থেকে MyPlanner-APK ডাউনলোড ও Extract করুন।
4. Extract করলে app-debug.apk পাবেন; সেটি ফোনে ইনস্টল করতে পারবেন।

প্রধান ফাইল
- app/src/main/assets/index.html             : আপনার ওয়েব অ্যাপ (Android bridge যুক্ত)
- app/src/main/java/app/myplanner/offline/MainActivity.java : Android wrapper
- app/src/main/AndroidManifest.xml             : Android permissions/settings
- .github/workflows/build-apk.yml             : অনলাইন APK বিল্ড

বিল্ডের প্রয়োজন: Android SDK 35, Java 17, Gradle 8.11.1; Android Gradle Plugin 8.9.2.
এই পরিবেশে Android SDK ও Gradle নেই এবং বাইরের প্যাকেজ ডাউনলোড করা যাচ্ছে না,
তাই এখান থেকে যাচাইকৃত APK ফাইল দেওয়া যায়নি।
