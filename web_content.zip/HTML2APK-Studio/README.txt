# HTML2APK Studio
Open `index.html` in a modern browser with an internet connection (JSZip is loaded from a CDN).
It lets you inspect a website ZIP or index.html and export a Capacitor Android project ZIP with a GitHub Actions workflow that builds a debug APK.
Files are processed locally in the browser; the exported project is downloaded to your device.
