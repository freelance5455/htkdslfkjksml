Eco Galaxy Daily Companion Pro v5
--------------------------------
Core rule: ONE Companion Set = ONE Ad Day.
- 11 Sep: create one Companion, enter that day's total ad spend.
- All parcels dated 11 Sep must belong to that Companion.
- 12 Sep: create a NEW Companion; its ad spend is independent.
- No cumulative updating of previous days is required.
- Daily Companion can be edited/deleted.
- Deleting a Companion deletes its linked parcels after confirmation.
- Profit is recalculated live using that day's ad spend pool.
- Products 1L/3L/5L are preloaded with supplied pricing/cost data.
- Returns, failed delivery loss, extra expenses, reports, CSV and backup included.
