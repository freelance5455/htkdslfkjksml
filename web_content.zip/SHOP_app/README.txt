SHOP — Nur Gadgets
Version 1 prototype

Open index.html in a modern browser. Data is stored locally in the browser (localStorage).
Modules: Dashboard, Stock, Purchase, Sale, Jemi assistant.
