document.addEventListener('DOMContentLoaded', () => {
    const VERIFIED_EMAILS = [
        'ioam3r@gmail.com',
        'legaendamory@gmail.com',
        'amorylegaend@gmail.com'
    ];

    // Screens
    const loginPage = document.getElementById('login-page');
    const signupPage = document.getElementById('signup-page');
    const mainPage = document.getElementById('main-page');
    const profilePage = document.getElementById('profile-page');
    const messagesPage = document.getElementById('messages-page');
    const notificationsPage = document.getElementById('notifications-page');
    const searchPage = document.getElementById('search-page');
    const reelsPage = document.getElementById('reels-page');

    // Modals
    const editProfileModal = document.getElementById('edit-profile-modal');
    const settingsModal = document.getElementById('settings-modal');
    const createPostModal = document.getElementById('create-post-modal');
    const storyActionModal = document.getElementById('story-action-modal');

    // User State
    let currentUser = null;
    let userAvatarUrl = null;
    let userCoverUrl = null;
    let userPosts = [];
    let selectedPostImage = null;

    // Ripple effect
    document.addEventListener('click', (e) => {
        const target = e.target.closest('.ripple-btn, .nav-item, .icon-btn');
        if (target) {
            const rect = target.getBoundingClientRect();
            const ripple = document.createElement('span');
            ripple.className = 'water-ripple';
            const size = Math.max(rect.width, rect.height);
            ripple.style.width = ripple.style.height = `${size}px`;
            ripple.style.left = `${e.clientX - rect.left - size / 2}px`;
            ripple.style.top = `${e.clientY - rect.top - size / 2}px`;
            target.appendChild(ripple);
            setTimeout(() => ripple.remove(), 650);
        }
    });

    // Navigation Switcher
    function switchScreen(activeScreen) {
        [mainPage, profilePage, messagesPage, notificationsPage, searchPage, reelsPage].forEach(screen => {
            if (screen) screen.classList.remove('active');
        });
        activeScreen.classList.add('active');

        // Update active status in bottom nav
        document.querySelectorAll('.bottom-nav .nav-item').forEach(btn => btn.classList.remove('active'));
        if (activeScreen === mainPage) document.querySelectorAll('.nav-home-trigger').forEach(b => b.classList.add('active'));
        if (activeScreen === searchPage) document.querySelectorAll('.nav-search-trigger').forEach(b => b.classList.add('active'));
        if (activeScreen === reelsPage) document.querySelectorAll('.nav-reels-trigger').forEach(b => b.classList.add('active'));
        if (activeScreen === profilePage) document.querySelectorAll('.nav-profile-trigger').forEach(b => b.classList.add('active'));
    }

    // Connect Navigation Buttons
    document.querySelectorAll('.nav-home-trigger').forEach(btn => btn.addEventListener('click', () => switchScreen(mainPage)));
    document.querySelectorAll('.nav-search-trigger').forEach(btn => btn.addEventListener('click', () => switchScreen(searchPage)));
    document.querySelectorAll('.nav-reels-trigger').forEach(btn => btn.addEventListener('click', () => switchScreen(reelsPage)));
    document.querySelectorAll('.nav-profile-trigger').forEach(btn => btn.addEventListener('click', () => switchScreen(profilePage)));

    document.getElementById('notifications-btn').addEventListener('click', () => switchScreen(notificationsPage));
    document.getElementById('direct-msg-btn').addEventListener('click', () => switchScreen(messagesPage));
    document.getElementById('back-from-messages-btn').addEventListener('click', () => switchScreen(mainPage));
    document.getElementById('back-from-notifications-btn').addEventListener('click', () => switchScreen(mainPage));
    document.getElementById('back-to-feed-btn').addEventListener('click', () => switchScreen(mainPage));

    // Auth forms
    document.getElementById('show-signup').addEventListener('click', (e) => {
        e.preventDefault();
        loginPage.classList.remove('active');
        signupPage.classList.add('active');
    });

    document.getElementById('show-login').addEventListener('click', (e) => {
        e.preventDefault();
        signupPage.classList.remove('active');
        loginPage.classList.add('active');
    });

    document.getElementById('login-form').addEventListener('submit', (e) => {
        e.preventDefault();
        const email = document.getElementById('login-email').value.toLowerCase().trim();
        handleLogin(email, email.split('@')[0]);
    });

    document.getElementById('signup-form').addEventListener('submit', (e) => {
        e.preventDefault();
        const email = document.getElementById('signup-email').value.toLowerCase().trim();
        const username = document.getElementById('signup-username').value.trim();
        handleLogin(email, username);
    });

    function handleLogin(email, username) {
        const isVerified = VERIFIED_EMAILS.includes(email);
        currentUser = { email, username, bio: 'أضف نبذة تعريفية تعبر عنك...', isVerified };

        loginPage.classList.remove('active');
        signupPage.classList.remove('active');
        switchScreen(mainPage);

        document.getElementById('msg-screen-username').textContent = currentUser.username;
        updateUserProfileUI();
    }

    // Update Profile UI (Without fake stats)
    function updateUserProfileUI() {
        if (!currentUser) return;

        document.getElementById('modern-header-username').textContent = currentUser.username;
        document.getElementById('modern-display-name').textContent = `@${currentUser.username}`;
        document.getElementById('modern-bio-display').textContent = currentUser.bio;

        // Realistic actual stats
        document.getElementById('posts-count').textContent = userPosts.length;
        document.getElementById('followers-count').textContent = '0';
        document.getElementById('following-count').textContent = '0';

        const badgeContainer = document.getElementById('modern-verified-badge-container');
        badgeContainer.innerHTML = currentUser.isVerified ? '<i class="fas fa-check-circle verified-badge"></i>' : '';

        if (userAvatarUrl) {
            const imgHtml = `<img src="${userAvatarUrl}" alt="Avatar">`;
            document.getElementById('modern-avatar-img').innerHTML = imgHtml;
            document.getElementById('edit-avatar-preview').innerHTML = imgHtml;
            document.querySelectorAll('.feed-user-avatar').forEach(el => el.innerHTML = imgHtml);
        }

        if (userCoverUrl) {
            document.getElementById('profile-cover-box').style.backgroundImage = `url('${userCoverUrl}')`;
        }

        renderUserPosts();
    }

    // Direct Avatar / Cover Selection
    function handleProfileImageSelect(e) {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(evt) {
                userAvatarUrl = evt.target.result;
                updateUserProfileUI();
            };
            reader.readAsDataURL(file);
        }
    }

    document.getElementById('direct-avatar-file-input').addEventListener('change', handleProfileImageSelect);
    document.getElementById('modal-avatar-input').addEventListener('change', handleProfileImageSelect);

    document.getElementById('cover-file-input').addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(evt) {
                userCoverUrl = evt.target.result;
                updateUserProfileUI();
            };
            reader.readAsDataURL(file);
        }
    });

    // Create Modal triggers
    document.querySelectorAll('.nav-create-trigger').forEach(btn => {
        btn.addEventListener('click', () => {
            storyActionModal.style.display = 'flex';
        });
    });

    document.getElementById('close-story-modal').addEventListener('click', () => {
        storyActionModal.style.display = 'none';
    });

    document.getElementById('opt-create-post').addEventListener('click', () => {
        storyActionModal.style.display = 'none';
        createPostModal.style.display = 'flex';
    });

    document.getElementById('opt-add-story').addEventListener('click', () => {
        storyActionModal.style.display = 'none';
        document.getElementById('story-file-input').click();
    });

    document.getElementById('close-post-modal').addEventListener('click', () => {
        createPostModal.style.display = 'none';
    });

    // Post Image Upload Preview
    document.getElementById('post-image-input').addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(evt) {
                selectedPostImage = evt.target.result;
                document.getElementById('post-image-preview-container').innerHTML = `<img src="${selectedPostImage}">`;
            };
            reader.readAsDataURL(file);
        }
    });

    // Create & Publish Post
    document.getElementById('submit-post-btn').addEventListener('click', () => {
        const text = document.getElementById('post-text-input').value.trim();
        if (!text && !selectedPostImage) return;

        const newPost = {
            id: Date.now(),
            text: text,
            image: selectedPostImage,
            likes: 0,
            liked: false,
            time: 'الآن'
        };

        userPosts.unshift(newPost);
        document.getElementById('post-text-input').value = '';
        selectedPostImage = null;
        document.getElementById('post-image-preview-container').innerHTML = '';
        createPostModal.style.display = 'none';

        updateUserProfileUI();
        renderFeed();
    });

    // Render Feed & Posts
    function renderFeed() {
        const feedContainer = document.getElementById('feed-container');
        if (userPosts.length === 0) {
            feedContainer.innerHTML = `
                <div id="empty-feed-msg" class="empty-feed">
                    <i class="far fa-newspaper empty-icon"></i>
                    <p>لا توجد منشورات حتى الآن.</p>
                </div>`;
            return;
        }

        feedContainer.innerHTML = '';
        userPosts.forEach(post => {
            const card = document.createElement('div');
            card.className = 'post-card';
            card.innerHTML = `
                <div class="post-header">
                    <div class="post-avatar default-avatar feed-user-avatar">
                        ${userAvatarUrl ? `<img src="${userAvatarUrl}">` : '<i class="fas fa-user"></i>'}
                    </div>
                    <div class="post-user-info">
                        <div class="post-username">@${currentUser.username}</div>
                        <div class="post-time">${post.time}</div>
                    </div>
                </div>
                ${post.text ? `<div class="post-text">${post.text}</div>` : ''}
                ${post.image ? `<div class="post-img-box"><img src="${post.image}"></div>` : ''}
                <div class="post-actions">
                    <button class="post-action-btn like-btn ${post.liked ? 'liked' : ''}" data-id="${post.id}">
                        <i class="${post.liked ? 'fas' : 'far'} fa-heart"></i>
                        <span>${post.likes}</span>
                    </button>
                    <button class="post-action-btn"><i class="far fa-comment"></i> 0</button>
                    <button class="post-action-btn"><i class="fas fa-share"></i></button>
                </div>
            `;

            // Like action
            card.querySelector('.like-btn').addEventListener('click', (e) => {
                const btn = e.currentTarget;
                post.liked = !post.liked;
                post.likes += post.liked ? 1 : -1;
                renderFeed();
            });

            feedContainer.appendChild(card);
        });
    }

    function renderUserPosts() {
        const grid = document.getElementById('profile-user-posts');
        if (userPosts.length === 0) {
            grid.innerHTML = `
                <div class="empty-profile-content">
                    <i class="fas fa-photo-video empty-p-icon"></i>
                    <p>لم تقم بنشر أي منشورات بعد.</p>
                </div>`;
            return;
        }

        grid.innerHTML = '';
        userPosts.forEach(post => {
            const item = document.createElement('div');
            item.className = 'post-card';
            item.style.marginBottom = '15px';
            item.innerHTML = `
                ${post.text ? `<p class="post-text">${post.text}</p>` : ''}
                ${post.image ? `<div class="post-img-box"><img src="${post.image}"></div>` : ''}
                <div class="post-actions">
                    <span class="post-action-btn"><i class="fas fa-heart"></i> ${post.likes}</span>
                </div>
            `;
            grid.appendChild(item);
        });
    }

    // Edit profile dialog
    document.getElementById('open-edit-profile-btn').addEventListener('click', () => {
        document.getElementById('edit-username-input').value = currentUser.username;
        document.getElementById('edit-bio-input').value = currentUser.bio;
        editProfileModal.style.display = 'flex';
    });

    document.getElementById('save-profile-btn').addEventListener('click', () => {
        const newUsername = document.getElementById('edit-username-input').value.trim();
        const newBio = document.getElementById('edit-bio-input').value.trim();

        if (newUsername) currentUser.username = newUsername;
        currentUser.bio = newBio || 'أضف نبذة تعريفية...';

        updateUserProfileUI();
        editProfileModal.style.display = 'none';
    });

    document.getElementById('close-edit-modal').addEventListener('click', () => editProfileModal.style.display = 'none');
    document.getElementById('close-settings-modal').addEventListener('click', () => settingsModal.style.display = 'none');
    document.getElementById('open-settings-from-profile').addEventListener('click', () => settingsModal.style.display = 'flex');

    document.getElementById('share-profile-btn').addEventListener('click', () => {
        if (navigator.share) {
            navigator.share({ title: currentUser.username, url: window.location.href });
        } else {
            alert('تم نسخ رابط الملف الشخصي!');
        }
    });

    document.getElementById('logout-btn').addEventListener('click', () => {
        currentUser = null;
        userAvatarUrl = null;
        userCoverUrl = null;
        userPosts = [];
        settingsModal.style.display = 'none';
        switchScreen(loginPage);
    });
});
