# Build WA LINK dari Termux

## Yang dibangun di sini
- `MainActivity` memuat `index.html` kamu (UI "Manajemen Akun" yang sudah ada) di dalam WebView lokal.
- Tombol **BUKA** di tiap slot sekarang manggil `WaLinkNative.openSlot(index, nama)` lewat JS bridge,
  yang membuka `WaWebViewActivity` berisi WebView ke `https://web.whatsapp.com/`.
- Tiap slot (0-4) jalan di **proses Android terpisah** (`:wa0`.. `:wa4`), dan `WaLinkApplication`
  mengatur data directory WebView unik per proses. Ini sebabnya tiap slot bisa login
  linked-device WhatsApp yang berbeda secara bersamaan tanpa cookie/session-nya bentrok.
- Mendukung 5 slot aktif sekaligus (index 0-4). Slot ke-6 akan berbagi proses dengan slot 0
  (lihat komentar di `MainActivity.NativeBridge.openSlot`) — tambah proses baru di
  `AndroidManifest.xml` + subclass baru kalau butuh lebih banyak.
- WebView di slot pakai desktop User-Agent (supaya WhatsApp Web mau jalan) dan sudah
  meminta izin kamera/mikrofon untuk voice note serta voice/video call.

**Penting:** fitur ini hanya untuk menautkan (link) akun WhatsApp milik pengguna sendiri lewat
QR code resmi WhatsApp — sama seperti WhatsApp Web biasa, hanya dibungkus di dalam app-mu.

## Setup toolchain di Termux

```bash
pkg update && pkg upgrade
pkg install openjdk-17 gradle git
```

Android SDK command-line tools (butuh koneksi internet untuk download):

```bash
pkg install wget unzip
mkdir -p ~/android-sdk/cmdline-tools
cd ~/android-sdk/cmdline-tools
wget https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
unzip commandlinetools-linux-11076708_latest.zip
mv cmdline-tools latest

export ANDROID_HOME=~/android-sdk
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools

yes | sdkmanager --licenses
sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"
```

> Catatan: `sdkmanager`, `aapt2`, dan `d8` dari Google ini dikompilasi untuk x86_64/Linux biasa.
> Di HP ARM lewat Termux ini kadang tidak langsung jalan (`CANNOT LINK EXECUTABLE` dsb).
> Kalau kamu mentok di langkah ini, cara paling stabil untuk build Android project
> langsung di HP adalah pakai aplikasi **AndroidIDE** (project Termux-based yang sudah
> menyertakan toolchain ARM-native) — project folder ini (`WaLinkApp/`) bisa langsung
> di-import ke situ tanpa diubah, lalu build seperti biasa dari dalam app-nya.

## Build APK (kalau toolchain di atas sudah jalan)

```bash
export ANDROID_HOME=~/android-sdk
cd WaLinkApp
gradle assembleDebug
```

APK hasil build ada di `app/build/outputs/apk/debug/app-debug.apk`, tinggal `pkg install termux-api`
dan install lewat `termux-open app/build/outputs/apk/debug/app-debug.apk`, atau copy ke folder
Download lalu install manual.

## Struktur file untuk diedit

- `app/src/main/assets/index.html`, `style.css`, `script.js` — UI (sama seperti project awalmu).
- `app/src/main/java/com/rasya/walink/MainActivity.kt` — load UI + bridge ke WebView slot.
- `app/src/main/java/com/rasya/walink/WaWebViewActivity.kt` — logika WebView WhatsApp Web
  (user agent, izin kamera/mic, file picker untuk attachment).
- `app/src/main/java/com/rasya/walink/WaLinkApplication.kt` — isolasi data per slot.
- `app/src/main/AndroidManifest.xml` — daftar proses `:wa0`.. `:wa4`.
