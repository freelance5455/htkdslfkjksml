let toastTimer;

function info(message) {
  const box = document.getElementById("toast");
  box.textContent = message;
  box.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => box.classList.remove("show"), 3200);
}

function openWeb() {
  info("Pemindai Web WALINK tidak tersedia.");
}

function openWA() {
  window.location.href = "https://www.whatsapp.com/";
}

function getSlots() {
  try {
    return JSON.parse(localStorage.getItem("walink_slots") || '["Pengguna 1"]');
  } catch {
    return ["Pengguna 1"];
  }
}

function saveSlots(slots) {
  localStorage.setItem("walink_slots", JSON.stringify(slots));
}

function manageAccount() {
  document.getElementById("walink-manager")?.remove();

  const slots = getSlots();

  const modal = document.createElement("div");
  modal.id = "walink-manager";
  modal.innerHTML = `
    <div class="wm-backdrop" onclick="closeManager()"></div>
    <div class="wm-panel">
      <div class="wm-head">
        <div>
          <small>WA LINK / ACCOUNT CENTER</small>
          <h2>Manajemen Akun</h2>
        </div>
        <button class="wm-close" onclick="closeManager()">✕</button>
      </div>
      <p class="wm-sub">Kelola slot akun WhatsApp milikmu.</p>
      <div id="wm-slots"></div>
      <button class="wm-add" onclick="addSlot()">＋ Tambah Pengguna</button>
      <div class="wm-note">Penautan akun dilakukan melalui layanan resmi WhatsApp. WALINK hanya menyimpan nama slot di perangkat ini.</div>
    </div>
  `;

  document.body.appendChild(modal);
  renderSlots();
}

function renderSlots() {
  const list = document.getElementById("wm-slots");
  if (!list) return;

  const slots = getSlots();

  list.innerHTML = slots.map((name, i) => `
    <div class="wm-slot">
      <div class="wm-avatar">${i + 1}</div>
      <div class="wm-info">
        <b>${escapeText(name)}</b>
        <small>Slot akun lokal</small>
      </div>
      <button class="wm-open" onclick="openSlot(${i}, '${escapeText(name).replace(/'/g, "\\'")}')">BUKA</button>
      <button class="wm-delete" onclick="deleteSlot(${i})">×</button>
    </div>
  `).join("");
}

function addSlot() {
  const slots = getSlots();
  let n = 1;
  while (slots.includes("Pengguna " + n)) n++;
  slots.push("Pengguna " + n);
  saveSlots(slots);
  renderSlots();
  info("Pengguna " + n + " berhasil ditambahkan.");
}

function openSlot(index, name) {
  if (window.WaLinkNative && typeof window.WaLinkNative.openSlot === "function") {
    // Inside the APK: opens an isolated in-app WebView session for this slot.
    window.WaLinkNative.openSlot(index, name);
  } else {
    // Fallback when running as a plain web page (no native bridge available).
    info("Buka aplikasi WA LINK untuk menautkan akun ini.");
  }
}

function deleteSlot(index) {
  const slots = getSlots();
  if (slots.length <= 1) {
    info("Minimal harus ada satu slot.");
    return;
  }

  if (!confirm("Hapus slot ini?")) return;
  slots.splice(index, 1);
  saveSlots(slots);
  renderSlots();
}

function closeManager() {
  document.getElementById("walink-manager")?.remove();
}

function escapeText(text) {
  return String(text).replace(/[&<>"']/g, c => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  }[c]));
}

function directChat() {
  const number = prompt("Masukkan nomor dengan kode negara, tanpa +:");
  if (!number) return;

  const clean = number.replace(/[^0-9]/g, "");
  if (clean.length < 8) {
    info("Nomor tidak valid.");
    return;
  }

  window.location.href = "https://wa.me/" + clean;
}

function downloads() {
  info("Unduhan dikelola melalui folder Download perangkat kamu.");
}

function guide() {
  info("Tambah slot untuk mengatur daftar akun. Penautan dilakukan melalui WhatsApp resmi.");
}
