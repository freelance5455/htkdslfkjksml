package com.rasya.walink

import android.app.ActivityManager
import android.app.Application
import android.os.Process
import android.webkit.WebView

/**
 * Each WhatsApp Web "slot" runs its own Android process (see AndroidManifest,
 * android:process=":wa0" .. ":wa4"). WebView only allows ONE process per app
 * to use the default data directory, so every non-default process must set
 * its own unique suffix *before* any WebView is created in that process.
 * This must run as early as possible, hence it lives in Application, not in
 * the Activity itself.
 */
class WaLinkApplication : Application() {

    override fun onCreate() {
        super.onCreate()

        val processName = currentProcessName() ?: return
        val suffix = processName.substringAfterLast(':', missingDelimiterValue = "")

        // Only the ":waN" slot processes need a custom suffix.
        // The main process (running MainActivity's local-UI WebView) keeps the default.
        if (suffix.startsWith("wa")) {
            WebView.setDataDirectorySuffix(suffix)
        }
    }

    private fun currentProcessName(): String? {
        val pid = Process.myPid()
        val manager = getSystemService(ACTIVITY_SERVICE) as? ActivityManager ?: return null
        return manager.runningAppProcesses?.firstOrNull { it.pid == pid }?.processName
    }
}
