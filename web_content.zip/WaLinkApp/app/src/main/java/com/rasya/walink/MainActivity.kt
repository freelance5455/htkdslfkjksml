package com.rasya.walink

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val webView = findViewById<WebView>(R.id.webview)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = WebViewClient()

        // Exposes window.WaLinkNative.openSlot(index) to the page's JavaScript
        webView.addJavascriptInterface(NativeBridge(this), "WaLinkNative")

        webView.loadUrl("file:///android_asset/index.html")
    }

    class NativeBridge(private val activity: MainActivity) {

        /** Called from script.js when the user taps "BUKA" on a slot. */
        @JavascriptInterface
        fun openSlot(slotIndex: Int, slotName: String) {
            activity.runOnUiThread {
                // Only 5 isolated processes are declared (wa0..wa4), so slots cycle through them.
                // With more than 5 slots, slot 5 would share a process (and session) with slot 0.
                val targetClass = when (slotIndex % 5) {
                    0 -> WaWebViewActivity::class.java
                    1 -> WaSlotActivity1::class.java
                    2 -> WaSlotActivity2::class.java
                    3 -> WaSlotActivity3::class.java
                    else -> WaSlotActivity4::class.java
                }
                val intent = Intent(activity, targetClass)
                intent.putExtra(WaWebViewActivity.EXTRA_SLOT_INDEX, slotIndex)
                intent.putExtra(WaWebViewActivity.EXTRA_SLOT_NAME, slotName)
                activity.startActivity(intent)
            }
        }
    }
}
