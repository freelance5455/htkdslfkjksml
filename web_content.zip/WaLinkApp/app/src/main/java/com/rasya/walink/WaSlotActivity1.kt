package com.rasya.walink

/** Runs in its own process (see AndroidManifest, android:process=":wa1") so this
 *  slot's WhatsApp Web session (cookies/local storage) is isolated from the others. */
class WaSlotActivity1 : WaWebViewActivity()
