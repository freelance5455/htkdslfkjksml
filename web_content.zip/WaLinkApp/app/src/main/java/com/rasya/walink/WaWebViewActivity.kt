package com.rasya.walink

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.webkit.ConsoleMessage
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * Open base class: each concrete subclass (WaSlotActivity1..4) is declared in the
 * manifest with its own android:process, which is what actually gives each slot
 * an isolated WhatsApp Web session (see WaLinkApplication for why).
 */
open class WaWebViewActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_SLOT_INDEX = "slot_index"
        const val EXTRA_SLOT_NAME = "slot_name"
        private const val DESKTOP_USER_AGENT =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        private const val RUNTIME_PERMISSION_REQUEST = 1001
    }

    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var pendingPermissionRequest: PermissionRequest? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_wa_webview)
        title = intent.getStringExtra(EXTRA_SLOT_NAME) ?: "WhatsApp Web"

        webView = findViewById(R.id.wa_webview)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.databaseEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.settings.userAgentString = DESKTOP_USER_AGENT
        WebView.setWebContentsDebuggingEnabled(true) // lets you inspect via chrome://inspect from a PC
        webView.webViewClient = buildWebViewClient()
        webView.webChromeClient = buildChromeClient()

        requestRuntimePermissions()
        webView.loadUrl("https://web.whatsapp.com/")
    }

    private fun buildWebViewClient() = object : WebViewClient() {
        override fun onReceivedError(
            view: WebView,
            request: WebResourceRequest,
            error: WebResourceError
        ) {
            super.onReceivedError(view, request, error)
            if (request.isForMainFrame) {
                Log.e("WaLink", "Page load error: ${error.errorCode} ${error.description} url=${request.url}")
            }
        }

        override fun onPageFinished(view: WebView, url: String) {
            super.onPageFinished(view, url)
            Log.d("WaLink", "onPageFinished: $url")
        }
    }

    private fun buildChromeClient() = object : WebChromeClient() {

        override fun onConsoleMessage(message: ConsoleMessage): Boolean {
            Log.d(
                "WaLinkConsole",
                "${message.message()} -- ${message.sourceId()}:${message.lineNumber()}"
            )
            return true
        }


        // Camera/mic access for voice notes, voice calls and video calls
        override fun onPermissionRequest(request: PermissionRequest) {
            val needsCamera = request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)
            val needsMic = request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)

            val cameraOk = !needsCamera || hasPermission(Manifest.permission.CAMERA)
            val micOk = !needsMic || hasPermission(Manifest.permission.RECORD_AUDIO)

            if (cameraOk && micOk) {
                runOnUiThread { request.grant(request.resources) }
            } else {
                pendingPermissionRequest = request
                requestRuntimePermissions()
            }
        }

        // File picker for sending attachments (photos, documents, etc.)
        override fun onShowFileChooser(
            webView: WebView,
            callback: ValueCallback<Array<Uri>>,
            params: FileChooserParams
        ): Boolean {
            filePathCallback?.onReceiveValue(null)
            filePathCallback = callback
            try {
                startActivityForResult(params.createIntent(), 2001)
            } catch (e: Exception) {
                filePathCallback = null
                return false
            }
            return true
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        if (requestCode == 2001) {
            val results = WebChromeClient.FileChooserParams.parseResult(resultCode, data)
            filePathCallback?.onReceiveValue(results)
            filePathCallback = null
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    private fun hasPermission(permission: String) =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    private fun requestRuntimePermissions() {
        val needed = listOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
            .filter { !hasPermission(it) }
        if (needed.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toTypedArray(), RUNTIME_PERMISSION_REQUEST)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == RUNTIME_PERMISSION_REQUEST) {
            pendingPermissionRequest?.let { request ->
                if (hasPermission(Manifest.permission.CAMERA) && hasPermission(Manifest.permission.RECORD_AUDIO)) {
                    request.grant(request.resources)
                } else {
                    request.deny()
                }
            }
            pendingPermissionRequest = null
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
