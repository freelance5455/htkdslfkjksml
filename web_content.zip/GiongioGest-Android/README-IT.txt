GIONGIO GEST 1.4 - PROGETTO ANDROID

Questo progetto ricrea il contenitore Android dell'app e gestisce esplicitamente
WebChromeClient.onShowFileChooser, necessario per aprire il selettore file da HTML
dentro una WebView. Il selettore Android consente di scegliere una o più immagini.

REQUISITI
- Android Studio recente
- JDK 17
- Android SDK Platform 35

COME GENERARE L'APK
1. Estrai lo ZIP.
2. Apri la cartella GiongioGest-Android con Android Studio.
3. Attendi la sincronizzazione Gradle e l'installazione degli eventuali componenti SDK.
4. Seleziona Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio mostrerà il percorso dell'APK generato.

NOTE IMPORTANTI
- Il file HTML è incluso in app/src/main/assets/index.html.
- Non sono richiesti permessi generali di memoria: il selettore documenti Android
  concede accesso alle URI selezionate dall'utente.
- I dati di localStorage e IndexedDB dipendono dall'origine WebView. Questo progetto
  usa l'origine stabile https://appassets.androidplatform.net per gli asset locali.
  La prima installazione del nuovo contenitore potrebbe non vedere i dati locali
  salvati dalla vecchia app. Prima di sostituire l'app, esporta il backup JSON
  dalla vecchia Giongio Gest e conservalo.
- L'applicationId è it.giongiogest.app. Se la vecchia app usa un ID diverso, Android
  la installerà come app separata (più sicuro per provare senza sovrascrivere i dati).
- Il progetto è preparato ma non è stato compilato né provato su un telefono in questo
  ambiente: non considerarlo un APK già pronto o una correzione verificata.
