// ==============================
// VENOM SHOP JAVASCRIPT
// ==============================


// MENU

const menuBtn = document.getElementById("menuBtn");

const navMenu = document.getElementById("navMenu");


menuBtn.addEventListener("click", function () {

    navMenu.classList.toggle("show");

});


// CLOSE MENU WHEN A LINK IS CLICKED

const navLinks = document.querySelectorAll("#navMenu a");


navLinks.forEach(function (link) {

    link.addEventListener("click", function () {

        navMenu.classList.remove("show");

    });

});


// CURRENT YEAR

const year = document.getElementById("year");

year.textContent = new Date().getFullYear();


// BUTTON CLICK EFFECT

const buttons = document.querySelectorAll(".btn");


buttons.forEach(function (button) {

    button.addEventListener("click", function () {

        button.style.transform = "scale(0.96)";

        setTimeout(function () {

            button.style.transform = "scale(1)";

        }, 120);

    });

});