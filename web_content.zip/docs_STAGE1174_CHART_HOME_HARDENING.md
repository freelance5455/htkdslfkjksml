# Stage 1174 — Chart/Home Hardening

- Added SVG DOM fallback charts for Trade and Futures so Android WebView canvas/GPU rendering cannot leave the chart visually blank.
- Fallback uses real received OHLC rows when available; if historical rows are unavailable it shows a clearly labeled LIVE sampled view instead of a blank area or fabricated historical candles.
- Home missing-price callback no longer rebuilds the whole market list on every single ticker; it updates the exact visible row, preventing scroll/list churn.
- Home forced price sweep also requests the secondary CoinPaprika public snapshot as a fallback while LBank remains authoritative when available.
- Existing LBank native REST/WebSocket market paths are preserved.
