window.DexParser = {
    parse(arrayBuffer, fileName = 'classes.dex') {
        const dataView = new DataView(arrayBuffer);
        const bytes = new Uint8Array(arrayBuffer);

        const magic = String.fromCharCode(...bytes.slice(0, 4));
        if (magic !== 'dex\n') {
            throw new Error(`الملف ${fileName} ليس ملف DEX صالحاً.`);
        }

        const stringIdsSize = dataView.getUint32(56, true);
        const stringIdsOff = dataView.getUint32(60, true);

        const typeIdsSize = dataView.getUint32(64, true);
        const typeIdsOff = dataView.getUint32(68, true);

        const methodIdsSize = dataView.getUint32(88, true);
        const methodIdsOff = dataView.getUint32(92, true);

        const classDefsSize = dataView.getUint32(96, true);
        const classDefsOff = dataView.getUint32(100, true);

        const strings = [];
        for (let i = 0; i < stringIdsSize; i++) {
            const stringDataOff = dataView.getUint32(stringIdsOff + (i * 4), true);
            const uleb = Utils.readULEB128(dataView, stringDataOff);
            const strBytes = bytes.slice(stringDataOff + uleb.byteLength, stringDataOff + uleb.byteLength + uleb.value);
            strings.push(Utils.readMUTF8(strBytes));
        }

        const types = [];
        for (let i = 0; i < typeIdsSize; i++) {
            const descriptorIdx = dataView.getUint32(typeIdsOff + (i * 4), true);
            types.push(strings[descriptorIdx] || `Type_${descriptorIdx}`);
        }

        const methods = [];
        for (let i = 0; i < methodIdsSize; i++) {
            const offset = methodIdsOff + (i * 8);
            const classIdx = dataView.getUint16(offset, true);
            const nameIdx = dataView.getUint32(offset + 4, true);
            methods.push(`${types[classIdx] || 'Class'}->${strings[nameIdx] || 'Method'}`);
        }

        const classes = [];
        for (let i = 0; i < classDefsSize; i++) {
            const offset = classDefsOff + (i * 32);
            const classIdx = dataView.getUint32(offset, true);
            classes.push(types[classIdx] || `Class_${classIdx}`);
        }

        return { fileName, strings, types, classes, methods };
    }
};
