// ==========================================
// GOLDEN DEX ANALYZER - DEX PARSER ENGINE
// ==========================================

window.DexParser = {
    /**
     * تحليل ملف DEX واستخراج الهيكل الداخلي وجداول المعرفات
     * @param {ArrayBuffer} arrayBuffer - بيانات ملف DEX
     * @param {string} fileName - اسم الملف
     * @returns {Object} الهيكل المحلل
     */
    parse(arrayBuffer, fileName = 'classes.dex') {
        const dataView = new DataView(arrayBuffer);
        const bytes = new Uint8Array(arrayBuffer);

        // 1. التحقق من التوقيع السحري (Magic Bytes)
        const magic = String.fromCharCode(...bytes.slice(0, 4));
        if (magic !== 'dex\n') {
            throw new Error(`الملف ${fileName} ليس ملف DEX صالحاً.`);
        }

        // 2. قراءة بيانات الـ Header بالكامل
        const header = {
            magic: magic,
            version: String.fromCharCode(...bytes.slice(4, 7)),
            checksum: dataView.getUint32(8, true),
            signature: bytes.slice(12, 32),
            fileSize: dataView.getUint32(32, true),
            headerSize: dataView.getUint32(36, true),
            endianTag: dataView.getUint32(40, true),
            linkSize: dataView.getUint32(44, true),
            linkOff: dataView.getUint32(48, true),
            mapOff: dataView.getUint32(52, true),
            stringIdsSize: dataView.getUint32(56, true),
            stringIdsOff: dataView.getUint32(60, true),
            typeIdsSize: dataView.getUint32(64, true),
            typeIdsOff: dataView.getUint32(68, true),
            protoIdsSize: dataView.getUint32(72, true),
            protoIdsOff: dataView.getUint32(76, true),
            fieldIdsSize: dataView.getUint32(80, true),
            fieldIdsOff: dataView.getUint32(84, true),
            methodIdsSize: dataView.getUint32(88, true),
            methodIdsOff: dataView.getUint32(92, true),
            classDefsSize: dataView.getUint32(96, true),
            classDefsOff: dataView.getUint32(100, true),
            dataSize: dataView.getUint32(104, true),
            dataOff: dataView.getUint32(108, true)
        };

        // 3. استخراج جدول النصوص (String IDs Table)
        const strings = [];
        for (let i = 0; i < header.stringIdsSize; i++) {
            const stringDataOff = dataView.getUint32(header.stringIdsOff + (i * 4), true);
            const uleb = this.readULEB128(dataView, stringDataOff);
            const strBytes = bytes.slice(stringDataOff + uleb.byteLength, stringDataOff + uleb.byteLength + uleb.value);
            strings.push(this.readMUTF8(strBytes));
        }

        // 4. استخراج جدول الأنواع (Type IDs Table)
        const types = [];
        for (let i = 0; i < header.typeIdsSize; i++) {
            const descriptorIdx = dataView.getUint32(header.typeIdsOff + (i * 4), true);
            types.push(strings[descriptorIdx] || `Type_${descriptorIdx}`);
        }

        // 5. استخراج جدول الحقول (Field IDs Table)
        const fields = [];
        for (let i = 0; i < header.fieldIdsSize; i++) {
            const offset = header.fieldIdsOff + (i * 8);
            const classIdx = dataView.getUint16(offset, true);
            const typeIdx = dataView.getUint16(offset + 2, true);
            const nameIdx = dataView.getUint32(offset + 4, true);
            fields.push(`${types[classIdx] || 'Class'}->${strings[nameIdx] || 'Field'}:${types[typeIdx] || 'Type'}`);
        }

        // 6. استخراج جدول الدوال (Method IDs Table)
        const methods = [];
        for (let i = 0; i < header.methodIdsSize; i++) {
            const offset = header.methodIdsOff + (i * 8);
            const classIdx = dataView.getUint16(offset, true);
            const protoIdx = dataView.getUint16(offset + 2, true);
            const nameIdx = dataView.getUint32(offset + 4, true);
            methods.push(`${types[classIdx] || 'Class'}->${strings[nameIdx] || 'Method'}`);
        }

        // 7. استخراج تعاريف الكلاسات (Class Definitions)
        const classes = [];
        for (let i = 0; i < header.classDefsSize; i++) {
            const offset = header.classDefsOff + (i * 32);
            const classIdx = dataView.getUint32(offset, true);
            classes.push(types[classIdx] || `Class_${classIdx}`);
        }

        return {
            fileName,
            header,
            strings,
            types,
            fields,
            methods,
            classes
        };
    },

    /**
     * قراءة ترميز ULEB128 المتغير الطول
     */
    readULEB128(dataView, offset) {
        let result = 0;
        let shift = 0;
        let size = 0;
        let byte;

        do {
            byte = dataView.getUint8(offset + size);
            result |= (byte & 0x7f) << shift;
            shift += 7;
            size++;
        } while ((byte & 0x80) !== 0);

        return { value: result, byteLength: size };
    },

    /**
     * قراءة سلاسل النصوص بترميز MUTF-8
     */
    readMUTF8(bytes) {
        if (window.Utils && typeof Utils.readMUTF8 === 'function') {
            return Utils.readMUTF8(bytes);
        }
        
        let out = "";
        let i = 0;
        const len = bytes.length;
        
        while (i < len) {
            let c = bytes[i++];
            switch (c >> 4) {
                case 0: case 1: case 2: case 3: case 4: case 5: case 6: case 7:
                    out += String.fromCharCode(c);
                    break;
                case 12: case 13:
                    let char2 = bytes[i++];
                    out += String.fromCharCode(((c & 0x1F) << 6) | (char2 & 0x3F));
                    break;
                case 14:
                    let char2_3 = bytes[i++];
                    let char3 = bytes[i++];
                    out += String.fromCharCode(((c & 0x0F) << 12) | ((char2_3 & 0x3F) << 6) | ((char3 & 0x3F) << 0));
                    break;
            }
        }
        return out;
    }
};
