# PIRACYhub — mobile-first resource discovery website

A static, responsive website inspired by the resource-discovery concept: dark glass UI, mobile bottom navigation, search, categories, bookmarks, community submissions, and a local moderation demo.

## Run it locally
You can open `index.html` directly in a browser for the main UI. For PWA install and offline caching, serve it over localhost or HTTPS:
```bash
python -m http.server 8080
```
Then open `http://localhost:8080` on your computer. For your phone, deploy to a public HTTPS host or use a tunnel while testing.

## Publish for free
1. Create a GitHub repository and upload all files in this folder.
2. In repository settings, enable GitHub Pages for the main branch/root folder.
3. Open the HTTPS URL from your Android phone.
4. In Chrome, use menu → **Install app** or **Add to Home screen** (wording varies).

Other static hosts such as Netlify or Cloudflare Pages also work. Upload this folder as a static site; no build command is needed.

## What works
- Responsive mobile-first UI with a premium dark theme and subtle glass blur.
- Search across titles, descriptions, categories, and tags.
- Category filtering and curated starter resources.
- Save/unsave bookmarks using browser localStorage.
- Submit resources and review a local moderation queue.
- PWA manifest and service worker for home-screen install and basic offline shell.

## Prototype limits
All user data is local to the browser/device. It does not sync between users or devices. The moderation queue is a demonstration and has no real permissions. For a public community, connect a backend such as Supabase or Firebase and implement authentication, server-side moderator roles, abuse reporting, URL/domain safety checks, rate limits, audit logs, privacy policy, and terms.

Review every starter resource for safety, legality, current availability, and attribution before launch. PIRACYhub is independent and not affiliated with or endorsed by FMHY.


Brand update: the header monogram has been replaced with the PIRACYhub neon pirate-ship icon (`piracyhub-ship-icon.png`).
