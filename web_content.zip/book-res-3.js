/* JOSTECH — MANUEL 06 : RÉSEAUX & MAINTENANCE NIVEAU 3 */
registerLessonDetail(6, 3, "res-3-1-1", {
  title: "Leçon 1 : Sous-réseaux CIDR, NAT, Dépannage et Virtualisation",
  duration: "45 min (Manuel universitaire complet)",
  objectives: [
    "Découper un réseau IPv4 en sous-réseaux (notation CIDR /n, adresse réseau et broadcast).",
    "Expliquer le rôle vital du NAT/PAT et des services DHCP / DNS.",
    "Diagnostiquer une panne réseau méthodiquement (ping, traceroute, ss) et comparer VM vs Conteneurs."
  ],
  prerequisites: ["Niveau 2 — OSI et conversions binaires."],
  sections: [
    {
      type: "theory",
      title: "1. Adressage IPv4, Masques CIDR et Sous-réseaux",
      text: "Une adresse IPv4 comporte 32 bits (4 octets, ex: 192.168.10.25). Le masque réseau (souvent écrit en notation CIDR, ex: /24) sépare l'adresse en deux parties : les n bits de gauche identifient le Réseau (NetID), et les (32 - n) bits de droite identifient les Machines (HostID).\n\nDans tout sous-réseau, deux adresses sont réservées et interdites aux machines : la toute première (tous les bits hôtes à 0 = Adresse du Réseau) et la toute dernière (tous les bits hôtes à 1 = Adresse de Broadcast). Le nombre de machines adressables vaut donc toujours : 2^(32 - n) - 2."
    },
    {
      type: "code",
      lang: "Calcul complet d'un sous-réseau /26",
      code: [
        "Réseau : 192.168.1.0/26",
        "• Bits réseau = 26  →  Bits hôtes = 32 - 26 = 6 bits",
        "• Masque binaire : 11111111.11111111.11111111.11000000 = 255.255.255.192",
        "• Taille totale du bloc : 2^6 = 64 adresses (de .0 à .63)",
        "• Adresse réseau : 192.168.1.0  |  Broadcast : 192.168.1.63",
        "• Plage hôtes utilisables (62 machines) : de 192.168.1.1 à 192.168.1.62"
      ].join("\n")
    },
    {
      type: "definition",
      term: "DHCP, NAT/PAT et Virtualisation (VM vs Docker)",
      text: "• DHCP : attribue automatiquement IP, masque, passerelle et DNS à un appareil qui se connecte.\n• NAT/PAT : traduit les milliers d'IP privées (192.168.x.x, 10.x.x.x) d'une école ou maison vers une seule IP publique Internet en utilisant des numéros de ports.\n• VM vs Conteneur : une Machine Virtuelle virtualise tout le matériel et lance un OS complet (lourd en RAM, isolation maximale). Un Conteneur (Docker) partage le noyau Linux de l'hôte en isolant les applications (démarrage instantané, très léger)."
    },
    {
      type: "table",
      title: "2. Méthodologie de dépannage réseau (De bas en haut)",
      headers: ["Commande", "Ce qu'elle teste exactement"],
      rows: [
        ["ping 127.0.0.1", "Vérifie la pile TCP/IP locale de votre propre machine (Loopback)."],
        ["ping 192.168.1.1", "Vérifie le câble/Wi-Fi et la jonction avec votre routeur (Passerelle)."],
        ["ping 8.8.8.8", "Vérifie l'accès réel à Internet (sans dépendre du DNS)."],
        ["ping jostech.edu / nslookup", "Si 8.8.8.8 répond mais pas le nom, la panne vient uniquement du DNS !"]
      ]
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Dimensionnement CIDR d'un campus",
      question: "Un bâtiment universitaire doit connecter 120 ordinateurs dans un seul sous-réseau. Quel préfixe CIDR le plus économique choisissez-vous : /24, /25 ou /26 ?",
      solution: "• /26 donne 2^6 - 2 = 62 hôtes (insuffisant).\n• /25 donne 2^7 - 2 = 126 hôtes utilisables : parfait pour 120 ordinateurs tout en économisant les adresses !"
    },
    {
      title: "Exercice 2 — Diagnostic d'une panne réelle",
      question: "Un étudiant tape « ping 8.8.8.8 » et reçoit des réponses rapides, mais Chrome affiche « DNS_PROBE_FINISHED_BAD_CONFIG » sur tous les sites. Où se situe la panne ?",
      solution: "La connectivité IP vers Internet fonctionne parfaitement. Seule la résolution de noms DNS est en panne (mauvais serveur DNS configuré)."
    }
  ],
  summary: "L'administrateur systèmes et réseaux dimensionne les adresses par CIDR, sécurise l'accès par NAT et VLAN, dépanne méthodiquement (Loopback → Passerelle → IP publique → DNS) et déploie des services légers en conteneurs ou VMs.",
  references: ["Kurose & Ross — Computer Networking.", "Turnbull, J. — The Docker Book."]
});