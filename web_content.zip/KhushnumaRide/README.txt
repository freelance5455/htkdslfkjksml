KHUSHNUMA RIDE — TRIAL APP

This is a phone-friendly PWA prototype with working trial ride booking flow.
Features: Home, Two Wheeler/Four Wheeler daily fares, destination, Book button, booking confirmation.

INSTALL ON ANDROID:
1. Put this folder on a web server (or open index.html for a basic demo).
2. In Chrome, open the hosted address.
3. Chrome menu -> Add to Home screen / Install app.

For a true APK, this web app can next be wrapped into an Android app and connected to a backend/maps/payment system.
