package com.html2apk.wrapper

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.util.Base64
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader
import com.html2apk.wrapper.databinding.ActivityMainBinding
import java.io.ByteArrayInputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * پوستهٔ بومی: WebView تمام‌صفحه که فایل‌های www را از https://appassets.androidplatform.net
 * (یک origin امن) بارگذاری می‌کند. بدون Pull-to-refresh؛ حس برنامهٔ بومی.
 */
class MainActivity : AppCompatActivity() {

    companion object {
        const val LOCAL_HOST = "appassets.androidplatform.net"
    }

    private lateinit var binding: ActivityMainBinding
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private var fileChooserMulti = false
    private var pendingBytes: ByteArray? = null
    private var startUrl: String = ""
    private var pendingUrl: String? = null
    private var pendingToken: String? = null
    private var pendingCookie: String = ""
    private var lastBackPress = 0L
    private var contentReady = false
    private var webViewDead = false
    private var permCallback: ((Boolean) -> Unit)? = null

    @Volatile private var currentHost: String = ""
    @Volatile private var sharedName: String = ""

    private val permissionSet: Set<String> by lazy {
        BuildConfig.PERMISSIONS.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
    }

    private val fileChooserLauncher =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            val list = if (fileChooserMulti) uris else uris.take(1)
            fileChooserCallback?.onReceiveValue(if (list.isNotEmpty()) list.toTypedArray() else null)
            fileChooserCallback = null
        }

    // راه جایگزین وقتی انتخاب‌گر سند (OpenDocument) روی گوشی در دسترس نیست: ACTION_GET_CONTENT
    private val getContentLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            val uris = WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data)
            fileChooserCallback?.onReceiveValue(uris)
            fileChooserCallback = null
        }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
            val cb = permCallback
            permCallback = null
            cb?.invoke(true)
        }

    private val saveLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri ->
            val bytes = pendingBytes
            pendingBytes = null
            if (uri != null && bytes != null) {
                try {
                    contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                    Toast.makeText(this, R.string.saved, Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, getString(R.string.save_failed) + ": " + e.message, Toast.LENGTH_LONG).show()
                }
            }
        }

    /** دانلود فایل (با توکن گیت‌هاب یا کوکی)؛ بعد از ریدایرکت هدرهای احراز هویت حذف می‌شوند. */
    private fun openWithRedirects(start: String, token: String, cookie: String): HttpURLConnection {
        var current = start
        var first = true
        for (i in 0 until 6) {
            val c = URL(current).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 20000
            c.readTimeout = 60000
            c.setRequestProperty("User-Agent", "YA-Forge")
            if (first) {
                if (token.isNotEmpty()) {
                    c.setRequestProperty("Authorization", "Bearer $token")
                    c.setRequestProperty("Accept", "application/octet-stream")
                }
                if (cookie.isNotEmpty()) c.setRequestProperty("Cookie", cookie)
            }
            val code = c.responseCode
            if (code in 200..299) return c
            if (code in 300..399) {
                val loc = c.getHeaderField("Location") ?: throw Exception("redirect")
                current = URL(URL(current), loc).toString()
                first = false
                c.disconnect()
            } else {
                throw Exception("HTTP $code")
            }
        }
        throw Exception("too many redirects")
    }

    private val downloadLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri ->
            val url = pendingUrl
            val token = pendingToken
            val cookie = pendingCookie
            pendingUrl = null
            pendingToken = null
            pendingCookie = ""
            if (uri != null && url != null && token != null) {
                Toast.makeText(this, R.string.downloading, Toast.LENGTH_SHORT).show()
                Thread {
                    try {
                        val conn = openWithRedirects(url, token, cookie)
                        val total = conn.contentLengthLong
                        var done = 0L
                        var lastPct = -1
                        contentResolver.openOutputStream(uri)?.use { out ->
                            conn.inputStream.use { input ->
                                val buf = ByteArray(65536)
                                while (true) {
                                    val n = input.read(buf)
                                    if (n < 0) break
                                    out.write(buf, 0, n)
                                    done += n
                                    if (total > 0) {
                                        val pct = (done * 100 / total).toInt()
                                        if (pct != lastPct) {
                                            lastPct = pct
                                            progressJs(pct)
                                        }
                                    }
                                }
                            }
                        }
                        progressJs(100)
                        runOnUiThread { Toast.makeText(this, R.string.saved, Toast.LENGTH_LONG).show() }
                    } catch (e: Exception) {
                        progressJs(-1)
                        runOnUiThread {
                            Toast.makeText(this, getString(R.string.download_failed) + ": " + e.message, Toast.LENGTH_LONG).show()
                        }
                    }
                }.start()
            }
        }

    private fun progressJs(pct: Int) {
        runOnUiThread {
            if (!webViewDead && !isDestroyed) {
                binding.webView.evaluateJavascript("window.__yaProg&&window.__yaProg($pct)", null)
            }
        }
    }

    /** دانلودهای blob: و data: (خروجی PDF/Excel/بکاپ) را به ذخیرهٔ اندروید می‌فرستد. */
    private val downloadHook = """
(function(){
 if(window.__yaDl)return;window.__yaDl=1;
 function go(a){
  var h=a.href||'';
  if(!/^(blob:|data:)/.test(h))return false;
  var name=a.getAttribute('download')||'file';
  fetch(h).then(function(r){return r.blob()}).then(function(b){
   var f=new FileReader();
   f.onloadend=function(){var s=String(f.result);window.YAApp.saveFile(name,b.type||'application/octet-stream',s.substring(s.indexOf(',')+1))};
   f.readAsDataURL(b)});
  return true}
 var oc=HTMLAnchorElement.prototype.click;
 HTMLAnchorElement.prototype.click=function(){if(this.hasAttribute('download')&&go(this))return;oc.apply(this,arguments)};
 var od=HTMLAnchorElement.prototype.dispatchEvent;
 HTMLAnchorElement.prototype.dispatchEvent=function(e){if(e&&e.type==='click'&&this.hasAttribute('download')&&go(this))return true;return od.apply(this,arguments)};
 document.addEventListener('click',function(e){var a=e.target&&e.target.closest?e.target.closest('a[download]'):null;if(a&&go(a)){e.preventDefault()}},true);
})();
""".trimIndent()

    private fun blobScript(url: String, name: String, mime: String): String {
        return "(function(){fetch(" + org.json.JSONObject.quote(url) +
            ").then(function(r){return r.blob()}).then(function(b){var f=new FileReader();" +
            "f.onloadend=function(){var s=String(f.result);window.YAApp.saveFile(" +
            org.json.JSONObject.quote(name) + "," + org.json.JSONObject.quote(mime) +
            ",s.substring(s.indexOf(',')+1))};f.readAsDataURL(b)})})();"
    }

    private fun isTrustedHost(host: String?): Boolean {
        if (host.isNullOrEmpty()) return false
        if (host == LOCAL_HOST) return true
        val h = host.removePrefix("www.")
        val remoteHost = Uri.parse(BuildConfig.REMOTE_URL).host?.removePrefix("www.")
        if (!remoteHost.isNullOrEmpty() && (h == remoteHost || h.endsWith(".$remoteHost"))) return true
        return BuildConfig.ALLOWED_DOMAINS.any { d ->
            val dd = d.removePrefix("www.")
            dd.isNotBlank() && (h == dd || h.endsWith(".$dd"))
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun saveFile(name: String, mime: String, b64: String) {
            if (!isTrustedHost(currentHost)) return
            val bytes = try { Base64.decode(b64, Base64.DEFAULT) } catch (e: Exception) { return }
            runOnUiThread {
                pendingBytes = bytes
                saveLauncher.launch(name)
            }
        }

        @JavascriptInterface
        fun downloadAsset(name: String, url: String, token: String) {
            if (currentHost != LOCAL_HOST) return
            if (!url.startsWith("https://api.github.com/")) return
            runOnUiThread {
                pendingUrl = url
                pendingToken = token
                pendingCookie = ""
                downloadLauncher.launch(name)
            }
        }

        @JavascriptInterface
        fun appVersion(): String = BuildConfig.VERSION_NAME

        /** نام فایلی که از بیرون (اشتراک‌گذاری) به برنامه داده شده؛ خالی یعنی چیزی نیست. */
        @JavascriptInterface
        fun sharedName(): String = if (currentHost == LOCAL_HOST) sharedName else ""

        @JavascriptInterface
        fun clearShared() {
            sharedName = ""
            File(cacheDir, "shared.bin").delete()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        splash.setKeepOnScreenCondition { !contentReady }
        Handler(Looper.getMainLooper()).postDelayed({ contentReady = true }, 2500)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or
                    WindowInsetsCompat.Type.displayCutout() or
                    WindowInsetsCompat.Type.ime()
            )
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }

        val brand = ContextCompat.getColor(this, R.color.brand_primary_dark)
        val insetsController = WindowCompat.getInsetsController(window, window.decorView)
        val lightBars = ColorUtils.calculateLuminance(brand) > 0.5
        insetsController.isAppearanceLightStatusBars = lightBars
        insetsController.isAppearanceLightNavigationBars = lightBars
        if (BuildConfig.FULLSCREEN) {
            insetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            insetsController.hide(WindowInsetsCompat.Type.systemBars())
        }
        if (BuildConfig.KEEP_SCREEN_ON) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val webView = binding.webView
        webView.overScrollMode = View.OVER_SCROLL_NEVER
        webView.isHapticFeedbackEnabled = false
        webView.setBackgroundColor(ContextCompat.getColor(this, R.color.brand_primary))
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = true
            // صفحه روی https://appassets... است؛ برای اتصال به سرور مدل محلی (http://127.0.0.1) باید mixed content باز باشد.
            // امن می‌ماند چون network_security_config فقط http به 127.0.0.1 و localhost را مجاز می‌کند و بقیهٔ http مسدود است.
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            cacheMode = WebSettings.LOAD_DEFAULT
            setSupportZoom(BuildConfig.ALLOW_ZOOM)
            builtInZoomControls = BuildConfig.ALLOW_ZOOM
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = false
            if (BuildConfig.USER_AGENT_SUFFIX.isNotBlank()) {
                userAgentString = userAgentString + " " + BuildConfig.USER_AGENT_SUFFIX
            }
        }

        webView.addJavascriptInterface(Bridge(), "YAApp")

        val assetsHandler = WebViewAssetLoader.AssetsPathHandler(this)
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/") { path ->
                val p = if (path.isEmpty() || path.endsWith("/")) path + "index.html" else path
                assetsHandler.handle("www/$p")
            }
            .build()

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                val u = request.url
                if (BuildConfig.SHARE_TARGET && u.host == LOCAL_HOST && u.path == "/__shared") {
                    val f = File(cacheDir, "shared.bin")
                    return if (f.exists()) {
                        WebResourceResponse(
                            "application/octet-stream", null, 200, "OK",
                            mapOf("Cache-Control" to "no-store"), f.inputStream()
                        )
                    } else {
                        WebResourceResponse(
                            "text/plain", "utf-8", 404, "Not Found",
                            mapOf("Cache-Control" to "no-store"), ByteArrayInputStream(ByteArray(0))
                        )
                    }
                }
                return assetLoader.shouldInterceptRequest(u)
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                val scheme = (url.scheme ?: "").lowercase()
                if (scheme == "http" || scheme == "https") {
                    if (isTrustedHost(url.host) || !BuildConfig.EXTERNAL_IN_BROWSER) return false
                    openExternal(url)
                    return true
                }
                if (scheme == "about" || scheme == "blob" || scheme == "data" || scheme == "javascript") return false
                if (scheme == "intent") {
                    try {
                        val i = Intent.parseUri(url.toString(), Intent.URI_INTENT_SCHEME)
                        i.component = null
                        i.selector = null
                        i.addCategory(Intent.CATEGORY_BROWSABLE)
                        startActivity(i)
                    } catch (e: Exception) {
                        Toast.makeText(this@MainActivity, R.string.no_app_for_link, Toast.LENGTH_SHORT).show()
                    }
                    return true
                }
                openExternal(url)
                return true
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                currentHost = Uri.parse(url ?: "").host ?: ""
                showContent()
                binding.progressBar.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                currentHost = Uri.parse(url ?: "").host ?: ""
                contentReady = true
                binding.progressBar.visibility = View.GONE
                if (isTrustedHost(currentHost)) view.evaluateJavascript(downloadHook, null)
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                super.onReceivedError(view, request, error)
                if (request.isForMainFrame) showError()
            }

            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                webViewDead = true
                Toast.makeText(this@MainActivity, R.string.renderer_crashed, Toast.LENGTH_LONG).show()
                recreate()
                return true
            }
        }

        webView.setDownloadListener { url, _, contentDisposition, mimetype, _ ->
            val fname = URLUtil.guessFileName(url, contentDisposition, mimetype)
            if (url.startsWith("blob:") || url.startsWith("data:")) {
                webView.evaluateJavascript(blobScript(url, fname, mimetype ?: "application/octet-stream"), null)
            } else if (url.startsWith("http")) {
                pendingUrl = url
                pendingToken = ""
                pendingCookie = CookieManager.getInstance().getCookie(url) ?: ""
                downloadLauncher.launch(fname)
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                fileChooserCallback?.onReceiveValue(null)
                fileChooserCallback = filePathCallback
                fileChooserMulti = fileChooserParams.mode == FileChooserParams.MODE_OPEN_MULTIPLE
                val types = fileChooserParams.acceptTypes
                    .flatMap { it.split(",") }
                    .map { it.trim() }
                    .filter { it.isNotEmpty() }
                // پسوندها (مثل .zip) را خود صفحه بررسی می‌کند؛ فقط نوع‌های MIME کامل را به انتخاب‌گر می‌دهیم.
                val mimes = if (types.isEmpty() || types.any { !it.contains("/") }) arrayOf("*/*")
                else types.distinct().toTypedArray()
                return try {
                    fileChooserLauncher.launch(mimes)
                    true
                } catch (e: Exception) {
                    try {
                        getContentLauncher.launch(fileChooserParams.createIntent())
                        true
                    } catch (e2: Exception) {
                        fileChooserCallback = null
                        filePathCallback.onReceiveValue(null)
                        Toast.makeText(this@MainActivity, "انتخاب‌گر فایل در این گوشی باز نشد", Toast.LENGTH_LONG).show()
                        true
                    }
                }
            }

            override fun onProgressChanged(view: WebView, newProgress: Int) {
                super.onProgressChanged(view, newProgress)
                binding.progressBar.progress = newProgress
            }

            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    if (!isTrustedHost(request.origin?.host)) {
                        request.deny()
                        return@runOnUiThread
                    }
                    val needed = ArrayList<String>()
                    for (r in request.resources) {
                        when (r) {
                            PermissionRequest.RESOURCE_VIDEO_CAPTURE ->
                                if ("camera" in permissionSet) needed.add(android.Manifest.permission.CAMERA) else { request.deny(); return@runOnUiThread }
                            PermissionRequest.RESOURCE_AUDIO_CAPTURE ->
                                if ("microphone" in permissionSet) needed.add(android.Manifest.permission.RECORD_AUDIO) else { request.deny(); return@runOnUiThread }
                            else -> { request.deny(); return@runOnUiThread }
                        }
                    }
                    if (needed.isEmpty()) {
                        request.deny()
                        return@runOnUiThread
                    }
                    askPermissions(needed) { ok ->
                        if (ok) request.grant(request.resources) else request.deny()
                    }
                }
            }

            override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                runOnUiThread {
                    val host = Uri.parse(origin).host
                    if ("location" !in permissionSet || !isTrustedHost(host)) {
                        callback.invoke(origin, false, false)
                        return@runOnUiThread
                    }
                    askPermissions(
                        listOf(
                            android.Manifest.permission.ACCESS_FINE_LOCATION,
                            android.Manifest.permission.ACCESS_COARSE_LOCATION
                        )
                    ) { ok -> callback.invoke(origin, ok, false) }
                }
            }
        }

        binding.retryButton.setOnClickListener {
            showContent()
            webView.loadUrl(startUrl)
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webViewDead) {
                    finish()
                    return
                }
                // اگر صفحه خودش پنجره‌ای باز دارد (مثل مودال)، اول آن را می‌بندد.
                binding.webView.evaluateJavascript(
                    "(function(){try{return window.__yaBack?window.__yaBack():false}catch(e){return false}})()"
                ) { r ->
                    if (r != "true") defaultBack()
                }
            }
        })

        startUrl = if (BuildConfig.REMOTE_URL.isNotBlank()) BuildConfig.REMOTE_URL else "https://$LOCAL_HOST/index.html"
        if (savedInstanceState != null && webView.restoreState(savedInstanceState) != null) {
            // وضعیت قبلی بازیابی شد
        } else {
            webView.loadUrl(startUrl)
        }
        handleShare(intent)
    }

    private fun defaultBack() {
        val webView = binding.webView
        if (binding.errorView.visibility != View.VISIBLE && webView.canGoBack()) {
            webView.goBack()
            return
        }
        val now = System.currentTimeMillis()
        if (BuildConfig.EXIT_CONFIRM && now - lastBackPress > 2000) {
            lastBackPress = now
            Toast.makeText(this, R.string.press_back_again, Toast.LENGTH_SHORT).show()
        } else {
            finish()
        }
    }

    private fun askPermissions(perms: List<String>, done: (Boolean) -> Unit) {
        val missing = perms.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) {
            done(true)
            return
        }
        permCallback?.invoke(false)
        permCallback = {
            done(perms.all { p -> ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED })
        }
        permLauncher.launch(missing.toTypedArray())
    }

    private fun openExternal(uri: Uri) {
        try {
            val i = Intent(Intent.ACTION_VIEW, uri)
            i.addCategory(Intent.CATEGORY_BROWSABLE)
            startActivity(i)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.no_app_for_link, Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            // نادیده گرفته می‌شود
        }
    }

    // ---------- دریافت فایل از «اشتراک‌گذاری / باز کردن با» (فقط وقتی share_target فعال باشد) ----------
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShare(intent)
    }

    @Suppress("DEPRECATION")
    private fun streamUri(i: Intent): Uri? {
        return if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        else i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
    }

    private fun handleShare(intent: Intent?) {
        if (!BuildConfig.SHARE_TARGET || intent == null) return
        val uri: Uri? = when (intent.action) {
            Intent.ACTION_VIEW -> intent.data
            Intent.ACTION_SEND -> streamUri(intent)
            else -> null
        }
        if (uri == null) return
        intent.action = null // تا با چرخش یا بازگشت دوباره پردازش نشود
        Thread {
            try {
                var name = "file"
                contentResolver.query(uri, null, null, null, null)?.use { c ->
                    val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0 && c.moveToFirst()) name = c.getString(idx) ?: "file"
                }
                val out = File(cacheDir, "shared.bin")
                contentResolver.openInputStream(uri)?.use { input ->
                    out.outputStream().use { o -> input.copyTo(o) }
                }
                sharedName = name
                runOnUiThread {
                    if (!webViewDead && !isDestroyed) {
                        binding.webView.evaluateJavascript(
                            "window.__yaShared&&window.__yaShared(" + org.json.JSONObject.quote(name) + ")", null
                        )
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, R.string.shared_failed, Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun showError() {
        binding.progressBar.visibility = View.GONE
        binding.webView.visibility = View.GONE
        binding.errorView.visibility = View.VISIBLE
    }

    private fun showContent() {
        binding.errorView.visibility = View.GONE
        binding.webView.visibility = View.VISIBLE
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        if (!webViewDead) {
            try {
                binding.webView.saveState(outState)
            } catch (e: Exception) {
                // نادیده گرفته می‌شود
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && BuildConfig.FULLSCREEN) {
            WindowCompat.getInsetsController(window, window.decorView).hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    override fun onPause() {
        if (!webViewDead) binding.webView.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (!webViewDead) binding.webView.onResume()
    }

    override fun onDestroy() {
        binding.webView.apply {
            (parent as? ViewGroup)?.removeView(this)
            clearHistory()
            destroy()
        }
        super.onDestroy()
    }
}
