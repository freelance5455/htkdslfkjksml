package com.html2apk.wrapper

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.speech.tts.TextToSpeech
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import androidx.core.content.ContextCompat
import java.util.Locale
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.webkit.WebViewAssetLoader
import com.html2apk.wrapper.databinding.ActivityMainBinding

/**
 * پوستهٔ بومی YA Git: WebView تمام‌صفحه که فایل‌های www را از طریق
 * https://appassets.androidplatform.net (یک origin امن و واقعی) بارگذاری می‌کند.
 * این کار باعث می‌شود IndexedDB، crypto و fetch به APIهای اینترنتی درست کار کنند.
 *
 * پل جاوااسکریپت (YAApp.saveFile) فایل ساخته‌شده توسط صفحه (مثل ZIP) را با
 * انتخاب‌گر سیستم اندروید ذخیره می‌کند؛ روی همهٔ نسخه‌ها بدون نیاز به مجوز حافظه.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null

    // ---- YA Forge v2: مجوزها (GPS، دوربین، میکروفون) و صدا ----
    private var geoCallback: GeolocationPermissions.Callback? = null
    private var geoOrigin: String? = null
    private val locLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
            geoCallback?.invoke(geoOrigin, r.values.any { it }, false)
            geoCallback = null
            geoOrigin = null
        }
    private var permReq: PermissionRequest? = null
    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
            val req = permReq
            permReq = null
            if (req != null) {
                if (r.isNotEmpty() && r.values.all { it }) req.grant(req.resources) else req.deny()
            }
        }
    private var tts: TextToSpeech? = null
    private var ttsWarned = false
    private fun setTtsLang(lang: String): Boolean {
        val loc = if (lang == "fa") Locale("fa", "IR") else Locale.forLanguageTag(lang)
        val r = tts?.setLanguage(loc) ?: return false
        return r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
    }
    private var pendingBytes: ByteArray? = null
    private var startUrl: String = ""
    private var pendingUrl: String? = null
    private var pendingToken: String? = null
    private var pendingCookie: String = ""

    private val fileChooserLauncher =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            fileChooserCallback?.onReceiveValue(
                if (uris.isNotEmpty()) uris.toTypedArray() else null
            )
            fileChooserCallback = null
        }

    private val saveLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri ->
            val bytes = pendingBytes
            pendingBytes = null
            if (uri != null && bytes != null) {
                try {
                    contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                    Toast.makeText(this, "ذخیره شد ✓", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "ذخیره نشد: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }

    /** دانلود فایل (با توکن گیت‌هاب یا کوکی)؛ بعد از ریدایرکت هدرهای احراز هویت حذف می‌شوند. */
    private fun openWithRedirects(start: String, token: String, cookie: String): java.io.InputStream {
        var current = start
        var first = true
        for (i in 0 until 5) {
            val c = java.net.URL(current).openConnection() as java.net.HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 20000
            c.readTimeout = 60000
            c.setRequestProperty("User-Agent", "YA-Forge")
            if (first) {
                if (token.isNotEmpty()) {
                    c.setRequestProperty("Authorization", "Bearer " + token)
                    c.setRequestProperty("Accept", "application/octet-stream")
                }
                if (cookie.isNotEmpty()) c.setRequestProperty("Cookie", cookie)
            }
            val code = c.responseCode
            if (code in 200..299) return c.inputStream
            if (code in 300..399) {
                current = c.getHeaderField("Location") ?: throw Exception("redirect")
                first = false
                c.disconnect()
            } else {
                throw Exception("HTTP " + code)
            }
        }
        throw Exception("too many redirects")
    }

    private val downloadLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri ->
            val url = pendingUrl
            val token = pendingToken
            val cookie = pendingCookie
            pendingUrl = null
            pendingToken = null
            pendingCookie = ""
            if (uri != null && url != null && token != null) {
                Toast.makeText(this, "در حال دانلود…", Toast.LENGTH_SHORT).show()
                Thread {
                    try {
                        val stream = openWithRedirects(url, token, cookie)
                        contentResolver.openOutputStream(uri)?.use { out ->
                            stream.use { it.copyTo(out) }
                        }
                        runOnUiThread {
                            Toast.makeText(this, "ذخیره شد ✓", Toast.LENGTH_LONG).show()
                        }
                    } catch (e: Exception) {
                        runOnUiThread {
                            Toast.makeText(this, "دانلود نشد: " + e.message, Toast.LENGTH_LONG).show()
                        }
                    }
                }.start()
            }
        }

    /** اسکریپتی که دانلودهای blob: و data: (مثل خروجی PDF/Excel/بکاپ) را به ذخیره‌ی اندروید می‌فرستد. */
    private val downloadHook = """
(function(){
 if(window.__yaDl)return;window.__yaDl=1;
 function go(a){
  var h=a.href||'';
  if(!/^(blob:|data:)/.test(h))return false;
  var name=a.getAttribute('download')||'file';
  fetch(h).then(function(r){return r.blob()}).then(function(b){
   var f=new FileReader();
   f.onloadend=function(){var s=String(f.result);window.YAApp.saveFile(name,b.type||'application/octet-stream',s.substring(s.indexOf(',')+1))};
   f.readAsDataURL(b)});
  return true}
 var oc=HTMLAnchorElement.prototype.click;
 HTMLAnchorElement.prototype.click=function(){if(this.hasAttribute('download')&&go(this))return;oc.apply(this,arguments)};
 var od=HTMLAnchorElement.prototype.dispatchEvent;
 HTMLAnchorElement.prototype.dispatchEvent=function(e){if(e&&e.type==='click'&&this.hasAttribute('download')&&go(this))return true;return od.apply(this,arguments)};
 document.addEventListener('click',function(e){var a=e.target&&e.target.closest?e.target.closest('a[download]'):null;if(a&&go(a)){e.preventDefault()}},true);
})();
""".trimIndent()

    private fun blobScript(url: String, name: String, mime: String): String {
        return "(function(){fetch(" + org.json.JSONObject.quote(url) +
            ").then(function(r){return r.blob()}).then(function(b){var f=new FileReader();" +
            "f.onloadend=function(){var s=String(f.result);window.YAApp.saveFile(" +
            org.json.JSONObject.quote(name) + "," + org.json.JSONObject.quote(mime) +
            ",s.substring(s.indexOf(',')+1))};f.readAsDataURL(b)})})();"
    }

    /** رابط ساده برای همه‌ی برنامه‌ها: window.YA.speak / keepAwake / share / toast */
    private val apiHook = """
(function(){
 if(window.YA)return;
 window.YA={native:true,
  speak:function(t,l){window.YAApp.speak(String(t),l||'fa')},
  stop:function(){window.YAApp.stopSpeak()},
  keepAwake:function(b){window.YAApp.keepAwake(!!b)},
  toast:function(m){window.YAApp.toast(String(m))},
  share:function(t){window.YAApp.share(String(t))}};
})();
""".trimIndent()

    inner class Bridge {
        @JavascriptInterface
        fun speak(text: String, lang: String) {
            runOnUiThread {
                if (setTtsLang(lang)) {
                    tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ya")
                } else if (!ttsWarned) {
                    ttsWarned = true
                    Toast.makeText(this@MainActivity,
                        "صدای فارسی نصب نیست؛ در تنظیمات گوشی، تبدیل متن به گفتار، فارسی را نصب کنید",
                        Toast.LENGTH_LONG).show()
                }
            }
        }

        @JavascriptInterface
        fun stopSpeak() { runOnUiThread { tts?.stop() } }

        @JavascriptInterface
        fun keepAwake(on: Boolean) {
            runOnUiThread {
                if (on) window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }

        @JavascriptInterface
        fun toast(msg: String) {
            runOnUiThread { Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show() }
        }

        @JavascriptInterface
        fun share(text: String) {
            runOnUiThread {
                val i = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                }
                startActivity(Intent.createChooser(i, null))
            }
        }

        @JavascriptInterface
        fun saveFile(name: String, mime: String, b64: String) {
            val bytes = Base64.decode(b64, Base64.DEFAULT)
            runOnUiThread {
                pendingBytes = bytes
                saveLauncher.launch(name)
            }
        }

        @JavascriptInterface
        fun downloadAsset(name: String, url: String, token: String) {
            if (!url.startsWith("https://api.github.com/")) return
            runOnUiThread {
                pendingUrl = url
                pendingToken = token
                pendingCookie = ""
                downloadLauncher.launch(name)
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val webView = binding.webView
        webView.overScrollMode = View.OVER_SCROLL_NEVER

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = false
            allowContentAccess = true
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            cacheMode = WebSettings.LOAD_DEFAULT
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
        }

        webView.addJavascriptInterface(Bridge(), "YAApp")
        tts = TextToSpeech(this) { st -> if (st == TextToSpeech.SUCCESS) setTtsLang("fa") }

        val localHost = "appassets.androidplatform.net"
        val assetsHandler = WebViewAssetLoader.AssetsPathHandler(this)
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/") { path ->
                val p = if (path.isEmpty() || path.endsWith("/")) path + "index.html" else path
                assetsHandler.handle("www/" + p)
            }
            .build()

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val url = request.url
                val host = url.host ?: return false
                val isLoop = host == "127.0.0.1" || host == "localhost"
                val remotePort = try { Uri.parse(BuildConfig.REMOTE_URL).port } catch (e: Exception) { -1 }
                val allowed = host == localHost || BuildConfig.ALLOWED_DOMAINS.any { domain ->
                    domain.isNotBlank() && (host == domain || host.endsWith(".$domain")) &&
                        (!isLoop || url.port == remotePort)
                }
                return if (allowed) {
                    false
                } else {
                    startActivity(Intent(Intent.ACTION_VIEW, url))
                    true
                }
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                showContent()
                binding.progressBar.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                binding.progressBar.visibility = View.GONE
                view.evaluateJavascript(downloadHook, null)
                view.evaluateJavascript(apiHook, null)
            }

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: WebResourceError
            ) {
                super.onReceivedError(view, request, error)
                if (request.isForMainFrame) showError()
            }
        }

        webView.setDownloadListener { url, _, contentDisposition, mimetype, _ ->
            val fname = URLUtil.guessFileName(url, contentDisposition, mimetype)
            if (url.startsWith("blob:") || url.startsWith("data:")) {
                webView.evaluateJavascript(blobScript(url, fname, mimetype ?: "application/octet-stream"), null)
            } else if (url.startsWith("http")) {
                pendingUrl = url
                pendingToken = ""
                pendingCookie = CookieManager.getInstance().getCookie(url) ?: ""
                downloadLauncher.launch(fname)
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                fileChooserCallback?.onReceiveValue(null)
                fileChooserCallback = filePathCallback
                fileChooserLauncher.launch(arrayOf("*/*"))
                return true
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String,
                callback: GeolocationPermissions.Callback
            ) {
                val ok = ContextCompat.checkSelfPermission(
                    this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
                if (ok) {
                    callback.invoke(origin, true, false)
                } else {
                    geoCallback = callback
                    geoOrigin = origin
                    locLauncher.launch(arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    ))
                }
            }

            override fun onPermissionRequest(request: PermissionRequest) {
                val need = ArrayList<String>()
                for (r in request.resources) {
                    if (r == PermissionRequest.RESOURCE_VIDEO_CAPTURE) need.add(Manifest.permission.CAMERA)
                    if (r == PermissionRequest.RESOURCE_AUDIO_CAPTURE) need.add(Manifest.permission.RECORD_AUDIO)
                }
                val missing = need.filter {
                    ContextCompat.checkSelfPermission(this@MainActivity, it) != PackageManager.PERMISSION_GRANTED
                }
                if (need.isEmpty()) {
                    request.deny()
                } else if (missing.isEmpty()) {
                    request.grant(request.resources)
                } else {
                    permReq?.deny()
                    permReq = request
                    permLauncher.launch(missing.toTypedArray())
                }
            }

            override fun onProgressChanged(view: WebView, newProgress: Int) {
                super.onProgressChanged(view, newProgress)
                binding.progressBar.progress = newProgress
            }
        }

        binding.retryButton.setOnClickListener {
            showContent()
            webView.loadUrl(startUrl)
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        startUrl = if (BuildConfig.REMOTE_URL.isNotBlank()) {
            BuildConfig.REMOTE_URL
        } else {
            "https://$localHost/index.html"
        }
        webView.loadUrl(startUrl)
    }

    private fun showError() {
        val r = BuildConfig.REMOTE_URL
        if (r.startsWith("http://127.0.0.1") || r.startsWith("http://localhost")) {
            binding.errorTitle.text = "سرور روشن نیست"
            binding.errorMessage.text = "ترمکس را باز کنید، دستور ./start.sh را بزنید و بعد «Retry» را لمس کنید."
        }
        binding.progressBar.visibility = View.GONE
        binding.webView.visibility = View.GONE
        binding.errorView.visibility = View.VISIBLE
    }

    private fun showContent() {
        binding.errorView.visibility = View.GONE
        binding.webView.visibility = View.VISIBLE
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        binding.webView.apply {
            clearHistory()
            destroy()
        }
        super.onDestroy()
    }
}
