-keepattributes JavascriptInterface
-keep class com.html2apk.wrapper.MainActivity$Bridge { *; }
-keepclassmembers class com.html2apk.wrapper.MainActivity$Bridge {
    @android.webkit.JavascriptInterface <methods>;
}
