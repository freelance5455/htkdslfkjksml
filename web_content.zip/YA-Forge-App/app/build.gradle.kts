import java.io.FileInputStream
import java.io.InputStreamReader
import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// تنظیمات هر بیلد از generated-config.properties (ساخته‌شده توسط scripts/build.sh از config.json) خوانده می‌شود.
val appConfig = Properties().apply {
    val f = file("generated-config.properties")
    if (f.exists()) load(InputStreamReader(FileInputStream(f), Charsets.UTF_8))
}
fun cfg(key: String, default: String): String = appConfig.getProperty(key, default)
fun cfgBool(key: String, default: Boolean): Boolean = cfg(key, default.toString()).trim().lowercase() == "true"
fun jstr(v: String): String = v.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ").replace("\r", " ")
fun resStr(v: String): String {
    var s = v.replace("&", "&amp;").replace("<", "&lt;").replace("\\", "\\\\").replace("'", "\\'").replace("\"", "\\\"")
    if (s.startsWith("@") || s.startsWith("?")) s = "\\" + s
    return s
}

val cfgAppName = cfg("app_name", "App")
val cfgPackageId = cfg("package_id", "com.example.myapp")
val cfgVersionName = cfg("version_name", "1.0.0")
val cfgVersionCode = cfg("version_code", "1").toIntOrNull() ?: 1
val cfgPrimaryColor = cfg("primary_color", "#1E88E5")
val cfgPrimaryColorDark = cfg("primary_color_dark", "#1565C0")
val cfgRemoteUrl = cfg("remote_url", "")
val cfgAllowedDomains = cfg("allowed_domains", "")
val cfgPermissions = cfg("permissions", "").split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }.toSet()
val cfgOrientation = when (cfg("orientation", "auto")) {
    "portrait" -> "portrait"
    "landscape" -> "landscape"
    else -> "unspecified"
}

// مانیفست مکمل: دسترسی‌های اختیاری و دریافت فایل از «اشتراک‌گذاری» فقط وقتی در config فعال باشند اضافه می‌شوند.
run {
    val sb = StringBuilder()
    sb.append("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n")
    sb.append("<manifest xmlns:android=\"http://schemas.android.com/apk/res/android\">\n")
    if ("camera" in cfgPermissions) {
        sb.append("  <uses-permission android:name=\"android.permission.CAMERA\" />\n")
        sb.append("  <uses-feature android:name=\"android.hardware.camera\" android:required=\"false\" />\n")
    }
    if ("microphone" in cfgPermissions) {
        sb.append("  <uses-permission android:name=\"android.permission.RECORD_AUDIO\" />\n")
        sb.append("  <uses-permission android:name=\"android.permission.MODIFY_AUDIO_SETTINGS\" />\n")
        sb.append("  <uses-feature android:name=\"android.hardware.microphone\" android:required=\"false\" />\n")
    }
    if ("location" in cfgPermissions) {
        sb.append("  <uses-permission android:name=\"android.permission.ACCESS_FINE_LOCATION\" />\n")
        sb.append("  <uses-permission android:name=\"android.permission.ACCESS_COARSE_LOCATION\" />\n")
        sb.append("  <uses-feature android:name=\"android.hardware.location\" android:required=\"false\" />\n")
    }
    if ("vibrate" in cfgPermissions) sb.append("  <uses-permission android:name=\"android.permission.VIBRATE\" />\n")
    if (cfgBool("share_target", false)) {
        sb.append("  <application>\n    <activity android:name=\".MainActivity\">\n")
        sb.append("      <intent-filter>\n        <action android:name=\"android.intent.action.SEND\" />\n        <category android:name=\"android.intent.category.DEFAULT\" />\n")
        sb.append("        <data android:mimeType=\"application/zip\" />\n        <data android:mimeType=\"application/x-zip-compressed\" />\n        <data android:mimeType=\"text/html\" />\n      </intent-filter>\n")
        sb.append("      <intent-filter>\n        <action android:name=\"android.intent.action.VIEW\" />\n        <category android:name=\"android.intent.category.DEFAULT\" />\n        <category android:name=\"android.intent.category.BROWSABLE\" />\n")
        sb.append("        <data android:scheme=\"content\" />\n        <data android:mimeType=\"application/zip\" />\n        <data android:mimeType=\"application/x-zip-compressed\" />\n        <data android:mimeType=\"text/html\" />\n      </intent-filter>\n")
        sb.append("    </activity>\n  </application>\n")
    }
    sb.append("</manifest>\n")
    val f = file("src/overlay/AndroidManifest.xml")
    f.parentFile.mkdirs()
    f.writeText(sb.toString())
}

val keystoreProps = Properties().apply {
    val f = rootProject.file("keystore.properties")
    if (f.exists()) load(FileInputStream(f))
}
val hasReleaseSigning = keystoreProps.containsKey("storeFile")

android {
    namespace = "com.html2apk.wrapper"
    compileSdk = 36

    defaultConfig {
        applicationId = cfgPackageId
        minSdk = 24
        targetSdk = 36
        versionCode = cfgVersionCode
        versionName = cfgVersionName

        resValue("string", "app_name", resStr(cfgAppName))
        resValue("color", "brand_primary", cfgPrimaryColor)
        resValue("color", "brand_primary_dark", cfgPrimaryColorDark)

        manifestPlaceholders["allowBackup"] = cfgBool("allow_backup", false).toString()
        manifestPlaceholders["screenOrientation"] = cfgOrientation

        buildConfigField("String", "REMOTE_URL", "\"${jstr(cfgRemoteUrl)}\"")
        val domains = cfgAllowedDomains.split(",").map { it.trim() }.filter { it.isNotEmpty() }
            .joinToString(", ") { "\"${jstr(it)}\"" }
        buildConfigField("String[]", "ALLOWED_DOMAINS", "{ $domains }")
        buildConfigField("boolean", "EXTERNAL_IN_BROWSER", cfgBool("allow_external_links_in_browser", true).toString())
        buildConfigField("boolean", "FULLSCREEN", cfgBool("fullscreen", false).toString())
        buildConfigField("boolean", "KEEP_SCREEN_ON", cfgBool("keep_screen_on", false).toString())
        buildConfigField("boolean", "ALLOW_ZOOM", cfgBool("allow_zoom", false).toString())
        buildConfigField("boolean", "EXIT_CONFIRM", cfgBool("exit_confirm", true).toString())
        buildConfigField("boolean", "SHARE_TARGET", cfgBool("share_target", false).toString())
        buildConfigField("String", "PERMISSIONS", "\"${jstr(cfgPermissions.joinToString(","))}\"")
        buildConfigField("String", "USER_AGENT_SUFFIX", "\"${jstr(cfg("user_agent_suffix", ""))}\"")
    }

    signingConfigs {
        if (hasReleaseSigning) {
            create("release") {
                storeFile = rootProject.file(keystoreProps.getProperty("storeFile"))
                storePassword = keystoreProps.getProperty("storePassword")
                keyAlias = keystoreProps.getProperty("keyAlias")
                keyPassword = keystoreProps.getProperty("keyPassword")
            }
        }
    }

    sourceSets {
        getByName("debug").manifest.srcFile("src/overlay/AndroidManifest.xml")
        getByName("release").manifest.srcFile("src/overlay/AndroidManifest.xml")
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            if (hasReleaseSigning) signingConfig = signingConfigs.getByName("release")
        }
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }

    bundle {
        language { enableSplit = false }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.webkit:webkit:1.12.1")
}
