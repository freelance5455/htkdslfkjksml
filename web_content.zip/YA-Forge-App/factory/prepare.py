#!/usr/bin/env python3
"""YA Forge — آماده‌سازی یک بیلد: منبع وب، config.json، آیکون و کلید امضا."""
import json, os, pathlib, re, secrets, shutil, subprocess, sys, zipfile
from urllib.parse import urlparse

E = os.environ
FACTORY_VERSION = 3

def die(msg):
    print("::error::" + msg); sys.exit(1)

JAVA_KW = set("abstract assert boolean break byte case catch char class const continue default do double else enum extends final finally float for goto if implements import instanceof int interface long native new package private protected public return short static strictfp super switch synchronized this throw throws transient try void volatile while true false null".split())

if E.get("REPO_PRIVATE", "true") != "true":
    die("مخزن کارخانه باید خصوصی باشد؛ کلید امضا داخل آن ذخیره می‌شود.")

pid = E["PROJECT_ID"]
if not re.fullmatch(r"[A-Za-z0-9_-]{1,40}", pid): die("شناسه پروژه نامعتبر است")
src = pathlib.Path("projects") / pid
name = re.sub(r"[<>&\"'\\\r\n]", " ", E["APP_NAME"]).strip().lstrip("@?").strip()[:40]
pkg = E["PACKAGE_ID"].strip()
vn = E["VERSION_NAME"].strip()
color = E["PRIMARY_COLOR"].strip()
stype = E.get("SOURCE_TYPE", "html")
if not name: die("نام برنامه خالی است")
if len(pkg) > 100 or not re.fullmatch(r"[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+", pkg): die("شناسه بسته نامعتبر است: " + pkg)
if any(seg in JAVA_KW for seg in pkg.split(".")): die("شناسه بسته نباید کلمه‌ی رزروشده‌ی جاوا داشته باشد: " + pkg)
if not re.fullmatch(r"[0-9A-Za-z._-]{1,20}", vn): die("نام نسخه نامعتبر است")
if not re.fullmatch(r"#[0-9A-Fa-f]{6}", color): die("رنگ نامعتبر است")
if stype not in ("zip", "html", "url"): die("نوع منبع نامعتبر است")
try: vc = int(E["VERSION_CODE"]); assert 0 < vc < 2100000000
except Exception: die("شماره نسخه نامعتبر است")
try: opt = json.loads(E.get("OPTIONS") or "{}"); assert isinstance(opt, dict)
except Exception: die("گزینه‌های ساخت نامعتبر است")

def flag(k, d=False): return bool(opt.get(k, d))
orientation = opt.get("orientation", "auto")
if orientation not in ("auto", "portrait", "landscape"): orientation = "auto"
perms = [p for p in opt.get("permissions", []) if p in ("camera", "microphone", "location", "vibrate")]
domains = [d.strip().lower() for d in opt.get("allowed_domains", []) if re.fullmatch(r"[a-z0-9.-]{3,100}", str(d).strip().lower())]
ua = re.sub(r"[^A-Za-z0-9 ._/-]", "", str(opt.get("user_agent_suffix", "")))[:40]

# ---- منبع وب ----
www = pathlib.Path("www_source")
shutil.rmtree(www, ignore_errors=True); www.mkdir()
remote = ""
if stype == "zip":
    z = src / "site.zip"
    if not z.exists(): die("فایل site.zip در مخزن نیست")
    total = 0
    with zipfile.ZipFile(z) as zf:
        infos = zf.infolist()
        if len(infos) > 20000: die("تعداد فایل‌های ZIP بیش از حد است")
        for m in infos:
            p = pathlib.PurePosixPath(m.filename.replace("\\", "/"))
            if p.is_absolute() or ".." in p.parts or (p.parts and re.match(r"^[A-Za-z]:", p.parts[0])): die("مسیر نامعتبر داخل ZIP")
            total += m.file_size
        if total > 400 * 1048576: die("حجم باز‌شده‌ی ZIP بیش از ۴۰۰ مگابایت است")
        for m in infos:
            if m.filename.startswith("__MACOSX/") or m.filename.endswith(".DS_Store"): continue
            zf.extract(m, www)
    if not (www / "index.html").exists():
        found = sorted(www.rglob("index.html"), key=lambda p: len(p.parts))
        if not found: die("index.html داخل ZIP پیدا نشد")
        tmp = pathlib.Path("www_tmp"); shutil.rmtree(tmp, ignore_errors=True)
        shutil.move(str(found[0].parent), str(tmp)); shutil.rmtree(www); shutil.move(str(tmp), str(www))
elif stype == "html":
    h = src / "index.html"
    if not h.exists(): die("فایل index.html در مخزن نیست")
    t = h.read_text(encoding="utf-8", errors="replace")
    if not re.search(r"<meta[^>]+name=[\"']viewport", t, re.I):
        vp = '<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">'
        if re.search(r"<head[^>]*>", t, re.I): t = re.sub(r"(<head[^>]*>)", r"\1" + vp, t, count=1, flags=re.I)
        else: t = vp + t
        print("viewport meta added")
    (www / "index.html").write_text(t, encoding="utf-8")
else:
    remote = str(opt.get("remote_url", "")).strip()
    u = urlparse(remote)
    if u.scheme != "https" or not u.hostname: die("آدرس سایت باید با https شروع شود")
    if re.search(r"[\"\\\s]", remote): die("آدرس سایت نامعتبر است")
    domains = sorted(set(domains + [u.hostname.lower()]))
    (www / "index.html").write_text('<!doctype html><meta charset="utf-8"><title>%s</title><body>…</body>' % name, encoding="utf-8")
print("web files:", sum(1 for p in www.rglob("*") if p.is_file()))

# ---- تنظیمات ----
def darker(c, f=0.8):
    return "#%02X%02X%02X" % tuple(int(int(c[i:i + 2], 16) * f) for i in (1, 3, 5))
json.dump({"app_name": name, "package_id": pkg, "version_name": vn, "version_code": vc,
           "primary_color": color, "primary_color_dark": darker(color), "www_source": "www_source",
           "remote_url": remote, "allow_external_links_in_browser": flag("external_links", True), "allowed_domains": domains,
           "orientation": orientation, "fullscreen": flag("fullscreen"), "keep_screen_on": flag("keep_screen_on"),
           "allow_zoom": flag("allow_zoom"), "allow_backup": flag("allow_backup"), "exit_confirm": flag("exit_confirm", True),
           "share_target": False, "permissions": perms, "user_agent_suffix": ua},
          open("config.json", "w", encoding="utf-8"), ensure_ascii=False, indent=2)
safe = re.sub(r"[^a-z0-9]+", "-", pkg.split(".")[-1]).strip("-") or "app"
json.dump({"name": name, "safe": safe, "vn": vn, "pkg": pkg, "vc": vc, "type": stype}, open("build_meta.json", "w", encoding="utf-8"), ensure_ascii=False)

# ---- آیکون سفارشی (آیکون تطبیقی با حاشیه‌ی امن) ----
icon = src / "icon.png"
if E.get("HAS_ICON") == "true" and icon.exists():
    from PIL import Image
    im = Image.open(icon).convert("RGBA")
    shutil.copy(icon, "custom_icon.png")
    res = pathlib.Path("app/src/main/res")
    for d, px in {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}.items():
        o = res / ("mipmap-" + d); o.mkdir(parents=True, exist_ok=True)
        r = im.resize((px, px), Image.LANCZOS)
        r.save(o / "ic_launcher.png"); r.save(o / "ic_launcher_round.png")
    # پس‌زمینه: اگر تصویر مات است از رنگ گوشه‌ها، وگرنه رنگ برند
    w, h2 = im.size
    corners = [im.getpixel(p) for p in ((0, 0), (w - 1, 0), (0, h2 - 1), (w - 1, h2 - 1))]
    if all(c[3] > 250 for c in corners):
        bg = "#%02X%02X%02X" % tuple(sum(c[i] for c in corners) // 4 for i in range(3))
    else:
        bg = color
    canvas = Image.new("RGBA", (432, 432), (0, 0, 0, 0))
    canvas.paste(im.resize((288, 288), Image.LANCZOS), (72, 72))
    nd = res / "drawable-nodpi"; nd.mkdir(exist_ok=True)
    canvas.save(nd / "ic_launcher_foreground.png")
    (res / "drawable" / "ic_launcher_foreground.xml").unlink(missing_ok=True)
    (res / "values" / "ic_launcher_bg.xml").write_text('<?xml version="1.0" encoding="utf-8"?>\n<resources><color name="ic_launcher_background">%s</color></resources>\n' % bg, encoding="utf-8")
    (res / "mipmap-anydpi-v26" / "ic_launcher.xml").write_text('<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n  <background android:drawable="@color/ic_launcher_background"/>\n  <foreground android:drawable="@drawable/ic_launcher_foreground"/>\n</adaptive-icon>\n', encoding="utf-8")
    print("custom icon applied, background", bg)

# ---- کلید امضا (برای هر package یک کلید ثابت؛ می‌تواند از اپ وارد شده باشد) ----
keys = pathlib.Path("keys"); keys.mkdir(exist_ok=True)
jks, prop = keys / (pkg + ".jks"), keys / (pkg + ".properties")
if not (jks.exists() and prop.exists()):
    pw = secrets.token_urlsafe(18)
    subprocess.check_call(["keytool", "-genkeypair", "-keystore", str(jks), "-alias", "release", "-keyalg", "RSA",
                           "-keysize", "2048", "-validity", "10000", "-storepass", pw, "-keypass", pw,
                           "-dname", "CN=" + pkg + ", O=YA Forge"])
    prop.write_text("storePassword=%s\nkeyPassword=%s\nkeyAlias=release\n" % (pw, pw), encoding="utf-8")
    print("new signing key created")
else:
    print("existing signing key reused")
kp = dict(l.split("=", 1) for l in prop.read_text(encoding="utf-8").splitlines() if "=" in l)
chk = subprocess.run(["keytool", "-list", "-keystore", str(jks), "-storepass", kp["storePassword"], "-alias", kp["keyAlias"]], capture_output=True, text=True)
if chk.returncode != 0: die("کلید امضا یا رمز آن درست نیست (alias/رمز را بررسی کن): " + chk.stdout[-200:] + chk.stderr[-200:])
shutil.copy(jks, "release.keystore")
pathlib.Path("keystore.properties").write_text(
    "storeFile=release.keystore\nstorePassword=%s\nkeyAlias=%s\nkeyPassword=%s\n" % (kp["storePassword"], kp["keyAlias"], kp["keyPassword"]),
    encoding="utf-8")
