#!/usr/bin/env python3
"""YA Forge — آماده‌سازی یک بیلد: منبع وب، config.json، آیکون و کلید امضا."""
import json, os, pathlib, re, secrets, shutil, subprocess, sys, zipfile

E = os.environ
def die(msg):
    print("::error::" + msg); sys.exit(1)

pid = E["PROJECT_ID"]
if not re.fullmatch(r"[A-Za-z0-9_-]{1,40}", pid): die("شناسه پروژه نامعتبر است")
src = pathlib.Path("projects") / pid
name = re.sub(r"[<>&\"'\\\r\n]", " ", E["APP_NAME"]).strip()[:40]
pkg = E["PACKAGE_ID"].strip()
vn = E["VERSION_NAME"].strip()
color = E["PRIMARY_COLOR"].strip()
if not name: die("نام برنامه خالی است")
if not re.fullmatch(r"[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+", pkg): die("شناسه بسته نامعتبر است: " + pkg)
if not re.fullmatch(r"[0-9A-Za-z._-]{1,20}", vn): die("نام نسخه نامعتبر است")
if not re.fullmatch(r"#[0-9A-Fa-f]{6}", color): die("رنگ نامعتبر است")
try: vc = int(E["VERSION_CODE"]); assert vc > 0
except Exception: die("شماره نسخه نامعتبر است")

# ---- منبع وب ----
www = pathlib.Path("www_source")
shutil.rmtree(www, ignore_errors=True); www.mkdir()
if E["SOURCE_TYPE"] == "zip":
    z = src / "site.zip"
    if not z.exists(): die("فایل site.zip در مخزن نیست")
    with zipfile.ZipFile(z) as zf:
        for m in zf.namelist():
            p = pathlib.PurePosixPath(m)
            if p.is_absolute() or ".." in p.parts: die("مسیر نامعتبر داخل ZIP")
        zf.extractall(www)
    if not (www / "index.html").exists():
        found = sorted(www.rglob("index.html"), key=lambda p: len(p.parts))
        if not found: die("index.html داخل ZIP پیدا نشد")
        tmp = pathlib.Path("www_tmp"); shutil.rmtree(tmp, ignore_errors=True)
        shutil.move(str(found[0].parent), str(tmp)); shutil.rmtree(www); shutil.move(str(tmp), str(www))
else:
    h = src / "index.html"
    if not h.exists(): die("فایل index.html در مخزن نیست")
    shutil.copy(h, www / "index.html")
print("web files:", sum(1 for p in www.rglob("*") if p.is_file()))

# ---- تنظیمات ----
def darker(c, f=0.8):
    return "#%02X%02X%02X" % tuple(int(int(c[i:i + 2], 16) * f) for i in (1, 3, 5))
json.dump({"app_name": name, "package_id": pkg, "version_name": vn, "version_code": vc,
           "primary_color": color, "primary_color_dark": darker(color), "www_source": "www_source",
           "remote_url": "", "allow_external_links_in_browser": True, "allowed_domains": []},
          open("config.json", "w", encoding="utf-8"), ensure_ascii=False, indent=2)
safe = re.sub(r"[^a-z0-9]+", "-", pkg.split(".")[-1]).strip("-") or "app"
json.dump({"name": name, "safe": safe, "vn": vn, "pkg": pkg}, open("build_meta.json", "w", encoding="utf-8"), ensure_ascii=False)

# ---- آیکون سفارشی ----
icon = src / "icon.png"
if E.get("HAS_ICON") == "true" and icon.exists():
    from PIL import Image
    im = Image.open(icon).convert("RGBA")
    shutil.copy(icon, "custom_icon.png")
    res = pathlib.Path("app/src/main/res")
    for d, px in {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}.items():
        o = res / ("mipmap-" + d); o.mkdir(parents=True, exist_ok=True)
        r = im.resize((px, px), Image.LANCZOS)
        r.save(o / "ic_launcher.png"); r.save(o / "ic_launcher_round.png")
    shutil.rmtree(res / "mipmap-anydpi-v26", ignore_errors=True)
    (res / "drawable" / "ic_launcher_foreground.xml").unlink(missing_ok=True)
    nd = res / "drawable-nodpi"; nd.mkdir(exist_ok=True)
    im.resize((432, 432), Image.LANCZOS).save(nd / "ic_launcher_foreground.png")
    print("custom icon applied")

# ---- کلید امضا (برای هر package یک کلید ثابت) ----
keys = pathlib.Path("keys"); keys.mkdir(exist_ok=True)
jks, prop = keys / (pkg + ".jks"), keys / (pkg + ".properties")
if not (jks.exists() and prop.exists()):
    pw = secrets.token_urlsafe(18)
    subprocess.check_call(["keytool", "-genkeypair", "-keystore", str(jks), "-alias", "release", "-keyalg", "RSA",
                           "-keysize", "2048", "-validity", "10000", "-storepass", pw, "-keypass", pw,
                           "-dname", "CN=" + pkg + ", O=YA Forge"])
    prop.write_text("storePassword=%s\nkeyPassword=%s\nkeyAlias=release\n" % (pw, pw), encoding="utf-8")
    print("new signing key created")
else:
    print("existing signing key reused")
kp = dict(l.split("=", 1) for l in prop.read_text(encoding="utf-8").splitlines() if "=" in l)
shutil.copy(jks, "release.keystore")
pathlib.Path("keystore.properties").write_text(
    "storeFile=release.keystore\nstorePassword=%s\nkeyAlias=%s\nkeyPassword=%s\n" % (kp["storePassword"], kp["keyAlias"], kp["keyPassword"]),
    encoding="utf-8")
