#!/usr/bin/env python3
"""YA Forge — انتشار APK/AAB امضاشده در Releases."""
import glob, json, os, shutil, subprocess, sys

m = json.load(open("build_meta.json", encoding="utf-8"))
fm = os.environ.get("FORMATS", "both"); bid = os.environ["BUILD_ID"]
os.makedirs("out", exist_ok=True); files = []

def pick(pattern, ext):
    c = [f for f in sorted(glob.glob(pattern)) if "unsigned" not in f]
    if not c:
        print("::error::خروجی امضاشده برای %s پیدا نشد" % ext); sys.exit(1)
    dst = "out/%s-v%s.%s" % (m["safe"], m["vn"], ext)
    shutil.copy(c[0], dst); files.append(dst)

if fm in ("both", "apk"): pick("dist/*release*.apk", "apk")
if fm in ("both", "aab"): pick("dist/*release*.aab", "aab")
for f in files:
    if f.endswith(".apk"):
        subprocess.call("keytool -printcert -jarfile '%s' | grep -E 'Owner|SHA256'" % f, shell=True)
subprocess.check_call(["gh", "release", "create", "b-" + bid] + files +
                      ["--title", "%s v%s" % (m["name"], m["vn"]), "--notes", "YA Forge · " + m["pkg"]])
