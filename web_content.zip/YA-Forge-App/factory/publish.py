#!/usr/bin/env python3
"""YA Forge — بررسی امضا و انتشار APK/AAB در Releases همراه اثر انگشت و چک‌سام."""
import glob, hashlib, json, os, re, shutil, subprocess, sys

m = json.load(open("build_meta.json", encoding="utf-8"))
fm = os.environ.get("FORMATS", "both"); bid = os.environ["BUILD_ID"]
os.makedirs("out", exist_ok=True); files = []

def pick(pattern, ext):
    c = [f for f in sorted(glob.glob(pattern)) if "unsigned" not in f]
    if not c:
        print("::error::خروجی امضاشده برای %s پیدا نشد" % ext); sys.exit(1)
    dst = "out/%s-v%s.%s" % (m["safe"], m["vn"], ext)
    shutil.copy(c[0], dst); files.append(dst)

if fm in ("both", "apk"): pick("dist/*release*.apk", "apk")
if fm in ("both", "aab"): pick("dist/*release*.aab", "aab")

def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""): h.update(b)
    return h.hexdigest()

notes = ["**%s** · نسخه %s (%s)" % (m["name"], m["vn"], m.get("vc", "")), "", "شناسه بسته: `%s`" % m["pkg"], ""]
for f in files:
    notes.append("- `%s` — %.1f MB — SHA-256: `%s`" % (os.path.basename(f), os.path.getsize(f) / 1048576, sha256(f)))
    if f.endswith(".aab"):
        r = subprocess.run(["jarsigner", "-verify", f], capture_output=True, text=True)
        if "jar verified" not in (r.stdout + r.stderr):
            print("::error::امضای AAB تأیید نشد"); sys.exit(1)
        print("AAB signature verified")
    else:
        r = subprocess.run(["keytool", "-printcert", "-jarfile", f], capture_output=True, text=True)
        print(r.stdout)
        fp = re.search(r"SHA256:\s*([0-9A-F:]+)", r.stdout)
        if fp: notes += ["", "اثر انگشت گواهی (SHA-256): `%s`" % fp.group(1)]
body = "\n".join(notes) + "\n\nAPK: نصب مستقیم · AAB: بارگذاری در Google Play"
open("release_notes.md", "w", encoding="utf-8").write(body)
if os.environ.get("GITHUB_STEP_SUMMARY"):
    open(os.environ["GITHUB_STEP_SUMMARY"], "a", encoding="utf-8").write(body + "\n")
subprocess.check_call(["gh", "release", "create", "b-" + bid] + files +
                      ["--title", "%s v%s" % (m["name"], m["vn"]), "--notes-file", "release_notes.md"])
