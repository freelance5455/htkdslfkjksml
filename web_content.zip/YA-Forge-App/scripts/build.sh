#!/usr/bin/env bash
# ========================================================================
# build.sh — ساخت APK و AAB امضاشده از روی config.json
#
# استفاده:
#   ./scripts/build.sh                 # APK دیباگ + APK/AAB ریلیز (امضاشده)
#   ./scripts/build.sh --debug-only    # فقط APK دیباگ (سریع‌تر، برای تست)
#   ./scripts/build.sh --no-debug --formats apk|aab|both   # فقط ریلیز (کارخانه از این استفاده می‌کند)
#   GRADLE_BIN=/path/to/gradle ./scripts/build.sh   # استفاده از Gradle خاص
#
# ورودی: config.json (برندینگ) + پوشهٔ www_source (فایل‌های HTML/CSS/JS)
# خروجی: پوشهٔ dist/ شامل APK و AAB نهایی
# ========================================================================
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_ROOT"

CONFIG_FILE="$PROJECT_ROOT/config.json"
DEBUG_ONLY=false
NO_DEBUG=false
FORMATS=both
while [[ $# -gt 0 ]]; do
    case "$1" in
        --debug-only) DEBUG_ONLY=true ;;
        --no-debug) NO_DEBUG=true ;;
        --formats) FORMATS="${2:-both}"; shift ;;
    esac
    shift
done

if [[ ! -f "$CONFIG_FILE" ]]; then
    echo "❌ فایل config.json پیدا نشد در: $CONFIG_FILE"
    exit 1
fi

if ! command -v python3 >/dev/null 2>&1; then
    echo "❌ python3 لازم است (برای خواندن config.json) و پیدا نشد."
    echo "   نصب: pkg install python   (ترموکس)   یا   apt install python3  (proot/Ubuntu)"
    exit 1
fi

echo "📋 در حال خواندن config.json ..."

# ---- ۱. تبدیل config.json به یک فایل properties ساده برای Gradle ----
python3 - "$CONFIG_FILE" "$PROJECT_ROOT/app/generated-config.properties" << 'PYEOF'
import json, sys

config_path, out_path = sys.argv[1], sys.argv[2]
with open(config_path, encoding="utf-8") as f:
    cfg = json.load(f)

def esc(v):
    return str(v).replace("\\", "\\\\").replace("\n", " ")

def lst(v):
    return ",".join(v) if isinstance(v, list) else str(v)

def b(v, d):
    return "true" if cfg.get(v, d) in (True, "true", "True", 1) else "false"

lines = [
    f"app_name={esc(cfg.get('app_name', 'App'))}",
    f"package_id={esc(cfg.get('package_id', 'com.example.myapp'))}",
    f"version_name={esc(cfg.get('version_name', '1.0.0'))}",
    f"version_code={esc(cfg.get('version_code', 1))}",
    f"primary_color={esc(cfg.get('primary_color', '#1E88E5'))}",
    f"primary_color_dark={esc(cfg.get('primary_color_dark', '#1565C0'))}",
    f"remote_url={esc(cfg.get('remote_url', ''))}",
    f"allowed_domains={esc(lst(cfg.get('allowed_domains', [])))}",
    f"allow_external_links_in_browser={b('allow_external_links_in_browser', True)}",
    f"orientation={esc(cfg.get('orientation', 'auto'))}",
    f"fullscreen={b('fullscreen', False)}",
    f"keep_screen_on={b('keep_screen_on', False)}",
    f"allow_zoom={b('allow_zoom', False)}",
    f"allow_backup={b('allow_backup', False)}",
    f"exit_confirm={b('exit_confirm', True)}",
    f"share_target={b('share_target', False)}",
    f"permissions={esc(lst(cfg.get('permissions', [])))}",
    f"user_agent_suffix={esc(cfg.get('user_agent_suffix', ''))}",
]
with open(out_path, "w", encoding="utf-8") as f:
    f.write("\n".join(lines) + "\n")

print(f"  app_name       = {cfg.get('app_name')}")
print(f"  package_id     = {cfg.get('package_id')}")
print(f"  version        = {cfg.get('version_name')} ({cfg.get('version_code')})")
print(f"  www_source     = {cfg.get('www_source', '(تنظیم نشده)')}")
PYEOF

# ---- ۱.۵. قالب کارخانه (template.json) برای خود اپ؛ در قالب کارخانه این اسکریپت وجود ندارد ----
if [[ -f "$PROJECT_ROOT/scripts/pack_template.py" ]]; then
    python3 "$PROJECT_ROOT/scripts/pack_template.py"
fi

# ---- ۲. کپی محتوای وب به assets/www ----
WWW_SOURCE=$(python3 -c "import json;print(json.load(open('$CONFIG_FILE',encoding='utf-8')).get('www_source','web-example'))")
WWW_SOURCE_PATH="$PROJECT_ROOT/$WWW_SOURCE"

if [[ ! -d "$WWW_SOURCE_PATH" ]]; then
    echo "❌ پوشهٔ www_source پیدا نشد: $WWW_SOURCE_PATH"
    echo "   این مقدار را در config.json درست کنید یا پوشه را بسازید."
    exit 1
fi

echo "📁 کپی محتوای وب از '$WWW_SOURCE' به app/src/main/assets/www ..."
rm -rf "$PROJECT_ROOT/app/src/main/assets/www"
mkdir -p "$PROJECT_ROOT/app/src/main/assets/www"
cp -r "$WWW_SOURCE_PATH"/. "$PROJECT_ROOT/app/src/main/assets/www/"

if [[ ! -f "$PROJECT_ROOT/app/src/main/assets/www/index.html" ]]; then
    echo "⚠️  هشدار: index.html در ریشهٔ '$WWW_SOURCE' پیدا نشد — اپ هنگام اجرا صفحهٔ سفید نشان می‌دهد."
fi

# ---- ۲.۵. ساخت آیکون‌های راستری برای اندروید زیر ۸ (API<26) با رنگ برند ----
PRIMARY_COLOR=$(python3 -c "import json;print(json.load(open('$CONFIG_FILE',encoding='utf-8')).get('primary_color','#1E88E5'))")
PRIMARY_COLOR_DARK=$(python3 -c "import json;print(json.load(open('$CONFIG_FILE',encoding='utf-8')).get('primary_color_dark','#1565C0'))")
python3 "$PROJECT_ROOT/scripts/generate_icons.py" "$PROJECT_ROOT/app/src/main/res" "$PRIMARY_COLOR" "$PRIMARY_COLOR_DARK"

# ---- ۳. ساخت کی‌استور (اگر نبود) ----
"$PROJECT_ROOT/scripts/gen_keystore.sh"

# ---- ۴. انتخاب باینری Gradle ----
# این پروژه عمداً Gradle Wrapper ندارد (در محیط ساخت من دسترسی به
# services.gradle.org مسدود بود، پس نتوانستم یک wrapper واقعی و تست‌شده
# تحویل بدهم). به‌جایش، یک نسخهٔ Gradle سازگار (۸.9 تا ۸.13، نه ۹.x) را خودتان
# نصب کنید و مسیرش را با GRADLE_BIN بدهید — مثلاً اگر از TERMUX_SETUP.md
# پیروی کرده باشید:
#   GRADLE_BIN=$HOME/tools/gradle-8.13/bin/gradle ./scripts/build.sh
GRADLE_BIN="${GRADLE_BIN:-gradle}"
if [[ "$GRADLE_BIN" == "gradle" ]]; then
    echo "⚠️  GRADLE_BIN تنظیم نشده؛ از 'gradle' موجود در PATH استفاده می‌شود."
    echo "   اگر این نسخهٔ Gradle 9.x است، بیلد با خطای ناسازگاری AGP شکست می‌خورد."
    echo "   برای رفع: GRADLE_BIN=/path/to/gradle-8.13/bin/gradle ./scripts/build.sh"
fi
echo "🔧 استفاده از Gradle: $GRADLE_BIN ($($GRADLE_BIN -v 2>/dev/null | grep '^Gradle ' || echo 'نسخه نامشخص'))"

# ---- ۵. بیلد (یک بار اجرای Gradle برای همهٔ خروجی‌ها؛ سریع‌تر) ----
rm -rf "$PROJECT_ROOT/dist"
mkdir -p "$PROJECT_ROOT/dist"

TASKS=()
if [[ "$DEBUG_ONLY" == true ]]; then
    TASKS+=(":app:assembleDebug")
else
    [[ "$NO_DEBUG" == false ]] && TASKS+=(":app:assembleDebug")
    [[ "$FORMATS" == "both" || "$FORMATS" == "apk" ]] && TASKS+=(":app:assembleRelease")
    [[ "$FORMATS" == "both" || "$FORMATS" == "aab" ]] && TASKS+=(":app:bundleRelease")
fi
if [[ ${#TASKS[@]} -eq 0 ]]; then
    echo "❌ هیچ خروجی‌ای انتخاب نشده (--formats باید apk یا aab یا both باشد)"
    exit 1
fi

echo "🔨 ساخت: ${TASKS[*]}"
"$GRADLE_BIN" --no-daemon --stacktrace "${TASKS[@]}"

cp "$PROJECT_ROOT"/app/build/outputs/apk/debug/*.apk "$PROJECT_ROOT/dist/" 2>/dev/null || true
cp "$PROJECT_ROOT"/app/build/outputs/apk/release/*.apk "$PROJECT_ROOT/dist/" 2>/dev/null || true
cp "$PROJECT_ROOT"/app/build/outputs/bundle/release/*.aab "$PROJECT_ROOT/dist/" 2>/dev/null || true

echo ""
echo "✅ تمام شد. خروجی‌ها در پوشهٔ dist/:"
ls -la "$PROJECT_ROOT/dist/"
