#!/usr/bin/env python3
"""
generate_icons.py — ساخت آیکون‌های راستری (PNG) برای اندروید نسخه‌های قدیمی‌تر
(زیر API 26) که از adaptive icon (XML برداری) پشتیبانی نمی‌کنند.

برای اندروید ۸ به بالا، همان آیکون برداری در mipmap-anydpi-v26/ic_launcher.xml
کافی است و این اسکریپت کاری با آن ندارد. این فقط یک نسخهٔ راستری سازگار با
همان رنگ برند (از config.json) برای mipmap-mdpi تا mipmap-xxxhdpi می‌سازد تا
روی اندروید ۷ و ۷.۱ هم آیکون درست نمایش داده شود، نه آیکون پیش‌فرض اندروید.

استفاده: python3 generate_icons.py <res_dir> <primary_color_hex> <primary_color_dark_hex>
مثال:   python3 generate_icons.py app/src/main/res "#1E88E5" "#1565C0"
"""
import sys
import os
import math

try:
    from PIL import Image, ImageDraw
except ImportError:
    print("⚠️  Pillow نصب نیست؛ از آیکون‌های راستری موجود (یا پیش‌فرض) صرف‌نظر می‌شود.")
    print("   نصب با: pip install Pillow  (یا در ترموکس: pkg install python-pillow)")
    sys.exit(0)  # این یک خطای مرگبار نیست؛ بیلد می‌تواند بدون آن ادامه یابد

DENSITIES = {
    "mdpi": 48,
    "hdpi": 72,
    "xhdpi": 96,
    "xxhdpi": 144,
    "xxxhdpi": 192,
}


def hex_to_rgb(h):
    h = h.lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def draw_glyph(draw, size, color):
    """حروف YA (طلایی) با همان مختصات آیکون برداری (بوم ۱۰۸×۱۰۸)."""
    k = size / 108.0
    w = max(2, round(7 * k))
    def line(pts):
        P = [(x * k, y * k) for x, y in pts]
        draw.line(P, fill=color, width=w, joint="curve")
        for x, y in P:
            draw.ellipse([x - w / 2, y - w / 2, x + w / 2, y + w / 2], fill=color)
    line([(31, 38), (41, 54), (51, 38)])
    line([(41, 54), (41, 72)])
    line([(57, 72), (67, 38), (77, 72)])
    line([(61.5, 61), (72.5, 61)])


def make_icon(size, bg_rgb, fg_rgb=(226, 182, 75)):
    scale = 4  # سوپرسمپل برای لبه‌های صاف‌تر
    big = size * scale
    img = Image.new("RGBA", (big, big), bg_rgb + (255,))
    draw = ImageDraw.Draw(img)
    draw_glyph(draw, big, fg_rgb + (255,))
    img = img.resize((size, size), Image.LANCZOS)
    return img


def main():
    if os.path.exists("custom_icon.png"):
        print("custom icon found; skipping default icon generation")
        return
    if len(sys.argv) < 4:
        print("استفاده: generate_icons.py <res_dir> <primary_color_hex> <primary_color_dark_hex>")
        sys.exit(1)

    res_dir = sys.argv[1]
    primary = hex_to_rgb(sys.argv[2])

    for density, size in DENSITIES.items():
        out_dir = os.path.join(res_dir, f"mipmap-{density}")
        os.makedirs(out_dir, exist_ok=True)
        icon = make_icon(size, primary)
        icon.save(os.path.join(out_dir, "ic_launcher.png"))
        icon.save(os.path.join(out_dir, "ic_launcher_round.png"))

    print(f"✅ آیکون‌های راستری (API<26) با رنگ {sys.argv[2]} ساخته شدند.")


if __name__ == "__main__":
    main()
