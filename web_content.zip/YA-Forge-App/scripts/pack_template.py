#!/usr/bin/env python3
"""بسته‌بندی قالب اندروید (کارخانه) داخل www_source/template.json تا خود اپ بتواند آن را روی GitHub کاربر بگذارد."""
import base64, json, pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
EXC_DIRS = {".git", "www_source", "dist", "build", ".gradle", "factory", ".idea", "__pycache__"}
EXC_FILES = {"config.json", "keystore.properties", "release.keystore", ".gitignore", "scripts/pack_template.py",
             "app/generated-config.properties"}
EXC_PREFIX = ("app/src/main/assets/www", ".github/workflows/build.yml", "README")
files = {}
for p in sorted(ROOT.rglob("*")):
    if not p.is_file(): continue
    rel = p.relative_to(ROOT).as_posix()
    if set(p.relative_to(ROOT).parts) & EXC_DIRS: continue
    if rel in EXC_FILES or rel.startswith(EXC_PREFIX) or rel.endswith((".jks", ".keystore", ".pyc")): continue
    raw = p.read_bytes()
    try: files[rel] = {"e": "u", "d": raw.decode("utf-8")}
    except UnicodeDecodeError: files[rel] = {"e": "b", "d": base64.b64encode(raw).decode()}
F = ROOT / "factory"
files[".github/workflows/factory.yml"] = {"e": "u", "d": (F / "factory.yml").read_text(encoding="utf-8")}
files["scripts/prepare.py"] = {"e": "u", "d": (F / "prepare.py").read_text(encoding="utf-8")}
files["scripts/publish.py"] = {"e": "u", "d": (F / "publish.py").read_text(encoding="utf-8")}
files[".gitignore"] = {"e": "u", "d": (F / "gitignore").read_text(encoding="utf-8")}
out = ROOT / "www_source" / "template.json"
json.dump({"files": files}, open(out, "w", encoding="utf-8"), ensure_ascii=False, separators=(",", ":"))
print("template files:", len(files), "size:", out.stat().st_size)
