(function(){
'use strict';
var $=function(s){return document.querySelector(s)};
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function sleep(ms){return new Promise(function(r){setTimeout(r,ms)})}
function fa(n){return String(n).replace(/\d/g,function(d){return '۰۱۲۳۴۵۶۷۸۹'[d]})}
var enc=new TextEncoder();
var TPL_VERSION=3;
var KW='abstract assert boolean break byte case catch char class const continue default do double else enum extends final finally float for goto if implements import instanceof int interface long native new package private protected public return short static strictfp super switch synchronized this throw throws transient try void volatile while true false null'.split(' ');

/* ---------- وضعیت ---------- */
var S;try{S=JSON.parse(localStorage.getItem('yf')||'{}')}catch(e){S={}}
S.projects=S.projects||{};S.builds=S.builds||[];
function save(){try{localStorage.setItem('yf',JSON.stringify(S))}catch(e){}}
var PEND={},PICON={},TM=null,REL=[];
function toast(m){var e=$('#toast');e.textContent=m;e.className='show';clearTimeout(toast.t);toast.t=setTimeout(function(){e.className=''},3400)}
function b64(u8){var s='';for(var i=0;i<u8.length;i+=32768)s+=String.fromCharCode.apply(null,u8.subarray(i,i+32768));return btoa(s)}
function readBuf(f){return new Promise(function(res,rej){var r=new FileReader();r.onload=function(){res(new Uint8Array(r.result))};r.onerror=function(){rej(new Error('خواندن فایل ممکن نشد'))};r.readAsArrayBuffer(f)})}
function saveOut(name,u8,mime){
 if(window.YAApp&&window.YAApp.saveFile){window.YAApp.saveFile(name,mime||'application/octet-stream',b64(u8))}
 else{var a=document.createElement('a');a.href=URL.createObjectURL(new Blob([u8]));a.download=name;document.body.appendChild(a);a.click()}}

/* ---------- پنجره‌ها ---------- */
function closeModal(){var m=$('#modal');if(m.classList.contains('hidden'))return false;m.classList.add('hidden');m.innerHTML='';return true}
window.__yaBack=function(){return closeModal()};
function ask(title,msg,ok,danger){return new Promise(function(res){
 var m=$('#modal');m.innerHTML='<div class="box fade"><h2>'+esc(title)+'</h2><p class="m">'+esc(msg)+'</p><button class="w'+(danger?' d':'')+'" id="mk">'+esc(ok||'تأیید')+'</button><button class="w s" id="mc">انصراف</button></div>';
 m.classList.remove('hidden');
 $('#mk').onclick=function(){closeModal();res(true)};$('#mc').onclick=function(){closeModal();res(false)};
 m.onclick=function(e){if(e.target===m){closeModal();res(false)}}})}
window.__yaProg=function(p){var e=$('#prog');if(p<0||p>=100){e.classList.add('hidden');return}
 e.classList.remove('hidden');e.innerHTML='<div class="box"><b>در حال دانلود… '+fa(p)+'٪</b><div class="bar"><i style="width:'+p+'%"></i></div></div>'};

/* ---------- ZIP ---------- */
var CT=(function(){var T=[];for(var n=0;n<256;n++){var c=n;for(var k=0;k<8;k++)c=c&1?0xEDB88320^(c>>>1):c>>>1;T[n]=c>>>0}return T})();
function crc(b){var c=-1;for(var i=0;i<b.length;i++)c=CT[(c^b[i])&255]^(c>>>8);return(c^-1)>>>0}
function zip(files){
 var u16=function(n){return[n&255,(n>>8)&255]},u32=function(n){return[n&255,(n>>8)&255,(n>>16)&255,(n>>>24)&255]};
 var parts=[],cen=[],off=0;
 files.forEach(function(f){var nm=enc.encode(f.p),d=f.d,c=crc(d),n=d.length;
  var lh=new Uint8Array([0x50,0x4b,3,4,20,0,0,8,0,0,0,0,33,0].concat(u32(c),u32(n),u32(n),u16(nm.length),[0,0]));
  parts.push(lh,nm,d);
  cen.push(new Uint8Array([0x50,0x4b,1,2,20,0,20,0,0,8,0,0,0,0,33,0].concat(u32(c),u32(n),u32(n),u16(nm.length),[0,0,0,0,0,0,0,0,0,0,0,0],u32(off))),nm);
  off+=lh.length+nm.length+n});
 var cs=cen.reduce(function(a,x){return a+x.length},0);
 var end=new Uint8Array([0x50,0x4b,5,6,0,0,0,0].concat(u16(files.length),u16(files.length),u32(cs),u32(off),[0,0]));
 var all=parts.concat(cen,[end]),out=new Uint8Array(all.reduce(function(a,x){return a+x.length},0)),p=0;
 all.forEach(function(x){out.set(x,p);p+=x.length});return out}
/* خواندن فهرست ZIP برای بررسی وجود index.html پیش از آپلود */
function zipInfo(u8){
 var dv=new DataView(u8.buffer,u8.byteOffset,u8.byteLength),e=-1;
 for(var i=u8.length-22;i>=Math.max(0,u8.length-65558);i--){if(dv.getUint32(i,true)===0x06054b50){e=i;break}}
 if(e<0)throw new Error('این فایل ZIP معتبر نیست');
 var n=dv.getUint16(e+10,true),p=dv.getUint32(e+16,true),names=[],idx=null;
 for(var k=0;k<n;k++){
  if(dv.getUint32(p,true)!==0x02014b50)break;
  var m=dv.getUint16(p+10,true),cs=dv.getUint32(p+20,true),nl=dv.getUint16(p+28,true),el=dv.getUint16(p+30,true),cl=dv.getUint16(p+32,true),lo=dv.getUint32(p+42,true);
  var nm=new TextDecoder().decode(u8.subarray(p+46,p+46+nl));names.push(nm);
  if(/(^|\/)index\.html$/i.test(nm)&&nm.indexOf('__MACOSX')<0&&(!idx||nm.split('/').length<idx.n.split('/').length))idx={n:nm,m:m,cs:cs,lo:lo};
  p+=46+nl+el+cl}
 return{names:names,index:idx}}
async function zipTitle(u8,idx){
 try{var dv=new DataView(u8.buffer,u8.byteOffset,u8.byteLength),nl=dv.getUint16(idx.lo+26,true),el=dv.getUint16(idx.lo+28,true),s=idx.lo+30+nl+el,d=u8.subarray(s,s+idx.cs),txt;
  if(idx.m===0)txt=new TextDecoder().decode(d);
  else{var r=new Response(new Blob([d]).stream().pipeThrough(new DecompressionStream('deflate-raw')));txt=new TextDecoder().decode(await r.arrayBuffer())}
  return titleOf(txt)}catch(e){return''}}
function titleOf(h){var m=/<title[^>]*>([^<]{1,60})<\/title>/i.exec(h||'');return m?m[1].trim():''}

/* ---------- GitHub ---------- */
function friendly(e){
 var m=String(e&&e.message||e);
 if(e&&e.st===401)return'توکن نامعتبر یا منقضی است. در «حساب» یک توکن تازه بساز.';
 if(e&&e.st===403&&/rate limit/i.test(m))return'سقف درخواست GitHub پر شده؛ چند دقیقه بعد دوباره تلاش کن.';
 if(e&&e.st===403)return'دسترسی کافی نیست. توکن باید تیک repo و workflow داشته باشد.';
 if(e&&e.st===404)return'پیدا نشد. ممکن است توکن به این مخزن دسترسی نداشته باشد.';
 if(e&&e.st===409)return'GitHub هنوز آماده نیست؛ چند ثانیه بعد دوباره تلاش کن.';
 if(e&&e.st===422)return'GitHub درخواست را نپذیرفت. «حساب ← به‌روزرسانی کارخانه» را بزن و دوباره تلاش کن.';
 if(e&&e.st>=500)return'GitHub موقتاً مشکل دارد؛ کمی بعد دوباره تلاش کن.';
 if(/Failed to fetch|NetworkError|Load failed|abort/i.test(m)||!navigator.onLine)return'اتصال اینترنت برقرار نیست یا GitHub در دسترس نیست.';
 return m}
async function ghRaw0(m,u,b,ms){
 var h={Authorization:'Bearer '+S.token,Accept:'application/vnd.github+json'};if(b)h['Content-Type']='application/json';
 var ac=new AbortController(),t=setTimeout(function(){ac.abort()},ms||60000);
 try{return await fetch(u.indexOf('http')===0?u:'https://api.github.com'+u,{method:m,headers:h,body:b?JSON.stringify(b):undefined,cache:'no-store',signal:ac.signal})}finally{clearTimeout(t)}}
async function gh(m,u,b,ms){
 var r;try{r=await ghRaw0(m,u,b,ms)}catch(e){await sleep(1500);r=await ghRaw0(m,u,b,ms)}
 var j={};if(r.status!==204){try{j=await r.json()}catch(e){}}
 if(!r.ok){var er=new Error('GitHub '+r.status+': '+(j.message||''));er.st=r.status;throw er}
 j.__scopes=r.headers.get('x-oauth-scopes');return j}
async function ghBin(u,accept){
 var r=await fetch(u.indexOf('http')===0?u:'https://api.github.com'+u,{headers:{Authorization:'Bearer '+S.token,Accept:accept},cache:'no-store'});
 if(!r.ok){var er=new Error('HTTP '+r.status);er.st=r.status;throw er}return new Uint8Array(await r.arrayBuffer())}
async function putFile(path,u8,msg){
 var sha;try{sha=(await gh('GET','/repos/'+S.repo+'/contents/'+path+'?ref='+S.branch)).sha}catch(e){if(e.st!==404)throw e}
 await gh('PUT','/repos/'+S.repo+'/contents/'+path,{message:msg,content:b64(u8),branch:S.branch,sha:sha},240000)}
function isReady(){return !!(S.ready&&S.token)}

async function setup(say){
 if(!S.token)throw new Error('اول توکن را وارد کن');
 say('در حال اتصال به GitHub…');var me=await gh('GET','/user');S.login=me.login;
 var sc=me.__scopes;
 if(sc!==null&&sc!==undefined&&(sc.indexOf('repo')<0||sc.indexOf('workflow')<0))throw new Error('توکن باید دسترسی repo و workflow داشته باشد. توکن تازه با همین دو تیک بساز.');
 var rn=($('#rn')&&$('#rn').value.trim())||S.rn||'ya-forge-factory';
 if(!/^[A-Za-z0-9._-]+$/.test(rn))throw new Error('نام مخزن نامعتبر است');S.rn=rn;
 var full=me.login+'/'+rn,info;
 try{info=await gh('GET','/repos/'+full)}catch(e){if(e.st!==404)throw e;say('در حال ساخت مخزن خصوصی…');info=await gh('POST','/user/repos',{name:rn,private:true,auto_init:true,description:'YA Forge factory'});await sleep(2500)}
 if(!info.private)throw new Error('این مخزن عمومی است. کلیدهای امضا داخل مخزن ذخیره می‌شوند؛ نام دیگری بده یا مخزن را خصوصی کن.');
 var br=info.default_branch||'main',head=null;
 for(var i=0;i<6&&!head;i++){try{head=await gh('GET','/repos/'+full+'/git/ref/heads/'+br)}catch(e){if(e.st!==404&&e.st!==409)throw e;await sleep(2000)}}
 if(!head)throw new Error('مخزن خالی است؛ چند ثانیه بعد دوباره تلاش کن');
 say('در حال گذاشتن قالب اندروید…');
 var tr0=await fetch('template.json',{cache:'no-store'}),tt=await tr0.text(),tpl;
 try{tpl=JSON.parse(tt)}catch(e){tpl=null}
 if(!tpl||!tpl.files)throw new Error('قالب کارخانه داخل این نسخه از برنامه نیست. برنامه را با ساخت کامل (GitHub Actions یا scripts/build.sh) دوباره بساز.');
 var names=Object.keys(tpl.files),ents=[],idx=0;
 var base=(await gh('GET','/repos/'+full+'/git/commits/'+head.object.sha)).tree.sha;
 var worker=async function(){while(idx<names.length){var n=names[idx++],f=tpl.files[n];
  var b=await gh('POST','/repos/'+full+'/git/blobs',f.e==='b'?{content:f.d,encoding:'base64'}:{content:f.d,encoding:'utf-8'});
  ents.push({path:n,mode:'100644',type:'blob',sha:b.sha});say('در حال گذاشتن قالب اندروید… '+fa(ents.length)+' از '+fa(names.length))}};
 await Promise.all([worker(),worker(),worker(),worker()]);
 var tr=await gh('POST','/repos/'+full+'/git/trees',{base_tree:base,tree:ents});
 var cm=await gh('POST','/repos/'+full+'/git/commits',{message:'YA Forge factory v'+(tpl.v||TPL_VERSION),tree:tr.sha,parents:[head.object.sha]});
 await gh('PATCH','/repos/'+full+'/git/refs/heads/'+br,{sha:cm.sha});
 S.repo=full;S.branch=br;S.ready=true;S.tplv=tpl.v||TPL_VERSION;save()}

/* ---------- ساخت ---------- */
function readForm(id){
 var p=S.projects[id],g=function(s){return $(s)},ck=function(s){return !!(g(s)&&g(s).checked)};
 var name=g('#f_name').value.trim(),pkg=g('#f_pkg').value.trim(),vn=g('#f_vn').value.trim(),vc=parseInt(g('#f_vc').value,10),col=g('#f_col').value.trim();
 if(!name)throw new Error('نام برنامه را بنویس');
 if(!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/.test(pkg)||pkg.length>100)throw new Error('شناسه بسته نامعتبر است (مثل app.yashar.mytool؛ حروف کوچک انگلیسی، عدد و _)');
 if(pkg.split('.').some(function(x){return KW.indexOf(x)>=0}))throw new Error('شناسه بسته نباید کلمه رزروشده جاوا (مثل new یا class) داشته باشد');
 if(!/^[0-9A-Za-z._-]{1,20}$/.test(vn))throw new Error('نام نسخه نامعتبر است (مثل 1.0.0)');
 if(!(vc>0))throw new Error('شماره نسخه باید عدد مثبت باشد');
 if(!/^#[0-9A-Fa-f]{6}$/.test(col))throw new Error('رنگ باید مثل #0E1118 باشد');
 var perms=['camera','microphone','location','vibrate'].filter(function(k){return ck('#pm_'+k)});
 var doms=(g('#o_dom').value||'').split(/[\s,]+/).map(function(x){return x.trim().toLowerCase()}).filter(Boolean);
 var o={orientation:g('#o_ori').value,fullscreen:ck('#o_fs'),keep_screen_on:ck('#o_ko'),allow_zoom:ck('#o_zm'),allow_backup:ck('#o_bk'),external_links:ck('#o_ex'),exit_confirm:ck('#o_ec'),permissions:perms,allowed_domains:doms};
 if(p.type==='url'){var u=g('#f_url').value.trim();if(!/^https:\/\/[^\s"\\]+\.[^\s"\\]+$/i.test(u))throw new Error('آدرس سایت باید با https:// شروع شود');o.remote_url=u}
 p.name=name;p.pkg=pkg;p.vn=vn;p.vc=vc;p.color=col;p.fmt=g('#f_fmt').value;p.o=o;save();return o}
async function ensureFactory(say){
 if(!isReady()){location.hash='#/acc';throw new Error('اول در «حساب» توکن GitHub را وارد و کارخانه را راه‌اندازی کن')}
 if(S.tplv!==TPL_VERSION){say('در حال به‌روزرسانی کارخانه…');await setup(say)}}
async function doBuild(id,say){
 var p=S.projects[id],o=readForm(id);
 await ensureFactory(say);
 if(p.type!=='url'){
  if(PEND[id]){say('در حال آپلود فایل‌ها…');var u8=PEND[id];if(u8.length>40*1048576)throw new Error('حجم فایل بیشتر از ۴۰ مگابایت است');
   await putFile('projects/'+id+'/'+(p.type==='zip'?'site.zip':'index.html'),u8,'source '+id);p.up=true;delete PEND[id];save()}
  if(!p.up)throw new Error('فایل منبع را دوباره انتخاب کن')}
 if(PICON[id]){say('در حال آپلود آیکون…');await putFile('projects/'+id+'/icon.png',PICON[id],'icon '+id);p.icon=true;delete PICON[id];save()}
 say('در حال شروع ساخت…');
 var bid=Math.random().toString(36).slice(2,8),done=false;
 var inputs={project_id:id,build_id:bid,app_name:p.name,package_id:p.pkg,version_name:p.vn,version_code:String(p.vc),primary_color:p.color,source_type:p.type,formats:p.fmt,has_icon:p.icon?'true':'false',options:JSON.stringify(o)};
 for(var i=0;i<6&&!done;i++){try{await gh('POST','/repos/'+S.repo+'/actions/workflows/factory.yml/dispatches',{ref:S.branch,inputs:inputs});done=true}catch(e){if(e.st!==404||i===5)throw e;await sleep(3000)}}
 S.builds.unshift({id:bid,pid:id,name:p.name,vn:p.vn,fmt:p.fmt,created:Date.now()});S.builds=S.builds.slice(0,30);
 p.vc=p.vc+1;save();return bid}

async function tick(b){
 try{
  if(!b.run){var r=await gh('GET','/repos/'+S.repo+'/actions/workflows/factory.yml/runs?event=workflow_dispatch&per_page=10'),m=null;
   (r.workflow_runs||[]).forEach(function(x){if((x.display_title||'').indexOf(b.id)>=0)m=x});if(m){b.run=m.id;b.url=m.html_url}}
  if(b.run){
   var ru=await gh('GET','/repos/'+S.repo+'/actions/runs/'+b.run);b.st=ru.status;b.cc=ru.conclusion;b.url=ru.html_url;
   var jb=await gh('GET','/repos/'+S.repo+'/actions/runs/'+b.run+'/jobs');
   b.steps=(((jb.jobs||[])[0]||{}).steps||[]).filter(function(s){return/^\d\)/.test(s.name)}).map(function(s){return{n:s.name,s:s.status,c:s.conclusion}});
   if(b.st==='completed'&&b.cc==='success'&&!b.assets){
    var rl=await gh('GET','/repos/'+S.repo+'/releases/tags/b-'+b.id);
    b.assets=(rl.assets||[]).map(function(a){return{name:a.name,size:a.size,url:a.url}});b.rel=rl.html_url}}
  b.err='';save()
 }catch(e){b.err=friendly(e)}
 paint(b)}
function sOf(b){return b.cc==='success'?'ok':b.cc==='cancelled'?'fail':b.st==='completed'?'fail':(b.run&&b.st==='in_progress')?'running':'queued'}
var ST={queued:'در صف…',running:'در حال ساخت…',ok:'ساخته شد ✓',fail:'ناموفق ✗'};
function badge(b){var s=sOf(b);return'<span class="badge '+(s==='queued'?'':s)+'">'+ST[s]+(b.cc==='cancelled'?' (لغو شد)':'')+'</span>'}
function paint(b){
 var e=$('#bst');if(!e)return;var s=sOf(b),steps=b.steps||[];
 var dn=steps.filter(function(x){return x.c==='success'}).length,pc=s==='ok'?100:Math.min(95,Math.round(dn/4*100)+(steps.some(function(x){return x.s==='in_progress'})?8:0));
 var h=badge(b);
 if(s==='queued'||s==='running'){h+='<div class="bar"><i style="width:'+pc+'%"></i></div><p class="m">ساخت معمولاً ۴ تا ۸ دقیقه طول می‌کشد. می‌توانی از برنامه بیرون بروی؛ ساخت روی GitHub ادامه دارد.</p>'}
 steps.forEach(function(x){var ic=x.c==='success'?'✅':x.c==='failure'?'❌':x.s==='in_progress'?'⏳':'⚪';h+='<div class="r"><div class="i">'+ic+' '+esc(x.n.replace(/^\d\)\s*/,''))+'</div></div>'});
 if(s==='queued'||s==='running'){if(b.run)h+='<button class="s w" data-a="cancel" data-p="'+esc(b.id)+'">لغو ساخت</button>'}
 if(s==='fail'){var f=steps.filter(function(x){return x.c==='failure'})[0];if(f)h+='<p class="m">مرحله ناموفق: <b>'+esc(f.n.replace(/^\d\)\s*/,''))+'</b></p>';
  h+='<p class="m">دلیل‌های رایج: شناسه بسته تکراری یا نامعتبر، نبودن index.html در ZIP، یا رمز کلید واردشده اشتباه است. لاگ کامل را ببین:</p>';
  if(b.url)h+='<p><a href="'+esc(b.url)+'">باز کردن لاگ ساخت در GitHub</a></p>';h+='<button class="w" data-a="again" data-p="'+esc(b.pid)+'">تلاش دوباره</button>'}
 if(s==='ok'&&b.assets){b.assets.forEach(function(a,i){h+='<button class="w" data-a="dla" data-p="'+esc(b.id)+'|'+i+'">⬇️ دانلود '+esc(a.name)+' ('+fa((a.size/1048576).toFixed(1))+' مگابایت)</button>'});
  h+='<p class="m">فایل APK را روی گوشی نصب کن. فایل AAB را در Google Play Console بارگذاری کن.</p>';
  if(b.rel)h+='<p class="m"><a href="'+esc(b.rel)+'">صفحه انتشار در GitHub</a></p>'}
 if(b.err)h+='<p class="m">⚠️ '+esc(b.err)+'</p>';
 e.innerHTML=h}
async function dlAsset(a){
 if(window.YAApp&&window.YAApp.downloadAsset){window.YAApp.downloadAsset(a.name,a.url,S.token);return}
 toast('در حال دانلود…');
 try{saveOut(a.name,await ghBin(a.url,'application/octet-stream'))}catch(e){toast('دانلود نشد: '+friendly(e))}}

/* ---------- نمایش‌ها ---------- */
function bt(a,p,l,c){return'<button class="'+(c||'')+'" data-a="'+a+'"'+(p!=null?' data-p="'+esc(p)+'"':'')+'>'+l+'</button>'}
function ck(id,label,on){return'<label class="ck"><input type="checkbox" id="'+id+'"'+(on?' checked':'')+'>'+label+'</label>'}
function vHome(){
 var h='';
 h+='<p class="m" style="margin:6px 4px">APK و AAB امضاشده را روی حساب GitHub خودت بساز؛ رایگان و بدون محدودیت.</p>';
 if(!isReady())h+='<div class="c warn"><b>قدم اول</b><br>برای شروع، یک بار GitHub را وصل کن (حدود ۲ دقیقه).<br>'+bt('go','#/acc','اتصال به GitHub','w')+'</div>';
 else if(S.tplv!==TPL_VERSION)h+='<div class="c warn">نسخه کارخانه قدیمی است؛ هنگام ساخت بعدی خودکار به‌روز می‌شود.</div>';
 h+='<h3>برنامه جدید از…</h3><div class="g3">'
  +'<button type="button" class="big" data-native-file="zip" style="margin:0"><span class="ic">🗜️</span><b>سایت ZIP</b><small>فایل .zip دارای index.html</small></button>'
  +'<button type="button" class="big" data-native-file="html" style="margin:0"><span class="ic">&lt;/&gt;</span><b>فایل HTML</b><small>یک سند .html</small></button>'
  +'<button class="big" data-a="newurl" style="margin:0"><span class="ic">🔗</span><b>آدرس سایت</b><small>سایت آنلاین خودت</small></button></div>';
 h+='<div class="c" style="margin-top:14px"><h2>ساخت‌های اخیر</h2>';
 if(!S.builds.length)h+='<span class="m">هنوز چیزی ساخته نشده.</span>';
 S.builds.slice(0,6).forEach(function(b){h+='<div class="r"><div class="i"><b>'+esc(b.name)+'</b> <span class="m">نسخه '+esc(b.vn)+'</span></div>'+badge(b)+bt('go','#/b/'+b.id,'باز','s')+'</div>'});
 return h+'</div>'}
function vProject(id){
 var p=S.projects[id];if(!p)return'<div class="c">پیدا نشد.</div>';var o=p.o||{};
 var pm=o.permissions||[];
 var src=p.type==='url'?'':('<label class="f">فایل منبع ('+(p.type==='zip'?'ZIP':'HTML')+')</label><div class="m">'+(PEND[id]?'✅ آماده آپلود':(p.up?'✅ روی GitHub آماده است':'⚠️ فایل را دوباره انتخاب کن'))+(p.note?'<br>'+esc(p.note):'')+'</div><label class="b s">تعویض فایل<input type="file" hidden data-c="resrc" data-p="'+esc(id)+'"></label>');
 var url=p.type==='url'?'<label class="f">آدرس سایت (https)</label><input id="f_url" dir="ltr" value="'+esc(o.remote_url||'https://')+'">':'';
 return(isReady()?'':'<div class="c warn">برای ساخت، اول در «حساب» توکن را وارد کن. تنظیمات این صفحه می‌ماند.</div>')
 +'<div class="c">'+bt('go','#/prj','‹ بازگشت','s')+'<h2>'+esc(p.name)+'</h2>'
 +'<label class="f">نام برنامه</label><input id="f_name" value="'+esc(p.name)+'">'+url
 +'<label class="f">شناسه بسته (یکتا و ثابت؛ بعد از انتشار عوض نکن)</label><input id="f_pkg" dir="ltr" value="'+esc(p.pkg)+'">'
 +'<div class="g3"><div><label class="f">نام نسخه</label><input id="f_vn" dir="ltr" value="'+esc(p.vn)+'"></div><div><label class="f">شماره نسخه</label><input id="f_vc" dir="ltr" inputmode="numeric" value="'+esc(p.vc)+'"></div></div>'
 +'<label class="f">رنگ اصلی (نوار بالا و صفحه شروع)</label><div class="g3"><input id="f_col" dir="ltr" value="'+esc(p.color)+'"><input type="color" id="f_cp" value="'+esc(p.color)+'" style="max-width:70px"></div>'
 +'<label class="f">خروجی</label><select id="f_fmt"><option value="both"'+(p.fmt==='both'?' selected':'')+'>APK + AAB</option><option value="apk"'+(p.fmt==='apk'?' selected':'')+'>فقط APK (نصب مستقیم)</option><option value="aab"'+(p.fmt==='aab'?' selected':'')+'>فقط AAB (Google Play)</option></select>'
 +'<label class="f">آیکون (اختیاری؛ تصویر مربعی ۵۱۲ پیکسل بهتر است)</label><label class="b s">انتخاب تصویر<input type="file" accept="image/*" hidden data-c="icon" data-p="'+esc(id)+'"></label> <span class="m" id="ico">'+(PICON[id]||p.icon?'آیکون انتخاب شد ✓':'')+'</span>'
 +src+'</div>'
 +'<div class="c"><details'+(p.type==='url'?' open':'')+'><summary>تنظیمات پیشرفته</summary>'
 +'<label class="f">جهت صفحه</label><select id="o_ori"><option value="auto"'+(o.orientation!=='portrait'&&o.orientation!=='landscape'?' selected':'')+'>خودکار</option><option value="portrait"'+(o.orientation==='portrait'?' selected':'')+'>فقط عمودی</option><option value="landscape"'+(o.orientation==='landscape'?' selected':'')+'>فقط افقی</option></select>'
 +ck('o_fs','تمام‌صفحه (پنهان‌کردن نوار وضعیت)',o.fullscreen)+ck('o_ko','روشن‌ماندن صفحه',o.keep_screen_on)+ck('o_zm','اجازه زوم با دو انگشت',o.allow_zoom)
 +ck('o_ec','پیام «برای خروج دوباره بزن»',o.exit_confirm!==false)+ck('o_ex','لینک‌های بیرونی در مرورگر باز شوند',o.external_links!==false)+ck('o_bk','پشتیبان‌گیری خودکار اندروید از داده‌ها',o.allow_backup)
 +'<label class="f">دامنه‌هایی که داخل برنامه باز شوند (با ویرگول جدا کن)</label><input id="o_dom" dir="ltr" placeholder="example.com, api.example.com" value="'+esc((o.allowed_domains||[]).join(', '))+'">'
 +'<h3>دسترسی‌ها (فقط اگر برنامه‌ات لازم دارد)</h3>'+ck('pm_camera','دوربین',pm.indexOf('camera')>=0)+ck('pm_microphone','میکروفون',pm.indexOf('microphone')>=0)+ck('pm_location','موقعیت مکانی',pm.indexOf('location')>=0)+ck('pm_vibrate','لرزش',pm.indexOf('vibrate')>=0)
 +'<p class="m">هر دسترسی اضافه در فروشگاه‌ها باید توضیح داده شود؛ فقط موارد لازم را بزن.</p></details>'
 +'<button class="w" data-a="build" data-p="'+esc(id)+'">🚀 ساخت برنامه</button><div id="bs" class="m"></div></div>'}
function vBuild(id){
 var b=S.builds.filter(function(x){return x.id===id})[0];if(!b)return'<div class="c">پیدا نشد.</div>';
 setTimeout(function(){tick(b)},0);TM=setInterval(function(){if(b.cc&&b.assets||b.st==='completed'&&b.cc!=='success'){clearInterval(TM);return}tick(b)},8000);
 return'<div class="c">'+bt('go','#/','‹ خانه','s')+'<h2>'+esc(b.name)+' · نسخه '+esc(b.vn)+'</h2><div id="bst"></div></div>'}
function vPrj(){
 var ids=Object.keys(S.projects).sort(function(a,b){return S.projects[b].created-S.projects[a].created});
 var h='<div class="c"><h2>پروژه‌ها</h2>';if(!ids.length)h+='<span class="m">هنوز پروژه‌ای نیست. از «خانه» یک فایل یا آدرس انتخاب کن.</span>';
 ids.forEach(function(id){var p=S.projects[id];h+='<div class="r"><div class="i"><b>'+esc(p.name)+'</b><div class="m l">'+esc(p.pkg)+' · v'+esc(p.vn)+'</div></div>'+bt('go','#/p/'+id,'باز','s')+bt('delp',id,'حذف','d')+'</div>'});
 return h+'</div>'}
async function vDl(){
 var rs=await gh('GET','/repos/'+S.repo+'/releases?per_page=30');REL=rs;
 var h='<div class="c"><h2>ساخت‌های موفق</h2>'+bt('go','#/dl','↻ تازه‌سازی','s');
 if(!rs.length)h+='<p class="m">هنوز ساختی نیست.</p>';
 rs.forEach(function(r,i){h+='<div class="r"><div class="i"><b>'+esc(r.name||r.tag_name)+'</b><div class="m">'+fa(new Date(r.published_at||r.created_at).toLocaleString('fa-IR'))+'</div>';
  (r.assets||[]).forEach(function(a,j){h+=bt('dlr',i+'|'+j,'⬇️ '+esc(a.name)+' ('+fa((a.size/1048576).toFixed(1))+'MB)','s')});h+='</div>'+bt('delr',String(i),'🗑','d')+'</div>'});
 return h+'</div>'}
function vAcc(){
 var ok=isReady();
 return'<div class="c"><h2>اتصال به GitHub</h2>'+(ok?'<p>✅ متصل به <b class="l">'+esc(S.login)+'</b> · <span class="l">'+esc(S.repo||'')+'</span></p>':'<p class="m">برای ساخت برنامه، یک بار کارخانه را روی حساب خودت راه بینداز.</p>')
 +'<div class="c" style="background:var(--pn2)"><b>راه‌اندازی در ۳ قدم</b><ol style="margin:6px 0;padding:0 22px"><li>دکمه زیر را بزن تا GitHub باز شود (اگر وارد نیستی، وارد شو).</li><li>پایین صفحه «Generate token» را بزن و توکن (که با ghp_ شروع می‌شود) را کپی کن.</li><li>به همین برنامه برگرد، توکن را در کادر زیر بچسبان و «ذخیره و راه‌اندازی» را بزن.</li></ol><a class="b" href="https://github.com/settings/tokens/new?description=YA%20Forge&scopes=repo,workflow">۱) ساخت توکن در GitHub</a></div>'
 +'<label class="f">توکن دسترسی GitHub</label><input id="tk" type="password" dir="ltr" autocomplete="off" placeholder="'+(S.token?'••••'+esc(S.token.slice(-4)):'ghp_…')+'">'
 +'<p class="m">توکن فقط داخل همین برنامه روی گوشی می‌ماند و فقط به GitHub فرستاده می‌شود.</p>'
 +'<label class="f">نام مخزن کارخانه (خصوصی)</label><input id="rn" dir="ltr" value="'+esc(S.rn||'ya-forge-factory')+'">'
 +'<button class="w" data-a="setup">'+(ok?'به‌روزرسانی کارخانه':'ذخیره و راه‌اندازی')+'</button><div id="as" class="m"></div>'
 +(S.token?bt('logout',null,'خروج و حذف توکن','s w'):'')+'</div>'
 +'<div class="c"><h2>پیشوند شناسه بسته</h2><p class="m">شناسه برنامه‌های جدید با این پیشوند ساخته می‌شود.</p><input id="pfx" dir="ltr" value="'+esc(prefix())+'"><button class="s" data-a="savepfx">ذخیره</button></div>'
 +'<div class="c"><h2>🔐 کلیدهای امضا</h2><p class="m">کلید امضای هر برنامه روی مخزن خصوصی تو ذخیره می‌شود. حتماً یک نسخه پشتیبان بیرون از GitHub نگه دار؛ با گم‌شدن کلید دیگر نمی‌توانی همان برنامه را به‌روزرسانی کنی.</p>'
 +bt('keys',null,'⬇️ پشتیبان همه کلیدها (ZIP)','s')+'<details><summary>وارد کردن کلید امضای موجود</summary><p>اگر قبلاً برنامه‌ای با کلید خودت منتشر کرده‌ای، کلید را اینجا بده تا همان کلید استفاده شود.</p>'
 +'<label class="f">شناسه بسته برنامه</label><input id="ik_pkg" dir="ltr"><label class="f">فایل کلید (.jks یا .keystore)</label><input id="ik_file" type="file">'
 +'<label class="f">رمز فایل کلید</label><input id="ik_sp" type="password" dir="ltr"><label class="f">نام کلید (alias)</label><input id="ik_al" dir="ltr" value="release"><label class="f">رمز کلید (اگر فرق دارد)</label><input id="ik_kp" type="password" dir="ltr">'
 +bt('impkey',null,'وارد کردن کلید','s w')+'</details></div>'
 +'<div class="c m" dir="ltr" style="font-size:11px">build: tpl'+TPL_VERSION+' · bridge: '+(window.YAApp?('yes'+(window.YAApp.pickFile?'+pick':'')):'no')+' · '+esc((navigator.userAgent.match(/Chrome\/[\d.]+/)||['?'])[0])+' · token: '+(S.token?'saved':'none')+'</div>'+'<div class="c m">YA Forge · نسخه '+esc(window.YAApp&&window.YAApp.appVersion?window.YAApp.appVersion():'2.0.0')+' · ساخت APK و AAB امضاشده روی حساب خودت</div>'}
var FAQ=[
['توکن GitHub چیست و چطور بسازم؟','توکن مثل یک رمز مخصوص است که به YA Forge اجازه می‌دهد روی حساب خودت برنامه بسازد. از «حساب» دکمه ساخت توکن را بزن، پایین صفحه Generate token را بزن و آن را کپی کن. تیک repo و workflow باید روشن باشد.'],
['فرق APK و AAB چیست؟','APK را مستقیم روی گوشی نصب می‌کنی. AAB فقط برای بارگذاری در Google Play است و خودِ Play از روی آن APK مناسب هر گوشی را می‌سازد.'],
['چطور در Google Play منتشر کنم؟','۱) در Play Console یک برنامه بساز. ۲) فایل AAB را در بخش انتشار بارگذاری کن. ۳) سیاست حریم خصوصی، رده‌بندی محتوا و فرم Data safety را پر کن. ۴) از کلید امضای ثابت همین برنامه استفاده کن و برای به‌روزرسانی، شماره نسخه را بالا ببر (خودکار بالا می‌رود). نسخه هدف اندروید در این قالب ۳۶ است که شرط فعلی Play است.'],
['کلید امضا چیست؟ چرا پشتیبان بگیرم؟','هر برنامه با یک کلید ثابت امضا می‌شود. اگر کلید را گم کنی نمی‌توانی نسخه جدید همان برنامه را روی گوشی‌ها یا در Play منتشر کنی. از «حساب ← پشتیبان کلیدها» یک نسخه ZIP بگیر و جای امن نگه دار.'],
['هزینه‌ای دارد؟','خود YA Forge رایگان است. ساخت‌ها روی GitHub Actions اجرا می‌شود و حساب رایگان GitHub برای مخزن خصوصی سهمیه ماهانه دارد (حدود ۲۰۰۰ دقیقه). هر ساخت معمولاً ۴ تا ۸ دقیقه است.'],
['سایت HTML من در برنامه درست کار نمی‌کند','مسیر فایل‌ها را نسبی بنویس (مثل css/style.css نه C:\\...). اگر از CDN استفاده می‌کنی برنامه فقط با اینترنت کامل باز می‌شود؛ برای کار آفلاین فایل‌ها را داخل ZIP بگذار. فایل اصلی باید index.html باشد.'],
['حالت «آدرس سایت» چیست؟','برنامه فقط سایت آنلاین تو را (با https) داخل یک قاب بومی باز می‌کند. با هر تغییر سایت، برنامه خودکار به‌روز دیده می‌شود. لینک‌های دامنه‌های دیگر در مرورگر باز می‌شوند.'],
['دسترسی‌ها (دوربین، میکروفون، مکان) چه می‌شوند؟','فقط اگر در «تنظیمات پیشرفته» تیک بزنی به برنامه اضافه می‌شوند و هنگام استفاده از کاربر اجازه گرفته می‌شود.'],
['فایل را از تلگرام یا مدیر فایل چطور بدهم؟','روی فایل ZIP یا HTML بزن، «اشتراک‌گذاری» یا «باز کردن با» را انتخاب کن و YA Forge را بزن؛ پروژه جدید خودکار ساخته می‌شود.'],
['ساخت ناموفق شد، چه کنم؟','در صفحه ساخت، مرحله ناموفق و لینک لاگ نمایش داده می‌شود. دلیل‌های رایج: شناسه بسته نامعتبر، ZIP بدون index.html، یا رمز کلید واردشده اشتباه است. «تلاش دوباره» را بزن.'],
['حریم خصوصی','توکن و پروژه‌ها فقط روی گوشی و حساب GitHub خودت هستند. چیزی روی سرور ما ذخیره نمی‌شود.']];
function vHelp(){var h='<div class="c"><h2>راهنما و پرسش‌های رایج</h2>';FAQ.forEach(function(q){h+='<details><summary>'+esc(q[0])+'</summary><p>'+esc(q[1])+'</p></details>'});return h+'</div>'}

function prefix(){var base=S.prefix||('app.'+String(S.login||'yashar').toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_+|_+$/g,'')) ;return base}
function titleFor(h){return{acc:'حساب',prj:'پروژه‌ها',p:'تنظیمات پروژه',b:'وضعیت ساخت',dl:'دانلودها',help:'راهنما'}[h]||'YA Forge'}
var NAV=[['','🏠','خانه'],['prj','📚','پروژه‌ها'],['dl','⬇️','دانلودها'],['acc','👤','حساب'],['help','❓','راهنما']];
async function render(){
 clearInterval(TM);closeModal();
 var h=(location.hash||'#/').slice(1).split('/').filter(Boolean),html;
 $('#ttl').textContent=titleFor(h[0]);
 $('#nav').innerHTML=NAV.map(function(n){return'<button class="'+((h[0]||'')===n[0]?'on':'')+'" data-a="go" data-p="#/'+n[0]+'"><span>'+n[1]+'</span>'+n[2]+'</button>'}).join('');
 try{
  if(h[0]==='acc')html=vAcc();else if(h[0]==='prj')html=vPrj();else if(h[0]==='p')html=vProject(h[1]);
  else if(h[0]==='b')html=vBuild(h[1]);else if(h[0]==='help')html=vHelp();
  else if(h[0]==='dl'){if(!isReady()){html='<div class="c warn">اول در «حساب» GitHub را وصل کن.</div>'}else{$('#app').innerHTML='<div class="c m">…</div>';html=await vDl()}}
  else html=vHome();
 }catch(e){html='<div class="c err">⚠️ '+esc(friendly(e))+'</div>'}
 $('#app').innerHTML='<div class="fade">'+html+'</div>';window.scrollTo(0,0)}

/* ---------- رویدادها ---------- */
function newProject(kind,base,title,url){
 var slug=base.toLowerCase().replace(/[^a-z0-9]/g,'');
 if(!/^[a-z]/.test(slug))slug='app'+slug;slug=slug.slice(0,14);
 if(slug.length<4||KW.indexOf(slug)>=0)slug='app'+Math.random().toString(36).slice(2,7);
 var id='p'+Date.now().toString(36);
 S.projects[id]={id:id,name:(title||base).slice(0,40),pkg:prefix()+'.'+slug,vn:'1.0.0',vc:1,color:'#0E1118',fmt:'both',type:kind,up:kind==='url',icon:false,created:Date.now(),o:url?{remote_url:url}:{}};
 return id}
async function takeFile(f,fromShare){
 var kind=/\.zip$/i.test(f.name)?'zip':/\.html?$/i.test(f.name)?'html':null;
 if(!kind){toast('فقط فایل .zip یا .html پشتیبانی می‌شود');return}
 if(f.size>40*1048576){toast('حجم فایل بیشتر از ۴۰ مگابایت است');return}
 var u8=await readBuf(f),title='',note='';
 if(kind==='zip'){var zi=zipInfo(u8);if(!zi.index)throw new Error('داخل ZIP فایل index.html پیدا نشد');title=await zipTitle(u8,zi.index);note=fa(zi.names.length)+' فایل داخل ZIP'}
 else{var t=new TextDecoder().decode(u8);title=titleOf(t);var w=[];if(!/<meta[^>]+viewport/i.test(t))w.push('تگ viewport نبود؛ هنگام ساخت خودکار اضافه می‌شود.');if(/(src|href)=["']http:\/\//i.test(t))w.push('آدرس http:// پیدا شد؛ فقط https در برنامه کار می‌کند.');note=w.join(' ')}
 var base=f.name.replace(/\.[^.]+$/,''),id=newProject(kind,base,title);
 S.projects[id].note=note;PEND[id]=u8;save();toast('فایل آماده شد: '+f.name);location.hash='#/p/'+id}
window.__yaShared=async function(name){
 try{var r=await fetch('/__shared',{cache:'no-store'});if(!r.ok)return;var blob=await r.blob();window.YAApp.clearShared();await takeFile(new File([blob],name),true)}catch(e){toast(friendly(e))}};
var A={
 go:function(p){if(location.hash===p)render();else location.hash=p},
 newurl:async function(){var id=newProject('url','site','وب‌اپ من','https://');S.projects[id].o={};save();location.hash='#/p/'+id},
 setup:async function(){var tk=$('#tk').value.trim();if(tk)S.token=tk;var say=function(x){$('#as').textContent=x};
  try{await setup(say)}catch(e){var fm=friendly(e);say('⚠️ '+fm);$('#as').style.color='#ff8a8a';throw new Error(fm)}
  say('کارخانه آماده است ✓');toast('کارخانه آماده است ✓');setTimeout(render,1000)},
 logout:async function(){if(!await ask('خروج','توکن از این برنامه حذف می‌شود. پروژه‌ها و ساخت‌های قبلی روی GitHub می‌مانند.','خروج',true))return;delete S.token;S.ready=false;save();render()},
 savepfx:function(){var v=$('#pfx').value.trim().toLowerCase();if(!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)*$/.test(v))throw new Error('پیشوند نامعتبر است (مثل app.yashar)');S.prefix=v;save();toast('ذخیره شد ✓')},
 build:async function(id){var say=function(x){$('#bs').textContent=x};var btn=$('[data-a=build]');btn.disabled=true;
  try{var bid=await doBuild(id,say);location.hash='#/b/'+bid}catch(e){say('');btn.disabled=false;throw new Error(friendly(e))}},
 again:function(pid){location.hash='#/p/'+pid},
 cancel:async function(id){var b=S.builds.filter(function(x){return x.id===id})[0];if(!b||!b.run)return;await gh('POST','/repos/'+S.repo+'/actions/runs/'+b.run+'/cancel');toast('درخواست لغو ارسال شد')},
 dla:function(p){var q=p.split('|'),b=S.builds.filter(function(x){return x.id===q[0]})[0];return dlAsset(b.assets[+q[1]])},
 dlr:function(p){var q=p.split('|'),a=REL[+q[0]].assets[+q[1]];return dlAsset({name:a.name,url:a.url})},
 delr:async function(i){var r=REL[+i];if(!await ask('حذف ساخت','«'+(r.name||r.tag_name)+'» از GitHub پاک شود؟ این کار برگشت‌پذیر نیست.','حذف',true))return;
  await gh('DELETE','/repos/'+S.repo+'/releases/'+r.id);try{await gh('DELETE','/repos/'+S.repo+'/git/refs/tags/'+r.tag_name)}catch(e){}toast('حذف شد');render()},
 delp:async function(id){if(!await ask('حذف پروژه','این پروژه از فهرست حذف شود؟ فایل‌های روی GitHub می‌مانند.','حذف',true))return;delete S.projects[id];save();render()},
 keys:async function(){
  var list;try{list=await gh('GET','/repos/'+S.repo+'/contents/keys?ref='+S.branch)}catch(e){if(e.st===404)return toast('هنوز کلیدی ساخته نشده');throw e}
  var files=[];for(var i=0;i<list.length;i++)files.push({p:list[i].name,d:await ghBin(list[i].url,'application/vnd.github.raw')});
  saveOut('ya-forge-keys-backup.zip',zip(files),'application/zip')},
 impkey:async function(){
  if(!isReady())throw new Error('اول GitHub را وصل کن');
  var pkg=$('#ik_pkg').value.trim(),f=$('#ik_file').files[0],sp=$('#ik_sp').value,al=$('#ik_al').value.trim()||'release',kp=$('#ik_kp').value||sp;
  if(!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/.test(pkg))throw new Error('شناسه بسته نامعتبر است');
  if(!f||!sp)throw new Error('فایل کلید و رمز آن را بده');
  if(!await ask('وارد کردن کلید','کلید فعلی این برنامه (اگر باشد) جایگزین می‌شود.','وارد کن'))return;
  await putFile('keys/'+pkg+'.jks',await readBuf(f),'import key '+pkg);
  await putFile('keys/'+pkg+'.properties',enc.encode('storePassword='+sp+'\nkeyPassword='+kp+'\nkeyAlias='+al+'\n'),'import key props '+pkg);
  toast('کلید وارد شد ✓')}
};
var C={
 pickFile:async function(f,kind){
  if(kind==='zip'&&!/\.zip$/i.test(f.name))return toast('فایل باید .zip باشد');
  if(kind==='html'&&!/\.html?$/i.test(f.name))return toast('فایل باید .html باشد');await takeFile(f)},
 resrcFile:async function(f,id){var p=S.projects[id];if(!p)return;
  if(/\.zip$/i.test(f.name))p.type='zip';else if(/\.html?$/i.test(f.name))p.type='html';else return toast('فقط .zip یا .html');
  var u8=await readBuf(f);if(p.type==='zip'&&!zipInfo(u8).index)throw new Error('داخل ZIP فایل index.html پیدا نشد');PEND[id]=u8;save();render()},
 pick:async function(inp){var f=inp.files&&inp.files[0],kind=inp.getAttribute('data-k');if(!f){toast('فایلی انتخاب نشد یا خوانده نشد؛ دوباره امتحان کن');return}toast('در حال خواندن: '+f.name);
  if(kind==='zip'&&!/\.zip$/i.test(f.name))return toast('فایل باید .zip باشد');
  if(kind==='html'&&!/\.html?$/i.test(f.name))return toast('فایل باید .html باشد');await takeFile(f)},
 resrc:async function(inp){var f=inp.files[0],id=inp.getAttribute('data-p');inp.value='';if(!f)return;var p=S.projects[id];
  if(/\.zip$/i.test(f.name))p.type='zip';else if(/\.html?$/i.test(f.name))p.type='html';else return toast('فقط .zip یا .html');
  var u8=await readBuf(f);if(p.type==='zip'&&!zipInfo(u8).index)throw new Error('داخل ZIP فایل index.html پیدا نشد');PEND[id]=u8;save();render()},
 icon:async function(inp){var f=inp.files[0],id=inp.getAttribute('data-p');inp.value='';if(!f)return;PICON[id]=await iconPng(f);$('#ico').textContent='آیکون انتخاب شد ✓'}
};
function iconPng(file){return new Promise(function(res,rej){
 var img=new Image(),u=URL.createObjectURL(file);
 img.onload=function(){var c=document.createElement('canvas');c.width=c.height=512;var x=c.getContext('2d'),s=Math.min(img.width,img.height);
  x.drawImage(img,(img.width-s)/2,(img.height-s)/2,s,s,0,0,512,512);URL.revokeObjectURL(u);
  c.toBlob(function(b){if(!b)return rej(new Error('آیکون خوانده نشد'));readBuf(b).then(res,rej)},'image/png')};
 img.onerror=function(){rej(new Error('این تصویر خوانده نشد'))};img.src=u})}
document.addEventListener('click',async function(e){var b=e.target.closest('[data-a]');if(!b)return;
 try{await A[b.getAttribute('data-a')](b.getAttribute('data-p')||'',b)}catch(x){toast(friendly(x))}});
/* انتخاب فایل: کارت‌های صفحه اصلی مستقیماً به پل بومی متصل‌اند؛ بدون label و input مخفی. */
var NP=null,NPB=null;
function nativePick(ctx){
 NP=ctx;
 try{
  if(window.YAApp&&typeof window.YAApp.pickFile==='function') window.YAApp.pickFile(ctx.k);
  else {
   NP=null;
   var inp=document.createElement('input');inp.type='file';inp.accept=ctx.k==='zip'?'.zip,application/zip,application/x-zip-compressed':'.html,.htm,text/html';
   inp.onchange=function(){var f=inp.files&&inp.files[0];if(!f)return;C.pickFile(f).catch(function(x){toast(friendly(x))})};
   inp.click();
  }
 }catch(x){NP=null;toast('باز کردن انتخاب‌گر فایل ناموفق بود: '+friendly(x))}
}
window.__yaPickBegin=function(name,size){NPB={name:name,size:size,parts:[],n:0};toast('در حال خواندن: '+name)};
window.__yaPickChunk=function(b){if(!NPB)return;var s=atob(b),u=new Uint8Array(s.length);for(var i=0;i<s.length;i++)u[i]=s.charCodeAt(i);NPB.parts.push(u);NPB.n+=u.length};
window.__yaPickFail=function(m){NPB=null;NP=null;if(m)toast(m)};
window.__yaPickEnd=async function(){var b=NPB,c=NP;NPB=null;NP=null;if(!b||!c)return;
 try{var f=new File(b.parts,b.name);await C.pickFile(f,c.k)}catch(x){toast(friendly(x))}};
document.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('[data-native-file]');if(!b)return;e.preventDefault();e.stopPropagation();var k=b.getAttribute('data-native-file');if(k!=='zip'&&k!=='html')return;nativePick({c:'pick',k:k})},true);
document.addEventListener('change',async function(e){var b=e.target.closest('[data-c]');if(!b)return;
 try{await C[b.getAttribute('data-c')](b)}catch(x){toast(friendly(x))}});
document.addEventListener('input',function(e){if(e.target.id==='f_cp'){$('#f_col').value=e.target.value.toUpperCase()}});
window.addEventListener('hashchange',render);
function net(){$('#off').classList.toggle('hidden',navigator.onLine)}
window.addEventListener('online',net);window.addEventListener('offline',net);net();
window.addEventListener('unhandledrejection',function(e){toast(friendly(e.reason))});
render();
if(window.YAApp&&window.YAApp.sharedName&&window.YAApp.sharedName()){window.__yaShared(window.YAApp.sharedName())}
})();
