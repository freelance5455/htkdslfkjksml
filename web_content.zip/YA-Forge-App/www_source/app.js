(function(){
'use strict';
var $=function(s){return document.querySelector(s)};
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function sleep(ms){return new Promise(function(r){setTimeout(r,ms)})}
var enc=new TextEncoder();

/* ---------- زبان‌ها ---------- */
var L={fa:{
 sub:'ساخت APK و AAB امضاشده روی GitHub خودت — رایگان',zip:'سایت ZIP‌شده',zipd:'فایل .zip که index.html دارد',html:'فایل HTML',htmld:'یک سند .html تنها',
 acc:'حساب',dl:'دانلودها',prj:'پروژه‌ها',recent:'اخیر',empty:'چیزی نیست.',need:'اول در «حساب»، توکن GitHub را وارد و کارخانه را راه‌اندازی کن.',
 badzip:'فایل باید .zip باشد',badhtml:'فایل باید .html باشد',back:'بازگشت',pname:'نام برنامه',ppkg:'شناسه بسته (package)',pvn:'نام نسخه',pvc:'شماره نسخه (عدد)',
 pcol:'رنگ اصلی',pfmt:'خروجی',fboth:'APK + AAB',fapk:'فقط APK',faab:'فقط AAB',picon:'آیکون (اختیاری)',pickicon:'انتخاب تصویر',iconok:'آیکون انتخاب شد ✓',
 src:'فایل منبع',chsrc:'تعویض فایل',srcready:'منبع روی GitHub آماده است ✓',srcmissing:'فایل منبع را دوباره انتخاب کن',build:'🚀 ساخت برنامه',
 bad_name:'نام برنامه را بنویس',bad_pkg:'شناسه بسته نامعتبر است (مثل app.yashar.mytool با حروف کوچک انگلیسی)',bad_vn:'نام نسخه نامعتبر است',bad_vc:'شماره نسخه باید عدد مثبت باشد',bad_col:'رنگ باید مثل #0E1118 باشد',
 big:'حجم فایل بیشتر از ۴۰ مگابایت است',up_src:'در حال آپلود فایل‌ها…',disp:'در حال شروع ساخت…',
 st_queued:'در صف…',st_running:'در حال ساخت…',st_ok:'ساخته شد ✓',st_fail:'ناموفق ✗',dlfile:'دانلود',dling:'در حال دانلود…',dlfail:'دانلود مستقیم نشد:',
 relpage:'باز کردن صفحه Release در مرورگر',openlog:'باز کردن لاگ ساخت',nf:'پیدا نشد.',failstep:'مرحله ناموفق:',minutes:'ساخت معمولاً ۴ تا ۸ دقیقه طول می‌کشد.',
 del:'حذف',open:'باز کردن',delc:'این پروژه از لیست حذف شود؟ (فایل‌های GitHub باقی می‌مانند)',
 tok:'توکن دسترسی GitHub',tokh:'GitHub ← Settings ← Developer settings ← Personal access tokens (classic) ← تیک repo و workflow',rn:'نام مخزن کارخانه',
 setup:'ذخیره و راه‌اندازی کارخانه',conn:'متصل به',ready:'کارخانه آماده است ✓',s1:'در حال اتصال به GitHub…',s2:'در حال ساخت مخزن خصوصی…',s3:'در حال گذاشتن قالب اندروید',
 badrepo:'نام مخزن نامعتبر است',notok:'اول توکن را وارد کن',lng:'زبان',keys:'پشتیبان کلیدهای امضا',keysh:'کلید امضای هر برنامه روی مخزن خصوصی تو ذخیره می‌شود. یک نسخه پشتیبان بیرون از GitHub هم نگه دار؛ با گم‌شدن کلید دیگر نمی‌توانی آپدیت بدهی.',
 nokeys:'هنوز کلیدی ساخته نشده.',about:'YA Forge · نسخه ۱.۰ · AAB، امضا و ساخت نامحدود — رایگان، روی حساب خودت',dlh:'ساخت‌های موفق',nodl:'هنوز ساختی نیست.',
 tokstay:'توکن فقط داخل همین برنامه روی گوشی می‌ماند.',done:'انجام شد ✓',saved:'ذخیره شد ✓',asset:'فایل',picked:'فایل انتخاب شد:',tokbtn:'۱) ساخت توکن در GitHub (صفحه باز می‌شود)',g_title:'راه‌اندازی در ۳ قدم',
 g1:'روی دکمه‌ی بالا بزن تا صفحه GitHub باز شود (اگر وارد نیستی، وارد حساب شو).',g2:'پایین صفحه روی «Generate token» بزن و توکن (که با ghp_ شروع می‌شود) را کپی کن.',g3:'برگرد به این اپ، توکن را در کادر زیر بچسبان و «ذخیره و راه‌اندازی کارخانه» را بزن.',
 pneed:'برای ساخت، اول در «حساب» توکن را وارد کن. فایل انتخاب‌شده می‌ماند.'
},en:{
 sub:'Signed APK & AAB builds on your own GitHub — free',zip:'Zipped site',zipd:'A .zip with index.html inside',html:'HTML file',htmld:'A single .html document',
 acc:'Account',dl:'Downloads',prj:'Projects',recent:'Recent',empty:'Nothing here.',need:'First enter your GitHub token in Account and set up the factory.',
 badzip:'File must be a .zip',badhtml:'File must be an .html',back:'Back',pname:'App name',ppkg:'Package id',pvn:'Version name',pvc:'Version code (number)',
 pcol:'Main color',pfmt:'Output',fboth:'APK + AAB',fapk:'APK only',faab:'AAB only',picon:'Icon (optional)',pickicon:'Choose image',iconok:'Icon selected ✓',
 src:'Source file',chsrc:'Replace file',srcready:'Source is ready on GitHub ✓',srcmissing:'Pick the source file again',build:'🚀 Build app',
 bad_name:'Enter the app name',bad_pkg:'Invalid package id (e.g. app.yashar.mytool, lowercase English)',bad_vn:'Invalid version name',bad_vc:'Version code must be a positive number',bad_col:'Color must look like #0E1118',
 big:'File is larger than 40 MB',up_src:'Uploading files…',disp:'Starting the build…',
 st_queued:'Queued…',st_running:'Building…',st_ok:'Built ✓',st_fail:'Failed ✗',dlfile:'Download',dling:'Downloading…',dlfail:'Direct download failed:',
 relpage:'Open the Release page in the browser',openlog:'Open build log',nf:'Not found.',failstep:'Failed step:',minutes:'A build usually takes 4–8 minutes.',
 del:'Delete',open:'Open',delc:'Remove this project from the list? (GitHub files stay)',
 tok:'GitHub access token',tokh:'GitHub → Settings → Developer settings → Personal access tokens (classic) → tick repo and workflow',rn:'Factory repo name',
 setup:'Save & set up factory',conn:'Connected as',ready:'Factory is ready ✓',s1:'Connecting to GitHub…',s2:'Creating a private repo…',s3:'Uploading the Android template',
 badrepo:'Invalid repo name',notok:'Enter the token first',lng:'Language',keys:'Back up signing keys',keysh:'Each app’s signing key lives in your private repo. Keep a backup outside GitHub too; if the key is lost you can no longer publish updates.',
 nokeys:'No keys yet.',about:'YA Forge · v1.0 · AAB, signing and unlimited builds — free, on your own account',dlh:'Successful builds',nodl:'No builds yet.',
 tokstay:'The token stays only inside this app on your phone.',done:'Done ✓',saved:'Saved ✓',asset:'File',picked:'File selected:',tokbtn:'1) Create a token on GitHub (opens the page)',g_title:'Setup in 3 steps',
 g1:'Tap the button above to open GitHub (sign in if needed).',g2:'Scroll down, tap “Generate token”, and copy the token (it starts with ghp_).',g3:'Come back to this app, paste the token below and tap “Save & set up factory”.',
 pneed:'To build, first enter your token in Account. Your selected file is kept.'
}};
var lang=localStorage.getItem('yf_lang')||(/^en/i.test(navigator.language||'')?'en':'fa');
function t(k){return(L[lang]&&L[lang][k])||L.fa[k]||k}
function applyDir(){document.documentElement.dir=lang==='fa'?'rtl':'ltr';document.documentElement.lang=lang}

/* ---------- وضعیت ---------- */
var S;try{S=JSON.parse(localStorage.getItem('yf')||'{}')}catch(e){S={}}
S.projects=S.projects||{};S.builds=S.builds||[];
function save(){localStorage.setItem('yf',JSON.stringify(S))}
var PEND={},PICON={},TM=null,REL=[];
function toast(m){var e=$('#toast');e.textContent=m;e.className='show';clearTimeout(toast.t);toast.t=setTimeout(function(){e.className=''},3200)}
function b64(u8){var s='';for(var i=0;i<u8.length;i+=32768)s+=String.fromCharCode.apply(null,u8.subarray(i,i+32768));return btoa(s)}
function readBuf(f){return new Promise(function(res,rej){var r=new FileReader();r.onload=function(){res(new Uint8Array(r.result))};r.onerror=function(){rej(new Error('read failed'))};r.readAsArrayBuffer(f)})}
function saveOut(name,u8,mime){
 if(window.YAApp){window.YAApp.saveFile(name,mime||'application/octet-stream',b64(u8))}
 else{var a=document.createElement('a');a.href=URL.createObjectURL(new Blob([u8]));a.download=name;document.body.appendChild(a);a.click()}}
function iconPng(file){return new Promise(function(res,rej){
 var img=new Image(),u=URL.createObjectURL(file);
 img.onload=function(){var c=document.createElement('canvas');c.width=c.height=512;var x=c.getContext('2d'),s=Math.min(img.width,img.height);
  x.drawImage(img,(img.width-s)/2,(img.height-s)/2,s,s,0,0,512,512);URL.revokeObjectURL(u);
  c.toBlob(function(b){if(!b)return rej(new Error('icon'));readBuf(b).then(res,rej)},'image/png')};
 img.onerror=function(){rej(new Error('icon'))};img.src=u})}
var CT=(function(){var T=[];for(var n=0;n<256;n++){var c=n;for(var k=0;k<8;k++)c=c&1?0xEDB88320^(c>>>1):c>>>1;T[n]=c>>>0}return T})();
function crc(b){var c=-1;for(var i=0;i<b.length;i++)c=CT[(c^b[i])&255]^(c>>>8);return(c^-1)>>>0}
function zip(files){
 var u16=function(n){return[n&255,(n>>8)&255]},u32=function(n){return[n&255,(n>>8)&255,(n>>16)&255,(n>>>24)&255]};
 var parts=[],cen=[],off=0;
 files.forEach(function(f){var nm=enc.encode(f.p),d=f.d,c=crc(d),n=d.length;
  var lh=new Uint8Array([0x50,0x4b,3,4,20,0,0,8,0,0,0,0,33,0].concat(u32(c),u32(n),u32(n),u16(nm.length),[0,0]));
  parts.push(lh,nm,d);
  cen.push(new Uint8Array([0x50,0x4b,1,2,20,0,20,0,0,8,0,0,0,0,33,0].concat(u32(c),u32(n),u32(n),u16(nm.length),[0,0,0,0,0,0,0,0,0,0,0,0],u32(off))),nm);
  off+=lh.length+nm.length+n});
 var cs=cen.reduce(function(a,x){return a+x.length},0);
 var end=new Uint8Array([0x50,0x4b,5,6,0,0,0,0].concat(u16(files.length),u16(files.length),u32(cs),u32(off),[0,0]));
 var all=parts.concat(cen,[end]),out=new Uint8Array(all.reduce(function(a,x){return a+x.length},0)),p=0;
 all.forEach(function(x){out.set(x,p);p+=x.length});return out}

/* ---------- GitHub ---------- */
async function gh(m,u,b){
 var h={Authorization:'Bearer '+S.token,Accept:'application/vnd.github+json'};if(b)h['Content-Type']='application/json';
 var r=await fetch(u.indexOf('http')===0?u:'https://api.github.com'+u,{method:m,headers:h,body:b?JSON.stringify(b):undefined,cache:'no-store'});
 var j={};try{j=await r.json()}catch(e){}
 if(!r.ok){var er=new Error('GitHub '+r.status+': '+(j.message||''));er.st=r.status;throw er}
 return j}
async function ghRaw(u,accept){
 var r=await fetch(u.indexOf('http')===0?u:'https://api.github.com'+u,{headers:{Authorization:'Bearer '+S.token,Accept:accept},cache:'no-store'});
 if(!r.ok)throw new Error('HTTP '+r.status);return new Uint8Array(await r.arrayBuffer())}
async function putFile(path,u8,msg){
 var sha;try{sha=(await gh('GET','/repos/'+S.repo+'/contents/'+path+'?ref='+S.branch)).sha}catch(e){if(e.st!==404)throw e}
 await gh('PUT','/repos/'+S.repo+'/contents/'+path,{message:msg,content:b64(u8),branch:S.branch,sha:sha})}

async function setup(say){
 if(!S.token)throw new Error(t('notok'));
 say(t('s1'));var me=await gh('GET','/user');S.login=me.login;
 var rn=($('#rn')&&$('#rn').value.trim())||S.rn||'ya-forge-factory';
 if(!/^[A-Za-z0-9._-]+$/.test(rn))throw new Error(t('badrepo'));S.rn=rn;
 var full=me.login+'/'+rn,info;
 try{info=await gh('GET','/repos/'+full)}catch(e){if(e.st!==404)throw e;say(t('s2'));info=await gh('POST','/user/repos',{name:rn,private:true,auto_init:true,description:'YA Forge factory'});await sleep(2500)}
 var br=info.default_branch||'main',head=null;
 for(var i=0;i<6&&!head;i++){try{head=await gh('GET','/repos/'+full+'/git/ref/heads/'+br)}catch(e){if(e.st!==404&&e.st!==409)throw e;await sleep(2000)}}
 if(!head)throw new Error('GitHub: empty repository');
 say(t('s3'));
 var tpl=await(await fetch('template.json',{cache:'no-store'})).json();
 var names=Object.keys(tpl.files),ents=[],idx=0;
 var base=(await gh('GET','/repos/'+full+'/git/commits/'+head.object.sha)).tree.sha;
 var worker=async function(){while(idx<names.length){var n=names[idx++],f=tpl.files[n];
  var b=await gh('POST','/repos/'+full+'/git/blobs',f.e==='b'?{content:f.d,encoding:'base64'}:{content:f.d,encoding:'utf-8'});
  ents.push({path:n,mode:'100644',type:'blob',sha:b.sha});say(t('s3')+' '+ents.length+'/'+names.length)}};
 await Promise.all([worker(),worker(),worker(),worker()]);
 var tr=await gh('POST','/repos/'+full+'/git/trees',{base_tree:base,tree:ents});
 var cm=await gh('POST','/repos/'+full+'/git/commits',{message:'YA Forge factory',tree:tr.sha,parents:[head.object.sha]});
 await gh('PATCH','/repos/'+full+'/git/refs/heads/'+br,{sha:cm.sha});
 S.repo=full;S.branch=br;S.ready=true;save()}

/* ---------- ساخت ---------- */
async function doBuild(id,say){
 if(!S.ready||!S.token){location.hash='#/acc';throw new Error(t('need'))}
 var p=S.projects[id];
 var name=$('#f_name').value.trim(),pkg=$('#f_pkg').value.trim(),vn=$('#f_vn').value.trim(),vc=parseInt($('#f_vc').value,10),col=$('#f_col').value.trim(),fmt=$('#f_fmt').value;
 if(!name)throw new Error(t('bad_name'));
 if(!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/.test(pkg))throw new Error(t('bad_pkg'));
 if(!/^[0-9A-Za-z._-]{1,20}$/.test(vn))throw new Error(t('bad_vn'));
 if(!(vc>0))throw new Error(t('bad_vc'));
 if(!/^#[0-9A-Fa-f]{6}$/.test(col))throw new Error(t('bad_col'));
 p.name=name;p.pkg=pkg;p.vn=vn;p.vc=vc;p.color=col;p.fmt=fmt;save();
 if(PEND[id]){say(t('up_src'));var u8=await readBuf(PEND[id]);if(u8.length>40*1048576)throw new Error(t('big'));
  await putFile('projects/'+id+'/'+(p.type==='zip'?'site.zip':'index.html'),u8,'source '+id);p.up=true;delete PEND[id];save()}
 if(!p.up)throw new Error(t('srcmissing'));
 if(PICON[id]){await putFile('projects/'+id+'/icon.png',PICON[id],'icon '+id);p.icon=true;delete PICON[id];save()}
 say(t('disp'));
 var bid=Math.random().toString(36).slice(2,8),done=false;
 var inputs={project_id:id,build_id:bid,app_name:name,package_id:pkg,version_name:vn,version_code:String(vc),primary_color:col,source_type:p.type,formats:fmt,has_icon:p.icon?'true':'false'};
 for(var i=0;i<6&&!done;i++){try{await gh('POST','/repos/'+S.repo+'/actions/workflows/factory.yml/dispatches',{ref:S.branch,inputs:inputs});done=true}catch(e){if(e.st!==404||i===5)throw e;await sleep(3000)}}
 S.builds.unshift({id:bid,pid:id,name:name,vn:vn,fmt:fmt,created:Date.now()});S.builds=S.builds.slice(0,30);
 p.vc=vc+1;save();return bid}

async function tick(b){
 try{
  if(!b.run){var r=await gh('GET','/repos/'+S.repo+'/actions/workflows/factory.yml/runs?event=workflow_dispatch&per_page=10'),m=null;
   (r.workflow_runs||[]).forEach(function(x){if((x.display_title||'').indexOf(b.id)>=0)m=x});if(m){b.run=m.id;b.url=m.html_url}}
  if(b.run){
   var ru=await gh('GET','/repos/'+S.repo+'/actions/runs/'+b.run);b.st=ru.status;b.cc=ru.conclusion;b.url=ru.html_url;
   var jb=await gh('GET','/repos/'+S.repo+'/actions/runs/'+b.run+'/jobs');
   b.steps=(((jb.jobs||[])[0]||{}).steps||[]).filter(function(s){return/^\d\)/.test(s.name)}).map(function(s){return{n:s.name,s:s.status,c:s.conclusion}});
   if(b.st==='completed'&&b.cc==='success'&&!b.assets){
    var rl=await gh('GET','/repos/'+S.repo+'/releases/tags/b-'+b.id);
    b.assets=(rl.assets||[]).map(function(a){return{name:a.name,size:a.size,url:a.url}});b.rel=rl.html_url}}
  b.err='';save()
 }catch(e){b.err=e.message}
 paint(b)}
function sOf(b){return b.cc==='success'?'ok':b.st==='completed'?'fail':(b.run&&b.st==='in_progress')?'running':'queued'}
function paint(b){
 var e=$('#bst');if(!e)return;var s=sOf(b);
 var h='<span class="badge '+(s==='queued'?'':s)+'">'+t('st_'+s)+'</span>';
 if(s==='queued'||s==='running')h+='<p class="m">'+t('minutes')+'</p>';
 (b.steps||[]).forEach(function(x){var ic=x.c==='success'?'✅':x.c==='failure'?'❌':x.s==='in_progress'?'⏳':'⚪';h+='<div class="r"><div class="i">'+ic+' '+esc(x.n)+'</div></div>'});
 if(s==='fail'){var f=(b.steps||[]).filter(function(x){return x.c==='failure'})[0];if(f)h+='<p>'+t('failstep')+' <b>'+esc(f.n)+'</b></p>';if(b.url)h+='<p><a href="'+esc(b.url)+'">'+t('openlog')+'</a></p>'}
 if(s==='ok'&&b.assets){b.assets.forEach(function(a,i){h+='<button data-a="dla" data-p="'+esc(b.id)+'|'+i+'">⬇️ '+esc(a.name)+' ('+(a.size/1048576).toFixed(1)+' MB)</button>'});
  if(b.rel)h+='<p class="m"><a href="'+esc(b.rel)+'">'+t('relpage')+'</a></p>'}
 if(b.err)h+='<p class="m">⚠️ '+esc(b.err)+'</p>';
 e.innerHTML=h}
async function dlAsset(a){
 if(window.YAApp&&window.YAApp.downloadAsset){window.YAApp.downloadAsset(a.name,a.url,S.token);return}
 toast(t('dling'));
 try{saveOut(a.name,await ghRaw(a.url,'application/octet-stream'))}
 catch(e){toast(t('dlfail')+' '+e.message)}}

/* ---------- نمایش‌ها ---------- */
function bt(a,p,l,c){return'<button class="'+(c||'')+'" data-a="'+a+'"'+(p!=null?' data-p="'+esc(p)+'"':'')+'>'+l+'</button>'}
function vHome(){
 var ok=S.ready&&S.token,h='';
 h+='<p class="m" style="margin:6px 4px">'+t('sub')+'</p>';
 if(!ok)h+='<div class="c warn">'+t('need')+'<br>'+bt('go','#/acc',t('acc'))+'</div>';
 h+='<div class="g2"><button type="button" class="big" data-pick="pick_zip"><span class="ic">🗜️</span><b>'+t('zip')+'</b><small>'+t('zipd')+'</small></button>'
  +'<button type="button" class="big" data-pick="pick_html"><span class="ic">&lt;/&gt;</span><b>'+t('html')+'</b><small>'+t('htmld')+'</small></button></div>'
  +'<input id="pick_zip" type="file" accept=".zip,application/zip" hidden data-c="pick" data-k="zip">'
  +'<input id="pick_html" type="file" accept=".html,.htm,text/html" hidden data-c="pick" data-k="html">';
 h+='<div class="g3" style="margin:12px 0">'+bt('go','#/acc','👤<br>'+t('acc'))+bt('go','#/dl','⬇️<br>'+t('dl'))+bt('go','#/prj','📚<br>'+t('prj'))+'</div>';
 h+='<div class="c"><h2>'+t('recent')+'</h2>';
 if(!S.builds.length)h+='<span class="m">'+t('empty')+'</span>';
 S.builds.slice(0,6).forEach(function(b){h+='<div class="r"><div class="i"><b>'+esc(b.name)+'</b> <span class="m">v'+esc(b.vn)+'</span></div><span class="badge '+(sOf(b)==='queued'?'':sOf(b))+'">'+t('st_'+sOf(b))+'</span>'+bt('go','#/b/'+b.id,t('open'),'s')+'</div>'});
 return h+'</div>'}
function vProject(id){
 var p=S.projects[id];if(!p)return'<div class="c">'+t('nf')+'</div>';
 var srcTxt=PEND[id]?esc(PEND[id].name):(p.up?t('srcready'):t('srcmissing'));
 var nb=(S.ready&&S.token)?'':'<div class="c warn">'+t('pneed')+'<br>'+bt('go','#/acc',t('acc'))+'</div>';
 return nb+'<div class="c">'+bt('go','#/prj',t('back'),'s')+'<h2>'+esc(p.name)+'</h2>'
 +'<label class="f">'+t('pname')+'</label><input id="f_name" value="'+esc(p.name)+'">'
 +'<label class="f">'+t('ppkg')+'</label><input id="f_pkg" dir="ltr" value="'+esc(p.pkg)+'">'
 +'<label class="f">'+t('pvn')+'</label><input id="f_vn" dir="ltr" value="'+esc(p.vn)+'">'
 +'<label class="f">'+t('pvc')+'</label><input id="f_vc" dir="ltr" inputmode="numeric" value="'+esc(p.vc)+'">'
 +'<label class="f">'+t('pcol')+'</label><input id="f_col" dir="ltr" value="'+esc(p.color)+'">'
 +'<label class="f">'+t('pfmt')+'</label><select id="f_fmt"><option value="both"'+(p.fmt==='both'?' selected':'')+'>'+t('fboth')+'</option><option value="apk"'+(p.fmt==='apk'?' selected':'')+'>'+t('fapk')+'</option><option value="aab"'+(p.fmt==='aab'?' selected':'')+'>'+t('faab')+'</option></select>'
 +'<label class="f">'+t('picon')+'</label><label class="b s">'+t('pickicon')+'<input type="file" accept="image/*" hidden data-c="icon" data-p="'+esc(id)+'"></label> <span class="m" id="ico">'+(PICON[id]||p.icon?t('iconok'):'')+'</span>'
 +'<label class="f">'+t('src')+' ('+(p.type==='zip'?'ZIP':'HTML')+')</label><div class="m">'+srcTxt+'</div>'
 +'<label class="b s">'+t('chsrc')+'<input type="file" hidden data-c="resrc" data-p="'+esc(id)+'"></label>'
 +'<button class="w" data-a="build" data-p="'+esc(id)+'">'+t('build')+'</button><div id="bs" class="m"></div></div>'}
function vBuild(id){
 var b=S.builds.filter(function(x){return x.id===id})[0];if(!b)return'<div class="c">'+t('nf')+'</div>';
 setTimeout(function(){tick(b)},0);TM=setInterval(function(){if(b.cc&&b.assets||b.st==='completed'&&b.cc!=='success'){clearInterval(TM);return}tick(b)},8000);
 return'<div class="c">'+bt('go','#/',t('back'),'s')+'<h2>'+esc(b.name)+' · v'+esc(b.vn)+'</h2><div id="bst"></div></div>'}
function vPrj(){
 var ids=Object.keys(S.projects).sort(function(a,b){return S.projects[b].created-S.projects[a].created});
 var h='<div class="c"><h2>'+t('prj')+'</h2>';if(!ids.length)h+='<span class="m">'+t('empty')+'</span>';
 ids.forEach(function(id){var p=S.projects[id];h+='<div class="r"><div class="i"><b>'+esc(p.name)+'</b><div class="m l">'+esc(p.pkg)+' · v'+esc(p.vn)+'</div></div>'+bt('go','#/p/'+id,t('open'),'s')+bt('delp',id,t('del'),'d')+'</div>'});
 return h+'</div>'}
async function vDl(){
 var rs=await gh('GET','/repos/'+S.repo+'/releases?per_page=30');REL=rs;
 var h='<div class="c"><h2>'+t('dlh')+'</h2>';
 if(!rs.length)h+='<span class="m">'+t('nodl')+'</span>';
 rs.forEach(function(r,i){h+='<div class="r"><div class="i"><b>'+esc(r.name||r.tag_name)+'</b><div class="m">'+new Date(r.published_at||r.created_at).toLocaleString(lang==='fa'?'fa-IR':'en-US')+'</div>';
  (r.assets||[]).forEach(function(a,j){h+=bt('dlr',i+'|'+j,'⬇️ '+esc(a.name),'s')});h+='</div></div>'});
 return h+'</div>'}
function vAcc(){
 return'<div class="c"><h2>👤 '+t('acc')+'</h2>'+(S.login?'<p class="m">'+t('conn')+' <b class="l">'+esc(S.login)+'</b> · <span class="l">'+esc(S.repo||'')+'</span></p>':'')
 +'<div class="c" style="background:#10151f"><b>'+t('g_title')+'</b><ol style="margin:6px 0;padding:0 22px"><li>'+t('g1')+'</li><li>'+t('g2')+'</li><li>'+t('g3')+'</li></ol><a class="b" href="https://github.com/settings/tokens/new?description=YA%20Forge&scopes=repo,workflow">'+t('tokbtn')+'</a></div>'
 +'<label class="f">'+t('tok')+'</label><input id="tk" type="password" dir="ltr" autocomplete="off" placeholder="'+(S.token?'••••'+esc(S.token.slice(-4)):'ghp_…')+'">'
 +'<p class="m">'+t('tokh')+'<br>'+t('tokstay')+'</p>'
 +'<label class="f">'+t('rn')+'</label><input id="rn" dir="ltr" value="'+esc(S.rn||'ya-forge-factory')+'">'
 +'<button class="w" data-a="setup">'+t('setup')+'</button><div id="as" class="m"></div></div>'
 +'<div class="c"><h2>🔐 '+t('keys')+'</h2><p class="m">'+t('keysh')+'</p>'+bt('keys',null,'⬇️ ZIP')+'</div>'
 +'<div class="c"><h2>🌐 '+t('lng')+'</h2><select data-c="lg"><option value="fa"'+(lang==='fa'?' selected':'')+'>فارسی</option><option value="en"'+(lang==='en'?' selected':'')+'>English</option></select></div>'
 +'<div class="c m">'+t('about')+'</div>'}

async function render(){
 clearInterval(TM);applyDir();
 var h=(location.hash||'#/').slice(1).split('/').filter(Boolean),html;
 try{
  if(h[0]==='acc')html=vAcc();
  else if(h[0]==='prj')html=vPrj();
  else if(h[0]==='p')html=vProject(h[1]);
  else if(h[0]==='b')html=vBuild(h[1]);
  else if(h[0]==='dl'){if(!S.repo){html='<div class="c warn">'+t('need')+'</div>'}else{html='<div class="c m">…</div>';$('#app').innerHTML=html;html=await vDl()}}
  else html=vHome();
 }catch(e){html='<div class="c">⚠️ '+esc(e.message)+'</div>'}
 $('#app').innerHTML=html;window.scrollTo(0,0)}

/* ---------- رویدادها ---------- */
var A={
 go:function(p){if(location.hash===p)render();else location.hash=p},
 lang:function(){lang=lang==='fa'?'en':'fa';localStorage.setItem('yf_lang',lang);render()},
 setup:async function(){
  var tk=$('#tk').value.trim();if(tk)S.token=tk;
  var say=function(x){$('#as').textContent=x};
  await setup(say);say(t('ready'));toast(t('ready'));setTimeout(render,1200)},
 build:async function(id){var say=function(x){$('#bs').textContent=x};var btn=$('[data-a=build]');btn.disabled=true;
  try{var bid=await doBuild(id,say);location.hash='#/b/'+bid}catch(e){say('');btn.disabled=false;throw e}},
 dla:function(p){var q=p.split('|'),b=S.builds.filter(function(x){return x.id===q[0]})[0];return dlAsset(b.assets[+q[1]])},
 dlr:function(p){var q=p.split('|'),a=REL[+q[0]].assets[+q[1]];return dlAsset({name:a.name,url:a.url})},
 delp:function(id){if(!confirm(t('delc')))return;delete S.projects[id];save();render()},
 keys:async function(){
  var list;try{list=await gh('GET','/repos/'+S.repo+'/contents/keys?ref='+S.branch)}catch(e){if(e.st===404)return toast(t('nokeys'));throw e}
  var files=[];for(var i=0;i<list.length;i++)files.push({p:list[i].name,d:await ghRaw(list[i].url,'application/vnd.github.raw')});
  saveOut('ya-forge-keys-backup.zip',zip(files),'application/zip')}
};
var C={
 pick:function(inp){var f=inp.files[0],kind=inp.getAttribute('data-k');inp.value='';if(!f)return;
  if(kind==='zip'&&!/\.zip$/i.test(f.name))return toast(t('badzip'));
  if(kind==='html'&&!/\.html?$/i.test(f.name))return toast(t('badhtml'));
  var base=f.name.replace(/\.[^.]+$/,''),slug=base.toLowerCase().replace(/[^a-z0-9]/g,'');
  if(!/^[a-z]/.test(slug))slug='app'+slug;slug=slug.slice(0,20);
  var id='p'+Date.now().toString(36);
  S.projects[id]={id:id,name:base.slice(0,40),pkg:'app.yashar.'+slug,vn:'1.0.0',vc:1,color:'#0E1118',fmt:'both',type:kind,up:false,icon:false,created:Date.now()};
  PEND[id]=f;save();toast(t('picked')+' '+f.name);location.hash='#/p/'+id},
 resrc:function(inp){var f=inp.files[0],id=inp.getAttribute('data-p');inp.value='';if(!f)return;var p=S.projects[id];
  if(/\.zip$/i.test(f.name))p.type='zip';else if(/\.html?$/i.test(f.name))p.type='html';else return toast(t('badhtml'));
  PEND[id]=f;save();render()},
 icon:async function(inp){var f=inp.files[0],id=inp.getAttribute('data-p');inp.value='';if(!f)return;PICON[id]=await iconPng(f);$('#ico').textContent=t('iconok')},
 lg:function(s){lang=s.value;localStorage.setItem('yf_lang',lang);render()}
};
document.addEventListener('click',async function(e){
 var pick=e.target.closest('[data-pick]');
 if(pick){var input=document.getElementById(pick.getAttribute('data-pick'));if(input)input.click();return}
 var b=e.target.closest('[data-a]');if(!b)return;
 try{await A[b.getAttribute('data-a')](b.getAttribute('data-p')||'',b)}catch(x){toast(x.message||String(x))}});
document.addEventListener('change',async function(e){var b=e.target.closest('[data-c]');if(!b)return;
 try{await C[b.getAttribute('data-c')](b)}catch(x){toast(x.message||String(x))}});
window.addEventListener('hashchange',render);
window.addEventListener('unhandledrejection',function(e){toast(String(e.reason&&e.reason.message||e.reason))});
render();
})();
