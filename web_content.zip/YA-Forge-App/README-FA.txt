YA Forge — ساخت APK و AAB امضاشده از HTML/ZIP، روی GitHub خودت.

۱) این پروژه را در یک مخزن GitHub بگذار (push). تب Actions اپ YA Forge را می‌سازد.
۲) اپ را نصب کن. در «حساب»: توکن GitHub (classic، تیک repo و workflow) را بده و «راه‌اندازی کارخانه» را بزن.
۳) فایل HTML یا ZIP را انتخاب کن، مشخصات را پر کن و «ساخت برنامه» را بزن.
۴) APK و AAB امضاشده در «دانلودها» می‌آید. کلید امضای هر برنامه ثابت است.

برای امضای ثابت خود YA Forge، Secretهای KEYSTORE_B64 و KEYSTORE_PASSWORD و KEY_ALIAS و KEY_PASSWORD را بساز.
