YA Forge — ساخت APK و AAB امضاشده از HTML، ZIP یا آدرس سایت، روی GitHub خودت.

راه‌اندازی:
۱) این پروژه را در یک مخزن «خصوصی» GitHub بگذار (push). تب Actions اپ YA Forge را می‌سازد.
   اگر مخزن عمومی باشد، ساخت عمداً متوقف می‌شود تا کلید امضا لو نرود؛ یا مخزن را خصوصی کن یا Secrets بساز.
۲) اپ را نصب کن. در «حساب»: توکن GitHub (classic، تیک repo و workflow) را بده و «ذخیره و راه‌اندازی» را بزن.
۳) از «خانه» فایل HTML، ZIP یا آدرس سایت را انتخاب کن، مشخصات را پر کن و «ساخت برنامه» را بزن.
   می‌توانی فایل را از تلگرام یا مدیر فایل هم با «اشتراک‌گذاری ← YA Forge» بفرستی.
۴) APK و AAB امضاشده در «دانلودها» می‌آید. کلید امضای هر برنامه ثابت است؛ از «حساب» پشتیبان بگیر.

برای امضای ثابت خود YA Forge می‌توانی Secretهای KEYSTORE_B64 و KEYSTORE_PASSWORD و KEY_ALIAS و KEY_PASSWORD را بسازی.

نسخه‌های ابزار: AGP 8.13.0، Kotlin 2.1.21، Gradle 8.13، compileSdk/targetSdk 36 (شرط فعلی Google Play).
ساخت محلی: ./scripts/build.sh  (یا --no-debug --formats apk|aab|both)
