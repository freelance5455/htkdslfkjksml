const $ = id => document.getElementById(id);
const fileInput = $("projectFile");
const buildBtn = $("buildBtn");
const statusBox = $("status");
const downloadLink = $("downloadLink");

const words = {
  ar: {
    subtitle:"حوّل مشروع Android المضغوط إلى تطبيق قابل للتثبيت",
    tag:"محول مشاريع أندرويد", headline:"من ZIP إلى APK بخطوات بسيطة",
    description:"ارفع ملف مشروع Android بصيغة ZIP، وسيفحصه الخادم ثم يحاول بناء نسخة APK تجريبية.",
    choose:"اختر ملف ZIP", hint:"اضغط هنا لاختيار الملف — الحد الأقصى 100 MB",
    noFile:"لم يتم اختيار ملف", build:"فحص وبناء APK", download:"تنزيل APK",
    requirementsTitle:"ما الذي يجب أن يحتويه ZIP؟",
    req1:"مشروع Android قابل للبناء باستخدام Gradle.",
    req2:"ملف settings.gradle أو settings.gradle.kts.",
    req3:"مجلد app وملفات البناء اللازمة.",
    warning:"مهم: هذا الموقع يحتاج إلى خادم عليه Node.js وGradle وAndroid SDK. صفحة HTML وحدها لا تستطيع إنشاء APK.",
    selected:"الملف المحدد: ", working:"جارٍ فحص المشروع وبناؤه... قد تستغرق العملية عدة دقائق.",
    done:"تم إنشاء APK بنجاح.", failed:"تعذر بناء APK: "
  },
  en: {
    subtitle:"Turn a zipped Android project into an installable app",
    tag:"Android project builder", headline:"From ZIP to APK in a few steps",
    description:"Upload a ZIP containing an Android project. The server will inspect it and try to build a debug APK.",
    choose:"Choose ZIP file", hint:"Tap to select a file — 100 MB maximum",
    noFile:"No file selected", build:"Check and build APK", download:"Download APK",
    requirementsTitle:"What must the ZIP contain?",
    req1:"An Android project that can be built with Gradle.",
    req2:"settings.gradle or settings.gradle.kts.",
    req3:"An app folder and required build files.",
    warning:"Note: This app needs a server with Node.js, Gradle and Android SDK. HTML alone cannot compile an APK.",
    selected:"Selected file: ", working:"Checking project and building... This may take several minutes.",
    done:"APK created successfully.", failed:"Could not build APK: "
  },
  ku: {
    subtitle:"پرۆژەی Android ـی ZIP بگۆڕە بۆ ئەپی دامەزرێنراو",
    tag:"دروستکەری پرۆژەی ئەندرۆید", headline:"لە ZIP بۆ APK بە چەند هەنگاوێک",
    description:"فایلی ZIP ـی پرۆژەی Android باربکە؛ سێرڤەر پشکنینی دەکات و هەوڵی دروستکردنی APK دەدات.",
    choose:"فایلی ZIP هەڵبژێرە", hint:"بۆ هەڵبژاردنی فایل کرتە بکە — زۆرترین قەبارە 100 MB",
    noFile:"هیچ فایلێک هەڵنەبژێردراوە", build:"پشکنین و دروستکردنی APK", download:"داگرتنی APK",
    requirementsTitle:"ZIP چی دەبێت لەخۆبگرێت؟",
    req1:"پرۆژەیەکی Android کە بە Gradle دروست دەکرێت.",
    req2:"فایلی settings.gradle یان settings.gradle.kts.",
    req3:"فۆڵدەری app و فایلەکانی پێویستی دروستکردن.",
    warning:"تێبینی: ئەم ئەپە پێویستی بە سێرڤەری Node.js و Gradle و Android SDK هەیە. HTML بە تەنها ناتوانێت APK دروست بکات.",
    selected:"فایلی هەڵبژێردراو: ", working:"پرۆژەکە پشکنین و دروست دەکرێت...",
    done:"APK بە سەرکەوتوویی دروست کرا.", failed:"دروستکردنی APK سەرکەوتوو نەبوو: "
  }
};

function setLanguage(lang) {
  const t = words[lang] || words.ar;
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === "en" ? "ltr" : "rtl";
  document.querySelectorAll("[data-i18n]").forEach(el => {
    const key = el.dataset.i18n;
    if (t[key]) el.textContent = t[key];
  });
  if (fileInput.files[0]) $("fileName").textContent = t.selected + fileInput.files[0].name;
}
$("language").addEventListener("change", e => setLanguage(e.target.value));

fileInput.addEventListener("change", () => {
  const file = fileInput.files[0];
  const t = words[$("language").value];
  $("fileName").textContent = file ? t.selected + file.name : t.noFile;
  buildBtn.disabled = !file || !file.name.toLowerCase().endsWith(".zip");
  statusBox.textContent = "";
  statusBox.className = "status";
  downloadLink.hidden = true;
});

buildBtn.addEventListener("click", async () => {
  const file = fileInput.files[0];
  if (!file) return;
  const t = words[$("language").value];
  const data = new FormData();
  data.append("project", file);
  buildBtn.disabled = true;
  statusBox.className = "status";
  statusBox.textContent = t.working;
  downloadLink.hidden = true;

  try {
    const response = await fetch("/api/build", { method: "POST", body: data });
    const type = response.headers.get("content-type") || "";
    if (!response.ok || type.includes("application/json")) {
      const error = await response.json();
      throw new Error(error.error + (error.details ? "\n" + error.details : ""));
    }
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    downloadLink.href = url;
    downloadLink.download = "app-debug.apk";
    downloadLink.hidden = false;
    statusBox.textContent = t.done;
    statusBox.classList.add("success");
  } catch (error) {
    statusBox.textContent = t.failed + error.message;
    statusBox.classList.add("error");
  } finally {
    buildBtn.disabled = false;
  }
});

setLanguage("ar");