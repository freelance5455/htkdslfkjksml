const express = require("express");
const multer = require("multer");
const AdmZip = require("adm-zip");
const fs = require("fs");
const os = require("os");
const path = require("path");
const { spawn } = require("child_process");

const app = express();
const PORT = process.env.PORT || 3000;
const MAX_FILE_BYTES = 100 * 1024 * 1024;
const BUILD_TIMEOUT_MS = 12 * 60 * 1000;
const upload = multer({
  dest: path.join(os.tmpdir(), "zip-apk-uploads"),
  limits: { fileSize: MAX_FILE_BYTES, files: 1 }
});

app.use(express.static(path.join(__dirname, "public")));
app.get("/api/health", (_req, res) => res.json({ ok: true }));

function extractSafely(zipPath, destination) {
  const zip = new AdmZip(zipPath);
  const base = path.resolve(destination) + path.sep;
  let total = 0;
  for (const entry of zip.getEntries()) {
    const output = path.resolve(destination, entry.entryName);
    if (!output.startsWith(base)) throw new Error("ملف ZIP يحتوي على مسار غير آمن.");
    if (!entry.isDirectory) {
      total += entry.header.size || 0;
      if (total > 500 * 1024 * 1024) throw new Error("حجم الملفات بعد فك الضغط أكبر من الحد المسموح.");
    }
    if (entry.isDirectory) fs.mkdirSync(output, { recursive: true });
    else {
      fs.mkdirSync(path.dirname(output), { recursive: true });
      fs.writeFileSync(output, entry.getData());
    }
  }
}

function locateProject(folder) {
  const dirs = [folder];
  for (const item of fs.readdirSync(folder, { withFileTypes: true })) {
    if (item.isDirectory()) dirs.push(path.join(folder, item.name));
  }
  return dirs.find(dir =>
    (fs.existsSync(path.join(dir, "settings.gradle")) ||
     fs.existsSync(path.join(dir, "settings.gradle.kts"))) &&
    fs.existsSync(path.join(dir, "app"))
  );
}

function locateApk(folder) {
  if (!fs.existsSync(folder)) return null;
  const queue = [folder];
  while (queue.length) {
    const dir = queue.shift();
    for (const item of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, item.name);
      if (item.isDirectory()) queue.push(full);
      else if (item.name.endsWith(".apk")) return full;
    }
  }
  return null;
}

function runBuild(projectRoot) {
  return new Promise(resolve => {
    const wrapper = process.platform === "win32" ? "gradlew.bat" : "./gradlew";
    const hasWrapper = fs.existsSync(path.join(projectRoot, wrapper));
    const command = hasWrapper ? wrapper : "gradle";
    const args = hasWrapper
      ? ["--no-daemon", "--stacktrace", "assembleDebug"]
      : ["--no-daemon", "--stacktrace", "assembleDebug"];

    const child = spawn(command, args, {
      cwd: projectRoot,
      env: {
        ...process.env,
        ANDROID_HOME: process.env.ANDROID_HOME || "/opt/android-sdk",
        ANDROID_SDK_ROOT: process.env.ANDROID_SDK_ROOT || "/opt/android-sdk"
      }
    });
    let log = "";
    let settled = false;
    const finish = result => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve({ ...result, log: log.slice(-12000) });
    };
    const timer = setTimeout(() => {
      child.kill("SIGKILL");
      finish({ code: -1, timedOut: true });
    }, BUILD_TIMEOUT_MS);
    child.stdout.on("data", d => { log += d.toString(); });
    child.stderr.on("data", d => { log += d.toString(); });
    child.on("error", e => finish({ code: -1, error: e.message }));
    child.on("close", code => finish({ code }));
  });
}

app.post("/api/build", upload.single("project"), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: "اختر ملف ZIP أولاً." });
  const work = fs.mkdtempSync(path.join(os.tmpdir(), "apk-build-"));
  const cleanup = () => {
    fs.rmSync(work, { recursive: true, force: true });
    if (req.file?.path) fs.rmSync(req.file.path, { force: true });
  };

  try {
    const extracted = path.join(work, "source");
    fs.mkdirSync(extracted);
    extractSafely(req.file.path, extracted);

    const projectRoot = locateProject(extracted);
    if (!projectRoot) {
      cleanup();
      return res.status(400).json({
        error: "لم أجد مشروع Android صالحاً. يلزم settings.gradle أو settings.gradle.kts ومجلد app."
      });
    }

    const hasBuildFile = ["build.gradle", "build.gradle.kts"]
      .some(name => fs.existsSync(path.join(projectRoot, name)));
    if (!hasBuildFile) {
      cleanup();
      return res.status(400).json({ error: "ملف build.gradle أو build.gradle.kts الرئيسي غير موجود." });
    }

    const result = await runBuild(projectRoot);
    if (result.code !== 0) {
      cleanup();
      return res.status(500).json({
        error: result.timedOut
          ? "انتهت مهلة البناء. جرّب مشروعاً أصغر أو خادماً بموارد أكبر."
          : "فشل بناء APK. تحقق من ملفات المشروع واعتماديات Gradle.",
        details: result.log || result.error || ""
      });
    }

    const apk = locateApk(path.join(projectRoot, "app", "build", "outputs", "apk"));
    if (!apk) {
      cleanup();
      return res.status(500).json({ error: "اكتمل البناء لكن لم يتم العثور على APK." });
    }

    res.download(apk, path.basename(apk), cleanup);
    res.on("close", cleanup);
  } catch (err) {
    cleanup();
    res.status(400).json({ error: err.message || "تعذر معالجة الملف." });
  }
});

app.use((err, _req, res, _next) => {
  if (err instanceof multer.MulterError && err.code === "LIMIT_FILE_SIZE") {
    return res.status(413).json({ error: "حجم الملف أكبر من 100 MB." });
  }
  res.status(400).json({ error: err.message || "حدث خطأ في الطلب." });
});

app.listen(PORT, "0.0.0.0", () => console.log(`ZIP to APK listening on ${PORT}`));
