const express = require("express");
const multer = require("multer");
const AdmZip = require("adm-zip");
const fs = require("fs");
const os = require("os");
const path = require("path");
const { spawn } = require("child_process");

const app = express();
const PORT = process.env.PORT || 3000;
const upload = multer({
  dest: path.join(os.tmpdir(), "zip-apk-uploads"),
  limits: { fileSize: 100 * 1024 * 1024, files: 1 }
});

app.use(express.static(path.join(__dirname, "public")));

function safeExtract(zipPath, destination) {
  const zip = new AdmZip(zipPath);
  const base = path.resolve(destination) + path.sep;
  for (const entry of zip.getEntries()) {
    const output = path.resolve(destination, entry.entryName);
    if (!output.startsWith(base)) {
      throw new Error("ملف ZIP يحتوي على مسار غير آمن.");
    }
    if (entry.isDirectory) {
      fs.mkdirSync(output, { recursive: true });
    } else {
      fs.mkdirSync(path.dirname(output), { recursive: true });
      fs.writeFileSync(output, entry.getData());
    }
  }
}

function findAndroidRoot(folder) {
  const candidates = [folder];
  for (const name of fs.readdirSync(folder, { withFileTypes: true })) {
    if (name.isDirectory()) candidates.push(path.join(folder, name.name));
  }
  return candidates.find(dir =>
    (fs.existsSync(path.join(dir, "settings.gradle")) ||
     fs.existsSync(path.join(dir, "settings.gradle.kts"))) &&
    fs.existsSync(path.join(dir, "app"))
  );
}

app.post("/api/build", upload.single("project"), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: "اختر ملف ZIP أولاً." });

  const work = fs.mkdtempSync(path.join(os.tmpdir(), "apk-build-"));
  const extracted = path.join(work, "source");

  try {
    fs.mkdirSync(extracted);
    safeExtract(req.file.path, extracted);

    const projectRoot = findAndroidRoot(extracted);
    if (!projectRoot) {
      return res.status(400).json({
        error: "لم أجد مشروع Android صالحاً. يجب أن يحتوي ZIP على settings.gradle أو settings.gradle.kts ومجلد app."
      });
    }

    const gradleFile = ["build.gradle", "build.gradle.kts"]
      .some(name => fs.existsSync(path.join(projectRoot, name)));
    if (!gradleFile) {
      return res.status(400).json({ error: "ملف بناء Gradle الرئيسي غير موجود." });
    }

    const apkDir = path.join(projectRoot, "app", "build", "outputs", "apk");
    const result = await new Promise(resolve => {
      const child = spawn("gradle", ["--no-daemon", "assembleDebug"], {
        cwd: projectRoot,
        env: process.env
      });
      let log = "";
      child.stdout.on("data", d => log += d.toString());
      child.stderr.on("data", d => log += d.toString());
      child.on("error", e => resolve({ code: -1, log: log + "\n" + e.message }));
      child.on("close", code => resolve({ code, log }));
    });

    if (result.code !== 0) {
      return res.status(500).json({
        error: "فشل بناء APK. تأكد من تثبيت Gradle وAndroid SDK وصحة المشروع.",
        details: result.log.slice(-5000)
      });
    }

    const apk = findApk(apkDir);
    if (!apk) {
      return res.status(500).json({ error: "اكتمل البناء لكن لم يتم العثور على ملف APK." });
    }

    res.download(apk, path.basename(apk), () => {
      fs.rmSync(work, { recursive: true, force: true });
      fs.rmSync(req.file.path, { force: true });
    });
    return;
  } catch (err) {
    return res.status(400).json({ error: err.message || "تعذر معالجة الملف." });
  } finally {
    fs.rmSync(req.file.path, { force: true });
    // Keep build folder until a successful download completes.
    if (!res.headersSent && !res.downloaded) {
      // On errors, clean up temporary files.
      setTimeout(() => fs.rmSync(work, { recursive: true, force: true }), 1000);
    }
  }
});

function findApk(dir) {
  if (!fs.existsSync(dir)) return null;
  const queue = [dir];
  while (queue.length) {
    const current = queue.shift();
    for (const item of fs.readdirSync(current, { withFileTypes: true })) {
      const full = path.join(current, item.name);
      if (item.isDirectory()) queue.push(full);
      else if (item.name.endsWith(".apk")) return full;
    }
  }
  return null;
}

app.listen(PORT, () => console.log(`ZIP to APK Converter running on port ${PORT}`));