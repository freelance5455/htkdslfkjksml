import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DEFAULT_MODEL = process.env.GEMINI_MODEL || "gemini-3.8-flash";
const CANDIDATE_MODELS = [
  DEFAULT_MODEL,
  "gemini-3.8-flash",
  "gemini-3.7-flash",
  "gemini-3.6-flash",
  "gemini-3.5-flash",
].filter((model, index, list) => Boolean(model) && list.indexOf(model) === index);

const jsonError = (res: express.Response, status: number, code: string, message: string) =>
  res.status(status).json({ error: message, code });

function getValidCustomKey(customKey?: unknown): string | null {
  if (typeof customKey !== "string") return null;
  const trimmed = customKey.trim();
  if (!trimmed || trimmed === "undefined" || trimmed === "null" || trimmed === "MY_GEMINI_API_KEY" || trimmed.length < 20) return null;
  return trimmed;
}

function getApiKey(customApiKey?: unknown): string | null {
  return getValidCustomKey(customApiKey) || getValidCustomKey(process.env.GEMINI_API_KEY);
}

function createClient(customApiKey?: unknown): GoogleGenAI {
  const apiKey = getApiKey(customApiKey);
  if (!apiKey) throw new Error("GEMINI_API_KEY_NOT_CONFIGURED");
  return new GoogleGenAI({ apiKey });
}

function isRetryable(message: string): boolean {
  return /(?:429|500|502|503|504|UNAVAILABLE|RESOURCE_EXHAUSTED|quota|rate.?limit|temporarily)/i.test(message);
}

export async function generateWithRetry(
  ai: GoogleGenAI,
  params: { contents: unknown; config?: Record<string, unknown>; model?: string }
) {
  const models = params.model ? [params.model, ...CANDIDATE_MODELS.filter((m) => m !== params.model)] : CANDIDATE_MODELS;
  let lastError: unknown = null;
  for (const model of models) {
    try {
      return await ai.models.generateContent({
        model,
        contents: params.contents as any,
        config: params.config as any,
      });
    } catch (error: any) {
      lastError = error;
      const message = error?.message || String(error);
      if (!isRetryable(message)) throw error;
    }
  }
  throw lastError instanceof Error ? lastError : new Error("GEMINI_GENERATION_FAILED");
}

const AI_RULES = `
أنت محرك تحليل مالي مساعد لمنصة EGX Pro. تعامل مع الأرقام الواردة باعتبارها مصدر الحقيقة الوحيد.
قواعد إلزامية:
1) لا تخترع سعرًا أو حجمًا أو مؤشرًا أو دعمًا أو مقاومة أو هدفًا أو وقف خسارة.
2) إذا كانت قيمة غير موجودة أو غير كافية تاريخيًا اكتب "N/A" أو "بيانات تاريخية غير كافية" بدل التخمين.
3) لا تعتبر TradingView مصدرًا للأسعار داخل المنصة؛ هو شارت خارجي فقط.
4) لا تصدر إشارة تنفيذية أقوى من signalGate أو signal المرسل من المحرك الكمي.
5) إذا signalGate=false فلا تنشئ Entry/Targets/Stop من عندك.
6) ميّز بين البيانات الخام Data و المؤشرات Calculated و السياق الخارجي External.
7) اذكر تاريخ أحدث جلسة وعدد الجلسات عند توفرهما.
8) لا تدّعي أن الذكاء الاصطناعي جلب بيانات سوق بنفسه.
9) اكتب بالعربية الواضحة، دون مبالغة أو ضمانات.
`;

function compactStockContext(stock: any): string {
  const t = stock?.technical || {};
  return [
    `السهم: ${stock?.name || "غير متاح"} | الكود: ${stock?.code || "غير متاح"}`,
    `مصدر البيانات: ${stock?.dataQuality?.source || "unknown"} | الحالة: ${stock?.dataQuality?.status || "unknown"}`,
    `أحدث جلسة: ${stock?.dataQuality?.asOfDate || "غير متاح"} | عدد الجلسات: ${stock?.dataQuality?.bars ?? "غير متاح"}`,
    `OHLC: O=${stock?.open ?? "N/A"}, H=${stock?.high ?? "N/A"}, L=${stock?.low ?? "N/A"}, C=${stock?.close ?? "N/A"}`,
    `التغير: ${stock?.changePercent ?? "N/A"}% | الحجم: ${stock?.volume ?? "N/A"} | القيمة: ${stock?.value ?? "N/A"}`,
    `الشمعة: ${stock?.candlestickPattern || "N/A"} | النوع: ${stock?.patternType || "N/A"}`,
    `RSI14=${t.rsi14 ?? "N/A"}, MACD-H=${t.macdHistogram ?? "N/A"}, StochK=${t.stochasticK ?? "N/A"}, CCI20=${t.cci20 ?? "N/A"}, ROC12=${t.roc12 ?? "N/A"}`,
    `ATR14=${t.atr14 ?? "N/A"}, BBWidth=${t.bollingerWidth ?? "N/A"}, RelVol20=${t.relativeVolume20 ?? "N/A"}, OBV=${t.obv ?? "N/A"}, MFI14=${t.mfi14 ?? "N/A"}, VWAP=${t.vwap ?? "N/A"}`,
    `ADX14=${t.adx14 ?? "N/A"}, +DI=${t.plusDI14 ?? "N/A"}, -DI=${t.minusDI14 ?? "N/A"}`,
    `SMA20=${t.sma20 ?? "N/A"}, SMA50=${t.sma50 ?? "N/A"}, EMA20=${t.ema20 ?? "N/A"}, EMA50=${t.ema50 ?? "N/A"}`,
    `Pivot=${stock?.pivot ?? "N/A"}, S1=${stock?.support1 ?? "N/A"}, S2=${stock?.support2 ?? "N/A"}, R1=${stock?.resistance1 ?? "N/A"}, R2=${stock?.resistance2 ?? "N/A"}`,
    `Signal=${stock?.signal || "N/A"} | Gate=${stock?.signalGate === true ? "true" : "false"} | Confidence=${stock?.confidence ?? "N/A"} | Regime=${stock?.marketRegime || "N/A"}`,
    `Entry=${stock?.entryZone || "N/A"} | T1=${stock?.target1 ?? "N/A"} | T2=${stock?.target2 ?? "N/A"} | SL=${stock?.stopLoss ?? "N/A"} | R:R=${stock?.riskReward || "N/A"}`,
  ].join("\n");
}

async function callGemini(prompt: string, customApiKey?: unknown, systemInstruction = AI_RULES) {
  const ai = createClient(customApiKey);
  const result = await generateWithRetry(ai, {
    contents: prompt,
    config: {
      systemInstruction,
      temperature: 0.2,
      maxOutputTokens: 1800,
    },
  });
  const text = result.text?.trim() || "";
  if (!text) throw new Error("EMPTY_AI_RESPONSE");
  return text;
}

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT || 3000);
  app.disable("x-powered-by");
  app.use(express.json({ limit: "5mb" }));

  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  app.get("/api/gemini/status", (_req, res) => {
    const configured = Boolean(getValidCustomKey(process.env.GEMINI_API_KEY));
    res.json({ configured, model: DEFAULT_MODEL, provider: "google-gemini", serverSideKey: configured });
  });

  app.post("/api/gemini/verify-key", async (req, res) => {
    const key = getValidCustomKey(req.body?.apiKey);
    if (!key) return jsonError(res, 400, "INVALID_API_KEY", "المفتاح فارغ أو غير صالح.");
    try {
      const ai = new GoogleGenAI({ apiKey: key });
      await generateWithRetry(ai, { contents: "اختبار اتصال قصير. أجب بكلمة: OK.", config: { maxOutputTokens: 10, temperature: 0 } });
      return res.json({ valid: true, model: DEFAULT_MODEL });
    } catch (error: any) {
      return jsonError(res, 400, "INVALID_API_KEY", error?.message || "تعذر التحقق من المفتاح.");
    }
  });

  app.post("/api/gemini/generate", async (req, res) => {
    const { prompt, systemInstruction, customApiKey } = req.body || {};
    if (typeof prompt !== "string" || !prompt.trim()) return jsonError(res, 400, "MISSING_PROMPT", "النص المطلوب تحليله غير موجود.");
    try {
      const text = await callGemini(prompt, customApiKey, `${AI_RULES}\n${typeof systemInstruction === "string" ? systemInstruction : ""}`);
      res.json({ text, model: DEFAULT_MODEL });
    } catch (error: any) {
      const message = error?.message || String(error);
      const code = /GEMINI_API_KEY_NOT_CONFIGURED/.test(message) ? "AI_NOT_CONFIGURED" : "AI_UNAVAILABLE";
      jsonError(res, code === "AI_NOT_CONFIGURED" ? 503 : 502, code, code === "AI_NOT_CONFIGURED" ? "محرك Gemini غير مهيأ على الخادم." : "تعذر الحصول على رد من Gemini دون استخدام بيانات بديلة.");
    }
  });

  app.post("/api/gemini/analyze-stock", async (req, res) => {
    const { stock, customApiKey } = req.body || {};
    if (!stock?.dataQuality || !Number.isFinite(stock.close)) return jsonError(res, 400, "INVALID_STOCK_CONTEXT", "بيانات السهم أو مصدرها غير صالح للتحليل.");
    const context = compactStockContext(stock);
    const prompt = `حلّل السهم التالي اعتمادًا على البيانات المرسلة فقط.\n\n${context}\n\nالمطلوب:\n- تشخيص الشمعة في سياق الاتجاه وليس بمعزل عنه.\n- قراءة RSI/MACD/ADX/الحجم إن كانت متاحة.\n- تفسير الدعم والمقاومة مع توضيح أنها مستويات محسوبة من السجل.\n- اذكر بوضوح إن كانت بوابة الإشارة مكتملة.\n- لا تنشئ مستويات سعرية بديلة إذا كانت القيم المطلوبة N/A.`;
    try {
      const text = await callGemini(prompt, customApiKey);
      res.json({ text, model: DEFAULT_MODEL });
    } catch (error: any) {
      const message = error?.message || String(error);
      jsonError(res, /GEMINI_API_KEY_NOT_CONFIGURED/.test(message) ? 503 : 502, /GEMINI_API_KEY_NOT_CONFIGURED/.test(message) ? "AI_NOT_CONFIGURED" : "AI_UNAVAILABLE", "تعذر تشغيل التحليل الذكي. لم يتم استخدام تقرير بديل أو أرقام مولدة.");
    }
  });

  app.post("/api/gemini/chat", async (req, res) => {
    const { messages, stockContext, customApiKey } = req.body || {};
    if (!Array.isArray(messages)) return jsonError(res, 400, "INVALID_MESSAGES", "سجل المحادثة غير صالح.");
    const context = stockContext?.dataQuality ? compactStockContext(stockContext) : "لا يوجد سياق سهم موثّق.";
    const recent = messages.slice(-8).map((m: any) => `${m.role === "user" ? "المستخدم" : "المساعد"}: ${String(m.content || "")}`).join("\n");
    const prompt = `سياق السهم:\n${context}\n\nالمحادثة الأخيرة:\n${recent}\n\nأجب عن السؤال الأخير فقط. لا تضف أرقامًا غير موجودة في السياق.`;
    try {
      const text = await callGemini(prompt, customApiKey);
      res.json({ text, model: DEFAULT_MODEL });
    } catch (error: any) {
      const message = error?.message || String(error);
      jsonError(res, /GEMINI_API_KEY_NOT_CONFIGURED/.test(message) ? 503 : 502, /GEMINI_API_KEY_NOT_CONFIGURED/.test(message) ? "AI_NOT_CONFIGURED" : "AI_UNAVAILABLE", "تعذر تشغيل حوار الذكاء الاصطناعي دون بيانات بديلة.");
    }
  });

  app.post("/api/gemini/scan-chart", async (req, res) => {
    const { stock, customApiKey } = req.body || {};
    if (!stock?.dataQuality || !Number.isFinite(stock.close)) return jsonError(res, 400, "INVALID_STOCK_CONTEXT", "بيانات السهم غير صالحة.");
    const context = compactStockContext(stock);
    const prompt = `نفّذ مسحًا فنيًا مختصرًا للسهم التالي.\n${context}\n\nقدّم: حالة الاتجاه، الزخم، السيولة، أقرب مستويات المراقبة المتاحة، وما إذا كانت بوابة الإشارة مكتملة. لا تخترع نسبة ثقة جديدة إن لم تكن مشتقة من signalGate/confidence المرسلة.`;
    try {
      const text = await callGemini(prompt, customApiKey);
      res.json({ text, model: DEFAULT_MODEL });
    } catch (error: any) {
      const message = error?.message || String(error);
      jsonError(res, /GEMINI_API_KEY_NOT_CONFIGURED/.test(message) ? 503 : 502, /GEMINI_API_KEY_NOT_CONFIGURED/.test(message) ? "AI_NOT_CONFIGURED" : "AI_UNAVAILABLE", "تعذر تشغيل ماسح الشارت. لا توجد نتيجة بديلة مخمّنة.");
    }
  });

  app.post("/api/gemini/market-structure", async (req, res) => {
    const { marketStats, topGainers, topLosers, volumeLeaders, customApiKey } = req.body || {};
    if (!marketStats) return jsonError(res, 400, "INVALID_MARKET_CONTEXT", "بيانات السوق غير موجودة.");
    const safe = JSON.stringify({ marketStats, topGainers, topLosers, volumeLeaders });
    const prompt = `حلّل اتساع السوق المصري بناءً على الكائن التالي فقط:\n${safe}\n\nافصل بين ما هو مقاس فعليًا وما هو استنتاج. لا تدّع حركة مؤسسية أو تجميعًا/تصريفًا ما لم تدعمها البيانات المرسلة.`;
    try {
      const text = await callGemini(prompt, customApiKey);
      res.json({ text, model: DEFAULT_MODEL });
    } catch (error: any) {
      const message = error?.message || String(error);
      jsonError(res, /GEMINI_API_KEY_NOT_CONFIGURED/.test(message) ? 503 : 502, /GEMINI_API_KEY_NOT_CONFIGURED/.test(message) ? "AI_NOT_CONFIGURED" : "AI_UNAVAILABLE", "تعذر تشغيل قراءة هيكل السوق دون استخدام نص بديل أو أرقام مولدة.");
    }
  });

  const publicDir = path.join(__dirname, "public");
  app.get("/egx-pro-cloud-standalone.html", (_req, res) => res.sendFile(path.join(publicDir, "egx-pro-cloud-standalone.html")));

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({ server: { middlewareMode: true }, appType: "spa" });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => res.sendFile(path.join(distPath, "index.html")));
  }

  app.listen(PORT, "0.0.0.0", () => console.log(`EGX Pro server running on :${PORT}`));
}

startServer().catch((error) => {
  console.error("Server failed to start:", error);
  process.exit(1);
});
