import type { HistoricalBar, SignalGate, TechnicalIndicators, TechnicalLevels } from "../types";

export const MIN_HISTORY = {
  rsi14: 15,
  macd: 35,
  trend: 50,
  full: 60,
} as const;

const finite = (value: unknown): value is number =>
  typeof value === "number" && Number.isFinite(value);

const round = (value: number, digits = 2): number => {
  const factor = 10 ** digits;
  return Math.round(value * factor) / factor;
};

const lastFinite = (values: Array<number | null | undefined>): number | null => {
  for (let i = values.length - 1; i >= 0; i--) {
    if (finite(values[i])) return values[i] as number;
  }
  return null;
};

export function sma(values: number[], period: number): number | null {
  if (values.length < period) return null;
  const slice = values.slice(-period);
  return round(slice.reduce((a, b) => a + b, 0) / period);
}

export function ema(values: number[], period: number): number | null {
  if (values.length < period) return null;
  const seed = values.slice(0, period).reduce((a, b) => a + b, 0) / period;
  let current = seed;
  const k = 2 / (period + 1);
  for (let i = period; i < values.length; i++) {
    current = values[i] * k + current * (1 - k);
  }
  return round(current);
}

export function rsi(values: number[], period = 14): number | null {
  if (values.length <= period) return null;
  let gains = 0;
  let losses = 0;
  for (let i = 1; i <= period; i++) {
    const delta = values[i] - values[i - 1];
    if (delta > 0) gains += delta;
    if (delta < 0) losses += Math.abs(delta);
  }
  let avgGain = gains / period;
  let avgLoss = losses / period;
  for (let i = period + 1; i < values.length; i++) {
    const delta = values[i] - values[i - 1];
    const gain = Math.max(delta, 0);
    const loss = Math.max(-delta, 0);
    avgGain = (avgGain * (period - 1) + gain) / period;
    avgLoss = (avgLoss * (period - 1) + loss) / period;
  }
  if (avgLoss === 0) return avgGain === 0 ? 50 : 100;
  return round(100 - 100 / (1 + avgGain / avgLoss), 1);
}

export function macd(values: number[], fastPeriod = 12, slowPeriod = 26, signalPeriod = 9) {
  if (values.length < slowPeriod + signalPeriod) {
    return { line: null, signal: null, histogram: null };
  }
  const fastSeries: number[] = [];
  const slowSeries: number[] = [];
  let fastCurrent = values.slice(0, fastPeriod).reduce((a, b) => a + b, 0) / fastPeriod;
  let slowCurrent = values.slice(0, slowPeriod).reduce((a, b) => a + b, 0) / slowPeriod;
  const kFast = 2 / (fastPeriod + 1);
  const kSlow = 2 / (slowPeriod + 1);
  for (let i = 0; i < values.length; i++) {
    if (i === 0) {
      fastSeries.push(fastCurrent);
      slowSeries.push(slowCurrent);
      continue;
    }
    fastCurrent = values[i] * kFast + fastCurrent * (1 - kFast);
    slowCurrent = values[i] * kSlow + slowCurrent * (1 - kSlow);
    fastSeries.push(fastCurrent);
    slowSeries.push(slowCurrent);
  }
  const macdSeries = fastSeries.map((v, i) => v - slowSeries[i]).slice(slowPeriod - 1);
  if (macdSeries.length < signalPeriod) {
    return { line: null, signal: null, histogram: null };
  }
  const signal = ema(macdSeries, signalPeriod);
  const line = lastFinite(macdSeries);
  return {
    line,
    signal,
    histogram: line !== null && signal !== null ? round(line - signal, 3) : null,
  };
}

export function stochastic(highs: number[], lows: number[], closes: number[], period = 14) {
  if (closes.length < period) return { k: null, d: null };
  const kSeries: number[] = [];
  for (let i = period - 1; i < closes.length; i++) {
    const highest = Math.max(...highs.slice(i - period + 1, i + 1));
    const lowest = Math.min(...lows.slice(i - period + 1, i + 1));
    const denominator = highest - lowest;
    kSeries.push(denominator === 0 ? 50 : ((closes[i] - lowest) / denominator) * 100);
  }
  const k = lastFinite(kSeries);
  const d = kSeries.length >= 3 ? sma(kSeries, 3) : null;
  return { k: k === null ? null : round(k, 1), d: d === null ? null : round(d, 1) };
}

export function williamsR(highs: number[], lows: number[], closes: number[], period = 14): number | null {
  if (closes.length < period) return null;
  const highest = Math.max(...highs.slice(-period));
  const lowest = Math.min(...lows.slice(-period));
  const denominator = highest - lowest;
  if (denominator === 0) return -50;
  return round(((highest - closes[closes.length - 1]) / denominator) * -100, 1);
}

export function cci(highs: number[], lows: number[], closes: number[], period = 20): number | null {
  if (closes.length < period) return null;
  const tp = closes.map((c, i) => (highs[i] + lows[i] + c) / 3);
  const window = tp.slice(-period);
  const mean = window.reduce((a, b) => a + b, 0) / period;
  const meanDeviation = window.reduce((a, b) => a + Math.abs(b - mean), 0) / period;
  if (meanDeviation === 0) return 0;
  return round((tp[tp.length - 1] - mean) / (0.015 * meanDeviation), 1);
}

export function roc(values: number[], period = 12): number | null {
  if (values.length <= period) return null;
  const previous = values[values.length - 1 - period];
  if (previous === 0) return null;
  return round(((values[values.length - 1] - previous) / previous) * 100, 2);
}

export function momentum(values: number[], period = 10): number | null {
  if (values.length <= period) return null;
  return round(values[values.length - 1] - values[values.length - 1 - period], 3);
}

export function trueRanges(highs: number[], lows: number[], closes: number[]): number[] {
  const tr: number[] = [];
  for (let i = 0; i < highs.length; i++) {
    if (i === 0) {
      tr.push(highs[i] - lows[i]);
      continue;
    }
    tr.push(
      Math.max(
        highs[i] - lows[i],
        Math.abs(highs[i] - closes[i - 1]),
        Math.abs(lows[i] - closes[i - 1])
      )
    );
  }
  return tr;
}

export function atr(highs: number[], lows: number[], closes: number[], period = 14): number | null {
  const tr = trueRanges(highs, lows, closes);
  return sma(tr, period);
}

export function bollinger(values: number[], period = 20, multiplier = 2) {
  if (values.length < period) return { middle: null, upper: null, lower: null, width: null };
  const slice = values.slice(-period);
  const middle = slice.reduce((a, b) => a + b, 0) / period;
  const variance = slice.reduce((sum, value) => sum + (value - middle) ** 2, 0) / period;
  const std = Math.sqrt(variance);
  const upper = middle + multiplier * std;
  const lower = middle - multiplier * std;
  return {
    middle: round(middle),
    upper: round(upper),
    lower: round(lower),
    width: middle !== 0 ? round(((upper - lower) / middle) * 100, 2) : null,
  };
}

export function obv(closes: number[], volumes: number[]): number | null {
  if (closes.length < 2 || volumes.length !== closes.length || volumes.every((v) => !v)) return null;
  let current = 0;
  for (let i = 1; i < closes.length; i++) {
    if (closes[i] > closes[i - 1]) current += volumes[i];
    if (closes[i] < closes[i - 1]) current -= volumes[i];
  }
  return round(current, 0);
}

export function mfi(highs: number[], lows: number[], closes: number[], volumes: number[], period = 14): number | null {
  if (closes.length < period + 1 || volumes.length !== closes.length || volumes.every((v) => !v)) return null;
  let positive = 0;
  let negative = 0;
  for (let i = closes.length - period; i < closes.length; i++) {
    const typical = (highs[i] + lows[i] + closes[i]) / 3;
    const prevTypical = (highs[i - 1] + lows[i - 1] + closes[i - 1]) / 3;
    const money = typical * volumes[i];
    if (typical > prevTypical) positive += money;
    if (typical < prevTypical) negative += money;
  }
  if (negative === 0) return positive === 0 ? 50 : 100;
  return round(100 - 100 / (1 + positive / negative), 1);
}

export function vwap(highs: number[], lows: number[], closes: number[], volumes: number[]): number | null {
  if (volumes.length !== closes.length || volumes.every((v) => !v)) return null;
  let sumPV = 0;
  let sumV = 0;
  for (let i = 0; i < closes.length; i++) {
    const typical = (highs[i] + lows[i] + closes[i]) / 3;
    const volume = Math.max(0, volumes[i]);
    sumPV += typical * volume;
    sumV += volume;
  }
  return sumV === 0 ? null : round(sumPV / sumV);
}

export function adx(highs: number[], lows: number[], closes: number[], period = 14) {
  if (closes.length < period * 2) return { adx: null, plusDI: null, minusDI: null };
  const trs: number[] = [];
  const plusDM: number[] = [];
  const minusDM: number[] = [];
  for (let i = 1; i < closes.length; i++) {
    const up = highs[i] - highs[i - 1];
    const down = lows[i - 1] - lows[i];
    plusDM.push(up > down && up > 0 ? up : 0);
    minusDM.push(down > up && down > 0 ? down : 0);
    trs.push(Math.max(highs[i] - lows[i], Math.abs(highs[i] - closes[i - 1]), Math.abs(lows[i] - closes[i - 1])));
  }
  const dx: number[] = [];
  let lastPlus: number | null = null;
  let lastMinus: number | null = null;
  for (let i = period; i <= trs.length; i++) {
    const trSum = trs.slice(i - period, i).reduce((a, b) => a + b, 0);
    if (trSum === 0) continue;
    const plusSum = plusDM.slice(i - period, i).reduce((a, b) => a + b, 0);
    const minusSum = minusDM.slice(i - period, i).reduce((a, b) => a + b, 0);
    const pdi = (plusSum / trSum) * 100;
    const mdi = (minusSum / trSum) * 100;
    const total = pdi + mdi;
    const currentDx = total === 0 ? 0 : (Math.abs(pdi - mdi) / total) * 100;
    dx.push(currentDx);
    lastPlus = pdi;
    lastMinus = mdi;
  }
  const adxValue = sma(dx, period);
  return {
    adx: adxValue,
    plusDI: lastPlus === null ? null : round(lastPlus, 1),
    minusDI: lastMinus === null ? null : round(lastMinus, 1),
  };
}

export function ichimoku(highs: number[], lows: number[], closes: number[]) {
  if (closes.length < 52) {
    return { tenkan: null, kijun: null, senkouA: null, senkouB: null, chikou: null };
  }
  const midpoint = (period: number, endIndex: number) => {
    const start = Math.max(0, endIndex - period + 1);
    const h = Math.max(...highs.slice(start, endIndex + 1));
    const l = Math.min(...lows.slice(start, endIndex + 1));
    return (h + l) / 2;
  };
  const i = closes.length - 1;
  const tenkan = midpoint(9, i);
  const kijun = midpoint(26, i);
  const senkouB = midpoint(52, i);
  const senkouA = (tenkan + kijun) / 2;
  return {
    tenkan: round(tenkan),
    kijun: round(kijun),
    senkouA: round(senkouA),
    senkouB: round(senkouB),
    chikou: round(closes[Math.max(0, i - 26)]),
  };
}

export function classicPivots(high: number, low: number, close: number) {
  if (![high, low, close].every(finite) || high < low || close < 0) {
    return { pivot: null, r1: null, r2: null, s1: null, s2: null };
  }
  const pivot = (high + low + close) / 3;
  return {
    pivot: round(pivot),
    r1: round(2 * pivot - low),
    r2: round(pivot + (high - low)),
    s1: round(2 * pivot - high),
    s2: round(pivot - (high - low)),
  };
}

export function camarilla(high: number, low: number, close: number) {
  const range = high - low;
  if (![high, low, close].every(finite) || range <= 0) {
    return { h3: null, h4: null, l3: null, l4: null };
  }
  return {
    h3: round(close + (range * 1.1) / 4),
    h4: round(close + (range * 1.1) / 2),
    l3: round(close - (range * 1.1) / 4),
    l4: round(close - (range * 1.1) / 2),
  };
}

function isLocalLow(bars: HistoricalBar[], i: number, radius = 2): boolean {
  const low = bars[i].low;
  for (let d = 1; d <= radius; d++) {
    if (i - d >= 0 && bars[i - d].low < low) return false;
    if (i + d < bars.length && bars[i + d].low < low) return false;
  }
  return true;
}

function isLocalHigh(bars: HistoricalBar[], i: number, radius = 2): boolean {
  const high = bars[i].high;
  for (let d = 1; d <= radius; d++) {
    if (i - d >= 0 && bars[i - d].high > high) return false;
    if (i + d < bars.length && bars[i + d].high > high) return false;
  }
  return true;
}

export function structuralLevels(bars: HistoricalBar[], currentClose: number): Pick<TechnicalLevels, "supports" | "resistances" | "source"> {
  const window = bars.slice(-60);
  const supports = window.filter((_, i) => isLocalLow(window, i) && window[i].low < currentClose).map((b) => b.low).sort((a, b) => b - a);
  const resistances = window.filter((_, i) => isLocalHigh(window, i) && window[i].high > currentClose).map((b) => b.high).sort((a, b) => a - b);
  const dedupe = (values: number[]) => {
    const result: number[] = [];
    for (const value of values) {
      if (!result.some((v) => Math.abs(v - value) / Math.max(0.01, value) < 0.003)) result.push(value);
      if (result.length >= 4) break;
    }
    return result;
  };
  return {
    supports: dedupe(supports),
    resistances: dedupe(resistances),
    source: window.length >= 10 ? "historical-swings" : "insufficient-history",
  };
}

export function calculateTechnicalIndicators(bars: HistoricalBar[]): TechnicalIndicators {
  const clean = bars
    .filter((b) => [b.open, b.high, b.low, b.close].every(finite))
    .sort((a, b) => String(a.date).localeCompare(String(b.date)));
  const closes = clean.map((b) => b.close);
  const highs = clean.map((b) => b.high);
  const lows = clean.map((b) => b.low);
  const volumes = clean.map((b) => finite(b.volume) ? b.volume : 0);
  const macdValues = macd(closes);
  const stoch = stochastic(highs, lows, closes);
  const tr = trueRanges(highs, lows, closes);
  const averageVolume20 = sma(volumes, 20);
  const currentVolume = volumes.at(-1) ?? 0;
  const relVol = averageVolume20 && currentVolume > 0 ? round(currentVolume / averageVolume20, 2) : null;
  const bb = bollinger(closes);
  const adxResult = adx(highs, lows, closes);
  const ichi = ichimoku(highs, lows, closes);
  const close = closes.at(-1) ?? null;
  const volatility = closes.length >= 20 ? round(Math.sqrt(closes.slice(-20).reduce((sum, value, i, arr) => {
    if (i === 0) return sum;
    const ret = (value - arr[i - 1]) / arr[i - 1];
    return sum + ret * ret;
  }, 0) / Math.max(1, closes.slice(-20).length - 1)) * Math.sqrt(252) * 100, 2) : null;

  return {
    bars: clean.length,
    sma5: sma(closes, 5), sma10: sma(closes, 10), sma20: sma(closes, 20), sma50: sma(closes, 50), sma100: sma(closes, 100), sma200: sma(closes, 200),
    ema9: ema(closes, 9), ema12: ema(closes, 12), ema20: ema(closes, 20), ema26: ema(closes, 26), ema50: ema(closes, 50), ema200: ema(closes, 200),
    rsi14: rsi(closes, 14),
    macd: macdValues.line,
    macdSignal: macdValues.signal,
    macdHistogram: macdValues.histogram,
    stochasticK: stoch.k,
    stochasticD: stoch.d,
    williamsR: williamsR(highs, lows, closes),
    cci20: cci(highs, lows, closes),
    roc12: roc(closes),
    momentum10: momentum(closes),
    atr14: atr(highs, lows, closes),
    bollingerMiddle: bb.middle,
    bollingerUpper: bb.upper,
    bollingerLower: bb.lower,
    bollingerWidth: bb.width,
    volatility20Annualized: volatility,
    volumeSma20: averageVolume20 === null ? null : round(averageVolume20, 0),
    relativeVolume20: relVol,
    obv: obv(closes, volumes),
    mfi14: mfi(highs, lows, closes, volumes),
    vwap: vwap(highs, lows, closes, volumes),
    adx14: adxResult.adx === null ? null : round(adxResult.adx, 1),
    plusDI14: adxResult.plusDI,
    minusDI14: adxResult.minusDI,
    ichimokuTenkan: ichi.tenkan,
    ichimokuKijun: ichi.kijun,
    ichimokuSenkouA: ichi.senkouA,
    ichimokuSenkouB: ichi.senkouB,
    ichimokuChikou: ichi.chikou,
    trueRange14: sma(tr, 14),
    lastClose: close,
  };
}

export function deriveSignal(
  indicators: TechnicalIndicators,
  patternType: "bullish" | "bearish" | "neutral",
  currentClose: number,
  previousClose?: number | null
): SignalGate {
  const required = [indicators.rsi14, indicators.ema20, indicators.ema50, indicators.macdHistogram, indicators.adx14];
  const historyReady = indicators.bars >= MIN_HISTORY.trend && required.every((v) => finite(v));
  if (!historyReady) {
    return {
      signal: "بيانات غير كافية",
      gatePassed: false,
      confidence: null,
      regime: "غير محدد — يلزم سجل تاريخي كافٍ",
      reasons: [
        `عدد الجلسات المتاحة: ${indicators.bars}؛ الحد الأدنى للتحليل الاتجاهي: ${MIN_HISTORY.trend}`,
      ],
    };
  }

  const relVolOk = indicators.relativeVolume20 === null || indicators.relativeVolume20 >= 1;
  const bullishChecks = [
    currentClose > (indicators.ema20 as number),
    (indicators.ema20 as number) > (indicators.ema50 as number),
    (indicators.rsi14 as number) >= 50,
    (indicators.macdHistogram as number) > 0,
    (indicators.adx14 as number) >= 18,
    patternType === "bullish",
    relVolOk,
  ];
  const bearishChecks = [
    currentClose < (indicators.ema20 as number),
    (indicators.ema20 as number) < (indicators.ema50 as number),
    (indicators.rsi14 as number) < 50,
    (indicators.macdHistogram as number) < 0,
    (indicators.adx14 as number) >= 18,
    patternType === "bearish",
    relVolOk,
  ];
  const bull = bullishChecks.filter(Boolean).length;
  const bear = bearishChecks.filter(Boolean).length;
  const confidence = Math.round((Math.max(bull, bear) / bullishChecks.length) * 100);
  const trend = currentClose > (indicators.ema20 as number) ? "صاعد" : currentClose < (indicators.ema20 as number) ? "هابط" : "محايد";
  const regime = (indicators.adx14 as number) >= 25 ? `اتجاه ${trend} واضح (ADX ${round(indicators.adx14 as number, 1)})` : `تذبذب/اتجاه ${trend} متوسط (ADX ${round(indicators.adx14 as number, 1)})`;

  if (bull >= 5 && bull > bear) {
    return { signal: bull >= 6 ? "شراء قوي" : "شراء مع تأكيد", gatePassed: true, confidence, regime, reasons: [
      `الإغلاق ${currentClose > (indicators.ema20 as number) ? "فوق" : "دون"} EMA20`,
      `RSI14 = ${indicators.rsi14}`,
      `MACD Histogram = ${indicators.macdHistogram}`,
      `ADX14 = ${indicators.adx14}`,
    ]};
  }
  if (bear >= 5 && bear > bull) {
    return { signal: "حذر ووقف خسارة", gatePassed: true, confidence, regime, reasons: [
      `الإغلاق ${currentClose < (indicators.ema20 as number) ? "دون" : "فوق"} EMA20`,
      `RSI14 = ${indicators.rsi14}`,
      `MACD Histogram = ${indicators.macdHistogram}`,
      `ADX14 = ${indicators.adx14}`,
    ]};
  }
  const nearPrevious = finite(previousClose) && Math.abs(currentClose - (previousClose as number)) / Math.max(0.01, currentClose) < 0.01;
  return {
    signal: nearPrevious ? "ترقب" : bull > bear ? "شراء مع تأكيد" : bear > bull ? "جني أرباح" : "ترقب",
    gatePassed: false,
    confidence,
    regime,
    reasons: ["بوابة التأكيد الكمية لم تكتمل؛ لا توجد إشارة تنفيذية مؤكدة."],
  };
}

export function calculateLevels(bars: HistoricalBar[], close: number, high: number, low: number) {
  const pivots = classicPivots(high, low, close);
  const cam = camarilla(high, low, close);
  const structure = structuralLevels(bars, close);
  const support1 = structure.supports[0] ?? pivots.s1;
  const support2 = structure.supports[1] ?? pivots.s2;
  const resistance1 = structure.resistances[0] ?? pivots.r1;
  const resistance2 = structure.resistances[1] ?? pivots.r2;
  const swingHigh = Math.max(...bars.slice(-60).map((b) => b.high));
  const swingLow = Math.min(...bars.slice(-60).map((b) => b.low));
  const fib = swingHigh > swingLow && Number.isFinite(swingHigh) ? {
    level0: round(swingHigh),
    level236: round(swingHigh - (swingHigh - swingLow) * 0.236),
    level382: round(swingHigh - (swingHigh - swingLow) * 0.382),
    level500: round(swingHigh - (swingHigh - swingLow) * 0.5),
    level618: round(swingHigh - (swingHigh - swingLow) * 0.618),
    level786: round(swingHigh - (swingHigh - swingLow) * 0.786),
    level100: round(swingLow),
  } : null;
  return { ...pivots, ...cam, support1, support2, resistance1, resistance2, supports: structure.supports, resistances: structure.resistances, fib, source: structure.source };
}
