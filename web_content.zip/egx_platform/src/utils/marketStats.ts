import type { MarketStats, StockData } from "../types";

export function calculateMarketStats(stocks: StockData[], date: string): MarketStats {
  const usable = stocks.filter((s) => Number.isFinite(s.close));
  const withChange = usable.filter((s) => Number.isFinite(s.changePercent));
  const advancers = withChange.filter((s) => (s.changePercent as number) > 0).length;
  const decliners = withChange.filter((s) => (s.changePercent as number) < 0).length;
  const unchanged = withChange.filter((s) => (s.changePercent as number) === 0).length;
  const totalVolume = usable.reduce((sum, s) => sum + (s.volume ?? 0), 0);
  const totalValue = usable.reduce((sum, s) => sum + (s.value ?? 0), 0);
  let marketSentiment: MarketStats["marketSentiment"] = "غير متاح";
  if (withChange.length) {
    const breadth = (advancers - decliners) / withChange.length;
    marketSentiment = breadth > 0.25 ? "إيجابي قوي" : breadth > 0.05 ? "إيجابي معتدل" : breadth < -0.25 ? "تصحيح حاد" : breadth < -0.05 ? "سلبي وجني أرباح" : "متذبذب / محايد";
  }
  return {
    date,
    totalStocks: usable.length,
    advancers,
    decliners,
    unchanged,
    totalVolume,
    totalValue,
    marketSentiment,
    topGainer: [...withChange].sort((a, b) => (b.changePercent as number) - (a.changePercent as number))[0],
    topLoser: [...withChange].sort((a, b) => (a.changePercent as number) - (b.changePercent as number))[0],
    mostActiveByValue: [...usable].sort((a, b) => (b.value ?? -1) - (a.value ?? -1))[0],
  };
}
