import * as XLSX from "xlsx";
import type { HistoricalBar, StockData } from "../types";
import { enrichStockTechnicalData } from "./candlestickAnalyzer";
import { resolveTradingViewSymbol } from "../data/egxTickers";

const DATE_ALIASES = ["date", "التاريخ", "تاريخ", "التاريخ"];
const NAME_ALIASES = ["اسم السهم", "الاسم", "اسم", "الشركة", "الورقة", "company", "security", "name"];
const CODE_ALIASES = ["الكود", "كود", "رمز التداول", "رمز", "ticker", "symbol", "code"];
const OPEN_ALIASES = ["الفتح", "افتتاح", "سعر الفتح", "open"];
const HIGH_ALIASES = ["الأعلى", "اعلى", "أعلى", "high"];
const LOW_ALIASES = ["الأدنى", "ادنى", "أدنى", "low"];
const CLOSE_ALIASES = ["الإغلاق", "اغلاق", "إقفال", "الاخير", "آخر", "close", "last", "price"];
const VOLUME_ALIASES = ["الحجم", "كمية التداول", "كمية", "volume", "qty", "quantity"];
const VALUE_ALIASES = ["قيمة التداول", "القيمة", "قيمة", "turnover", "value"];
const TRADES_ALIASES = ["عدد العمليات", "الصفقات", "عدد الصفقات", "trades", "transactions"];
const SECTOR_ALIASES = ["القطاع", "sector"];

function normalizeText(value: unknown): string {
  return String(value ?? "")
    .normalize("NFKC")
    .replace(/[ًٌٍَُِّْـ]/g, "")
    .replace(/[إأآا]/g, "ا")
    .replace(/ى/g, "ي")
    .replace(/ة/g, "ه")
    .toLowerCase()
    .trim();
}

function parseNumber(value: unknown): number | null {
  if (value === null || value === undefined || value === "") return null;
  if (typeof value === "number") return Number.isFinite(value) ? value : null;
  const normalized = String(value)
    .replace(/[٬،]/g, ",")
    .replace(/[٫]/g, ".")
    .replace(/,/g, "")
    .replace(/٪/g, "%")
    .trim();
  const number = Number.parseFloat(normalized.replace(/%$/, ""));
  return Number.isFinite(number) ? number : null;
}

function parseDate(value: unknown, fallback: string): string {
  if (value instanceof Date && !Number.isNaN(value.getTime())) {
    return value.toISOString().slice(0, 10);
  }
  if (typeof value === "number" && Number.isFinite(value)) {
    const parsed = XLSX.SSF.parse_date_code(value);
    if (parsed) {
      const y = String(parsed.y).padStart(4, "0");
      const m = String(parsed.m).padStart(2, "0");
      const d = String(parsed.d).padStart(2, "0");
      return `${y}-${m}-${d}`;
    }
  }
  const raw = String(value ?? "").trim();
  if (!raw) return fallback;
  const isoLike = raw.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$/);
  if (isoLike) return `${isoLike[1]}-${isoLike[2].padStart(2, "0")}-${isoLike[3].padStart(2, "0")}`;
  const dmy = raw.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})$/);
  if (dmy) return `${dmy[3]}-${dmy[2].padStart(2, "0")}-${dmy[1].padStart(2, "0")}`;
  const parsed = new Date(raw);
  return Number.isNaN(parsed.getTime()) ? fallback : parsed.toISOString().slice(0, 10);
}

function findHeaderIndex(rows: unknown[][]): number {
  let bestIndex = -1;
  let bestScore = -1;
  for (let i = 0; i < Math.min(20, rows.length); i++) {
    const cells = Array.isArray(rows[i]) ? rows[i].map(normalizeText) : [];
    if (!cells.length) continue;
    const score = [
      DATE_ALIASES,
      NAME_ALIASES,
      CODE_ALIASES,
      OPEN_ALIASES,
      HIGH_ALIASES,
      LOW_ALIASES,
      CLOSE_ALIASES,
      VOLUME_ALIASES,
      VALUE_ALIASES,
    ].reduce((total, aliases) => total + (cells.some((cell) => aliases.some((a) => cell === normalizeText(a) || cell.includes(normalizeText(a)))) ? 1 : 0), 0);
    if (score > bestScore) {
      bestScore = score;
      bestIndex = i;
    }
  }
  return bestScore >= 3 ? bestIndex : 0;
}

function findColumn(headers: string[], aliases: string[]): number {
  const normalized = headers.map(normalizeText);
  const exact = normalized.findIndex((h) => aliases.some((a) => h === normalizeText(a)));
  if (exact >= 0) return exact;
  return normalized.findIndex((h) => aliases.some((a) => h.includes(normalizeText(a))));
}

function rowToBar(headers: string[], row: unknown[], fallbackDate: string): {
  name: string;
  code: string;
  sector?: string;
  bar: HistoricalBar;
} | null {
  const get = (aliases: string[]) => {
    const index = findColumn(headers, aliases);
    return index >= 0 ? row[index] : undefined;
  };

  const nameRaw = get(NAME_ALIASES) ?? row[0];
  const codeRaw = get(CODE_ALIASES) ?? row[1];
  const name = String(nameRaw ?? "").trim();
  const code = String(codeRaw ?? "").trim().toUpperCase();
  const close = parseNumber(get(CLOSE_ALIASES) ?? row[2]);
  const open = parseNumber(get(OPEN_ALIASES));
  const high = parseNumber(get(HIGH_ALIASES));
  const low = parseNumber(get(LOW_ALIASES));

  if (!name && !code) return null;
  if (![open, high, low, close].every((v) => v !== null && v > 0)) return null;
  if ((high as number) < Math.max(open as number, close as number) || (low as number) > Math.min(open as number, close as number)) return null;

  const volume = parseNumber(get(VOLUME_ALIASES));
  const value = parseNumber(get(VALUE_ALIASES));
  const trades = parseNumber(get(TRADES_ALIASES));
  const sectorValue = get(SECTOR_ALIASES);
  return {
    name: name || "غير محدد",
    code,
    sector: sectorValue == null ? undefined : String(sectorValue).trim() || undefined,
    bar: {
      date: parseDate(get(DATE_ALIASES), fallbackDate),
      open: open as number,
      high: high as number,
      low: low as number,
      close: close as number,
      volume,
      value,
      trades,
      source: "imported-file",
    },
  };
}

function buildStocks(records: Array<ReturnType<typeof rowToBar>>, fallbackDate: string): StockData[] {
  const grouped = new Map<string, { name: string; code: string; sector?: string; bars: HistoricalBar[] }>();
  for (const record of records) {
    if (!record) continue;
    const identity = record.code || normalizeText(record.name);
    const current = grouped.get(identity) ?? { name: record.name, code: record.code, sector: record.sector, bars: [] };
    current.name = record.name || current.name;
    current.code = record.code || current.code;
    current.sector = record.sector || current.sector;
    current.bars.push(record.bar);
    grouped.set(identity, current);
  }

  const stocks: StockData[] = [];
  for (const [identity, group] of grouped) {
    const byDate = new Map<string, HistoricalBar>();
    for (const bar of group.bars) byDate.set(bar.date || fallbackDate, bar);
    const bars = [...byDate.values()].sort((a, b) => a.date.localeCompare(b.date));
    const latest = bars.at(-1);
    if (!latest) continue;
    const resolved = resolveTradingViewSymbol(group.code || group.name);
    try {
      stocks.push(enrichStockTechnicalData(
        {
          id: `${identity}-${latest.date}`,
          name: group.name,
          code: group.code,
          sector: group.sector,
          tvSymbol: resolved,
          open: latest.open,
          high: latest.high,
          low: latest.low,
          close: latest.close,
          volume: latest.volume ?? null,
          value: latest.value ?? null,
          trades: latest.trades ?? null,
        },
        bars
      ));
    } catch {
      // Invalid records are intentionally omitted rather than repaired with invented numbers.
    }
  }

  if (!stocks.length) throw new Error("لم يتم العثور على صفوف OHLC صالحة. يلزم وجود: فتح، أعلى، أدنى، إغلاق مع اسم/رمز السهم.");
  return stocks;
}

export async function parseUploadedFile(file: File, fallbackDate: string): Promise<StockData[]> {
  const ext = file.name.split(".").pop()?.toLowerCase();
  if (!ext) throw new Error("تعذر تحديد نوع الملف.");
  if (["xlsx", "xls"].includes(ext)) return parseExcelFile(file, fallbackDate);
  if (["csv", "txt"].includes(ext)) return parseCsvFile(file, fallbackDate);
  throw new Error("النسخة الحالية تدعم Excel وCSV فقط. ملفات PDF لا تُحوّل إلى أسعار تلقائيًا حتى لا يتم اختراع OHLC عند فشل الاستخراج.");
}

async function parseExcelFile(file: File, fallbackDate: string): Promise<StockData[]> {
  const buffer = await file.arrayBuffer();
  const workbook = XLSX.read(buffer, { type: "array", cellDates: true, raw: true });
  if (!workbook.SheetNames.length) throw new Error("ملف Excel فارغ.");

  const records: Array<ReturnType<typeof rowToBar>> = [];
  const usedSheets: string[] = [];
  for (const sheetName of workbook.SheetNames) {
    const worksheet = workbook.Sheets[sheetName];
    const rows = XLSX.utils.sheet_to_json<unknown[]>(worksheet, { header: 1, defval: null, raw: true }) as unknown[][];
    if (!rows.length) continue;
    const headerIndex = findHeaderIndex(rows);
    const headers = (rows[headerIndex] ?? []).map((v) => String(v ?? "").trim());
    if (headers.length < 3) continue;
    let added = 0;
    for (let i = headerIndex + 1; i < rows.length; i++) {
      const parsed = rowToBar(headers, rows[i] ?? [], fallbackDate);
      if (parsed) {
        records.push(parsed);
        added++;
      }
    }
    if (added) usedSheets.push(sheetName);
  }
  if (!records.length) throw new Error("لم يتم استخراج أي بيانات صالحة من أوراق Excel.");
  return buildStocks(records, fallbackDate);
}

async function parseCsvFile(file: File, fallbackDate: string): Promise<StockData[]> {
  const text = await file.text();
  const rows = parseCsvRows(text);
  if (rows.length < 2) throw new Error("ملف CSV لا يحتوي على بيانات كافية.");
  const headerIndex = findHeaderIndex(rows);
  const headers = rows[headerIndex].map((v) => String(v ?? "").trim());
  const records: Array<ReturnType<typeof rowToBar>> = [];
  for (let i = headerIndex + 1; i < rows.length; i++) {
    const parsed = rowToBar(headers, rows[i], fallbackDate);
    if (parsed) records.push(parsed);
  }
  if (!records.length) throw new Error("لم يتم استخراج أي صف OHLC صالح من CSV.");
  return buildStocks(records, fallbackDate);
}

function parseCsvRows(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = "";
  let quoted = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (ch === '"') {
      if (quoted && text[i + 1] === '"') {
        field += '"';
        i++;
      } else {
        quoted = !quoted;
      }
    } else if (ch === "," && !quoted) {
      row.push(field.trim());
      field = "";
    } else if ((ch === "\n" || ch === "\r") && !quoted) {
      if (ch === "\r" && text[i + 1] === "\n") i++;
      row.push(field.trim());
      field = "";
      if (row.some((cell) => cell.length)) rows.push(row);
      row = [];
    } else {
      field += ch;
    }
  }
  if (field.length || row.length) {
    row.push(field.trim());
    if (row.some((cell) => cell.length)) rows.push(row);
  }
  return rows;
}
