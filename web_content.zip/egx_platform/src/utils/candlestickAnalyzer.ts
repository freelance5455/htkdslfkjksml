import type { HistoricalBar, StockData } from "../types";
import {
  calculateLevels,
  calculateTechnicalIndicators,
  classicPivots,
  deriveSignal,
} from "./technicalEngine";

export interface PatternAnalysis {
  pattern: string;
  type: "bullish" | "bearish" | "neutral";
  reliability: "عالية" | "متوسطة" | "عادية";
  description: string;
}

const isFiniteNumber = (v: unknown): v is number => typeof v === "number" && Number.isFinite(v);
const round = (n: number, d = 2) => Math.round(n * 10 ** d) / 10 ** d;

export function analyzeCandlestickPattern(
  open: number,
  high: number,
  low: number,
  close: number
): PatternAnalysis {
  const range = high - low;
  if (![open, high, low, close].every(isFiniteNumber) || range < 0 || high < Math.max(open, close) || low > Math.min(open, close)) {
    return {
      pattern: "بيانات شمعة غير صالحة",
      type: "neutral",
      reliability: "عادية",
      description: "تعذر تحليل الشمعة بسبب عدم اكتمال أو عدم اتساق OHLC.",
    };
  }
  if (range === 0) {
    return { pattern: "دوجي خطية", type: "neutral", reliability: "عادية", description: "الفتح والأعلى والأدنى والإغلاق متساوية في هذه الجلسة." };
  }

  const body = Math.abs(close - open);
  const upperShadow = high - Math.max(open, close);
  const lowerShadow = Math.min(open, close) - low;
  const bodyRatio = body / range;
  const upperRatio = upperShadow / range;
  const lowerRatio = lowerShadow / range;
  const green = close >= open;

  if (bodyRatio <= 0.08) {
    if (lowerRatio >= 0.65 && upperRatio <= 0.15) {
      return { pattern: "دوجي اليعسوب", type: "bullish", reliability: "متوسطة", description: "رفض سعري واضح من القاع، وتحتاج الإشارة إلى تأكيد من الجلسة التالية والاتجاه." };
    }
    if (upperRatio >= 0.65 && lowerRatio <= 0.15) {
      return { pattern: "دوجي شاهد القبر", type: "bearish", reliability: "متوسطة", description: "رفض سعري من القمة، ولا تكفي الشمعة وحدها للحكم على انعكاس الاتجاه." };
    }
    return { pattern: "دوجي محايدة", type: "neutral", reliability: "متوسطة", description: "توازن نسبي بين قوى العرض والطلب داخل الجلسة." };
  }

  if (lowerRatio >= 0.55 && upperRatio <= 0.15 && bodyRatio >= 0.15 && bodyRatio <= 0.4) {
    return {
      pattern: green ? "مطرقة صاعدة" : "مطرقة حمراء",
      type: green ? "bullish" : "neutral",
      reliability: "متوسطة",
      description: "ظل سفلي طويل مع جسم صغير نسبيًا؛ تصبح أكثر دلالة قرب دعم سابق وبعد اتجاه هابط مؤكد.",
    };
  }

  if (upperRatio >= 0.55 && lowerRatio <= 0.15 && bodyRatio >= 0.15 && bodyRatio <= 0.4) {
    return {
      pattern: green ? "مطرقة مقلوبة" : "شهاب ساقط",
      type: green ? "bullish" : "bearish",
      reliability: "متوسطة",
      description: "ظل علوي طويل؛ يلزم سياق اتجاه وموقع سعري قبل استخدامه كإشارة انعكاس.",
    };
  }

  if (bodyRatio >= 0.85) {
    return {
      pattern: green ? "ماروبوزو صاعد" : "ماروبوزو هابط",
      type: green ? "bullish" : "bearish",
      reliability: "متوسطة",
      description: "جسم كبير يغطي معظم نطاق الجلسة ويعكس سيطرة اتجاهية واضحة خلال الجلسة نفسها.",
    };
  }

  if (bodyRatio <= 0.35 && upperRatio >= 0.25 && lowerRatio >= 0.25) {
    return { pattern: "سبينينغ توب", type: "neutral", reliability: "عادية", description: "تذبذب داخل الجلسة مع جسم صغير نسبيًا وحيرة قصيرة الأجل." };
  }

  return {
    pattern: green ? "شمعة خضراء اعتيادية" : "شمعة حمراء اعتيادية",
    type: green ? "bullish" : "bearish",
    reliability: "عادية",
    description: "سلوك سعري اعتيادي؛ لا توجد بنية شمعة منفردة مميزة تتطلب تصنيفًا أقوى.",
  };
}

export function calculatePivotLevels(high: number, low: number, close: number) {
  return classicPivots(high, low, close);
}

export function calculateTradingTargets(
  close: number,
  levels: ReturnType<typeof calculateLevels>,
  signal: StockData["signal"],
  atr14: number | null
) {
  if (![close].every(isFiniteNumber) || !levels || signal === "بيانات غير كافية") {
    return { entryZone: null, target1: null, target2: null, stopLoss: null, riskReward: null };
  }

  const support = levels.support1;
  const support2 = levels.support2;
  const r1 = levels.resistance1;
  const r2 = levels.resistance2;
  const atr = isFiniteNumber(atr14) && atr14 > 0 ? atr14 : null;

  if (signal === "شراء قوي" || signal === "شراء مع تأكيد") {
    if (!isFiniteNumber(support) || !isFiniteNumber(r1) || r1 <= close) {
      return { entryZone: null, target1: null, target2: null, stopLoss: null, riskReward: null };
    }
    const stop = isFiniteNumber(atr) ? support - 0.5 * atr : support;
    const target1 = r1;
    const target2 = isFiniteNumber(r2) && r2 > target1 ? r2 : null;
    const risk = close - stop;
    const reward = target1 - close;
    return {
      entryZone: `${round(Math.min(close, support))} - ${round(Math.max(close, support))}`,
      target1: round(target1),
      target2: target2 === null ? null : round(target2),
      stopLoss: round(stop),
      riskReward: risk > 0 && reward > 0 ? `1 : ${round(reward / risk, 1)}` : null,
    };
  }

  if (signal === "حذر ووقف خسارة" || signal === "جني أرباح") {
    const resistance = isFiniteNumber(levels.resistance1) ? levels.resistance1 : null;
    const breakdown = isFiniteNumber(support2) ? support2 : support;
    return {
      entryZone: isFiniteNumber(resistance) ? `مراقبة دون ${round(resistance)}` : null,
      target1: isFiniteNumber(breakdown) ? round(breakdown) : null,
      target2: null,
      stopLoss: isFiniteNumber(support) ? round(support) : null,
      riskReward: null,
    };
  }

  return { entryZone: null, target1: null, target2: null, stopLoss: null, riskReward: null };
}

export function enrichStockTechnicalData(raw: Partial<StockData>, history?: HistoricalBar[]): StockData {
  const open = Number(raw.open);
  const high = Number(raw.high);
  const low = Number(raw.low);
  const close = Number(raw.close);
  if (![open, high, low, close].every(isFiniteNumber) || close <= 0 || high < low || high < Math.max(open, close) || low > Math.min(open, close)) {
    throw new Error("بيانات OHLC غير صالحة؛ تم رفض السجل بدل استكماله بأرقام افتراضية.");
  }

  const bars = (history && history.length ? history : [{
    date: new Date().toISOString().slice(0, 10),
    open,
    high,
    low,
    close,
    volume: raw.volume ?? null,
    value: raw.value ?? null,
    trades: raw.trades ?? null,
    source: "imported-file",
  }]).filter((bar) => [bar.open, bar.high, bar.low, bar.close].every(isFiniteNumber));

  bars.sort((a, b) => a.date.localeCompare(b.date));
  const technical = calculateTechnicalIndicators(bars);
  const latest = bars[bars.length - 1];
  const pattern = analyzeCandlestickPattern(latest.open, latest.high, latest.low, latest.close);
  const levels = calculateLevels(bars, latest.close, latest.high, latest.low);
  const previousClose = bars.length >= 2 ? bars[bars.length - 2].close : (raw.previousClose ?? null);
  const rawChangeValue = raw.changeValue == null ? null : Number(raw.changeValue);
  const rawChangePercent = raw.changePercent == null ? null : Number(raw.changePercent);
  const changeValue = previousClose !== null ? latest.close - previousClose : (isFiniteNumber(rawChangeValue) ? rawChangeValue : null);
  const changePercent = previousClose && previousClose !== 0
    ? (changeValue === null ? null : (changeValue / previousClose) * 100)
    : (isFiniteNumber(rawChangePercent) ? rawChangePercent : null);
  const gate = deriveSignal(technical, pattern.type, latest.close, previousClose);
  const targets = calculateTradingTargets(latest.close, levels, gate.signal, technical.atr14);
  const volume = latest.volume == null ? null : Number(latest.volume);
  const value = latest.value == null && volume != null ? latest.close * volume : (latest.value == null ? null : Number(latest.value));

  const missingRequiredFields: string[] = [];
  if (previousClose == null && bars.length < 2) missingRequiredFields.push("previousClose");
  const messages: string[] = [];
  if (value != null && latest.value == null && volume != null) messages.push("قيمة التداول حُسبت من الإغلاق × الحجم لأنها غير موجودة في المصدر.");
  if (technical.rsi14 == null) messages.push("RSI14 غير متاح: يلزم تاريخ سعري أطول.");
  if (technical.macdHistogram == null) messages.push("MACD غير متاح: يلزم تاريخ سعري أطول.");
  if (technical.volumeSma20 == null) messages.push("مؤشرات الحجم غير متاحة أو لا تحتوي السلسلة على أحجام صالحة.");
  if (!gate.gatePassed) messages.push("لم تُصدر المنصة إشارة تنفيذية مؤكدة لأن بوابة التأكيد لم تكتمل.");

  return {
    id: raw.id || `${String(raw.code || "EGX").toUpperCase()}-${bars[bars.length - 1].date}`,
    name: String(raw.name || "سهم غير مسمى").trim(),
    code: String(raw.code || "EGX").trim().toUpperCase(),
    tvSymbol: raw.tvSymbol || "",
    sector: raw.sector,
    open: latest.open,
    high: latest.high,
    low: latest.low,
    close: latest.close,
    previousClose,
    changePercent: changePercent === null ? null : round(changePercent),
    changeValue: changeValue === null ? null : round(changeValue),
    volume,
    value,
    trades: latest.trades ?? raw.trades ?? null,
    candlestickPattern: pattern.pattern,
    patternType: pattern.type,
    patternReliability: pattern.reliability,
    patternDescription: pattern.description,
    rsi: technical.rsi14,
    pivot: levels.pivot,
    support1: levels.support1,
    support2: levels.support2,
    resistance1: levels.resistance1,
    resistance2: levels.resistance2,
    signal: gate.signal,
    entryZone: targets.entryZone,
    target1: targets.target1,
    target2: targets.target2,
    stopLoss: targets.stopLoss,
    riskReward: targets.riskReward,
    confidence: gate.confidence,
    signalGate: gate.gatePassed,
    marketRegime: gate.regime,
    technical,
    levels,
    history: bars,
    dataQuality: {
      source: "imported-file",
      asOfDate: latest.date || null,
      bars: bars.length,
      missingRequiredFields,
      messages,
      status: missingRequiredFields.length || messages.some((m) => m.includes("غير متاح")) ? "partial" : "verified",
    },
  };
}
