export const unavailable = "N/A";
export const formatNumber = (value: number | null | undefined, digits = 2): string =>
  typeof value === "number" && Number.isFinite(value) ? value.toFixed(digits) : unavailable;
export const formatInteger = (value: number | null | undefined): string =>
  typeof value === "number" && Number.isFinite(value) ? value.toLocaleString("en-US") : unavailable;
