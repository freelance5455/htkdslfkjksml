export interface HistoricalBar {
  date: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number | null;
  value?: number | null;
  trades?: number | null;
  source?: string;
}

export interface TechnicalIndicators {
  bars: number;
  sma5: number | null; sma10: number | null; sma20: number | null; sma50: number | null; sma100: number | null; sma200: number | null;
  ema9: number | null; ema12: number | null; ema20: number | null; ema26: number | null; ema50: number | null; ema200: number | null;
  rsi14: number | null;
  macd: number | null; macdSignal: number | null; macdHistogram: number | null;
  stochasticK: number | null; stochasticD: number | null; williamsR: number | null; cci20: number | null; roc12: number | null; momentum10: number | null;
  atr14: number | null; bollingerMiddle: number | null; bollingerUpper: number | null; bollingerLower: number | null; bollingerWidth: number | null;
  volatility20Annualized: number | null; volumeSma20: number | null; relativeVolume20: number | null; obv: number | null; mfi14: number | null; vwap: number | null;
  adx14: number | null; plusDI14: number | null; minusDI14: number | null;
  ichimokuTenkan: number | null; ichimokuKijun: number | null; ichimokuSenkouA: number | null; ichimokuSenkouB: number | null; ichimokuChikou: number | null;
  trueRange14: number | null; lastClose: number | null;
}

export interface TechnicalLevels {
  pivot: number | null;
  r1: number | null;
  r2: number | null;
  s1: number | null;
  s2: number | null;
  h3: number | null;
  h4: number | null;
  l3: number | null;
  l4: number | null;
  support1: number | null;
  support2: number | null;
  resistance1: number | null;
  resistance2: number | null;
  supports: number[];
  resistances: number[];
  fib: Record<string, number> | null;
  source: string;
}

export interface SignalGate {
  signal: "شراء قوي" | "شراء مع تأكيد" | "ترقب" | "جني أرباح" | "حذر ووقف خسارة" | "بيانات غير كافية";
  gatePassed: boolean;
  confidence: number | null;
  regime: string;
  reasons: string[];
}

export interface DataQuality {
  source: "imported-file" | "server-feed" | "unknown";
  asOfDate: string | null;
  bars: number;
  missingRequiredFields: string[];
  messages: string[];
  status: "verified" | "partial" | "unavailable";
}

export interface StockData {
  id: string;
  name: string;
  code: string;
  tvSymbol: string;
  sector?: string;
  open: number;
  high: number;
  low: number;
  close: number;
  previousClose?: number | null;
  changePercent: number | null;
  changeValue: number | null;
  volume: number | null;
  value: number | null;
  trades?: number | null;
  candlestickPattern: string;
  patternType: "bullish" | "bearish" | "neutral";
  patternReliability: "عالية" | "متوسطة" | "عادية";
  patternDescription: string;
  rsi: number | null;
  pivot: number | null;
  support1: number | null;
  support2: number | null;
  resistance1: number | null;
  resistance2: number | null;
  signal: SignalGate["signal"];
  entryZone?: string | null;
  target1?: number | null;
  target2?: number | null;
  stopLoss?: number | null;
  riskReward?: string | null;
  confidence?: number | null;
  signalGate?: boolean;
  marketRegime?: string;
  technical?: TechnicalIndicators;
  levels?: TechnicalLevels;
  history?: HistoricalBar[];
  dataQuality: DataQuality;
}

export interface MarketStats {
  date: string;
  totalStocks: number;
  advancers: number;
  decliners: number;
  unchanged: number;
  totalVolume: number;
  totalValue: number;
  marketSentiment: "إيجابي قوي" | "إيجابي معتدل" | "متذبذب / محايد" | "سلبي وجني أرباح" | "تصحيح حاد" | "غير متاح";
  topGainer?: StockData;
  topLoser?: StockData;
  mostActiveByValue?: StockData;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
}

export interface HistoricalSession {
  date: string;
  stocksCount: number;
  stocks: StockData[];
  note?: string;
}
