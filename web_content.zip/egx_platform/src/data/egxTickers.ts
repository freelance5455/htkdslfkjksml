// Comprehensive Egyptian Stock Exchange (EGX) Name & Code to TradingView Symbol Mapping
export const EGX_TICKERS_MAP: Record<string, string> = {
  // Top 30 / Major EGX Stocks
  "التجاري الدولي": "COMI",
  "البنك التجاري الدولي": "COMI",
  "comi": "COMI",
  "cib": "COMI",
  "فوري": "FWRY",
  "فوري لتكنولوجيا البنوك": "FWRY",
  "fwry": "FWRY",
  "هيرمس": "HRHO",
  "اي اف جي القابضة": "HRHO",
  "مجموعة إي إف جي القابضة": "HRHO",
  "hrho": "HRHO",
  "طلعت مصطفى": "TMGH",
  "مجموعة طلعت مصطفى": "TMGH",
  "tmgh": "TMGH",
  "ابو قير للاسمدة": "ABUK",
  "أبو قير للأسمدة": "ABUK",
  "abuk": "ABUK",
  "السويدي اليكتريك": "SWDY",
  "السويدى اليكتريك": "SWDY",
  "swdy": "SWDY",
  "الشرقية للدخان": "EAST",
  "ايسترن كومباني": "EAST",
  "east": "EAST",
  "سيدي كرير": "SKPC",
  "سيدي كرير للبتروكيماويات": "SKPC",
  "skpc": "SKPC",
  "المصرية للاتصالات": "ETEL",
  "we": "ETEL",
  "etel": "ETEL",
  "مدينة مصر": "MASR",
  "مدينة مصر للاسكان": "MASR",
  "mnhd": "MASR",
  "masr": "MASR",
  "حديد عز": "ESRS",
  "esrs": "ESRS",
  "موبكو": "MFPC",
  "مصر لإنتاج الأسمدة": "MFPC",
  "mfpc": "MFPC",
  "بالم هيلز": "PHDC",
  "بالم هيلز للتعمير": "PHDC",
  "phdc": "PHDC",
  "بلتون": "BTFH",
  "بلتون المالية القابضة": "BTFH",
  "btfh": "BTFH",
  "اي فاينانس": "EFIH",
  "إي فاينانس للاستثمارات المالية": "EFIH",
  "efih": "EFIH",
  "اسكندرية لتداول الحاويات": "ALCN",
  "إسكندرية لتداول الحاويات والبضائع": "ALCN",
  "alcn": "ALCN",
  "اوراسكوم للانشاء": "ORAS",
  "أوراسكوم كونستراكشون": "ORAS",
  "oras": "ORAS",
  "جي بي كورب": "AUTO",
  "غبور أوتو": "AUTO",
  "auto": "AUTO",
  "كليوباترا": "CLHO",
  "مستشفى كليوباترا": "CLHO",
  "clho": "CLHO",
  "بنك قطر الوطني": "QNBE",
  "qnb": "QNBE",
  "qnbe": "QNBE",
  "كريدي اجريكول": "CIEB",
  "كريدى أجريكول - مصر": "CIEB",
  "cieb": "CIEB",
  "ابن سينا فارما": "ISPH",
  "إبن سينا فارما": "ISPH",
  "isph": "ISPH",
  "بي انفستمنتس": "BINV",
  "بى انفستمنتس القابضة": "BINV",
  "binv": "BINV",
  "القاهرة للدواجن": "POUL",
  "poul": "POUL",
  "جهينة": "JUFO",
  "جهينة للصناعات الغذائية": "JUFO",
  "jufo": "JUFO",
  "اديتا": "EFID",
  "إيديتا للصناعات الغذائية": "EFID",
  "efid": "EFID",
  "دومتي": "DOMT",
  "الصناعات الغذائية العربية-دومتى": "DOMT",
  "domt": "DOMT",
  "النساجون الشرقيون": "ORWE",
  "orwe": "ORWE",
  "ايجيترانس": "ETRS",
  "المصرية لخدمات النقل (ايجيترانس)": "ETRS",
  "etrs": "ETRS",
  "راية القابضة": "RAYA",
  "raya": "RAYA",
  "مصر الجديدة للاسكان": "HELI",
  "heli": "HELI",
  "اوراسكوم للتنمية": "ORHD",
  "orhd": "ORHD",
  "القلعة": "CCAP",
  "القلعة للاستشارات المالية": "CCAP",
  "ccap": "CCAP",
  "العربية لحليج الاقطان": "ACGC",
  "acgc": "ACGC",
  "سيناء للأسمنت": "SCEM",
  "scem": "SCEM",
  "اسمنت سيناء": "SCEM",
  "اسمنت قنا": "MCQE",
  "مصر للأسمنت - قنا": "MCQE",
  "mcqe": "MCQE",
  "اسمنت العربية": "ARCC",
  "arcc": "ARCC",
  "كونتكت المالية": "CNFN",
  "cnfn": "CNFN",
  "سي آي كابيتال": "CICH",
  "cich": "CICH",
  "ام ام جروب": "MTIE",
  "mtie": "MTIE",
  "عبور لاند": "OLFI",
  "olfi": "OLFI",
  "رميدا": "DBK",
  "dbk": "DBK",
  "دايس": "DSCW",
  "dscw": "DSCW",
  "سبيد ميديكال": "SPMD",
  "spmd": "SPMD",
  "المطورون العرب": "ARVA",
  "arva": "ARVA",
  "مصر للالومنيوم": "EGAL",
  "مصر للألومنيوم": "EGAL",
  "egal": "EGAL"
};

export function resolveTradingViewSymbol(nameOrCode: string): string {
  if (!nameOrCode) return "";
  
  const cleaned = nameOrCode.trim().toLowerCase();
  
  // Direct match in map
  if (EGX_TICKERS_MAP[cleaned]) {
    return `EGX:${EGX_TICKERS_MAP[cleaned]}`;
  }
  
  // Partial substring match
  for (const [key, symbol] of Object.entries(EGX_TICKERS_MAP)) {
    if (cleaned.includes(key.toLowerCase()) || key.toLowerCase().includes(cleaned)) {
      return `EGX:${symbol}`;
    }
  }
  
  // If looks like an English ticker code already (3 to 5 uppercase letters)
  const alphaOnly = nameOrCode.replace(/[^A-Za-z]/g, "").toUpperCase();
  if (alphaOnly.length >= 3 && alphaOnly.length <= 5) {
    return `EGX:${alphaOnly}`;
  }
  
  return "";
}
