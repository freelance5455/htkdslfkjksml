import React, { useState, useEffect } from "react";
import { Header } from "./components/Header";
import { CloudArchiveBar } from "./components/CloudArchiveBar";
import { Toolbar } from "./components/Toolbar";
import { StocksTable } from "./components/StocksTable";
import { StockModal } from "./components/StockModal";
import { MarketStructureModal } from "./components/MarketStructureModal";
import { OversoldBounceModal } from "./components/OversoldBounceModal";
import { StrategicOpportunitiesModal } from "./components/StrategicOpportunitiesModal";
import { HistoricalArchiveModal } from "./components/HistoricalArchiveModal";
import { ApiKeyModal } from "./components/ApiKeyModal";
import { DownloadModal } from "./components/DownloadModal";
import { StockData, HistoricalSession, MarketStats } from "./types";
import { calculateMarketStats } from "./utils/marketStats";
import { parseUploadedFile } from "./utils/fileParser";
import { AlertCircle, CheckCircle2 } from "lucide-react";

export function App() {
  const [currentDate, setCurrentDate] = useState<string>(() =>
    new Intl.DateTimeFormat("en-CA", { timeZone: "Africa/Cairo", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date())
  );
  const [stocks, setStocks] = useState<StockData[]>(() => {
    try {
      const saved = localStorage.getItem("egx_real_current_stocks_v7");
      const parsed = saved ? JSON.parse(saved) : [];
      return Array.isArray(parsed) && parsed.every((s) => s?.dataQuality?.source === "imported-file") ? parsed : [];
    } catch {
      return [];
    }
  });

  const [savedSessions, setSavedSessions] = useState<HistoricalSession[]>(() => {
    try {
      const saved = localStorage.getItem("egx_real_saved_sessions_v7");
      const parsed = saved ? JSON.parse(saved) : [];
      return Array.isArray(parsed) ? parsed.filter((session) => Array.isArray(session?.stocks) && session.stocks.every((s: StockData) => s?.dataQuality?.source === "imported-file")) : [];
    } catch {
      return [];
    }
  });

  const [customApiKey, setCustomApiKey] = useState<string>("");

  // Modal states
  const [selectedStock, setSelectedStock] = useState<StockData | null>(null);
  const [isMarketStructureOpen, setIsMarketStructureOpen] = useState(false);
  const [isOversoldBounceOpen, setIsOversoldBounceOpen] = useState(false);
  const [isOpportunitiesOpen, setIsOpportunitiesOpen] = useState(false);
  const [isHistoricalArchiveOpen, setIsHistoricalArchiveOpen] = useState(false);
  const [isApiKeyModalOpen, setIsApiKeyModalOpen] = useState(false);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);

  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [notification, setNotification] = useState<{
    text: string;
    type: "success" | "error" | "info";
  } | null>(null);

  // Persist stocks & sessions
  useEffect(() => {
    localStorage.setItem("egx_real_current_stocks_v7", JSON.stringify(stocks));
  }, [stocks]);

  useEffect(() => {
    localStorage.setItem("egx_real_saved_sessions_v7", JSON.stringify(savedSessions));
  }, [savedSessions]);

  const showNotification = (text: string, type: "success" | "error" | "info" = "info") => {
    setNotification({ text, type });
    setTimeout(() => {
      setNotification(null);
    }, 4500);
  };

  const marketStats: MarketStats = calculateMarketStats(stocks, currentDate);

  const handleFileUpload = async (file: File) => {
    setIsLoading(true);
    try {
      const parsed = await parseUploadedFile(file, currentDate);
      setStocks(parsed);
      const activeSessionDate = parsed
        .map((s) => s.dataQuality.asOfDate)
        .filter((v): v is string => Boolean(v))
        .sort()
        .at(-1) || currentDate;
      setCurrentDate(activeSessionDate);

      // Auto-save this session into the local archive.
      const existingIdx = savedSessions.findIndex((s) => s.date === activeSessionDate);
      if (existingIdx >= 0) {
        const updated = [...savedSessions];
        updated[existingIdx] = {
          date: activeSessionDate,
          stocksCount: parsed.length,
          stocks: parsed,
          note: `تقرير مستورد: ${file.name}`,
        };
        setSavedSessions(updated);
      } else {
        const newSession: HistoricalSession = {
          date: activeSessionDate,
          stocksCount: parsed.length,
          stocks: parsed,
          note: `تقرير مستورد: ${file.name}`,
        };
        setSavedSessions((prev) => [newSession, ...prev]);
      }

      showNotification(
        `تم تحليل الملف بنجاح: ${parsed.length} سهمًا. تم الحساب من بيانات الملف فقط؛ الشارت الخارجي لا يُستخدم كمصدر أسعار.`,
        "success"
      );
    } catch (err: any) {
      showNotification(err.message || "حدث خطأ أثناء معالجة الملف.", "error");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectDate = (date: string) => {
    setCurrentDate(date);
    const foundSession = savedSessions.find((s) => s.date === date);
    if (foundSession) {
      setStocks(foundSession.stocks);
      showNotification(`تم تحميل بيانات جلسة ${date} بنجاح.`, "info");
    } else {
      showNotification(`تم تعيين تاريخ الجلسة إلى ${date}.`, "info");
    }
  };

  const handleSaveCurrentSession = () => {
    if (!stocks.length) {
      showNotification("لا توجد بيانات حقيقية متاحة للحفظ.", "error");
      return;
    }
    const existingIdx = savedSessions.findIndex((s) => s.date === currentDate);
    if (existingIdx >= 0) {
      const updated = [...savedSessions];
      updated[existingIdx] = {
        date: currentDate,
        stocksCount: stocks.length,
        stocks,
        note: `جلسة محدثة يدوياً في ${new Date().toLocaleTimeString("ar-EG")}`,
      };
      setSavedSessions(updated);
    } else {
      const newSession: HistoricalSession = {
        date: currentDate,
        stocksCount: stocks.length,
        stocks,
        note: `جلسة جديدة مسجلة في ${new Date().toLocaleTimeString("ar-EG")}`,
      };
      setSavedSessions((prev) => [newSession, ...prev]);
    }
    showNotification(`تم حفظ بيانات جلسة ${currentDate} في أرشيف المتصفح المحلي.`, "success");
  };

  const handleSaveApiKey = (key: string) => {
    setCustomApiKey(key);
    if (key) {
      showNotification("تم تفعيل مفتاح Gemini المخصص لهذه الجلسة فقط.", "success");
    } else {
      showNotification("تمت إزالة المفتاح المخصص؛ سيتم استخدام إعداد الخادم.", "info");
    }
  };

  const handleCopyReport = () => {
    const topGainers = [...stocks].filter((s) => s.changePercent != null).sort((a, b) => (b.changePercent as number) - (a.changePercent as number)).slice(0, 3);
    const text = `🇪🇬 ملخص جلسة البورصة المصرية (${currentDate}) - منصة EGX Pro Cloud
• إجمالي الأسهم النشطة: ${stocks.length}
• الصاعدون: ${marketStats.advancers} | الهابطون: ${marketStats.decliners} | المستقرون: ${marketStats.unchanged}
• معنويات السوق: ${marketStats.marketSentiment}
• إجمالي التداول: ${(marketStats.totalValue / 1e6).toFixed(1)} مليون ج.م

🌟 أبرز الرابحين:
${topGainers.map((s, i) => `${i + 1}. ${s.name} (${s.code}): ${s.close} ج.م (${s.changePercent != null ? `${s.changePercent > 0 ? "+" : ""}${s.changePercent}%` : "N/A"}) - ${s.candlestickPattern}`).join("\n")}

تم إعداد التقرير تلقائياً عبر منصة EGX Pro Cloud والخبير الاستراتيجي.`;

    navigator.clipboard.writeText(text);
    setCopied(true);
    showNotification("تم نسخ تقرير الجلسة بنجاح.", "success");
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-[#040711] text-slate-100 p-2 sm:p-4 md:p-6 font-sans antialiased selection:bg-emerald-500 selection:text-slate-950" dir="rtl">
      <div className="max-w-7xl mx-auto space-y-3">
        {/* Notification Toast */}
        {notification && (
          <div
            className={`fixed top-4 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-2xl shadow-2xl border text-xs md:text-sm font-bold flex items-center gap-2.5 backdrop-blur-md transition-all animate-bounce ${
              notification.type === "success"
                ? "bg-emerald-950/95 text-emerald-300 border-emerald-500/60"
                : notification.type === "error"
                ? "bg-rose-950/95 text-rose-300 border-rose-500/60"
                : "bg-indigo-950/95 text-indigo-300 border-indigo-500/60"
            }`}
          >
            {notification.type === "error" ? (
              <AlertCircle className="w-4 h-4 text-rose-400" />
            ) : (
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            )}
            <span>{notification.text}</span>
          </div>
        )}

        {/* 1. Header */}
        <Header
          onOpenApiKeyModal={() => setIsApiKeyModalOpen(true)}
          onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
          onCopyReport={handleCopyReport}
          copied={copied}
        />

        {/* 2. Cloud Archive Bar */}
        <CloudArchiveBar
          currentDate={currentDate}
          onSelectDate={handleSelectDate}
          savedSessions={savedSessions}
          onSaveCurrentSession={handleSaveCurrentSession}
        />

        {/* 3. Toolbar & Strategic Triggers */}
        <Toolbar
          onFileUpload={handleFileUpload}
          isLoading={isLoading}
          onOpenHistoricalArchive={() => setIsHistoricalArchiveOpen(true)}
          onOpenMarketStructure={() => setIsMarketStructureOpen(true)}
          onOpenOversoldBounce={() => setIsOversoldBounceOpen(true)}
          onOpenOpportunities={() => setIsOpportunitiesOpen(true)}
          hasData={stocks.length > 0}
        />

        {/* 4. Main Stocks Table with Candlesticks, RSI, Pivots */}
        <StocksTable
          stocks={stocks}
          currentDate={currentDate}
          onSelectStock={(stock) => setSelectedStock(stock)}
        />
      </div>

      {/* MODALS */}
      {selectedStock && (
        <StockModal
          stock={selectedStock}
          onClose={() => setSelectedStock(null)}
          customApiKey={customApiKey}
        />
      )}

      {isMarketStructureOpen && (
        <MarketStructureModal
          stats={marketStats}
          stocks={stocks}
          onClose={() => setIsMarketStructureOpen(false)}
          customApiKey={customApiKey}
          onSelectStock={(stock) => setSelectedStock(stock)}
        />
      )}

      {isOversoldBounceOpen && (
        <OversoldBounceModal
          stocks={stocks}
          onClose={() => setIsOversoldBounceOpen(false)}
          onSelectStock={(stock) => setSelectedStock(stock)}
        />
      )}

      {isOpportunitiesOpen && (
        <StrategicOpportunitiesModal
          stocks={stocks}
          onClose={() => setIsOpportunitiesOpen(false)}
          onSelectStock={(stock) => setSelectedStock(stock)}
        />
      )}

      {isHistoricalArchiveOpen && (
        <HistoricalArchiveModal
          sessions={savedSessions}
          currentDate={currentDate}
          onSelectDate={handleSelectDate}
          onClose={() => setIsHistoricalArchiveOpen(false)}
        />
      )}

      {isApiKeyModalOpen && (
        <ApiKeyModal
          customApiKey={customApiKey}
          onSaveApiKey={handleSaveApiKey}
          onClose={() => setIsApiKeyModalOpen(false)}
        />
      )}

      {isDownloadModalOpen && (
        <DownloadModal onClose={() => setIsDownloadModalOpen(false)} />
      )}
    </div>
  );
}
export default App;
