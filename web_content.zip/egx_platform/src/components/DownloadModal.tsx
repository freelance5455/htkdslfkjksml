import React, { useState } from "react";
import { X, Download, FileCode, Archive, Check, Copy, Terminal, ExternalLink } from "lucide-react";

interface DownloadModalProps {
  onClose: () => void;
}

export const DownloadModal: React.FC<DownloadModalProps> = ({ onClose }) => {
  const [copiedScript, setCopiedScript] = useState(false);

  const runCommandText = `git clone <your-repo>
npm install
npm run dev`;

  const copyRunCommand = () => {
    navigator.clipboard.writeText(runCommandText);
    setCopiedScript(true);
    setTimeout(() => setCopiedScript(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/90 backdrop-blur-md p-3 md:p-6">
      <div className="bg-[#060913] rounded-2xl border border-slate-800 shadow-2xl w-full max-w-2xl overflow-hidden">
        {/* Header */}
        <div className="bg-slate-950 px-5 py-3.5 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5 text-emerald-400 font-bold text-sm md:text-base">
            <Download className="w-5 h-5 text-emerald-400" />
            <span>تحميل وتصدير كود منصة EGX Pro Cloud كاملاً</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-rose-400 hover:text-white w-8 h-8 rounded-lg bg-rose-950/40 hover:bg-rose-900 flex items-center justify-center border border-rose-900/50 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 text-xs md:text-sm text-slate-300 max-h-[80vh] overflow-y-auto">
          <p className="text-slate-300 leading-relaxed">
            تم تجهيز النسخة المصدرية الحالية بنية قابلة للبناء، مع فصل واضح بين البيانات المستوردة والحسابات الفنية والذكاء الاصطناعي:
          </p>

          {/* Download Options Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {/* Option 1: Full React + Express Project ZIP */}
            <div className="bg-slate-900/90 border border-slate-800 hover:border-emerald-500/50 transition-all p-4 rounded-xl flex flex-col justify-between space-y-3 shadow-lg">
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-emerald-400 font-bold">
                  <Archive className="w-5 h-5 text-emerald-400" />
                  <span className="text-sm">مشروع كامل (Full ZIP Archive)</span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  يحتوي على كافة ملفات الواجهة React 19 + TypeScript + Tailwind CSS ومخدم Express والخوارزميات الفنية.
                </p>
                <div className="text-[11px] text-slate-500 font-mono">
                  يشمل package.json و server.ts و src/* ونسخة Standalone محدثة
                </div>
              </div>

              <a
                href="/egx-pro-cloud-full-project.zip"
                download="egx-pro-cloud-project.zip"
                className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 px-4 rounded-xl text-xs flex items-center justify-center gap-2 shadow-md transition-all active:scale-95"
              >
                <Download className="w-4 h-4" />
                <span>تحميل المشروع كاملاً (ZIP)</span>
              </a>
            </div>

            {/* Option 2: Single-File Standalone HTML */}
            <div className="bg-slate-900/90 border border-slate-800 hover:border-cyan-500/50 transition-all p-4 rounded-xl flex flex-col justify-between space-y-3 shadow-lg">
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-cyan-400 font-bold">
                  <FileCode className="w-5 h-5 text-cyan-400" />
                  <span className="text-sm">ملف HTML مستقل (Single-File)</span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  ملف واحد لاستيراد Excel/CSV وعرض الحسابات الأساسية بدون قاعدة بيانات أو خادم. يعتمد على مصادر الملف فقط.
                </p>
                <div className="text-[11px] text-slate-500 font-mono">
                  صيغة: .html مستقل | TradingView للشارت فقط عند توفر رمز صحيح
                </div>
              </div>

              <div className="flex gap-2">
                <a
                  href="/egx-pro-cloud-standalone.html"
                  download="egx-pro-cloud-standalone.html"
                  className="flex-1 bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-2.5 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-md transition-all active:scale-95"
                >
                  <Download className="w-4 h-4" />
                  <span>تنزيل الملف</span>
                </a>
                <a
                  href="/egx-pro-cloud-standalone.html"
                  target="_blank"
                  rel="noreferrer"
                  className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-2.5 rounded-xl text-xs flex items-center justify-center gap-1 border border-slate-700 transition-all"
                  title="فتح في تبويب جديد"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>معاينة</span>
                </a>
              </div>
            </div>
          </div>

          {/* Quick Setup instructions */}
          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-2 text-xs">
            <div className="flex items-center justify-between text-slate-300 font-bold">
              <div className="flex items-center gap-1.5">
                <Terminal className="w-4 h-4 text-amber-400" />
                <span>طريقة تشغيل المشروع الكامل على جهازك:</span>
              </div>
              <button
                type="button"
                onClick={copyRunCommand}
                className="text-[11px] text-emerald-400 hover:text-emerald-300 flex items-center gap-1 cursor-pointer"
              >
                {copiedScript ? <Check className="w-3 h-3 text-emerald-300" /> : <Copy className="w-3 h-3" />}
                <span>{copiedScript ? "تم النسخ" : "نسخ الأوامر"}</span>
              </button>
            </div>
            <ol className="list-decimal list-inside space-y-1 text-slate-400 text-[11px] leading-relaxed">
              <li>قم بفك ضغط ملف <span className="font-mono text-slate-200">egx-pro-cloud-project.zip</span>.</li>
              <li>افتح مجلد المشروع في برنامج Visual Studio Code أو Terminal.</li>
              <li>نفّذ الأمر <code className="bg-slate-900 px-1.5 py-0.5 rounded text-emerald-300 font-mono">npm install</code> لتثبيت الحزم.</li>
              <li>شغّل المنصة محلياً عبر <code className="bg-slate-900 px-1.5 py-0.5 rounded text-emerald-300 font-mono">npm run dev</code> وافتح الرابط <code className="font-mono text-cyan-300">http://localhost:3000</code>.</li>
            </ol>
          </div>

          {/* AI Studio Platform Export Tip */}
          <div className="p-3 bg-amber-950/30 border border-amber-800/40 rounded-xl text-xs text-amber-200 leading-relaxed">
            💡 <strong>تصدير مباشر عبر واجهة المنصة:</strong> يمكنك أيضاً تصدير كامل المشروع إلى مستودع GitHub أو تنزيله كملف مضغوط في أي وقت عبر قائمة الإعدادات العلوية في AI Studio (أيقونة الترس ⚙️ في الزاوية العلوية).
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-950 px-5 py-3 border-t border-slate-800 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer"
          >
            إغلاق النافذة
          </button>
        </div>
      </div>
    </div>
  );
};
