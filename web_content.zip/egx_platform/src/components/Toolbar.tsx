import React, { useRef } from "react";
import {
  UploadCloud,
  FileSpreadsheet,
  Layers,
  PieChart,
  TrendingUp,
  Crown,
  Loader2,
} from "lucide-react";

interface ToolbarProps {
  onFileUpload: (file: File) => void;
  isLoading: boolean;
  onOpenHistoricalArchive: () => void;
  onOpenMarketStructure: () => void;
  onOpenOversoldBounce: () => void;
  onOpenOpportunities: () => void;
  hasData: boolean;
}

export const Toolbar: React.FC<ToolbarProps> = ({
  onFileUpload,
  isLoading,
  onOpenHistoricalArchive,
  onOpenMarketStructure,
  onOpenOversoldBounce,
  onOpenOpportunities,
  hasData,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onFileUpload(file);
    }
  };

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-3 md:p-4 shadow-xl mb-3">
      <div className="flex flex-col lg:flex-row items-center justify-between gap-4">
        {/* Upload Box */}
        <div className="w-full lg:w-1/3">
          <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <FileSpreadsheet className="w-4 h-4 text-amber-400" />
              <span>تحميل تقرير التداول اليومي (.xlsx, .xls, .csv)</span>
            </span>
            <span className="text-[10px] text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800/50">
              Excel + CSV
            </span>
          </label>
          <input
            ref={fileInputRef}
            type="file"
            id="fileInput"
            accept=".xlsx,.xls,.csv"
            onChange={handleFileChange}
            className="w-full text-xs text-slate-400
              file:mr-2 file:py-2 file:px-4
              file:rounded-xl file:border-0
              file:text-xs file:font-bold
              file:bg-gradient-to-r file:from-emerald-500 file:to-teal-500 file:text-slate-950
              hover:file:from-emerald-400 hover:file:to-teal-400 file:transition-all
              cursor-pointer bg-slate-950/80
              rounded-xl border border-slate-700/80 p-1.5"
          />
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto">
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={isLoading}
            className="flex-1 lg:flex-none bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold px-4 py-2.5 rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg text-xs cursor-pointer active:scale-95 border border-emerald-500/40"
          >
            {isLoading ? (
              <Loader2 className="w-4 h-4 animate-spin text-white" />
            ) : (
              <UploadCloud className="w-4 h-4" />
            )}
            <span>معالجة وتحليل البيانات + شارت TV</span>
          </button>

          <button
            type="button"
            onClick={onOpenHistoricalArchive}
            disabled={!hasData}
            className="flex-1 lg:flex-none bg-cyan-800 hover:bg-cyan-700 disabled:bg-slate-800 disabled:text-slate-600 disabled:border-slate-700 text-white font-bold px-4 py-2.5 rounded-xl border border-cyan-600/40 transition-all flex items-center justify-center gap-2 shadow-md text-xs cursor-pointer active:scale-95"
          >
            <Layers className="w-4 h-4 text-cyan-300" />
            <span>السلسلة التاريخية</span>
          </button>

          <button
            type="button"
            onClick={onOpenMarketStructure}
            disabled={!hasData}
            className="flex-1 lg:flex-none bg-purple-700 hover:bg-purple-600 disabled:bg-slate-800 disabled:text-slate-600 disabled:border-slate-700 text-white font-bold px-4 py-2.5 rounded-xl border border-purple-600/40 transition-all flex items-center justify-center gap-2 shadow-md text-xs cursor-pointer active:scale-95"
          >
            <PieChart className="w-4 h-4 text-purple-300" />
            <span>تحليل هيكل السوق</span>
          </button>

          <button
            type="button"
            onClick={onOpenOversoldBounce}
            disabled={!hasData}
            className="flex-1 lg:flex-none bg-rose-700 hover:bg-rose-600 disabled:bg-slate-800 disabled:text-slate-600 disabled:border-slate-700 text-white font-bold px-4 py-2.5 rounded-xl border border-rose-600/40 transition-all flex items-center justify-center gap-2 shadow-md text-xs cursor-pointer active:scale-95"
          >
            <TrendingUp className="w-4 h-4 text-rose-300" />
            <span>أنماط الارتداد الشرائي</span>
          </button>

          <button
            type="button"
            onClick={onOpenOpportunities}
            disabled={!hasData}
            className="flex-1 lg:flex-none bg-amber-500 hover:bg-amber-400 disabled:bg-slate-800 disabled:text-slate-600 disabled:border-slate-700 text-slate-950 font-black px-4 py-2.5 rounded-xl border border-amber-400/50 transition-all flex items-center justify-center gap-2 shadow-lg text-xs cursor-pointer active:scale-95"
          >
            <Crown className="w-4 h-4 text-slate-950" />
            <span>فرص الشموع الاستراتيجية (12+)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
