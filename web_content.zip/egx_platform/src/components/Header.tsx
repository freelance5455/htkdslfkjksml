import React from "react";
import { Brain, Copy, Key, Download, Check } from "lucide-react";

interface HeaderProps {
  onOpenApiKeyModal: () => void;
  onOpenDownloadModal: () => void;
  onCopyReport: () => void;
  copied: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenApiKeyModal,
  onOpenDownloadModal,
  onCopyReport,
  copied,
}) => {
  return (
    <header className="flex flex-col md:flex-row items-center justify-between gap-4 bg-slate-900/90 border border-slate-800 px-4 py-3 rounded-2xl shadow-2xl mb-3 backdrop-blur-md">
      <div className="flex items-center gap-3.5">
        <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-emerald-500/20 to-amber-500/20 text-emerald-400 flex items-center justify-center font-bold text-xl shadow-inner border border-emerald-500/30">
          <Brain className="w-6 h-6 text-emerald-400" />
        </div>
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-base md:text-xl font-black text-emerald-400 tracking-tight">
              منصة EGX Pro Cloud - الخبير الاستراتيجي
            </h1>
            <span className="bg-amber-950/90 text-amber-300 border border-amber-700/60 text-[10px] font-mono px-2 py-0.5 rounded-full font-bold">
              v7.0 Real-Data Gate
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            محرك تحليل كمي يحسب من البيانات المستوردة فقط؛ TradingView للشارت الخارجي ولا يُعد مصدر الأسعار داخل المنصة
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2 w-full md:w-auto justify-end flex-wrap">
        <button
          type="button"
          onClick={onCopyReport}
          className="bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-emerald-500/30 px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shadow-sm cursor-pointer active:scale-95"
          title="نسخ ذكي وسريع للتقرير الحالي"
        >
          {copied ? <Check className="w-4 h-4 text-emerald-300" /> : <Copy className="w-4 h-4" />}
          <span>{copied ? "تم النسخ بنجاح" : "النسخ الذكي"}</span>
        </button>

        <button
          type="button"
          onClick={onOpenApiKeyModal}
          className="bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shadow-sm cursor-pointer active:scale-95"
          title="إعداد مفتاح Gemini للجلسة الحالية أو التحقق من إعداد الخادم"
        >
          <Key className="w-4 h-4 text-amber-400" />
          <span>مفتاح الذكاء الاصطناعي</span>
        </button>

        <button
          type="button"
          onClick={onOpenDownloadModal}
          className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white px-4 py-2 rounded-xl shadow-lg transition-all flex items-center gap-2 font-bold text-xs cursor-pointer border border-emerald-500/40 active:scale-95"
          title="تحميل الكود البرمجي كاملاً بصيغة ZIP أو HTML مستقل"
        >
          <Download className="w-4 h-4 text-emerald-200" />
          <span>تحميل الكود كاملاً (ZIP/HTML)</span>
        </button>
      </div>
    </header>
  );
};
