import React from "react";
import { X, TrendingUp, Sparkles, Target, ShieldAlert, ArrowUpRight } from "lucide-react";
import { StockData } from "../types";

interface OversoldBounceModalProps {
  stocks: StockData[];
  onClose: () => void;
  onSelectStock: (stock: StockData) => void;
}

export const OversoldBounceModal: React.FC<OversoldBounceModalProps> = ({
  stocks,
  onClose,
  onSelectStock,
}) => {
  // لا نعرض فرصة ارتداد إلا عندما يكون RSI تاريخيًا متاحًا وتكون بوابة الإشارة مكتملة.
  const bounceCandidates = stocks
    .filter(
      (s) =>
        s.rsi !== null &&
        s.rsi <= 35 &&
        s.signalGate === true &&
        (s.patternType === "bullish" || s.signal === "شراء قوي" || s.signal === "شراء مع تأكيد")
    )
    .sort((a, b) => (a.rsi ?? Infinity) - (b.rsi ?? Infinity));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/90 backdrop-blur-md p-3 md:p-6">
      <div className="bg-[#060913] rounded-2xl border border-slate-800 shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-slate-950 px-4 py-3 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2 text-rose-400 font-bold text-sm md:text-base">
            <TrendingUp className="w-5 h-5 text-rose-400" />
            <span>محرك رصد أنماط الارتداد الشرائي (Oversold Reversal Setups)</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-rose-400 hover:text-white w-8 h-8 rounded-lg bg-rose-950/40 hover:bg-rose-900 flex items-center justify-center border border-rose-900/50 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 text-xs md:text-sm">
          <p className="text-slate-400 text-xs bg-slate-900/80 p-3 rounded-xl border border-slate-800">
            يقوم هذا الفلتر الذكي بفرز الأسهم التي وصلت إلى مناطق تشبع بيعي حاد (RSI &le; 45) أو كونت نماذج شموع انعكاسية صاعدة (مطرقة، دوجي اليعسوب، ابتلاع) بالقرب من مستويات الدعم، مما يمنحها احتمالية ارتداد سريعة بنسبة عائد إلى مخاطرة ممتازة.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {bounceCandidates.length === 0 ? (
              <div className="col-span-2 text-center py-8 text-slate-500">
                لا توجد أسهم حالياً في مناطق تشبع بيعي قاسية في هذه الجلسة.
              </div>
            ) : (
              bounceCandidates.map((stock) => {
                const upsidePercent = stock.target1
                  ? (((stock.target1 - stock.close) / stock.close) * 100).toFixed(1)
                  : "5.0";

                return (
                  <div
                    key={stock.id}
                    onClick={() => {
                      onClose();
                      onSelectStock(stock);
                    }}
                    className="bg-slate-900/90 hover:bg-slate-800/80 border border-slate-800 hover:border-rose-500/50 p-4 rounded-xl cursor-pointer transition-all shadow-md group"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs bg-slate-950 border border-slate-700 px-2 py-0.5 rounded text-amber-400 font-bold">
                          {stock.code}
                        </span>
                        <span className="font-bold text-slate-100 group-hover:text-emerald-400 transition-colors">
                          {stock.name}
                        </span>
                      </div>
                      <div className="font-mono font-bold text-xs text-slate-200">
                        {stock.close} ج.م
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 my-2.5 text-[11px] bg-slate-950/70 p-2.5 rounded-lg border border-slate-800/60">
                      <div>
                        <span className="text-slate-500 block">مؤشر RSI:</span>
                        <span
                          className={`font-mono font-black ${
                            stock.rsi <= 35 ? "text-emerald-400" : "text-amber-400"
                          }`}
                        >
                          {stock.rsi === null ? "N/A" : stock.rsi} (تشبع بيعي)
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-500 block">العائد المحتمل:</span>
                        <span className="font-mono font-black text-emerald-400 flex items-center gap-0.5">
                          <ArrowUpRight className="w-3.5 h-3.5" />
                          +{upsidePercent}%
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-500 block">هدف الارتداد (T1):</span>
                        <span className="font-mono font-bold text-slate-200">
                          {stock.target1 ?? "N/A"} ج.م
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-500 block">وقف الخسارة:</span>
                        <span className="font-mono font-bold text-rose-400">
                          {stock.stopLoss ?? "N/A"} ج.م
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-[11px] mt-2">
                      <span className="text-slate-400 truncate max-w-[200px]">
                        نمط: <strong className="text-amber-300">{stock.candlestickPattern}</strong>
                      </span>
                      <span className="text-rose-400 font-bold group-hover:underline">
                        عرض التحليل والشارت &larr;
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
