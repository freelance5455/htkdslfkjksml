import React from "react";
import { Database, Link2, Calendar, PlusCircle } from "lucide-react";
import { HistoricalSession } from "../types";

interface CloudArchiveBarProps {
  currentDate: string;
  onSelectDate: (date: string) => void;
  savedSessions: HistoricalSession[];
  onSaveCurrentSession: () => void;
}

export const CloudArchiveBar: React.FC<CloudArchiveBarProps> = ({
  currentDate,
  onSelectDate,
  savedSessions,
  onSaveCurrentSession,
}) => {
  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-3 md:p-4 shadow-xl mb-3">
      <div className="flex flex-col md:flex-row items-center justify-between gap-3 border-b border-slate-800/80 pb-3 mb-3">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-indigo-500/10 text-indigo-400 flex items-center justify-center font-bold text-sm border border-indigo-500/20">
            <Database className="w-4 h-4 text-indigo-400" />
          </div>
          <div>
            <h3 className="text-xs md:text-sm font-bold text-slate-200">
              أرشيف الجلسات التاريخية المحلية ومزامنة الشارت
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">
              حفظ الجلسات التي تم تحميلها من ملفات حقيقية وربط الشارت الخارجي بها
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          {/* TradingView Sync Badge */}
          <span className="bg-indigo-950/80 text-indigo-300 border border-indigo-700/60 text-[10px] px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 shadow-sm">
            <Link2 className="w-3.5 h-3.5 text-indigo-400" />
            <span>الشارت: TradingView | الأسعار من الملف</span>
          </span>

          {/* Date Picker */}
          <div className="flex items-center gap-2 bg-slate-950/60 p-1.5 rounded-xl border border-slate-800/60">
            <label htmlFor="sheetDate" className="text-xs text-slate-300 font-medium whitespace-nowrap px-2">
              تاريخ الجلسة:
            </label>
            <input
              type="date"
              id="sheetDate"
              value={currentDate}
              onChange={(e) => {
                if (e.target.value) onSelectDate(e.target.value);
              }}
              className="bg-slate-900 border border-slate-700 text-slate-200 rounded-lg px-3 py-1 text-xs focus:outline-none focus:border-emerald-500 font-bold transition-colors cursor-pointer"
            />
          </div>

          <button
            type="button"
            onClick={onSaveCurrentSession}
            className="bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-emerald-500/30 px-2.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm cursor-pointer"
            title="حفظ بيانات الجلسة الحالية في الأرشيف"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>حفظ الجلسة</span>
          </button>
        </div>
      </div>

      {/* Saved dates buttons */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        <span className="text-xs font-bold text-indigo-400 ml-2 whitespace-nowrap flex items-center gap-1">
          <Calendar className="w-3.5 h-3.5 text-indigo-400" />
          <span>الجلسات المحفوظة:</span>
        </span>
        {savedSessions.map((session) => {
          const isSelected = session.date === currentDate;
          return (
            <button
              key={session.date}
              type="button"
              onClick={() => onSelectDate(session.date)}
              className={`px-3 py-1.5 rounded-lg border text-[11px] cursor-pointer transition-all flex items-center gap-1.5 whitespace-nowrap active:scale-95 ${
                isSelected
                  ? "bg-emerald-600 text-slate-950 font-black border-emerald-400 shadow-lg ring-1 ring-emerald-400/50"
                  : "bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-700/80"
              }`}
            >
              <Calendar className={`w-3 h-3 ${isSelected ? "text-slate-950" : "text-amber-400"}`} />
              <span>{session.date}</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${isSelected ? "bg-emerald-800 text-white" : "bg-slate-800 text-slate-400"}`}>
                {session.stocksCount} سهم
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
