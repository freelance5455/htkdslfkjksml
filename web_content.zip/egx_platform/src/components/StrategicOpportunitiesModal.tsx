import React from "react";
import { X, Crown, Sparkles, Target, ShieldAlert, ArrowUpRight, CheckCircle2 } from "lucide-react";
import { StockData } from "../types";

interface StrategicOpportunitiesModalProps {
  stocks: StockData[];
  onClose: () => void;
  onSelectStock: (stock: StockData) => void;
}

export const StrategicOpportunitiesModal: React.FC<StrategicOpportunitiesModalProps> = ({
  stocks,
  onClose,
  onSelectStock,
}) => {
  // Select top strategic setups (prioritizing high reliability patterns and strong signals)
  const strategicSetups = [...stocks]
    .filter(
      (s) =>
        s.signalGate === true &&
        (s.signal === "شراء قوي" || s.signal === "شراء مع تأكيد") &&
        s.patternType === "bullish"
    )
    .sort((a, b) => {
      const scoreA = (a.patternReliability === "عالية" ? 20 : 10) + (a.changePercent ?? 0);
      const scoreB = (b.patternReliability === "عالية" ? 20 : 10) + (b.changePercent ?? 0);
      return scoreB - scoreA;
    })
    .slice(0, 12);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/90 backdrop-blur-md p-3 md:p-6">
      <div className="bg-[#060913] rounded-2xl border border-slate-800 shadow-2xl w-full max-w-5xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-slate-950 px-4 py-3 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2 text-amber-400 font-bold text-sm md:text-base">
            <Crown className="w-5 h-5 text-amber-400" />
            <span>فرص الإشارات المكتملة ببوابة التأكيد</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-rose-400 hover:text-white w-8 h-8 rounded-lg bg-rose-950/40 hover:bg-rose-900 flex items-center justify-center border border-rose-900/50 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs md:text-sm">
          <div className="flex items-center justify-between bg-amber-950/40 border border-amber-500/40 p-3 rounded-xl">
            <div className="flex items-center gap-2 text-amber-200">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>
                تم فرز وتصفية أفضل نماذج الشموع اليابانية الصاعدة المكتملة المدعومة بالسيولة ونقاط الارتكاز المحورية.
              </span>
            </div>
            <span className="text-[11px] font-bold text-amber-400 bg-amber-900/50 px-2 py-0.5 rounded border border-amber-600/60 font-mono">
              {strategicSetups.length} إشارات اجتازت البوابة
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {strategicSetups.map((stock, idx) => (
              <div
                key={stock.id}
                onClick={() => {
                  onClose();
                  onSelectStock(stock);
                }}
                className="bg-slate-900/90 hover:bg-slate-800/90 border border-slate-800 hover:border-amber-500/50 p-3.5 rounded-xl cursor-pointer transition-all shadow-md group flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-xs font-mono">
                      #{idx + 1}
                    </span>
                    <span className="font-mono text-xs bg-slate-950 border border-slate-700 px-2 py-0.5 rounded text-amber-400 font-bold">
                      {stock.code}
                    </span>
                  </div>

                  <h4 className="font-black text-slate-100 group-hover:text-amber-300 transition-colors text-sm mb-1 truncate">
                    {stock.name}
                  </h4>

                  <div className="flex items-center gap-2 text-xs font-mono mb-2">
                    <span className="text-slate-200 font-bold">{stock.close} ج.م</span>
                    <span className="text-emerald-400 font-bold">
                      {stock.changePercent == null ? "N/A" : `+${stock.changePercent}%`}
                    </span>
                  </div>

                  {/* Pattern Badge */}
                  <div className="bg-slate-950/80 p-2 rounded-lg border border-slate-800 mb-2">
                    <div className="text-[10px] text-slate-400">النمط المكتشف:</div>
                    <div className="text-xs font-bold text-emerald-400 truncate">
                      {stock.candlestickPattern}
                    </div>
                  </div>

                  {/* Key Metrics */}
                  <div className="space-y-1 text-[11px] text-slate-300">
                    <div className="flex justify-between">
                      <span className="text-slate-500">نطاق الدخول:</span>
                      <span className="font-mono text-slate-200">{stock.entryZone || "-"}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">الهدف الأول:</span>
                      <span className="font-mono text-emerald-400 font-bold">{stock.target1} ج.م</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">وقف الخسارة:</span>
                      <span className="font-mono text-rose-400 font-bold">{stock.stopLoss} ج.م</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">العائد / المخاطرة:</span>
                      <span className="font-mono text-amber-300 font-bold">{stock.riskReward || "N/A"}</span>
                    </div>
                  </div>
                </div>

                <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs">
                  <span className="text-slate-400 flex items-center gap-1 text-[10px]">
                    <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                    <span>موثوقية {stock.patternReliability}</span>
                  </span>
                  <span className="text-amber-400 font-bold group-hover:underline text-[11px]">
                    تفاصيل الصفقة &larr;
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
