import React from "react";
import { X, Layers, Calendar, FileText, CheckCircle2 } from "lucide-react";
import { HistoricalSession } from "../types";

interface HistoricalArchiveModalProps {
  sessions: HistoricalSession[];
  currentDate: string;
  onSelectDate: (date: string) => void;
  onClose: () => void;
}

export const HistoricalArchiveModal: React.FC<HistoricalArchiveModalProps> = ({
  sessions,
  currentDate,
  onSelectDate,
  onClose,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/90 backdrop-blur-md p-3 md:p-6">
      <div className="bg-[#060913] rounded-2xl border border-slate-800 shadow-2xl w-full max-w-3xl max-h-[85vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-slate-950 px-4 py-3 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2 text-cyan-400 font-bold text-sm md:text-base">
            <Layers className="w-5 h-5 text-cyan-400" />
            <span>أرشيف السلسلة التاريخية للبورصة المصرية</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-rose-400 hover:text-white w-8 h-8 rounded-lg bg-rose-950/40 hover:bg-rose-900 flex items-center justify-center border border-rose-900/50 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 text-xs md:text-sm">
          <p className="text-slate-400 text-xs bg-slate-900/80 p-3 rounded-xl border border-slate-800">
            يمكنك التبديل بين الجلسات المسجلة في السلسلة الزمنية لمراجعة تطور حركة الأسهم ومطابقة مسارات الشموع السابقة مع حركة الأسعار الحالية.
          </p>

          <div className="space-y-2.5">
            {sessions.map((session) => {
              const isActive = session.date === currentDate;
              return (
                <div
                  key={session.date}
                  onClick={() => {
                    onSelectDate(session.date);
                    onClose();
                  }}
                  className={`p-4 rounded-xl border cursor-pointer transition-all flex items-center justify-between group ${
                    isActive
                      ? "bg-slate-900 border-cyan-500 shadow-lg ring-1 ring-cyan-500/40"
                      : "bg-slate-950/80 hover:bg-slate-900 border-slate-800"
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <Calendar className={`w-4 h-4 ${isActive ? "text-cyan-400" : "text-slate-400"}`} />
                      <span className="font-mono font-bold text-slate-100 text-sm">
                        {session.date}
                      </span>
                      {isActive && (
                        <span className="bg-cyan-950 text-cyan-300 border border-cyan-700/50 text-[10px] px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3 text-cyan-400" />
                          الجلسة النشطة
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-400 flex items-center gap-1.5">
                      <FileText className="w-3 h-3 text-slate-500" />
                      <span>{session.note || "بيانات جلسة التداول اليومي"}</span>
                    </p>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="text-xs font-mono text-slate-300 bg-slate-900 px-2.5 py-1 rounded border border-slate-800">
                      {session.stocksCount} سهم
                    </span>
                    <span className="text-cyan-400 text-xs font-bold group-hover:underline">
                      تحميل الجلسة &larr;
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
