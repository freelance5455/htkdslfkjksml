import React, { useState, useMemo } from "react";
import {
  Search,
  ArrowUpDown,
  TrendingUp,
  TrendingDown,
  LineChart,
  CloudCheck,
  ChevronLeft,
  ChevronRight,
  Sparkles,
} from "lucide-react";
import { StockData } from "../types";
import { formatNumber, formatInteger } from "../utils/display";

interface StocksTableProps {
  stocks: StockData[];
  currentDate: string;
  onSelectStock: (stock: StockData) => void;
}

type SortField = "name" | "close" | "changePercent" | "volume" | "value" | "rsi";
type SortOrder = "asc" | "desc";

export const StocksTable: React.FC<StocksTableProps> = ({
  stocks,
  currentDate,
  onSelectStock,
}) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [signalFilter, setSignalFilter] = useState<string>("all");
  const [sortField, setSortField] = useState<SortField>("value");
  const [sortOrder, setSortOrder] = useState<SortOrder>("desc");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 12;

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortOrder("desc");
    }
  };

  const filteredAndSortedStocks = useMemo(() => {
    let result = [...stocks];

    // Filter by search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter(
        (s) =>
          s.name.toLowerCase().includes(q) ||
          s.code.toLowerCase().includes(q) ||
          s.candlestickPattern.toLowerCase().includes(q) ||
          s.sector?.toLowerCase().includes(q)
      );
    }

    // Filter by signal
    if (signalFilter !== "all") {
      result = result.filter((s) => s.signal === signalFilter);
    }

    // Sort
    result.sort((a, b) => {
      let valA: any = a[sortField];
      let valB: any = b[sortField];

      if (typeof valA === "string" || typeof valB === "string") {
        return sortOrder === "asc"
          ? String(valA ?? "").localeCompare(String(valB ?? ""), "ar")
          : String(valB ?? "").localeCompare(String(valA ?? ""), "ar");
      }
      const aNum = typeof valA === "number" && Number.isFinite(valA) ? valA : null;
      const bNum = typeof valB === "number" && Number.isFinite(valB) ? valB : null;
      if (aNum === null && bNum === null) return 0;
      if (aNum === null) return 1;
      if (bNum === null) return -1;
      return sortOrder === "asc" ? aNum - bNum : bNum - aNum;
    });

    return result;
  }, [stocks, searchQuery, signalFilter, sortField, sortOrder]);

  const totalPages = Math.max(1, Math.ceil(filteredAndSortedStocks.length / itemsPerPage));
  const paginatedStocks = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredAndSortedStocks.slice(start, start + itemsPerPage);
  }, [filteredAndSortedStocks, currentPage]);

  const getSignalBadgeStyle = (signal: string) => {
    switch (signal) {
      case "شراء قوي":
        return "bg-emerald-950/90 text-emerald-300 border-emerald-500/60 font-black";
      case "شراء مع تأكيد":
        return "bg-teal-950/80 text-teal-300 border-teal-600/50 font-bold";
      case "ترقب":
        return "bg-slate-800 text-slate-300 border-slate-700";
      case "جني أرباح":
        return "bg-amber-950/80 text-amber-300 border-amber-600/50 font-bold";
      case "حذر ووقف خسارة":
        return "bg-rose-950/90 text-rose-300 border-rose-600/60 font-black";
      default:
        return "bg-slate-800 text-slate-400 border-slate-700";
    }
  };

  const getPatternBadgeStyle = (type: "bullish" | "bearish" | "neutral") => {
    switch (type) {
      case "bullish":
        return "bg-emerald-500/10 text-emerald-400 border-emerald-500/30";
      case "bearish":
        return "bg-rose-500/10 text-rose-400 border-rose-500/30";
      default:
        return "bg-slate-800/80 text-slate-300 border-slate-700";
    }
  };

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-3 md:p-4 shadow-2xl w-full">
      {/* Table Header Controls */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-3 mb-4">
        <div className="flex items-center gap-3 flex-wrap">
          <h2 className="text-xs md:text-base font-bold text-slate-200 flex items-center gap-2">
            <span className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs shadow-inner">
              <LineChart className="w-4 h-4" />
            </span>
            <span>جلسة:</span>
            <span className="text-emerald-400 tracking-wide font-black">
              {currentDate}
            </span>
          </h2>
          <span className="text-[10px] bg-emerald-950/80 text-emerald-300 border border-emerald-800/50 px-2.5 py-1 rounded-full flex items-center gap-1.5 font-bold shadow-sm">
            <CloudCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>مصدر: الملف المستورد ({stocks.length} أسهم)</span>
          </span>
        </div>

        {/* Search & Filter */}
        <div className="flex items-center gap-2 w-full md:w-auto flex-wrap">
          {/* Signal Filter */}
          <select
            value={signalFilter}
            onChange={(e) => {
              setSignalFilter(e.target.value);
              setCurrentPage(1);
            }}
            className="bg-slate-950/90 border border-slate-700/80 rounded-xl py-2 px-3 text-xs text-slate-200 focus:outline-none focus:border-emerald-500 cursor-pointer"
          >
            <option value="all">كل الإشارات</option>
            <option value="شراء قوي">شراء قوي 🟢</option>
            <option value="شراء مع تأكيد">شراء مع تأكيد</option>
            <option value="ترقب">ترقب وحياد</option>
            <option value="جني أرباح">جني أرباح 🟡</option>
            <option value="حذر ووقف خسارة">حذر ووقف خسارة 🔴</option>
          </select>

          {/* Search Input */}
          <div className="w-full md:w-72 relative">
            <span className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-slate-400">
              <Search className="w-4 h-4" />
            </span>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setCurrentPage(1);
              }}
              placeholder="بحث ذكي (اسم السهم، الكود، نمط الشمعة...)"
              className="w-full bg-slate-950/90 border border-slate-700/80 rounded-xl py-2 pr-9 pl-4 text-xs text-slate-200 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 shadow-inner transition-all"
            />
          </div>
        </div>
      </div>

      {/* Main Table */}
      <div className="rounded-xl border border-slate-800 overflow-x-auto bg-slate-950/90 w-full shadow-inner">
        <table className="w-full text-right text-xs text-slate-300">
          <thead className="bg-slate-900/95 text-[11px] text-slate-400 font-bold border-b border-slate-800 select-none">
            <tr>
              <th
                onClick={() => handleSort("name")}
                className="py-3 px-3 cursor-pointer hover:bg-slate-800/60 hover:text-emerald-400 transition-colors"
              >
                <div className="flex items-center gap-1.5">
                  <span>الرمز والشركة</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-500" />
                </div>
              </th>
              <th
                onClick={() => handleSort("close")}
                className="py-3 px-3 cursor-pointer hover:bg-slate-800/60 hover:text-emerald-400 transition-colors"
              >
                <div className="flex items-center gap-1.5">
                  <span>سعر الإغلاق</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-500" />
                </div>
              </th>
              <th
                onClick={() => handleSort("changePercent")}
                className="py-3 px-3 cursor-pointer hover:bg-slate-800/60 hover:text-emerald-400 transition-colors"
              >
                <div className="flex items-center gap-1.5">
                  <span>التغير %</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-500" />
                </div>
              </th>
              <th className="py-3 px-3 hidden lg:table-cell">
                <span>مدى الجلسة (أدنى - أعلى)</span>
              </th>
              <th className="py-3 px-3">
                <span>نمط الشمعة اليابانية</span>
              </th>
              <th
                onClick={() => handleSort("rsi")}
                className="py-3 px-3 cursor-pointer hover:bg-slate-800/60 hover:text-emerald-400 transition-colors hidden sm:table-cell"
              >
                <div className="flex items-center gap-1.5">
                  <span>مؤشر RSI</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-500" />
                </div>
              </th>
              <th className="py-3 px-3 hidden xl:table-cell">
                <span>نقطة الارتكاز والدعم</span>
              </th>
              <th className="py-3 px-3">
                <span>الإشارة الفنية</span>
              </th>
              <th className="py-3 px-3 text-center">
                <span>التحليل والشارت</span>
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/80">
            {paginatedStocks.length === 0 ? (
              <tr>
                <td colSpan={9} className="py-8 text-center text-slate-500">
                  لا توجد نتائج مطابقة لبحثك.
                </td>
              </tr>
            ) : (
              paginatedStocks.map((stock) => {
                const isPositive = stock.changePercent != null && stock.changePercent > 0;
                const isNegative = stock.changePercent != null && stock.changePercent < 0;

                return (
                  <tr
                    key={stock.id}
                    onClick={() => onSelectStock(stock)}
                    className="hover:bg-slate-800/40 cursor-pointer transition-colors group"
                  >
                    {/* Stock & Code */}
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-xs bg-slate-900 border border-slate-700/80 px-2 py-0.5 rounded text-amber-400 group-hover:border-emerald-500/50">
                          {stock.code}
                        </span>
                        <div>
                          <div className="font-bold text-slate-100 group-hover:text-emerald-400 transition-colors">
                            {stock.name}
                          </div>
                          <div className="text-[10px] text-slate-500">
                            {stock.sector || "سوق الأسهم الرئيسي"}
                          </div>
                        </div>
                      </div>
                    </td>

                    {/* Close */}
                    <td className="py-3 px-3 font-mono font-black text-sm text-slate-100">
                      {formatNumber(stock.close)}{" "}
                      <span className="text-[10px] font-sans text-slate-500 font-normal">
                        ج.م
                      </span>
                    </td>

                    {/* Change % */}
                    <td className="py-3 px-3 font-mono font-bold text-xs">
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-lg border ${
                          isPositive
                            ? "bg-emerald-950/80 text-emerald-400 border-emerald-800/60"
                            : isNegative
                            ? "bg-rose-950/80 text-rose-400 border-rose-800/60"
                            : "bg-slate-900 text-slate-400 border-slate-800"
                        }`}
                      >
                        {isPositive && <TrendingUp className="w-3 h-3" />}
                        {isNegative && <TrendingDown className="w-3 h-3" />}
                        <span>
                          {stock.changePercent == null ? "N/A" : `${isPositive ? "+" : ""}${formatNumber(stock.changePercent)}%`}
                        </span>
                      </span>
                    </td>

                    {/* Day Range */}
                    <td className="py-3 px-3 font-mono text-[11px] text-slate-400 hidden lg:table-cell">
                      <div className="flex items-center gap-2">
                        <span className="text-slate-500">{formatNumber(stock.low)}</span>
                        <div className="w-16 h-1.5 bg-slate-800 rounded-full overflow-hidden relative">
                          <div
                            className="h-full bg-gradient-to-r from-teal-500 to-emerald-400 rounded-full"
                            style={{
                              width: `${Math.min(
                                100,
                                Math.max(
                                  10,
                                  ((stock.close - stock.low) /
                                    Math.max(0.01, stock.high - stock.low)) *
                                    100
                                )
                              )}%`,
                            }}
                          />
                        </div>
                        <span className="text-slate-300 font-bold">{formatNumber(stock.high)}</span>
                      </div>
                    </td>

                    {/* Candlestick Pattern */}
                    <td className="py-3 px-3">
                      <span
                        className={`inline-flex items-center gap-1.5 text-[11px] px-2.5 py-1 rounded-lg border font-bold ${getPatternBadgeStyle(
                          stock.patternType
                        )}`}
                        title={stock.patternDescription}
                      >
                        <Sparkles className="w-3 h-3" />
                        <span>{stock.candlestickPattern}</span>
                      </span>
                    </td>

                    {/* RSI */}
                    <td className="py-3 px-3 font-mono hidden sm:table-cell">
                      <div className="flex items-center gap-1.5">
                        <span
                          className={`font-black text-xs ${
                            stock.rsi !== null && stock.rsi <= 35
                              ? "text-emerald-400"
                              : stock.rsi !== null && stock.rsi >= 70
                              ? "text-rose-400"
                              : "text-amber-400"
                          }`}
                        >
                          {formatNumber(stock.rsi, 1)}
                        </span>
                        <span className="text-[10px] text-slate-500">
                          {stock.rsi === null ? "(غير متاح)" : stock.rsi <= 35 ? "(تشبع بيعي)" : stock.rsi >= 70 ? "(تشبع شرائي)" : ""}
                        </span>
                      </div>
                    </td>

                    {/* Pivot & Support */}
                    <td className="py-3 px-3 font-mono text-[11px] text-slate-400 hidden xl:table-cell">
                      <div>
                        ارتكاز: <span className="text-slate-200">{formatNumber(stock.pivot)}</span>
                      </div>
                      <div className="text-[10px] text-slate-500">
                        دعم 1: {formatNumber(stock.support1)} | مقاومة 1: {formatNumber(stock.resistance1)}
                      </div>
                    </td>

                    {/* Signal */}
                    <td className="py-3 px-3">
                      <span
                        className={`inline-flex items-center px-2.5 py-1 rounded-lg border text-[11px] ${getSignalBadgeStyle(
                          stock.signal
                        )}`}
                      >
                        {stock.signal}
                      </span>
                    </td>

                    {/* Action */}
                    <td className="py-3 px-3 text-center">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectStock(stock);
                        }}
                        className="bg-slate-800 hover:bg-emerald-600 text-emerald-400 hover:text-slate-950 font-bold px-3 py-1.5 rounded-lg border border-slate-700 hover:border-emerald-400 text-xs transition-all shadow-sm cursor-pointer active:scale-95 inline-flex items-center gap-1"
                      >
                        <span>تحليل + TV</span>
                      </button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Footer */}
      <div className="flex flex-col md:flex-row items-center justify-between mt-3 pt-3 border-t border-slate-800 text-xs text-slate-400 gap-3">
        <div>
          عرض {(currentPage - 1) * itemsPerPage + 1} إلى{" "}
          {Math.min(currentPage * itemsPerPage, filteredAndSortedStocks.length)} من إجمالي{" "}
          <span className="text-emerald-400 font-bold">
            {filteredAndSortedStocks.length}
          </span>{" "}
          سهم
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-30 disabled:hover:bg-slate-800 text-slate-200 border border-slate-700 cursor-pointer"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
          <span className="font-mono font-bold px-2">
            صفحة {currentPage} من {totalPages}
          </span>
          <button
            type="button"
            onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-30 disabled:hover:bg-slate-800 text-slate-200 border border-slate-700 cursor-pointer"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
