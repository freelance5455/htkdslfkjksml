import React, { useState } from "react";
import { X, PieChart, TrendingUp, TrendingDown, Wand2, Loader2, Sparkles } from "lucide-react";
import { StockData, MarketStats } from "../types";
import { formatNumber } from "../utils/display";

interface MarketStructureModalProps {
  stats: MarketStats;
  stocks: StockData[];
  onClose: () => void;
  customApiKey?: string;
  onSelectStock: (stock: StockData) => void;
}

export const MarketStructureModal: React.FC<MarketStructureModalProps> = ({
  stats,
  stocks,
  onClose,
  customApiKey,
  onSelectStock,
}) => {
  const [aiAnalysis, setAiAnalysis] = useState<string>("");
  const [isLoadingAi, setIsLoadingAi] = useState(false);
  const formatChange = (value: number | null) => value == null ? "N/A" : `${value > 0 ? "+" : ""}${formatNumber(value)}%`;

  const withChange = stocks.filter((s) => Number.isFinite(s.changePercent));
  const topGainers = [...withChange].sort((a, b) => (b.changePercent as number) - (a.changePercent as number)).slice(0, 5);
  const topLosers = [...withChange].sort((a, b) => (a.changePercent as number) - (b.changePercent as number)).slice(0, 5);
  const volumeLeaders = [...stocks].sort((a, b) => (b.value ?? -1) - (a.value ?? -1)).slice(0, 5);

  const total = stats.advancers + stats.decliners + stats.unchanged || 1;
  const advancerPercent = Math.round((stats.advancers / total) * 100);
  const declinerPercent = Math.round((stats.decliners / total) * 100);
  const unchangedPercent = 100 - advancerPercent - declinerPercent;

  const handleGenerateAiAnalysis = async () => {
    setIsLoadingAi(true);
    try {
      const res = await fetch("/api/gemini/market-structure", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          marketStats: stats,
          topGainers,
          topLosers,
          volumeLeaders,
          customApiKey,
        }),
      });
      const data = await res.json();
      setAiAnalysis(data.text || "تم التحليل بنجاح.");
    } catch (err: any) {
      setAiAnalysis("حدث خطأ أثناء تحليل هيكل السوق: " + err.message);
    } finally {
      setIsLoadingAi(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/90 backdrop-blur-md p-3 md:p-6">
      <div className="bg-[#060913] rounded-2xl border border-slate-800 shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-slate-950 px-4 py-3 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2 text-purple-400 font-bold text-sm md:text-base">
            <PieChart className="w-5 h-5 text-purple-400" />
            <span>تحليل هيكل السوق واتساع السيولة (Market Breadth)</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-rose-400 hover:text-white w-8 h-8 rounded-lg bg-rose-950/40 hover:bg-rose-900 flex items-center justify-center border border-rose-900/50 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs md:text-sm">
          {/* Breadth Progress Bar */}
          <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-200 flex items-center gap-2">
                <span>معنويات السوق العامة:</span>
                <span className="text-amber-400 font-black px-2 py-0.5 bg-amber-950/60 rounded border border-amber-600/40 text-xs">
                  {stats.marketSentiment}
                </span>
              </span>
              <span className="text-slate-400 text-xs font-mono">
                إجمالي التداول: {(stats.totalValue / 1e6).toFixed(1)} مليون ج.م
              </span>
            </div>

            <div className="h-3.5 w-full bg-slate-950 rounded-full overflow-hidden flex shadow-inner">
              <div
                className="h-full bg-emerald-500 transition-all"
                style={{ width: `${advancerPercent}%` }}
                title={`الصاعدون: ${stats.advancers} (${advancerPercent}%)`}
              />
              <div
                className="h-full bg-slate-600 transition-all"
                style={{ width: `${unchangedPercent}%` }}
                title={`المستقرون: ${stats.unchanged} (${unchangedPercent}%)`}
              />
              <div
                className="h-full bg-rose-500 transition-all"
                style={{ width: `${declinerPercent}%` }}
                title={`الهابطون: ${stats.decliners} (${declinerPercent}%)`}
              />
            </div>

            <div className="flex items-center justify-between text-xs text-slate-300">
              <span className="flex items-center gap-1 text-emerald-400 font-bold">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                صاعد: {stats.advancers} سهم ({advancerPercent}%)
              </span>
              <span className="flex items-center gap-1 text-slate-400">
                <span className="w-2.5 h-2.5 rounded-full bg-slate-500" />
                مستقر: {stats.unchanged} سهم
              </span>
              <span className="flex items-center gap-1 text-rose-400 font-bold">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                هابط: {stats.decliners} سهم ({declinerPercent}%)
              </span>
            </div>
          </div>

          {/* Top Gainers & Top Losers Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Top Gainers */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3">
              <h4 className="font-bold text-emerald-400 mb-2 flex items-center gap-1.5 text-xs">
                <TrendingUp className="w-4 h-4" />
                <span>أكثر الأسهم صعوداً (Top Gainers)</span>
              </h4>
              <div className="space-y-1.5">
                {topGainers.map((s) => (
                  <div
                    key={s.id}
                    onClick={() => {
                      onClose();
                      onSelectStock(s);
                    }}
                    className="flex items-center justify-between p-2 rounded-lg bg-slate-950/70 hover:bg-slate-800 border border-slate-800/80 cursor-pointer transition-colors"
                  >
                    <div>
                      <span className="font-bold text-slate-100">{s.name}</span>
                      <span className="text-slate-500 text-[10px] mr-2">({s.code})</span>
                    </div>
                    <div className="font-mono text-emerald-400 font-black">
                      +{formatChange(s.changePercent)}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Top Losers */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3">
              <h4 className="font-bold text-rose-400 mb-2 flex items-center gap-1.5 text-xs">
                <TrendingDown className="w-4 h-4" />
                <span>أكثر الأسهم هبوطاً (Top Losers)</span>
              </h4>
              <div className="space-y-1.5">
                {topLosers.map((s) => (
                  <div
                    key={s.id}
                    onClick={() => {
                      onClose();
                      onSelectStock(s);
                    }}
                    className="flex items-center justify-between p-2 rounded-lg bg-slate-950/70 hover:bg-slate-800 border border-slate-800/80 cursor-pointer transition-colors"
                  >
                    <div>
                      <span className="font-bold text-slate-100">{s.name}</span>
                      <span className="text-slate-500 text-[10px] mr-2">({s.code})</span>
                    </div>
                    <div className="font-mono text-rose-400 font-black">
                      {formatChange(s.changePercent)}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* AI Strategic Market Overview */}
          <div className="bg-slate-900/90 border border-purple-500/30 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h4 className="font-black text-purple-300 flex items-center gap-2 text-xs">
                <Wand2 className="w-4 h-4 text-purple-400" />
                <span>التقرير الهيكلي المتعمق من خبير البورصة المصرية (AI)</span>
              </h4>
              <button
                type="button"
                onClick={handleGenerateAiAnalysis}
                disabled={isLoadingAi}
                className="bg-purple-600 hover:bg-purple-500 text-white font-bold px-3 py-1.5 rounded-lg text-xs transition-all flex items-center gap-1.5 shadow-md cursor-pointer active:scale-95"
              >
                {isLoadingAi ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Sparkles className="w-3.5 h-3.5" />
                )}
                <span>توليد قراءة الهيكل</span>
              </button>
            </div>

            {isLoadingAi ? (
              <div className="py-6 flex flex-col items-center justify-center text-center space-y-2">
                <Loader2 className="w-6 h-6 text-purple-400 animate-spin" />
                <p className="text-xs text-slate-400">جاري قراءة السيولة وتوزيع الصفقات...</p>
              </div>
            ) : aiAnalysis ? (
              <div className="prose prose-invert max-w-none text-xs md:text-sm leading-relaxed whitespace-pre-line text-slate-200">
                {aiAnalysis}
              </div>
            ) : (
              <p className="text-xs text-slate-400 text-center py-2">
                اضغط على "توليد قراءة الهيكل" للحصول على قراءة استراتيجية لحركة السيولة وفرص الجلسة القادمة.
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
