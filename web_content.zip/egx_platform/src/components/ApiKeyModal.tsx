import React, { useState } from "react";
import { X, Key, ShieldCheck, Check, Trash2, Loader2, AlertCircle } from "lucide-react";

interface ApiKeyModalProps {
  customApiKey: string;
  onSaveApiKey: (key: string) => void;
  onClose: () => void;
}

export const ApiKeyModal: React.FC<ApiKeyModalProps> = ({
  customApiKey,
  onSaveApiKey,
  onClose,
}) => {
  const [keyValue, setKeyValue] = useState(customApiKey);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{
    valid: boolean;
    message: string;
  } | null>(null);

  const handleTestKey = async () => {
    const key = keyValue.trim();
    if (!key) {
      setTestResult({ valid: false, message: "يرجى كتابة المفتاح المراد فحصه أولاً." });
      return;
    }

    setIsTesting(true);
    setTestResult(null);

    try {
      const res = await fetch("/api/gemini/verify-key", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ apiKey: key }),
      });
      const data = await res.json();
      if (res.ok && data.valid) {
        setTestResult({ valid: true, message: "تم التحقق! المفتاح يعمل وصالح للاستخدام." });
      } else {
        setTestResult({
          valid: false,
          message: data.error || "المفتاح غير صالح أو لم يتم قبوله من Google Gemini.",
        });
      }
    } catch (err: any) {
      setTestResult({
        valid: false,
        message: "تعذر فحص المفتاح: " + (err.message || "خطأ اتصال"),
      });
    } finally {
      setIsTesting(false);
    }
  };

  const handleSave = () => {
    onSaveApiKey(keyValue.trim());
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 1200);
  };

  const handleClear = () => {
    setKeyValue("");
    onSaveApiKey("");
    setTestResult({
      valid: true,
      message: "تم مسح المفتاح المخصص والعودة لإعداد الخادم.",
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/90 backdrop-blur-md p-3 md:p-6">
      <div className="bg-[#060913] rounded-2xl border border-slate-800 shadow-2xl w-full max-w-lg overflow-hidden">
        {/* Header */}
        <div className="bg-slate-950 px-4 py-3 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2 text-amber-400 font-bold text-sm md:text-base">
            <Key className="w-5 h-5 text-amber-400" />
            <span>إعداد مفتاح الذكاء الاصطناعي (Gemini API Key)</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-rose-400 hover:text-white w-8 h-8 rounded-lg bg-rose-950/40 hover:bg-rose-900 flex items-center justify-center border border-rose-900/50 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4 text-xs md:text-sm text-slate-300">
          <div className="bg-emerald-950/40 border border-emerald-600/40 p-3 rounded-xl flex items-start gap-2.5">
            <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div className="text-xs leading-relaxed text-slate-300">
              <strong className="text-emerald-300 block mb-1">
                المفتاح الأساسي على الخادم (Server-side Gemini):
              </strong>
              لا يوجد مفتاح مُضمّن داخل الواجهة. في بيئة الإنتاج يجب ضبط GEMINI_API_KEY على الخادم، والمفتاح المخصص هنا لا يُحفظ بعد إغلاق الصفحة.
            </div>
          </div>

          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-300">
              مفتاح Gemini API المخصص للجلسة الحالية (اختياري):
            </label>
            <div className="flex gap-2">
              <input
                type="password"
                value={keyValue}
                onChange={(e) => {
                  setKeyValue(e.target.value);
                  setTestResult(null);
                }}
                placeholder="AIzaSy..."
                className="flex-1 bg-slate-950 border border-slate-700/80 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-500 font-mono shadow-inner"
              />
              <button
                type="button"
                onClick={handleTestKey}
                disabled={isTesting || !keyValue.trim()}
                className="bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-amber-300 border border-slate-700 px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
              >
                {isTesting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : null}
                <span>فحص المفتاح</span>
              </button>
            </div>
          </div>

          {testResult && (
            <div
              className={`p-2.5 rounded-lg border text-xs flex items-center gap-2 ${
                testResult.valid
                  ? "bg-emerald-950/60 border-emerald-600/50 text-emerald-300"
                  : "bg-rose-950/60 border-rose-600/50 text-rose-300"
              }`}
            >
              {testResult.valid ? (
                <Check className="w-4 h-4 text-emerald-400 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              )}
              <span>{testResult.message}</span>
            </div>
          )}

          {savedSuccess && (
            <div className="p-2.5 bg-emerald-950/60 border border-emerald-600/50 text-emerald-300 rounded-lg flex items-center gap-2 text-xs font-bold">
              <Check className="w-4 h-4 text-emerald-400" />
              <span>تم حفظ الإعدادات بنجاح!</span>
            </div>
          )}

          {/* Buttons */}
          <div className="flex items-center justify-between pt-2 border-t border-slate-800">
            <button
              type="button"
              onClick={handleClear}
              className="text-slate-400 hover:text-rose-400 text-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>استخدام مفتاح الخادم</span>
            </button>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={onClose}
                className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={handleSave}
                className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-black px-4 py-2 rounded-xl text-xs transition-all flex items-center gap-1.5 shadow-md cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>حفظ التعديلات</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
