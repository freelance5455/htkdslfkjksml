import React, { useState, useEffect, useRef } from "react";
import {
  Wand2,
  Copy,
  Maximize2,
  Minimize2,
  X,
  CandlestickChart,
  LineChart,
  MessageSquare,
  Radar,
  Send,
  Loader2,
  ShieldAlert,
  Target,
  ArrowUpRight,
  Sparkles,
  Check,
} from "lucide-react";
import { StockData, ChatMessage } from "../types";
import { formatNumber, formatInteger } from "../utils/display";

interface StockModalProps {
  stock: StockData;
  onClose: () => void;
  customApiKey?: string;
}

export const StockModal: React.FC<StockModalProps> = ({
  stock,
  onClose,
  customApiKey,
}) => {
  const [activeTab, setActiveTab] = useState<"report" | "chart" | "chat">("report");
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [copied, setCopied] = useState(false);

  // Strategic AI In-depth Report State
  const [aiReport, setAiReport] = useState<string>("");
  const [isAiReportLoading, setIsAiReportLoading] = useState<boolean>(false);
  const [aiReportError, setAiReportError] = useState<string>("");

  // AI Chart Radar Scanner State
  const [scanResult, setScanResult] = useState<string>("");
  const [isScanning, setIsScanning] = useState<boolean>(false);

  // Interactive Chat State
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "welcome",
      role: "assistant",
      content: `أهلاً بك! أنا مساعدك الفني الذكي لسهم **${stock.name} (${stock.code})**.\nسعر الإغلاق: **${stock.close} ج.م** (${stock.changePercent == null ? "N/A" : `${stock.changePercent > 0 ? "+" : ""}${formatNumber(stock.changePercent)}%`})\nنمط الشمعة المكتشف: **${stock.candlestickPattern}**.\nكيف يمكنني مساعدتك في اتخاذ قرارك الاستثماري اليوم؟`,
      timestamp: new Date().toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" }),
    },
  ]);
  const [inputMessage, setInputMessage] = useState("");
  const [isChatLoading, setIsChatLoading] = useState(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Fetch AI Strategic Report when modal opens
  useEffect(() => {
    let isMounted = true;

    async function fetchAiReport() {
      setIsAiReportLoading(true);
      setAiReportError("");
      try {
        const res = await fetch("/api/gemini/analyze-stock", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ stock, customApiKey }),
        });

        if (!res.ok) {
          const errData = await res.json().catch(() => ({}));
          throw new Error(errData.error || "تعذر إتمام التحليل عبر الذكاء الاصطناعي");
        }

        const data = await res.json();
        if (isMounted) {
          setAiReport(data.text || "");
        }
      } catch (err: any) {
        if (isMounted) {
          let msg = err?.message || "فشل الاتصال بمحرك الذكاء الاصطناعي.";
          if (msg.includes("API key") || msg.includes("configured")) {
            msg = "محرك الذكاء الاصطناعي غير مهيأ أو أن المفتاح غير صالح على الخادم.";
          }
          setAiReportError(msg);
        }
      } finally {
        if (isMounted) {
          setIsAiReportLoading(false);
        }
      }
    }

    fetchAiReport();
    return () => {
      isMounted = false;
    };
  }, [stock, customApiKey]);

  useEffect(() => {
    if (activeTab === "chat") {
      chatBottomRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, activeTab]);

  const handleScanChart = async () => {
    setIsScanning(true);
    setScanResult("");
    try {
      const res = await fetch("/api/gemini/scan-chart", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ stock, customApiKey }),
      });
      const data = await res.json();
      setScanResult(data.text || "تم المسح بنجاح.");
    } catch (err: any) {
      setScanResult("تعذر تشغيل ماسح الشارت في الوقت الحالي: " + err.message);
    } finally {
      setIsScanning(false);
    }
  };

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputMessage).trim();
    if (!query || isChatLoading) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}-user`,
      role: "user",
      content: query,
      timestamp: new Date().toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputMessage("");
    setIsChatLoading(true);

    try {
      const res = await fetch("/api/gemini/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...messages, userMsg],
          stockContext: stock,
          customApiKey,
        }),
      });

      const data = await res.json();
      const assistantMsg: ChatMessage = {
        id: `msg-${Date.now()}-assistant`,
        role: "assistant",
        content: data.text || "عذراً، لم أتمكن من الحصول على إجابة من الخبير.",
        timestamp: new Date().toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" }),
      };
      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: `msg-${Date.now()}-error`,
          role: "assistant",
          content: "حدث خطأ أثناء معالجة السؤال: " + err.message,
          timestamp: new Date().toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" }),
        },
      ]);
    } finally {
      setIsChatLoading(false);
    }
  };

  const copyFullReport = () => {
    const text = `📊 تقرير EGX Pro Cloud الفني والاستراتيجي
السهم: ${stock.name} (${stock.code || "غير متاح"})
مصدر البيانات: ${stock.dataQuality.source} | تاريخ أحدث جلسة: ${stock.dataQuality.asOfDate || "غير متاح"} | عدد الجلسات: ${stock.dataQuality.bars}
سعر الإغلاق: ${formatNumber(stock.close)} ج.م | التغير: ${formatNumber(stock.changePercent)}%
نمط الشمعة اليابانية: ${stock.candlestickPattern} (${stock.patternReliability})
RSI14: ${formatNumber(stock.technical?.rsi14, 1)}
MACD Histogram: ${formatNumber(stock.technical?.macdHistogram, 3)}
ADX14: ${formatNumber(stock.technical?.adx14, 1)}
نقطة الارتكاز (Pivot): ${formatNumber(stock.pivot)}
الدعوم: S1 = ${formatNumber(stock.support1)} | S2 = ${formatNumber(stock.support2)}
المقاومات: R1 = ${formatNumber(stock.resistance1)} | R2 = ${formatNumber(stock.resistance2)}
بوابة الإشارة: ${stock.signalGate ? "مكتملة" : "غير مكتملة"}
الإشارة: ${stock.signal}
منطقة الدخول: ${stock.entryZone || "N/A"}
الهدف الأول: ${formatNumber(stock.target1)} ج.م | الهدف الثاني: ${formatNumber(stock.target2)} ج.م
وقف الخسارة: ${formatNumber(stock.stopLoss)} ج.م
نسبة العائد إلى المخاطرة: ${stock.riskReward || "N/A"}

${aiReport ? `\n--- تحليل الذكاء الاصطناعي ---\n${aiReport}` : ""}`;

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // TradingView Iframe Widget URL with clean parameters
  const tvWidgetUrl = `https://s.tradingview.com/widgetembed/?symbol=${encodeURIComponent(
    stock.tvSymbol
  )}&interval=D&theme=dark&style=1&timezone=Africa%2FCairo&hide_top_toolbar=0&save_image=0&locale=ar_AE`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/90 backdrop-blur-md p-0 md:p-4 transition-opacity">
      <div
        className={`bg-[#060913] rounded-2xl border border-slate-800 shadow-2xl overflow-hidden flex flex-col transition-all duration-300 ${
          isFullscreen ? "w-screen h-screen rounded-none border-0" : "w-full max-w-5xl h-[92vh]"
        }`}
      >
        {/* Header Toolbar */}
        <div className="bg-slate-950 px-4 py-3 flex items-center justify-between border-b border-slate-800 shrink-0 shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-sm border border-emerald-500/30">
              <Wand2 className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xs md:text-base font-black text-emerald-400">
                  {stock.name}
                </h3>
                <span className="font-mono text-xs bg-slate-900 border border-slate-700 px-2 py-0.5 rounded text-amber-400 font-bold">
                  {stock.code}
                </span>
                <span className="font-mono text-xs text-slate-300 font-bold">
                  {formatNumber(stock.close)} ج.م
                </span>
                <span
                  className={`text-[10px] font-mono px-1.5 py-0.5 rounded font-bold ${
                    stock.changePercent == null
                      ? "bg-slate-900 text-slate-400"
                      : stock.changePercent >= 0
                      ? "bg-emerald-950 text-emerald-400"
                      : "bg-rose-950 text-rose-400"
                  }`}
                >
                  {stock.changePercent == null ? "N/A" : `${stock.changePercent >= 0 ? "+" : ""}${formatNumber(stock.changePercent)}%`}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={copyFullReport}
              className="text-emerald-400 hover:text-white text-xs bg-emerald-950/60 hover:bg-emerald-900 px-2.5 py-1.5 rounded-lg flex items-center gap-1.5 border border-emerald-800/50 cursor-pointer transition-colors font-bold"
              title="نسخ التقرير"
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span className="hidden sm:inline">{copied ? "تم النسخ" : "نسخ التقرير"}</span>
            </button>
            <button
              type="button"
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="text-slate-300 hover:text-white text-xs bg-slate-800/60 hover:bg-slate-700 w-8 h-8 rounded-lg flex items-center justify-center border border-slate-700 cursor-pointer transition-colors"
              title="تكبير / تصغير"
            >
              {isFullscreen ? (
                <Minimize2 className="w-3.5 h-3.5" />
              ) : (
                <Maximize2 className="w-3.5 h-3.5" />
              )}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="text-rose-400 hover:text-white text-xs bg-rose-950/40 hover:bg-rose-900 w-8 h-8 rounded-lg flex items-center justify-center border border-rose-900/50 cursor-pointer transition-colors"
              title="إغلاق"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="bg-slate-900/90 border-b border-slate-800 px-4 py-1.5 flex items-center gap-4 text-xs font-bold text-slate-400 shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab("report")}
            className={`py-1.5 px-1 flex items-center gap-1.5 cursor-pointer transition-colors ${
              activeTab === "report"
                ? "border-b-2 border-emerald-500 text-emerald-400 font-extrabold"
                : "hover:text-slate-200"
            }`}
          >
            <CandlestickChart className="w-4 h-4" />
            <span>التقرير الفني المتقدم</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab("chart")}
            className={`py-1.5 px-1 flex items-center gap-1.5 cursor-pointer transition-colors ${
              activeTab === "chart"
                ? "border-b-2 border-emerald-500 text-emerald-400 font-extrabold"
                : "hover:text-slate-200"
            }`}
          >
            <LineChart className="w-4 h-4" />
            <span>الشارت التفاعلي (TradingView)</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab("chat")}
            className={`py-1.5 px-1 flex items-center gap-1.5 cursor-pointer transition-colors ${
              activeTab === "chat"
                ? "border-b-2 border-emerald-500 text-emerald-400 font-extrabold"
                : "hover:text-slate-200"
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            <span>حوار الخبير الفني</span>
          </button>
        </div>

        {/* Scrollable Viewport */}
        <div className="flex-1 overflow-y-auto p-3 md:p-5 space-y-4 text-slate-200 text-xs md:text-sm bg-[#060913]">
          {/* TAB 1: Advanced Report */}
          {activeTab === "report" && (
            <div className="space-y-4">
              {/* Top Highlights Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl">
                  <div className="text-[11px] text-slate-400 mb-1 flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>نمط الشمعة</span>
                  </div>
                  <div className="font-bold text-slate-100 text-xs md:text-sm truncate">
                    {stock.candlestickPattern}
                  </div>
                  <div className="text-[10px] text-emerald-400 mt-0.5">
                    الموثوقية: {stock.patternReliability}
                  </div>
                </div>

                <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl">
                  <div className="text-[11px] text-slate-400 mb-1 flex items-center gap-1">
                    <Target className="w-3.5 h-3.5 text-indigo-400" />
                    <span>نقطة الارتكاز (Pivot)</span>
                  </div>
                  <div className="font-mono font-black text-amber-300 text-sm md:text-base">
                    {formatNumber(stock.pivot)} ج.م
                  </div>
                  <div className="text-[10px] text-slate-500 mt-0.5">
                    R1: {formatNumber(stock.resistance1)} | S1: {formatNumber(stock.support1)}
                  </div>
                </div>

                <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl">
                  <div className="text-[11px] text-slate-400 mb-1 flex items-center gap-1">
                    <ArrowUpRight className="w-3.5 h-3.5 text-emerald-400" />
                    <span>الأهداف السعرية</span>
                  </div>
                  <div className="font-mono font-black text-emerald-400 text-sm md:text-base">
                    {formatNumber(stock.target1)} - {formatNumber(stock.target2)} ج.م
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">
                    عائد/مخاطرة: {stock.riskReward || "N/A"}
                  </div>
                </div>

                <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl">
                  <div className="text-[11px] text-slate-400 mb-1 flex items-center gap-1">
                    <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
                    <span>وقف الخسارة الصارم</span>
                  </div>
                  <div className="font-mono font-black text-rose-400 text-sm md:text-base">
                    {formatNumber(stock.stopLoss)} ج.م
                  </div>
                  <div className="text-[10px] text-slate-500 mt-0.5">
                    منطقة الدخول: {stock.entryZone || "N/A"}
                  </div>
                </div>
              </div>

              {/* Quantitative Technical Matrix */}
              <div className="bg-slate-900/80 border border-cyan-500/20 rounded-xl p-4">
                <h4 className="text-xs font-bold text-cyan-300 mb-3 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-cyan-400" />
                  <span>المؤشرات الكمية المحسوبة من السجل التاريخي</span>
                </h4>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-2 text-center font-mono text-[11px]">
                  <div className="bg-slate-950 p-2 rounded-lg border border-slate-800"><div className="text-slate-500">RSI14</div><div className="text-cyan-300 font-black">{formatNumber(stock.technical?.rsi14, 1)}</div></div>
                  <div className="bg-slate-950 p-2 rounded-lg border border-slate-800"><div className="text-slate-500">MACD Hist.</div><div className="text-cyan-300 font-black">{formatNumber(stock.technical?.macdHistogram, 3)}</div></div>
                  <div className="bg-slate-950 p-2 rounded-lg border border-slate-800"><div className="text-slate-500">Stoch %K</div><div className="text-cyan-300 font-black">{formatNumber(stock.technical?.stochasticK, 1)}</div></div>
                  <div className="bg-slate-950 p-2 rounded-lg border border-slate-800"><div className="text-slate-500">ATR14</div><div className="text-cyan-300 font-black">{formatNumber(stock.technical?.atr14)}</div></div>
                  <div className="bg-slate-950 p-2 rounded-lg border border-slate-800"><div className="text-slate-500">RelVol20</div><div className="text-cyan-300 font-black">{formatNumber(stock.technical?.relativeVolume20, 2)}</div></div>
                  <div className="bg-slate-950 p-2 rounded-lg border border-slate-800"><div className="text-slate-500">ADX14</div><div className="text-cyan-300 font-black">{formatNumber(stock.technical?.adx14, 1)}</div></div>
                  <div className="bg-slate-950 p-2 rounded-lg border border-slate-800"><div className="text-slate-500">MFI14</div><div className="text-cyan-300 font-black">{formatNumber(stock.technical?.mfi14, 1)}</div></div>
                  <div className="bg-slate-950 p-2 rounded-lg border border-slate-800"><div className="text-slate-500">VWAP</div><div className="text-cyan-300 font-black">{formatNumber(stock.technical?.vwap)}</div></div>
                  <div className="bg-slate-950 p-2 rounded-lg border border-slate-800"><div className="text-slate-500">CCI20</div><div className="text-cyan-300 font-black">{formatNumber(stock.technical?.cci20, 1)}</div></div>
                  <div className="bg-slate-950 p-2 rounded-lg border border-slate-800"><div className="text-slate-500">Volatility20</div><div className="text-cyan-300 font-black">{formatNumber(stock.technical?.volatility20Annualized, 2)}%</div></div>
                </div>
                <div className="mt-3 text-[10px] text-slate-500">السجل المستخدم: {formatInteger(stock.dataQuality.bars)} جلسة | أحدث جلسة: {stock.dataQuality.asOfDate || "غير متاح"} | النظام لا يملأ القيم المفقودة تخمينيًا.</div>
              </div>

              {/* Pivot & Support/Resistance Detailed Matrix */}
              <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4">
                <h4 className="text-xs font-bold text-slate-300 mb-3 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                  <span>مصفوفة المستويات المحورية ونسب فيبوناتشي اللحظية</span>
                </h4>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-2 text-center font-mono">
                  <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                    <div className="text-[10px] text-rose-400 font-bold">مقاومة 2 (R2)</div>
                    <div className="font-black text-xs md:text-sm text-slate-200 mt-0.5">
                      {formatNumber(stock.resistance2)}
                    </div>
                  </div>
                  <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                    <div className="text-[10px] text-amber-400 font-bold">مقاومة 1 (R1)</div>
                    <div className="font-black text-xs md:text-sm text-slate-200 mt-0.5">
                      {formatNumber(stock.resistance1)}
                    </div>
                  </div>
                  <div className="bg-emerald-950/40 p-2 rounded-lg border border-emerald-500/40">
                    <div className="text-[10px] text-emerald-400 font-bold">نقطة الارتكاز (P)</div>
                    <div className="font-black text-xs md:text-sm text-emerald-300 mt-0.5">
                      {formatNumber(stock.pivot)}
                    </div>
                  </div>
                  <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                    <div className="text-[10px] text-cyan-400 font-bold">دعم 1 (S1)</div>
                    <div className="font-black text-xs md:text-sm text-slate-200 mt-0.5">
                      {formatNumber(stock.support1)}
                    </div>
                  </div>
                  <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                    <div className="text-[10px] text-blue-400 font-bold">دعم 2 (S2)</div>
                    <div className="font-black text-xs md:text-sm text-slate-200 mt-0.5">
                      {formatNumber(stock.support2)}
                    </div>
                  </div>
                </div>
              </div>

              {/* Candlestick Behaviour Description */}
              <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4">
                <h4 className="text-xs font-bold text-amber-400 mb-2 flex items-center gap-2">
                  <Sparkles className="w-4 h-4" />
                  <span>دلالة وسلوك الشمعة اليابانية المكتشفة</span>
                </h4>
                <p className="text-xs md:text-sm leading-relaxed text-slate-300">
                  {stock.patternDescription}
                </p>
              </div>

              {/* AI Strategic Generated Report */}
              <div className="bg-slate-900/90 border border-emerald-500/30 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <h4 className="text-xs font-black text-emerald-400 flex items-center gap-2">
                    <Wand2 className="w-4 h-4 text-emerald-400" />
                    <span>تقرير الخبير الاستراتيجي المدعوم بالذكاء الاصطناعي (Gemini)</span>
                  </h4>
                  {isAiReportLoading && (
                    <span className="text-[10px] text-amber-400 flex items-center gap-1.5 animate-pulse">
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>جاري التحليل المعمق...</span>
                    </span>
                  )}
                </div>

                {isAiReportLoading ? (
                  <div className="py-8 flex flex-col items-center justify-center text-center space-y-2">
                    <Loader2 className="w-8 h-8 text-emerald-400 animate-spin" />
                    <p className="text-xs text-slate-400">
                      يقوم الخبير المالي بدراسة الشموع اليابانية ومستويات الدعم والمقاومة والسيولة...
                    </p>
                  </div>
                ) : aiReportError ? (
                  <div className="p-3 bg-rose-950/40 border border-rose-900/50 rounded-lg text-xs text-rose-300">
                    {aiReportError}
                  </div>
                ) : (
                  <div className="prose prose-invert max-w-none text-xs md:text-sm leading-relaxed whitespace-pre-line text-slate-200">
                    {aiReport || "جاهز لتوليد التقرير المعمق."}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: Interactive TradingView Chart */}
          {activeTab === "chart" && (
            <div className="space-y-3">
              {/* Radar Scanner Top Bar */}
              <div className="flex flex-col sm:flex-row items-center justify-between bg-slate-900/90 border border-slate-800 px-3 py-2.5 rounded-xl gap-2 shadow-md">
                <div className="flex items-center gap-2 text-indigo-400 font-bold text-xs md:text-sm">
                  <LineChart className="w-4 h-4 text-amber-400" />
                  <span>الشارت التفاعلي المباشر (TradingView Feed: {stock.tvSymbol})</span>
                </div>
                <button
                  type="button"
                  onClick={handleScanChart}
                  disabled={isScanning}
                  className="w-full sm:w-auto bg-gradient-to-r from-indigo-600 via-purple-600 to-emerald-600 hover:from-indigo-500 hover:to-emerald-500 text-white font-black px-4 py-2 rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95 border border-indigo-400/40 text-xs"
                >
                  {isScanning ? (
                    <Loader2 className="w-4 h-4 animate-spin text-white" />
                  ) : (
                    <Radar className="w-4 h-4 text-amber-300 animate-pulse" />
                  )}
                  <span>ماسح الشارت الذكي AI Scanner</span>
                </button>
              </div>

              {/* Chart Embedded Container */}
              <div className="w-full h-[520px] rounded-xl overflow-hidden border border-slate-800/80 bg-slate-950 relative">
                {stock.tvSymbol ? <iframe
                  src={tvWidgetUrl}
                  title={`TradingView Chart for ${stock.name}`}
                  className="w-full h-full border-0"
                  allowTransparency
                /> : <div className="h-full flex items-center justify-center text-slate-500 text-sm p-6 text-center">رمز TradingView غير معروف لهذا السهم؛ لم يتم اختراع رمز بديل.</div>}
              </div>

              {/* Scanner Result Card */}
              {scanResult && (
                <div className="bg-slate-900/95 border border-emerald-500/50 p-4 rounded-xl text-xs md:text-sm text-slate-200 shadow-2xl space-y-2">
                  <div className="font-bold text-emerald-400 flex items-center gap-2 border-b border-slate-800 pb-1.5">
                    <Radar className="w-4 h-4 text-amber-400" />
                    <span>نتيجة ماسح الشارت اللحظي AI Radar:</span>
                  </div>
                  <div className="whitespace-pre-line leading-relaxed text-slate-300">
                    {scanResult}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: Interactive Expert Chat */}
          {activeTab === "chat" && (
            <div className="bg-slate-900/80 p-3 md:p-4 rounded-xl border border-slate-800 space-y-4 flex flex-col h-[520px]">
              {/* Quick Prompt Chips */}
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                <span className="text-amber-400 text-xs font-bold flex items-center gap-1.5">
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>حوار الخبير الفني المباشر:</span>
                </span>
                <div className="hidden sm:flex items-center gap-1.5 text-[10px]">
                  <button
                    type="button"
                    onClick={() =>
                      handleSendMessage("ما هو نمط الشمعة الظاهر وما هي معانيه الفنية؟")
                    }
                    className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-2 py-1 rounded border border-slate-700 cursor-pointer"
                  >
                    نمط الشمعة؟
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      handleSendMessage("ما هي مستويات المحور والدعم والمقاومة بدقة؟")
                    }
                    className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-2 py-1 rounded border border-slate-700 cursor-pointer"
                  >
                    الدعم والمقاومة؟
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      handleSendMessage("ما هي استراتيجية الدخول والمخاطرة الموصى بها؟")
                    }
                    className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-2 py-1 rounded border border-slate-700 cursor-pointer"
                  >
                    المخاطرة والدخول؟
                  </button>
                </div>
              </div>

              {/* Chat Message List */}
              <div className="flex-1 overflow-y-auto space-y-3 px-1 scrollbar-thin">
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${
                      msg.role === "user" ? "items-start" : "items-end"
                    }`}
                  >
                    <div
                      className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-xs md:text-sm leading-relaxed whitespace-pre-line shadow-md ${
                        msg.role === "user"
                          ? "bg-slate-800 text-slate-100 border border-slate-700 text-right"
                          : "bg-emerald-950/80 text-emerald-100 border border-emerald-700/50 text-right"
                      }`}
                    >
                      {msg.content}
                    </div>
                    <span className="text-[10px] text-slate-500 mt-1 px-1">
                      {msg.timestamp}
                    </span>
                  </div>
                ))}
                {isChatLoading && (
                  <div className="flex items-center gap-2 text-xs text-slate-400 p-2">
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-400" />
                    <span>الخبير يفكر في الإجابة...</span>
                  </div>
                )}
                <div ref={chatBottomRef} />
              </div>

              {/* Input Bar */}
              <div className="flex gap-2 pt-2 border-t border-slate-800">
                <input
                  type="text"
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") handleSendMessage();
                  }}
                  placeholder="اسأل الخبير الاستراتيجي عن الشموع ومستويات الدخول والهدف..."
                  className="flex-1 bg-slate-950/90 border border-slate-700/80 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
                />
                <button
                  type="button"
                  onClick={() => handleSendMessage()}
                  disabled={isChatLoading || !inputMessage.trim()}
                  className="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-slate-950 font-black px-4 py-2 rounded-xl transition-all text-xs flex items-center justify-center gap-2 shadow-lg cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>إرسال</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
