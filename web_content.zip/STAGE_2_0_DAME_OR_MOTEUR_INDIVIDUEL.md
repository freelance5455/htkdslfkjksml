# Socle 2.0 — Moteur individuel de la Dame d’Or

## Livré dans cette étape
- Création du registre persistant `state.dameOr` avec migration rétrocompatible des sauvegardes Socle 1.9.
- Enregistrement idempotent après homologation centrale des rencontres entre clubs : championnat, Coupes FGD et Intergalactique des Clubs.
- Attribution de chaque rencontre à un damiste titulaire de chaque club. Le manager peut choisir le titulaire de son club sur les prochaines rencontres depuis le panneau Dame d’Or. Pour les matchs gérés par l’IA, le choix de joueur est déterministe et sauvegardé.
- Statistiques réellement disponibles : matchs joués, victoires, nuls, défaites, points (3/1/0), buts pour/contre et différence de buts.
- Classement mixte sans distinction de genre, avec départage : points, victoires, différence de buts, buts marqués, matchs joués, puis ordre alphabétique.
- Panneau de carrière : choix du titulaire, classement provisoire et palmarès.
- Clôture de saison et archivage du vainqueur lorsque la date officielle de fin FGD est atteinte et que toutes les rencontres de la saison sont terminées.
- Protection contre les doublons via les identifiants de rencontres déjà enregistrées.

## Limites assumées / à confirmer
- Les données techniques détaillées (prises, dames promues, erreurs, précision, etc.) ne sont pas encore mesurées par le moteur de partie ; elles ne sont donc pas utilisées dans le classement.
- L’autorité organisatrice de la Dame d’Or reste « à confirmer » : aucune institution n’est attribuée sans validation.
- La règle de classement et ses critères de départage sont une première base fonctionnelle à valider par le manager.
- La sélection automatique de l’IA est stable et déterministe, mais ne prétend pas représenter un choix tactique humain.

## Tests
- Tests spécifiques : sélection de titulaire, homologation, classement, idempotence, clôture et palmarès.
- Suite complète exécutée : 130 tests réussis, 0 échec. Tous les fichiers JavaScript passent la vérification syntaxique.
- Le niveau et la forme du damiste titulaire retenu sont transmis au moteur de simulation des matchs de clubs, y compris l’Intergalactique des Clubs ; la sélection individuelle n’est donc pas seulement décorative.


## Socle 2.1 — statistiques techniques individuelles

Les parties jouées manuellement et les simulations automatiques transmettent désormais, lorsqu'elles sont disponibles, les indicateurs techniques réels du moteur de dames : coups joués, prises, promotions et déplacements de dames. Ces indicateurs sont enregistrés sur la fiche du damiste titulaire après homologation. Ils servent de critères secondaires de départage après les points, victoires, différence de buts et buts marqués ; ils ne remplacent pas les résultats sportifs. Les statistiques détaillées ne sont pas inventées pour les anciennes sauvegardes ou les rencontres dont le moteur n'a pas fourni ces données.
