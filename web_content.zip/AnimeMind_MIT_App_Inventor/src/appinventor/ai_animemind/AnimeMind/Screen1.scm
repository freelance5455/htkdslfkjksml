#|
$JSON
{"authURL":["ai2.appinventor.mit.edu"],"YaVersion":"223","Source":"Form"}
|#
{"YaVersion":"223","Source":"Form","Properties":{"$Name":"Screen1","$Type":"Form","$Version":"31","AppName":"AnimeMind","Title":"AnimeMind","Uuid":"0","Sizing":"Responsive","Scrollable":"True","ShowStatusBar":"True","ShowNavigationBar":"True","BackgroundColor":"&HFF0A1024","AlignHorizontal":"3","AlignVertical":"2","Children":[{"$Name":"WebViewer1","$Type":"WebViewer","$Version":"8","Uuid":"1001","Width":-2,"Height":-2,"HomeUrl":"file:///android_asset/index.html","FollowLinks":true,"UsesLocation":false,"PromptforPermission":false,"IgnoreSslErrors":false,"WebViewString":""}]}}