# CPLS V2 — Stage 1126

Mobile Futures chart readability and interaction refinement.

- Responsive chart height for small phone screens.
- Larger, clearer timeframe labels and chart price marker on narrow screens.
- Touch-action/user-selection handling prevents accidental page scrolling while chart gestures are active.
- Selected candle is highlighted with a vertical guide and OHLC tooltip.
- Pointer tap selection works alongside pinch zoom and pan.
- Existing 1125 zoom/pan, persistent samples, REST feed and WebSocket diagnostics remain intact.

Source ZIP only; APK build not performed in this environment.
