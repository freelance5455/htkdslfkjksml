package com.dolina.strannostey

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings

class MainActivity : Activity() {
    private lateinit var game: WebView

    @Suppress("DEPRECATION")
    private fun immersive() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        immersive()
        game = WebView(this)
        game.setBackgroundColor(android.graphics.Color.rgb(18, 13, 29))
        game.webViewClient = WebViewClient()
        game.webChromeClient = WebChromeClient()
        game.settings.javaScriptEnabled = true
        game.settings.domStorageEnabled = true
        game.settings.databaseEnabled = true
        game.settings.allowFileAccess = true
        game.settings.cacheMode = WebSettings.LOAD_DEFAULT
        game.settings.mediaPlaybackRequiresUserGesture = false
        setContentView(game)
        if (savedInstanceState == null) game.loadUrl("file:///android_asset/index.html")
        else game.restoreState(savedInstanceState)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        game.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::game.isInitialized && game.canGoBack()) game.goBack() else super.onBackPressed()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) immersive()
    }
}
