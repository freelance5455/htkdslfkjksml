import './style.css';
import {create,all} from 'mathjs';
import nerdamer from 'nerdamer/all';
import 'nerdamer/Calculus';
import 'nerdamer/Solve';
const math=create(all,{});
const $=id=>document.getElementById(id);
let lastText='',recognized='';
function clean(s){return s.replace(/[×]/g,'*').replace(/[÷]/g,'/').replace(/[−–]/g,'-').replace(/π/g,'pi').trim()}
function fmt(v){if(typeof v==='number')return Number.isFinite(v)?(Math.abs(v-Math.round(v))<1e-10?String(Math.round(v)):Number(v.toPrecision(10)).toString()):String(v);return String(v)}
function equationSolve(q,v){let parts=q.split('=');if(parts.length!==2)throw Error('Write one equation using =, e.g. 2*x+5=17');let expr=`(${parts[0]})-(${parts[1]})`;let ans=nerdamer.solve(expr,v).toString();if(!ans||ans==='[]')return 'No solution found in the supported symbolic domain';return ans}
function runSolve(q,op,v){q=clean(q);if(!q)throw Error('Please enter a maths question.');
if(op==='auto'){if(q.includes('='))op='solve';else if(/^factor\(/i.test(q))op='factor';else if(/^expand\(/i.test(q))op='expand';else if(/^simplify\(/i.test(q))op='simplify';else op='evaluate'}
let out,steps=[];
if(op==='solve'){out=equationSolve(q,v);steps=['Move all terms to one side of the equation.','Use the symbolic equation solver to find values of '+v+'.','Check each candidate by substituting it into the original equation.'];}
else if(['simplify','factor','expand','partial'].includes(op)){let inner=q.replace(/^(simplify|factor|expand|partfrac)\(/i,'').replace(/\)$/,'');let fn=op==='partial'?'partfrac':op;out=nerdamer[fn](inner).toString();steps=[`Apply symbolic ${op} rules to the expression.`,`Result: ${out}`,'Where variables are present, check any excluded values from the original denominator.'];}
else{let val=math.evaluate(q);out=fmt(val);steps=['Interpret the expression using standard mathematical precedence.','Evaluate powers, roots, functions and arithmetic.','Numerical result: '+out];}
return {out,steps,note:'Computed with a local mathematics engine. A correct result still depends on the question being transcribed and interpreted correctly.'};}
function showResult(r){$('answer').hidden=false;$('answerText').textContent=r.out;$('steps').innerHTML='';r.steps.forEach(s=>{let li=document.createElement('li');li.textContent=s;$('steps').append(li)});$('note').textContent=r.note;lastText='Answer: '+r.out+'. '+r.steps.join('. ');}
$('solve').onclick=()=>{try{let q=$('question').value.trim()||recognized;let r=runSolve(q,$('operation').value,$('variable').value||'x');showResult(r)}catch(e){$('answer').hidden=false;$('answerText').textContent='Could not solve';$('steps').innerHTML='';$('note').textContent=e.message}};
$('clear').onclick=()=>{$('question').value='';$('photo').value='';recognized='';$('answer').hidden=true;$('preview').hidden=true;$('ocrStatus').textContent='Select a picture to read its question.'};
$('textMode').onclick=()=>mode('text');$('imageMode').onclick=()=>mode('image');
function mode(m){$('textBox').hidden=m!=='text';$('imageBox').hidden=m!=='image';$('textMode').classList.toggle('active',m==='text');$('imageMode').classList.toggle('active',m==='image')}
$('photo').addEventListener('change',async e=>{let file=e.target.files?.[0];if(!file)return;$('preview').src=URL.createObjectURL(file);$('preview').hidden=false;$('ocrStatus').textContent='Reading image… please wait.';try{const {createWorker}=await import('tesseract.js');const worker=await createWorker('eng');const result=await worker.recognize(file);recognized=result.data.text.trim();await worker.terminate();if(recognized){$('question').value=recognized;$('ocrStatus').textContent='Text detected. Check the symbols and edit the question if needed, then press Solve.';mode('text')}else{$('ocrStatus').textContent='No readable text found. Try a sharper image or type the question.'}}catch(err){$('ocrStatus').textContent='Image reader could not start. Check internet, or type the question manually.'}});
$('copy').onclick=async()=>{try{await navigator.clipboard.writeText(lastText);$('copy').textContent='Copied ✓'}catch{$('copy').textContent='Copy unavailable'}};
$('speak').onclick=()=>{if(!('speechSynthesis'in window)){ $('note').textContent='Voice reading is not supported by this browser.';return}speechSynthesis.cancel();let text='The answer is. '+$('answerText').textContent+'. Here are the steps. '+[...$('steps').querySelectorAll('li')].map(x=>x.textContent).join('. ');let u=new SpeechSynthesisUtterance(text);u.rate=0.92;u.pitch=1.0;u.lang='en-IN';let voices=speechSynthesis.getVoices();u.voice=voices.find(v=>v.lang==='en-IN')||voices.find(v=>v.lang.startsWith('en'))||null;speechSynthesis.speak(u)};
$('stopSpeak').onclick=()=>{if('speechSynthesis'in window)speechSynthesis.cancel()};
function hist(){let h=JSON.parse(localStorage.getItem('nmhist')||'[]');$('history').innerHTML=h.length?h.map((x,i)=>`<div style="padding:8px;border-bottom:1px solid #2a3d57;cursor:pointer" data-h="${i}">${escapeHtml(x.q)} → <b>${escapeHtml(x.a)}</b></div>`).join(''):'No saved questions yet.';$('history').querySelectorAll('[data-h]').forEach(el=>el.onclick=()=>{$('question').value=h[+el.dataset.h].q;mode('text')})}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
$('save').onclick=()=>{let h=JSON.parse(localStorage.getItem('nmhist')||'[]');h.unshift({q:$('question').value||recognized,a:$('answerText').textContent});localStorage.setItem('nmhist',JSON.stringify(h.slice(0,30)));hist()};
$('clearHistory')?.addEventListener('click',()=>{localStorage.removeItem('nmhist');hist()});hist();
document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>{document.querySelectorAll('.workspace-nav [data-tab]').forEach(x=>x.classList.toggle('active',x===b));document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id===b.dataset.tab))});
document.querySelectorAll('[data-q]').forEach(b=>b.onclick=()=>{$('question').value=b.dataset.q;$('operation').value=b.dataset.op;document.querySelector('[data-tab="solver"]').click();});
$('runCal').onclick=()=>{try{let x=$('calExpr').value,op=$('calOp').value,res=op==='diff'?nerdamer.diff(x,'x').toString():op==='integrate'?nerdamer.integrate(x,'x').toString()+' + C':nerdamer.limit(x,'x',0).toString();$('calOut').textContent=res}catch(e){$('calOut').textContent='Could not calculate: '+e.message}};
$('runMat').onclick=()=>{try{let m=math.matrix(math.evaluate($('mat').value));let op=$('matOp').value;let r=op==='det'?math.det(m):op==='inv'?math.inv(m):op==='transpose'?math.transpose(m):op==='rank'?math.rank(m):math.trace(m);$('matOut').textContent=typeof r==='number'?fmt(r):r.toString()}catch(e){$('matOut').textContent='Matrix error: '+e.message}};
for(let i=1;i<=100;i++){let o=document.createElement('option');o.value=i;o.textContent=i;$('tableN').append(o);let tr=document.createElement('tr');tr.innerHTML=`<td>${i}</td><td>${i*i}</td><td>${i}</td><td>${i*i*i}</td><td>${i}</td>`;$('powers').querySelector('tbody').append(tr)}
function table(){let n=+$('tableN').value;$('tableOut').innerHTML='<table>'+Array.from({length:10},(_,i)=>`<tr><td>${n} × ${i+1}</td><td>${n*(i+1)}</td></tr>`).join('')+'</table>'}
$('showTable').onclick=table;table();
const keys=['7','8','9','÷','4','5','6','×','1','2','3','−','0','.','(',')','sqrt(','^','pi','⌫','AC','='];keys.forEach(k=>{let b=document.createElement('button');b.textContent=k;b.onclick=()=>{let d=$('display');if(k==='AC')d.value='';else if(k==='⌫')d.value=d.value.slice(0,-1);else if(k==='='){try{d.value=fmt(math.evaluate(clean(d.value)))}catch{d.value='Error'}}else d.value+=({'×':'*','÷':'/','−':'-'}[k]||k)};$('keys').append(b)});
$('theme').onclick=()=>document.body.classList.toggle('light');
