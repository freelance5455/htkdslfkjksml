# N Maths Solver Pro — Premium UI Refresh (v2.2)

## What's new
- Refreshed the interface with a premium dark gradient theme, responsive mobile layout, clearer navigation, quick examples, and dedicated tool panels.
- Added a light/dark theme toggle and improved navigation state handling.

## What's fixed/added
- Image mode now has a real file picker with camera capture on supported phones.
- OCR is loaded on demand using Tesseract.js; extracted text is copied into the editable question field. Check OCR symbols before solving.
- Added spoken answer using the browser/device speech engine (`speechSynthesis`), with Read answer and Stop voice buttons.
- Added symbolic algebra operations (simplify, factor, expand, equation solving), calculus differentiation/integration/limits, matrix tools, table 1–100, squares/cubes and roots, and scientific calculator.

## Run web
1. Install Node.js LTS.
2. In this folder run `npm install`
3. Run `npm run dev` and open the local URL.
4. For a deployable site run `npm run build`; upload the `dist` folder to an HTTPS host.

## Android APK
1. `npm install`
2. `npm run build`
3. `npx cap add android` (first time only)
4. `npx cap sync android`
5. `npx cap open android`
6. In Android Studio: Build > Build APK(s).

This ZIP is source code, not a precompiled APK. Building Android requires Android Studio and the Android SDK.

## Accuracy and limitations
The local symbolic/numeric engines cover many common school and university operations, but cannot guarantee every possible problem or proof. OCR can confuse handwriting, exponents, minus signs and fractions; always review recognised text. Spoken answers use the voice installed on the device and may not be Alexa's exact voice. Browser speech support and language availability vary. The voice feature speaks computed output; it does not itself improve mathematical correctness.
