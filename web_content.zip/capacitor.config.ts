import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.nexacircle.app',
  appName: 'NexaCircle',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;
