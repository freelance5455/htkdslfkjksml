import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.codeverse.studio',
  appName: 'CodeVerse',
  webDir: 'dist',
  bundledWebRuntime: false,
};

export default config;
