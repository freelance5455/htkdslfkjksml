import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.abdulla.aiassistant',
  appName: 'Abdulla AI Assistant',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;
