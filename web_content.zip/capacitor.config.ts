import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.allji.app',
  appName: 'AllJi - Sab Kuch, Ek Hi Jagah',
  webDir: 'dist',
  bundledWebRuntime: false
};

export default config;
