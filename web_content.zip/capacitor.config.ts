import type { CapacitorConfig } from '@capacitor/cli';

const serverUrl = process.env.CAPACITOR_SERVER_URL?.trim();

const config: CapacitorConfig = {
  appId: 'in.socialboost.app',
  appName: 'SOCIAL BOOST',
  webDir: 'dist',
  backgroundColor: '#08071a',
  ...(serverUrl
    ? {
        server: {
          url: serverUrl,
          cleartext: false,
        },
      }
    : {}),
  android: {
    allowMixedContent: false,
    backgroundColor: '#08071a',
  },
};

export default config;
