/**
 * Capacitor config used by scripts/build-android-apk.sh to wrap Keep Tracked
 * in a real Android APK without opening Android Studio.
 *
 * CAP_SERVER_URL must point at a running Keep Tracked server
 * (e.g. https://your-preview-url). For local emulator testing use
 * http://10.0.2.2:3000 which maps to the host machine's localhost.
 */
const serverUrl = process.env.CAP_SERVER_URL || "http://10.0.2.2:3000";

const config = {
  appId: "app.keeptracked.mobile",
  appName: "Keep Tracked",
  webDir: "public",
  backgroundColor: "#080b0a",
  server: {
    url: serverUrl,
    cleartext: true,
    androidScheme: "https",
  },
  android: {
    allowMixedContent: true,
    backgroundColor: "#080b0a",
  },
};

export default config;
