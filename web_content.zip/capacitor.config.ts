import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.eli.workspace',
  appName: 'ELI Workspace',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;
