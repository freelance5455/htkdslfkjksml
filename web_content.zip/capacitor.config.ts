import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.crypto.daytrading",
  appName: "Crypto Day Trading",
  webDir: "dist",
  server: {
    androidScheme: "https",
    cleartext: true,
    allowNavigation: [
      "api.binance.com",
      "stream.binance.com",
      "ws.coincap.io",
      "api.coingecko.com",
      "integrate.api.nvidia.com",
      "ai.api.nvidia.com",
    ],
  },
  android: {
    allowMixedContent: true,
    captureInput: true,
    webContentsDebuggingEnabled: true,
  },
};

export default config;
