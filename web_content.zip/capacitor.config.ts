const config = {
  appId: 'mw.tevetpower.app',
  appName: 'TEVET POWER APP',
  webDir: 'dist',
  bundledWebRuntime: false,
  android: {
    allowMixedContent: false,
    captureInput: true,
    webContentsDebuggingEnabled: false,
  },
  server: {
    androidScheme: 'https',
    // Keep API calls and WebSockets pointed to the deployed backend when running inside Capacitor Android:
    // Set CAPACITOR_SERVER_URL in CI/local build if bundling a remote-backed APK, or host static dist + API.
    url: process.env.CAPACITOR_SERVER_URL || undefined,
    cleartext: false,
  },
};

export default config;
