import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.hebrew.calendar',
  appName: 'Hebrew Calendar & Zmanim',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  }
};

export default config;
