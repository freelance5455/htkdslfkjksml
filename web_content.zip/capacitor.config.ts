import type { CapacitorConfig } from "@capacitor/cli";

/**
 * Android wrapper for "لأنه الله".
 *
 * The app loads the live website (which hosts the Next.js server features such as
 * "نموذج أ" and the Quran API) inside a native Android WebView.
 *
 * Set CAP_SERVER_URL to the public https address where the site is deployed, e.g.
 *   CAP_SERVER_URL=https://lianahu.example.sy npx cap sync android
 */
const serverUrl = process.env.CAP_SERVER_URL ?? "https://li-annahu-allah.vercel.app";

const config: CapacitorConfig = {
  appId: "sy.lianahu.app",
  appName: "لأنه الله",
  // Used only if the server is unreachable; the app itself loads serverUrl.
  webDir: "public",
  server: {
    url: serverUrl,
    cleartext: false,
    androidScheme: "https",
  },
  android: {
    allowMixedContent: false,
    backgroundColor: "#0F1828",
  },
};

export default config;
