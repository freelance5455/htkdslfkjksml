import type { CapacitorConfig } from "@capacitor/cli";

/**
 * MICHILICIAS: GATITOS MÁGICOS — configuración de la app Android.
 * La carpeta `dist` (salida de `npm run build`) se empaqueta dentro
 * del APK. El juego funciona 100% sin conexión una vez instalado.
 */
const config: CapacitorConfig = {
  appId: "com.michilicias.gatitosmagicos",
  appName: "MICHILICIAS: GATITOS MÁGICOS",
  webDir: "dist",
  backgroundColor: "#0d0b14",
  android: {
    backgroundColor: "#0d0b14",
    allowMixedContent: false,
  },
  server: {
    androidScheme: "https",
  },
};

export default config;
