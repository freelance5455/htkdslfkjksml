import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.royalshowdown.app',
  appName: 'Royal Number Showdown',
  webDir: 'www',
  server: {
    androidScheme: 'http'
  }
};

export default config;
