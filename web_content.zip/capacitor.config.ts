import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.habivio.app',
  appName: 'Habivio',
  webDir: 'dist',
  android: {
    allowMixedContent: true,
    backgroundColor: '#0F172A',
  },
  plugins: {
    HabivioAlarm: {},
  },
};

export default config;
