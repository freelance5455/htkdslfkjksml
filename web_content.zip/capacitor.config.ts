import type { CapacitorConfig } from "@capacitor/cli";

/**
 * Android app configuration.
 *
 * The app is a native shell that loads the live ShifaCare website, so every content change
 * made in the admin dashboard appears in the app immediately (no new APK needed).
 *
 * Set CAPACITOR_SERVER_URL to your public HTTPS domain before generating the final APK, e.g.
 *   CAPACITOR_SERVER_URL=https://www.shifacare.ma npx cap sync android
 */
const serverUrl = process.env.CAPACITOR_SERVER_URL || "https://3000-i6dtgizv7vm05jbssibut.e2b.app";

const config: CapacitorConfig = {
  appId: "ma.shifacare.app",
  appName: "ShifaCare",
  webDir: "www",
  server: {
    url: serverUrl,
    cleartext: serverUrl.startsWith("http://"),
    androidScheme: "https",
  },
  android: {
    backgroundColor: "#ffffff",
    allowMixedContent: false,
    captureInput: true,
    webContentsDebuggingEnabled: false,
  },
};

export default config;
