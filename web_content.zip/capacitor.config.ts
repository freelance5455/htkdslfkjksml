import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "club.ridgeline.game",
  appName: "Ridgeline",
  webDir: "dist",
  backgroundColor: "#080d0a",
  android: {
    backgroundColor: "#080d0a",
    allowMixedContent: false,
    webContentsDebuggingEnabled: false,
    captureInput: true,
    loggingBehavior: "none",
    adjustMarginsForEdgeToEdge: "auto",
  },
  server: {
    androidScheme: "https",
  },
};

export default config;
