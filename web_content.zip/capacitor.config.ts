import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.aivideo.creator',
  appName: 'AI Video Creator',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
    cleartext: true,
    allowNavigation: [
      'https://ais-dev-tsr7sr2nz7v5wafqe5ryub-778620181160.asia-northeast1.run.app',
      'https://ais-pre-tsr7sr2nz7v5wafqe5ryub-778620181160.asia-northeast1.run.app',
      '*.run.app',
      '*.googleapis.com',
    ],
  },
  android: {
    allowMixedContent: true,
    captureInput: true,
    webContentsDebuggingEnabled: true,
  },
};

export default config;
