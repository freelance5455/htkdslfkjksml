import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.arhan.magicalclass',
  appName: "Arhan's Magical Class",
  webDir: 'dist',
  android: {
    backgroundColor: '#fff7ed',
  },
};

export default config;
