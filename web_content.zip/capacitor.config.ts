import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.kisufire.gamebooster",
  appName: "Kisu-Game-Booster",
  webDir: "dist",
  android: { backgroundColor: "#0b0d12" },
};
export default config;
