import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.cryptobot.app",
  appName: "Crypto App",
  webDir: "dist",
  backgroundColor: "#0f172a",
  android: {
    allowMixedContent: false,
    backgroundColor: "#0f172a",
  },
  server: {
    // androidScheme https → secure origin inside the WebView, enabling
    // localStorage, Service Worker (sw.js), Notification API and wss:// feeds.
    androidScheme: "https",
  },
};

export default config;
