import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.voiceorb.assistant",
  appName: "Voice Orb",
  webDir: "dist",
  server: {
    androidScheme: "https"
  }
};

export default config;