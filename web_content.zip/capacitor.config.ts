import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.mazohub.pos',
  appName: 'MAZO HUB POS',
  webDir: 'public',
  server: {
    url: 'https://mazo-hub-mazom5242-5664s-projects.vercel.app/admin/',
    cleartext: false
  },
  android: {
    backgroundColor: '#08070b'
  }
};

export default config;
