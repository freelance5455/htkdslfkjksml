import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.mibiblioteca.app',
  appName: 'Mi Biblioteca',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
  },
};

export default config;
