import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.facelook.app',
  appName: 'FaceLook',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  }
};

export default config;
