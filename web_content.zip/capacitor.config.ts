import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.iphonelauncher.app',
  appName: 'iPhone Launcher Pro',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
    cleartext: true
  },
  plugins: {
    StatusBar: {
      style: 'DARK',
      backgroundColor: '#000000',
      overlaysWebView: false
    },
    SplashScreen: {
      launchShowDuration: 0,
      backgroundColor: '#000000',
      showSpinner: false
    },
    App: {
      allowMixedContent: true
    },
    Preferences: {
      group: 'launcher_prefs'
    }
  },
  android: {
    buildOptions: {
      keystorePath: 'launcher.keystore',
      keystoreAlias: 'launcher'
    }
  }
};

export default config;
