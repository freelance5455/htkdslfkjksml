package com.hasanjassim.followup;
import android.content.Context;
public class PasswordManager {
    private static final String PREF="followup_security", KEY="password";
    public static String get(Context c){ return c.getSharedPreferences(PREF,0).getString(KEY,"0000"); }
    public static void set(Context c,String p){ c.getSharedPreferences(PREF,0).edit().putString(KEY,p).apply(); }
}
