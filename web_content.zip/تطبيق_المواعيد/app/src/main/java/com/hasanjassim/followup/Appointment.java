package com.hasanjassim.followup;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class Appointment {
    public long id;
    public String title="", date="", time="", notes="";
    public String status="لم يتم";
    public String reason="";
    public List<String> reminders = new ArrayList<>();

    public JSONObject toJson() {
        JSONObject o=new JSONObject();
        try {
            o.put("id",id); o.put("title",title); o.put("date",date); o.put("time",time);
            o.put("notes",notes); o.put("status",status); o.put("reason",reason);
            JSONArray a=new JSONArray(); for(String r:reminders)a.put(r); o.put("reminders",a);
        } catch(Exception ignored){}
        return o;
    }
    public static Appointment fromJson(JSONObject o) {
        Appointment a=new Appointment();
        try {
            a.id=o.optLong("id"); a.title=o.optString("title"); a.date=o.optString("date");
            a.time=o.optString("time"); a.notes=o.optString("notes");
            a.status=o.optString("status","لم يتم"); a.reason=o.optString("reason");
            JSONArray ar=o.optJSONArray("reminders"); if(ar!=null) for(int i=0;i<ar.length();i++) a.reminders.add(ar.optString(i));
        } catch(Exception ignored){}
        return a;
    }
}
