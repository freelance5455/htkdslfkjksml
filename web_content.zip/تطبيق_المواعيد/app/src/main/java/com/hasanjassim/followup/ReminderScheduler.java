package com.hasanjassim.followup;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ReminderScheduler {
    public static void schedule(Context c, Appointment a, String reminder){
        try{
            String[] p=reminder.split("\\|");
            if(p.length<2)return;
            String dt=a.date+" "+p[0];
            Date d=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).parse(dt);
            if(d==null || d.getTime()<=System.currentTimeMillis())return;
            int code=(int)((a.id*31 + reminder.hashCode()) & 0x7fffffff);
            Intent i=new Intent(c,ReminderReceiver.class);
            i.putExtra("title",a.title); i.putExtra("date",a.date); i.putExtra("time",p[0]);
            i.putExtra("id",a.id);
            PendingIntent pi=PendingIntent.getBroadcast(c,code,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
            if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,d.getTime(),pi);
            } else {
                if(Build.VERSION.SDK_INT>=23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,d.getTime(),pi);
                else am.setExact(AlarmManager.RTC_WAKEUP,d.getTime(),pi);
            }
        }catch(Exception ignored){}
    }
    public static void scheduleAll(Context c){
        for(Appointment a:Store.load(c)) for(String r:a.reminders) schedule(c,a,r);
    }
}
