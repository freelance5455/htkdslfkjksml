package com.hasanjassim.followup;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.*;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import androidx.core.app.NotificationCompat;

public class ReminderReceiver extends BroadcastReceiver {
    public void onReceive(Context c, Intent in){
        String title=in.getStringExtra("title");
        String time=in.getStringExtra("time");
        String channel="appointments";
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            Uri sound=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            NotificationChannel ch=new NotificationChannel(channel,"تنبيهات المواعيد",NotificationManager.IMPORTANCE_HIGH);
            ch.setSound(sound,null); nm.createNotificationChannel(ch);
        }
        Intent open=new Intent(c,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(c,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder b=new NotificationCompat.Builder(c,channel)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("تنبيه موعد")
            .setContentText((title==null?"موعد":title)+" — "+(time==null?"":time))
            .setPriority(NotificationCompat.PRIORITY_MAX).setAutoCancel(true)
            .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
            .setContentIntent(pi);
        nm.notify((int)(System.currentTimeMillis()%100000),b.build());
    }
}
