package com.hasanjassim.followup;

import android.content.Context;
import org.json.JSONArray;
import java.util.ArrayList;
import java.util.List;

public class Store {
    private static final String PREF="followup_store", KEY="appointments";
    public static List<Appointment> load(Context c){
        List<Appointment> list=new ArrayList<>();
        try{
            JSONArray a=new JSONArray(c.getSharedPreferences(PREF,0).getString(KEY,"[]"));
            for(int i=0;i<a.length();i++) list.add(Appointment.fromJson(a.getJSONObject(i)));
        }catch(Exception ignored){}
        return list;
    }
    public static void save(Context c,List<Appointment> list){
        JSONArray a=new JSONArray(); for(Appointment x:list)a.put(x.toJson());
        c.getSharedPreferences(PREF,0).edit().putString(KEY,a.toString()).apply();
    }
    public static void add(Context c,Appointment ap){
        List<Appointment> l=load(c); l.add(ap); save(c,l);
    }
    public static void delete(Context c,long id){
        List<Appointment> l=load(c); l.removeIf(x->x.id==id); save(c,l);
    }
}
