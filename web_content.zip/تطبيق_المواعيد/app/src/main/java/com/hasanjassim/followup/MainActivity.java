package com.hasanjassim.followup;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.provider.Settings;
import android.net.Uri;

public class MainActivity extends Activity {
    LinearLayout root, listBox;
    ArrayList<Appointment> data=new ArrayList<>();
    int blue=Color.rgb(21,101,192);

    public void onCreate(Bundle b){
        super.onCreate(b);
        showLogin();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},55);
        data=new ArrayList<>(Store.load(this));
        buildHome();
    }
    TextView tv(String s,int sp){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setPadding(18,14,18,14); return t; }
    Button btn(String s){ Button b=new Button(this); b.setText(s); b.setAllCaps(false); return b; }

    void showLogin(){
        final EditText pass=field("كلمة السر");
        pass.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        new AlertDialog.Builder(this).setTitle("تطبيق المتابعة").setMessage("أدخل كلمة السر للمتابعة")
        .setView(pass).setCancelable(false).setPositiveButton("دخول",(d,w)->{
            if(pass.getText().toString().equals(PasswordManager.get(this))) buildHome();
            else { Toast.makeText(this,"كلمة السر غير صحيحة",Toast.LENGTH_SHORT).show(); showLogin(); }
        }).show();
    }

    void settings(){
        LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);
        Button cp=btn("تغيير كلمة السر"); Button info=btn("حول التطبيق");x.addView(cp);x.addView(info);
        cp.setOnClickListener(v->{
            LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);
            EditText old=field("كلمة السر الحالية"); EditText np=field("كلمة السر الجديدة"); EditText cf=field("تأكيد كلمة السر");
            for(EditText e:new EditText[]{old,np,cf}) e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
            b.addView(old);b.addView(np);b.addView(cf);
            new AlertDialog.Builder(this).setTitle("تغيير كلمة السر").setView(b).setPositiveButton("حفظ",(d,w)->{
                if(!old.getText().toString().equals(PasswordManager.get(this))) Toast.makeText(this,"كلمة السر الحالية غير صحيحة",Toast.LENGTH_LONG).show();
                else if(np.length()<4 || !np.getText().toString().equals(cf.getText().toString())) Toast.makeText(this,"كلمة السر الجديدة غير متطابقة",Toast.LENGTH_LONG).show();
                else {PasswordManager.set(this,np.getText().toString());Toast.makeText(this,"تم تغيير كلمة السر",Toast.LENGTH_SHORT).show();}
            }).setNegativeButton("إلغاء",null).show();
        });
        info.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حول التطبيق").setMessage("تطبيق المتابعة\\nكلمة السر الافتراضية: 0000\\nتم إعداد التطبيق بواسطة المهندس حسن جاسم").setPositiveButton("حسنًا",null).show());
        new AlertDialog.Builder(this).setTitle("الإعدادات").setView(x).setNegativeButton("إغلاق",null).show();
    }

    void buildHome(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(12,10,12,8);
        TextView head=tv("تطبيق المتابعة",26); head.setTypeface(Typeface.DEFAULT,Typeface.BOLD); head.setGravity(Gravity.CENTER);
        root.addView(head,new LinearLayout.LayoutParams(-1,-2));
        TextView dev=tv("تم إعداد التطبيق بواسطة المهندس حسن جاسم",13); dev.setGravity(Gravity.CENTER); root.addView(dev);
        LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.VERTICAL);
        Button add=btn("إضافة موعد جديد"); add.setOnClickListener(v->addAppointment());
        Button reports=btn("التقارير"); reports.setOnClickListener(v->reports());
        Button refresh=btn("تحديث المواعيد"); refresh.setOnClickListener(v->buildHome());
        Button settings=btn("الإعدادات"); settings.setOnClickListener(v->settings());
        actions.addView(add); actions.addView(reports); actions.addView(refresh); actions.addView(settings);
        root.addView(actions);
        TextView total=tv("إجمالي المواعيد: "+data.size(),18); total.setTypeface(null,Typeface.BOLD); root.addView(total);
        listBox=new LinearLayout(this); listBox.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv=new ScrollView(this); sv.addView(listBox); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root); renderList();
    }

    void renderList(){
        listBox.removeAllViews();
        Collections.sort(data,(a,b)->(a.date+" "+a.time).compareTo(b.date+" "+b.time));
        for(Appointment a:data){
            LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(12,12,12,12);
            TextView x=tv(a.title+"\n"+a.date+"  "+a.time+"\nالتنبيهات: "+a.reminders.size()+"   الحالة: "+a.status,16);
            x.setTypeface(null,Typeface.BOLD); card.addView(x);
            if(!a.notes.isEmpty()) card.addView(tv("ملاحظات: "+a.notes,14));
            LinearLayout row=new LinearLayout(this);
            Button edit=btn("تعديل"); edit.setOnClickListener(v->editAppointment(a));
            Button status=btn("الحالة"); status.setOnClickListener(v->setStatus(a));
            Button del=btn("حذف"); del.setOnClickListener(v->{Store.delete(this,a.id); data=new ArrayList<>(Store.load(this)); buildHome();});
            row.addView(edit,new LinearLayout.LayoutParams(0,-2,1)); row.addView(status,new LinearLayout.LayoutParams(0,-2,1)); row.addView(del,new LinearLayout.LayoutParams(0,-2,1));
            card.addView(row); listBox.addView(card);
        }
    }

    EditText field(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setPadding(14,10,14,10); return e; }

    void addAppointment(){ showAppointmentDialog(null); }
    void editAppointment(Appointment a){ showAppointmentDialog(a); }

    void showAppointmentDialog(Appointment old){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        EditText title=field("عنوان الموعد"); EditText date=field("التاريخ yyyy-MM-dd"); EditText time=field("الوقت 12 ساعة (مثال 09:30 م)");
        EditText notes=field("ملاحظات"); box.addView(title); box.addView(date); box.addView(time); box.addView(notes);
        if(old!=null){title.setText(old.title);date.setText(old.date);time.setText(old.time);notes.setText(old.notes);}
        new AlertDialog.Builder(this).setTitle(old==null?"ترتيب موعد جديد":"تعديل الموعد").setView(box)
        .setPositiveButton("حفظ",(d,w)->{
            if(old==null){ Appointment a=new Appointment(); a.id=System.currentTimeMillis(); a.title=title.getText().toString(); a.date=date.getText().toString(); a.time=time.getText().toString(); a.notes=notes.getText().toString(); addRemindersAndSave(a); }
            else {old.title=title.getText().toString();old.date=date.getText().toString();old.time=time.getText().toString();old.notes=notes.getText().toString(); Store.save(this,data); ReminderScheduler.scheduleAll(this); buildHome();}
        }).setNegativeButton("إلغاء",null).show();
    }

    void addRemindersAndSave(Appointment a){
        final String[] options={"قبل 5 دقائق","قبل 10 دقائق","قبل 30 دقيقة","قبل ساعة","في وقت الموعد","منبه مرن"};
        boolean[] checked=new boolean[options.length];
        new AlertDialog.Builder(this).setTitle("التنبيهات — يمكن اختيار أكثر من تنبيه")
        .setMultiChoiceItems(options,checked,(d,which,is)->checked[which]=is)
        .setPositiveButton("متابعة",(d,w)->{
            for(int i=0;i<options.length;i++) if(checked[i]){
                if(i==5){ flexibleReminder(a); } else { a.reminders.add(reminderSpec(a.time,offset(i))); }
            }
            Store.add(this,a); data=new ArrayList<>(Store.load(this)); ReminderScheduler.scheduleAll(this); buildHome();
        }).setNegativeButton("بدون تنبيه",(d,w)->{Store.add(this,a);data=new ArrayList<>(Store.load(this));buildHome();}).show();
    }

    int offset(int i){return new int[]{5,10,30,60,0}[i];}
    String reminderSpec(String time,int mins){ return time+"|"+mins; }

    void flexibleReminder(Appointment a){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        EditText t=field("وقت التنبيه 12 ساعة (مثال 08:15 ص)");
        Spinner sp=new Spinner(this); String[] units={"دقيقة قبل الموعد","ساعتين قبل الموعد","ساعة قبل الموعد","في وقت الموعد"}; sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,units));
        box.addView(t);box.addView(sp);
        new AlertDialog.Builder(this).setTitle("منبه مرن").setMessage("يمكنك تحديد وقت تنبيه مخصص أو استخدام خيار جاهز.")
        .setView(box).setPositiveButton("إضافة",(d,w)->{
            String val=t.getText().toString().trim(); if(!val.isEmpty()) a.reminders.add(val+"|0");
            Store.add(this,a);data=new ArrayList<>(Store.load(this));ReminderScheduler.scheduleAll(this);buildHome();
        }).setNegativeButton("إلغاء",null).show();
    }

    void setStatus(Appointment a){
        String[] s={"تم","لم يتم"};
        new AlertDialog.Builder(this).setTitle("حالة الموعد").setSingleChoiceItems(s,a.status.equals("تم")?0:1,(d,w)->{
            a.status=s[w]; d.dismiss(); if(a.status.equals("لم يتم")) askReason(a); else {Store.save(this,data);buildHome();}
        }).show();
    }
    void askReason(Appointment a){
        EditText e=field("سبب عدم الإنجاز"); e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE); e.setText(a.reason);
        new AlertDialog.Builder(this).setTitle("سبب").setView(e).setPositiveButton("حفظ",(d,w)->{a.reason=e.getText().toString();Store.save(this,data);buildHome();}).show();
    }

    void reports(){
        LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);
        Button monthly=btn("التقرير الشهري"); Button annual=btn("التقرير السنوي");
        Button present=btn("عرض تقديمي بسيط شهري / سنوي");
        Button export=btn("تصدير PDF أو Excel أو كلاهما");
        b.addView(monthly);b.addView(annual);b.addView(present);b.addView(export);
        monthly.setOnClickListener(v->reportText("شهري"));
        annual.setOnClickListener(v->reportText("سنوي"));
        present.setOnClickListener(v->presentation());
        export.setOnClickListener(v->chooseExport());
        new AlertDialog.Builder(this).setTitle("التقارير").setView(b).setNegativeButton("إغلاق",null).show();
    }

    void chooseExport(){
        String[] f={"PDF","Excel","كلاهما"};
        new AlertDialog.Builder(this).setTitle("صيغة التقرير").setItems(f,(d,w)->{
            String[] p={"شهري","سنوي"};
            new AlertDialog.Builder(this).setTitle("نوع التقرير").setItems(p,(dd,k)->{
                if(w==0) exportPdf(p[k]); else if(w==1) exportExcel(p[k]); else {exportPdf(p[k]);exportExcel(p[k]);}
            }).show();
        }).show();
    }

    void exportExcel(String type){
        try{
            String name="تقرير_"+type+"_"+new SimpleDateFormat("yyyyMMdd_HHmm",Locale.US).format(new Date())+".xls";
            java.io.File f=new java.io.File(getExternalFilesDir(null),name);
            java.io.FileOutputStream out=new java.io.FileOutputStream(f);
            String h="<html><head><meta charset='UTF-8'></head><body><table border='1'><tr><th>التاريخ</th><th>الوقت</th><th>الموعد</th><th>الحالة</th><th>السبب</th><th>الملاحظات</th></tr>";
            for(Appointment x:data) h+="<tr><td>"+x.date+"</td><td>"+x.time+"</td><td>"+x.title+"</td><td>"+x.status+"</td><td>"+x.reason+"</td><td>"+x.notes+"</td></tr>";
            h+="</table></body></html>";out.write(h.getBytes("UTF-8"));out.close();
            Toast.makeText(this,"تم حفظ ملف Excel داخل ملفات التطبيق",Toast.LENGTH_LONG).show();
        }catch(Exception e){Toast.makeText(this,"تعذر إنشاء Excel",Toast.LENGTH_LONG).show();}
    }

    void exportPdf(String type){
        try{
            android.graphics.pdf.PdfDocument doc=new android.graphics.pdf.PdfDocument();
            int pageNo=1; android.graphics.pdf.PdfDocument.PageInfo pi=new android.graphics.pdf.PdfDocument.PageInfo.Builder(595,842,pageNo).create();
            android.graphics.pdf.PdfDocument.Page page=doc.startPage(pi); android.graphics.Canvas c=page.getCanvas();android.graphics.Paint q=new android.graphics.Paint();
            q.setTextSize(18);c.drawText("تطبيق المتابعة - التقرير "+type,40,45,q);q.setTextSize(11);int y=75;
            for(Appointment x:data){
                c.drawText(x.date+" | "+x.time+" | "+x.title+" | "+x.status,40,y,q);y+=20;
                if(y>810){doc.finishPage(page);pageNo++;pi=new android.graphics.pdf.PdfDocument.PageInfo.Builder(595,842,pageNo).create();page=doc.startPage(pi);c=page.getCanvas();y=45;}
            }
            doc.finishPage(page);
            java.io.File f=new java.io.File(getExternalFilesDir(null),"تقرير_"+type+"_"+new SimpleDateFormat("yyyyMMdd_HHmm",Locale.US).format(new Date())+".pdf");
            java.io.FileOutputStream out=new java.io.FileOutputStream(f);doc.writeTo(out);out.close();doc.close();
            Toast.makeText(this,"تم حفظ ملف PDF داخل ملفات التطبيق",Toast.LENGTH_LONG).show();
        }catch(Exception e){Toast.makeText(this,"تعذر إنشاء PDF",Toast.LENGTH_LONG).show();}
    }

    void presentation(){
        int total=data.size(),done=0;for(Appointment x:data)if(x.status.equals("تم"))done++;
        int not=total-done;int pct=total==0?0:done*100/total;
        StringBuilder m=new StringBuilder("ملخص شهري / سنوي\\n\\n");
        m.append("إجمالي المواعيد: ").append(total).append("\\nتم: ").append(done).append("\\nلم يتم: ").append(not).append("\\nنسبة الإنجاز: ").append(pct).append("%\\n\\n");
        m.append("أبرز المواعيد:\\n");int n=0;for(Appointment x:data){if(n++>=8)break;m.append("• ").append(x.date).append(" — ").append(x.time).append(" — ").append(x.title).append("\\n");}
        new AlertDialog.Builder(this).setTitle("العرض التقديمي").setMessage(m.toString()).setPositiveButton("حسنًا",null).show();
    }

    void exportText(){
        try{
            StringBuilder s=new StringBuilder("التاريخ\\tالوقت\\tالموعد\\tالحالة\\tالسبب\\tالملاحظات\\n");
            for(Appointment a:data)s.append(a.date).append("\\t").append(a.time).append("\\t").append(a.title).append("\\t").append(a.status).append("\\t").append(a.reason).append("\\t").append(a.notes).append("\\n");
            String name="تقرير_المواعيد_"+new SimpleDateFormat("yyyyMMdd_HHmm",Locale.US).format(new Date())+".xls";
            java.io.File f=new java.io.File(getExternalFilesDir(null),name);
            java.io.FileOutputStream out=new java.io.FileOutputStream(f);out.write(s.toString().getBytes("UTF-8"));out.close();
            new AlertDialog.Builder(this).setTitle("تم التصدير").setMessage("تم حفظ الملف داخل مجلد ملفات التطبيق:\\n"+f.getAbsolutePath()).setPositiveButton("حسنًا",null).show();
        }catch(Exception e){Toast.makeText(this,"تعذر التصدير",Toast.LENGTH_LONG).show();}
    }
}
