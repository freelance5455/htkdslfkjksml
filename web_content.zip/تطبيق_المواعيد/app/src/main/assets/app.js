const KEY='followup_html_data', PASS='followup_html_password';
let appointments=JSON.parse(localStorage.getItem(KEY)||'[]');
let password=localStorage.getItem(PASS)||'0000';

function login(){
 const p=document.getElementById('loginPass').value;
 if(p===password){document.getElementById('login').classList.add('hidden');document.getElementById('app').classList.remove('hidden');render();}
 else alert('كلمة السر غير صحيحة');
}
function save(){localStorage.setItem(KEY,JSON.stringify(appointments));render();}
function showTab(id){
 document.querySelectorAll('.tab').forEach(x=>x.classList.add('hidden'));
 document.getElementById(id).classList.remove('hidden');
 if(id==='reports') report();
 if(id==='summary') presentation();
}
function openForm(item=null){
 const a=item||{id:Date.now(),title:'',date:'',time:'',notes:'',status:'لم يتم',reason:'',reminders:[]};
 const m=document.getElementById('modal');
 m.innerHTML=`<div class="dialog"><h2>${item?'تعديل الموعد':'موعد جديد'}</h2>
 <input id="fTitle" placeholder="عنوان الموعد" value="${esc(a.title)}">
 <input id="fDate" type="date" value="${esc(a.date)}">
 <input id="fTime" type="time" value="${esc(a.time)}">
 <input id="fReminder" placeholder="تنبيه إضافي (مثال: 08:30)">
 <textarea id="fNotes" rows="3" placeholder="ملاحظات">${esc(a.notes)}</textarea>
 <div><button onclick="saveForm(${a.id})">حفظ</button><button onclick="closeModal()">إلغاء</button></div></div>`;
 m.classList.remove('hidden');window.current=a;
}
function saveForm(id){
 let a=appointments.find(x=>x.id===id);
 if(!a){a=window.current;appointments.push(a)}
 a.title=document.getElementById('fTitle').value.trim()||'موعد';
 a.date=document.getElementById('fDate').value;
 a.time=document.getElementById('fTime').value;
 a.notes=document.getElementById('fNotes').value;
 const r=document.getElementById('fReminder').value.trim();
 if(r && !a.reminders.includes(r))a.reminders.push(r);
 save();closeModal();
}
function closeModal(){document.getElementById('modal').classList.add('hidden')}
function edit(id){openForm(appointments.find(x=>x.id===id))}
function del(id){if(confirm('حذف الموعد؟')){appointments=appointments.filter(x=>x.id!==id);save()}}
function status(id){
 const a=appointments.find(x=>x.id===id);
 const s=prompt('اكتب: تم أو لم يتم',a.status);
 if(s==='تم'||s==='لم يتم'){a.status=s;if(s==='لم يتم')a.reason=prompt('سبب عدم الإنجاز','')||'';save()}
}
function render(){
 const q=(document.getElementById('search')?.value||'').toLowerCase();
 const list=document.getElementById('list');if(!list)return;
 let arr=appointments.filter(a=>(a.title+a.date+a.notes).toLowerCase().includes(q)).sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time));
 list.innerHTML=arr.map(a=>`<div class="card"><h3>${esc(a.title)} <span class="badge ${a.status==='تم'?'done':'notdone'}">${a.status}</span></h3>
 <div class="meta">📅 ${a.date||'-'} &nbsp; ⏰ ${a.time||'-'}<br>🔔 عدد التنبيهات: ${a.reminders?.length||0}<br>${a.notes?'📝 '+esc(a.notes):''}${a.reason?' 🟠 السبب: '+esc(a.reason):''}</div>
 <button onclick="edit(${a.id})">تعديل</button><button onclick="status(${a.id})">الحالة</button><button class="danger" onclick="del(${a.id})">حذف</button></div>`).join('')||'<div class="card">لا توجد مواعيد.</div>';
 report();
}
function report(){
 let done=appointments.filter(a=>a.status==='تم').length,total=appointments.length;
 document.getElementById('total').textContent=total;document.getElementById('done').textContent=done;document.getElementById('notdone').textContent=total-done;document.getElementById('percent').textContent=(total?Math.round(done*100/total):0)+'%';
 document.getElementById('reportTable').innerHTML='<div class="tablewrap"><table><tr><th>التاريخ</th><th>الوقت</th><th>الموعد</th><th>الحالة</th><th>السبب</th></tr>'+appointments.map(a=>`<tr><td>${a.date}</td><td>${a.time}</td><td>${esc(a.title)}</td><td>${a.status}</td><td>${esc(a.reason||'')}</td></tr>`).join('')+'</table></div>';
}
function presentation(){
 let total=appointments.length,done=appointments.filter(a=>a.status==='تم').length;
 let pct=total?Math.round(done*100/total):0;
 document.getElementById('presentation').innerHTML=`<h2>العرض التقديمي — ملخص المواعيد</h2><div class="big">${pct}%</div><p>نسبة الإنجاز</p><hr><p>إجمالي المواعيد: <b>${total}</b></p><p>تم: <b>${done}</b></p><p>لم يتم: <b>${total-done}</b></p><h3>أبرز المواعيد</h3>${appointments.slice(0,8).map(a=>`<p>• ${a.date} — ${a.time} — ${esc(a.title)}</p>`).join('')}`;
}
function chooseExport(){}
function exportReport(){
 const fmt=document.getElementById('format').value;
 if(fmt==='PDF'){window.print();return}
 const rows=[['التاريخ','الوقت','الموعد','الحالة','السبب','الملاحظات'],...appointments.map(a=>[a.date,a.time,a.title,a.status,a.reason||'',a.notes||''])];
 const csv='\ufeff'+rows.map(r=>r.map(v=>`"${String(v).replaceAll('"','""')}"`).join(',')).join('\n');
 const blob=new Blob([csv],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='تقرير_المواعيد.xls';a.click();URL.revokeObjectURL(url);
 if(fmt==='كلاهما')setTimeout(()=>window.print(),300);
}
function settings(){
 const old=prompt('كلمة السر الحالية');if(old===null)return;
 if(old!==password){alert('كلمة السر الحالية غير صحيحة');return}
 const np=prompt('كلمة السر الجديدة (4 أرقام أو أكثر)');if(!np||np.length<4){alert('كلمة السر قصيرة');return}
 password=np;localStorage.setItem(PASS,password);alert('تم تغيير كلمة السر');
}
function esc(v){return String(v??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;')}
document.addEventListener('keydown',e=>{if(e.key==='Enter'&&document.activeElement.id==='loginPass')login()});
