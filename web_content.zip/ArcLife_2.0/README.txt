ArcLife 2.0 - Black + Neon Green fitness app prototype

HOW TO USE
1. Extract the ZIP file.
2. Open index.html in Chrome on your phone or computer.
3. Internet is needed for the remote exercise photos.
4. Workout completions and progress are stored in that browser on that device.

INCLUDED
- Responsive mobile-first UI inspired by the ArcLife visual concept
- Workout categories: Abs, Chest, Arms, Legs, Full Body
- Exercise photo, sets/reps, instructions, rest timer
- 30-day challenge, progress history, profile and reminder preference toggle

IMPORTANT
This is a working web prototype, not an installable Android APK yet. It uses online image URLs for exercise photos. The reminder toggle is a prototype preference, not a scheduled Android notification. To make an APK, wrap/build this project with an Android toolchain such as Capacitor/Android Studio or another supported builder.
