package dk.cardboard.aivision;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.net.Uri;
import android.widget.Toast;
import androidx.core.content.ContextCompat;
import androidx.webkit.WebViewAssetLoader;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView webView;
    private PermissionRequest pendingWebPermission;
    private SpeechRecognizer speechRecognizer;
    private TextToSpeech tts;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private static final int REQ_MIC = 201;
    private static final int REQ_WEB_PERMISSION = 202;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(
            4 | 1024 | 4096 | 512 | 2
        );
        webView = new WebView(this);
        setContentView(webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(false);
        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");

        WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
            .build();

        webView.setWebViewClient(new WebViewClient() {
            @Override public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                return !("appassets.androidplatform.net".equals(u.getHost()) && "https".equals(u.getScheme()));
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    boolean cameraOk = ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
                    if (cameraOk) request.grant(request.getResources());
                    else {
                        pendingWebPermission = request;
                        requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_WEB_PERMISSION);
                    }
                });
            }
            @Override public void onPermissionRequestCanceled(PermissionRequest request) {
                if (pendingWebPermission == request) pendingWebPermission = null;
            }
        });
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("da", "DK"));
        });
    }

    private void js(String script) {
        runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript(script, null); });
    }

    private void startSpeech() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            js("window.onNativeSpeechError && window.onNativeSpeechError('Talegenkendelse er ikke tilgængelig på denne enhed')");
            return;
        }
        if (speechRecognizer != null) speechRecognizer.destroy();
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) { js("window.onNativeSpeechStatus && window.onNativeSpeechStatus('Lytter…')"); }
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() { js("window.onNativeSpeechStatus && window.onNativeSpeechStatus('Behandler tale…')"); }
            @Override public void onError(int error) { js("window.onNativeSpeechError && window.onNativeSpeechError('Kunne ikke genkende tale (kode " + error + ")')"); }
            @Override public void onResults(Bundle results) {
                ArrayList<String> list = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (list != null && !list.isEmpty()) {
                    js("window.onNativeSpeechResult && window.onNativeSpeechResult(" + JSONObject.quote(list.get(0)) + ")");
                } else js("window.onNativeSpeechError && window.onNativeSpeechError('Ingen tale genkendt')");
            }
            @Override public void onPartialResults(Bundle partialResults) {}
            @Override public void onEvent(int eventType, Bundle params) {}
        });
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "da-DK");
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "da-DK");
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        speechRecognizer.startListening(intent);
    }

    private void analyze(String question, String dataUrl, String key) {
        executor.execute(() -> {
            HttpURLConnection conn = null;
            try {
                if (key == null || key.trim().isEmpty()) throw new Exception("Indsæt din DeepSeek API-nøgle.");
                if (dataUrl == null || !dataUrl.startsWith("data:image/")) throw new Exception("Kameraet har ikke leveret et billede.");
                JSONObject body = new JSONObject();
                body.put("model", "deepseek-flash");
                body.put("max_tokens", 180);
                body.put("thinking", new JSONObject().put("type", "disabled"));
                JSONArray messages = new JSONArray();
                JSONObject message = new JSONObject().put("role", "user");
                JSONArray content = new JSONArray();
                content.put(new JSONObject().put("type", "text").put("text",
                    (question == null || question.trim().isEmpty() ? "Beskriv billedet kort." : question) +
                    " Svar kort på dansk. Beskriv kun det, der faktisk kan ses."));
                content.put(new JSONObject().put("type", "image_url")
                    .put("image_url", new JSONObject().put("url", dataUrl).put("detail", "low")));
                message.put("content", content);
                messages.put(message);
                body.put("messages", messages);

                conn = (HttpURLConnection) new URL("https://api.deepseek.com/chat/completions").openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(20000);
                conn.setReadTimeout(45000);
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Authorization", "Bearer " + key.trim());
                byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
                try (OutputStream os = conn.getOutputStream()) { os.write(bytes); }
                int code = conn.getResponseCode();
                InputStream stream = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
                StringBuilder response = new StringBuilder();
                try (BufferedReader br = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                    String line; while ((line = br.readLine()) != null) response.append(line);
                }
                JSONObject parsed = new JSONObject(response.toString());
                if (code < 200 || code >= 300) {
                    String msg = parsed.optJSONObject("error") != null ? parsed.optJSONObject("error").optString("message", "API-fejl " + code) : "API-fejl " + code;
                    throw new Exception(msg);
                }
                String answer = parsed.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content", "Intet svar modtaget.");
                js("window.onAiResult && window.onAiResult(" + JSONObject.quote(answer) + ")");
            } catch (Exception e) {
                js("window.onAiError && window.onAiError(" + JSONObject.quote(e.getMessage() == null ? "Ukendt fejl" : e.getMessage()) + ")");
            } finally { if (conn != null) conn.disconnect(); }
        });
    }

    private class Bridge {
        @JavascriptInterface public void startListening() { runOnUiThread(() -> MainActivity.this.startSpeech()); }
        @JavascriptInterface public void speak(String text) {
            runOnUiThread(() -> {
                if (tts != null) tts.speak(text == null ? "" : text, TextToSpeech.QUEUE_FLUSH, null, "cardboard-ai-answer");
            });
        }
        @JavascriptInterface public void stopSpeaking() {
            runOnUiThread(() -> { if (tts != null) tts.stop(); });
        }
        @JavascriptInterface public void analyze(String question, String imageData, String key) {
            MainActivity.this.analyze(question, imageData, key);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_WEB_PERMISSION && pendingWebPermission != null) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) pendingWebPermission.grant(pendingWebPermission.getResources());
            else pendingWebPermission.deny();
            pendingWebPermission = null;
        } else if (requestCode == REQ_MIC) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) startSpeech();
            else js("window.onNativeSpeechError && window.onNativeSpeechError('Mikrofontilladelse blev afvist')");
        }
    }

    @Override public void onDestroy() {
        if (speechRecognizer != null) speechRecognizer.destroy();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (webView != null) { webView.destroy(); webView = null; }
        executor.shutdownNow();
        super.onDestroy();
    }
}
