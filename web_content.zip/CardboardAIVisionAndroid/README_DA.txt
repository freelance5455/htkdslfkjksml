CARDBOARD AI VISION — Android-projekt (version 1.1)
===================================================

Indeholder:
- SBS-kameravisning til Google Cardboard
- Androids native talegenkendelse (STT) på dansk
- Androids native tekst-til-tale (TTS)
- DeepSeek Flash billedanalyse via Android-netværkskode
- Kamera- og mikrofontilladelser i appen
- API-nøglen indtastes i appen og gemmes ikke permanent

VIGTIGT:
Dette er Android-projektets kildekode, ikke en allerede kompileret APK.
Der var ikke Android SDK/Gradle installeret i miljøet, så en APK kunne ikke
kompileres her. Åbn projektet i Android Studio eller en Android IDE, som
understøtter Gradle/Android SDK, og byg en debug APK.

Bygning:
1. Åbn projektmappen som et Gradle-projekt.
2. Synkronisér Gradle og installer nødvendige Android SDK-platformværktøjer.
3. Kør Build > Build APK(s).
4. Installer APK'en på din telefon, og giv kamera- og mikrofontilladelse.

API-nøgle:
Indsæt din egen gyldige DeepSeek API-nøgle i appen. Nøglen indlejres ikke i
projektet. Fordi nøglen blev delt i en chat tidligere, bør den tilbagekaldes
og erstattes med en ny før brug.

Bemærk:
- AI-analyse kræver internet og en aktiv DeepSeek API-konto.
- Kameraet vises i to SBS-halvdele; det er ikke stereoskopisk dybdekamera.
- Talegenkendelse kan kræve, at Androids talegenkendelsestjeneste er installeret.
