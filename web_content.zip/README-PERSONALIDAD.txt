Actualización de personalidad de Miércoles 3.1:
- Tono profesional, neutral y respetuoso por defecto.
- Sin sarcasmo, ironía ni humor oscuro salvo que el usuario lo elija en Ajustes > Personalización.
- Se mantienen las opciones de tono en Personalización.
- Las instrucciones personalizadas siguen teniendo prioridad.
- Se conserva la conexión Groq y el resto de funciones del ZIP de origen.
