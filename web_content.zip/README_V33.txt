ADI X DATA ADMIN V33 — REVIEW CONTROL ENHANCEMENT
==============================================
Base: ADI X DATA V32 Premium Control Center.

Preserved V32 features:
- Premium Control Center
- Withdrawal search / approval controls
- Reject + Reject & Return reason popup
- Multi-path live Telegram mirroring
- Users, Keys, Top Sellers, Support, Notifications, Settings, Audit and Security Center

V33 enhancements:
- Dedicated Customer Reviews control on Admin dashboard
- Review moderation queue with search, status filter and rating filter
- Full private reviewer bio visible to Admin only
- Public masked-name preview
- Publish / Hide / Edit / Delete controls
- Review statistics and average rating
- Export review records for Admin backup
- Review moderation actions added to Audit Log
- Review database paths included in Security diagnostics and Admin backup
- Versioning follows the separate Admin V-series; this is V33, not User V99.

Firebase project: data-x-pro-77
Admin UID: uUXSoYnTLxNpDgF8fqh0Ea3IGWK2

Publish FIREBASE_RULES_V33_ADMIN_REVIEWS.json together with the Admin build if the live Rules file does not already expose the review paths to Admin.
