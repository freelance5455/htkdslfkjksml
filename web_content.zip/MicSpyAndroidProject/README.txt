MicSpy UI Demo - Android Studio project

WHAT THIS BUILDS
- An Android app that displays the supplied MicSpy HTML demo inside a WebView.
- The Sender screen can request microphone permission and play a local preview on the same phone.
- The Receiver screen is only a UI placeholder.

IMPORTANT LIMITATION
This project does NOT stream audio to another phone. It has no WebRTC signaling server,
pairing backend, or remote audio receiver. Do not treat the pairing screen as functional.

HOW TO BUILD THE APK
1. Install Android Studio (with Android SDK Platform 35).
2. Extract this ZIP.
3. In Android Studio choose File > Open and select the MicSpyAndroidProject folder.
4. Wait for Gradle sync to finish.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show a link to the generated APK. The usual output path is:
   app/build/outputs/apk/debug/app-debug.apk

TESTING
- Install the debug APK on an Android phone.
- Open the app and tap "Start Microphone Preview".
- Grant microphone permission.
- Tap "Stop Preview" to release the microphone.

The microphone preview is local to the phone and only works while the app is open.
