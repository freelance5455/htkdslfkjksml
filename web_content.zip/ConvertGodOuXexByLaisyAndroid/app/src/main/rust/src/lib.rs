use anyhow::{bail, Context, Result};
use iso2god::{executable::TitleInfo, god, iso};
use iso2god::god::{ContentType, FileLayout};
use iso2god::iso::{DirectoryTable, WindowsPath};
use jni::objects::{JClass, JString};
use jni::sys::jstring;
use jni::JNIEnv;
use std::fs::{self, File};
use std::io::{Read, Seek, SeekFrom, Write};
use std::path::{Component, Path, PathBuf};

fn clear_and_create(path: &Path) -> Result<()> {
    if path.exists() {
        fs::remove_dir_all(path).with_context(|| format!("could not clear {}", path.display()))?;
    }
    fs::create_dir_all(path).with_context(|| format!("could not create {}", path.display()))?;
    Ok(())
}

fn convert_god(input: &Path, output_root: &Path, custom_title: &str) -> Result<String> {
    let source_file = File::open(input).context("could not open ISO")?;
    let source_meta = source_file.metadata().context("could not read ISO size")?;
    let mut source = iso::IsoReader::read(source_file).context("unsupported or damaged Xbox ISO")?;
    let title = TitleInfo::from_image(&mut source).context("could not find default.xex/default.xbe")?;
    let exe = title.execution_info;
    let content_type = title.content_type;

    let data_size = source.get_max_used_prefix_size();
    if data_size == 0 { bail!("the ISO does not contain readable game data"); }
    let block_count = data_size.div_ceil(god::BLOCK_SIZE);
    let part_count = block_count.div_ceil(god::BLOCKS_PER_PART);
    if part_count == 0 { bail!("no GOD data parts were produced"); }

    let layout = FileLayout::new(output_root, &exe, content_type);
    clear_and_create(&layout.data_dir_path()).context("could not prepare GOD data folder")?;

    for index in 0..part_count {
        let mut volume = File::open(input).context("could not reopen ISO")?;
        volume.seek(SeekFrom::Start(source.volume_descriptor.root_offset))?;
        let part_path = layout.part_file_path(index);
        let mut part = File::options().write(true).create(true).truncate(true).open(&part_path)
            .with_context(|| format!("could not create {}", part_path.display()))?;
        god::write_part(volume, index, &mut part).with_context(|| format!("failed writing GOD part {index}"))?;
        part.flush()?;
    }

    let mut mht = read_mht(&layout, part_count - 1).context("could not read final hash table")?;
    for part_index in (0..part_count - 1).rev() {
        let mut previous = read_mht(&layout, part_index).context("could not read hash table")?;
        previous.add_hash(&mht.digest());
        write_mht(&layout, part_index, &previous).context("could not update hash table")?;
        mht = previous;
    }

    let last_size = fs::metadata(layout.part_file_path(part_count - 1))?.len();
    let mut header = god::ConHeaderBuilder::new()
        .with_execution_info(&exe)
        .with_block_counts(block_count as u32, 0)
        .with_data_parts_info(part_count as u32, last_size + (part_count - 1) * god::BLOCK_SIZE * 0xa290)
        .with_content_type(content_type)
        .with_mht_hash(&mht.digest());
    let game_title = if custom_title.trim().is_empty() {
        iso2god::game_list::find_title_by_id(exe.title_id)
    } else {
        Some(custom_title.trim().to_owned())
    };
    if let Some(name) = game_title.as_deref() { header = header.with_game_title(name); }
    let header_path = layout.con_header_file_path();
    if let Some(parent) = header_path.parent() { fs::create_dir_all(parent)?; }
    let mut output = File::options().write(true).create(true).truncate(true).open(&header_path)
        .context("could not create GOD header")?;
    output.write_all(&header.finalize())?;
    output.flush()?;
    let original_size = source_meta.len();
    Ok(format!("GOD pronto · Title ID {:08X} · ISO {} bytes", exe.title_id, original_size))
}

fn read_mht(layout: &FileLayout, index: u64) -> Result<god::HashList> {
    let mut file = File::open(layout.part_file_path(index))?;
    Ok(god::HashList::read(&mut file)?)
}
fn write_mht(layout: &FileLayout, index: u64, hashes: &god::HashList) -> Result<()> {
    let mut file = File::options().write(true).open(layout.part_file_path(index))?;
    hashes.write(&mut file)?;
    Ok(())
}

fn safe_child(base: &Path, name: &str) -> Result<PathBuf> {
    if name.is_empty() || name == "." || name == ".." || name.contains('/') || name.contains('\\') || name.contains('\0') {
        bail!("ISO contains an unsafe file name");
    }
    let candidate = base.join(name);
    if candidate.components().any(|c| matches!(c, Component::ParentDir | Component::RootDir | Component::Prefix(_))) {
        bail!("unsafe path in ISO");
    }
    Ok(candidate)
}

fn extract_dir(source: &mut File, dir: &DirectoryTable, base_offset: u64, sector_size: u64, target: &Path) -> Result<()> {
    for entry in &dir.entries {
        let dest = safe_child(target, &entry.name)?;
        if entry.is_directory() {
            fs::create_dir_all(&dest).with_context(|| format!("could not create {}", dest.display()))?;
            if let Some(subdir) = &entry.subdirectory {
                extract_dir(source, subdir, base_offset, sector_size, &dest)?;
            }
        } else {
            if let Some(parent) = dest.parent() { fs::create_dir_all(parent)?; }
            let offset = base_offset.checked_add((entry.sector as u64).checked_mul(sector_size).context("sector offset overflow")?)
                .context("file offset overflow")?;
            source.seek(SeekFrom::Start(offset)).with_context(|| format!("could not seek to {}", entry.name))?;
            let mut out = File::create(&dest).with_context(|| format!("could not create {}", dest.display()))?;
            let mut bounded = (&mut *source).take(entry.size as u64);
            let copied = std::io::copy(&mut bounded, &mut out).with_context(|| format!("could not extract {}", entry.name))?;
            if copied != entry.size as u64 { bail!("truncated file in ISO: {}", entry.name); }
        }
    }
    Ok(())
}

fn convert_xex(input: &Path, output_root: &Path) -> Result<String> {
    let mut image = iso::IsoReader::read(File::open(input).context("could not open ISO")?)
        .context("unsupported or damaged Xbox ISO")?;
    let title = TitleInfo::from_image(&mut image).context("could not find default.xex/default.xbe")?;
    let title_id = title.execution_info.title_id;
    let base_offset = image.volume_descriptor.root_offset;
    let sector_size = image.volume_descriptor.sector_size;
    if sector_size == 0 { bail!("invalid sector size in ISO"); }
    let output = output_root.join("XEX");
    clear_and_create(&output)?;
    let mut source = File::open(input).context("could not reopen ISO")?;
    extract_dir(&mut source, &image.directory_table, base_offset, sector_size, &output)
        .context("could not extract the ISO file tree")?;
    Ok(format!("XEX extraído · Title ID {title_id:08X}"))
}

#[no_mangle]
pub extern "system" fn Java_br_com_laisy_convertbylaisy_NativeConverter_convert(
    mut env: JNIEnv,
    _class: JClass,
    input: JString,
    output_root: JString,
    format: JString,
    title: JString,
) -> jstring {
    let result = (|| -> Result<String> {
        let input: String = env.get_string(&input).map_err(|e| anyhow::anyhow!(e.to_string()))?.into();
        let output_root: String = env.get_string(&output_root).map_err(|e| anyhow::anyhow!(e.to_string()))?.into();
        let format: String = env.get_string(&format).map_err(|e| anyhow::anyhow!(e.to_string()))?.into();
        let title: String = env.get_string(&title).map_err(|e| anyhow::anyhow!(e.to_string()))?.into();
        let input = Path::new(&input);
        let output_root = Path::new(&output_root);
        fs::create_dir_all(output_root)?;
        match format.to_ascii_uppercase().as_str() {
            "GOD" => convert_god(input, output_root, &title),
            "XEX" => convert_xex(input, output_root),
            _ => bail!("unknown output format"),
        }
    })();
    let message = match result { Ok(text) => format!("OK:{text}"), Err(error) => format!("ERROR:{error:#}") };
    env.new_string(message).map(|s| s.into_raw()).unwrap_or(std::ptr::null_mut())
}
