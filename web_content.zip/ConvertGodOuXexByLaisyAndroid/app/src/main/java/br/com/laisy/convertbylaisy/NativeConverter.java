package br.com.laisy.convertbylaisy;

public final class NativeConverter {
    static {
        System.loadLibrary("convert_native");
    }

    private NativeConverter() {}

    public static native String convert(String inputPath, String outputRoot, String format, String title);
}
