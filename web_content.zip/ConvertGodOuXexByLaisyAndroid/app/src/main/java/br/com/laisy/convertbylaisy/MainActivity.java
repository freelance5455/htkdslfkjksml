package br.com.laisy.convertbylaisy;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.documentfile.provider.DocumentFile;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int PICK_ISO = 4172;
    private static final int PICK_OUTPUT = 4173;
    private static final String PREFS = "convert_god_xex_by_laisy";
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private WebView webView;
    private Uri isoUri;
    private Uri outputTreeUri;
    private volatile boolean working;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        isoUri = readUri("iso_uri");
        outputTreeUri = readUri("output_uri");
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF10111A);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setSupportZoom(false);
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                runJs("window.androidSetReady && window.androidSetReady();");
                if (isoUri != null) sendIsoInfo();
                if (outputTreeUri != null) sendFolderInfo();
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private Uri readUri(String key) {
        String value = getSharedPreferences(PREFS, MODE_PRIVATE).getString(key, null);
        try { return value == null ? null : Uri.parse(value); } catch (Exception ignored) { return null; }
    }

    private void saveUri(String key, Uri uri) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(key, uri == null ? null : uri.toString()).apply();
    }

    private void runJs(String script) {
        if (webView == null) return;
        mainHandler.post(() -> { if (webView != null) webView.evaluateJavascript(script, null); });
    }

    private void status(String message, boolean success) {
        runJs("window.androidSetStatus && window.androidSetStatus(" + JSONObject.quote(message) + "," + success + ",true);");
    }

    private void progress(String message) {
        runJs("window.androidSetStatus && window.androidSetStatus(" + JSONObject.quote(message) + ",false,false);");
    }

    private String queryDisplayName(Uri uri) {
        try (Cursor cursor = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int column = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (column >= 0) return cursor.getString(column);
            }
        } catch (Exception ignored) { }
        String last = uri.getLastPathSegment();
        return last == null ? "arquivo.iso" : last;
    }

    private long querySize(Uri uri) {
        try (Cursor cursor = getContentResolver().query(uri, new String[]{OpenableColumns.SIZE}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int column = cursor.getColumnIndex(OpenableColumns.SIZE);
                if (column >= 0 && !cursor.isNull(column)) return cursor.getLong(column);
            }
        } catch (Exception ignored) { }
        return 0;
    }

    private void sendIsoInfo() {
        if (isoUri == null) return;
        String name = queryDisplayName(isoUri);
        if (!name.toLowerCase(Locale.ROOT).endsWith(".iso")) return;
        long size = querySize(isoUri);
        runJs("window.androidSetIso && window.androidSetIso(" + JSONObject.quote(name) + "," + size + ");");
    }

    private void sendFolderInfo() {
        if (outputTreeUri == null) return;
        DocumentFile folder = DocumentFile.fromTreeUri(this, outputTreeUri);
        String name = folder == null || folder.getName() == null ? "Pasta escolhida" : folder.getName();
        runJs("window.androidSetFolder && window.androidSetFolder(" + JSONObject.quote(name) + ");");
    }

    private final class AndroidBridge {
        @JavascriptInterface public void pickIso() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/x-iso9660-image", "application/octet-stream", "application/vnd.ms-cd-image"});
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(intent, PICK_ISO);
            });
        }

        @JavascriptInterface public void clearIso() {
            isoUri = null;
            saveUri("iso_uri", null);
        }

        @JavascriptInterface public void pickOutputFolder() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(intent, PICK_OUTPUT);
            });
        }

        @JavascriptInterface public void startConversion(String format) {
            if (working) { status("Já existe uma conversão em andamento.", false); return; }
            if (isoUri == null || outputTreeUri == null) { status("Selecione uma ISO e uma pasta de saída.", false); return; }
            final String safeFormat = "XEX".equalsIgnoreCase(format) ? "XEX" : "GOD";
            working = true;
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            progress("Copiando ISO para o espaço temporário do app…");
            worker.execute(() -> doConversion(safeFormat));
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            if (requestCode == PICK_ISO) {
                String name = queryDisplayName(uri);
                if (!name.toLowerCase(Locale.ROOT).endsWith(".iso")) {
                    status("Selecione um arquivo com extensão .iso.", false);
                    return;
                }
                int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                getContentResolver().takePersistableUriPermission(uri, flags & Intent.FLAG_GRANT_READ_URI_PERMISSION);
                isoUri = uri;
                saveUri("iso_uri", uri);
                sendIsoInfo();
            } else if (requestCode == PICK_OUTPUT) {
                int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                getContentResolver().takePersistableUriPermission(uri, flags);
                outputTreeUri = uri;
                saveUri("output_uri", uri);
                sendFolderInfo();
            }
        } catch (Exception e) {
            status("Não foi possível guardar a permissão. Escolha novamente.", false);
        }
    }

    private void doConversion(String format) {
        File work = null;
        DocumentFile sessionFolder = null;
        try {
            File appStorage = getExternalFilesDir("conversoes");
            if (appStorage == null) appStorage = new File(getFilesDir(), "conversoes");
            if (!appStorage.exists() && !appStorage.mkdirs()) throw new Exception("Sem espaço ou sem acesso ao armazenamento do app.");
            work = new File(appStorage, "job-" + System.currentTimeMillis());
            if (!work.mkdirs()) throw new Exception("Não foi possível criar a pasta temporária.");
            File input = new File(work, "input.iso");
            copyUriToFile(isoUri, input);
            File nativeOutput = new File(work, "output");
            if (!nativeOutput.mkdirs()) throw new Exception("Não foi possível preparar a saída temporária.");

            progress("Convertendo para " + format + "… pode levar bastante tempo.");
            String result = NativeConverter.convert(input.getAbsolutePath(), nativeOutput.getAbsolutePath(), format, "");
            if (result == null || result.startsWith("ERROR:")) throw new Exception(result == null ? "O motor não retornou resultado." : result.substring("ERROR:".length()).trim());

            // A ISO intermediária já não é necessária; removê-la reduz o pico de armazenamento ao copiar a saída.
            if (input.exists()) input.delete();
            DocumentFile chosen = DocumentFile.fromTreeUri(this, outputTreeUri);
            if (chosen == null || !chosen.canWrite()) throw new Exception("A pasta escolhida não permite gravação. Selecione outra.");
            String stamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.ROOT).format(new Date());
            sessionFolder = chosen.createDirectory("Convert-God-Xex-" + stamp);
            if (sessionFolder == null) throw new Exception("Não foi possível criar a pasta de saída.");
            progress("Salvando os arquivos na pasta escolhida…");
            File[] children = nativeOutput.listFiles();
            if (children == null || children.length == 0) throw new Exception("A conversão terminou sem arquivos de saída.");
            for (File child : children) copyTreeToSaf(child, sessionFolder);
            String label = sessionFolder.getName() == null ? "pasta escolhida" : sessionFolder.getName();
            status("Pronto! Resultado salvo em " + label + ".", true);
        } catch (Throwable error) {
            if (sessionFolder != null) {
                try { sessionFolder.delete(); } catch (Exception ignored) { }
            }
            String message = error.getMessage() == null ? "Falha inesperada durante a conversão." : error.getMessage();
            status("ERRO: " + message, false);
        } finally {
            if (work != null) deleteRecursively(work);
            working = false;
            runOnUiThread(() -> getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON));
        }
    }

    private void copyUriToFile(Uri uri, File target) throws Exception {
        InputStream raw = getContentResolver().openInputStream(uri);
        if (raw == null) throw new Exception("O Android não conseguiu abrir a ISO.");
        try (InputStream in = new BufferedInputStream(raw, 1024 * 1024);
             OutputStream out = new BufferedOutputStream(new FileOutputStream(target), 1024 * 1024)) {
            copyStream(in, out);
        }
    }

    private static void copyStream(InputStream in, OutputStream out) throws Exception {
        byte[] buffer = new byte[1024 * 1024];
        int n;
        while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
        out.flush();
    }

    private void copyTreeToSaf(File source, DocumentFile parent) throws Exception {
        if (source.isDirectory()) {
            DocumentFile dir = parent.createDirectory(source.getName());
            if (dir == null) throw new Exception("Falha ao criar pasta " + source.getName());
            File[] children = source.listFiles();
            if (children == null) throw new Exception("Não foi possível ler " + source.getName());
            for (File child : children) copyTreeToSaf(child, dir);
        } else {
            DocumentFile output = parent.createFile("application/octet-stream", source.getName());
            if (output == null) throw new Exception("Falha ao criar arquivo " + source.getName());
            InputStream rawIn = new FileInputStream(source);
            OutputStream rawOut = getContentResolver().openOutputStream(output.getUri(), "w");
            if (rawOut == null) throw new Exception("Não foi possível gravar " + source.getName());
            try (InputStream in = new BufferedInputStream(rawIn, 1024 * 1024);
                 OutputStream out = new BufferedOutputStream(rawOut, 1024 * 1024)) {
                copyStream(in, out);
            }
        }
    }

    private static void deleteRecursively(File file) {
        if (file == null || !file.exists()) return;
        File[] children = file.listFiles();
        if (children != null) for (File child : children) deleteRecursively(child);
        try { file.delete(); } catch (Exception ignored) { }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidBridge");
            webView.destroy();
            webView = null;
        }
        worker.shutdown();
        super.onDestroy();
    }
}
