let toastTimer;
function showToast(message){const toast=document.getElementById('toast');toast.textContent=message;toast.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.classList.remove('show'),2200)}
function openPanel(title,text){document.getElementById('modal-title').textContent=title;document.getElementById('modal-text').textContent=text;document.getElementById('modal').classList.add('show')}
function closePanel(event){if(!event||event.target.id==='modal')document.getElementById('modal').classList.remove('show')}
function showPage(pageId,navId){document.querySelectorAll('.page').forEach(page=>page.classList.remove('active-page'));document.getElementById(pageId).classList.add('active-page');document.querySelectorAll('.nav-item').forEach(item=>item.classList.remove('active'));document.getElementById(navId).classList.add('active');window.scrollTo({top:0,behavior:'smooth'})}
