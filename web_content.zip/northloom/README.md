# Northloom — Freelance Studio Website Template

A premium, dark, one-page portfolio site for a freelance designer/developer.
Built with plain HTML, CSS and JavaScript — no frameworks, no build step,
nothing to install.

## What's inside

```
northloom/
├── index.html    → the whole page (semantic HTML)
├── styles.css    → all styling (dark theme, responsive, animations)
└── script.js     → nav, sliders, counters, form validation, IST clock
```

## Run it locally

Just open `index.html` in your browser. For the proper experience (fonts,
form, etc.) serve it instead of double-clicking:

```bash
cd northloom
python3 -m http.server 8000
# then visit http://localhost:8000
```

Or use VS Code → "Live Server" extension.

> Fonts load from Google Fonts (Fraunces + Inter), so the first visit needs
> an internet connection. Everything else works fully offline.

## Make it yours — checklist

The site currently contains **sample content** (fictional projects, numbers,
testimonials). Replace it with your real details before going live:

**1. Identity**
- `index.html` → replace "Northloom" (logo text, `<title>`, footer, email)
- Search for `hello@northloom.studio` and put your real address everywhere

**2. Proof & numbers**
- Projects in the Work section (names, results, SVG covers)
- Stats in the hero (47 projects / 31 clients / 4 weeks)
- Testimonials — real quotes from real clients
- The About section — your actual story; swap the SVG portrait for a photo

**3. Pricing**
- Service prices are realistic Indian freelance rates (₹75k–₹2.5L+).
  Set your own; honest ranges filter out bad-fit clients.

**4. Contact form**
- The form is a front-end demo — it validates but doesn't send yet.
  Wire it up in `script.js` (search for "DEMO ONLY"): Formspree, Web3Forms
  or Netlify Forms all work in minutes, no backend needed.

**5. Go live**
- Free hosting: Netlify Drop (drag & drop the folder) or GitHub Pages.
  Buy a domain (~₹800/yr) and point it at your host.

## Features already built in

- Responsive (desktop / tablet / phone) with a mobile menu
- Scroll-reveal animations + animated number counters
- Testimonial slider with autoplay, pause-on-hover and keyboard support
- FAQ accordion (only one open at a time)
- Live IST clock in the footer
- Accessible: semantic HTML, aria labels, focus states, reduced-motion support
- Works without JS (content stays visible, noscript fallback included)
- SEO basics: meta description, Open Graph tags, semantic headings

## License

Free to use and modify for your own business. The sample content
(names, projects, testimonials) is fictional — replace it with the truth.
