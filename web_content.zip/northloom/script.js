/* ═══════════════════════════════════════════════════════════
   NORTHLOOM — script.js
   Vanilla JS, no dependencies. Comments left in on purpose —
   future-me will thank present-me.
   ═══════════════════════════════════════════════════════════ */

(function () {
  "use strict";

  var $  = function (s, ctx) { return (ctx || document).querySelector(s); };
  var $$ = function (s, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(s)); };

  /* ── sticky nav ───────────────────────────────────────── */
  var nav = $("#nav");

  function onScroll() {
    if (!nav) return;
    nav.classList.toggle("scrolled", window.scrollY > 24);
  }
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  /* ── mobile menu ──────────────────────────────────────── */
  var burger    = $("#burger");
  var navLinks  = $("#navLinks");

  if (burger && navLinks) {
    burger.addEventListener("click", function () {
      var open = navLinks.classList.toggle("open");
      burger.classList.toggle("open", open);
      burger.setAttribute("aria-expanded", String(open));
      burger.setAttribute("aria-label", open ? "Close menu" : "Open menu");
      document.body.style.overflow = open ? "hidden" : "";
    });

    // close after tapping a link
    $$(".nav-links a").forEach(function (a) {
      a.addEventListener("click", function () {
        navLinks.classList.remove("open");
        burger.classList.remove("open");
        document.body.style.overflow = "";
      });
    });
  }

  /* ── scroll reveal ─────────────────────────────────────── */
  var reveals = $$(".reveal");

  if ("IntersectionObserver" in window && reveals.length) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });

    reveals.forEach(function (el, i) {
      // slight stagger between siblings so groups don't pop in unison
      el.style.transitionDelay = (i % 4) * 70 + "ms";
      io.observe(el);
    });
  } else {
    reveals.forEach(function (el) { el.classList.add("visible"); });
  }

  /* ── animated counters in hero ─────────────────────────── */
  function animateCount(el) {
    var target = parseInt(el.getAttribute("data-count"), 10) || 0;
    var dur = 1400;
    var t0 = null;

    function tick(t) {
      if (!t0) t0 = t;
      var p = Math.min((t - t0) / dur, 1);
      // ease-out cubic
      var eased = 1 - Math.pow(1 - p, 3);
      el.textContent = Math.round(eased * target);
      if (p < 1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }

  var counters = $$("[data-count]");
  if ("IntersectionObserver" in window && counters.length) {
    var cio = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          animateCount(entry.target);
          cio.unobserve(entry.target);
        }
      });
    }, { threshold: 0.6 });
    counters.forEach(function (el) { cio.observe(el); });
  } else {
    counters.forEach(function (el) {
      el.textContent = el.getAttribute("data-count");
    });
  }

  /* ── testimonial slider ───────────────────────────────── */
  var track = $("#tTrack");
  var slides = track ? $$(".t-slide", track) : [];
  var dotsWrap = $("#tDots");

  if (track && slides.length && dotsWrap) {
    slides.forEach(function (_, i) {
      var dot = document.createElement("button");
      dot.className = "t-dot" + (i === 0 ? " active" : "");
      dot.setAttribute("aria-label", "Go to testimonial " + (i + 1));
      dot.addEventListener("click", function () { goTo(i); });
      dotsWrap.appendChild(dot);
    });

    var dots = $$(".t-dot", dotsWrap);

    function goTo(i) {
      track.scrollTo({ left: slides[i].offsetLeft - track.offsetLeft, behavior: "smooth" });
    }

    function current() {
      var idx = 0, best = Infinity;
      slides.forEach(function (s, i) {
        var d = Math.abs(s.getBoundingClientRect().left - track.getBoundingClientRect().left);
        if (d < best) { best = d; idx = i; }
      });
      return idx;
    }

    function setDots() {
      var c = current();
      dots.forEach(function (d, i) { d.classList.toggle("active", i === c); });
    }

    $("#tPrev").addEventListener("click", function () {
      goTo((current() - 1 + slides.length) % slides.length);
    });
    $("#tNext").addEventListener("click", function () {
      goTo((current() + 1) % slides.length);
    });

    // keyboard support + sync dots on scroll
    track.addEventListener("scroll", setDots, { passive: true });
    setDots();

    // gentle autoplay, pauses on hover/focus/touch
    var timer = null;
    function start() {
      stop();
      timer = setInterval(function () {
        goTo((current() + 1) % slides.length);
      }, 6500);
    }
    function stop() { if (timer) { clearInterval(timer); timer = null; } }

    var slider = $("#tSlider");
    slider.addEventListener("mouseenter", stop);
    slider.addEventListener("mouseleave", start);
    slider.addEventListener("touchstart", stop, { passive: true });
    slider.addEventListener("focusin", stop);

    // only autoplay when actually visible on screen
    if ("IntersectionObserver" in window) {
      new IntersectionObserver(function (entries) {
        entries.forEach(function (e) { e.isIntersecting ? start() : stop(); });
      }, { threshold: 0.4 }).observe(slider);
    } else {
      start();
    }
  }

  /* ── single-open FAQ (details elements fight you on this) ── */
  var faqs = $$(".faq-item");
  faqs.forEach(function (item) {
    item.addEventListener("toggle", function () {
      if (item.open) {
        faqs.forEach(function (other) {
          if (other !== item) other.open = false;
        });
      }
    });
  });

  /* ── contact form (front-end demo) ────────────────────── */
  var form = $("#contactForm");
  var toast = $("#toast");
  var toastTimer = null;

  function showToast(msg) {
    if (!toast) return;
    toast.textContent = msg;
    toast.hidden = false;
    // next frame so the transition actually fires
    requestAnimationFrame(function () {
      requestAnimationFrame(function () { toast.classList.add("show"); });
    });
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () {
      toast.classList.remove("show");
      setTimeout(function () { toast.hidden = true; }, 400);
    }, 4200);
  }

  if (form) {
    form.addEventListener("submit", function (e) {
      e.preventDefault();

      var name = $("#f-name").value.trim();
      var email = $("#f-email").value.trim();
      var budget = $("#f-budget").value;
      var msg = $("#f-msg").value.trim();
      var errBox = $("#formError");
      var problems = [];

      if (name.length < 2) problems.push("your name");
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) problems.push("a valid email");
      if (!budget) problems.push("a budget range");
      if (msg.length < 10) problems.push("a sentence about the project");

      if (problems.length) {
        errBox.textContent = "Please add " + problems.join(", ") + ".";
        errBox.hidden = false;
        return;
      }

      errBox.hidden = true;

      var btn = $("#submitBtn");
      btn.disabled = true;
      btn.textContent = "Sending…";

      /* DEMO ONLY — connect your backend / Formspree / Web3Forms here.
         Replace the setTimeout with a fetch() POST in production, e.g.:

         fetch("https://formspree.io/f/yourformid", {
           method: "POST",
           headers: { "Accept": "application/json" },
           body: new FormData(form)
         }).then(...)
      */
      setTimeout(function () {
        form.reset();
        btn.disabled = false;
        btn.innerHTML = "Send enquiry&nbsp;&nbsp;→";
        showToast("Thanks " + name.split(" ")[0] + " — got it. I'll reply within 24 hours.");
      }, 900);
    });
  }

  /* ── footer clock (IST, updates every second) ──────────── */
  var clock = $("#clock");
  if (clock) {
    var fmt = new Intl.DateTimeFormat("en-IN", {
      hour: "2-digit", minute: "2-digit", second: "2-digit",
      hour12: false, timeZone: "Asia/Kolkata"
    });
    function tickClock() { clock.textContent = fmt.format(new Date()); }
    tickClock();
    setInterval(tickClock, 1000);
  }

  /* ── footer year ──────────────────────────────────────── */
  var year = $("#year");
  if (year) year.textContent = String(new Date().getFullYear());

  /* ── for the curious ──────────────────────────────────── */
  console.log(
    "%cNorthloom %c— peeking at the source? Good instinct. \n" +
    "If you're reading this, you probably care about craft — we should talk. \n" +
    "hello@northloom.studio",
    "font-family:Georgia,serif;font-size:16px;color:#c9a86a",
    "color:#8a8782;font-size:12px"
  );
})();
