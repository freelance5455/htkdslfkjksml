# CyberNexus — Netlify version

Այս նախագիծը նախատեսված է Netlify-ում տեղադրելու համար և չի պահանջում GitHub։

## Կառուցվածքը
- `index.html` — CyberNexus UI
- `netlify/functions/api.mjs` — login/register/users/messages/profile backend
- `netlify/functions/lib.mjs` — password hashing, sessions, storage helpers
- `netlify.toml` — Functions + `/api/*` routing
- `package.json` — Netlify Blobs dependency

## Կարևոր
Այս տարբերակը օգտագործում է Netlify Blobs-ը, որպեսզի նույն տվյալները հասանելի լինեն տարբեր սարքերից։ Password-ը plain text-ով չի պահվում․ backend-ը պահում է PBKDF2 hash + salt, իսկ session-ը HttpOnly cookie-ով։

Սա լավ MVP է, բայց production-ի համար պետք է ավելացնել rate limiting, email/password recovery, moderation/reporting, pagination, image processing և ավելի խիստ abuse protection։


IMPORTANT DEPLOY:
Netlify Dashboard -> Add new project -> Deploy manually.
Upload the UNZIPPED project folder while logged in. Because this project has a build step,
Netlify must run `npm install` so the Functions can package @netlify/blobs.
After deployment, open /api/health on the site. It should return {"ok":true,"service":"CyberNexus API"}.


REAL-TIME NOTE:
The client now polls the open conversation about every 1.2 seconds while the page is visible, so messages should appear almost immediately without a manual refresh. This is near-real-time polling, not a persistent WebSocket connection.
