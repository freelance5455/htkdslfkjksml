import { json, body, userStore, sessionStore, messageStore, normalizeUser, validUser, hashPassword, checkPassword, token, sessionCookie, clearCookie, currentUser, publicUser, pair } from "./lib.mjs";

const okMethods=(req,methods)=>methods.includes(req.method);

export default async req=>{
  const url=new URL(req.url), path=url.pathname.replace(/^\/api\/?/,"").replace(/\/$/,"");

  if(path==="register" && req.method==="POST"){
    const b=await body(req), username=normalizeUser(b.username), password=String(b.password||"");
    if(!validUser(username))return json({error:"Սխալ username"},400);
    if(password.length<10)return json({error:"Գաղտնաբառը պետք է ունենա առնվազն 10 նիշ"},400);
    if(password!==String(b.confirm||""))return json({error:"Գաղտնաբառերը չեն համընկնում"},400);
    if(await userStore().get(username,{type:"json"}))return json({error:"Այս username-ը արդեն օգտագործվում է"},409);
    const hp=hashPassword(password);
    await userStore().setJSON(username,{username,salt:hp.salt,hash:hp.hash,photo:"",created:Date.now()});
    const t=token();await sessionStore().setJSON(t,{username,created:Date.now()});
    return json({user:{username,photo:""}},201,{"set-cookie":sessionCookie(t)});
  }

  if(path==="login" && req.method==="POST"){
    const b=await body(req),username=normalizeUser(b.username),u=await userStore().get(username,{type:"json"});
    if(!u||!checkPassword(String(b.password||""),u.salt,u.hash))return json({error:"Սխալ username կամ գաղտնաբառ"},401);
    const t=token();await sessionStore().setJSON(t,{username,created:Date.now()});
    return json({user:publicUser(u)},200,{"set-cookie":sessionCookie(t)});
  }

  if(path==="logout" && req.method==="POST"){
    const c=(req.headers.get("cookie")||"").match(/(?:^|;\s*)cn_session=([^;]+)/);
    if(c)await sessionStore().delete(decodeURIComponent(c[1]));
    return json({ok:true},200,{"set-cookie":clearCookie()});
  }

  const u=await currentUser(req);
  if(!u)return json({error:"Մուտք գործիր հաշիվ"},401);

  if(path==="me" && req.method==="GET")return json({user:publicUser(u)});

  if(path==="users" && req.method==="GET"){
    const q=String(url.searchParams.get("q")||"").toLowerCase();
    const {blobs=[]}=await userStore().list({includeMetadata:false});
    const users=[];
    for(const x of blobs){
      if(x.key===u.username)continue;
      if(q && !x.key.toLowerCase().includes(q))continue;
      const v=await userStore().get(x.key,{type:"json"});
      if(v)users.push(publicUser(v));
      if(users.length>=50)break;
    }
    return json({users});
  }

  if(path==="messages" && req.method==="GET"){
    const other=normalizeUser(url.searchParams.get("with"));
    if(!validUser(other)||other===u.username)return json({error:"Սխալ օգտատեր"},400);
    const {blobs=[]}=await messageStore().list({prefix:pair(u.username,other)+"/"});
    const messages=[];
    for(const x of blobs){const v=await messageStore().get(x.key,{type:"json"});if(v)messages.push(v)}
    messages.sort((a,b)=>a.ts-b.ts);
    return json({user:publicUser(await userStore().get(other,{type:"json"})||{username:other}),messages:messages.slice(-500)});
  }

  if(path==="messages" && req.method==="POST"){
    const b=await body(req),to=normalizeUser(b.to),text=String(b.text||"").trim();
    if(!validUser(to)||to===u.username)return json({error:"Սխալ ստացող"},400);
    if(text.length<1||text.length>4000)return json({error:"Հաղորդագրությունը պետք է լինի 1–4000 նիշ"},400);
    if(!await userStore().get(to,{type:"json"}))return json({error:"Օգտատերը չի գտնվել"},404);
    const msg={from:u.username,to,text,ts:Date.now()};
    const k=pair(u.username,to)+"/"+msg.ts+"-"+token().slice(0,8);
    await messageStore().setJSON(k,msg);
    return json({message:msg},201);
  }

  if(path==="profile" && req.method==="POST"){
    const b=await body(req),nn=normalizeUser(b.username||u.username),np=b.password?String(b.password):"";
    if(!validUser(nn))return json({error:"Սխալ username"},400);
    if(np&&np.length<10)return json({error:"Գաղտնաբառը պետք է ունենա առնվազն 10 նիշ"},400);
    if(nn!==u.username && await userStore().get(nn,{type:"json"}))return json({error:"Username-ը զբաղված է"},409);
    const updated={...u,username:nn};
    delete updated.hash;delete updated.salt;
    if(np){const hp=hashPassword(np);updated.salt=hp.salt;updated.hash=hp.hash}
    if(typeof b.photo==="string"){
      if(b.photo.length>2_800_000)return json({error:"Նկարը չափազանց մեծ է"},400);
      updated.photo=b.photo;
    }
    await userStore().setJSON(nn,updated);
    if(nn!==u.username){
      await userStore().delete(u.username);
      const {blobs=[]}=await sessionStore().list();
      for(const x of blobs){const s=await sessionStore().get(x.key,{type:"json"});if(s?.username===u.username)await sessionStore().setJSON(x.key,{...s,username:nn})}
    }
    return json({user:publicUser(updated)});
  }

  if(path==="account" && req.method==="DELETE"){
    const {blobs=[]}=await messageStore().list({prefix:""});
    for(const x of blobs){
      const v=await messageStore().get(x.key,{type:"json"});
      if(v?.from===u.username||v?.to===u.username)await messageStore().delete(x.key);
    }
    await userStore().delete(u.username);
    const c=(req.headers.get("cookie")||"").match(/(?:^|;\s*)cn_session=([^;]+)/);
    if(c)await sessionStore().delete(decodeURIComponent(c[1]));
    return json({ok:true},200,{"set-cookie":clearCookie()});
  }

  return json({error:"Not found"},404);
};
