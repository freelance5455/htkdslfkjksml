
import { getStore } from "@netlify/blobs";
import crypto from "node:crypto";

export const json = (data,status=200,headers={}) =>
  new Response(JSON.stringify(data),{status,headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store",...headers}});

export const body = async req => { try{return await req.json()}catch{return {}} };

export const cookies = req => {
  const raw=req.headers.get("cookie")||"", out={};
  for(const p of raw.split(";")){const i=p.indexOf("=");if(i>0)out[p.slice(0,i).trim()]=decodeURIComponent(p.slice(i+1).trim())}
  return out;
};

export const userStore=()=>getStore("cybernexus-users");
export const sessionStore=()=>getStore("cybernexus-sessions");
export const messageStore=()=>getStore("cybernexus-messages");

export function normalizeUser(s){return String(s||"").trim().replace(/\s+/g,"_")}
export function validUser(s){return /^[A-Za-z0-9_.-]{3,24}$/.test(s)}
export function hashPassword(password,salt=crypto.randomBytes(16).toString("hex")){
  return {salt,hash:crypto.pbkdf2Sync(password,salt,210000,32,"sha256").toString("hex")}
}
export function checkPassword(password,salt,hash){
  const h=crypto.pbkdf2Sync(password,salt,210000,32,"sha256").toString("hex");
  return crypto.timingSafeEqual(Buffer.from(h),Buffer.from(hash));
}
export function token(){return crypto.randomBytes(32).toString("hex")}
export function sessionCookie(t){return `cn_session=${encodeURIComponent(t)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=2592000`}
export function clearCookie(){return "cn_session=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0"}
export async function currentUser(req){
  const t=cookies(req).cn_session;if(!t)return null;
  const s=await sessionStore().get(t,{type:"json"});if(!s)return null;
  const u=await userStore().get(s.username,{type:"json"});return u?{...u,username:s.username}:null;
}
export function publicUser(u){return {username:u.username,photo:u.photo||""}}
export function pair(a,b){return [a,b].sort().join("::")}
