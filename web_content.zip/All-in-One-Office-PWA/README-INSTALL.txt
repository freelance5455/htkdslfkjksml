ALL-IN-ONE OFFICE — INSTALLABLE WEB APP PACKAGE

This package prepares All-in-One Office as a Progressive Web App (PWA). It is not a signed APK.
A PWA can be installed from Chrome after the files are hosted on HTTPS.

FILES
- index.html: the office app
- manifest.webmanifest: install metadata and app name
- sw.js: service worker for caching the app shell
- icons/: app icons

FREE ANDROID INSTALL STEPS
1. Extract this ZIP on your phone or computer.
2. Host the files on an HTTPS static host. A free option is GitHub Pages:
   a. Sign in/create a GitHub account.
   b. Create a new public repository named all-in-one-office.
   c. Upload index.html, manifest.webmanifest, sw.js, and the icons folder (keep paths unchanged).
   d. In repository Settings > Pages, enable deployment from the main branch and /(root).
   e. Wait for GitHub Pages to publish the site and open the generated HTTPS URL.
3. On Android, open the URL in Chrome.
4. Tap Chrome menu (⋮) > Install app, or Add to Home screen, then confirm.
5. Launch All-in-One Office from the new home-screen icon.

IMPORTANT
- PWA installation requires HTTPS hosting; opening index.html directly from Downloads will not provide the full install flow.
- The app shell is cached after the first visit, but office format libraries are loaded from a CDN and may need internet.
- This is not a native APK. Creating a signed APK needs a separate Android wrapper/build and testing step.
- PPTX import/editing is not included in this prototype. PPTX creation/export is included when its library loads.
- Keep confidential or regulated documents out of this prototype until approved security review.
