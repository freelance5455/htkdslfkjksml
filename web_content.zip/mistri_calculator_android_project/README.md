# Mistri Calculator Pro Android project (v1.7)

This project wraps the existing app in an Android WebView and uses the supplied Mistri Calculator Pro logo as the launcher icon.

## Build an APK in Android Studio
1. Install Android Studio and Android SDK (API 35 platform; a recent Android Gradle Plugin-compatible JDK).
2. Extract this ZIP.
3. Android Studio → Open → select `mistri_calculator_android_project`.
4. Allow Gradle sync/downloads.
5. Build → Build Bundle(s) / APK(s) → Build APK(s).
6. APK output is usually `app/build/outputs/apk/debug/app-debug.apk`.

This workspace does not contain Android SDK/Gradle build tools, so an APK could not be compiled here. The source project is prepared for Android Studio.
