package com.titlibanaras.privateapp;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.content.SharedPreferences;

public class MainActivity extends Activity {
    private static final String PREFS = "private_access";
    private static final String KEY = "unlocked";
    private static final String PIN = "1890";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY, false)) {
            showSite();
        } else {
            showLock();
        }
    }

    private void showLock() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(50, 50, 50, 50);

        TextView title = new TextView(this);
        title.setText("Titli Banaras\nPRIVATE");
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER);
        title.setTextColor(Color.BLACK);
        box.addView(title);

        EditText pin = new EditText(this);
        pin.setHint("Enter PIN");
        pin.setInputType(2);
        box.addView(pin);

        Button unlock = new Button(this);
        unlock.setText("UNLOCK");
        box.addView(unlock);

        TextView error = new TextView(this);
        error.setText("");
        error.setGravity(Gravity.CENTER);
        box.addView(error);

        unlock.setOnClickListener(v -> {
            if (PIN.equals(pin.getText().toString())) {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY, true).apply();
                showSite();
            } else {
                error.setText("Incorrect PIN");
            }
        });
        setContentView(box);
    }

    private void showSite() {
        WebView web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        web.setWebViewClient(new WebViewClient());
        web.setLongClickable(false);
        web.setHapticFeedbackEnabled(false);
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }
}