# Titli Banaras Private App
Android Studio project generated from titli_banaras_1890.html.

Private access PIN in MainActivity.java: 1890

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).

Note: the app includes basic access control and disables WebView file/content access. No app can guarantee that screenshots or photos cannot be copied from a device.
