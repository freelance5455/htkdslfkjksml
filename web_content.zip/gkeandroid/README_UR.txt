گلاب خان الیکٹرونکس — Android Studio project

یہ Android ایپ کا سورس پروجیکٹ ہے، تیار شدہ APK نہیں۔ اس ماحول میں Android SDK/Gradle build tools موجود نہیں، اس لیے یہاں سے APK compile یا sign نہیں کی گئی۔

APK بنانے کا طریقہ:
1) کمپیوٹر پر Android Studio انسٹال کریں۔
2) Android Studio میں Open منتخب کرکے اس فولڈر کو کھولیں جس میں settings.gradle موجود ہے۔
3) Gradle sync مکمل ہونے دیں اور Android SDK Platform 35 انسٹال کریں اگر پوچھا جائے۔
4) Build > Build Bundle(s) / APK(s) > Build APK(s) منتخب کریں۔
5) APK عموماً app/build/outputs/apk/debug/app-debug.apk میں بنے گی۔ اسے صرف اپنے قابل اعتماد ڈیوائس پر انسٹال کریں۔

اہم:
- ریکارڈ اسی فون کی ایپ میں محفوظ رہتا ہے؛ دوسرے فون یا کمپیوٹر سے خودکار sync نہیں ہے۔
- فون بدلنے یا ایپ حذف کرنے سے پہلے بیک اپ بنائیں اور محفوظ کریں۔
- پہلے فرضی گاہکوں کے ساتھ آزمائیں؛ یہ ابتدائی ورژن ہے، ابھی آزادانہ سیکیورٹی آڈٹ نہیں ہوا۔
