plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Назва пакета гри, яку запускає кнопка "Грати".
// Змініть на справжню назву пакета встановленої гри (одне місце на весь проєкт).
val gamePackage = "com.example.game"

android {
    namespace = "com.bearlyvisuals.launcher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.bearlyvisuals.launcher"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1"
        manifestPlaceholders["gamePackage"] = gamePackage
        buildConfigField("String", "GAME_PACKAGE", "\"$gamePackage\"")
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
}
