# Change log

## v1.1.0 — 31 October 2026

User-approved transition to a **new experimental version**, while preserving the v1.0 baseline.

- UNCHANGED: all Life Path and Personal Year/Month/Day calculations, master-number conventions and archetype vectors.
- NEW: directional transitions that distinguish losing existing traits from gaining new demands.
- NEW: multiplicative whole-chain bottleneck gate.
- NEW: opponent-relative expression weighted by the opponent Life Path.
- NEW: combined 65% internally gated chain + 35% direct opponent interaction.
- UNCHANGED: nominal five-point verdict abstention threshold and edge-tier cutoffs.
- NEW: 132+4,972 test assertions and Python/JavaScript parity checks across 253 matches.
- RESET: empty prospective evaluation ledger. No known results were used to fit v1.1 parameters.

This is experimental, symbolic, and not an established accurate way to forecast sports winners.
