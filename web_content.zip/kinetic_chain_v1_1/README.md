# Kinetic-Chain Sports Numerology Engine v1.1.0

**Active experimental engine**. Deterministic, sports-only and numerology-only. No empirically established ability to predict winners.

## Quick use

1. Open `Kinetic_Chain_Engine_v1_1.html` in a modern browser. It works offline and has no external dependencies.
2. Enter match date, each name, each date of birth, then choose **Calculate v1.1**.
3. Before the match begins, choose **Lock prediction**. After the match, record the winner separately in the local log.
4. Export JSON regularly: local browser storage may be lost or cleared.

Alternatively, run Python 3.9+ with no third-party dependencies:

```bash
python engine_v1_1.py --test
python engine_v1_1.py --date 2026-11-01 --a-name A --a-dob 2001-08-15 --b-name B --b-dob 2003-06-22
```

- `RULEBOOK_v1_1.md`: full v1.1.0 frozen numerological definitions and evaluation protocol
- `rules_v1_1.json`: machine-readable version specification
- `engine_v1_1.py`: authoritative deterministic Python reference engine, with tests
- `baseline_v1/`: *unaltered* original v1.0.0 Python implementation, rules and historical regression data
- `prospective_ledger_v1_1.json`: fresh **empty** test ledger; does not contain outcomes or known matches
- `Kinetic_Chain_Engine_v1_1.html`: standalone offline interface and local log

### Important

The first 20-match v1.0 test is a closed, separate archive. The 21st match was outside that test. Prior results should **not** be recounted as validation of v1.1.

The existing data have a striking sampling issue: all 21 reported winners were listed first. Future test matches must be entered with randomized or blinded competitor order, without the outcome known at prediction time.

Frozen v1.1.0 is our chosen experimental *hypothesis*, not an evidence-backed accuracy improvement. Do not adjust the formula during the prospective evaluation.
