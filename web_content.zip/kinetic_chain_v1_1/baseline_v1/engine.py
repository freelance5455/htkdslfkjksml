"""Kinetic-Chain Sports Numerology Engine v1.0.0.

A deterministic *symbolic* model, NOT an empirically validated sports forecasting method.
Rule weights and profiles are frozen in rules_v1.json.
"""
from __future__ import annotations
from datetime import date
from pathlib import Path
import json, hashlib, argparse

BASE = Path(__file__).resolve().parent
RULES = json.loads((BASE / 'rules_v1.json').read_text(encoding='utf-8'))


def reduce_root(n: int) -> int:
    if n < 0:
        raise ValueError('number cannot be negative')
    while n > 9:
        n = sum(int(d) for d in str(n))
    return n


def reduce_master(n: int) -> int:
    if n < 0:
        raise ValueError('number cannot be negative')
    while n > 9 and n not in (11, 22, 33):
        n = sum(int(d) for d in str(n))
    return n


def lp_root(lp: int) -> int:
    return reduce_root(lp)


def life_path(dob: date) -> tuple[int, str, dict]:
    raw_digit_sum = sum(map(int, dob.strftime('%d%m%Y')))
    raw_path = reduce_master(raw_digit_sum)
    day_component = reduce_master(dob.day)
    month_component = reduce_master(dob.month)
    year_component = reduce_master(sum(map(int, str(dob.year))))
    component_sum = day_component + month_component + year_component
    component_path = reduce_master(component_sum)
    if raw_path in (11, 22, 33):
        result, rule = raw_path, 'raw-digit master precedence'
    elif component_path in (11, 22, 33):
        result, rule = component_path, 'component-preserved master precedence'
    else:
        result, rule = reduce_root(raw_digit_sum), 'raw-digit root'
    return result, rule, dict(raw_digit_sum=raw_digit_sum, raw_path=raw_path,
                              component_sum=component_sum, component_path=component_path,
                              day_component=day_component, month_component=month_component,
                              year_component=year_component)


def chain(dob: date, match: date) -> dict:
    lp, master_rule, detail = life_path(dob)
    uy = reduce_root(sum(map(int, str(match.year))))
    py = reduce_root(reduce_root(dob.day) + reduce_root(dob.month) + uy)
    pm = reduce_root(py + reduce_root(match.month))
    pd = reduce_root(pm + reduce_root(match.day))
    return {
        'life_path': lp, 'life_path_label': f'{lp}/{lp_root(lp)}' if lp in (11, 22, 33) else str(lp),
        'life_path_root': lp_root(lp), 'personal_year': py, 'personal_month': pm, 'personal_day': pd,
        'chain': [lp, py, pm, pd], 'master_rule': master_rule, 'life_path_audit': detail,
        'universal_year': uy, 'match_month_root': reduce_root(match.month),
        'match_day_root': reduce_root(match.day)
    }


def affinity(a: int, b: int) -> int:
    pa = RULES['profiles'][str(lp_root(a))]
    pb = RULES['profiles'][str(lp_root(b))]
    dist = sum(abs(x-y) for x, y in zip(pa, pb))
    return 100 - ((100*dist + 7)//14)


def tier(s: int) -> str:
    for t in RULES['affinity_tiers']:
        if s >= t['min']:
            return t['label']
    raise AssertionError


def score(ch: list[int]) -> dict:
    lp, py, pm, pd = ch
    e1, e2, e3 = affinity(lp, py), affinity(py, pm), affinity(pm, pd)
    fit = affinity(lp, pd)
    bottleneck = min(e1, e2, e3)
    w = RULES['score_weights_percent']
    centipoints = e1*w['life_path_to_year'] + e2*w['year_to_month'] + e3*w['month_to_day'] + fit*w['life_path_to_day'] + bottleneck*w['weakest_adjacent_link']
    steps = [
        {'from': str(lp), 'to': py, 'affinity': e1, 'tier': tier(e1), 'stage': 'Core → activation'},
        {'from': str(py), 'to': pm, 'affinity': e2, 'tier': tier(e2), 'stage': 'Activation → conversion'},
        {'from': str(pm), 'to': pd, 'affinity': e3, 'tier': tier(e3), 'stage': 'Conversion → final expression'},
    ]
    return {'steps': steps, 'life_path_to_day_affinity': fit, 'life_path_to_day_tier': tier(fit),
            'weakest_affinity': bottleneck, 'weakest_stage': steps[next(i for i, x in enumerate((e1,e2,e3)) if x == bottleneck)]['stage'],
            'score_centipoints': centipoints, 'score': centipoints / 100}


def compare(a: dict, b: dict, when: date) -> dict:
    ca, cb = chain(date.fromisoformat(a['dob']), when), chain(date.fromisoformat(b['dob']), when)
    sa, sb = score(ca['chain']), score(cb['chain'])
    diff = abs(sa['score_centipoints'] - sb['score_centipoints'])
    edge = next(t['label'] for t in RULES['verdict_score_difference_thresholds'] if diff >= t['min_centipoints'])
    verdict = None if edge == 'no decisive edge' else a['name'] if sa['score_centipoints'] > sb['score_centipoints'] else b['name']
    return {'engine': RULES['version'], 'date': when.isoformat(), 'a': {'name': a['name'], 'dob': a['dob'], 'numbers': ca, 'metrics': sa},
            'b': {'name': b['name'], 'dob': b['dob'], 'numbers': cb, 'metrics': sb},
            'verdict': verdict, 'edge': edge, 'score_difference': diff / 100,
            'method_note': 'Symbolic edge, not empirical probability.'}


def run_checks() -> dict:
    examples = json.loads((BASE/'history.json').read_text())
    cases = 0
    for entry in examples:
        match = date.fromisoformat(entry['date'])
        for side in ('a','b'):
            p = entry[side]
            got = chain(date.fromisoformat(p['dob']), match)['chain']
            assert got == p['chain'], f"Unexpected chain for {p['name']}: {got} != {p['chain']}"
            cases += 1
        first = compare(entry['a'], entry['b'], match)
        second = compare(entry['a'], entry['b'], match)
        assert first == second, f"Nondeterministic result in {entry['a']['name']} / {entry['b']['name']}"
        swapped = compare(entry['b'], entry['a'], match)
        assert first['a']['metrics']['score_centipoints'] == swapped['b']['metrics']['score_centipoints']
        assert first['b']['metrics']['score_centipoints'] == swapped['a']['metrics']['score_centipoints']
        assert first['edge'] == swapped['edge']
        cases += 3
    assert sum(RULES['score_weights_percent'].values()) == 100
    assert sorted(RULES['profiles']) == list('123456789')
    for x in range(1,10):
        assert affinity(x, x) == 100
        for y in range(1,10):
            assert affinity(x,y) == affinity(y,x)
            assert 0 <= affinity(x,y) <= 100
    cases += 82
    return {'status': 'PASS', 'test_assertions': cases, 'historical_matchups': len(examples),
            'historical_person_calculations_verified': 2*len(examples)}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Deterministic symbolic numerology matchup engine')
    parser.add_argument('--test', action='store_true')
    parser.add_argument('--date')
    parser.add_argument('--a-name')
    parser.add_argument('--a-dob')
    parser.add_argument('--b-name')
    parser.add_argument('--b-dob')
    args = parser.parse_args()
    if args.test:
        print(json.dumps(run_checks(), indent=2))
    elif args.date and args.a_name and args.a_dob and args.b_name and args.b_dob:
        print(json.dumps(compare({'name': args.a_name, 'dob': args.a_dob}, {'name': args.b_name, 'dob': args.b_dob}, date.fromisoformat(args.date)), indent=2))
    else:
        parser.print_help()
