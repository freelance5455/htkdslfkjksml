"""Unchanged frozen v1.0.0 calculation baseline."""
