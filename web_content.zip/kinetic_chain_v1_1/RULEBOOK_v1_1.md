# Kinetic-Chain Sports Numerology — v1.1.0

**Status:** ACTIVE experimental version, rules frozen for the next prospective evaluation.  
**Approved by user:** 31 October 2026.  
**Scope:** sports matchups **only**, numerical Life Path / Personal Year / Personal Month / Personal Day **only**. No player statistics, odds, form, rankings, injuries, sports-specific factors or external data. This is a symbolic hypothesis, not a scientifically validated forecasting system.

## Versioning and untouched baseline

v1.0.0, its original archived reference engine and its closed first 20-match ledger remain frozen and unchanged. In its complete 20-result sample it selected 11 winners, correctly identified 5 and incorrectly identified 6; 9 were abstentions. Matchup 21 (Karl–Zahraj) was an unchanged-v1.0 additional abstention, not part of the closed 20.

The first 21 user-reported winners all appeared in the first competitor position. This reveals an ordering/selection bias in the available evaluation sample; the new rules have **not** been fitted to the known winners, and retrospective apparent performance is not validation. All rules below are declared before use on a fresh test set and are maintained unchanged within v1.1.0.

## 1 — Core Life Path and personal-cycle calculations (UNCHANGED)

The v1.0.0 custom **dual-path** master-number Life Path convention is used exactly as implemented in the archived Python engine. The raw-digit route has master-number precedence, then the component-preserved route, then raw root. Life Path masters 11/22/33 are displayed as e.g. 22/4, but affinity calculations use root 2/4/6 without a bonus.

Let `root(n)` repeatedly sum the digits until 1–9.

- Universal Year UY = root(sum of match-year digits)
- Personal Year PY = root(root(birth day) + root(birth month) + UY)
- Personal Month PM = root(PY + root(match month))
- Personal Day PD = root(PM + root(match day))

Life Path (LP) is the **Core Engine**; PY is **Activation**; PM is **Conversion**; PD is the **Final Weapon**. The 7-axis symbolic vectors for each root 1–9 are retained *unchanged* from v1.0.0, in this order:

`[initiative, structure, adaptability, analysis, connection, expression, completion]`.

No result or athlete history determines the vector values.

## 2 — Directional chain transitions (NEW)

v1.0 used symmetric vector similarity: affinity(X,Y) = affinity(Y,X). This ignores the direction of the Kinetic-Chain. v1.1 distinguishes moving from an established stage to a new stage.

For the source profile `S` and target profile `T`, on each of the seven axes calculate:

- `lost = sum(max(S[i] − T[i], 0))` (capabilities present at the earlier stage that are less present at the next)
- `gained = sum(max(T[i] − S[i], 0))` (new demands introduced at the next stage)
- `directional(S,T) = 100 − floor((100 × (2×lost + gained) + 14)/28)`

This intentionally charges twice the symbolic conversion cost for losing an already expressed axis versus introducing a new one. It is a *proposed design assumption*, not an empirical finding. The measure is integer 0–100. Reversing a transition can change its score. Same source and target scores 100.

Calculate `A=T(LP,PY)`, `B=T(PY,PM)`, `C=T(PM,PD)`, `D=T(LP,PD)` and `E=min(A,B,C)`.

## 3 — Whole-chain bottleneck gate (NEW)

Preserve v1.0's stage-weight priorities for interpretability:

`weighted = .20×A + .20×B + .25×C + .25×D + .10×E`

But do not permit an excellent first or last link to fully compensate for an interrupted chain. Multiply the weighted score by the gate:

`gate = 0.60 + 0.40×E/100`  
`internal = weighted × gate`

The gate lies 0.60–1.00 and is based on the weakest actual adjacent conversion step. This makes a bottleneck affect the *entire* chain.

## 4 — Opponent-specific final-day expression (NEW)

v1.0 scored both competitors independently; the same individual chain always received the same score, regardless of opponent. In v1.1, compare the competitor's Personal Day vector to the opponent's Personal Day vector, in seven axes weighted by the **opponent's Life Path**.

For competitor A against competitor B:

- `w[i] = 1 + profile(LP_B)[i]` (strictly positive symbolic relevance of each axis to opponent's core)
- `delta = sum(w[i] × (profile(PD_A)[i] − profile(PD_B)[i]))`
- `W = sum(w[i])`
- `weapon_A = 50 + 25×delta/W`

Similarly, `weapon_B` uses A's Life Path to weight differences between B's and A's Personal Day profiles. `weapon` is a bounded score 0–100. Identical Personal Days yield exactly 50 for each opponent. This *does not* represent actual dominance or head-to-head athletic advantage; it is a versioned, symbolic opponent-relative construction.

## 5 — Final symbolic score and official verdict (NEW)

`final_A = 0.65×internal_A + 0.35×weapon_A`  
`final_B = 0.65×internal_B + 0.35×weapon_B`

All calculations are performed as integer centipoints, with **round-half-up** arithmetic after the chain gate, weapon calculation and final combination; the reference implementation is authoritative.

Frozen v1.1 verdict rules (same numeric thresholds as v1.0):

| Absolute final-score gap | Official verdict |
|---|---|
| <5.00 | NO DECISIVE EDGE — abstention |
| 5.00–11.99 | Higher-scoring competitor has slight symbolic edge |
| 12.00–21.99 | Higher-scoring competitor has moderate symbolic edge |
| 22.00 or more | Higher-scoring competitor has pronounced symbolic edge |

The official predicted winner is **only** the higher-scoring competitor when the difference is at least five points. The score is not a probability. The model must not assert empirical reliability from these symbolic numbers.

## 6 — Execution and prospective evaluation

1. **Before a match begins** and without seeing its outcome, enter its date and both competitors' DOBs. Randomize or blind which competitor is listed first. Save the complete engine output, rule version, timestamp, all chain values, internal/external scores, official verdict and score gap.
2. **After the match**, append the actual winner separately. Do not alter the original prediction. For NO DECISIVE EDGE, count an **abstention** even if the higher raw scorer wins.
3. Track at least 100 new *genuinely pre-match* outcomes, preferably 200. Run archived v1.0 and frozen v1.1 side by side on the same fresh matches; never add outcomes to v1.1's rule definitions mid-test.
4. Report exact correct/wrong/abstention counts, selection rate, conditional directional accuracy, errors by edge tier and head-to-head results on the subset where both engines select a winner. Include a first-position-only baseline to diagnose ordering bias.
5. A change to profiles, numbers, weights, gate, opponent formula, or threshold requires a **new version** (e.g. v1.2.0) and separate test. No silent reinterpretations upon 'recheck'.

## 7 — Test and parity guarantees

The original frozen v1.0.0 engine is included unchanged in `baseline_v1/`; its existing 132 assertions pass. v1.1 additionally passes 4,972 deterministic assertions, including 600 competitor-order reversals. The offline JavaScript app was compared with the Python engine on 253 generated matchups, including preserved-master cases, with identical chain scores, opponent interaction, verdicts and gaps.

The parameters of v1.1 are **predefined symbolic choices**, not learned from actual winners. An improvement in predictive accuracy is a hypothesis to be tested, not a present finding.
