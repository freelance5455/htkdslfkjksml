"""Kinetic-Chain Sports Numerology v1.1.0.

Deterministic symbolic experimental engine. Not proven to predict sports outcomes.
No known match winners or performance data appear anywhere in scoring rules.
Historical v1.0.0 engine is bundled intact for chain calculation and regression checks.
"""
from __future__ import annotations
from datetime import date
from pathlib import Path
import argparse, hashlib, json
from baseline_v1 import engine as v1

BASE = Path(__file__).resolve().parent
RULES = json.loads((BASE / "rules_v1_1.json").read_text(encoding="utf-8"))


def profile(num: int) -> list[int]:
    return v1.RULES['profiles'][str(v1.lp_root(num))]


def loss_gain(src: int, dst: int) -> tuple[int, int]:
    before, after = profile(src), profile(dst)
    loss = sum(max(a-b, 0) for a, b in zip(before, after))
    gain = sum(max(b-a, 0) for a, b in zip(before, after))
    return loss, gain


def directional(src: int, dst: int) -> int:
    loss, gain = loss_gain(src,dst)
    return 100 - ((100*(2*loss+gain)+14)//28)


def internal_metrics(ch: list[int]) -> dict:
    lp,py,pm,pd = ch
    a,b,c,d = directional(lp,py),directional(py,pm),directional(pm,pd),directional(lp,pd)
    e=min(a,b,c)
    weights=RULES['chain_score']['stage_weights_percent']
    arithmetic_cp = (a*weights['core_to_year'] + b*weights['year_to_month'] +
                     c*weights['month_to_day'] + d*weights['core_to_day'] +
                     e*weights['weakest_adjacent'])
    # 60%..100% gate; round half up to exact centipoints
    gated_cp=(arithmetic_cp*(300+2*e)+250)//500
    return {'directional_links':{'core_to_year':a,'year_to_month':b,'month_to_day':c,
                                  'core_to_day':d,'weakest_adjacent':e},
            'weighted_centipoints':arithmetic_cp,
            'weighted_score':arithmetic_cp/100,
            'gate_factor':(300+2*e)/500,
            'gated_centipoints':gated_cp,
            'gated_score':gated_cp/100,
            'loss_gain':{'core_to_year':loss_gain(lp,py),
                         'year_to_month':loss_gain(py,pm),
                         'month_to_day':loss_gain(pm,pd),
                         'core_to_day':loss_gain(lp,pd)}}


def weapon_centipoints(my_pd:int, opp_pd:int, opp_lp:int) -> int:
    lp=profile(opp_lp)
    weights=[1+x for x in lp]
    delta=sum(w*(a-b) for w,a,b in zip(weights,profile(my_pd),profile(opp_pd)))
    W=sum(weights)
    n=5000*W+2500*delta
    assert 0 <= n <= 10000*W
    return (2*n+W)//(2*W)  # round half up


def compare(a:dict,b:dict,when:date)->dict:
    if not a.get('name') or not b.get('name'):
        raise ValueError('Both competitor names are required')
    ac=v1.chain(date.fromisoformat(a['dob']),when)
    bc=v1.chain(date.fromisoformat(b['dob']),when)
    ai=internal_metrics(ac['chain'])
    bi=internal_metrics(bc['chain'])
    aw=weapon_centipoints(ac['personal_day'],bc['personal_day'],bc['life_path'])
    bw=weapon_centipoints(bc['personal_day'],ac['personal_day'],ac['life_path'])
    af=(65*ai['gated_centipoints']+35*aw+50)//100
    bf=(65*bi['gated_centipoints']+35*bw+50)//100
    gap=abs(af-bf)
    edge=next(t['label'] for t in RULES['verdict_thresholds_centipoints'] if gap >= t['min'])
    verdict=(a['name'] if af>bf else b['name']) if edge!='no decisive edge' else None
    identity=sorted([{'name':p['name'],'dob':p['dob']} for p in (a,b)],key=lambda x:(x['dob'],x['name']))
    payload={'version':RULES['version'],'date':when.isoformat(),'competitors':identity}
    key=hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',',':')).encode()).hexdigest()[:20]
    return {'engine':RULES['version'],'date':when.isoformat(),'audit_key':key,
            'a':{'name':a['name'],'dob':a['dob'],'numbers':ac,
                 'internal':ai,'weapon_centipoints':aw,'opponent_weapon':aw/100,
                 'final_centipoints':af,'score':af/100},
            'b':{'name':b['name'],'dob':b['dob'],'numbers':bc,
                 'internal':bi,'weapon_centipoints':bw,'opponent_weapon':bw/100,
                 'final_centipoints':bf,'score':bf/100},
            'gap_centipoints':gap,'gap':gap/100,'edge':edge,'verdict':verdict,
            'method_note':'Experimental symbolic comparison; no demonstrated predictive accuracy.'}


def run_checks()->dict:
    baseline=v1.run_checks()
    assert baseline['status']=='PASS' and baseline['test_assertions']==132
    n=1
    for i in range(1,10):
        assert directional(i,i)==100
        n+=1
        for j in range(1,10):
            t=directional(i,j)
            assert 0<=t<=100
            assert (loss_gain(i,j)[0],loss_gain(i,j)[1])==(loss_gain(j,i)[1],loss_gain(j,i)[0])
            n+=2
    from random import Random
    rng=Random(1110)
    dates=[date(2026,10,26),date(2027,1,11),date(2028,8,9)]
    for _ in range(600):
        dob1=date(rng.randrange(1980,2011),rng.randrange(1,13),rng.randrange(1,28)).isoformat()
        dob2=date(rng.randrange(1980,2011),rng.randrange(1,13),rng.randrange(1,28)).isoformat()
        a,b={'name':'Alpha','dob':dob1},{'name':'Beta','dob':dob2}
        d=rng.choice(dates)
        r1=compare(a,b,d)
        r2=compare(a,b,d)
        s=compare(b,a,d)
        assert r1==r2
        assert r1['a']['final_centipoints']==s['b']['final_centipoints']
        assert r1['b']['final_centipoints']==s['a']['final_centipoints']
        assert r1['gap_centipoints']==s['gap_centipoints']
        assert r1['verdict']==s['verdict']
        assert r1['audit_key']==s['audit_key']
        assert r1['edge']==s['edge']
        assert 0<=r1['a']['final_centipoints']<=10000
        assert 0<=r1['b']['final_centipoints']<=10000
        n+=8
    return {'status':'PASS','v1_baseline_assertions':132,'v1_1_assertions':n,
            'independent_side_swap_cases':600,'version':RULES['version']}


if __name__=='__main__':
    p=argparse.ArgumentParser(description='Kinetic-Chain v1.1 experimental, numerology-only')
    p.add_argument('--test',action='store_true')
    p.add_argument('--date')
    p.add_argument('--a-name');p.add_argument('--a-dob')
    p.add_argument('--b-name');p.add_argument('--b-dob')
    args=p.parse_args()
    if args.test:
        print(json.dumps(run_checks(),indent=2))
    elif all((args.date,args.a_name,args.a_dob,args.b_name,args.b_dob)):
        print(json.dumps(compare({'name':args.a_name,'dob':args.a_dob},
                                 {'name':args.b_name,'dob':args.b_dob},
                                 date.fromisoformat(args.date)),indent=2))
    else:
        p.print_help()
