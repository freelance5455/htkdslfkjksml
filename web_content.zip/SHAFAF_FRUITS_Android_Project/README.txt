SHAFAF FRUITS Android wrapper project

This project wraps app/src/main/assets/index.html in an Android WebView.
It is a source project, not a prebuilt APK. Build with Android Studio on a computer:
1. Install Android Studio and Android SDK Platform 35.
2. Open this folder as an existing project.
3. Let Gradle sync complete.
4. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the generated app-debug.apk on your Android phone.

Important:
- Test all flows, especially Add Selected, Save Sale, PDF/share and backup/restore before using for real sales.
- WebView local storage is separate from the browser's local storage. Export a backup from the old app before moving to this APK; restore it in the APK if the app supports that backup format.
