# InTalk — Live and Talk

A language-learning **life simulation** in one self-contained web page. The learner picks a native language, a target
language (8 supported: az, tr, ru, en, de, es, zh, ko) and a CEFR level, creates a character with a family, and then
lives in a neighbourhood: people (played by an AI) talk to them in the target language, mistakes are collected, and a
phone offers messages, a tutor, a dictionary, music, games, a wallpaper picker and more.

* No framework, no runtime dependencies — plain HTML/CSS/JavaScript bundled into **`dist/index.html`**.
* The AI runs through a small Cloudflare Worker (`worker/groq-worker.js`, provider: Groq) or, when the page is opened
  inside Claude, through the built-in `sample` capability.

## Quick start

```bash
npm run build        # src/  ->  dist/index.html   (needs Node 18+, nothing to install)
npm test             # unit tests (no browser)
npm run test:e2e     # builds + end-to-end tests in 3 AI modes (needs: npm i && npx playwright install chromium)
npm run serve        # build + http://localhost:8080
```

Open `dist/index.html` in a browser, or upload that single file to any static host (see `docs/DEPLOYMENT.md`).

## Folder map

```
intalk/
├─ dist/index.html            the finished app - publish this one file
├─ src/
│  ├─ index.template.html     page skeleton (build injects styles + scripts)
│  ├─ manifest.json           load order of styles and scripts (checked by the build)
│  ├─ styles/                 base · setup · world · phone · apps  (.css)
│  ├─ scripts/
│  │  ├─ config/              WORKER_URL (AI proxy address)
│  │  ├─ i18n/                UI texts in 8 languages
│  │  ├─ core/                store, helpers, icons, mascot, audio, voice, permissions
│  │  ├─ avatar/              40 SVG avatars
│  │  ├─ ai/                  AI service (Game state + calls) and ALL prompts
│  │  ├─ game/                family, places, setup wizard, world logic, group chat, XP/levels
│  │  ├─ ui/                  main screens (map / place / chat) and Back-button handling
│  │  ├─ phone/               phone shell, wallpapers, apps/ (one file per app)
│  │  └─ main.js              start-up
│  ├─ data/dictionary/        26 plain-text files - the built-in dictionary (one category each)
│  └─ assets/                 mascot/ and wallpapers/ images (embedded by the build)
├─ worker/                    Cloudflare Worker (Groq): AI proxy + speech-to-text + English TTS
├─ tools/build.js             the builder
├─ tests/                     unit/ and e2e/
└─ docs/                      ARCHITECTURE · CUSTOMIZING · DEPLOYMENT · TESTING
```

## Where do I change …?

| I want to … | Edit |
|---|---|
| change how the AI people behave / talk | `src/scripts/ai/prompts.js` |
| change a UI text or translation | `src/scripts/i18n/ui-strings.js`, `ui-strings-extra.js` |
| add words to the dictionary | `src/data/dictionary/NN-*.txt` (one line = one entry) |
| add a kind of place (pharmacy, cinema…) | `src/scripts/game/places.js` (`KINDS`) + icon in `core/icons.js` + names in `ui-strings-extra.js` |
| change XP, levels, daily goal | `src/scripts/game/progress.js` |
| change colours / dark theme | `src/styles/base.css` (CSS variables at the top) |
| replace the mascot or wallpapers | drop new files into `src/assets/mascot/` or `src/assets/wallpapers/` |
| change the Worker address | `src/scripts/config/config.js` |
| add a phone app | new file in `src/scripts/phone/apps/` + one line in `src/manifest.json` |
| change the map look | `src/scripts/ui/render.js` (`mapSvg`) |
| change sounds / voice | `src/scripts/core/audio.js`, `core/voice.js` |

Step-by-step recipes: `docs/CUSTOMIZING.md`. How the pieces fit together: `docs/ARCHITECTURE.md`.
