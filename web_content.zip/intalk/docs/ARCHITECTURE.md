# Architecture

## Big picture

* **One page, one global scope.** `tools/build.js` concatenates the scripts listed in `src/manifest.json` into a single
  `<script>`. There are no modules/imports: every file may use anything defined in files listed **above** it at
  load time (inside functions, anything defined anywhere is fine because it runs later).
* **Generated data.** The build prepends two constants: `ASSETS` (images from `src/assets/`, as data URIs) and `LEX`
  (the dictionary from `src/data/dictionary/*.txt`).
* **State is plain objects.** `S` (the saved profile), `Game` (the running world), `Ph` (the phone) and a few small
  singletons (`Store`, `Voice`, `Sfx`, `Progress`, `Streak`, `Groups`, `Greet`, `Nav`, `Dict`, `Wall`, `Perm`).
* **Rendering is re-render-on-change.** `render()` rebuilds the main area from `Game.view` (`map` | `place` | `chat`);
  `Ph.draw()` rebuilds the phone screen. Events are delegated (one listener per container, `closest('[data-…]')`).

## Load order (see `src/manifest.json`)

| Layer | Files | Role |
|---|---|---|
| config / i18n | `config/config.js`, `i18n/ui-strings*.js` | Worker URL, language list, UI texts `T[lang][key]` |
| core | `icons`, `mascot`, `store`, `helpers`, `audio`, `voice`, `permissions` | storage, DOM helpers, toasts, icon set + flags + emoji→icon swap, shared AudioContext + sound effects, speech in/out, mic permission |
| avatar | `avatar/avatar.js` | 40 SVG characters (`avatar(look, mood, size, crop)`) |
| ai | `ai-service.js`, `prompts.js` | `Game` object, rate-limited AI calls, tolerant JSON parser, every prompt |
| game | `family`, `places`, `setup`, `world`, `groups`, `progress` | rules of the simulation |
| ui | `render.js`, `nav.js` | main screens, header, map, Back-button layers |
| phone | `core.js`, `wallpapers.js`, `apps/**` | phone shell + one file per app |
| start-up | `main.js` | wires events, starts the game (or the wizard on first run) |

## Key runtime objects

* `S` — profile: `{nat, tgt, lvl, nick, gen, age, job, av, fam, marital, done}`; saved under `intalk_profile`.
* `Game` — `{places, people, npcs, friends, groups, view, place, cur, grp, work, city, …}`; `Game.clock()` gives the
  local time of day that is passed to every prompt.
* `t(key)` → UI text in the learner's **native** language; `tp(key)` → in the **target** language (phone labels).
* `reg({id, icon, name(), order, home|dock, badge(), onOpen(c), draw({top,c}), click(e,q), key(e)})` registers a phone
  app (`phone/core.js`). `draw` returns HTML; `click(e, q)` receives the event and `q(selector)` = `closest`.

## AI flow

`Game.ask(prompt, strict)` → `Game.call()` → `viaWorker()` (POST to `WORKER_URL`) **or**, if no Worker is reachable,
the built-in Claude `sample` capability → `parse()` (tolerant JSON reader: strips ``` fences, ignores surrounding text,
repairs truncated output). Calls are spaced (≥1.5 s) and retried on rate limits.

Every prompt lives in `ai/prompts.js`: `scenePrompt` (who is at a place), `npcPrompt` (one person's reply),
`groupPrompt` (group chat; a member can call any nearby person over via the `join` field), `phonePrompt` (texting), `classifyPrompt` (profession → workplace), `tutorPrompt`. They all
receive the local time, personas and memory so people behave consistently. Replies are small JSON objects; the fields
are documented at the end of each prompt.

## Worker (`worker/groq-worker.js`)

Provider: **Groq** (OpenAI-compatible API). `POST {system, messages, max_tokens}` → `{content:[{type:'text', text}], stop_reason}`
(chat, `llama-3.3-70b-versatile` by default; Groq JSON mode is switched on when the prompt says "valid JSON only");
`POST {task:'stt', audio:<base64 WAV 16 kHz>, lang}` → `{text}` (Whisper, all 8 languages);
`POST {task:'tts', text, gender:'f'|'m', lang}` → `{audio:<base64 WAV>}` (Groq's voices are **English only**; other languages get
HTTP 400 and the app uses the device voice instead).
Secret `GROQ_API_KEY`; optional `GROQ_MODEL`, `GROQ_STT_MODEL`, `GROQ_TTS_MODEL`, `GROQ_TTS_VOICE_F/M`, `ALLOWED_ORIGIN`.

## Storage (localStorage, prefix `intalk_`)

`profile` · `xp` · `streak` · `stats` · `mistakes` · `songs` · `cal` · `dict_user` · `wall` · `theme` · `sfx` · `tts` · `mic`.
Data saved by older versions under `lq_` is migrated automatically on first load (`core/store.js`).

## Behaviour rules worth knowing

* People approach **one at a time** (`Greet` in `game/world.js`); the "waiting" queue is ordered by who spoke first.
* Only real spelling/grammar/word-choice mistakes are reported; spacing, punctuation and capitalisation are ignored
  (`realMistakes` in `core/helpers.js` + `MISTAKE_RULE` in the prompts).
* Back button: `ui/nav.js` keeps one history entry armed and steps out of one UI layer per press.
* Voice output tries the device voice → Worker voice → Google audio; failures are shown with a reason code.
