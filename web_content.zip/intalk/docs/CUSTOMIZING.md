# Customizing — recipes

After any change run `npm run build` (and `npm test`).

## Add or fix dictionary words
Files: `src/data/dictionary/NN-category.txt`. Format (8 languages, always this order: `az|tr|ru|en|de|es|zh|ko`):

```
# comment lines start with #
@name Peşələr|Meslekler|Профессии|Professions|Berufe|Profesiones|职业|직업
müəllim|öğretmen|учитель|teacher|Lehrer|profesor|老师|선생님
```
Add a line to an existing file, or create `27-newcategory.txt` (number = order of the chips in the app). The build
refuses a file with the wrong number of columns and tells you the file and line.

## Change the AI behaviour
`src/scripts/ai/prompts.js`. Shared rules are constants at the top (`HUMAN_RULE`, `MISTAKE_RULE`); each prompt is a
method of `Game`. Keep the final `Output ONLY compact JSON {…}` line in sync with the code that reads the fields
(`game/world.js` → `sendNpc`, `game/groups.js` → `groupTurn`).

## Add a kind of place
1. `game/places.js` → add an entry to `KINDS` (`e` = emoji key, `cat` = colour category, `en` = description for the AI).
2. `core/icons.js` → make sure the emoji maps to an icon in `EMOJI_ICON` (add a path to `ICO` if needed).
3. `i18n/ui-strings-extra.js` → add the place name in the 8 languages (a key equal to the kind id).
4. Optional: add the id to `BASE_IDS` to show it from the start; otherwise people can "tell" the player about it.

## Add a phone app
Create `src/scripts/phone/apps/myapp.js`:
```js
reg({ id: 'myapp', icon: '📚', order: 15, home: true, name: () => tp('myapp'),
  draw({ top }) { return top(tp('myapp'), 'home') + '<div class="pb">…</div>'; },
  click(e, q) { if (q('[data-x]')) { /* … */ return true; } } });
```
then list it in `src/manifest.json` (before `scripts/main.js`) and add a `myapp` text to `i18n/ui-strings-extra.js`.
`icon` accepts an emoji that exists in `EMOJI_ICON`; it is drawn as a line icon.

## Add or change a UI text / language
* Texts: `i18n/ui-strings.js` (core) and `ui-strings-extra.js` (groups: `k:'key1|key2'` + one pipe-separated line per language).
* New language (advanced): add it to `LANGS`, `LC` (speech codes) and every text group, add a 9th column to every
  dictionary file (and raise `LANG_COUNT` in `tools/lib/data.js` and the `LI` table in `phone/apps/dictionary.js`),
  add a flag in `core/icons.js` (`FLAGS`) and speech settings in `core/voice.js`.

## XP, levels, daily goal
`game/progress.js`: `GOAL` (daily XP), `Progress.at(l)` (XP needed for level l), `Progress.gain()` call sites
(`msg`, `friend`, `visit`, games). Streak rules (freeze every 7 days) are in `core/store.js`.

## Colours, fonts, dark theme
CSS variables at the top of `styles/base.css` (`--blue`, `--ink`, `--bg`, …); `:root[data-theme=dark]` overrides them.

## Replace the mascot / wallpapers
Put files in `src/assets/mascot/` (names used by code: wave, both, peace, thumb, bust, face) or
`src/assets/wallpapers/` (any `*.webp|png|jpg` — the file name becomes its id; the picker lists all of them).

## Change the Worker address
`src/scripts/config/config.js` → `WORKER_URL`. See `docs/DEPLOYMENT.md` for deploying the Worker.
