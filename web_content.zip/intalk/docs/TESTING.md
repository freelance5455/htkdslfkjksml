# Testing

| Command | What runs |
|---|---|
| `npm test` | all `tests/unit/*.test.js` (fast, no browser) |
| `npm run test:e2e` | unit tests + build + `tests/e2e/e2e.js` in three AI modes (`claude`, `worker`, `worker-messy`) |

Unit tests: `parse` (tolerant JSON reader), `worker` (Groq Worker: request/response mapping, JSON mode, errors, Whisper STT, TTS), `progress`
(XP, levels, daily goal, streak freeze), `mistakes` (typography is never a mistake), `dict` (dictionary files).

The end-to-end test drives the real page in headless Chromium with a **fake AI** (`mock` at the top of `e2e.js`) and a
fake microphone. It walks through: the wizard, map, chat, kinship address rules, friends and home addresses, phone apps,
dictionary, wallpapers, group chat, back-button layers, new game, voice fallbacks, and scans every screen for stray emoji.
It needs Playwright: `npm i && npx playwright install chromium` (or set `PW=/path/to/node_modules/playwright`).
`MODE=claude|worker|worker-messy` selects how the fake AI answers.

When you add a feature, add a `step('…', async () => { … })` to `e2e.js` and, for pure logic, a small `*.test.js`.
