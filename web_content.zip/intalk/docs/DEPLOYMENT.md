# Deployment

## 1. Publish the page
`npm run build` produces **`dist/index.html`** — one self-contained file (≈0.9 MB).
Upload it to any static host (GitHub Pages, Netlify, Cloudflare Pages, S3, nginx…). No server code is needed.

* It loads the *Inter* font from Google Fonts; offline it falls back to system fonts.
* If you set a strict Content-Security-Policy, allow: `connect-src` → your Worker, `translate.googleapis.com`,
  `api.mymemory.translated.net`, `en.wiktionary.org`; `media-src` → `translate.google.com`; `style-src/font-src` →
  `fonts.googleapis.com`, `fonts.gstatic.com`.
* Use HTTPS: microphone access and some audio features need a secure context.

## 2. The AI Worker (Groq; needed outside Claude)
1. Cloudflare dashboard → Workers → create a Worker → paste `worker/groq-worker.js` (or `npx wrangler deploy` with `worker/wrangler.toml`).
2. Settings → Variables and Secrets → **Secret** `GROQ_API_KEY` = your key from console.groq.com.
3. Optional variables: `GROQ_MODEL` (default `llama-3.3-70b-versatile`; pick a normal chat model - "reasoning" models may spend the
   token budget on hidden reasoning), `GROQ_STT_MODEL` (default `whisper-large-v3-turbo`), `GROQ_TTS_MODEL`
   (default `canopylabs/orpheus-v1-english`), `GROQ_TTS_VOICE_F` / `GROQ_TTS_VOICE_M` (defaults `hannah` / `troy`),
   `ALLOWED_ORIGIN` (default `*`; set it to your site's origin in production).
4. Put the Worker URL into `src/scripts/config/config.js` (`WORKER_URL`) and rebuild.
5. Test: in the app → phone → Settings → 🛠 (AI · sound · microphone) → "Run AI tests".

Voice features also go through the Worker (`task:'stt'`, `task:'tts'`). Speech-to-text (Whisper) works for all 8 languages.
Groq's text-to-speech is **English only**; for other languages the Worker answers HTTP 400 ("English only"), the app remembers it
and speaks with the device voice (or the Google audio fallback). Groq may ask you to accept the TTS model's terms once in the
Groq console. An old Worker without voice support answers HTTP 400 and the app shows it in the error code.

## 3. Android APK (HTML → APK tools)
Use any "website/HTML to APK" wrapper and point it at `dist/index.html` (or your hosted URL). Check that the wrapper:
* grants **RECORD_AUDIO** and forwards the WebView microphone permission request (otherwise voice input cannot work);
* forwards the hardware **Back** key to `webView.goBack()` (the app uses history entries to step back one screen);
* allows internet access (AI Worker, online dictionary lookups, Google voice fallback).
Device speech output needs a text-to-speech voice for the language (Android: Settings → Languages → Text-to-speech).

## 4. Release checklist
`npm test` → `npm run test:e2e` → bump `version` in `package.json` → `npm run build` → upload `dist/index.html`.
