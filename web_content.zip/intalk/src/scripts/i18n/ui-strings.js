/**
 * i18n core: languages, base UI strings (T[lang][key])
 *
 * Provides: LANGS, PFX, LEVELS, K, RAW, T
 */
const LANGS = {
    az: ['Azərbaycanca', '🇦🇿', 'Azerbaijani'], tr: ['Türkçe', '🇹🇷', 'Turkish'], ru: ['Русский', '🇷🇺', 'Russian'], en: ['English', '🇬🇧', 'English'], de: ['Deutsch', '🇩🇪', 'German'], es: ['Español', '🇪🇸', 'Spanish'], zh: ['中文', '🇨🇳', 'Mandarin Chinese'], ko: ['한국어', '🇰🇷', 'Korean']
};
const PFX = {
    az: '+994 50', tr: '+90 5', ru: '+7 9', en: '+44 77', de: '+49 151', es: '+34 6', zh: '+86 13', ko: '+82 10'
};
const LEVELS = ['A1', 'A2', 'B1', 'B2', 'C1'];
const K = 'nat|tgt|lvl|age|m|f|job|nick|go|err|set|typ|none|newg|think|msg|fri|prof|hint|saved|hood|look|gam|news|clr|home|street|cafe|market|park|school|work|bus'.split('|');
const RAW = {
    az: 'Ana dilin|Öyrəndiyin dil|Səviyyən|Yaş|Kişi|Qadın|Peşə və həyat tərzi|Adın|OYUNA BAŞLA|Səhv dəftərçəsi|Ayarlar|Cavabını yaz…|Hələ səhv yoxdur|Yeni oyun|Yazır…|Mesajlar|Kontaktlar|Profil|Bir yerə get, kimləsə tanış ol 📞|Kontakt saxlanıldı|Məhəllə|Ətrafa bax 👀|Oyunlar|Xəbərlər|Hamısını sil|Ev|Küçə|Kafe|Ərzaq mağazası|Park|Məktəb|İş|Dayanacaq',
    tr: 'Ana dilin|Öğreneceğin dil|Seviyen|Yaş|Erkek|Kadın|Meslek ve yaşam tarzı|Adın|OYUNA BAŞLA|Hata defteri|Ayarlar|Cevabını yaz…|Henüz hata yok|Yeni oyun|Yazıyor…|Mesajlar|Kişiler|Profil|Bir yere git, biriyle tanış 📞|Kişi kaydedildi|Mahalle|Etrafa bak 👀|Oyunlar|Haberler|Hepsini sil|Ev|Sokak|Kafe|Market|Park|Okul|İş|Durak',
    ru: 'Родной язык|Изучаемый язык|Уровень|Возраст|Муж.|Жен.|Профессия и образ жизни|Имя|НАЧАТЬ ИГРУ|Тетрадь ошибок|Настройки|Напиши ответ…|Ошибок пока нет|Новая игра|Печатает…|Сообщения|Контакты|Профиль|Сходи куда-нибудь и познакомься 📞|Контакт сохранён|Район|Осмотреться 👀|Игры|Новости|Удалить всё|Дом|Улица|Кафе|Продуктовый магазин|Парк|Школа|Работа|Остановка',
    en: 'Native language|Language to learn|Your level|Age|Male|Female|Job & lifestyle|Name|START GAME|Mistake notebook|Settings|Type your reply…|No mistakes yet|New game|Typing…|Messages|Contacts|Profile|Go somewhere and meet people 📞|Contact saved|Neighbourhood|Look around 👀|Games|News|Clear all|Home|Street|Café|Grocery store|Park|School|Work|Bus stop',
    de: 'Muttersprache|Zielsprache|Dein Niveau|Alter|Männlich|Weiblich|Beruf & Lebensstil|Name|SPIEL STARTEN|Fehlerheft|Einstellungen|Antwort schreiben…|Noch keine Fehler|Neues Spiel|Schreibt…|Nachrichten|Kontakte|Profil|Geh irgendwohin und lerne Leute kennen 📞|Kontakt gespeichert|Viertel|Umschauen 👀|Spiele|Nachrichten|Alles löschen|Zuhause|Straße|Café|Lebensmittelgeschäft|Park|Schule|Arbeit|Haltestelle',
    es: 'Lengua materna|Idioma a aprender|Tu nivel|Edad|Hombre|Mujer|Trabajo y estilo de vida|Nombre|EMPEZAR|Cuaderno de errores|Ajustes|Escribe tu respuesta…|Aún sin errores|Nueva partida|Escribiendo…|Mensajes|Contactos|Perfil|Ve a algún sitio y conoce gente 📞|Contacto guardado|Barrio|Mirar alrededor 👀|Juegos|Noticias|Borrar todo|Casa|Calle|Café|Tienda de comestibles|Parque|Escuela|Trabajo|Parada',
    zh: '母语|学习语言|你的水平|年龄|男|女|职业与生活方式|名字|开始游戏|错题本|设置|输入回复…|暂无错误|新游戏|正在输入…|信息|联系人|我的|去个地方认识新朋友 📞|联系人已保存|街区|四处看看 👀|游戏|新闻|全部删除|家|街道|咖啡馆|食品店|公园|学校|工作|公交站'
};
RAW.ko = '모국어|배울 언어|내 수준|나이|남성|여성|직업과 생활 방식|이름|게임 시작|오답 노트|설정|답장을 입력하세요…|아직 오답이 없어요|새 게임|입력 중…|메시지|연락처|프로필|어딘가 가서 사람들을 만나 보세요 📞|연락처 저장됨|동네|둘러보기 👀|게임|뉴스|모두 삭제|집|거리|카페|식료품점|공원|학교|직장|버스 정류장';
const T = Object.fromEntries(Object.entries(RAW).map(([l, s]) => [l, Object.fromEntries(s.split('|').map((v, i) => [K[i], v]))]));
