/**
 * Extra UI strings: one group = keys + one pipe-separated line per language
 *
 * Provides: EXTRA
 */
const EXTRA = [
    {
        k: 'inst|del|mus|lib|disc',
        az: 'Yüklə|Sil|Musiqi|Kitabxana|Kəşf et', tr: 'İndir|Sil|Müzik|Kütüphane|Keşfet', ru: 'Установить|Удалить|Музыка|Библиотека|Обзор', en: 'Get|Delete|Music|Library|Discover',
        de: 'Laden|Löschen|Musik|Bibliothek|Entdecken', es: 'Obtener|Eliminar|Música|Biblioteca|Descubrir', zh: '获取|删除|音乐|音乐库|发现', ko: '받기|삭제|음악|보관함|둘러보기'
    },
    {
        k: 'calc|trn|cal|ai|wrd|mat|qz|lis',
        az: 'Kalkulyator|Tərcüməçi|Təqvim|Süni intellekt|Söz tap|Cütlə|Viktorina|Dinlə və yaz', tr: 'Hesap makinesi|Çevirmen|Takvim|Yapay zekâ|Kelime bul|Eşleştir|Bilgi yarışı|Dinle ve yaz',
        ru: 'Калькулятор|Переводчик|Календарь|ИИ-репетитор|Угадай слово|Пары|Викторина|Слушай и пиши', en: 'Calculator|Translator|Calendar|AI Tutor|Word guess|Match|Quiz|Listen & type',
        de: 'Rechner|Übersetzer|Kalender|KI-Tutor|Wortraten|Paare|Quiz|Hören & schreiben', es: 'Calculadora|Traductor|Calendario|Tutor IA|Adivina|Parejas|Quiz|Escucha y escribe',
        zh: '计算器|翻译|日历|AI 助手|猜词|配对|问答|听写', ko: '계산기|번역기|캘린더|AI 튜터|단어 맞추기|짝 맞추기|퀴즈|듣고 쓰기'
    },
    {
        k: 'fam|mar|sg|mr|mo|fa|br|si|gm|gf|sp|ch',
        az: 'Ailə|Ailə vəziyyəti|Subay|Evli|Ana|Ata|Qardaş|Bacı|Nənə|Baba|Həyat yoldaşı|Övlad', tr: 'Aile|Medeni durum|Bekâr|Evli|Anne|Baba|Erkek kardeş|Kız kardeş|Büyükanne|Büyükbaba|Eş|Çocuk',
        ru: 'Семья|Семейное положение|Не женат / не замужем|Женат / замужем|Мама|Папа|Брат|Сестра|Бабушка|Дедушка|Супруг(а)|Ребёнок', en: 'Family|Marital status|Single|Married|Mother|Father|Brother|Sister|Grandmother|Grandfather|Spouse|Child',
        de: 'Familie|Familienstand|Ledig|Verheiratet|Mutter|Vater|Bruder|Schwester|Großmutter|Großvater|Ehepartner|Kind', es: 'Familia|Estado civil|Soltero/a|Casado/a|Madre|Padre|Hermano|Hermana|Abuela|Abuelo|Pareja|Hijo/a',
        zh: '家人|婚姻状况|单身|已婚|妈妈|爸爸|兄弟|姐妹|奶奶|爷爷|配偶|孩子', ko: '가족|결혼 여부|미혼|기혼|어머니|아버지|형제|자매|할머니|할아버지|배우자|자녀'
    },
    {
        k: 'add|today|ask|next|chk|done',
        az: 'Əlavə et|Bu gün|Soruş…|Növbəti|Yoxla|Hazır', tr: 'Ekle|Bugün|Sor…|Sonraki|Kontrol et|Tamam', ru: 'Добавить|Сегодня|Спроси…|Далее|Проверить|Готово', en: 'Add|Today|Ask…|Next|Check|Done',
        de: 'Hinzufügen|Heute|Frag…|Weiter|Prüfen|Fertig', es: 'Añadir|Hoy|Pregunta…|Siguiente|Comprobar|Listo', zh: '添加|今天|提问…|下一个|检查|完成', ko: '추가|오늘|물어보세요…|다음|확인|완료'
    },
    {
        k: 'slogan|l1|l2|l3|l4|l5',
        az: 'Yaşa və danış|Başlanğıc|Elementar|Orta|Orta üstü|İrəli', tr: 'Yaşa ve konuş|Başlangıç|Temel|Orta|Orta üstü|İleri', ru: 'Живи и говори|Начальный|Базовый|Средний|Выше среднего|Продвинутый', en: 'Live and Talk|Beginner|Elementary|Intermediate|Upper-intermediate|Advanced',
        de: 'Lebe und sprich|Anfänger|Grundlagen|Mittelstufe|Gehobene Mittelstufe|Fortgeschritten', es: 'Vive y habla|Principiante|Elemental|Intermedio|Intermedio alto|Avanzado', zh: '生活，交流|入门|初级|中级|中高级|高级', ko: '살고, 대화하세요|입문|초급|중급|중고급|고급'
    },
    {
        k: 'all|pub|frd|search|talk|ppl|visit',
        az: 'Hamısı|İctimai|Dostlar|Məkan və ya şəxs axtar…|Danış|nəfər|Get', tr: 'Tümü|Genel|Arkadaşlar|Yer veya kişi ara…|Konuş|kişi|Git', ru: 'Все|Общие|Друзья|Поиск мест и людей…|Говорить|чел.|Зайти', en: 'All|Public|Friends|Search places or people…|Talk|people|Visit',
        de: 'Alle|Öffentlich|Freunde|Orte oder Personen suchen…|Sprechen|Personen|Besuchen', es: 'Todos|Público|Amigos|Buscar lugares o personas…|Hablar|personas|Visitar', zh: '全部|公共|朋友|搜索地点或人物…|交谈|人|前往', ko: '전체|공공|친구|장소나 사람 검색…|대화|명|방문'
    },
    {
        k: 'rk1|rk2|rk3|rk4|rk5|rk6|goal|strk|best|ach|lvup',
        az: 'Təzə gələn|Tələbə|Kəşfçi|Yerli sakin|Bələdçi|Usta|Gündəlik hədəf|Seriya|Rekord|Nailiyyətlər|Yeni səviyyə!', tr: 'Yeni gelen|Öğrenci|Kâşif|Yerli|Rehber|Usta|Günlük hedef|Seri|Rekor|Başarılar|Yeni seviye!',
        ru: 'Новичок|Ученик|Исследователь|Местный|Знаток|Мастер|Цель дня|Серия|Рекорд|Достижения|Новый уровень!', en: 'Newcomer|Learner|Explorer|Local|Insider|Master|Daily goal|Streak|Best|Achievements|Level up!',
        de: 'Neuling|Lernender|Entdecker|Einheimischer|Kenner|Meister|Tagesziel|Serie|Rekord|Erfolge|Level-up!', es: 'Novato|Aprendiz|Explorador|Local|Conocedor|Maestro|Meta diaria|Racha|Récord|Logros|¡Nuevo nivel!',
        zh: '新人|学习者|探索者|本地人|行家|大师|每日目标|连续天数|最佳|成就|升级了！', ko: '새내기|학습자|탐험가|현지인|고수|마스터|일일 목표|연속 학습|최고|업적|레벨 업!'
    },
    {
        k: 'snd|voi|thm|mic|nov|nom',
        az: 'Səslər|Səs|Mövzu|Mikrofon|Bu cihazda səs oxunmur|Mikrofon işləmir və ya icazə verilməyib', tr: 'Sesler|Ses|Tema|Mikrofon|Bu cihazda ses oynatılamıyor|Mikrofon çalışmıyor veya izin verilmedi',
        ru: 'Звуки|Голос|Тема|Микрофон|Озвучка недоступна на этом устройстве|Микрофон недоступен или нет разрешения', en: 'Sounds|Voice|Theme|Microphone|Voice playback is not available on this device|Microphone unavailable or permission denied',
        de: 'Töne|Stimme|Design|Mikrofon|Sprachausgabe ist auf diesem Gerät nicht verfügbar|Mikrofon nicht verfügbar oder Zugriff verweigert', es: 'Sonidos|Voz|Tema|Micrófono|La voz no está disponible en este dispositivo|Micrófono no disponible o sin permiso',
        zh: '音效|语音|主题|麦克风|此设备无法播放语音|麦克风不可用或未授权', ko: '효과음|음성|테마|마이크|이 기기에서는 음성 재생을 사용할 수 없습니다|마이크를 사용할 수 없거나 권한이 없습니다'
    },
    {
        k: 'ngq|ngi|yes|no',
        az: 'Yeni oyun başlansın?|Dil seçimin və personajın sıfırlanacaq. XP və seriyan qalır.|Bəli|Xeyr', tr: 'Yeni oyun başlasın mı?|Dil seçimin ve karakterin sıfırlanacak. XP ve serin korunur.|Evet|Hayır',
        ru: 'Начать новую игру?|Выбор языков и персонаж будут сброшены. XP и серия сохранятся.|Да|Нет', en: 'Start a new game?|Your language choices and character will be reset. XP and streak are kept.|Yes|No',
        de: 'Neues Spiel starten?|Sprachauswahl und Figur werden zurückgesetzt. XP und Serie bleiben erhalten.|Ja|Nein', es: '¿Empezar una partida nueva?|Se restablecerán tus idiomas y tu personaje. Se conservan el XP y la racha.|Sí|No',
        zh: '开始新游戏？|语言选择和角色将被重置，经验值和连续天数会保留。|是|否', ko: '새 게임을 시작할까요?|언어 선택과 캐릭터가 초기화됩니다. XP와 연속 학습은 유지됩니다.|예|아니요'
    },
    {
        k: 'wall|wait|first|bexit|grant|reply',
        az: 'Divar kağızı|Cavabını gözləyir|Əvvəl buna cavab ver|Çıxmaq üçün yenidən geri bas|Mikrofon icazəsi verildi|Cavab ver', tr: 'Duvar kağıdı|Cevabını bekliyor|Önce buna cevap ver|Çıkmak için tekrar geri bas|Mikrofon izni verildi|Cevapla',
        ru: 'Обои|Ждёт ответа|Ответь сначала|Нажми «Назад» ещё раз, чтобы выйти|Доступ к микрофону разрешён|Ответить', en: 'Wallpaper|Waiting for your reply|Reply to this one first|Press back again to exit|Microphone allowed|Reply',
        de: 'Hintergrund|Wartet auf deine Antwort|Antworte zuerst hier|Zum Beenden erneut „Zurück" drücken|Mikrofon erlaubt|Antworten', es: 'Fondo de pantalla|Espera tu respuesta|Responde a esta primero|Pulsa atrás otra vez para salir|Micrófono permitido|Responder',
        zh: '壁纸|等待你的回复|请先回复这位|再按一次返回即可退出|已允许麦克风|回复', ko: '배경화면|답장을 기다리는 중|먼저 이 사람에게 답하세요|종료하려면 뒤로 가기를 한 번 더 누르세요|마이크가 허용되었습니다|답장'
    },
    {
        k: 'clothes|station|company|pharmacy|bank|restaurant|library|gym|cinema|post|hospital|hotel|mall|museum|barber|bakery|airport|lake|newp|grp|gstart|joined',
        az: 'Geyim mağazası|Avtovağzal|Şirkət|Aptek|Bank|Restoran|Kitabxana|İdman zalı|Kinoteatr|Poçt|Xəstəxana|Otel|Ticarət mərkəzi|Muzey|Bərbərxana|Çörək evi|Hava limanı|Göl|Xəritəyə əlavə olundu|Qrup söhbəti|Başla|qoşuldu',
        tr: 'Giyim mağazası|Otogar|Şirket|Eczane|Banka|Restoran|Kütüphane|Spor salonu|Sinema|Postane|Hastane|Otel|AVM|Müze|Berber|Fırın|Havalimanı|Göl|Haritaya eklendi|Grup sohbeti|Başlat|katıldı',
        ru: 'Магазин одежды|Автовокзал|Компания|Аптека|Банк|Ресторан|Библиотека|Спортзал|Кинотеатр|Почта|Больница|Отель|Торговый центр|Музей|Парикмахерская|Пекарня|Аэропорт|Озеро|Добавлено на карту|Групповой чат|Начать|присоединился',
        en: 'Clothing store|Bus station|Company|Pharmacy|Bank|Restaurant|Library|Gym|Cinema|Post office|Hospital|Hotel|Mall|Museum|Barber|Bakery|Airport|Lake|Added to the map|Group chat|Start|joined',
        de: 'Bekleidungsgeschäft|Busbahnhof|Firma|Apotheke|Bank|Restaurant|Bibliothek|Fitnessstudio|Kino|Post|Krankenhaus|Hotel|Einkaufszentrum|Museum|Friseur|Bäckerei|Flughafen|See|Zur Karte hinzugefügt|Gruppenchat|Starten|ist beigetreten',
        es: 'Tienda de ropa|Estación de autobuses|Empresa|Farmacia|Banco|Restaurante|Biblioteca|Gimnasio|Cine|Correos|Hospital|Hotel|Centro comercial|Museo|Barbería|Panadería|Aeropuerto|Lago|Añadido al mapa|Chat de grupo|Empezar|se unió',
        zh: '服装店|汽车站|公司|药店|银行|餐厅|图书馆|健身房|电影院|邮局|医院|酒店|商场|博物馆|理发店|面包店|机场|湖|已添加到地图|群聊|开始|加入了',
        ko: '옷 가게|버스터미널|회사|약국|은행|식당|도서관|헬스장|영화관|우체국|병원|호텔|쇼핑몰|박물관|이발소|빵집|공항|호수|지도에 추가되었습니다|그룹 대화|시작|참여했습니다'
    },
    {
        k: 'dict|dmy|dadd|dword|dmean|dex|donl|dnone|dsaved|dsave|dsrch|dother|dwords|dsrc',
        az: 'Lüğət|Mənim sözlərim|Söz əlavə et|Söz və ya ifadə|Mənası|Nümunə cümlə|İnternetdə axtar|Heç nə tapılmadı|Lüğətə əlavə olundu|Yadda saxla|Lüğətdə axtar…|Digər dillərdə|söz|Mənbə', tr: 'Sözlük|Kelimelerim|Kelime ekle|Kelime veya ifade|Anlamı|Örnek cümle|İnternette ara|Hiçbir şey bulunamadı|Sözlüğe eklendi|Kaydet|Sözlükte ara…|Diğer dillerde|kelime|Kaynak',
        ru: 'Словарь|Мои слова|Добавить слово|Слово или фраза|Значение|Пример|Искать в интернете|Ничего не найдено|Добавлено в словарь|Сохранить|Поиск в словаре…|На других языках|слов|Источник', en: 'Dictionary|My words|Add a word|Word or phrase|Meaning|Example sentence|Search online|Nothing found|Added to the dictionary|Save|Search the dictionary…|In other languages|words|Source',
        de: 'Wörterbuch|Meine Wörter|Wort hinzufügen|Wort oder Ausdruck|Bedeutung|Beispielsatz|Online suchen|Nichts gefunden|Zum Wörterbuch hinzugefügt|Speichern|Im Wörterbuch suchen…|In anderen Sprachen|Wörter|Quelle', es: 'Diccionario|Mis palabras|Añadir una palabra|Palabra o frase|Significado|Frase de ejemplo|Buscar en internet|No se encontró nada|Añadido al diccionario|Guardar|Buscar en el diccionario…|En otros idiomas|palabras|Fuente',
        zh: '词典|我的单词|添加单词|单词或短语|意思|例句|在线搜索|没有找到|已添加到词典|保存|搜索词典…|其他语言|个词|来源', ko: '사전|내 단어|단어 추가|단어 또는 표현|뜻|예문|온라인 검색|결과가 없습니다|사전에 추가되었습니다|저장|사전에서 검색…|다른 언어|단어|출처'
    }
];
EXTRA.forEach(g => {
    const ks = g.k.split('|');
    Object.keys(LANGS).forEach(l => g[l].split('|').forEach((v, i) => {
        T[l][ks[i]] = v;
    }));
});
/* UI strings carry no emoji: icons are drawn by the icon system */
Object.keys(T).forEach(l => Object.keys(T[l]).forEach(k => {
    T[l][k] = T[l][k].replace(/\s*(\p{Extended_Pictographic}\uFE0F?)+\s*/gu, ' ').trim();
}));
