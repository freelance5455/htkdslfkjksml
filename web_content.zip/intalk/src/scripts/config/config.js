/**
 * Configuration. WORKER_URL: Cloudflare Worker used as the AI proxy (POST {system, messages} ->
 * {content:[{text}]}). It only works when the game is hosted on your own site/domain (Claude-hosted
 * artifact pages block outside requests; there the game automatically falls back to the built-in
 * Claude connection). Set to '' to use only the built-in Claude connection. Never put API keys here -
 * keep them in the Worker's secrets.
 *
 * Provides: WORKER_URL
 */
const WORKER_URL = 'https://intalk2.intigamrahimov.workers.dev';
