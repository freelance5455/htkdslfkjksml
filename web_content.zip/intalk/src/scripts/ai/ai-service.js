/**
 * AI service: rate-limited access to the Claude "sample" capability + global game state
 *
 * Provides: scanJson, repairJson, parse, extractText, SYS_JSON, viaWorker, Game
 */
/* tolerant JSON reader: strips markdown fences, ignores text around the JSON, repairs truncated output */
function scanJson(s) {
    const st = [];
    let str = false, esc = false;
    for (let i = 0; i < s.length; i++) {
        const c = s[i];
        if (str) {
            if (esc)
                esc = false;
            else if (c === '\\')
                esc = true;
            else if (c === '"')
                str = false;
            continue;
        }
        if (c === '"')
            str = true;
        else if (c === '{' || c === '[')
            st.push(c);
        else if (c === '}' || c === ']') {
            st.pop();
            if (!st.length)
                return {
                    end: i + 1, st, str
                };
        }
    }
    return {
        end: -1, st, str
    };
}
function repairJson(s) {
    const cuts = [s.length];
    for (let i = s.length - 1, k = 0; i > 0 && k < 60; i--) {
        if (s[i] === ',' || s[i] === '}' || s[i] === ']') {
            cuts.push(i + (s[i] === ',' ? 0 : 1));
            k++;
        }
    }
    for (const c of cuts) {
        const p = s.slice(0, c).replace(/,\s*$/, ''), r = scanJson(p);
        if (r.end > 0) {
            try {
                return JSON.parse(p.slice(0, r.end));
            } catch {
            }
            continue;
        }
        let q = p + (r.str ? '"' : '');
        q = q.replace(/,\s*$/, '').replace(/:\s*$/, ':null') + r.st.slice().reverse().map(x => x === '{' ? '}' : ']').join('');
        try {
            return JSON.parse(q);
        } catch {
        }
    }
    return null;
}
const parse = t => {
    t = String(t || '').replace(/```(?:json)?/gi, '');
    try {
        return JSON.parse(t.trim());
    } catch {
    }
    const a = t.search(/[\[{]/);
    if (a < 0)
        return null;
    const s = t.slice(a), r = scanJson(s);
    if (r.end > 0)
        try {
            return JSON.parse(s.slice(0, r.end));
        } catch {
        }
    return repairJson(s);
};
/* reads the answer text from the common worker/API response shapes */
function extractText(d) {
    if (!d)
        return '';
    const c = d.content;
    if (typeof c === 'string')
        return c;
    if (Array.isArray(c)) {
        const t = c.map(x => typeof x === 'string' ? x : (x && (x.text || (typeof x.content === 'string' ? x.content : ''))) || '').join('');
        if (t)
            return t;
    }
    const ch = d.choices && d.choices[0];
    if (ch) {
        const m = (ch.message && ch.message.content) || ch.text;
        if (typeof m === 'string')
            return m;
        if (Array.isArray(m))
            return m.map(x => x.text || '').join('');
    }
    for (const k of ['completion', 'text', 'reply', 'response', 'message', 'output', 'result', 'answer'])
        if (typeof d[k] === 'string' && d[k])
            return d[k];
    return d.data ? extractText(d.data) : '';
}
const SYS_JSON = 'Reply with valid JSON only: no markdown fences, no explanations, no text before or after the JSON.';
async function viaWorker(prompt, json) {
    let res;
    try {
        res = await fetch(WORKER_URL, {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({
                system: json ? SYS_JSON : '', messages: [
                    {
                        role: 'user', content: prompt
                    }
                ], max_tokens: 3000
            })
        });
    } catch (e) {
        throw {
            code: 'network', message: 'Worker is unreachable'
        };
    }
    let d = null, raw = '';
    try {
        raw = await res.text();
        d = JSON.parse(raw);
    } catch (e) {
    }
    Game.lastBody = 'HTTP ' + res.status + ' ' + raw.slice(0, 400);
    if (!res.ok || !d || d.error) {
        const m = String((d && d.error && (d.error.message || d.error)) || 'HTTP ' + res.status + ' ' + raw.slice(0, 120));
        throw {
            code: res.status === 429 || /limit|rate|quota/i.test(m) ? 'rate_limited' : 'worker_error', message: m
        };
    }
    const text = extractText(d);
    if (!String(text).trim())
        throw {
            code: 'empty_response', message: 'Worker answered HTTP ' + res.status + ' but the text is empty. Body: ' + raw.slice(0, 200)
        };
    return {
        text, truncated: (d.stop_reason || d.stopReason) === 'max_tokens'
    };
}
const Game = {
    sample: null, p: null, seq: 0,
    reset(p) {
        Object.assign(this, {
            p, npcs: {}, people: {}, narr: {}, threads: {}, friends: [], places: [], seen: {}, loading: {}, view: 'map', place: null, cur: null, city: '', work: null,
            news: null, know: {}, groups: {}, grp: null, gd: {}, tutor: [], songs: {}, q: '', cat: 'all'
        });
    },
    clock(d) {
        d = d || new Date();
        const h = d.getHours(), part = h < 5 ? 'night' : h < 12 ? 'morning' : h < 17 ? 'afternoon' : h < 22 ? 'evening' : 'night';
        return {
            h, part, text: d.toLocaleDateString('en-US', { weekday: 'long' }) + ' ' + String(h).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0') + ' (' + part + ')'
        };
    },
    async call(p, json) {
        const now = Date.now(), at = Math.max(now, this.next || 0);
        this.next = at + 1500;
        if (at > now)
            await new Promise(r => setTimeout(r, at - now));
        for (let n = 0;; n++) {
            try {
                return await this.send(p, json);
            } catch (e) {
                this.lastErr = (e.code || '') + ' ' + (e.message || '');
                if (e.code === 'rate_limited' && n < 2) {
                    await new Promise(r => setTimeout(r, 6000 * (n + 1)));
                    continue;
                }
                throw e;
            }
        }
    },
    /* worker first (if configured), built-in Claude connection as fallback */
    async send(p, json) {
        if (WORKER_URL && !this.noWorker) {
            try {
                return await viaWorker(p, json);
            } catch (e) {
                if (e.code === 'network')
                    this.noWorker = true;
                if (!this.sample)
                    throw e;
            }
        }
        if (!this.sample)
            throw {
                code: 'no_ai', message: 'AI is not connected'
            };
        return this.sample(p, { cache: false });
    },
    async ask(prompt, strict) {
        let o, r = null;
        for (let i = 0; i < 2 && !r; i++) {
            o = await this.call(i ? prompt + '\n\nIMPORTANT: reply with COMPLETE, COMPACT, valid JSON only (no markdown, no extra text) and keep every text field as short as possible.' : prompt, true);
            this.lastRaw = o.text;
            r = parse(o.text);
        }
        if (!r) {
            const raw = String(o.text || '');
            this.lastErr = 'Bad AI format (' + raw.length + ' chars' + (o.truncated ? ', truncated' : '') + '): ' + raw.slice(0, 200);
            if (strict)
                throw {
                    message: 'Bad AI format: ' + raw.slice(0, 60) + '… (' + raw.length + (o.truncated ? ', truncated' : '') + ')'
                };
            r = {
                say: raw.replace(/[{}"]/g, ''), text: raw
            };
        }
        return r;
    },
    ctx() {
        const p = this.p, tg = LANGS[p.tgt][2], nt = LANGS[p.nat][2], fam = famRoles().map(k => T.en[k]).join(', ');
        return {
            tg, nt, L: `Learner: native ${nt}, learning ${tg}, CEFR ${p.lvl}. Player: ${p.nick}, age ${p.age}, ${p.gen === 'f' ? 'female' : 'male'}, ${p.marital === 'mr' ? 'married' : 'single'}, job/lifestyle: ${p.job}${fam ? '; family: ' + fam : ''}.`,
            sp: `All speech ONLY in ${tg}, strictly ${p.lvl} level${['zh', 'ko'].includes(p.tgt) && p.lvl < 'B' ? (p.tgt === 'zh' ? ' (add pinyin in parentheses)' : ' (add romanization in parentheses)') : ''}, 1-3 short sentences.`
        };
    }
};
