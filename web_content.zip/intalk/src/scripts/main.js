/**
 * Entry point
 *
 * Provides: applyTheme
 */
if ('speechSynthesis' in window)
    try {
        speechSynthesis.getVoices();
    } catch (e) {
    }
/* always start in light mode (the host page may pre-set a dark theme); the user's choice is saved */
const applyTheme = () => {
    document.documentElement.dataset.theme = Store.get('theme', 'light');
};
applyTheme();
window.addEventListener('load', () => {
    applyTheme();
    setTimeout(applyTheme, 400);
});
$('brandlogo').innerHTML = logo(32);
$('brandwm').innerHTML = wordmark();
/* static markup carries data-icon names; fill them from the icon set */
document.querySelectorAll('[data-icon]').forEach(el => {
    el.innerHTML = icon(el.dataset.icon, el.dataset.size ? +el.dataset.size : 20);
});
iconify(document.body);
Nav.init();
/* on-screen keyboard: when the visible area shrinks while a field is focused, give the layout the visible height and hide the nav bar */
(() => {
    const b = document.body, vv = window.visualViewport;
    let max = Math.max(innerHeight, vv ? vv.height : 0);
    const set = () => {
        const h = vv ? vv.height : innerHeight;
        if (h > max)
            max = h;
        document.documentElement.style.setProperty('--vh', h + 'px');
        const f = document.activeElement, typing = f && /INPUT|TEXTAREA/.test(f.tagName);
        b.classList.toggle('kb', !!typing && max - h > 140);
    };
    if (vv)
        vv.addEventListener('resize', set);
    addEventListener('resize', set);
    document.addEventListener('focusin', () => setTimeout(set, 120));
    document.addEventListener('focusout', () => setTimeout(set, 250));
    set();
})();
boot();
