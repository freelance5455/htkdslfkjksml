/**
 * Back button: never leaves the app by accident. One "sentinel" history entry is always re-armed, so
 * the phone's Back key steps out of the current layer (dialog -> level card -> recording -> phone
 * screen -> phone -> chat -> place -> map -> wizard step). At the very start a second press within 2 s
 * lets the app exit.
 *
 * Provides: Nav
 */
const Nav = {
    last: 0, needArm: false,
    arm() {
        try {
            history.pushState({ intalk: 1 }, '', location.href);
        } catch (e) {
        }
        this.needArm = false;
    },
    init() {
        try {
            history.replaceState({ intalk: 0 }, '', location.href);
        } catch (e) {
        }
        this.arm();
        window.addEventListener('popstate', () => this.onPop());
        window.addEventListener('pointerdown', () => {
            if (this.needArm)
                this.arm();
        }, true);
    },
    onPop() {
        if (this.back()) {
            this.arm();
            return;
        }
        const now = Date.now();
        if (now - this.last < 2000) {
            this.last = 0;
            this.needArm = true;
            return;
        }
        this.last = now;
        toast('chevL', t('bexit'));
        this.arm();
    },
    back() {
        const dlg = document.querySelector('.dlg');
        if (dlg) {
            dlg.remove();
            return true;
        }
        const cel = document.querySelector('.cel');
        if (cel) {
            cel.remove();
            return true;
        }
        if (Voice.rec) {
            Voice.stopRec();
            return true;
        }
        if (Ph.on)
            return Ph.back();
        if (!$('game').classList.contains('on')) {
            if (step > 0) {
                step--;
                renderSetup();
                return true;
            }
            if (S.done && Game.p) {
                cancelEdit();
                return true;
            }
            return false;
        }
        if (Game.view === 'chat') {
            Game.view = 'place';
            Game.grp = null;
            render();
            return true;
        }
        if (Game.view === 'place') {
            Game.view = 'map';
            render();
            return true;
        }
        return false;
    }
};
