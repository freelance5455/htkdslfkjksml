/**
 * Main screens (e-commerce style): places grid, people grid, chat. Header search, breadcrumb, nav
 * wiring
 *
 * Provides: PHN, catOf, CATC, tree, TSL, DES, crs, flatB, mapSvg, chatBar, render, head
 */
const PHN = {
    az: 'Telefon', tr: 'Telefon', ru: 'Телефон', en: 'Phone', de: 'Handy', es: 'Teléfono', zh: '手机', ko: '전화'
};
const catOf = p => p.host ? 'frd' : p.id === 'home' ? 'home' : p.work ? 'work' : 'pub', CATS = ['all', 'home', 'work', 'pub', 'frd'];
/* NAVIGATION-STYLE MAP: roads, blocks with 3D buildings, parks, forests, ponds/lakes and a river. Every place sits on its own block as a coloured pin. */
const CATC = {
    home: '#0a7cff', work: '#0b1a30', food: '#f59e0b', shop: '#8b5cf6', health: '#ef4444', transport: '#0891b2', culture: '#14b8a6', service: '#64748b', nature: '#16a34a', fun: '#ec4899'
};
const tree = (x, y, r, c) => `<g class="m-tree"><circle cx="${x}" cy="${y}" r="${r}" fill="${c || '#7fbf7a'}"/><circle cx="${x - r * .25}" cy="${y - r * .3}" r="${r * .6}" fill="#a4d99d"/></g>`;
/* NEIGHBOURHOOD MAP: simple navigator style. ONE connected road network: three long vertical roads run through the whole map and every
   horizontal road passes exactly through their junctions, so nothing is left dangling. Tiles (8 places each) alternate between two layouts. */
const TSL = [[48, 58], [148, 48], [300, 70], [112, 138], [232, 146], [44, 212], [160, 226], [286, 222]], VX = [80, 180, 280];
const DES = [
    {
        m: [[84, 62], [190, 84], [278, 96]], s: [[92, 196], [188, 204], [276, 200]], me: [40, 100], se: [214, 188]
    }, {
        m: [[76, 112], [182, 92], [284, 128]], s: [[88, 222], [178, 236], [272, 214]], me: [78, 150], se: [196, 250]
    }
];
const crs = pts => {
    const f = n => n.toFixed(1);
    let d = 'M' + f(pts[0][0]) + ' ' + f(pts[0][1]);
    for (let i = 0; i < pts.length - 1; i++) {
        const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
        d += 'C' + f(p1[0] + (p2[0] - p0[0]) / 6) + ' ' + f(p1[1] + (p2[1] - p0[1]) / 6) + ' ' + f(p2[0] - (p3[0] - p1[0]) / 6) + ' ' + f(p2[1] - (p3[1] - p1[1]) / 6) + ' ' + f(p2[0]) + ' ' + f(p2[1]);
    }
    return d;
};
const flatB = (x, y, w, h) => `<rect class="m-bld" x="${x}" y="${y}" width="${w}" height="${h}" rx="4" fill="#e4e9ef" stroke="#d3dae3"/>`;
function mapSvg(ok) {
    const pls = Game.places, T = Math.max(2, Math.ceil(pls.length / 8)), H = T * 300 + 24, F = 'font-family="Inter,system-ui,sans-serif"', un = p => (Game.people[p] || []).reduce((a, i) => a + Game.npcs[i].unread, 0);
    let under = '', pins = '';
    const vert = [[[80, -10]], [[180, -10]], [[280, -10]]], mains = [], streets = [];
    for (let k = 0; k < T; k++) {
        const oy = k * 300 + 12, D = DES[k % 2], G = x => `<g transform="translate(0,${oy})">${x}</g>`;
        for (let i = 0; i < 3; i++)
            vert[i].push([VX[i], oy], [D.m[i][0], oy + D.m[i][1]], [D.s[i][0], oy + D.s[i][1]]);
        mains.push([[-10, oy + D.me[0]], ...D.m.map(p => [p[0], oy + p[1]]), [370, oy + D.me[1]]]);
        streets.push([[-10, oy + D.se[0]], ...D.s.map(p => [p[0], oy + p[1]]), [370, oy + D.se[1]]]);
        let u = `<g class="m-park"><path d="M-6 110C20 94 70 98 88 122C100 146 70 176 30 174C0 172 -10 140 -6 110z" fill="#d7edd0"/></g>${[[16, 128], [40, 112], [62, 126], [34, 150], [64, 152]].map(t => tree(t[0], t[1], 6)).join('')}<g class="m-water"><ellipse cx="214" cy="116" rx="30" ry="12" fill="#bfdcf5"/><ellipse cx="210" cy="114" rx="16" ry="4" fill="#dcecfb"/></g>`;
        if (k % 2 === 0)
            u += `<g class="m-water"><path d="M-10 288C80 268 150 308 230 288S330 268 370 290" stroke="#bfdcf5" stroke-width="24" fill="none" stroke-linecap="round"/></g>`;
        if (k % 2 === 1)
            u += `<g class="m-forest"><path d="M300 262C318 250 360 252 366 272C370 292 330 302 306 296C288 290 284 272 300 262z" fill="#b8dbb0"/>${[[318, 268], [336, 262], [352, 272], [322, 284], [342, 288], [308, 280]].map(t => tree(t[0], t[1], 6, '#6fb273')).join('')}</g>`;
        u += [
            [14, 96, 26, 20], [130, 112, 24, 18], [176, 172, 22, 18], [326, 126, 24, 20], [206, 258, 24, 16], [330, 172, 22, 18], [14, 250, 24, 18], [236, 262, 20, 14]
        ].map(b => flatB(...b)).join('');
        under += G(u);
        for (let i = 0; i < 8; i++) {
            const p = pls[k * 8 + i];
            if (!p)
                continue;
            const x = TSL[i][0], y = oy + TSL[i][1], pp = P(p.id), dim = ok(p) ? 1 : .25, uu = un(p.id), cur = Game.place === p.id, nm = String(pp.n).slice(0, 13), w = Math.max(34, nm.length * 6.2 + 16), cat = p.work ? 'work' : (KINDS[p.kind] || {}).cat || 'service', pc = CATC[cat] || '#0a7cff', lx = Math.max(4 - x, Math.min(-w / 2, 356 - x - w));
            pins += `<g class="mk" data-place="${p.id}" transform="translate(${x},${y})" opacity="${dim}"><circle r="26" fill="#fff" fill-opacity="0"/>${cur ? `<circle class="pulse" r="22" fill="none" stroke="${pc}" stroke-width="3"/>` : ''}<ellipse cx="0" cy="19" rx="9" ry="3" fill="#0b1a30" opacity=".16"/><path d="M-6 9L0 20 6 9z" fill="${pc}"/><circle r="13" fill="${pc}" stroke="#fff" stroke-width="2.5"/><g transform="translate(-7.5 -7.5) scale(.62)" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round">${ICON_INNER(EMOJI_ICON[String(p.e).replace(/\uFE0F/g, '')] || 'building')}</g><rect x="${lx}" y="25" width="${w}" height="16" rx="8" fill="#fff" stroke="#e1e9f5"/><text x="${lx + w / 2}" y="36.5" text-anchor="middle" font-size="10" font-weight="700" fill="#0b1a30" ${F}>${esc(nm)}</text>${uu ? `<circle cx="13" cy="-12" r="8" fill="#ef4444" stroke="#fff" stroke-width="1.5"/><text x="13" y="-8.5" text-anchor="middle" font-size="10" font-weight="800" fill="#fff" ${F}>${uu}</text>` : ''}${p.work ? `<circle cx="-13" cy="-12" r="7" fill="#0b1a30" stroke="#fff" stroke-width="1.5"/><g transform="translate(-17.3 -16.3) scale(.36)" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round">${ICON_INNER('briefcase')}</g>` : ''}</g>`;
        }
    }
    vert.forEach((v, i) => v.push([VX[i], T * 300 + 12], [VX[i], H + 10]));
    const white = vert.concat(streets).map(crs).join(''), yel = mains.map(crs).join(''), rd = (d, c1, c2, w) => `<path class="m-road" d="${d}" stroke="${c1}" stroke-width="${w + 4}" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path class="m-road" d="${d}" stroke="${c2}" stroke-width="${w}" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`;
    return `<svg class="mapw" viewBox="0 0 360 ${H}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="map"><rect width="360" height="${H}" fill="#f3f5f8"/>${under}${rd(white, '#dbe2ea', '#fff', 9)}${rd(yel, '#f0cd7a', '#ffe9b0', 11)}${pins}</svg>`;
}
const chatBar = () => `<div id="bar"><button class="ib sm" id="cv" aria-label="speaker">${Voice.tts ? '🔊' : '🔇'}</button><input id="ci" autocomplete="off" placeholder="${esc(t('typ'))}"><button class="ib sm ${Voice.rec ? 'on' : ''} ${Voice.proc ? 'proc' : ''}" id="cm" aria-label="microphone">🎤</button><button class="btn" id="cs" aria-label="send">➤</button></div>`;
function render() {
    const v = Game.view, m = $('main'), n = Game.npcs[Game.cur], pl = Game.place, pd = pl ? P(pl) : null, q = (Game.q || '').toLowerCase().trim();
    head();
    $('game').dataset.v = v;
    const act = document.activeElement?.id === 'ci';
    $('bk').style.display = v === 'chat' ? 'inline-flex' : 'none';
    $('q').placeholder = t('search');
    $('q').closest('.search').style.display = v === 'chat' ? 'none' : '';
    const bc = [`<span class="bc" data-bc="map">${esc(t('hood'))}</span>`];
    if (v !== 'map' && pd)
        bc.push(`<span class="bc" data-bc="place">${esc(pd.e + ' ' + pd.n)}</span>`);
    if (v === 'chat' && Game.grp && Game.groups[Game.grp])
        bc.push(`<b>${esc(t('grp'))}</b>`);
    else if (v === 'chat' && n)
        bc.push(`<b>${esc(n.name)}</b>`);
    $('ttl').innerHTML = bc.join(' › ');
    $('nMapL').textContent = t('hood');
    $('nPlaceL').textContent = pd ? pd.n.slice(0, 14) : '—';
    $('nPhL').textContent = PHN[S.nat];
    $('nMap').classList.toggle('on', v === 'map' && !Ph.on);
    $('nPlace').classList.toggle('on', v !== 'map' && !Ph.on);
    $('bPh').classList.toggle('on', !!Ph.on);
    const here = Object.values(Game.npcs).filter(x => x.log.length && x.place === pl), wl = pl ? waitList(pl) : [];
    here.sort((a, b) => {
        const ia = wl.indexOf(a), ib = wl.indexOf(b);
        return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib);
    });
    $('chats').innerHTML = here.map(x => {
        const no = wl.indexOf(x) + 1;
        return `<div class="cc ${v === 'chat' && Game.cur === x.id ? 'on' : ''}" data-npc="${x.id}">${avatar(x.look, x.mood, 46, 2)}<div>${esc(x.name)}</div>${no && wl.length > 1 ? `<i class="qno">${no}</i>` : ''}${x.unread ? `<b class="dot">${x.unread}</b>` : ''}${x.pending ? '<div>…</div>' : ''}</div>`;
    }).join('') + grpStrip(pl, v);
    const wbar = skip => {
        const o = wl.filter(x => x.id !== skip), f = o[0];
        return f ? `<div class="waitbar" data-npc="${f.id}"><span class="wb-av">${avatar(f.look, f.mood, 40, 1)}</span><div><b>${esc(f.name)}</b><small>${esc(t('wait'))}${o.length > 1 ? ' · +' + (o.length - 1) : ''}</small></div><span class="btn s">${esc(t('reply'))}</span></div>` : '';
    };
    if (v === 'map') {
        const ok = p => (Game.cat === 'all' || catOf(p) === Game.cat) && (!q || P(p.id).n.toLowerCase().includes(q)), shown = Game.places.filter(ok).length;
        m.innerHTML = `<div class="pad"><div class="h2"><h2>${esc(t('hood'))}</h2><small>${shown}/${Game.places.length}</small></div><div class="cats">${CATS.map(c => `<button class="chip ${Game.cat === c ? 'on' : ''}" data-cat="${c}">${esc(t(c))}</button>`).join('')}</div>${mapSvg(ok)}<p class="hint">${esc(t('hint'))}</p></div>`;
    } else if (v === 'place') {
        const ids = (Game.people[pl] || []).filter(i => {
            const x = Game.npcs[i];
            return !q || (x.name + ' ' + x.role).toLowerCase().includes(q);
        }).sort((a, b) => {
            const ia = wl.indexOf(Game.npcs[a]), ib = wl.indexOf(Game.npcs[b]);
            return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib);
        });
        m.innerHTML = `<div class="pad"><div class="h2"><h2>${pd.e} ${esc(pd.n)}</h2><small>${ids.length} ${esc(t('ppl'))}</small></div>${wbar(0)}${Game.narr[pl] ? `<p class="dim" style="margin:-6px 0 0">${esc(Game.narr[pl])}</p>` : ''}${Game.loading[pl] ? `<div class="ld">${mascot('wave', 96, 'bounce')}<div>${dots(load())}</div></div>` : ''}<div class="pgrid">${ids.map(i => {
            const x = Game.npcs[i];
            return `<button class="pcard who ${x.unread ? 'hi' : ''}" data-npc="${i}"><div class="pav">${avatar(x.look, x.mood, 200, 2)}</div><div class="pc-b"><b>${esc(x.name)}</b><small>${esc(x.role)}</small>${waitNo(x) ? `<div class="${waitNo(x) === 1 && wl.length > 1 ? 'qfirst' : 'qwait'}">${esc(t(waitNo(x) === 1 && wl.length > 1 ? 'first' : 'wait'))}</div>` : ''}${x.unread ? `<div class="pbub">${esc(x.log.at(-1)?.text || '')}</div>` : ''}</div>${waitNo(x) && wl.length > 1 ? `<i class="qno">${waitNo(x)}</i>` : ''}${x.unread ? `<i class="dot" style="top:8px;right:8px">${x.unread}</i>` : ''}<span class="btn ${x.unread ? '' : 'o'} s">${esc(t('talk'))}</span></button>`;
        }).join('')}${Game.loading[pl] ? '<div class="skel"></div><div class="skel"></div>' : ''}</div>${ids.length >= 2 ? `<button class="btn g" data-gdlg="1">${icon('users', 18)}${esc(t('grp'))}</button>` : ''}${pd.kind === 'home' ? '' : `<button class="btn g" data-more="1" ${Game.loading[pl] ? 'disabled' : ''}>${icon('eye', 18)}${esc(t('look'))}</button>`}</div>`;
    } else if (v === 'chat' && Game.grp && Game.groups[Game.grp]) {
        const g = Game.groups[Game.grp], ms = Groups.members(g), pn = P(g.place), col = id => `hsl(${hash(String(id)) % 360} 62% 36%)`;
        m.innerHTML = `<div class="chat"><aside class="vn gvn"><div class="gav">${ms.map(x => `<span class="gav-i" title="${esc(x.name)}">${avatar(x.look, x.mood, 64, 1)}</span>`).join('')}</div><div class="vn-info"><b>${esc(ms.map(x => x.name).join(', '))}</b><span>${esc(t('grp'))} · ${ms.length}</span><span>${esc(pn.e + ' ' + pn.n)}</span></div>${(Game.people[g.place] || []).length > ms.length ? `<button class="btn s g gbtn" data-gadd="1" aria-label="add">${icon('plus', 16)}</button>` : ''}</aside><section class="sheet"><div class="pad" id="log">${g.log.map((x, i) => x.who === 'me' ? `<div class="you">${esc(x.text)}</div>${mistakeHtml(x.note)}` : x.who === 'sys' ? `<div class="${/⚠/.test(x.text) ? 'err' : 'gsys'}">${esc(x.text)}</div>` : `<div class="nb"><b class="sn" style="color:${col(x.npc)}">${esc((Game.npcs[x.npc] || {}).name || '')}</b>${esc(x.text)}<button class="spk" data-gsay="${i}" aria-label="play">${icon('speaker', 15)}</button></div>`).join('')}${g.pending ? `<div class="dim">${dots()}</div>` : ''}</div>${chatBar()}</section></div>`;
        $('ci').value = g.draft;
        if (act)
            $('ci').focus();
        const l = $('log');
        l.scrollTop = l.scrollHeight;
    } else if (n) {
        const pn = P(n.place);
        m.innerHTML = `<div class="chat"><aside class="vn"><div class="vn-img">${avatar(n.look, n.mood, 200, 2)}</div><div class="vn-info"><b>${esc(n.name)}</b><span>${esc(n.role)}</span><span>${esc(pn.e + ' ' + pn.n)}</span></div>${(Game.people[n.place] || []).length > 1 ? `<button class="btn s g gbtn" data-gadd="1" aria-label="group">${icon('users', 16)}</button>` : ''}</aside><section class="sheet">${wbar(n.id)}<div class="pad" id="log">${n.log.map(x => x.who === 'me' ? `<div class="you">${esc(x.text)}</div>${mistakeHtml(x.note)}` : x.who === 'sys' ? `<div class="err">${esc(x.text)}</div>` : `<div class="nb">${esc(x.text)}<button class="spk" data-say="${n.log.indexOf(x)}" aria-label="play">${icon('speaker', 15)}</button></div>`).join('')}${n.pending ? `<div class="dim">${dots()}</div>` : ''}</div>${chatBar()}</section></div>`;
        $('ci').value = n.draft;
        if (act)
            $('ci').focus();
        const l = $('log');
        l.scrollTop = l.scrollHeight;
    }
}
function head() {
    const i = Progress.info(), n = Streak.n(), on = Streak.doneToday(), C = 75.4;
    $('streak').innerHTML = `<span class="hs f ${on ? 'on' : ''}">${icon('flame', 17)}<b>${n}</b></span><span class="hs l"><svg width="32" height="32" viewBox="0 0 32 32" aria-hidden="true"><circle cx="16" cy="16" r="12" fill="none" stroke="var(--line)" stroke-width="3.4"/><circle cx="16" cy="16" r="12" fill="none" stroke="var(--blue)" stroke-width="3.4" stroke-linecap="round" stroke-dasharray="${(C * i.p).toFixed(1)} ${C}" transform="rotate(-90 16 16)"/><text x="16" y="20.2" text-anchor="middle" font-size="12" font-weight="800" fill="currentColor">${i.l}</text></svg></span>`;
    const u = unreadTotal();
    $('phN').style.display = u ? 'inline-flex' : 'none';
    $('phN').textContent = u;
}
$('main').addEventListener('click', e => {
    const wb = e.target.closest('.waitbar'), ga = e.target.closest('[data-gadd]'), gd = e.target.closest('[data-gdlg]'), gs = e.target.closest('[data-gsay]'), sp = e.target.closest('[data-say]'), p = e.target.closest('[data-place]'), n = e.target.closest('[data-npc]'), c = e.target.closest('[data-cat]'), id = e.target.closest('button')?.id;
    if (ga) {
        const g = Game.grp && Game.groups[Game.grp];
        groupDlg(g ? g.members : [Game.cur]);
    } else if (gd) {
        groupDlg([]);
    } else if (gs) {
        const g = Game.groups[Game.grp], x = g && g.log[+gs.dataset.gsay], o = x && Game.npcs[x.npc];
        if (o)
            Voice.speak(x.text, o);
    } else if (wb) {
        openChat(wb.dataset.npc);
    } else if (sp) {
        const o = Game.npcs[Game.cur], m = o && o.log[+sp.dataset.say];
        if (m)
            Voice.speak(m.text, o);
    } else if (c) {
        Game.cat = c.dataset.cat;
        render();
    } else if (p)
        enterPlace(p.dataset.place);
    else if (n)
        openChat(n.dataset.npc);
    else if (e.target.closest('[data-more]')) {
        if (!Game.loading[Game.place])
            enterPlace(Game.place, true);
    } else if (id === 'cs') {
        sendNpc();
        if (document.body.classList.contains('kb'))
            setTimeout(() => {
                const i = $('ci');
                if (i && Game.view === 'chat')
                    i.focus();
            }, 40);
    } else if (id === 'cm')
        Voice.listen();
    else if (id === 'cv')
        Voice.toggleTts();
});
$('chats').addEventListener('click', e => {
    const gg = e.target.closest('[data-grp]');
    if (gg) {
        const g = Game.groups[gg.dataset.grp];
        if (g)
            Groups.open(g.members);
        return;
    }
    const n = e.target.closest('[data-npc]');
    if (n)
        openChat(n.dataset.npc);
});
$('ttl').addEventListener('click', e => {
    const c = e.target.closest('[data-bc]');
    if (!c)
        return;
    Game.view = c.dataset.bc === 'map' ? 'map' : 'place';
    render();
});
$('q').addEventListener('input', e => {
    Game.q = e.target.value;
    if (Game.view !== 'chat')
        render();
});
$('main').addEventListener('input', e => {
    if (e.target.id !== 'ci')
        return;
    const o = Game.grp ? Game.groups[Game.grp] : Game.npcs[Game.cur];
    if (o)
        o.draft = e.target.value;
});
$('main').addEventListener('keydown', e => {
    if (e.key === 'Enter' && e.target.id === 'ci')
        sendNpc();
});
$('streak').onclick = () => Ph.open('profile');
$('bk').onclick = () => {
    Game.view = 'place';
    Game.grp = null;
    render();
};
$('nMap').onclick = () => {
    Ph.close();
    Game.view = 'map';
    render();
};
$('nPlace').onclick = () => {
    Ph.close();
    if (Game.place) {
        Game.view = 'place';
        render();
    }
};
$('bPh').onclick = () => {
    if (!Ph.on)
        Ph.open('home');
};
