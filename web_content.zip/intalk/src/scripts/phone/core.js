/**
 * Phone core: app registry, device shell, home screen, event dispatch. An app = reg({id, icon, color,
 * name(), order, home|dock, badge(), onOpen(c), draw({top,c}), click(e,q), key(e)})
 *
 * Provides: Apps, Ph, homeHtml
 */
const Apps = {};
const reg = a => {
    Apps[a.id] = a;
    return a;
};
const Ph = {
    on: false, view: 'home', cur: null,
    open(v, c) {
        this.on = true;
        this.go(v, c);
        $('ov').style.display = 'flex';
    },
    close() {
        if (!this.on)
            return;
        this.on = false;
        $('ov').style.display = 'none';
    },
    go(v, c) {
        this.view = v;
        this.cur = c || null;
        if (Apps[v] && Apps[v].onOpen)
            Apps[v].onOpen(c);
        this.draw();
        head();
    },
    /* Back inside the phone: previous screen, or close from the home screen */
    back() {
        if (!this.on)
            return false;
        if (this.view === 'home') {
            this.close();
            return true;
        }
        this.go(this.parent || ({ thread: 'messages' })[this.view] || 'home');
        return true;
    },
    draw() {
        const el = $('scr'), v = this.view, app = Apps[v], pv = $('pm')?.value || '', now = new Date().toLocaleTimeString([], {
            hour: '2-digit', minute: '2-digit'
        });
        this.parent = null;
        const top = (title, back, extra) => {
            this.parent = back || null;
            return `<div class="ptop">${back ? `<button data-go="${back}">‹</button>` : ''}<span>${title}</span>${extra || ''}</div>`;
        };
        const body = v === 'home' ? homeHtml() : app ? app.draw({
            top, c: this.cur
        }) : '';
        el.dataset.v = v;
        if (v === 'home') {
            const w = Wall.get();
            el.style.background = w.css;
            el.dataset.lt = w.light ? '1' : '0';
            el.dataset.img = w.img ? '1' : '0';
        } else {
            el.style.background = '';
            el.dataset.lt = '0';
            el.dataset.img = '0';
        }
        el.innerHTML = `<div class="sb"><span>${now}</span><span class="sbi">${icon('signal', 15)}${icon('battery', 17)}</span></div>${body}<div class="home" data-go="home"></div>`;
        if (typeof Music !== 'undefined' && Music.cur && Music.ctx)
            Music.ui();
        const pm = $('pm');
        if (pm && pv) {
            pm.value = pv;
            pm.focus();
        }
        const pb = $('pb');
        if (pb)
            pb.scrollTop = pb.scrollHeight;
    }
};
function homeHtml() {
    const apps = Object.values(Apps).filter(a => a.home || a.dock).sort((a, b) => (a.order || 0) - (b.order || 0)), d = new Date();
    const ic = (a, lab) => {
        const inner = `<i>${a.icon}</i>${lab ? esc(a.name()) : ''}${a.badge && a.badge() ? `<b class="dot" style="top:-4px;right:2px">${a.badge()}</b>` : ''}`;
        return a.href ? `<a class="app" href="${esc(a.href)}" target="_blank" rel="noopener noreferrer">${inner}</a>` : `<button class="app" data-go="${a.id}"${a.c ? ` data-c="${esc(a.c)}"` : ''}>${inner}</button>`;
    };
    const grid = apps.filter(a => a.home).map(a => ic(a, 1));
    return `<div class="wid"><div class="tm">${d.toLocaleTimeString([], {
        hour: '2-digit', minute: '2-digit'
    })}</div><div>${d.toLocaleDateString(S.tgt, {
        weekday: 'long', day: 'numeric', month: 'long'
    })}</div><div class="wr">${icon('flame', 14)} ${Streak.n()} &nbsp; ${icon('bolt', 14)} ${Progress.xp()} XP &nbsp; Lv ${Progress.level()}${typeof Music !== 'undefined' && Music.cur ? ` &nbsp; ${icon('music', 14)} ${esc(Music.cur.title)}` : ''}</div></div><div class="pb"><div class="apps">${grid.join('')}</div></div><div class="dock">${apps.filter(a => a.dock).map(a => ic(a, 0)).join('')}</div>`;
}
$('scr').addEventListener('click', e => {
    const q = s => e.target.closest(s), g = q('[data-go]');
    if (g)
        return Ph.go(g.dataset.go, g.dataset.c);
    for (const a of Object.values(Apps))
        if (a.click && a.click(e, q) === true)
            return;
});
$('scr').addEventListener('keydown', e => {
    if (e.key !== 'Enter')
        return;
    for (const a of Object.values(Apps))
        if (a.key && a.key(e) === true)
            return;
});
$('ov').addEventListener('click', e => {
    if (e.target.id === 'ov')
        Ph.close();
});
document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && Ph.on)
        Ph.close();
});
