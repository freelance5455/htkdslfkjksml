/**
 * Phone wallpapers: InTalk mascot scenes (embedded WebP) + plain colours
 *
 * Provides: WALLS, WALL_COLORS, Wall
 */
const WALLS = ASSETS.wallpapers; // images come from src/assets/wallpapers/*.webp (embedded by tools/build.js)
const WALL_COLORS = [
    {
        id: 'c-blue', css: 'linear-gradient(160deg,#0a7cff 0%,#2fa4ff 55%,#8fe0ff 100%)'
    }, {
        id: 'c-sky', css: 'linear-gradient(160deg,#9fd0ff,#e3f1ff)', light: 1
    }, {
        id: 'c-white', css: 'linear-gradient(180deg,#ffffff,#eef3fa)', light: 1
    }, {
        id: 'c-navy', css: 'linear-gradient(160deg,#06214a,#0a4aa0 60%,#1479d6)'
    }, {
        id: 'c-black', css: 'linear-gradient(180deg,#0b1220,#1b2740)'
    }, {
        id: 'c-pink', css: 'linear-gradient(160deg,#ff5fa2,#ff9ccc 60%,#ffd1e6)'
    }, {
        id: 'c-purple', css: 'linear-gradient(160deg,#4b2bd6,#8b5cf6 60%,#c4b5fd)'
    }, {
        id: 'c-gray', css: 'linear-gradient(180deg,#e5e9f0,#cfd6e2)', light: 1
    }
];
const Wall = {
    get() {
        const id = Store.get('wall', 'c-blue');
        if (WALLS[id])
            return {
                id, css: `linear-gradient(rgba(5,15,35,.18),rgba(5,15,35,.5)),url(${WALLS[id]}) center/cover no-repeat`, light: false, img: true
            };
        const c = WALL_COLORS.find(x => x.id === id) || WALL_COLORS[0];
        return {
            id: c.id, css: c.css, light: !!c.light
        };
    },
    set(id) {
        Store.set('wall', id);
    }
};
