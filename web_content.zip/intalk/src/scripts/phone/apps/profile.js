/**
 * App: Profile - rank and level, XP bar, daily goal, streak week, achievements
 *
 * Provides: ring, app:profile
 */
const ring = (p, sz, sw, inner) => {
    const r = (sz - sw) / 2, c = 2 * Math.PI * r;
    return `<svg class="pring" width="${sz}" height="${sz}" viewBox="0 0 ${sz} ${sz}"><circle cx="${sz / 2}" cy="${sz / 2}" r="${r}" fill="none" stroke="var(--psh)" stroke-width="${sw}"/><circle cx="${sz / 2}" cy="${sz / 2}" r="${r}" fill="none" stroke="var(--blue)" stroke-width="${sw}" stroke-linecap="round" stroke-dasharray="${(c * Math.min(1, p)).toFixed(1)} ${c.toFixed(1)}" transform="rotate(-90 ${sz / 2} ${sz / 2})"/>${inner || ''}</svg>`;
};
reg({
    id: 'profile', order: 21, home: true, icon: '👤', name: () => tp('prof'),
    draw({ top }) {
        const i = Progress.info(), sd = Streak.data(), n = Streak.n(), st = Stats(), day = Progress.today(), wk = Streak.week(), rows = ACH.map(a => ({
            a, on: a.ok(st)
        })), got = rows.filter(r => r.on).length;
        const wd = d => new Date(d + 'T00:00').toLocaleDateString(S.tgt, { weekday: 'narrow' });
        return top(tp('prof'), 'home') + `<div class="pb">
  <div class="pf pf-hero"><div class="pf-av">${avatar(myLook(), 'happy', 200, 2)}</div><div class="pf-id"><b>${esc(S.nick)}</b><span>${esc(tp(Progress.rankKey(i.l)))}</span><span class="pf-lang">${flag(S.nat, 15)} ${icon('chevR', 11)} ${flag(S.tgt, 15)} · ${esc(S.lvl)}</span></div><div class="pf-lv"><b>${i.l}</b><small>Lv</small></div></div>
  <div class="pf"><div class="pf-row"><b>${i.xp} XP</b><span class="dim">${i.l >= 50 ? 'MAX' : i.need + ' XP → Lv ' + (i.l + 1)}</span></div><div class="xpbar"><i style="width:${Math.round(i.p * 100)}%"></i></div></div>
  <div class="pf pf-goal">${ring(day / GOAL, 72, 8, `<g transform="translate(24 24)" fill="none" stroke="var(--blue)" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${ICON_INNER('bolt')}</g>`)}<div><b>${esc(tp('goal'))}</b><div class="dim">${Math.min(day, GOAL)} / ${GOAL} XP</div></div></div>
  <div class="pf"><div class="pf-row"><b class="pf-fl">${icon('flame', 20)} ${n}</b><span class="dim">${esc(tp('best'))}: ${sd.best || 0} &nbsp; ${icon('snow', 14)} ${sd.freeze || 0}</span></div><div class="wk">${wk.map(w => `<div class="wkd ${w.on ? 'on' : ''} ${w.today ? 'td' : ''}"><i>${w.on ? icon('check', 15) : ''}</i><span>${esc(wd(w.d))}</span></div>`).join('')}</div></div>
  <div class="pf"><div class="pf-row"><b>${esc(tp('ach'))}</b><span class="dim">${got}/${rows.length}</span></div><div class="achg">${rows.map(r => `<div class="ach ${r.on ? 'on' : ''}"><i>${icon(r.on ? r.a.ic : 'lock', 22)}</i><span>${r.a.lv ? 'Lv ' : ''}${r.a.n}</span></div>`).join('')}</div></div></div>`;
    }
});
