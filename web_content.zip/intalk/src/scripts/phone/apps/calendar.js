/**
 * App: Calendar (month view in the target language, personal events)
 *
 * Provides: isoD, addEvent, app:cal
 */
const isoD = d => d.toLocaleDateString('en-CA'), Cal = {
    y: new Date().getFullYear(), m: new Date().getMonth(), sel: isoD(new Date())
};
reg({
    id: 'cal', order: 12, home: true, icon: '📅', color: '#ff8fb1', name: () => tp('cal'),
    draw({ top }) {
        const ev = Store.get('cal', {}), first = new Date(Cal.y, Cal.m, 1), off = (first.getDay() + 6) % 7, days = new Date(Cal.y, Cal.m + 1, 0).getDate(), today = isoD(new Date()), sel = Cal.sel;
        const wd = [...Array(7)].map((_, i) => `<b>${new Date(2024, 0, 1 + i).toLocaleDateString(S.tgt, { weekday: 'narrow' })}</b>`).join('');
        const cells = [...Array(off)].map(() => '<button class="n"></button>').join('') + [...Array(days)].map((_, i) => {
            const iso = isoD(new Date(Cal.y, Cal.m, i + 1));
            return `<button data-cd="${iso}" class="${iso === today ? 't' : ''} ${iso === sel ? 's' : ''} ${(ev[iso] || []).length ? 'e' : ''}">${i + 1}</button>`;
        }).join('');
        return top('📅 ' + tp('cal'), 'home', '<button data-ctoday="1">' + esc(tp('today')) + '</button>') + `<div class="pb"><div class="row" style="justify-content:space-between;align-items:center"><button class="chip" data-cm="-1">‹</button><b style="font:800 18px var(--f)">${esc(first.toLocaleDateString(S.tgt, {
            month: 'long', year: 'numeric'
        }))}</b><button class="chip" data-cm="1">›</button></div><div class="cg">${wd}${cells}</div><b>${esc(new Date(sel + 'T00:00').toLocaleDateString(S.tgt, {
            weekday: 'long', day: 'numeric', month: 'long'
        }))}</b>${(ev[sel] || []).map((x, i) => `<div class="li" style="cursor:default"><div style="flex:1">${esc(x)}</div><button class="x" data-cdel="${i}">✕</button></div>`).join('')}<div id="bar" style="margin:0"><input id="cai" autocomplete="off" placeholder="${esc(tp('add'))}…"><button class="btn s" data-cadd="1">＋</button></div></div>`;
    },
    click(e, q) {
        if (Ph.view !== 'cal')
            return;
        const cd = q('[data-cd]'), cm = q('[data-cm]'), dl = q('[data-cdel]');
        if (cd) {
            Cal.sel = cd.dataset.cd;
            Ph.draw();
            return true;
        }
        if (cm) {
            const d = new Date(Cal.y, Cal.m + +cm.dataset.cm, 1);
            Cal.y = d.getFullYear();
            Cal.m = d.getMonth();
            Ph.draw();
            return true;
        }
        if (q('[data-ctoday]')) {
            const d = new Date();
            Cal.y = d.getFullYear();
            Cal.m = d.getMonth();
            Cal.sel = isoD(d);
            Ph.draw();
            return true;
        }
        if (q('[data-cadd]')) {
            addEvent();
            return true;
        }
        if (dl) {
            const ev = Store.get('cal', {});
            (ev[Cal.sel] = ev[Cal.sel] || []).splice(+dl.dataset.cdel, 1);
            Store.set('cal', ev);
            Ph.draw();
            return true;
        }
    },
    key(e) {
        if (Ph.view === 'cal' && e.target.id === 'cai') {
            addEvent();
            return true;
        }
    }
});
function addEvent() {
    const v = $('cai').value.trim();
    if (!v)
        return;
    const ev = Store.get('cal', {});
    (ev[Cal.sel] = ev[Cal.sel] || []).push(v);
    Store.set('cal', ev);
    Ph.draw();
}
