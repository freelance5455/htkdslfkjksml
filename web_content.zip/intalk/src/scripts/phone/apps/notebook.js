/**
 * App: Mistake notebook (delete one / clear all)
 *
 * Provides: app:notebook
 */
reg({
    id: 'notebook', order: 20, home: true, icon: '📝', color: '#ffd23f', name: () => tp('err'),
    draw({ top }) {
        const m = Store.get('mistakes', []);
        return top('📝 ' + tp('err') + ' (' + m.length + ')', 'home', m.length ? '<button data-clr="1">🗑</button>' : '') + `<div class="pb">${m.map((x, i) => [x, i]).reverse().map(([x, i]) => `<div class="li" style="display:block;cursor:default"><div style="display:flex"><div style="flex:1"><s style="color:var(--pbad)">${esc(x.wrong)}</s> → <b style="color:var(--pok)">${esc(x.right)}</b></div><button class="x" data-dm="${i}">✕</button></div><div class="dim">${esc(x.note)}</div></div>`).join('') || `<p class="dim" style="text-align:center">${tp('none')}</p>`}</div>`;
    },
    click(e, q) {
        const dm = q('[data-dm]');
        if (dm) {
            const m = Store.get('mistakes', []);
            m.splice(+dm.dataset.dm, 1);
            Store.set('mistakes', m);
            Ph.draw();
            return true;
        }
        if (q('[data-clr]')) {
            Store.set('mistakes', []);
            Ph.draw();
            return true;
        }
    }
});
