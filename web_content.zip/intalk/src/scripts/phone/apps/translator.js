/**
 * App: Translator (native <-> target language, pronunciation, example, speak)
 *
 * Provides: Tr, translate, app:trn
 */
const Tr = {
    dir: 1, h: [], busy: false, q: ''
};
reg({
    id: 'trn', order: 11, home: true, icon: '🌐', color: '#34c9a0', name: () => tp('trn'),
    draw({ top }) {
        const f = Tr.dir ? LANGS[S.nat] : LANGS[S.tgt], to = Tr.dir ? LANGS[S.tgt] : LANGS[S.nat];
        return top('🌐 ' + tp('trn'), 'home') + `<div class="pb"><div class="row" style="justify-content:center;align-items:center;gap:12px"><b>${flag(Tr.dir ? S.nat : S.tgt, 18)} ${f[0]}</b><button class="chip" data-trdir="1">⇄</button><b>${flag(Tr.dir ? S.tgt : S.nat, 18)} ${to[0]}</b></div><textarea id="tri" rows="3">${esc(Tr.q)}</textarea><button class="btn b" data-trgo="1">➤</button>${Tr.busy ? `<div class="dim" style="text-align:center">${dots(loadP())}</div>` : ''}${Tr.h.map((x, i) => [x, i]).reverse().map(([x, i]) => `<div class="li" style="display:block;cursor:default"><div class="dim">${esc(x.q)}</div><b style="font-size:18px">${esc(x.t)}</b>${x.p ? `<div class="dim">${esc(x.p)}</div>` : ''}<div>${esc(x.x)}</div><div class="dim">${esc(x.n)}</div><button class="chip" data-trsay="${i}" aria-label="speak">🔊</button></div>`).join('')}</div>`;
    },
    click(e, q) {
        if (Ph.view !== 'trn')
            return;
        const sy = q('[data-trsay]');
        if (q('[data-trdir]')) {
            Tr.q = $('tri').value;
            Tr.dir = Tr.dir ? 0 : 1;
            Ph.draw();
            return true;
        }
        if (q('[data-trgo]')) {
            translate();
            return true;
        }
        if (sy) {
            const x = Tr.h[+sy.dataset.trsay];
            Voice.speak(x.tg, null);
            return true;
        }
    }
});
async function translate() {
    const v = $('tri').value.trim();
    if (!v || Tr.busy)
        return;
    Tr.busy = 1;
    Tr.q = '';
    const dir = Tr.dir;
    Ph.draw();
    const c = Game.ctx(), from = dir ? c.nt : c.tg, to = dir ? c.tg : c.nt;
    try {
        const r = await Game.ask(`Translate "${v}" from ${from} to ${to}. Output ONLY JSON {"t":"translation","p":"pronunciation or romanization of the ${c.tg} text if ${c.tg} is not written in Latin script, else empty","x":"one short natural example sentence in ${c.tg} (${Game.p.lvl} level) using that ${c.tg} word or phrase","n":"a one-line usage note in ${c.nt}"}`, false);
        const t2 = String(r.t || r.say || '?');
        Tr.h.push({
            q: v, t: t2, p: r.p || '', x: r.x || '', n: r.n || '', tg: dir ? t2 : v
        });
    } catch (e) {
        Tr.h.push({
            q: v, t: '⚠️', p: '', x: e.message || '', n: '', tg: ''
        });
    }
    Tr.busy = 0;
    Ph.on && Ph.view === 'trn' && Ph.draw();
}
