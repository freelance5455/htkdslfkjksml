/**
 * App: Messages (conversation list + thread with delete)
 *
 * Provides: unreadThreads, sendPhone, app:messages, app:thread
 */
const unreadThreads = () => Object.values(Game.threads).reduce((a, x) => a + (x.unread || 0), 0);
reg({
    id: 'messages', order: 1, dock: true, icon: '💬', color: '#3aa8ff', name: () => tp('msg'), badge: unreadThreads,
    draw({ top }) {
        return top('💬 ' + tp('msg'), 'home') + `<div class="pb">${Object.keys(Game.threads).map(n => {
            const th = Game.threads[n], l = th.msgs.at(-1);
            return `<div class="li" data-go="thread" data-c="${esc(n)}">${avatar(th.look, 'happy', 40, 1)}<div style="flex:1;min-width:0"><b>${esc(n)}</b><div class="dim" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(l?.text || '…')}</div></div>${th.unread ? `<b class="dot" style="position:static">${th.unread}</b>` : ''}</div>`;
        }).join('') || `<div class="pmasc">${mascot('peace', 110)}<p class="dim">${tp('hint')}</p></div>`}</div>`;
    }
});
reg({
    id: 'thread',
    onOpen(c) {
        if (c && Game.threads[c])
            Game.threads[c].unread = 0;
    },
    draw({ c }) {
        const th = Game.threads[c] || {
            msgs: [], look: lookFor(c)
        };
        return `<div class="ptop"><button data-go="messages">‹</button>${avatar(th.look, 'happy', 34, 1)}<span>${esc(c)}</span><button data-dt="1" aria-label="${esc(tp('clr'))}">🗑</button></div><div class="pb" id="pb">${th.msgs.map((m, i) => `<div class="mb ${m.me ? 'me' : ''}">${esc(m.text)}<button class="x" data-dmsg="${i}">✕</button>${m.note ? `<div class="pn">${icon('note', 13)} ${m.note.map(x => `<s>${esc(x.wrong)}</s> → <b>${esc(x.right)}</b> · ${esc(x.note)}`).join('<br>')}</div>` : ''}</div>`).join('')}${th.pending ? `<div class="mb">${dots(tp('think'))}</div>` : ''}</div><div id="bar"><input id="pm" autocomplete="off" placeholder="${esc(tp('typ'))}"><button class="btn s" id="ps">➤</button></div>`;
    },
    click(e, q) {
        const th = Game.threads[Ph.cur], dg = q('[data-dmsg]');
        if (Ph.view !== 'thread')
            return;
        if (q('#ps')) {
            sendPhone();
            return true;
        }
        if (dg && th) {
            th.msgs.splice(+dg.dataset.dmsg, 1);
            Ph.draw();
            return true;
        }
        if (q('[data-dt]') && th) {
            th.msgs = [];
            Ph.draw();
            return true;
        }
    },
    key(e) {
        if (e.target.id === 'pm') {
            sendPhone();
            return true;
        }
    }
});
async function sendPhone() {
    const v = $('pm').value.trim(), to = Ph.cur, th = Game.threads[to];
    if (!v || th.pending)
        return;
    Streak.touch();
    th.msgs.push({
        me: 1, text: v
    });
    th.pending = true;
    Sfx.play('send');
    $('pm').value = '';
    Ph.draw();
    try {
        const r = await Game.ask(Game.phonePrompt(to, th), false), m = realMistakes(r.mistakes);
        Progress.msg(!m.length, 'phone');
        if (m.length) {
            saveMistakes(m);
            const l = [...th.msgs].reverse().find(x => x.me);
            if (l)
                l.note = m;
        }
        th.msgs.push({ text: clean(r.text || r.say) });
        Sfx.play('recv');
        if (!(Ph.on && Ph.view === 'thread' && Ph.cur === to)) {
            th.unread = (th.unread || 0) + 1;
            toast('💬', to + ': ' + clean(r.text || r.say), () => Ph.open('thread', to));
        }
    } catch (e) {
        th.msgs.push({ text: '⚠️ ' + (e.message || 'Error') });
    }
    th.pending = false;
    Ph.on && Ph.draw();
    head();
}
