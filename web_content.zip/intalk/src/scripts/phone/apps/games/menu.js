/**
 * App: Games menu + classic mini-games (XOX vs bot, Memory)
 *
 * Provides: Gm, win, botMove, newMem, app:games, app:ttt, app:mem
 */
const Gm = {
    tt: null, mem: null
}, TW = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
const win = b => {
    for (const [a, c, d] of TW)
        if (b[a] && b[a] === b[c] && b[a] === b[d])
            return b[a];
    return b.every(x => x) ? 'tie' : '';
};
function botMove(b) {
    const f = s => {
        for (const [a, c, d] of TW) {
            const l = [b[a], b[c], b[d]];
            if (l.filter(x => x === s).length === 2 && l.includes(''))
                return [a, c, d][l.indexOf('')];
        }
        return -1;
    };
    let i = f('O');
    if (i < 0)
        i = f('X');
    if (i < 0 && !b[4])
        i = 4;
    if (i < 0) {
        const e = b.map((x, j) => x ? -1 : j).filter(j => j >= 0);
        i = e[Math.floor(Math.random() * e.length)];
    }
    b[i] = 'O';
}
const newMem = () => ({
    c: ['🏠', '🚌', '☕', '🌳', '📚', '🎧', '🏠', '🚌', '☕', '🌳', '📚', '🎧'].sort(() => Math.random() - .5), o: [], d: [], n: 0, lock: false
});
reg({
    id: 'games', order: 14, home: true, icon: '🎮', color: '#8d7bff', name: () => tp('gam'),
    draw({ top }) {
        const G = [
            ['g-wrd', '🔤', tp('wrd'), '#3aa8ff'], ['g-mat', '🔗', tp('mat'), '#34c9a0'], ['g-qz', '❓', tp('qz'), '#ff8a5b'], ['g-lis', '🎧', tp('lis'), '#ff6b9d'], ['ttt', '❌', 'XOX', '#8d7bff'], ['mem', '🃏', 'Memory', '#ffd23f']
        ];
        return top('🎮 ' + tp('gam'), 'home') + `<div class="apps">${G.map(g => `<button class="app" data-go="${g[0]}"><i style="background:${g[3]}">${g[1]}</i>${esc(g[2])}</button>`).join('')}</div>`;
    }
});
reg({
    id: 'ttt', onOpen() {
        Gm.tt = {
            b: Array(9).fill(''), r: ''
        };
    },
    draw({ top }) {
        const g = Gm.tt;
        return top('❌⭕', 'games', '<button data-go="ttt">↻</button>') + `<div class="tt">${g.b.map((c, i) => `<button data-t="${i}" ${c || g.r ? 'disabled' : ''}>${c === 'X' ? '❌' : c === 'O' ? '⭕' : ''}</button>`).join('')}</div><p style="text-align:center;font-weight:900;font-size:22px">${g.r === 'X' ? icon('trophy', 32) : g.r === 'O' ? icon('x', 32) : g.r === 'tie' ? icon('swap', 32) : ''}</p>`;
    },
    click(e, q) {
        const tb = q('[data-t]');
        if (tb && Ph.view === 'ttt') {
            const g = Gm.tt, i = +tb.dataset.t;
            if (g.b[i] || g.r)
                return true;
            g.b[i] = 'X';
            g.r = win(g.b);
            if (!g.r) {
                botMove(g.b);
                g.r = win(g.b);
            }
            if (g.r === 'X') {
                addXp(10);
                Progress.win();
                Sfx.play('ok');
            } else if (g.r === 'O')
                Sfx.play('bad');
            Ph.draw();
            return true;
        }
    }
});
reg({
    id: 'mem', onOpen() {
        Gm.mem = newMem();
    },
    draw({ top }) {
        const g = Gm.mem;
        return top('🃏 ' + g.n, 'games', '<button data-go="mem">↻</button>') + `<div class="mm">${g.c.map((c, i) => {
            const sh = g.o.includes(i) || g.d.includes(i);
            return `<button class="${sh ? 'o' : ''}" data-m="${i}">${sh ? c : '?'}</button>`;
        }).join('')}</div><p style="text-align:center;font-weight:900;font-size:22px">${g.d.length === 12 ? icon('trophy', 32) : ''}</p>`;
    },
    click(e, q) {
        const mb = q('[data-m]');
        if (mb && Ph.view === 'mem') {
            const g = Gm.mem, i = +mb.dataset.m;
            if (g.lock || g.o.includes(i) || g.d.includes(i))
                return true;
            g.o.push(i);
            if (g.o.length === 2) {
                g.n++;
                g.lock = true;
                const [a, b] = g.o;
                setTimeout(() => {
                    if (g.c[a] === g.c[b]) {
                        Sfx.play('ok');
                        g.d.push(a, b);
                        if (g.d.length === 12)
                            addXp(15);
                    }
                    g.o = [];
                    g.lock = false;
                    Ph.view === 'mem' && Ph.draw();
                }, 700);
            }
            Ph.draw();
            return true;
        }
    }
});
