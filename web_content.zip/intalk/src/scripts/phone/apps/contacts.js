/**
 * App: Contacts (friends, phone numbers, saved home addresses)
 *
 * Provides: app:friends
 */
reg({
    id: 'friends', order: 2, dock: true, icon: '📞', color: '#34c9a0', name: () => tp('fri'),
    draw({ top }) {
        return top('📞 ' + tp('fri'), 'home') + `<div class="pb">${Game.friends.map(f => {
            const h = Game.places.find(p => p.host === f.id);
            return `<div class="li" data-go="thread" data-c="${esc(f.name)}">${avatar(f.look, 'happy', 44, 1)}<div style="flex:1"><b>${esc(f.name)}</b> <span class="dim">· ${esc(f.role)}</span><div class="dim">📱 ${esc(f.number)}${h ? ' · 🏡' : ''}</div></div>${h ? `<button class="chip" data-visit="${esc(h.id)}" aria-label="home">🏡</button>` : ''}💬</div>`;
        }).join('') || `<div class="pmasc">${mascot('peace', 110)}<p class="dim">${tp('hint')}</p></div>`}</div>`;
    },
    click(e, q) {
        const v = q('[data-visit]');
        if (v) {
            Ph.close();
            enterPlace(v.dataset.visit);
            return true;
        }
    }
});
