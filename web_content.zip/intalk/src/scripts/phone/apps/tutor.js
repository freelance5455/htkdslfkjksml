/**
 * App: AI tutor (ask grammar/vocabulary questions, answers in the native language)
 *
 * Provides: Tu, askTutor, app:tutor
 */
const Tu = { busy: false };
reg({
    id: 'tutor', order: 3, dock: true, icon: '<span class="mi">' + mascot('face', 40) + '</span>', color: '#0a7cff', name: () => tp('ai'),
    draw({ top }) {
        return top(mascot('face', 28, 'inl') + ' ' + tp('ai'), 'home') + `<div class="pb" id="pb">${Game.tutor.map(m => m.me ? `<div class="tu me">${esc(m.text)}</div>` : `<div class="tur">${mascot('face', 32, 'tav')}<div class="tu">${esc(m.text)}</div></div>`).join('') || `<div class="pmasc">${mascot('thumb', 150)}<p class="dim">${esc(tp('ask'))}</p></div>`}${Tu.busy ? `<div class="tur">${mascot('face', 32, 'tav')}<div class="tu">${dots(tp('think'))}</div></div>` : ''}</div><div id="bar"><input id="tui" autocomplete="off" placeholder="${esc(tp('ask'))}"><button class="btn s" data-tu="1">➤</button></div>`;
    },
    click(e, q) {
        if (Ph.view === 'tutor' && q('[data-tu]')) {
            askTutor();
            return true;
        }
    },
    key(e) {
        if (Ph.view === 'tutor' && e.target.id === 'tui') {
            askTutor();
            return true;
        }
    }
});
async function askTutor() {
    const v = $('tui').value.trim();
    if (!v || Tu.busy)
        return;
    Streak.touch();
    Game.tutor.push({
        me: 1, text: v
    });
    Tu.busy = 1;
    Ph.draw();
    Progress.gain(2);
    try {
        const o = await Game.call(Game.tutorPrompt());
        Game.tutor.push({ text: String(o.text).trim() });
    } catch (e) {
        Game.tutor.push({ text: '⚠️ ' + (e.message || 'Error') });
    }
    Tu.busy = 0;
    Ph.on && Ph.view === 'tutor' && Ph.draw();
}
