/**
 * App: Wallpaper (Settings -> Wallpaper): InTalk scenes or plain colours for the phone home screen
 *
 * Provides: app:wall
 */
reg({
    id: 'wall',
    draw({ top }) {
        const cur = Wall.get().id, w = Wall.get();
        return top(tp('wall'), 'settings') + `<div class="pb"><div class="wprev" style="background:${w.css}" data-lt="${w.light ? 1 : 0}"><div class="wprev-w"><b>09:41</b><span>InTalk</span></div></div>
  <div class="wgrid">${Object.keys(WALLS).map(k => `<button class="wth ${cur === k ? 'on' : ''}" data-wall="${k}" style="background-image:url(${WALLS[k]})" aria-label="wallpaper">${cur === k ? icon('check', 20) : ''}</button>`).join('')}</div>
  <div class="wcol">${WALL_COLORS.map(c => `<button class="wsq ${cur === c.id ? 'on' : ''}" data-wall="${c.id}" style="background:${c.css}" aria-label="colour">${cur === c.id ? icon('check', 18) : ''}</button>`).join('')}</div></div>`;
    },
    click(e, q) {
        const b = q('[data-wall]');
        if (Ph.view !== 'wall' || !b)
            return;
        Wall.set(b.dataset.wall);
        Ph.draw();
        return true;
    }
});
