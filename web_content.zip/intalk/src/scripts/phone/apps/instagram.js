/**
 * App: Instagram shortcut (opens the InTalk page)
 *
 * Provides: IG_URL, app:insta
 */
const IG_URL = 'https://www.instagram.com/intalkofficial/';
reg({
    id: 'insta', order: 13, home: true, href: IG_URL, name: () => 'Instagram',
    icon: '<span class="ig"><svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="5.5"/><circle cx="12" cy="12" r="4.2"/><circle cx="17.3" cy="6.7" r="1" fill="#fff" stroke="none"/></svg></span>',
    draw() {
        return '';
    }
});
