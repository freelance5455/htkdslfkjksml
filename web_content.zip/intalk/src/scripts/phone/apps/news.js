/**
 * App: News (fictional local news in the target language)
 *
 * Provides: fetchNews, app:news
 */
reg({
    id: 'news', order: 12, home: true, icon: '📰', color: '#ff8a5b', name: () => tp('news'),
    onOpen() {
        if (!Game.news && !Game.newsP)
            fetchNews();
    },
    draw({ top }) {
        return top('📰 ' + tp('news'), 'home', '<button data-news="1">↻</button>') + `<div class="pb">${Game.news ? Game.news.map(x => `<div class="li" style="display:block;cursor:default"><b>${esc(x.t)}</b><div class="dim">${esc(x.x)}</div></div>`).join('') : `<div class="dim" style="text-align:center;padding:20px">${dots(loadP())}</div>`}</div>`;
    },
    click(e, q) {
        if (q('[data-news]')) {
            fetchNews();
            return true;
        }
    }
});
async function fetchNews() {
    Game.newsP = 1;
    Game.news = null;
    Ph.on && Ph.draw();
    const c = Game.ctx();
    try {
        const r = await Game.ask(`Write 4 short FICTIONAL local news items for ${Game.city || 'a city where ' + c.tg + ' is spoken'}, ${c.sp.replace('1-3 short sentences', 'each summary 1-2 short sentences')} ${c.L} Output ONLY JSON array: [{"t":"headline","x":"summary"}]`, true);
        Game.news = Array.isArray(r) ? r : r.items || [];
    } catch (e) {
        Game.news = [
            {
                t: '⚠️', x: (e.message || 'Error')
            }
        ];
    }
    Game.newsP = 0;
    Ph.on && Ph.draw();
}
