/**
 * App: Settings (wallpaper, theme, sounds, voice, new game, AI & sound diagnostics)
 *
 * Provides: onOff, app:settings
 */
const onOff = v => `<span class="dim" style="margin-left:auto">${v ? 'ON' : 'OFF'}</span>`;
reg({
    id: 'settings', order: 22, home: true, icon: '⚙️', color: '#a9b3c4', name: () => tp('set'),
    draw({ top }) {
        return top('⚙️ ' + tp('set'), 'home') + `<div class="pb"><div class="li" data-act="profile">✏️ ${esc(tp('prof'))}<span class="dim" style="margin-left:auto">${flag(S.nat, 15)} → ${flag(S.tgt, 15)} · ${esc(S.lvl)}</span></div><div class="li" data-act="wall"><span class="wsw" style="background:${Wall.get().css}"></span> ${esc(tp('wall'))}</div><div class="li" data-act="theme">🌓 ${esc(tp('thm'))}</div><div class="li" data-act="sfx">🔔 ${esc(tp('snd'))}${onOff(Sfx.on)}</div><div class="li" data-act="tts">${Voice.tts ? '🔊' : '🔇'} ${esc(tp('voi'))}${onOff(Voice.tts)}</div><div class="li" data-act="mic">🎤 ${esc(tp('mic'))}${onOff(Perm.micOn())}</div><div class="li" data-act="restart">🔄 ${esc(tp('newg'))}</div><div class="li" data-act="diag">🛠 AI · ${esc(tp('snd'))} · ${esc(tp('mic'))}</div></div>`;
    },
    click(e, q) {
        const a = q('[data-act]');
        if (!a || Ph.view !== 'settings')
            return;
        const k = a.dataset.act;
        if (k === 'theme') {
            const d = document.documentElement;
            d.dataset.theme = d.dataset.theme === 'dark' ? 'light' : 'dark';
            Store.set('theme', d.dataset.theme);
        } else if (k === 'diag') {
            Ph.go('diag');
            return true;
        } else if (k === 'wall') {
            Ph.go('wall');
            return true;
        } else if (k === 'tts') {
            Voice.toggleTts();
            if (Voice.tts) {
                AudioHub.unlock();
                Voice.speak(SAMPLE[S.tgt] || SAMPLE.en, null);
            }
            Ph.draw();
        } else if (k === 'sfx') {
            Sfx.toggle();
            if (Sfx.on)
                AudioHub.unlock();
            Ph.draw();
        } else if (k === 'mic') {
            if (Perm.micOn()) {
                Store.set('mic', false);
                Ph.draw();
            } else
                Perm.mic().then(ok => {
                    toast('mic', ok ? t('grant') : t('nom') + ' [' + (Perm.err || '?') + ']');
                    Ph.on && Ph.view === 'settings' && Ph.draw();
                });
        } else if (k === 'profile') {
            editProfile();
        } else if (k === 'restart') {
            confirmDlg(t('ngq'), t('ngi'), t('yes'), t('no'), newGame);
        }
        return true;
    }
});
