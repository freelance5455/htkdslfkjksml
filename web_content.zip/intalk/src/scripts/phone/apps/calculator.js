/**
 * App: Calculator
 *
 * Provides: Calc, CK, app:calc
 */
const Calc = {
    d: '0', a: null, op: null, fresh: true,
    press(k) {
        if ('0123456789.'.includes(k)) {
            if (this.d === 'Error' || this.fresh) {
                this.d = k === '.' ? '0.' : k;
                this.fresh = false;
            } else if (!(k === '.' && this.d.includes('.')))
                this.d = (this.d === '0' && k !== '.') ? k : this.d + k;
            return;
        }
        if (k === 'C') {
            Object.assign(this, {
                d: '0', a: null, op: null, fresh: true
            });
            return;
        }
        if (this.d === 'Error')
            return;
        if (k === '±') {
            this.d = String(-parseFloat(this.d));
            return;
        }
        if (k === '%') {
            this.d = String(parseFloat(this.d) / 100);
            return;
        }
        if (this.op && !this.fresh)
            this.eq();
        if (this.d === 'Error')
            return;
        this.a = parseFloat(this.d);
        this.op = k === '=' ? null : k;
        this.fresh = true;
    },
    eq() {
        const a = this.a, b = parseFloat(this.d), r = this.op === '+' ? a + b : this.op === '−' ? a - b : this.op === '×' ? a * b : this.op === '÷' ? (b ? a / b : NaN) : b;
        this.d = Number.isFinite(r) ? String(+r.toPrecision(12)) : 'Error';
        this.a = null;
    }
};
const CK = ['C', '±', '%', '÷', '7', '8', '9', '×', '4', '5', '6', '−', '1', '2', '3', '+', '0', '.', '='];
reg({
    id: 'calc', order: 10, home: true, icon: '🧮', color: '#ffd23f', name: () => tp('calc'),
    draw({ top }) {
        return top('🧮 ' + tp('calc'), 'home') + `<div class="calc"><div class="cd" style="font-size:${Calc.d.length > 9 ? 26 : 38}px">${esc(Calc.d)}</div><div class="ck">${CK.map(k => `<button data-ck="${k}" class="${'÷×−+'.includes(k) ? 'o' : k === '=' ? 'f' : k === '0' ? 'z' : ''}">${k}</button>`).join('')}</div></div>`;
    },
    click(e, q) {
        const b = q('[data-ck]');
        if (b && Ph.view === 'calc') {
            Calc.press(b.dataset.ck);
            Ph.draw();
            return true;
        }
    }
});
