/**
 * Music engine: original tracks synthesized with Web Audio (scales/rhythms per language) + AI song
 * catalog
 *
 * Provides: cov, Music, fetchSongs, ensureSongs
 */
const cov = s => {
    const k = hash(s.id) % 4;
    return `background:linear-gradient(135deg,${['#2563eb', '#6b7280', '#93c5fd', '#111827'][k]},${['#93c5fd', '#d1d5db', '#2563eb', '#6b7280'][k]})`;
};
const Music = {
    ctx: null, m: null, cur: null, on: false, tab: 'lib', tr: false, ev: [], len: 1, t0: 0, i: 0, lp: 0, tm: null, dl: {},
    SC: {
        es: [0, 1, 4, 5, 7, 8, 10], tr: [0, 1, 4, 5, 7, 8, 10], az: [0, 2, 3, 5, 7, 8, 10], ru: [0, 2, 3, 5, 7, 8, 11], de: [0, 2, 4, 5, 7, 9, 11], en: [0, 2, 4, 5, 7, 9, 11], zh: [0, 2, 4, 7, 9], ko: [0, 3, 5, 7, 10]
    },
    BPM: {
        es: 104, tr: 96, az: 80, ru: 120, de: 112, en: 100, zh: 76, ko: 108
    },
    rng(seed) {
        let a = seed >>> 0;
        return () => {
            a = (a + 0x6D2B79F5) >>> 0;
            let t = Math.imul(a ^ (a >>> 15), 1 | a);
            t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
            return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
        };
    },
    hz: m => 440 * Math.pow(2, (m - 69) / 12),
    drum(L, q) {
        if (L === 'tr' || L === 'az')
            return q === 0 ? ['d'] : (q === 2 || q === 5) ? ['t'] : [];
        if (L === 'de')
            return q === 0 ? ['k'] : (q === 2 || q === 4) ? ['h'] : [];
        if (L === 'zh')
            return q === 0 ? ['d'] : [];
        if (L === 'en' || L === 'ko')
            return (q === 0 || q === 4 ? ['k'] : []).concat(['h']);
        return (q === 0 ? ['k'] : []).concat(q % 2 ? ['h'] : []);
    },
    compose(s) {
        const L = s.lang, r = this.rng(hash(s.id)), sc = this.SC[L] || this.SC.en, n = sc.length, bpm = (this.BPM[L] || 100) + Math.floor(r() * 17) - 8, bt = 60 / bpm, bpb = L === 'de' ? 3 : 4, root = 45 + Math.floor(r() * 6), ev = [];
        const deg = d => root + sc[((d % n) + n) % n] + 12 * Math.floor(d / n), lo = Math.floor(n * 1.4), hi = Math.floor(n * 2.7);
        const pats = bpb === 3 ? [[1, 1, 1], [2, 1], [1, .5, .5, 1], [1.5, .5, 1]] : [[1, 1, 1, 1], [1.5, .5, 1, 1], [.5, .5, 1, 2], [2, 1, 1], [1, .5, .5, 2], [.5, .5, .5, .5, 2]];
        const mk = bars => {
            let d = n * 2;
            const out = [];
            for (let b = 0; b < bars; b++) {
                const p = pats[Math.floor(r() * pats.length)];
                let x = 0;
                p.forEach((du, k) => {
                    d = Math.max(lo, Math.min(hi, d + Math.floor(r() * 5) - 2));
                    out.push({
                        b, t: x, d: du, p: deg(b === bars - 1 && k === p.length - 1 ? n * 2 : d)
                    });
                    x += du;
                });
            }
            return out;
        };
        const A = mk(4), B = mk(4), put = (ph, off) => ph.forEach(x => ev.push({
            t: ((off + x.b) * bpb + x.t) * bt, k: 'm', f: this.hz(x.p), d: Math.max(.2, x.d * bt * .95), v: .22
        }));
        put(A, 0);
        put(A, 4);
        put(B, 8);
        put(A, 12);
        const prog = [0, 3, 4, 0, 0, 3, 4, 0, 5, 3, 4, 0, 0, 3, 4, 0].map(x => x % n);
        for (let b = 0; b < 16; b++) {
            const g = prog[b], t = b * bpb * bt;
            ev.push({
                t, k: 'b', f: this.hz(deg(g)), d: bt * .9, v: .3
            });
            if (bpb === 4)
                ev.push({
                    t: t + 2 * bt, k: 'b', f: this.hz(deg(g + 4)), d: bt * .9, v: .26
                });
            [0, 2, 4].forEach(o => ev.push({
                t, k: 'p', f: this.hz(deg(g + o) + 12), d: bpb * bt * .98, v: .07
            }));
            for (let q = 0; q < bpb * 2; q++)
                this.drum(L, q).forEach(k => ev.push({
                    t: t + q * bt / 2, k, v: 1
                }));
        }
        ev.sort((a, b) => a.t - b.t);
        this.ev = ev;
        this.len = 16 * bpb * bt;
    },
    inst(L, k) {
        if (k === 'b')
            return {
                w: 'triangle', lp: 600, a: .01, r: .08, sus: 0
            };
        if (k === 'p')
            return L === 'de' ? {
                w: 'sawtooth', lp: 1100, a: .05, r: .2, sus: 1, det: 6
            } : {
                w: 'sine', lp: 1800, a: .15, r: .3, sus: 1
            };
        return ({
            es: {
                w: 'triangle', lp: 3500, a: .004, r: .25, sus: 0
            }, tr: {
                w: 'sawtooth', lp: 2000, a: .004, r: .3, sus: 0, det: 4
            }, az: {
                w: 'sawtooth', lp: 1600, a: .004, r: .35, sus: 0
            }, ru: {
                w: 'square', lp: 1800, a: .004, r: .2, sus: 0
            }, de: {
                w: 'sawtooth', lp: 1800, a: .03, r: .15, sus: 1, det: 7
            }, en: {
                w: 'triangle', lp: 3000, a: .01, r: .3, sus: 1
            }, zh: {
                w: 'triangle', lp: 4000, a: .003, r: .6, sus: 0
            }, ko: {
                w: 'sawtooth', lp: 2600, a: .01, r: .2, sus: 1, det: 5
            }
        })[L] || {
            w: 'triangle', lp: 3000, a: .01, r: .2, sus: 0
        };
    },
    note(f, w, d, v, o) {
        const c = this.ctx, g = c.createGain(), fl = c.createBiquadFilter(), end = w + Math.max(d, .3), nd = o.det ? .5 : 1;
        fl.type = 'lowpass';
        fl.frequency.value = o.lp;
        g.gain.setValueAtTime(.0001, w);
        g.gain.linearRampToValueAtTime(v * nd, w + o.a);
        if (o.sus) {
            g.gain.setValueAtTime(v * nd * .8, w + d);
            g.gain.exponentialRampToValueAtTime(.0001, w + d + o.r);
        } else
            g.gain.exponentialRampToValueAtTime(.0001, end + o.r);
        [0].concat(o.det ? [o.det, -o.det] : []).forEach(dt => {
            const os = c.createOscillator();
            os.type = o.w;
            os.frequency.value = f;
            os.detune.value = dt;
            os.connect(fl);
            os.start(w);
            os.stop((o.sus ? w + d : end) + o.r + .05);
        });
        fl.connect(g);
        g.connect(this.m);
    },
    nz() {
        if (!this._n) {
            const c = this.ctx, b = c.createBuffer(1, Math.floor(c.sampleRate * .1), c.sampleRate), d = b.getChannelData(0);
            for (let i = 0; i < d.length; i++)
                d[i] = Math.random() * 2 - 1;
            this._n = b;
        }
        return this._n;
    },
    fire(e, w) {
        const c = this.ctx;
        if (e.k === 'h') {
            const s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
            s.buffer = this.nz();
            f.type = 'highpass';
            f.frequency.value = 7000;
            g.gain.setValueAtTime(.1, w);
            g.gain.exponentialRampToValueAtTime(.001, w + .05);
            s.connect(f);
            f.connect(g);
            g.connect(this.m);
            s.start(w);
            s.stop(w + .06);
            return;
        }
        const dr = {
            k: [130, 45, .8, .22], d: [150, 70, .7, .2], t: [420, 260, .35, .08]
        }[e.k];
        if (dr) {
            const o = c.createOscillator(), g = c.createGain();
            o.frequency.setValueAtTime(dr[0], w);
            o.frequency.exponentialRampToValueAtTime(dr[1], w + .1);
            g.gain.setValueAtTime(dr[2], w);
            g.gain.exponentialRampToValueAtTime(.001, w + dr[3]);
            o.connect(g);
            g.connect(this.m);
            o.start(w);
            o.stop(w + dr[3] + .03);
            return;
        }
        this.note(e.f, w, e.d, e.v, this.inst(this.cur.lang, e.k));
    },
    async play(s) {
        try {
            this.ctx = await AudioHub.get();
        } catch (e) {
            this.ctx = null;
        }
        if (!this.ctx) {
            toast('speakerOff', t('nov'));
            return;
        }
        this.stop(true);
        this.cur = s;
        this.compose(s);
        this.m = this.ctx.createGain();
        this.m.gain.value = .8;
        this.m.connect(this.ctx.destination);
        this.t0 = this.ctx.currentTime + .15;
        this.i = 0;
        this.lp = 0;
        this.on = true;
        this.tm = setInterval(() => this.tick(), 40);
        Ph.on && Ph.draw();
    },
    tick() {
        const c = this.ctx;
        if (!this.on || !this.ev.length)
            return;
        for (let guard = 0; guard < 400; guard++) {
            const e = this.ev[this.i], w = this.t0 + this.lp * this.len + e.t;
            if (w > c.currentTime + .3)
                break;
            if (w >= c.currentTime - .05)
                this.fire(e, Math.max(w, c.currentTime));
            this.i++;
            if (this.i >= this.ev.length) {
                this.i = 0;
                this.lp++;
            }
        }
        this.ui();
    },
    toggle() {
        if (!this.cur || !this.ctx)
            return;
        const c = this.ctx;
        if (this.on) {
            this.on = false;
            this.pt = c.currentTime;
            if (this.m)
                this.m.gain.setTargetAtTime(0, c.currentTime, .02);
        } else {
            this.t0 += c.currentTime - this.pt;
            if (this.m)
                this.m.gain.setTargetAtTime(.8, c.currentTime, .02);
            this.on = true;
        }
        Ph.on && Ph.draw();
    },
    stop(keep) {
        clearInterval(this.tm);
        if (this.m) {
            try {
                this.m.disconnect();
            } catch (e) {
            }
        }
        this.on = false;
        if (!keep)
            this.cur = null;
    },
    step(d) {
        const l = Store.get('songs', []);
        if (!l.length || !this.cur)
            return;
        const i = l.findIndex(x => x.id === this.cur.id);
        this.play(l[(i + d + l.length) % l.length]);
    },
    prog() {
        return this.ctx ? (((this.ctx.currentTime - this.t0) % this.len) + this.len) % this.len / this.len : 0;
    },
    ui() {
        const p = this.prog(), b = $('mprog');
        if (b)
            b.style.width = (p * 100) + '%';
        if (this.cur) {
            const n = this.cur.lyrics.length, i = Math.min(n - 1, Math.floor(p * n));
            document.querySelectorAll('.ly').forEach((e, k) => e.classList.toggle('on', k === i));
        }
    }
};
async function fetchSongs() {
    Game.songP = 1;
    Ph.on && Ph.draw();
    const c = Game.ctx();
    try {
        const r = await Game.ask(`Create 5 ORIGINAL fictional songs typical of the music culture of ${c.tg}-speaking countries (match the real genres of that culture, e.g. flamenco-pop, saz folk, mugham-pop, K-pop, schlager, chanson, pop-rock). ${c.L} For each: "id" slug, "title" in ${c.tg}, "artist" a fictional name, "genre" short, "emoji" one, "lyrics": array of 6 short singable lines in ${c.tg} (${Game.p.lvl} level, original, simple, never real song text), "tr": the same 6 lines translated into ${c.nt}. Output ONLY a JSON array.`, true);
        (Game.songs = Game.songs || {})[S.tgt] = (Array.isArray(r) ? r : r.songs || []).filter(x => x && x.title && Array.isArray(x.lyrics) && x.lyrics.length).map(x => ({
            id: S.tgt + '-' + hash(x.title + (x.artist || '')), title: String(x.title), artist: String(x.artist || ''), genre: String(x.genre || ''), emoji: x.emoji || '🎵', lyrics: x.lyrics.slice(0, 8).map(String), tr: (x.tr || []).slice(0, 8).map(String), lang: S.tgt
        }));
    } catch (e) {
        toast('⚠️', e.message || 'Error');
        (Game.songs = Game.songs || {})[S.tgt] = [];
    }
    Game.songP = 0;
    Ph.on && Ph.draw();
}
const ensureSongs = () => {
    if (!(Game.songs || {})[S.tgt] && !Game.songP)
        fetchSongs();
};
