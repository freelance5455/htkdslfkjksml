/**
 * App: Music (library = downloaded songs, discover = AI catalog; player with lyrics + translation)
 *
 * Provides: app:music, app:player
 */
reg({
    id: 'music', order: 4, dock: true, icon: '🎵', color: '#ff6b9d', name: () => tp('mus'),
    onOpen() {
        Music.tab = Store.get('songs', []).length ? 'lib' : 'disc';
        if (Music.tab === 'disc')
            ensureSongs();
    },
    draw({ top }) {
        const lib = Store.get('songs', []), cat = (Game.songs || {})[S.tgt] || [], tab = Music.tab;
        const row = (s, dl) => {
            const has = lib.some(x => x.id === s.id), busy = Music.dl[s.id];
            return `<div class="li" style="cursor:default"><div class="cover" style="${cov(s)}">${icon('music', 22)}</div><div style="flex:1;min-width:0"><b>${esc(s.title)}</b><div class="dim">${LANGS[s.lang] ? flag(s.lang, 14) + ' ' : ''}${esc(s.artist)} · ${esc(s.genre)}</div></div>${dl ? (has ? '<span class="okc">' + icon('check', 22) + '</span>' : busy ? '<span class="dots"><span>•</span><span>•</span><span>•</span></span>' : `<button class="btn s b" data-dl="${esc(s.id)}" aria-label="${esc(tp('inst'))}">⬇️</button>`) : `<button class="btn s" data-play="${esc(s.id)}">▶</button><button class="x" data-sdel="${esc(s.id)}" aria-label="${esc(tp('del'))}" style="font-size:18px">🗑</button>`}</div>`;
        };
        return top('🎵 ' + tp('mus'), 'home', tab === 'disc' ? '<button data-msr="1">↻</button>' : '') + `<div class="row" style="padding:0 12px 6px"><button class="chip ${tab === 'lib' ? 'on' : ''}" data-mt="lib">📚 ${esc(tp('lib'))} (${lib.length})</button><button class="chip ${tab === 'disc' ? 'on' : ''}" data-mt="disc">🔎 ${esc(tp('disc'))}</button></div><div class="pb">${tab === 'lib' ? (lib.map(s => row(s, 0)).join('') || '<div class="pmasc">' + mascot('peace', 110) + '<p class="dim">' + icon('headphones', 18) + ' ' + icon('download', 18) + '</p></div>') : (Game.songP ? `<div class="dim" style="text-align:center;padding:20px">${dots(loadP())}</div>` : cat.map(s => row(s, 1)).join(''))}</div>${Music.cur ? `<div class="mini" data-go="player">🎵 <b>${esc(Music.cur.title)}</b><span>${Music.on ? '⏸' : '▶'}</span></div>` : ''}`;
    },
    click(e, q) {
        if (Ph.view !== 'music')
            return;
        const mt = q('[data-mt]'), dl = q('[data-dl]'), pl = q('[data-play]'), sd = q('[data-sdel]');
        if (mt) {
            Music.tab = mt.dataset.mt;
            if (Music.tab === 'disc')
                ensureSongs();
            Ph.draw();
            return true;
        }
        if (q('[data-msr]')) {
            Game.songs[S.tgt] = null;
            fetchSongs();
            return true;
        }
        if (dl) {
            const id = dl.dataset.dl, s = ((Game.songs || {})[S.tgt] || []).find(x => x.id === id);
            if (s && !Music.dl[id]) {
                Music.dl[id] = 1;
                Ph.draw();
                setTimeout(() => {
                    const l = Store.get('songs', []);
                    if (!l.some(x => x.id === id))
                        l.push(s);
                    Store.set('songs', l);
                    delete Music.dl[id];
                    Ph.on && Ph.draw();
                }, 1400);
            }
            return true;
        }
        if (pl) {
            const s = Store.get('songs', []).find(x => x.id === pl.dataset.play);
            if (s) {
                Music.play(s);
                Ph.go('player');
            }
            return true;
        }
        if (sd) {
            const id = sd.dataset.sdel;
            Store.set('songs', Store.get('songs', []).filter(x => x.id !== id));
            if (Music.cur && Music.cur.id === id)
                Music.stop();
            Ph.draw();
            return true;
        }
    }
});
reg({
    id: 'player',
    draw({ top }) {
        const s = Music.cur;
        return top('', 'music', s ? '<button data-mtr="1">🌐</button>' : '') + (s ? `<div class="pb"><div class="pl2"><div class="cover big" style="${cov(s)}">${icon('music', 54)}</div><b style="font:800 20px var(--f)">${esc(s.title)}</b><div class="dim">${esc(s.artist)} · ${esc(s.genre)}</div><div class="eq ${Music.on ? 'on' : ''}"><i></i><i></i><i></i><i></i></div><div class="prog"><i id="mprog"></i></div><div class="ctl"><button data-mp="prev">⏮</button><button class="main" data-mp="play">${Music.on ? '⏸' : '▶'}</button><button data-mp="next">⏭</button></div></div>${s.lyrics.map((l, i) => `<div class="ly">${esc(l)}${Music.tr && s.tr[i] ? `<small>${esc(s.tr[i])}</small>` : ''}</div>`).join('')}</div>` : '');
    },
    click(e, q) {
        if (Ph.view !== 'player')
            return;
        const mp = q('[data-mp]');
        if (mp) {
            const k = mp.dataset.mp;
            if (k === 'play')
                Music.toggle();
            else
                Music.step(k === 'next' ? 1 : -1);
            return true;
        }
        if (q('[data-mtr]')) {
            Music.tr = !Music.tr;
            Ph.draw();
            return true;
        }
    }
});
