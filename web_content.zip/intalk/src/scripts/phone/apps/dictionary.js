/**
 * App: Dictionary - built-in thematic dictionary (8 languages) + search in any language + online
 * lookup + "My words"
 *
 * Provides: LI, nz, DICT, DICT_TOTAL, Dict, app:dict, app:dentry
 */
const LI = {
    az: 0, tr: 1, ru: 2, en: 3, de: 4, es: 5, zh: 6, ko: 7
};
const nz = s => String(s || '').toLocaleLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[əäæ]/g, 'e').replace(/ı/g, 'i').replace(/[öø]/g, 'o').replace(/ß/g, 'ss').replace(/ё/g, 'е').replace(/[^\p{L}\p{N} ]+/gu, '').replace(/\s+/g, ' ').trim();
const DICT = LEX.map(c => ({
    id: c.id, n: c.n.split('|'), w: c.w.trim().split('\n').map(l => {
        const r = l.split('|');
        r.key = r.map(nz).join(' ');
        return r;
    })
}));
const DICT_TOTAL = DICT.reduce((a, c) => a + c.w.length, 0);
const Dict = {
    cat: 'greet', q: '', adding: false, det: null, online: null, busy: false, items: [],
    users() {
        return Store.get('dict_user', []).filter(x => x.lt === S.tgt);
    },
    cname(c) {
        return c.n[LI[S.nat]] || c.n[3];
    },
    tg(r) {
        return r[LI[S.tgt]];
    }, nt(r) {
        return r[LI[S.nat]];
    },
    /* current list: search (all categories + my words) or the selected category */
    build() {
        const q = nz(this.q), U = this.users().map(u => ({
            u, tg: u.tg, nt: u.nat, cat: t('dmy')
        }));
        if (q) {
            const sc = (a, b) => {
                const x = nz(a), y = nz(b);
                return x === q || y === q ? 0 : x.startsWith(q) || y.startsWith(q) ? 1 : 2;
            }, out = [];
            U.forEach(i => {
                if (nz(i.tg + ' ' + i.nt + ' ' + (i.u.ex || '')).includes(q))
                    out.push({
                        ...i, s: sc(i.tg, i.nt)
                    });
            });
            DICT.forEach(c => c.w.forEach(r => {
                if (r.key.includes(q))
                    out.push({
                        r, tg: this.tg(r), nt: this.nt(r), cat: this.cname(c), s: sc(this.tg(r), this.nt(r)) + .5
                    });
            }));
            return out.sort((a, b) => a.s - b.s).slice(0, 80);
        }
        if (this.cat === 'my')
            return U;
        const c = DICT.find(x => x.id === this.cat) || DICT[0];
        return c.w.map(r => ({
            r, tg: this.tg(r), nt: this.nt(r), cat: this.cname(c)
        }));
    },
    rows() {
        this.items = this.build();
        const q = this.q.trim();
        return (this.items.length ? this.items.map((it, i) => `<div class="dli" data-dopen="${i}"><div class="dw"><b>${esc(it.tg)}</b><span>${esc(it.nt)}</span>${q ? `<small>${esc(it.cat)}</small>` : ''}</div><button class="dsp" data-dsp="${i}" aria-label="speak">${icon('speaker', 18)}</button></div>`).join('') : `<div class="dim dnone">${esc(this.cat === 'my' && !q ? t('dadd') : t('dnone'))}</div>`) + this.onlineHtml();
    },
    onlineHtml() {
        const o = this.online, q = this.q.trim();
        if (this.busy)
            return `<div class="donl dim">${dots()}</div>`;
        if (!o)
            return q.length > 1 ? `<button class="btn s g donlb" data-donl="1">${icon('globe', 18)} ${esc(t('donl'))}</button>` : '';
        if (!o.tg)
            return `<div class="donl"><div class="dim">${esc(t('dnone'))}${o.err ? ' [' + esc(o.err.trim()) + ']' : ''}</div><button class="btn s g donlb" data-donl="1">${icon('refresh', 18)} ${esc(t('donl'))}</button></div>`;
        return `<div class="donl"><div class="dim">${icon('globe', 14)} ${esc(t('dsrc'))}: ${esc(o.src)}</div><div class="dli"><div class="dw"><b>${esc(o.tg)}</b><span>${esc(o.nat)}</span></div><button class="dsp" data-dspo="1" aria-label="speak">${icon('speaker', 18)}</button></div>${o.alts.map(a => `<div class="dalt"><i>${esc(a.pos)}</i> ${esc(a.words.join(', '))}</div>`).join('')}${o.defs.map(d => `<div class="ddef"><i>${esc(d.pos)}</i> ${esc(d.def)}${d.ex ? `<em>${esc(d.ex)}</em>` : ''}</div>`).join('')}<button class="btn s" data-dsave="1">${icon('plus', 18)} ${esc(t('dsave'))}</button></div>`;
    },
    paint() {
        const l = document.getElementById('dlist');
        if (!l)
            return;
        l.innerHTML = this.rows();
        const c = document.getElementById('dcount');
        if (c)
            c.textContent = this.items.length + ' ' + t('dwords');
        const x = document.querySelector('.dclr');
        if (x)
            x.style.visibility = this.q ? 'visible' : 'hidden';
        document.querySelectorAll('.dcat').forEach(b => b.classList.toggle('off', !!this.q.trim()));
    },
    speak(text) {
        Voice.speak(text, {
            name: 'dict', look: {
                g: 'f', t: 0
            }
        });
    },
    saveUser(tg, nat, ex) {
        tg = String(tg || '').trim();
        nat = String(nat || '').trim();
        if (!tg || !nat)
            return false;
        const a = Store.get('dict_user', []);
        if (a.some(x => x.lt === S.tgt && nz(x.tg) === nz(tg) && nz(x.nat) === nz(nat)))
            return true;
        a.push({
            id: 'u' + Date.now(), tg, nat, ex: String(ex || '').trim(), lt: S.tgt, ln: S.nat
        });
        Store.set('dict_user', a);
        return true;
    },
    /* online lookup: Google (auto-detect + alternatives) -> MyMemory -> AI; then Wiktionary definitions */
    async lookup(q) {
        q = String(q || '').trim();
        if (q.length < 2 || this.busy)
            return;
        this.busy = true;
        this.online = null;
        this.paint();
        const tg = S.tgt, nt = S.nat, cd = l => ({ zh: 'zh-CN' })[l] || l, res = {
            q, tg: '', nat: '', alts: [], defs: [], src: '', err: ''
        }, J = async (u) => {
            const ac = new AbortController(), tm = setTimeout(() => ac.abort(), 8000);
            try {
                const r = await fetch(u, { signal: ac.signal });
                if (!r.ok)
                    throw new Error('HTTP ' + r.status);
                return await r.json();
            } finally {
                clearTimeout(tm);
            }
        };
        try {
            const g = tl => J('https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=' + cd(tl) + '&dt=t&dt=bd&q=' + encodeURIComponent(q));
            let d = await g(tg);
            const toTg = String(d[2] || '').slice(0, 2) !== tg.slice(0, 2);
            if (!toTg)
                d = await g(nt);
            const main = (d[0] || []).map(x => x[0]).join('').trim();
            if (main && nz(main) !== nz(q)) {
                if (toTg) {
                    res.tg = main;
                    res.nat = q;
                } else {
                    res.tg = q;
                    res.nat = main;
                }
                res.alts = (Array.isArray(d[1]) ? d[1] : []).map(p => ({
                    pos: p[0], words: (p[1] || []).slice(0, 6)
                })).slice(0, 4);
                res.src = 'Google Translate';
            }
        } catch (e) {
            res.err += 'google: ' + (e.name || e.message) + ' ';
        }
        if (!res.tg) {
            try {
                const M = (a, b) => J('https://api.mymemory.translated.net/get?q=' + encodeURIComponent(q) + '&langpair=' + cd(a) + '|' + cd(b));
                let d = await M(nt, tg), x = d && d.responseData && d.responseData.translatedText;
                if (x && nz(x) !== nz(q)) {
                    res.tg = x;
                    res.nat = q;
                } else {
                    d = await M(tg, nt);
                    x = d && d.responseData && d.responseData.translatedText;
                    if (x && nz(x) !== nz(q)) {
                        res.tg = q;
                        res.nat = x;
                    }
                }
                if (res.tg)
                    res.src = 'MyMemory';
            } catch (e) {
                res.err += 'mymemory: ' + (e.name || e.message) + ' ';
            }
        }
        if (!res.tg) {
            try {
                const o = await Game.call(`Dictionary lookup for a language learner. Input: "${q}" (it may be in ${LANGS[nt][0]} or ${LANGS[tg][0]}). Give the word/phrase in BOTH languages. Output ONLY JSON {"tg":"in ${LANGS[tg][0]}","nat":"in ${LANGS[nt][0]}","alts":["other common translations"],"ex":"one short example sentence in ${LANGS[tg][0]}"}`, true), p = parse(o.text);
                if (p && p.tg && p.nat) {
                    res.tg = String(p.tg);
                    res.nat = String(p.nat);
                    res.alts = (p.alts && p.alts.length) ? [
                        {
                            pos: '', words: p.alts.slice(0, 6)
                        }
                    ] : [];
                    if (p.ex)
                        res.defs = [
                            {
                                pos: '', def: '', ex: String(p.ex)
                            }
                        ];
                    res.src = 'AI';
                }
            } catch (e) {
                res.err += 'ai: ' + (e.message || e) + ' ';
            }
        }
        if (res.tg && !/\s/.test(res.tg.trim()) && res.src !== 'AI') {
            try {
                const w = await J('https://en.wiktionary.org/api/rest_v1/page/definition/' + encodeURIComponent(res.tg.trim().toLowerCase())), st = h => {
                    const e = document.createElement('div');
                    e.innerHTML = String(h || '');
                    return e.textContent.trim();
                };
                res.defs = (w[tg] || []).slice(0, 2).flatMap(e => (e.definitions || []).slice(0, 2).map(d => ({
                    pos: e.partOfSpeech || '', def: st(d.definition), ex: st((d.examples || [])[0])
                }))).filter(d => d.def).slice(0, 3);
            } catch (e) {
            }
        }
        this.busy = false;
        this.online = res;
        this.paint();
    }
};
reg({
    id: 'dict', order: 11.5, home: true, icon: '📚', name: () => tp('dict'),
    onOpen() {
        setTimeout(() => {
            const b = document.querySelector('.dcat.on');
            if (b)
                b.scrollIntoView({
                    inline: 'center', block: 'nearest'
                });
        }, 120);
    },
    draw({ top }) {
        const my = Dict.users().length, chips = [
            `<button class="dcat ${Dict.cat === 'my' ? 'on' : ''}" data-dcat="my">${icon('user', 14)} ${esc(t('dmy'))} ${my}</button>`
        ].concat(DICT.map(c => `<button class="dcat ${Dict.cat === c.id ? 'on' : ''}" data-dcat="${c.id}">${esc(Dict.cname(c))} ${c.w.length}</button>`)).join('');
        const form = Dict.adding ? `<div class="dform"><input id="dwt" placeholder="${esc(t('dword'))} (${esc(LANGS[S.tgt][0])})" autocomplete="off"><input id="dwn" placeholder="${esc(t('dmean'))} (${esc(LANGS[S.nat][0])})" autocomplete="off"><input id="dwx" placeholder="${esc(t('dex'))}" autocomplete="off"><div class="row"><button class="btn s g" data-dcancel="1" aria-label="cancel">${icon('x', 16)}</button><button class="btn s" data-dform="1">${icon('check', 16)} ${esc(t('dsave'))}</button></div></div>` : '';
        Dict.items = Dict.build();
        return top(tp('dict'), 'home', `<button data-dadd="1" aria-label="add">${icon('plus', 20)}</button>`) + `<div class="pb dpb"><div class="dsearch">${icon('search', 18)}<input id="dq" value="${esc(Dict.q)}" placeholder="${esc(t('dsrch'))}" autocomplete="off" autocapitalize="off"><button class="dclr" data-dclr="1" aria-label="clear" style="visibility:${Dict.q ? 'visible' : 'hidden'}">${icon('x', 16)}</button></div>${form}<div class="dcats">${chips}</div><div class="dim dcnt">${DICT_TOTAL} ${esc(t('dwords'))} · <span id="dcount">${Dict.items.length} ${esc(t('dwords'))}</span></div><div id="dlist">${Dict.rows()}</div></div>`;
    },
    click(e, q) {
        if (Ph.view !== 'dict')
            return;
        const b = s => q(s);
        let x;
        if (x = b('[data-dsp]')) {
            const it = Dict.items[+x.dataset.dsp];
            if (it)
                Dict.speak(it.tg);
            return true;
        }
        if (b('[data-dspo]')) {
            if (Dict.online)
                Dict.speak(Dict.online.tg);
            return true;
        }
        if (x = b('[data-dcat]')) {
            Dict.cat = x.dataset.dcat;
            Dict.q = '';
            Dict.online = null;
            Ph.draw();
            setTimeout(() => {
                const o = document.querySelector('.dcat.on');
                if (o)
                    o.scrollIntoView({
                        inline: 'center', block: 'nearest'
                    });
            }, 40);
            return true;
        }
        if (x = b('[data-dopen]')) {
            Dict.det = Dict.items[+x.dataset.dopen];
            if (Dict.det) {
                Ph.go('dentry');
                return true;
            }
        }
        if (b('[data-dadd]')) {
            Dict.adding = !Dict.adding;
            Ph.draw();
            if (Dict.adding)
                setTimeout(() => {
                    const i = document.getElementById('dwt');
                    i && i.focus();
                }, 60);
            return true;
        }
        if (b('[data-dcancel]')) {
            Dict.adding = false;
            Ph.draw();
            return true;
        }
        if (b('[data-dform]')) {
            const v = id => (document.getElementById(id) || {}).value || '';
            if (!Dict.saveUser(v('dwt'), v('dwn'), v('dwx'))) {
                toast('warning', t('dword') + ' + ' + t('dmean'));
                return true;
            }
            Dict.adding = false;
            Dict.cat = 'my';
            Dict.q = '';
            toast('check', t('dsaved'));
            Ph.draw();
            return true;
        }
        if (b('[data-dclr]')) {
            Dict.q = '';
            Dict.online = null;
            Ph.draw();
            return true;
        }
        if (b('[data-donl]')) {
            Dict.lookup(Dict.q);
            return true;
        }
        if (b('[data-dsave]')) {
            const o = Dict.online;
            if (o && Dict.saveUser(o.tg, o.nat, (o.defs.find(d => d.ex) || {}).ex)) {
                toast('check', t('dsaved'));
                Dict.cat = 'my';
                Dict.q = '';
                Dict.online = null;
                Ph.draw();
            }
            return true;
        }
    },
    key(e) {
        if (Ph.view === 'dict' && e.target && e.target.id === 'dq' && Dict.q.trim().length > 1) {
            Dict.lookup(Dict.q);
            return true;
        }
    }
});
/* detail page: the word in every language */
reg({
    id: 'dentry',
    draw({ top }) {
        const it = Dict.det;
        if (!it)
            return top(tp('dict'), 'dict') + '<div class="pb"></div>';
        const all = it.r ? ['az', 'tr', 'ru', 'en', 'de', 'es', 'zh', 'ko'].map(l => `<div class="dall ${l === S.tgt ? 'on' : ''}">${flag(l, 18)}<span>${esc(it.r[LI[l]])}</span></div>`).join('') : '';
        return top(tp('dict'), 'dict') + `<div class="pb"><div class="dbig"><b>${esc(it.tg)}</b><button class="dsp big" data-dspd="1" aria-label="speak">${icon('speaker', 24)}</button></div><div class="dmean">${flag(S.nat, 16)} ${esc(it.nt)}</div><div class="dim">${esc(it.cat)}</div>${it.u && it.u.ex ? `<div class="ddef"><i>${esc(t('dex'))}</i> <em>${esc(it.u.ex)}</em></div>` : ''}${all ? `<div class="dim dsec">${esc(t('dother'))}</div>${all}` : ''}${it.u ? `<button class="btn s g" data-ddel="1">${icon('trash', 16)}</button>` : ''}</div>`;
    },
    click(e, q) {
        if (Ph.view !== 'dentry')
            return;
        if (q('[data-dspd]')) {
            if (Dict.det)
                Dict.speak(Dict.det.tg);
            return true;
        }
        if (q('[data-ddel]') && Dict.det && Dict.det.u) {
            Store.set('dict_user', Store.get('dict_user', []).filter(x => x.id !== Dict.det.u.id));
            Dict.det = null;
            Ph.go('dict');
            return true;
        }
    }
});
document.getElementById('scr').addEventListener('input', e => {
    if (e.target.id === 'dq') {
        Dict.q = e.target.value;
        Dict.online = null;
        Dict.paint();
    }
});
