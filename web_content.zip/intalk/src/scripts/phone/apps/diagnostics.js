/**
 * App: diagnostics (Settings -> AI / sound / microphone). Shows what this device can do and runs quick
 * tests.
 *
 * Provides: SAMPLE, caps, runDiag, runSnd, app:diag
 */
const SAMPLE = {
    az: 'Salam, necəsən?', tr: 'Merhaba, nasılsın?', ru: 'Привет, как дела?', en: 'Hello, how are you?', de: 'Hallo, wie geht es dir?', es: 'Hola, ¿cómo estás?', zh: '你好，你好吗？', ko: '안녕하세요, 잘 지내세요?'
};
const caps = () => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition, vs = Voice.voices(), md = navigator.mediaDevices;
    return [
        [
            'Audio', (window.AudioContext || window.webkitAudioContext) ? 'yes · ' + (AudioHub.ctx ? AudioHub.ctx.state : 'not started') : 'no'
        ],
        [
            'Speech output', window.speechSynthesis ? 'device voices: ' + vs.length + ' · for ' + S.tgt + ': ' + vs.filter(v => v.lang && v.lang.toLowerCase().startsWith(S.tgt)).length : 'not supported'
        ],
        [
            'Cloud voice', WORKER_URL ? (Voice.cloudOff ? 'Worker unreachable' : 'Worker configured') : 'no Worker'
        ],
        [
            'Speech input', SR ? 'browser recognition' : (md && md.getUserMedia && WORKER_URL ? 'recorder + Worker' : 'not available')
        ], ['Microphone API', md && md.getUserMedia ? 'yes' : 'no']
    ];
};
reg({
    id: 'diag',
    draw({ top }) {
        const mode = WORKER_URL && !Game.noWorker ? 'Worker' : 'Claude (built-in)', row = r => `<div class="li dgr" style="display:block;cursor:default"><b>${r.ok === null ? '…' : icon(r.ok ? 'check' : 'x', 16)} ${esc(r.n)}</b>${r.len != null ? ` <span class="dim">${r.len} chars</span>` : ''}<pre class="pre">${esc(r.note || '')}</pre></div>`;
        return top('🛠 AI · ' + tp('snd'), 'settings') + `<div class="pb"><div class="li" style="display:block;cursor:default"><b>AI:</b> ${esc(mode)}${WORKER_URL ? `<div class="dim">${esc(WORKER_URL)}</div>` : ''}</div><button class="btn s" data-dg="all" ${Game.diagBusy ? 'disabled' : ''}>Run AI tests</button>${Game.diagBusy ? `<div class="dim">${dots(loadP())}</div>` : ''}${(Game.diag || []).map(row).join('')}
  <div class="li" style="display:block;cursor:default"><b>${esc(tp('snd'))} / ${esc(tp('voi'))} / ${esc(tp('mic'))}</b>${caps().map(c => `<div class="dim">${esc(c[0])}: <b>${esc(c[1])}</b></div>`).join('')}</div>
  <div class="row"><button class="btn s" data-dg="beep">${esc(tp('snd'))}</button><button class="btn s" data-dg="voice">${esc(tp('voi'))}</button><button class="btn s" data-dg="mic">${esc(tp('mic'))}</button></div>${(Game.snd || []).map(row).join('')}
  <div class="li" style="display:block;cursor:default"><b>Last worker response (raw)</b><pre class="pre">${esc(Game.lastBody || '—')}</pre></div><div class="li" style="display:block;cursor:default"><b>Last error</b><pre class="pre">${esc(Game.lastErr || '—')}</pre></div></div>`;
    },
    click(e, q) {
        const b = q('[data-dg]');
        if (Ph.view !== 'diag' || !b)
            return;
        const k = b.dataset.dg;
        if (k === 'all')
            runDiag();
        else
            runSnd(k);
        return true;
    }
});
async function runDiag() {
    Game.diagBusy = 1;
    Game.diag = [];
    Ph.draw();
    const T = [
        ['short text', 'Say hello in Spanish in one short sentence.', false], ['small JSON', 'Reply with exactly this JSON and nothing else: {"ok":true,"n":1}', true], [
            'long answer (40 items)', 'Output ONLY a JSON array of 40 objects like {"i":1,"w":"word"} with i from 1 to 40 and w a common English word.', true
        ], [
            'long prompt (3000+ chars)', 'Filler text to ignore: ' + 'lorem ipsum dolor sit amet '.repeat(120) + '\nNow reply with only the word DONE.', false
        ]
    ];
    for (const [n, p, j] of T) {
        const r = { n };
        try {
            const o = await Game.call(p, j);
            r.len = o.text.length;
            r.ok = r.len > 0;
            r.t = o.truncated;
            const pr = j ? parse(o.text) : 1;
            r.note = (j && !pr ? 'NOT VALID JSON: ' : '') + o.text.slice(0, 90);
            if (j && !pr)
                r.ok = false;
            if (n.startsWith('long answer') && Array.isArray(pr))
                r.note = 'parsed ' + pr.length + ' of 40 items';
        } catch (e) {
            r.len = 0;
            r.ok = false;
            r.note = (e.code || '') + ' ' + (e.message || '');
        }
        Game.diag.push(r);
        Ph.on && Ph.view === 'diag' && Ph.draw();
    }
    Game.diagBusy = 0;
    Ph.on && Ph.view === 'diag' && Ph.draw();
}
async function runSnd(kind) {
    Game.snd = Game.snd || [];
    const put = (r) => {
        Game.snd.push(r);
        Ph.on && Ph.view === 'diag' && Ph.draw();
        return Game.snd.length - 1;
    }, set = (i, r) => {
        Game.snd[i] = r;
        Ph.on && Ph.view === 'diag' && Ph.draw();
    };
    if (kind === 'beep') {
        const c = await AudioHub.get();
        if (!c) {
            put({
                n: 'Sound effect', ok: false, note: 'AudioContext not supported'
            });
            return;
        }
        const was = Sfx.on;
        Sfx.on = true;
        Sfx.play('level');
        Sfx.on = was;
        put({
            n: 'Sound effect', ok: c.state === 'running', note: 'AudioContext: ' + c.state + ' (you should hear a short melody)'
        });
    } else if (kind === 'voice') {
        const i = put({
            n: 'Voice (' + S.tgt + ')', ok: null, note: '…'
        });
        await new Promise(r => Voice.speak(SAMPLE[S.tgt] || SAMPLE.en, {
            name: 'Test', look: {
                g: 'f', t: 0
            }
        }, r));
        set(i, {
            n: 'Voice (' + S.tgt + ')', ok: !!Voice.last.engine, note: 'engine: ' + (Voice.last.engine || 'none') + (Voice.last.err ? ' · ' + Voice.last.err : '') + ' (you should hear: ' + (SAMPLE[S.tgt] || '') + ')'
        });
    } else if (kind === 'mic') {
        const i = put({
            n: 'Microphone', ok: null, note: 'speak now (2.5 s)…'
        });
        try {
            const st = await navigator.mediaDevices.getUserMedia({ audio: true }), c = await AudioHub.get(), src = c.createMediaStreamSource(st), an = c.createAnalyser();
            an.fftSize = 1024;
            src.connect(an);
            const buf = new Float32Array(an.fftSize), t0 = Date.now();
            let peak = 0;
            await new Promise(r => {
                const iv = setInterval(() => {
                    an.getFloatTimeDomainData(buf);
                    let s = 0;
                    for (const x of buf)
                        s += x * x;
                    peak = Math.max(peak, Math.sqrt(s / buf.length));
                    if (Date.now() - t0 > 2500) {
                        clearInterval(iv);
                        r();
                    }
                }, 60);
            });
            st.getTracks().forEach(x => x.stop());
            set(i, {
                n: 'Microphone', ok: peak > .005, note: 'input level ' + (peak * 100).toFixed(1) + '%' + (peak > .005 ? '' : ' - nothing heard')
            });
        } catch (e) {
            set(i, {
                n: 'Microphone', ok: false, note: String(e && e.message || e)
            });
        }
    }
}
