/**
 * Audio: ONE shared AudioContext (music, sound effects, voice playback), unlocked by the first tap;
 * Sfx = short synthesized sound effects; Wav = helpers to encode/decode audio for the voice features
 *
 * Provides: AudioHub, Wav, Sfx
 */
const AudioHub = {
    ctx: null,
    async get() {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC)
            return null;
        if (!this.ctx)
            this.ctx = new AC();
        if (this.ctx.state !== 'running') {
            try {
                await this.ctx.resume();
            } catch (e) {
            }
        }
        return this.ctx;
    },
    unlock() {
        this.get().then(c => {
            if (!c)
                return;
            const s = c.createBufferSource();
            s.buffer = c.createBuffer(1, 1, 22050);
            s.connect(c.destination);
            s.start(0);
        });
        try {
            if ('speechSynthesis' in window) {
                const u = new SpeechSynthesisUtterance(' ');
                u.volume = 0;
                speechSynthesis.speak(u);
            }
        } catch (e) {
        }
    }
};
(() => {
    const ev = ['pointerdown', 'touchstart', 'keydown'], f = () => {
        AudioHub.unlock();
        ev.forEach(e => window.removeEventListener(e, f, true));
    };
    ev.forEach(e => window.addEventListener(e, f, true));
})();
const Wav = {
    encode(f32, rate) {
        const n = f32.length, b = new ArrayBuffer(44 + n * 2), v = new DataView(b), w = (o, s) => {
            for (let i = 0; i < s.length; i++)
                v.setUint8(o + i, s.charCodeAt(i));
        };
        w(0, 'RIFF');
        v.setUint32(4, 36 + n * 2, true);
        w(8, 'WAVEfmt ');
        v.setUint32(16, 16, true);
        v.setUint16(20, 1, true);
        v.setUint16(22, 1, true);
        v.setUint32(24, rate, true);
        v.setUint32(28, rate * 2, true);
        v.setUint16(32, 2, true);
        v.setUint16(34, 16, true);
        w(36, 'data');
        v.setUint32(40, n * 2, true);
        for (let i = 0; i < n; i++) {
            const s = Math.max(-1, Math.min(1, f32[i]));
            v.setInt16(44 + i * 2, s < 0 ? s * 0x8000 : s * 0x7fff, true);
        }
        return b;
    },
    b64(buf) {
        let s = '';
        const u = new Uint8Array(buf);
        for (let i = 0; i < u.length; i += 0x8000)
            s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000));
        return btoa(s);
    },
    fromB64(b) {
        const s = atob(b), u = new Uint8Array(s.length);
        for (let i = 0; i < s.length; i++)
            u[i] = s.charCodeAt(i);
        return u.buffer;
    },
    down(f, from, to) {
        if (from <= to)
            return f;
        const r = from / to, n = Math.floor(f.length / r), o = new Float32Array(n);
        for (let i = 0; i < n; i++) {
            const a = Math.floor(i * r), b = Math.min(f.length, Math.floor((i + 1) * r));
            let s = 0;
            for (let j = a; j < b; j++)
                s += f[j];
            o[i] = s / Math.max(1, b - a);
        }
        return o;
    },
    decode(ctx, ab) {
        return new Promise((res, rej) => {
            const p = ctx.decodeAudioData(ab, res, rej);
            if (p && p.catch)
                p.catch(rej);
        });
    }
};
const Sfx = {
    on: Store.get('sfx', true), vol: .5,
    toggle() {
        this.on = !this.on;
        Store.set('sfx', this.on);
        if (this.on)
            this.play('ok');
    },
    SET: {
        tap: [[620, .04, 0, 'sine', .1]], send: [[520, .07, 0, 'sine', .16], [780, .09, .07, 'sine', .15]], recv: [[740, .08, 0, 'sine', .15], [988, .12, .09, 'sine', .13]], notify: [[880, .1, 0, 'triangle', .15], [1175, .16, .11, 'triangle', .13]],
        ok: [[660, .1, 0, 'sine', .17], [880, .14, .1, 'sine', .17]], bad: [[300, .16, 0, 'sawtooth', .09], [220, .2, .12, 'sawtooth', .09]], xp: [[900, .05, 0, 'sine', .09], [1200, .07, .05, 'sine', .09]],
        level: [
            [523, .14, 0, 'triangle', .2], [659, .14, .14, 'triangle', .2], [784, .14, .28, 'triangle', .2], [1046, .32, .42, 'triangle', .22]
        ], goal: [[784, .12, 0, 'sine', .2], [988, .12, .12, 'sine', .2], [1318, .28, .24, 'sine', .2]]
    },
    async play(k) {
        if (!this.on)
            return;
        let c;
        try {
            c = await AudioHub.get();
        } catch (e) {
            return;
        }
        if (!c)
            return;
        const t = c.currentTime;
        (this.SET[k] || []).forEach(([f, d, o, w, v]) => {
            const os = c.createOscillator(), g = c.createGain();
            os.type = w;
            os.frequency.value = f;
            g.gain.setValueAtTime(.0001, t + o);
            g.gain.linearRampToValueAtTime(v * this.vol * 2, t + o + .01);
            g.gain.exponentialRampToValueAtTime(.0001, t + o + d);
            os.connect(g);
            g.connect(c.destination);
            os.start(t + o);
            os.stop(t + o + d + .02);
        });
    }
};
document.addEventListener('click', e => {
    if (e.target.closest && e.target.closest('button,.chip,.app,a.app,.lvc,.avt,.pcard,.mk,[data-go]'))
        Sfx.play('tap');
}, true);
