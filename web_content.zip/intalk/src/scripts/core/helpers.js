/**
 * Shared UI helpers: DOM, escaping, toasts, language shortcuts
 *
 * Provides: $, S, t, chips, fl, toast, clean, saveMistakes, mistakeHtml, unreadTotal, LC, logo, wordmark, confirmDlg, trivialMistake, realMistakes
 */
const $ = id => document.getElementById(id), esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;'
}[c]));
let S = Store.get('profile', {
    nat: 'az', tgt: 'en', lvl: 'A1', gen: 'm', age: '', job: '', nick: ''
});
const t = k => T[S.nat][k], LOAD = {
    az: 'Yüklənir…', tr: 'Yükleniyor…', ru: 'Загрузка…', en: 'Loading…', de: 'Lädt…', es: 'Cargando…', zh: '加载中…', ko: '로딩 중…'
}, load = () => LOAD[S.nat], loadP = () => LOAD[S.tgt], tp = k => T[S.tgt][k], dots = l => `<span class="dots">${l || t('think')} <span>•</span><span>•</span><span>•</span></span>`;
const chips = (f, map, cur) => Object.entries(map).map(([k, v]) => `<button class="chip ${cur === k ? 'on' : ''}" data-f="${f}" data-v="${k}">${v}</button>`).join('');
const fl = ex => Object.fromEntries(Object.entries(LANGS).filter(([k]) => k !== ex).map(([k, v]) => [k, v[1] + ' ' + v[0]]));
function toast(ic, txt, fn) {
    if (typeof Sfx !== 'undefined')
        Sfx.play('notify');
    const d = document.createElement('div');
    d.className = 'toast';
    d.innerHTML = `<span class="ti">${ICO[ic] ? icon(ic, 20) : esc(ic)}</span><span>${esc(txt)}</span>`;
    d.onclick = () => {
        d.remove();
        fn && fn();
    };
    document.body.appendChild(d);
    setTimeout(() => d.remove(), 4500);
}
const clean = s => String(s ?? '').replace(/\+?\d[\d\s().-]{6,}\d/g, '');
const saveMistakes = m => {
    const all = Store.get('mistakes', []);
    m.forEach(x => all.push({
        ...x, id: Date.now() + Math.random()
    }));
    Store.set('mistakes', all);
};
const mistakeHtml = m => m && m.length ? `<div class="err"><b class="nk">${icon('note', 14)}</b> ${m.map(x => `<div><s>${esc(x.wrong)}</s> → <u>${esc(x.right)}</u><br><span class="dim">${esc(x.note)}</span></div>`).join('')}</div>` : '';
const unreadTotal = () => Object.values(Game.npcs || {}).reduce((a, n) => a + n.unread, 0) + Object.values(Game.threads || {}).reduce((a, n) => a + (n.unread || 0), 0);
const LC = {
    az: 'az-AZ', tr: 'tr-TR', ru: 'ru-RU', en: 'en-US', de: 'de-DE', es: 'es-ES', zh: 'zh-CN', ko: 'ko-KR'
};
const logo = sz => `<span class="logo-t" style="width:${sz}px;height:${sz}px"><img src="${MASCOT.face}" alt="InTalk" draggable="false"></span>`;
const wordmark = () => '<span class="wm">In<b>Talk</b></span>';
/* in-app confirmation dialog (window.confirm is blocked in many WebViews) */
function confirmDlg(title, msg, yes, no, onYes) {
    const d = document.createElement('div');
    d.className = 'dlg';
    d.innerHTML = `<div class="dlg-card">${mascot('peace', 96)}<b>${esc(title)}</b><p>${esc(msg)}</p><div class="row"><button class="btn g" data-dlg="no">${esc(no)}</button><button class="btn" data-dlg="yes">${esc(yes)}</button></div></div>`;
    d.addEventListener('click', e => {
        const b = e.target.closest('[data-dlg]');
        if (!b && e.target !== d)
            return;
        const ok = !!b && b.dataset.dlg === 'yes';
        d.remove();
        if (ok)
            onYes();
    });
    document.body.appendChild(d);
}
/* only real spelling / grammar / word-choice mistakes count: spacing, punctuation and capitalization are ignored */
const trivialMistake = m => {
    const f = s => String(s || '').toLocaleLowerCase().replace(/[\p{P}\p{S}\s]+/gu, '');
    return f(m.wrong) === f(m.right);
};
const realMistakes = a => (Array.isArray(a) ? a : []).filter(m => m && m.wrong && m.right && !trivialMistake(m));
