/**
 * InTalk mascot: transparent WebP images from src/assets (wave, both, peace, thumb, bust, face)
 *
 * Provides: MASCOT, mascot
 */
const MASCOT = ASSETS.mascot; // images come from src/assets/mascot/*.webp (embedded by tools/build.js)
const mascot = (k, sz, cls) => `<img class="mascot ${cls || ''}" src="${MASCOT[k]}"${sz ? ` width="${sz}"` : ''} alt="InTalk" draggable="false">`;
