/**
 * Voice. OUTPUT: device voices (Web Speech) first; if the device cannot speak (typical in WebView/APK)
 * -> cloud voice via the Worker. INPUT: browser speech recognition first; if unavailable (WebView) ->
 * record the microphone and let the Worker transcribe it.
 *
 * Provides: SPEAK_FALL, Voice
 */
const SPEAK_FALL = { az: ['tr-TR'] }; /* languages with no installed voice borrow a close one */
const Voice = {
    tts: Store.get('tts', true), rec: null, proc: false, conv: false, maxMs: 12000, forceSend: false, last: {}, playing: null,
    voices() {
        try {
            return window.speechSynthesis ? (speechSynthesis.getVoices() || []) : [];
        } catch (e) {
            return [];
        }
    },
    pick(n, lg) {
        const l = String(lg || LC[S.tgt]).toLowerCase().replace('_', '-'), vs = this.voices(), ex = vs.filter(x => x.lang && x.lang.toLowerCase().replace('_', '-') === l), pre = vs.filter(x => x.lang && x.lang.toLowerCase().startsWith(l.slice(0, 2))), pool = ex.length ? ex : pre;
        return pool.length ? pool[hash((n && n.name) || '') % pool.length] : null;
    },
    toggleTts() {
        this.tts = !this.tts;
        Store.set('tts', this.tts);
        if (!this.tts)
            this.stopSpeak();
        render();
    },
    stopSpeak() {
        try {
            if (window.speechSynthesis)
                speechSynthesis.cancel();
        } catch (e) {
        }
        if (this.playing) {
            try {
                this.playing.stop();
            } catch (e) {
            }
            this.playing = null;
        }
    },
    queue(text, n) {
        if (!this.tts)
            return;
        this._q = (this._q || Promise.resolve()).then(() => new Promise(r => this.speak(text, n, r)));
    },
    cancelAll() {
        this._q = Promise.resolve();
        this.stopSpeak();
    },
    plain: s => String(s).replace(/\([^)]*\)/g, '').replace(/\s+/g, ' ').trim(),
    micFail(why) {
        if (why)
            this.last.err = String(why);
        toast('mic', t('nom') + ' [' + (this.last.err || '?') + ']');
    },
    gtts(text) {
        const map = {
            az: ['az', 'tr'], tr: ['tr'], ru: ['ru'], en: ['en'], de: ['de'], es: ['es'], zh: ['zh-CN'], ko: ['ko']
        }[S.tgt] || ['en'], parts = (text.match(/[^.!?;。！？]+[.!?;。！？]*/g) || [text]).flatMap(p => p.length <= 170 ? [p.trim()] : (p.match(/.{1,170}(\s|$)/g) || [p])).filter(Boolean);
        return new Promise(res => {
            let i = 0, li = 0;
            const next = () => {
                if (i >= parts.length) {
                    this.last.engine = 'gtts';
                    return res(true);
                }
                const a = new Audio('https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=' + map[li] + '&q=' + encodeURIComponent(parts[i]));
                this.playing = { stop() {
                        try {
                            a.pause();
                        } catch (e) {
                        }
                        res(false);
                    } };
                a.onended = () => {
                    i++;
                    next();
                };
                a.onerror = () => {
                    if (li < map.length - 1) {
                        li++;
                        next();
                    } else {
                        this.last.err = (this.last.err ? this.last.err + ' / ' : '') + 'tts-audio';
                        res(false);
                    }
                };
                const p = a.play();
                if (p && p.catch)
                    p.catch(e => {
                        this.last.err = (this.last.err ? this.last.err + ' / ' : '') + (e.name || 'play');
                        res(false);
                    });
            };
            next();
        });
    },
    canCloud() {
        return !!WORKER_URL && !this.cloudOff;
    },
    /* the Worker voices only some languages (Groq: English); once it says no, stop asking for that language */
    canTts() {
        return this.canCloud() && !(this.ttsOff && this.ttsOff[S.tgt]);
    },
    /* cloud voice: the Worker (Groq TTS, English only) returns a WAV; other languages get HTTP 400 and are remembered in ttsOff */
    async cloud(text, n) {
        if (!this.canTts())
            return false;
        try {
            const li = lookInfo(n && n.look);
            let res;
            try {
                res = await fetch(WORKER_URL, {
                    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({
                        task: 'tts', text: text.slice(0, 600), gender: li.f ? 'f' : 'm', lang: S.tgt
                    })
                });
            } catch (e) {
                this.cloudOff = true;
                this.cloudOffAt = Date.now();
                throw e;
            }
            const d = await res.json().catch(() => null);
            if (!res.ok || !d || !d.audio) {
                const msg = (d && d.error) || 'HTTP ' + res.status;
                if (/English only|not supported/i.test(msg))
                    (this.ttsOff = this.ttsOff || {})[S.tgt] = true;
                throw new Error(msg);
            }
            const c = await AudioHub.get();
            if (!c)
                return false;
            const buf = await Wav.decode(c, Wav.fromB64(d.audio));
            return await new Promise(r => {
                const s = c.createBufferSource();
                s.buffer = buf;
                s.connect(c.destination);
                this.playing = s;
                this.last.engine = 'cloud';
                s.onended = () => {
                    this.playing = null;
                    r(true);
                };
                s.start();
            });
        } catch (e) {
            this.last.err = (this.last.err ? this.last.err + ' / ' : '') + 'worker: ' + String(e && e.message || e);
            return false;
        }
    },
    speak(text, n, after) {
        const txt = this.plain(text);
        let fin = false, fell = false;
        const done = () => {
            if (fin)
                return;
            fin = true;
            after && after();
        };
        this.stopSpeak();
        this.last = { err: '' };
        const why = m => {
            this.last.err = (this.last.err ? this.last.err + ' / ' : '') + m;
        };
        if (!txt) {
            done();
            return;
        }
        if (this.cloudOff && Date.now() - (this.cloudOffAt || 0) > 60000)
            this.cloudOff = false;
        const fall = () => {
            if (fell)
                return;
            fell = true;
            if (!this.canTts())
                why(!WORKER_URL ? 'no worker' : this.cloudOff ? 'worker unreachable' : 'worker has no voice for ' + S.tgt);
            this.cloud(txt, n).then(ok => ok || this.gtts(txt)).then(ok => {
                if (!ok)
                    toast('speakerOff', t('nov') + ' [' + (this.last.err || '?') + ']');
                done();
            });
        };
        const dev = !!(window.speechSynthesis && typeof SpeechSynthesisUtterance !== 'undefined'), all = [LC[S.tgt], ...(SPEAK_FALL[S.tgt] || [])], have = this.voices().length ? all.filter(l => this.pick(n, l)) : [], langs = have.length ? have : all;
        if (!dev) {
            why('no speechSynthesis');
            fall();
            return;
        }
        if (this.voices().length && !have.length && this.canTts()) {
            why('no device voice for ' + S.tgt);
            fall();
            return;
        }
        const li = lookInfo(n && n.look);
        let ai = 0;
        const tryDev = () => {
            if (fin || fell)
                return;
            const lg = langs[ai];
            if (!lg) {
                fall();
                return;
            }
            let started = false, moved = false;
            const next = m => {
                if (moved || started || fin || fell)
                    return;
                moved = true;
                why('device(' + lg + '): ' + m);
                try {
                    speechSynthesis.cancel();
                } catch (e) {
                }
                ai++;
                tryDev();
            };
            const u = new SpeechSynthesisUtterance(txt), v = this.pick(n, lg);
            u.lang = v ? v.lang : lg;
            if (v)
                u.voice = v;
            u.rate = .95;
            u.pitch = (li.f ? 1.2 : .92) * (li.old ? .92 : 1);
            u.onstart = () => {
                started = true;
                this.last.engine = 'device';
            };
            u.onend = () => {
                if (started)
                    done();
                else
                    next('ended without sound');
            };
            u.onerror = e => {
                if (started)
                    done();
                else
                    next((e && e.error) || 'error');
            };
            window.__utter = u;
            try {
                speechSynthesis.cancel();
                speechSynthesis.resume();
                setTimeout(() => {
                    if (!fin && !fell && !moved) {
                        try {
                            speechSynthesis.speak(u);
                        } catch (e) {
                            next('speak() threw');
                        }
                    }
                }, 70);
            } catch (e) {
                next('cancel() threw');
                return;
            }
            setTimeout(() => {
                if (!started)
                    next('no start');
            }, 2000);
        };
        tryDev();
    },
    say(text, n, viaVoice) {
        if (!this.tts)
            return;
        this.speak(text, n, () => {
            if ((viaVoice || this.conv) && Game.view === 'chat')
                this.listen();
        });
    },
    listen() {
        const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (this.rec) {
            this.stopRec();
            return;
        }
        if (this.proc || Game.view !== 'chat' || (Game.npcs[Game.cur] && Game.npcs[Game.cur].pending) || (Game.grp && Game.groups[Game.grp] && Game.groups[Game.grp].pending))
            return;
        if (!Perm.micOn()) {
            Perm.mic().then(ok => {
                if (ok) {
                    toast('mic', t('grant'));
                    this.listen();
                } else
                    this.micFail(Perm.err);
            });
            return;
        }
        if (SR)
            this.srListen(SR);
        else
            this.record();
    },
    stopRec() {
        const r = this.rec;
        if (!r)
            return;
        try {
            r.stop && r.stop();
        } catch (e) {
        }
        if (r.kind === 'sr') {
            this.rec = null;
            this.conv = false;
            render();
        }
    },
    srListen(SR) {
        const r = new SR();
        r.lang = LC[S.tgt];
        r.interimResults = false;
        r.maxAlternatives = 1;
        r.kind = 'sr';
        this.rec = r;
        this.conv = true;
        let got = false;
        r.onresult = e => {
            got = true;
            this.rec = null;
            sendNpc(e.results[0][0].transcript, true);
        };
        r.onerror = e => {
            this.rec = null;
            this.conv = false;
            render();
            if (['network', 'service-not-allowed', 'language-not-supported'].includes(e.error) && this.canCloud()) {
                this.record();
                return;
            }
            this.micFail('recognition:' + e.error);
        };
        r.onend = () => {
            if (this.rec === r) {
                this.rec = null;
                if (!got)
                    this.conv = false;
                render();
            }
        };
        try {
            r.start();
            render();
        } catch (e) {
            this.rec = null;
            this.conv = false;
            this.record();
        }
    },
    /* recorder fallback: capture microphone -> 16 kHz WAV -> Worker transcription */
    async record() {
        const md = navigator.mediaDevices;
        if (!md || !md.getUserMedia) {
            this.micFail(self !== top ? 'blocked in embedded page' : 'no microphone API (insecure page or WebView without permission)');
            return;
        }
        if (!WORKER_URL) {
            this.micFail('no Worker address');
            return;
        }
        let st;
        try {
            st = await md.getUserMedia({
                audio: {
                    channelCount: 1, echoCancellation: true, noiseSuppression: true
                }
            });
        } catch (e) {
            this.micFail(e && e.name || e);
            return;
        }
        const c = await AudioHub.get();
        if (!c) {
            st.getTracks().forEach(x => x.stop());
            this.micFail('no AudioContext');
            return;
        }
        const src = c.createMediaStreamSource(st), pr = c.createScriptProcessor(4096, 1, 1), chunks = [], rate = c.sampleRate, t0 = Date.now();
        let voiced = false, quiet = 0, end = false;
        const r = { kind: 'rec' };
        this.rec = r;
        this.conv = true;
        render();
        const finish = async (send) => {
            if (end)
                return;
            end = true;
            try {
                pr.disconnect();
                src.disconnect();
            } catch (e) {
            }
            st.getTracks().forEach(x => x.stop());
            this.rec = null;
            if (!send || !chunks.length || !(voiced || this.forceSend)) {
                this.conv = false;
                render();
                return;
            }
            this.proc = true;
            render();
            try {
                const f = new Float32Array(chunks.reduce((a, x) => a + x.length, 0));
                let o = 0;
                chunks.forEach(x => {
                    f.set(x, o);
                    o += x.length;
                });
                const text = await this.transcribe(Wav.b64(Wav.encode(Wav.down(f, rate, 16000), 16000)));
                this.proc = false;
                if (text)
                    sendNpc(text, true);
                else {
                    this.conv = false;
                    this.micFail('empty transcript');
                    render();
                }
            } catch (e) {
                this.proc = false;
                this.conv = false;
                this.conv = false;
                this.micFail('transcribe: ' + (e && e.message || e));
                render();
            }
        };
        pr.onaudioprocess = e => {
            if (end)
                return;
            const d = e.inputBuffer.getChannelData(0);
            chunks.push(new Float32Array(d));
            let s = 0;
            for (let i = 0; i < d.length; i++)
                s += d[i] * d[i];
            const rms = Math.sqrt(s / d.length);
            if (rms > .015) {
                voiced = true;
                quiet = 0;
            } else if (voiced)
                quiet += d.length / rate;
            if ((voiced && quiet > 1.3) || Date.now() - t0 > this.maxMs)
                finish(true);
        };
        src.connect(pr);
        pr.connect(c.destination);
        r.stop = () => finish(true);
        r.cancel = () => finish(false);
    },
    async transcribe(b64) {
        const res = await fetch(WORKER_URL, {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({
                task: 'stt', audio: b64, mime: 'audio/wav', lang: S.tgt
            })
        });
        const d = await res.json().catch(() => null);
        if (!res.ok || !d || d.error)
            throw new Error((d && d.error) || 'HTTP ' + res.status);
        return String(d.text || '').trim();
    }
};
