/**
 * Device permissions: asks the phone for microphone access when the user switches it on (or taps the
 * mic for the first time)
 *
 * Provides: Perm
 */
const Perm = {
    err: '',
    micOn() {
        return Store.get('mic', false);
    },
    async mic() {
        try {
            if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia)
                throw new Error('no getUserMedia');
            const st = await navigator.mediaDevices.getUserMedia({ audio: true });
            st.getTracks().forEach(x => x.stop());
            Store.set('mic', true);
            this.err = '';
            return true;
        } catch (e) {
            Store.set('mic', false);
            this.err = (self !== top && /NotAllowed|Security/.test(e.name || '') ? 'blocked in embedded page: ' : '') + (e.name || e.message);
            return false;
        }
    },
    async state() {
        try {
            if (navigator.permissions && navigator.permissions.query)
                return (await navigator.permissions.query({ name: 'microphone' })).state;
        } catch (e) {
        }
        return 'unknown';
    }
};
