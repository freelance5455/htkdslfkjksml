/**
 * Persistence (localStorage), daily streak (with freezes) and learning stats
 *
 * Provides: Store, iso, Streak, Stats, saveStats
 */
const Store = {
    get(k, d) {
        try {
            return JSON.parse(localStorage.getItem('intalk_' + k)) ?? d;
        } catch {
            return d;
        }
    }, set(k, v) {
        try {
            localStorage.setItem('intalk_' + k, JSON.stringify(v));
        } catch {
        }
    }
};
/* one-time migration of data saved under the old project name (lq_) */
try {
    Object.keys(localStorage).filter(k => k.startsWith('lq_')).forEach(k => {
        const n = 'intalk_' + k.slice(3);
        if (localStorage.getItem(n) === null)
            localStorage.setItem(n, localStorage.getItem(k));
    });
} catch (e) {
}
const iso = o => new Date(Date.now() - (o || 0) * 864e5).toLocaleDateString('en-CA');
const Streak = {
    day: iso,
    data() {
        return Store.get('streak', {
            n: 0, best: 0, last: '', freeze: 0, days: []
        });
    },
    /* current streak: still alive if active today/yesterday, or the day before with a freeze in stock */
    n() {
        const s = this.data();
        return (s.last === iso(0) || s.last === iso(1) || (s.last === iso(2) && s.freeze > 0)) ? s.n : 0;
    },
    doneToday() {
        return this.data().last === iso(0);
    },
    touch() {
        const s = this.data(), t = iso(0);
        if (s.last === t)
            return s.n;
        if (s.last === iso(1))
            s.n++;
        else if (s.last === iso(2) && s.freeze > 0) {
            s.freeze--;
            s.n++;
        } else
            s.n = 1;
        s.last = t;
        s.best = Math.max(s.best || 0, s.n);
        s.days = (s.days || []).concat(t).slice(-120);
        if (s.n % 7 === 0 && (s.freeze || 0) < 2)
            s.freeze = (s.freeze || 0) + 1;
        Store.set('streak', s);
        if (typeof Progress !== 'undefined')
            Progress.newDay(s.n);
        return s.n;
    },
    week() {
        const s = this.data();
        return [6, 5, 4, 3, 2, 1, 0].map(o => ({
            d: iso(o), on: (s.days || []).includes(iso(o)), today: o === 0
        }));
    }
};
const Stats = () => Store.get('stats', {
    msgs: 0, clean: 0, friends: 0, places: {}, wins: 0, days: {}, goal: {}
});
const saveStats = s => Store.set('stats', s);
