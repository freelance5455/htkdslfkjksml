/**
 * Icon system: one consistent set of line icons (inline SVG, currentColor), round flag icons, and an
 * automatic pass that swaps emoji / arrow glyphs inside UI controls for these icons (chat bubbles and
 * other user/AI text are never touched).
 *
 * Provides: ICO, ICON_INNER, icon, FLAGS, flag, EMOJI_ICON, FLAG_OF, placeEmoji, glyphHtml, EMO_RX, UI_SEL, SKIP_SEL, iconifyText, iconify
 */
const ICO = {
    home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/>',
    map: '<path d="M12 21s7-6.2 7-11a7 7 0 1 0-14 0c0 4.8 7 11 7 11z"/><circle cx="12" cy="10" r="2.5"/>',
    users: '<circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.5 2.7-6 6-6s6 2.5 6 6"/><circle cx="17" cy="9" r="2.5"/><path d="M17 14c2.5 0 4 1.8 4 4.5"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4.5 21c0-4.2 3.4-7 7.5-7s7.5 2.8 7.5 7"/>',
    phoneDev: '<rect x="7" y="2.5" width="10" height="19" rx="2.5"/><path d="M11 18.5h2"/>',
    phone: '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A15 15 0 0 1 3 6a2 2 0 0 1 2-2z"/>',
    search: '<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/>',
    chevL: '<path d="M15 5l-7 7 7 7"/>', chevR: '<path d="M9 5l7 7-7 7"/>',
    send: '<path d="M21 3L10 14"/><path d="M21 3l-6.5 18-3.5-7-7-3.5z"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5.5 11a6.5 6.5 0 0 0 13 0"/><path d="M12 17.5V21"/>',
    speaker: '<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path d="M15.5 9a4 4 0 0 1 0 6"/><path d="M18 6.5a8 8 0 0 1 0 11"/>',
    speakerOff: '<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path d="M16 9l5 6M21 9l-5 6"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    refresh: '<path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4v7h-7"/>',
    trash: '<path d="M4 7h16"/><path d="M9 7V4h6v3"/><path d="M6 7l1 13h10l1-13"/><path d="M10 11v6M14 11v6"/>',
    plus: '<path d="M12 5v14M5 12h14"/>', check: '<path d="M5 12.5l4.5 4.5L19 7"/>',
    flame: '<path d="M12 3c1 3.5 5 5.5 5 10a5 5 0 0 1-10 0c0-2 1-3.4 2.2-4.6C9.5 10 10.5 11 11 11.5 11.8 9 12 6 12 3z"/>',
    star: '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
    bolt: '<path d="M13 2.5L5 13.5h6l-1 8 8-11h-6z"/>',
    trophy: '<path d="M8 4h8v5a4 4 0 0 1-8 0z"/><path d="M8 6H4v1.5A3.5 3.5 0 0 0 8 11M16 6h4v1.5A3.5 3.5 0 0 1 16 11"/><path d="M12 13v4M8.5 20h7M10 17h4v3h-4z"/>',
    medal: '<circle cx="12" cy="14" r="5.5"/><path d="M8.5 9.5L6.5 3h4l1.5 3M15.5 9.5L17.5 3h-4L12 6"/>',
    crown: '<path d="M3.5 18.5L2.5 7l5.5 4.5L12 5l4 6.5L21.5 7l-1 11.5z"/><path d="M3.5 21h17"/>',
    chat: '<path d="M4 5h16v11H11l-5 4v-4H4z"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18"/><path d="M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>',
    calculator: '<rect x="5" y="3" width="14" height="18" rx="2.5"/><path d="M8.5 7.5h7"/><circle cx="9" cy="12.5" r=".7" fill="currentColor"/><circle cx="12" cy="12.5" r=".7" fill="currentColor"/><circle cx="15" cy="12.5" r=".7" fill="currentColor"/><circle cx="9" cy="16.5" r=".7" fill="currentColor"/><circle cx="12" cy="16.5" r=".7" fill="currentColor"/><circle cx="15" cy="16.5" r=".7" fill="currentColor"/>',
    calendar: '<rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
    news: '<rect x="4" y="4" width="16" height="16" rx="2.5"/><path d="M8 9h8M8 13h8M8 17h5"/>',
    bag: '<path d="M5 8h14l-1 12H6z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/>',
    gamepad: '<rect x="3" y="7" width="18" height="11" rx="5"/><path d="M8 10.5v4M6 12.5h4"/><circle cx="15.5" cy="11.5" r=".9" fill="currentColor"/><circle cx="17.7" cy="13.8" r=".9" fill="currentColor"/>',
    book: '<path d="M5 4h10a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3z"/><path d="M5 17a3 3 0 0 1 3-3h10"/>',
    note: '<path d="M6 3h9l4 4v14H6z"/><path d="M14.5 3v5H19M9 13h7M9 17h5"/>',
    gear: '<circle cx="12" cy="12" r="3"/><path d="M12 3v2.5M12 18.5V21M3 12h2.5M18.5 12H21M5.6 5.6l1.8 1.8M16.6 16.6l1.8 1.8M18.4 5.6l-1.8 1.8M7.4 16.6l-1.8 1.8"/>',
    music: '<path d="M9 18V6l10-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="16.5" cy="16" r="2.5"/>',
    headphones: '<path d="M4 15v-3a8 8 0 0 1 16 0v3"/><rect x="3" y="14" width="4.5" height="6.5" rx="2"/><rect x="16.5" y="14" width="4.5" height="6.5" rx="2"/>',
    play: '<path d="M7 4.5v15l12-7.5z" fill="currentColor"/>', pause: '<path d="M8 5v14M16 5v14" stroke-width="3.2"/>',
    skipB: '<path d="M18 5v14L8.5 12z" fill="currentColor"/><path d="M6 5v14"/>', skipF: '<path d="M6 5v14l9.5-7z" fill="currentColor"/><path d="M18 5v14"/>',
    cap: '<path d="M2.5 9L12 4.5 21.5 9 12 13.5z"/><path d="M6.5 11.5V16c0 1.5 2.5 3 5.5 3s5.5-1.5 5.5-3v-4.5"/><path d="M21.5 9v5"/>',
    briefcase: '<rect x="3" y="7.5" width="18" height="12" rx="2.5"/><path d="M9 7.5V5.5a1.5 1.5 0 0 1 1.5-1.5h3A1.5 1.5 0 0 1 15 5.5v2"/><path d="M3 13h18"/>',
    cup: '<path d="M5 8h11v6a5 5 0 0 1-5 5h-1a5 5 0 0 1-5-5z"/><path d="M16 9.5h1.5a2.5 2.5 0 0 1 0 5H16"/><path d="M8 3.5v2M11 3.5v2"/>',
    cart: '<circle cx="9" cy="19.5" r="1.4"/><circle cx="17" cy="19.5" r="1.4"/><path d="M3 4h2.5l2 11h10l2-8H7"/>',
    tree: '<path d="M12 21v-6"/><path d="M12 3c4 0 6.5 3 5.5 6 2 .5 3 2.5 2 4.5-.8 1.6-2.5 2-4 1.5H8.5c-1.5.5-3.2.1-4-1.5-1-2 0-4 2-4.5C5.5 6 8 3 12 3z"/>',
    bus: '<rect x="4" y="3.5" width="16" height="14" rx="3"/><path d="M4 11h16"/><circle cx="8" cy="14.5" r=".9" fill="currentColor"/><circle cx="16" cy="14.5" r=".9" fill="currentColor"/><path d="M6.5 17.5V20M17.5 17.5V20"/>',
    road: '<path d="M8 3L5 21M16 3l3 18"/><path d="M12 4v3M12 10.5v3M12 17v3"/>',
    building: '<rect x="5" y="3" width="14" height="18" rx="1.5"/><path d="M9 7.5h1.5M13.5 7.5H15M9 11.5h1.5M13.5 11.5H15M10 21v-4h4v4"/>',
    heart: '<path d="M12 20s-7.5-4.6-7.5-10A4.3 4.3 0 0 1 12 7.5 4.3 4.3 0 0 1 19.5 10c0 5.4-7.5 10-7.5 10z"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6L7 7M17 17l1.4 1.4M18.4 5.6L17 7M7 17l-1.4 1.4"/>',
    moon: '<path d="M20 14.5A8 8 0 1 1 9.5 4 6.5 6.5 0 0 0 20 14.5z"/>',
    pencil: '<path d="M4 20l1-4L16.5 4.5a2 2 0 0 1 3 3L8 19z"/><path d="M14.5 6.5l3 3"/>',
    download: '<path d="M12 4v11M7.5 11l4.5 4.5L16.5 11M5 20h14"/>',
    eye: '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="2.8"/>',
    target: '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><circle cx="12" cy="12" r="1" fill="currentColor"/>',
    lock: '<rect x="5" y="10.5" width="14" height="10" rx="2.5"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"/>',
    wrench: '<path d="M14.5 6.5a4 4 0 0 0-5.2 5.2L3.5 17.5l3 3 5.8-5.8A4 4 0 0 0 17.5 9.5l-2.3 2.3-2.5-.5-.5-2.5z"/>',
    swap: '<path d="M4 8h14M14 4l4 4-4 4"/><path d="M20 16H6M10 12l-4 4 4 4"/>',
    warning: '<path d="M12 4l9.5 16h-19z"/><path d="M12 10v4.5"/><circle cx="12" cy="17.5" r=".8" fill="currentColor"/>',
    wallet: '<rect x="3" y="6" width="18" height="13" rx="3"/><path d="M3 10h18M16 14.5h2"/>',
    help: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.6 2.2c-.7.4-1.1.9-1.1 1.8"/><circle cx="12" cy="16.8" r=".8" fill="currentColor"/>',
    type: '<path d="M5 6h14M12 6v13M9 19h6"/>', link: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
    cards: '<rect x="4" y="6" width="11" height="14" rx="2"/><path d="M9 6V5a2 2 0 0 1 2-2h7a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-1"/>',
    circle: '<circle cx="12" cy="12" r="7.5"/>', square: '<rect x="5" y="5" width="14" height="14" rx="3"/>', checkSq: '<rect x="4" y="4" width="16" height="16" rx="4"/><path d="M8.5 12.5l2.5 2.5 4.5-5"/>',
    tag: '<path d="M3 12V4h8l10 10-8 8z"/><circle cx="7.5" cy="8.5" r="1.2" fill="currentColor"/>',
    signal: '<path d="M5 19v-3M10 19v-6M15 19V9M20 19V5"/>', battery: '<rect x="3" y="8" width="16" height="9" rx="2.5"/><path d="M21 11v3"/><rect x="5" y="10" width="9" height="5" rx="1" fill="currentColor" stroke="none"/>',
    bulb: '<path d="M9 18h6M10 21h4"/><path d="M12 3a6 6 0 0 0-3.5 10.8c.7.6 1 1.3 1 2.2h5c0-.9.3-1.6 1-2.2A6 6 0 0 0 12 3z"/>',
    camera: '<path d="M4 8h3l1.5-2.5h7L17 8h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>',
    contrast: '<circle cx="12" cy="12" r="9"/><path d="M12 3v18" /><path d="M12 3a9 9 0 0 1 0 18z" fill="currentColor"/>',
    snow: '<path d="M12 3v18M4.2 7.5l15.6 9M19.8 7.5l-15.6 9"/><path d="M9.5 4.5L12 6.5l2.5-2M9.5 19.5L12 17.5l2.5 2"/>',
    bell: '<path d="M6 16V11a6 6 0 0 1 12 0v5l1.5 2h-15z"/><path d="M10 21h4"/>',
    shirt: '<path d="M8 4l-5 3 2.5 4L8 10v10h8V10l2.5 1L21 7l-5-3a4 4 0 0 1-8 0z"/>',
    utensils: '<path d="M7 3v8M5 3v5a2 2 0 0 0 4 0V3M7 11v10"/><path d="M17 3c-2 1-3 4-3 7h3v11"/>',
    pharmacy: '<path d="M10.5 20a4.5 4.5 0 0 1-3.2-7.7l5-5a4.5 4.5 0 0 1 6.4 6.4l-5 5a4.5 4.5 0 0 1-3.2 1.3z"/><path d="M9.5 9.5l5 5"/>',
    bank: '<path d="M3 9l9-5 9 5z"/><path d="M5 10v8M9.5 10v8M14.5 10v8M19 10v8M3 20h18"/>',
    mail: '<rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="M3.5 7l8.5 6 8.5-6"/>',
    hospital: '<path d="M5 21V5a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v16"/><path d="M12 8v6M9 11h6M10 21v-4h4v4"/>',
    bed: '<path d="M3 18V7M3 14h18v4M21 18v-4a3 3 0 0 0-3-3h-7v3"/><circle cx="7" cy="11" r="1.8"/>',
    dumbbell: '<path d="M6.5 7v10M17.5 7v10M3.5 9.5v5M20.5 9.5v5M6.5 12h11"/>',
    film: '<rect x="3.5" y="4" width="17" height="16" rx="2.5"/><path d="M8 4v16M16 4v16M3.5 9h4.5M16 9h4.5M3.5 15h4.5M16 15h4.5"/>',
    museum: '<path d="M4 20h16M6 20v-8M10 20v-8M14 20v-8M18 20v-8M4 12h16"/><path d="M6 12a6 6 0 0 1 12 0"/>',
    scissors: '<circle cx="6.5" cy="7" r="2.5"/><circle cx="6.5" cy="17" r="2.5"/><path d="M8.5 8.5L20 18M8.5 15.5L20 6"/>',
    bread: '<path d="M4 11a4 4 0 0 1 3-6h10a4 4 0 0 1 3 6v8H4z"/><path d="M9 5v4M14 5v4"/>',
    plane: '<path d="M21 4L3 11l6 2.5L11.5 20 14 14l5-1z"/>',
    train: '<rect x="5" y="3.5" width="14" height="14" rx="3"/><path d="M5 11h14M8 17.5L6 21M16 17.5L18 21"/><circle cx="9" cy="14" r=".9" fill="currentColor"/><circle cx="15" cy="14" r=".9" fill="currentColor"/>',
    water: '<path d="M3 9c3-3 6 3 9 0s6 3 9 0M3 14c3-3 6 3 9 0s6 3 9 0M3 19c3-3 6 3 9 0s6 3 9 0"/>',
    dot: '<circle cx="12" cy="12" r="3" fill="currentColor"/>'
};
const ICON_INNER = n => ICO[n] || ICO.dot;
const icon = (n, sz, cls) => `<svg class="ic ${cls || ''}" width="${sz || 20}" height="${sz || 20}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICON_INNER(n)}</svg>`;
/* round flags (simplified) */
const FLAGS = {
    az: '<rect width="24" height="8" fill="#00b5e2"/><rect y="8" width="24" height="8" fill="#ef3340"/><rect y="16" width="24" height="8" fill="#509e2f"/><circle cx="11" cy="12" r="3.3" fill="#fff"/><circle cx="12" cy="12" r="2.7" fill="#ef3340"/><circle cx="15.3" cy="12" r=".9" fill="#fff"/>',
    tr: '<rect width="24" height="24" fill="#e30a17"/><circle cx="10" cy="12" r="5" fill="#fff"/><circle cx="11.4" cy="12" r="4" fill="#e30a17"/><circle cx="15.2" cy="12" r="1.4" fill="#fff"/>',
    ru: '<rect width="24" height="8" fill="#fff"/><rect y="8" width="24" height="8" fill="#1c57a5"/><rect y="16" width="24" height="8" fill="#d52b1e"/>',
    en: '<rect width="24" height="24" fill="#1d3a8a"/><path d="M0 0L24 24M24 0L0 24" stroke="#fff" stroke-width="4.5"/><path d="M0 0L24 24M24 0L0 24" stroke="#d6283c" stroke-width="1.6"/><path d="M12 0v24M0 12h24" stroke="#fff" stroke-width="7"/><path d="M12 0v24M0 12h24" stroke="#d6283c" stroke-width="4"/>',
    de: '<rect width="24" height="8" fill="#111"/><rect y="8" width="24" height="8" fill="#dd0000"/><rect y="16" width="24" height="8" fill="#ffce00"/>',
    es: '<rect width="24" height="24" fill="#c8102e"/><rect y="6" width="24" height="12" fill="#ffc400"/>',
    zh: '<rect width="24" height="24" fill="#de2910"/><polygon points="6,3.5 7,6.3 10,6.4 7.6,8.2 8.5,11 6,9.3 3.5,11 4.4,8.2 2,6.4 5,6.3" fill="#ffde00"/>',
    ko: '<rect width="24" height="24" fill="#fff"/><circle cx="12" cy="12" r="5" fill="#cd2e3a"/><path d="M7 12a5 5 0 0 0 10 0 2.5 2.5 0 0 0-5 0 2.5 2.5 0 0 1-5 0z" fill="#0047a0"/><path d="M3 5l3-2M18 3l3 2M3 19l3 2M18 21l3-2" stroke="#111" stroke-width="1.6"/>'
};
const flag = (l, sz) => `<svg class="flag" width="${sz || 18}" height="${sz || 18}" viewBox="0 0 24 24" aria-hidden="true"><defs><clipPath id="fc-${l}"><circle cx="12" cy="12" r="12"/></clipPath></defs><g clip-path="url(#fc-${l})">${FLAGS[l] || ''}</g><circle cx="12" cy="12" r="11.6" fill="none" stroke="rgba(11,26,48,.18)"/></svg>`;
/* emoji / glyph -> icon name */
const EMOJI_ICON = {
    '⚠': 'warning', '📞': 'phone', '↻': 'refresh', '👀': 'eye', '💬': 'chat', '👋': 'chat', '✕': 'x', '❌': 'x', '🎵': 'music', '🎧': 'headphones', '🔥': 'flame', '📝': 'note', '🏡': 'home', '🏠': 'home', '‹': 'chevL', '›': 'chevR', '➡': 'chevR', '✏': 'pencil', '🔊': 'speaker', '🔇': 'speakerOff', '➤': 'send', '⭐': 'star', '🗑': 'trash', '☕': 'cup', '🌳': 'tree', '🚌': 'bus', '📱': 'phoneDev', '🎤': 'mic', '❓': 'help', '🌐': 'globe', '✅': 'check', '✓': 'check', '📚': 'book', '🎉': 'trophy', '🏆': 'trophy', '🏅': 'medal', '👑': 'crown', '📍': 'map', '🏘': 'map', '👥': 'users', '📰': 'news', '🛍': 'bag', '🔄': 'refresh', '＋': 'plus', '🧮': 'calculator', '📅': 'calendar', '⬇': 'download', '⏸': 'pause', '▶': 'play', '⏮': 'skipB', '⏭': 'skipF', '🎮': 'gamepad', '🔤': 'type', '🔗': 'link', '🃏': 'cards', '⭕': 'circle', '⚙': 'gear', '🛠': 'wrench', '🛣': 'road', '🛒': 'cart', '🏫': 'cap', '🏢': 'building', '🙋': 'user', '👤': 'user', '👨': 'user', '👩': 'user', '💍': 'heart', '💼': 'briefcase', '📶': 'signal', '🔋': 'battery', '🏷': 'tag', '☑': 'checkSq', '⬜': 'square', '⇄': 'swap', '🔎': 'search', '🔍': 'search', '💡': 'bulb', '🌓': 'contrast', '📷': 'camera', '⚡': 'bolt', '🎯': 'target', '🔔': 'bell', '💊': 'pharmacy', '🏦': 'bank', '👗': 'shirt', '🚍': 'bus', '🍽': 'utensils', '🏋': 'dumbbell', '🎬': 'film', '📮': 'mail', '🏥': 'hospital', '🏨': 'bed', '🏛': 'museum', '💈': 'scissors', '🥖': 'bread', '✈': 'plane', '🏞': 'water', '🚉': 'train'
};
const FLAG_OF = {
    '🇦🇿': 'az', '🇹🇷': 'tr', '🇷🇺': 'ru', '🇬🇧': 'en', '🇩🇪': 'de', '🇪🇸': 'es', '🇨🇳': 'zh', '🇰🇷': 'ko'
};
const placeEmoji = e => {
    e = String(e || '').replace(/\uFE0F/g, '');
    return EMOJI_ICON[e] && !/^[‹›]$/.test(e) ? e : '🏢';
};
const glyphHtml = g => {
    g = g.replace(/\uFE0F/g, '');
    if (FLAG_OF[g])
        return flag(FLAG_OF[g], 18);
    const n = EMOJI_ICON[g];
    return n ? icon(n, 20) : '';
};
const EMO_RX = /[\u{1F1E6}-\u{1F1FF}]{2}|\p{Extended_Pictographic}\uFE0F?|[‹›➤↻⇄＋✓]/gu, EMO_TEST = /[\u{1F1E6}-\u{1F1FF}]{2}|\p{Extended_Pictographic}|[‹›➤↻⇄＋✓]/u;
const UI_SEL = 'button,a.app,.chip,.tag,.pill,.toast,.ptop,#nav,.h2,label,.stt,.li[data-act],.li[data-go],.hint,.sub,.cats,.stepper,#ttl,.vn-info,.hstat,.wr,a.li,.mini,.dgr b';
const SKIP_SEL = '.nb,.you,.mb,.tu,.ly,.pbub,.err,textarea,input,svg,script,style,.pre,.mapw';
function iconifyText(node) {
    const s = node.nodeValue, f = document.createDocumentFragment();
    let last = 0, m;
    EMO_RX.lastIndex = 0;
    while ((m = EMO_RX.exec(s))) {
        f.append(s.slice(last, m.index));
        const sp = document.createElement('span');
        sp.className = 'ei';
        sp.innerHTML = glyphHtml(m[0]);
        if (sp.innerHTML)
            f.append(sp);
        last = m.index + m[0].length;
    }
    f.append(s.slice(last));
    node.replaceWith(f);
}
function iconify(root) {
    if (!root || root.nodeType === 8)
        return;
    const targets = [];
    if (root.nodeType === 3) {
        const p = root.parentElement;
        if (p && EMO_TEST.test(root.nodeValue) && p.closest(UI_SEL) && !p.closest(SKIP_SEL))
            targets.push(root);
    } else if (root.nodeType === 1) {
        const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
        let n;
        while ((n = w.nextNode())) {
            if (!EMO_TEST.test(n.nodeValue))
                continue;
            const p = n.parentElement;
            if (p && p.closest(UI_SEL) && !p.closest(SKIP_SEL))
                targets.push(n);
        }
    }
    targets.forEach(iconifyText);
}
if (typeof MutationObserver !== 'undefined') {
    new MutationObserver(ms => {
        for (const m of ms) {
            if (m.type === 'characterData')
                iconify(m.target);
            else
                m.addedNodes.forEach(iconify);
        }
    }).observe(document.documentElement, {
        childList: true, subtree: true, characterData: true
    });
}
