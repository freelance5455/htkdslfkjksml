/**
 * Onboarding wizard: languages -> level -> character -> family, then start the game
 *
 * Provides: step, genChips, marChips, myLook, renderSetup, checkChar, editSnap, showSplash, boot, newGame, editProfile, cancelEdit, start
 */
let step = 0, lastStep = -1;
const genChips = g => ['m', 'f'].map(k => `<button class="chip ${g === k ? 'on' : ''}" data-f="gen" data-v="${k}">${avatar({
    g: k, t: k === 'm' ? 1 : 0
}, 'happy', 28, 1)}${esc(t(k))}</button>`).join('');
const marChips = () => ['sg', 'mr'].map(k => `<button class="chip ${(S.marital || 'sg') === k ? 'on' : ''}" data-f="marital" data-v="${k}">${icon(k === 'sg' ? 'user' : 'heart', 18)}${esc(t(k))}</button>`).join('');
const LAST = 3;
const myLook = () => S.av || {
    g: S.gen === 'f' ? 'f' : 'm', t: 0
};
function renderSetup() {
    document.documentElement.lang = S.nat;
    if (!S.fam)
        S.fam = { ...FAMDEF };
    if (!S.av)
        S.av = {
            g: S.gen === 'f' ? 'f' : 'm', t: 0
        };
    const sc = lastStep === step ? ($('wzb')?.scrollTop || 0) : 0;
    lastStep = step;
    const g = S.av.g, cl = i => i < step ? 'dn' : i === step ? 'on' : '';
    const stepper = [0, 1, 2, 3].map(i => `<i class="${cl(i)}">${i < step ? '✓' : i + 1}</i>${i < 3 ? `<u class="${i < step ? 'dn' : ''}"></u>` : ''}`).join('');
    let b = '';
    if (step === 0)
        b = `<div class="hero2"><div>${wordmark()}<p>${esc(t('slogan'))}</p></div>${mascot('wave', 150, 'bounce')}</div><h2 class="stt">${esc(t('nat'))}</h2><div class="tiles">${chips('nat', fl(''), S.nat)}</div><h2 class="stt">${esc(t('tgt'))}</h2><div class="tiles">${chips('tgt', fl(S.nat), S.tgt)}</div>`;
    else if (step === 1)
        b = `<h2 class="stt">${esc(t('lvl'))}</h2><div class="lvl">${LEVELS.map((l, i) => `<button class="lvc ${S.lvl === l ? 'on' : ''}" data-f="lvl" data-v="${l}"><span class="bars">${[0, 1, 2, 3, 4].map(j => `<i class="${j <= i ? 'f' : ''}"></i>`).join('')}</span><b>${l}</b><span class="t">${esc(t('l' + (i + 1)))}</span></button>`).join('')}</div>`;
    else if (step === 2)
        b = `<div class="seg">${genChips(g)}</div><div class="avg">${TPL[g].map((_, i) => `<button class="avt ${S.av.t === i ? 'on' : ''}" data-av="${i}" aria-label="avatar ${i + 1}">${avatar({
            g, t: i
        }, 'neutral', 90, 2)}</button>`).join('')}</div>
  <div class="card f2"><div><label>${esc(t('nick'))}</label><input id="fn" value="${esc(S.nick)}" autocomplete="off"></div><div><label>${esc(t('age'))}</label><input id="fa" type="number" inputmode="numeric" min="10" max="99" value="${esc(S.age)}"></div><div><label>${esc(t('job'))}</label><textarea id="fj" rows="2">${esc(S.job)}</textarea></div></div>`;
    else
        b = `<h2 class="stt">${esc(t('mar'))}</h2><div class="seg">${marChips()}</div><h2 class="stt">${esc(t('fam'))}</h2><div class="fam">${FAM_ORDER.filter(k => S.marital === 'mr' || (k !== 'sp' && k !== 'ch')).map(k => `<button class="chip ${S.fam[k] ? 'on' : ''}" data-fam="${k}">${famIco(k)}${esc(t(k))}</button>`).join('')}</div>`;
    const sum = `<aside class="wz-sum"><div class="sum"><div class="sum-img">${avatar(myLook(), 'happy', 200, 2)}</div><div class="sum-b"><b>${esc(S.nick || '—')}</b><div class="row"><span>${flag(S.nat, 16)} ${icon('chevR', 12)} ${flag(S.tgt, 16)}</span><span>${S.lvl}</span></div></div></div></aside>`;
    $('setup').innerHTML = `<div class="wz-top"><div class="wz-w"><div class="brand">${logo(44)}<div>${wordmark()}<small>${esc(t('slogan'))}</small></div></div><div class="stepper">${stepper}</div></div></div><div class="wz-main"><div class="wz-body" id="wzb">${b}</div>${sum}</div><div class="wz-foot"><div class="wz-w">${step ? '<button class="btn g" data-step="-1" aria-label="back">‹</button>' : (S.done ? '<button class="btn g" data-step="cancel" aria-label="cancel">✕</button>' : '')}<button class="btn" id="nx" data-step="1">${step === LAST ? esc(t('go')) : '›'}</button></div></div>`;
    const w = $('wzb');
    if (w)
        w.scrollTop = sc;
    ['fn', 'fa', 'fj'].forEach(i => {
        const e = $(i);
        if (e)
            e.oninput = () => {
                S.nick = $('fn').value;
                S.age = $('fa').value;
                S.job = $('fj').value;
            };
    });
}
function checkChar() {
    const miss = [['fn', t('nick')], ['fa', t('age')], ['fj', t('job')]].filter(([i]) => !String($(i)?.value ?? '').trim());
    if (miss.length) {
        miss.forEach(([i]) => {
            $(i).style.borderColor = '#ff5252';
            $(i).style.background = '#fff0f0';
        });
        $(miss[0][0]).focus();
        toast('✏️', miss.map(x => x[1]).join(', '));
        return false;
    }
    return true;
}
$('setup').addEventListener('click', e => {
    const bt = e.target.closest('[data-boot]');
    if (bt) {
        if (bt.dataset.boot === 'retry')
            boot();
        else {
            step = 0;
            renderSetup();
        }
        return;
    }
    const s = e.target.closest('[data-step]'), f = e.target.closest('[data-fam]'), av = e.target.closest('[data-av]'), b = e.target.closest('[data-f]');
    if (s && s.dataset.step === 'cancel')
        return cancelEdit();
    if (s) {
        const d = +s.dataset.step;
        if (d > 0 && step === 2 && !checkChar())
            return;
        if (d > 0 && step === LAST)
            return start();
        step = Math.max(0, Math.min(LAST, step + d));
        return renderSetup();
    }
    if (f) {
        S.fam[f.dataset.fam] = S.fam[f.dataset.fam] ? 0 : 1;
        return renderSetup();
    }
    if (av) {
        S.av = {
            g: S.av.g, t: +av.dataset.av
        };
        return renderSetup();
    }
    if (!b)
        return;
    S[b.dataset.f] = b.dataset.v;
    if (S.nat === S.tgt)
        S.tgt = S.nat === 'en' ? 'es' : 'en';
    if (b.dataset.f === 'gen')
        S.av = {
            g: b.dataset.v, t: S.av.g === b.dataset.v ? S.av.t : 0
        };
    if (b.dataset.f === 'marital' && b.dataset.v === 'sg') {
        S.fam.sp = 0;
        S.fam.ch = 0;
    }
    renderSetup();
});
let editSnap = null;
function showSplash(err) {
    $('setup').style.display = 'flex';
    $('game').classList.remove('on');
    $('setup').innerHTML = `<div class="splash">${mascot('wave', 170, 'bounce')}${wordmark()}<p>${esc(t('slogan'))}</p>${err ? `<p>${icon('warning', 16)} ${esc(err)}</p><div class="row"><button class="btn" data-boot="retry">↻</button><button class="btn g" data-boot="edit">✏️</button></div>` : '<div class="dots"><span>•</span><span>•</span><span>•</span></div>'}</div>`;
}
/* the profile is saved after the first start; later launches go straight into the game */
async function boot() {
    if (S.done && S.nick && S.job) {
        showSplash();
        if (!(await start()))
            showSplash('AI is not connected');
    } else
        renderSetup();
}
/* NEW GAME: forget the character and choices, go back to the first screen (language selection). XP, streak and notebook are kept. */
function newGame() {
    document.querySelectorAll('.toast').forEach(x => x.remove());
    Ph.close();
    Music.stop();
    Voice.stopSpeak();
    if (Voice.rec)
        Voice.stopRec();
    const nat = S.nat || 'az';
    Object.keys(S).forEach(k => delete S[k]);
    Object.assign(S, {
        nat, tgt: nat === 'en' ? 'es' : 'en', lvl: 'A1', gen: 'm', age: '', job: '', nick: '', fam: { ...FAMDEF }, done: false
    });
    Store.set('profile', S);
    editSnap = null;
    Game.reset(null);
    $('game').classList.remove('on');
    $('setup').style.display = 'flex';
    step = 0;
    lastStep = -1;
    renderSetup();
}
function editProfile() {
    editSnap = JSON.stringify(S);
    Ph.close();
    Music.stop();
    Voice.stopSpeak();
    $('game').classList.remove('on');
    $('setup').style.display = 'flex';
    step = 0;
    renderSetup();
}
function cancelEdit() {
    if (editSnap) {
        const o = JSON.parse(editSnap);
        Object.keys(S).forEach(k => delete S[k]);
        Object.assign(S, o);
        editSnap = null;
    }
    if (Game.p) {
        $('setup').style.display = 'none';
        $('game').classList.add('on');
        render();
    } else
        boot();
}
async function start() {
    const go = $('nx');
    if (go)
        go.disabled = true;
    try {
        Game.sample = await window.claude?.use?.('sample');
    } catch (e) {
        Game.sample = null;
    }
    if (!Game.sample && !WORKER_URL) {
        if (go)
            go.disabled = false;
        toast('⚠️', 'AI is not connected. Open this page from its Claude artifact link, not from a downloaded file.');
        return false;
    }
    S.done = true;
    Store.set('profile', S);
    editSnap = null;
    Game.reset(S);
    buildPlaces();
    Streak.touch();
    $('setup').style.display = 'none';
    $('game').classList.add('on');
    render();
    enterPlace('home');
    classifyWork();
    return true;
}
