/**
 * Neighbourhood model: place kinds (icon, category, description for the AI), the base places, the
 * workplace that fits the profession, friends' homes and places discovered by asking people
 *
 * Provides: KINDS, BASE_IDS, mkPlace, P, buildPlaces, classifyWork, addHome, addDiscovered, moveNpc
 */
const KINDS = {
    home: {
        e: '🏠', cat: 'home', en: "the player's own home (the family members live here)"
    },
    street: {
        e: '🛣️', cat: 'service', en: 'a street of the neighbourhood (passers-by, shopkeeper, street musician, tourist)'
    },
    cafe: {
        e: '☕', cat: 'food', en: 'a cafe (barista, customers, waiter)'
    },
    market: {
        e: '🛒', cat: 'shop', en: 'a grocery store / supermarket (cashier, shoppers, seller; products and prices)'
    },
    clothes: {
        e: '👗', cat: 'shop', en: 'a clothing store (shop assistant, customers, fitting room; sizes, colours, prices)'
    },
    park: {
        e: '🌳', cat: 'nature', en: 'a park (jogger, dog walker, elderly person, parent with kids)'
    },
    bus: {
        e: '🚌', cat: 'transport', en: 'a bus stop (commuters, driver, tourist asking directions)'
    },
    station: {
        e: '🚍', cat: 'transport', en: 'a long-distance bus station (ticket seller, passengers, driver, information desk)'
    },
    company: {
        e: '🏢', cat: 'service', en: 'a company office for business meetings (receptionist, manager, business partner, interviewer)'
    },
    pharmacy: {
        e: '💊', cat: 'health', en: 'a pharmacy (pharmacist, customers)'
    },
    bank: {
        e: '🏦', cat: 'service', en: 'a bank (teller, clerk, customers)'
    },
    restaurant: {
        e: '🍽️', cat: 'food', en: 'a restaurant (waiter, chef, guests)'
    },
    library: {
        e: '📚', cat: 'culture', en: 'a library (librarian, students, readers)'
    },
    gym: {
        e: '🏋️', cat: 'fun', en: 'a gym (trainer, members)'
    },
    cinema: {
        e: '🎬', cat: 'culture', en: 'a cinema (ticket seller, moviegoers)'
    },
    post: {
        e: '📮', cat: 'service', en: 'a post office (clerk, customers)'
    },
    hospital: {
        e: '🏥', cat: 'health', en: 'a hospital or clinic (doctor, nurse, patients, receptionist)'
    },
    hotel: {
        e: '🏨', cat: 'service', en: 'a hotel (receptionist, guests, porter)'
    },
    mall: {
        e: '🛍️', cat: 'shop', en: 'a shopping mall (shop assistants, shoppers)'
    },
    museum: {
        e: '🏛️', cat: 'culture', en: 'a museum (guide, ticket seller, visitors)'
    },
    barber: {
        e: '💈', cat: 'service', en: 'a barber / hair salon (hairdresser, clients)'
    },
    bakery: {
        e: '🥖', cat: 'food', en: 'a bakery (baker, customers)'
    },
    airport: {
        e: '✈️', cat: 'transport', en: 'an airport (check-in agent, travellers, security)'
    },
    lake: {
        e: '🏞️', cat: 'nature', en: 'a lake shore (fishermen, walkers, couples)'
    },
    school: {
        e: '🏫', cat: 'culture', en: "a school/university (teachers, classmates, staff) - the player's place of study or work"
    }
};
const BASE_IDS = [
    'street', 'cafe', 'market', 'clothes', 'park', 'bus', 'station', 'company', 'pharmacy', 'bank', 'restaurant', 'library'
];
const mkPlace = (id, x) => ({
    id, kind: id, e: KINDS[id].e, bg: '#bfe1ff,#fff', en: KINDS[id].en, ...(x || {})
});
const P = id => {
    const p = (Game.places || []).find(x => x.id === id) || (KINDS[id] ? mkPlace(id, id === 'school' ? { work: 1 } : {}) : {
        id, kind: 'company', e: '🏢', bg: '#bfe1ff,#fff', en: 'a place'
    });
    return {
        ...p, n: p.n || t(p.kind || p.id)
    };
};
function buildPlaces() {
    const w = Game.work, list = [mkPlace('home')];
    if (w && w.kind === 'school')
        list.push(mkPlace('school', { work: 1 }));
    else if (w && w.kind === 'custom')
        list.push({
            id: 'work', kind: 'company', e: placeEmoji(w.emoji), n: w.name || t('work'), bg: '#c6d8ff,#e9f0ff', en: w.en || "the player's workplace (boss, coworkers, clients)", work: 1
        });
    BASE_IDS.forEach(id => list.push(mkPlace(id)));
    Game.places = list.concat(Game.places.filter(x => x.host || x.disc));
}
async function classifyWork() {
    try {
        const r = await Game.ask(Game.classifyPrompt(), true);
        Game.work = {
            kind: ['school', 'home', 'custom'].includes(r.kind) ? r.kind : 'custom', name: r.name, emoji: r.emoji, en: r.en
        };
    } catch (e) {
        Game.work = { kind: 'custom' };
    }
    buildPlaces();
    render();
}
function addHome(n) {
    const id = 'h-' + n.id;
    if (Game.places.some(x => x.id === id))
        return;
    Game.places.push({
        id, kind: 'home', e: '🏡', n: n.name, bg: '#ffd9a0,#fff1d6', en: `${n.name}'s private home (${n.name} and relatives or housemates live here)`, host: n.id
    });
    toast('📍', '🏡 ' + n.name, () => {
        Game.view = 'map';
        render();
    });
    render();
}
/* a place somebody told us about -> appears on the map */
function addDiscovered(info) {
    if (!info || !info.name)
        return null;
    const kind = KINDS[info.kind] && info.kind !== 'home' && info.kind !== 'school' ? info.kind : 'company', name = String(info.name).trim().slice(0, 28);
    if (Game.places.some(p => p.kind === kind && String(P(p.id).n).toLowerCase() === name.toLowerCase()))
        return null;
    const id = 'd-' + kind + '-' + (hash(name) % 9973);
    if (Game.places.some(p => p.id === id))
        return null;
    const p = mkPlace(kind, {
        id, n: name, en: String(info.en || KINDS[kind].en).slice(0, 200), disc: 1
    });
    Game.places.push(p);
    toast('📍', t('newp') + ': ' + name, () => {
        Game.view = 'map';
        render();
    });
    render();
    return p;
}
function moveNpc(n, id) {
    const o = Game.people[n.place];
    if (o)
        Game.people[n.place] = o.filter(i => i !== n.id);
    (Game.people[id] = Game.people[id] || []).push(n.id);
    n.place = id;
}
