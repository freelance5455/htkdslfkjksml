/**
 * XP, levels, daily goal, streak bonus and achievements
 *
 * Provides: GOAL, Progress, addXp, ACH
 */
const GOAL = 60;
const Progress = {
    at: l => Math.round(60 * Math.pow(l - 1, 1.6)), /* total XP needed to reach level l */
    xp() {
        return Store.get('xp', 0);
    },
    level(xp) {
        xp = xp == null ? this.xp() : xp;
        let l = 1;
        while (l < 50 && xp >= this.at(l + 1))
            l++;
        return l;
    },
    info() {
        const xp = this.xp(), l = this.level(xp), a = this.at(l), b = this.at(l + 1);
        return {
            xp, l, a, b, p: l >= 50 ? 1 : (xp - a) / (b - a), need: Math.max(0, b - xp)
        };
    },
    rankKey: l => 'rk' + (l < 5 ? 1 : l < 10 ? 2 : l < 15 ? 3 : l < 25 ? 4 : l < 40 ? 5 : 6),
    today() {
        return Stats().days[iso(0)] || 0;
    },
    gain(n) {
        if (!n)
            return;
        if (n > 0)
            Streak.touch();
        const b = this.level(), st = Stats(), d = iso(0);
        let xp = Math.max(0, this.xp() + n);
        if (n > 0) {
            st.days[d] = (st.days[d] || 0) + n;
            const ks = Object.keys(st.days).sort();
            while (ks.length > 90)
                delete st.days[ks.shift()];
            if (st.days[d] >= GOAL && !st.goal[d]) {
                st.goal[d] = 1;
                xp += 20;
                st.days[d] += 20;
                toast('target', t('goal') + ' · +20 XP');
                Sfx.play('goal');
            }
        }
        saveStats(st);
        Store.set('xp', xp);
        const a = this.level(xp);
        head();
        if (a > b)
            this.levelUp(a);
        if (typeof Ph !== 'undefined' && Ph.on && Ph.view === 'profile')
            Ph.draw();
    },
    newDay(n) {
        if (n < 2)
            return;
        const bonus = Math.min(n, 10) * 2, st = Stats(), d = iso(0);
        Store.set('xp', this.xp() + bonus);
        st.days[d] = (st.days[d] || 0) + bonus;
        saveStats(st);
        toast('flame', t('strk') + ' ' + n + ' · +' + bonus + ' XP');
    },
    msg(clean, kind) {
        const st = Stats();
        st.msgs++;
        if (clean)
            st.clean++;
        saveStats(st);
        this.gain(kind === 'phone' ? 2 + (clean ? 2 : 0) : 3 + (clean ? 3 : 1));
    },
    friend() {
        const st = Stats();
        st.friends++;
        saveStats(st);
        this.gain(15);
    },
    visit(id) {
        const st = Stats();
        if (!st.places[id]) {
            st.places[id] = 1;
            saveStats(st);
            this.gain(10);
        }
    },
    win() {
        const st = Stats();
        st.wins++;
        saveStats(st);
    },
    levelUp(l) {
        Sfx.play('level');
        const el = document.createElement('div');
        el.className = 'cel';
        el.innerHTML = `<div class="cel-card">${mascot('both', 140, 'bounce')}<div class="cel-t">${esc(t('lvup'))}</div><div class="cel-l">${l}</div><div class="cel-r">${esc(t(this.rankKey(l)))}</div></div>`;
        el.onclick = () => el.remove();
        document.body.appendChild(el);
        setTimeout(() => el.remove(), 4200);
    }
};
const addXp = n => Progress.gain(n);
/* achievements: icon + number (language independent) */
const ACH = [
    {
        ic: 'chat', n: 1, ok: s => s.msgs >= 1
    }, {
        ic: 'check', n: 25, ok: s => s.clean >= 25
    }, {
        ic: 'users', n: 3, ok: s => s.friends >= 3
    }, {
        ic: 'map', n: 6, ok: s => Object.keys(s.places).length >= 6
    },
    {
        ic: 'flame', n: 3, ok: () => Streak.data().best >= 3
    }, {
        ic: 'flame', n: 7, ok: () => Streak.data().best >= 7
    }, {
        ic: 'flame', n: 30, ok: () => Streak.data().best >= 30
    },
    {
        ic: 'bolt', n: 500, ok: () => Progress.xp() >= 500
    }, {
        ic: 'star', n: 5, lv: 1, ok: () => Progress.level() >= 5
    }, {
        ic: 'trophy', n: 10, lv: 1, ok: () => Progress.level() >= 10
    }, {
        ic: 'target', n: 5, ok: s => s.wins >= 5
    }
];
