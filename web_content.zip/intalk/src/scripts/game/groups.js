/**
 * Group conversations: several people who are at the same place talk with the learner (and with each
 * other) in ONE chat. Start it from the place screen ("Group chat"), from a chat ("+") or when
 * somebody calls another person over.
 *
 * Provides: Groups, grpStrip, groupDlg, groupTurn, sendGroup, joinNpc
 */
const Groups = {
    members(g) {
        return g.members.map(i => Game.npcs[i]).filter(Boolean);
    },
    open(ids) {
        ids = [...new Set(ids)].filter(i => Game.npcs[i]);
        if (ids.length < 2)
            return;
        const pl = Game.npcs[ids[0]].place;
        ids = ids.filter(i => Game.npcs[i].place === pl);
        if (ids.length < 2)
            return;
        const k = ids.slice().sort().join('+');
        let g = Game.groups[k];
        if (!g) {
            g = Game.groups[k] = {
                id: k, place: pl, members: ids, log: [
                    {
                        who: 'sys', text: ids.map(i => Game.npcs[i].name).join(', ')
                    }
                ], pending: false, draft: '', unread: 0
            };
            const cur = Game.npcs[Game.cur];
            if (cur && ids.includes(cur.id))
                cur.log.filter(x => x.who !== 'sys').slice(-4).forEach(x => g.log.push(x.who === 'me' ? {
                    who: 'me', text: x.text
                } : {
                    who: 'npc', npc: cur.id, text: x.text, mood: x.mood
                }));
        }
        Game.grp = k;
        Game.cur = ids[0];
        Game.place = pl;
        g.unread = 0;
        Game.view = 'chat';
        if (Ph.on)
            Ph.close();
        render();
        return g;
    }
};
/* small stacked avatars in the strip above the chat */
function grpStrip(pl, v) {
    return Object.values(Game.groups).filter(g => g.place === pl).map(g => {
        const ms = Groups.members(g);
        return `<div class="cc gcc ${v === 'chat' && Game.grp === g.id ? 'on' : ''}" data-grp="${g.id}"><span class="gstack">${ms.slice(0, 3).map(x => avatar(x.look, x.mood, 30, 1)).join('')}</span><div>${esc(ms.map(x => x.name).join(' + ').slice(0, 16))}</div>${g.unread ? `<b class="dot">${g.unread}</b>` : ''}${g.pending ? '<div>…</div>' : ''}</div>`;
    }).join('');
}
/* picker: choose who takes part (at least 2) */
function groupDlg(pre) {
    const pl = Game.place, ppl = (Game.people[pl] || []).map(i => Game.npcs[i]).filter(Boolean);
    if (ppl.length < 2)
        return;
    const sel = new Set((pre || []).filter(i => Game.npcs[i] && Game.npcs[i].place === pl)), d = document.createElement('div');
    d.className = 'dlg';
    const draw = () => {
        d.innerHTML = `<div class="dlg-card"><b>${esc(t('grp'))}</b><div class="gpick">${ppl.map(n => `<button class="gp ${sel.has(n.id) ? 'on' : ''}" data-gm="${n.id}">${avatar(n.look, 'happy', 40, 1)}<span><b>${esc(n.name)}</b><small>${esc(n.role)}</small></span>${sel.has(n.id) ? icon('check', 18) : ''}</button>`).join('')}</div><div class="row"><button class="btn g" data-dlg="no">${esc(t('no'))}</button><button class="btn" data-dlg="go" ${sel.size < 2 ? 'disabled' : ''}>${esc(t('gstart'))}</button></div></div>`;
    };
    draw();
    d.addEventListener('click', e => {
        const m = e.target.closest('[data-gm]');
        if (m) {
            const id = m.dataset.gm;
            sel.has(id) ? sel.delete(id) : sel.add(id);
            draw();
            return;
        }
        const b = e.target.closest('[data-dlg]');
        if (!b && e.target !== d)
            return;
        const go = !!b && b.dataset.dlg === 'go' && sel.size >= 2;
        d.remove();
        if (go)
            Groups.open([...sel]);
    });
    document.body.appendChild(d);
}
/* one round: the AI writes 1-3 turns from different members */
async function groupTurn(g, event) {
    g.pending = true;
    render();
    try {
        const r = await Game.ask(Game.groupPrompt(g, event), false), m = realMistakes(r.mistakes), mem = Groups.members(g);
        if (!event) {
            Progress.msg(!m.length);
            if (m.length) {
                saveMistakes(m);
                const last = [...g.log].reverse().find(x => x.who === 'me');
                if (last)
                    last.note = m;
            }
        }
        const turns = (Array.isArray(r.turns) ? r.turns : r.say ? [
            {
                who: mem[0] && mem[0].name, say: r.say, mood: r.mood
            }
        ] : []).slice(0, 4);
        for (const tu of turns) {
            const npc = mem.find(x => x.name.toLowerCase() === String(tu.who || '').trim().toLowerCase()) || mem[0], say = clean(tu.say);
            if (!npc || !say)
                continue;
            g.log.push({
                who: 'npc', npc: npc.id, text: say, mood: tu.mood || 'neutral'
            });
            npc.mood = tu.mood || npc.mood;
            npc.waitSince = Date.now();
            if (Game.view === 'chat' && Game.grp === g.id) {
                Sfx.play('recv');
                Voice.queue(say, npc);
            } else {
                g.unread++;
                toast('💬', npc.name + ': ' + say, () => Groups.open(g.members));
            }
            render();
            await new Promise(res => setTimeout(res, 600));
        }
        (Array.isArray(r.remember) ? r.remember : []).forEach(x => {
            const npc = mem.find(n => n.name.toLowerCase() === String(x && x.who || '').toLowerCase());
            if (npc && x.fact) {
                (npc.facts = npc.facts || []).push(String(x.fact).slice(0, 140));
                if (npc.facts.length > 10)
                    npc.facts.shift();
            }
        });
        if (r.newPlace && r.newPlace.name)
            addDiscovered(r.newPlace);
        if (mem[0] && r.join && r.join.length)
            joinNpc(mem[0], r.join, g);
    } catch (e) {
        g.log.push({
            who: 'sys', text: '⚠️ ' + (e.code || '') + ' ' + (e.message || 'Error')
        });
    }
    g.pending = false;
    render();
}
async function sendGroup(txt) {
    const g = Game.groups[Game.grp], v = String(txt == null ? (($('ci') && $('ci').value) || '') : txt).trim();
    if (!g || !v || g.pending)
        return;
    Streak.touch();
    g.log.push({
        who: 'me', text: v
    });
    g.draft = '';
    Voice.cancelAll();
    Sfx.play('send');
    await groupTurn(g);
}
/* somebody (e.g. a parent) calls one or more other people over: they join the conversation (1:1 chat -> group, or group -> bigger group) */
function joinNpc(n, names, from) {
    from = from || (Game.grp && Game.groups[Game.grp]);
    const taken = new Set(from ? from.members : [n.id]);
    const joiners = [].concat(names || []).map(nm => Object.values(Game.npcs).find(x => !taken.has(x.id) && x.place === n.place && x.name.toLowerCase() === String(nm || '').trim().toLowerCase())).filter((x, i, a) => x && a.indexOf(x) === i);
    if (!joiners.length)
        return false;
    const g = Groups.open([...(from ? from.members : [n.id]), ...joiners.map(x => x.id)]);
    if (!g)
        return false;
    if (from && g !== from && g.log.length <= 2)
        from.log.slice(1).forEach(x => g.log.push(x));
    joiners.forEach(j => g.log.push({
        who: 'sys', text: j.name + ' ' + t('joined')
    }));
    groupTurn(g, joiners.map(j => j.name).join(' and ') + ' just walked over and joined the conversation');
    return true;
}
