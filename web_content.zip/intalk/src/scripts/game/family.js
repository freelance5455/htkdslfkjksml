/**
 * Family model: who is who, and how each person addresses the others
 *
 * Provides: FAM_ORDER, FAMDEF, KIN, famRoles, kin, FAM_AV, famIco
 */
const FAM_ORDER = ['mo', 'fa', 'br', 'si', 'gm', 'gf', 'sp', 'ch'], KIN_ROLES = ['pl', 'mo', 'fa', 'br', 'si', 'gm', 'gf', 'sp', 'ch'];
const FAMDEF = {
    mo: 1, fa: 1, br: 0, si: 0, gm: 0, gf: 0, sp: 0, ch: 0
};
/* KIN[x][y] = who person y is, from person x's point of view (index = KIN_ROLES) */
const KIN = {
    mo: [
        'your child (use their first name)', '—', 'your husband', 'your son', 'your daughter', 'your mother or mother-in-law (call her "Mom")', 'your father or father-in-law (call him "Dad")', "your child's spouse", 'your grandchild'
    ],
    fa: [
        'your child (use their first name)', 'your wife', '—', 'your son', 'your daughter', 'your mother or mother-in-law (call her "Mom")', 'your father or father-in-law (call him "Dad")', "your child's spouse", 'your grandchild'
    ],
    br: [
        'your sibling (first name)', 'your mother: call her "Mom"/"Mother", NEVER by first name', 'your father: call him "Dad"/"Father", NEVER by first name', 'your brother', 'your sister', 'your grandmother (call her "Grandma")', 'your grandfather (call him "Grandpa")', "your sibling's spouse (first name)", 'your niece or nephew'
    ],
    si: [
        'your sibling (first name)', 'your mother: call her "Mom"/"Mother", NEVER by first name', 'your father: call him "Dad"/"Father", NEVER by first name', 'your brother', 'your sister', 'your grandmother (call her "Grandma")', 'your grandfather (call him "Grandpa")', "your sibling's spouse (first name)", 'your niece or nephew'
    ],
    gm: [
        'your grandchild (first name or "dear")', 'your child or child-in-law', 'your child or child-in-law', 'your grandchild', 'your grandchild', '—', 'your husband', "your grandchild's spouse", 'your great-grandchild'
    ],
    gf: [
        'your grandchild (first name or "dear")', 'your child or child-in-law', 'your child or child-in-law', 'your grandchild', 'your grandchild', 'your wife', '—', "your grandchild's spouse", 'your great-grandchild'
    ],
    sp: [
        'your spouse (first name or an endearment)', 'your mother-in-law', 'your father-in-law', 'your brother-in-law', 'your sister-in-law', "your spouse's grandmother", 'your spouse\'s grandfather', '—', 'your child'
    ],
    ch: [
        'your parent: call them "Mom" if the player is a woman, "Dad" if a man, NEVER by first name', 'your grandmother ("Grandma")', 'your grandfather ("Grandpa")', 'your uncle or aunt', 'your aunt or uncle', 'your great-grandmother', 'your great-grandfather', 'your other parent: "Mom"/"Dad", NEVER by first name', '—'
    ]
};
const famRoles = () => {
    const f = S.fam || FAMDEF;
    return FAM_ORDER.filter(k => f[k] && (S.marital === 'mr' || (k !== 'sp' && k !== 'ch')));
};
function kin(x) {
    if (!x.rel || !KIN[x.rel])
        return '';
    const row = KIN[x.rel], others = Object.values(Game.npcs).filter(n => n.rel && n.id !== x.id);
    return `FAMILY (kinship from YOUR point of view; address relatives with the natural kinship words of the target culture, and NEVER by first name when they are your parent or grandparent): the player ${S.nick} (a ${S.gen === 'f' ? 'woman' : 'man'}) is ${row[0]}${others.length ? '; ' + others.map(n => `${n.name} is ${row[KIN_ROLES.indexOf(n.rel)]}`).join('; ') : ''}.`;
}
/* family chips show small cute avatars (spouse: heart) */
const FAM_AV = {
    mo: {
        g: 'f', t: 0
    }, fa: {
        g: 'm', t: 1
    }, br: {
        g: 'm', t: 14
    }, si: {
        g: 'f', t: 14
    }, gm: {
        g: 'f', t: 17
    }, gf: {
        g: 'm', t: 17
    }, ch: {
        g: 'm', t: 15
    }
};
const famIco = k => k === 'sp' ? icon('heart', 20) : avatar(FAM_AV[k], 'happy', 30, 1);
