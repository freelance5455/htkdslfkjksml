/**
 * World logic: entering places, creating people, chatting, gossip, contacts, addresses
 *
 * Provides: enterPlace, openChat, addFriend, sendNpc, spread, incoming, waitList, waitNo, Greet
 */
async function enterPlace(id, more) {
    if (more && P(id).kind === 'home')
        return;
    Game.place = id;
    Game.view = 'place';
    const pd = P(id);
    Progress.visit(id);
    if (pd.host) {
        const h = Game.npcs[pd.host];
        if (h && h.place !== id)
            moveNpc(h, id);
    }
    if (Game.seen[id] && !more) {
        render();
        return;
    }
    Game.seen[id] = 1;
    Game.loading[id] = 1;
    render();
    try {
        const fam = id === 'home' && !more ? famRoles() : [], r = await Game.ask(Game.scenePrompt(id, more), true), made = [];
        Game.city = Game.city || r.city || '';
        Game.narr[id] = r.narration || Game.narr[id] || '';
        (r.npcs || []).forEach((n, i) => {
            if (!n.name)
                return;
            const rel = fam.length ? (fam.includes(n.rel) ? n.rel : fam[i] || '') : '';
            const npc = {
                id: 'n' + (++Game.seq), name: n.name, role: (rel && t(rel)) || n.role || '', rel, family: !!rel, look: null, mood: n.mood || 'neutral', place: id, log: [], unread: 0, pending: false, draft: '', persona: n.persona || null, facts: []
            };
            {
                const lk = n.look || {}, fm = ({
                    mo: 1, fa: 0, gm: 1, gf: 0, si: 1, br: 0
                })[rel] ?? lk.female, old = rel === 'gm' || rel === 'gf' ? 1 : rel ? 0 : lk.old, kid = rel === 'ch' && +S.age < 50 ? 1 : rel ? 0 : lk.kid;
                npc.look = mkLook(n.name, {
                    female: fm, old, kid
                });
            }
            if (n.greet)
                npc.pendingGreet = clean(n.greet);
            Game.npcs[npc.id] = npc;
            (Game.people[id] = Game.people[id] || []).push(npc.id);
            made.push([npc, n]);
        });
        made.forEach(([npc, n]) => {
            if (n.about && n.greet) {
                const t2 = Object.values(Game.npcs).find(x => x.id !== npc.id && x.name.toLowerCase() === String(n.about).toLowerCase());
                if (t2)
                    (Game.know[t2.id] = Game.know[t2.id] || []).push(`${npc.name} complained to the learner about you: "${clean(n.greet)}"`);
            }
        });
        if (id === 'home' && !more)
            made.forEach(([npc]) => addFriend(npc, 1));
        Greet.next(id);
    } catch (e) {
        toast('⚠️', (e.code || '') + ' ' + (e.message || 'Error'));
    }
    Game.loading[id] = 0;
    Game.people[id] = Game.people[id] || [];
    render();
}
function openChat(id) {
    const n = Game.npcs[id];
    Game.grp = null;
    Game.cur = id;
    Game.place = n.place;
    n.unread = 0;
    Game.view = 'chat';
    Ph.on && Ph.close();
    render();
}
function addFriend(n, q) {
    if (Game.friends.find(f => f.name === n.name))
        return;
    const num = PFX[S.tgt] + ' ' + String(Math.floor(1e7 + Math.random() * 9e7)).replace(/(\d{3})(\d{2})(\d{2})/, '$1 $2 $3');
    Game.friends.push({
        id: n.id, name: n.name, number: num, look: n.look, role: n.role
    });
    Game.threads[n.name] = Game.threads[n.name] || {
        msgs: [], look: n.look, role: n.role
    };
    q || Progress.friend();
    q || toast('📞', t('saved') + ': ' + n.name + ' · ' + num, () => Ph.open('friends'));
}
async function sendNpc(txt, viaVoice) {
    if (Game.grp && Game.groups[Game.grp])
        return sendGroup(txt);
    const n = Game.npcs[Game.cur], v = String(txt ?? $('ci')?.value ?? '').trim();
    if (!n || !v || n.pending)
        return;
    Streak.touch();
    if (/^\[?\s*(📱|telefon|phone|телефон|teléfono|手机|handy)/i.test(v)) {
        n.draft = '';
        if ($('ci'))
            $('ci').value = '';
        return Ph.open('home');
    }
    n.log.push({
        who: 'me', text: v
    });
    n.draft = '';
    n.pending = true;
    Voice.cancelAll();
    Sfx.play('send');
    render();
    try {
        const r = await Game.ask(Game.npcPrompt(n), false), m = realMistakes(r.mistakes), say = clean(r.say || r.text);
        Progress.msg(!m.length);
        if (m.length) {
            saveMistakes(m);
            const last = [...n.log].reverse().find(x => x.who === 'me');
            if (last)
                last.note = m;
        }
        n.mood = r.mood || 'neutral';
        n.log.push({
            who: 'npc', text: say, mood: n.mood
        });
        n.waitSince = Date.now();
        if (r.friend === true || r.friend?.name)
            addFriend(n);
        if (r.address === true)
            addHome(n);
        if (r.remember) {
            (n.facts = n.facts || []).push(String(r.remember).slice(0, 140));
            if (n.facts.length > 10)
                n.facts.shift();
        }
        if (r.newPlace && r.newPlace.name)
            addDiscovered(r.newPlace);
        if (r.join)
            setTimeout(() => joinNpc(n, r.join), 900);
        (r.phone || []).forEach(p => incoming(p.from, clean(p.text)));
        if (r.tell?.to && r.tell?.text)
            spread(n, r.tell);
        if (n.place !== Game.place) {
            if (Game.friends.find(f => f.name === n.name))
                incoming(n.name, say);
        } else if (!(Game.view === 'chat' && Game.cur === n.id)) {
            n.unread++;
            toast('💬', n.name + ': ' + say, () => openChat(n.id));
        } else {
            Sfx.play('recv');
            Voice.say(say, n, viaVoice);
        }
    } catch (e) {
        n.log.push({
            who: 'sys', text: '⚠️ ' + (e.code || '') + ' ' + (e.message || 'Error')
        });
    }
    n.pending = false;
    render();
    setTimeout(() => Greet.next(Game.place), 3500);
}
async function spread(from, tell) {
    const to = Object.values(Game.npcs).find(x => x.id !== from.id && x.name.toLowerCase() === String(tell.to).toLowerCase());
    if (!to)
        return;
    (Game.know[to.id] = Game.know[to.id] || []).push(`${from.name} told you about the learner: "${clean(tell.text)}"`);
    await new Promise(r => setTimeout(r, 2500));
    const c = Game.ctx();
    try {
        const r = await Game.ask(`You are ${to.name} (${to.role}) at ${P(to.place).en}, in a language-learning life simulation. ${c.L} ${c.sp} ${kin(to)} ${from.name} just told you this about the learner: "${clean(tell.text)}". Now speak to the learner yourself and make your remark about it (scold, warn or ask them, in character). Output ONLY JSON {"say":"","mood":"neutral|smirk|surprised"}`, false);
        const say = clean(r.say || r.text);
        to.mood = r.mood || 'neutral';
        if (to.place === Game.place) {
            to.log.push({
                who: 'npc', text: say, mood: to.mood
            });
            to.waitSince = Date.now();
            if (!(Game.view === 'chat' && Game.cur === to.id)) {
                to.unread++;
                toast('👀', to.name + ': ' + say, () => openChat(to.id));
            }
            render();
        } else
            incoming(to.name, say);
    } catch (e) {
    }
}
function incoming(from, text) {
    if (!from || !text)
        return;
    const th = Game.threads[from] = Game.threads[from] || {
        msgs: [], look: lookFor(from), role: ''
    };
    th.msgs.push({ text });
    if (!(Ph.on && Ph.view === 'thread' && Ph.cur === from)) {
        th.unread = (th.unread || 0) + 1;
        toast('💬', from + ': ' + text, () => Ph.open('thread', from));
    }
}
/* ---- who is waiting for an answer: ordered by who spoke first ---- */
const waitList = pl => Object.values(Game.npcs).filter(n => n.place === pl && n.log.length && n.log[n.log.length - 1].who === 'npc' && !n.pending).sort((a, b) => (a.waitSince || 0) - (b.waitSince || 0));
const waitNo = n => waitList(n.place).indexOf(n) + 1;
/* people approach ONE AT A TIME: the next greeting arrives only when nobody is unattended */
const Greet = {
    last: 0,
    next(pl) {
        if (!pl || Game.place !== pl)
            return;
        const here = Object.values(Game.npcs).filter(n => n.place === pl);
        if (here.some(n => n.unread > 0))
            return;
        const n = here.find(x => x.pendingGreet);
        if (!n)
            return;
        const text = n.pendingGreet;
        delete n.pendingGreet;
        n.log.push({
            who: 'npc', text, mood: n.mood
        });
        n.unread = 1;
        n.waitSince = Date.now();
        this.last = Date.now();
        toast('👋', n.name + ': ' + text, () => openChat(n.id));
        Sfx.play('recv');
        render();
    },
    tick() {
        if (Game.view !== 'map' && Game.place && Date.now() - this.last > 14000)
            this.next(Game.place);
    }
};
setInterval(() => {
    try {
        Greet.tick();
    } catch (e) {
    }
}, 5000);
