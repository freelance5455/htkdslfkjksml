/**
 * Avatars: 40 ready-made cute 3D-style characters (20 male + 20 female) drawn as SVG with gradients
 * and highlights. Men and women use different head shapes, necks, shoulders, brows, eyes, lips and
 * hairstyles. look = {g:'m'|'f', t:0..19}. crop: 0 = full bust, 1 = face square, 2 = head+shoulders
 * square
 *
 * Provides: SKIN, NV, TPL, hash, mkLook, lookFor, lookInfo, MH, FH, shade, AVN, avatar
 */
const SKIN = ['#fbe3d3', '#f4cba8', '#e3ab80', '#c88c5c', '#9b6441', '#6b452f'], HAIR = ['#1c1917', '#3a2416', '#6a4126', '#8d3d20', '#d9b45f', '#b9bec7', '#eef0f3'], IRIS = ['#5a3a22', '#2f6fb0', '#3b7a57', '#6b7280'];
const NV = '#1e3a5f', BL = '#2563eb', GR = '#6b7280', LG = '#e5e7eb', SB = '#93c5fd';
const TPL = {
    m: [
        {
            s: 2, h: 0, st: 0, c: 0, cc: NV, ac: '', age: 'a'
        }, {
            s: 1, h: 2, st: 1, c: 2, cc: LG, ac: '', age: 'a'
        }, {
            s: 3, h: 0, st: 2, c: 3, cc: GR, ac: '', age: 'a'
        }, {
            s: 4, h: 0, st: 3, c: 1, cc: BL, ac: '', age: 'a'
        },
        {
            s: 5, h: 0, st: 4, c: 0, cc: '#f3f4f6', ac: 'r', age: 'a'
        }, {
            s: 1, h: 3, st: 5, c: 5, cc: '#9ca3af', ac: 'b', age: 'a'
        }, {
            s: 2, h: 1, st: 6, c: 2, cc: SB, ac: 'B', age: 'a'
        }, {
            s: 3, h: 1, st: 7, c: 4, cc: NV, ac: 'm', age: 'a'
        },
        {
            s: 0, h: 4, st: 8, c: 4, cc: '#4b5563', ac: 's', age: 'a'
        }, {
            s: 1, h: 2, st: 9, c: 3, cc: BL, ac: 'g', age: 'a'
        }, {
            s: 2, h: 0, st: 1, c: 1, cc: GR, ac: 'm', age: 'a'
        }, {
            s: 5, h: 0, st: 0, c: 2, cc: '#d1d5db', ac: 's', age: 'a'
        },
        {
            s: 0, h: 3, st: 2, c: 0, cc: BL, ac: 'f', age: 'a'
        }, {
            s: 3, h: 2, st: 3, c: 5, cc: NV, ac: 't', age: 'a'
        }, {
            s: 1, h: 2, st: 9, c: 0, cc: BL, ac: '', age: 'k'
        }, {
            s: 4, h: 0, st: 0, c: 3, cc: GR, ac: '', age: 'k'
        },
        {
            s: 1, h: 5, st: 1, c: 5, cc: '#9ca3af', ac: 'rw', age: 's'
        }, {
            s: 0, h: 6, st: 6, c: 2, cc: SB, ac: 'Bw', age: 's'
        }, {
            s: 3, h: 6, st: 8, c: 4, cc: '#4b5563', ac: 'w', age: 's'
        }, {
            s: 4, h: 1, st: 5, c: 3, cc: NV, ac: 'B', age: 'a'
        }
    ],
    f: [
        {
            s: 1, h: 0, st: 0, c: 0, cc: '#f3f4f6', ac: '', age: 'a'
        }, {
            s: 0, h: 4, st: 1, c: 3, cc: GR, ac: 'e', age: 'a'
        }, {
            s: 2, h: 2, st: 2, c: 2, cc: BL, ac: 'o', age: 'a'
        }, {
            s: 3, h: 0, st: 3, c: 4, cc: GR, ac: 'e', age: 'a'
        },
        {
            s: 1, h: 3, st: 4, c: 1, cc: NV, ac: 'e', age: 'a'
        }, {
            s: 5, h: 0, st: 5, c: 5, cc: BL, ac: 'e', age: 'a'
        }, {
            s: 4, h: 0, st: 6, c: 0, cc: '#9ca3af', ac: '', age: 'a'
        }, {
            s: 0, h: 4, st: 7, c: 5, cc: SB, ac: 'e', age: 'a'
        },
        {
            s: 2, h: 0, st: 8, c: 0, cc: NV, sc: '#1e3a5f', ac: '', age: 'a'
        }, {
            s: 1, h: 1, st: 9, c: 2, cc: GR, ac: 'co', age: 'a'
        }, {
            s: 2, h: 0, st: 1, c: 3, cc: NV, ac: 'e', age: 'a'
        }, {
            s: 5, h: 0, st: 2, c: 1, cc: BL, ac: 'e', age: 'a'
        },
        {
            s: 0, h: 4, st: 4, c: 4, cc: BL, ac: '', age: 'a'
        }, {
            s: 1, h: 2, st: 3, c: 0, cc: '#f3f4f6', ac: 'g', age: 'a'
        }, {
            s: 2, h: 2, st: 6, c: 2, cc: BL, ac: 'fo', age: 'k'
        }, {
            s: 4, h: 0, st: 1, c: 2, cc: '#9ca3af', ac: 'o', age: 'k'
        },
        {
            s: 1, h: 5, st: 1, c: 0, cc: '#9ca3af', ac: 'cw', age: 's'
        }, {
            s: 0, h: 6, st: 3, c: 4, cc: BL, ac: 'w', age: 's'
        }, {
            s: 3, h: 0, st: 8, c: 0, cc: '#9ca3af', sc: '#6b7280', ac: '', age: 'a'
        }, {
            s: 3, h: 3, st: 0, c: 3, cc: BL, ac: 'e', age: 'a'
        }
    ]
};
const hash = s => [...String(s)].reduce((a, c) => (a * 31 + c.charCodeAt(0)) >>> 0, 7);
/* pick a template for a person: gender + age group ('a' adult, 'k' kid, 's' senior), stable per name */
function mkLook(name, o) {
    o = o || {};
    const g = o.female !== undefined && o.female !== null ? (+o.female ? 'f' : 'm') : (hash(name) % 2 ? 'f' : 'm'), age = +o.old ? 's' : +o.kid ? 'k' : 'a', pool = TPL[g].map((x, i) => x.age === age ? i : -1).filter(i => i >= 0);
    return {
        g, t: pool[hash(name + g) % pool.length]
    };
}
const lookFor = n => mkLook(n);
const lookInfo = l => {
    l = l || {};
    const g = l.g === 'f' ? 'f' : 'm', T = TPL[g][((+l.t || 0) % 20 + 20) % 20];
    return {
        f: g === 'f', old: T.age === 's'
    };
};
/* hairstyles: b = behind head, f = in front, l = locks over shoulders; '@@' = hair colour */
const MH = [
    {
        f: '<path d="M62 90C58 54 78 40 100 40S142 54 138 90C134 70 122 62 100 62S66 70 62 90z" fill="@@" opacity=".92"/>'
    },
    {
        f: '<path d="M60 94C52 52 78 32 106 34C132 36 148 56 140 94C138 74 128 62 108 60C86 58 68 68 60 94z" fill="@@"/><path d="M92 38C96 50 92 58 84 62" stroke="#000" stroke-opacity=".18" stroke-width="2" fill="none"/>'
    },
    {
        f: '<path d="M58 94C48 48 82 20 116 24C146 28 150 62 140 94C138 74 128 58 106 56C86 54 66 66 58 94z" fill="@@"/><path d="M72 44C84 14 126 16 134 42C116 30 90 30 72 44z" fill="@@"/>'
    },
    {
        f: [66, 82, 98, 114, 130].map((x, i) => `<circle cx="${x}" cy="${46 - (i % 2) * 6 - (i === 2 ? 6 : 0)}" r="17" fill="@@"/>`).join('') + '<circle cx="62" cy="76" r="10" fill="@@"/><circle cx="138" cy="76" r="10" fill="@@"/>'
    },
    {
        b: '<circle cx="100" cy="70" r="62" fill="@@"/>', f: '<path d="M66 88C66 62 80 54 100 54S134 62 134 88C124 72 114 66 100 66S76 72 66 88z" fill="@@"/>'
    },
    {
        b: '<path d="M50 96C40 36 76 18 100 18S160 36 150 96L156 190H44z" fill="@@"/>', f: '<path d="M60 94C54 54 80 36 104 38C130 40 146 58 140 94C136 76 126 62 104 60C84 58 66 68 60 94z" fill="@@"/>', l: '<path d="M52 110C44 146 46 176 54 196L70 150zM148 110C156 146 154 176 146 196L130 150z" fill="@@"/>'
    },
    {
        f: '<path d="M62 92C60 78 64 70 68 66C66 76 66 86 66 96zM138 92C140 78 136 70 132 66C134 76 134 86 134 96z" fill="@@" opacity=".85"/>'
    },
    {
        f: '<path d="M60 94C52 56 78 36 102 38C130 40 148 58 140 94C136 74 126 62 102 60C84 58 66 70 60 94z" fill="@@"/><circle cx="102" cy="28" r="15" fill="@@"/><rect x="92" y="38" width="20" height="5" rx="2.5" fill="#000" opacity=".25"/>'
    },
    {
        f: '<path d="M60 96C50 50 80 28 108 30C136 32 150 56 140 96C136 74 124 58 104 54C84 52 66 68 60 96z" fill="@@"/><path d="M80 40C92 36 112 36 124 42M74 52C92 44 116 44 130 54" stroke="#fff" stroke-opacity=".25" stroke-width="2.5" fill="none"/>'
    },
    {
        f: '<path d="M58 96C48 50 76 26 104 28C134 30 152 56 142 96L134 74 126 86 116 62 104 80 94 60 82 82 72 66z" fill="@@"/>'
    }
];
const FH = [
    {
        b: '<path d="M54 100C42 40 76 20 100 20S158 40 146 100L156 214H44z" fill="@@"/>', f: '<path d="M66 92C62 54 82 36 100 36S138 54 134 92C126 70 112 58 100 58S74 70 66 92z" fill="@@"/>', l: '<path d="M58 110C50 150 52 186 62 208L78 156zM142 110C150 150 148 186 138 208L122 156z" fill="@@"/>'
    },
    {
        b: '<path d="M54 104C44 44 78 24 100 24S156 44 146 104L146 140C132 150 68 150 54 140z" fill="@@"/>', f: '<path d="M66 94C60 56 84 36 104 36C128 38 140 58 134 94C128 74 116 60 100 60C82 60 70 74 66 94z" fill="@@"/>'
    },
    {
        f: '<path d="M66 92C62 54 82 36 100 36S138 54 134 92C126 70 112 58 100 58S74 70 66 92z" fill="@@"/><path d="M134 76C170 84 176 140 150 176C150 140 144 112 134 98z" fill="@@"/>'
    },
    {
        f: '<path d="M66 92C62 54 82 36 100 36S138 54 134 92C126 70 112 58 100 58S74 70 66 92z" fill="@@"/><circle cx="100" cy="24" r="17" fill="@@"/><path d="M90 38h20" stroke="#000" stroke-opacity=".2" stroke-width="4" stroke-linecap="round"/>'
    },
    {
        b: '<path d="M52 100C38 40 76 18 100 18S162 40 148 100C160 130 142 150 156 176C148 196 160 206 150 216H50C40 206 52 196 44 176C58 150 40 130 52 100z" fill="@@"/>', f: '<path d="M64 94C62 52 84 34 100 34S138 52 136 94C128 66 116 56 100 56S72 66 64 94z" fill="@@"/>', l: '<path d="M56 112C46 150 54 182 62 204L80 152zM144 112C154 150 146 182 138 204L120 152z" fill="@@"/>'
    },
    {
        b: '<circle cx="100" cy="66" r="62" fill="@@"/>', f: '<path d="M68 90C68 62 82 52 100 52S132 62 132 90C124 72 114 64 100 64S76 72 68 90z" fill="@@"/>'
    },
    {
        f: '<path d="M66 92C62 54 82 36 100 36S138 54 134 92C126 70 112 58 100 58S74 70 66 92z" fill="@@"/>', l: [0, 1, 2, 3, 4].map(i => `<ellipse cx="${56 - i * 2}" cy="${112 + i * 20}" rx="8" ry="11" fill="@@"/><ellipse cx="${144 + i * 2}" cy="${112 + i * 20}" rx="8" ry="11" fill="@@"/>`).join('')
    },
    {
        f: '<path d="M62 94C54 52 80 30 104 32C132 34 148 56 138 90C136 74 128 62 118 58C110 70 92 74 74 70C68 78 64 86 62 94z" fill="@@"/>'
    },
    { scarf: 1 },
    {
        b: '<path d="M54 100C42 40 76 20 100 20S158 40 146 100L152 206H48z" fill="@@"/>', f: '<path d="M64 88C62 52 84 34 100 34S138 52 136 88L136 76C118 66 82 66 64 76z" fill="@@"/>', l: '<path d="M58 112C50 150 52 184 62 204L78 156zM142 112C150 150 148 184 138 204L122 156z" fill="@@"/>'
    }
];
const shade = (h, p) => {
    const n = parseInt(h.slice(1), 16), r = n >> 16, g = n >> 8 & 255, b = n & 255, t = p < 0 ? 0 : 255, k = Math.abs(p) / 100, f = c => Math.round(c + (t - c) * k);
    return '#' + ((1 << 24) + (f(r) << 16) + (f(g) << 8) + f(b)).toString(16).slice(1);
};
let AVN = 0;
function avatar(l, mood, sz, crop) {
    l = l || {};
    const g = l.g === 'f' ? 'f' : 'm', fem = g === 'f', T = TPL[g][((+l.t || 0) % 20 + 20) % 20], id = 'av' + (++AVN), sk = SKIN[T.s], hc = HAIR[T.h], cc = T.cc, ac = T.ac || '', D = '#2a2233', has = c => ac.includes(c), hs = (fem ? FH : MH)[T.st], ir = IRIS[(T.s + T.st + T.c) % 4], lip = fem ? '#d6456a' : '#9a5248', HT = 'translate(100 104) scale(1.24 .91) translate(-100 -96)', U = n => `url(#${id}${n})`, col = x => (x || '').replace(/@@/g, U('h'));
    const defs = `<defs><radialGradient id="${id}k" cx=".36" cy=".3" r=".85"><stop offset="0" stop-color="${shade(sk, 24)}"/><stop offset=".5" stop-color="${sk}"/><stop offset="1" stop-color="${shade(sk, -17)}"/></radialGradient><linearGradient id="${id}h" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${shade(hc, 32)}"/><stop offset=".5" stop-color="${hc}"/><stop offset="1" stop-color="${shade(hc, -26)}"/></linearGradient><linearGradient id="${id}c" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${shade(cc, 26)}"/><stop offset=".6" stop-color="${cc}"/><stop offset="1" stop-color="${shade(cc, -24)}"/></linearGradient><radialGradient id="${id}b" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#ff7a93" stop-opacity=".7"/><stop offset="1" stop-color="#ff7a93" stop-opacity="0"/></radialGradient><radialGradient id="${id}i" cx=".4" cy=".35" r=".75"><stop offset="0" stop-color="${shade(ir, 38)}"/><stop offset=".6" stop-color="${ir}"/><stop offset="1" stop-color="${shade(ir, -38)}"/></radialGradient></defs>`;
    const torso = fem ? 'M30 240C30 196 58 182 100 182S170 196 170 240Z' : 'M10 240C10 190 42 176 100 176S190 190 190 240Z';
    const body = `<path d="${torso}" fill="${U('c')}"/><ellipse cx="${fem ? 72 : 60}" cy="210" rx="34" ry="16" fill="#fff" opacity=".15" transform="rotate(-18 ${fem ? 72 : 60} 210)"/>`;
    const neck = fem ? `<rect x="87" y="142" width="26" height="46" rx="12" fill="${U('k')}"/>` : `<rect x="80" y="140" width="40" height="46" rx="15" fill="${U('k')}"/>`;
    const det = fem ? [
        `<path d="M80 182L100 216 120 182z" fill="${sk}"/><path d="M80 182L100 216 120 182" fill="none" stroke="#000" stroke-opacity=".12" stroke-width="3"/>`,
        `<path d="M72 184C82 210 118 210 128 184z" fill="${sk}"/><path d="M72 184C82 210 118 210 128 184" fill="none" stroke="#000" stroke-opacity=".12" stroke-width="3"/>`,
        `<path d="M68 180Q100 214 132 180" fill="none" stroke="${shade(cc, -8)}" stroke-width="11" stroke-linecap="round"/><path d="M92 202v26M108 202v26" stroke="#fff" stroke-width="3" stroke-linecap="round"/>`,
        `<path d="${torso}" fill="#000" opacity=".26"/><path d="M84 184L100 232 116 184z" fill="#fff"/><path d="M84 184L66 214 92 202zM116 184L134 214 108 202z" fill="#000" opacity=".28"/>`,
        `<rect x="84" y="150" width="32" height="38" rx="14" fill="${U('c')}"/><path d="M84 164h32M84 174h32" stroke="#000" stroke-opacity=".14" stroke-width="3"/>`,
        `<path d="M74 186C84 208 116 208 126 186z" fill="${sk}"/><path d="M82 190C90 208 110 208 118 190" fill="none" stroke="#cbd5e1" stroke-width="2"/><circle cx="100" cy="206" r="4.5" fill="${BL}"/>`
    ][T.c]
        : [
            `<path d="M82 178C86 196 114 196 118 178z" fill="${sk}"/><path d="M82 178C86 196 114 196 118 178" fill="none" stroke="#000" stroke-opacity=".12" stroke-width="3"/>`,
            `<path d="M78 176L100 200 122 176 114 170 100 184 86 170z" fill="#fff"/><path d="M100 188V236" stroke="#000" stroke-opacity=".18" stroke-width="3"/><circle cx="100" cy="204" r="2.6" fill="#fff"/><circle cx="100" cy="220" r="2.6" fill="#fff"/>`,
            `<path d="M76 176L100 206 124 176 114 168 100 184 86 168z" fill="#fff"/><path d="M100 190l-7 10 7 38 7-38z" fill="${BL}"/>`,
            `<path d="M64 172Q100 208 136 172" fill="none" stroke="${shade(cc, -8)}" stroke-width="13" stroke-linecap="round"/><path d="M90 198v30M110 198v30" stroke="#fff" stroke-width="3" stroke-linecap="round"/><path d="M60 228h80" stroke="#000" stroke-opacity=".1" stroke-width="3"/>`,
            `<path d="${torso}" fill="#000" opacity=".26"/><path d="M84 176L100 232 116 176z" fill="#fff"/><path d="M84 176L62 214 90 200zM116 176L138 214 110 200z" fill="#000" opacity=".28"/>`,
            `<path d="M78 176C84 194 116 194 122 176" fill="none" stroke="${shade(cc, -8)}" stroke-width="11" stroke-linecap="round"/><path d="M14 228h172" stroke="#000" stroke-opacity=".1" stroke-width="4"/>`
        ][T.c];
    const headP = fem ? 'M54 98C54 62 75 52 100 52S146 62 146 98C146 126 126 158 100 158S54 126 54 98Z' : 'M53 98C53 62 74 52 100 52S147 62 147 98C147 128 128 156 100 156S53 128 53 98Z';
    const scarf = hs.scarf ? {
        b: `<path d="M46 98C34 38 72 14 100 14S166 38 154 98C164 142 156 196 100 206C44 196 36 142 46 98z" fill="${U('c')}"/>`, l: `<path d="M52 128C44 162 42 192 56 210C82 222 118 222 144 210C158 192 156 162 148 128C138 160 120 174 100 174S62 160 52 128z" fill="${U('c')}"/>`, f: `<path d="M58 88C60 58 80 46 100 46S140 58 142 88C130 68 116 62 100 62S70 68 58 88z" fill="${U('c')}"/>`
    } : null;
    const ears = `<circle cx="52" cy="110" r="9" fill="${U('k')}"/><circle cx="148" cy="110" r="9" fill="${U('k')}"/><circle cx="52" cy="111" r="4.5" fill="#000" opacity=".08"/><circle cx="148" cy="111" r="4.5" fill="#000" opacity=".08"/>` + (has('e') ? '<circle cx="52" cy="122" r="3.6" fill="#cbd5e1"/><circle cx="148" cy="122" r="3.6" fill="#cbd5e1"/>' : '');
    const head = `<ellipse cx="100" cy="158" rx="36" ry="10" fill="#000" opacity=".14"/><path d="${headP}" fill="${U('k')}"/><ellipse cx="78" cy="74" rx="18" ry="9" fill="#fff" opacity=".2" transform="rotate(-25 78 74)"/><path d="M57 104C55 82 66 64 84 58" stroke="#fff" stroke-opacity=".3" stroke-width="4" fill="none" stroke-linecap="round"/>`;
    const E = fem ? {
        x: [79, 121], y: 108, rx: 9.8, ry: 11, ir: 7.6
    } : {
        x: [78, 122], y: 108, rx: 8.6, ry: 9.6, ir: 6.6
    }, sup = mood === 'surprised';
    const eyes = mood === 'laugh' ? E.x.map(x => `<path d="M${x - 10} ${E.y + 3}Q${x} ${E.y - 10} ${x + 10} ${E.y + 3}" stroke="${D}" stroke-width="4" fill="none" stroke-linecap="round"/>`).join('') :
        `<g class="bl">${E.x.map(x => `<ellipse cx="${x}" cy="${E.y}" rx="${E.rx}" ry="${sup ? E.ry + 2.5 : E.ry}" fill="#fff"/><circle cx="${x}" cy="${E.y + .8}" r="${E.ir}" fill="${U('i')}"/><circle cx="${x}" cy="${E.y + .8}" r="${E.ir * .52}" fill="${D}"/><circle cx="${x - 2.6}" cy="${E.y - 2.8}" r="2.7" fill="#fff"/><circle cx="${x + 2.6}" cy="${E.y + 3.2}" r="1.3" fill="#fff" opacity=".85"/>`).join('')}</g>` + E.x.map(x => `<path d="M${x - E.rx - 1} ${E.y - 2}Q${x} ${E.y - E.ry - 3.5} ${x + E.rx + 1} ${E.y - 2}" stroke="${D}" stroke-width="${fem ? 3.2 : 2.6}" fill="none" stroke-linecap="round"/>`).join('') + (fem ? `<path d="M${E.x[0] - E.rx - 1} ${E.y - 3}l-5-3.5M${E.x[0] - E.rx + 2} ${E.y - 6}l-3-5M${E.x[1] + E.rx + 1} ${E.y - 3}l5-3.5M${E.x[1] + E.rx - 2} ${E.y - 6}l3-5" stroke="${D}" stroke-width="2.2" stroke-linecap="round"/>` : '');
    const up = sup || mood === 'laugh', dl = up ? -7 : 0, dr = up ? -7 : mood === 'smirk' ? -8 : 0, B = fem ? [[67, 92, 78, 83, 91, 88], [109, 88, 122, 83, 133, 92]] : [[65, 92, 78, 85, 92, 90], [108, 90, 122, 85, 135, 92]];
    const brows = B.map((b, i) => {
        const d = i ? dr : dl;
        return `M${b[0]} ${b[1] + d}Q${b[2]} ${b[3] + d} ${b[4]} ${b[5] + d}`;
    }).join('');
    const nose = '<ellipse cx="100" cy="122" rx="4.2" ry="3" fill="#000" opacity=".1"/><ellipse cx="99" cy="120.5" rx="2" ry="1.2" fill="#fff" opacity=".5"/>', my = fem ? 138 : 137;
    const mouth = {
        laugh: `<path d="M88 ${my - 4}Q100 ${my + 22} 112 ${my - 4}z" fill="#7a1f2e"/><path d="M90 ${my - 2}Q100 ${my + 4} 110 ${my - 2}V${my + 2}Q100 ${my + 8} 90 ${my + 2}z" fill="#fff"/><ellipse cx="100" cy="${my + 11}" rx="8" ry="4.5" fill="#f08a9c"/>`,
        happy: `<path d="M90 ${my - 2}Q100 ${my + 13} 110 ${my - 2}Q100 ${my + 3} 90 ${my - 2}z" fill="#fff"/><path d="M90 ${my - 2}Q100 ${my + 13} 110 ${my - 2}" stroke="${lip}" stroke-width="3.4" fill="none" stroke-linecap="round"/>`,
        smirk: `<path d="M91 ${my + 2}Q102 ${my + 7} 113 ${my - 5}" stroke="${lip}" stroke-width="3.4" fill="none" stroke-linecap="round"/>`, surprised: `<ellipse cx="100" cy="${my + 3}" rx="6.5" ry="8" fill="#7a1f2e"/>`
    }[mood] || (fem ? `<path d="M92 ${my}Q100 ${my - 4} 108 ${my}Q100 ${my + 6} 92 ${my}z" fill="${lip}"/><ellipse cx="97" cy="${my}" rx="2.5" ry="1" fill="#fff" opacity=".5"/>` : `<path d="M92 ${my}Q100 ${my + 4} 108 ${my}" stroke="${lip}" stroke-width="3.4" fill="none" stroke-linecap="round"/>`);
    const bd = fem ? '' : (has('s') ? `<g transform="${HT}"><path d="M64 108C64 136 82 150 100 150S136 136 136 108C128 124 116 132 100 132S72 124 64 108z" fill="${U('h')}" opacity=".3"/></g>` : '') + (has('b') ? `<g transform="${HT}"><path d="M62 104C60 140 80 152 100 152S140 140 138 104C132 126 120 124 100 124S68 126 62 104z" fill="${U('h')}"/></g>` : '') + (has('B') ? `<g transform="${HT}"><path d="M58 100C54 146 78 164 100 164S146 146 142 100C136 124 124 120 100 120S64 124 58 100z" fill="${U('h')}"/></g>` : '') + (has('t') ? `<ellipse cx="100" cy="150" rx="11" ry="8" fill="${U('h')}"/>` : '') + (has('m') || has('b') || has('B') ? `<path d="M82 128Q92 121 100 127Q108 121 118 128Q108 134 100 131Q92 134 82 128z" fill="${U('h')}"/>` : '');
    const gl = (() => {
        const k = has('g') ? 'g' : has('r') ? 'r' : has('c') ? 'c' : '';
        if (!k)
            return '';
        const [a, b] = E.x, y = E.y, f = `fill="#bfe0ff" fill-opacity=".22" stroke="${D}" stroke-width="3.2"`;
        return (k === 'g' ? `<g ${f}><circle cx="${a}" cy="${y}" r="17"/><circle cx="${b}" cy="${y}" r="17"/><path d="M${a + 17} ${y}h${b - a - 34}"/></g>` : k === 'r' ? `<g ${f}><rect x="${a - 17}" y="${y - 12}" width="34" height="25" rx="8"/><rect x="${b - 17}" y="${y - 12}" width="34" height="25" rx="8"/><path d="M${a + 17} ${y - 3}h${b - a - 34}"/></g>` :
            `<g ${f}><path d="M${a - 18} ${y - 7}Q${a} ${y - 17} ${a + 17} ${y - 10}L${a + 14} ${y + 11}Q${a} ${y + 14} ${a - 15} ${y + 10}z"/><path d="M${b + 18} ${y - 7}Q${b} ${y - 17} ${b - 17} ${y - 10}L${b - 14} ${y + 11}Q${b} ${y + 14} ${b + 15} ${y + 10}z"/><path d="M${a + 17} ${y - 7}Q100 ${y - 11} ${b - 17} ${y - 7}"/></g>`) + `<path d="M${a - 9} ${y - 8}l7-3M${b - 9} ${y - 8}l7-3" stroke="#fff" stroke-width="2.4" stroke-linecap="round" opacity=".8"/>`;
    })();
    const extra = (has('f') ? [[76, 126], [85, 130], [93, 127], [107, 127], [115, 130], [124, 126]].map(p => `<circle cx="${p[0]}" cy="${p[1]}" r="1.4" fill="#b4532a" opacity=".55"/>`).join('') : '') + (has('w') ? '<path d="M72 68q28-8 56 0M64 126q-4 11 2 20M136 126q4 11-2 20M60 108q5 5 10 4M140 108q-5 5-10 4" stroke="#000" stroke-opacity=".2" stroke-width="2" fill="none" stroke-linecap="round"/>' : '') + (has('o') ? `<g transform="translate(66 66) rotate(-20)"><path d="M0 0L-17-11V11z" fill="${BL}"/><path d="M0 0L17-11V11z" fill="${BL}"/><circle r="5" fill="${shade(BL, -22)}"/></g>` : '');
    const blush = `<ellipse cx="66" cy="127" rx="14" ry="9" fill="${U('b')}"/><ellipse cx="134" cy="127" rx="14" ry="9" fill="${U('b')}"/>`;
    const shine = hs.scarf || T.st === 6 && !fem ? '' : '<path d="M66 64Q88 44 120 50" stroke="#fff" stroke-opacity=".34" stroke-width="7" stroke-linecap="round" fill="none"/>';
    const inner = `${defs}${scarf ? scarf.b : `<g transform="${HT}">${col(hs.b)}</g>`}${body}${neck}${det}${scarf ? scarf.l : `<g transform="${HT}">${col(hs.l)}</g>`}${ears}${head}${blush}${scarf ? scarf.f : `<g transform="${HT}">${col(hs.f)}</g>`}${shine}<path d="${brows}" stroke="${shade(hc, -18)}" stroke-width="${fem ? 3.4 : 5.6}" fill="none" stroke-linecap="round"/>${eyes}${nose}${bd}${mouth}${extra}${gl}`;
    const kid = T.age === 'k', vb = crop === 1 ? '38 30 124 124' : crop === 2 ? '0 24 200 200' : '0 0 200 240', w = sz, h = crop ? sz : Math.round(sz * 1.2);
    return `<svg class="av ${mood === 'laugh' ? 'laugh' : ''}" viewBox="${vb}" width="${w}" height="${h}" role="img" aria-label="avatar">${kid ? `<g transform="translate(14 30) scale(.86)">${inner}</g>` : inner}</svg>`;
}
