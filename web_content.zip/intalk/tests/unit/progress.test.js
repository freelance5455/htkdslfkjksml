/* node tests/progress.test.js - XP, levels, daily goal and streak (with freezes) */
const fs = require('fs');
const J = __dirname + '/../../src/scripts/';
const mem = {};
global.localStorage = {
    getItem: k => k in mem ? mem[k] : null, setItem: (k, v) => {
        mem[k] = String(v);
    }, removeItem: k => {
        delete mem[k];
    }
};
let now = Date.UTC(2026, 5, 1, 12);
const RealDate = Date;
const FD = function (...a) {
    return a.length ? new RealDate(...a) : new RealDate(now);
};
FD.now = () => now;
FD.UTC = RealDate.UTC;
FD.prototype = RealDate.prototype;
global.Date = FD;
const toasts = [];
const ctx = {
    Sfx: { play() {
        } }, toast: (i, x) => toasts.push(i + ':' + x), head() {
    }, t: k => k, mascot: () => '', esc: s => s, Ph: { on: false }, document: {
        createElement: () => ({}), body: { appendChild() {
            } }
    }, setTimeout: () => {
    }
};
const src = fs.readFileSync(J + 'core/store.js', 'utf8') + fs.readFileSync(J + 'game/progress.js', 'utf8');
const M = new Function(...Object.keys(ctx), src + ';return {Progress,Streak,Stats,Store,GOAL}')(...Object.values(ctx));
const { Progress, Streak, Stats, Store, GOAL } = M;
let bad = 0;
const t = (n, ok) => {
    console.log((ok ? '✓ ' : '✗ ') + n);
    if (!ok)
        bad++;
};
const day = n => {
    now = Date.UTC(2026, 5, 1 + n, 12);
};
t('level thresholds', Progress.at(1) === 0 && Progress.at(2) === 60 && Progress.level(0) === 1 && Progress.level(59) === 1 && Progress.level(60) === 2 && Progress.level(1e9) === 50);
t('levels grow slower and slower', Progress.at(3) - Progress.at(2) < Progress.at(4) - Progress.at(3));
day(0);
Progress.gain(10);
t('gain adds XP', Progress.xp() === 10);
t('first activity starts streak at 1', Streak.n() === 1);
Progress.gain(-4);
t('negative XP lowers total but not below 0', Progress.xp() === 6);
Progress.gain(-100);
t('XP never negative', Progress.xp() === 0);
Progress.gain(GOAL);
t('daily goal bonus +20 once', Progress.xp() === GOAL + 20 && Stats().goal['2026-06-01'] === 1);
const before = Progress.xp();
Progress.gain(5);
t('goal bonus is not repeated', Progress.xp() === before + 5);
day(1);
Progress.gain(5);
t('next day: streak 2 and streak bonus', Streak.n() === 2 && Progress.xp() > before + 5 + 5);
day(2);
Progress.gain(5);
day(3);
Progress.gain(5);
t('consecutive days keep the streak (4)', Streak.n() === 4);
day(6);
t('missing 2+ days with no freeze: streak shows 0', Streak.n() === 0);
Progress.gain(5);
t('...and restarts at 1', Streak.n() === 1);
for (let i = 7; i <= 12; i++) {
    day(i);
    Progress.gain(5);
}
t('7 days in a row earns a freeze', Streak.n() === 7 && Streak.data().freeze === 1);
day(14);
t('a missed day is covered by the freeze', Streak.n() === 7);
Progress.gain(5);
t('freeze consumed, streak continues (8)', Streak.n() === 8 && Streak.data().freeze === 0);
t('best streak tracked', Streak.data().best >= 8);
t('week strip has 7 days, today last', Streak.week().length === 7 && Streak.week()[6].today === true);
Progress.msg(true);
Progress.msg(false, 'phone');
t('message stats counted', Stats().msgs === 2 && Stats().clean === 1);
Progress.friend();
t('friend stat', Stats().friends === 1);
Progress.visit('cafe');
Progress.visit('cafe');
t('place visit rewarded once', Object.keys(Stats().places).length === 1);
t('rank keys cover all levels', [1, 4, 5, 9, 10, 14, 15, 24, 25, 39, 40, 50].map(Progress.rankKey).join() === 'rk1,rk1,rk2,rk2,rk3,rk3,rk4,rk4,rk5,rk5,rk6,rk6');
console.log(bad ? 'FAILED ' + bad : 'ALL OK');
process.exit(bad ? 1 : 0);
