/* node tests/mistakes.test.js - trivial typography must never count as a mistake */
const fs = require('fs');
const src = fs.readFileSync(__dirname + '/../../src/scripts/core/helpers.js', 'utf8');
const a = src.indexOf('const trivialMistake');
const { realMistakes, trivialMistake } = new Function(src.slice(a) + ';return {realMistakes,trivialMistake}')();
let bad = 0;
const t = (n, ok) => {
    console.log((ok ? '✓ ' : '✗ ') + n);
    if (!ok)
        bad++;
};
t('space after comma is ignored', trivialMistake({
    wrong: 'Hola,que tal', right: 'Hola, que tal'
}));
t('capitalization is ignored', trivialMistake({
    wrong: 'hola', right: 'Hola'
}));
t('missing final period / question mark is ignored', trivialMistake({
    wrong: 'como estas', right: 'como estas?'
}) && trivialMistake({
    wrong: 'Hello world', right: 'Hello, world.'
}));
t('apostrophe and double spaces are ignored', trivialMistake({
    wrong: "dont  go", right: "don't go"
}));
t('Chinese / Korean punctuation is ignored', trivialMistake({
    wrong: '你好,你好吗', right: '你好，你好吗？'
}) && trivialMistake({
    wrong: '안녕하세요 .', right: '안녕하세요.'
}));
t('real grammar mistake is kept', !trivialMistake({
    wrong: 'yo es', right: 'yo soy'
}));
t('spelling mistake with accent is kept', !trivialMistake({
    wrong: 'esta cansado', right: 'está cansado'
}));
t('wrong word is kept', !trivialMistake({
    wrong: 'Ich bin 20 Jahre alt gehe', right: 'Ich bin 20 Jahre alt'
}));
const r = realMistakes([
    {
        wrong: 'hola,que', right: 'hola, que', note: 'x'
    }, {
        wrong: 'yo es', right: 'yo soy', note: 'ser'
    }, null, {
        wrong: '', right: 'a'
    }, {
        wrong: 'Hello', right: 'hello'
    }
]);
t('realMistakes keeps only the real one', r.length === 1 && r[0].right === 'yo soy');
t('non-array input is safe', realMistakes(undefined).length === 0 && realMistakes('x').length === 0);
console.log(bad ? 'FAILED ' + bad : 'ALL OK');
process.exit(bad ? 1 : 0);
