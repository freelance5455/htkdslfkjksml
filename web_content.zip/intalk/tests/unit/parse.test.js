/* node tests/unit/parse.test.js - checks the tolerant JSON reader against typical AI/worker outputs */
const fs = require('fs');
const src = fs.readFileSync(__dirname + '/../../src/scripts/ai/ai-service.js', 'utf8');
const { parse, extractText } = new Function(src.slice(0, src.indexOf('const SYS_JSON')) + ';return {parse,extractText}')();
const cases = [
    ['plain object', '{"a":1,"b":[1,2]}', o => o.a === 1],
    ['markdown fence', '```json\n{"a":1}\n```', o => o.a === 1],
    [
        'text around json', 'Here is the JSON you asked for:\n{"say":"Hola","mood":"happy"}\nHope it helps!', o => o.say === 'Hola'
    ],
    ['array in text', 'Sure! [{"t":"a"},{"t":"b"}] done', o => Array.isArray(o) && o.length === 2],
    [
        'truncated array of objects', '[{"id":"a","title":"Una"},{"id":"b","title":"Do', o => Array.isArray(o) && o.length >= 1 && o[0].id === 'a'
    ],
    [
        'truncated nested object', '{"city":"Madrid","narration":"Hola","npcs":[{"name":"Lucía","rel":"mo","look":{"female":1}},{"name":"Pab', o => o.city === 'Madrid' && o.npcs.length >= 1
    ],
    ['truncated after key', '{"a":1,"b":', o => o.a === 1],
    ['braces inside strings', '{"say":"use {x} and [y]","n":2}', o => o.n === 2],
    ['no json at all', 'Sorry, I cannot help with that.', o => o === null]
];
const shapes = [
    [
        'anthropic', { content: [
                {
                    type: 'text', text: 'hi'
                }
            ] }, 'hi'
    ], [
        'content string', { content: 'hi' }, 'hi'
    ], [
        'openai', { choices: [
                { message: { content: 'hi' } }
            ] }, 'hi'
    ], [
        'reply field', { reply: 'hi' }, 'hi'
    ], [
        'nested data', { data: { content: [
                    { text: 'hi' }
                ] } }, 'hi'
    ], [
        'empty content', { content: [
                {
                    type: 'text', text: ''
                }
            ] }, ''
    ], [
        'unknown', { foo: 1 }, ''
    ]
];
let bad = 0;
for (const [n, d, exp] of shapes) {
    const ok = extractText(d) === exp;
    console.log((ok ? '✓ ' : '✗ ') + 'shape: ' + n);
    if (!ok)
        bad++;
}
for (const [n, t, f] of cases) {
    let ok = false;
    try {
        ok = !!f(parse(t));
    } catch (e) {
    }
    console.log((ok ? '✓ ' : '✗ ') + n);
    if (!ok)
        bad++;
}
console.log(bad ? 'FAILED ' + bad : 'ALL OK');
process.exit(bad ? 1 : 0);
