/* node tests/unit/worker.test.js - the Groq Worker: request mapping, JSON mode, errors, Whisper (STT) and TTS */
const fs = require('fs');
const path = require('path');

const src = fs.readFileSync(path.join(__dirname, '../../worker/groq-worker.js'), 'utf8').replace('export default', 'return ');
const worker = new Function(src)();

let bad = 0;
const t = (name, ok) => { console.log((ok ? '✓ ' : '✗ ') + name); if (!ok) bad++; };

/* fake fetch: records the last upstream request and answers with the queued responses */
let up = null;
let queue = [];
const reply = (status, body) => queue.push(() => new Response(typeof body === 'string' || body instanceof Uint8Array ? body : JSON.stringify(body), { status }));
global.fetch = async (url, init) => {
    up = { url, method: init.method, headers: init.headers, body: init.body };
    if (typeof init.body === 'string') { try { up.json = JSON.parse(init.body); } catch (e) { /* not JSON */ } }
    const next = queue.shift();
    if (!next) throw new Error('network down');
    return next();
};
const env = { GROQ_API_KEY: 'gsk_test' };
const call = (body, e = env, init = {}) => worker.fetch(new Request('https://w.example/', { method: 'POST', body: typeof body === 'string' ? body : JSON.stringify(body), ...init }), e);
const ok = text => reply(200, { choices: [{ message: { content: text }, finish_reason: 'stop' }] });

(async () => {
    let r, d;

    /* basics */
    r = await worker.fetch(new Request('https://w.example/', { method: 'OPTIONS' }), env);
    t('OPTIONS -> 204 with CORS headers', r.status === 204 && r.headers.get('Access-Control-Allow-Origin') === '*');
    t('ALLOWED_ORIGIN is honoured', (await worker.fetch(new Request('https://w.example/', { method: 'OPTIONS' }), { ...env, ALLOWED_ORIGIN: 'https://x.io' })).headers.get('Access-Control-Allow-Origin') === 'https://x.io');
    r = await worker.fetch(new Request('https://w.example/'), env);
    t('GET -> 405', r.status === 405);
    r = await call({ messages: [{ role: 'user', content: 'hi' }] }, {});
    t('missing GROQ_API_KEY -> 500 with a clear message', r.status === 500 && /GROQ_API_KEY/.test((await r.json()).error));
    t('invalid JSON body -> 400', (await call('{nope')).status === 400);
    t('no messages -> 400', (await call({ system: 'x', messages: [] })).status === 400);
    t('too large -> 413', (await call({ messages: [{ role: 'user', content: 'x'.repeat(61000) }] })).status === 413);

    /* chat */
    queue = []; ok('Hola!');
    r = await call({ system: 'You are Lucía.', messages: [{ role: 'user', content: 'hi' }, { role: 'assistant', content: 'hello' }, { role: 'user', content: 'bye' }], max_tokens: 99999 });
    d = await r.json();
    t('chat answer is mapped to {content:[{type:text,text}], stop_reason}', r.status === 200 && d.content[0].type === 'text' && d.content[0].text === 'Hola!' && d.stop_reason === 'end_turn');
    t('calls Groq chat/completions with the Bearer key', up.url === 'https://api.groq.com/openai/v1/chat/completions' && up.headers.Authorization === 'Bearer gsk_test');
    t('system prompt first, roles kept in order', up.json.messages.map(m => m.role).join() === 'system,user,assistant,user');
    t('max_tokens is capped at 4096; default model is llama-3.3-70b-versatile', up.json.max_tokens === 4096 && up.json.model === 'llama-3.3-70b-versatile');
    t('plain chat does not force JSON mode', !up.json.response_format);

    ok('x'); await call({ system: 'Reply with valid JSON only: no markdown', messages: [{ role: 'user', content: 'go' }] });
    t('"valid JSON only" switches on Groq JSON mode', up.json.response_format && up.json.response_format.type === 'json_object');
    ok('x'); await call({ messages: [{ role: 'user', content: 'go' }] }, { ...env, GROQ_MODEL: 'llama-3.1-8b-instant' });
    t('GROQ_MODEL overrides the model', up.json.model === 'llama-3.1-8b-instant');
    ok('x'); await call({ messages: [{ role: 'user', content: 'go' }] });
    t('no system prompt -> no system message', up.json.messages.length === 1);

    queue = []; reply(200, { choices: [{ message: { content: '{"a":' }, finish_reason: 'length' }] });
    d = await (await call({ messages: [{ role: 'user', content: 'go' }] })).json();
    t('finish_reason "length" -> stop_reason "max_tokens"', d.stop_reason === 'max_tokens');

    queue = []; reply(400, { error: { message: "'response_format' is not supported with this model" } }); ok('{"ok":true}');
    r = await call({ system: 'valid JSON only', messages: [{ role: 'user', content: 'go' }] }); d = await r.json();
    t('a model that rejects JSON mode is retried once without it', r.status === 200 && d.content[0].text === '{"ok":true}' && !up.json.response_format);

    queue = []; reply(429, { error: { message: 'Rate limit reached' } });
    r = await call({ messages: [{ role: 'user', content: 'go' }] }); d = await r.json();
    t('429 stays 429 and says "limit"', r.status === 429 && /^limit:/.test(d.error));
    queue = []; reply(500, { error: { message: 'boom' } });
    r = await call({ messages: [{ role: 'user', content: 'go' }] });
    t('other upstream errors -> 502 with the upstream message', r.status === 502 && (await r.json()).error === 'boom');
    queue = [];
    r = await call({ messages: [{ role: 'user', content: 'go' }] });
    t('network failure -> 502 "Groq is unreachable"', r.status === 502 && /unreachable/.test((await r.json()).error));
    queue = []; reply(200, { choices: [{ message: { content: '  ' }, finish_reason: 'stop' }] });
    r = await call({ messages: [{ role: 'user', content: 'go' }] });
    t('empty answer -> 502 with the finish reason', r.status === 502 && /empty answer.*stop/.test((await r.json()).error));

    /* speech to text */
    const wav = Buffer.from('RIFFxxxxWAVE').toString('base64');
    queue = []; reply(200, { text: '  hola yo soy Ayşə ' });
    r = await call({ task: 'stt', audio: wav, lang: 'es' }); d = await r.json();
    t('stt returns the trimmed transcript', r.status === 200 && d.text === 'hola yo soy Ayşə');
    t('stt posts multipart to audio/transcriptions with whisper-large-v3-turbo and the language', up.url.endsWith('/audio/transcriptions') && up.body instanceof FormData && up.body.get('model') === 'whisper-large-v3-turbo' && up.body.get('language') === 'es' && up.body.get('response_format') === 'json');
    const file = up.body.get('file');
    t('the uploaded file is the decoded WAV', file instanceof Blob && file.size === 12 && file.type === 'audio/wav' && !up.headers['Content-Type']);
    queue = []; reply(200, { text: 'x' }); await call({ task: 'stt', audio: wav, lang: 'zh-CN' }, { ...env, GROQ_STT_MODEL: 'whisper-large-v3' });
    t('GROQ_STT_MODEL overrides; language is reduced to 2 letters', up.body.get('model') === 'whisper-large-v3' && up.body.get('language') === 'zh');
    t('stt rejects missing and huge audio', (await call({ task: 'stt' })).status === 400 && (await call({ task: 'stt', audio: 'x'.repeat(2100000) })).status === 400);
    queue = []; reply(429, { error: { message: 'slow down' } });
    t('stt rate limit -> 429', (await call({ task: 'stt', audio: wav })).status === 429);

    /* text to speech */
    queue = []; reply(200, new Uint8Array([82, 73, 70, 70, 1, 2, 3]));
    r = await call({ task: 'tts', text: 'Hello there', gender: 'f', lang: 'en' }); d = await r.json();
    t('tts returns the audio as base64 WAV', r.status === 200 && d.mime === 'audio/wav' && Buffer.from(d.audio, 'base64').toString('latin1', 0, 4) === 'RIFF');
    t('tts asks Groq audio/speech for English with the female default voice', up.url.endsWith('/audio/speech') && up.json.model === 'canopylabs/orpheus-v1-english' && up.json.voice === 'hannah' && up.json.response_format === 'wav' && up.json.input === 'Hello there');
    reply(200, new Uint8Array([1])); await call({ task: 'tts', text: 'Hi', gender: 'm' });
    t('male gender -> male voice', up.json.voice === 'troy');
    reply(200, new Uint8Array([1])); await call({ task: 'tts', text: 'Hi', gender: 'f' }, { ...env, GROQ_TTS_MODEL: 'm2', GROQ_TTS_VOICE_F: 'austin' });
    t('GROQ_TTS_MODEL and voice variables override', up.json.model === 'm2' && up.json.voice === 'austin');
    queue = [];
    r = await call({ task: 'tts', text: 'Hola', lang: 'es' }); d = await r.json();
    t('other languages -> 400 "English only" (the app then uses the device voice)', r.status === 400 && /English only/.test(d.error));
    t('tts needs text', (await call({ task: 'tts', text: '  ' })).status === 400);
    queue = []; reply(400, { error: { message: 'terms acceptance required' } });
    r = await call({ task: 'tts', text: 'Hello' });
    t('tts upstream error is passed on', r.status === 502 && /terms/.test((await r.json()).error));

    console.log(bad ? 'FAILED ' + bad : 'ALL OK');
    process.exit(bad ? 1 : 0);
})();
