/* node tests/unit/dict.test.js - built-in dictionary data (src/data/dictionary/*.txt) and the accent-insensitive search key */
const fs = require('fs'), path = require('path');
const { readDictionary } = require('../../tools/lib/data');
const app = fs.readFileSync(path.join(__dirname, '../../src/scripts/phone/apps/dictionary.js'), 'utf8');
const start = app.indexOf('const nz');
const nz = new Function(app.slice(start, app.indexOf(';\n', start) + 1) + ';return nz')();
let bad = 0;
const t = (n, ok) => {
    console.log((ok ? '✓ ' : '✗ ') + n);
    if (!ok)
        bad++;
};
let LEX;
try {
    LEX = readDictionary();
    t('every file parses: 8 columns per entry, no empty cell, "@name" line present', true);
} catch (e) {
    console.log('✗ ' + e.message);
    process.exit(1);
}
const rows = LEX.map(c => c.w.split('\n').map(l => l.split('|')));
const total = rows.reduce((a, r) => a + r.length, 0);
t('26 thematic categories', LEX.length === 26);
t(`800+ entries (${total})`, total >= 800);
const dups = LEX.flatMap(c => {
    const seen = new Set();
    return c.w.split('\n').filter(l => seen.has(l) || !seen.add(l)).map(l => c.id + ': ' + l.slice(0, 30));
});
t('no duplicate entries inside a category' + (dups.length ? ' ' + dups.join(', ') : ''), !dups.length);
const need = [
    'greet', 'phrases', 'quest', 'fam', 'job', 'place', 'house', 'body', 'food', 'cloth', 'animal', 'nature', 'trans', 'school', 'shop', 'health', 'feel', 'adj', 'verb', 'color', 'num', 'time', 'dir', 'pron', 'tech', 'hobby'
];
t('all requested kinds exist: nouns, adjectives, verbs, phrases, kinship, professions, places...', need.every(id => LEX.some(c => c.id === id)));
const by = id => LEX.find(c => c.id === id).w.split('\n').length;
t('rich lists (professions 40+, verbs 60+, adjectives 45+, phrases 45+, family 40+, places 40+)', by('job') >= 40 && by('verb') >= 60 && by('adj') >= 45 && by('phrases') >= 45 && by('fam') >= 40 && by('place') >= 40);
const fam = LEX.find(c => c.id === 'fam').w.split('\n').map(l => l.split('|'));
t('kinship keeps the paternal/maternal distinctions (əmi/dayı/bibi/xala, amca/dayı/hala/teyze)', [
    'əmi (atanın qardaşı)', 'dayı (ananın qardaşı)', 'bibi (atanın bacısı)', 'xala (ananın bacısı)'
].every(w => fam.some(f => f[0] === w)) && fam.some(f => f[1] === 'amca') && fam.some(f => f[1] === 'teyze'));
t('accent / case insensitive keys: ağıllı = AGILLI, médico = MEDICO, Straße = strasse, Öğretmen = ogretmen', nz('ağıllı') === nz('AGILLI') && nz('médico') === nz('MEDICO') && nz('Straße') === 'strasse' && nz('Öğretmen') === 'ogretmen');
t('punctuation and extra spaces are ignored', nz('  Hola,  ¿qué tal?! ') === 'hola que tal');
t('Chinese and Korean text survive normalisation', nz('你好') === '你好' && nz('안녕하세요').length > 0);
const key = r => r.map(nz).join(' ');
t('a search for "brother" finds the brother entries', rows.flat().filter(r => key(r).includes('brother')).length >= 2);
console.log(bad ? 'FAILED ' + bad : 'ALL OK');
process.exit(bad ? 1 : 0);
