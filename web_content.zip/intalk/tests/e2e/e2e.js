/* End-to-end smoke test with a fake AI. Run: node tests/e2e/e2e.js  (needs: npm i playwright; npx playwright install chromium) */
const { chromium } = require(process.env.PW || 'playwright');
const path = require('path');
const FILE = 'file://' + path.resolve(__dirname, '../../dist/index.html');
const mock = `window.__prompts=[];window.__fake=async p=>{await new Promise(r=>setTimeout(r,40));p=String(p);window.__prompts.push(p);let o;
 const L=(name,rel,role,f)=>({name,rel,role,mood:'happy',look:{skin:1,hair:1,style:f?1:0,outfit:2,female:f,cloth:0},greet:'Hola, ¿qué tal?',about:'',persona:{traits:'warm, chatty',goal:'wants to chat before dinner',bio:'Lives nearby.'}});
 if(p.includes('Decide where this player spends'))o={kind:'custom',name:'Cafetería',emoji:'☕',en:'a cafe owned by the player'};
 else if(p.includes('EXACTLY these family')){const roles=[...p.matchAll(/\\b(mo|fa|br|si|gm|gf|sp|ch) \\(/g)].map(m=>m[1]);o={city:'Madrid',narration:'Buenos días.',npcs:roles.map((r,i)=>L(['Lucía','Pablo','Rosa','Diego'][i%4],r,r,i%2===0))}} else if(p.includes('Place:'))o={city:'Madrid',narration:'Una mañana tranquila.',npcs:[L('Marta','','Camarera',1),L('Iván','','Cliente',0)]};
 else if(p.includes('GROUP conversation')){const cv=p.split('Conversation:')[1]||'',ms=p.split('MEMBERS: ')[1].split(String.fromCharCode(10))[0].split(';').map(x=>x.trim().split(' (')[0]);o={turns:[{who:ms[0],say:'Hola, soy '+ms[0]+'.',mood:'happy'},{who:ms[1]||ms[0],say:'Yo también estoy aquí.',mood:'smirk'}],mistakes:/yo es/.test(cv)?[{wrong:'yo es',right:'yo soy',note:'ser'}]:[],remember:[],newPlace:/bakery/.test(cv)?{kind:'bakery',name:'Panadería Sol',en:'a bakery'}:null,join:/call the (third|fourth)/.test(cv)?[p.split('NEARBY, not in this conversation yet: ')[1].split(' (')[0]]:[]}} else if(p.includes('You play')){const cv=p.split('Conversation:')[1]||'',oth=p.split('only these names: ')[1].split(')')[0].split(',')[0].trim();o={say:/address/.test(cv)?'¡Claro, ven a mi casa!':'Me llamo Lucía.',mood:'laugh',mistakes:[{wrong:'yo es',right:'yo soy',note:'ser'},{wrong:'hola,que tal',right:'hola, que tal',note:'espacio'}],friend:/number/.test(cv),address:/address/.test(cv),phone:[],tell:null,remember:'likes tests',newPlace:/bakery/.test(cv)?{kind:'bakery',name:'Panadería Sol',en:'a bakery'}:null,join:/call dad/.test(cv)?oth:''}} else if(p.includes('texting'))o={text:'jaja claro',mistakes:[]};
 else if(p.includes('language tutor'))return{text:'Buena pregunta: ser = permanente.'};
 else if(p.includes('Translate "'))o={t:'casa',p:'',x:'Mi casa es grande.',n:'sustantivo'};
 else if(p.includes('Wordle-style'))o={word:'casas',hint:'houses'};
 else if(p.includes('matching game'))o=[{a:'casa',b:'ev'},{a:'perro',b:'it'},{a:'gato',b:'pişik'}];
 else if(p.includes('multiple-choice'))o=[{q:'ev = ?',o:['casa','perro','gato','sol'],a:0,why:'casa = ev'},{q:'it = ?',o:['casa','perro','gato','sol'],a:1,why:'perro'}];
 else if(p.includes('dictation game'))o=[{w:'casa',tr:'ev'},{w:'perro',tr:'it'}];
 else if(p.includes('ORIGINAL fictional songs'))o=[1,2].map(i=>({id:'s'+i,title:'Canción '+i,artist:'Ana',genre:'pop',emoji:'🎸',lyrics:['Hola mundo','Vamos a bailar','La luna brilla','Canto contigo','Estamos aquí','Siempre juntos'],tr:['a','b','c','d','e','f']}));
 else if(p.includes('Phone app "'))o=[{t:'Tarea 1',x:'Haz algo.'},{t:'Tarea 2',x:'Habla.'}];
 else if(p.includes('news'))o=[{t:'Noticia',x:'Texto.'}];
 else o={say:'ok'};
 return{text:JSON.stringify(o),truncated:false}};if(!String(window.__MODE).startsWith('worker'))window.claude={use:async n=>n==='sample'?window.__fake:null};`;
(async () => {
    const b = await chromium.launch({
        args: [
            '--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream', '--autoplay-policy=no-user-gesture-required'
        ]
    });
    const ctx = await b.newContext({ viewport: {
            width: 390, height: 800
        } });
    await ctx.route(/fonts\.(googleapis|gstatic)/, r => r.abort());
    const p = await ctx.newPage();
    p.setDefaultTimeout(5000);
    const errs = [], ok = [];
    p.on('pageerror', e => errs.push('PAGEERR ' + (e.stack || e.message).split('\n').slice(0, 4).join(' | ')));
    p.on('console', m => {
        if (m.type() === 'error' && !/fonts|ERR_FAILED|ERR_NAME_NOT_RESOLVED|ERR_INTERNET_DISCONNECTED|translate_tts/.test(m.text() + (m.location().url || '')))
            errs.push('CONSOLE ' + m.text());
    });
    const MODE = process.env.MODE || 'claude';
    await p.addInitScript('window.__MODE=' + JSON.stringify(MODE));
    await p.addInitScript(mock);
    await ctx.route(/workers\.dev/, async (route) => {
        const req = route.request(), cors = {
            'access-control-allow-origin': '*', 'access-control-allow-headers': 'content-type', 'access-control-allow-methods': 'POST,OPTIONS'
        };
        if (!MODE.startsWith('worker'))
            return route.abort();
        if (req.method() === 'OPTIONS')
            return route.fulfill({
                status: 204, headers: cors
            });
        const body = JSON.parse(req.postData());
        if (body.task === 'tts') {
            global.__tts = (global.__tts || 0) + 1;
            const wav = Buffer.alloc(44 + 4800);
            wav.write('RIFF', 0);
            wav.writeUInt32LE(36 + 4800, 4);
            wav.write('WAVEfmt ', 8);
            wav.writeUInt32LE(16, 16);
            wav.writeUInt16LE(1, 20);
            wav.writeUInt16LE(1, 22);
            wav.writeUInt32LE(24000, 24);
            wav.writeUInt32LE(48000, 28);
            wav.writeUInt16LE(2, 32);
            wav.writeUInt16LE(16, 34);
            wav.write('data', 36);
            wav.writeUInt32LE(4800, 40);
            return route.fulfill({
                status: 200, contentType: 'application/json', headers: cors, body: JSON.stringify({
                    audio: wav.toString('base64'), mime: 'audio/wav'
                })
            });
        }
        if (body.task === 'stt') {
            global.__stt = body;
            return route.fulfill({
                status: 200, contentType: 'application/json', headers: cors, body: JSON.stringify({ text: 'hola yo soy Ayşə' })
            });
        }
        global.__lastBody = body;
        const r = await p.evaluate(q => window.__fake(q), body.messages[body.messages.length - 1].content);
        route.fulfill({
            status: 200, contentType: 'application/json', headers: cors, body: JSON.stringify({
                content: [
                    {
                        type: 'text', text: MODE === 'worker-messy' ? 'Sure! Here is the JSON:\n```json\n' + r.text + '\n```\nLet me know if you need more!' : r.text
                    }
                ]
            })
        });
    });
    await p.addInitScript("(function(){var o=new MutationObserver(function(){if(document.documentElement){document.documentElement.dataset.theme='dark';o.disconnect()}});o.observe(document,{childList:true})})()");
    await p.goto(FILE);
    const shot = async (n) => {
        await p.waitForTimeout(500);
        await p.screenshot({
            path: path.join(require('os').tmpdir(), 'intalk-shot-' + n + '.png')
        });
    };
    const step = async (name, fn) => {
        try {
            await fn();
            ok.push('✓ ' + name);
        } catch (e) {
            errs.push('✗ ' + name + ': ' + e.message.split('\n')[0]);
        }
    };
    await step('AI connection mode: ' + MODE, async () => {
        const has = await p.evaluate(() => !!window.claude);
        if (MODE.startsWith('worker') && has)
            throw new Error('claude should be absent in worker mode');
    });
    await step('starts in light mode even if host is dark', async () => {
        const t = await p.evaluate(() => document.documentElement.dataset.theme);
        if (t !== 'light')
            throw new Error('theme ' + t);
    });
    await step('setup wizard (4 steps, family)', async () => {
        await p.click('[data-f=nat][data-v=az]');
        await p.click('[data-f=tgt][data-v=es]');
        await p.click('[data-step="1"]');
        await p.click('[data-f=lvl][data-v=A2]');
        await p.click('[data-step="1"]');
        await p.fill('#fn', 'Ayşə');
        await p.fill('#fa', '30');
        await p.fill('#fj', 'Kafe sahibi');
        await p.click('[data-step="1"]');
        await p.click('[data-f=marital][data-v=mr]');
        await p.click('[data-fam=sp]');
        await p.click('[data-fam=br]');
        await shot('setup-family');
        await p.click('#nx');
    });
    await step('family appears at home', async () => {
        await p.waitForSelector('.who', { timeout: 8000 });
        const n = await p.locator('.who').count();
        if (n < 4)
            throw new Error('family count ' + n);
    });
    await step('workplace from profession on map', async () => {
        await p.click('#nMap');
        await p.waitForSelector('[data-place=work]', { timeout: 8000 });
        await shot('map');
    });
    await step('chat + kin terms in prompt', async () => {
        await p.click('[data-place=home]', { force: true });
        await p.waitForSelector('.who');
        await p.click('.who >> nth=1');
        await p.fill('#ci', 'hola yo es Ayşə');
        await p.click('#cs');
        await p.waitForFunction(() => {
            const n = Game.npcs[Game.cur];
            return n && !n.pending && n.log.some(x => x.who === 'me') && n.log[n.log.length - 1].who === 'npc';
        }, null, { timeout: 12000 });
        const has = await p.evaluate(() => __prompts.some(x => x.includes('You play') && x.includes('NEVER by first name')));
        if (!has)
            throw new Error('no kin text');
        await shot('chat');
    });
    await step('home address adds a place to the map', async () => {
        await p.fill('#ci', 'can I have your address?');
        await p.click('#cs');
        await p.waitForTimeout(400);
        await p.click('#nMap');
        await p.waitForSelector('[data-place^="h-"]', { timeout: 6000 });
    });
    await step('voice buttons present + tts toggle', async () => {
        await p.click('[data-place=home]', { force: true });
        await p.click('.who >> nth=1');
        await p.click('#cv');
        await p.click('#cv');
        if (!(await p.locator('#cm').count()))
            throw new Error('no mic');
    });
    const app = async (id) => {
        await p.click('#bPh');
        await p.evaluate(() => Ph.go('home')).catch(() => {
        });
        await p.click(`[data-go=${id}]`);
    };
    await step('phone home', async () => {
        await p.click('#bPh');
        await shot('phone');
    });
    await step('phone: tap outside to leave, Esc also works, phone is smaller than the screen', async () => {
        const box = await p.locator('.ph').boundingBox(), vp = p.viewportSize();
        if (box.x < 10 || box.y < 10 || box.x + box.width > vp.width - 10 || box.y + box.height > vp.height - 10)
            throw new Error('phone touches the screen edge');
        await p.mouse.click(4, 4);
        if (await p.isVisible('#scr'))
            throw new Error('outside tap did not close');
        await p.click('#bPh');
        await p.keyboard.press('Escape');
        if (await p.isVisible('#scr'))
            throw new Error('Escape did not close');
        await p.click('#bPh');
    });
    await step('Instagram shortcut on the phone', async () => {
        await p.evaluate(() => Ph.go('home'));
        const h = await p.getAttribute('a.app[href*="instagram.com/intalkofficial"]', 'href');
        const t = await p.getAttribute('a.app[href*="instagram.com/intalkofficial"]', 'target');
        if (!h || t !== '_blank')
            throw new Error('bad link');
    });
    await step('calculator 7×6=42', async () => {
        await p.evaluate(() => Ph.go('home'));
        await p.click('[data-go=calc]');
        for (const k of ['7', '×', '6', '='])
            await p.click(`[data-ck="${k}"]`);
        const d = await p.textContent('.cd');
        if (d !== '42')
            throw new Error('got ' + d);
        await shot('calc');
    });
    await step('translator', async () => {
        await p.evaluate(() => Ph.go('home'));
        await p.click('[data-go=trn]');
        await p.fill('#tri', 'ev');
        await p.click('[data-trgo]');
        await p.waitForSelector('[data-trsay]');
    });
    await step('calendar add event', async () => {
        await p.evaluate(() => Ph.go('home'));
        await p.click('[data-go=cal]');
        await p.fill('#cai', 'Test');
        await p.click('[data-cadd]');
        await p.waitForSelector('[data-cdel]');
        await shot('calendar');
    });
    await step('AI tutor', async () => {
        await p.evaluate(() => Ph.go('home'));
        await p.click('[data-go=tutor]');
        await p.fill('#tui', 'ser vs estar?');
        await p.click('[data-tu]');
        await p.waitForSelector('.tu:not(.me)', { timeout: 6000 });
    });
    await step('music: download, play, delete', async () => {
        await p.evaluate(() => Ph.go('home'));
        await p.click('[data-go=music]');
        await p.waitForSelector('[data-dl]');
        await p.click('[data-dl]:first-of-type');
        await p.waitForSelector('.cover + div', { timeout: 3000 });
        await p.waitForTimeout(1800);
        await p.click('[data-mt=lib]');
        await p.click('[data-play]');
        await p.waitForSelector('#mprog');
        await p.waitForTimeout(900);
        const st = await p.evaluate(() => ({
            s: Music.ctx.state, i: Music.i, lp: Music.lp, n: Music.ev.length, bad: Music.ev.some(e => !isFinite(e.t) || (e.k === 'm' && !isFinite(e.f)))
        }));
        if (st.bad || !st.n || st.s !== 'running')
            throw new Error(JSON.stringify(st));
        await shot('player');
        await p.click('[data-mp=play]');
        await p.click('[data-go=music]');
        await p.click('[data-sdel]');
        await p.waitForTimeout(200);
    });
    await step('music engine composes all 8 languages', async () => {
        const r = await p.evaluate(() => Object.keys(LANGS).map(l => {
            Music.compose({
                id: l + '-x', lang: l
            });
            return Music.ev.length > 100 && Music.ev.every(e => isFinite(e.t) && (!e.f || isFinite(e.f)));
        }));
        if (r.includes(false))
            throw new Error(r.join());
    });
    await step('word guess game', async () => {
        await p.evaluate(() => Ph.go('home'));
        await p.click('[data-go=games]');
        await p.click('[data-go=g-wrd]');
        await p.waitForSelector('#wgi');
        await p.fill('#wgi', 'casas');
        await p.click('[data-wg]');
        await p.waitForSelector('.wt.g');
        await shot('wordle');
    });
    await step('match game', async () => {
        await p.click('[data-go=games]');
        await p.click('[data-go=g-mat]');
        await p.waitForSelector('[data-ml]');
        const t = await p.evaluate(() => Mt.L.map(x => x.k));
        for (const k of t.slice(0, 1)) {
            await p.click(`[data-ml="${k}"]`);
            await p.click(`[data-mr="${k}"]`);
        }
    });
    await step('quiz game', async () => {
        await p.click('[data-go=games]');
        await p.click('[data-go=g-qz]');
        await p.waitForSelector('[data-qa]');
        await p.click('[data-qa="0"]');
        await p.click('[data-qn]');
    });
    await step('listen game', async () => {
        await p.click('[data-go=games]');
        await p.click('[data-go=g-lis]');
        await p.waitForSelector('#lsi');
        await p.fill('#lsi', 'casa');
        await p.click('[data-lchk]');
        await p.waitForSelector('[data-lnext]');
    });
    await step('xox + memory', async () => {
        await p.click('[data-go=games]');
        await p.click('[data-go=ttt]');
        await p.click('[data-t="0"]');
        await p.click('[data-go=games]');
        await p.click('[data-go=mem]');
        await p.click('[data-m="0"]');
    });
    await step('news / contacts / notebook / profile / settings / dark', async () => {
        for (const g of ['news', 'friends', 'notebook', 'profile', 'settings']) {
            await p.evaluate(() => Ph.go('home'));
            await p.click(`[data-go=${g}]`);
            await p.waitForTimeout(150);
        }
        await p.click('[data-act=theme]');
        await shot('dark');
    });
    await step('sound effects run on the shared audio context', async () => {
        await p.evaluate(() => Sfx.play('level'));
        const st = await p.evaluate(async () => {
            const c = await AudioHub.get();
            return c.state;
        });
        if (st !== 'running')
            throw new Error('context ' + st);
    });
    await step('voice output never hangs: device voice or cloud voice', async () => {
        const r = await p.evaluate(() => new Promise(res => {
            const t = setTimeout(() => res('TIMEOUT'), 9000);
            Voice.speak('Hola, ¿qué tal?', {
                name: 'Lucía', look: {
                    g: 'f', t: 0
                }
            }, () => {
                clearTimeout(t);
                res(Voice.last.engine || 'none');
            });
        }));
        if (r === 'TIMEOUT')
            throw new Error('speak() never finished');
    });
    if (MODE.startsWith('worker'))
        await step('no device voice -> cloud voice through the Worker (WAV decoded and played)', async () => {
            await p.evaluate(() => {
                Object.defineProperty(window, 'speechSynthesis', {
                    value: undefined, configurable: true
                });
            });
            global.__tts = 0;
            const r = await p.evaluate(() => new Promise(res => {
                const t = setTimeout(() => res('TIMEOUT'), 9000);
                Voice.speak('Hola, ¿qué tal?', {
                    name: 'Lucía', look: {
                        g: 'f', t: 0
                    }
                }, () => {
                    clearTimeout(t);
                    res(Voice.last.engine || 'none');
                });
            }));
            if (r !== 'cloud' || !global.__tts)
                throw new Error('engine ' + r);
        });
    if (MODE.startsWith('worker'))
        await step('no browser recognition -> record the microphone and transcribe through the Worker', async () => {
            await p.evaluate(() => {
                window.SpeechRecognition = undefined;
                window.webkitSpeechRecognition = undefined;
                Voice.forceSend = true;
                Voice.maxMs = 1800;
                Ph.close();
            });
            await p.click('#nPlace');
            await p.click('.who >> nth=1');
            global.__stt = null;
            await p.click('#cm');
            await p.waitForFunction(() => [...document.querySelectorAll('.you')].some(e => e.textContent.includes('hola yo soy')), null, { timeout: 12000 });
            const b = global.__stt;
            if (!b || b.task !== 'stt' || !b.audio.startsWith('UklGR') || b.lang !== 'es')
                throw new Error('stt request ' + JSON.stringify(b && Object.keys(b)));
        });
    await step('replay button on chat bubbles + sound/voice diagnostics', async () => {
        if (!(await p.locator('.nb .spk').count()))
            throw new Error('no replay button');
        await p.evaluate(() => {
            Ph.open('diag');
        });
        await p.click('[data-dg=beep]');
        await p.click('[data-dg=voice]');
        await p.waitForFunction(() => {
            const r = [...document.querySelectorAll('.dgr')];
            return r.length >= 2 && r.every(x => !/…/.test(x.querySelector('b').textContent));
        }, null, { timeout: 12000 });
        await p.evaluate(() => Ph.close());
    });
    await step('AI diagnostics screen', async () => {
        await p.evaluate(() => Ph.open('home'));
        await p.click('[data-go=settings]');
        await p.click('[data-act=diag]');
        await p.click('[data-dg=all]');
        await p.waitForFunction(() => document.querySelectorAll('.dgr').length >= 4 && !document.querySelector('[data-dg=all]').disabled, null, { timeout: 12000 });
        const bad = await p.evaluate(() => [...document.querySelectorAll('.dgr b')].filter(b => b.textContent.includes('❌')).length);
        if (bad)
            throw new Error(bad + ' diagnostic tests failed');
    });
    await step('no emoji left in buttons/labels on any screen (icons only)', async () => {
        const views = [
            'home', 'messages', 'friends', 'news', 'games', 'ttt', 'mem', 'g-wrd', 'g-mat', 'g-qz', 'g-lis', 'notebook', 'profile', 'settings', 'wall', 'trn', 'cal', 'calc', 'tutor', 'music', 'diag'
        ];
        const bad = [];
        await p.click('#bPh').catch(() => {
        });
        for (const v of views) {
            await p.evaluate(x => Ph.go(x), v);
            await p.waitForTimeout(120);
            const r = await p.evaluate(() => {
                const rx = /[\u{1F1E6}-\u{1F1FF}]{2}|\p{Extended_Pictographic}|[‹›➤↻⇄＋]/u, skip = '.nb,.you,.mb,.tu,.ly,.pbub,.err,input,textarea,.pre,svg,script,style', out = [], w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
                let n;
                while (n = w.nextNode()) {
                    const p = n.parentElement;
                    if (!p || p.closest(skip))
                        continue;
                    if (rx.test(n.nodeValue))
                        out.push(n.nodeValue.trim().slice(0, 24) + ' @' + p.tagName + '.' + p.className);
                }
                return out;
            });
            r.forEach(x => bad.push(v + ': ' + x));
        }
        await p.evaluate(() => Ph.close());
        await p.click('#nMap');
        await p.waitForTimeout(150);
        for (const v of ['map', 'place']) {
            await p.evaluate(x => {
                Game.view = x;
                render();
            }, v);
            await p.waitForTimeout(120);
            const r = await p.evaluate(() => {
                const rx = /[\u{1F1E6}-\u{1F1FF}]{2}|\p{Extended_Pictographic}|[‹›➤↻⇄＋]/u, skip = '.nb,.you,.mb,.tu,.ly,.pbub,.err,input,textarea,.pre,svg,script,style', out = [], w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
                let n;
                while (n = w.nextNode()) {
                    const p = n.parentElement;
                    if (!p || p.closest(skip))
                        continue;
                    if (rx.test(n.nodeValue))
                        out.push(n.nodeValue.trim().slice(0, 24) + ' @' + p.tagName + '.' + p.className);
                }
                return out;
            });
            r.forEach(x => bad.push(v + ': ' + x));
        }
        if (bad.length)
            throw new Error(bad.slice(0, 25).join(' | '));
    });
    await step('XP, level-up celebration, header progress and profile screen', async () => {
        await p.evaluate(() => Progress.gain(250));
        await p.waitForSelector('.cel', { timeout: 3000 });
        await p.click('.cel');
        const lv = await p.evaluate(() => ({
            l: Progress.level(), h: document.querySelector('#streak .hs.l text')?.textContent
        }));
        if (lv.l < 2 || String(lv.l) !== lv.h)
            throw new Error('header level ' + JSON.stringify(lv));
        await p.click('#bPh');
        await p.evaluate(() => Ph.go('profile'));
        await p.waitForSelector('.achg .ach');
        const w = await p.evaluate(() => document.querySelector('.xpbar i').style.width);
        if (!/%$/.test(w))
            throw new Error('no xp bar');
        await p.evaluate(() => Ph.close());
    });
    await step('profile is remembered: reload goes straight into the game', async () => {
        await p.reload();
        await p.waitForSelector('.who', { timeout: 10000 });
        if (await p.isVisible('.wz-body'))
            throw new Error('wizard shown again');
        const prof = await p.evaluate(() => JSON.parse(localStorage.getItem('intalk_profile')));
        if (!prof.done || prof.nick !== 'Ayşə')
            throw new Error('profile not saved');
    });
    await step('settings: edit profile reopens the wizard prefilled, cancel returns to the game', async () => {
        await p.click('#bPh');
        await p.click('[data-go=settings]');
        await p.click('[data-act=profile]');
        await p.waitForSelector('.wz-body');
        if (await p.isVisible('#game'))
            throw new Error('game still visible');
        await p.click('[data-step=cancel]');
        await p.waitForSelector('#nav');
        if (!(await p.isVisible('#nav')))
            throw new Error('game not restored');
    });
    await step('phone messaging to family', async () => {
        await p.click('#bPh');
        await p.evaluate(() => Ph.go('home'));
        await p.click('[data-go=messages]');
        await p.click('.li >> nth=0');
        await p.fill('#pm', 'hola');
        await p.click('#ps');
        await p.waitForSelector('.mb:not(.me) >> nth=0');
    });
    await step('config: Worker address is intalk2.intigamrahimov.workers.dev', async () => {
        const u = await p.evaluate(() => WORKER_URL);
        if (u !== 'https://intalk2.intigamrahimov.workers.dev')
            throw new Error(u);
    });
    await step('more places: grocery, clothing, bus station, company, pharmacy, bank, restaurant, library', async () => {
        await p.evaluate(() => Ph.close());
        const r = await p.evaluate(() => ({
            n: Game.places.length, kinds: Game.places.map(x => x.kind)
        }));
        const need = [
            'market', 'clothes', 'station', 'company', 'pharmacy', 'bank', 'restaurant', 'library', 'park', 'bus'
        ];
        const miss = need.filter(k => !r.kinds.includes(k));
        if (r.n < 13 || miss.length)
            throw new Error('places ' + r.n + ' missing ' + miss.join());
    });
    await step('map looks like a navigation map: roads, buildings, park, forest, lake, river and a pin for every place', async () => {
        await p.click('#nMap');
        await p.evaluate(() => {
            Game.view = 'map';
            render();
        });
        const r = await p.evaluate(() => ({
            mk: document.querySelectorAll('.mk').length, n: Game.places.length, bld: document.querySelectorAll('.m-bld').length, park: document.querySelectorAll('.m-park').length, forest: document.querySelectorAll('.m-forest').length, water: document.querySelectorAll('.m-water').length, road: document.querySelectorAll('.m-road').length, tree: document.querySelectorAll('.m-tree').length
        }));
        if (r.mk !== r.n)
            throw new Error('pins ' + r.mk + '/' + r.n);
        for (const k of ['bld', 'park', 'forest', 'water', 'road', 'tree'])
            if (!r[k])
                throw new Error('no ' + k + ' on the map');
    });
    await step('a place somebody tells us about is added to the map', async () => {
        await p.evaluate(() => {
            Game.place = 'home';
            Game.view = 'place';
            render();
        });
        await p.click('.who >> nth=0');
        await p.fill('#ci', 'where is a bakery?');
        await p.click('#cs');
        await p.waitForFunction(() => Game.places.some(x => x.kind === 'bakery' && x.disc), null, { timeout: 12000 });
        const r = await p.evaluate(() => ({
            n: Game.places.filter(x => x.disc).length, name: Game.places.find(x => x.kind === 'bakery').n
        }));
        await p.evaluate(() => {
            Game.view = 'map';
            render();
        });
        const pin = await p.evaluate(() => !!document.querySelector('[data-place^="d-bakery"]'));
        if (r.n !== 1 || !pin || r.name !== 'Panadería Sol')
            throw new Error(JSON.stringify(r) + ' pin ' + pin);
    });
    await step('characters know the time of day and have a persona and memory', async () => {
        const r = await p.evaluate(() => {
            const c = h => Game.clock(new Date(2026, 5, 1, h, 5)).part;
            const n = Game.npcs[Game.people.home[0]];
            n.facts = ['likes tests'];
            const pr = Game.npcPrompt(n);
            return {
                parts: [c(3), c(8), c(13), c(19), c(23)].join(), prompt: pr, persona: !!n.persona, mem: Object.values(Game.npcs).some(x => (x.facts || []).length)
            };
        });
        if (r.parts !== 'night,morning,afternoon,evening,night')
            throw new Error('day parts ' + r.parts);
        for (const k of [
            'Local time now:', 'good morning" only in the morning', 'PERSONA', 'likes tests', 'REAL person'
        ])
            if (!r.prompt.includes(k))
                throw new Error('prompt lacks ' + k);
        if (!r.persona)
            throw new Error('npc has no persona');
    });
    await step('GROUP CHAT: add a second person, both answer; people can join by themselves', async () => {
        await p.evaluate(() => {
            Game.place = 'home';
            Game.view = 'place';
            render();
        });
        await p.click('.who >> nth=0').catch(e => {
            throw new Error('click .who >> nth=0: ' + e.message.split(String.fromCharCode(10))[0]);
        });
        await p.click('[data-gadd]').catch(e => {
            throw new Error('click [data-gadd]: ' + e.message.split(String.fromCharCode(10))[0]);
        });
        await p.waitForSelector('.dlg .gp');
        await p.click('.dlg .gp >> nth=1').catch(e => {
            throw new Error('click .dlg .gp >> nth=1: ' + e.message.split(String.fromCharCode(10))[0]);
        });
        if (await p.locator('.dlg [data-dlg=go]').isDisabled())
            throw new Error('start disabled with 2 people');
        await p.click('.dlg [data-dlg=go]').catch(e => {
            throw new Error('click .dlg [data-dlg=go]: ' + e.message.split(String.fromCharCode(10))[0]);
        });
        await p.waitForFunction(() => Game.grp && Game.groups[Game.grp] && Game.view === 'chat', null, { timeout: 4000 });
        await p.fill('#ci', 'hola yo es mamá y papá');
        await p.click('#cs').catch(e => {
            throw new Error('click #cs: ' + e.message.split(String.fromCharCode(10))[0]);
        });
        await p.waitForFunction(() => {
            const g = Game.groups[Game.grp];
            return g && !g.pending && new Set(g.log.filter(x => x.who === 'npc').map(x => x.npc)).size >= 2;
        }, null, { timeout: 12000 });
        const r = await p.evaluate(() => ({
            names: [...document.querySelectorAll('.nb .sn')].map(e => e.textContent), mist: document.querySelectorAll('.err').length, strip: document.querySelectorAll('.cc[data-grp]').length, mem: Game.groups[Game.grp].members.length, mistakes: ([...Game.groups[Game.grp].log].reverse().find(x => x.who === 'me') || {}).note
        }));
        if (new Set(r.names).size < 2)
            throw new Error('names ' + r.names.join());
        if (r.strip < 1)
            throw new Error('group not in strip');
        if (!r.mistakes || r.mistakes.length !== 1)
            throw new Error('mistake filter in group: ' + JSON.stringify(r.mistakes));
        await p.evaluate(() => {
            document.querySelectorAll('.toast').forEach(t => t.remove());
            document.getElementById('bk').click();
        });
        if (await p.evaluate(() => Game.view) !== 'place' || await p.evaluate(() => !!Game.grp))
            throw new Error('back from group');
        await p.click('.cc[data-grp]').catch(e => {
            throw new Error('click .cc[data-grp]: ' + e.message.split(String.fromCharCode(10))[0]);
        });
        await p.waitForFunction(() => Game.view === 'chat' && Game.grp, null, { timeout: 3000 });
        const before = await p.evaluate(() => Game.groups[Game.grp].members.length);
        await p.evaluate(() => {
            Game.view = 'place';
            Game.grp = null;
            render();
        });
        await p.click('.who >> nth=0').catch(e => {
            throw new Error('click .who >> nth=0: ' + e.message.split(String.fromCharCode(10))[0]);
        });
        await p.fill('#ci', 'please call dad');
        await p.click('#cs').catch(e => {
            throw new Error('click #cs: ' + e.message.split(String.fromCharCode(10))[0]);
        });
        await p.waitForFunction(() => Game.grp && Game.groups[Game.grp] && Game.groups[Game.grp].members.length >= 2 && Game.view === 'chat', null, { timeout: 12000 });
    });
    await step('GROUP CHAT: a group can call a third and a fourth person over', async () => {
        await p.evaluate(() => { Game.place = 'home'; Groups.open(Game.people.home.slice(0, 2)); });
        // the test family may have only 3 people: then asking for a 4th must be ignored safely
        const total = await p.evaluate(() => Game.people.home.length);
        for (const [word, count] of [['third', 3], ['fourth', Math.min(4, total)]]) {
            await p.waitForFunction(() => Game.grp && Game.groups[Game.grp] && !Game.groups[Game.grp].pending, null, { timeout: 30000 });
            await p.fill('#ci', 'please call the ' + word + ' person');
            await p.click('#cs');
            await p.waitForFunction(c => Game.grp && Game.groups[Game.grp].members.length === c && !Game.groups[Game.grp].pending, count, { timeout: 40000 });
            const r = await p.evaluate(() => {
                const g = Game.groups[Game.grp];
                return { avatars: document.querySelectorAll('.gav-i').length, joined: g.log.some(x => x.who === 'sys' && /joined|qoşuldu/.test(x.text)), members: g.members.length };
            });
            if (r.avatars !== count || !r.joined) throw new Error(word + ': ' + JSON.stringify(r));
        }
        const prompt = await p.evaluate(() => Game.groupPrompt(Game.groups[Game.grp]));
        if (!/NEARBY/.test(prompt) || !/"join":\[\]/.test(prompt)) throw new Error('group prompt lacks the join rule');
    });
    await step('dock (Messages, Phone, AI, Music) fits and is symmetric on narrow and wide phones', async () => {
        await p.evaluate(() => Ph.open('home'));
        for (const w of [320, 360, 412, 820]) {
            await p.setViewportSize({
                width: w, height: 800
            });
            await p.waitForTimeout(250);
            const r = await p.evaluate(() => {
                const d = document.querySelector('.dock').getBoundingClientRect(), t = [...document.querySelectorAll('.dock .app')].map(e => e.getBoundingClientRect()), i = [...document.querySelectorAll('.dock .app i')].map(e => e.getBoundingClientRect());
                return {
                    out: t[3].right > d.right + 0.5 || t[0].left < d.left - 0.5, gap: Math.abs((i[0].left - d.left) - (d.right - i[3].right)), w: new Set(i.map(x => Math.round(x.width))).size, step: new Set(t.slice(1).map((x, k) => Math.round(x.left - t[k].left))).size
                };
            });
            if (r.out || r.gap > 1.5 || r.w !== 1 || r.step !== 1)
                throw new Error(w + 'px ' + JSON.stringify(r));
        }
        await p.setViewportSize({
            width: 390, height: 844
        });
        await p.evaluate(() => Ph.close());
    });
    await step('no "look around" at home (no strangers bursting into the house); it stays in public places', async () => {
        await p.evaluate(() => Ph.close());
        const r = await p.evaluate(() => {
            const c = pl => {
                Game.place = pl;
                Game.view = 'place';
                if (!Game.people[pl])
                    Game.people[pl] = [];
                render();
                return document.querySelectorAll('[data-more]').length;
            };
            const h = c('home'), s = c('street');
            Game.view = 'map';
            render();
            return {
                h, s
            };
        });
        if (r.h !== 0 || r.s !== 1)
            throw new Error(JSON.stringify(r));
    });
    await step('voice last resort (audio element) speaks every sentence in the right language; failures show a reason', async () => {
        const r = await p.evaluate(async () => {
            const urls = [], Real = window.Audio;
            window.Audio = function (u) {
                urls.push(u);
                this.play = () => {
                    setTimeout(() => this.onended && this.onended(), 15);
                    return Promise.resolve();
                };
                this.pause = () => {
                };
            };
            const ok = await Voice.gtts('Hola. ¿Qué tal estás hoy?');
            const eng = Voice.last.engine;
            window.Audio = Real;
            return {
                ok, eng, n: urls.length, tl: /tl=es/.test(urls[0] || ''), enc: /q=Hola/.test(urls[0] || '')
            };
        });
        if (!r.ok || r.eng !== 'gtts' || r.n < 2 || !r.tl || !r.enc)
            throw new Error(JSON.stringify(r));
        const m = await p.evaluate(async () => {
            const real = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
            navigator.mediaDevices.getUserMedia = () => Promise.reject(Object.assign(new Error('x'), { name: 'NotAllowedError' }));
            Store.set('mic', false);
            const ok = await Perm.mic();
            const err = Perm.err;
            navigator.mediaDevices.getUserMedia = real;
            return {
                ok, err
            };
        });
        if (m.ok || !/NotAllowedError/.test(m.err))
            throw new Error(JSON.stringify(m));
    });
    await step('Azerbaijani without an az voice borrows the Turkish voice; every failed step is named in the error', async () => {
        const r = await p.evaluate(async () => {
            const RS = window.speechSynthesis, RU = window.SpeechSynthesisUtterance, RA = window.Audio, tg = S.tgt, cw = Voice.cloudOff;
            S.tgt = 'az';
            Voice.cloudOff = true;
            Voice.cloudOffAt = Date.now();
            const used = [];
            window.SpeechSynthesisUtterance = function (t) {
                this.text = t;
            };
            Object.defineProperty(window, 'speechSynthesis', {
                configurable: true, value: {
                    getVoices: () => [
                        {
                            lang: 'tr-TR', name: 'T'
                        }
                    ], cancel() {
                    }, resume() {
                    }, speak(u) {
                        used.push(u.lang);
                        setTimeout(() => {
                            u.onstart && u.onstart();
                            u.onend && u.onend();
                        }, 10);
                    }
                }
            });
            await new Promise(res => Voice.speak('Salam, necəsən?', {
                name: 'A', look: {
                    g: 'f', t: 0
                }
            }, res));
            const eng = Voice.last.engine;
            Object.defineProperty(window, 'speechSynthesis', {
                configurable: true, value: {
                    getVoices: () => [], cancel() {
                    }, resume() {
                    }, speak(u) {
                        setTimeout(() => u.onerror && u.onerror({ error: 'language-unavailable' }), 10);
                    }
                }
            });
            window.Audio = function () {
                this.play = () => {
                    setTimeout(() => this.onerror && this.onerror(), 10);
                    return Promise.resolve();
                };
                this.pause = () => {
                };
            };
            await new Promise(res => Voice.speak('Salam', {
                name: 'A', look: {
                    g: 'f', t: 0
                }
            }, res));
            const err = Voice.last.err;
            Object.defineProperty(window, 'speechSynthesis', {
                configurable: true, value: RS
            });
            window.SpeechSynthesisUtterance = RU;
            window.Audio = RA;
            S.tgt = tg;
            Voice.cloudOff = cw;
            return {
                eng, used, err
            };
        });
        if (r.eng !== 'device' || r.used[0] !== 'tr-TR')
            throw new Error('no Turkish fallback ' + JSON.stringify(r));
        for (const k of ['device(az-AZ): language-unavailable', 'device(tr-TR): language-unavailable', 'tts-audio'])
            if (!r.err.includes(k))
                throw new Error('error chain lacks ' + k + ': ' + r.err);
    });
    await step('DICTIONARY: categories, search in any language, my words, add a word, online lookup, detail page', async () => {
        // earlier steps may still have AI answers on the way; the dictionary test must not race with them
        await p.waitForFunction(() => Object.values(Game.groups).every(g => !g.pending) && Object.values(Game.npcs).every(n => !n.pending), null, { timeout: 40000 });
        await p.route(/translate\.googleapis\.com/, r => r.fulfill({
            status: 200, contentType: 'application/json', headers: { 'access-control-allow-origin': '*' }, body: JSON.stringify([[['hola amigo', 'hello friend', null, null, 1]], [['noun', ['amigo', 'compañero'], []]], 'en'])
        }));
        await p.route(/wiktionary\.org|mymemory/, r => r.abort());
        await p.evaluate(() => {
            Dict.cat = 'greet';
            Dict.q = '';
            Ph.open('dict');
        });
        await p.waitForSelector('#dq');
        const i = await p.evaluate(() => ({
            cats: document.querySelectorAll('.dcat').length, rows: document.querySelectorAll('#dlist .dli').length, total: DICT_TOTAL, home: !!document.querySelector('#scr [data-go=dict]')
        }));
        if (i.cats !== 27 || i.rows < 20 || i.total < 800)
            throw new Error(JSON.stringify(i));
        await p.evaluate(() => Ph.go('home'));
        if (!(await p.evaluate(() => !!document.querySelector('#scr [data-go=dict]'))))
            throw new Error('no Dictionary tile on the phone home screen');
        await p.evaluate(() => Ph.go('dict'));
        const f = await p.evaluate(() => {
            const r = DICT.find(c => c.id === 'fam').w[2];
            return {
                nat: r[LI[S.nat]], tg: r[LI[S.tgt]], en: r[3]
            };
        });
        for (const w of [f.nat, f.tg, f.en, f.tg.toUpperCase()]) {
            await p.fill('#dq', w);
            const ok = await p.evaluate(tg => [...document.querySelectorAll('#dlist .dli b')].some(b => b.textContent === tg), f.tg);
            if (!ok)
                throw new Error('search for "' + w + '" did not find ' + f.tg);
        }
        await p.fill('#dq', 'medico');
        if (!(await p.evaluate(() => document.querySelectorAll('#dlist .dli').length)))
            throw new Error('accent-less search found nothing');
        await p.fill('#dq', '');
        await p.click('[data-dadd]');
        await p.fill('#dwt', 'zapatilla');
        await p.fill('#dwn', 'tərlik');
        await p.click('[data-dform]');
        await p.waitForFunction(() => Dict.cat === 'my' && document.querySelectorAll('#dlist .dli').length === 1, null, { timeout: 8000 });
        await p.fill('#dq', 'tərlik');
        if (!(await p.evaluate(() => [...document.querySelectorAll('#dlist .dli b')].some(b => b.textContent === 'zapatilla'))))
            throw new Error('added word not searchable');
        await p.fill('#dq', 'hello friend');
        await p.click('[data-donl]');
        await p.waitForSelector('.donl [data-dsave]', { timeout: 8000 });
        if (!(await p.evaluate(() => document.querySelector('.donl').textContent.includes('hola amigo') && document.querySelector('.donl').textContent.includes('compañero'))))
            throw new Error('online result');
        await p.click('[data-dsave]');
        await p.waitForFunction(() => Dict.users().some(u => u.tg === 'hola amigo' && u.nat === 'hello friend'), null, { timeout: 8000 });
        await p.click('[data-dcat=fam]');
        await p.click('#dlist .dli >> nth=2');
        await p.waitForSelector('.dall');
        if ((await p.locator('.dall').count()) !== 8)
            throw new Error('detail page lacks the 8 languages');
        await p.evaluate(() => {
            Ph.go('dict');
            Ph.close();
        });
    });
    await step('Store app is gone', async () => {
        const r = await p.evaluate(() => ({
            app: !!Apps.store, btn: !!document.querySelector('[data-go=store]'), game: !!Game.installed
        }));
        if (r.app || r.btn || r.game)
            throw new Error(JSON.stringify(r));
    });
    await step('phone home screen is symmetric (every row centred, no corner mascot)', async () => {
        await p.evaluate(() => Ph.open('home'));
        await p.waitForTimeout(150);
        const r = await p.evaluate(() => {
            const c = document.querySelector('.apps').getBoundingClientRect(), els = [...document.querySelectorAll('.apps .app')].map(e => e.querySelector('i').getBoundingClientRect()), rows = {};
            els.forEach(b => {
                (rows[Math.round(b.top / 12)] = rows[Math.round(b.top / 12)] || []).push(b);
            });
            return {
                wpm: !!document.querySelector('.wpm'), rows: Object.values(rows).map(r => Math.abs((Math.min(...r.map(b => b.left)) - c.left) - (c.right - Math.max(...r.map(b => b.right)))))
            };
        });
        if (r.wpm)
            throw new Error('corner mascot still there');
        if (r.rows.some(d => d > 3))
            throw new Error('asymmetric rows ' + r.rows.join() + 'px');
    });
    await step('Settings: no Instagram row; wallpaper (photo + colour); microphone toggle asks for permission', async () => {
        await p.evaluate(() => Ph.go('settings'));
        if (await p.locator('a.li[href*="instagram"]').count())
            throw new Error('Instagram row still in Settings');
        await p.click('[data-act=wall]');
        await p.click('[data-wall=w3]');
        if (await p.evaluate(() => Store.get('wall')) !== 'w3')
            throw new Error('photo not saved');
        await p.evaluate(() => Ph.go('home'));
        let bg = await p.evaluate(() => document.getElementById('scr').style.background);
        if (!/url\(/.test(bg))
            throw new Error('photo not applied: ' + bg.slice(0, 60));
        await p.evaluate(() => Ph.go('wall'));
        await p.click('[data-wall=c-white]');
        await p.evaluate(() => Ph.go('home'));
        bg = await p.evaluate(() => document.getElementById('scr').style.background);
        if (!/gradient/.test(bg) || await p.evaluate(() => document.getElementById('scr').dataset.lt) !== '1')
            throw new Error('colour not applied');
        await p.evaluate(() => Ph.go('settings'));
        await p.evaluate(() => Store.set('mic', false));
        await p.evaluate(() => Ph.draw());
        await p.click('[data-act=mic]');
        await p.waitForFunction(() => Store.get('mic') === true, null, { timeout: 5000 });
        await p.click('[data-act=mic]');
        if (await p.evaluate(() => Store.get('mic')))
            throw new Error('mic did not switch off');
    });
    await step('people approach one at a time and are numbered by who spoke first', async () => {
        await p.evaluate(() => Ph.close());
        const r = await p.evaluate(() => {
            Game.view = 'place';
            Game.place = 'home';
            const ids = Game.people.home, ns = ids.map(i => Game.npcs[i]);
            ns.forEach(n => {
                n.log = [];
                n.unread = 0;
                n.pendingGreet = 'Hola!' + n.name;
            });
            Greet.next('home');
            Greet.next('home');
            const unread = ns.filter(n => n.unread > 0).length;
            ns[0].unread = 0;
            ns[1].unread = 0;
            ns.slice(0, 3).forEach((n, i) => {
                n.log = [
                    {
                        who: 'npc', text: 'Hi ' + i
                    }
                ];
                n.waitSince = 1000 + i * 10;
                n.pending = false;
            });
            render();
            return {
                unread, qno: [...document.querySelectorAll('.pcard.who')].map(c => c.querySelector('.qno')?.textContent || ''), first: document.querySelector('.pcard.who')?.textContent || '', bar: !!document.querySelector('.waitbar'), cur: t('first')
            };
        });
        if (r.unread !== 1)
            throw new Error('greetings arrived together: ' + r.unread);
        if (r.qno.slice(0, 3).join() !== '1,2,3')
            throw new Error('numbers ' + r.qno.join());
        if (!r.bar)
            throw new Error('no wait bar');
        if (!r.first.includes(r.cur))
            throw new Error('first card lacks the "reply first" label');
    });
    await step('Back key never closes the app: steps back through every layer', async () => {
        const url = p.url();
        await p.evaluate(() => {
            Ph.close();
            Game.view = 'chat';
            Game.cur = Game.people.home[0];
            Game.place = 'home';
            render();
        });
        await p.goBack();
        await p.waitForFunction(() => Game.view === 'place', null, { timeout: 3000 });
        await p.goBack();
        await p.waitForFunction(() => Game.view === 'map', null, { timeout: 3000 });
        await p.evaluate(() => Ph.open('games'));
        await p.goBack();
        await p.waitForFunction(() => Ph.on && Ph.view === 'home', null, { timeout: 3000 });
        await p.goBack();
        await p.waitForFunction(() => !Ph.on, null, { timeout: 3000 });
        await p.evaluate(() => confirmDlg('t', 'm', 'y', 'n', () => {
        }));
        await p.goBack();
        await p.waitForFunction(() => !document.querySelector('.dlg'), null, { timeout: 3000 });
        await p.goBack();
        await p.waitForSelector('.toast', { timeout: 3000 });
        if (p.url() !== url)
            throw new Error('left the app: ' + p.url());
    });
    await step('NEW GAME: asks first, "No" keeps the game, "Yes" goes back to language selection', async () => {
        await p.evaluate(() => Ph.open('settings'));
        await p.click('[data-act=restart]');
        await p.waitForSelector('.dlg');
        await p.click('[data-dlg=no]');
        if (await p.locator('.dlg').count())
            throw new Error('dialog stayed');
        if (!(await p.isVisible('#game')))
            throw new Error('game closed on No');
        const xp0 = await p.evaluate(() => Progress.xp());
        await p.click('[data-act=restart]');
        await p.click('[data-dlg=yes]');
        await p.waitForSelector('#setup .tiles', { timeout: 4000 });
        if (await p.isVisible('#game'))
            throw new Error('game still visible');
        if (await p.isVisible('#scr'))
            throw new Error('phone still open');
        const st = await p.evaluate(() => ({
            step: document.querySelectorAll('.stepper i.on')[0].textContent.trim(), tiles: document.querySelectorAll('#setup .tiles .chip').length, prof: JSON.parse(localStorage.getItem('intalk_profile')), xp: Progress.xp()
        }));
        if (st.step !== '1' || st.tiles < 8)
            throw new Error('not at language selection: ' + JSON.stringify({
                s: st.step, t: st.tiles
            }));
        if (st.prof.done || st.prof.nick || st.prof.job)
            throw new Error('profile not cleared');
        if (st.xp < xp0)
            throw new Error('XP lost');
        await p.reload();
        await p.waitForSelector('#setup .tiles', { timeout: 5000 });
        if (await p.isVisible('#game'))
            throw new Error('reload skipped the wizard after new game');
    });
    if (MODE.startsWith('worker')) {
        const b = global.__lastBody;
        if (!b || !Array.isArray(b.messages) || b.messages[0].role !== 'user' || !('system' in b))
            errs.push('✗ worker request shape: ' + JSON.stringify(b).slice(0, 120));
        else
            ok.push('✓ worker request shape {system, messages:[{role,content}]}');
    }
    console.log(ok.join('\n'));
    console.log(errs.length ? '\nPROBLEMS:\n' + errs.join('\n') : '\nALL OK');
    await b.close();
})().catch(e => console.log('TESTFAIL', e.message.slice(0, 300)));
