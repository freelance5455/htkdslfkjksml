#!/usr/bin/env node
/**
 * Test runner.
 *   node tests/run.js            unit tests only (fast, no browser needed)
 *   node tests/run.js --e2e      unit tests + build + end-to-end tests in 3 AI modes (needs Playwright)
 */
const { spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const run = (file, env = {}) => spawnSync(process.execPath, [path.join(root, file)], {
    stdio: 'inherit', env: {
        ...process.env, ...env
    }
}).status === 0;
let failed = 0;
const step = (name, ok) => {
    console.log(`\n${ok ? 'PASS' : 'FAIL'}  ${name}`);
    if (!ok)
        failed++;
};
for (const f of fs.readdirSync(path.join(__dirname, 'unit')).filter(f => f.endsWith('.test.js')).sort()) {
    step('unit/' + f, run('tests/unit/' + f));
}
if (process.argv.includes('--e2e')) {
    step('build', run('tools/build.js'));
    // claude = built-in AI, worker = Cloudflare Worker format, worker-messy = Worker answers with sloppy JSON
    for (const mode of ['claude', 'worker', 'worker-messy'])
        step('e2e/' + mode, run('tests/e2e/e2e.js', { MODE: mode }));
}
console.log(failed ? `\n${failed} FAILED` : '\nALL PASSED');
process.exit(failed ? 1 : 0);
