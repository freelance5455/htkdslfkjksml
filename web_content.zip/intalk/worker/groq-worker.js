/**
 * InTalk AI proxy for Cloudflare Workers - Groq edition.
 *
 * Chat            POST {system, messages:[{role,content}], max_tokens?}
 *                 -> {content:[{type:'text', text}], stop_reason}   or   {error} with an HTTP error status
 * Speech-to-text  POST {task:'stt', audio:<base64 WAV, 16 kHz mono>, lang}   -> {text}            (Groq Whisper, multilingual)
 * Text-to-speech  POST {task:'tts', text, gender:'f'|'m', lang}              -> {audio:<base64 WAV>, mime}
 *                 (Groq's TTS models speak English only; other languages get HTTP 400 and the app falls back to the device voice)
 *
 * Secret    GROQ_API_KEY  (required: Cloudflare -> Worker -> Settings -> Variables and Secrets)
 * Optional  GROQ_MODEL (default llama-3.3-70b-versatile), GROQ_STT_MODEL (default whisper-large-v3-turbo),
 *           GROQ_TTS_MODEL (default canopylabs/orpheus-v1-english), GROQ_TTS_VOICE_F (hannah), GROQ_TTS_VOICE_M (troy),
 *           ALLOWED_ORIGIN (default *)
 */
const GROQ = 'https://api.groq.com/openai/v1';

const CORS = origin => ({
    'Access-Control-Allow-Origin': origin || '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Max-Age': '86400',
});
const json = (obj, status, origin) => new Response(JSON.stringify(obj), {
    status,
    headers: { 'Content-Type': 'application/json', ...CORS(origin) },
});

/** HTTP error from Groq -> our error response (429 stays 429, everything else becomes 502). */
async function groqError(res, origin) {
    const data = await res.json().catch(() => null);
    const message = (data && data.error && data.error.message) || 'HTTP ' + res.status;
    return json({ error: (res.status === 429 ? 'limit: ' : '') + message }, res.status === 429 ? 429 : 502, origin);
}

const bytesToBase64 = bytes => {
    let s = '';
    for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    return btoa(s);
};
const base64ToBytes = b64 => Uint8Array.from(atob(b64), c => c.charCodeAt(0));

/* ---- chat ---- */
async function chat(b, env, origin) {
    const msgs = Array.isArray(b.messages) ? b.messages : [];
    if (!msgs.length) return json({ error: 'messages is required' }, 400, origin);
    const system = String(b.system || '');
    if (system.length + JSON.stringify(msgs).length > 60000) return json({ error: 'request too large' }, 413, origin);

    const body = {
        model: env.GROQ_MODEL || 'llama-3.3-70b-versatile',
        messages: [
            ...(system ? [{ role: 'system', content: system }] : []),
            ...msgs.map(m => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: String(m.content == null ? '' : m.content) })),
        ],
        max_tokens: Math.min(+b.max_tokens || 2048, 4096),
        temperature: 0.8,
    };
    // the game asks for JSON with this phrase -> use Groq's JSON mode
    if (/valid JSON only/i.test(system)) body.response_format = { type: 'json_object' };

    const call = payload => fetch(GROQ + '/chat/completions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + env.GROQ_API_KEY },
        body: JSON.stringify(payload),
    });

    let res;
    try {
        res = await call(body);
        // a model that rejects JSON mode: retry once as a normal request (the prompt already demands JSON)
        if (res.status === 400 && body.response_format) {
            const peek = await res.clone().json().catch(() => null);
            if (/response_format|json/i.test((peek && peek.error && peek.error.message) || '')) {
                delete body.response_format;
                res = await call(body);
            }
        }
    } catch (e) {
        return json({ error: 'Groq is unreachable' }, 502, origin);
    }
    if (!res.ok) return groqError(res, origin);

    const data = await res.json().catch(() => null);
    const choice = data && data.choices && data.choices[0];
    const text = (choice && choice.message && choice.message.content) || '';
    if (!String(text).trim()) {
        const why = (choice && choice.finish_reason) || 'no choices';
        return json({ error: 'empty answer from Groq (reason: ' + why + ')' }, 502, origin);
    }
    return json({ content: [{ type: 'text', text }], stop_reason: choice.finish_reason === 'length' ? 'max_tokens' : 'end_turn' }, 200, origin);
}

/* ---- speech to text (Whisper) ---- */
async function stt(b, env, origin) {
    const audio = String(b.audio || '');
    if (!audio || audio.length > 2000000) return json({ error: 'audio is required (max about 1.5 MB)' }, 400, origin);

    const form = new FormData();
    form.append('file', new Blob([base64ToBytes(audio)], { type: 'audio/wav' }), 'speech.wav');
    form.append('model', env.GROQ_STT_MODEL || 'whisper-large-v3-turbo');
    form.append('response_format', 'json');
    form.append('temperature', '0');
    const lang = String(b.lang || '').slice(0, 2).toLowerCase();
    if (/^[a-z]{2}$/.test(lang)) form.append('language', lang);

    let res;
    try {
        res = await fetch(GROQ + '/audio/transcriptions', { method: 'POST', headers: { Authorization: 'Bearer ' + env.GROQ_API_KEY }, body: form });
    } catch (e) {
        return json({ error: 'Groq is unreachable' }, 502, origin);
    }
    if (!res.ok) return groqError(res, origin);
    const data = await res.json().catch(() => null);
    return json({ text: String((data && data.text) || '').trim() }, 200, origin);
}

/* ---- text to speech (English only on Groq) ---- */
async function tts(b, env, origin) {
    const text = String(b.text || '').slice(0, 600);
    if (!text.trim()) return json({ error: 'text is required' }, 400, origin);
    if (String(b.lang || 'en').slice(0, 2).toLowerCase() !== 'en') {
        return json({ error: 'tts: this Worker voices English only (Groq has no voice for this language)' }, 400, origin);
    }
    const voice = b.gender === 'm' ? env.GROQ_TTS_VOICE_M || 'troy' : env.GROQ_TTS_VOICE_F || 'hannah';

    let res;
    try {
        res = await fetch(GROQ + '/audio/speech', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + env.GROQ_API_KEY },
            body: JSON.stringify({ model: env.GROQ_TTS_MODEL || 'canopylabs/orpheus-v1-english', input: text, voice, response_format: 'wav' }),
        });
    } catch (e) {
        return json({ error: 'Groq is unreachable' }, 502, origin);
    }
    if (!res.ok) return groqError(res, origin);
    return json({ audio: bytesToBase64(new Uint8Array(await res.arrayBuffer())), mime: 'audio/wav' }, 200, origin);
}

export default {
    async fetch(req, env) {
        const origin = env.ALLOWED_ORIGIN || '*';
        if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS(origin) });
        if (req.method !== 'POST') return json({ error: 'POST only' }, 405, origin);
        if (!env.GROQ_API_KEY) return json({ error: 'GROQ_API_KEY is not set in the Worker' }, 500, origin);

        let body;
        try {
            body = await req.json();
        } catch (e) {
            return json({ error: 'invalid JSON body' }, 400, origin);
        }
        if (body.task === 'tts') return tts(body, env, origin);
        if (body.task === 'stt') return stt(body, env, origin);
        return chat(body, env, origin);
    },
};
