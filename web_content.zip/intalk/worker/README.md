# InTalk Worker (Groq)

Cloudflare Worker that hides the Groq API key and gives the page three things: chat completions, speech-to-text
(Whisper, all 8 languages) and text-to-speech (English only - Groq's voices). API and deployment steps:
`../docs/DEPLOYMENT.md` and `../docs/ARCHITECTURE.md`.
Unit test: `node ../tests/unit/worker.test.js` (runs the Worker code against a fake `fetch`).
