/* Study Hub service worker — offline-first app shell. Version is stamped at build time. */
const VERSION='90d363a5f4';
const SHELL=['./','index.html','manifest.webmanifest','icons/icon-192.png','icons/icon-512.png','icons/maskable-512.png','icons/apple-touch-icon.png','icons/favicon-48.png'];
self.addEventListener('install',e=>{
  e.waitUntil(caches.open('shell-'+VERSION).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting()));
});
self.addEventListener('activate',e=>{
  e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('shell-')&&k!=='shell-'+VERSION).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));
});
self.addEventListener('fetch',e=>{
  const req=e.request;if(req.method!=='GET')return;
  const url=new URL(req.url);
  if(url.origin!==location.origin){                      /* Google Fonts etc.: cache after first load */
    e.respondWith(caches.open('ext-v1').then(async c=>{
      const hit=await c.match(req);
      const net=fetch(req).then(r=>{if(r&&(r.ok||r.type==='opaque'))c.put(req,r.clone());return r}).catch(()=>hit);
      return hit||net;
    }));return;
  }
  if(req.mode==='navigate'){                            /* the page: network first (gets updates), cache when offline */
    e.respondWith(fetch(req).then(r=>{const cp=r.clone();caches.open('shell-'+VERSION).then(c=>c.put('index.html',cp));return r})
      .catch(()=>caches.match('index.html').then(r=>r||caches.match('./'))));return;
  }
  e.respondWith(caches.match(req).then(hit=>hit||fetch(req).then(r=>{const cp=r.clone();caches.open('shell-'+VERSION).then(c=>c.put(req,cp));return r})));
});
