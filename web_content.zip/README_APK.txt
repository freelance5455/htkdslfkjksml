Paket ZIP to APK v1.0.6

index.html berada langsung di root ZIP. Ekstrak/unggah seluruh isi ZIP sesuai petunjuk aplikasi ZIP to APK.
Pastikan aplikasi converter mendukung HTML lokal dan akses internet jika game memuat Three.js dari CDN.
