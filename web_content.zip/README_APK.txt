SK PORTAL - APK BANANE KI GUIDE
================================

IS ZIP ME KYA HAI
  SK_Portal_App/   -> Android Studio project (app ka poora source)
  website/         -> aapki website ki files (index.html, verify.php) + hosting par lagane ka tareeka
  README_APK.txt   -> ye guide

ZAROORI BAAT
  Ye app aapki live website (https://sam.free.nf/) ko ek app ke andar kholta hai.
  Isliye website hosting par chalu rehni chahiye. Aapka data, login, cloud save aur
  QR verification sab waise hi kaam karenge jaise browser me.
  Website me kuch badlav karoge (index.html upload karoge) to app me apne aap wahi dikhega,
  APK dobara banane ki zaroorat nahi.

STEP 1 - WEBSITE ADDRESS CHECK KARO
  File kholo:  SK_Portal_App/app/src/main/res/values/strings.xml
  Is line me apni website ka sahi address likho (last me / zaroor):
     <string name="site_url">https://sam.free.nf/</string>
  Agar aapki site mrsam.gt.tc par hai to wo likho.
  App ka naam badalna ho to "app_name" badlo.

STEP 2 - APK BANAO (computer par)
  1. Android Studio download karke install karo (free): https://developer.android.com/studio
  2. Android Studio kholo -> Open -> "SK_Portal_App" folder chuno.
  3. Pehli baar sync me thoda time lagta hai (internet chahiye). Jo bhi SDK maange, Install dabao.
  4. Menu me:  Build  ->  Build Bundle(s) / APK(s)  ->  Build APK(s)
  5. Neeche "locate" dabao. APK is jagah milegi:
       SK_Portal_App/app/build/outputs/apk/debug/app-debug.apk
  6. Is APK ko WhatsApp / USB se phone me bhejo, kholo, Install karo
     (phone me "Install from unknown sources" allow karna padega).

STEP 3 - PLAY STORE ke liye (zaroori nahi, sirf agar chahiye)
  Build -> Generate Signed Bundle / APK -> apna keystore banao. Keystore file aur password
  safe rakhna, kho gaya to app update nahi ho payegi.

APP ME KYA KAAM KAREGA
  - Login, billing, workers, ledger, balance, ID card, salary slip, letter pad
  - Photo / signature upload (gallery ya file se)
  - Print / PDF: print dabane par Android ka print screen khulta hai, wahan "Save as PDF" chuno
  - Excel / CSV / zip downloads: phone ke Downloads folder me save hote hain
  - Delete / confirm wale popup
  - Internet na ho to "Dobara try karein" page aata hai
  - Phone ka back button: pichle page par jaata hai

DHYAN RAKHNE WALI BAATEN (sach me pata nahi, phone par test karke dekhna)
  - Fingerprint login (website wala) app ke andar kaam kare ya na kare, ye phone aur
    Android version par depend karta hai. Na chale to password se login karo.
  - Print ka layout phone ke print screen me alag dikh sakta hai. Ek baar test print karke dekh lena.
  - Ye APK maine yahan banakar test nahi kiya hai, kyunki yahan Android banane ka tool nahi hai.
    Android Studio me build karte time koi error aaye to uska screenshot bhej dena.

BINA ANDROID STUDIO KE (aasan tareeka)
  Agar Android Studio nahi chalana, to koi "website to APK" service use kar sakte ho
  (jaise WebIntoApp, Appilix). Unme apni website ka address daalo, app ka naam aur icon do,
  wo APK bana dengi. Pehle wale project jaisa print / download support unme alag ho sakta hai.
