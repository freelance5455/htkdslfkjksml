GT COMERCIAL — pacote preparado para conversão ZIP → APK.

Entrada: index.html na raiz.
O núcleo funciona offline; a sincronização online é opcional e só ocorre quando uma API é configurada pelo utilizador.
