====================================================
  STRIKE MOBILE — сборка APK (Android)
====================================================

ВАРИАНТ 1. ЧЕРЕЗ CAPACITOR (рекомендуется)
-----------------------------------------
1) Установите Node.js (https://nodejs.org) и Android Studio
   с SDK (https://developer.android.com/studio).

2) Положите папку shooter_mobile в отдельную директорию и откройте
   терминал в ней:

   npm init -y
   npm install @capacitor/core @capacitor/cli @capacitor/android

3) Чтобы игра работала БЕЗ интернета, скачайте Three.js локально:
   - откройте https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js
   - сохраните файл как js/three.min.js рядом с game.js
   - в index.html замените строку
       <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
     на
       <script src="js/three.min.js"></script>

4) Инициализация и сборка:

   npx cap init "Strike Mobile" ru.yourname.strike --web-dir=.
   npx cap add android
   npx cap sync
   npx cap open android        (откроется Android Studio)

5) В Android Studio: Build → Build APK(s).
   Готовый APK: android/app/build/outputs/apk/debug/app-debug.apk
   Для релизной подписанной версии: Build → Generate Signed Bundle/APK.

ВАРИАНТ 2. ОНЛАЙН-СБОРЩИКИ (без установки, быстро)
-------------------------------------------------
Заархивируйте папку в ZIP и загрузите в один из сервисов
(в настройках выберите "Fullscreen / Immersive"):
  - appsgeyser.com        - web2apk
  - median.co
  - Gonule (apps)
  - Website 2 APK Builder (Windows-программа)
Игра использует Three.js с CDN, поэтому при такой сборке
нужен интернет при первом запуске.

УПРАВЛЕНИЕ НА ТЕЛЕФОНЕ
----------------------
- Левая половина экрана  — виртуальный джойстик (движение)
- Правая половина экрана — свайп (обзор)
- ОГОНЬ / ПЕРЕЗ. / ПРЫЖОК / СМЕНА / НОЖ — кнопки справа
- ЗАЛОЖИТЬ / ОБЕЗВРЕДИТЬ — появляются рядом с бомбой/плентом (удерживать)
- ⏸ — пауза, 📋 — таблица счёта

НА ПК: WASD — движение, мышь (клик по экрану для захвата) — обзор,
ЛКМ — огонь, R — перезарядка, Q/1/2/3 — оружие, B — закупка, Пробел — прыжок.

ОСОБЕННОСТИ
----------
- Режим «Закладка бомбы» 5 на 5 (вы + 4 бота против 5 ботов)
- Матч до 8 побед, смена сторон после 8 раундов
- Ножи: стандартный, танто, керамбит, бабочка (с трюком при доставании)
- Оружие: АК-47, M4A4, M4A1-S, Galil AR, Glock-18, USP-S, Desert Eagle
- Экономика, закупка в начале раунда, $ за убийства/раунды
- 4 бесплатных бесконечных кейса: оружейный, ножевой, перчаточный, микс
- Инвентарь с экипировкой скинов (сохраняется на устройстве)
- Радар, килфид, хитмаркеры, таблица счёта, MVP раунда, статистика
