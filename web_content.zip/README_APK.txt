Наш Всесвіт — ZIP ДЛЯ WEB→APK КОНВЕРТЕРА

ВАЖЛИВО: цей архів спеціально має index.html У КОРЕНІ ZIP.
Не переміщуйте його в папку web перед завантаженням у конвертер.

Файли в корені:
- index.html — головна сторінка застосунку
- app_bg.jpg — фон застосунку
- chat_bg.jpg — фон чату
- widget.html — віджет
- sw.js — service worker
- version.json — версія

Якщо конвертер показує помилку:
file:///android_asset/web/index.html
net::ERR_FILE_NOT_FOUND
це означає, що конвертер сам очікує index.html у своїй папці web.
Завантажуйте цей ZIP як WEB-архів і вкажіть index.html як стартову сторінку.

Якщо конвертер має поле Start URL / Start Page, вкажіть:
index.html

Не вказуйте:
web/index.html

Після збірки APK усередині нього має існувати:
android_asset/web/index.html
