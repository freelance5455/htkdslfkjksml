Rewards Play - مشروع Android لتحويل صفحة HTML إلى APK

المشروع يغلّف صفحة Rewards Play الحالية داخل تطبيق Android باستخدام WebView.
الصفحة الأصلية موجودة في:
app/src/main/assets/index.html

طريقة إنشاء APK:
1) ثبّت Android Studio على الكمبيوتر.
2) فك ضغط RewardsPlay_Android.zip.
3) افتح Android Studio ثم اختر Open وحدد مجلد RewardsPlay_Android.
4) انتظر اكتمال Gradle Sync، وثبّت Android SDK Platform 35 إذا طلبه البرنامج.
5) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
6) بعد انتهاء البناء اضغط Locate للوصول إلى ملف APK.

ملاحظات:
- يلزم اتصال إنترنت لتسجيل الدخول وSupabase وتحميل مكتبة Supabase والخطوط الخارجية.
- لم يتم إنشاء APK موقّع للنشر على Google Play؛ هذا المشروع جاهز للبناء محلياً.
- لا تضع مفاتيح Supabase السرية أو service_role داخل HTML أو التطبيق.
- اختبر تسجيل الدخول والعجلة والطلبات على هاتف حقيقي بعد إنشاء APK.
- اسم الحزمة: com.rewardsplay.app
