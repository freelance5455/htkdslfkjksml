#!/bin/bash
# بناء APK — شغّل هذا السكربت من داخل المجلد بعد تثبيت Android Studio
set -e
echo "=== 1) تثبيت الحزم ==="
npm install
echo "=== 2) إضافة منصة أندرويد ==="
npx cap add android || true
echo "=== 3) مزامنة الملفات ==="
npx cap sync android
echo "=== 4) بناء APK ==="
cd android
./gradlew assembleDebug
echo ""
echo "✅ تم البناء!"
echo "الملف موجود في:"
find app/build/outputs/apk -name "*.apk" 2>/dev/null
echo ""
echo "انسخ الـ APK إلى هاتفك وثبّته."
