@echo off
chcp 65001 >nul
echo === 1) تثبيت الحزم ===
call npm install
if errorlevel 1 goto err
echo === 2) إضافة منصة أندرويد ===
call npx cap add android
echo === 3) مزامنة الملفات ===
call npx cap sync android
if errorlevel 1 goto err
echo === 4) بناء APK ===
cd android
call gradlew.bat assembleDebug
if errorlevel 1 goto err
echo.
echo ✅ تم البناء!
echo الملف موجود في: android\app\build\outputs\apk\debug\app-debug.apk
echo انسخه إلى هاتفك وثبّته.
pause
exit /b 0
:err
echo.
echo ❌ حدث خطأ. تأكد من تثبيت Node.js و Android Studio.
pause
exit /b 1
