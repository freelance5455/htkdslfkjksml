/**
 * LOUIS CBE ANALYZER — multi-school backend
 * System Administrator: Louis Macharia — 0715367959 — macharialouise7@gmail.com
 *
 * ARCHITECTURE
 *   One Apps Script project + one Spreadsheet serves every school. Each school gets:
 *     - its own sheet tab ("School_<code>") holding that school's entire JSON database
 *       in one cell, exactly like the single-school version, so each school's data never
 *       mixes with another's
 *     - its own encryption key (Script Properties: ENC_KEY_<code>) for marks/phone numbers
 *     - its own staff and parent logins, scoped only to that school's data
 *   A "Schools" registry sheet lists every school and its Principal contact.
 *
 *   HONEST LIMIT: this is real per-school data isolation, not separate hosting/deployments.
 *   It comfortably supports many schools at light-to-moderate usage on Google's free Apps
 *   Script quotas (consumer accounts: ~90 min total script runtime/day, ~30 simultaneous
 *   executions). If this grows into hundreds of schools with constant concurrent use, that
 *   is the point to move off Apps Script onto a dedicated hosted database — this design
 *   does not change that physics, it just keeps each school's data cleanly separated so a
 *   future migration per school is straightforward.
 *
 * DEPLOY: see README.md.
 */

const SYSTEM_ADMIN_EMAIL = "macharialouise7@gmail.com";
const SYSTEM_ADMIN_NAME = "Louis Macharia";
const SCHOOLS_SHEET = "Schools";
const CELL_LIMIT = 45000;
const MAX_LESSON_DOCS_PER_TERM = 10;

function setup() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let reg = ss.getSheetByName(SCHOOLS_SHEET);
  if (!reg) {
    reg = ss.insertSheet(SCHOOLS_SHEET);
    reg.appendRow(["SchoolCode", "SchoolName", "PrincipalName", "PrincipalEmail", "PrincipalPhone", "CreatedAt"]);
    reg.setFrozenRows(1);
  }
  const props = PropertiesService.getScriptProperties();
  if (!props.getProperty("SYS_ADMIN_PASS_HASH")) {
    props.setProperty("SYS_ADMIN_PASS_HASH", sha256Hex_("12345")); // change on first login
  }
  Logger.log("Setup complete.");
}

function doGet() {
  return HtmlService.createHtmlOutputFromFile("Index")
    .setTitle("Louis CBE Analyzer")
    .addMetaTag("viewport", "width=device-width, initial-scale=1");
}

// ---------- SYSTEM ADMIN (Louis): manage schools ----------
function systemAdminLogin(password) {
  const hash = PropertiesService.getScriptProperties().getProperty("SYS_ADMIN_PASS_HASH");
  if (sha256Hex_(password) !== hash) throw new Error("Incorrect system administrator password.");
  return { ok: true, name: SYSTEM_ADMIN_NAME, email: SYSTEM_ADMIN_EMAIL };
}
function changeSystemAdminPassword(oldPass, newPass) {
  const props = PropertiesService.getScriptProperties();
  if (sha256Hex_(oldPass) !== props.getProperty("SYS_ADMIN_PASS_HASH")) throw new Error("Current password is incorrect.");
  if (!newPass || newPass.length < 4) throw new Error("New password must be at least 4 characters.");
  props.setProperty("SYS_ADMIN_PASS_HASH", sha256Hex_(newPass));
  return { ok: true };
}

function listSchools() {
  const reg = getRegistry_();
  const rows = reg.getDataRange().getValues();
  return rows.slice(1).map(r => ({ code: r[0], name: r[1], principalName: r[2], principalEmail: r[3], principalPhone: r[4], createdAt: r[5] }));
}

// Creates a new, fully isolated school: its own sheet, its own encryption key, and an
// initial Principal account with an auto-generated email (firstname@cbe.co.ke).
function createSchool(sysAdminPassword, payload) {
  const props = PropertiesService.getScriptProperties();
  if (sha256Hex_(sysAdminPassword) !== props.getProperty("SYS_ADMIN_PASS_HASH")) throw new Error("Incorrect system administrator password.");
  if (!payload || !payload.schoolName || !payload.principalName || !payload.principalPhone) {
    throw new Error("School name, principal name and principal phone are required.");
  }
  const code = generateSchoolCode_(payload.schoolName);
  const reg = getRegistry_();
  const principalEmail = generateCbeEmail_(payload.principalName, code, []);
  const defaultPass = "12345";

  getOrCreateSchoolSheet_(code); // creates the tab
  props.setProperty("ENC_KEY_" + code, Utilities.getUuid());

  const seedData = emptySchoolData_(code, payload.schoolName);
  seedData.users.push({
    name: payload.principalName, email: principalEmail, phone: payload.principalPhone,
    role: "principal", subjects: [], classId: "", pass: sha256Hex_(defaultPass), status: "Approved"
  });
  writeSchoolData_(code, seedData);

  reg.appendRow([code, payload.schoolName, payload.principalName, principalEmail, payload.principalPhone, new Date()]);

  try {
    MailApp.sendEmail({
      to: principalEmail.indexOf("@cbe.co.ke") >= 0 ? SYSTEM_ADMIN_EMAIL : principalEmail, // @cbe.co.ke isn't a real inbox — notify the system admin instead
      subject: "New school created — " + payload.schoolName,
      body: `School "${payload.schoolName}" was created.\nSchool code: ${code}\nPrincipal login email: ${principalEmail}\nDefault password: ${defaultPass}\n\nPass these to the principal directly — the auto-generated @cbe.co.ke address is an internal login ID, not a real inbox.`
    });
  } catch (e) { /* email is best-effort */ }

  return { ok: true, code, principalEmail, defaultPassword: defaultPass };
}

function generateSchoolCode_(name) {
  const base = (name || "SCH").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 6) || "SCH";
  const reg = getRegistry_();
  const existing = reg.getDataRange().getValues().slice(1).map(r => r[0]);
  let code = base, n = 1;
  while (existing.indexOf(code) >= 0) { code = base + n; n++; }
  return code;
}

// firstname@cbe.co.ke — this is an internal login identifier, not a real mailbox.
// Real notifications (approvals, requests) go to the system admin or are shown on-screen.
function generateCbeEmail_(fullName, schoolCode, existingEmails) {
  const first = (fullName || "user").trim().split(/\s+/)[0].toLowerCase().replace(/[^a-z0-9]/g, "") || "user";
  let email = first + "@cbe.co.ke", n = 1;
  while (existingEmails.indexOf(email) >= 0) { email = first + n + "@cbe.co.ke"; n++; }
  return email;
}

function getRegistry_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let reg = ss.getSheetByName(SCHOOLS_SHEET);
  if (!reg) { setup(); reg = ss.getSheetByName(SCHOOLS_SHEET); }
  return reg;
}
function getOrCreateSchoolSheet_(code) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const name = "School_" + code;
  let sheet = ss.getSheetByName(name);
  if (!sheet) {
    sheet = ss.insertSheet(name);
    sheet.getRange("A1").setValue("{}");
    sheet.getRange("A2").setValue("Last saved");
    sheet.getRange("B2").setValue(new Date());
  }
  return sheet;
}
function schoolExists_(code) {
  return listSchools().some(s => s.code === code);
}

function emptySchoolData_(code, name) {
  return {
    school: { code, name }, users: [], classes: [], learners: [], exams: [], marks: [],
    timetables: {}, lessonDocs: [], staffAttendance: [], classRegister: [], accessRequests: [],
    thresholds: { EE: 80, ME: 50, AE: 30 }
  };
}

// ---------- PER-SCHOOL ENCRYPTION ----------
function encKeyFor_(code) {
  return PropertiesService.getScriptProperties().getProperty("ENC_KEY_" + code) || ("fallback-" + code);
}
function encrypt_(code, text) {
  const key = encKeyFor_(code);
  const bytes = Utilities.newBlob(String(text)).getBytes();
  const keyBytes = Utilities.newBlob(key).getBytes();
  const out = [];
  for (let i = 0; i < bytes.length; i++) out.push(bytes[i] ^ keyBytes[i % keyBytes.length]);
  return "ENC:" + Utilities.base64Encode(out);
}
function decrypt_(code, value) {
  if (typeof value !== "string" || value.indexOf("ENC:") !== 0) return value;
  const key = encKeyFor_(code);
  const bytes = Utilities.base64Decode(value.slice(4));
  const keyBytes = Utilities.newBlob(key).getBytes();
  const out = [];
  for (let i = 0; i < bytes.length; i++) out.push(bytes[i] ^ keyBytes[i % keyBytes.length]);
  return Utilities.newBlob(out).getDataAsString();
}
function transformSensitiveFields_(code, data, fn) {
  if (data && Array.isArray(data.marks)) data.marks.forEach(m => { if (m.score !== undefined && m.score !== null) m.score = fn(String(m.score)); });
  if (data && Array.isArray(data.learners)) data.learners.forEach(l => { if (l.parentPhone) l.parentPhone = fn(l.parentPhone); });
  return data;
}
function encryptForStorage_(code, data) { return transformSensitiveFields_(code, data, t => encrypt_(code, t)); }
function decryptFromStorage_(code, data) {
  return transformSensitiveFields_(code, data, v => {
    const out = decrypt_(code, v);
    return isNaN(out) ? out : Number(out);
  });
}

function withLock_(fn) {
  const lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try { return fn(); } finally { lock.releaseLock(); }
}
function readSchoolRaw_(code) {
  const sheet = getOrCreateSchoolSheet_(code);
  const val = sheet.getRange("A1").getValue();
  try { return val ? JSON.parse(val) : emptySchoolData_(code, code); } catch (e) { return emptySchoolData_(code, code); }
}
function writeSchoolData_(code, data) {
  const json = JSON.stringify(data);
  if (json.length > CELL_LIMIT) throw new Error("This school's database is getting large (" + json.length + " characters) — ask for the multi-sheet upgrade.");
  const sheet = getOrCreateSchoolSheet_(code);
  sheet.getRange("A1").setValue(json);
  sheet.getRange("B2").setValue(new Date());
}

// ---------- MAIN DATA SYNC (per school) ----------
function getData(schoolCode) {
  if (!schoolExists_(schoolCode)) throw new Error("Unknown school code.");
  const data = withLock_(() => readSchoolRaw_(schoolCode));
  return JSON.stringify(decryptFromStorage_(schoolCode, data));
}

function saveData(schoolCode, jsonString) {
  if (!schoolExists_(schoolCode)) throw new Error("Unknown school code.");
  if (typeof jsonString !== "string") throw new Error("Invalid data.");
  let incoming;
  try { incoming = JSON.parse(jsonString); } catch (e) { throw new Error("Invalid JSON."); }

  validateLessonDocCaps_(incoming);
  validateDailyAttendance_(incoming);

  withLock_(() => {
    const encrypted = encryptForStorage_(schoolCode, incoming);
    const current = readSchoolRaw_(schoolCode);
    encrypted.accessRequests = current.accessRequests || []; // server-managed, don't let client overwrite
    writeSchoolData_(schoolCode, encrypted);
  });
  return { ok: true, savedAt: new Date().toISOString() };
}

// Rule #8: at most 10 lesson plan/scheme submissions per teacher, per subject, per term+year.
function validateLessonDocCaps_(data) {
  if (!data || !Array.isArray(data.lessonDocs)) return;
  const counts = {};
  data.lessonDocs.forEach(d => {
    const key = [d.teacherEmail, d.subject, d.term, d.year].join("|");
    counts[key] = (counts[key] || 0) + 1;
  });
  Object.entries(counts).forEach(([key, n]) => {
    if (n > MAX_LESSON_DOCS_PER_TERM) {
      throw new Error("Too many lesson documents for one subject/term (max " + MAX_LESSON_DOCS_PER_TERM + "): " + key);
    }
  });
}

// Rule #9: at most one clock-IN and one clock-OUT per staff member per calendar day.
function validateDailyAttendance_(data) {
  if (!data || !Array.isArray(data.staffAttendance)) return;
  const counts = {};
  data.staffAttendance.forEach(a => {
    const dateKey = a.dateKey || new Date(a.timestamp).toDateString();
    const key = [a.staffEmail, dateKey, a.type].join("|");
    counts[key] = (counts[key] || 0) + 1;
  });
  Object.entries(counts).forEach(([key, n]) => {
    if (n > 1) throw new Error("More than one " + key.split("|")[2] + " entry for the same staff member on the same day: " + key);
  });
}

// ---------- ACCESS REQUESTS (per school, admin-gated, email-verified) ----------
function requestAccess(schoolCode, p) {
  if (!schoolExists_(schoolCode)) throw new Error("Unknown school code.");
  if (!p || !p.name || !p.email || !p.phone) throw new Error("Name, email and phone are required.");
  withLock_(() => {
    const data = readSchoolRaw_(schoolCode);
    data.accessRequests = data.accessRequests || [];
    if (data.accessRequests.some(r => r.email.toLowerCase() === p.email.toLowerCase() && r.status === "PENDING")) {
      throw new Error("A request for that email is already pending.");
    }
    data.accessRequests.push({ name: p.name, email: p.email, phone: p.phone, subject: p.subject || "", role: p.role || "subject_teacher", status: "PENDING", requestedAt: new Date().toISOString() });
    writeSchoolData_(schoolCode, data);
  });
  const reg = getRegistry_();
  const school = reg.getDataRange().getValues().slice(1).find(r => r[0] === schoolCode);
  const principalEmail = school ? school[3] : SYSTEM_ADMIN_EMAIL;
  try {
    MailApp.sendEmail({
      to: principalEmail.indexOf("@cbe.co.ke") >= 0 ? SYSTEM_ADMIN_EMAIL : principalEmail,
      subject: "New staff access request",
      body: `${p.name} has requested access.\nEmail: ${p.email}\nPhone: ${p.phone}\nSubject: ${p.subject || "—"}\n\nOpen the app's admin tab to verify and approve or reject.`
    });
  } catch (e) { /* best-effort */ }
  return { ok: true, message: "Request sent. The school's administrator will verify your details before approving." };
}

function listPendingRequests(schoolCode) {
  const data = withLock_(() => readSchoolRaw_(schoolCode));
  return (data.accessRequests || []).filter(r => r.status === "PENDING");
}

function approveRequest(schoolCode, email) {
  let passcode;
  withLock_(() => {
    const data = readSchoolRaw_(schoolCode);
    data.accessRequests = data.accessRequests || [];
    const req = data.accessRequests.find(r => r.email === email && r.status === "PENDING");
    if (!req) throw new Error("No pending request found for that email.");
    passcode = String(Math.floor(100000 + Math.random() * 900000));
    data.users = data.users || [];
    const existingEmails = data.users.map(u => u.email);
    const loginEmail = generateCbeEmail_(req.name, schoolCode, existingEmails);
    data.users.push({ name: req.name, email: loginEmail, phone: req.phone, role: req.role || "subject_teacher", subjects: req.subject ? [req.subject] : [], classId: "", pass: sha256Hex_(passcode), status: "Approved" });
    req.status = "APPROVED";
    req.loginEmail = loginEmail;
    writeSchoolData_(schoolCode, data);
  });
  return { ok: true, message: "Approved. Auto-generated login email and passcode are shown below — share them with the teacher privately." };
}

function rejectRequest(schoolCode, email) {
  withLock_(() => {
    const data = readSchoolRaw_(schoolCode);
    const req = (data.accessRequests || []).find(r => r.email === email && r.status === "PENDING");
    if (req) { req.status = "REJECTED"; writeSchoolData_(schoolCode, data); }
  });
  return { ok: true };
}

// SHA-256 hex, matching the browser's crypto.subtle.digest('SHA-256', ...) hex output.
function sha256Hex_(text) {
  const digest = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, text, Utilities.Charset.UTF_8);
  return digest.map(b => (b < 0 ? b + 256 : b).toString(16).padStart(2, "0")).join("");
}
