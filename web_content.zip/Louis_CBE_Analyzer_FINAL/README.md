# Louis CBE Analyzer — multi-school version

System Administrator: **Louis Macharia** — 0715367959 — macharialouise7@gmail.com

## What's new in this build (your 15 requested items)

1. **Updates from other users/devices** — the app re-fetches the shared database every 20
   seconds automatically while you're using it, so a mark entered on another phone shows up
   here without you doing anything. Honest limit: this is polling, not instant push — Apps
   Script/Sheets has no real-time push channel, so there can be up to ~20 seconds' delay, and
   saves are last-write-wins if two people edit the same thing at the exact same moment.
2. **PP1 to Grade 12 everywhere** — every class, subject-quick-pick, exam, lesson plan, and
   register screen uses the same canonical list (PP1, PP2, Grade 1–12), auto-grouped into
   Pre-Primary / Lower Primary / Upper Primary / Junior School / Senior School for subject sets.
3. **Auto-generated logins** — every new staff account (added directly or approved from a
   request) gets `firstname@cbe.co.ke` automatically. This is an internal login ID, not a real
   mailbox — approval/request notifications go to the Principal's or system admin's real email.
4. **Learner directory shows only the class teacher** — each class's learner list displays
   just that class's assigned Class Teacher's name/phone/email, pulled automatically from the
   staff directory, not the full staff list.
5. **Exam naming taxonomy** — Year (2023 onward) × Term (1/2/3) × Type (Opener/Mid Term/End
   Term), composed into a consistent exam name and archived permanently.
6. **Class-first, then learner** — marks entry and analysis both require picking a class
   before a learner/results list appears.
7. **Stream performance summary** — a dedicated tab that strictly requires choosing one single
   class/stream at a time (PP1–Grade 12); there is no "all streams combined" option.
8. **Lesson plans & schemes** — Term + Year fields, up to 10 documents per subject per term
   (enforced both in the browser and on the server, so it can't be bypassed), visible only to
   Principal/Deputy/Senior Teacher for review, with Approve/Comment, and an Edit & Resubmit
   button for the submitting teacher. Note: documents are rich text entries, not binary file
   uploads (e.g. not a Word/PDF attachment) — that's a further upgrade if you want real file
   attachments via Google Drive.
9. **Staff clock in/out** — available to every role, limited to one clock-in and one clock-out
   per person per calendar day (enforced server-side too). Once clocked out, only Principal,
   Deputy or Senior Teacher can edit/comment/delete that entry — the staff member can't.
10. **Multi-school** — see the architecture note below; each school gets fully isolated data,
    its own encryption key, and its own staff/parent logins.
11. **Database download restricted** — the "Download database" backup button only appears for
    the Principal's account.
12. **Six staff roles** — Principal, Deputy Principal, Senior Teacher, Class Teacher, Subject
    Teacher, Subordinate Staff — selectable whenever staff are added or approved.
13. **Subordinate Staff** — their navigation menu shows only the Attendance (clock in/out) tab.
14. **Class attendance register** — a daily register per class, editable only by that class's
    own Class Teacher or by Principal/Deputy, with a separate Countersign action restricted to
    Principal/Deputy.
15. **Rank within stream and within grade** — the Analysis tab shows each learner's rank inside
    their own class/stream, and, whenever a grade has more than one stream, their rank across
    the whole grade too.

## Architecture: how multi-school actually works here

One Apps Script project + one Spreadsheet serves every school:
- A **Schools** registry sheet lists every school and its Principal's contact.
- Each school gets its **own sheet tab** holding its entire database in one cell — exactly
  like the single-school version — so no school's data ever mixes with another's.
- Each school gets its **own encryption key**, stored separately in Script Properties.
- Each school has its **own staff and parent logins**, scoped only to that school.

**Honest limit on "up to a thousand schools":** this gives genuine per-school data isolation,
and Google Sheets can hold many hundreds of tabs without trouble. But it is still one Apps
Script project running on Google's quotas — a consumer Google account gets roughly 90 minutes
of total script runtime per day and about 30 simultaneous executions. That's plenty for
dozens of schools using the app at a light-to-moderate pace. If you reach the point of
hundreds of schools with constant, concurrent, all-day use, that's the point to move off Apps
Script onto a dedicated hosted database (e.g., Firebase or a proper SQL backend) — because each
school's data is already cleanly separated here, migrating school-by-school later is
straightforward, not a rebuild.

## Deploy it (10 minutes)
1. **sheets.google.com** → Blank spreadsheet → name it e.g. "Louis CBE Analyzer DB".
2. **Extensions → Apps Script.**
3. Replace the default `Code.gs` with this project's `Code.gs`.
4. **+** next to Files → HTML → name it exactly `Index` → paste in `Index.html`.
5. Function dropdown → `setup` → **Run** (authorize when asked). This creates the Schools
   registry and the system administrator's default password.
6. **Deploy → New deployment** → Web app → Execute as: **Me** → Who has access: **Anyone** →
   **Deploy**. Copy the Web app URL — this one link serves every school.
7. Open that link → "System administrator" → log in with the default password **12345** →
   **change it immediately** → create your first school. The Principal's login and default
   password are shown on screen once — write them down and send them to that Principal
   directly (not by email, since their generated address isn't a real inbox).
8. Android: open the link in Chrome → menu (⋮) → **Add to Home Screen** for a real
   home-screen app icon (Android 4.4+).

## Other limits still true from before
- **No automated bulk SMS** — results send through your own phone's Messages/Gmail app at
  your normal Safaricom rate; true backend bulk SMS needs a paid gateway account.
- **Not a compiled Android .apk** — "Add to Home Screen" is the real home-screen-app
  experience; a true .apk needs Android Studio and a signing key.
- **~45,000-character budget per school**, in one Sheet cell — plenty for one school for
  several years; a clear error (never silent data loss) appears if a single school's data
  ever approaches that, and the fix then is a multi-sheet upgrade for that school specifically.
