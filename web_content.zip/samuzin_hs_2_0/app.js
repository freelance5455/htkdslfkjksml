const labels=["Geral","Ponto Vermelho","Mira 2x","Mira 4x","AWM","Olhadinha"];
const values=[195,190,185,180,90,150];
let profile=0, dpi=600, current=[...values];
const list=document.getElementById("sensitivities");
const style=document.getElementById("style");
const dpiValue=document.getElementById("dpiValue");
const profileValue=document.getElementById("profileValue");
const status=document.getElementById("status");

function render(){
  list.innerHTML="";
  labels.forEach((label,i)=>{
    const item=document.createElement("div");item.className="sens-item";
    const top=document.createElement("div");top.className="sens-top";
    const name=document.createElement("span");name.textContent=label;
    const output=document.createElement("output");output.textContent=current[i];
    const slider=document.createElement("input");slider.type="range";slider.min="0";slider.max="200";slider.step="1";slider.value=current[i];
    slider.setAttribute("aria-label",`Sensibilidade ${label}`);
    slider.addEventListener("input",()=>{current[i]=Number(slider.value);output.textContent=current[i];});
    top.append(name,output);item.append(top,slider);list.append(item);
  });
  dpiValue.textContent=`${dpi} DPI`;
  profileValue.innerHTML=`${profile} <small>/ 150</small>`;
}
function generate(){
  profile=profile>=150?1:profile+1;
  const seed=profile;
  const mode=style.value;
  const base=mode==="capa"?190:mode==="rush"?180:mode==="precisao"?150:170;
  current=[base+seed%11,base-5+seed%13,base-12+seed%15,base-20+seed%17,base-80+seed%16,base-35+seed%19].map(v=>Math.max(0,Math.min(200,v)));
  dpi=400+(seed*37)%601;
  render();
  status.textContent=`Perfil ${profile} gerado! DPI e sensibilidades atualizados juntos.`;
}
function copyAll(){
  const text=`SAMUZIN HS 2.0 • FREE FIRE\nPerfil: ${profile}/150\nEstilo: ${style.options[style.selectedIndex].text}\nDPI: ${dpi}\n`+labels.map((x,i)=>`${x}: ${current[i]}`).join("\n");
  if(navigator.clipboard && window.isSecureContext){
    navigator.clipboard.writeText(text).then(()=>status.textContent="Configuração copiada!").catch(()=>fallbackCopy(text));
  }else fallbackCopy(text);
}
function fallbackCopy(text){
  const area=document.createElement("textarea");area.value=text;document.body.append(area);area.select();
  try{document.execCommand("copy");status.textContent="Configuração copiada!";}catch(e){status.textContent="Não foi possível copiar automaticamente.";}
  area.remove();
}
document.getElementById("generateBtn").addEventListener("click",generate);
document.getElementById("copyBtn").addEventListener("click",copyAll);
document.getElementById("resetBtn").addEventListener("click",()=>{profile=0;dpi=600;current=[...values];render();status.textContent="Painel restaurado.";});
render();
