package dz.hanouti.app;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.webkit.*;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
 private WebView webView;
 @SuppressLint({"SetJavaScriptEnabled","JavascriptInterface"})
 @Override public void onCreate(Bundle savedInstanceState) {
  super.onCreate(savedInstanceState);
  webView = new WebView(this);
  webView.getSettings().setJavaScriptEnabled(true);
  webView.getSettings().setDomStorageEnabled(true);
  webView.getSettings().setAllowFileAccess(true);
  webView.setWebViewClient(new WebViewClient());
  webView.setWebChromeClient(new WebChromeClient());
  webView.addJavascriptInterface(new Bridge(), "Android");
  setContentView(webView);
  webView.loadUrl("file:///android_asset/index.html");
 }
 private class Bridge {
  @JavascriptInterface public void scanBarcode(String target) {
   runOnUiThread(() -> {
    IntentIntegrator scan = new IntentIntegrator(MainActivity.this);
    scan.setDesiredBarcodeFormats(IntentIntegrator.ONE_D_CODE_TYPES);
    scan.setPrompt("وجّه الكاميرا نحو باركود السلعة");
    scan.setBeepEnabled(false); scan.setOrientationLocked(true);
    scan.setBarcodeImageEnabled(false); scan.initiateScan();
   });
  }
 }
 @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
  IntentResult result=IntentIntegrator.parseActivityResult(requestCode,resultCode,data);
  if(result!=null) {
   if(result.getContents()!=null) {
    String code=JSONObject.quote(result.getContents());
    webView.post(() -> webView.evaluateJavascript("window.onNativeBarcode("+code+");",null));
   }
   return;
  }
  super.onActivityResult(requestCode,resultCode,data);
 }
 @Override public void onBackPressed() { if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed(); }
}
