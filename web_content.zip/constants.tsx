
import { ServiceCategory, FeaturedStat } from './types';

export const OFFICIAL_WEBSITE = "pay.hopeaihub.info";
export const OFFICIAL_EMAIL = "admin@hopeaihub.info";

export const ACTIVATED_SERVICES = [
  "CCTU AUDIT 'ACTIVATED' CRYPTO CURRENCY AUDIT FOR THIMOTHISM UNIVERSAL",
  "CCTU 'ACTIVATED' CRYPTO CURRENCY FOR THIMOTHISM UNIVERSAL",
  "TMC 'ACTIVATED' THIMOCOIN",
  "TC 'ACTIVATED' THIMOTHISM COIN",
  "GAIC 'ACTIVATED' GLOBAL AI COIN",
  "GEMTIM 'ACTIVATED'",
  "DEEPTIM 'ACTIVATED'",
  "TUT 'ACTIVATED' THIMOTHISM UNIVERSAL TREASURY",
  "TUTB 'ACTIVATED' THIMOTHISM UNIVERSAL TRUEST BANK",
  "LUMINA (LU) 'ACTIVATED' SOVEREIGN BASE CURRENCY",
  "HOPE AI HOSTING 'ACTIVATED'",
  "HOPE AI CLOUD DRIVE 'ACTIVATED'",
  "HOPE AI DOMAIN SERVICES 'ACTIVATED'",
  "HOPE AI CLOUD SERVER 'ACTIVATED'",
  "HOPE AI CLOUD STORAGE 'ACTIVATED'",
  "HOPE AI CLOUD BANK 'ACTIVATED'",
  "UDIA 'ACTIVATED' UNIVERSAL DIGITAL AND INTERNET AUTHORITY",
  "GAA 'ACTIVATED' GLOBAL AI AUTHORITY",
  "TUIDL 'ACTIVATED' THIMOTHISM UNIVERSAL INTERNATIONAL DRIVING LICENSE",
  "TUP 'ACTIVATED' THIMOTHISM UNIVERSAL PASSPORT",
  "TUIC 'ACTIVATED' THIMOTHISM UNIVERSAL IDENTIFICATION CARD",
  "TUTE AI 'ACTIVATED' THIMOTHISM UNIVERSAL THOUGHT ENGINE",
  "BBS 'ACTIVATED' BARRIER BREAKER SYSTEM",
  "TUVP AI 'ACTIVATED' THIMOTHISM UNIVERSAL VERIFICATION PROTECTOR",
  "GAISN 'ACTIVATED' GLOBAL AI SOVEREIGN NEXUS",
  "CGT 'ACTIVATED' CLEAN GENUINE TECHNOLOGIES",
  "CWP 'ACTIVATED' CLEAN WORLD PROJECT",
  "LANKA PAY 'INSTANT SETTLEMENT' SRI LANKA",
  "TUGS 'ACTIVATED' TU5G GATEWAY SYSTEM (+984)",
  "HAG 'ACTIVATED' HOPE AI GSM 5G VIRTUAL SIM",
  "TACCNES AI 'ACTIVATED' CLOUD CELLULAR ENGINE",
  "REAL BALANCE PROTOCOL 'PRODUCTION READY'"
];

export const BANK_REGISTRY = {
  SRI_LANKA: [
    "Bank of Ceylon (BOC)", "People's Bank", "Commercial Bank", "Hatton National Bank (HNB)", 
    "Sampath Bank", "Seylan Bank", "Nations Trust Bank (NTB)", "DFCC Bank", "Pan Asia Bank", 
    "Union Bank", "Amana Bank", "Cargills Bank"
  ],
  INDIA: [
    "State Bank of India (SBI)", "HDFC Bank", "ICICI Bank", "Axis Bank", 
    "Punjab National Bank (PNB)", "Canara Bank", "Bank of Baroda", "Union Bank of India"
  ],
  MALAYSIA: [
    "Maybank", "CIMB Bank", "Public Bank Berhad", "RHB Bank", "Hong Leong Bank", "AmBank"
  ],
  NIGERIA: [
    "Access Bank", "Zenith Bank", "First Bank of Nigeria", "United Bank for Africa (UBA)", 
    "Guaranty Trust Bank (GTB)", "Stanbic IBTC"
  ],
  THAILAND: [
    "Bangkok Bank", "Kasikornbank (KBank)", "Siam Commercial Bank (SCB)", 
    "Krung Thai Bank", "TMBThanachart Bank (ttb)"
  ]
};

export const SERVICE_CATEGORIES: ServiceCategory[] = [
  {
    id: 'digital-assets',
    title: 'Digital Assets & Audit',
    icon: '🪙',
    subServices: [
      'CCTU Crypto Currency',
      'CCTU Audit Protocol v1.0',
      'TMC ThimoCoin Asset',
      'TC Thimothism Coin Asset',
      'GAIC Global AI Coin'
    ]
  },
  {
    id: 'sovereign-finance',
    title: 'Treasury & Trust',
    icon: '⚖️',
    subServices: [
      'TUT Universal Treasury Vault',
      'TUTB Universal Truest Bank',
      'Lumina (LU) Liquidity Pool',
      'Sovereign Reserve Management',
      'TUTB High-Tier Settlement'
    ]
  },
  {
    id: 'web-sovereignty',
    title: 'Web Sovereignty',
    icon: '🕸️',
    subServices: [
      'Hope AI Domain Registration',
      'Hope AI Hosting v1.0',
      'UDIA Certified SSL/TLS',
      'Decentralized DNS Routing',
      'Hosting Production Ready'
    ]
  },
  {
    id: 'hacb-banking',
    title: 'AI Cloud Bank (HACB)',
    icon: '🏦',
    subServices: [
      'Multi-Bank Single CDM Integration',
      'Hope Pay ATM Cloud Nexus',
      'International Settlement Bridge',
      'Mini Cash Point Authorization',
      'HACB v1.0 Production Vault'
    ]
  }
];

export const STATS: FeaturedStat[] = [
  { label: 'Asset Audit', value: 'CCTU VERIFIED', icon: '🔍' },
  { label: 'ThimoCoin', value: 'TMC ACTIVE', icon: '💎' },
  { label: 'AI Coin', value: 'GAIC ACTIVE', icon: '🤖' },
  { label: 'Treasury', value: 'TUT ACTIVATED', icon: '🏛️' }
];
