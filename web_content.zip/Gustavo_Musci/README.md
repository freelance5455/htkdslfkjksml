# Gustavo Musci

App simples de música offline.

Recursos:
- Reproduzir arquivos de música salvos no aparelho.
- Importar músicas pelo seletor de arquivos.
- Playlist local.
- Nome do app: Gustavo Musci.

Observação:
O app não inclui um sistema para baixar músicas protegidas por direitos autorais sem autorização. Ele pode ser adaptado para baixar arquivos de fontes que permitam oficialmente o download.
