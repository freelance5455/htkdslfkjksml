#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")"
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle n'est pas installé. Lance : pkg install openjdk-17 gradle unzip"
  exit 1
fi
if [ ! -f local.properties ]; then
  echo "local.properties est absent. Indique le chemin de ton Android SDK."
  echo "Exemple : echo 'sdk.dir=$HOME/android-sdk' > local.properties"
  exit 1
fi
gradle assembleDebug
printf '\nAPK généré : %s\n' "$PWD/app/build/outputs/apk/debug/app-debug.apk"
