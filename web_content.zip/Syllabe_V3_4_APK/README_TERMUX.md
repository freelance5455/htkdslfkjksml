# Syllabe V3.4 — APK Android

Cette version transforme l'interface HTML/CSS/JS de Syllabe V3.3 en application Android native contenant une WebView locale. `server.py` n'est plus nécessaire dans l'APK.

## Prérequis Termux

Installer Java et Gradle :

```bash
pkg update
pkg install openjdk-17 gradle unzip
```

Un Android SDK avec `platforms;android-35` et `build-tools` doit également être disponible. Le chemin SDK doit être défini dans `local.properties`, par exemple :

```properties
sdk.dir=/chemin/vers/android-sdk
```

## Compilation

Depuis le dossier du projet :

```bash
gradle assembleDebug
```

APK :

```text
app/build/outputs/apk/debug/app-debug.apk
```

Installation sur le téléphone :

```bash
pkg install android-tools
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Ou copie simplement l'APK dans le stockage et ouvre-le avec le gestionnaire de fichiers Android.

## Fonctionnement

- Interface V3.3 embarquée dans `app/src/main/assets/www/`.
- Comptes utilisateurs et progression conservés via `localStorage` de la WebView.
- Aucun serveur Python nécessaire pour l'APK.
- Aucun accès Internet requis par l'application.
- Nom d'application : Syllabe.
- Version : 3.4.
