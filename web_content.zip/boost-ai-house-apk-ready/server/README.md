# Boost Ai House API

Node.js API for Boost Ai House: email/password registration and login (bcrypt hash), SMS verification through Twilio Verify, optional Google/Telegram OAuth, JWT sessions, SQLite user accounts and settings.

## Run
1. Install Node.js 20+.
2. `cd server && npm install`
3. Copy `.env.example` to `.env`.
4. Set a random `JWT_SECRET` of at least 32 characters.
5. Configure provider credentials and `npm start`.

Health endpoint: `GET /api/health`. Email registration: `POST /api/auth/register` with `{ "name": "User", "email": "user@example.com", "password": "at-least-10-chars" }`. Email login: `POST /api/auth/login` with `{ "email": "user@example.com", "password": "..." }`.

## Providers
- Google: create a Web OAuth client in Google Cloud Console and set `GOOGLE_CLIENT_ID`. The frontend must obtain an ID token and POST `{ "idToken": "..." }` to `/api/auth/google`.
- Telegram: create a bot using @BotFather, set `TELEGRAM_BOT_TOKEN`, configure the Login Widget and domain, and POST the signed Telegram payload to `/api/auth/telegram`.
- SMS: configure Twilio Verify and set `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_VERIFY_SERVICE_SID`. POST `{ "phone": "+77001234567" }` to `/api/auth/phone/start`, then `{ "phone": "...", "code": "..." }` to `/api/auth/phone/verify`.

Authenticated endpoints use `Authorization: Bearer <token>`: `GET /api/me`, `GET /api/settings`, `PUT /api/settings` with `{ "settings": { "theme":"dark", "liquidGlass":true } }`.

Before production use HTTPS, secrets manager, strict CORS, backups, monitoring, fraud controls, account deletion and security review. Provider accounts and credentials are not created by this project. Accounts are not automatically merged. Email/password accounts are created on the server; configure HTTPS, backups and email verification before public production launch. The website uses a same-origin `/api` base by default; set `API_BASE_URL` in `index.html` if the API is on another origin and configure CORS accordingly.
