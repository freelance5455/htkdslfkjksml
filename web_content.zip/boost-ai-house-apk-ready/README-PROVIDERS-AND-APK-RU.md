# Boost Ai House — подключение регистрации и APK

## Что уже подготовлено в исходниках
- Регистрация по email + пароль и вход через API `/api/auth/register` и `/api/auth/login`.
- Подтверждение номера по SMS через Twilio Verify (`/api/auth/phone/start`, `/api/auth/phone/verify`).
- Проверка Google ID token на сервере (`GOOGLE_CLIENT_ID`).
- Кнопки OAuth для GitHub, VK ID, Яндекс ID, MAX и Facebook оставлены в интерфейсе, но их серверные маршруты нужно реализовать и включить после получения OAuth credentials. Они не считаются рабочими, пока провайдер не настроен.
- Кнопка «Telegram / номер телефона» ведёт на форму SMS, не на Telegram-канал.
- Android WebView исходник и GitHub Actions workflow для сборки debug APK.

## Обязательные условия для настоящей регистрации
1. Разместить сайт и API на публичном HTTPS-домене.
2. Задать `FRONTEND_ORIGIN` и случайный `JWT_SECRET` длиной не менее 32 символов.
3. Для SMS создать Twilio Verify service и задать `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_VERIFY_SERVICE_SID`.
4. Для Google создать OAuth client ID и задать `GOOGLE_CLIENT_ID`.
5. Для каждого другого провайдера создать приложение в его кабинете, указать точный HTTPS callback URL и хранить client secret только на сервере. Реализовать серверную проверку `state`/PKCE и callback. Не запрашивать пароль от сторонних сервисов в форме Boost Ai House.
6. Перед публичным запуском добавить подтверждение email, восстановление пароля, политику конфиденциальности, условия использования, резервные копии БД и мониторинг.

## Сборка APK
Сборка APK не может быть завершена только изменением HTML. Нужен Android SDK/Gradle (локально или в GitHub Actions) и публичный HTTPS URL сайта. В репозитории GitHub добавьте repository variable `SITE_URL`, запустите workflow `Build Android APK`, скачайте артефакт `boost-ai-house-debug-apk` из вкладки Actions. Это debug APK для тестирования, не релизная подписанная сборка Google Play.

## Прямая ссылка для скачивания
После сборки загрузите APK на ваш HTTPS-хостинг или в GitHub Release. Затем замените `APK_DOWNLOAD_URL` в `index.html` на **прямой URL файла `.apk`**. Пока URL не заменён и файл не загружен, кнопка намеренно не выдаёт фиктивную ссылку.

## Google Play
Для публикации нужна учётная запись Google Play Console, проверка разработчика и подписанный Android App Bundle (`.aab`). Google Play не принимает debug APK как готовый релиз. Создание учётной записи и отправку приложения должен выполнить владелец аккаунта.
