# Boost Ai House — регистрация и Android-проект

## Что изменено
- Добавлена регистрация email + пароль и вход в аккаунт через API.
- Пароль хранится на сервере только в виде bcrypt-хеша.
- Добавлен процесс подтверждения номера телефона: запрос SMS-кода и проверка кода через Twilio Verify.
- Кнопка Telegram в авторизации не ведёт в Telegram-канал. Для регистрации по телефону используется SMS.
- Сессия хранится в браузере как JWT; API защищает пользовательские настройки.
- В комплект включён исходный Android WebView-проект.

## Что необходимо для реальной работы онлайн
1. Нужен HTTPS-хостинг для сайта и Node.js API. Открой `server/`, выполни `npm install`, скопируй `.env.example` в `.env` и задай случайный `JWT_SECRET` длиной не менее 32 символов.
2. В `server/.env` настрой `FRONTEND_ORIGIN` и значения Twilio: `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_VERIFY_SERVICE_SID`. Без этих учётных данных настоящий SMS отправить невозможно.
3. Запусти `npm start`. Для сайта и API на разных доменах укажи `API_BASE_URL` внизу `index.html` и добавь домен сайта в `FRONTEND_ORIGIN`.
4. Перед публичным запуском добавь подтверждение email, политику конфиденциальности, удаление аккаунта, резервные копии и мониторинг злоупотреблений. Не используй SQLite на эфемерном хостинге без постоянного диска.

## Сборка APK
В этой среде нет установленного Android SDK/Gradle, поэтому готовый APK здесь не собран. В папке `android-app/` находится исходный проект. После публикации сайта замени `SITE_URL` в `android-app/gradle.properties` на публичный HTTPS URL сайта. Затем открой папку `android-app` в Android Studio, синхронизируй Gradle и собери `Build > Build Bundle(s) / APK(s) > Build APK(s)`. Для распространения собери подписанный APK через `Build > Generate Signed Bundle / APK` и размести APK на HTTPS-хостинге; после этого укажи прямую ссылку в `APK_DOWNLOAD_URL` в `index.html`.

## API
- `GET /api/health`
- `POST /api/auth/register` `{ "name": "User", "email": "user@example.com", "password": "minimum-10-chars" }`
- `POST /api/auth/login` `{ "email": "user@example.com", "password": "..." }`
- `POST /api/auth/phone/start` `{ "phone": "+77001234567" }`
- `POST /api/auth/phone/verify` `{ "phone": "+77001234567", "code": "123456" }`
- `GET /api/me` with `Authorization: Bearer <token>`

## Ограничения
- Email/password и SMS-flow реализованы в исходниках, но станут рабочими только после развёртывания API и настройки SMS-провайдера.
- OAuth-провайдеры Google/VK/Яндекс/MAX/Facebook не включены автоматически: для каждого нужны официальные клиентские настройки и серверная проверка. Не показываем их как будто уже подключены.
- APK-файл не включён, так как без Android SDK и URL опубликованного сайта собрать и проверить установочный пакет нельзя.
