# Boost Ai House — APK и Google Play

## Важно
- В этой папке есть исходный Android-проект и GitHub Actions workflow для сборки APK в облаке.
- Сам APK не приложен: локально в среде нет Android SDK/Gradle, а приложение должно быть настроено на реальный публичный HTTPS URL сайта.
- OAuth-кнопки показывают варианты входа, но каждый провайдер должен быть подключён к серверу с официальными Client ID/Secret и callback URL. Не запрашивайте у пользователей пароль от стороннего сервиса.
- SMS требует действующего аккаунта SMS-провайдера и настроек сервера. Telegram OAuth и SMS по телефону — отдельные способы входа.

## Сборка APK через GitHub Actions
1. Опубликуйте сайт и API на HTTPS.
2. Загрузите весь проект в свой GitHub-репозиторий.
3. В Settings → Secrets and variables → Actions → Variables добавьте `SITE_URL` с публичным HTTPS адресом сайта.
4. Откройте Actions → Build Android APK → Run workflow.
5. После успешной сборки скачайте артефакт `boost-ai-house-debug-apk`. Это debug APK для тестирования, не релизная подписанная версия.
6. Для Google Play создайте подписанный release AAB/APK в Android Studio и храните ключ подписи в безопасном месте. Не добавляйте keystore и пароли в GitHub.

## Google Play
1. Создайте/подтвердите аккаунт разработчика в Google Play Console.
2. Подготовьте название, краткое и полное описание, значок, скриншоты, URL политики конфиденциальности и сведения о сборе данных.
3. Загрузите подписанный Android App Bundle (AAB) в тестовый трек.
4. Для новых личных аккаунтов Google указывает закрытое тестирование с минимум 12 участниками, непрерывно подключёнными 14 дней, перед запросом доступа к production. Требования смотрите в своей Play Console.
5. Отправьте приложение на проверку. Публикация не автоматическая и зависит от решения Google.

## Официальные страницы
- Play Console: https://play.google.com/console/about/
- Создание аккаунта разработчика: https://support.google.com/googleplay/android-developer/answer/6112435
- Тестирование новых личных аккаунтов: https://support.google.com/googleplay/android-developer/answer/14151465
