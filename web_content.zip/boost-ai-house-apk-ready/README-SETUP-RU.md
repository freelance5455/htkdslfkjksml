# Boost Ai House — сервер и Android-проект

Подготовлены исходники серверной части и Android WebView-оболочка. Реальные провайдеры не подключены без ваших учётных данных; приложение пока не собрано в APK, потому что в среде сборки нет Android SDK и ключа подписи.

## Сервер
Требуется Node.js 20+. В `server`: `npm install`, скопировать `.env.example` в `.env`, задать случайный `JWT_SECRET` длиной 32+ символов, заполнить настройки Google/Telegram/Twilio, затем `npm start`. Для публичного запуска нужен сервер и HTTPS-домен; установите правильный `FRONTEND_ORIGIN`.

- Google: Google Cloud Console → OAuth Client ID для Web.
- Telegram: создать бота через @BotFather, настроить Login Widget и домен.
- SMS: настроить Twilio Verify. SMS платные; доступность зависит от страны и аккаунта.

Не публикуйте `.env` и не отправляйте секреты в чат.

## APK
Откройте `android-app` в Android Studio с Android SDK 35. Сначала опубликуйте сайт и замените `SITE_URL` в `gradle.properties` на HTTPS-адрес. Затем выберите **Build → Build Bundle(s) / APK(s) → Build APK(s)**. Для релиза используйте **Build → Generate Signed Bundle / APK → APK** и сохраните ключ подписи безопасно.

## Перед production
Нужны HTTPS, защищённое хранилище секретов, ограничения SMS, резервные копии, мониторинг, политика конфиденциальности, удаление аккаунта и проверка безопасности. Аккаунты разных провайдеров не объединяются автоматически.
