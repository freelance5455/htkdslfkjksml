CryptoPulse V36 Pro — Web Edition

index.html را برای تست رابط باز کنید.
برای تبدیل به APK، پوشه CryptoPulse_V36_Pro_Android را استفاده کنید.
