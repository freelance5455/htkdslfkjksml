const NOM_BASE_IMAGES = "the-completionist-images";
let baseImages = null;
const urlsImages = {};

function ouvrirBase() {
  return new Promise((resolve, reject) => {
    if (baseImages) return resolve(baseImages);
    const requete = indexedDB.open(NOM_BASE_IMAGES, 1);
    requete.onupgradeneeded = () => requete.result.createObjectStore("images");
    requete.onsuccess = () => { baseImages = requete.result; resolve(baseImages); };
    requete.onerror = () => reject(requete.error);
  });
}

function estIdImage(valeur) {
  return typeof valeur === "string" && valeur.startsWith("img:");
}

function enregistrerImage(blob) {
  const id = "img:" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  return ouvrirBase().then(db => new Promise((resolve, reject) => {
    const tx = db.transaction("images", "readwrite");
    tx.objectStore("images").put(blob, id);
    tx.oncomplete = () => resolve(id);
    tx.onerror = () => reject(tx.error);
  }));
}

function lireImage(id) {
  return ouvrirBase().then(db => new Promise((resolve, reject) => {
    const requete = db.transaction("images", "readonly").objectStore("images").get(id);
    requete.onsuccess = () => resolve(requete.result);
    requete.onerror = () => reject(requete.error);
  }));
}

function supprimerImage(id) {
  if (urlsImages[id]) {
    URL.revokeObjectURL(urlsImages[id]);
    delete urlsImages[id];
  }
  return ouvrirBase().then(db => new Promise((resolve, reject) => {
    const tx = db.transaction("images", "readwrite");
    tx.objectStore("images").delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  }));
}

async function urlImage(id) {
  if (urlsImages[id]) return urlsImages[id];
  const blob = await lireImage(id);
  if (!blob) return null;
  urlsImages[id] = URL.createObjectURL(blob);
  return urlsImages[id];
}

function balisesImage(source, alt) {
  const texte = alt || "";
  if (estIdImage(source)) return `<img data-img="${source}" alt="${texte}">`;
  return `<img src="${source}" alt="${texte}">`;
}

async function resoudreImages(racine) {
  const elements = [...racine.querySelectorAll("[data-img]")];
  const restants = [];
  elements.forEach(el => {
    const connue = urlsImages[el.dataset.img];
    if (connue) el.src = connue;
    else restants.push(el);
  });
  await Promise.all(restants.map(async el => {
    const url = await urlImage(el.dataset.img);
    if (url) el.src = url;
  }));
}

function redimensionner(fichier, largeurMax, hauteurMax, qualite) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    const url = URL.createObjectURL(fichier);
    image.onload = () => {
      const ratio = Math.min(1, largeurMax / image.width, hauteurMax / image.height);
      const canevas = document.createElement("canvas");
      canevas.width = Math.max(1, Math.round(image.width * ratio));
      canevas.height = Math.max(1, Math.round(image.height * ratio));
      canevas.getContext("2d").drawImage(image, 0, 0, canevas.width, canevas.height);
      URL.revokeObjectURL(url);
      canevas.toBlob(blob => blob ? resolve(blob) : reject(new Error("conversion")),
        "image/webp", qualite);
    };
    image.onerror = () => { URL.revokeObjectURL(url); reject(new Error("lecture")); };
    image.src = url;
  });
}