import { getStore } from "@netlify/blobs";
import { randomUUID } from "crypto";

const MAX_FILE_SIZE = 1024 * 1024 * 1024; // 1 GB

function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: { "Content-Type": "application/json" } });
}

export default async (req, context) => {
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  try {
    const form = await req.formData();
    const action = String(form.get("action") || "legacy");
    const store = getStore("videos");

    if (action === "init") {
      const size = Number(form.get("fileSize") || 0);
      if (!Number.isFinite(size) || size <= 0 || size > MAX_FILE_SIZE) return json({ error: "File must be between 1 byte and 1 GB." }, 413);
      const id = randomUUID();
      await store.setJSON(id + "-manifest", {
        id,
        title: String(form.get("title") || "Shared Media"),
        description: String(form.get("description") || ""),
        username: String(form.get("username") || "anonymous"),
        mediaType: String(form.get("mediaType") || "video"),
        type: String(form.get("type") || "long"),
        fileName: String(form.get("fileName") || "media"),
        contentType: String(form.get("contentType") || "application/octet-stream"),
        size,
        totalChunks: Math.ceil(size / (3.5 * 1024 * 1024)),
        createdAt: new Date().toISOString()
      });
      return json({ success: true, id });
    }

    if (action === "chunk") {
      const id = String(form.get("id") || "");
      const index = Number(form.get("chunkIndex"));
      const chunk = form.get("chunk");
      if (!id || !Number.isInteger(index) || index < 0 || !(chunk instanceof File)) return json({ error: "Invalid chunk" }, 400);
      if (chunk.size > 4 * 1024 * 1024) return json({ error: "Chunk too large" }, 413);
      await store.set(`${id}-chunk-${index}`, chunk, { metadata: { contentType: chunk.type || "application/octet-stream", size: chunk.size } });
      return json({ success: true, index });
    }

    if (action === "finish") {
      const id = String(form.get("id") || "");
      const totalChunks = Number(form.get("totalChunks"));
      const size = Number(form.get("fileSize") || 0);
      if (!id || !Number.isInteger(totalChunks) || totalChunks < 1 || !Number.isFinite(size) || size <= 0 || size > MAX_FILE_SIZE) return json({ error: "Invalid upload" }, 400);

      const manifest = await store.get(id + "-manifest", { type: "json" });
      if (!manifest) return json({ error: "Upload session not found" }, 404);
      manifest.totalChunks = totalChunks;
      manifest.size = size;
      manifest.title = String(form.get("title") || manifest.title || "Shared Media");
      manifest.description = String(form.get("description") || manifest.description || "");
      manifest.username = String(form.get("username") || manifest.username || "anonymous");
      manifest.mediaType = String(form.get("mediaType") || manifest.mediaType || "video");
      manifest.type = String(form.get("type") || manifest.type || "long");
      manifest.fileName = String(form.get("fileName") || manifest.fileName || "media");
      manifest.contentType = String(form.get("contentType") || manifest.contentType || "application/octet-stream");

      const thumbnail = form.get("thumbnail");
      let thumbnailUrl = null;
      if (thumbnail && thumbnail instanceof File && thumbnail.size <= 2 * 1024 * 1024) {
        await store.set(id + "-thumb", thumbnail, { metadata: { contentType: thumbnail.type || "image/jpeg" } });
        const siteUrl = context.site?.url || "";
        thumbnailUrl = `${siteUrl}/.netlify/functions/get-video?id=${id}&thumb=1`;
      }
      manifest.thumbnailUrl = thumbnailUrl;
      await store.setJSON(id + "-manifest", manifest);

      const metaStore = getStore("video-meta");
      let list = [];
      try {
        const existing = await metaStore.get("public-list", { type: "json" });
        if (Array.isArray(existing)) list = existing;
      } catch (e) {}
      list.unshift({
        id, title: manifest.title, description: manifest.description, username: manifest.username,
        mediaType: manifest.mediaType, type: manifest.type, thumbnailUrl,
        createdAt: manifest.createdAt, size, likes: 0, comments: [], saves: 0, reposts: 0, likedBy: [], savedBy: []
      });
      list = list.slice(0, 100);
      await metaStore.setJSON("public-list", list);

      const siteUrl = context.site?.url || "";
      return json({ success: true, id, shareUrl: `${siteUrl}/.netlify/functions/get-video?id=${id}`, thumbnailUrl, title: manifest.title, mediaType: manifest.mediaType, type: manifest.type });
    }

    // Backward-compatible small-file upload.
    const file = form.get("file");
    if (!(file instanceof File)) return json({ error: "No media file provided" }, 400);
    if (file.size > 4 * 1024 * 1024) return json({ error: "Large files must use chunked upload." }, 413);
    const id = randomUUID();
    const title = String(form.get("title") || "Shared Media");
    const description = String(form.get("description") || "");
    const username = String(form.get("username") || "anonymous");
    const mediaType = String(form.get("mediaType") || (String(file.type || "").startsWith("image/") ? "image" : "video"));
    const type = String(form.get("type") || "long");
    await store.set(`${id}-chunk-0`, file, { metadata: { contentType: file.type || "application/octet-stream", size: file.size } });
    const manifest = { id, title, description, username, mediaType, type, fileName: file.name || "media", contentType: file.type || "application/octet-stream", size: file.size, totalChunks: 1, createdAt: new Date().toISOString(), thumbnailUrl: null };
    await store.setJSON(id + "-manifest", manifest);
    const metaStore = getStore("video-meta");
    let list = [];
    try { const existing = await metaStore.get("public-list", { type: "json" }); if (Array.isArray(existing)) list = existing; } catch (e) {}
    list.unshift({ id, title, description, username, mediaType, type, thumbnailUrl: null, createdAt: manifest.createdAt, size: file.size, likes: 0, comments: [], saves: 0, reposts: 0, likedBy: [], savedBy: [] });
    await metaStore.setJSON("public-list", list.slice(0, 100));
    const siteUrl = context.site?.url || "";
    return json({ success: true, id, shareUrl: `${siteUrl}/.netlify/functions/get-video?id=${id}`, thumbnailUrl: null, title, mediaType, type });
  } catch (err) {
    console.error(err);
    return json({ error: "Upload failed", details: err.message }, 500);
  }
};
