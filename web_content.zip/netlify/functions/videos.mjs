export default async (request) => {
  const apiKey = process.env.DOODSTREAM_API_KEY || process.env.VIDEO_API_KEY;
  if (!apiKey) {
    return Response.json(
      { error: "DOODSTREAM_API_KEY yoki VIDEO_API_KEY Netlify environment variable sifatida kiritilmagan." },
      { status: 500, headers: { "Cache-Control": "no-store" } }
    );
  }

  const url = new URL(request.url);
  const rawPage = Number.parseInt(url.searchParams.get("page") || "1", 10);
  const page = Number.isFinite(rawPage) ? Math.min(10000, Math.max(1, rawPage)) : 1;

  try {
    const apiUrl = new URL("https://doodapi.co/api/file/list");
    apiUrl.searchParams.set("key", apiKey);
    apiUrl.searchParams.set("page", String(page));
    apiUrl.searchParams.set("per_page", "40");

    const upstream = await fetch(apiUrl, {
      method: "GET",
      headers: { "Accept": "application/json" }
    });
    const body = await upstream.json();

    if (!upstream.ok || (body.status && Number(body.status) >= 400)) {
      return Response.json(
        { error: "DoodStream API xato qaytardi. API kalitini va hisob holatini tekshiring." },
        { status: 502, headers: { "Cache-Control": "no-store" } }
      );
    }

    try {
      const { getStore } = await import("@netlify/blobs");
      const blobStore = getStore("xhouse-admin-data");
      const hiddenRaw = await blobStore.get("hidden-dood-files.json");
      const statsRaw = await blobStore.get("external-metrics.json");
      const hidden = new Set(JSON.parse(hiddenRaw || "[]"));
      const stats = JSON.parse(statsRaw || "{}");
      const result = body.result || {};
      const files = Array.isArray(result.files) ? result.files : (Array.isArray(result) ? result : []);
      result.files = files.filter(f => !hidden.has(`dood:${String(f.file_code || f.filecode || f.file_id || '')}`)).map(f => {
        const id = `dood:${String(f.file_code || f.filecode || f.file_id || '')}`;
        const m = stats[id] || {};
        // These are Xhouse-site interactions, not the hosting provider's separate counter.
        return { ...f, views: Number(m.views || 0), likes: Number(m.likes || 0), dislikes: Number(m.dislikes || 0), __xhouseMetricId: id };
      });
      body.result = result;
    } catch {}

    return Response.json(body, {
      status: 200,
      headers: {
        "Cache-Control": "public, max-age=60, s-maxage=60",
        "Access-Control-Allow-Origin": "*"
      }
    });
  } catch {
    return Response.json(
      { error: "DoodStream API bilan bog‘lanib bo‘lmadi." },
      { status: 502, headers: { "Cache-Control": "no-store" } }
    );
  }
};
