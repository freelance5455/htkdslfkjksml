const https = require("https");

function fetchFirebaseConfig() {
  return new Promise((resolve) => {
    const url = "https://pay4smart-default-rtdb.firebaseio.com/app_settings.json";
    https.get(url, (res) => {
      let data = "";
      res.on("data", (chunk) => (data += chunk));
      res.on("end", () => {
        try {
          resolve(JSON.parse(data) || {});
        } catch (e) {
          resolve({});
        }
      });
    }).on("error", () => resolve({}));
  });
}

exports.handler = async (event) => {
  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };

  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }

  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "Method Not Allowed" })
    };
  }

  try {
    const data = JSON.parse(event.body || "{}");
    const { phone, otp } = data;

    if (!phone || !otp) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "Phone number and OTP are required" })
      };
    }

    const firebaseSettings = await fetchFirebaseConfig();
    const smsBaseUrl = firebaseSettings.sms_api_url || "https://sms.renflair.in/V1.php";
    const apiToken = firebaseSettings.sms_api_token || "d7fd7e561f3eb9cf534fb16a3052f970";

    const smsUrl = `${smsBaseUrl}?API=${encodeURIComponent(apiToken)}&PHONE=${encodeURIComponent(phone)}&OTP=${encodeURIComponent(otp)}`;

    const response = await fetch(smsUrl, { method: "GET" });
    const result = await response.json();

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        status: "SUCCESS",
        gateway_response: result
      })
    };

  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Failed to send SMS",
        details: error.message
      })
    };
  }
};
