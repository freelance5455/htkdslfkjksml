import { getStore } from "@netlify/blobs";

const CHUNK_SIZE = 3.5 * 1024 * 1024;

export default async (req) => {
  const url = new URL(req.url);
  const id = url.searchParams.get("id");
  if (!id) return new Response("Missing media id", { status: 400 });

  try {
    const store = getStore("videos");
    const manifest = await store.get(id + "-manifest", { type: "json" });
    if (!manifest) return new Response("Media not found", { status: 404 });
    const totalChunks = Number(manifest.totalChunks || Math.ceil(Number(manifest.size || 0) / CHUNK_SIZE));
    const size = Number(manifest.size || 0);
    let index = 0;

    const stream = new ReadableStream({
      async pull(controller) {
        if (index >= totalChunks) {
          controller.close();
          return;
        }
        try {
          const data = await store.get(`${id}-chunk-${index}`, { type: "arrayBuffer" });
          if (!data) throw new Error("Media chunk not found");
          controller.enqueue(new Uint8Array(data));
          index += 1;
          if (index >= totalChunks) controller.close();
        } catch (e) {
          controller.error(e);
        }
      }
    });

    const safeName = String(manifest.fileName || "video.mp4").replace(/[\\"\r\n]/g, "_");
    return new Response(stream, {
      status: 200,
      headers: {
        "Content-Type": manifest.contentType || "application/octet-stream",
        "Content-Length": String(size),
        "Content-Disposition": `attachment; filename="${safeName}"`,
        "Cache-Control": "no-cache"
      }
    });
  } catch (err) {
    console.error(err);
    return new Response("Download failed", { status: 500 });
  }
};
