const https = require("https");

function fetchFirebaseConfig() {
  return new Promise((resolve) => {
    const url = "https://pay4smart-default-rtdb.firebaseio.com/app_settings.json";
    https.get(url, (res) => {
      let data = "";
      res.on("data", (chunk) => (data += chunk));
      res.on("end", () => {
        try {
          resolve(JSON.parse(data) || {});
        } catch (e) {
          resolve({});
        }
      });
    }).on("error", () => resolve({}));
  });
}

exports.handler = async (event) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json"
  };

  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "OK" };
  }

  if (event.httpMethod !== "POST") {
    return { 
      statusCode: 405, 
      headers, 
      body: JSON.stringify({ error: "Method Not Allowed" }) 
    };
  }

  try {
    const { amount, phone, name } = JSON.parse(event.body || "{}");

    if (!amount || isNaN(amount) || parseFloat(amount) <= 0) {
      return { 
        statusCode: 400, 
        headers, 
        body: JSON.stringify({ status: false, message: "সঠিক টাকার পরিমাণ দিন" }) 
      };
    }

    const firebaseSettings = await fetchFirebaseConfig();

    const GATEWAY_URL = firebaseSettings.gateway_api_url || "https://pay.dghost.in/api/create-order";
    const USER_TOKEN = firebaseSettings.dghost_user_token || "bf16ca864f7a41e0e9fa5b11ba080f48";
    const REDIRECT_URL = firebaseSettings.dghost_redirect_url || "https://pay4smart.netlify.app";

    const orderId = "DEP" + Date.now();

    const params = new URLSearchParams({
      user_token: USER_TOKEN,
      order_id: orderId,
      amount: parseFloat(amount),
      customer_mobile: phone || "8207200380",
      customer_name: name || "User",
      redirect_url: REDIRECT_URL
    });

    const response = await fetch(GATEWAY_URL, {
      method: "POST",
      headers: { 
        "Content-Type": "application/x-www-form-urlencoded" 
      },
      body: params.toString()
    });

    const resData = await response.json();

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(resData)
    };
  } catch (err) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ status: false, error: err.message })
    };
  }
};
