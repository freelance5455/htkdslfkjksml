import { Readable } from 'node:stream';
import crypto from 'node:crypto';
import backend from '../../backend/server.cjs';

// API credentials come from host environment variables, never from the download.
function cookieValue(request,name){return(request.headers.get('cookie')||'').split(';').map(s=>s.trim()).find(s=>s.startsWith(name+'='))?.slice(name.length+1)}
function signingKey(){return crypto.createHash('sha256').update((process.env.STUDIO_ACCESS_CODE||'')+'|'+(process.env.OPENROUTER_API_KEY||process.env.OPENAI_API_KEY||'')).digest()}
function sign(payload){return crypto.createHmac('sha256',signingKey()).update(payload).digest('base64url')}
function unlocked(request){let c=cookieValue(request,'th_access');if(!c)return false;let [expiry,mac]=c.split('.');let expected=sign(expiry||'');return Number(expiry)>Date.now()&&mac?.length===expected.length&&crypto.timingSafeEqual(Buffer.from(mac),Buffer.from(expected))}
const json=(obj,status=200,extra={})=>new Response(JSON.stringify(obj),{status,headers:{'Content-Type':'application/json','Cache-Control':'no-store',...extra}});

export default async function(request){
 let pathname=new URL(request.url).pathname;
 if(pathname.startsWith('/.netlify/functions/ai/'))pathname='/api/ai/'+pathname.slice('/.netlify/functions/ai/'.length);
 if(pathname==='/.netlify/functions/ai')pathname='/api/ai/status';
 const code=process.env.STUDIO_ACCESS_CODE;
 if(!code||code.length<16)return json({connected:false,setupRequired:true,error:'Set STUDIO_ACCESS_CODE (at least 16 characters) and your provider API key in Netlify environment variables, then redeploy.'},503);
 if(pathname==='/api/ai/unlock'){
  if(request.method!=='POST'||request.headers.get('x-th-studio')!=='1')return json({error:'Invalid request'},403);
  let body;try{body=await request.json()}catch{return json({error:'Invalid request'},400)}
  let input=typeof body.code==='string'?body.code:'';
  if(input.length!==code.length||!crypto.timingSafeEqual(Buffer.from(input),Buffer.from(code)))return json({error:'Access code did not match.'},401);
  let expiry=String(Date.now()+7200000),token=expiry+'.'+sign(expiry);
  return json({unlocked:true},200,{'Set-Cookie':`th_access=${token}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=7200`});
 }
 if(!unlocked(request))return json({connected:false,locked:true,error:'Unlock your studio with its access code.'},pathname.endsWith('/status')?200:401);
 if(!pathname.startsWith('/api/ai/'))return json({error:'Not found'},404);
 const buffer=Buffer.from(await request.arrayBuffer());if(buffer.length>1800000)return json({error:'Request too large'},413);
 let req=Readable.from(buffer.length?[buffer]:[]);req.url=pathname;req.method=request.method;req.headers=Object.fromEntries(request.headers);
 return await new Promise(resolve=>{
  let status=200,headers={},parts=[];
  const res={setHeader(k,v){headers[k]=v},writeHead(n,h={}){status=n;Object.assign(headers,h)},end(data){if(data)parts.push(Buffer.isBuffer(data)?data:Buffer.from(String(data)));resolve(new Response(Buffer.concat(parts),{status,headers}))}};
  Promise.resolve(backend.handleRequest(req,res)).catch(()=>resolve(json({error:'AI service request failed. No changes were applied.'},500)));
 });
}
