import { GoogleGenAI } from "@google/genai";

const json = (data, status=200) =>
  new Response(JSON.stringify(data), {status, headers: {"content-type":"application/json"}});

export default async (req) => {
  if (req.method !== "POST") return json({error:"POST only"},405);
  try {
    const {type="chat", prompt="", imageData} = await req.json();
    if (!prompt.trim()) return json({error:"Prompt required"},400);

    const key = process.env.GEMINI_API_KEY;
    if (!key) return json({error:"GEMINI_API_KEY is not configured in Netlify."},500);

    const ai = new GoogleGenAI({apiKey:key});

    if (type === "chat") {
      const contents = imageData
        ? [{inlineData:{mimeType:imageData.match(/^data:(.*?);base64,/)?.[1] || "image/jpeg",
                        data:imageData.replace(/^data:.*?;base64,/,"")}},
           {text:prompt}]
        : prompt;
      const r = await ai.models.generateContent({
        model: process.env.GEMINI_TEXT_MODEL || "gemini-2.5-flash",
        contents
      });
      return json({text:r.text || ""});
    }

    if (type === "image") {
      const model = process.env.GEMINI_IMAGE_MODEL;
      if (!model) return json({error:"Set GEMINI_IMAGE_MODEL to an image-capable Gemini model available to your account."},501);
      const r = await ai.models.generateContent({
        model,
        contents: prompt,
        config: {responseModalities:["TEXT","IMAGE"]}
      });
      const parts = r.candidates?.[0]?.content?.parts || [];
      const img = parts.find(p => p.inlineData);
      if (!img) return json({error:"The image model returned no image."},502);
      return json({imageUrl:`data:${img.inlineData.mimeType};base64,${img.inlineData.data}`});
    }

    if (type === "video") {
      const model = process.env.GEMINI_VIDEO_MODEL || "veo-3.1-fast-generate-preview";
      const operation = await ai.models.generateVideos({
        model,
        prompt,
        config: {numberOfVideos: 1}
      });
      return json({videoJob: operation.name || String(operation), message:"Video generation started asynchronously. Poll the operation server-side before exposing the final media URL."});
    }

    return json({error:"Unknown AI type"},400);
  } catch (e) {
    return json({error:e?.message || "AI request failed"},500);
  }
};
