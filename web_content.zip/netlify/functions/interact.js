import { getStore } from "@netlify/blobs";

export default async (req) => {
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405, headers: { "Content-Type": "application/json" },
    });
  }
  try {
    const body = await req.json();
    const { action, id, username, text } = body;
    if (!id || !action) {
      return new Response(JSON.stringify({ error: "Missing id or action" }), {
        status: 400, headers: { "Content-Type": "application/json" },
      });
    }
    const metaStore = getStore("video-meta");
    let list = [];
    try {
      const existing = await metaStore.get("public-list", { type: "json" });
      if (Array.isArray(existing)) list = existing;
    } catch (e) {}

    let idx = list.findIndex(v => v.id === id);
    if (idx === -1) {
      // create a stub entry if video exists but not in list
      list.unshift({ id, title: "Video", username: username || "user", createdAt: new Date().toISOString(), likes: 0, comments: [], saves: 0, reposts: 0, likedBy: [], savedBy: [] });
      idx = 0;
    }
    const v = list[idx];
    v.likes = v.likes || 0;
    v.comments = Array.isArray(v.comments) ? v.comments : [];
    v.saves = v.saves || 0;
    v.reposts = v.reposts || 0;
    v.likedBy = Array.isArray(v.likedBy) ? v.likedBy : [];
    v.savedBy = Array.isArray(v.savedBy) ? v.savedBy : [];

    let result = {};
    if (action === "like") {
      if (username && !v.likedBy.includes(username)) {
        v.likedBy.push(username);
        v.likes += 1;
      }
      result = { likes: v.likes, liked: true };
    } else if (action === "unlike") {
      if (username) {
        v.likedBy = v.likedBy.filter(u => u !== username);
        v.likes = Math.max(0, v.likes - 1);
      }
      result = { likes: v.likes, liked: false };
    } else if (action === "comment") {
      if (text && String(text).trim()) {
        v.comments.push({ user: username || "anon", text: String(text).trim(), at: new Date().toISOString() });
      }
      result = { comments: v.comments, count: v.comments.length };
    } else if (action === "save") {
      if (username && !v.savedBy.includes(username)) {
        v.savedBy.push(username);
        v.saves += 1;
      }
      result = { saves: v.saves, saved: true };
    } else if (action === "unsave") {
      if (username) {
        v.savedBy = v.savedBy.filter(u => u !== username);
        v.saves = Math.max(0, v.saves - 1);
      }
      result = { saves: v.saves, saved: false };
    } else if (action === "repost") {
      v.reposts += 1;
      result = { reposts: v.reposts };
    } else {
      return new Response(JSON.stringify({ error: "Unknown action" }), {
        status: 400, headers: { "Content-Type": "application/json" },
      });
    }

    list[idx] = v;
    await metaStore.setJSON("public-list", list);
    return new Response(JSON.stringify({ success: true, ...result }), {
      status: 200, headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error(err);
    return new Response(JSON.stringify({ error: "Interact failed", details: err.message }), {
      status: 500, headers: { "Content-Type": "application/json" },
    });
  }
};
