import { getStore } from "@netlify/blobs";

const headers = { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" };
const clean = (u) => String(u || "").trim().toLowerCase().replace(/\s+/g, "_");

async function readAccount(store, u) {
  const a = await store.get(u, { type: "json" });
  if (!a) throw new Error("Account not found");
  a.followersList = Array.isArray(a.followersList) ? a.followersList : [];
  a.followingList = Array.isArray(a.followingList) ? a.followingList : [];
  a.followers = a.followersList.length;
  a.following = a.followingList.length;
  return a;
}

function safe(a) {
  const { passHash, password, ...out } = a;
  return out;
}

export default async (req) => {
  if (req.method === "OPTIONS") return new Response("", { status: 204, headers });
  try {
    const body = req.method === "POST" ? await req.json() : {};
    const url = new URL(req.url);
    const action = body.action || url.searchParams.get("action") || "state";
    const meUser = clean(body.me || url.searchParams.get("me"));
    const targetUser = clean(body.target || url.searchParams.get("target"));
    if (!meUser) return new Response(JSON.stringify({ error: "Missing user" }), { status: 400, headers });

    const store = getStore("accounts");
    const me = await readAccount(store, meUser);

    if (action === "state") {
      const friends = me.followingList.filter(u => me.followersList.includes(u));
      return new Response(JSON.stringify({ success:true, following:me.followingList, followers:me.followersList, friends }), { status:200, headers });
    }

    if (!targetUser || targetUser === meUser) return new Response(JSON.stringify({ error:"Invalid target" }), { status:400, headers });
    const target = await readAccount(store, targetUser);

    if (action === "follow") {
      if (!me.followingList.includes(targetUser)) me.followingList.push(targetUser);
      if (!target.followersList.includes(meUser)) target.followersList.push(meUser);
    } else if (action === "unfollow") {
      me.followingList = me.followingList.filter(u => u !== targetUser);
      target.followersList = target.followersList.filter(u => u !== meUser);
    } else {
      return new Response(JSON.stringify({ error:"Unknown action" }), { status:400, headers });
    }

    me.followers = me.followersList.length;
    me.following = me.followingList.length;
    target.followers = target.followersList.length;
    target.following = target.followingList.length;
    await store.setJSON(meUser, me);
    await store.setJSON(targetUser, target);
    const friends = me.followingList.filter(u => me.followersList.includes(u));
    return new Response(JSON.stringify({ success:true, following:me.followingList, followers:me.followersList, friends, targetFollowers:target.followers, targetFollowing:target.following }), { status:200, headers });
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message || "Social action failed" }), { status:500, headers });
  }
};
