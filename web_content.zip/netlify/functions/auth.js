import { getStore } from "@netlify/blobs";

function simpleHash(str) {
  // deterministic non-crypto hash for password storage (good enough for this app)
  let h = 2166136261;
  const s = "dma_v2:" + str;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  // second pass
  let h2 = 0;
  for (let i = 0; i < s.length; i++) {
    h2 = ((h2 << 5) - h2) + s.charCodeAt(i);
    h2 |= 0;
  }
  return (h >>> 0).toString(16) + (h2 >>> 0).toString(16);
}

export default async (req) => {
  // CORS preflight
  if (req.method === "OPTIONS") {
    return new Response("", {
      status: 204,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
      },
    });
  }

  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
    });
  }

  try {
    const body = await req.json();
    const { action, username, password, name, email, mobile } = body;
    const user = String(username || "").trim().toLowerCase().replace(/\s+/g, "_");
    const pass = String(password || "");

    if (!user || !pass) {
      return new Response(JSON.stringify({ error: "Username and password required" }), {
        status: 400,
        headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
      });
    }

    const store = getStore("accounts");
    const headers = { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" };

    if (action === "register") {
      const existing = await store.get(user, { type: "json" });
      if (existing) {
        return new Response(JSON.stringify({ error: "Username already taken" }), {
          status: 409, headers,
        });
      }
      const account = {
        username: user,
        name: String(name || user).trim() || user,
        email: String(email || "").trim(),
        mobile: String(mobile || "").trim(),
        passHash: simpleHash(pass),
        followers: 0,
        following: 0,
        createdAt: new Date().toISOString(),
      };
      await store.setJSON(user, account);

      const meta = getStore("account-meta");
      let list = [];
      try {
        const l = await meta.get("public-users", { type: "json" });
        if (Array.isArray(l)) list = l;
      } catch (e) {}
      list = list.filter((u) => u.username !== user);
      list.unshift({ username: user, name: account.name, createdAt: account.createdAt });
      list = list.slice(0, 200);
      await meta.setJSON("public-users", list);

      const { passHash, ...safe } = account;
      return new Response(JSON.stringify({ success: true, account: safe }), {
        status: 200, headers,
      });
    }

    if (action === "login") {
      const account = await store.get(user, { type: "json" });
      if (!account) {
        return new Response(JSON.stringify({ error: "Account not found" }), {
          status: 404, headers,
        });
      }
      if (account.passHash !== simpleHash(pass)) {
        return new Response(JSON.stringify({ error: "Wrong password" }), {
          status: 401, headers,
        });
      }
      const { passHash, ...safe } = account;
      return new Response(JSON.stringify({ success: true, account: safe }), {
        status: 200, headers,
      });
    }

    if (action === "search") {
      const q = user;
      const meta = getStore("account-meta");
      let list = [];
      try {
        const l = await meta.get("public-users", { type: "json" });
        if (Array.isArray(l)) list = l;
      } catch (e) {}
      const filtered = list
        .filter((u) => u.username.includes(q) || (u.name && u.name.toLowerCase().includes(q)))
        .slice(0, 30);
      return new Response(JSON.stringify({ success: true, users: filtered }), {
        status: 200, headers,
      });
    }

    return new Response(JSON.stringify({ error: "Unknown action" }), {
      status: 400, headers,
    });
  } catch (err) {
    console.error(err);
    return new Response(JSON.stringify({ error: err.message || "Auth failed" }), {
      status: 500,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
    });
  }
};
