import { getStore } from "@netlify/blobs";

function parseRange(range, size) {
  if (!range || !/^bytes=\d*-\d*$/.test(range)) return null;
  const raw = range.slice(6);
  const [a, b] = raw.split('-');
  let start = a === '' ? Math.max(0, size - Number(b)) : Number(a);
  let end = b === '' ? size - 1 : Number(b);
  if (!Number.isFinite(start) || !Number.isFinite(end) || start < 0 || end < start || start >= size) return null;
  end = Math.min(end, size - 1);
  return { start, end };
}

export default async (req, context) => {
  const url = new URL(req.url);
  const id = url.searchParams.get("id");
  const thumb = url.searchParams.get("thumb") === "1";
  if (!id) return new Response("Missing media id", { status: 400 });

  try {
    const store = getStore("videos");
    if (thumb) {
      const { data, metadata } = await store.getWithMetadata(id + "-thumb", { type: "stream" });
      if (!data) return new Response("Thumbnail not found", { status: 404 });
      return new Response(data, { headers: { "Content-Type": metadata?.contentType || "image/jpeg", "Cache-Control": "public, max-age=31536000" } });
    }

    const manifest = await store.get(id + "-manifest", { type: "json" });
    if (!manifest) return new Response("Media not found", { status: 404 });
    const size = Number(manifest.size || 0);
    const totalChunks = Number(manifest.totalChunks || 1);
    const CHUNK_SIZE = 3.5 * 1024 * 1024;
    const range = parseRange(req.headers.get("range"), size);
    const start = range ? range.start : 0;
    const end = range ? range.end : Math.min(size - 1, CHUNK_SIZE - 1);

    // Return a bounded response. Browsers will issue subsequent Range requests for large media.
    const firstChunk = Math.floor(start / CHUNK_SIZE);
    const lastChunk = Math.floor(end / CHUNK_SIZE);
    if (firstChunk !== lastChunk) {
      // Keep each function response below Netlify's streaming response limit.
      const safeEnd = Math.min(end, (firstChunk + 1) * CHUNK_SIZE - 1);
      const data = await store.get(`${id}-chunk-${firstChunk}`, { type: "arrayBuffer" });
      if (!data) return new Response("Media chunk not found", { status: 404 });
      const localStart = start - firstChunk * CHUNK_SIZE;
      const localEnd = safeEnd - firstChunk * CHUNK_SIZE + 1;
      const bytes = new Uint8Array(data).slice(localStart, localEnd);
      return new Response(bytes, {
        status: 206,
        headers: {
          "Content-Type": manifest.contentType || "application/octet-stream",
          "Content-Range": `bytes ${start}-${safeEnd}/${size}`,
          "Accept-Ranges": "bytes",
          "Content-Length": String(bytes.byteLength),
          "Cache-Control": "public, max-age=31536000"
        }
      });
    }

    const data = await store.get(`${id}-chunk-${firstChunk}`, { type: "arrayBuffer" });
    if (!data) return new Response("Media chunk not found", { status: 404 });
    const localStart = start - firstChunk * CHUNK_SIZE;
    const localEnd = end - firstChunk * CHUNK_SIZE + 1;
    const bytes = new Uint8Array(data).slice(localStart, localEnd);
    const full = !range && start === 0 && end === size - 1;
    return new Response(bytes, {
      status: full ? 200 : 206,
      headers: {
        "Content-Type": manifest.contentType || "application/octet-stream",
        "Content-Range": `bytes ${start}-${end}/${size}`,
        "Accept-Ranges": "bytes",
        "Content-Length": String(bytes.byteLength),
        "Cache-Control": "public, max-age=31536000",
        "Content-Disposition": `inline; filename="${String(manifest.fileName || 'media').replace(/"/g, '')}"`
      }
    });
  } catch (err) {
    console.error(err);
    return new Response("Error loading media", { status: 500 });
  }
};
