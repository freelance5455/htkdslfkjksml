import { getStore } from "@netlify/blobs";
import { createHash } from "node:crypto";
const store=()=>getStore("xhouse-admin-data");
const reply=(body,status=200)=>Response.json(body,{status,headers:{"Cache-Control":"no-store","X-Content-Type-Options":"nosniff","Referrer-Policy":"strict-origin-when-cross-origin"}});
async function readVideos(){try{return JSON.parse((await (await store()).get("videos.json"))||"[]")}catch{return []}}
async function readStats(){try{return JSON.parse((await (await store()).get("external-metrics.json"))||"{}")}catch{return {}}}
function originOkay(request){const origin=request.headers.get("origin");if(!origin)return false;try{const o=new URL(origin),r=new URL(request.url);return o.protocol==="https:"&&r.protocol==="https:"&&o.host===r.host}catch{return false}}
function clientHash(request){const ip=request.headers.get("x-nf-client-connection-ip")||request.headers.get("x-forwarded-for")?.split(",")[0]?.trim()||"unknown";return createHash("sha256").update(ip).digest("hex").slice(0,32)}
export default async request=>{
 if(request.method!=="POST")return reply({error:"Method not allowed"},405);
 if(!originOkay(request))return reply({error:"So‘rov manbasi tasdiqlanmadi."},403);
 if(!(request.headers.get("content-type")||"").toLowerCase().includes("application/json"))return reply({error:"Faqat JSON qabul qilinadi."},415);
 if(Number(request.headers.get("content-length")||0)>2048)return reply({error:"So‘rov juda katta."},413);
 let body;try{body=await request.json()}catch{return reply({error:"Noto‘g‘ri so‘rov"},400)}
 const id=String(body.id||"").slice(0,100),action=String(body.action||"");if(!/^(?:[a-f0-9]{24}|dood:[A-Za-z0-9_-]{1,80})$/.test(id)||!['view','like','dislike'].includes(action))return reply({error:"Noto‘g‘ri amal"},400);
 const ip=clientHash(request), now=Date.now(), throttleKey=`metric-throttle/${ip}/${createHash("sha256").update(id+":"+action).digest("hex").slice(0,32)}`;
 const db=await store();
 // Limit repeat actions from the same network: views once per 30 minutes, votes once per day.
 const windowMs=action==="view"?30*60*1000:24*60*60*1000;
 try{const previous=Number(await db.get(throttleKey)||0);if(previous+windowMs>now)return reply({error:"Bu amal yaqinda bajarilgan. Keyinroq qayta urinib ko‘ring."},429);await db.set(throttleKey,String(now),{expirationTtl:Math.ceil(windowMs/1000)+60})}catch{return reply({error:"Xavfsizlik tekshiruvi vaqtincha ishlamadi."},503)}
 const videos=await readVideos(),v=videos.find(x=>x.id===id);
 if(v){if(action==='view')v.views=(v.views||0)+1;else if(action==='like')v.likes=(v.likes||0)+1;else v.dislikes=(v.dislikes||0)+1;await db.set("videos.json",JSON.stringify(videos));return reply({ok:true,views:v.views||0,likes:v.likes||0,dislikes:v.dislikes||0});}
 if(!id.startsWith("dood:"))return reply({error:"Video topilmadi"},404);
 const all=await readStats(),stat=all[id]||{views:0,likes:0,dislikes:0};if(action==='view')stat.views++;else if(action==='like')stat.likes++;else stat.dislikes++;all[id]=stat;await db.set("external-metrics.json",JSON.stringify(all));return reply({ok:true,...stat});
};
