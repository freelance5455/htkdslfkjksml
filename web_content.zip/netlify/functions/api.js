// netlify/functions/api.js
// Backend Serverless API untuk FirasX Rent:
// 1. Pembaca OTP Moonton Real-Time via IMAP Gmail (imap.gmail.com:993) dengan dukungan penuh Email Bertitik (Gmail Dot-Trick)
// 2. Diagnostik Otomatis App Password & Status IMAP (memberi tahu penyebab pasti jika salah/belum aktif)
// 3. Database Bersama (Shared State) menggunakan Netlify Blobs agar perubahan Developer langsung tampil di HP semua pengunjung
// 4. Endpoint Webhook Pembayaran Otomatis

const { ImapFlow } = require('imapflow');
const { simpleParser } = require('mailparser');

let getStore;
try {
  ({ getStore } = require('@netlify/blobs'));
} catch (e) {
  getStore = null;
}

// Fallback memory store jika Netlify Blobs belum diaktifkan
let memoryState = null;

async function readSharedState() {
  if (getStore) {
    try {
      const store = getStore('firasx-rent-db');
      const data = await store.get('main_state', { type: 'json' });
      if (data) return data;
    } catch (e) {
      console.warn('Netlify Blobs read fallback:', e.message);
    }
  }
  return memoryState;
}

async function writeSharedState(newState) {
  memoryState = newState;
  if (getStore) {
    try {
      const store = getStore('firasx-rent-db');
      await store.setJSON('main_state', newState);
    } catch (e) {
      console.warn('Netlify Blobs write fallback:', e.message);
    }
  }
  return newState;
}

// Klasifikasi error Gmail IMAP yang akurat & jujur
function classifyImapError(err) {
  const raw = String(err && (err.responseText || err.message || err));
  if (/Application-specific password required|Invalid credentials|WebLoginRequired|AUTHENTICATIONFAILED/i.test(raw)) {
    return {
      errorType: 'INVALID_APP_PASSWORD',
      errorTitle: 'App Password Salah atau Verifikasi 2 Langkah Belum Aktif',
      message: 'Google menolak login IMAP. Pastikan: (1) Verifikasi 2 Langkah sudah ON di akun Google induk, (2) Gunakan 16 digit App Password Google (bukan password biasa Gmail), (3) Tidak ada salah ketik huruf.'
    };
  }
  if (/IMAP access is disabled|Disabled for this account|not enabled for IMAP/i.test(raw)) {
    return {
      errorType: 'IMAP_DISABLED',
      errorTitle: 'IMAP Belum Aktif di Pengaturan Gmail',
      message: 'Akses IMAP masih nonaktif pada akun Gmail induk ini. Buka Gmail di browser -> Setelan (ikon gerigi) -> Lihat semua setelan -> Penerusan dan POP/IMAP -> pilih "Aktifkan IMAP" -> Simpan Perubahan.'
    };
  }
  if (/ETIMEDOUT|ECONNREFUSED|ENOTFOUND/i.test(raw)) {
    return {
      errorType: 'NETWORK_ERROR',
      errorTitle: 'Koneksi ke Server imap.gmail.com Gagal',
      message: 'Server gagal terhubung ke imap.gmail.com port 993. Coba beberapa detik lagi.'
    };
  }
  return {
    errorType: 'UNKNOWN_IMAP_ERROR',
    errorTitle: 'Gagal Terhubung ke Gmail IMAP',
    message: 'Detail teknis dari Google: ' + raw
  };
}

// Verifikasi koneksi IMAP + App Password secara langsung
async function verifyGmailCredentials(masterEmail, appPassword) {
  const cleanPass = String(appPassword || '').replace(/\s+/g, '');
  const client = new ImapFlow({
    host: 'imap.gmail.com',
    port: 993,
    secure: true,
    auth: {
      user: masterEmail,
      pass: cleanPass
    },
    logger: false,
    connectionTimeout: 10000
  });

  try {
    await client.connect();
    const lock = await client.getMailboxLock('INBOX');
    lock.release();
    await client.logout();
    return {
      valid: true,
      message: `✅ SUKSES! Login ke ${masterEmail} berhasil & IMAP aktif sepenuhnya. Siap menangkap OTP Moonton otomatis.`
    };
  } catch (err) {
    const info = classifyImapError(err);
    return {
      valid: false,
      errorType: info.errorType,
      message: `❌ ${info.errorTitle}: ${info.message}`
    };
  }
}

// Cari OTP Moonton terbaru untuk alamat email bertitik tertentu
async function fetchMoontonOtp(masterEmail, appPassword, targetEmail) {
  const cleanPass = String(appPassword || '').replace(/\s+/g, '');
  const normalizedTarget = String(targetEmail || '').trim().toLowerCase();

  const client = new ImapFlow({
    host: 'imap.gmail.com',
    port: 993,
    secure: true,
    auth: {
      user: masterEmail,
      pass: cleanPass
    },
    logger: false,
    connectionTimeout: 12000
  });

  try {
    await client.connect();
    const lock = await client.getMailboxLock('INBOX');

    try {
      // Ambil 25 pesan terakhir di INBOX (lebih akurat daripada SEARCH TO karena Gmail dot-alias sering di-header Delivered-To / To)
      const total = client.mailbox.exists || 0;
      if (total === 0) {
        return { found: false };
      }
      const startSeq = Math.max(1, total - 24);
      const messages = [];

      for await (let msg of client.fetch(`${startSeq}:${total}`, { source: true, envelope: true })) {
        messages.push(msg);
      }

      // Urutkan dari email paling baru ke paling lama
      messages.reverse();

      for (const msg of messages) {
        const parsed = await simpleParser(msg.source);
        const fromText = (parsed.from && parsed.from.text ? parsed.from.text : '').toLowerCase();
        const subjectText = (parsed.subject || '').toLowerCase();
        const bodyText = (parsed.text || '') + '\n' + (parsed.html || '');

        // Kumpulkan semua header tujuan (To, Delivered-To, X-Original-To) + isi email ("Dear h.ara.panindubapam@gmail.com")
        const toHeader = (parsed.to && parsed.to.text ? parsed.to.text : '').toLowerCase();
        const deliveredTo = String(parsed.headers.get('delivered-to') || '').toLowerCase();
        const combinedRecipient = `${toHeader} ${deliveredTo} ${bodyText.toLowerCase()}`;

        const isMoonton = fromText.includes('moonton') || subjectText.includes('moonton');
        const matchesAlias = combinedRecipient.includes(normalizedTarget);

        if (isMoonton && matchesAlias) {
          // Ekstrak kode OTP 6 digit dari isi email Moonton ("Verification code: 327445")
          const otpMatch = bodyText.match(/Verification code[:\s\r\n<>/a-zA-Z="*]*([0-9]{6})/i) || bodyText.match(/\b([0-9]{6})\b/);
          if (otpMatch && otpMatch[1]) {
            return {
              found: true,
              otp: otpMatch[1],
              to: targetEmail,
              sender: parsed.from ? parsed.from.text : 'Moonton Account',
              date: parsed.date ? new Date(parsed.date).toLocaleString('id-ID') : 'Baru saja'
            };
          }
        }
      }

      return { found: false };
    } finally {
      lock.release();
      await client.logout();
    }
  } catch (err) {
    const info = classifyImapError(err);
    return {
      found: false,
      errorType: info.errorType,
      errorTitle: info.errorTitle,
      message: info.message
    };
  }
}

exports.handler = async function (event) {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const body = event.body ? JSON.parse(event.body) : {};
    const action = body.action;

    // 1. Ambil state database bersama
    if (action === 'get_state') {
      const state = await readSharedState();
      return { statusCode: 200, headers, body: JSON.stringify({ state }) };
    }

    // 2. Simpan state database bersama
    if (action === 'save_state') {
      const saved = await writeSharedState(body.state);
      return { statusCode: 200, headers, body: JSON.stringify({ state: saved }) };
    }

    // 3. Cek App Password & IMAP Gmail secara real-time
    if (action === 'verify_gmail') {
      const result = await verifyGmailCredentials(body.masterEmail, body.appPassword);
      return { statusCode: 200, headers, body: JSON.stringify(result) };
    }

    // 4. Ambil OTP Moonton otomatis untuk email titik tertentu
    if (action === 'fetch_otp') {
      const currentState = await readSharedState();
      const masterEmail = body.masterEmail || (currentState && currentState.gmailConfig && currentState.gmailConfig.masterEmail);
      const appPassword = body.appPassword || (currentState && currentState.gmailConfig && currentState.gmailConfig.appPassword);

      if (!masterEmail || !appPassword) {
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({
            found: false,
            errorType: 'MISSING_CONFIG',
            errorTitle: 'Gmail Induk Belum Diatur',
            message: 'Developer belum mengisi Gmail Induk dan App Password di Panel Developer.'
          })
        };
      }

      const otpResult = await fetchMoontonOtp(masterEmail, appPassword, body.targetEmail);
      return { statusCode: 200, headers, body: JSON.stringify(otpResult) };
    }

    // 5. Webhook Pembayaran Otomatis (contoh: Tripay / Midtrans / Saweria / Custom Gateway)
    if (action === 'payment_webhook' || body.order_id) {
      const orderId = body.order_id || body.merchant_ref;
      const status = String(body.status || body.transaction_status || '').toUpperCase();
      const state = await readSharedState();
      if (state && Array.isArray(state.orders) && (status === 'PAID' || status === 'SETTLEMENT' || status === 'SUCCESS')) {
        const targetOrder = state.orders.find(o => o.id === orderId);
        if (targetOrder) {
          targetOrder.status = 'paid';
          await writeSharedState(state);
        }
      }
      return { statusCode: 200, headers, body: JSON.stringify({ received: true, orderId }) };
    }

    return { statusCode: 400, headers, body: JSON.stringify({ error: 'Unknown action' }) };
  } catch (error) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: error.message }) };
  }
};
