import { getStore } from "@netlify/blobs";
import { createHmac, timingSafeEqual, randomBytes, createHash } from "node:crypto";

const store = () => getStore("xhouse-admin-data");
const cookieName = "xhouse_admin_session";
const noStore = { "Cache-Control": "no-store" };
const json = (data, status=200, headers={}) => Response.json(data, { status, headers: secureHeaders(headers) });
const b64 = (s) => Buffer.from(s).toString("base64url");
function secret() { return process.env.SESSION_SECRET || ""; }
function sign(value) { return createHmac("sha256", secret()).update(value).digest("base64url"); }
function sessionCookie(value, maxAge=60*60*2) { return `${cookieName}=${value}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=${maxAge}`; }
function validSession(request) {
  if (!secret()) return false;
  const raw = (request.headers.get("cookie") || "").split(";").map(v=>v.trim()).find(v=>v.startsWith(cookieName+"="))?.slice(cookieName.length+1);
  if (!raw) return false;
  const [payload, sig] = raw.split("."); if (!payload || !sig) return false;
  const expected = sign(payload);
  try { if (!timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return false; } catch { return false; }
  try { const data=JSON.parse(Buffer.from(payload,"base64url").toString()); return data.exp > Date.now() && data.role === "admin"; } catch { return false; }
}
async function readList() { try { return JSON.parse((await (await store()).get("videos.json")) || "[]"); } catch { return []; } }
async function saveList(list) { await (await store()).set("videos.json", JSON.stringify(list)); }
async function readHidden() { try { return JSON.parse((await (await store()).get("hidden-dood-files.json")) || "[]"); } catch { return []; } }
async function saveHidden(list) { await (await store()).set("hidden-dood-files.json", JSON.stringify([...new Set(list)])); }
async function externalVideos() {
  const key = process.env.DOODSTREAM_API_KEY || process.env.VIDEO_API_KEY;
  if (!key) return [];
  const out=[];
  for (let page=1; page<=10; page++) {
    try {
      const u=new URL("https://doodapi.co/api/file/list"); u.searchParams.set("key",key); u.searchParams.set("page",String(page)); u.searchParams.set("per_page","40");
      const r=await fetch(u,{headers:{Accept:"application/json"}}); if(!r.ok) break;
      const d=await r.json(); const result=d.result||{}; const files=Array.isArray(result.files)?result.files:(Array.isArray(result)?result:[]);
      out.push(...files); if(files.length<40 || page>=Number(result.total_pages||1)) break;
    } catch { break; }
  }
  const hidden=new Set(await readHidden()); let stats={}; try{stats=JSON.parse((await (await store()).get('external-metrics.json'))||'{}')}catch{}
  return out.map(f=>{const id=`dood:${String(f.file_code||f.filecode||f.file_id||'')}`;const m=stats[id]||{};return { id, external:true, title:String(f.title||f.file_title||'Video').slice(0,160), url:String(f.download_url||f.single_img||f.file_code||f.filecode||''), type:'doodstream', views:Number(m.views||0), likes:Number(m.likes||0), dislikes:Number(m.dislikes||0), createdAt:f.uploaded||'' }}).filter(v=>v.id!=='dood:'&&!hidden.has(v.id));
}
function safeText(v, max=160) { return typeof v === "string" ? v.trim().slice(0,max) : ""; }
function clientKey(request) {
  const ip = request.headers.get("x-nf-client-connection-ip") || request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
  return createHash("sha256").update(ip).digest("hex").slice(0,32);
}
async function loginState(request) {
  try { return JSON.parse((await (await store()).get(`login-attempts/${clientKey(request)}`)) || '{"count":0,"until":0}'); }
  catch { return { count:0, until:0 }; }
}
async function saveLoginState(request, state) {
  await (await store()).set(`login-attempts/${clientKey(request)}`, JSON.stringify(state));
}
function sameOrigin(request) {
  const origin = request.headers.get("origin");
  // Mutating browser requests must carry an exact HTTPS origin; absent Origin is rejected.
  if (!origin) return false;
  try {
    const o = new URL(origin), r = new URL(request.url);
    return o.protocol === "https:" && r.protocol === "https:" && o.host === r.host;
  } catch { return false; }
}
function secureHeaders(extra={}) {
  return { "Cache-Control":"no-store", "X-Content-Type-Options":"nosniff", "Referrer-Policy":"no-referrer", ...extra };
}
function constantTimeEqual(a,b) {
  const aa=Buffer.from(String(a)), bb=Buffer.from(String(b));
  // Keep comparison timing independent of credential contents, including length mismatch.
  const max=Math.max(aa.length,bb.length,1), ap=Buffer.alloc(max), bp=Buffer.alloc(max);
  aa.copy(ap); bb.copy(bp);
  const same=timingSafeEqual(ap,bp);
  return same && aa.length===bb.length;
}

export default async (request) => {
  const url = new URL(request.url); const action = url.searchParams.get("action");
  if (request.method === "POST" && !sameOrigin(request)) return json({error:"Xavfsizlik tekshiruvi so‘rovni blokladi."},403);
  if (request.method === "POST" && !(request.headers.get("content-type")||"").toLowerCase().includes("application/json")) return json({error:"Faqat JSON so‘rov qabul qilinadi."},415);
  if (request.method === "POST" && Number(request.headers.get("content-length")||0) > 7_000_000) return json({error:"So‘rov hajmi juda katta."},413);
  if (request.method === "POST" && action === "login") {
    const state = await loginState(request);
    if (state.until > Date.now()) return json({error:"Juda ko‘p urinish. 15 daqiqadan keyin qayta urinib ko‘ring."},429,{"Retry-After":String(Math.ceil((state.until-Date.now())/1000))});
    const cfgUser=process.env.ADMIN_USERNAME, cfgPass=process.env.ADMIN_PASSWORD;
    if (!cfgUser || !cfgPass || !secret()) return json({error:"Netlify environment variables sozlanmagan."},500);
    let body; try { body=await request.json(); } catch { return json({error:"Noto‘g‘ri so‘rov."},400); }
    const user=String(body.username||""), pass=String(body.password||"");
    const matchUser=constantTimeEqual(user,cfgUser), matchPass=constantTimeEqual(pass,cfgPass);
    if (!matchUser || !matchPass) {
      const count = Number(state.count || 0) + 1;
      const next = count >= 5 ? {count:0, until:Date.now()+15*60*1000} : {count, until:0};
      await saveLoginState(request,next);
      return json({error:count >= 5 ? "5 ta xato urinish. Kirish 15 daqiqaga vaqtincha bloklandi." : "Login yoki parol noto‘g‘ri."},401);
    }
    await saveLoginState(request,{count:0,until:0});
    const payload=b64(JSON.stringify({role:"admin",exp:Date.now()+8*60*60*1000,nonce:randomBytes(12).toString("hex")}));
    return json({ok:true},200,{"Set-Cookie":sessionCookie(payload+"."+sign(payload)), "Pragma":"no-cache"});
  }
  if (request.method === "POST" && action === "logout") return json({ok:true},200,{"Set-Cookie":sessionCookie("",0)});
  if (!validSession(request)) return json({error:"Admin sifatida tizimga kiring."},401);

  if (request.method === "GET") {
    const manual=await readList();
    const external=await externalVideos();
    const manualUrls=new Set(manual.map(v=>{try{return new URL(v.url).href.replace(/\/$/,"")}catch{return v.url}}));
    const combined=manual.concat(external.filter(v=>!manualUrls.has(v.url)));
    return json({videos:combined, sourceError:(!process.env.DOODSTREAM_API_KEY&&!process.env.VIDEO_API_KEY)?"DoodStream API sozlanmagan":null});
  }
  if (request.method !== "POST") return json({error:"Method not allowed"},405);
  let body; try { body=await request.json(); } catch { return json({error:"Noto‘g‘ri JSON."},400); }
  if (action === "add-link") {
    const title=safeText(body.title), link=safeText(body.url,2048);
    let parsed; try { parsed=new URL(link); } catch { return json({error:"To‘g‘ri video URL kiriting."},400); }
    if (parsed.protocol !== 'https:') return json({error:"Faqat xavfsiz HTTPS havolalari mumkin."},400);
    if (!title) return json({error:"Video nomini kiriting."},400);
    const videos=await readList(); const canonical = (value) => { try { const u=new URL(value); u.hash=""; for (const key of [...u.searchParams.keys()]) if (["utm_source","utm_medium","utm_campaign","fbclid","gclid"].includes(key.toLowerCase())) u.searchParams.delete(key); return u.href.replace(/\/$/,""); } catch { return value; } };
    if (videos.some(v => canonical(v.url) === canonical(parsed.href))) return json({error:"Bu video saytimizda bor! Xuddi shu havola oldin qo‘shilgan."},409);
    const item={id:randomBytes(12).toString("hex"),title,url:parsed.href,type:"link",views:0,likes:0,dislikes:0,createdAt:new Date().toISOString()};
    videos.unshift(item); await saveList(videos); return json({ok:true,video:item});
  }
  if (action === "upload") {
    const title=safeText(body.title), name=safeText(body.name,180), type=safeText(body.contentType,100), data=body.data;
    if (!title || typeof data!=="string" || !name) return json({error:"Video nomi va fayl kerak."},400);
    if (!/^video\/(mp4|webm|ogg|quicktime)$/.test(type)) return json({error:"MP4, WebM, OGG yoki MOV video fayl tanlang."},415);
    if (data.length > 5_200_000) return json({error:"Fayl juda katta. Netlify Functions orqali 3.5 MB dan kichik video yuklang yoki video havolasini qo‘shing."},413);
    if (!/^[A-Za-z0-9+/]*={0,2}$/.test(data)) return json({error:"Fayl ma’lumoti noto‘g‘ri."},400);
    let bytes; try { bytes=Buffer.from(data,"base64"); } catch { return json({error:"Faylni o‘qib bo‘lmadi."},400); }
    if (!bytes.length || bytes.length > 3_800_000) return json({error:"Video fayl hajmi ruxsat etilgan chegaradan oshdi."},413);
    const id=randomBytes(12).toString("hex"), key=`media/${id}`;
    await (await store()).set(key, bytes, { metadata:{contentType:type, name} });
    const videos=await readList(); const item={id,title,type:"upload",url:`/.netlify/functions/admin-media?id=${id}`,storageKey:key,contentType:type,views:0,likes:0,dislikes:0,createdAt:new Date().toISOString()};
    videos.unshift(item); await saveList(videos); return json({ok:true,video:item});
  }
  if (action === "delete") {
    const id=safeText(body.id,100); if (!id) return json({error:"Video ID yo‘q."},400);
    const videos=await readList(), item=videos.find(v=>v.id===id);
    if (id.startsWith("dood:")) { const hidden=await readHidden(); hidden.push(id); await saveHidden(hidden); return json({ok:true,hidden:true}); }
    if (!item) return json({error:"Video topilmadi."},404);
    if (item.storageKey) await (await store()).delete(item.storageKey);
    await saveList(videos.filter(v=>v.id!==id)); return json({ok:true});
  }
  return json({error:"Noma’lum amal."},400);
};
