exports.handler = async function(event) {
  const username = String(event.queryStringParameters?.username || '').replace(/^@/, '').trim();
  if (!username) return json(400, { error: 'username_required' });

  const token = process.env.TIKTOK_RESEARCH_ACCESS_TOKEN;
  if (!token) return json(503, { error: 'tiktok_api_not_configured' });

  const fields = 'display_name,bio_description,avatar_url,is_verified,bio_url';
  try {
    const r = await fetch('https://open.tiktokapis.com/v2/research/user/info/?fields=' + fields, {
      method: 'POST',
      headers: {
        Authorization: 'Bearer ' + token,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ username })
    });
    const body = await r.text();
    let data;
    try { data = JSON.parse(body); } catch (_) { data = { error: 'invalid_tiktok_response' }; }
    return {
      statusCode: r.status,
      headers: {
        'content-type': 'application/json; charset=utf-8',
        'cache-control': 'no-store'
      },
      body: JSON.stringify(data)
    };
  } catch (e) {
    return json(502, { error: 'tiktok_request_failed' });
  }
};
function json(statusCode, body) {
  return { statusCode, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' }, body: JSON.stringify(body) };
}
