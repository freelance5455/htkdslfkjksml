import { getStore } from "@netlify/blobs";

export default async () => {
  try {
    const metaStore = getStore("video-meta");
    const list = (await metaStore.get("public-list", { type: "json" })) || [];

    return new Response(JSON.stringify(list), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        "Cache-Control": "public, max-age=30",
      },
    });
  } catch (err) {
    return new Response(JSON.stringify([]), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  }
};

// Available at: /.netlify/functions/list-videos
