import { getStore } from "@netlify/blobs";

function chatKey(u1, u2) {
  return [u1, u2].sort().join(":");
}

export default async (req) => {
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405 });
  }

  try {
    const body = await req.json();
    const { from, to, text } = body;

    if (!from || !to || !text) {
      return new Response(JSON.stringify({ error: "Missing from/to/text" }), { status: 400 });
    }

    const key = chatKey(from, to);
    const store = getStore("chats");

    let messages = [];
    try {
      const existing = await store.get(key, { type: "json" });
      if (Array.isArray(existing)) messages = existing;
    } catch (e) {}

    const msg = {
      id: Date.now() + Math.random().toString(36).slice(2, 7),
      from,
      to,
      text: String(text).slice(0, 1000),
      time: new Date().toISOString()
    };

    messages.push(msg);
    // keep last 200 messages
    if (messages.length > 200) messages = messages.slice(-200);

    await store.setJSON(key, messages);

    // also update conversation list for both users
    const meta = getStore("chat-meta");
    for (const user of [from, to]) {
      let list = [];
      try {
        const l = await meta.get("user:" + user, { type: "json" });
        if (Array.isArray(l)) list = l;
      } catch (e) {}

      // remove old entry for this partner
      const partner = user === from ? to : from;
      list = list.filter(c => c.with !== partner);
      list.unshift({
        with: partner,
        lastText: msg.text.slice(0, 40),
        lastTime: msg.time,
        lastFrom: from
      });
      list = list.slice(0, 50);
      await meta.setJSON("user:" + user, list);
    }

    return new Response(JSON.stringify({ success: true, message: msg }), {
      status: 200,
      headers: { "Content-Type": "application/json" }
    });
  } catch (err) {
    console.error(err);
    return new Response(JSON.stringify({ error: err.message }), { status: 500 });
  }
};
