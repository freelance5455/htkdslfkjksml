// Secure, read-only Groww live-data proxy. Never place the access token in browser code.
const API_BASE = 'https://api.groww.in/v1/live-data';
const ALLOWED = new Set(['ltp', 'quote', 'ohlc']);
const json = (statusCode, body) => ({
  statusCode,
  headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'access-control-allow-origin': '*', 'access-control-allow-methods': 'GET, OPTIONS' },
  body: JSON.stringify(body),
});

export const handler = async (request) => {
  if (request.httpMethod === 'OPTIONS') return { statusCode: 204, headers: { 'access-control-allow-origin': '*', 'access-control-allow-methods': 'GET, OPTIONS', 'access-control-allow-headers': 'Accept' }, body: '' };
  if (request.httpMethod !== 'GET') return json(405, { ok: false, error: 'GET_ONLY' });
  const token = process.env.GROWW_ACCESS_TOKEN;
  if (!token) return json(503, { ok: false, error: 'GROWW_ACCESS_TOKEN_NOT_CONFIGURED', message: 'Netlify environment variable GROWW_ACCESS_TOKEN configure karein.' });
  const params = new URLSearchParams(request.queryStringParameters || {});
  const action = params.get('action') || 'ltp';
  if (!ALLOWED.has(action)) return json(400, { ok: false, error: 'ACTION_NOT_ALLOWED' });
  const segment = (params.get('segment') || 'CASH').toUpperCase();
  if (!['CASH', 'FNO'].includes(segment)) return json(400, { ok: false, error: 'INVALID_SEGMENT' });

  const upstreamParams = new URLSearchParams();
  upstreamParams.set('segment', segment);
  if (action === 'ltp' || action === 'ohlc') {
    const symbols = (params.get('exchange_symbols') || '').trim();
    if (!symbols || symbols.length > 1500 || !/^[A-Za-z0-9_,.-]+$/.test(symbols))
      return json(400, { ok: false, error: 'INVALID_EXCHANGE_SYMBOLS', message: 'exchange_symbols required; e.g. NSE_RELIANCE' });
    const parts = symbols.split(',');
    if (parts.length > 50) return json(400, { ok: false, error: 'MAX_50_SYMBOLS' });
    upstreamParams.set('exchange_symbols', symbols);
  } else {
    const exchange = (params.get('exchange') || 'NSE').toUpperCase();
    const symbol = (params.get('trading_symbol') || '').trim();
    if (!['NSE', 'BSE'].includes(exchange) || !/^[A-Za-z0-9_.&-]{1,80}$/.test(symbol))
      return json(400, { ok: false, error: 'INVALID_QUOTE_SYMBOL' });
    upstreamParams.set('exchange', exchange);
    upstreamParams.set('trading_symbol', symbol);
  }

  try {
    const response = await fetch(`${API_BASE}/${action}?${upstreamParams.toString()}`, {
      method: 'GET',
      headers: { Accept: 'application/json', Authorization: `Bearer ${token}`, 'X-API-VERSION': '1.0' },
      signal: AbortSignal.timeout(10000),
    });
    const raw = await response.text();
    let payload;
    try { payload = JSON.parse(raw); } catch { payload = { message: 'Groww returned a non-JSON response' }; }
    if (!response.ok) return json(response.status === 401 ? 401 : 502, {
      ok: false,
      error: response.status === 401 ? 'GROWW_TOKEN_INVALID_OR_EXPIRED' : 'GROWW_API_ERROR',
      upstreamStatus: response.status,
      details: payload,
    });
    return json(200, { ok: true, source: 'Groww API', action, segment, receivedAt: new Date().toISOString(), data: payload });
  } catch (error) {
    return json(502, { ok: false, error: 'GROWW_CONNECTION_FAILED', message: String(error?.name || 'Network error') });
  }
};
