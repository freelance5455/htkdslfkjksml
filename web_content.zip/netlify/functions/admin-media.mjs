import { getStore } from "@netlify/blobs";
export default async (request) => {
  const id=new URL(request.url).searchParams.get("id")||"";
  if (!/^[a-f0-9]{24}$/.test(id)) return new Response("Not found",{status:404});
  const store=getStore("xhouse-admin-data");
  const meta=await store.getMetadata(`media/${id}`);
  if (!meta) return new Response("Not found",{status:404});
  const data=await store.get(`media/${id}`,{type:"arrayBuffer"});
  if (!data) return new Response("Not found",{status:404});
  return new Response(data,{headers:{"Content-Type":meta.metadata?.contentType||"video/mp4","Cache-Control":"public, max-age=3600","Accept-Ranges":"bytes"}});
};
