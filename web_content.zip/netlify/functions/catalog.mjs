import { getStore } from "@netlify/blobs";
export default async () => {
  try {
    const raw = await getStore("xhouse-admin-data").get("videos.json");
    const videos = JSON.parse(raw || "[]").map(v => ({ id:v.id, title:v.title, url:v.url, type:v.type, createdAt:v.createdAt, views:v.views||0, likes:v.likes||0, dislikes:v.dislikes||0 }));
    return Response.json({ videos }, { headers:{ "Cache-Control":"public, max-age=15" } });
  } catch { return Response.json({ videos:[] }, { headers:{ "Cache-Control":"no-store" } }); }
};
