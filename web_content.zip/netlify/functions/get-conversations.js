import { getStore } from "@netlify/blobs";

export default async (req) => {
  const url = new URL(req.url);
  const user = url.searchParams.get("user");

  if (!user) {
    return new Response(JSON.stringify([]), { status: 200 });
  }

  try {
    const meta = getStore("chat-meta");
    let list = [];
    try {
      const data = await meta.get("user:" + user, { type: "json" });
      if (Array.isArray(data)) list = data;
    } catch (e) {}

    return new Response(JSON.stringify(list), {
      status: 200,
      headers: { "Content-Type": "application/json", "Cache-Control": "no-cache" }
    });
  } catch (err) {
    return new Response(JSON.stringify([]), { status: 200 });
  }
};
