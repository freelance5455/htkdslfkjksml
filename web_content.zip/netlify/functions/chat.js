export default async (req) => {
  if (req.method !== "POST") return json({error:"Méthode non autorisée"},405);
  try {
    const body=await req.json();
    const message=typeof body.message==="string"?body.message.trim():"";
    if(!message) return json({error:"Message vide"},400);
    const key=process.env.OPENAI_API_KEY;
    if(!key) return json({error:"OPENAI_API_KEY manquante"},503);

    const r=await fetch("https://api.openai.com/v1/responses",{
      method:"POST",
      headers:{"Content-Type":"application/json","Authorization":`Bearer ${key}`},
      body:JSON.stringify({
        model:"gpt-6-luna",
        instructions:"Tu es Mini Yackuza AI, un assistant francophone pour une interface de démonstration. Aide à rédiger, reformuler, résumer et structurer des textes. Ne prétends jamais pouvoir bannir, débannir ou modifier un compte WhatsApp. Les messages de bannissement sont uniquement des simulations.",
        input:message
      })
    });
    const data=await r.json();
    if(!r.ok) return json({error:data.error?.message||"Erreur OpenAI"},r.status);
    return json({reply:data.output_text||"Réponse vide."},200);
  } catch(e){ return json({error:"Erreur serveur"},500); }
};
function json(data,status){return new Response(JSON.stringify(data),{status,headers:{"Content-Type":"application/json"}})}
