exports.handler = async function(event) {
  const headers = { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' };
  const username = String((event.queryStringParameters || {}).username || '').replace(/^@/, '').trim();
  if (!username || !/^[A-Za-z0-9._-]{1,30}$/.test(username)) {
    return { statusCode: 400, headers, body: JSON.stringify({ ok:false, error:'Enter a valid TikTok username.' }) };
  }
  const token = process.env.TIKTOK_RESEARCH_ACCESS_TOKEN;
  if (!token) {
    return { statusCode: 503, headers, body: JSON.stringify({ ok:false, code:'TOKEN_MISSING', error:'TikTok API token is not configured on Netlify.' }) };
  }
  try {
    const fields = 'display_name,bio_description,avatar_url,is_verified,bio_url';
    const r = await fetch('https://open.tiktokapis.com/v2/research/user/info/?fields=' + encodeURIComponent(fields), {
      method:'POST', headers:{'Authorization':'Bearer '+token,'Content-Type':'application/json'}, body:JSON.stringify({username})
    });
    const j = await r.json().catch(()=>({}));
    if (!r.ok || j.error && j.error.code && j.error.code !== 'ok') {
      return { statusCode:r.status || 502, headers, body:JSON.stringify({ok:false, code:j.error?.code || 'TIKTOK_ERROR', error:j.error?.message || 'TikTok API request failed.'}) };
    }
    const u = j.data || {};
    let recentViews = null;
    try {
      const end = new Date();
      const start = new Date(end.getTime() - 30*24*60*60*1000);
      const ymd = d => d.toISOString().slice(0,10).replace(/-/g,'');
      const q = {
        query:{and:[{operation:'EQ',field_name:'username',field_values:[username]}]},
        start_date:ymd(start), end_date:ymd(end), max_count:100, is_random:false
      };
      const vr = await fetch('https://open.tiktokapis.com/v2/research/video/query/?fields='+encodeURIComponent('id,view_count'), {
        method:'POST', headers:{'Authorization':'Bearer '+token,'Content-Type':'application/json'}, body:JSON.stringify(q)
      });
      const vj = await vr.json().catch(()=>({}));
      if (vr.ok && Array.isArray(vj.data?.videos)) recentViews = vj.data.videos.reduce((sum,v)=>sum + (Number(v.view_count)||0),0);
    } catch (_) {}
    return { statusCode:200, headers, body:JSON.stringify({ok:true, profile:{username,display_name:u.display_name||username,bio_description:u.bio_description||'',avatar_url:u.avatar_url||'',is_verified:!!u.is_verified,follower_count:u.follower_count,following_count:u.following_count,likes_count:u.likes_count,video_count:u.video_count,bio_url:u.bio_url||'',profile_url:'https://www.tiktok.com/@'+encodeURIComponent(username),recent_views_30d:recentViews}}) };
  } catch (e) {
    return { statusCode:502, headers, body:JSON.stringify({ok:false, code:'NETWORK_ERROR', error:'Could not reach TikTok API.'}) };
  }
};
