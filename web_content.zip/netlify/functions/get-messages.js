import { getStore } from "@netlify/blobs";

function chatKey(u1, u2) {
  return [u1, u2].sort().join(":");
}

export default async (req) => {
  const url = new URL(req.url);
  const me = url.searchParams.get("me");
  const withUser = url.searchParams.get("with");

  if (!me || !withUser) {
    return new Response(JSON.stringify({ error: "Missing me or with" }), { status: 400 });
  }

  try {
    const store = getStore("chats");
    const key = chatKey(me, withUser);
    let messages = [];
    try {
      const data = await store.get(key, { type: "json" });
      if (Array.isArray(data)) messages = data;
    } catch (e) {}

    return new Response(JSON.stringify(messages), {
      status: 200,
      headers: { "Content-Type": "application/json", "Cache-Control": "no-cache" }
    });
  } catch (err) {
    return new Response(JSON.stringify([]), { status: 200 });
  }
};
