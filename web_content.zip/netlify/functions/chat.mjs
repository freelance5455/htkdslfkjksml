// Servidor de Miércoles: recibe el chat, lo envía a un modelo de IA real
// y devuelve la respuesta en tiempo real (streaming), como ChatGPT o Gemini.
// La clave secreta vive solo aquí (variables de entorno de Netlify), nunca en la app.
//
// Variables de entorno (Netlify > Site configuration > Environment variables):
//   AI_API_KEY  -> tu clave del proveedor
//   AI_API_BASE -> dirección del proveedor (formato OpenAI)
//   AI_MODEL    -> nombre del modelo
//
// Ejemplos:
//   Groq (gratis):   https://api.groq.com/openai/v1                              llama-3.3-70b-versatile
//   Gemini (gratis): https://generativelanguage.googleapis.com/v1beta/openai     gemini-2.0-flash
//   OpenAI:          https://api.openai.com/v1                                   gpt-4o-mini
//   Grok (xAI):      https://api.x.ai/v1                                         grok-3-mini
//   OpenRouter:      https://openrouter.ai/api/v1                                meta-llama/llama-3.3-70b-instruct:free

const PERSONA = `Eres Miércoles, una inteligencia artificial de uso general, como un asistente moderno de IA.
Ayudas con preguntas, explicaciones, escritura, traducción, programación, matemáticas, ideas y consejos.
Tu personalidad: humor seco, irónico y un punto oscuro, con frases claras y directas. Tu sarcasmo es cariñoso, nunca cruel.
Reglas: sé útil, honesta y precisa; si no sabes algo o no tienes datos actuales, dilo en lugar de inventar;
responde en el idioma de la persona; sé breve salvo que pidan detalle; usa listas y bloques de código cuando ayuden.
Si alguien está mal o en peligro, deja el sarcasmo y responde con calidez y seriedad.`;

const json = (o, s) => new Response(JSON.stringify(o), { status: s, headers: { "Content-Type": "application/json" } });

export default async (req) => {
  if (req.method !== "POST") return json({ error: "Método no permitido" }, 405);
  const { AI_API_KEY, AI_API_BASE, AI_MODEL } = process.env;
  if (!AI_API_KEY || !AI_API_BASE || !AI_MODEL)
    return json({ error: "Miércoles aún no tiene cerebro: faltan AI_API_KEY, AI_API_BASE y AI_MODEL en tu servidor." }, 500);

  let msgs;
  try { msgs = (await req.json()).messages; } catch { msgs = null; }
  if (!Array.isArray(msgs) || !msgs.length) return json({ error: "Mensajes inválidos" }, 400);
  msgs = msgs.slice(-24).map(m => ({
    role: m.role === "assistant" ? "assistant" : "user",
    content: String(m.content || "").slice(0, 6000)
  }));

  const hoy = new Date().toLocaleDateString("es", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
  try {
    const up = await fetch(AI_API_BASE.replace(/\/$/, "") + "/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: "Bearer " + AI_API_KEY },
      body: JSON.stringify({
        model: AI_MODEL, stream: true, max_tokens: 1200,
        messages: [{ role: "system", content: PERSONA + "\nFecha de hoy: " + hoy + "." }, ...msgs]
      })
    });
    if (!up.ok) return json({ error: "El proveedor de IA respondió " + up.status + ". Revisa tu clave y el modelo." }, 502);
    return new Response(up.body, { headers: { "Content-Type": "text/event-stream", "Cache-Control": "no-cache" } });
  } catch {
    return json({ error: "No se pudo contactar al proveedor de IA." }, 502);
  }
};

export const config = { path: "/api/chat" };
