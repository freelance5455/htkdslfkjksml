const https = require("https");

function fetchFirebaseData(endpoint) {
  return new Promise((resolve) => {
    const url = `https://pay4smart-default-rtdb.firebaseio.com/${endpoint}.json`;
    https.get(url, (res) => {
      let data = "";
      res.on("data", (chunk) => (data += chunk));
      res.on("end", () => {
        try {
          resolve(JSON.parse(data) || {});
        } catch (e) {
          resolve({});
        }
      });
    }).on("error", () => resolve({}));
  });
}

function updateFirebaseData(endpoint, payload) {
  return new Promise((resolve, reject) => {
    const dataStr = JSON.stringify(payload);
    const req = https.request(`https://pay4smart-default-rtdb.firebaseio.com/${endpoint}.json`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" }
    }, (res) => {
      let responseData = "";
      res.on("data", chunk => responseData += chunk);
      res.on("end", () => resolve(responseData));
    });
    req.on("error", reject);
    req.write(dataStr);
    req.end();
  });
}

function pushFirebaseHistory(endpoint, historyItem) {
  return new Promise((resolve, reject) => {
    const dataStr = JSON.stringify(historyItem);
    const req = https.request(`https://pay4smart-default-rtdb.firebaseio.com/${endpoint}.json`, {
      method: "POST",
      headers: { "Content-Type": "application/json" }
    }, (res) => {
      resolve();
    });
    req.on("error", reject);
    req.write(dataStr);
    req.end();
  });
}

exports.handler = async (event) => {
  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };

  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }

  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ status: "FAILURE", message: "Method Not Allowed" })
    };
  }

  try {
    const data = JSON.parse(event.body || "{}");
    const { userPhone, tpin, number, amount, provider_code, txn_id, service_name } = data;

    const rechargeAmt = parseFloat(amount);
    if (!userPhone || !rechargeAmt || rechargeAmt <= 0 || !number || !provider_code) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ status: "FAILURE", message: "ভুল বা অসম্পূর্ণ তথ্য পাঠানো হয়েছে।" })
      };
    }

    const userData = await fetchFirebaseData(`users/${userPhone}`);
    if (!userData || !userData.phone) {
      return {
        statusCode: 404,
        headers,
        body: JSON.stringify({ status: "FAILURE", message: "ইউজার অ্যাকাউন্ট পাওয়া যায়নি।" })
      };
    }

    if (tpin && userData.tpin && userData.tpin !== tpin) {
      return {
        statusCode: 403,
        headers,
        body: JSON.stringify({ status: "FAILURE", message: "ভুল TPIN! ট্রানজ্যাকশন বাতিল।" })
      };
    }

    const currentBalance = parseFloat(userData.balance || 0);
    if (currentBalance < rechargeAmt) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ status: "FAILURE", message: "পর্যাপ্ত ওয়ালেট ব্যালেন্স নেই।" })
      };
    }

    const [firebaseSettings, margins] = await Promise.all([
      fetchFirebaseData("app_settings"),
      fetchFirebaseData("margins")
    ]);

    const baseUrl = firebaseSettings.recharge_api_url || "https://payicon.in/api/api_service/recharges";
    const token = firebaseSettings.recharge_api_token || "DQQVHAWL3H1S8GMB2sYatbtB4hpvjD7p";
    const callbackUrl = firebaseSettings.recharge_callback_url || "https://pay4smart.netlify.app/.netlify/functions/payment-callback";
    const apiOrderId = txn_id || ("ORD" + Date.now());

    const targetUrl = `${baseUrl}?token=${encodeURIComponent(token)}&provider_id=${encodeURIComponent(provider_code)}&number=${encodeURIComponent(number)}&amount=${encodeURIComponent(rechargeAmt)}&api_order_id=${encodeURIComponent(apiOrderId)}&callback_url=${encodeURIComponent(callbackUrl)}`;

    const response = await fetch(targetUrl, {
      method: "POST",
      headers: {
        "Accept": "*/*",
        "User-Agent": "Mozilla/5.0"
      }
    });

    const responseText = await response.text();
    const cleanText = responseText.trim();

    let isSuccess = false;
    let message = cleanText;
    let operatorRef = "";

    try {
      const jsonRes = JSON.parse(cleanText);
      const resStatus = (jsonRes.status || jsonRes.STATUS || "").toString().toUpperCase();

      if (
        resStatus === "SUCCESS" ||
        resStatus === "PENDING" ||
        resStatus === "1" ||
        jsonRes.status === 1 ||
        jsonRes.status === true
      ) {
        isSuccess = true;
        message = jsonRes.message || jsonRes.msg || "Recharge Accepted Successfully";
        operatorRef = jsonRes.order_id || jsonRes.operator_id || "";
      } else {
        message = jsonRes.remark || jsonRes.error_msg || jsonRes.message || jsonRes.msg || cleanText;
      }
    } catch (e) {
      if (cleanText === "1" || cleanText.toLowerCase().includes("success")) {
        isSuccess = true;
        message = "Recharge Accepted Successfully";
      }
    }

    if (isSuccess) {
      let marginRate = 0.5;
      const sName = (service_name || "").toLowerCase();
      if (sName.includes("jio")) marginRate = parseFloat(margins.jio) || 1.1;
      else if (sName.includes("airtel")) marginRate = parseFloat(margins.airtel) || 2.0;
      else if (sName.includes("vi")) marginRate = parseFloat(margins.vi) || 2.0;
      else if (sName.includes("bsnl")) marginRate = parseFloat(margins.bsnl_topup) || 4.0;
      else if (sName.includes("tata") || sName.includes("dish") || sName.includes("d2h") || sName.includes("sun")) marginRate = parseFloat(margins.tataplay) || 2.0;

      const commission = parseFloat(((rechargeAmt * marginRate) / 100).toFixed(2));
      const finalBalance = parseFloat((currentBalance - rechargeAmt + commission).toFixed(2));
      const newTotalSale = parseFloat((userData.total_sale || 0) + rechargeAmt);
      const newTotalProfit = parseFloat((userData.total_profit || 0) + commission);

      const timeStr = "Today, " + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

      await updateFirebaseData(`users/${userPhone}`, {
        balance: finalBalance,
        total_sale: newTotalSale,
        total_profit: newTotalProfit
      });

      await pushFirebaseHistory(`users/${userPhone}/history`, {
        txnId: apiOrderId,
        title: `${service_name || 'Mobile'} Recharge`,
        desc: `${number} • Success`,
        amount: rechargeAmt,
        type: "debit",
        category: "recharge",
        time: timeStr
      });

      if (commission > 0) {
        await pushFirebaseHistory(`users/${userPhone}/history`, {
          txnId: "COMM" + Date.now(),
          title: "Commission Cashback",
          desc: `${marginRate}% Margin Added`,
          amount: commission,
          type: "credit",
          category: "ledger",
          time: timeStr
        });
      }

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          status: "SUCCESS",
          message: message,
          operator_ref: operatorRef,
          commission: commission,
          new_balance: finalBalance
        })
      };
    } else {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          status: "FAILURE",
          message: message || "অপারেটর থেকে রিচার্জ সফল হয়নি।"
        })
      };
    }

  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        status: "FAILURE",
        message: "Server Error: " + error.message
      })
    };
  }
};
