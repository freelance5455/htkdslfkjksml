SMART EDU MPR — ANDROID STUDIO PROJECT

Source included:
app/src/main/assets/index.html
This is the supplied latest Smart_Edu_MPR_Builder_Firestore_CloudSync.html.

BUILD APK
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio, choose Open and select the extracted SmartEduMPR_Android_Project folder.
4. Allow Gradle sync and install the Android SDK platform requested by Android Studio (compile SDK 35).
5. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
6. The debug APK will be under app/build/outputs/apk/debug/app-debug.apk.

FIREBASE CHECKS BEFORE REAL USE
- In Firebase Console > Authentication > Settings / Authorized domains, add appassets.androidplatform.net if Firebase rejects the app's origin.
- Confirm Email/Password sign-in is enabled.
- The Firestore rules must allow each signed-in user to access only their own users/{uid}/appData/main document. Do not use broad rules that let every authenticated user read/write every user's records.
- Test registration, sign-in, cloud sync, offline behavior, PDF/printing, and app restart on the target Android phone.

NOTES
- Internet is required for Firebase SDK downloads and cloud sync.
- This is a WebView wrapper project, not a native rewrite.
- An APK has not been compiled or tested in this environment because the Android SDK/Gradle build environment is not installed here.
