# Paint Ball – APK ആക്കാൻ

വേണ്ടത്: Node.js, Android Studio (ഇവ ഇൻസ്റ്റാൾ ചെയ്തിരിക്കണം)

1. ഈ ഫോൾഡറിൽ ടെർമിനൽ തുറക്കുക
2. npm install
3. npx cap add android
4. npx capacitor-assets generate --android
5. npx cap sync android
6. npx cap open android
7. Android Studio-യിൽ: Build > Build Bundle(s) / APK(s) > Build APK(s)
   APK ഇവിടെ കിട്ടും: android/app/build/outputs/apk/debug/app-debug.apk
