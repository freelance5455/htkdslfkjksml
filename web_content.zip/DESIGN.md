---
name: Serene Strength
colors:
  surface: '#f9f9f6'
  surface-dim: '#dadad7'
  surface-bright: '#f9f9f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f4f1'
  surface-container: '#eeeeeb'
  surface-container-high: '#e8e8e5'
  surface-container-highest: '#e2e3e0'
  on-surface: '#1a1c1b'
  on-surface-variant: '#414942'
  inverse-surface: '#2f312f'
  inverse-on-surface: '#f1f1ee'
  outline: '#717972'
  outline-variant: '#c1c8c0'
  surface-tint: '#3f674d'
  primary: '#0d3721'
  on-primary: '#ffffff'
  primary-container: '#264e36'
  on-primary-container: '#93bea0'
  inverse-primary: '#a5d1b1'
  secondary: '#476550'
  on-secondary: '#ffffff'
  secondary-container: '#c6e8cd'
  on-secondary-container: '#4b6954'
  tertiary: '#29322c'
  on-tertiary: '#ffffff'
  tertiary-container: '#404842'
  on-tertiary-container: '#adb6af'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#c0edcc'
  primary-fixed-dim: '#a5d1b1'
  on-primary-fixed: '#002110'
  on-primary-fixed-variant: '#274f37'
  secondary-fixed: '#c9ebd0'
  secondary-fixed-dim: '#adcfb5'
  on-secondary-fixed: '#032110'
  on-secondary-fixed-variant: '#304d39'
  tertiary-fixed: '#dce5dd'
  tertiary-fixed-dim: '#c0c9c1'
  on-tertiary-fixed: '#151d19'
  on-tertiary-fixed-variant: '#404943'
  background: '#f9f9f6'
  on-background: '#1a1c1b'
  surface-variant: '#e2e3e0'
typography:
  display-lg:
    fontFamily: Epilogue
    fontSize: 3rem
    fontWeight: '600'
    lineHeight: 3.5rem
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Epilogue
    fontSize: 2rem
    fontWeight: '600'
    lineHeight: 2.5rem
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Epilogue
    fontSize: 1.625rem
    fontWeight: '600'
    lineHeight: 2.125rem
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Epilogue
    fontSize: 1.375rem
    fontWeight: '600'
    lineHeight: 1.875rem
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Epilogue
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.625rem
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.625rem
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.375rem
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.6875rem
    fontWeight: '500'
    lineHeight: 0.875rem
    letterSpacing: 0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-tablet: 1.5rem
  gutter-desktop: 2rem
  margin: 1.25rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.25rem
---

## Brand & Style

This design system embodies a dual emotional ethos: absolute safety paired with quiet empowerment. It balances the grounding calm required during mental distress with the clear-headed, decisive readiness needed for self-defense guidance. 

The aesthetic is an organic blend of warm minimalism and soft tactile depth. The visual tone rejects clinical coldness and aggressive tactical tropes, using welcoming organic geometry, spacious layouts, and nurturing earth tones. The interface reassures users through gentle clarity, predictable affordances, and zero sensory overload while remaining immediately legible under stress.

## Colors

The palette pairs natural foliage tones with warm, breathable neutrals to lower cognitive stress and foster security.

- **Primary (`#264E36` - Deep Forest Green)**: Communicates grounded resilience, authority, and structural stability. Used for critical interactive actions, key active indicators, and high-emphasis elements.
- **Secondary (`#7D9D85` - Soothing Sage Green)**: Softens interaction points, framing supportive actions, progress states, and secondary controls with tranquil balance.
- **Tertiary (`#DCE5DD` - Soft Mint & Moss Wash)**: Serves as an empathetic container fill, card background, and subtle highlight surface to gently separate content layers without harsh borders.
- **Neutral (`#F9F9F6` - Warm Alabaster Cream)**: The primary canvas backdrop. Replaces sterile digital white with a warm, paper-like warmth that reduces glare and eye strain.
- **Text & Contrast Hierarchy**: Text relies on `#16261B` (Deep Pine Umber) for high-contrast, effortless legibility that passes WCAG AAA guidelines across all light surfaces. Subtle captioning uses `#4B5E50`.

## Typography

The typographic pairing balances reassuring humanism with crisp, reassuring clarity:

- **Headlines (Epilogue)**: Imparts warmth, intentional character, and steady strength. The subtle sculptural curves offer emotional comfort in moments of anxiety while establishing visual authority during tactical guidance steps.
- **Body & Labels (Plus Jakarta Sans)**: Delivers exceptional optical legibility at every scale. Its rounded terminals and open apertures provide a soft, welcoming demeanor without sacrificing spatial efficiency or scanning speed under high-stress conditions.

## Layout & Spacing

The layout philosophy prioritizes generous, calming whitespace that lets content breathe, preventing mental fatigue.

- **Mobile First Framework**: Mobile interfaces adhere to a single-column or 4-column fluid system with `1.25rem` outer margins. Content groups are separated by expansive vertical buffers (`space-lg` and `space-xl`) to encourage gradual, paced scrolling.
- **Tablet & Large Screens**: Content gracefully locks into an 8-column layout (max width `640px` for reading-focused mental health sessions; max `960px` for two-column tactical routines) with `1.5rem` gutters.
- **Touch-First Breathing Room**: Interactive targets maintain a minimum vertical hit area of `48px`, surrounded by at least `space-sm` separation to prevent accidental taps during elevated emotional states.

## Elevation & Depth

Visual hierarchy uses warm tonal layering and soft ambient depth, avoiding heavy dropshadows or stark high-contrast borders:

- **Level 0 (Base Canvas)**: Neutral `#F9F9F6`, setting a warm, non-reflective baseline.
- **Level 1 (Ground Cards & Surfaces)**: Pure white `#FFFFFF` or pale moss `#F0F4F1` layered over the base. Borders are replaced with delicate tonal contrast or ultra-soft ambient shadows: `box-shadow: 0 4px 20px -2px rgba(38, 78, 54, 0.05)`.
- **Level 2 (Active Sheets & Modals)**: Floating bottom sheets, breathing timers, and emergency guidance overlays use `box-shadow: 0 12px 32px -4px rgba(22, 38, 27, 0.08)` tinted with the primary forest undertone.
- **Layering Philosophy**: Depth is primarily communicated through shifts in soft tint fills (`#F9F9F6` to `#F0F4F1` to `#DCE5DD`) rather than harsh elevation changes, creating an uninterrupted sense of peace.

## Shapes

The design system incorporates soft, welcoming geometry to create a safe and non-threatening tactile environment:

- **Containers & Cards (`rounded-lg`, 1rem)**: Softens edges, making guidance cards and journal entries feel friendly and approachable.
- **Modals, Floating Panels & Action Hubs (`rounded-xl`, 1.5rem)**: Creates organic, pebble-like surfaces for major interactive panels.
- **Chips, Pills & Buttons**: Primary buttons and tags utilize fully pill-shaped radii (`9999px`) to emphasize fluidity, gentle touchpoints, and natural reassurance.

## Components

- **Buttons**:
  - *Primary*: Forest green fill (`#264E36`) with alabaster text (`#F9F9F6`), fully rounded pill shape (`9999px`), minimum height of `52px`. Gentle inward spring scale (`0.98`) on press.
  - *Secondary*: Soft mint fill (`#DCE5DD`) with deep pine text (`#16261B`).
  - *SOS / Quick Defense Guide*: Immediate high-visibility pill utilizing forest green with a warm amber-moss accent icon, anchored at thumb reach.

- **Cards**:
  - Crisp, uncluttered rounded rectangles (`1rem` radius) with `1.25rem` internal padding. Features dual color treatments: crisp white with subtle tinted ambient shadows for mental clarity tools, and soft moss tint (`#F0F4F1`) for physical self-defense drills.

- **Chips & Mood Selectors**:
  - Pill-shaped tags with `0.5rem` vertical and `1rem` horizontal padding. Default state: `#EAEFEA` background with `#2D4534` text. Selected state: `#264E36` fill with white text, transitioning with a smooth fade.

- **Inputs & Text Areas**:
  - Soft alabaster containers with subtle borders (`1.5px solid #CCD8CF`). Focus state transitions smoothly to `#264E36` with a soft mint outer halo (`3px rgba(125, 157, 133, 0.25)`).

- **Checkboxes & Radios**:
  - Rounded checkbox surfaces (`6px` radius) and circular radios with a `24px` hit target. Filled with deep forest green and an off-white inner checkmark icon when selected.

- **Guided Breathing & Defense Routine Widget**:
  - Dedicated circular pacing indicators that expand and contract smoothly with soothing sage gradients, providing rhythm and grounded focus without disruptive abrupt animations.