---
name: Nova Media Player
colors:
  surface: '#10131a'
  surface-dim: '#10131a'
  surface-bright: '#363940'
  surface-container-lowest: '#0b0e14'
  surface-container-low: '#191c22'
  surface-container: '#1d2026'
  surface-container-high: '#272a31'
  surface-container-highest: '#32353c'
  on-surface: '#e1e2eb'
  on-surface-variant: '#bac9cc'
  inverse-surface: '#e1e2eb'
  inverse-on-surface: '#2e3037'
  outline: '#849396'
  outline-variant: '#3b494c'
  surface-tint: '#00daf3'
  primary: '#c3f5ff'
  on-primary: '#00363d'
  primary-container: '#00e5ff'
  on-primary-container: '#00626e'
  inverse-primary: '#006875'
  secondary: '#a8c8ff'
  on-secondary: '#003061'
  secondary-container: '#3491ff'
  on-secondary-container: '#002955'
  tertiary: '#f1e9ff'
  on-tertiary: '#370096'
  tertiary-container: '#d6c9ff'
  on-tertiary-container: '#622be5'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#9cf0ff'
  primary-fixed-dim: '#00daf3'
  on-primary-fixed: '#001f24'
  on-primary-fixed-variant: '#004f58'
  secondary-fixed: '#d5e3ff'
  secondary-fixed-dim: '#a8c8ff'
  on-secondary-fixed: '#001b3c'
  on-secondary-fixed-variant: '#004689'
  tertiary-fixed: '#e8deff'
  tertiary-fixed-dim: '#cdbdff'
  on-tertiary-fixed: '#20005f'
  on-tertiary-fixed-variant: '#4f00d0'
  background: '#10131a'
  on-background: '#e1e2eb'
  surface-variant: '#32353c'
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
  title-lg:
    fontFamily: Roboto Flex
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  title-md:
    fontFamily: Roboto Flex
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 22px
  body-lg:
    fontFamily: Roboto Flex
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Roboto Flex
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Space Grotesk
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  gutter-tablet: 1.25rem
  gutter-desktop: 1.5rem
  margin: 1.25rem
  margin-mobile: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system delivers a futuristic, high-performance multimedia player environment engineered natively around modern Material 3 (Expressive) ergonomics and optimized for OLED/AMOLED hardware displays. The aesthetic pairs deep, energy-efficient ink obsidian surfaces with hyper-vivid, luminescent optical pulses in cyan, electric blue, and ultraviolet.

### Creative Direction & Movements
- **Hyper-Modern AMOLED Expressive:** True blacks and deep-space midnight containers yield infinite contrast and zero pixel-drain, focusing attention purely on video playback, hi-res album artwork, and fluid dynamic audio visualizations.
- **Luminescent Glass & Ambient Glow:** Layered frosted sheets with low-alpha tinting, microscopic rim-lights, and localized chromatic back-glows that react in real-time to active media artwork.
- **Physicality & Responsive Haptics:** Rounded card clusters, tactile continuous pill scrubs, and oversized touch targets tailored for thumb-driven one-handed gesture navigation.

### Target Audience & Emotional Impact
Audiophiles, video purists, and high-spec Android enthusiasts seeking a desktop-grade powerhouse wrapped in a fluid, tactile, and sensory-satisfying touch experience. The UI evokes technological precision, effortless speed, and theatrical immersion.

## Colors

The palette is rooted in absolute depth and luminous clarity. Color operates as an active state indicator and a beacon for playback feedback against cavernous obsidian canvas tiers.

### Surface Tiers (True Dark Engine)
- **Background / Canvas (`#0B0E14`):** Base underlying viewport; true deep space with minimal luminance.
- **Surface Container Lowest (`#080A0F`):** Recessed wells, collapsed playlists, and scrub rails.
- **Surface Container Low (`#121721`):** Primary base tier for inactive cards, sheets, and grouped audio lists.
- **Surface Container Default (`#161D2B`):** Standard resting state for actionable items, media panels, and persistent bottom dock.
- **Surface Container High (`#1A2232`):** Elevated dialogues, active modals, and pop-out pip controllers.
- **Surface Container Highest (`#222D42`):** Highlighted card focus, hovered touch regions, and active segment segments.

### Signal & Accent Systems
- **Primary Electric Cyan (`#00E5FF`):** Live playhead scrubbing, active audio track title, master volume peak indicators, and primary floating action buttons.
- **Secondary Cobalt Blue (`#0088FF`):** Stream quality metadata (FLAC, Dolby Atmos, 4K HDR), buffer fill indicators, and persistent loop/shuffle toggles.
- **Tertiary Neon Violet (`#7C4DFF`):** Spatial audio markers, frequency spectrum highs, bookmarks, and EQ visualizer ribbons.
- **Surface Variant & Borders (`rgba(255, 255, 255, 0.08)`): Micro-borders providing edge definition without contrast clash.
- **On-Surface High-Contrast Text (`#F0F4FC`):** 96% opacity for primary titles, timestamps, and active status.
- **On-Surface Medium-Contrast Text (`#94A3B8`):** 65% opacity for artist metadata, file specs, and secondary tags.

## Typography

The type system blends the technical, machine-age authority of Space Grotesk with the hyper-legible, utilitarian fluidity of Roboto Flex. Space Grotesk is leveraged for punchy media titles, numerical readouts, timecodes, and format badges, instilling an advanced audio console impression. Roboto Flex manages long metadata strings, lyric streams, and contextual system copy with immaculate vertical rhythm.

### Typographic Implementation Rules
- **Monospaced Timecodes:** Scrubbers and digital clocks always render numerical glyphs in tabular/monospaced configurations (`font-feature-settings: 'tnum' on`) to eliminate jitter during continuous playback.
- **Metadata Badges & Chips:** Rendered in `label-sm` with full uppercase transformations and generous letter-spacing to sustain rapid scanning at high vehicle speeds or gym workouts.
- **Hierarchical Contrast:** Titles maintain crisp white `#F0F4FC`, while subordinate artist/album names transition down to `#94A3B8` without ever falling below WCAG AAA legibility thresholds.

## Layout & Spacing

The player layout employs a fluid adaptive Material 3 grid that anchors bottom-weighted touch geometry for handheld use and expands horizontally into dual-pane control stages on wide viewports.

### Breakpoints & Adaptivity
- **Compact (<600dp, Mobile):** 4-column layout. Margin 16dp (`margin-mobile`), gutter 12dp (`gutter-mobile`). Persistent dynamic bottom control deck (height: 72dp) with swipable mini-player transitioning via vertical drag into an edge-to-edge full-canvas playback theater.
- **Medium (600dp - 839dp, Foldables/Tablets):** 8-column layout. Gutter 20dp (`gutter-tablet`), Margin 32dp (`margin-tablet`). Master-detail split: Left quadrant reserved for visualizer/album sleeve and scrubbers; right quadrant handles real-time queue, EQ sliders, and synchronized lyrics.
- **Expanded (≥840dp, Desktop/Automotive/TV):** 12-column layout. 3-column modular workbench: Library/Playlists (left 3 cols), Central Cinematic Video Canvas (center 6 cols), and Master Audio DSP/Telemetry Panel (right 3 cols).

### Spatial Rhythm
All padding, stacking, and component gaps align to an irreducible 4px base module, jumping cleanly to 8px, 16px, 24px, and 40px intervals. Scrubbing bars require at least a 48dp minimum physical touch target despite slim 4dp visual rails.

## Elevation & Depth

Rather than conventional drop shadows—which disappear or muddy against true black backgrounds—this system establishes visual depth through calculated surface-container tone shifts, subtle directional specular highlights, and chromatic aura glows.

### Tonal Stratification
- **Tier 0 (Base Canvas):** `#0B0E14` (0% ambient glow).
- **Tier 1 (Surface Cards & Lists):** `#121721` with an interior top border highlight: `inset 0 1px 0 0 rgba(255, 255, 255, 0.05)`.
- **Tier 2 (Floating Action Decks & Now-Playing Sheets):** `#1A2232` with a peripheral glow: `0 8px 32px -4px rgba(0, 0, 0, 0.65), 0 0 1px 1px rgba(255, 255, 255, 0.08)`.
- **Tier 3 (Active Modals & Context Menus):** `#222D42` with an overlaid backdrop blur: `backdrop-filter: blur(24px) saturate(180%)`.

### Luminous Chromatic Glow
Actionable focus states and the primary play/pause node abandon neutral halos in favor of tinted optical energy:
- **Active Playhead & Master Fab:** `box-shadow: 0 0 24px 2px rgba(0, 229, 255, 0.45), 0 4px 12px 0 rgba(0, 0, 0, 0.8)`.
- **Selected Filter / EQ Node:** `box-shadow: 0 0 16px 0 rgba(124, 77, 255, 0.4)`.

## Shapes

In full alignment with Material 3 Expressive geometry, this design system uses generous, organic curves paired with pilliform active components. Curvature creates a frictionless physical sensation and acts as a safe visual containment perimeter for rich dynamic media.

### Shape Scale Rules
- **Full-Pill (`rounded-full` / >9999px):** All interactive control buttons, volume scrub heads, playback speed selectors, audio format pill chips (e.g., `DSD 5.6MHz`), and the bottom gesture bar.
- **Card Extreme (`rounded-3xl` / 2rem / 32px):** Now-Playing album art wrappers, modal bottom sheets, pip floating panels, and featured media showcase cards.
- **Card Standard (`rounded-2xl` / 1.5rem / 24px):** Playlist tiles, EQ preset containers, directory folders, and settings cards.
- **Component Subtle (`rounded-xl` / 1rem / 16px):** Nested track items inside queues, contextual menu dropdowns, and thumbnail previews.

## Components

### Playback Transport Controls
- **Primary Play/Pause Toggle:** 64dp circular floating surface bathed in `#00E5FF` fill with `#080A0F` glyph icon. Emits dynamic cyan bloom. Scales down by 6% on active press (`active:scale-95`).
- **Secondary Transport (Skip/Prev/Seek):** 48dp transparent discs with 24dp `#F0F4FC` optical glyphs. Inactive state features a `#161D2B` background layer; on hover/tap, illuminates to `#1A2232` with a subtle `#00E5FF` icon highlight.
- **Scrubber / Seekbar:** Track height is 4dp resting, dynamically morphing to 8dp upon finger proximity or hover. Inactive track: `#1A2232`. Buffered track: `#0088FF` at 40% alpha. Played track: solid `#00E5FF`. The scrub thumb is a 16dp solid `#F0F4FC` pill with an inner core of `#00E5FF` that expands during user drag.

### Buttons & Chips
- **Filled Action Button:** Full-pill shape, solid `#00E5FF` background, `#080A0F` Space Grotesk text (`label-lg`), height 44dp, minimum horizontal padding of 24dp.
- **Tonal Button:** Full-pill shape, `#1A2232` background, `#00E5FF` text, with a 1px border of `rgba(0, 229, 255, 0.2)`.
- **Metadata Badges & Chips:** Full-pill, height 24dp, padding horizontal 10dp. Background: `rgba(255, 255, 255, 0.05)`, border: `1px solid rgba(255, 255, 255, 0.1)`. Label font: `label-sm`, color: `#94A3B8`. When showing lossless/Dolby credentials, the border transitions to `#7C4DFF` and the label adopts `#F0F4FC`.

### Media Cards & Lists
- **Album / Video Grid Card:** Contained in `rounded-3xl` frame. 1:1 aspect ratio for audio, 16:9 for video. Background: `#121721`. Imagery features an ultra-subtle inward vignette to guarantee that overlay badges and duration readouts remain legible without scrim blocks.
- **Track Item Row:** Height 64dp, radius `rounded-xl`, padding horizontal 12dp. Shows track index/artwork (44dp `rounded-lg`), title (`title-md`), subtitle (`body-md`), and trailing options. Active playing row shifts background to `rgba(0, 229, 255, 0.08)`, text turns `#00E5FF`, and displays an animated 3-bar equalizer glyph.

### Form Inputs & Selectors
- **Search Field:** Height 52dp, `rounded-full`, filled with `#121721`, border `1px solid rgba(255, 255, 255, 0.06)`. Focused state initiates a clean `#00E5FF` border and a localized neon underglow.
- **Switches & Segmented Toggles:** Enclosed in a full-pill `#121721` housing. Active selected segment slides via a spring-physics curved transform, backed by `#222D42` and branded with cyan typography.
- **Checkboxes & Radios:** 20dp `rounded-md` (checkbox) or circular (radio) with a 2dp border in `#94A3B8`. On selection, fills with `#00E5FF` featuring an `#080A0F` checkmark.

### Domain-Specific Components
- **Graphic Equalizer Sliders:** Vertical 10-band slider array. Vertical track: 6dp wide `#121721` with neon violet central zero-baseline. Draggable puck: 24dp x 12dp horizontal pill illuminated in `#7C4DFF`.
- **Waveform Timeline Scrub:** Real-time audio amplitude visualizer rendered in 2dp vertical bars with 2dp spacing. Left of playhead paints in energetic `#00E5FF`, right remains dormant in `#1A2232`.