# SAGOR AI — Expanded Assistant

এই সংস্করণে যোগ করা হয়েছে:
- OpenAI Responses API দিয়ে বাংলা AI chat
- Browser speech recognition (বাংলা voice input; browser/device support প্রয়োজন)
- Browser speech synthesis (উপলভ্য বাংলা voice থাকলে spoken reply)
- Open-Meteo দিয়ে geolocation-ভিত্তিক বর্তমান আবহাওয়া
- BBC World ও Al Jazeera RSS থেকে headline
- OpenAI image generation endpoint দিয়ে ছবি তৈরির request
- আগের কথোপকথনের সাম্প্রতিক ২০টি message context

## এখনো কী নেই
**ফোনের সব অ্যাপ সম্পূর্ণ নিয়ন্ত্রণ নেই।** ওয়েবসাইট/HTML কোনো Android অ্যাপকে নির্বিচারে খুলতে, পড়তে বা নিয়ন্ত্রণ করতে পারে না। এর জন্য native Android APK, Android intents, user-granted permissions এবং নির্দিষ্ট ক্ষেত্রে Accessibility Service দরকার। Accessibility অনুমতি ব্যবহারকারীকে নিজে Android Settings থেকে দিতে হয়; নিরাপত্তা ও Play policy-ও মানতে হয়। এই ZIP-এ Accessibility Service অন্তর্ভুক্ত নয়।
এটি wake-word/always-listening assistant নয়। ব্যবহারকারীকে মাইক্রোফোন বাটন চাপতে হবে।
News অংশ RSS headline দেখায়; AI দিয়ে পূর্ণ web search বা article summarization নয়।
Video generation, WhatsApp/SMS/calls, file access, alarm/calendar, app-specific actions এখনো নেই।

## Deploy
1. ZIP extract করুন এবং GitHub private repository-তে upload করুন।
2. Render-এ New > Web Service > repository connect করুন।
3. Build: `npm install`; Start: `npm start`.
4. Environment Variables:
   - `OPENAI_API_KEY`: আপনার OpenAI API key (কখনো HTML-এ নয়)
   - `OPENAI_MODEL`: আপনার API account-এ উপলভ্য text model ID
   - `OPENAI_IMAGE_MODEL`: `gpt-image-1` (অ্যাকাউন্টে অনুমোদিত হলে)
5. Deploy হলে HTTPS URL খুলুন, microphone ও location permission দিন।

API key, API billing এবং image generation access আলাদা করে লাগবে। ChatGPT subscription API credit নয়। API usage-এর জন্য budget limit সেট করুন।
