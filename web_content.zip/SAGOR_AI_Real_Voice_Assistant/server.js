import express from "express";
import "dotenv/config";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;
app.disable("x-powered-by");
app.use(express.json({ limit: "12mb" }));
app.use(express.static(path.join(__dirname, "public")));

const SYSTEM_INSTRUCTIONS = `
তুমি SAGOR AI, সাগরের ব্যক্তিগত বাংলা AI সহকারী।
সবসময় সহজ, স্বাভাবিক বাংলাদেশি বাংলায় উত্তর দেবে।
ব্যবহারকারীর অনুরোধ অনুযায়ী গল্প, স্ক্রিপ্ট, YouTube SEO, ব্যাখ্যা, পরিকল্পনা ও সাধারণ প্রশ্নে সাহায্য করবে।
তুমি ফোনের সব অ্যাপ বা সিস্টেম নিজে নিয়ন্ত্রণ করতে পারো—এমন দাবি করবে না।
কোনো কাজ বাস্তবে না করলে সম্পন্ন হয়েছে বলবে না।
`;

async function openAI(pathname, body) {
  if (!process.env.OPENAI_API_KEY) throw new Error("সার্ভারে OPENAI_API_KEY সেট করা হয়নি।");
  const response = await fetch(`https://api.openai.com/v1/${pathname}`, {
    method: "POST",
    headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data?.error?.message || `AI API error: ${response.status}`);
  return data;
}

app.get("/api/health", (_req,res) => res.json({
  ok:true, configured:Boolean(process.env.OPENAI_API_KEY),
  imageConfigured:Boolean(process.env.OPENAI_API_KEY), app:"SAGOR AI"
}));

app.post("/api/chat", async (req,res) => {
  try {
    const messages = Array.isArray(req.body?.messages) ? req.body.messages : [];
    const clean = messages.filter(m=>m && ["user","assistant"].includes(m.role) && typeof m.content==="string")
      .slice(-20).map(m=>({role:m.role,content:m.content.slice(0,8000)}));
    if (!clean.length || clean.at(-1).role!=="user") return res.status(400).json({error:"একটি প্রশ্ন লিখুন বা বলুন।"});
    const model = process.env.OPENAI_MODEL || "gpt-6";
    const data = await openAI("responses",{model,instructions:SYSTEM_INSTRUCTIONS,input:clean});
    let answer=data.output_text || "";
    if(!answer && Array.isArray(data.output)) answer=data.output.flatMap(x=>x.content||[]).filter(x=>x.type==="output_text").map(x=>x.text).join("\n");
    res.json({answer:answer||"দুঃখিত, উত্তর তৈরি করা যায়নি।"});
  } catch(e){res.status(500).json({error:e.message||"AI সার্ভারে সমস্যা হয়েছে।"});}
});

// Current weather: Open-Meteo public forecast API (no API key for normal non-commercial use).
app.get("/api/weather", async (req,res)=>{
  try{
    const lat=Number(req.query.lat), lon=Number(req.query.lon);
    if(!Number.isFinite(lat)||!Number.isFinite(lon)) return res.status(400).json({error:"লোকেশন পাওয়া যায়নি।"});
    const u=new URL("https://api.open-meteo.com/v1/forecast");
    u.search=new URLSearchParams({latitude:String(lat),longitude:String(lon),current:"temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,wind_speed_10m",daily:"temperature_2m_max,temperature_2m_min,precipitation_probability_max",timezone:"auto"}).toString();
    const r=await fetch(u); if(!r.ok) throw new Error("আবহাওয়ার তথ্য পাওয়া যায়নি");
    res.json(await r.json());
  }catch(e){res.status(502).json({error:e.message});}
});

// Public RSS headline reader. Sources/availability may vary by region and feed policy.
app.get("/api/news", async (_req,res)=>{
  try{
    const feeds=[
      "https://feeds.bbci.co.uk/news/world/rss.xml",
      "https://www.aljazeera.com/xml/rss/all.xml"
    ];
    const results=await Promise.all(feeds.map(async url=>{
      try{const r=await fetch(url,{headers:{"User-Agent":"SAGOR-AI/1.0"}});return r.ok?await r.text():"";}catch{return "";}
    }));
    const items=[];
    for(const xml of results){
      const chunks=xml.match(/<item[\\s\\S]*?<\\/item>/gi)||[];
      for(const chunk of chunks.slice(0,12)){
        const title=(chunk.match(/<title><!\\[CDATA\\[([\\s\\S]*?)\\]\\]><\\/title>|<title>([\\s\\S]*?)<\\/title>/i)||[]).slice(1).find(Boolean)||"";
        const link=(chunk.match(/<link>([\\s\\S]*?)<\\/link>/i)||[])[1]||"";
        const date=(chunk.match(/<pubDate>([\\s\\S]*?)<\\/pubDate>/i)||[])[1]||"";
        const clean=s=>s.replace(/&amp;/g,"&").replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/<[^>]+>/g,"").trim();
        if(title) items.push({title:clean(title),url:clean(link),date:clean(date)});
      }
    }
    res.json({items:items.slice(0,20)});
  }catch(e){res.status(502).json({error:"খবর আনা যায়নি: "+e.message});}
});

// Image generation. Returns base64 image data; API key remains on server.
app.post("/api/image", async(req,res)=>{
  try{
    const prompt=String(req.body?.prompt||"").trim();
    if(!prompt) return res.status(400).json({error:"ছবির বর্ণনা লিখুন।"});
    const data=await openAI("images/generations",{model:process.env.OPENAI_IMAGE_MODEL||"gpt-image-1",prompt,size:"1024x1024",n:1});
    const item=data.data?.[0];
    if(!item?.b64_json) throw new Error("ইমেজ সার্ভিস থেকে ছবি পাওয়া যায়নি।");
    res.json({image:`data:image/png;base64,${item.b64_json}`});
  }catch(e){res.status(500).json({error:e.message||"ছবি তৈরি করা যায়নি।"});}
});

app.get("*",(_req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`SAGOR AI listening on ${PORT}`));
