# Socle 2.5 — Contrats des damistes et offres commerciales entrantes automatiques

## Contrats individuels des damistes
- Le manager peut proposer une rémunération par saison, une prime, une durée de 1 à 5 saisons et un statut sportif (titulaire ou rotation).
- Le damiste accepte ou formule une contre-proposition calculée à partir de son niveau, du moral et du budget du club.
- Une contre-proposition du damiste doit être explicitement acceptée par le manager ; la signature reste une action distincte.
- La signature crée le contrat individuel, augmente le moral du damiste et actualise la masse salariale annuelle engagée.
- Le moteur refuse une signature qui ferait dépasser au total la capacité budgétaire du club.
- Les négociations sont historisées, idempotentes et validées. Une seule négociation active par damiste.

## Offres commerciales entrantes automatiques
- Après les 3e, 6e et 9e rencontres de championnat du club dirigé, une structure du catalogue historique peut approcher le club.
- Les structures utilisées proviennent exclusivement des catalogues de sponsors, partenaires, promoteurs, banques et firmes existants.
- Les offres sont entrantes, uniques par saison et jalon ; aucun démarchage sortant ni signature automatique.
- Le montant de départ est un coefficient provisoire de simulation basé sur le budget, la réputation médiatique et la satisfaction des supporters. Il est clairement affiché comme barème de simulation, pas comme une donnée historique.
- Les fonds ne sont crédités qu'après signature du contrat commercial.

## Préservation et compatibilité
- Les huit compétitions, leurs identifiants, calendriers, formats et moteurs ne sont pas modifiés par cette tranche.
- Les sauvegardes antérieures reçoivent des valeurs par défaut pour la masse salariale et les jalons d'offres ; les données existantes sont conservées.
- Les catalogues historiques ne sont ni remplacés ni réduits.

## Vérifications
- 152 tests automatisés réussis, syntaxe JavaScript vérifiée et intégrité ZIP vérifiée.
- Tests spécifiques : demande salariale, contre-proposition du damiste, signature, masse salariale, plafond budgétaire, offres automatiques, idempotence et absence de démarchage sortant.
- Une tentative de démarrage Chromium sans interface a dépassé le délai imparti ; la vérification visuelle complète dans un navigateur reste donc à réaliser.
