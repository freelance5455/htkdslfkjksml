# Shoply – Android app (Capacitor)

Your two HTML pages wrapped as a real Android app (full-screen WebView, offline fonts,
hardware back button, status bar colour, slide-in screen transition).

## Build the APK — easiest (no Android Studio)
1. Push this folder to a new GitHub repo.
2. Open the **Actions** tab → "Build Android APK" → wait ~5 min.
3. Download `shoply-debug-apk` from the run, unzip, copy `app-debug.apk` to your phone and install
   (allow "Install unknown apps").

## Build locally
Needs Node 18+, JDK 17, Android Studio (SDK).
    npm install
    npx cap add android
    npm run apk        # → android/app/build/outputs/apk/debug/app-debug.apk
or `npm run open` to run it from Android Studio.

## Edit the app
Change files in `www/` (index.html = first page, second.html = receipt page), then `npx cap sync android`.
