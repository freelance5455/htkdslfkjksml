(function () {
  var cap = window.Capacitor, P = (cap && cap.Plugins) || {};
  var isHome = /(^|\/)(index\.html)?$/.test(location.pathname);

  // Android hardware / gesture back button
  if (P.App) {
    P.App.addListener('backButton', function () {
      var editing = document.querySelector('[contenteditable="true"]');
      if (editing) { editing.blur(); return; }
      if (isHome) P.App.exitApp(); else location.href = 'index.html';
    });
  }
  // Header back arrow on the home screen exits the app instead of doing nothing
  var back = document.querySelector('.back-btn');
  if (back && isHome) back.addEventListener('click', function (e) {
    e.preventDefault(); if (P.App) P.App.exitApp();
  });

  // Status bar matches the blue header
  if (P.StatusBar) {
    try { P.StatusBar.setStyle({ style: 'DARK' }); P.StatusBar.setBackgroundColor({ color: '#0050e6' }); } catch (e) {}
  }
  if (P.SplashScreen) { try { P.SplashScreen.hide(); } catch (e) {} }
})();
