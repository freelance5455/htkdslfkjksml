const catalog = {
 Combat: [
  ["⚔","Auto-Clicker","Click-assistance demo toggle",false],
  ["♢","Attack Indicator","Show a local UI indicator",true],
  ["⌖","Crosshair","Customize the on-screen crosshair",true]
 ],
 Movement: [
  ["♜","Sprint Assist","Convenience setting placeholder",true],
  ["⇧","Jump Display","Show jump status in UI",true],
  ["⌁","Motion Blur","Visual effect placeholder",false]
 ],
 Render: [
  ["◉","Fullbright","Brightness preference placeholder",true],
  ["▧","Particle Effects","Adjust visual effect preference",true],
  ["☼","Weather Overlay","Toggle weather overlay preference",false]
 ],
 Player: [
  ["♟","Player HUD","Show player information panel",true],
  ["♥","Health Display","Show health indicator placeholder",true],
  ["◷","Status Effects","Show status effect list",true]
 ],
 World: [
  ["⬡","World Map","Map integration placeholder",false],
  ["▦","Waypoints","Waypoint manager placeholder",true],
  ["☷","Resource Info","World info panel placeholder",false]
 ],
 Misc: [
  ["⌁","Keystrokes","Show keyboard input overlay",true],
  ["◷","Clock","Show in-game clock placeholder",true],
  ["♧","Cosmetics","Cosmetic profile placeholder",false]
 ],
 Settings: [
  ["☾","Dark Theme","Use the default dark blue theme",true],
  ["✦","Glow Effects","Neon accent effects",true],
  ["▣","Compact UI","Reduce interface spacing",false]
 ]
};
const $ = s => document.querySelector(s);
const pageContent = $("#pageContent");
const toast = $("#toast");
let toastTimer;
function notify(message){toast.textContent=message;toast.style.display="block";clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.style.display="none",2600)}
function renderToggles(cat){
 $("#toggleList").innerHTML = (catalog[cat]||[]).map((item,i)=>`<div class="toggle-row"><div class="toggle-icon">${item[0]}</div><div class="toggle-text"><b>${item[1]}</b><small>${item[2]}</small></div><button class="switch ${item[3]?'on':''}" role="switch" aria-checked="${item[3]}" aria-label="${item[1]}" data-toggle="${cat}-${i}"></button></div>`).join("");
 $("#toggleList").querySelectorAll(".switch").forEach(btn=>btn.addEventListener("click",()=>{btn.classList.toggle("on");btn.setAttribute("aria-checked",btn.classList.contains("on"));notify("UI preference toggled. Game integration is not connected yet.")}));
}
document.querySelectorAll(".cat").forEach(btn=>btn.addEventListener("click",()=>{document.querySelectorAll(".cat").forEach(x=>x.classList.remove("active"));btn.classList.add("active");renderToggles(btn.dataset.cat)}));
const pageData={
 Home:["Home","Welcome to Blaze Client. Choose a version and loader, explore the mod library, and customize the interface.",[["Quick Start","Choose your Minecraft version and mod loader, then review compatible mods.","Choose version"],["Latest News","This is a front-end prototype. Minecraft launching is not connected yet.","View details"]]],
 Mods:["Mods Library","A curated catalog interface for free, open-source and community mods. Check each project’s license and compatibility before installing.",[["Performance","Sodium, Lithium, FerriteCore, Entity Culling","Browse category"],["Utility","AppleSkin, Mod Menu, Jade","Browse category"],["Quality of Life","Mouse Tweaks, EMI, Xaero’s Minimap","Browse category"],["Mod Sources","Modrinth and CurseForge are common trusted discovery sources. Downloads are not wired into this prototype.","Open sources"]]],
 Settings:["Settings","Customize the interface preferences.",[["Appearance","Dark blue theme, accent glow, UI scale","Configure"],["Privacy","No login credentials or personal data are collected in this prototype.","Review"],["Notifications","Choose whether app notices are displayed.","Configure"]]],
 Performance:["Performance","Performance recommendations depend on your PC, Minecraft version, loader, and installed mods.",[["Sodium","Rendering optimization for supported Fabric setups.","Details"],["Lithium","Game logic optimization for supported versions.","Details"],["FerriteCore","Memory usage optimization for supported versions.","Details"],["Entity Culling","Avoid rendering hidden entities where supported.","Details"]]],
 "HUD Editor":["HUD Editor","A visual planning area for HUD elements. Drag-and-drop editing is a future integration.",[["FPS Counter","Example HUD element","Select"],["Keystrokes","Example HUD element","Select"],["Coordinates","Example HUD element","Select"],["Armor Status","Example HUD element","Select"]]],
 Launcher:["Launcher","Launcher shortcuts and profile management concept. This app does not yet launch Minecraft.",[["Minecraft Java","Desktop game profile placeholder","Select"],["Fabric","Mod loader profile placeholder","Select"],["Forge / NeoForge","Alternative loader profile placeholder","Select"],["Import Profile","Profile import is not implemented yet.","Import"]]],
 Account:["Account","Optional profile screen. This prototype does not require registration and does not store passwords.",[["Local Profile","Manage a display name locally in this session.","Edit profile"],["Sync","Cloud sync is not connected.","Not connected"]]]
};
function showPage(name){
 const data=pageData[name]||pageData.Home;
 document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===name));
 if(name==="Home"){pageContent.classList.remove("show");return}
 pageContent.innerHTML=`<h2>${name}</h2><p style="color:#91bfe6;font-size:13px;line-height:1.7">${data[1]}</p><div class="tile-grid">${data[2].map(t=>`<article class="tile"><h3>${t[0]}</h3><p>${t[1]}</p><button type="button">${t[2]}</button></article>`).join("")}</div>`;
 pageContent.classList.add("show");
 pageContent.querySelectorAll("button").forEach(b=>b.addEventListener("click",()=>notify("This is a prototype action; integration is not connected yet.")));
 if(window.innerWidth<700) pageContent.scrollIntoView({behavior:"smooth",block:"start"});
}
document.querySelectorAll(".nav-item").forEach(btn=>btn.addEventListener("click",()=>{showPage(btn.dataset.page);$("#sidebar").classList.remove("open")}));
$("#mobileMenu").addEventListener("click",()=>$("#sidebar").classList.toggle("open"));
$("#playButton").addEventListener("click",()=>notify("Minecraft launch is not connected. This build is a responsive UI prototype."));
$("#version").addEventListener("change",()=>notify("Selected Minecraft version: "+$("#version").value));
$("#loader").addEventListener("change",()=>notify("Selected loader: "+$("#loader").value));
renderToggles("Combat");
if("serviceWorker" in navigator && location.protocol.startsWith("http")) navigator.serviceWorker.register("./sw.js").catch(()=>{});
