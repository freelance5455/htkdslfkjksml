# Blaze Client — Cross-platform responsive UI prototype

This package includes a responsive web app that adapts to desktop PCs, laptops, tablets, and mobile browsers. It recreates the visual direction of the supplied reference: dark navy background, electric-blue accents, left navigation, hero launcher panel, right-side quick toggles, and feature strip.

## Run it
- Extract the ZIP.
- Open `index.html` in a modern browser.
- For installable PWA/offline caching, serve the folder over HTTPS or localhost and use the browser's **Install app** option.

## Included sections
- Home
- Mods Library
- Settings
- Performance
- HUD Editor
- Launcher
- Account
- Quick settings categories: Combat, Movement, Render, Player, World, Misc, Settings

## Honest limitations
- This is a responsive front-end prototype, **not a compiled APK**.
- It does not yet launch Minecraft, install mods, read real FPS/ping, or edit a live game HUD.
- The right-side switches are interface demonstrations, not live game modules.
- A universal “all free mods” bundle cannot be safely or legally prepacked without checking each mod's license, source, game version, and loader.
- It does not implement cheats or anti-cheat bypasses.
- The hero background uses a remote image, so it may not appear offline.

## About APK and desktop builds
An Android APK must be built using an Android project and SDK. A desktop installer (Windows/macOS/Linux) needs a separate packaging step. This ZIP gives you the shared responsive UI foundation; it is not yet a ready-to-install native package for every platform.
