---
name: Titanium Executive Intelligence
colors:
  surface: '#0f131c'
  surface-dim: '#0f131c'
  surface-bright: '#353943'
  surface-container-lowest: '#0a0e17'
  surface-container-low: '#181b25'
  surface-container: '#1c1f29'
  surface-container-high: '#262a34'
  surface-container-highest: '#31353f'
  on-surface: '#dfe2ef'
  on-surface-variant: '#b9cacb'
  inverse-surface: '#dfe2ef'
  inverse-on-surface: '#2c303a'
  outline: '#849495'
  outline-variant: '#3b494b'
  surface-tint: '#00dbe9'
  primary: '#dbfcff'
  on-primary: '#00363a'
  primary-container: '#00f0ff'
  on-primary-container: '#006970'
  inverse-primary: '#006970'
  secondary: '#adc6ff'
  on-secondary: '#002e6a'
  secondary-container: '#0566d9'
  on-secondary-container: '#e6ecff'
  tertiary: '#fff3ea'
  on-tertiary: '#472a00'
  tertiary-container: '#ffd19c'
  on-tertiary-container: '#855300'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#7df4ff'
  primary-fixed-dim: '#00dbe9'
  on-primary-fixed: '#002022'
  on-primary-fixed-variant: '#004f54'
  secondary-fixed: '#d8e2ff'
  secondary-fixed-dim: '#adc6ff'
  on-secondary-fixed: '#001a42'
  on-secondary-fixed-variant: '#004395'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#0f131c'
  on-background: '#dfe2ef'
  surface-variant: '#31353f'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: -0.015em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 12px
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-tablet: 1.5rem
  gutter-desktop: 2rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes an authoritative, precision-engineered visual language for an autonomous personal AI agent. The aesthetic synthesizes dark modern titanium with deep sapphire tonalities, pairing understated executive polish with technical capability. Rather than leaning into theatrical "cyberpunk" tropes or sci-fi green terminals, the interface evokes the gravitas of bespoke Swiss avionics instrumentation and high-end executive hardware: silent, hyper-responsive, and uncompromised.

The visual direction merges **Clean Technical Glassmorphism** with **Precision Tonal Layering**:
- **Frosted Sapphire & Onyx Depth:** Semi-translucent panels float over deep slate-onyx canvas, using high-density backdrop blurs and micro-fine hairline borders to create physical hierarchy.
- **Controlled Luminescence:** Cyan and electric sapphire accents provide active state indicators, telemetry pulses, and attention focal points without overwhelming readability.
- **Engineered Restraint:** Visual elements respect structural order, high signal-to-noise ratios, and ultra-crisp edge delineation suited for dense handheld displays.

## Colors

The palette operates in strict dark mode by default, anchoring the agent's presence in deep, low-luminance titanium and onyx tones while reserving high-intensity spectrums strictly for runtime status and executive actions.

### Core Swatches
- **Primary (`#00F0FF` - Electric Cyan):** Reserved for agent cognition states, active voice waves, micro-glows, primary call-to-actions, and focal interaction targets.
- **Secondary (`#3B82F6` - Sapphire Blue):** Used for structural navigation nodes, secondary action states, ambient telemetry gradients, and active agent execution pipelines.
- **Tertiary (`#F59E0B` - Precision Amber):** Human-in-the-loop overrides, caution alerts, permission confirmations, and critical system latency notices.
- **Neutral (`#090D16` - Deep Slate-Onyx):** The baseline canvas substrate. All layered tiers step up progressively in lightness:
  - Base Canvas: `#090D16`
  - Substrate Container: `#0F172A`
  - Elevated Card Surface: `#111827`
  - Floating Sheet Surface: `#1E293B`

### Functional Accents
- **Success (`#10B981` - Autonomous Emerald):** Successful task completion, stable telemetry, and verified tool integrations.
- **Danger (`#EF4444` - Crimson Interruption):** Critical process terminations, tool failure states, and connection drops.
- **Hairline Dividers (`rgba(51, 65, 85, 0.5)` to `rgba(30, 41, 59, 0.8)`): Subtle slate borders that provide tactile definition without visual noise.

## Typography

Typography enforces a strict cognitive separation between natural human conversation and agentic computational output:

1. **Executive Interface & Conversational Layer (Inter):** Clean, neutral, high-legibility geometric grotesque optimized for Android OLED screens. Headlines utilize tight negative tracking (`-0.02em` to `-0.025em`) to impart structural solidity and weight.
2. **Deterministic Agent Logs & Code Pipelines (JetBrains Mono):** Used exclusively for system metrics, timestamped execution traces, terminal outputs, latency badges, and parameter values. The monospace tabular figures maintain strict vertical alignment across real-time execution threads.
3. **Hierarchy Scaling:** The `headline-xl-mobile` token takes precedence on typical handheld viewports, capping oversized display sizes to prevent single-word line wraps on portrait screens.

## Layout & Spacing

The layout is built upon an Android-first **fluid column grid system** mapped to an 8px vertical baseline rhythm:

- **Mobile Viewports (<600dp):** Single-column layout with 4-column sub-grids, bounded by 16px (`1rem`) lateral screen margins and 16px (`1rem`) gutters. Content cards expand to fill full width or pair into compact metric tiles.
- **Tablet / Foldable Viewports (600dp - 1024dp):** 8-column layout with 24px (`1.5rem`) margins. Permits persistent side-by-side agent status and execution stream panels.
- **Desktop / DeX Mode (>1024dp):** 12-column layout with 48px (`3rem`) margins, anchored to a maximum content width of 1440px.

Component padding and density are strictly calibrated around rapid thumb interactions in the lower two-thirds of the viewport (the primary Android interaction zone). Interactive triggers maintain a minimum touch target bounding box of 48×48dp, even when visual glyphs are constrained to smaller spatial units.

## Elevation & Depth

Depth is established through physical light attenuation and translucent refractive glass layering, avoiding muddy opaque drop shadows:

- **Level 0 (Canvas):** Pure deep slate-onyx (`#090D16`), raw and non-reflective.
- **Level 1 (Substrate Containers):** Semi-transparent surfaces (`#111827` at 85% opacity) with `backdrop-filter: blur(16px)` and a continuous hairline stroke of `rgba(30, 41, 59, 0.7)`.
- **Level 2 (Active Cards & Floating Pods):** Elevated panels (`#1E293B` at 70% opacity) coupled with `backdrop-filter: blur(24px)`. Elevated elements cast an ambient, ultra-diffused sapphire-tinted glow (`box-shadow: 0 12px 32px -8px rgba(15, 23, 42, 0.8), 0 0 1px 1px rgba(0, 240, 255, 0.15)`).
- **Level 3 (Modal Sheets & Contextual Overlays):** Deep glass sheets floating over a darkened canvas mask (`#090D16` at 80% opacity with 8px blur). Borders receive a directional top-edge highlight using a linear gradient from `rgba(0, 240, 255, 0.35)` to `rgba(59, 130, 246, 0.05)`.
- **Agent Focus Ring:** When an autonomous task is executing, targeted cards display an active 1px perimeter border pulse transitioning smoothly between `#00F0FF` and `#3B82F6` with an inner 4px ambient haze.

## Shapes

The interface implements a refined **Level 2 (Rounded)** shape language:

- **Interactive Nodes & Inputs:** Standard elements, buttons, text fields, and segmented tabs use a base border radius of `0.5rem` (8px), maintaining precision without aggressive industrial sharpness.
- **Cards & Execution Pods:** Medium-to-large containers utilize `rounded-lg` (`1rem` / 16px), aligning naturally with Android modern hardware corner curvatures.
- **Bottom Sheets & Modal Pods:** Primary overlay surfaces scale to `rounded-xl` (`1.5rem` / 24px) along their exposed top anchors.
- **Status Pills & Telemetry Badges:** Fully circular (`rounded-full`) pill configurations to differentiate micro-status indicators and execution tags from structural UI cards.

## Components

### Buttons & Executive Triggers
- **Primary Agent Trigger:** High-contrast solid or translucent backdrop (`rgba(0, 240, 255, 0.15)`) with an electric cyan border (`#00F0FF`), white text in `Inter Medium`, and a subtle `0 0 12px rgba(0, 240, 255, 0.25)` ambient glow.
- **Secondary Action:** Titanium-slate panel (`#1E293B`) with muted slate border (`border-slate-800/80`) and sapphire text hover/pressed feedback (`#3B82F6`).
- **Emergency Halt / Override:** Frosted dark crimson glass button with high-contrast amber/crimson text, triggering immediate autonomous thread suspension.

### Input Fields & Command Oracles
- **Voice/Text Prompt Bar:** Persistent floating pill or rounded rectangular card anchored to the bottom thumb zone. Glassmorphic treatment with `backdrop-filter: blur(20px)`, dark translucent surface (`rgba(17, 24, 39, 0.85)`), and active focus ring transitioning into electric cyan.
- **Input Text:** Set in `Inter`, while placeholder hints cycle dynamically through available agent capabilities in muted titanium grey (`#64748B`).

### Chips & Telemetry Status Badges
- **Status Pill:** Compact horizontal tags containing a 6px pulsating status LED (green for active, cyan for analyzing, amber for human confirmation needed).
- **Log Chips:** Set in `JetBrains Mono` (`label-sm`), featuring low-opacity slate backgrounds (`rgba(30, 41, 59, 0.6)`) with hairline borders for displaying memory usage, token throughput, and execution latencies.

### Autonomous Action Cards
- Modular glass containers displaying real-time agent reasoning steps. Each card includes:
  - Header: Action type label (`JetBrains Mono`, cyan or sapphire).
  - Body: Reasoning summary (`Inter`, `#E2E8F0`).
  - Trace Log Drawer: Collapsible code/execution snippet container rendered with an onyx backdrop (`#05080E`) and syntax-highlighted monospace type.

### Checkboxes, Toggles & Switches
- **Switches:** Android-native thumb travel housed within a sleek capsule chassis. Off state is muted dark slate (`#1E293B`); On state illuminates with an electric cyan core and subtle sapphire outer glow.
- **Selection Nodes:** Rounded 4px checkboxes with dark titanium fill and sharp cyan checkmark vectors upon validation.

### Real-Time Waveform & Agent Aura Pod
- Dynamic speech and thinking visualization positioned along focal interaction points. Employs non-intrusive harmonic sapphire-to-cyan audio wave curves or particle rings that react to vocal input and computational thought processing.