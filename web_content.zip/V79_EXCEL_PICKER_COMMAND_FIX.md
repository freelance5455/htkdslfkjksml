# V79 — Excel Picker Command Fix

Based on V78. Both the Android asset and the web copy now use the same `dpm-import://pick` command for Choose File. The web copy no longer contains the obsolete `AndroidDPM.pickImportFile()` / bridge-missing error path. MainActivity already intercepts `dpm-import://` and launches the native Android picker. No Supabase or SQL changes.
