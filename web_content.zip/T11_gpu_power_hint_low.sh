#!/system/bin/sh
# T11_gpu_power_hint_low — GPU power hint low when screen off
MODULE_ID="T11_gpu_power_hint_low"
. "$(dirname "$0")/../../lib/core.sh"
vcg_init
apply() {
    vcg_apply_or_skip T11_ENABLED || return 0
    vcg_dc_put activity_manager_native_boot gpu_power_hint_low 1
}
revert() { vcg_log INFO "revert T11_gpu_power_hint_low: transient"; }
case "${1:-apply}" in apply) apply ;; revert) revert ;; *) exit 1 ;; esac
