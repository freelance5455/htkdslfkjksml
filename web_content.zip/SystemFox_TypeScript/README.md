# System Fox — projeto TypeScript

Esta pasta contém a migração do System Fox para fontes `.ts`, com os sistemas organizados em arquivos separados.

## O que foi alterado
- Os scripts originais foram separados em `src/boot.ts`, `src/core-megadrive.ts`, `src/core-gbc.ts`, `src/core-gba.ts`, `src/core-snes.ts`, `src/core-runtime.ts`, `src/layout.ts` e `src/interface.ts`, preservando a ordem de execução usada pelo projeto.
- Os núcleos Mega Drive, Game Boy, Game Boy Color, Game Boy Advance e SNES permanecem no projeto.
- O HTML carrega `dist/systemfox.js`, que é gerado pelo compilador TypeScript.
- O suporte ao Nintendo DS foi removido: núcleo DeSmuME/EmulatorJS, ROM `.nds`, metadados e configurações específicas. Há apenas uma rotina de migração que apaga do IndexedDB uma antiga tabela `dsroms` de versões anteriores.
- Não há diretivas `@ts-nocheck` ou `@ts-ignore`, nem usos explícitos de `any`, nos fontes.

## Verificação e compilação

Com Node.js instalado, dentro desta pasta execute:

```sh
npm install
npm run check
npm run build
```

`npm run check` verifica os tipos com as verificações estritas do TypeScript ativas. `npm run build` gera `dist/systemfox.js`. Para manter compatibilidade com trechos herdados do JavaScript original, `strictNullChecks` permanece desativado: uma auditoria com essa opção ativada ainda encontra 153 diagnósticos de possíveis valores `null`/`undefined` que precisam de tratamento individual. Portanto, o projeto compila sem erros na configuração atual, mas ainda não está no nível máximo de segurança de tipos.

Abra `index.html` por um servidor HTTP local para executar no Chrome.

## Android / Termux

Com Node.js instalado no Termux:

```sh
cd SystemFox_TypeScript
npm install
npm run build
npx http-server . -p 8080
```

Depois abra `http://localhost:8080` no Chrome.

## Observações sobre a migração

O Chrome não executa arquivos `.ts` diretamente. O navegador utiliza o JavaScript compilado em `dist/`; os arquivos `.ts` são os fontes editáveis do projeto.

As verificações de tipos da configuração atual, a ausência de usos explícitos de `any` nos fontes, a compilação e a sintaxe do JavaScript gerado foram verificadas com sucesso. Ainda faltam testes práticos de funcionamento dos jogos, controles, salvamentos e áudio no Chrome e em um aparelho Android. Compilar sem erros não garante, por si só, que todos os jogos estejam funcionando corretamente.
