// System Fox — Game Boy / Game Boy Color (TypeScript)

/* ---------- Game Boy Color: núcleo próprio (CPU, vídeo, som, cartuchos) ---------- */
// Roda dentro de um iframe isolado: não divide variáveis, laço nem áudio com o núcleo do Mega Drive.
function gbChild(){
"use strict";
function P(m:Record<string, unknown>):void{try{parent.postMessage(m,"*")}catch(e){}}
var cv=document.getElementById("c") as HTMLCanvasElement,vx=cv.getContext("2d"),oc=document.createElement("canvas");oc.width=160;oc.height=144;
var ox=oc.getContext("2d"),img=ox.createImageData(160,144),fb=new Uint32Array(img.data.buffer);
var gid=0,run=0,paused=0,stopped=0,ffm=1,lastT=0,todo=0,fr=0,offC=0,dirty=0,vw=160,vh=144,ac:AudioContext|null=null,sp:ScriptProcessorNode|null=null;
var rom=new Uint8Array(0),romMask=1,rb=1,ram:Uint8Array|null=null,ramMask=0,ramOn=0,ramB=0,mbc=0,hiB=0,loB=1,mode1=0,rb5=1,lastL=0,rtcR=[0,0,0,0,0],rtcBase=Date.now();
var cgb=0,vb=0,wb=1,vram=new Uint8Array(0x4000),wram=new Uint8Array(0x8000),oam=new Uint8Array(160),hram=new Uint8Array(128),io=new Uint8Array(128),ie=0;
var bgPal=new Uint8Array(64).fill(255),obPal=new Uint8Array(64).fill(255);
var A=0,F=0,B=0,C=0,D=0,E=0,H=0,L=0,SP=0,PC=0,ime=0,imeD=0,halted=0,hbug=0,dbl=0,div=0,tcnt=0;
var ly=0,mode=2,lcnt=0,wly=0,sl=0,jp=0,hOn=0,hLeft=0,hs=0,hd=0,bgi=new Uint8Array(160),bgp=new Uint8Array(160);
var tbl=new Uint32Array(32768),dmgc=[0xFFD0F8E0,0xFF70C088,0xFF566834,0xFF201808];
for(var i=0;i<32768;i++){var r5=i&31,g5=(i>>5)&31,b5=(i>>10)&31;tbl[i]=(0xFF000000|(((b5<<3)|(b5>>2))<<16)|(((g5<<3)|(g5>>2))<<8)|((r5<<3)|(r5>>2)))>>>0}
var TP=[1024,16,64,256];

/* ---- memória ---- */
function rd(a:number):number{
switch(a>>12){
case 0:case 1:case 2:case 3:return rom[a];
case 4:case 5:case 6:case 7:return rom[(rb<<14)|(a&0x3FFF)];
case 8:case 9:return vram[(vb<<13)|(a&0x1FFF)];
case 10:case 11:
if(!ramOn||!ram)return 255;
if(mbc===3&&ramB>7)return rtcR[ramB-8]|0;
if(mbc===2)return ram[a&0x1FF]|0xF0;
return ram[(((mbc===3?ramB&3:ramB)<<13)|(a&0x1FFF))&ramMask];
case 12:case 14:return wram[a&0xFFF];
case 13:return wram[(wb<<12)|(a&0xFFF)];
default:
if(a<0xFE00)return wram[(wb<<12)|(a&0xFFF)];
if(a<0xFEA0)return oam[a-0xFE00];
if(a<0xFF00)return 255;
if(a<0xFF80)return rio(a&0x7F);
return a===0xFFFF?ie:hram[a-0xFF80]}}
function wr(a:number,v:number):void{
switch(a>>12){
case 0:case 1:case 2:case 3:case 4:case 5:case 6:case 7:mbcW(a,v);return;
case 8:case 9:vram[(vb<<13)|(a&0x1FFF)]=v;return;
case 10:case 11:
if(!ramOn||!ram)return;
if(mbc===3&&ramB>7){rtcR[ramB-8]=v;var s=rtcR[0]+rtcR[1]*60+rtcR[2]*3600+(rtcR[3]|((rtcR[4]&1)<<8))*86400;rtcBase=Date.now()-s*1000;dirty=1;return}
if(mbc===2)ram[a&0x1FF]=v&15;else ram[(((mbc===3?ramB&3:ramB)<<13)|(a&0x1FFF))&ramMask]=v;
dirty=1;return;
case 12:case 14:wram[a&0xFFF]=v;return;
case 13:wram[(wb<<12)|(a&0xFFF)]=v;return;
default:
if(a<0xFE00)wram[(wb<<12)|(a&0xFFF)]=v;
else if(a<0xFEA0)oam[a-0xFE00]=v;
else if(a<0xFF00)return;
else if(a<0xFF80)wio(a&0x7F,v);
else if(a===0xFFFF)ie=v;
else hram[a-0xFF80]=v}}
function rd16(a:number):number{return rd(a)|(rd((a+1)&0xFFFF)<<8)}
function mbcW(a:number,v:number):void{
switch(mbc){
case 1:
if(a<0x2000)ramOn=(v&15)===10?1:0;
else if(a<0x4000)loB=(v&31)||1;
else if(a<0x6000)hiB=v&3;
else mode1=v&1;
rb=((hiB<<5)|loB)&romMask;ramB=mode1?hiB:0;return;
case 2:if(a<0x4000){if(a&0x100)rb=((v&15)||1)&romMask;else ramOn=(v&15)===10?1:0}return;
case 3:
if(a<0x2000)ramOn=(v&15)===10?1:0;
else if(a<0x4000)rb=((v&127)||1)&romMask;
else if(a<0x6000)ramB=v;
else{if(v===1&&lastL===0)rtcLatch();lastL=v}
return;
case 5:
if(a<0x2000)ramOn=(v&15)===10?1:0;
else if(a<0x3000){rb5=(rb5&0x100)|v;rb=rb5&romMask}
else if(a<0x4000){rb5=(rb5&255)|((v&1)<<8);rb=rb5&romMask}
else if(a<0x6000)ramB=v&15;
return}}
function rtcLatch(){var s=Math.floor((Date.now()-rtcBase)/1000),d=Math.floor(s/86400);rtcR=[s%60,Math.floor(s/60)%60,Math.floor(s/3600)%24,d&255,((d>>8)&1)|(d>511?128:0)]}

/* ---- registradores de E/S ---- */
var AM=[0x80,0x3F,0,0xFF,0xBF,0xFF,0x3F,0,0xFF,0xBF,0x7F,0xFF,0x9F,0xFF,0xBF,0xFF,0xFF,0,0,0xBF,0,0,0x70];
function rio(r:number):number{
switch(r){
case 0:var s=io[0]&0x30,v=0x0F;if(!(s&16))v&=~(jp&15);if(!(s&32))v&=~((jp>>4)&15);return 0xC0|s|v;
case 4:return (div>>8)&255;
case 15:return io[15]|0xE0;
case 0x41:return 0x80|(io[0x41]&0x78)|(io[0x40]&128?((ly===io[0x45]?4:0)|mode):0);
case 0x44:return ly;
case 0x4D:return cgb?(0x7E|(dbl<<7)|(io[0x4D]&1)):255;
case 0x4F:return cgb?(0xFE|vb):255;
case 0x55:return hOn?((hLeft-1)&0x7F):255;
case 0x69:return cgb?bgPal[io[0x68]&0x3F]:255;
case 0x6B:return cgb?obPal[io[0x6A]&0x3F]:255;
case 0x70:return cgb?(0xF8|wb):255;
case 0x26:return (io[0x26]&0x80)|0x70|(c1.on?1:0)|(c2.on?2:0)|(c3.on?4:0)|(c4.on?8:0)}
if(r>=0x10&&r<=0x26)return io[r]|AM[r-0x10];
return io[r]}
function wio(r:number,v:number):void{
switch(r){
case 0:io[0]=v&0x30;return;
case 2:if((v&0x81)===0x81){io[1]=255;io[2]=v&0x7F;io[15]|=8}else io[2]=v;return;
case 4:div=0;return;
case 7:io[7]=v&7;return;
case 15:io[15]=v&31;return;
case 0x40:
if(!(v&128)&&(io[0x40]&128)){ly=0;mode=0;lcnt=0;wly=0;sl=0}
else if((v&128)&&!(io[0x40]&128)){ly=0;mode=2;lcnt=0;wly=0;offC=0}
io[0x40]=v;stat();return;
case 0x41:io[0x41]=v&0x78;stat();return;
case 0x44:return;
case 0x45:io[0x45]=v;stat();return;
case 0x46:{var s=v<<8;if(s>=0xE000)s-=0x2000;for(var i=0;i<160;i++)oam[i]=rd(s+i);io[0x46]=v;return}
case 0x4D:io[0x4D]=(io[0x4D]&0x80)|(v&1);return;
case 0x4F:if(cgb)vb=v&1;return;
case 0x55:hdma(v);return;
case 0x68:io[0x68]=v;return;
case 0x6A:io[0x6A]=v;return;
case 0x69:if(cgb){bgPal[io[0x68]&0x3F]=v;if(io[0x68]&128)io[0x68]=128|((io[0x68]+1)&0x3F)}return;
case 0x6B:if(cgb){obPal[io[0x6A]&0x3F]=v;if(io[0x6A]&128)io[0x6A]=128|((io[0x6A]+1)&0x3F)}return;
case 0x70:if(cgb)wb=(v&7)||1;return}
if(r>=0x10&&r<=0x3F){apuW(r,v);return}
io[r]=v}
function hdma(v:number):void{
if(!cgb)return;
if(hOn&&!(v&128)){hOn=0;return}
hs=((io[0x51]<<8)|(io[0x52]&0xF0))&0xFFF0;hd=(((io[0x53]&0x1F)<<8)|(io[0x54]&0xF0))&0x1FF0;
var n=(v&0x7F)+1;
if(v&128){hOn=1;hLeft=n}else{for(var i=0;i<n*16;i++){vram[(vb<<13)|((hd+i)&0x1FFF)]=rd((hs+i)&0xFFFF)}hs+=n*16;hd+=n*16;io[0x51]=(hs>>8)&255;io[0x52]=hs&255;hOn=0}}
function hdmaBlk(){
for(var i=0;i<16;i++)vram[(vb<<13)|((hd+i)&0x1FFF)]=rd((hs+i)&0xFFFF);
hs=(hs+16)&0xFFFF;hd=(hd+16)&0x1FFF;if(--hLeft<=0){hOn=0;hLeft=0}}

/* ---- vídeo ---- */
function stat(){
var s=io[0x41],l=((s&8)&&mode===0)||((s&16)&&mode===1)||((s&32)&&mode===2)||((s&64)&&ly===io[0x45]);
if(l&&!sl)io[15]|=2;sl=l?1:0}
function ppu(c:number):void{
if(!(io[0x40]&128)){offC+=c;if(offC>=70224){offC-=70224;for(var q=0;q<23040;q++)fb[q]=dmgc[0];fr=1}return}
lcnt+=c;
for(;;){
if(mode===2){if(lcnt<80)break;mode=3}
else if(mode===3){if(lcnt<252)break;mode=0;line();if(hOn&&ly<144)hdmaBlk()}
else if(mode===0){if(lcnt<456)break;lcnt-=456;ly++;if(ly===144){mode=1;io[15]|=1;fr=1}else mode=2}
else{if(lcnt<456)break;lcnt-=456;ly++;if(ly>153){ly=0;mode=2;wly=0}}
stat()}}
function line(){
var y=ly,lc=io[0x40],base=y*160,x,bgOn=cgb||(lc&1),scx=io[0x43],scy=io[0x42],wx=io[0x4B]-7,wy=io[0x4A];
var winOn=bgOn&&(lc&32)&&y>=wy&&io[0x4B]<=166,mapB=(lc&8)?0x1C00:0x1800,wmB=(lc&64)?0x1C00:0x1800,uns=lc&16,bgp0=io[0x47];
if(!bgOn){var z=dmgc[bgp0&3];for(x=0;x<160;x++){fb[base+x]=z;bgi[x]=0;bgp[x]=0}}
else{
for(x=0;x<160;x++){
var inW=winOn&&x>=wx,mx,my,mb;
if(inW){mx=x-wx;my=wly;mb=wmB}else{mx=(x+scx)&255;my=(y+scy)&255;mb=mapB}
var ti=mb+((my>>3)<<5)+(mx>>3),tn=vram[ti],at=cgb?vram[0x2000+ti]:0;
var ta=uns?tn*16:0x1000+((tn<<24)>>24)*16,ty=my&7;
if(at&0x40)ty=7-ty;
ta+=((at&8)?0x2000:0)+ty*2;
var lo=vram[ta],hi=vram[ta+1],bit=(at&0x20)?(mx&7):7-(mx&7),ci=(((hi>>bit)&1)<<1)|((lo>>bit)&1);
if(cgb){var j=(at&7)*8+ci*2;fb[base+x]=tbl[(bgPal[j]|(bgPal[j+1]<<8))&0x7FFF]}
else fb[base+x]=dmgc[(bgp0>>(ci*2))&3];
bgi[x]=ci;bgp[x]=(at&0x80)?1:0}
if(winOn&&wx<160)wly++}
if(lc&2){
var h=(lc&4)?16:8,n=0,spr=[],i,k,px;
for(i=0;i<40&&n<10;i++){var sy=oam[i*4]-16;if(y>=sy&&y<sy+h){spr.push(i);n++}}
if(!cgb)spr.sort(function(a,b){return (oam[a*4+1]-oam[b*4+1])||(a-b)});
for(k=spr.length-1;k>=0;k--){
i=spr[k];var sy2=oam[i*4]-16,sx=oam[i*4+1]-8,tn2=oam[i*4+2],at2=oam[i*4+3];
if(h===16)tn2&=0xFE;
var ty2=y-sy2;if(at2&0x40)ty2=h-1-ty2;
var ta2=((cgb&&(at2&8))?0x2000:0)+tn2*16+ty2*2,lo2=vram[ta2],hi2=vram[ta2+1];
for(px=0;px<8;px++){
x=sx+px;if(x<0||x>=160)continue;
var bt=(at2&0x20)?px:7-px,ci2=(((hi2>>bt)&1)<<1)|((lo2>>bt)&1);
if(!ci2)continue;
if(cgb){if((lc&1)&&bgi[x]&&((at2&0x80)||bgp[x]))continue;var j2=(at2&7)*8+ci2*2;fb[base+x]=tbl[(obPal[j2]|(obPal[j2+1]<<8))&0x7FFF]}
else{if((at2&0x80)&&bgi[x])continue;fb[base+x]=dmgc[(io[(at2&0x10)?0x49:0x48]>>(ci2*2))&3]}}}}}

/* ---- som ---- */
var DUTY=[1,0x81,0x87,0x7E],NDIV=[8,16,32,48,64,80,96,112],pw=0,fs=0,fsC=0,smC=0,rate=44100,hpl=0,hpr=0,lfsr=0x7FFF;
var bl=new Float32Array(16384),brr=new Float32Array(16384),wp=0,rp=0,lastL2=0,lastR2=0;
function mkc():GBCChannelState{return{on:0,dac:0,len:0,lenOn:0,freq:0,tmr:0,pos:0,duty:0,vol:0,iv:0,eD:0,eP:0,eT:0,sP:0,sD:0,sS:0,sT:0,sOn:0,sh:0}}
var c1:GBCChannelState=mkc(),c2:GBCChannelState=mkc(),c3:GBCChannelState=mkc(),c4:GBCChannelState=mkc();
function swCalc(c:GBCChannelState):number{var n=c.sh>>c.sS;n=c.sD?c.sh-n:c.sh+n;if(n>2047)c.on=0;return n}
function trg(c:GBCChannelState,ln:number,sw:number):void{
c.on=c.dac?1:0;if(!c.len)c.len=ln;
if(c===c3){c.tmr=(2048-c.freq)*2;c.pos=0}
else if(c===c4){c.tmr=NDIV[io[0x22]&7]<<(io[0x22]>>4);lfsr=0x7FFF;c.vol=c.iv;c.eT=c.eP||8}
else{c.tmr=(2048-c.freq)*4;c.vol=c.iv;c.eT=c.eP||8}
if(sw){c.sh=c.freq;c.sT=c.sP||8;c.sOn=(c.sP||c.sS)?1:0;if(c.sS)swCalc(c)}}
function apuW(r:number,v:number):void{
if(r>=0x30){io[r]=v;return}
if(r===0x26){var p=(v>>7)&1;if(!p&&pw){for(var q=0x10;q<0x26;q++)io[q]=0;c1=mkc();c2=mkc();c3=mkc();c4=mkc()}if(p&&!pw)fs=0;pw=p;io[0x26]=v&0x80;return}
if(!pw)return;
io[r]=v;
switch(r){
case 0x10:c1.sP=(v>>4)&7;c1.sD=(v>>3)&1;c1.sS=v&7;break;
case 0x11:c1.duty=v>>6;c1.len=64-(v&63);break;
case 0x12:c1.iv=v>>4;c1.eD=(v>>3)&1;c1.eP=v&7;c1.dac=(v&0xF8)?1:0;if(!c1.dac)c1.on=0;break;
case 0x13:c1.freq=(c1.freq&0x700)|v;break;
case 0x14:c1.freq=(c1.freq&255)|((v&7)<<8);c1.lenOn=(v>>6)&1;if(v&128)trg(c1,64,1);break;
case 0x16:c2.duty=v>>6;c2.len=64-(v&63);break;
case 0x17:c2.iv=v>>4;c2.eD=(v>>3)&1;c2.eP=v&7;c2.dac=(v&0xF8)?1:0;if(!c2.dac)c2.on=0;break;
case 0x18:c2.freq=(c2.freq&0x700)|v;break;
case 0x19:c2.freq=(c2.freq&255)|((v&7)<<8);c2.lenOn=(v>>6)&1;if(v&128)trg(c2,64,0);break;
case 0x1A:c3.dac=(v>>7)&1;if(!c3.dac)c3.on=0;break;
case 0x1B:c3.len=256-v;break;
case 0x1D:c3.freq=(c3.freq&0x700)|v;break;
case 0x1E:c3.freq=(c3.freq&255)|((v&7)<<8);c3.lenOn=(v>>6)&1;if(v&128)trg(c3,256,0);break;
case 0x20:c4.len=64-(v&63);break;
case 0x21:c4.iv=v>>4;c4.eD=(v>>3)&1;c4.eP=v&7;c4.dac=(v&0xF8)?1:0;if(!c4.dac)c4.on=0;break;
case 0x23:c4.lenOn=(v>>6)&1;if(v&128)trg(c4,64,0);break}}
function lenClk(c:GBCChannelState):void{if(c.lenOn&&c.len>0&&--c.len===0)c.on=0}
function envClk(c:GBCChannelState):void{if(!c.eP)return;if(--c.eT<=0){c.eT=c.eP;if(c.eD){if(c.vol<15)c.vol++}else if(c.vol>0)c.vol--}}
function fsStep(){
var s=fs;fs=(fs+1)&7;
if(!(s&1)){lenClk(c1);lenClk(c2);lenClk(c3);lenClk(c4)}
if(s===2||s===6){var c=c1;if(--c.sT<=0){c.sT=c.sP||8;if(c.sOn&&c.sP){var n=swCalc(c);if(n<=2047&&c.sS){c.freq=c.sh=n;swCalc(c)}}}}
if(s===7){envClk(c1);envClk(c2);envClk(c4)}}
function apuStep(c:number):void{
if(!pw)return;
fsC+=c;while(fsC>=8192){fsC-=8192;fsStep()}
c1.tmr-=c;while(c1.tmr<=0){c1.tmr+=(2048-c1.freq)*4;c1.pos=(c1.pos+1)&7}
c2.tmr-=c;while(c2.tmr<=0){c2.tmr+=(2048-c2.freq)*4;c2.pos=(c2.pos+1)&7}
c3.tmr-=c;while(c3.tmr<=0){c3.tmr+=(2048-c3.freq)*2;c3.pos=(c3.pos+1)&31}
c4.tmr-=c;
while(c4.tmr<=0){var q=io[0x22];c4.tmr+=NDIV[q&7]<<(q>>4);var x=(lfsr&1)^((lfsr>>1)&1);lfsr=(lfsr>>1)|(x<<14);if(q&8)lfsr=(lfsr&~0x40)|(x<<6)}
if(ffm===1&&ac){smC+=c*rate;while(smC>=4194304){smC-=4194304;mix()}}}
function mix(){
var l=0,r=0,n=io[0x25],o,a;
if(c1.on&&c1.dac){a=((DUTY[c1.duty]>>(7-c1.pos))&1)*c1.vol/7.5-1;if(n&1)r+=a;if(n&16)l+=a}
if(c2.on&&c2.dac){a=((DUTY[c2.duty]>>(7-c2.pos))&1)*c2.vol/7.5-1;if(n&2)r+=a;if(n&32)l+=a}
if(c3.on&&c3.dac){var by=io[0x30+(c3.pos>>1)];o=((c3.pos&1)?by&15:by>>4)>>[4,0,1,2][(io[0x1C]>>5)&3];a=o/7.5-1;if(n&4)r+=a;if(n&64)l+=a}
if(c4.on&&c4.dac){a=(~lfsr&1)*c4.vol/7.5-1;if(n&8)r+=a;if(n&128)l+=a}
var m=io[0x24];l*=(((m>>4)&7)+1)/32;r*=((m&7)+1)/32;
var ol=l-hpl;hpl=l-ol*0.996;var or2=r-hpr;hpr=r-or2*0.996;
bl[wp]=ol;brr[wp]=or2;wp=(wp+1)&16383;if(wp===rp)rp=(rp+1)&16383}
function initAudio(){
try{var AC=window.AudioContext||window.webkitAudioContext;ac=new AC({latencyHint:"interactive"});rate=ac.sampleRate;
sp=ac.createScriptProcessor(2048,0,2);
sp.onaudioprocess=function(e){var L2=e.outputBuffer.getChannelData(0),R2=e.outputBuffer.getChannelData(1);
for(var i=0;i<L2.length;i++){if(rp!==wp){lastL2=bl[rp];lastR2=brr[rp];rp=(rp+1)&16383}else{lastL2*=0.98;lastR2*=0.98}L2[i]=lastL2;R2[i]=lastR2}};
sp.connect(ac.destination)}catch(x){ac=null}}
function wake(){try{if(ac&&ac.state==="suspended")ac.resume()}catch(e){}}

/* ---- CPU (SM83) ---- */
function g8(i:number):number{switch(i){case 0:return B;case 1:return C;case 2:return D;case 3:return E;case 4:return H;case 5:return L;case 6:return rd((H<<8)|L);default:return A}}
function s8(i:number,v:number):void{switch(i){case 0:B=v;break;case 1:C=v;break;case 2:D=v;break;case 3:E=v;break;case 4:H=v;break;case 5:L=v;break;case 6:wr((H<<8)|L,v);break;default:A=v}}
function g16(i:number):number{switch(i){case 0:return (B<<8)|C;case 1:return (D<<8)|E;case 2:return (H<<8)|L;default:return SP}}
function s16(i:number,v:number):void{switch(i){case 0:B=v>>8;C=v&255;break;case 1:D=v>>8;E=v&255;break;case 2:H=v>>8;L=v&255;break;default:SP=v}}
function push(v:number):void{SP=(SP-1)&0xFFFF;wr(SP,v>>8);SP=(SP-1)&0xFFFF;wr(SP,v&255)}
function pop(){var v=rd(SP);SP=(SP+1)&0xFFFF;v|=rd(SP)<<8;SP=(SP+1)&0xFFFF;return v}
function cc(c:number):boolean{switch(c){case 0:return !(F&128);case 1:return !!(F&128);case 2:return !(F&16);default:return !!(F&16)}}
function alu(o:number,v:number):void{
var a=A,r,c;
switch(o){
case 0:r=a+v;F=((r&255)?0:128)|(((a&15)+(v&15))>15?32:0)|(r>255?16:0);A=r&255;break;
case 1:c=(F>>4)&1;r=a+v+c;F=((r&255)?0:128)|(((a&15)+(v&15)+c)>15?32:0)|(r>255?16:0);A=r&255;break;
case 2:r=a-v;F=64|((r&255)?0:128)|(((a&15)-(v&15))<0?32:0)|(r<0?16:0);A=r&255;break;
case 3:c=(F>>4)&1;r=a-v-c;F=64|((r&255)?0:128)|(((a&15)-(v&15)-c)<0?32:0)|(r<0?16:0);A=r&255;break;
case 4:A=a&v;F=A?32:160;break;
case 5:A=a^v;F=A?0:128;break;
case 6:A=a|v;F=A?0:128;break;
default:r=a-v;F=64|((r&255)?0:128)|(((a&15)-(v&15))<0?32:0)|(r<0?16:0)}}
function rot(y:number,v:number):number{
var c;
switch(y){
case 0:c=v>>7;v=((v<<1)|c)&255;break;
case 1:c=v&1;v=(v>>1)|(c<<7);break;
case 2:c=v>>7;v=((v<<1)|((F>>4)&1))&255;break;
case 3:c=v&1;v=(v>>1)|(((F>>4)&1)<<7);break;
case 4:c=v>>7;v=(v<<1)&255;break;
case 5:c=v&1;v=(v>>1)|(v&128);break;
case 6:c=0;v=((v<<4)|(v>>4))&255;break;
default:c=v&1;v=v>>1}
F=(v?0:128)|(c?16:0);return v}
function cpu(){
if(imeD>0){if(--imeD===0)ime=1}
var pend=io[15]&ie&31,op,a,e,v,r;
if(pend){halted=0;if(ime){ime=0;hbug=0;var i=0;while(!(pend&(1<<i)))i++;io[15]&=~(1<<i);push(PC);PC=0x40+i*8;return 20}}
if(halted)return 4;
op=rd(PC);if(hbug)hbug=0;else PC=(PC+1)&0xFFFF;
switch(op>>6){
case 1:
if(op===0x76){if(!ime&&pend)hbug=1;else halted=1;return 4}
s8((op>>3)&7,g8(op&7));return ((op&7)===6||((op>>3)&7)===6)?8:4;
case 2:alu((op>>3)&7,g8(op&7));return (op&7)===6?8:4;
case 0:
switch(op&7){
case 0:
if(op===0)return 4;
if(op===8){a=rd16(PC);PC=(PC+2)&0xFFFF;wr(a,SP&255);wr((a+1)&0xFFFF,SP>>8);return 20}
if(op===0x10){PC=(PC+1)&0xFFFF;if(cgb&&(io[0x4D]&1)){dbl^=1;io[0x4D]&=0xFE;div=0}return 4}
e=(rd(PC)<<24)>>24;PC=(PC+1)&0xFFFF;
if(op===0x18||cc((op>>3)&3)){PC=(PC+e)&0xFFFF;return 12}return 8;
case 1:
if(op&8){v=g16((op>>4)&3);a=g16(2);r=a+v;F=(F&128)|(((a&0xFFF)+(v&0xFFF))>0xFFF?32:0)|(r>0xFFFF?16:0);s16(2,r&0xFFFF);return 8}
s16((op>>4)&3,rd16(PC));PC=(PC+2)&0xFFFF;return 12;
case 2:
switch(op>>4){case 0:a=(B<<8)|C;break;case 1:a=(D<<8)|E;break;default:a=(H<<8)|L}
if(op&8)A=rd(a);else wr(a,A);
if((op>>4)===2){a=(a+1)&0xFFFF;H=a>>8;L=a&255}else if((op>>4)===3){a=(a-1)&0xFFFF;H=a>>8;L=a&255}
return 8;
case 3:a=(op>>4)&3;v=g16(a);s16(a,(op&8)?(v-1)&0xFFFF:(v+1)&0xFFFF);return 8;
case 4:r=(op>>3)&7;v=(g8(r)+1)&255;F=(F&16)|(v?0:128)|((v&15)===0?32:0);s8(r,v);return r===6?12:4;
case 5:r=(op>>3)&7;v=(g8(r)-1)&255;F=(F&16)|64|(v?0:128)|((v&15)===15?32:0);s8(r,v);return r===6?12:4;
case 6:r=(op>>3)&7;s8(r,rd(PC));PC=(PC+1)&0xFFFF;return r===6?12:8;
default:
switch(op){
case 0x07:case 0x0F:case 0x17:case 0x1F:A=rot((op>>3)&3,A);F&=16;return 4;
case 0x27:
a=A;
if(!(F&64)){if((F&16)||a>0x99){a+=0x60;F|=16}if((F&32)||(a&15)>9)a+=6}
else{if(F&16)a-=0x60;if(F&32)a-=6}
A=a&255;F=(F&0x50)|(A?0:128);return 4;
case 0x2F:A^=255;F|=0x60;return 4;
case 0x37:F=(F&128)|16;return 4;
default:F=(F&128)|((F&16)^16);return 4}}
default:
switch(op&7){
case 0:
if(op<0xE0){if(cc((op>>3)&3)){PC=pop();return 20}return 8}
if(op===0xE0){wr(0xFF00|rd(PC),A);PC=(PC+1)&0xFFFF;return 12}
if(op===0xF0){A=rd(0xFF00|rd(PC));PC=(PC+1)&0xFFFF;return 12}
e=(rd(PC)<<24)>>24;PC=(PC+1)&0xFFFF;
F=((SP&15)+(e&15)>15?32:0)|((SP&255)+(e&255)>255?16:0);
if(op===0xE8){SP=(SP+e)&0xFFFF;return 16}
a=(SP+e)&0xFFFF;H=a>>8;L=a&255;return 12;
case 1:
if(op&8){
if(op===0xC9){PC=pop();return 16}
if(op===0xD9){PC=pop();ime=1;return 16}
if(op===0xE9){PC=(H<<8)|L;return 4}
SP=(H<<8)|L;return 8}
v=pop();a=(op>>4)&3;if(a===3){A=v>>8;F=v&0xF0}else s16(a,v);return 12;
case 2:
if(op<0xE0){a=rd16(PC);PC=(PC+2)&0xFFFF;if(cc((op>>3)&3)){PC=a;return 16}return 12}
if(op===0xE2){wr(0xFF00|C,A);return 8}
if(op===0xF2){A=rd(0xFF00|C);return 8}
a=rd16(PC);PC=(PC+2)&0xFFFF;
if(op===0xEA)wr(a,A);else A=rd(a);
return 16;
case 3:
if(op===0xC3){PC=rd16(PC);return 16}
if(op===0xCB){
op=rd(PC);PC=(PC+1)&0xFFFF;r=op&7;a=(op>>3)&7;
switch(op>>6){
case 0:s8(r,rot(a,g8(r)));return r===6?16:8;
case 1:F=(F&16)|32|(((g8(r)>>a)&1)?0:128);return r===6?12:8;
case 2:s8(r,g8(r)&~(1<<a));return r===6?16:8;
default:s8(r,g8(r)|(1<<a));return r===6?16:8}}
if(op===0xF3){ime=0;imeD=0;return 4}
if(op===0xFB){imeD=2;return 4}
return 4;
case 4:
if(op<0xE0){a=rd16(PC);PC=(PC+2)&0xFFFF;if(cc((op>>3)&3)){push(PC);PC=a;return 24}return 12}
return 4;
case 5:
if(op&8){if(op===0xCD){a=rd16(PC);PC=(PC+2)&0xFFFF;push(PC);PC=a;return 24}return 4}
a=(op>>4)&3;push(a===3?((A<<8)|F):g16(a));return 16;
case 6:alu((op>>3)&7,rd(PC));PC=(PC+1)&0xFFFF;return 8;
default:push(PC);PC=op&0x38;return 16}}}
function stepAll(){
var cy=cpu();
div=(div+cy)&0xFFFF;
if(io[7]&4){tcnt+=cy;var p=TP[io[7]&3];while(tcnt>=p){tcnt-=p;if(io[5]===255){io[5]=io[6];io[15]|=4}else io[5]++}}
var pc=dbl?cy>>1:cy;ppu(pc);apuStep(pc);return pc}

/* ---- ciclo de vida ---- */
function fit(){var k=Math.max(1,Math.floor((cv.clientWidth||160)*(window.devicePixelRatio||1)/160));vw=160*k;vh=144*k;cv.width=vw;cv.height=vh;vx.imageSmoothingEnabled=false;fr=1}
function loop(t:number):void{
if(stopped)return;
requestAnimationFrame(loop);
if(paused||!run){lastT=t;return}
var dt=t-lastT;lastT=t;if(dt>50||dt<0)dt=16.7;
todo+=dt*4194.304*ffm;if(todo>421344)todo=421344;
try{while(todo>0)todo-=stepAll()}catch(e){run=0;P({t:"fail",m:"Erro no emulador: "+(e instanceof Error ? (e instanceof Error ? e.message : String(e)) : String(e))});return}
if(fr){fr=0;ox.putImageData(img,0,0);vx.drawImage(oc,0,0,vw,vh)}}
function getSt(){return{v:1,cgb:cgb,vb:vb,wb:wb,vram:vram.slice(),wram:wram.slice(),oam:oam.slice(),hram:hram.slice(),io:io.slice(),ie:ie,bgPal:bgPal.slice(),obPal:obPal.slice(),A:A,F:F,B:B,C:C,D:D,E:E,H:H,L:L,SP:SP,PC:PC,ime:ime,imeD:imeD,halted:halted,hbug:hbug,dbl:dbl,div:div,tcnt:tcnt,ly:ly,mode:mode,lcnt:lcnt,wly:wly,sl:sl,hOn:hOn,hLeft:hLeft,hs:hs,hd:hd,rb:rb,ramOn:ramOn,ramB:ramB,hiB:hiB,loB:loB,mode1:mode1,rb5:rb5,lastL:lastL,rtcR:rtcR.slice(),rtcBase:rtcBase,ram:ram?ram.slice():null,pw:pw,fs:fs,fsC:fsC,smC:smC,lfsr:lfsr,c1:Object.assign({},c1),c2:Object.assign({},c2),c3:Object.assign({},c3),c4:Object.assign({},c4)}}
function setSt(s:GBCStateSnapshot):void{if(!s||s.v!==1||!s.vram)throw new Error("estado inválido");cgb=s.cgb;vb=s.vb;wb=s.wb;vram.set(s.vram);wram.set(s.wram);oam.set(s.oam);hram.set(s.hram);io.set(s.io);ie=s.ie;bgPal.set(s.bgPal);obPal.set(s.obPal);A=s.A;F=s.F;B=s.B;C=s.C;D=s.D;E=s.E;H=s.H;L=s.L;SP=s.SP;PC=s.PC;ime=s.ime;imeD=s.imeD;halted=s.halted;hbug=s.hbug;dbl=s.dbl;div=s.div;tcnt=s.tcnt;ly=s.ly;mode=s.mode;lcnt=s.lcnt;wly=s.wly;sl=s.sl;hOn=s.hOn;hLeft=s.hLeft;hs=s.hs;hd=s.hd;rb=s.rb;ramOn=s.ramOn;ramB=s.ramB;hiB=s.hiB;loB=s.loB;mode1=s.mode1;rb5=s.rb5;lastL=s.lastL;rtcR=s.rtcR.slice();rtcBase=s.rtcBase;if(ram&&s.ram)ram.set(s.ram.subarray(0,ram.length));pw=s.pw;fs=s.fs;fsC=s.fsC;smC=s.smC;lfsr=s.lfsr;Object.assign(c1,s.c1);Object.assign(c2,s.c2);Object.assign(c3,s.c3);Object.assign(c4,s.c4);todo=0;dirty=1;fr=1}
function sramMsg(){if(!ram)return;P({k:"gbc-sram",t:"sram",id:gid,rec:{ram:ram.slice(),rtc:rtcBase}});dirty=0}
function load(buf:Uint8Array,sav:GBCBatterySave|null):void{
if(!buf||buf.length<0x150)throw new Error("arquivo pequeno demais para ser uma ROM");
var ct=buf[0x147],n=1;while(n<buf.length)n<<=1;if(n<0x8000)n=0x8000;
rom=new Uint8Array(n);rom.set(buf);romMask=(n>>14)-1;
cgb=(buf[0x143]&0x80)?1:0;
mbc=ct===0?0:ct<=3?1:(ct===5||ct===6)?2:(ct>=0x0F&&ct<=0x13)?3:(ct>=0x19&&ct<=0x1E)?5:1;
var rs=[0,0x800,0x2000,0x8000,0x20000,0x10000][buf[0x149]]||0;if(mbc===2)rs=512;
ramMask=rs?rs-1:0;ram=rs?new Uint8Array(rs):null;
if(sav&&sav.ram&&ram){ram.set(sav.ram.length>ram.length?sav.ram.subarray(0,ram.length):sav.ram)}
if(sav&&sav.rtc)rtcBase=sav.rtc;
rb=1&romMask;
if(cgb){A=0x11;F=0x80;B=0;C=0;D=0xFF;E=0x56;H=0;L=0x0D}else{A=1;F=0xB0;B=0;C=0x13;D=0;E=0xD8;H=1;L=0x4D}
SP=0xFFFE;PC=0x100;div=0xABCC;
io[0x40]=0x91;io[0x47]=0xFC;io[0x48]=0xFF;io[0x49]=0xFF;io[0x41]=0x85;io[15]=0xE1;io[0x24]=0x77;io[0x25]=0xF3;io[0x26]=0x80;pw=1;
for(var i=0;i<16;i++)io[0x30+i]=(i&1)?0xFF:0x00;
for(var q=0;q<23040;q++)fb[q]=dmgc[0]}
async function unzip(u:Uint8Array):Promise<Uint8Array|null>{
var dv=new DataView(u.buffer,u.byteOffset,u.byteLength),e=u.length-22;
while(e>=0&&dv.getUint32(e,true)!==0x06054b50)e--;
if(e<0)return null;
var n=dv.getUint16(e+10,true),o=dv.getUint32(e+16,true);
for(var i=0;i<n;i++){
if(dv.getUint32(o,true)!==0x02014b50)break;
var m=dv.getUint16(o+10,true),cs=dv.getUint32(o+20,true),nl=dv.getUint16(o+28,true),xl=dv.getUint16(o+30,true),cl=dv.getUint16(o+32,true),lo=dv.getUint32(o+42,true);
var name=new TextDecoder().decode(u.subarray(o+46,o+46+nl));o+=46+nl+xl+cl;
if(/\.(gbc?|sgb)$/i.test(name)){
var ln=dv.getUint16(lo+26,true),lx=dv.getUint16(lo+28,true),ds=lo+30+ln+lx,data=u.subarray(ds,ds+cs);
if(m===0)return data.slice();
if(m===8)return new Uint8Array(await new Response(new Blob([data]).stream().pipeThrough(new DecompressionStream("deflate-raw"))).arrayBuffer())}}
return null}
var started=0;
async function init(d:GBCInitMessage):Promise<void>{
if(started)return;started=1;
try{
var buf=new Uint8Array(await new Response(d.blob).arrayBuffer());
if(buf[0]===0x50&&buf[1]===0x4B){buf=await unzip(buf);if(!buf)throw new Error("o ZIP não tem um .gb/.gbc dentro")}
gid=d.id;load(buf,d.sram);initAudio();fit();
setInterval(function(){if(dirty&&!stopped)sramMsg()},5000);
run=1;lastT=performance.now();P({t:"start"});requestAnimationFrame(loop)
}catch(e){P({t:"fail",m:"Não consegui iniciar esse jogo: "+(e instanceof Error ? (e instanceof Error ? e.message : String(e)) : String(e))})}}
var KM:Record<number,number>={4:2,5:3,6:1,7:0,8:4,0:5,2:6,3:7};
addEventListener("message",function(e){
var d=e.data||{};
if(d.t==="init"){init(d)}
else if(d.t==="btn"){var b=KM[d.k];if(b!==undefined){if(d.v){jp|=1<<b;io[15]|=16}else jp&=~(1<<b)}wake()}
else if(d.t==="ff"){ffm=d.v?(d.m||4):1;todo=0}
else if(d.t==="pause"){paused=d.v?1:0;try{if(ac)d.v?ac.suspend():ac.resume()}catch(x){}if(d.v&&dirty)sramMsg()}
else if(d.t==="save"){sramMsg();setTimeout(function(){P({t:"saved"})},50)}
else if(d.t==="getst"){try{P({t:"state",data:getSt()})}catch(x){P({t:"nostate"})}}else if(d.t==="setst"){try{setSt(d.data);P({t:"stloaded",ok:1})}catch(x){P({t:"stloaded",ok:0,m:String(x instanceof Error ? x.message : String(x))})}}else if(d.t==="stop"){if(dirty||ram)sramMsg();stopped=1;run=0;try{if(sp)sp.disconnect();if(ac)ac.close()}catch(x){}}});
addEventListener("resize",fit);
window.__g={reg:function(){return{A:A,F:F,B:B,C:C,D:D,E:E,H:H,L:L,SP:SP,PC:PC,ly:ly,mode:mode,ime:ime,imeD:imeD,halted:halted,hbug:hbug,cgb:cgb,mbc:mbc}},rd:rd,wr:wr,fb:fb,run:function(n:number){var s=0;while(s<n)s+=stepAll();return s},pw:function(){return[c1.on,c2.on,c3.on,c4.on]},wp:function(){return wp}}
}
const GB_DOC='<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><style>html,body{margin:0;height:100%;background:#000;overflow:hidden}#c{display:block;width:100%;height:100%}</style></head><body><canvas id="c" width="160" height="144"></canvas><script>'+FPSJS+'<\/script><script>('+gbChild.toString()+')()<\/script></body></html>';
