// System Fox — Super Nintendo (TypeScript)

/* ---------- Super Nintendo: núcleo próprio completo: CPU 65816, PPU, DMA/HDMA, IRQ, SPC700+DSP (som), save ---------- */
const SNRE=/\.(sfc|smc|swc|fig)$/i;
function snesChild(){
var ar=new Uint8Array(65536),dsp=new Uint8Array(128),spi=[0,0,0,0],spo=[0,0,0,0],iplOn=1,sa=0,sx=0,sy=0,ssp=0,spc=0,sN=0,sV=0,sP=0,sH=0,sZ=0,sC=0,sB=0,sI=0,
tEn=[0,0,0],tDv=[256,256,256],tCt=[0,0,0],tOu=[0,0,0],tAc=[0,0,0],dAd=0,dAc=0,sbud=0,gc=0,kon=0,eOff=0,hi2=0,
IPL=[205,239,189,232,0,198,29,208,252,143,170,244,143,187,245,120,204,244,208,251,47,25,235,244,208,252,126,244,208,11,228,245,203,244,215,0,252,208,243,171,1,16,239,126,244,16,235,186,246,218,0,228,244,196,244,248,245,208,219,31,0,0,192,255],
RP=[0,2048,1536,1280,1024,768,640,512,384,320,256,192,160,128,96,80,64,48,40,32,24,20,16,12,10,8,6,5,4,3,2,1],
vAd=[0,0,0,0,0,0,0,0],vPc=[0,0,0,0,0,0,0,0],vIx=[0,0,0,0,0,0,0,0],vEn=[0,0,0,0,0,0,0,0],vSt=[0,0,0,0,0,0,0,0],vH=[0,0,0,0,0,0,0,0],vB:Int16Array[]=[],
hL=new Int32Array(8),hR=new Int32Array(8),QL=new Float32Array(16384),QR=new Float32Array(16384),qw=0,qr=0,ac:AudioContext|null=null,arate=44100,arp=0,lL=0,lR=0,
he=0,hdn=[0,0,0,0,0,0,0,0],hdd=[0,0,0,0,0,0,0,0],hdo=[0,0,0,0,0,0,0,0],irqm=0,ht=0,vt=0,tup=0,irqP=0,sd=0,gid=0,vlat=0,cgd=1,
m7a=0,m7b=0,m7c=0,m7d=0,m7x=0,m7y=0,m7h=0,m7v=0,m7o=0,fxc=4278190080,fxr=0,fxg=0,fxb=0,tb=null,tl=null,
lb2=new Uint32Array(256),ly=new Uint8Array(256),ly2=new Uint8Array(256),OD1B=[4,8,9,2,0,10,3,1,11,5],OD7=[8,0,9,10,11],q9;
for(q9=0;q9<8;q9++)vB.push(new Int16Array(19));

/* ---------- SPC700 ---------- */
function spcReset(){ar.fill(0);dsp.fill(0);dsp[108]=224;iplOn=1;spi=[0,0,0,0];spo=[0,0,0,0];sa=sx=sy=0;ssp=239;spc=65472;sps(0);
tEn=[0,0,0];tDv=[256,256,256];tCt=[0,0,0];tOu=[0,0,0];tAc=[0,0,0];dAd=0;dAc=0;sbud=0;kon=0;eOff=0;
for(var i=0;i<8;i++){vSt[i]=0;vEn[i]=0}}
function sr(a:number){a&=65535;if(a>239&&a<256)return sio(a);if(a>=65472&&iplOn)return IPL[a-65472];return ar[a]}
function sw(a:number,v:number){a&=65535;if(a>239&&a<256)swio(a,v&255);else ar[a]=v&255}
function sio(a:number){switch(a){case 242:return dAd;case 243:return dsp[dAd&127];case 244:case 245:case 246:case 247:return spi[a-244];case 253:case 254:case 255:var t=a-253,v=tOu[t];tOu[t]=0;return v}return a<242?0:ar[a]}
function swio(a:number,v:number){switch(a){
case 241:for(var t=0;t<3;t++){var e=v>>t&1;if(e&&!tEn[t]){tCt[t]=0;tOu[t]=0}tEn[t]=e}if(v&16){spi[0]=0;spi[1]=0}if(v&32){spi[2]=0;spi[3]=0}iplOn=v>>7&1;break;
case 242:dAd=v;break;
case 243:if(dAd<128){dsp[dAd]=v;if(dAd===76)kon|=v;else if(dAd===124)dsp[124]=0}break;
case 244:case 245:case 246:case 247:spo[a-244]=v;break;
case 250:case 251:case 252:tDv[a-250]=v||256;ar[a]=v;break;
default:ar[a]=v}}
function gps(){return sN<<7|sV<<6|sP<<5|sB<<4|sH<<3|sI<<2|sZ<<1|sC}
function sps(v:number){sN=v>>7&1;sV=v>>6&1;sP=v>>5&1;sB=v>>4&1;sH=v>>3&1;sI=v>>2&1;sZ=v>>1&1;sC=v&1}
function snz(v:number){v&=255;sN=v>>7;sZ=v?0:1;return v}
function sdp(a:number){return sP<<8|a}
function sf(){var v=sr(spc);spc=spc+1&65535;return v}
function sp8(v:number){ar[256|ssp]=v&255;ssp=ssp-1&255}
function sl8(){ssp=ssp+1&255;return ar[256|ssp]}
function spush(v:number){sp8(v>>8);sp8(v&255)}
function spop(){var l=sl8();return l|sl8()<<8}
function rw(a:number){return sr(sdp(a))|sr(sdp(a+1&255))<<8}
function ww(a:number,v:number){sw(sdp(a),v&255);sw(sdp(a+1&255),v>>8&255)}
function salu(k:number,a:number,b:number){var r;switch(k){case 0:return snz(a|b);case 1:return snz(a&b);case 2:return snz(a^b);
case 3:r=a-b;sC=r>=0?1:0;snz(r);return a;
case 4:r=a+b+sC;sV=(~(a^b)&(a^r)&128)?1:0;sH=((a&15)+(b&15)+sC)>15?1:0;sC=r>255?1:0;return snz(r);
default:b^=255;r=a+b+sC;sV=(~(a^b)&(a^r)&128)?1:0;sH=((a&15)+(b&15)+sC)>15?1:0;sC=r>255?1:0;return snz(r)}}
function srmw(k:number,v:number){var r;switch(k){case 0:sC=v>>7;r=v<<1&255;break;case 1:r=(v<<1|sC)&255;sC=v>>7;break;case 2:sC=v&1;r=v>>1;break;case 3:r=v>>1|sC<<7;sC=v&1;break;case 4:r=v-1&255;break;default:r=v+1&255}return snz(r)}
function cmpr(a:number,b:number){var r=a-b;sC=r>=0?1:0;snz(r)}
function sbr(c:number|boolean){var d=sf();if(c)spc=spc+(d<<24>>24)&65535}
function sea(l:number){var q;switch(l){case 4:return sdp(sf());case 20:return sdp(sf()+sx&255);case 5:q=sf();return q|sf()<<8;case 21:q=sf();return(q|sf()<<8)+sx&65535;case 22:q=sf();return(q|sf()<<8)+sy&65535;case 6:return sdp(sx);
case 7:q=sf()+sx&255;return sr(sdp(q))|sr(sdp(q+1&255))<<8;case 23:q=sf();return(sr(sdp(q))|sr(sdp(q+1&255))<<8)+sy&65535}return 0}
function sstep(){var o=sf(),k=o>>5,l=o&31,a,b,v,r,q;
if(k<6&&(l===8||l===9||l===24||l===25||l===4||l===5||l===6||l===7||l===20||l===21||l===22||l===23)){
if(l===8){r=salu(k,sa,sf());if(k!==3)sa=r;return}
if(l===9){b=sr(sdp(sf()));a=sdp(sf());r=salu(k,sr(a),b);if(k!==3)sw(a,r);return}
if(l===24){b=sf();a=sdp(sf());r=salu(k,sr(a),b);if(k!==3)sw(a,r);return}
if(l===25){b=sr(sdp(sy));a=sdp(sx);r=salu(k,sr(a),b);if(k!==3)sw(a,r);return}
a=sea(l);r=salu(k,sa,sr(a));if(k!==3)sa=r;return}
if(k<6&&(l===11||l===27||l===12)){a=l===11?sdp(sf()):l===27?sdp(sf()+sx&255):sea(5);sw(a,srmw(k,sr(a)));return}
if(k<6&&l===28){sa=srmw(k,sa);return}
if((o&15)===3){a=sr(sdp(sf()));b=sf();if((a>>k&1)===(o&16?0:1))spc=spc+(b<<24>>24)&65535;return}
if((o&15)===2){a=sdp(sf());v=sr(a);b=1<<k;sw(a,o&16?v&~b:v|b);return}
if((o&15)===1){spush(spc);a=65502-(o>>4)*2;spc=sr(a)|sr(a+1)<<8;return}
switch(o){
case 0:case 239:case 255:return;
case 232:sa=snz(sf());return;case 230:sa=snz(sr(sdp(sx)));return;case 228:sa=snz(sr(sdp(sf())));return;case 244:sa=snz(sr(sdp(sf()+sx&255)));return;
case 229:sa=snz(sr(sea(5)));return;case 245:sa=snz(sr(sea(21)));return;case 246:sa=snz(sr(sea(22)));return;case 231:sa=snz(sr(sea(7)));return;case 247:sa=snz(sr(sea(23)));return;
case 191:sa=snz(sr(sdp(sx)));sx=sx+1&255;return;
case 196:sw(sdp(sf()),sa);return;case 212:sw(sdp(sf()+sx&255),sa);return;case 197:sw(sea(5),sa);return;case 213:sw(sea(21),sa);return;case 214:sw(sea(22),sa);return;case 199:sw(sea(7),sa);return;case 215:sw(sea(23),sa);return;case 198:sw(sdp(sx),sa);return;case 175:sw(sdp(sx),sa);sx=sx+1&255;return;
case 205:sx=snz(sf());return;case 248:sx=snz(sr(sdp(sf())));return;case 249:sx=snz(sr(sdp(sf()+sy&255)));return;case 233:sx=snz(sr(sea(5)));return;
case 141:sy=snz(sf());return;case 235:sy=snz(sr(sdp(sf())));return;case 251:sy=snz(sr(sdp(sf()+sx&255)));return;case 236:sy=snz(sr(sea(5)));return;
case 216:sw(sdp(sf()),sx);return;case 217:sw(sdp(sf()+sy&255),sx);return;case 201:sw(sea(5),sx);return;
case 203:sw(sdp(sf()),sy);return;case 219:sw(sdp(sf()+sx&255),sy);return;case 204:sw(sea(5),sy);return;
case 125:sa=snz(sx);return;case 221:sa=snz(sy);return;case 93:sx=snz(sa);return;case 253:sy=snz(sa);return;case 157:sx=snz(ssp);return;case 189:ssp=sx;return;
case 250:b=sr(sdp(sf()));sw(sdp(sf()),b);return;case 143:b=sf();sw(sdp(sf()),b);return;
case 200:cmpr(sx,sf());return;case 62:cmpr(sx,sr(sdp(sf())));return;case 30:cmpr(sx,sr(sea(5)));return;
case 173:cmpr(sy,sf());return;case 126:cmpr(sy,sr(sdp(sf())));return;case 94:cmpr(sy,sr(sea(5)));return;
case 61:sx=snz(sx+1);return;case 29:sx=snz(sx-1);return;case 252:sy=snz(sy+1);return;case 220:sy=snz(sy-1);return;
case 186:b=sf();r=rw(b);sa=r&255;sy=r>>8;sN=r>>15;sZ=r?0:1;return;
case 218:b=sf();ww(b,sy<<8|sa);return;
case 58:b=sf();r=rw(b)+1&65535;ww(b,r);sN=r>>15;sZ=r?0:1;return;
case 26:b=sf();r=rw(b)-1&65535;ww(b,r);sN=r>>15;sZ=r?0:1;return;
case 122:b=rw(sf());a=sy<<8|sa;r=a+b;sC=r>65535?1:0;sV=(~(a^b)&(a^r)&32768)?1:0;sH=((a&4095)+(b&4095))>4095?1:0;r&=65535;sa=r&255;sy=r>>8;sN=r>>15;sZ=r?0:1;return;
case 154:b=rw(sf());a=sy<<8|sa;r=a-b;sC=r>=0?1:0;sV=((a^b)&(a^r)&32768)?1:0;sH=((a&4095)-(b&4095))>=0?1:0;r&=65535;sa=r&255;sy=r>>8;sN=r>>15;sZ=r?0:1;return;
case 90:b=rw(sf());a=sy<<8|sa;r=a-b;sC=r>=0?1:0;r&=65535;sN=r>>15;sZ=r?0:1;return;
case 207:r=sy*sa;sa=r&255;sy=r>>8;sN=sy>>7;sZ=sy?0:1;return;
case 158:a=sy<<8|sa;sV=sy>=sx?1:0;sH=(sy&15)>=(sx&15)?1:0;if(sy<(sx<<1)){sa=a/sx|0;sy=a%sx}else{b=sx<<9;sa=255-((a-b)/(256-sx)|0);sy=sx+(a-b)%(256-sx)}sa&=255;sy&=255;snz(sa);return;
case 223:if(sC||sa>153){sa=sa+96&255;sC=1}if(sH||(sa&15)>9)sa=sa+6&255;snz(sa);return;
case 190:if(!sC||sa>153){sa=sa-96&255;sC=0}if(!sH||(sa&15)>9)sa=sa-6&255;snz(sa);return;
case 159:sa=(sa<<4|sa>>4)&255;snz(sa);return;
case 47:sbr(1);return;case 240:sbr(sZ);return;case 208:sbr(!sZ);return;case 176:sbr(sC);return;case 144:sbr(!sC);return;case 112:sbr(sV);return;case 80:sbr(!sV);return;case 48:sbr(sN);return;case 16:sbr(!sN);return;
case 46:a=sdp(sf());b=sf();if(sa!==sr(a))spc=spc+(b<<24>>24)&65535;return;
case 222:a=sdp(sf()+sx&255);b=sf();if(sa!==sr(a))spc=spc+(b<<24>>24)&65535;return;
case 110:a=sdp(sf());b=sf();v=sr(a)-1&255;sw(a,v);if(v)spc=spc+(b<<24>>24)&65535;return;
case 254:b=sf();sy=sy-1&255;if(sy)spc=spc+(b<<24>>24)&65535;return;
case 95:a=sf();spc=a|sf()<<8;return;
case 31:a=sf();a=(a|sf()<<8)+sx&65535;spc=sr(a)|sr(a+1)<<8;return;
case 63:a=sf();a|=sf()<<8;spush(spc);spc=a;return;
case 79:a=sf();spush(spc);spc=65280|a;return;
case 111:spc=spop();return;case 127:sps(sl8());spc=spop();return;
case 15:spush(spc);sp8(gps());sB=1;sI=0;spc=sr(65502)|sr(65503)<<8;return;
case 45:sp8(sa);return;case 77:sp8(sx);return;case 109:sp8(sy);return;case 13:sp8(gps());return;
case 174:sa=sl8();return;case 206:sx=sl8();return;case 238:sy=sl8();return;case 142:sps(sl8());return;
case 96:sC=0;return;case 128:sC=1;return;case 237:sC^=1;return;case 224:sV=0;sH=0;return;case 32:sP=0;return;case 64:sP=1;return;case 160:sI=1;return;case 192:sI=0;return;
case 14:a=sea(5);v=sr(a);snz(sa-v);sw(a,v|sa);return;case 78:a=sea(5);v=sr(a);snz(sa-v);sw(a,v&~sa);return;
case 10:case 42:case 74:case 106:case 138:case 170:case 202:case 234:q=sf();a=q|sf()<<8;b=a>>13;a&=8191;v=sr(a)>>b&1;
switch(o){case 10:sC|=v;break;case 42:sC|=v^1;break;case 74:sC&=v;break;case 106:sC&=v^1;break;case 138:sC^=v;break;case 170:sC=v;break;
case 202:r=sr(a);sw(a,sC?r|1<<b:r&~(1<<b));break;default:sw(a,sr(a)^1<<b)}return}}
function sTick(c:number){for(var t=0;t<3;t++){tAc[t]+=c;var per=t<2?128:16;while(tAc[t]>=per){tAc[t]-=per;if(tEn[t]&&++tCt[t]>=tDv[t]){tCt[t]=0;tOu[t]=tOu[t]+1&15}}}dAc+=c;while(dAc>=32){dAc-=32;dsp1()}}
function spcSync(){while(sbud>0){sstep();sbud-=4;sTick(4)}}

/* ---------- DSP ---------- */
function ok2(r:number){return r&&gc%RP[r]===0}
function brr(v:number){var b=vB[v],ad=vAd[v],h=ar[ad&65535],rg=h>>4,fl=h>>2&3,p1,p2,i,n,s,by;b[0]=b[16];b[1]=b[17];b[2]=b[18];p1=b[2];p2=b[1];
for(i=0;i<16;i++){by=ar[ad+1+(i>>1)&65535];n=i&1?by&15:by>>4;n=n>7?n-16:n;s=rg>12?(n<0?-2048:0):(n<<rg)>>1;
if(fl===1)s+=p1+((-p1)>>4);else if(fl===2)s+=(p1<<1)+((-p1*3)>>5)-p2+(p2>>4);else if(fl===3)s+=(p1<<1)+((-p1*13)>>6)-p2+((p2*3)>>4);
s=s>32767?32767:s<-32768?-32768:s;s=s<<17>>17;b[3+i]=s;p2=p1;p1=s}
vH[v]=h;if(h&1)dsp[124]|=1<<v;vAd[v]=ad+9&65535}
function nb2(v:number){if(vH[v]&1){if(vH[v]&2){var da=(dsp[93]<<8)+(dsp[(v<<4)+4]<<2);vAd[v]=ar[da+2&65535]|ar[da+3&65535]<<8}else{vSt[v]=0;vEn[v]=0;return}}brr(v)}
function envStep(v:number){var r=v<<4,a1=dsp[r+5],a2=dsp[r+6],g=dsp[r+7],e=vEn[v],s=vSt[v],t;
if(s===4){e-=8;if(e<=0){e=0;s=0}}
else if(a1&128){
if(s===1){t=(a1&15)*2+1;if(ok2(t)){e+=t===31?1024:32;if(e>2047){e=2047;s=2}}}
else if(s===2){t=((a1>>4)&7)*2+16;if(ok2(t)){e-=((e-1)>>8)+1;if((e>>8)<=(a2>>5))s=3}}
else{t=a2&31;if(ok2(t))e-=((e-1)>>8)+1}}
else{if(!(g&128))e=(g&127)<<4;else{t=g&31;if(ok2(t)){switch(g>>5&3){case 0:e-=32;break;case 1:e-=((e-1)>>8)+1;break;case 2:e+=32;break;default:e+=e<1536?32:8}}}}
if(e<0)e=0;if(e>2047)e=2047;vEn[v]=e;vSt[v]=s}
function dsp1(){var L=0,R=0,eL=0,eR=0,v,r,i,fl=dsp[108],k=kon,ko=dsp[92],o,sm,b,ix2,vl,vr,pi,n2;kon=0;gc=gc>=30719?0:gc+1;
for(v=0;v<8;v++){r=v<<4;
if(k>>v&1){var da=(dsp[93]<<8)+(dsp[r+4]<<2);vAd[v]=ar[da&65535]|ar[da+1&65535]<<8;vB[v].fill(0);vH[v]=0;vIx[v]=0;vPc[v]=0;vEn[v]=0;vSt[v]=1;dsp[124]&=~(1<<v);brr(v)}
if(!vSt[v]){dsp[r+8]=0;dsp[r+9]=0;continue}
if(fl&128){vSt[v]=0;vEn[v]=0;continue}
if(ko>>v&1)vSt[v]=4;
envStep(v);if(!vSt[v])continue;
b=vB[v];ix2=vIx[v];sm=b[2+ix2]+((b[3+ix2]-b[2+ix2])*vPc[v]>>12);
o=sm*vEn[v]>>11;dsp[r+8]=vEn[v]>>4;dsp[r+9]=o>>8&255;
vl=o*(dsp[r]<<24>>24)>>7;vr=o*(dsp[r+1]<<24>>24)>>7;L+=vl;R+=vr;if(dsp[77]>>v&1){eL+=vl;eR+=vr}
pi=(dsp[r+3]&63)<<8|dsp[r+2];vPc[v]+=pi;
while(vPc[v]>=4096){vPc[v]-=4096;if(++vIx[v]>=16){vIx[v]=0;nb2(v);if(!vSt[v])break}}}
L=L*(dsp[12]<<24>>24)>>7;R=R*(dsp[28]<<24>>24)>>7;
var em=(dsp[125]&15)?(dsp[125]&15)<<11:4,ea=((dsp[109]<<8)+eOff)&65535,xL=(ar[ea]|ar[ea+1&65535]<<8)<<16>>16>>1,xR=(ar[ea+2&65535]|ar[ea+3&65535]<<8)<<16>>16>>1,fL=0,fR=0,cf;
hL[hi2]=xL;hR[hi2]=xR;hi2=hi2+1&7;
for(i=0;i<8;i++){cf=dsp[(i<<4)+15]<<24>>24;fL+=hL[hi2+i&7]*cf;fR+=hR[hi2+i&7]*cf}
fL>>=6;fR>>=6;fL=fL>32767?32767:fL<-32768?-32768:fL;fR=fR>32767?32767:fR<-32768?-32768:fR;
L+=fL*(dsp[44]<<24>>24)>>7;R+=fR*(dsp[60]<<24>>24)>>7;
if(!(fl&32)){var fb2=dsp[13]<<24>>24,wl=eL+(fL*fb2>>7),wr2=eR+(fR*fb2>>7);wl=wl>16383?16383:wl<-16384?-16384:wl;wr2=wr2>16383?16383:wr2<-16384?-16384:wr2;
ar[ea]=wl<<1&255;ar[ea+1&65535]=wl<<1>>8&255;ar[ea+2&65535]=wr2<<1&255;ar[ea+3&65535]=wr2<<1>>8&255}
eOff+=4;if(eOff>=em)eOff=0;
if(fl&64){L=0;R=0}
L=L>32767?32767:L<-32768?-32768:L;R=R>32767?32767:R<-32768?-32768:R;
if(ffm===1){n2=qw+1&16383;if(n2!==qr){QL[qw]=L/32768;QR[qw]=R/32768;qw=n2}if((qw-qr&16383)>6000)qr=qr+3000&16383}}
function audioInit(){try{var AC:typeof AudioContext|undefined=window.AudioContext||window.webkitAudioContext;if(!AC)return;ac=new AC({latencyHint:"interactive"});arate=ac.sampleRate||44100;var spn=ac.createScriptProcessor(2048,0,2);
spn.onaudioprocess=function(e){var Lc=e.outputBuffer.getChannelData(0),Rc=e.outputBuffer.getChannelData(1),stp2=32000/arate,i,j,k2;
for(i=0;i<Lc.length;i++){if((qw-qr&16383)>1){j=qr;k2=qr+1&16383;lL=QL[j]+(QL[k2]-QL[j])*arp;lR=QR[j]+(QR[k2]-QR[j])*arp;arp+=stp2;while(arp>=1){arp-=1;qr=qr+1&16383}}else{lL*=.98;lR*=.98}Lc[i]=lL;Rc[i]=lR}};
spn.connect(ac.destination)}catch(x){ac=null}}
function wake(){try{if(ac&&ac.state==="suspended")ac.resume()}catch(e){}}
function audioStop(){try{if(ac)ac.close()}catch(e){}ac=null}
function sramSend(){P({k:"gbc-sram",t:"sram",id:gid,rec:{ram:sram.slice(0,sm+1),rtc:0}});sd=0}

/* ---------- HDMA ---------- */
function hdLoad(c:number){var q=c*16,a=dma[q+8]|dma[q+9]<<8,bk=dma[q+4]<<16,n=rd(bk|a);a=a+1&65535;
if(!n){hdd[c]=1;dma[q+8]=a&255;dma[q+9]=a>>8;return}
hdn[c]=n;if(dma[q]&64){dma[q+5]=rd(bk|a);a=a+1&65535;dma[q+6]=rd(bk|a);a=a+1&65535}
dma[q+8]=a&255;dma[q+9]=a>>8;hdo[c]=1}
function hdInit(){for(var c=0;c<8;c++){hdd[c]=0;hdn[c]=0;hdo[c]=0;if(he>>c&1){var q=c*16;dma[q+8]=dma[q+2];dma[q+9]=dma[q+3];hdLoad(c)}}}
function hdXfer(c:number){var q=c*16,cr=dma[q],bd=dma[q+1],p=PT[cr&7],ind=cr&64,a,bk,i;
if(ind){a=dma[q+5]|dma[q+6]<<8;bk=dma[q+7]<<16}else{a=dma[q+8]|dma[q+9]<<8;bk=dma[q+4]<<16}
for(i=0;i<p.length;i++){wio(8448+bd+p[i],rd(bk|a));a=a+1&65535}
if(ind){dma[q+5]=a&255;dma[q+6]=a>>8}else{dma[q+8]=a&255;dma[q+9]=a>>8}}
function hdLine(){if(!he)return;for(var c=0;c<8;c++){if(!(he>>c&1)||hdd[c])continue;
if(hdo[c])hdXfer(c);var n=hdn[c],cnt=(n&127)-1;hdo[c]=n&128?1:0;if(cnt<=0)hdLoad(c);else hdn[c]=n&128|cnt}}

/* ---------- PPU extra ---------- */
function vw(){return vram[vmadd<<1&65535]|vram[(vmadd<<1|1)&65535]<<8}
function s13(v:number){return v<<19>>19}
function ppuRd(o:number){var v;switch(o){
case 8500:return m7a*(m7b>>8)&255;case 8501:return(m7a*(m7b>>8))>>8&255;case 8502:return(m7a*(m7b>>8))>>16&255;
case 8504:v=oam[oama<512?oama:512+(oama&31)];oama=oama+1&1023;return v;
case 8505:v=vlat&255;if(!(vmain&128)){vlat=vw();vmadd=vmadd+vi()&32767}return v;
case 8506:v=vlat>>8;if(vmain&128){vlat=vw();vmadd=vmadd+vi()&32767}return v;
case 8507:v=cgl?cg[cga*2+1]:cg[cga*2];if(cgl)cga=cga+1&255;cgl^=1;return v;
case 8510:return 1;case 8511:return 3}return 0}
function ppuWr(o:number,v:number){if(o>=8475&&o<=8480){var w=(v<<8|m7o)<<16>>16;m7o=v;switch(o){case 8475:m7a=w;break;case 8476:m7b=w;break;case 8477:m7c=w;break;case 8478:m7d=w;break;case 8479:m7x=s13(w&8191);break;default:m7y=s13(w&8191)}}
else if(o===8498){var iv=v&31;iv=iv<<3|iv>>2;if(v&32)fxr=iv;if(v&64)fxg=iv;if(v&128)fxb=iv;fxc=4278190080|fxb<<16|fxg<<8|fxr}}
function m7(y:number){var sel=pr[26],yy=y+1,tt=sel>>6,hc,vc,ox,oy,x,xx,px,py,c,tn;if(sel&2)yy=255-yy;
hc=s13(m7h-m7x);vc=s13(m7v-m7y);
ox=(m7a*hc&-64)+(m7b*vc&-64)+(m7b*yy&-64)+(m7x<<8);oy=(m7c*hc&-64)+(m7d*vc&-64)+(m7d*yy&-64)+(m7y<<8);
for(x=0;x<256;x++){xx=sel&1?255-x:x;px=ox+m7a*xx>>8;py=oy+m7c*xx>>8;
if((px|py)&-1024){if(tt===2)continue;if(tt===3)c=vram[((py&7)*8+(px&7)<<1|1)&65535];else{px&=1023;py&=1023;tn=vram[((py>>3)*128+(px>>3)<<1)&65535];c=vram[(tn*64+(py&7)*8+(px&7)<<1|1)&65535]}}
else{tn=vram[((py>>3)*128+(px>>3)<<1)&65535];c=vram[(tn*64+(py&7)*8+(px&7)<<1|1)&65535]}
if(c){tb[x]=pal32[c];tl[x]=1}}}
function palUpd(){var br=pr[0]&15,i,v,r,g2,b;for(i=0;i<256;i++){v=cg[i*2]|cg[i*2+1]<<8;r=v&31;g2=v>>5&31;b=v>>10&31;r=(r<<3|r>>2)*(br+1)>>4;g2=(g2<<3|g2>>2)*(br+1)>>4;b=(b<<3|b>>2)*(br+1)>>4;pal32[i]=4278190080|b<<16|g2<<8|r}cgd=0}
function dl(od:number[],msk:number,y:number){for(var j=0;j<od.length;j++){var c=od[j];if(c<8){if(msk>>(c>>1)&1)bg(c>>1,c&1,y)}else if(msk&16)obj(c-8,y)}}
function renderLine(y:number){var ys=y*256;if(pr[0]&128){fb.fill(4278190080,ys,ys+256);return}ever=1;if(cgd)palUpd();
var m=pr[5]&7,od=m===0?ODR[0]:m===1?(pr[5]&8?OD1B:ODR[1]):m===7?OD7:ODR[2],cw=pr[48],ca=pr[49],x,l,bit,mn,sb,sh2,a,b,r,hb;
tm=pr[44]&31;tb=lb;tl=ly;lb.fill(pal32[0]);ly.fill(0);dl(od,tm,y);
if((ca&63)&&(cw>>4&3)!==3){
if(cw&2){tb=lb2;tl=ly2;lb2.fill(fxc);ly2.fill(0);dl(od,pr[45]&31,y)}
for(x=0;x<256;x++){l=ly[x];bit=l===0?32:l===6?0:l===5?16:1<<(l-1);if(!(ca&bit))continue;
mn=lb[x];sb=(cw&2)?lb2[x]:fxc;hb=(ca&64)&&!((cw&2)&&!ly2[x]);
r=0;for(sh2=0;sh2<24;sh2+=8){a=mn>>sh2&255;b=sb>>sh2&255;a=(ca&128)?a-b:a+b;if(hb)a>>=1;a=a<0?0:a>255?255:a;r|=a<<sh2}
lb[x]=4278190080|r}}
fb.set(lb,ys)}
var wram=new Uint8Array(131072),vram=new Uint8Array(65536),cg=new Uint8Array(512),oam=new Uint8Array(544),sram=new Uint8Array(131072),dma=new Uint8Array(128),pr=new Uint8Array(256);
var ROM:Uint8Array|null=null,HI=0,sm=8191,A=0,X=0,Y=0,S=511,D=0,DB=0,PB=0,PC=0,N=0,V=0,Z=0,C=0,Dm=0,I=1,M=1,XF=1,E=1,wai=0,stp=0;
var apu=[170,187,0,0],joy=0,jl=0,stb=0,jauto=0,nmiOn=0,nmiF=0,vbl=0,hbl=0,wa=0,vmadd=0,vmain=0,cga=0,cgl=0,cgt=0,oama=0,wmpya=0,wrdiv=0,rdmpy=0,rddiv=0,frames=0,PT=[[0],[0,1],[0,0],[0,0,1,1],[0,1,2,3],[0,1,0,1],[0,0],[0,0,1,1]],T1=[9,0,-1,3,10,1,5,4],T3=[13,11,-1,6,14,12,-1,7];
function rom(b:number,o:number){var i=HI?((b&63)<<16)|o:((b&127)<<15)|(o&32767);return ROM[i%ROM.length]}
function vi(){return[1,32,128,128][vmain&3]}
function rd(a:number){var b=a>>16,o=a&65535,bb=b&127;
if(bb<64){if(o<8192)return wram[o];if(o<32768){if(o>=24576&&HI&&bb>=32)return sram[((bb&31)<<13|o&8191)&sm];return o>=8448&&o<17408?io(o):0}return rom(b,o)}
if(b===126||b===127)return wram[(b&1)<<16|o];if(HI)return rom(b,o);
if(b>=112&&b<126&&o<32768)return sram[((b-112)<<15|o)&sm];return o>=32768?rom(b,o):0}
function wr(a:number,v:number){var b=a>>16,o=a&65535,bb=b&127;
if(bb<64){if(o<8192)wram[o]=v;else if(o<32768){if(o>=24576&&HI&&bb>=32)sram[((bb&31)<<13|o&8191)&sm]=v,sd=1;else if(o>=8448&&o<17408)wio(o,v)}return}
if(b===126||b===127){wram[(b&1)<<16|o]=v;return}if(!HI&&b>=112&&b<126&&o<32768)sram[((b-112)<<15|o)&sm]=v,sd=1}
function io(o:number){if(o<8704){if(o>=8512&&o<8576){sbud+=24;spcSync();return spo[o&3]}if(o===8576){return wram[wa++&131071]}return ppuRd(o)}
switch(o){case 16406:var b=jl>>15&1;jl=(jl<<1|1)&65535;return b;case 16912:var v=nmiF<<7|2;nmiF=0;return v;case 16913:var tv=tup<<7;tup=0;irqP=0;return tv;case 16914:return vbl<<7|hbl<<6|(jauto?1:0);case 16915:return 192;
case 16916:return rddiv&255;case 16917:return rddiv>>8;case 16918:return rdmpy&255;case 16919:return rdmpy>>8;case 16920:return joy&255;case 16921:return joy>>8}
return o>=17152&&o<17280?dma[o-17152]:0}
function wio(o:number,v:number){if(o<8704){switch(o){case 8450:oama=oama&512|v<<1;break;case 8451:oama=oama&510|(v&1)<<9;break;
case 8452:if(oama<512)oam[oama]=v;else oam[512+(oama&31)]=v;oama=oama+1&1023;break;case 8469:vmain=v;break;case 8470:vmadd=vmadd&32512|v;vlat=vw();break;case 8471:vmadd=vmadd&255|(v&127)<<8;vlat=vw();break;
case 8472:vram[vmadd<<1&65535]=v;if(!(vmain&128))vmadd=vmadd+vi()&32767;break;case 8473:vram[(vmadd<<1|1)&65535]=v;if(vmain&128)vmadd=vmadd+vi()&32767;break;
case 8481:cga=v;cgl=0;break;case 8482:if(!cgl)cgt=v;else{cg[cga*2]=cgt;cg[cga*2+1]=v&127;cga=cga+1&255;cgd=1}cgl^=1;break;
case 8576:wram[wa++&131071]=v;break;case 8577:wa=wa&130816|v;break;case 8578:wa=wa&65791|v<<8;break;case 8579:wa=wa&65535|(v&1)<<16;break;
case 8461:case 8462:case 8463:case 8464:case 8465:case 8466:case 8467:case 8468:{var k=o-8461,w;if(k&1){w=(v<<8|scl)&8191;vs[k>>1]=w}else{w=(v<<8|(scl&248)|(hs[k>>1]>>8&7))&8191;hs[k>>1]=w}if(k===0)m7h=(v<<8|m7o)&8191;if(k===1)m7v=(v<<8|m7o)&8191;m7o=v;scl=v;break}
default:if(o>=8512&&o<8576){sbud+=24;spcSync();spi[o&3]=v}else{pr[o&255]=v;if(o===8448)cgd=1;ppuWr(o,v)}}return}
switch(o){case 16406:stb=v&1;if(stb)jl=joy;break;case 16896:nmiOn=v>>7&1;irqm=v>>4&3;break;case 16903:ht=ht&256|v;break;case 16904:ht=ht&255|(v&1)<<8;break;case 16905:vt=vt&256|v;break;case 16906:vt=vt&255|(v&1)<<8;break;case 16908:he=v;break;case 16898:wmpya=v;break;case 16899:rdmpy=wmpya*v;break;case 16900:wrdiv=wrdiv&65280|v;break;case 16901:wrdiv=wrdiv&255|v<<8;break;
case 16902:if(v){rddiv=wrdiv/v|0;rdmpy=wrdiv%v}else{rddiv=65535;rdmpy=wrdiv}break;case 16907:dmaRun(v);break;
default:if(o>=17152&&o<17280)dma[o-17152]=v}}
function dmaRun(m:number){for(var c=0;c<8;c++)if(m>>c&1){var q=c*16,cr=dma[q],bd=dma[q+1],sa=dma[q+2]|dma[q+3]<<8,sb=dma[q+4],n=(dma[q+5]|dma[q+6]<<8)||65536,p=PT[cr&7],s2=cr>>3&3,st=s2===0?1:s2===2?-1:0;
for(var i=0;i<n;i++){var bo=8448+bd+p[i%p.length];if(cr&128)wr(sb<<16|sa,bo<8704?io(bo):0);else{var vv=rd(sb<<16|sa);if(bo<8704)wio(bo,vv)}sa=sa+st&65535}
dma[q+2]=sa&255;dma[q+3]=sa>>8;dma[q+5]=0;dma[q+6]=0}}
function gp(){return N<<7|V<<6|M<<5|XF<<4|Dm<<3|I<<2|Z<<1|C}
function sp(v:number){N=v>>7&1;V=v>>6&1;if(!E){M=v>>5&1;XF=v>>4&1}Dm=v>>3&1;I=v>>2&1;Z=v>>1&1;C=v&1;if(XF){X&=255;Y&=255}}
function f8(){var v=rd(PB<<16|PC);PC=PC+1&65535;return v}
function f16(){var l=f8();return l|f8()<<8}
function f24(){var l=f16();return l|f8()<<16}
function r16(a:number){return rd(a&16777215)|rd(a+1&16777215)<<8}
function r24(a:number){return r16(a)|rd(a+2&16777215)<<16}
function w16(a:number,v:number){wr(a&16777215,v&255);wr(a+1&16777215,v>>8&255)}
function ps8(v:number){wr(S,v&255);S=E?256|S-1&255:S-1&65535}
function pl8(){S=E?256|S+1&255:S+1&65535;return rd(S)}
function ps16(v:number){ps8(v>>8);ps8(v)}
function pl16(){var l=pl8();return l|pl8()<<8}
function am(t:number){var xx=XF?X&255:X,yy=XF?Y&255:Y;switch(t){
case 0:return D+f8()&65535;case 1:return D+f8()+xx&65535;case 2:return D+f8()+yy&65535;case 3:return DB<<16|f16();
case 4:return(DB<<16)+f16()+xx&16777215;case 5:return(DB<<16)+f16()+yy&16777215;case 6:return f24();case 7:return f24()+xx&16777215;
case 8:return DB<<16|r16(D+f8()&65535);case 9:return DB<<16|r16(D+f8()+xx&65535);case 10:return(DB<<16)+r16(D+f8()&65535)+yy&16777215;
case 11:return r24(D+f8()&65535);case 12:return r24(D+f8()&65535)+yy&16777215;case 13:return S+f8()&65535;case 14:return(DB<<16)+r16(S+f8()&65535)+yy&16777215}}
function rm(a:number){return M?rd(a):r16(a)}
function wm(a:number,v:number){if(M)wr(a,v&255);else w16(a,v)}
function rx(a:number){return XF?rd(a):r16(a)}
function wx(a:number,v:number){if(XF)wr(a,v&255);else w16(a,v)}
function im(){return M?f8():f16()}
function ix(){return XF?f8():f16()}
function nz(v:number,w:number){if(w){N=v>>7&1;Z=v&255?0:1}else{N=v>>15&1;Z=v&65535?0:1}}
function alu(k:number,v:number){var w=M?255:65535,sg=M?128:32768,a=A&w,t;
switch(k){case 0:a|=v;break;case 1:a&=v;break;case 2:a^=v;break;case 3:case 7:if(k===7)v=~v&w;t=a+v+C;V=(~(a^v)&(a^t)&sg)?1:0;C=t>w?1:0;a=t&w;break;
case 5:a=v;break;case 6:t=a-v;C=t>=0?1:0;nz(t&w,M);return}
A=M?A&65280|a:a;nz(a,M)}
function sh(k:number,v:number){var w=M?255:65535,sg=M?128:32768,r,c=C;
switch(k){case 0:C=v&sg?1:0;r=v<<1&w;break;case 1:C=v&sg?1:0;r=(v<<1|c)&w;break;case 2:C=v&1;r=v>>1;break;case 3:C=v&1;r=v>>1|(c?sg:0);break;case 6:r=v-1&w;break;default:r=v+1&w}
nz(r,M);return r}
function cp(R:number,v:number){var t=R-v;C=t>=0?1:0;nz(t&(XF?255:65535),XF)}
function br(c:number|boolean){var d=f8();if(c)PC=PC+(d<<24>>24)&65535}
function irq(vn:number,ve:number,bk:number){if(!E)ps8(PB);ps16(PC);ps8(gp()&(E&&!bk?~16:255));I=1;Dm=0;PB=0;PC=r16(E?ve:vn)}
function nmi(){wai=0;irq(65514,65530,0)}
function bit(ea:number){var v=rm(ea);Z=(A&v&(M?255:65535))?0:1;N=v>>(M?7:15)&1;V=v>>(M?6:14)&1}
function step(){var o=f8(),cc=o&3,aa=o>>5,bb=o>>2&7,ea,v;
if(cc===1||cc===3&&bb!==2&&bb!==6||cc===2&&bb===4){
if(o===137){v=im();Z=(A&v&(M?255:65535))?0:1;return}
if(cc===1&&bb===2)v=im();else{ea=am(cc===1?T1[bb]:cc===3?T3[bb]:8);if(aa===4){wm(ea,A);return}v=rm(ea)}
alu(aa,v);return}
if(cc===2&&(bb===1||bb===3||bb===5||bb===7||o===162)){
if(o===158){wm(am(4),0);return}
if(aa===4||aa===5){if(o===162){X=ix();nz(X,XF);return}ea=am(bb===1?0:bb===3?3:bb===5?2:5);if(aa===4)wx(ea,X);else{X=rx(ea);nz(X,XF)}return}
ea=am(bb===1?0:bb===3?3:bb===5?1:4);wm(ea,sh(aa,rm(ea)));return}
switch(o){
case 10:case 42:case 74:case 106:v=sh(aa,A&(M?255:65535));A=M?A&65280|v:v;break;
case 26:v=A+1;A=M?A&65280|v&255:v&65535;nz(A,M);break;case 58:v=A-1;A=M?A&65280|v&255:v&65535;nz(A,M);break;
case 4:case 12:ea=am(o===4?0:3);v=rm(ea);Z=(A&v)?0:1;wm(ea,v|A);break;
case 20:case 28:ea=am(o===20?0:3);v=rm(ea);Z=(A&v)?0:1;wm(ea,v&~A);break;
case 36:bit(am(0));break;case 44:bit(am(3));break;case 52:bit(am(1));break;case 60:bit(am(4));break;
case 100:wm(am(0),0);break;case 116:wm(am(1),0);break;case 156:wm(am(3),0);break;
case 132:wx(am(0),Y);break;case 140:wx(am(3),Y);break;case 148:wx(am(1),Y);break;
case 160:Y=ix();nz(Y,XF);break;case 164:Y=rx(am(0));nz(Y,XF);break;case 172:Y=rx(am(3));nz(Y,XF);break;case 180:Y=rx(am(1));nz(Y,XF);break;case 188:Y=rx(am(4));nz(Y,XF);break;
case 192:cp(Y,ix());break;case 196:cp(Y,rx(am(0)));break;case 204:cp(Y,rx(am(3)));break;
case 224:cp(X,ix());break;case 228:cp(X,rx(am(0)));break;case 236:cp(X,rx(am(3)));break;
case 76:PC=f16();break;case 108:PC=r16(f16());break;case 124:v=f16()+(XF?X&255:X)&65535;PC=r16(PB<<16|v);break;
case 92:v=f16();PB=f8();PC=v;break;case 220:v=f16();PC=r16(v);PB=rd(v+2&65535);break;
case 32:v=f16();ps16(PC-1&65535);PC=v;break;case 252:v=f16()+(XF?X&255:X)&65535;ps16(PC-1&65535);PC=r16(PB<<16|v);break;
case 34:v=f16();ea=f8();ps8(PB);ps16(PC-1&65535);PC=v;PB=ea;break;
case 96:PC=pl16()+1&65535;break;case 107:PC=pl16()+1&65535;PB=pl8();break;case 64:sp(pl8());PC=pl16();if(!E)PB=pl8();break;
case 0:f8();irq(65510,65534,1);break;case 2:f8();irq(65508,65524,1);break;
case 16:br(!N);break;case 48:br(N);break;case 80:br(!V);break;case 112:br(V);break;case 144:br(!C);break;case 176:br(C);break;case 208:br(!Z);break;case 240:br(Z);break;case 128:br(1);break;
case 130:v=f16();PC=PC+v&65535;break;
case 244:ps16(f16());break;case 212:ps16(r16(D+f8()&65535));break;case 98:v=f16();ps16(PC+v&65535);break;
case 8:ps8(gp());break;case 40:sp(pl8());break;
case 72:if(M)ps8(A);else ps16(A);break;case 104:if(M){v=pl8();A=A&65280|v;nz(v,1)}else{A=pl16();nz(A,0)}break;
case 90:if(XF)ps8(Y);else ps16(Y);break;case 122:Y=XF?pl8():pl16();nz(Y,XF);break;
case 218:if(XF)ps8(X);else ps16(X);break;case 250:X=XF?pl8():pl16();nz(X,XF);break;
case 139:ps8(DB);break;case 171:DB=pl8();nz(DB,1);break;case 11:ps16(D);break;case 43:D=pl16();nz(D,0);break;case 75:ps8(PB);break;
case 24:C=0;break;case 56:C=1;break;case 88:I=0;break;case 120:I=1;break;case 184:V=0;break;case 216:Dm=0;break;case 248:Dm=1;break;
case 194:v=f8();sp(gp()&~v);break;case 226:v=f8();sp(gp()|v);break;
case 251:v=C;C=E;E=v;if(E){M=1;XF=1;X&=255;Y&=255;S=256|S&255}break;
case 170:X=XF?A&255:A;nz(X,XF);break;case 168:Y=XF?A&255:A;nz(Y,XF);break;
case 138:A=M?A&65280|X&255:X;nz(A,M);break;case 152:A=M?A&65280|Y&255:Y;nz(A,M);break;
case 186:X=XF?S&255:S;nz(X,XF);break;case 154:S=E?256|X&255:X;break;
case 155:Y=X;nz(Y,XF);break;case 187:X=Y;nz(X,XF);break;
case 91:D=A;nz(D,0);break;case 123:A=D;nz(A,0);break;case 27:S=E?256|A&255:A;break;case 59:A=S;nz(A,0);break;
case 232:X=X+1&(XF?255:65535);nz(X,XF);break;case 200:Y=Y+1&(XF?255:65535);nz(Y,XF);break;
case 202:X=X-1&(XF?255:65535);nz(X,XF);break;case 136:Y=Y-1&(XF?255:65535);nz(Y,XF);break;
case 235:A=(A&255)<<8|A>>8;nz(A&255,1);break;case 234:break;case 66:f8();break;
case 84:case 68:{var d1=f8(),s1=f8(),dl=o===84?1:-1,mk=XF?255:65535;DB=d1;wr(d1<<16|Y,rd(s1<<16|X));X=X+dl&mk;Y=Y+dl&mk;A=A-1&65535;if(A!==65535)PC=PC-3&65535;break}
case 203:wai=1;break;case 219:stp=1;break}}
function reset(){A=X=Y=D=DB=PB=0;S=511;E=1;M=1;XF=1;I=1;N=V=Z=C=Dm=0;wai=stp=0;PC=r16(65532)}
function run(n:number){for(var i=0;i<n;i++){if(irqP){if(!I){irqP=0;wai=0;irq(65518,65534,0)}else if(wai)wai=0}if(wai||stp)return;step()}}
function frame(){frames++;for(var ln=0;ln<262;ln++){if(ln===0){vbl=0;hdInit()}
if(ln>0&&ln<225){hdLine();renderLine(ln-1)}
if(ln===225){vbl=1;nmiF=1;jauto=1;if(nmiOn)nmi()}if(ln===228)jauto=0;
hbl=0;run(40);sbud+=33;spcSync();
if(irqm&&(irqm===1||ln===vt)){tup=1;irqP=1}
hbl=1;run(17);sbud+=32;spcSync()}}

var fb=new Uint32Array(57344),pal32=new Uint32Array(256),lb=new Uint32Array(256),hs=[0,0,0,0],vs=[0,0,0,0],scl=0,ever=0,tm=0,BPP=[[2,2,2,2],[4,4,2,0],[4,4,0,0],[8,4,0,0],[8,2,0,0]],OS=[[8,16],[8,32],[8,64],[16,32],[16,64],[32,64],[16,32],[16,32]],ODR=[[6,4,8,7,5,9,2,0,10,3,1,11],[4,8,5,9,2,0,10,3,1,11],[2,8,0,9,3,10,1,11]];
function bg(n:number,p:number,y:number){var m=pr[5]&7,bp;if(m===7){if(!n&&!p)m7(y);return}bp=BPP[m]?BPP[m][n]:0;if(!bp)return;
var big=pr[5]>>(4+n)&1,v=pr[7+n],mb=(v&252)<<9,w=v&1,h=v>>1&1,cb=((n<2?pr[11]:pr[12])>>((n&1)*4)&15)<<13,sy=y+vs[n]&1023,sx0=hs[n],
x,sx,fx,tx,ty,a,e=0,hf=0,vf=0,tn,ca,b0=0,b1=0,b2=0,b3=0,b4=0,b5=0,b6=0,b7=0,bt,ix,ci,ry;
for(x=0;x<256;x++){sx=x+sx0&1023;fx=sx&7;
if(!x||!fx){tx=big?sx>>4:sx>>3;ty=big?sy>>4:sy>>3;a=mb+((tx>>5&w)+(ty>>5&h)*(w?2:1))*2048+((ty&31)*32+(tx&31))*2;e=vram[a&65535]|vram[a+1&65535]<<8;
hf=e>>14&1;vf=e>>15&1;tn=e&1023;ry=sy&7;if(big){var sh=sx>>3&1,sv=sy>>3&1;if(hf)sh^=1;if(vf)sv^=1;tn+=sh+sv*16}
ca=cb+tn*bp*8+(vf?7-ry:ry)*2;b0=vram[ca&65535];b1=vram[ca+1&65535];
if(bp>=4){b2=vram[ca+16&65535];b3=vram[ca+17&65535]}if(bp===8){b4=vram[ca+32&65535];b5=vram[ca+33&65535];b6=vram[ca+48&65535];b7=vram[ca+49&65535]}}
if((e>>13&1)!==p)continue;bt=hf?fx:7-fx;ix=(b0>>bt&1)|(b1>>bt&1)<<1;
if(bp>=4)ix|=(b2>>bt&1)<<2|(b3>>bt&1)<<3;if(bp===8)ix|=(b4>>bt&1)<<4|(b5>>bt&1)<<5|(b6>>bt&1)<<6|(b7>>bt&1)<<7;
if(!ix)continue;ci=bp===2?(m===0?n*32:0)+((e>>10&7)<<2)+ix:bp===4?((e>>10&7)<<4)+ix:ix;tb[x]=pal32[ci];tl[x]=n+1}}
function obj(k:number,y:number){var os=OS[pr[1]>>5],nb=(pr[1]&7)<<14,gp=((pr[1]>>3&3)+1)<<13;
for(var i=127;i>=0;i--){var a=i*4,at=oam[a+3];if((at>>4&3)!==k)continue;var hi=oam[512+(i>>2)]>>((i&3)*2)&3,sz=os[hi>>1],sx=oam[a]|(hi&1)<<8,dy=y-(oam[a+1]+1)&255;
if(dy>=sz)continue;if(sx>255)sx-=512;var hf=at>>6&1,ry=at>>7&1?sz-1-dy:dy,tc=sz>>3,t=oam[a+2];
for(var cx=0;cx<tc;cx++){var fx=hf?tc-1-cx:cx,n=((t>>4)+(ry>>3)&15)<<4|((t&15)+fx&15),ca=nb+(at&1?gp:0)+n*32+(ry&7)*2,b0=vram[ca&65535],b1=vram[ca+1&65535],b2=vram[ca+16&65535],b3=vram[ca+17&65535];
for(var q=0;q<8;q++){var x=sx+cx*8+q;if(x<0||x>255)continue;var bt=hf?q:7-q,ix=(b0>>bt&1)|(b1>>bt&1)<<1|(b2>>bt&1)<<2|(b3>>bt&1)<<3;if(ix){tb[x]=pal32[128+((at>>1&7)<<4)+ix];tl[x]=(at>>1&7)>3?5:6}}}}}
var cv=document.getElementById("c") as HTMLCanvasElement,g=cv.getContext("2d"),go=0,paused=0,ffm=1,acc=0,lastT=0,imd=g.createImageData(256,224),f32=new Uint32Array(imd.data.buffer),KMS:Record<number,number>={0:15,8:7,2:13,3:12,4:11,5:10,6:9,7:8,9:5,10:4,1:6,11:14};
function P(m:Record<string,unknown>){try{parent.postMessage(m,"*")}catch(e){}}
function sc(d:Uint8Array,o:number){if(o+64>d.length)return -1;var s=0,a=d[o+28]|d[o+29]<<8,b=d[o+30]|d[o+31]<<8;
if((a^b)===65535)s+=4;var m=d[o+21]&239;if((o===32704&&m===32)||(o===65472&&m===33))s+=2;
if((d[o+60]|d[o+61]<<8)>=32768)s+=2;for(var i=0;i<21;i++){var c=d[o+i];if(c<32||c>126)s-=1}return s}
function hx(v:number,n:number){var out=v.toString(16).toUpperCase();while(out.length<n)out="0"+out;return out}
function txt(L:Array<[string,string?]>,hd:string=""){g.fillStyle="#10131a";g.fillRect(0,0,256,224);g.font="bold 13px monospace";g.fillStyle="#7aa2ff";g.fillText(hd||"SUPER NINTENDO",12,22);
g.font="11px monospace";for(var i=0;i<L.length;i++){g.fillStyle=L[i][1]||"#e8ebf3";g.fillText(L[i][0],12,46+i*15)}}
function dbg(){var nv=0;for(var i=0;i<65536;i+=16)if(vram[i])nv++;
txt([["PC "+hx(PB,2)+":"+hx(PC,4)+"  "+(wai?"WAI":stp?"STP":"rodando"),wai||stp?"#ffb86b":"#7bd88f"],
["A "+hx(A,4)+" X "+hx(X,4)+" Y "+hx(Y,4)],["S "+hx(S,4)+" D "+hx(D,4)+" DB "+hx(DB,2)],
["N"+N+" V"+V+" M"+M+" X"+XF+" D"+Dm+" I"+I+" Z"+Z+" C"+C+" E"+E],
["Quadros "+frames+"   NMI "+(nmiOn?"ligado":"desligado")],
["Portas APU "+hx(apu[0],2)+" "+hx(apu[1],2)+" "+hx(apu[2],2)+" "+hx(apu[3],2)],
["VRAM com dados: "+(nv?"sim ("+nv+")":"não")],["",""],
["CPU ativa, mas o jogo ainda não ligou a tela.","#ffb86b"]],"SUPER NINTENDO · CPU");
for(var c=0;c<256;c++){var v=cg[c*2]|cg[c*2+1]<<8;g.fillStyle="rgb("+(v&31)*8+","+(v>>5&31)*8+","+(v>>10&31)*8+")";g.fillRect((c&31)*8,160+(c>>5)*8,8,8)}}
function loop(ts:number){if(!go)return;requestAnimationFrame(loop);var dt=ts-lastT;lastT=ts;if(dt>100)dt=16.7;if(paused)return;acc+=dt*ffm;var n=0;
try{while(acc>=16.74&&n<5){frame();acc-=16.74;n++}}catch(e){go=0;P({t:"fail",m:"Erro na CPU: "+(e instanceof Error ? (e instanceof Error ? e.message : String(e)) : String(e))});return}if(n){if(ever){f32.set(fb);g.putImageData(imd,0,0)}else if(frames>90&&(frames&3)===0)dbg()}}
function init(d:GBAInitMessage){d.blob.arrayBuffer().then(function(ab){var u=new Uint8Array(ab);
if(u[0]===80&&u[1]===75){txt([["ZIP ainda não é lido no SNES.","#ffb86b"],["Use o arquivo .sfc ou .smc direto."]]);return P({t:"start"})}
var hdr=(u.length%1024===512)?512:0,r=hdr?u.subarray(512):u,lo=sc(r,32704),hi=sc(r,65472);
if(r.length<32768||Math.max(lo,hi)<3){txt([["Não reconheci esse cartucho.","#ff7a7a"],["Tamanho: "+(u.length>>10)+" KB"],["Confira se é uma ROM de SNES."]]);return P({t:"start"})}
var o=hi>lo?65472:32704,sr=r[o+24]?(1<<r[o+24]):0;ROM=r;HI=o===65472?1:0;sm=Math.min(Math.max(sr*1024,8192),131072)-1;
reset();spcReset();audioInit();gid=d.id;try{if(d.sram&&d.sram.ram)sram.set(d.sram.ram.subarray(0,131072))}catch(e){}setInterval(function(){if(sd&&go)sramSend()},5000);go=1;lastT=performance.now();P({t:"start"});requestAnimationFrame(loop)}).catch(function(e){P({t:"fail",m:"Não consegui ler o cartucho: "+(e instanceof Error ? (e instanceof Error ? e.message : String(e)) : String(e))})})}
addEventListener("message",function(e:MessageEvent){var d=e.data||{};
if(d.t==="init")init(d);
else if(d.t==="btn"){wake();var b=KMS[d.k];if(b!==undefined){if(d.v)joy|=1<<b;else joy&=~(1<<b)}}
else if(d.t==="ff"){ffm=d.v?(d.m||4):1;acc=0}else if(d.t==="getst"||d.t==="setst"){P({t:"nostate"})}else if(d.t==="pause"){paused=d.v?1:0;if(d.v&&sd)sramSend()}
else if(d.t==="save"){sramSend();setTimeout(function(){P({t:"saved"})},20)}else if(d.t==="stop"){go=0;if(sd)sramSend();audioStop()}});
}
const SNES_DOC='<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><style>html,body{margin:0;height:100%;background:#000;overflow:hidden}#c{display:block;width:100%;height:100%;object-fit:contain;image-rendering:pixelated}</style></head><body><canvas id="c" width="256" height="224"></canvas><script>'+FPSJS+'<\/script><script>('+snesChild.toString()+')()<\/script></body></html>';
