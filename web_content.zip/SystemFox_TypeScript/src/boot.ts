// System Fox — Inicialização em TypeScript

window.__in0=performance.now();(function(){try{var d=document.documentElement,L=localStorage;var pf=L.getItem("mdperf")||"auto";var c=navigator.hardwareConcurrency||4,m=navigator.deviceMemory||4;var det=(m<=2||c<=2)?2:(m<=3||c<=4)?1:0;d.dataset.pf=String(pf==="auto"?Math.max(det,+L.getItem("mdpfauto")||0):+pf);if(L.getItem("mdintro")==="0")document.getElementById("intro").hidden=true}catch(e){}})();
