// System Fox — Mega Drive e biblioteca compartilhada (TypeScript)



const $=<T extends HTMLElement=HTMLElement>(i:string):T=>document.getElementById(i) as T;
const FPSJS='(function(){var n=0,P=function(m){try{parent.postMessage(m,"*")}catch(e){}};var C=CanvasRenderingContext2D.prototype,d=C.drawImage,p=C.putImageData;C.drawImage=function(){if(this.canvas&&this.canvas.id==="c")n++;return d.apply(this,arguments)};C.putImageData=function(){if(this.canvas&&this.canvas.id==="c")n++;return p.apply(this,arguments)};setInterval(function(){var x=window.__fc!=null;P({t:"fps",v:x?window.__fc:n,x:x?1:0});n=0;if(x)window.__fc=0},1000)})();';
let rom=new Uint8Array(0x200000),RL=0x200000,ram=new Uint8Array(65536),zr=new Uint8Array(8192),sram=new Uint8Array(32768).fill(255),
vram=new Uint8Array(65536),cram=new Uint16Array(64),vs=new Uint16Array(64),rg=new Uint8Array(32),
pend=0,cd=0,va=0,fill=0,vf=0,ip6=0,ip4=0,pad=0,th=0x40,line=0,hc=0,run=0,stopped=0,dmaBusy=0,
R=new Int32Array(16),pc=0,sr=0x2700,EA=0,EM=0,ER=0,usp=0,sramOn=0,bk=[0,1,2,3,4,5,6,7],ilc=0,sdirty=0,sf=0;
const m=(v:number,s:number):number=>s==0?v&255:s==1?v&65535:v|0,
sgn=(v:number,s:number):number=>s==0?v&128:s==1?v&32768:v&0x80000000;
function ill(op:number):void{
  if(ilc++>5)return;
  const msg = "Opcode não implementado: 0x"+op.toString(16).toUpperCase().padStart(4,"0")+" em 0x"+((pc-2)&0xFFFFFF).toString(16).toUpperCase();
  console.warn(msg);
  $("st").textContent = "Aviso: " + msg;
}
/* ---------- barramento ---------- */
function pd(){const p=pad;return th&0x40?0x40|(~p&0x3F):(~((p&3)|((p>>2)&0x30))&0x33)}
function r8(a:number):number{a&=0xFFFFFF;if(a>=0xE00000)return ram[a&0xFFFF];
if(a<0x400000){if(sramOn&&a>=0x200000)return a&1?sram[(a>>1)&0x7FFF]:255;
if(a<RL)return RL>0x400000?(rom[(bk[a>>19]<<19)|(a&0x7FFFF)]||0):rom[a];
return a&1?sram[(a>>1)&0x7FFF]:255}
if(a>=0xC00000&&a<0xC00020){const v=vr(a);return a&1?v&255:v>>8}
if(a==0xA11100)return zbus?0:1;if(a>=0xA04000&&a<0xA04004)return ymr();if(a>=0xA00000&&a<0xA02000)return zr[a&0x1FFF];
if(a>=0xA10000&&a<0xA10020){a&=0x1F;return a==1?0xA0:a==3?pd():a==5?0x7F:0}
return 0}
function r16(a:number):number{a&=0xFFFFFF;if(a>=0xC00000&&a<0xC00020)return vr(a);return r8(a)<<8|r8(a+1)}
function r32(a:number):number{return(r16(a)<<16|r16(a+2))|0}
function w8(a:number,v:number):void{a&=0xFFFFFF;v&=255;
if(a>=0xE00000)ram[a&0xFFFF]=v;
else if(a>=0xC00000){if(a<0xC00010)vw(a&~1,v<<8|v);else if(a<0xC00018&&a&1)psgw(v)}
else if(a==0xA11100)zbus=v&1;else if(a==0xA11200){zrs=(v&1)?0:1;if(zrs){zpc=0;zsp=0xFFFF;zhalt=0;ziff1=ziff2=0;zint=0}}
else if(a>=0xA04000&&a<0xA04004)ymw(a&3,v);else if(a==0xA07F11)psgw(v);else if(a>=0xA10000&&a<0xA10020){if((a&0x1F)==3)th=v}
else if(a>=0xA00000&&a<0xA02000)zr[a&0x1FFF]=v;
else if(a>=0xA130F0&&a<0xA13100){if(a&1){const k=(a-0xA130F1)>>1;if(k==0)sramOn=v&1;else if(k<8)bk[k]=v&63}}
else if(a>=0x200000&&a<0x400000&&(sramOn||a>=RL)&&(a&1)){sram[(a>>1)&0x7FFF]=v;sdirty=1}}
function w16(a:number,v:number):void{a&=0xFFFFFF;if(a>=0xC00000&&a<0xC00020)vw(a,v&0xFFFF);else{w8(a,v>>8);w8(a+1,v)}}
function w32(a:number,v:number):void{w16(a,v>>>16);w16(a+2,v&0xFFFF)}
/* ---------- VDP ---------- */
function vput(v:number):void{const c=cd&7,x=va&0xFFFF;
if(c==1){vram[x]=v>>8;vram[x^1]=v&255}else if(c==3){cram[(va>>1)&63]=v;pdirty=1}else if(c==5)vs[(va>>1)&63]=v;
va=(va+rg[15])&0xFFFF}
function dma(){let n=rg[19]|rg[20]<<8,md=rg[23]>>6;
dmaBusy=1;
n = n || 65536;
if(md<2){let s=(rg[21]|rg[22]<<8|(rg[23]&127)<<16)<<1;while(n--){vput(r16(s));s=(s&0xFE0000)|((s+2)&0x1FFFF)}}
else if(md==2)fill=n;
else{let s=rg[21]|rg[22]<<8;while(n--){vram[va&0xFFFF]=vram[s&0xFFFF];s++;va=(va+rg[15])&0xFFFF}}
dmaBusy=0;}
function vw(a:number,v:number):void{a&=0x1F;
if(a<4){pend=0;if(fill){let n=fill;fill=0;vput(v);while(n--){vram[(va&0xFFFF)^1]=v>>8;va=(va+rg[15])&0xFFFF}}else vput(v)}
else if(a<8){if(pend){pend=0;va=(va&0x3FFF)|((v&3)<<14);cd=(cd&3)|((v>>2)&0x3C);if((cd&0x20)&&(rg[1]&0x10))dma()}
else if((v&0xC000)==0x8000)rg[(v>>8)&31]=v;else{pend=1;va=v&0x3FFF;cd=v>>14}}}
function vr(a:number):number{a&=0x1F;
if(a<4){const c=cd&15,x=va&0xFFFF;let v=0;pend=0;
if(c==0)v=vram[x]<<8|vram[x^1];else if(c==8)v=cram[(va>>1)&63];else if(c==4)v=vs[(va>>1)&63];
va=(va+rg[15])&0xFFFF;return v}
if(a<8){pend=0;const v=0x3600|(vf?0x80:0)|(line>=224?8:0)|(dmaBusy?2:0);vf=0;return v}
return(line&255)<<8}
/* ---------- renderização ---------- */
let cv=$<HTMLCanvasElement>("c"),ctx=cv.getContext("2d",{alpha:false}),oc=document.createElement("canvas"),octx=(oc.width=320,oc.height=224,oc.getContext("2d",{alpha:false})),img=octx.createImageData(320,224),u32=new Uint32Array(img.data.buffer),pal=new Uint32Array(64),
LA=new Uint8Array(320),PA=new Uint8Array(320),LB=new Uint8Array(320),PB=new Uint8Array(320),LS=new Uint8Array(320),PS=new Uint8Array(320);
const SZ=[32,64,32,128];
function plane(p:number,y:number,W:number,lb:Uint8Array,pr:Uint8Array):void{const sz=rg[16],w=SZ[sz&3],h=SZ[(sz>>4)&3],
nt=p?(rg[4]&7)<<13:(rg[2]&0x38)<<10,hb=(rg[13]&63)<<10,hm=rg[11]&3,
ho=hm==0?0:hm==3?y*4:(y&~7)*4,i=(hb+ho+p*2)&0xFFFF,hs=((vram[i]<<8)|vram[i+1])&0x3FF;
for(let x=0;x<W;x++){const px=(x-hs)&(w*8-1),sv=rg[11]&4?vs[((x>>4)*2+p)&63]:vs[p],py=(y+(sv&0x3FF))&(h*8-1),
ad=(nt+((py>>3)*w+(px>>3))*2)&0xFFFF,e=vram[ad]<<8|vram[ad+1];
let tx=px&7,ty=py&7;if(e&0x800)tx=7-tx;if(e&0x1000)ty=7-ty;
const b=vram[(((e&0x7FF)<<5)+ty*4+(tx>>1))&0xFFFF],c=tx&1?b&15:b>>4;
if(c){lb[x]=((e>>13)&3)*16+c;pr[x]=e>>15}}}
function win(y:number,W:number):void{if(!rg[17]&&!rg[18])return;const wh=(rg[17]&31)*16,hd=rg[17]&0x80,wv=(rg[18]&31)*8,vin=(rg[18]&0x80)?y>=wv:y<wv,
ww=W==320?64:32,nt=(rg[3]&(W==320?0x3C:0x3E))<<10,row=y>>3;
for(let x=0;x<W;x++){if(!(vin||(hd?x>=wh:x<wh)))continue;
const ad=(nt+(row*ww+(x>>3))*2)&0xFFFF,e=vram[ad]<<8|vram[(ad+1)&0xFFFF];
let tx=x&7,ty=y&7;if(e&0x800)tx=7-tx;if(e&0x1000)ty=7-ty;
const b=vram[(((e&0x7FF)<<5)+ty*4+(tx>>1))&0xFFFF],c=tx&1?b&15:b>>4;
LA[x]=c?((e>>13)&3)*16+c:0;PA[x]=c?e>>15:0}}
function spr(y:number,W:number,ls:Uint8Array,sp:Uint8Array):void{const sb=(rg[5]&0x7F)<<9,mx=W==320?80:64;let i=0,n=0,cnt=0;
do{const a=(sb+i*8)&0xFFFF,yy=((vram[a]<<8|vram[a+1])&0x3FF)-128,sz=vram[a+2],l=vram[a+3]&127,
at=vram[a+4]<<8|vram[a+5],xr=(vram[a+6]<<8|vram[a+7])&0x1FF,xx=xr-128,w=((sz>>2)&3)+1,h=(sz&3)+1;
if(y>=yy&&y<yy+h*8){if(xr==0&&cnt>0)break;if(++cnt>(W==320?20:16))break;let ry=y-yy;if(at&0x1000)ry=h*8-1-ry;
for(let px=0;px<w*8;px++){const sx=xx+px;if(sx<0||sx>=W||ls[sx])continue;const cx=at&0x800?w*8-1-px:px,
t=(at&0x7FF)+(cx>>3)*h+(ry>>3),b=vram[((t<<5)+((ry&7)<<2)+((cx&7)>>1))&0xFFFF],c=cx&1?b&15:b>>4;
if(c){ls[sx]=((at>>13)&3)*16+c;sp[sx]=at>>15}}}
i=l}while(i&&++n<mx)}
const DAC=[0,52,87,116,144,172,206,255];let pdirty=1,xc=0;
function rl(y:number):void{if(pdirty){pdirty=0;for(let i=0;i<64;i++){const c=cram[i];pal[i]=0xFF000000|DAC[(c>>9)&7]<<16|DAC[(c>>5)&7]<<8|DAC[(c>>1)&7]}}
const bd=pal[rg[7]&0x3F],W=rg[12]&0x81?320:256,o=y*320,off=(320-W)>>1;
u32.fill(0xFF000000,o,o+320);
if(!(rg[1]&0x40))return;
LA.fill(0);PA.fill(0);LB.fill(0);PB.fill(0);LS.fill(0);PS.fill(0);
plane(1,y,W,LB,PB);plane(0,y,W,LA,PA);win(y,W);spr(y,W,LS,PS);
for(let x=0;x<W;x++){let v=0;
if(LB[x]&&!PB[x])v=LB[x];if(LA[x]&&!PA[x])v=LA[x];if(LS[x]&&!PS[x])v=LS[x];
if(LB[x]&&PB[x])v=LB[x];if(LA[x]&&PA[x])v=LA[x];if(LS[x]&&PS[x])v=LS[x];
u32[o+off+x]=v?pal[v]:bd}}
/* ---------- CPU 68000 ---------- */
function bcd(sub:number,dst:number,src:number):number{const x=(sr>>4)&1;let res,c;
if(!sub){res=(src&15)+(dst&15)+x;if(res>9)res+=6;res+=(src&0xF0)+(dst&0xF0);c=res>0x99;if(c)res-=0xA0}
else{res=(dst&15)-(src&15)-x;if(res>9||res<0)res-=6;res+=(dst&0xF0)-(src&0xF0);c=res>0x99||res<0;if(c)res+=0xA0}
res&=255;sr=(sr&~0x1B)|(c?17:0)|(res&128?8:0);if(res)sr&=~4;return res}
function bcdop(sub:number,op:number):void{const mo=(op>>3)&7,r0=op&7,r9=(op>>9)&7;
if(mo&1){ea(4,r0,0);const b=rd(0);ea(4,r9,0);const a=rd(0);wr(0,bcd(sub,a,b))}
else dn(r9,0,bcd(sub,R[r9]&255,R[r0]&255))}
function f16(){const v=r16(pc);pc=(pc+2)&0xFFFFFF;return v}
function setSR(v:number):void{sr=v&0xFFFF}
function nz(v:number,s:number):void{sr=(sr&~15)|(sgn(v,s)?8:0)|(m(v,s)==0?4:0)}
function dn(r:number,s:number,v:number):void{R[r]=s==0?(R[r]&~255)|(v&255):s==1?(R[r]&~65535)|(v&65535):v}
function ix(b:number):number{const x=f16();let v=R[(x>>12)&15];if(!(x&0x800))v=v<<16>>16;return b+(x<<24>>24)+v}
function ea(md:number,r:number,s:number):void{EM=md;ER=r;
switch(md){case 0:case 1:EA=-1;break;
case 2:EA=R[8+r];break;
case 3:EA=R[8+r];R[8+r]+=(s==0&&r==7)?2:1<<s;break;
case 4:R[8+r]-=(s==0&&r==7)?2:1<<s;EA=R[8+r];break;
case 5:EA=R[8+r]+(f16()<<16>>16);break;
case 6:EA=ix(R[8+r]);break;
default:if(r==0)EA=f16()<<16>>16;else if(r==1)EA=(f16()<<16)|f16();
else if(r==2){const b=pc;EA=b+(f16()<<16>>16)}else if(r==3){const b=pc;EA=ix(b)}
else{EA=pc+(s==0?1:0);pc=(pc+(s==2?4:2))&0xFFFFFF}}}
function rd(s:number):number{if(EM==0)return m(R[ER],s);if(EM==1)return m(R[8+ER],s);return s==0?r8(EA):s==1?r16(EA):r32(EA)}
function wr(s:number,v:number):void{if(EM==0)dn(ER,s,v);else if(EM==1)R[8+ER]=s==1?v<<16>>16:v;else s==0?w8(EA,v):s==1?w16(EA,v):w32(EA,v)}
function alu(op:number,a:number,b:number,s:number,x:number,kx:number):number{const A=m(a,s),B=m(b,s),ua=s==2?A>>>0:A,ub=s==2?B>>>0:B,mx=s==0?255:s==1?65535:4294967295;
const t=op?ua-ub-x:ua+ub+x,r=m(t,s),c=op?t<0:t>mx,sa=!!sgn(A,s),sb=!!sgn(B,s),sq=!!sgn(r,s),v=op?(sa!=sb&&sq!=sa):(sa==sb&&sq!=sa);
let f=(c?1:0)|(v?2:0)|(r==0?4:0)|(sq?8:0);if(!kx&&c)f|=16;sr=(sr&(kx?~15:~31))|f;return r}
function cc(c:number):number|boolean{const C=sr&1,V=(sr>>1)&1,Z=(sr>>2)&1,N=(sr>>3)&1;
switch(c){case 0:return 1;case 1:return 0;case 2:return !C&&!Z;case 3:return C||Z;case 4:return !C;case 5:return C;case 6:return !Z;case 7:return Z;
case 8:return !V;case 9:return V;case 10:return !N;case 11:return N;case 12:return N==V;case 13:return N!=V;case 14:return !Z&&N==V;default:return Z||N!=V}}
function sh(ty:number,L:number,v:number,n:number,s:number):number{let c=0,o=0,x=(sr>>4)&1;const msb=[128,32768,-2147483648][s],bt=8<<s;
if(!n)c=ty==2?x:0;
for(let i=0;i<n;i++){let out,nv;
if(L){out=v&msb?1:0;nv=v<<1;if(ty==2)nv|=x;if(ty==3)nv|=out;nv=m(nv,s);if(ty==0&&((nv&msb)?1:0)!=out)o=1}
else{out=v&1;nv=v>>>1;if(ty==0)nv|=v&msb;if(ty==2)nv|=x<<(bt-1);if(ty==3)nv|=out<<(bt-1)}
c=out;if(ty!=3)x=out;v=m(nv,s)}
sr=(sr&~15)|(v&msb?8:0)|(v==0?4:0)|(o?2:0)|c;if(n&&ty!=3)sr=(sr&~16)|(x<<4);return v}
function bitop(op:number,n:number):void{const mo=(op>>3)&7,r=op&7,ty=(op>>6)&3;ea(mo,r,0);n&=mo==0?31:7;
let v=mo==0?R[r]:r8(EA);const b=1<<n;sr=(sr&~4)|((v&b)?0:4);
if(ty){v=ty==1?v^b:ty==2?v&~b:v|b;if(mo==0)R[r]=v;else w8(EA,v)}}
function lg(k:number,op:number,s:number):void{const r9=(op>>9)&7;ea((op>>3)&7,op&7,s);const d=R[r9],o=rd(s);let v=m(k?o&d:o|d,s);
if(op&0x100)wr(s,v);else dn(r9,s,v);nz(v,s)}
function movem(op:number):void{const mk=f16(),s=op&0x40?2:1,st=s==2?4:2,mo=(op>>3)&7,r=op&7;let ad;
if(op&0x400){if(mo==3)ad=R[8+r];else{ea(mo,r,s);ad=EA}
for(let i=0;i<16;i++)if((mk>>i)&1){R[i]=s==2?r32(ad):r16(ad)<<16>>16;ad+=st}
if(mo==3)R[8+r]=ad}
else if(mo==4){ad=R[8+r];for(let i=0;i<16;i++)if((mk>>i)&1){ad-=st;const v=R[15-i];s==2?w32(ad,v):w16(ad,v)}R[8+r]=ad}
else{ea(mo,r,s);ad=EA;for(let i=0;i<16;i++)if((mk>>i)&1){s==2?w32(ad,R[i]):w16(ad,R[i]);ad+=st}}}
function exc(v:number):void{const o=sr;sr=(sr|0x2000)&~0x8000;R[15]-=4;w32(R[15],pc);R[15]-=2;w16(R[15],o);pc=r32(v*4)&0xFFFFFF}
function step(){const op=f16(),t=op>>12,r9=(op>>9)&7,mo=(op>>3)&7,r0=op&7,s=(op>>6)&3;
switch(t){
case 0:{
if(op&0x100){if(mo==1){const ad=R[8+r0]+(f16()<<16>>16),lw=s&1,n=lw?4:2;if(s&2){for(let i=0;i<n;i++)w8(ad+i*2,R[r9]>>((n-1-i)*8))}else{let v=0;for(let i=0;i<n;i++)v=(v<<8)|r8(ad+i*2);dn(r9,lw?2:1,v)}}else bitop(op,R[r9])}
else if((op&0xF00)==0x800)bitop(op,f16());
else{const k=(op>>9)&7;
if((op&0xBF)==0x3C&&(k==0||k==1||k==5)){const im=f16(),mk=op&0x40?0xFFFF:0x1F,cu=sr&mk;sr=(sr&~mk)|((k==0?cu|im:k==1?cu&im:cu^im)&mk)}
else{if(s==3){ill(op);break}const im=s==2?(f16()<<16)|f16():f16();ea(mo,r0,s);const a=rd(s);
if(k==0||k==1||k==5){const v=m(k==0?a|im:k==1?a&im:a^im,s);nz(v,s);wr(s,v)}
else if(k==2)wr(s,alu(1,a,im,s,0,0));else if(k==3)wr(s,alu(0,a,im,s,0,0));else alu(1,a,im,s,0,1)}}
break}
case 1:case 2:case 3:{const z=t==1?0:t==3?1:2,dm=(op>>6)&7;ea(mo,r0,z);const v=rd(z);
if(dm==1)R[8+r9]=z==1?v<<16>>16:v;else{ea(dm,r9,z);wr(z,v);nz(v,z)}break}
case 4:{
if((op&0x1C0)==0x1C0){ea(mo,r0,2);R[8+r9]=EA;break}
switch((op>>8)&15){
case 0:if(s==3){ea(mo,r0,1);wr(1,sr)}else{ea(mo,r0,s);const v=rd(s),z=sr&4,r=alu(1,0,v,s,(sr>>4)&1,0);sr=(sr&~4)|(r==0?z:0);wr(s,r)}break;
case 2:ea(mo,r0,s);wr(s,0);nz(0,s);break;
case 4:if(s==3){ea(mo,r0,1);sr=(sr&~0x1F)|(rd(1)&0x1F)}else{ea(mo,r0,s);const v=rd(s);wr(s,alu(1,0,v,s,0,0))}break;
case 6:if(s==3){ea(mo,r0,1);setSR(rd(1))}else{ea(mo,r0,s);const v=m(~rd(s),s);wr(s,v);nz(v,s)}break;
case 8:if(s==0){ea(mo,r0,0);const v=rd(0);wr(0,bcd(1,0,v))}
else if(s==1){if(mo==0){R[r0]=(R[r0]<<16)|(R[r0]>>>16);nz(R[r0],2)}else{ea(mo,r0,2);R[15]-=4;w32(R[15],EA)}}
else if(mo==0){if(s==2){R[r0]=(R[r0]&~65535)|((R[r0]<<24>>24)&65535);nz(R[r0],1)}else{R[r0]=R[r0]<<16>>16;nz(R[r0],2)}}
else movem(op);break;
case 10:if(s==3){ea(mo,r0,0);const v=rd(0);nz(v,0);wr(0,v|128)}else{ea(mo,r0,s);nz(rd(s),s)}break;
case 12:if(s>=2)movem(op);else ill(op);break;
case 14:
if((op&0xFFF0)==0x4E40)exc(32+(op&15));
else if((op&0xFFF8)==0x4E50){R[15]-=4;w32(R[15],R[8+r0]);R[8+r0]=R[15];R[15]+=f16()<<16>>16}
else if((op&0xFFF8)==0x4E58){R[15]=R[8+r0];R[8+r0]=r32(R[15]);R[15]+=4}
else if(op==0x4E75){pc=r32(R[15])&0xFFFFFF;R[15]+=4}
else if(op==0x4E73){setSR(r16(R[15]));R[15]+=2;pc=r32(R[15])&0xFFFFFF;R[15]+=4}
else if(op==0x4E72){setSR(f16());stopped=1}
else if((op&0xFFC0)==0x4E80){ea(mo,r0,2);R[15]-=4;w32(R[15],pc);pc=EA&0xFFFFFF}
else if((op&0xFFC0)==0x4EC0){ea(mo,r0,2);pc=EA&0xFFFFFF}
else if(op==0x4E77){sr=(sr&~0x1F)|(r16(R[15])&0x1F);R[15]+=2;pc=r32(R[15])&0xFFFFFF;R[15]+=4}
else if(op==0x4E76){if(sr&2)exc(7)}
else if((op&0xFFF0)==0x4E60){if(op&8)R[8+r0]=usp;else usp=R[8+r0]}
else if(op==0x4E71||op==0x4E70){}else ill(op);break;
default:if((op&0x1C0)==0x180){ea(mo,r0,1);const bd=rd(1)<<16>>16,d=R[r9]<<16>>16;if(d<0||d>bd){sr=(sr&~8)|(d<0?8:0);exc(6)}}else ill(op)}
break}
case 5:
if(s==3){const c=(op>>8)&15;
if(mo==1){const b=pc,d=f16()<<16>>16;if(!cc(c)){const w=(R[r0]-1)&65535;R[r0]=(R[r0]&~65535)|w;if(w!=65535)pc=(b+d)&0xFFFFFF}}
else{ea(mo,r0,0);wr(0,cc(c)?255:0)}}
else{const q=r9||8,sub=op&0x100;
if(mo==1)R[8+r0]+=sub?-q:q;else{ea(mo,r0,s);const a=rd(s);wr(s,alu(sub?1:0,a,q,s,0,0))}}
break;
case 6:{let d=op&255;const b=pc,c=(op>>8)&15;if(d==0)d=f16()<<16>>16;else d=d<<24>>24;
if(c==1){R[15]-=4;w32(R[15],pc);pc=(b+d)&0xFFFFFF}else if(c==0||cc(c))pc=(b+d)&0xFFFFFF;break}
case 7:R[r9]=op<<24>>24;nz(R[r9],2);break;
case 8:
if(s==3){xc+=120;ea(mo,r0,1);const dv=rd(1);
if(op&0x100){const d=dv<<16>>16;if(!d){exc(5);break}const n=R[r9],q=Math.trunc(n/d),rm=n%d;
if(q>32767||q<-32768)sr=(sr&~15)|2;else{R[r9]=(rm<<16)|(q&65535);nz(q,1)}}
else{if(!dv){exc(5);break}const n=R[r9]>>>0,q=Math.floor(n/dv),rm=n%dv;
if(q>65535)sr=(sr&~15)|2;else{R[r9]=(rm<<16)|q;nz(q,1)}}}
else{if((op&0x1F0)==0x100)bcdop(1,op);else lg(0,op,s)}
break;
case 9:case 13:{const sb=t==9?1:0;
if(s==3){const z=op&0x100?2:1;ea(mo,r0,z);let v=rd(z);if(z==1)v=v<<16>>16;R[8+r9]=sb?R[8+r9]-v:R[8+r9]+v}
else if((op&0x130)==0x100){const x=(sr>>4)&1,z=sr&4;let a,b,r;
if(mo&1){ea(4,r0,s);b=rd(s);ea(4,r9,s);a=rd(s);r=alu(sb,a,b,s,x,0);sr=(sr&~4)|(r==0?z:0);wr(s,r)}
else{a=m(R[r9],s);b=m(R[r0],s);r=alu(sb,a,b,s,x,0);sr=(sr&~4)|(r==0?z:0);dn(r9,s,r)}}
else{ea(mo,r0,s);const o=rd(s);
if(op&0x100)wr(s,alu(sb,o,R[r9],s,0,0));else dn(r9,s,alu(sb,R[r9],o,s,0,0))}
break}
case 11:
if(s==3){const z=op&0x100?2:1;ea(mo,r0,z);let v=rd(z);if(z==1)v=v<<16>>16;alu(1,R[8+r9],v,2,0,1)}
else if(op&0x100){if(mo==1){ea(3,r0,s);const x=rd(s);ea(3,r9,s);alu(1,rd(s),x,s,0,1)}
else{ea(mo,r0,s);const v=m(rd(s)^R[r9],s);wr(s,v);nz(v,s)}}
else{ea(mo,r0,s);alu(1,R[r9],rd(s),s,0,1)}
break;
case 12:{const om=(op>>3)&31;
if(s==3){xc+=58;ea(mo,r0,1);const v=rd(1),r=op&0x100?(R[r9]<<16>>16)*(v<<16>>16):(R[r9]&65535)*v;R[r9]=r|0;nz(r|0,2)}
else if((op&0x100)&&(om==8||om==9||om==17)){const x=om==9?8+r9:r9,y=om==8?r0:8+r0,tt=R[x];R[x]=R[y];R[y]=tt}
else{if((op&0x1F0)==0x100)bcdop(0,op);else lg(1,op,s)}
break}
case 14:
if(s==3){ea(mo,r0,1);wr(1,sh((op>>9)&3,op&0x100,rd(1),1,1))}
else{const c=op&0x20?R[r9]&63:r9||8;dn(r0,s,sh((op>>3)&3,op&0x100,m(R[r0],s),c,s))}
break;
default:exc(t==10?10:11)}}
function cpu(n:number):void{let c=0;
while(c<n){const lv=ip6?6:ip4?4:0;
if(lv&&lv>((sr>>8)&7)){if(lv==6)ip6=0;else ip4=0;stopped=0;exc(24+lv);sr=(sr&~0x700)|(lv<<8);c+=44}
if(stopped)break;step();c+=12+xc;xc=0}}
function frame(){for(line=0;line<262;line++){
if(line<224){if(!skipR)rl(line);if(--hc<0){hc=rg[10];if(rg[0]&0x10)ip4=1}}
else if(line==224){vf=1;hc=rg[10];if(rg[1]&0x20)ip6=1}
cpu(line==224?700:488);zrun(228)}
if(ip6)cpu(30);}
/* ---------- entrada, ROM e laço principal ---------- */
const km:Record<string,number>={ArrowUp:1,ArrowDown:2,ArrowLeft:4,ArrowRight:8,KeyZ:64,KeyX:16,KeyC:32,Enter:128,KeyS:256};
addEventListener("keydown",e=>{if(km[e.code]){pad|=km[e.code];e.preventDefault()}});
addEventListener("keyup",e=>{if(km[e.code])pad&=~km[e.code]});
document.querySelectorAll<HTMLElement>("[data-k]").forEach(b=>{const k=+b.dataset.k;
b.onpointerdown=e=>{pad|=k;b.setPointerCapture(e.pointerId)};b.onpointerup=b.onpointercancel=()=>{pad&=~k};b.oncontextmenu=e=>e.preventDefault()});
(function(){const dp=document.querySelector<HTMLElement>(".dp")!;let act=0,dr:DOMRect|null=null;
dp.querySelectorAll("b").forEach(b=>{b.onpointerdown=b.onpointerup=b.onpointercancel=null});
function upd(e:PointerEvent):void{const r=dr||(dr=dp.getBoundingClientRect());let dx=e.clientX-(r.left+r.width/2),dy=e.clientY-(r.top+r.height/2);
if(document.body.classList.contains("rot")){const t=dx;dx=dy;dy=-t}
const hw=Math.max(r.width,r.height)/2,nx=dx/hw,ny=dy/hw;
let m=0;if(nx<-.3)m|=4;if(nx>.3)m|=8;if(ny<-.3)m|=1;if(ny>.3)m|=2;pad=(pad&~15)|m}
dp.onpointerdown=e=>{act=1;dr=null;dp.setPointerCapture(e.pointerId);upd(e)};
dp.onpointermove=e=>{if(act)upd(e)};
dp.onpointerup=dp.onpointercancel=()=>{act=0;setTimeout(()=>{if(!act)pad&=~15},50)};
window.__rdp=()=>{act=0;dr=null};
})();
(function(){
const btns=[...document.querySelectorAll<HTMLElement>("[data-k]")].filter(b=>!b.closest(".dp"));
btns.forEach(b=>{b.onpointerdown=b.onpointerup=b.onpointercancel=null});
const ptrs=new Map<number,number>(),until:Record<string,number>={};
let rc:MegaDriveHitRect[]|null=null;window.__invRects=()=>{rc=null};
function maskFor(x:number,y:number):number{if(!rc)rc=btns.map(b=>{const r=b.getBoundingClientRect();return{k:+b.dataset.k,cx:r.left+r.width/2,cy:r.top+r.height/2,lim:Math.max(r.width,r.height)/2+12}});let best=0,bd=1e9;for(const b of rc){const d=Math.hypot(x-b.cx,y-b.cy);if(d<b.lim&&d<bd){bd=d;best=b.k}}return best}
function recompute():void{let m=0,nx=0;ptrs.forEach(v=>m|=v);const now=performance.now();for(const k in until)if(until[k]>now){m|=+k;nx=Math.max(nx,until[k]-now)}pad=(pad&15)|m;if(nx)setTimeout(recompute,nx+5)}
function hit(e:PointerEvent):void{if(document.body.classList.contains("msp"))return;const m=maskFor(e.clientX,e.clientY),old=ptrs.get(e.pointerId)||0;if(m&~old){const t=performance.now()+60;for(let b=1;b<=256;b<<=1)if(m&b)until[b]=t}ptrs.set(e.pointerId,m);recompute()}
document.addEventListener("pointerdown",e=>{const target=e.target;if(target instanceof Element&&(target.closest(".dp")||target.closest(".scr")||target.closest("#cf")||target.closest("#act")))return;rc=null;hit(e)},true);
document.addEventListener("pointermove",e=>{if(ptrs.has(e.pointerId))hit(e)},true);
const up=(e:PointerEvent):void=>{if(document.body.classList.contains("msp"))return;if(ptrs.delete(e.pointerId)){recompute();setTimeout(recompute,70)}};
document.addEventListener("pointerup",up,true);document.addEventListener("pointercancel",up,true);
const clr=()=>{ptrs.clear();pad=0};
window.__rptr=()=>{ptrs.clear();for(const k in until)delete until[k]};
addEventListener("blur",clr);document.addEventListener("visibilitychange",()=>{if(document.hidden)clr()});
document.addEventListener("contextmenu",e=>{if(!/^(INPUT|TEXTAREA)$/.test((e.target instanceof HTMLElement?e.target.tagName:"")))e.preventDefault()});
})();
let fx="clean",scan=0,mono=0;try{fx=localStorage.getItem("mdfx")||"clean";scan=+(localStorage.getItem("mdscan")||0);mono=+(localStorage.getItem("mdmono")||0)}catch(e){}
const scn=document.createElement("canvas");function mkScn(k:number):void{scn.width=320*k;scn.height=224*k;const g=scn.getContext("2d");if(k<2)return;g.fillStyle="rgba(0,0,0,.34)";for(let y=k-1;y<224*k;y+=k)g.fillRect(0,y,scn.width,1)}mkScn(3);
function applyFx(){ctx.imageSmoothingEnabled=(fx==="smooth");cv.classList.toggle("px",fx==="sharp"||fx==="vivid");cv.classList.toggle("vivid",fx==="vivid");cv.classList.toggle("mono",!!mono)}
let PF=0,skipR=0,frDn=0,skc=0;let KK=3,fc=0,lw=0;function rs(){const k=(fx==="sharp"||fx==="vivid")?Math.max(1,Math.min(PF>1?1:PF?2:8,Math.floor(cv.clientWidth*(window.devicePixelRatio||1)/320)||3)):(PF>1?1:PF?2:3);if(cv.width!==320*k){cv.width=320*k;cv.height=224*k;mkScn(k)}KK=k;applyFx()}rs();
function rebuildCanvas(){try{const n=cv.cloneNode(false) as HTMLCanvasElement;n.width=320*KK;n.height=224*KK;n.style.cssText=cv.style.cssText;cv.parentNode.replaceChild(n,cv);cv=n;ctx=cv.getContext("2d",{alpha:false});applyFx();lw=0}catch(e){}}
const idle=(f:()=>void)=>window.requestIdleCallback?requestIdleCallback(f,{timeout:2000}):setTimeout(f,50);
let last=0,acc=0,af=0,spd=1;
let lid=0,lastTick=0,errs=0;
function startLoop(){const id=++lid;last=performance.now();acc=0;lastTick=last;const f=(t:number)=>{if(id!==lid||!run)return;lastTick=performance.now();if(tick(t)&&id===lid&&run)requestAnimationFrame(f)};requestAnimationFrame(f)}
setInterval(()=>{if(run&&!document.hidden&&performance.now()-lastTick>800)startLoop()},500);
document.addEventListener("visibilitychange",()=>{if(!document.hidden&&run)startLoop()});
/* ---- Z80 ---- */
const Z=new Uint8Array(8),Z2=new Uint8Array(8),PAR=new Uint8Array(256);for(let i=0;i<256;i++){let p=1,x=i;while(x){p^=x&1;x>>=1}PAR[i]=p?4:0}
let zF=0,zF2=0,zpc=0,zsp=0xFFFF,zix=0,ziy=0,zx=0,zi=0,zrr=0,ziff1=0,ziff2=0,zim=0,zhalt=0,zint=0,zcyc=0,zbud=0,zbus=0,zrs=1,zbank=0,zbn=0;
function zinit(){Z.fill(0);Z2.fill(0);zF=zF2=zpc=zix=ziy=zi=zrr=ziff1=ziff2=zim=zhalt=zint=zbud=zbank=zbn=0;zsp=0xFFFF;zbus=0;zrs=1;zr.fill(0);ymInit()}
function zrb(a:number):number{a&=65535;zcyc+=3;if(a<0x4000)return zr[a&0x1FFF];if(a<0x6000)return a<0x4004?ymr():0;if(a<0x8000)return 255;return r8(zbank|(a&0x7FFF))}
function zwb(a:number,v:number):void{a&=65535;zcyc+=3;if(a<0x4000)zr[a&0x1FFF]=v;else if(a<0x4004)ymw(a&3,v);else if(a>=0x6000&&a<0x6100){zbn=(zbn>>1)|((v&1)<<8);zbank=(zbn<<15)&0xFFFFFF}else if(a==0x7F11)psgw(v);else if(a>=0x8000)w8(zbank|(a&0x7FFF),v)}
function zf8(){const a=zpc;zpc=(a+1)&65535;if(a<0x2000){zcyc+=3;return zr[a]}return zrb(a)}
function zf16(){const l=zf8();return l|zf8()<<8}
function zea(){if(!zx)return Z[4]<<8|Z[5];return((zx==1?zix:ziy)+(zf8()<<24>>24))&65535}
function grp(p:number):number{return p==3?zsp:p==2?(zx==0?Z[4]<<8|Z[5]:zx==1?zix:ziy):Z[p*2]<<8|Z[p*2+1]}
function srp(p:number,v:number):void{v&=65535;if(p==3)zsp=v;else if(p==2){if(zx==0){Z[4]=v>>8;Z[5]=v&255}else if(zx==1)zix=v;else ziy=v}else{Z[p*2]=v>>8;Z[p*2+1]=v&255}}
function zpush(v:number):void{zsp=(zsp-1)&65535;zwb(zsp,v>>8);zsp=(zsp-1)&65535;zwb(zsp,v&255)}
function zpop(){const l=zrb(zsp);zsp=(zsp+1)&65535;const h=zrb(zsp);zsp=(zsp+1)&65535;return l|h<<8}
function zcc(y:number):number|boolean{const f=zF;switch(y){case 0:return!(f&64);case 1:return f&64;case 2:return!(f&1);case 3:return f&1;case 4:return!(f&4);case 5:return f&4;case 6:return!(f&128);default:return f&128}}
function zalu(y:number,b:number):void{const a=Z[7],c=zF&1;let r;
switch(y){case 0:case 1:r=a+b+(y&&c?1:0);zF=(r&128)|((r&255)?0:64)|((a^b^r)&16)|(((a^r)&(b^r)&128)?4:0)|((r>>8)&1)|(r&40);Z[7]=r;break;
case 2:case 3:case 7:r=a-b-(y==3&&c?1:0);zF=(r&128)|((r&255)?0:64)|((a^b^r)&16)|(((a^b)&(a^r)&128)?4:0)|2|((r>>8)&1)|((y==7?b:r)&40);if(y!=7)Z[7]=r;break;
case 4:r=a&b;zF=(r&128)|(r?0:64)|16|PAR[r]|(r&40);Z[7]=r;break;
case 5:r=a^b;zF=(r&128)|(r?0:64)|PAR[r]|(r&40);Z[7]=r;break;
default:r=a|b;zF=(r&128)|(r?0:64)|PAR[r]|(r&40);Z[7]=r}}
function zinc(v:number):number{const r=(v+1)&255;zF=(zF&1)|(r&128)|(r?0:64)|((v&15)==15?16:0)|(v==127?4:0)|(r&40);return r}
function zdec(v:number):number{const r=(v-1)&255;zF=(zF&1)|(r&128)|(r?0:64)|((v&15)==0?16:0)|(v==128?4:0)|2|(r&40);return r}
function zadd16(a:number,b:number):number{const r=a+b;zF=(zF&0xC4)|(((a^b^r)>>8)&16)|((r>>16)&1)|((r>>8)&40);return r&65535}
function zsh(y:number,v:number):number{let r,c;switch(y){case 0:c=v>>7;r=((v<<1)|c)&255;break;case 1:c=v&1;r=(v>>1)|(c<<7);break;case 2:c=v>>7;r=((v<<1)|(zF&1))&255;break;case 3:c=v&1;r=(v>>1)|((zF&1)<<7);break;case 4:c=v>>7;r=(v<<1)&255;break;case 5:c=v&1;r=(v>>1)|(v&128);break;case 6:c=v>>7;r=((v<<1)|1)&255;break;default:c=v&1;r=v>>1}zF=(r&128)|(r?0:64)|PAR[r]|c|(r&40);return r}
function zdaa(){const a=Z[7],n=zF&2;let c=zF&1,adj=0;if((zF&16)||(a&15)>9)adj|=6;if(c||a>0x99){adj|=0x60;c=1}const r=n?(a-adj)&255:(a+adj)&255;zF=(r&128)|(r?0:64)|((a^r)&16)|PAR[r]|n|c|(r&40);Z[7]=r}
function zcb(o:number,a:number):void{const x=o>>6,y=(o>>3)&7,z=o&7,m=a>=0||z==6;if(a<0&&z==6)a=Z[4]<<8|Z[5];let v=m?zrb(a):Z[z];zcyc+=m?2:1;
if(x==1){const b=v&(1<<y);zF=(zF&1)|16|(b?0:68)|((y==7&&b)?128:0)|(v&40);return}
if(x==0)v=zsh(y,v);else if(x==2)v&=~(1<<y);else v|=1<<y;if(m)zwb(a,v);if(z!=6)Z[z]=v}
function zed(){const o=zf8(),x=o>>6,y=(o>>3)&7,z=o&7,p=y>>1,q=y&1;zcyc+=1;
if(x==1){switch(z){case 0:if(y!=6)Z[y]=255;zF=(zF&1)|(y==6?0:128);break;case 1:break;
case 2:{const a=grp(2),b=grp(p),c=zF&1;if(q==0){const r=a-b-c;zF=((r>>8)&128)|((r&65535)?0:64)|(((a^b^r)>>8)&16)|((((a^b)&(a^r))&0x8000)?4:0)|2|((r>>16)&1)|((r>>8)&40);srp(2,r)}else{const r=a+b+c;zF=((r>>8)&128)|((r&65535)?0:64)|(((a^b^r)>>8)&16)|(((~(a^b)&(a^r))&0x8000)?4:0)|((r>>16)&1)|((r>>8)&40);srp(2,r)}zcyc+=7;break}
case 3:{const a=zf16();if(q==0){const v=grp(p);zwb(a,v&255);zwb(a+1,v>>8)}else srp(p,zrb(a)|(zrb(a+1)<<8));break}
case 4:{const a=Z[7];Z[7]=0;zalu(2,a);break}
case 5:zpc=zpop();ziff1=ziff2;break;case 6:zim=y==2?1:y==3?2:0;break;
default:switch(y){case 0:zi=Z[7];break;case 1:zrr=Z[7];break;case 2:Z[7]=zi;zF=(zF&1)|(zi&128)|(zi?0:64)|(ziff2?4:0);break;case 3:Z[7]=zrr&127;zF=(zF&1)|((zrr&127)?0:64)|(ziff2?4:0);break;
case 4:{const a=Z[4]<<8|Z[5],v=zrb(a),A=Z[7];zwb(a,((A&15)<<4)|(v>>4));Z[7]=(A&0xF0)|(v&15);zF=(zF&1)|(Z[7]&128)|(Z[7]?0:64)|PAR[Z[7]];break}
case 5:{const a=Z[4]<<8|Z[5],v=zrb(a),A=Z[7];zwb(a,((v<<4)&255)|(A&15));Z[7]=(A&0xF0)|(v>>4);zF=(zF&1)|(Z[7]&128)|(Z[7]?0:64)|PAR[Z[7]];break}}}return}
if(x==2&&y>=4&&z<2){const d=y&1?-1:1;let hl=Z[4]<<8|Z[5],bc=(Z[0]<<8|Z[1])-1&65535;const rep=y>=6;zcyc+=5;
if(z==0){let de=Z[2]<<8|Z[3];const v=zrb(hl);zwb(de,v);de=(de+d)&65535;Z[2]=de>>8;Z[3]=de&255;const t=Z[7]+v;zF=(zF&0xC1)|(bc?4:0)|((t&2)?32:0)|(t&8);hl=(hl+d)&65535;Z[0]=bc>>8;Z[1]=bc&255;Z[4]=hl>>8;Z[5]=hl&255;if(rep&&bc){zpc=(zpc-2)&65535;zcyc+=5}}
else{const v=zrb(hl),r=(Z[7]-v)&255;zF=(zF&1)|2|(r&128)|(r?0:64)|((Z[7]^v^r)&16)|(bc?4:0);hl=(hl+d)&65535;Z[0]=bc>>8;Z[1]=bc&255;Z[4]=hl>>8;Z[5]=hl&255;if(rep&&bc&&r){zpc=(zpc-2)&65535;zcyc+=5}}}}
function zstep(){
if(zint&&ziff1){zint=0;ziff1=ziff2=0;zhalt=0;zpush(zpc);zpc=0x38;zcyc+=13;return}
if(zhalt){zcyc+=4;return}
zx=0;let op=zf8();zcyc+=1;zrr=(zrr+1)&255;while(op==0xDD||op==0xFD){zx=op==0xDD?1:2;op=zf8();zcyc+=1}
const x=op>>6,y=(op>>3)&7,z=op&7,p=y>>1,q=y&1;
if(x==1){if(op==0x76){zhalt=1;zpc=(zpc-1)&65535}else if(y==6)zwb(zea(),Z[z]);else if(z==6)Z[y]=zrb(zea());else Z[y]=Z[z];return}
if(x==2){zalu(y,z==6?zrb(zea()):Z[z]);return}
if(x==0){switch(z){
case 0:if(y==0){}else if(y==1){let t=Z[7];Z[7]=ZA2;ZA2=t;t=zF;zF=zF2;zF2=t}else if(y==2){Z[0]=(Z[0]-1)&255;const d=zf8()<<24>>24;if(Z[0]){zpc=(zpc+d)&65535;zcyc+=5}}else{const d=zf8()<<24>>24;if(y==3||zcc(y-4)){zpc=(zpc+d)&65535;zcyc+=5}}break;
case 1:if(q==0)srp(p,zf16());else{srp(2,zadd16(grp(2),grp(p)));zcyc+=7}break;
case 2:{if(q==0){if(p==0)zwb(Z[0]<<8|Z[1],Z[7]);else if(p==1)zwb(Z[2]<<8|Z[3],Z[7]);else if(p==2){const a=zf16(),v=grp(2);zwb(a,v&255);zwb(a+1,v>>8)}else zwb(zf16(),Z[7])}
else{if(p==0)Z[7]=zrb(Z[0]<<8|Z[1]);else if(p==1)Z[7]=zrb(Z[2]<<8|Z[3]);else if(p==2){const a=zf16();srp(2,zrb(a)|(zrb(a+1)<<8))}else Z[7]=zrb(zf16())}break}
case 3:srp(p,grp(p)+(q?-1:1));zcyc+=2;break;
case 4:if(y==6){const a=zea();zwb(a,zinc(zrb(a)))}else Z[y]=zinc(Z[y]);break;
case 5:if(y==6){const a=zea();zwb(a,zdec(zrb(a)))}else Z[y]=zdec(Z[y]);break;
case 6:if(y==6){const a=zea();zwb(a,zf8())}else Z[y]=zf8();break;
default:{const A=Z[7];let c;switch(y){case 0:c=A>>7;Z[7]=((A<<1)|c)&255;zF=(zF&0xC4)|c|(Z[7]&40);break;case 1:c=A&1;Z[7]=(A>>1)|(c<<7);zF=(zF&0xC4)|c|(Z[7]&40);break;case 2:c=A>>7;Z[7]=((A<<1)|(zF&1))&255;zF=(zF&0xC4)|c|(Z[7]&40);break;case 3:c=A&1;Z[7]=(A>>1)|((zF&1)<<7);zF=(zF&0xC4)|c|(Z[7]&40);break;case 4:zdaa();break;case 5:Z[7]=~A&255;zF=(zF&0xC5)|0x12|(Z[7]&40);break;case 6:zF=(zF&0xC4)|1|(A&40);break;default:zF=(zF&0xC4)|((zF&1)?16:0)|((zF&1)?0:1)|(A&40)}}}return}
switch(z){
case 0:if(zcc(y)){zpc=zpop();zcyc+=1}break;
case 1:if(q==0){const v=zpop();if(p==3){Z[7]=v>>8;zF=v&255}else srp(p,v)}else if(p==0)zpc=zpop();else if(p==1){for(let i=0;i<6;i++){const t=Z[i];Z[i]=Z2[i];Z2[i]=t}}else if(p==2)zpc=grp(2);else{zsp=grp(2);zcyc+=2}break;
case 2:{const a=zf16();if(zcc(y))zpc=a;break}
case 3:switch(y){case 0:zpc=zf16();break;case 1:if(zx){const a=((zx==1?zix:ziy)+(zf8()<<24>>24))&65535;zcb(zf8(),a)}else zcb(zf8(),-1);break;case 2:zf8();break;case 3:zf8();Z[7]=255;break;
case 4:{const v=zpop();zpush(grp(2));srp(2,v);zcyc+=3;break}
case 5:{for(let i=2;i<4;i++){const t=Z[i];Z[i]=Z[i+2];Z[i+2]=t}break}
case 6:ziff1=ziff2=0;break;default:ziff1=ziff2=1}break;
case 4:{const a=zf16();if(zcc(y)){zpush(zpc);zpc=a;zcyc+=1}break}
case 5:if(q==0){const v=p==3?(Z[7]<<8|zF):grp(p);zpush(v);zcyc+=1}else if(p==0){const a=zf16();zpush(zpc);zpc=a;zcyc+=1}else if(p==2)zed();break;
case 6:zalu(y,zf8());break;
default:zpush(zpc);zpc=y*8;zcyc+=1}}
let ZA2=0;
function z80(n:number):void{if(zbus||zrs){zbud=0;return}zbud+=n;let g=0;while(zbud>0&&g++<400){const c=zcyc;zstep();const d=zcyc-c;zbud-=d>0?d:1}if(zbud>0)zbud=0}
function zrun(n:number):void{if(line===224)zint=1;else if(line===225)zint=0;ymTimers(3.39);
if(AU.ctx&&AU.on&&spd===1){AU.zc+=n;const cps=3579545/AU.sr;while(AU.zc>=cps){AU.zc-=cps;z80(cps);audioPush()}}else{AU.zc=0;z80(n)}}
/* ---- YM2612 ---- */
const YR=new Uint8Array(512),YM={ad:0,pt:0,hi:0,fa:0,fb:0,ctl:0,ta:0,tb:0,nA:0,nB:0,dac:0,dv:0,ec:0,ect:0,L:0,R:0};
const YCH:YMChannelState[]=[];function ymInit(){YR.fill(0);Object.assign(YM,{ad:0,pt:0,hi:0,fa:0,fb:0,ctl:0,ta:0,tb:0,nA:0,nB:0,dac:0,dv:0});YCH.length=0;for(let i=0;i<6;i++){const c:YMChannelState={fn:0,bl:0,fb:0,al:0,hz:0,p1:0,p2:0,pl:1,pr:1,op:[]};for(let j=0;j<4;j++)c.op.push({mx:.5,tl:127,ks:0,ar:0,d1:0,d2:0,sl:0,rr:0,ph:0,att:1023,st:3});YCH.push(c)}}
const SN=new Float32Array(4096);for(let i=0;i<4096;i++)SN[i]=Math.sin(i*6.283185307/4096);
const PW=new Float32Array(1024);for(let i=0;i<1024;i++)PW[i]=Math.pow(2,-i/64);
const SLOT=[0,2,1,3];
function ymr(){return YM.fa|(YM.fb<<1)}
function ymTimers(u:number):void{const c=YM.ctl;if(c&1){YM.ta+=u;const P=1024-YM.nA;if(YM.ta>=P){YM.ta%=P;if(c&4)YM.fa=1}}if(c&2){YM.tb+=u/16;const P=256-YM.nB;if(YM.tb>=P){YM.tb%=P;if(c&8)YM.fb=1}}}
function ymw(p:number,v:number):void{if(!(p&1)){YM.ad=v;YM.pt=p>>1;return}const a=YM.ad,pt=YM.pt;YR[(pt<<8)|a]=v;
if(pt==0&&a<0x30){switch(a){case 0x24:YM.nA=(v<<2)|(YR[0x25]&3);break;case 0x25:YM.nA=(YR[0x24]<<2)|(v&3);break;case 0x26:YM.nB=v;break;
case 0x27:{const o=YM.ctl;YM.ctl=v;if(v&1&&!(o&1))YM.ta=0;if(v&2&&!(o&2))YM.tb=0;if(v&0x10)YM.fa=0;if(v&0x20)YM.fb=0;break}
case 0x28:{let ch=v&7;if(ch==3||ch>6)break;if(ch>3)ch--;const c=YCH[ch];for(let i=0;i<4;i++){const o=c.op[i];if((v>>(4+i))&1){if(o.st==3){o.ph=0;o.st=0;if(ymRate(o,c,o.ar)>=62)o.att=0}}else o.st=3}break}
case 0x2A:YM.dv=(v-128)/128*.5;break;case 0x2B:YM.dac=v>>7;break}return}
if((a&3)==3)return;const ch=(a&3)+pt*3,c=YCH[ch];
if(a>=0xA0){if(a<0xA4){c.fn=((YM.hi&7)<<8)|v;c.bl=(YM.hi>>3)&7;c.hz=(c.fn*Math.pow(2,c.bl)/2)*53267/1048576}else if(a<0xA8)YM.hi=v&63;else if(a>=0xB0&&a<0xB4){c.al=v&7;c.fb=(v>>3)&7}else if(a>=0xB4&&a<0xB8){c.pl=(v>>7)&1;c.pr=(v>>6)&1}return}
if(a<0x30)return;const o=c.op[SLOT[(a>>2)&3]];switch(a&0xF0){case 0x30:o.mx=(v&15)||.5;break;case 0x40:o.tl=v&127;break;case 0x50:o.ks=v>>6;o.ar=v&31;break;case 0x60:o.d1=v&31;break;case 0x70:o.d2=v&31;break;case 0x80:o.sl=v>>4;o.rr=v&15}}
function ymRate(o:YMOperatorState,c:YMChannelState,R:number):number{if(!R)return 0;const kc=(c.bl<<2)|((c.fn>>9)&3);return Math.min(63,2*R+(kc>>(3-o.ks)))}
function ymEnv(o:YMOperatorState,c:YMChannelState):void{let R=o.st==0?o.ar:o.st==1?o.d1:o.st==2?o.d2:o.rr*2+1;if(!R)return;const Rr=ymRate(o,c,R),sh=11-(Rr>>2);if(sh>0&&(YM.ec&((1<<sh)-1)))return;const inc=(4+(Rr&3))/4*(sh<0?(1<<-sh):1);
if(o.st==0){o.att-=(o.att+1)*inc/16;if(o.att<=0){o.att=0;o.st=1}}else{o.att=Math.min(1023,o.att+inc);if(o.st==1&&o.att>=(o.sl==15?992:o.sl*32))o.st=2}}
function ymF(o:YMOperatorState,c:YMChannelState,m:number):number{o.ph+=c.hz*o.mx/AU.sr;if(o.ph>=1)o.ph-=1;return SN[((o.ph*4096+m*651.8986)|0)&4095]*PW[Math.min(1023,(o.att|0)+(o.tl<<3))]}
function ymCh(c:YMChannelState):number{const O=c.op;if(O[0].st==3&&O[1].st==3&&O[2].st==3&&O[3].st==3&&O[0].att>=1000&&O[1].att>=1000&&O[2].att>=1000&&O[3].att>=1000)return 0;
const T=12.566371,o1=ymF(O[0],c,(c.p1+c.p2)*.5*Math.PI*Math.pow(2,c.fb-5)*(c.fb?1:0));c.p2=c.p1;c.p1=o1;let o2,o3;
switch(c.al){case 0:o2=ymF(O[1],c,o1*T);o3=ymF(O[2],c,o2*T);return ymF(O[3],c,o3*T);
case 1:o2=ymF(O[1],c,0);o3=ymF(O[2],c,(o1+o2)*T);return ymF(O[3],c,o3*T);
case 2:o2=ymF(O[1],c,0);o3=ymF(O[2],c,o2*T);return ymF(O[3],c,(o1+o3)*T);
case 3:o2=ymF(O[1],c,o1*T);o3=ymF(O[2],c,0);return ymF(O[3],c,(o2+o3)*T);
case 4:o2=ymF(O[1],c,o1*T);o3=ymF(O[2],c,0);return o2+ymF(O[3],c,o3*T);
case 5:return ymF(O[1],c,o1*T)+ymF(O[2],c,o1*T)+ymF(O[3],c,o1*T);
case 6:o2=ymF(O[1],c,o1*T);return o2+ymF(O[2],c,0)+ymF(O[3],c,0);
default:return o1+ymF(O[1],c,0)+ymF(O[2],c,0)+ymF(O[3],c,0)}}
function ymSample(){YM.ect+=17755/AU.sr;while(YM.ect>=1){YM.ect--;YM.ec++;for(let i=0;i<6;i++){const c=YCH[i];for(let j=0;j<4;j++)ymEnv(c.op[j],c)}}
let l=0,r=0;for(let i=0;i<6;i++){const c=YCH[i],v=(i==5&&YM.dac)?YM.dv*2:ymCh(c);if(c.pl!==0)l+=v;if(c.pr!==0)r+=v}YM.L=l*.16;YM.R=r*.16;return 0}
ymInit();
/* ---- som: PSG (SN76489) + saída de áudio suave ---- */
const AU:MegaDriveAudioRuntime={ctx:null,node:null,sr:44100,buf:new Float32Array(32768),bR:new Float32Array(32768),l3:0,zc:0,w:0,r:0,on:1,pre:1,last:0,nf:735,q:0,l2:0,readFrac:0};try{AU.on=localStorage.getItem("mdsnd")!=="0"?1:0}catch(e){}
const psg:PSGRuntime={t:[0,0,0],v:[15,15,15,15],c:[1,1,1],o:[1,1,1],n:0,nc:1,lf:0x8000,ch:0,vt:0,ac:0};
function psgInit(){psg.t=[0,0,0];psg.v=[15,15,15,15];psg.c=[1,1,1];psg.o=[1,1,1];psg.n=0;psg.nc=1;psg.lf=0x8000;psg.ch=0;psg.vt=0;psg.ac=0;AU.w=AU.r=0;AU.pre=1;AU.q=0;AU.l2=0;AU.last=0;AU.readFrac=0}
const PV=[...Array(16)].map((_,i)=>i==15?0:.1*Math.pow(10,-i/10));
function psgw(v:number):void{if(v&128){psg.ch=(v>>5)&3;psg.vt=(v>>4)&1;if(psg.vt)psg.v[psg.ch]=v&15;else if(psg.ch<3)psg.t[psg.ch]=(psg.t[psg.ch]&0x3F0)|(v&15);else{psg.n=v&7;psg.lf=0x8000}}else if(!psg.vt&&psg.ch<3)psg.t[psg.ch]=(psg.t[psg.ch]&15)|((v&63)<<4)}
function psgSample(){psg.ac+=223722/AU.sr;let sum=0,cn=0;
while(psg.ac>=1){psg.ac--;for(let k=0;k<3;k++)if(--psg.c[k]<=0){psg.c[k]=Math.max(psg.t[k],1);psg.o[k]^=1}
if(--psg.nc<=0){const q=psg.n&3;psg.nc=q==3?Math.max(psg.t[2],1):16<<q;const fb=psg.n&4?((psg.lf&1)^((psg.lf>>3)&1)):psg.lf&1;psg.lf=(psg.lf>>1)|(fb<<15)}
let o=(psg.lf&1?1:-1)*PV[psg.v[3]];for(let k=0;k<3;k++)o+=(psg.o[k]?1:-1)*PV[psg.v[k]];sum+=o;cn++}
return cn?sum/cn:AU.last}
function audioFrame(){}
let dcx=0,dcy=0,dcx2=0,dcy2=0;
const REC:RecordingRuntime={on:0,L:[],R:[],i:0,n:0,sr:44100};
function recPush(x:number,z:number):void{if(REC.i===0||REC.i>=16384){REC.L.push(new Int16Array(16384));REC.R.push(new Int16Array(16384));REC.i=0}const k=REC.L.length-1;REC.L[k][REC.i]=Math.max(-1,Math.min(1,x))*32767;REC.R[k][REC.i]=Math.max(-1,Math.min(1,z))*32767;REC.i++;REC.n++;if(REC.n>=REC.sr*300)recStop()}
function audioPush(){const p=psgSample();ymSample();AU.last=p;const a=p+YM.L,b=p+YM.R;const x=a-dcx+.995*dcy;dcx=a;dcy=x;const z=b-dcx2+.995*dcy2;dcx2=b;dcy2=z;if(REC.on)recPush(x,z);if(((AU.w+1)&32767)!==AU.r){AU.buf[AU.w]=x;AU.bR[AU.w]=z;AU.w=(AU.w+1)&32767}}
var gbHold=0;
function startAudio(){if(gbHold)return;const C=window.AudioContext||window.webkitAudioContext;if(!C)return;
if(AU.ctx){if(AU.ctx.state!=="running"){try{const p=AU.ctx.resume();if(p&&p.catch)p.catch(()=>{})}catch(e){}}return}
try{let ac;try{ac=new C({latencyHint:"playback"})}catch(e){ac=new C()}AU.sr=ac.sampleRate||44100;const sp=ac.createScriptProcessor(4096,0,2);
const lp=ac.createBiquadFilter();lp.type="lowpass";lp.frequency.value=12000;lp.Q.value=.5;const g=ac.createGain();g.gain.value=.9;
sp.onaudioprocess=e=>{const o=e.outputBuffer.getChannelData(0),q=e.outputBuffer.getChannelData(1);if(!AU.on){o.fill(0);q.fill(0);AU.r=AU.w;AU.pre=1;AU.l2=0;AU.l3=0;return}let l=AU.l2,m=AU.l3;
for(let i=0;i<o.length;i++){if(AU.pre&&((AU.w-AU.r)&32767)>=4096)AU.pre=0;if(!AU.pre&&AU.r!==AU.w){l=AU.buf[AU.r];m=AU.bR[AU.r];AU.r=(AU.r+1)&32767}else{l*=.995;m*=.995;if(!AU.pre)AU.pre=1}o[i]=l;q[i]=m}AU.l2=l;AU.l3=m};
AU.node=sp;AU.ctx=ac;AU.w=AU.r=0;AU.pre=1;AU.zc=0;sp.connect(lp);lp.connect(g);g.connect(ac.destination);
if(ac.state!=="running"){const p=ac.resume();if(p&&p.catch)p.catch(()=>{})}}catch(e){AU.ctx=null}}
["pointerdown","touchstart","mousedown","keydown"].forEach(ev=>addEventListener(ev,startAudio,true));
function sndSync(){document.querySelectorAll<HTMLElement>("#sa button").forEach(x=>x.classList.toggle("on",x.dataset.v===String(AU.on)))}
document.querySelectorAll<HTMLElement>("#sa button").forEach(x=>x.onclick=()=>{AU.on=+x.dataset.v;try{localStorage.setItem("mdsnd",String(AU.on))}catch(e){}if(AU.on)startAudio();sndSync()});
sndSync();
let recT=0;const rst=(m:string):void=>{$("recs").textContent=m};const fmt=(n:number):string=>{const t=Math.floor(n/REC.sr);return Math.floor(t/60)+":"+String(t%60).padStart(2,"0")};
function recStop(){if(!REC.on)return;REC.on=0;clearInterval(recT);$("recb").textContent="⏺ Gravar";if(REC.n>REC.sr/2){$("recd").style.display="flex";rst("Gravado: "+fmt(REC.n)+". Escolha o formato.")}else rst("Gravação muito curta.")}
function recFlat(c:Int16Array[]):Int16Array{const o=new Int16Array(REC.n);for(let k=0;k<c.length;k++){const a=c[k];o.set(k===c.length-1?a.subarray(0,REC.n-k*16384):a,k*16384)}return o}
function recSave(b:Blob,ext:string):void{const u=URL.createObjectURL(b),a=document.createElement("a"),d=new Date(),z=(n:number)=>String(n).padStart(2,"0");a.href=u;a.download="megadrive_"+d.getFullYear()+z(d.getMonth()+1)+z(d.getDate())+"_"+z(d.getHours())+z(d.getMinutes())+z(d.getSeconds())+"."+ext;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),60000)}
function mkWav(L:Int16Array,R:Int16Array){const n=L.length,B=new ArrayBuffer(44+n*4),v=new DataView(B),w=(o:number,t:string):void=>{for(let i=0;i<t.length;i++)v.setUint8(o+i,t.charCodeAt(i))};w(0,"RIFF");v.setUint32(4,36+n*4,true);w(8,"WAVEfmt ");v.setUint32(16,16,true);v.setUint16(20,1,true);v.setUint16(22,2,true);v.setUint32(24,REC.sr,true);v.setUint32(28,REC.sr*4,true);v.setUint16(32,4,true);v.setUint16(34,16,true);w(36,"data");v.setUint32(40,n*4,true);for(let i=0,o=44;i<n;i++,o+=4){v.setInt16(o,L[i],true);v.setInt16(o+2,R[i],true)}return new Blob([B],{type:"audio/wav"})}
function loadLame():Promise<void>{return new Promise<void>((ok,no)=>{if(window.lamejs)return ok();const u=["https://cdnjs.cloudflare.com/ajax/libs/lamejs/1.2.1/lame.min.js","https://cdn.jsdelivr.net/npm/lamejs@1.2.1/lame.min.js"];let i=0;const t=()=>{if(i>=u.length)return no();const s=document.createElement("script");s.src=u[i++];s.onload=()=>window.lamejs?ok():t();s.onerror=t;document.head.appendChild(s)};t()})}
$("recb").onclick=()=>{if(REC.on){recStop();return}if(!AU.on){rst("Ligue o Som para gravar.");return}startAudio();REC.sr=AU.sr;REC.L=[];REC.R=[];REC.i=0;REC.n=0;REC.on=1;$("recd").style.display="none";$("recb").textContent="⏹ Parar";rst("Gravando… 0:00 (máx. 5 min)");recT=setInterval(()=>rst("Gravando… "+fmt(REC.n)+" (máx. 5 min)"),500)};
$("dlwav").onclick=()=>{rst("Gerando WAV…");setTimeout(()=>{recSave(mkWav(recFlat(REC.L),recFlat(REC.R)),"wav");rst("WAV salvo.")},30)};
$("dlmp3").onclick=async()=>{rst("Carregando codificador MP3…");try{await loadLame()}catch(e){rst("MP3 precisa de internet na 1ª vez. Baixe em WAV ou tente de novo online.");return}
const L=recFlat(REC.L),R=recFlat(REC.R),E=new window.lamejs!.Mp3Encoder(2,REC.sr,192),out=[],S=11520;for(let i=0,k=0;i<L.length;i+=S,k++){const a=E.encodeBuffer(L.subarray(i,i+S),R.subarray(i,i+S));if(a.length)out.push(new Uint8Array(a));if(k%10===0){rst("Gerando MP3… "+Math.round(i/L.length*100)+"%");await new Promise<void>(r=>setTimeout(r))}}
const f=E.flush();if(f.length)out.push(new Uint8Array(f));recSave(new Blob(out,{type:"audio/mpeg"}),"mp3");rst("MP3 salvo.")};
/* ---- celular fraco: automático / leve / muito leve ---- */
let PFset="auto",PFauto=0,pfN=0,pfE=0,pfLow=0;
try{PFset=localStorage.getItem("mdperf")||"auto";PFauto=+localStorage.getItem("mdpfauto")||0}catch(e){}
function pfDetect(){const c=navigator.hardwareConcurrency||4,m=navigator.deviceMemory||4;return(m<=2||c<=2)?2:(m<=3||c<=4)?1:0}
function pfSync(){document.querySelectorAll<HTMLElement>("#spf button").forEach(x=>x.classList.toggle("on",x.dataset.v===PFset));const t=$("pfn");if(t)t.textContent="Ativo agora: "+["Normal","Leve","Muito leve"][PF]}
function pfApply(){const n=PFset==="auto"?Math.max(pfDetect(),PFauto):+PFset;if(n!==PF){PF=n;try{rs()}catch(e){}}document.documentElement.dataset.pf=String(PF);pfSync()}
document.querySelectorAll<HTMLElement>("#spf button").forEach(x=>x.onclick=()=>{PFset=x.dataset.v;pfN=0;pfE=0;PFauto=0;try{localStorage.setItem("mdperf",String(PFset));localStorage.removeItem("mdpfauto")}catch(e){}pfApply()});
pfApply();
function tick(t:number):boolean{let dt=t-last;last=t;if(dt>100||dt<0)dt=16.67;if(Math.abs(dt-16.67)<2.5)dt=16.67;else if(Math.abs(dt-8.33)<1.5)dt=8.333;acc+=dt*spd;if(acc>(PF?75:40)*Math.max(1,spd))acc=16.67;
try{let n=0;if(window.__padJump){window.__padJump=0;if(acc<16.5)acc=16.667}if(AU.ctx&&AU.on&&spd===1){const lv=(AU.w-AU.r)&32767;if(lv<AU.sr*.06&&acc<16.5)acc=16.667;else if(lv>AU.sr*.25)acc=Math.min(acc,16.2)}
while(acc>=16.5&&n<(spd>2?5:(spd>1||PF?3:2))){skipR=PF&&(acc>=33.2||(PF>1&&(++skc&1)))?1:0;const t0=performance.now();frame();if(!skipR)frDn=1;if(PFset==="auto"&&++pfN>150){pfE=pfE*.94+(performance.now()-t0)*.06;if(PF<2&&pfE>(PF?19:13)){PFauto=PF+1;try{localStorage.setItem("mdpfauto",String(PFauto))}catch(e){}pfN=0;pfE=0;pfLow=0;pfApply()}else if(PFauto>0&&pfE<5){if(++pfLow>900){PFauto--;try{localStorage.setItem("mdpfauto",String(PFauto))}catch(e){}pfN=0;pfE=0;pfLow=0;pfApply()}}else pfLow=0}acc-=16.667;n++}if(sdirty&&++sf>90){sf=0;sdirty=0;idle(saveSram)}if(n&&(frDn||!PF)){frDn=0;if(!(++fc&31)&&cv.clientWidth!==lw){lw=cv.clientWidth;rs()}octx.putImageData(img,0,0);ctx.drawImage(oc,0,0,320*KK,224*KK);if(scan&&!PF)ctx.drawImage(scn,0,0)}}
catch(e){acc=0;if(++errs>30){run=0;$("st").textContent="Parou: "+(e instanceof Error ? e.message : String(e));return false}$("st").textContent="Aviso: "+(e instanceof Error ? e.message : String(e))}
return true}
function saveSram(){try{localStorage.setItem("mdsram_"+currentKey,uint8ToBase64(sram))}catch(e){}}
const roms:SystemRomEntry<Uint8Array>[]=[],gbroms:SystemRomEntry<Blob>[]=[];let system:SystemKey="md",curRom:number|null=null;
try{Object.keys(localStorage).filter(k=>/^ds(recent|favorites|cover_|layout|legacy|btn|vib|gpu|core|skip)/.test(k)).forEach(k=>localStorage.removeItem(k))}catch(e){}
try{const m=JSON.parse(localStorage.getItem("mdlast")||"null");if(m&&m.s==="ds")localStorage.removeItem("mdlast")}catch(e){}
try{system=localStorage.getItem("mdsys")==="gb"?"gb":"md"}catch(e){}
try{navigator.storage&&navigator.storage.persist&&navigator.storage.persist()}catch(e){}
const dbp: Promise<IDBDatabase | null> = new Promise((res: (db: IDBDatabase | null) => void)=>{try{const q=indexedDB.open("mdjs",6);q.onupgradeneeded=()=>{const d=q.result;if(!d.objectStoreNames.contains("roms"))d.createObjectStore("roms",{keyPath:"name"});if(!d.objectStoreNames.contains("states"))d.createObjectStore("states",{keyPath:"key"});if(d.objectStoreNames.contains("dsroms"))d.deleteObjectStore("dsroms");if(!d.objectStoreNames.contains("gbroms"))d.createObjectStore("gbroms",{keyPath:"name"});if(!d.objectStoreNames.contains("gbsav"))d.createObjectStore("gbsav")};q.onsuccess=()=>{const d=q.result;d.onversionchange=()=>d.close();res(d)};q.onerror=()=>res(null)}catch(e){res(null)}});
function dbPut(r:SystemRomEntry<Uint8Array>):void{dbp.then(d=>{if(!d)return;try{d.transaction("roms","readwrite").objectStore("roms").put({name:r.name,data:r.data})}catch(e){}})}
function dbDel(name:string):void{dbp.then(d=>{if(!d)return;try{d.transaction("roms","readwrite").objectStore("roms").delete(name)}catch(e){}})}
function gbPut(rec:SystemRomEntry<Blob>):Promise<boolean>{return new Promise(res=>{dbp.then(d=>{if(!d)return res(false);try{const tx=d.transaction("gbroms","readwrite");tx.objectStore("gbroms").put(rec);tx.oncomplete=()=>res(true);tx.onerror=tx.onabort=()=>res(false)}catch(e){res(false)}})})}
function gbDel(name:string):void{dbp.then(d=>{if(!d)return;try{d.transaction("gbroms","readwrite").objectStore("gbroms").delete(name)}catch(e){}})}

/* ---------- biblioteca (Mega Drive e Game Boy Color usam a mesma lógica) ---------- */
const ldArr=(k:string):string[]=>{try{const v=JSON.parse(localStorage.getItem(k)||"[]");return Array.isArray(v)?v:[]}catch(e){return[]}};
const recent=ldArr("mdrecent"),favorites=ldArr("mdfavorites"),gbRecent=ldArr("gbrecent"),gbFav=ldArr("gbfavorites");
const MD:SystemLibrary<Uint8Array>={id:"md",name:"Mega Drive",list:roms,recent:recent,fav:favorites,rk:"mdrecent",fk:"mdfavorites",ck:"mdcover_",re:/\.(bin|md|gen|smd|sgd|rom)$/i,ph:"MD"};
const GB:SystemLibrary<Blob>={id:"gb",name:"Game Boy Color",list:gbroms,recent:gbRecent,fav:gbFav,rk:"gbrecent",fk:"gbfavorites",ck:"gbcover_",re:/\.(gb|gbc|sgb|gba|sfc|smc|swc|fig|zip)$/i,ph:"GBA"};
const SYSS:Record<SystemKey,AnySystemLibrary>={md:MD,gb:GB};
const sj=(k:string,v:unknown):void=>{try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}};
let tab=0;
const isFav=(S:AnySystemLibrary,n:string):boolean=>S.fav.includes(n);
function toggleFav(S:AnySystemLibrary,n:string):void{const i=S.fav.indexOf(n);if(i>=0)S.fav.splice(i,1);else S.fav.push(n);sj(S.fk,S.fav);fillRl()}
function pushRecent(S:AnySystemLibrary,n:string):void{const k=S.recent.indexOf(n);if(k>=0)S.recent.splice(k,1);S.recent.unshift(n);if(S.recent.length>20)S.recent.length=20;sj(S.rk,S.recent)}
function setLast(S:AnySystemLibrary,n:string):void{try{localStorage.setItem("mdlast",JSON.stringify({s:S.id,n}))}catch(e){}}
function lastGame():SystemGameSelection|null{
try{const L=JSON.parse(localStorage.getItem("mdlast")||"null") as {s?:SystemKey;n?:string}|null;if(L&&SYSS[L.s]){const S=SYSS[L.s],i=S.list.findIndex(r=>r.name===L.n);if(i>=0)return{S,i}}}catch(e){}
const n=recent.find(n=>roms.some(r=>r.name===n));if(n!=null)return{S:MD,i:roms.findIndex(r=>r.name===n)};
return null}
function gname(n:string):string{return String(n).split("/").pop().replace(/\.(bin|md|gen|smd|sgd|rom|gb|gbc|sgb|gba|sfc|smc|swc|fig|zip)$/i,"")}
function getCover(S:AnySystemLibrary,n:string):string|null{try{return localStorage.getItem(S.ck+n)}catch(e){return null}}
function fmtSize(b:number):string{return b>=1048576?(b/1048576).toFixed(b>=10485760?0:1)+" MB":Math.max(1,Math.round(b/1024))+" KB"}
function toast(m:string,ms=3200){const t=$("toast") as HTMLElement & {_t?:number};t.textContent=m;t.classList.add("on");clearTimeout(t._t);t._t=window.setTimeout(()=>t.classList.remove("on"),ms||3200)}
let cfY:(()=>void)|null=null,cfN:(()=>void)|null=null;
function ask(t:string,y:()=>void,n?:(()=>void)|null):void{$("cft").textContent=t;cfY=y;cfN=n||null;$("cf").hidden=false}
$("cfy").onclick=()=>{$("cf").hidden=true;const f=cfY;cfY=cfN=null;f&&f()};
$("cfn").onclick=()=>{$("cf").hidden=true;const f=cfN;cfY=cfN=null;f&&f()};
function mkIcon(S:AnySystemLibrary,n:string):HTMLDivElement{const d=document.createElement("div");d.className="gi";const cvr=getCover(S,n);if(cvr){d.style.backgroundImage="url("+cvr+")";return d}
let h=0;for(let i=0;i<n.length;i++)h=(h*31+n.charCodeAt(i))>>>0;
d.style.background="linear-gradient(135deg,hsl("+(h%360)+",60%,48%),hsl("+((h+50)%360)+",60%,30%))";
d.textContent=gname(n).replace(/[^A-Za-z0-9]/g,"").slice(0,2).toUpperCase()||S.ph;return d}
function renderList(){fillRl()}
function setTab(n:number):void{tab=n;document.querySelectorAll<HTMLElement>("#games .ft").forEach((t,i)=>t.classList.toggle("on",i===n));fillRl()}
document.querySelectorAll<HTMLElement>("#games .ft").forEach((t,i)=>t.onclick=()=>setTab(i));
function playRom(i:number):void{const r=roms[i];if(!r)return;curRom=i;pushRecent(MD,r.name);setLast(MD,r.name);
["home","games","opts","pick"].forEach(x=>$(x).hidden=true);
try{window.__setMode&&window.__setMode()}catch(e){}
startRom(r.data,r.name)}
function fillRl(){const S=SYSS[system],rl=$("gl");rl.innerHTML="";
let items=S.list.map((r,i)=>({r,i}));
if(tab===0)items.sort((x,y)=>gname(x.r.name).localeCompare(gname(y.r.name)));
else if(tab===1)items=S.recent.map(n=>items.find(x=>x.r.name===n)).filter(Boolean);
else items=S.fav.map(n=>items.find(x=>x.r.name===n)).filter(Boolean);
$("gcnt").textContent=items.length?items.length+(items.length===1?" jogo":" jogos"):"";
if(!items.length){const e=document.createElement("div");e.className="emp";
if(tab===0){const t=document.createElement("div");t.className="et";t.textContent="Nenhum jogo de "+S.name;
const s=document.createElement("div");s.className="es";s.textContent=S.id==="gb"?"Adicione arquivos .gb, .gbc, .gba, .sfc ou .smc (ou um .zip com um deles dentro).":"Adicione ROMs .bin, .md, .gen, .smd, .sgd ou .rom.";
const b=document.createElement("button");b.type="button";b.className="btn";b.textContent="+ Adicionar jogos";b.onclick=()=>$("f").click();e.append(t,s,b)}
else e.textContent=tab===1?"Nenhum jogo recente ainda.":"Você ainda não marcou favoritos.";
rl.appendChild(e);return}
items.forEach(({r,i})=>{const d=document.createElement("div");d.className="gm";
d.appendChild(mkIcon(S,r.name));
const tx=document.createElement("div");tx.className="gt";
const nm=document.createElement("div");nm.className="gn";nm.textContent=gname(r.name);
const sb=document.createElement("div");sb.className="gs";sb.textContent=(S===GB&&SNRE.test(r.name)?"Super Nintendo":S===GB&&/\.gba$/i.test(r.name)?"Game Boy Advance":S.name)+" · "+fmtSize(S===GB?(r.size||0):(r.data instanceof Blob?r.data.size:r.data.length));
tx.append(nm,sb);d.appendChild(tx);
const fv=isFav(S,r.name),star=document.createElement("button");star.type="button";star.className="gf"+(fv?" on":"");star.textContent=fv?"★":"☆";
star.setAttribute("aria-label",fv?"Remover dos favoritos":"Adicionar aos favoritos");star.onclick=e=>{e.stopPropagation();toggleFav(S,r.name)};d.appendChild(star);
let tm=0,lp=0,sx=0,sy=0;
d.onpointerdown=e=>{if(e.target instanceof Element&&e.target.closest(".gf"))return;lp=0;sx=e.clientX;sy=e.clientY;clearTimeout(tm);tm=setTimeout(()=>{lp=1;askAct(S,i)},550)};
d.onpointermove=e=>{if(tm&&Math.hypot(e.clientX-sx,e.clientY-sy)>10){clearTimeout(tm);tm=0}};
d.onpointerup=d.onpointercancel=d.onpointerleave=()=>{clearTimeout(tm);tm=0};
d.oncontextmenu=e=>{e.preventDefault()};
d.onclick=()=>{if(lp){lp=0;return}S===GB?playGB(i):playRom(i)};
rl.appendChild(d)});
const h=document.createElement("div");h.className="gh";h.textContent="Toque para jogar · segure para mais opções";rl.appendChild(h)}
function setSystem(next:SystemKey):void{system=next;try{localStorage.setItem("mdsys",next)}catch(e){}
$("sysMD").classList.toggle("on",next==="md");$("sysGB").classList.toggle("on",next==="gb");
if(next==="gb")$("f").removeAttribute("accept");else $("f").setAttribute("accept",".bin,.md,.gen,.smd,.sgd,.rom");
fillRl()}
$("sysMD").onclick=()=>setSystem("md");
$("sysGB").onclick=()=>setSystem("gb");
setSystem(system);

/* ---------- Game Boy Color: importação ---------- */
// Confere o logo da Nintendo no cabeçalho da ROM (offset 0x104). Arquivos .zip passam direto.
async function gbPrep(fl:File):Promise<{blob:File;warn:number}|null>{
if(!fl||fl.size<512)return null;
let blob=fl,warn=0;
if(/\.(gb|gbc|sgb)$/i.test(fl.name)){
const h=new Uint8Array(await fl.slice(0x104,0x108).arrayBuffer());
if(!(h[0]===0xCE&&h[1]===0xED&&h[2]===0x66&&h[3]===0x66))warn=1}
return{blob,warn}}
async function addGB(fl:File,name:string):Promise<number>{
const p=await gbPrep(fl);if(!p)return 0;
const rec={name,data:p.blob,size:p.blob.size};
const ok=await gbPut(rec);
const k=gbroms.findIndex(x=>x.name===name);if(k>=0)gbroms[k]=rec;else gbroms.push(rec);
return ok?(p.warn?2:1):-1}

/* ---------- ações do jogo (segurar) ---------- */
let actS:AnySystemLibrary|null=null,actIdx=-1;
function askAct(S:AnySystemLibrary,i:number):void{actS=S;actIdx=i;$("actt").textContent=gname(S.list[i].name);$("actr").hidden=!getCover(S,S.list[i].name);$("act").hidden=false}
function makeCover(fl:File):Promise<string>{return new Promise<string>((res,rej)=>{const u=URL.createObjectURL(fl),im=new Image();
im.onload=()=>{try{const S=160,c2=document.createElement("canvas");c2.width=c2.height=S;const g2=c2.getContext("2d");const mn=Math.min(im.naturalWidth,im.naturalHeight),sx=(im.naturalWidth-mn)/2,sy=(im.naturalHeight-mn)/2;g2.drawImage(im,sx,sy,mn,mn,0,0,S,S);URL.revokeObjectURL(u);res(c2.toDataURL("image/jpeg",.85))}catch(e){rej(e)}};
im.onerror=()=>{URL.revokeObjectURL(u);rej(new Error("img"))};im.src=u})}
$("actx").onclick=()=>{$("act").hidden=true;actIdx=-1};
$("actd").onclick=()=>{const S=actS,i=actIdx;$("act").hidden=true;actIdx=-1;if(S&&i>=0&&S.list[i])askDel(S,i)};
$("actc").onclick=()=>{$("act").hidden=true;$("cvf").click()};
$("actr").onclick=()=>{const S=actS,i=actIdx;$("act").hidden=true;actIdx=-1;if(S&&i>=0&&S.list[i]){try{localStorage.removeItem(S.ck+S.list[i].name)}catch(e){}fillRl()}};
$("cvf").onchange=async e=>{const input=e.currentTarget as HTMLInputElement;const fl=input.files?.[0];input.value="";const S=actS,i=actIdx;actIdx=-1;if(!fl||!S||i<0||!S.list[i])return;
try{const url=await makeCover(fl);localStorage.setItem(S.ck+S.list[i].name,url)}catch(err){toast("Não foi possível usar essa imagem.")}
fillRl()};
function askDel(S:AnySystemLibrary,i:number):void{const r=S.list[i];if(r)ask('Apagar "'+gname(r.name)+'" da lista?',()=>delGame(S,i))}
function delGame(S:AnySystemLibrary,i:number):void{const r=S.list[i];if(!r)return;
if(S===MD)dbDel(r.name);else gbDel(r.name);
const fi=S.fav.indexOf(r.name);if(fi>=0){S.fav.splice(fi,1);sj(S.fk,S.fav)}
try{localStorage.removeItem(S.ck+r.name)}catch(e){}
const k=S.recent.indexOf(r.name);if(k>=0){S.recent.splice(k,1);sj(S.rk,S.recent)}
if(S===MD){if(curRom===i){if(run&&currentKey)saveSram();run=0;lid++;curRom=null;$("st").textContent="ROM apagada: "+r.name+". Escolha outra ROM na lista."}else if(curRom!=null&&curRom>i)curRom--}
S.list.splice(i,1);fillRl();window.__upHome&&window.__upHome()}

/* ---------- carregar o que foi salvo no navegador ---------- */
dbp.then(d=>{if(!d)return;try{const q=d.transaction("roms").objectStore("roms").getAll();q.onsuccess=()=>{for(const r of q.result)if(!roms.some(x=>x.name===r.name))roms.push({name:r.name,data:new Uint8Array(r.data)});if(system==="md")fillRl();window.__upHome&&window.__upHome()}}catch(e){}});
dbp.then(d=>{if(!d)return;try{const q=d.transaction("gbroms").objectStore("gbroms").getAll();q.onsuccess=()=>{for(const r of q.result){if(gbroms.some(x=>x.name===r.name))continue;const data=r.data instanceof Blob?r.data:new Blob([r.data]);gbroms.push({name:r.name,data,size:r.size||data.size})}if(system==="gb")fillRl();window.__upHome&&window.__upHome()}}catch(e){}});

