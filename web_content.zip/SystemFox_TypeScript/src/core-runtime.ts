// System Fox — Integração dos sistemas, ROMs e estados (TypeScript)

function gbId(n:string):number{let h=0;for(let i=0;i<n.length;i++)h=(h*31+n.charCodeAt(i))>>>0;return 1+(h%2000000000)}
function gbSavGet(id: IDBValidKey): Promise<GBCBatterySave | null>{return dbp.then(d=>new Promise<GBCBatterySave | null>(res=>{if(!d)return res(null);try{const q=d.transaction("gbsav").objectStore("gbsav").get(id);q.onsuccess=()=>res(q.result||null);q.onerror=()=>res(null)}catch(e){res(null)}}))}
const gbBak: Record<string, 1> = Object.create(null);
function gbSavPut(id: IDBValidKey,rec: GBCBatterySave): void{dbp.then(d=>{if(!d)return;try{const st=d.transaction("gbsav","readwrite").objectStore("gbsav");
 const backupKey=String(id);if(!gbBak[backupKey]){gbBak[backupKey]=1;const g=st.get(id);g.onsuccess=()=>{if(g.result)st.put(g.result,id+"#bak");st.put(rec,id)};g.onerror=()=>st.put(rec,id)}else st.put(rec,id)}catch(e){}})}
function playGB(i:number):void{const r=gbroms[i];if(!r||gbOn)return;
setLast(GB,r.name);pushRecent(GB,r.name);
if(currentKey)saveSram();run=0;lid++;pad=0;
["home","games","opts","pick"].forEach(x=>$(x).hidden=true);
gbOpen(r)}
async function gbWake(){try{if(navigator.wakeLock&&!gbWL){gbWL=await navigator.wakeLock.request("screen");gbWL.addEventListener("release",()=>{gbWL=null})}}catch(e){}}
function gbRelease(){try{gbWL&&gbWL.release()}catch(e){}gbWL=null}
function gbOpen(r:SystemRomEntry<Blob>):void{gbOn=1;gbCur=r;gbHold=1;try{if(AU.ctx&&AU.ctx.state==="running")AU.ctx.suspend()}catch(e){}
$("gb").hidden=false;$("gb").classList.remove("live");gbFit();$("gbmsg").hidden=false;$("gbspin").hidden=false;$("gbmb").hidden=true;$("gbmt").textContent="Abrindo "+gname(r.name)+"…";
try{const el=document.documentElement;if(!document.fullscreenElement&&el.requestFullscreen)el.requestFullscreen().catch(()=>{})}catch(e){}
gbWake();
if(!gbHist){try{history.pushState({gb:1},"");gbHist=1}catch(e){gbHist=0}}
const fr=document.createElement("iframe");fr.id="gbf";fr.setAttribute("allow","autoplay; fullscreen; gamepad");fr.setAttribute("title","Game Boy Color");
fr.onload=()=>{if(fr!==gbFr)return;
try{const blob=r.data instanceof Blob?r.data:new Blob([r.data]),id=gbId(r.name);
gbSavGet(id).then(sram=>{if(fr!==gbFr)return;try{fr.contentWindow.postMessage({t:"init",blob,id,sram,name:r.name},"*")}catch(e){gbFail("Não consegui iniciar o Game Boy Color.")}})}
catch(e){gbFail("Não consegui iniciar o Game Boy Color.")}};
fr.srcdoc=SNRE.test(r.name)?SNES_DOC:/\.gba$/i.test(r.name)?GBA_DOC:GB_DOC;$("gb").classList.toggle("gba",/\.gba$/i.test(r.name));$("gb").classList.toggle("snes",SNRE.test(r.name));gbFr=fr;$("gb").insertBefore(fr,$("gb").firstChild);
clearTimeout(gbT);
gbT=setTimeout(()=>{if(gbOn&&gbFr===fr&&!$("gbmsg").hidden)gbFail("Demorou demais para iniciar o jogo. Toque em 'Tentar de novo'.")},90000)}
function gbFail(m:string):void{clearTimeout(gbT);$("gbmsg").hidden=false;$("gbspin").hidden=true;$("gbmt").textContent=m;$("gbmb").hidden=false}
function gbTeardown(){gbHold=0;clearTimeout(gbT);gbHeld.clear();gbFF=0;const fr=gbFr;gbFr=null;gbOn=0;if(fr){try{fr.contentWindow.postMessage({t:"stop"},"*")}catch(e){}setTimeout(()=>{try{fr.remove()}catch(e){}},400)}gbRelease()}
function gbExit(){if(!gbOn)return;const fr=gbFr;gbHold=0;gbRel();gbMenu(0);
try{fr.contentWindow.postMessage({t:"stop"},"*")}catch(e){}
gbOn=0;gbFr=null;clearTimeout(gbT);$("gb").hidden=true;gbRelease();
if(gbHist){gbHist=0;try{history.back()}catch(e){}}
// o iframe fica mais um instante para o jogo gravar o progresso e só então é removido
setTimeout(()=>{try{fr.remove()}catch(e){}},900);
try{window.__toGames&&window.__toGames()}catch(e){}}
$("gbx").onclick=()=>ask(GB_EXIT,()=>gbExit(),undefined);
/* ---- controles na tela ---- */
const gbHeld=new Set<number>();let gbFF=0;
function gbG(k:string,d:string):string{try{return localStorage.getItem(k)||d}catch(e){return d}}
function gbMsg(m:Record<string, unknown>):void{try{gbFr&&gbFr.contentWindow.postMessage(m,"*")}catch(e){}}
function gbKey(k:number,v:number|boolean):void{v=!!v;if(v===gbHeld.has(k))return;v?gbHeld.add(k):gbHeld.delete(k);gbMsg({t:"btn",k,v:v?1:0})}
function gbRel(){[...gbHeld].forEach(k=>gbKey(k,0));if(gbFF)gbSetFF(0)}
function gbSetFF(v:number):void{gbFF=v;gbMsg({t:"ff",v});$("gbff").classList.toggle("on",!!v)}
function gbFit(){$("gb").classList.toggle("nob",gbG("gbbtn","1")==="0")}
function gbLabels(){$("gbm_m").textContent="⚙ MODO GBA: "+["AUTOMÁTICO","RÁPIDO","PRECISO"][+gbG("gbmode","0")%3];$("gbm_f").textContent="⏩ AVANÇO RÁPIDO: "+(gbFF?"LIGADO":"DESLIGADO")}
function gbMenu(o:number|boolean):void{const m=$("gbmenu");if(!!o===!m.hidden)return;m.hidden=!o;if(o){[...gbHeld].forEach(k=>gbKey(k,0));gbLabels()}gbMsg({t:"pause",v:o?1:0})}
document.querySelectorAll<HTMLElement>("#gbctl .dk[data-k]").forEach(el=>{const k=+el.dataset.k;
el.addEventListener("pointerdown",e=>{e.preventDefault();try{el.setPointerCapture(e.pointerId)}catch(x){}el.classList.add("p");gbKey(k,1)});
const u=()=>{el.classList.remove("p");gbKey(k,0)};el.addEventListener("pointerup",u);el.addEventListener("pointercancel",u)});
(function(){const pad=$("gbpad");let on=0;
function mv(e:PointerEvent):void{const r=pad.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5,ax=Math.abs(x),ay=Math.abs(y),dx=ay>ax*1.8?0:x,dy=ax>ay*1.8?0:y;gbKey(6,dx<-.12);gbKey(7,dx>.12);gbKey(4,dy<-.12);gbKey(5,dy>.12)}
const up=()=>{on=0;[4,5,6,7].forEach(k=>gbKey(k,0))};
pad.addEventListener("pointerdown",e=>{e.preventDefault();on=1;try{pad.setPointerCapture(e.pointerId)}catch(x){}mv(e)});
pad.addEventListener("pointermove",e=>{if(on)mv(e)});pad.addEventListener("pointerup",up);pad.addEventListener("pointercancel",up)})();
$("gbff").onclick=()=>gbSetFF(gbFF?0:1);
$("gbup").onclick=()=>gbMenu(1);
$("gbmenu").onclick=e=>{const target=e.target instanceof HTMLElement?e.target:null;const a=target?.dataset?.a;if(!a){if(target?.id==="gbmenu")gbMenu(0);return}
if(a==="f")gbSetFF(gbFF?0:1);
else if(a==="m"){const n=(+gbG("gbmode","0")+1)%3;try{localStorage.setItem("gbmode",String(n))}catch(e){}gbMsg({t:"cfg",mode:n})}
else if(a==="s"){gbMsg({t:"save"});toast("Jogo salvo")}
else if(a==="x"){gbMenu(0);ask(GB_EXIT,()=>gbExit(),undefined);return}
else{gbMenu(0);return}
gbLabels()};
$("gbretry").onclick=()=>{const r=gbCur;gbTeardown();if(r)gbOpen(r)};
$("gbback").onclick=()=>gbExit();
addEventListener("message",e=>{if(!gbFr||e.source!==gbFr.contentWindow)return;const d=e.data||{};
if(d.t==="ready"||d.t==="start"){gbMsg({t:"cfg",mode:+gbG("gbmode","0")});clearTimeout(gbT);$("gbmsg").hidden=true;$("gb").classList.add("live")}
else if(d.t==="fail")gbFail(d.m||"Não consegui iniciar esse jogo.")});
// saves do jogo (RAM da bateria) vão para o banco do app, mesmo se o iframe já foi fechado
addEventListener("message",e=>{const d=e.data;if(d&&d.k==="gbc-sram"&&d.id&&d.rec)gbSavPut(d.id,d.rec)});
addEventListener("popstate",()=>{if(!gbHist)return;gbHist=0;if(!gbOn)return;
ask(GB_EXIT,()=>gbExit(),()=>{try{history.pushState({gb:1},"");gbHist=1}catch(e){}})});
document.addEventListener("visibilitychange",()=>{if(!gbOn||!gbFr)return;
if(document.hidden){try{gbFr.contentWindow.postMessage({t:"save"},"*")}catch(e){}}else gbWake()});

let currentKey = "";
function startRom(b:Uint8Array,name:string):void{
if(gbFr)gbTeardown();
if(run&&currentKey)saveSram();run=0;rom=new Uint8Array(Math.max(b.length,0x200000));rom.set(b);RL=rom.length;
for(const a of[ram,zr,vram,cram,vs,rg])a.fill(0);
sram.fill(255);usp=sramOn=ilc=sdirty=sf=0;bk=[0,1,2,3,4,5,6,7];
pend=cd=va=fill=vf=ip6=ip4=line=hc=stopped=dmaBusy=0;th=0x40;R.fill(0);pdirty=1;R[15]=r32(0);pc=r32(4)&0xFFFFFF;sr=0x2700;
const nm=String.fromCharCode(...rom.subarray(0x120,0x150)).replace(/\s+/g," ").trim();
currentKey = (name+"_"+b.length).replace(/[^a-zA-Z0-9]/g,"_").slice(0,60);
try{const sv=localStorage.getItem("mdsram_"+currentKey);if(sv)sram.set(base64ToUint8(sv).subarray(0,32768))}catch(e){}
$("st").textContent="ROM: "+(nm||name)+" ("+(b.length>>10)+" KB). Use ☰ Menu inicial para trocar de jogo.";
zinit();psgInit();errs=0;run=1;startLoop()
}
// Estados completos da sessão: CPU, VDP, Z80 e chips de áudio.
const stateArrays:Record<string,Uint8Array|Uint16Array|Int32Array>={ram,zr,sram,vram,cram,vs,rg,R,Z,Z2};
function captureState():SystemMegaDriveSnapshot{
const a:Record<string,Uint8Array|Uint16Array|Int32Array>={};for(const k in stateArrays)a[k]=stateArrays[k].slice() as Uint8Array|Uint16Array|Int32Array;
const values={
RL,pend,cd,va,fill,vf,ip6,ip4,pad,th,line,hc,stopped,dmaBusy,pc,sr,EA,EM,ER,usp,sramOn,ilc,sdirty,sf,pdirty,xc,bk:bk.slice(),
Z80:{zF,zF2,zpc,zsp,zix,ziy,zx,zi,zrr,ziff1,ziff2,zim,zhalt,zint,zcyc,zbud,zbus,zrs,zbank,zbn,ZA2},
YM:{registers:Array.from(YR),state:{...YM},channels:YCH.map(c=>({...c,op:c.op.map((o:YMOperatorState)=>({...o}))}))},
PSG:{...psg,t:psg.t.slice(),v:psg.v.slice(),c:psg.c.slice(),o:psg.o.slice()}
};
return{key:currentKey,romName:roms[curRom]?.name||"",arrays:a,values,savedAt:Date.now(),stateVersion:2}
}
function applyState(s:SystemMegaDriveSnapshot,expectedKey:string):void{
if(!s||!s.arrays||!s.values||s.key!==expectedKey)throw new Error("O estado não corresponde à ROM/slot selecionado.");
for(const k in stateArrays){const src=s.arrays[k];if(src){if(src.length!==stateArrays[k].length)throw new Error("Estado incompatível: "+k)}else if(k!=="Z"&&k!=="Z2")throw new Error("O estado está incompleto: "+k)}
run=0;lid++;
for(const k in stateArrays)if(s.arrays[k])stateArrays[k].set(s.arrays[k]);
const v=s.values;
({RL,pend,cd,va,fill,vf,ip6,ip4,pad,th,line,hc,stopped,dmaBusy,pc,sr,EA,EM,ER,usp,sramOn,ilc,sdirty,sf,pdirty,xc}=v);
bk=v.bk?v.bk.slice():[0,1,2,3,4,5,6,7];
if(v.Z80){({zF,zF2,zpc,zsp,zix,ziy,zx,zi,zrr,ziff1,ziff2,zim,zhalt,zint,zcyc,zbud,zbus,zrs,zbank,zbn,ZA2}=v.Z80)}
else if(v.zs){const q=v.zs;Z.set(q.Z||[]);Z2.set(q.Z2||[]);[zF,zF2,zpc,zsp,zix,ziy,zi,zrr,ziff1,ziff2,zim,zhalt,zbus,zrs,zbank,zbn,ZA2]=q.v;zint=zcyc=zbud=zx=0}
if(v.YM){YR.set(v.YM.registers);Object.assign(YM,v.YM.state);YCH.length=0;for(const c of v.YM.channels as YMChannelState[])YCH.push({...c,op:c.op.map((o:YMOperatorState)=>({...o}))})}
else if(v.zs&&v.zs.ym){ymInit();for(let pt=0;pt<2;pt++)for(let r=0x30;r<0xC0;r++){ymw(pt*2,r);ymw(pt*2+1,v.zs.ym[pt*256+r])}ymw(0,0x24);ymw(1,v.zs.ym[0x24]);ymw(0,0x26);ymw(1,v.zs.ym[0x26]);ymw(0,0x2B);ymw(1,v.zs.ym[0x2B])}
if(v.PSG){Object.assign(psg,{...v.PSG,t:v.PSG.t.slice(),v:v.PSG.v.slice(),c:v.PSG.c.slice(),o:v.PSG.o.slice()})}
pad=0;try{window.__resetInput?.()}catch(e){}
AU.w=AU.r=0;AU.pre=1;AU.q=0;AU.l2=0;AU.last=0;AU.readFrac=0;audioFrame();
acc=0;errs=0;saveSram();run=1;startLoop();$("st").textContent="Partida carregada: "+(s.romName||"ROM")+" · Slot "+slot;
}
function saveState(){
if(!currentKey||curRom==null){$("st").textContent="Abra um jogo antes de salvar.";return}
const selectedSlot=slot,dbKey=currentKey+"#"+selectedSlot,state=captureState();state.key=dbKey;
dbp.then(d=>{
if(!d||!d.objectStoreNames.contains("states")){$("st").textContent="Armazenamento de slots indisponível. Abra o emulador no Chrome e tente novamente.";return}
try{const tx=d.transaction("states","readwrite");tx.objectStore("states").put(state);
tx.oncomplete=()=>{$("st").textContent="Partida salva corretamente no Slot "+selectedSlot+"."};
tx.onerror=()=>{$("st").textContent="Não foi possível salvar no Slot "+selectedSlot+"."};
tx.onabort=()=>{$("st").textContent="Salvamento cancelado. Verifique o espaço disponível."}
}catch(e){$("st").textContent="Falha ao salvar: "+(e instanceof Error ? e.message : String(e))}
})
}
function loadState(){
if(!currentKey||curRom==null){$("st").textContent="Abra primeiro a mesma ROM usada no salvamento.";return}
const selectedSlot=slot,dbKey=currentKey+"#"+selectedSlot;
dbp.then(d=>{
if(!d||!d.objectStoreNames.contains("states")){$("st").textContent="Banco de slots indisponível neste navegador.";return}
try{
const tx=d.transaction("states","readonly"),store=tx.objectStore("states"),q=store.get(dbKey);
q.onsuccess=()=>{
const useState=(record:SystemMegaDriveSnapshot|null|undefined,key:string):void=>{if(!record){$("st").textContent="O Slot "+selectedSlot+" está vazio. Salve uma partida nele primeiro.";return}
try{applyState(record,key);if(selectedSlot===1&&key===currentKey)$("st").textContent="Partida antiga do Slot 1 carregada."}
catch(e){$("st").textContent="Não foi possível carregar o Slot "+selectedSlot+": "+(e instanceof Error ? e.message : String(e))}}
if(q.result)useState(q.result as SystemMegaDriveSnapshot,dbKey);
else if(selectedSlot===1){const old=store.get(currentKey);old.onsuccess=()=>useState(old.result as SystemMegaDriveSnapshot|undefined,currentKey);old.onerror=()=>{$("st").textContent="Erro ao localizar o salvamento antigo."}}
else $("st").textContent="O Slot "+selectedSlot+" está vazio. Salve uma partida nele primeiro."
};
q.onerror=()=>{$("st").textContent="Erro ao carregar a partida."};
}catch(e){$("st").textContent="Erro ao carregar: "+(e instanceof Error ? e.message : String(e))}
})
}
let slot=1;try{slot=Math.min(5,Math.max(1,+localStorage.getItem("mdslot")||1))}catch(e){}
($("slotsel") as HTMLSelectElement).value=String(slot);
$("slotsel").onchange=e=>{const target=e.currentTarget as HTMLSelectElement;slot=Math.min(5,Math.max(1,+target.value||1));try{localStorage.setItem("mdslot",String(slot))}catch(e2){}};
$("savestate").onclick=saveState;$("loadstate").onclick=loadState;
async function importFiles(fileList: FileList | File[],fromFolder=false){
const files=Array.from(fileList||[]),S=SYSS[system];
let added=0,ignored=0,warn=0,nosave=0;
for(const fl of files){
if(!S.re.test(fl.name)){ignored++;continue}
const rel=fl.webkitRelativePath||"";
const name=fromFolder&&rel?(rel.split("/").slice(1).join("/")||fl.name):fl.name;
if(S===MD){
let b=new Uint8Array(await fl.arrayBuffer());
if(!b.length){ignored++;continue}
if(b.length%16384==512&&b[8]==0xAA&&b[9]==0xBB){b=b.subarray(512);const o=new Uint8Array(b.length);
for(let k=0;k<b.length;k+=16384)for(let i=0;i<8192;i++){o[k+i*2+1]=b[k+i];o[k+i*2]=b[k+8192+i]}b=o}
else if(b.length%1024==512)b=b.subarray(512);
const r={name,data:b.slice()},k=roms.findIndex(x=>x.name===r.name);
if(k>=0)roms[k]=r;else roms.push(r);
dbPut(r);added++;
}else{
const c=await addGB(fl,name);
if(!c)ignored++;else{added++;if(c===2)warn++;if(c<0)nosave++}
}}
if(added)setTab(0);else fillRl();
const pl=(n:number,a:string,b:string)=>n+" "+(n>1?b:a),bits=[];
if(added)bits.push(pl(added,"jogo adicionado","jogos adicionados"));
if(ignored)bits.push(pl(ignored,"arquivo ignorado","arquivos ignorados"));
if(warn)bits.push(pl(warn,"sem cabeçalho de Game Boy válido (pode não abrir)","sem cabeçalho de Game Boy válido (podem não abrir)"));
if(nosave)bits.push("não deu para guardar no navegador (some ao fechar)");
if(!added)bits.push(S.id==="gb"?"Formatos aceitos: .gb, .gbc, .gba, .sfc, .smc e .zip":"Formatos aceitos: .bin, .md, .gen, .smd, .sgd e .rom");
toast(bits.join(" · "),4800)}
$("f").onchange=async e=>{const target=e.currentTarget as HTMLInputElement;await importFiles(target.files||[],false);target.value=""};
$("folderf").onchange=async e=>{const target=e.currentTarget as HTMLInputElement;await importFiles(target.files||[],false);target.value=""};
$("folderf").parentNode.addEventListener("click",async e=>{if(!window.showDirectoryPicker)return;e.preventDefault();try{const out:File[]=[];const w=async(h:FileSystemDirectoryHandleLike):Promise<void>=>{for await(const [n,x] of h.entries()){if(x.kind==="file")out.push(await x.getFile());else await w(x)}};await w(await window.showDirectoryPicker());await importFiles(out,false)}catch(x){if(!(x instanceof DOMException && x.name==="AbortError"))toast("Não consegui ler a pasta. Selecione os arquivos.")}});

function uint8ToBase64(u8:Uint8Array):string{
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < u8.length; i += chunk) {
    binary += String.fromCharCode.apply(null, Array.from(u8.subarray(i, Math.min(i + chunk, u8.length))));
  }
  return btoa(binary);
}
function base64ToUint8(b64:string):Uint8Array{
  const binary = atob(b64);
  const u8 = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) u8[i] = binary.charCodeAt(i);
  return u8;
}
let resetArmed=0;
function resetGame(){
if(!currentKey||!rom){$("st").textContent="Carregue uma ROM primeiro.";return}
if(!resetArmed){resetArmed=1;$("rstbtn").textContent="Confirmar?";setTimeout(()=>{resetArmed=0;$("rstbtn").textContent="Resetar"},3000);return}resetArmed=0;$("rstbtn").textContent="Resetar";
saveSram();for(const a of[ram,zr,vram,cram,vs,rg])a.fill(0);
usp=sramOn=ilc=sf=0;zinit();psgInit();bk=[0,1,2,3,4,5,6,7];
pend=cd=va=fill=vf=ip6=ip4=line=hc=stopped=dmaBusy=0;th=0x40;R.fill(0);pdirty=1;R[15]=r32(0);pc=r32(4)&0xFFFFFF;sr=0x2700;acc=0;
document.body.classList.remove("menu");
$("st").textContent="Jogo reiniciado. Seu progresso salvo foi mantido."}
addEventListener("pagehide",()=>{if(currentKey)saveSram()});
document.addEventListener("visibilitychange",()=>{if(document.hidden&&currentKey)saveSram()});
$("rstbtn").onclick=resetGame;

