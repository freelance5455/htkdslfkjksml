// System Fox — Game Boy Advance e sessão portátil (TypeScript)

/* ---- GBA: núcleo próprio (roda num iframe separado, como o GBC) ---- */
function gbaChild(){
function P(m:Record<string, unknown>):void{try{parent.postMessage(m,"*")}catch(e){}}
var cv=document.getElementById("c") as HTMLCanvasElement,vx=cv.getContext("2d"),oc=document.createElement("canvas");oc.width=240;oc.height=160;
var ox=oc.getContext("2d"),img=ox.createImageData(240,160),fb=new Uint32Array(img.data.buffer);
var gid=0,run=0,paused=0,stopped=0,ffm=1,lastT=0,vw=240,vh=160,acc=0,started=0,fr=0,frames=0,kp=0,kcnt=0,ly=0,dirty=0,lastErr="",gtitle="",gcode="";
function mk(n:number):GbaMemoryRegion{var b=new ArrayBuffer(n);return{u8:new Uint8Array(b),u16:new Uint16Array(b),i32:new Int32Array(b),m:n-1}}
var BIOS=mk(0x4000),EW=mk(0x40000),IW=mk(0x8000),PAL=mk(0x400),VR=mk(0x20000),OAM=mk(0x400),io=new Uint16Array(0x200),
ROM:Uint8Array|null=null,rom8:Uint8Array=new Uint8Array(0),rom16:Uint16Array=new Uint16Array(0),rom32:Int32Array=new Int32Array(0),romN=0,
ie=new Int32Array(10),ifl=new Int32Array(10),ime=new Int32Array(10),
tc=[0,0,0,0],trl=[0,0,0,0],tl=[0,0,0,0],tacc=[0,0,0,0],dsa=[0,0,0,0],dda=[0,0,0,0],dn=[0,0,0,0],rx=[0,0],ry=[0,0],ipl=470,cpu:GbaArmCpu|null=null,wcnt=0,openBus=0;
function bR(b:GbaMemoryRegion,a:number,sz:number):number{return sz===32?b.i32[(a&b.m)>>2]:sz===16?b.u16[(a&b.m)>>1]:b.u8[a&b.m]}
function bW(b:GbaMemoryRegion,a:number,v:number,sz:number):void{if(sz===32)b.i32[(a&b.m)>>2]=v;else if(sz===16)b.u16[(a&b.m)>>1]=v;else b.u8[a&b.m]=v}
function vro(a:number){var o=a&0x1FFFF;return o>=0x18000?o-0x8000:o}
function romRd(a:number, sz:number){var o=a&0x1FFFFFF;
if(o+(sz>>3)<=romN)return sz===32?rom32[o>>2]:sz===16?rom16[o>>1]:rom8[o];
if(o>=romN){var q=o>>1;return sz===32?((q&0xFFFF)|(((q+1)&0xFFFF)<<16)):sz===16?(q&0xFFFF):(q>>((o&1)*8)&255)}
return sz===32?(rom8[o]|rom8[o+1]<<8|rom8[o+2]<<16|rom8[o+3]<<24):sz===16?(rom8[o]|rom8[o+1]<<8):rom8[o]}
function rd(c:number, a:number, sz:number){var r=a>>>24;
switch(r){
case 0:if(a<0x4000){if(cpu&&cpu.R[15]>>>0>=0x4000){var ob=0xE129F000|0;return sz===32?ob:sz===16?(ob>>>((a&2)*8))&0xFFFF:(ob>>>((a&3)*8))&255}return bR(BIOS,a,sz)}return 0;
case 2:return bR(EW,a,sz);
case 3:return bR(IW,a,sz);
case 4:return ior(a&0x3FF,sz);
case 5:return bR(PAL,a,sz);
case 6:return bR(VR,vro(a),sz);
case 7:return bR(OAM,a,sz);
case 13:if(eepOn&&(romN<=0x1000000||(a&0x1FFFF00)===0x1FFFF00))return eepNext();return romRd(a,sz);
case 8:case 9:case 10:case 11:case 12:return romRd(a,sz);
case 14:case 15:return savRd(a)}
if(r>=0x10&&cpu){var pc=cpu.R[15]>>>0,w=(pc>>>24>=8&&pc>>>24<=13)?romRd(pc&~3,32):0;return sz===32?w:sz===16?(w>>>((a&2)*8))&0xFFFF:(w>>>((a&3)*8))&255}return 0}
function wr(c:number, a:number, v:number, sz:number){var r=a>>>24,o;
switch(r){
case 2:bW(EW,a,v,sz);return;
case 3:bW(IW,a,v,sz);return;
case 4:iow(a&0x3FF,v,sz);return;
case 5:if(sz===8){PAL.u16[(a&0x3FE)>>1]=(v&255)*0x101}else bW(PAL,a,v,sz);return;
case 6:o=vro(a);if(sz===8){if(o<((io[0]&7)>=3?0x14000:0x10000))VR.u16[o>>1]=(v&255)*0x101}else bW(VR,o,v,sz);return;
case 7:if(sz!==8)bW(OAM,a,v,sz);return;
case 14:case 15:savWr(a,v&255);return}}

/* ---------- CPU ARM (ARM9 = ARMv5TE, ARM7 = ARMv4T) ---------- */
function mkCpu(id:number){
var A9=id===9,R=new Int32Array(16),N=0,Z=0,C=0,V=0,Q=0,I=1,F=1,T=0,md=31,cc=0,halted=0,waiting=0,waitPC=0,burnN=0,trf:((registers:Int32Array)=>void)|null=null,
b13=new Int32Array(32),b14=new Int32Array(32),spsr=new Int32Array(32),fq=new Int32Array(5),us=new Int32Array(5),
IV=A9?(0xFFFF0018|0):0x18,RV=A9?(0xFFFF0200|0):0x200,o:GbaArmCpu={} as GbaArmCpu;
function bi(m:number){return m===16?31:m}
function setMode(nm:number){var ob=bi(md),nb=bi(nm),i;if(ob!==nb){b13[ob]=R[13];b14[ob]=R[14];
if(ob===17)for(i=0;i<5;i++){fq[i]=R[8+i];R[8+i]=us[i]}
if(nb===17)for(i=0;i<5;i++){us[i]=R[8+i];R[8+i]=fq[i]}
R[13]=b13[nb];R[14]=b14[nb]}md=nm}
function cpsr(){return N<<31|Z<<30|C<<29|V<<28|Q<<27|I<<7|F<<6|T<<5|md}
function setC(v:number){N=v>>>31;Z=v>>>30&1;C=v>>>29&1;V=v>>>28&1;Q=v>>>27&1;if(md!==16){I=v>>>7&1;F=v>>>6&1;T=v>>>5&1;setMode(v&31)}}
function ck(c:number){switch(c){case 0:return Z;case 1:return !Z;case 2:return C;case 3:return !C;case 4:return N;case 5:return !N;case 6:return V;case 7:return !V;
case 8:return C&&!Z;case 9:return !C||Z;case 10:return N===V;case 11:return N!==V;case 12:return !Z&&N===V;case 13:return Z||N!==V}return 1}
function nz(r:number){N=r>>>31;Z=r===0?1:0;return r}
function add(a:number, b:number, ci:number, s:number|boolean){var t=(a>>>0)+(b>>>0)+ci,r=t|0;if(s){N=r>>>31;Z=r===0?1:0;C=t>4294967295?1:0;V=(~(a^b)&(a^r))>>>31}return r}
function sub(a:number, b:number, ci:number, s:number|boolean){var t=(a>>>0)+((~b)>>>0)+ci,r=t|0;if(s){N=r>>>31;Z=r===0?1:0;C=t>4294967295?1:0;V=((a^b)&(a^r))>>>31}return r}
function shf(t:number, v:number, a:number, imm:number){switch(t){
case 0:if(a===0){cc=C;return v}if(a<32){cc=v>>>(32-a)&1;return v<<a}if(a===32){cc=v&1;return 0}cc=0;return 0;
case 1:if(imm&&a===0)a=32;if(a===0){cc=C;return v}if(a<32){cc=v>>>(a-1)&1;return v>>>a}if(a===32){cc=v>>>31;return 0}cc=0;return 0;
case 2:if(imm&&a===0)a=32;if(a===0){cc=C;return v}if(a<32){cc=v>>(a-1)&1;return v>>a}cc=v>>>31;return v>>31;
default:if(imm&&a===0){cc=v&1;return(C<<31)|(v>>>1)}if(a===0){cc=C;return v}a&=31;if(a===0){cc=v>>>31;return v}cc=v>>>(a-1)&1;return v>>>a|v<<(32-a)}}
function g15(n:number){return n===15?R[15]+4:R[n]}
function bx(t:number){if(t&1){T=1;R[15]=t&~1}else{T=0;R[15]=t&~3}}
function ldw(a:number){var v=rd(id,a,32),s=(a&3)*8;return s?(v>>>s|v<<(32-s)):v}
function wrPc(v:number){if(A9)bx(v);else R[15]=v&(T?~1:~3)}
function msr(ins:number, v:number){var m=ins>>>16&15,i;if(ins&0x400000){i=bi(md);var s=spsr[i];if(m&8)s=s&0x0FFFFFFF|v&0xF0000000;if(m&1)s=s&~0xFF|v&0xFF;spsr[i]=s}
else{if(m&8){N=v>>>31;Z=v>>>30&1;C=v>>>29&1;V=v>>>28&1;Q=v>>>27&1}if((m&1)&&md!==16){I=v>>>7&1;F=v>>>6&1;setMode(v&31)}}}
function sat(x:number){if(x>2147483647){Q=1;return 2147483647}if(x<-2147483648){Q=1;return -2147483648}return x}
function dp(ins:number){var opc=ins>>>21&15,s=ins>>>20&1,rn=ins>>>16&15,rdn=ins>>>12&15,a,b,r=0,w=1;
if(ins&0x2000000){var rot=(ins>>>8&15)*2;b=ins&255;a=g15(rn);if(rot){b=(b>>>rot)|(b<<(32-rot));cc=b>>>31}else cc=C}
else{var rm=ins&15,t=ins>>>5&3;if(ins&16){var am=R[ins>>>8&15]&255;b=rm===15?R[15]+8:R[rm];a=rn===15?R[15]+8:R[rn];b=shf(t,b,am,0)}else{b=shf(t,g15(rm),ins>>>7&31,1);a=g15(rn)}}
var sf=s&&rdn!==15;
switch(opc){
case 0:r=a&b;if(sf){nz(r);C=cc}break;case 1:r=a^b;if(sf){nz(r);C=cc}break;
case 2:r=sub(a,b,1,sf);break;case 3:r=sub(b,a,1,sf);break;case 4:r=add(a,b,0,sf);break;case 5:r=add(a,b,C,sf);break;
case 6:r=sub(a,b,C,sf);break;case 7:r=sub(b,a,C,sf);break;
case 8:nz(a&b);C=cc;w=0;break;case 9:nz(a^b);C=cc;w=0;break;case 10:sub(a,b,1,1);w=0;break;case 11:add(a,b,0,1);w=0;break;
case 12:r=a|b;if(sf){nz(r);C=cc}break;case 13:r=b;if(sf){nz(r);C=cc}break;case 14:r=a&~b;if(sf){nz(r);C=cc}break;default:r=~b;if(sf){nz(r);C=cc}}
if(w){if(rdn===15){if(s){var sp2=spsr[bi(md)];setC(sp2);R[15]=r&(T?~1:~3)}else R[15]=r&~3}else R[rdn]=r}}
function ldst(ins:number){var P2=ins>>>24&1,U=ins>>>23&1,B=ins>>>22&1,W=ins>>>21&1,L=ins>>>20&1,rn=ins>>>16&15,rdn=ins>>>12&15,off,base=g15(rn),a,v,nb;
if(ins&0x2000000){if(ins&16){window.__und=(window.__und|0)+1;window.__undI=ins;return}off=shf(ins>>>5&3,g15(ins&15),ins>>>7&31,1)}else off=ins&4095;
nb=(U?base+off:base-off)|0;a=P2?nb:base;
if(L){if(!P2||W)R[rn]=nb;v=B?rd(id,a,8):ldw(a);if(rdn===15){if(!B)wrPc(v)}else R[rdn]=v}
else{v=rdn===15?R[15]+8:R[rdn];if(B)wr(id,a,v&255,8);else wr(id,a,v,32);if(!P2||W)R[rn]=nb}}
function half(ins:number){var P2=ins>>>24&1,U=ins>>>23&1,Im=ins>>>22&1,W=ins>>>21&1,L=ins>>>20&1,rn=ins>>>16&15,rdn=ins>>>12&15,sh=ins>>>5&3,base=g15(rn),off=Im?((ins>>>4&0xF0)|(ins&15)):R[ins&15],nb=(U?base+off:base-off)|0,a=P2?nb:base,v;
if(L){if(!P2||W)R[rn]=nb;if(sh===1)v=rd(id,a,16);else if(sh===2)v=rd(id,a,8)<<24>>24;else v=rd(id,a,16)<<16>>16;if(rdn===15)return;R[rdn]=v}
else if(sh===1){wr(id,a,R[rdn]&65535,16);if(!P2||W)R[rn]=nb}
else if(A9&&sh===2){R[rdn]=rd(id,a,32);R[rdn+1]=rd(id,a+4,32);if(!P2||W)R[rn]=nb}
else if(A9&&sh===3){wr(id,a,R[rdn],32);wr(id,a+4,R[rdn+1],32);if(!P2||W)R[rn]=nb}}
function pc16(n:number){n=n-((n>>1)&0x5555);n=(n&0x3333)+((n>>2)&0x3333);n=(n+(n>>4))&0x0F0F;return(n+(n>>8))&31}
function ldm(ins:number){var P2=ins>>>24&1,U=ins>>>23&1,S=ins>>>22&1,W=ins>>>21&1,L=ins>>>20&1,rn=ins>>>16&15,rl=ins&0xFFFF,base=R[rn],n=pc16(rl),a,i,v,nb,sm=md,ub=0;
if(rl===0){rl=0x8000;n=16}
nb=U?base+4*n:base-4*n;a=U?(P2?base+4:base):(P2?base-4*n:base-4*n+4);a&=~3;
if(S&&!(L&&(rl&0x8000))){ub=1;setMode(16)}
for(i=0;i<16;i++)if(rl>>i&1){if(L){v=rd(id,a,32);if(i===15){if(S){setC(spsr[bi(sm)]);R[15]=v&(T?~1:~3)}else wrPc(v)}else R[i]=v}else wr(id,a,i===15?R[15]+8:R[i],32);a+=4}
if(ub)setMode(sm);
if(W&&!(L&&(rl>>rn&1)))R[rn]=nb}
function ar(ins:number, cond:number){var op=ins>>>25&7,rdn,rn,rm,rs,r,x;
switch(op){
case 0:
if((ins&0x90)===0x90){
if((ins&0x60)===0){x=ins>>>23&31;
if(x===0){rdn=ins>>>16&15;rn=ins>>>12&15;rs=ins>>>8&15;rm=ins&15;r=Math.imul(R[rm],R[rs]);if(ins&0x200000)r=r+R[rn]|0;R[rdn]=r;if(ins&0x100000)nz(r)}
else if(x===1){var hi=ins>>>16&15,lo=ins>>>12&15,sg=ins&0x400000;rs=ins>>>8&15;rm=ins&15;
var p=sg?BigInt(R[rm])*BigInt(R[rs]):BigInt(R[rm]>>>0)*BigInt(R[rs]>>>0);
if(ins&0x200000)p+=(sg?BigInt.asIntN(64,(BigInt(R[hi]>>>0)<<32n)|BigInt(R[lo]>>>0)):((BigInt(R[hi]>>>0)<<32n)|BigInt(R[lo]>>>0)));
R[lo]=Number(BigInt.asUintN(32,p))|0;R[hi]=Number(BigInt.asUintN(32,p>>32n))|0;if(ins&0x100000){N=R[hi]>>>31;Z=(R[lo]|R[hi])===0?1:0}}
else if(x===2){rn=ins>>>16&15;rdn=ins>>>12&15;rm=ins&15;var ad=R[rn];if(ins&0x400000){var t8=rd(id,ad,8);wr(id,ad,R[rm]&255,8);R[rdn]=t8}else{var t32=ldw(ad);wr(id,ad,R[rm],32);R[rdn]=t32}}}
else half(ins);return}
if((ins&0x01900000)===0x01000000){x=ins&0x0FFFFFF0;
if((ins&0x0FBF0FFF)===0x010F0000){R[ins>>>12&15]=ins&0x400000?spsr[bi(md)]:cpsr()}
else if((ins&0x0FB0FFF0)===0x0120F000)msr(ins,R[ins&15]);
else if(x===0x012FFF10)bx(R[ins&15]);
else if(A9&&x===0x012FFF30){var tg=R[ins&15];R[14]=R[15];bx(tg)}
else if(A9&&(ins&0x0FFF0FF0)===0x016F0F10)R[ins>>>12&15]=Math.clz32(R[ins&15]);
else if(A9&&(ins&0x0F900FF0)===0x01000050){var qa=R[ins&15],qb=R[ins>>>16&15],k=ins>>>21&3;
if(k&2)qb=sat(qb*2);R[ins>>>12&15]=k&1?sat(qa-qb):sat(qa+qb)}
else if(A9&&(ins&0x0F900090)===0x01000080){var k2=ins>>>21&3,xh=ins>>>5&1,yh=ins>>>6&1,d2=ins>>>16&15,n2=ins>>>12&15,s2=ins>>>8&15,m2=ins&15,hv=function(v:number,h:number){return h?v>>16:v<<16>>16},pr2;
if(k2===0){pr2=hv(R[m2],xh)*hv(R[s2],yh);var sr=pr2+R[n2];if(sr>2147483647||sr<-2147483648)Q=1;R[d2]=sr|0}
else if(k2===1){pr2=Math.floor(R[m2]*hv(R[s2],yh)/65536);if(xh)R[d2]=pr2|0;else{var sw2=pr2+R[n2];if(sw2>2147483647||sw2<-2147483648)Q=1;R[d2]=sw2|0}}
else if(k2===2){var p3=BigInt(hv(R[m2],xh)*hv(R[s2],yh))+BigInt.asIntN(64,(BigInt(R[d2]>>>0)<<32n)|BigInt(R[n2]>>>0));R[n2]=Number(BigInt.asUintN(32,p3))|0;R[d2]=Number(BigInt.asUintN(32,p3>>32n))|0}
else R[d2]=hv(R[m2],xh)*hv(R[s2],yh)}}
else dp(ins);return;
case 1:if((ins&0x01900000)===0x01000000){if((ins&0x0FB0F000)===0x0320F000){var rt=(ins>>>8&15)*2,iv=ins&255;if(rt)iv=(iv>>>rt)|(iv<<(32-rt));msr(ins,iv)}}else dp(ins);return;
case 2:case 3:ldst(ins);return;
case 4:ldm(ins);return;
case 5:{var off=ins<<8>>6;
if(cond===15){R[14]=R[15];R[15]=(R[15]+4+off+((ins>>>24&1)<<1))&~1;T=1}
else{if(ins&0x1000000)R[14]=R[15];R[15]=R[15]+4+off}return}
case 6:window.__und=(window.__und|0)+1;window.__undI=ins;return;
case 7:if(ins&0x1000000){bios(ins>>>16&255)}return}}
function flagPtr(){return 0x03007FF8}
function div(a:number, b:number){if(b===0){R[0]=a<0?-1:1;R[1]=a;R[3]=1;return}var q=Math.trunc(a/b)|0,r=(a%b)|0;R[0]=q;R[1]=r;R[3]=Math.abs(q)|0}
function r8(a:number){return rd(id,a,8)}function r16(a:number){return rd(id,a,16)}function r32(a:number){return rd(id,a,32)}
function w8(a:number, v:number){wr(id,a,v&255,8)}function w16(a:number, v:number){wr(id,a,v&65535,16)}function w32(a:number, v:number){wr(id,a,v|0,32)}
function ramReset(f:number){var i;
if(f&1)for(i=0;i<0x40000;i+=4)w32(0x02000000+i,0);
if(f&2)for(i=0;i<0x7E00;i+=4)w32(0x03000000+i,0);
if(f&4)for(i=0;i<0x400;i+=4)w32(0x05000000+i,0);
if(f&8)for(i=0;i<0x18000;i+=4)w32(0x06000000+i,0);
if(f&16)for(i=0;i<0x400;i+=4)w32(0x07000000+i,0);
if(f&0x80){for(i=0;i<0x30;i++)io[i]=0;io[0]=0x80}
if(f&0x40)for(i=0x30;i<0x58;i++)io[i]=0}
function bios(n:number){var r0=R[0],r1=R[1],r2=R[2],r3=R[3],i,j,x,y;window.__sw=n;window.__swc=(window.__swc|0)+1;
switch(n){
case 0:boot(r8(0x03007FFA)?0x02000000:0x08000000,0x03007FE0,0x03007FA0,0x03007F00);for(i=0;i<0x200;i+=4)w32(0x03007E00+i,0);break;
case 1:ramReset(r0&255);break;
case 2:case 3:halted=1;break;
case 4:case 5:{var m=n===5?1:r1;if((n===4&&r0)||n===5){var fp=flagPtr();w16(fp,r16(fp)&~m)}ime[id]=1;waiting=m;waitPC=R[15];break}
case 6:div(r0,r1);break;
case 7:div(r1,r0);break;
case 8:R[0]=Math.floor(Math.sqrt(r0>>>0));break;
case 9:R[0]=Math.round(Math.atan((r0<<16>>16)/16384)*65536/(2*Math.PI));break;
case 10:x=r0<<16>>16;y=r1<<16>>16;R[0]=(x===0&&y===0)?0:(Math.round(Math.atan2(y,x)*65536/(2*Math.PI))&0xFFFF);break;
case 11:{var len=r2&0x1FFFFF,fl=r2&0x1000000,w4=r2&0x4000000,sa=r0,da=r1,v;
if(w4){sa&=~3;da&=~3}else{sa&=~1;da&=~1}
v=w4?r32(sa):r16(sa);
for(i=0;i<len;i++){if(!fl)v=w4?r32(sa+i*4):r16(sa+i*2);if(w4)w32(da+i*4,v);else w16(da+i*2,v)}break}
case 12:{var l2=(r2&0x1FFFFF+7)&~7,f2=r2&0x1000000,sa2=r0&~3,da2=r1&~3,v2=r32(sa2);l2=((r2&0x1FFFFF)+7)&~7;
for(i=0;i<l2;i++){if(!f2)v2=r32(sa2+i*4);w32(da2+i*4,v2)}break}
case 13:R[0]=0xBAAE187F;break;
case 14:{var sp=r0,dp=r1;for(i=0;i<r2;i++){var ox=r32(sp),oy=r32(sp+4),scx=r16(sp+8)<<16>>16,scy=r16(sp+10)<<16>>16,sx=r16(sp+12)<<16>>16,sy=r16(sp+14)<<16>>16,an=r16(sp+16);sp+=20;
var th=(an>>>8)*(2*Math.PI/256),c=Math.cos(th),s=Math.sin(th),pa=Math.round(sx*c),pb=Math.round(-sx*s),pc=Math.round(sy*s),pd=Math.round(sy*c);
w16(dp,pa);w16(dp+2,pb);w16(dp+4,pc);w16(dp+6,pd);w32(dp+8,ox-(pa*scx+pb*scy));w32(dp+12,oy-(pc*scx+pd*scy));dp+=16}break}
case 15:{var sp2=r0,dp2=r1;for(i=0;i<r2;i++){var sx2=r16(sp2)<<16>>16,sy2=r16(sp2+2)<<16>>16,an2=r16(sp2+4);sp2+=8;
var th2=(an2>>>8)*(2*Math.PI/256),c2=Math.cos(th2),s2=Math.sin(th2);
w16(dp2,Math.round(sx2*c2));w16(dp2+r3,Math.round(-sx2*s2));w16(dp2+2*r3,Math.round(sy2*s2));w16(dp2+3*r3,Math.round(sy2*c2));dp2+=4*r3}break}
case 16:{var sl=r16(r2),sw=r8(r2+2),dw=r8(r2+3),of=r32(r2+4),zf=of&0x80000000,offs=of&0x7FFFFFFF,src=r0,dst=r1,out=0,ob=0,mk2=(1<<sw)-1;
for(i=0;i<sl;i++){var b=r8(src+i);for(j=0;j<8;j+=sw){var vv=(b>>j)&mk2;if(vv||zf)vv+=offs;out|=vv<<ob;ob+=dw;if(ob>=32){w32(dst,out);dst+=4;out=0;ob=0}}}break}
case 17:case 18:{var s=r0,d=r1,hd=r32(s),sz=hd>>>8,o=0,wv=n===18,buf:number[]=[];s+=4;
while(o<sz){var fg=r8(s++);for(i=7;i>=0&&o<sz;i--){if(fg>>i&1){var b1=r8(s++),b2=r8(s++),ln=(b1>>4)+3,ds=((b1&15)<<8|b2)+1;for(j=0;j<ln&&o<sz;j++){buf[o]=buf[o-ds];o++}}else buf[o++]=r8(s++)}}
for(i=0;i<sz;i++){if(wv){if(i&1)w16(d+i-1,buf[i-1]|buf[i]<<8)}else w8(d+i,buf[i])}if(wv&&(sz&1))w16(d+sz-1,buf[sz-1]);break}
case 19:{var hs=r0,hd2=r1,h=r32(hs),bits=h&15,tot=h>>>8,ts=r8(hs+4),root=hs+5,node=root,dpp=hs+4+(ts+1)*2,wd=0,bl=0,ac=0,ab=0,oc2=0;
while(oc2<tot){if(bl===0){wd=r32(dpp);dpp+=4;bl=32}var bit=(wd>>>31)&1;wd<<=1;bl--;
var nb=r8(node),of2=nb&63,ch=((node&~1)+(of2+1)*2)+bit,isD=bit?(nb&0x40):(nb&0x80);
if(isD){ac|=r8(ch)<<ab;ab+=bits;node=root;if(ab>=32){w32(hd2,ac);hd2+=4;oc2+=4;ac=0;ab=0}}else node=ch}break}
case 20:case 21:{var s3=r0,d3=r1,h3=r32(s3),z3=h3>>>8,o3=0,b3=[];s3+=4;
while(o3<z3){var f3=r8(s3++),l3=f3&0x7F;if(f3&0x80){l3+=3;var dv=r8(s3++);for(i=0;i<l3&&o3<z3;i++)b3[o3++]=dv}else{l3+=1;for(i=0;i<l3&&o3<z3;i++)b3[o3++]=r8(s3++)}}
for(i=0;i<z3;i++){if(n===21){if(i&1)w16(d3+i-1,b3[i-1]|b3[i]<<8)}else w8(d3+i,b3[i])}break}
case 22:case 23:{var s4=r0,d4=r1,h4=r32(s4),z4=h4>>>8,pv=0,bb4=[];s4+=4;for(i=0;i<z4;i++){pv=(pv+r8(s4+i))&255;bb4[i]=pv}
for(i=0;i<z4;i++){if(n===23){if(i&1)w16(d4+i-1,bb4[i-1]|bb4[i]<<8)}else w8(d4+i,bb4[i])}break}
case 24:{var s5=r0,d5=r1,h5=r32(s5),z5=h5>>>8,pv5=0;s5+=4;for(i=0;i<z5;i+=2){pv5=(pv5+r16(s5+i))&65535;w16(d5+i,pv5)}break}
case 31:R[0]=Math.floor(r32(r0+4)/Math.pow(2,(180-(r1&255)-(r2&255)/256)/12))|0;break;
default:window.__swu=n}}
/* Thumb */
function talu(op:number, rdn:number, rsn:number){var a=R[rdn],b=R[rsn],r;
switch(op){
case 0:r=nz(a&b);break;case 1:r=nz(a^b);break;
case 2:r=shf(0,a,b&255,0);nz(r);C=cc;break;case 3:r=shf(1,a,b&255,0);nz(r);C=cc;break;case 4:r=shf(2,a,b&255,0);nz(r);C=cc;break;
case 5:r=add(a,b,C,1);break;case 6:r=sub(a,b,C,1);break;case 7:r=shf(3,a,b&255,0);nz(r);C=cc;break;
case 8:nz(a&b);return;case 9:r=sub(0,b,1,1);break;case 10:sub(a,b,1,1);return;case 11:add(a,b,0,1);return;
case 12:r=nz(a|b);break;case 13:r=nz(Math.imul(a,b));break;case 14:r=nz(a&~b);break;default:r=nz(~b)}
R[rdn]=r}
function th(i:number){var op=i>>>11,rdn,rsn,a,b,v,t;
switch(op){
case 0:case 1:case 2:rdn=i&7;v=shf(op,R[i>>>3&7],i>>>6&31,1);R[rdn]=v;nz(v);C=cc;return;
case 3:a=R[i>>>3&7];b=i&0x400?(i>>>6&7):R[i>>>6&7];R[i&7]=i&0x200?sub(a,b,1,1):add(a,b,0,1);return;
case 4:rdn=i>>>8&7;R[rdn]=nz(i&255);return;
case 5:sub(R[i>>>8&7],i&255,1,1);return;
case 6:rdn=i>>>8&7;R[rdn]=add(R[rdn],i&255,0,1);return;
case 7:rdn=i>>>8&7;R[rdn]=sub(R[rdn],i&255,1,1);return;
case 8:if(i&0x400){var o2=i>>>8&3;rdn=(i&7)|(i>>>4&8);rsn=i>>>3&15;b=rsn===15?R[15]+2:R[rsn];a=rdn===15?R[15]+2:R[rdn];
if(o2===0){v=a+b|0;if(rdn===15)R[15]=v&~1;else R[rdn]=v}
else if(o2===1)sub(a,b,1,1);
else if(o2===2){if(rdn===15)R[15]=b&~1;else R[rdn]=b}
else{if(A9&&(i&0x80))R[14]=R[15]|1;bx(b)}}
else talu(i>>>6&15,i&7,i>>>3&7);return;
case 9:R[i>>>8&7]=rd(id,((R[15]+2)&~3)+((i&255)<<2),32);return;
case 10:case 11:{rdn=i&7;a=R[i>>>3&7]+R[i>>>6&7]|0;switch(i>>>9&7){
case 0:wr(id,a,R[rdn],32);break;case 1:wr(id,a,R[rdn]&65535,16);break;case 2:wr(id,a,R[rdn]&255,8);break;
case 3:R[rdn]=rd(id,a,8)<<24>>24;break;case 4:R[rdn]=ldw(a);break;case 5:R[rdn]=rd(id,a,16);break;case 6:R[rdn]=rd(id,a,8);break;default:R[rdn]=rd(id,a,16)<<16>>16}return}
case 12:wr(id,R[i>>>3&7]+((i>>>6&31)<<2)|0,R[i&7],32);return;
case 13:R[i&7]=ldw(R[i>>>3&7]+((i>>>6&31)<<2)|0);return;
case 14:wr(id,R[i>>>3&7]+(i>>>6&31)|0,R[i&7]&255,8);return;
case 15:R[i&7]=rd(id,R[i>>>3&7]+(i>>>6&31)|0,8);return;
case 16:wr(id,R[i>>>3&7]+((i>>>6&31)<<1)|0,R[i&7]&65535,16);return;
case 17:R[i&7]=rd(id,R[i>>>3&7]+((i>>>6&31)<<1)|0,16);return;
case 18:wr(id,R[13]+((i&255)<<2)|0,R[i>>>8&7],32);return;
case 19:R[i>>>8&7]=ldw(R[13]+((i&255)<<2)|0);return;
case 20:R[i>>>8&7]=((R[15]+2)&~3)+((i&255)<<2);return;
case 21:R[i>>>8&7]=R[13]+((i&255)<<2);return;
case 22:case 23:{var h=i>>>8&15;
if(h===0){R[13]=R[13]+(i&0x80?-(i&0x7F)*4:(i&0x7F)*4)}
else if(h===4||h===5){var rl=i&255,n=pc16(rl)+(h&1),sp=R[13]-4*n,ad=sp;for(t=0;t<8;t++)if(rl>>t&1){wr(id,ad,R[t],32);ad+=4}if(h&1)wr(id,ad,R[14],32);R[13]=sp}
else if(h===12||h===13){var rl2=i&255,ad2=R[13];for(t=0;t<8;t++)if(rl2>>t&1){R[t]=rd(id,ad2,32);ad2+=4}
if(h&1){v=rd(id,ad2,32);ad2+=4;if(A9)bx(v);else R[15]=v&~1}R[13]=ad2}
return}
case 24:{rdn=i>>>8&7;var rl3=i&255,ad3=R[rdn];for(t=0;t<8;t++)if(rl3>>t&1){wr(id,ad3,R[t],32);ad3+=4}R[rdn]=ad3;return}
case 25:{rdn=i>>>8&7;var rl4=i&255,ad4=R[rdn];for(t=0;t<8;t++)if(rl4>>t&1){R[t]=rd(id,ad4,32);ad4+=4}if(!(rl4>>rdn&1))R[rdn]=ad4;return}
case 26:case 27:{var cd=i>>>8&15;if(cd===15)bios(i&255);else if(cd!==14&&ck(cd))R[15]=R[15]+2+((i<<24>>24)<<1);return}
case 28:R[15]=R[15]+2+((i<<21>>21)<<1);return;
case 29:if(A9){t=R[15];R[15]=(R[14]+((i&0x7FF)<<1))&~3;R[14]=t|1;T=0}return;
case 30:R[14]=R[15]+2+((i<<21>>21)<<12);return;
case 31:t=R[15];R[15]=R[14]+((i&0x7FF)<<1);R[14]=t|1;return}}
function irqEnter(){spsr[18]=cpsr();var lr=R[15]+4;setMode(18);R[14]=lr;T=0;I=1;R[15]=0x18}
function step(){var pc=R[15],ins;
if(T){ins=rd(id,pc,16);R[15]=pc+2;th(ins);return}
ins=rd(id,pc,32);R[15]=pc+4;var cond=ins>>>28;
if(cond!==14){if(cond===15){if(!A9||(ins>>>25&7)!==5)return}else if(!ck(cond))return}
ar(ins,cond)}
function run(n:number){for(var k=0;k<n;k++){
if(trf)trf(R);if(burnN>0){burnN--;continue}
if(halted){if(ie[id]&ifl[id])halted=0;else return}
if(!I&&ime[id]&&(ie[id]&ifl[id]))irqEnter();
if(waiting&&R[15]===waitPC){var fp=flagPtr(),w=rd(id,fp,32);if(w&waiting){wr(id,fp,w&~waiting,32);waiting=0}else{halted=1;continue}}
step()}}
function boot(entry:number, sps:number, spi:number, spu:number){R.fill(0);N=Z=C=V=Q=0;I=0;F=0;T=0;md=31;b13.fill(0);b14.fill(0);b13[18]=spi;b13[19]=sps;R[13]=spu;R[15]=entry;halted=0;waiting=0}
o.R=R;o.run=run;o.boot=boot;o.state=function(){return{pc:R[15],t:T,md:md,cpsr:cpsr(),halted:halted,w:waiting}};
o.setFlags=function(n,z,c,v){N=n;Z=z;C=c;V=v};o.flags=function(){return[N,Z,C,V]};o.step=step;o.setT=function(t){T=t};
o.halt=function(v){halted=v};o.getS=function(){return{R:R.slice(),N:N,Z:Z,C:C,V:V,Q:Q,I:I,F:F,T:T,md:md,cc:cc,halted:halted,waiting:waiting,waitPC:waitPC,burnN:burnN,b13:b13.slice(),b14:b14.slice(),spsr:spsr.slice(),fq:fq.slice(),us:us.slice()}};o.setS=function(s){R.set(s.R);N=s.N;Z=s.Z;C=s.C;V=s.V;Q=s.Q;I=s.I;F=s.F;T=s.T;md=s.md;cc=s.cc;halted=s.halted;waiting=s.waiting;waitPC=s.waitPC!==undefined?s.waitPC:R[15];burnN=s.burnN;b13.set(s.b13);b14.set(s.b14);spsr.set(s.spsr);fq.set(s.fq);us.set(s.us)};o.setTr=function(f){trf=f};o.isHalted=function(){return halted};
return o}

/* ---------- E/S, interrupções, timers, DMA, teclado ---------- */
function raise(b:number){ifl[7]|=1<<b}
function s28(i:number){return(io[i]|io[i+1]<<16)<<4>>4}
function ior(o:number, sz:number){if(sz===32)return(ior16(o&~3)|ior16((o&~3)+2)<<16)|0;if(sz===16)return ior16(o&~1);var v=ior16(o&~1);return o&1?v>>8:v&255}
function ior16(o:number){
switch(o){
case 0x004:return io[2];
case 0x006:return ly;
case 0x130:return(~kp)&0x3FF;
case 0x132:return kcnt;
case 0x200:return ie[7]&0x3FFF;case 0x202:return ifl[7]&0x3FFF;case 0x208:return ime[7]&1}
if(o>=0x60&&o<0xB0)return sndRd(o);
if(o>=0x100&&o<0x110){var i=(o-0x100)>>2;return o&2?tl[i]:tc[i]}
if(o>=0xB0&&o<0xE0){return((o-0xB0)%12)===10?io[o>>1]:0}
return io[o>>1]}
function iow(o:number, v:number, sz:number){
if(sz===32){iow16(o&~3,v&65535);iow16((o&~3)+2,(v>>>16)&65535);return}
if(sz===16){iow16(o&~1,v&65535);return}
if(o===0x301){cpu.halt(1);return}
if(o===0x300){io[0x180]=v;return}
if(o===0x202||o===0x203){ifl[7]&=~(v<<((o&1)*8));return}
if(o>=0xA0&&o<0xA8){sndFifoB(o,v);return}
var cur=(o>=0x60&&o<0xB0)?sndRaw(o&~1):ior16(o&~1);iow16(o&~1,o&1?(cur&255)|(v<<8):(cur&0xFF00)|v)}
function iow16(o:number, v:number){
switch(o){
case 0x004:io[2]=(io[2]&7)|(v&0xFFF8);return;
case 0x006:case 0x130:return;
case 0x132:kcnt=v;kcheck();return;
case 0x200:ie[7]=v&0x3FFF;return;
case 0x202:ifl[7]&=~v;return;
case 0x208:ime[7]=v&1;return}
if(o>=0x100&&o<0x110){var i=(o-0x100)>>2;if(o&2){if(!(tl[i]&0x80)&&(v&0x80)){tc[i]=trl[i];tacc[i]=0}tl[i]=v}else trl[i]=v;return}
var old=io[o>>1];io[o>>1]=v;
if(o>=0xBA&&o<=0xDE&&((o-0xBA)%12)===0){if((v&0x8000)&&!(old&0x8000))dmaStart((o-0xBA)/12)}
else if(o>=0x28&&o<=0x2F){rx[0]=s28(0x14);ry[0]=s28(0x16)}
else if(o>=0x38&&o<=0x3F){rx[1]=s28(0x1C);ry[1]=s28(0x1E)}
else if(o>=0x60&&o<0xB0)sndW(o,v)}
/* ===================== SOM DO GBA ===================== */
/* Saída: AudioWorklet (thread própria = sem cortes) com fallback ScriptProcessor.
   Fila FIFO em taxa fixa, com pré-buffer e fade suave em falta de dados,
   mixagem PSG + Direct Sound com integração por área
   (sem aliasing), eventos de timer com precisão de ciclo, filtro DC,
   passa-baixa leve e limitador suave (sem estourar). */
function mkRing(sr:number,tgtS:number):GbaAudioRing{
 /* Fila estéreo com controle dinâmico de taxa: o relógio do áudio e o do emulador nunca
    batem 100%, então a leitura acelera/desacelera de forma mínima (e suavizada) para manter
    o buffer sempre perto do alvo. Interpolação cúbica = sem chiado. Sem esvaziar = sem "tec". */
 var N=32768,M=N-1,Lb=new Float32Array(N),Rb=new Float32Array(N),
     wp=0,rp=0,fr=0,count=0,target=Math.max(1024,Math.min((N>>2)-512,(sr*tgtS)|0)),
     startAt=Math.max(512,(target*.35)|0),playing=0,gain=0,ratio=1,lastL=0,lastR=0,
     fadeStep=1/Math.max(1,(sr*.008)|0),jmp=0;
 return{
  push:function(a:Float32Array,n:number){
   var i,k,d;
   if(count>target*3){d=count-((target*1.2)|0);rp=(rp+d)&M;count-=d;jmp++}
   for(i=0;i<n;i++){
    if(count>=N-8)break;
    k=wp&M;Lb[k]=a[i*2];Rb[k]=a[i*2+1];wp=(wp+1)&M;count++
   }
  },
  reset:function(){wp=0;rp=0;fr=0;count=0;playing=0;gain=0;ratio=1;lastL=0;lastR=0;Lb.fill(0);Rb.fill(0)},
  fill:function(){return count},
  target:function(){return target},
  ratio:function(){return ratio},
  jumps:function(){return jmp},
  process:function(L:Float32Array,R:Float32Array){
   var len=L.length,i,k,x,y,t,t2,t3,a0,a1,a2,a3,b0,b1,b2,b3,des,e,al;
   e=(count-fr-target)/target;des=1;
   al=len/(sr*(e<-.6?.06:.4));if(al>1)al=1;if(playing)ratio+=(des-ratio)*al;else ratio=1;
   for(i=0;i<len;i++){
    if(!playing&&count>=startAt){playing=1;gain=0}
    if(playing&&count>=4){
     k=rp&M;t=fr;t2=t*t;t3=t2*t;
     a0=Lb[(k-1)&M];a1=Lb[k];a2=Lb[(k+1)&M];a3=Lb[(k+2)&M];
     b0=Rb[(k-1)&M];b1=Rb[k];b2=Rb[(k+1)&M];b3=Rb[(k+2)&M];
     x=a1+.5*t*(a2-a0)+t2*(a0-2.5*a1+2*a2-.5*a3)+t3*(.5*(a3-a0)+1.5*(a1-a2));
     y=b1+.5*t*(b2-b0)+t2*(b0-2.5*b1+2*b2-.5*b3)+t3*(.5*(b3-b0)+1.5*(b1-b2));
     fr+=ratio;while(fr>=1){fr-=1;rp=(rp+1)&M;count--}
     if(gain<1){gain+=fadeStep;if(gain>1)gain=1}
     lastL=x;lastR=y;L[i]=x*gain;R[i]=y*gain
    }else if(playing){
     gain-=fadeStep;if(gain<0)gain=0;
     L[i]=lastL*gain;R[i]=lastR*gain;
     if(gain===0){playing=0;lastL=0;lastR=0}
    }else{L[i]=0;R[i]=0}
   }
  }
 }
}

function snCh(k:number){return{k:k,on:0,dac:0,len:0,lenOn:0,fr:0,tmr:0,pos:0,duty:0,vol:0,iv:0,eD:0,eP:0,eT:8,sP:0,sD:0,sS:0,sT:8,sOn:0,sh:0}}
var s1=snCh(0),s2=snCh(0),s3=snCh(1),s4=snCh(2),sWave=new Uint8Array(32),sW3={dim:0,sel:0,vol:0,f75:0},sN4={r:0,s:0,w:0},sLf=0x7FFF,sFs=0,sFc=0,
sFifo=[new Int8Array(32),new Int8Array(32)],sFh=[0,0],sFn=[0,0],sDs=[0,0],sEvT=new Float64Array(96),sEvM=new Uint8Array(96),sEn=0,
SDUTY=[1,0x81,0x87,0x7E],
AU:GbaAudioRuntime={ctx:null,node:null,port:null,ring:null,ok:0,rate:48000,cps:174.76,buf:null,bn:0,sp:0,aL:0,aR:0,xl:0,xr:0,yl:0,yr:0,hl:new Float32Array(128),hrr:new Float32Array(128),hp:0,ph:0,fir:null,hr:.9997,vol:1,mg:.7,cold:1};

/* ---- saída de áudio ---- */
function auInit(){
 try{
  var C=window.AudioContext||window.webkitAudioContext;if(!C)return;
  var ac:AudioContext;try{ac=new C({latencyHint:"interactive"})}catch(e){ac=new C()}
  AU.ctx=ac;AU.rate=ac.sampleRate||48000;AU.cps=16777216/(2*AU.rate);AU.fir=snFir(AU.rate);AU.ph=0;
  AU.hr=1-6.2831853*5/(2*AU.rate);
  AU.buf=new Float32Array(2048);AU.bn=0;AU.cold=1;
  var fb=function(){
   if(!AU.ctx||AU.ok)return;
   try{var ring=mkRing(AU.rate,.075),nd=ac.createScriptProcessor(1024,0,2);
    nd.onaudioprocess=function(e){ring.process(e.outputBuffer.getChannelData(0),e.outputBuffer.getChannelData(1))};
    nd.connect(ac.destination);AU.node=nd;AU.ring=ring;AU.ok=1}catch(e){AU.ok=0}};
  var src="var mkRing="+mkRing.toString()+";registerProcessor('gba-out',class extends AudioWorkletProcessor{constructor(){super();var r=mkRing(sampleRate,.075);this.r=r;this.port.onmessage=function(e){var d=e.data;if(d===0)r.reset();else r.push(d,d.length>>1)}}process(i,o){var x=o[0];this.r.process(x[0],x[1]||x[0]);return true}});";
  var wk=0;
  try{
   if(ac.audioWorklet&&window.AudioWorkletNode&&window.Blob&&window.URL&&URL.createObjectURL){
    var url=URL.createObjectURL(new Blob([src],{type:"application/javascript"}));
    ac.audioWorklet.addModule(url).then(function(){
     try{URL.revokeObjectURL(url)}catch(e){}
     if(!AU.ctx)return;
     var nd=new AudioWorkletNode(ac,"gba-out",{numberOfInputs:0,numberOfOutputs:1,outputChannelCount:[2]});
     nd.connect(ac.destination);AU.node=nd;AU.port=nd.port;AU.ok=1
    }).catch(function(){fb()});wk=1}
  }catch(e){wk=0}
  if(!wk)fb();
  auWake()
 }catch(e){AU.ctx=null;AU.ok=0}}
function auWake(){try{if(AU.ctx&&AU.ctx.state==="suspended"){var p=AU.ctx.resume();if(p&&p.catch)p.catch(function(){})}}catch(e){}}
function auReset(){AU.bn=0;AU.sp=0;AU.aL=0;AU.aR=0;AU.cold=1;try{if(AU.port)AU.port.postMessage(0);else if(AU.ring)AU.ring.reset()}catch(e){}}
function auPause(v:number){try{if(!AU.ctx)return;if(v)AU.ctx.suspend();else{auReset();auWake()}}catch(e){}}
function auClose(){try{if(AU.node)AU.node.disconnect()}catch(e){}try{if(AU.ctx)AU.ctx.close()}catch(e){}AU.ctx=null;AU.node=null;AU.port=null;AU.ring=null;AU.ok=0}
function auFlush(){
 var n=AU.bn;if(!n)return;AU.bn=0;if(!AU.ok)return;
 try{if(AU.port){var c=AU.buf.slice(0,n*2);AU.port.postMessage(c,[c.buffer])}else if(AU.ring)AU.ring.push(AU.buf,n)}catch(e){}}
function snLim(x:number){var a=x<0?-x:x;if(a<.7)return x;a=.7+.3*Math.tanh((a-.7)/.3);return x<0?-a:a}
function snFir(rate:number){
 var Fi=2*rate,fc=Math.min(20000,.46*rate)/Fi,N=64,h=new Float32Array(N),s=0,i,x,w,t;
 for(i=0;i<N;i++){x=i-(N-1)/2;t=2*Math.PI*(i+.5)/N;
  w=.35875-.48829*Math.cos(t)+.14128*Math.cos(2*t)-.01168*Math.cos(3*t);
  h[i]=(x===0?2*fc:Math.sin(2*Math.PI*fc*x)/(Math.PI*x))*w;s+=h[i]}
 for(i=0;i<N;i++)h[i]/=s;return h}
function auVol(v:number){v=+v;if(!(v>=0))v=0;if(v>1.5)v=1.5;AU.vol=v;AU.mg=.7*v}
/* recebe amostras na taxa interna (2x); filtro DC; FIR passa-baixa ~20 kHz + decimação 2:1; limitador */
function snOut(L:number, R:number){
 if(AU.cold){AU.xl=L;AU.xr=R;AU.yl=0;AU.yr=0;AU.hl.fill(0);AU.hrr.fill(0);AU.hp=0;AU.ph=0;AU.cold=0}
 var yl=L-AU.xl+AU.hr*AU.yl,yr=R-AU.xr+AU.hr*AU.yr,p=AU.hp,a=0,b=0,k,j,h=AU.fir,hl=AU.hl,hr=AU.hrr;
 AU.xl=L;AU.xr=R;AU.yl=yl;AU.yr=yr;
 hl[p]=yl;hr[p]=yr;p=(p+1)&127;AU.hp=p;
 AU.ph^=1;if(AU.ph)return;
 j=p-1;for(k=0;k<32;k++){a+=h[k]*(hl[(j-k)&127]+hl[(j-63+k)&127]);b+=h[k]*(hr[(j-k)&127]+hr[(j-63+k)&127])}
 k=AU.bn*2;AU.buf[k]=snLim(a*AU.mg);AU.buf[k+1]=snLim(b*AU.mg);
 if(++AU.bn>=512)auFlush()}

/* ---- FIFO do Direct Sound (+ DMA de som) ---- */
function snPush(ch:number, b:number){if(sFn[ch]<32){sFifo[ch][(sFh[ch]+sFn[ch])&31]=b;sFn[ch]++}}
function snDma(ch:number){
 var tgt=0x040000A0+ch*4,i,b,c,s,st,k,w;
 for(i=1;i<3;i++){b=0x58+6*i;c=io[b+5];
  if((c&0x8000)&&((c>>12)&3)===3&&((((io[b+2]|(io[b+3]<<16))&0x0FFFFFFF)&~3)===tgt)){
   k=(c>>7)&3;st=k===2?0:k===1?-4:4;s=dsa[i]&~3;
   for(k=0;k<4;k++){w=rd(0,s,32);s+=st;snPush(ch,w&255);snPush(ch,(w>>8)&255);snPush(ch,(w>>16)&255);snPush(ch,(w>>>24)&255)}
   dsa[i]=s;return}}}
function snPop(ch:number){
 if(sFn[ch]>0){sDs[ch]=sFifo[ch][sFh[ch]];sFh[ch]=(sFh[ch]+1)&31;sFn[ch]--}
 if(sFn[ch]<=16)snDma(ch)}

/* ---- canais 1-4 ---- */
function snPer(c:GbaSoundChannel){return c.k===0?(2048-c.fr)*16:c.k===1?(2048-c.fr)*8:32*(sN4.r?sN4.r:.5)*(1<<(sN4.s+1))}
function snSw(c:GbaSoundChannel){var n=c.sh>>c.sS;n=c.sD?c.sh-n:c.sh+n;if(n>2047)c.on=0;return n}
function snTrig(c:GbaSoundChannel, ln:number){var was=c.on;
 if(!c.len)c.len=ln;
 c.vol=c.iv;c.eT=c.eP||8;c.tmr=snPer(c);
 if(c.k===1||!was)c.pos=0;
 if(c.k===2)sLf=0x7FFF;
 c.on=c.dac?1:0;
 if(c===s1){c.sh=c.fr;c.sT=c.sP||8;c.sOn=(c.sP||c.sS)?1:0;if(c.sS)snSw(c)}}
function snLen(c:GbaSoundChannel){if(c.lenOn&&c.len>0&&--c.len===0)c.on=0}
function snEnvC(c:GbaSoundChannel){if(!c.eP)return;if(--c.eT<=0){c.eT=c.eP;if(c.eD){if(c.vol<15)c.vol++}else if(c.vol>0)c.vol--}}
function snFs(){
 var s=sFs;sFs=(sFs+1)&7;
 if(!(s&1)){snLen(s1);snLen(s2);snLen(s3);snLen(s4)}
 if(s===2||s===6){var c=s1;if(--c.sT<=0){c.sT=c.sP||8;if(c.sOn&&c.sP){var n=snSw(c);if(n<=2047&&c.sS){c.fr=c.sh=n;snSw(c)}}}}
 if(s===7){snEnvC(s1);snEnvC(s2);snEnvC(s4)}}
/* integrais (nível × ciclos) de cada canal ao longo de dt ciclos */
function sqI(c:GbaSoundChannel, dt:number){var per=(2048-c.fr)*16,t=c.tmr,p=c.pos,pt=SDUTY[c.duty],s=0,b=(pt>>(7-p))&1,d;
 while(dt>1e-9){d=dt<t?dt:t;if(b)s+=d;t-=d;dt-=d;if(t<=1e-9){p=(p+1)&7;b=(pt>>(7-p))&1;t+=per}}
 c.tmr=t;c.pos=p;return s*c.vol}
function snNib(p:number){var bk=sW3.dim?((sW3.sel+(p>>5))&1):sW3.sel,by=sWave[bk*16+((p&31)>>1)];return(p&1)?by&15:by>>4}
function wvI(c:GbaSoundChannel, dt:number){var per=(2048-c.fr)*8,t=c.tmr,p=c.pos,ns=sW3.dim?64:32,s=0,b=snNib(p),d,vf=sW3.f75?.75:sW3.vol===1?1:sW3.vol===2?.5:sW3.vol===3?.25:0;
 while(dt>1e-9){d=dt<t?dt:t;s+=b*d;t-=d;dt-=d;if(t<=1e-9){p++;if(p>=ns)p=0;b=snNib(p);t+=per}}
 c.tmr=t;c.pos=p;return s*vf}
function nzI(c:GbaSoundChannel, dt:number){var sh=sN4.s,per=32*(sN4.r?sN4.r:.5)*(1<<(sh+1)),t=c.tmr,lf=sLf,s=0,b=(~lf)&1,d,x;
 if(sh>=14){c.tmr=t;return b*dt*c.vol}
 while(dt>1e-9){d=dt<t?dt:t;if(b)s+=d;t-=d;dt-=d;if(t<=1e-9){x=(lf&1)^((lf>>1)&1);lf=(lf>>1)|(x<<14);if(sN4.w)lf=(lf&~0x40)|(x<<6);b=(~lf)&1;t+=per}}
 c.tmr=t;sLf=lf;return s*c.vol}

/* ---- registradores ---- */
function sndRaw(o:number){var i;if(o>=0x90&&o<0xA0){i=(1-sW3.sel)*16+(o-0x90);return sWave[i]|(sWave[i+1]<<8)}return io[o>>1]}
function sndRd(o:number){var v=sndRaw(o);
 switch(o){
 case 0x60:return v&0x7F;
 case 0x62:case 0x68:return v&0xFFC0;
 case 0x64:case 0x6C:case 0x74:return v&0x4000;
 case 0x70:return v&0xE0;
 case 0x72:return v&0xE000;
 case 0x78:return v&0xFF00;
 case 0x7C:return v&0x40FF;
 case 0x80:return v&0xFF77;
 case 0x82:return v&0x770F;
 case 0x84:return(io[0x42]&0x80)|(s1.on?1:0)|(s2.on?2:0)|(s3.on?4:0)|(s4.on?8:0);
 case 0x88:return v&0xC3FE}
 if(o>=0xA0&&o<0xA8)return 0;
 return v}
function snEnv(c:GbaSoundChannel, v:number){c.len=64-(v&63);c.duty=(v>>6)&3;c.iv=(v>>12)&15;c.eD=(v>>11)&1;c.eP=(v>>8)&7;c.dac=(v&0xF800)?1:0;if(!c.dac)c.on=0}
function sndFifoB(o:number, v:number){snPush(o<0xA4?0:1,v&255)}
function sndW(o:number, v:number){var m=io[0x42]&0x80,c;
 if(o===0x84){v&=0x80;io[0x42]=v;if(!v){s1.on=s2.on=s3.on=s4.on=0}else if(!m)sFs=0;return}
 if(o>=0x90&&o<0xA0){c=(1-sW3.sel)*16+(o-0x90);sWave[c]=v&255;sWave[c+1]=(v>>8)&255;return}
 if(o>=0xA0&&o<0xA8){c=o<0xA4?0:1;snPush(c,v&255);snPush(c,(v>>8)&255);return}
 switch(o){
 case 0x60:s1.sP=(v>>4)&7;s1.sD=(v>>3)&1;s1.sS=v&7;break;
 case 0x62:snEnv(s1,v);break;
 case 0x64:s1.fr=v&2047;s1.lenOn=(v>>14)&1;io[0x32]=v&0x7FFF;if((v&0x8000)&&m)snTrig(s1,64);break;
 case 0x68:snEnv(s2,v);break;
 case 0x6C:s2.fr=v&2047;s2.lenOn=(v>>14)&1;io[0x36]=v&0x7FFF;if((v&0x8000)&&m)snTrig(s2,64);break;
 case 0x70:sW3.dim=(v>>5)&1;sW3.sel=(v>>6)&1;s3.dac=(v>>7)&1;if(!s3.dac)s3.on=0;break;
 case 0x72:s3.len=256-(v&255);sW3.vol=(v>>13)&3;sW3.f75=(v>>15)&1;break;
 case 0x74:s3.fr=v&2047;s3.lenOn=(v>>14)&1;io[0x3A]=v&0x7FFF;if((v&0x8000)&&m)snTrig(s3,256);break;
 case 0x78:snEnv(s4,v);break;
 case 0x7C:sN4.r=v&7;sN4.w=(v>>3)&1;sN4.s=(v>>4)&15;s4.lenOn=(v>>14)&1;io[0x3E]=v&0x7FFF;if((v&0x8000)&&m)snTrig(s4,64);break;
 case 0x82:if(v&0x800){sFn[0]=0;sFh[0]=0}if(v&0x8000){sFn[1]=0;sFh[1]=0}io[0x41]=v&0x770F;break}}

/* ---- timers alimentam o Direct Sound (t0 = ciclo do 1º overflow na linha) ---- */
function sndTm(i:number, ov:number, t0:number, per:number){
 if(!(io[0x42]&0x80))return;
 var h=io[0x41],mk=(((h>>10)&1)===i?1:0)|(((h>>14)&1)===i?2:0),k,t,ex;
 if(!mk)return;
 if(ov>24){ex=ov-24;ov=24;for(k=0;k<ex;k++){if(mk&1)snPop(0);if(mk&2)snPop(1)}}
 for(k=0;k<ov;k++){
  t=t0<0?(k+.5)*1232/ov:t0+k*per;if(t>=1232)t=1231.99;
  if(sEn<96){sEvT[sEn]=t;sEvM[sEn]=mk;sEn++}else{if(mk&1)snPop(0);if(mk&2)snPop(1)}}}

/* ---- uma linha de vídeo (1232 ciclos) ---- */
function sndLine(){
 var m=io[0x42]&0x80,n=sEn,i,j,tm,mk,T,ei,nx,dt,th,q1,q2,q3,q4,cps=AU.cps,cnt,h,eL,eR,pr,kL,kR,sa,sb,dL,dR,ch;
 sFc+=1232;while(sFc>=32768){sFc-=32768;if(m)snFs()}
 sEn=0;
 for(i=1;i<n;i++){tm=sEvT[i];mk=sEvM[i];j=i-1;while(j>=0&&sEvT[j]>tm){sEvT[j+1]=sEvT[j];sEvM[j+1]=sEvM[j];j--}sEvT[j+1]=tm;sEvM[j+1]=mk}
 if(!AU.ok||ffm!==1||!m){
  for(i=0;i<n;i++){if(sEvM[i]&1)snPop(0);if(sEvM[i]&2)snPop(1)}
  AU.sp=0;AU.aL=0;AU.aR=0;AU.cold=1;return}
 cnt=io[0x40];h=io[0x41];eL=(cnt>>12)&15;eR=(cnt>>8)&15;pr=h&3;pr=pr===0?.25:pr===1?.5:1;
 kL=(((cnt>>4)&7)+1)*pr/512;kR=((cnt&7)+1)*pr/512;sa=(h&4)?1:.5;sb=(h&8)?1:.5;
 dL=(((h&0x200)?sDs[0]*sa:0)+((h&0x2000)?sDs[1]*sb:0))/128;
 dR=(((h&0x100)?sDs[0]*sa:0)+((h&0x1000)?sDs[1]*sb:0))/128;
 T=0;ei=0;
 while(T<1232){
  nx=1232;th=cps-AU.sp;if(T+th<nx)nx=T+th;
  if(ei<n&&sEvT[ei]<nx)nx=sEvT[ei];
  if(nx<T)nx=T;
  dt=nx-T;
  if(dt>0){
   q1=s1.on?sqI(s1,dt):0;q2=s2.on?sqI(s2,dt):0;q3=s3.on?wvI(s3,dt):0;q4=s4.on?nzI(s4,dt):0;
   AU.aL+=((eL&1?q1:0)+(eL&2?q2:0)+(eL&4?q3:0)+(eL&8?q4:0))*kL+dL*dt;
   AU.aR+=((eR&1?q1:0)+(eR&2?q2:0)+(eR&4?q3:0)+(eR&8?q4:0))*kR+dR*dt;
   AU.sp+=dt;T=nx;
   if(AU.sp>=cps-1e-6){snOut(AU.aL/cps,AU.aR/cps);AU.aL=0;AU.aR=0;AU.sp=0}}
  else T=nx;
  ch=0;
  while(ei<n&&sEvT[ei]<=T+1e-6){if(sEvM[ei]&1)snPop(0);if(sEvM[ei]&2)snPop(1);ei++;ch=1}
  if(ch){
   dL=(((h&0x200)?sDs[0]*sa:0)+((h&0x2000)?sDs[1]*sb:0))/128;
   dR=(((h&0x100)?sDs[0]*sa:0)+((h&0x1000)?sDs[1]*sb:0))/128}}}

/* ---- reset / estado ---- */
function sndReset(){
 s1=snCh(0);s2=snCh(0);s3=snCh(1);s4=snCh(2);sWave.fill(0);sW3.dim=0;sW3.sel=0;sW3.vol=0;sW3.f75=0;sN4.r=0;sN4.s=0;sN4.w=0;sLf=0x7FFF;sFs=0;sFc=0;
 sFifo[0].fill(0);sFifo[1].fill(0);sFh[0]=sFh[1]=0;sFn[0]=sFn[1]=0;sDs[0]=sDs[1]=0;sEn=0;io[0x44]=0x200;
 AU.sp=0;AU.aL=0;AU.aR=0;AU.cold=1;AU.bn=0;try{if(AU.port)AU.port.postMessage(0);else if(AU.ring)AU.ring.reset()}catch(e){}}
function sndSave(){var cp=function<T extends object>(c:T):T{return Object.assign({},c)};
 return{c:[cp(s1),cp(s2),cp(s3),cp(s4)],w:sWave.slice(),w3:cp(sW3),n4:cp(sN4),lf:sLf,fs:sFs,fc:sFc,ff:[sFifo[0].slice(),sFifo[1].slice()],fh:sFh.slice(),fn:sFn.slice(),ds:sDs.slice()}}
function sndLoad(a:ReturnType<typeof sndSave>):void{
 Object.assign(s1,a.c[0]);Object.assign(s2,a.c[1]);Object.assign(s3,a.c[2]);Object.assign(s4,a.c[3]);
 sWave.set(a.w);Object.assign(sW3,a.w3);Object.assign(sN4,a.n4);sLf=a.lf;sFs=a.fs;sFc=a.fc;
 sFifo[0].set(a.ff[0]);sFifo[1].set(a.ff[1]);sFh[0]=a.fh[0];sFh[1]=a.fh[1];sFn[0]=a.fn[0];sFn[1]=a.fn[1];sDs[0]=a.ds[0];sDs[1]=a.ds[1];sEn=0}
function sndRestore(){
 var rs=[0x84,0x60,0x62,0x64,0x68,0x6C,0x70,0x72,0x74,0x78,0x7C,0x80,0x82],i,o;
 sndReset();
 for(i=0;i<rs.length;i++){o=rs[i];sndW(o,io[o>>1]&0x7FFF|(o===0x84?io[0x42]&0x80:0))}
 sDs[0]=sDs[1]=0}
/* ================== FIM DO SOM DO GBA ================== */
function kcheck(){if(!(kcnt&0x4000))return;var m=kcnt&0x3FF,p=kp&0x3FF;if(kcnt&0x8000){if(m&&(p&m)===m)raise(12)}else if(p&m)raise(12)}
/* DMA */
function dmaStart(i:number){var b=0x58+6*i,w=(io[b+5]&0x400)?4:2;
dsa[i]=((io[b]|io[b+1]<<16)&(i?0xFFFFFFF:0x7FFFFFF))&~(w-1);dda[i]=((io[b+2]|io[b+3]<<16)&(i===3?0xFFFFFFF:0x7FFFFFF))&~(w-1);
dn[i]=io[b+4]||(i===3?0x10000:0x4000);if(((io[b+5]>>12)&3)===0)dmaRun(i)}
function dmaRun(i:number){var b=0x58+6*i,c=io[b+5],w=(c&0x400)?4:2,dc=(c>>5)&3,sc=(c>>7)&3,n=dn[i],s=dsa[i],d=dda[i],tm=(c>>12)&3;
if(i===3&&eepOn&&((d>>>24)===13||(s>>>24)===13)){eepDma(i,s,d,n,w);}
else while(n-->0){if(w===4)wr(0,d,rd(0,s,32),32);else wr(0,d,rd(0,s,16),16);s+=sc===2?0:sc===1?-w:w;d+=dc===2?0:dc===1?-w:w}
dsa[i]=s;
if(c&0x200&&tm!==0){dn[i]=io[b+4]||(i===3?0x10000:0x4000);if(dc===3)dda[i]=((io[b+2]|io[b+3]<<16)&(i===3?0xFFFFFFF:0x7FFFFFF))&~(w-1);else dda[i]=d}
else{io[b+5]=c&0x7FFF}
if(c&0x4000)raise(8+i)}
function dmaT(t:number){for(var i=0;i<4;i++){var c=io[0x58+6*i+5];if((c&0x8000)&&((c>>12)&3)===t)dmaRun(i)}}
/* Timers */
var PSC=[1,64,256,1024];
function tmTick(cy:number){var ov=0,pov,i,n,ps,t0;
for(i=0;i<4;i++){pov=ov;ov=0;if(!(tl[i]&0x80))continue;
if(i>0&&(tl[i]&4)){n=pov;t0=-1}else{ps=PSC[tl[i]&3];t0=(65536-tc[i])*ps-tacc[i];tacc[i]+=cy;n=(tacc[i]/ps)|0;tacc[i]-=n*ps}
if(n){tc[i]+=n;if(tc[i]>65535){var per=65536-trl[i];ov=(((tc[i]-65536)/per)|0)+1;tc[i]=trl[i]+(tc[i]-65536)%per;if(tl[i]&0x40)raise(3+i);sndTm(i,ov,t0,t0<0?0:per*ps)}}}}
/* ---------- Modos de operação ---------- */
var cfg={mode:0},effMode=2,fAvg=16,fCnt=0,skipN=0,skipRender=0;
function setMode(m:number){cfg.mode=m;if(m===1)effMode=1;else if(m===2)effMode=2;fCnt=0}
function adapt(ms:number){fAvg=fAvg*0.9+ms*0.1;if(cfg.mode!==0)return;fCnt++;if(fCnt<40)return;
if(effMode===2&&fAvg>28){effMode=1;fCnt=0}else if(effMode===1&&fAvg<15){effMode=2;fCnt=0}}
/* ---------- Quadro ---------- */
function frame(){var l,hd=(ipl*960/1232)|0,hb=ipl-hd,doR=effMode===2||(frames&1)===0;
for(ly=0;ly<228;ly++){
if(ly===0){rx[0]=s28(0x14);ry[0]=s28(0x16);rx[1]=s28(0x1C);ry[1]=s28(0x1E)}
var vb=ly>=160&&ly<227,lm=ly===(io[2]>>8);
io[2]=(io[2]&~7)|(vb?1:0)|(lm?4:0);
if(lm&&(io[2]&0x20))raise(2);
if(ly===160){if(io[2]&8)raise(0);dmaT(1)}
cpu.run(hd);
if(ly<160&&doR&&!skipRender)rline(ly);
io[2]|=2;if(io[2]&0x10)raise(1);if(ly<160)dmaT(2);
cpu.run(hb);
tmTick(1232);sndLine()}
auFlush();frames++;window.__fc=(window.__fc|0)+1;if(window.__dg){(window.__pcs=window.__pcs||[]).push(cpu.R[15]>>>0);if(window.__pcs.length>6)window.__pcs.shift()}if(doR)fr=1}

/* ---------- Vídeo ---------- */
var cl=new Uint32Array(32768),bgl=[new Uint16Array(240),new Uint16Array(240),new Uint16Array(240),new Uint16Array(240)],so=new Uint16Array(240),sp=new Uint8Array(240),ow=new Uint8Array(240),stt=new Uint8Array(240),bgon=[0,0,0,0],bgp=[0,0,0,0],
SW=[[8,16,32,64],[16,32,32,64],[8,8,16,32]],SH=[[8,16,32,64],[8,8,16,32],[16,32,32,64]];
(function(){for(var q=0;q<32768;q++){var r=q&31,g=(q>>5)&31,b=(q>>10)&31;cl[q]=(0xFF000000|(((b<<3)|(b>>2))<<16)|(((g<<3)|(g>>2))<<8)|((r<<3)|(r>>2)))>>>0}})();
function mosH(L:Uint16Array, c:number){if(!(c&0x40))return;var mh=(io[0x26]&15)+1,x;if(mh>1)for(x=0;x<240;x++)L[x]=L[x-(x%mh)]}
function tbg(b:number, y:number, L:Uint16Array){var c=io[4+b];if(c&0x40)y-=y%(((io[0x26]>>4)&15)+1);
var cb=((c>>2)&3)*0x4000,sbk=((c>>8)&31)*0x800,c8=c&0x80,sz=c>>14,W=(sz&1)?512:256,H=(sz&2)?512:256,sx=io[8+b*2]&511,sy=(y+(io[9+b*2]&511))&(H-1),x,px,a,e,tn,tx,ty,idx,
mapRow=sbk+(((sy>>3)&31)<<6)+(sy>=256?(W===512?0x1000:0x800):0);
for(x=0;x<240;x++){px=(x+sx)&(W-1);a=mapRow+(((px>>3)&31)<<1)+(px>=256?0x800:0);e=VR.u16[a>>1];tn=e&1023;tx=px&7;ty=sy&7;if(e&0x400)tx=7-tx;if(e&0x800)ty=7-ty;
if(c8){idx=VR.u8[(cb+tn*64+ty*8+tx)&0xFFFF];L[x]=idx?PAL.u16[idx]&0x7FFF:0x8000}
else{idx=VR.u8[(cb+tn*32+ty*4+(tx>>1))&0xFFFF];idx=(tx&1)?idx>>4:idx&15;L[x]=idx?PAL.u16[((e>>12)<<4)+idx]&0x7FFF:0x8000}}
mosH(L,c)}
function abg(b:number, y:number, L:Uint16Array){var c=io[4+b],cb=((c>>2)&3)*0x4000,sbk=((c>>8)&31)*0x800,sz=128<<(c>>14),wrap=c&0x2000,i=b===2?0x10:0x18,pa=io[i]<<16>>16,pb=io[i+1]<<16>>16,pc=io[i+2]<<16>>16,pd=io[i+3]<<16>>16,X=rx[b-2],Y=ry[b-2],x,u,v,t,idx;
for(x=0;x<240;x++){u=(X+pa*x)>>8;v=(Y+pc*x)>>8;
if(u<0||v<0||u>=sz||v>=sz){if(!wrap){L[x]=0x8000;continue}u&=sz-1;v&=sz-1}
t=VR.u8[(sbk+(v>>3)*(sz>>3)+(u>>3))&0xFFFF];idx=VR.u8[(cb+t*64+(v&7)*8+(u&7))&0xFFFF];L[x]=idx?PAL.u16[idx]&0x7FFF:0x8000}
mosH(L,c);rx[b-2]+=pb;ry[b-2]+=pd}
function bmp(m:number, y:number, L:Uint16Array){var pa=io[0x10]<<16>>16,pb=io[0x11]<<16>>16,pc=io[0x12]<<16>>16,pd=io[0x13]<<16>>16,X=rx[0],Y=ry[0],W=m===5?160:240,H=m===5?128:160,pg=(io[0]&16)?0xA000:0,x,u,v,idx;
for(x=0;x<240;x++){u=(X+pa*x)>>8;v=(Y+pc*x)>>8;if(u<0||v<0||u>=W||v>=H){L[x]=0x8000;continue}
if(m===3)L[x]=VR.u16[v*240+u]&0x7FFF;
else if(m===4){idx=VR.u8[pg+v*240+u];L[x]=idx?PAL.u16[idx]&0x7FFF:0x8000}
else L[x]=VR.u16[(pg>>1)+v*160+u]&0x7FFF}
rx[0]+=pb;ry[0]+=pd}
function spr(y:number){var d=io[0],oneD=d&0x40,bmM=(d&7)>=3,i,x,a0,a1,a2,rs,md,sh,szc,w,h,bw,bh,sy,ax,c8,t0,pr,pb,g,qa,qb,qc,qd,px,sx,dx,dy,ox2,oy,ti,idx,by,col;
for(x=0;x<240;x++){so[x]=0x8000;sp[x]=255;ow[x]=0;stt[x]=0}
for(i=127;i>=0;i--){a0=OAM.u16[i*4];rs=a0&0x100;if(!rs&&(a0&0x200))continue;md=(a0>>10)&3;if(md===3)continue;sh=a0>>14;if(sh===3)continue;
a1=OAM.u16[i*4+1];a2=OAM.u16[i*4+2];szc=a1>>14;w=SW[sh][szc];h=SH[sh][szc];bw=w;bh=h;if(rs&&(a0&0x200)){bw*=2;bh*=2}
sy=(y-(a0&255))&255;if(sy>=bh)continue;ax=a1&511;if(ax>=256)ax-=512;if(ax>=240||ax+bw<=0)continue;
c8=a0&0x2000;t0=a2&1023;pr=(a2>>10)&3;pb=a2>>12;
if(rs){g=((a1>>9)&31)*16;qa=OAM.u16[g+3]<<16>>16;qb=OAM.u16[g+7]<<16>>16;qc=OAM.u16[g+11]<<16>>16;qd=OAM.u16[g+15]<<16>>16}
for(px=0;px<bw;px++){sx=ax+px;if(sx<0||sx>=240)continue;
if(rs){ox2=px-(bw>>1);oy=sy-(bh>>1);dx=((qa*ox2+qb*oy)>>8)+(w>>1);dy=((qc*ox2+qd*oy)>>8)+(h>>1);if(dx<0||dy<0||dx>=w||dy>=h)continue}
else{dx=(a1&0x1000)?w-1-px:px;dy=(a1&0x2000)?h-1-sy:sy}
ti=oneD?t0+(dy>>3)*(w>>3)*(c8?2:1)+(dx>>3)*(c8?2:1):t0+(dy>>3)*32+(dx>>3)*(c8?2:1);ti&=1023;
if(bmM&&ti<512)continue;
if(c8){idx=VR.u8[0x10000+((ti*32+(dy&7)*8+(dx&7))&0x7FFF)];if(!idx)continue;col=PAL.u16[256+idx]&0x7FFF}
else{by=VR.u8[0x10000+((ti*32+(dy&7)*4+((dx&7)>>1))&0x7FFF)];idx=(dx&1)?by>>4:by&15;if(!idx)continue;col=PAL.u16[256+pb*16+idx]&0x7FFF}
if(md===2){ow[sx]=1;continue}
if(sp[sx]<pr)continue;
so[sx]=col;sp[sx]=pr;stt[sx]=md===1?1:0}}}
function inH(v:number, x:number){var a=v>>8,b=v&255;if(b>240)b=240;return a<=b?(x>=a&&x<b):(x>=a||x<b)}
function inV(v:number, y:number){var a=v>>8,b=v&255;if(b>160)b=160;return a<=b?(y>=a&&y<b):(y>=a||y<b)}
function gbl(a:number, b:number, ea:number, eb:number){var r=((a&31)*ea+(b&31)*eb)>>4,g=(((a>>5)&31)*ea+((b>>5)&31)*eb)>>4,bl=(((a>>10)&31)*ea+((b>>10)&31)*eb)>>4;return(r>31?31:r)|((g>31?31:g)<<5)|((bl>31?31:bl)<<10)}
function gbr(a:number, e:number){var r=a&31,g=(a>>5)&31,b=(a>>10)&31;r+=((31-r)*e)>>4;g+=((31-g)*e)>>4;b+=((31-b)*e)>>4;return r|(g<<5)|(b<<10)}
function gdk(a:number, e:number){var r=a&31,g=(a>>5)&31,b=(a>>10)&31;r-=(r*e)>>4;g-=(g*e)>>4;b-=(b*e)>>4;return r|(g<<5)|(b<<10)}
function rline(y:number){var d=io[0],o=y*240,x,b,p,mode=d&7,bd15;
if(d&0x80){for(x=0;x<240;x++)fb[o+x]=0xFFFFFFFF;return}
bgon[0]=bgon[1]=bgon[2]=bgon[3]=0;
if(mode===0){for(b=0;b<4;b++)if((d>>(8+b))&1){bgon[b]=1;tbg(b,y,bgl[b])}}
else if(mode===1){if(d&0x100){bgon[0]=1;tbg(0,y,bgl[0])}if(d&0x200){bgon[1]=1;tbg(1,y,bgl[1])}if(d&0x400){bgon[2]=1;abg(2,y,bgl[2])}}
else if(mode===2){if(d&0x400){bgon[2]=1;abg(2,y,bgl[2])}if(d&0x800){bgon[3]=1;abg(3,y,bgl[3])}}
else if(mode<=5){if(d&0x400){bgon[2]=1;bmp(mode,y,bgl[2])}}
for(b=0;b<4;b++)bgp[b]=io[4+b]&3;
if(d&0x1000)spr(y);else for(x=0;x<240;x++){so[x]=0x8000;sp[x]=255;ow[x]=0;stt[x]=0}
bd15=PAL.u16[0]&0x7FFF;
var bld=io[0x28],bm=(bld>>6)&3,t1=bld&63,t2=(bld>>8)&63,al=io[0x29],eva=al&31,evb=(al>>8)&31,evy=io[0x2A]&31;if(eva>16)eva=16;if(evb>16)evb=16;if(evy>16)evy=16;
if(effMode===1){
for(x=0;x<240;x++){var c1=-1,l1=5;
for(p=0;p<4&&c1<0;p++){if(sp[x]===p&&so[x]!==0x8000){c1=so[x];l1=4}else for(b=0;b<4;b++)if(bgon[b]&&bgp[b]===p&&bgl[b][x]!==0x8000){c1=bgl[b][x];l1=b;break}}
if(c1<0){c1=bd15;l1=5}
if(bm===2&&((t1>>l1)&1))c1=gbr(c1,evy);else if(bm===3&&((t1>>l1)&1))c1=gdk(c1,evy);
fb[o+x]=cl[c1]}return}
var w0=d&0x2000,w1=d&0x4000,wo=d&0x8000,wc=(d&0xE000)!==0,wi=io[0x24],wout=io[0x25],in0=w0&&inV(io[0x22],y),in1=w1&&inV(io[0x23],y);
for(x=0;x<240;x++){var wf=63,c1=-1,l1=5,c2=-1,l2=5,out;
if(wc){wf=wout&63;if(in0&&inH(io[0x20],x))wf=wi&63;else if(in1&&inH(io[0x21],x))wf=(wi>>8)&63;else if(wo&&ow[x])wf=(wout>>8)&63}
for(p=0;p<4&&c2<0;p++){
if((wf&16)&&sp[x]===p&&so[x]!==0x8000){if(c1<0){c1=so[x];l1=4}else{c2=so[x];l2=4}}
for(b=0;b<4&&c2<0;b++)if(((wf>>b)&1)&&bgon[b]&&bgp[b]===p&&bgl[b][x]!==0x8000){if(c1<0){c1=bgl[b][x];l1=b}else{c2=bgl[b][x];l2=b}}}
if(c1<0){c1=bd15;l1=5;c2=bd15;l2=5}else if(c2<0){c2=bd15;l2=5}
out=c1;
if(wf&32){if(l1===4&&stt[x]&&((t2>>l2)&1))out=gbl(c1,c2,eva,evb);
else if(bm===1&&((t1>>l1)&1)&&((t2>>l2)&1))out=gbl(c1,c2,eva,evb);
else if(bm===2&&((t1>>l1)&1))out=gbr(c1,evy);
else if(bm===3&&((t1>>l1)&1))out=gdk(c1,evy)}
fb[o+x]=cl[out]}}

/* ---------- Save: SRAM, Flash 64K/128K, EEPROM ---------- */
var svT=1,sv=new Uint8Array(0x20000).fill(255),fS=0,fId=0,fBank=0,fErase=0,fProg=0,fBankSet=0,eepOn=0,eepSz=0x2000,eepAddr=0,eepRdPos=0,eepRd=0;
function detectSave(){svT=1;var n=romN-8,i,c;for(i=0;i<n;i++){c=rom8[i];
if(c===69&&rom8[i+1]===69&&rom8[i+2]===80&&rom8[i+3]===82&&rom8[i+4]===79&&rom8[i+5]===77){svT=4;return}
if(c===70&&rom8[i+1]===76&&rom8[i+2]===65&&rom8[i+3]===83&&rom8[i+4]===72){svT=rom8[i+5]===49?3:2;return}
if(c===83&&rom8[i+1]===82&&rom8[i+2]===65&&rom8[i+3]===77){svT=1;return}}}
function savSize(){return svT===1?0x8000:svT===2?0x10000:svT===3?0x20000:eepSz}
function savRd(a:number){var o=a&0xFFFF;if(svT===1)return sv[o&0x7FFF];if(svT===2||svT===3){if(fId&&o<2)return svT===3?(o?0x13:0x62):(o?0x1B:0x32);return sv[(fBank<<16)|o]}return 0xFF}
function savWr(a:number, v:number){var o=a&0xFFFF,ix;
if(svT===1){sv[o&0x7FFF]=v;dirty=1;return}
if(svT!==2&&svT!==3)return;
if(fProg){ix=(fBank<<16)|o;sv[ix]&=v;fProg=0;dirty=1;return}
if(fBankSet&&o===0){fBank=svT===3?(v&1):0;fBankSet=0;return}
if(fS===0){if(v===0xF0){fId=0;return}if(o===0x5555&&v===0xAA)fS=1;return}
if(fS===1){fS=(o===0x2AAA&&v===0x55)?2:0;return}
fS=0;
if(o===0x5555){switch(v){case 0x90:fId=1;break;case 0xF0:fId=0;break;case 0x80:fErase=1;break;case 0xA0:fProg=1;break;case 0xB0:fBankSet=1;break;case 0x10:if(fErase){sv.fill(255);fErase=0;dirty=1}break}}
else if(fErase&&v===0x30){var sb=(fBank<<16)|(o&0xF000);sv.fill(255,sb,sb+0x1000);fErase=0;dirty=1}}
function eepDma(i:number, s:number, d:number, n:number, w:number){var k,bits;
if((d>>>24)===13){bits=[];for(k=0;k<n;k++)bits.push(rd(0,s+k*2,16)&1);eepWrite(bits)}
else for(k=0;k<n;k++)wr(0,d+k*2,eepNext(),16)}
function eepWrite(bits:number[]){var n=bits.length,cmd=(bits[0]<<1)|bits[1],ab=(n===9||n===73)?6:14,addr=0,k,j,b;
if(!eepRd&&!dirty&&ab===6)eepSz=0x200;
for(k=0;k<ab;k++)addr=(addr<<1)|bits[2+k];
if(cmd===2){if(n<2+ab+64)return;for(j=0;j<8;j++){b=0;for(k=0;k<8;k++)b=(b<<1)|bits[2+ab+j*8+k];sv[(addr&0x3FF)*8+j]=b}eepRd=0;dirty=1}
else if(cmd===3){eepAddr=addr&0x3FF;eepRdPos=0;eepRd=1}}
function eepNext(){if(!eepRd)return 1;var p=eepRdPos++;if(p<4)return 0;p-=4;if(p>=64){eepRd=0;return 1}return(sv[eepAddr*8+(p>>3)]>>(7-(p&7)))&1}

/* ---------- Carregar, laço, mensagens ---------- */
function biosInit(){BIOS.u8.fill(0);BIOS.i32[6]=0xEA000042;BIOS.i32[74]=0xE92D500F;BIOS.i32[75]=0xE3A00301;BIOS.i32[76]=0xE28FE000;BIOS.i32[77]=0xE510F004;BIOS.i32[78]=0xE8BD500F;BIOS.i32[79]=0xE25EF004}
function load(buf:Uint8Array,sa:GbaBatterySave|null):void{var i,n=buf.length;window.__legacy=0;romN=n;rom8=new Uint8Array(((n+3)&~3)+8);rom8.set(buf);rom16=new Uint16Array(rom8.buffer);rom32=new Int32Array(rom8.buffer);
gtitle="";for(i=0;i<12;i++){var ch=rom8[0xA0+i];if(ch>31&&ch<127)gtitle+=String.fromCharCode(ch)}gcode="";for(i=0;i<4;i++)gcode+=String.fromCharCode(rom8[0xAC+i]);
detectSave();eepOn=svT===4?1:0;if(svT===4&&sa&&sa.ram&&sa.ev!==2){sa=null;window.__legacy=1}sv.fill(255);if(sa&&sa.ram){var rr=sa.ram.length>sv.length?sa.ram.subarray(0,sv.length):sa.ram;sv.set(rr);if(svT===4&&sa.ram.length)eepSz=sa.ram.length<=0x200?0x200:0x2000}
fS=0;fId=0;fBank=0;fErase=0;fProg=0;fBankSet=0;eepRd=0;
EW.u8.fill(0);IW.u8.fill(0);PAL.u8.fill(0);VR.u8.fill(0);OAM.u8.fill(0);io.fill(0);io[0]=0x80;io[0x10]=0x100;io[0x13]=0x100;io[0x18]=0x100;io[0x1B]=0x100;
ie.fill(0);ifl.fill(0);ime.fill(0);tc=[0,0,0,0];trl=[0,0,0,0];tl=[0,0,0,0];tacc=[0,0,0,0];rx=[0,0];ry=[0,0];kp=0;kcnt=0;frames=0;fb.fill(0xFF000000);
sndReset();biosInit();cpu.boot(0x08000000,0x03007FE0,0x03007FA0,0x03007F00)}
function fit(){var k=Math.max(1,Math.floor((cv.clientWidth||240)*(window.devicePixelRatio||1)/240));vw=240*k;vh=160*k;cv.width=vw;cv.height=vh;vx.imageSmoothingEnabled=false;fr=1}
function loop(t:number){if(stopped)return;requestAnimationFrame(loop);
if(paused||!run){lastT=t;return}
var dt=t-lastT;lastT=t;if(dt>50||dt<0)dt=16.7;acc+=dt*ffm;if(acc>(ffm>1?100:50.228119))acc=(ffm>1?100:50.228119);
try{var n=0;while(acc>=16.7427063&&n<(ffm>1?6:3)){var t0=performance.now();skipRender=(acc>=33.485413&&n<(ffm>1?5:2))?1:0;frame();adapt(performance.now()-t0);acc-=16.7427063;n++}}
catch(e){run=0;P({t:"fail",m:"Erro no emulador: "+(e instanceof Error ? (e instanceof Error ? e.message : String(e)) : String(e))});return}
if(fr){fr=0;ox.putImageData(img,0,0);vx.drawImage(oc,0,0,vw,vh)}}
function sramMsg(){P({k:"gbc-sram",t:"sram",id:gid,rec:{ram:sv.slice(0,savSize()),rtc:0,ev:2}});dirty=0}
async function init(d:GBAInitMessage):Promise<void>{if(started)return;started=1;
try{var buf=new Uint8Array(await new Response(d.blob).arrayBuffer());
if(buf.length<0x200)throw new Error("arquivo pequeno demais");
gid=d.id;load(buf,d.sram);fit();auInit();setInterval(function(){if(dirty&&!stopped)sramMsg()},5000);
run=1;lastT=performance.now();P({t:"start"});setInterval(diag,1000);setInterval(diag2,700);requestAnimationFrame(loop)}
catch(e){P({t:"fail",m:"Não consegui iniciar esse jogo: "+(e instanceof Error ? (e instanceof Error ? e.message : String(e)) : String(e))})}}
function diag(){var el=document.getElementById("dbg");if(!window.__dg){if(el)el.style.display="none";return}
 var wh=1,k;for(k=0;k<fb.length;k+=61)if(fb[k]!==0xFFFFFFFF){wh=0;break}
 if(stopped||!run||paused||!wh||frames<300){if(el)el.style.display="none";return}
 if(!el){el=document.createElement("div");el.id="dbg";el.style.cssText="position:fixed;left:0;right:0;bottom:0;background:rgba(0,0,0,.88);color:#9f9;font:12px monospace;padding:6px;white-space:pre-wrap;z-index:9;pointer-events:none";document.body.appendChild(el)}
 var st=cpu.state(),h=function(v:number){return"0x"+(v>>>0).toString(16)};el.style.display="block";
 el.textContent="TELA BRANCA - diagnostico\nJogo: "+gtitle+" ("+gcode+")  save="+["","SRAM","FLASH64","FLASH128","EEPROM"][svT]+"\nPC="+h(st.pc)+" thumb="+st.t+" modo="+st.md+" cpsr="+h(st.cpsr)+" halt="+st.halted+" espera="+st.w+"\nIE="+h(ie[7])+" IF="+h(ifl[7])+" IME="+ime[7]+" DISPSTAT="+h(io[2])+" DISPCNT="+h(io[0])+" BLDCNT="+h(io[0x28])+" BLDY="+h(io[0x2A])+"\nUltima SWI="+h(window.__sw|0)+" (x"+(window.__swc|0)+")\nPCs: "+(window.__pcs||[]).map(h).join(" ")}
function diag2(){if(stopped||!run||!window.__dg)return;var st=cpu.state(),h=function(v:number){return"0x"+(v>>>0).toString(16)};
P({t:"gbadiag",m:"PC "+h(st.pc)+(st.t?" T":" A")+" md"+st.md+" halt"+st.halted+" w"+st.w+"\nIE "+h(ie[7])+" IF "+h(ifl[7])+" IME "+ime[7]+" DISPSTAT "+h(io[2])+" DISPCNT "+h(io[0])+"\nSWI "+h(window.__sw|0)+" x"+(window.__swc|0)+" und "+(window.__und|0)+" "+h(window.__undI|0)+" swu "+h(window.__swu|0)+"\nfr "+frames+" sv "+svT+" mode "+effMode+" vec "+h(IW.i32[0x7FFC>>2])+"\nPCs "+(window.__pcs||[]).map(h).join(" ")+"\nTM "+tl.map(function(x,i){return h(x)+":"+h(tc[i])}).join(" ")})}
var KM:Record<number,number>={8:0,0:1,2:2,3:3,7:4,6:5,4:6,5:7,10:8,9:9};
function getSt(){return{v:1,EW:EW.u8.slice(),IW:IW.u8.slice(),PAL:PAL.u8.slice(),VR:VR.u8.slice(),OAM:OAM.u8.slice(),io:io.slice(),ie:ie.slice(),ifl:ifl.slice(),ime:ime.slice(),tc:tc.slice(),trl:trl.slice(),tl:tl.slice(),tacc:tacc.slice(),dsa:dsa.slice(),dda:dda.slice(),dn:dn.slice(),rx:rx.slice(),ry:ry.slice(),kcnt:kcnt,frames:frames,wcnt:wcnt,openBus:openBus,ipl:ipl,sv:sv.slice(),sg:[svT,fS,fId,fBank,fErase,fProg,fBankSet,eepOn,eepSz,eepAddr,eepRdPos,eepRd],cpu:cpu.getS(),au:sndSave()}}
function setSt(s:ReturnType<typeof getSt>):void{if(!s||s.v!==1||!s.cpu)throw new Error("estado inválido");EW.u8.set(s.EW);IW.u8.set(s.IW);PAL.u8.set(s.PAL);VR.u8.set(s.VR);OAM.u8.set(s.OAM);io.set(s.io);ie.set(s.ie);ifl.set(s.ifl);ime.set(s.ime);tc=s.tc.slice();trl=s.trl.slice();tl=s.tl.slice();tacc=s.tacc.slice();dsa=s.dsa.slice();dda=s.dda.slice();dn=s.dn.slice();rx=s.rx.slice();ry=s.ry.slice();kcnt=s.kcnt;frames=s.frames;wcnt=s.wcnt;openBus=s.openBus;ipl=s.ipl;sv.set(s.sv);var g=s.sg;svT=g[0];fS=g[1];fId=g[2];fBank=g[3];fErase=g[4];fProg=g[5];fBankSet=g[6];eepOn=g[7];eepSz=g[8];eepAddr=g[9];eepRdPos=g[10];eepRd=g[11];cpu.setS(s.cpu);if(s.au)sndLoad(s.au);else sndRestore();auReset();dirty=1;acc=0;fr=1}
cpu=mkCpu(7);
addEventListener("message",function(e){var d=e.data||{};
if(d.t==="init")init(d);
else if(d.t==="btn"){var b=KM[d.k];if(b!==undefined){if(d.v)kp|=1<<b;else kp&=~(1<<b);kcheck()}auWake()}
else if(d.t==="ff"){ffm=d.v?(d.m||4):1;acc=0;auReset()}
else if(d.t==="cfg"){setMode(d.mode|0)}
else if(d.t==="vol"){auVol(d.v)}
else if(d.t==="pause"){paused=d.v?1:0;auPause(d.v);if(d.v&&dirty)sramMsg()}
else if(d.t==="save"){sramMsg();setTimeout(function(){P({t:"saved"})},50)}
else if(d.t==="diag"){window.__dg=d.v?1:0}else if(d.t==="getst"){try{P({t:"state",data:getSt()})}catch(x){P({t:"nostate"})}}else if(d.t==="setst"){try{setSt(d.data);P({t:"stloaded",ok:1})}catch(x){P({t:"stloaded",ok:0,m:String(x instanceof Error ? x.message : String(x))})}}else if(d.t==="stop"){if(dirty)sramMsg();stopped=1;run=0;auClose()}});
addEventListener("resize",fit);

}
const GBA_DOC='<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><style>html,body{margin:0;height:100%;background:#000;overflow:hidden}#c{display:block;width:100%;height:100%;object-fit:contain}</style></head><body><canvas id="c" width="240" height="160"></canvas><script>'+FPSJS+'<\/script><script>('+gbaChild.toString()+')()<\/script></body></html>';
let gbOn=0,gbFr:HTMLIFrameElement|null=null,gbCur:SystemRomEntry<Blob>|null=null,gbWL:({release:()=>Promise<void>} & EventTarget)|null=null,gbT=0,gbHist=0;




const GB_EXIT="Sair do jogo? O progresso salvo dentro do jogo é mantido.";

