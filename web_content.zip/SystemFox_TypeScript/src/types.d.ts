/** Extensões dos tipos do navegador usadas pelo System Fox. */
interface Navigator {
  /** Quantidade aproximada de memória RAM exposta pelo navegador, em GB. */
  readonly deviceMemory?: number;
}

interface ScreenOrientation {
  lock(orientation: OrientationLockType): Promise<void>;
}

interface Window {
  __in0?: number;
  __invRects?: () => void;
  __rdp?: () => void;
  __rptr?: () => void;
  __setMode?: () => void;
  __upHome?: () => void;
  __toGames?: () => void;
  __resetInput?: () => void;
  showDirectoryPicker?: () => Promise<FileSystemDirectoryHandleLike>;
  webkitAudioContext?: typeof AudioContext;
  __padJump?: number;
  __g?: unknown;
  __und?: number;
  __undI?: number;
  __sw?: number;
  __swc?: number;
  __swu?: number;
  __fc?: number;
  __dg?: number;
  __pcs?: number[];
  __legacy?: number;
  lamejs?: { Mp3Encoder: new (channels: number, sampleRate: number, kbps: number) => { encodeBuffer(left: Int16Array, right: Int16Array): Uint8Array; flush(): Uint8Array } };
}


/** Interface mínima da File System Access API usada pelo seletor de pastas. */
interface FileSystemDirectoryHandleLike {
  entries(): AsyncIterableIterator<[string, FileSystemFileHandleLike | FileSystemDirectoryHandleLike]>;
  getFile?(): Promise<File>;
  readonly kind: "directory" | "file";
}
interface FileSystemFileHandleLike {
  readonly kind: "file";
  getFile(): Promise<File>;
}

interface HTMLElement { _tmp?: number; _t?: number; }
interface Element { _tmp?: number; }


/** Tipos compartilhados do catálogo e da persistência de ROMs. */
type SystemKey = "md" | "gb";
interface SystemRomEntry<TData extends Blob | Uint8Array = Blob | Uint8Array> {
  name: string;
  data: TData;
  size?: number;
}
interface SystemLibrary<TData extends Blob | Uint8Array = Blob | Uint8Array> {
  id: SystemKey;
  name: string;
  list: SystemRomEntry<TData>[];
  recent: string[];
  fav: string[];
  rk: string;
  fk: string;
  ck: string;
  re: RegExp;
  ph: string;
}
type AnySystemLibrary = SystemLibrary<Blob> | SystemLibrary<Uint8Array>;
interface GBCBatterySave {
  ram?: Uint8Array;
  rtc?: number;
}
interface GBCChannelState {
  on: number; dac: number; len: number; lenOn: number; freq: number;
  tmr: number; pos: number; duty: number; vol: number; iv: number;
  eD: number; eP: number; eT: number; sP: number; sD: number;
  sS: number; sT: number; sOn: number; sh: number;
}
interface GBCStateSnapshot {
  v: number; cgb: number; vb: number; wb: number;
  vram: Uint8Array; wram: Uint8Array; oam: Uint8Array;
  hram: Uint8Array; io: Uint8Array; ie: number;
  bgPal: Uint8Array; obPal: Uint8Array;
  A: number; F: number; B: number; C: number; D: number; E: number;
  H: number; L: number; SP: number; PC: number;
  ime: number; imeD: number; halted: number; hbug: number; dbl: number;
  div: number; tcnt: number; ly: number; mode: number; lcnt: number;
  wly: number; sl: number; hOn: number; hLeft: number; hs: number; hd: number;
  rb: number; ramOn: number; ramB: number; hiB: number; loB: number;
  mode1: number; rb5: number; lastL: number; rtcR: number[]; rtcBase: number;
  ram: Uint8Array | null; pw: number; fs: number; fsC: number; smC: number;
  lfsr: number; c1: GBCChannelState; c2: GBCChannelState;
  c3: GBCChannelState; c4: GBCChannelState;
}
interface GBCInitMessage {
  blob: Blob;
  id: number;
  sram?: GBCBatterySave | null;
}


/** Estrutura de canais e operadores do sintetizador FM usado pelo Mega Drive. */
interface YMOperatorState {
  mx: number; tl: number; ks: number; ar: number; d1: number; d2: number;
  sl: number; rr: number; ph: number; att: number; st: number;
}
interface YMChannelState {
  fn: number; bl: number; fb: number; al: number; hz: number;
  p1: number; p2: number; pl: number; pr: number; op: YMOperatorState[];
}
interface SystemMDZ80State {
  zF:number; zF2:number; zpc:number; zsp:number; zix:number; ziy:number; zx:number; zi:number;
  zrr:number; ziff1:number; ziff2:number; zim:number; zhalt:number; zint:number; zcyc:number;
  zbud:number; zbus:number; zrs:number; zbank:number; zbn:number; ZA2:number;
}
interface SystemMDLegacyZ80State {
  Z?:ArrayLike<number>; Z2?:ArrayLike<number>; v:number[]; ym?:ArrayLike<number>;
}
interface SystemMDYMState {
  registers:number[]; state:MegaDriveYMRuntime; channels:YMChannelState[];
}
interface SystemMDStateValues {
  RL:number; pend:number; cd:number; va:number; fill:number; vf:number; ip6:number; ip4:number;
  pad:number; th:number; line:number; hc:number; stopped:number; dmaBusy:number; pc:number; sr:number;
  EA:number; EM:number; ER:number; usp:number; sramOn:number; ilc:number; sdirty:number; sf:number;
  pdirty:number; xc:number; bk:number[]; Z80?:SystemMDZ80State; zs?:SystemMDLegacyZ80State;
  YM?:SystemMDYMState; PSG?:PSGRuntime;
}
type SystemMDTypedArray = Uint8Array | Uint16Array | Int32Array | Uint32Array;
interface SystemMegaDriveSnapshot {
  key:string; romName:string; arrays:Record<string,SystemMDTypedArray>; values:SystemMDStateValues;
  savedAt:number; stateVersion?:number;
}


/** Estruturas usadas diretamente pelo núcleo ARM7TDMI do GBA. */
interface GbaMemoryRegion {
  u8: Uint8Array;
  u16: Uint16Array;
  i32: Int32Array;
  m: number;
}
interface GbaBatterySave {
  ram?: Uint8Array;
  ev?: number;
}
interface GBAInitMessage {
  blob: Blob;
  id: number;
  sram?: GbaBatterySave | null;
}
interface GbaArmCpuState {
  R:Int32Array; N:number; Z:number; C:number; V:number; Q:number; I:number; F:number; T:number;
  md:number; cc:number; halted:number; waiting:number; waitPC:number; burnN:number;
  b13:Int32Array; b14:Int32Array; spsr:Int32Array; fq:Int32Array; us:Int32Array;
}
interface GbaArmCpu {
  R: Int32Array;
  run(n: number): void;
  boot(entry: number, sps: number, spi: number, spu: number): void;
  state(): { pc: number; t: number; md: number; cpsr: number; halted: number; w: number };
  getS(): GbaArmCpuState;
  setS(state: GbaArmCpuState): void;
  halt(value: number): void;
  setFlags(n: number, z: number, c: number, v: number): void;
  flags(): number[];
  step(): void;
  setT(value: number): void;
  setTr(callback: ((registers: Int32Array) => void) | null): void;
  isHalted(): number;
}

interface GbaSoundChannel {
  k: number; on: number; dac: number; len: number; lenOn: number; fr: number;
  tmr: number; pos: number; duty: number; vol: number; iv: number; eD: number;
  eP: number; eT: number; sP: number; sD: number; sS: number; sT: number;
  sOn: number; sh: number;
}


/** Estruturas da fila de áudio do núcleo GBA. */
interface GbaAudioRing {
  push(samples: Float32Array, length: number): void;
  reset(): void;
  fill(): number;
  target(): number;
  ratio(): number;
  jumps(): number;
  process(left: Float32Array, right: Float32Array): void;
}
interface GbaAudioRuntime {
  ctx: AudioContext | null;
  node: AudioNode | null;
  port: MessagePort | null;
  ring: GbaAudioRing | null;
  ok: number; rate: number; cps: number;
  buf: Float32Array | null; bn: number; sp: number;
  aL: number; aR: number; xl: number; xr: number;
  yl: number; yr: number; hl: Float32Array; hrr: Float32Array;
  hp: number; ph: number; fir: Float32Array | null; hr: number;
  vol: number; mg: number; cold: number;
}


/** Tipos da camada de interface, biblioteca e assistente do System Fox. */
type SystemGameKind = "md" | "gba" | "gbc" | "snes";
type SystemSaveMode = "save" | "load";
interface SystemGameListItem {
  S: AnySystemLibrary;
  i: number;
  r: SystemRomEntry<Blob | Uint8Array>;
  n: string;
}
interface SystemFoxAIMessage { role: "user" | "model"; text: string; }
interface SystemFoxApiResult { txt?: string; err?: string; status?: number; }
interface SystemFoxStateRecord { key?: string; savedAt?: number; name?: string; data?: unknown; }
interface SystemWakeLock { release(): Promise<void>; addEventListener(type: "release", listener: EventListener): void; }

interface MegaDriveAudioRuntime {
  ctx: AudioContext | null; node: ScriptProcessorNode | null; sr: number;
  buf: Float32Array; bR: Float32Array; l3: number; zc: number; w: number; r: number;
  on: number; pre: number; last: number; nf: number; q: number; l2: number; readFrac: number;
}
interface PSGRuntime { t: number[]; v: number[]; c: number[]; o: number[]; n: number; nc: number; lf: number; ch: number; vt: number; ac: number; }
interface RecordingRuntime { on: number; L: Int16Array[]; R: Int16Array[]; i: number; n: number; sr: number; }
interface MegaDriveYMRuntime {
 ad:number; pt:number; hi:number; fa:number; fb:number; ctl:number; ta:number; tb:number; nA:number; nB:number;
 dac:number; dv:number; ec:number; ect:number; L:number; R:number;
}
interface MegaDriveHitRect { k:number; cx:number; cy:number; lim:number; }
interface SystemGameSelection { S: AnySystemLibrary; i: number; }
