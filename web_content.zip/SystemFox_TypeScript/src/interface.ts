// System Fox — Interface, biblioteca e configurações em TypeScript


/* ===== Interface System Fox (v55) ===== */
(function(){
"use strict";
const $=<T extends HTMLElement=HTMLElement>(i:string):T=>document.getElementById(i) as T,B=document.body;
const qa=<T extends Element=HTMLElement>(s:string,r:ParentNode=document):T[]=>Array.from(r.querySelectorAll<T>(s));
const LS=(k:string,d:string):string=>{try{const v=localStorage.getItem(k);return v==null?d:v}catch(e){return d}};
const LSet=(k:string,v:string|number|boolean):void=>{try{localStorage.setItem(k,String(v))}catch(e){}};
const ICON={
 gear:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9.3" fill="none" stroke="currentColor" stroke-width="3" stroke-dasharray="3.7 3.7"/><circle cx="12" cy="12" r="7.2" fill="none" stroke="currentColor" stroke-width="3"/></svg>',
 folder:'<svg viewBox="0 0 24 24"><path d="M10 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-8l-2-2z"/></svg>',
 file:'<svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zm-1 7V3.5L18.5 9H13z"/></svg>',
 chip:'<svg viewBox="0 0 24 24"><rect x="6" y="6" width="12" height="12" rx="1" fill="none" stroke="currentColor" stroke-width="2"/><rect x="9.5" y="9.5" width="5" height="5"/><path d="M9 2v3M15 2v3M9 19v3M15 19v3M2 9h3M2 15h3M19 9h3M19 15h3" stroke="currentColor" stroke-width="2" fill="none"/></svg>',
 video:'<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="12" rx="1.5" fill="none" stroke="currentColor" stroke-width="2.4"/><path d="M8 20h8M12 16v4" stroke="currentColor" stroke-width="2.4" fill="none"/></svg>',
 audio:'<svg viewBox="0 0 24 24"><path d="M12 3v10.6A4 4 0 1 0 14 17V7h4V3h-6z"/></svg>',
 ai:'<svg viewBox="0 0 24 24"><path d="M4 4h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H9l-5 4v-4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z"/></svg>',
 pad:'<svg viewBox="0 0 24 24"><path d="M9 2h6v6.5H9zM9 15.5h6V22H9zM2 9h6.5v6H2zM15.5 9H22v6h-6.5z"/><circle cx="12" cy="12" r="2.6"/></svg>'
};
/* ---------- estado ---------- */
let sortM=LS("mssort","name"),query="",searching=0;
let mdTot=0,gbEx=0,playing=0,paused=0,sysK="md",kind:SystemGameKind="md",ff=0,gbFps=0,mdF=0,nav:string[]=[],leaving=0,sigLast="";
const AR:Record<SystemGameKind,number>={md:10/7,gba:3/2,gbc:10/9,snes:8/7};

/* ---------- lista de jogos ---------- */
function kindOf(S:AnySystemLibrary,r:SystemRomEntry<Blob|Uint8Array>):SystemGameKind{return S===MD?"md":SNRE.test(r.name)?"snes":/\.gba$/i.test(r.name)?"gba":"gbc"}
function rk(x:SystemGameListItem):number{const k=x.S.recent.indexOf(x.r.name);return(k<0?999:k)*2+(x.S===MD?0:1)}
function items():SystemGameListItem[]{
 let a:SystemGameListItem[]=[];[MD,GB].forEach(S=>S.list.forEach((r,i)=>a.push({S,i,r,n:gname(r.name)})));
 if(query){const q=query.toLowerCase();a=a.filter(x=>(x.n+" "+x.r.name).toLowerCase().includes(q))}
 if(sortM==="recent")a.sort((x,y)=>rk(x)-rk(y)||x.n.localeCompare(y.n));
 else if(sortM==="console")a.sort((x,y)=>(x.S===y.S?0:x.S===MD?-1:1)||x.n.localeCompare(y.n));
 else a.sort((x,y)=>x.n.localeCompare(y.n));
 return a}
function render(){
 sigLast=roms.length+","+gbroms.length;
 const L=$("mslst"),a=items();L.innerHTML="";
 if(!a.length){const e=document.createElement("div");e.className="msemp";
  e.innerHTML=query?"<div class=\"h\">Nada encontrado</div>Nenhum jogo combina com a pesquisa.":"<div class=\"h\">Nenhuma ROM</div>Adicione jogos de Mega Drive, Game Boy, Game Boy Color, Game Boy Advance ou Super Nintendo.<br><button>Adicionar jogos</button>";
  const b=e.querySelector("button");if(b)b.onclick=pickFiles;L.appendChild(e);return}
 a.forEach(x=>{const d=document.createElement("div");d.className="msr";
  const ic=mkIcon(x.S,x.r.name);ic.className="msi";d.appendChild(ic);
  const t=document.createElement("div");t.className="mst";
  const n=document.createElement("div");n.className="msn";n.textContent=x.n;
  const s=document.createElement("div");s.className="mss";const sp=document.createElement("span");sp.textContent=x.r.name;sp.style.cssText="direction:ltr;unicode-bidi:isolate";s.appendChild(sp);t.append(n,s);d.appendChild(t);
  const g=document.createElement("button");g.type="button";g.className="msgear";g.innerHTML=ICON.gear;
  g.setAttribute("aria-label","Opções do jogo");
  g.onclick=e=>{e.stopPropagation();askAct(x.S,x.i)};d.appendChild(g);
  d.onclick=()=>play(x.S,x.i);L.appendChild(d)})}
window.fillRl=render;
setInterval(()=>{if(!$("msl").hidden&&sigLast!==roms.length+","+gbroms.length)render()},500);
/* ---------- barra de cima (pesquisa / ordenar / menu) ---------- */
const bar=$("msbar");
function barNormal(){searching=0;query="";bar.innerHTML=barHTML();wireBar();render()}
function barHTML(){return '<div class="ttl" id="msttl">System Fox</div>'+
 '<button class="msib" id="mssbtn" aria-label="Pesquisar"><svg viewBox="0 0 24 24"><circle cx="10" cy="10" r="6" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M14.5 14.5L20.5 20.5" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" fill="none"/></svg></button>'+
 '<button class="msib" id="mssort" aria-label="Ordenar"><svg viewBox="0 0 24 24"><path d="M3 18h6v-2H3v2zM3 6v2h18V6H3zm0 7h12v-2H3v2z"/></svg></button>'+
 '<button class="msib" id="msmore" aria-label="Mais"><svg viewBox="0 0 24 24"><path d="M12 8a2 2 0 1 0 0-4 2 2 0 0 0 0 4zm0 2a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm0 6a2 2 0 1 0 0 4 2 2 0 0 0 0-4z"/></svg></button>'}
function wireBar(){
 $("mssbtn").onclick=()=>{searching=1;bar.innerHTML='<button class="msib" id="mssx" aria-label="Fechar"><svg viewBox="0 0 24 24"><path d="M20 11H7.8l5.6-5.6L12 4l-8 8 8 8 1.4-1.4L7.8 13H20z"/></svg></button><input id="mssrch" type="search" placeholder="Pesquisar" autocomplete="off">';
  const i=$("mssrch") as HTMLInputElement;i.oninput=()=>{query=i.value.trim();render()};$("mssx").onclick=barNormal;i.focus()};
 $("mssort").onclick=()=>popup([["name","Nome"],["recent","Recentes"],["console","Console"]],v=>{sortM=v;LSet("mssort",v);render()},sortM);
 $("msmore").onclick=()=>popup([["add","Adicionar jogos"],["dir","Adicionar pasta"],["set","Configurações"]].filter(x=>x[0]!=="dir"||window.showDirectoryPicker),v=>{
  if(v==="add")pickFiles();else if(v==="dir")pickDir();else openSettings()})}
wireBar();
function popup(list:readonly string[][],cb:(value:string)=>void,cur?:string):void{const m=$("msmenu"),p=$("mspop");p.innerHTML="";
 list.forEach(([v,t])=>{const d=document.createElement("div");d.textContent=t;if(v===cur)d.className="on";d.onclick=e=>{e.stopPropagation();m.hidden=true;cb(v)};p.appendChild(d)});
 m.hidden=false;m.onclick=()=>{m.hidden=true}}
/* ---------- importar ---------- */
/* ZIP: abre na hora de adicionar e manda o jogo de dentro para o console certo (GBA, SNES, Mega Drive, GB/GBC) */
const ROMX=/\.(gb|gbc|sgb|gba|sfc|smc|swc|fig|bin|md|gen|smd|sgd|rom)$/i;
async function unzipRom(f:File):Promise<File|null>{
 const u=new Uint8Array(await f.arrayBuffer()),dv=new DataView(u.buffer);let e=u.length-22;
 while(e>=0&&dv.getUint32(e,true)!==0x06054b50)e--;if(e<0)return null;
 const n=dv.getUint16(e+10,true);let o=dv.getUint32(e+16,true);
 for(let i=0;i<n;i++){
  if(dv.getUint32(o,true)!==0x02014b50)break;
  const meth=dv.getUint16(o+10,true),csz=dv.getUint32(o+20,true),nl=dv.getUint16(o+28,true),xl=dv.getUint16(o+30,true),cl=dv.getUint16(o+32,true),lh=dv.getUint32(o+42,true),name=new TextDecoder().decode(u.subarray(o+46,o+46+nl));
  o+=46+nl+xl+cl;if(!ROMX.test(name))continue;
  const st=lh+30+dv.getUint16(lh+26,true)+dv.getUint16(lh+28,true),raw=u.subarray(st,st+csz);let out:Uint8Array;
  if(meth===0)out=raw;else if(meth===8)out=new Uint8Array(await new Response(new Blob([raw]).stream().pipeThrough(new DecompressionStream("deflate-raw"))).arrayBuffer());else continue;
  return new File([out],name.split("/").pop())}
 return null}

function pickFiles(){$("msfile").click()}
$("msfile").onchange=async e=>{const input=e.currentTarget as HTMLInputElement;const f=Array.from(input.files||[]);input.value="";await imp(f)};
async function pickDir():Promise<void>{try{const out:File[]=[];const w=async(h:FileSystemDirectoryHandleLike):Promise<void>=>{for await(const [n,x] of h.entries()){if(x.kind==="file")out.push(await x.getFile());else await w(x)}};await w(await window.showDirectoryPicker!());await imp(out)}catch(x){if(!(x instanceof DOMException && x.name==="AbortError"))toast("Não consegui ler a pasta. Selecione os arquivos.")}}
async function imp(files:File[]):Promise<void>{
 const ex:File[]=[];for(const f of files){if(/\.zip$/i.test(f.name)){try{const x=await unzipRom(f);if(x)ex.push(x);else toast("Não achei um jogo dentro de "+f.name)}catch(e){toast("Não consegui abrir "+f.name)}}else ex.push(f)}
 files=ex;if(!files.length)return;const keep=system;
 const md=files.filter(f=>MD.re.test(f.name)),gb=files.filter(f=>!MD.re.test(f.name));
 try{if(md.length){system="md";await importFiles(md,false)}if(gb.length){system="gb";await importFiles(gb,false)}}catch(e){toast("Não consegui adicionar alguns arquivos.")}
 system=keep;render()}
/* ---------- navegação com o botão voltar ---------- */
function push(n:string):void{nav.push(n);try{history.pushState({ms:nav.length},"")}catch(e){}}
function closeTop(n:string):void{
 if(n==="sub")$("mssub").hidden=true;
 else if(n==="set"){$("mss").hidden=true;if(playing&&paused)$("msd").hidden=false}}
function back(){if(nav.length&&nav[nav.length-1]!=="game")history.back();else{const n=nav.pop();if(n)closeTop(n)}}
addEventListener("popstate",()=>{
 const n=(history.state&&history.state.ms)||0;
 while(nav.length>n){const t=nav.pop();
  if(t==="game"){if(leaving){leaving=0;leave();continue}
   nav.push("game");try{history.pushState({ms:nav.length},"")}catch(e){}
   if(!$("msai").hidden)closeAI();else if(!$("msslot").hidden)$("msslot").hidden=true;else if(!$("msd").hidden)resume();else showPause()}
  else closeTop(t)}});
qa("[data-back]").forEach(b=>b.onclick=back);

/* ---------- Assistente de IA (Gemini): conversa por texto sobre o jogo ---------- */
const AIK="msai_key",AIM="msai_model",AIDEF="gemini-flash-latest",AIP="msai_prov",AIOK="msai_okey",AIOM="msai_omodel",AIODEF="gpt-4o-mini";let aiHist:SystemFoxAIMessage[]=[],aiBusy=0,aiPausedByMe=false,aiFromPause=false,aiGameKey="";
function aiGame():string{try{const r=sysK==="md"?roms[curRom]:gbCur;return r?gname(r.name):"um jogo"}catch(e){return"um jogo"}}
function aiConsole():string{return{md:"Mega Drive",gba:"Game Boy Advance",gbc:"Game Boy / Game Boy Color",snes:"Super Nintendo"}[kind]||"videogame"}
function aiNetErr(e:unknown):string{const err=e as {name?:string;message?:string}|null;return err?.name==="AbortError"?"a IA não respondeu em 15 segundos (cancelado)":(err?.message||String(e))}
function aiSt(t:string):void{$("msaist").textContent=t||""}
function aiLoad():void{const k=aiGame();if(k===aiGameKey)return;aiGameKey=k;try{aiHist=JSON.parse(localStorage.getItem("msai_h:"+k)||"[]")}catch(e){aiHist=[]}}
function aiSave():void{try{localStorage.setItem("msai_h:"+aiGameKey,JSON.stringify(aiHist.slice(-24)))}catch(e){}}
function aiRich(el:HTMLElement,text:string):void{const lines=String(text).replace(/\r/g,"").split("\n");
 lines.forEach((ln,i)=>{if(i)el.appendChild(document.createElement("br"));
  ln=ln.replace(/^\s*[*-]\s+/,"• ").replace(/^#+\s*/,"");
  ln.split(/(\*\*[^*]+\*\*)/g).forEach(p=>{if(!p)return;if(/^\*\*[^*]+\*\*$/.test(p)){const s=document.createElement("strong");s.textContent=p.slice(2,-2);el.appendChild(s)}else el.appendChild(document.createTextNode(p.replace(/\*(?=\S)/g,"")))})})}
function aiRender(extra=""):void{const box=$("msaimsgs");box.replaceChildren();
 if(!aiHist.length&&!extra){const d=document.createElement("div");d.className="hint";d.textContent="Pergunte qualquer coisa sobre "+aiGame()+": como passar de uma fase, onde fica um item, dicas de chefe, controles, truques. A conversa fica guardada para este jogo.";box.appendChild(d)}
 aiHist.forEach(m=>{const d=document.createElement("div");d.className="aim "+(m.role==="user"?"u":"a");if(m.role==="user")d.textContent=m.text;else aiRich(d,m.text);box.appendChild(d)});
 if(extra){const d=document.createElement("div");d.className="aim a w";d.textContent=extra;box.appendChild(d)}
 box.scrollTop=box.scrollHeight}
function openAI(fromPause:boolean):void{
 if(!playing)return;aiFromPause=!!fromPause;relAll();
 if(!paused&&LS("msaipause","1")!=="0"){setPaused(true);aiPausedByMe=true}else aiPausedByMe=false;
 $("msd").hidden=true;$("msai").hidden=false;aiLoad();aiRender();aiSt(aiKey()?"":"Falta a chave da API. Vá em Configurações > Assistente de IA.");
 setTimeout(()=>{try{$("msaiin").focus()}catch(e){}},150)}
function closeAI(){$("msai").hidden=true;
 if(aiFromPause){$("msd").hidden=false}else if(aiPausedByMe){aiPausedByMe=false;setPaused(false)}}
const aiProv=()=>LS(AIP,"gemini")==="openai"?"openai":"gemini";
const aiKey=()=>LS(aiProv()==="openai"?AIOK:AIK,"").replace(/\s+/g,"");
const aiMod=()=>{const o=aiProv()==="openai",m=(LS(o?AIOM:AIM,"")||"").trim().replace(/^models\//,"").replace(/\s+/g,"");if(o)return m||AIODEF;return/^gemini-/i.test(m)?m:AIDEF};
let aiAbort:AbortController|null=null,aiCancel=0;
const aiBusyErr=(r:SystemFoxApiResult|null|undefined):boolean=>!!(r&&r.err&&(r.status===503||r.status===500||/high demand|overloaded|unavailable|try again later/i.test(r.err)||(r.status===429&&!/quota|credit|billing/i.test(r.err))));
async function aiCall(sys:string|null,msgs:SystemFoxAIMessage[],visible=false):Promise<SystemFoxApiResult>{
 const key=aiKey(),model=aiMod();aiCancel=0;let r:SystemFoxApiResult;
 for(let n=0;n<3;n++){
  const ac=new AbortController(),tm=setTimeout(()=>ac.abort(),15000);aiAbort=ac;
  try{r=await aiCall2(sys,msgs,key,model,ac.signal)}finally{clearTimeout(tm);if(aiAbort===ac)aiAbort=null}
  if(!aiBusyErr(r)||n===2)return r;
  if(visible)aiRender("A IA está ocupada, tentando de novo ("+(n+2)+"/3)…");
  await new Promise<void>(res=>setTimeout(res,2500*(n+1)));
  if(aiCancel){aiCancel=0;throw Object.assign(new Error("cancelado"),{name:"AbortError"})}
 }
 return r}
async function aiCall2(sys:string|null,msgs:SystemFoxAIMessage[],key:string,model:string,signal:AbortSignal):Promise<SystemFoxApiResult>{
 if(aiProv()==="openai"){
  const resp=await fetch("https://api.openai.com/v1/chat/completions",{method:"POST",signal,headers:{"Content-Type":"application/json","Authorization":"Bearer "+key},body:JSON.stringify({model,messages:[...(sys?[{role:"system",content:sys}]:[]),...msgs.map(m=>({role:m.role==="user"?"user":"assistant",content:m.text}))],max_completion_tokens:4096})});
  const j=await resp.json().catch(()=>({}));
  if(!resp.ok)return{err:String((j.error&&j.error.message)||("erro "+resp.status)),status:resp.status};
  return{txt:String((j.choices&&j.choices[0]&&j.choices[0].message&&j.choices[0].message.content)||"").trim()}}
 const body:{contents:Array<{role:"user"|"model";parts:{text:string}[]}>;generationConfig:{temperature:number;maxOutputTokens:number};systemInstruction?:{parts:{text:string}[]}}={contents:msgs.map(m=>({role:m.role==="user"?"user":"model",parts:[{text:m.text}]})),generationConfig:{temperature:.6,maxOutputTokens:4096}};
 if(sys)body.systemInstruction={parts:[{text:sys}]};
 const resp=await fetch("https://generativelanguage.googleapis.com/v1beta/models/"+encodeURIComponent(model)+":generateContent",{method:"POST",signal,headers:{"Content-Type":"application/json","x-goog-api-key":key},body:JSON.stringify(body)});
 const j=await resp.json().catch(()=>({}));
 if(!resp.ok)return{err:String((j.error&&j.error.message)||("erro "+resp.status)),status:resp.status};
 return{txt:((j.candidates&&j.candidates[0]&&j.candidates[0].content&&j.candidates[0].content.parts)||[]).map((p:{text?:string})=>p.text||"").join("").trim()}}
async function aiAsk(q:string):Promise<void>{
 if(aiBusy)return;const key=aiKey();if(!key){aiSt("Falta a chave da API. Vá em Configurações > Assistente de IA.");return}
 if(navigator.onLine===false){aiSt("Sem internet. O assistente precisa de conexão.");return}
 aiBusy=1;aiSt("");aiHist.push({role:"user",text:q});aiRender("Pensando…");

 const sys="Você é um especialista em videogames clássicos e em emulação, e está conversando com um jogador que está jogando "+aiGame()+" no "+aiConsole()+". Responda sempre em português do Brasil, com clareza e no tamanho que a pergunta pede: curto para dúvidas simples e passo a passo para guias e fases. Use o que você realmente sabe sobre este jogo (fases, chefes, itens, controles, truques, versões). Se a pergunta for vaga, peça um detalhe (qual fase, qual chefe) em vez de chutar. Se você não tiver certeza ou não conhecer o jogo ou a versão, diga isso claramente e nunca invente fases, itens ou códigos. Não repita a pergunta e não encha de avisos.";
 try{
  const r=await aiCall(sys,aiHist.slice(-14),true);
  if(r.err){aiHist.pop();aiRender();($("msaiin") as HTMLInputElement).value=q;aiSt("Erro da IA: "+r.err.slice(0,220)+" — confira a chave e o modelo em Configurações > Assistente de IA.");toast("Erro da IA: "+r.err.slice(0,100),6000);aiBusy=0;return}
  const txt=r.txt;
  if(!txt){aiHist.pop();aiRender();($("msaiin") as HTMLInputElement).value=q;aiSt("A IA não devolveu resposta (pode ter sido bloqueada). Tente perguntar de outro jeito.");aiBusy=0;return}
  aiHist.push({role:"model",text:txt});aiSave();aiRender()
 }catch(e){aiHist.pop();aiRender();($("msaiin") as HTMLInputElement).value=q;{aiSt("Não consegui falar com a IA: "+aiNetErr(e)+". Confira a internet e a chave.");toast("Falha: "+aiNetErr(e),5000)}}
 aiBusy=0}
$("msaiclose").onclick=closeAI;
$("msaiclr").onclick=()=>{aiCancel=1;try{if(aiAbort)aiAbort.abort()}catch(e){}aiBusy=0;aiHist=[];aiSave();aiRender();aiSt("")};
$("msaisend").onclick=()=>{const v=($("msaiin") as HTMLInputElement).value.trim();if(!v)return;if(aiBusy){aiSt("Ainda esperando a resposta anterior… toque em Limpar para cancelar.");return}($("msaiin") as HTMLInputElement).value="";aiAsk(v)};
$("msaiin").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey&&!/Android|iPhone|iPad/i.test(navigator.userAgent)){e.preventDefault();$("msaisend").click()}});
function mkIn(label:string,key:string,def:string,type:string,note:string|null):HTMLElement[]{const h=document.createElement("h4");h.textContent=label;h._tmp=1;const i=document.createElement("input");i.type=type;i.value=LS(key,def);i.autocomplete="off";i.spellcheck=false;i.oninput=()=>LSet(key,i.value.trim());i._tmp=1;const a=[h,i];if(note)a.push(mkTxt(note));return a}
async function aiTest():Promise<void>{const key=aiKey();if(!key)return toast("Cole a chave da API primeiro.");toast("Testando…");
 try{const r=await aiCall(null,[{role:"user",text:"Responda só: ok"}],false);toast(r.err?"Erro: "+r.err.slice(0,120):"Funcionou! A IA respondeu.",5000)}catch(e){toast("Falha: "+aiNetErr(e),5000)}}
async function pasteKey(i:HTMLInputElement,key:string){
 let t="";try{t=await navigator.clipboard.readText()}catch(e){}
 if(!t){try{t=prompt("Cole a chave aqui (segure o dedo no campo e escolha Colar):","")||""}catch(e){}}
 t=(t||"").replace(/\s+/g,"");if(!t)return toast("Nada para colar.");
 i.value=t;LSet(key,t);toast("Chave colada (termina em …"+t.slice(-4)+").",3500)}
function mkKey(label:string,key:string,note:string|null):HTMLElement[]{const a=mkIn(label,key,"","password",null),i=a[1] as HTMLInputElement;
 a.push(mkBtn("📋 Colar chave da área de transferência",()=>pasteKey(i,key)));
 a.push(mkBtn("Mostrar / esconder a chave",()=>{i.type=i.type==="password"?"text":"password"}));
 if(note)a.push(mkTxt(note));return a}
function aiRebuild():void{const s=SUBS.find(x=>x[0]==="ia"),c=$("mssubc"),hold=$("opts").querySelector(".ob");Array.from(c.children).forEach(n=>n._tmp?n.remove():hold.appendChild(n));s[4]().forEach(n=>c.appendChild(n))}
/* ---------- configurações ---------- */
qa<HTMLHeadingElement>("#opts .ob>h4").forEach(h=>{const nodes:HTMLElement[]=[h];let n=h.nextElementSibling as HTMLElement|null;while(n&&n.tagName!=="H4"){nodes.push(n);n=n.nextElementSibling as HTMLElement|null}
 secs[h.textContent.replace(/^[^\p{L}]+/u,"").trim()]=nodes});
const secs:Record<string,HTMLElement[]>={};
function sec(k:string,title=k):HTMLElement[]{const a=secs[k]||[];if(a[0])a[0].textContent=title||k;return a}
function mkSeg(title:string,key:string,opts:Array<[string,string]>,def:string,onc?:(value:string)=>void):HTMLElement[]{
 const h=document.createElement("h4");h.textContent=title;h._tmp=1;const d=document.createElement("div");d.className="seg";d._tmp=1;
 const sync=()=>qa("button",d).forEach(b=>b.classList.toggle("on",b.dataset.v===LS(key,def)));
 opts.forEach(([v,t])=>{const b=document.createElement("button");b.type="button";b.dataset.v=v;b.textContent=t;b.onclick=()=>{LSet(key,v);sync();onc&&onc(v)};d.appendChild(b)});
 sync();return[h,d]}
function mkTxt(t:string):HTMLParagraphElement{const p=document.createElement("p");p.textContent=t;p._tmp=1;return p}
function mkBtn(t:string,f:()=>void):HTMLButtonElement{const b=document.createElement("button");b.type="button";b.className="msflat";b.textContent=t;b.onclick=f;b._tmp=1;return b}
type SubEntry=[string,keyof typeof ICON,string,string,()=>HTMLElement[]];
const SUBS:SubEntry[]=[
 ["geral","gear","Geral","Velocidade, informações do app",()=>[...mkSeg("Velocidade do avanço rápido (botão ▶▶)","msffm",[["2","2x"],["3","3x"],["4","4x"]],"2",()=>{if(ff)setFF(1)}),...sec("Velocidade do jogo","Velocidade do jogo (Mega Drive)"),...sec("Dados e compatibilidade","Sobre"),mkTxt("System Fox v56 · emulador multissistema.")]],
 ["roms","folder","ROMs","Adicionar jogos, formatos aceitos",()=>{const a:HTMLElement[]=[mkBtn("Adicionar jogos",pickFiles)];if(window.showDirectoryPicker)a.push(mkBtn("Adicionar pasta",pickDir));
  a.push(mkTxt("Jogos na lista: "+(roms.length+gbroms.length)+". Mega Drive: BIN, MD, GEN, SMD, SGD e ROM. Game Boy / Color: GB e GBC. Game Boy Advance: GBA. Super Nintendo: SFC, SMC, SWC e FIG. Também aceita ZIP com um jogo dentro."));return a}],
 ["saves","file","Arquivos de salvamento","Salvar estado, progresso do jogo",()=>[mkTxt("O progresso salvo dentro do jogo (bateria) é gravado automaticamente ao sair. Os estados (Salvar/Carregar estado) usam 5 slots por jogo. Estado salvo funciona no Mega Drive, Game Boy, Game Boy Color e Game Boy Advance; no Super Nintendo ainda não."),
  mkBtn("Apagar todos os estados salvos",()=>ask("Apagar todos os estados salvos de todos os jogos?",clearStates))]],
 ["sistema","chip","Sistema","Desempenho, modo do GBA",()=>[...sec("Celular fraco","Desempenho do celular"),...mkSeg("Modo do Game Boy Advance","gbmode",[["0","Automático"],["1","Rápido"],["2","Preciso"]],"0",v=>gbMsg({t:"cfg",mode:+v})),...mkSeg("Diagnóstico do GBA (mostra dados técnicos na tela)","msdiag",[["0","Desligado"],["1","Ligado"]],"0",v=>gbMsg({t:"diag",v:+v}))]],
 ["video","video","Vídeo","Filtro, cores, contador de FPS",()=>[...sec("Filtro de imagem"),...sec("Cores do jogo"),...sec("Linhas de TV (scanlines)"),...mkSeg("Contador de FPS","msfps",[["1","Mostrar"],["0","Ocultar"]],"1",()=>fpsVis())]],
 ["audio","audio","Áudio","Som, gravação do áudio",()=>[...sec("Som (estéreo)"),...sec("Gravar áudio do jogo")]],
 ["ia","ai","Assistente de IA","Converse por texto sobre o jogo (Gemini ou ChatGPT)",()=>[...mkSeg("Qual IA usar",AIP,[["gemini","Gemini"],["openai","ChatGPT"]],"gemini",aiRebuild),...(aiProv()==="openai"?[...mkKey("Chave da API do ChatGPT (OpenAI)",AIOK,"Crie a chave em platform.openai.com/api-keys (começa com sk-). A assinatura ChatGPT Plus não inclui API: a chave tem cobrança separada. Ela fica só neste celular, dentro do navegador. Não compartilhe este arquivo com a chave dentro."),...mkIn("Modelo",AIOM,AIODEF,"text","O padrão é o gpt-4o-mini (barato). Se der erro de modelo, troque pelo nome de um modelo atual da OpenAI.")]:[...mkKey("Chave da API do Gemini",AIK,"Pegue a chave no Google AI Studio (aistudio.google.com). Ela fica só neste celular, dentro do navegador. Não compartilhe este arquivo com a chave dentro."),...mkIn("Modelo",AIM,AIDEF,"text","O padrão acompanha o Gemini Flash mais novo. Se der erro de modelo, troque pelo nome de um modelo Gemini atual.")]),mkBtn("Testar a IA",aiTest),...mkSeg("Pausar o jogo ao perguntar","msaipause",[["1","Sim"],["0","Não"]],"1"),mkTxt("O app envia só o texto da conversa, o nome do jogo e o console. Não envia imagem nem arquivo."),mkBtn("Apagar todas as conversas",()=>ask("Apagar as conversas com a IA de todos os jogos?",()=>{try{Object.keys(localStorage).filter(k=>k.indexOf("msai_h:")===0).forEach(k=>localStorage.removeItem(k))}catch(e){}aiHist=[];aiGameKey="";toast("Conversas apagadas.")}))]],
 ["entrada","pad","Entrada","Controles na tela, feedback (resposta) tátil",()=>[...mkSeg("Pulo mínimo no Mega Drive (quadros do jogo que o botão A, B, X ou Y fica apertado)","msjumpf",[["0","Desligado"],["6","Curto"],["9","Médio"],["12","Cheio"],["16","Máximo"]],"9"),mkTxt("Conta em quadros do jogo, e não em tempo, então vale igual mesmo se o celular rodar abaixo de 60 FPS. No Sonic, Médio (9) dá um pulo meio-alto e Cheio (12) faz um toque virar o pulo alto. Desligado deixa o toque rápido dar só um pulinho."),...sec("Game Boy Color · botões na tela","Mostrar controles na tela"),...sec("Game Boy Color · vibração","Vibração (feedback tátil)")]]
];
(function(){const L=$("msslst");SUBS.forEach(s=>{const d=document.createElement("div");d.className="msset";d.innerHTML=ICON[s[1]]+'<div class="tx"><div class="stt">'+s[2]+'</div><div class="sbt">'+s[3]+'</div></div>';d.onclick=()=>openSub(s);L.appendChild(d)})})();
function openSub(s:SubEntry){const c=$("mssubc"),hold=$("opts").querySelector(".ob");Array.from(c.children).forEach(n=>n._tmp?n.remove():hold.appendChild(n));s[4]().forEach(n=>c.appendChild(n));$("mssubt").textContent=s[2];$("mssub").hidden=false;$("mssub").querySelector(".lst").scrollTop=0;push("sub")}
function openSettings(){$("msd").hidden=true;$("mss").hidden=false;push("set")}
qa("#sdb button").forEach(b=>b.addEventListener("click",()=>setTimeout(applyCtl,0)));
function applyMono(){try{if(gbFr)gbFr.style.filter=LS("mdmono","0")==="1"?"grayscale(1)":""}catch(e){}}
qa("#sc button").forEach(b=>b.addEventListener("click",()=>setTimeout(applyMono,0)));
const ROWS:Record<string,number>={gba:160,gbc:144,snes:224};
function applyScan(){const el=$("msscan");if(!el)return;
 if(!playing||sysK==="md"||LS("mdscan","0")!=="1"||!gbFr){el.hidden=true;return}
 const r=gbFr.getBoundingClientRect(),p=r.height/(ROWS[kind]||200);
 if(!r.height||p<1.6){el.hidden=true;return}
 el.style.cssText="left:"+r.left+"px;top:"+r.top+"px;width:"+r.width+"px;height:"+r.height+"px;background-image:linear-gradient(to bottom,rgba(0,0,0,0) 0,rgba(0,0,0,0) 55%,rgba(0,0,0,.38) 55%,rgba(0,0,0,.38) 100%);background-size:100% "+p+"px";
 el.hidden=false}
qa("#sn button").forEach(b=>b.addEventListener("click",()=>setTimeout(applyScan,0)));
addEventListener("resize",()=>setTimeout(applyScan,200));addEventListener("orientationchange",()=>setTimeout(applyScan,400));

/* filtro "Suave" também nos outros consoles + tela sempre ligada durante o jogo */
function applyImg(){try{if(!gbFr||!gbFr.contentDocument)return;const sm=LS("mdfx","clean")==="smooth";gbFr.contentDocument.querySelectorAll("canvas").forEach(c=>{c.style.imageRendering=sm?"auto":"pixelated"})}catch(e){}}
qa("#sf button,#smoothbtn").forEach(b=>b.addEventListener("click",()=>setTimeout(applyImg,0)));
let wl:SystemWakeLock|null=null;
async function wakeOn(){try{if(navigator.wakeLock&&!wl){wl=await navigator.wakeLock.request("screen");wl.addEventListener("release",()=>{wl=null})}}catch(e){wl=null}}
function wakeOff(){try{if(wl){wl.release();wl=null}}catch(e){}}
document.addEventListener("visibilitychange",()=>{if(!document.hidden&&playing)wakeOn()});
function applyCtl(){B.classList.toggle("msnoctl",LS("gbbtn","1")==="0")}
function fpsVis(){$("msfps").hidden=!(playing&&LS("msfps","1")!=="0")}
function clearStates(){dbp.then(d=>{try{if(d&&d.objectStoreNames.contains("states")){d.transaction("states","readwrite").objectStore("states").clear();toast("Estados apagados.")}}catch(e){toast("Não foi possível apagar.")}})}
/* ---------- iniciar / sair do jogo ---------- */
function play(S:AnySystemLibrary,i:number):void{
 if(S===MD){const r=roms[i];if(!r)return;playRom(i);if(curRom!==i)return;enter("md")}
 else{const r=gbroms[i];if(!r||gbOn)return;gbHist=1;playGB(i);gbHist=0;if(!gbOn)return;enter(kindOf(GB,r))}}
function enter(k:SystemGameKind):void{
 playing=1;paused=0;kind=k;sysK=k==="md"?"md":"gb";ff=0;gbFps=0;mdF=0;
 B.classList.add("msp");B.style.setProperty("--arn",String(AR[k]||1.4286));
 $("msl").hidden=true;$("mss").hidden=true;$("mssub").hidden=true;$("msd").hidden=true;$("msslot").hidden=true;
 $("msc").hidden=false;$("msff").classList.remove("on");$("msff").dataset.m="";applyCtl();applyMono();wakeOn();setTimeout(applyScan,300);setTimeout(applyScan,1500);setTimeout(applyImg,800);setTimeout(applyImg,3500);fpsVis();
 push("game");
 try{const m=document.querySelector<HTMLMetaElement>('meta[name="theme-color"]');m&&(m.content="#000000")}catch(e){}
 try{if(!document.fullscreenElement&&document.documentElement.requestFullscreen)document.documentElement.requestFullscreen().catch(()=>{})}catch(e){}
 if(sysK==="md")spd=+LS("mdspd","1")||1}
function leave(){
 if(!playing&&$("msl").hidden===false)return;
 relAll();wakeOff();playing=0;paused=0;ff=0;B.classList.remove("msp");try{$("msscan").hidden=true}catch(e){}
 $("msc").hidden=true;$("msfps").hidden=true;$("msdiag").hidden=true;$("msd").hidden=true;$("msslot").hidden=true;$("mss").hidden=true;$("mssub").hidden=true;
 $("msl").hidden=false;barNormal();
 try{const m=document.querySelector<HTMLMetaElement>('meta[name="theme-color"]');m&&(m.content="#303030")}catch(e){}
 if(sysK==="md")spd=+LS("mdspd","1")||1}
window.__toGames=function(){nav.length=0;leave()};
window.__setMode=function(){B.dataset.mode="portrait";B.classList.remove("rot","menu")};
function exitGame(){
 if(sysK==="md"){try{if(currentKey)saveSram()}catch(e){}run=0;lid++;pad=0}
 else{try{gbExit()}catch(e){}}
 nav.length=0;leave();
 const g=history.state&&history.state.ms;if(g){try{history.go(-g)}catch(e){}}}
/* ---------- pausa ---------- */
function setPaused(on:boolean){if(!playing)return;paused=on?1:0;relAll();
 if(sysK==="md"){if(on){run=0}else{acc=0;run=1;startLoop()}}else gbMsg({t:"pause",v:on?1:0})}
function showPause(){setPaused(true);$("msd").hidden=false}
function resume(){$("msd").hidden=true;$("msslot").hidden=true;setPaused(false)}
$("msd").onclick=e=>{const target=e.target instanceof Element?e.target:null;const t=target?.closest("[data-a]") as HTMLElement|null;
 if(!t){if(target instanceof HTMLElement&&target.id==="msd")resume();return}
 const a=t.dataset.a;
 if(a==="set")openSettings();
 else if(a==="save")slots("save");else if(a==="load")slots("load");
 else if(a==="rst")restart();else if(a==="exit")exitGame();else if(a==="ai")openAI(true)};
function restart(){
 $("msd").hidden=true;
 if(sysK==="md"){const r=roms[curRom];if(r){paused=0;ff=0;$("msff").classList.remove("on");spd=+LS("mdspd","1")||1;startRom(r.data,r.name)}}
 else{const r=gbCur;if(r){gbHist=1;gbTeardown();gbOpen(r);gbHist=0;applyMono();setTimeout(applyScan,300);setTimeout(applyImg,800);paused=0;ff=0;$("msff").classList.remove("on")}}}
/* ---------- avanço rápido 2x ---------- */
function ffm(){return +LS("msffm","2")||2}
function setFF(v:number|boolean):void{ff=v?1:0;$("msff").classList.toggle("on",!!ff);$("msff").dataset.m=ff?ffm()+"x":"";
 if(sysK==="md"){spd=ff?ffm():(+LS("mdspd","1")||1);acc=0}else gbMsg({t:"ff",v:ff,m:ffm()})}
/* ---------- salvar / carregar estado ---------- */
function stKey(n:number):string{return sysK==="md"?currentKey+"#"+n:"gb"+gbId(gbCur.name)+"#"+n}
function slotInfo():Promise<number[]>{return dbp.then(d=>new Promise<number[]>(res=>{const out=[0,0,0,0,0];
 if(!d||!d.objectStoreNames.contains("states"))return res(out);
 try{const st=d.transaction("states").objectStore("states");let k=0;
  for(let n=1;n<=5;n++){const q=st.get(stKey(n));q.onsuccess=()=>{out[n-1]=q.result?(q.result.savedAt||1):0;if(++k===5)res(out)};q.onerror=()=>{if(++k===5)res(out)}}}catch(e){res(out)}}))}
function fmtDate(t:number):string{if(t<=1)return"salvo";const d=new Date(t),z=(n:number)=>String(n).padStart(2,"0");return z(d.getDate())+"/"+z(d.getMonth()+1)+" "+z(d.getHours())+":"+z(d.getMinutes())}
function slots(mode:SystemSaveMode):void{
 if(kind==="snes"){toast("Estado salvo ainda não funciona no Super Nintendo.");return}
 $("msslt").textContent=mode==="save"?"Salvar estado":"Carregar estado";
 const c=$("msslc");c.innerHTML="";$("msd").hidden=true;$("msslot").hidden=false;
 slotInfo().then(inf=>{c.innerHTML="";for(let n=1;n<=5;n++){const d=document.createElement("div");d.className="it";
  const t=inf[n-1];d.innerHTML="Slot "+n+"<small>"+(t?fmtDate(t):"Vazio")+"</small>";
  if(mode==="load"&&!t)d.classList.add("off");
  else d.onclick=()=>{$("msslot").hidden=true;mode==="save"?doSave(n):doLoad(n);resume()};
  c.appendChild(d)}})}
$("msslx").onclick=()=>{$("msslot").hidden=true;$("msd").hidden=false};
let stWait=0,pendSave=0,pendLoad=0;
new MutationObserver(()=>{if(stWait){stWait=0;toast($("st").textContent)}}).observe($("st"),{childList:true,characterData:true,subtree:true});
function putState(rec:SystemFoxStateRecord):Promise<boolean>{return dbp.then(d=>new Promise<boolean>(res=>{if(!d||!d.objectStoreNames.contains("states"))return res(false);try{const tx=d.transaction("states","readwrite");tx.objectStore("states").put(rec);tx.oncomplete=()=>res(true);tx.onerror=tx.onabort=()=>res(false)}catch(e){res(false)}}))}
function getState(k:string):Promise<SystemFoxStateRecord|null>{return dbp.then(d=>new Promise<{data?:unknown}|null>(res=>{if(!d||!d.objectStoreNames.contains("states"))return res(null);try{const q=d.transaction("states").objectStore("states").get(k);q.onsuccess=()=>res(q.result||null);q.onerror=()=>res(null)}catch(e){res(null)}}))}
function doSave(n:number):void{
 if(sysK==="md"){slot=n;LSet("mdslot",n);try{($("slotsel") as HTMLSelectElement).value=String(n)}catch(e){}stWait=1;saveState();setTimeout(()=>{stWait=0},4000)}
 else{pendSave=n;gbMsg({t:"getst"});setTimeout(()=>{if(pendSave===n){pendSave=0;toast("Não consegui salvar o estado.")}},3000)}}
function doLoad(n:number):void{
 if(sysK==="md"){slot=n;LSet("mdslot",n);try{($("slotsel") as HTMLSelectElement).value=String(n)}catch(e){}stWait=1;loadState();setTimeout(()=>{if(stWait){stWait=0;toast("Estado carregado (Slot "+n+")")}},700)}
 else getState(stKey(n)).then(r=>{if(!r||!r.data)return toast("Slot "+n+" vazio");pendLoad=n;gbMsg({t:"setst",data:r.data});setTimeout(()=>{if(pendLoad===n){pendLoad=0;toast("Não consegui carregar o estado.")}},3000)})}
addEventListener("message",e=>{
 if(!gbFr||e.source!==gbFr.contentWindow)return;const d=e.data||{};
 if(d.t==="fps"){gbFps=d.v;gbEx=d.x}
 else if(d.t==="start"){gbMsg({t:"diag",v:LS("msdiag","0")==="1"?1:0})}
 else if(d.t==="gbadiag"){const el=$("msdiag");if(LS("msdiag","0")==="1"&&playing){el.hidden=false;el.textContent=d.m}else el.hidden=true}
 else if(d.t==="state"&&pendSave){const n=pendSave;pendSave=0;putState({key:stKey(n),savedAt:Date.now(),name:gbCur.name,data:d.data}).then(ok=>toast(ok?"Estado salvo (Slot "+n+")":"Não foi possível salvar o estado."))}
 else if(d.t==="nostate"){pendSave=0;pendLoad=0;toast("Estado salvo ainda não funciona nesse console.")}
 else if(d.t==="stloaded"){const n=pendLoad;pendLoad=0;toast(d.ok?"Estado carregado"+(n?" (Slot "+n+")":""):"Estado incompatível com este jogo.")}});
/* ---------- contador de FPS ---------- */
{const _f=window.frame;if(typeof _f==="function")window.frame=function(){mdF++;mdTot++;const r=Reflect.apply(_f, this, arguments);for(const k in holdF){if(--holdF[k]<=0){delete holdF[k];key2(k,false)}}return r}}
setInterval(()=>{if(!playing||paused)return;const v=sysK==="md"?mdF:Math.round(gbEx?gbFps:gbFps*(ff?ffm():1));mdF=0;$("msfps").textContent="FPS: "+(v<0?"--":v)+(sysK==="md"&&typeof PF!=="undefined"&&PF>0?" · "+(PF>1?"muito leve":"leve"):"")},1000);
/* ---------- controles na tela ---------- */
const GBK:Record<string,number>={b:0,x:1,select:2,start:3,up:4,down:5,left:6,right:7,a:8,l:9,r:10};
const MDK:Record<string,number>={up:1,down:2,left:4,right:8,b:16,a:64,x:32,y:32,start:128,select:256};
const held=new Set<string>();
const holdF:Record<string,number>={},pressF:Record<string,number>={};function minHold(){const v=+LS("msjumpf","9");return isNaN(v)?9:v}
function mdAct(n:string):boolean{return sysK==="md"&&(n==="a"||n==="b"||n==="x"||n==="y")}
/* Mega Drive: o botão de pulo fica apertado por um mínimo de QUADROS DO JOGO (e não de milissegundos), então o pulo não depende de o celular rodar a 60 FPS */
function key(n:string,d:boolean|number):void{
 if(d){delete holdF[n];pressF[n]=mdTot;if(mdAct(n))window.__padJump=1}
 else if(mdAct(n)&&held.has(n)&&holdF[n]===undefined){const N=minHold(),el=mdTot-(pressF[n]||0);
  if(N&&el<N){holdF[n]=N-el;setTimeout(()=>{if(holdF[n]!==undefined){delete holdF[n];key2(n,false)}},900);return}}
 key2(n,d)}
function key2(n:string,d:boolean|number):void{if(d===held.has(n))return;d?held.add(n):held.delete(n);
 if(sysK==="md"){let m=0;held.forEach(k=>m|=MDK[k]||0);pad=m}else gbKey(GBK[n]??0,d?1:0);
 if(d&&LS("gbvib","1")!=="0"&&navigator.vibrate)try{navigator.vibrate(6)}catch(e){}}
function relAll(){Object.keys(holdF).forEach(k=>delete holdF[k]);Array.from(held).forEach(k=>key2(k,false));qa("#msc .p").forEach(e=>e.classList.remove("p"));["up","down","left","right"].forEach(n=>$("msdp").classList.remove("d-"+n))}
qa("#msc .mk[data-k]").forEach(el=>{const k=el.dataset.k;
 el.addEventListener("pointerdown",e=>{e.preventDefault();try{el.setPointerCapture(e.pointerId)}catch(x){}el.classList.add("p");key(k,1)});
 const u=()=>{el.classList.remove("p");key(k,0)};el.addEventListener("pointerup",u);el.addEventListener("pointercancel",u)});
qa("#msc .ib").forEach(el=>{el.addEventListener("pointerdown",e=>{e.preventDefault();el.classList.add("p")});
 const u=()=>el.classList.remove("p");el.addEventListener("pointerup",u);el.addEventListener("pointercancel",u);
 el.addEventListener("click",()=>{const a=el.dataset.a;if(a==="pause")showPause();else if(a==="ff")setFF(!ff);else if(a==="save")slots2("save");else if(a==="load")slots2("load");else if(a==="ai")openAI(false)})});
function slots2(m:SystemSaveMode):void{if(!playing)return;if(kind==="snes"){toast("Estado salvo ainda não funciona no Super Nintendo.");return}setPaused(true);slots(m)}
(function(){const dp=$("msdp");let on=0;
 const set=(n:string,v:boolean):void=>{key(n,v);dp.classList.toggle("d-"+n,v)};
 function mv(e:PointerEvent):void{const r=dp.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5,ax=Math.abs(x),ay=Math.abs(y),dx=ay>ax*1.8?0:x,dy=ax>ay*1.8?0:y;
  set("left",dx<-.13);set("right",dx>.13);set("up",dy<-.13);set("down",dy>.13)}
 const up=()=>{on=0;["up","down","left","right"].forEach(n=>set(n,false))};
 dp.addEventListener("pointerdown",e=>{e.preventDefault();on=1;try{dp.setPointerCapture(e.pointerId)}catch(x){}mv(e)});
 dp.addEventListener("pointermove",e=>{if(on)mv(e)});dp.addEventListener("pointerup",up);dp.addEventListener("pointercancel",up)})();
document.addEventListener("visibilitychange",()=>{if(document.hidden&&playing&&!paused)showPause()});
/* ---------- início ---------- */
["act","cf","cvf"].forEach(i=>{const e=$(i);if(e)B.appendChild(e)});
try{localStorage.setItem("mdmode","portrait")}catch(e){}
B.dataset.mode="portrait";
render();
})();

