// System Fox — Layout e orientação em TypeScript
type DisplayMode = "land" | "portrait";
type SpeedMode = "0.5" | "1" | "2";


(function(){const b=document.body,app=document.getElementById("app"),home=$("home"),games=$("games"),opts=$("opts"),pick=$("pick");
let mode:DisplayMode="land",ls=".7";
try{const savedMode=localStorage.getItem("mdmode");mode=savedMode==="portrait"?"portrait":"land";ls=localStorage.getItem("mdls2")||".7"}catch(e){}
function applyLs(){document.documentElement.style.setProperty("--ls",ls)}applyLs();
function fit(){const land=b.dataset.mode==="land",rot=land&&innerHeight>innerWidth;
b.classList.toggle("rot",rot);
if(land){const w=rot?innerHeight:innerWidth,h=rot?innerWidth:innerHeight;
app.style.width=w+"px";app.style.height=h+"px";app.style.transform=rot?"translateX("+innerWidth+"px) rotate(90deg)":"none"}
else{app.style.width=app.style.height=app.style.transform=""}}
function resetInput(){try{window.__invRects&&window.__invRects();window.__rdp&&window.__rdp();window.__rptr&&window.__rptr()}catch(e){}pad=0}
window.__resetInput=resetInput;
let ft:number[]=[],rt=0;
function refit(){ft.forEach(clearTimeout);ft=[0,80,250,600,1200].map(d=>setTimeout(()=>{fit();lw=0;if(d>=250)rebuildCanvas()},d));resetInput();if(run)startLoop()}
function softFit(){clearTimeout(rt);rt=setTimeout(fit,60)}
function setMode(m:DisplayMode):void{b.dataset.mode=m;b.classList.remove("menu");
if(m==="land"){try{const p=document.documentElement.requestFullscreen();p&&p.then(()=>screen.orientation.lock("landscape")).catch(()=>{})}catch(e){}}
else{try{screen.orientation.unlock()}catch(e){}try{if(document.fullscreenElement)document.exitFullscreen().catch(()=>{})}catch(e){}}
fit();refit()}
window.__setMode=()=>setMode(mode);
addEventListener("resize",softFit);
addEventListener("orientationchange",refit);
addEventListener("pageshow",refit);
document.addEventListener("fullscreenchange",refit);
try{screen.orientation.addEventListener("change",refit)}catch(e){}
if(window.visualViewport)visualViewport.addEventListener("resize",softFit);
document.getElementById("menubtn").onclick=()=>b.classList.toggle("menu");

/* ---- velocidade ---- */
let sp:SpeedMode="1";try{const savedSpeed=localStorage.getItem("mdspd");if(savedSpeed==="0.5"||savedSpeed==="1"||savedSpeed==="2")sp=savedSpeed}catch(e){}
const SPN:Record<SpeedMode,string>={"0.5":"Lento","1":"Normal","2":"Rápido (2x)"};
function applySp():void{spd=+sp;$("spdbtn").textContent="⏱ "+SPN[sp];document.querySelectorAll<HTMLElement>("#sv button").forEach(x=>x.classList.toggle("on",x.dataset.v===sp))}
function setSp(v:SpeedMode):void{sp=v;try{localStorage.setItem("mdspd",sp)}catch(e){}applySp();acc=0}
document.querySelectorAll<HTMLElement>("#sv button").forEach(x=>x.onclick=()=>{const v=x.dataset.v;if(v==="0.5"||v==="1"||v==="2")setSp(v)});
$("spdbtn").onclick=()=>{const o=["0.5","1","2"];setSp(o[(o.indexOf(sp)+1)%3] as SpeedMode)};
applySp();
/* ---- vista de menu: sempre em pé normal ---- */
function menuView(){b.dataset.mode="menu";b.classList.remove("rot","menu");app.style.width=app.style.height=app.style.transform="";lw=0}
/* ---- navegação das telas ---- */
function pkCnt(){try{const m=SYSS.md.list.length,g=SYSS.gb.list,a=g.filter(r=>/\.gba$/i.test(r.name)).length,sn=g.filter(r=>SNRE.test(r.name)).length,f=(n:number)=>n?n+(n===1?" jogo":" jogos"):"nenhum jogo";$("pkc_md").textContent=f(m);$("pkc_gbc").textContent=f(g.length-a-sn);$("pkc_gba").textContent=f(a);$("pkc_snes").textContent=f(sn)}catch(e){}}
function pkAnim(){pick.classList.remove("in");void pick.offsetWidth;pick.classList.add("in")}
function show(el:HTMLElement):void{[home,games,opts,pick].forEach(x=>x.hidden=x!==el);if(el===pick){pkCnt();pkAnim()}if(el===home)upHome();if(el===games)setTab(tab);if(el===opts)syncOpts()}
function canCont(){return!!lastGame()}
function upHome(){const L=lastGame();$("hc").style.opacity=L?"1":".45";$("hcs").textContent=L?gname(L.S.list[L.i].name):"";$("hmsg").textContent=""}
function goHome(){if(currentKey)saveSram();run=0;lid++;pad=0;resetInput();b.classList.remove("menu");menuView();
try{screen.orientation.unlock()}catch(e){}try{if(document.fullscreenElement)document.exitFullscreen().catch(()=>{})}catch(e){}
show(home);refit()}
function cont(){
const L=lastGame();
if(!L){show(games);return}
if(L.S===GB){playGB(L.i);return}
if(curRom!=null&&roms[curRom]&&currentKey&&roms[curRom].name===roms[L.i].name){[home,games,opts,pick].forEach(x=>x.hidden=true);setMode(mode);acc=0;run=1;startLoop();return}
playRom(L.i)}
$("hc").onclick=cont;
$("hl").onclick=()=>show(pick);
$("pbk").onclick=()=>show(home);
document.querySelectorAll<HTMLElement>("#pick .pt").forEach(t=>{t.onclick=()=>{const k=t.dataset.s;setSystem(k==="md"?"md":"gb");show(games)}});
$("ho").onclick=()=>show(opts);
$("hx").onclick=()=>{if(currentKey)saveSram();run=0;lid++;try{window.close()}catch(e){}setTimeout(()=>{$("hmsg").textContent="Pode fechar esta aba ou voltar ao navegador."},150)};
$("gbk").onclick=()=>show(pick);
$("obk").onclick=()=>show(home);
$("homebtn").onclick=goHome;
window.__upHome=upHome;
window.__toGames=function(){b.classList.remove("menu");menuView();try{if(document.fullscreenElement)document.exitFullscreen().catch(()=>{})}catch(e){}show(games);refit()};

/* ---- opções ---- */
function syncOpts(){applySp();document.querySelectorAll<HTMLElement>("#sm button").forEach(x=>x.classList.toggle("on",x.dataset.v===mode));
document.querySelectorAll<HTMLElement>("#ss button").forEach(x=>x.classList.toggle("on",x.dataset.v===ls));gbOptSync()}
document.querySelectorAll<HTMLElement>("#sm button").forEach(x=>x.onclick=()=>{const v=x.dataset.v;if(v!=="land"&&v!=="portrait")return;mode=v;try{localStorage.setItem("mdmode",mode)}catch(e){}syncOpts()});
document.querySelectorAll<HTMLElement>("#ss button").forEach(x=>x.onclick=()=>{ls=x.dataset.v;try{localStorage.setItem("mdls2",ls)}catch(e){}applyLs();syncOpts()});
syncOpts();upHome();
dbp.then(()=>setTimeout(upHome,introOn()?3200:300));

/* ---- opções do Game Boy Color ---- */
function gbMap():Record<string,[string,string]>{return{sdb:["gbbtn","1"],sdv:["gbvib","1"]}}
function gbOptSync(){const GBO=gbMap();for(const id in GBO){let v=GBO[id][1];try{v=localStorage.getItem(GBO[id][0])||v}catch(e){}document.querySelectorAll<HTMLElement>("#"+id+" button").forEach(x=>x.classList.toggle("on",x.dataset.v===v))}}
{const GBO=gbMap();for(const id in GBO)document.querySelectorAll<HTMLElement>("#"+id+" button").forEach(x=>x.onclick=()=>{try{localStorage.setItem(GBO[id][0],x.dataset.v)}catch(e){}gbOptSync()})}

/* ---- animação de entrada ---- */
const intro=$("intro");let inT=0;
function introOn():boolean{try{return localStorage.getItem("mdintro")!=="0"}catch(e){return true}}
let inS=0;
function introShow(){clearTimeout(inT);intro.classList.remove("go","out");
intro.hidden=true;void intro.offsetWidth;intro.hidden=false;
requestAnimationFrame(()=>{inS=performance.now();intro.classList.add("go");inT=setTimeout(introHide,2600)})}
function introHide(){clearTimeout(inT);if(intro.hidden||intro.classList.contains("out"))return;intro.classList.add("out");setTimeout(()=>{intro.hidden=true;intro.classList.remove("out","go")},240)}
intro.onclick=()=>{if(performance.now()-inS>250)introHide()};
function inSync(){document.querySelectorAll<HTMLElement>("#si button").forEach(x=>x.classList.toggle("on",x.dataset.v===(introOn()?"1":"0")))}
document.querySelectorAll<HTMLElement>("#si button").forEach(x=>x.onclick=()=>{try{localStorage.setItem("mdintro",x.dataset.v)}catch(e){}inSync()});
$("inprev").onclick=introShow;
inSync();
if(introOn()){inS=window.__in0||performance.now();intro.hidden=false;intro.classList.add("go");inT=setTimeout(introHide,Math.max(700,2600-(performance.now()-inS)))}else intro.hidden=true;
// ao voltar para o app depois de um tempo fora, o intro toca de novo (só nos menus, nunca durante um jogo)
requestAnimationFrame(()=>requestAnimationFrame(()=>intro.classList.remove("pre")));
let outAt=0;document.addEventListener("visibilitychange",()=>{if(document.hidden){outAt=performance.now();return}
if(outAt&&performance.now()-outAt>20000&&introOn()&&intro.hidden&&(!home.hidden||!games.hidden||!opts.hidden||!pick.hidden))introShow();outAt=0});

/* ---- filtro de imagem ---- */
function fxSync(){document.querySelectorAll<HTMLElement>("#sf button").forEach(x=>x.classList.toggle("on",x.dataset.v===fx));$("smoothbtn").classList.toggle("on",fx==="smooth");document.querySelectorAll<HTMLElement>("#sn button").forEach(x=>x.classList.toggle("on",x.dataset.v===String(scan)));document.querySelectorAll<HTMLElement>("#sc button").forEach(x=>x.classList.toggle("on",x.dataset.v===String(mono)))}
document.querySelectorAll<HTMLElement>("#sf button,#smoothbtn").forEach(x=>x.onclick=()=>{fx=x.dataset.v;try{localStorage.setItem("mdfx",fx)}catch(e){}rs();fxSync()});
document.querySelectorAll<HTMLElement>("#sc button").forEach(x=>x.onclick=()=>{mono=+x.dataset.v;try{localStorage.setItem("mdmono",String(mono))}catch(e){}applyFx();fxSync()});
document.querySelectorAll<HTMLElement>("#sn button").forEach(x=>x.onclick=()=>{scan=+x.dataset.v;try{localStorage.setItem("mdscan",String(scan))}catch(e){}fxSync()});
fxSync();

})();

