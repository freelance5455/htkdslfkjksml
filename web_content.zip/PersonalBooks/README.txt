PERSONAL BOOKS - Android project (wraps index.html in a WebView)

Build the APK:
1. Install Android Studio (free).
2. File > Open > choose this PersonalBooks folder. Let it sync (it downloads Gradle and the SDK).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Click "locate" in the popup. The file is app/build/outputs/apk/debug/app-debug.apk
5. Copy it to your phone and tap it. Allow "install unknown apps" for your file manager if asked.

Notes:
- Your data is saved on the phone (WebView local storage). Use Setup > Backup now regularly.
- Excel/PDF report buttons need internet the first time to load their libraries. Backup and CSV work offline.
- To update the app later, replace app/src/main/assets/index.html and build again.
