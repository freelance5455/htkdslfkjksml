APK ýasamak (kompýuter gerek däl, telefon bilen hem bolýar):
1. github.com-da mugt hasap aç, täze "Chat" repository döret.
2. Şu papkanyň ähli faýllaryny (.github bilen bilelikde) repository-e ýükle.
3. Actions -> "Build APK" -> Run workflow. ~5 minut gutarýança garaş.
4. Gutaranda Artifacts -> "chat-apk" -> ZIP-i ýükle, içindäki app-debug.apk-ni telefona guruzla.
5. Supabase -> Authentication -> URL Configuration -> Redirect URLs-e şuny goş: com.chatapp.app://auth
Index.html-i üýtgetseň, www/index.html-i täzele we ýene Run workflow et.
