p = 'android/app/src/main/AndroidManifest.xml'
s = open(p).read()
perm = ''.join(f'<uses-permission android:name="android.permission.{x}"/>' for x in ['CAMERA', 'RECORD_AUDIO', 'MODIFY_AUDIO_SETTINGS', 'ACCESS_NETWORK_STATE'])
feat = '<uses-feature android:name="android.hardware.camera" android:required="false"/><uses-feature android:name="android.hardware.microphone" android:required="false"/>'
link = '<intent-filter><action android:name="android.intent.action.VIEW"/><category android:name="android.intent.category.DEFAULT"/><category android:name="android.intent.category.BROWSABLE"/><data android:scheme="com.chatapp.app" android:host="auth"/></intent-filter>'
s = s.replace('</application>', '</application>' + perm + feat, 1).replace('</activity>', link + '</activity>', 1)
open(p, 'w').write(s)
