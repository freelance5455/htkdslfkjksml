const defaultMedicalTerms = [
    {
        id: 1,
        term: "Gastritis",
        pronunciation: "ګیسټرایټس",
        pashto: "د معدې التهاب",
        english: "Inflammation of the stomach",
        category: "Digestive System",
        root: "Gastr = Stomach",
        suffix: "-itis = Inflammation"
    },

    {
        id: 2,
        term: "Hepatitis",
        pronunciation: "هېپټایټس",
        pashto: "د ځیګر التهاب",
        english: "Inflammation of the liver",
        category: "Digestive System",
        root: "Hepat = Liver",
        suffix: "-itis = Inflammation"
    },

    {
        id: 3,
        term: "Carditis",
        pronunciation: "کارډایټس",
        pashto: "د زړه التهاب",
        english: "Inflammation of the heart",
        category: "Cardiovascular System",
        root: "Card = Heart",
        suffix: "-itis = Inflammation"
    },

    {
        id: 4,
        term: "Nephritis",
        pronunciation: "نیفرایټس",
        pashto: "د پښتورګي التهاب",
        english: "Inflammation of the kidney",
        category: "Urinary System",
        root: "Nephr = Kidney",
        suffix: "-itis = Inflammation"
    },

    {
        id: 5,
        term: "Arthritis",
        pronunciation: "آرترایټس",
        pashto: "د بندونو التهاب",
        english: "Inflammation of a joint",
        category: "Musculoskeletal System",
        root: "Arthr = Joint",
        suffix: "-itis = Inflammation"
    }
];