const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  onNewDocument: (callback) => ipcRenderer.on('menu-new-doc', callback),
  getVersion: () => process.versions.electron,
  isElectron: true
});