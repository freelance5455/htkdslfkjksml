/* ============ قاعدة البيانات المحلية ============ */
let sections = JSON.parse(localStorage.getItem('adv_sections')) || [
    "الموارد البشرية", "الحسابات والمالية", "الشؤون القانونية", 
    "المشتريات", "الإدارة العامة", "الدعم الفني", "العلاقات العامة"
];
let documents = JSON.parse(localStorage.getItem('adv_docs')) || [];

/* ============ التهيئة ============ */
window.onload = function() { 
    renderSections(); 
    renderDocuments(); 
    loadSavedLogo(); 
};

/* ============ أدوات مساعدة ============ */
function escapeHtml(s) {
    return String(s ?? '').replace(/[&<>"']/g, c => ({
        "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
    }[c]));
}

function safeSetItem(key, value) {
    try { 
        localStorage.setItem(key, value); 
        return true; 
    } catch (e) {
        alert("⚠️ الذاكرة المحلية ممتلئة. احذف وثائق قديمة.");
        return false;
    }
}

/* ============ إدارة الأقسام ============ */
function renderSections() {
    const selectEl = document.getElementById('doc-section');
    const listEl = document.getElementById('sidebar-sections-list');
    
    if (selectEl) selectEl.innerHTML = '<option value="">اختر القسم...</option>';
    if (listEl) listEl.innerHTML = '';
    
    sections.forEach((sec, idx) => {
        if (selectEl) selectEl.innerHTML += `<option value="${escapeHtml(sec)}">${escapeHtml(sec)}</option>`;
        if (listEl) {
            listEl.innerHTML += `
                <div class="section-item-row">
                    <span>📁 ${escapeHtml(sec)}</span>
                    <span style="cursor:pointer; color:var(--danger-color);" onclick="deleteSection(${idx})">❌</span>
                </div>`;
        }
    });
    
    const totalSectionsEl = document.getElementById('stat-total-sections');
    if (totalSectionsEl) totalSectionsEl.innerText = sections.length;
    safeSetItem('adv_sections', JSON.stringify(sections));
}

function addNewSection() {
    const inputEl = document.getElementById('new-section-name');
    const name = inputEl ? inputEl.value.trim() : "";
    if (!name) return;
    if (sections.includes(name)) {
        alert("هذا القسم موجود مسبقًا");
        return;
    }
    sections.push(name); 
    inputEl.value = ''; 
    renderSections(); 
}

function deleteSection(idx) { 
    const secName = sections[idx];
    const affected = documents.filter(d => d.section === secName).length;
    const msg = affected > 0
        ? `يوجد ${affected} وثيقة مرتبطة. هل تريد حذف القسم وتحويل وثائقه إلى "غير مصنف"؟`
        : "هل أنت متأكد من حذف هذا القسم؟";
    
    if (!confirm(msg)) return;
    
    documents.forEach(d => {
        if (d.section === secName) d.section = "غير مصنف";
    });
    
    sections.splice(idx, 1); 
    safeSetItem('adv_docs', JSON.stringify(documents));
    renderSections(); 
    renderDocuments();
}

/* ============ الشعار ============ */
function loadLogo(event) {
    const file = event.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function() {
        const img = document.getElementById('logo-img');
        const text = document.getElementById('logo-text');
        if (img) { img.src = reader.result; img.style.display = 'block'; }
        if (text) text.style.display = 'none';
        safeSetItem('adv_logo', reader.result);
    };
    reader.readAsDataURL(file);
}

function loadSavedLogo() {
    const logo = localStorage.getItem('adv_logo');
    if(logo) {
        const img = document.getElementById('logo-img');
        const text = document.getElementById('logo-text');
        if (img) { img.src = logo; img.style.display = 'block'; }
        if (text) text.style.display = 'none';
    }
}

/* ============ OCR ============ */
function runLiveOCR(files) {
    const file = files[0];
    if (!file) return;
    
    if (typeof Tesseract === 'undefined') {
        alert("مكتبة OCR غير محملة");
        return;
    }
    
    const statusText = document.getElementById('ocr-status-text');
    const resultBox = document.getElementById('ocr-fast-result');
    
    if (statusText) statusText.innerText = "⏳ جاري معالجة المستند واستخراج النصوص...";
    
    Tesseract.recognize(file, 'ara+eng').then(({ data: { text } }) => {
        if (statusText) statusText.innerText = "✅ اكتملت القراءة الذكية!";
        if (resultBox) {
            resultBox.value = text;
            resultBox.style.display = "block";
        }
        const keywordsInput = document.getElementById('doc-keywords');
        if (keywordsInput && !keywordsInput.value.trim()) {
            keywordsInput.value = text.replace(/\n/g, ' ').slice(0, 200);
        }
    }).catch(err => {
        if (statusText) statusText.innerText = "❌ حدث خطأ أثناء القراءة.";
        console.error(err);
    });
}

/* ============ حفظ وثيقة ============ */
function saveDocument(e) {
    e.preventDefault();
    const fileInput = document.getElementById('doc-file');
    if(!fileInput || !fileInput.files[0]) return;

    const file = fileInput.files[0];
    const extension = file.name.split('.').pop().toLowerCase();
    const randomCode = "ARC-" + new Date().getFullYear() + "-" + Math.floor(1000 + Math.random() * 9000);

    const reader = new FileReader();
    reader.onload = function() {
        const newDoc = {
            code: randomCode,
            name: document.getElementById('doc-name').value,
            section: document.getElementById('doc-section').value,
            date: document.getElementById('doc-date').value,
            keywords: document.getElementById('doc-keywords').value,
            fileName: file.name,
            fileType: extension,
            fileData: reader.result
        };

        documents.push(newDoc);
        if (!safeSetItem('adv_docs', JSON.stringify(documents))) {
            documents.pop();
            return;
        }
        
        const now = new Date();
        safeSetItem('adv_last_update', now.toLocaleTimeString('ar-EG') + " " + now.toLocaleDateString('ar-EG'));
        
        document.getElementById('archive-form').reset();
        const resultBox = document.getElementById('ocr-fast-result');
        const statusText = document.getElementById('ocr-status-text');
        if (resultBox) resultBox.style.display = "none";
        if (statusText) statusText.innerText = "";
        
        renderDocuments();
        alert("✅ تم حفظ الوثيقة بنجاح: " + randomCode);
    };
    reader.readAsDataURL(file);
}

/* ============ عرض الوثائق ============ */
function renderDocuments(records = documents) {
    const tbody = document.getElementById('documents-table-body');
    if (!tbody) return;

    if (records.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;color:#999;padding:20px;">📁 المستودع فارغ</td></tr>`;
        return;
    }

    tbody.innerHTML = records.map(doc => {
        let badgeClass = 'bg-pdf';
        const t = (doc.fileType || '').toLowerCase();
        let typeLabel = t.toUpperCase();
        if (['doc','docx'].includes(t)) badgeClass = 'bg-word';
        else if (['xls','xlsx'].includes(t)) badgeClass = 'bg-excel';
        else if (['jpg','jpeg','png','gif','bmp'].includes(t)) badgeClass = 'bg-image';
        else if (['zip','rar'].includes(t)) badgeClass = 'bg-zip';

        return `<tr>
            <td style="font-weight:bold;color:var(--accent-color);">${escapeHtml(doc.code)}</td>
            <td>${escapeHtml(doc.name)}</td>
            <td><span style="background:#eee;padding:3px 7px;border-radius:4px;">${escapeHtml(doc.section)}</span></td>
            <td>${escapeHtml(doc.date)}</td>
            <td><span class="file-badge ${badgeClass}">${typeLabel}</span></td>
            <td>
                <div class="action-row">
                    <button class="action-btn btn-primary" onclick="viewFile('${doc.code}')">👁️ عرض</button>
                    <button class="action-btn btn-danger" onclick="deleteDocument('${doc.code}')">حذف</button>
                </div>
            </td>
        </tr>`;
    }).join('');

    const totalEl = document.getElementById('stat-total-docs');
    if (totalEl) totalEl.innerText = documents.length;
    const update = localStorage.getItem('adv_last_update');
    const updateEl = document.getElementById('stat-last-update');
    if (update && updateEl) updateEl.innerText = update;
}

/* ============ البحث ============ */
function filterDocuments() {
    const searchInput = document.getElementById('search-input');
    if (!searchInput) return;
    
    const query = searchInput.value.toLowerCase().trim();
    if (!query) {
        renderDocuments();
        return;
    }
    
    const filtered = documents.filter(doc => {
        return (doc.name || '').toLowerCase().includes(query) || 
               (doc.code || '').toLowerCase().includes(query) || 
               (doc.section || '').toLowerCase().includes(query) || 
               (doc.fileType || '').toLowerCase().includes(query) ||
               (doc.keywords || '').toLowerCase().includes(query);
    });
    renderDocuments(filtered);
}

/* ============ معاينة ============ */
function viewFile(code) {
    const doc = documents.find(d => d.code === code);
    if (!doc) return;

    const modal = document.getElementById('preview-modal');
    const container = document.getElementById('modal-preview-body');
    const title = document.getElementById('modal-title');

    if (title) title.innerText = `👁️ معاينة: ${doc.name} (${doc.fileName})`;
    if (!container || !modal) return;

    container.innerHTML = '';
    if (['jpg','jpeg','png','gif','bmp'].includes(doc.fileType)) {
        container.innerHTML = `<img src="${doc.fileData}" class="preview-image">`;
    } else if (doc.fileType === 'pdf') {
        container.innerHTML = `<iframe src="${doc.fileData}" width="100%" height="100%"></iframe>`;
    } else {
        container.innerHTML = `
            <div style="text-align:center;padding:30px;width:100%;">
                <p style="font-size:2.5rem;">📄</p>
                <h4>مستند Office (${doc.fileType.toUpperCase()})</h4>
                <a href="${doc.fileData}" download="${doc.fileName}" class="btn btn-success" style="width:auto;display:inline-flex;">📥 تحميل الملف</a>
            </div>`;
    }
    modal.style.display = 'flex';
}

function closePreview() { 
    const modal = document.getElementById('preview-modal');
    if (modal) modal.style.display = 'none';
}

/* ============ حذف وثيقة ============ */
function deleteDocument(code) {
    if (!confirm("هل أنت متأكد من حذف هذه الوثيقة؟")) return;
    const idx = documents.findIndex(d => d.code === code);
    if (idx === -1) return;
    documents.splice(idx, 1);
    safeSetItem('adv_docs', JSON.stringify(documents));
    renderDocuments();
}

/* ============ إغلاق Modal ============ */
document.addEventListener('keydown', e => {
    if (e.key === 'Escape') closePreview();
});
document.getElementById('preview-modal')?.addEventListener('click', e => {
    if (e.target.id === 'preview-modal') closePreview();
});