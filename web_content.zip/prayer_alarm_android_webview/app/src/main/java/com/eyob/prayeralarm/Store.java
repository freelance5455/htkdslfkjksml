package com.eyob.prayeralarm;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Single source of truth: assets/prayers.js (fixed prayers) + SharedPreferences (personal alarms). */
final class Store {
    static final String PREFS = "prayer_store";
    static final int PERSONAL_BASE = 1000;   // personal alarm ids start here
    static final int SNOOZE_ID = 999;

    static final class Entry {
        final int id; final String title; final int hour; final int minute;
        Entry(int id, String title, int hour, int minute) {
            this.id = id; this.title = title; this.hour = hour; this.minute = minute;
        }
    }

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static String readAsset(Context c, String name) {
        try (InputStream in = c.getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "[]";
        }
    }

    static String prayersJson(Context c) {
        String s = readAsset(c, "prayers.js");          // "window.PRAYERS = [ ... ];"
        int a = s.indexOf('['), b = s.lastIndexOf(']');
        return (a >= 0 && b > a) ? s.substring(a, b + 1) : "[]";
    }
    static String personalJson(Context c) { return prefs(c).getString("personal", "[]"); }
    static void savePersonal(Context c, JSONArray a) {
        prefs(c).edit().putString("personal", a.toString()).apply();
    }

    // ---- user settings: master ON/OFF + hours switched off ----
    static boolean masterOn(Context c) { return prefs(c).getBoolean("master", true); }

    static Set<Integer> offSet(Context c) {
        Set<Integer> s = new HashSet<>();
        try {
            JSONArray a = new JSONArray(prefs(c).getString("off", "[]"));
            for (int i = 0; i < a.length(); i++) s.add(a.getInt(i));
        } catch (Exception ignored) { }
        return s;
    }

    static String offJson(Context c) { return prefs(c).getString("off", "[]"); }

    static boolean isEnabled(Context c, int id) { return masterOn(c) && !offSet(c).contains(id); }

    static void saveSettings(Context c, boolean on, String offJson) {
        String safe = "[]";
        try { safe = new JSONArray(offJson).toString(); } catch (Exception ignored) { }
        prefs(c).edit().putBoolean("master", on).putString("off", safe).apply();
    }

    static List<Entry> all(Context c) {
        List<Entry> list = new ArrayList<>();
        addFrom(list, prayersJson(c));
        addFrom(list, personalJson(c));
        return list;
    }

    static Entry find(Context c, int id) {
        for (Entry e : all(c)) if (e.id == id) return e;
        return null;
    }

    private static void addFrom(List<Entry> list, String json) {
        try {
            JSONArray a = new JSONArray(json);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                String[] t = o.getString("time").split(":");
                list.add(new Entry(o.getInt("id"), o.getString("name"),
                        Integer.parseInt(t[0].trim()), Integer.parseInt(t[1].trim())));
            }
        } catch (Exception ignored) { }
    }
}
