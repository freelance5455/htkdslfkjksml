package com.eyob.prayeralarm;

import android.app.*;
import android.content.*;
import android.media.*;
import android.os.*;
import androidx.core.app.NotificationCompat;

public class AlarmPlaybackService extends Service {
    private MediaPlayer player;
    private static final String CHANNEL = "prayer_alarm_channel";

    @Override public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "የፀሎት ማንቂያ",
                NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("የጸሎት ሰዓት ማንቂያ");
            ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String title = intent != null ? intent.getStringExtra("title") : "የጸሎት ሰዓት";
        Intent open = new Intent(this, AlarmActivity.class);
        open.putExtra("title", title);
        PendingIntent pi = PendingIntent.getActivity(this, 700, open,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title == null ? "የፀሎት ማንቂያ" : title)
            .setContentText("የጸሎት ጊዜ ደርሷል")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setFullScreenIntent(pi, true).setContentIntent(pi).setOngoing(true).build();
        startForeground(700, n);
        try {
            if (player == null) {
                player = MediaPlayer.create(this, getResources().getIdentifier("prayer_alarm", "raw", getPackageName()));
                if (player != null) {
                    player.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
                    player.setLooping(true);
                    player.start();
                }
            } else if (!player.isPlaying()) player.start();
        } catch (Exception ignored) {}
        return START_STICKY;
    }

    @Override public void onDestroy() {
        if (player != null) { try { player.stop(); } catch (Exception ignored) {} player.release(); player = null; }
        super.onDestroy();
    }
    @Override public android.os.IBinder onBind(Intent i) { return null; }
}
