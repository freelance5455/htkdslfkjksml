package com.eyob.prayeralarm;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

import androidx.core.app.NotificationCompat;
import androidx.core.app.ServiceCompat;

/** Plays the user's own MP3 (res/raw/prayer_alarm.mp3) in a loop on the ALARM stream. */
public class AlarmPlaybackService extends Service {
    static final String ACTION_STOP = "com.eyob.prayeralarm.STOP";
    static final String ACTION_STOPPED = "com.eyob.prayeralarm.ALARM_STOPPED";
    private static final String CHANNEL = "prayer_alarm_v2";
    private static final int NOTIF_ID = 700;
    private static final long MAX_RING_MS = 10 * 60 * 1000L;   // stop by itself after 10 minutes

    private MediaPlayer player;
    private Ringtone fallback;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable autoStop = () -> stopSelf();

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        int refId = intent != null ? intent.getIntExtra("refId", -1) : -1;
        String title = intent != null ? intent.getStringExtra("title") : null;
        if (title == null) title = "የፀሎት ሰዓት";

        createChannel();

        Intent open = new Intent(this, AlarmActivity.class);
        open.putExtra("refId", refId);
        open.putExtra("title", title);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 700, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, AlarmPlaybackService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 701, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification n = new NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(title)
                .setContentText("የፀሎት ሰዓት ደርሷል — ለመጸለይ ይንኩ")
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setFullScreenIntent(openPi, true)
                .setContentIntent(openPi)
                .setOngoing(true)
                .addAction(0, "አቁም", stopPi)
                .build();
        ServiceCompat.startForeground(this, NOTIF_ID, n,
                Build.VERSION.SDK_INT >= 29 ? ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK : 0);

        startSound();
        handler.removeCallbacks(autoStop);
        handler.postDelayed(autoStop, MAX_RING_MS);

        // Also try to open the prayer screen directly (works when the phone is allowed to; otherwise
        // the full-screen notification above shows it).
        try { startActivity(open); } catch (Exception ignored) { }
        return START_NOT_STICKY;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "የፀሎት ማንቂያ", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("የፀሎት ሰዓት ማንቂያ");
            ch.setSound(null, null);               // the MP3 is played by MediaPlayer, not by the notification
            ch.enableVibration(false);
            ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    private void startSound() {
        if (player != null || fallback != null) return;
        try {   // make sure the alarm volume is not (almost) silent
            AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
            int max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM);
            int want = Math.max(1, Math.round(max * 0.7f));
            if (am.getStreamVolume(AudioManager.STREAM_ALARM) < want)
                am.setStreamVolume(AudioManager.STREAM_ALARM, want, 0);
        } catch (Exception ignored) { }
        try {
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            AssetFileDescriptor afd = getResources().openRawResourceFd(R.raw.prayer_alarm);
            player.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            player.setLooping(true);
            player.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK);
            player.setOnPreparedListener(mp -> mp.start());
            player.setOnErrorListener((mp, what, extra) -> { playFallback(); return true; });
            player.prepareAsync();
        } catch (Exception e) {
            playFallback();
        }
    }

    /** Only used if the MP3 cannot be played: phone's default alarm sound. */
    private void playFallback() {
        releasePlayer();
        try {
            Uri u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            fallback = RingtoneManager.getRingtone(this, u);
            if (fallback != null) {
                fallback.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM).build());
                if (Build.VERSION.SDK_INT >= 28) fallback.setLooping(true);
                fallback.play();
            }
        } catch (Exception ignored) { }
    }

    private void releasePlayer() {
        if (player != null) {
            try { player.stop(); } catch (Exception ignored) { }
            try { player.release(); } catch (Exception ignored) { }
            player = null;
        }
    }

    @Override public void onDestroy() {
        handler.removeCallbacks(autoStop);
        releasePlayer();
        if (fallback != null) { try { fallback.stop(); } catch (Exception ignored) { } fallback = null; }
        sendBroadcast(new Intent(ACTION_STOPPED).setPackage(getPackageName()));   // closes the alarm screen
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent i) { return null; }
}
