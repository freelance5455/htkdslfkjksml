package com.eyob.prayeralarm;

import android.content.*;
import android.os.Build;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(i.getAction()) ||
            Intent.ACTION_MY_PACKAGE_REPLACED.equals(i.getAction())) {
            // Launching the app schedules the daily alarms again; boot receiver
            // also schedules all fixed alarms directly.
            String[] t = {"05:00","09:00","12:00","15:00","17:00","21:00","00:00"};
            String[] n = {"ነግሕ","ሦስት ሰዓት","ስድስት ሰዓት","ዘጠኝ ሰዓት","ሰርክ","ጸሎተ ንዋም","እኩለ ሌሊት"};
            for (int x=0; x<7; x++) {
                String[] p=t[x].split(":");
                java.util.Calendar cal=java.util.Calendar.getInstance();
                cal.set(java.util.Calendar.HOUR_OF_DAY,Integer.parseInt(p[0]));
                cal.set(java.util.Calendar.MINUTE,Integer.parseInt(p[1]));
                cal.set(java.util.Calendar.SECOND,0); cal.set(java.util.Calendar.MILLISECOND,0);
                if(cal.getTimeInMillis()<=System.currentTimeMillis()) cal.add(java.util.Calendar.DAY_OF_YEAR,1);
                Intent a=new Intent(c,AlarmReceiver.class); a.putExtra("alarmId",x); a.putExtra("title",n[x]);
                PendingIntent pi=PendingIntent.getBroadcast(c,x,a,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
                android.app.AlarmManager am=(android.app.AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
                if(Build.VERSION.SDK_INT>=23) am.setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),pi);
                else am.setExact(android.app.AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),pi);
            }
        }
    }
}
