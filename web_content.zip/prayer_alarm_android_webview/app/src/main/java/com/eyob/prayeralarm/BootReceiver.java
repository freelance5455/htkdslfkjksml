package com.eyob.prayeralarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import java.util.TimeZone;

/** Re-arms every alarm after reboot, app update, clock change or time-zone change. */
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        String a = i.getAction();
        if (a == null) return;
        if (Intent.ACTION_TIMEZONE_CHANGED.equals(a)) TimeZone.setDefault(null);  // re-read phone zone
        Scheduler.scheduleAll(c);
        if (Intent.ACTION_BOOT_COMPLETED.equals(a) || Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)) {
            try { androidx.core.content.ContextCompat.startForegroundService(c, new Intent(c, KeepAliveService.class)); }
            catch (Exception ignored) { }
        }
    }
}
