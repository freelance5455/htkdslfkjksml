package com.eyob.prayeralarm;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import androidx.core.app.NotificationCompat;
import androidx.core.app.ServiceCompat;

/**
 * Tiny silent foreground service. Phones such as Tecno / Infinix / itel / Xiaomi often kill idle apps
 * and delete their alarms; while this service runs the app stays alive, and every 15 minutes it
 * re-arms all alarms again (self-healing).
 */
public class KeepAliveService extends Service {
    private static final String CHANNEL = "prayer_keepalive";
    private static final int NOTIF_ID = 710;
    private static final long BEAT_MS = 15 * 60 * 1000L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable beat = new Runnable() {
        @Override public void run() {
            Scheduler.scheduleAll(KeepAliveService.this);
            handler.postDelayed(this, BEAT_MS);
        }
    };

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        Scheduler.scheduleAll(this);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "ማንቂያ በሥራ ላይ", NotificationManager.IMPORTANCE_MIN);
            ch.setShowBadge(false);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
        PendingIntent open = PendingIntent.getActivity(this, 2, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("የፀሎት ማንቂያ በሥራ ላይ ነው")
                .setContentText("የፀሎት ሰዓት ማንቂያዎች ዝግጁ ናቸው")
                .setPriority(NotificationCompat.PRIORITY_MIN)
                .setOngoing(true)
                .setShowWhen(false)
                .setContentIntent(open)
                .build();
        try {
            ServiceCompat.startForeground(this, NOTIF_ID, n,
                    Build.VERSION.SDK_INT >= 34 ? ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE : 0);
        } catch (Exception e) {
            stopSelf();
            return START_NOT_STICKY;
        }
        handler.removeCallbacks(beat);
        handler.postDelayed(beat, BEAT_MS);
        return START_STICKY;
    }

    @Override public void onDestroy() {
        handler.removeCallbacks(beat);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent i) { return null; }
}
