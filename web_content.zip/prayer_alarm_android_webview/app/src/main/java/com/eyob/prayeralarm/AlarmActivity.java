package com.eyob.prayeralarm;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.WebView;

import androidx.core.content.ContextCompat;

/** Full screen prayer page shown when an alarm rings (also over the lock screen). */
public class AlarmActivity extends Activity {
    private WebView web;
    private final BroadcastReceiver stopped = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { finish(); }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                    | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = Ui.createWebView(this, new Bridge(this, true));
        setContentView(Ui.wrap(this, web));
        ContextCompat.registerReceiver(this, stopped,
                new IntentFilter(AlarmPlaybackService.ACTION_STOPPED), ContextCompat.RECEIVER_NOT_EXPORTED);
        load(getIntent());
    }

    private void load(Intent in) {
        int ref = in.getIntExtra("refId", -1);
        String title = in.getStringExtra("title");
        if (title == null) title = "";
        web.loadUrl("file:///android_asset/alarm.html?ref=" + ref + "&title=" + Uri.encode(title));
    }

    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        load(i);
    }

    @Override protected void onDestroy() {
        try { unregisterReceiver(stopped); } catch (Exception ignored) { }
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
