package com.eyob.prayeralarm;

import android.app.Activity;
import android.content.*;
import android.os.Bundle;
import android.view.*;
import android.widget.*;

public class AlarmActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags( android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
            android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
            android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        String title = getIntent().getStringExtra("title");
        LinearLayout root = new LinearLayout(this); root.setOrientation(1);
        root.setGravity(Gravity.CENTER); root.setPadding(28,28,28,28);
        root.setBackgroundColor(0xFF102A43);
        TextView heading = new TextView(this); heading.setText("የፀሎት ማንቂያ");
        heading.setTextColor(0xFFFFFFFF); heading.setTextSize(28); heading.setGravity(Gravity.CENTER);
        TextView detail = new TextView(this); detail.setText((title == null ? "የጸሎት ጊዜ" : title) + "\n\nየጸሎት ጊዜ ደርሷል።");
        detail.setTextColor(0xFFFFFFFF); detail.setTextSize(22); detail.setGravity(Gravity.CENTER);
        Button snooze = new Button(this); snooze.setText("5 ደቂቃ አሳርፍ");
        snooze.setOnClickListener(v -> {
            stopService(new Intent(this, AlarmPlaybackService.class));
            Intent i = new Intent(this, AlarmReceiver.class); i.putExtra("alarmId",999); i.putExtra("title","የ5 ደቂቃ ማስታወሻ");
            PendingIntent p = PendingIntent.getBroadcast(this,999,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            ((android.app.AlarmManager)getSystemService(ALARM_SERVICE)).setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP,System.currentTimeMillis()+300000,p);
            finish();
        });
        Button stop = new Button(this); stop.setText("አቁም");
        stop.setOnClickListener(v -> { stopService(new Intent(this, AlarmPlaybackService.class)); finish(); });
        root.addView(heading); root.addView(detail); root.addView(snooze); root.addView(stop);
        setContentView(root);
    }
}
