package com.eyob.prayeralarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.core.content.ContextCompat;

public class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent in) {
        int id = in.getIntExtra("alarmId", -1);
        int refId = in.getIntExtra("refId", id);
        String title = in.getStringExtra("title");

        // 1) Re-arm tomorrow first, so the next day's alarm is safe even if something below fails.
        Store.Entry e = Store.find(c, id);
        if (e != null) {
            Scheduler.scheduleNext(c, e, 30_000L);
            if (title == null) title = e.title;
        }
        if (title == null) title = "የፀሎት ሰዓት";

        // 2) Start the sound + alarm screen.
        Intent s = new Intent(c, AlarmPlaybackService.class);
        s.putExtra("alarmId", id);
        s.putExtra("refId", refId);
        s.putExtra("title", title);
        ContextCompat.startForegroundService(c, s);
    }
}
