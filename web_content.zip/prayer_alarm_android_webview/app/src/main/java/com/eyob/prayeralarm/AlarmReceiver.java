package com.eyob.prayeralarm;

import android.content.*;
import android.os.Build;

public class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        Intent service = new Intent(context, AlarmPlaybackService.class);
        service.putExtra("title", intent.getStringExtra("title"));
        service.putExtra("alarmId", intent.getIntExtra("alarmId", 0));
        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(service);
        else context.startService(service);

        Intent screen = new Intent(context, AlarmActivity.class);
        screen.putExtra("title", intent.getStringExtra("title"));
        screen.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        context.startActivity(screen);

        int id = intent.getIntExtra("alarmId", 0);
        if (id >= 0 && id < 7) {
            // Repeat the fixed prayer alarm tomorrow.
            String[] t = {"05:00","09:00","12:00","15:00","17:00","21:00","00:00"};
            String[] names = {"ነግሕ","ሦስት ሰዓት","ስድስት ሰዓት","ዘጠኝ ሰዓት","ሰርክ","ጸሎተ ንዋም","እኩለ ሌሊት"};
            String[] p = t[id].split(":");
            java.util.Calendar c = java.util.Calendar.getInstance();
            c.set(java.util.Calendar.HOUR_OF_DAY, Integer.parseInt(p[0]));
            c.set(java.util.Calendar.MINUTE, Integer.parseInt(p[1]));
            c.set(java.util.Calendar.SECOND, 0); c.set(java.util.Calendar.MILLISECOND, 0);
            c.add(java.util.Calendar.DAY_OF_YEAR, 1);
            Intent next = new Intent(context, AlarmReceiver.class);
            next.putExtra("alarmId", id); next.putExtra("title", names[id]);
            android.app.PendingIntent pi = android.app.PendingIntent.getBroadcast(context, id, next,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT | android.app.PendingIntent.FLAG_IMMUTABLE);
            android.app.AlarmManager am = (android.app.AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
            if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);
            else am.setExact(android.app.AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);
        }
    }
}
