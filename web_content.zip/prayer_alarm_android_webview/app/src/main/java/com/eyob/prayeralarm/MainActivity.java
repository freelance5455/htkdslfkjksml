package com.eyob.prayeralarm;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.webkit.WebView;

public class MainActivity extends Activity {
    private WebView web;

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        web = Ui.createWebView(this, new Bridge(this, false));
        setContentView(Ui.wrap(this, web));
        web.loadUrl("file:///android_asset/index.html");
        Scheduler.scheduleAll(this);   // alarms are set automatically as soon as the app opens
        try { androidx.core.content.ContextCompat.startForegroundService(this, new Intent(this, KeepAliveService.class)); }
        catch (Exception ignored) { }
    }

    @Override protected void onResume() {
        super.onResume();
        nextSetupStep();
    }

    /** Asks (once each, one at a time) for the permissions that make the alarm reliable. */
    private void nextSetupStep() {
        SharedPreferences p = Store.prefs(this);

        if (Build.VERSION.SDK_INT >= 33 && !p.getBoolean("ask_notif", false)) {
            p.edit().putBoolean("ask_notif", true).apply();
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
                return;
            }
        }
        if (Build.VERSION.SDK_INT >= 34 && !p.getBoolean("ask_fsi", false)) {
            p.edit().putBoolean("ask_fsi", true).apply();
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (!nm.canUseFullScreenIntent()) {
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                            Uri.parse("package:" + getPackageName())));
                    return;
                } catch (Exception ignored) { }
            }
        }
        if (!p.getBoolean("ask_batt", false)) {
            p.edit().putBoolean("ask_batt", true).apply();
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (!pm.isIgnoringBatteryOptimizations(getPackageName())) {
                try {
                    startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                            Uri.parse("package:" + getPackageName())));
                } catch (Exception ignored) { }
            }
        }
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
