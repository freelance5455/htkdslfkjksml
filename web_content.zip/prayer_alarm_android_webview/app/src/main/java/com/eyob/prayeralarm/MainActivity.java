package com.eyob.prayeralarm;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.WebView;

import androidx.core.content.ContextCompat;

public class MainActivity extends Activity {
    private WebView web;

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        web = Ui.createWebView(this, new Bridge(this, false));
        setContentView(Ui.wrap(this, web));
        web.loadUrl("file:///android_asset/index.html");
        Scheduler.scheduleAll(this);   // alarms are set automatically as soon as the app opens
        try { ContextCompat.startForegroundService(this, new Intent(this, KeepAliveService.class)); }
        catch (Exception ignored) { }
    }

    @Override protected void onResume() {
        super.onResume();
        // Only the normal Android "allow notifications?" box, once. No jumping to Settings pages.
        SharedPreferences p = Store.prefs(this);
        if (Build.VERSION.SDK_INT >= 33 && !p.getBoolean("ask_notif", false)) {
            p.edit().putBoolean("ask_notif", true).apply();
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
            }
        }
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
