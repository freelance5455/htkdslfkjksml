package com.eyob.prayeralarm;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.webkit.*;
import android.widget.Toast;
import androidx.annotation.Nullable;

import java.util.Calendar;

public class MainActivity extends Activity {
    private WebView web;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        requestNotificationPermission();
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.addJavascriptInterface(new AlarmBridge(), "AndroidAlarm");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        scheduleAllPrayerAlarms();
        askExactAlarmPermissionIfNeeded();
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 101);
        }
    }

    private void askExactAlarmPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 31) {
            AlarmManager am = (AlarmManager)getSystemService(ALARM_SERVICE);
            if (!am.canScheduleExactAlarms()) {
                try {
                    startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                        Uri.parse("package:" + getPackageName())));
                } catch (Exception ignored) {}
            }
        }
    }

    // AlarmManager uses the phone's current local timezone. The display clock in JS converts it to Ethiopian time.\n    private void scheduleAllPrayerAlarms() {
        String[][] times = {
            {"ነግሕ", "05:00"}, {"ሦስት ሰዓት", "09:00"},
            {"ስድስት ሰዓት", "12:00"}, {"ዘጠኝ ሰዓት", "15:00"},
            {"ሰርክ", "17:00"}, {"ጸሎተ ንዋም", "21:00"},
            {"እኩለ ሌሊት", "00:00"}
        };
        for (int i=0; i<times.length; i++) scheduleDaily(i, times[i][0], times[i][1]);
    }

    private void scheduleDaily(int id, String title, String hhmm) {
        String[] p = hhmm.split(":");
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, Integer.parseInt(p[0]));
        c.set(Calendar.MINUTE, Integer.parseInt(p[1]));
        c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0);
        if (c.getTimeInMillis() <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR, 1);

        Intent i = new Intent(this, AlarmReceiver.class);
        i.putExtra("alarmId", id); i.putExtra("title", title);
        PendingIntent pi = PendingIntent.getBroadcast(this, id, i,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager)getSystemService(ALARM_SERVICE);
        if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);
        else am.setExact(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);
    }

    public class AlarmBridge {
        @JavascriptInterface public void addPersonalAlarm(int id, String title, String hhmm) {
            runOnUiThread(() -> scheduleDaily(1000 + id, title, hhmm));
        }
        @JavascriptInterface public void stopAlarm() {
            stopService(new Intent(MainActivity.this, AlarmPlaybackService.class));
        }
        @JavascriptInterface public void snoozeAlarm() {
            stopService(new Intent(MainActivity.this, AlarmPlaybackService.class));
            Intent i = new Intent(MainActivity.this, AlarmReceiver.class);
            i.putExtra("alarmId", 999); i.putExtra("title", "የ5 ደቂቃ ማስታወሻ");
            PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this, 999,
                i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            AlarmManager am = (AlarmManager)getSystemService(ALARM_SERVICE);
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,
                System.currentTimeMillis() + 5*60*1000, pi);
        }
    }
}
